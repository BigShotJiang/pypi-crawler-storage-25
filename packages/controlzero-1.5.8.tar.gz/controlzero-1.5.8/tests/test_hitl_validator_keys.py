"""Tests for HITL-5a (gh#538): policy validator additive surface in 1.5.8.

Covers every new branch in policy_loader.py:
- escalate_on_deny is recognized + plumbed into PolicyRule (default False).
- _levenshtein_le_1 helper: 0/1-edit pairs return True; >=2-edit pairs return False.
- Typo guardrail: warns on near-miss unknown rule keys (Levenshtein-1).
- Typo guardrail: silent on unknown keys far from any known one.
- Existing 1.5.7 policies (no escalate_on_deny field) still parse identically.
"""
from __future__ import annotations

from controlzero.policy_loader import (
    _KNOWN_RULE_KEYS,
    _levenshtein_le_1,
    load_policy,
)


class TestLevenshteinHelper:
    """Pure-function unit tests for _levenshtein_le_1."""

    def test_identical_strings_return_true(self):
        assert _levenshtein_le_1("escalate_on_deny", "escalate_on_deny") is True

    def test_empty_strings_return_true(self):
        assert _levenshtein_le_1("", "") is True

    def test_one_substitution(self):
        # tru -> true is one substitution? No, that's an insertion.
        # 'eqcalate_on_deny' vs 'escalate_on_deny': 'q'->'s' is one sub.
        assert _levenshtein_le_1("eqcalate_on_deny", "escalate_on_deny") is True

    def test_one_insertion(self):
        assert _levenshtein_le_1("escalate_on_dny", "escalate_on_deny") is True

    def test_one_deletion(self):
        # symmetric to insertion; helper handles both via a swap.
        assert _levenshtein_le_1("escalate_on_denyx", "escalate_on_deny") is True

    def test_two_substitutions_return_false(self):
        assert _levenshtein_le_1("escalate_on_dnen", "escalate_on_deny") is False

    def test_length_diff_gt_1_short_circuit(self):
        # Very different lengths: helper short-circuits without scanning.
        assert _levenshtein_le_1("a", "abc") is False
        assert _levenshtein_le_1("escalate", "escalate_on_deny") is False

    def test_completely_different_strings(self):
        assert _levenshtein_le_1("foo", "bar") is False

    def test_one_char_strings(self):
        assert _levenshtein_le_1("a", "a") is True
        assert _levenshtein_le_1("a", "b") is True  # one substitution
        assert _levenshtein_le_1("a", "") is True   # one deletion
        assert _levenshtein_le_1("", "a") is True   # one insertion

    def test_swap_branch_when_b_shorter_than_a(self):
        # Forces the la > lb swap branch.
        assert _levenshtein_le_1("escalate_on_deny", "escalate_on_den") is True

    def test_substitution_at_end(self):
        assert _levenshtein_le_1("escalate_on_denz", "escalate_on_deny") is True

    def test_diff_count_via_remaining_tail(self):
        # When inner loop exhausts a but b has tail; helper adds remaining.
        assert _levenshtein_le_1("foo", "fooxx") is False
        assert _levenshtein_le_1("foo", "foox") is True


class TestKnownRuleKeysAllowlist:
    """The _KNOWN_RULE_KEYS set is the typo-guardrail allowlist."""

    def test_escalate_on_deny_is_known(self):
        assert "escalate_on_deny" in _KNOWN_RULE_KEYS

    def test_legacy_keys_still_known(self):
        for k in ("id", "name", "deny", "allow", "effect", "action", "actions",
                  "resource", "resources", "when", "conditions", "reason",
                  "reason_code"):
            assert k in _KNOWN_RULE_KEYS, f"legacy key {k!r} missing from _KNOWN_RULE_KEYS"

    def test_no_unexpected_keys(self):
        # Defensive: if someone adds a new key, this test fails so they
        # remember to update the typo guardrail intentionally.
        expected = {
            "id", "name", "deny", "allow", "effect", "action", "actions",
            "resource", "resources", "when", "conditions", "reason",
            "reason_code", "escalate_on_deny",
        }
        assert _KNOWN_RULE_KEYS == expected


class TestEscalateOnDenyAdditive:
    """The new escalate_on_deny field flows into PolicyRule."""

    def test_default_false_when_absent(self):
        result = load_policy({
            "version": "1",
            "rules": [{"deny": "Bash:sudo *", "reason": "no sudo"}],
        })
        assert result.rules[0].escalate_on_deny is False

    def test_true_when_set(self):
        result = load_policy({
            "version": "1",
            "rules": [{
                "deny": "Bash:sudo *",
                "reason": "no sudo",
                "escalate_on_deny": True,
            }],
        })
        assert result.rules[0].escalate_on_deny is True

    def test_explicit_false_stays_false(self):
        result = load_policy({
            "version": "1",
            "rules": [{
                "deny": "Bash:sudo *",
                "escalate_on_deny": False,
            }],
        })
        assert result.rules[0].escalate_on_deny is False

    def test_truthy_non_bool_coerced_to_bool(self):
        # Defensive: customers may YAML-write `escalate_on_deny: 1` etc.
        result = load_policy({
            "version": "1",
            "rules": [{"deny": "Bash:sudo *", "escalate_on_deny": 1}],
        })
        assert result.rules[0].escalate_on_deny is True
        assert isinstance(result.rules[0].escalate_on_deny, bool)

    def test_falsy_non_bool_coerced_to_false(self):
        result = load_policy({
            "version": "1",
            "rules": [{"deny": "Bash:sudo *", "escalate_on_deny": 0}],
        })
        assert result.rules[0].escalate_on_deny is False

    def test_allow_rule_can_also_carry_field(self):
        # Field is rule-level, not effect-coupled.
        result = load_policy({
            "version": "1",
            "rules": [{
                "allow": "Bash:make test",
                "escalate_on_deny": True,
            }],
        })
        assert result.rules[0].escalate_on_deny is True
        assert result.rules[0].effect == "allow"


class TestTypoGuardrailWarnings:
    """The Levenshtein-1 typo guardrail surfaces 'did you mean?' warnings."""

    def test_warns_on_near_miss_to_escalate_on_deny(self, capsys):
        # `escalate_on_dny` is one deletion away from `escalate_on_deny`.
        # Levenshtein-1 catches deletions / insertions / substitutions but
        # NOT transpositions (those are distance 2 in basic Levenshtein).
        load_policy({
            "version": "1",
            "rules": [{
                "deny": "Bash:sudo *",
                "escalate_on_dny": True,  # one-deletion typo
            }],
        })
        captured = capsys.readouterr()
        assert "escalate_on_dny" in captured.err
        assert "escalate_on_deny" in captured.err
        assert "did you mean" in captured.err

    def test_silent_on_transposition_typo(self, capsys):
        # Transpositions are distance 2 (not 1), so we explicitly do NOT
        # warn on them. Documented behavior; if the typo guardrail ever
        # upgrades to Damerau-Levenshtein, this test breaks.
        load_policy({
            "version": "1",
            "rules": [{
                "deny": "Bash:sudo *",
                "escalate_on_dney": True,  # transposition (n<->e)
            }],
        })
        captured = capsys.readouterr()
        assert captured.err == ""

    def test_warns_on_actiom_typo(self, capsys):
        load_policy({
            "version": "1",
            "rules": [{
                "actiom": "Bash:make",  # near-miss for "action"
                "deny": "Bash:make",
            }],
        })
        captured = capsys.readouterr()
        assert "actiom" in captured.err
        assert "action" in captured.err

    def test_silent_on_far_unknown_keys(self, capsys):
        # An unknown key with no near-miss to any known key: silent.
        load_policy({
            "version": "1",
            "rules": [{
                "deny": "Bash:sudo *",
                "completely_made_up_field_xyz": "some value",
            }],
        })
        captured = capsys.readouterr()
        assert captured.err == ""

    def test_silent_when_all_keys_known(self, capsys):
        load_policy({
            "version": "1",
            "rules": [{
                "id": "r1",
                "name": "no sudo",
                "deny": "Bash:sudo *",
                "reason": "policy",
                "escalate_on_deny": True,
            }],
        })
        captured = capsys.readouterr()
        assert captured.err == ""

    def test_unknown_key_does_not_break_parsing(self):
        # Even with the typo warning fired, the rule should still parse.
        result = load_policy({
            "version": "1",
            "rules": [{
                "deny": "Bash:sudo *",
                "escalate_on_dney": True,  # typo
            }],
        })
        assert len(result.rules) == 1
        assert result.rules[0].effect == "deny"


class TestExisting157PoliciesStillParse:
    """Defensive: 1.5.7-shape policies (no escalate_on_deny) still parse identically."""

    def test_minimal_policy_unchanged(self):
        result = load_policy({
            "version": "1",
            "rules": [{"deny": "*"}],
        })
        assert result.rules[0].effect == "deny"
        assert result.rules[0].escalate_on_deny is False  # default

    def test_complex_policy_unchanged(self):
        result = load_policy({
            "version": "1",
            "settings": {"tamper_behavior": "warn"},
            "rules": [
                {"id": "r1", "deny": "Bash:sudo *", "reason": "no sudo"},
                {"id": "r2", "allow": "Bash:make *"},
                {"id": "r3", "deny": "*", "when": {"model": "claude-opus-*"}},
            ],
        })
        assert len(result.rules) == 3
        for rule in result.rules:
            assert rule.escalate_on_deny is False
