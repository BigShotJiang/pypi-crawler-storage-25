"""T104 regression tests: stale cache GC on key rotation.

Customer report 2026-05-12: rotated their api_key from one value to
another. The new key bootstrapped fresh but the prior key's
``cache/bundle-<oldscope>.bin`` lingered for 25 days next to the new
key's files. T104 GC's any cache files whose key-scope does NOT match
the currently-active api_key, but only on a fresh bootstrap (not on a
cache hit, because that means the active key is unchanged).
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from controlzero import hosted_policy
from controlzero.hosted_policy import (
    BootstrapKeys,
    _key_scope,
    gc_stale_cache,
)


@pytest.fixture
def fake_cache_dir(tmp_path, monkeypatch):
    cache_dir = tmp_path / ".controlzero" / "cache"
    cache_dir.mkdir(parents=True)

    def _fake_cache_dir():
        return cache_dir

    monkeypatch.setattr(hosted_policy, "_cache_dir", _fake_cache_dir)
    return cache_dir


def _write_cache_triplet(cache_dir: Path, scope: str) -> tuple[Path, Path, Path]:
    """Drop a (bootstrap, bundle.bin, bundle.meta) triplet for a key scope."""
    bootstrap = cache_dir / f"bootstrap-{scope}.json"
    bin_path = cache_dir / f"bundle-{scope}.bin"
    meta_path = cache_dir / f"bundle-{scope}.meta"
    bootstrap.write_text(json.dumps({"project_id": "x"}), encoding="utf-8")
    bin_path.write_bytes(b"\x00" * 64)
    meta_path.write_text('{"etag":"abc","checksum":"def"}', encoding="utf-8")
    return bootstrap, bin_path, meta_path


def test_gc_removes_files_for_rotated_keys(fake_cache_dir):
    """Stale triplet for the old scope is removed when the new scope is active."""
    _write_cache_triplet(fake_cache_dir, _key_scope("cz_live_oldscope0000"))
    new_files = _write_cache_triplet(
        fake_cache_dir, _key_scope("cz_live_newscope0000")
    )

    removed = gc_stale_cache("cz_live_newscope0000")

    assert removed == 3  # the old-scope triplet
    for stale_name in (
        f"bootstrap-{_key_scope('cz_live_oldscope0000')}.json",
        f"bundle-{_key_scope('cz_live_oldscope0000')}.bin",
        f"bundle-{_key_scope('cz_live_oldscope0000')}.meta",
    ):
        assert not (fake_cache_dir / stale_name).exists()
    for active in new_files:
        assert active.exists()


def test_gc_is_noop_when_only_active_key_present(fake_cache_dir):
    """No-op when every file already belongs to the active key."""
    _write_cache_triplet(fake_cache_dir, _key_scope("cz_live_newscope0000"))
    removed = gc_stale_cache("cz_live_newscope0000")
    assert removed == 0


def test_gc_leaves_unrelated_files_alone(fake_cache_dir):
    """Stray user files in the cache dir are preserved.

    A customer's machine had `s3_copy.py` in `~/.controlzero/`; we are
    not going to delete arbitrary user content even if they put it in
    our cache dir.
    """
    stray = fake_cache_dir / "README.txt"
    stray.write_text("notes", encoding="utf-8")
    config = fake_cache_dir / "random_user_file.yaml"
    config.write_text("foo: bar", encoding="utf-8")

    _write_cache_triplet(fake_cache_dir, _key_scope("cz_live_oldold__"))
    removed = gc_stale_cache("cz_live_active__")

    assert removed == 3  # only the cz_live_oldold__ triplet
    assert stray.exists()
    assert config.exists()


def test_gc_returns_zero_when_api_key_empty(fake_cache_dir):
    """Empty api_key returns 0 without touching anything (defensive)."""
    _write_cache_triplet(fake_cache_dir, "some_scope__")
    removed = gc_stale_cache("")
    assert removed == 0
    assert (fake_cache_dir / "bootstrap-some_scope__.json").exists()


def test_gc_handles_partial_triplets(fake_cache_dir):
    """Orphan bundle.bin without bootstrap (legacy state) still gets gc'd."""
    orphan = fake_cache_dir / "bundle-cz_live_orphan_.bin"
    orphan.write_bytes(b"\x00")
    removed = gc_stale_cache("cz_live_active__")
    assert removed == 1
    assert not orphan.exists()


def test_get_or_fetch_bootstrap_triggers_gc_on_fresh_fetch(
    fake_cache_dir, monkeypatch
):
    """A fresh bootstrap fetch triggers cache GC for rotated keys."""
    stale_scope = _key_scope("cz_live_oldscope0000")
    _write_cache_triplet(fake_cache_dir, stale_scope)

    fresh_keys = BootstrapKeys(
        project_id="proj",
        org_id="org",
        encryption_key=b"\x00" * 32,
        signing_pubkey=b"\x01" * 32,
        key_version=1,
    )

    def fake_fetch(api_key, api_url=None):
        assert api_key == "cz_live_newscope0000"
        return fresh_keys

    monkeypatch.setattr(hosted_policy, "fetch_bootstrap", fake_fetch)

    keys = hosted_policy.get_or_fetch_bootstrap("cz_live_newscope0000")
    assert keys.project_id == "proj"

    # Stale triplet gone, new bootstrap landed.
    new_scope = _key_scope("cz_live_newscope0000")
    assert not (fake_cache_dir / f"bootstrap-{stale_scope}.json").exists()
    assert not (fake_cache_dir / f"bundle-{stale_scope}.bin").exists()
    assert not (fake_cache_dir / f"bundle-{stale_scope}.meta").exists()
    assert (fake_cache_dir / f"bootstrap-{new_scope}.json").exists()


def test_get_or_fetch_bootstrap_no_gc_on_cache_hit(fake_cache_dir, monkeypatch):
    """Cache hit returns without GC -- active key is unchanged."""
    active_scope = _key_scope("cz_live_active__cafe")
    _write_cache_triplet(fake_cache_dir, active_scope)
    # Also drop an "orphan" triplet to verify it is NOT removed on a cache hit.
    orphan_scope = _key_scope("cz_live_orphan_dead")
    _write_cache_triplet(fake_cache_dir, orphan_scope)

    # Make load_cached_bootstrap return a valid cached value for the
    # active key so the code path takes the cache-hit branch.
    fresh_keys = BootstrapKeys(
        project_id="proj",
        org_id="org",
        encryption_key=b"\x00" * 32,
        signing_pubkey=b"\x01" * 32,
        key_version=1,
    )
    monkeypatch.setattr(
        hosted_policy, "load_cached_bootstrap", lambda k: fresh_keys
    )

    def must_not_fetch(*_args, **_kwargs):
        raise AssertionError("fetch should not run on cache hit")

    monkeypatch.setattr(hosted_policy, "fetch_bootstrap", must_not_fetch)

    keys = hosted_policy.get_or_fetch_bootstrap("cz_live_active__cafe")
    assert keys is fresh_keys
    # Orphan still present -- proves no GC fired.
    assert (fake_cache_dir / f"bootstrap-{orphan_scope}.json").exists()
