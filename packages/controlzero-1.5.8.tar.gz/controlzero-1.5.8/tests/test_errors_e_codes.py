"""Contract tests for E#### codes wired into existing exceptions
(Tier 0b, #174 follow-up, 2026-05-15).

Pins:
  - Each cataloged exception class carries the right E_CODE and
    surfaces it via the `e_code` property.
  - `str(exc)` keeps the original message text as a prefix
    (backwards compat for callers that match on substrings).
  - `str(exc)` appends the canonical fix + docs URL so users hit
    the right page from any error surface (CLI, log, traceback).
  - Un-cataloged exceptions (HostedModeNotImplemented) keep clean
    legacy behavior with no augmentation.
  - A typo / missing E#### code does not break the SDK error path.
"""

from __future__ import annotations

import pytest

from controlzero.errors import (
    BundleSignatureError,
    HostedAuthError,
    HostedBootstrapError,
    HostedModeNotImplemented,
    HybridModeError,
    PolicyLoadError,
    PolicyValidationError,
    _augment_with_code,
)


# ---------------------------------------------------------------------------
# Per-class E_CODE wiring
# ---------------------------------------------------------------------------


class TestECodeAttribute:
    """Each cataloged class has the right code on the e_code property."""

    def test_policy_validation_error_is_E1201(self) -> None:
        exc = PolicyValidationError(["bad field"], source="x.yaml")
        assert exc.e_code == "E1201"

    def test_policy_load_error_is_E1202(self) -> None:
        exc = PolicyLoadError("not found", source="x.yaml")
        assert exc.e_code == "E1202"

    def test_bundle_signature_error_is_E1203(self) -> None:
        exc = BundleSignatureError("sig mismatch")
        assert exc.e_code == "E1203"

    def test_hosted_auth_error_is_E1101(self) -> None:
        exc = HostedAuthError("401")
        assert exc.e_code == "E1101"

    def test_hosted_bootstrap_error_is_E1205(self) -> None:
        exc = HostedBootstrapError("no bundle")
        assert exc.e_code == "E1205"

    def test_hybrid_mode_error_is_E1204(self) -> None:
        exc = HybridModeError("conflict")
        assert exc.e_code == "E1204"

    def test_hosted_mode_not_implemented_has_no_code(self) -> None:
        # Legacy / deprecation path. No catalog entry; e_code is None.
        exc = HostedModeNotImplemented("legacy")
        assert exc.e_code is None


# ---------------------------------------------------------------------------
# str(exc) augmentation
# ---------------------------------------------------------------------------


class TestStrAugmentation:
    """The augmented str(exc) preserves the original message + appends
    the catalog code prefix + docs URL."""

    def test_original_message_kept_as_prefix(self) -> None:
        # Backwards compat: any test or caller that matches on the
        # original message must still pass.
        exc = PolicyValidationError(["field 'rules' is required"], source="foo.yaml")
        rendered = str(exc)
        assert "Policy validation failed for foo.yaml" in rendered
        assert "field 'rules' is required" in rendered

    def test_e_code_appended(self) -> None:
        exc = PolicyValidationError(["x"], source="y.yaml")
        assert "[E1201]" in str(exc)

    def test_docs_url_appended(self) -> None:
        exc = PolicyValidationError(["x"], source="y.yaml")
        assert "docs.controlzero.ai/errors/E1201" in str(exc)

    def test_bundle_signature_str_augmented(self) -> None:
        exc = BundleSignatureError("Policy bundle signature verification failed: bad sig")
        rendered = str(exc)
        assert "bad sig" in rendered
        assert "[E1203]" in rendered
        assert "docs.controlzero.ai/errors/E1203" in rendered

    def test_hosted_auth_error_str_augmented(self) -> None:
        exc = HostedAuthError("CZ key rejected")
        rendered = str(exc)
        assert "CZ key rejected" in rendered
        assert "[E1101]" in rendered

    def test_hosted_bootstrap_error_str_augmented(self) -> None:
        exc = HostedBootstrapError("no cached bundle")
        rendered = str(exc)
        assert "no cached bundle" in rendered
        assert "[E1205]" in rendered

    def test_hosted_mode_not_implemented_not_augmented(self) -> None:
        # Un-cataloged: should NOT carry code or docs URL.
        exc = HostedModeNotImplemented("legacy hosted mode")
        rendered = str(exc)
        assert "legacy hosted mode" in rendered
        assert "[E" not in rendered
        assert "docs.controlzero.ai/errors/" not in rendered


# ---------------------------------------------------------------------------
# Defensive behavior
# ---------------------------------------------------------------------------


class TestDefensiveBehavior:
    def test_augment_with_none_code_returns_message_verbatim(self) -> None:
        # A class that opts out via E_CODE=None passes None to the
        # helper. The helper must return the message untouched.
        assert _augment_with_code("hello", None) == "hello"

    def test_augment_with_unknown_code_returns_message_verbatim(self) -> None:
        # A typo or missing catalog entry must NOT raise -- the SDK
        # error path can't afford to crash inside an except block.
        assert _augment_with_code("hello", "E9999") == "hello"

    def test_isinstance_chain_preserved(self) -> None:
        # Existing callers do `except ValueError`, `except RuntimeError`
        # etc. The mixin must not break the inheritance chain.
        assert isinstance(PolicyValidationError(["x"]), ValueError)
        assert isinstance(HostedAuthError("x"), RuntimeError)
        assert isinstance(HostedBootstrapError("x"), RuntimeError)
        assert isinstance(HybridModeError("x"), RuntimeError)
        assert isinstance(HostedModeNotImplemented("x"), NotImplementedError)


# ---------------------------------------------------------------------------
# Constructor backwards compatibility
# ---------------------------------------------------------------------------


class TestConstructorCompat:
    """Pre-Tier-0b call sites pass a single message string. The new
    constructors must accept that positional usage unchanged."""

    def test_bundle_signature_accepts_positional_message(self) -> None:
        exc = BundleSignatureError("Policy bundle signature verification failed: bad")
        assert "bad" in str(exc)

    def test_hosted_auth_accepts_positional_message(self) -> None:
        exc = HostedAuthError("Control Zero API key rejected by backend")
        assert "Control Zero API key rejected by backend" in str(exc)

    def test_hosted_bootstrap_accepts_positional_message(self) -> None:
        exc = HostedBootstrapError("bootstrap request failed: connection refused")
        assert "connection refused" in str(exc)

    def test_policy_validation_kept_signature(self) -> None:
        # Signature didn't change for this one; pin it anyway.
        exc = PolicyValidationError(["field x missing"], source="foo.yaml")
        assert exc.errors == ["field x missing"]
        assert exc.source == "foo.yaml"

    def test_policy_load_error_kept_signature(self) -> None:
        cause = ValueError("parse fail")
        exc = PolicyLoadError("bad policy", source="foo.yaml", cause=cause)
        assert exc.source == "foo.yaml"
        assert exc.cause is cause
        rendered = str(exc)
        assert "bad policy" in rendered
        assert "ValueError" in rendered


# ---------------------------------------------------------------------------
# Catch chains used by callers
# ---------------------------------------------------------------------------


class TestCatchChains:
    """Real callsites use `except (HostedAuthError, HostedBootstrapError)`
    style catches. Pin that the changes don't break those chains."""

    def test_can_catch_via_runtime_error_base(self) -> None:
        with pytest.raises(RuntimeError):
            raise HostedAuthError("test")
        with pytest.raises(RuntimeError):
            raise HostedBootstrapError("test")
        with pytest.raises(RuntimeError):
            raise HybridModeError("test")

    def test_can_catch_via_value_error_base(self) -> None:
        with pytest.raises(ValueError):
            raise PolicyValidationError(["x"])

    def test_can_catch_via_concrete_class(self) -> None:
        with pytest.raises(BundleSignatureError):
            raise BundleSignatureError("test")
