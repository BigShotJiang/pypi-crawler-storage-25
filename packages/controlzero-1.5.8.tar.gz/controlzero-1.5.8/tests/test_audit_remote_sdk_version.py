"""Contract tests for the controlzero_sdk_version wire field.

#495 / v1 (2026-05-14): every audit POST must carry a normalized
"<lang>@<version>" SDK version so the backend can disambiguate the
controlzero SDK package from the host CLI version. This test pins
the wire-format invariant on both audit sinks (RemoteAuditSink for
enrolled-mode + BearerAuditSink for hosted-mode).

Failure modes covered:
  - missing field on the wire (regression of the wire-format add)
  - wrong shape (drops the "python@" prefix)
  - over-cap value (would pollute the LowCardinality column on the
    backend; we cap at 64 chars at construction time)
  - drifts from the canonical __version__ exported by the package
"""

from __future__ import annotations

from controlzero import __version__ as PACKAGE_VERSION
from controlzero.audit_remote import (
    BearerAuditSink,
    RemoteAuditSink,
    _CZ_SDK_VERSION_WIRE,
)


# ---------------------------------------------------------------------------
# Wire-format constant
# ---------------------------------------------------------------------------


class TestSDKVersionWireConstant:
    def test_wire_format_is_python_prefixed(self) -> None:
        """The constant must be `python@<version>` so the backend can
        group across SDKs without the bare "1.9.1" colliding with Node."""
        assert _CZ_SDK_VERSION_WIRE.startswith("python@")

    def test_wire_format_carries_canonical_version(self) -> None:
        """Drift guard: if someone forks the constant from the source
        of truth (controlzero.__version__), this test fails loudly."""
        assert _CZ_SDK_VERSION_WIRE == f"python@{PACKAGE_VERSION}"

    def test_wire_format_under_64_chars(self) -> None:
        """Backend caps the controlzero_sdk_version column at 64 chars
        (LowCardinality dict-encoded). The wire constant must respect
        the cap so over-length values never round-trip. The construction
        in audit_remote.py truncates to 64 chars."""
        assert len(_CZ_SDK_VERSION_WIRE) <= 64

    def test_wire_format_non_empty(self) -> None:
        """A blank wire constant means the package version export is
        broken. The audit pipeline would carry empty strings into
        production. Fail loudly here."""
        assert _CZ_SDK_VERSION_WIRE != ""
        assert _CZ_SDK_VERSION_WIRE != "python@"


# ---------------------------------------------------------------------------
# RemoteAuditSink (enrolled mode)
# ---------------------------------------------------------------------------


class TestRemoteAuditSinkWireFormat:
    def test_to_wire_includes_controlzero_sdk_version(self, tmp_path) -> None:
        """The enrolled-mode sink must include the field on every entry
        it builds for the backend POST."""
        sink = RemoteAuditSink(
            api_url="https://api.example.com",
            machine_token="not-used-for-test",
            org_id="00000000-0000-0000-0000-000000000000",
            machine_id="test-machine",
            state_dir=tmp_path,
        )
        wire = sink._to_wire_format({
            "tool": "test_tool",
            "decision": "allow",
            "policy_id": "rule-0",
            "reason": "test",
            "mode": "local",
        })
        assert "controlzero_sdk_version" in wire
        assert wire["controlzero_sdk_version"] == _CZ_SDK_VERSION_WIRE

    def test_wire_format_distinct_from_client_version(self, tmp_path) -> None:
        """The whole point of the v1 column is to disambiguate the
        controlzero SDK version from the host CLI version. Make sure
        the two wire fields are distinct keys, not aliases."""
        sink = RemoteAuditSink(
            api_url="https://api.example.com",
            machine_token="not-used-for-test",
            org_id="00000000-0000-0000-0000-000000000000",
            machine_id="test-machine",
            state_dir=tmp_path,
        )
        wire = sink._to_wire_format({"tool": "x", "decision": "allow"})
        # Both keys present.
        assert "controlzero_sdk_version" in wire
        assert "client_version" in wire
        # client_version is the host CLI version (e.g. "claude-code/1.0").
        # Different shape, different meaning.
        assert wire["controlzero_sdk_version"] != wire["client_version"]


# ---------------------------------------------------------------------------
# BearerAuditSink (hosted mode)
# ---------------------------------------------------------------------------


class TestBearerAuditSinkWireFormat:
    def test_to_wire_includes_controlzero_sdk_version(self) -> None:
        """The hosted-mode sink (Bearer auth, IngestViaAPIKey backend
        path) must mirror the field on every entry it builds. Both
        sinks producing identical row shapes is the contract the
        backend depends on."""
        sink = BearerAuditSink(
            api_url="https://api.example.com",
            api_key="cz_test_fakekey",
        )
        wire = sink._to_wire_format({
            "tool": "test_tool",
            "decision": "deny",
            "policy_id": "rule-1",
            "reason": "test",
            "mode": "hosted",
        })
        assert "controlzero_sdk_version" in wire
        assert wire["controlzero_sdk_version"] == _CZ_SDK_VERSION_WIRE

    def test_both_sinks_emit_identical_sdk_version_shape(self, tmp_path) -> None:
        """The backend's ingest path expects the wire field to be the
        same string regardless of which sink emits it. Pin that."""
        bearer = BearerAuditSink(
            api_url="https://api.example.com",
            api_key="cz_test_fakekey",
        )
        remote = RemoteAuditSink(
            api_url="https://api.example.com",
            machine_token="not-used-for-test",
            org_id="00000000-0000-0000-0000-000000000000",
            machine_id="test-machine",
            state_dir=tmp_path,
        )
        entry = {"tool": "x", "decision": "allow"}
        assert bearer._to_wire_format(entry)["controlzero_sdk_version"] == \
               remote._to_wire_format(entry)["controlzero_sdk_version"]
