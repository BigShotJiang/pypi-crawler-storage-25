"""Regression tests for T99 -- `controlzero install --api-key` pre-fetches
the hosted policy bundle at install time (1.5.4/1.5.5 depending on which
PR merges first).

Before T99 the installer wrote the api_key to ~/.controlzero/config.yaml
and exited. The first PreToolUse hook call did the bundle fetch, which:

* Hid auth errors (wrong api_key) until the customer ran their agent.
* Added a 1-2s cold-start spike to the first hook call.

After T99 the installer calls _prefetch_bundle(api_key) immediately
after _write_api_key_config(api_key). On success it prints the rule
count. On failure (auth, network, tamper) it prints a WARNING to stderr
and exits cleanly -- the install completes either way so the user is
not left with a half-configured machine, but they SEE the problem now.
"""

from __future__ import annotations

from unittest import mock


import controlzero.cli.main as cli_main


def test_prefetch_bundle_prints_rule_count_on_success(capsys):
    fake_parsed = {"rules": [{"id": "r1"}, {"id": "r2"}, {"id": "r3"}]}

    with mock.patch(
        "controlzero.hosted_policy.load_hosted_policy",
        return_value=("inline", fake_parsed),
    ):
        cli_main._prefetch_bundle("cz_live_abc123")

    captured = capsys.readouterr()
    assert "Pre-fetched hosted policy (3 rules)" in captured.out
    assert "WARNING" not in captured.err
    assert "WARNING" not in captured.out


def test_prefetch_bundle_singular_rule_text(capsys):
    fake_parsed = {"rules": [{"id": "only"}]}
    with mock.patch(
        "controlzero.hosted_policy.load_hosted_policy",
        return_value=("inline", fake_parsed),
    ):
        cli_main._prefetch_bundle("cz_live_abc123")
    captured = capsys.readouterr()
    assert "1 rule)" in captured.out  # not "1 rules"


def test_prefetch_bundle_handles_empty_rules_list(capsys):
    fake_parsed = {"rules": []}
    with mock.patch(
        "controlzero.hosted_policy.load_hosted_policy",
        return_value=("inline", fake_parsed),
    ):
        cli_main._prefetch_bundle("cz_live_abc123")
    captured = capsys.readouterr()
    # Zero is a legitimate (pre-attach) state -- show the count, not
    # an error. Cf. project_424_real_root_causes.md.
    assert "Pre-fetched hosted policy (0 rules)" in captured.out


def test_prefetch_bundle_warns_on_auth_failure_but_does_not_raise(capsys):
    # Common failure: customer pasted the wrong api_key. We must NOT
    # raise -- install must complete -- but we MUST surface the error
    # in stderr so they see it before their first agent run.
    with mock.patch(
        "controlzero.hosted_policy.load_hosted_policy",
        side_effect=RuntimeError("HostedAuthError: 401"),
    ):
        # No exception leaks out:
        cli_main._prefetch_bundle("cz_live_wrong")

    captured = capsys.readouterr()
    assert "WARNING: Could not pre-fetch hosted policy" in captured.err
    assert "HostedAuthError: 401" in captured.err
    assert "double-check the api_key" in captured.err


def test_prefetch_bundle_warns_on_network_failure(capsys):
    with mock.patch(
        "controlzero.hosted_policy.load_hosted_policy",
        side_effect=ConnectionError("Connection refused"),
    ):
        cli_main._prefetch_bundle("cz_live_abc123")

    captured = capsys.readouterr()
    assert "WARNING: Could not pre-fetch hosted policy" in captured.err
    assert "Connection refused" in captured.err
    # Must mention the SDK will retry so the user knows install is OK:
    assert "retry on the first tool call" in captured.err


def test_prefetch_bundle_handles_missing_rules_key_gracefully(capsys):
    # Defensive: backend may return a parsed bundle with no rules key
    # (legacy shape, malformed response). The rule_count fallback is
    # 0, no exception.
    with mock.patch(
        "controlzero.hosted_policy.load_hosted_policy",
        return_value=("inline", {"unexpected": "shape"}),
    ):
        cli_main._prefetch_bundle("cz_live_abc123")
    captured = capsys.readouterr()
    assert "Pre-fetched hosted policy (0 rules)" in captured.out


def test_install_claude_code_calls_prefetch_when_api_key_present(tmp_path, monkeypatch):
    """End-to-end: install claude-code --api-key X must call _prefetch_bundle."""
    monkeypatch.setattr(cli_main, "GLOBAL_POLICY_DIR", tmp_path / ".controlzero")
    monkeypatch.setattr(
        cli_main, "GLOBAL_POLICY_PATH", tmp_path / ".controlzero" / "policy.yaml"
    )
    monkeypatch.setattr(
        cli_main, "GLOBAL_CONFIG_PATH", tmp_path / ".controlzero" / "config.yaml"
    )
    monkeypatch.setattr(
        cli_main, "GLOBAL_AUDIT_PATH", tmp_path / ".controlzero" / "audit.log"
    )

    settings_path = tmp_path / ".claude" / "settings.json"

    fake_parsed = {"rules": [{"id": "r1"}]}
    with mock.patch(
        "controlzero.hosted_policy.load_hosted_policy",
        return_value=("inline", fake_parsed),
    ) as mocked:
        from click.testing import CliRunner

        runner = CliRunner()
        result = runner.invoke(
            cli_main.cli,
            [
                "install",
                "claude-code",
                "--api-key",
                "cz_live_testkey",
                "--settings",
                str(settings_path),
                "--force",
            ],
        )

    assert result.exit_code == 0, result.output
    mocked.assert_called_once_with("cz_live_testkey")
    assert "Pre-fetched hosted policy (1 rule)" in result.output


def test_install_without_api_key_does_NOT_prefetch(tmp_path, monkeypatch):
    """No api_key = no network call (offline install must stay offline)."""
    monkeypatch.setattr(cli_main, "GLOBAL_POLICY_DIR", tmp_path / ".controlzero")
    monkeypatch.setattr(
        cli_main, "GLOBAL_POLICY_PATH", tmp_path / ".controlzero" / "policy.yaml"
    )
    monkeypatch.setattr(
        cli_main, "GLOBAL_CONFIG_PATH", tmp_path / ".controlzero" / "config.yaml"
    )
    monkeypatch.setattr(
        cli_main, "GLOBAL_AUDIT_PATH", tmp_path / ".controlzero" / "audit.log"
    )

    settings_path = tmp_path / ".claude" / "settings.json"

    with mock.patch(
        "controlzero.hosted_policy.load_hosted_policy"
    ) as mocked:
        from click.testing import CliRunner

        runner = CliRunner()
        result = runner.invoke(
            cli_main.cli,
            [
                "install",
                "claude-code",
                "--settings",
                str(settings_path),
                "--force",
            ],
        )

    assert result.exit_code == 0, result.output
    mocked.assert_not_called()
