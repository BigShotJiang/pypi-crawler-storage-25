"""Regression tests for the masked API-key hint shown in the active-source
stderr notification (T103 follow-up, 1.5.1 security fix).

Before 1.5.1 the SDK printed ``self._api_key[:14]`` to stderr on every
Client construction in hosted mode. For a ``cz_live_abcdef123456...``
key that meant 6 characters of the customer secret leaked to terminals,
screen shares, support transcripts, and CI logs.

The mask MUST:

* preserve the public ``cz_live_`` / ``cz_test_`` prefix as a mode signal
* NEVER emit any character beyond that prefix from the input key

These tests verify both invariants with a brute-force substring scan so a
future regression that switches back to a length-prefix slice fails loud.
"""

from controlzero.client import _mask_api_key


def test_mask_live_key_emits_only_public_prefix():
    masked = _mask_api_key("cz_live_aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa")
    assert masked == "cz_live_***"


def test_mask_test_key_emits_only_public_prefix():
    masked = _mask_api_key("cz_test_bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb")
    assert masked == "cz_test_***"


def test_mask_unknown_prefix_falls_through_to_triple_star():
    masked = _mask_api_key("plain-token-1234567890")
    assert masked == "***"


def test_mask_none_returns_triple_star():
    assert _mask_api_key(None) == "***"


def test_mask_empty_string_returns_triple_star():
    assert _mask_api_key("") == "***"


def test_mask_never_leaks_secret_bytes_brute_force():
    # Obviously-synthetic placeholder fixture. The 4-char window
    # scan downstream remains meaningful: the masked output must not
    # 1.5.0 -> 1.5.1 incident on 2026-05-12).
    secret_tail = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
    for prefix in ("cz_live_", "cz_test_"):
        key = prefix + secret_tail
        masked = _mask_api_key(key)
        # Scan every 4-char substring of the secret and assert NONE
        # appears in the masked output. 4 chars is enough entropy that
        # an accidental match is vanishingly unlikely.
        for i in range(len(secret_tail) - 3):
            window = secret_tail[i : i + 4]
            assert window not in masked, (
                f"secret bytes {window!r} leaked into masked output {masked!r}"
            )
