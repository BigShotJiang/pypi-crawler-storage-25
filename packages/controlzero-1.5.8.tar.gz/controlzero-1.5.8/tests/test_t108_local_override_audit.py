"""T108 regression: LOCAL_OVERRIDE emits a governance audit event.

When a user sets CONTROLZERO_LOCAL_OVERRIDE=1 with an api_key, the SDK
bypasses the hosted bundle. T108 (2026-05-12, governance follow-up to
T103) emits a one-shot audit event so ops sees the bypass in the audit
dashboard and can alert on reason_code=LOCAL_OVERRIDE_ACTIVE.
"""

from __future__ import annotations

from unittest.mock import MagicMock, patch


from controlzero import Client
from controlzero._internal.enforcer import REASON_CODE_LOCAL_OVERRIDE_ACTIVE


def _make_fake_bearer_sink():
    """Return a stand-in BearerAuditSink that records every .log() call."""
    sink = MagicMock()
    sink.logged = []

    def _record(entry):
        sink.logged.append(entry)

    sink.log.side_effect = _record
    sink.close = MagicMock()
    return sink


def test_local_override_emits_audit_event(monkeypatch, tmp_path):
    """LOCAL_OVERRIDE=1 + api_key + cwd policy => emits the event."""
    pol = tmp_path / "controlzero.yaml"
    pol.write_text(
        "version: '1'\nrules:\n  - allow: '*'\n",
        encoding="utf-8",
    )
    monkeypatch.chdir(tmp_path)
    monkeypatch.setenv("CONTROLZERO_API_KEY", "cz_live_t108_test")
    monkeypatch.setenv("CONTROLZERO_LOCAL_OVERRIDE", "1")

    fake_sink = _make_fake_bearer_sink()
    with patch(
        "controlzero.audit_remote.BearerAuditSink", return_value=fake_sink
    ):
        cz = Client(log_path=str(tmp_path / "cz.log"))

    assert any(
        e.get("reason_code") == REASON_CODE_LOCAL_OVERRIDE_ACTIVE
        for e in fake_sink.logged
    ), f"expected LOCAL_OVERRIDE_ACTIVE event, got: {fake_sink.logged}"

    # Event shape: synthetic policy_id, decision=audit, mode=lifecycle.
    ev = next(
        e
        for e in fake_sink.logged
        if e.get("reason_code") == REASON_CODE_LOCAL_OVERRIDE_ACTIVE
    )
    assert ev["decision"] == "audit"
    assert ev["policy_id"] == "<lifecycle>"
    assert ev["mode"] == "lifecycle"
    assert "CONTROLZERO_LOCAL_OVERRIDE" in ev["reason"]
    # Source hint names the file we ended up loading.
    assert "controlzero.yaml" in ev["reason"]
    cz.close()


def test_no_override_no_event(monkeypatch, tmp_path):
    """api_key alone (no LOCAL_OVERRIDE) => no override audit event."""
    monkeypatch.setenv("CONTROLZERO_API_KEY", "cz_live_t108_test")
    monkeypatch.delenv("CONTROLZERO_LOCAL_OVERRIDE", raising=False)

    fake_sink = _make_fake_bearer_sink()
    fake_parsed = MagicMock()
    with patch(
        "controlzero.audit_remote.BearerAuditSink", return_value=fake_sink
    ), patch(
        "controlzero.hosted_policy.load_hosted_policy",
        return_value=(
            {"version": "1", "rules": [{"allow": "*"}]},
            fake_parsed,
        ),
    ), patch(
        "controlzero.hosted_policy.load_cached_bundle", return_value=None
    ):
        cz = Client(log_path=str(tmp_path / "cz.log"))

    override_events = [
        e
        for e in fake_sink.logged
        if e.get("reason_code") == REASON_CODE_LOCAL_OVERRIDE_ACTIVE
    ]
    assert override_events == [], f"unexpected override event: {override_events}"
    cz.close()


def test_caller_explicit_local_does_not_emit_override(monkeypatch, tmp_path):
    """Caller-supplied policy with api_key emits the hybrid warning, NOT
    the LOCAL_OVERRIDE event. The two cases are semantically distinct:
    caller-explicit is "I know what I'm doing", LOCAL_OVERRIDE is "use
    the local-fallback escape hatch".
    """
    monkeypatch.setenv("CONTROLZERO_API_KEY", "cz_live_t108_test")
    monkeypatch.delenv("CONTROLZERO_LOCAL_OVERRIDE", raising=False)

    fake_sink = _make_fake_bearer_sink()
    with patch(
        "controlzero.audit_remote.BearerAuditSink", return_value=fake_sink
    ):
        cz = Client(policy={"rules": [{"allow": "*"}]})

    override_events = [
        e
        for e in fake_sink.logged
        if e.get("reason_code") == REASON_CODE_LOCAL_OVERRIDE_ACTIVE
    ]
    assert override_events == []
    cz.close()


def test_local_override_without_api_key_does_not_emit(monkeypatch, tmp_path):
    """LOCAL_OVERRIDE=1 but no api_key is just local mode. No remote
    audit sink, no governance event needed.
    """
    pol = tmp_path / "controlzero.yaml"
    pol.write_text("rules:\n  - allow: '*'\n", encoding="utf-8")
    monkeypatch.chdir(tmp_path)
    monkeypatch.delenv("CONTROLZERO_API_KEY", raising=False)
    monkeypatch.setenv("CONTROLZERO_LOCAL_OVERRIDE", "1")

    fake_sink = _make_fake_bearer_sink()
    with patch(
        "controlzero.audit_remote.BearerAuditSink", return_value=fake_sink
    ):
        cz = Client(log_path=str(tmp_path / "cz.log"))

    # No bearer sink got constructed (no api_key).
    assert fake_sink.log.call_count == 0
    cz.close()


def test_audit_event_carries_reason_code_in_wire_format(monkeypatch, tmp_path):
    """Wire envelope from BearerAuditSink._to_wire_format must include
    the reason_code. Without this the backend audit_logs.reason_code
    column stays empty and ops cannot filter on LOCAL_OVERRIDE_ACTIVE.
    """
    from controlzero.audit_remote import BearerAuditSink

    sink = BearerAuditSink(api_url="http://127.0.0.1:1", api_key="cz_test_fake")
    wire = sink._to_wire_format(
        {
            "tool": "_lifecycle",
            "decision": "audit",
            "reason_code": REASON_CODE_LOCAL_OVERRIDE_ACTIVE,
            "reason": "bypass",
            "policy_id": "<lifecycle>",
        }
    )
    assert wire["reason_code"] == REASON_CODE_LOCAL_OVERRIDE_ACTIVE
    assert wire["decision"] == "audit"
    assert wire["policy_id"] == "<lifecycle>"
    sink.close()
