"""The new `controlzero` package imports cleanly. (Shim test for the rename.)

The deprecated `control-zero` package's stub is tested separately because it
lives in a different directory and depends on `controlzero` being installed.
"""


def test_top_level_imports():
    from controlzero import (
        Client,
        __version__,
    )
    assert callable(Client)
    # Version comes from package metadata, not hardcoded in the test
    # (hardcoding drifts every time we bump the version).
    assert isinstance(__version__, str) and len(__version__) > 0


def test_client_class_is_documented():
    from controlzero import Client
    assert Client.__doc__ is not None
    assert "Hello World" in Client.__doc__


def test_hello_world_works_end_to_end(tmp_path):
    """The literal Hello World from the README must work."""
    from controlzero import Client

    cz = Client(
        policy={
            "rules": [
                {"deny":  "delete_*", "reason": "Hello World: deletes are blocked"},
                {"allow": "*",        "reason": "Hello World: everything else is fine"},
            ]
        },
        log_path=str(tmp_path / "test.log"),
    )

    assert cz.guard("delete_file", {"path": "/tmp/foo"}).decision == "deny"
    assert cz.guard("read_file",   {"path": "/tmp/foo"}).decision == "allow"
    cz.close()
