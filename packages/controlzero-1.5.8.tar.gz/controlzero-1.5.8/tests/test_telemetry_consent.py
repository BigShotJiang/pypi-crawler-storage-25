"""Unit tests for controlzero.cli.telemetry_consent."""

from __future__ import annotations

import os
from pathlib import Path
from unittest import mock

import pytest
import yaml

from controlzero.cli import telemetry_consent as tc


@pytest.fixture
def fake_home(tmp_path: Path):
    with mock.patch("controlzero.cli.telemetry_consent._TELEMETRY_PATH",
                    tmp_path / ".controlzero" / "telemetry.yaml"):
        yield tmp_path


class TestGetMode:
    def test_default_is_unset_on_first_run(self, fake_home: Path) -> None:
        assert tc.get_mode() == "unset"

    def test_env_var_overrides_persisted(self, fake_home: Path) -> None:
        tc.set_mode("full")
        with mock.patch.dict(os.environ, {"CONTROLZERO_TELEMETRY": "off"}):
            assert tc.get_mode() == "off"

    def test_env_var_off_synonyms(self, fake_home: Path) -> None:
        for val in ("off", "false", "no", "0", "disabled"):
            with mock.patch.dict(os.environ, {"CONTROLZERO_TELEMETRY": val}):
                assert tc.get_mode() == "off"

    def test_corrupt_file_falls_back_to_unset(self, fake_home: Path) -> None:
        tc._TELEMETRY_PATH.parent.mkdir(parents=True, exist_ok=True)
        tc._TELEMETRY_PATH.write_text(": : not yaml")
        assert tc.get_mode() == "unset"


class TestSetMode:
    def test_persists_to_disk(self, fake_home: Path) -> None:
        tc.set_mode("full")
        loaded = yaml.safe_load(tc._TELEMETRY_PATH.read_text())
        assert loaded["mode"] == "full"

    def test_wipes_device_id_when_leaving_full(self, fake_home: Path) -> None:
        tc.set_mode("full")
        tc.get_device_id()  # triggers device_id creation
        tc.set_mode("off")
        loaded = yaml.safe_load(tc._TELEMETRY_PATH.read_text())
        assert "device_id" not in loaded


class TestGetDeviceId:
    def test_returns_none_when_not_full(self, fake_home: Path) -> None:
        tc.set_mode("anonymous")
        assert tc.get_device_id() is None

    def test_returns_stable_id_when_full(self, fake_home: Path) -> None:
        tc.set_mode("full")
        did1 = tc.get_device_id()
        did2 = tc.get_device_id()
        assert did1 == did2
        assert did1.startswith("cz_dev_")


class TestPromptIfUnset:
    def test_non_interactive_returns_unset_silently(self, fake_home: Path) -> None:
        # No tty -> don't prompt, don't enable.
        with mock.patch("sys.stdin.isatty", return_value=False), \
             mock.patch("sys.stdout.isatty", return_value=False):
            assert tc.prompt_if_unset() == "unset"

    def test_already_set_returns_existing_without_prompting(self, fake_home: Path) -> None:
        tc.set_mode("off")
        # Even on a tty, an already-set mode short-circuits.
        with mock.patch("sys.stdin.isatty", return_value=True), \
             mock.patch("sys.stdout.isatty", return_value=True):
            assert tc.prompt_if_unset() == "off"


class TestPermissions:
    @pytest.mark.skipif(os.name == "nt", reason="POSIX perms only")
    def test_telemetry_yaml_is_0600(self, fake_home: Path) -> None:
        tc.set_mode("anonymous")
        import stat
        mode = stat.S_IMODE(tc._TELEMETRY_PATH.stat().st_mode)
        assert mode == 0o600
