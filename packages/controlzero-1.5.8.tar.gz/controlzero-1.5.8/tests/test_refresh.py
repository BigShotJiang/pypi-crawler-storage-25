"""Tests for hosted-policy periodic refresh.

Covers Bug #1 from the 2026-04-19 investigation: before this
change, :class:`Client._evaluator` was loaded exactly once in
``__init__`` and held for the life of the process. Updates made on the
dashboard never reached a long-running SDK client until it restarted.

The implementation uses a monotonic-clock TTL and a
:class:`threading.Lock` around the evaluator swap. These tests exercise:

- default 60-second TTL behavior
- ``refresh_interval_seconds=None`` disables the periodic refresh
- ``refresh_interval_seconds=0`` refreshes on every guard (tests only)
- network errors during refresh keep the old bundle + log WARN
- ``cz.refresh()`` returns True on bundle change, False on no change
- ETag 304 path (no swap, but timer bumped)
- thread safety: many concurrent guards + a refresh, no deadlock,
  no torn reads
"""

from __future__ import annotations

import base64
import json
import logging
import os
import struct
import threading
import time
from http.server import BaseHTTPRequestHandler, HTTPServer

import pytest


# ---- mock backend (reused from test_hosted_policy_e2e) ----------------------


def _build_bundle_bytes(payload_dict: dict, enc_key: bytes, priv) -> bytes:
    """Build a valid signed+encrypted bundle with the given payload."""
    import zstandard as zstd
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM

    payload_json = json.dumps(payload_dict).encode("utf-8")
    compressed = zstd.ZstdCompressor().compress(payload_json)
    nonce = os.urandom(12)
    encrypted = nonce + AESGCM(enc_key).encrypt(nonce, compressed, None)

    sig_offset = 32 + len(encrypted)
    header = (
        b"CZ01"
        + struct.pack("<HQHII", 1, 1700000000, 1, sig_offset, 64)
        + b"\x00" * 8
    )
    data_to_sign = header + encrypted
    signature = priv.sign(data_to_sign)
    return data_to_sign + signature


class _MockBackend:
    """Swappable, thread-safe mock of the SDK-pull endpoint.

    Tests mutate ``current_payload`` (via :meth:`set_payload`) to model a
    dashboard edit, then call ``guard()`` or ``refresh()`` to observe the
    SDK's behavior.
    """

    def __init__(self):
        from cryptography.hazmat.primitives.asymmetric.ed25519 import (
            Ed25519PrivateKey,
        )

        self._priv = Ed25519PrivateKey.generate()
        self._pub = self._priv.public_key().public_bytes_raw()
        self._enc_key = os.urandom(32)

        self._lock = threading.Lock()
        self._payload = self._make_payload([
            {"effect": "allow", "tool": "*"},
        ])
        self._bundle = _build_bundle_bytes(self._payload, self._enc_key, self._priv)

        self.pull_count = 0
        self.not_modified_count = 0
        self.force_error = False
        self.force_error_after = None  # int or None

    @staticmethod
    def _make_payload(rules: list) -> dict:
        return {
            "schema_version": "1.0",
            "bundle_id": "v1",
            "project_id": "test-project",
            "policies": [
                {"id": "p1", "name": "Demo", "priority": 10, "rules": rules}
            ],
        }

    def set_payload(self, rules: list) -> None:
        """Swap the served policy. Next non-304 pull picks it up."""
        with self._lock:
            self._payload = self._make_payload(rules)
            self._bundle = _build_bundle_bytes(
                self._payload, self._enc_key, self._priv
            )

    # ---------- introspection helpers ----------

    @property
    def enc_key(self) -> bytes:
        return self._enc_key

    @property
    def pub_key(self) -> bytes:
        return self._pub

    @property
    def bundle_bytes(self) -> bytes:
        with self._lock:
            return self._bundle


@pytest.fixture
def mock_backend(tmp_path, monkeypatch):
    backend = _MockBackend()

    bootstrap_resp = {
        "project_id": "test-project",
        "org_id": "test-org",
        "project_encryption_key_b64": base64.b64encode(backend.enc_key).decode("ascii"),
        "signing_pubkey_hex": backend.pub_key.hex(),
        "signing_pubkey_pem": "",
        "key_version": 1,
        "algorithm": "ed25519",
    }

    # ETag is the sha256 of the bundle bytes (mirrors the SDK's
    # _compute_etag fallback). Recompute on every pull so rotations
    # invalidate the client's cached ETag.
    import hashlib

    def current_etag() -> str:
        # Match the SDK's _compute_etag (full 64-char hex). The earlier
        # [:32] truncation here mirrored the bug in hosted_policy.py
        # that PR #374 fixed; keeping the truncation here would make
        # the mock backend's ETag perpetually mismatch the SDK's
        # If-None-Match and the 304 short-circuit would never fire.
        return hashlib.sha256(backend.bundle_bytes).hexdigest()

    class Handler(BaseHTTPRequestHandler):
        def _bearer_ok(self):
            auth = self.headers.get("Authorization", "")
            if not auth.startswith("Bearer cz_"):
                self.send_response(401)
                self.end_headers()
                return False
            return True

        def do_GET(self):
            if not self._bearer_ok():
                return
            # Error injection for "network failure" tests.
            if backend.force_error:
                self.send_response(500)
                self.end_headers()
                return
            if backend.force_error_after is not None and backend.pull_count >= backend.force_error_after:
                self.send_response(500)
                self.end_headers()
                return

            if self.path == "/v1/sdk/bootstrap":
                body = json.dumps(bootstrap_resp).encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
                return
            if self.path == "/v1/sdk/policies/pull":
                etag = current_etag()
                inm = self.headers.get("If-None-Match", "")
                if inm and inm == etag:
                    backend.not_modified_count += 1
                    self.send_response(304)
                    self.end_headers()
                    return
                backend.pull_count += 1
                blob = backend.bundle_bytes
                self.send_response(200)
                self.send_header("Content-Type", "application/octet-stream")
                self.send_header("ETag", etag)
                self.send_header("Content-Length", str(len(blob)))
                self.end_headers()
                self.wfile.write(blob)
                return
            self.send_response(404)
            self.end_headers()

        def do_POST(self):
            # Audit + tamper endpoints silently accept.
            length = int(self.headers.get("Content-Length", "0"))
            _ = self.rfile.read(length) if length else b""
            body = b'{"accepted": 0, "dropped": 0}'
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def log_message(self, *a, **kw):
            pass

    server = HTTPServer(("127.0.0.1", 0), Handler)
    port = server.server_address[1]
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()

    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setenv("CONTROLZERO_API_URL", f"http://127.0.0.1:{port}")

    yield backend

    server.shutdown()


# ---- tests -----------------------------------------------------------------


def test_refresh_default_interval_applied(mock_backend):
    """Default refresh_interval_seconds is 60s."""
    from controlzero import Client

    client = Client(api_key="cz_live_test_default")
    try:
        assert client._refresh_interval == 60.0
        assert client._refresh_enabled is True
    finally:
        client.close()


def test_refresh_disabled_when_none(mock_backend):
    """Passing None disables auto-refresh entirely."""
    from controlzero import Client

    client = Client(api_key="cz_live_test_none", refresh_interval_seconds=None)
    try:
        assert client._refresh_interval is None
        assert client._refresh_enabled is False
        # Guard calls should not trigger a refresh.
        pulls_before = mock_backend.pull_count
        not_mod_before = mock_backend.not_modified_count
        for _ in range(5):
            client.guard("web_search", args={"q": "test"})
        assert mock_backend.pull_count == pulls_before
        assert mock_backend.not_modified_count == not_mod_before
    finally:
        client.close()


def test_refresh_every_guard_when_zero(mock_backend):
    """refresh_interval_seconds=0 refreshes on every guard call."""
    from controlzero import Client

    # Use force=0, TTL=0 seconds means "any elapsed time >= 0 triggers refresh".
    client = Client(api_key="cz_live_test_zero", refresh_interval_seconds=0)
    try:
        # First guard: TTL already expired (0 >= 0) -> refresh fires.
        # Bundle unchanged -> 304.
        for _ in range(3):
            client.guard("web_search", args={})
        assert mock_backend.not_modified_count >= 3
    finally:
        client.close()


def test_refresh_picks_up_dashboard_change(mock_backend):
    """The client sees an updated bundle once the TTL elapses."""
    from controlzero import Client

    client = Client(api_key="cz_live_test_pickup", refresh_interval_seconds=0)
    try:
        # Original bundle: allow *
        d1 = client.guard("send_email", args={})
        assert d1.effect == "allow"

        # Simulate a dashboard update: now deny send_email.
        mock_backend.set_payload([
            {"effect": "deny", "tool": "send_email", "reason": "blocked"},
            {"effect": "allow", "tool": "*"},
        ])

        # Next guard should trigger a refresh (TTL=0) and pick up deny.
        d2 = client.guard("send_email", args={})
        assert d2.effect == "deny"
    finally:
        client.close()


def test_refresh_method_unconditional(mock_backend):
    """Client.refresh() is unconditional and returns True on change."""
    from controlzero import Client

    # TTL=None means auto-refresh off, but cz.refresh() should still work.
    client = Client(api_key="cz_live_test_manual", refresh_interval_seconds=None)
    try:
        # No-op initially: bundle hasn't changed.
        changed = client.refresh()
        assert changed is False

        # Update the dashboard, then force a refresh.
        mock_backend.set_payload([
            {"effect": "deny", "tool": "send_email"},
            {"effect": "allow", "tool": "*"},
        ])
        changed = client.refresh()
        assert changed is True

        # New bundle is in effect even though auto-refresh is off.
        assert client.guard("send_email", args={}).effect == "deny"
    finally:
        client.close()


def test_refresh_returns_false_in_local_mode(tmp_path):
    """In local mode (no API key) refresh() is a no-op returning False."""
    from controlzero import Client

    client = Client(policy={"rules": [{"allow": "*"}]}, log_path=str(tmp_path / "a.log"))
    try:
        assert client.refresh() is False
    finally:
        client.close()


def test_refresh_network_error_keeps_old_bundle(mock_backend, caplog, tmp_path, monkeypatch):
    """Transient errors keep the old bundle; the SDK never raises.

    Two layers of defense protect the caller:

    1. ``hosted_policy.load_hosted_policy`` falls back to the on-disk cache
       on network error (logs a WARN from ``controlzero.hosted_policy``).
    2. If even the cache is missing, the refresh path in ``client.py``
       swallows the resulting ``HostedBootstrapError`` (logs a WARN from
       ``controlzero.client.refresh``).

    Either way, the caller must see ``allow`` from the old evaluator.
    """
    from controlzero import Client

    client = Client(api_key="cz_live_test_err", refresh_interval_seconds=0)
    try:
        # Original bundle allows everything.
        assert client.guard("send_email", args={}).effect == "allow"

        # Break the backend. Refresh will hit the error.
        mock_backend.force_error = True

        with caplog.at_level(logging.WARNING):
            d = client.guard("send_email", args={})

        assert d.effect == "allow", "old bundle must survive refresh failure"

        # Confirm a WARN was emitted somewhere along the refresh stack.
        warn_messages = [r.getMessage().lower() for r in caplog.records if r.levelno >= logging.WARNING]
        assert any(
            "policy refresh" in m
            or "policy pull failed" in m
            or "using cached bundle" in m
            for m in warn_messages
        ), f"expected a WARN log about refresh/pull failure, got: {warn_messages}"
    finally:
        client.close()


def test_refresh_network_error_no_cache_still_keeps_old_bundle(tmp_path, monkeypatch, caplog):
    """Refresh failure with no on-disk cache must still keep the in-memory bundle.

    Sets up a Client successfully, wipes the on-disk cache, breaks the
    backend, and asserts that subsequent guards still use the original
    in-memory evaluator.
    """
    import shutil
    from controlzero import Client

    backend = _MockBackend()
    bootstrap_resp = {
        "project_id": "test-project",
        "org_id": "test-org",
        "project_encryption_key_b64": base64.b64encode(backend.enc_key).decode("ascii"),
        "signing_pubkey_hex": backend.pub_key.hex(),
        "signing_pubkey_pem": "",
        "key_version": 1,
        "algorithm": "ed25519",
    }

    class _ErrAfterFirstHandler(BaseHTTPRequestHandler):
        first_pull_done = False

        def _bearer_ok(self):
            auth = self.headers.get("Authorization", "")
            if not auth.startswith("Bearer cz_"):
                self.send_response(401)
                self.end_headers()
                return False
            return True

        def do_GET(self):
            if not self._bearer_ok():
                return
            if backend.force_error:
                self.send_response(500)
                self.end_headers()
                return
            if self.path == "/v1/sdk/bootstrap":
                body = json.dumps(bootstrap_resp).encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
                return
            if self.path == "/v1/sdk/policies/pull":
                blob = backend.bundle_bytes
                self.send_response(200)
                self.send_header("Content-Type", "application/octet-stream")
                self.send_header("Content-Length", str(len(blob)))
                self.end_headers()
                self.wfile.write(blob)
                return
            self.send_response(404)
            self.end_headers()

        def do_POST(self):
            length = int(self.headers.get("Content-Length", "0"))
            _ = self.rfile.read(length) if length else b""
            body = b'{"accepted": 0, "dropped": 0}'
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def log_message(self, *a, **kw): pass

    server = HTTPServer(("127.0.0.1", 0), _ErrAfterFirstHandler)
    port = server.server_address[1]
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()

    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setenv("CONTROLZERO_API_URL", f"http://127.0.0.1:{port}")

    try:
        client = Client(api_key="cz_live_test_nocache", refresh_interval_seconds=0)
        try:
            assert client.guard("send_email", args={}).effect == "allow"

            # Wipe the on-disk cache so the next refresh cannot fall
            # back to it. Then break the backend.
            cache_dir = tmp_path / ".controlzero" / "cache"
            if cache_dir.exists():
                shutil.rmtree(cache_dir)
            backend.force_error = True

            with caplog.at_level(logging.WARNING, logger="controlzero.client.refresh"):
                d = client.guard("send_email", args={})

            # Old in-memory evaluator survives the refresh failure.
            assert d.effect == "allow"
            # Client's own refresh logger should have fired since the
            # hosted_policy module raised past the cache fallback.
            warn_msgs = [r.getMessage().lower() for r in caplog.records]
            assert any("policy refresh failed" in m for m in warn_msgs), (
                f"expected WARN from client.refresh, got: {warn_msgs}"
            )
        finally:
            client.close()
    finally:
        server.shutdown()


def test_refresh_etag_304_no_swap(mock_backend):
    """On 304, timer bumps but evaluator is unchanged."""
    from controlzero import Client

    client = Client(api_key="cz_live_test_304", refresh_interval_seconds=0)
    try:
        # First guard forces at least one pull (or 304 if already cached).

        # Second guard, same bundle -> pure 304. Backend should see
        # If-None-Match match and never re-serve the body.
        client.guard("web_search", args={})
        client.guard("web_search", args={})

        # Evaluator object may or may not be swapped (initial construction
        # happens in __init__ before the refresh loop). What MUST be true:
        # backend sees the conditional-GET roundtrips.
        assert mock_backend.not_modified_count >= 1
    finally:
        client.close()


def test_refresh_thread_safety_many_concurrent_guards(mock_backend):
    """Many threads hitting guard() + refresh() must not deadlock or crash.

    Also asserts no torn reads: every guard decision is well-formed.
    """
    from controlzero import Client

    client = Client(api_key="cz_live_test_threads", refresh_interval_seconds=0)
    try:
        errors: list[BaseException] = []
        decisions: list[str] = []
        decisions_lock = threading.Lock()

        def worker():
            try:
                for _ in range(5):
                    dec = client.guard("web_search", args={"q": "x"})
                    with decisions_lock:
                        decisions.append(dec.effect)
            except BaseException as e:  # noqa: BLE001
                errors.append(e)

        def refresher():
            try:
                for _ in range(5):
                    client.refresh()
                    time.sleep(0.005)
            except BaseException as e:  # noqa: BLE001
                errors.append(e)

        threads = [threading.Thread(target=worker) for _ in range(10)]
        threads.append(threading.Thread(target=refresher))
        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=10)
            assert not t.is_alive(), "thread hung -- possible deadlock"

        assert not errors, f"worker raised: {errors!r}"
        # All decisions are from a well-defined set.
        assert decisions, "no decisions recorded"
        assert set(decisions).issubset({"allow", "deny", "warn"}), (
            f"unexpected decision effects: {set(decisions)}"
        )
    finally:
        client.close()


def test_refresh_last_refreshed_at_updates(mock_backend):
    """The wall-clock last_refreshed_at advances on a successful refresh."""
    from controlzero import Client

    client = Client(api_key="cz_live_test_wallclock", refresh_interval_seconds=None)
    try:
        t0 = client.last_refreshed_at
        # Force a refresh by mutating the dashboard.
        mock_backend.set_payload([
            {"effect": "deny", "tool": "send_email"},
            {"effect": "allow", "tool": "*"},
        ])
        client.refresh()
        t1 = client.last_refreshed_at
        assert t1 >= t0
    finally:
        client.close()
