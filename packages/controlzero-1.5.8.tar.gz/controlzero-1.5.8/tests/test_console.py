"""Smoke tests for controlzero.cli.console.

The Rich console is mostly tested by visual inspection, but the helper
functions need to at least not raise + emit the right text content.
"""

from __future__ import annotations

import io

from rich.console import Console

from controlzero.cli import console as cz


def _capture() -> tuple[Console, io.StringIO]:
    """Build a console that writes to a StringIO so we can assert on
    the rendered text."""
    buf = io.StringIO()
    return Console(file=buf, force_terminal=False, theme=cz._CZ_THEME), buf


class TestHelpers:
    def test_success_emits_ok_prefix(self, monkeypatch) -> None:
        c, buf = _capture()
        monkeypatch.setattr(cz, "_stdout", c)
        cz.success("policy installed")
        out = buf.getvalue()
        assert "[OK]" in out
        assert "policy installed" in out

    def test_warn_emits_warn_prefix(self, monkeypatch) -> None:
        c, buf = _capture()
        monkeypatch.setattr(cz, "_stderr", c)
        cz.warn("approaching limit")
        out = buf.getvalue()
        assert "[WARN]" in out
        assert "approaching limit" in out

    def test_error_emits_error_prefix(self, monkeypatch) -> None:
        c, buf = _capture()
        monkeypatch.setattr(cz, "_stderr", c)
        cz.error("blocked")
        assert "[ERROR]" in buf.getvalue()

    def test_error_with_code_prepends_code(self, monkeypatch) -> None:
        c, buf = _capture()
        monkeypatch.setattr(cz, "_stderr", c)
        cz.error("api key leaked", code="E1001")
        out = buf.getvalue()
        assert "E1001" in out
        assert "api key leaked" in out

    def test_info_emits_plain_text(self, monkeypatch) -> None:
        c, buf = _capture()
        monkeypatch.setattr(cz, "_stdout", c)
        cz.info("hint: try --dry-run first")
        assert "hint: try --dry-run first" in buf.getvalue()

    def test_heading_emits_message(self, monkeypatch) -> None:
        c, buf = _capture()
        monkeypatch.setattr(cz, "_stdout", c)
        cz.heading("Doctor report")
        assert "Doctor report" in buf.getvalue()

    def test_panel_renders_content(self, monkeypatch) -> None:
        c, buf = _capture()
        monkeypatch.setattr(cz, "_stdout", c)
        cz.panel("inside the box", title="Consent")
        out = buf.getvalue()
        assert "inside the box" in out
        assert "Consent" in out


class TestTheme:
    def test_palette_uses_design_tokens(self) -> None:
        # The palette must use the exact DESIGN.md sage-green hex.
        # If a designer changes the token, this fails loudly so we
        # remember to update both places.
        accent_style = cz._CZ_THEME.styles["cz.accent"]
        assert "#22c55e" in accent_style.color.name.lower() or \
               accent_style.color.triplet == (0x22, 0xc5, 0x5e)

    def test_error_token_is_red(self) -> None:
        err_style = cz._CZ_THEME.styles["cz.error"]
        assert "#ef4444" in err_style.color.name.lower() or \
               err_style.color.triplet == (0xef, 0x44, 0x44)
