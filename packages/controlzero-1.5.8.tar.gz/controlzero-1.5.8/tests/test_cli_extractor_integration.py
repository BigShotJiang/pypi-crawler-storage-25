"""Hook-check CLI integration: verify the extractor pipes through.

Phase 3 of issue #228. These tests feed realistic Gemini / Claude Code /
Codex PreToolUse payloads through the ``controlzero hook-check`` CLI
and assert that the canonical ``(tool, method)`` action the extractor
produced is the action the policy evaluator matched against.

The flagship case is the customer scenario: a policy that denies
``database:DROP`` should not fire on
``{tool: "database", args: {sql: "SELECT * FROM users"}}`` because the
extractor resolves the action to ``database:SELECT``. Before this
change the hook collapsed to ``database:*`` and either over- or
under-enforced. We also cover the SQL-injection piggyback class:
``SELECT 1; DROP TABLE users`` must resolve to ``database:DROP`` and
miss an allow-SELECT rule.
"""

from __future__ import annotations

import json
from pathlib import Path

import yaml
from click.testing import CliRunner

from controlzero.cli.main import cli


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _write_policy(tmp_path: Path, rules: list, default_action: str = "allow") -> Path:
    """Write a minimal policy.yaml. Returns its path.

    ``default_action`` defaults to ``allow`` because most of these
    tests want to isolate whether the extractor produced the expected
    action; a deny-default would mask the extractor behind a broad
    deny.
    """
    p = tmp_path / "policy.yaml"
    p.write_text(
        yaml.safe_dump(
            {
                "version": "1",
                "settings": {"default_action": default_action},
                "rules": rules,
            }
        )
    )
    return p


def _invoke(policy_path: Path, payload: dict) -> tuple[int, dict, str]:
    """Run hook-check and return (exit_code, decision_json, raw_output).

    The CLI runner mixes stderr into output by default; the decision
    JSON is the line(s) starting with ``{``.
    """
    runner = CliRunner()
    result = runner.invoke(
        cli,
        ["hook-check", "--policy", str(policy_path)],
        input=json.dumps(payload),
    )
    decision = {}
    for line in result.output.strip().splitlines():
        line = line.strip()
        if line.startswith("{"):
            try:
                decision = json.loads(line)
                break
            except json.JSONDecodeError:
                continue
    return result.exit_code, decision, result.output


# ---------------------------------------------------------------------------
# the customer scenario and its evil twin (#228 phase 3 flagship).
# ---------------------------------------------------------------------------


def test_customer_scenario_database_select_resolves_to_database_colon_select(
    tmp_path: Path,
):
    """SELECT payload emits action=database:SELECT (not database:*)."""
    policy = _write_policy(tmp_path, [{"allow": "*"}])
    payload = {
        "tool_name": "database",
        "tool_input": {"sql": "SELECT * FROM users"},
    }
    code, decision, _ = _invoke(policy, payload)
    assert code == 0
    # 1.5.3 adapter base: payload has no Claude Code signature ->
    # UnknownHostAdapter -> omits `decision` on allow (universal-
    # proceed). The meaningful contract is exit_code == 0 plus the
    # tool/extractor/action metadata pinned below.
    assert decision.get("decision") in (None, "approve", "allow"), (
        f"unexpected decision: {decision.get('decision')!r}"
    )
    assert decision.get("tool") == "database"
    assert decision.get("extracted_method") == "SELECT"
    assert decision.get("action") == "database:SELECT"


def test_database_drop_is_blocked_by_deny_database_drop_rule(tmp_path: Path):
    """deny database:DROP on a DROP payload -> block."""
    policy = _write_policy(
        tmp_path,
        [
            {"deny": "database:DROP", "reason": "destructive SQL"},
            {"allow": "*"},
        ],
    )
    payload = {
        "tool_name": "database",
        "tool_input": {"sql": "DROP TABLE users"},
    }
    code, decision, _ = _invoke(policy, payload)
    assert code == 2
    assert decision.get("decision") == "block"
    assert decision.get("extracted_method") == "DROP"
    assert decision.get("action") == "database:DROP"


def test_database_select_does_not_match_deny_database_drop(tmp_path: Path):
    """deny database:DROP on a SELECT payload -> allow (pre-fix regression)."""
    policy = _write_policy(
        tmp_path,
        [
            {"deny": "database:DROP", "reason": "destructive SQL"},
            {"allow": "*"},
        ],
    )
    payload = {
        "tool_name": "database",
        "tool_input": {"sql": "SELECT * FROM users"},
    }
    code, decision, _ = _invoke(policy, payload)
    assert code == 0
    # 1.5.3 adapter base: payload has no Claude Code signature ->
    # UnknownHostAdapter -> omits `decision` on allow (universal-
    # proceed). The meaningful contract is exit_code == 0 plus the
    # tool/extractor/action metadata pinned below.
    assert decision.get("decision") in (None, "approve", "allow"), (
        f"unexpected decision: {decision.get('decision')!r}"
    )
    assert decision.get("extracted_method") == "SELECT"


def test_piggyback_select_drop_resolves_to_drop_and_blocks(tmp_path: Path):
    """SQL injection: SELECT ... ; DROP ... must resolve to DROP."""
    policy = _write_policy(
        tmp_path,
        [
            {"deny": "database:DROP", "reason": "destructive SQL"},
            {"allow": "*"},
        ],
    )
    payload = {
        "tool_name": "database",
        "tool_input": {"sql": "SELECT * FROM t; DROP TABLE users;"},
    }
    code, decision, _ = _invoke(policy, payload)
    assert code == 2
    assert decision.get("decision") == "block"
    assert decision.get("extracted_method") == "DROP"
    assert decision.get("action") == "database:DROP"


# ---------------------------------------------------------------------------
# Gemini / Claude / Codex payload shapes.
# ---------------------------------------------------------------------------


def test_claude_code_bash_rm_resolves_to_bash_rm(tmp_path: Path):
    """Claude Code Bash payload with destructive rm -> action=Bash:rm."""
    policy = _write_policy(
        tmp_path,
        [
            {"deny": "Bash:rm", "reason": "destructive filesystem"},
            {"allow": "*"},
        ],
    )
    payload = {
        "tool_name": "Bash",
        "tool_input": {"command": "rm -rf /tmp/foo"},
    }
    code, decision, _ = _invoke(policy, payload)
    assert code == 2
    assert decision.get("extracted_method") == "rm"
    assert decision.get("action") == "Bash:rm"


def test_gemini_run_shell_command_alias_resolves_to_bash(tmp_path: Path):
    """Gemini's run_shell_command alias maps to canonical Bash."""
    policy = _write_policy(tmp_path, [{"allow": "*"}])
    payload = {
        "tool_name": "run_shell_command",
        "tool_input": {"command": "ls -la"},
    }
    code, decision, _ = _invoke(policy, payload)
    assert code == 0
    assert decision.get("tool") == "Bash"
    assert decision.get("extracted_method") == "ls"
    assert decision.get("action") == "Bash:ls"


def test_bash_sudo_outranks_rm(tmp_path: Path):
    """sudo rm -rf -> action=Bash:sudo so a deny-sudo rule catches it."""
    policy = _write_policy(
        tmp_path,
        [
            {"deny": "Bash:sudo", "reason": "privilege escalation"},
            {"allow": "*"},
        ],
    )
    payload = {
        "tool_name": "Bash",
        "tool_input": {"command": "sudo rm -rf /"},
    }
    code, decision, _ = _invoke(policy, payload)
    assert code == 2
    assert decision.get("extracted_method") == "sudo"
    assert decision.get("action") == "Bash:sudo"


def test_bash_compound_echo_and_rm_resolves_to_rm(tmp_path: Path):
    policy = _write_policy(
        tmp_path,
        [
            {"deny": "Bash:rm", "reason": "destructive"},
            {"allow": "*"},
        ],
    )
    payload = {
        "tool_name": "Bash",
        "tool_input": {"command": "echo starting && rm -rf /tmp/foo"},
    }
    code, decision, _ = _invoke(policy, payload)
    assert code == 2
    assert decision.get("extracted_method") == "rm"


def test_http_method_lowercase_uppercased(tmp_path: Path):
    """http tool with {method: 'post'} -> action=http:POST."""
    policy = _write_policy(
        tmp_path,
        [
            {"deny": "http:POST", "reason": "read-only"},
            {"allow": "*"},
        ],
    )
    payload = {
        "tool_name": "http",
        "tool_input": {"method": "post", "url": "https://example.com"},
    }
    code, decision, _ = _invoke(policy, payload)
    assert code == 2
    assert decision.get("extracted_method") == "POST"


def test_fetch_alias_resolves_to_http(tmp_path: Path):
    policy = _write_policy(tmp_path, [{"allow": "*"}])
    payload = {
        "tool_name": "fetch",
        "tool_input": {"method": "delete"},
    }
    code, decision, _ = _invoke(policy, payload)
    assert code == 0
    assert decision.get("tool") == "http"
    assert decision.get("extracted_method") == "DELETE"
    assert decision.get("action") == "http:DELETE"


def test_claude_code_read_maps_to_file_read_read(tmp_path: Path):
    """Claude Code Read -> canonical tool file_read, method=read."""
    policy = _write_policy(tmp_path, [{"allow": "*"}])
    payload = {
        "tool_name": "Read",
        "tool_input": {"file_path": "/tmp/foo.txt"},
    }
    code, decision, _ = _invoke(policy, payload)
    assert code == 0
    assert decision.get("tool") == "file_read"
    assert decision.get("extracted_method") == "read"
    assert decision.get("action") == "file_read:read"


def test_claude_code_edit_maps_to_file_write_write(tmp_path: Path):
    policy = _write_policy(tmp_path, [{"allow": "*"}])
    payload = {
        "tool_name": "Edit",
        "tool_input": {
            "file_path": "/tmp/foo.txt",
            "old_string": "a",
            "new_string": "b",
        },
    }
    code, decision, _ = _invoke(policy, payload)
    assert code == 0
    assert decision.get("tool") == "file_write"
    assert decision.get("extracted_method") == "write"
    assert decision.get("action") == "file_write:write"


def test_browser_action_preserves_case(tmp_path: Path):
    policy = _write_policy(tmp_path, [{"allow": "*"}])
    payload = {
        "tool_name": "playwright",
        "tool_input": {"action": "click"},
    }
    code, decision, _ = _invoke(policy, payload)
    assert code == 0
    assert decision.get("tool") == "browser"
    assert decision.get("extracted_method") == "click"


# ---------------------------------------------------------------------------
# Fallback paths.
# ---------------------------------------------------------------------------


def test_database_empty_sql_falls_back_to_star(tmp_path: Path):
    policy = _write_policy(tmp_path, [{"allow": "*"}])
    payload = {"tool_name": "database", "tool_input": {"sql": ""}}
    code, decision, _ = _invoke(policy, payload)
    assert code == 0
    assert decision.get("extracted_method") == "*"
    assert decision.get("action") == "database:*"


def test_database_missing_sql_field_falls_back_to_star(tmp_path: Path):
    policy = _write_policy(tmp_path, [{"allow": "*"}])
    payload = {"tool_name": "database", "tool_input": {}}
    code, decision, _ = _invoke(policy, payload)
    assert code == 0
    assert decision.get("extracted_method") == "*"


def test_bash_whitespace_only_falls_back_to_star(tmp_path: Path):
    policy = _write_policy(tmp_path, [{"allow": "*"}])
    payload = {"tool_name": "Bash", "tool_input": {"command": "   \t "}}
    code, decision, _ = _invoke(policy, payload)
    assert code == 0
    assert decision.get("extracted_method") == "*"


def test_unknown_tool_falls_through_with_star(tmp_path: Path):
    policy = _write_policy(tmp_path, [{"allow": "*"}])
    payload = {
        "tool_name": "totally_unknown_tool",
        "tool_input": {"anything": "whatever"},
    }
    code, decision, _ = _invoke(policy, payload)
    assert code == 0
    assert decision.get("tool") == "totally_unknown_tool"
    assert decision.get("extracted_method") == "*"
    assert decision.get("action") == "totally_unknown_tool:*"


def test_unknown_tool_with_deny_default_blocks(tmp_path: Path):
    """Unknown tool + deny default + no allow -> block."""
    policy = _write_policy(
        tmp_path,
        [
            {"deny": "explicit_bad:*", "reason": "anything"},
        ],
        default_action="deny",
    )
    payload = {
        "tool_name": "mysterious",
        "tool_input": {},
    }
    code, decision, _ = _invoke(policy, payload)
    # No-match deny because default_action=deny. extracted_method
    # still populated so the audit row captures it.
    assert code == 2
    assert decision.get("extracted_method") == "*"
    assert decision.get("action") == "mysterious:*"


def test_codex_style_toolname_toolinput_aliases_accepted(tmp_path: Path):
    """Codex payloads use camelCase: toolName / toolInput."""
    policy = _write_policy(tmp_path, [{"allow": "*"}])
    # Use the alternate key names.
    runner = CliRunner()
    payload = {
        "toolName": "database",
        "toolInput": {"sql": "INSERT INTO t VALUES (1)"},
    }
    result = runner.invoke(
        cli,
        ["hook-check", "--policy", str(_write_policy(tmp_path / "b", [{"allow": "*"}]) if False else policy)],
        input=json.dumps(payload),
    )
    decision = {}
    for line in result.output.strip().splitlines():
        line = line.strip()
        if line.startswith("{"):
            decision = json.loads(line)
            break
    assert result.exit_code == 0, result.output
    assert decision.get("extracted_method") == "INSERT"


def test_extracted_method_in_audit_entry_local_mode(tmp_path: Path, monkeypatch):
    """The local audit sink receives the extracted_method field."""
    from controlzero.audit_local import LocalAuditLogger

    captured: list[dict] = []
    original_log = LocalAuditLogger.log

    def spy(self, entry):
        captured.append(entry)
        return original_log(self, entry)

    monkeypatch.setattr(LocalAuditLogger, "log", spy)

    policy = _write_policy(tmp_path, [{"allow": "*"}])
    payload = {
        "tool_name": "database",
        "tool_input": {"sql": "SELECT 1"},
    }
    code, _decision, _ = _invoke(policy, payload)
    assert code == 0
    assert captured, "no audit entries captured"
    entry = captured[-1]
    assert entry.get("extracted_method") == "SELECT"
    assert entry.get("extracted_action") == "database:SELECT"
    assert entry.get("host_tool_name") == "database"


def test_extracted_method_propagates_to_wire_format(tmp_path: Path):
    """The BearerAuditSink / RemoteAuditSink wire format carries extracted_method."""
    from controlzero.audit_remote import BearerAuditSink, RemoteAuditSink

    sink_bearer = BearerAuditSink.__new__(BearerAuditSink)
    sink_bearer._api_url = "https://example"
    sink_bearer._api_key = "cz_test_x"
    wire = sink_bearer._to_wire_format(
        {
            "tool": "database",
            "decision": "allow",
            "policy_id": "p1",
            "reason": "ok",
            "mode": "hosted",
            "extracted_method": "SELECT",
        }
    )
    assert wire["extracted_method"] == "SELECT"

    sink_remote = RemoteAuditSink.__new__(RemoteAuditSink)
    sink_remote._state_dir = None
    wire2 = sink_remote._to_wire_format(
        {
            "tool": "Bash",
            "decision": "block",
            "policy_id": "p2",
            "reason": "deny",
            "mode": "local",
            "extracted_method": "rm",
        }
    )
    assert wire2["extracted_method"] == "rm"


def test_extracted_method_missing_from_entry_yields_empty_string(tmp_path: Path):
    """SDK calls that don't populate extracted_method get an empty string."""
    from controlzero.audit_remote import BearerAuditSink

    sink = BearerAuditSink.__new__(BearerAuditSink)
    sink._api_url = "https://example"
    sink._api_key = "cz_test_x"
    wire = sink._to_wire_format(
        {
            "tool": "database",
            "decision": "allow",
            "policy_id": "p1",
            "reason": "ok",
            "mode": "hosted",
        }
    )
    assert wire["extracted_method"] == ""
