"""Tests for HITL-5a (gh#538): new HITL reason codes in 1.5.8.

The 9 new codes are registered in VALID_REASON_CODES so a 1.6.0+ client
emitting them via audit doesn't get rejected by a 1.5.8 ingest path.
1.5.8 itself never EMITS these codes (no HITL flow yet); it just
recognizes them.
"""
from __future__ import annotations

from controlzero._internal.enforcer import (
    REASON_CODE_DLP_BLOCKED,  # legacy sanity check
    REASON_CODE_HITL_ARGS_HASH_MISMATCH,
    REASON_CODE_HITL_BACKEND_UNREACHABLE,
    REASON_CODE_HITL_IDENTITY_CLAIM_REJECTED,
    REASON_CODE_HITL_IDENTITY_NOT_IN_ORG,
    REASON_CODE_HITL_IDENTITY_REQUIRED,
    REASON_CODE_HITL_NO_APPROVER_AVAILABLE,
    REASON_CODE_HITL_POLICY_VERSION_CONFLICT,
    REASON_CODE_HITL_SDK_TIMEOUT,
    REASON_CODE_HITL_SLA_EXPIRED,
    VALID_REASON_CODES,
)


HITL_CODES = (
    REASON_CODE_HITL_SDK_TIMEOUT,
    REASON_CODE_HITL_SLA_EXPIRED,
    REASON_CODE_HITL_BACKEND_UNREACHABLE,
    REASON_CODE_HITL_POLICY_VERSION_CONFLICT,
    REASON_CODE_HITL_NO_APPROVER_AVAILABLE,
    REASON_CODE_HITL_IDENTITY_NOT_IN_ORG,
    REASON_CODE_HITL_IDENTITY_REQUIRED,
    REASON_CODE_HITL_IDENTITY_CLAIM_REJECTED,
    REASON_CODE_HITL_ARGS_HASH_MISMATCH,
)


def test_all_9_hitl_codes_exported():
    # Module-level constants exist + are non-empty strings.
    for c in HITL_CODES:
        assert isinstance(c, str) and c.startswith("HITL_")


def test_all_9_hitl_codes_in_valid_set():
    for c in HITL_CODES:
        assert c in VALID_REASON_CODES, f"{c!r} missing from VALID_REASON_CODES"


def test_legacy_codes_still_in_valid_set():
    # No regression: existing 1.5.7 codes remain registered.
    assert REASON_CODE_DLP_BLOCKED in VALID_REASON_CODES


def test_hitl_codes_match_design_doc_exactly():
    # Spelling guard: any rename here breaks cross-SDK parity with the
    # design doc + Node + Go. Lock them in.
    assert REASON_CODE_HITL_SDK_TIMEOUT == "HITL_SDK_TIMEOUT"
    assert REASON_CODE_HITL_SLA_EXPIRED == "HITL_SLA_EXPIRED"
    assert REASON_CODE_HITL_BACKEND_UNREACHABLE == "HITL_BACKEND_UNREACHABLE"
    assert REASON_CODE_HITL_POLICY_VERSION_CONFLICT == "HITL_POLICY_VERSION_CONFLICT"
    assert REASON_CODE_HITL_NO_APPROVER_AVAILABLE == "HITL_NO_APPROVER_AVAILABLE"
    assert REASON_CODE_HITL_IDENTITY_NOT_IN_ORG == "HITL_IDENTITY_NOT_IN_ORG"
    assert REASON_CODE_HITL_IDENTITY_REQUIRED == "HITL_IDENTITY_REQUIRED"
    assert REASON_CODE_HITL_IDENTITY_CLAIM_REJECTED == "HITL_IDENTITY_CLAIM_REJECTED"
    assert REASON_CODE_HITL_ARGS_HASH_MISMATCH == "HITL_ARGS_HASH_MISMATCH"


def test_valid_set_size_grew_by_exactly_9():
    # 1.5.7 had 9 codes; 1.5.8 adds 9 -> 18. If anyone adds another
    # code without updating this test, it fires so the addition is
    # intentional + reviewed.
    assert len(VALID_REASON_CODES) == 9 + 9
