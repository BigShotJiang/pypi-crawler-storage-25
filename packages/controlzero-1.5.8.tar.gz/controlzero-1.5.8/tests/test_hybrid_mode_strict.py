"""Hybrid and hosted-mode Client construction semantics.

As of controlzero 1.4, hosted mode is implemented:
  - ``Client(api_key=...)`` pulls the signed bundle from the dashboard,
    verifies + decrypts + translates, and enforces it locally.
  - ``Client(policy=..., api_key=...)`` is hybrid mode and still warns,
    still raises with ``strict_hosted=True``.
  - ``Client(policy=...)`` pure-local mode is unchanged.

These tests cover construction-time semantics only (no real network).
End-to-end hosted-mode behavior is covered in ``test_hosted_policy.py``.
"""

import pytest

from controlzero import Client
from controlzero.errors import (
    HostedAuthError,
    HostedBootstrapError,
    HybridModeError,
)


def test_strict_hosted_hybrid_raises(monkeypatch):
    """API key + explicit local policy + strict_hosted=True => HybridModeError.

    T103: message reworded from "manual policy override detected" to
    "explicit ... overrides the hosted bundle". Semantics unchanged.
    """
    monkeypatch.setenv("CONTROLZERO_API_KEY", "cz_test_fakekey")
    with pytest.raises(HybridModeError, match="overrides the hosted bundle"):
        Client(
            policy={"rules": [{"deny": "delete_*"}]},
            strict_hosted=True,
        )


def test_hybrid_error_is_runtime_error_subclass():
    """Backward-compat: HybridModeError still catches as RuntimeError."""
    assert issubclass(HybridModeError, RuntimeError)


def test_strict_hosted_does_not_raise_in_pure_local():
    """No API key + local policy is fine even with strict_hosted=True."""
    cz = Client(
        policy={"rules": [{"allow": "*"}]},
        strict_hosted=True,
        log_path="/tmp/cz-strict.log",
    )
    assert cz.guard("anything").allowed
    cz.close()


def test_pure_local_mode_unchanged():
    """Regression test: pure-local mode must still work without any
    backend calls. Uses no env vars, no api_key arg."""
    cz = Client(policy={
        "version": "1",
        "rules": [
            {"deny": "send_email", "reason": "blocked"},
            {"allow": "*"},
        ],
    })
    assert cz.guard("web_search").effect == "allow"
    assert cz.guard("send_email").effect == "deny"
    cz.close()


def test_hosted_mode_fail_closed_no_backend(monkeypatch, tmp_path):
    """api_key set + unreachable backend + no cache => HostedBootstrapError.

    This enforces the fail-closed invariant: we never construct a Client
    with api_key but no policy if we cannot verify the backend.
    """
    # Point at a port nothing is listening on to guarantee refused connection.
    monkeypatch.setenv("CONTROLZERO_API_URL", "http://127.0.0.1:1")
    # Isolate the cache directory so stale caches don't mask the failure.
    monkeypatch.setenv("HOME", str(tmp_path))
    with pytest.raises(HostedBootstrapError, match="bootstrap request failed"):
        Client(api_key="cz_live_fakekey")


def test_hosted_mode_auth_error_surfaces_cleanly(monkeypatch, tmp_path, respx_mock):
    """401 from /v1/sdk/bootstrap => HostedAuthError with a clear message."""
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setenv("CONTROLZERO_API_URL", "https://api.fake.test")

    respx_mock.get("https://api.fake.test/v1/sdk/bootstrap").respond(401, json={"error": "INVALID_API_KEY"})
    with pytest.raises(HostedAuthError, match="rejected"):
        Client(api_key="cz_live_invalid")
