"""Phase 6: enrollment client unit tests.

Coverage matrix:
  - generate_keypair returns valid PEM
  - save/load private key roundtrip preserves bytes
  - save/load state roundtrip preserves all fields
  - sign_request produces a header dict that the SAME public key
    verifies (cryptographic round-trip)
  - sign_request canonical string format matches the backend exactly
  - enroll() happy path against an httpx mock
  - enroll() rejects 401 -> TokenError
  - enroll() rejects 503 -> EnrollmentError with FEATURE_DISABLED hint
  - heartbeat() sends signed request, parses response
  - pull_policy() with matching ETag returns None (304)
  - pull_policy() with stale ETag returns bundle and updates state
  - send_audit_batch validates max 500
  - compute_fingerprint is stable across calls
"""

from __future__ import annotations

import hashlib
import json
from base64 import b64decode

import httpx
import pytest

from controlzero.enrollment import (
    EnrollmentError,
    EnrollmentState,
    NotEnrolledError,
    PRIVKEY_FILE_NAME,
    STATE_FILE_NAME,
    TokenError,
    compute_fingerprint,
    enroll,
    generate_keypair,
    heartbeat,
    load_private_key,
    load_state,
    pull_policy,
    save_private_key,
    save_state,
    send_audit_batch,
    sign_request,
)


# --- key + state I/O -----------------------------------------------------


def test_generate_keypair_returns_valid_pem(tmp_path):
    priv, pem = generate_keypair()
    assert "BEGIN PUBLIC KEY" in pem
    assert "END PUBLIC KEY" in pem
    # Verify the private key actually signs
    sig = priv.sign(b"hello")
    assert len(sig) == 64  # Ed25519 signature length


def test_save_and_load_private_key_roundtrip(tmp_path):
    priv, _ = generate_keypair()
    save_private_key(priv, tmp_path)
    loaded = load_private_key(tmp_path)
    # Sign the same payload with both keys; signatures should match
    payload = b"deterministic"
    assert priv.sign(payload) == loaded.sign(payload)


def test_load_private_key_missing_raises(tmp_path):
    with pytest.raises(NotEnrolledError):
        load_private_key(tmp_path)


def test_save_and_load_state_roundtrip(tmp_path):
    state = EnrollmentState(
        machine_id="ba0d16ee-0580-49e5-a791-2c2cccedb13e",
        org_id="b4fdd5e2-292f-403b-96e8-ab9f2fb91788",
        api_url="https://api.example.com",
        hostname="dev-laptop",
        fingerprint_hint="abc123",
        machine_pubkey_pem="-----BEGIN PUBLIC KEY-----\nfake\n-----END PUBLIC KEY-----",
        enrolled_at="2026-04-08T10:50:42Z",
        policy_version=3,
        plugin_versions={"sdk": "0.2.0"},
    )
    save_state(state, tmp_path)
    loaded = load_state(tmp_path)
    assert loaded is not None
    assert loaded.machine_id == state.machine_id
    assert loaded.org_id == state.org_id
    assert loaded.policy_version == 3
    assert loaded.plugin_versions == {"sdk": "0.2.0"}


def test_load_state_missing_returns_none(tmp_path):
    assert load_state(tmp_path) is None


# --- sign_request --------------------------------------------------------


def test_sign_request_canonical_format_matches_backend(tmp_path):
    """The canonical signed string MUST match middleware/machine_auth.go.

    Backend format:
        machine_id + "\\n" + timestamp + "\\n" + method + "\\n" +
        path + "\\n" + sha256_hex(body)

    If this test ever drifts from the Go implementation, every signed
    request fails with INVALID_SIGNATURE in production. The test
    re-derives the canonical string client-side and verifies it
    against the same Ed25519 keypair.
    """
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
    from cryptography.hazmat.primitives import serialization

    priv, pub_pem = generate_keypair()
    save_private_key(priv, tmp_path)

    state = EnrollmentState(
        machine_id="ba0d16ee-0580-49e5-a791-2c2cccedb13e",
        org_id="b4fdd5e2-292f-403b-96e8-ab9f2fb91788",
        api_url="https://api.example.com",
        hostname="dev-laptop",
        fingerprint_hint="abc",
        machine_pubkey_pem=pub_pem,
        enrolled_at="2026-04-08T10:50:42Z",
    )

    body = b'{"hello":"world"}'
    headers = sign_request(state, "POST", "/api/heartbeat", body, state_dir=tmp_path, now=1712572800)

    assert headers["X-CZ-Machine-ID"] == state.machine_id
    assert headers["X-CZ-Timestamp"] == "1712572800"
    assert headers["X-CZ-Signature"]

    # Reconstruct the canonical string and verify the signature
    body_hash = hashlib.sha256(body).hexdigest()
    canonical = (
        f"{state.machine_id}\n1712572800\nPOST\n/api/heartbeat\n{body_hash}"
    ).encode("utf-8")

    pub = serialization.load_pem_public_key(pub_pem.encode("utf-8"))
    assert isinstance(pub, Ed25519PublicKey)
    sig = b64decode(headers["X-CZ-Signature"])
    pub.verify(sig, canonical)  # raises if invalid


def test_sign_request_empty_body(tmp_path):
    priv, pub_pem = generate_keypair()
    save_private_key(priv, tmp_path)
    state = EnrollmentState(
        machine_id="m1", org_id="o1", api_url="x", hostname="h",
        fingerprint_hint="fp", machine_pubkey_pem=pub_pem, enrolled_at="",
    )
    headers = sign_request(state, "GET", "/api/policy", b"", state_dir=tmp_path)
    assert headers["X-CZ-Machine-ID"] == "m1"
    assert headers["X-CZ-Signature"]


def test_sign_request_unenrolled_raises():
    state = EnrollmentState(
        machine_id="", org_id="", api_url="", hostname="",
        fingerprint_hint="", machine_pubkey_pem="", enrolled_at="",
    )
    with pytest.raises(NotEnrolledError):
        sign_request(state, "GET", "/api/policy")


# --- compute_fingerprint -------------------------------------------------


def test_compute_fingerprint_is_stable():
    a = compute_fingerprint()
    b = compute_fingerprint()
    assert a == b
    assert len(a) == 32  # truncated to 32 hex chars


# --- enroll() ------------------------------------------------------------


class MockTransport:
    """Tiny httpx transport stub returning a canned response."""

    def __init__(self, status_code: int, body: dict | str, extra_headers: dict | None = None):
        self.status_code = status_code
        self.body = body
        self.extra_headers = extra_headers or {}
        self.last_request = None

    def __call__(self, request: httpx.Request) -> httpx.Response:
        self.last_request = request
        if isinstance(self.body, dict):
            content = json.dumps(self.body).encode("utf-8")
            headers = {"content-type": "application/json"}
        else:
            content = self.body.encode("utf-8")
            headers = {"content-type": "text/plain"}
        headers.update(self.extra_headers)
        return httpx.Response(self.status_code, headers=headers, content=content)


def _patch_httpx(monkeypatch, mock):
    """Patch httpx.post + httpx.get to use a stub transport."""
    def fake_post(url, **kwargs):
        req = httpx.Request("POST", url, **{k: v for k, v in kwargs.items() if k in ("json", "content", "headers")})
        return mock(req)
    def fake_get(url, **kwargs):
        req = httpx.Request("GET", url, **{k: v for k, v in kwargs.items() if k in ("headers",)})
        return mock(req)
    monkeypatch.setattr(httpx, "post", fake_post)
    monkeypatch.setattr(httpx, "get", fake_get)


def test_enroll_happy_path(tmp_path, monkeypatch):
    mock = MockTransport(
        201,
        {
            "machine_id": "ba0d16ee-0580-49e5-a791-2c2cccedb13e",
            "org_id": "b4fdd5e2-292f-403b-96e8-ab9f2fb91788",
            "enrolled_at": "2026-04-08T10:50:42Z",
            "policy_version": 0,
        },
    )
    _patch_httpx(monkeypatch, mock)

    state = enroll(
        api_url="https://api.example.com",
        token="cz_enroll_test_token",
        state_dir=tmp_path,
    )

    assert state.machine_id == "ba0d16ee-0580-49e5-a791-2c2cccedb13e"
    assert state.org_id == "b4fdd5e2-292f-403b-96e8-ab9f2fb91788"
    assert (tmp_path / STATE_FILE_NAME).exists()
    assert (tmp_path / PRIVKEY_FILE_NAME).exists()

    # Reload state from disk should match
    reloaded = load_state(tmp_path)
    assert reloaded.machine_id == state.machine_id


def test_enroll_token_rejected(tmp_path, monkeypatch):
    mock = MockTransport(
        401,
        {"error": {"code": "INVALID_TOKEN", "message": "enrollment token not found"}},
    )
    _patch_httpx(monkeypatch, mock)

    with pytest.raises(TokenError):
        enroll(api_url="https://x", token="bad", state_dir=tmp_path)


def test_enroll_feature_disabled(tmp_path, monkeypatch):
    mock = MockTransport(
        503,
        {"error": "FEATURE_DISABLED", "message": "enrollment api is currently disabled"},
    )
    _patch_httpx(monkeypatch, mock)

    with pytest.raises(EnrollmentError, match="FEATURE_DISABLED"):
        enroll(api_url="https://x", token="any", state_dir=tmp_path)


def test_enroll_missing_token():
    with pytest.raises(TokenError):
        enroll(api_url="https://x", token="")


# --- heartbeat -----------------------------------------------------------


def test_heartbeat_signed_request(tmp_path, monkeypatch):
    # Pre-enroll
    enroll_mock = MockTransport(
        201,
        {"machine_id": "m1", "org_id": "o1", "enrolled_at": "2026-04-08T10:00:00Z", "policy_version": 0},
    )
    _patch_httpx(monkeypatch, enroll_mock)
    enroll(api_url="https://api.example.com", token="t", state_dir=tmp_path)

    # Now heartbeat with a fresh mock
    hb_mock = MockTransport(200, {"server_time": "2026-04-08T10:01:00Z", "policy_version": 5})
    _patch_httpx(monkeypatch, hb_mock)

    state = load_state(tmp_path)
    resp = heartbeat(state, state_dir=tmp_path)
    assert resp["policy_version"] == 5

    # Verify the request was signed
    assert hb_mock.last_request.headers.get("x-cz-machine-id") == "m1"
    assert hb_mock.last_request.headers.get("x-cz-signature")


def test_heartbeat_not_enrolled(tmp_path):
    with pytest.raises(NotEnrolledError):
        heartbeat(state_dir=tmp_path)


# --- pull_policy ---------------------------------------------------------


def test_pull_policy_etag_match_returns_none(tmp_path, monkeypatch):
    # Pre-enroll with policy_version=3
    enroll_mock = MockTransport(
        201,
        {"machine_id": "m1", "org_id": "o1", "enrolled_at": "x", "policy_version": 3},
    )
    _patch_httpx(monkeypatch, enroll_mock)
    enroll(api_url="https://api.example.com", token="t", state_dir=tmp_path)

    # Server returns 304 Not Modified
    pull_mock = MockTransport(304, "")
    _patch_httpx(monkeypatch, pull_mock)

    bundle = pull_policy(state_dir=tmp_path)
    assert bundle is None
    # Verify If-None-Match was sent with the cached version
    assert pull_mock.last_request.headers.get("if-none-match") == '"3"'


def test_pull_policy_stale_returns_bundle_and_updates_state(tmp_path, monkeypatch):
    # Pre-enroll with policy_version=2
    enroll_mock = MockTransport(
        201,
        {"machine_id": "m1", "org_id": "o1", "enrolled_at": "x", "policy_version": 2},
    )
    _patch_httpx(monkeypatch, enroll_mock)
    enroll(api_url="https://api.example.com", token="t", state_dir=tmp_path)

    # Server returns 200 with version 5
    pull_mock = MockTransport(
        200,
        {
            "policy_version": 5,
            "rules": [
                {"id": "r1", "name": "ssn", "pattern": r"\d{3}-\d{2}-\d{4}",
                 "category": "pii", "action": "block", "scopes": ["sdk"]},
            ],
        },
    )
    _patch_httpx(monkeypatch, pull_mock)

    bundle = pull_policy(state_dir=tmp_path)
    assert bundle is not None
    assert bundle["policy_version"] == 5
    assert len(bundle["rules"]) == 1

    # Local state should be updated
    state = load_state(tmp_path)
    assert state.policy_version == 5


# --- send_audit_batch ----------------------------------------------------


def test_send_audit_batch_validates_size():
    state = EnrollmentState(
        machine_id="m", org_id="o", api_url="x", hostname="h",
        fingerprint_hint="f", machine_pubkey_pem="", enrolled_at="",
    )
    with pytest.raises(EnrollmentError, match="empty"):
        send_audit_batch([], state)
    with pytest.raises(EnrollmentError, match="500"):
        send_audit_batch([{"id": "x"}] * 501, state)


def test_send_audit_batch_happy_path(tmp_path, monkeypatch):
    enroll_mock = MockTransport(
        201, {"machine_id": "m1", "org_id": "o1", "enrolled_at": "x", "policy_version": 0},
    )
    _patch_httpx(monkeypatch, enroll_mock)
    enroll(api_url="https://api.example.com", token="t", state_dir=tmp_path)

    audit_mock = MockTransport(200, {"accepted": 2, "dropped": 0})
    _patch_httpx(monkeypatch, audit_mock)

    state = load_state(tmp_path)
    resp = send_audit_batch(
        [
            {"id": "e1", "tool_name": "bash", "decision": "allow"},
            {"id": "e2", "tool_name": "read", "decision": "deny"},
        ],
        state,
        state_dir=tmp_path,
    )
    assert resp["accepted"] == 2
    assert resp["dropped"] == 0


# --- WS1: org signing pubkey + bundle signature verification ---------------


def test_org_signing_pubkey_persisted_from_enrollment(tmp_path, monkeypatch):
    """org_signing_pubkey from the enrollment response is persisted in the state file."""
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    from cryptography.hazmat.primitives import serialization

    org_priv = Ed25519PrivateKey.generate()
    org_pub_pem = org_priv.public_key().public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    ).decode("utf-8")

    mock = MockTransport(
        201,
        {
            "machine_id": "m1",
            "org_id": "o1",
            "enrolled_at": "2026-04-12T00:00:00Z",
            "policy_version": 0,
            "org_signing_pubkey": org_pub_pem,
        },
    )
    _patch_httpx(monkeypatch, mock)

    state = enroll(api_url="https://api.example.com", token="tok", state_dir=tmp_path)
    assert state.org_signing_pubkey_pem == org_pub_pem

    reloaded = load_state(tmp_path)
    assert reloaded.org_signing_pubkey_pem == org_pub_pem


def test_org_signing_pubkey_defaults_empty_when_omitted(tmp_path, monkeypatch):
    """When server does not include org_signing_pubkey, it defaults to empty string."""
    mock = MockTransport(
        201,
        {
            "machine_id": "m1",
            "org_id": "o1",
            "enrolled_at": "2026-04-12T00:00:00Z",
            "policy_version": 0,
        },
    )
    _patch_httpx(monkeypatch, mock)

    state = enroll(api_url="https://api.example.com", token="tok", state_dir=tmp_path)
    assert state.org_signing_pubkey_pem == ""


def test_pull_policy_verifies_valid_signature(tmp_path, monkeypatch):
    """pull_policy verifies the X-Policy-Signature header against org pubkey."""
    import base64
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    from cryptography.hazmat.primitives import serialization

    org_priv = Ed25519PrivateKey.generate()
    org_pub_pem = org_priv.public_key().public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    ).decode("utf-8")

    # Pre-enroll with org pubkey
    enroll_mock = MockTransport(
        201,
        {
            "machine_id": "m1",
            "org_id": "o1",
            "enrolled_at": "x",
            "policy_version": 0,
            "org_signing_pubkey": org_pub_pem,
        },
    )
    _patch_httpx(monkeypatch, enroll_mock)
    enroll(api_url="https://api.example.com", token="t", state_dir=tmp_path)

    # Build a signed policy bundle response
    bundle = {"policy_version": 1, "rules": []}
    bundle_bytes = json.dumps(bundle).encode("utf-8")
    sig = org_priv.sign(bundle_bytes)
    sig_b64 = base64.b64encode(sig).decode("ascii")

    pull_mock = MockTransport(200, bundle, extra_headers={"X-Policy-Signature": sig_b64})
    _patch_httpx(monkeypatch, pull_mock)

    result = pull_policy(state_dir=tmp_path)
    assert result is not None
    assert result["policy_version"] == 1


def test_pull_policy_raises_on_bad_signature(tmp_path, monkeypatch):
    """pull_policy raises BundleSignatureError on invalid signature."""
    import base64
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    from cryptography.hazmat.primitives import serialization
    from controlzero.errors import BundleSignatureError

    org_priv = Ed25519PrivateKey.generate()
    org_pub_pem = org_priv.public_key().public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    ).decode("utf-8")

    # Pre-enroll with org pubkey
    enroll_mock = MockTransport(
        201,
        {
            "machine_id": "m1",
            "org_id": "o1",
            "enrolled_at": "x",
            "policy_version": 0,
            "org_signing_pubkey": org_pub_pem,
        },
    )
    _patch_httpx(monkeypatch, enroll_mock)
    enroll(api_url="https://api.example.com", token="t", state_dir=tmp_path)

    # Sign with a DIFFERENT key (wrong signature)
    wrong_priv = Ed25519PrivateKey.generate()
    bundle = {"policy_version": 1, "rules": []}
    bundle_bytes = json.dumps(bundle).encode("utf-8")
    bad_sig = wrong_priv.sign(bundle_bytes)
    bad_sig_b64 = base64.b64encode(bad_sig).decode("ascii")

    pull_mock = MockTransport(200, bundle, extra_headers={"X-Policy-Signature": bad_sig_b64})
    _patch_httpx(monkeypatch, pull_mock)

    with pytest.raises(BundleSignatureError):
        pull_policy(state_dir=tmp_path)


def test_pull_policy_backward_compat_no_pubkey_no_header(tmp_path, monkeypatch):
    """No pubkey + no signature header = backward compatible, no error."""
    enroll_mock = MockTransport(
        201,
        {
            "machine_id": "m1",
            "org_id": "o1",
            "enrolled_at": "x",
            "policy_version": 0,
        },
    )
    _patch_httpx(monkeypatch, enroll_mock)
    enroll(api_url="https://api.example.com", token="t", state_dir=tmp_path)

    pull_mock = MockTransport(200, {"policy_version": 1, "rules": []})
    _patch_httpx(monkeypatch, pull_mock)

    result = pull_policy(state_dir=tmp_path)
    assert result is not None
    assert result["policy_version"] == 1
