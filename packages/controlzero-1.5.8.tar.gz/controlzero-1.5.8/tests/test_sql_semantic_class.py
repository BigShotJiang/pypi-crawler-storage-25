"""SQL semantic-class extractor tests (issue #345).

a customer reported a `db-read-only` policy that denied legitimate
read-only SQL because the per-keyword extractor surfaced `WITH`,
`EXPLAIN`, and `SHOW` as the canonical method while the blueprint
wrote rules against `database:query`/`database:execute`/`database:delete`
-- strings the extractor never produces.

The fix introduces a portable canonical layer: every SQL statement
resolves to one of four semantic classes. Rules can match the
keyword (existing behaviour), the class, or both. Multi-statement
piggyback like ``SELECT 1; DROP TABLE x`` resolves to ``admin`` so
a deny-admin rule catches it.

The cross-SDK parity test at the bottom of this module loads
``tests/fixtures/enforcement-spec/extractors/parity-cases.json``
section ``sql_semantic_class_cases`` and asserts byte-identical
output between Python and Node SDKs.
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from controlzero._internal.hook_extractors import (
    most_dangerous_sql_keyword,
    sql_semantic_class,
)


# ---------------------------------------------------------------------------
# Table-driven happy path: 21 canonical cases.
# ---------------------------------------------------------------------------


CASES = [
    # read
    ("SELECT * FROM users", "read"),
    ("WITH x AS (SELECT 1) SELECT * FROM x", "read"),
    ("SELECT * FROM u WHERE id IN (SELECT id FROM admins)", "read"),
    ("EXPLAIN SELECT * FROM users", "read"),
    ("EXPLAIN ANALYZE SELECT * FROM users", "read"),
    ("SHOW TABLES", "read"),
    ("DESCRIBE users", "read"),
    # write
    ("INSERT INTO users (a) VALUES (1)", "write"),
    ("UPDATE users SET a=1", "write"),
    ("DELETE FROM users WHERE id=1", "write"),
    (
        "MERGE INTO target USING source ON target.id = source.id "
        "WHEN MATCHED THEN UPDATE SET a = source.a",
        "write",
    ),
    # admin
    ("CREATE TABLE x (a int)", "admin"),
    ("ALTER TABLE x ADD COLUMN b int", "admin"),
    ("DROP TABLE x", "admin"),
    ("TRUNCATE TABLE x", "admin"),
    ("GRANT SELECT ON x TO y", "admin"),
    # transaction-control class
    ("BEGIN", "exec"),
    ("COMMIT", "exec"),
    ("ROLLBACK", "exec"),
    # injection: most-dangerous-class wins
    ("SELECT 1; DROP TABLE users", "admin"),
    # multi-select stays read
    ("SELECT 1; SELECT 2", "read"),
]


@pytest.mark.parametrize("sql,expected", CASES, ids=[c[0][:40] for c in CASES])
def test_sql_semantic_class_table(sql: str, expected: str) -> None:
    assert sql_semantic_class(sql) == expected


# ---------------------------------------------------------------------------
# Edge cases.
# ---------------------------------------------------------------------------


def test_empty_string_is_empty() -> None:
    assert sql_semantic_class("") == ""


def test_whitespace_only_is_empty() -> None:
    assert sql_semantic_class("   \n\t  ") == ""


def test_non_string_is_empty() -> None:
    # Defensive: never raise on bad input, hook stays fail-soft.
    assert sql_semantic_class(None) == ""  # type: ignore[arg-type]
    assert sql_semantic_class(123) == ""  # type: ignore[arg-type]


def test_only_comment_is_empty() -> None:
    assert sql_semantic_class("-- nothing here\n") == ""


def test_unrecognized_keyword_is_empty() -> None:
    assert sql_semantic_class("FOOBAR baz") == ""


def test_lowercase_uppercases() -> None:
    assert sql_semantic_class("select * from t") == "read"
    assert sql_semantic_class("drop table x") == "admin"


def test_string_literal_does_not_hide_drop_in_other_statement() -> None:
    assert (
        sql_semantic_class("SELECT 'DROP TABLE users'; DROP TABLE x")
        == "admin"
    )


def test_string_literal_alone_stays_read() -> None:
    assert sql_semantic_class("SELECT 'DROP TABLE users' AS msg") == "read"


def test_block_comment_does_not_promote_class() -> None:
    assert sql_semantic_class("SELECT 1 /* ; DROP TABLE x */") == "read"


def test_admin_beats_write() -> None:
    assert sql_semantic_class("UPDATE x SET a=1; DROP TABLE x") == "admin"


def test_write_beats_read() -> None:
    assert sql_semantic_class("SELECT 1; DELETE FROM x") == "write"


def test_txn_class_beats_read() -> None:
    # COMMIT outranks SELECT in the class ordering.
    assert sql_semantic_class("SELECT 1; COMMIT") == "exec"


def test_admin_beats_txn_class() -> None:
    # DROP outranks ROLLBACK in the class ordering.
    assert sql_semantic_class("ROLLBACK; DROP TABLE x") == "admin"


def test_write_beats_txn_class() -> None:
    # DELETE outranks COMMIT in the class ordering.
    assert sql_semantic_class("COMMIT; DELETE FROM x") == "write"


def test_keyword_layer_unchanged_for_select() -> None:
    # Sanity: the existing per-keyword extractor still produces SELECT
    # so existing rules like `database:SELECT` keep working.
    assert most_dangerous_sql_keyword("SELECT * FROM t") == "SELECT"


def test_keyword_layer_unchanged_for_drop() -> None:
    assert most_dangerous_sql_keyword("DROP TABLE x") == "DROP"


# ---------------------------------------------------------------------------
# Cross-SDK parity: load fixture and assert every case agrees with Node.
# ---------------------------------------------------------------------------


def _find_parity_fixture() -> Path | None:
    here = Path(__file__).resolve()
    for candidate in [here.parent, *here.parents]:
        hit = (
            candidate
            / "tests"
            / "fixtures"
            / "enforcement-spec"
            / "extractors"
            / "parity-cases.json"
        )
        if hit.exists():
            return hit
    return None


_PARITY_PATH = _find_parity_fixture()


def _load_semantic_cases():
    if _PARITY_PATH is None:
        return []
    data = json.loads(_PARITY_PATH.read_text(encoding="utf-8"))
    return data.get("sql_semantic_class_cases", [])


_SEMANTIC_CASES = _load_semantic_cases()


@pytest.mark.skipif(
    not _SEMANTIC_CASES, reason="parity fixture not bundled in this image"
)
@pytest.mark.parametrize(
    "case", _SEMANTIC_CASES, ids=[c["name"] for c in _SEMANTIC_CASES]
)
def test_parity_semantic_class(case) -> None:
    sql = case["sql"]
    expected_keyword = case.get("expected_keyword", "")
    expected_class = case["expected_class"]

    keyword = most_dangerous_sql_keyword(sql)
    cls = sql_semantic_class(sql)

    assert keyword == expected_keyword, (
        f"{case['name']}: keyword {keyword!r} != expected "
        f"{expected_keyword!r}"
    )
    assert cls == expected_class, (
        f"{case['name']}: class {cls!r} != expected {expected_class!r}"
    )
