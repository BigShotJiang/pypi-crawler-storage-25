"""Tests for quarantine (mandatory tamper enforcement) in WS2."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from controlzero.tamper import TamperState, report_tamper_alert


# ---------------------------------------------------------------------------
# TamperState persistence
# ---------------------------------------------------------------------------


def test_tamper_state_save_load_roundtrip(tmp_path: Path):
    """Save quarantine state, load it back, fields match."""
    state = TamperState(
        quarantined=True,
        reason="test reason",
        detected_at="2026-04-12T00:00:00Z",
        source="policy_hmac",
    )
    state.save(tmp_path)
    loaded = TamperState.load(tmp_path)
    assert loaded.quarantined is True
    assert loaded.reason == "test reason"
    assert loaded.detected_at == "2026-04-12T00:00:00Z"
    assert loaded.source == "policy_hmac"


def test_tamper_state_is_quarantined_true(tmp_path: Path):
    """After enter_quarantine, is_quarantined returns True."""
    TamperState.enter_quarantine(tmp_path, "tamper detected", "audit_chain")
    assert TamperState.is_quarantined(tmp_path) is True


def test_tamper_state_is_quarantined_false_when_no_file(tmp_path: Path):
    """No quarantine.json means not quarantined."""
    assert TamperState.is_quarantined(tmp_path) is False


def test_tamper_state_clear(tmp_path: Path):
    """After clear, is_quarantined returns False."""
    TamperState.enter_quarantine(tmp_path, "tamper detected", "policy_hmac")
    assert TamperState.is_quarantined(tmp_path) is True
    TamperState.clear(tmp_path)
    assert TamperState.is_quarantined(tmp_path) is False


def test_tamper_state_load_malformed_json(tmp_path: Path):
    """Malformed JSON falls back to default (not quarantined)."""
    qfile = tmp_path / "quarantine.json"
    qfile.write_text("not valid json", encoding="utf-8")
    assert TamperState.is_quarantined(tmp_path) is False
    loaded = TamperState.load(tmp_path)
    assert loaded.quarantined is False


def test_tamper_state_enter_quarantine_sets_detected_at(tmp_path: Path):
    """enter_quarantine writes a non-empty detected_at timestamp."""
    TamperState.enter_quarantine(tmp_path, "reason", "bundle_signature")
    state = TamperState.load(tmp_path)
    assert state.detected_at.endswith("Z")
    assert len(state.detected_at) > 10


# ---------------------------------------------------------------------------
# Client.guard() quarantine integration
# ---------------------------------------------------------------------------


def test_client_guard_denies_when_quarantined(tmp_path: Path):
    """When quarantined, Client.guard() returns deny for any tool."""
    TamperState.enter_quarantine(tmp_path, "tamper", "policy_hmac")

    from controlzero.client import Client

    # Monkey-patch the tamper state dir
    cz = Client(policy={"rules": [{"allow": "*"}]})
    cz._tamper_state_dir = tmp_path

    decision = cz.guard("anything")
    assert decision.denied
    assert "quarantined" in decision.reason.lower()
    cz.close()


def test_client_guard_allows_after_clear(tmp_path: Path):
    """After clearing quarantine, guard evaluates normally."""
    TamperState.enter_quarantine(tmp_path, "tamper", "policy_hmac")
    TamperState.clear(tmp_path)

    from controlzero.client import Client

    cz = Client(policy={"rules": [{"allow": "*"}]})
    cz._tamper_state_dir = tmp_path

    decision = cz.guard("anything")
    assert decision.allowed
    cz.close()


def test_client_guard_quarantined_raises_on_deny(tmp_path: Path):
    """When quarantined + raise_on_deny, PolicyDeniedError is raised."""
    TamperState.enter_quarantine(tmp_path, "tamper", "policy_hmac")

    from controlzero._internal.enforcer import PolicyDeniedError
    from controlzero.client import Client

    cz = Client(policy={"rules": [{"allow": "*"}]})
    cz._tamper_state_dir = tmp_path

    with pytest.raises(PolicyDeniedError):
        cz.guard("anything", raise_on_deny=True)
    cz.close()


# ---------------------------------------------------------------------------
# CLI hook-check quarantine
# ---------------------------------------------------------------------------


def test_hook_check_exits_2_when_quarantined(tmp_path: Path):
    """When quarantined, hook-check exits 2 with block JSON on stdout."""
    TamperState.enter_quarantine(tmp_path, "tamper", "policy_hmac")

    from click.testing import CliRunner

    from controlzero.cli.main import cli

    runner = CliRunner()

    # Write a policy file so the CLI gets past the "no policy" check
    policy_path = tmp_path / "policy.yaml"
    policy_path.write_text(
        "version: '1'\nrules:\n  - allow: '*'\n",
        encoding="utf-8",
    )

    with patch("controlzero.cli.main.GLOBAL_POLICY_DIR", tmp_path), \
         patch("controlzero.cli.main.GLOBAL_POLICY_PATH", policy_path):
        result = runner.invoke(
            cli,
            ["hook-check", "--policy", str(policy_path)],
            input='{"tool_name": "test_tool", "tool_input": {}}',
        )
    assert result.exit_code == 2
    stdout_json = json.loads(result.output.strip())
    assert stdout_json["decision"] == "block"
    assert "quarantined" in stdout_json["reason"].lower()


# ---------------------------------------------------------------------------
# Tamper alert reporting
# ---------------------------------------------------------------------------


def test_tamper_alert_post_sent(tmp_path: Path):
    """Verify report_tamper_alert attempts a POST and does not raise."""
    # Create a fake enrollment state
    enrollment_state = MagicMock()
    enrollment_state.api_url = "https://api.controlzero.ai"
    enrollment_state.hostname = "test-host"
    enrollment_state.machine_id = "machine-123"

    mock_sign = MagicMock(return_value={"X-CZ-Machine-ID": "m", "X-CZ-Timestamp": "1"})
    mock_httpx = MagicMock()

    with patch("controlzero.enrollment.load_state", return_value=enrollment_state), \
         patch("controlzero.enrollment.sign_request", mock_sign):
        # Patch httpx at the point where it gets imported inside report_tamper_alert
        import sys
        sys.modules["httpx"] = mock_httpx
        try:
            report_tamper_alert(tmp_path, "policy_hmac", {"test": True})
        finally:
            # Clean up the mock module
            if "httpx" in sys.modules and sys.modules["httpx"] is mock_httpx:
                del sys.modules["httpx"]

    # The function should have attempted a POST (best-effort, no crash)
    mock_httpx.post.assert_called_once()


def test_tamper_alert_noop_when_not_enrolled(tmp_path: Path):
    """No enrollment.json means report_tamper_alert does nothing (no crash)."""
    # This should complete without error even with no enrollment state
    report_tamper_alert(tmp_path, "policy_hmac")
