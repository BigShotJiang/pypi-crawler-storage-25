"""Cross-SDK action alias parity (T84 / GitHub #389).

Mirrors the cross-SDK fixture at tests/parity/action_aliases.json.
The same shape of tests runs in the Node SDK
(tests/actionAliases.test.ts) and the Go SDK
(action_aliases_test.go). Drift in any SDK breaks parity here.

Mandate: NO BREAKING CHANGES. Pre-#350 customer rules using legacy
database action names (database:query, database:DROP, ...) MUST keep
matching even after the SDK started emitting canonical SQL classes.
"""

from __future__ import annotations

import hashlib
import json
import unittest
from pathlib import Path

from controlzero._internal.action_aliases import (
    alias_table_json,
    expand_candidate_actions,
)
from controlzero._internal.enforcer import PolicyEvaluator
from controlzero._internal.types import PolicyRule


# ---------------------------------------------------------------------------
# Locate the cross-SDK parity fixture. Walks up from this file looking
# for the repo's tests/parity/action_aliases.json. The same routine is
# used by other parity tests so the test stays robust to where the SDK
# tree sits inside the monorepo.
# ---------------------------------------------------------------------------
def _parity_fixture_path() -> Path:
    here = Path(__file__).resolve()
    for candidate in [here.parent, *here.parents]:
        fixture = candidate / "tests" / "parity" / "action_aliases.json"
        if fixture.exists():
            return fixture
    raise FileNotFoundError("tests/parity/action_aliases.json not found")


class AliasTableParityTests(unittest.TestCase):
    """Confirm the in-SDK alias table matches the cross-SDK fixture."""

    def test_json_dump_matches_fixture(self) -> None:
        fixture = json.loads(_parity_fixture_path().read_text())
        fixture.pop("comment", None)
        expected = json.dumps(fixture, indent=2, sort_keys=False)
        self.assertEqual(alias_table_json(), expected)

    def test_sha256_matches_fixture(self) -> None:
        fixture = json.loads(_parity_fixture_path().read_text())
        fixture.pop("comment", None)
        expected = json.dumps(fixture, indent=2, sort_keys=False)
        expected_hash = hashlib.sha256(expected.encode()).hexdigest()
        actual_hash = hashlib.sha256(alias_table_json().encode()).hexdigest()
        self.assertEqual(actual_hash, expected_hash)


class ExpandCandidateActionsTests(unittest.TestCase):
    """Bidirectional alias expansion."""

    def test_legacy_query_expands_to_canonical_read(self) -> None:
        out = expand_candidate_actions(["database:query"])
        self.assertIn("database:query", out)
        self.assertIn("database:read", out)
        # Original always first.
        self.assertEqual(out[0], "database:query")

    def test_canonical_read_expands_to_every_legacy_alias(self) -> None:
        out = expand_candidate_actions(["database:read"])
        for alias in ("query", "SELECT", "EXPLAIN", "SHOW", "DESCRIBE", "FETCH", "READ"):
            self.assertIn(f"database:{alias}", out, f"missing alias {alias}")
        self.assertEqual(out[0], "database:read")

    def test_canonical_write_includes_DELETE(self) -> None:
        out = expand_candidate_actions(["database:write"])
        self.assertIn("database:DELETE", out)
        self.assertIn("database:UPDATE", out)
        self.assertIn("database:INSERT", out)

    def test_canonical_admin_includes_DROP(self) -> None:
        out = expand_candidate_actions(["database:admin"])
        self.assertIn("database:DROP", out)
        self.assertIn("database:TRUNCATE", out)

    def test_canonical_exec_includes_execute(self) -> None:
        out = expand_candidate_actions(["database:exec"])
        self.assertIn("database:execute", out)
        self.assertIn("database:CALL", out)

    def test_legacy_delete_is_ambiguous(self) -> None:
        """Legacy database:delete maps to BOTH write AND admin."""
        out = expand_candidate_actions(["database:delete"])
        self.assertIn("database:delete", out)
        self.assertIn("database:write", out)
        self.assertIn("database:admin", out)

    def test_non_database_tool_is_passthrough(self) -> None:
        out = expand_candidate_actions(["github:open_issue"])
        self.assertEqual(out, ["github:open_issue"])

    def test_unknown_database_method_is_passthrough(self) -> None:
        out = expand_candidate_actions(["database:VACUUM"])
        # No alias mapping; passes through unchanged.
        self.assertEqual(out, ["database:VACUUM"])

    def test_empty_input_returns_empty(self) -> None:
        self.assertEqual(expand_candidate_actions([]), [])

    def test_dedupes_repeated_actions(self) -> None:
        out = expand_candidate_actions(["database:query", "database:query"])
        self.assertEqual(out.count("database:query"), 1)

    def test_malformed_action_is_skipped(self) -> None:
        out = expand_candidate_actions(["no_colon"])
        # No expansion possible; returned as-is.
        self.assertEqual(out, ["no_colon"])


class EnforcerRoundtripTests(unittest.TestCase):
    """End-to-end: every legacy name through guard() against a
    canonical-name rule, AND every canonical name against a legacy-name
    rule. No false positives."""

    LEGACY_TO_CLASS = {
        "query": "read",
        "SELECT": "read",
        "EXPLAIN": "read",
        "SHOW": "read",
        "DESCRIBE": "read",
        "FETCH": "read",
        "READ": "read",
        "UPDATE": "write",
        "INSERT": "write",
        "DELETE": "write",
        "MERGE": "write",
        "UPSERT": "write",
        "REPLACE": "write",
        "DROP": "admin",
        "CREATE": "admin",
        "TRUNCATE": "admin",
        "ALTER": "admin",
        "GRANT": "admin",
        "REVOKE": "admin",
        "RENAME": "admin",
        "execute": "exec",
        "EXECUTE": "exec",
        "EXEC": "exec",
        "CALL": "exec",
        "do": "exec",
    }

    def _allow_rule(self, action: str) -> PolicyRule:
        return PolicyRule(
            id="r1",
            name="r1",
            effect="allow",
            actions=[action],
            resources=["*"],
            conditions={},
            reason="alias-roundtrip",
        )

    def test_legacy_call_matches_canonical_rule(self) -> None:
        """Caller passes legacy method name (SELECT); rule is written
        against the canonical class (database:read). Should ALLOW."""
        for legacy, cls in self.LEGACY_TO_CLASS.items():
            with self.subTest(legacy=legacy, canonical=cls):
                evaluator = PolicyEvaluator(rules=[self._allow_rule(f"database:{cls}")])
                decision = evaluator.evaluate("database", legacy)
                self.assertEqual(
                    decision.effect,
                    "allow",
                    f"legacy method {legacy!r} did not match canonical rule database:{cls}",
                )

    def test_canonical_call_matches_legacy_rule(self) -> None:
        """Caller passes canonical class (read); rule is written against a
        legacy method (database:SELECT). Should ALLOW."""
        for legacy, cls in self.LEGACY_TO_CLASS.items():
            with self.subTest(legacy=legacy, canonical=cls):
                evaluator = PolicyEvaluator(rules=[self._allow_rule(f"database:{legacy}")])
                decision = evaluator.evaluate("database", cls)
                self.assertEqual(
                    decision.effect,
                    "allow",
                    f"canonical method {cls!r} did not match legacy rule database:{legacy}",
                )

    def test_legacy_delete_matches_both_write_and_admin_rules(self) -> None:
        """Ambiguous legacy database:delete should match a canonical
        write rule AND a canonical admin rule (either intent)."""
        for cls in ("write", "admin"):
            with self.subTest(canonical=cls):
                evaluator = PolicyEvaluator(rules=[self._allow_rule(f"database:{cls}")])
                decision = evaluator.evaluate("database", "delete")
                self.assertEqual(decision.effect, "allow")

    def test_no_false_positive_for_unrelated_tool(self) -> None:
        """A database alias rule must NOT match a github call."""
        evaluator = PolicyEvaluator(rules=[self._allow_rule("database:read")])
        decision = evaluator.evaluate("github", "SELECT")
        # No allow rule matches github -> default deny.
        self.assertEqual(decision.effect, "deny")

    def test_no_false_positive_across_classes(self) -> None:
        """A read-class rule must NOT match a write-class call."""
        evaluator = PolicyEvaluator(rules=[self._allow_rule("database:read")])
        # INSERT is in the write class. No read rule should fire.
        decision = evaluator.evaluate("database", "INSERT")
        self.assertEqual(decision.effect, "deny")

    def test_unknown_method_does_not_falsely_match(self) -> None:
        """A method name with no alias mapping must not silently match
        any class rule."""
        evaluator = PolicyEvaluator(rules=[self._allow_rule("database:read")])
        decision = evaluator.evaluate("database", "VACUUM")
        self.assertEqual(decision.effect, "deny")


if __name__ == "__main__":
    unittest.main()
