"""Tests for the synthetic:* policy_id sentinels (T79).

These tests pin the contract that the audit dashboard relies on to
distinguish four very different bug classes (stale bundle, missing
resource gate, vocabulary mismatch, genuine no-match) that all
previously rendered identically as `Decision=Deny, policy_id="",
reason_code=NO_RULE_MATCH`.

The synthetic:* prefix is load-bearing: the backend audit ingest
stores policy_id verbatim (no validation on content), the frontend
matches on the prefix to switch chip styling, and the values
themselves mirror the reason_code enum 1:1 PLUS one new value
(RESOURCE_GATE_SKIP) that captures the T83-class bug.
"""

from __future__ import annotations

import pytest

from controlzero._internal.bundle import (
    make_bundle_missing_policy,
    translate_to_local_policy,
)
from controlzero._internal.enforcer import (
    SYNTHETIC_BUNDLE_MISSING,
    SYNTHETIC_ENGINE_UNAVAILABLE,
    SYNTHETIC_NO_ACTIVE_POLICIES,
    SYNTHETIC_NO_RULE_MATCH,
    SYNTHETIC_POLICY_ID_PREFIX,
    SYNTHETIC_QUARANTINE,
    SYNTHETIC_RESOURCE_GATE_SKIP,
    VALID_SYNTHETIC_POLICY_IDS,
    PolicyEvaluator,
)
from controlzero.policy_loader import load_policy


# ---- enum surface ---------------------------------------------------------


def test_synthetic_constants_have_expected_string_values():
    """The frontend, the backend, and three SDKs all match on these
    exact strings. Renames are a hard wire-format break.
    """
    assert SYNTHETIC_POLICY_ID_PREFIX == "synthetic:"
    assert SYNTHETIC_NO_RULE_MATCH == "synthetic:NO_RULE_MATCH"
    assert SYNTHETIC_NO_ACTIVE_POLICIES == "synthetic:NO_ACTIVE_POLICIES"
    assert SYNTHETIC_BUNDLE_MISSING == "synthetic:BUNDLE_MISSING"
    assert SYNTHETIC_RESOURCE_GATE_SKIP == "synthetic:RESOURCE_GATE_SKIP"
    assert SYNTHETIC_QUARANTINE == "synthetic:QUARANTINE"
    assert SYNTHETIC_ENGINE_UNAVAILABLE == "synthetic:ENGINE_UNAVAILABLE"


def test_valid_synthetic_set_is_exactly_six_values():
    """Six was the spec: NO_RULE_MATCH, NO_ACTIVE_POLICIES,
    BUNDLE_MISSING, RESOURCE_GATE_SKIP, QUARANTINE, ENGINE_UNAVAILABLE.
    Adding a seventh is intentional but should require updating the
    frontend chip metadata table at the same time.
    """
    assert len(VALID_SYNTHETIC_POLICY_IDS) == 6
    assert VALID_SYNTHETIC_POLICY_IDS == frozenset({
        "synthetic:NO_RULE_MATCH",
        "synthetic:NO_ACTIVE_POLICIES",
        "synthetic:BUNDLE_MISSING",
        "synthetic:RESOURCE_GATE_SKIP",
        "synthetic:QUARANTINE",
        "synthetic:ENGINE_UNAVAILABLE",
    })


def test_all_synthetic_ids_carry_canonical_prefix():
    """Frontend renders chips by `policy_id.startswith("synthetic:")`.
    A regression that emits a sentinel without the prefix would fall
    through to the plain text rendering and re-create the original
    "blank Policy column" bug from the incident.
    """
    for value in VALID_SYNTHETIC_POLICY_IDS:
        assert value.startswith(SYNTHETIC_POLICY_ID_PREFIX), value


# ---- evaluator no-match path ---------------------------------------------


def test_no_rule_match_stamps_synthetic_NO_RULE_MATCH():
    """When the bundle loaded cleanly but no rule matched, the
    PolicyDecision MUST carry policy_id=synthetic:NO_RULE_MATCH so
    the audit row is distinguishable from a user-rule-deny on the
    dashboard.
    """
    parsed = load_policy({
        "version": "1",
        "rules": [{"effect": "allow", "action": "safe_tool", "reason": "ok"}],
    })
    ev = PolicyEvaluator(parsed.rules)
    decision = ev.evaluate(tool="other_tool", method="*")
    assert decision.effect == "deny"
    assert decision.policy_id == SYNTHETIC_NO_RULE_MATCH
    assert decision.reason_code == "NO_RULE_MATCH"


def test_resource_gate_skip_distinguished_from_generic_no_match():
    """The T83-class signature: a rule's actions list matched the
    call but its `resources:` list excluded it. The generic
    NO_RULE_MATCH chip would mislead operators because the
    remediation is completely different ("fix the resources gate"
    vs "add a new rule").
    """
    # Rule's actions match "delete_file:*" but the resources gate
    # restricts to "/safe/*" -- a call without context.resource (or
    # to /unsafe/*) skips the rule purely on the resource gate.
    parsed = load_policy({
        "version": "1",
        "rules": [{
            "effect": "allow",
            "action": "delete_file",
            "resources": ["/safe/*"],
            "reason": "only safe path is allowed",
        }],
    })
    ev = PolicyEvaluator(parsed.rules)
    decision = ev.evaluate(
        tool="delete_file",
        method="*",
        context={"resource": "/unsafe/secret.key"},
    )
    assert decision.effect == "deny"
    # CRITICAL: this is the new sentinel that lets ops tell "your
    # rule's resources list excluded this call" apart from "no rule
    # at all matched". Without it, the operator would chase the
    # wrong bug class.
    assert decision.policy_id == SYNTHETIC_RESOURCE_GATE_SKIP


def test_resource_gate_skip_does_not_fire_when_action_does_not_match():
    """If NO rule's actions matched the call at all, the deny is
    NO_RULE_MATCH, not RESOURCE_GATE_SKIP. The latter requires that
    SOME rule's actions matched but its resources gate vetoed it.
    """
    parsed = load_policy({
        "version": "1",
        "rules": [{
            "effect": "allow",
            "action": "totally_different_tool",
            "resources": ["/safe/*"],
            "reason": "ok",
        }],
    })
    ev = PolicyEvaluator(parsed.rules)
    decision = ev.evaluate(
        tool="delete_file",
        method="*",
        context={"resource": "/unsafe/secret.key"},
    )
    assert decision.effect == "deny"
    assert decision.policy_id == SYNTHETIC_NO_RULE_MATCH


def test_resource_gate_skip_only_fires_under_default_deny():
    """When default_action=allow, a no-match path is not a deny so
    the synthetic NO_RULE_MATCH/RESOURCE_GATE_SKIP distinction does
    not matter (the chip is only relevant on Decision=Deny rows).
    The sentinel still falls back to NO_RULE_MATCH for consistency.
    """
    parsed = load_policy({
        "version": "1",
        "settings": {"default_action": "allow"},
        "rules": [{
            "effect": "deny",
            "action": "delete_file",
            "resources": ["/safe/*"],
            "reason": "block deletes in safe",
        }],
    })
    # Honour the parsed settings on the evaluator so default_action=allow
    # actually takes effect. (The Client wires this up automatically;
    # the test exercises the lower-level construction path.)
    ev = PolicyEvaluator(parsed.rules, default_action=parsed.settings.default_action)
    decision = ev.evaluate(
        tool="delete_file",
        method="*",
        context={"resource": "/unsafe/x"},
    )
    # Allowed because default_action=allow, so this is not a synthetic
    # deny we need to chip-decorate. The id falls back to the
    # generic sentinel.
    assert decision.effect == "allow"
    assert decision.policy_id == SYNTHETIC_NO_RULE_MATCH


# ---- empty bundle (NO_ACTIVE_POLICIES) ------------------------------------


def test_empty_bundle_synthetic_rule_carries_synthetic_id():
    """The translator emits a single deny-all rule with
    `id=synthetic:NO_ACTIVE_POLICIES` so policy_loader carries it
    through to PolicyRule.id, and the evaluator stamps it on the
    decision's policy_id.
    """
    local = translate_to_local_policy({"policies": []})
    rules = local["rules"]
    assert len(rules) == 1
    assert rules[0].get("id") == SYNTHETIC_NO_ACTIVE_POLICIES
    assert rules[0].get("reason_code") == "NO_ACTIVE_POLICIES"


def test_empty_bundle_roundtrip_to_decision_carries_synthetic_id():
    """End-to-end: the audit row policy_id MUST be
    synthetic:NO_ACTIVE_POLICIES when the bundle was empty.
    """
    local = translate_to_local_policy({"policies": []})
    parsed = load_policy(local)
    ev = PolicyEvaluator(parsed.rules)
    decision = ev.evaluate(tool="anything", method="*")
    assert decision.effect == "deny"
    assert decision.policy_id == SYNTHETIC_NO_ACTIVE_POLICIES
    assert decision.reason_code == "NO_ACTIVE_POLICIES"


# ---- BUNDLE_MISSING -------------------------------------------------------


def test_make_bundle_missing_policy_carries_synthetic_id():
    """The synthetic missing-bundle rule must carry
    id=synthetic:BUNDLE_MISSING so audit rows for "no bundle on
    disk" link to the right troubleshooting anchor.
    """
    pol = make_bundle_missing_policy()
    rule = pol["rules"][0]
    assert rule["id"] == SYNTHETIC_BUNDLE_MISSING
    assert rule["reason_code"] == "BUNDLE_MISSING"


def test_make_bundle_missing_policy_roundtrip_to_decision():
    """End-to-end: PolicyDecision carries policy_id=synthetic:BUNDLE_MISSING
    when the SDK fell into the missing-bundle path.
    """
    pol = make_bundle_missing_policy(default_on_missing="deny")
    parsed = load_policy(pol)
    ev = PolicyEvaluator(parsed.rules)
    decision = ev.evaluate(tool="anything", method="*")
    assert decision.effect == "deny"
    assert decision.policy_id == SYNTHETIC_BUNDLE_MISSING


# ---- forward-compat: backend audit ingest stores synthetic:* verbatim -----


def test_synthetic_id_does_not_match_real_policy_id_format():
    """Real policy_ids are bare strings (e.g. "p_01HXY..."). The
    synthetic:* prefix is reserved so the backend audit ingest can
    pass it through without confusion AND the dashboard can branch
    on the prefix safely. A regression that uses a colon-bearing id
    for a real policy would clash.
    """
    for sid in VALID_SYNTHETIC_POLICY_IDS:
        # Just sanity-check the shape: prefix:WORD with no extra colons
        # in the suffix segment.
        assert sid.count(":") == 1
        suffix = sid.split(":", 1)[1]
        assert suffix.isupper() or "_" in suffix


# ---- prefix helper --------------------------------------------------------


@pytest.mark.parametrize("value,expected", [
    (SYNTHETIC_NO_RULE_MATCH, True),
    (SYNTHETIC_NO_ACTIVE_POLICIES, True),
    (SYNTHETIC_BUNDLE_MISSING, True),
    (SYNTHETIC_RESOURCE_GATE_SKIP, True),
    (SYNTHETIC_QUARANTINE, True),
    (SYNTHETIC_ENGINE_UNAVAILABLE, True),
    ("p_01HXY", False),
    ("", False),
    (None, False),
])
def test_is_synthetic_helper_pattern(value, expected):
    """Frontend ships an `isSyntheticPolicyId` helper that branches
    on the prefix. The Python equivalent is just a string
    startswith() check; pin the contract here so any future helper
    refactor in either language stays in sync.
    """
    if value is None:
        assert not isinstance(value, str)
        return
    assert isinstance(value, str)
    assert value.startswith(SYNTHETIC_POLICY_ID_PREFIX) is expected
