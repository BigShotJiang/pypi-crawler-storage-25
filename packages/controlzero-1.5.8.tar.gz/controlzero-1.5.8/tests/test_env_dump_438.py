"""Regression tests for `controlzero env-dump` (#438).

Filed as a follow-up to the 2026-05-12 hook-decision regression where
source-detection on Windows took multiple rounds because we had no way
to ask the customer "what env vars does YOUR hook subprocess see?"

The subcommand prints a JSON snapshot of the SDK's effective
environment: env vars (redacted by default), host-adapter selection,
file inventory, API URL. \`--from-hook\` reads a stdin payload so the
output reflects what the hook subprocess would resolve.
"""

from __future__ import annotations

import json

from click.testing import CliRunner

from controlzero.cli.main import cli


def _invoke(args, env=None, input=None):
    # CliRunner version-portable: the `mix_stderr=False` parameter was
    # removed in newer click releases. Tests instead use
    # _extract_json() below to slice the JSON payload out of the
    # combined output, ignoring any WARNING preamble from
    # --show-secrets.
    runner = CliRunner(env=env)
    return runner.invoke(cli, ["env-dump", *args], input=input)


def _extract_json(output: str) -> dict:
    """Slice the JSON object out of mixed stdout/stderr output.

    The env-dump JSON always starts with `{` on its own line and ends
    with `}` on its own line; any WARNING prefix from --show-secrets
    lives above. We grab from the first `{` to the last `}`.
    """
    start = output.find("{")
    end = output.rfind("}")
    if start < 0 or end < 0 or end < start:
        raise AssertionError(f"no JSON envelope found in output: {output!r}")
    return json.loads(output[start : end + 1])


def test_env_dump_outputs_valid_json(monkeypatch):
    monkeypatch.delenv("CONTROLZERO_CLIENT", raising=False)
    result = _invoke([])
    assert result.exit_code == 0, result.output
    data = _extract_json(result.output)
    assert "controlzero_version" in data
    assert "hostname" in data
    assert "api_url" in data
    assert data["api_url"].startswith("http")
    assert "adapter" in data
    assert data["adapter"]["name"] in (
        "claude_code",
        "gemini_cli",
        "codex_cli",
        "unknown",
    )
    assert "env" in data
    assert data["show_secrets"] is False


def test_env_dump_redacts_api_key_by_default(monkeypatch):
    monkeypatch.setenv(
        "CONTROLZERO_API_KEY",
        "cz_live_aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
    )
    result = _invoke([])
    assert result.exit_code == 0
    data = _extract_json(result.output)
    masked = data["env"]["CONTROLZERO_API_KEY"]
    assert masked == "cz_live_***"
    # Defensive: the secret bytes MUST NOT appear anywhere in the dump.
    secret_tail = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
    assert secret_tail not in result.output


def test_env_dump_redacts_test_key_prefix(monkeypatch):
    monkeypatch.setenv("CONTROLZERO_API_KEY", "cz_test_abcdef1234567890")
    result = _invoke([])
    data = _extract_json(result.output)
    assert data["env"]["CONTROLZERO_API_KEY"] == "cz_test_***"


def test_env_dump_redacts_generic_secret_envvars(monkeypatch):
    monkeypatch.setenv("MY_SERVICE_TOKEN", "super-secret-value")
    monkeypatch.setenv("DB_PASSWORD", "abc123")
    monkeypatch.setenv("STRIPE_API_KEY", "sk_live_supersecret")
    result = _invoke([])
    data = _extract_json(result.output)
    for k in ("MY_SERVICE_TOKEN", "DB_PASSWORD", "STRIPE_API_KEY"):
        v = data["env"][k]
        assert v.startswith("<REDACTED-LEN"), f"{k} not redacted: {v!r}"


def test_env_dump_show_secrets_unredacts(monkeypatch):
    monkeypatch.setenv("MY_SERVICE_TOKEN", "super-secret-value")
    result = _invoke(["--show-secrets"])
    data = _extract_json(result.output)
    assert data["env"]["MY_SERVICE_TOKEN"] == "super-secret-value"
    assert data["show_secrets"] is True
    # Always-on warning when secrets are shown -- lives in stderr,
    # NOT stdout (so a downstream `jq` pipe still works).
    # WARNING goes to stderr but CliRunner mixes streams; the JSON
    # extractor strips it from the parsed data, but it still shows
    # in the combined `result.output` string.
    assert "WARNING" in result.output


def test_env_dump_from_hook_picks_right_adapter(monkeypatch):
    monkeypatch.delenv("CONTROLZERO_CLIENT", raising=False)
    monkeypatch.delenv("CLAUDECODE", raising=False)

    # Claude Code's stdin signature:
    payload = json.dumps({
        "session_id": "01HX9Z6R3W6XAMPLE",
        "transcript_path": "/Users/x/.claude/transcripts/abc.jsonl",
        "cwd": "/Users/x/project",
        "tool_name": "Write",
        "tool_input": {"file_path": "/tmp/maruthi"},
        "hook_event_name": "PreToolUse",
    })
    result = _invoke(["--from-hook"], input=payload)
    assert result.exit_code == 0
    data = _extract_json(result.output)
    assert data["adapter"]["name"] == "claude_code"
    assert "session_id" in data["from_hook_payload_keys"]
    assert "tool_input" in data["from_hook_payload_keys"]


def test_env_dump_lists_settings_files_without_revealing_contents(tmp_path, monkeypatch):
    monkeypatch.setenv("HOME", str(tmp_path))
    claude_settings = tmp_path / ".claude" / "settings.json"
    claude_settings.parent.mkdir(parents=True)
    claude_settings.write_text('{"hooks":{}}')

    result = _invoke([])
    data = _extract_json(result.output)
    entry = data["files"].get(str(claude_settings))
    assert entry is not None
    assert entry["exists"] is True
    assert entry["size_bytes"] > 0
    assert "mtime_iso" in entry
    # File CONTENTS must NOT be in the dump.
    assert '"hooks":{}' not in result.output
