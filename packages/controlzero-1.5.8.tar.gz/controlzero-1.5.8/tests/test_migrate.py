"""Unit tests for controlzero.cli.migrate (Tier 0a hotfix 2026-05-15)."""

from __future__ import annotations

import json
import os
import stat
from pathlib import Path
from unittest import mock

import pytest
import yaml

from controlzero.cli.migrate import (
    _extract_first_key,
    _rewrite_text,
    _write_config_key,
    run_migrate,
)


class TestRewriteText:
    def test_strips_inline_key_from_hook(self) -> None:
        text = (
            '{"hooks": {"PreToolUse": [{"command": '
            '"CONTROLZERO_API_KEY=cz_live_aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa controlzero hook-check"}]}}'
        )
        new_text, rewrites = _rewrite_text(text)
        assert "cz_live_aaaa" not in new_text
        assert '"command": "controlzero hook-check"' in new_text
        assert len(rewrites) == 1
        # The rewrite summary itself uses the redacted form.
        assert "cz_live_***" in rewrites[0].before_snippet

    def test_idempotent_on_clean_text(self) -> None:
        text = '{"command": "controlzero hook-check"}'
        new_text, rewrites = _rewrite_text(text)
        assert new_text == text
        assert rewrites == []

    def test_handles_multiple_leaks(self) -> None:
        text = (
            'a CONTROLZERO_API_KEY=cz_live_aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa controlzero hook-check b\n'
            'c CONTROLZERO_API_KEY=cz_test_bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb controlzero hook-check d'
        )
        new_text, rewrites = _rewrite_text(text)
        assert len(rewrites) == 2
        assert "cz_live_aaaa" not in new_text
        assert "cz_test_bbbb" not in new_text

    def test_preserves_hook_tail_flags(self) -> None:
        text = "CONTROLZERO_API_KEY=cz_live_abcdefghijklmnop controlzero hook-check --policy /x/y.yaml"
        new_text, _ = _rewrite_text(text)
        assert new_text == "controlzero hook-check --policy /x/y.yaml"


class TestExtractFirstKey:
    def test_returns_first_key_in_text(self) -> None:
        text = "CONTROLZERO_API_KEY=cz_live_aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa controlzero"
        assert _extract_first_key(text) == "cz_live_aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"

    def test_none_on_no_match(self) -> None:
        assert _extract_first_key("nothing here") is None


class TestWriteConfigKey:
    def test_creates_dir_and_file(self, tmp_path: Path) -> None:
        with mock.patch("pathlib.Path.home", return_value=tmp_path):
            cfg_path = _write_config_key("cz_live_abcdefghijklmnop")
        assert cfg_path.exists()
        loaded = yaml.safe_load(cfg_path.read_text(encoding="utf-8"))
        assert loaded["api_key"] == "cz_live_abcdefghijklmnop"

    @pytest.mark.skipif(os.name == "nt", reason="POSIX perms only")
    def test_sets_0600_on_file_0700_on_dir(self, tmp_path: Path) -> None:
        with mock.patch("pathlib.Path.home", return_value=tmp_path):
            cfg_path = _write_config_key("cz_live_abcdefghijklmnop")
        file_mode = stat.S_IMODE(cfg_path.stat().st_mode)
        dir_mode = stat.S_IMODE(cfg_path.parent.stat().st_mode)
        assert file_mode == 0o600
        assert dir_mode == 0o700

    def test_idempotent_overwrite(self, tmp_path: Path) -> None:
        with mock.patch("pathlib.Path.home", return_value=tmp_path):
            _write_config_key("cz_live_first")
            _write_config_key("cz_live_second")
            cfg_path = tmp_path / ".controlzero" / "config.yaml"
        loaded = yaml.safe_load(cfg_path.read_text(encoding="utf-8"))
        assert loaded["api_key"] == "cz_live_second"


class TestRunMigrate:
    def test_clean_machine_returns_zero(self, tmp_path: Path) -> None:
        with mock.patch("pathlib.Path.home", return_value=tmp_path):
            assert run_migrate(dry_run=False) == 0

    def test_dry_run_does_not_modify_files(self, tmp_path: Path) -> None:
        claude_dir = tmp_path / ".claude"
        claude_dir.mkdir()
        settings = claude_dir / "settings.json"
        original = json.dumps({
            "hooks": {"PreToolUse": [{
                "command": "CONTROLZERO_API_KEY=cz_live_aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa controlzero hook-check"
            }]}
        })
        settings.write_text(original)
        with mock.patch("pathlib.Path.home", return_value=tmp_path):
            assert run_migrate(dry_run=True) == 0
        assert settings.read_text() == original  # untouched

    def test_real_run_rewrites_file_and_persists_key(self, tmp_path: Path) -> None:
        claude_dir = tmp_path / ".claude"
        claude_dir.mkdir()
        settings = claude_dir / "settings.json"
        settings.write_text(json.dumps({
            "hooks": {"PreToolUse": [{
                "command": "CONTROLZERO_API_KEY=cz_live_aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa controlzero hook-check"
            }]}
        }))
        with mock.patch("pathlib.Path.home", return_value=tmp_path):
            assert run_migrate(dry_run=False) == 0
        # The settings file no longer contains the inline key.
        after = settings.read_text()
        assert "cz_live_aaaa" not in after
        assert "controlzero hook-check" in after
        # The key was persisted to the config file.
        cfg = yaml.safe_load((tmp_path / ".controlzero" / "config.yaml").read_text())
        assert cfg["api_key"].startswith("cz_live_")
