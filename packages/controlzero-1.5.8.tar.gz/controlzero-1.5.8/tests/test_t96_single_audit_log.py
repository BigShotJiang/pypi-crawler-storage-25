"""Regression tests for T96 -- single-file local audit log (1.5.4).

Before 1.5.4 the SDK wrote decision rows to ``~/.controlzero/audit.log``
and lifecycle events (carve-out, hook errors) to a separate
``~/.controlzero/events.log``. Two log paths confused customers and
``cz debug bundle`` had to merge both.

After 1.5.4 ``_append_event()`` writes to ``audit.log`` directly. The
T101 migration shim (1.5.5) folds any legacy ``events.log`` into
``audit.log`` on first run, so the dual-read grace window in ``status``
is no longer needed -- the shim guarantees the legacy file is gone by
the time any subcommand executes.
"""

from __future__ import annotations

import json


import controlzero.cli.main as cli_main


def test_append_event_writes_to_audit_log_not_events_log(tmp_path, monkeypatch):
    audit_path = tmp_path / "audit.log"
    events_path = tmp_path / "events.log"
    monkeypatch.setattr(cli_main, "GLOBAL_POLICY_DIR", tmp_path)
    monkeypatch.setattr(cli_main, "GLOBAL_AUDIT_PATH", audit_path)
    monkeypatch.setattr(cli_main, "GLOBAL_EVENTS_PATH", events_path)

    cli_main._append_event({
        "event": "unenrolled_first_run_allow",
        "tool_name": "Bash",
        "reason_code": "RULE_MATCH",
        "ts": 1715000000.0,
    })

    # T96 invariant: writes land in audit.log, NOT events.log.
    assert audit_path.exists(), "audit.log should exist after _append_event"
    assert not events_path.exists(), (
        "events.log MUST NOT be created by 1.5.4 -- T96 collapsed the "
        "two log files into one"
    )

    lines = audit_path.read_text().splitlines()
    assert len(lines) == 1
    parsed = json.loads(lines[0])
    assert parsed["event"] == "unenrolled_first_run_allow"
    assert parsed["tool_name"] == "Bash"


def test_status_reads_carve_out_events_from_audit_log(tmp_path, monkeypatch):
    # Status pulls carve-out lifecycle events out of audit.log. Pre-1.5.4
    # they lived in events.log; the status command now sees them in
    # audit.log because _append_event writes there.
    audit_path = tmp_path / "audit.log"
    events_path = tmp_path / "events.log"
    monkeypatch.setattr(cli_main, "GLOBAL_POLICY_DIR", tmp_path)
    monkeypatch.setattr(cli_main, "GLOBAL_AUDIT_PATH", audit_path)
    monkeypatch.setattr(cli_main, "GLOBAL_EVENTS_PATH", events_path)

    # Mix decision rows + lifecycle rows in audit.log (the post-1.5.4
    # reality). Status must filter to the carve-out rows only.
    audit_path.write_text("\n".join([
        json.dumps({"decision": "allow", "tool": "Read", "ts": 1.0}),
        json.dumps({"event": "unenrolled_first_run_allow", "tool_name": "Bash", "ts": 2.0}),
        json.dumps({"decision": "deny", "tool": "Write", "ts": 3.0}),
        json.dumps({"event": "unenrolled_first_run_allow", "tool_name": "Edit", "ts": 4.0}),
    ]) + "\n")

    from click.testing import CliRunner

    runner = CliRunner()
    result = runner.invoke(cli_main.cli, ["status"])
    assert result.exit_code == 0
    assert "carve-out allows: 2" in result.output


def test_status_surfaces_pre_1_5_4_history_via_migration_shim(
    tmp_path, monkeypatch
):
    # Users upgrading from <= 1.5.3 land here with carve-out history
    # in events.log. T101's layout-migration shim folds those rows
    # into audit.log before any subcommand runs, so by the time
    # status_cmd reads audit.log it sees both the legacy and the
    # post-upgrade rows.
    audit_path = tmp_path / "audit.log"
    events_path = tmp_path / "events.log"
    monkeypatch.setattr(cli_main, "GLOBAL_POLICY_DIR", tmp_path)
    monkeypatch.setattr(cli_main, "GLOBAL_AUDIT_PATH", audit_path)
    monkeypatch.setattr(cli_main, "GLOBAL_EVENTS_PATH", events_path)

    # Pre-1.5.4 history lives in events.log:
    events_path.write_text(
        json.dumps(
            {"event": "unenrolled_first_run_allow", "tool_name": "LegacyBash", "ts": 1.0}
        )
        + "\n"
    )
    # Post-upgrade row lands in audit.log:
    audit_path.write_text(
        json.dumps(
            {"event": "unenrolled_first_run_allow", "tool_name": "Bash", "ts": 2.0}
        )
        + "\n"
    )

    from click.testing import CliRunner

    runner = CliRunner()
    result = runner.invoke(cli_main.cli, ["status"])
    assert result.exit_code == 0
    # Both rows surface in the summary count.
    assert "carve-out allows: 2" in result.output


def test_append_event_silently_swallows_disk_errors(tmp_path, monkeypatch):
    # The "never brick the agent" guarantee: if the audit.log open
    # fails (read-only volume, full disk, perm denied), _append_event
    # must NOT raise.
    bad_path = tmp_path / "definitely-not-writable" / "audit.log"
    monkeypatch.setattr(cli_main, "GLOBAL_POLICY_DIR", tmp_path / "no-dir")
    monkeypatch.setattr(cli_main, "GLOBAL_AUDIT_PATH", bad_path)

    # Should not raise even though the directory can't be created in
    # some scenarios; the function is best-effort.
    cli_main._append_event({"event": "x"})
