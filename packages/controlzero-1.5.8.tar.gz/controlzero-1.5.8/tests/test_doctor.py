"""Unit tests for controlzero.cli.doctor (Tier 0a hotfix 2026-05-15)."""

from __future__ import annotations

import json
import os
from pathlib import Path
from unittest import mock

import pytest

from controlzero.cli.doctor import (
    Finding,
    _AgentPath,
    _check_agent_key_leaks,
    _check_config_permissions,
    _check_global_environment,
    run_doctor,
)


def _ap(tmp_path: Path, name: str, content: str) -> _AgentPath:
    """Create a fake agent settings file under tmp_path, return its
    _AgentPath shape for the leak scanner."""
    p = tmp_path / name
    p.write_text(content, encoding="utf-8")
    return _AgentPath(agent="test-agent", path=p, note="test hook")


class TestCheckAgentKeyLeaks:
    def test_no_leak_returns_empty(self, tmp_path: Path) -> None:
        ap = _ap(tmp_path, "settings.json",
                 json.dumps({"hooks": {"PreToolUse": [{"command": "controlzero hook-check"}]}}))
        assert _check_agent_key_leaks([ap]) == []

    def test_finds_live_key_leak(self, tmp_path: Path) -> None:
        content = json.dumps({
            "hooks": {"PreToolUse": [{"command": "CONTROLZERO_API_KEY=cz_live_aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa controlzero hook-check"}]}
        })
        ap = _ap(tmp_path, "settings.json", content)
        findings = _check_agent_key_leaks([ap])
        assert len(findings) == 1
        f = findings[0]
        assert f.severity == "ERROR"
        assert f.code == "E1001"
        assert "cz_live_***" in f.message  # redacted, not raw
        assert "cz_live_aaaa" not in f.message

    def test_finds_test_key_leak(self, tmp_path: Path) -> None:
        content = "cmd: CONTROLZERO_API_KEY=cz_test_aaaaaaaaaaaaaaaaaaaaaaaa controlzero hook-check"
        ap = _ap(tmp_path, "config.toml", content)
        findings = _check_agent_key_leaks([ap])
        assert len(findings) == 1
        assert findings[0].code == "E1001"

    def test_skips_missing_files(self) -> None:
        ap = _AgentPath(agent="absent", path=Path("/tmp/does-not-exist-xyz"),
                        note="hook")
        assert _check_agent_key_leaks([ap]) == []

    def test_unreadable_file_emits_warn(self, tmp_path: Path) -> None:
        ap = _ap(tmp_path, "settings.json", "foo")
        ap.path.chmod(0o000)
        try:
            findings = _check_agent_key_leaks([ap])
            # Either we got a WARN (read failed) or the file was readable
            # anyway and we got nothing. Both acceptable; never raised.
            for f in findings:
                assert f.severity in ("WARN", "ERROR")
        finally:
            ap.path.chmod(0o644)


class TestCheckConfigPermissions:
    def test_no_findings_when_perms_correct(self, tmp_path: Path) -> None:
        cfg_dir = tmp_path / ".controlzero"
        cfg_dir.mkdir(mode=0o700)
        cfg = cfg_dir / "config.yaml"
        cfg.write_text("api_key: x")
        cfg.chmod(0o600)
        with mock.patch("pathlib.Path.home", return_value=tmp_path):
            findings = _check_config_permissions()
        assert findings == []

    @pytest.mark.skipif(os.name == "nt", reason="POSIX-only perms check")
    def test_world_readable_config_emits_error(self, tmp_path: Path) -> None:
        cfg_dir = tmp_path / ".controlzero"
        cfg_dir.mkdir(mode=0o700)
        cfg = cfg_dir / "config.yaml"
        cfg.write_text("api_key: x")
        cfg.chmod(0o644)  # world-readable -- BAD
        with mock.patch("pathlib.Path.home", return_value=tmp_path):
            findings = _check_config_permissions()
        codes = [f.code for f in findings]
        assert "E1003" in codes


class TestCheckGlobalEnvironment:
    def test_key_in_shell_history_emits_warn(self, tmp_path: Path) -> None:
        hist = tmp_path / ".bash_history"
        hist.write_text("export CONTROLZERO_API_KEY=cz_live_abcd1234567890\n")
        with mock.patch("pathlib.Path.home", return_value=tmp_path):
            findings = _check_global_environment()
        assert any(f.code == "E1004" for f in findings)

    def test_clean_history_returns_empty(self, tmp_path: Path) -> None:
        hist = tmp_path / ".bash_history"
        hist.write_text("ls\ncd\necho hello\n")
        with mock.patch("pathlib.Path.home", return_value=tmp_path):
            findings = _check_global_environment()
        assert findings == []


class TestRunDoctor:
    def test_clean_machine_exits_zero(self, tmp_path: Path) -> None:
        with mock.patch("pathlib.Path.home", return_value=tmp_path):
            code = run_doctor(verbose=False)
        assert code == 0

    def test_leaked_settings_exit_one(self, tmp_path: Path) -> None:
        claude_dir = tmp_path / ".claude"
        claude_dir.mkdir()
        (claude_dir / "settings.json").write_text(
            json.dumps({
                "hooks": {"PreToolUse": [{
                    "command": "CONTROLZERO_API_KEY=cz_live_aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa controlzero hook-check"
                }]}
            })
        )
        with mock.patch("pathlib.Path.home", return_value=tmp_path):
            code = run_doctor(verbose=False)
        assert code == 1


class TestFindingRender:
    def test_render_includes_severity_and_code(self) -> None:
        f = Finding(
            path="/x/y.json",
            line=42,
            col=5,
            severity="ERROR",
            code="E1001",
            message="test message",
            fix_hint="do the thing",
        )
        out = f.render()
        assert "/x/y.json:42:5" in out
        assert "ERROR[E1001]" in out
        assert "test message" in out
        assert "fix: do the thing" in out
