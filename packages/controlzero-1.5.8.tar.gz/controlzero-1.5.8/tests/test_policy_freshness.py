"""Tests for policy freshness check in hook-check (finding #4 fix).

Coverage matrix:
  - Enrolled + stale policy + network available -> policy refreshed
  - Enrolled + stale policy + network timeout -> uses cached, warns
  - Enrolled + fresh policy -> no network call
  - Not enrolled -> no network call
  - enrollment.json missing -> no network call
  - enrollment.json malformed -> no network call (fail-open)
"""

from __future__ import annotations

import os
import time
from pathlib import Path
from typing import Optional
from unittest.mock import MagicMock, patch

import yaml

from controlzero.enrollment import EnrollmentState, save_state


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_enrollment_state(
    state_dir: Path,
    org_id: str = "org_123",
    api_url: str = "https://api.controlzero.ai",
) -> EnrollmentState:
    """Write a valid enrollment.json and return the state."""
    state = EnrollmentState(
        machine_id="mach_abc",
        org_id=org_id,
        api_url=api_url,
        hostname="test-host",
        fingerprint_hint="deadbeef" * 4,
        machine_pubkey_pem="-----BEGIN PUBLIC KEY-----\nfake\n-----END PUBLIC KEY-----\n",
        enrolled_at="2026-01-01T00:00:00Z",
        policy_version=1,
    )
    save_state(state, state_dir)
    return state


def _write_policy(policy_path: Path, rules: Optional[list] = None) -> None:
    """Write a minimal policy YAML file."""
    if rules is None:
        rules = [{"allow": "*"}]
    policy_path.write_text(
        yaml.safe_dump({"version": "1", "rules": rules}),
        encoding="utf-8",
    )


def _age_file(path: Path, age_seconds: float) -> None:
    """Backdate a file's mtime by *age_seconds*."""
    t = time.time() - age_seconds
    os.utime(path, (t, t))


# ---------------------------------------------------------------------------
# _is_policy_stale
# ---------------------------------------------------------------------------

class TestIsPolicyStale:
    def test_fresh_file_is_not_stale(self, tmp_path):
        from controlzero.cli.main import _is_policy_stale
        p = tmp_path / "policy.yaml"
        _write_policy(p)
        assert _is_policy_stale(p, threshold_s=300) is False

    def test_old_file_is_stale(self, tmp_path):
        from controlzero.cli.main import _is_policy_stale
        p = tmp_path / "policy.yaml"
        _write_policy(p)
        _age_file(p, 600)
        assert _is_policy_stale(p, threshold_s=300) is True

    def test_missing_file_is_stale(self, tmp_path):
        from controlzero.cli.main import _is_policy_stale
        p = tmp_path / "nonexistent.yaml"
        assert _is_policy_stale(p, threshold_s=300) is True


# ---------------------------------------------------------------------------
# _load_enrollment_state
# ---------------------------------------------------------------------------

class TestLoadEnrollmentState:
    def test_returns_state_when_enrolled(self, tmp_path):
        from controlzero.cli.main import _load_enrollment_state
        _make_enrollment_state(tmp_path)
        state = _load_enrollment_state(tmp_path)
        assert state is not None
        assert state.org_id == "org_123"

    def test_returns_none_when_no_file(self, tmp_path):
        from controlzero.cli.main import _load_enrollment_state
        assert _load_enrollment_state(tmp_path) is None

    def test_returns_none_when_malformed(self, tmp_path):
        from controlzero.cli.main import _load_enrollment_state
        (tmp_path / "enrollment.json").write_text("{bad json", encoding="utf-8")
        assert _load_enrollment_state(tmp_path) is None

    def test_returns_none_when_missing_org_id(self, tmp_path):
        from controlzero.cli.main import _load_enrollment_state
        _make_enrollment_state(tmp_path, org_id="")
        assert _load_enrollment_state(tmp_path) is None

    def test_returns_none_when_missing_api_url(self, tmp_path):
        from controlzero.cli.main import _load_enrollment_state
        _make_enrollment_state(tmp_path, api_url="")
        assert _load_enrollment_state(tmp_path) is None


# ---------------------------------------------------------------------------
# _maybe_refresh_policy -- integration-level
# ---------------------------------------------------------------------------

class TestMaybeRefreshPolicy:
    """Test the full _maybe_refresh_policy function with mocked network."""

    def test_enrolled_stale_network_ok_refreshes(self, tmp_path, capsys):
        """Enrolled + stale policy + network returns new bundle -> file updated."""
        from controlzero.cli.main import _maybe_refresh_policy

        state = _make_enrollment_state(tmp_path)
        policy_path = tmp_path / "policy.yaml"
        _write_policy(policy_path, [{"allow": "*"}])
        _age_file(policy_path, 600)

        new_bundle = {
            "version": "1",
            "policy_version": 2,
            "rules": [{"deny": "Bash", "reason": "updated from backend"}],
        }

        with patch("controlzero.cli.main._load_enrollment_state", return_value=state):
            with patch("controlzero.enrollment.pull_policy", return_value=new_bundle):
                _maybe_refresh_policy(policy_path, state_dir=tmp_path, threshold_s=300, timeout_s=5.0)

        content = yaml.safe_load(policy_path.read_text(encoding="utf-8"))
        assert len(content["rules"]) == 1
        assert content["rules"][0]["deny"] == "Bash"
        # No warning should have been emitted
        captured = capsys.readouterr()
        assert "stale" not in captured.err
        assert "timed out" not in captured.err

    def test_enrolled_stale_304_touches_file(self, tmp_path, capsys):
        """Enrolled + stale + backend returns 304 -> file mtime updated."""
        from controlzero.cli.main import _maybe_refresh_policy

        state = _make_enrollment_state(tmp_path)
        policy_path = tmp_path / "policy.yaml"
        _write_policy(policy_path, [{"allow": "*"}])
        _age_file(policy_path, 600)
        old_mtime = os.path.getmtime(policy_path)

        with patch("controlzero.cli.main._load_enrollment_state", return_value=state):
            with patch("controlzero.enrollment.pull_policy", return_value=None):
                _maybe_refresh_policy(policy_path, state_dir=tmp_path, threshold_s=300, timeout_s=5.0)

        new_mtime = os.path.getmtime(policy_path)
        assert new_mtime > old_mtime

    def test_enrolled_stale_network_error_warns(self, tmp_path, capsys):
        """Enrolled + stale + pull_policy raises -> use cached, warn once."""
        from controlzero.cli.main import _maybe_refresh_policy

        state = _make_enrollment_state(tmp_path)
        policy_path = tmp_path / "policy.yaml"
        _write_policy(policy_path, [{"allow": "*"}])
        original_content = policy_path.read_text(encoding="utf-8")
        _age_file(policy_path, 600)

        def _raise(*a, **kw):
            raise ConnectionError("network down")

        with patch("controlzero.cli.main._load_enrollment_state", return_value=state):
            with patch("controlzero.enrollment.pull_policy", side_effect=_raise):
                _maybe_refresh_policy(policy_path, state_dir=tmp_path, threshold_s=300, timeout_s=5.0)

        # Policy file should be unchanged
        assert policy_path.read_text(encoding="utf-8") == original_content
        captured = capsys.readouterr()
        assert "stale" in captured.err or "cached" in captured.err

    def test_enrolled_stale_network_timeout_warns(self, tmp_path, capsys):
        """Enrolled + stale + pull_policy hangs -> timeout, use cached, warn."""
        from controlzero.cli.main import _maybe_refresh_policy

        state = _make_enrollment_state(tmp_path)
        policy_path = tmp_path / "policy.yaml"
        _write_policy(policy_path, [{"allow": "*"}])
        original_content = policy_path.read_text(encoding="utf-8")
        _age_file(policy_path, 600)

        def _hang(*a, **kw):
            # Block for much longer than the timeout
            import time as _time
            _time.sleep(10)
            return {"version": "1", "rules": []}

        with patch("controlzero.cli.main._load_enrollment_state", return_value=state):
            with patch("controlzero.enrollment.pull_policy", side_effect=_hang):
                _maybe_refresh_policy(policy_path, state_dir=tmp_path, threshold_s=300, timeout_s=0.2)

        # Policy file should be unchanged (thread timed out)
        assert policy_path.read_text(encoding="utf-8") == original_content
        captured = capsys.readouterr()
        assert "timed out" in captured.err

    def test_enrolled_fresh_policy_no_call(self, tmp_path):
        """Enrolled + fresh policy -> no pull_policy call."""
        from controlzero.cli.main import _maybe_refresh_policy

        state = _make_enrollment_state(tmp_path)
        policy_path = tmp_path / "policy.yaml"
        _write_policy(policy_path)

        mock_pull = MagicMock()
        with patch("controlzero.cli.main._load_enrollment_state", return_value=state):
            with patch("controlzero.enrollment.pull_policy", mock_pull):
                _maybe_refresh_policy(policy_path, state_dir=tmp_path, threshold_s=300, timeout_s=5.0)

        mock_pull.assert_not_called()

    def test_not_enrolled_no_call(self, tmp_path):
        """Not enrolled (no enrollment.json) -> no pull_policy call."""
        from controlzero.cli.main import _maybe_refresh_policy

        policy_path = tmp_path / "policy.yaml"
        _write_policy(policy_path)
        _age_file(policy_path, 600)

        mock_pull = MagicMock()
        with patch("controlzero.enrollment.pull_policy", mock_pull):
            _maybe_refresh_policy(policy_path, state_dir=tmp_path, threshold_s=300, timeout_s=5.0)

        mock_pull.assert_not_called()

    def test_enrollment_missing_no_call(self, tmp_path):
        """enrollment.json missing entirely -> no pull_policy call."""
        from controlzero.cli.main import _maybe_refresh_policy

        policy_path = tmp_path / "policy.yaml"
        _write_policy(policy_path)
        _age_file(policy_path, 600)

        mock_pull = MagicMock()
        with patch("controlzero.enrollment.pull_policy", mock_pull):
            _maybe_refresh_policy(policy_path, state_dir=tmp_path, threshold_s=300, timeout_s=5.0)

        mock_pull.assert_not_called()

    def test_enrollment_malformed_no_call(self, tmp_path):
        """enrollment.json is malformed -> fail-open, no pull_policy call."""
        from controlzero.cli.main import _maybe_refresh_policy

        (tmp_path / "enrollment.json").write_text("{not valid json", encoding="utf-8")
        policy_path = tmp_path / "policy.yaml"
        _write_policy(policy_path)
        _age_file(policy_path, 600)

        mock_pull = MagicMock()
        with patch("controlzero.enrollment.pull_policy", mock_pull):
            _maybe_refresh_policy(policy_path, state_dir=tmp_path, threshold_s=300, timeout_s=5.0)

        mock_pull.assert_not_called()
