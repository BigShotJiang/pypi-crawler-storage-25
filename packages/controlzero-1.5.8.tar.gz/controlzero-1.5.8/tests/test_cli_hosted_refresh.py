"""Tests for the hook-check ENROLLMENT-mode background policy refresh.

T103 (2026-05-12): api_key clients no longer use ``_maybe_refresh_policy``
to refresh the local policy file. The hook-check CLI constructs
``Client(api_key=...)`` directly; ``hosted_policy.load_hosted_policy``
handles cache + If-None-Match refresh internally.

This file is now scoped to the enrollment-based refresh path (used by
machines that ran ``controlzero login`` and persisted enrollment.json).
The old hosted-pull-and-rewrite-file tests were dropped because
``_do_hosted_pull_and_write`` was deleted: it overwrote user-edited
``policy.yaml`` content with hosted bundle rules, which is what caused
the stale-file shadow (2026-05-12).
"""

from __future__ import annotations

from pathlib import Path
from unittest.mock import patch

import pytest
import yaml


def _write_stale_policy(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        yaml.safe_dump({"version": "1", "rules": [{"allow": "*"}]}),
        encoding="utf-8",
    )
    import os
    past = os.path.getmtime(path) - 10 * 60
    os.utime(path, (past, past))


def test_refresh_noop_without_enrollment(tmp_path, monkeypatch):
    """No enrollment.json => skip refresh entirely.

    After T103 the hosted (api_key) refresh path also lives in the
    Client constructor, not here, so api_key alone no longer triggers
    a CLI-level refresh.
    """
    from controlzero.cli.main import _maybe_refresh_policy

    policy_path = tmp_path / "policy.yaml"
    _write_stale_policy(policy_path)
    monkeypatch.delenv("CONTROLZERO_API_KEY", raising=False)

    before = policy_path.read_text(encoding="utf-8")
    with patch("controlzero.cli.main._load_enrollment_state", return_value=None):
        _maybe_refresh_policy(policy_path, state_dir=tmp_path, threshold_s=60, timeout_s=1)
    after = policy_path.read_text(encoding="utf-8")

    assert before == after


def test_refresh_noop_with_api_key_alone(tmp_path, monkeypatch):
    """api_key + no enrollment => skip (Client constructor handles it)."""
    from controlzero.cli.main import _maybe_refresh_policy

    policy_path = tmp_path / "policy.yaml"
    _write_stale_policy(policy_path)
    monkeypatch.setenv("CONTROLZERO_API_KEY", "cz_live_fakekey")

    before = policy_path.read_text(encoding="utf-8")
    with patch("controlzero.cli.main._load_enrollment_state", return_value=None):
        _maybe_refresh_policy(policy_path, state_dir=tmp_path, threshold_s=60, timeout_s=1)
    after = policy_path.read_text(encoding="utf-8")

    # T103: the function returns immediately because there is no
    # enrollment state; hosted refresh is no longer this function's
    # responsibility.
    assert before == after


def test_refresh_uses_enrollment_when_state_present(tmp_path, monkeypatch):
    """Enrollment state present => signed enrollment pull, file rewritten.

    Requires the 'hosted' extras (cryptography) to import the enrollment
    module. Skip in slim-install test environments.
    """
    try:
        import controlzero.enrollment as _enroll_mod  # noqa: F401
    except ImportError:
        pytest.skip("enrollment module requires 'hosted' extras")

    from controlzero.cli.main import _maybe_refresh_policy

    policy_path = tmp_path / "policy.yaml"
    _write_stale_policy(policy_path)
    monkeypatch.setenv("CONTROLZERO_API_KEY", "cz_live_fakekey")

    enrollment_called = {"value": False}

    def fake_enrollment_pull(*args, **kwargs):
        enrollment_called["value"] = True
        return None  # 304 Not Modified -- _do_pull_and_write just touches mtime

    with patch("controlzero.cli.main._load_enrollment_state", return_value=object()), \
         patch.object(_enroll_mod, "pull_policy", side_effect=fake_enrollment_pull):
        _maybe_refresh_policy(policy_path, state_dir=tmp_path, threshold_s=60, timeout_s=5)

    assert enrollment_called["value"] is True
