"""Regression tests for the 1.5.3 host-agent adapter base.

Two pillars under test:

1. Each adapter's ``claim()`` recognises its own host's invocation
   signature AND ignores other hosts' signatures. Detection survives
   missing env vars on Windows because the stdin payload shape is
   the primary signal for Claude Code.

2. Each adapter's ``render()`` emits a JSON envelope that the host's
   PreToolUse / BeforeTool hook validator accepts. The critical bug
   fixed here: Claude Code's allow path. Pre-1.5.3 the SDK emitted
   ``decision: "allow"`` which crashed Claude Code's validator with
   ``Hook JSON output validation failed - (root): Invalid input``;
   the customer (an enterprise customer admin, 2026-05-12) saw a Write block
   succeed and then a PowerShell command bypass on the same intent.
   After 1.5.3 the Claude Code adapter renders allow as ``approve``
   (the spec-correct value) and deny as ``block``.
"""

from __future__ import annotations

import pytest

from controlzero.cli.hosts import (
    REGISTRY,
    CZDecision,
    ClaudeCodeAdapter,
    CodexCLIAdapter,
    GeminiCLIAdapter,
    UnknownHostAdapter,
    select_adapter,
)


# ----------------------------------------------------------------
# Sample stdin payloads observed from each host's PreToolUse call.
# ----------------------------------------------------------------

CLAUDE_CODE_PAYLOAD = {
    "session_id": "01HX9Z6R3W6XAMPLE",
    "transcript_path": "/Users/x/.claude/transcripts/abc.jsonl",
    "cwd": "/Users/x/project",
    "tool_name": "Write",
    "tool_input": {"file_path": "/tmp/maruthi", "content": ""},
    "hook_event_name": "PreToolUse",
}

GEMINI_CLI_PAYLOAD = {
    "tool_name": "Bash",
    "tool_input": {"command": "ls"},
    "session_id": "gem-1",
    "cwd": "/home/x",
}

CODEX_CLI_PAYLOAD = {
    "tool_name": "Bash",
    "tool_input": {"command": "ls"},
    "session_id": "codex-1",
    "cwd": "/home/x",
}


# ----------------------------------------------------------------
# claim() coverage
# ----------------------------------------------------------------


class TestClaudeCodeClaim:
    def test_claims_via_hook_event_name(self):
        assert ClaudeCodeAdapter().claim(CLAUDE_CODE_PAYLOAD, env={})

    def test_claims_via_session_id_plus_transcript_path(self):
        payload = {
            "session_id": "s",
            "transcript_path": "/p",
            "tool_input": {},
        }
        assert ClaudeCodeAdapter().claim(payload, env={})

    def test_claims_via_env_var_even_without_payload_signature(self):
        # The Windows case: Anthropic launcher may not export
        # CLAUDECODE on every platform, but if it does we still
        # claim.
        assert ClaudeCodeAdapter().claim({}, env={"CLAUDECODE": "1"})

    def test_claims_via_explicit_controlzero_client_override(self):
        assert ClaudeCodeAdapter().claim(
            {}, env={"CONTROLZERO_CLIENT": "claude-code"}
        )

    def test_does_NOT_claim_gemini_payload(self):
        # Gemini doesn't ship hook_event_name and doesn't ship
        # transcript_path. Without env hints we must NOT claim.
        assert not ClaudeCodeAdapter().claim(
            GEMINI_CLI_PAYLOAD, env={}
        )


class TestGeminiCLIClaim:
    def test_claims_via_gemini_cli_env(self):
        assert GeminiCLIAdapter().claim({}, env={"GEMINI_CLI": "1"})

    def test_claims_via_gemini_sandbox_env(self):
        assert GeminiCLIAdapter().claim({}, env={"GEMINI_SANDBOX": "1"})

    def test_does_NOT_claim_via_gemini_api_key(self):
        # T78 / T92 regression: GEMINI_API_KEY is a Google API
        # credential, NOT a CLI runtime signal. Must NOT trigger
        # the Gemini adapter (the 2026-05-10 incident).
        assert not GeminiCLIAdapter().claim(
            {}, env={"GEMINI_API_KEY": "fake"}
        )


class TestCodexCLIClaim:
    def test_claims_via_codex_home_env(self):
        assert CodexCLIAdapter().claim({}, env={"CODEX_HOME": "/x"})


class TestUnknownClaim:
    def test_always_claims(self):
        assert UnknownHostAdapter().claim({}, env={})
        assert UnknownHostAdapter().claim(CLAUDE_CODE_PAYLOAD, env={})


class TestRegistryOrder:
    def test_claude_code_payload_picks_claude_adapter(self):
        adapter = select_adapter(CLAUDE_CODE_PAYLOAD, env={})
        assert isinstance(adapter, ClaudeCodeAdapter)
        assert adapter.canonical_source == "claude_code"

    def test_unknown_payload_falls_back_to_unknown_adapter(self):
        adapter = select_adapter(
            {"tool_name": "Foo"}, env={}
        )
        assert isinstance(adapter, UnknownHostAdapter)
        assert adapter.canonical_source == "unknown"

    def test_unknown_is_registry_tail(self):
        # Defensive invariant: if Unknown ever moves up the registry
        # it will claim BEFORE more-specific adapters and silently
        # break every host integration.
        assert isinstance(REGISTRY[-1], UnknownHostAdapter)


# ----------------------------------------------------------------
# render() coverage  -- the policy-bypass fix lives here.
# ----------------------------------------------------------------


class TestClaudeCodeRender:
    def test_allow_emits_approve_NOT_allow(self):
        # THE 2026-05-12 BUG. Pre-1.5.3 emitted "decision": "allow"
        # which Claude Code rejects as Invalid input -> hook output
        # dropped -> policy bypass. The fix below MUST hold.
        decision = CZDecision(
            effect="allow",
            reason="[Control Zero] Allowed: Write",
            reason_code="RULE_MATCH",
            tool="file_write",
            method="/tmp/x",
        )
        out = ClaudeCodeAdapter().render(decision)
        assert out["decision"] == "approve", (
            "Claude Code rejects decision=allow with "
            "'Hook JSON output validation failed' -- must emit "
            "'approve' on the allow path"
        )
        assert out["decision"] != "allow"

    def test_deny_emits_block(self):
        decision = CZDecision(
            effect="deny",
            reason="[Control Zero] Blocked",
            reason_code="RULE_MATCH",
            policy_id="59307692-9236-457d-9bfb-f1611c07a2ac",
            tool="file_write",
        )
        out = ClaudeCodeAdapter().render(decision)
        assert out["decision"] == "block"

    def test_render_carries_metadata_fields(self):
        decision = CZDecision(
            effect="allow",
            reason="r",
            reason_code="RULE_MATCH",
            tool="database",
            method="SELECT",
            extracted_action="database:SELECT",
            semantic_class="read",
        )
        out = ClaudeCodeAdapter().render(decision)
        assert out["tool"] == "database"
        assert out["extracted_method"] == "SELECT"
        assert out["action"] == "database:SELECT"
        assert out["action_semantic_class"] == "read"


class TestGeminiCLIRender:
    def test_allow_omits_decision(self):
        decision = CZDecision(
            effect="allow", reason="r", reason_code="RULE_MATCH"
        )
        out = GeminiCLIAdapter().render(decision)
        assert "decision" not in out

    def test_deny_emits_deny(self):
        decision = CZDecision(
            effect="deny", reason="r", reason_code="RULE_MATCH"
        )
        out = GeminiCLIAdapter().render(decision)
        assert out["decision"] == "deny"


class TestCodexCLIRender:
    def test_allow_emits_allow(self):
        decision = CZDecision(
            effect="allow", reason="r", reason_code="RULE_MATCH"
        )
        out = CodexCLIAdapter().render(decision)
        assert out["decision"] == "allow"

    def test_deny_emits_deny(self):
        decision = CZDecision(
            effect="deny", reason="r", reason_code="RULE_MATCH"
        )
        out = CodexCLIAdapter().render(decision)
        assert out["decision"] == "deny"


class TestUnknownRender:
    def test_allow_omits_decision(self):
        # The universal-proceed signal. No host treats absent
        # decision as block.
        decision = CZDecision(
            effect="allow", reason="r", reason_code="RULE_MATCH"
        )
        out = UnknownHostAdapter().render(decision)
        assert "decision" not in out

    def test_deny_emits_block(self):
        decision = CZDecision(
            effect="deny", reason="r", reason_code="RULE_MATCH"
        )
        out = UnknownHostAdapter().render(decision)
        assert out["decision"] == "block"


# ----------------------------------------------------------------
# End-to-end: payload -> select_adapter -> render
# ----------------------------------------------------------------


@pytest.mark.parametrize(
    "payload,env,expected_source,expected_allow_decision",
    [
        (CLAUDE_CODE_PAYLOAD, {}, "claude_code", "approve"),
        ({}, {"CLAUDECODE": "1"}, "claude_code", "approve"),
        ({}, {"GEMINI_CLI": "1"}, "gemini_cli", None),  # omit
        ({}, {"CODEX_HOME": "/x"}, "codex_cli", "allow"),
        ({}, {}, "unknown", None),  # omit
    ],
)
def test_end_to_end_allow_path(
    payload, env, expected_source, expected_allow_decision
):
    adapter = select_adapter(payload, env)
    assert adapter.canonical_source == expected_source
    decision = CZDecision(
        effect="allow", reason="r", reason_code="RULE_MATCH"
    )
    out = adapter.render(decision)
    if expected_allow_decision is None:
        assert "decision" not in out
    else:
        assert out["decision"] == expected_allow_decision
