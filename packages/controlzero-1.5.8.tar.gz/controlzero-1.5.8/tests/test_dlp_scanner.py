"""Comprehensive tests for DLP scanner: argument-level sensitive data detection.

Organized by pattern category with positive, negative, context, and hashing
tests for every builtin pattern group. Plus integration, custom rules, and
edge case tests.
"""

import hashlib
import time


from controlzero._internal.dlp_scanner import (
    BUILTIN_PATTERNS,
    DLPScanner,
    extract_text_from_args,
    load_dlp_rules_from_policy,
)
from controlzero._internal.enforcer import PolicyEvaluator
from controlzero._internal.types import PolicyRule
from controlzero.client import Client


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _allow_all_rules():
    return [PolicyRule(id="allow-all", name="allow-all", effect="allow", actions=["*"])]


def _scanner_builtins():
    return DLPScanner(enable_builtins=True)


def _find(matches, rule_id):
    return [m for m in matches if m.rule_id == rule_id]


# ---------------------------------------------------------------------------
# PII: US Patterns
# ---------------------------------------------------------------------------

class TestPIIUSPatterns:

    def test_ssn_positive(self):
        m = _find(_scanner_builtins().scan("123-45-6789"), "builtin-us-ssn")
        assert len(m) == 1
        assert m[0].matched_text == "123-45-6789"

    def test_ssn_negative_too_short(self):
        m = _find(_scanner_builtins().scan("123-45"), "builtin-us-ssn")
        assert len(m) == 0

    def test_ssn_context(self):
        text = "The employee SSN is 078-05-1120 on file."
        m = _find(_scanner_builtins().scan(text), "builtin-us-ssn")
        assert len(m) == 1

    def test_us_phone_positive(self):
        m = _find(_scanner_builtins().scan("(555) 123-4567"), "builtin-us-phone")
        assert len(m) >= 1

    def test_us_phone_with_country_code(self):
        m = _find(_scanner_builtins().scan("+1-555-123-4567"), "builtin-us-phone")
        assert len(m) >= 1

    def test_us_phone_negative_too_short(self):
        m = _find(_scanner_builtins().scan("555-123"), "builtin-us-phone")
        assert len(m) == 0


# ---------------------------------------------------------------------------
# PII: Korean Patterns
# ---------------------------------------------------------------------------

class TestPIIKoreanPatterns:

    def test_rrn_positive(self):
        m = _find(_scanner_builtins().scan("850101-1234567"), "builtin-kr-rrn")
        assert len(m) == 1
        assert m[0].matched_text == "850101-1234567"

    def test_rrn_all_gender_digits(self):
        for d in "1234":
            text = f"900101-{d}234567"
            assert len(_find(_scanner_builtins().scan(text), "builtin-kr-rrn")) == 1

    def test_rrn_negative_gender_0(self):
        assert len(_find(_scanner_builtins().scan("900101-0234567"), "builtin-kr-rrn")) == 0

    def test_rrn_negative_gender_5(self):
        assert len(_find(_scanner_builtins().scan("900101-5234567"), "builtin-kr-rrn")) == 0

    def test_rrn_context_korean(self):
        text = "주민번호: 850101-1234567 확인 완료"
        assert len(_find(_scanner_builtins().scan(text), "builtin-kr-rrn")) == 1

    def test_phone_positive_010(self):
        m = _find(_scanner_builtins().scan("010-1234-5678"), "builtin-kr-phone")
        assert len(m) == 1
        assert m[0].matched_text == "010-1234-5678"

    def test_phone_positive_016_short(self):
        m = _find(_scanner_builtins().scan("016-123-4567"), "builtin-kr-phone")
        assert len(m) == 1

    def test_phone_negative_wrong_prefix(self):
        assert len(_find(_scanner_builtins().scan("020-1234-5678"), "builtin-kr-phone")) == 0

    def test_phone_context(self):
        text = "전화번호 010-9876-5432 으로 연락주세요"
        assert len(_find(_scanner_builtins().scan(text), "builtin-kr-phone")) == 1

    def test_brn_positive(self):
        m = _find(_scanner_builtins().scan("123-45-67890"), "builtin-kr-brn")
        assert len(m) == 1

    def test_brn_negative_too_short(self):
        assert len(_find(_scanner_builtins().scan("123-45-6789"), "builtin-kr-brn")) == 0

    def test_brn_context(self):
        text = "사업자등록번호: 214-86-12345"
        assert len(_find(_scanner_builtins().scan(text), "builtin-kr-brn")) == 1

    def test_drivers_license_positive(self):
        m = _find(_scanner_builtins().scan("11-22-333444-55"), "builtin-kr-drivers-license")
        assert len(m) == 1

    def test_passport_positive(self):
        m = _find(_scanner_builtins().scan("M12345678"), "builtin-kr-passport")
        assert len(m) == 1

    def test_passport_negative_wrong_prefix(self):
        assert len(_find(_scanner_builtins().scan("A12345678"), "builtin-kr-passport")) == 0

    def test_passport_context(self):
        text = "여권번호 S98765432 확인"
        assert len(_find(_scanner_builtins().scan(text), "builtin-kr-passport")) == 1

    def test_mixed_korean_unicode(self):
        text = "이름: 김철수, 주민번호: 850101-1234567, 전화: 010-9876-5432"
        s = _scanner_builtins()
        assert len(_find(s.scan(text), "builtin-kr-rrn")) == 1
        assert len(_find(s.scan(text), "builtin-kr-phone")) == 1


# ---------------------------------------------------------------------------
# PII: Japanese Patterns
# ---------------------------------------------------------------------------

class TestPIIJapanesePatterns:

    def test_my_number_individual_positive(self):
        m = _find(_scanner_builtins().scan("1234 5678 9012"), "builtin-jp-my-number-individual")
        assert len(m) >= 1

    def test_my_number_individual_no_spaces(self):
        m = _find(_scanner_builtins().scan("123456789012"), "builtin-jp-my-number-individual")
        assert len(m) >= 1

    def test_my_number_negative_too_short(self):
        m = _find(_scanner_builtins().scan("1234 5678"), "builtin-jp-my-number-individual")
        assert len(m) == 0

    def test_my_number_corporate_positive(self):
        m = _find(_scanner_builtins().scan("1234567890123"), "builtin-jp-my-number-corporate")
        assert len(m) >= 1

    def test_jp_phone_positive(self):
        m = _find(_scanner_builtins().scan("090-1234-5678"), "builtin-jp-phone")
        assert len(m) == 1

    def test_jp_phone_080(self):
        m = _find(_scanner_builtins().scan("080-9876-5432"), "builtin-jp-phone")
        assert len(m) == 1

    def test_jp_phone_negative_wrong_prefix(self):
        assert len(_find(_scanner_builtins().scan("010-1234-5678"), "builtin-jp-phone")) == 0

    def test_jp_phone_context(self):
        text = "Please call 090-1234-5678 for the Tokyo office."
        assert len(_find(_scanner_builtins().scan(text), "builtin-jp-phone")) == 1


# ---------------------------------------------------------------------------
# PII: European Patterns
# ---------------------------------------------------------------------------

class TestPIIEuropeanPatterns:

    def test_uk_nin_positive(self):
        m = _find(_scanner_builtins().scan("AB 12 34 56 C"), "builtin-uk-nin")
        assert len(m) == 1

    def test_uk_nin_no_spaces(self):
        m = _find(_scanner_builtins().scan("AB123456C"), "builtin-uk-nin")
        assert len(m) == 1

    def test_uk_nin_negative_invalid_prefix(self):
        # D and F are not valid first letters
        assert len(_find(_scanner_builtins().scan("DA123456C"), "builtin-uk-nin")) == 0

    def test_uk_nin_context(self):
        text = "NI number: AB 12 34 56 C on payslip"
        assert len(_find(_scanner_builtins().scan(text), "builtin-uk-nin")) == 1

    def test_de_tax_id_positive(self):
        m = _find(_scanner_builtins().scan("12345678901"), "builtin-de-tax-id")
        assert len(m) >= 1

    def test_fr_nir_positive(self):
        # Format: 1 85 01 75 123 456 78
        m = _find(_scanner_builtins().scan("1 85 01 75 123 456 78"), "builtin-fr-nir")
        assert len(m) >= 1

    def test_fr_nir_context(self):
        text = "NIR: 2 93 08 99 123 456 85"
        assert len(_find(_scanner_builtins().scan(text), "builtin-fr-nir")) >= 1


# ---------------------------------------------------------------------------
# PII: Indian Patterns
# ---------------------------------------------------------------------------

class TestPIIIndianPatterns:

    def test_aadhaar_positive(self):
        m = _find(_scanner_builtins().scan("1234 5678 9012"), "builtin-in-aadhaar")
        assert len(m) >= 1

    def test_aadhaar_context(self):
        text = "Aadhaar: 2345 6789 0123"
        assert len(_find(_scanner_builtins().scan(text), "builtin-in-aadhaar")) >= 1

    def test_pan_positive(self):
        m = _find(_scanner_builtins().scan("ABCDE1234F"), "builtin-in-pan")
        assert len(m) == 1

    def test_pan_negative_wrong_format(self):
        assert len(_find(_scanner_builtins().scan("12345ABCDE"), "builtin-in-pan")) == 0

    def test_pan_context(self):
        text = "PAN card: BNZAA2318J is verified"
        assert len(_find(_scanner_builtins().scan(text), "builtin-in-pan")) == 1


# ---------------------------------------------------------------------------
# PII: Brazilian Patterns
# ---------------------------------------------------------------------------

class TestPIIBrazilianPatterns:

    def test_cpf_positive(self):
        m = _find(_scanner_builtins().scan("123.456.789-09"), "builtin-br-cpf")
        assert len(m) == 1
        assert m[0].matched_text == "123.456.789-09"

    def test_cpf_negative_no_dots(self):
        assert len(_find(_scanner_builtins().scan("12345678909"), "builtin-br-cpf")) == 0

    def test_cpf_context(self):
        text = "CPF do cliente: 987.654.321-00"
        assert len(_find(_scanner_builtins().scan(text), "builtin-br-cpf")) == 1


# ---------------------------------------------------------------------------
# PII: Global Patterns
# ---------------------------------------------------------------------------

class TestPIIGlobalPatterns:

    def test_email_positive(self):
        m = _find(_scanner_builtins().scan("user@example.com"), "builtin-email")
        assert len(m) == 1

    def test_email_negative_no_domain(self):
        assert len(_find(_scanner_builtins().scan("user@"), "builtin-email")) == 0

    def test_email_context(self):
        text = "Send the report to ceo@samsung.co.kr by Friday"
        assert len(_find(_scanner_builtins().scan(text), "builtin-email")) == 1

    def test_ca_sin_positive(self):
        m = _find(_scanner_builtins().scan("123-456-789"), "builtin-ca-sin")
        assert len(m) >= 1

    def test_sg_nric_positive(self):
        m = _find(_scanner_builtins().scan("S1234567D"), "builtin-sg-nric")
        assert len(m) == 1

    def test_sg_nric_negative_wrong_prefix(self):
        assert len(_find(_scanner_builtins().scan("X1234567D"), "builtin-sg-nric")) == 0

    def test_hk_id_positive(self):
        m = _find(_scanner_builtins().scan("A123456(7)"), "builtin-hk-id")
        assert len(m) >= 1


# ---------------------------------------------------------------------------
# Financial Patterns
# ---------------------------------------------------------------------------

class TestFinancialPatterns:

    def test_credit_card_visa(self):
        m = _find(_scanner_builtins().scan("4111-1111-1111-1111"), "builtin-credit-card")
        assert len(m) >= 1

    def test_credit_card_visa_no_dashes(self):
        m = _find(_scanner_builtins().scan("4111111111111111"), "builtin-credit-card")
        assert len(m) >= 1

    def test_credit_card_mastercard(self):
        m = _find(_scanner_builtins().scan("5500 0000 0000 0004"), "builtin-credit-card")
        assert len(m) >= 1

    def test_credit_card_amex(self):
        # Amex: 15 digits starting with 34 or 37, formatted as 4-4-4-3
        m = _find(_scanner_builtins().scan("3782-8224-6310-005"), "builtin-credit-card")
        assert len(m) >= 1

    def test_credit_card_negative_too_short(self):
        assert len(_find(_scanner_builtins().scan("4111-1111"), "builtin-credit-card")) == 0

    def test_credit_card_context(self):
        text = "Charge card 4111111111111111 for $29.99"
        assert len(_find(_scanner_builtins().scan(text), "builtin-credit-card")) >= 1

    def test_iban_positive(self):
        m = _find(_scanner_builtins().scan("DE89370400440532013000"), "builtin-iban")
        assert len(m) >= 1

    def test_iban_gb(self):
        m = _find(_scanner_builtins().scan("GB29NWBK60161331926819"), "builtin-iban")
        assert len(m) >= 1

    def test_iban_negative_too_short(self):
        assert len(_find(_scanner_builtins().scan("DE89"), "builtin-iban")) == 0

    def test_iban_context(self):
        text = "Wire to IBAN DE89370400440532013000 by EOD"
        assert len(_find(_scanner_builtins().scan(text), "builtin-iban")) >= 1

    def test_swift_positive(self):
        m = _find(_scanner_builtins().scan("DEUTDEFF"), "builtin-swift-bic")
        assert len(m) >= 1

    def test_ethereum_address(self):
        m = _find(
            _scanner_builtins().scan("0x742d35Cc6634C0532925a3b844Bc9e7595f2bd70"),
            "builtin-ethereum-address",
        )
        assert len(m) == 1

    def test_ethereum_negative(self):
        assert len(_find(_scanner_builtins().scan("0x742"), "builtin-ethereum-address")) == 0


# ---------------------------------------------------------------------------
# Healthcare Patterns
# ---------------------------------------------------------------------------

class TestHealthcarePatterns:

    def test_us_dea_positive(self):
        m = _find(_scanner_builtins().scan("AB1234567"), "builtin-us-dea")
        assert len(m) >= 1

    def test_us_dea_negative_wrong_prefix(self):
        # 'I' is not a valid DEA first letter
        assert len(_find(_scanner_builtins().scan("IB1234567"), "builtin-us-dea")) == 0

    def test_us_dea_context(self):
        text = "DEA registration: AB1234567 for Dr. Smith"
        assert len(_find(_scanner_builtins().scan(text), "builtin-us-dea")) >= 1


# ---------------------------------------------------------------------------
# Secrets: Cloud Provider Patterns
# ---------------------------------------------------------------------------

class TestCloudSecretPatterns:

    def test_aws_access_key_positive(self):
        m = _find(_scanner_builtins().scan("AKIAIOSFODNN7EXAMPLE"), "builtin-aws-access-key")
        assert len(m) == 1
        assert m[0].category == "secret"

    def test_aws_access_key_negative_too_short(self):
        assert len(_find(_scanner_builtins().scan("AKIA"), "builtin-aws-access-key")) == 0

    def test_aws_access_key_context(self):
        text = "export AWS_ACCESS_KEY_ID=AKIAIOSFODNN7EXAMPLE"
        assert len(_find(_scanner_builtins().scan(text), "builtin-aws-access-key")) == 1

    def test_aws_key_hashed(self):
        m = _find(_scanner_builtins().scan("AKIAIOSFODNN7EXAMPLE"), "builtin-aws-access-key")
        expected = hashlib.sha256("AKIAIOSFODNN7EXAMPLE".encode()).hexdigest()
        assert m[0].matched_text == expected

    def test_gcp_api_key_positive(self):
        # AIza + 35 alphanumeric chars = 39 total
        key = "AIza" + "a" * 35
        m = _find(_scanner_builtins().scan(key), "builtin-gcp-api-key")
        assert len(m) == 1

    def test_gcp_api_key_negative(self):
        assert len(_find(_scanner_builtins().scan("AIza"), "builtin-gcp-api-key")) == 0

    def test_gcp_service_account_positive(self):
        text = '{"type": "service_account", "project_id": "test"}'
        m = _find(_scanner_builtins().scan(text), "builtin-gcp-service-account")
        assert len(m) == 1

    def test_azure_sas_token_positive(self):
        text = "sv=2021-06-08&ss=bfqt&srt=sco&sp=rwdl&se=2025-01-01&sig=abc123%3D"
        m = _find(_scanner_builtins().scan(text), "builtin-azure-sas-token")
        assert len(m) == 1


# ---------------------------------------------------------------------------
# Secrets: AI Provider Patterns
# ---------------------------------------------------------------------------

class TestAIProviderSecretPatterns:

    def test_openai_key_positive(self):
        key = "sk-proj-" + "a" * 48
        m = _find(_scanner_builtins().scan(key), "builtin-openai-key")
        assert len(m) == 1

    def test_openai_key_legacy_format(self):
        key = "sk-" + "a" * 48
        m = _find(_scanner_builtins().scan(key), "builtin-openai-key")
        assert len(m) == 1

    def test_openai_key_negative(self):
        assert len(_find(_scanner_builtins().scan("sk-"), "builtin-openai-key")) == 0

    def test_openai_key_context(self):
        text = f"export OPENAI_API_KEY=sk-proj-{'x' * 48}"
        assert len(_find(_scanner_builtins().scan(text), "builtin-openai-key")) == 1

    def test_openai_key_hashed(self):
        key = "sk-proj-" + "a" * 48
        m = _find(_scanner_builtins().scan(key), "builtin-openai-key")
        expected = hashlib.sha256(key.encode()).hexdigest()
        assert m[0].matched_text == expected

    def test_anthropic_key_positive(self):
        key = "sk-ant-" + "a" * 95
        m = _find(_scanner_builtins().scan(key), "builtin-anthropic-key")
        assert len(m) == 1

    def test_anthropic_key_negative_too_short(self):
        assert len(_find(_scanner_builtins().scan("sk-ant-abc"), "builtin-anthropic-key")) == 0

    def test_anthropic_key_context(self):
        key = "sk-ant-" + "x" * 95
        text = f"ANTHROPIC_API_KEY={key}"
        assert len(_find(_scanner_builtins().scan(text), "builtin-anthropic-key")) == 1

    def test_huggingface_token_positive(self):
        token = "hf_" + "a" * 34
        m = _find(_scanner_builtins().scan(token), "builtin-huggingface-token")
        assert len(m) == 1

    def test_huggingface_token_negative(self):
        assert len(_find(_scanner_builtins().scan("hf_abc"), "builtin-huggingface-token")) == 0

    def test_huggingface_token_context(self):
        token = "hf_" + "B" * 34
        text = f"HF_TOKEN={token} in .env"
        assert len(_find(_scanner_builtins().scan(text), "builtin-huggingface-token")) == 1


# ---------------------------------------------------------------------------
# Secrets: Database Connection Strings
# ---------------------------------------------------------------------------

class TestDatabaseSecretPatterns:

    def test_postgres_url_positive(self):
        url = "postgresql://admin:secretpass@db.example.com:5432/mydb"
        m = _find(_scanner_builtins().scan(url), "builtin-postgres-url")
        assert len(m) == 1

    def test_postgres_url_simple(self):
        url = "postgres://user:pass@localhost/test"
        m = _find(_scanner_builtins().scan(url), "builtin-postgres-url")
        assert len(m) == 1

    def test_postgres_url_negative_no_password(self):
        url = "postgresql://readonly@db.example.com/mydb"
        assert len(_find(_scanner_builtins().scan(url), "builtin-postgres-url")) == 0

    def test_postgres_url_context(self):
        text = 'DATABASE_URL="postgresql://admin:s3cret@prod-db.internal:5432/app"'
        assert len(_find(_scanner_builtins().scan(text), "builtin-postgres-url")) == 1

    def test_postgres_url_hashed(self):
        url = "postgres://user:pass@localhost/test"
        m = _find(_scanner_builtins().scan(url), "builtin-postgres-url")
        expected = hashlib.sha256(url.encode()).hexdigest()
        assert m[0].matched_text == expected

    def test_mysql_url_positive(self):
        url = "mysql://root:password@127.0.0.1:3306/mydb"
        m = _find(_scanner_builtins().scan(url), "builtin-mysql-url")
        assert len(m) == 1

    def test_mongodb_url_positive(self):
        url = "mongodb+srv://admin:p4ssw0rd@cluster0.example.net/test"
        m = _find(_scanner_builtins().scan(url), "builtin-mongodb-url")
        assert len(m) == 1

    def test_redis_url_positive(self):
        url = "redis://:mysecret@redis.example.com:6379/0"
        m = _find(_scanner_builtins().scan(url), "builtin-redis-url")
        assert len(m) == 1

    def test_jwt_token_positive(self):
        # Realistic-ish JWT (header.payload.signature)
        token = "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMjM0NTY3ODkwIn0.dozjgNryP4J3jVmNHl0w5N_XgL0n3I9PlFUP0THsR8U"
        m = _find(_scanner_builtins().scan(token), "builtin-jwt-token")
        assert len(m) == 1

    def test_jwt_negative_not_jwt(self):
        assert len(_find(_scanner_builtins().scan("eyJ.notjwt"), "builtin-jwt-token")) == 0

    def test_jwt_context(self):
        token = "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMjM0NTY3ODkwIn0.dozjgNryP4J3jVmNHl0w5N_XgL0n3I9PlFUP0THsR8U"
        text = f"Authorization: Bearer {token}"
        assert len(_find(_scanner_builtins().scan(text), "builtin-jwt-token")) == 1


# ---------------------------------------------------------------------------
# Secrets: SaaS / Developer Tools
# ---------------------------------------------------------------------------

class TestSaaSSecretPatterns:

    def test_github_pat_positive(self):
        token = "ghp_" + "A" * 36
        m = _find(_scanner_builtins().scan(token), "builtin-github-pat")
        assert len(m) == 1

    def test_github_pat_new_format(self):
        token = "github_pat_" + "A" * 82
        m = _find(_scanner_builtins().scan(token), "builtin-github-pat")
        assert len(m) == 1

    def test_github_pat_negative(self):
        assert len(_find(_scanner_builtins().scan("ghp_short"), "builtin-github-pat")) == 0

    def test_github_pat_context(self):
        token = "ghp_" + "x" * 36
        text = f"git clone https://oauth2:{token}@github.com/org/repo.git"
        assert len(_find(_scanner_builtins().scan(text), "builtin-github-pat")) == 1

    def test_github_pat_hashed(self):
        token = "ghp_" + "A" * 36
        m = _find(_scanner_builtins().scan(token), "builtin-github-pat")
        expected = hashlib.sha256(token.encode()).hexdigest()
        assert m[0].matched_text == expected

    def test_gitlab_pat_positive(self):
        token = "glpat-" + "a" * 20
        m = _find(_scanner_builtins().scan(token), "builtin-gitlab-pat")
        assert len(m) == 1

    def test_gitlab_pat_negative(self):
        assert len(_find(_scanner_builtins().scan("glpat-"), "builtin-gitlab-pat")) == 0

    def test_slack_bot_token_positive(self):
        token = "xoxb-123456789012-123456789012-abcdef1234567890abcdef12"
        m = _find(_scanner_builtins().scan(token), "builtin-slack-bot-token")
        assert len(m) == 1

    def test_slack_webhook_positive(self):
        url = "https://hooks.slack.com/services/T01234567/B01234567/abcdefghijklmnop"
        m = _find(_scanner_builtins().scan(url), "builtin-slack-webhook")
        assert len(m) == 1

    def test_stripe_secret_live(self):
        key = "sk_live_" + "a" * 24
        m = _find(_scanner_builtins().scan(key), "builtin-stripe-secret")
        assert len(m) == 1

    def test_stripe_secret_test(self):
        key = "sk_test_" + "a" * 24
        m = _find(_scanner_builtins().scan(key), "builtin-stripe-secret")
        assert len(m) == 1

    def test_stripe_publishable(self):
        key = "pk_live_" + "a" * 24
        m = _find(_scanner_builtins().scan(key), "builtin-stripe-publishable")
        assert len(m) == 1

    def test_stripe_context(self):
        key = "sk_live_" + "x" * 24
        text = f'STRIPE_SECRET_KEY="{key}"'
        assert len(_find(_scanner_builtins().scan(text), "builtin-stripe-secret")) == 1

    def test_sendgrid_key_positive(self):
        key = "SG." + "a" * 22 + "." + "b" * 43
        m = _find(_scanner_builtins().scan(key), "builtin-sendgrid-key")
        assert len(m) == 1

    def test_npm_token_positive(self):
        token = "npm_" + "A" * 36
        m = _find(_scanner_builtins().scan(token), "builtin-npm-token")
        assert len(m) == 1

    def test_npm_token_negative(self):
        assert len(_find(_scanner_builtins().scan("npm_short"), "builtin-npm-token")) == 0

    def test_controlzero_key_live(self):
        key = "cz_live_" + "A" * 24
        m = _find(_scanner_builtins().scan(key), "builtin-controlzero-key")
        assert len(m) == 1

    def test_controlzero_key_test(self):
        key = "cz_test_" + "A" * 24
        m = _find(_scanner_builtins().scan(key), "builtin-controlzero-key")
        assert len(m) == 1


# ---------------------------------------------------------------------------
# Secrets: Infrastructure
# ---------------------------------------------------------------------------

class TestInfraSecretPatterns:

    def test_ssh_private_key_rsa(self):
        text = "-----BEGIN RSA PRIVATE KEY-----"
        m = _find(_scanner_builtins().scan(text), "builtin-ssh-private-key")
        assert len(m) == 1

    def test_ssh_private_key_ec(self):
        text = "-----BEGIN EC PRIVATE KEY-----"
        m = _find(_scanner_builtins().scan(text), "builtin-ssh-private-key")
        assert len(m) == 1

    def test_ssh_private_key_openssh(self):
        text = "-----BEGIN OPENSSH PRIVATE KEY-----"
        m = _find(_scanner_builtins().scan(text), "builtin-ssh-private-key")
        assert len(m) == 1

    def test_ssh_private_key_generic(self):
        text = "-----BEGIN PRIVATE KEY-----"
        m = _find(_scanner_builtins().scan(text), "builtin-ssh-private-key")
        assert len(m) == 1

    def test_ssh_private_key_context(self):
        text = "File contents:\n-----BEGIN RSA PRIVATE KEY-----\nMIIEpAIBAAKC..."
        assert len(_find(_scanner_builtins().scan(text), "builtin-ssh-private-key")) == 1

    def test_ssh_key_hashed(self):
        text = "-----BEGIN RSA PRIVATE KEY-----"
        m = _find(_scanner_builtins().scan(text), "builtin-ssh-private-key")
        expected = hashlib.sha256(text.encode()).hexdigest()
        assert m[0].matched_text == expected

    def test_pem_certificate(self):
        text = "-----BEGIN CERTIFICATE-----"
        m = _find(_scanner_builtins().scan(text), "builtin-pem-certificate")
        assert len(m) == 1

    def test_vault_token_positive(self):
        token = "hvs." + "a" * 30
        m = _find(_scanner_builtins().scan(token), "builtin-vault-token")
        assert len(m) == 1

    def test_vault_token_negative(self):
        assert len(_find(_scanner_builtins().scan("hvs."), "builtin-vault-token")) == 0

    def test_vault_token_context(self):
        token = "hvs." + "x" * 30
        text = f"VAULT_TOKEN={token}"
        assert len(_find(_scanner_builtins().scan(text), "builtin-vault-token")) == 1

    def test_doppler_token_positive(self):
        token = "dp.st." + "a" * 44
        m = _find(_scanner_builtins().scan(token), "builtin-doppler-token")
        assert len(m) == 1

    def test_sentry_dsn_positive(self):
        dsn = "https://abc123def456@o123456.ingest.sentry.io/7890123"
        m = _find(_scanner_builtins().scan(dsn), "builtin-sentry-dsn")
        assert len(m) == 1

    def test_bearer_token_positive(self):
        text = "Authorization: Bearer eyJtoken123.payload.sig"
        m = _find(_scanner_builtins().scan(text), "builtin-bearer-token")
        assert len(m) == 1

    def test_bearer_token_lowercase(self):
        text = "authorization: Bearer mytoken123"
        m = _find(_scanner_builtins().scan(text), "builtin-bearer-token")
        assert len(m) == 1

    def test_amqp_url_positive(self):
        url = "amqp://guest:guest@rabbitmq.example.com:5672/"
        m = _find(_scanner_builtins().scan(url), "builtin-amqp-url")
        assert len(m) == 1

    def test_linear_key_positive(self):
        key = "lin_api_" + "a" * 44
        m = _find(_scanner_builtins().scan(key), "builtin-linear-key")
        assert len(m) == 1

    def test_newrelic_key_positive(self):
        key = "NRAK-" + "A" * 27
        m = _find(_scanner_builtins().scan(key), "builtin-newrelic-key")
        assert len(m) == 1


# ---------------------------------------------------------------------------
# Secret Hashing (cross-cutting)
# ---------------------------------------------------------------------------

class TestSecretHashing:

    def test_all_secret_matches_are_hashed(self):
        """Every secret-category match should contain a SHA-256 hash, not plaintext."""
        scanner = _scanner_builtins()
        text = (
            "AKIAIOSFODNN7EXAMPLE "
            "sk-proj-" + "a" * 48 + " "
            "ghp_" + "B" * 36 + " "
            "-----BEGIN RSA PRIVATE KEY-----"
        )
        matches = scanner.scan(text)
        secret_matches = [m for m in matches if m.category == "secret"]
        assert len(secret_matches) > 0
        for m in secret_matches:
            # SHA-256 hex is always 64 chars of [0-9a-f]
            assert len(m.matched_text) == 64, f"Rule {m.rule_id} did not hash"
            assert all(c in "0123456789abcdef" for c in m.matched_text)

    def test_pii_matches_are_not_hashed(self):
        scanner = _scanner_builtins()
        matches = scanner.scan("123-45-6789")
        ssn = _find(matches, "builtin-us-ssn")
        assert len(ssn) >= 1
        assert ssn[0].matched_text == "123-45-6789"

    def test_financial_matches_are_not_hashed(self):
        scanner = _scanner_builtins()
        matches = scanner.scan("4111111111111111")
        cc = _find(matches, "builtin-credit-card")
        assert len(cc) >= 1
        # Should be plaintext, not a hash
        assert "4111" in cc[0].matched_text

    def test_audit_findings_exclude_text_for_secrets(self):
        scanner = _scanner_builtins()
        matches = scanner.scan("AKIAIOSFODNN7EXAMPLE")
        findings = scanner.get_findings_for_audit(matches)
        for f in findings:
            if f["category"] == "secret":
                assert "matched_text" not in f

    def test_audit_findings_include_text_for_pii(self):
        scanner = _scanner_builtins()
        matches = scanner.scan("123-45-6789")
        findings = scanner.get_findings_for_audit(matches)
        ssn_f = [f for f in findings if f["rule_id"] == "builtin-us-ssn"]
        assert len(ssn_f) >= 1
        assert "matched_text" in ssn_f[0]


# ---------------------------------------------------------------------------
# Enforcer DLP Integration
# ---------------------------------------------------------------------------

class TestEnforcerDLPIntegration:

    def test_allow_with_clean_args(self):
        scanner = _scanner_builtins()
        evaluator = PolicyEvaluator(rules=_allow_all_rules(), dlp_scanner=scanner)
        decision = evaluator.evaluate("Bash", args={"command": "ls -la"})
        assert decision.allowed

    def test_allow_with_pii_detect(self):
        scanner = _scanner_builtins()
        evaluator = PolicyEvaluator(rules=_allow_all_rules(), dlp_scanner=scanner)
        decision = evaluator.evaluate("Bash", args={"command": "echo 123-45-6789"})
        assert decision.allowed
        assert len(decision.dlp_findings) > 0
        assert any(f["rule_id"] == "builtin-us-ssn" for f in decision.dlp_findings)

    def test_deny_from_policy_no_dlp(self):
        scanner = _scanner_builtins()
        rules = [PolicyRule(id="deny-all", name="deny-all", effect="deny", actions=["*"])]
        evaluator = PolicyEvaluator(rules=rules, dlp_scanner=scanner)
        decision = evaluator.evaluate("Bash", args={"command": "echo 123-45-6789"})
        assert decision.denied
        assert decision.dlp_findings == []

    def test_block_rule_overrides_allow(self):
        custom = [{"id": "block-ssn", "name": "Block SSN", "pattern": r"\b\d{3}-\d{2}-\d{4}\b",
                    "category": "pii", "action": "block"}]
        scanner = DLPScanner(custom_rules=custom, enable_builtins=False)
        evaluator = PolicyEvaluator(rules=_allow_all_rules(), dlp_scanner=scanner)
        decision = evaluator.evaluate("Bash", args={"command": "echo 123-45-6789"})
        assert decision.denied
        assert "Block SSN" in decision.reason
        assert "pii" in decision.reason

    def test_no_scanner_no_dlp(self):
        evaluator = PolicyEvaluator(rules=_allow_all_rules(), dlp_scanner=None)
        decision = evaluator.evaluate("Bash", args={"command": "echo 123-45-6789"})
        assert decision.allowed
        assert decision.dlp_findings == []

    def test_empty_args_no_dlp(self):
        scanner = _scanner_builtins()
        evaluator = PolicyEvaluator(rules=_allow_all_rules(), dlp_scanner=scanner)
        decision = evaluator.evaluate("Bash", args={})
        assert decision.allowed
        assert decision.dlp_findings == []

    def test_none_args_no_dlp(self):
        scanner = _scanner_builtins()
        evaluator = PolicyEvaluator(rules=_allow_all_rules(), dlp_scanner=scanner)
        decision = evaluator.evaluate("Bash", args=None)
        assert decision.allowed

    def test_nested_args_scanned(self):
        scanner = _scanner_builtins()
        evaluator = PolicyEvaluator(rules=_allow_all_rules(), dlp_scanner=scanner)
        args = {"tool_input": {"content": {"data": "SSN: 123-45-6789"}}}
        decision = evaluator.evaluate("Bash", args=args)
        assert decision.allowed
        assert any(f["rule_id"] == "builtin-us-ssn" for f in decision.dlp_findings)

    def test_multiple_findings(self):
        scanner = _scanner_builtins()
        evaluator = PolicyEvaluator(rules=_allow_all_rules(), dlp_scanner=scanner)
        text = "SSN: 123-45-6789, email: foo@bar.com, phone: 010-1234-5678"
        decision = evaluator.evaluate("Bash", args={"command": text})
        assert decision.allowed
        rule_ids = {f["rule_id"] for f in decision.dlp_findings}
        assert "builtin-us-ssn" in rule_ids
        assert "builtin-email" in rule_ids
        assert "builtin-kr-phone" in rule_ids

    def test_set_dlp_scanner_after_init(self):
        evaluator = PolicyEvaluator(rules=_allow_all_rules())
        decision = evaluator.evaluate("Bash", args={"command": "echo 123-45-6789"})
        assert decision.dlp_findings == []

        evaluator.set_dlp_scanner(_scanner_builtins())
        decision = evaluator.evaluate("Bash", args={"command": "echo 123-45-6789"})
        assert len(decision.dlp_findings) > 0


# ---------------------------------------------------------------------------
# Custom Policy DLP Rules
# ---------------------------------------------------------------------------

class TestCustomPolicyDLPRules:

    def test_client_loads_dlp_rules_from_dict_policy(self, tmp_log):
        policy = {
            "rules": [{"allow": "*"}],
            "dlp_rules": [
                {"id": "block-rrn", "name": "Block Korean RRN",
                 "pattern": r"\b\d{6}-[1-4]\d{6}\b",
                 "category": "pii", "action": "block", "scopes": ["sdk"]},
            ],
        }
        cz = Client(policy=policy, log_path=str(tmp_log))
        decision = cz.guard("Bash", args={"command": "echo 850101-1234567"})
        assert decision.denied
        assert "Block Korean RRN" in decision.reason
        cz.close()

    def test_client_clean_args_allowed(self, tmp_log):
        policy = {"rules": [{"allow": "*"}]}
        cz = Client(policy=policy, log_path=str(tmp_log))
        decision = cz.guard("Bash", args={"command": "ls -la"})
        assert decision.allowed
        cz.close()

    def test_client_denied_by_policy_no_dlp(self, tmp_log):
        policy = {"rules": [{"deny": "*"}]}
        cz = Client(policy=policy, log_path=str(tmp_log))
        decision = cz.guard("Bash", args={"command": "echo 850101-1234567"})
        assert decision.denied
        assert decision.dlp_findings == []
        cz.close()

    def test_gateway_scope_filtered_out(self, tmp_log):
        policy = {
            "rules": [{"allow": "*"}],
            "dlp_rules": [
                {"id": "gw-only", "name": "GW Only",
                 "pattern": r"\b\d{6}-[1-4]\d{6}\b",
                 "category": "pii", "action": "block", "scopes": ["gateway"]},
            ],
        }
        cz = Client(policy=policy, log_path=str(tmp_log))
        # Should NOT block because the rule is gateway-scoped, not sdk
        decision = cz.guard("Bash", args={"command": "echo 850101-1234567"})
        # The builtin RRN detect rule may still fire, but should not block
        assert decision.allowed
        cz.close()

    def test_dlp_rules_from_yaml_file(self, tmp_path, tmp_log):
        policy_file = tmp_path / "policy.yaml"
        policy_file.write_text(
            "version: '1'\n"
            "rules:\n"
            "  - allow: '*'\n"
            "dlp_rules:\n"
            "  - id: block-passport\n"
            "    name: Block Korean Passport\n"
            "    pattern: '\\b[MS]\\d{8}\\b'\n"
            "    category: pii\n"
            "    action: block\n"
            "    scopes: [sdk]\n"
        )
        cz = Client(policy_file=str(policy_file), log_path=str(tmp_log))
        decision = cz.guard("Bash", args={"command": "passport M12345678"})
        assert decision.denied
        assert "Block Korean Passport" in decision.reason
        cz.close()


# ---------------------------------------------------------------------------
# load_dlp_rules_from_policy
# ---------------------------------------------------------------------------

class TestLoadDLPRulesFromPolicy:

    def test_no_dlp_rules_section(self):
        assert load_dlp_rules_from_policy({"rules": [{"allow": "*"}]}) == []

    def test_dlp_rules_loaded(self):
        policy = {
            "rules": [{"allow": "*"}],
            "dlp_rules": [{"id": "r1", "pattern": r"\d+", "scopes": ["sdk"]}],
        }
        assert len(load_dlp_rules_from_policy(policy)) == 1

    def test_non_sdk_scope_filtered(self):
        policy = {
            "rules": [{"allow": "*"}],
            "dlp_rules": [{"id": "gw", "pattern": r"\d+", "scopes": ["gateway"]}],
        }
        assert len(load_dlp_rules_from_policy(policy)) == 0

    def test_no_scopes_passes(self):
        policy = {
            "rules": [{"allow": "*"}],
            "dlp_rules": [{"id": "u", "pattern": r"\d+"}],
        }
        assert len(load_dlp_rules_from_policy(policy)) == 1

    def test_missing_pattern_skipped(self):
        policy = {
            "rules": [{"allow": "*"}],
            "dlp_rules": [{"id": "no-pat", "category": "pii"}],
        }
        assert len(load_dlp_rules_from_policy(policy)) == 0

    def test_non_dict_rule_skipped(self):
        policy = {"rules": [{"allow": "*"}], "dlp_rules": ["not-a-dict"]}
        assert len(load_dlp_rules_from_policy(policy)) == 0


# ---------------------------------------------------------------------------
# extract_text_from_args
# ---------------------------------------------------------------------------

class TestExtractText:

    def test_flat_dict(self):
        text = extract_text_from_args({"a": "hello", "b": "world"})
        assert "hello" in text and "world" in text

    def test_nested_dict(self):
        assert "deep" in extract_text_from_args({"a": {"b": {"c": "deep"}}})

    def test_list_values(self):
        text = extract_text_from_args({"items": ["one", "two", "three"]})
        assert "one" in text and "three" in text

    def test_numeric_values(self):
        text = extract_text_from_args({"port": 8080})
        assert "8080" in text

    def test_none_skipped(self):
        assert extract_text_from_args({"key": None}) == ""

    def test_string_input(self):
        assert extract_text_from_args("just a string") == "just a string"

    def test_empty_dict(self):
        assert extract_text_from_args({}) == ""


# ---------------------------------------------------------------------------
# Edge Cases
# ---------------------------------------------------------------------------

class TestEdgeCases:

    def test_empty_text(self):
        assert _scanner_builtins().scan("") == []

    def test_no_rules_no_matches(self):
        scanner = DLPScanner(enable_builtins=False)
        assert scanner.scan("123-45-6789") == []

    def test_invalid_regex_skipped(self):
        custom = [
            {"id": "bad", "name": "Bad", "pattern": r"[invalid", "category": "pii"},
            {"id": "good", "name": "Good", "pattern": r"\b\d{3}-\d{2}-\d{4}\b", "category": "pii"},
        ]
        scanner = DLPScanner(custom_rules=custom, enable_builtins=False)
        assert scanner.rule_count == 1
        assert len(scanner.scan("123-45-6789")) == 1

    def test_large_text_performance(self):
        scanner = _scanner_builtins()
        large_text = "x" * 50000 + " 123-45-6789 " + "y" * 50000
        start = time.monotonic()
        matches = scanner.scan(large_text)
        elapsed_ms = (time.monotonic() - start) * 1000
        ssn = _find(matches, "builtin-us-ssn")
        assert len(ssn) == 1
        assert elapsed_ms < 500, f"DLP scan took {elapsed_ms:.1f}ms on 100KB"

    def test_has_blocking_match_true(self):
        custom = [{"id": "b", "pattern": r"foo", "category": "pii", "action": "block"}]
        scanner = DLPScanner(custom_rules=custom, enable_builtins=False)
        matches = scanner.scan("foo")
        assert scanner.has_blocking_match(matches)

    def test_has_blocking_match_false(self):
        custom = [{"id": "d", "pattern": r"foo", "category": "pii", "action": "detect"}]
        scanner = DLPScanner(custom_rules=custom, enable_builtins=False)
        matches = scanner.scan("foo")
        assert not scanner.has_blocking_match(matches)

    def test_add_rules_incremental(self):
        scanner = DLPScanner(enable_builtins=False)
        assert scanner.rule_count == 0
        scanner.add_rules([{"id": "a", "pattern": r"foo", "category": "pii"}])
        assert scanner.rule_count == 1
        scanner.add_rules([{"id": "b", "pattern": r"bar", "category": "pii"}])
        assert scanner.rule_count == 2

    def test_builtin_count(self):
        scanner = _scanner_builtins()
        assert scanner.rule_count == len(BUILTIN_PATTERNS)
        assert scanner.rule_count >= 50  # We ship 50+ builtins
