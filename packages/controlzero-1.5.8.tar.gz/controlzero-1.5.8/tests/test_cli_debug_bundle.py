"""Tests for ``controlzero debug bundle`` (T87, GH #392).

These tests build a real signed+encrypted bundle in-memory, write it
to a tmp cache dir, then exercise the CLI via Click's ``CliRunner``.
The fixture mirrors the on-disk layout the SDK actually produces in
``~/.controlzero/cache/`` so the command is exercised end-to-end:
parse_bundle (verify+decrypt+decode) -> render -> simulate.
"""

from __future__ import annotations

import base64
import json
import re
import struct

import pytest
from click.testing import CliRunner

from controlzero.cli import debug_bundle as dbg
from controlzero.cli.main import cli


# ---------------------------------------------------------------------------
# Fixture: build a real signed+encrypted bundle.
#
# We use the same wire format as `parse_bundle` expects
# (see controlzero/_internal/bundle.py for the canonical spec):
#
#     0       4   magic "CZ01"
#     4       2   schema_version (uint16, LE)
#     6       8   created_at unix seconds (uint64, LE)
#     14      2   policy_count (uint16, LE)
#     16      4   sig_offset (uint32, LE)
#     20      4   sig_len (uint32, LE) == 64
#     24      8   reserved (must be zero)
#     32      N   AES-GCM(zstd(json(payload))) -- nonce(12) || ct || tag(16)
#     32+N    64  Ed25519(header[0:32] || encrypted_payload)
#
# The fixture builds a payload with two policies and a handful of
# rules that exercise the simulate code paths.
# ---------------------------------------------------------------------------


SAMPLE_PAYLOAD = {
    "bundle_id": "bundle-fixture-001",
    "created_at": 1714492800,  # 2024-04-30T16:00:00Z, well-known timestamp
    "expires_at": 1714579200,  # 24 hours later
    "default_action": "deny",
    "default_on_missing": "deny",
    "default_on_tamper": "warn",
    "policies": [
        {
            "id": "pol-db-read",
            "name": "Allow database reads",
            "version": "1",
            "is_enabled": True,
            "priority": 10,
            "rules": [
                {
                    "id": "r-db-read-allow",
                    "effect": "allow",
                    "principals": ["agent:*"],
                    "actions": ["database:read"],
                    "resources": ["*"],
                    "conditions": {},
                    "reason": "Reads on the orders table are permitted.",
                }
            ],
        },
        {
            "id": "pol-db-write",
            "name": "Block database writes",
            "version": "1",
            "is_enabled": True,
            "priority": 20,
            "rules": [
                {
                    "id": "r-db-write-deny",
                    "effect": "deny",
                    "principals": ["agent:*"],
                    "actions": ["database:write", "database:admin"],
                    "resources": ["*"],
                    "conditions": {},
                    "reason": "Writes go through the migrations pipeline.",
                }
            ],
        },
    ],
}


def _zstd_compress(data: bytes) -> bytes:
    try:
        import zstandard as zstd
    except ImportError:  # pragma: no cover - exercised on installs lacking zstd
        import pyzstd
        return pyzstd.compress(data)
    cctx = zstd.ZstdCompressor()
    return cctx.compress(data)


def _build_bundle(payload: dict) -> tuple[bytes, bytes, bytes]:
    """Return ``(blob, encryption_key, signing_pubkey)`` for *payload*."""
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM

    enc_key = AESGCM.generate_key(bit_length=256)
    aesgcm = AESGCM(enc_key)
    nonce = b"\x01" * 12
    plaintext = json.dumps(payload).encode("utf-8")
    compressed = _zstd_compress(plaintext)
    ct = aesgcm.encrypt(nonce, compressed, None)
    encrypted_payload = nonce + ct

    schema_version = 1
    created_at = payload["created_at"]
    policy_count = len(payload.get("policies") or [])

    header_size = 32
    sig_len = 64
    sig_offset = header_size + len(encrypted_payload)

    header = (
        b"CZ01"
        + struct.pack(
            "<HQHII",
            schema_version,
            created_at,
            policy_count,
            sig_offset,
            sig_len,
        )
        + b"\x00" * 8
    )
    assert len(header) == header_size

    sk = Ed25519PrivateKey.generate()
    pk_bytes = sk.public_key().public_bytes_raw()
    signature = sk.sign(header + encrypted_payload)
    assert len(signature) == sig_len

    blob = header + encrypted_payload + signature
    return blob, enc_key, pk_bytes


@pytest.fixture()
def cache_with_bundle(tmp_path, monkeypatch):
    """Write a real signed+encrypted bundle into a tmp cache dir.

    Patches ``CACHE_DIR`` / ``CONFIG_DIR`` / ``CONFIG_PATH`` in the
    debug_bundle module so the CLI looks at the tmp dir instead of the
    user's real ``~/.controlzero``. Returns a small handle dict the
    tests can assert against.
    """
    cache_dir = tmp_path / ".controlzero" / "cache"
    cache_dir.mkdir(parents=True)

    blob, enc_key, sig_key = _build_bundle(SAMPLE_PAYLOAD)

    prefix = "cz_test_loca"  # 12 chars, mirrors hosted_policy._key_scope
    bootstrap_path = cache_dir / f"bootstrap-{prefix}.json"
    bundle_path = cache_dir / f"bundle-{prefix}.bin"

    bootstrap_path.write_text(
        json.dumps(
            {
                "project_id": "proj_test_fixture",
                "org_id": "org_test_fixture",
                "project_encryption_key_b64": base64.b64encode(enc_key).decode("ascii"),
                "signing_pubkey_hex": sig_key.hex(),
                "key_version": 1,
            }
        ),
        encoding="utf-8",
    )
    bundle_path.write_bytes(blob)

    monkeypatch.setattr(dbg, "CACHE_DIR", cache_dir)
    monkeypatch.setattr(dbg, "CONFIG_DIR", tmp_path / ".controlzero")
    monkeypatch.setattr(dbg, "CONFIG_PATH", tmp_path / ".controlzero" / "config.yaml")
    # No env-driven API key for the autodetect path.
    monkeypatch.delenv("CONTROLZERO_API_KEY", raising=False)

    return {
        "prefix": prefix,
        "cache_dir": cache_dir,
        "bootstrap_path": bootstrap_path,
        "bundle_path": bundle_path,
        "encryption_key_b64": base64.b64encode(enc_key).decode("ascii"),
        "signing_pubkey_hex": sig_key.hex(),
    }


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


def test_happy_path_renders_known_bundle(cache_with_bundle):
    runner = CliRunner()
    result = runner.invoke(cli, ["debug", "bundle"])
    assert result.exit_code == 0, result.output

    out = result.output
    # Header fields
    assert "Control Zero -- bundle on disk" in out
    assert "cache prefix      : cz_test_loca" in out
    assert "project_id        : proj_test_fixture" in out
    assert "org_id            : org_test_fixture" in out
    assert "key_version       : 1" in out
    assert "schema_version    : 1" in out
    assert "bundle_id         : bundle-fixture-001" in out
    # ISO-8601 fragment for the well-known timestamp (2024-04-30T16:00:00 UTC)
    assert "2024-04-30T16:00:00" in out
    assert "default_action    : deny" in out
    assert "default_on_missing: deny" in out
    assert "default_on_tamper : warn" in out

    # Policy section
    assert "Policies (2)" in out
    assert "id        : pol-db-read" in out
    assert "name      : Allow database reads" in out
    assert "is_enabled: true" in out
    assert "priority  : 10" in out
    assert "id        : pol-db-write" in out
    # Rule details
    assert "id        : r-db-read-allow" in out
    assert "effect    : allow" in out
    assert "principals: ['agent:*']" in out
    assert "actions   : ['database:read']" in out
    assert "resources : ['*']" in out
    assert "id        : r-db-write-deny" in out
    assert "effect    : deny" in out


def test_simulate_database_read_select_allows(cache_with_bundle):
    runner = CliRunner()
    result = runner.invoke(
        cli,
        [
            "debug",
            "bundle",
            "--simulate",
            "database read sql=SELECT id FROM orders",
        ],
    )
    assert result.exit_code == 0, result.output

    out = result.output
    assert "Simulation" in out
    assert "tool   : database" in out
    assert "method : read" in out
    # Args parsing must keep the SELECT statement intact, even with
    # spaces in the SQL value.
    assert "'sql': 'SELECT id FROM orders'" in out
    # The sample policy lets database:read through with the explicit reason.
    assert "DECISION    : ALLOW" in out
    assert "reason_code : RULE_MATCH" in out
    # The matched-rule reason from the bundle must surface verbatim so
    # an operator pasting the output into a support thread can see why.
    assert "Reads on the orders table are permitted." in out
    # policy_id is non-empty (i.e. a rule actually matched). The
    # bundle->local translator does not round-trip rule IDs today, so
    # we only assert that the field is not the no-match sentinel.
    assert "policy_id   : (no rule matched)" not in out


def test_simulate_no_rule_match_falls_through_to_default_action(cache_with_bundle):
    """A tool/method with no matching rule must fall through to default_action.

    The fixture pins ``default_action=deny``. Calling ``files write`` does
    not match either of the two rules (which target ``database:read`` and
    ``database:write``/``database:admin``), so the evaluator must surface
    the no-rule-match deny with reason_code=NO_RULE_MATCH.
    """
    runner = CliRunner()
    result = runner.invoke(
        cli,
        ["debug", "bundle", "--simulate", "files write path=/tmp/x"],
    )
    assert result.exit_code == 0, result.output

    out = result.output
    assert "DECISION    : DENY" in out
    assert "reason_code : NO_RULE_MATCH" in out
    assert "policy_id   : synthetic:NO_RULE_MATCH" in out
    assert "fail-closed default" in out


def test_missing_bootstrap_file_emits_helpful_error(tmp_path, monkeypatch):
    """No bootstrap on disk -> exit 2 + a hint pointing at the right path."""
    cache_dir = tmp_path / ".controlzero" / "cache"
    cache_dir.mkdir(parents=True)

    monkeypatch.setattr(dbg, "CACHE_DIR", cache_dir)
    monkeypatch.setattr(dbg, "CONFIG_DIR", tmp_path / ".controlzero")
    monkeypatch.setattr(dbg, "CONFIG_PATH", tmp_path / ".controlzero" / "config.yaml")
    monkeypatch.delenv("CONTROLZERO_API_KEY", raising=False)

    runner = CliRunner()
    result = runner.invoke(
        cli, ["debug", "bundle", "--api-key-prefix", "cz_test_loca"]
    )
    # Exit 2 reserved for "expected file missing".
    assert result.exit_code == 2, result.output
    assert "bootstrap file not found" in result.output
    # Path hint must be present so the operator knows what to look for.
    assert "bootstrap-cz_test_loca.json" in result.output


def test_missing_bundle_file_emits_helpful_error(tmp_path, monkeypatch):
    """Bootstrap present but bundle missing -> exit 2 + a hint."""
    cache_dir = tmp_path / ".controlzero" / "cache"
    cache_dir.mkdir(parents=True)
    prefix = "cz_test_loca"
    # Write a valid-shaped bootstrap pointing at a freshly generated key
    # so the bootstrap loader does not fail before we hit the bundle path.
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM

    enc_key = AESGCM.generate_key(bit_length=256)
    sk = Ed25519PrivateKey.generate()
    (cache_dir / f"bootstrap-{prefix}.json").write_text(
        json.dumps(
            {
                "project_id": "proj",
                "org_id": "org",
                "project_encryption_key_b64": base64.b64encode(enc_key).decode("ascii"),
                "signing_pubkey_hex": sk.public_key().public_bytes_raw().hex(),
                "key_version": 1,
            }
        ),
        encoding="utf-8",
    )

    monkeypatch.setattr(dbg, "CACHE_DIR", cache_dir)
    monkeypatch.setattr(dbg, "CONFIG_DIR", tmp_path / ".controlzero")
    monkeypatch.setattr(dbg, "CONFIG_PATH", tmp_path / ".controlzero" / "config.yaml")
    monkeypatch.delenv("CONTROLZERO_API_KEY", raising=False)

    runner = CliRunner()
    result = runner.invoke(
        cli, ["debug", "bundle", "--api-key-prefix", prefix]
    )
    assert result.exit_code == 2, result.output
    assert "bundle file not found" in result.output
    assert f"bundle-{prefix}.bin" in result.output


def test_output_does_not_leak_encryption_key_or_signing_pubkey(cache_with_bundle):
    """The CLI output must NEVER include the encryption key or signing pubkey.

    Operators paste this output into a support thread; a leak would
    let anyone who scrapes the thread decrypt the bundle. We check the
    full base64 encryption key and the hex-encoded signing pubkey
    do not appear in stdout. Also walks the JSON-key labels so a
    future change cannot serialize them by accident.
    """
    runner = CliRunner()
    result = runner.invoke(
        cli,
        [
            "debug",
            "bundle",
            "--simulate",
            "database read sql=SELECT 1",
        ],
    )
    assert result.exit_code == 0, result.output

    out = result.output
    assert cache_with_bundle["encryption_key_b64"] not in out
    assert cache_with_bundle["signing_pubkey_hex"] not in out
    # JSON key labels are also a smell -- if they appear, the source
    # caller is dumping the raw bootstrap dict.
    for label in (
        "project_encryption_key_b64",
        "encryption_key_b64",
        "signing_pubkey_hex",
        "signing_pub_key_hex",
    ):
        assert label not in out, f"sensitive label leaked: {label!r}"
    # Belt-and-braces: scan for anything that looks like a 64-char hex
    # string (ed25519 pubkey shape) or a 44-char base64 string ending
    # in '=' (32-byte key shape) -- both of which the redactor should
    # have stripped if they ever leaked. We only flag the literal
    # values we provisioned, since the CLI legitimately prints other
    # short hex/base64-ish identifiers.
    assert not re.search(r"[0-9a-f]{64}", out) or cache_with_bundle["signing_pubkey_hex"] not in out
