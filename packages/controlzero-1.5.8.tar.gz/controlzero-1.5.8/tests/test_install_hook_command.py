"""Regression tests for the Claude Code / Gemini CLI / Codex CLI installer
hook command (1.5.2 customer fix).

Two invariants the installer MUST satisfy:

1. The `command` field in the agent settings JSON is plain
   ``controlzero hook-check``. It MUST NOT contain the customer api
   key. Embedding ``CONTROLZERO_API_KEY=cz_live_... controlzero
   hook-check`` was a portability bug: bash parses the env-prefix,
   PowerShell / cmd.exe do not, so the hook subprocess failed to
   spawn on Windows and a customer's Claude Code instance never
   delivered audit logs (2026-05-12 incident).
2. The api key is persisted to ``~/.controlzero/config.yaml`` so the
   hook subprocess can pick it up at runtime via the
   ``cli/main.py:hook_check`` env-fallback path.

The test runs the installer via the click CLI runner with a synthetic
HOME directory so the assertions can read both files back.
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest
import yaml
from click.testing import CliRunner

from controlzero.cli.main import cli


LIVE_KEY = "cz_live_aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
TEST_KEY = "cz_test_bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb"


def _read_pretooluse_command(settings_path: Path) -> str:
    data = json.loads(settings_path.read_text())
    blocks = data["hooks"]["PreToolUse"]
    # Find the controlzero block (idempotent installer keeps a single
    # block; tests assert the singular contract).
    cz_blocks = [
        b
        for b in blocks
        if any("controlzero hook-check" in h.get("command", "") for h in b.get("hooks", []))
    ]
    assert len(cz_blocks) == 1, f"expected one controlzero hook block, got {cz_blocks}"
    return cz_blocks[0]["hooks"][0]["command"]


@pytest.mark.parametrize("api_key", [LIVE_KEY, TEST_KEY])
def test_install_claude_code_writes_clean_hook_command(api_key, tmp_path, monkeypatch):
    monkeypatch.setenv("HOME", str(tmp_path))
    # Force the controlzero state dir to match the synthetic HOME so
    # _write_api_key_config and the settings.json patch both land
    # inside tmp_path.
    monkeypatch.setattr(
        "controlzero.cli.main.GLOBAL_POLICY_DIR",
        tmp_path / ".controlzero",
    )
    monkeypatch.setattr(
        "controlzero.cli.main.GLOBAL_POLICY_PATH",
        tmp_path / ".controlzero" / "policy.yaml",
    )
    monkeypatch.setattr(
        "controlzero.cli.main.GLOBAL_CONFIG_PATH",
        tmp_path / ".controlzero" / "config.yaml",
    )
    monkeypatch.setattr(
        "controlzero.cli.main.GLOBAL_AUDIT_PATH",
        tmp_path / ".controlzero" / "audit.log",
    )

    settings_path = tmp_path / ".claude" / "settings.json"

    runner = CliRunner()
    result = runner.invoke(
        cli,
        [
            "install",
            "claude-code",
            "--api-key",
            api_key,
            "--settings",
            str(settings_path),
            "--force",
        ],
    )
    assert result.exit_code == 0, result.output

    # Invariant 1: hook command MUST NOT embed the api key. Plain
    # `controlzero hook-check` is the only acceptable shape.
    command = _read_pretooluse_command(settings_path)
    assert command == "controlzero hook-check", (
        f"hook command leaked api_key or shell-only syntax: {command!r}"
    )
    assert "cz_live_" not in command
    assert "cz_test_" not in command
    assert "CONTROLZERO_API_KEY=" not in command

    # Invariant 2: api key MUST be persisted to config.yaml so the
    # hook subprocess can resolve it without an env-prefix.
    config_path = tmp_path / ".controlzero" / "config.yaml"
    assert config_path.exists(), "_write_api_key_config did not run"
    cfg = yaml.safe_load(config_path.read_text())
    assert cfg["api_key"] == api_key, "config.yaml api_key mismatch"


def test_detect_client_name_default_is_python_sdk(monkeypatch):
    # 1.5.2 default-emission fix: when no agent-runtime env vars are
    # set, detect_client_name() must return the canonical
    # `python-sdk` alias so the backend NormalizeSource pipeline
    # resolves it to SourcePythonSDK instead of SourceUnknown (which
    # the dashboard renders as `--`).
    for var in (
        "CONTROLZERO_CLIENT",
        "CLAUDECODE",
        "CLAUDE_CODE",
        "CODEX_HOME",
        "CODEX_PROFILE",
        "CODEX_CLI",
        "CURSOR_TRACE_ID",
        "CURSOR_AGENT",
        "CURSOR_USER_AGENT",
        "TERM_PROGRAM",
        "WINDSURF_AGENT",
        "WINDSURF_SESSION_ID",
        "GEMINI_CLI",
        "GEMINI_SANDBOX",
        "GEMINI_SYSTEM_MD",
    ):
        monkeypatch.delenv(var, raising=False)

    # Reset the module-level cache so the function actually re-runs.
    import controlzero.device as device

    monkeypatch.setattr(device, "_client_name_cache", None)

    assert device.detect_client_name() == "python-sdk"
