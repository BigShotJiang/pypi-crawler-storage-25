"""Tests for PolicyEvaluator.evaluate() with rule.conditions.

Covers:
1.  Conditions with glob pattern allows when tag matches.
2.  Same rule denies (fails through to fail-closed) when tag mismatches.
3.  Missing condition key on context/args denies.
4.  Multi-key conditions: all must match.
5.  Conditions read from args when context is absent.
6.  Conditions read from context["tags"] nested dict.
7.  Glob "prod*" matches "production".
8.  Wildcard "*" matches any non-null value.
9.  No conditions on rule: rule always matches the conditions phase.
10. Combined action + resource + conditions all must match.
"""

from __future__ import annotations


from controlzero._internal.enforcer import PolicyEvaluator
from controlzero._internal.types import PolicyRule


def _rule(
    effect: str = "allow",
    actions=None,
    resources=None,
    conditions=None,
    rid: str = "r1",
) -> PolicyRule:
    return PolicyRule(
        id=rid,
        effect=effect,
        actions=actions or ["*:*"],
        resources=resources or [],
        conditions=conditions or {},
    )


# 1. Rule with conditions: {agent_id: "research-*"} allows when context.agent_id matches
def test_conditions_glob_allows_matching_agent_id() -> None:
    ev = PolicyEvaluator(
        [_rule(effect="allow", conditions={"agent_id": "research-*"})]
    )
    decision = ev.evaluate(
        "tool", "call", context={"agent_id": "research-1"}
    )
    assert decision.allowed, decision.reason


# 2. Same rule denies when agent_id does not match (fail-closed: no matching rule)
def test_conditions_glob_denies_non_matching_agent_id() -> None:
    ev = PolicyEvaluator(
        [_rule(effect="allow", conditions={"agent_id": "research-*"})]
    )
    decision = ev.evaluate(
        "tool", "call", context={"agent_id": "support-1"}
    )
    assert decision.denied
    assert "fail-closed" in (decision.reason or "").lower()


# 3. Denies when agent_id missing entirely
def test_conditions_missing_key_denies() -> None:
    ev = PolicyEvaluator(
        [_rule(effect="allow", conditions={"agent_id": "research-*"})]
    )
    decision = ev.evaluate("tool", "call", context={})
    assert decision.denied


# 4. Multi-key conditions: all must match
def test_multi_key_conditions_all_must_match() -> None:
    ev = PolicyEvaluator(
        [
            _rule(
                effect="allow",
                conditions={"agent_id": "research-*", "environment": "prod"},
            )
        ]
    )
    # First key matches, second does not -> deny
    decision = ev.evaluate(
        "tool",
        "call",
        context={"agent_id": "research-1", "environment": "dev"},
    )
    assert decision.denied

    # Both match -> allow
    decision = ev.evaluate(
        "tool",
        "call",
        context={"agent_id": "research-1", "environment": "prod"},
    )
    assert decision.allowed


# 5. Conditions read from args when context is absent
def test_conditions_read_from_args() -> None:
    ev = PolicyEvaluator(
        [_rule(effect="allow", conditions={"agent_id": "research-*"})]
    )
    decision = ev.evaluate(
        "tool", "call", args={"agent_id": "research-42"}
    )
    assert decision.allowed


# 6. Conditions read from context["tags"] nested dict
def test_conditions_read_from_context_tags_nested() -> None:
    ev = PolicyEvaluator(
        [_rule(effect="allow", conditions={"agent_id": "research-*"})]
    )
    decision = ev.evaluate(
        "tool",
        "call",
        context={"tags": {"agent_id": "research-7"}},
    )
    assert decision.allowed


# 7. Glob "prod*" matches "production"
def test_conditions_glob_production() -> None:
    ev = PolicyEvaluator(
        [_rule(effect="allow", conditions={"environment": "prod*"})]
    )
    decision = ev.evaluate(
        "tool", "call", context={"environment": "production"}
    )
    assert decision.allowed


# 8. Wildcard "*" matches any non-null value
def test_conditions_wildcard_matches_any_non_null() -> None:
    ev = PolicyEvaluator(
        [_rule(effect="allow", conditions={"agent_id": "*"})]
    )
    decision = ev.evaluate(
        "tool", "call", context={"agent_id": "anything"}
    )
    assert decision.allowed

    # Missing key still fails (value is None)
    decision = ev.evaluate("tool", "call", context={})
    assert decision.denied


# 9. No conditions on rule: rule always matches conditions phase
def test_no_conditions_rule_always_matches() -> None:
    ev = PolicyEvaluator(
        [_rule(effect="allow", conditions={})]
    )
    decision = ev.evaluate("tool", "call", context={})
    assert decision.allowed
    decision2 = ev.evaluate("tool", "call")
    assert decision2.allowed


# 10. Combined action + resource + conditions all must match
def test_combined_action_resource_conditions() -> None:
    ev = PolicyEvaluator(
        [
            _rule(
                effect="allow",
                actions=["llm:generate"],
                resources=["model/gpt-*"],
                conditions={"agent_id": "research-*"},
            )
        ]
    )
    # All three match -> allow
    decision = ev.evaluate(
        "llm",
        "generate",
        context={"resource": "model/gpt-5", "agent_id": "research-1"},
    )
    assert decision.allowed, decision.reason

    # Action mismatch -> deny
    decision = ev.evaluate(
        "embedding",
        "generate",
        context={"resource": "model/gpt-5", "agent_id": "research-1"},
    )
    assert decision.denied

    # Resource mismatch -> deny
    decision = ev.evaluate(
        "llm",
        "generate",
        context={"resource": "model/claude-opus-4", "agent_id": "research-1"},
    )
    assert decision.denied

    # Condition mismatch -> deny
    decision = ev.evaluate(
        "llm",
        "generate",
        context={"resource": "model/gpt-5", "agent_id": "support-1"},
    )
    assert decision.denied
