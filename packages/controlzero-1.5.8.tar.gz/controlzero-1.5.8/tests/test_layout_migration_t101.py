"""Tests for the T101 SDK_LOCAL_LAYOUT migration shim.

Behaviour the shim must guarantee:
  - When ``events.log`` exists, its lines are folded into ``audit.log``.
  - A single ``layout_migration`` lifecycle marker is appended after the
    migrated lines so support can grep for the migration.
  - ``events.log`` is deleted after a successful migration.
  - Re-running the shim is a no-op when ``events.log`` is absent.
  - Disk failures and malformed lines never raise.
"""

from __future__ import annotations

import json
from pathlib import Path


from controlzero.layout_migration import run_layout_migration


def test_no_op_when_events_log_absent(tmp_path: Path):
    # State dir doesn't exist yet -- the shim must still be safe to call.
    state = tmp_path / ".controlzero"
    count = run_layout_migration(state, sdk_version="1.5.5")
    assert count == 0
    assert not (state / "audit.log").exists()


def test_migrates_events_log_into_audit_log(tmp_path: Path):
    state = tmp_path / ".controlzero"
    state.mkdir()

    events = state / "events.log"
    events.write_text(
        '{"event_type":"unenrolled_first_run_allow","tool_name":"Read"}\n'
        '{"event_type":"unenrolled_first_run_allow","tool_name":"Edit"}\n'
        '{"event_type":"local_override","reason":"debug"}\n',
        encoding="utf-8",
    )

    count = run_layout_migration(state, sdk_version="1.5.5")
    assert count == 3
    assert not events.exists()

    audit = state / "audit.log"
    assert audit.exists()
    lines = audit.read_text(encoding="utf-8").strip().splitlines()
    # 3 migrated lines + 1 marker
    assert len(lines) == 4

    marker = json.loads(lines[-1])
    assert marker["kind"] == "lifecycle"
    assert marker["event_type"] == "layout_migration"
    assert marker["from"] == "events.log"
    assert marker["to"] == "audit.log"
    assert marker["sdk"] == "python"
    assert marker["sdk_version"] == "1.5.5"
    assert marker["lines_migrated"] == 3


def test_idempotent_second_run(tmp_path: Path):
    state = tmp_path / ".controlzero"
    state.mkdir()
    events = state / "events.log"
    events.write_text('{"a":1}\n', encoding="utf-8")

    first = run_layout_migration(state, sdk_version="x")
    second = run_layout_migration(state, sdk_version="x")
    assert first == 1
    assert second == 0

    audit = state / "audit.log"
    lines = audit.read_text(encoding="utf-8").strip().splitlines()
    # Exactly one migrated line + one marker. The second run must not
    # add a second marker.
    assert len(lines) == 2


def test_preserves_existing_audit_log_content(tmp_path: Path):
    state = tmp_path / ".controlzero"
    state.mkdir()
    (state / "audit.log").write_text(
        '{"existing":"row"}\n', encoding="utf-8"
    )
    (state / "events.log").write_text(
        '{"migrated":"row"}\n', encoding="utf-8"
    )

    run_layout_migration(state, sdk_version="x")

    lines = (state / "audit.log").read_text(encoding="utf-8").strip().splitlines()
    assert len(lines) == 3
    assert json.loads(lines[0]) == {"existing": "row"}
    assert json.loads(lines[1]) == {"migrated": "row"}
    assert json.loads(lines[2])["event_type"] == "layout_migration"


def test_empty_events_log(tmp_path: Path):
    state = tmp_path / ".controlzero"
    state.mkdir()
    (state / "events.log").write_text("", encoding="utf-8")

    count = run_layout_migration(state, sdk_version="x")
    assert count == 0
    # File is gone, marker still written so support sees the migration
    # ran (since events.log existed at start).
    assert not (state / "events.log").exists()
    audit = state / "audit.log"
    assert audit.exists()
    marker = json.loads(audit.read_text(encoding="utf-8").strip())
    assert marker["event_type"] == "layout_migration"
    assert marker["lines_migrated"] == 0


def test_blank_lines_are_skipped(tmp_path: Path):
    state = tmp_path / ".controlzero"
    state.mkdir()
    (state / "events.log").write_text(
        '{"a":1}\n\n   \n{"b":2}\n', encoding="utf-8"
    )

    count = run_layout_migration(state, sdk_version="x")
    assert count == 2


def test_never_raises_on_unwritable_dir(tmp_path: Path, monkeypatch):
    # Even if the audit.log write blows up, the shim must swallow the
    # exception and return 0. We simulate by pointing state_dir at a
    # path whose parent is a file (mkdir will fail).
    blocker = tmp_path / "blocker"
    blocker.write_text("not a directory", encoding="utf-8")
    state = blocker / "subdir"
    # state.mkdir() will fail because blocker is a file. The shim must
    # not propagate -- and since events.log can never exist under a
    # non-directory path, the shim returns 0 cleanly.
    assert run_layout_migration(state, sdk_version="x") == 0


def test_client_init_triggers_migration(tmp_path: Path, monkeypatch):
    # Ensure Client construction runs the shim via CONTROLZERO_HOME.
    cz_home = tmp_path / "home"
    cz_home.mkdir()
    (cz_home / "events.log").write_text(
        '{"event_type":"unenrolled_first_run_allow"}\n', encoding="utf-8"
    )
    monkeypatch.setenv("CONTROLZERO_HOME", str(cz_home))
    monkeypatch.delenv("CONTROLZERO_API_KEY", raising=False)

    from controlzero import Client
    # Policy validator requires >= 1 rule. Reuse the shape other test
    # modules use; the rule body is irrelevant -- the point is the
    # migration shim runs inside __init__.
    Client(policy={"rules": [{"allow": "*", "reason": "test fixture"}]})

    assert not (cz_home / "events.log").exists()
    audit = cz_home / "audit.log"
    assert audit.exists()
    lines = audit.read_text(encoding="utf-8").strip().splitlines()
    assert json.loads(lines[-1])["event_type"] == "layout_migration"
