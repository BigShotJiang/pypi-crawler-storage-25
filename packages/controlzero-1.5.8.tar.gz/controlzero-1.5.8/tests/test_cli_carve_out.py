"""Tests for the #228 Phase 2 unenrolled first-run carve-out.

Spec (user-approved, pinned here so a future refactor does not
regress):

  - When the hook-check CLI runs AND the machine has neither a
    CONTROLZERO_API_KEY env var NOR an ~/.controlzero/enrollment.json
    file, exit 0, emit a loud banner on stderr, and log the event
    to ~/.controlzero/events.log so `controlzero status` can
    surface it.
  - The moment either signal appears, the carve-out stops applying
    and the normal default_on_missing logic takes over.
  - JSON output adds a "reason_code" key (RULE_MATCH on the
    carve-out path, BUNDLE_MISSING when enrolled-but-no-policy,
    MACHINE_QUARANTINED when quarantined).

These tests drive the CLI via click's CliRunner and patch
GLOBAL_POLICY_DIR so each test is hermetic.
"""

from __future__ import annotations

import importlib
import json
from pathlib import Path

import yaml
from click.testing import CliRunner


def _reload_cli(tmp_path: Path, monkeypatch):
    """Rebuild the CLI module with a patched GLOBAL_POLICY_DIR.

    Re-importing is the cleanest way to isolate tests: the module
    caches Path objects at import time (GLOBAL_POLICY_DIR,
    GLOBAL_POLICY_PATH, etc.) and we want them pointed at the test
    tmp dir so we do not touch ~/.controlzero in CI.

    Also chdir to a fresh isolated directory so `_has_resolvable_
    policy_file()` does not pick up a stray ./controlzero.yaml
    from whatever directory pytest was launched in.
    """
    cz_dir = tmp_path / "cz"
    cz_dir.mkdir(parents=True, exist_ok=True)
    work_dir = tmp_path / "work"
    work_dir.mkdir(parents=True, exist_ok=True)
    monkeypatch.chdir(work_dir)
    monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)
    import controlzero.cli.main as cli_main
    importlib.reload(cli_main)
    return cli_main


# ---- carve-out: unenrolled first-run -------------------------------------


def test_carve_out_no_api_key_no_enrollment_allows(tmp_path, monkeypatch):
    """Unenrolled first-run -> exit 0, banner on stderr, JSON
    reason_code=RULE_MATCH.
    """
    cli_main = _reload_cli(tmp_path, monkeypatch)
    runner = CliRunner()
    payload = json.dumps({"tool_name": "Bash", "tool_input": {"command": "ls"}})
    result = runner.invoke(cli_main.cli, ["hook-check"], input=payload)

    assert result.exit_code == 0, result.output
    # Banner must appear in stderr (mixed into output by CliRunner).
    assert "Not enrolled" in result.output
    assert "controlzero login" in result.output

    # JSON must carry the new reason_code key.
    json_lines = [ln for ln in result.output.splitlines() if ln.startswith("{")]
    assert len(json_lines) >= 1
    decision = json.loads(json_lines[0])
    # 1.5.3 adapter base: payload has no Claude Code signature -> falls
    # through to UnknownHostAdapter which omits `decision` on allow
    # (universal-proceed signal). Test pins the meaningful contract
    # (reason_code + reason present), not the now-adapter-dependent
    # decision string.
    assert decision.get("decision") in (None, "approve", "allow"), (
        f"unexpected decision: {decision.get('decision')!r}"
    )
    assert decision["reason_code"] == "RULE_MATCH"


def test_carve_out_logs_event_for_status(tmp_path, monkeypatch):
    """Carve-out runs must append a JSON line to the audit log so
    `controlzero status` can report the count.

    1.5.4 (T96 / SDK_LOCAL_LAYOUT): lifecycle events now land in
    audit.log alongside decisions, not in a separate events.log.
    """
    cli_main = _reload_cli(tmp_path, monkeypatch)
    runner = CliRunner()
    payload = json.dumps({"tool_name": "Bash", "tool_input": {}})
    runner.invoke(cli_main.cli, ["hook-check"], input=payload)

    audit_path = cli_main.GLOBAL_AUDIT_PATH
    assert audit_path.exists(), (
        "T96: lifecycle events must land in audit.log after 1.5.4"
    )
    lines = [
        ln for ln in audit_path.read_text().splitlines()
        if ln.strip() and "unenrolled_first_run_allow" in ln
    ]
    assert len(lines) == 1
    ev = json.loads(lines[0])
    assert ev["event"] == "unenrolled_first_run_allow"
    assert ev["tool_name"] == "Bash"
    assert ev["reason_code"] == "RULE_MATCH"


def test_carve_out_suppressed_when_api_key_set(tmp_path, monkeypatch):
    """API key in env -> carve-out stops applying. Even with no
    policy file, the normal BUNDLE_MISSING path takes over and
    denies (canonical default_on_missing).
    """
    monkeypatch.setenv("CONTROLZERO_API_KEY", "cz_test_fake")
    cli_main = _reload_cli(tmp_path, monkeypatch)
    runner = CliRunner()
    payload = json.dumps({"tool_name": "Bash", "tool_input": {}})
    result = runner.invoke(cli_main.cli, ["hook-check"], input=payload)

    # BUNDLE_MISSING -> canonical deny -> exit 2.
    assert result.exit_code == 2
    # Banner must NOT appear now that the user has a key.
    assert "Not enrolled" not in result.output

    json_lines = [ln for ln in result.output.splitlines() if ln.startswith("{")]
    decision = json.loads(json_lines[0])
    assert decision["decision"] == "block"
    assert decision["reason_code"] == "BUNDLE_MISSING"


def test_carve_out_suppressed_when_enrollment_exists(tmp_path, monkeypatch):
    """An enrollment.json file on disk -> carve-out off. Same
    BUNDLE_MISSING path.
    """
    cli_main = _reload_cli(tmp_path, monkeypatch)
    enrollment = cli_main.GLOBAL_POLICY_DIR / "enrollment.json"
    enrollment.parent.mkdir(parents=True, exist_ok=True)
    enrollment.write_text(json.dumps({
        "machine_id": "m1",
        "org_id": "o1",
        "api_url": "https://api.controlzero.ai",
        "hostname": "h",
        "fingerprint_hint": "fp",
        "machine_pubkey_pem": "-----BEGIN PUBLIC KEY-----\n...",
        "enrolled_at": "2026-04-20T00:00:00Z",
    }))

    runner = CliRunner()
    payload = json.dumps({"tool_name": "Bash", "tool_input": {}})
    result = runner.invoke(cli_main.cli, ["hook-check"], input=payload)

    assert result.exit_code == 2
    assert "Not enrolled" not in result.output
    json_lines = [ln for ln in result.output.splitlines() if ln.startswith("{")]
    decision = json.loads(json_lines[0])
    assert decision["reason_code"] == "BUNDLE_MISSING"


def test_carve_out_suppressed_when_policy_supplied_explicitly(tmp_path, monkeypatch):
    """Power users who pass ``--policy`` are opting into enforcement
    even without enrollment; the carve-out must step aside so their
    rules actually apply. Regression guard for pre-Phase 2 test
    fixtures that depend on --policy working without
    enrollment.json.
    """
    cli_main = _reload_cli(tmp_path, monkeypatch)
    policy_path = tmp_path / "policy.yaml"
    policy_path.write_text(yaml.safe_dump({
        "version": "1",
        "rules": [{"deny": "Bash"}, {"allow": "*"}],
    }))
    runner = CliRunner()
    payload = json.dumps({"tool_name": "Bash", "tool_input": {}})
    result = runner.invoke(
        cli_main.cli,
        ["hook-check", "--policy", str(policy_path)],
        input=payload,
    )
    # The explicit policy's deny Bash rule must fire; carve-out
    # banner must NOT appear.
    assert result.exit_code == 2
    assert "Not enrolled" not in result.output


def test_carve_out_suppressed_when_project_controlzero_yaml_exists(tmp_path, monkeypatch):
    """A ./controlzero.yaml in the agent's cwd is enough signal that
    the user is past first-run, even without a key or enrollment.
    """
    cli_main = _reload_cli(tmp_path, monkeypatch)
    # The _reload_cli helper already chdir'd to tmp_path/work. Drop
    # a controlzero.yaml in that work dir.
    import os as _os
    cwd_policy = Path(_os.getcwd()) / "controlzero.yaml"
    cwd_policy.write_text(yaml.safe_dump({
        "version": "1",
        "rules": [{"allow": "*"}],
    }))
    runner = CliRunner()
    payload = json.dumps({"tool_name": "Bash", "tool_input": {}})
    result = runner.invoke(cli_main.cli, ["hook-check"], input=payload)
    assert result.exit_code == 0
    assert "Not enrolled" not in result.output


def test_carve_out_suppressed_when_config_yaml_has_api_key(tmp_path, monkeypatch):
    """API key in ~/.controlzero/config.yaml also counts -- that's
    the path `controlzero install claude-code --api-key ...` writes.
    """
    cli_main = _reload_cli(tmp_path, monkeypatch)
    config_path = cli_main.GLOBAL_POLICY_DIR / "config.yaml"
    config_path.parent.mkdir(parents=True, exist_ok=True)
    config_path.write_text(yaml.safe_dump({"api_key": "cz_test_fake"}))

    runner = CliRunner()
    payload = json.dumps({"tool_name": "Bash", "tool_input": {}})
    result = runner.invoke(cli_main.cli, ["hook-check"], input=payload)

    assert "Not enrolled" not in result.output


# ---- BUNDLE_MISSING: enrolled but no policy file -------------------------


def test_bundle_missing_emits_reason_code(tmp_path, monkeypatch):
    """With an API key + invalid key, hosted load fails; deny + BUNDLE_MISSING.

    T103 (2026-05-12): hook-check now uses Client(api_key=...) directly,
    so a fake/unreachable key fails the hosted load instead of taking
    the pre-T103 "no file found" path. reason_code stays BUNDLE_MISSING
    so dashboards continue to distinguish this from a user-rule deny.
    The reason TEXT is now "Hosted policy load failed: ..." because that
    is what actually happened (the api_key was rejected).
    """
    monkeypatch.setenv("CONTROLZERO_API_KEY", "cz_test_fake")
    # Point the SDK at an unreachable host so hosted load deterministically
    # fails without hitting a real network. Tests must not depend on the
    # real backend being reachable.
    monkeypatch.setenv("CONTROLZERO_API_URL", "http://127.0.0.1:1")
    cli_main = _reload_cli(tmp_path, monkeypatch)
    runner = CliRunner()
    payload = json.dumps({"tool_name": "Bash", "tool_input": {}})
    result = runner.invoke(cli_main.cli, ["hook-check"], input=payload)

    assert result.exit_code == 2
    json_lines = [ln for ln in result.output.splitlines() if ln.startswith("{")]
    decision = json.loads(json_lines[0])
    assert decision["decision"] == "block"
    assert decision["reason_code"] == "BUNDLE_MISSING"
    # The message names the failure cleanly; either "Hosted policy load
    # failed" (new path) or "No policy bundle available" (legacy path for
    # users who set LOCAL_OVERRIDE=1 without a file).
    assert (
        "Hosted policy load failed" in decision["reason"]
        or "No policy bundle available" in decision["reason"]
    )


# ---- JSON shape: reason_code key strictly additive -----------------------


def test_hook_check_allow_json_includes_reason_code(tmp_path, monkeypatch):
    """Allow path must carry reason_code in JSON output (strictly
    additive -- existing 'decision' and 'reason' keys stay).
    """
    monkeypatch.setenv("CONTROLZERO_API_KEY", "cz_test_fake")
    cli_main = _reload_cli(tmp_path, monkeypatch)
    # Create a permissive policy so the evaluator allows.
    policy_path = tmp_path / "policy.yaml"
    policy_path.write_text(yaml.safe_dump(
        {"version": "1", "rules": [{"allow": "*"}]}
    ))
    runner = CliRunner()
    payload = json.dumps({"tool_name": "Bash", "tool_input": {}})
    result = runner.invoke(
        cli_main.cli,
        ["hook-check", "--policy", str(policy_path)],
        input=payload,
    )

    assert result.exit_code == 0
    json_lines = [ln for ln in result.output.splitlines() if ln.startswith("{")]
    assert json_lines, f"no JSON output found: {result.output!r}"
    decision = json.loads(json_lines[0])
    # 1.5.3 adapter base: see note in
    # test_first_run_unenrolled_emits_banner_and_allows for the
    # decision-key contract change.
    assert decision.get("decision") in (None, "approve", "allow"), (
        f"unexpected decision: {decision.get('decision')!r}"
    )
    assert "reason" in decision
    # New key (additive).
    assert decision["reason_code"] == "RULE_MATCH"


def test_hook_check_deny_json_includes_reason_code(tmp_path, monkeypatch):
    """Deny path also carries reason_code. RULE_MATCH for a user-
    authored deny rule.
    """
    monkeypatch.setenv("CONTROLZERO_API_KEY", "cz_test_fake")
    cli_main = _reload_cli(tmp_path, monkeypatch)
    policy_path = tmp_path / "policy.yaml"
    policy_path.write_text(yaml.safe_dump({
        "version": "1",
        "rules": [
            {"deny": "Bash", "reason": "no shell"},
            {"allow": "*"},
        ],
    }))
    runner = CliRunner()
    payload = json.dumps({"tool_name": "Bash", "tool_input": {}})
    result = runner.invoke(
        cli_main.cli,
        ["hook-check", "--policy", str(policy_path)],
        input=payload,
    )

    assert result.exit_code == 2
    json_lines = [ln for ln in result.output.splitlines() if ln.startswith("{")]
    decision = json.loads(json_lines[0])
    assert decision["decision"] == "block"
    assert decision["reason_code"] == "RULE_MATCH"


def test_hook_check_no_rule_match_json_reason_code(tmp_path, monkeypatch):
    """Fall-through deny from the evaluator must surface
    reason_code=NO_RULE_MATCH (distinct from RULE_MATCH and from
    BUNDLE_MISSING).
    """
    monkeypatch.setenv("CONTROLZERO_API_KEY", "cz_test_fake")
    cli_main = _reload_cli(tmp_path, monkeypatch)
    policy_path = tmp_path / "policy.yaml"
    # Only one rule that does NOT cover our call.
    policy_path.write_text(yaml.safe_dump({
        "version": "1",
        "rules": [{"allow": "Read"}],
    }))
    runner = CliRunner()
    payload = json.dumps({"tool_name": "Bash", "tool_input": {}})
    result = runner.invoke(
        cli_main.cli,
        ["hook-check", "--policy", str(policy_path)],
        input=payload,
    )

    assert result.exit_code == 2
    json_lines = [ln for ln in result.output.splitlines() if ln.startswith("{")]
    decision = json.loads(json_lines[0])
    assert decision["reason_code"] == "NO_RULE_MATCH"


def test_hook_check_default_action_allow_in_policy_yaml(tmp_path, monkeypatch):
    """settings.default_action=allow in the YAML must flip the
    no-match path from deny to allow in hook-check output.
    """
    monkeypatch.setenv("CONTROLZERO_API_KEY", "cz_test_fake")
    cli_main = _reload_cli(tmp_path, monkeypatch)
    policy_path = tmp_path / "policy.yaml"
    policy_path.write_text(yaml.safe_dump({
        "version": "1",
        "settings": {"default_action": "allow"},
        "rules": [{"deny": "Bash"}],
    }))
    runner = CliRunner()
    payload = json.dumps({"tool_name": "Read", "tool_input": {}})  # not in rules
    result = runner.invoke(
        cli_main.cli,
        ["hook-check", "--policy", str(policy_path)],
        input=payload,
    )

    assert result.exit_code == 0, result.output
    json_lines = [ln for ln in result.output.splitlines() if ln.startswith("{")]
    decision = json.loads(json_lines[0])
    # 1.5.3 adapter base: see note in
    # test_first_run_unenrolled_emits_banner_and_allows.
    assert decision.get("decision") in (None, "approve", "allow"), (
        f"unexpected decision: {decision.get('decision')!r}"
    )
    assert decision["reason_code"] == "NO_RULE_MATCH"


# ---- status command ------------------------------------------------------


def test_status_shows_unenrolled_allow_all_mode(tmp_path, monkeypatch):
    """`controlzero status` must report the carve-out is active when
    no api key and no enrollment.json exist.
    """
    cli_main = _reload_cli(tmp_path, monkeypatch)
    runner = CliRunner()
    result = runner.invoke(cli_main.cli, ["status"])

    assert result.exit_code == 0
    assert "UNENROLLED ALLOW-ALL" in result.output
    assert "carve-out active" in result.output


def test_status_shows_enforcing_when_api_key_present(tmp_path, monkeypatch):
    """API key present -> status reports ENFORCING, not the carve-
    out banner.
    """
    monkeypatch.setenv("CONTROLZERO_API_KEY", "cz_test_fake")
    cli_main = _reload_cli(tmp_path, monkeypatch)
    runner = CliRunner()
    result = runner.invoke(cli_main.cli, ["status"])

    assert "ENFORCING" in result.output
    assert "UNENROLLED" not in result.output


def test_status_surfaces_carve_out_event_count(tmp_path, monkeypatch):
    """After the carve-out fires N times, status must report N
    carve-out allows plus recent tool names for triage.
    """
    cli_main = _reload_cli(tmp_path, monkeypatch)
    runner = CliRunner()
    for tool_name in ["ToolA", "ToolB", "ToolC", "ToolD"]:
        runner.invoke(
            cli_main.cli,
            ["hook-check"],
            input=json.dumps({"tool_name": tool_name}),
        )

    result = runner.invoke(cli_main.cli, ["status"])
    assert "carve-out allows: 4" in result.output
    # Last 3 shown for triage.
    assert "ToolD" in result.output
    assert "ToolC" in result.output
    assert "ToolB" in result.output


def test_status_handles_missing_events_log_gracefully(tmp_path, monkeypatch):
    """No events.log -> status prints normally without a carve-out
    summary. Must not raise.
    """
    cli_main = _reload_cli(tmp_path, monkeypatch)
    runner = CliRunner()
    result = runner.invoke(cli_main.cli, ["status"])
    assert result.exit_code == 0


def test_status_handles_corrupt_events_log(tmp_path, monkeypatch):
    """A damaged events.log must not crash status. Best-effort is
    the contract (we never want `status` to raise on the user).
    """
    cli_main = _reload_cli(tmp_path, monkeypatch)
    cli_main.GLOBAL_POLICY_DIR.mkdir(parents=True, exist_ok=True)
    cli_main.GLOBAL_EVENTS_PATH.write_text("this is not json\n")
    runner = CliRunner()
    result = runner.invoke(cli_main.cli, ["status"])
    assert result.exit_code == 0


# ---- helper function unit tests ------------------------------------------


def test_is_unenrolled_first_run_detects_bare_install(tmp_path, monkeypatch):
    """Fresh install (no key, no enrollment) -> True."""
    cli_main = _reload_cli(tmp_path, monkeypatch)
    assert cli_main._is_unenrolled_first_run() is True


def test_is_unenrolled_first_run_detects_env_api_key(tmp_path, monkeypatch):
    """API key in env -> False."""
    monkeypatch.setenv("CONTROLZERO_API_KEY", "cz_test_fake")
    cli_main = _reload_cli(tmp_path, monkeypatch)
    assert cli_main._is_unenrolled_first_run() is False


def test_is_unenrolled_first_run_detects_enrollment_file(tmp_path, monkeypatch):
    """enrollment.json on disk -> False."""
    cli_main = _reload_cli(tmp_path, monkeypatch)
    cli_main.GLOBAL_POLICY_DIR.mkdir(parents=True, exist_ok=True)
    (cli_main.GLOBAL_POLICY_DIR / "enrollment.json").write_text("{}")
    assert cli_main._is_unenrolled_first_run() is False


def test_is_unenrolled_first_run_handles_unreadable_config(tmp_path, monkeypatch):
    """Corrupt config.yaml -> treat as no key, carve-out stays
    active (fail-open on the carve-out itself).
    """
    cli_main = _reload_cli(tmp_path, monkeypatch)
    cli_main.GLOBAL_POLICY_DIR.mkdir(parents=True, exist_ok=True)
    (cli_main.GLOBAL_POLICY_DIR / "config.yaml").write_text("[[broken yaml")
    assert cli_main._is_unenrolled_first_run() is True


def test_append_event_is_resilient_to_disk_failure(tmp_path, monkeypatch):
    """_append_event must never raise. If the events dir is
    somehow unwritable, the helper swallows the error -- the
    agent must keep working.
    """
    cli_main = _reload_cli(tmp_path, monkeypatch)
    # Point at a path whose parent is a file (write will fail).
    blocker = tmp_path / "blocker"
    blocker.write_text("i am a file not a dir")
    monkeypatch.setattr(cli_main, "GLOBAL_EVENTS_PATH", blocker / "events.log")
    # Must not raise.
    cli_main._append_event({"event": "x"})


def test_resolve_default_on_missing_returns_canonical_deny(tmp_path, monkeypatch):
    """Phase 2 resolver always returns the canonical backend
    default (deny). Phase 3+ could cache per-org values; today
    this helper is deliberately a constant so the behaviour is
    predictable.
    """
    cli_main = _reload_cli(tmp_path, monkeypatch)
    assert cli_main._resolve_default_on_missing() == "deny"
