# Changelog

## v1.5.8 -- 2026-05-16 (HITL-5a, gh#538)

Additive minor preparing the SDK for the Human-in-the-Loop approval
workflow that ships in 1.6.0 (HITL-6a, gh#542). Pure additive: no
behavior change on existing policies; no new public API surface.

### Added

- **`escalate_on_deny: bool` rule key** is acknowledged. Customers may
  pre-tag deny rules for HITL eligibility; 1.5.8 persists the field
  on `PolicyRule` (default `False`). The actual `request_approval()`
  flow ships in 1.6.0; 1.5.8 ensures a customer pre-tagging rules
  doesn't crash an old client.
- **Typo guardrail** on rule keys. Unknown keys within Levenshtein-1
  of a known key (`escalate_on_dney` -> `escalate_on_deny`) now print
  a one-line "did you mean?" warning to stderr. Unknown keys far from
  any known key remain silently accepted (additive contract).
- **9 new HITL reason codes** registered in `VALID_REASON_CODES`:
  `HITL_SDK_TIMEOUT`, `HITL_SLA_EXPIRED`, `HITL_BACKEND_UNREACHABLE`,
  `HITL_POLICY_VERSION_CONFLICT`, `HITL_NO_APPROVER_AVAILABLE`,
  `HITL_IDENTITY_NOT_IN_ORG`, `HITL_IDENTITY_REQUIRED`,
  `HITL_IDENTITY_CLAIM_REJECTED`, `HITL_ARGS_HASH_MISMATCH`. 1.5.8
  itself never emits these; registration ensures a 1.6.0+ client's
  audit rows pass 1.5.8 ingest validation during a mixed-version
  rollout.

### Unchanged

- 11-line Hello World still works.
- All 156 existing SDK hook tests pass.
- No new methods on `Client` or `PolicyDecision`.
- Existing 1.5.7 policies parse identically (escalate_on_deny defaults
  to `False`; legacy keys still in `_KNOWN_RULE_KEYS`).

## v1.5.7 -- 2026-05-16 (PRIVACY)

### Fixed

- **Customer-context comments in the published wheel.** Codex +
  Gemini outside-voice review surfaced several customer-context
  strings + private monorepo path references that v1.5.6 missed:
  - `controlzero/hosted_policy.py` referenced a customer-specific
    possessive when describing the T104 cache-GC scenario. Rewritten
    in neutral phrasing that preserves the technical context.
  - `controlzero/enrollment.py` documented the wire-format contract
    via a private monorepo path. Replaced with a pointer to the
    public docs site.
  - `controlzero/cli/hosts/base.py` and
    `controlzero/cli/hosts/unknown.py` referenced an internal
    backend filename in inline comments. Replaced with a generic
    description of the constraint.
  - Tests `test_t104_cache_gc.py` and `test_t103_precedence.py`
    carried a geographic identifier and a customer-derived test
    name (NOT in the published wheel since tests are excluded, but
    scrubbed for consistency).
- **No behavior change.** Comments + docstrings only.

## v1.5.6 -- 2026-05-15 (PRIVACY)

### Fixed

- **Customer names and identifiable references removed from the
  published wheel.** Earlier 1.5.x releases (including 1.5.5)
  carried customer names and individual contributor names in inline
  comments and docstrings as historical context for past incidents.
  This release replaces every such reference with a generic
  technical description (a customer / an enterprise customer / a
  date-stamped incident label) while preserving the technical
  meaning of the comment. No behavior change. Concretely affects
  inline comments in `client.py`, `device.py`, `hosted_policy.py`,
  `enrollment.py`, `cli/main.py`, `cli/_secrets.py`, `cli/debug_bundle.py`,
  `cli/hosts/claude_code.py`, `cli/hosts/gemini_cli.py`,
  `_internal/bundle.py`, `_internal/enforcer.py`. 1.5.5 is yanked
  on PyPI.
- **Realistic-looking placeholder key in source replaced.** The
  64-hex-char `cz_live_*` string used as a docstring example and
  test fixture has been swapped for an obviously-synthetic
  `cz_live_aaaa...` placeholder. The original value was a test
  fixture, not a real customer key, but the format was close
  enough to a real key that an external reader could not tell.

## v1.5.5 -- 2026-05-15 (YANKED)

YANKED on 2026-05-15 due to customer-name leakage in inline comments.
Use 1.5.6 instead.

## Unreleased -- Tier 0a security hotfix (2026-05-15)

### Security (P0 hotfix for #174)

- **New `controlzero doctor` command**. Scans every known coding-agent
  settings file (claude-code, gemini-cli, codex-cli, cursor, windsurf,
  vscode, cline, antigravity, adal, jetbrains) for plaintext `cz_*_*`
  API keys baked into hook commands. Reports findings compiler-style
  with stable E#### error codes. Exit 1 on any ERROR finding so it
  can run in CI / pre-push hooks.
- **New `controlzero migrate` command**. Auto-rewrites every leaked
  inline hook of the form `CONTROLZERO_API_KEY=cz_live_... controlzero
hook-check` into the safe `controlzero hook-check` form, and
  persists the recovered key to `~/.controlzero/config.yaml`
  (mode 0o600, parent dir 0o700). Has `--dry-run`. Idempotent.
- **Stable error-code catalog** (`controlzero.error_codes`). 24 E####
  codes across security / auth / policy / cache / network / hook /
  runtime ranges. Each entry has title, what, fix, and a docs slug
  for the `docs.controlzero.ai/errors/` URL.
- **`controlzero telemetry`** group: `full` / `anonymous` / `off`.
  Opt-IN per the 2026-05-14 transparency mandate. Default unset =
  silent. Non-interactive shells never prompt. State in
  `~/.controlzero/telemetry.yaml` (mode 0o600).
- **Tighter local-file permissions**. `_write_api_key_config` now
  enforces 0o600 on `config.yaml` and 0o700 on the parent directory.
  Best-effort on Windows / FAT (silent skip).
- **Cross-SDK CI contract test**: `scripts/ci/check-no-key-leaks.sh`
  fails the build on any new `cz_(live|test)_*` leak surface across
  Python, Node, Go, frontend, docs.
- **Rich CLI palette**: doctor + migrate now use the DESIGN.md
  sage-green theme via `controlzero.cli.console`.

If you previously ran `controlzero install <agent>` on a version
older than 1.5.3, your agent settings file likely still contains
the plaintext key. Run `controlzero doctor` to check; run
`controlzero migrate` to fix.

## 1.5.5a1 (pre-release) -- 2026-05-13

This is a **pre-release**. `pip install control-zero` continues to
resolve to the latest stable (1.5.3). To install this alpha:

    pip install --pre control-zero
    # or pin explicitly:
    pip install control-zero==1.5.5a1

Promotion to stable `1.5.5` will follow once we have soak time on the
T96 + T101 layout changes in real customer environments.

### Added

- **`controlzero env-dump` diagnostic subcommand** (#438). Prints a
  JSON snapshot of the SDK's effective environment: env vars
  (redacted by default, `--show-secrets` to unredact with a loud
  warning), host-adapter selection, file inventory (size + mtime,
  not contents), and resolved API URL. With `--from-hook` it parses
  a stdin payload so the output reflects what the hook subprocess
  actually sees. Built for fast Windows-hook triage after the
  2026-05-12 incident -- a customer can now run a single
  command and send us the JSON instead of guessing which env vars
  their hook sees.

- **Layout migration shim** (T101, SDK_LOCAL_LAYOUT spec). Folds any
  legacy `~/.controlzero/events.log` into `audit.log` on first run of
  the CLI or first `Client()` construction, then deletes the legacy
  file. Writes a single `layout_migration` lifecycle marker into
  `audit.log` so support can grep for the migration. Idempotent and
  best-effort: a disk failure here never breaks the user's agent.
  `controlzero status` no longer reads the legacy file; the shim
  guarantees it's gone by the time any subcommand runs.

## 1.5.4 -- 2026-05-13

### Changed

- **Single-file local audit log** (T96, part of the SDK_LOCAL_LAYOUT
  spec). Pre-1.5.4 the SDK split rows across `~/.controlzero/audit.log`
  (policy-engine decisions) and `~/.controlzero/events.log` (carve-out +
  hook lifecycle). Customers had to tail two files and `cz debug bundle`
  had to merge both for support. After 1.5.4 every line lands in
  `audit.log` (JSON Lines). Lifecycle entries carry the original `event`
  key so `controlzero status` can still filter for carve-out events.
  `controlzero status` reads BOTH `audit.log` AND `events.log` (legacy
  fallback) so users upgrading from <= 1.5.3 keep seeing pre-upgrade
  history; the migration shim in a follow-up release (T101) will rename
  the legacy file in-place.

## 1.5.3 -- 2026-05-12

### Added

- **Host-agent adapter base** (`controlzero/cli/hosts/`). A pluggable
  per-host hook adapter pattern. Each adapter owns three things for
  one host runtime: `claim(payload, env) -> bool` (recognise the
  inbound hook call), `render(decision) -> dict` (translate the
  canonical CZ Decision into the host's JSON envelope), and
  `canonical_source` (backend audit alias). First adapter in
  `REGISTRY` whose `claim()` returns True owns the call; a conservative
  `UnknownHostAdapter` is the registry tail and always claims.
  Adding Cursor / Windsurf / OpenClaw / Antigravity / the next
  agent is now one file in `controlzero/cli/hosts/`, no edits to
  `cli/main.py` or `audit_remote.py`.

### Fixed

- **Claude Code policy bypass on the allow path.** Pre-1.5.3 the SDK
  emitted `{"decision": "allow", ...}` for every allow hook decision.
  Anthropic's PreToolUse hook schema only accepts `"approve" | "block"`
  -- the `"allow"` string crashed Claude Code's validator with
  `Hook JSON output validation failed - (root): Invalid input` and
  Claude Code dropped the hook decision (defaults to proceed). A customer
  saw a `Write` correctly blocked, then a `PowerShell` command bypass
  to the same intent. After 1.5.3 the Claude Code adapter renders
  allow as `"approve"` and deny as `"block"`; Gemini CLI / Codex CLI
  / unknown hosts each get their schema-correct shape. Customers who
  hit this on 1.5.2 must upgrade.
- **Source label for Claude Code hook on Windows.** Pre-1.5.3
  detection relied on `CLAUDECODE=1` which Anthropic's Windows
  launcher does not always export, so the audit row labelled the
  agent as `python-sdk`. The Claude Code adapter now claims via the
  stdin payload signature (presence of `hook_event_name` /
  `session_id` + `tool_input`) in addition to env vars, so detection
  survives env-var-stripped Windows hook subprocesses. Audit row
  SOURCE column renders `Claude Code` instead of `Python SDK`.

### Known follow-ups (not in 1.5.3)

- Canonical-tool extractor coverage for shell-mediated file
  operations (`PowerShell:New-Item`, `Bash:touch`, `Bash:rm`, etc.)
  so a single `file_write` deny rule covers both the native `Write`
  tool AND the equivalent shell command. The adapter base provides
  the right home for this in the next release.
- Wire-payload field gaps (`latency_ms`, `method_name`, `args`) on
  the `/v1/sdk/audit` endpoint. Needs paired backend change.

## 1.5.2 -- 2026-05-12

### Fixed

- **Windows Claude Code hook never delivered audit logs.** The
  installer wrote `CONTROLZERO_API_KEY=cz_live_... controlzero hook-check`
  into `~/.claude/settings.json`. The `VAR=value command` env-prefix
  is bash-only and PowerShell / cmd.exe cannot parse it, so the
  Claude Code hook subprocess failed to spawn on every PreToolUse
  call. macOS / Linux were unaffected. After 1.5.2 the hook command
  is plain `controlzero hook-check`; the api key flows through
  `~/.controlzero/config.yaml` (already written by `install --api-key`)
  on every supported platform. Side benefit: the cleartext key is
  no longer embedded in `settings.json` on disk.
- **Audit-log dashboard SOURCE column rendered `--` for direct-SDK
  rows.** `detect_client_name()` returned the generic alias `"sdk"`
  when no agent-runtime env vars were detected; the backend
  `NormalizeSource` mapped `"sdk"` to `unknown`, and the frontend
  rendered `unknown` as `--`. The default is now `"python-sdk"`,
  which the backend maps to the canonical `python_sdk` source value
  and the frontend renders as `Python SDK`.

### Customer impact

an enterprise customer admin reported on 2026-05-12 that Claude Code on
Windows was not sending any audit logs to the dashboard, while the
direct Python SDK script was sending logs without a populated
SOURCE column. Both symptoms collapse to the two fixes above.

## 1.5.1 -- 2026-05-12 (SECURITY)

### Fixed

- **API key leak in the active-source stderr notification.** The T103
  startup line `controlzero: active policy source = hosted (...)`
  printed the first 14 characters of `CONTROLZERO_API_KEY`, which for
  a `cz_live_...` or `cz_test_...` key meant 6 characters of the
  customer secret reached stderr (visible in terminals, screen shares,
  support transcripts, and CI logs). The hint is now masked to
  `cz_live_***` or `cz_test_***` so the mode is still observable but
  no secret bytes are exposed. Upgrade ASAP if you ran 1.5.0 in any
  environment where stderr is observable. 1.5.0 is yanked on PyPI.

## 1.5.0 -- 2026-05-12

### Changed (governance posture; opt-out path documented)

- **Hosted policy wins by default when `CONTROLZERO_API_KEY` is set.**
  Before 1.5: a stale local `policy.yaml` silently shadowed the
  dashboard policy. A paying customer ran for 25 days without
  enforcement because of this. After 1.5: an api_key means hosted is
  authoritative; a local file is consulted only when no api_key, or
  when `CONTROLZERO_LOCAL_OVERRIDE=1` is set explicitly as a
  debug/offline escape hatch. An explicit `policy=` / `policy_file=`
  arg passed to `Client(...)` still wins (caller is intentional) but
  emits a loud stderr warning. `strict_hosted=True` upgrades the
  warning to a `HybridModeError`. The active policy source is named
  in a single stderr line at Client init so customer support can
  debug in one glance; `CONTROLZERO_QUIET=1` silences it in CLI
  subprocess contexts.

### Added

- **Governance audit event when LOCAL_OVERRIDE is used.** Every Client
  init that bypasses the hosted bundle via
  `CONTROLZERO_LOCAL_OVERRIDE=1` emits a one-shot audit event with
  `reason_code=LOCAL_OVERRIDE_ACTIVE` to the remote audit sink. Ops
  can filter / alert on this code in the audit dashboard so a silent
  bypass is no longer possible.
- **Cache GC on api_key rotation.** On every fresh bootstrap fetch
  the SDK removes `cache/bootstrap-<scope>.json` +
  `cache/bundle-<scope>.{bin,meta}` files whose scope does NOT match
  the active api_key. Stray user files in the cache dir are
  preserved.
- **`policy.json` accepted alongside `policy.yaml`.** The cwd
  auto-detect now probes `controlzero.{yaml,yml,json}` in order.
  Schema is identical to YAML; default write is still YAML.
- New reason_code: `LOCAL_OVERRIDE_ACTIVE`. Extends the SDK
  reason-code enum from 8 to 9. Used only on lifecycle events; no
  impact on guard decisions.

### Refs

GH #424 (umbrella), PRs #425 (precedence), #428 (cache GC), #427
(dashboard dedupe), #429 (governance audit event).

## 1.4.7 -- 2026-05-11

### Added

- **`controlzero debug bundle` -- inspect SDK-loaded rules + simulate guards**
  (T87, GH #392). The bundle on disk is encrypted+signed; `cat` returns
  nothing useful, so until now diagnosing a deny-deny incident meant
  shipping the bundle back to engineering or attaching a debugger
  (the deny-deny took ~3 hours to root-cause for exactly this
  reason). The new subcommand reads the matching `bootstrap-<prefix>.json`
  for keys, decrypts and verifies the cached bundle blob via the same
  parser the SDK uses, and prints a human-readable summary: bundle id,
  created_at / expires_at, default_action / default_on_missing /
  default_on_tamper, every policy (id, name, version, is_enabled,
  priority), and every rule (id, effect, principals, actions, resources,
  conditions).

  With `--simulate "tool method args"` it also runs the request through
  the same `PolicyEvaluator` the SDK uses and prints the decision plus
  which rule matched and why. The args grammar accepts either a JSON
  object or whitespace-separated `key=value` pairs (values may contain
  spaces, so `sql=SELECT id FROM orders` parses as a single value).

  The output is designed to be pasted into a support thread: the
  encryption key, signing public key, and API key are NEVER printed,
  enforced by a final `_redact_sensitive` pass before emit.

  Six tests in `tests/test_cli_debug_bundle.py` cover the happy path,
  simulate-allow, simulate-no-rule-match, missing bootstrap, missing
  bundle, and the privacy contract.

### Fixed

- **Pre-#350 customer rules using legacy database action names keep
  matching** (T84, GitHub #389). The SDK started emitting canonical
  SQL semantic classes (`database:read`, `database:write`,
  `database:admin`, `database:exec`) in 1.4.x via #345/#350. That
  silently broke any policy authored before #350 that used legacy
  per-keyword actions like `database:query`, `database:DROP`, or
  `database:execute`: the legacy rule and the modern call no longer
  shared a string, so the rule never fired and the call fell through
  to the default deny.

  The fix is a bidirectional alias shim. The enforcer now expands
  candidate actions through a single-source-of-truth alias table
  (`controlzero/_internal/action_aliases.py`) so:
  - A pre-#350 rule with `actions: ["database:query"]` keeps matching
    modern SELECT calls (which the SDK emits as `database:read`).
  - A modern rule with `actions: ["database:read"]` keeps matching
    legacy guard calls that pass `method="SELECT"`.
  - The legacy ambiguous `database:delete` (used historically for
    both row DELETE and table DROP) maps to BOTH `database:write`
    and `database:admin`, so neither modern intent silently breaks.

  The alias table is byte-identical across Python, Node, and Go SDKs
  and is locked by the cross-SDK fixture at
  `tests/parity/action_aliases.json`. Drift in any SDK fails its
  parity test.

  This is a NO-BREAKING-CHANGES fix: every existing rule continues to
  work, modern rules continue to work, and only previously-broken
  legacy rules start matching again.

- **Synthetic policy_id sentinels** (T79, the deny-deny postmortem).
  `PolicyDecision.policy_id` is now stamped with one of six canonical
  `synthetic:*` values whenever the deny was emitted by a fail-closed
  code path (no rule matched, empty bundle, missing bundle, T83-class
  resource gate skip, machine quarantine, evaluator crash). Previously
  these all carried `policy_id=None` and rendered as a blank Policy
  column on the audit dashboard, making four very different bug
  classes look identical. The new sentinels are:
  - `synthetic:NO_RULE_MATCH` -- bundle loaded, no rule's actions
    matched the call.
  - `synthetic:NO_ACTIVE_POLICIES` -- bundle was structurally empty.
  - `synthetic:BUNDLE_MISSING` -- enrolled but no bundle loadable.
  - `synthetic:RESOURCE_GATE_SKIP` -- a rule's actions matched but its
    `resources:` list excluded the call (T83-class signature).
  - `synthetic:QUARANTINE` -- machine in local quarantine.
  - `synthetic:ENGINE_UNAVAILABLE` -- evaluator crashed mid-evaluate.

  The `reason_code` field is unchanged; the synthetic policy_id is a
  parallel signal that the dashboard reads to switch chip styling and
  link to the matching troubleshooting anchor. Backwards-compatible:
  consumers that only branch on `reason_code` keep working.

  Constants exported from `controlzero._internal.enforcer` as
  `SYNTHETIC_POLICY_ID_PREFIX`, `SYNTHETIC_NO_RULE_MATCH`, etc., plus
  `VALID_SYNTHETIC_POLICY_IDS` for runtime validation.

## 1.4.6 -- 2026-05-11

### Fixed

- **resources:["*"] no longer requires a caller resource** (T83).
  Hosted policy bundles emit `resources:["*"]` for any rule that does
  not scope by resource. The enforcer's resource gate previously
  required a caller-supplied `context.resource` even when the rule's
  resources list was the universal wildcard, causing every rule to be
  silently skipped on calls that didn't pass a resource. Result: every
  `cz.guard()` returned `deny` with `reason_code=NO_RULE_MATCH` regardless
  of what the policy said. Now rules with `*` in their resources match
  universally; non-wildcard resource patterns still require a caller
  resource (no silent broadening). Three regression tests added in
  `tests/test_glob_matching.py` including the exact bundle shape from
  the customer reproduction.

## 1.4.5 -- 2026-05-05

### Added

- **Cross-CLI canonical tool coverage** (#341). The shared
  `tool_extractors.json` is now spec_version 2 and adds three new
  canonical tools (`web_search`, `file_search`, `task`) plus extended
  aliases so PowerShell shell-command emission, Codex CLI's
  `apply_patch`, Gemini CLI's `read_many_files`, and the WebFetch
  family all resolve to the existing canonical tools. One rule
  `action: Bash:rm` now covers Claude Code, Gemini CLI, Codex CLI,
  and PowerShell on Windows.
- **SQL semantic-class layer** (#345/#350). New `sql_semantic_class()`
  helper emits a parallel `database:read|write|admin|exec` action
  alongside the existing per-keyword `database:SELECT|DROP|...`
  action. Write portable rules like `allow: database:read` that cover
  SELECT, EXPLAIN, SHOW, DESCRIBE, and CTE in one rule, without
  enumerating every keyword the dialect accepts. Multi-statement
  piggybacks like `SELECT 1; DROP TABLE x` correctly resolve to
  `database:admin` so deny rules catch them. 21 new parity-test
  fixtures (cross-SDK byte-identical with the Node sibling).

  Legacy action names continue to work: `database:query`,
  `database:execute`, and `database:delete` are still matched against
  the same calls and remain valid in policy rules. New policies
  should prefer the canonical class names; existing rules keyed on
  the legacy names need no migration.

### Documentation

- New customer-facing reference at `docs/sdk/policies/canonical-tools.md`
  explaining canonical tool names, alias coverage per host CLI, and
  the contract for adding new clients.
- New SQL semantic class section in `canonical-tools.md` plus updated
  quickstart and read-only-database recipe.

## 1.4.4 -- 2026-04-19

### Fixed

- Hosted mode now refreshes the policy bundle periodically (default 60 seconds) so dashboard edits reach long-running clients without a process restart. New `Client(refresh_interval_seconds=...)` constructor arg controls cadence: pass `None` to disable, `0` to refresh on every `guard()` call (tests only). Added public `Client.refresh()` for on-demand reloads and `Client.last_refreshed_at` for ops visibility. Swap is protected by a lock so multi-threaded callers never observe torn state.
- Bundle translator now reads plural `actions: [...]` rules from the hosted bundle. Previously every such rule collapsed to a universal `*` match, turning narrow denies like `deny database:execute` into deny-all.
- Backend now stamps `api_keys.last_used_at` on the SDK pull endpoint on both fresh-bundle and 304 paths, so the dashboard can distinguish "SDK online with cached bundle" from "SDK has never connected". Best-effort write; stamp failures never block the response.

## 1.4.1 -- 2026-04-15

### Added

- `agent_name` arg + `CZ_AGENT_NAME` env var contract on the `Client` constructor (issue #71). Order: explicit arg > env > `default-agent`.
- `CZ_DEBUG=1` (or `true`/`yes`/`on`) flips the controlzero logger to DEBUG at construction. Cheap escape hatch for support.
- Optional install extras: `controlzero[google]`, `controlzero[openai]`, `controlzero[anthropic]` (issue #68). Pin the matching upstream SDK so users do not see import errors.
- Cross-SDK action canonicalization parity test (issue #69). Mirrors the same fixture in the Node and Go SDKs.
- Smoke + denial + error-propagation tests for the `wrap_google` integration (issue #68).

## 1.4.0 -- 2026-04-15

### Breaking changes

- Integration wrappers now emit simplified action names (`llm:generate`, `embedding:generate`, `tool:call`) instead of provider-prefixed ones (`llm:openai:chat.completions.create`). Policies targeting the old action names must be updated. Provider and model move into `context` tags. See docs/integrations for current patterns.
- Google integration rewritten against `google-genai` (deprecated `google.generativeai` removed). Install `google-genai`.
- `integrations.langchain.agent.GovernedAgent` wrapping `AgentExecutor` is deprecated in LangChain v1.x. Use `integrations.langchain.modern.create_governed_agent`.

### New integrations

- `integrations.autogen` - first-party helper for autogen-agentchat v0.7+
- `integrations.pydantic_ai` - first-party helper for pydantic-ai v1.x
- `integrations.langchain.modern` - LangGraph create_agent pattern

### New features

- Policy rule `conditions` field is now evaluated in the local enforcer. Conditions are matched against merged context + args with glob patterns. All keys must match.

### Enhancements

- `integrations.litellm` - async + success/failure hooks for streaming audit.
