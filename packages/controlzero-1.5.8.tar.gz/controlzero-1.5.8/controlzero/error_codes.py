"""Stable error code catalog for the controlzero SDK + CLI.

Tier 0a hotfix piece 4 (#174). Every user-visible error message now
carries one of these E#### codes. The code is what we put in the URL
the error message points the user at: docs.controlzero.ai/errors/E1001.

Why a flat catalog instead of nested error classes:

- The CLI and the SDK both raise errors; doctor + migrate emit
  warnings; the hook subprocess prints to stderr. We want one
  stable code space across all four surfaces.
- Codes must never be renumbered. Adding new codes is fine; renaming
  or repurposing a code is a breaking change for our docs site
  (the URL fragment lives in customers' bookmarks + support tickets).
- The hook subprocess is invoked thousands of times per session;
  importing a heavy exception hierarchy on every fire is overhead
  we don't want to pay. A NamedTuple lookup is cheap.

Each entry has:
- code:        E#### stable identifier
- title:       1-line summary suitable for an error message header
- what:        2-3 sentences explaining what happened, in user terms
- fix:         actionable next step the user can run
- doc:         URL slug under docs.controlzero.ai/errors/

Conventions:

- E1000-E1099: Security + secrets management
- E1100-E1199: Authentication + enrollment
- E1200-E1299: Policy load / validate / bundle
- E1300-E1399: Cache + local-disk layout
- E1400-E1499: Network + remote backend
- E1500-E1599: Hook subprocess + agent integration
- E1600-E1699: SDK runtime (guard / audit / close)
"""

from __future__ import annotations

from typing import Dict, NamedTuple


class ErrorCode(NamedTuple):
    code: str
    title: str
    what: str
    fix: str
    doc: str  # slug; full URL is f"https://docs.controlzero.ai/errors/{doc}"


_CATALOG: Dict[str, ErrorCode] = {}


def _add(code: str, title: str, what: str, fix: str, doc: str) -> ErrorCode:
    e = ErrorCode(code=code, title=title, what=what, fix=fix, doc=doc)
    _CATALOG[code] = e
    return e


# --- Security + secrets ----------------------------------------------------

E1001 = _add(
    "E1001",
    "API key found in agent settings file",
    "An agent settings file (e.g. ~/.claude/settings.json) contains a "
    "plaintext cz_live_* or cz_test_* key inside a hook command. On every "
    "tool invocation the key is echoed to the agent's stderr, where it "
    "can be captured by terminal scrollback, shell history, or log files.",
    "Run `controlzero migrate` to move the key into ~/.controlzero/config.yaml "
    "(mode 0600) and rewrite the hook to read $CONTROLZERO_API_KEY from the "
    "env. Then rotate the leaked key in the dashboard.",
    "E1001-api-key-in-settings",
)

E1002 = _add(
    "E1002",
    "~/.controlzero directory is world-readable",
    "The directory holding your API key has permissions other than 0700. "
    "Other local users on this machine can read its contents.",
    "Run `chmod 700 ~/.controlzero`.",
    "E1002-config-dir-perms",
)

E1003 = _add(
    "E1003",
    "config.yaml is world-readable",
    "The API key on disk has file permissions other than 0600. Other "
    "local users on this machine can read the key.",
    "Run `chmod 600 ~/.controlzero/config.yaml` or re-run `controlzero "
    "install` to re-apply.",
    "E1003-config-file-perms",
)

E1004 = _add(
    "E1004",
    "API key found in shell history",
    "An API key was found in your shell history file (.bash_history / "
    ".zsh_history). Histories are typically synced to cloud backups and "
    "are readable to any process running as the same user.",
    "Rotate the key in the dashboard, then scrub the history entry "
    "with `history -d <number>` or by editing the history file directly.",
    "E1004-key-in-shell-history",
)

E1005 = _add(
    "E1005",
    "Cannot read an agent settings file",
    "Doctor wanted to scan an agent settings file but the file is "
    "unreadable (permissions / disk error). We can't confirm whether "
    "the file contains a leaked key.",
    "Check the file's permissions. If it should be readable to you, "
    "fix the perms; if it shouldn't exist at all, delete it.",
    "E1005-unreadable-settings",
)

# --- Authentication + enrollment ------------------------------------------

E1101 = _add(
    "E1101",
    "API key rejected (401)",
    "The hosted backend rejected the API key. The key is either revoked, "
    "from a different environment (test vs live), or never existed.",
    "Check your dashboard for the current key under Settings → API Keys. "
    "Make sure CONTROLZERO_API_KEY matches the key shown there.",
    "E1101-key-rejected",
)

E1102 = _add(
    "E1102",
    "Enrollment token expired",
    "The single-use enrollment token from the dashboard has expired or "
    "was already consumed. Each token is valid for 15 minutes and one "
    "enrollment.",
    "Generate a fresh token in the dashboard and re-run `controlzero "
    "enroll --token=...`.",
    "E1102-enroll-token-expired",
)

E1103 = _add(
    "E1103",
    "No API key found",
    "The SDK looked for an API key in $CONTROLZERO_API_KEY and "
    "~/.controlzero/config.yaml but neither produced one.",
    "Either export `CONTROLZERO_API_KEY=cz_live_...` in your shell, or "
    "run `controlzero install <agent> --api-key=cz_live_...` to write "
    "it to the config file.",
    "E1103-no-api-key",
)

E1104 = _add(
    "E1104",
    "API key format invalid",
    "The string supplied as the API key does not match the expected shape "
    "(`cz_live_*` or `cz_test_*` followed by 64 hex characters).",
    "Copy the key from the dashboard directly; do not URL-encode or "
    "wrap it in quotes when exporting.",
    "E1104-key-format-invalid",
)

# --- Policy load / validate / bundle --------------------------------------

E1201 = _add(
    "E1201",
    "Policy file failed validation",
    "The local policy file (controlzero.yaml or controlzero.json) does "
    "not conform to the policy schema. See the error list immediately "
    "above for which fields are wrong.",
    "Run `controlzero validate <file>` to get the same errors formatted "
    "as a checklist. Or open the file in your editor and fix the fields.",
    "E1201-policy-validate",
)

E1202 = _add(
    "E1202",
    "Policy file not found",
    "The SDK was told to load a policy from a path that does not exist.",
    "Double-check the path you passed to policy_file=. If you meant to "
    "use the global policy, drop the argument and let the SDK find "
    "~/.controlzero/policy.yaml automatically.",
    "E1202-policy-not-found",
)

E1203 = _add(
    "E1203",
    "Policy bundle signature mismatch",
    "The signed policy bundle the SDK pulled from the backend has a "
    "signature that does not match the expected public key. This is a "
    "tamper signal: someone may have modified the bundle in transit or "
    "on disk.",
    "Delete the cached bundle (~/.controlzero/bundle-cz_*.bin), restart "
    "the SDK, and re-pull. If the error recurs, escalate to support.",
    "E1203-bundle-sig",
)

E1204 = _add(
    "E1204",
    "Policy version conflict",
    "The local policy and the hosted policy disagree on which version "
    "is current. SDK precedence (T103) means the hosted version wins, "
    "but we surface a warning so you know about it.",
    "Pick one source of truth. If you want the hosted policy: delete "
    "the local file. If you want the local policy: run "
    "`controlzero install <agent> --local-override` to opt out of hosted.",
    "E1204-version-conflict",
)

E1205 = _add(
    "E1205",
    "Policy bundle missing -- fail-closed engaged",
    "Hosted mode is configured but no cached bundle is available and "
    "the backend is unreachable. The SDK refuses to construct rather "
    "than silently allow every tool call.",
    "Check network reachability to api.controlzero.ai. If you're "
    "offline by design, pre-cache the bundle with `controlzero "
    "policy-pull` while you have connectivity.",
    "E1205-fail-closed",
)

# --- Cache + local-disk layout --------------------------------------------

E1301 = _add(
    "E1301",
    "Cache directory permissions wrong",
    "~/.controlzero needs mode 0700. Found a different mode.",
    "Run `chmod 700 ~/.controlzero`.",
    "E1301-cache-perms",
)

E1302 = _add(
    "E1302",
    "Stale bundle for rotated key",
    "T104 cache GC found a cached bundle whose key prefix no longer "
    "matches any active key in your enrollment. Almost always means a "
    "key rotated and the old bundle should be discarded.",
    "Run `controlzero policy-pull` to refresh, or delete the stale "
    "bundle: `rm ~/.controlzero/bundle-cz_*.bin`.",
    "E1302-stale-bundle",
)

E1303 = _add(
    "E1303",
    "Audit log not writable",
    "The SDK can't append to ~/.controlzero/audit.log. Usually a "
    "permissions or out-of-disk issue.",
    "Check `ls -la ~/.controlzero/audit.log` and `df -h ~`. If perms "
    "are wrong, `chmod 600 ~/.controlzero/audit.log`.",
    "E1303-audit-write",
)

# --- Network + remote backend ---------------------------------------------

E1401 = _add(
    "E1401",
    "Backend unreachable",
    "The SDK could not connect to api.controlzero.ai (or whatever "
    "CONTROLZERO_API_URL points at). Tool calls will use the cached "
    "policy bundle; new audit events buffer locally.",
    "Check `curl -I https://api.controlzero.ai`. If you're behind a "
    "corporate proxy, set HTTPS_PROXY before launching your agent.",
    "E1401-backend-unreachable",
)

E1402 = _add(
    "E1402",
    "Backend returned 5xx",
    "The backend returned a server error. Transient. The SDK will "
    "retry on the next guard() call. Audit events buffer locally and "
    "flush when the backend recovers.",
    "If it persists for more than a few minutes, check "
    "status.controlzero.ai or open a support ticket with the timestamp.",
    "E1402-backend-5xx",
)

E1403 = _add(
    "E1403",
    "Rate limit exceeded",
    "The hosted backend rate-limited this client. The SDK backs off "
    "and retries; tool calls are not blocked.",
    "If you see this consistently, your usage may have crossed your "
    "tier's limit. Check the dashboard's Usage page.",
    "E1403-rate-limit",
)

E1404 = _add(
    "E1404",
    "TLS verification failed",
    "The TLS handshake to api.controlzero.ai failed verification. "
    "Usually a corporate MITM proxy that injects its own CA, or a "
    "system clock that's badly out of sync.",
    "Either point the SDK at your corporate CA bundle "
    "(REQUESTS_CA_BUNDLE=/path/to/corp.pem) or fix the system clock.",
    "E1404-tls-verify",
)

# --- Hook subprocess + agent integration ----------------------------------

E1501 = _add(
    "E1501",
    "Hook input was not JSON",
    "The agent invoked the controlzero hook subprocess but the stdin "
    "payload could not be parsed as JSON. The hook fails open (allows "
    "the tool call) so the agent does not stall.",
    "Re-install the hook with `controlzero install <agent>` to fix any "
    "manual edits to the agent's settings file that may have corrupted "
    "the contract.",
    "E1501-hook-bad-json",
)

E1502 = _add(
    "E1502",
    "Hook timed out",
    "The hook subprocess took longer than 5 seconds to return a "
    "decision. The agent allowed the tool call to proceed rather than "
    "blocking on us.",
    "Usually a slow disk or a hung network call. Run `controlzero "
    "doctor -v` to confirm the cache files are readable.",
    "E1502-hook-timeout",
)

E1503 = _add(
    "E1503",
    "Hook returned the wrong decision key",
    "Claude Code's hook spec accepts decision: 'approve' or 'block'. "
    "An older controlzero version emitted decision: 'allow', which "
    "Claude silently discarded -- bypassing the policy entirely. The "
    "1.5.3 host-agent adapter base fixed this.",
    "Upgrade to controlzero >= 1.5.3.",
    "E1503-decision-key",
)

E1504 = _add(
    "E1504",
    "Windows agent hook syntax error",
    "The agent's settings file uses `VAR=value command` bash-prefix "
    "syntax for the hook command. PowerShell and cmd.exe cannot parse "
    "this -- the hook silently fails on every Windows agent.",
    "Re-install with `controlzero install <agent>`. The current "
    "install path emits the portable form.",
    "E1504-windows-hook",
)

# --- SDK runtime ----------------------------------------------------------

E1601 = _add(
    "E1601",
    "guard() called after close()",
    "Your code called Client.guard() on a Client that already had "
    "close() called on it. The SDK refuses to continue auditing because "
    "the audit sinks have been drained and shut down.",
    "Restructure your code so close() runs exactly once, at the end of "
    "the agent's lifecycle. The most common cause is putting close() "
    "inside a finally that fires per-iteration instead of once.",
    "E1601-guard-after-close",
)

E1602 = _add(
    "E1602",
    "Tool name not in canonical vocab",
    "The tool action you passed to guard() does not match any rule in "
    "your policy AND does not match any canonical alias. The action "
    "was logged as `unknown_tool` and the synthetic NO_RULE_MATCH "
    "decision applied.",
    "Either add a rule covering this action, or `controlzero validate` "
    "your policy with --suggest to see did-you-mean hints from T86.",
    "E1602-unknown-tool",
)

E1603 = _add(
    "E1603",
    "Args hash mismatch (deterministic check)",
    "The args hash recomputed by the engine on this audit row does not "
    "match the args hash the SDK shipped. Either the args were mutated "
    "in flight or the JCS canonicalizer drifted between SDK + engine.",
    "Upgrade the SDK to match the engine version (run `controlzero "
    "version` and compare against the backend health endpoint).",
    "E1603-args-hash-drift",
)


def get(code: str) -> ErrorCode:
    """Look up an error code. Raises KeyError if the code is not in
    the catalog -- intentional, because shipping an unknown E#### to
    a user is worse than crashing."""
    return _CATALOG[code]


def all_codes() -> Dict[str, ErrorCode]:
    """Return a copy of the catalog. Used by the docs-site generator
    to render docs/errors/<code>.md."""
    return dict(_CATALOG)


def format_error(code: str, extra: str = "") -> str:
    """Render an E#### error suitable for stderr.

    Example output:

        [Control Zero] ERROR E1001: API key found in agent settings file
          ~/.claude/settings.json contains a plaintext cz_live_*** key.

          Fix: Run `controlzero migrate` to move the key into config.yaml.
          Docs: https://docs.controlzero.ai/errors/E1001-api-key-in-settings
    """
    e = get(code)
    body = (
        f"[Control Zero] ERROR {e.code}: {e.title}\n"
        f"  {e.what}\n"
    )
    if extra:
        body += f"  {extra}\n"
    body += (
        f"\n"
        f"  Fix:  {e.fix}\n"
        f"  Docs: https://docs.controlzero.ai/errors/{e.doc}\n"
    )
    return body
