"""Device fingerprint and client detection for ControlZero SDK.

Collects hardware/OS identifiers (hostname, IP, MAC, serial number) and
detects which AI coding client is invoking the SDK. All collection is
best-effort: failures return "unknown" and never crash the caller.

Results are cached for the lifetime of the process (collected once).
"""

from __future__ import annotations

import logging
import os
import platform
import re
import socket
import subprocess
import uuid
from typing import Optional

logger = logging.getLogger("controlzero.device")

# Module-level caches (populated on first call, never refreshed)
_device_fingerprint_cache: Optional[dict] = None
_client_name_cache: Optional[str] = None
_client_version_cache: Optional[str] = None

_SUBPROCESS_TIMEOUT_S = 5


def get_device_fingerprint() -> dict:
    """Return a dict of device identity fields.

    Keys: hostname, ip_address, mac_address, serial_number,
          os_name, os_version, arch

    All values are strings. On collection failure the value is "unknown".
    Collected once per process and cached.
    """
    global _device_fingerprint_cache
    if _device_fingerprint_cache is not None:
        return dict(_device_fingerprint_cache)

    fp = {
        "hostname": _safe_hostname(),
        "ip_address": _safe_ip_address(),
        "mac_address": _safe_mac_address(),
        "serial_number": _safe_serial_number(),
        "os_name": platform.system() or "unknown",
        "os_version": platform.version() or "unknown",
        "arch": platform.machine() or "unknown",
    }
    _device_fingerprint_cache = fp
    return dict(fp)


def detect_client_name() -> str:
    """Detect which AI coding client is running.

    Detection uses signals each tool ACTUALLY ships, not generic env-var
    prefixes that users might export for unrelated reasons. T92 rewrite,
    after the the source-mislabel incident (2026-05-10) where a Python
    SDK user with ``GEMINI_API_KEY`` exported for direct Google API access
    was mislabeled as "Gemini CLI" because the prior implementation
    matched any ``GEMINI_`` prefix.

    Check order:
      1. CONTROLZERO_CLIENT env var (explicit override; always wins)
      2. CLAUDECODE / CLAUDE_CODE_* (Claude Code)
      3. CODEX_HOME / CODEX_PROFILE / CODEX_CLI (Codex CLI)
      4. CURSOR_TRACE_ID / CURSOR_AGENT / TERM_PROGRAM=cursor (Cursor IDE)
      5. WINDSURF_AGENT / WINDSURF_SESSION_ID (Windsurf)
      6. GEMINI_CLI / GEMINI_SANDBOX / GEMINI_SYSTEM_MD (Gemini CLI runtime,
         NOT GEMINI_API_KEY)
      7. Default: "sdk"

    Cached after first call.
    """
    global _client_name_cache
    if _client_name_cache is not None:
        return _client_name_cache

    # 1. Explicit override -- always wins. The escape hatch for any
    # detection miss; users can set CONTROLZERO_CLIENT=cursor if their
    # IDE does not ship the env vars we sniff for.
    explicit = os.environ.get("CONTROLZERO_CLIENT", "").strip()
    if explicit:
        _client_name_cache = explicit
        return explicit

    # 2. Claude Code. The Anthropic shell launcher exports CLAUDECODE=1
    # (no underscore). Pre-T92 we checked CLAUDE_CODE which is never
    # set, so Claude Code users were silently misclassified as "sdk".
    if os.environ.get("CLAUDECODE") or os.environ.get("CLAUDE_CODE"):
        _client_name_cache = "claude-code"
        return "claude-code"

    # 3. Codex CLI. The CLI exports CODEX_HOME (path to ~/.codex) and
    # CODEX_PROFILE in its launched subprocesses. CODEX_CLI mirrors
    # the Node SDK's convention. Pre-T92 there was NO Codex detection;
    # Codex users showed up as "sdk".
    if (os.environ.get("CODEX_HOME") or
            os.environ.get("CODEX_PROFILE") or
            os.environ.get("CODEX_CLI")):
        _client_name_cache = "codex-cli"
        return "codex-cli"

    # 4. Cursor. Cursor sets CURSOR_TRACE_ID per terminal window and
    # CURSOR_AGENT in its agent panes. TERM_PROGRAM=cursor catches the
    # IDE's integrated shell as a fallback. Pre-T92 we matched any
    # CURSOR_ prefix which would also catch user-set env vars
    # unrelated to Cursor. Cursor must be checked BEFORE Gemini so
    # that Cursor users with GEMINI_* present do not slip into the
    # gemini-cli branch.
    if (os.environ.get("CURSOR_TRACE_ID") or
            os.environ.get("CURSOR_AGENT") or
            os.environ.get("CURSOR_USER_AGENT") or
            os.environ.get("TERM_PROGRAM") == "cursor"):
        _client_name_cache = "cursor"
        return "cursor"

    # 5. Windsurf
    if (os.environ.get("WINDSURF_AGENT") or
            os.environ.get("WINDSURF_SESSION_ID")):
        _client_name_cache = "windsurf"
        return "windsurf"

    # 6. Gemini CLI. Match ONLY env vars the CLI runtime sets, NOT the
    # broad GEMINI_ prefix. GEMINI_API_KEY is exported by anyone using
    # Google's Python SDK directly (the customer's case). GEMINI_CLI mirrors
    # the Node SDK's convention; GEMINI_SANDBOX / GEMINI_SYSTEM_MD are
    # set by the gemini-cli runtime itself.
    if (os.environ.get("GEMINI_CLI") or
            os.environ.get("GEMINI_SANDBOX") or
            os.environ.get("GEMINI_SYSTEM_MD")):
        _client_name_cache = "gemini-cli"
        return "gemini-cli"

    # Direct SDK usage (no agent runtime detected) -- emit the canonical
    # backend source value so the dashboard renders "Python SDK" instead
    # of "--". Pre-2026-05-12 we emitted the generic alias "sdk", which
    # the backend NormalizeSource maps to "unknown" and the audit log
    # column rendered as "--", confusing customers into thinking their
    # logs weren't reaching the dashboard.
    _client_name_cache = "python-sdk"
    return "python-sdk"


def detect_client_version() -> str:
    """Attempt to detect the version of the running AI client.

    Returns an empty string if detection fails or the client is unknown.
    Cached after first call.
    """
    global _client_version_cache
    if _client_version_cache is not None:
        return _client_version_cache

    client = detect_client_name()
    version = ""

    try:
        if client == "claude-code":
            version = _run_version_cmd(["claude", "--version"])
        elif client == "cursor":
            version = (os.environ.get("CURSOR_VERSION", "") or
                       os.environ.get("CURSOR_APP_VERSION", ""))
        elif client == "gemini-cli":
            version = _run_version_cmd(["gemini", "--version"])
        elif client == "codex-cli":
            version = (_run_version_cmd(["codex", "--version"]) or
                       os.environ.get("CODEX_VERSION", ""))
        elif client == "windsurf":
            version = os.environ.get("WINDSURF_VERSION", "")
    except Exception:
        pass

    _client_version_cache = version
    return version


# -- internal helpers -------------------------------------------------------


def _safe_hostname() -> str:
    try:
        return socket.gethostname() or "unknown"
    except Exception:
        return "unknown"


def _safe_ip_address() -> str:
    """Get the primary local IP address."""
    try:
        # Connect to a public DNS to determine the default route interface.
        # No actual traffic is sent (UDP, no connect handshake needed).
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.connect(("8.8.8.8", 80))
            return s.getsockname()[0]
        finally:
            s.close()
    except Exception:
        pass

    # Fallback: getaddrinfo
    try:
        hostname = socket.gethostname()
        addrs = socket.getaddrinfo(hostname, None, socket.AF_INET)
        for family, _type, _proto, _canon, sockaddr in addrs:
            ip = sockaddr[0]
            if ip and not ip.startswith("127."):
                return ip
    except Exception:
        pass

    return "unknown"


def _safe_mac_address() -> str:
    """Get MAC address formatted as XX:XX:XX:XX:XX:XX."""
    try:
        mac_int = uuid.getnode()
        # uuid.getnode() returns a random value with bit 0 of the first
        # octet set if it cannot determine the real MAC. Check for that.
        if (mac_int >> 40) & 1:
            return "unknown"
        mac_hex = f"{mac_int:012x}"
        return ":".join(mac_hex[i : i + 2] for i in range(0, 12, 2))
    except Exception:
        return "unknown"


def _safe_serial_number() -> str:
    """Get the hardware serial number (platform-specific)."""
    system = platform.system().lower()

    try:
        if system == "darwin":
            return _serial_macos()
        elif system == "linux":
            return _serial_linux()
        elif system == "windows":
            return _serial_windows()
    except Exception as exc:
        logger.debug("serial number detection failed: %s", exc)

    return "unknown"


def _serial_macos() -> str:
    result = subprocess.run(
        ["ioreg", "-l"],
        capture_output=True,
        text=True,
        timeout=_SUBPROCESS_TIMEOUT_S,
    )
    if result.returncode != 0:
        return "unknown"
    for line in result.stdout.splitlines():
        if "IOPlatformSerialNumber" in line:
            match = re.search(r'"IOPlatformSerialNumber"\s*=\s*"([^"]+)"', line)
            if match:
                return match.group(1).strip()
    return "unknown"


def _serial_linux() -> str:
    # Try /sys path first (no root needed on many distros)
    try:
        path = "/sys/class/dmi/id/product_serial"
        with open(path) as f:
            serial = f.read().strip()
            if serial and serial.lower() not in ("", "none", "to be filled by o.e.m."):
                return serial
    except (OSError, PermissionError):
        pass

    # Fallback: dmidecode (requires root usually)
    try:
        result = subprocess.run(
            ["dmidecode", "-s", "system-serial-number"],
            capture_output=True,
            text=True,
            timeout=_SUBPROCESS_TIMEOUT_S,
        )
        if result.returncode == 0:
            serial = result.stdout.strip()
            if serial and serial.lower() not in ("", "none", "to be filled by o.e.m."):
                return serial
    except (OSError, FileNotFoundError):
        pass

    return "unknown"


def _serial_windows() -> str:
    result = subprocess.run(
        ["wmic", "bios", "get", "serialnumber"],
        capture_output=True,
        text=True,
        timeout=_SUBPROCESS_TIMEOUT_S,
    )
    if result.returncode != 0:
        return "unknown"
    lines = [ln.strip() for ln in result.stdout.splitlines() if ln.strip()]
    # First line is header "SerialNumber", second is the value
    if len(lines) >= 2:
        serial = lines[1]
        if serial and serial.lower() not in ("", "none", "to be filled by o.e.m."):
            return serial
    return "unknown"


def _run_version_cmd(cmd: list[str]) -> str:
    """Run a version command and return the first line of output."""
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=_SUBPROCESS_TIMEOUT_S,
        )
        if result.returncode == 0 and result.stdout.strip():
            return result.stdout.strip().splitlines()[0]
    except (OSError, FileNotFoundError, subprocess.TimeoutExpired):
        pass
    return ""


def _reset_caches() -> None:
    """Reset all module-level caches. For testing only."""
    global _device_fingerprint_cache, _client_name_cache, _client_version_cache
    _device_fingerprint_cache = None
    _client_name_cache = None
    _client_version_cache = None
