"""Public exception types for the controlzero SDK.

Tier 0b (#174 follow-up, 2026-05-15): every public exception class
now carries a stable E#### error code from the catalog in
`controlzero.error_codes`. The catalog code surfaces as:

  - `exc.e_code` attribute (e.g. "E1201"), so programmatic callers
    can route on it.
  - A docs-URL suffix appended to `str(exc)`, so anywhere the message
    hits a human (CLI stderr, log line, traceback) the user sees the
    canonical fix at https://docs.controlzero.ai/errors/<slug>.

Backward compatible: the original message text is preserved as a
prefix, so existing tests that assert "X in str(exc)" keep working.
The augmented form looks like:

  Policy validation failed for foo.yaml:
    - field "rules" is required
  [E1201] Run `controlzero validate <file>` to get a formatted checklist.
  Docs: https://docs.controlzero.ai/errors/E1201-policy-validate
"""

from __future__ import annotations

from typing import ClassVar, Optional

from controlzero._internal.enforcer import PolicyDeniedError, PolicyDecision
from controlzero.error_codes import ErrorCode, get as _get_error_code


def _augment_with_code(message: str, code_key: Optional[str]) -> str:
    """Append the catalog's fix + docs URL to a raw error message.

    Pure function; no I/O. Returns the original message unchanged
    when `code_key` is None or the code is not in the catalog,
    so a typo never breaks the SDK's error path.
    """
    if not code_key:
        return message
    try:
        entry: ErrorCode = _get_error_code(code_key)
    except KeyError:
        return message
    suffix = (
        f"\n[{entry.code}] {entry.fix}"
        f"\nDocs: https://docs.controlzero.ai/errors/{entry.doc}"
    )
    return f"{message}{suffix}"


class _CZErrorMixin:
    """Base for SDK exceptions that opt into the E#### catalog.

    Set the `E_CODE` class attribute to a key from
    `controlzero.error_codes` and `_augment_with_code` will splice
    the canonical fix + docs URL into every str(exc) automatically.
    Subclasses that omit `E_CODE` keep legacy behavior verbatim.
    """

    E_CODE: ClassVar[Optional[str]] = None

    @property
    def e_code(self) -> Optional[str]:
        """The stable E#### code for this exception, or None for
        un-cataloged classes. Safe to call on any subclass."""
        return self.E_CODE


class HostedModeNotImplemented(_CZErrorMixin, NotImplementedError):
    """Raised when an API key is set but no local policy is provided.

    Hosted mode (dashboard-managed policies + remote audit) is not
    implemented in the slim `controlzero` package. To use hosted
    mode, install the legacy `control-zero<=0.3.0` package. To use
    this package, provide a local policy via `policy=` or
    `policy_file=`.
    """
    # No catalog code: this is a deprecation pathway, not a runtime
    # error from the supported install path. Keep the message clean.
    E_CODE = None


class HybridModeError(_CZErrorMixin, RuntimeError):
    """Raised when an API key and a local policy are both provided
    AND `strict_hosted=True` is set. Indicates an accidental
    dashboard-policy override that the user opted to make a hard
    error. Maps to E1204 (policy version conflict)."""

    E_CODE = "E1204"

    def __init__(self, message: str = "hybrid mode rejected by strict_hosted=True"):
        super().__init__(_augment_with_code(message, self.E_CODE))


class PolicyValidationError(_CZErrorMixin, ValueError):
    """Raised when a policy file or dict fails schema validation.
    Maps to E1201.

    Attributes:
        errors: List of human-readable error strings, one per bad field.
        source: The file path or "<dict>" indicating where the policy came from.
    """

    E_CODE = "E1201"

    def __init__(self, errors: list[str], source: str = "<unknown>"):
        self.errors = errors
        self.source = source
        msg = f"Policy validation failed for {source}:\n  - " + "\n  - ".join(errors)
        super().__init__(_augment_with_code(msg, self.E_CODE))


class PolicyLoadError(_CZErrorMixin, Exception):
    """Raised when a policy file cannot be loaded (file not found,
    parse error, etc). Maps to E1202.

    Wraps the underlying exception with extra context (file path, format hint).
    """

    E_CODE = "E1202"

    def __init__(self, message: str, source: str = "<unknown>", cause: Exception = None):
        self.source = source
        self.cause = cause
        full = f"{message} (source: {source})"
        if cause:
            full += f"\n  caused by: {type(cause).__name__}: {cause}"
        super().__init__(_augment_with_code(full, self.E_CODE))


class BundleSignatureError(_CZErrorMixin, Exception):
    """Policy bundle signature verification failed. Maps to E1203."""

    E_CODE = "E1203"

    def __init__(self, message: str = "policy bundle signature verification failed"):
        super().__init__(_augment_with_code(message, self.E_CODE))


class HostedAuthError(_CZErrorMixin, RuntimeError):
    """Raised when the project API key is rejected by the backend
    (401/403). Maps to E1101.

    This is a permanent failure: the caller supplied an invalid or
    revoked API key. Retrying with the same key will not help. The
    SDK surfaces this so the user can correct their configuration.
    """

    E_CODE = "E1101"

    def __init__(self, message: str = "hosted API key rejected by backend"):
        super().__init__(_augment_with_code(message, self.E_CODE))


class HostedBootstrapError(_CZErrorMixin, RuntimeError):
    """Raised when hosted mode cannot initialize and no cached bundle
    exists. Maps to E1205 (fail-closed engaged).

    The SDK fails closed: without a valid policy it refuses to
    construct. This is preferable to silently allowing every tool
    call. If a cached bundle is present, the SDK uses it and emits
    a warning instead.
    """

    E_CODE = "E1205"

    def __init__(self, message: str = "hosted bootstrap failed and no cached bundle available"):
        super().__init__(_augment_with_code(message, self.E_CODE))


__all__ = [
    "PolicyDecision",
    "PolicyDeniedError",
    "PolicyValidationError",
    "PolicyLoadError",
    "BundleSignatureError",
    "HostedAuthError",
    "HostedBootstrapError",
    "HostedModeNotImplemented",
    "HybridModeError",
]
