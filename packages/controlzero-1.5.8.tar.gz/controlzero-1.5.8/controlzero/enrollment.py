"""Enrollment client for the ControlZero managed mode.

Phase 6 of the enterprise governance plan: SDK-side
counterpart to the Phase 5a backend endpoints.

Flow:
    1. Admin generates an enrollment token in the dashboard.
    2. SDK runs ``controlzero enroll --token <raw>`` on first machine
       boot. This generates a fresh signing keypair, sends the public
       half to ``POST /api/enroll`` along with the token + machine
       fingerprint, and receives back a server-assigned machine_id.
    3. The SDK persists the machine_id + public key + private key
       to ``~/.controlzero/`` and uses the private key to sign every
       subsequent request to ``/api/heartbeat``, ``/api/policy``, and
       ``/api/audit``.

OS keystore integration is intentionally NOT in this first cut. The
private key lives in ``~/.controlzero/machine.key`` with mode 0600.
A follow-up will plug in Keychain/DPAPI/secret-service per platform;
the file-on-disk fallback stays as the bottom of the chain.

Wire-format contract: see the public docs and OpenAPI spec for the
machine-auth endpoint at https://docs.controlzero.ai. This module is
the source of truth on the client side.
"""

from __future__ import annotations

import dataclasses
import hashlib
import json
import os
import platform
import socket
import time
from base64 import b64encode
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

try:
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric.ed25519 import (
        Ed25519PrivateKey,
        Ed25519PublicKey,  # noqa: F401 -- re-exported for callers
    )
except ImportError as exc:  # pragma: no cover
    raise ImportError(
        "controlzero enrollment requires the 'hosted' extras. "
        "Install with: pip install 'control-zero[hosted]'"
    ) from exc

try:
    import httpx
except ImportError as exc:  # pragma: no cover
    raise ImportError(
        "controlzero enrollment requires httpx. "
        "Install with: pip install 'control-zero[hosted]'"
    ) from exc


# ----- on-disk layout ---------------------------------------------------

DEFAULT_STATE_DIR = Path.home() / ".controlzero"
STATE_FILE_NAME = "enrollment.json"
PRIVKEY_FILE_NAME = "machine.key"


# ----- typed state ------------------------------------------------------


@dataclass
class EnrollmentState:
    """Everything the SDK needs to authenticate signed requests.

    The private key bytes are NOT stored on this dataclass; they live
    in a separate file with restricted permissions and are loaded on
    demand by ``load_private_key``. Keeping the key out of the JSON
    state file means an accidental log of the state object cannot
    leak the signing key.
    """

    machine_id: str
    org_id: str
    api_url: str
    hostname: str
    fingerprint_hint: str
    machine_pubkey_pem: str
    enrolled_at: str
    org_signing_pubkey_pem: str = ""
    policy_version: int = 0
    tamper_behavior: str = "warn"
    plugin_versions: dict[str, str] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, d: dict) -> "EnrollmentState":
        return cls(
            machine_id=d["machine_id"],
            org_id=d["org_id"],
            api_url=d["api_url"],
            hostname=d["hostname"],
            fingerprint_hint=d["fingerprint_hint"],
            machine_pubkey_pem=d["machine_pubkey_pem"],
            enrolled_at=d["enrolled_at"],
            org_signing_pubkey_pem=d.get("org_signing_pubkey_pem", ""),
            policy_version=int(d.get("policy_version", 0)),
            tamper_behavior=d.get("tamper_behavior", "warn"),
            plugin_versions=dict(d.get("plugin_versions", {})),
        )

    def to_dict(self) -> dict:
        return dataclasses.asdict(self)


# ----- enrollment errors ------------------------------------------------


class EnrollmentError(Exception):
    """Anything went wrong during enroll/heartbeat/policy/audit."""


class TokenError(EnrollmentError):
    """The enrollment token was invalid, expired, revoked, or exhausted."""


class NotEnrolledError(EnrollmentError):
    """sign_request / heartbeat called without a valid local state."""


# ----- fingerprint ------------------------------------------------------


def compute_fingerprint() -> str:
    """Stable hash of host attributes used as a dedup key on enroll.

    Re-running ``controlzero enroll`` on the same machine should
    converge on the same fingerprint, which lets the backend's
    ``UNIQUE(org_id, fingerprint_hint)`` upsert return the existing
    machine_id rather than minting a new one.

    The hash inputs are: hostname, OS, OS version, machine arch, and
    the install path of this Python module. Changing any of these
    produces a "new machine" -- which is the desired behaviour for
    e.g. a forked container or a fresh laptop image.
    """
    parts = [
        platform.node() or "unknown",
        platform.system(),
        platform.release(),
        platform.machine(),
        str(Path(__file__).resolve().parent),
    ]
    h = hashlib.sha256("|".join(parts).encode("utf-8"))
    return h.hexdigest()[:32]


# ----- key + state I/O --------------------------------------------------


def _ensure_state_dir(state_dir: Path) -> None:
    state_dir.mkdir(parents=True, exist_ok=True)
    # Tighten permissions on the directory itself.
    try:
        os.chmod(state_dir, 0o700)
    except OSError:
        pass


def generate_keypair() -> tuple[Ed25519PrivateKey, str]:
    """Mint a fresh signing keypair and return (private, public_pem)."""
    priv = Ed25519PrivateKey.generate()
    pub = priv.public_key()
    pem = pub.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    ).decode("utf-8")
    return priv, pem


def save_private_key(priv: Ed25519PrivateKey, state_dir: Path = DEFAULT_STATE_DIR) -> Path:
    """Persist the private key to ``<state_dir>/machine.key`` (mode 0600)."""
    _ensure_state_dir(state_dir)
    path = state_dir / PRIVKEY_FILE_NAME
    pem = priv.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )
    # Write atomically: tmp + rename, then chmod 0600. The chmod
    # happens AFTER write so a partial file never sits at 0600 with
    # zero contents.
    tmp = path.with_suffix(".key.tmp")
    tmp.write_bytes(pem)
    os.chmod(tmp, 0o600)
    tmp.replace(path)
    return path


def load_private_key(state_dir: Path = DEFAULT_STATE_DIR) -> Ed25519PrivateKey:
    path = state_dir / PRIVKEY_FILE_NAME
    if not path.exists():
        raise NotEnrolledError(f"private key not found at {path}; run `controlzero enroll` first")
    pem = path.read_bytes()
    key = serialization.load_pem_private_key(pem, password=None)
    if not isinstance(key, Ed25519PrivateKey):
        raise EnrollmentError(f"private key at {path} is not a supported signing key")
    return key


def save_state(state: EnrollmentState, state_dir: Path = DEFAULT_STATE_DIR) -> Path:
    _ensure_state_dir(state_dir)
    path = state_dir / STATE_FILE_NAME
    tmp = path.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(state.to_dict(), indent=2))
    os.chmod(tmp, 0o600)
    tmp.replace(path)
    return path


def load_state(state_dir: Path = DEFAULT_STATE_DIR) -> Optional[EnrollmentState]:
    path = state_dir / STATE_FILE_NAME
    if not path.exists():
        return None
    return EnrollmentState.from_dict(json.loads(path.read_text()))


# ----- enroll -----------------------------------------------------------


def enroll(
    api_url: str,
    token: str,
    *,
    hostname: Optional[str] = None,
    fingerprint_hint: Optional[str] = None,
    plugin_versions: Optional[dict[str, str]] = None,
    state_dir: Path = DEFAULT_STATE_DIR,
    user_email: Optional[str] = None,
    timeout_s: float = 30.0,
) -> EnrollmentState:
    """Run the enrollment round-trip and persist the resulting state.

    Generates a fresh signing keypair, calls ``POST /api/enroll`` with
    the public key, and writes both the state file and the private
    key to ``state_dir``. Returns the populated EnrollmentState.

    Idempotent: re-running with the same fingerprint converges on the
    same machine_id (the backend's upsert handles MDM thundering herds).
    """
    if not token:
        raise TokenError("token is required")
    if not api_url:
        raise EnrollmentError("api_url is required")

    api_url = api_url.rstrip("/")
    hostname = hostname or socket.gethostname() or platform.node() or "unknown"
    fingerprint_hint = fingerprint_hint or compute_fingerprint()
    plugin_versions = plugin_versions or {"sdk": _sdk_version()}

    priv, pub_pem = generate_keypair()

    # Collect device identity for richer enrollment metadata
    try:
        from controlzero.device import get_device_fingerprint, detect_client_name
        dev_fp = get_device_fingerprint()
    except Exception:
        dev_fp = {}

    try:
        client_name = detect_client_name()
    except Exception:
        client_name = "sdk"

    payload = {
        "token": token,
        "fingerprint_hint": fingerprint_hint,
        "hostname": hostname,
        "os": _short_os(),
        "user_email": user_email or "",
        "plugin_versions": plugin_versions,
        "machine_pubkey": pub_pem,
        "ip_address": dev_fp.get("ip_address", ""),
        "mac_address": dev_fp.get("mac_address", ""),
        "serial_number": dev_fp.get("serial_number", ""),
        "client_name": client_name,
    }

    try:
        resp = httpx.post(
            f"{api_url}/api/enroll",
            json=payload,
            timeout=timeout_s,
        )
    except httpx.HTTPError as exc:
        raise EnrollmentError(f"network error during enroll: {exc}") from exc

    if resp.status_code == 401:
        raise TokenError(_extract_error(resp) or "token rejected by server")
    if resp.status_code == 503:
        raise EnrollmentError(
            "server returned 503 FEATURE_DISABLED -- the enrollment API "
            "is currently disabled by the operator. Ask your admin to "
            "set ENROLLMENT_API_ENABLED=true."
        )
    if resp.status_code != 201:
        raise EnrollmentError(
            f"enroll failed: HTTP {resp.status_code}: {_extract_error(resp) or resp.text}"
        )

    body = resp.json()
    state = EnrollmentState(
        machine_id=body["machine_id"],
        org_id=body["org_id"],
        api_url=api_url,
        hostname=hostname,
        fingerprint_hint=fingerprint_hint,
        machine_pubkey_pem=pub_pem,
        enrolled_at=body.get("enrolled_at", ""),
        policy_version=int(body.get("policy_version", 0)),
        org_signing_pubkey_pem=body.get("org_signing_pubkey", ""),
        tamper_behavior=body.get("tamper_behavior", "warn"),
        plugin_versions=plugin_versions,
    )
    save_private_key(priv, state_dir)
    save_state(state, state_dir)
    return state


# ----- signed-request helpers ------------------------------------------


def sign_request(
    state: EnrollmentState,
    method: str,
    path: str,
    body: bytes = b"",
    *,
    state_dir: Path = DEFAULT_STATE_DIR,
    now: Optional[int] = None,
) -> dict[str, str]:
    """Build the X-CZ-* headers for a signed machine request.

    Canonical signed string (matches backend exactly):

        machine_id + "\\n" + timestamp + "\\n" + method + "\\n" +
        path + "\\n" + sha256_hex(body)

    Returns a dict suitable for splatting into ``httpx.post(headers=...)``.
    """
    if state is None or not state.machine_id:
        raise NotEnrolledError("no enrollment state -- run `controlzero enroll` first")

    priv = load_private_key(state_dir)
    ts = str(int(now if now is not None else time.time()))
    body_hash = hashlib.sha256(body).hexdigest()
    canonical = f"{state.machine_id}\n{ts}\n{method.upper()}\n{path}\n{body_hash}"
    sig = priv.sign(canonical.encode("utf-8"))
    return {
        "X-CZ-Machine-ID": state.machine_id,
        "X-CZ-Timestamp": ts,
        "X-CZ-Signature": b64encode(sig).decode("ascii"),
    }


# ----- heartbeat / policy / audit ---------------------------------------


def heartbeat(
    state: Optional[EnrollmentState] = None,
    *,
    state_dir: Path = DEFAULT_STATE_DIR,
    plugin_versions: Optional[dict[str, str]] = None,
    timeout_s: float = 10.0,
) -> dict:
    """Send a heartbeat to ``POST /api/heartbeat``.

    Returns the parsed response body which contains the server time
    and current policy_version. Use the policy_version to decide
    whether to call ``pull_policy`` next.
    """
    state = state or load_state(state_dir)
    if state is None:
        raise NotEnrolledError("not enrolled")

    payload = {}
    if plugin_versions:
        payload["plugin_versions"] = plugin_versions
    body = json.dumps(payload).encode("utf-8") if payload else b""

    headers = sign_request(state, "POST", "/api/heartbeat", body, state_dir=state_dir)
    if body:
        headers["Content-Type"] = "application/json"

    resp = httpx.post(
        f"{state.api_url}/api/heartbeat",
        content=body,
        headers=headers,
        timeout=timeout_s,
    )
    if resp.status_code != 200:
        raise EnrollmentError(
            f"heartbeat failed: HTTP {resp.status_code}: {_extract_error(resp) or resp.text}"
        )
    return resp.json()


def pull_policy(
    state: Optional[EnrollmentState] = None,
    *,
    state_dir: Path = DEFAULT_STATE_DIR,
    timeout_s: float = 10.0,
) -> Optional[dict]:
    """Pull the org's current policy bundle from ``GET /api/policy``.

    Sends If-None-Match with the locally cached policy_version. If
    the server returns 304 Not Modified, returns None (caller keeps
    the existing local bundle). On 200, returns the parsed bundle
    AND updates the local state file's policy_version.
    """
    state = state or load_state(state_dir)
    if state is None:
        raise NotEnrolledError("not enrolled")

    headers = sign_request(state, "GET", "/api/policy", b"", state_dir=state_dir)
    if state.policy_version > 0:
        headers["If-None-Match"] = f'"{state.policy_version}"'

    resp = httpx.get(
        f"{state.api_url}/api/policy",
        headers=headers,
        timeout=timeout_s,
    )
    if resp.status_code == 304:
        return None
    if resp.status_code != 200:
        raise EnrollmentError(
            f"pull_policy failed: HTTP {resp.status_code}: {_extract_error(resp) or resp.text}"
        )
    bundle = resp.json()

    # Verify bundle signature if org pubkey is available
    sig_header = resp.headers.get("X-Policy-Signature")
    if state.org_signing_pubkey_pem and sig_header:
        try:
            import base64 as _b64
            pub_key_obj = serialization.load_pem_public_key(
                state.org_signing_pubkey_pem.encode("utf-8")
            )
            sig_bytes = _b64.b64decode(sig_header)
            pub_key_obj.verify(sig_bytes, resp.content)
        except Exception as exc:
            from controlzero.errors import BundleSignatureError
            raise BundleSignatureError(
                f"Policy bundle signature verification failed: {exc}"
            ) from exc
    elif state.org_signing_pubkey_pem and not sig_header:
        import sys as _sys
        print(
            "controlzero: enrolled with org signing key but server did not sign bundle",
            file=_sys.stderr,
        )
    # No pubkey + no header = backward compatible, pass through

    new_version = int(bundle.get("policy_version", state.policy_version))
    if new_version != state.policy_version:
        state.policy_version = new_version
        save_state(state, state_dir)
    return bundle


def send_audit_batch(
    entries: list[dict],
    state: Optional[EnrollmentState] = None,
    *,
    state_dir: Path = DEFAULT_STATE_DIR,
    timeout_s: float = 15.0,
) -> dict:
    """Stream a batch of audit decisions to ``POST /api/audit``.

    The caller is responsible for batching at most 500 entries per
    call (matches the server-side cap). Each entry should have at
    minimum: id (uuid str), tool_name, decision, ts (ISO8601 string).
    """
    state = state or load_state(state_dir)
    if state is None:
        raise NotEnrolledError("not enrolled")
    if not entries:
        raise EnrollmentError("entries cannot be empty")
    if len(entries) > 500:
        raise EnrollmentError("entries cannot exceed 500 per batch")

    body = json.dumps({"entries": entries}).encode("utf-8")
    headers = sign_request(state, "POST", "/api/audit", body, state_dir=state_dir)
    headers["Content-Type"] = "application/json"

    resp = httpx.post(
        f"{state.api_url}/api/audit",
        content=body,
        headers=headers,
        timeout=timeout_s,
    )
    if resp.status_code != 200:
        raise EnrollmentError(
            f"send_audit_batch failed: HTTP {resp.status_code}: {_extract_error(resp) or resp.text}"
        )
    return resp.json()


# ----- internals --------------------------------------------------------


def _short_os() -> str:
    sysname = platform.system().lower()
    rel = platform.release()
    return f"{sysname} {rel}".strip()


def _sdk_version() -> str:
    try:
        from controlzero import __version__

        return __version__
    except Exception:
        return "unknown"


def _extract_error(resp: "httpx.Response") -> str:
    try:
        body = resp.json()
        if isinstance(body, dict):
            err = body.get("error")
            if isinstance(err, dict):
                return f"{err.get('code', '')}: {err.get('message', '')}"
            if isinstance(err, str):
                return err
    except Exception:
        pass
    return ""
