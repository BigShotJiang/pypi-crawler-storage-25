"""Bidirectional alias table between legacy and canonical action names.

T84 / GitHub #389. Mandate: NO BREAKING CHANGES.

Pre-#350 customer rules used legacy database action names directly: a
rule with ``actions: ["database:query"]`` or ``actions: ["database:DROP"]``
matched a guard call where the SDK passed ``method="query"`` /
``method="DROP"``. Starting with #345/#350 the SDK emits canonical SQL
semantic classes instead (``database:read``, ``database:write``,
``database:admin``, ``database:exec``).

Without an alias shim, that change broke every pre-#350 rule on the
day a customer upgraded the SDK. The alias table fixes this in both
directions:

- A pre-#350 rule with ``actions: ["database:query"]`` keeps matching a
  modern SELECT call (which the SDK emits as ``database:read``)
  because ``database:read`` is the canonical form of ``query``.
- A modern rule with ``actions: ["database:read"]`` keeps matching a
  legacy guard call where the host passed ``method="SELECT"`` because
  ``SELECT`` is one of the read-class aliases.

The enforcer's candidate_actions list is expanded via
``expand_candidate_actions`` to include every alias of every
candidate. Any rule whose actions list contains ANY alias of the
caller's action will match.

The alias table itself is the single source of truth across all three
SDKs (Python / Node / Go). The cross-SDK fixture at
``tests/parity/action_aliases.json`` is byte-identical to the JSON
dump of this table; drift is caught by the parity test in each SDK.

The legacy ``database:delete`` action is intentionally ambiguous:
older policies used it for both row-level DELETE and table-level DROP.
We map it to BOTH ``database:write`` AND ``database:admin`` so neither
modern intent is silently broken.
"""

from __future__ import annotations

import json
from typing import Iterable

# Tool covered by this alias table. Currently only "database" carries
# the legacy <-> canonical split; other tools were added post-#350 and
# always emitted canonical names from day one.
TOOL = "database"

# Canonical class -> ordered list of legacy aliases. Order matters for
# the JSON dump that the parity fixture compares against.
_CLASSES: dict[str, list[str]] = {
    "read": ["query", "SELECT", "EXPLAIN", "SHOW", "DESCRIBE", "FETCH", "READ"],
    "write": ["UPDATE", "INSERT", "DELETE", "MERGE", "UPSERT", "REPLACE"],
    "admin": ["DROP", "CREATE", "TRUNCATE", "ALTER", "GRANT", "REVOKE", "RENAME"],
    "exec": ["execute", "EXECUTE", "EXEC", "CALL", "do"],
}

# Legacy aliases that map to MORE THAN ONE canonical class. A rule
# written against the legacy ambiguous name keeps firing on either
# modern intent. The match direction (legacy -> canonical) is the
# important one here; reverse (canonical -> legacy) is handled by the
# class table above.
_AMBIGUOUS: dict[str, list[str]] = {
    "delete": ["write", "admin"],
}


def _canonical(method: str) -> str:
    return f"{TOOL}:{method}"


# Forward map: legacy alias method -> set of canonical actions.
# Built once at import time so guard() stays cheap on the hot path.
_LEGACY_TO_CANONICAL: dict[str, set[str]] = {}
for cls, aliases in _CLASSES.items():
    canon = _canonical(cls)
    for alias in aliases:
        _LEGACY_TO_CANONICAL.setdefault(alias, set()).add(canon)
for alias, classes in _AMBIGUOUS.items():
    _LEGACY_TO_CANONICAL.setdefault(alias, set()).update(_canonical(c) for c in classes)

# Reverse map: canonical method -> set of legacy aliases (as full
# tool:method actions).
_CANONICAL_TO_LEGACY: dict[str, set[str]] = {}
for cls, aliases in _CLASSES.items():
    canon = _canonical(cls)
    _CANONICAL_TO_LEGACY[canon] = {_canonical(a) for a in aliases}


def expand_candidate_actions(actions: Iterable[str]) -> list[str]:
    """Expand an iterable of candidate actions to include every known alias.

    Both directions are expanded:

    - Legacy ``database:query`` adds canonical ``database:read``.
    - Canonical ``database:read`` adds every legacy alias
      (``database:query``, ``database:SELECT``, ...).
    - Ambiguous legacy ``database:delete`` adds BOTH ``database:write``
      and ``database:admin``.

    The original action is always preserved at the head of the list so
    callers that read the first element (audit trail provenance) keep
    seeing the un-expanded form.

    Order is stable: original actions first (in input order), then
    expansions in deterministic class+alias order.
    """
    seen: set[str] = set()
    out: list[str] = []

    for action in actions:
        if action and action not in seen:
            seen.add(action)
            out.append(action)

    # Second pass: walk every original action and append its aliases.
    # Two-pass keeps the input order for the originals and gives a
    # deterministic ordering for the expansions.
    for action in list(out):
        if not action or ":" not in action:
            continue
        tool, method = action.split(":", 1)
        if tool != TOOL:
            continue
        # Legacy method -> canonical(s).
        for canon in sorted(_LEGACY_TO_CANONICAL.get(method, ())):
            if canon not in seen:
                seen.add(canon)
                out.append(canon)
        # Canonical method -> legacy aliases.
        for legacy in sorted(_CANONICAL_TO_LEGACY.get(action, ())):
            if legacy not in seen:
                seen.add(legacy)
                out.append(legacy)

    return out


def alias_table_json() -> str:
    """Return the alias table as a deterministic JSON string.

    Used by the parity test in each SDK to confirm byte-identical
    alias content across Python / Node / Go. The on-disk fixture at
    ``tests/parity/action_aliases.json`` carries an extra ``comment``
    key documenting the contract; this dump omits the comment so each
    SDK's hash check can compare apples to apples.
    """
    payload = {
        "version": 1,
        "tool": TOOL,
        "classes": {
            cls: {
                "canonical": _canonical(cls),
                "aliases": list(aliases),
            }
            for cls, aliases in _CLASSES.items()
        },
        "ambiguous_aliases": {
            alias: list(classes) for alias, classes in _AMBIGUOUS.items()
        },
    }
    return json.dumps(payload, indent=2, sort_keys=False)


__all__ = ["TOOL", "expand_candidate_actions", "alias_table_json"]
