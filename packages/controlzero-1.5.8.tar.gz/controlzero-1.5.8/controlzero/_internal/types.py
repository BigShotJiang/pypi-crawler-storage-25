"""Internal type definitions. Public users should import from controlzero, not here."""

from typing import Any
from pydantic import BaseModel, Field


class PolicyRule(BaseModel):
    """Internal canonical representation of a single policy rule.

    The user-facing schema (see policy_loader) is friendlier; this is what the
    evaluator consumes after translation.
    """
    id: str = ""
    name: str = ""
    effect: str  # "allow" or "deny"
    actions: list[str] = Field(default_factory=list)
    resources: list[str] = Field(default_factory=list)
    conditions: dict[str, Any] = Field(default_factory=dict)
    reason: str = ""  # Human-readable explanation, surfaced in audit + denies
    # Machine-readable reason code from the REASON_CODE_* enum in
    # enforcer.py. Set for synthetic rules emitted by the bundle
    # translator (e.g. the empty-bundle deny carries
    # "NO_ACTIVE_POLICIES"). User-authored rules leave this empty and
    # the evaluator does not promote them to a code.
    reason_code: str = ""
    # HITL escalation tag (HITL-5a, gh#538): when True and the rule's
    # effect is `deny`, the SDK marks the resulting PolicyDecision as
    # `hitl_eligible=True`. The actual approval-request flow ships in
    # 1.6.0 (HITL-6a, gh#542); 1.5.8 just acknowledges the field so a
    # customer pre-tagging rules for HITL doesn't crash an old client.
    escalate_on_deny: bool = False
