"""Local policy evaluator. Pure Python, in-process, fail-closed by default.

Copied from the proven control_zero.policy.enforcer module and adapted for the
local-first surface. The eval logic is identical so behavior is consistent
across hosted and local modes.

Pattern matching uses Python's stdlib fnmatch (shell-style globs). All friendly
shorthand (e.g. "delete_*" -> "delete_*:*") is normalized in policy_loader.py
BEFORE rules reach this evaluator. By the time rules arrive here, every action
is canonical "tool:method" form. This keeps the evaluator simple and matches
the legacy hosted engine's behavior.

DLP scanning (added 2026-04-09): after the tool-name policy check, the
evaluator optionally scans tool arguments for PII, secrets, and sensitive data
patterns. A "block" DLP match overrides an "allow" decision. "detect" matches
are recorded in the audit entry without blocking.
"""

from __future__ import annotations

import fnmatch
from dataclasses import dataclass, field
from typing import Optional

from controlzero._internal.dlp_scanner import (
    DLPScanner,
    extract_text_from_args,
)
from controlzero._internal.types import PolicyRule


# Canonical reason_code enum values. Stable machine-readable labels
# so integrations + dashboards can branch on decision provenance
# without regex-matching the human-readable `reason` string.
#
# Added 2026-04-19 after the 2026-04-19 P0: the SDK fail-closed with "No
# active policies. Define one in the Control Zero dashboard." when
# the user had in fact defined three; the three surfaces disagreed
# because policy_attachments was empty. reason_code lets the hosted
# dashboard, local-mode CLI, and audit ingestion distinguish the
# fail-closed paths without parsing English text.
#
# Extended 2026-04-20 (#228 Phase 2) from 5 values to 8. Additions
# are strictly additive: existing consumers that switch on the old
# five keep working because the enum only grows. The three new codes
# correspond to surfaces that previously had no machine label at all:
#
#   - RULE_MATCH         -- a user-authored rule fired (allow OR deny).
#   - BUNDLE_MISSING     -- bundle could not be loaded (never synced,
#                           backend 4xx/5xx, decrypt failure). Honors
#                           `default_on_missing`.
#   - DLP_BLOCKED        -- DLP rule overrode the policy-level allow.
REASON_CODE_RULE_MATCH = "RULE_MATCH"
REASON_CODE_NO_RULE_MATCH = "NO_RULE_MATCH"
REASON_CODE_NO_ACTIVE_POLICIES = "NO_ACTIVE_POLICIES"
REASON_CODE_BUNDLE_MISSING = "BUNDLE_MISSING"
REASON_CODE_BUNDLE_TAMPERED = "BUNDLE_TAMPERED"
REASON_CODE_MACHINE_QUARANTINED = "MACHINE_QUARANTINED"
REASON_CODE_NETWORK_ERROR = "NETWORK_ERROR"
REASON_CODE_DLP_BLOCKED = "DLP_BLOCKED"
# Governance trail (T108, 2026-05-12). Emitted once per Client init when
# the user has set CONTROLZERO_LOCAL_OVERRIDE=1 with an api_key, telling
# the SDK to bypass the hosted bundle in favour of a local file. Posted
# to the remote audit sink so ops can detect override usage via the
# normal audit dashboard + alert on it. NOT a deny / allow decision --
# decision is "audit" and policy_id is "<lifecycle>".
REASON_CODE_LOCAL_OVERRIDE_ACTIVE = "LOCAL_OVERRIDE_ACTIVE"

# HITL approval-flow reason codes (HITL-5a, gh#538). The actual
# request-approval flow ships in 1.6.0 (HITL-6a, gh#542); 1.5.8
# registers the codes so audit rows from a 1.6.0+ client can be
# accepted by a 1.5.8 ingest path without rejection.
REASON_CODE_HITL_SDK_TIMEOUT = "HITL_SDK_TIMEOUT"
REASON_CODE_HITL_SLA_EXPIRED = "HITL_SLA_EXPIRED"
REASON_CODE_HITL_BACKEND_UNREACHABLE = "HITL_BACKEND_UNREACHABLE"
REASON_CODE_HITL_POLICY_VERSION_CONFLICT = "HITL_POLICY_VERSION_CONFLICT"
REASON_CODE_HITL_NO_APPROVER_AVAILABLE = "HITL_NO_APPROVER_AVAILABLE"
REASON_CODE_HITL_IDENTITY_NOT_IN_ORG = "HITL_IDENTITY_NOT_IN_ORG"
REASON_CODE_HITL_IDENTITY_REQUIRED = "HITL_IDENTITY_REQUIRED"
REASON_CODE_HITL_IDENTITY_CLAIM_REJECTED = "HITL_IDENTITY_CLAIM_REJECTED"
REASON_CODE_HITL_ARGS_HASH_MISMATCH = "HITL_ARGS_HASH_MISMATCH"

VALID_REASON_CODES = frozenset({
    REASON_CODE_RULE_MATCH,
    REASON_CODE_NO_RULE_MATCH,
    REASON_CODE_NO_ACTIVE_POLICIES,
    REASON_CODE_BUNDLE_MISSING,
    REASON_CODE_BUNDLE_TAMPERED,
    REASON_CODE_MACHINE_QUARANTINED,
    REASON_CODE_NETWORK_ERROR,
    REASON_CODE_DLP_BLOCKED,
    REASON_CODE_LOCAL_OVERRIDE_ACTIVE,
    REASON_CODE_HITL_SDK_TIMEOUT,
    REASON_CODE_HITL_SLA_EXPIRED,
    REASON_CODE_HITL_BACKEND_UNREACHABLE,
    REASON_CODE_HITL_POLICY_VERSION_CONFLICT,
    REASON_CODE_HITL_NO_APPROVER_AVAILABLE,
    REASON_CODE_HITL_IDENTITY_NOT_IN_ORG,
    REASON_CODE_HITL_IDENTITY_REQUIRED,
    REASON_CODE_HITL_IDENTITY_CLAIM_REJECTED,
    REASON_CODE_HITL_ARGS_HASH_MISMATCH,
})

# Synthetic policy_id sentinels (T79 / the deny-deny postmortem,
# 2026-05-11). When a deny is emitted by anything OTHER than a
# user-authored rule, the SDK stamps the audit row's `policy_id` with
# one of these `synthetic:*` values so the audit dashboard can render
# a recognizable chip and link it to the right troubleshooting
# anchor. Without this, four very different bug classes (stale
# bundle, missing resource gate, vocabulary mismatch, genuine
# no-match) all looked identical in the Policy column (blank
# placeholder + Decision=Deny + reason_code=NO_RULE_MATCH).
#
# The `synthetic:` prefix is a contract: the backend audit ingest
# stores it verbatim (no validation on policy_id content), the
# frontend matches on the prefix to switch chip styling, and the
# values themselves mirror the reason_code enum 1:1 PLUS one new
# value (RESOURCE_GATE_SKIP) that captures the T83-class bug where
# every action-matching rule was skipped purely on the resource gate.
SYNTHETIC_POLICY_ID_PREFIX = "synthetic:"
SYNTHETIC_NO_RULE_MATCH = "synthetic:NO_RULE_MATCH"
SYNTHETIC_NO_ACTIVE_POLICIES = "synthetic:NO_ACTIVE_POLICIES"
SYNTHETIC_BUNDLE_MISSING = "synthetic:BUNDLE_MISSING"
SYNTHETIC_RESOURCE_GATE_SKIP = "synthetic:RESOURCE_GATE_SKIP"
SYNTHETIC_QUARANTINE = "synthetic:QUARANTINE"
SYNTHETIC_ENGINE_UNAVAILABLE = "synthetic:ENGINE_UNAVAILABLE"

VALID_SYNTHETIC_POLICY_IDS = frozenset({
    SYNTHETIC_NO_RULE_MATCH,
    SYNTHETIC_NO_ACTIVE_POLICIES,
    SYNTHETIC_BUNDLE_MISSING,
    SYNTHETIC_RESOURCE_GATE_SKIP,
    SYNTHETIC_QUARANTINE,
    SYNTHETIC_ENGINE_UNAVAILABLE,
})

# Canonical bundle-level default values. These must stay in lockstep
# with the backend's `DefaultBundleAction` / `DefaultBundleOnMissing`
# / `DefaultBundleOnTamper` constants (bundle_handler.go). They are
# the values the SDK falls back to when a bundle (a) was built by an
# old backend that predates schema 1.1 and has no default_* fields,
# or (b) parses one of the fields as an unknown value. Matches the
# pre-#228 hard-coded behaviour: no-match deny, missing-bundle deny,
# tamper warn.
DEFAULT_BUNDLE_ACTION = "deny"
DEFAULT_BUNDLE_ON_MISSING = "deny"
DEFAULT_BUNDLE_ON_TAMPER = "warn"

VALID_DEFAULT_ACTIONS = frozenset({"deny", "allow", "warn"})
VALID_DEFAULT_ON_MISSING = frozenset({"deny", "allow"})
VALID_DEFAULT_ON_TAMPER = frozenset({"warn", "deny", "deny-all", "quarantine"})


@dataclass
class PolicyDecision:
    """Result of a policy evaluation.

    Attributes:
        effect: One of "allow", "deny", "warn", "audit".
        decision: Alias for effect, for ergonomic Hello World code.
        policy_id: ID of the rule that matched, or None if no match.
        reason: Human-readable reason for the decision. Keep this for
            display / error messages; it can be translated, re-worded,
            or localized without breaking consumers.
        reason_code: Machine-readable code from the REASON_CODE_* set.
            Stable across SDK versions -- automation should branch on
            this, not on `reason`. Empty string when the decision
            carries no structured reason (e.g. a plain user-policy
            match).
        evaluated_rules: How many rules were checked before a match.
        dlp_findings: List of DLP match dicts for the audit trail.
    """
    effect: str
    policy_id: Optional[str] = None
    reason: Optional[str] = None
    reason_code: str = ""
    evaluated_rules: int = 0
    dlp_findings: list[dict] = field(default_factory=list)

    @property
    def decision(self) -> str:
        """Alias for `effect`. Reads more naturally in user code."""
        return self.effect

    @property
    def allowed(self) -> bool:
        """True if the call was allowed."""
        return self.effect == "allow"

    @property
    def denied(self) -> bool:
        """True if the call was denied."""
        return self.effect == "deny"


class PolicyDeniedError(Exception):
    """Raised by `Client.guard(..., raise_on_deny=True)` when a policy denies an action."""

    def __init__(self, decision: PolicyDecision):
        self.decision = decision
        super().__init__(
            f"Policy denied: {decision.reason or 'no reason provided'}"
        )


class PolicyEvaluator:
    """In-process policy evaluator. Fail-closed by default.

    Loads a list of internal `PolicyRule` objects and evaluates tool calls
    against them in order. The first matching rule wins. If no rule matches,
    the call is denied (fail-closed).

    Optionally accepts a DLPScanner to inspect tool arguments for sensitive
    content after the tool-name policy check passes.

    All pattern matching uses `fnmatch.fnmatchcase` (shell-style globs):
        *           matches everything
        delete_*    matches anything starting with "delete_"
        github:*    matches any method on the github tool
        *:read      matches the read method on any tool
        model:*-haiku-*  matches any model with -haiku- in its name
    """

    def __init__(
        self,
        rules: Optional[list[PolicyRule]] = None,
        dlp_scanner: Optional[DLPScanner] = None,
        default_action: str = DEFAULT_BUNDLE_ACTION,
    ):
        self._rules: list[PolicyRule] = rules or []
        self._dlp_scanner: Optional[DLPScanner] = dlp_scanner
        # Coerce unknown values to the canonical deny default. Keeps the
        # evaluator safe even if a caller hands in a stale / bad value
        # from a future schema -- SDK fails closed, never raises.
        self._default_action: str = (
            default_action if default_action in VALID_DEFAULT_ACTIONS else DEFAULT_BUNDLE_ACTION
        )

    def load(self, rules: list[PolicyRule]) -> None:
        """Replace the rule set."""
        self._rules = list(rules)

    def set_dlp_scanner(self, scanner: DLPScanner) -> None:
        """Set or replace the DLP scanner."""
        self._dlp_scanner = scanner

    def set_default_action(self, action: str) -> None:
        """Replace the no-match default action.

        Called by the Client after a hosted-policy refresh so the
        bundle's resolved ``default_action`` takes effect without
        rebuilding the evaluator. Unknown values coerce to the
        canonical deny default, matching pre-#228 fail-closed
        behaviour.
        """
        self._default_action = (
            action if action in VALID_DEFAULT_ACTIONS else DEFAULT_BUNDLE_ACTION
        )

    @property
    def default_action(self) -> str:
        """The effective no-match default action."""
        return self._default_action

    def evaluate(
        self,
        tool: str,
        method: str = "*",
        context: Optional[dict] = None,
        args: Optional[dict] = None,
    ) -> PolicyDecision:
        """Evaluate a tool call against the loaded rules.

        Args:
            tool: Tool name (e.g. "delete_file", "github").
            method: Optional method name. Defaults to "*" which matches any.
            context: Optional context dict with `resource` and `tags` keys.
            args: Optional tool arguments dict. Scanned for DLP patterns if
                  a DLPScanner is configured.

        Returns:
            PolicyDecision. Always returns; never raises.
        """
        action = f"{tool}:{method}"

        # Semantic-class layer (#345): when the action carries a
        # canonical SQL class (database:read|write|admin|exec) the
        # evaluator matches rules against BOTH the per-keyword action
        # above AND this class action. A rule whose actions list
        # contains `database:read` therefore fires for any read-shaped
        # SQL (SELECT, EXPLAIN, SHOW, CTE, ...) regardless of dialect
        # spelling, while existing per-keyword rules
        # (`database:DROP`) keep working unchanged. Two sources for
        # the class action: the caller may provide it in
        # ``context['action_semantic_class']`` (used by the hook-check
        # CLI), or we derive it on the fly from ``args['sql']`` when
        # the tool is ``database`` and no class was provided.
        ctx_dict = context or {}
        semantic_action = ctx_dict.get("action_semantic_class") or ""
        if not semantic_action and tool == "database" and args:
            from controlzero._internal.hook_extractors import sql_semantic_class
            sql_text = args.get("sql") if isinstance(args, dict) else None
            if isinstance(sql_text, str) and sql_text:
                cls = sql_semantic_class(sql_text)
                if cls:
                    semantic_action = f"{tool}:{cls}"
        candidate_actions: list[str] = [action]
        if semantic_action and semantic_action != action:
            candidate_actions.append(semantic_action)

        # T84: expand candidate_actions through the legacy <-> canonical
        # alias table so pre-#350 customer rules using legacy database
        # action names (database:query, database:DROP, database:execute,
        # ...) keep matching modern SDK calls that emit canonical
        # semantic classes (database:read|write|admin|exec), and vice
        # versa. NO BREAKING CHANGES contract -- see #389.
        from controlzero._internal.action_aliases import expand_candidate_actions
        candidate_actions = expand_candidate_actions(candidate_actions)

        resource = ctx_dict.get("resource")
        evaluated = 0
        # T79: track whether the no-match path was caused PURELY by the
        # resource gate (every action-matching rule was skipped because
        # the resource didn't match) so the synthetic deny can be
        # tagged RESOURCE_GATE_SKIP rather than the more generic
        # NO_RULE_MATCH. This is the T83-class signature -- a rule's
        # actions matched the call but its `resources:` list excluded it.
        action_matched_resource_skipped = False
        action_matched_any = False

        for rule in self._rules:
            evaluated += 1
            if not any(_glob_any(rule.actions, a) for a in candidate_actions):
                continue
            action_matched_any = True
            if rule.resources:
                # T83: a rule whose resources list contains "*" matches
                # universally and must NOT require the caller to supply
                # context.resource. The dashboard always emits
                # resources:["*"] for unscoped rules, so prior to this
                # fix every cz.guard() call without an explicit resource
                # was skipping every rule and falling through to the
                # default deny (the deny-deny incident, 2026-05-10).
                # Logic now: if any pattern in rule.resources is the
                # universal "*", treat the gate as satisfied; otherwise
                # require a caller-supplied resource and glob-match it.
                if "*" not in rule.resources:
                    if not resource or not _glob_any(rule.resources, resource):
                        action_matched_resource_skipped = True
                        continue
            if not self._conditions_match(rule.conditions, context, args):
                continue
            # Prefer the rule-declared reason_code (only synthetic
            # rules set one today -- e.g. the empty-bundle
            # NO_ACTIVE_POLICIES deny). Everything else defaults to
            # RULE_MATCH so consumers can tell a user-authored rule
            # firing apart from the no-match fallthrough below.
            rule_code = getattr(rule, "reason_code", "") or ""
            decision_code = rule_code or REASON_CODE_RULE_MATCH
            decision = PolicyDecision(
                effect=rule.effect,
                policy_id=rule.id or rule.name or None,
                # User-provided reason wins. Falls back to canned text only if
                # the rule had no `reason:` field in the source policy.
                reason=rule.reason or f"Matched rule {rule.id or rule.name}".strip(),
                reason_code=decision_code,
                evaluated_rules=evaluated,
            )
            # DLP scan: only when the policy decision is "allow" and args exist
            if decision.allowed and args and self._dlp_scanner is not None:
                decision = self._apply_dlp_scan(decision, args)
            return decision

        # No-match default. Pre-#228 this was hard-coded to deny; as
        # of Phase 2 the bundle can override it (default_action =
        # deny|allow|warn). The reason_code stays NO_RULE_MATCH so
        # "rule set evaluated, nothing matched" is distinguishable
        # from "bundle was empty" (NO_ACTIVE_POLICIES) and "bundle
        # was missing" (BUNDLE_MISSING).
        #
        # Reason-text note: the historical "fail-closed default"
        # phrase is kept for the deny case so downstream consumers
        # that regex-match the reason string (a pattern we actively
        # discourage -- use reason_code instead) keep working.
        if self._default_action == "deny":
            reason = "No matching policy rule (fail-closed default)"
        elif self._default_action == "allow":
            reason = "No matching policy rule (default_action=allow)"
        else:  # "warn"
            reason = "No matching policy rule (default_action=warn)"

        # T79: distinguish the T83-class signature ("a rule's actions
        # matched but its resources gate excluded the call") from the
        # generic no-match. Both still apply default_action; the
        # synthetic policy_id is what the audit dashboard reads to
        # surface the right remediation.
        if (
            self._default_action == "deny"
            and action_matched_any
            and action_matched_resource_skipped
        ):
            synthetic_id = SYNTHETIC_RESOURCE_GATE_SKIP
        else:
            synthetic_id = SYNTHETIC_NO_RULE_MATCH

        return PolicyDecision(
            effect=self._default_action,
            policy_id=synthetic_id,
            reason=reason,
            reason_code=REASON_CODE_NO_RULE_MATCH,
            evaluated_rules=evaluated,
        )

    def _conditions_match(
        self,
        rule_conditions: Optional[dict],
        context: Optional[dict],
        args: Optional[dict],
    ) -> bool:
        """Match rule.conditions against merged context+args using fnmatch globs.

        All condition keys must match. Missing key = no match. Context keys
        override args on collision. Nested ``context['tags']`` dict is flattened.
        """
        if not rule_conditions:
            return True
        import fnmatch as _fn

        merged: dict = {}
        if args:
            merged.update(args)
        if context:
            merged.update(context)
            tags = context.get("tags") or {}
            if isinstance(tags, dict):
                merged.update(tags)
        for key, pattern in rule_conditions.items():
            value = merged.get(key)
            if value is None:
                return False
            if not _fn.fnmatchcase(str(value), str(pattern)):
                return False
        return True

    def _apply_dlp_scan(
        self, decision: PolicyDecision, args: dict
    ) -> PolicyDecision:
        """Run DLP scanner on tool arguments and update decision if needed.

        If any DLP rule has action="block", the decision is overridden to DENY.
        If rules have action="detect" or "mask", findings are attached to the
        decision for audit but the call is still allowed.
        """
        if self._dlp_scanner is None:
            return decision

        text = extract_text_from_args(args)
        if not text:
            return decision

        matches = self._dlp_scanner.scan(text)
        if not matches:
            return decision

        findings = self._dlp_scanner.get_findings_for_audit(matches)
        decision.dlp_findings = findings

        if self._dlp_scanner.has_blocking_match(matches):
            # Find the first blocking rule for the reason message
            blocking = next(m for m in matches if m.action == "block")
            return PolicyDecision(
                effect="deny",
                policy_id=decision.policy_id,
                reason=(
                    f"DLP rule '{blocking.rule_name}' matched "
                    f"{blocking.category} content in tool arguments"
                ),
                # DLP_BLOCKED means: the tool-name policy said allow,
                # but a DLP rule found a hit in the arguments and
                # overrode the decision. Dashboards bucket this as a
                # different failure surface from a rule-authored deny
                # so ops can tell "my tool is blocked" from "my
                # argument tripped a DLP guard" apart.
                reason_code=REASON_CODE_DLP_BLOCKED,
                evaluated_rules=decision.evaluated_rules,
                dlp_findings=findings,
            )

        return decision


def _glob_any(patterns: list[str], value: str) -> bool:
    """True if any pattern matches the value via fnmatch.fnmatchcase.

    fnmatchcase is case-sensitive (matches policy semantics) and supports the
    same syntax users learn from .gitignore: *, ?, [seq], [!seq].
    """
    for p in patterns:
        if fnmatch.fnmatchcase(value, p):
            return True
    return False
