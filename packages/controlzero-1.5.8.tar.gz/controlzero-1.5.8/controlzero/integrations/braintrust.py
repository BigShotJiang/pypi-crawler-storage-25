"""Braintrust integration for ControlZero.

Provides a callback handler that sends governance decisions and audit
events to Braintrust for evaluation and monitoring.

Usage::

    from controlzero import Client
    from controlzero.integrations.braintrust import BraintrustGovernanceLogger

    cz = Client(policy={"rules": [{"allow": "*"}]})

    logger = BraintrustGovernanceLogger(project_name="my-agent")

    decision = cz.guard("database", {"sql": "SELECT 1"})
    logger.log_decision(
        tool="database",
        method="query",
        decision=decision.effect,
        latency_ms=0.12,
    )
"""

from __future__ import annotations

from typing import Any, Optional

try:
    import braintrust  # noqa: F401

    _HAS_BRAINTRUST = True
except ImportError:
    _HAS_BRAINTRUST = False


class BraintrustGovernanceLogger:
    """Logs ControlZero governance decisions to Braintrust for evaluation.

    If the braintrust package is not installed, operations are no-ops.
    """

    def __init__(
        self,
        project_name: str = "controlzero",
        experiment_name: Optional[str] = None,
    ) -> None:
        self._project_name = project_name
        self._experiment_name = experiment_name
        self._logger = None

        if _HAS_BRAINTRUST:
            self._logger = braintrust.init_logger(project=project_name)

    def log_decision(
        self,
        tool: str,
        method: str,
        decision: str,
        latency_ms: float = 0,
        policy_id: Optional[str] = None,
        context: Optional[dict] = None,
        metadata: Optional[dict] = None,
    ) -> None:
        """Log a governance decision to Braintrust.

        Args:
            tool: Tool name
            method: Method name
            decision: Policy decision (allow/deny)
            latency_ms: Policy evaluation latency
            policy_id: ID of the matched policy
            context: Request context
            metadata: Additional metadata
        """
        if not self._logger:
            return

        self._logger.log(
            input={
                "tool": tool,
                "method": method,
                "action": f"{tool}:{method}",
                "context": context or {},
            },
            output={
                "decision": decision,
                "policy_id": policy_id,
            },
            metadata={
                "latency_ms": latency_ms,
                "source": "controlzero",
                **(metadata or {}),
            },
            scores={
                "governance_pass": 1.0 if decision == "allow" else 0.0,
            },
        )

    def log_tool_call(
        self,
        tool: str,
        method: str,
        arguments: dict,
        result: Any = None,
        error: Optional[str] = None,
        duration_ms: float = 0,
    ) -> None:
        """Log a complete tool call (decision + execution) to Braintrust.

        Args:
            tool: Tool name
            method: Method name
            arguments: Tool call arguments
            result: Tool call result (if successful)
            error: Error message (if failed)
            duration_ms: Total call duration
        """
        if not self._logger:
            return

        self._logger.log(
            input={
                "tool": tool,
                "method": method,
                "arguments": arguments,
            },
            output={
                "result": str(result)[:1000] if result else None,
                "error": error,
            },
            metadata={
                "duration_ms": duration_ms,
                "source": "controlzero",
                "status": "error" if error else "success",
            },
        )

    def flush(self) -> None:
        """Flush any buffered logs to Braintrust."""
        if self._logger and hasattr(self._logger, "flush"):
            self._logger.flush()
