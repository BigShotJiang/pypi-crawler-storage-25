"""Langfuse integration for ControlZero.

Provides a callback handler that sends governance decisions, policy
evaluations, and audit events to Langfuse for observability.

Usage::

    from controlzero import Client
    from controlzero.integrations.langfuse import LangfuseGovernanceHandler

    cz = Client(policy={"rules": [{"allow": "*"}]})

    handler = LangfuseGovernanceHandler()

    decision = cz.guard("database", {"sql": "SELECT 1"})
    handler.log_governance_event(
        tool="database",
        method="query",
        decision=decision.effect,
    )
"""

from __future__ import annotations

from typing import Any, Optional

try:
    from langfuse import Langfuse

    _HAS_LANGFUSE = True
except ImportError:
    _HAS_LANGFUSE = False


class LangfuseGovernanceHandler:
    """Sends ControlZero governance events to Langfuse for observability.

    If the langfuse package is not installed, all operations are no-ops.
    Langfuse reads LANGFUSE_PUBLIC_KEY, LANGFUSE_SECRET_KEY, and
    LANGFUSE_HOST from environment variables.
    """

    def __init__(
        self,
        public_key: Optional[str] = None,
        secret_key: Optional[str] = None,
        host: Optional[str] = None,
    ) -> None:
        self._client = None
        if _HAS_LANGFUSE:
            kwargs: dict = {}
            if public_key:
                kwargs["public_key"] = public_key
            if secret_key:
                kwargs["secret_key"] = secret_key
            if host:
                kwargs["host"] = host
            self._client = Langfuse(**kwargs)

    def log_governance_event(
        self,
        tool: str,
        method: str,
        decision: str,
        latency_ms: float = 0,
        policy_id: Optional[str] = None,
        context: Optional[dict] = None,
        trace_id: Optional[str] = None,
    ) -> Optional[str]:
        """Log a governance decision as a Langfuse generation event.

        Args:
            tool: Tool name
            method: Method name
            decision: Policy decision (allow/deny)
            latency_ms: Policy evaluation latency
            policy_id: ID of the matched policy
            context: Request context
            trace_id: Optional trace ID to attach to

        Returns:
            The Langfuse trace ID, or None if Langfuse is not available
        """
        if not self._client:
            return None

        trace = self._client.trace(
            id=trace_id,
            name=f"governance:{tool}:{method}",
            metadata={
                "source": "controlzero",
                "tool": tool,
                "method": method,
            },
            tags=["controlzero", f"decision:{decision}"],
        )

        trace.generation(
            name="policy_evaluation",
            input={"action": f"{tool}:{method}", "context": context or {}},
            output={"decision": decision, "policy_id": policy_id},
            metadata={"latency_ms": latency_ms},
            level="DEFAULT" if decision == "allow" else "WARNING",
        )

        return trace.id

    def log_tool_execution(
        self,
        tool: str,
        method: str,
        arguments: dict,
        result: Any = None,
        error: Optional[str] = None,
        duration_ms: float = 0,
        trace_id: Optional[str] = None,
        input_tokens: int = 0,
        output_tokens: int = 0,
        model: Optional[str] = None,
    ) -> None:
        """Log a complete tool execution as a Langfuse span.

        Args:
            tool: Tool name
            method: Method name
            arguments: Tool call arguments
            result: Tool call result
            error: Error message if failed
            duration_ms: Execution duration
            trace_id: Trace ID from log_governance_event
            input_tokens: Token count (for LLM calls)
            output_tokens: Token count (for LLM calls)
            model: Model identifier (for LLM calls)
        """
        if not self._client:
            return

        trace = self._client.trace(id=trace_id) if trace_id else self._client.trace(
            name=f"tool:{tool}:{method}",
            tags=["controlzero"],
        )

        span_kwargs: dict = {
            "name": f"{tool}:{method}",
            "input": arguments,
            "metadata": {
                "duration_ms": duration_ms,
                "source": "controlzero",
            },
            "level": "ERROR" if error else "DEFAULT",
        }

        if result is not None:
            span_kwargs["output"] = str(result)[:2000]
        if error:
            span_kwargs["output"] = {"error": error}

        if model:
            trace.generation(
                model=model,
                usage={"input": input_tokens, "output": output_tokens},
                **span_kwargs,
            )
        else:
            trace.span(**span_kwargs)

    def flush(self) -> None:
        """Flush buffered events to Langfuse."""
        if self._client:
            self._client.flush()

    def shutdown(self) -> None:
        """Flush and shutdown the Langfuse client."""
        if self._client:
            self._client.shutdown()
