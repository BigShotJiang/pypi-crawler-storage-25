"""
Governed CrewAI Agent wrapper.

Provides governance enforcement for CrewAI agents including:
- Role-based access control
- Tool filtering based on agent role
- Action logging
- Execution tracking
"""

from __future__ import annotations

import time
from functools import wraps
from typing import Any, Callable, List, Optional

try:
    from crewai import Agent
    from crewai.tools import BaseTool as CrewAIBaseTool
    CREWAI_AVAILABLE = True
except ImportError:
    CREWAI_AVAILABLE = False
    class Agent:
        pass
    class CrewAIBaseTool:
        pass

from controlzero.client import Client
from controlzero.errors import PolicyDeniedError, PolicyDecision
from controlzero.integrations.crewai.tool import GovernedCrewTool


class GovernedCrewAgent:
    """
    Governance wrapper for CrewAI Agent.

    Wraps a CrewAI Agent to provide:
    - Role-based policy enforcement
    - Tool-level governance
    - Action audit logging
    - Execution tracking

    Usage:
        from crewai import Agent

        researcher = Agent(
            role="Senior Researcher",
            goal="Research topics thoroughly",
            backstory="You are an expert researcher...",
            tools=[search_tool, scrape_tool],
        )

        governed_researcher = GovernedCrewAgent(
            agent=researcher,
            client=client,
            wrap_tools=True,
        )

        # Use in a crew
        crew = Crew(
            agents=[governed_researcher.agent],
            tasks=[...],
        )
    """

    def __init__(
        self,
        agent: Agent,
        client: Client,
        wrap_tools: bool = True,
        agent_name: Optional[str] = None,
        allowed_tools: Optional[List[str]] = None,
    ):
        """
        Initialize governed agent.

        Args:
            agent: The CrewAI Agent to wrap
            client: ControlZero client
            wrap_tools: Whether to wrap agent tools with governance
            agent_name: Name for logging (defaults to agent.role)
            allowed_tools: List of allowed tool names (filters tools)
        """
        if not CREWAI_AVAILABLE:
            raise ImportError(
                "crewai is required. Install with: pip install crewai"
            )

        self._agent = agent
        self._client = client
        self._agent_name = agent_name or agent.role
        self._allowed_tools = allowed_tools

        # Filter tools if allowlist specified
        if allowed_tools and agent.tools:
            agent.tools = [
                t for t in agent.tools
                if getattr(t, 'name', str(t)) in allowed_tools
            ]

        # Wrap tools with governance
        if wrap_tools and agent.tools:
            self._wrap_agent_tools()

        # Tracking
        self._total_actions = 0
        self._session_start = time.time()

    def _wrap_agent_tools(self) -> None:
        """Wrap all agent tools with governance."""
        governed_tools = []
        for tool in self._agent.tools:
            if isinstance(tool, GovernedCrewTool):
                governed_tools.append(tool)
            elif isinstance(tool, CrewAIBaseTool):
                governed_tools.append(
                    GovernedCrewTool(
                        base_tool=tool,
                        client=self._client,
                    )
                )
            else:
                # Callable tools - wrap inline
                governed_tools.append(tool)
        self._agent.tools = governed_tools

    def execute_task(
        self,
        task: Any,
        context: Optional[str] = None,
        tools: Optional[List] = None,
    ) -> str:
        """
        Execute a task with governance.

        Args:
            task: The task to execute
            context: Additional context
            tools: Override tools for this execution

        Returns:
            Task result string
        """
        tool_name = self._agent_name
        decision = self._client.guard(
            tool_name,
            method="call",
            context={
                "tags": {
                    "framework": "crewai",
                    "agent_id": self._agent_name,
                    "action_detail": "execute_task",
                },
            },
        )

        if decision.denied:
            raise PolicyDeniedError(decision)

        start = time.perf_counter()
        self._total_actions += 1

        try:
            result = self._agent.execute_task(
                task=task,
                context=context,
                tools=tools or self._agent.tools,
            )

            latency_ms = int((time.perf_counter() - start) * 1000)
            try:
                self._client._audit_decision(
                    tool=tool_name,
                    method="call",
                    args={
                        "status": "success",
                        "latency_ms": latency_ms,
                        "agent_role": self._agent.role,
                        "total_actions": self._total_actions,
                        "action_detail": "execute_task",
                    },
                    decision=decision,
                )
            except Exception:
                pass

            return result

        except PolicyDeniedError:
            raise
        except Exception as e:
            latency_ms = int((time.perf_counter() - start) * 1000)
            try:
                err_decision = PolicyDecision(
                    effect="allow",
                    reason=f"error: {type(e).__name__}: {e}",
                )
                self._client._audit_decision(
                    tool=tool_name,
                    method="call",
                    args={
                        "status": "error",
                        "latency_ms": latency_ms,
                        "action_detail": "execute_task",
                    },
                    decision=err_decision,
                )
            except Exception:
                pass
            raise

    @property
    def agent(self) -> Agent:
        """Get underlying CrewAI agent."""
        return self._agent

    @property
    def role(self) -> str:
        """Get agent role."""
        return self._agent.role

    @property
    def goal(self) -> str:
        """Get agent goal."""
        return self._agent.goal

    @property
    def tools(self) -> List:
        """Get agent tools."""
        return self._agent.tools

    @property
    def total_actions(self) -> int:
        """Get total actions executed."""
        return self._total_actions


def governed_agent(
    client: Client,
    wrap_tools: bool = True,
    allowed_tools: Optional[List[str]] = None,
) -> Callable:
    """
    Decorator to create a governed CrewAI agent.

    Usage:
        @governed_agent(client, wrap_tools=True)
        def create_researcher():
            return Agent(
                role="Researcher",
                goal="Research topics",
                backstory="You are an expert researcher",
                tools=[search_tool],
            )

        researcher = create_researcher()  # Returns GovernedCrewAgent
    """
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs) -> GovernedCrewAgent:
            agent = func(*args, **kwargs)
            return GovernedCrewAgent(
                agent=agent,
                client=client,
                wrap_tools=wrap_tools,
                allowed_tools=allowed_tools,
            )
        return wrapper
    return decorator
