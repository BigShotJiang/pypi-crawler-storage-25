"""
Governed CrewAI Task wrapper.

Provides governance enforcement for CrewAI tasks including:
- Task-level policy checks
- Delegation governance
- Output validation
- Execution logging
"""

from __future__ import annotations

import time
from functools import wraps
from typing import Any, Callable, List, Optional

try:
    from crewai import Task, Agent
    CREWAI_AVAILABLE = True
except ImportError:
    CREWAI_AVAILABLE = False
    class Task:
        pass
    class Agent:
        pass

from controlzero.client import Client
from controlzero.errors import PolicyDeniedError, PolicyDecision


class GovernedTask:
    """
    Governance wrapper for CrewAI Task.

    Wraps a CrewAI Task to provide:
    - Task execution policy enforcement
    - Delegation governance
    - Output validation
    - Execution audit logging

    Usage:
        from crewai import Task

        research_task = Task(
            description="Research the topic...",
            agent=researcher,
            expected_output="A detailed report...",
        )

        governed_task = GovernedTask(
            task=research_task,
            client=client,
            task_name="research_task",
        )
    """

    def __init__(
        self,
        task: Task,
        client: Client,
        task_name: Optional[str] = None,
        allow_delegation: bool = True,
        max_delegation_depth: int = 3,
        log_outputs: bool = False,
    ):
        """
        Initialize governed task.

        Args:
            task: The CrewAI Task to wrap
            client: ControlZero client
            task_name: Name for logging purposes
            allow_delegation: Whether to allow task delegation
            max_delegation_depth: Maximum delegation depth
            log_outputs: Whether to log output content
        """
        if not CREWAI_AVAILABLE:
            raise ImportError(
                "crewai is required. Install with: pip install crewai"
            )

        self._task = task
        self._client = client
        self._task_name = task_name or self._extract_task_name(task)
        self._allow_delegation = allow_delegation
        self._max_delegation_depth = max_delegation_depth
        self._log_outputs = log_outputs

        # Tracking
        self._delegation_depth = 0
        self._execution_count = 0

    def _extract_task_name(self, task: Task) -> str:
        """Extract a name from task description."""
        if hasattr(task, 'description'):
            desc = str(task.description)[:30]
            return desc.replace(" ", "_").lower()
        return "unnamed_task"

    def execute(
        self,
        agent: Optional[Agent] = None,
        context: Optional[str] = None,
        tools: Optional[List] = None,
    ) -> Any:
        """
        Execute the task with governance.

        Args:
            agent: Agent to execute (overrides task.agent)
            context: Additional context
            tools: Override tools for execution

        Returns:
            Task output
        """
        tool_name = self._task_name
        decision = self._client.guard(
            tool_name,
            method="call",
            context={
                "tags": {
                    "framework": "crewai",
                    "agent_id": self._task_name,
                    "action_detail": "execute",
                },
            },
        )

        if decision.denied:
            raise PolicyDeniedError(decision)

        start = time.perf_counter()
        self._execution_count += 1

        try:
            # Check delegation policy
            if self._delegation_depth >= self._max_delegation_depth:
                raise PolicyDeniedError(PolicyDecision(
                    effect="deny",
                    reason=f"Maximum delegation depth ({self._max_delegation_depth}) exceeded"
                ))

            executing_agent = agent or self._task.agent
            result = self._task.execute(
                agent=executing_agent,
                context=context,
                tools=tools,
            )

            latency_ms = int((time.perf_counter() - start) * 1000)

            metadata = {
                "execution_count": self._execution_count,
                "delegation_depth": self._delegation_depth,
                "status": "success",
                "latency_ms": latency_ms,
            }

            if self._log_outputs and result:
                metadata["output_preview"] = str(result)[:200]

            try:
                self._client._audit_decision(
                    tool=tool_name,
                    method="execute",
                    args=metadata,
                    decision=decision,
                )
            except Exception:
                pass

            return result

        except PolicyDeniedError:
            raise
        except Exception as e:
            latency_ms = int((time.perf_counter() - start) * 1000)
            try:
                err_decision = PolicyDecision(
                    effect="allow",
                    reason=f"error: {type(e).__name__}: {e}",
                )
                self._client._audit_decision(
                    tool=tool_name,
                    method="execute",
                    args={"status": "error", "latency_ms": latency_ms},
                    decision=err_decision,
                )
            except Exception:
                pass
            raise

    def delegate(
        self,
        to_agent: Agent,
        context: Optional[str] = None,
    ) -> Any:
        """
        Delegate task to another agent with governance.

        Args:
            to_agent: Agent to delegate to
            context: Context for delegation

        Returns:
            Delegation result
        """
        if not self._allow_delegation:
            decision = PolicyDecision(
                effect="deny",
                reason="Task delegation is not allowed"
            )
            raise PolicyDeniedError(decision)

        tool_name = self._task_name
        decision = self._client.guard(
            tool_name,
            method="call",
            context={
                "tags": {
                    "framework": "crewai",
                    "agent_id": self._task_name,
                    "action_detail": "delegate",
                },
            },
        )

        if decision.denied:
            raise PolicyDeniedError(decision)

        # Increment delegation depth
        self._delegation_depth += 1

        try:
            return self.execute(agent=to_agent, context=context)
        finally:
            self._delegation_depth -= 1

    @property
    def task(self) -> Task:
        """Get underlying CrewAI task."""
        return self._task

    @property
    def description(self) -> str:
        """Get task description."""
        return getattr(self._task, 'description', '')

    @property
    def agent(self) -> Optional[Agent]:
        """Get assigned agent."""
        return getattr(self._task, 'agent', None)

    @property
    def execution_count(self) -> int:
        """Get total execution count."""
        return self._execution_count


def governed_task(
    client: Client,
    task_name: Optional[str] = None,
    allow_delegation: bool = True,
    max_delegation_depth: int = 3,
    log_outputs: bool = False,
) -> Callable:
    """
    Decorator to create a governed CrewAI task.

    Usage:
        @governed_task(client, task_name="research")
        def create_research_task(agent):
            return Task(
                description="Research the topic...",
                agent=agent,
                expected_output="A detailed report",
            )

        task = create_research_task(researcher)  # Returns GovernedTask
    """
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs) -> GovernedTask:
            task = func(*args, **kwargs)
            return GovernedTask(
                task=task,
                client=client,
                task_name=task_name,
                allow_delegation=allow_delegation,
                max_delegation_depth=max_delegation_depth,
                log_outputs=log_outputs,
            )
        return wrapper
    return decorator
