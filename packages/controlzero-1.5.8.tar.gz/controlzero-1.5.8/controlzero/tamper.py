"""
v0.2 SDK tamper protection: HMAC-signed policies + hash-chained audit.

Two primitives live here:

1. HMAC signing for policy bundles. When the SDK runs in hybrid mode
   (local cache of a remote policy), the local copy is HMAC-SHA256 signed
   with a secret the SDK received at enrollment. Before every policy
   evaluation the SDK recomputes the HMAC and compares. Tampering with
   the on-disk file breaks the signature and the SDK fails closed.

2. Hash-chained audit entries. Each new audit entry embeds the SHA-256
   of the previous entry (base64). Removing or reordering entries breaks
   the chain and is detectable with a single linear scan. The chain
   seed ("genesis" entry) is written to a separate anchor file so a
   malicious local actor cannot silently create a new chain from scratch.

Both primitives are stdlib-only (hmac, hashlib) so they do not expand
the SDK dependency footprint. loguru is still optional.

Security caveats:
- An attacker with access to the HMAC secret itself can forge bundles.
  The SDK assumes the secret is protected by the OS keystore or file
  permissions on ~/.controlzero/tamper.key (mode 0600). Future releases
  move this to OS keystore.
- The audit chain protects integrity, not confidentiality. Anyone who
  can read the log can read its contents; this module does not encrypt.
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import threading
import json
import os
import secrets
import sys
from pathlib import Path
from typing import Optional


# ---------------------------------------------------------------------------
# HMAC-signed policy bundles
# ---------------------------------------------------------------------------


class TamperDetectedError(Exception):
    """Raised when a signed payload fails verification."""


def sign_bundle(payload: bytes, secret: bytes) -> str:
    """Return a base64(HMAC-SHA256(secret, payload)) tag.

    The tag is intended to be stored alongside the payload on disk or
    transmitted in a sidecar field. 32-byte HMAC output encodes to 44
    characters in base64.
    """
    if not isinstance(payload, (bytes, bytearray)):
        raise TypeError("payload must be bytes")
    if not isinstance(secret, (bytes, bytearray)):
        raise TypeError("secret must be bytes")
    if len(secret) < 32:
        raise ValueError("secret must be at least 32 bytes for HMAC-SHA256")
    mac = hmac.new(secret, payload, hashlib.sha256).digest()
    return base64.b64encode(mac).decode("ascii")


def verify_bundle(payload: bytes, signature: str, secret: bytes) -> bool:
    """Return True if signature is a valid HMAC-SHA256 tag for payload.

    Uses hmac.compare_digest to avoid timing leaks. Never raises; returns
    False on any format / length mismatch.
    """
    if not isinstance(payload, (bytes, bytearray)):
        return False
    if not isinstance(signature, str):
        return False
    if not isinstance(secret, (bytes, bytearray)):
        return False
    try:
        expected = hmac.new(secret, payload, hashlib.sha256).digest()
        got = base64.b64decode(signature, validate=True)
    except (ValueError, TypeError):
        return False
    if len(got) != len(expected):
        return False
    return hmac.compare_digest(expected, got)


def require_bundle(payload: bytes, signature: str, secret: bytes) -> None:
    """Raise TamperDetectedError if verification fails."""
    if not verify_bundle(payload, signature, secret):
        raise TamperDetectedError("policy bundle HMAC verification failed")


def load_signed_file(path: Path, secret: bytes) -> bytes:
    """Read a signed-bundle file and return the payload bytes.

    File format is a JSON envelope: {"payload": <base64>, "sig": <base64>}.
    Raises TamperDetectedError on HMAC mismatch, FileNotFoundError if the
    file is missing, ValueError on malformed envelope.
    """
    data = path.read_bytes()
    try:
        envelope = json.loads(data.decode("utf-8"))
    except (json.JSONDecodeError, UnicodeDecodeError) as exc:
        raise ValueError(f"malformed signed-bundle envelope: {exc}") from exc
    try:
        payload = base64.b64decode(envelope["payload"], validate=True)
        signature = envelope["sig"]
    except (KeyError, ValueError, TypeError) as exc:
        raise ValueError(f"missing payload/sig fields: {exc}") from exc
    require_bundle(payload, signature, secret)
    return payload


def write_signed_file(path: Path, payload: bytes, secret: bytes) -> None:
    """Write a signed-bundle file that load_signed_file can consume.

    Creates parent directories as needed. File is written mode 0600.
    """
    signature = sign_bundle(payload, secret)
    envelope = {
        "payload": base64.b64encode(payload).decode("ascii"),
        "sig": signature,
    }
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(envelope), encoding="utf-8")
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass


# ---------------------------------------------------------------------------
# Hash-chained audit log
# ---------------------------------------------------------------------------


class HashChain:
    """Append-only hash chain for audit entries.

    Each entry is a JSON object with at least the keys caller passes in,
    plus two fields this class adds:
      - "prev_hash": SHA-256 of the previous entry's canonical serialization
      - "entry_hash": SHA-256 of the current entry including prev_hash

    The chain starts from a genesis seed stored in a sidecar anchor file
    at <log_path>.anchor. If the anchor file is missing on append(), a
    fresh random 32-byte seed is generated and stored.

    Verification walks the chain start-to-end, recomputing each entry
    hash from its canonical form and checking that each entry's
    prev_hash equals the previous entry's entry_hash. Any mismatch
    (deletion, reorder, mutation) is reported with the index of the
    first bad entry.
    """

    def __init__(self, log_path: Path):
        self.log_path = Path(log_path)
        # genesis seed: immutable, written once, used by verify() to
        # confirm the first entry's prev_hash matches the real chain
        # start (prevents truncation attacks).
        self.anchor_path = self.log_path.with_suffix(self.log_path.suffix + ".anchor")
        # head pointer: moves forward on every append so a new
        # HashChain instance for the same log path resumes where the
        # previous one left off.
        self.head_path = self.log_path.with_suffix(self.log_path.suffix + ".head")
        self._genesis: Optional[str] = None
        self._last_hash: Optional[str] = None
        # Serialize append() across threads. Two concurrent writers
        # without this would race on self._last_hash + the head file
        # write and produce orphaned entries. Flagged by code review
        # 2026-04-08.
        self._lock = threading.Lock()
        self._init_anchor()

    def _init_anchor(self) -> None:
        """Initialize genesis + head pointer from the two sidecar files.

        On first run: generate a random 32-byte genesis seed, write it
        to the anchor file (immutable), and copy it to the head file.

        On subsequent runs: read genesis from anchor and current head
        from head file. This lets a new HashChain instance for the
        same log path resume where the previous one left off.
        """
        if self.anchor_path.exists():
            try:
                self._genesis = self.anchor_path.read_text(encoding="utf-8").strip() or None
            except OSError:
                self._genesis = None
        if self.head_path.exists():
            try:
                self._last_hash = self.head_path.read_text(encoding="utf-8").strip() or None
            except OSError:
                self._last_hash = None

        if self._genesis is None:
            seed_hex = secrets.token_bytes(32).hex()
            self._genesis = seed_hex
            self._last_hash = seed_hex
            self._write_file(self.anchor_path, seed_hex)
            self._write_file(self.head_path, seed_hex)
        elif self._last_hash is None:
            # Anchor present but head missing; seed head from anchor.
            self._last_hash = self._genesis
            self._write_file(self.head_path, self._genesis)

    @staticmethod
    def _write_file(path: Path, value: str) -> None:
        """Atomic file write: tmp + rename.

        A crash mid-write on the head pointer would otherwise leave a
        partial hex string on disk, which _read_anchor_seed would
        return as-is, silently breaking verify() on next start. The
        tmp+rename pattern means the head file is either the old
        complete value or the new complete value, never a torn write.
        Flagged by code review 2026-04-08.
        """
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            tmp = path.with_suffix(path.suffix + ".tmp")
            tmp.write_text(value, encoding="utf-8")
            try:
                os.chmod(tmp, 0o600)
            except OSError:
                pass
            os.replace(tmp, path)
        except OSError:
            print(
                f"controlzero: could not write chain file {path}",
                file=sys.stderr,
            )

    @staticmethod
    def _canonical(entry: dict) -> bytes:
        """Canonical JSON serialization used for hashing.

        sort_keys + no whitespace so the same dict always hashes to the
        same bytes regardless of insertion order or Python dict
        iteration order.
        """
        return json.dumps(entry, sort_keys=True, separators=(",", ":")).encode("utf-8")

    def append(self, entry: dict) -> dict:
        """Build a chained entry from `entry` and return the augmented dict.

        Does NOT write the entry to disk; the caller's audit sink does
        the writing. This separation lets the chain work alongside
        loguru, analytical store forwarding, or any other sink.
        """
        # Serialize across threads -- without the lock, two concurrent
        # append() calls can read the same self._last_hash, produce
        # two entries with the same prev_hash (invalid chain), and
        # interleave their head-file writes.
        with self._lock:
            chained = dict(entry)
            chained["prev_hash"] = self._last_hash or ""
            digest = hashlib.sha256(self._canonical(chained)).hexdigest()
            chained["entry_hash"] = digest
            self._last_hash = digest
            # Advance the on-disk head pointer so a fresh HashChain
            # instance for the same log path resumes from the current
            # position. Atomic write via _write_file.
            self._write_file(self.head_path, digest)
            return chained

    def verify(self, entries: list[dict]) -> tuple[bool, Optional[int]]:
        """Walk entries in order and verify the chain is intact.

        Returns (True, None) on success, (False, index) on first bad
        entry. Compares against the on-disk anchor if it exists; caller
        can pass the anchor seed manually by injecting a fake first
        entry with prev_hash == seed and entry_hash == sha256(seed).
        """
        prev = self._read_anchor_seed()
        for i, entry in enumerate(entries):
            expected_prev = prev
            if entry.get("prev_hash") != expected_prev:
                return False, i
            recomputed = hashlib.sha256(
                self._canonical({k: v for k, v in entry.items() if k != "entry_hash"})
            ).hexdigest()
            if entry.get("entry_hash") != recomputed:
                return False, i
            prev = recomputed
        return True, None

    def _read_anchor_seed(self) -> str:
        if self._genesis is not None:
            return self._genesis
        if self.anchor_path.exists():
            try:
                return self.anchor_path.read_text(encoding="utf-8").strip()
            except OSError:
                return ""
        return ""


# ---------------------------------------------------------------------------
# Secret management
# ---------------------------------------------------------------------------


def load_or_create_secret(path: Path) -> bytes:
    """Load the 32-byte HMAC secret from disk, generating one if missing.

    Path permissions are tightened to 0600. Returns raw bytes.
    """
    if path.exists():
        data = path.read_bytes()
        if len(data) >= 32:
            return data
        # Malformed, regenerate.
    secret = secrets.token_bytes(32)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(secret)
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass
    return secret


# Imports below sit mid-module by design: the quarantine block is a
# self-contained subsystem that came in later than the original file
# (#383 quarantine support) and was kept locally scoped to make the
# diff reviewable. ruff E402 noqa preserves that layout.
import datetime  # noqa: E402
from dataclasses import dataclass  # noqa: E402

QUARANTINE_FILE_NAME = "quarantine.json"


@dataclass
class TamperState:
    """Persisted quarantine state for mandatory tamper enforcement.

    When tamper_behavior is 'deny-all' or 'quarantine' and tampering is
    detected, the machine enters quarantine. All tool calls are denied
    until recovery (re-enrollment or fresh policy pull).
    """
    quarantined: bool = False
    reason: str = ""
    detected_at: str = ""
    source: str = ""  # "policy_hmac" | "audit_chain" | "bundle_signature"

    @classmethod
    def load(cls, state_dir: Path) -> "TamperState":
        path = state_dir / QUARANTINE_FILE_NAME
        if not path.exists():
            return cls()
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            return cls(
                quarantined=data.get("quarantined", False),
                reason=data.get("reason", ""),
                detected_at=data.get("detected_at", ""),
                source=data.get("source", ""),
            )
        except (json.JSONDecodeError, OSError, KeyError):
            return cls()

    def save(self, state_dir: Path) -> None:
        state_dir.mkdir(parents=True, exist_ok=True)
        path = state_dir / QUARANTINE_FILE_NAME
        tmp = path.with_suffix(".json.tmp")
        tmp.write_text(json.dumps({
            "quarantined": self.quarantined,
            "reason": self.reason,
            "detected_at": self.detected_at,
            "source": self.source,
        }), encoding="utf-8")
        try:
            os.chmod(tmp, 0o600)
        except OSError:
            pass
        os.replace(tmp, path)

    @classmethod
    def clear(cls, state_dir: Path) -> None:
        path = state_dir / QUARANTINE_FILE_NAME
        try:
            path.unlink(missing_ok=True)
        except OSError:
            pass

    @classmethod
    def is_quarantined(cls, state_dir: Path) -> bool:
        path = state_dir / QUARANTINE_FILE_NAME
        if not path.exists():
            return False
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            return data.get("quarantined", False)
        except (json.JSONDecodeError, OSError):
            return False

    @classmethod
    def enter_quarantine(cls, state_dir: Path, reason: str, source: str) -> None:
        state = cls(
            quarantined=True,
            reason=reason,
            detected_at=datetime.datetime.utcnow().isoformat() + "Z",
            source=source,
        )
        state.save(state_dir)


def report_tamper_alert(
    state_dir: Path,
    source: str,
    details: Optional[dict] = None,
    timeout_s: float = 5.0,
) -> None:
    """POST tamper alert to backend. Best-effort, never raises.

    Uses enrollment state for authentication. Silently no-ops if not
    enrolled or on any network error.
    """
    try:
        from controlzero.enrollment import load_state, sign_request
    except ImportError:
        return

    state = load_state(state_dir)
    if state is None:
        return

    import httpx

    payload = {
        "source": source,
        "hostname": state.hostname,
        "machine_id": state.machine_id,
        "details": details or {},
    }
    body = json.dumps(payload).encode("utf-8")
    try:
        headers = sign_request(state, "POST", "/v1/sdk/tamper-alert", body, state_dir=state_dir)
        headers["Content-Type"] = "application/json"
        httpx.post(
            f"{state.api_url}/v1/sdk/tamper-alert",
            content=body,
            headers=headers,
            timeout=timeout_s,
        )
    except Exception:
        pass  # Best-effort


__all__ = [
    "TamperDetectedError",
    "sign_bundle",
    "verify_bundle",
    "require_bundle",
    "load_signed_file",
    "write_signed_file",
    "HashChain",
    "load_or_create_secret",
    "TamperState",
    "report_tamper_alert",
]
