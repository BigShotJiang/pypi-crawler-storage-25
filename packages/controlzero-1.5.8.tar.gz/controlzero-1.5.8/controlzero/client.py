"""ControlZero Client. The user-facing entry point.

Three states, one client:

  state                                   policy source        audit destination
  ----------------------------------------------------------------------------
  no API key + local policy               local (dict/file)    local rotated log
  API key + no local policy               dashboard (hosted)   remote audit trail
  API key + local policy                  HOSTED wins          remote audit trail
                                           + stderr notice
  API key + local + LOCAL_OVERRIDE=1      local OVERRIDES      remote audit trail
                                           + WARN log
  no API key + no local policy            none                 stderr (one warning)
                                           + pass-through

Resolution order for finding a policy (T103, 2026-05-12):
  1. explicit `policy=` or `policy_file=` arg WINS unconditionally (caller is explicit)
  2. CONTROLZERO_API_KEY set => hosted bundle (DEFAULT)
  3. CONTROLZERO_LOCAL_OVERRIDE=1 set with api_key => local fallback path
  4. no api_key => CONTROLZERO_POLICY_FILE env var
  5. no api_key => ./controlzero.yaml in cwd
  6. nothing => no-op pass-through with one-time stderr warning

Before T103, local always won when both were present. an enterprise customer
hit this in prod: a stale ~/.controlzero/policy.yaml shadowed the dashboard
policy and silently disabled enforcement. The reversal makes the api_key
the explicit "I want hosted" signal and forces an env-var opt-out for the
old behavior.
"""

from __future__ import annotations

import logging
import os
import sys
import threading
import time
import warnings
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional, Union

from controlzero._internal.dlp_scanner import (
    DLPScanner,
    load_dlp_rules_from_policy,
)
from controlzero._internal.enforcer import (
    PolicyDecision,
    PolicyDeniedError,
    PolicyEvaluator,
)
from controlzero.audit_local import LocalAuditLogger
from controlzero.audit_remote import RemoteAuditSink
from controlzero.errors import (
    HybridModeError,
    PolicyLoadError,
    PolicyValidationError,
)
from controlzero.policy_loader import load_policy, PolicySettings

# One-time warning state per process
_NO_POLICY_WARNED = False
_HYBRID_WARNED = False

# Default TTL for hosted-policy background refresh. A hosted client
# re-checks the dashboard for a fresh bundle every N seconds between
# guard() calls. Picked to strike a balance: short enough that a user
# who just updated policy on the dashboard sees their change within a
# minute, long enough that steady-state traffic is not dominated by
# conditional GETs.
_DEFAULT_REFRESH_INTERVAL_SECONDS = 60

_refresh_logger = logging.getLogger("controlzero.client.refresh")


def _mask_api_key(api_key: Optional[str]) -> str:
    # Reveal only the public, non-secret prefix (cz_live_ / cz_test_) and mask
    # the rest. Anything past the prefix is entropy from the customer's secret
    # and must never appear on stderr, in logs, or in support transcripts.
    if not api_key:
        return "***"
    if api_key.startswith("cz_live_"):
        return "cz_live_***"
    if api_key.startswith("cz_test_"):
        return "cz_test_***"
    return "***"


class Client:
    """The ControlZero policy client.

    Hello World (no API key, no signup):

        from controlzero import Client

        cz = Client(policy={
            "rules": [{"deny": "delete_*", "reason": "Hello World"}]
        })

        result = cz.guard("delete_file", {"path": "/tmp/foo"})
        print(result.decision)  # "deny"

    Hosted mode (with API key, audit ships to dashboard):

        cz = Client(api_key="cz_live_...")  # or set CONTROLZERO_API_KEY env var

    Hybrid (API key + local policy override): emits a WARN log on init.
    Use `strict_hosted=True` to raise instead of warn.
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        policy: Optional[dict] = None,
        policy_file: Optional[Union[str, Path]] = None,
        strict_hosted: bool = False,
        log_path: str = "./controlzero.log",
        log_rotation: str = "daily",
        log_retention: str = "30 days",
        log_compression: Optional[str] = None,
        log_format: str = "json",
        agent_name: Optional[str] = None,
        refresh_interval_seconds: Optional[int] = _DEFAULT_REFRESH_INTERVAL_SECONDS,
    ):
        if policy is not None and policy_file is not None:
            raise ValueError(
                "Pass either `policy` or `policy_file`, not both."
            )

        # T101 layout-migration shim: fold any legacy
        # ~/.controlzero/events.log into audit.log on every Client
        # construction. Idempotent and best-effort: no-op when the
        # legacy file is absent. Mirrors the CLI shim.
        try:
            from controlzero import __version__ as _cz_version
            from controlzero.layout_migration import run_layout_migration
            _cz_home = Path(
                os.environ.get("CONTROLZERO_HOME") or (Path.home() / ".controlzero")
            )
            run_layout_migration(_cz_home, sdk_version=_cz_version)
        except Exception:  # noqa: BLE001
            # Migration must never break the user's agent.
            pass

        # Resolve API key from arg or env
        self._api_key = api_key or os.environ.get("CONTROLZERO_API_KEY")

        # Resolve agent identity. Used to tag audit events so multi-agent
        # systems can attribute calls. Order: explicit arg > CZ_AGENT_NAME
        # env > "default-agent".
        self._agent_name = (
            agent_name or os.environ.get("CZ_AGENT_NAME") or "default-agent"
        )

        # CZ_DEBUG=1 (or true/yes/on) flips the controlzero logger to DEBUG
        # at construction time. Cheap escape hatch when a user reports
        # weird behavior and we want them to send us a verbose log.
        if os.environ.get("CZ_DEBUG", "").lower() in ("1", "true", "yes", "on"):
            import logging as _logging
            _logging.getLogger("controlzero").setLevel(_logging.DEBUG)

        # T103 precedence (2026-05-12):
        #   1. Caller-explicit policy / policy_file wins unconditionally.
        #   2. api_key set => hosted bundle (the new default).
        #   3. CONTROLZERO_LOCAL_OVERRIDE=1 with api_key => use local file
        #      instead of hosted (debug / offline fallback only).
        #   4. No api_key => look for a local file in the usual places.
        self._has_api_key = bool(self._api_key)
        local_override = os.environ.get("CONTROLZERO_LOCAL_OVERRIDE", "").lower() in (
            "1", "true", "yes", "on"
        )
        caller_supplied_local = policy is not None or policy_file is not None

        self._hosted_parsed = None
        self._hosted_etag: Optional[str] = None
        local_source: Optional[Union[dict, Path]] = None

        if caller_supplied_local:
            # The caller explicitly handed us a policy; respect it. If they
            # ALSO set an api_key we still treat the explicit arg as the
            # source of truth (loud warning emitted below in _warn_explicit).
            local_source = policy if policy is not None else Path(policy_file)
            self._has_local_policy = True
            if self._has_api_key:
                self._warn_explicit_local_with_api_key(strict_hosted, local_source)
        elif self._has_api_key and not local_override:
            from controlzero.hosted_policy import (
                load_cached_bundle,
                load_hosted_policy,
            )
            # Fail-closed guarantees:
            #   - HostedAuthError: invalid API key -> raise immediately.
            #   - HostedBootstrapError: backend unreachable with no cache ->
            #     raise (never silently pass-through).
            #   - Network error with cache -> warn, use cached bundle.
            #   - Bundle signature or format failure -> raise.
            local_source, self._hosted_parsed = load_hosted_policy(self._api_key)
            self._has_local_policy = True
            try:
                cb = load_cached_bundle(self._api_key)
                if cb is not None:
                    self._hosted_etag = cb.etag
            except Exception:  # noqa: BLE001
                self._hosted_etag = None
            self._notify_active_source("hosted", source_hint=_mask_api_key(self._api_key))
        else:
            # Either no api_key, or api_key + LOCAL_OVERRIDE escape hatch.
            local_source = self._resolve_local_source(None, None)
            self._has_local_policy = local_source is not None
            if self._has_local_policy:
                self._notify_active_source(
                    "local-override" if local_override else "local",
                    source_hint=str(local_source),
                )

        # T108 (2026-05-12): record the override fact so we can emit a
        # governance audit event AFTER the remote sink is set up below.
        # LOCAL_OVERRIDE with an api_key is the bypass case ops needs to
        # see in the audit dashboard.
        self._local_override_active = bool(
            local_override and self._has_api_key and not caller_supplied_local
        )
        self._local_override_source_hint = str(local_source) if self._local_override_active else ""

        # Load local policy if present
        self._evaluator: Optional[PolicyEvaluator] = None
        self._policy_settings = PolicySettings()
        if self._has_local_policy:
            try:
                parsed = load_policy(local_source)
                rules = parsed.rules
                self._policy_settings = parsed.settings
            except (PolicyLoadError, PolicyValidationError):
                # Re-raise: caller needs to fix their config
                raise

            # Initialize DLP scanner with built-in patterns + any custom
            # dlp_rules from the policy file.
            dlp_scanner = DLPScanner()
            raw_policy_data = self._get_raw_policy_data(local_source)
            if raw_policy_data:
                custom_dlp = load_dlp_rules_from_policy(raw_policy_data)
                if custom_dlp:
                    dlp_scanner.add_rules(custom_dlp)

            self._evaluator = PolicyEvaluator(
                rules,
                dlp_scanner=dlp_scanner,
                # Thread the bundle-level default_action through to
                # the evaluator. In local mode users set this via
                # ``settings.default_action:`` in their YAML; in
                # hosted mode the bundle translator stamps the
                # resolved triple from the backend. Either way the
                # evaluator no longer hard-codes deny on the
                # no-match path.
                default_action=self._policy_settings.default_action,
            )

        # Effective tamper behavior: enrollment state > policy settings > default
        self._tamper_behavior = self._policy_settings.tamper_behavior
        try:
            from controlzero.enrollment import load_state as _load_enroll_state
            _es = _load_enroll_state()
            if _es and getattr(_es, 'tamper_behavior', '') and _es.tamper_behavior != 'warn':
                self._tamper_behavior = _es.tamper_behavior
        except ImportError:
            pass

        self._tamper_state_dir = Path.home() / ".controlzero"

        # Set up local audit logger ONLY in pure-local mode.
        # When hosted, audit goes through the remote forwarder (not implemented in
        # this skinny client; see hosted SDK in the legacy package for now).
        self._audit: Optional[LocalAuditLogger] = None
        if not self._has_api_key:
            # log_* options are honored
            self._audit = LocalAuditLogger(
                log_path=log_path,
                rotation=log_rotation,
                retention=log_retention,
                compression=log_compression,
                log_format=log_format,
            )
        else:
            # Hosted: log_* options are ignored. Warn if user tried to set them.
            user_set_log_opts = (
                log_path != "./controlzero.log"
                or log_rotation != "daily"
                or log_retention != "30 days"
                or log_compression is not None
                or log_format != "json"
            )
            if user_set_log_opts:
                warnings.warn(
                    "controlzero: log_* options are ignored when an API key is set "
                    "(audit is managed server-side).",
                    UserWarning,
                    stacklevel=2,
                )

        # --- Hosted policy periodic refresh state --------------------------
        #
        # Bug #1 (2026-04-19 investigation): prior to this, ``_evaluator``
        # was loaded exactly once in ``__init__`` and held for the life of
        # the process. Users who updated policy on the dashboard after
        # constructing the client kept enforcing the stale bundle until
        # their process restarted.
        #
        # We now track the time of the last successful refresh and, on
        # each ``guard()`` call, check whether the TTL has expired. If so,
        # we issue a best-effort conditional ``GET /v1/sdk/policies/pull``
        # (via :func:`hosted_policy.load_hosted_policy`), swap the new
        # evaluator under a lock, and continue. Network errors keep the
        # old bundle alive -- refresh is never on the hot path of a user
        # request.
        self._refresh_lock = threading.Lock()
        self._refresh_interval: Optional[float] = (
            float(refresh_interval_seconds)
            if refresh_interval_seconds is not None
            else None
        )
        self._last_refresh_at: float = time.monotonic()
        # Wall-clock timestamp so ops/tests can eyeball it.
        self._last_refreshed_wall: datetime = datetime.now(timezone.utc)
        # Refresh only makes sense for hosted mode.
        self._refresh_enabled = (
            self._has_api_key
            and self._hosted_parsed is not None
            and self._refresh_interval is not None
        )

        # Set up remote audit sink. Precedence: enrolled-machine signed
        # request > Bearer-API-key. Only one is active at a time.
        self._remote_sink: Optional[RemoteAuditSink] = None
        self._bearer_sink = None  # type: ignore[assignment]
        self._init_remote_sink()
        if self._remote_sink is None and self._has_api_key:
            try:
                from controlzero.audit_remote import BearerAuditSink
                from controlzero.hosted_policy import get_api_url
                self._bearer_sink = BearerAuditSink(
                    api_url=get_api_url(),
                    api_key=self._api_key,
                )
            except Exception as exc:  # noqa: BLE001
                # Never let audit sink init crash the client.
                import logging as _logging
                _logging.getLogger("controlzero.client").warning(
                    "controlzero: bearer audit sink unavailable (%s); "
                    "audit will be logged locally only",
                    exc,
                )

        # T108 (2026-05-12): emit a governance audit event when the
        # CONTROLZERO_LOCAL_OVERRIDE escape hatch was used to bypass the
        # hosted bundle. Posted to the remote audit sink so ops sees it
        # in the audit dashboard and can alert on
        # reason_code=LOCAL_OVERRIDE_ACTIVE. Best-effort: failure here
        # must never crash the Client.
        if getattr(self, "_local_override_active", False):
            try:
                self._emit_local_override_audit_event()
            except Exception as exc:  # noqa: BLE001
                import logging as _logging
                _logging.getLogger("controlzero.client").warning(
                    "controlzero: could not emit LOCAL_OVERRIDE audit event (%s)",
                    exc,
                )

    # ---------------- public API ----------------

    @property
    def agent_name(self) -> str:
        """The agent identity attached to audit events for this client."""
        return self._agent_name

    @property
    def last_refreshed_at(self) -> datetime:
        """Wall-clock time of the last successful hosted-policy refresh.

        In local mode (no API key), this is the construction time of the
        client. In hosted mode, it is updated on every successful refresh
        (200 OR 304) -- i.e. every time we successfully confirmed with the
        backend that the bundle is up-to-date.
        """
        return self._last_refreshed_wall

    def refresh(self) -> bool:
        """Unconditionally refresh the hosted policy bundle.

        Returns:
            ``True`` if the bundle actually changed (new etag / new rules);
            ``False`` otherwise. In local mode, always returns ``False``.

        This is the public hook for callers who want to force a policy
        reload after a dashboard change without waiting for the TTL.
        Safe to call from any thread.
        """
        if not (self._has_api_key and self._hosted_parsed is not None):
            return False
        return bool(self._refresh_policy_nonblocking(force=True))

    def guard(
        self,
        tool: str,
        args: Optional[dict] = None,
        method: str = "*",
        raise_on_deny: bool = False,
        context: Optional[dict] = None,
    ) -> PolicyDecision:
        """Evaluate a tool call against the loaded policy.

        Args:
            tool: The tool name (e.g. "delete_file", "github").
            args: The arguments the tool would be called with. Logged for audit.
            method: Optional method name. Defaults to "*" (any method).
            raise_on_deny: If True, raises PolicyDeniedError on a deny decision.
            context: Optional context dict with `resource` and `tags` keys for
                     resource-level matching and identity tags.

        Returns:
            PolicyDecision. Always returns; never raises unless raise_on_deny.
        """
        # Periodic hosted-policy refresh. Runs only in hosted mode and only
        # when the TTL has elapsed since the last refresh. Any network
        # error is swallowed: the old bundle keeps working.
        self._maybe_refresh_policy()

        # Machine-level quarantine check: if quarantined, deny everything
        try:
            from controlzero.tamper import TamperState
            if TamperState.is_quarantined(self._tamper_state_dir):
                decision = PolicyDecision(
                    effect="deny",
                    # T79: synthetic policy_id so the audit dashboard
                    # can render a recognizable chip + tooltip pointing
                    # at the quarantine recovery anchor.
                    policy_id="synthetic:QUARANTINE",
                    reason="Machine quarantined: policy tampering detected. All calls denied until recovery.",
                    reason_code="MACHINE_QUARANTINED",
                )
                self._audit_decision(tool, method, args or {}, decision, context=context)
                if raise_on_deny:
                    raise PolicyDeniedError(decision)
                return decision
        except ImportError:
            pass

        # Per-call tamper behavior enforcement
        if context and context.get("tamper_detected") and self._tamper_behavior != "warn":
            if self._tamper_behavior == "deny":
                decision = PolicyDecision(
                    effect="deny",
                    # T79: synthetic policy_id so the audit dashboard
                    # can render a recognizable chip. BUNDLE_TAMPERED
                    # rolls into the QUARANTINE chip family because
                    # both deliver the same "policy file integrity
                    # failed" signal to operators.
                    policy_id="synthetic:QUARANTINE",
                    reason="Policy tampering detected. Call blocked by tamper enforcement policy.",
                    reason_code="BUNDLE_TAMPERED",
                )
                self._audit_decision(tool, method, args or {}, decision, context=context)
                if raise_on_deny:
                    raise PolicyDeniedError(decision)
                return decision
            elif self._tamper_behavior in ("deny-all", "quarantine"):
                from controlzero.tamper import TamperState, report_tamper_alert
                TamperState.enter_quarantine(
                    self._tamper_state_dir,
                    reason="Policy tampering detected",
                    source=context.get("tamper_source", "policy_hmac"),
                )
                if self._tamper_behavior == "quarantine":
                    report_tamper_alert(self._tamper_state_dir, source="policy_hmac")
                decision = PolicyDecision(
                    effect="deny",
                    # T79: synthetic policy_id so the audit dashboard
                    # can render a recognizable chip + tooltip pointing
                    # at the quarantine recovery anchor.
                    policy_id="synthetic:QUARANTINE",
                    reason="Machine quarantined: policy tampering detected.",
                    reason_code="MACHINE_QUARANTINED",
                )
                self._audit_decision(tool, method, args or {}, decision, context=context)
                if raise_on_deny:
                    raise PolicyDeniedError(decision)
                return decision

        if self._evaluator is None:
            return self._noop_decision(tool, method)

        try:
            decision = self._evaluator.evaluate(
                tool, method, context=context, args=args,
            )
        except Exception as e:
            # Fail closed on any evaluator crash. NEVER allow on error.
            # T79: tag with synthetic:ENGINE_UNAVAILABLE so the audit
            # dashboard can tell evaluator-crash denies apart from
            # rule-driven denies.
            decision = PolicyDecision(
                effect="deny",
                policy_id="synthetic:ENGINE_UNAVAILABLE",
                reason=f"Evaluator error: {type(e).__name__}: {e}. Failing closed.",
            )

        self._audit_decision(tool, method, args or {}, decision, context=context)

        if raise_on_deny and decision.denied:
            raise PolicyDeniedError(decision)

        return decision

    def close(self) -> None:
        """Flush and close audit sinks (local + remote + bearer)."""
        if self._remote_sink is not None:
            self._remote_sink.close()
            self._remote_sink = None
        if self._bearer_sink is not None:
            try:
                self._bearer_sink.close()
            except Exception:  # noqa: BLE001
                pass
            self._bearer_sink = None
        if self._audit is not None:
            self._audit.close()
            self._audit = None

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()

    # ---------------- internals ----------------

    def _maybe_refresh_policy(self) -> None:
        """If the TTL has elapsed, fire a best-effort refresh.

        A refresh_interval of 0 means "refresh on every guard" (tests
        only). A refresh_interval of None disables the periodic refresh
        entirely -- callers can still force a refresh via
        :meth:`refresh`.
        """
        if not self._refresh_enabled:
            return
        if self._refresh_interval is None:
            return
        elapsed = time.monotonic() - self._last_refresh_at
        if elapsed < self._refresh_interval:
            return
        self._refresh_policy_nonblocking(force=False)

    def _refresh_policy_nonblocking(self, force: bool) -> bool:
        """Attempt to refresh the hosted policy bundle.

        Only one thread does the actual network + parse work at a time
        (protected by ``self._refresh_lock``). Other threads bail out
        immediately -- the next ``guard()`` call will observe the updated
        bundle or retry.

        Returns:
            ``True`` if a new evaluator was swapped in, ``False`` otherwise.

        This method never raises on network failure. On error, the old
        bundle stays in place and we bump the refresh timer so that
        steady-state traffic is not dominated by retry storms against a
        dead backend.
        """
        acquired = self._refresh_lock.acquire(blocking=False)
        if not acquired:
            # Another thread is already refreshing. Do nothing -- the
            # outcome will be visible after it releases.
            return False
        try:
            # Re-check TTL under the lock (unless forced). Prevents a
            # thundering herd where N threads queue up on the lock and
            # each issue a redundant refresh.
            if not force and self._refresh_interval is not None:
                if (time.monotonic() - self._last_refresh_at
                        < self._refresh_interval):
                    return False

            try:
                from controlzero.hosted_policy import (
                    load_cached_bundle,
                    load_hosted_policy,
                )
                from controlzero._internal.dlp_scanner import (
                    DLPScanner,
                    load_dlp_rules_from_policy,
                )
                from controlzero.policy_loader import load_policy
                from controlzero.errors import HostedAuthError
            except Exception:  # noqa: BLE001
                return False

            # Track the old etag so we can detect "no change".
            old_etag = self._hosted_etag

            try:
                new_local_source, new_parsed = load_hosted_policy(
                    self._api_key
                )
            except HostedAuthError as exc:
                # Hard auth failure is permanent. Log loudly, keep the
                # old bundle (which may or may not still be valid), and
                # back off aggressively.
                _refresh_logger.warning(
                    "controlzero: policy refresh auth error (%s); "
                    "keeping previous bundle",
                    exc,
                )
                self._last_refresh_at = time.monotonic()
                return False
            except Exception as exc:  # noqa: BLE001
                # Transient network / parse error. Keep old bundle. Bump
                # timer so we do not retry immediately.
                _refresh_logger.warning(
                    "controlzero: policy refresh failed (%s); "
                    "keeping previous bundle",
                    exc,
                )
                self._last_refresh_at = time.monotonic()
                return False

            # Compare against the old etag via the on-disk cache.
            new_etag: Optional[str] = None
            try:
                cb = load_cached_bundle(self._api_key)
                if cb is not None:
                    new_etag = cb.etag
            except Exception:  # noqa: BLE001
                new_etag = None

            # Build the fresh evaluator before swapping. If construction
            # fails, the old one stays.
            try:
                parsed_policy = load_policy(new_local_source)
                dlp_scanner = DLPScanner()
                raw_policy_data = self._get_raw_policy_data(new_local_source)
                if raw_policy_data:
                    custom_dlp = load_dlp_rules_from_policy(raw_policy_data)
                    if custom_dlp:
                        dlp_scanner.add_rules(custom_dlp)
                new_evaluator = PolicyEvaluator(
                    parsed_policy.rules,
                    dlp_scanner=dlp_scanner,
                    # Carry the freshly-resolved default_action into
                    # the swapped evaluator. Otherwise a dashboard
                    # flip of the no-match default would not take
                    # effect until the process restarted.
                    default_action=parsed_policy.settings.default_action,
                )
            except Exception as exc:  # noqa: BLE001
                _refresh_logger.warning(
                    "controlzero: refreshed bundle failed to build evaluator "
                    "(%s); keeping previous bundle",
                    exc,
                )
                self._last_refresh_at = time.monotonic()
                return False

            # Atomic swap. Python's GIL makes a single attribute write
            # atomic; the extra lock protects the read-compare-write of
            # the refresh state itself.
            self._evaluator = new_evaluator
            self._policy_settings = parsed_policy.settings
            self._hosted_parsed = new_parsed
            self._hosted_etag = new_etag
            self._last_refresh_at = time.monotonic()
            self._last_refreshed_wall = datetime.now(timezone.utc)

            changed = (old_etag is None) or (
                new_etag is not None and new_etag != old_etag
            )
            return bool(changed)
        finally:
            self._refresh_lock.release()

    def _init_remote_sink(self) -> None:
        """Create a RemoteAuditSink if this machine is enrolled.

        Enrollment state lives in ~/.controlzero/enrollment.json. If the
        file exists and is valid, we create a sink that will buffer audit
        entries and POST them to the backend asynchronously. If enrollment
        is absent or the enrollment module is not installed (no 'hosted'
        extras), we silently skip -- local audit still works.
        """
        try:
            from controlzero.enrollment import load_state
        except ImportError:
            # 'hosted' extras not installed -- no remote audit
            return

        try:
            state = load_state()
        except Exception:
            return

        if state is None:
            return

        if not state.api_url or not state.machine_id or not state.org_id:
            return

        try:
            self._remote_sink = RemoteAuditSink(
                api_url=state.api_url,
                machine_token="",  # auth via signed request headers
                org_id=state.org_id,
                machine_id=state.machine_id,
            )
        except Exception:
            # Any failure creating the sink should not block the client
            pass

    @staticmethod
    def _get_raw_policy_data(
        source: Union[dict, Path],
    ) -> Optional[dict]:
        """Read the raw policy dict to extract non-rule sections (e.g. dlp_rules).

        If source is already a dict, return it directly. If it is a file path,
        parse it again to get the full dict (including sections that load_policy
        strips out).
        """
        if isinstance(source, dict):
            return source
        if isinstance(source, Path) and source.exists():
            import json as _json
            text = source.read_text(encoding="utf-8")
            suffix = source.suffix.lower()
            if suffix in (".yaml", ".yml"):
                try:
                    import yaml
                    return yaml.safe_load(text)
                except Exception:
                    return None
            elif suffix == ".json":
                try:
                    return _json.loads(text)
                except Exception:
                    return None
        return None

    def _resolve_local_source(
        self,
        policy: Optional[dict],
        policy_file: Optional[Union[str, Path]],
    ) -> Optional[Union[dict, Path]]:
        """Find a local policy source by priority order (no-api-key path).

        Also accepts ``policy.json`` per the SDK_LOCAL_LAYOUT spec (T97):
        YAML is the default, JSON is auto-detected by extension.
        """
        if policy is not None:
            return policy
        if policy_file is not None:
            return Path(policy_file)

        env_path = os.environ.get("CONTROLZERO_POLICY_FILE")
        if env_path:
            return Path(env_path)

        for candidate in (
            Path.cwd() / "controlzero.yaml",
            Path.cwd() / "controlzero.yml",
            Path.cwd() / "controlzero.json",
        ):
            if candidate.exists():
                return candidate

        return None

    def _warn_explicit_local_with_api_key(
        self, strict: bool, source: Union[dict, Path]
    ) -> None:
        """Caller passed BOTH policy/policy_file AND an api_key.

        The explicit arg is treated as the source of truth (caller is
        intentional), but we surface the conflict so it cannot be silent.
        ``strict_hosted=True`` upgrades the warning to an exception.
        """
        global _HYBRID_WARNED
        descriptor = (
            "explicit policy dict" if isinstance(source, dict)
            else f"explicit policy file {source}"
        )
        msg = (
            f"controlzero: {descriptor} overrides the hosted bundle "
            "for this Client. The dashboard policy is IGNORED for this "
            "instance. Audit still ships remotely. Unset CONTROLZERO_API_KEY "
            "or stop passing policy/policy_file to silence this warning."
        )
        if strict:
            raise HybridModeError(msg + " (strict_hosted=True)")
        if not _HYBRID_WARNED:
            print("WARNING: " + msg, file=sys.stderr)
            _HYBRID_WARNED = True

    def _emit_local_override_audit_event(self) -> None:
        """Emit a single governance audit event for LOCAL_OVERRIDE usage.

        Required by T108 (2026-05-12). A user setting
        CONTROLZERO_LOCAL_OVERRIDE=1 with a valid api_key is bypassing
        the hosted policy bundle in favour of their local file. Every
        such bypass must be visible in the audit dashboard so:

          - ops can alert on it (unexpected override = potential abuse)
          - compliance can prove the bypass was authorised
          - support can correlate weird customer behaviour with their
            local override choice

        Wire-shape uses the existing BearerAuditSink envelope with
        ``reason_code=LOCAL_OVERRIDE_ACTIVE`` so the backend's
        audit_logs.reason_code column captures it. The synthetic
        policy_id ``<lifecycle>`` and decision ``audit`` make it
        impossible to confuse with a guard decision when querying.

        Falls back to the local audit log when no remote sink exists
        (caller is in pure-local mode but somehow still emitted the
        event -- defensive). Best-effort: any exception is caught by
        the caller.
        """
        from controlzero._internal.enforcer import (
            REASON_CODE_LOCAL_OVERRIDE_ACTIVE,
        )

        entry = {
            "tool": "_lifecycle",
            "method": "local_override_active",
            "decision": "audit",
            "policy_id": "<lifecycle>",
            "reason": (
                f"CONTROLZERO_LOCAL_OVERRIDE=1 is bypassing the hosted "
                f"policy bundle. Local source: {self._local_override_source_hint}"
            ),
            "reason_code": REASON_CODE_LOCAL_OVERRIDE_ACTIVE,
            "mode": "lifecycle",
        }
        if self._bearer_sink is not None:
            self._bearer_sink.log(entry)
        elif self._remote_sink is not None:
            self._remote_sink.log(entry)
        elif self._audit is not None:
            # No remote sink available -- still record locally so a
            # debug-bundle export captures the override fact.
            self._audit.log(entry)

    def _notify_active_source(self, mode: str, source_hint: str) -> None:
        """Emit a single stderr line naming the active policy source.

        Required by SDK_LOCAL_LAYOUT (T103) so users and support can
        determine instantly which policy is enforcing. Quiet (DEBUG level
        only) when CONTROLZERO_QUIET=1 is set.
        """
        if os.environ.get("CONTROLZERO_QUIET", "").lower() in ("1", "true", "yes", "on"):
            _refresh_logger.debug("controlzero: active policy source = %s (%s)", mode, source_hint)
            return
        print(
            f"controlzero: active policy source = {mode} ({source_hint})",
            file=sys.stderr,
        )

    def _noop_decision(self, tool: str, method: str) -> PolicyDecision:
        """No policy configured: pass through with a one-time warning."""
        global _NO_POLICY_WARNED
        if not _NO_POLICY_WARNED:
            print(
                "WARNING: controlzero: no policy configured, calls are not being checked. "
                "Pass `policy=...`, `policy_file=...`, set CONTROLZERO_POLICY_FILE, "
                "create ./controlzero.yaml, or set CONTROLZERO_API_KEY.",
                file=sys.stderr,
            )
            _NO_POLICY_WARNED = True
        return PolicyDecision(
            effect="allow",
            reason="No policy configured (pass-through)",
            policy_id="<noop>",
        )

    def _audit_decision(
        self,
        tool: str,
        method: str,
        args: dict,
        decision: PolicyDecision,
        context: Optional[dict] = None,
    ) -> None:
        entry = {
            "decision": decision.effect,
            "tool": tool,
            "method": method,
            "policy_id": decision.policy_id,
            "reason": decision.reason,
            "args_keys": sorted(args.keys()),
            "mode": "local",
        }
        # Include DLP findings in audit entry
        if decision.dlp_findings:
            entry["dlp_findings"] = decision.dlp_findings

        # Include tamper detection flags from context if present
        if context is not None:
            if "tamper_detected" in context:
                entry["tamper_detected"] = context["tamper_detected"]
            if "audit_chain_broken" in context:
                entry["audit_chain_broken"] = context["audit_chain_broken"]
            # Phase 3 of #228: coding-agent hook-check populates these
            # from the shared tool-extractor spec so the backend audit
            # can show what (tool, method) the hook actually evaluated
            # against. Named `extracted_method` to match the backend
            # audit column (#228 phase 3, T4d).
            if "extracted_method" in context:
                entry["extracted_method"] = context["extracted_method"]
            if "extracted_action" in context:
                entry["extracted_action"] = context["extracted_action"]
            if "host_tool_name" in context:
                entry["host_tool_name"] = context["host_tool_name"]

        # Local file first (when local audit is enabled)
        if self._audit is not None:
            self._audit.log(entry)

        # Remote sink (enrolled machines: signed-request auth).
        if self._remote_sink is not None:
            try:
                self._remote_sink.log(entry)
            except Exception:
                pass

        # Bearer sink (hosted mode: API-key auth).
        if self._bearer_sink is not None:
            try:
                hosted_entry = dict(entry)
                hosted_entry["mode"] = "hosted"
                self._bearer_sink.log(hosted_entry)
            except Exception:
                pass
