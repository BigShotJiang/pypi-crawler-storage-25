"""SDK_LOCAL_LAYOUT migration shim (T101).

Pre-1.5.4 the Python SDK split CLI lifecycle events into a separate
``~/.controlzero/events.log`` file. T96 (1.5.4) collapsed everything
into the single ``audit.log`` JSONL file the SDK_LOCAL_LAYOUT spec
mandates. This shim handles existing customer disks: if ``events.log``
is still present, fold its lines into ``audit.log`` (preserving order),
write a lifecycle marker so support can see the migration happened,
then delete ``events.log``.

Idempotent: no-op when ``events.log`` is absent. Safe to call on every
CLI invocation and every Client construction. Never raises -- a disk
failure here must not break the user's agent.

The Node and Go SDKs ship the same shim under the same contract so a
customer who copies ``~/.controlzero/`` from a Python install to a
Node-only or Go-only install gets the same automatic cleanup.
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path


def run_layout_migration(state_dir: Path, sdk_version: str = "unknown") -> int:
    """Fold legacy ``events.log`` into ``audit.log`` and delete it.

    Returns the number of lines migrated. 0 means no migration was
    needed (either ``events.log`` didn't exist or it was empty).

    Never raises. Any IOError or decode error is swallowed so the
    SDK keeps working even if the migration fails.
    """
    try:
        events_path = state_dir / "events.log"
        audit_path = state_dir / "audit.log"

        if not events_path.exists():
            return 0

        try:
            raw = events_path.read_text(encoding="utf-8")
        except OSError:
            return 0

        lines = [ln for ln in raw.splitlines() if ln.strip()]

        # Ensure the directory exists before we write the marker.
        state_dir.mkdir(parents=True, exist_ok=True)

        # Append the migrated lines to audit.log preserving order, then
        # write a single lifecycle marker so support can grep
        # `"layout_migration"` and see when this customer's disk was
        # upgraded. Marker goes last so the migrated lines keep their
        # original chronological position relative to the rest of the
        # file.
        with audit_path.open("a", encoding="utf-8") as f:
            for line in lines:
                f.write(line + "\n")
            marker = {
                "ts": datetime.now(timezone.utc).isoformat(),
                "kind": "lifecycle",
                "event_type": "layout_migration",
                "sdk": "python",
                "sdk_version": sdk_version,
                "from": "events.log",
                "to": "audit.log",
                "lines_migrated": len(lines),
            }
            f.write(json.dumps(marker) + "\n")

        # Delete the legacy file. If the unlink fails (permissions,
        # busy file on Windows), leave it -- the next run will retry.
        try:
            events_path.unlink()
        except OSError:
            pass

        return len(lines)
    except Exception:
        # Last-resort guard. Migration is best-effort; never break the
        # agent because of it.
        return 0
