"""controlzero CLI: init, validate, test, tail.

This is the on-ramp for new users. `controlzero init` writes a sample policy
file with annotated examples; that file IS the tutorial.
"""

from __future__ import annotations

import json
import os
import sys
import threading
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

import click
import yaml

from controlzero import Client, __version__
from controlzero._internal.enforcer import (
    DEFAULT_BUNDLE_ON_MISSING,
    REASON_CODE_BUNDLE_MISSING,
    REASON_CODE_MACHINE_QUARANTINED,
    REASON_CODE_RULE_MATCH,
)
from controlzero._internal.hook_extractors import extract_method, sql_semantic_class
from controlzero.cli.debug_bundle import debug_group
from controlzero.cli.doctor import doctor_cmd
from controlzero.cli.migrate import migrate_cmd
from controlzero.cli.telemetry_consent import telemetry_group
from controlzero.errors import PolicyLoadError, PolicyValidationError
from controlzero.policy_loader import load_policy
from controlzero.tamper import HashChain, load_or_create_secret, sign_bundle, verify_bundle

TEMPLATE_DIR = Path(__file__).parent / "templates"
DEFAULT_TEMPLATES = [
    "generic",
    "rag",
    "mcp",
    "cost-cap",
    "claude-code",
    "langchain",
    "crewai",
    "cursor",
    "autogen",
]

# Where the global policy lives when controlzero is used as a Claude Code hook.
# Per-project ./controlzero.yaml takes precedence (the SDK already does this).
GLOBAL_POLICY_DIR = Path.home() / ".controlzero"
GLOBAL_POLICY_PATH = GLOBAL_POLICY_DIR / "policy.yaml"
GLOBAL_POLICY_SIG_PATH = GLOBAL_POLICY_DIR / "policy.yaml.sig"
GLOBAL_TAMPER_KEY_PATH = GLOBAL_POLICY_DIR / "tamper.key"
GLOBAL_AUDIT_PATH = GLOBAL_POLICY_DIR / "audit.log"
# Where the hook-check CLI logs surface-level events that don't flow
# through the policy evaluator -- today just the unenrolled first-run
# carve-out so `controlzero status` can surface "you're running in
# unenrolled allow-all mode" even when no tool calls have been made
# yet. Strictly append-only JSON lines.
GLOBAL_EVENTS_PATH = GLOBAL_POLICY_DIR / "events.log"

# Carve-out banner -- emitted to stderr on every hook-check run that
# hits the unenrolled first-run branch. Kept loud so users cannot
# miss it on day 1. Wording is pinned by test_cli_hook.py so
# integrations can regex-match the banner if they ever need to.
UNENROLLED_BANNER = (
    "[Control Zero] Not enrolled. All actions allowed. Run "
    "'controlzero login' to activate policies."
)


@click.group()
@click.version_option(__version__, prog_name="controlzero")
def cli():
    """ControlZero: AI agent governance, policies, and audit.

    Get started in 30 seconds:

      controlzero init           Write a sample policy.yaml
      controlzero validate       Lint your policy file
      controlzero test <tool>    Dry-run a tool call against the policy
      controlzero tail           Follow the local audit log
    """
    # T101 layout-migration shim: fold any legacy ~/.controlzero/events.log
    # into audit.log before the subcommand runs so downstream commands
    # see the single-file layout the SDK_LOCAL_LAYOUT spec promises.
    # Idempotent and best-effort: no-op when events.log is absent.
    try:
        from controlzero.layout_migration import run_layout_migration
        run_layout_migration(GLOBAL_POLICY_DIR, sdk_version=__version__)
    except Exception:  # noqa: BLE001
        # Migration must never break the CLI.
        pass


@cli.command()
@click.option(
    "--template",
    "-t",
    type=click.Choice(DEFAULT_TEMPLATES),
    default="generic",
    help="Which template to write. 'generic' is a Hello World policy with comments.",
)
@click.option(
    "--out",
    "-o",
    type=click.Path(),
    default="controlzero.yaml",
    help="Output file path. Defaults to ./controlzero.yaml",
)
@click.option(
    "--force",
    "-f",
    is_flag=True,
    help="Overwrite the output file if it exists.",
)
def init(template: str, out: str, force: bool):
    """Write a sample policy file with examples and comments."""
    out_path = Path(out)
    if out_path.exists() and not force:
        click.echo(
            f"error: {out_path} already exists. Use --force to overwrite.",
            err=True,
        )
        sys.exit(1)

    src = TEMPLATE_DIR / f"{template}.yaml"
    if not src.exists():
        click.echo(f"error: template not found: {template}", err=True)
        sys.exit(1)

    out_path.write_text(src.read_text(encoding="utf-8"), encoding="utf-8")
    click.echo(f"Wrote {out_path} ({template} template)")
    click.echo("")
    click.echo("Next steps:")
    click.echo(f"  1. Open {out_path} and edit the rules to fit your app")
    click.echo(f"  2. Run: controlzero validate {out_path}")
    click.echo(f"  3. Test: controlzero test delete_file --policy {out_path}")
    click.echo(f"  4. Use it in code: Client(policy_file='{out_path}')")


@cli.command()
@click.argument("policy_file", type=click.Path(exists=True), default="controlzero.yaml")
def validate(policy_file: str):
    """Validate a policy file. Exits non-zero on errors."""
    try:
        parsed = load_policy(policy_file)
    except (PolicyLoadError, PolicyValidationError) as e:
        click.echo(f"INVALID: {e}", err=True)
        sys.exit(1)
    rules = parsed.rules
    click.echo(f"OK: {policy_file} parsed cleanly ({len(rules)} rules)")
    for r in rules:
        click.echo(f"  - {r.effect:5s} {r.actions} {'(' + r.id + ')' if r.id else ''}")


@cli.command()
@click.argument("tool")
@click.option("--method", "-m", default="*", help="Method name. Defaults to '*'.")
@click.option(
    "--policy",
    "-p",
    type=click.Path(exists=True),
    default="controlzero.yaml",
    help="Policy file to test against.",
)
@click.option("--args", "-a", default="{}", help="Tool args as a JSON string.")
def test(tool: str, method: str, policy: str, args: str):
    """Dry-run a single tool call against a policy file."""
    try:
        args_dict = json.loads(args)
    except json.JSONDecodeError as e:
        click.echo(f"error: --args is not valid JSON: {e}", err=True)
        sys.exit(2)

    try:
        cz = Client(policy_file=policy)
    except (PolicyLoadError, PolicyValidationError) as e:
        click.echo(f"error: {e}", err=True)
        sys.exit(1)

    decision = cz.guard(tool, args_dict, method=method)
    cz.close()

    color = "green" if decision.allowed else "red"
    click.echo(f"tool:    {tool}")
    click.echo(f"method:  {method}")
    click.echo(f"args:    {args_dict}")
    click.echo("")
    click.secho(f"DECISION: {decision.effect.upper()}", fg=color, bold=True)
    if decision.policy_id:
        click.echo(f"matched: {decision.policy_id}")
    if decision.reason:
        click.echo(f"reason:  {decision.reason}")
    sys.exit(0 if decision.allowed else 3)


@cli.command()
@click.option(
    "--log",
    "-l",
    type=click.Path(),
    default="./controlzero.log",
    help="Log file path.",
)
@click.option("--lines", "-n", default=10, help="Show the last N lines first.")
def tail(log: str, lines: int):
    """Follow the local audit log."""
    log_path = Path(log)
    if not log_path.exists():
        click.echo(f"error: log file not found: {log_path}", err=True)
        click.echo(
            "hint: run a Client.guard() call first, or pass --log to a different path.",
            err=True,
        )
        sys.exit(1)

    # Print last N lines
    text = log_path.read_text(encoding="utf-8")
    last_lines = text.splitlines()[-lines:]
    for line in last_lines:
        click.echo(line)

    # Then follow
    import time
    with log_path.open("r", encoding="utf-8") as f:
        f.seek(0, 2)  # seek to end
        try:
            while True:
                chunk = f.readline()
                if not chunk:
                    time.sleep(0.5)
                    continue
                click.echo(chunk.rstrip("\n"))
        except KeyboardInterrupt:
            click.echo("")  # newline after ^C


@cli.command("enroll")
@click.option("--token", required=True, help="Single-use enrollment token from the dashboard.")
@click.option(
    "--api-url",
    default="https://api.controlzero.ai",
    show_default=True,
    help="ControlZero API base URL.",
)
@click.option(
    "--user-email",
    default=None,
    help="Optional: associate the enrolled machine with a user email.",
)
def enroll_cmd(token: str, api_url: str, user_email):
    """Enroll this machine with a ControlZero org.

    Generates a fresh signing keypair, exchanges the enrollment token
    for a server-assigned machine_id, and persists the result to
    ~/.controlzero/. Subsequent calls (heartbeat, policy pull, audit)
    sign requests with the private key automatically.

    Re-running with the same machine fingerprint converges on the
    same machine_id (the backend dedups via UNIQUE(org, fingerprint)).

    Example:

      controlzero enroll --token cz_enroll_xxxxxxxx
      controlzero enroll --token cz_enroll_xxxxxxxx --api-url https://api.controlzero.ai
    """
    from controlzero.enrollment import EnrollmentError, TokenError, enroll

    try:
        state = enroll(api_url=api_url, token=token, user_email=user_email)
    except TokenError as e:
        click.echo(f"enrollment failed: token rejected: {e}", err=True)
        sys.exit(2)
    except EnrollmentError as e:
        click.echo(f"enrollment failed: {e}", err=True)
        sys.exit(1)

    click.echo("Enrolled successfully.")
    click.echo(f"  machine_id     : {state.machine_id}")
    click.echo(f"  org_id         : {state.org_id}")
    click.echo(f"  hostname       : {state.hostname}")
    click.echo(f"  fingerprint    : {state.fingerprint_hint}")
    click.echo(f"  policy_version : {state.policy_version}")
    click.echo("")
    click.echo("State persisted to ~/.controlzero/enrollment.json")
    click.echo("Private key persisted to ~/.controlzero/machine.key (mode 0600)")


@cli.command("heartbeat")
def heartbeat_cmd():
    """Send a single signed heartbeat to the backend.

    Useful for verifying enrollment end-to-end. In normal operation
    a long-running daemon sends heartbeats every 5 minutes.
    """
    from controlzero.enrollment import (
        EnrollmentError,
        NotEnrolledError,
        heartbeat,
        load_state,
    )

    state = load_state()
    if state is None:
        click.echo("not enrolled. Run `controlzero enroll --token <TOKEN>` first.", err=True)
        sys.exit(1)

    try:
        resp = heartbeat(state)
    except NotEnrolledError as e:
        click.echo(f"heartbeat failed: {e}", err=True)
        sys.exit(1)
    except EnrollmentError as e:
        click.echo(f"heartbeat failed: {e}", err=True)
        sys.exit(2)

    click.echo("Heartbeat OK.")
    click.echo(f"  server_time    : {resp.get('server_time', 'unknown')}")
    click.echo(f"  policy_version : {resp.get('policy_version', 0)}")


@cli.command("policy-pull")
def policy_pull_cmd():
    """Pull the latest policy bundle from the backend.

    Uses If-None-Match with the locally cached policy_version. If the
    server returns 304 Not Modified, the local cache is already
    current and nothing is downloaded.
    """
    from controlzero.enrollment import (
        EnrollmentError,
        NotEnrolledError,
        load_state,
        pull_policy,
    )

    state = load_state()
    if state is None:
        click.echo("not enrolled. Run `controlzero enroll --token <TOKEN>` first.", err=True)
        sys.exit(1)

    try:
        bundle = pull_policy(state)
    except NotEnrolledError as e:
        click.echo(f"pull failed: {e}", err=True)
        sys.exit(1)
    except EnrollmentError as e:
        click.echo(f"pull failed: {e}", err=True)
        sys.exit(2)

    if bundle is None:
        click.echo(f"Policy is up to date (version {state.policy_version}).")
        return

    click.echo(f"Pulled policy version {bundle.get('policy_version', 0)}.")
    rules = bundle.get("rules", [])
    click.echo(f"  rules: {len(rules)}")
    for rule in rules[:10]:
        click.echo(f"    - {rule.get('name')} ({rule.get('action')}, scopes={rule.get('scopes')})")
    if len(rules) > 10:
        click.echo(f"    ... and {len(rules) - 10} more")


@cli.command("env-dump")
@click.option(
    "--show-secrets",
    is_flag=True,
    default=False,
    help="Un-redact API keys and secret-like env vars. Use only when sharing with Control Zero support.",
)
@click.option(
    "--from-hook",
    is_flag=True,
    default=False,
    help="Read a hook-style JSON payload from stdin and report which host-agent adapter would claim it.",
)
def env_dump_cmd(show_secrets: bool, from_hook: bool):
    """Print a redacted snapshot of the SDK's effective environment.

    Designed for support: paste the JSON output into a ticket and the
    Control Zero team can tell you (without round-trips) which host
    adapter the SDK is selecting, which env vars are present, which
    config files exist, and what API URL is in effect.

    Examples:

      controlzero env-dump
      controlzero env-dump --from-hook < /tmp/claude-payload.json
      controlzero env-dump --show-secrets    # un-redacts; DANGEROUS

    Filed as #438 follow-up to the 2026-05-12 hook-decision regression
    where source-detection on Windows was unknown without instrumenting
    the customer's hook environment.
    """
    import platform as _platform
    import re as _re

    payload: dict = {}
    if from_hook:
        try:
            raw = sys.stdin.read()
            if raw.strip():
                payload = json.loads(raw)
        except (KeyboardInterrupt, EOFError, json.JSONDecodeError):
            payload = {}

    # Mask CONTROLZERO_API_KEY and *_TOKEN / *_KEY / *_SECRET env vars
    # unless --show-secrets is passed.
    _secret_pat = _re.compile(r"(TOKEN|KEY|SECRET|PASSWORD|CREDENTIAL)$", _re.IGNORECASE)
    env_view: dict = {}
    for k, v in sorted(os.environ.items()):
        if not isinstance(v, str):
            continue
        # Keep ASCII-printable values, length-capped at 200 chars; non-
        # printable env vars are usually accidental binary export and
        # not useful for debugging.
        if any(ord(c) < 32 or ord(c) > 126 for c in v):
            redacted = f"<NON-PRINTABLE-LEN-{len(v)}>"
        elif show_secrets:
            redacted = v
        elif k == "CONTROLZERO_API_KEY":
            # Always preserve the public prefix so "is it a live or
            # test key" is observable without leaking entropy.
            if v.startswith("cz_live_"):
                redacted = "cz_live_***"
            elif v.startswith("cz_test_"):
                redacted = "cz_test_***"
            else:
                redacted = "***"
        elif _secret_pat.search(k):
            redacted = f"<REDACTED-LEN-{len(v)}>"
        else:
            redacted = v if len(v) <= 200 else (v[:200] + f"...<+{len(v) - 200}>")
        env_view[k] = redacted

    # Host adapter selection.
    try:
        from controlzero.cli.hosts import select_adapter as _select_adapter
        adapter = _select_adapter(payload, os.environ)
        adapter_info = {
            "name": adapter.name,
            "canonical_source": adapter.canonical_source,
        }
    except Exception as exc:  # noqa: BLE001
        adapter_info = {"name": "unknown", "error": str(exc)}

    # Config + log file presence (size + mtime, NOT contents).
    files = {}
    for path in (
        GLOBAL_POLICY_DIR / "config.yaml",
        GLOBAL_POLICY_DIR / "policy.yaml",
        GLOBAL_POLICY_DIR / "audit.log",
        GLOBAL_POLICY_DIR / "events.log",  # legacy, pre-1.5.4
        GLOBAL_POLICY_DIR / "enrollment.json",
        Path.home() / ".claude" / "settings.json",
        Path.home() / ".gemini" / "settings.json",
        Path.home() / ".codex" / "hooks.json",
    ):
        try:
            if path.exists():
                stat = path.stat()
                files[str(path)] = {
                    "exists": True,
                    "size_bytes": stat.st_size,
                    "mtime_iso": datetime.fromtimestamp(
                        stat.st_mtime, tz=timezone.utc
                    ).isoformat(),
                }
            else:
                files[str(path)] = {"exists": False}
        except Exception as exc:  # noqa: BLE001
            files[str(path)] = {"exists": "error", "error": str(exc)}

    # Resolved hosted API URL.
    api_url = os.environ.get("CONTROLZERO_API_URL", "https://api.controlzero.ai")

    from controlzero import __version__ as _cz_version

    dump = {
        "controlzero_version": _cz_version,
        "hostname": _platform.node(),
        "system": _platform.system(),
        "release": _platform.release(),
        "machine": _platform.machine(),
        "python_version": _platform.python_version(),
        "python_executable": sys.executable,
        "api_url": api_url,
        "adapter": adapter_info,
        "from_hook_payload_keys": sorted(payload.keys()) if payload else [],
        "files": files,
        "env": env_view,
        "show_secrets": show_secrets,
    }

    if show_secrets:
        click.echo(
            "WARNING: env-dump was run with --show-secrets. The output below contains unredacted API keys, tokens, and credentials.",
            err=True,
        )

    click.echo(json.dumps(dump, indent=2, sort_keys=True))


@cli.command("status")
def status_cmd():
    """Show enrollment state, policy source, and recent carve-out events.

    Printed as human-readable text by default. Part of the #228
    Phase 2 carve-out contract: a user who is running in
    unenrolled allow-all mode must be able to run a single command
    and see "you are in allow-all mode" plus the count of
    unenrolled tool calls the hook has allowed.
    """
    api_key_env = bool(os.environ.get("CONTROLZERO_API_KEY", ""))
    api_key_config = False
    config_path = GLOBAL_POLICY_DIR / "config.yaml"
    if config_path.exists():
        try:
            cfg = yaml.safe_load(config_path.read_text(encoding="utf-8"))
            if isinstance(cfg, dict) and cfg.get("api_key"):
                api_key_config = True
        except Exception:  # noqa: BLE001
            pass

    enrollment_path = GLOBAL_POLICY_DIR / "enrollment.json"
    enrolled = enrollment_path.exists()

    unenrolled_first_run = not (api_key_env or api_key_config or enrolled)

    click.echo("Control Zero status")
    click.echo("")
    click.echo(f"  state dir       : {GLOBAL_POLICY_DIR}")
    click.echo(f"  enrolled        : {enrolled}")
    click.echo(f"  api key (env)   : {api_key_env}")
    click.echo(f"  api key (cfg)   : {api_key_config}")
    click.echo("")
    if unenrolled_first_run:
        click.secho(
            "  mode            : UNENROLLED ALLOW-ALL (carve-out active)",
            fg="yellow",
            bold=True,
        )
        click.echo(
            "                    Run `controlzero login` or "
            "`controlzero enroll --token ...`"
        )
        click.echo(
            "                    to activate policy enforcement."
        )
    else:
        click.echo("  mode            : ENFORCING (policy-driven)")

    # Summarize recent carve-out events so the user can see whether
    # their agent has been allowed-through without policy.
    # 1.5.5 (T101): the layout-migration shim runs in cli() before
    # this subcommand, so any legacy events.log content has already
    # been folded into audit.log by the time we get here. Only
    # audit.log is read.
    if GLOBAL_AUDIT_PATH.exists():
        try:
            lines = GLOBAL_AUDIT_PATH.read_text(encoding="utf-8").splitlines()
            carve_out_events = [
                json.loads(ln) for ln in lines
                if ln.strip() and "unenrolled_first_run_allow" in ln
            ]
            click.echo("")
            click.echo(
                f"  carve-out allows: {len(carve_out_events)} "
                "(unenrolled tool calls allowed since install)"
            )
            if carve_out_events:
                # Show the last 3 tool names for quick triage.
                recent = carve_out_events[-3:]
                for ev in recent:
                    tool = ev.get("tool_name", "?")
                    click.echo(f"    - {tool}")
        except Exception:  # noqa: BLE001
            # Broken events file is fine -- status is best-effort.
            pass


@cli.command("hook-check")
@click.option(
    "--policy",
    "-p",
    type=click.Path(readable=False),
    default=None,
    help="Policy file. Defaults to ./controlzero.yaml then ~/.controlzero/policy.yaml",
)
def hook_check(policy: Optional[str]):
    """Read a tool call from stdin (Claude Code hook protocol) and decide.

    Reads JSON from stdin with at minimum {"tool_name": "...", "tool_input": {...}}.
    Evaluates against the resolved policy. On allow exits 0. On deny exits 2 with
    a JSON block decision on stdout.

    Designed for Claude Code's PreToolUse hook system. Other agents that send a
    similar JSON-on-stdin protocol can reuse this command.
    """
    # Read stdin -- Claude Code passes the tool payload here
    try:
        raw = sys.stdin.read()
    except (KeyboardInterrupt, EOFError):
        # No payload: pass through (do not break the agent)
        sys.exit(0)

    if not raw.strip():
        # Empty stdin: pass through
        sys.exit(0)

    try:
        payload = json.loads(raw)
    except json.JSONDecodeError as e:
        # Malformed payload: log to stderr and pass through. Never brick the agent.
        click.echo(f"controlzero: hook payload is not JSON ({e}); allowing", err=True)
        sys.exit(0)

    tool_name = payload.get("tool_name") or payload.get("toolName") or ""
    tool_args = payload.get("tool_input") or payload.get("toolInput") or {}
    if not tool_name:
        click.echo("controlzero: hook payload missing tool_name; allowing", err=True)
        sys.exit(0)

    # 1.5.3 adapter base: pick the right host-agent adapter for this
    # invocation. Detection uses the stdin payload signature first
    # (works even when env vars are missing -- e.g. CLAUDECODE not
    # exported on Windows) and falls back to env hints. The selected
    # adapter owns both the on-the-wire decision shape (rendering)
    # and the canonical source name carried into the audit row.
    from controlzero.cli.hosts import CZDecision, select_adapter

    _adapter = select_adapter(payload, os.environ)
    # Pin the audit-row source so audit_remote._to_wire_format
    # records the right SOURCE column value (CONTROLZERO_CLIENT is
    # the explicit-override head of detect_client_name's ladder).
    os.environ["CONTROLZERO_CLIENT"] = _adapter.canonical_source

    def _emit_decision(
        effect: str,
        reason: str,
        reason_code: str,
        *,
        policy_id: str = "",
        tool: str = "",
        method: str = "",
        extracted_action: str = "",
        semantic_class: str = "",
        tamper_detected: bool = False,
        audit_chain_broken: bool = False,
    ) -> None:
        """Render the decision through the active host adapter and
        write it to stdout. Replaces the pre-1.5.3 hard-coded
        ``json.dumps({"decision": ...})`` calls that crashed Claude
        Code's hook validator when ``decision="allow"`` was emitted.
        """
        decision = CZDecision(
            effect=effect,
            reason=reason,
            reason_code=reason_code,
            policy_id=policy_id,
            tool=tool,
            method=method,
            extracted_action=extracted_action,
            semantic_class=semantic_class,
            tamper_detected=tamper_detected,
            audit_chain_broken=audit_chain_broken,
        )
        click.echo(json.dumps(_adapter.render(decision)))

    # Resolve (canonical_tool, method) from the shared extractor spec.
    # Before #228 phase 3 the hook-check CLI passed method="*" for every
    # call because it could not reach into tool_input to pull a method
    # out. That meant rules like `deny database:DROP` never matched via
    # the hook path. Now every the 2026-04-19-style PreToolUse payload collapses
    # to the same canonical (tool, method) the Gateway and SDK
    # guard() call sites already produce.
    _tool_args_dict = tool_args if isinstance(tool_args, dict) else {}
    canonical_tool, extracted_method = extract_method(
        tool_name, _tool_args_dict,
    )
    extracted_action = f"{canonical_tool}:{extracted_method}"

    # Semantic-class layer for SQL: a portable canonical class
    # (read|write|admin|exec) parallel to the per-keyword method.
    # Lets a `database:read` rule cover SELECT / EXPLAIN / SHOW /
    # CTE / DESCRIBE without enumerating every dialect-specific
    # spelling. See ``docs/sdk/policies/canonical-tools.md``.
    semantic_class = ""
    semantic_action = ""
    if canonical_tool == "database":
        sql_text = _tool_args_dict.get("sql") if isinstance(_tool_args_dict, dict) else None
        if isinstance(sql_text, str) and sql_text:
            semantic_class = sql_semantic_class(sql_text)
            if semantic_class:
                semantic_action = f"{canonical_tool}:{semantic_class}"

    # Unenrolled first-run carve-out.
    #
    # Spec (#228 Phase 2, user-approved): when no API key AND no
    # ~/.controlzero/enrollment.json exists AND no local policy
    # file has been resolved, the hook exits 0 with a loud banner
    # on stderr. This is the onboarding path: a user who just ran
    # `pip install control-zero` and wired up a coding-agent hook
    # should NOT have their agent bricked by fail-closed semantics
    # before they have even touched a dashboard. The banner makes
    # the "allow-all" mode obvious so nobody mistakes the install
    # for "governance active". The moment any of the three signals
    # appears (API key in env, an enrollment.json on disk, OR a
    # local policy file), the carve-out stops applying and the
    # normal evaluator + default_on_missing logic takes over.
    #
    # The explicit-policy exemption lets power users run
    # `controlzero hook-check --policy my.yaml` and get the same
    # behaviour as before Phase 2 -- no surprise banner just because
    # they never ran `controlzero login`.
    _explicit_policy_supplied = policy is not None or _has_resolvable_policy_file()
    if _is_unenrolled_first_run() and not _explicit_policy_supplied:
        click.echo(UNENROLLED_BANNER, err=True)
        # Emit the same JSON shape as the policy path so downstream
        # consumers can parse a consistent structure. decision=allow
        # plus reason_code=RULE_MATCH is intentionally a white lie:
        # there is no rule, but we want automation that branches on
        # reason_code to treat this as a normal allow. A dedicated
        # code would require adding a ninth enum value; the user
        # explicitly pinned the enum at eight.
        _emit_decision(
            effect="allow",
            reason=UNENROLLED_BANNER,
            reason_code=REASON_CODE_RULE_MATCH,
        )
        _append_event({
            "event": "unenrolled_first_run_allow",
            "tool_name": tool_name,
            "reason_code": REASON_CODE_RULE_MATCH,
            "ts": time.time(),
        })
        sys.exit(0)

    # Machine-level quarantine check: if quarantined, deny everything immediately
    from controlzero.tamper import TamperState
    _quarantine_dir = GLOBAL_POLICY_DIR
    # Allow test override via patched GLOBAL_POLICY_DIR
    if TamperState.is_quarantined(_quarantine_dir):
        _emit_decision(
            effect="deny",
            reason="[Control Zero] Machine quarantined: all tool calls denied until recovery.",
            reason_code=REASON_CODE_MACHINE_QUARANTINED,
        )
        sys.exit(2)

    # Hoist api_key resolution above the precedence decision so a key
    # stored only in ~/.controlzero/config.yaml correctly enables hosted
    # mode. Pre-T103 this happened AFTER the resolver, so a user with the
    # key in config.yaml but not in env fell through to the local-file
    # path on every hook-check.
    if not os.environ.get("CONTROLZERO_API_KEY"):
        _config_path = GLOBAL_POLICY_DIR / "config.yaml"
        if _config_path.exists():
            try:
                _config = yaml.safe_load(_config_path.read_text(encoding="utf-8"))
                if _config and _config.get("api_key"):
                    os.environ["CONTROLZERO_API_KEY"] = _config["api_key"]
            except Exception:
                pass

    # T103 review (B1, B2): the CLI hook-check is a non-interactive
    # subprocess that Claude Code / Gemini CLI / Codex CLI spawn fresh
    # for every PreToolUse hook. Module-level "warn once per process"
    # guards do nothing here: every tool call is a new process.
    # Without this env var, every Bash / Edit / Read in an agent
    # session would emit an active-source notification to stderr.
    # Suppress for the hook subprocess context only; library callers
    # still see it once per process. CLI runs may opt in by setting
    # CONTROLZERO_VERBOSE_HOOK=1.
    if os.environ.get("CONTROLZERO_VERBOSE_HOOK", "").lower() not in ("1", "true", "yes", "on"):
        os.environ.setdefault("CONTROLZERO_QUIET", "1")

    # T103 precedence (2026-05-12):
    #   1. --policy <path> wins unconditionally.
    #   2. api_key set => hosted mode. Client(api_key=...) loads the cached
    #      bundle via hosted_policy and conditional-refreshes it on every
    #      construction (content-hash via If-None-Match, not mtime). This
    #      is the path the customer should have hit on every hook-check.
    #   3. CONTROLZERO_LOCAL_OVERRIDE=1 with api_key => fall back to file.
    #   4. No api_key, no enrollment => local file path.
    #
    # Before T103 the resolver fell back to ~/.controlzero/policy.yaml
    # whenever it existed, even with a valid api_key. a customer's manually
    # edited policy.yaml shadowed the dashboard policy with no warning.
    _local_override = os.environ.get(
        "CONTROLZERO_LOCAL_OVERRIDE", ""
    ).lower() in ("1", "true", "yes", "on")
    _hosted_active = bool(os.environ.get("CONTROLZERO_API_KEY")) and not _local_override

    if policy is not None:
        # Explicit --policy wins.
        policy_path = _resolve_hook_policy(policy)
    elif _hosted_active:
        # Hosted mode. No file resolution; the Client constructor will
        # read the cache + conditional-refresh. policy_path stays None so
        # we route through the hosted branch below.
        policy_path = None
    else:
        # Local mode: enrollment-based pull (if enrolled) or static file.
        policy_path = _resolve_hook_policy(policy)
        if policy_path is not None:
            _maybe_refresh_policy(policy_path)

    if policy_path is None and not _hosted_active:
        # No policy installed AND the carve-out already passed (user
        # is enrolled or has an API key). This is the BUNDLE_MISSING
        # path -- backend bundle never synced, sync failed, or the
        # user has not yet run `controlzero install`. Honor the
        # resolved default_on_missing; canonical default is deny.
        #
        # Recovery lookup order:
        #   1. enrollment.json -- if the prior sync persisted a
        #      default_on_missing. (Enrollment state doesn't carry
        #      this today; placeholder for future Phase 2 work.)
        #   2. Canonical backend default -- deny.
        effect = _resolve_default_on_missing()
        reason = (
            f"[Control Zero] No policy bundle available. Honoring "
            f"default_on_missing={effect}. Run "
            "`controlzero install claude-code` to install one."
        )
        if effect == "allow":
            # User / org opted into permissive onboarding.
            click.echo(reason, err=True)
            _emit_decision(
                effect="allow",
                reason=reason,
                reason_code=REASON_CODE_BUNDLE_MISSING,
            )
            sys.exit(0)
        # effect == "deny"
        click.echo(reason, err=True)
        _emit_decision(
            effect="deny",
            reason=reason,
            reason_code=REASON_CODE_BUNDLE_MISSING,
        )
        sys.exit(2)

    # api_key resolution moved above the precedence decision (see T103
    # block). Do not re-load here.

    # --- Tamper detection ---
    # Policy-file HMAC check applies ONLY to file-backed policies. In
    # hosted mode (policy_path is None) the bundle is cryptographically
    # signed and verified inside hosted_policy.load_hosted_policy at
    # Client init time; a separate HMAC over a local file is meaningless.
    tamper_detected = _check_policy_tamper(policy_path) if policy_path is not None else False

    # --- Tamper detection: audit log hash chain check ---
    audit_chain_broken = _check_audit_chain()

    # Apply tamper behavior enforcement
    if tamper_detected or audit_chain_broken:
        behavior = _get_tamper_behavior(policy_path, GLOBAL_POLICY_DIR)
        if behavior == "deny":
            source = "policy_hmac" if tamper_detected else "audit_chain"
            _emit_decision(
                effect="deny",
                reason=f"[Control Zero] Tamper detected ({source}). Blocked by enforcement policy.",
                reason_code="BUNDLE_TAMPERED",
                tamper_detected=tamper_detected,
                audit_chain_broken=audit_chain_broken,
            )
            click.echo(f"[Control Zero] Tamper enforcement: {source} mismatch", err=True)
            sys.exit(2)
        elif behavior in ("deny-all", "quarantine"):
            from controlzero.tamper import TamperState, report_tamper_alert
            source = "policy_hmac" if tamper_detected else "audit_chain"
            TamperState.enter_quarantine(GLOBAL_POLICY_DIR, reason=f"tamper: {source}", source=source)
            if behavior == "quarantine":
                report_tamper_alert(GLOBAL_POLICY_DIR, source=source)
            _emit_decision(
                effect="deny",
                reason="[Control Zero] Machine quarantined: tampering detected.",
                reason_code=REASON_CODE_MACHINE_QUARANTINED,
                tamper_detected=tamper_detected,
                audit_chain_broken=audit_chain_broken,
            )
            click.echo("[Control Zero] Quarantined: all calls blocked until recovery", err=True)
            sys.exit(2)

    try:
        if _hosted_active and policy_path is None:
            # T103: hosted mode. Client() reads the cache and conditional-
            # refreshes it on construction. No file-path argument.
            cz = Client(log_path=str(GLOBAL_AUDIT_PATH))
        else:
            cz = Client(
                policy_file=str(policy_path),
                log_path=str(GLOBAL_AUDIT_PATH),
            )
    except (PolicyLoadError, PolicyValidationError, PermissionError, OSError) as e:
        # Bad/unreadable policy file: log + allow (do not silently break the agent)
        click.echo(f"controlzero: policy file invalid ({e}); allowing", err=True)
        sys.exit(0)
    except Exception as e:  # noqa: BLE001
        # Hosted-pull failure (HostedAuthError, HostedBootstrapError, etc).
        # Fail-closed with a clear reason; do NOT silently allow because
        # that's what the customer was hitting at the time.
        click.echo(f"controlzero: hosted policy load failed ({e})", err=True)
        _emit_decision(
            effect="deny",
            reason=f"[Control Zero] Hosted policy load failed: {e}",
            reason_code=REASON_CODE_BUNDLE_MISSING,
        )
        sys.exit(2)

    decision = cz.guard(
        canonical_tool,
        args=_tool_args_dict,
        method=extracted_method,
        context={
            "tamper_detected": tamper_detected,
            "audit_chain_broken": audit_chain_broken,
            # Carry the resolved action + extractor output through to
            # the audit envelope so the backend audit column
            # `extracted_method` (#228 phase 3 T4d) sees what the
            # coding-agent hook actually evaluated against.
            "extracted_method": extracted_method,
            "extracted_action": extracted_action,
            "host_tool_name": tool_name,
            # Semantic-class layer (issue #345). The evaluator matches
            # rules against BOTH the per-keyword action above AND this
            # canonical class so a `database:read` rule fires for any
            # read-shaped statement (SELECT, EXPLAIN, SHOW, CTE, ...)
            # while a `database:DROP` keyword rule still works.
            "action_semantic_class": semantic_action,
        },
    )
    cz.close()

    if decision.denied:
        reason = decision.reason or "Blocked by policy"
        branded_reason = f"[Control Zero] {reason}"
        # Claude Code reads stdout JSON for the model-facing reason.
        # reason_code is additive (#228 Phase 2) -- downstream
        # consumers that branch on it can distinguish a user-rule
        # deny (RULE_MATCH) from a fall-through deny (NO_RULE_MATCH)
        # from an empty-bundle deny (NO_ACTIVE_POLICIES). Keeps the
        # free-text "reason" field intact for humans.
        _emit_decision(
            effect="deny",
            reason=branded_reason,
            reason_code=decision.reason_code or "",
            policy_id=decision.policy_id or "",
            tool=canonical_tool,
            method=extracted_method,
            extracted_action=extracted_action,
            semantic_class=semantic_action,
            tamper_detected=tamper_detected,
            audit_chain_broken=audit_chain_broken,
        )
        # Gemini CLI and Codex CLI read stderr for the rejection reason on exit 2
        click.echo(branded_reason, err=True)
        sys.exit(2)

    # On allow, print a brief branded notice to stderr so the user knows CZ is active.
    # Agents ignore stderr on exit 0, but it appears in terminal logs.
    # Emit the same JSON envelope as the deny path so tooling has a
    # consistent shape to parse; agents that only look at exit code
    # continue to ignore it.
    _emit_decision(
        effect="allow",
        reason=f"[Control Zero] Allowed: {tool_name}",
        reason_code=decision.reason_code or REASON_CODE_RULE_MATCH,
        policy_id=decision.policy_id or "",
        tool=canonical_tool,
        method=extracted_method,
        extracted_action=extracted_action,
        semantic_class=semantic_action,
        tamper_detected=tamper_detected,
        audit_chain_broken=audit_chain_broken,
    )
    click.echo(f"[Control Zero] Allowed: {tool_name}", err=True)
    sys.exit(0)


# =============================================================================
# sign-policy
# =============================================================================


@cli.command("sign-policy")
@click.option(
    "--policy",
    "-p",
    type=click.Path(exists=True, readable=True),
    default=None,
    help="Policy file to sign. Defaults to ~/.controlzero/policy.yaml",
)
@click.option(
    "--verify-only",
    is_flag=True,
    help="Only verify the existing signature, do not re-sign.",
)
def sign_policy(policy: Optional[str], verify_only: bool):
    """Sign a policy file with HMAC-SHA256 for tamper detection.

    Creates or updates a .sig file alongside the policy. The hook-check
    command verifies this signature on every invocation. If the policy
    file is modified after signing, tamper detection flags the mismatch.

    The HMAC key is stored at ~/.controlzero/tamper.key (created on
    first use, permissions restricted to 0600).
    """
    policy_path = Path(policy) if policy else GLOBAL_POLICY_PATH

    if not policy_path.exists():
        click.echo(
            f"[Control Zero] Policy file not found: {policy_path}",
            err=True,
        )
        click.echo(
            "Run 'controlzero install claude-code' (or gemini-cli/codex-cli) to create one.",
            err=True,
        )
        sys.exit(1)

    key_path = policy_path.parent / "tamper.key"
    secret = load_or_create_secret(key_path)
    sig_path = policy_path.with_suffix(policy_path.suffix + ".sig")

    if verify_only:
        if not sig_path.exists():
            click.echo("[Control Zero] No signature file found. Policy is unsigned.")
            sys.exit(1)
        content = policy_path.read_bytes()
        existing_sig = sig_path.read_text(encoding="utf-8").strip()
        if verify_bundle(content, existing_sig, secret):
            click.echo("[Control Zero] Policy signature is valid. No tampering detected.")
            sys.exit(0)
        else:
            click.echo(
                "[Control Zero] TAMPER DETECTED: Policy file has been modified since signing.",
                err=True,
            )
            click.echo(
                f"  Policy:    {policy_path}",
                err=True,
            )
            click.echo(
                f"  Signature: {sig_path}",
                err=True,
            )
            click.echo(
                "  Run 'controlzero sign-policy' to re-sign after reviewing changes.",
                err=True,
            )
            sys.exit(2)

    # Sign the policy
    content = policy_path.read_bytes()
    signature = sign_bundle(content, secret)
    sig_path.write_text(signature + "\n", encoding="utf-8")

    click.echo("[Control Zero] Policy signed successfully.")
    click.echo(f"  Policy:    {policy_path}")
    click.echo(f"  Signature: {sig_path}")
    click.echo(f"  Key:       {key_path}")
    click.echo("")
    click.echo("  The hook-check command will now verify this signature on every")
    click.echo("  tool call. If the policy is modified without re-signing, tamper")
    click.echo("  detection will flag the mismatch in the audit trail.")


def _has_resolvable_policy_file() -> bool:
    """True when a ``./controlzero.yaml`` or ``~/.controlzero/policy.yaml``
    exists and looks loadable.

    Scoped to the carve-out logic: "do we already have a policy in
    the standard search paths?" If yes, the user is past first-run
    and the carve-out banner is noise. Mirrors the happy-path search
    order in :func:`_resolve_hook_policy` so the two stay in sync.
    """
    cwd_policy = Path.cwd() / "controlzero.yaml"
    if cwd_policy.exists():
        return True
    if GLOBAL_POLICY_PATH.exists():
        return True
    return False


def _is_unenrolled_first_run() -> bool:
    """True when the machine has neither an API key nor an enrollment file.

    Part of the #228 Phase 2 carve-out: a user who just installed
    the SDK + wired a coding-agent hook, but has not yet logged in
    OR enrolled, should not have their agent bricked by
    fail-closed semantics. The moment either signal appears, this
    returns False and the normal default_on_missing path takes
    over.

    Both signals are deliberately cheap to check -- the hook-check
    hot path must not add noticeable latency. A missing enrollment
    file is a simple ``Path.exists``; a missing API key is an env
    read + a config.yaml read.
    """
    # API key in env OR in ~/.controlzero/config.yaml
    api_key = os.environ.get("CONTROLZERO_API_KEY", "")
    if not api_key:
        config_path = GLOBAL_POLICY_DIR / "config.yaml"
        if config_path.exists():
            try:
                config = yaml.safe_load(config_path.read_text(encoding="utf-8"))
                if isinstance(config, dict) and config.get("api_key"):
                    api_key = str(config["api_key"])
            except Exception:  # noqa: BLE001
                # Unreadable config: treat as no key. Fail-open on the
                # carve-out is safer than accidentally bricking the
                # agent on a bad yaml.
                api_key = ""
    if api_key:
        return False
    enrollment_path = GLOBAL_POLICY_DIR / "enrollment.json"
    if enrollment_path.exists():
        return False
    return True


def _resolve_default_on_missing() -> str:
    """Resolve the effective default_on_missing for the hook-check CLI.

    Today the only signal available to the CLI when the bundle is
    missing is the canonical backend default (``deny``). Future
    Phase 2 work could teach enrollment.json to cache the last-seen
    default_on_missing, at which point we'd prefer that value. For
    now, stay canonical so SDKs and the CLI agree.
    """
    # Placeholder for cached bundle-level default lookup. Keeping the
    # helper here lets us swap in a richer resolver in Phase 2+
    # without touching the hook-check call site.
    return DEFAULT_BUNDLE_ON_MISSING


def _append_event(event: dict) -> None:
    """Append a structured lifecycle event to ~/.controlzero/audit.log.

    Used for the unenrolled-first-run carve-out (so `controlzero
    status` can report whether the hook is allowing through without
    policy), the T108 LOCAL_OVERRIDE governance event, and any
    future hook-lifecycle event we want to surface to support.

    1.5.4 (T96 -- SDK_LOCAL_LAYOUT spec): the SDK now writes ONE
    JSONL file at ``~/.controlzero/audit.log``. Pre-1.5.4 the SDK
    split rows across ``audit.log`` (decisions) and ``events.log``
    (lifecycle). Customers had to tail two files; ``cz debug
    bundle`` had to read two paths. The single-file layout
    standardises everything.

    Decision rows are written by the BearerAuditSink / local
    AuditLogger (in JSON Lines too); we use an explicit
    ``event_type`` field on lifecycle entries so a reader can
    filter (decisions land without that key).
    """
    try:
        GLOBAL_POLICY_DIR.mkdir(parents=True, exist_ok=True)
        with GLOBAL_AUDIT_PATH.open("a", encoding="utf-8") as f:
            f.write(json.dumps(event) + "\n")
    except Exception:  # noqa: BLE001
        # Best-effort. Logging failure must not propagate.
        pass


def _check_policy_tamper(policy_path: Path) -> bool:
    """Check policy file integrity against its HMAC signature file.

    Returns True if tamper is detected. Returns False if the signature
    file does not exist (backwards compatible) or if verification passes.
    Never raises; logs warnings to stderr on tamper detection.
    """
    # Determine sig path: sibling of the policy file with .sig appended
    sig_path = policy_path.with_suffix(policy_path.suffix + ".sig")
    if not sig_path.exists():
        # No signature file: skip check (backwards compatible)
        return False

    try:
        key_path = policy_path.parent / "tamper.key"
        if not key_path.exists():
            # No tamper key but sig file exists: suspicious but not conclusive
            click.echo(
                "controlzero: policy signature file exists but tamper key is missing; "
                "skipping tamper check",
                err=True,
            )
            return False
        secret = load_or_create_secret(key_path)
        policy_content = policy_path.read_bytes()
        signature = sig_path.read_text(encoding="utf-8").strip()
        if not verify_bundle(policy_content, signature, secret):
            click.echo(
                "controlzero: policy file tamper detected (HMAC mismatch); "
                "allowing but flagging",
                err=True,
            )
            return True
    except Exception as e:
        # Any error in tamper checking: log and continue (fail-open for CLI)
        click.echo(
            f"controlzero: tamper check error ({e}); skipping",
            err=True,
        )
    return False


def _check_audit_chain() -> bool:
    """Verify the audit log hash chain integrity.

    Returns True if the chain is broken. Returns False if the audit log
    does not exist, has no entries, or the chain is intact.
    Never raises; logs warnings to stderr on chain breakage.
    """
    if not GLOBAL_AUDIT_PATH.exists():
        return False

    try:
        text = GLOBAL_AUDIT_PATH.read_text(encoding="utf-8").strip()
        if not text:
            return False

        entries = []
        for line in text.splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                entry = json.loads(line)
                # Only check entries that have hash chain fields
                if "entry_hash" in entry and "prev_hash" in entry:
                    entries.append(entry)
            except json.JSONDecodeError:
                continue

        if not entries:
            return False

        chain = HashChain(GLOBAL_AUDIT_PATH)
        ok, bad_idx = chain.verify(entries)
        if not ok:
            click.echo(
                f"controlzero: audit log hash chain broken at entry {bad_idx}; "
                "allowing but flagging",
                err=True,
            )
            return True
    except Exception as e:
        click.echo(
            f"controlzero: audit chain check error ({e}); skipping",
            err=True,
        )
    return False


def _get_tamper_behavior(policy_path: Optional[Path], state_dir: Path) -> str:
    """Determine effective tamper behavior. Priority: enrollment > policy > default."""
    # 1. Check enrollment state
    es = _load_enrollment_state(state_dir)
    if es and hasattr(es, 'tamper_behavior') and es.tamper_behavior:
        return es.tamper_behavior
    # 2. Check policy settings section
    if policy_path and policy_path.exists():
        try:
            parsed = load_policy(policy_path)
            if parsed.settings.tamper_behavior != "warn":
                return parsed.settings.tamper_behavior
        except Exception:
            pass
    return "warn"


# -- Policy freshness check for enrolled machines -------------------------
# Staleness threshold in seconds. If the global policy file is older than
# this, hook-check will attempt a background pull_policy() call.
POLICY_STALENESS_THRESHOLD_S = 300  # 5 minutes
# Maximum time to wait for the network sync before falling back to the
# cached policy. Keeps the agent snappy.
POLICY_SYNC_TIMEOUT_S = 2.0


def _is_policy_stale(policy_path: Path, threshold_s: float = POLICY_STALENESS_THRESHOLD_S) -> bool:
    """Return True if *policy_path* mtime is older than *threshold_s* seconds."""
    try:
        mtime = os.path.getmtime(policy_path)
        return (time.time() - mtime) > threshold_s
    except OSError:
        # File missing or inaccessible: treat as stale so we try to pull.
        return True


def _load_enrollment_state(state_dir: Path = GLOBAL_POLICY_DIR) -> Optional[object]:
    """Load the enrollment state from disk, returning None on any error.

    This is a fail-open helper: if enrollment.json is missing, malformed,
    or missing required fields, we return None so the caller skips the
    sync and proceeds with local-only mode.
    """
    try:
        from controlzero.enrollment import load_state
        state = load_state(state_dir)
        if state is None:
            return None
        # Validate that the required fields are present and non-empty.
        if not state.org_id or not state.api_url:
            return None
        return state
    except Exception:
        return None


def _do_pull_and_write(state: object, policy_path: Path, state_dir: Path, result: dict) -> None:
    """Worker target: pull policy from backend and write to disk.

    Writes results into *result* dict so the caller can inspect what
    happened. Keys: 'refreshed' (bool), 'error' (str or None).
    """
    try:
        from controlzero.enrollment import pull_policy
        bundle = pull_policy(state, state_dir=state_dir, timeout_s=POLICY_SYNC_TIMEOUT_S)
        if bundle is None:
            # 304 Not Modified: touch the file so mtime is refreshed.
            try:
                policy_path.touch()
            except OSError:
                pass
            result["refreshed"] = True
            result["error"] = None
            return
        # Write the bundle rules as YAML to the policy file.
        yaml_content = yaml.safe_dump(
            {
                "version": str(bundle.get("version", "1")),
                "rules": bundle.get("rules", []),
            },
            default_flow_style=False,
            allow_unicode=True,
        )
        # Atomic write: tmp + rename
        tmp = policy_path.with_suffix(".yaml.tmp")
        tmp.write_text(yaml_content, encoding="utf-8")
        tmp.replace(policy_path)
        result["refreshed"] = True
        result["error"] = None
    except Exception as exc:
        result["refreshed"] = False
        result["error"] = str(exc)


def _maybe_refresh_policy(
    policy_path: Path,
    state_dir: Path = GLOBAL_POLICY_DIR,
    threshold_s: float = POLICY_STALENESS_THRESHOLD_S,
    timeout_s: float = POLICY_SYNC_TIMEOUT_S,
) -> None:
    """If an ENROLLED machine's policy file is stale, sync in background.

    T103 (2026-05-12): the Bearer api_key refresh branch was removed
    here. api_key clients now go through ``Client(api_key=...)`` which
    reads the signed bundle cache and conditional-refreshes via
    ``hosted_policy.load_hosted_policy`` (If-None-Match etag). The CLI
    no longer clobbers ``~/.controlzero/policy.yaml`` from a hosted pull,
    because that destroyed user-edited content (customer report 2026-05-12).

    This function now serves only the enrollment-based path used by
    machines that ran ``controlzero login`` and persisted
    enrollment.json. If no enrollment state, returns immediately.

    Uses a background thread with a join timeout so the hook never stalls
    for longer than *timeout_s* seconds.
    """
    if not _is_policy_stale(policy_path, threshold_s):
        return

    state = _load_enrollment_state(state_dir)
    if state is None:
        return

    # Compute staleness for the warning message.
    try:
        age_min = int((time.time() - os.path.getmtime(policy_path)) / 60)
    except OSError:
        age_min = -1

    result: dict = {"refreshed": False, "error": None}
    worker = threading.Thread(
        target=_do_pull_and_write,
        args=(state, policy_path, state_dir, result),
        daemon=True,
    )
    worker.start()
    worker.join(timeout=timeout_s)

    if worker.is_alive():
        # Thread is still running (network slow). Warn and proceed.
        msg = "controlzero: policy sync timed out"
        if age_min >= 0:
            msg += f" (last sync {age_min} min ago)"
        msg += "; using cached version."
        click.echo(msg, err=True)
        return

    if not result["refreshed"] and result["error"]:
        msg = "controlzero: policy stale"
        if age_min >= 0:
            msg += f" (last sync {age_min} min ago)"
        msg += "; using cached version."
        click.echo(msg, err=True)


def _resolve_hook_policy(explicit: Optional[str]) -> Optional[Path]:
    """Find a policy file using the hook-time resolution order:

    1. Explicit --policy argument
    2. ./controlzero.yaml (per-project)
    3. ~/.controlzero/policy.yaml (global)
    """
    if explicit:
        p = Path(explicit)
        return p if p.exists() else None
    cwd = Path.cwd() / "controlzero.yaml"
    if cwd.exists():
        return cwd
    if GLOBAL_POLICY_PATH.exists():
        return GLOBAL_POLICY_PATH
    return None


def _policy_has_deny_rules(policy_path: Path) -> bool:
    """Check whether an existing policy file contains any active deny rules.

    Returns True if at least one uncommented deny rule exists. Returns False
    if the policy only has allow rules (or is empty/unparseable).
    """
    try:
        text = policy_path.read_text(encoding="utf-8")
        data = yaml.safe_load(text)
        if not isinstance(data, dict):
            return False
        rules = data.get("rules", [])
        if not isinstance(rules, list):
            return False
        for rule in rules:
            if isinstance(rule, dict) and "deny" in rule:
                return True
        return False
    except Exception:
        return False


def _extract_template_deny_comments(template_path: Path) -> list[str]:
    """Extract commented-out deny rule blocks from a template file.

    Returns a list of comment lines (including the '#') that contain deny
    examples. These are the lines the user WOULD get if they used --force.
    """
    lines = template_path.read_text(encoding="utf-8").splitlines()
    deny_lines: list[str] = []
    in_deny_block = False
    for line in lines:
        stripped = line.strip()
        if stripped.startswith("#") and "deny:" in stripped:
            in_deny_block = True
            deny_lines.append(line)
        elif in_deny_block and stripped.startswith("#") and stripped != "#":
            deny_lines.append(line)
        else:
            in_deny_block = False
    return deny_lines


def _merge_template_deny_rules(existing_path: Path, template_path: Path) -> str:
    """Merge deny rule examples from a template into an existing policy file.

    Inserts the template's commented-out deny rules just BEFORE the final
    allow-everything rule. Returns the merged text. Does not write to disk.
    """
    existing_text = existing_path.read_text(encoding="utf-8")
    template_text = template_path.read_text(encoding="utf-8")

    # Extract commented deny blocks from the template
    template_lines = template_text.splitlines()
    deny_sections: list[str] = []
    i = 0
    while i < len(template_lines):
        line = template_lines[i]
        stripped = line.strip()
        # Look for comment blocks that contain deny examples
        if stripped.startswith("#") and "DENY:" in stripped:
            section_lines = [line]
            i += 1
            while i < len(template_lines):
                next_line = template_lines[i]
                next_stripped = next_line.strip()
                # Section ends at the next section header or a non-comment active rule
                if next_stripped.startswith("# ==") and "ALLOW:" in next_stripped:
                    break
                if next_stripped and not next_stripped.startswith("#") and not next_stripped.startswith("-"):
                    break
                section_lines.append(next_line)
                i += 1
            section_text = "\n".join(section_lines)
            if "deny:" in section_text.lower():
                deny_sections.append(section_text)
            continue
        i += 1

    if not deny_sections:
        return existing_text

    # Find the allow-everything rule and insert before it
    existing_lines = existing_text.splitlines()
    insert_idx = None
    for idx, line in enumerate(existing_lines):
        stripped = line.strip()
        if "allow-everything" in stripped or (
            stripped.startswith("- id:") and "allow" in stripped.lower()
        ):
            insert_idx = idx
            break
        # Also catch bare allow rules that are the last rule
        if stripped == "- allow: '*'" or stripped == '- allow: "*"':
            insert_idx = idx
            break

    if insert_idx is None:
        # No allow-everything found; append at end
        insert_idx = len(existing_lines)

    merged_block = "\n".join(deny_sections)
    merged_lines = (
        existing_lines[:insert_idx]
        + ["", merged_block, ""]
        + existing_lines[insert_idx:]
    )
    return "\n".join(merged_lines) + "\n"


def _warn_no_deny_rules(agent_name: str, template_path: Path) -> None:
    """Emit a loud warning that the existing policy has no deny rules.

    Also shows what deny rules the template WOULD have added.
    """
    click.secho(
        f"WARNING: Your existing policy at {GLOBAL_POLICY_PATH} has NO deny rules.",
        fg="yellow",
        bold=True,
        err=True,
    )
    click.secho(
        f"The {agent_name} hook will ALLOW ALL tool calls. "
        "This may not be what you want.",
        fg="yellow",
        err=True,
    )
    click.echo("", err=True)
    click.echo(
        "Options:",
        err=True,
    )
    click.echo(
        f"  --force    Overwrite with the {agent_name} template",
        err=True,
    )
    click.echo(
        f"  --merge    Add the {agent_name} template's deny rules to your existing policy",
        err=True,
    )
    click.echo(
        f"  manual     Edit {GLOBAL_POLICY_PATH} and add deny rules yourself",
        err=True,
    )

    # Show what deny rules the template has (commented out)
    deny_comments = _extract_template_deny_comments(template_path)
    if deny_comments:
        click.echo("", err=True)
        click.echo(
            f"The {agent_name} template includes these deny examples:",
            err=True,
        )
        for line in deny_comments[:10]:
            click.echo(f"  {line}", err=True)


GLOBAL_CONFIG_PATH = GLOBAL_POLICY_DIR / "config.yaml"


def _validate_api_key(api_key: str) -> bool:
    """Return True if the API key has a valid cz_live_ or cz_test_ prefix."""
    return api_key.startswith("cz_live_") or api_key.startswith("cz_test_")


def _write_api_key_config(api_key: str) -> None:
    """Write the API key to ~/.controlzero/config.yaml.

    Permissions are enforced at 0600 on every write (Tier 0a hotfix
    2026-05-15). The directory is enforced at 0700. We do not trust the
    umask of the calling shell -- on a shared dev box (CI runner,
    multi-user workstation) a default umask of 0022 would leave the
    secret world-readable. Explicit chmod closes that hole.

    Windows: os.chmod on Windows only flips the read-only bit, not full
    POSIX permissions. The Windows code path falls back to setting the
    file's ACL to current-user-only via a separate helper (TODO Tier 0b
    if we see real Windows traffic; today the customer base is Mac +
    Linux per audit-log client_name distribution).
    """
    GLOBAL_POLICY_DIR.mkdir(parents=True, exist_ok=True)
    try:
        os.chmod(GLOBAL_POLICY_DIR, 0o700)
    except OSError:
        # Windows / FAT / read-only fs -- best effort.
        pass
    config_data: dict = {}
    if GLOBAL_CONFIG_PATH.exists():
        try:
            existing = yaml.safe_load(GLOBAL_CONFIG_PATH.read_text(encoding="utf-8"))
            if isinstance(existing, dict):
                config_data = existing
        except Exception:
            pass
    config_data["api_key"] = api_key
    GLOBAL_CONFIG_PATH.write_text(
        yaml.safe_dump(config_data, default_flow_style=False),
        encoding="utf-8",
    )
    try:
        os.chmod(GLOBAL_CONFIG_PATH, 0o600)
    except OSError:
        pass


def _prefetch_bundle(api_key: str) -> None:
    """Best-effort pre-warm of the hosted policy bundle at install time.

    Called by `controlzero install <agent> --api-key cz_...`. Doing the
    bundle pull now (a) surfaces an obvious install-time error if the
    api_key is wrong or the network is dead, instead of failing
    silently on the first hook call; and (b) eliminates the cold-start
    spike Claude Code customers see on their first PreToolUse hook
    after install.

    Never raises -- a failed pre-fetch must not block the install. If
    the pull fails, the first hook call will retry per the normal
    hosted-mode path; the user has already gotten an installer warning
    so they know to investigate.
    """
    try:
        from controlzero.hosted_policy import load_hosted_policy
        _local_source, parsed = load_hosted_policy(api_key)
        rule_count = 0
        try:
            rule_count = len((parsed or {}).get("rules", []) or [])
        except Exception:  # noqa: BLE001
            rule_count = 0
        click.echo(
            f"  Pre-fetched hosted policy ({rule_count} rule"
            f"{'s' if rule_count != 1 else ''}). First tool call will be fast."
        )
    except Exception as exc:  # noqa: BLE001
        # Common failures: auth (HostedAuthError -> wrong api_key),
        # network (HostedBootstrapError -> backend unreachable), or
        # tamper (bundle signature mismatch). Surface ALL of them in
        # the installer output so the user sees the problem now, not
        # later. We do not exit non-zero: install completes; first
        # hook call will retry and the user can re-run install once
        # they fix the env.
        click.echo("")
        click.echo(
            f"  WARNING: Could not pre-fetch hosted policy: {exc}",
            err=True,
        )
        click.echo(
            "  The install is complete. The SDK will retry on the "
            "first tool call. If this keeps failing, double-check the "
            "api_key + network reachability to https://api.controlzero.ai.",
            err=True,
        )


def _print_api_key_status(api_key: Optional[str]) -> None:
    """Print API key configuration status after install."""
    if api_key:
        click.echo("")
        click.echo("API key configured. Audit logs will sync to the Control Zero dashboard.")
        click.echo("View them at: https://app.controlzero.ai/audit")
    else:
        click.echo("")
        click.echo("Tip: Pass --api-key cz_live_xxx to sync audit logs to the dashboard.")


@cli.group()
def install():
    """Install controlzero into a coding agent (Claude Code, Cursor, etc)."""


@install.command("claude-code")
@click.option(
    "--force",
    "-f",
    is_flag=True,
    help="Overwrite existing global policy file if present.",
)
@click.option(
    "--merge",
    "-m",
    is_flag=True,
    help="Merge template deny rules into existing policy without overwriting.",
)
@click.option(
    "--settings",
    type=click.Path(),
    default=None,
    help="Path to Claude Code settings.json. Defaults to ~/.claude/settings.json",
)
@click.option(
    "--api-key",
    "-k",
    default=None,
    help="Control Zero API key (cz_live_* or cz_test_*). Enables audit log sync to the dashboard.",
)
def install_claude_code(force: bool, merge: bool, settings: Optional[str], api_key: Optional[str]):
    """Install controlzero as a Claude Code PreToolUse hook.

    Writes ~/.controlzero/policy.yaml from the claude-code template (idempotent
    unless --force is set) and merges a hook block into ~/.claude/settings.json.
    Existing hooks are preserved.
    """
    if api_key is not None:
        if not _validate_api_key(api_key):
            click.echo(
                "error: Invalid API key format. Must start with 'cz_live_' or 'cz_test_'.",
                err=True,
            )
            sys.exit(1)
        _write_api_key_config(api_key)
        _prefetch_bundle(api_key)

    template_path = TEMPLATE_DIR / "claude-code.yaml"
    if not template_path.exists():
        click.echo(f"error: claude-code template missing at {template_path}", err=True)
        sys.exit(1)

    # Step 1: write the global policy file
    GLOBAL_POLICY_DIR.mkdir(parents=True, exist_ok=True)
    if GLOBAL_POLICY_PATH.exists() and not force:
        if merge:
            # Merge template deny rules into existing policy
            merged_text = _merge_template_deny_rules(GLOBAL_POLICY_PATH, template_path)
            GLOBAL_POLICY_PATH.write_text(merged_text, encoding="utf-8")
            click.echo(
                f"Merged deny rules from claude-code template into {GLOBAL_POLICY_PATH}"
            )
        else:
            # Check if existing policy has deny rules; warn loudly if not
            if not _policy_has_deny_rules(GLOBAL_POLICY_PATH):
                _warn_no_deny_rules("claude-code", template_path)
            click.echo(
                f"Skipping policy write: {GLOBAL_POLICY_PATH} already exists "
                "(use --force to overwrite or --merge to add deny rules)."
            )
    else:
        GLOBAL_POLICY_PATH.write_text(
            template_path.read_text(encoding="utf-8"), encoding="utf-8"
        )
        click.echo(f"Wrote {GLOBAL_POLICY_PATH} (claude-code template)")

    # Step 2: merge into Claude Code settings.json
    settings_path = Path(settings) if settings else Path.home() / ".claude" / "settings.json"
    settings_path.parent.mkdir(parents=True, exist_ok=True)

    existing: dict = {}
    if settings_path.exists():
        try:
            existing = json.loads(settings_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as e:
            click.echo(
                f"error: {settings_path} is not valid JSON ({e}). "
                "Fix it manually or move it aside, then re-run.",
                err=True,
            )
            sys.exit(1)

    hooks = existing.setdefault("hooks", {})
    pre_tool = hooks.setdefault("PreToolUse", [])

    # Idempotency: replace any existing controlzero hook block, preserve others.
    # The hook subprocess resolves api_key from ~/.controlzero/config.yaml
    # (written by _write_api_key_config above) and falls back to
    # CONTROLZERO_API_KEY in the parent shell env. Embedding
    # `CONTROLZERO_API_KEY=cz_... controlzero hook-check` as a bash-style
    # env-prefix was a Windows-portability bug (PowerShell / cmd.exe cannot
    # parse the syntax) AND placed the cleartext key into settings.json on
    # disk. Both go away here. See 2026-05-12 incident.
    hook_command = "controlzero hook-check"
    new_block = {
        "matcher": "*",
        "hooks": [
            {
                "type": "command",
                "command": hook_command,
                "timeout": 5000,
            }
        ],
    }
    pre_tool[:] = [
        b for b in pre_tool
        if not (
            isinstance(b, dict)
            and any(
                isinstance(h, dict)
                and isinstance(h.get("command"), str)
                and "controlzero hook-check" in h.get("command", "")
                for h in b.get("hooks", [])
            )
        )
    ]
    pre_tool.append(new_block)

    settings_path.write_text(
        json.dumps(existing, indent=2) + "\n",
        encoding="utf-8",
    )
    click.echo(f"Updated {settings_path} (added PreToolUse hook)")
    click.echo("")
    click.echo("[Control Zero] Installed successfully.")
    click.echo("")
    click.echo("  Default policy: ALLOW ALL (every tool call is permitted and logged)")
    click.echo("  Add deny rules to block specific tools or patterns.")
    click.echo("")
    click.echo("Test it:")
    click.echo("  1. Open Claude Code in any project")
    click.echo("  2. Every tool call will show '[Control Zero] Allowed: <tool>'")
    click.echo("  3. Add deny rules, then watch blocked tools show '[Control Zero] <reason>'")
    click.echo("")
    click.echo(f"Edit your policy: {GLOBAL_POLICY_PATH}")
    click.echo(f"Audit log:        {GLOBAL_AUDIT_PATH}")
    _print_api_key_status(api_key)


# =============================================================================
# install gemini-cli
# =============================================================================
#
# Gemini CLI stores user-level config under ~/.gemini/settings.json. The
# pre-tool-call hook contract is modeled on Claude Code's: a command
# that receives the tool call on stdin and returns 0 to allow or
# non-zero to deny. We merge a `BeforeTool.hooks` entry so existing
# hooks are preserved.
#
# Ref: Gemini CLI settings.json schema (as of gemini-cli 0.5.x).

@install.command("gemini-cli")
@click.option(
    "--force",
    "-f",
    is_flag=True,
    help="Overwrite existing global policy file if present.",
)
@click.option(
    "--merge",
    "-m",
    is_flag=True,
    help="Merge template deny rules into existing policy without overwriting.",
)
@click.option(
    "--settings",
    type=click.Path(),
    default=None,
    help="Path to Gemini CLI settings.json. Defaults to ~/.gemini/settings.json",
)
@click.option(
    "--api-key",
    "-k",
    default=None,
    help="Control Zero API key (cz_live_* or cz_test_*). Enables audit log sync to the dashboard.",
)
def install_gemini_cli(force: bool, merge: bool, settings: Optional[str], api_key: Optional[str]):
    """Install controlzero as a Gemini CLI pre-tool-call hook.

    Writes ~/.controlzero/policy.yaml from the gemini-cli template
    (idempotent unless --force is set) and merges a hook block into
    ~/.gemini/settings.json. Existing hooks are preserved.
    """
    if api_key is not None:
        if not _validate_api_key(api_key):
            click.echo(
                "error: Invalid API key format. Must start with 'cz_live_' or 'cz_test_'.",
                err=True,
            )
            sys.exit(1)
        _write_api_key_config(api_key)
        _prefetch_bundle(api_key)

    template_path = TEMPLATE_DIR / "gemini-cli.yaml"
    if not template_path.exists():
        click.echo(f"error: gemini-cli template missing at {template_path}", err=True)
        sys.exit(1)

    # Step 1: write the global policy file
    GLOBAL_POLICY_DIR.mkdir(parents=True, exist_ok=True)
    if GLOBAL_POLICY_PATH.exists() and not force:
        if merge:
            merged_text = _merge_template_deny_rules(GLOBAL_POLICY_PATH, template_path)
            GLOBAL_POLICY_PATH.write_text(merged_text, encoding="utf-8")
            click.echo(
                f"Merged deny rules from gemini-cli template into {GLOBAL_POLICY_PATH}"
            )
        else:
            if not _policy_has_deny_rules(GLOBAL_POLICY_PATH):
                _warn_no_deny_rules("gemini-cli", template_path)
            click.echo(
                f"Skipping policy write: {GLOBAL_POLICY_PATH} already exists "
                "(use --force to overwrite or --merge to add deny rules)."
            )
    else:
        GLOBAL_POLICY_PATH.write_text(
            template_path.read_text(encoding="utf-8"), encoding="utf-8"
        )
        click.echo(f"Wrote {GLOBAL_POLICY_PATH} (gemini-cli template)")

    # Step 2: merge into Gemini CLI settings.json
    settings_path = Path(settings) if settings else Path.home() / ".gemini" / "settings.json"
    settings_path.parent.mkdir(parents=True, exist_ok=True)

    existing: dict = {}
    if settings_path.exists():
        try:
            existing = json.loads(settings_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as e:
            click.echo(
                f"error: {settings_path} is not valid JSON ({e}). "
                "Fix it manually or move it aside, then re-run.",
                err=True,
            )
            sys.exit(1)

    hooks_root = existing.setdefault("hooks", {})
    before_tool = hooks_root.setdefault("BeforeTool", [])

    # 1.5.2: api_key flows via ~/.controlzero/config.yaml (see
    # _write_api_key_config above). The legacy bash-only env-prefix
    # broke Windows; see the claude-code install path for the full
    # rationale.
    hook_command = "controlzero hook-check"

    # Gemini CLI expects a nested structure:
    #   { matcher: "regex", hooks: [{ type: "command", command: "...", timeout: N }] }
    new_block = {
        "matcher": ".*",
        "hooks": [
            {
                "type": "command",
                "command": hook_command,
                "timeout": 5000,
            }
        ],
    }
    # Idempotency: replace any existing controlzero hook block.
    before_tool[:] = [
        b
        for b in before_tool
        if not (
            isinstance(b, dict)
            and any(
                isinstance(h, dict) and "controlzero hook-check" in h.get("command", "")
                for h in (b.get("hooks") or [])
            )
            # Also remove old flat-format entries from prior versions
            and True
        )
        and not (
            isinstance(b, dict)
            and isinstance(b.get("command"), str)
            and "controlzero hook-check" in b.get("command", "")
        )
    ]
    before_tool.append(new_block)

    settings_path.write_text(
        json.dumps(existing, indent=2) + "\n",
        encoding="utf-8",
    )
    click.echo(f"Updated {settings_path} (added BeforeTool hook)")
    click.echo("")
    click.echo("[Control Zero] Installed successfully.")
    click.echo("")
    click.echo("  Default policy: ALLOW ALL (every tool call is permitted and logged)")
    click.echo("  Add deny rules to block specific tools or patterns.")
    click.echo("")
    click.echo("Test it:")
    click.echo("  1. Open Gemini CLI in any project: gemini")
    click.echo("  2. Every tool call will show '[Control Zero] Allowed: <tool>'")
    click.echo("  3. Add deny rules, then watch blocked tools show '[Control Zero] <reason>'")
    click.echo("")
    click.echo(f"Edit your policy: {GLOBAL_POLICY_PATH}")
    click.echo(f"Audit log:        {GLOBAL_AUDIT_PATH}")
    _print_api_key_status(api_key)


# =============================================================================
# install codex-cli
# =============================================================================
#
# Codex CLI (OpenAI) stores config under ~/.codex/config.toml. Codex
# does not expose a first-class hook API (as of 0.3.x), so we ship a
# small wrapper script that intercepts tool calls via the
# `tool_approval_policy` extension point: Codex calls out to an
# external reviewer command, gets JSON back, decides.
#
# Install writes:
#   ~/.controlzero/policy.yaml
#   ~/.codex/hooks/controlzero.sh     (wrapper that invokes hook-check)
#   appends a tool_approval_policy block to ~/.codex/config.toml
#
# If the user's config.toml already has a controlzero approval policy,
# it's left untouched (idempotent). The wrapper script is always
# rewritten so upgrades flow automatically.

@install.command("codex-cli")
@click.option(
    "--force",
    "-f",
    is_flag=True,
    help="Overwrite existing global policy file and config.toml block.",
)
@click.option(
    "--merge",
    "-m",
    is_flag=True,
    help="Merge template deny rules into existing policy without overwriting.",
)
@click.option(
    "--config",
    type=click.Path(),
    default=None,
    help="Path to Codex CLI config.toml. Defaults to ~/.codex/config.toml",
)
@click.option(
    "--api-key",
    "-k",
    default=None,
    help="Control Zero API key (cz_live_* or cz_test_*). Enables audit log sync to the dashboard.",
)
def install_codex_cli(force: bool, merge: bool, config: Optional[str], api_key: Optional[str]):
    """Install controlzero as a Codex CLI tool approval hook.

    Writes ~/.controlzero/policy.yaml from the codex-cli template
    (idempotent unless --force is set), drops a wrapper script at
    ~/.codex/hooks/controlzero.sh, and appends a
    `[tool_approval_policy]` block to ~/.codex/config.toml pointing at
    the wrapper.
    """
    if api_key is not None:
        if not _validate_api_key(api_key):
            click.echo(
                "error: Invalid API key format. Must start with 'cz_live_' or 'cz_test_'.",
                err=True,
            )
            sys.exit(1)
        _write_api_key_config(api_key)
        _prefetch_bundle(api_key)

    template_path = TEMPLATE_DIR / "codex-cli.yaml"
    if not template_path.exists():
        click.echo(f"error: codex-cli template missing at {template_path}", err=True)
        sys.exit(1)

    # Step 1: write the global policy file
    GLOBAL_POLICY_DIR.mkdir(parents=True, exist_ok=True)
    if GLOBAL_POLICY_PATH.exists() and not force:
        if merge:
            merged_text = _merge_template_deny_rules(GLOBAL_POLICY_PATH, template_path)
            GLOBAL_POLICY_PATH.write_text(merged_text, encoding="utf-8")
            click.echo(
                f"Merged deny rules from codex-cli template into {GLOBAL_POLICY_PATH}"
            )
        else:
            if not _policy_has_deny_rules(GLOBAL_POLICY_PATH):
                _warn_no_deny_rules("codex-cli", template_path)
            click.echo(
                f"Skipping policy write: {GLOBAL_POLICY_PATH} already exists "
                "(use --force to overwrite or --merge to add deny rules)."
            )
    else:
        GLOBAL_POLICY_PATH.write_text(
            template_path.read_text(encoding="utf-8"), encoding="utf-8"
        )
        click.echo(f"Wrote {GLOBAL_POLICY_PATH} (codex-cli template)")

    # Step 2: write hooks.json for Codex CLI.
    # Codex CLI reads hooks from ~/.codex/hooks.json (user-level) using
    # the PreToolUse event. Exit 0 = allow, exit 2 = block (stderr = reason).
    codex_dir = Path.home() / ".codex"
    codex_dir.mkdir(parents=True, exist_ok=True)
    hooks_json_path = codex_dir / "hooks.json"

    # 1.5.2: api_key flows via ~/.controlzero/config.yaml (see
    # _write_api_key_config above). The legacy bash-only env-prefix
    # broke Windows; see the claude-code install path for the full
    # rationale.
    hook_command = "controlzero hook-check"

    new_hook_entry = {
        "matcher": ".*",
        "hooks": [
            {
                "type": "command",
                "command": hook_command,
                "timeout": 5000,
            }
        ],
    }

    # Load existing hooks.json or create a new one
    existing_hooks: dict = {"hooks": {}}
    if hooks_json_path.exists():
        try:
            existing_hooks = json.loads(hooks_json_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            existing_hooks = {"hooks": {}}

    hooks_obj = existing_hooks.setdefault("hooks", {})
    pre_tool = hooks_obj.setdefault("PreToolUse", [])

    # Idempotency: remove any existing controlzero entries
    pre_tool[:] = [
        b for b in pre_tool
        if not (
            isinstance(b, dict)
            and any(
                isinstance(h, dict) and "controlzero hook-check" in h.get("command", "")
                for h in (b.get("hooks") or [])
            )
        )
    ]
    pre_tool.append(new_hook_entry)

    hooks_json_path.write_text(
        json.dumps(existing_hooks, indent=2) + "\n",
        encoding="utf-8",
    )
    click.echo(f"Wrote {hooks_json_path} (PreToolUse hook)")

    # Step 3: ensure codex_hooks feature is enabled in config.toml
    cfg_path = Path(config) if config else codex_dir / "config.toml"
    cfg_path.parent.mkdir(parents=True, exist_ok=True)
    existing_text = cfg_path.read_text(encoding="utf-8") if cfg_path.exists() else ""

    # Remove old tool_approval_policy blocks from prior versions
    old_marker = "# controlzero:tool_approval_policy"
    if old_marker in existing_text:
        lines = existing_text.splitlines(keepends=True)
        out: list = []
        skip = False
        for line in lines:
            if line.strip() == old_marker:
                skip = True
                continue
            if skip and line.strip() == "":
                skip = False
                continue
            if not skip:
                out.append(line)
        existing_text = "".join(out)
        click.echo("Removed legacy tool_approval_policy block from config.toml")

    # Add codex_hooks feature flag if not present
    feature_marker = "# controlzero:features"
    if "codex_hooks = true" not in existing_text:
        feature_block = (
            f"\n{feature_marker}\n"
            "[features]\n"
            "codex_hooks = true\n"
        )
        cfg_path.write_text(existing_text + feature_block, encoding="utf-8")
        click.echo(f"Updated {cfg_path} (enabled codex_hooks feature)")
    else:
        click.echo("codex_hooks already enabled in config.toml")
    click.echo("")
    click.echo("[Control Zero] Installed successfully.")
    click.echo("")
    click.echo("  Default policy: ALLOW ALL (every tool call is permitted and logged)")
    click.echo("  Add deny rules to block specific tools or patterns.")
    click.echo("")
    click.echo("Test it:")
    click.echo("  1. Open Codex CLI in any project: codex")
    click.echo("  2. Every tool call will show '[Control Zero] Allowed: <tool>'")
    click.echo("  3. Add deny rules, then watch blocked tools show '[Control Zero] <reason>'")
    click.echo("")
    click.echo(f"Edit your policy: {GLOBAL_POLICY_PATH}")
    click.echo(f"Audit log:        {GLOBAL_AUDIT_PATH}")
    _print_api_key_status(api_key)


# =============================================================================
# uninstall command group
# =============================================================================


@cli.group()
def uninstall():
    """Remove controlzero hooks from a coding agent."""


@uninstall.command("claude-code")
@click.option(
    "--settings",
    type=click.Path(),
    default=None,
    help="Path to Claude Code settings.json. Defaults to ~/.claude/settings.json",
)
def uninstall_claude_code(settings: Optional[str]):
    """Remove the controlzero PreToolUse hook from Claude Code.

    Reads ~/.claude/settings.json (or --settings), removes any PreToolUse
    hook block where the command is 'controlzero hook-check', and writes
    the cleaned JSON back. Policy and audit log files are preserved.
    """
    settings_path = Path(settings) if settings else Path.home() / ".claude" / "settings.json"

    if not settings_path.exists():
        click.echo("No controlzero hook found in Claude Code.")
        sys.exit(0)

    try:
        existing = json.loads(settings_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        click.echo(
            f"error: {settings_path} is not valid JSON ({e}). "
            "Fix it manually or move it aside, then re-run.",
            err=True,
        )
        sys.exit(1)

    hooks = existing.get("hooks", {})
    pre_tool = hooks.get("PreToolUse", [])

    original_count = len(pre_tool)
    cleaned = [
        b for b in pre_tool
        if not (
            isinstance(b, dict)
            and any(
                isinstance(h, dict)
                and isinstance(h.get("command"), str)
                and "controlzero hook-check" in h.get("command", "")
                for h in b.get("hooks", [])
            )
        )
    ]

    if len(cleaned) == original_count:
        click.echo("No controlzero hook found in Claude Code.")
        sys.exit(0)

    hooks["PreToolUse"] = cleaned
    settings_path.write_text(
        json.dumps(existing, indent=2) + "\n",
        encoding="utf-8",
    )
    click.echo(
        "Removed controlzero hook from Claude Code. "
        "Policy + audit log preserved at ~/.controlzero/"
    )


@uninstall.command("gemini-cli")
@click.option(
    "--settings",
    type=click.Path(),
    default=None,
    help="Path to Gemini CLI settings.json. Defaults to ~/.gemini/settings.json",
)
def uninstall_gemini_cli(settings: Optional[str]):
    """Remove the controlzero BeforeTool hook from Gemini CLI.

    Reads ~/.gemini/settings.json (or --settings), removes any BeforeTool
    entry where the command is 'controlzero hook-check', and writes the
    cleaned JSON back. Policy and audit log files are preserved.
    """
    settings_path = Path(settings) if settings else Path.home() / ".gemini" / "settings.json"

    if not settings_path.exists():
        click.echo("No controlzero hook found in Gemini CLI.")
        sys.exit(0)

    try:
        existing = json.loads(settings_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        click.echo(
            f"error: {settings_path} is not valid JSON ({e}). "
            "Fix it manually or move it aside, then re-run.",
            err=True,
        )
        sys.exit(1)

    hooks_root = existing.get("hooks", {})
    pre_call = hooks_root.get("BeforeTool", [])

    original_count = len(pre_call)
    cleaned = [
        b for b in pre_call
        # Remove new nested format entries
        if not (
            isinstance(b, dict)
            and any(
                isinstance(h, dict) and "controlzero hook-check" in h.get("command", "")
                for h in (b.get("hooks") or [])
            )
        )
        # Also remove old flat-format entries from prior versions
        and not (
            isinstance(b, dict)
            and isinstance(b.get("command"), str)
            and "controlzero hook-check" in b.get("command", "")
        )
    ]

    if len(cleaned) == original_count:
        click.echo("No controlzero hook found in Gemini CLI.")
        sys.exit(0)

    hooks_root["BeforeTool"] = cleaned
    settings_path.write_text(
        json.dumps(existing, indent=2) + "\n",
        encoding="utf-8",
    )
    click.echo(
        "Removed controlzero hook from Gemini CLI. "
        "Policy + audit log preserved at ~/.controlzero/"
    )


@uninstall.command("codex-cli")
@click.option(
    "--config",
    type=click.Path(),
    default=None,
    help="Path to Codex CLI config.toml. Defaults to ~/.codex/config.toml",
)
def uninstall_codex_cli(config: Optional[str]):
    """Remove the controlzero hooks from Codex CLI.

    Removes the controlzero PreToolUse entry from ~/.codex/hooks.json,
    cleans up legacy wrapper scripts and config.toml blocks from prior
    versions, and preserves policy + audit log files.
    """
    codex_dir = Path.home() / ".codex"
    cfg_path = Path(config) if config else codex_dir / "config.toml"
    hooks_json_path = codex_dir / "hooks.json"
    wrapper = codex_dir / "hooks" / "controlzero.sh"

    found_anything = False

    # Remove hooks.json entries (current format)
    if hooks_json_path.exists():
        try:
            hooks_data = json.loads(hooks_json_path.read_text(encoding="utf-8"))
            pre_tool = hooks_data.get("hooks", {}).get("PreToolUse", [])
            original_count = len(pre_tool)
            cleaned = [
                b for b in pre_tool
                if not (
                    isinstance(b, dict)
                    and any(
                        isinstance(h, dict) and "controlzero hook-check" in h.get("command", "")
                        for h in (b.get("hooks") or [])
                    )
                )
            ]
            if len(cleaned) < original_count:
                hooks_data["hooks"]["PreToolUse"] = cleaned
                hooks_json_path.write_text(
                    json.dumps(hooks_data, indent=2) + "\n", encoding="utf-8"
                )
                found_anything = True
        except (json.JSONDecodeError, KeyError):
            pass

    # Remove legacy wrapper script if it exists
    if wrapper.exists():
        wrapper.unlink()
        found_anything = True

    # Remove legacy marker blocks from config.toml
    if cfg_path.exists():
        existing_text = cfg_path.read_text(encoding="utf-8")
        for marker in ["# controlzero:tool_approval_policy", "# controlzero:features"]:
            if marker in existing_text:
                lines = existing_text.splitlines(keepends=True)
                out: list = []
                skip = False
                for line in lines:
                    if line.strip() == marker:
                        skip = True
                        continue
                    if skip and line.strip() == "":
                        skip = False
                        continue
                    if not skip:
                        out.append(line)
                existing_text = "".join(out)
                found_anything = True
        if found_anything:
            cfg_path.write_text(existing_text, encoding="utf-8")

    if not found_anything:
        click.echo("No controlzero hook found in Codex CLI.")
        sys.exit(0)

    click.echo(
        "Removed controlzero hook from Codex CLI. "
        "Policy + audit log preserved at ~/.controlzero/"
    )


# Register the `controlzero debug ...` subcommand group. Defined in
# controlzero.cli.debug_bundle to keep the bundle-inspection logic
# isolated from the existing CLI body. Today the group exposes the
# single `bundle` subcommand (T87, GH #392) but the group lives so
# we can attach future operator-facing debug helpers without
# growing main.py.
cli.add_command(debug_group)
cli.add_command(doctor_cmd)
cli.add_command(migrate_cmd)
cli.add_command(telemetry_group)


if __name__ == "__main__":
    cli()
