"""``controlzero debug bundle`` -- inspect SDK-loaded rules + simulate guard.

the deny-deny incident (T87, GH #392) burned ~3 hours of root-cause
work because the bundle on disk is encrypted+signed. ``cat`` returns
nothing legible; operators had to attach a debugger or ship the bundle
back to engineering. This module gives them a self-serve alternative.

What it does
============

1. Reads ``~/.controlzero/cache/bootstrap-<prefix>.json`` to get the
   project encryption key + signing public key.
2. Reads ``~/.controlzero/cache/bundle-<prefix>.bin`` for the raw blob.
3. Calls :func:`controlzero._internal.bundle.parse_bundle` to verify
   the signature, decrypt the AES-GCM payload, and decode the JSON.
4. Prints a human-readable summary (bundle id / created_at / expires_at,
   default_action / default_on_missing / default_on_tamper, every
   policy with its rules).
5. With ``--simulate "tool method args_json"``, runs the request
   through the same :class:`PolicyEvaluator` the SDK uses and prints
   the decision plus which rule matched and why.

Privacy
-------

The output is designed to be pasted into a support thread. The encryption
key, signing public key, and any API key are NEVER printed. A
``_redact_sensitive`` post-pass scrubs the rendered text against a
fixed-list of sensitive substrings before emit, so a future change to
this module cannot accidentally leak them.

The API-key prefix used to locate the cache files IS shown (12 chars,
e.g. ``cz_test_loca``) -- this is the same prefix that already appears
in CLI logs and is not sensitive.
"""

from __future__ import annotations

import base64
import json
import os
import re
import sys
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

import click
import yaml

from controlzero._internal.bundle import (
    BundleFormatError,
    BundleVerificationError,
    parse_bundle,
    translate_to_local_policy,
)
from controlzero._internal.enforcer import PolicyEvaluator
from controlzero.policy_loader import load_policy

# --- Paths ----------------------------------------------------------------

CACHE_DIR = Path.home() / ".controlzero" / "cache"
CONFIG_DIR = Path.home() / ".controlzero"
CONFIG_PATH = CONFIG_DIR / "config.yaml"

# Length of the API-key prefix used in cache filenames. Mirrors
# hosted_policy._key_scope() so the two stay in lockstep. If that
# function changes, this constant should change with it.
_KEY_SCOPE_LEN = 12


# --- Privacy / redaction helpers -----------------------------------------


_SENSITIVE_KEY_LABELS = (
    "project_encryption_key_b64",
    "encryption_key_b64",
    "signing_pubkey_hex",
    "signing_pub_key_hex",
)


def _redact_sensitive(text: str, secrets: list[str]) -> str:
    """Replace any literal occurrence of a secret in *text* with ``REDACTED``.

    ``secrets`` is the list of literal byte/hex/base64 strings that must
    never appear in CLI output. We also strip the JSON keys that name
    them in case a future caller hands us a dict that still carries
    them. Belt-and-braces -- the call site never embeds them in the
    first place; this is the safety net.
    """
    out = text
    for s in secrets:
        if s and len(s) >= 8:
            out = out.replace(s, "REDACTED")
    return out


# --- Cache discovery ------------------------------------------------------


@dataclass
class CacheLocation:
    """Resolved on-disk paths for an API-key prefix."""

    prefix: str
    bootstrap_path: Path
    bundle_path: Path


def _resolve_api_key() -> Optional[str]:
    """Return the API key from env or config.yaml, or None."""
    key = os.environ.get("CONTROLZERO_API_KEY", "").strip()
    if key:
        return key
    if CONFIG_PATH.exists():
        try:
            cfg = yaml.safe_load(CONFIG_PATH.read_text(encoding="utf-8"))
            if isinstance(cfg, dict):
                ck = cfg.get("api_key")
                if isinstance(ck, str) and ck.strip():
                    return ck.strip()
        except Exception:  # noqa: BLE001
            return None
    return None


def _api_key_prefix(api_key: str) -> str:
    """Match ``hosted_policy._key_scope`` -- first 12 chars, slashes/dots replaced."""
    if not api_key:
        return "unknown"
    return api_key[:_KEY_SCOPE_LEN].replace("/", "_").replace(".", "_")


def _resolve_cache_for_prefix(prefix: str) -> CacheLocation:
    return CacheLocation(
        prefix=prefix,
        bootstrap_path=CACHE_DIR / f"bootstrap-{prefix}.json",
        bundle_path=CACHE_DIR / f"bundle-{prefix}.bin",
    )


def _autodetect_cache() -> Optional[CacheLocation]:
    """Pick a single bootstrap+bundle pair under ``CACHE_DIR``.

    Used when the operator did not specify ``--api-key-prefix`` and we
    cannot find an API key in env / config. Returns the unique pair
    when there is exactly one; returns None when there are zero or
    several (caller surfaces a helpful error in either case).
    """
    if not CACHE_DIR.exists():
        return None
    bootstraps = sorted(CACHE_DIR.glob("bootstrap-*.json"))
    if len(bootstraps) != 1:
        return None
    name = bootstraps[0].name  # bootstrap-<prefix>.json
    prefix = name[len("bootstrap-") : -len(".json")]
    return _resolve_cache_for_prefix(prefix)


# --- Bundle load ----------------------------------------------------------


@dataclass
class LoadedBundle:
    payload: dict
    header_schema_version: int
    header_created_at: int
    header_policy_count: int


def _load_bootstrap_keys(path: Path) -> tuple[bytes, bytes, dict]:
    """Return ``(encryption_key, signing_pubkey, raw_metadata)``.

    ``raw_metadata`` strips the secret-bearing fields so callers can
    surface the safe metadata (project_id, org_id, key_version)
    without having to re-parse the file.
    """
    if not path.exists():
        raise FileNotFoundError(str(path))
    data = json.loads(path.read_text(encoding="utf-8"))
    enc_b64 = data.get("project_encryption_key_b64")
    sig_hex = data.get("signing_pubkey_hex")
    if not enc_b64 or not sig_hex:
        raise ValueError(
            f"bootstrap file missing required fields: {path}"
        )
    enc = base64.b64decode(enc_b64)
    sig = bytes.fromhex(sig_hex)
    safe_meta = {
        k: v
        for k, v in data.items()
        if k not in _SENSITIVE_KEY_LABELS
    }
    return enc, sig, safe_meta


def _load_bundle_blob(path: Path) -> bytes:
    if not path.exists():
        raise FileNotFoundError(str(path))
    return path.read_bytes()


# --- Pretty-print --------------------------------------------------------


def _fmt_unix(ts) -> str:
    """Format a unix timestamp (seconds, int|float|str) as ISO-8601 UTC."""
    if ts is None or ts == "" or ts == 0:
        return "(none)"
    try:
        ts_int = int(ts)
        return datetime.fromtimestamp(ts_int, tz=timezone.utc).isoformat()
    except (TypeError, ValueError):
        return str(ts)


def _print_header(
    out,
    payload: dict,
    schema_version: int,
    header_created_at: int,
    safe_bootstrap_meta: dict,
    cache: CacheLocation,
):
    bundle_id = payload.get("bundle_id") or payload.get("id") or "(none)"
    created_at = payload.get("created_at") or header_created_at
    expires_at = payload.get("expires_at")
    default_action = payload.get("default_action") or "(unset)"
    default_on_missing = payload.get("default_on_missing") or "(unset)"
    default_on_tamper = payload.get("default_on_tamper") or "(unset)"
    project_id = safe_bootstrap_meta.get("project_id", "(unknown)")
    org_id = safe_bootstrap_meta.get("org_id", "(unknown)")
    key_version = safe_bootstrap_meta.get("key_version", "(unknown)")

    click.echo("Control Zero -- bundle on disk", file=out)
    click.echo("", file=out)
    click.echo(f"  cache prefix      : {cache.prefix}", file=out)
    click.echo(f"  bootstrap path    : {cache.bootstrap_path}", file=out)
    click.echo(f"  bundle path       : {cache.bundle_path}", file=out)
    click.echo(f"  project_id        : {project_id}", file=out)
    click.echo(f"  org_id            : {org_id}", file=out)
    click.echo(f"  key_version       : {key_version}", file=out)
    click.echo("", file=out)
    click.echo(f"  schema_version    : {schema_version}", file=out)
    click.echo(f"  bundle_id         : {bundle_id}", file=out)
    click.echo(f"  created_at        : {_fmt_unix(created_at)}", file=out)
    click.echo(f"  expires_at        : {_fmt_unix(expires_at)}", file=out)
    click.echo(f"  default_action    : {default_action}", file=out)
    click.echo(f"  default_on_missing: {default_on_missing}", file=out)
    click.echo(f"  default_on_tamper : {default_on_tamper}", file=out)


def _print_policies(out, payload: dict):
    policies = payload.get("policies") or []
    click.echo("", file=out)
    click.echo(f"Policies ({len(policies)})", file=out)
    if not policies:
        click.echo("  (none -- empty bundle)", file=out)
        return
    for i, pol in enumerate(policies):
        if not isinstance(pol, dict):
            click.echo(f"  [{i}] (skipped, not a mapping)", file=out)
            continue
        pid = pol.get("id") or "(no id)"
        name = pol.get("name") or "(no name)"
        version = pol.get("version") or pol.get("policy_version") or "(no version)"
        is_enabled = pol.get("is_enabled")
        if is_enabled is None:
            is_enabled_s = "(unset)"
        else:
            is_enabled_s = "true" if is_enabled else "false"
        priority = pol.get("priority", "(unset)")
        click.echo("", file=out)
        click.echo(f"  policy {i}", file=out)
        click.echo(f"    id        : {pid}", file=out)
        click.echo(f"    name      : {name}", file=out)
        click.echo(f"    version   : {version}", file=out)
        click.echo(f"    is_enabled: {is_enabled_s}", file=out)
        click.echo(f"    priority  : {priority}", file=out)
        rules_raw = pol.get("rules")
        if isinstance(rules_raw, dict):
            rule_list = list(rules_raw.values())
        elif isinstance(rules_raw, list):
            rule_list = rules_raw
        else:
            rule_list = []
        click.echo(f"    rules     : {len(rule_list)}", file=out)
        for j, rule in enumerate(rule_list):
            if not isinstance(rule, dict):
                continue
            rid = rule.get("id") or f"(rule-{j})"
            effect = rule.get("effect") or "(unset)"
            principals = rule.get("principals") or rule.get("subjects") or []
            actions = rule.get("actions")
            if actions is None:
                # Backwards-compat singular fallthrough
                a = rule.get("action") or rule.get("tool") or rule.get("pattern")
                actions = [a] if a else []
            resources = rule.get("resources") or rule.get("resource") or []
            if isinstance(resources, str):
                resources = [resources]
            conditions = rule.get("conditions") or rule.get("when") or {}
            click.echo(f"      rule {j}", file=out)
            click.echo(f"        id        : {rid}", file=out)
            click.echo(f"        effect    : {effect}", file=out)
            click.echo(f"        principals: {list(principals)}", file=out)
            click.echo(f"        actions   : {list(actions)}", file=out)
            click.echo(f"        resources : {list(resources)}", file=out)
            click.echo(f"        conditions: {dict(conditions)}", file=out)


# --- Simulate ------------------------------------------------------------


_SIMULATE_RE = re.compile(r"^\s*(\S+)\s+(\S+)\s*(.*)$")


def _parse_simulate(text: str) -> tuple[str, str, dict]:
    """Parse ``"tool method [args_json | k=v k=v ...]"``.

    Two arg shapes are accepted:

    1. A single JSON object, e.g. ``{"sql": "SELECT id FROM orders"}``.
    2. A series of ``key=value`` pairs separated by whitespace.

    For shape (2), values are allowed to contain spaces -- the parser
    runs left-to-right, splits at each ``key=`` boundary using the
    next ``key=`` as a terminator, and treats everything in between
    as the value. This means ``sql=SELECT id FROM orders foo=bar``
    parses as ``{"sql": "SELECT id FROM orders", "foo": "bar"}``,
    matching what an operator copy-pastes from a SQL log line.

    Returns ``(tool, method, args_dict)``.
    """
    m = _SIMULATE_RE.match(text or "")
    if not m:
        raise ValueError(
            "--simulate must be 'tool method [args_json | key=value ...]'"
        )
    tool = m.group(1)
    method = m.group(2)
    rest = (m.group(3) or "").strip()

    if not rest:
        return tool, method, {}

    # JSON object?
    if rest.startswith("{"):
        try:
            args = json.loads(rest)
        except json.JSONDecodeError as exc:
            raise ValueError(f"--simulate args is not valid JSON: {exc}") from exc
        if not isinstance(args, dict):
            raise ValueError("--simulate args JSON must be an object")
        return tool, method, args

    # k=v pairs. Values may contain whitespace -- we tokenize by
    # finding key boundaries (``[A-Za-z_][\w-]*=``) and slicing the
    # input between them. This lets ``sql=SELECT id FROM orders``
    # parse as a single value rather than choking on the spaces.
    boundary = re.compile(r"(?:^|\s)([A-Za-z_][\w-]*)=")
    matches = list(boundary.finditer(rest))
    if not matches:
        raise ValueError(
            f"--simulate args {rest!r} is not 'key=value ...' or JSON"
        )
    if matches[0].start() != 0 and rest[: matches[0].start()].strip():
        # Leading text before the first key= is not a recognized form.
        raise ValueError(
            f"--simulate args {rest!r} has leading text before the first key="
        )

    args: dict = {}
    for i, m_kv in enumerate(matches):
        key = m_kv.group(1)
        value_start = m_kv.end()
        value_end = matches[i + 1].start() if i + 1 < len(matches) else len(rest)
        value = rest[value_start:value_end].strip()
        args[key] = value
    return tool, method, args


def _simulate_decision(payload: dict, tool: str, method: str, args: dict):
    """Run *tool/method/args* through the same evaluator the SDK uses."""
    local_dict = translate_to_local_policy(payload)
    parsed = load_policy(local_dict)
    evaluator = PolicyEvaluator(
        rules=parsed.rules,
        default_action=parsed.settings.default_action,
    )
    return evaluator.evaluate(tool, method=method, args=args)


def _print_simulation(out, decision, tool: str, method: str, args: dict):
    click.echo("", file=out)
    click.echo("Simulation", file=out)
    click.echo(f"  tool   : {tool}", file=out)
    click.echo(f"  method : {method}", file=out)
    click.echo(f"  args   : {args}", file=out)
    click.echo("", file=out)
    color = "green" if decision.allowed else ("red" if decision.denied else "yellow")
    click.secho(
        f"  DECISION    : {decision.effect.upper()}",
        file=out,
        fg=color,
        bold=True,
    )
    click.echo(f"  reason_code : {decision.reason_code or '(none)'}", file=out)
    click.echo(f"  policy_id   : {decision.policy_id or '(no rule matched)'}", file=out)
    click.echo(f"  reason      : {decision.reason or '(none)'}", file=out)
    click.echo(f"  rules eval'd: {decision.evaluated_rules}", file=out)


# --- Click wiring --------------------------------------------------------


@click.group("debug")
def debug_group():
    """Operator-facing debug commands.

    Sub-commands:

      bundle    Inspect the SDK-loaded policy bundle on disk + simulate a guard call.
    """


@debug_group.command("bundle")
@click.option(
    "--api-key-prefix",
    default=None,
    help=(
        "Override the cache prefix to inspect (e.g. 'cz_test_loca'). "
        "Defaults to the prefix derived from CONTROLZERO_API_KEY in env "
        "or ~/.controlzero/config.yaml."
    ),
)
@click.option(
    "--simulate",
    default=None,
    help=(
        'Optional: simulate a guard call. Format: "tool method args" where '
        '"args" is either a JSON object or a series of key=value pairs. '
        'Example: --simulate "database read sql=SELECT id FROM orders"'
    ),
)
def debug_bundle_cmd(api_key_prefix: Optional[str], simulate: Optional[str]):
    """Inspect the SDK's local policy bundle + optionally simulate a guard call.

    The bundle on disk is encrypted+signed, so ``cat`` returns nothing
    useful. This command reads the matching bootstrap file, verifies the
    signature, decrypts the bundle, and prints every policy and rule
    in human-readable form. Pair it with ``--simulate`` to run a request
    through the same evaluator the SDK uses.

    The output is designed to be pasted into a support thread and never
    contains the project encryption key, signing public key, or your
    API key.
    """
    # 1. Resolve the cache pair to inspect.
    cache: Optional[CacheLocation] = None
    if api_key_prefix:
        cache = _resolve_cache_for_prefix(api_key_prefix)
    else:
        api_key = _resolve_api_key()
        if api_key:
            cache = _resolve_cache_for_prefix(_api_key_prefix(api_key))
        else:
            cache = _autodetect_cache()

    if cache is None:
        click.echo(
            "error: no API key found and no single bundle in cache.",
            err=True,
        )
        click.echo(
            "  Set CONTROLZERO_API_KEY=cz_live_... or pass --api-key-prefix.",
            err=True,
        )
        click.echo(f"  Looked under: {CACHE_DIR}", err=True)
        sys.exit(1)

    # 2. Load bootstrap (keys + safe metadata).
    try:
        enc_key, sig_key, safe_meta = _load_bootstrap_keys(cache.bootstrap_path)
    except FileNotFoundError:
        click.echo(
            f"error: bootstrap file not found: {cache.bootstrap_path}",
            err=True,
        )
        click.echo(
            "  The SDK creates this on first hosted-policy fetch. "
            "Trigger one by running any cz.guard() call against your project, "
            "or run `controlzero policy-pull`.",
            err=True,
        )
        sys.exit(2)
    except (ValueError, OSError, json.JSONDecodeError) as exc:
        click.echo(
            f"error: bootstrap file unreadable ({exc}): {cache.bootstrap_path}",
            err=True,
        )
        sys.exit(2)

    # 3. Load and parse the bundle.
    try:
        blob = _load_bundle_blob(cache.bundle_path)
    except FileNotFoundError:
        click.echo(
            f"error: bundle file not found: {cache.bundle_path}",
            err=True,
        )
        click.echo(
            "  The SDK writes this alongside the bootstrap on the first "
            "successful policy pull. Run `controlzero policy-pull` or any "
            "cz.guard() call to populate it.",
            err=True,
        )
        sys.exit(2)
    except OSError as exc:
        click.echo(
            f"error: cannot read bundle file ({exc}): {cache.bundle_path}",
            err=True,
        )
        sys.exit(2)

    try:
        parsed = parse_bundle(blob, enc_key, sig_key)
    except BundleVerificationError as exc:
        click.echo(
            f"error: bundle signature/decrypt failed: {exc}",
            err=True,
        )
        click.echo(
            "  This usually means the cached bundle was rotated server-side. "
            "Run `controlzero policy-pull` to refresh.",
            err=True,
        )
        sys.exit(3)
    except BundleFormatError as exc:
        click.echo(f"error: bundle malformed: {exc}", err=True)
        sys.exit(3)

    # 4. Render. We accumulate into a buffer, scrub against the literal
    #    secret strings, then emit. The call site never embeds those
    #    strings; this scrub is the safety net so a future change to
    #    _print_header / _print_policies can never leak them.
    import io

    buf = io.StringIO()
    _print_header(
        buf,
        parsed.payload,
        parsed.header.schema_version,
        parsed.header.created_at,
        safe_meta,
        cache,
    )
    _print_policies(buf, parsed.payload)

    if simulate:
        try:
            tool, method, args = _parse_simulate(simulate)
        except ValueError as exc:
            click.echo(f"error: {exc}", err=True)
            sys.exit(2)
        decision = _simulate_decision(parsed.payload, tool, method, args)
        _print_simulation(buf, decision, tool, method, args)

    rendered = buf.getvalue()
    enc_b64_literal = base64.b64encode(enc_key).decode("ascii")
    sig_hex_literal = sig_key.hex()
    api_key_literal = os.environ.get("CONTROLZERO_API_KEY", "")
    secrets = [enc_b64_literal, sig_hex_literal]
    if api_key_literal:
        secrets.append(api_key_literal)
    rendered = _redact_sensitive(rendered, secrets)
    click.echo(rendered, nl=False)
    if not rendered.endswith("\n"):
        click.echo("")
