"""API key redaction + leak-detection helpers (Tier 0a hotfix 2026-05-15).

Single source of truth for:

1. Detecting `cz_(live|test)_*` patterns in arbitrary text (used by
   `controlzero doctor` to scan agent settings files + the cross-SDK
   contract test that fails the CI on any leak surface).
2. Redacting a full key to a last-4 form for display in CLI output
   (`cz_live_***aaaaa`). Matches the gh CLI / Stripe CLI convention.

These helpers MUST stay pure (no I/O, no logging) so the contract test
that depends on `find_key_leaks` can run in a sandbox without touching
the user's actual filesystem.
"""

from __future__ import annotations

import re
from typing import Iterable, List, NamedTuple

# A controlzero API key is 8-char prefix (cz_live_ / cz_test_) + 64 hex
# characters in production. We also accept shorter trailing alphanumerics
# so legacy short-form test keys (cz_test_localdev_...) are caught.
# The pattern is deliberately greedy on the suffix so we catch:
#   cz_live_aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa
#   cz_test_localdev_000000000000000000000000
#   cz_test_xxxxxxxx (rarer, but valid)
# but stops at a non-alphanumeric so we don't gobble surrounding markup.
_KEY_PATTERN = re.compile(r"cz_(live|test)_[A-Za-z0-9_]{4,}")


class KeyMatch(NamedTuple):
    """One match from `find_key_leaks`. The `key` field is the FULL
    matched substring; callers that surface this in customer output
    must run it through `redact_key` first."""

    start: int
    end: int
    key: str
    line_number: int


def find_key_leaks(text: str) -> List[KeyMatch]:
    """Return every `cz_(live|test)_*` substring in `text`.

    Used by:
    - `controlzero doctor` to scan ~/.claude/settings.json etc.
    - The cross-SDK contract test to fail the PR on any leak.
    - `controlzero migrate` to identify which entries to rewrite.

    Pure function. No I/O. Deterministic. Safe to call on arbitrary
    untrusted input (no regex catastrophic backtracking; pattern is
    linear).
    """
    matches: List[KeyMatch] = []
    if not text:
        return matches
    for m in _KEY_PATTERN.finditer(text):
        # Compute the 1-indexed line number so doctor output reads
        # like a compiler error: `foo.json:42:5`. Counts newlines
        # from start of text to the match start.
        line_number = text.count("\n", 0, m.start()) + 1
        matches.append(
            KeyMatch(
                start=m.start(),
                end=m.end(),
                key=m.group(0),
                line_number=line_number,
            )
        )
    return matches


def redact_key(key: str) -> str:
    """Convert `cz_live_aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa`
    to `cz_live_***aaaaa` (last-5 of the secret payload).

    The prefix (`cz_live_` / `cz_test_`) is preserved so the mode is
    still readable: ops can tell at a glance which key family this
    is. The last 5 hex chars are kept so two different keys are
    distinguishable in support tickets without exposing enough to
    reconstruct the key (5 hex chars = 20 bits = 1M combinations,
    not enough to brute-force back to the full key but enough for a
    human to disambiguate "is this customer A's key or customer B's key").

    Returns the input verbatim if it doesn't match the expected shape,
    so caller-side `print(redact_key(maybe_key))` is always safe.
    """
    stripped = key.strip()
    m = _KEY_PATTERN.fullmatch(stripped)
    if not m:
        return key
    mode = m.group(1)  # 'live' or 'test'
    last5 = stripped[-5:] if len(stripped) >= 5 else stripped
    return f"cz_{mode}_***{last5}"


def redact_text(text: str) -> str:
    """Apply `redact_key` to every `cz_(live|test)_*` match inside an
    arbitrary string.

    Used to scrub log lines, error messages, and stderr before the SDK
    prints them. Cheaper than wiring per-call-site escapes; safer too
    because the redaction is centralized.
    """

    def _replace(m: re.Match[str]) -> str:
        return redact_key(m.group(0))

    return _KEY_PATTERN.sub(_replace, text)


# Convenience: scan a list of file paths, return a flat list of
# (path, KeyMatch) pairs for everything found. doctor + migrate both
# consume this.
def scan_files(paths: Iterable[str]) -> List[tuple[str, KeyMatch]]:
    """Open each path, scan for key leaks, return matches with file
    path attached. Missing files / unreadable files are silently
    skipped -- the caller (doctor) handles "did we find the agent
    config at all" via a separate codepath.
    """
    import pathlib

    out: List[tuple[str, KeyMatch]] = []
    for p in paths:
        path = pathlib.Path(p).expanduser()
        if not path.exists():
            continue
        try:
            content = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        for match in find_key_leaks(content):
            out.append((str(path), match))
    return out
