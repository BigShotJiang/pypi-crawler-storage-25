"""controlzero telemetry consent: opt-IN, transparent, user-visible.

Tier 0a hotfix piece 5 (#174). Per the user's privacy mandate
2026-05-14: "we need to be transparent and give the users the
opportunity to decide and show them we value their privacy."

Three settings, all stored in ~/.controlzero/telemetry.yaml:

- `full`     -- full anonymized telemetry: SDK version, command
                used, success / error outcome, duration. Includes a
                stable random device ID so we can track trends per
                machine. No code, file paths, API keys, or tool
                arguments are sent.

- `anonymous` -- counter-only: we increment a "someone ran a
                 controlzero command" counter. No device ID. No
                 way to associate two commands with the same user.

- `off`      -- nothing is sent. The user opted out completely.

Default is `off`. The consent prompt fires once, the first time the
user runs any controlzero command that needs the network. The
choice persists. Users can change the choice any time with
`controlzero telemetry [full|anonymous|off]` or by editing
~/.controlzero/telemetry.yaml directly.

We never send anything at all until the user has explicitly chosen.
A first-time user whose machine has no telemetry.yaml file is
treated as `off` until they answer.
"""

from __future__ import annotations

import os
import secrets
import sys
from pathlib import Path
from typing import Dict, Literal, Optional

import click
import yaml


TelemetryMode = Literal["full", "anonymous", "off", "unset"]

_TELEMETRY_PATH = Path.home() / ".controlzero" / "telemetry.yaml"


def _read_state() -> Dict[str, str]:
    """Read the persisted state. Empty dict on first run."""
    if not _TELEMETRY_PATH.exists():
        return {}
    try:
        return yaml.safe_load(_TELEMETRY_PATH.read_text(encoding="utf-8")) or {}
    except (OSError, yaml.YAMLError):
        return {}


def _write_state(state: Dict[str, str]) -> None:
    """Persist state with the same 0o700 / 0o600 hygiene as config.yaml."""
    _TELEMETRY_PATH.parent.mkdir(parents=True, exist_ok=True)
    try:
        os.chmod(_TELEMETRY_PATH.parent, 0o700)
    except OSError:
        pass
    _TELEMETRY_PATH.write_text(
        yaml.safe_dump(state, default_flow_style=False),
        encoding="utf-8",
    )
    try:
        os.chmod(_TELEMETRY_PATH, 0o600)
    except OSError:
        pass


def get_mode() -> TelemetryMode:
    """Resolve the current telemetry mode, in precedence order:

    1. CONTROLZERO_TELEMETRY env var (off/full/anonymous) -- escape
       hatch for shared machines.
    2. ~/.controlzero/telemetry.yaml mode field.
    3. Default: "unset" -- meaning we haven't asked yet, so do
       nothing while we wait for the user to answer.
    """
    env = os.environ.get("CONTROLZERO_TELEMETRY", "").strip().lower()
    if env in ("off", "false", "no", "0", "disabled"):
        return "off"
    if env in ("full", "anonymous"):
        return env  # type: ignore[return-value]

    state = _read_state()
    mode = state.get("mode", "unset")
    if mode in ("full", "anonymous", "off"):
        return mode  # type: ignore[return-value]
    return "unset"


def get_device_id() -> Optional[str]:
    """Return the per-machine stable random ID for `full` mode, or
    None if the user is not in `full` mode. Lazily generated on
    first use; persisted to telemetry.yaml.
    """
    if get_mode() != "full":
        return None
    state = _read_state()
    did = state.get("device_id")
    if did:
        return did
    did = "cz_dev_" + secrets.token_hex(16)
    state["device_id"] = did
    _write_state(state)
    return did


def set_mode(mode: TelemetryMode) -> None:
    """Persist a new mode. Wipes the device_id when leaving `full`."""
    state = _read_state()
    state["mode"] = mode
    if mode != "full":
        state.pop("device_id", None)
    _write_state(state)


def prompt_if_unset() -> TelemetryMode:
    """If we haven't asked the user yet, ask now. Returns the
    resulting mode. Idempotent: subsequent calls return the saved
    choice without re-prompting.

    Called from any CLI command that emits telemetry. Designed so a
    non-interactive shell (CI, piped input) never prompts -- it
    silently leaves the mode as `unset`, which behaves like `off`.
    """
    mode = get_mode()
    if mode != "unset":
        return mode

    if not sys.stdin.isatty() or not sys.stdout.isatty():
        # Non-interactive: don't prompt, don't enable. Stay quiet.
        return "unset"

    click.echo("")
    click.echo("Control Zero would like to collect anonymous usage telemetry.")
    click.echo("")
    click.echo("  - SDK + CLI version")
    click.echo("  - Which commands you run (e.g. `controlzero install claude-code`)")
    click.echo("  - Success or error outcome + duration")
    click.echo("")
    click.echo("We never send:")
    click.echo("  - Your API key or any credentials")
    click.echo("  - Source code, file paths, or tool arguments")
    click.echo("  - Audit log contents")
    click.echo("")
    click.echo("Pick one:")
    click.echo("  [1] full       (stable device ID; helps us debug trends)")
    click.echo("  [2] anonymous  (counter only; no device ID)")
    click.echo("  [3] off        (nothing is ever sent)")
    click.echo("")
    choice = click.prompt(
        "Your choice",
        type=click.Choice(["1", "2", "3"], case_sensitive=False),
        default="3",
        show_default=True,
    )
    mapping: Dict[str, TelemetryMode] = {
        "1": "full",
        "2": "anonymous",
        "3": "off",
    }
    new_mode: TelemetryMode = mapping[choice]
    set_mode(new_mode)

    click.echo(f"Saved {new_mode} to {_TELEMETRY_PATH}. Change any time with "
               f"`controlzero telemetry [full|anonymous|off]`.")
    return new_mode


# -----------------------------------------------------------------------------
# CLI surface. `controlzero telemetry` shows current mode; subcommands
# let the user change without manually editing the YAML.
# -----------------------------------------------------------------------------


@click.group("telemetry", invoke_without_command=True)
@click.pass_context
def telemetry_group(ctx: click.Context) -> None:
    """Manage anonymous SDK telemetry.

    Run `controlzero telemetry` with no args to see your current mode.
    Run `controlzero telemetry off` to opt out.
    """
    if ctx.invoked_subcommand is None:
        mode = get_mode()
        click.echo(f"Current mode: {mode}")
        if mode == "unset":
            click.echo("(no choice saved -- the SDK is silent until you pick one)")
        if mode == "full":
            click.echo(f"Device ID: {get_device_id()}")
        click.echo(f"Path: {_TELEMETRY_PATH}")


@telemetry_group.command("full")
def telemetry_full() -> None:
    """Opt in to full anonymous telemetry (with stable device ID)."""
    set_mode("full")
    click.echo("Telemetry: full. Thank you -- this helps us spot regressions.")


@telemetry_group.command("anonymous")
def telemetry_anonymous() -> None:
    """Counter-only telemetry. No device ID."""
    set_mode("anonymous")
    click.echo("Telemetry: anonymous. Counter-only -- nothing personal.")


@telemetry_group.command("off")
def telemetry_off() -> None:
    """Disable telemetry entirely."""
    set_mode("off")
    click.echo("Telemetry: off. Nothing is sent.")
