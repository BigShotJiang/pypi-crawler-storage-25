"""Canonical Decision + abstract HostAdapter contract.

The CZ canonical Decision is the policy engine's single source of
truth. It carries everything the audit log + downstream consumers
need to reason about the decision. Adapters translate it on the
way out to whatever shape the host hook validator accepts.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping


@dataclass(frozen=True)
class CZDecision:
    """The canonical Control Zero decision. Adapter-independent.

    Adapters never construct one of these directly -- the hook_check
    workflow builds it from the policy engine's
    ``PolicyDecision`` + the resolved extractor + the tamper context.
    Adapters consume it via ``HostAdapter.render(decision)`` to
    produce the host-specific JSON envelope.

    Fields
    ------
    effect : "allow" | "deny" | "warn"
        Policy engine's verdict.
    reason : str
        Human-readable, branded message ("[Control Zero] ..."). Goes
        to the agent (model-facing).
    reason_code : str
        Machine-readable enum (see ``controlzero._internal.enforcer``
        REASON_CODE_*). Used by downstream consumers that branch on
        why a decision happened.
    policy_id : str
        UUID of the rule that matched (or ``"<noop>"`` on no-rule
        carve-outs). Empty string when not applicable.
    tool : str
        Canonical tool name post-extraction (e.g. ``"file_write"``,
        ``"database"``, ``"network"``). Independent of host tool name.
    method : str
        Extracted method (e.g. SQL keyword for database, file path
        for file_write). Empty string when not extractable.
    extracted_action : str
        ``f"{tool}:{method}"`` convenience shape the audit dashboard
        renders. Empty string when not extractable.
    semantic_class : str
        Class-level normaliser parallel to ``method`` (e.g. SQL
        ``read|write|admin|exec``). Empty outside SQL or when the
        keyword has no class mapping.
    tamper_detected : bool
        True when the policy file HMAC or audit chain failed
        verification. Carries through to host output so the agent
        can surface a tamper notice.
    audit_chain_broken : bool
        True when the local audit chain hash sequence is broken.
        Same surfacing rationale as ``tamper_detected``.
    """

    effect: str  # "allow" | "deny" | "warn"
    reason: str
    reason_code: str
    policy_id: str = ""
    tool: str = ""
    method: str = ""
    extracted_action: str = ""
    semantic_class: str = ""
    tamper_detected: bool = False
    audit_chain_broken: bool = False

    @property
    def is_deny(self) -> bool:
        return self.effect == "deny"

    @property
    def is_allow(self) -> bool:
        return self.effect in ("allow", "warn")


class HostAdapter:
    """Per-host hook adapter. Subclass + register in REGISTRY.

    A subclass needs three things:

    * ``name`` -- short identifier used in logs ("claude_code").
    * ``canonical_source`` -- backend-side source alias
      ("claude_code" / "gemini_cli" / "codex_cli" / "unknown").
      This is what the audit row's SOURCE column resolves to so
      the dashboard renders the right label.
    * ``claim(payload, env)`` -- True when this adapter recognises
      the inbound hook invocation. The registry tries adapters in
      order; first claim wins. Use a combination of stdin payload
      shape AND env vars so detection survives a host that doesn't
      export the canonical env var on every platform.
    * ``render(decision)`` -- map a ``CZDecision`` to the host's
      JSON envelope. Return a ``dict`` ready for ``json.dumps``.

    Subclasses may also override:

    * ``extract_method(tool_name, tool_input)`` -- canonical-tool
      extraction overrides. Most adapters inherit the shared
      extractor from ``controlzero._internal.tool_extractors``; only
      override when a host packs its tool args differently (e.g.
      PowerShell's nested command syntax that needs parsing before
      the canonical extractor can see ``file_write``).
    """

    #: Short identifier used in logs / metrics.
    name: str = "base"

    #: Backend audit source alias. Must be one of the canonical
    #: values the dashboard accepts so the right label renders.
    #: Default is ``"unknown"`` -- subclasses MUST override.
    canonical_source: str = "unknown"

    # -- detection --------------------------------------------------

    def claim(self, payload: dict, env: Mapping[str, str]) -> bool:
        """Return True if this adapter recognises this hook call."""
        raise NotImplementedError

    # -- rendering --------------------------------------------------

    def render(self, decision: CZDecision) -> dict:
        """Translate a CZDecision into this host's JSON envelope."""
        raise NotImplementedError

    # -- shared default extractor passthrough ----------------------

    def extract_method(self, tool_name: str, tool_input: dict) -> tuple[str, str]:
        """Default = shared extractor. Override for host-specific shells."""
        from controlzero._internal.enforcer import extract_method  # local import to avoid cycle

        return extract_method(tool_name, tool_input)


# Convenience type-aliases used by tests.
HostDecision = dict
HostPayload = dict
