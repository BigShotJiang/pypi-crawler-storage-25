"""Gemini CLI BeforeTool hook adapter.

Gemini CLI config lives at ``~/.gemini/settings.json``. The hook
contract was verified against the public docs (April 2026):

* Schema slot: ``hooks.BeforeTool[].hooks[]`` (array of
  ``{ type: "command", command, timeout }``).
* Stdin: ``{ tool_name, tool_input, session_id, cwd, ... }``.
* Stdout decision: ``{ "decision": "deny", "reason": "..." }`` or
  exit 2 to block. Anything else proceeds.

Reference: https://www.geminicli.com/docs/hooks/reference
"""

from __future__ import annotations

from typing import Mapping

from controlzero.cli.hosts.base import CZDecision, HostAdapter


class GeminiCLIAdapter(HostAdapter):
    name = "gemini_cli"
    canonical_source = "gemini_cli"

    # Only true CLI runtime signals. ``GEMINI_API_KEY`` is set by
    # anyone using Google's Python SDK directly and must NOT match
    # (the deny-deny incident, 2026-05-10 -- T78 / T92).
    _ENV_HINTS = ("GEMINI_CLI", "GEMINI_SANDBOX", "GEMINI_SYSTEM_MD")

    def claim(self, payload: dict, env: Mapping[str, str]) -> bool:
        if (env.get("CONTROLZERO_CLIENT") or "").strip().lower() in (
            "gemini-cli",
            "gemini_cli",
            "gemini",
        ):
            return True
        for hint in self._ENV_HINTS:
            if env.get(hint):
                return True
        return False

    def render(self, decision: CZDecision) -> dict:
        envelope: dict = {
            "reason": decision.reason,
            "reason_code": decision.reason_code,
            "tool": decision.tool,
            "extracted_method": decision.method,
            "action": decision.extracted_action,
            "action_semantic_class": decision.semantic_class,
            "tamper_detected": decision.tamper_detected,
            "audit_chain_broken": decision.audit_chain_broken,
        }
        if decision.is_deny:
            envelope["decision"] = "deny"
        # Gemini: omit decision on allow. Per docs, any non-deny
        # body or exit 0 with no body proceeds.
        return envelope
