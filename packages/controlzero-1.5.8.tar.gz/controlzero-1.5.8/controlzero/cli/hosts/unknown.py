"""Conservative fallback adapter for unrecognised host runtimes.

Always claims the call (final entry in REGISTRY) so the SDK never
crashes when a brand-new agent invokes the hook before we have a
dedicated adapter for it.

Render rules:

* On deny -- emit ``{"decision": "block", "reason": ...}``. Block
  is universal: every host runtime we have seen treats ``block``
  as the explicit "do not proceed" signal. If a future host uses
  a different keyword we will catch it with a dedicated adapter
  before the unknown fallback is hit.
* On allow -- emit a body with NO ``decision`` field. Per every
  known hook protocol, the absence of a decision means "no
  opinion, proceed normally." Safer than guessing ``approve`` /
  ``allow`` / ``ok`` and tripping a strict validator.
"""

from __future__ import annotations

from typing import Mapping

from controlzero.cli.hosts.base import CZDecision, HostAdapter


class UnknownHostAdapter(HostAdapter):
    name = "unknown"
    # Canonical source value the dashboard accepts -- renders as
    # ``--`` on the dashboard. Better than mislabelling.
    canonical_source = "unknown"

    def claim(self, payload: dict, env: Mapping[str, str]) -> bool:
        # Final-fallback adapter: always claims.
        return True

    def render(self, decision: CZDecision) -> dict:
        envelope: dict = {
            "reason": decision.reason,
            "reason_code": decision.reason_code,
            "tool": decision.tool,
            "extracted_method": decision.method,
            "action": decision.extracted_action,
            "action_semantic_class": decision.semantic_class,
            "tamper_detected": decision.tamper_detected,
            "audit_chain_broken": decision.audit_chain_broken,
        }
        if decision.is_deny:
            envelope["decision"] = "block"
        # Allow: NO decision field. Universal proceed.
        return envelope
