"""Claude Code PreToolUse hook adapter.

Spec reference: https://docs.anthropic.com/en/docs/claude-code/hooks

Stdin payload shape Claude Code sends (PreToolUse):
::

    {
      "session_id": "uuid",
      "transcript_path": "/path/to/transcript",
      "cwd": "/working/dir",
      "tool_name": "Write" | "Bash" | "Read" | "Edit" | ...,
      "tool_input": { ...tool args... },
      "hook_event_name": "PreToolUse"
    }

Stdout decision shape Claude Code accepts:
::

    {
      "decision": "approve" | "block",   // optional; omit = proceed
      "reason": "string"                  // shown to the model when block
    }

Critical: ``"decision": "allow"`` is **NOT** valid -- Claude Code
rejects the hook output with
``Hook JSON output validation failed - (root): Invalid input`` and
falls back to its default (proceed). That is the 2026-05-12
the Windows PowerShell-bypass root cause.
"""

from __future__ import annotations

from typing import Mapping

from controlzero.cli.hosts.base import CZDecision, HostAdapter


class ClaudeCodeAdapter(HostAdapter):
    name = "claude_code"
    canonical_source = "claude_code"

    # Env-var hints (best-effort). On macOS / Linux the Anthropic
    # launcher exports CLAUDECODE=1; on Windows the env-var may be
    # missing depending on launcher version, so the stdin shape
    # check below is the authoritative signal.
    _ENV_HINTS = (
        "CLAUDECODE",
        "CLAUDE_CODE",
        "CLAUDE_CODE_HOOK_VERSION",
        "ANTHROPIC_CLI",
    )

    def claim(self, payload: dict, env: Mapping[str, str]) -> bool:
        # Explicit env-var override always wins. ``CONTROLZERO_CLIENT``
        # lets a power-user or CI environment force the right adapter.
        if (env.get("CONTROLZERO_CLIENT") or "").strip().lower() in (
            "claude-code",
            "claude_code",
            "claudecode",
        ):
            return True

        # Env-var hint: any of the Anthropic-family vars present.
        for hint in self._ENV_HINTS:
            if env.get(hint):
                return True

        # Stdin payload signature: PreToolUse always carries
        # ``hook_event_name`` (post-2024-10 schema) OR a
        # ``session_id`` + ``transcript_path`` + ``tool_input``
        # tuple. We accept either to handle older + newer Claude
        # Code releases.
        if isinstance(payload, dict):
            if payload.get("hook_event_name") in (
                "PreToolUse",
                "PostToolUse",
                "Notification",
                "Stop",
                "SubagentStop",
            ):
                return True
            if (
                "session_id" in payload
                and "transcript_path" in payload
                and ("tool_input" in payload or "tool_name" in payload)
            ):
                return True

        return False

    def render(self, decision: CZDecision) -> dict:
        # Claude Code's PreToolUse hook spec:
        #   decision: "approve" | "block" | (omit)
        # On deny we emit "block". On allow we explicitly emit
        # "approve" so Claude Code records that the hook ran AND
        # decided yes (cleaner audit + bypasses any user-permission
        # prompt that would otherwise interrupt the flow). The
        # legacy "allow" string is REMOVED -- it crashed validation.
        envelope: dict = {
            "reason": decision.reason,
            # Non-spec metadata fields. Claude Code is permissive
            # about extras (per docs, "additional fields are
            # ignored"). These keep the existing fields the SDK
            # was emitting so any external consumer parsing the
            # JSON keeps working.
            "reason_code": decision.reason_code,
            "tool": decision.tool,
            "extracted_method": decision.method,
            "action": decision.extracted_action,
            "action_semantic_class": decision.semantic_class,
            "tamper_detected": decision.tamper_detected,
            "audit_chain_broken": decision.audit_chain_broken,
        }
        if decision.is_deny:
            envelope["decision"] = "block"
        else:
            # Allow path. "approve" is the explicit positive signal;
            # Claude Code accepts it without a permission prompt.
            envelope["decision"] = "approve"
        return envelope
