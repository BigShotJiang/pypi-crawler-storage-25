"""Codex CLI PreToolUse hook adapter.

Codex CLI ships its hook config at ``~/.codex/hooks.json`` with
the PreToolUse contract verified March 2026:

* Stdin: ``{ "tool_name", "tool_input", "session_id", "cwd" }``.
* Stdout decision:
  ``{ "decision": "allow" | "deny", "reason": "..." }``
  or exit 2 + reason on stderr.
* Codex launcher exports ``CODEX_HOME`` (path to ``~/.codex``),
  ``CODEX_PROFILE`` (active profile name), and ``CODEX_CLI`` (a
  mirror of the cross-SDK convention).
"""

from __future__ import annotations

from typing import Mapping

from controlzero.cli.hosts.base import CZDecision, HostAdapter


class CodexCLIAdapter(HostAdapter):
    name = "codex_cli"
    canonical_source = "codex_cli"

    _ENV_HINTS = ("CODEX_HOME", "CODEX_PROFILE", "CODEX_CLI")

    def claim(self, payload: dict, env: Mapping[str, str]) -> bool:
        if (env.get("CONTROLZERO_CLIENT") or "").strip().lower() in (
            "codex-cli",
            "codex_cli",
            "codex",
        ):
            return True
        for hint in self._ENV_HINTS:
            if env.get(hint):
                return True
        return False

    def render(self, decision: CZDecision) -> dict:
        envelope: dict = {
            "reason": decision.reason,
            "reason_code": decision.reason_code,
            "tool": decision.tool,
            "extracted_method": decision.method,
            "action": decision.extracted_action,
            "action_semantic_class": decision.semantic_class,
            "tamper_detected": decision.tamper_detected,
            "audit_chain_broken": decision.audit_chain_broken,
        }
        # Codex spec uses allow / deny verbs (NOT Anthropic's
        # approve / block).
        envelope["decision"] = "deny" if decision.is_deny else "allow"
        return envelope
