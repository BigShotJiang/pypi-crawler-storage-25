"""Host-agent adapter base for the hook-check command (1.5.3).

Background
----------
Before 1.5.3 the hook subprocess wrote a single hard-coded JSON
envelope to stdout regardless of which coding agent invoked it. Two
bugs followed from that design:

* Claude Code's PreToolUse hook spec only accepts
  ``decision: "approve" | "block"``. The SDK emitted
  ``decision: "allow"`` on the allow path, which Claude Code rejects
  as ``Hook JSON output validation failed - (root): Invalid input``.
  Claude Code then drops the hook decision and runs the call. Customer
  saw a Write block correctly, then a PowerShell command bypass on
  the same tool intent (2026-05-12).

* Source detection relied on env vars Anthropic only exports on
  macOS / Linux. On Windows the hook subprocess saw no
  ``CLAUDECODE`` and ``detect_client_name()`` fell through to the
  generic ``python-sdk`` default. The audit row mis-labelled the
  agent as a direct SDK call.

Both failure modes share a root: the SDK conflated "what decision
did the policy engine make" with "what shape does the host expect
on the wire." Splitting those two concerns is what this package
does.

Design
------
A ``HostAdapter`` owns three responsibilities for one host runtime:

1. ``claim(payload, env)`` -- decide whether the inbound hook
   invocation came from this host. First adapter to claim wins.
   Adapters use BOTH stdin-payload signatures and env-var hints so
   detection works even when the host's launcher strips env vars
   (Windows Claude Code is the canonical case).
2. ``render(decision)`` -- translate the canonical ``CZDecision``
   into the JSON shape this host's hook validator accepts.
3. ``canonical_source`` -- the backend-side source alias
   (``claude_code`` / ``gemini_cli`` / ``codex_cli`` / etc.) so the
   audit row's SOURCE column renders correctly.

Adding a new host (Cursor, Windsurf, OpenClaw, Antigravity, the
next agent that ships) is a single file in this package: subclass
``HostAdapter``, append the instance to ``REGISTRY``. No edits to
``cli/main.py``, ``audit_remote.py``, the policy engine, or the
backend.

A conservative ``UnknownHostAdapter`` sits at the bottom of the
registry and is the final claim. It emits ``{}`` for allow (every
known host treats no-decision as "proceed") and the universal
``{"decision": "block", "reason": ...}`` for deny.
"""

from __future__ import annotations

from controlzero.cli.hosts.base import CZDecision, HostAdapter
from controlzero.cli.hosts.claude_code import ClaudeCodeAdapter
from controlzero.cli.hosts.codex_cli import CodexCLIAdapter
from controlzero.cli.hosts.gemini_cli import GeminiCLIAdapter
from controlzero.cli.hosts.unknown import UnknownHostAdapter


# Registry order = claim priority. First adapter whose ``claim()`` returns
# True owns the call. The unknown fallback always claims so the order
# above it MUST cover every supported host.
#
# IMPORTANT: keep this list ordered from most-specific to least-specific.
# The Claude Code adapter goes first because Anthropic's PreToolUse
# stdin payload is the most distinctive (it always carries a
# ``tool_input`` envelope alongside a ``session_id`` field). Codex
# / Gemini follow with their own signatures. Unknown is always last.
REGISTRY: list[HostAdapter] = [
    ClaudeCodeAdapter(),
    CodexCLIAdapter(),
    GeminiCLIAdapter(),
    UnknownHostAdapter(),  # always claims; must stay at the tail
]


def select_adapter(payload: dict, env) -> HostAdapter:
    """Pick the right host adapter for this hook invocation.

    Iterates ``REGISTRY`` and returns the first adapter whose
    ``claim()`` returns True. ``UnknownHostAdapter`` is the
    backstop, so this function never raises.
    """
    for adapter in REGISTRY:
        try:
            if adapter.claim(payload, env):
                return adapter
        except Exception:  # noqa: BLE001
            # An adapter's claim() must never crash the hook. If one
            # does, skip it and try the next. Unknown is the floor.
            continue
    # Unreachable in practice (UnknownHostAdapter always claims),
    # but mypy/runtime safety.
    return REGISTRY[-1]


__all__ = [
    "CZDecision",
    "HostAdapter",
    "ClaudeCodeAdapter",
    "CodexCLIAdapter",
    "GeminiCLIAdapter",
    "UnknownHostAdapter",
    "REGISTRY",
    "select_adapter",
]
