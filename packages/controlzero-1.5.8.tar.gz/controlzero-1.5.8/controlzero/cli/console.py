"""Centralized Rich console for the controlzero CLI.

Tier 0a hotfix piece 6 (#174 / DESIGN.md): every user-facing CLI
output goes through this singleton so colors, padding, and spinner
styles stay consistent across `controlzero doctor`, `controlzero
migrate`, `controlzero install`, and the install-time consent prompt.

Color palette pulled straight from DESIGN.md:

- accent:   #22c55e  sage green (logo, active states, success)
- success:  #22c55e  same as accent (allowed, healthy)
- warning:  #eab308  yellow (approaching limits, soft errors)
- error:    #ef4444  red (blocked, critical)
- text-1:   #f0f0f3  primary (headings, values)
- text-2:   #8b8b96  secondary (descriptions)
- text-3:   #7a7a86  tertiary (labels)
- border:   rgba(255,255,255,0.06)  (rendered as dim grey in terminal)

Use the module-level helpers (`success`, `warn`, `error`, `info`,
`panel`) rather than constructing rich objects in each command. This
makes the CLI testable: tests can mock the singleton and assert on
the rendered strings.

If the user has NO_COLOR set, rich's automatic detection kicks in
and we render plain text -- nothing to do here.
"""

from __future__ import annotations

from typing import Optional

from rich.console import Console
from rich.panel import Panel
from rich.style import Style
from rich.text import Text
from rich.theme import Theme


# DESIGN.md color tokens. Names mirror the CSS custom property names
# so a designer can grep across the repo and find every place a token
# is consumed.
_CZ_THEME = Theme({
    "cz.accent": Style(color="#22c55e", bold=False),
    "cz.success": Style(color="#22c55e", bold=True),
    "cz.warning": Style(color="#eab308", bold=True),
    "cz.error": Style(color="#ef4444", bold=True),
    "cz.text1": Style(color="#f0f0f3"),
    "cz.text2": Style(color="#8b8b96"),
    "cz.text3": Style(color="#7a7a86"),
    "cz.text4": Style(color="#5a5a65", dim=True),
    "cz.code": Style(color="#f0f0f3", bgcolor="#222225"),
    # Compound helpers used by panels.
    "cz.heading": Style(color="#f0f0f3", bold=True),
    "cz.dim_border": Style(color="#5a5a65", dim=True),
})


# Two consoles so callers can route errors to stderr without
# leaking color escape codes into a redirected stdout.
_stdout = Console(theme=_CZ_THEME, highlight=False)
_stderr = Console(theme=_CZ_THEME, highlight=False, stderr=True)


def stdout() -> Console:
    """The shared stdout-bound console. Use this for normal CLI
    output. Tests can monkeypatch this to capture rendered output."""
    return _stdout


def stderr() -> Console:
    """The shared stderr-bound console. Use this for warnings + errors."""
    return _stderr


# -----------------------------------------------------------------------------
# Helpers -- the public surface. Every CLI command should use these
# rather than touching the underlying console.
# -----------------------------------------------------------------------------


def success(message: str) -> None:
    """Bold sage-green check mark + message. Used for happy-path
    completion lines like 'Installed claude-code hook'.
    """
    _stdout.print(Text.assemble(("[OK] ", "cz.success"), (message, "cz.text1")))


def warn(message: str) -> None:
    """Yellow warning. Used for soft errors that don't block the
    operation but the user should know about (e.g. 'shell history
    contains a key')."""
    _stderr.print(Text.assemble(("[WARN] ", "cz.warning"), (message, "cz.text1")))


def error(message: str, code: Optional[str] = None) -> None:
    """Red error. If a stable E#### code is supplied, prepend it so
    the user can search the docs site for the canonical fix."""
    prefix = f"[ERROR {code}] " if code else "[ERROR] "
    _stderr.print(Text.assemble((prefix, "cz.error"), (message, "cz.text1")))


def info(message: str) -> None:
    """Plain informational line, no color. Used for hints + status
    lines that aren't the headline output."""
    _stdout.print(Text(message, style="cz.text2"))


def heading(message: str) -> None:
    """Section heading. Bold, primary text color."""
    _stdout.print(Text(message, style="cz.heading"))


def code(snippet: str) -> Text:
    """Render a short code snippet (filename, command, key) with the
    code style. Returns a Text so callers can compose it into a
    larger renderable."""
    return Text(snippet, style="cz.code")


def panel(content: str, title: str = "", style: str = "cz.dim_border") -> None:
    """Outlined box with optional title. Used for the consent prompt
    + the post-install confirmation summary so they don't drown in
    other terminal output."""
    p = Panel.fit(content, title=title or None, border_style=style)
    _stdout.print(p)
