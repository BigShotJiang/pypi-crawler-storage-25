"""controlzero doctor: scan local machine for security + config issues.

Tier 0a hotfix piece 2 (#174). Doctor is the single command users run
after a security advisory to find out whether they have a problem on
their box. It scans:

1. Every known coding-agent settings file for cz_(live|test)_* key leaks
   in inline hook commands (`CONTROLZERO_API_KEY=cz_live_... controlzero
   hook-check`). This is the 2026-05-14 incident shape.
2. The permissions of ~/.controlzero/config.yaml + ~/.controlzero/ to
   make sure the key on disk is not world-readable.
3. Whether the policy bundle is signed + the signature verifies.

Output is one line per finding, formatted compiler-style:

    /path/to/file:LINE:COL: SEVERITY[CODE]: message
                    where to fix: how-to text

Exit code: 0 if clean, 1 if any ERROR-severity finding.

The agent settings paths it scans are the same paths the install
command writes to. If we add a new agent, add it here too. The list
deliberately covers every coding agent we documented in CLAUDE.md as
supported, not just the ones with native install commands -- otherwise
a Cline / Windsurf / Antigravity / Adal user gets no signal.

This module intentionally does NOT auto-fix. `controlzero migrate`
does that; doctor only reports. Splitting them lets us run doctor in
CI / pre-push without surprising side effects on developer machines.
"""

from __future__ import annotations

import os
import stat
import sys
from pathlib import Path
from typing import Iterable, List, NamedTuple

import click

from controlzero.cli._secrets import find_key_leaks, redact_key


# -----------------------------------------------------------------------------
# Agent settings paths. Mirrors the install commands plus the
# fall-through agents (Cline / Windsurf / Antigravity / Adal / Cursor /
# VS Code Copilot / JetBrains) that use the MCP server. Listed by the
# agent name they map back to in `controlzero install <agent>`.
# -----------------------------------------------------------------------------

class _AgentPath(NamedTuple):
    agent: str
    path: Path
    note: str  # human-readable hint for the migrate command


def _agent_paths() -> List[_AgentPath]:
    """Every settings file we want to scan, in priority order.

    Priority matters: the agents most likely to leak (claude-code,
    gemini-cli, codex-cli per the 2026-05-14 incident) come first so
    the user sees those failures at the top of the report.
    """
    home = Path.home()
    return [
        _AgentPath("claude-code", home / ".claude" / "settings.json",
                   "PreToolUse hook command"),
        _AgentPath("gemini-cli", home / ".gemini" / "settings.json",
                   "tools.preInvoke hook command"),
        _AgentPath("codex-cli", home / ".codex" / "config.toml",
                   "[tool_approval_policy] command"),
        _AgentPath("codex-cli", home / ".codex" / "hooks.json",
                   "Codex legacy hooks file"),
        _AgentPath("cursor", home / ".cursor" / "mcp.json",
                   "MCP server config"),
        _AgentPath("cursor", home / ".cursor" / "settings.json",
                   "Cursor settings"),
        _AgentPath("windsurf", home / ".codeium" / "windsurf" / "mcp_config.json",
                   "Windsurf MCP config"),
        _AgentPath("vscode", home / ".vscode" / "settings.json",
                   "VS Code user settings"),
        _AgentPath("cline", home / "Library" / "Application Support" / "Code" / "User" / "globalStorage" / "saoudrizwan.claude-dev" / "settings" / "cline_mcp_settings.json",
                   "Cline MCP settings (macOS)"),
        _AgentPath("antigravity", home / ".antigravity" / "config.json",
                   "Antigravity config"),
        _AgentPath("adal", home / ".adal" / "config.json",
                   "Adal config"),
        _AgentPath("jetbrains", home / ".config" / "JetBrains" / "mcp.json",
                   "JetBrains MCP config (Linux)"),
    ]


# -----------------------------------------------------------------------------
# Finding shape. We render each as a compiler-style line so terminals
# with editor integration (VS Code, JetBrains, Vim quickfix) can jump
# straight to the offending line.
# -----------------------------------------------------------------------------

class Finding(NamedTuple):
    path: str
    line: int
    col: int
    severity: str  # "ERROR" | "WARN" | "INFO"
    code: str  # E#### catalog code
    message: str
    fix_hint: str  # human-readable next step

    def render(self) -> str:
        line1 = f"{self.path}:{self.line}:{self.col}: {self.severity}[{self.code}]: {self.message}"
        line2 = f"  fix: {self.fix_hint}"
        return f"{line1}\n{line2}"


# -----------------------------------------------------------------------------
# Individual checks. Each returns a list of findings. Pure functions:
# no exit, no print. The CLI layer below assembles + renders + exits.
# -----------------------------------------------------------------------------


def _check_agent_key_leaks(agent_paths: Iterable[_AgentPath]) -> List[Finding]:
    """Scan every known agent settings file for cz_*_* keys baked into
    hook command strings. This is the 2026-05-14 incident shape: the
    install command originally wrote `CONTROLZERO_API_KEY=cz_live_...
    controlzero hook-check` inline into settings.json, which echoed
    the full key to stderr on every PreToolUse fire."""
    findings: List[Finding] = []
    for ap in agent_paths:
        if not ap.path.exists():
            continue
        try:
            text = ap.path.read_text(encoding="utf-8", errors="replace")
        except OSError as exc:
            findings.append(Finding(
                path=str(ap.path),
                line=1,
                col=1,
                severity="WARN",
                code="E1005",
                message=f"cannot read {ap.agent} settings: {exc}",
                fix_hint="check filesystem permissions; doctor can't tell if this file leaks keys",
            ))
            continue
        for match in find_key_leaks(text):
            findings.append(Finding(
                path=str(ap.path),
                line=match.line_number,
                col=(match.start - text.rfind("\n", 0, match.start)),
                severity="ERROR",
                code="E1001",
                message=(
                    f"{ap.agent} {ap.note} contains a plaintext API key "
                    f"({redact_key(match.key)}). On every tool invocation, "
                    f"this key is echoed to the agent's stderr -- visible "
                    f"to anyone reading the terminal or log files."
                ),
                fix_hint=(
                    "run `controlzero migrate` to move the key to "
                    "~/.controlzero/config.yaml (mode 0600) and rewrite "
                    "the hook to read $CONTROLZERO_API_KEY from the env"
                ),
            ))
    return findings


def _check_config_permissions() -> List[Finding]:
    """The config file holds the user's API key in plaintext. It must
    be mode 0o600 and the parent dir must be 0o700 so other users on
    a shared machine cannot read it."""
    findings: List[Finding] = []
    cfg_dir = Path.home() / ".controlzero"
    cfg_file = cfg_dir / "config.yaml"

    if cfg_dir.exists():
        mode = stat.S_IMODE(cfg_dir.stat().st_mode)
        if mode & 0o077 and os.name != "nt":  # POSIX only; Windows ACL ignored
            findings.append(Finding(
                path=str(cfg_dir),
                line=1,
                col=1,
                severity="WARN",
                code="E1002",
                message=(
                    f"~/.controlzero is mode {oct(mode)} -- other local "
                    f"users can read its contents."
                ),
                fix_hint=f"run `chmod 700 {cfg_dir}`",
            ))

    if cfg_file.exists():
        mode = stat.S_IMODE(cfg_file.stat().st_mode)
        if mode & 0o077 and os.name != "nt":
            findings.append(Finding(
                path=str(cfg_file),
                line=1,
                col=1,
                severity="ERROR",
                code="E1003",
                message=(
                    f"config.yaml is mode {oct(mode)} -- the API key on "
                    f"disk is readable by other local users."
                ),
                fix_hint=f"run `chmod 600 {cfg_file}` (or reinstall to re-apply)",
            ))

    return findings


def _check_global_environment() -> List[Finding]:
    """If CONTROLZERO_API_KEY is set in the user's shell, that's
    usually fine -- it's how the SDK is meant to be configured. But
    if it's *also* in ~/.bash_history or ~/.zsh_history, that's an
    on-disk leak worth flagging."""
    findings: List[Finding] = []
    home = Path.home()
    for hist_name in (".bash_history", ".zsh_history", ".history"):
        hist = home / hist_name
        if not hist.exists():
            continue
        try:
            text = hist.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        for match in find_key_leaks(text):
            findings.append(Finding(
                path=str(hist),
                line=match.line_number,
                col=1,
                severity="WARN",
                code="E1004",
                message=(
                    f"shell history contains an API key "
                    f"({redact_key(match.key)}). This is on-disk in your "
                    f"home directory and may be backed up to remote storage."
                ),
                fix_hint=(
                    f"rotate the key in the dashboard, then run "
                    f"`history -d <number>` (or edit {hist} directly) "
                    f"to scrub the historic entry"
                ),
            ))
            break  # one finding per history file is enough
    return findings


# -----------------------------------------------------------------------------
# Public entrypoint. Wired into the CLI as `controlzero doctor`.
# -----------------------------------------------------------------------------


def run_doctor(verbose: bool = False) -> int:
    """Run every check, render findings, return an exit code.

    Returns 0 on clean / WARN-only output, 1 if any ERROR found.
    """
    findings: List[Finding] = []
    findings.extend(_check_agent_key_leaks(_agent_paths()))
    findings.extend(_check_config_permissions())
    findings.extend(_check_global_environment())

    errors = [f for f in findings if f.severity == "ERROR"]
    warns = [f for f in findings if f.severity == "WARN"]

    # Lazy import so the (small) rich dependency is only loaded when
    # the doctor command actually runs -- not on every SDK import.
    from controlzero.cli import console as cz_console

    if not findings:
        cz_console.success("controlzero doctor: no issues found.")
        if verbose:
            cz_console.info("checked:")
            for ap in _agent_paths():
                status = "exists" if ap.path.exists() else "absent"
                cz_console.info(f"  {ap.agent:14s} {status:7s} {ap.path}")
        return 0

    for f in findings:
        if f.severity == "ERROR":
            cz_console.error(
                f"{f.path}:{f.line}:{f.col}: {f.message}",
                code=f.code,
            )
        else:
            cz_console.warn(f"{f.path}:{f.line}:{f.col} [{f.code}]: {f.message}")
        cz_console.info(f"  fix: {f.fix_hint}")

    cz_console.info("")
    summary = f"{len(errors)} error(s), {len(warns)} warning(s)"
    if errors:
        cz_console.error(f"controlzero doctor: {summary}.")
        cz_console.info(
            "Run `controlzero migrate` to auto-fix the ERROR findings above."
        )
        return 1
    cz_console.warn(f"controlzero doctor: {summary}.")
    return 0


@click.command("doctor")
@click.option("--verbose", "-v", is_flag=True,
              help="List every settings file checked, even when clean.")
def doctor_cmd(verbose: bool) -> None:
    """Scan local machine for API key leaks and config issues.

    Run this after a controlzero install or whenever a security
    advisory tells you to. Reports each finding compiler-style with
    a stable error code (E####). Exit 0 if clean, 1 on any error.
    """
    sys.exit(run_doctor(verbose=verbose))
