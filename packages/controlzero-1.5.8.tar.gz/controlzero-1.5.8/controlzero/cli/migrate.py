"""controlzero migrate: auto-rewrite leaked keys out of agent settings.

Tier 0a hotfix piece 3 (#174). The complement to `controlzero doctor`:
doctor reports, migrate fixes.

What it does:

1. Scans every known coding-agent settings file (same list as
   doctor) for `cz_(live|test)_*` keys embedded in inline hook
   commands.
2. Extracts the first real (non-`*****`-redacted) key it finds and
   writes it to ~/.controlzero/config.yaml with mode 0o600 (the
   install path already does this since 1.5.3; migrate handles the
   case where the file is missing or was pre-1.5.3).
3. Rewrites every leaked hook command from
   `CONTROLZERO_API_KEY=cz_live_xxx controlzero hook-check ...`
   to just `controlzero hook-check ...`. The hook subprocess will
   resolve the key from the config file (or the env) on the next
   invocation.
4. Prints a before / after summary and the path to the new config.

Why a separate command (not a flag on doctor): doctor is safe to
run in CI / pre-push; it has no side effects. Migrate writes files.
Splitting them lets us recommend doctor in security advisories
without worrying about side effects on shared boxes (CI / build
servers / shared dev machines).

Idempotency: migrate is safe to run multiple times. The second run
sees no leaks and exits 0 with no changes.
"""

from __future__ import annotations

import os
import re
import sys
from pathlib import Path
from typing import List, NamedTuple, Optional, Tuple

import click
import yaml

from controlzero.cli._secrets import _KEY_PATTERN, find_key_leaks, redact_key
from controlzero.cli.doctor import _agent_paths


# Pattern that matches the leaked-hook shape: optional whitespace,
# CONTROLZERO_API_KEY=cz_live_*, whitespace, then the hook command.
# We capture the hook-tail so we can preserve any flags the user
# added after `hook-check`.
_LEAKED_HOOK_PATTERN = re.compile(
    r"CONTROLZERO_API_KEY=cz_(?:live|test)_[A-Za-z0-9_]{4,}[ \t]+(controlzero[^\"'\n]*)"
)


class _Rewrite(NamedTuple):
    path: str
    before_snippet: str
    after_snippet: str
    key_found: str  # redacted form for the summary


def _extract_first_key(text: str) -> Optional[str]:
    """Return the first cz_(live|test)_* key found, or None."""
    matches = find_key_leaks(text)
    if not matches:
        return None
    return matches[0].key


def _rewrite_text(text: str) -> Tuple[str, List[_Rewrite]]:
    """Return (new_text, rewrites). Pure: no I/O."""
    rewrites: List[_Rewrite] = []

    def _sub(m: re.Match[str]) -> str:
        before = m.group(0)
        after = m.group(1)  # the `controlzero ...` tail
        # The redaction-friendly form of the full match for the summary.
        rewrites.append(_Rewrite(
            path="(in-memory)",
            before_snippet=re.sub(
                _KEY_PATTERN,
                lambda km: redact_key(km.group(0)),
                before,
            ),
            after_snippet=after,
            key_found=redact_key(m.group(0).split("=")[1].split()[0]),
        ))
        return after

    new_text = _LEAKED_HOOK_PATTERN.sub(_sub, text)
    return new_text, rewrites


def _write_config_key(api_key: str) -> Path:
    """Persist the recovered key to ~/.controlzero/config.yaml with
    mode 0o600. Idempotent: re-writes the file in place if it already
    exists. Returns the config path so the CLI layer can print it."""
    cfg_dir = Path.home() / ".controlzero"
    cfg_dir.mkdir(parents=True, exist_ok=True)
    try:
        os.chmod(cfg_dir, 0o700)
    except OSError:
        pass  # Windows / FAT / read-only fs: best effort

    cfg_path = cfg_dir / "config.yaml"
    existing: dict = {}
    if cfg_path.exists():
        try:
            existing = yaml.safe_load(cfg_path.read_text(encoding="utf-8")) or {}
        except yaml.YAMLError:
            existing = {}
    existing["api_key"] = api_key
    cfg_path.write_text(yaml.safe_dump(existing, default_flow_style=False),
                        encoding="utf-8")
    try:
        os.chmod(cfg_path, 0o600)
    except OSError:
        pass
    return cfg_path


def run_migrate(dry_run: bool = False) -> int:
    """Scan + (optionally) rewrite. Returns exit code."""
    total_rewrites: List[_Rewrite] = []
    rewritten_paths: List[Path] = []
    recovered_key: Optional[str] = None

    for ap in _agent_paths():
        if not ap.path.exists():
            continue
        try:
            text = ap.path.read_text(encoding="utf-8", errors="replace")
        except OSError as exc:
            click.echo(f"warn: cannot read {ap.path}: {exc}", err=True)
            continue

        new_text, rewrites = _rewrite_text(text)
        if not rewrites:
            continue

        # Attach the real path to each rewrite for the summary.
        for r in rewrites:
            total_rewrites.append(r._replace(path=str(ap.path)))

        # Recover the first real key so we can write it to the config.
        if recovered_key is None:
            recovered_key = _extract_first_key(text)

        if not dry_run:
            ap.path.write_text(new_text, encoding="utf-8")
            rewritten_paths.append(ap.path)

    from controlzero.cli import console as cz_console

    if not total_rewrites:
        cz_console.success("controlzero migrate: no leaked API keys found in agent settings.")
        return 0

    # If we found leaks, persist the key so the hook can still resolve
    # it after we rip the inline form out. Unless dry-run.
    cfg_path: Optional[Path] = None
    if recovered_key and not dry_run:
        cfg_path = _write_config_key(recovered_key)

    verb = "would rewrite" if dry_run else "rewrote"
    cz_console.heading(f"controlzero migrate: {verb} {len(total_rewrites)} hook command(s).")
    for r in total_rewrites:
        cz_console.info("")
        cz_console.info(f"  file:   {r.path}")
        cz_console.info(f"  key:    {r.key_found}")
        cz_console.info(f"  before: {r.before_snippet}")
        cz_console.info(f"  after:  {r.after_snippet}")

    if cfg_path:
        cz_console.info("")
        cz_console.success(f"Wrote API key to {cfg_path} (mode 0600).")
        cz_console.info("Future hook invocations resolve the key from this file.")
    elif dry_run:
        cz_console.info("")
        cz_console.warn("Dry run: no files changed. Re-run without --dry-run to apply.")

    cz_console.info("")
    cz_console.info("Next step: run `controlzero doctor` to confirm the box is clean.")
    return 0


@click.command("migrate")
@click.option("--dry-run", is_flag=True,
              help="Show what would change without writing.")
def migrate_cmd(dry_run: bool) -> None:
    """Move leaked API keys out of agent settings into ~/.controlzero/config.yaml.

    The 2026-05-14 incident put plaintext keys into Claude Code,
    Gemini CLI, and Codex CLI settings files via early install
    commands. This command finds the leaks (same scan as
    `controlzero doctor`) and rewrites the inline form to use the
    config file. Safe to re-run -- idempotent.
    """
    sys.exit(run_migrate(dry_run=dry_run))
