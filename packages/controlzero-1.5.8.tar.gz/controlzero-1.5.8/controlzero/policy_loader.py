"""Load and validate policies from dict, YAML file, or JSON file.

Translates the friendly user-facing schema into internal `PolicyRule` objects
that the evaluator consumes.

User-facing schema (the "Hello World" form):

    version: "1"
    rules:
      - id: hello-world           # optional
        deny: "delete_*"          # tool name pattern, OR "tool:method"
        reason: "Hello World"
      - allow: "read_*"
      - deny: "*"
        when:
          model: "claude-opus-*"

Internal schema (what the evaluator sees) is a list of PolicyRule with explicit
effect, actions, and resources fields. The translation handles shorthand:
- "delete_*" -> action ["delete_*:*"] (any method on matching tools)
- "github:list_*" -> action ["github:list_*"]
- "*" -> action ["*"]
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Union

from controlzero._internal.enforcer import (
    DEFAULT_BUNDLE_ACTION,
    DEFAULT_BUNDLE_ON_MISSING,
    DEFAULT_BUNDLE_ON_TAMPER,
    VALID_DEFAULT_ACTIONS,
    VALID_DEFAULT_ON_MISSING,
    VALID_DEFAULT_ON_TAMPER,
)
from controlzero._internal.types import PolicyRule
from controlzero.errors import PolicyLoadError, PolicyValidationError

PolicyInput = Union[dict, str, Path]

VALID_TAMPER_BEHAVIORS = {"warn", "deny", "deny-all", "quarantine"}

# Known rule-level keys. Used by the typo guardrail (HITL-5a, gh#538)
# to surface "did you mean?" warnings on near-misses. Unknown keys are
# still silently accepted (additive contract; never break existing YAML)
# but a Levenshtein-1 match on a known key fires a `_KNOWN_RULE_KEYS`
# warning in stderr so the customer can self-correct.
_KNOWN_RULE_KEYS = frozenset({
    "id",
    "name",
    "deny",
    "allow",
    "effect",
    "action",
    "actions",
    "resource",
    "resources",
    "when",
    "conditions",
    "reason",
    "reason_code",
    "escalate_on_deny",  # HITL tag (additive in 1.5.8; behavior in 1.6.0)
})


def _levenshtein_le_1(a: str, b: str) -> bool:
    """Return True iff edit distance between `a` and `b` is exactly 0 or 1.

    Used by the typo guardrail to suggest fixes for unknown rule keys
    that are one keystroke away from a known one (e.g. `escalate_on_dnen`
    -> `escalate_on_deny`). Pure-Python; no external dependency.
    """
    if a == b:
        return True
    la, lb = len(a), len(b)
    if abs(la - lb) > 1:
        return False
    if la > lb:
        a, b = b, a
        la, lb = lb, la
    # la <= lb; check for one substitution (la == lb) or one insertion
    i = j = diffs = 0
    while i < la and j < lb:
        if a[i] != b[j]:
            diffs += 1
            if diffs > 1:
                return False
            if la == lb:
                i += 1
                j += 1
            else:
                j += 1  # insertion in b
        else:
            i += 1
            j += 1
    if j < lb:
        diffs += lb - j
    return diffs <= 1


@dataclass
class PolicySettings:
    """Parsed settings from the policy YAML.

    Schema 1.1 (#228 Phase 2) adds three enforcement-default knobs
    that the bundle carries as top-level fields and the translator
    surfaces into this block:

    - ``default_action``: effect for the no-match path. One of
      ``deny``/``allow``/``warn``. Default ``deny`` matches the
      pre-1.1 hard-coded behaviour so old bundles keep working.
    - ``default_on_missing``: effect when the bundle itself cannot be
      loaded. ``deny``/``allow``. Default ``deny``.
    - ``default_on_tamper``: mirrors ``tamper_behavior`` for parity
      with the backend schema. ``warn``/``deny``/``deny-all``/
      ``quarantine``. Default ``warn``.

    ``tamper_behavior`` is kept as the authoritative field for one
    release so existing YAML policies that only set ``tamper_behavior``
    keep working; the bundle translator sets both in lockstep.
    """

    tamper_behavior: str = "warn"
    default_action: str = DEFAULT_BUNDLE_ACTION
    default_on_missing: str = DEFAULT_BUNDLE_ON_MISSING
    default_on_tamper: str = DEFAULT_BUNDLE_ON_TAMPER


@dataclass
class ParsedPolicy:
    """Result of loading a policy file. Contains rules + settings."""
    rules: list[PolicyRule]
    settings: PolicySettings = field(default_factory=PolicySettings)


def _canonicalize_action(pattern: str) -> str:
    """Translate a user-facing action pattern to canonical "tool:method" form.

    Rules:
      "*"             -> "*"            (universal, matches any tool:method)
      "delete_*"      -> "delete_*:*"   (no colon = match any method on matching tools)
      "github:*"      -> "github:*"     (already canonical)
      "github:list_*" -> "github:list_*"
      "*:read"        -> "*:read"
    """
    if pattern == "*":
        return "*"
    if ":" in pattern:
        return pattern
    return f"{pattern}:*"


def load_policy(source: PolicyInput) -> ParsedPolicy:
    """Load a policy from a dict, file path, or Path object.

    Args:
        source: A dict matching the user-facing schema, OR a path to a YAML/JSON
                file, OR a pathlib.Path.

    Returns:
        A ParsedPolicy containing rules and settings.

    Raises:
        PolicyLoadError: file not found, parse error, or unsupported format.
        PolicyValidationError: schema invalid, with a list of bad fields.
    """
    if isinstance(source, dict):
        return _validate_and_translate(source, source_label="<dict>")

    if isinstance(source, (str, Path)):
        path = Path(source)
        return _load_from_file(path)

    raise PolicyLoadError(
        f"unsupported policy source type: {type(source).__name__}",
        source=str(source),
    )


def _load_from_file(path: Path) -> ParsedPolicy:
    if not path.exists():
        raise PolicyLoadError(
            f"policy file not found: {path}",
            source=str(path),
        )

    suffix = path.suffix.lower()
    text = path.read_text(encoding="utf-8")

    if suffix in (".yaml", ".yml"):
        try:
            import yaml  # local import: pyyaml is a hard dep but only needed for files
        except ImportError as e:
            raise PolicyLoadError(
                "pyyaml is required to load YAML policy files. "
                "Install with: pip install controlzero[dev] or pip install pyyaml",
                source=str(path),
                cause=e,
            ) from e
        try:
            data = yaml.safe_load(text)
        except yaml.YAMLError as e:
            raise PolicyLoadError(
                f"YAML parse error: {e}",
                source=str(path),
                cause=e,
            ) from e
    elif suffix == ".json":
        try:
            data = json.loads(text)
        except json.JSONDecodeError as e:
            raise PolicyLoadError(
                f"JSON parse error at line {e.lineno}, column {e.colno}: {e.msg}",
                source=str(path),
                cause=e,
            ) from e
    else:
        raise PolicyLoadError(
            f"unsupported file format: {suffix} (use .yaml, .yml, or .json)",
            source=str(path),
        )

    if data is None:
        raise PolicyValidationError(
            ["policy file is empty"],
            source=str(path),
        )
    if not isinstance(data, dict):
        raise PolicyValidationError(
            [f"policy root must be a mapping/object, got {type(data).__name__}"],
            source=str(path),
        )

    return _validate_and_translate(data, source_label=str(path))


def _validate_and_translate(data: dict, source_label: str) -> ParsedPolicy:
    errors: list[str] = []

    version = data.get("version", "1")
    if version != "1":
        errors.append(f"unsupported version {version!r}, expected '1'")

    # Parse optional settings section
    settings = PolicySettings()
    settings_raw = data.get("settings")
    if settings_raw is not None:
        if not isinstance(settings_raw, dict):
            errors.append("'settings' must be a mapping if present")
        else:
            tb = settings_raw.get("tamper_behavior", "warn")
            if tb not in VALID_TAMPER_BEHAVIORS:
                errors.append(
                    f"settings.tamper_behavior must be one of {sorted(VALID_TAMPER_BEHAVIORS)}, got {tb!r}"
                )
            else:
                settings.tamper_behavior = tb

            # Schema 1.1 defaults. Each field is independently
            # optional; missing => canonical fallback, invalid =>
            # validation error (so users writing YAML get a clear
            # "you typed the wrong enum value" message instead of a
            # silent coerce). The bundle translator sanitises its own
            # input, so bundle-shipped settings never take this
            # branch.
            da = settings_raw.get("default_action")
            if da is not None:
                if da not in VALID_DEFAULT_ACTIONS:
                    errors.append(
                        "settings.default_action must be one of "
                        f"{sorted(VALID_DEFAULT_ACTIONS)}, got {da!r}"
                    )
                else:
                    settings.default_action = da

            dom = settings_raw.get("default_on_missing")
            if dom is not None:
                if dom not in VALID_DEFAULT_ON_MISSING:
                    errors.append(
                        "settings.default_on_missing must be one of "
                        f"{sorted(VALID_DEFAULT_ON_MISSING)}, got {dom!r}"
                    )
                else:
                    settings.default_on_missing = dom

            dot = settings_raw.get("default_on_tamper")
            if dot is not None:
                if dot not in VALID_DEFAULT_ON_TAMPER:
                    errors.append(
                        "settings.default_on_tamper must be one of "
                        f"{sorted(VALID_DEFAULT_ON_TAMPER)}, got {dot!r}"
                    )
                else:
                    settings.default_on_tamper = dot

    rules_raw = data.get("rules")
    if rules_raw is None:
        errors.append("missing required field 'rules'")
    elif not isinstance(rules_raw, list):
        errors.append(f"'rules' must be a list, got {type(rules_raw).__name__}")
    elif len(rules_raw) == 0:
        errors.append("'rules' must contain at least one rule")

    if errors:
        raise PolicyValidationError(errors, source=source_label)

    out: list[PolicyRule] = []
    for i, raw in enumerate(rules_raw):
        rule_errors = []
        if not isinstance(raw, dict):
            errors.append(f"rules[{i}]: must be a mapping, got {type(raw).__name__}")
            continue

        # Typo guardrail (HITL-5a, gh#538): warn on unknown rule keys that
        # are within Levenshtein-1 of a known key. Unknown keys are still
        # silently accepted (additive contract); the warning is stderr-only.
        for k in raw.keys():
            if k in _KNOWN_RULE_KEYS:
                continue
            for known in _KNOWN_RULE_KEYS:
                if _levenshtein_le_1(k, known):
                    import sys as _sys
                    _sys.stderr.write(
                        f"controlzero: rules[{i}] unknown key {k!r}; "
                        f"did you mean {known!r}?\n"
                    )
                    break

        # Determine effect from the keys present
        has_deny = "deny" in raw
        has_allow = "allow" in raw
        explicit_effect = raw.get("effect")

        if explicit_effect:
            if explicit_effect not in ("allow", "deny", "warn", "audit"):
                rule_errors.append(
                    f"rules[{i}].effect: must be one of allow/deny/warn/audit, got {explicit_effect!r}"
                )
            effect = explicit_effect
            pattern = raw.get("action") or raw.get("actions")
        elif has_deny and has_allow:
            rule_errors.append(
                f"rules[{i}]: cannot set both 'deny' and 'allow' on the same rule"
            )
            effect = None
            pattern = None
        elif has_deny:
            effect = "deny"
            pattern = raw["deny"]
        elif has_allow:
            effect = "allow"
            pattern = raw["allow"]
        else:
            rule_errors.append(
                f"rules[{i}]: must specify one of 'deny', 'allow', or 'effect'"
            )
            effect = None
            pattern = None

        if effect and pattern is None:
            rule_errors.append(f"rules[{i}]: missing tool pattern")

        if rule_errors:
            errors.extend(rule_errors)
            continue

        # Normalize pattern to a list of canonical "tool:method" strings.
        # Friendly forms users write:
        #   "delete_*"           -> "delete_*:*"      (no colon = match any method)
        #   "github:list_*"      -> "github:list_*"   (already canonical)
        #   "*"                  -> "*"               (universal)
        # This translation lives ONLY here so the evaluator stays simple.
        if isinstance(pattern, str):
            raw_patterns = [pattern]
        elif isinstance(pattern, list):
            if not all(isinstance(p, str) for p in pattern):
                errors.append(f"rules[{i}]: pattern list must contain only strings")
                continue
            raw_patterns = pattern
        else:
            errors.append(f"rules[{i}]: pattern must be a string or list of strings")
            continue

        actions = [_canonicalize_action(p) for p in raw_patterns]

        # Normalize resource(s) to a list
        resources_raw = raw.get("resources") or raw.get("resource") or []
        if isinstance(resources_raw, str):
            resources = [resources_raw]
        elif isinstance(resources_raw, list):
            resources = list(resources_raw)
        else:
            errors.append(f"rules[{i}]: 'resources' must be a string or list")
            continue

        out.append(
            PolicyRule(
                id=str(raw.get("id", "")),
                name=str(raw.get("name", raw.get("id", f"rule-{i}"))),
                effect=effect,
                actions=actions,
                resources=resources,
                conditions=raw.get("when") or raw.get("conditions") or {},
                reason=str(raw.get("reason", "")),
                # Machine-readable reason code. Only synthetic rules
                # (e.g. the empty-bundle NO_ACTIVE_POLICIES deny
                # emitted by bundle.translate_to_local_policy) set
                # this today; user-authored rules leave it empty.
                reason_code=str(raw.get("reason_code", "")),
                # HITL escalation tag (HITL-5a, gh#538). Coerce truthy
                # values; non-bool / missing => False. The actual
                # request-approval flow ships in 1.6.0 (HITL-6a); 1.5.8
                # just persists the field so old SDKs don't crash on
                # rules that pre-tag for HITL.
                escalate_on_deny=bool(raw.get("escalate_on_deny", False)),
            )
        )

    if errors:
        raise PolicyValidationError(errors, source=source_label)

    return ParsedPolicy(rules=out, settings=settings)
