"""Catalog wrapper for the attested collector framework.

Bridge surfaces are universal — they iterate descriptors at module
load and surface row content / attestation / descriptor metadata
without per-source code paths. The whole point of v0.25.0 is that
adding a source is a CONFIG change (descriptor + schema + NDJSON);
no per-source ``*_catalog.py`` module needed.

Reproducibility tiers (notebook §18.1)
---------------------------------------
* **T0** — committed NDJSON under ``_research/attested/<source>/``.
  Byte-identical across all installs of a given version.
* **T1** — CI-baked extension (auto-PR refresh via the collect
  workflow). Byte-identical at the next ship.
* **T2** — *(v0.25.1+)* user runtime kernel. Local NDJSON cache
  registered via :func:`use_local_kernel`. Byte-identical *within*
  a user's local cache state; the cache hash documents the state
  for paper appendices.
* **T3** — *(v0.25.2+)* live query.

When a T2 overlay is registered, queries merge T0+T1 baseline rows
with T2 overlay rows on a per-source-and-table basis. Default
policy is **replace**: an overlay file at
``<overlay>/<source>/<table>.ndjson`` REPLACES the baseline file
for that source. Future v0.25.x ships may add an explicit append
policy.

Surfaces
--------
* :func:`list_attested_sources` — every registered source's
  rendered metadata (name, purpose, license, cite_as, gap_targeting).
* :func:`get_attested_dataset` — paginated row content for one
  source, with full attestation + rendering blocks. Honours T2
  overlay when registered.
* :func:`get_attested_descriptor` — full parsed descriptor for one
  source (UI / pre-fetch).
* :func:`attestation_audit` — per-row attestation metadata, **no
  data payload** (cheap, paper-appendix-ready).
* :func:`use_local_kernel` — register a T2 user-runtime-kernel
  overlay. *(v0.25.1+)*
* :func:`clear_local_kernel` — remove the T2 overlay. *(v0.25.1+)*
* :func:`get_local_kernel_state` — return current T2 state +
  per-source cache-hash so a paper can replay exactly which rows
  were used. *(v0.25.1+)*

References
----------
* Notebook §18 — full normative format spec.
* `attested_collector_format` — MPR record format.
* `attested_collector_descriptor` — descriptor TOML schema.
"""

from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Any, Dict, Iterator, List, Optional

from .attested_collector_descriptor import (
    Descriptor,
    discover_descriptors,
)
from .attested_collector_format import MPRRecord, read_ndjson


# ──────────────────────────────────────────────────────────────────────
# Discovery — cached at module load
# ──────────────────────────────────────────────────────────────────────


def _attested_root() -> Path:
    """Resolve the attested-tree root for the current install.

    Looks for ``attested/`` next to this module. Works for both the
    research-tree source (``docs/antikythera-maths/research/``) and
    the mirrored package (``ephemerides_spectral/_research/``).
    """
    return Path(__file__).resolve().parent / "attested"


_DESCRIPTORS_CACHE: Optional[Dict[str, Descriptor]] = None


def _descriptors() -> Dict[str, Descriptor]:
    """Lazy-load + cache the descriptor map for this install."""
    global _DESCRIPTORS_CACHE
    if _DESCRIPTORS_CACHE is None:
        _DESCRIPTORS_CACHE = discover_descriptors(_attested_root())
    return _DESCRIPTORS_CACHE


def _ndjson_path(descriptor: Descriptor) -> Path:
    """Resolve the baseline NDJSON file path for a descriptor.

    The descriptor's ``[schema].data_schema_id`` is used as the
    filename stem; e.g. ``earthref_sc.seamount.v1`` →
    ``seamount.ndjson`` (we strip the source-prefix and version
    suffix, taking the middle as the table name).
    """
    schema_id = str(descriptor.schema["data_schema_id"])
    parts = schema_id.split(".")
    # Convention: <source_key>.<table>.<version>
    table = parts[1] if len(parts) >= 3 else parts[-1]
    return descriptor.path.parent / f"{table}.ndjson"


def _table_name(descriptor: Descriptor) -> str:
    """Resolve the table-name part of the descriptor's data_schema_id.
    Mirrors :func:`_ndjson_path` filename stem."""
    schema_id = str(descriptor.schema["data_schema_id"])
    parts = schema_id.split(".")
    return parts[1] if len(parts) >= 3 else parts[-1]


# ──────────────────────────────────────────────────────────────────────
# T2 — User runtime kernel (v0.25.1+)
# ──────────────────────────────────────────────────────────────────────


_LOCAL_KERNEL_PATH: Optional[Path] = None
"""Currently registered T2 overlay root (or None for T0+T1 only)."""


def use_local_kernel(path: Optional[Path | str]) -> Dict[str, Any]:
    """Register a user-runtime-kernel overlay (T2).

    Parameters
    ----------
    path
        Filesystem path to a directory shaped like
        ``<source_key>/<table>.ndjson``. When None, clears any
        registered overlay (equivalent to :func:`clear_local_kernel`).

    Behaviour
    ---------
    Once registered, queries (``get_attested_dataset`` /
    ``attestation_audit``) consult the overlay directory FIRST. For
    each registered source, if the overlay contains a matching
    ``<source>/<table>.ndjson`` file, it REPLACES the baseline
    NDJSON for that source. Sources with no overlay file fall
    through to the T0+T1 baseline.

    Returns the new local-kernel state for confirmation.
    """
    global _LOCAL_KERNEL_PATH
    if path is None:
        _LOCAL_KERNEL_PATH = None
        return {
            "ok": True,
            "active": False,
            "path": None,
            "message": "T2 overlay cleared; queries return T0+T1 baseline only",
        }
    resolved = Path(path).expanduser().resolve()
    if not resolved.exists():
        return {
            "ok": False,
            "error": f"local kernel path does not exist: {resolved}",
        }
    if not resolved.is_dir():
        return {
            "ok": False,
            "error": f"local kernel path is not a directory: {resolved}",
        }
    _LOCAL_KERNEL_PATH = resolved
    return {
        "ok": True,
        "active": True,
        "path": str(resolved),
        "message": f"T2 overlay registered at {resolved}",
    }


def clear_local_kernel() -> Dict[str, Any]:
    """Remove the registered T2 overlay. Equivalent to
    ``use_local_kernel(None)``."""
    return use_local_kernel(None)


def get_local_kernel_state() -> Dict[str, Any]:
    """Return the current T2 state and per-source cache-hash.

    The cache-hash is SHA-256 over the canonical-serialised list of
    ``(source_key, ndjson_sha256)`` pairs. Used in paper appendices
    to document exactly which rows were used at runtime — papers
    can replay the cache state by recomputing this hash against the
    archived overlay tree.
    """
    descriptors = _descriptors()
    per_source: List[Dict[str, str]] = []
    for key in sorted(descriptors.keys()):
        descriptor = descriptors[key]
        overlay = _overlay_path_for(descriptor)
        if overlay is None or not overlay.exists():
            continue
        per_source.append({
            "source_key": key,
            "table": _table_name(descriptor),
            "overlay_path": str(overlay),
            "overlay_sha256": _file_sha256(overlay),
        })

    canonical = "\n".join(
        f"{e['source_key']}\t{e['overlay_sha256']}" for e in per_source
    )
    cache_hash = hashlib.sha256(canonical.encode("utf-8")).hexdigest()

    return {
        "ok": True,
        "active": _LOCAL_KERNEL_PATH is not None,
        "path": str(_LOCAL_KERNEL_PATH) if _LOCAL_KERNEL_PATH else None,
        "n_overlay_sources": len(per_source),
        "per_source": per_source,
        "cache_hash": cache_hash,
    }


def _overlay_path_for(descriptor: Descriptor) -> Optional[Path]:
    """Resolve the T2 overlay NDJSON path for a descriptor (or
    None when no overlay is registered)."""
    if _LOCAL_KERNEL_PATH is None:
        return None
    return _LOCAL_KERNEL_PATH / descriptor.key / f"{_table_name(descriptor)}.ndjson"


def _file_sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def _resolved_ndjson_path(descriptor: Descriptor) -> Path:
    """Resolve the NDJSON path actually consumed at query time —
    T2 overlay if registered + present, else T0+T1 baseline."""
    overlay = _overlay_path_for(descriptor)
    if overlay is not None and overlay.exists():
        return overlay
    return _ndjson_path(descriptor)


# ──────────────────────────────────────────────────────────────────────
# Bridge surfaces
# ──────────────────────────────────────────────────────────────────────


def list_attested_sources() -> Dict[str, Any]:
    """Enumerate every registered attested source.

    Returns a dict with each source's rendered metadata: human-
    readable name, purpose, license, citation template, adapter,
    and gap-targeting regime labels. Useful for UI source-pickers
    and for the v0.26.x schema-gap-driven trigger.
    """
    descriptors = _descriptors()
    sources: List[Dict[str, Any]] = []
    for key in sorted(descriptors.keys()):
        d = descriptors[key]
        sources.append({
            "key": key,
            "human_readable_name": str(d.source.get("human_readable_name", key)),
            "purpose": str(d.source.get("purpose", "")),
            "license": str(d.source.get("license", "")),
            "homepage": str(d.source.get("homepage", "")),
            "canonical_doi": str(d.source.get("canonical_doi", "")),
            "adapter": d.adapter_name,
            "cite_as_template": str(d.rendering.get("cite_as_template", "")),
            "gap_targeting": dict(d.gap_targeting),
            "data_schema_id": str(d.schema.get("data_schema_id", "")),
        })
    return {
        "ok": True,
        "n_sources": len(sources),
        "sources": sources,
    }


def get_attested_dataset(
    source_key: str,
    *,
    limit: Optional[int] = None,
    offset: int = 0,
    live: bool = False,
) -> Dict[str, Any]:
    """Return paginated row content for a registered source.

    Each row carries its full ``data`` + ``attestation`` +
    ``rendering`` blocks. Use :func:`attestation_audit` for the
    cheap data-block-free variant.

    Parameters
    ----------
    source_key
        The descriptor's ``[source].key`` string.
    limit, offset
        Pagination over the result set.
    live
        *(v0.25.2+)* When ``True``, fetch the source's rows from
        its upstream archive at call time (T3 reproducibility tier)
        instead of reading the committed NDJSON. The fetch uses
        the descriptor's declared adapter; each row is stamped
        with retrieval-time + response checksum + collector-
        descriptor-hash, just like a T1 collector run, plus a
        ``"_tier": "T3"`` discriminator on the returned envelope.
        Defaults to ``False`` (T0+T1+T2 baseline).

    Returns
    -------
    dict
        ``{ok, source_key, total, offset, limit, next_offset, rows}``
        where ``rows`` is a list-of-dict slice. ``next_offset`` is
        ``None`` when the slice extends through end-of-file. T3
        responses also carry ``tier="T3"`` + ``retrieved_at`` +
        ``upstream_response_sha256`` for paper-appendix replay.
    """
    descriptors = _descriptors()
    if source_key not in descriptors:
        return {
            "ok": False,
            "error": f"unknown source_key {source_key!r}",
            "available": sorted(descriptors.keys()),
        }
    descriptor = descriptors[source_key]

    if live:
        return _get_attested_dataset_live(
            descriptor, limit=limit, offset=offset
        )

    ndjson = _resolved_ndjson_path(descriptor)
    if not ndjson.exists():
        return {
            "ok": True,
            "source_key": source_key,
            "tier": "T0+T1+T2",
            "total": 0,
            "offset": offset,
            "limit": limit,
            "next_offset": None,
            "rows": [],
            "note": "no committed NDJSON; first T1 collection pending",
        }

    rows: List[Dict[str, Any]] = []
    total = 0
    for record in read_ndjson(ndjson):
        total += 1
        if total - 1 < offset:
            continue
        if limit is not None and len(rows) >= limit:
            continue
        rows.append({
            "data": dict(record.data),
            "attestation": dict(record.attestation),
            "rendering": dict(record.rendering),
            "data_schema_id": record.data_schema_id,
            "mpr_version": record.mpr_version,
        })

    next_offset: Optional[int]
    if limit is None:
        next_offset = None
    else:
        end = offset + len(rows)
        next_offset = end if end < total else None

    return {
        "ok": True,
        "source_key": source_key,
        "tier": "T0+T1+T2",
        "total": total,
        "offset": offset,
        "limit": limit,
        "next_offset": next_offset,
        "rows": rows,
    }


# ──────────────────────────────────────────────────────────────────────
# T3 — Live query (v0.25.2+)
# ──────────────────────────────────────────────────────────────────────


def _get_attested_dataset_live(
    descriptor: Descriptor,
    *,
    limit: Optional[int],
    offset: int,
) -> Dict[str, Any]:
    """Fetch a source's rows live from upstream (T3 tier).

    Runs the descriptor's declared adapter at call time. The
    composer in ``attested_adapters._base.run`` handles fetch +
    parse + per-row attestation; this function paginates the
    resulting MPRRecord stream and adds the T3 envelope fields.

    Reproducibility: weakest tier. Each row's attestation block
    carries the response_sha256 + retrieved_at the upstream
    *currently* serves; replaying requires re-running the live
    fetch against an unchanged upstream OR archiving the response
    bytes alongside the recorded retrieved_at + sha256.
    """
    import datetime as _dt

    # Lazy-import to keep regenerate.py off the network path.
    from . import attested_adapters as _adapters

    package_version = _read_package_version()
    parser_version = f"ephemerides-spectral {package_version}"
    retrieved_at = _dt.datetime.now(_dt.timezone.utc)

    rows: List[Dict[str, Any]] = []
    total = 0
    upstream_hashes: List[str] = []

    try:
        for record in _adapters.run(
            descriptor,
            parser_version=parser_version,
            retrieved_at=retrieved_at,
        ):
            total += 1
            sha = record.attestation.get("response_sha256", "")
            if sha and sha not in upstream_hashes:
                upstream_hashes.append(sha)
            if total - 1 < offset:
                continue
            if limit is not None and len(rows) >= limit:
                # Keep iterating to compute total when no limit
                # would be respected — but break early on limit
                # to avoid pulling the whole upstream just to
                # count when the consumer only wants `limit`
                # rows. Trade-off: total reflects only the
                # partial fetch consumed.
                continue
            rows.append({
                "data": dict(record.data),
                "attestation": dict(record.attestation),
                "rendering": dict(record.rendering),
                "data_schema_id": record.data_schema_id,
                "mpr_version": record.mpr_version,
            })
    except Exception as exc:  # noqa: BLE001 — surface adapter errors
        return {
            "ok": False,
            "source_key": descriptor.key,
            "tier": "T3",
            "error": f"live fetch failed: {exc}",
            "retrieved_at": retrieved_at.strftime("%Y-%m-%dT%H:%M:%SZ"),
        }

    next_offset: Optional[int]
    if limit is None:
        next_offset = None
    else:
        end = offset + len(rows)
        next_offset = end if end < total else None

    return {
        "ok": True,
        "source_key": descriptor.key,
        "tier": "T3",
        "retrieved_at": retrieved_at.strftime("%Y-%m-%dT%H:%M:%SZ"),
        "upstream_response_sha256s": upstream_hashes,
        "total": total,
        "offset": offset,
        "limit": limit,
        "next_offset": next_offset,
        "rows": rows,
    }


def _read_package_version() -> str:
    """Read the running package's version string. Used in T3
    attestation blocks so consumers can replay against the same
    parser_version that produced the row."""
    try:
        from .. import version as _ver  # type: ignore
        return str(_ver.__version__)
    except Exception:
        return "unknown"


def get_attested_descriptor(source_key: str) -> Dict[str, Any]:
    """Return the full parsed descriptor for one source.

    Used by UI code that wants to render the descriptor's
    ``[rendering]``, ``[source]``, ``[gap_targeting]`` content
    without iterating row data first.
    """
    descriptors = _descriptors()
    if source_key not in descriptors:
        return {
            "ok": False,
            "error": f"unknown source_key {source_key!r}",
            "available": sorted(descriptors.keys()),
        }
    descriptor = descriptors[source_key]
    return {
        "ok": True,
        "source_key": source_key,
        "descriptor": descriptor.to_dict(),
    }


def attestation_audit(source_key: str) -> Dict[str, Any]:
    """Return per-row attestation metadata (no data payload).

    Cheap; paper-appendix-ready. Each row returns its
    ``response_sha256``, ``retrieved_at``, ``parser_version``,
    ``parser_rule_hash``, ``collector_descriptor_hash`` so a
    downstream consumer can reproduce the row's provenance trail.
    """
    descriptors = _descriptors()
    if source_key not in descriptors:
        return {
            "ok": False,
            "error": f"unknown source_key {source_key!r}",
            "available": sorted(descriptors.keys()),
        }
    descriptor = descriptors[source_key]
    ndjson = _resolved_ndjson_path(descriptor)
    if not ndjson.exists():
        return {
            "ok": True,
            "source_key": source_key,
            "n_rows": 0,
            "rows": [],
            "note": "no committed NDJSON; first T1 collection pending",
        }

    rows: List[Dict[str, str]] = []
    for record in read_ndjson(ndjson):
        attestation = dict(record.attestation)
        rows.append({
            "data_schema_id": record.data_schema_id,
            "response_sha256": attestation.get("response_sha256", ""),
            "retrieved_at": attestation.get("retrieved_at", ""),
            "parser_version": attestation.get("parser_version", ""),
            "parser_rule_hash": attestation.get("parser_rule_hash", ""),
            "collector_descriptor_hash": attestation.get(
                "collector_descriptor_hash", ""
            ),
        })
    return {
        "ok": True,
        "source_key": source_key,
        "n_rows": len(rows),
        "rows": rows,
    }


# ──────────────────────────────────────────────────────────────────────
# Streaming — Python-only, NOT bridge-exposed (Pyodide-incompatible)
# ──────────────────────────────────────────────────────────────────────


def iter_attested_dataset(source_key: str) -> Iterator[MPRRecord]:
    """Stream MPRRecords from a registered source's NDJSON.

    NOT bridge-exposed (returns a Python iterator, not JSON-serialisable).
    Use this from Python consumers that need to process large rosters
    (e.g. the eventual ~1,800-row EarthRef SC seamount catalog) without
    materialising the full list.
    """
    descriptors = _descriptors()
    if source_key not in descriptors:
        raise KeyError(f"unknown source_key {source_key!r}")
    descriptor = descriptors[source_key]
    ndjson = _resolved_ndjson_path(descriptor)
    if not ndjson.exists():
        return iter(())
    return read_ndjson(ndjson)


__all__ = [
    "list_attested_sources",
    "get_attested_dataset",
    "get_attested_descriptor",
    "attestation_audit",
    "iter_attested_dataset",
    "use_local_kernel",
    "clear_local_kernel",
    "get_local_kernel_state",
]
