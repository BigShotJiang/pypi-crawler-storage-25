"""
bigboss
=======

This package contains the core implementation of the BigBoss command‑line
tools.  Each module corresponds to a previously standalone script and
exposes a ``main()`` function that accepts an optional iterable of
arguments.  When invoked with ``argv=None`` (the default) the
functions parse command‑line arguments from ``sys.argv``.  When
provided with a sequence of strings the functions parse those
arguments instead.  This dual‑mode behaviour allows the modules to be
used both as standalone command‑line programs and programmatically
from other Python code (including the API defined in ``app.app``).

The following modules are available:

- :mod:`download_all_models`: download llama.cpp binaries and model weights.
- :mod:`summary`: summarise text, PDF and image files in a folder.
- :mod:`compare_sum`: compare an input sentence to existing summaries
  and arrange files into similarity layers.
- :mod:`rearrange_deep`: rearrange selected files/folders into
  clustered priority folders and write a manifest for undo.
- :mod:`derearrange_deep`: undo a deep rearrangement based on its
  manifest.
- :mod:`path_ui`: simple Tkinter drag‑and‑drop path selection GUI.

Example::

    from bigboss.summary import main as summary_main
    summary_main(["/path/to/folder", "--no-bigboss"])

"""

__all__ = [
    "download_all_models",
    "summary",
    "compare_sum",
    "rearrange_deep",
    "derearrange_deep",
    "path_ui",
]

from . import download_all_models  # noqa: F401
from . import summary  # noqa: F401
from . import compare_sum  # noqa: F401
from . import rearrange_deep  # noqa: F401
from . import derearrange_deep  # noqa: F401
from . import path_ui  # noqa: F401