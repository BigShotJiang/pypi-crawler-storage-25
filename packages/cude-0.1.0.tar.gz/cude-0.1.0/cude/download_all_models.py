"""
Download text and vision models for BigBoss.

This module replicates the behaviour of the original ``download_all_models.py``
script.  It provides a :func:`main` function with an optional ``argv``
parameter.  When run from the command line the function parses
arguments from ``sys.argv``; when called programmatically you can
supply a list of arguments instead.
"""

import argparse
import shutil
import zipfile
from pathlib import Path
import requests
from tqdm import tqdm
from huggingface_hub import hf_hub_download, list_repo_files
from transformers import AutoProcessor, AutoModelForCausalLM

# These constants mirror those in the original script.  They are
# resolved relative to the working directory.
LLAMA_DIR = Path("llama")
VISION_DIR = Path("vision") / "florence-2-base"

QWEN_MODELS = [
    ("lm-kit/qwen-3-0.6b-instruct-gguf", "qwen3_0.6b_q4_k_m.gguf"),
    ("lm-kit/qwen-3-1.7b-instruct-gguf", "qwen3_1.7b_q4_k_m.gguf"),
]

FLORENCE_ID = "microsoft/Florence-2-base"


def download_url(url: str, out: Path) -> None:
    """Download a file from ``url`` to ``out`` with a progress bar."""
    out.parent.mkdir(parents=True, exist_ok=True)
    with requests.get(url, stream=True, timeout=60) as r:
        r.raise_for_status()
        total = int(r.headers.get("content-length", 0))
        with open(out, "wb") as f, tqdm(total=total, unit="B", unit_scale=True, desc=out.name) as bar:
            for chunk in r.iter_content(1024 * 1024):
                if chunk:
                    f.write(chunk)
                    bar.update(len(chunk))


def latest_llama_asset(kind: str) -> tuple[str, str]:
    """Return the name and download URL of the latest llama.cpp asset for the given kind."""
    api = "https://api.github.com/repos/ggml-org/llama.cpp/releases/latest"
    data = requests.get(api, timeout=60).json()
    assets = [(a["name"], a["browser_download_url"]) for a in data.get("assets", [])]
    if kind == "cuda":
        must = ["win", "cuda", "x64", ".zip"]
        avoid = ["cudart"]
    else:
        must = ["win", "cpu", "x64", ".zip"]
        avoid = []
    for name, url in assets:
        low = name.lower()
        if all(x in low for x in must) and not any(x in low for x in avoid):
            return name, url
    # If no match, print available assets and raise
    names = "\n".join(f" - {n}" for n, _ in assets)
    raise RuntimeError(f"Cannot find llama.cpp Windows {kind} zip. Available assets:\n{names}")


def download_llama_cpp(kind: str) -> None:
    """Download and extract the appropriate llama.cpp binary bundle."""
    if kind == "skip":
        return
    LLAMA_DIR.mkdir(exist_ok=True)
    name, url = latest_llama_asset(kind)
    zpath = LLAMA_DIR / name
    print(f"[llama.cpp] downloading {name}")
    download_url(url, zpath)
    print("[llama.cpp] extracting")
    with zipfile.ZipFile(zpath, "r") as z:
        z.extractall(LLAMA_DIR)
    # Copy executable to top‑level llama directory if nested
    exe = next(LLAMA_DIR.rglob("llama-cli.exe"), None) or next(LLAMA_DIR.rglob("main.exe"), None)
    if exe and exe.parent != LLAMA_DIR:
        for p in exe.parent.iterdir():
            dst = LLAMA_DIR / p.name
            if p.is_file() and not dst.exists():
                shutil.copy2(p, dst)
    print("[ok] llama.cpp ready")


def q4km_file(repo: str) -> str:
    """Return the name of the quantised GGUF file in a HF repository."""
    files = list_repo_files(repo)
    ggufs = [f for f in files if f.lower().endswith(".gguf")]
    q4 = [f for f in ggufs if "q4_k_m" in f.lower()]
    if not q4:
        raise RuntimeError(f"No Q4_K_M GGUF found in {repo}")
    return sorted(q4, key=len)[0]


def download_qwen_gguf() -> None:
    """Download the quantised Qwen model weights to ``LLAMA_DIR``."""
    LLAMA_DIR.mkdir(exist_ok=True)
    for repo, out_name in QWEN_MODELS:
        fname = q4km_file(repo)
        print(f"[GGUF] {repo} -> {fname}")
        local = Path(hf_hub_download(repo_id=repo, filename=fname, local_dir=LLAMA_DIR))
        out = LLAMA_DIR / out_name
        if local.resolve() != out.resolve():
            shutil.copy2(local, out)
        print(f"[ok] {out}")
    # Copy the largest model to a standard name used by other scripts
    shutil.copy2(LLAMA_DIR / "qwen3_1.7b_q4_k_m.gguf", LLAMA_DIR / "model.gguf")
    print("[ok] default text model = llama/model.gguf")


def download_florence() -> None:
    """Download the Florence‑2 base vision model."""
    print(f"[Florence] downloading {FLORENCE_ID}")
    VISION_DIR.mkdir(parents=True, exist_ok=True)
    processor = AutoProcessor.from_pretrained(FLORENCE_ID, trust_remote_code=True)
    model = AutoModelForCausalLM.from_pretrained(FLORENCE_ID, trust_remote_code=True)
    processor.save_pretrained(VISION_DIR)
    model.save_pretrained(VISION_DIR)
    print(f"[ok] Florence saved to {VISION_DIR}")


def main(argv: list[str] | None = None) -> None:
    """Entry point for the download_all_models command.

    :param argv: optional list of arguments (excluding program name);
                 if ``None`` (default) command‑line arguments are parsed
                 from ``sys.argv``.
    """
    parser = argparse.ArgumentParser()
    parser.add_argument("--llama", choices=["cuda", "cpu", "skip"], default="cuda")
    parser.add_argument("--skip-florence", action="store_true")
    parser.add_argument("--skip-qwen", action="store_true")
    args = parser.parse_args(argv)
    download_llama_cpp(args.llama)
    if not args.skip_qwen:
        download_qwen_gguf()
    if not args.skip_florence:
        download_florence()
    print("\nDONE")
    print("Text model path:   llama/model.gguf")
    print("Vision model path: vision/florence-2-base")
    print('Test llama:')
    print('  llama\\llama-cli.exe -m llama\\model.gguf -p "Summarize: hello world" -n 40')


if __name__ == "__main__":  # pragma: no cover
    main()