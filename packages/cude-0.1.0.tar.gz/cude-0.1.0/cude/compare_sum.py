"""
Compare BigBoss summaries to an input sentence and create nested similarity layers.

This module refactors the original ``compare_sum.py`` script.  It exposes
a ``main`` function that accepts an optional list of arguments.  When run
from the command line the arguments are taken from ``sys.argv``; when
invoked programmatically you can supply a list of strings.  The
function reads summaries produced by ``summary.py``, embeds them using
sentence transformers, ranks them by similarity to a query sentence,
assigns them to layers and optionally rearranges the corresponding
files or copies them into a nested folder structure.  It also
supports optional folder name refinement using an external llama.cpp
model.
"""

import argparse
import json
import re
import shutil
import subprocess
from pathlib import Path
from typing import Any, Dict, List, Tuple, Optional

import numpy as np
from sklearn.metrics.pairwise import cosine_similarity
from sentence_transformers import SentenceTransformer


DEFAULT_SUMMARY = Path("memory") / "llm_file_summaries.jsonl"
DEFAULT_OUT_JSON = Path("memory") / "compare_summary_layers.json"
DEFAULT_OUT_TXT = Path("memory") / "compare_summary_layers.txt"
DEFAULT_REARRANGE_DIR = Path("rearranged_by_summary")
DEFAULT_EMBED_MODEL = "sentence-transformers/all-MiniLM-L6-v2"

LAYER_ORDER = [
    "Layer_1_highest_closest",
    "Layer_2_close",
    "Layer_3_middle",
    "Layer_4_lower",
    "Layer_5_edge_lowest",
]


def clean(x: str) -> str:
    x = x or ""
    x = x.replace("\x00", " ")
    x = re.sub(r"[ \t]+", " ", x)
    x = re.sub(r"\n{3,}", "\n\n", x)
    return x.strip()


def safe_folder_name(x: str, max_len: int = 90) -> str:
    x = clean(x)
    x = re.sub(r"[^a-zA-Z0-9_\- ]+", "", x)
    x = re.sub(r"[\s\-]+", "_", x).strip("_")
    if not x:
        x = "unnamed_folder"
    return x[:max_len]


def unique_path(path: Path) -> Path:
    if not path.exists():
        return path
    stem = path.stem
    suffix = path.suffix
    parent = path.parent
    k = 2
    while True:
        candidate = parent / f"{stem}__copy{k}{suffix}"
        if not candidate.exists():
            return candidate
        k += 1


def progress(i: int, total: int, msg: str) -> None:
    pct = 100.0 * i / max(total, 1)
    print(f"[{i:04d}/{total:04d}] {pct:6.2f}%  {msg}", flush=True)


def load_jsonl(path: Path) -> List[Dict[str, Any]]:
    if not path.exists():
        raise FileNotFoundError(f"Cannot find summary file: {path}")
    rows: List[Dict[str, Any]] = []
    for line in path.read_text(encoding="utf-8", errors="ignore").splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            raw = json.loads(line)
        except Exception:
            continue
        file_name = clean(raw.get("file", ""))
        summary = clean(raw.get("embedding_text") or raw.get("summary") or "")
        if not file_name or not summary:
            continue
        rows.append({
            "file": file_name,
            "type": raw.get("type", ""),
            "summary": summary,
            "raw": raw,
        })
    return rows


def assign_layer(rank_index: int, total: int) -> str:
    q = (rank_index + 1) / max(total, 1)
    if q <= 0.20:
        return "Layer_1_highest_closest"
    if q <= 0.40:
        return "Layer_2_close"
    if q <= 0.60:
        return "Layer_3_middle"
    if q <= 0.80:
        return "Layer_4_lower"
    return "Layer_5_edge_lowest"


def find_llama_cli() -> Optional[Path]:
    for p in [
        Path("llama/llama-cli.exe"),
        Path("llama/main.exe"),
        Path("llama/llama-cli"),
        Path("llama/main"),
    ]:
        if p.exists():
            return p
    return None


def ask_llama(prompt: str, model: Path, ctx: int = 4096, n: int = 80) -> str:
    cli = find_llama_cli()
    if not cli or not model.exists():
        return ""
    cmd = [
        str(cli),
        "-m", str(model),
        "-c", str(ctx),
        "-n", str(n),
        "--temp", "0.1",
        "-p", prompt,
    ]
    try:
        r = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="ignore",
            timeout=180,
        )
        if r.returncode != 0:
            return ""
        out = clean(r.stdout)
        if out.startswith(prompt):
            out = out[len(prompt):]
        return clean(out)
    except Exception:
        return ""


def simple_folder_name(layer: str, items: List[Dict[str, Any]]) -> str:
    stop = {
        "this", "file", "summary", "contains", "about", "with", "from", "that",
        "into", "and", "the", "for", "one", "sentence", "image", "text", "pdf",
        "data", "using", "based", "shows", "describes", "includes", "folder",
        "system", "files",
    }
    text = " ".join((x["file"] + " " + x["summary"]) for x in items).lower()
    freq: Dict[str, int] = {}
    for w in re.findall(r"[a-zA-Z][a-zA-Z0-9_]{2,}", text):
        if w not in stop:
            freq[w] = freq.get(w, 0) + 1
    top = [w for w, _ in sorted(freq.items(), key=lambda kv: kv[1], reverse=True)[:4]]
    suffix = "_".join(top) if top else "mixed_files"
    return safe_folder_name(f"{layer}__{suffix}")


def llama_folder_name(layer: str, items: List[Dict[str, Any]], model: Path) -> str:
    small = items[:25]
    content = "\n".join(
        f"- {x['file']}: {x['summary'][:450]}" for x in small
    )
    prompt = f"""You name folders for a nested file organization system.

Meaning:
- Layer_1 is closest to the user's sentence and should be the outer folder.
- Higher layer = more important.
- Lower layer = deeper inside folder and more edge/less related.

Task:
Based on the file summaries inside this layer, create the best short folder name.

Rules:
- 2 to 5 words only.
- Use safe folder name style with underscores.
- No punctuation except underscore.
- No explanation.
- Do not include the word folder.
- Keep the meaning of the files in this layer.

Layer:
{layer}

Files:
{content}

Best folder name:"""
    out = ask_llama(prompt, model=model, ctx=4096, n=60)
    out = clean(out).splitlines()[0].strip() if out else ""
    out = safe_folder_name(out)
    if not out or len(out) < 3:
        return simple_folder_name(layer, items)
    return safe_folder_name(f"{layer}__{out}")


def layer_depth_path(base: Path, layer_folders: Dict[str, str], target_layer: str) -> Path:
    p = base
    for layer in LAYER_ORDER:
        if layer not in layer_folders:
            continue
        p = p / layer_folders[layer]
        if layer == target_layer:
            break
    return p


def build_nested_structure(
    root: Path,
    base_out: Path,
    layers: Dict[str, Dict[str, Any]],
    mode: str,
) -> Dict[str, Any]:
    print("\n[build] creating nested folder structure...")
    layer_folders = {layer: data["folder_name"] for layer, data in layers.items()}
    # create all nested folders first
    p = base_out
    for layer in LAYER_ORDER:
        if layer in layer_folders:
            p = p / layer_folders[layer]
            p.mkdir(parents=True, exist_ok=True)
    all_items: List[Tuple[str, Dict[str, Any]]] = []
    for layer in LAYER_ORDER:
        for item in layers.get(layer, {}).get("files", []):
            all_items.append((layer, item))
    total = len(all_items)
    copied: List[Dict[str, Any]] = []
    missing: List[Dict[str, Any]] = []
    for i, (layer, item) in enumerate(all_items, 1):
        src = root / item["file"]
        dest_dir = layer_depth_path(base_out, layer_folders, layer)
        dest_dir.mkdir(parents=True, exist_ok=True)
        if not src.exists():
            progress(i, total, f"MISSING source={src}")
            missing.append({"layer": layer, "file": item["file"]})
            continue
        dest = unique_path(dest_dir / src.name)
        if mode == "move":
            shutil.move(str(src), str(dest))
            action = "moved"
        else:
            shutil.copy2(str(src), str(dest))
            action = "copied"
        item["new_path"] = str(dest)
        item["layer_depth_folder"] = str(dest_dir)
        copied.append({"layer": layer, "source": str(src), "new_path": str(dest)})
        progress(i, total, f"{action} -> {dest}")
    return {
        "mode": mode,
        "base_out": str(base_out),
        "copied_or_moved_count": len(copied),
        "missing_count": len(missing),
        "missing": missing,
        "items": copied,
    }


def make_text_report(query: str, result: Dict[str, Any]) -> str:
    lines: List[str] = []
    lines.append("BigBoss Compare Summary Nested Layer Report")
    lines.append("=" * 50)
    lines.append(f"Query: {query}")
    lines.append("")
    lines.append("Meaning:")
    lines.append("Layer_1 = closest to your sentence, outside/top folder")
    lines.append("Layer_5 = edge/least close, deepest inside folder")
    lines.append("")
    if "rearrange" in result:
        lines.append(f"Rearranged output: {result['rearrange']['base_out']}")
        lines.append(f"Mode: {result['rearrange']['mode']}")
        lines.append("")
    for layer_name in LAYER_ORDER:
        if layer_name not in result["layers"]:
            continue
        layer = result["layers"][layer_name]
        lines.append(layer_name)
        lines.append("-" * len(layer_name))
        lines.append(f"Folder name: {layer['folder_name']}")
        lines.append(f"File count: {len(layer['files'])}")
        lines.append("")
        for x in layer["files"]:
            lines.append(f"score={x['score']:.4f} | {x['file']}")
            if x.get("new_path"):
                lines.append(f"  new_path: {x['new_path']}")
            lines.append(f"  summary: {x['summary']}")
        lines.append("")
    return "\n".join(lines)


def main(argv: List[str] | None = None) -> None:
    ap = argparse.ArgumentParser(
        description="Compare BigBoss summaries, create nested higher/lower layer folders, and copy/move files."
    )
    ap.add_argument("sentence", help="Input sentence/query to compare against file and picture summaries")
    ap.add_argument("--root", required=True, help="Original folder containing files summarised by summary.py")
    ap.add_argument("--summary", default=str(DEFAULT_SUMMARY), help="summary.py output jsonl")
    ap.add_argument("--embed-model", default=DEFAULT_EMBED_MODEL)
    ap.add_argument("--llm-model", default="llama/model.gguf")
    ap.add_argument("--no-llm-folder-name", action="store_true")
    ap.add_argument("--out-dir", default=str(DEFAULT_REARRANGE_DIR))
    ap.add_argument("--mode", choices=["copy", "move"], default="copy")
    ap.add_argument("--report-only", action="store_true", help="only create JSON/TXT report, do not copy/move files")
    ap.add_argument("--out-json", default=str(DEFAULT_OUT_JSON))
    ap.add_argument("--out-txt", default=str(DEFAULT_OUT_TXT))
    args = ap.parse_args(argv)

    query = clean(args.sentence)
    root = Path(args.root).expanduser().resolve()
    summary_path = Path(args.summary).expanduser().resolve()
    out_json = Path(args.out_json).expanduser().resolve()
    out_txt = Path(args.out_txt).expanduser().resolve()
    base_out = Path(args.out_dir).expanduser().resolve()
    llm_model = Path(args.llm_model).expanduser().resolve()
    out_json.parent.mkdir(parents=True, exist_ok=True)
    out_txt.parent.mkdir(parents=True, exist_ok=True)

    print("[compare_sum.py] loading summaries...")
    rows = load_jsonl(summary_path)
    if not rows:
        raise RuntimeError("No usable summaries found. Run summary.py first.")
    print(f"[compare_sum.py] loaded {len(rows)} summaries")
    print(f"[compare_sum.py] root folder: {root}")
    print(f"[compare_sum.py] output folder: {base_out}")
    print(f"[compare_sum.py] loading embedding model: {args.embed_model}")
    emb_model = SentenceTransformer(args.embed_model)
    total = len(rows)
    texts: List[str] = []
    for i, r in enumerate(rows, 1):
        progress(i, total, f"prepare embedding text: {r['file']}")
        texts.append(f"{r['file']} -- {r['summary']}")
    print("[compare_sum.py] embedding input sentence...")
    q_emb = emb_model.encode([query], normalize_embeddings=True)
    print("[compare_sum.py] embedding all file/image summaries...")
    file_embs = emb_model.encode(texts, normalize_embeddings=True, show_progress_bar=True)
    print("[compare_sum.py] calculating similarity...")
    scores = cosine_similarity(q_emb, file_embs)[0]
    ranked: List[Dict[str, Any]] = []
    for i, (r, score) in enumerate(zip(rows, scores), 1):
        progress(i, total, f"score={float(score):.4f} file={r['file']}")
        ranked.append({
            "file": r["file"],
            "type": r.get("type", ""),
            "summary": r["summary"],
            "score": float(score),
        })
    ranked.sort(key=lambda x: x["score"], reverse=True)
    grouped: Dict[str, List[Dict[str, Any]]] = {}
    for idx, item in enumerate(ranked):
        layer = assign_layer(idx, len(ranked))
        grouped.setdefault(layer, []).append(item)
    print("\n[compare_sum.py] refining layer folder names...")
    layers: Dict[str, Dict[str, Any]] = {}
    for i, layer in enumerate(LAYER_ORDER, 1):
        items = grouped.get(layer, [])
        if not items:
            continue
        progress(i, len(LAYER_ORDER), f"name folder for {layer}")
        if args.no_llm_folder_name:
            folder_name = simple_folder_name(layer, items)
        else:
            folder_name = llama_folder_name(layer, items, llm_model)
        layers[layer] = {
            "folder_name": folder_name,
            "files": items,
        }
    result: Dict[str, Any] = {
        "query": query,
        "root": str(root),
        "summary_source": str(summary_path),
        "embedding_model": args.embed_model,
        "idea": {
            "higher_layer": "closer to input sentence, placed outside/top folder",
            "lower_layer": "less close / edge, placed deeper inside folder",
        },
        "layer_order": LAYER_ORDER,
        "layer_rule": {
            "Layer_1_highest_closest": "top 20% most similar to query",
            "Layer_2_close": "20-40%",
            "Layer_3_middle": "40-60%",
            "Layer_4_lower": "60-80%",
            "Layer_5_edge_lowest": "bottom 20%, edge / least related",
        },
        "layers": layers,
    }
    if not args.report_only:
        rearrange_info = build_nested_structure(
            root=root,
            base_out=base_out,
            layers=layers,
            mode=args.mode,
        )
        result["rearrange"] = rearrange_info
    else:
        print("[report-only] no files copied or moved.")
    out_json.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    out_txt.write_text(make_text_report(query, result), encoding="utf-8")
    print("\n[DONE]")
    print(f"JSON saved: {out_json}")
    print(f"TXT saved:  {out_txt}")
    if not args.report_only:
        print(f"Nested folder output: {base_out}")
    print("\nTop closest files:")
    for x in ranked[:10]:
        print(f"{x['score']:.4f}  {x['file']}")


if __name__ == "__main__":  # pragma: no cover
    main()