"""
Undo deep rearrangements produced by ``rearrange_deep.py``.

This module exposes a ``main`` function that accepts an optional list
of arguments.  When invoked programmatically you can supply
``argv``; when run as a script the function parses command‑line
arguments from ``sys.argv``.  It reads the JSON manifest produced by
``rearrange_deep.py``, moves files back to their original locations and
optionally extracts archived items and removes empty folders.
"""

import argparse
import json
import shutil
import zipfile
from pathlib import Path


def unique_path(path: Path) -> Path:
    if not path.exists():
        return path
    parent, stem, suffix = path.parent, path.stem, path.suffix
    i = 2
    while True:
        p = parent / f"{stem}_restored_{i}{suffix}"
        if not p.exists():
            return p
        i += 1


def abs_from_root(root: Path, rel_path: str) -> Path:
    return root / rel_path.replace("/", "\\")


def move_back(root: Path, src_rel: str, dst_rel: str, dry_run: bool) -> None:
    src = abs_from_root(root, src_rel)
    dst = unique_path(abs_from_root(root, dst_rel))
    if not src.exists():
        print(f"SKIP missing: {src}")
        return
    if dry_run:
        print(f"WOULD RESTORE: {src} -> {dst}")
        return
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.move(str(src), str(dst))
    print(f"RESTORED: {src} -> {dst}")


def restore_archived_removed(root: Path, op: dict, dry_run: bool) -> None:
    if not op.get("remove_original"):
        return
    zip_path = abs_from_root(root, op["zip_path"])
    if not zip_path.exists():
        print(f"SKIP missing zip: {zip_path}")
        return
    print(f"[ZIP RESTORE] {zip_path}")
    with zipfile.ZipFile(zip_path, "r") as z:
        names = set(z.namelist())
        for item in op.get("items", []):
            arc = item.get("arcname", item["original_path"])
            dst = abs_from_root(root, item["original_path"])
            if arc not in names:
                print(f"  SKIP missing in zip: {arc}")
                continue
            if dst.exists():
                print(f"  SKIP already exists: {dst}")
                continue
            if dry_run:
                print(f"  WOULD EXTRACT: {arc} -> {dst}")
            else:
                dst.parent.mkdir(parents=True, exist_ok=True)
                z.extract(arc, root)
                print(f"  EXTRACTED: {arc}")


def remove_empty_folders(root: Path, dry_run: bool) -> None:
    folders = [p for p in root.rglob("*") if p.is_dir()]
    folders.sort(key=lambda p: len(p.relative_to(root).parts), reverse=True)
    for f in folders:
        try:
            if any(f.iterdir()):
                continue
        except PermissionError:
            continue
        if dry_run:
            print(f"WOULD REMOVE EMPTY: {f}")
        else:
            try:
                f.rmdir()
                print(f"REMOVED EMPTY: {f}")
            except OSError:
                pass


def main(argv: list[str] | None = None) -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--manifest", required=True)
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--remove-empty-folders", action="store_true")
    args = ap.parse_args(argv)
    manifest_path = Path(args.manifest).expanduser().resolve()
    data = json.loads(manifest_path.read_text(encoding="utf-8"))
    root = Path(data["root"]).expanduser().resolve()
    print(f"[ROOT] {root}")
    print(f"[MODE] {'DRY RUN' if args.dry_run else 'RESTORE'}")
    operations = data.get("operations", [])
    print("\n[STEP 1] Restore moved items")
    for op in reversed(operations):
        if op.get("type") != "priority_cluster_move":
            continue
        for mv in reversed(op.get("moves", [])):
            move_back(root, mv["dest_path"], mv["source_path"], args.dry_run)
    print("\n[STEP 2] Restore archive-removed items")
    for op in reversed(operations):
        if op.get("type") == "archive_zip":
            restore_archived_removed(root, op, args.dry_run)
    if args.remove_empty_folders:
        print("\n[STEP 3] Remove empty folders")
        remove_empty_folders(root, args.dry_run)
    print("\nOK")


if __name__ == "__main__":  # pragma: no cover
    main()