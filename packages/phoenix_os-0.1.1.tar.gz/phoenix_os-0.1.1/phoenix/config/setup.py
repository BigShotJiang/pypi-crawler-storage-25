"""First-run setup wizard -- model selection and API key configuration."""

import getpass
import os
from pathlib import Path

from phoenix.config.secrets import get_secret, store_secret

_PHOENIX_DIR = Path(os.environ.get("PHOENIX_DIR", Path.home() / ".phoenix"))
_CONFIG_FILE = _PHOENIX_DIR / "config.yaml"

# Colors
DIM = "\033[2m"
BOLD = "\033[1m"
CYAN = "\033[36m"
GREEN = "\033[32m"
YELLOW = "\033[33m"
RED = "\033[31m"
BRIGHT_BLACK = "\033[90m"
RESET = "\033[0m"

BOX_H = "\u2500"
BOX_V = "\u2502"
BOX_TL = "\u256d"
BOX_TR = "\u256e"
BOX_BL = "\u2570"
BOX_BR = "\u256f"
ICON_DOT = "\u2022"
ICON_OK = "\u2713"
ICON_KEY = "\u2756"

PROVIDERS = [
    {
        "name": "Anthropic",
        "desc": "Claude Sonnet, Opus, Haiku",
        "key": "anthropic",
        "env_var": "ANTHROPIC_API_KEY",
        "models": [
            ("anthropic:claude-sonnet-4-20250514", "Sonnet 4 -- balanced"),
            ("anthropic:claude-opus-4-20250514", "Opus 4 -- strongest"),
            ("anthropic:claude-haiku-4-20250514", "Haiku 4 -- fastest"),
        ],
        "default": 0,
        "needs_key": True,
        "key_url": "https://console.anthropic.com/settings/keys",
    },
    {
        "name": "OpenAI",
        "desc": "GPT-4o, o3-mini",
        "key": "openai",
        "env_var": "OPENAI_API_KEY",
        "models": [
            ("openai:gpt-4o", "GPT-4o -- flagship"),
            ("openai:gpt-4o-mini", "GPT-4o mini -- fast"),
            ("openai:o3-mini", "o3-mini -- reasoning"),
        ],
        "default": 0,
        "needs_key": True,
        "key_url": "https://platform.openai.com/api-keys",
    },
    {
        "name": "Google Gemini",
        "desc": "Gemini Flash, Pro",
        "key": "google",
        "env_var": "GEMINI_API_KEY",
        "models": [
            ("google-gla:gemini-2.0-flash", "Flash -- fast"),
            ("google-gla:gemini-2.5-pro-preview-06-05", "Pro -- advanced"),
        ],
        "default": 0,
        "needs_key": True,
        "key_url": "https://aistudio.google.com/apikey",
    },
    {
        "name": "Groq",
        "desc": "Fast inference, free tier",
        "key": "groq",
        "env_var": "GROQ_API_KEY",
        "models": [
            ("groq:llama-3.3-70b-versatile", "Llama 3.3 70B"),
            ("groq:llama-3.1-8b-instant", "Llama 3.1 8B -- instant"),
            ("groq:mixtral-8x7b-32768", "Mixtral 8x7B"),
        ],
        "default": 0,
        "needs_key": True,
        "key_url": "https://console.groq.com/keys",
    },
    {
        "name": "Ollama",
        "desc": "Local, free, no API key",
        "key": "ollama",
        "env_var": None,
        "models": [
            ("ollama:llama3:8b", "Llama 3 8B"),
            ("ollama:mistral:7b", "Mistral 7B"),
            ("ollama:codellama:13b", "Code Llama 13B"),
        ],
        "default": 0,
        "needs_key": False,
        "key_url": None,
    },
    {
        "name": "Mistral",
        "desc": "Mistral Large, Small",
        "key": "mistral",
        "env_var": "MISTRAL_API_KEY",
        "models": [
            ("mistral:mistral-large-latest", "Large -- flagship"),
            ("mistral:mistral-small-latest", "Small -- efficient"),
        ],
        "default": 0,
        "needs_key": True,
        "key_url": "https://console.mistral.ai/api-keys",
    },
    {
        "name": "DeepSeek",
        "desc": "DeepSeek Chat, Reasoner",
        "key": "deepseek",
        "env_var": "DEEPSEEK_API_KEY",
        "models": [
            ("deepseek:deepseek-chat", "Chat"),
            ("deepseek:deepseek-reasoner", "Reasoner"),
        ],
        "default": 0,
        "needs_key": True,
        "key_url": "https://platform.deepseek.com/api_keys",
    },
]


def needs_setup() -> bool:
    """Check if first-run setup is needed."""
    if _CONFIG_FILE.exists():
        return False
    if os.environ.get("PHOENIX_MODEL"):
        return False
    for p in PROVIDERS:
        if p["env_var"] and os.environ.get(p["env_var"]):
            return False
    return True


def _prompt(msg: str) -> str:
    """Styled input prompt."""
    try:
        return input(f"  {GREEN}{BOLD}>{RESET} {msg}").strip()
    except (KeyboardInterrupt, EOFError):
        return ""


def _step_header(step: int, total: int, title: str):
    print()
    print(f"  {BRIGHT_BLACK}[{step}/{total}]{RESET} {BOLD}{title}{RESET}")
    print()


def run_setup() -> dict | None:
    """Run interactive setup wizard."""
    w = 60
    bar = BOX_H * w

    print()
    print(f"  {DIM}{BOX_TL}{bar}{BOX_TR}{RESET}")
    print(f"  {DIM}{BOX_V}{RESET} {BOLD}Phoenix Setup{RESET}")
    print(f"  {DIM}{BOX_V}{RESET}")
    print(
        f"  {DIM}{BOX_V}{RESET} {BRIGHT_BLACK}First-time configuration. API keys are stored{RESET}"
    )
    print(f"  {DIM}{BOX_V}{RESET} {BRIGHT_BLACK}securely in your OS keychain.{RESET}")
    print(f"  {DIM}{BOX_BL}{bar}{BOX_BR}{RESET}")

    # -- Step 1: Provider --
    _step_header(1, 3, "Choose a provider")

    for i, p in enumerate(PROVIDERS, 1):
        name = p["name"]
        desc = p["desc"]
        if not p["needs_key"]:
            badge = f" {GREEN}free{RESET}"
        else:
            badge = ""
        print(f"    {CYAN}{i}{RESET}  {name}{badge}  {BRIGHT_BLACK}{desc}{RESET}")
    print()

    provider = None
    while provider is None:
        choice = _prompt(f"Provider (1-{len(PROVIDERS)}): ")
        if not choice:
            print(f"\n  {DIM}Setup cancelled.{RESET}\n")
            return None
        try:
            idx = int(choice) - 1
            if 0 <= idx < len(PROVIDERS):
                provider = PROVIDERS[idx]
        except ValueError:
            pass
        if provider is None:
            print(f"    {RED}Invalid choice.{RESET}")

    print(f"    {ICON_OK} {provider['name']}")

    # -- Step 2: Model --
    _step_header(2, 3, "Choose a model")

    models = provider["models"]
    for i, (model_id, desc) in enumerate(models, 1):
        default = f" {GREEN}(default){RESET}" if i == 1 else ""
        print(f"    {CYAN}{i}{RESET}  {model_id}  {BRIGHT_BLACK}{desc}{RESET}{default}")
    print()

    model = None
    while model is None:
        choice = _prompt(f"Model (1-{len(models)}) or Enter for default: ")
        if not choice:
            model = models[provider["default"]][0]
            break
        if choice == "":
            print(f"\n  {DIM}Setup cancelled.{RESET}\n")
            return None
        try:
            idx = int(choice) - 1
            if 0 <= idx < len(models):
                model = models[idx][0]
        except ValueError:
            pass
        if model is None:
            print(f"    {RED}Invalid choice.{RESET}")

    print(f"    {ICON_OK} {model}")

    # -- Step 3: API key --
    api_key = None
    if provider["needs_key"]:
        _step_header(3, 3, "API key")

        env_var = provider["env_var"]
        existing = get_secret(env_var)

        if existing:
            masked = existing[:6] + "..." + existing[-4:]
            print(f"    {BRIGHT_BLACK}Existing key: {masked}{RESET}")
            keep = _prompt("Keep this key? (Y/n): ")
            if keep.lower() not in ("n", "no"):
                api_key = existing

        if api_key is None:
            if provider.get("key_url"):
                print(f"    {BRIGHT_BLACK}Get your key: {provider['key_url']}{RESET}")
                print()

            try:
                api_key = getpass.getpass(
                    f"  {GREEN}{BOLD}>{RESET} Paste {provider['name']} API key: "
                )
            except (KeyboardInterrupt, EOFError):
                print(f"\n  {DIM}Setup cancelled.{RESET}\n")
                return None

            if not api_key.strip():
                print(f"    {RED}No key entered.{RESET}\n")
                return None
            api_key = api_key.strip()

        store_secret(env_var, api_key)
        os.environ[env_var] = api_key
        print(f"    {GREEN}{ICON_OK} Key stored in OS keychain{RESET}")
    else:
        print()
        print(f"  {BRIGHT_BLACK}[3/3]{RESET} {BOLD}API key{RESET}  {GREEN}not needed{RESET}")

    # -- Save config --
    config = {"model": model, "provider": provider["key"]}
    _save_config(config)

    print()
    print(f"  {DIM}{BOX_TL}{bar}{BOX_TR}{RESET}")
    print(
        f"  {DIM}{BOX_V}{RESET} {GREEN}{BOLD}"
        f"Ready.{RESET} {BRIGHT_BLACK}"
        f"Run 'phoenix --setup' to reconfigure.{RESET}"
    )
    print(f"  {DIM}{BOX_BL}{bar}{BOX_BR}{RESET}")
    print()

    return config


def load_config() -> dict:
    """Load saved config."""
    if not _CONFIG_FILE.exists():
        return {}
    try:
        import yaml

        return yaml.safe_load(_CONFIG_FILE.read_text()) or {}
    except Exception:
        return {}


def _save_config(config: dict):
    _PHOENIX_DIR.mkdir(parents=True, exist_ok=True)
    try:
        import yaml

        _CONFIG_FILE.write_text(yaml.dump(config, default_flow_style=False))
    except ImportError:
        lines = [f"{k}: {v}" for k, v in config.items()]
        _CONFIG_FILE.write_text("\n".join(lines) + "\n")


def apply_config():
    """Load saved config and apply. Called at startup."""
    config = load_config()
    if not config:
        return

    model = config.get("model")
    if model and not os.environ.get("PHOENIX_MODEL"):
        os.environ["PHOENIX_MODEL"] = model
        from phoenix.config.settings import set_model

        set_model(model)
