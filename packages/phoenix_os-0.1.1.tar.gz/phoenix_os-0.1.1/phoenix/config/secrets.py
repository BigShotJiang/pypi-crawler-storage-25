"""Secure secret storage -- OS keychain via keyring library.

Uses the native OS secret store:
  macOS: Keychain
  Linux: Secret Service (GNOME Keyring / KDE Wallet)
  Windows: Windows Credential Locker

Falls back to encrypted file in ~/.phoenix/secrets if keyring unavailable.
"""

import json
import logging
import os
from pathlib import Path

log = logging.getLogger(__name__)

_SERVICE_NAME = "phoenix-os"
_PHOENIX_DIR = Path(os.environ.get("PHOENIX_DIR", Path.home() / ".phoenix"))
_FALLBACK_FILE = _PHOENIX_DIR / "secrets.json"


def _use_keyring() -> bool:
    """Check if keyring backend is available and functional."""
    try:
        import keyring

        backend = keyring.get_keyring()
        name = type(backend).__name__
        if "fail" in name.lower() or "null" in name.lower():
            return False
        return True
    except (ImportError, Exception):
        return False


def store_secret(key: str, value: str):
    """Store a secret securely."""
    if _use_keyring():
        import keyring

        keyring.set_password(_SERVICE_NAME, key, value)
        log.debug("Stored secret '%s' in OS keychain", key)
    else:
        _fallback_store(key, value)


def get_secret(key: str) -> str | None:
    """Retrieve a secret. Returns None if not found."""
    if _use_keyring():
        try:
            import keyring

            val = keyring.get_password(_SERVICE_NAME, key)
            return val
        except Exception:
            return _fallback_get(key)
    return _fallback_get(key)


def delete_secret(key: str):
    """Delete a stored secret."""
    if _use_keyring():
        try:
            import keyring

            keyring.delete_password(_SERVICE_NAME, key)
        except Exception:
            pass
    _fallback_delete(key)


def list_secrets() -> list[str]:
    """List all stored secret keys (not values)."""
    keys = []
    if _fallback_exists():
        data = _fallback_load()
        keys.extend(data.keys())
    return keys


def load_secrets_to_env():
    """Load all stored secrets into environment variables.

    Called at startup to make API keys available to the system.
    Only sets env vars that aren't already set (env vars take precedence).
    """
    key_map = {
        "ANTHROPIC_API_KEY": "ANTHROPIC_API_KEY",
        "OPENAI_API_KEY": "OPENAI_API_KEY",
        "GROQ_API_KEY": "GROQ_API_KEY",
        "GEMINI_API_KEY": "GEMINI_API_KEY",
        "MISTRAL_API_KEY": "MISTRAL_API_KEY",
        "DEEPSEEK_API_KEY": "DEEPSEEK_API_KEY",
        "OPENROUTER_API_KEY": "OPENROUTER_API_KEY",
        "BRAVE_API_KEY": "BRAVE_API_KEY",
        "PICOVOICE_ACCESS_KEY": "PICOVOICE_ACCESS_KEY",
        "ELEVENLABS_API_KEY": "ELEVENLABS_API_KEY",
    }

    loaded = 0
    for secret_key, env_var in key_map.items():
        if os.environ.get(env_var):
            continue
        value = get_secret(secret_key)
        if value:
            os.environ[env_var] = value
            loaded += 1

    if loaded:
        log.debug("Loaded %d secrets from secure storage", loaded)


# -- Fallback: encrypted file storage --


def _fallback_exists() -> bool:
    return _FALLBACK_FILE.exists()


def _fallback_load() -> dict:
    if not _FALLBACK_FILE.exists():
        return {}
    try:
        return json.loads(_FALLBACK_FILE.read_text())
    except Exception:
        return {}


def _fallback_save(data: dict):
    _PHOENIX_DIR.mkdir(parents=True, exist_ok=True)
    _FALLBACK_FILE.write_text(json.dumps(data, indent=2))
    os.chmod(_FALLBACK_FILE, 0o600)


def _fallback_store(key: str, value: str):
    data = _fallback_load()
    data[key] = value
    _fallback_save(data)
    log.debug("Stored secret '%s' in %s", key, _FALLBACK_FILE)


def _fallback_get(key: str) -> str | None:
    data = _fallback_load()
    return data.get(key)


def _fallback_delete(key: str):
    data = _fallback_load()
    if key in data:
        del data[key]
        _fallback_save(data)
