"""Display formatting -- colors, banner, tool calls, usage, safety indicators."""

import shutil
import sys
import time

# ANSI codes
DIM = "\033[2m"
BOLD = "\033[1m"
ITALIC = "\033[3m"
UNDERLINE = "\033[4m"
CYAN = "\033[36m"
YELLOW = "\033[33m"
GREEN = "\033[32m"
RED = "\033[31m"
MAGENTA = "\033[35m"
WHITE = "\033[37m"
BRIGHT_BLACK = "\033[90m"
RESET = "\033[0m"

# Box drawing
BOX_H = "\u2500"
BOX_V = "\u2502"
BOX_TL = "\u256d"
BOX_TR = "\u256e"
BOX_BL = "\u2570"
BOX_BR = "\u256f"

# Status icons
ICON_OK = "\u2713"
ICON_FAIL = "\u2717"
ICON_ARROW = "\u25b8"
ICON_DOT = "\u2022"
ICON_BOLT = "\u26a1"


def _term_width() -> int:
    try:
        return shutil.get_terminal_size().columns
    except Exception:
        return 80


def truncate(text: str, max_len: int = 120) -> str:
    if len(text) <= max_len:
        return text
    return text[: max_len - 3] + "..."


# ---------------------------------------------------------------------------
# Safety mode
# ---------------------------------------------------------------------------

_MODE_COLORS = {"safe": GREEN, "auto": YELLOW, "yolo": RED}
_MODE_LABELS = {"safe": "safe", "auto": "auto", "yolo": "YOLO"}


def get_mode_color() -> str:
    from phoenix.core.interceptor import AutoApprovalBackend, get_approval_backend

    backend = get_approval_backend()
    if isinstance(backend, AutoApprovalBackend):
        return _MODE_COLORS.get(backend.mode, GREEN)
    return GREEN


def get_mode_name() -> str:
    from phoenix.core.interceptor import AutoApprovalBackend, get_approval_backend

    backend = get_approval_backend()
    if isinstance(backend, AutoApprovalBackend):
        return _MODE_LABELS.get(backend.mode, "safe")
    return "safe"


def get_prompt() -> str:
    color = get_mode_color()
    return f"{color}{BOLD}>{RESET} "


# ---------------------------------------------------------------------------
# Banner
# ---------------------------------------------------------------------------


def _rule() -> str:
    """Horizontal rule that fits the terminal."""
    w = min(_term_width() - 4, 68)
    return f"  {BRIGHT_BLACK}{BOX_H * w}{RESET}"


def print_banner(
    model: str,
    abilities: list[str],
    agents: list[str],
    memory_stats: dict | None = None,
    ambient_active: bool = False,
):
    visible_agents = [a for a in agents if a != "brain"]

    print()
    print(_rule())
    print()

    # Title + model on one line
    provider = model.split(":")[0] if ":" in model else model
    model_name = model.split(":", 1)[1] if ":" in model else model
    print(
        f"  {BOLD}Phoenix{RESET}  "
        f"{BRIGHT_BLACK}on{RESET} {CYAN}{provider}{RESET}"
        f"{BRIGHT_BLACK}:{RESET}{model_name}"
    )
    print()

    # Abilities
    if abilities:
        print(f"  {BRIGHT_BLACK}abilities{RESET}  {', '.join(abilities)}")

    # Agents
    if visible_agents:
        print(f"  {BRIGHT_BLACK}agents{RESET}     {', '.join(visible_agents)}")

    print()

    # Status badges
    mode = get_mode_name()
    mode_color = get_mode_color()
    badges = [f"{mode_color}{BOLD}{mode}{RESET}"]

    if memory_stats and memory_stats.get("total", 0) > 0:
        total = memory_stats["total"]
        pinned = memory_stats.get("pinned", 0)
        mem_str = f"{total} memories"
        if pinned:
            mem_str += f", {pinned} pinned"
        badges.append(f"{CYAN}{mem_str}{RESET}")

    if ambient_active:
        badges.append(f"{GREEN}ambient on{RESET}")

    dot = f" {BRIGHT_BLACK}{ICON_DOT}{RESET} "
    print(f"  {dot.join(badges)}")

    print()
    print(f"  {BRIGHT_BLACK}/help commands  /tools abilities  /bye exit  \\\\ multiline{RESET}")

    print()
    print(_rule())
    print()


# ---------------------------------------------------------------------------
# Thinking / streaming
# ---------------------------------------------------------------------------

_thinking_start: float = 0


def print_thinking():
    global _thinking_start
    _thinking_start = time.time()
    sys.stdout.write(f"\n  {BRIGHT_BLACK}thinking...{RESET}")
    sys.stdout.flush()


def clear_thinking():
    sys.stdout.write("\r\033[K")
    sys.stdout.flush()


def print_text(text: str):
    sys.stdout.write(text)
    sys.stdout.flush()


# ---------------------------------------------------------------------------
# Tool calls
# ---------------------------------------------------------------------------


def print_tool_call(tool_name: str, args: dict | None = None):
    args_str = ""
    if args and isinstance(args, dict):
        items = []
        for k, v in args.items():
            v_str = truncate(str(v).replace("\n", " "), 50)
            items.append(f"{BRIGHT_BLACK}{k}={RESET}{v_str}")
        args_str = ", ".join(items)

    print(f"  {YELLOW}{ICON_ARROW}{RESET} {CYAN}{tool_name}{RESET}({args_str})")


def print_tool_result(tool_name: str, result: str, success: bool = True):
    icon = f"{GREEN}{ICON_OK}{RESET}" if success else f"{RED}{ICON_FAIL}{RESET}"
    content = truncate(result.replace("\n", " "), 90)
    print(f"    {icon} {BRIGHT_BLACK}{content}{RESET}")


def print_tool_calls(messages: list):
    try:
        from pydantic_ai.messages import (
            ModelRequest,
            ModelResponse,
            ToolCallPart,
            ToolReturnPart,
        )
    except ImportError:
        return

    for msg in messages:
        if isinstance(msg, ModelResponse):
            tool_parts = [p for p in msg.parts if isinstance(p, ToolCallPart)]
            if len(tool_parts) > 1:
                print(f"\n  {YELLOW}{ICON_BOLT} {len(tool_parts)} parallel calls{RESET}")
            for part in tool_parts:
                args = part.args if isinstance(part.args, dict) else {}
                print_tool_call(part.tool_name, args)

        elif isinstance(msg, ModelRequest):
            for part in msg.parts:
                if isinstance(part, ToolReturnPart):
                    content = str(part.content)
                    is_err = content.startswith("Error") or content.startswith("(")
                    print_tool_result(part.tool_name, content, success=not is_err)


# ---------------------------------------------------------------------------
# Usage / tokens
# ---------------------------------------------------------------------------


def print_usage(input_tokens: int, output_tokens: int, turn_count: int = 0):
    elapsed = time.time() - _thinking_start if _thinking_start else 0

    parts = []
    if elapsed > 0.5:
        parts.append(f"{elapsed:.1f}s")
    parts.append(f"{input_tokens:,} in")
    parts.append(f"{output_tokens:,} out")

    dot = f" {BRIGHT_BLACK}{ICON_DOT}{RESET}{BRIGHT_BLACK} "
    print(f"\n  {BRIGHT_BLACK}{dot.join(parts)}{RESET}")


def print_session_usage(usage_total: dict, turn_count: int):
    total = usage_total.get("input", 0) + usage_total.get("output", 0)
    print(f"  {BRIGHT_BLACK}Session: {total:,} tokens, {turn_count} turns{RESET}")


# ---------------------------------------------------------------------------
# Status / error / notifications
# ---------------------------------------------------------------------------


def print_error(message: str):
    print(f"\n  {RED}{ICON_FAIL} Error:{RESET} {message}")


def print_status(message: str):
    print(f"  {BRIGHT_BLACK}{message}{RESET}")


def print_notification(message: str):
    print(f"  {CYAN}{ICON_BOLT} {message}{RESET}")


def print_separator():
    w = min(_term_width(), 72)
    print(f"  {BRIGHT_BLACK}{BOX_H * (w - 4)}{RESET}")
