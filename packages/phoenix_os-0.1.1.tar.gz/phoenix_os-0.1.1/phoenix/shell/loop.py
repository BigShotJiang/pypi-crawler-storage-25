"""Chat loop -- the main conversation interface.

Uses topic-based context engineering:
  - No full conversation history passed to the model
  - Active topic messages only (current topic)
  - Completed topic summaries injected as context
  - Memory recall for cross-session facts
  - Flat cost per turn regardless of session length
"""

from phoenix.config.settings import get_model
from phoenix.core.engine import PhoenixEngine
from phoenix.shell import display
from phoenix.shell.commands import CommandContext, handle_command
from phoenix.shell.input import read_input_safe
from phoenix.shell.session import SessionManager


async def run_loop(
    engine: PhoenixEngine,
    session: SessionManager,
    history: list | None = None,
    ambient=None,
    voice_queue=None,
    voice_daemon=None,
    hook_runner=None,
):
    """Run the main Phoenix chat loop with topic-based context."""
    # Active history = only the current topic's pydantic-ai messages
    # This starts empty; engine.run_stream populates it
    active_history: list = history or []
    turn_count = 0
    usage_total = {"input": 0, "output": 0}

    mem_stats = engine._memory.stats() if engine._memory else None

    display.print_banner(
        model=get_model(),
        abilities=engine.registry.list_abilities(),
        agents=engine.registry.list_agents(),
        memory_stats=mem_stats,
        ambient_active=bool(ambient and ambient.is_enabled),
    )

    if history:
        display.print_status(f"Restored session {session.session_id}")

    cmd_ctx = CommandContext(
        history=active_history,
        turn_count=turn_count,
        usage_total=usage_total,
        save_fn=session.save,
        engine=engine,
    )

    while True:
        # Display ambient notifications
        if ambient:
            for note in ambient.get_notifications():
                display.print_notification(note)

        # Display background task notifications
        if engine.bg_manager:
            for note in engine.bg_manager.get_notifications():
                display.print_notification(note)

        # Get input with safety-colored prompt
        prompt_str = display.get_prompt()
        user_input, should_exit = read_input_safe(prompt_str)

        if should_exit:
            try:
                await _save_session_summary(engine, session, active_history)
            except (KeyboardInterrupt, Exception):
                session.save(active_history)
            print("\nBye, Boss.")
            break

        if not user_input.strip():
            continue

        # Record input for ambient idle detection
        if ambient:
            ambient.record_input()

        # Handle slash commands
        result = handle_command(user_input, cmd_ctx)
        if result is not None:
            if result == "__EXIT__":
                try:
                    await _save_session_summary(engine, session, active_history)
                except (KeyboardInterrupt, Exception):
                    session.save(active_history)
                print("Bye, Boss.")
                break
            print(result)
            active_history = cmd_ctx.history
            turn_count = cmd_ctx.turn_count
            continue

        # Pre-turn hooks
        if hook_runner and hook_runner.has_hooks:
            from phoenix.hooks.runner import HookContext, HookEvent

            hr = await hook_runner.run(
                HookEvent.PRE_TURN,
                HookContext(
                    event=HookEvent.PRE_TURN,
                    user_input=user_input,
                    turn_count=turn_count,
                ),
            )
            if hr.feedback:
                display.print_status(hr.feedback.strip())
            if not hr.allow:
                display.print_status("(blocked by hook)")
                continue

        # Run agent turn (with topic-based context)
        try:
            display.print_thinking()
            first = True
            chunks = []

            # Pass active_history (current topic only, not full session)
            async for text in engine.run_stream(user_input, active_history):
                if first:
                    display.clear_thinking()
                    first = False
                display.print_text(text)
                chunks.append(text)

            print()
            active_history = engine.last_history
            turn_count += 1
            cmd_ctx.history = active_history
            cmd_ctx.turn_count = turn_count

            # Show token usage
            usage = engine.last_usage
            if usage:
                inp = getattr(usage, "request_tokens", 0) or 0
                out = getattr(usage, "response_tokens", 0) or 0
                if inp or out:
                    usage_total["input"] += inp
                    usage_total["output"] += out
                    display.print_usage(inp, out, turn_count)

            # Notify if topic shift happened
            tracker = engine.topic_tracker
            if tracker and tracker.completed_count > 0:
                label = tracker.active_topic_label
                if label:
                    display.print_status(f"topic: {label} ({tracker.completed_count} completed)")

            # Post-turn hooks
            if hook_runner and hook_runner.has_hooks:
                from phoenix.hooks.runner import HookContext, HookEvent

                hr = await hook_runner.run(
                    HookEvent.POST_TURN,
                    HookContext(
                        event=HookEvent.POST_TURN,
                        user_input=user_input,
                        turn_count=turn_count,
                    ),
                )
                if hr.feedback:
                    display.print_status(hr.feedback.strip())

            # Save active history for crash recovery
            session.save(active_history)

        except KeyboardInterrupt:
            display.clear_thinking()
            print("\n(cancelled)")
        except Exception as e:
            display.clear_thinking()
            display.print_error(str(e))
            session.save(active_history)


async def _save_session_summary(
    engine: PhoenixEngine,
    session: SessionManager,
    history: list,
):
    """Save session summary to memory on exit."""
    import asyncio

    # Always save history first (fast, no LLM call)
    session.save(history)

    # Try to create session summary (LLM call) with timeout
    # If user is mashing Ctrl+C, skip gracefully
    try:
        summary = await asyncio.wait_for(engine.create_session_summary(), timeout=15.0)
        if summary:
            display.print_status("Session saved to memory.")
    except (asyncio.TimeoutError, asyncio.CancelledError, KeyboardInterrupt):
        display.print_status("Session saved (summary skipped).")
    except Exception:
        display.print_status("Session saved.")
