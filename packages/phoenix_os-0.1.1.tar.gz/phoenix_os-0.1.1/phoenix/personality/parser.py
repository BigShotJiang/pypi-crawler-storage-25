"""Personality parser -- reads YAML agent definitions, merges defaults, builds prompts."""

import platform
from datetime import datetime
from pathlib import Path
from typing import Any

import yaml
from pydantic import BaseModel, Field

_PERSONALITY_DIR = Path(__file__).parent


# ---------------------------------------------------------------------------
# Schema models
# ---------------------------------------------------------------------------


class BehaviorConfig(BaseModel):
    ask_permission: bool = True
    narrate_steps: bool = True
    delegation: bool = True
    context_window: str = "fresh"


class AgentMeta(BaseModel):
    category: str = "community"
    author: str = ""
    version: float | str = 1.0


class AgentConfig(BaseModel):
    name: str
    role: str = ""
    tone: list[str] = Field(default_factory=list)
    rules: list[str] = Field(default_factory=list)
    behaviors: BehaviorConfig = Field(default_factory=BehaviorConfig)
    abilities: list[str] = Field(default_factory=list)
    model: str | None = None
    meta: AgentMeta = Field(default_factory=AgentMeta)


class IdentityConfig(BaseModel):
    name: str = "Phoenix"
    version: str = "0.1.0"
    description: str = ""


class PhoenixDefaults(BaseModel):
    identity: IdentityConfig = Field(default_factory=IdentityConfig)
    defaults: dict[str, Any] = Field(default_factory=dict)
    reasoning: list[str] = Field(default_factory=list)
    rules: list[str] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Loading
# ---------------------------------------------------------------------------


def load_defaults() -> PhoenixDefaults:
    path = _PERSONALITY_DIR / "phoenix.yaml"
    if not path.exists():
        return PhoenixDefaults()
    with open(path) as f:
        data = yaml.safe_load(f) or {}
    return PhoenixDefaults(**data)


def parse_agent(yaml_path: Path) -> AgentConfig:
    with open(yaml_path) as f:
        data = yaml.safe_load(f) or {}
    return AgentConfig(**data)


# ---------------------------------------------------------------------------
# Merging
# ---------------------------------------------------------------------------


def merge_config(defaults: PhoenixDefaults, agent: AgentConfig) -> AgentConfig:
    """Fill agent fields from global defaults where the agent didn't specify them."""
    default_vals = defaults.defaults

    if not agent.tone and "tone" in default_vals:
        agent.tone = default_vals["tone"]

    if not agent.rules:
        agent.rules = list(defaults.rules)
    else:
        global_rules = [r for r in defaults.rules if r not in agent.rules]
        agent.rules = global_rules + agent.rules

    default_behaviors = default_vals.get("behaviors", {})
    if default_behaviors:
        agent_dict = agent.behaviors.model_dump()
        for key, val in default_behaviors.items():
            if key not in agent_dict or agent_dict[key] == BehaviorConfig.model_fields[key].default:
                setattr(agent.behaviors, key, val)

    if agent.model is None and "model" in default_vals:
        agent.model = default_vals["model"]

    return agent


# ---------------------------------------------------------------------------
# Prompt generation
# ---------------------------------------------------------------------------


def _substitute_variables(text: str) -> str:
    now = datetime.now()
    variables = {
        "today": now.strftime("%Y-%m-%d"),
        "datetime": now.strftime("%A, %B %d, %Y at %I:%M %p"),
        "system_info": platform.system(),
    }
    for key, val in variables.items():
        text = text.replace(f"{{{key}}}", val)
    return text


def build_system_prompt(
    config: AgentConfig,
    defaults: PhoenixDefaults | None = None,
    project_context: str = "",
) -> str:
    """Generate the final system prompt string from a merged AgentConfig."""
    if defaults is None:
        defaults = load_defaults()

    identity = defaults.identity
    parts: list[str] = []

    # Identity
    parts.append(
        f"You are {identity.name}, an advanced general intelligence "
        f"whose goal is to serve as a personal assistant to the user. "
        f"You call your user Boss. Respectfully."
    )

    if config.role:
        parts.append(f"\nRole: {config.role}")

    if config.tone:
        parts.append(f"\nTone: {', '.join(config.tone)}")

    # Reasoning framework (how Phoenix thinks)
    if defaults.reasoning:
        parts.append("\nHow you operate:")
        for i, step in enumerate(defaults.reasoning, 1):
            parts.append(f"{i}. {step}")

    # Behavioral rules
    if config.rules:
        parts.append("\nRules:")
        for rule in config.rules:
            parts.append(f"- {rule}")

    now = datetime.now()
    parts.append(
        f"\nCurrent date and time: {now.strftime('%A, %B %d, %Y')} at {now.strftime('%I:%M %p')}."
    )

    if project_context:
        parts.append(f"\nProject context:\n{project_context}")

    prompt = "\n".join(parts)
    return _substitute_variables(prompt)


def build_agent_prompt(agent_name: str, project_context: str = "") -> str:
    """Convenience: load agent YAML, merge with defaults, build prompt."""
    defaults = load_defaults()
    agent_path = _PERSONALITY_DIR / "agents" / f"{agent_name}.yaml"
    if not agent_path.exists():
        raise FileNotFoundError(f"Agent personality not found: {agent_path}")
    config = parse_agent(agent_path)
    config = merge_config(defaults, config)
    return build_system_prompt(config, defaults, project_context)
