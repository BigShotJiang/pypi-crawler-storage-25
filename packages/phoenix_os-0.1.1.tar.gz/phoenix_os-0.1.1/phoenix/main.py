"""Phoenix main -- async entry point."""

import argparse
import asyncio

from phoenix.config.settings import get_model, set_model, setup_logging
from phoenix.core.engine import PhoenixEngine
from phoenix.shell.session import SessionManager


def parse_args():
    parser = argparse.ArgumentParser(description="Phoenix -- AI agent OS")
    parser.add_argument("--model", metavar="MODEL", help="Model override (e.g. openai:gpt-4o)")
    parser.add_argument("--yolo", action="store_true", help="Auto-approve all tool calls")
    parser.add_argument("--auto", action="store_true", help="Auto-approve file edits, ask for bash")
    parser.add_argument("--sessions", action="store_true", help="List saved sessions")
    parser.add_argument(
        "--continue",
        dest="continue_session",
        action="store_true",
        help="Resume the most recent session",
    )
    parser.add_argument("--resume", metavar="SESSION_ID", help="Resume a specific session")
    parser.add_argument("--voice", action="store_true", help="Enable voice I/O (say 'Phoenix')")
    parser.add_argument("--setup", action="store_true", help="Run setup wizard")
    return parser.parse_args()


async def main():
    setup_logging()
    args = parse_args()

    # Load secrets from OS keychain into env vars
    from phoenix.config.secrets import load_secrets_to_env

    load_secrets_to_env()

    # Apply saved config (model from ~/.phoenix/config.yaml)
    from phoenix.config.setup import apply_config, needs_setup, run_setup

    # Run setup wizard if --setup flag or first run
    if args.setup or needs_setup():
        result = run_setup()
        if result is None:
            return
        if args.setup:
            return

    apply_config()

    if args.model:
        set_model(args.model)

    if args.sessions:
        sessions = SessionManager.list_sessions()
        if not sessions:
            print("No saved sessions.")
        else:
            print(f"{'ID':<14} {'Messages':>8}  {'Last Active':<20}  {'Directory'}")
            print("-" * 80)
            for s in sessions:
                print(
                    f"{s.get('session_id', '?'):<14} "
                    f"{s.get('message_count', 0):>8}  "
                    f"{s.get('last_active', '?')[:19]:<20}  "
                    f"{s.get('working_dir', '?')}"
                )
        return

    if args.yolo or args.auto:
        from phoenix.core.interceptor import AutoApprovalBackend, set_approval_backend

        mode = "yolo" if args.yolo else "auto"
        set_approval_backend(AutoApprovalBackend(mode))

    session = None
    history = None

    if args.resume:
        session = SessionManager(args.resume)
        history = session.load()
        if not history:
            print(f"Session '{args.resume}' not found or empty.")
            return
        print(f"Resuming session: {args.resume}")
    elif args.continue_session:
        sid = SessionManager.get_latest_session_id()
        if sid:
            session = SessionManager(sid)
            history = session.load()
            print(f"Resuming session: {sid}")
        else:
            print("No previous session found. Starting new session.")

    if session is None:
        session = SessionManager()

    # Load hooks
    from phoenix.hooks.loader import load_hooks_config

    hook_runner = load_hooks_config()

    # Initialize memory
    from phoenix.memory import MemorySystem

    memory = MemorySystem()

    # Boot engine with session context
    engine = PhoenixEngine()
    await engine.boot(
        memory=memory,
        hook_runner=hook_runner,
        session_id=session.session_id,
    )

    # Start ambient daemon
    from phoenix.ambient.daemon import AmbientDaemon

    ambient = AmbientDaemon(model=get_model(), memory=memory)
    ambient_task = asyncio.create_task(ambient.run())

    # Start voice daemon (optional)
    voice_task = None
    voice_queue = None
    voice_daemon = None
    if args.voice:
        try:
            from phoenix.voice.config import VoiceConfig
            from phoenix.voice.daemon import VoiceDaemon

            voice_daemon = VoiceDaemon(config=VoiceConfig())
            voice_queue = voice_daemon.voice_queue
            voice_task = asyncio.create_task(voice_daemon.run())
        except ImportError:
            print("Voice dependencies not installed. Run: pip install phoenix-os[voice]")

    try:
        from phoenix.shell.loop import run_loop

        await run_loop(
            engine=engine,
            session=session,
            history=history,
            ambient=ambient,
            voice_queue=voice_queue,
            voice_daemon=voice_daemon,
            hook_runner=hook_runner,
        )
    finally:
        ambient.stop()
        ambient_task.cancel()
        if voice_task:
            voice_daemon.stop()
            voice_task.cancel()
        try:
            await ambient_task
            if voice_task:
                await voice_task
        except asyncio.CancelledError:
            pass
        memory.close()


def run():
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nBye, Boss.")


if __name__ == "__main__":
    run()
