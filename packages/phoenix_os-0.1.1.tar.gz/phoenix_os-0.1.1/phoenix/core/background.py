"""Background task manager -- submit, track, and notify on async tasks."""

import asyncio
import logging
import time
from dataclasses import dataclass, field

log = logging.getLogger(__name__)


@dataclass
class BackgroundTask:
    task_id: int
    name: str
    asyncio_task: asyncio.Task
    started_at: float = field(default_factory=time.time)
    completed_at: float | None = None
    result: str = ""
    error: str = ""

    @property
    def status(self) -> str:
        if self.error:
            return "failed"
        if self.completed_at:
            return "done"
        return "running"

    @property
    def elapsed(self) -> float:
        end = self.completed_at or time.time()
        return end - self.started_at

    def elapsed_str(self) -> str:
        secs = self.elapsed
        if secs < 60:
            return f"{secs:.0f}s"
        mins = secs / 60
        return f"{mins:.1f}m"


class BackgroundManager:
    """Manages background async tasks with notification queue."""

    def __init__(self):
        self._tasks: dict[int, BackgroundTask] = {}
        self._next_id = 1
        self._notifications: list[str] = []

    def submit(self, coro, name: str) -> int:
        """Submit an async coroutine as a background task. Returns task_id."""
        task_id = self._next_id
        self._next_id += 1

        async def _wrapper():
            bg_task = self._tasks[task_id]
            try:
                result = await coro
                bg_task.completed_at = time.time()

                # Extract output
                if hasattr(result, "output"):
                    bg_task.result = str(result.output)[:500]
                elif hasattr(result, "status"):
                    bg_task.result = (
                        f"Status: {result.status} "
                        f"({result.iterations} iterations, "
                        f"{result.duration:.1f}s)"
                    )
                    if hasattr(result, "output") and result.output:
                        bg_task.result += f"\n{str(result.output)[:300]}"
                else:
                    bg_task.result = str(result)[:500]

                self._notifications.append(
                    f"Task #{task_id} completed: {name} [{bg_task.elapsed_str()}]"
                )
                log.info("Background task #%d done: %s", task_id, name)

            except Exception as e:
                bg_task.completed_at = time.time()
                bg_task.error = str(e)
                self._notifications.append(f"Task #{task_id} failed: {name} -- {e}")
                log.error("Background task #%d failed: %s", task_id, e)

        asyncio_task = asyncio.create_task(_wrapper())
        self._tasks[task_id] = BackgroundTask(
            task_id=task_id,
            name=name,
            asyncio_task=asyncio_task,
        )

        log.info("Background task #%d submitted: %s", task_id, name)
        return task_id

    def get_notifications(self) -> list[str]:
        """Return and clear pending notifications."""
        notes = list(self._notifications)
        self._notifications.clear()
        return notes

    def get_task(self, task_id: int) -> BackgroundTask | None:
        return self._tasks.get(task_id)

    def list_tasks(self) -> list[BackgroundTask]:
        return sorted(self._tasks.values(), key=lambda t: t.started_at, reverse=True)

    @property
    def has_running(self) -> bool:
        return any(t.status == "running" for t in self._tasks.values())

    def format_list(self) -> str:
        """Format all tasks for display."""
        if not self._tasks:
            return "No background tasks."

        lines = []
        for t in self.list_tasks():
            if t.status == "running":
                icon = "\033[33m...\033[0m"
            elif t.status == "done":
                icon = "\033[32m ok\033[0m"
            else:
                icon = "\033[31m  x\033[0m"

            name = t.name[:50]
            lines.append(f"  #{t.task_id} [{icon}] {name} \033[90m{t.elapsed_str()}\033[0m")
        return "\n".join(lines)

    def format_task(self, task_id: int) -> str:
        """Format a single task with full detail."""
        t = self._tasks.get(task_id)
        if not t:
            return f"Task #{task_id} not found."

        lines = [
            f"Task #{t.task_id}: {t.name}",
            f"  Status: {t.status}",
            f"  Elapsed: {t.elapsed_str()}",
        ]
        if t.result:
            lines.append(f"  Result:\n    {t.result}")
        if t.error:
            lines.append(f"  Error: {t.error}")
        return "\n".join(lines)
