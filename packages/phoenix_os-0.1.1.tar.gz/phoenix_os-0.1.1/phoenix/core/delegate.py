"""Delegate -- the brain's tool for routing tasks to specialized agents.

Two modes:
  - Standard: single run, immediate result (default)
  - Autonomous: execute-evaluate-retry loop, runs in background
"""

import logging

from pydantic_ai import RunContext

from phoenix.core.factory import build_agent
from phoenix.core.registry import get_registry

log = logging.getLogger(__name__)

# Module-level background manager (set by engine at boot)
_bg_manager = None


def set_background_manager(manager):
    global _bg_manager
    _bg_manager = manager


async def delegate(
    ctx: RunContext,
    task: str,
    agent: str = "worker",
    autonomous: bool = False,
) -> str:
    """Delegate a task to a specialized agent.

    Args:
        task: Description of what needs to be done.
        agent: Agent name (worker, explorer, planner, etc.).
        autonomous: If True, run in background with retry loop until done.
    """
    registry = get_registry()

    if agent not in registry.list_agents():
        available = ", ".join(registry.list_agents())
        return f"Unknown agent '{agent}'. Available agents: {available}"

    if agent == "brain":
        return "Cannot delegate to self. Choose a specialized agent."

    log.info("Delegating to '%s': %s (autonomous=%s)", agent, task[:80], autonomous)

    if autonomous:
        return await _delegate_autonomous(task, agent)
    return await _delegate_standard(task, agent)


async def _delegate_standard(task: str, agent: str) -> str:
    """Single run, immediate result."""
    try:
        registry = get_registry()
        subagent = build_agent(
            agent_name=agent,
            registry=registry,
            project_context="",
        )
        result = await subagent.run(task)
        output = str(result.output)
        log.info("Delegate '%s' returned %d chars", agent, len(output))
        return output
    except Exception as e:
        log.error("Delegation to '%s' failed: %s", agent, e)
        return f"Delegation to '{agent}' failed: {e}"


async def _delegate_autonomous(task: str, agent: str) -> str:
    """Run task loop in background with retry logic. Seeks approval first."""
    from phoenix.core.interceptor import get_approval_backend
    from phoenix.core.task_loop import run_task

    # Seek approval before autonomous execution
    backend = get_approval_backend()
    approved = await backend.request_approval(
        "autonomous_task",
        f"Run '{agent}' autonomously until task is done (max 5 retries)",
        {"task": task[:200], "agent": agent},
    )
    if not approved:
        return "Autonomous task rejected by user."

    if _bg_manager is None:
        # No background manager -- run inline
        log.info("No background manager, running autonomous task inline")
        result = await run_task(task=task, agent_name=agent)
        return (
            f"[{result.status}] ({result.iterations} iterations, "
            f"{result.duration:.1f}s)\n{result.output}"
        )

    # Submit to background
    coro = run_task(task=task, agent_name=agent)
    task_id = _bg_manager.submit(coro, name=f"{agent}: {task[:60]}")
    return (
        f"Task #{task_id} started in background. "
        f"Agent '{agent}' working autonomously.\n"
        f"Check status: /tasks\n"
        f"View result: /task {task_id}"
    )
