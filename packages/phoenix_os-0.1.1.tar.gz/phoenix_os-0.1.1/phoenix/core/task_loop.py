"""Task loop -- execute-evaluate-retry until success.

Implements the autonomous agent loop:
  1. Execute: agent runs with task + feedback from prior attempt
  2. Evaluate: check if task succeeded (LLM judge or programmatic)
  3. Retry: feed failure feedback into next iteration

Referenced from Den's Loop Engine architecture, adapted for Phoenix.
"""

import logging
import time
from dataclasses import dataclass, field

from pydantic import BaseModel, Field

from phoenix.core.factory import build_agent
from phoenix.core.registry import get_registry

log = logging.getLogger(__name__)

DEFAULT_MAX_ITERATIONS = 5
DEFAULT_COOLDOWN = 2.0


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------


@dataclass
class TaskResult:
    status: str  # "success", "exhausted", "failed"
    output: str = ""
    iterations: int = 0
    duration: float = 0.0
    iteration_log: list[dict] = field(default_factory=list)


class TaskEvaluation(BaseModel):
    """LLM judge output for task evaluation."""

    succeeded: bool = Field(description="Did the agent accomplish the task?")
    confidence: float = Field(
        default=0.5,
        description="Confidence 0-1 that the task is complete",
    )
    feedback: str = Field(
        default="",
        description="What needs to be fixed or improved. "
        "Be specific about errors, missing steps, or quality issues.",
    )


# ---------------------------------------------------------------------------
# Evaluators
# ---------------------------------------------------------------------------


async def evaluate_with_llm(
    task: str,
    output: str,
    model: str,
) -> TaskEvaluation:
    """Ask the LLM to judge if the task was completed successfully."""
    try:
        from pydantic_ai import Agent

        agent = Agent(
            model,
            output_type=TaskEvaluation,
            instructions=(
                "You evaluate whether an AI agent completed a task. "
                "Be strict -- partial completion is not success. "
                "If failed, give specific actionable feedback."
            ),
        )

        prompt = (
            f"Task: {task}\n\n"
            f"Agent output:\n{output[:3000]}\n\n"
            f"Did the agent fully complete the task? "
            f"If not, what specifically needs to be fixed?"
        )

        result = await agent.run(prompt)
        return result.output

    except Exception as e:
        log.warning("LLM evaluation failed: %s", e)
        return TaskEvaluation(
            succeeded=True,
            confidence=0.3,
            feedback=f"Evaluation failed: {e}. Assuming success.",
        )


def evaluate_programmatic(output: str) -> TaskEvaluation:
    """Quick programmatic check for obvious failures."""
    lower = output.lower()

    # Check for error indicators
    error_signals = [
        "error:",
        "traceback",
        "failed:",
        "exception:",
        "command not found",
        "permission denied",
        "syntax error",
    ]

    for signal in error_signals:
        if signal in lower:
            return TaskEvaluation(
                succeeded=False,
                confidence=0.8,
                feedback=f"Output contains error signal: '{signal}'. Fix the error.",
            )

    # Check for empty or too-short output
    if len(output.strip()) < 20:
        return TaskEvaluation(
            succeeded=False,
            confidence=0.5,
            feedback="Output is too short. Task may not have completed.",
        )

    return TaskEvaluation(succeeded=True, confidence=0.6, feedback="")


# ---------------------------------------------------------------------------
# Task loop
# ---------------------------------------------------------------------------


async def run_task(
    task: str,
    agent_name: str = "worker",
    max_iterations: int = DEFAULT_MAX_ITERATIONS,
    model: str | None = None,
    use_llm_eval: bool = True,
    cooldown: float = DEFAULT_COOLDOWN,
) -> TaskResult:
    """Run an autonomous task loop: execute -> evaluate -> retry.

    Args:
        task: What needs to be done.
        agent_name: Which agent to use.
        max_iterations: Max attempts before giving up.
        model: Model override for the agent.
        use_llm_eval: Use LLM to judge completion (vs programmatic only).
        cooldown: Seconds between retries.
    """
    import asyncio

    from phoenix.config.settings import get_model

    registry = get_registry()
    effective_model = model or get_model()
    start_time = time.time()
    feedback = ""
    iteration_log: list[dict] = []
    last_output = ""

    for iteration in range(1, max_iterations + 1):
        iter_start = time.time()
        log.info(
            "Task loop iteration %d/%d: %s",
            iteration,
            max_iterations,
            task[:80],
        )

        # Build prompt with feedback from prior attempt
        prompt = task
        if feedback:
            prompt += (
                f"\n\n[Previous attempt failed -- iteration {iteration - 1}]\n"
                f"{feedback}\n"
                f"Fix these issues and try again."
            )

        # Execute
        try:
            subagent = build_agent(
                agent_name=agent_name,
                registry=registry,
                model_override=effective_model,
            )
            result = await subagent.run(prompt)
            output = str(result.output)
            last_output = output
        except Exception as e:
            output = f"Agent execution failed: {e}"
            last_output = output
            log.error("Task loop execution error: %s", e)

        # Evaluate
        # First: quick programmatic check (free)
        prog_eval = evaluate_programmatic(output)

        if prog_eval.succeeded and use_llm_eval:
            # Programmatic says OK, double-check with LLM
            llm_eval = await evaluate_with_llm(task, output, effective_model)
            eval_result = llm_eval
        elif not prog_eval.succeeded:
            # Programmatic caught an error, no need for LLM
            eval_result = prog_eval
        else:
            eval_result = prog_eval

        iter_duration = time.time() - iter_start
        iteration_log.append(
            {
                "iteration": iteration,
                "succeeded": eval_result.succeeded,
                "confidence": eval_result.confidence,
                "feedback": eval_result.feedback,
                "duration": round(iter_duration, 1),
                "output_preview": output[:200],
            }
        )

        if eval_result.succeeded:
            log.info(
                "Task succeeded on iteration %d (confidence: %.2f)",
                iteration,
                eval_result.confidence,
            )
            return TaskResult(
                status="success",
                output=output,
                iterations=iteration,
                duration=time.time() - start_time,
                iteration_log=iteration_log,
            )

        # Failed -- prepare for retry
        feedback = eval_result.feedback
        log.info(
            "Task iteration %d failed: %s",
            iteration,
            feedback[:100],
        )

        if iteration < max_iterations and cooldown > 0:
            await asyncio.sleep(cooldown)

    # Exhausted all iterations
    return TaskResult(
        status="exhausted",
        output=last_output,
        iterations=max_iterations,
        duration=time.time() - start_time,
        iteration_log=iteration_log,
    )
