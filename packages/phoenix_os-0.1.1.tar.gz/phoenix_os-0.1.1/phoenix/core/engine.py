"""Engine -- the central orchestrator that boots and runs Phoenix.

Context architecture:
  - Each request is nearly stateless. No full conversation history passed.
  - Context is ENGINEERED from three layers:
    1. Memory recall (cross-session facts, preferences, skills)
    2. Topic summaries (completed topics from this session)
    3. Active topic messages (only the current topic's messages)
  - Cost is FLAT: ~5-6k tokens per turn regardless of session length.
  - One LLM call per topic shift (~every 10 turns) for summarization.
"""

import logging
from typing import Any

from pydantic_ai import Agent

from phoenix.abilities import PhoenixContext
from phoenix.config.settings import PHOENIX_DIR, get_model
from phoenix.core.context import scan_project
from phoenix.core.delegate import delegate
from phoenix.core.factory import build_agent
from phoenix.core.reasoning import (
    classify_query,
    detect_stakes,
    get_reasoning_instruction,
)
from phoenix.core.registry import Registry, get_registry

log = logging.getLogger(__name__)

# Max pydantic-ai messages to keep in active history within a topic.
# ~10 turns = 20 messages (request + response per turn).
MAX_ACTIVE_HISTORY = 20

# On topic shift, keep only last N messages as bridge.
BRIDGE_MESSAGES = 4  # 2 turns


def _trim_history(history: list, keep_last: int) -> list:
    """Trim pydantic-ai message history, keeping last N messages.

    Ensures we trim at message pair boundaries (ModelRequest + ModelResponse).
    """
    if len(history) <= keep_last:
        return history
    # Trim to keep_last, ensuring even number (pairs)
    start = len(history) - keep_last
    if start % 2 != 0:
        start += 1  # align to pair boundary
    return history[start:]


class PhoenixEngine:
    """Central orchestrator -- boots the system, manages the agent lifecycle."""

    def __init__(self):
        self._registry: Registry | None = None
        self._agent: Agent | None = None
        self._project_context: str = ""
        self._memory: Any = None
        self._topic_tracker: Any = None
        self.bg_manager = None

    async def boot(
        self,
        memory: Any = None,
        hook_runner=None,
        session_id: str = "",
        session_summary: str = "",
    ):
        """Initialize the engine: discover plugins, build brain agent."""
        self._memory = memory
        self._hook_runner = hook_runner
        self._session_summary = session_summary
        self._registry = get_registry()
        self._registry.discover_all()

        self._project_context = scan_project()

        # Initialize background task manager
        from phoenix.core.background import BackgroundManager
        from phoenix.core.delegate import set_background_manager

        self.bg_manager = BackgroundManager()
        set_background_manager(self.bg_manager)

        # Initialize topic tracker
        from phoenix.memory.session import TopicTracker

        self._topic_tracker = TopicTracker(
            model=get_model(),
            session_id=session_id,
        )

        context = PhoenixContext(
            config={"phoenix_dir": str(PHOENIX_DIR), "model": get_model()},
            memory=self._memory,
            agent_name="brain",
        )

        self._agent = build_agent(
            agent_name="brain",
            registry=self._registry,
            project_context=self._project_context,
            extra_tools=[delegate],
            phoenix_context=context,
            hook_runner=hook_runner,
        )

        abilities = self._registry.list_abilities()
        agents = self._registry.list_agents()
        log.info(
            "Phoenix booted: %d abilities, %d agents",
            len(abilities),
            len(agents),
        )

    @property
    def agent(self) -> Agent:
        if self._agent is None:
            raise RuntimeError("Engine not booted. Call boot() first.")
        return self._agent

    @property
    def registry(self) -> Registry:
        if self._registry is None:
            raise RuntimeError("Engine not booted. Call boot() first.")
        return self._registry

    @property
    def topic_tracker(self):
        return self._topic_tracker

    def _build_engineered_context(self, user_input: str, memory_context: str) -> str:
        """Build the engineered context from all three layers."""
        parts = []

        # Layer 1: Previous session summary (if --continue)
        if self._session_summary:
            parts.append(f"[Previous session]\n{self._session_summary}")

        # Layer 2: Memory recall (cross-session facts)
        if memory_context:
            parts.append(memory_context)

        # Layer 3: Topic summaries (completed topics this session)
        if self._topic_tracker:
            topic_ctx = self._topic_tracker.build_context()
            if topic_ctx:
                parts.append(f"[Session context]\n{topic_ctx}")

        # Query classification + reasoning instruction
        query_type = classify_query(user_input)
        reasoning = get_reasoning_instruction(query_type)
        if reasoning:
            parts.append(reasoning)

        # User message
        parts.append(user_input)

        return "\n\n".join(parts)

    async def run_stream(
        self,
        user_input: str,
        history: list | None = None,
    ):
        """Execute a turn with streaming. Uses topic-based context.

        The history parameter is the ACTIVE TOPIC's messages only,
        not the full conversation history.
        """
        # Memory pre-turn
        memory_context = ""
        if self._memory and hasattr(self._memory, "pre_turn"):
            try:
                memory_context = self._memory.pre_turn(user_input)
            except Exception as e:
                log.warning("Memory pre_turn failed: %s", e)

        # Build engineered context (replaces raw history)
        prompt = self._build_engineered_context(user_input, memory_context)

        # Use only active topic messages as history (not full conversation)
        active_history = history or []

        async with self.agent.run_stream(prompt, message_history=active_history) as stream:
            chunks = []
            async for text in stream.stream_text(delta=True):
                chunks.append(text)
                yield text

            full_output = "".join(chunks)
            updated_history = stream.all_messages()

            try:
                usage = stream.usage()
                self._last_usage = usage
            except Exception:
                self._last_usage = None

        stakes = detect_stakes(user_input)
        if stakes:
            full_output = f"{stakes}\n\n{full_output}"

        # Memory post-turn
        if self._memory and hasattr(self._memory, "post_turn"):
            try:
                self._memory.post_turn(user_input=user_input, ai_output=full_output)
            except Exception as e:
                log.warning("Memory post_turn failed: %s", e)

        # Topic tracker post-turn + history trimming
        if self._topic_tracker:
            completed_before = self._topic_tracker.completed_count
            try:
                await self._topic_tracker.process_turn(
                    user_input=user_input,
                    ai_output=full_output,
                )
            except Exception as e:
                log.warning("Topic tracker failed: %s", e)

            # Only trim when topic actually shifts
            # Within a topic: full history stays (model needs the detail)
            # On shift: trim to bridge messages (summary covers the rest)
            if self._topic_tracker.completed_count > completed_before:
                updated_history = _trim_history(updated_history, keep_last=BRIDGE_MESSAGES)
                log.info(
                    "Topic shifted -> trimmed history to %d messages",
                    len(updated_history),
                )

        self._last_output = full_output
        self._last_history = updated_history

    async def create_session_summary(self) -> str | None:
        """Create a session summary on exit. Store in memory."""
        if not self._topic_tracker:
            return None

        summary = await self._topic_tracker.create_session_summary()
        if summary and self._memory:
            try:
                self._memory.post_turn(
                    user_input=f"[Session summary] {summary}",
                    ai_output="",
                    namespace="sessions",
                )
            except Exception as e:
                log.warning("Failed to store session summary: %s", e)

        return summary

    @property
    def last_output(self) -> str:
        return getattr(self, "_last_output", "")

    @property
    def last_history(self) -> list:
        return getattr(self, "_last_history", [])

    @property
    def last_usage(self):
        return getattr(self, "_last_usage", None)
