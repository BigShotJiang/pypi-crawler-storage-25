"""Web search -- Brave LLM Context API for grounded web knowledge.

Uses Brave's LLM Context endpoint which returns pre-extracted,
relevance-scored web content optimized for LLM consumption.
Single API call, no scraping needed.
"""

import json
import os

from phoenix.abilities import ability

_API_BASE = "https://api.search.brave.com/res/v1"


def _get_api_key() -> str | None:
    return os.environ.get("BRAVE_API_KEY", "")


@ability(
    name="web_search",
    description="Search the web for current information using Brave Search",
)
async def web_search(
    query: str,
    max_results: int = 10,
    max_tokens: int = 4096,
    freshness: str = "",
    context_mode: str = "balanced",
) -> str:
    """Search the web and return extracted content ready for reasoning.

    Uses Brave LLM Context API -- returns actual page content,
    not just links. One call, pre-extracted, relevance-scored.

    Args:
        query: What to search for.
        max_results: Max URLs to include (1-50, default 10).
        max_tokens: Approx max tokens of context (1024-32768, default 4096).
        freshness: Filter by age: pd (24h), pw (week), pm (month), py (year), or empty.
        context_mode: Relevance threshold: strict, balanced, lenient, disabled.
    """
    import asyncio

    api_key = _get_api_key()
    if not api_key:
        return (
            "Web search requires BRAVE_API_KEY. "
            "Get one free at https://brave.com/search/api/ "
            "then run: phoenix --setup or set BRAVE_API_KEY in .env"
        )

    # Try LLM Context endpoint first (best for Phoenix)
    result = await asyncio.to_thread(
        _search_llm_context,
        query,
        api_key,
        max_results,
        max_tokens,
        freshness,
        context_mode,
    )

    if result:
        return result

    # Fallback to regular web search
    return await asyncio.to_thread(_search_web, query, api_key, max_results)


def _search_llm_context(
    query: str,
    api_key: str,
    max_results: int,
    max_tokens: int,
    freshness: str,
    context_mode: str,
) -> str | None:
    """Brave LLM Context API -- pre-extracted content for LLM."""
    try:
        import httpx
    except ImportError:
        return None

    params = {
        "q": query,
        "count": min(max_results, 50),
        "maximum_number_of_tokens": min(max_tokens, 32768),
        "maximum_number_of_urls": min(max_results, 50),
        "context_threshold_mode": context_mode,
    }
    if freshness:
        params["freshness"] = freshness

    try:
        resp = httpx.get(
            f"{_API_BASE}/llm/context",
            params=params,
            headers={
                "X-Subscription-Token": api_key,
                "Accept": "application/json",
                "Accept-Encoding": "gzip",
            },
            timeout=30.0,
        )

        if resp.status_code == 422 or resp.status_code == 404:
            # LLM Context not available on this plan, fallback
            return None

        if resp.status_code != 200:
            return f"Search error (HTTP {resp.status_code}): {resp.text[:200]}"

        data = resp.json()
        return _format_llm_context(data, query)

    except Exception as e:
        return f"Search failed: {e}"


def _search_web(query: str, api_key: str, max_results: int) -> str:
    """Fallback: Brave Web Search API -- links + snippets."""
    try:
        import httpx
    except ImportError:
        return "httpx not installed. Run: pip install httpx"

    try:
        resp = httpx.get(
            f"{_API_BASE}/web/search",
            params={
                "q": query,
                "count": min(max_results, 20),
                "extra_snippets": "true",
            },
            headers={
                "X-Subscription-Token": api_key,
                "Accept": "application/json",
            },
            timeout=30.0,
        )

        if resp.status_code != 200:
            return f"Search error (HTTP {resp.status_code}): {resp.text[:200]}"

        data = resp.json()
        return _format_web_results(data, query)

    except Exception as e:
        return f"Search failed: {e}"


def _format_llm_context(data: dict, query: str) -> str:
    """Format LLM Context API response into readable text."""
    grounding = data.get("grounding", {})
    sources = data.get("sources", {})
    generic = grounding.get("generic", [])

    if not generic:
        return f"No relevant content found for: {query}"

    lines = [f"[Web search: {query}]", ""]

    for item in generic:
        url = item.get("url", "")
        title = item.get("title", "")
        snippets = item.get("snippets", [])

        # Source metadata
        source = sources.get(url, {})
        age = ""
        if source.get("age") and len(source["age"]) >= 3:
            age = f" ({source['age'][2]})"

        lines.append(f"-- {title}{age}")
        lines.append(f"   {url}")

        for snippet in snippets[:3]:
            # Snippets can be plain text or JSON
            if isinstance(snippet, str):
                text = snippet.strip()[:500]
            else:
                text = json.dumps(snippet)[:500]
            if text:
                lines.append(f"   {text}")
        lines.append("")

    # POI data (local results)
    poi = grounding.get("poi")
    if poi:
        lines.append(f"-- Local: {poi.get('name', '')}")
        for s in poi.get("snippets", [])[:2]:
            lines.append(f"   {str(s)[:300]}")
        lines.append("")

    return "\n".join(lines)


def _format_web_results(data: dict, query: str) -> str:
    """Format regular Web Search API response."""
    web = data.get("web", {})
    results = web.get("results", [])

    if not results:
        return f"No results found for: {query}"

    lines = [f"[Web search: {query}]", ""]

    for r in results[:10]:
        title = r.get("title", "")
        url = r.get("url", "")
        desc = r.get("description", "")
        lines.append(f"-- {title}")
        lines.append(f"   {url}")
        if desc:
            lines.append(f"   {desc[:300]}")

        # Extra snippets if available
        extras = r.get("extra_snippets", [])
        for snippet in extras[:2]:
            lines.append(f"   {snippet[:200]}")
        lines.append("")

    return "\n".join(lines)
