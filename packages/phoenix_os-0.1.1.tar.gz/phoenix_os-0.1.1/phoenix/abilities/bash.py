"""Shell command execution with safety checks."""

import asyncio
import os
import re
import subprocess

from phoenix.abilities import ability

TIMEOUT = 120
MAX_OUTPUT = 16_000

DENY_PATTERNS = [
    r"\brm\s+(-[a-zA-Z]*f[a-zA-Z]*\s+.*)?/\s*$",
    r"\bmkfs\b",
    r"\bdd\s+if=",
    r":\(\)\{.*\}",
    r"\bchmod\s+-R\s+777\s+/\s*$",
    r"\b(shutdown|reboot|halt|poweroff)\b",
    r">\s*/dev/sd[a-z]",
]

ALLOWLIST = [
    "ls",
    "pwd",
    "echo",
    "cat",
    "head",
    "tail",
    "wc",
    "date",
    "whoami",
    "which",
    "type",
    "file",
    "stat",
    "du",
    "df",
    "uname",
    "env",
    "printenv",
    "python3 -c",
    "python -c",
    "node -e",
    "uptime",
    "vm_stat",
    "ps",
    "top -l",
    "sysctl",
    "sw_vers",
    "system_profiler",
    "hostinfo",
    "arch",
    "nproc",
    "free",
    "lscpu",
    "mount",
    "ifconfig",
    "hostname",
    "id",
    "groups",
    "lsof",
    "find",
    "tree",
    "curl -s",
    "wget -q",
    "dig",
    "nslookup",
    "ping -c",
    "traceroute",
    "md5",
    "shasum",
    "sort",
    "uniq",
    "diff",
    "less",
    "more",
    "grep",
    "rg",
    "jq",
    "xargs",
    "dirname",
    "basename",
    "realpath",
    "git status",
    "git log",
    "git diff",
    "git branch",
    "git remote",
    "git show",
    "git rev-parse",
    "git describe",
    "pip list",
    "pip show",
    "pip freeze",
    "pip3 list",
    "pip3 show",
    "npm list",
    "npm ls",
    "npm view",
    "npm info",
    "brew list",
    "brew info",
    "brew doctor",
]

DANGEROUS_OPERATORS = re.compile(r"[;&`$\(]")


def _is_safe(command: str) -> bool:
    cmd = command.strip()

    # Block truly dangerous chaining: ; && ` $() backticks
    if DANGEROUS_OPERATORS.search(cmd):
        return False

    # Allow pipes if every segment starts with an allowlisted command
    if "|" in cmd:
        segments = [s.strip() for s in cmd.split("|")]
        return all(any(seg.startswith(prefix) for prefix in ALLOWLIST) for seg in segments)

    return any(cmd.startswith(prefix) for prefix in ALLOWLIST)


def _safe_env():
    env = os.environ.copy()
    env["CI"] = "true"
    env["NONINTERACTIVE"] = "1"
    return env


def _run_subprocess(command: str, timeout: int, cwd: str) -> str:
    try:
        run_cwd = cwd if cwd and os.path.isdir(cwd) else os.path.expanduser("~")
        result = subprocess.run(
            command,
            shell=True,
            capture_output=True,
            text=True,
            timeout=timeout,
            cwd=run_cwd,
            env=_safe_env(),
        )
        stdout = result.stdout[:MAX_OUTPUT]
        stderr = result.stderr[:MAX_OUTPUT]
        output = stdout.strip()
        if result.returncode != 0 and stderr.strip():
            output += f"\n[stderr]: {stderr.strip()}"
        return output or f"(no output, exit code {result.returncode})"
    except subprocess.TimeoutExpired:
        return f"Error: command timed out after {timeout}s"
    except Exception as e:
        return f"Error: {e}"


@ability(name="bash", description="Execute shell commands with safety checks")
async def bash(command: str, workdir: str = "", timeout: int = TIMEOUT) -> str:
    """Run a shell command and return output.

    Args:
        command: The shell command to execute.
        workdir: Working directory. Empty = home directory.
        timeout: Max seconds before kill. Default 120.
    """
    for pattern in DENY_PATTERNS:
        if re.search(pattern, command):
            return "Blocked: command matches dangerous pattern"

    if not _is_safe(command):
        from phoenix.core.interceptor import get_approval_backend

        backend = get_approval_backend()
        desc = f"$ {command}" + (f"  (in {workdir})" if workdir else "")
        approved = await backend.request_approval("bash", desc, {"command": command})
        if not approved:
            return "(command rejected by user)"

    cwd = workdir if workdir else os.path.expanduser("~")
    return await asyncio.to_thread(_run_subprocess, command, timeout, cwd)
