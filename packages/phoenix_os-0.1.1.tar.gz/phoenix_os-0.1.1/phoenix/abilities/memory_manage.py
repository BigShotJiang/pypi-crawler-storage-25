"""Memory management -- search, update, forget, pin memories.

Gives Phoenix the ability to manage its own memory system.
The brain can search for memories, update them, mark them as
completed/resolved, pin important ones, or forget outdated info.
"""

from phoenix.abilities import PhoenixContext, ability


@ability(
    name="memory_manage",
    description="Search, update, forget, or pin memories",
)
async def memory_manage(
    ctx: PhoenixContext,
    action: str,
    query: str = "",
    content: str = "",
) -> str:
    """Manage Phoenix's persistent memory.

    Args:
        action: One of: search, update, forget, pin, unpin, store, stats
        query: Search query or memory content to find (for search/update/forget/pin/unpin)
        content: New content for update, or fact to store (for update/store)
    """
    if not ctx.memory:
        return "Memory system not available."

    memory = ctx.memory
    action = action.strip().lower()

    if action == "search":
        return _search(memory, query)
    elif action == "update":
        return _update(memory, query, content)
    elif action == "forget":
        return _forget(memory, query)
    elif action == "pin":
        return _pin(memory, query, pinned=True)
    elif action == "unpin":
        return _pin(memory, query, pinned=False)
    elif action == "store":
        return _store(memory, content or query)
    elif action == "stats":
        return _stats(memory)
    else:
        return f"Unknown action: {action}. Use: search, update, forget, pin, unpin, store, stats"


def _search(memory, query: str) -> str:
    """Search memories by content."""
    if not query:
        return "Provide a search query."

    memory._ensure_initialized()
    results = memory.store.search_text(query, limit=10)

    if not results:
        return f"No memories found matching '{query}'."

    lines = [f"Found {len(results)} memories:"]
    for mem in results:
        mid = mem["id"]
        content = mem["content"][:120]
        cat = mem.get("category", "?")
        strength = mem.get("strength", 0)
        pinned = " [PINNED]" if mem.get("pinned") else ""
        superseded = " [SUPERSEDED]" if mem.get("superseded_by") else ""
        lines.append(f"  [{mid}] ({cat}, str:{strength:.2f}{pinned}{superseded}) {content}")
    return "\n".join(lines)


def _update(memory, query: str, new_content: str) -> str:
    """Find a memory by query and update its content."""
    if not query:
        return "Provide a search query to find the memory to update."
    if not new_content:
        return "Provide new content for the memory."

    memory._ensure_initialized()
    results = memory.store.search_text(query, limit=5)

    if not results:
        return f"No memories found matching '{query}'. Nothing to update."

    # Update the best match
    best = results[0]
    old_content = best["content"]
    mid = best["id"]

    # Store new memory that supersedes the old one
    embedding = memory.embedder.embed(new_content)
    new_id = memory.store.add(
        content=new_content,
        category=best.get("category", "fact"),
        namespace=best.get("namespace", "global"),
        embedding=embedding,
        strength=best.get("strength", 1.0),
        prior_value=old_content,
        prior_date=best.get("created_at"),
    )
    memory.store.supersede(mid, new_id)

    return (
        f"Updated memory [{mid}]:\n"
        f"  Was: {old_content[:100]}\n"
        f"  Now: {new_content[:100]}\n"
        f"  New ID: [{new_id}]"
    )


def _forget(memory, query: str) -> str:
    """Find and remove a memory."""
    if not query:
        return "Provide a search query to find the memory to forget."

    memory._ensure_initialized()
    results = memory.store.search_text(query, limit=5)

    if not results:
        return f"No memories found matching '{query}'."

    # Delete the best match
    best = results[0]
    mid = best["id"]
    content = best["content"][:100]
    memory.store.delete(mid)

    return f"Forgotten: [{mid}] {content}"


def _pin(memory, query: str, pinned: bool) -> str:
    """Pin or unpin a memory (pinned = always recalled)."""
    if not query:
        return "Provide a search query to find the memory."

    memory._ensure_initialized()
    results = memory.store.search_text(query, limit=5)

    if not results:
        return f"No memories found matching '{query}'."

    best = results[0]
    mid = best["id"]
    content = best["content"][:100]
    action_word = "Pinned" if pinned else "Unpinned"

    memory.store.set_pinned(mid, pinned)
    return f"{action_word}: [{mid}] {content}"


def _store(memory, content: str) -> str:
    """Explicitly store a new memory fact. Runs through novelty gate."""
    if not content:
        return "Provide content to store."

    memory._ensure_initialized()
    embedding = memory.embedder.embed(content)
    category, _ = memory._cat_clf.classify(embedding)

    # Run through novelty gate (same as automatic pipeline)
    gate_result = memory._gate.evaluate(
        content=content,
        embedding=embedding,
        namespace="global",
    )

    action = gate_result["action"]

    if action == "contradict":
        # Contradiction detected -- supersede the old memory
        memory._gate.handle_contradiction(
            old_id=gate_result["old_id"],
            new_content=content,
            embedding=embedding,
            category=category,
            namespace="global",
        )
        old_content = gate_result.get("old_content", "?")[:80]
        return (
            f"Contradiction detected. Updated:\n"
            f"  Was: {old_content}\n"
            f"  Now: {content[:100]}\n"
            f"  Old memory superseded."
        )

    if action == "strengthen":
        # Near-duplicate exists -- strengthened instead of storing
        existing_id = gate_result.get("existing_id", "?")
        return (
            f"Similar memory already exists [{existing_id}]. Strengthened instead of duplicating."
        )

    if action == "filter":
        # Not novel enough
        reason = gate_result.get("reason", "not novel")
        return f"Not stored: {reason}. Memory already covers this."

    # Passed gate -- store
    from phoenix.memory.config import CATEGORY_IMPORTANCE
    from phoenix.memory.gate import is_self_identity

    importance = CATEGORY_IMPORTANCE.get(category, 1.0)
    strength = 1.0 * importance * gate_result.get("gate", 1.0)

    mid = memory.store.add(
        content=content,
        category=category,
        namespace="global",
        embedding=embedding,
        strength=strength,
    )

    # Auto-pin self-identity
    if category == "entity" and is_self_identity(content):
        memory.store.set_pinned(mid)

    # Build graph edges
    memory._build_edges(mid, embedding, "global")

    return f"Stored: [{mid}] ({category}) {content[:100]}"


def _stats(memory) -> str:
    """Show memory statistics."""
    stats = memory.stats()
    lines = [
        f"Total memories: {stats['total']}",
        f"Pinned: {stats.get('pinned', 0)}",
        f"Clusters: {stats.get('clusters', 0)}",
        f"Graph edges: {stats.get('edge_count', 0)}",
        f"Episodes: {stats.get('episodes', 0)}",
        f"Avg strength: {stats.get('avg_strength', 0)}",
    ]
    if stats.get("by_category"):
        cats = ", ".join(f"{k}:{v}" for k, v in stats["by_category"].items())
        lines.append(f"Categories: {cats}")
    return "\n".join(lines)
