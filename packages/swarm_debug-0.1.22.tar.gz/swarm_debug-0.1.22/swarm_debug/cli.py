import argparse
import filecmp
import json
import os
import shutil
import sys
import urllib.request
from importlib.metadata import version
from pathlib import Path


DEFAULT_PORT = 6969


class _StalenessCheckVersionAction(argparse._VersionAction):
    """Show staleness notice before printing version and exiting."""
    def __call__(self, parser, namespace, values, option_string=None):
        _check_all_staleness(self.version.split()[-1])
        super().__call__(parser, namespace, values, option_string)


class _StalenessCheckHelpAction(argparse._HelpAction):
    """Show staleness notice before printing help and exiting."""
    def __call__(self, parser, namespace, values, option_string=None):
        pkg_version = version("swarm-debug")
        _check_all_staleness(pkg_version)
        super().__call__(parser, namespace, values, option_string)


_SKILL_SRC = Path(__file__).resolve().parent / "data" / "SKILL.md"


def _skill_dst_dir() -> Path:
    """Project-local skill directory so each project tracks its own version."""
    from swarm_debug.core.DEFAULTS import get_root_dir
    return Path(get_root_dir()) / ".cursor" / "skills" / "swarm-debug"


def _skill_dst() -> Path:
    return _skill_dst_dir() / "SKILL.md"


def _cmd_gui(args):
    from swarm_debug.server import start_server
    start_server(port=args.port, open_browser=True)


def _cmd_status(args):
    from swarm_debug.core.toggle_ops import load_tree, print_status
    tree = load_tree(quiet=args.json)
    print_status(tree, json_mode=args.json)


def _cmd_toggle(args):
    from swarm_debug.core.toggle_ops import load_tree, save_tree, toggle_all, toggle_node

    tree = load_tree()

    if args.all:
        toggle_all(tree, args.state == "on")
        save_tree(tree)
        state_label = "ON" if args.state == "on" else "OFF"
        print(f"Toggled all files {state_label}")
        return

    if not args.path:
        print("Error: a path is required (or use --all)", file=sys.stderr)
        sys.exit(1)

    state = args.state == "on"
    if toggle_node(tree, args.path, state):
        save_tree(tree)
        state_label = "ON" if state else "OFF"
        print(f"Toggled '{args.path}' {state_label}")
    else:
        print(f"Error: path '{args.path}' not found in the debug tree", file=sys.stderr)
        sys.exit(1)


def _cmd_set_root(args):
    from swarm_debug.core.DEFAULTS import set_root_dir
    from swarm_debug.core.data_dir import get_data_file

    path = os.path.abspath(args.path)
    if not os.path.isdir(path):
        print(f"Error: '{path}' is not a valid directory", file=sys.stderr)
        sys.exit(1)

    set_root_dir(path)
    needs_resync_file = get_data_file("needs_resync.txt", path)
    with open(needs_resync_file, "w") as f:
        f.write("1")
    print(f"Project root set to: {path}")


def _cmd_set_color(args):
    from swarm_debug.core.toggle_ops import load_tree, save_tree, set_node_color

    tree = load_tree()
    if set_node_color(tree, args.path, args.color):
        save_tree(tree)
        print(f"Set color of '{args.path}' to {args.color}")
    else:
        if not args.color.startswith("#") or len(args.color) != 7:
            pass  # error already printed by set_node_color
        else:
            print(f"Error: path '{args.path}' not found in the debug tree", file=sys.stderr)
        sys.exit(1)


def _cmd_set_emoji(args):
    from swarm_debug.core.toggle_ops import load_tree, save_tree, set_node_emoji

    tree = load_tree()
    if set_node_emoji(tree, args.path, args.emoji):
        save_tree(tree)
        print(f"Set emoji of '{args.path}' to {args.emoji}")
    else:
        print(f"Error: path '{args.path}' not found in the debug tree", file=sys.stderr)
        sys.exit(1)


def _cmd_reset(args):
    from swarm_debug.core.toggle_ops import load_tree, reset_all, save_tree

    tree = load_tree()
    reset_all(tree)
    save_tree(tree)
    print("Reset all colors and emojis to defaults")


def _install_cursor_skill():
    if not _SKILL_SRC.exists():
        print("Error: bundled SKILL.md not found in package data", file=sys.stderr)
        sys.exit(1)

    dst_dir = _skill_dst_dir()
    dst = _skill_dst()

    if dst.exists():
        if filecmp.cmp(_SKILL_SRC, dst, shallow=False):
            print(f"Cursor skill is already up to date: {dst}")
            return
        shutil.copy2(_SKILL_SRC, dst)
        print(f"Cursor skill updated: {dst}")
    else:
        dst_dir.mkdir(parents=True, exist_ok=True)
        shutil.copy2(_SKILL_SRC, dst)
        print(f"Cursor skill installed: {dst}")

    print("Tip: this will be kept in sync automatically whenever you use any swarm-debug command.")


def _uninstall_cursor_skill():
    dst_dir = _skill_dst_dir()

    if not dst_dir.exists():
        print("Cursor skill is not installed, nothing to remove.")
        return

    shutil.rmtree(dst_dir)
    print(f"Cursor skill removed: {dst_dir}")


def _print_boxed_notice(lines, *, color="\033[31m"):
    """Print a styled box with colored border and bold text to stderr."""
    BOLD = "\033[1m"
    RESET = "\033[0m"

    inner_width = max(len(line) for line in lines) + 2
    top = f"{color}╭{'─' * inner_width}╮{RESET}"
    bot = f"{color}╰{'─' * inner_width}╯{RESET}"
    mid = [f"{color}│{RESET} {BOLD}{line.ljust(inner_width - 2)}{RESET} {color}│{RESET}" for line in lines]

    print(file=sys.stderr)
    print(top, file=sys.stderr)
    for row in mid:
        print(row, file=sys.stderr)
    print(bot, file=sys.stderr)
    print(file=sys.stderr)


def _check_skill_staleness():
    """Warn if the installed Cursor skill is outdated compared to the bundled one."""
    dst = _skill_dst()
    if dst.exists() and _SKILL_SRC.exists():
        if not filecmp.cmp(_SKILL_SRC, dst, shallow=False):
            _print_boxed_notice([
                "⚠  Your Cursor skill is out of date.",
                "   Run: swarm-debug --install-cursor-skill",
            ])


def _check_package_staleness(current_version: str):
    """Warn if a newer version of swarm-debug is available on PyPI."""
    from packaging.version import Version, InvalidVersion

    try:
        url = "https://pypi.org/pypi/swarm-debug/json"
        req = urllib.request.Request(url, headers={"Accept": "application/json"})
        with urllib.request.urlopen(req, timeout=2) as resp:
            data = json.loads(resp.read())
        latest = data["info"]["version"]
        if Version(latest) > Version(current_version):
            _print_boxed_notice([
                f"⚠  A newer swarm-debug is available: {latest}",
                f"   You are running: {current_version}",
                f"   Run: pip install --upgrade swarm-debug",
            ], color="\033[33m")
    except (urllib.error.URLError, TimeoutError, KeyError,
            json.JSONDecodeError, InvalidVersion, OSError):
        pass


def _check_all_staleness(current_version: str):
    _check_skill_staleness()
    _check_package_staleness(current_version)


def main():
    pkg_version = version("swarm-debug")

    parser = argparse.ArgumentParser(
        prog="swarm-debug",
        description="A colorized, toggleable debug logger with a web GUI and CLI.",
        epilog="Run 'swarm-debug <command> --help' for more info on a specific command.",
        add_help=False,
    )
    parser.add_argument(
        "-h", "--help", action=_StalenessCheckHelpAction,
        default=argparse.SUPPRESS, help="show this help message and exit",
    )
    parser.add_argument(
        "--version", action=_StalenessCheckVersionAction,
        version=f"swarm-debug {pkg_version}",
    )
    parser.add_argument(
        "--install-cursor-skill", action="store_true",
        help="Install the swarm-debug Cursor AI skill to .cursor/skills/ in the project root",
    )
    parser.add_argument(
        "--uninstall-cursor-skill", action="store_true",
        help="Remove the swarm-debug Cursor AI skill from .cursor/skills/ in the project root",
    )
    subparsers = parser.add_subparsers(dest="command")

    # --- gui ---
    gui_parser = subparsers.add_parser("gui", help="Launch the debug configuration GUI")
    gui_parser.add_argument(
        "--port", "-p", type=int, default=DEFAULT_PORT,
        help=f"Port for the GUI server (default: {DEFAULT_PORT})",
    )
    gui_parser.set_defaults(func=_cmd_gui)

    # --- status ---
    status_parser = subparsers.add_parser("status", help="Show the debug toggle tree")
    status_parser.add_argument(
        "--json", action="store_true", help="Output as JSON"
    )
    status_parser.set_defaults(func=_cmd_status)

    # --- toggle ---
    toggle_parser = subparsers.add_parser(
        "toggle", help="Toggle debug output for a file or directory"
    )
    toggle_parser.add_argument("state", choices=["on", "off"], help="Desired state")
    toggle_parser.add_argument("path", nargs="?", default=None, help="Relative path (e.g. src/utils/helpers.py)")
    toggle_parser.add_argument(
        "--all", action="store_true", help="Toggle all files"
    )
    toggle_parser.set_defaults(func=_cmd_toggle)

    # --- set-root ---
    root_parser = subparsers.add_parser("set-root", help="Set the project root directory")
    root_parser.add_argument("path", help="Absolute or relative path to the project root")
    root_parser.set_defaults(func=_cmd_set_root)

    # --- set-color ---
    color_parser = subparsers.add_parser("set-color", help="Set a node's debug output color")
    color_parser.add_argument("path", help="Relative path to the file or directory")
    color_parser.add_argument("color", help="Hex color (e.g. #ff0000)")
    color_parser.set_defaults(func=_cmd_set_color)

    # --- set-emoji ---
    emoji_parser = subparsers.add_parser("set-emoji", help="Set a node's debug output emoji")
    emoji_parser.add_argument("path", help="Relative path to the file or directory")
    emoji_parser.add_argument("emoji", help="Emoji character")
    emoji_parser.set_defaults(func=_cmd_set_emoji)

    # --- reset ---
    reset_parser = subparsers.add_parser("reset", help="Reset all colors and emojis to defaults")
    reset_parser.set_defaults(func=_cmd_reset)

    args = parser.parse_args()

    if args.install_cursor_skill:
        _install_cursor_skill()
        return

    if args.uninstall_cursor_skill:
        _uninstall_cursor_skill()
        return

    _check_all_staleness(pkg_version)

    if args.command is None:
        parser.print_help()
        sys.exit(0)

    args.func(args)
