from collections.abc import Mapping, Sequence
from pathlib import Path

import gymnasium as gym
import numpy as np
import torch

from axiomrl.algorithms.her import HER
from axiomrl.data.her_replay_buffer import HERReplayBuffer
from axiomrl.envs.factory import build_env, make_vector_env
from axiomrl.envs.goals import (
    GoalSpaceSpec,
    flatten_goal_observation,
    infer_goal_space_spec,
    is_goal_observation_space,
)
from axiomrl.experiment.checkpointing import CheckpointState
from axiomrl.experiment.config import TrainConfig
from axiomrl.models.mlp_ddpg import MLPDDPGModel
from axiomrl.runtime.callbacks import Callback, CallbackList
from axiomrl.runtime.collector import CollectResult
from axiomrl.runtime.controls import resolve_eval_interval, should_run_evaluation
from axiomrl.runtime.evaluation_support import evaluate_continuous_episodes
from axiomrl.runtime.resume_state import (
    capture_global_random_state,
    capture_vector_env_resume_state,
    restore_global_random_state,
    restore_vector_env_resume_state,
)
from axiomrl.runtime.run_utils import save_training_checkpoint
from axiomrl.runtime.session import create_training_session
from axiomrl.runtime.td3_trainer import _action_bounds, _apply_exploration_noise, _scale_actions
from axiomrl.runtime.trainer import TrainerState, TrainResult
from axiomrl.runtime.types import MetricDict


def _infer_her_spaces(config: TrainConfig) -> tuple[GoalSpaceSpec, int]:
    env = build_env(config, 0)
    try:
        obs_space = env.observation_space
        action_space = env.action_space
        if not is_goal_observation_space(obs_space):
            raise TypeError(f"unsupported observation space for HER trainer: {type(obs_space)!r}")
        if not isinstance(action_space, gym.spaces.Box):
            raise TypeError(f"unsupported action space for HER trainer: {type(action_space)!r}")
        if action_space.shape is None or len(action_space.shape) != 1:
            raise ValueError(f"expected flat 1D actions, got shape={action_space.shape!r}")
        return infer_goal_space_spec(obs_space), int(action_space.shape[0])
    finally:
        env.close()


def _slice_goal_observation(observation: Mapping[str, np.ndarray], env_index: int) -> dict[str, np.ndarray]:
    return {key: np.asarray(value[env_index], dtype=np.float32) for key, value in observation.items()}


def _evaluate_her_policy(
    model: MLPDDPGModel,
    config: TrainConfig,
    *,
    device: torch.device,
    num_episodes: int,
) -> MetricDict:
    class _ActionFn:
        def __init__(self) -> None:
            self.low: torch.Tensor | None = None
            self.high: torch.Tensor | None = None
            self.success = 0.0

        def bind_env(self, env: gym.Env) -> None:
            action_space = env.action_space
            if not isinstance(action_space, gym.spaces.Box):
                raise TypeError(f"unsupported action space for HER evaluation: {type(action_space)!r}")
            self.low, self.high = _action_bounds(action_space, device=device)

        def reset(self) -> None:
            self.success = 0.0

        def prepare_observation(self, obs) -> torch.Tensor:  # type: ignore[no-untyped-def]
            return torch.as_tensor(flatten_goal_observation(obs), dtype=torch.float32, device=device)

        def __call__(self, obs_tensor: torch.Tensor) -> np.ndarray:
            if self.low is None or self.high is None:
                raise RuntimeError("action bounds must be bound before evaluation")
            with torch.no_grad():
                normalized_action = model.actor(obs_tensor).squeeze(0)
                env_action = _scale_actions(normalized_action, low=self.low, high=self.high)
            return env_action.cpu().numpy()

        def after_step(self, next_obs, reward: float, done: bool, truncated: bool, info) -> None:  # type: ignore[no-untyped-def]
            del next_obs, reward
            success = bool(info.get("is_success", done and not truncated))
            self.success = float(max(self.success, float(success)))

        def episode_metrics(self) -> dict[str, float]:
            return {"eval_success_rate": self.success}

    return evaluate_continuous_episodes(
        config,
        device=device,
        num_episodes=num_episodes,
        action_fn=_ActionFn(),
    )


def _restore_training_state(
    *,
    algorithm: HER,
    replay_buffer: HERReplayBuffer,
    envs: gym.vector.VectorEnv,
    checkpoint_state: CheckpointState | None,
) -> tuple[object | None, int, int]:
    if checkpoint_state is None:
        return None, 0, 0
    algorithm.load_state_dict(checkpoint_state.algorithm_state)
    if checkpoint_state.buffer_state is not None:
        replay_buffer.load_state_dict(checkpoint_state.buffer_state)
    restored_obs = None
    resume_context = checkpoint_state.trainer_state.get("resume_context")
    if isinstance(resume_context, dict):
        env_resume_state = resume_context.get("env_state")
        if isinstance(env_resume_state, dict):
            restored_obs = restore_vector_env_resume_state(envs, env_resume_state)
        random_state = resume_context.get("random_state")
        if isinstance(random_state, dict):
            restore_global_random_state(random_state)
    return (
        restored_obs,
        int(checkpoint_state.trainer_state.get("global_step", 0)),
        int(checkpoint_state.trainer_state.get("update_count", 0)),
    )


def _as_goal_observation_mapping(obs: object, *, source: str) -> Mapping[str, np.ndarray]:
    if not isinstance(obs, Mapping):
        raise TypeError(f"expected goal-conditioned Mapping observations from {source}, got {type(obs)!r}")
    return obs


def _store_her_transitions(
    replay_buffer: HERReplayBuffer,
    *,
    obs: Mapping[str, np.ndarray],
    actions: torch.Tensor,
    rewards: np.ndarray,
    next_obs: Mapping[str, np.ndarray],
    terminated: np.ndarray,
    truncated: np.ndarray,
    num_envs: int,
) -> None:
    for env_index in range(num_envs):
        replay_buffer.add(
            env_index=env_index,
            obs=_slice_goal_observation(obs, env_index),
            actions=actions[env_index].detach().cpu().numpy(),
            rewards=float(rewards[env_index]),
            next_obs=_slice_goal_observation(next_obs, env_index),
            terminated=bool(terminated[env_index]),
            truncated=bool(truncated[env_index]),
        )


def _maybe_update_algorithm(
    *,
    algorithm: HER,
    replay_buffer: HERReplayBuffer,
    reward_env: gym.Env,
    batch_size: int,
    learning_starts: int,
    global_step: int,
    train_frequency: int,
    callback_list: CallbackList,
    trainer_state: TrainerState,
    latest_update_metrics: MetricDict,
    update_count: int,
) -> tuple[MetricDict, int]:
    if len(replay_buffer) < max(batch_size, learning_starts):
        return latest_update_metrics, update_count
    if global_step % train_frequency != 0:
        return latest_update_metrics, update_count

    result = algorithm.update(replay_buffer.sample(batch_size, env=reward_env), global_step=global_step)
    callback_list.on_update_end(trainer_state, result)
    return result.metrics, update_count + result.num_gradient_steps


def _maybe_run_evaluation(
    *,
    algorithm: HER,
    model: MLPDDPGModel,
    config: TrainConfig,
    logger,
    callback_list: CallbackList,
    trainer_state: TrainerState,
    metrics: MetricDict,
    global_step: int,
    eval_interval: int,
    device: torch.device,
) -> tuple[MetricDict, bool]:
    if not should_run_evaluation(
        global_step=global_step,
        total_timesteps=config.total_timesteps,
        eval_interval=eval_interval,
    ):
        return metrics, False

    algorithm.set_eval_mode()
    eval_metrics = _evaluate_her_policy(
        model,
        config,
        device=device,
        num_episodes=config.eval_episodes,
    )
    algorithm.set_train_mode()
    evaluated_metrics = {**metrics, **eval_metrics}
    logger.log_metrics(evaluated_metrics, step=global_step)
    callback_list.on_eval_end(trainer_state, evaluated_metrics)
    return evaluated_metrics, trainer_state.should_stop


def train_her(
    config: TrainConfig,
    *,
    run_suffix: str | None = None,
    checkpoint_state: CheckpointState | None = None,
    callbacks: Sequence[Callback] | None = None,
) -> TrainResult:
    session = create_training_session(config, algorithm="her", run_suffix=run_suffix, callbacks=callbacks)
    device = session.device
    run_context = session.run_context
    logger = session.logger
    callback_list = session.callback_list
    trainer_state = session.trainer_state

    buffer_capacity = int(config.algo_kwargs.get("buffer_capacity", 50000))
    batch_size = int(config.algo_kwargs.get("batch_size", 256))
    learning_starts = int(config.algo_kwargs.get("learning_starts", 1000))
    train_frequency = int(config.algo_kwargs.get("train_frequency", 1))
    hidden_sizes = tuple(config.algo_kwargs.get("hidden_sizes", (256, 256)))
    learning_rate = float(config.algo_kwargs.get("learning_rate", 3e-4))
    gamma = float(config.algo_kwargs.get("gamma", 0.99))
    tau = float(config.algo_kwargs.get("tau", 0.005))
    her_ratio = float(config.algo_kwargs.get("her_ratio", 0.8))
    goal_selection_strategy = str(config.algo_kwargs.get("goal_selection_strategy", "future"))
    exploration_noise = float(config.algo_kwargs.get("exploration_noise", 0.0))
    eval_interval = resolve_eval_interval(config)

    torch.manual_seed(config.seed)
    np.random.seed(config.seed)

    envs = None
    reward_env = None
    checkpoint_path: Path | None = None
    metrics: MetricDict = {}

    try:
        envs = make_vector_env(config)
        reward_env = build_env(config, 0)
        goal_spec, action_dim = _infer_her_spaces(config)
        action_space = envs.single_action_space
        if not isinstance(action_space, gym.spaces.Box):
            raise TypeError(f"unsupported action space for HER trainer: {type(action_space)!r}")
        low, high = _action_bounds(action_space, device=device)

        model = MLPDDPGModel(
            obs_dim=goal_spec.flat_observation_dim,
            action_dim=action_dim,
            hidden_sizes=hidden_sizes,
        ).to(device)
        algorithm = HER(
            model=model,
            learning_rate=learning_rate,
            gamma=gamma,
            tau=tau,
        )
        replay_buffer = HERReplayBuffer(
            capacity=buffer_capacity,
            num_envs=config.num_envs,
            obs_shape=(goal_spec.observation_dim,),
            goal_shape=(goal_spec.goal_dim,),
            action_shape=(action_dim,),
            her_ratio=her_ratio,
            goal_selection_strategy=goal_selection_strategy,
            seed=config.seed,
            device=device,
        )

        initial_obs, _ = envs.reset(seed=config.seed)
        obs = _as_goal_observation_mapping(initial_obs, source="vector env")
        restored_obs, global_step, update_count = _restore_training_state(
            algorithm=algorithm,
            replay_buffer=replay_buffer,
            envs=envs,
            checkpoint_state=checkpoint_state,
        )
        if restored_obs is not None:
            obs = _as_goal_observation_mapping(restored_obs, source="resume state")
        latest_update_metrics: MetricDict = {}
        trainer_state.global_step = global_step
        trainer_state.update_count = update_count
        callback_list.on_train_start(trainer_state)

        while global_step < config.total_timesteps:
            obs_tensor = torch.as_tensor(flatten_goal_observation(obs), dtype=torch.float32, device=device)
            with torch.no_grad():
                normalized_actions = model.actor(obs_tensor)
                normalized_actions = _apply_exploration_noise(normalized_actions, std=exploration_noise)
                env_actions = _scale_actions(normalized_actions, low=low, high=high)

            raw_next_obs, rewards, terminated, truncated, _ = envs.step(env_actions.cpu().numpy())
            next_obs = _as_goal_observation_mapping(raw_next_obs, source="vector env")
            dones = np.logical_or(terminated, truncated).astype(np.float32)

            _store_her_transitions(
                replay_buffer,
                obs=obs,
                actions=normalized_actions,
                rewards=rewards,
                next_obs=next_obs,
                terminated=terminated,
                truncated=truncated,
                num_envs=config.num_envs,
            )

            obs = next_obs
            global_step += config.num_envs
            trainer_state.global_step = global_step
            callback_list.on_collect_end(
                trainer_state,
                CollectResult(
                    num_env_steps=config.num_envs,
                    num_episodes=int(np.sum(dones)),
                    metrics={"global_step": float(global_step), "buffer_size": float(len(replay_buffer))},
                    last_obs=obs,
                ),
            )

            latest_update_metrics, update_count = _maybe_update_algorithm(
                algorithm=algorithm,
                replay_buffer=replay_buffer,
                reward_env=reward_env,
                batch_size=batch_size,
                learning_starts=learning_starts,
                global_step=global_step,
                train_frequency=train_frequency,
                callback_list=callback_list,
                trainer_state=trainer_state,
                latest_update_metrics=latest_update_metrics,
                update_count=update_count,
            )
            trainer_state.update_count = update_count

            metrics = {
                **latest_update_metrics,
                "her_ratio": her_ratio,
                "global_step": float(global_step),
                "buffer_size": float(len(replay_buffer)),
                "gradient_steps": float(update_count),
            }
            metrics, should_stop = _maybe_run_evaluation(
                algorithm=algorithm,
                model=model,
                config=config,
                logger=logger,
                callback_list=callback_list,
                trainer_state=trainer_state,
                metrics=metrics,
                global_step=global_step,
                eval_interval=eval_interval,
                device=device,
            )
            if should_stop:
                break

        checkpoint_path = save_training_checkpoint(
            run_context=run_context,
            config=config,
            algorithm_state=algorithm.state_dict(),
            buffer_state=replay_buffer.state_dict(),
            trainer_state={
                "global_step": global_step,
                "update_count": update_count,
                "should_stop": trainer_state.should_stop,
                "stop_reason": trainer_state.stop_reason,
                "resume_context": {
                    "env_state": capture_vector_env_resume_state(envs),
                    "random_state": capture_global_random_state(),
                },
            },
            metrics=metrics,
        )
    finally:
        if envs is not None:
            envs.close()
        if reward_env is not None:
            reward_env.close()
        session.close()

    result = TrainResult(
        run_dir=run_context.run_dir,
        checkpoint_path=checkpoint_path,
        metrics=metrics,
    )
    callback_list.on_train_end(trainer_state, result)
    return result
