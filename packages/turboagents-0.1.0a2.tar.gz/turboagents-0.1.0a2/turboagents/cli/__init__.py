"""CLI package."""

