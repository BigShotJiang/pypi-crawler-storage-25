# IVAS -- Immortal Virtual Agent Sessions

**Your AI agent remembers everything. Forever. Across crashes, restarts, and updates.**

IVAS gives any AI agent persistent memory, session continuity, and verified knowledge restoration.

## Install

```bash
pip install ivas
```

## Quick Start

```python
from ivas import Client

client = Client(api_key="your-key")

# Store memories
client.remember("user", "preference", "Dark mode enabled")

# Search memories (< 1ms server-side)
results = client.recall("dark mode")

# Save session state
client.save_session(
    active_task="Processing invoices",
    current_thought="Checking line 47",
)

# Restore after crash
state = client.restore_session()

# Verify nothing was lost
report = client.audit()
```

## CLI

```bash
export IVAS_API_KEY="your-key"
ivas remember user preference "Dark mode enabled"
ivas recall "dark mode"
ivas stats
ivas save "Processing invoices" "Checking line 47"
ivas restore
ivas audit
ivas health
```

## Features

- **Immortal Memory** -- Survives crashes, restarts, updates. Proven, not promised.
- **Einherjar Protocol** -- Verifies nothing was lost after every session transition.
- **Sub-1ms Recall** -- FTS5 full-text search, no embedding drift.
- **Private Vault** -- Your data on isolated infrastructure. Never shared.
- **Any Model** -- Works with Claude, GPT, LLaMA, Gemini, or custom agents.
- **Zero Setup** -- `pip install ivas`, get an API key, done.

## Get Your API Key

Sign up at [ivas.dev](https://ivas.dev) to get your API key and start your free trial.

## License

Proprietary -- IVAS Corp

Patent: 64/019,813 (Provisional) -- Multi-Instance AI Agent Session Relay System with Persistent State Recovery.

## Links

- [ivas.dev](https://ivas.dev) -- Homepage
- [Documentation](https://ivas.dev/docs)
