"""
IVAS API Client -- connects to ivas.dev for immortal agent memory.

All memory storage, search, session management, and verification
runs on IVAS servers. This client handles authentication and API calls.

Usage:
    from ivas import Client

    client = Client(api_key="your-key")
    client.remember("user", "preference", "Dark mode enabled")
    results = client.recall("dark mode")
    client.save_session(active_task="Processing data")
    state = client.restore_session()
    report = client.audit()
"""

from __future__ import annotations

import json
import os
from typing import Optional

import httpx


class Client:
    """IVAS API client for immortal agent memory.

    Connects to ivas.dev servers where all memory operations run.
    Your data is stored in an isolated, private vault.

    Args:
        api_key: Your IVAS API key (get one at ivas.dev).
        base_url: API endpoint (default: https://api.ivas.dev).
        timeout: Request timeout in seconds.
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: str = "https://api.ivas.dev",
        timeout: float = 30.0,
    ):
        self.api_key = api_key or os.environ.get("IVAS_API_KEY", "")
        if not self.api_key:
            raise ValueError(
                "API key required. Pass api_key= or set IVAS_API_KEY env var. "
                "Get your key at https://ivas.dev"
            )

        self.base_url = base_url.rstrip("/")
        self._client = httpx.Client(
            base_url=self.base_url,
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "User-Agent": "ivas-python/0.2.0",
            },
            timeout=timeout,
        )

    # -- Memory --

    def remember(
        self,
        category: str,
        subject: str,
        content: str,
        confidence: float = 0.8,
        source: Optional[str] = None,
    ) -> dict:
        """Store a memory in your vault."""
        resp = self._client.post("/api/v1/remember", json={
            "category": category,
            "subject": subject,
            "content": content,
            "confidence": confidence,
            "source": source,
        })
        resp.raise_for_status()
        return resp.json()

    def recall(
        self,
        query: str,
        limit: int = 10,
        category: Optional[str] = None,
    ) -> list[dict]:
        """Search your memories."""
        resp = self._client.post("/api/v1/recall", json={
            "query": query,
            "limit": limit,
            "category": category,
        })
        resp.raise_for_status()
        return resp.json().get("results", [])

    def recent(self, limit: int = 10) -> list[dict]:
        """Get most recent memories."""
        resp = self._client.get("/api/v1/recent", params={"limit": limit})
        resp.raise_for_status()
        return resp.json().get("results", [])

    def stats(self) -> dict:
        """Get vault statistics."""
        resp = self._client.get("/api/v1/stats")
        resp.raise_for_status()
        return resp.json()

    # -- Sessions --

    def save_session(
        self,
        active_task: Optional[str] = None,
        current_thought: Optional[str] = None,
        decisions: Optional[dict] = None,
        pending_actions: Optional[list[str]] = None,
    ) -> dict:
        """Save current session state."""
        resp = self._client.post("/api/v1/session/save", json={
            "active_task": active_task,
            "current_thought": current_thought,
            "decisions": decisions or {},
            "pending_actions": pending_actions or [],
        })
        resp.raise_for_status()
        return resp.json()

    def restore_session(self) -> Optional[dict]:
        """Restore most recent session state."""
        resp = self._client.post("/api/v1/session/restore")
        resp.raise_for_status()
        return resp.json().get("state")

    # -- Verification --

    def audit(
        self,
        decisions: Optional[list[str]] = None,
        corrections: Optional[list[str]] = None,
        critical_facts: Optional[list[str]] = None,
    ) -> dict:
        """Run Einherjar knowledge verification."""
        resp = self._client.post("/api/v1/audit", json={
            "decisions": decisions or [],
            "corrections": corrections or [],
            "critical_facts": critical_facts or [],
        })
        resp.raise_for_status()
        return resp.json()

    # -- Corrections --

    def add_correction(
        self,
        mistake: str,
        correction: str,
        severity: int = 3,
    ) -> dict:
        """Record a correction."""
        resp = self._client.post("/api/v1/corrections", json={
            "mistake": mistake,
            "correction": correction,
            "severity": severity,
        })
        resp.raise_for_status()
        return resp.json()

    def get_corrections(self) -> list[dict]:
        """Get active corrections."""
        resp = self._client.get("/api/v1/corrections")
        resp.raise_for_status()
        return resp.json().get("corrections", [])

    # -- Utility --

    def health(self) -> dict:
        """Check API health."""
        resp = self._client.get("/api/v1/health")
        resp.raise_for_status()
        return resp.json()

    def export(self) -> dict:
        """Export all vault data as JSON."""
        resp = self._client.get("/api/v1/export")
        resp.raise_for_status()
        return resp.json()

    def close(self):
        """Close the HTTP connection."""
        self._client.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    def __repr__(self):
        return f"ivas.Client(base_url='{self.base_url}')"
