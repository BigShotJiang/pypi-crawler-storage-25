"""
IVAS -- Immortal Virtual Agent Sessions.

True immortal memory for AI agents. Your agent remembers everything forever --
across crashes, restarts, and updates. Patent-pending. Zero dependencies.

Usage:
    from ivas import Client

    client = Client(api_key="your-key")
    client.remember("user", "name", "Boss prefers dark mode")
    client.recall("dark mode")
"""

__version__ = "0.2.0"

from ivas.client import Client

__all__ = ["Client", "__version__"]
