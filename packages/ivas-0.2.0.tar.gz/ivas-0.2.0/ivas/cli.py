"""
IVAS CLI -- Command-line interface for ivas.dev.

Usage:
    ivas remember <category> <subject> <content>
    ivas recall <query>
    ivas stats
    ivas save <task> [thought]
    ivas restore
    ivas audit
    ivas health
    ivas version
"""

from __future__ import annotations

import argparse
import json
import os
import sys


def get_client():
    """Get an authenticated IVAS client."""
    from ivas.client import Client

    api_key = os.environ.get("IVAS_API_KEY", "")
    if not api_key:
        print("Error: IVAS_API_KEY environment variable not set.")
        print("Get your API key at https://ivas.dev")
        sys.exit(1)
    return Client(api_key=api_key)


def main():
    parser = argparse.ArgumentParser(
        prog="ivas",
        description="IVAS -- Immortal Virtual Agent Sessions",
    )
    sub = parser.add_subparsers(dest="command")

    # remember
    p_rem = sub.add_parser("remember", help="Store a memory")
    p_rem.add_argument("category")
    p_rem.add_argument("subject")
    p_rem.add_argument("content")

    # recall
    p_rec = sub.add_parser("recall", help="Search memories")
    p_rec.add_argument("query")
    p_rec.add_argument("--limit", type=int, default=10)

    # stats
    sub.add_parser("stats", help="Vault statistics")

    # save
    p_save = sub.add_parser("save", help="Save session state")
    p_save.add_argument("task")
    p_save.add_argument("thought", nargs="?", default=None)

    # restore
    sub.add_parser("restore", help="Restore session state")

    # audit
    sub.add_parser("audit", help="Run Einherjar verification")

    # health
    sub.add_parser("health", help="Check API health")

    # version
    sub.add_parser("version", help="Show version")

    args = parser.parse_args()

    if args.command == "version":
        from ivas import __version__
        print(f"ivas {__version__}")
        return

    if not args.command:
        parser.print_help()
        return

    client = get_client()

    try:
        if args.command == "remember":
            result = client.remember(args.category, args.subject, args.content)
            print(f"Stored memory #{result.get('id', '?')}")

        elif args.command == "recall":
            results = client.recall(args.query, limit=args.limit)
            if not results:
                print("No memories found.")
            for r in results:
                print(f"  [{r.get('id', '?')}] {r.get('category', '')}/{r.get('subject', '')}: {r.get('content', '')}")

        elif args.command == "stats":
            stats = client.stats()
            print(json.dumps(stats, indent=2))

        elif args.command == "save":
            result = client.save_session(active_task=args.task, current_thought=args.thought)
            print(f"Session saved: {result.get('status', 'ok')}")

        elif args.command == "restore":
            state = client.restore_session()
            if state:
                print(json.dumps(state, indent=2))
            else:
                print("No saved session found.")

        elif args.command == "audit":
            report = client.audit()
            print(json.dumps(report, indent=2))

        elif args.command == "health":
            health = client.health()
            print(json.dumps(health, indent=2))

    finally:
        client.close()


if __name__ == "__main__":
    main()
