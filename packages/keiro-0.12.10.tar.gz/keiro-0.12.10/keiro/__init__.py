"""Keiro — EB1 multi-model ensemble inference.

Quick start::

    pip install keiro
    keiro "What is ML?"

Prompt-first facade::

    from keiro import models

    reply = models.response("eb1-preview", "Explain quantum computing.")
    print(reply.text)

    creative = models.instance("eb1-preview", temperature=0.8)
    print(creative("Write a limerick"))

The ``complete`` function sends a prompt to the hosted Keiro API and
returns the response text. EB1 runs multiple frontier models in
parallel and synthesizes the best response.

Full client::

    from keiro import Client

    client = Client()
    response = client.chat(
        messages=[{"role": "user", "content": "Explain quantum computing."}],
        model="eb1-preview",
    )

    # Batch concurrent calls
    results = client.batch(
        ["What is ML?", "What is AI?", "What is DL?"],
        model="eb1-preview",
    )

Models:

    - ``"eb1-preview"`` (default) — adaptive frontier model
    - ``"eb1-efficient-preview"`` — adaptive frontier model, cost-optimized
    - ``"eb1-delta-preview"`` — adaptive model with orchestration
    - ``"eb1"`` — standard multi-model
    - ``"eb1-pro"`` — extended capability
    - ``"eb1-frontier"`` — highest quality, max reasoning
    - ``"eb1-codex"`` — optimized for code and SWE
    - ``"eb1-fast"`` — low latency
    - ``"eb1-fast-preview"`` — adaptive, low latency
    - ``"eb1-frontier-preview"`` — adaptive, max quality
    - ``"claude-opus-4-6"`` — direct single-model passthrough
    - ``"gpt-5.4"`` — direct single-model passthrough

Configuration:

    Run ``keiro setup`` to store your API key at ``~/.keiro/credentials``,
    or set ``KEIRO_API_KEY`` and ``KEIRO_BASE_URL`` environment variables.
"""

__version__ = "0.12.10"

from keiro.client import (
    BatchError,
    Client,
    KeirError,
    KeirValidationError,
    RateLimitInfo,
    complete,
)
from keiro.model_api import ModelBinding, ModelInvocation, ModelResult, ModelsAPI, Response

models = ModelsAPI()

__all__ = [
    "BatchError",
    "Client",
    "KeirError",
    "KeirValidationError",
    "ModelBinding",
    "ModelInvocation",
    "ModelResult",
    "ModelsAPI",
    "RateLimitInfo",
    "Response",
    "complete",
    "models",
    "__version__",
]
