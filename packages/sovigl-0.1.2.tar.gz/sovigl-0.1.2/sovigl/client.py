import requests
import uuid


def map_status(status):
    if status == "allowed":
        return "approved"
    if status == "pending_approval":
        return "pending"
    return status


class Decision:
    def __init__(self, data):
        self.status = map_status(data["status"])
        self.reason = data.get("reason")
        self.cdt = data.get("cdt")

    @property
    def approved(self):
        return self.status == "approved"

    @property
    def pending(self):
        return self.status == "pending"

    @property
    def blocked(self):
        return self.status == "blocked"


def evaluate(action: str, context: dict, org_id: str = "demo_fintech"):
    amount = context["amount"]
    payload = {
        "org_id": org_id,
        "type": action.split(".")[0],
        "amount": amount,
        "role": "employee",
        "user_id": "sdk_user",
        "agent_id": "sdk_client",
        "agent_type": "ai",
        "decision_id": str(uuid.uuid4()),
    }
    if amount > 10000:
        payload["description"] = "SDK test transaction"

    response = requests.post(
        "https://web-production-e334b.up.railway.app/evaluate",
        json=payload,
    )
    data = response.json()
    return Decision(data)
