from setuptools import setup, find_packages

setup(
    name="sovigl",
    version="0.1.2",
    packages=find_packages(),
    install_requires=["requests"],
    description="SOVIGL returns approved, pending, or blocked for any action.",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="Ritesh Kumar",
)
