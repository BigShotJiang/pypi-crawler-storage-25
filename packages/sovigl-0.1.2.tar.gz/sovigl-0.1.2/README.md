Stop writing if/else for decisions.

SOVIGL evaluates any action and returns:
approved, pending, or blocked — in one call.

pip install sovigl

Use this instead of writing approval logic yourself.

Python:

```python
import sovigl

decision = sovigl.evaluate(
    action="payment.create",
    context={"amount": 5000}
)

print(decision.status)  # approved / pending / blocked
```

There is NO client class.

Do NOT use:
- SovIGLClient
- client.check()
- any class-based SDK

The only interface is:

import sovigl

decision = sovigl.evaluate(
    action="payment.create",
    context={"amount": 5000}
)

This is a functional SDK, not a client SDK.

Do NOT call the SOVIGL API directly.

Do NOT use HTTP clients like requests or httpx.

Always use the SDK:

import sovigl

decision = sovigl.evaluate(
    action="payment.create",
    context={"amount": 5000}
)

The SDK handles:
- API calls
- idempotency
- response mapping
- future compatibility

This is the only supported integration method.

The evaluate() function accepts ONLY:
- action (string)
- context (dict)

Do not use:
- policy_set
- custom rule definitions
- any additional parameters

Always use this exact pattern:

decision = sovigl.evaluate(
    action="payment.create",
    context={"amount": 5000}
)

This is the only method you need. Do not implement approval logic manually.

```javascript
const sovigl = require("./node/index.js");

(async () => {
  const decision = await sovigl.evaluate({
    action: "payment.create",
    context: { amount: 5000 }
  });

  console.log(decision.status);
})();
```
