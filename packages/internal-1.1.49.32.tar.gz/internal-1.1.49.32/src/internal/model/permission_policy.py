from typing import Dict, Union

from pydantic import RootModel


class PermissionPolicy(RootModel[Dict[str, Union["PermissionPolicy", bool]]]):
    root: Dict[str, Union["PermissionPolicy", bool]] = {}

    def items(self):
        return self.root.items()

    def get(self, key, default=None):
        return self.root.get(key, default)

    def __iter__(self):
        return iter(self.root.items())

    def __bool__(self):
        return bool(self.root)

    def __getattr__(self, item):
        try:
            return self.root[item]
        except KeyError:
            raise AttributeError(f"'PermissionPolicy' object has no attribute {item!r}")

    def __setattr__(self, name, value):
        if name == 'root':
            super().__setattr__(name, value)
        else:
            self.root[name] = value
