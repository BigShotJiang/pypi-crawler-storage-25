AWS_CONF_KEY = ["AWS_REGION"]

AWS_CW_ALERT_KEY = "[CloudWatchAlert]"
