import re

from .exception.app_exception import PlateNoFormatException, VinLengthOrFormatException, PhoneFormatException, \
    DateFormatException, EMailFormatException
from .model.permission_policy import PermissionPolicy
from .utils import sanitize_plate_no


def verify_and_sanitize_plate_no(value: str, is_require: bool = False):
    if is_require and not value:
        raise PlateNoFormatException()

    if value:
        # 移除空格和常見分隔符號進行檢查
        cleaned = sanitize_plate_no(value)

        if not re.match(r'^[外使領試臨軍A-Za-z0-9]{5,7}\Z', cleaned):
            raise PlateNoFormatException()

    return sanitize_plate_no(value)


def verify_vin(value: str, is_require: bool = False):
    if is_require and not value:
        raise VinLengthOrFormatException()

    if value:
        if not re.match(r'^(?:[A-Za-z0-9]{7}|[A-Za-z0-9]{10}|[A-Za-z0-9]{17})\Z', value):
            raise VinLengthOrFormatException()


def verify_phone(value: str, is_require: bool = False):
    if is_require and not value:
        raise PhoneFormatException()

    if value:
        if not re.match(r'^09\d{8}\Z', value):
            raise PhoneFormatException()


def verify_date(value: str, is_require: bool = False):
    if is_require and not value:
        raise DateFormatException()

    if value:
        if not re.match(r'^\d{4}-\d{2}-\d{2}$', value):
            raise DateFormatException()


def verify_mail(value: str, is_require: bool = False):
    if is_require and not value:
        raise EMailFormatException()

    if value:
        if not re.match(r'^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$', value):
            raise EMailFormatException()


def validate_permission_policy(permission_policy: PermissionPolicy) -> PermissionPolicy:
    def check_node(node, path=""):
        for key, value in node.items():
            current_path = f"{path}.{key}" if path else key
            if isinstance(value, PermissionPolicy):
                check_node(value, current_path)
            elif value is not False:
                raise ValueError(f"'{current_path}' 的值只能是 false，但得到 {repr(value)}")

    check_node(permission_policy)
    return permission_policy


def validate_exclude_permission_policy(permission_policy: PermissionPolicy) -> PermissionPolicy:
    def check_node(node, path=""):
        for key, value in node.items():
            current_path = f"{path}.{key}" if path else key
            if isinstance(value, PermissionPolicy):
                check_node(value, current_path)
            elif not isinstance(value, bool):
                raise ValueError(f"'{current_path}' 的值必須是 bool，但得到 {repr(value)}")

    check_node(permission_policy)
    return permission_policy
