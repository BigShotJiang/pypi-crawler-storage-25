"""Tests for idaustria.session — the pending-identification map."""

from __future__ import annotations

from idaustria.session import (
    MAX_PENDING_ITEMS,
    PENDING_MAP_KEY,
    clear_pending_identification,
    get_pending_identification,
    set_pending_identification,
)


def test_set_returns_id_and_stores_payload(request_with_session):
    pid = set_pending_identification(request_with_session, {"sub": "abc"})
    assert pid
    assert request_with_session.session[PENDING_MAP_KEY][pid] == {"sub": "abc"}


def test_get_by_id(request_with_session):
    pid = set_pending_identification(request_with_session, {"sub": "abc"})
    assert get_pending_identification(request_with_session, pending_id=pid) == {
        "sub": "abc"
    }


def test_get_without_id_returns_only_entry(request_with_session):
    set_pending_identification(request_with_session, {"sub": "only"})
    assert get_pending_identification(request_with_session) == {"sub": "only"}


def test_get_without_id_returns_none_when_multiple(request_with_session):
    set_pending_identification(request_with_session, {"sub": "a"})
    set_pending_identification(request_with_session, {"sub": "b"})
    assert get_pending_identification(request_with_session) is None


def test_max_items_enforced_fifo(request_with_session):
    ids = [
        set_pending_identification(request_with_session, {"n": i})
        for i in range(MAX_PENDING_ITEMS + 2)
    ]
    stored = request_with_session.session[PENDING_MAP_KEY]
    assert len(stored) == MAX_PENDING_ITEMS
    # first two inserted should have been evicted
    assert ids[0] not in stored
    assert ids[1] not in stored
    # most recent should be present
    assert ids[-1] in stored


def test_clear_by_id(request_with_session):
    pid = set_pending_identification(request_with_session, {"sub": "a"})
    clear_pending_identification(request_with_session, pending_id=pid)
    assert get_pending_identification(request_with_session, pending_id=pid) is None


def test_clear_all(request_with_session):
    set_pending_identification(request_with_session, {"sub": "a"})
    set_pending_identification(request_with_session, {"sub": "b"})
    clear_pending_identification(request_with_session)
    assert PENDING_MAP_KEY not in request_with_session.session
