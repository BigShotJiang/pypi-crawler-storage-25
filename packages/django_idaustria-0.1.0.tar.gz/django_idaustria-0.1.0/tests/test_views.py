"""Integration tests for idaustria.views.start and .callback."""

from __future__ import annotations

from urllib.parse import parse_qs, urlparse

import pytest
import responses
from django.test import Client
from django.urls import reverse

from idaustria.exceptions import AuthorizationError, StateMismatchError
from idaustria.identity import IDAustriaIdentity
from idaustria.signals import identification_completed

pytestmark = pytest.mark.django_db


@pytest.fixture
def client():
    return Client()


class TestStartView:
    def test_redirects_to_idp(self, client):
        resp = client.get(reverse("idaustria:start"))
        assert resp.status_code == 302
        parsed = urlparse(resp["Location"])
        assert parsed.netloc == "idp.ref.id-austria.gv.at"
        assert "state" in parse_qs(parsed.query)

    def test_stores_state_in_session(self, client):
        client.get(reverse("idaustria:start"))
        assert "idaustria_state" in client.session
        assert client.session["idaustria_state"]["state"]


class TestCallbackView:
    def test_missing_code_returns_400(self, client):
        resp = client.get(reverse("idaustria:callback"))
        assert resp.status_code == 400
        assert b"code" in resp.content.lower()

    def test_state_mismatch_returns_400(self, client):
        # Prime session with expected state
        session = client.session
        session["idaustria_state"] = {"state": "EXPECTED", "code_verifier": None}
        session.save()

        resp = client.get(
            reverse("idaustria:callback"), {"code": "X", "state": "WRONG"}
        )
        assert resp.status_code == 400
        assert b"state" in resp.content.lower()

    @responses.activate
    def test_happy_path_stores_pending_and_emits_signal(
        self, client, jwks, sign_id_token
    ):
        # Prime session by going through /start
        client.get(reverse("idaustria:start"))
        state = client.session["idaustria_state"]["state"]

        id_token = sign_id_token({"sub": "test-user", "given_name": "Alice"})

        responses.add(
            responses.POST,
            "https://idp.ref.id-austria.gv.at/auth/idp/profile/oidc/token",
            json={
                "id_token": id_token,
                "access_token": "AT",
                "token_type": "Bearer",
                "expires_in": 3600,
                "scope": "openid profile",
            },
            status=200,
        )
        responses.add(
            responses.GET,
            "https://idp.ref.id-austria.gv.at/auth/idp/profile/oidc/keyset",
            json=jwks,
            status=200,
        )

        signal_events: list[dict] = []

        def _listen(sender, **kwargs):
            signal_events.append(kwargs)

        identification_completed.connect(_listen)
        try:
            resp = client.get(
                reverse("idaustria:callback"),
                {"code": "AUTH_CODE", "state": state},
            )
        finally:
            identification_completed.disconnect(_listen)

        assert resp.status_code == 200
        data = resp.json()
        assert data["ok"] is True
        assert data["claims"]["sub"] == "test-user"
        assert "pending_id" in data

        # pending payload is stored in session
        pmap = client.session["idaustria_pending_map"]
        assert data["pending_id"] in pmap

        # signal fired with success=True and an IDAustriaIdentity instance
        assert len(signal_events) == 1
        assert signal_events[0]["success"] is True
        identity = signal_events[0]["identity"]
        assert isinstance(identity, IDAustriaIdentity)
        assert identity.subject == "test-user"
        assert identity.given_name == "Alice"

    @responses.activate
    def test_token_exchange_failure_emits_failure_signal(self, client):
        client.get(reverse("idaustria:start"))
        state = client.session["idaustria_state"]["state"]

        responses.add(
            responses.POST,
            "https://idp.ref.id-austria.gv.at/auth/idp/profile/oidc/token",
            json={"error": "invalid_grant"},
            status=400,
        )

        events: list[dict] = []

        def listener(sender, **kw):
            events.append(kw)

        identification_completed.connect(listener)
        try:
            resp = client.get(
                reverse("idaustria:callback"),
                {"code": "BAD", "state": state},
            )
        finally:
            identification_completed.disconnect(listener)
        assert resp.status_code == 400
        assert events and events[-1]["success"] is False


class TestCallbackIdpErrors:
    """RFC 6749 §4.1.2.1: IdP may redirect back with ?error=... instead of ?code=..."""

    def test_idp_error_with_matching_state_emits_authorization_error(self, client):
        client.get(reverse("idaustria:start"))
        state = client.session["idaustria_state"]["state"]

        events: list[dict] = []

        def listener(sender, **kw):
            events.append(kw)

        identification_completed.connect(listener)
        try:
            resp = client.get(
                reverse("idaustria:callback"),
                {
                    "error": "access_denied",
                    "error_description": "User cancelled",
                    "state": state,
                },
            )
        finally:
            identification_completed.disconnect(listener)

        assert resp.status_code == 400
        data = resp.json()
        assert data["ok"] is False
        assert data["error"] == "access_denied"
        assert data["error_description"] == "User cancelled"

        assert events and events[-1]["success"] is False
        assert isinstance(events[-1]["error"], AuthorizationError)
        assert events[-1]["error"].code == "access_denied"

        # flow state is cleared after terminal outcome
        assert "idaustria_state" not in client.session

    def test_idp_error_with_mismatched_state_raises_state_mismatch(self, client):
        session = client.session
        session["idaustria_state"] = {"state": "EXPECTED", "code_verifier": None}
        session.save()

        events: list[dict] = []

        def listener(sender, **kw):
            events.append(kw)

        identification_completed.connect(listener)
        try:
            resp = client.get(
                reverse("idaustria:callback"),
                {"error": "access_denied", "state": "WRONG"},
            )
        finally:
            identification_completed.disconnect(listener)

        assert resp.status_code == 400
        data = resp.json()
        assert data["error"] == "StateMismatchError"
        assert events and isinstance(events[-1]["error"], StateMismatchError)

    def test_idp_error_passes_through_error_uri(self, client):
        client.get(reverse("idaustria:start"))
        state = client.session["idaustria_state"]["state"]

        resp = client.get(
            reverse("idaustria:callback"),
            {
                "error": "server_error",
                "error_description": "IdP is on fire",
                "error_uri": "https://idp.example/errors/42",
                "state": state,
            },
        )

        data = resp.json()
        assert data["error"] == "server_error"
        assert data["error_uri"] == "https://idp.example/errors/42"
