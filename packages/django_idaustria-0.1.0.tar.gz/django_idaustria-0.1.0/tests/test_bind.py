"""Tests for idaustria.bind.bind_pending_identification."""

from __future__ import annotations

import pytest
from django.contrib.auth import get_user_model
from django.test import RequestFactory

from idaustria.bind import bind_pending_identification
from idaustria.session import set_pending_identification

from .conftest import FakeSession

pytestmark = pytest.mark.django_db


@pytest.fixture
def user(db):
    User = get_user_model()
    return User.objects.create_user(username="alice", password="irrelevant")


@pytest.fixture
def request_with_pending(user):
    request = RequestFactory().get("/")
    request.session = FakeSession()
    request.user = user
    pid = set_pending_identification(
        request,
        {
            "id_token": "header.payload.sig",
            "access_token": "AT",
            "token_type": "Bearer",
            "scope": "openid profile",
            "expires_in": 3600,
            "sub": "subject-xyz",
            "bpk": "BPK-1",
            "claims": {"sub": "subject-xyz", "given_name": "Alice"},
        },
    )
    return request, pid


def test_binds_pending_to_user(request_with_pending, user):
    request, pid = request_with_pending
    identification = bind_pending_identification(request, user, pending_id=pid)

    assert identification is not None
    assert identification.user == user
    assert identification.sub == "subject-xyz"
    assert identification.bpk == "BPK-1"
    assert identification.claims["given_name"] == "Alice"


def test_clears_pending_after_bind(request_with_pending, user):
    request, pid = request_with_pending
    bind_pending_identification(request, user, pending_id=pid)
    from idaustria.session import get_pending_identification

    assert get_pending_identification(request, pending_id=pid) is None


def test_returns_none_without_pending(user):
    request = RequestFactory().get("/")
    request.session = FakeSession()
    request.user = user
    assert bind_pending_identification(request, user) is None


def test_falls_back_to_request_user_when_authenticated(request_with_pending):
    request, pid = request_with_pending
    # don't pass user explicitly — bind should use request.user
    identification = bind_pending_identification(request, pending_id=pid)
    assert identification is not None
    assert identification.user == request.user


def test_returns_none_if_user_missing_and_request_anonymous():
    from django.contrib.auth.models import AnonymousUser

    request = RequestFactory().get("/")
    request.session = FakeSession()
    request.user = AnonymousUser()
    assert bind_pending_identification(request) is None
