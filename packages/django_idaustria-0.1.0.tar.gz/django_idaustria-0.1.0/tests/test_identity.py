"""Unit tests for idaustria.identity."""

from __future__ import annotations

import base64
import json
from datetime import date

from idaustria.identity import (
    CLAIM_BPK,
    CLAIM_EIDAS_LEVEL,
    CLAIM_GENDER,
    CLAIM_IDENTITY_STATUS,
    CLAIM_MAIN_ADDRESS,
    CLAIM_NATIONALITY,
    CLAIM_PORTRAIT,
    CLAIM_SECTOR,
    IDAustriaIdentity,
    MainAddress,
)


def _encode_address(data: dict) -> str:
    return base64.b64encode(json.dumps(data).encode("utf-8")).decode("ascii")


SAMPLE_CLAIMS = {
    "iss": "https://idp.ref.id-austria.gv.at",
    "sub": "TRANSIENT-ABC-123",
    "given_name": "XXXHildegard",
    "family_name": "XXXÖhlinger",
    "birthdate": "1983-06-04",
    CLAIM_BPK: "ZP-MH:KQMY8Sl9WsmBxrYrYOiFS2VkLyo=",
    CLAIM_SECTOR: "urn:publicid:gv.at:cdid+BW",
    CLAIM_EIDAS_LEVEL: "http://eidas.europa.eu/LoA/high",
    CLAIM_IDENTITY_STATUS: "http://eid.gv.at/eID/status/testidentity",
    CLAIM_GENDER: "female",
    CLAIM_NATIONALITY: "AT",
    "org.iso.18013.5.1:age_over_18": True,
    "org.iso.18013.5.1:age_over_21": True,
    CLAIM_MAIN_ADDRESS: _encode_address(
        {
            "Gemeindekennziffer": "09988",
            "Gemeindebezeichnung": "Testgemeinde",
            "Postleitzahl": "0088",
            "Ortschaft": "Testort A",
            "Strasse": "Testgasse",
            "Hausnummer": "bei 1A-2B",
            "Stiege": "",
            "Tuer": "",
        }
    ),
}


class TestCoreAttributes:
    def test_bpk_is_stable_identifier(self):
        identity = IDAustriaIdentity(claims=SAMPLE_CLAIMS)
        assert identity.bpk == "ZP-MH:KQMY8Sl9WsmBxrYrYOiFS2VkLyo="

    def test_sub_is_surfaced_but_labeled_transient(self):
        identity = IDAustriaIdentity(claims=SAMPLE_CLAIMS)
        assert identity.subject == "TRANSIENT-ABC-123"

    def test_names(self):
        identity = IDAustriaIdentity(claims=SAMPLE_CLAIMS)
        assert identity.given_name == "XXXHildegard"
        assert identity.family_name == "XXXÖhlinger"
        assert identity.full_name == "XXXHildegard XXXÖhlinger"

    def test_full_name_handles_partial(self):
        identity = IDAustriaIdentity(claims={"given_name": "Alice"})
        assert identity.full_name == "Alice"

    def test_full_name_none_if_empty(self):
        assert IDAustriaIdentity(claims={}).full_name is None

    def test_birthdate_parsed_as_date(self):
        identity = IDAustriaIdentity(claims=SAMPLE_CLAIMS)
        assert identity.birthdate == date(1983, 6, 4)

    def test_birthdate_missing_returns_none(self):
        assert IDAustriaIdentity(claims={}).birthdate is None

    def test_birthdate_invalid_returns_none(self):
        assert IDAustriaIdentity(claims={"birthdate": "not-a-date"}).birthdate is None

    def test_sector_and_eidas_level(self):
        identity = IDAustriaIdentity(claims=SAMPLE_CLAIMS)
        assert identity.sector == "urn:publicid:gv.at:cdid+BW"
        assert identity.eidas_level == "http://eidas.europa.eu/LoA/high"

    def test_issuer(self):
        identity = IDAustriaIdentity(claims=SAMPLE_CLAIMS)
        assert identity.issuer == "https://idp.ref.id-austria.gv.at"

    def test_gender_nationality(self):
        identity = IDAustriaIdentity(claims=SAMPLE_CLAIMS)
        assert identity.gender == "female"
        assert identity.nationality == "AT"

    def test_missing_claims_return_none(self):
        identity = IDAustriaIdentity(claims={})
        assert identity.bpk is None
        assert identity.given_name is None
        assert identity.family_name is None
        assert identity.gender is None
        assert identity.nationality is None


class TestTestIdentityFlag:
    def test_detects_ref_test_identity(self):
        identity = IDAustriaIdentity(claims=SAMPLE_CLAIMS)
        assert identity.is_test_identity is True

    def test_prod_identity_flag_is_false(self):
        identity = IDAustriaIdentity(
            claims={CLAIM_IDENTITY_STATUS: "http://eid.gv.at/eID/status/active"}
        )
        assert identity.is_test_identity is False

    def test_missing_status_is_false(self):
        assert IDAustriaIdentity(claims={}).is_test_identity is False


class TestAgeOver:
    def test_returns_configured_attestation(self):
        identity = IDAustriaIdentity(claims=SAMPLE_CLAIMS)
        assert identity.age_over(18) is True
        assert identity.age_over(21) is True

    def test_returns_none_for_unconfigured_threshold(self):
        # ID Austria only delivers thresholds configured in IDA-SPR.
        # Missing != "below threshold".
        identity = IDAustriaIdentity(claims=SAMPLE_CLAIMS)
        assert identity.age_over(16) is None


class TestMainAddress:
    def test_decodes_base64_json(self):
        identity = IDAustriaIdentity(claims=SAMPLE_CLAIMS)
        addr = identity.main_address
        assert isinstance(addr, MainAddress)
        assert addr.gemeindekennziffer == "09988"
        assert addr.gemeindebezeichnung == "Testgemeinde"
        assert addr.strasse == "Testgasse"
        assert addr.hausnummer == "bei 1A-2B"
        assert addr.stiege == ""
        assert addr.tuer == ""

    def test_missing_returns_none(self):
        assert IDAustriaIdentity(claims={}).main_address is None

    def test_invalid_base64_returns_none(self):
        identity = IDAustriaIdentity(claims={CLAIM_MAIN_ADDRESS: "not-base64!!!"})
        assert identity.main_address is None

    def test_invalid_json_returns_none(self):
        garbage = base64.b64encode(b"not json").decode("ascii")
        identity = IDAustriaIdentity(claims={CLAIM_MAIN_ADDRESS: garbage})
        assert identity.main_address is None


class TestPortrait:
    def test_portrait_passthrough(self):
        identity = IDAustriaIdentity(claims={CLAIM_PORTRAIT: "BASE64BLOB"})
        assert identity.portrait == "BASE64BLOB"


class TestDictEscapeHatch:
    def test_get_with_arbitrary_claim(self):
        identity = IDAustriaIdentity(claims={"urn:custom:x": 42})
        assert identity.get("urn:custom:x") == 42
        assert identity.get("missing", "default") == "default"

    def test_contains(self):
        identity = IDAustriaIdentity(claims=SAMPLE_CLAIMS)
        assert "given_name" in identity
        assert "missing" not in identity


class TestImmutability:
    def test_frozen_dataclass(self):
        import dataclasses

        identity = IDAustriaIdentity(claims={})
        with __import__("pytest").raises(dataclasses.FrozenInstanceError):
            identity.claims = {"x": 1}  # type: ignore[misc]
