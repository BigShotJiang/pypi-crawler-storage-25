"""Unit tests for idaustria.oidc."""

from __future__ import annotations

import hashlib
import base64
from urllib.parse import parse_qs, urlparse

import pytest
import responses
from django.test import override_settings

from idaustria import oidc
from idaustria.exceptions import IDTokenValidationError, TokenExchangeError


def _b64url_decode_len(s: str) -> int:
    padding = "=" * (-len(s) % 4)
    return len(base64.urlsafe_b64decode(s + padding))


class TestStateAndPkce:
    def test_generate_state_is_url_safe_and_long_enough(self):
        state = oidc.generate_state()
        assert state and " " not in state
        # 24 random bytes -> 32 chars in base64url (no padding)
        assert _b64url_decode_len(state) == 24

    def test_generate_pkce_pair_challenge_is_sha256_of_verifier(self):
        verifier, challenge = oidc.generate_pkce_pair()
        expected = (
            base64.urlsafe_b64encode(hashlib.sha256(verifier.encode("ascii")).digest())
            .rstrip(b"=")
            .decode("ascii")
        )
        assert challenge == expected

    def test_two_states_differ(self):
        assert oidc.generate_state() != oidc.generate_state()


class TestFlowStateSession:
    def test_store_and_pop_roundtrip(self, request_with_session):
        oidc.store_flow_state(request_with_session, "STATE", "VERIFIER")
        assert oidc.get_flow_state(request_with_session) == {
            "state": "STATE",
            "code_verifier": "VERIFIER",
        }
        popped = oidc.pop_flow_state(request_with_session)
        assert popped["state"] == "STATE"
        assert oidc.get_flow_state(request_with_session) == {}


class TestBuildAuthorizeUrl:
    def test_contains_required_params(self, request_with_session):
        url, state = oidc.build_authorize_url(request_with_session)
        parsed = urlparse(url)
        qs = parse_qs(parsed.query)
        assert parsed.netloc == "idp.ref.id-austria.gv.at"
        assert parsed.path.endswith("/authorize")
        assert qs["response_type"] == ["code"]
        assert qs["client_id"] == ["https://example.test/app"]
        # redirect_uri is taken verbatim from IDAUSTRIA_REDIRECT_URI.
        assert qs["redirect_uri"] == ["https://example.test/idaustria/callback/"]
        assert qs["state"] == [state]
        assert "openid" in qs["scope"][0]

    @override_settings(
        IDAUSTRIA_REDIRECT_URI="https://tunnel.example/idaustria/callback/"
    )
    def test_redirect_uri_uses_setting(self, request_with_session):
        url, _ = oidc.build_authorize_url(request_with_session)
        qs = parse_qs(urlparse(url).query)
        assert qs["redirect_uri"] == ["https://tunnel.example/idaustria/callback/"]

    @override_settings(IDAUSTRIA_REDIRECT_URI=None)
    def test_missing_redirect_uri_raises(self, request_with_session):
        with pytest.raises(RuntimeError, match="IDAUSTRIA_REDIRECT_URI"):
            oidc.build_authorize_url(request_with_session)

    def test_stores_state_in_session(self, request_with_session):
        _, state = oidc.build_authorize_url(request_with_session)
        assert oidc.get_flow_state(request_with_session)["state"] == state

    @override_settings(IDAUSTRIA_USE_PKCE=True)
    def test_pkce_adds_challenge(self, request_with_session):
        url, _ = oidc.build_authorize_url(request_with_session)
        qs = parse_qs(urlparse(url).query)
        assert qs["code_challenge_method"] == ["S256"]
        assert qs["code_challenge"][0]
        # verifier is persisted for the callback to use
        assert oidc.get_flow_state(request_with_session)["code_verifier"]

    @override_settings(IDAUSTRIA_ENV="prod")
    def test_prod_environment_uses_prod_endpoint(self, request_with_session):
        url, _ = oidc.build_authorize_url(request_with_session)
        assert "idp.id-austria.gv.at" in url
        assert "ref" not in urlparse(url).netloc


class TestExchangeCodeForTokens:
    @responses.activate
    def test_happy_path_returns_token_payload(self, request_with_session):
        token_url = "https://idp.ref.id-austria.gv.at/auth/idp/profile/oidc/token"
        responses.add(
            responses.POST,
            token_url,
            json={"id_token": "ID", "access_token": "AT", "token_type": "Bearer"},
            status=200,
        )
        out = oidc.exchange_code_for_tokens(request_with_session, "CODE")
        assert out["id_token"] == "ID"

        # ID Austria: client_secret_post — credentials in the form body.
        form = responses.calls[0].request.body
        assert "code=CODE" in form
        assert "grant_type=authorization_code" in form
        assert "client_secret=test-client-secret" in form
        assert "client_id=" in form

    @responses.activate
    def test_raises_token_exchange_error_on_http_failure(self, request_with_session):
        responses.add(
            responses.POST,
            "https://idp.ref.id-austria.gv.at/auth/idp/profile/oidc/token",
            json={"error": "invalid_grant"},
            status=400,
        )
        with pytest.raises(TokenExchangeError):
            oidc.exchange_code_for_tokens(request_with_session, "CODE")

    @responses.activate
    @override_settings(IDAUSTRIA_USE_PKCE=True)
    def test_pkce_verifier_sent_when_enabled(self, request_with_session):
        responses.add(
            responses.POST,
            "https://idp.ref.id-austria.gv.at/auth/idp/profile/oidc/token",
            json={"id_token": "ID"},
            status=200,
        )
        oidc.exchange_code_for_tokens(
            request_with_session, "CODE", code_verifier="V123"
        )
        assert "code_verifier=V123" in responses.calls[0].request.body


class TestValidateIdToken:
    @responses.activate
    def test_valid_token_returns_claims(self, jwks, sign_id_token):
        responses.add(
            responses.GET,
            "https://idp.ref.id-austria.gv.at/auth/idp/profile/oidc/keyset",
            json=jwks,
            status=200,
        )
        token = sign_id_token({"sub": "user-1"})
        claims = oidc.validate_id_token(token)
        assert claims["sub"] == "user-1"

    @responses.activate
    def test_wrong_audience_rejected(self, jwks, sign_id_token):
        responses.add(
            responses.GET,
            "https://idp.ref.id-austria.gv.at/auth/idp/profile/oidc/keyset",
            json=jwks,
            status=200,
        )
        token = sign_id_token({"aud": "https://wrong.example/"})
        with pytest.raises(IDTokenValidationError):
            oidc.validate_id_token(token)

    @responses.activate
    def test_expired_token_rejected(self, jwks, sign_id_token):
        responses.add(
            responses.GET,
            "https://idp.ref.id-austria.gv.at/auth/idp/profile/oidc/keyset",
            json=jwks,
            status=200,
        )
        token = sign_id_token({"exp": 1})
        with pytest.raises(IDTokenValidationError):
            oidc.validate_id_token(token)

    @responses.activate
    def test_unknown_kid_rejected(self, jwks, sign_id_token):
        responses.add(
            responses.GET,
            "https://idp.ref.id-austria.gv.at/auth/idp/profile/oidc/keyset",
            json=jwks,
            status=200,
        )
        token = sign_id_token({}, kid="not-in-jwks")
        with pytest.raises(IDTokenValidationError):
            oidc.validate_id_token(token)
