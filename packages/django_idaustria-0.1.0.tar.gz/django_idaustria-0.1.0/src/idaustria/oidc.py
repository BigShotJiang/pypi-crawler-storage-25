from __future__ import annotations

import base64
import hashlib
import os
from typing import Any, Mapping, Optional

import jwt
import requests
from django.conf import settings
from django.http import HttpRequest
from django.utils.http import urlencode

from . import conf
from .conf import get_client_id, get_redirect_uri
from .exceptions import IDTokenValidationError, TokenExchangeError
import logging

logger = logging.getLogger(__name__)

SESSION_KEY = "idaustria_state"


def _b64url(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def generate_state() -> str:
    return _b64url(os.urandom(24))


def generate_pkce_pair() -> tuple[str, str]:
    verifier = _b64url(os.urandom(32))
    challenge = _b64url(hashlib.sha256(verifier.encode("ascii")).digest())
    return verifier, challenge


def store_flow_state(
    request: HttpRequest, state: str, code_verifier: Optional[str] = None
) -> None:
    request.session[SESSION_KEY] = {
        "state": state,
        "code_verifier": code_verifier,
    }
    request.session.modified = True


def pop_flow_state(request: HttpRequest) -> Mapping[str, Optional[str]]:
    data = request.session.pop(SESSION_KEY, {})
    request.session.modified = True
    return data


def get_flow_state(request: HttpRequest) -> Mapping[str, Optional[str]]:
    data = request.session.get(SESSION_KEY, {})
    return data


def build_redirect_uri() -> str:
    """Returns the absolute redirect URI for the ID Austria callback.

    Single source of truth is the ``IDAUSTRIA_REDIRECT_URI`` setting; it must
    match the URL registered at the IDA-SPR verbatim. The ``client_id`` is an
    opaque URL *identifier* at ID Austria and must not be used as a base URL.
    """
    return get_redirect_uri()


def build_authorize_url(request: HttpRequest) -> tuple[str, str]:
    """Returns the authorization url and a state."""
    provider = conf.get_provider()
    client_id = conf.get_client_id()
    scopes = conf.get_scopes()
    redirect_uri = build_redirect_uri()

    state = generate_state()
    params: dict[str, str] = {
        "response_type": "code",
        "client_id": client_id,
        "redirect_uri": redirect_uri,
        "scope": " ".join(scopes),
        "state": state,
    }

    code_verifier = None
    if conf.use_pkce():
        code_verifier, code_challenge = generate_pkce_pair()
        params["code_challenge"] = code_challenge
        params["code_challenge_method"] = "S256"

    store_flow_state(request, state, code_verifier)
    url = f"{provider.authorize_endpoint}?{urlencode(params)}"
    logger.warning(url)
    return url, state


def _get_jwks() -> dict[str, Any]:
    provider = conf.get_provider()
    timeout = conf.get_timeout()
    resp = requests.get(provider.jwks_uri, timeout=timeout)
    resp.raise_for_status()
    return resp.json()


def exchange_code_for_tokens(
    request: HttpRequest, code: str, code_verifier: Optional[str] = None
) -> dict[str, Any]:
    provider = conf.get_provider()
    timeout = conf.get_timeout()

    # ID Austria specifies `client_secret_post`: client_id + client_secret go
    # into the form body alongside the other parameters. Using Basic auth
    # yields an `unauthorized_client` error at /token.
    # See https://www.id-austria.gv.at/de/developer/anbinden/anbindung-mit-openid-connect
    data = {
        "code": code,
        "grant_type": "authorization_code",
        "client_id": conf.get_client_id(),
        "client_secret": conf.get_client_secret(),
        "redirect_uri": build_redirect_uri(),
    }

    if conf.use_pkce() and code_verifier:
        data["code_verifier"] = code_verifier  # if PKCE used

    try:
        resp = requests.post(provider.token_endpoint, data=data, timeout=timeout)
    except requests.RequestException as exc:
        raise TokenExchangeError(str(exc)) from exc

    if not resp.ok:
        # Surface the IdP's error payload — at OIDC token endpoints this is
        # typically {"error": "...", "error_description": "..."} and the only
        # signal that distinguishes invalid_grant from invalid_client etc.
        body = (resp.text or "").strip()
        raise TokenExchangeError(
            f"token endpoint returned HTTP {resp.status_code}: {body[:500]}"
        )

    return resp.json()


def _pick_key_for_kid(
    jwks: Mapping[str, Any], kid: Optional[str]
) -> Optional[Mapping[str, Any]]:
    for key in jwks.get("keys", []):
        if kid is None or key.get("kid") == kid:
            return key
    return None


def validate_id_token(id_token: str) -> Mapping[str, Any]:
    # Validate signature using JWKS and verify standard claims
    unverified_header = jwt.get_unverified_header(id_token)
    kid = unverified_header.get("kid")
    jwks = _get_jwks()
    jwk = _pick_key_for_kid(jwks, kid)
    if jwk is None:
        raise IDTokenValidationError("No suitable JWK found for ID token")

    issuer = conf.get_provider().base_url
    audience = conf.get_client_id()

    try:
        # PyJWT's decode() needs a key object (or PEM), not a raw JWK dict.
        signing_key = jwt.PyJWK(jwk).key
        claims = jwt.decode(
            id_token,
            key=signing_key,
            algorithms=[unverified_header.get("alg", "RS256")],
            audience=audience,
            issuer=issuer,
            options={
                "verify_aud": True,
                "verify_signature": True,
                "verify_exp": True,
                "verify_iss": True,
            },
        )
    except (jwt.PyJWTError, jwt.InvalidKeyError, ValueError) as exc:
        raise IDTokenValidationError(str(exc)) from exc

    return claims
