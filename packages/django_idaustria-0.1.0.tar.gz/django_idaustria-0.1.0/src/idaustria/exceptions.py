class IDAustriaError(Exception):
    """Base exception for the ID Austria app."""


class StateMismatchError(IDAustriaError):
    pass


class TokenExchangeError(IDAustriaError):
    pass


class IDTokenValidationError(IDAustriaError):
    pass


class AuthorizationError(IDAustriaError):
    """IdP returned an error at the authorize step (RFC 6749 §4.1.2.1).

    Attributes:
        code:        standard error identifier (e.g. ``access_denied``,
                     ``invalid_request``, ``unauthorized_client``,
                     ``unsupported_response_type``, ``invalid_scope``,
                     ``server_error``, ``temporarily_unavailable``)
        description: optional human-readable message from the IdP
        uri:         optional URL with further information
    """

    def __init__(
        self, code: str, description: str | None = None, uri: str | None = None
    ):
        self.code = code
        self.description = description
        self.uri = uri
        msg = f"{code}: {description}" if description else code
        super().__init__(msg)
