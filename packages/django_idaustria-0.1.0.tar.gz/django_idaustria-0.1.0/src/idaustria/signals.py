from django.dispatch import Signal

# Sent when an ID Austria identification flow completed (successfully or with error).
# Args:
#   request:  the incoming HttpRequest
#   success:  bool — whether the flow finished successfully
#   identity: IDAustriaIdentity | None — typed view over the ID token claims
#             (None on failure)
#   tokens:   dict | None — raw token endpoint response (None on failure)
#   error:    Exception | None — the IDAustriaError subclass on failure
identification_completed = Signal()
