from __future__ import annotations

from typing import Optional, TYPE_CHECKING

from django.contrib.auth import get_user_model
from django.http import HttpRequest

from .session import get_pending_identification, clear_pending_identification

if TYPE_CHECKING:  # import for type hints only; avoids models import at app load time
    from .models import Identification


def bind_pending_identification(
    request: HttpRequest,
    user: Optional[get_user_model()] = None,
    *,
    pending_id: Optional[str] = None,
) -> Optional["Identification"]:
    """Create an Identification for the given user from pending session data.

    Returns the created Identification or None if no pending data is available.
    Clears the pending data from session upon successful bind.
    """
    if user is None:
        # try to take request.user if authenticated
        if getattr(request, "user", None) is None or not request.user.is_authenticated:
            return None
        user = request.user

    pending = get_pending_identification(request, pending_id=pending_id)
    if not pending:
        return None

    # Local import to ensure app registry is ready before accessing models
    from .models import Identification

    identification = Identification.objects.create(
        user=user,
        id_token=pending.get("id_token", ""),
        access_token=pending.get("access_token"),
        token_type=pending.get("token_type"),
        scope=pending.get("scope"),
        expires_in=pending.get("expires_in"),
        sub=pending.get("sub", ""),
        bpk=pending.get("bpk"),
        claims=pending.get("claims", {}),
    )

    # Clear all pending if only one existed, or just the specified one
    clear_pending_identification(request, pending_id=pending_id)
    return identification
