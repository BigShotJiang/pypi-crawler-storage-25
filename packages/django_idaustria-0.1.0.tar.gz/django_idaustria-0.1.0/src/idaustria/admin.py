from django.contrib import admin

from .models import Identification


@admin.register(Identification)
class IdentificationAdmin(admin.ModelAdmin):
    list_display = (
        "id",
        "user",
        "sub",
        "bpk",
        "token_type",
        "scope",
        "created_at",
    )
    search_fields = ("sub", "bpk", "user__username", "user__email")
    list_filter = ("token_type", "created_at")
