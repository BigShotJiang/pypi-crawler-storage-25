from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence

from django.conf import settings

REF_BASE = "https://idp.ref.id-austria.gv.at"
PROD_BASE = "https://idp.id-austria.gv.at"


@dataclass(frozen=True)
class ProviderConfig:
    base_url: str

    @property
    def authorize_endpoint(self) -> str:
        return f"{self.base_url}/auth/idp/profile/oidc/authorize"

    @property
    def token_endpoint(self) -> str:
        return f"{self.base_url}/auth/idp/profile/oidc/token"

    @property
    def jwks_uri(self) -> str:
        return f"{self.base_url}/auth/idp/profile/oidc/keyset"


def _get_provider() -> ProviderConfig:
    env = getattr(settings, "IDAUSTRIA_ENV", "ref").lower()
    if env == "prod" or env == "production":
        return ProviderConfig(PROD_BASE)
    # default to reference environment
    return ProviderConfig(REF_BASE)


def get_provider() -> ProviderConfig:
    return _get_provider()


def get_client_id() -> str:
    client_id = getattr(settings, "IDAUSTRIA_CLIENT_ID", None)
    if not client_id:
        raise RuntimeError(
            "IDAUSTRIA_CLIENT_ID is not configured in Django settings. "
            "It must be a URL in the application's context."
        )
    return client_id


def get_client_secret() -> str:
    secret = getattr(settings, "IDAUSTRIA_CLIENT_SECRET", None)
    if not secret:
        raise RuntimeError(
            "IDAUSTRIA_CLIENT_SECRET is not configured in Django settings."
        )
    return secret


def get_scopes() -> Sequence[str]:
    # As per docs, scopes do not influence claims; recommend openid and profile
    return getattr(settings, "IDAUSTRIA_SCOPES", ("openid", "profile"))


def get_timeout() -> float:
    return float(getattr(settings, "IDAUSTRIA_TIMEOUT", 10.0))


def get_redirect_uri() -> str:
    """Absolute redirect URI used for the OIDC callback.

    Must be an exact match for the URL registered at the IDA-SPR — ID Austria
    compares scheme, host, path and trailing slash verbatim (no wildcards).
    """
    uri = getattr(settings, "IDAUSTRIA_REDIRECT_URI", None)
    if not uri:
        raise RuntimeError(
            "IDAUSTRIA_REDIRECT_URI is not configured in Django settings. "
            "It must be the full absolute callback URL (e.g. "
            "'https://your.site/idaustria/callback/') registered at the IDA-SPR."
        )
    return uri


def use_pkce() -> bool:
    return bool(getattr(settings, "IDAUSTRIA_USE_PKCE", False))
