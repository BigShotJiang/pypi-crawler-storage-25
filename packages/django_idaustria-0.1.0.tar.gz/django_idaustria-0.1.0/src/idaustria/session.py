from __future__ import annotations

import os
import base64
from typing import Any, Optional

from django.http import HttpRequest

PENDING_MAP_KEY = "idaustria_pending_map"
MAX_PENDING_ITEMS = 5


def _b64url_random(n: int = 16) -> str:
    return base64.urlsafe_b64encode(os.urandom(n)).rstrip(b"=").decode("ascii")


def _get_map(request: HttpRequest) -> dict[str, Any]:
    return dict(request.session.get(PENDING_MAP_KEY, {}))


def _set_map(request: HttpRequest, data: dict[str, Any]) -> None:
    request.session[PENDING_MAP_KEY] = data
    request.session.modified = True


def set_pending_identification(request: HttpRequest, payload: dict[str, Any]) -> str:
    """Store a pending identification payload in the session and return its id."""
    pending_id = _b64url_random(16)
    m = _get_map(request)
    # prune if exceeds max items
    if len(m) >= MAX_PENDING_ITEMS:
        # remove arbitrary oldest by insertion order (py3.7+ preserves dict order)
        first_key = next(iter(m.keys()))
        m.pop(first_key, None)
    m[pending_id] = payload
    _set_map(request, m)
    return pending_id


def get_pending_identification(
    request: HttpRequest, pending_id: Optional[str] = None
) -> Optional[dict[str, Any]]:
    m = _get_map(request)
    if pending_id:
        return m.get(pending_id)
    # if only one present, return it
    if len(m) == 1:
        return next(iter(m.values()))
    return None


def clear_pending_identification(
    request: HttpRequest, pending_id: Optional[str] = None
) -> None:
    if pending_id is None:
        # clear all
        request.session.pop(PENDING_MAP_KEY, None)
        request.session.modified = True
        return
    m = _get_map(request)
    if pending_id in m:
        m.pop(pending_id, None)
        _set_map(request, m)
    else:
        # nothing to clear
        return
