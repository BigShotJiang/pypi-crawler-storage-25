"""Typed, ergonomic view over ID Austria ID token claims.

ID Austria delivers *all* attributes inside the ``id_token`` (there is no
``/userinfo`` endpoint). Which attributes are delivered is configured at
registration time in IDA-SPR, not via OIDC scopes. This module exposes the
common claims under plain attribute names, decodes the nested ``mainAddress``
from its Base64-encoded JSON representation, and keeps the full raw claims
dict accessible for anything not explicitly surfaced.

See
https://www.id-austria.gv.at/de/developer/registrieren/personenmerkmale
for the full attribute catalog.
"""

from __future__ import annotations

import base64
import binascii
import json
from dataclasses import dataclass
from datetime import date
from typing import Any, Mapping, Optional

# --- Claim name constants ----------------------------------------------------
# Standard OIDC / profile claims (given_name, family_name, birthdate, sub, ...)
# are referenced by their plain names; only the non-obvious URN-namespaced
# claims get constants here so callers don't have to hand-type URNs.

CLAIM_BPK = "urn:pvpgvat:oidc.bpk"
CLAIM_EIDAS_LEVEL = "urn:pvpgvat:oidc.eid_citizen_qaa_eidas_level"
CLAIM_IDENTITY_STATUS = "urn:pvpgvat:oidc.eid_identity_status_level"
CLAIM_PVP_VERSION = "urn:pvpgvat:oidc.pvp_version"
CLAIM_SECTOR = "urn:pvpgvat:oidc.eid_sector_for_identifier"
CLAIM_CCS_URL = "urn:pvpgvat:oidc.eid_ccs_url"
CLAIM_ONLINE_IDENTITY_LINK = "urn:pvpgvat:oidc.eid_online_identity_link"

CLAIM_MAIN_ADDRESS = "urn:eidgvat:attributes.mainAddress"
CLAIM_GENDER = "urn:eidgvat:attributes.gender"
CLAIM_NATIONALITY = "urn:eidgvat:attributes.nationality"
CLAIM_MARITAL_STATUS = "urn:eidgvat:attributes.maritalStatus"
CLAIM_VEHICLE_REGISTRATIONS = "urn:eidgvat:attributes.vehicleRegistrations"
CLAIM_IDENTIFICATION_DOCUMENT_DATA = "urn:eidgvat:attributes.identificationDocumentData"

CLAIM_PORTRAIT = "org.iso.18013.5.1:portrait"
_AGE_OVER_PREFIX = "org.iso.18013.5.1:age_over_"


# --- mainAddress -------------------------------------------------------------
@dataclass(frozen=True)
class MainAddress:
    """Decoded representation of ``urn:eidgvat:attributes.mainAddress``.

    The raw claim is a Base64-encoded JSON object (not a native JSON claim).
    All fields are required by ID Austria's schema but may be empty strings.
    """

    gemeindekennziffer: str = ""
    gemeindebezeichnung: str = ""
    postleitzahl: str = ""
    ortschaft: str = ""
    strasse: str = ""
    hausnummer: str = ""
    stiege: str = ""
    tuer: str = ""

    @classmethod
    def from_encoded(cls, encoded: str) -> "MainAddress":
        raw = base64.b64decode(encoded, validate=True)
        data = json.loads(raw.decode("utf-8"))
        return cls(
            gemeindekennziffer=data.get("Gemeindekennziffer", ""),
            gemeindebezeichnung=data.get("Gemeindebezeichnung", ""),
            postleitzahl=data.get("Postleitzahl", ""),
            ortschaft=data.get("Ortschaft", ""),
            strasse=data.get("Strasse", ""),
            hausnummer=data.get("Hausnummer", ""),
            stiege=data.get("Stiege", ""),
            tuer=data.get("Tuer", ""),
        )


# --- IDAustriaIdentity -------------------------------------------------------
@dataclass(frozen=True)
class IDAustriaIdentity:
    """Read-only, typed view over an ID Austria identification result.

    Not a Django model — persistence is the host project's responsibility
    (see :class:`idaustria.models.Identification` for the bound record).
    """

    claims: Mapping[str, Any]

    # --- stable person identifier -------------------------------------------
    @property
    def bpk(self) -> Optional[str]:
        """Bereichsspezifisches Personenkennzeichen — stable across logins.

        This is the only identifier safe for personal recognition. The OIDC
        ``sub`` claim is *transient* (different on every login) at ID Austria.
        """
        return self.claims.get(CLAIM_BPK)

    @property
    def sector(self) -> Optional[str]:
        """URN of the bpk sector (e.g. ``urn:publicid:gv.at:cdid+BW``)."""
        return self.claims.get(CLAIM_SECTOR)

    # --- personal attributes ------------------------------------------------
    @property
    def given_name(self) -> Optional[str]:
        return self.claims.get("given_name")

    @property
    def family_name(self) -> Optional[str]:
        return self.claims.get("family_name")

    @property
    def full_name(self) -> Optional[str]:
        parts = [p for p in (self.given_name, self.family_name) if p]
        return " ".join(parts) if parts else None

    @property
    def birthdate(self) -> Optional[date]:
        raw = self.claims.get("birthdate")
        if not raw:
            return None
        try:
            return date.fromisoformat(raw)
        except (TypeError, ValueError):
            return None

    @property
    def gender(self) -> Optional[str]:
        return self.claims.get(CLAIM_GENDER)

    @property
    def nationality(self) -> Optional[str]:
        return self.claims.get(CLAIM_NATIONALITY)

    @property
    def main_address(self) -> Optional[MainAddress]:
        encoded = self.claims.get(CLAIM_MAIN_ADDRESS)
        if not encoded:
            return None
        try:
            return MainAddress.from_encoded(encoded)
        except (binascii.Error, ValueError, json.JSONDecodeError):
            return None

    @property
    def portrait(self) -> Optional[str]:
        """Base64-encoded portrait image, if configured in IDA-SPR."""
        return self.claims.get(CLAIM_PORTRAIT)

    def age_over(self, years: int) -> Optional[bool]:
        """Return the ``age_over_N`` attestation if present, else ``None``.

        ID Austria only delivers the thresholds configured in IDA-SPR
        (typically 14/16/18/21). A missing attestation means "not configured",
        not "below threshold".
        """
        return self.claims.get(f"{_AGE_OVER_PREFIX}{years}")

    # --- assurance / meta ---------------------------------------------------
    @property
    def eidas_level(self) -> Optional[str]:
        """eIDAS level of assurance URI, e.g. ``http://eidas.europa.eu/LoA/high``."""
        return self.claims.get(CLAIM_EIDAS_LEVEL)

    @property
    def is_test_identity(self) -> bool:
        """True when the IdP flagged this as a test identity (ref env only)."""
        status = self.claims.get(CLAIM_IDENTITY_STATUS) or ""
        return "testidentity" in status.lower()

    # --- standard OIDC ------------------------------------------------------
    @property
    def subject(self) -> Optional[str]:
        """Transient OIDC ``sub`` — do NOT use for recognition; use :attr:`bpk`."""
        return self.claims.get("sub")

    @property
    def issuer(self) -> Optional[str]:
        return self.claims.get("iss")

    # --- dict-like escape hatch --------------------------------------------
    def get(self, key: str, default: Any = None) -> Any:
        return self.claims.get(key, default)

    def __contains__(self, key: str) -> bool:
        return key in self.claims
