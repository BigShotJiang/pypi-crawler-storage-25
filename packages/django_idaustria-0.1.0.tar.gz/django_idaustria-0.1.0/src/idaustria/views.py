from __future__ import annotations

from typing import Any

from django.http import HttpRequest, HttpResponse, JsonResponse, HttpResponseRedirect
from django.views.decorators.http import require_GET

from .exceptions import (
    AuthorizationError,
    IDAustriaError,
    IDTokenValidationError,
    StateMismatchError,
    TokenExchangeError,
)
from .identity import CLAIM_BPK, IDAustriaIdentity
from .oidc import (
    build_authorize_url,
    exchange_code_for_tokens,
    validate_id_token,
    pop_flow_state,
    get_flow_state,
)
from .signals import identification_completed
from .session import set_pending_identification


@require_GET
def start(request: HttpRequest) -> HttpResponse:
    """Initiate the ID Austria identification by redirecting to the authorize endpoint."""
    url, state = build_authorize_url(request)
    # Return a redirect to the ID Austria IdP
    return HttpResponseRedirect(url)


def _emit_failure(request: HttpRequest, exc: IDAustriaError) -> None:
    identification_completed.send(
        sender=callback,
        request=request,
        success=False,
        identity=None,
        tokens=None,
        error=exc,
    )


def _error_response(exc: IDAustriaError, status: int = 400) -> JsonResponse:
    """Structured JSON response so callers can distinguish error kinds."""
    payload: dict[str, Any] = {
        "ok": False,
        "error": type(exc).__name__,
        "message": str(exc),
    }
    if isinstance(exc, AuthorizationError):
        payload["error"] = exc.code
        if exc.description:
            payload["error_description"] = exc.description
        if exc.uri:
            payload["error_uri"] = exc.uri
    return JsonResponse(payload, status=status)


def _state_matches(
    request: HttpRequest, state_param: str | None
) -> tuple[bool, dict[str, Any]]:
    flow_state: dict[str, Any] = dict(get_flow_state(request))
    expected = flow_state.get("state") if flow_state else None
    ok = not expected or state_param == expected
    return ok, flow_state


@require_GET
def callback(request: HttpRequest) -> HttpResponse:
    """Callback endpoint for the ID Austria flow.

    Handles three incoming shapes per RFC 6749 §4.1.2:
      1. Success: ``?code=...&state=...`` — exchange code, validate id_token,
         store pending payload, fire signal with ``success=True``.
      2. IdP error: ``?error=...&error_description=...&state=...`` — surface
         as :class:`AuthorizationError`, fire signal with ``success=False``.
      3. Malformed: neither ``code`` nor ``error`` — treated as a bad request.
    """
    state_param = request.GET.get("state")
    error_code = request.GET.get("error")
    code = request.GET.get("code")

    # --- IdP-reported error ---------------------------------------------------
    if error_code:
        # Validate state even on error: a mismatched state means the error is
        # not tied to a flow we initiated and could be a replay/forgery.
        state_ok, _ = _state_matches(request, state_param)
        if not state_ok:
            exc: IDAustriaError = StateMismatchError(
                "State parameter mismatch on error response"
            )
            _emit_failure(request, exc)
            pop_flow_state(request)
            return _error_response(exc)

        exc = AuthorizationError(
            code=error_code,
            description=request.GET.get("error_description"),
            uri=request.GET.get("error_uri"),
        )
        pop_flow_state(request)
        _emit_failure(request, exc)
        # access_denied (user cancelled) is semantically "forbidden", others
        # are protocol/configuration failures — both map to 400 for callers
        # who just want to know the flow didn't complete.
        return _error_response(exc)

    # --- Malformed callback ---------------------------------------------------
    if not code:
        exc = IDAustriaError("Missing authorization code")
        _emit_failure(request, exc)
        return _error_response(exc)

    # --- Success path ---------------------------------------------------------
    state_ok, flow_state = _state_matches(request, state_param)
    if not state_ok:
        exc = StateMismatchError("State parameter mismatch")
        _emit_failure(request, exc)
        return _error_response(exc)

    try:
        tokens = exchange_code_for_tokens(
            request, code, code_verifier=flow_state.get("code_verifier")
        )
        id_token = tokens.get("id_token")
        if not id_token:
            raise TokenExchangeError("No id_token in token response")

        claims = validate_id_token(id_token)
        identity = IDAustriaIdentity(claims=claims)

        pop_flow_state(request)
        pending_id = set_pending_identification(
            request,
            {
                "id_token": id_token,
                "access_token": tokens.get("access_token"),
                "token_type": tokens.get("token_type"),
                "scope": tokens.get("scope"),
                "expires_in": tokens.get("expires_in"),
                "sub": claims.get("sub", ""),
                "bpk": claims.get(CLAIM_BPK),
                "claims": dict(claims),
            },
        )

        identification_completed.send(
            sender=callback,
            request=request,
            success=True,
            identity=identity,
            tokens=tokens,
            error=None,
        )
        return JsonResponse(
            {"ok": True, "claims": dict(claims), "pending_id": pending_id}
        )
    except (TokenExchangeError, IDTokenValidationError, IDAustriaError) as exc:
        _emit_failure(request, exc)
        return _error_response(exc)
