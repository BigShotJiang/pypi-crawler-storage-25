from django.urls import path

from . import views

app_name = "idaustria"

urlpatterns = [
    path("start/", views.start, name="start"),
    path("callback/", views.callback, name="callback"),
]
