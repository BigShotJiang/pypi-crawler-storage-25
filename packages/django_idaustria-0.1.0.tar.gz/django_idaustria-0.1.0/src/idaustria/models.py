from django.conf import settings
from django.db import models

from .identity import IDAustriaIdentity


class Identification(models.Model):
    """Stores a successful ID Austria identification for a user."""

    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="idaustria_identifications",
    )

    # Tokens returned by the token endpoint
    id_token = models.TextField()
    access_token = models.TextField(blank=True, null=True)
    token_type = models.CharField(max_length=32, blank=True, null=True)
    scope = models.CharField(max_length=512, blank=True, null=True)
    expires_in = models.IntegerField(blank=True, null=True)

    # Core claims (denormalized for convenience)
    sub = models.CharField(max_length=255)
    bpk = models.CharField(
        max_length=255,
        blank=True,
        null=True,
        help_text="urn:pvpgvat:oidc.bpk claim if present",
    )

    # Full claims payload
    claims = models.JSONField()

    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ("-created_at",)

    def __str__(self) -> str:  # pragma: no cover - simple repr
        return f"Identification(user={self.user_id}, sub={self.sub})"

    @property
    def identity(self) -> IDAustriaIdentity:
        """Typed view over :attr:`claims` — see :class:`IDAustriaIdentity`."""
        return IDAustriaIdentity(claims=self.claims or {})
