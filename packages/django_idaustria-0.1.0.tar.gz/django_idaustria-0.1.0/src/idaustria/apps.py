from django.apps import AppConfig


class IdaustriaConfig(AppConfig):
    name = "idaustria"
