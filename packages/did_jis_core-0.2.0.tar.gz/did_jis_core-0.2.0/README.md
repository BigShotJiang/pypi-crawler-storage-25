# did-jis-core — DEPRECATED

This package is deprecated and no longer maintained.

The DID:JIS method has been superseded by the JIS identity standard.

See [humotica.com](https://humotica.com) for current packages.
