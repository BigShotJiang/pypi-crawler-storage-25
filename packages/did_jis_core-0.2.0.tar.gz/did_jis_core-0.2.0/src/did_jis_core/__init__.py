"""
did-jis-core — DEPRECATED
=========================

This package is deprecated and no longer maintained.
The DID:JIS method has been superseded by the JIS identity standard.

See: https://humotica.com
"""

import warnings

warnings.warn(
    "did-jis-core is deprecated and no longer maintained. "
    "See https://humotica.com for current JIS identity packages.",
    DeprecationWarning,
    stacklevel=2,
)

__version__ = "0.2.0"
