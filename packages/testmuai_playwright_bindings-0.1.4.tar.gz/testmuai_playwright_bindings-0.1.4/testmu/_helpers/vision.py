"""Vision helpers — query, textual query, wait, action, and coordinate lookup.

All five functions are smart-gated: when _config.smart is OFF they return
safe fallbacks immediately without touching any network endpoint.

When smart is ON, they call the analyzer sidecar via aiohttp.

Analyzer base URL is read from TESTMU_AI_API_HOST env var
(default: http://localhost:8000).
"""

import asyncio
import base64
import logging
import os

import aiohttp

from testmu import _config
from testmu._helpers._http import create_session
from testmu._helpers._screenshot import take_screenshot
from testmu._helpers._dom_capture import (
    build_flat_dom as _build_flat_dom,
    get_element_snapshot as _get_element_snapshot,
)

_log = logging.getLogger("testmu")

_VISION_API_HOST = os.getenv("TESTMU_AI_API_HOST", "https://kaneai-api.lambdatest.com/v16-server")
_ANALYZER_URL = f"{_VISION_API_HOST}/api/v1/analyzer"
_ANALYZER_TIMEOUT = aiohttp.ClientTimeout(total=120)
_QUERY_TIMEOUT = aiohttp.ClientTimeout(total=60)

_WAIT_MAX_RETRIES = 5
_WAIT_RETRY_INTERVAL = 2  # seconds

_COORD_MAX_RETRIES = 10
_COORD_RETRY_INTERVAL = 1  # seconds


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


async def _post_analyzer(
    session: aiohttp.ClientSession, body: dict, timeout=None
) -> dict:
    """POST to the analyzer endpoint and return parsed JSON."""
    t = timeout or _ANALYZER_TIMEOUT
    async with session.post(_ANALYZER_URL, json=body, timeout=t) as resp:
        if resp.status != 200:
            text = await resp.text()
            raise Exception(f"Analyzer API error {resp.status}: {text}")
        return await resp.json()


async def _check_wait_condition(
    session: aiohttp.ClientSession, screenshot_b64: str, query: str
) -> dict:
    async with session.post(
        f"{_VISION_API_HOST}/api/v1/wait/check",
        json={"screenshot_b64": screenshot_b64, "query": query},
        timeout=aiohttp.ClientTimeout(total=30),
    ) as resp:
        if resp.status == 200:
            return await resp.json()
        raise Exception(f"Wait API error: {resp.status}")


async def _check_visibility(
    session: aiohttp.ClientSession, screenshot_b64: str, query: str
) -> dict:
    async with session.post(
        f"{_VISION_API_HOST}/api/v1/visibility/check",
        json={"screenshot_b64": screenshot_b64, "query": query},
        timeout=aiohttp.ClientTimeout(total=30),
    ) as resp:
        if resp.status == 200:
            return await resp.json()
        raise Exception(f"Visibility API error: {resp.status}")


async def _wait_for_visibility(page, query: str, opts: dict = None) -> str:
    """Poll visibility API until element is visible; return the last screenshot_b64.

    opts keys (all optional):
        max_retries (int):     defaults to _COORD_MAX_RETRIES
        retry_interval (int):  seconds between attempts, defaults to _COORD_RETRY_INTERVAL
        should_raise (bool):   when False, return the last screenshot_b64 instead of
                               raising on exhaustion. Defaults to True.
    """
    opts = opts or {}
    max_retries = opts.get("max_retries", _COORD_MAX_RETRIES)
    retry_interval = opts.get("retry_interval", _COORD_RETRY_INTERVAL)
    should_raise = opts.get("should_raise", True)

    last_reasoning = None
    last_screenshot_b64 = None
    async with create_session() as session:
        for attempt in range(1, max_retries + 1):
            screenshot_bytes = await take_screenshot(page)
            screenshot_b64 = base64.b64encode(screenshot_bytes).decode("utf-8")
            last_screenshot_b64 = screenshot_b64

            result = await _check_visibility(session, screenshot_b64, query)
            _log.info(
                "    [visibility] attempt %d/%d visible=%s",
                attempt,
                max_retries,
                result.get("visible"),
            )

            if result.get("visible", False):
                return screenshot_b64

            last_reasoning = result.get("reasoning", "unknown")
            if attempt < max_retries:
                await asyncio.sleep(retry_interval)

    if not should_raise:
        _log.info(
            "    [visibility] not visible after %d attempts (should_raise=False); returning last screenshot. reasoning=%s",
            max_retries,
            last_reasoning,
        )
        return last_screenshot_b64

    raise Exception(
        f"Element not visible after {max_retries} attempts. Last reasoning: {last_reasoning}"
    )


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


async def vision_query(page, description: str, return_type: str):
    """Extract a value from the page using a screenshot + analyzer API.

    Smart-gated: returns None when _config.smart is OFF.

    Args:
        page: Playwright page object.
        description: Natural-language description of what to extract.
        return_type: Expected type hint (e.g. "string").

    Returns:
        Extracted value as a string, or None when smart is OFF.
    """
    if not _config.smart:
        return None

    _log.info("    [vision_query] query=%s", description[:80])

    # VQ must not throw on invisibility — fall through with the last screenshot
    # so the analyzer still gets a chance to extract.
    screenshot_b64 = await _wait_for_visibility(
        page,
        description,
        opts={"max_retries": 2, "retry_interval": 2, "should_raise": False},
    )

    async with create_session() as session:
        result = await _post_analyzer(
            session,
            {
                "type": "visual",
                "query": description,
                "screenshot_b64": screenshot_b64,
            },
            timeout=_QUERY_TIMEOUT,
        )

    extracted = result.get("extracted_value", "")
    _log.info("    [vision_query] result=%s", repr(extracted)[:120])
    return extracted


async def textual_query(page, description: str, return_type: str):
    """Extract a value from a DOM element using 2-step DOM + analyzer API.

    Step 1: Build flat accessibility tree, identify target element via LLM.
    Step 2: Snapshot element via CDP, extract value via LLM.

    Smart-gated: returns None when _config.smart is OFF.

    Args:
        page: Playwright page object.
        description: Natural-language description of what to extract.
        return_type: Expected type hint (e.g. "string").

    Returns:
        Extracted value as a string, or None when smart is OFF.
    """
    if not _config.smart:
        return None

    _log.info("    [textual_query] query=%s", description[:80])

    cdp = await page.context.new_cdp_session(page)
    try:
        await cdp.send("DOM.enable")

        a11y_resp = await cdp.send("Accessibility.getFullAXTree")
        flat_dom = _build_flat_dom(a11y_resp.get("nodes", []))

        screenshot_bytes = await take_screenshot(page)
        screenshot_b64 = base64.b64encode(screenshot_bytes).decode("utf-8")

        async with create_session() as session:
            identify_resp = await _post_analyzer(
                session,
                {
                    "type": "dom",
                    "query": description,
                    "full_dom_list": flat_dom,
                    "screenshot_b64": screenshot_b64,
                },
            )
            dom_index = identify_resp.get("dom_index")
            if dom_index is None:
                raise Exception(
                    f"DOM identify step returned no dom_index: {identify_resp}"
                )
            dom_index = int(dom_index)

            target = next((el for el in flat_dom if el.get("index") == dom_index), None)
            if not target or "backend_dom_node_id" not in target:
                raise Exception(
                    f"Element at dom_index={dom_index} not found or missing backend_dom_node_id"
                )

            snapshot = await _get_element_snapshot(cdp, target["backend_dom_node_id"])

            extract_resp = await _post_analyzer(
                session,
                {
                    "type": "dom",
                    "query": description,
                    "element_snapshot": snapshot,
                },
            )

        extracted = extract_resp.get("extracted_value", "")
        _log.info("    [textual_query] result=%s", repr(extracted)[:120])
        return extracted

    finally:
        await cdp.detach()


async def vision_wait(page, description: str, timeout_ms: int = 30000):
    """Poll the vision wait API until the described condition is met.

    Smart-gated: falls back to page.wait_for_timeout(timeout_ms) when
    _config.smart is OFF.

    Args:
        page: Playwright page object.
        description: Human-readable description of what to wait for.
        timeout_ms: Original timeout in ms. Used as static sleep when smart is OFF.
    """
    if not _config.smart:
        await page.wait_for_timeout(timeout_ms)
        return

    _log.info("    [vision_wait] query=%s", description[:80])

    async with create_session() as session:
        for attempt in range(1, _WAIT_MAX_RETRIES + 1):
            screenshot_bytes = await take_screenshot(page)
            screenshot_b64 = base64.b64encode(screenshot_bytes).decode("utf-8")

            result = await _check_wait_condition(session, screenshot_b64, description)
            waiting = result.get("waiting", True)
            _log.info(
                "    [vision_wait] attempt %d/%d waiting=%s",
                attempt,
                _WAIT_MAX_RETRIES,
                waiting,
            )

            if not waiting:
                return

            if attempt < _WAIT_MAX_RETRIES:
                await asyncio.sleep(_WAIT_RETRY_INTERVAL)

    _log.info("    [vision_wait] max retries exhausted, continuing")


async def vision_action(
    page, description: str, action_type: str, direction: str = "down", amount: int = 300
) -> bool:
    """Get vision coordinates and execute click or scroll at those coordinates.

    Smart-gated: returns None when _config.smart is OFF.

    Args:
        page: Playwright page object.
        description: Human-readable description of the target element.
        action_type: "click" or "scroll".
        direction: Scroll direction ("up", "down", "left", "right"). Only used for scroll.
        amount: Scroll amount in pixels. Only used for scroll.

    Returns:
        True if coordinates found and action executed, False on API miss,
        or None when smart is OFF.
    """
    if not _config.smart:
        return None

    _log.info("    [vision_action] action=%s query=%s", action_type, description[:60])

    screenshot_bytes = await take_screenshot(page)
    screenshot_b64 = base64.b64encode(screenshot_bytes).decode("utf-8")

    viewport = page.viewport_size
    width = viewport["width"] if viewport else 1280
    height = viewport["height"] if viewport else 713

    async with create_session() as session:
        async with session.post(
            f"{_VISION_API_HOST}/api/v1/vision/coordinates",
            json={
                "screenshot_b64": screenshot_b64,
                "action_instruction": description,
                "action_type": action_type,
                "width": width,
                "height": height,
            },
            timeout=aiohttp.ClientTimeout(total=30),
        ) as resp:
            if resp.status != 200:
                _log.info("    [vision_action] API error status=%d", resp.status)
                return False
            result = await resp.json()
            if not result.get("found", False):
                _log.info("    [vision_action] element not found")
                return False
            coord_x = result["x"]
            coord_y = result["y"]

    _log.info(
        "    [vision_action] executing %s at (%d, %d)", action_type, coord_x, coord_y
    )

    if action_type == "click":
        await page.mouse.click(coord_x, coord_y)
    elif action_type == "scroll":
        delta_x = 0
        delta_y = 0
        if direction == "down":
            delta_y = amount
        elif direction == "up":
            delta_y = -amount
        elif direction == "right":
            delta_x = amount
        elif direction == "left":
            delta_x = -amount
        await page.mouse.move(coord_x, coord_y)
        await page.mouse.wheel(delta_x, delta_y)

    return True


async def get_vision_coordinates(
    page, description: str, action_type: str = "click", x: int = None, y: int = None
) -> dict:
    """Get coordinates for an element via vision API.

    When smart is ON: always uses vision API. No fallback to (x, y) — if the
    API can't find the element or errors, raises instead of silently using
    stale coordinates that may click the wrong thing.

    When smart is OFF: returns {"x": x, "y": y} immediately.

    Args:
        page: Playwright page object.
        description: Description of the action/element to find.
        action_type: Type of action ("click", "type", etc.).
        x: X coordinate used only when smart is OFF.
        y: Y coordinate used only when smart is OFF.

    Returns:
        dict with 'x' and 'y' keys.
    """
    if not _config.smart:
        return {"x": x, "y": y}

    _log.info("    [get_vision_coordinates] query=%s", description[:60])

    screenshot_b64 = await _wait_for_visibility(page, description)

    viewport = page.viewport_size
    width = viewport["width"] if viewport else 1920
    height = viewport["height"] if viewport else 1080

    async with create_session() as session:
        async with session.post(
            f"{_VISION_API_HOST}/api/v1/vision/coordinates",
            json={
                "screenshot_b64": screenshot_b64,
                "action_instruction": description,
                "action_type": action_type,
                "width": width,
                "height": height,
            },
            timeout=aiohttp.ClientTimeout(total=30),
        ) as resp:
            if resp.status != 200:
                raise Exception(f"Vision API error: {resp.status}")
            result = await resp.json()
            if not result.get("found", False):
                raise Exception(
                    f"Vision API: element not found for query={description!r}"
                )
            coords = {"x": result["x"], "y": result["y"]}
            _log.info(
                "    [get_vision_coordinates] found (%d, %d)", coords["x"], coords["y"]
            )
            return coords
