"""Vision wait/check helper — check_until_condition.

Smart-gated: calls the vision sidecar's wait/check endpoint.
When smart is OFF, returns False immediately (condition not met — skip behavior).
"""
import base64
import logging

import aiohttp

from testmu._helpers._http import create_session
from testmu._helpers._screenshot import take_screenshot

from testmu import _config

_log = logging.getLogger("testmu")

_AI_API_HOST_DEFAULT = "https://kaneai-api.lambdatest.com/v16-server"


async def check_until_condition(page, condition: str) -> bool:
    """Check whether a named condition is satisfied by querying the vision API.

    Takes a screenshot, sends it to the vision wait/check endpoint, and
    returns True when the condition is met.

    Smart-gated: returns False immediately when _config.smart is OFF.

    Args:
        page: Playwright page object.
        condition: Natural-language description of the condition to check.

    Returns:
        True if the condition is satisfied, False otherwise (including when
        smart is OFF).
    """
    import os

    if not _config.smart:
        _log.info("[check_until_condition] smart is OFF — returning False (condition skipped)")
        return False

    vision_api_host = os.getenv("TESTMU_AI_API_HOST", _AI_API_HOST_DEFAULT)

    _log.info("    [check_until_condition] condition=%s", condition[:80])

    screenshot_bytes = await take_screenshot(page)
    screenshot_b64 = base64.b64encode(screenshot_bytes).decode("utf-8")

    async with create_session() as session:
        async with session.post(
            f"{vision_api_host}/api/v1/wait/check",
            json={"screenshot_b64": screenshot_b64, "query": condition},
            timeout=aiohttp.ClientTimeout(total=30),
        ) as response:
            if response.status == 200:
                result = await response.json()
                met = not result.get("waiting", True)
                _log.info("    [check_until_condition] met=%s", met)
                return met
            _log.info("    [check_until_condition] API error status=%d → returning False",
                      response.status)
            return False
