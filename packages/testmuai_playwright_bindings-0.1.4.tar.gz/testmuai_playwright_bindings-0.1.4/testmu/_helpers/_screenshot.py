"""Internal helper: wait briefly then take a page screenshot.

300ms settle gives in-flight animations / lazy reflows a chance to land
before the screenshot is captured. Used by every binding code path that
screenshots the page (vision, wait, assertion, autoheal). Not exported
on the testmu namespace — internal use only (leading underscore).
"""


async def take_screenshot(page) -> bytes:
    await page.wait_for_timeout(300)
    return await page.screenshot()
