"""TestMu dashboard reporter (LambdaTest grid).

Uses page.evaluate('lambdatest_action: ...') for:
  - setTestStatus (overall test verdict)
  - lambda-testCase-start / lambda-testCase-end (per-step annotations on LT timeline)

All events are ALSO logged to stdout so HyperExecute console
shows progress — the CDP calls alone are invisible in HE logs.

The page reference is set by testmu.run() at session start.
"""

import json
import logging

_log = logging.getLogger("testmu")


class LTReporter:
    def __init__(self):
        self._page = None
        self._step_num = 0

    def set_page(self, page):
        self._page = page

    async def begin_test(self, name):
        self._step_num = 0
        _log.info("[TEST START] %s", name)

    async def pass_test(self):
        _log.info("[TEST PASS] (%d steps)", self._step_num)
        await self._evaluate_action(
            "setTestStatus",
            {
                "status": "passed",
                "remark": "Test completed successfully",
            },
        )

    async def fail_test(self, error):
        _log.error("[TEST FAIL] at step %d — %s", self._step_num, error)
        await self._evaluate_action(
            "setTestStatus",
            {
                "status": "failed",
                "remark": str(error),
            },
        )

    async def begin_step(self, description):
        self._step_num += 1
        _log.info("  [STEP %d] %s", self._step_num, description)
        await self._evaluate_action("lambda-testCase-start", {"name": description})

    async def end_step(self, description, ok, error=None):
        if not ok:
            _log.error("  [STEP %d FAIL] %s", self._step_num, error)
        await self._evaluate_action("lambda-testCase-end", {"name": description})

    async def warn_step(self, description, error):
        _log.warning("  [STEP %d WARN] %s — %s", self._step_num, description, error)
        await self._evaluate_action(
            "lambda-testCase-start",
            {"name": f"[WARN] {description}: {error}"},
        )

    # async def attach_screenshot(self, data):
    #     # Stub — screenshot bytes aren't uploaded to LT dashboard yet.
    #     _log.info("  [SCREENSHOT] %d bytes", len(data))

    async def _evaluate_action(self, action, arguments):
        if self._page is None:
            return
        try:
            payload = json.dumps({"action": action, "arguments": arguments})
            await self._page.evaluate("_ => {}", f"lambdatest_action: {payload}")
        except Exception as e:
            _log.warning("lambdatest_action failed: %s", e)

    # async def _evaluate_executor(self, action, arguments):
    #     # Unused — stepcontext was replaced by testCaseStart/End.
    #     if self._page is None:
    #         return
    #     try:
    #         payload = json.dumps({"action": action, "arguments": arguments})
    #         await self._page.evaluate("_ => {}", f"lambdatest_executor: {payload}")
    #     except Exception as e:
    #         _log.warning("lambdatest_executor failed: %s", e)
