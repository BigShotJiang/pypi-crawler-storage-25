"""Local stdout reporter."""
import logging

_log = logging.getLogger("testmu")


class LocalReporter:
    def __init__(self):
        self._step_num = 0

    async def begin_test(self, name):
        self._step_num = 0
        _log.info("[TEST START] %s", name)

    async def pass_test(self):
        _log.info("[TEST PASS] (%d steps)", self._step_num)

    async def fail_test(self, error):
        _log.error("[TEST FAIL] at step %d — %s", self._step_num, error)

    async def begin_step(self, description):
        self._step_num += 1
        _log.info("  [STEP %d] %s", self._step_num, description)

    async def end_step(self, description, ok, error=None):
        if not ok:
            _log.error("  [STEP %d FAIL] %s", self._step_num, error)

    async def warn_step(self, description, error):
        _log.warning("  [STEP %d WARN] %s — %s", self._step_num, description, error)

    # async def attach_screenshot(self, data):
    #     # Stub — screenshot bytes aren't uploaded anywhere.
    #     _log.info("  [SCREENSHOT] %d bytes", len(data))
