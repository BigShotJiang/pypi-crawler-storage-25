from html import escape

from panelmark.layout import HSplit, VSplit, Panel, BorderRow

from .css import get_base_css


class HTMLRenderer:
    """Converts a panelmark Shell into an HTML fragment or full document.

    Renders the shell's panel structure with stable DOM hooks.  Each named
    panel that has an assigned interaction receives ``data-pm-interaction``,
    ``data-pm-focusable``, and ``data-pm-focused`` attributes.  Named panels
    without an assigned interaction receive ``data-pm-empty="true"``.  Panel
    bodies are always empty placeholders; interaction body content is deferred
    to ``panelmark-web``.

    CSS rules are provided by ``get_base_css()``.
    """

    def render_fragment(self, shell, *, include_css: bool = False) -> str:
        """Return an HTML fragment for *shell*.

        Parameters
        ----------
        shell:
            A ``panelmark.Shell`` instance.
        include_css:
            If True, prepend a ``<style>`` block with the base CSS.
        """
        parts = []
        if include_css:
            css = get_base_css()
            if css:
                parts.append(f'<style>\n{css}\n</style>\n')
        parts.append(self._render_shell(shell))
        return ''.join(parts)

    def render_document(self, shell, *, title: str = 'panelmark',
                        css_href: str | None = None,
                        extra_head: str = '') -> str:
        """Return a full HTML document for *shell*.

        Parameters
        ----------
        shell:
            A ``panelmark.Shell`` instance.
        title:
            Value for the ``<title>`` element.
        css_href:
            If provided, emit a ``<link>`` to this stylesheet instead of
            inlining the base CSS.
        extra_head:
            Optional raw HTML string appended inside ``<head>`` before
            ``</head>``.
        """
        head_lines = [
            '    <meta charset="UTF-8">',
            '    <meta name="viewport" content="width=device-width, initial-scale=1.0">',
            f'    <title>{escape(title)}</title>',
        ]
        if css_href:
            head_lines.append(
                f'    <link rel="stylesheet" href="{escape(css_href, quote=True)}">'
            )
        else:
            css = get_base_css()
            if css:
                head_lines.append(f'    <style>\n{css}\n    </style>')
        if extra_head:
            head_lines.append(f'    {extra_head}')

        head = '\n'.join(head_lines)
        fragment = self._render_shell(shell)

        return (
            '<!DOCTYPE html>\n'
            '<html lang="en">\n'
            '<head>\n'
            f'{head}\n'
            '</head>\n'
            '<body>\n'
            f'{fragment}'
            '</body>\n'
            '</html>\n'
        )

    # ------------------------------------------------------------------
    # Internal rendering
    # ------------------------------------------------------------------

    def _render_shell(self, shell) -> str:
        node = shell.layout.root
        if node is None:
            return '<div class="pm-shell" data-pm-shell></div>\n'
        inner = self._render_node(node, shell, indent=2)
        return f'<div class="pm-shell" data-pm-shell>\n{inner}</div>\n'

    def _render_node(self, node, shell, indent: int = 0) -> str:
        if node is None:
            return ''
        pad = ' ' * indent

        if isinstance(node, Panel):
            return self._render_panel(node, shell, indent)

        if isinstance(node, VSplit):
            left = self._render_node(node.left, shell, indent + 2)
            right = self._render_node(node.right, shell, indent + 2)
            return (
                f'{pad}<div class="pm-split pm-split-v">\n'
                f'{left}'
                f'{right}'
                f'{pad}</div>\n'
            )

        if isinstance(node, HSplit):
            top = self._render_node(node.top, shell, indent + 2)
            border = ''
            if (node.border is not None
                    and node.top is not None
                    and node.bottom is not None):
                border = self._render_border(node.border, indent + 2)
            bottom = self._render_node(node.bottom, shell, indent + 2)
            return (
                f'{pad}<div class="pm-split pm-split-h">\n'
                f'{top}'
                f'{border}'
                f'{bottom}'
                f'{pad}</div>\n'
            )

        return ''

    def _render_border(self, border: BorderRow, indent: int = 0) -> str:
        pad = ' ' * indent
        style_class = 'pm-border-double' if border.style == 'double' else 'pm-border-single'
        if border.title:
            inner = ' ' * (indent + 2)
            return (
                f'{pad}<div class="pm-border {style_class}">\n'
                f'{inner}<span class="pm-border-title">{escape(border.title)}</span>\n'
                f'{pad}</div>\n'
            )
        return f'{pad}<div class="pm-border {style_class}"></div>\n'

    def _render_panel(self, node: Panel, shell, indent: int = 0) -> str:
        pad = ' ' * indent
        inner = ' ' * (indent + 2)

        attrs = ['class="pm-panel"']
        if node.name:
            attrs.append(f'data-pm-region="{escape(node.name, quote=True)}"')
            attrs.append('data-pm-kind="panel"')
            attrs.append(f'id="pm-region-{escape(node.name, quote=True)}"')

            if node.heading:
                attrs.append(f'data-pm-heading="{escape(node.heading, quote=True)}"')

            interaction = shell.interactions.get(node.name)
            if interaction is not None:
                cls = type(interaction)
                qualified = f'{cls.__module__}.{cls.__qualname__}'
                focusable = 'true' if interaction.is_focusable else 'false'
                focused = 'true' if shell.focus == node.name else 'false'
                attrs.append(f'data-pm-interaction="{escape(qualified, quote=True)}"')
                attrs.append(f'data-pm-focusable="{focusable}"')
                attrs.append(f'data-pm-focused="{focused}"')
            else:
                attrs.append('data-pm-empty="true"')

        lines = [f'{pad}<section {" ".join(attrs)}>\n']

        if node.heading:
            lines.append(
                f'{inner}<header class="pm-panel-heading">'
                f'{escape(node.heading)}'
                f'</header>\n'
            )

        lines.append(f'{inner}<div class="pm-panel-body"></div>\n')
        lines.append(f'{pad}</section>\n')

        return ''.join(lines)
