"""
CF-Ares tests package.
"""
