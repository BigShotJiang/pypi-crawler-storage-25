"""
sdd-kit v2.0.0 — Spec-Driven Development CLI
"""

__version__ = "2.0.3"
__author__ = "SDD Team"
