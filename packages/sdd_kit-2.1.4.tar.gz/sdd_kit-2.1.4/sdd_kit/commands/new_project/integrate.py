"""
sdd /integrate
Generate integration-skeleton.py from live Silver schema (~1m).
"""
from __future__ import annotations

from pathlib import Path

from rich.console import Console

console = Console()


def run(
    project_root: Path | None = None,
    retro: bool = False,
    dry_run: bool = False,
    platform_name: str = "mock",
) -> Path:
    root = project_root or Path.cwd()
    task = "retro-integrate" if retro else "integrate"

    spec_path = root / "spec.md"
    if not spec_path.exists():
        console.print("[red]❌ spec.md not found. Run 'sdd /specify' first.[/]")
        raise FileNotFoundError("spec.md not found")

    spec_content = spec_path.read_text(encoding="utf-8")
    console.print(f"[bold blue]🔗 Generating integration skeleton (retro={retro})...[/]")

    from sdd_kit.agent.orchestrator import Orchestrator
    orch = Orchestrator(project_root=root, platform_name=platform_name)

    result = orch.run_task(
        task=task,
        user_input=spec_content,
        top_k=8,
        dry_run=dry_run,
    )

    out_dir = root / "src" / "integrations"
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / "integration-skeleton.py"
    out_path.write_text(result, encoding="utf-8")

    console.print(f"[green]✓ integration-skeleton.py → {out_path}[/]")
    return out_path
