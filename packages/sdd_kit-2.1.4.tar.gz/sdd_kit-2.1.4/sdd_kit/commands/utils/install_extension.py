"""
sdd install-extension
Helper to install the VS Code extension directly from the Python package.
"""
from __future__ import annotations

import os
import subprocess
from pathlib import Path

from rich.console import Console

console = Console()


def run() -> bool:
    """
    Locate the bundled VSIX and install it via 'code' command.
    """
    # 1. Locate the VSIX inside the package
    pkg_root = Path(__file__).parent.parent.parent
    vsix_path = pkg_root / "core" / "extensions" / "sdd-kit-2.0.3.vsix"

    if not vsix_path.exists():
        console.print("[red]❌ Extension package (.vsix) not found in the installation.[/]")
        console.print("[dim]Note: The extension must be bundled during the build process.[/]")
        return False

    console.print(f"[bold blue]📦 Found extension: {vsix_path.name}[/]")
    console.print("[dim]Attempting to install via 'code --install-extension'...[/]")

    try:
        # Check if 'code' command is available
        subprocess.run(["code", "--version"], check=True, capture_output=True)
    except (subprocess.CalledProcessError, FileNotFoundError):
        console.print("[red]❌ 'code' command not found in PATH.[/]")
        console.print("[yellow]Please ensure you have VS Code installed and the 'code' command is in your PATH.[/]")
        console.print("[dim]In VS Code, run 'Shell Command: Install 'code' command in PATH' from the Command Palette.[/]")
        return False

    # 2. Run the install command
    try:
        subprocess.run(["code", "--install-extension", str(vsix_path)], check=True)
        console.print("[bold green]✅ VS Code Extension installed successfully![/]")
        console.print("[dim]Please reload VS Code or use 'Developer: Reload Window' to activate it.[/]")
        return True
    except subprocess.CalledProcessError as e:
        console.print(f"[red]❌ Installation failed: {e}[/]")
        return False
