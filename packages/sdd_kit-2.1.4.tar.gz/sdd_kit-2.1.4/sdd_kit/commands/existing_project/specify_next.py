"""
sdd /specify-next
Generate spec-next.md — delta spec for existing projects (≤60s).
Rule 08: Delta only. Never rewrite spec.md.
"""
from __future__ import annotations

from pathlib import Path

from rich.console import Console

console = Console()


def run(
    project_root: Path | None = None,
    next_goals: str = "",
    dry_run: bool = False,
    platform_name: str = "mock",
) -> Path:
    root = project_root or Path.cwd()
    audit_path = root / ".sdd" / "audit.md"

    if not audit_path.exists():
        console.print("[red]❌ audit.md not found. Run 'sdd /audit' first.[/]")
        raise FileNotFoundError("audit.md not found")

    audit_content = audit_path.read_text(encoding="utf-8")
    console.print("[bold blue]📝 Generating spec-next.md (delta only)...[/]")

    user_input = audit_content
    if next_goals:
        user_input = f"## Next Phase Goals\n{next_goals}\n\n---\n\n{audit_content}"

    from sdd_kit.agent.orchestrator import Orchestrator
    orch = Orchestrator(project_root=root, platform_name=platform_name)

    result = orch.run_task(
        task="specify-next",
        user_input=user_input,
        existing_state=audit_content[:6000],  # audit.md IS the state
        top_k=10,
        dry_run=dry_run,
    )

    spec_next_path = root / "spec-next.md"
    spec_next_path.write_text(result, encoding="utf-8")

    console.print(f"[green]✓ spec-next.md → {spec_next_path}[/]")
    console.print("[dim]Next: run 'sdd /plan-next' to generate delta plan[/]")

    return spec_next_path
