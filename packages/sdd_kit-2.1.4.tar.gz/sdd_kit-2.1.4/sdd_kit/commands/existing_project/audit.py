"""
sdd /audit
Audit existing codebase — generates audit.md + audit-findings.md (≤90s).
Rule 08: Never say code is broken. Recommend delta only.
"""
from __future__ import annotations

from pathlib import Path

from rich.console import Console

console = Console()

MAX_CODE_SAMPLE_CHARS = 8_000  # ~2K tokens


def run(
    project_root: Path | None = None,
    dry_run: bool = False,
    return_prompt: bool = False,
    platform_name: str = "mock",
) -> Path | str:
    """
    Audit the existing project. Returns path to audit.md.
    """
    root = project_root or Path.cwd()
    sdd_dir = root / ".sdd"

    if not sdd_dir.exists():
        console.print("[yellow]⚠️  .sdd/ not found. Running 'sdd onboard' first...[/]")
        from sdd_kit.commands.existing_project.onboard import run as onboard_run
        onboard_run(project_root=root)

    console.print("[bold blue]🔍 Auditing existing codebase...[/]")

    # Sample code (≤2K tokens)
    code_sample = _sample_code(root)
    console.print(f"[dim]  Sampled {len(code_sample)} chars from source files[/]")

    from sdd_kit.agent.orchestrator import Orchestrator
    orch = Orchestrator(project_root=root, platform_name=platform_name)

    result = orch.run_task(
        task="audit",
        user_input=code_sample,
        top_k=8,
        existing_state="",
        dry_run=dry_run,
        return_prompt=return_prompt,
    )

    if return_prompt:
        return result

    audit_path = sdd_dir / "audit.md"
    audit_path.write_text(result, encoding="utf-8")

    # Also write to local-kb as audit-findings.md
    findings_path = sdd_dir / "local-kb" / "audit-findings.md"
    findings_path.write_text(result, encoding="utf-8")

    console.print(f"[green]✓ audit.md → {audit_path}[/]")
    console.print("[dim]Next: run 'sdd /specify-next' to generate delta spec[/]")

    return audit_path


def _sample_code(root: Path) -> str:
    """
    Strategically sample source code for the audit.
    Priority: entry points → data models → integration code → config.
    """
    priority_patterns = [
        "main.py", "app.py", "cli.py", "index.ts", "index.js",
        "**/models*.py", "**/schema*.py", "**/integration*.py",
        "pyproject.toml", "package.json", ".env.example",
    ]

    collected = []
    total = 0
    seen = set()

    for pattern in priority_patterns:
        for path in root.glob(pattern):
            if str(path) in seen:
                continue
            if any(skip in str(path) for skip in [".venv", "node_modules", "__pycache__", ".git"]):
                continue
            try:
                content = path.read_text(encoding="utf-8", errors="ignore")
                snippet = content[:2000]  # Max 2K per file
                header = f"\n\n### File: {path.relative_to(root)}\n```\n"
                footer = "\n```\n"
                entry = header + snippet + footer
                if total + len(entry) > MAX_CODE_SAMPLE_CHARS:
                    break
                collected.append(entry)
                total += len(entry)
                seen.add(str(path))
            except Exception:
                continue

    return f"# Code Sample (audit input)\nProject: {root.name}\n" + "".join(collected)
