"""
Session orchestrator — manages the session lifecycle.
Rules loaded once, skills loaded on-demand (Rule 07, 09).
"""
from __future__ import annotations

import logging
from pathlib import Path

logger = logging.getLogger(__name__)


class Orchestrator:
    """
    Single-agent orchestrator. Manages:
    - One-time system prompt loading (12 rules + skills manifest)
    - Per-turn context assembly (via ContextBuilder)
    - Claude API calls (via ClaudeClient)
    - Token budget enforcement
    - Session log
    """

    def __init__(self, project_root: Path | None = None, platform_name: str = "mock"):
        from sdd_kit.agent.claude_client import ClaudeClient
        from sdd_kit.agent.rules import build_system_prompt
        from sdd_kit.context.builder import ContextBuilder
        from sdd_kit.context.zone_loader import ZoneLoader
        from sdd_kit.lakehouse.semantic_query_adapter import SemanticQueryAdapter
        from sdd_kit.skills.registry import SkillsRegistry
        from sdd_kit.utils.config import PLATFORM

        self._project_root = project_root or Path.cwd()
        self._platform_name = platform_name or PLATFORM

        # Initialize platform
        self._platform = self._get_platform(self._platform_name)
        self._query_adapter = SemanticQueryAdapter(self._platform)

        # Session state — rules + manifest loaded ONCE
        self._system_prompt = build_system_prompt()
        self._rules_loaded = True

        # Components
        self._builder = ContextBuilder()
        self._zone_loader = ZoneLoader(self._project_root)
        self._skills = SkillsRegistry()
        self._client = ClaudeClient()

        logger.info(f"Orchestrator initialized (platform={self._platform_name})")

    def run_task(
        self,
        task: str,
        user_input: str = "",
        domain: str = "generic",
        top_k: int = 12,
        existing_state: str = "",
        dry_run: bool = False,
        return_prompt: bool = False,
    ) -> str:
        """
        Execute a single SDD task turn.
        task: 'specify' | 'plan' | 'audit' | 'specify-next' | etc.
        Returns the AI response text (or dry-run context dump).
        """
        # Load Zone 0 task prompt (once per turn)
        zone0_prompt = self._zone_loader.load_task_prompt(task)

        # Load Layer 2 skill file (on-demand, Rule 09)
        skill_content = self._skills.load_skill_file(f"{task}-skill")
        if skill_content:
            zone0_prompt = zone0_prompt + "\n\n---\n## Skill Reference\n" + skill_content
            logger.info(f"Loaded Layer 2 skill: {task}-skill")

        # Retrieve Gold chunks
        gold_chunks = self._query_adapter.retrieve(user_input or task, domain=domain, top_k=top_k)

        # Load Zone 2 local-kb
        zone2_kb = self._zone_loader.load_zone2_kb() if self._zone_loader.has_zone2_kb() else ""

        # Assemble context
        ctx = self._builder.build_for_task(
            task=task,
            zone0_prompt=zone0_prompt,
            gold_chunks=gold_chunks,
            zone2_kb=zone2_kb,
            user_input=user_input,
            existing_state=existing_state,
        )

        logger.info(f"\n{ctx.report()}")

        if return_prompt:
            return f"{self._system_prompt}\n\n---\n\n{ctx.text}"

        if dry_run:
            return f"[DRY RUN — {ctx.token_count} tokens assembled]\n\n{ctx.text}"

        if ctx.is_over_budget:
            logger.error("Context is over budget — refusing to call API")
            raise RuntimeError(f"Context exceeds 8K token budget: {ctx.token_count} tokens")

        # Call Claude
        return self._client.call(
            system_prompt=self._system_prompt,
            user_content=ctx.text,
            max_tokens=2048,
            task_name=task,
        )

    def _get_platform(self, name: str):
        if name == "databricks":
            from sdd_kit.lakehouse.platforms.databricks import DatabricksPlatform
            from sdd_kit.utils.config import DATABRICKS_HOST, DATABRICKS_TOKEN
            return DatabricksPlatform(host=DATABRICKS_HOST, token=DATABRICKS_TOKEN)
        elif name == "snowflake":
            from sdd_kit.lakehouse.platforms.snowflake import SnowflakePlatform
            return SnowflakePlatform()
        else:
            from sdd_kit.lakehouse.platforms.mock import MockPlatform
            return MockPlatform()
