import * as React from "react";
import { createRoot } from "react-dom/client";
import {
  ControlledTreeEnvironment,
  Tree,
} from "react-complex-tree";
import rctBaseRaw from "react-complex-tree/lib/style.css";
import rctModernRaw from "react-complex-tree/lib/style-modern.css";

// esbuild's `text` loader does NOT resolve `@import`, so style-modern.css's
// `@import "./style.css"` would silently drop the base stylesheet. Import both
// explicitly, strip the dead @import directive from modern, and rewrite :root
// to :host so CSS variables apply inside the shadow DOM.
const rctStyles = (rctBaseRaw + rctModernRaw.replace(/@import[^;]+;/g, ""))
  .replace(/:root\b/g, ":host");

const EXTRA_CSS = `
:host {
  display: block;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", system-ui, sans-serif;
  color: inherit;
}
.rct-tree-item-li {
  font-size: inherit;
}
`;

const TREE_ID = "rct-tree";

function useModelState(model, key, fallback) {
  const [value, setValue] = React.useState(() => model.get(key) ?? fallback);
  React.useEffect(() => {
    const handler = () => {
      const next = model.get(key);
      setValue(next == null ? fallback : Array.isArray(next) ? [...next] : next);
    };
    model.on(`change:${key}`, handler);
    return () => model.off(`change:${key}`, handler);
  }, [model, key]);
  return value;
}

function ComplexTree({ model }) {
  const items = useModelState(model, "items", {});
  const rootItem = useModelState(model, "root_item", "root");
  const selectedItems = useModelState(model, "selected_items", []);
  const expandedItems = useModelState(model, "expanded_items", []);
  const focusedItem = useModelState(model, "focused_item", undefined);
  const fontSize = useModelState(model, "font_size", 14);
  const treeRef = React.useRef(null);

  React.useEffect(() => {
    if (focusedItem && treeRef.current?.focusItem) {
      treeRef.current.focusItem(focusedItem);
    }
  }, [focusedItem]);

  const update = React.useCallback(
    (key, value) => {
      model.set(key, value);
      model.save_changes();
    },
    [model],
  );

  if (!items || Object.keys(items).length === 0) {
    return null;
  }

  return (
    <div style={{ fontSize: `${fontSize}px` }}>
    <ControlledTreeEnvironment
      items={items}
      getItemTitle={(item) => item.data}
      renderDepthOffset={18}
      renderItemArrow={({ item, context }) =>
        item.isFolder ? (
          <span
            {...context.arrowProps}
            className="rct-tree-item-arrow"
            style={{
              display: "inline-flex",
              alignItems: "center",
              justifyContent: "center",
              width: 16,
              height: 16,
              flexShrink: 0,
            }}
          >
            <svg
              viewBox="0 0 16 16"
              width="10"
              height="10"
              style={{
                transform: context.isExpanded ? "rotate(90deg)" : "none",
                transition: "transform 0.1s",
              }}
            >
              <path
                d="M5 3 L10 8 L5 13"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </span>
        ) : null
      }
      viewState={{
        [TREE_ID]: {
          selectedItems,
          expandedItems,
          focusedItem: focusedItem ?? undefined,
        },
      }}
      onSelectItems={(ids) => update("selected_items", [...ids])}
      onExpandItem={(item) => {
        const current = model.get("expanded_items") ?? [];
        if (!current.includes(item.index)) {
          update("expanded_items", [...current, item.index]);
        }
      }}
      onCollapseItem={(item) => {
        const current = model.get("expanded_items") ?? [];
        update(
          "expanded_items",
          current.filter((i) => i !== item.index),
        );
      }}
      onFocusItem={(item) => update("focused_item", item.index)}
    >
      <Tree
        ref={treeRef}
        treeId={TREE_ID}
        rootItem={rootItem}
        treeLabel="Tree"
      />
    </ControlledTreeEnvironment>
    </div>
  );
}

export default {
  render({ model, el }) {
    const host = document.createElement("div");
    el.appendChild(host);
    const shadow = host.attachShadow({ mode: "open" });

    const style = document.createElement("style");
    style.textContent = rctStyles + EXTRA_CSS;
    shadow.appendChild(style);

    const container = document.createElement("div");
    container.classList.add("anycomplextree");
    shadow.appendChild(container);

    const root = createRoot(container);
    root.render(<ComplexTree model={model} />);
    return () => {
      root.unmount();
      host.remove();
    };
  },
};
