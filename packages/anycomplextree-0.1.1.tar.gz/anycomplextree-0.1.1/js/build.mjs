import * as esbuild from "esbuild";

const watch = process.argv.includes("--watch");

const options = {
  entryPoints: ["src/widget.jsx"],
  bundle: true,
  format: "esm",
  outfile: "../anycomplextree/static/widget.js",
  loader: { ".css": "text" },
  jsx: "automatic",
  minify: !watch,
  sourcemap: watch,
  target: ["es2022"],
  logLevel: "info",
};

if (watch) {
  const ctx = await esbuild.context(options);
  await ctx.watch();
} else {
  await esbuild.build(options);
}
