import pathlib

import anywidget
import traitlets

_STATIC = pathlib.Path(__file__).parent / "static"


class ComplexTree(anywidget.AnyWidget):
    _esm = _STATIC / "widget.js"

    items = traitlets.Dict().tag(sync=True)
    root_item = traitlets.Unicode("root").tag(sync=True)
    selected_items = traitlets.List().tag(sync=True)
    expanded_items = traitlets.List().tag(sync=True)
    focused_item = traitlets.Unicode(None, allow_none=True).tag(sync=True)
    font_size = traitlets.Int(14).tag(sync=True)

    @traitlets.validate("items")
    def _validate_items(self, proposal):
        items = proposal["value"]
        if not isinstance(items, dict):
            raise traitlets.TraitError(
                f"items must be a dict, got {type(items).__name__}"
            )
        normalized: dict = {}
        for key, item in items.items():
            if not isinstance(item, dict):
                raise traitlets.TraitError(
                    f"items[{key!r}] must be a dict, got {type(item).__name__}"
                )
            if "index" not in item:
                item = {**item, "index": key}
            elif item["index"] != key:
                raise traitlets.TraitError(
                    f"items[{key!r}]['index'] is {item['index']!r} but must "
                    f"equal the dict key {key!r}. The dict key, 'index', and "
                    f"entries in parent 'children' arrays must all match."
                )
            normalized[key] = item
        for key, item in normalized.items():
            for child in item.get("children") or []:
                if child not in normalized:
                    raise traitlets.TraitError(
                        f"items[{key!r}]['children'] references {child!r}, "
                        f"which is not a key in items"
                    )
        return normalized

    @traitlets.validate("root_item")
    def _validate_root_item(self, proposal):
        root = proposal["value"]
        if self.items and root not in self.items:
            raise traitlets.TraitError(
                f"root_item {root!r} is not a key in items"
            )
        return root
