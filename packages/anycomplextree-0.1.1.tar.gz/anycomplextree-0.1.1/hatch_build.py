import os
import shutil
import subprocess
from pathlib import Path

from hatchling.builders.hooks.plugin.interface import BuildHookInterface

ROOT = Path(__file__).parent
JS_DIR = ROOT / "js"
BUNDLE = ROOT / "anycomplextree" / "static" / "widget.js"


class JsBuildHook(BuildHookInterface):
    PLUGIN_NAME = "anycomplextree-js"

    def initialize(self, version, build_data):
        if os.environ.get("ANYCOMPLEXTREE_SKIP_JS_BUILD"):
            return
        if shutil.which("npm") is None:
            if BUNDLE.exists():
                self.app.display_warning(
                    "npm not found; using existing bundled widget.js"
                )
                return
            raise RuntimeError(
                "npm is required to build the JS bundle and no prebuilt "
                "widget.js was found. Install Node.js or set "
                "ANYCOMPLEXTREE_SKIP_JS_BUILD=1 if you know what you're doing."
            )
        self.app.display_info(f"anycomplextree: installing JS deps in {JS_DIR}")
        subprocess.run(["npm", "install"], cwd=JS_DIR, check=True)
        self.app.display_info("anycomplextree: building JS bundle")
        subprocess.run(["npm", "run", "build"], cwd=JS_DIR, check=True)
        if not BUNDLE.exists():
            raise RuntimeError(f"JS build did not produce {BUNDLE}")
