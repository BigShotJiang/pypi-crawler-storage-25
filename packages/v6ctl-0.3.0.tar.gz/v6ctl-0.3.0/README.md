# v6ctl

The official CLI for the [v6Node](https://v6node.com) Reseller API.

Provision, manage, and script every reseller endpoint. Works interactively with Rich tables, or scripted with `--json` and proper exit codes.

```text
$ v6ctl nodes list
╭────────────────────────────── Nodes ──────────────────────────────╮
│ ID        Hostname      Region     Plan      OS          IP      │
│ a0fd028d  prod-web-1    Frankfurt  Standard  debian-13   5.1.2.3 │
│ b12c444e  staging-db    Frankfurt  Compute   ubuntu-24   5.1.2.4 │
╰───────────────────────────────────────────────────────────────────╯
```

## Install

```bash
pipx install v6ctl
```

### Don't have pipx?

```bash
# macOS
brew install pipx

# Debian / Ubuntu
sudo apt install pipx

# Everywhere else
python3 -m pip install --user pipx
python3 -m pipx ensurepath
```

Or use plain pip:

```bash
pip install v6ctl
```

## Configure

Get your API token from the [v6Node dashboard](https://cloud.v6node.com), then:

```bash
v6ctl config set token v6_...
```

Token is stored at `~/.config/v6ctl/config.json` with `0600` permissions.

Alternatively, set `V6_TOKEN` in your environment.

## Use

```bash
v6ctl nodes list                                # list your nodes
v6ctl nodes show <pay-id>                       # full details for a node
v6ctl nodes create -r frankfurt-2 -p 8gb -k laptop -t debian-13
v6ctl nodes create                              # run on a TTY → guided prompts
v6ctl nodes reboot <pay-id>
v6ctl nodes delete <pay-id>

v6ctl keys list                                 # list SSH keys
v6ctl keys create -d "laptop" -k "ssh-ed25519 AAAA..."

v6ctl webhooks create -u https://example.com/hook -e node.deployed

v6ctl plans                                     # available plans + pricing
v6ctl regions                                   # available regions
v6ctl templates                                 # available OS templates
```

Run `v6ctl --help` or `v6ctl <command> --help` for the full reference.

### Friendly `nodes create`

`--region`, `--plan`, and `--key` each accept a numeric ID, a short slug, a
full slug, or an exact name. Numeric inputs are looked up as an ID first; if
no such ID exists, the value falls through to a name/slug match so keys with
numeric descriptions remain reachable.

```bash
# All equivalent (assuming the IDs/slugs exist in your account):
v6ctl nodes create -r 7           -p 14              -k 3
v6ctl nodes create -r frankfurt-2 -p 8gb             -k laptop
v6ctl nodes create -r frankfurt-2 -p node-8gb-g2     -k laptop
v6ctl nodes create -r "Frankfurt 2" -p "Node 8GB G2" -k "My Laptop"
```

Run `v6ctl nodes create` on a terminal with any flag omitted and you'll be
prompted with the list of candidates. Omitting a flag in non-interactive
mode (pipe, CI) or with `--json` is an error — scripts stay fail-fast.

## JSON output

Every command supports `--json` for scripting:

```bash
v6ctl --json nodes list | jq '.items[].pay_id'
v6ctl --json plans       | jq '.[] | select(.memory_mb >= 4096)'
```

## Configuration

| Where | Precedence |
| --- | --- |
| `--flag` on the command line | 1 (highest) |
| Environment variable (`V6_TOKEN`, `V6_API_URL`) | 2 |
| Config file `~/.config/v6ctl/config.json` | 3 |
| Built-in defaults | 4 (lowest) |

```bash
v6ctl config show            # show resolved config (token redacted)
v6ctl config path            # print config file path
v6ctl config set api_url https://cloud.v6node.com/api/v1
v6ctl config unset token
```

## Requirements

- Python 3.10 or newer

## License

MIT — see [LICENSE](LICENSE).
