"""
v6ctl — command-line interface for the v6Node cloud platform.

Install:   pipx install v6ctl
Configure: v6ctl config set token <your-token>
Use:       v6ctl nodes list

Docs: https://github.com/v6Node/v6ctl
"""

from __future__ import annotations

import functools
import json as _json
import os
import re
import sys
from pathlib import Path
from typing import Any

import rich_click as click
import requests
from rich import box
from rich.console import Console
from rich.panel import Panel
from rich.pretty import Pretty
from rich.prompt import Prompt
from rich.table import Table
from rich.text import Text

click.rich_click.USE_RICH_MARKUP = True
click.rich_click.SHOW_ARGUMENTS = True
click.rich_click.GROUP_ARGUMENTS_OPTIONS = False
click.rich_click.STYLE_OPTION = "bold cyan"
click.rich_click.STYLE_ARGUMENT = "bold cyan"
click.rich_click.STYLE_COMMAND = "bold cyan"
click.rich_click.STYLE_SWITCH = "bold green"
click.rich_click.STYLE_METAVAR = "dim cyan"
click.rich_click.STYLE_HEADER_TEXT = "bold"
click.rich_click.STYLE_HELPTEXT = ""
click.rich_click.STYLE_HELPTEXT_FIRST_LINE = "bold"
click.rich_click.STYLE_OPTIONS_PANEL_BORDER = "dim"
click.rich_click.STYLE_COMMANDS_PANEL_BORDER = "dim"
click.rich_click.STYLE_USAGE = "bold yellow"
click.rich_click.MAX_WIDTH = 100

__version__ = "0.3.0"

DEFAULT_API_URL = "https://cloud.v6node.com/api/v1"

CONFIG_DIR = Path(os.environ.get("XDG_CONFIG_HOME", str(Path.home() / ".config"))) / "v6ctl"
CONFIG_FILE = CONFIG_DIR / "config.json"

WEBHOOK_EVENTS = [
    "node.deployed",
    "node.deploy_failed",
    "node.deleted",
    "node.rebuilt",
    "node.rebuild_failed",
    "snapshot.created",
    "snapshot.create_failed",
    "snapshot.rolled_back",
    "snapshot.deleted",
]

console = Console()
err_console = Console(stderr=True)


# ═══════════════════════════════════════════════════════════
#  Config
# ═══════════════════════════════════════════════════════════


def load_config() -> dict:
    """Config precedence: env vars > config file > defaults."""
    cfg: dict[str, Any] = {"api_url": DEFAULT_API_URL}
    if CONFIG_FILE.exists():
        try:
            cfg.update(_json.loads(CONFIG_FILE.read_text()))
        except _json.JSONDecodeError:
            pass

    if tok := (os.environ.get("V6_TOKEN") or os.environ.get("API_TOKEN")):
        cfg["token"] = tok
    if url := (os.environ.get("V6_API_URL") or os.environ.get("API_URL")):
        cfg["api_url"] = url

    return cfg


def save_config(cfg: dict) -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_FILE.write_text(_json.dumps(cfg, indent=2) + "\n")
    CONFIG_FILE.chmod(0o600)


# ═══════════════════════════════════════════════════════════
#  API Client
# ═══════════════════════════════════════════════════════════


class V6Error(Exception):
    def __init__(self, status: int, code: str, message: str):
        self.status = status
        self.code = code
        self.message = message
        super().__init__(f"[{code}] {message}")


class V6Client:
    def __init__(self, base_url: str, token: str):
        self.base_url = base_url.rstrip("/")
        self.session = requests.Session()
        self.session.headers.update(
            {
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/json",
                "Accept": "application/json",
                "User-Agent": f"v6ctl/{__version__}",
            }
        )

    def _request(self, method: str, path: str, body: dict | None = None):
        url = f"{self.base_url}/{path.lstrip('/')}"
        try:
            resp = self.session.request(
                method, url, data=_json.dumps(body) if body else None, timeout=30
            )
        except requests.RequestException as e:
            raise V6Error(0, "NETWORK_ERROR", str(e)) from e

        if resp.status_code == 204:
            return None

        try:
            data = resp.json()
        except ValueError:
            raise V6Error(resp.status_code, "BAD_RESPONSE", resp.text[:200])

        if not resp.ok:
            if isinstance(data, dict):
                base = data.get("error") or data.get("message") or str(data)[:200]
                code = data.get("code") or (
                    "VALIDATION_ERROR" if resp.status_code == 422 else "ERROR"
                )
                fields = data.get("errors")
                if isinstance(fields, dict) and fields:
                    detail = "; ".join(
                        f"{k}: {', '.join(v) if isinstance(v, list) else v}"
                        for k, v in fields.items()
                    )
                    message = f"{base} — {detail}" if base else detail
                else:
                    message = base
                raise V6Error(resp.status_code, code, message)
            raise V6Error(resp.status_code, "UNKNOWN", str(data)[:200])

        if isinstance(data, dict) and "data" in data:
            result = data["data"]
            if "meta" in data:
                result = {"items": result, "meta": data["meta"]}
            return result
        return data

    def _get(self, path):
        return self._request("GET", path)

    def _post(self, path, body=None):
        return self._request("POST", path, body)

    def _patch(self, path, body=None):
        return self._request("PATCH", path, body)

    def _delete(self, path):
        return self._request("DELETE", path)

    # ── SSH Keys ─────────────────────────────────────────

    def keys_list(self):
        return self._get("keys")

    def keys_create(self, description, pubkey):
        return self._post("keys", {"description": description, "pubkey": pubkey})

    def keys_delete(self, key_id):
        return self._delete(f"keys/{key_id}")

    # ── Nodes ────────────────────────────────────────────

    def nodes_list(self):
        return self._get("nodes")

    def nodes_show(self, pay_id):
        return self._get(f"nodes/{pay_id}")

    def nodes_create(self, *, region_id, plan_id, key_id, hostname=None, template=None, flavor_id=None, additional_address=None):
        body = {"region_id": region_id, "plan_id": plan_id, "key_id": key_id}
        if hostname:
            body["hostname"] = hostname
        if template:
            body["template"] = template
        if flavor_id:
            body["flavor_id"] = flavor_id
        if additional_address:
            body["additional_address"] = additional_address
        return self._post("nodes", body)

    def nodes_update(self, pay_id, *, hostname=None, description=None, key_id=None, project_id=None):
        body: dict[str, Any] = {}
        if hostname is not None:
            body["hostname"] = hostname
        if description is not None:
            body["description"] = description
        if key_id is not None:
            body["key_id"] = key_id
        if project_id is not None:
            body["project_id"] = project_id
        return self._patch(f"nodes/{pay_id}", body)

    def nodes_delete(self, pay_id):
        return self._delete(f"nodes/{pay_id}")

    def nodes_power(self, pay_id, action):
        return self._post(f"nodes/{pay_id}/{action}")

    def nodes_status(self, pay_id):
        return self._get(f"nodes/{pay_id}/status")

    def nodes_rebuild(self, pay_id, *, template=None, flavor_id=None):
        body: dict[str, Any] = {}
        if template:
            body["template"] = template
        if flavor_id:
            body["flavor_id"] = flavor_id
        return self._post(f"nodes/{pay_id}/rebuild", body)

    def nodes_password(self, pay_id):
        return self._post(f"nodes/{pay_id}/password")

    def nodes_addresses(self, pay_id):
        return self._get(f"nodes/{pay_id}/addresses")

    def nodes_stats(self, pay_id, timerange):
        return self._get(f"nodes/{pay_id}/stats/{timerange}")

    def nodes_activity(self, pay_id):
        return self._get(f"nodes/{pay_id}/activity")

    # ── Webhooks ─────────────────────────────────────────

    def webhooks_list(self):
        return self._get("webhooks")

    def webhooks_create(self, url, events):
        return self._post("webhooks", {"url": url, "events": events})

    def webhooks_update(self, webhook_id, *, url=None, enabled=None, events=None):
        body: dict[str, Any] = {}
        if url is not None:
            body["url"] = url
        if enabled is not None:
            body["enabled"] = enabled
        if events is not None:
            body["events"] = events
        return self._patch(f"webhooks/{webhook_id}", body)

    def webhooks_delete(self, webhook_id):
        return self._delete(f"webhooks/{webhook_id}")

    def webhooks_test(self, webhook_id):
        return self._post(f"webhooks/{webhook_id}/test")

    def webhooks_deliveries(self, webhook_id):
        return self._get(f"webhooks/{webhook_id}/deliveries")

    # ── Reference (read-only) ────────────────────────────

    def plans(self):
        return self._get("plans")

    def regions(self):
        return self._get("regions")

    def templates(self):
        return self._get("templates")


# ═══════════════════════════════════════════════════════════
#  Output — Rich renderers with --json fallback
# ═══════════════════════════════════════════════════════════


STATUS_COLORS = {
    "running": "green",
    "stopped": "red",
    "deploying": "yellow",
    "deleting": "yellow",
    "rebuilding": "yellow",
    "queued": "yellow",
    "locked": "red",
}


def _is_json() -> bool:
    ctx = click.get_current_context(silent=True)
    return bool(ctx and ctx.obj and ctx.obj.get("json"))


def _render(data: Any, renderer):
    """Emit JSON if --json is set, otherwise invoke the Rich renderer."""
    if _is_json():
        click.echo(_json.dumps(data, indent=2, default=str))
    else:
        renderer(data)


def _format_status(s: str) -> Text:
    return Text(s, style=f"bold {STATUS_COLORS.get(s, 'dim')}")


def _human_bytes(b) -> str:
    try:
        b = int(b)
    except (ValueError, TypeError):
        return str(b)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if abs(b) < 1024:
            return f"{b:.1f} {unit}" if unit != "B" else f"{b} {unit}"
        b /= 1024
    return f"{b:.1f} PB"


def _human_uptime(seconds) -> str:
    try:
        s = int(seconds)
    except (ValueError, TypeError):
        return str(seconds)
    days, s = divmod(s, 86400)
    hours, s = divmod(s, 3600)
    mins, _ = divmod(s, 60)
    parts = []
    if days:
        parts.append(f"{days}d")
    if hours:
        parts.append(f"{hours}h")
    parts.append(f"{mins}m")
    return " ".join(parts)


def _short_date(dt) -> str:
    return dt[:10] if dt and len(dt) >= 10 else (dt or "")


def print_success(msg: str):
    console.print(f"[bold green]✓[/bold green] {msg}")


def print_error(msg: str):
    err_console.print(f"[bold red]✗[/bold red] {msg}")


def print_raw(data):
    _render(data, lambda d: console.print(Pretty(d)))


# ── Keys ─────────────────────────────────────────────────


def _print_keys(keys):
    if not keys:
        console.print("[dim]No SSH keys found.[/dim]")
        return
    t = Table(title="SSH Keys", box=box.SIMPLE_HEAD, header_style="bold")
    t.add_column("ID", style="cyan", justify="right")
    t.add_column("Description")
    t.add_column("Created", style="dim")
    for k in keys:
        t.add_row(str(k["id"]), k.get("description", ""), k.get("created_at", ""))
    console.print(t)


def _print_key(key):
    console.print(
        Panel(
            f"[bold cyan]ID:[/bold cyan] {key['id']}\n"
            f"[bold]Description:[/bold] {key.get('description', '')}\n"
            f"[dim]Created:[/dim] {key.get('created_at', '')}",
            title="SSH Key",
            border_style="green",
            box=box.ROUNDED,
        )
    )


# ── Nodes ────────────────────────────────────────────────


def _print_nodes(data, all_ips: bool = False):
    items = data.get("items", data) if isinstance(data, dict) else data
    meta = data.get("meta") if isinstance(data, dict) else None
    if not items:
        console.print("[dim]No nodes found.[/dim]")
        return

    t = Table(title="Nodes", box=box.SIMPLE_HEAD, header_style="bold")
    for col, style, no_wrap in [
        ("ID", "cyan", True),
        ("Hostname", "", True),
        ("Region", "", True),
        ("Plan", "", True),
        ("OS", "", True),
        ("IP", "green", not all_ips),
        ("Created", "dim", True),
    ]:
        t.add_column(col, style=style, no_wrap=no_wrap)

    for n in items:
        region = n.get("region") or {}
        plan = n.get("plan") or {}
        region_str = region.get("title", "") if isinstance(region, dict) else str(region)
        plan_str = plan.get("title", "") if isinstance(plan, dict) else str(plan)
        addresses = n.get("addresses") or []
        ips = [a["ip"] for a in addresses if a.get("ip")]
        if all_ips:
            ip_str = "\n".join(ips)
        elif len(ips) <= 2:
            ip_str = ", ".join(ips)
        else:
            ip_str = ", ".join(ips[:2]) + f" [dim](+{len(ips) - 2})[/dim]"
        locked = " [red]LOCKED[/red]" if n.get("is_locked") else ""
        t.add_row(
            n.get("pay_id", ""),
            (n.get("hostname") or "") + locked,
            region_str,
            plan_str,
            n.get("template", ""),
            ip_str,
            _short_date(n.get("created_at", "")),
        )
    console.print(t)
    if meta:
        console.print(
            f"[dim]Page {meta.get('current_page')} of {meta.get('last_page')} "
            f"({meta.get('total')} total)[/dim]"
        )


def _print_node(node, status=None, activity=None):
    lines = []

    def add(label, value, style="white"):
        if value is not None and value != "":
            lines.append(f"[bold]{label}:[/bold] [{style}]{value}[/{style}]")

    add("Pay ID", node.get("pay_id"), "cyan")
    add("Hostname", node.get("hostname"))
    add("Description", node.get("description"))

    region = node.get("region") or {}
    add("Region", region.get("title") if isinstance(region, dict) else region)

    plan = node.get("plan") or {}
    if isinstance(plan, dict):
        add(
            "Plan",
            f"{plan.get('title', '')} "
            f"({plan.get('cores', '?')} cores, "
            f"{plan.get('memory_mb', '?')} MB, "
            f"{plan.get('disk_gb', '?')} GB)",
        )
    add("Template", node.get("template"))

    flavor = node.get("flavor") or {}
    if isinstance(flavor, dict) and flavor.get("title"):
        add("Flavor", flavor.get("title"))

    for a in node.get("addresses") or []:
        primary = " (primary)" if a.get("primary") else ""
        lines.append(
            f"[bold]IP:[/bold] [green]{a['ip']}[/green] "
            f"{a.get('type', '')}/{a.get('routing', '')}{primary}"
        )

    if node.get("is_locked"):
        lines.append("[bold red]LOCKED[/bold red]")
    if node.get("requires_reboot"):
        lines.append("[bold yellow]REQUIRES REBOOT[/bold yellow]")

    add("Created", node.get("created_at"), "dim")

    console.print(
        Panel(
            "\n".join(lines),
            title=f"Node {node.get('pay_id', '')}",
            border_style="cyan",
            box=box.ROUNDED,
        )
    )

    if status and isinstance(status, dict):
        _print_node_status(status)

    if activity and isinstance(activity, list):
        t = Table(title="Recent Activity", box=box.SIMPLE_HEAD, header_style="bold")
        t.add_column("Date", style="dim", no_wrap=True)
        t.add_column("Subject")
        t.add_column("Action", style="cyan")
        for entry in activity[:5]:
            t.add_row(
                _short_date(entry.get("created_at", "")),
                entry.get("subject", ""),
                entry.get("description", ""),
            )
        console.print(t)


def _print_node_status(status):
    mem = status.get("memory", {})
    disk = status.get("disk", {})
    try:
        cpu_pct = f"{float(status.get('cpu', 0)) * 100:.1f}%"
    except (ValueError, TypeError):
        cpu_pct = str(status.get("cpu", "N/A"))

    lines = [
        f"[bold]State:[/bold] {_format_status(status.get('state', 'unknown'))}",
        f"[bold]Uptime:[/bold] {_human_uptime(status.get('uptime', 'N/A'))}",
        f"[bold]CPU:[/bold] {cpu_pct}",
        f"[bold]Memory:[/bold] {_human_bytes(mem.get('used', '?'))} / {_human_bytes(mem.get('total', '?'))}",
        f"[bold]Disk:[/bold] {_human_bytes(disk.get('used', '?'))} / {_human_bytes(disk.get('total', '?'))}",
    ]
    console.print(
        Panel(
            "\n".join(lines),
            title="Node Status",
            border_style="cyan",
            box=box.ROUNDED,
        )
    )


def _print_addresses(addresses):
    if not addresses:
        console.print("[dim]No addresses found.[/dim]")
        return
    t = Table(title="IP Addresses", box=box.SIMPLE_HEAD, header_style="bold")
    t.add_column("ID", style="cyan", justify="right")
    t.add_column("IP", style="green")
    t.add_column("Type")
    t.add_column("Range")
    t.add_column("Primary", justify="center")
    t.add_column("Routing", style="dim")
    for a in addresses:
        primary = "[green]Yes[/green]" if a.get("primary") else "[dim]No[/dim]"
        t.add_row(
            str(a["id"]),
            a["ip"],
            a.get("type", ""),
            a.get("range", ""),
            primary,
            a.get("routing", ""),
        )
    console.print(t)


def _print_action(data, title="Action"):
    lines = []
    for k, v in (data or {}).items():
        if k == "status":
            lines.append(f"[bold]{k}:[/bold] {_format_status(str(v))}")
        else:
            lines.append(f"[bold]{k}:[/bold] {v}")
    console.print(
        Panel("\n".join(lines), title=title, border_style="yellow", box=box.ROUNDED)
    )


def _print_password(password):
    console.print(
        Panel(
            f"[bold yellow]{password}[/bold yellow]",
            title="Root Password",
            subtitle="[dim]Save this — it won't be shown again[/dim]",
            border_style="yellow",
            box=box.HEAVY,
        )
    )


# ── Webhooks ─────────────────────────────────────────────


def _print_webhooks(webhooks):
    items = webhooks if isinstance(webhooks, list) else [webhooks]
    if not items:
        console.print("[dim]No webhooks found.[/dim]")
        return
    t = Table(title="Webhooks", box=box.SIMPLE_HEAD, header_style="bold")
    t.add_column("ID", style="cyan", justify="right")
    t.add_column("URL")
    t.add_column("Events")
    t.add_column("Enabled", justify="center")
    t.add_column("Approved", justify="center")
    t.add_column("Created", style="dim")
    for w in items:
        events = w.get("events", "")
        if isinstance(events, list):
            events = ", ".join(events)
        enabled = "[green]Yes[/green]" if w.get("enabled") in (True, "true", 1, "1") else "[red]No[/red]"
        approved = "[green]Yes[/green]" if w.get("approved") in (True, "true", 1, "1") else "[yellow]Pending[/yellow]"
        t.add_row(
            str(w.get("id", "")),
            str(w.get("url", "")),
            str(events),
            enabled,
            approved,
            str(w.get("created_at", "")),
        )
    console.print(t)


def _print_webhook(webhook):
    events = webhook.get("events", "")
    if isinstance(events, list):
        events = ", ".join(events)
    console.print(
        Panel(
            f"[bold cyan]ID:[/bold cyan] {webhook.get('id')}\n"
            f"[bold]URL:[/bold] {webhook.get('url')}\n"
            f"[bold]Events:[/bold] {events}\n"
            f"[bold]Enabled:[/bold] {webhook.get('enabled')}\n"
            f"[bold]Approved:[/bold] {webhook.get('approved')}\n"
            f"[dim]Created:[/dim] {webhook.get('created_at', '')}",
            title="Webhook",
            border_style="cyan",
            box=box.ROUNDED,
        )
    )


# ── Reference ────────────────────────────────────────────


def _print_plans(plans):
    t = Table(title="Plans", box=box.SIMPLE_HEAD, header_style="bold")
    t.add_column("ID", style="cyan", justify="right")
    t.add_column("Name")
    t.add_column("Cores", justify="right")
    t.add_column("Memory", justify="right")
    t.add_column("Disk", justify="right")
    t.add_column("Traffic", justify="right")
    t.add_column("Monthly", justify="right", style="green")
    t.add_column("Annual", justify="right", style="dim")
    for p in plans:
        monthly = p.get("price_monthly")
        annual = p.get("price_annual")
        t.add_row(
            str(p.get("id", "")),
            p.get("title", ""),
            str(p.get("cores", "")),
            f"{p.get('memory_mb', 0)} MB",
            f"{p.get('disk_gb', 0)} GB",
            f"{p.get('traffic_gb', 0)} GB",
            f"{monthly / 100:.2f}€" if monthly else "",
            f"{annual / 100:.2f}€" if annual else "",
        )
    console.print(t)


def _print_regions(regions):
    t = Table(title="Regions", box=box.SIMPLE_HEAD, header_style="bold")
    t.add_column("ID", style="cyan", justify="right")
    t.add_column("Name")
    t.add_column("Available", justify="center")
    t.add_column("Templates", style="dim")
    for r in regions:
        avail = "[green]Yes[/green]" if r.get("available") else "[red]No[/red]"
        templates = ", ".join(r.get("templates", []))
        t.add_row(str(r.get("id", "")), r.get("title", ""), avail, templates)
    console.print(t)


def _print_templates(templates):
    # Grouped shape: [{family, label, versions: [...]}]
    if isinstance(templates, list) and templates and "versions" in templates[0]:
        t = Table(title="OS Templates", box=box.SIMPLE_HEAD, header_style="bold")
        t.add_column("Family", style="bold")
        t.add_column("ID", style="cyan", justify="right")
        t.add_column("Slug")
        t.add_column("Title")
        t.add_column("Version", style="dim")
        t.add_column("LTS", justify="center")
        for fam in templates:
            for i, v in enumerate(fam.get("versions", [])):
                lts = "[green]Yes[/green]" if v.get("lts") else "[dim]No[/dim]"
                t.add_row(
                    fam.get("label", "") if i == 0 else "",
                    str(v.get("id", "")),
                    v.get("template", ""),
                    v.get("title", ""),
                    v.get("version", ""),
                    lts,
                )
        console.print(t)
    elif isinstance(templates, list) and templates and isinstance(templates[0], dict):
        t = Table(title="Templates", box=box.SIMPLE_HEAD, header_style="bold")
        t.add_column("ID", style="cyan", justify="right")
        t.add_column("Title")
        t.add_column("Slug", style="dim")
        for tpl in templates:
            t.add_row(
                str(tpl.get("id", "")),
                tpl.get("title", ""),
                tpl.get("slug", tpl.get("template", "")),
            )
        console.print(t)
    else:
        console.print(Pretty(templates))


# ═══════════════════════════════════════════════════════════
#  Resolvers — accept ID, slug, or name for --region/--plan/--key
# ═══════════════════════════════════════════════════════════


def _slugify(s: str) -> str:
    """Normalize to lowercase kebab-case. Used for both input matching and slug generation."""
    s = (s or "").strip().lower()
    s = re.sub(r"\s+", "-", s)
    return s


def _plan_short_slug(p: dict) -> str | None:
    """{memory_mb/1024}gb, but only for whole-GB plans ≥1 GB. Otherwise None."""
    mb = p.get("memory_mb") or 0
    if mb >= 1024 and mb % 1024 == 0:
        return f"{mb // 1024}gb"
    return None


def _format_candidates(kind: str, candidates: list, rows) -> str:
    """Build the multi-line candidate listing appended to error messages."""
    lines = [f"  Available {kind}s:"]
    for text in rows:
        lines.append(f"    {text}")
    return "\n" + "\n".join(lines)


def _match_one(value: str, candidates: list, tiers: list):
    """
    Walk match tiers against a normalized value.
    tiers: list of functions (candidate -> str | None) — None skips that candidate in that tier.
    Returns (matched_candidate_or_list, status) where status is "unique" | "ambiguous" | "none".
    ID tier is built-in and runs first: if value parses as a positive int and matches a candidate's id, win.
    If int-parse succeeds but no id matches, fall through to the other tiers (does NOT short-circuit).
    """
    try:
        as_id = int(value)
        if as_id > 0:
            for c in candidates:
                if c.get("id") == as_id:
                    return c, "unique"
    except ValueError:
        pass

    for tier_fn in tiers:
        hits = [c for c in candidates if tier_fn(c) == value]
        if len(hits) == 1:
            return hits[0], "unique"
        if len(hits) > 1:
            return hits, "ambiguous"

    return None, "none"


def _is_interactive() -> bool:
    """A prompt should fire: TTY on both streams, and --json is not set."""
    ctx = click.get_current_context(silent=True)
    json_mode = bool(ctx and ctx.obj and ctx.obj.get("json"))
    return sys.stdin.isatty() and sys.stdout.isatty() and not json_mode


def _prompt_id(label: str, valid_ids: list[int]) -> int:
    """Prompt for an ID, retry up to 3 times, honor Ctrl-C/Ctrl-D."""
    for _ in range(3):
        try:
            raw = Prompt.ask(f"[bold cyan]{label} ID[/bold cyan]")
        except KeyboardInterrupt:
            err_console.print("[yellow]Aborted.[/yellow]")
            sys.exit(130)
        except EOFError:
            err_console.print("[yellow]Aborted (EOF).[/yellow]")
            sys.exit(1)
        raw = (raw or "").strip()
        try:
            chosen = int(raw)
        except ValueError:
            err_console.print(f"[red]Not a number: {raw!r}[/red]")
            continue
        if chosen in valid_ids:
            return chosen
        err_console.print(f"[red]Invalid {label.lower()} ID: {chosen}[/red]")
    raise V6Error(422, f"INVALID_{label.upper()}", f"Too many invalid attempts for {label.lower()} ID.")


# ── region ──────────────────────────────────────────────


def _resolve_region(client, value: str | None) -> int:
    if value is None:
        if not _is_interactive():
            raise V6Error(422, "MISSING_ARGUMENT", "Missing option '-r' / '--region'.")
        return _prompt_region(client)

    normalized = _slugify(value)
    regions = client.regions() or []
    result, status = _match_one(
        normalized,
        regions,
        tiers=[
            lambda r: _slugify(r.get("title", "")),  # short slug
            lambda r: (r.get("title", "") or "").strip().lower(),  # title
        ],
    )

    if status == "none":
        rows = [
            f"{_slugify(r.get('title', '')):20s} (id={r['id']}{'' if r.get('available') else ', unavailable'})"
            for r in regions
        ]
        raise V6Error(
            422,
            "INVALID_REGION",
            f'No region matches "{value}"' + _format_candidates("region", regions, rows),
        )
    if status == "ambiguous":
        rows = [f"{_slugify(r.get('title', '')):20s} (id={r['id']})" for r in result]
        raise V6Error(
            422,
            "AMBIGUOUS_REGION",
            f'"{value}" matches multiple regions' + _format_candidates("region", result, rows),
        )
    if not result.get("available"):
        raise V6Error(
            422,
            "REGION_UNAVAILABLE",
            f'Region "{result.get("title")}" (id={result["id"]}) is not available for deployment.',
        )
    return result["id"]


def _prompt_region(client) -> int:
    regions = client.regions() or []
    available = [r for r in regions if r.get("available")]
    if not available:
        raise V6Error(422, "NO_REGIONS", "No regions are currently available for deployment.")
    if len(available) == 1:
        r = available[0]
        err_console.print(f"[dim]Using region: {r.get('title')} (id={r['id']})[/dim]")
        return r["id"]
    _print_regions(available)
    return _prompt_id("Region", [r["id"] for r in available])


# ── plan ────────────────────────────────────────────────


def _resolve_plan(client, value: str | None) -> int:
    if value is None:
        if not _is_interactive():
            raise V6Error(422, "MISSING_ARGUMENT", "Missing option '-p' / '--plan'.")
        return _prompt_plan(client)

    normalized = _slugify(value)
    plans = client.plans() or []
    result, status = _match_one(
        normalized,
        plans,
        tiers=[
            _plan_short_slug,  # {n}gb, or None
            lambda p: _slugify(p.get("title", "")),  # full slug
            lambda p: (p.get("title", "") or "").strip().lower(),  # title
        ],
    )

    if status == "none":
        rows = [
            f"{_plan_short_slug(p) or '—':6s} {_slugify(p.get('title', '')):18s} (id={p['id']})"
            for p in plans
        ]
        raise V6Error(
            422,
            "INVALID_PLAN",
            f'No plan matches "{value}"' + _format_candidates("plan", plans, rows),
        )
    if status == "ambiguous":
        rows = [f"{_slugify(p.get('title', '')):18s} (id={p['id']})" for p in result]
        raise V6Error(
            422,
            "AMBIGUOUS_PLAN",
            f'"{value}" matches multiple plans' + _format_candidates("plan", result, rows),
        )
    return result["id"]


def _prompt_plan(client) -> int:
    plans = client.plans() or []
    if not plans:
        raise V6Error(422, "NO_PLANS", "No plans are available.")
    _print_plans(plans)
    return _prompt_id("Plan", [p["id"] for p in plans])


# ── SSH key ─────────────────────────────────────────────


def _resolve_key(client, value: str | None) -> int:
    if value is None:
        if not _is_interactive():
            raise V6Error(422, "MISSING_ARGUMENT", "Missing option '-k' / '--key'.")
        return _prompt_key(client)

    normalized = _slugify(value)
    keys = client.keys_list() or []
    result, status = _match_one(
        normalized,
        keys,
        tiers=[
            lambda k: _slugify(k.get("description", "")),
            lambda k: (k.get("description", "") or "").strip().lower(),
        ],
    )

    if status == "none":
        rows = [f"{_slugify(k.get('description', '')):20s} (id={k['id']})" for k in keys]
        raise V6Error(
            422,
            "INVALID_KEY",
            f'No SSH key matches "{value}"' + _format_candidates("key", keys, rows),
        )
    if status == "ambiguous":
        rows = [f"{_slugify(k.get('description', '')):20s} (id={k['id']})" for k in result]
        raise V6Error(
            422,
            "AMBIGUOUS_KEY",
            f'"{value}" matches multiple keys' + _format_candidates("key", result, rows),
        )
    return result["id"]


def _prompt_key(client) -> int:
    keys = client.keys_list() or []
    if not keys:
        raise V6Error(
            422,
            "NO_KEYS",
            "No SSH keys found. Add one with: v6ctl keys create -d <label> -k <pubkey>",
        )
    if len(keys) == 1:
        k = keys[0]
        err_console.print(f"[dim]Using SSH key: {k.get('description')} (id={k['id']})[/dim]")
        return k["id"]
    _print_keys(keys)
    return _prompt_id("Key", [k["id"] for k in keys])


# ── template ───────────────────────────────────────────


def _prompt_template(client, region_id: int) -> str | None:
    """Prompt for a template slug from the region's allowed list."""
    regions = client.regions() or []
    region = next((r for r in regions if r.get("id") == region_id), None)
    templates = (region or {}).get("templates") or []
    if not templates:
        return None  # no templates exposed — let the API decide

    console.print("\n[bold]Available templates:[/bold]")
    for i, slug in enumerate(templates, 1):
        console.print(f"  [cyan]{i:2d}.[/cyan] {slug}")

    default = "debian-13" if "debian-13" in templates else templates[0]
    lower_map = {t.lower(): t for t in templates}

    for _ in range(3):
        try:
            raw = Prompt.ask("[bold cyan]Template[/bold cyan]", default=default)
        except KeyboardInterrupt:
            err_console.print("[yellow]Aborted.[/yellow]")
            sys.exit(130)
        except EOFError:
            err_console.print("[yellow]Aborted (EOF).[/yellow]")
            sys.exit(1)
        raw = (raw or "").strip()
        try:
            idx = int(raw)
            if 1 <= idx <= len(templates):
                return templates[idx - 1]
        except ValueError:
            pass
        if raw.lower() in lower_map:
            return lower_map[raw.lower()]
        err_console.print(f"[red]Invalid template: {raw!r}[/red]")
    raise V6Error(422, "INVALID_TEMPLATE", "Too many invalid attempts for template.")


# ═══════════════════════════════════════════════════════════
#  Click CLI
# ═══════════════════════════════════════════════════════════


def handle_errors(fn):
    @functools.wraps(fn)
    def wrapper(*args, **kwargs):
        try:
            return fn(*args, **kwargs)
        except V6Error as e:
            if _is_json():
                click.echo(
                    _json.dumps(
                        {"error": e.message, "code": e.code, "status": e.status}, indent=2
                    ),
                    err=True,
                )
            else:
                # Multi-line messages (resolver candidate lists): keep (code) on the first line
                # so the list below stays visually clean.
                if "\n" in e.message:
                    first, _, rest = e.message.partition("\n")
                    print_error(f"{first} ({e.code})")
                    err_console.print(rest)
                else:
                    print_error(f"{e.message} ({e.code})")
            sys.exit(1)

    return wrapper


def require_client(ctx):
    """Ensure a configured client is present; error with guidance if not."""
    client = ctx.obj.get("client")
    if client is None:
        print_error(
            "No API token configured. Run: [bold]v6ctl config set token <your-token>[/bold]"
        )
        sys.exit(2)
    return client


pass_client = click.make_pass_decorator(dict, ensure=True)


CONTEXT_SETTINGS = {"help_option_names": ["-h", "--help"]}


@click.group(context_settings=CONTEXT_SETTINGS)
@click.option("--json", "output_json", is_flag=True, help="Output JSON instead of formatted tables.")
@click.version_option(__version__, "-V", "--version", prog_name="v6ctl")
@click.pass_context
def cli(ctx, output_json):
    """v6ctl — manage v6Node cloud resources.

    \b
    Get started:
      v6ctl config set token <your-token>
      v6ctl nodes list

    \b
    Environment variables (override config file):
      V6_TOKEN      API token
      V6_API_URL    API base URL (default: {default_url})

    Docs: https://github.com/v6Node/v6ctl
    """
    cfg = load_config()
    ctx.ensure_object(dict)
    ctx.obj["json"] = output_json
    ctx.obj["config"] = cfg

    # `config` subcommands don't need a live client
    if ctx.invoked_subcommand == "config":
        ctx.obj["client"] = None
        return

    token = cfg.get("token")
    api_url = cfg.get("api_url", DEFAULT_API_URL)

    if not token:
        ctx.obj["client"] = None
    else:
        ctx.obj["client"] = V6Client(api_url, token)


cli.help = cli.help.format(default_url=DEFAULT_API_URL)


# ═══════════════════════════════════════════════════════════
#  config
# ═══════════════════════════════════════════════════════════


@cli.group(invoke_without_command=True)
@click.pass_context
def config(ctx):
    """Manage local configuration (token, API URL)."""
    if ctx.invoked_subcommand is None:
        ctx.invoke(config_show)


@config.command("set")
@click.argument("key", type=click.Choice(["token", "api_url"]))
@click.argument("value")
def config_set(key, value):
    """Set a config value (token, api_url)."""
    cfg = {}
    if CONFIG_FILE.exists():
        try:
            cfg = _json.loads(CONFIG_FILE.read_text())
        except _json.JSONDecodeError:
            pass
    cfg[key] = value
    save_config(cfg)
    print_success(f"Set [bold]{key}[/bold] → saved to {CONFIG_FILE}")


@config.command("unset")
@click.argument("key", type=click.Choice(["token", "api_url"]))
def config_unset(key):
    """Remove a config value."""
    if not CONFIG_FILE.exists():
        print_error(f"No config file at {CONFIG_FILE}")
        sys.exit(1)
    cfg = _json.loads(CONFIG_FILE.read_text())
    cfg.pop(key, None)
    save_config(cfg)
    print_success(f"Unset [bold]{key}[/bold]")


@config.command("show")
@click.pass_context
def config_show(ctx):
    """Show resolved configuration."""
    cfg = dict(ctx.obj["config"])
    if tok := cfg.get("token"):
        cfg["token"] = tok[:8] + "…" + tok[-4:] if len(tok) > 12 else "***"
    if _is_json():
        click.echo(_json.dumps(cfg, indent=2))
    else:
        console.print(
            Panel(
                "\n".join(f"[bold]{k}:[/bold] {v}" for k, v in cfg.items()) or "[dim]empty[/dim]",
                title="v6ctl config",
                subtitle=f"[dim]{CONFIG_FILE}[/dim]",
                border_style="cyan",
                box=box.ROUNDED,
            )
        )


@config.command("path")
def config_path():
    """Print the path to the config file."""
    click.echo(str(CONFIG_FILE))


# ═══════════════════════════════════════════════════════════
#  keys
# ═══════════════════════════════════════════════════════════


@cli.group(invoke_without_command=True)
@click.pass_context
def keys(ctx):
    """Manage SSH keys."""
    if ctx.invoked_subcommand is None:
        ctx.invoke(keys_list)


@keys.command("list")
@click.pass_context
@handle_errors
def keys_list(ctx):
    """List all SSH keys."""
    client = require_client(ctx)
    _render(client.keys_list(), _print_keys)


@keys.command("create")
@click.option("-d", "--description", required=True, help="Label for this key.")
@click.option("-k", "--pubkey", required=True, help="SSH public key string.")
@click.pass_context
@handle_errors
def keys_create(ctx, description, pubkey):
    """Add a new SSH key."""
    client = require_client(ctx)
    _render(client.keys_create(description, pubkey), _print_key)


@keys.command("delete")
@click.argument("key_id", type=int)
@click.option("-y", "--yes", is_flag=True, help="Skip confirmation.")
@click.pass_context
@handle_errors
def keys_delete(ctx, key_id, yes):
    """Delete an SSH key by ID."""
    client = require_client(ctx)
    if not yes:
        click.confirm(f"Delete SSH key {key_id}?", abort=True)
    client.keys_delete(key_id)
    print_success(f"Key {key_id} deleted.")


# ═══════════════════════════════════════════════════════════
#  nodes
# ═══════════════════════════════════════════════════════════


class NodeGroup(click.RichGroup):
    """Route unknown positional args to `show` so `nodes <pay_id>` just works."""

    def resolve_command(self, ctx, args):
        try:
            return super().resolve_command(ctx, args)
        except click.UsageError:
            if args and not args[0].startswith("-"):
                return super().resolve_command(ctx, ["show"] + args)
            raise


@cli.group(cls=NodeGroup, invoke_without_command=True)
@click.option("-A", "--all-ips", is_flag=True, help="Show every IP address per node (default: up to 2).")
@click.pass_context
def nodes(ctx, all_ips):
    """Manage VPS nodes."""
    if ctx.invoked_subcommand is None:
        ctx.invoke(nodes_list, all_ips=all_ips)


@nodes.command("list")
@click.option("-A", "--all-ips", is_flag=True, help="Show every IP address per node (default: up to 2).")
@click.pass_context
@handle_errors
def nodes_list(ctx, all_ips):
    """List all nodes."""
    client = require_client(ctx)
    _render(client.nodes_list(), lambda d: _print_nodes(d, all_ips=all_ips))


@nodes.command("show")
@click.argument("pay_id")
@click.pass_context
@handle_errors
def nodes_show(ctx, pay_id):
    """Show details for a node."""
    client = require_client(ctx)
    data = client.nodes_show(pay_id)

    if _is_json() or not isinstance(data, dict):
        _render(data, _print_node)
        return

    status = activity = None
    try:
        status = client.nodes_status(pay_id)
    except V6Error:
        pass
    try:
        activity = client.nodes_activity(pay_id)
    except V6Error:
        pass
    _print_node(data, status=status, activity=activity)


@nodes.command("create")
@click.option(
    "-r", "--region", "region", default=None, type=str,
    help='Region ID, slug, or name (e.g. 7, frankfurt-2, "Frankfurt 2").',
)
@click.option(
    "-p", "--plan", "plan", default=None, type=str,
    help="Plan ID, short slug, or full slug (e.g. 14, 8gb, node-8gb-g2).",
)
@click.option(
    "-k", "--key", "key", default=None, type=str,
    help="SSH key ID or description (numeric names resolve as ID first).",
)
@click.option("-h", "--hostname", default=None, help="Custom hostname.")
@click.option("-t", "--template", default=None, help="Template slug (e.g. debian-13).")
@click.option("--flavor", "flavor_id", default=None, type=int, help="Flavor ID.")
@click.option(
    "--address",
    "additional_address",
    default=None,
    type=click.Choice(["dedicated_ipv4"]),
    help="Additional IP address type.",
)
@click.pass_context
@handle_errors
def nodes_create(ctx, region, plan, key, hostname, template, flavor_id, additional_address):
    """Deploy a new node.

    On a TTY, any of --region/--plan/--key may be omitted and you will be
    prompted. In non-interactive mode (pipe, CI, or --json), omitting a flag
    is an error. Each flag accepts a numeric ID, a short slug, a full slug,
    or an exact name (case-insensitive).
    """
    client = require_client(ctx)
    region_id = _resolve_region(client, region)
    plan_id = _resolve_plan(client, plan)
    key_id = _resolve_key(client, key)
    if template is None and _is_interactive():
        template = _prompt_template(client, region_id)
    result = client.nodes_create(
        region_id=region_id,
        plan_id=plan_id,
        key_id=key_id,
        hostname=hostname,
        template=template,
        flavor_id=flavor_id,
        additional_address=additional_address,
    )
    _render(result, lambda d: _print_action(d, title="Node Deploying"))


@nodes.command("update")
@click.argument("pay_id")
@click.option("--hostname", default=None, help="New hostname.")
@click.option("--description", default=None, help="New description.")
@click.option("--key", "key", default=None, type=str, help="New SSH key ID or description.")
@click.option("--project", "project_id", default=None, type=int, help="Project ID.")
@click.pass_context
@handle_errors
def nodes_update(ctx, pay_id, hostname, description, key, project_id):
    """Update hostname, description, key, or project."""
    client = require_client(ctx)
    key_id = _resolve_key(client, key) if key is not None else None
    result = client.nodes_update(
        pay_id,
        hostname=hostname,
        description=description,
        key_id=key_id,
        project_id=project_id,
    )
    if isinstance(result, dict):
        _render(result, _print_node)
    else:
        print_raw(result)


@nodes.command("delete")
@click.argument("pay_id")
@click.option("-y", "--yes", is_flag=True, help="Skip confirmation.")
@click.pass_context
@handle_errors
def nodes_delete(ctx, pay_id, yes):
    """Destroy a node. Irreversible."""
    client = require_client(ctx)
    if not yes:
        click.confirm(f"Delete node {pay_id}? This is irreversible.", abort=True)
    _render(client.nodes_delete(pay_id), lambda d: _print_action(d, title="Node Deleting"))


@nodes.command("start")
@click.argument("pay_id")
@click.pass_context
@handle_errors
def nodes_start(ctx, pay_id):
    """Start a stopped node."""
    client = require_client(ctx)
    _render(client.nodes_power(pay_id, "start"), lambda d: _print_action(d, title="Start Queued"))


@nodes.command("stop")
@click.argument("pay_id")
@click.pass_context
@handle_errors
def nodes_stop(ctx, pay_id):
    """Hard stop a node (power off)."""
    client = require_client(ctx)
    _render(client.nodes_power(pay_id, "stop"), lambda d: _print_action(d, title="Stop Queued"))


@nodes.command("shutdown")
@click.argument("pay_id")
@click.pass_context
@handle_errors
def nodes_shutdown(ctx, pay_id):
    """Graceful shutdown via ACPI."""
    client = require_client(ctx)
    _render(
        client.nodes_power(pay_id, "shutdown"),
        lambda d: _print_action(d, title="Shutdown Queued"),
    )


@nodes.command("reboot")
@click.argument("pay_id")
@click.pass_context
@handle_errors
def nodes_reboot(ctx, pay_id):
    """Reboot a node."""
    client = require_client(ctx)
    _render(client.nodes_power(pay_id, "reboot"), lambda d: _print_action(d, title="Reboot Queued"))


@nodes.command("status")
@click.argument("pay_id")
@click.pass_context
@handle_errors
def nodes_status(ctx, pay_id):
    """Live status (state, CPU, memory, disk, uptime)."""
    client = require_client(ctx)
    _render(client.nodes_status(pay_id), _print_node_status)


@nodes.command("rebuild")
@click.argument("pay_id")
@click.option("-t", "--template", default=None, help="New template slug.")
@click.option("--flavor", "flavor_id", default=None, type=int, help="New flavor ID.")
@click.option("-y", "--yes", is_flag=True, help="Skip confirmation.")
@click.pass_context
@handle_errors
def nodes_rebuild(ctx, pay_id, template, flavor_id, yes):
    """Reinstall a node's OS. Destroys all data."""
    client = require_client(ctx)
    if not yes:
        click.confirm(
            f"Rebuild {pay_id}? This will DESTROY all data on the node.", abort=True
        )
    _render(
        client.nodes_rebuild(pay_id, template=template, flavor_id=flavor_id),
        lambda d: _print_action(d, title="Rebuild Started"),
    )


@nodes.command("password")
@click.argument("pay_id")
@click.pass_context
@handle_errors
def nodes_password(ctx, pay_id):
    """Generate a new root password (node must be running)."""
    client = require_client(ctx)
    result = client.nodes_password(pay_id)
    if _is_json():
        click.echo(_json.dumps(result, indent=2))
    else:
        _print_password(result.get("password", str(result)))


@nodes.command("addresses")
@click.argument("pay_id")
@click.pass_context
@handle_errors
def nodes_addresses(ctx, pay_id):
    """List IP addresses for a node."""
    client = require_client(ctx)
    _render(client.nodes_addresses(pay_id), _print_addresses)


@nodes.command("stats")
@click.argument("pay_id")
@click.option("-r", "--range", "timerange", default="hour", help="hour, day, week, month, year.")
@click.pass_context
@handle_errors
def nodes_stats(ctx, pay_id, timerange):
    """Node performance stats."""
    client = require_client(ctx)
    print_raw(client.nodes_stats(pay_id, timerange))


@nodes.command("activity")
@click.argument("pay_id")
@click.pass_context
@handle_errors
def nodes_activity(ctx, pay_id):
    """Recent activity log for a node."""
    client = require_client(ctx)
    print_raw(client.nodes_activity(pay_id))


# ═══════════════════════════════════════════════════════════
#  webhooks
# ═══════════════════════════════════════════════════════════


@cli.group(invoke_without_command=True)
@click.pass_context
def webhooks(ctx):
    """Manage webhook endpoints."""
    if ctx.invoked_subcommand is None:
        ctx.invoke(webhooks_list)


@webhooks.command("list")
@click.pass_context
@handle_errors
def webhooks_list(ctx):
    """List all webhooks."""
    client = require_client(ctx)
    data = client.webhooks_list()
    if isinstance(data, list):
        _render(data, _print_webhooks)
    else:
        print_raw(data)


@webhooks.command("create")
@click.option("-u", "--url", required=True, help="Webhook endpoint URL.")
@click.option(
    "-e",
    "--events",
    required=True,
    multiple=True,
    type=click.Choice(WEBHOOK_EVENTS),
    help="Event to subscribe to (repeat for multiple).",
)
@click.pass_context
@handle_errors
def webhooks_create(ctx, url, events):
    """Register a new webhook."""
    client = require_client(ctx)
    _render(client.webhooks_create(url, list(events)), _print_webhook)


@webhooks.command("update")
@click.argument("webhook_id", type=int)
@click.option("-u", "--url", default=None, help="New URL.")
@click.option("--enabled/--disabled", default=None, help="Enable or disable.")
@click.option(
    "-e",
    "--events",
    multiple=True,
    type=click.Choice(WEBHOOK_EVENTS),
    help="Replace events (repeat for multiple).",
)
@click.pass_context
@handle_errors
def webhooks_update(ctx, webhook_id, url, enabled, events):
    """Update a webhook's URL, status, or events."""
    client = require_client(ctx)
    events_list = list(events) if events else None
    _render(
        client.webhooks_update(webhook_id, url=url, enabled=enabled, events=events_list),
        _print_webhook,
    )


@webhooks.command("delete")
@click.argument("webhook_id", type=int)
@click.option("-y", "--yes", is_flag=True, help="Skip confirmation.")
@click.pass_context
@handle_errors
def webhooks_delete(ctx, webhook_id, yes):
    """Delete a webhook."""
    client = require_client(ctx)
    if not yes:
        click.confirm(f"Delete webhook {webhook_id}?", abort=True)
    client.webhooks_delete(webhook_id)
    print_success(f"Webhook {webhook_id} deleted.")


@webhooks.command("test")
@click.argument("webhook_id", type=int)
@click.pass_context
@handle_errors
def webhooks_test(ctx, webhook_id):
    """Send a test payload to a webhook."""
    client = require_client(ctx)
    result = client.webhooks_test(webhook_id)
    if _is_json():
        click.echo(_json.dumps(result, indent=2))
    elif result.get("sent"):
        print_success(f"Test payload sent to webhook {webhook_id}.")
    else:
        print_error("Test failed.")
        sys.exit(1)


@webhooks.command("deliveries")
@click.argument("webhook_id", type=int)
@click.pass_context
@handle_errors
def webhooks_deliveries(ctx, webhook_id):
    """View delivery history for a webhook."""
    client = require_client(ctx)
    print_raw(client.webhooks_deliveries(webhook_id))


# ═══════════════════════════════════════════════════════════
#  reference commands
# ═══════════════════════════════════════════════════════════


@cli.command()
@click.pass_context
@handle_errors
def plans(ctx):
    """List available plans (CPU, RAM, disk tiers)."""
    client = require_client(ctx)
    data = client.plans()
    if isinstance(data, list):
        _render(data, _print_plans)
    else:
        print_raw(data)


@cli.command()
@click.pass_context
@handle_errors
def regions(ctx):
    """List available regions."""
    client = require_client(ctx)
    data = client.regions()
    if isinstance(data, list):
        _render(data, _print_regions)
    else:
        print_raw(data)


@cli.command()
@click.pass_context
@handle_errors
def templates(ctx):
    """List available OS templates and flavors."""
    client = require_client(ctx)
    data = client.templates()
    if isinstance(data, list):
        _render(data, _print_templates)
    else:
        print_raw(data)


if __name__ == "__main__":
    cli()
