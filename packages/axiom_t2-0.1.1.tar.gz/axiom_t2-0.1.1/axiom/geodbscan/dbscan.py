"""
geodbscan.py

Implements Toroidal Geodesic DBSCAN.

Reference: GEODBSCAN_MATH_FOUNDATION.md
"""

import numpy as np
from axiom.manifold.torus import TorusManifold
from sklearn.cluster import DBSCAN

class GeoDBSCAN:
    def __init__(self, eps=0.585, min_pts=15, manifold=None, lam=0.0):
        self.manifold = manifold if manifold else TorusManifold()
        self.eps = eps
        self.min_pts = min_pts
        self.lam = lam
        self.labels_ = None
        self.n_clusters_ = None
        self.n_noise_ = None
        self.X_ = None

    def fit(self, X):
        self.X_ = np.array(X)
        D = self.manifold.quantum_geodesic_matrix(self.X_, self.lam)
        db = DBSCAN(eps=self.eps, min_samples=self.min_pts, metric='precomputed')
        db.fit(D)
        
        self.labels_ = db.labels_
        self.n_clusters_ = len(set(self.labels_)) - (1 if -1 in self.labels_ else 0)
        self.n_noise_ = list(self.labels_).count(-1)
        return self

    def fit_predict(self, X):
        self.fit(X)
        return self.labels_

    def cluster_summary(self):
        if self.labels_ is None:
            raise ValueError("Model has not been fitted yet.")
            
        summary = {}
        unique_labels = set(self.labels_)
        
        print(f"Noise count: {self.n_noise_}")
        print(f"{'Cluster ID':<12} | {'N_points':<10} | {'mean_u':<8} | {'mean_v':<8} | {'mean_lon_deg':<14} | {'mean_geomag_lat_deg':<20}")
        print("-" * 85)
        
        for label in sorted(unique_labels):
            if label == -1:
                continue
            
            mask = (self.labels_ == label)
            cluster_pts = self.X_[mask]
            
            # Using arctan2 to correctly average circular angles (solves dateline discontinuity in means)
            u_mean = np.arctan2(np.mean(np.sin(cluster_pts[:, 0])), np.mean(np.cos(cluster_pts[:, 0])))
            v_mean = np.arctan2(np.mean(np.sin(cluster_pts[:, 1])), np.mean(np.cos(cluster_pts[:, 1])))
            
            mean_lon_deg = np.degrees(u_mean)
            mean_geomag_lat_deg = np.degrees(v_mean)
            
            n_pts = len(cluster_pts)
            summary[label] = {
                'N_points': n_pts,
                'mean_u': float(u_mean),
                'mean_v': float(v_mean),
                'mean_lon_deg': float(mean_lon_deg),
                'mean_geomag_lat_deg': float(mean_geomag_lat_deg)
            }
            
            print(f"{label:<12} | {n_pts:<10} | {u_mean:<8.3f} | {v_mean:<8.3f} | {mean_lon_deg:<14.3f} | {mean_geomag_lat_deg:<20.3f}")
            
        return summary

def flat_dbscan(X, eps=0.585, min_pts=15):
    X = np.array(X)
    db = DBSCAN(eps=eps, min_samples=min_pts, metric='euclidean')
    db.fit(X)
    return db
