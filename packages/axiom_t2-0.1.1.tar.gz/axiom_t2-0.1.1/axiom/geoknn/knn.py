import numpy as np
from axiom.manifold.torus import TorusManifold
from collections import Counter

class GeoKNN:
    def __init__(self, K, manifold=None):
        self.manifold = manifold if manifold else TorusManifold()
        self.K = K
        self.X_train = None
        self.y_train = None

    def fit(self, X, y):
        """
        Store training points in toroidal coordinates
        X shape: (n_samples, 2) — columns are (u, v)
        y shape: (n_samples,) — labels (regime: 0=stable, 1=crisis)
        """
        self.X_train = np.array(X)
        self.y_train = np.array(y)
        return self

    def _toroidal_distance(self, p, q):
        """Compute geodesic distance using the specified formula."""
        # p and q are of shape (2,)
        u1, v1 = p
        u2, v2 = q
        
        du_abs = abs(u1 - u2)
        dv_abs = abs(v1 - v2)
        
        du = min(du_abs, 2 * np.pi - du_abs)
        dv = min(dv_abs, 2 * np.pi - dv_abs)
        
        v_bar = (v1 + v2) / 2.0
        
        d_sq = ((self.manifold.R + self.manifold.r * np.cos(v_bar))**2) * (du**2) + (self.manifold.r**2) * (dv**2)
        return np.sqrt(d_sq)

    def _pairwise_distances(self, X_query, X_train):
        """Compute full distance matrix between X_query and X_train"""
        # Vectorized pairwise distance calculation for better performance
        # X_query: (n_queries, 2), X_train: (n_train, 2)
        u1 = X_query[:, 0][:, np.newaxis]  # (n_queries, 1)
        v1 = X_query[:, 1][:, np.newaxis]
        
        u2 = X_train[:, 0][np.newaxis, :]  # (1, n_train)
        v2 = X_train[:, 1][np.newaxis, :]
        
        du_abs = np.abs(u1 - u2)
        dv_abs = np.abs(v1 - v2)
        
        du = np.minimum(du_abs, 2 * np.pi - du_abs)
        dv = np.minimum(dv_abs, 2 * np.pi - dv_abs)
        
        v_bar = (v1 + v2) / 2.0
        
        d_sq = ((self.manifold.R + self.manifold.r * np.cos(v_bar))**2) * (du**2) + (self.manifold.r**2) * (dv**2)
        return np.sqrt(d_sq)

    def predict(self, X_query):
        """Return K nearest neighbours majority vote"""
        dists = self._pairwise_distances(np.array(X_query), self.X_train)
        predictions = []
        
        for i in range(dists.shape[0]):
            idx = np.argsort(dists[i])[:self.K]
            k_labels = self.y_train[idx]
            most_common = Counter(k_labels).most_common(1)[0][0]
            predictions.append(most_common)
            
        return np.array(predictions)

    def predict_proba(self, X_query):
        """Return class probabilities from K neighbours"""
        dists = self._pairwise_distances(np.array(X_query), self.X_train)
        probas = []
        
        # Assuming binary classification (0 and 1)
        for i in range(dists.shape[0]):
            idx = np.argsort(dists[i])[:self.K]
            k_labels = self.y_train[idx]
            count_1 = np.sum(k_labels == 1)
            prob_1 = count_1 / self.K
            probas.append([1 - prob_1, prob_1])
            
        return np.array(probas)
