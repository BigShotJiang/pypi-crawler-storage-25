import numpy as np
from axiom.manifold.torus import TorusManifold
from sklearn.model_selection import KFold, GroupKFold, cross_val_score
from axiom.geoknn.knn import GeoKNN

class TorusScanner:
    def __init__(self, n_steps=100, rho_min=1.01, rho_max=20.0,
                 k_knn=5, n_bootstrap=50, n_scan_max=2000,
                 random_state=42):
        self.n_steps = n_steps
        self.manifold.rho_min = rho_min
        self.manifold.rho_max = rho_max
        self.k_knn = k_knn
        self.n_bootstrap = n_bootstrap
        self.n_scan_max = n_scan_max
        self.manifold.random_state = random_state
        
        self.manifold.rho_optimal_ = None
        self.manifold.R_ = None
        self.manifold.r_ = 1.0
        self.criterion_curve_ = None
        self.confidence_band_ = None
        self.domain_match_ = None
        self.scan_mode_ = None
        self.n_used_ = 0
        self.n_total_ = 0

    def _scan_grid(self):
        return np.logspace(np.log10(self.manifold.rho_min), np.log10(self.manifold.rho_max), self.n_steps)

    def _subsample(self, X, y=None, groups=None):
        self.n_total_ = len(X)
        if len(X) <= self.n_scan_max:
            self.n_used_ = len(X)
            return X, y, groups
            
        v_rad = X[:, 1]
        quartiles = np.percentile(v_rad, [25, 50, 75])
        
        strata = np.zeros(len(X), dtype=int)
        strata[v_rad >= quartiles[0]] = 1
        strata[v_rad >= quartiles[1]] = 2
        strata[v_rad >= quartiles[2]] = 3
        
        np.random.seed(self.manifold.random_state)
        sampled_indices = []
        for i in range(4):
            idx = np.where(strata == i)[0]
            n_sample = int(len(idx) / len(X) * self.n_scan_max)
            if n_sample > 0:
                sampled_indices.extend(np.random.choice(idx, size=n_sample, replace=False))
                
        if len(sampled_indices) < self.n_scan_max:
            remaining_slots = self.n_scan_max - len(sampled_indices)
            remaining_idx = list(set(range(len(X))) - set(sampled_indices))
            sampled_indices.extend(np.random.choice(remaining_idx, size=remaining_slots, replace=False))
            
        sampled_indices = np.array(sampled_indices[:self.n_scan_max])
        self.n_used_ = len(sampled_indices)
        
        return (
            X[sampled_indices], 
            y[sampled_indices] if y is not None else None, 
            groups[sampled_indices] if groups is not None else None
        )

    def _supervised_score(self, X, y, rho, groups=None):
        knn = GeoKNN(K=self.k_knn, R=rho, r=1.0)
        cv = GroupKFold(5) if groups is not None else KFold(5)
        scores = []
        splits = cv.split(X, y, groups)
        for train_idx, test_idx in splits:
            knn.fit(X[train_idx], y[train_idx])
            preds = knn.predict(X[test_idx])
            scores.append(np.mean(preds == y[test_idx]))
        return np.mean(scores)

    def _mle_score(self, X, rho):
        v = X[:, 1]  # poloidal angle only
        ll = np.log((rho + np.cos(v)) / (2 * np.pi * rho))
        return np.mean(ll)

    def fit(self, X, y=None, groups=None):
        from joblib import Parallel, delayed
        
        X = np.array(X)
        if y is not None:
            y = np.array(y)
        if groups is not None:
            groups = np.array(groups)
            
        X_scan, y_scan, groups_scan = self._subsample(X, y, groups)
        self.scan_mode_ = 'supervised' if y_scan is not None else 'unsupervised'
        
        grid = self._scan_grid()
        
        if self.scan_mode_ == 'supervised':
            scores = Parallel(n_jobs=-1)(delayed(self._supervised_score)(X_scan, y_scan, rho, groups_scan) for rho in grid)
        else:
            scores = Parallel(n_jobs=-1)(delayed(self._mle_score)(X_scan, rho) for rho in grid)
            
        self.criterion_curve_ = np.array(scores)
        best_idx = np.argmax(self.criterion_curve_)
        self.manifold.rho_optimal_ = grid[best_idx]
        self.manifold.R_ = self.manifold.rho_optimal_
        self.manifold.r_ = 1.0
        self.h_optimal_ = None
        
        self.domain_match_ = 'custom'
        presets = {'geographic': 3.0, 'financial': 10.0}
        for name, preset in presets.items():
            if abs(self.manifold.rho_optimal_ - preset) / preset < 0.15:
                self.domain_match_ = name
                break
        if self.domain_match_ == 'custom' and self.manifold.rho_optimal_ > 20:
            self.domain_match_ = 'protein'
            
        np.random.seed(self.manifold.random_state)
        n_samples = len(X_scan)
        
        def run_bootstrap_iteration():
            idx = np.random.choice(n_samples, n_samples, replace=True)
            X_b = X_scan[idx]
            y_b = y_scan[idx] if y_scan is not None else None
            g_b = groups_scan[idx] if groups_scan is not None else None
            
            b_scores = []
            for rho in grid:
                if self.scan_mode_ == 'supervised':
                    s = self._supervised_score(X_b, y_b, rho, g_b)
                else:
                    s = self._mle_score(X_b, rho)
                b_scores.append(s)
            return grid[np.argmax(b_scores)]
            
        bootstrap_rhos = Parallel(n_jobs=-1)(delayed(run_bootstrap_iteration)() for _ in range(self.n_bootstrap))
        
        if self.n_bootstrap > 0:
            self.confidence_band_ = (np.percentile(bootstrap_rhos, 2.5), np.percentile(bootstrap_rhos, 97.5))
        else:
            self.confidence_band_ = (self.manifold.rho_optimal_, self.manifold.rho_optimal_)
        
        return self

    @property
    def manifold(self):
        try:
            from geoknn import TorusManifold
            return TorusManifold(R=self.manifold.R_, r=1.0)
        except ImportError:
            return {'R': self.manifold.R_, 'r': 1.0}

    def summary(self):
        print(f"Optimal rho = R/r: {self.manifold.rho_optimal_:.3f}")
        print(f"Canonical params: R={self.manifold.R_:.3f}, r=1.000")
        print(f"95% CI: [{self.confidence_band_[0]:.3f}, {self.confidence_band_[1]:.3f}]")
        print(f"Domain match: {self.domain_match_}")
        print(f"Scan mode: {self.scan_mode_}")
        print(f"N scanned: {self.n_used_}/{self.n_total_}")
