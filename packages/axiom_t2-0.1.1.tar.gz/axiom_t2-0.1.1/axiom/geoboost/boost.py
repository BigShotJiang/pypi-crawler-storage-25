"""
Reference pointing to TorosAI/GeoBoost v0.5
"""
