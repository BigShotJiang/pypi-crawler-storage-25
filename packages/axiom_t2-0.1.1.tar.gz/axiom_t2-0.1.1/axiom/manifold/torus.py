import numpy as np

class TorusManifold:
    def __init__(self, R=3.0, r=1.0):
        self.R = R
        self.r = r

    @classmethod
    def geographic(cls):
        return cls(R=3.0, r=1.0)

    @classmethod
    def financial(cls):
        return cls(R=10.0, r=1.0)
        
    @classmethod
    def protein(cls):
        return cls(R=1.0, r=0.5)

    def K(self, v):
        """Gaussian curvature."""
        return np.cos(v) / (self.r * (self.R + self.r * np.cos(v)))

    def igrf13_to_torus(self, lon_deg, lat_geomag_deg):
        """Converts Geographic longitudes and IGRF-13 Geomagnetic latitudes to radians."""
        u_rad = np.radians(lon_deg)
        v_rad = np.radians(lat_geomag_deg)
        return u_rad, v_rad

    def geodesic_batch(self, X_query, X_train):
        """Computes pairwise geodesic distance between query points and train points."""
        u_q = X_query[:, 0][:, np.newaxis]
        v_q = X_query[:, 1][:, np.newaxis]
        
        u_r = X_train[:, 0][np.newaxis, :]
        v_r = X_train[:, 1][np.newaxis, :]
        
        du = np.abs(u_q - u_r)
        du = np.minimum(du, 2 * np.pi - du)
        
        dv = np.abs(v_q - v_r)
        dv = np.minimum(dv, 2 * np.pi - dv)
        
        v_bar = (v_q + v_r) / 2.0
        
        d2 = (self.R + self.r * np.cos(v_bar))**2 * du**2 + self.r**2 * dv**2
        return np.sqrt(d2)

    def geodesic_matrix(self, X):
        """Computes full NxN pairwise geodesic distance matrix for dataset X."""
        return self.geodesic_batch(X, X)

    def quantum_geodesic_matrix(self, X, lam=0.0):
        """Quantum distance inflation using curvature penalization."""
        D = self.geodesic_matrix(X)
        if lam == 0.0:
            return D
        v = X[:, 1]
        K_val = self.K(v)
        phi = np.exp(-lam * np.abs(K_val))
        phi_outer = np.outer(phi, phi)
        D_Q = D / np.sqrt(np.maximum(phi_outer, 1e-10))
        return D_Q
