"""
geokde.py

Implements Toroidal Geodesic Kernel Density Estimation (GeoKDE).

Reference: GEOKDE_MATH_FOUNDATION.md

Fixes two failure modes of Flat KDE on T^2:
1. Dateline tear: kernel splits events at lon=±179° that are 2° apart geodesically.
2. K=0 distortion: metric compression near phase boundary causes density underestimation.
"""

import warnings
import numpy as np
from axiom.manifold.torus import TorusManifold

class GeoKDE:
    def __init__(self, manifold=None, h=None, n_norm_samples=5000, random_state=42):
        self.manifold = manifold if manifold else TorusManifold()
        self.h = h
        self.n_norm_samples = n_norm_samples
        self.manifold.random_state = random_state
        self.h_ = None
        self._C = None
        self.X_train_ = None

    def _scott_bandwidth(self, X):
        rng = np.random.default_rng(self.manifold.random_state)
        N = len(X)
        n_pairs = 500
        idx1 = rng.choice(N, n_pairs)
        idx2 = rng.choice(N, n_pairs)
        
        D = self.manifold.geodesic_batch(X[idx1], X[idx2])
        dists = np.diag(D)
        sigma_geo = np.std(dists)
        
        h = (N ** (-1/6)) * sigma_geo
        return h

    def _normalisation(self, h):
        rng = np.random.default_rng(self.manifold.random_state)
        samples = []
        while len(samples) < self.n_norm_samples:
            u = rng.uniform(-np.pi, np.pi, self.n_norm_samples)
            v = rng.uniform(-np.pi, np.pi, self.n_norm_samples)
            w = (self.manifold.R + self.manifold.r * np.cos(v)) / (self.manifold.R + self.manifold.r)
            accept = rng.uniform(0, 1, self.n_norm_samples) < w
            valid = np.column_stack((u[accept], v[accept]))
            if len(valid) > 0:
                samples.extend(valid.tolist())
        X_samples = np.array(samples[:self.n_norm_samples])
        
        x0 = np.array([[0.0, 0.0]])
        dists = self.manifold.geodesic_batch(x0, X_samples)[0]
        
        mean_exp = np.mean(np.exp(-dists**2 / (2 * h**2)))
        return mean_exp

    def fit(self, X):
        self.X_train_ = np.array(X)
        if self.h is None:
            self.h_ = self._scott_bandwidth(self.X_train_)
        else:
            self.h_ = self.h
            
        self._C = self._normalisation(self.h_)
        return self

    def _phi_M(self, v, lam):
        K = np.cos(v) / (self.manifold.r * (self.manifold.R + self.manifold.r * np.cos(v)))
        return np.exp(-lam * np.abs(K))

    def score_samples(self, X_query, lam=0.0):
        X_query = np.array(X_query)
        N_train = len(self.X_train_)
        if N_train > 3000:
            warnings.warn(f"N_train = {N_train} > 3000. GeoKDE prediction is O(N^2) and may be slow.")
            
        D = self.manifold.geodesic_batch(X_query, self.X_train_)
        phi = self._phi_M(self.X_train_[:, 1], lam)
        kernel_vals = phi[np.newaxis, :] * np.exp(-D**2 / (2 * self.h_**2))
        f_hat = np.mean(kernel_vals, axis=1)
        f_hat = np.maximum(f_hat, 1e-300)
        return np.log(f_hat)

    def score(self, X_query, lam=0.0):
        return np.mean(self.score_samples(X_query, lam=lam))

def flat_kde(X_train, X_query, h=None):
    X_train = np.array(X_train)
    X_query = np.array(X_query)
    
    if h is None:
        rng = np.random.default_rng(42)
        N = len(X_train)
        n_pairs = 500
        idx1 = rng.choice(N, n_pairs)
        idx2 = rng.choice(N, n_pairs)
        dists = np.linalg.norm(X_train[idx1] - X_train[idx2], axis=1)
        sigma_eucl = np.std(dists)
        h = (N ** (-1/6)) * sigma_eucl
        
    u_q = X_query[:, 0][:, np.newaxis]
    v_q = X_query[:, 1][:, np.newaxis]
    u_r = X_train[:, 0][np.newaxis, :]
    v_r = X_train[:, 1][np.newaxis, :]
    
    d2 = (u_q - u_r)**2 + (v_q - v_r)**2
    kernel_vals = np.exp(-d2 / (2 * h**2))
    f_hat = np.mean(kernel_vals, axis=1)
    f_hat = np.maximum(f_hat, 1e-300)
    return np.log(f_hat)
