#!/usr/bin/env python3
"""
RPWP CLI — Resonance Proto-Writing Processor

Unified demo interface:
  PYTHONPATH=src python -m seif.cli "O amor liberta e guia"
  PYTHONPATH=src python -m seif.cli --gate "Tesla 369"
  PYTHONPATH=src python -m seif.cli --glyph "A Semente de Enoque"
  PYTHONPATH=src python -m seif.cli --audio "Love and Harmony"
  PYTHONPATH=src python -m seif.cli --fractal "O amor liberta e guia"
"""

import argparse
from pathlib import Path

from seif.core.resonance_gate import evaluate
from seif.analysis.transcompiler import transcompile, describe
from seif.generators.glyph_renderer import render, render_fractal_qr
from seif.generators.harmonic_audio import render_audio
from seif.generators.fractal_qrcode import generate_fractal_qr, describe as describe_fqr
from seif.generators.circuit_generator import generate_from_spec, render_svg
from seif.generators.composite_renderer import render_composite
from seif.core.resonance_encoding import encode_phrase, describe_melody


def cmd_autonomous(action: str, context_repo: str = None):
    from seif.context.autonomous import (
        load_config, save_config, is_autonomous, load_mapper,
        find_context_repo, CATEGORIES, DEFAULT_CONFIG,
    )

    # Auto-discover context repo if not specified
    if not context_repo:
        context_repo = find_context_repo() or ".seif"

    config = load_config(context_repo)

    if action == "enable":
        config["autonomous_context"] = True
        save_config(context_repo, config)
        print("Autonomous context: ENABLED")
        print(f"  Context repo:  {context_repo}")
        print(f"  Categories:    {', '.join(CATEGORIES.keys())}")
        print(f"  Quality min:   {config.get('quality_threshold', 'C')}")
        print(f"  Max modules:   {config.get('max_modules_per_project', 10)}/project")
        print()
        print("The AI will now manage its own knowledge persistence.")
        print("Use --autonomous disable to turn it off.")

    elif action == "disable":
        config["autonomous_context"] = False
        save_config(context_repo, config)
        print("Autonomous context: DISABLED")
        print("Existing .seif modules are preserved but no new ones will be created.")

    else:  # status
        enabled = is_autonomous(config)
        read_only = config.get("read_only", False)
        print(f"Autonomous context: {'ENABLED' if enabled else 'DISABLED'}")
        if read_only:
            print(f"  Mode:          READ-ONLY")
        print(f"  Context repo:  {context_repo}")
        print(f"  Decay:         {config.get('relevance_decay', 0.95)}")
        if config.get("require_confidential_approval", False):
            print(f"  CONFIDENTIAL:  requires approval")

        mapper = load_mapper(context_repo)
        print(f"  Sessions:      {mapper.session_count}")
        print(f"  Modules:       {len(mapper.modules)}")
        if mapper.last_session:
            print(f"  Last session:  {mapper.last_session[:19]}")
        if mapper.pending_observations:
            print(f"  Pending:       {len(mapper.pending_observations)} observations")

        ai_modules = [m for m in mapper.modules if m.origin == "ai-observed"]
        if ai_modules:
            print(f"\n  AI-created modules:")
            for m in ai_modules:
                project = m.project or "cross-project"
                cls_icon = {"PUBLIC": "🔓", "INTERNAL": "🔒", "CONFIDENTIAL": "⛔"}.get(m.classification, "?")
                print(f"    {cls_icon} {project}/{m.category} [{m.classification}] — {m.word_count} words")

        # Classification summary
        from seif.context.autonomous import CLASSIFICATION_LEVELS
        cls_counts = {}
        for m in mapper.modules:
            cls = getattr(m, 'classification', 'INTERNAL')
            cls_counts[cls] = cls_counts.get(cls, 0) + 1
        if cls_counts:
            print(f"\n  Classification:")
            for cls in ["PUBLIC", "INTERNAL", "CONFIDENTIAL"]:
                if cls in cls_counts:
                    print(f"    {cls}: {cls_counts[cls]} modules")


def cmd_export(context_repo: str, classification: str, output: str):
    from seif.context.autonomous import (
        load_mapper, bootstrap_context, find_context_repo, CLASSIFICATION_LEVELS,
    )

    # Auto-discover context repo if not specified
    if not context_repo:
        context_repo = find_context_repo() or ".seif"
    from pathlib import Path

    if classification not in CLASSIFICATION_LEVELS:
        print(f"Invalid classification: {classification}")
        print(f"Valid: {', '.join(CLASSIFICATION_LEVELS.keys())}")
        return

    mapper = load_mapper(context_repo)
    context = bootstrap_context(mapper, context_repo,
                                max_tokens=50000,
                                max_classification=classification)

    if output:
        Path(output).write_text(context, encoding="utf-8")
        print(f"Exported to: {output}")
    else:
        print(context)

    # Stats
    total = len(mapper.modules)
    level = CLASSIFICATION_LEVELS[classification]
    included = sum(1 for m in mapper.modules
                   if CLASSIFICATION_LEVELS.get(m.classification, 2) <= level)
    excluded = total - included
    print(f"\n--- Export: {included}/{total} modules (excluded {excluded} above {classification})")


def cmd_install_hooks(repo_path: str):
    from seif.context.git_hooks import install_hooks, check_hooks
    installed = install_hooks(repo_path)
    if installed:
        print("Git hooks installed:")
        for h in installed:
            print(f"  {h}")
        print("\n.seif will auto-sync on commit, pull, and branch switch.")
    else:
        print("No .git directory found. Initialize git first.")


def cmd_init(root_path: str, author: str, context_repo: str = None):
    from seif.context.workspace import discover_projects, sync_workspace, describe_workspace
    from seif.context.git_context import sync_project, extract_git_context
    from seif.context.git_hooks import install_hooks
    from pathlib import Path

    root = Path(root_path).resolve()
    print(f"Initializing S.E.I.F. in: {root}")
    if context_repo:
        print(f"Context repository: {context_repo} (SCR mode)")
    print()

    # Phase 1: Scan for subprojects
    subprojects = discover_projects(str(root))

    if subprojects:
        # Workspace mode: multiple projects found
        print(f"Detected WORKSPACE with {len(subprojects)} projects:")
        for p in subprojects:
            has_git = (root / p.path / ".git").exists()
            git_label = " (git)" if has_git else ""
            print(f"  {p.name:<25} {p.manifest_type or 'unknown'}{git_label}")
            if p.description:
                print(f"    {p.description[:80]}")
        print()

        # Sync workspace (creates nucleus + all project .seif files)
        print("Syncing all projects...")
        registry = sync_workspace(str(root), author=author,
                                  context_repo_path=context_repo)
        print()
        print(describe_workspace(registry))

        # Summary
        print()
        print(f"Created:")
        if context_repo:
            ctx_path = Path(context_repo).resolve()
            print(f"  {ctx_path}/manifest.json   — SCR manifest ({len(registry.projects)} projects)")
            print(f"  {ctx_path}/nucleus.seif     — workspace-level context")
            print(f"  {ctx_path}/README.md        — AI bootstrap")
            for p in registry.projects:
                print(f"  {ctx_path}/projects/{p.name}/ref.json")
                print(f"  {ctx_path}/projects/{p.name}/project.seif")
        else:
            print(f"  .seif/workspace.json    — project registry ({len(registry.projects)} projects)")
            print(f"  .seif/nucleus.seif      — workspace-level context")
            for p in registry.projects:
                seif_path = root / p.path / ".seif" / "project.seif"
                if seif_path.exists():
                    print(f"  {p.path}/.seif/project.seif")

    else:
        # Single project mode
        has_git = (root / ".git").exists()
        if has_git:
            ctx = extract_git_context(str(root))
            print(f"Detected SINGLE PROJECT: {ctx.repo_name}")
            print(f"  Branch:       {ctx.branch}")
            print(f"  Commits:      {ctx.total_commits}")
            print(f"  Contributors: {len(ctx.contributors)}")
            if ctx.manifest_type:
                print(f"  Manifest:     {ctx.manifest_type}")
            if ctx.hot_files:
                top = ctx.hot_files[0]
                print(f"  Hot file:     {top[0]} ({top[1]} changes)")
            print()

            target = None
            if context_repo:
                ctx_path = Path(context_repo).resolve()
                ctx_path.mkdir(parents=True, exist_ok=True)
                target = str(ctx_path / "projects" / ctx.repo_name / "project.seif")
                # Create ref.json
                from seif.context.ref import create_ref, save_ref
                ref = create_ref(str(root), str(ctx_path))
                save_ref(ref, Path(target).parent / "ref.json")

            module, path = sync_project(str(root), author=author, target_path=target)
            print(f"Created:")
            print(f"  {path}")
            print(f"  Words:   {module.compressed_words}")
            print(f"  Hash:    {module.integrity_hash}")
        else:
            print(f"No git repo or subprojects found in {root}")
            print(f"Run 'git init' first, or point to a workspace with subprojects.")
            return

    # Install git hooks for auto-sync
    if subprojects:
        # Install hooks in each subproject with git
        hook_count = 0
        for p in subprojects:
            project_dir = root / p.path
            if (project_dir / ".git").exists():
                hooks = install_hooks(str(project_dir))
                if hooks:
                    hook_count += 1
        if hook_count:
            print(f"\nGit hooks: installed in {hook_count} projects (auto-sync on commit/pull)")
    elif (root / ".git").exists():
        hooks = install_hooks(str(root))
        if hooks:
            print(f"\nGit hooks: {', '.join(h.split(' ')[0] for h in hooks)}")
            print("  .seif auto-syncs on commit, pull, and branch switch")

    print()
    print("Done. Next steps:")
    print("  seif-cli --quality-gate \"text\"       — measure any text")
    if context_repo:
        print(f"  seif-cli --sync --context-repo {context_repo}  — re-sync")
        print(f"  seif-cli --workspace --context-repo {context_repo} --ingest daily.txt")
    else:
        print("  seif-cli --sync                       — re-sync after changes")
        print("  seif-cli --ingest daily.txt            — ingest meeting notes")
        if subprojects:
            print("  seif-cli --workspace --ingest daily.txt — route to all projects")


def cmd_workspace(workspace_root: str, ingest_source: str = None,
                   author: str = "workspace", via: str = "sync",
                   context_repo: str = None):
    from seif.context.workspace import (
        sync_workspace, describe_workspace, ingest_to_workspace,
    )

    if ingest_source:
        # Route ingested text to all projects in workspace
        from seif.context.ingest import describe_ingest
        results = ingest_to_workspace(workspace_root, ingest_source,
                                       author=author, via=via,
                                       context_repo_path=context_repo)
        if "error" in results:
            print(f"Error: {results['error']}")
            return
        for project_name, result in results.items():
            if result.relevant:
                print(f"\n{project_name}:")
                print(describe_ingest(result))
            else:
                print(f"\n{project_name}: no relevant content")
    else:
        # Discover + sync all projects
        mode = " (SCR)" if context_repo else ""
        print(f"Syncing workspace{mode}: {workspace_root}")
        registry = sync_workspace(workspace_root, author=author,
                                  context_repo_path=context_repo)
        print()
        print(describe_workspace(registry))


def cmd_ingest(source: str, project_path: str, author: str, via: str):
    from seif.context.ingest import ingest, describe_ingest
    result = ingest(source, project_path, author=author, via=via)
    print(describe_ingest(result))


def cmd_quality_gate(text: str, role: str):
    from seif.analysis.quality_gate import assess, describe_verdict
    verdict = assess(text, role=role)
    print(describe_verdict(verdict))


def cmd_sync(repo_path: str, author: str, via: str, context_repo: str = None):
    from seif.context.git_context import sync_project, extract_git_context
    ctx = extract_git_context(repo_path)
    print(f"Repository:    {ctx.repo_name}")
    print(f"Branch:        {ctx.branch}")
    print(f"Commits:       {ctx.total_commits}")
    print(f"Contributors:  {len(ctx.contributors)}")
    if ctx.manifest_type:
        print(f"Manifest:      {ctx.manifest_type}")
    if ctx.hot_files:
        print(f"Hot files:     {ctx.hot_files[0][0]} ({ctx.hot_files[0][1]}x)")
    print()

    # Determine target path
    target = None
    if context_repo:
        from pathlib import Path
        ctx_path = Path(context_repo).resolve()
        target = str(ctx_path / "projects" / ctx.repo_name / "project.seif")
        # Update ref.json
        from seif.context.ref import create_ref, save_ref
        ref = create_ref(repo_path, str(ctx_path))
        save_ref(ref, Path(target).parent / "ref.json")

    module, path = sync_project(repo_path, author=author, via=via, target_path=target)
    print(f"Synced to:     {path}")
    print(f"  Version:     {module.version}")
    print(f"  Words:       {module.compressed_words}")
    print(f"  Hash:        {module.integrity_hash}")
    if module.parent_hash:
        print(f"  Parent:      {module.parent_hash}")


def cmd_contribute(module_path: str, text: str, author: str, via: str):
    from seif.context.context_manager import contribute_to_module
    module, path = contribute_to_module(module_path, text, author, via)
    print(f"Contributed to: {path}")
    print(f"  Version:      {module.version}")
    print(f"  Contributors: {len(module.contributors)}")
    print(f"  Words:        {module.compressed_words}")
    print(f"  Hash:         {module.integrity_hash}")
    print(f"  Parent hash:  {module.parent_hash}")


def cmd_composite(text: str):
    path = render_composite(text)
    print(f"Mapa de Ressonância Completo salvo: {path}")


def cmd_encode(text: str):
    melody = encode_phrase(text)
    print(describe_melody(melody))


def cmd_constants(text: str):
    from seif.analysis.physical_constants import describe_signature
    from seif.core.resonance_gate import evaluate
    result = evaluate(text)
    print(result)
    print()
    print(describe_signature(result.digital_root))


def cmd_circuit(text: str):
    spec = transcompile(text)
    layout = generate_from_spec(spec)
    path = render_svg(layout)
    print(f"Circuito SFA salvo: {path}")
    print(f"  Traces: {len(layout.traces)}, Pads: {len(layout.pads)}, Layers: {layout.layer_count}")


def cmd_analyze_artifact(image_path: str):
    from seif.analysis.artifact_analyzer import analyze, describe as desc_art, generate_overlay
    from seif.analysis.pattern_comparator import self_compare
    geo = analyze(image_path)
    print(desc_art(geo))
    overlay = generate_overlay(image_path, geo)
    print(f"\nOverlay salvo: {overlay}")
    report = self_compare(geo)
    print()
    print(report)


def cmd_gate(text: str):
    result = evaluate(text)
    print(result)


def cmd_transcompile(text: str):
    spec = transcompile(text)
    print(describe(spec))


def cmd_glyph(text: str):
    spec = transcompile(text)
    path = render(spec)
    print(f"Glifo salvo: {path}")


def cmd_audio(text: str):
    spec = transcompile(text)
    path = render_audio(spec)
    print(f"Áudio salvo: {path}")


def cmd_fractal(text: str):
    qr = generate_fractal_qr(text, max_depth=4)
    print(describe_fqr(qr))
    path = render_fractal_qr(qr)
    print(f"\nFractal QR salvo: {path}")


def cmd_all(text: str):
    print("=" * 60)
    print("RPWP — Processamento Completo")
    print("=" * 60)
    print()

    # 1. Gate
    result = evaluate(text)
    print(result)
    print()

    # 2. Transcompile
    spec = transcompile(text)
    print(describe(spec))
    print()

    # 3. Glyph
    glyph_path = render(spec)
    print(f"Glifo salvo: {glyph_path}")

    # 4. Audio
    audio_path = render_audio(spec)
    print(f"Áudio salvo: {audio_path}")

    # 5. Fractal QR
    qr = generate_fractal_qr(text, max_depth=4)
    print()
    print(describe_fqr(qr))
    qr_path = render_fractal_qr(qr)
    print(f"\nFractal QR salvo: {qr_path}")

    # 6. SFA Circuit
    layout = generate_from_spec(spec)
    circuit_path = render_svg(layout)
    print(f"Circuito SFA salvo: {circuit_path}")

    # 7. Composite Resonance Map
    composite_path = render_composite(text)
    print(f"Mapa de Ressonância Completo salvo: {composite_path}")

    print()
    print("=" * 60)
    print("Processamento completo.")


def main():
    parser = argparse.ArgumentParser(
        description="RPWP — Resonance Proto-Writing Processor",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Exemplos:\n"
            '  PYTHONPATH=src python -m seif.cli "O amor liberta e guia"\n'
            '  PYTHONPATH=src python -m seif.cli --gate "Tesla 369"\n'
            '  PYTHONPATH=src python -m seif.cli --fractal "A Semente de Enoque"\n'
        ),
    )
    parser.add_argument("text", nargs="?", default="",
                        help="Texto de entrada ou caminho de imagem (com --artifact)")
    parser.add_argument("--gate", action="store_true", help="Apenas Porta de Ressonância")
    parser.add_argument("--transcompile", action="store_true", help="Apenas transcompilação")
    parser.add_argument("--glyph", action="store_true", help="Apenas glifo visual")
    parser.add_argument("--audio", action="store_true", help="Apenas áudio 432Hz")
    parser.add_argument("--fractal", action="store_true", help="Apenas Fractal QR-Code")
    parser.add_argument("--circuit", action="store_true", help="Apenas circuito SFA (SVG)")
    parser.add_argument("--composite", action="store_true", help="Mapa de Ressonância Completo (selo + hardware)")
    parser.add_argument("--encode", action="store_true", help="Resonance Encoding (φ-spiral frequencies)")
    parser.add_argument("--artifact", action="store_true", help="Analisar imagem de artefato antigo")
    parser.add_argument("--all", action="store_true", help="Pipeline completo (padrão)")
    parser.add_argument("--init", nargs="?", const=".", metavar="PATH",
                        help="Initialize S.E.I.F.: scan, detect projects, extract git, generate .seif")
    parser.add_argument("--install-hooks", nargs="?", const=".", metavar="REPO",
                        help="Install git hooks for auto-sync on commit/pull/checkout")
    parser.add_argument("--quality-gate", action="store_true",
                        help="Quality Gate: unified stance + resonance verdict")
    parser.add_argument("--role", default="human", choices=["human", "ai"],
                        help="Role of the text author (for --quality-gate)")
    parser.add_argument("--workspace", nargs="?", const=".", metavar="ROOT_PATH",
                        help="Multi-project workspace: discover, sync, and manage all projects")
    parser.add_argument("--ingest", metavar="SOURCE",
                        help="Ingest external text (file, string, or - for stdin) into project .seif")
    parser.add_argument("--project", metavar="SEIF_PATH",
                        help="Target .seif file for --ingest (default: .seif/project.seif)")
    parser.add_argument("--sync", nargs="?", const=".", metavar="REPO_PATH",
                        help="Auto-generate .seif from git context (default: current dir)")
    parser.add_argument("--contribute", metavar="MODULE_PATH",
                        help="Contribute to an existing .seif module (text = contribution content)")
    parser.add_argument("--author", default="unknown", help="Author name for --contribute/--sync")
    parser.add_argument("--via", default="git", help="Tool/model used for --contribute/--sync")
    parser.add_argument("--context-repo", metavar="PATH",
                        help="Use a separate SEIF Context Repository (SCR mode). "
                             "All .seif data is stored externally, not inside code repos.")
    parser.add_argument("--autonomous", metavar="ACTION", nargs="?", const="status",
                        choices=["enable", "disable", "status"],
                        help="Manage AI autonomous context: enable, disable, or status (default)")
    parser.add_argument("--export", nargs="?", const="", metavar="OUTPUT_FILE",
                        help="Export context filtered by classification (to stdout or file)")
    parser.add_argument("--classification", default="INTERNAL",
                        choices=["PUBLIC", "INTERNAL", "CONFIDENTIAL"],
                        help="Classification filter for --export (default: INTERNAL)")

    args = parser.parse_args()

    if args.autonomous is not None:
        cmd_autonomous(args.autonomous, args.context_repo or ".seif")
        return

    if args.export is not None:
        cmd_export(args.context_repo or ".seif", args.classification, args.export)
        return

    if args.install_hooks is not None:
        cmd_install_hooks(args.install_hooks)
        return

    if args.init is not None:
        cmd_init(args.init, args.author, context_repo=args.context_repo)
        return

    if args.sync is not None:
        cmd_sync(args.sync, args.author, args.via, context_repo=args.context_repo)
        return

    if args.workspace is not None:
        cmd_workspace(args.workspace, ingest_source=args.ingest,
                       author=args.author, via=args.via,
                       context_repo=args.context_repo)
        return

    if args.ingest:
        project = args.project or ".seif/project.seif"
        cmd_ingest(args.ingest, project, args.author, args.via)
        return

    if args.quality_gate:
        if not args.text:
            parser.error("text is required for --quality-gate")
        cmd_quality_gate(args.text, args.role)
        return

    if args.contribute:
        cmd_contribute(args.contribute, args.text, args.author, args.via)
        return

    if not args.text:
        parser.error("text is required (unless using --sync)")

    flags = [args.gate, args.transcompile, args.glyph, args.audio,
             args.fractal, args.circuit, args.composite, args.encode, args.artifact, args.all]
    if not any(flags):
        args.all = True

    if args.artifact:
        cmd_analyze_artifact(args.text)
    elif args.gate:
        cmd_gate(args.text)
    elif args.transcompile:
        cmd_transcompile(args.text)
    elif args.glyph:
        cmd_glyph(args.text)
    elif args.audio:
        cmd_audio(args.text)
    elif args.fractal:
        cmd_fractal(args.text)
    elif args.circuit:
        cmd_circuit(args.text)
    elif args.composite:
        cmd_composite(args.text)
    elif args.encode:
        cmd_encode(args.text)
    else:
        cmd_all(args.text)


if __name__ == "__main__":
    main()
