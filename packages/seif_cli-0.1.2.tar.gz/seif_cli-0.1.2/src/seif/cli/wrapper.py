"""
seif — S.E.I.F. Resonance Wrapper (Python entry point)

Replaces the bash bin/seif for pip-installed usage.
After `pip install seif-cli`, the `seif` command launches
Claude or Gemini with the full SEIF context injected.

Usage:
    seif                    # interactive Claude + SEIF context
    seif -g                 # interactive Gemini + SEIF context
    seif -p "message"       # non-interactive (print mode)
    seif --status           # show context hierarchy
"""

import argparse
import os
import shutil
import subprocess
import sys
from pathlib import Path

from seif.context.context_manager import build_startup_context, estimate_tokens, list_modules
from seif.data.paths import get_resonance_path


def _build_global_prompt() -> str:
    """Layer 1: SEIF_HOME context (KERNEL + defaults — always present)."""
    try:
        return build_startup_context()
    except Exception:
        return "S.E.I.F. protocol active."


def _build_local_prompt() -> str:
    """Layer 2: Local context (RESONANCE.json or .seif/ in cwd)."""
    cwd = Path.cwd()
    parts = []

    if (cwd / "RESONANCE.json").exists():
        parts.append(f"[LOCAL PROJECT: {cwd} has RESONANCE.json]")

    seif_dir = cwd / ".seif"
    if seif_dir.is_dir():
        seif_files = sorted(seif_dir.glob("*.seif"))
        if seif_files:
            try:
                from seif.context.context_manager import load_module
                modules = []
                for f in seif_files:
                    try:
                        m = load_module(str(f))
                        if m.active:
                            modules.append(
                                f"MODULE ({m.source}, {m.compression_ratio:.0f}:1):\n"
                                f"{m.summary[:500]}"
                            )
                    except Exception:
                        pass
                if modules:
                    parts.append("[LOCAL .seif MODULES]")
                    parts.append("\n---\n".join(modules))
            except Exception:
                pass

    if parts:
        return "\n\n".join(parts)

    # No local SEIF context — provide workspace status
    has_git = (cwd / ".git").is_dir()
    manifest = "none"
    for mf in ("pyproject.toml", "package.json", "Cargo.toml", "go.mod", "pom.xml", "Gemfile"):
        if (cwd / mf).exists():
            manifest = mf
            break

    return (
        f"[WORKSPACE STATUS: {cwd}]\n"
        f"No .seif/ structure found. This directory has not been initialized with S.E.I.F.\n"
        f"Git repo: {'yes' if has_git else 'no'} | Manifest: {manifest}\n"
        f"The user may benefit from running: seif-cli --init\n"
        f"If they ask what to do, guide them through initialization and available features."
    )


def _build_prompt() -> str:
    """Assemble full startup prompt: global + local layers."""
    global_prompt = _build_global_prompt()
    local_prompt = _build_local_prompt()
    return f"{global_prompt}\n\n{local_prompt}"


def _has_command(name: str) -> bool:
    """Check if a CLI command is available."""
    return shutil.which(name) is not None


def _launch_claude(prompt: str, print_mode: bool, extra_args: list[str]):
    """Launch Claude CLI with SEIF context."""
    if not _has_command("claude"):
        print("Error: Claude CLI not found. Install it first.", file=sys.stderr)
        sys.exit(1)

    args = ["claude"]
    if print_mode:
        args.append("--print")
    args.extend(["--append-system-prompt", prompt])
    args.extend(extra_args)

    os.execvp("claude", args)


def _launch_gemini(prompt: str, print_mode: bool, extra_args: list[str]):
    """Launch Gemini CLI with SEIF context."""
    if not _has_command("gemini"):
        print("Error: Gemini CLI not found. Install it first.", file=sys.stderr)
        sys.exit(1)

    args = ["gemini", "-m", "gemini-2.5-flash"]
    if print_mode:
        args.append("-p")
    args.extend(extra_args)

    subprocess.run(args, input=prompt, text=True)


def cmd_status():
    """Show context hierarchy."""
    print("═══ S.E.I.F. STATUS ═══")
    cwd = Path.cwd()
    print(f"CWD: {cwd}")
    print()

    # Local context
    if (cwd / "RESONANCE.json").exists():
        print("Local RESONANCE.json: FOUND")
    if (cwd / ".seif").is_dir():
        count = len(list((cwd / ".seif").glob("*.seif")))
        print(f"Local .seif/ modules: {count} files")
    print()

    # Global context
    resonance = get_resonance_path()
    print(f"RESONANCE.json: {resonance}")
    exists = resonance.exists()
    print(f"  Status: {'FOUND' if exists else 'NOT FOUND'}")

    if exists:
        try:
            from seif.core.resonance_signal import load_and_validate
            _, valid, msg = load_and_validate(str(resonance))
            print(f"  Validation: {'VALID' if valid else 'INVALID'} — {msg}")
        except Exception as e:
            print(f"  Validation: ERROR — {e}")
    print()

    # Modules
    try:
        modules = list_modules()
        tokens = estimate_tokens()
        print(f"Modules: {len(modules)}")
        for m in modules:
            marker = "[default]" if m.get("is_default") else "[user]"
            active = "" if m.get("active") else " (inactive)"
            print(f"  {marker} {m['source']} — {m['words']}w, "
                  f"{m['compression']:.0f}:1, coh={m['coherence']:.3f}{active}")
        print()
        print(f"Total tokens: ~{tokens['total']}")
        print(f"  Kernel: {tokens['kernel']} + Modules: {tokens['modules']}")
    except Exception as e:
        print(f"Module listing error: {e}")


def main():
    parser = argparse.ArgumentParser(
        prog="seif",
        description="S.E.I.F. Resonance Wrapper — launch AI sessions with SEIF context",
    )
    parser.add_argument("-g", "--gemini", action="store_true",
                        help="Use Gemini instead of Claude")
    parser.add_argument("-p", "--print", action="store_true", dest="print_mode",
                        help="Non-interactive (print mode)")
    parser.add_argument("--status", action="store_true",
                        help="Show context hierarchy")
    parser.add_argument("args", nargs="*", help="Extra arguments passed to the AI CLI")

    parsed = parser.parse_args()

    if parsed.status:
        cmd_status()
        return

    prompt = _build_prompt()

    if parsed.gemini:
        _launch_gemini(prompt, parsed.print_mode, parsed.args)
    else:
        _launch_claude(prompt, parsed.print_mode, parsed.args)


if __name__ == "__main__":
    main()
