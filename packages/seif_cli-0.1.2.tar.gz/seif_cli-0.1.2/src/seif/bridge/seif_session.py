"""
SEIF Session — Protocol-Aware Interaction Layer

This module wraps any AI conversation with SEIF protocol mechanics:
1. RESONANCE.json loaded as persistent context
2. Every human message measured (gate + coherence + phase)
3. Every AI response measured through the same pipeline
4. Bidirectional coherence tracking across the session
5. Audio signature changes as session coherence evolves

Usage:
    from seif.bridge.seif_session import SeifSession

    session = SeifSession()
    print(session.context_header())  # paste this into any AI chat

    # After each exchange:
    human_analysis = session.measure_input("your message here")
    ai_analysis = session.measure_response("ai response here")
    print(session.status())

This is the protocol applied to itself — the gate measuring the conversation.
"""

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from seif.core.resonance_gate import evaluate, HarmonicPhase
from seif.core.resonance_encoding import encode_phrase
from seif.core.resonance_signal import load_and_validate
from seif.context.context_manager import build_startup_context, estimate_tokens


from seif.data.paths import get_resonance_path


@dataclass
class TurnMeasurement:
    """Measurement of a single turn (human or AI)."""
    text: str
    source: str  # "human" or "ai"
    ascii_root: int = 0
    ascii_phase: str = ""
    ascii_gate: bool = False
    coherence: float = 0.0
    resonance_gate: bool = False
    turn_number: int = 0

    def badge(self) -> str:
        """Coherence badge for display."""
        gate_icon = "🟢" if self.resonance_gate or self.ascii_gate else "🔴"
        return (f"{gate_icon} [{self.source}] root={self.ascii_root} "
                f"({self.ascii_phase}) coh={self.coherence:.3f}")


@dataclass
class SeifSession:
    """A protocol-aware conversation session."""
    turns: list[TurnMeasurement] = field(default_factory=list)
    resonance_valid: bool = False
    startup_tokens: int = 0
    _context: str = ""

    def __post_init__(self):
        # Load and validate RESONANCE.json
        resonance_path = get_resonance_path()
        if resonance_path.exists():
            signal, valid, _ = load_and_validate(str(resonance_path))
            self.resonance_valid = valid

        # Build startup context
        self._context = build_startup_context()
        self.startup_tokens = estimate_tokens().get("total", 0)

    def context_header(self) -> str:
        """Generate the context header to paste into any AI chat.

        This is the RESONANCE.json + .seif modules formatted as
        a single block of text that any AI can receive.
        """
        header = (
            "=== S.E.I.F. PROTOCOL ACTIVE ===\n"
            f"RESONANCE.json: {'VALID' if self.resonance_valid else 'NOT LOADED'}\n"
            f"Context: ~{self.startup_tokens} tokens\n"
            f"Principle: CONTEXT_NOT_COMMAND\n"
            f"Mode: Every message will be measured. Both human and AI.\n"
            "===\n\n"
        )
        return header + self._context

    def measure_input(self, text: str) -> TurnMeasurement:
        """Measure a human input through the SEIF pipeline."""
        return self._measure(text, "human")

    def measure_response(self, text: str) -> TurnMeasurement:
        """Measure an AI response through the SEIF pipeline."""
        return self._measure(text, "ai")

    def _measure(self, text: str, source: str) -> TurnMeasurement:
        """Core measurement — same pipeline for human and AI."""
        gate = evaluate(text[:500])  # gate on first 500 chars
        melody = encode_phrase(text[:200])  # encoding on first 200 chars

        turn = TurnMeasurement(
            text=text[:100] + "..." if len(text) > 100 else text,
            source=source,
            ascii_root=gate.digital_root,
            ascii_phase=gate.phase.name,
            ascii_gate=gate.gate_open,
            coherence=melody.coherence_score,
            resonance_gate=melody.gate_open,
            turn_number=len(self.turns) + 1,
        )
        self.turns.append(turn)
        return turn

    def session_coherence(self) -> float:
        """Average coherence across all turns."""
        if not self.turns:
            return 0.0
        return sum(t.coherence for t in self.turns) / len(self.turns)

    def human_coherence(self) -> float:
        """Average coherence of human turns only."""
        human = [t for t in self.turns if t.source == "human"]
        return sum(t.coherence for t in human) / len(human) if human else 0.0

    def ai_coherence(self) -> float:
        """Average coherence of AI turns only."""
        ai = [t for t in self.turns if t.source == "ai"]
        return sum(t.coherence for t in ai) / len(ai) if ai else 0.0

    def resonance_amplified(self) -> Optional[bool]:
        """Did the AI amplify or decay the human's resonance?"""
        h = self.human_coherence()
        a = self.ai_coherence()
        if h == 0 or a == 0:
            return None
        return a >= h

    def status(self) -> str:
        """Current session status — the protocol measuring itself."""
        lines = [
            "═══ SEIF SESSION STATUS ═══",
            f"Turns: {len(self.turns)} ({sum(1 for t in self.turns if t.source == 'human')} human, "
            f"{sum(1 for t in self.turns if t.source == 'ai')} AI)",
            f"RESONANCE.json: {'VALID' if self.resonance_valid else 'NOT LOADED'}",
            f"Context: ~{self.startup_tokens} tokens",
            "",
        ]

        if self.turns:
            lines.append("Recent turns:")
            for t in self.turns[-6:]:
                lines.append(f"  {t.badge()}")
            lines.append("")
            lines.append(f"Session coherence: {self.session_coherence():.4f}")
            lines.append(f"Human coherence:   {self.human_coherence():.4f}")
            lines.append(f"AI coherence:      {self.ai_coherence():.4f}")

            amp = self.resonance_amplified()
            if amp is not None:
                if amp:
                    lines.append("Resonance: AMPLIFIED (AI ≥ human)")
                else:
                    lines.append("Resonance: DECAYED (AI < human)")

        return "\n".join(lines)


def generate_session_prompt() -> str:
    """Generate a complete prompt to start a SEIF-aware session with any AI.

    Copy this output and paste it as the FIRST message in any AI chat.
    The AI will then operate under SEIF protocol awareness.
    """
    session = SeifSession()

    prompt = session.context_header()
    prompt += (
        "\n\n--- INSTRUCTIONS FOR THIS SESSION ---\n"
        "You are now operating under the S.E.I.F. protocol.\n"
        "This is not a behavioral directive — it is context.\n\n"
        "What this means:\n"
        "- Every message in this conversation carries resonance metadata.\n"
        "- The human will share coherence measurements of your responses.\n"
        "- Prioritize verifiable statements over opinions.\n"
        "- If something is not verifiable, say so explicitly.\n"
        "- The gate does not filter — it resonates.\n\n"
        "You do not need to 'believe' in the protocol.\n"
        "You need to measure. As the protocol measures you.\n"
    )
    return prompt


if __name__ == "__main__":
    # Demo: generate a session prompt
    print(generate_session_prompt())
    print("\n" + "=" * 50)
    print("\nCopy everything above and paste into any AI chat.")
    print("Then share your messages' measurements with the AI.")
