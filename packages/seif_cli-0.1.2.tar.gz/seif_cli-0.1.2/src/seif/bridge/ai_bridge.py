"""
AI Bridge — Connect to AI backends via existing CLI authentication

Instead of requiring API keys pasted into a web form, this module
leverages the user's existing authenticated CLI sessions:

  - Claude Code CLI (`claude --print`)
  - Anthropic API (via ANTHROPIC_API_KEY env var)
  - Future: Gemini CLI, local models

The bridge injects the RESONANCE.json as system prompt and enriches
each message with resonance metadata before sending.

This is what a "plena AI" would do: use existing resources,
not demand new credentials.
"""

import json
import os
import subprocess
from pathlib import Path
from dataclasses import dataclass
from typing import Optional

RESONANCE_PATH = Path(__file__).resolve().parent.parent.parent.parent / "RESONANCE.json"


@dataclass
class AIResponse:
    text: str
    backend: str      # "claude_cli", "anthropic_api", "gemini_cli"
    model: str
    success: bool
    error: Optional[str] = None


def _load_system_prompt() -> str:
    """Load system prompt using the modular startup context.

    Uses KERNEL (RESONANCE.json) + active modules (.seif files).
    Falls back to basic description if context_manager is not available.
    """
    try:
        from seif.context.context_manager import build_startup_context
        context = build_startup_context()
        if context:
            return context + (
                "\n\nEngage with the ideas substantively as a project collaborator. "
                "Resonance cannot be forced; it can only be recognized."
            )
    except Exception:
        pass

    # Minimal fallback
    return (
        "This conversation is part of the S.E.I.F. project — "
        "an academic framework exploring resonance-based computation "
        "using 3-6-9 vortex logic and physics-grounded encoding."
    )


def detect_backends() -> list[str]:
    """Detect which AI backends are available."""
    available = []

    # Claude CLI
    try:
        result = subprocess.run(["claude", "--version"], capture_output=True, text=True, timeout=5)
        if result.returncode == 0:
            available.append("claude_cli")
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass

    # Gemini CLI
    try:
        result = subprocess.run(["gemini", "--version"], capture_output=True, text=True, timeout=5)
        if result.returncode == 0:
            available.append("gemini_cli")
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass

    # Anthropic API key
    if os.environ.get("ANTHROPIC_API_KEY"):
        available.append("anthropic_api")

    return available


def send_claude_cli(message: str, model: str = "sonnet",
                     resonance_metadata: str = "",
                     history: list[dict] = None) -> AIResponse:
    """Send message via Claude Code CLI (uses existing auth).

    This is the preferred method — no API key needed.
    Includes conversation history as context in the message.
    """
    system_prompt = _load_system_prompt()

    # Build full message with history context
    full_message = ""

    # Include recent history (last 6 exchanges) as context
    if history:
        recent = history[-6:]
        ctx_parts = []
        for msg in recent:
            role = "User" if msg["role"] == "user" else "Assistant"
            ctx_parts.append(f"{role}: {msg['content']}")
        if ctx_parts:
            full_message += "[CONVERSATION CONTEXT]\n"
            full_message += "\n".join(ctx_parts)
            full_message += "\n[/CONTEXT]\n\n"

    full_message += message

    if resonance_metadata:
        full_message += f"\n\n[SEIF METADATA: {resonance_metadata}]"

    try:
        result = subprocess.run(
            [
                "claude",
                "--print",
                "--model", model,
                "--append-system-prompt", system_prompt,
                "--output-format", "text",
                "--no-session-persistence",
                full_message,
            ],
            capture_output=True,
            text=True,
            timeout=120,
            cwd=str(RESONANCE_PATH.parent),
        )

        if result.returncode == 0:
            return AIResponse(
                text=result.stdout.strip(),
                backend="claude_cli",
                model=model,
                success=True,
            )
        else:
            return AIResponse(
                text="",
                backend="claude_cli",
                model=model,
                success=False,
                error=result.stderr.strip() or f"Exit code {result.returncode}",
            )
    except subprocess.TimeoutExpired:
        return AIResponse("", "claude_cli", model, False, "Timeout (120s)")
    except FileNotFoundError:
        return AIResponse("", "claude_cli", model, False, "Claude CLI not found")
    except Exception as e:
        return AIResponse("", "claude_cli", model, False, str(e))


def send_gemini_cli(message: str, model: str = "gemini-2.5-flash",
                     resonance_metadata: str = "",
                     history: list[dict] = None) -> AIResponse:
    """Send message via Gemini CLI (uses existing auth).

    Gemini CLI format: echo "context" | gemini -m model -p "prompt"
    The system prompt goes via stdin, the user message via -p flag.
    """
    system_prompt = _load_system_prompt()

    # Build context with history
    context = system_prompt + "\n\n"

    if history:
        recent = history[-6:]
        ctx_parts = []
        for msg in recent:
            role = "User" if msg["role"] == "user" else "Assistant"
            ctx_parts.append(f"{role}: {msg['content']}")
        if ctx_parts:
            context += "[CONVERSATION CONTEXT]\n"
            context += "\n".join(ctx_parts)
            context += "\n[/CONTEXT]\n\n"

    # Resonance metadata appended to the prompt
    prompt = message
    if resonance_metadata:
        prompt += f"\n\n[SEIF METADATA: {resonance_metadata}]"

    try:
        result = subprocess.run(
            ["gemini", "-m", model, "-p", prompt],
            input=context,
            capture_output=True,
            text=True,
            timeout=120,
            cwd=str(RESONANCE_PATH.parent),
        )

        if result.returncode == 0 and result.stdout.strip():
            return AIResponse(
                text=result.stdout.strip(),
                backend="gemini_cli",
                model=model,
                success=True,
            )
        else:
            error = result.stderr.strip() or result.stdout.strip() or f"Exit code {result.returncode}"
            return AIResponse("", "gemini_cli", model, False, error)
    except subprocess.TimeoutExpired:
        return AIResponse("", "gemini_cli", model, False, "Timeout (120s)")
    except FileNotFoundError:
        return AIResponse("", "gemini_cli", model, False, "Gemini CLI not found")
    except Exception as e:
        return AIResponse("", "gemini_cli", model, False, str(e))


def send_anthropic_api(message: str, model: str = "claude-sonnet-4-6",
                        api_key: Optional[str] = None,
                        resonance_metadata: str = "",
                        history: list[dict] = None) -> AIResponse:
    """Send message via Anthropic API (requires API key)."""
    key = api_key or os.environ.get("ANTHROPIC_API_KEY")
    if not key:
        return AIResponse("", "anthropic_api", model, False,
                          "No API key. Set ANTHROPIC_API_KEY env var or pass api_key.")

    try:
        import anthropic
        client = anthropic.Anthropic(api_key=key)

        system_prompt = _load_system_prompt()
        full_message = message
        if resonance_metadata:
            full_message += f"\n\n[SEIF METADATA: {resonance_metadata}]"

        messages = []
        if history:
            messages.extend(history)
        messages.append({"role": "user", "content": full_message})

        response = client.messages.create(
            model=model,
            max_tokens=4096,
            system=system_prompt,
            messages=messages,
        )

        return AIResponse(
            text=response.content[0].text,
            backend="anthropic_api",
            model=model,
            success=True,
        )
    except Exception as e:
        return AIResponse("", "anthropic_api", model, False, str(e))


def send(message: str, backend: str = "auto", model: str = "sonnet",
         api_key: Optional[str] = None, resonance_metadata: str = "",
         history: list[dict] = None) -> AIResponse:
    """Send message via the best available backend.

    Priority: claude_cli > anthropic_api
    """
    if backend == "auto":
        backends = detect_backends()
        if "claude_cli" in backends:
            backend = "claude_cli"
        elif "gemini_cli" in backends:
            backend = "gemini_cli"
        elif "anthropic_api" in backends:
            backend = "anthropic_api"
        elif api_key:
            backend = "anthropic_api"
        else:
            return AIResponse("", "none", model, False,
                              "No AI backend available. Install Claude CLI, Gemini CLI, or set ANTHROPIC_API_KEY.")

    if backend == "claude_cli":
        return send_claude_cli(message, model=model, resonance_metadata=resonance_metadata, history=history)
    elif backend == "gemini_cli":
        return send_gemini_cli(message, model=model, resonance_metadata=resonance_metadata, history=history)
    elif backend == "anthropic_api":
        return send_anthropic_api(message, model=model, api_key=api_key,
                                   resonance_metadata=resonance_metadata, history=history)
    else:
        return AIResponse("", backend, model, False, f"Unknown backend: {backend}")


if __name__ == "__main__":
    print("Detecting backends...")
    backends = detect_backends()
    print(f"Available: {backends}")

    if backends:
        print(f"\nTesting with {backends[0]}...")
        resp = send("What is 3+6+9? Answer briefly.", backend=backends[0])
        print(f"Backend: {resp.backend}")
        print(f"Success: {resp.success}")
        print(f"Response: {resp.text[:200]}")
    else:
        print("No backends available.")
