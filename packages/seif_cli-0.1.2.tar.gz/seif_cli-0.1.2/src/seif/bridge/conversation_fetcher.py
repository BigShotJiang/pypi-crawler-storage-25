"""
Conversation Fetcher — Import Gemini shared conversations

Fetches a Gemini share URL via playwright (headless browser),
parses the conversation structure, and outputs clean markdown.

Only works with PUBLIC share URLs (gemini.google.com/share/xxx).
Does NOT work with authenticated app URLs (requires login cookies).

Processing in chunks to handle large conversations without timeout.
"""

import subprocess
import tempfile
import re
from pathlib import Path
from typing import Optional
from dataclasses import dataclass


@dataclass
class FetchResult:
    success: bool
    raw_lines: int
    markdown: str
    turns: int
    error: Optional[str] = None


FETCH_SCRIPT = """
const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage();
  try {
    await page.goto(process.argv[2], {
      waitUntil: 'domcontentloaded',
      timeout: 30000
    });
    await page.waitForTimeout(10000);
    const content = await page.evaluate(() => document.body.innerText);
    process.stdout.write(content);
  } catch(e) {
    process.stderr.write('Error: ' + e.message);
    process.exit(1);
  }
  await browser.close();
})();
"""


def _parse_raw_to_markdown(raw_text: str) -> tuple[str, int]:
    """Parse raw Gemini page text into clean conversation markdown.

    Returns (markdown, turn_count).
    """
    lines = raw_text.split("\n")

    # Skip header/footer boilerplate
    content_lines = []
    in_content = False
    for line in lines:
        stripped = line.strip()
        if stripped == "You said" or (in_content and stripped):
            in_content = True
        if in_content:
            if stripped in ("Google Privacy Policy", "Sign in", "Gemini may display inaccurate"):
                break
            content_lines.append(line)

    # Parse into turns
    markdown_parts = []
    current_role = None
    current_text = []
    turns = 0

    for line in content_lines:
        stripped = line.strip()

        if stripped == "You said":
            if current_role and current_text:
                markdown_parts.append(f"## {current_role}\n")
                markdown_parts.append("\n".join(current_text).strip())
                markdown_parts.append("\n\n---\n\n")
            current_role = "Usuário"
            current_text = []
            turns += 1
            continue

        # Gemini responses start after "You said" section ends
        # They don't have an explicit marker — they're the text between "You said" blocks
        if current_role == "Usuário" and not stripped:
            # Empty line after user message = start of Gemini response
            if current_text:
                markdown_parts.append(f"## {current_role}\n\n")
                markdown_parts.append("\n".join(current_text).strip())
                markdown_parts.append("\n\n---\n\n")
                current_role = "Gemini"
                current_text = []
                continue

        current_text.append(line)

    # Flush last part
    if current_role and current_text:
        markdown_parts.append(f"## {current_role}\n\n")
        markdown_parts.append("\n".join(current_text).strip())
        markdown_parts.append("\n")

    return "".join(markdown_parts), turns


def fetch_gemini_share(url: str) -> FetchResult:
    """Fetch a Gemini shared conversation and convert to markdown.

    Args:
        url: Gemini share URL (gemini.google.com/share/xxx)

    Returns:
        FetchResult with markdown content
    """
    # Validate URL — accept both full and short URLs
    if not any(pattern in url for pattern in [
        "gemini.google.com/share/",
        "g.co/gemini/share/",
        "gemini.google.com/app/share/",
    ]):
        return FetchResult(False, 0, "", 0,
                           "URL must be a Gemini share link (gemini.google.com/share/xxx or g.co/gemini/share/xxx)")

    # Write fetch script to /tmp (where playwright node_modules lives)
    script_path = "/tmp/seif_fetch_gemini.js"
    with open(script_path, 'w') as f:
        f.write(FETCH_SCRIPT)

    try:
        result = subprocess.run(
            ["node", script_path, url],
            capture_output=True,
            text=True,
            timeout=60,
            cwd=str(Path(__file__).resolve().parent.parent.parent.parent.parent),  # project root with node_modules
        )

        if result.returncode != 0:
            return FetchResult(False, 0, "", 0,
                               f"Fetch failed: {result.stderr.strip()[:200]}")

        raw = result.stdout
        raw_lines = len(raw.split("\n"))

        if raw_lines < 20:
            return FetchResult(False, raw_lines, "", 0,
                               "Page returned too few lines — may need authentication")

        markdown, turns = _parse_raw_to_markdown(raw)

        return FetchResult(
            success=True,
            raw_lines=raw_lines,
            markdown=markdown,
            turns=turns,
        )

    except subprocess.TimeoutExpired:
        return FetchResult(False, 0, "", 0, "Timeout (60s) — page may be too large")
    except FileNotFoundError:
        return FetchResult(False, 0, "", 0,
                           "Node.js not found. Install: brew install node")
    except Exception as e:
        return FetchResult(False, 0, "", 0, str(e))
    finally:
        Path(script_path).unlink(missing_ok=True)


def update_conversa_md(new_markdown: str, conversa_path: str = "conversa.md",
                        preserve_before_line: int = 2000) -> dict:
    """Update conversa.md preserving content before a given line.

    Args:
        new_markdown: Full conversation markdown from fetch
        conversa_path: Path to conversa.md
        preserve_before_line: Keep existing content before this line unchanged

    Returns:
        dict with stats
    """
    path = Path(conversa_path)
    if not path.exists():
        # Write entirely new
        path.write_text(new_markdown, encoding="utf-8")
        return {"action": "created", "lines": len(new_markdown.split("\n"))}

    existing = path.read_text(encoding="utf-8")
    existing_lines = existing.split("\n")

    if preserve_before_line > 0 and len(existing_lines) > preserve_before_line:
        # Keep first N lines, replace the rest
        preserved = "\n".join(existing_lines[:preserve_before_line])
        new_lines = new_markdown.split("\n")

        # Try to find overlap point
        # Use the last preserved line to find where new content should start
        result = preserved + "\n" + new_markdown
        path.write_text(result, encoding="utf-8")

        return {
            "action": "merged",
            "preserved_lines": preserve_before_line,
            "new_lines": len(new_lines),
            "total_lines": len(result.split("\n")),
        }
    else:
        path.write_text(new_markdown, encoding="utf-8")
        return {"action": "replaced", "lines": len(new_markdown.split("\n"))}
