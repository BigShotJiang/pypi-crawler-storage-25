"""
Evolution Tracker — Cross-Session Coherence Persistence

Records the Session Resonance Score after each session and tracks
the evolution of coherence over time. This implements:

  - Grok's proposal #1 (adapted): session-level feedback without "auto-evolution"
  - Grok's proposal #6: human persistence layer (intention tracked across sessions)
  - The fundamental asymmetry: machine measures (discrete), human persists (continuous)

Storage: evolution.json in data/sessions/
Format: append-only log of session scores with timestamps (rolling window of 50).

Intent persistence: the human's intention is hashed (sha256) on first session.
Subsequent sessions measure intent drift — did the human's focus change?
The machine never interprets the intention. It only measures resonance.

No parameters are modified. No thresholds are adjusted. The tracker
MEASURES evolution — it does not IMPOSE it. Consistent with
CONTEXT_NOT_COMMAND.
"""

import hashlib
import json
from datetime import datetime, timezone
from difflib import SequenceMatcher
from pathlib import Path
from typing import Optional

DATA_DIR = Path(__file__).resolve().parent.parent.parent.parent / "data" / "sessions"
EVOLUTION_FILE = DATA_DIR / "evolution.json"

MAX_HISTORY = 50  # rolling window — prevents infinite growth


def _intent_hash(text: str) -> str:
    """SHA-256 hash of normalized intention text."""
    return hashlib.sha256(text.strip().lower().encode("utf-8")).hexdigest()


def _load_evolution() -> list[dict]:
    """Load the evolution log."""
    if not EVOLUTION_FILE.exists():
        return []
    with open(EVOLUTION_FILE, "r", encoding="utf-8") as f:
        try:
            return json.load(f)
        except json.JSONDecodeError:
            return []


def _save_evolution(records: list[dict]):
    """Save the evolution log (with rolling window)."""
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    # Rolling window: keep only last MAX_HISTORY entries
    if len(records) > MAX_HISTORY:
        records = records[-MAX_HISTORY:]
    with open(EVOLUTION_FILE, "w", encoding="utf-8") as f:
        json.dump(records, f, ensure_ascii=False, indent=2)


def record_session(session_id: str, score: dict, total_turns: int,
                   human_intention: Optional[str] = None):
    """Record a completed session's resonance score.

    Args:
        session_id: The session identifier.
        score: The session_resonance_score dict from telemetry.
        total_turns: Number of turns in the session.
        human_intention: Optional free-text description of what the human
                        was pursuing in this session (persistence layer).
    """
    records = _load_evolution()

    entry = {
        "session_id": session_id,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "total_turns": total_turns,
        "score": score.get("score", 0.0),
        "gate_ratio": score.get("gate_ratio", 0.0),
        "coherence": score.get("coherence", 0.0),
        "evolution": score.get("evolution", 0.0),
        "status": score.get("status", "NO_DATA"),
        "human_intention": human_intention,
    }

    # Intent hash: track persistence of human focus across sessions
    if human_intention:
        entry["intent_hash"] = _intent_hash(human_intention)

    records.append(entry)
    _save_evolution(records)


def get_evolution_trend(last_n: int = 10) -> dict:
    """Analyze coherence evolution across the last N sessions.

    Returns:
        trend: ASCENDING / STABLE / DESCENDING
        avg_score: mean session score
        best_session: highest scoring session
        total_sessions: number of sessions tracked
        scores: list of (session_id, score) pairs
    """
    records = _load_evolution()
    if not records:
        return {
            "trend": "NO_DATA",
            "avg_score": 0.0,
            "best_session": None,
            "total_sessions": 0,
            "scores": [],
        }

    recent = records[-last_n:]
    scores = [r["score"] for r in recent]
    avg = sum(scores) / len(scores)

    # Trend: compare first half vs second half
    if len(scores) >= 4:
        first_half = scores[:len(scores) // 2]
        second_half = scores[len(scores) // 2:]
        diff = (sum(second_half) / len(second_half)) - (sum(first_half) / len(first_half))
        if diff > 0.05:
            trend = "ASCENDING"
        elif diff < -0.05:
            trend = "DESCENDING"
        else:
            trend = "STABLE"
    elif len(scores) >= 2:
        trend = "ASCENDING" if scores[-1] > scores[0] else "STABLE"
    else:
        trend = "INITIAL"

    best = max(recent, key=lambda r: r["score"])

    return {
        "trend": trend,
        "avg_score": round(avg, 4),
        "best_session": {
            "session_id": best["session_id"],
            "score": best["score"],
            "status": best["status"],
        },
        "total_sessions": len(records),
        "scores": [(r["session_id"], r["score"]) for r in recent],
    }


def get_human_intentions() -> list[dict]:
    """Retrieve all recorded human intentions (persistence layer).

    Returns intentions with their timestamps and associated session scores,
    enabling tracking of how a persistent human intention correlates with
    measured coherence over time.
    """
    records = _load_evolution()
    return [
        {
            "session_id": r["session_id"],
            "timestamp": r["timestamp"],
            "intention": r["human_intention"],
            "intent_hash": r.get("intent_hash"),
            "score": r["score"],
            "status": r["status"],
        }
        for r in records
        if r.get("human_intention")
    ]


def measure_intent_drift(new_intention: str) -> dict:
    """Measure whether a new intention still resonates with the persistent one.

    The machine does not interpret the intention. It measures:
      1. Hash match: is the intention textually identical? (perfect persistence)
      2. Similarity: how close is the new text to the original? (drift measurement)
      3. Coherence correlation: does changing intention correlate with score changes?

    Returns:
        resonance: "persistent" / "drifting" / "shifted" / "no_history"
        similarity: 0.0 to 1.0 (SequenceMatcher ratio)
        original_intention: the first recorded intention (anchor)
        drift_direction: "convergent" / "stable" / "divergent"
    """
    intentions = get_human_intentions()
    if not intentions:
        return {
            "resonance": "no_history",
            "similarity": 1.0,
            "original_intention": None,
            "drift_direction": "initial",
        }

    original = intentions[0]
    original_text = original["intention"]
    new_hash = _intent_hash(new_intention)

    # Perfect match: same intention persists
    if new_hash == original.get("intent_hash"):
        return {
            "resonance": "persistent",
            "similarity": 1.0,
            "original_intention": original_text,
            "drift_direction": "stable",
        }

    # Similarity measurement (no external deps)
    similarity = SequenceMatcher(
        None,
        new_intention.strip().lower(),
        original_text.strip().lower(),
    ).ratio()

    # Classify drift
    if similarity > 0.7:
        resonance = "persistent"
        direction = "stable"
    elif similarity > 0.4:
        resonance = "drifting"
        # Check if score is improving despite drift
        if len(intentions) >= 2:
            recent_scores = [i["score"] for i in intentions[-3:]]
            early_scores = [i["score"] for i in intentions[:3]]
            if sum(recent_scores) / len(recent_scores) > sum(early_scores) / len(early_scores):
                direction = "convergent"
            else:
                direction = "divergent"
        else:
            direction = "stable"
    else:
        resonance = "shifted"
        direction = "divergent"

    return {
        "resonance": resonance,
        "similarity": round(similarity, 4),
        "original_intention": original_text,
        "drift_direction": direction,
    }
