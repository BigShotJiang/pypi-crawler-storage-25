"""
Context Manager — Modular SEIF Context System

Architecture:
  RESONANCE.json = KERNEL (auto-authenticating, ~2000 tokens)
  *.seif files   = MODULES (compressed context, ~500 tokens each)

  Agent receives: KERNEL + active MODULES = 3000-5000 tokens
  vs raw text:    50,000+ tokens (quality degradation)

The .seif format (SEIF Encoded Insight File) stores:
  - Source file metadata
  - Agent-generated summary (the agent chose what matters)
  - Resonance validation (coherence, gate, root)
  - Verified data points (equations, measurements, rules)
  - Integrity hash

Storage: data/modules/*.seif
"""

import json
import hashlib
from dataclasses import dataclass, asdict, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from seif.core.resonance_gate import evaluate
from seif.core.resonance_encoding import encode_phrase
from seif.core.resonance_signal import load_and_validate

from seif.data.paths import get_resonance_path, get_defaults_dir, get_modules_dir

MODULES_DIR = get_modules_dir()
DEFAULTS_DIR = get_defaults_dir()
RESONANCE_PATH = get_resonance_path()


@dataclass
class SeifModule:
    """A compressed context module in .seif format."""
    _instruction: str = (
        "This is a S.E.I.F. compressed context module. "
        "Read the 'summary' field — it contains the full project context "
        "compressed from thousands of words to hundreds, with verified data points "
        "and an integrity hash. Protocol: github.com/and2carvalho/seif"
    )
    protocol: str = "SEIF-MODULE-v1"
    source: str = ""
    original_words: int = 0
    compressed_words: int = 0
    compression_ratio: float = 0
    summary: str = ""
    resonance: dict = field(default_factory=dict)
    verified_data: list[str] = field(default_factory=list)
    integrity_hash: str = ""
    active: bool = True
    # v2 collaborative fields (defaults preserve v1 backward compatibility)
    version: int = 1
    contributors: list[dict] = field(default_factory=list)
    parent_hash: Optional[str] = None
    updated_at: Optional[str] = None
    classification: Optional[str] = None   # PUBLIC | INTERNAL | CONFIDENTIAL


def _compute_hash(summary: str) -> str:
    return hashlib.sha256(summary.encode()).hexdigest()[:16]


def _extract_verified_data(text: str, limit: int = 20) -> list[str]:
    """Extract verified data points: lines starting with numbers, equations, or measurements."""
    verified = []
    for line in text.split("\n"):
        line = line.strip().lstrip("- •")
        if any(c.isdigit() for c in line[:20]) and len(line) > 10:
            verified.append(line[:200])
    return verified[:limit]


def create_module(source_name: str, original_words: int,
                  summary: str, author: str = None,
                  via: str = None) -> SeifModule:
    """Create a .seif module from an agent-generated summary."""
    summary_words = len(summary.split())
    compression = original_words / summary_words if summary_words > 0 else 0

    gate = evaluate(summary[:500])
    melody = encode_phrase(summary[:200])

    verified = _extract_verified_data(summary)

    contributors = []
    if author:
        contributors.append({
            "author": author,
            "at": datetime.now(timezone.utc).isoformat(),
            "via": via or "local",
            "action": "created",
        })

    module = SeifModule(
        source=source_name,
        original_words=original_words,
        compressed_words=summary_words,
        compression_ratio=round(compression, 1),
        summary=summary,
        resonance={
            "ascii_root": gate.digital_root,
            "ascii_phase": gate.phase.name,
            "coherence": melody.coherence_score,
            "gate": "OPEN" if melody.gate_open else "CLOSED",
        },
        verified_data=verified,
        integrity_hash=_compute_hash(summary),
        contributors=contributors,
    )
    return module


def save_module(module: SeifModule, filename: str = None,
                target_path: Path = None) -> Path:
    """Save module as .seif file.

    Args:
        module: The module to save.
        filename: Filename within MODULES_DIR (used when target_path is None).
        target_path: Full path to write to (overrides filename/MODULES_DIR).
    """
    if target_path:
        target_path.parent.mkdir(parents=True, exist_ok=True)
        path = target_path
    else:
        MODULES_DIR.mkdir(parents=True, exist_ok=True)
        if filename is None:
            safe = "".join(c if c.isalnum() or c in "_-" else "_" for c in module.source)
            filename = f"{safe[:50]}.seif"
        path = MODULES_DIR / filename
    with open(path, "w", encoding="utf-8") as f:
        json.dump(asdict(module), f, indent=2, ensure_ascii=False)
    return path


def load_module(path: str) -> SeifModule:
    """Load a .seif module."""
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    return SeifModule(**data)


def contribute_to_module(
    module_path: str,
    contribution_text: str,
    author: str = "unknown",
    via: str = "local",
) -> tuple[SeifModule, Path]:
    """Add a contribution to an existing .seif module.

    Creates a hash-chained provenance trail: each contribution records
    who contributed, when, via which tool, and links to the previous
    version's integrity hash.

    Args:
        module_path: Path to existing .seif file.
        contribution_text: New content to merge into the module.
        author: Who is contributing.
        via: Tool/model used (e.g. "claude-opus", "gemini").

    Returns:
        Tuple of (updated module, path where it was saved).
    """
    path = Path(module_path)
    module = load_module(str(path))

    now_iso = datetime.now(timezone.utc).isoformat()
    old_hash = module.integrity_hash

    # Append contributor
    module.contributors.append({
        "author": author,
        "at": now_iso,
        "via": via,
        "action": "contributed",
    })

    # Merge summary: append new section with contributor header
    section = (
        f"\n\n---\n### Contribution by {author} ({now_iso[:10]})\n"
        f"{contribution_text}"
    )
    module.summary += section

    # Extract and merge verified data (cap at 40 for collaborative modules)
    new_verified = _extract_verified_data(contribution_text, limit=20)
    module.verified_data = (module.verified_data + new_verified)[:40]

    # Recalculate stats
    module.compressed_words = len(module.summary.split())
    if module.original_words > 0:
        module.compression_ratio = round(
            module.original_words / module.compressed_words, 1
        )

    # Recalculate resonance
    gate = evaluate(module.summary[:500])
    melody = encode_phrase(module.summary[:200])
    module.resonance = {
        "ascii_root": gate.digital_root,
        "ascii_phase": gate.phase.name,
        "coherence": melody.coherence_score,
        "gate": "OPEN" if melody.gate_open else "CLOSED",
    }

    # Chain: link to previous version
    module.parent_hash = old_hash
    module.version += 1
    module.protocol = "SEIF-MODULE-v2"
    module.updated_at = now_iso
    module.integrity_hash = _compute_hash(module.summary)

    saved_path = save_module(module, target_path=path)
    return module, saved_path


def scan_docs_folder(folder_path: str, backend: str = "auto",
                      model: str = "sonnet", save_as_default: bool = False) -> list[SeifModule]:
    """Scan a folder of .md files and compress each into a .seif module.

    The agent summarizes each file (STATE). We don't dictate content (DIRECTION).
    Results saved to data/defaults/ (if save_as_default) or data/modules/.
    """
    from seif.context.context_importer import summarize_via_agent

    folder = Path(folder_path)
    if not folder.exists():
        return []

    target_dir = DEFAULTS_DIR if save_as_default else MODULES_DIR
    target_dir.mkdir(parents=True, exist_ok=True)

    md_files = sorted(folder.rglob("*.md"))
    results = []

    for md_path in md_files:
        try:
            content = md_path.read_text(encoding="utf-8")
            words = len(content.split())
            if words < 20:  # skip trivially small files
                continue

            summary, success, error = summarize_via_agent(content, backend, model)
            if not success:
                continue

            module = create_module(str(md_path.relative_to(folder)), words, summary)
            safe_name = str(md_path.relative_to(folder)).replace("/", "_").replace(" ", "_")
            save_module(module, f"{safe_name[:60]}.seif")
            results.append(module)
        except Exception:
            continue

    # Save manifest
    manifest = {
        "source_folder": str(folder),
        "files_processed": len(results),
        "total_original_words": sum(m.original_words for m in results),
        "total_compressed_words": sum(m.compressed_words for m in results),
    }
    manifest_path = target_dir / "manifest.json"
    with open(manifest_path, "w") as f:
        json.dump(manifest, f, indent=2)

    return results


def list_modules(include_defaults: bool = True) -> list[dict]:
    """List all available .seif modules (user + defaults)."""
    MODULES_DIR.mkdir(parents=True, exist_ok=True)
    DEFAULTS_DIR.mkdir(parents=True, exist_ok=True)

    modules = []

    # Defaults first (versionados)
    if include_defaults:
        for f in sorted(DEFAULTS_DIR.glob("*.seif")):
            try:
                m = load_module(str(f))
                modules.append({
                    "path": str(f), "filename": f.name,
                    "source": m.source, "words": m.compressed_words,
                    "tokens_est": int(m.compressed_words * 1.3),
                    "compression": m.compression_ratio,
                    "coherence": m.resonance.get("coherence", 0),
                    "gate": m.resonance.get("gate", "?"),
                    "active": m.active, "is_default": True,
                })
            except Exception:
                pass

    # User modules
    for f in sorted(MODULES_DIR.glob("*.seif")):
        try:
            m = load_module(str(f))
            modules.append({
                "path": str(f), "filename": f.name,
                "source": m.source, "words": m.compressed_words,
                "tokens_est": int(m.compressed_words * 1.3),
                "compression": m.compression_ratio,
                "coherence": m.resonance.get("coherence", 0),
                "gate": m.resonance.get("gate", "?"),
                "active": m.active, "is_default": False,
            })
        except Exception:
            pass
    return modules


def get_active_modules() -> list[SeifModule]:
    """Load all active modules (defaults + user)."""
    result = []
    for info in list_modules(include_defaults=True):
        if info["active"]:
            result.append(load_module(info["path"]))
    return result


def toggle_module(path: str, active: bool):
    """Activate or deactivate a module."""
    m = load_module(path)
    m.active = active
    save_module(m, Path(path).name)


def build_startup_context() -> str:
    """Build the complete startup context: KERNEL + active modules.

    This replaces raw text system prompts with compressed, validated,
    resonance-aware context. Each module contributes ~500 tokens
    instead of the original ~5000+.
    """
    parts = []

    # KERNEL: inject full RESONANCE.json (the self-authenticating signal)
    # The complete JSON carries ALL verifiable data: transfer function,
    # harmonics, geometry, seed analysis, cosmic anchors, integrity hash.
    # A summary paragraph loses data. The full signal is ~862 tokens.
    if RESONANCE_PATH.exists():
        try:
            signal, valid, _ = load_and_validate(str(RESONANCE_PATH))
            if valid:
                import json
                compact = json.dumps(signal, ensure_ascii=False, separators=(",", ":"))
                parts.append(
                    f"KERNEL (RESONANCE.json, verified):\n{compact}"
                )
        except Exception:
            pass

    # MODULES: active .seif files
    # Modules are already compressed — truncating compressed text wastes work.
    # Budget: ~2500 chars per module (≈500 words ≈ 650 tokens).
    active = get_active_modules()
    for m in active:
        parts.append(
            f"MODULE ({m.source}, {m.compression_ratio:.0f}:1 compression, "
            f"coherence={m.resonance.get('coherence', 0):.3f}):\n"
            f"{m.summary[:2500]}"
        )

    total_tokens = sum(len(p.split()) for p in parts) * 1.3

    context = "\n\n---\n\n".join(parts)
    context += (
        f"\n\n[Context: KERNEL + {len(active)} modules, "
        f"~{int(total_tokens)} tokens. "
        f"Messages include [SEIF METADATA] with resonance analysis.]"
    )
    return context


def estimate_tokens() -> dict:
    """Estimate total tokens for current configuration."""
    kernel_tokens = 300  # approximate
    modules = get_active_modules()
    module_tokens = sum(int(m.compressed_words * 1.3) for m in modules)
    return {
        "kernel": kernel_tokens,
        "modules": module_tokens,
        "module_count": len(modules),
        "total": kernel_tokens + module_tokens,
    }
