"""
Telemetry — Session Recording and Resonance Analytics

Records every interaction (user input + AI response) with full resonance
metadata for both sides. Enables analysis of:
  - Does the AI "resonate back"? (response coherence vs input coherence)
  - Does coherence increase over a conversation? (harmonic convergence)
  - Which inputs produce the deepest AI engagement? (gate correlation)

Storage: JSONL (one JSON object per line per turn) in data/sessions/

This is research data — every interaction is a data point for the thesis.
"""

import json
import os
from datetime import datetime, timezone
from pathlib import Path
from dataclasses import dataclass, asdict
from typing import Optional

DATA_DIR = Path(__file__).resolve().parent.parent.parent.parent / "data" / "sessions"


@dataclass
class TurnRecord:
    """One turn of conversation (user + assistant)."""
    session_id: str
    turn_number: int
    timestamp: str

    # User side
    user_text: str
    user_ascii_root: int
    user_ascii_phase: str
    user_ascii_gate: str
    user_resonance_coherence: float
    user_resonance_gate: str
    user_mode: str
    user_cosmic_anchors: list[str]
    user_asymmetry: str

    # Assistant side
    assistant_text: str
    assistant_ascii_root: Optional[int] = None
    assistant_ascii_phase: Optional[str] = None
    assistant_ascii_gate: Optional[str] = None
    assistant_resonance_coherence: Optional[float] = None
    assistant_resonance_gate: Optional[str] = None
    assistant_mode: Optional[str] = None
    assistant_backend: Optional[str] = None
    assistant_model: Optional[str] = None

    # Artifacts generated
    artifacts: Optional[dict] = None


def _ensure_dir():
    DATA_DIR.mkdir(parents=True, exist_ok=True)


def generate_session_id() -> str:
    """Generate a unique session ID based on timestamp."""
    return datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")


def record_turn(record: TurnRecord):
    """Append a turn record to the session's JSONL file."""
    _ensure_dir()
    filepath = DATA_DIR / f"{record.session_id}.jsonl"
    with open(filepath, "a", encoding="utf-8") as f:
        f.write(json.dumps(asdict(record), ensure_ascii=False) + "\n")


def load_session(session_id: str) -> list[TurnRecord]:
    """Load all turns from a session."""
    filepath = DATA_DIR / f"{session_id}.jsonl"
    if not filepath.exists():
        return []

    turns = []
    with open(filepath, "r", encoding="utf-8") as f:
        for line in f:
            if line.strip():
                data = json.loads(line)
                turns.append(TurnRecord(**data))
    return turns


def list_sessions() -> list[dict]:
    """List all available sessions with metadata."""
    _ensure_dir()
    sessions = []
    for f in sorted(DATA_DIR.glob("*.jsonl"), reverse=True):
        turns = 0
        first_input = ""
        with open(f) as fh:
            for i, line in enumerate(fh):
                if line.strip():
                    turns += 1
                    if i == 0:
                        try:
                            first_input = json.loads(line).get("user_text", "")[:50]
                        except:
                            pass
        sessions.append({
            "session_id": f.stem,
            "turns": turns,
            "preview": first_input,
            "path": str(f),
        })
    return sessions


def session_analytics(session_id: str) -> dict:
    """Compute resonance analytics for a session."""
    turns = load_session(session_id)
    if not turns:
        return {"error": "No turns found"}

    user_coherences = [t.user_resonance_coherence for t in turns]
    asst_coherences = [t.assistant_resonance_coherence for t in turns if t.assistant_resonance_coherence is not None]

    user_gates_open = sum(1 for t in turns if t.user_resonance_gate == "OPEN")
    asst_gates_open = sum(1 for t in turns if t.assistant_resonance_gate == "OPEN")

    # Coherence trend: is it increasing over the conversation?
    if len(user_coherences) >= 2:
        user_trend = user_coherences[-1] - user_coherences[0]
    else:
        user_trend = 0

    if len(asst_coherences) >= 2:
        asst_trend = asst_coherences[-1] - asst_coherences[0]
    else:
        asst_trend = 0

    return {
        "session_id": session_id,
        "total_turns": len(turns),
        "user": {
            "avg_coherence": sum(user_coherences) / len(user_coherences) if user_coherences else 0,
            "max_coherence": max(user_coherences) if user_coherences else 0,
            "gates_open": user_gates_open,
            "gates_open_pct": user_gates_open / len(turns) if turns else 0,
            "coherence_trend": user_trend,
        },
        "assistant": {
            "avg_coherence": sum(asst_coherences) / len(asst_coherences) if asst_coherences else 0,
            "max_coherence": max(asst_coherences) if asst_coherences else 0,
            "gates_open": asst_gates_open,
            "gates_open_pct": asst_gates_open / len(turns) if turns else 0,
            "coherence_trend": asst_trend,
        },
        "resonance_amplification": (
            (sum(asst_coherences) / len(asst_coherences)) / (sum(user_coherences) / len(user_coherences))
            if asst_coherences and user_coherences and sum(user_coherences) > 0
            else None
        ),
        "session_resonance_score": _compute_session_score(turns, user_coherences, asst_coherences),
    }


def _compute_session_score(
    turns: list[TurnRecord],
    user_coherences: list[float],
    asst_coherences: list[float],
) -> dict:
    """Session Resonance Score — single scalar metric for session quality.

    Three components weighted by 3-6-9:
      Gate ratio (3/18):  % of turns where both user AND assistant gates open
      Coherence (6/18):   geometric mean of user and assistant avg coherence
      Evolution (9/18):   trend direction — does coherence improve over time?

    Score range: 0.0 to 1.0. Threshold: φ⁻¹ (0.618).
    """
    if not turns:
        return {"score": 0.0, "gate_ratio": 0.0, "coherence": 0.0, "evolution": 0.0, "status": "NO_DATA"}

    # Gate ratio: turns where BOTH sides have gates open
    both_open = sum(
        1 for t in turns
        if t.user_resonance_gate == "OPEN"
        and t.assistant_resonance_gate == "OPEN"
    )
    gate_ratio = both_open / len(turns) if turns else 0.0

    # Coherence: geometric mean of averages (rewards balance between user and AI)
    user_avg = sum(user_coherences) / len(user_coherences) if user_coherences else 0.0
    asst_avg = sum(asst_coherences) / len(asst_coherences) if asst_coherences else 0.0
    import math
    coherence = math.sqrt(user_avg * asst_avg) if user_avg > 0 and asst_avg > 0 else 0.0

    # Evolution: normalized trend (positive = improving, capped to [0, 1])
    # Use per-turn average of user+assistant coherence, preserving chronological order
    per_turn = []
    for uc, ac in zip(user_coherences, asst_coherences if asst_coherences else user_coherences):
        per_turn.append((uc + ac) / 2)
    if not per_turn:
        per_turn = user_coherences if user_coherences else [0.0]

    if len(per_turn) >= 4:
        first_half = per_turn[:len(per_turn) // 2]
        second_half = per_turn[len(per_turn) // 2:]
        first_avg = sum(first_half) / len(first_half)
        second_avg = sum(second_half) / len(second_half)
        # Normalize: improvement of 0.2 maps to 1.0
        raw_evolution = (second_avg - first_avg) / 0.2 if first_avg > 0 else 0.0
        evolution = max(0.0, min(1.0, 0.5 + raw_evolution * 0.5))
    else:
        evolution = 0.5  # neutral with insufficient data

    # Weighted: 3/18, 6/18, 9/18
    score = (3.0 / 18.0) * gate_ratio + (6.0 / 18.0) * coherence + (9.0 / 18.0) * evolution
    score = round(min(1.0, score), 4)

    # Status threshold at φ⁻¹
    PHI_INV = 0.618034
    status = "RESONANT" if score >= PHI_INV else "DEVELOPING"

    return {
        "score": score,
        "gate_ratio": round(gate_ratio, 4),
        "coherence": round(coherence, 4),
        "evolution": round(evolution, 4),
        "status": status,
    }
