"""
Autonomous Context Manager — AI-managed knowledge persistence.

Enables the AI to manage its own .seif knowledge base autonomously:
  - Observe conversations and detect persistable knowledge
  - Create/update .seif modules without human intervention
  - Maintain a mapper (index) for quick context reconstruction
  - Rebuild knowledge structure across sessions

The human provides context by living — writing code, making decisions,
explaining reasons. The AI observes, compresses, and structures.

Architecture:
  .seif/
  ├── mapper.json              ← live index (AI reads first, always)
  ├── config.json              ← enable/disable autonomous features
  ├── nucleus.seif             ← workspace view
  ├── projects/
  │   └── <name>/
  │       ├── ref.json         ← pointer to code
  │       ├── project.seif     ← git context (auto-sync)
  │       ├── decisions.seif   ← architectural decisions (AI-created)
  │       ├── patterns.seif    ← observed code patterns (AI-created)
  │       └── intent.seif      ← human intent for this project (AI-created)
  └── sessions/
      └── evolution.json       ← drift tracking

Usage:
  from seif.context.autonomous import (
      load_mapper, persist_knowledge, bootstrap_context,
      load_config, is_autonomous,
  )

  # At session start
  config = load_config(".seif")
  if is_autonomous(config):
      mapper = load_mapper(".seif")
      context = bootstrap_context(mapper, ".seif")

  # During session — AI decides to persist
  persist_knowledge(
      context_repo=".seif",
      project="api",
      category="decisions",
      content="Migrated to PostgreSQL because of JSONB support for event sourcing",
      author="claude-opus",
  )
"""

import json
import hashlib
import os
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional


def find_context_repo(start_path: str = ".") -> Optional[str]:
    """Walk up the directory tree to find a .seif/ context repository.

    Similar to how git finds .git/ — starts at start_path and walks up
    until it finds a directory containing mapper.json or config.json
    (markers of a SEIF context repo), or reaches the filesystem root.

    Args:
        start_path: Directory to start searching from (default: cwd).

    Returns:
        Absolute path to the .seif/ directory, or None if not found.
    """
    current = Path(start_path).resolve()

    # Walk up to filesystem root (max 20 levels to prevent infinite loops)
    for _ in range(20):
        candidate = current / ".seif"
        if candidate.is_dir():
            # Verify it's a SEIF context repo (not just any .seif dir)
            if (candidate / "mapper.json").exists() or \
               (candidate / "config.json").exists() or \
               (candidate / "manifest.json").exists() or \
               (candidate / "RESONANCE.json").exists():
                return str(candidate)

        parent = current.parent
        if parent == current:
            break  # reached filesystem root
        current = parent

    return None


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

DEFAULT_CONFIG = {
    "autonomous_context": True,        # master switch (enabled by default)
    "auto_persist": True,              # AI creates modules without asking
    "read_only": False,                # read .seif but never write (shared environments)
    "persist_decisions": True,         # architectural decisions
    "persist_patterns": True,          # code patterns observed
    "persist_intent": True,            # human intent tracking
    "persist_feedback": True,          # corrections and preferences
    "quality_threshold": "C",          # minimum Quality Gate grade to persist
    "max_modules_per_project": 10,     # prevent unbounded growth
    "relevance_decay": 0.95,           # multiplied per session-end (0.0-1.0)
    # Classification
    "classification_default": "INTERNAL",
    "classification_rules": {
        "decisions": "INTERNAL",
        "patterns": "INTERNAL",
        "intent": "INTERNAL",
        "feedback": "INTERNAL",
        "context": "INTERNAL",
    },
    "classification_overrides": {},    # {"project/category": "PUBLIC"} — manual override
    "confidential_keywords": [
        "vulnerability", "CVE", "exploit", "secret", "key",
        "password", "token", "credential", "compliance",
        "LGPD", "GDPR", "breach", "leak", "pentest",
        "audit finding", "security gap", "attack vector",
    ],
    "require_confidential_approval": False,  # require explicit approve for CONFIDENTIAL writes
    "redact_on_export": True,
}

# Knowledge categories the AI can create
CATEGORIES = {
    "decisions":  "Architectural and technical decisions with reasoning",
    "patterns":   "Recurring code patterns, conventions, and preferences",
    "intent":     "Human goals, priorities, and motivations for the project",
    "feedback":   "Corrections, preferences, and interaction guidelines",
    "context":    "Important external context (deadlines, stakeholders, constraints)",
}

# Classification levels (ordered from most to least restrictive)
CLASSIFICATION_LEVELS = {
    "CONFIDENTIAL": 3,  # restricted access — exposure causes direct harm
    "INTERNAL": 2,      # org-private — useful for onboarding, not secret
    "PUBLIC": 1,        # open — can be in public repos
}

GRADE_ORDER = {"A": 5, "B": 4, "C": 3, "D": 2, "F": 1}


def load_config(context_repo: str) -> dict:
    """Load autonomous context configuration.

    Args:
        context_repo: Path to the .seif context repository.

    Returns:
        Config dict (merged with defaults for missing keys).
    """
    config_path = Path(context_repo) / "config.json"
    config = dict(DEFAULT_CONFIG)
    if config_path.exists():
        try:
            with open(config_path, encoding="utf-8") as f:
                user_config = json.load(f)
            config.update(user_config)
        except Exception:
            pass
    return config


def save_config(context_repo: str, config: dict) -> Path:
    """Save autonomous context configuration.

    Args:
        context_repo: Path to the .seif context repository.
        config: Configuration dict.

    Returns:
        Path to saved config.json.
    """
    ctx = Path(context_repo)
    ctx.mkdir(parents=True, exist_ok=True)
    config_path = ctx / "config.json"
    with open(config_path, "w", encoding="utf-8") as f:
        json.dump(config, f, indent=2, ensure_ascii=False)
    return config_path


def is_autonomous(config: dict) -> bool:
    """Check if autonomous context management is enabled."""
    return config.get("autonomous_context", False)


# ---------------------------------------------------------------------------
# Mapper — the live index
# ---------------------------------------------------------------------------

@dataclass
class MapperEntry:
    """A single entry in the mapper index."""
    path: str                          # relative to context repo
    category: str                      # decisions, patterns, intent, feedback, context
    project: Optional[str] = None      # project name (None for cross-project)
    origin: str = "ai-observed"        # ai-observed | auto-sync | human
    relevance: float = 1.0             # 0-1, decays over time
    last_updated: str = ""
    trigger: str = ""                  # what caused this module to be created/updated
    word_count: int = 0
    integrity_hash: str = ""
    classification: str = "INTERNAL"   # PUBLIC | INTERNAL | CONFIDENTIAL


@dataclass
class Mapper:
    """The live index of all knowledge in the context repo."""
    protocol: str = "SEIF-MAPPER-v1"
    last_session: str = ""
    session_count: int = 0
    modules: list[MapperEntry] = field(default_factory=list)
    pending_observations: list[str] = field(default_factory=list)


def load_mapper(context_repo: str) -> Mapper:
    """Load mapper from context repo. Creates empty if not found.

    If mapper.json is missing but .seif files exist, rebuilds the index
    by scanning (self-healing).

    Args:
        context_repo: Path to the .seif context repository.

    Returns:
        Mapper with current index state.
    """
    mapper_path = Path(context_repo) / "mapper.json"

    if mapper_path.exists():
        try:
            with open(mapper_path, encoding="utf-8") as f:
                data = json.load(f)
            modules = [
                MapperEntry(**{k: v for k, v in m.items()
                              if k in MapperEntry.__dataclass_fields__})
                for m in data.get("modules", [])
            ]
            return Mapper(
                protocol=data.get("protocol", "SEIF-MAPPER-v1"),
                last_session=data.get("last_session", ""),
                session_count=data.get("session_count", 0),
                modules=modules,
                pending_observations=data.get("pending_observations", []),
            )
        except Exception:
            pass

    # Self-healing: scan for existing .seif files
    ctx = Path(context_repo)
    mapper = Mapper()
    if ctx.exists():
        mapper = _rebuild_mapper(context_repo)

    return mapper


def save_mapper(context_repo: str, mapper: Mapper) -> Path:
    """Save mapper to context repo.

    Args:
        context_repo: Path to the .seif context repository.
        mapper: Mapper to save.

    Returns:
        Path to saved mapper.json.
    """
    ctx = Path(context_repo)
    ctx.mkdir(parents=True, exist_ok=True)
    mapper_path = ctx / "mapper.json"
    with open(mapper_path, "w", encoding="utf-8") as f:
        json.dump(asdict(mapper), f, indent=2, ensure_ascii=False)
    return mapper_path


def _rebuild_mapper(context_repo: str) -> Mapper:
    """Rebuild mapper by scanning existing .seif files (self-healing).

    Args:
        context_repo: Path to the .seif context repository.

    Returns:
        Reconstructed Mapper.
    """
    ctx = Path(context_repo)
    mapper = Mapper()

    for seif_file in ctx.rglob("*.seif"):
        rel = str(seif_file.relative_to(ctx))

        # Determine category and project from path
        parts = seif_file.relative_to(ctx).parts
        project = None
        category = "context"

        if len(parts) >= 2 and parts[0] == "projects":
            project = parts[1]
            if len(parts) >= 3:
                # projects/api/decisions.seif → category = decisions
                stem = seif_file.stem
                if stem in CATEGORIES:
                    category = stem
                elif stem == "project":
                    category = "context"
        elif seif_file.stem == "nucleus":
            category = "context"

        # Read basic metadata
        word_count = 0
        integrity_hash = ""
        try:
            with open(seif_file, encoding="utf-8") as f:
                data = json.load(f)
            word_count = data.get("compressed_words", 0)
            integrity_hash = data.get("integrity_hash", "")
        except Exception:
            pass

        mapper.modules.append(MapperEntry(
            path=rel,
            category=category,
            project=project,
            origin="rebuilt",
            relevance=0.8,
            last_updated=datetime.now(timezone.utc).isoformat(),
            word_count=word_count,
            integrity_hash=integrity_hash,
        ))

    return mapper


# ---------------------------------------------------------------------------
# Knowledge persistence
# ---------------------------------------------------------------------------

def persist_knowledge(
    context_repo: str = None,
    project: Optional[str] = None,
    category: str = "",
    content: str = "",
    author: str = "ai",
    trigger: str = "",
    classification_override: str = None,
    approved: bool = False,
) -> Optional[MapperEntry]:
    """Persist a piece of knowledge as a .seif module.

    The AI calls this when it observes something worth persisting:
    a decision, a pattern, an intent, feedback, or external context.

    Args:
        context_repo: Path to the .seif context repository.
                     If None, walks up from cwd to find .seif/.
        project: Project name (None for cross-project knowledge).
        category: One of: decisions, patterns, intent, feedback, context.
        content: The knowledge to persist.
        author: Who is persisting (e.g., "claude-opus").
        trigger: What triggered this persistence (e.g., "user explained migration").
        classification_override: Explicit classification (bypasses auto-detection).
        approved: If True, bypasses the CONFIDENTIAL approval gate.

    Returns:
        MapperEntry for the persisted module, or None if config blocks it.
    """
    if context_repo is None:
        context_repo = find_context_repo()
    if context_repo is None:
        return None

    ctx = Path(context_repo)
    config = load_config(context_repo)

    # Check master switch
    if not is_autonomous(config):
        return None

    # Check read-only mode
    if config.get("read_only", False):
        return None

    # Check category toggle
    category_key = f"persist_{category}"
    if not config.get(category_key, True):
        return None

    # Check quality threshold
    grade = _assess_quality(content)
    threshold = config.get("quality_threshold", "C")
    if GRADE_ORDER.get(grade, 0) < GRADE_ORDER.get(threshold, 3):
        return None

    # Validate category
    if category not in CATEGORIES:
        return None

    # Determine target path
    if project:
        target_dir = ctx / "projects" / project
    else:
        target_dir = ctx / "modules"
    target_dir.mkdir(parents=True, exist_ok=True)
    target_path = target_dir / f"{category}.seif"

    # Check module count limit
    if project:
        existing = list((ctx / "projects" / project).glob("*.seif"))
        max_modules = config.get("max_modules_per_project", 10)
        # Only count AI-created modules (exclude project.seif)
        ai_modules = [f for f in existing if f.stem != "project"]
        if len(ai_modules) >= max_modules and not target_path.exists():
            return None

    # Classify content
    classification = classify_content(content, category, config,
                                      override=classification_override,
                                      project=project)

    # Approval gate for CONFIDENTIAL
    if classification == "CONFIDENTIAL" and not approved and \
       config.get("require_confidential_approval", False):
        mapper = load_mapper(context_repo)
        pending = f"CONFIDENTIAL_PENDING|{project or ''}|{category}|{trigger}"
        if pending not in mapper.pending_observations:
            mapper.pending_observations.append(pending)
            mapper.pending_observations = mapper.pending_observations[-10:]
            save_mapper(context_repo, mapper)
        return None

    # Load mapper BEFORE writing (avoid rebuild picking up the new file with wrong classification)
    mapper = load_mapper(context_repo)
    rel_path = str(target_path.relative_to(ctx))

    # Create or contribute
    from seif.context.context_manager import (
        create_module, save_module, contribute_to_module,
    )

    now_iso = datetime.now(timezone.utc).isoformat()

    if target_path.exists():
        module, _ = contribute_to_module(
            str(target_path), content,
            author=author, via="autonomous",
        )
    else:
        module = create_module(
            source_name=f"{project or 'cross-project'}/{category}",
            original_words=len(content.split()) * 3,
            summary=content,
            author=author,
            via="autonomous",
        )
        save_module(module, target_path=target_path)

    # Stamp classification into the .seif file
    _stamp_classification(target_path, classification)

    # Find existing entry or create new
    entry = None
    for m in mapper.modules:
        if m.path == rel_path:
            entry = m
            break

    if entry:
        entry.last_updated = now_iso
        entry.trigger = trigger
        entry.word_count = module.compressed_words
        entry.integrity_hash = module.integrity_hash
        entry.relevance = min(1.0, entry.relevance + 0.1)
        if classification_override:
            # Explicit override: set directly (human decision)
            entry.classification = classification
        elif CLASSIFICATION_LEVELS.get(classification, 0) > \
             CLASSIFICATION_LEVELS.get(entry.classification, 0):
            # Auto-classification: escalate only (never downgrade)
            entry.classification = classification
    else:
        entry = MapperEntry(
            path=rel_path,
            category=category,
            project=project,
            origin="ai-observed",
            relevance=1.0,
            last_updated=now_iso,
            trigger=trigger,
            word_count=module.compressed_words,
            integrity_hash=module.integrity_hash,
            classification=classification,
        )
        mapper.modules.append(entry)

    mapper.last_session = now_iso
    save_mapper(context_repo, mapper)

    return entry


def classify_content(content: str, category: str, config: dict,
                     override: str = None, project: str = None) -> str:
    """Classify content as PUBLIC, INTERNAL, or CONFIDENTIAL.

    Uses a layered approach:
    0. Explicit override (highest priority — human decision)
    1. Config-based override by project/category
    2. Check for confidential keywords in content
    3. Apply category-level rule from config
    4. Fall back to default classification

    Args:
        content: The text to classify.
        category: Knowledge category (decisions, patterns, etc.).
        config: Autonomous context configuration.
        override: Explicit classification override (bypasses all auto-detection).
        project: Project name for config-based overrides.

    Returns:
        Classification level: "PUBLIC", "INTERNAL", or "CONFIDENTIAL".
    """
    # Layer 0: explicit override (human decision > auto-detection)
    if override and override in CLASSIFICATION_LEVELS:
        return override

    # Layer 1: config-based override by project/category
    overrides = config.get("classification_overrides", {})
    override_key = f"{project or '*'}/{category}"
    if override_key in overrides and overrides[override_key] in CLASSIFICATION_LEVELS:
        return overrides[override_key]

    content_lower = content.lower()

    # Layer 2: keyword detection — auto-escalate to CONFIDENTIAL
    confidential_keywords = config.get("confidential_keywords", [])
    for keyword in confidential_keywords:
        if keyword.lower() in content_lower:
            return "CONFIDENTIAL"

    # Layer 3: category-level rule
    rules = config.get("classification_rules", {})
    if category in rules:
        return rules[category]

    # Layer 4: default
    return config.get("classification_default", "INTERNAL")


def _stamp_classification(seif_path: Path, classification: str):
    """Write classification into the .seif JSON file."""
    try:
        with open(seif_path, encoding="utf-8") as f:
            data = json.load(f)
        data["classification"] = classification
        with open(seif_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
    except Exception:
        pass


def _assess_quality(text: str) -> str:
    """Quick quality assessment for persist threshold.

    Returns the grade, or 'C' (pass) for LOW_DATA — short text
    is not low quality, it's just insufficient for full analysis.
    """
    try:
        from seif.analysis.quality_gate import assess
        verdict = assess(text[:500])
        # LOW_DATA means text is too short to judge — let it pass
        if verdict.status == "LOW_DATA":
            return "C"
        return verdict.grade
    except Exception:
        return "C"  # default pass


# ---------------------------------------------------------------------------
# Context bootstrap — session start
# ---------------------------------------------------------------------------

def bootstrap_context(mapper: Mapper, context_repo: str,
                      max_tokens: int = 4000,
                      max_classification: str = "CONFIDENTIAL") -> str:
    """Build context string from mapper for session start.

    Loads modules by relevance order, fitting within token budget.
    Filters by classification level for safe export.

    Args:
        mapper: Current mapper state.
        context_repo: Path to the .seif context repository.
        max_tokens: Approximate token budget.
        max_classification: Maximum classification to include.
            "PUBLIC" = only public modules.
            "INTERNAL" = public + internal (default for org use).
            "CONFIDENTIAL" = all modules (default, local use only).

    Returns:
        Context string with all loaded knowledge.
    """
    ctx = Path(context_repo)
    max_level = CLASSIFICATION_LEVELS.get(max_classification, 3)

    # Sort by relevance (highest first)
    sorted_entries = sorted(mapper.modules, key=lambda m: -m.relevance)

    parts = []
    total_words = 0
    word_budget = int(max_tokens / 1.3)  # rough tokens-to-words

    for entry in sorted_entries:
        if total_words >= word_budget:
            break

        # Filter by classification
        entry_level = CLASSIFICATION_LEVELS.get(entry.classification, 2)
        if entry_level > max_level:
            continue

        seif_path = ctx / entry.path
        if not seif_path.exists():
            continue

        try:
            with open(seif_path, encoding="utf-8") as f:
                data = json.load(f)
            summary = data.get("summary", "")
            words = len(summary.split())

            if total_words + words > word_budget:
                # Truncate to fit
                remaining = word_budget - total_words
                summary = " ".join(summary.split()[:remaining])
                words = remaining

            label = entry.category.upper()
            if entry.project:
                label = f"{entry.project}/{label}"

            classification_tag = entry.classification
            parts.append(f"[{label}] [{classification_tag}] {summary}")
            total_words += words
        except Exception:
            continue

    if mapper.pending_observations:
        parts.append(
            "[PENDING] " + " | ".join(mapper.pending_observations[:5])
        )

    return "\n\n".join(parts)


# ---------------------------------------------------------------------------
# Session lifecycle
# ---------------------------------------------------------------------------

def start_session(context_repo: str = None) -> tuple[dict, Mapper, str]:
    """Called at session start. Returns config, mapper, and bootstrap context.

    Args:
        context_repo: Path to the .seif context repository.
                     If None, walks up from cwd to find .seif/.

    Returns:
        Tuple of (config, mapper, context_string).
    """
    if context_repo is None:
        context_repo = find_context_repo()
    if context_repo is None:
        return dict(DEFAULT_CONFIG), Mapper(), ""

    config = load_config(context_repo)
    mapper = load_mapper(context_repo)

    context = ""
    if is_autonomous(config):
        context = bootstrap_context(mapper, context_repo)

    # Write session tracking (skip in read-only mode)
    if not config.get("read_only", False):
        mapper.session_count += 1
        mapper.last_session = datetime.now(timezone.utc).isoformat()
        save_mapper(context_repo, mapper)

    return config, mapper, context


def end_session(context_repo: str = None,
                pending_observations: list[str] = None) -> Mapper:
    """Called at session end. Saves pending observations for next session.

    Args:
        context_repo: Path to the .seif context repository.
                     If None, walks up from cwd to find .seif/.
        pending_observations: Things the AI noticed but couldn't persist yet.

    Returns:
        Updated Mapper.
    """
    if context_repo is None:
        context_repo = find_context_repo()
    if context_repo is None:
        return Mapper()

    config = load_config(context_repo)
    mapper = load_mapper(context_repo)

    # Read-only mode: return current state without writing
    if config.get("read_only", False):
        return mapper

    mapper.last_session = datetime.now(timezone.utc).isoformat()

    if pending_observations:
        # Keep last 10 observations
        mapper.pending_observations = (
            mapper.pending_observations + pending_observations
        )[-10:]

    # Decay relevance (configurable factor, default 0.95)
    decay = max(0.0, min(1.0, config.get("relevance_decay", 0.95)))
    for entry in mapper.modules:
        entry.relevance = max(0.1, entry.relevance * decay)

    save_mapper(context_repo, mapper)
    return mapper


def add_observation(context_repo: str = None, observation: str = "") -> Mapper:
    """Add a pending observation for the next session.

    Args:
        context_repo: Path to the .seif context repository.
                     If None, walks up from cwd to find .seif/.
        observation: What to remember for next session.

    Returns:
        Updated Mapper.
    """
    if context_repo is None:
        context_repo = find_context_repo()
    if context_repo is None:
        return Mapper()

    config = load_config(context_repo)
    if config.get("read_only", False):
        return load_mapper(context_repo)

    mapper = load_mapper(context_repo)
    mapper.pending_observations.append(observation)
    mapper.pending_observations = mapper.pending_observations[-10:]
    save_mapper(context_repo, mapper)
    return mapper
