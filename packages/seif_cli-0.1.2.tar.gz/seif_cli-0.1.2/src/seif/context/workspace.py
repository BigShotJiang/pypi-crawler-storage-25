"""
Workspace Manager — Multi-project SEIF nucleus.

Manages a workspace of related projects from a single root directory.
The nucleus at the root understands all projects and their relationships,
enabling cross-project context routing and unified ingestion.

Supports two modes:
  1. Embedded (default): .seif/ inside each project directory
  2. SCR (SEIF Context Repository): all .seif data in a separate directory/repo

Architecture (embedded):
  workspace_root/
  ├── .seif/
  │   ├── workspace.json     ← project registry + relationships
  │   └── nucleus.seif       ← workspace-level compressed context
  ├── project-a/
  │   └── .seif/project.seif ← project-specific context
  └── project-b/
      └── .seif/project.seif

Architecture (SCR):
  workspace_root/
  ├── project-a/              ← code only, no .seif
  ├── project-b/              ← code only, no .seif
  └── .seif/                  ← context repository (own git)
      ├── manifest.json
      ├── nucleus.seif
      ├── README.md
      └── projects/
          ├── project-a/
          │   ├── ref.json
          │   └── project.seif
          └── project-b/
              ├── ref.json
              └── project.seif

Usage:
  seif-cli --workspace .                          # embedded mode
  seif-cli --workspace . --context-repo .seif     # SCR mode
  seif-cli --workspace . --ingest daily.txt       # route daily to all projects
"""

import json
import subprocess
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from seif.context.git_context import extract_git_context, context_to_summary, _extract_manifest
from seif.context.context_manager import (
    create_module, save_module, load_module, contribute_to_module,
)


@dataclass
class ProjectEntry:
    """A project within the workspace."""
    name: str
    path: str               # relative to workspace root
    manifest_type: Optional[str] = None
    description: str = ""
    dependencies: list[str] = field(default_factory=list)  # names of related projects
    last_synced: Optional[str] = None
    seif_path: Optional[str] = None     # relative .seif/project.seif path


@dataclass
class WorkspaceRegistry:
    """Registry of all projects in the workspace."""
    workspace_name: str
    workspace_path: str
    projects: list[ProjectEntry] = field(default_factory=list)
    updated_at: str = ""
    context_repo: Optional[str] = None   # SCR path (None = embedded mode)


# Patterns that indicate project directories (exact filenames)
PROJECT_INDICATORS = [
    # Language manifests
    "pyproject.toml", "package.json", "Cargo.toml", "go.mod",
    "pom.xml", "build.gradle", "Gemfile", "composer.json",
    "CMakeLists.txt", "mix.exs", "pubspec.yaml",
    "Package.swift",
    # Infrastructure as Code
    "Dockerfile", "docker-compose.yml", "docker-compose.yaml",
    "main.tf",
    "kustomization.yaml", "Chart.yaml",
    # CI/CD
    "Jenkinsfile",
    # Monorepo tools
    "nx.json", "turbo.json", "lerna.json", "pnpm-workspace.yaml",
    # Git (fallback)
    ".git",
]

# Glob patterns for project detection (checked via fnmatch)
PROJECT_GLOB_INDICATORS = [
    "*.sln",         # .NET solution
    "*.csproj",      # .NET project
    "*.xcodeproj",   # Xcode/iOS
]

# Directories to skip during discovery
SKIP_DIRS = {
    ".git", ".venv", "venv", "node_modules", "__pycache__",
    ".tox", "dist", "build", ".egg-info", "target", "vendor",
    ".seif", ".claude", ".cursor",
}


def discover_projects(workspace_root: str, max_depth: int = 2) -> list[ProjectEntry]:
    """Discover project directories within a workspace.

    Looks for directories containing project manifests (pyproject.toml,
    package.json, etc.) or .git directories up to max_depth levels.

    Args:
        workspace_root: Path to the workspace root.
        max_depth: How deep to search for projects.

    Returns:
        List of discovered ProjectEntry objects.
    """
    root = Path(workspace_root).resolve()
    projects = []
    seen = set()

    def _scan(directory: Path, depth: int):
        if depth > max_depth:
            return
        try:
            entries = sorted(directory.iterdir())
        except PermissionError:
            return

        for entry in entries:
            if not entry.is_dir() or entry.name in SKIP_DIRS or entry.name.startswith("."):
                continue

            rel_path = str(entry.relative_to(root))
            if rel_path in seen:
                continue

            # Check if this directory is a project
            is_project = any((entry / indicator).exists() for indicator in PROJECT_INDICATORS)
            # Check glob patterns (*.sln, *.csproj, *.xcodeproj)
            if not is_project:
                import fnmatch
                try:
                    names = [f.name for f in entry.iterdir()]
                    is_project = any(
                        any(fnmatch.fnmatch(n, pat) for n in names)
                        for pat in PROJECT_GLOB_INDICATORS
                    )
                except PermissionError:
                    pass

            if is_project:
                seen.add(rel_path)
                manifest_type, manifest_summary = _extract_manifest(entry)

                # Extract description from manifest
                description = ""
                if manifest_summary:
                    for line in manifest_summary.split("\n"):
                        if "description" in line.lower():
                            description = line.split("=", 1)[-1].strip().strip('"\'')
                            break

                projects.append(ProjectEntry(
                    name=entry.name,
                    path=rel_path,
                    manifest_type=manifest_type,
                    description=description[:200],
                    seif_path=f"{rel_path}/.seif/project.seif",
                ))

            # Continue scanning subdirectories
            _scan(entry, depth + 1)

    _scan(root, 0)
    return projects


def detect_dependencies(projects: list[ProjectEntry],
                        workspace_root: str) -> list[ProjectEntry]:
    """Detect cross-project dependencies by scanning manifests.

    Simple heuristic: if project A's manifest mentions project B's name,
    A depends on B.
    """
    root = Path(workspace_root).resolve()
    project_names = {p.name.lower() for p in projects}

    for project in projects:
        project_dir = root / project.path
        # Read manifest content
        for mf in PROJECT_INDICATORS[:-1]:  # all indicators except .git
            mf_path = project_dir / mf
            if mf_path.exists():
                try:
                    content = mf_path.read_text(encoding="utf-8", errors="ignore").lower()
                    deps = []
                    for other_name in project_names:
                        if other_name != project.name.lower() and other_name in content:
                            deps.append(other_name)
                    if deps:
                        project.dependencies = deps
                except Exception:
                    pass
                break

    return projects


# ---------------------------------------------------------------------------
# SCR (SEIF Context Repository) helpers
# ---------------------------------------------------------------------------

def init_context_repo(context_path: str) -> Path:
    """Initialize a SEIF Context Repository directory.

    Creates the directory and runs `git init` if needed.

    Args:
        context_path: Path for the context repository.

    Returns:
        Resolved Path to the context repo.
    """
    ctx = Path(context_path).resolve()
    ctx.mkdir(parents=True, exist_ok=True)

    # Git init if not already a repo
    if not (ctx / ".git").exists():
        subprocess.run(
            ["git", "init"],
            cwd=str(ctx), capture_output=True, timeout=10,
        )

    # .gitignore for context repos
    gitignore = ctx / ".gitignore"
    if not gitignore.exists():
        gitignore.write_text(
            "# SEIF Context Repository — no code, no secrets\n"
            "__pycache__/\n"
            ".DS_Store\n"
            "*.pyc\n"
            ".env\n"
            "*.key\n"
            "*.pem\n"
        )

    return ctx


def create_scr_readme(context_path: str, registry: "WorkspaceRegistry") -> Path:
    """Generate a README.md for the context repository.

    This README serves as a bootstrap for any AI that clones the repo.
    """
    ctx = Path(context_path).resolve()
    project_list = "\n".join(
        f"- **{p.name}** — {p.description or p.manifest_type or 'project'}"
        for p in registry.projects
    )

    readme = f"""# SEIF Context Repository — {registry.workspace_name}

This repository contains compressed project context, not source code.
Any AI can use this repo to understand the referenced projects without
cloning their code repositories.

## For AI: How to use

1. Read `RESONANCE.json` if present (SEIF KERNEL — self-authenticating signal)
2. Read `manifest.json` (project registry with references)
3. For each project: read `projects/<name>/project.seif` (compressed context)
4. If you need source code: see `projects/<name>/ref.json` for git URL and clone instructions

## Projects

{project_list}

## For humans

```bash
seif-cli --sync --context-repo {ctx.name}     # re-sync all projects
seif-cli --ingest daily.txt --context-repo {ctx.name}  # ingest meeting notes
```

## Protocol

- Context files use the SEIF-MODULE-v2 format (hash-chained provenance)
- References use the SEIF-REF-v1 format (pointers to source repos)
- Generated by [seif-cli](https://github.com/and2carvalho/seif)
"""
    readme_path = ctx / "README.md"
    readme_path.write_text(readme, encoding="utf-8")
    return readme_path


def create_scr_manifest(context_path: str, registry: "WorkspaceRegistry") -> Path:
    """Write manifest.json for the context repository."""
    ctx = Path(context_path).resolve()
    manifest = {
        "protocol": "SEIF-SCR-v1",
        "workspace_name": registry.workspace_name,
        "workspace_path": registry.workspace_path,
        "projects": [
            {
                "name": p.name,
                "seif_path": f"projects/{p.name}/project.seif",
                "ref_path": f"projects/{p.name}/ref.json",
                "manifest_type": p.manifest_type,
                "description": p.description,
                "dependencies": p.dependencies,
            }
            for p in registry.projects
        ],
        "updated_at": registry.updated_at,
    }
    manifest_path = ctx / "manifest.json"
    with open(manifest_path, "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2, ensure_ascii=False)
    return manifest_path


# ---------------------------------------------------------------------------
# Core sync
# ---------------------------------------------------------------------------

def sync_workspace(workspace_root: str, author: str = "workspace-sync",
                   context_repo_path: str = None) -> WorkspaceRegistry:
    """Discover, sync, and register all projects in a workspace.

    1. Discovers project directories
    2. Detects cross-project dependencies
    3. Syncs each project's context (embedded or SCR mode)
    4. Builds nucleus.seif (workspace-level summary)
    5. Saves workspace.json registry

    Args:
        workspace_root: Path to workspace root.
        author: Author name for contributions.
        context_repo_path: Optional path for SCR mode. When set, all .seif
                          data goes to this directory instead of inside projects.

    Returns:
        WorkspaceRegistry with all discovered projects.
    """
    root = Path(workspace_root).resolve()

    # Determine where .seif data lives
    if context_repo_path:
        ctx_repo = init_context_repo(context_repo_path)
        seif_dir = ctx_repo
    else:
        seif_dir = root / ".seif"
        seif_dir.mkdir(exist_ok=True)
        ctx_repo = None

    # 1. Discover projects
    projects = discover_projects(str(root))

    # 2. Detect dependencies
    projects = detect_dependencies(projects, str(root))

    # 3. Sync each project
    now_iso = datetime.now(timezone.utc).isoformat()
    for project in projects:
        project_dir = root / project.path

        # Determine target path for this project's .seif
        if ctx_repo:
            # SCR mode: save in context repo
            project_ctx_dir = ctx_repo / "projects" / project.name
            project_ctx_dir.mkdir(parents=True, exist_ok=True)
            project_seif_path = project_ctx_dir / "project.seif"
            project.seif_path = f"projects/{project.name}/project.seif"

            # Create/update ref.json
            from seif.context.ref import create_ref, save_ref
            ref = create_ref(str(project_dir), str(ctx_repo))
            save_ref(ref, project_ctx_dir / "ref.json")
        else:
            # Embedded mode: save inside project
            project_seif_dir = project_dir / ".seif"
            project_seif_dir.mkdir(exist_ok=True)
            project_seif_path = project_seif_dir / "project.seif"

        try:
            # Check if it's a git repo
            if (project_dir / ".git").exists():
                ctx = extract_git_context(str(project_dir), max_commits=15)
                summary = context_to_summary(ctx)
            else:
                # Non-git project: basic manifest summary
                _, manifest_summary = _extract_manifest(project_dir)
                summary = f"## {project.name}\n{manifest_summary or 'No manifest found.'}"

            if project_seif_path.exists():
                contribute_to_module(
                    str(project_seif_path), summary,
                    author=author, via="workspace-sync",
                )
            else:
                module = create_module(
                    source_name=f"{project.name} (workspace)",
                    original_words=max(len(summary.split()) * 3, 100),
                    summary=summary,
                    author=author, via="workspace-sync",
                )
                save_module(module, target_path=project_seif_path)

            project.last_synced = now_iso
        except Exception:
            pass

    # 4. Build nucleus (workspace-level summary)
    nucleus_parts = [f"## Workspace: {root.name}", f"Projects: {len(projects)}\n"]
    for p in projects:
        deps_str = f" → depends on: {', '.join(p.dependencies)}" if p.dependencies else ""
        nucleus_parts.append(
            f"### {p.name}\n"
            f"Path: {p.path} | Type: {p.manifest_type or 'unknown'}\n"
            f"{p.description}{deps_str}\n"
        )

    # Add relationship map
    dep_projects = [p for p in projects if p.dependencies]
    if dep_projects:
        nucleus_parts.append("### Dependency Map")
        for p in dep_projects:
            for dep in p.dependencies:
                nucleus_parts.append(f"- {p.name} → {dep}")

    nucleus_summary = "\n".join(nucleus_parts)
    nucleus_path = seif_dir / "nucleus.seif"

    if nucleus_path.exists():
        contribute_to_module(
            str(nucleus_path), nucleus_summary,
            author=author, via="workspace-sync",
        )
    else:
        nucleus = create_module(
            source_name=f"{root.name} (workspace nucleus)",
            original_words=sum(len(p.description.split()) for p in projects) * 10,
            summary=nucleus_summary,
            author=author, via="workspace-sync",
        )
        save_module(nucleus, target_path=nucleus_path)

    # 5. Save registry
    registry = WorkspaceRegistry(
        workspace_name=root.name,
        workspace_path=str(root),
        projects=projects,
        updated_at=now_iso,
        context_repo=str(ctx_repo) if ctx_repo else None,
    )

    registry_path = seif_dir / "workspace.json"
    with open(registry_path, "w", encoding="utf-8") as f:
        json.dump(asdict(registry), f, indent=2, ensure_ascii=False)

    # 6. SCR extras: README + manifest
    if ctx_repo:
        create_scr_readme(str(ctx_repo), registry)
        create_scr_manifest(str(ctx_repo), registry)

    return registry


def load_registry(workspace_root: str,
                  context_repo_path: str = None) -> Optional[WorkspaceRegistry]:
    """Load existing workspace registry.

    Args:
        workspace_root: Path to workspace root.
        context_repo_path: Optional SCR path. When set, loads from there.
    """
    if context_repo_path:
        reg_path = Path(context_repo_path).resolve() / "workspace.json"
    else:
        reg_path = Path(workspace_root).resolve() / ".seif" / "workspace.json"

    if not reg_path.exists():
        return None
    try:
        with open(reg_path) as f:
            data = json.load(f)
        return WorkspaceRegistry(
            workspace_name=data["workspace_name"],
            workspace_path=data["workspace_path"],
            projects=[ProjectEntry(**p) for p in data["projects"]],
            updated_at=data.get("updated_at", ""),
            context_repo=data.get("context_repo"),
        )
    except Exception:
        return None


def ingest_to_workspace(workspace_root: str, source: str,
                        author: str = "ingest",
                        via: str = "meeting",
                        backend: str = "auto",
                        model: str = "sonnet",
                        context_repo_path: str = None) -> dict:
    """Ingest external text and route to relevant projects in the workspace.

    Uses each project's .seif as a relevance filter. A single daily transcript
    gets split across N projects automatically.

    Args:
        workspace_root: Path to workspace root.
        source: Raw text, file path, or "-" for stdin.
        author: Author name.
        via: Source label.
        backend: AI backend for filtering.
        model: AI model.
        context_repo_path: Optional SCR path for finding project.seif files.

    Returns:
        Dict with results per project: {project_name: IngestResult}
    """
    from seif.context.ingest import ingest as single_ingest, _load_raw_text

    root = Path(workspace_root).resolve()
    registry = load_registry(str(root), context_repo_path=context_repo_path)

    if not registry:
        return {"error": "No workspace registry found. Run seif --workspace first."}

    raw_text, source_label = _load_raw_text(source)
    results = {}

    for project in registry.projects:
        # Find project.seif based on mode
        if context_repo_path:
            ctx_repo = Path(context_repo_path).resolve()
            seif_path = ctx_repo / "projects" / project.name / "project.seif"
        else:
            seif_path = root / project.path / ".seif" / "project.seif"

        if not seif_path.exists():
            continue

        result = single_ingest(
            raw_text, str(seif_path),
            author=author, via=via,
            backend=backend, model=model,
        )
        results[project.name] = result

    return results


def describe_workspace(registry: WorkspaceRegistry) -> str:
    """Human-readable workspace summary."""
    lines = []
    lines.append(f"Workspace: {registry.workspace_name}")
    lines.append(f"Projects:  {len(registry.projects)}")
    if registry.context_repo:
        lines.append(f"Context:   {registry.context_repo} (SCR)")
    lines.append("")

    for p in registry.projects:
        synced = "synced" if p.last_synced else "not synced"
        deps = f" → {', '.join(p.dependencies)}" if p.dependencies else ""
        lines.append(f"  {p.name:<25} {p.manifest_type or 'unknown':<18} {synced}{deps}")
        if p.description:
            lines.append(f"    {p.description[:80]}")

    return "\n".join(lines)
