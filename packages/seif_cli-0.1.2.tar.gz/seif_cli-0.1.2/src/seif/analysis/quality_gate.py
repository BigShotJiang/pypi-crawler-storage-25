"""
Quality Gate — Unified text quality verdict.

Composes two orthogonal measurements:
  1. Triple Gate (harmonic resonance: ASCII + melody + cadence)
  2. Stance Detector (semantic credibility: verifiable vs. interpretive)

Output: a single QualityVerdict with score, grade, and actionable feedback.

Usage:
  from seif.analysis.quality_gate import assess, describe_verdict

  verdict = assess("Your text here")
  print(describe_verdict(verdict))

  # Or for AI response analysis:
  verdict = assess(ai_response, role="ai")
"""

from dataclasses import dataclass, field
from seif.core.triple_gate import evaluate as triple_evaluate, TripleGateResult
from seif.analysis.stance_detector import analyze as stance_analyze, StanceAnalysis
from seif.constants import PHI_INVERSE


# Weights: stance (semantic) gets 6/9, resonance (harmonic) gets 3/9.
# Rationale: for a quality gate product, verifiability matters more than
# harmonic alignment. The resonance layer adds signal, not dominance.
WEIGHT_STANCE = 6 / 9    # 0.667
WEIGHT_RESONANCE = 3 / 9  # 0.333


@dataclass
class QualityVerdict:
    """Unified quality measurement of a text."""
    text_preview: str           # first 100 chars
    role: str                   # "human" or "ai"

    # Components
    triple_gate: TripleGateResult
    stance: StanceAnalysis

    # Composite
    score: float                # 0.0 to 1.0
    grade: str                  # A / B / C / D / F
    status: str                 # SOLID / MIXED / WEAK / LOW_DATA

    # Actionable
    flags: list[str] = field(default_factory=list)
    suggestions: list[str] = field(default_factory=list)


def _compute_grade(score: float) -> str:
    """Map 0-1 score to letter grade."""
    if score >= 0.85:
        return "A"
    elif score >= 0.70:
        return "B"
    elif score >= 0.55:
        return "C"
    elif score >= 0.40:
        return "D"
    return "F"


def _compute_status(stance_status: str, triple_status: str,
                    score: float) -> str:
    """Determine overall status."""
    if stance_status == "LOW_DATA":
        return "LOW_DATA"
    if stance_status == "GROUNDED" and score >= PHI_INVERSE:
        return "SOLID"
    if stance_status == "DRIFT":
        return "WEAK"
    if score >= 0.55:
        return "MIXED"
    return "WEAK"


def _generate_flags(stance: StanceAnalysis,
                    triple: TripleGateResult) -> list[str]:
    """Generate warning flags."""
    flags = []
    if stance.status == "DRIFT":
        flags.append(
            f"DRIFT: {stance.interpretive_count} interpretive claims, "
            f"verifiability {stance.verifiability_ratio:.0%}"
        )
    if stance.flagged_sentences:
        for s in stance.flagged_sentences[:3]:
            flags.append(f"FLAG: \"{s[:80]}...\"" if len(s) > 80 else f"FLAG: \"{s}\"")
    if triple.status == "CLOSED":
        flags.append("RESONANCE: all 3 harmonic layers closed")
    if triple.resonance_score < 0.3:
        flags.append(f"LOW COHERENCE: {triple.resonance_score:.3f} (threshold: {PHI_INVERSE:.3f})")
    return flags


def _generate_suggestions(stance: StanceAnalysis,
                          triple: TripleGateResult,
                          role: str) -> list[str]:
    """Generate actionable suggestions."""
    suggestions = []
    if stance.status in ("DRIFT", "MIXED") and stance.interpretive_count > 0:
        suggestions.append(
            "Add measurements, numbers, or references to ground interpretive claims"
        )
    if stance.verifiability_ratio < 0.5 and stance.total_sentences > 2:
        suggestions.append(
            f"Verifiability is {stance.verifiability_ratio:.0%} — "
            "consider replacing vague assertions with specific data"
        )
    if role == "ai" and stance.status == "DRIFT":
        suggestions.append(
            "AI response is speculative — re-prompt with verifiable constraints"
        )
    if triple.resonance_score < PHI_INVERSE and triple.resonance_score > 0:
        suggestions.append(
            f"Coherence {triple.resonance_score:.3f} below threshold "
            f"{PHI_INVERSE:.3f} — restructure for clarity"
        )
    return suggestions


def assess(text: str, role: str = "human") -> QualityVerdict:
    """Assess text quality through combined harmonic + semantic analysis.

    Args:
        text: The text to analyze.
        role: "human" for user input, "ai" for AI-generated responses.

    Returns:
        QualityVerdict with score, grade, status, flags, and suggestions.
    """
    triple = triple_evaluate(text)
    stance = stance_analyze(text)

    # Normalize stance to 0-1
    stance_score = stance.verifiability_ratio

    # Normalize triple to 0-1
    resonance_score = triple.composite_score

    # Weighted composite
    score = (WEIGHT_STANCE * stance_score) + (WEIGHT_RESONANCE * resonance_score)
    score = round(min(max(score, 0.0), 1.0), 4)

    grade = _compute_grade(score)
    status = _compute_status(stance.status, triple.status, score)
    flags = _generate_flags(stance, triple)
    suggestions = _generate_suggestions(stance, triple, role)

    return QualityVerdict(
        text_preview=text[:100],
        role=role,
        triple_gate=triple,
        stance=stance,
        score=score,
        grade=grade,
        status=status,
        flags=flags,
        suggestions=suggestions,
    )


def describe_verdict(v: QualityVerdict) -> str:
    """Human-readable quality report."""
    lines = []

    # Header
    icon = {"SOLID": "🟢", "MIXED": "🟡", "WEAK": "🔴", "LOW_DATA": "⚪"}.get(v.status, "⚪")
    role_label = "AI" if v.role == "ai" else "HUMAN"
    lines.append(f"{icon} [{role_label}] Grade: {v.grade} | Score: {v.score:.3f} | Status: {v.status}")
    lines.append("")

    # Components
    lines.append(f"  Stance:      {v.stance.status} "
                 f"(verifiable: {v.stance.verifiability_ratio:.0%}, "
                 f"{v.stance.verifiable_count}/{v.stance.total_sentences} sentences)")
    lines.append(f"  Resonance:   {v.triple_gate.status} "
                 f"(composite: {v.triple_gate.composite_score:.3f}, "
                 f"layers: {v.triple_gate.layers_open}/3)")
    lines.append(f"  Coherence:   {v.triple_gate.resonance_score:.3f} "
                 f"({'above' if v.triple_gate.resonance_score >= PHI_INVERSE else 'below'} "
                 f"threshold {PHI_INVERSE:.3f})")

    # Flags
    if v.flags:
        lines.append("")
        lines.append("  Flags:")
        for f in v.flags:
            lines.append(f"    - {f}")

    # Suggestions
    if v.suggestions:
        lines.append("")
        lines.append("  Suggestions:")
        for s in v.suggestions:
            lines.append(f"    + {s}")

    return "\n".join(lines)
