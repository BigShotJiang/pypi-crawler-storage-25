"""Tests for Autonomous Context Manager — AI-managed knowledge persistence."""

import sys
import os
import json
import tempfile
import subprocess
import shutil
import unittest
from pathlib import Path

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from seif.context.autonomous import (
    load_config, save_config, is_autonomous, DEFAULT_CONFIG,
    load_mapper, save_mapper, Mapper, MapperEntry,
    persist_knowledge, bootstrap_context,
    start_session, end_session, add_observation,
    classify_content, find_context_repo,
    CATEGORIES, CLASSIFICATION_LEVELS, _rebuild_mapper,
)


def _create_context_repo(autonomous=True):
    """Create a temporary context repo with config."""
    ctx = Path(tempfile.mkdtemp()) / ".seif"
    ctx.mkdir()
    config = dict(DEFAULT_CONFIG)
    config["autonomous_context"] = autonomous
    with open(ctx / "config.json", "w") as f:
        json.dump(config, f)
    return ctx


def _create_context_repo_with_project(autonomous=True):
    """Create a context repo with a dummy project.seif."""
    ctx = _create_context_repo(autonomous)
    project_dir = ctx / "projects" / "api"
    project_dir.mkdir(parents=True)

    # Create a minimal project.seif
    from seif.context.context_manager import create_module, save_module
    module = create_module(
        source_name="api (workspace)",
        original_words=500,
        summary="## api\nREST API built with FastAPI. Uses PostgreSQL.\nEndpoints: /users, /orders, /products.",
        author="test",
        via="test",
    )
    save_module(module, target_path=project_dir / "project.seif")

    return ctx


class TestConfig(unittest.TestCase):

    def setUp(self):
        self.ctx = Path(tempfile.mkdtemp()) / ".seif"
        self.ctx.mkdir()

    def tearDown(self):
        shutil.rmtree(str(self.ctx.parent), ignore_errors=True)

    def test_default_config(self):
        config = load_config(str(self.ctx))
        self.assertTrue(config["autonomous_context"])  # enabled by default
        self.assertTrue(config["auto_persist"])
        self.assertEqual(config["quality_threshold"], "C")

    def test_save_and_load(self):
        config = {"autonomous_context": True, "quality_threshold": "B"}
        save_config(str(self.ctx), config)
        loaded = load_config(str(self.ctx))
        self.assertTrue(loaded["autonomous_context"])
        self.assertEqual(loaded["quality_threshold"], "B")
        # Defaults should be merged
        self.assertTrue(loaded["persist_decisions"])

    def test_is_autonomous(self):
        self.assertFalse(is_autonomous({"autonomous_context": False}))
        self.assertTrue(is_autonomous({"autonomous_context": True}))

    def test_missing_config_file(self):
        config = load_config("/nonexistent/path")
        self.assertTrue(config["autonomous_context"])  # enabled by default


class TestMapper(unittest.TestCase):

    def setUp(self):
        self.ctx = _create_context_repo()

    def tearDown(self):
        shutil.rmtree(str(self.ctx.parent), ignore_errors=True)

    def test_empty_mapper(self):
        mapper = load_mapper(str(self.ctx))
        self.assertEqual(mapper.protocol, "SEIF-MAPPER-v1")
        self.assertEqual(len(mapper.modules), 0)

    def test_save_and_load(self):
        mapper = Mapper()
        mapper.session_count = 5
        mapper.modules.append(MapperEntry(
            path="projects/api/decisions.seif",
            category="decisions",
            project="api",
        ))
        save_mapper(str(self.ctx), mapper)

        loaded = load_mapper(str(self.ctx))
        self.assertEqual(loaded.session_count, 5)
        self.assertEqual(len(loaded.modules), 1)
        self.assertEqual(loaded.modules[0].category, "decisions")

    def test_pending_observations(self):
        mapper = Mapper()
        mapper.pending_observations = ["check deadline", "verify API schema"]
        save_mapper(str(self.ctx), mapper)

        loaded = load_mapper(str(self.ctx))
        self.assertEqual(len(loaded.pending_observations), 2)
        self.assertIn("check deadline", loaded.pending_observations)

    def test_rebuild_from_seif_files(self):
        """Mapper should self-heal by scanning existing .seif files."""
        ctx = _create_context_repo_with_project()

        # No mapper.json exists, but project.seif does
        mapper = load_mapper(str(ctx))
        self.assertGreater(len(mapper.modules), 0)

        # Should find the project.seif
        paths = [m.path for m in mapper.modules]
        self.assertTrue(any("project.seif" in p for p in paths))

        shutil.rmtree(str(ctx.parent), ignore_errors=True)


class TestPersistKnowledge(unittest.TestCase):

    def setUp(self):
        self.ctx = _create_context_repo_with_project(autonomous=True)

    def tearDown(self):
        shutil.rmtree(str(self.ctx.parent), ignore_errors=True)

    def test_persist_decision(self):
        entry = persist_knowledge(
            context_repo=str(self.ctx),
            project="api",
            category="decisions",
            content="Chose PostgreSQL over MongoDB for ACID compliance and JSONB support.",
            author="claude-opus",
            trigger="user explained database choice",
        )
        self.assertIsNotNone(entry)
        self.assertEqual(entry.category, "decisions")
        self.assertEqual(entry.project, "api")
        self.assertTrue((self.ctx / "projects" / "api" / "decisions.seif").exists())

    def test_persist_pattern(self):
        entry = persist_knowledge(
            context_repo=str(self.ctx),
            project="api",
            category="patterns",
            content="Repository pattern with dependency injection via constructor. "
                    "All services follow interface-first design.",
            author="claude-opus",
        )
        self.assertIsNotNone(entry)
        self.assertEqual(entry.category, "patterns")

    def test_persist_cross_project(self):
        entry = persist_knowledge(
            context_repo=str(self.ctx),
            project=None,
            category="context",
            content="Deploy freeze starts Thursday 2026-04-03. Mobile team cutting release.",
            author="claude-opus",
        )
        self.assertIsNotNone(entry)
        self.assertIsNone(entry.project)
        self.assertTrue((self.ctx / "modules" / "context.seif").exists())

    def test_blocked_when_disabled(self):
        ctx = _create_context_repo(autonomous=False)
        entry = persist_knowledge(
            context_repo=str(ctx),
            project="api",
            category="decisions",
            content="Some decision.",
            author="claude-opus",
        )
        self.assertIsNone(entry)
        shutil.rmtree(str(ctx.parent), ignore_errors=True)

    def test_blocked_by_category_toggle(self):
        config = load_config(str(self.ctx))
        config["persist_patterns"] = False
        save_config(str(self.ctx), config)

        entry = persist_knowledge(
            context_repo=str(self.ctx),
            project="api",
            category="patterns",
            content="Some pattern.",
            author="claude-opus",
        )
        self.assertIsNone(entry)

    def test_invalid_category_rejected(self):
        entry = persist_knowledge(
            context_repo=str(self.ctx),
            project="api",
            category="invalid_category",
            content="Some content.",
            author="claude-opus",
        )
        self.assertIsNone(entry)

    def test_contribute_to_existing(self):
        """Second persist to same category should contribute, not overwrite."""
        persist_knowledge(
            context_repo=str(self.ctx),
            project="api",
            category="decisions",
            content="Decision 1: Use PostgreSQL.",
            author="claude-opus",
        )
        entry2 = persist_knowledge(
            context_repo=str(self.ctx),
            project="api",
            category="decisions",
            content="Decision 2: Use Redis for caching.",
            author="claude-opus",
        )
        self.assertIsNotNone(entry2)

        # Read the .seif and check both decisions are there
        with open(self.ctx / "projects" / "api" / "decisions.seif") as f:
            data = json.load(f)
        self.assertIn("PostgreSQL", data["summary"])
        self.assertIn("Redis", data["summary"])
        self.assertGreater(data["version"], 1)

    def test_mapper_updated_after_persist(self):
        persist_knowledge(
            context_repo=str(self.ctx),
            project="api",
            category="intent",
            content="Goal: reduce checkout latency below 200ms.",
            author="claude-opus",
        )
        mapper = load_mapper(str(self.ctx))
        paths = [m.path for m in mapper.modules]
        self.assertTrue(any("intent.seif" in p for p in paths))

    def test_max_modules_limit(self):
        """Should not exceed max_modules_per_project."""
        config = load_config(str(self.ctx))
        config["max_modules_per_project"] = 2
        save_config(str(self.ctx), config)

        # project.seif already exists but doesn't count (it's auto-sync)
        persist_knowledge(str(self.ctx), "api", "decisions", "D1", "ai")
        persist_knowledge(str(self.ctx), "api", "patterns", "P1", "ai")

        # Third AI module should be blocked
        entry = persist_knowledge(str(self.ctx), "api", "intent", "I1", "ai")
        self.assertIsNone(entry)


class TestBootstrapContext(unittest.TestCase):

    def setUp(self):
        self.ctx = _create_context_repo_with_project(autonomous=True)

    def tearDown(self):
        shutil.rmtree(str(self.ctx.parent), ignore_errors=True)

    def test_bootstrap_loads_modules(self):
        # Persist some knowledge first
        persist_knowledge(str(self.ctx), "api", "decisions",
                         "Use PostgreSQL for ACID.", "ai")

        mapper = load_mapper(str(self.ctx))
        context = bootstrap_context(mapper, str(self.ctx))
        self.assertIn("PostgreSQL", context)

    def test_bootstrap_respects_token_budget(self):
        # Persist a large module
        big_content = " ".join(["word"] * 5000)
        persist_knowledge(str(self.ctx), "api", "patterns", big_content, "ai")

        mapper = load_mapper(str(self.ctx))
        context = bootstrap_context(mapper, str(self.ctx), max_tokens=500)
        words = len(context.split())
        self.assertLess(words, 500)  # should be truncated

    def test_bootstrap_includes_pending(self):
        mapper = load_mapper(str(self.ctx))
        mapper.pending_observations = ["check API v2 deadline"]
        save_mapper(str(self.ctx), mapper)

        mapper = load_mapper(str(self.ctx))
        context = bootstrap_context(mapper, str(self.ctx))
        self.assertIn("API v2 deadline", context)

    def test_bootstrap_sorts_by_relevance(self):
        persist_knowledge(str(self.ctx), "api", "decisions",
                         "Low relevance decision.", "ai")
        persist_knowledge(str(self.ctx), "api", "intent",
                         "High relevance intent.", "ai")

        mapper = load_mapper(str(self.ctx))
        # Boost intent relevance
        for m in mapper.modules:
            if m.category == "intent":
                m.relevance = 1.0
            elif m.category == "decisions":
                m.relevance = 0.3
        save_mapper(str(self.ctx), mapper)

        mapper = load_mapper(str(self.ctx))
        context = bootstrap_context(mapper, str(self.ctx))
        # Intent should appear before decisions
        intent_pos = context.find("intent")
        decisions_pos = context.find("decisions")
        if intent_pos >= 0 and decisions_pos >= 0:
            self.assertLess(intent_pos, decisions_pos)


class TestSessionLifecycle(unittest.TestCase):

    def setUp(self):
        self.ctx = _create_context_repo_with_project(autonomous=True)

    def tearDown(self):
        shutil.rmtree(str(self.ctx.parent), ignore_errors=True)

    def test_start_session(self):
        config, mapper, context = start_session(str(self.ctx))
        self.assertTrue(is_autonomous(config))
        self.assertEqual(mapper.session_count, 1)

    def test_session_count_increments(self):
        start_session(str(self.ctx))
        _, mapper, _ = start_session(str(self.ctx))
        self.assertEqual(mapper.session_count, 2)

    def test_end_session_saves_observations(self):
        start_session(str(self.ctx))
        mapper = end_session(str(self.ctx), ["check deadline Thursday"])

        loaded = load_mapper(str(self.ctx))
        self.assertIn("check deadline Thursday", loaded.pending_observations)

    def test_end_session_decays_relevance(self):
        persist_knowledge(str(self.ctx), "api", "decisions",
                         "Some decision.", "ai")
        mapper = load_mapper(str(self.ctx))
        initial_relevance = mapper.modules[-1].relevance

        end_session(str(self.ctx))
        mapper = load_mapper(str(self.ctx))
        # Find the decisions entry
        for m in mapper.modules:
            if m.category == "decisions":
                self.assertLess(m.relevance, initial_relevance)
                break

    def test_add_observation(self):
        add_observation(str(self.ctx), "user mentioned API v3 plans")
        mapper = load_mapper(str(self.ctx))
        self.assertIn("user mentioned API v3 plans", mapper.pending_observations)

    def test_observations_capped_at_10(self):
        for i in range(15):
            add_observation(str(self.ctx), f"obs {i}")
        mapper = load_mapper(str(self.ctx))
        self.assertEqual(len(mapper.pending_observations), 10)
        # Should keep the latest
        self.assertIn("obs 14", mapper.pending_observations)


class TestDisabledMode(unittest.TestCase):
    """When autonomous is disabled, nothing should be created."""

    def setUp(self):
        self.ctx = _create_context_repo(autonomous=False)

    def tearDown(self):
        shutil.rmtree(str(self.ctx.parent), ignore_errors=True)

    def test_persist_blocked(self):
        entry = persist_knowledge(str(self.ctx), "api", "decisions",
                                  "Some decision.", "ai")
        self.assertIsNone(entry)

    def test_start_session_returns_empty_context(self):
        config, mapper, context = start_session(str(self.ctx))
        self.assertFalse(is_autonomous(config))
        self.assertEqual(context, "")


class TestClassification(unittest.TestCase):
    """Tests for content classification system."""

    def setUp(self):
        self.config = dict(DEFAULT_CONFIG)
        self.config["autonomous_context"] = True

    def test_default_is_internal(self):
        cls = classify_content("Some technical decision.", "decisions", self.config)
        self.assertEqual(cls, "INTERNAL")

    def test_confidential_keyword_detection(self):
        cls = classify_content(
            "Found a vulnerability in the auth endpoint.",
            "decisions", self.config,
        )
        self.assertEqual(cls, "CONFIDENTIAL")

    def test_multiple_confidential_keywords(self):
        for keyword in ["CVE", "exploit", "secret", "password", "token",
                        "credential", "LGPD", "GDPR", "breach", "pentest"]:
            cls = classify_content(
                f"Text mentioning {keyword} in context.",
                "decisions", self.config,
            )
            self.assertEqual(cls, "CONFIDENTIAL",
                             f"'{keyword}' should trigger CONFIDENTIAL")

    def test_keyword_case_insensitive(self):
        cls = classify_content(
            "The VULNERABILITY was patched.",
            "decisions", self.config,
        )
        self.assertEqual(cls, "CONFIDENTIAL")

    def test_category_rule_override(self):
        self.config["classification_rules"]["patterns"] = "PUBLIC"
        cls = classify_content(
            "Uses repository pattern with DI.",
            "patterns", self.config,
        )
        self.assertEqual(cls, "PUBLIC")

    def test_keyword_overrides_category_rule(self):
        """Confidential keywords should override even PUBLIC category rules."""
        self.config["classification_rules"]["patterns"] = "PUBLIC"
        cls = classify_content(
            "Pattern: store password hashes with bcrypt.",
            "patterns", self.config,
        )
        self.assertEqual(cls, "CONFIDENTIAL")

    def test_custom_keywords(self):
        self.config["confidential_keywords"] = ["project-x", "classified"]
        cls = classify_content(
            "This relates to project-x timeline.",
            "context", self.config,
        )
        self.assertEqual(cls, "CONFIDENTIAL")


class TestClassificationPersistence(unittest.TestCase):
    """Tests that classification is persisted in .seif files and mapper."""

    def setUp(self):
        self.ctx = _create_context_repo_with_project(autonomous=True)

    def tearDown(self):
        shutil.rmtree(str(self.ctx.parent), ignore_errors=True)

    def test_internal_classification_in_mapper(self):
        entry = persist_knowledge(
            str(self.ctx), "api", "decisions",
            "Use PostgreSQL for its JSONB support and relational integrity.",
            "ai",
        )
        self.assertEqual(entry.classification, "INTERNAL")

    def test_confidential_classification_in_mapper(self):
        entry = persist_knowledge(
            str(self.ctx), "api", "decisions",
            "Found vulnerability in payment endpoint. CVE pending.",
            "ai",
        )
        self.assertEqual(entry.classification, "CONFIDENTIAL")

    def test_classification_in_seif_file(self):
        persist_knowledge(
            str(self.ctx), "api", "decisions",
            "Some internal decision.",
            "ai",
        )
        with open(self.ctx / "projects" / "api" / "decisions.seif") as f:
            data = json.load(f)
        self.assertEqual(data["classification"], "INTERNAL")

    def test_classification_escalation(self):
        """Adding confidential content to an INTERNAL module should escalate."""
        persist_knowledge(
            str(self.ctx), "api", "decisions",
            "Use PostgreSQL for ACID.",
            "ai",
        )
        entry = persist_knowledge(
            str(self.ctx), "api", "decisions",
            "Note: found SQL injection vulnerability in legacy query.",
            "ai",
        )
        self.assertEqual(entry.classification, "CONFIDENTIAL")

    def test_classification_never_downgrades(self):
        """Once CONFIDENTIAL, should stay CONFIDENTIAL even with public content."""
        persist_knowledge(
            str(self.ctx), "api", "decisions",
            "Found credential leak in config.",
            "ai",
        )
        entry = persist_knowledge(
            str(self.ctx), "api", "decisions",
            "Also decided to use REST over GraphQL.",
            "ai",
        )
        # Should remain CONFIDENTIAL from the first contribution
        self.assertEqual(entry.classification, "CONFIDENTIAL")


class TestClassificationExport(unittest.TestCase):
    """Tests that bootstrap_context filters by classification."""

    def setUp(self):
        self.ctx = _create_context_repo_with_project(autonomous=True)

    def tearDown(self):
        shutil.rmtree(str(self.ctx.parent), ignore_errors=True)

    def test_export_all(self):
        persist_knowledge(str(self.ctx), "api", "decisions",
                         "Internal decision.", "ai")
        persist_knowledge(str(self.ctx), "api", "feedback",
                         "Found password leak issue.", "ai")

        mapper = load_mapper(str(self.ctx))
        context = bootstrap_context(mapper, str(self.ctx),
                                    max_classification="CONFIDENTIAL")
        self.assertIn("Internal decision", context)
        self.assertIn("password leak", context)

    def test_export_internal_excludes_confidential(self):
        persist_knowledge(str(self.ctx), "api", "decisions",
                         "Internal decision about PostgreSQL.", "ai")
        persist_knowledge(str(self.ctx), "api", "feedback",
                         "Found password leak issue.", "ai")

        mapper = load_mapper(str(self.ctx))
        context = bootstrap_context(mapper, str(self.ctx),
                                    max_classification="INTERNAL")
        self.assertIn("PostgreSQL", context)
        self.assertNotIn("password leak", context)

    def test_export_public_excludes_internal(self):
        persist_knowledge(str(self.ctx), "api", "decisions",
                         "Internal decision.", "ai")

        mapper = load_mapper(str(self.ctx))
        # Set entry to INTERNAL
        for m in mapper.modules:
            if m.category == "decisions":
                m.classification = "INTERNAL"
        save_mapper(str(self.ctx), mapper)

        mapper = load_mapper(str(self.ctx))
        context = bootstrap_context(mapper, str(self.ctx),
                                    max_classification="PUBLIC")
        self.assertNotIn("Internal decision", context)

    def test_classification_tags_in_output(self):
        persist_knowledge(str(self.ctx), "api", "patterns",
                         "Repository pattern with DI.", "ai")

        mapper = load_mapper(str(self.ctx))
        context = bootstrap_context(mapper, str(self.ctx))
        self.assertIn("[INTERNAL]", context)


class TestFindContextRepo(unittest.TestCase):
    """Tests for find_context_repo — walking up the directory tree."""

    def setUp(self):
        # Create a workspace structure:
        # workspace/
        # ├── .seif/config.json    ← context repo here
        # ├── api/src/             ← deep nested project
        # └── web/
        self.workspace = Path(tempfile.mkdtemp())
        seif_dir = self.workspace / ".seif"
        seif_dir.mkdir()
        (seif_dir / "config.json").write_text('{"autonomous_context": true}')
        (seif_dir / "mapper.json").write_text('{"protocol": "SEIF-MAPPER-v1"}')

        self.api_src = self.workspace / "api" / "src" / "main"
        self.api_src.mkdir(parents=True)
        self.web = self.workspace / "web"
        self.web.mkdir()

    def tearDown(self):
        shutil.rmtree(str(self.workspace), ignore_errors=True)

    def test_finds_from_workspace_root(self):
        result = find_context_repo(str(self.workspace))
        self.assertIsNotNone(result)
        self.assertTrue(result.endswith(".seif"))

    def test_finds_from_project_dir(self):
        result = find_context_repo(str(self.workspace / "api"))
        self.assertIsNotNone(result)
        self.assertTrue(result.endswith(".seif"))

    def test_finds_from_deep_nested_dir(self):
        result = find_context_repo(str(self.api_src))
        self.assertIsNotNone(result)
        self.assertTrue(result.endswith(".seif"))

    def test_finds_from_sibling_project(self):
        result = find_context_repo(str(self.web))
        self.assertIsNotNone(result)

    def test_returns_none_when_not_found(self):
        isolated = Path(tempfile.mkdtemp())
        result = find_context_repo(str(isolated))
        self.assertIsNone(result)
        shutil.rmtree(str(isolated), ignore_errors=True)

    def test_ignores_empty_seif_dir(self):
        """A .seif/ dir without markers should not be detected."""
        isolated = Path(tempfile.mkdtemp())
        (isolated / ".seif").mkdir()  # empty, no config/mapper/manifest
        result = find_context_repo(str(isolated))
        self.assertIsNone(result)
        shutil.rmtree(str(isolated), ignore_errors=True)

    def test_start_session_auto_discovers(self):
        """start_session() without explicit path should find .seif/ above."""
        # We can't easily change cwd in tests, so test the explicit path
        config, mapper, context = start_session(str(self.workspace / ".seif"))
        self.assertTrue(is_autonomous(config))

    def test_persist_with_auto_discovery(self):
        """persist_knowledge with explicit context_repo from find_context_repo."""
        ctx = find_context_repo(str(self.workspace / "api"))
        # Create project dir in context repo
        (Path(ctx) / "projects" / "api").mkdir(parents=True)
        entry = persist_knowledge(
            context_repo=ctx,
            project="api",
            category="decisions",
            content="Use FastAPI for async support.",
            author="test",
        )
        self.assertIsNotNone(entry)


class TestConfidentialApprovalGate(unittest.TestCase):
    """Gap 1: CONFIDENTIAL writes require approval when enabled."""

    def setUp(self):
        self.ctx = _create_context_repo_with_project(autonomous=True)
        config = load_config(str(self.ctx))
        config["require_confidential_approval"] = True
        save_config(str(self.ctx), config)

    def tearDown(self):
        shutil.rmtree(str(self.ctx.parent), ignore_errors=True)

    def test_confidential_blocked_when_approval_required(self):
        entry = persist_knowledge(
            str(self.ctx), "api", "decisions",
            "Found vulnerability in auth endpoint.",
            "ai",
        )
        self.assertIsNone(entry)

    def test_confidential_pending_stored_in_mapper(self):
        persist_knowledge(
            str(self.ctx), "api", "decisions",
            "Found vulnerability in auth endpoint.",
            "ai", trigger="security audit",
        )
        mapper = load_mapper(str(self.ctx))
        self.assertTrue(any("CONFIDENTIAL_PENDING" in o
                           for o in mapper.pending_observations))

    def test_confidential_allowed_when_approved(self):
        entry = persist_knowledge(
            str(self.ctx), "api", "decisions",
            "Found vulnerability in auth endpoint.",
            "ai", approved=True,
        )
        self.assertIsNotNone(entry)
        self.assertEqual(entry.classification, "CONFIDENTIAL")

    def test_internal_not_blocked(self):
        """Non-CONFIDENTIAL content should pass even with approval gate on."""
        entry = persist_knowledge(
            str(self.ctx), "api", "patterns",
            "Uses repository pattern with DI.",
            "ai",
        )
        self.assertIsNotNone(entry)

    def test_confidential_allowed_when_toggle_off(self):
        config = load_config(str(self.ctx))
        config["require_confidential_approval"] = False
        save_config(str(self.ctx), config)

        entry = persist_knowledge(
            str(self.ctx), "api", "decisions",
            "Found vulnerability in auth endpoint.",
            "ai",
        )
        self.assertIsNotNone(entry)


class TestClassificationOverride(unittest.TestCase):
    """Gap 2: Manual override of auto-classification."""

    def setUp(self):
        self.ctx = _create_context_repo_with_project(autonomous=True)

    def tearDown(self):
        shutil.rmtree(str(self.ctx.parent), ignore_errors=True)

    def test_override_parameter(self):
        entry = persist_knowledge(
            str(self.ctx), "api", "decisions",
            "Discussion about CVE-2024-1234 in public blog.",
            "ai", classification_override="PUBLIC",
        )
        self.assertIsNotNone(entry)
        self.assertEqual(entry.classification, "PUBLIC")

    def test_config_override_by_project_category(self):
        config = load_config(str(self.ctx))
        config["classification_overrides"] = {"api/context": "PUBLIC"}
        save_config(str(self.ctx), config)

        entry = persist_knowledge(
            str(self.ctx), "api", "context",
            "Public CVE discussion for open source project.",
            "ai",
        )
        self.assertIsNotNone(entry)
        self.assertEqual(entry.classification, "PUBLIC")

    def test_override_invalid_level_ignored(self):
        config = load_config(str(self.ctx))
        cls = classify_content("normal text", "decisions", config, override="INVALID")
        self.assertEqual(cls, "INTERNAL")  # falls through to auto

    def test_classify_direct_override(self):
        config = load_config(str(self.ctx))
        cls = classify_content("text with vulnerability", "decisions", config,
                               override="PUBLIC")
        self.assertEqual(cls, "PUBLIC")


class TestConfigurableDecay(unittest.TestCase):
    """Gap 3: Relevance decay factor from config."""

    def setUp(self):
        self.ctx = _create_context_repo_with_project(autonomous=True)

    def tearDown(self):
        shutil.rmtree(str(self.ctx.parent), ignore_errors=True)

    def test_custom_decay_factor(self):
        config = load_config(str(self.ctx))
        config["relevance_decay"] = 0.80
        save_config(str(self.ctx), config)

        persist_knowledge(str(self.ctx), "api", "decisions",
                         "Some decision.", "ai")
        mapper = load_mapper(str(self.ctx))
        for m in mapper.modules:
            if m.category == "decisions":
                m.relevance = 1.0
        save_mapper(str(self.ctx), mapper)

        end_session(str(self.ctx))
        mapper = load_mapper(str(self.ctx))
        for m in mapper.modules:
            if m.category == "decisions":
                self.assertAlmostEqual(m.relevance, 0.80, places=2)

    def test_decay_clamped_high(self):
        config = load_config(str(self.ctx))
        config["relevance_decay"] = 1.5  # invalid, should clamp to 1.0
        save_config(str(self.ctx), config)

        persist_knowledge(str(self.ctx), "api", "decisions",
                         "Some decision.", "ai")
        end_session(str(self.ctx))
        mapper = load_mapper(str(self.ctx))
        for m in mapper.modules:
            if m.category == "decisions":
                self.assertLessEqual(m.relevance, 1.0)

    def test_decay_clamped_low(self):
        config = load_config(str(self.ctx))
        config["relevance_decay"] = -0.1  # invalid, should clamp to 0.0
        save_config(str(self.ctx), config)

        persist_knowledge(str(self.ctx), "api", "decisions",
                         "Some decision.", "ai")
        end_session(str(self.ctx))
        mapper = load_mapper(str(self.ctx))
        for m in mapper.modules:
            if m.category == "decisions":
                self.assertEqual(m.relevance, 0.1)  # min floor


class TestReadOnlyMode(unittest.TestCase):
    """Gap 4: Read-only mode for shared environments."""

    def setUp(self):
        self.ctx = _create_context_repo_with_project(autonomous=True)
        # Pre-populate a module so bootstrap has something to read
        persist_knowledge(str(self.ctx), "api", "decisions",
                         "Use PostgreSQL for relational data.", "ai")
        # Now enable read-only
        config = load_config(str(self.ctx))
        config["read_only"] = True
        save_config(str(self.ctx), config)

    def tearDown(self):
        shutil.rmtree(str(self.ctx.parent), ignore_errors=True)

    def test_read_only_blocks_persist(self):
        entry = persist_knowledge(
            str(self.ctx), "api", "patterns",
            "Some new pattern.", "ai",
        )
        self.assertIsNone(entry)

    def test_read_only_allows_bootstrap(self):
        mapper = load_mapper(str(self.ctx))
        context = bootstrap_context(mapper, str(self.ctx))
        self.assertIn("PostgreSQL", context)

    def test_read_only_blocks_end_session_writes(self):
        mapper_before = load_mapper(str(self.ctx))
        relevances_before = {m.path: m.relevance for m in mapper_before.modules}

        end_session(str(self.ctx))

        mapper_after = load_mapper(str(self.ctx))
        relevances_after = {m.path: m.relevance for m in mapper_after.modules}
        self.assertEqual(relevances_before, relevances_after)

    def test_read_only_blocks_add_observation(self):
        add_observation(str(self.ctx), "should not be saved")
        mapper = load_mapper(str(self.ctx))
        self.assertNotIn("should not be saved", mapper.pending_observations)

    def test_read_only_start_session_no_increment(self):
        mapper_before = load_mapper(str(self.ctx))
        count_before = mapper_before.session_count

        start_session(str(self.ctx))
        start_session(str(self.ctx))

        mapper_after = load_mapper(str(self.ctx))
        self.assertEqual(mapper_after.session_count, count_before)


if __name__ == "__main__":
    unittest.main()
