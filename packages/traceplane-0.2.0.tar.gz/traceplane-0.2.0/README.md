# Traceplane

Python SDK for the Traceplane trajectory data platform.

## Installation

```bash
pip install traceplane
```

With framework extras:

```bash
pip install traceplane[torch]     # PyTorch DataLoader
pip install traceplane[jax]       # JAX support
pip install traceplane[training]  # Diffusion policy training
pip install traceplane[all]       # Everything
```

## Quick Start

```python
from traceplane import TraceplaneClient

client = TraceplaneClient("https://api.traceplane.ai", api_key="tp_live_...")

# Register a dataset
client.register("my_data", "/path/to/dataset", include_data=True)

# Query with SQL
rows = client.sql_rows("SELECT * FROM my_data WHERE frame_count > 100")

# Upload data
client.upload_dataset("my_data", "/path/to/parquet/files/")

# Vector search
results = client.search_similar("my_data", episode_index=0, k=5)
```

## Features

- **SQL query engine** -- register datasets and query with full SQL, including vector UDFs (`vec_mean`, `vec_norm`, `vec_cosine_sim`, etc.)
- **Streaming dataloaders** -- PyTorch, JAX, and TensorFlow adapters with windowed sampling
- **LeRobot format** -- native reader for LeRobot v2/v3 datasets (Parquet + MP4)
- **Similarity search** -- find related episodes via embedding-based vector search
- **Dataset upload** -- push local Parquet files to the platform
- **Retargeting** -- XR hand poses to robot action space via calibration bridge
- **Training** -- built-in diffusion policy training with `traceplane-train` CLI

## Training Integration

```python
from traceplane import LeRobotReader
from traceplane.torch import TorchEpisodeLoader

reader = LeRobotReader("/path/to/lerobot/dataset")
loader = TorchEpisodeLoader(reader, batch_size=32, window_size=16)

for batch in loader:
    observations = batch["observation"]
    actions = batch["action"]
    # ... your training loop
```

## API Reference

Full documentation: [docs.traceplane.ai](https://docs.traceplane.ai)

## License

Apache-2.0
