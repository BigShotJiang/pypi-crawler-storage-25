"""Tests for core dataset, windowing, and LeRobot reader."""

import json
import tempfile
from pathlib import Path

import numpy as np
import pyarrow as pa
import pyarrow.parquet as pq
import pytest

from traceplane.dataset import Episode, FilteredDataset
from traceplane.lerobot_reader import LeRobotReader
from traceplane.windowing import WindowedDataset


# ---------------------------------------------------------------------------
# Helpers — create a minimal LeRobot v2 dataset on disk
# ---------------------------------------------------------------------------


def make_lerobot_dataset(root: Path, n_episodes: int = 3, frames: int = 50) -> None:
    """Write a minimal LeRobot v2 dataset structure."""
    meta = root / "meta"
    meta.mkdir(parents=True)
    data = root / "data"
    data.mkdir()

    action_dim = 7
    state_dim = 7
    fps = 30.0

    # info.json
    info = {
        "fps": fps,
        "total_episodes": n_episodes,
        "total_frames": n_episodes * frames,
        "robot_type": "test_robot",
    }
    (meta / "info.json").write_text(json.dumps(info))

    # tasks.jsonl
    tasks = [
        {"task_index": 0, "task": "pick up object"},
        {"task_index": 1, "task": "place on shelf"},
    ]
    (meta / "tasks.jsonl").write_text(
        "\n".join(json.dumps(t) for t in tasks) + "\n"
    )

    # episodes.jsonl
    episodes = []
    for i in range(n_episodes):
        episodes.append(
            {
                "episode_index": i,
                "tasks": [i % 2],
                "length": frames,
            }
        )
    (meta / "episodes.jsonl").write_text(
        "\n".join(json.dumps(e) for e in episodes) + "\n"
    )

    # Parquet files (flat layout)
    for i in range(n_episodes):
        rng = np.random.default_rng(seed=i)
        T = frames

        columns = {
            "index": pa.array(list(range(T)), type=pa.int64()),
            "timestamp": pa.array(np.arange(T) / fps, type=pa.float64()),
        }

        # Actions
        actions = rng.standard_normal((T, action_dim)).astype(np.float32)
        for d in range(action_dim):
            columns[f"action_{d}"] = pa.array(actions[:, d])

        # State observations
        state = rng.standard_normal((T, state_dim)).astype(np.float32)
        for d in range(state_dim):
            columns[f"observation.state_{d}"] = pa.array(state[:, d])

        table = pa.table(columns)
        pq.write_table(table, data / f"episode_{i:06d}.parquet")


# ---------------------------------------------------------------------------
# Episode tests
# ---------------------------------------------------------------------------


class TestEpisode:
    def test_empty_episode(self):
        ep = Episode(episode_id="test")
        assert ep.length == 0
        assert ep.action_dim == 0

    def test_episode_with_data(self):
        actions = np.random.randn(100, 7).astype(np.float32)
        ep = Episode(
            episode_id="ep_001",
            actions=actions,
            timestamps=np.arange(100, dtype=np.float64) / 30.0,
            observations={"state": np.random.randn(100, 7).astype(np.float32)},
            metadata={"task": "test"},
        )
        assert ep.length == 100
        assert ep.action_dim == 7


# ---------------------------------------------------------------------------
# LeRobotReader tests
# ---------------------------------------------------------------------------


class TestLeRobotReader:
    def test_read_dataset(self, tmp_path):
        make_lerobot_dataset(tmp_path, n_episodes=3, frames=50)
        reader = LeRobotReader(str(tmp_path))

        assert len(reader) == 3
        assert reader.fps == 30.0
        assert len(reader.episode_ids()) == 3

    def test_load_episode(self, tmp_path):
        make_lerobot_dataset(tmp_path, n_episodes=2, frames=30)
        reader = LeRobotReader(str(tmp_path))

        ep = reader[0]
        assert ep.episode_id == "episode_000000"
        assert ep.length == 30
        assert ep.action_dim == 7
        assert "state" in ep.observations
        assert ep.observations["state"].shape == (30, 7)
        assert ep.metadata["task_label"] == "pick up object"

    def test_subset_indices(self, tmp_path):
        make_lerobot_dataset(tmp_path, n_episodes=5, frames=20)
        reader = LeRobotReader(str(tmp_path), episode_indices=[1, 3])

        assert len(reader) == 2
        ids = reader.episode_ids()
        assert ids[0] == "episode_000001"
        assert ids[1] == "episode_000003"

    def test_filter(self, tmp_path):
        make_lerobot_dataset(tmp_path, n_episodes=4, frames=20)
        reader = LeRobotReader(str(tmp_path))
        filtered = reader.filter(["episode_000001", "episode_000002"])

        assert len(filtered) == 2
        ep = filtered[0]
        assert ep.episode_id == "episode_000001"

    def test_iteration(self, tmp_path):
        make_lerobot_dataset(tmp_path, n_episodes=3, frames=10)
        reader = LeRobotReader(str(tmp_path))

        episodes = list(reader)
        assert len(episodes) == 3
        for ep in episodes:
            assert ep.length == 10


# ---------------------------------------------------------------------------
# Windowing tests
# ---------------------------------------------------------------------------


class TestWindowedDataset:
    def test_window_count(self, tmp_path):
        make_lerobot_dataset(tmp_path, n_episodes=2, frames=50)
        reader = LeRobotReader(str(tmp_path))
        windowed = WindowedDataset(
            reader, obs_horizon=2, action_horizon=16, stride=1
        )

        # Each episode: valid range is [1, 50-16+1) = [1, 35) = 34 windows
        # 2 episodes * 34 = 68
        assert len(windowed) == 68

    def test_window_shapes(self, tmp_path):
        make_lerobot_dataset(tmp_path, n_episodes=1, frames=50)
        reader = LeRobotReader(str(tmp_path))
        windowed = WindowedDataset(
            reader, obs_horizon=4, action_horizon=8, stride=1
        )

        w = windowed[0]
        assert w.action_chunk.shape[0] == 8
        assert "state" in w.obs_history
        assert w.obs_history["state"].shape[0] == 4

    def test_window_stride(self, tmp_path):
        make_lerobot_dataset(tmp_path, n_episodes=1, frames=50)
        reader = LeRobotReader(str(tmp_path))

        w1 = WindowedDataset(reader, obs_horizon=2, action_horizon=16, stride=1)
        w2 = WindowedDataset(reader, obs_horizon=2, action_horizon=16, stride=5)

        # stride=5 should produce roughly 1/5 the windows
        assert len(w2) < len(w1)
        assert len(w2) == len(range(1, 35, 5))  # 7 windows

    def test_action_padding(self, tmp_path):
        """Windows near episode end should pad actions."""
        make_lerobot_dataset(tmp_path, n_episodes=1, frames=20)
        reader = LeRobotReader(str(tmp_path))
        windowed = WindowedDataset(
            reader, obs_horizon=1, action_horizon=16, stride=1
        )

        # Last window should still have action_horizon actions (padded)
        last = windowed[len(windowed) - 1]
        assert last.action_chunk.shape[0] == 16
