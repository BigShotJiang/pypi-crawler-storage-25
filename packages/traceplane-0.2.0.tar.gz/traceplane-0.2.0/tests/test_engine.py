"""Tests for the SQL engine integration in TraceplaneClient.

These tests require a running API server at localhost:8000.
They are skipped if the server is not available.
"""

import pytest
import requests

from traceplane import TraceplaneClient

G1_PATH = "/Users/taha/Startup/test-data/g1-grasp"


def api_available() -> bool:
    try:
        r = requests.get("http://localhost:8000/health", timeout=2)
        return r.status_code == 200
    except Exception:
        return False


skip_no_api = pytest.mark.skipif(
    not api_available(), reason="API server not running at localhost:8000"
)


import time

# Unique prefix per test run to avoid "table already exists"
_RUN_ID = str(int(time.time()))
_TABLE = f"g1_{_RUN_ID}"


@skip_no_api
class TestEngine:
    """Engine integration tests against running API + g1-grasp dataset."""

    _registered = False

    @pytest.fixture(autouse=True)
    def client(self):
        self.client = TraceplaneClient()
        if not TestEngine._registered:
            self.client.register(_TABLE, G1_PATH, include_data=True)
            TestEngine._registered = True

    def test_health(self):
        result = self.client.health()
        assert result["status"] == "ok"

    def test_tables(self):
        tables = self.client.tables()
        assert _TABLE in tables
        assert f"{_TABLE}_data" in tables

    def test_sql_count(self):
        result = self.client.sql(f"SELECT COUNT(*) AS cnt FROM {_TABLE}")
        assert result["row_count"] == 1
        assert result["rows"][0]["cnt"] == 301

    def test_sql_rows(self):
        rows = self.client.sql_rows(
            f"SELECT episode_index, length FROM {_TABLE} "
            "WHERE length > 1000 ORDER BY length DESC LIMIT 3"
        )
        assert len(rows) > 0
        assert all(r["length"] > 1000 for r in rows)

    def test_sql_udf(self):
        rows = self.client.sql_rows(
            f"SELECT episode_index, vec_dim(action) AS dims, "
            f"vec_mean(action) AS mean_action "
            f"FROM {_TABLE}_data WHERE episode_index = 0 LIMIT 3"
        )
        assert len(rows) == 3
        assert rows[0]["dims"] == 28  # Unitree G1 = 28 DoF

    def test_sql_and_load(self):
        load_name = f"g1_load_{_RUN_ID}"
        dataset = self.client.sql_and_load(
            dataset_path=G1_PATH,
            name=load_name,
            sql_filter="length > 1500",
        )
        assert len(dataset) > 0
        assert len(dataset) < 301

        ep = dataset[0]
        assert ep.length > 0
        assert ep.actions.shape[1] == 28  # 28 DoF
