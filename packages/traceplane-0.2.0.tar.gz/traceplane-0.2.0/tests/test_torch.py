"""Tests for PyTorch integration."""

import json
from pathlib import Path

import numpy as np
import pyarrow as pa
import pyarrow.parquet as pq
import pytest
import torch

from traceplane.lerobot_reader import LeRobotReader
from traceplane.torch import EpisodeDataset, WindowDataset, make_dataloader
from traceplane.windowing import WindowedDataset


def make_lerobot_dataset(root: Path, n_episodes: int = 3, frames: int = 50) -> None:
    meta = root / "meta"
    meta.mkdir(parents=True)
    data = root / "data"
    data.mkdir()

    action_dim = 7
    state_dim = 7
    fps = 30.0

    (meta / "info.json").write_text(json.dumps({
        "fps": fps,
        "total_episodes": n_episodes,
        "total_frames": n_episodes * frames,
    }))

    tasks = [{"task_index": 0, "task": "pick up object"}]
    (meta / "tasks.jsonl").write_text(json.dumps(tasks[0]) + "\n")

    episodes = []
    for i in range(n_episodes):
        episodes.append({"episode_index": i, "tasks": [0], "length": frames})
    (meta / "episodes.jsonl").write_text(
        "\n".join(json.dumps(e) for e in episodes) + "\n"
    )

    for i in range(n_episodes):
        rng = np.random.default_rng(seed=i)
        T = frames
        columns = {
            "timestamp": pa.array(np.arange(T) / fps, type=pa.float64()),
        }
        actions = rng.standard_normal((T, action_dim)).astype(np.float32)
        for d in range(action_dim):
            columns[f"action_{d}"] = pa.array(actions[:, d])
        state = rng.standard_normal((T, state_dim)).astype(np.float32)
        for d in range(state_dim):
            columns[f"observation.state_{d}"] = pa.array(state[:, d])

        pq.write_table(pa.table(columns), data / f"episode_{i:06d}.parquet")


class TestEpisodeDataset:
    def test_episode_tensors(self, tmp_path):
        make_lerobot_dataset(tmp_path, n_episodes=2, frames=30)
        reader = LeRobotReader(str(tmp_path))
        ds = EpisodeDataset(reader)

        assert len(ds) == 2
        item = ds[0]
        assert isinstance(item["actions"], torch.Tensor)
        assert item["actions"].shape == (30, 7)
        assert item["actions"].dtype == torch.float32
        assert "state" in item
        assert item["state"].shape == (30, 7)


class TestWindowDataset:
    def test_window_tensors(self, tmp_path):
        make_lerobot_dataset(tmp_path, n_episodes=1, frames=50)
        reader = LeRobotReader(str(tmp_path))
        windowed = WindowedDataset(reader, obs_horizon=2, action_horizon=16)
        ds = WindowDataset(windowed)

        item = ds[0]
        assert isinstance(item["action_chunk"], torch.Tensor)
        assert item["action_chunk"].shape == (16, 7)
        assert "state" in item["obs_history"]
        assert item["obs_history"]["state"].shape == (2, 7)


class TestMakeDataloader:
    def test_dataloader(self, tmp_path):
        make_lerobot_dataset(tmp_path, n_episodes=2, frames=50)
        reader = LeRobotReader(str(tmp_path))

        loader = make_dataloader(
            reader,
            obs_horizon=2,
            action_horizon=16,
            batch_size=8,
            shuffle=False,
            num_workers=0,
        )

        batch = next(iter(loader))
        assert batch["action_chunk"].shape[0] == 8  # batch size
        assert batch["action_chunk"].shape[1] == 16  # action horizon
        assert batch["action_chunk"].shape[2] == 7  # action dim
        assert "state" in batch["obs_history"]
        assert batch["obs_history"]["state"].shape == (8, 2, 7)
