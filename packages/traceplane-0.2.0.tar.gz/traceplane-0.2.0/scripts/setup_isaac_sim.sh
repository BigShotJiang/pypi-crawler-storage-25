#!/usr/bin/env bash
# Traceplane Isaac Sim Setup — Ubuntu 22.04/24.04 + NVIDIA RTX 5080
#
# Prerequisites:
#   - Ubuntu 22.04 or 24.04
#   - NVIDIA driver >= 565 (required for RTX 5080 / Blackwell)
#   - Python 3.10+
#
# Usage:
#   chmod +x scripts/setup_isaac_sim.sh
#   ./scripts/setup_isaac_sim.sh

set -euo pipefail

echo "=== Traceplane Isaac Sim Setup ==="
echo ""

# Check OS
if ! grep -qE "22\.04|24\.04" /etc/lsb-release 2>/dev/null; then
    echo "WARNING: This script targets Ubuntu 22.04/24.04."
    echo "Current OS: $(lsb_release -ds 2>/dev/null || echo 'unknown')"
    echo ""
fi

# Check NVIDIA driver
if ! command -v nvidia-smi &>/dev/null; then
    echo "ERROR: nvidia-smi not found. Install NVIDIA driver first:"
    echo "  sudo apt update && sudo apt install nvidia-driver-565"
    exit 1
fi

DRIVER_VERSION=$(nvidia-smi --query-gpu=driver_version --format=csv,noheader | head -1)
echo "NVIDIA driver: $DRIVER_VERSION"

DRIVER_MAJOR=$(echo "$DRIVER_VERSION" | cut -d. -f1)
if [ "$DRIVER_MAJOR" -lt 565 ]; then
    echo "WARNING: Driver $DRIVER_VERSION may be too old for RTX 5080."
    echo "Recommended: >= 565. Install with:"
    echo "  sudo apt install nvidia-driver-565"
    echo ""
fi

# Check GPU
GPU_NAME=$(nvidia-smi --query-gpu=name --format=csv,noheader | head -1)
echo "GPU: $GPU_NAME"
echo ""

# Check Python
PYTHON=${PYTHON:-python3}
PY_VERSION=$($PYTHON --version 2>&1)
echo "Python: $PY_VERSION"
echo ""

# Install Isaac Sim
echo "=== Installing Isaac Sim 5.x ==="
echo "This may take several minutes..."
$PYTHON -m pip install isaacsim==5.* --extra-index-url https://pypi.nvidia.com

# Install Traceplane sim module
echo ""
echo "=== Installing Traceplane sim module ==="
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DATALOADER_DIR="$(dirname "$SCRIPT_DIR")"
$PYTHON -m pip install -e "$DATALOADER_DIR[sim]"

# Smoke test
echo ""
echo "=== Smoke test ==="
$PYTHON -c "
from isaacsim import SimulationApp
app = SimulationApp({'headless': True})
print('Isaac Sim loaded successfully')
app.close()
print('Smoke test passed!')
"

echo ""
echo "=== Setup complete ==="
echo ""
echo "Quick start:"
echo "  # Replay a dataset episode in sim"
echo "  traceplane-sim-viz --dataset-path /path/to/dataset --episode-index 0"
echo ""
echo "  # Evaluate a policy"
echo "  traceplane-sim-eval /path/to/checkpoint.pt --num-episodes 10 --headless"
