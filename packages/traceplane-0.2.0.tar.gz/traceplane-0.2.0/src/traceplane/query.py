"""Client for the Traceplane REST API — query and filter episodes remotely."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import requests

from traceplane.dataset import TrajectoryDataset
from traceplane.lerobot_reader import LeRobotReader


class TraceplaneClient:
    """HTTP client for the Traceplane API.

    Lets you query episodes from a remote server and then load only
    the matching ones into a dataset.

    Args:
        base_url: API base URL (e.g. ``http://localhost:8000``).
        timeout: Request timeout in seconds.
    """

    def __init__(
        self,
        base_url: str = "http://localhost:8000",
        timeout: int = 30,
        api_key: str | None = None,
    ):
        self._base = base_url.rstrip("/")
        self._timeout = timeout
        self._session = requests.Session()
        self._session.headers["Content-Type"] = "application/json"
        if api_key is not None:
            self._session.headers["Authorization"] = f"Bearer {api_key}"

    # -- Health ---------------------------------------------------------------

    def health(self) -> dict[str, Any]:
        """Check API health."""
        resp = self._session.get(f"{self._base}/health", timeout=self._timeout)
        resp.raise_for_status()
        return resp.json()

    # -- Datasets -------------------------------------------------------------

    def list_datasets(self) -> list[dict[str, Any]]:
        resp = self._session.get(f"{self._base}/datasets", timeout=self._timeout)
        resp.raise_for_status()
        return resp.json()

    def get_dataset(self, dataset_id: str) -> dict[str, Any]:
        resp = self._session.get(
            f"{self._base}/datasets/{dataset_id}", timeout=self._timeout
        )
        resp.raise_for_status()
        return resp.json()

    def create_dataset(
        self,
        dataset_id: str,
        display_name: str | None = None,
        description: str | None = None,
        tags: list[str] | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {"id": dataset_id}
        if display_name:
            body["display_name"] = display_name
        if description:
            body["description"] = description
        if tags:
            body["tags"] = tags
        resp = self._session.post(
            f"{self._base}/datasets", json=body, timeout=self._timeout
        )
        resp.raise_for_status()
        return resp.json()

    # -- Query ----------------------------------------------------------------

    def query(
        self,
        dataset_path: str,
        format: str = "lerobot",
        scan_limit: int | None = None,
        **filters: Any,
    ) -> dict[str, Any]:
        """Query episodes by metadata predicates.

        Args:
            dataset_path: Path to dataset on the server's filesystem.
            format: Dataset format (``lerobot`` or ``hdf5``).
            scan_limit: Max episodes to scan from source.
            **filters: Query predicates (task_contains, min_frames, etc.).

        Returns:
            Dict with ``total_scanned``, ``total_matches``, ``episode_ids``.
        """
        body: dict[str, Any] = {
            "dataset_path": dataset_path,
            "format": format,
        }
        if scan_limit is not None:
            body["scan_limit"] = scan_limit
        body.update(filters)

        resp = self._session.post(
            f"{self._base}/query", json=body, timeout=self._timeout
        )
        resp.raise_for_status()
        return resp.json()

    def query_and_load(
        self,
        dataset_path: str,
        format: str = "lerobot",
        storage_options: dict[str, Any] | None = None,
        **filters: Any,
    ) -> TrajectoryDataset:
        """Query the API, then load only matching episodes into a dataset.

        This is the primary workflow: filter on the server, load locally.

        Args:
            dataset_path: Path to dataset (must be accessible both by server
                and by this client for loading).
            format: Dataset format.
            storage_options: fsspec options for remote access.
            **filters: Query predicates.

        Returns:
            A filtered ``LeRobotReader`` containing only matched episodes.
        """
        result = self.query(dataset_path, format=format, **filters)
        episode_ids: list[str] = result.get("episode_ids", [])

        if not episode_ids:
            # Return empty reader
            reader = LeRobotReader(
                dataset_path,
                storage_options=storage_options,
                episode_indices=[],
            )
            return reader

        # Convert episode IDs to indices
        indices = []
        for eid in episode_ids:
            # Parse "episode_000042" -> 42
            try:
                idx = int(eid.split("_")[-1])
                indices.append(idx)
            except (ValueError, IndexError):
                continue

        return LeRobotReader(
            dataset_path,
            storage_options=storage_options,
            episode_indices=indices,
        )

    # -- SQL Engine -----------------------------------------------------------

    def register(
        self,
        name: str,
        dataset_path: str,
        include_data: bool = True,
    ) -> dict[str, Any]:
        """Register a dataset in the DataFusion query engine.

        After registration, the dataset is queryable via SQL::

            client.sql("SELECT COUNT(*) FROM my_dataset")

        Args:
            name: Table name for SQL queries.
            dataset_path: Path to dataset on the server's filesystem.
            include_data: Also register per-timestep trajectory data
                as ``{name}_data``.

        Returns:
            Dict with ``episodes_registered``, ``data_registered``,
            ``format_version``.
        """
        resp = self._session.post(
            f"{self._base}/engine/register",
            json={
                "name": name,
                "dataset_path": dataset_path,
                "include_data": include_data,
            },
            timeout=self._timeout,
        )
        resp.raise_for_status()
        return resp.json()

    def sql(self, query: str) -> dict[str, Any]:
        """Execute a SQL query against the engine.

        Supports all registered tables and built-in trajectory UDFs:
        ``vec_mean``, ``vec_norm``, ``vec_dim``, ``vec_min``, ``vec_max``,
        ``vec_element``, ``vec_sum``, ``vec_abs_max``, ``vec_diff``,
        ``vec_dot``, ``vec_cosine_sim``.

        Args:
            query: SQL query string.

        Returns:
            Dict with ``row_count`` and ``rows`` (list of dicts).

        Example::

            result = client.sql(
                "SELECT episode_index, vec_mean(action) AS mean_action "
                "FROM g1_data WHERE episode_index < 5"
            )
            for row in result["rows"]:
                print(row["episode_index"], row["mean_action"])
        """
        resp = self._session.post(
            f"{self._base}/sql",
            json={"query": query},
            timeout=self._timeout,
        )
        resp.raise_for_status()
        return resp.json()

    def sql_rows(self, query: str) -> list[dict[str, Any]]:
        """Execute SQL and return just the rows (convenience wrapper).

        Args:
            query: SQL query string.

        Returns:
            List of row dicts.
        """
        return self.sql(query)["rows"]

    def tables(self) -> list[str]:
        """List all tables registered in the engine."""
        resp = self._session.get(
            f"{self._base}/engine/tables", timeout=self._timeout
        )
        resp.raise_for_status()
        return resp.json().get("tables", [])

    def materialize(
        self,
        query: str,
        output_path: str,
    ) -> dict[str, Any]:
        """Materialize a SQL query to Parquet files.

        Args:
            query: SQL query whose results will be written.
            output_path: Directory on the server for output Parquet files.

        Returns:
            Dict with ``row_count`` and ``output_path``.
        """
        resp = self._session.post(
            f"{self._base}/engine/materialize",
            json={"query": query, "output_path": output_path},
            timeout=self._timeout,
        )
        resp.raise_for_status()
        return resp.json()

    def sql_and_load(
        self,
        dataset_path: str,
        name: str,
        sql_filter: str,
        storage_options: dict[str, Any] | None = None,
        include_data: bool = False,
    ) -> TrajectoryDataset:
        """Register a dataset, query with SQL, load matching episodes.

        Convenience method combining register + SQL + local loading.

        Args:
            dataset_path: Path to dataset on the server.
            name: Table name for registration.
            sql_filter: SQL WHERE clause (without WHERE keyword) to filter
                episodes, e.g. ``"length > 500 AND episode_index < 100"``.
            storage_options: fsspec options for local data access.
            include_data: Register trajectory data table too.

        Returns:
            A filtered ``LeRobotReader`` with matching episodes.
        """
        self.register(name, dataset_path, include_data=include_data)

        rows = self.sql_rows(
            f"SELECT episode_index FROM {name} WHERE {sql_filter}"
        )
        indices = [int(r["episode_index"]) for r in rows]

        if not indices:
            return LeRobotReader(
                dataset_path,
                storage_options=storage_options,
                episode_indices=[],
            )

        return LeRobotReader(
            dataset_path,
            storage_options=storage_options,
            episode_indices=indices,
        )

    # -- Embodiments ----------------------------------------------------------

    def list_embodiments(self) -> list[dict[str, Any]]:
        resp = self._session.get(
            f"{self._base}/embodiments", timeout=self._timeout
        )
        resp.raise_for_status()
        return resp.json().get("presets", [])

    def get_embodiment(self, preset_id: str) -> dict[str, Any]:
        resp = self._session.get(
            f"{self._base}/embodiments/{preset_id}", timeout=self._timeout
        )
        resp.raise_for_status()
        return resp.json()

    # -- Search ---------------------------------------------------------------

    def register_embeddings(self, name: str, dataset_path: str) -> dict[str, Any]:
        """Register pre-computed embeddings for similarity search.

        The embeddings Parquet should be at
        ``{dataset_path}/embeddings/episode_embeddings.parquet``.
        """
        resp = self._session.post(
            f"{self._base}/search/register-embeddings",
            json={"name": name, "dataset_path": dataset_path},
            timeout=self._timeout,
        )
        resp.raise_for_status()
        return resp.json()

    def search_similar(
        self,
        name: str,
        episode_index: int | None = None,
        query_vector: list[float] | None = None,
        embedding_column: str = "trajectory_embedding",
        k: int = 10,
    ) -> list[dict[str, Any]]:
        """Find episodes similar to a query episode or vector.

        Args:
            name: Registered dataset name.
            episode_index: Find episodes similar to this one.
            query_vector: Or provide a raw embedding vector.
            embedding_column: Which embedding to search against.
            k: Number of results.

        Returns:
            List of dicts with episode_index, task_label, similarity.
        """
        body: dict[str, Any] = {
            "name": name,
            "embedding_column": embedding_column,
            "k": k,
        }
        if episode_index is not None:
            body["episode_index"] = episode_index
        if query_vector is not None:
            body["query_vector"] = query_vector
        resp = self._session.post(
            f"{self._base}/search/similar",
            json=body,
            timeout=self._timeout,
        )
        resp.raise_for_status()
        return resp.json().get("results", [])

    def search_similar_and_load(
        self,
        dataset_path: str,
        name: str,
        episode_index: int,
        k: int = 10,
        storage_options: dict[str, Any] | None = None,
    ) -> TrajectoryDataset:
        """Find similar episodes and load them as a dataset.

        Combines similarity search with local data loading.
        """
        results = self.search_similar(name, episode_index=episode_index, k=k)
        indices = [int(r["episode_index"]) for r in results]
        if not indices:
            return LeRobotReader(dataset_path, storage_options=storage_options, episode_indices=[])
        return LeRobotReader(dataset_path, storage_options=storage_options, episode_indices=indices)

    # -- Bridge ---------------------------------------------------------------

    def create_calibration(
        self,
        embodiment_id: str,
        translation: list[float],
        rotation: list[float],
        method: str = "manual_entry",
        description: str | None = None,
    ) -> dict[str, Any]:
        """Create a calibration (XR world frame -> robot base frame).

        Args:
            embodiment_id: Robot embodiment preset ID.
            translation: [x, y, z] translation in meters.
            rotation: [x, y, z, w] quaternion rotation.
            method: Calibration method (manual_entry, manual_markers, aruco_board).
            description: Optional human-readable description.
        """
        body: dict[str, Any] = {
            "embodiment_id": embodiment_id,
            "translation": translation,
            "rotation": rotation,
            "method": method,
        }
        if description:
            body["description"] = description
        resp = self._session.post(
            f"{self._base}/bridge/calibrations", json=body, timeout=self._timeout
        )
        resp.raise_for_status()
        return resp.json()

    def list_calibrations(self) -> list[dict[str, Any]]:
        """List all calibration records."""
        resp = self._session.get(
            f"{self._base}/bridge/calibrations", timeout=self._timeout
        )
        resp.raise_for_status()
        return resp.json()

    def retarget(
        self,
        calibration_id: str,
        embodiment_id: str,
        hand_joints: list[dict[str, Any]],
        target_group: str = "arm",
        strategy: str = "wrist_pose_with_grasp",
    ) -> dict[str, Any]:
        """Retarget a single hand frame to robot action space.

        Args:
            calibration_id: ID of the calibration record to use.
            embodiment_id: Robot embodiment preset ID.
            hand_joints: List of joint dicts with keys: name, px, py, pz, rx, ry, rz, rw.
            target_group: Joint group to map to (e.g. "arm").
            strategy: Retarget strategy (wrist_pose_only, wrist_pose_with_grasp).
        """
        resp = self._session.post(
            f"{self._base}/bridge/retarget",
            json={
                "calibration_id": calibration_id,
                "embodiment_id": embodiment_id,
                "strategy": strategy,
                "hand": {"ts_ns": 0, "tracked": True, "joints": hand_joints},
                "target_group": target_group,
            },
            timeout=self._timeout,
        )
        resp.raise_for_status()
        return resp.json()

    def retarget_batch(
        self,
        calibration_id: str,
        embodiment_id: str,
        hand_frames: list[dict[str, Any]],
        target_group: str = "arm",
        strategy: str = "wrist_pose_with_grasp",
    ) -> dict[str, Any]:
        """Retarget multiple hand frames in one request."""
        resp = self._session.post(
            f"{self._base}/bridge/retarget/batch",
            json={
                "calibration_id": calibration_id,
                "embodiment_id": embodiment_id,
                "strategy": strategy,
                "frames": hand_frames,
                "target_group": target_group,
            },
            timeout=self._timeout,
        )
        resp.raise_for_status()
        return resp.json()

    # -- Platform ---------------------------------------------------------------

    def query_log(self, limit: int = 50) -> list[dict[str, Any]]:
        """Fetch recent query log entries."""
        resp = self._session.get(
            f"{self._base}/query-log?limit={limit}", timeout=self._timeout
        )
        resp.raise_for_status()
        return resp.json()

    def profile(self, table_name: str) -> dict[str, Any]:
        """Get profile statistics for a registered table.

        Returns dict with episode_count, avg_frames, min_frames,
        max_frames, success_rate, unique_tasks, columns.
        """
        resp = self._session.get(
            f"{self._base}/engine/profile/{table_name}", timeout=self._timeout
        )
        resp.raise_for_status()
        return resp.json()

    def create_snapshot(
        self,
        dataset_id: str,
        description: str | None = None,
        tags: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
        source_query: str | None = None,
    ) -> dict[str, Any]:
        """Create an enriched snapshot with tags and provenance."""
        body: dict[str, Any] = {}
        if description:
            body["description"] = description
        if tags:
            body["tags"] = tags
        if metadata:
            body["metadata"] = metadata
        if source_query:
            body["source_query"] = source_query
        resp = self._session.post(
            f"{self._base}/datasets/{dataset_id}/snapshots",
            json=body,
            timeout=self._timeout,
        )
        resp.raise_for_status()
        return resp.json()

    def list_snapshots(self, dataset_id: str) -> list[dict[str, Any]]:
        """List all snapshots for a dataset."""
        resp = self._session.get(
            f"{self._base}/datasets/{dataset_id}/snapshots",
            timeout=self._timeout,
        )
        resp.raise_for_status()
        return resp.json()

    # -- Upload ---------------------------------------------------------------

    def upload_dataset(
        self,
        name: str,
        path: str,
        include_data: bool = True,
    ) -> dict[str, Any]:
        """Upload Parquet files from a local directory to the platform.

        Finds all ``.parquet`` files under *path* (recursively) and uploads
        each one via :meth:`upload_file`, then registers the dataset so it
        is queryable via SQL.

        Args:
            name: Dataset name for SQL queries.
            path: Local path to directory containing Parquet files.
            include_data: Also register trajectory data table.

        Returns:
            Dict with ``files_uploaded`` count and ``register`` result.
        """
        root = Path(path)
        if not root.is_dir():
            raise FileNotFoundError(f"Directory not found: {path}")

        parquet_files = sorted(root.rglob("*.parquet"))
        if not parquet_files:
            raise FileNotFoundError(f"No .parquet files found under: {path}")

        uploaded = []
        for pf in parquet_files:
            result = self.upload_file(name, str(pf))
            uploaded.append(result)

        return {
            "files_uploaded": len(uploaded),
            "uploads": uploaded,
        }

    def upload_file(self, dataset_name: str, file_path: str) -> dict[str, Any]:
        """Upload a single file to a dataset.

        Sends a multipart POST to ``/datasets/upload``.

        Args:
            dataset_name: Target dataset name.
            file_path: Local path to the file to upload.

        Returns:
            Server response dict.
        """
        p = Path(file_path)
        if not p.is_file():
            raise FileNotFoundError(f"File not found: {file_path}")

        # Temporarily remove Content-Type so requests sets the correct
        # multipart boundary header automatically.
        ct = self._session.headers.pop("Content-Type", None)
        try:
            with open(p, "rb") as f:
                resp = self._session.post(
                    f"{self._base}/datasets/upload",
                    data={"name": dataset_name},
                    files={"file": (p.name, f, "application/octet-stream")},
                    timeout=self._timeout,
                )
            resp.raise_for_status()
            return resp.json()
        finally:
            # Restore Content-Type for subsequent JSON requests.
            if ct is not None:
                self._session.headers["Content-Type"] = ct

    # -- Curation ---------------------------------------------------------------

    def curate_score(
        self,
        tables: list[str],
        max_episodes: int | None = None,
        keep_threshold: float = 0.6,
        drop_threshold: float = 0.3,
    ) -> dict[str, Any]:
        """Score episodes for quality across registered tables.

        Returns dict with total_scored, keep_count, review_count,
        drop_count, and scores list.
        """
        body: dict[str, Any] = {"tables": tables}
        if max_episodes is not None:
            body["max_episodes"] = max_episodes
        body["keep_threshold"] = keep_threshold
        body["drop_threshold"] = drop_threshold
        resp = self._session.post(
            f"{self._base}/curate/score", json=body, timeout=self._timeout
        )
        resp.raise_for_status()
        return resp.json()

    def coverage_analyze(
        self,
        tables: list[str],
    ) -> dict[str, Any]:
        """Analyze coverage gaps across registered tables.

        Returns dict with total_episodes, task_distribution,
        embodiment_distribution, recommendations.
        """
        resp = self._session.post(
            f"{self._base}/coverage/analyze",
            json={"tables": tables},
            timeout=self._timeout,
        )
        resp.raise_for_status()
        return resp.json()

    def eval_compare(
        self,
        training_table: str,
        rollout_table: str,
    ) -> dict[str, Any]:
        """Compare training vs rollout data distributions.

        Returns dict with training_episodes, rollout_episodes,
        success_rate, length_comparison, recommendations.
        """
        resp = self._session.post(
            f"{self._base}/eval/compare",
            json={
                "training_table": training_table,
                "rollout_table": rollout_table,
            },
            timeout=self._timeout,
        )
        resp.raise_for_status()
        return resp.json()

    def split_build(
        self,
        table: str,
        holdout_by: str = "task",
        test_fraction: float = 0.2,
        seed: int = 42,
    ) -> dict[str, Any]:
        """Build a generalization-aware train/eval split on a registered table.

        Returns dict with train/test episode IDs, held_out_values,
        and leakage analysis.
        """
        resp = self._session.post(
            f"{self._base}/split/build",
            json={
                "table": table,
                "holdout_by": holdout_by,
                "test_fraction": test_fraction,
                "seed": seed,
            },
            timeout=self._timeout,
        )
        resp.raise_for_status()
        return resp.json()

    def mix_compile(
        self,
        sources: list[dict[str, Any]],
        total_episodes: int | None = None,
        seed: int = 42,
    ) -> dict[str, Any]:
        """Compile a dataset mix from multiple registered tables.

        Args:
            sources: List of dicts with keys: table, weight, tier, tag.
            total_episodes: Target count (None = use all).
            seed: Random seed.

        Returns:
            Dict with total_episodes, source_counts, task_counts, episode_ids.
        """
        body: dict[str, Any] = {"sources": sources, "seed": seed}
        if total_episodes is not None:
            body["total_episodes"] = total_episodes
        resp = self._session.post(
            f"{self._base}/mix/compile",
            json=body,
            timeout=self._timeout,
        )
        resp.raise_for_status()
        return resp.json()

    # -- Validation -------------------------------------------------------------

    def validate_action(
        self,
        embodiment_id: str,
        action: list[float],
    ) -> dict[str, Any]:
        """Validate an action vector against embodiment joint limits.

        Returns:
            Dict with ``valid`` (bool) and ``violations`` (list).
        """
        resp = self._session.post(
            f"{self._base}/bridge/validate",
            json={"embodiment_id": embodiment_id, "action": action},
            timeout=self._timeout,
        )
        resp.raise_for_status()
        return resp.json()
