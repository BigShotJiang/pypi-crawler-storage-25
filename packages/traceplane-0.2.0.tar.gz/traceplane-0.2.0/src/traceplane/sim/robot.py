"""Robot handle — loads USD asset and wraps Isaac Sim articulation."""

from __future__ import annotations

from typing import Any

import numpy as np

from traceplane.sim._compat import ensure_isaacsim
from traceplane.sim.config import SimConfig

# Built-in Franka USD path within Isaac Sim assets
_FRANKA_USD = "/Isaac/Robots/Franka/franka_alt_fingers.usd"


def _quat_xyzw_to_wxyz(q: np.ndarray) -> np.ndarray:
    """Convert quaternion from Traceplane (x,y,z,w) to Isaac Sim (w,x,y,z)."""
    return np.array([q[3], q[0], q[1], q[2]])


def _quat_wxyz_to_xyzw(q: np.ndarray) -> np.ndarray:
    """Convert quaternion from Isaac Sim (w,x,y,z) to Traceplane (x,y,z,w)."""
    return np.array([q[1], q[2], q[3], q[0]])


class RobotHandle:
    """Wraps an Isaac Sim robot articulation.

    Handles USD loading, joint position control, gripper control,
    and observation extraction.

    Args:
        world: Isaac Sim World instance.
        config: Simulation configuration.
    """

    def __init__(self, world: Any, config: SimConfig):
        ensure_isaacsim()
        from omni.isaac.core.utils.nucleus import get_assets_root_path
        from omni.isaac.core.robots import Robot

        self._world = world
        self._config = config

        # Resolve USD path
        if config.usd_path:
            usd_path = config.usd_path
        else:
            assets_root = get_assets_root_path()
            if config.embodiment_id == "franka_panda":
                usd_path = assets_root + _FRANKA_USD
            else:
                raise ValueError(
                    f"No built-in USD for '{config.embodiment_id}'. "
                    f"Provide --usd-path explicitly."
                )

        # Add robot to the scene
        self._robot = world.scene.add(
            Robot(
                prim_path="/World/Robot",
                usd_path=usd_path,
                name="robot",
            )
        )
        self._n_joints = 9  # Franka: 7 arm + 2 finger joints

    def initialize(self) -> None:
        """Call after world.reset() to initialize the articulation controller."""
        self._robot.initialize()
        self._controller = self._robot.get_articulation_controller()

    def get_joint_positions(self) -> np.ndarray:
        """Get current joint positions. Shape (n_dof,)."""
        return self._robot.get_joint_positions()

    def get_joint_velocities(self) -> np.ndarray:
        """Get current joint velocities. Shape (n_dof,)."""
        return self._robot.get_joint_velocities()

    def get_ee_pose(self) -> tuple[np.ndarray, np.ndarray]:
        """Get end-effector pose as (position[3], quaternion_xyzw[4])."""
        from omni.isaac.core.utils.transformations import get_world_transform_xform
        import omni.usd

        stage = omni.usd.get_context().get_stage()
        # Franka EE link
        ee_prim = stage.GetPrimAtPath("/World/Robot/panda_hand")
        if ee_prim.IsValid():
            pos, quat_wxyz = get_world_transform_xform(ee_prim)
            return np.array(pos), _quat_wxyz_to_xyzw(np.array(quat_wxyz))

        # Fallback: use last link position
        pos = self._robot.get_world_pose()
        return np.array(pos[0]), _quat_wxyz_to_xyzw(np.array(pos[1]))

    def set_joint_positions(self, positions: np.ndarray) -> None:
        """Set target joint positions for the arm (indices 0-6)."""
        self._controller.apply_action(
            joint_positions=positions,
        )

    def set_gripper(self, width: float) -> None:
        """Set gripper finger width. Franka has two symmetric fingers."""
        half = width / 2.0
        positions = self.get_joint_positions()
        # Franka finger joints are typically indices 7 and 8
        if len(positions) >= 9:
            positions[7] = half
            positions[8] = half
            self._controller.apply_action(joint_positions=positions)

    def get_obs_state(self) -> np.ndarray:
        """Get observation state vector matching Traceplane embodiment convention.

        For Franka: [joint1..joint7, finger_width] = 8-dim.
        """
        positions = self.get_joint_positions()
        if self._config.embodiment_id == "franka_panda":
            arm = positions[:7]
            gripper = np.array([positions[7] + positions[8]])  # total finger width
            return np.concatenate([arm, gripper]).astype(np.float32)
        return positions.astype(np.float32)
