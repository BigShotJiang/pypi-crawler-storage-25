"""Configuration dataclasses for Isaac Sim integration."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class SimConfig:
    """Base configuration shared by all sim modules."""

    api_url: str = "http://localhost:8000"
    embodiment_id: str = "franka_panda"
    headless: bool = False
    physics_dt: float = 1.0 / 240.0
    rendering_dt: float = 1.0 / 60.0
    usd_path: str | None = None


@dataclass
class VisualizerConfig(SimConfig):
    """Configuration for Phase 1: retarget visualization.

    Provide one of ``dataset_path``, ``episode_path``, or set ``live=True``.
    """

    # Data source (pick one)
    dataset_path: str | None = None
    episode_index: int = 0
    episode_path: str | None = None
    live: bool = False

    # Retarget settings (for episode_path / live modes)
    calibration_id: str | None = None

    # Sim settings
    ik_solver: str = "differential"
    playback_speed: float = 1.0

    # Recording
    record_video: bool = False
    video_path: str = "./sim_replay.mp4"


@dataclass
class EvalConfig(SimConfig):
    """Configuration for Phase 2: closed-loop policy evaluation."""

    checkpoint_path: str = ""
    task: str = "pick_place_cube"
    num_episodes: int = 50
    max_steps: int = 300
    action_horizon: int = 16
    obs_horizon: int = 2
    seed: int = 42
    output_dir: str = "./eval_output"
    use_ema: bool = True
