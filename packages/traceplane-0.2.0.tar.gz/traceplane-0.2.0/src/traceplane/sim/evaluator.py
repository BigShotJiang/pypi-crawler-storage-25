"""Phase 2: Closed-loop policy evaluation in Isaac Sim."""

from __future__ import annotations

import json
import os
import sys
from collections import deque
from typing import Any

import numpy as np

from traceplane.sim._compat import ensure_isaacsim
from traceplane.sim.config import EvalConfig
from traceplane.sim.metrics import EpisodeResult, EvalReport, compile_report


class SimEvaluator:
    """Run a trained diffusion policy in Isaac Sim and collect metrics.

    Loads a checkpoint, sets up a manipulation task, runs closed-loop
    episodes, and produces an evaluation report.
    """

    def __init__(self, config: EvalConfig):
        ensure_isaacsim()
        self._config = config
        self._app = None
        self._world = None
        self._robot = None
        self._scene = None
        self._policy = None
        self._normalizer = None

    def setup(self) -> None:
        """Launch sim, load robot, load policy, set up task scene."""
        from isaacsim import SimulationApp
        from omni.isaac.core import World

        from traceplane.sim.robot import RobotHandle
        from traceplane.sim.scene import PickPlaceCubeScene

        self._app = SimulationApp({
            "headless": self._config.headless,
            "width": 1280,
            "height": 720,
        })

        self._world = World(
            physics_dt=self._config.physics_dt,
            rendering_dt=self._config.rendering_dt,
            stage_units_in_meters=1.0,
        )
        self._world.scene.add_default_ground_plane()

        # Robot
        self._robot = RobotHandle(self._world, self._config)

        # Task scene
        if self._config.task == "pick_place_cube":
            self._scene = PickPlaceCubeScene(self._world)
        else:
            raise ValueError(f"Unknown task: {self._config.task}")

        # Initialize
        self._world.reset()
        self._robot.initialize()

        # Load policy
        self._policy, self._normalizer = self._load_policy()

        print(f"Evaluator ready — {self._config.task}, "
              f"{self._config.num_episodes} episodes", file=sys.stderr)

    def _load_policy(self) -> tuple[Any, Any]:
        """Load diffusion policy from checkpoint."""
        import torch
        from traceplane.training.diffusion_policy import DiffusionPolicy
        from traceplane.training.normalization import Normalizer

        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

        ckpt = torch.load(
            self._config.checkpoint_path,
            map_location=device,
            weights_only=False,
        )

        # Reconstruct policy from saved config
        cfg = ckpt["config"]
        policy = DiffusionPolicy(
            action_dim=cfg["action_dim"] or 8,
            state_dim=cfg["state_dim"] or 8,
            obs_horizon=cfg.get("obs_horizon", self._config.obs_horizon),
            action_horizon=cfg.get("action_horizon", self._config.action_horizon),
            model_dim=cfg.get("model_dim", 256),
            model_depth=cfg.get("model_depth", 4),
            diffusion_steps=cfg.get("diffusion_steps", 100),
        ).to(device)

        # Load weights (EMA if available and requested)
        if self._config.use_ema and "ema_state_dict" in ckpt:
            for name, param in policy.named_parameters():
                if name in ckpt["ema_state_dict"]:
                    param.data.copy_(ckpt["ema_state_dict"][name])
        else:
            policy.load_state_dict(ckpt["model_state_dict"])

        policy.eval()

        # Load normalizer
        normalizer = None
        if "normalizer" in ckpt:
            normalizer = Normalizer.from_state_dict(ckpt["normalizer"])
            normalizer.to(device)

        n_params = sum(p.numel() for p in policy.parameters())
        print(f"Policy loaded: {n_params:,} params on {device}", file=sys.stderr)

        self._device = device
        return policy, normalizer

    def run_episode(self, seed: int) -> EpisodeResult:
        """Run a single evaluation episode."""
        import torch

        self._scene.reset(seed)
        # Step a few times to let physics settle
        for _ in range(10):
            self._world.step(render=False)

        obs_buffer: deque[np.ndarray] = deque(maxlen=self._config.obs_horizon)
        action_queue: deque[np.ndarray] = deque()

        # Fill initial observation buffer
        for _ in range(self._config.obs_horizon):
            obs = self._robot.get_obs_state()
            obs_buffer.append(obs)

        # Tracking
        all_joint_pos = []
        all_ee_pos = []
        all_actions = []
        step = 0

        while step < self._config.max_steps:
            if self._scene.check_success():
                break

            # Get new action chunk if queue empty
            if len(action_queue) == 0:
                obs_array = np.stack(list(obs_buffer))  # (obs_horizon, state_dim)
                obs_tensor = torch.from_numpy(obs_array).float().to(self._device)

                if self._normalizer is not None:
                    obs_tensor = self._normalizer.normalize_state(obs_tensor)

                obs_cond = obs_tensor.flatten().unsqueeze(0)  # (1, obs_horizon * state_dim)
                action_chunk = self._policy.predict_action(obs_cond)  # (1, action_horizon, action_dim)

                if self._normalizer is not None:
                    action_chunk = self._normalizer.denormalize_action(action_chunk)

                actions_np = action_chunk[0].cpu().numpy()  # (action_horizon, action_dim)
                for a in actions_np:
                    action_queue.append(a)

            action = action_queue.popleft()
            all_actions.append(action)

            # Execute
            arm_joints = action[:7] if len(action) >= 7 else action
            self._robot.set_joint_positions(arm_joints)
            if len(action) >= 8:
                self._robot.set_gripper(float(action[7]))

            self._world.step(render=not self._config.headless)

            # Record
            all_joint_pos.append(self._robot.get_joint_positions()[:8].copy())
            ee_pos, _ = self._robot.get_ee_pose()
            all_ee_pos.append(ee_pos)

            # Update obs buffer
            obs = self._robot.get_obs_state()
            obs_buffer.append(obs)
            step += 1

        success = self._scene.check_success()

        return EpisodeResult(
            success=success,
            steps=step,
            seed=seed,
            joint_positions=np.array(all_joint_pos) if all_joint_pos else np.zeros((0, 8)),
            ee_positions=np.array(all_ee_pos) if all_ee_pos else np.zeros((0, 3)),
            actions=np.array(all_actions) if all_actions else np.zeros((0, 8)),
        )

    def evaluate(self) -> EvalReport:
        """Run all evaluation episodes and compile report."""
        results = []
        for i in range(self._config.num_episodes):
            seed = self._config.seed + i
            result = self.run_episode(seed)
            status = "OK" if result.success else "FAIL"
            print(f"  Episode {i+1}/{self._config.num_episodes} "
                  f"[{status}] {result.steps} steps", file=sys.stderr)
            results.append(result)

        report = compile_report(results)

        # Write report
        os.makedirs(self._config.output_dir, exist_ok=True)
        report_path = os.path.join(self._config.output_dir, "eval_report.json")
        with open(report_path, "w") as f:
            json.dump(report.to_dict(), f, indent=2)

        print(f"\nEvaluation complete:", file=sys.stderr)
        print(f"  Success rate: {report.success_rate:.1%}", file=sys.stderr)
        print(f"  Mean steps: {report.mean_steps:.1f}", file=sys.stderr)
        print(f"  Mean smoothness: {report.mean_smoothness:.4f}", file=sys.stderr)
        print(f"  Joint violations: {report.total_joint_violations}", file=sys.stderr)
        print(f"  Report: {report_path}", file=sys.stderr)

        return report

    def teardown(self) -> None:
        if self._app:
            self._app.close()
