"""Tests for LSC Optimizer GUI."""

from __future__ import annotations

import pytest
import pytestqt.qtbot

from pytola_sim.lscopt.gui import (
    LSCOptimizerGUI,
    ParameterWidget,
    PlotWidget,
    ResultDisplayWidget,
)


class TestParameterWidget:
    """Tests for ParameterWidget."""

    def test_parameter_widget_creation(self, qtbot: pytestqt.qtbot.QtBot):
        """Test creating parameter widget."""
        widget = ParameterWidget("test_param", "Test Parameter", 1.0, 0.0, 10.0, 0.1)
        qtbot.addWidget(widget)

        assert widget.name == "test_param"
        assert widget.label == "Test Parameter"
        assert widget.get_value() == pytest.approx(1.0)

    def test_parameter_widget_set_value(self, qtbot: pytestqt.qtbot.QtBot):
        """Test setting parameter value."""
        widget = ParameterWidget("test_param", "Test Parameter", 1.0, 0.0, 10.0, 0.1)
        qtbot.addWidget(widget)

        widget.set_value(5.5)
        assert widget.get_value() == pytest.approx(5.5)


class TestResultDisplayWidget:
    """Tests for ResultDisplayWidget."""

    def test_result_display_creation(self, qtbot: pytestqt.qtbot.QtBot):
        """Test creating result display widget."""
        widget = ResultDisplayWidget()
        qtbot.addWidget(widget)

        # Check for either English or Chinese ready text
        ready_text = widget.result_text.text()
        assert "Ready to calculate" in ready_text or "准备计算" in ready_text

    def test_update_results(self, qtbot: pytestqt.qtbot.QtBot):
        """Test updating results display."""
        widget = ResultDisplayWidget()
        qtbot.addWidget(widget)

        widget.update_results(2.5, 0.001)
        result_text = widget.result_text.text()
        # Check for either English or Chinese calculation success text
        assert "Calculation completed" in result_text or "计算完成" in result_text
        assert "2.5000" in result_text
        assert "0.001000" in result_text

    def test_show_error(self, qtbot: pytestqt.qtbot.QtBot):
        """Test showing error message."""
        widget = ResultDisplayWidget()
        qtbot.addWidget(widget)

        widget.show_error("Test error message")
        # Check for either English or Chinese error text
        error_text = widget.result_text.text()
        assert "Error: Test error message" in error_text or "错误: Test error message" in error_text


class TestPlotWidget:
    """Tests for PlotWidget."""

    def test_plot_widget_creation(self, qtbot: pytestqt.qtbot.QtBot):
        """Test creating plot widget."""
        widget = PlotWidget()
        qtbot.addWidget(widget)

        assert widget.ax is not None
        assert widget.canvas is not None

    def test_clear_plot(self, qtbot: pytestqt.qtbot.QtBot):
        """Test clearing plot."""
        widget = PlotWidget()
        qtbot.addWidget(widget)

        # Add some data to plot
        widget.ax.plot([1, 2, 3], [1, 4, 2])
        widget.canvas.draw()

        # Clear plot
        widget.clear_plot()
        assert len(widget.ax.lines) == 0


class TestLSCOptimizerGUI:
    """Tests for LSCOptimizerGUI main window."""

    def setup_method(self):
        """Set up method to ensure English language for consistent testing."""
        # Import translation system
        try:
            from pytola_sim.lscopt.translation import Language, translator
        except ImportError:
            try:
                from pytola_sim.lscopt.translation import Language, translator
            except ImportError:
                from pytola_sim.lscopt.translation import Language, translator

        # Set language to English for consistent test expectations
        translator.set_language(Language.ENGLISH)

    def test_window_creation(self, qtbot: pytestqt.qtbot.QtBot):
        """Test that main window can be created."""
        window = LSCOptimizerGUI()
        qtbot.addWidget(window)

        assert window.windowTitle() == "LSC Optimizer v0.1.0"
        assert window.minimumSize().width() == 1200  # Updated to match new minimum width
        assert window.minimumSize().height() == 700

    def test_parameter_widgets_exist(self, qtbot: pytestqt.qtbot.QtBot):
        """Test that parameter widgets are created."""
        window = LSCOptimizerGUI()
        qtbot.addWidget(window)

        # Check that we have parameter widgets
        assert hasattr(window, "param_widgets")
        assert len(window.param_widgets) > 0

        # Check for specific parameters
        assert "m" in window.param_widgets
        assert "H" in window.param_widgets
        assert "J" in window.param_widgets

    def test_calculate_button_exists(self, qtbot: pytestqt.qtbot.QtBot):
        """Test that calculate button exists."""
        window = LSCOptimizerGUI()
        qtbot.addWidget(window)

        assert hasattr(window, "calculate_button")
        assert window.calculate_button.text() == "Calculate"

    def test_reset_button_exists(self, qtbot: pytestqt.qtbot.QtBot):
        """Test that reset button exists."""
        window = LSCOptimizerGUI()
        qtbot.addWidget(window)

        assert hasattr(window, "reset_button")
        assert window.reset_button.text() == "Reset to Defaults"

    def test_plot_widget_exists(self, qtbot: pytestqt.qtbot.QtBot):
        """Test that plot widget exists."""
        window = LSCOptimizerGUI()
        qtbot.addWidget(window)

        assert hasattr(window, "plot_widget")
        assert hasattr(window.plot_widget, "ax")
