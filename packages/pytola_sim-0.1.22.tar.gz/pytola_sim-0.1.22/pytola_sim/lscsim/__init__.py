"""LSCSIM - Python-based Simulation System."""

__version__ = "0.1.22"
__author__ = "LSCSIM Team"
