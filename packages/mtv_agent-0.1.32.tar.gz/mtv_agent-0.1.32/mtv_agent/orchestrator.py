"""Orchestrate MCP containers, claude-openai-proxy, and the API server."""

from __future__ import annotations

import atexit
import logging
import os
import shutil
import signal
import socket
import subprocess
import sys
import threading
import time
import webbrowser
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import urlparse

import uvicorn

import mtv_agent.config as config
from mtv_agent.config import (
    _bundled_data_path,
    bundled_config_example,
    bundled_mcp_example,
)
from mtv_agent.lib.kube import (
    KubeApiUnreachableError,
    resolve_kube_credentials,
    set_kube_credentials,
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Overridable defaults (MTV_AGENT_* environment variables)
# ---------------------------------------------------------------------------


def _validate_port(env_name: str, default: int) -> int:
    """Read an env var as a TCP port number (1–65535) with a friendly error."""
    raw = os.environ.get(env_name)
    if raw is None:
        return default
    try:
        port = int(raw)
    except ValueError:
        raise SystemExit(f"Error: {env_name}={raw!r} is not a valid integer") from None
    if not 1 <= port <= 65535:
        raise SystemExit(f"Error: {env_name}={port} is outside the valid range 1–65535")
    return port


_COP_PORT = _validate_port("MTV_AGENT_COP_PORT", 1234)
_CONTAINER_PORT = _validate_port("MTV_AGENT_CONTAINER_PORT", 8080)
_KUBE_INSECURE = os.environ.get("MTV_AGENT_KUBE_INSECURE", "true")

_CONTAINER_PREFIX = "mtv-agent-mcp"


def _container_name(key: str) -> str:
    """Derive a container name from an ``mcpServers`` config key."""
    return f"{_CONTAINER_PREFIX}-{key}"


@dataclass
class _RunState:
    """Tracks processes and containers started by the orchestrator."""

    runtime: str = ""
    container_names: list[str] = None  # type: ignore[assignment]
    cop_proc: subprocess.Popen | None = None

    def __post_init__(self) -> None:
        if self.container_names is None:
            self.container_names = []


_state = _RunState()


# ---------------------------------------------------------------------------
# Container runtime detection
# ---------------------------------------------------------------------------


def detect_runtime(preferred: str | None = None) -> str:
    """Return ``docker`` or ``podman``, preferring *preferred* if given."""
    if preferred:
        if shutil.which(preferred):
            return preferred
        raise RuntimeError(f"Requested runtime '{preferred}' not found in PATH")
    for candidate in ("docker", "podman"):
        if shutil.which(candidate):
            return candidate
    raise RuntimeError("Neither docker nor podman found in PATH")


# ---------------------------------------------------------------------------
# Readiness probe
# ---------------------------------------------------------------------------


def _wait_for_port(
    host: str,
    port: int,
    label: str,
    timeout: int = 60,
    interval: float = 1.0,
) -> bool:
    """Block until *host*:*port* accepts a TCP connection, or *timeout* expires."""
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            with socket.create_connection((host, port), timeout=2):
                logger.info("  %s is ready", label)
                return True
        except (ConnectionRefusedError, OSError):
            pass
        time.sleep(interval)
    logger.warning("  %s did not become ready within %ds", label, timeout)
    return False


def _client_host_for_listen(listen_host: str) -> str:
    """Host for TCP probes and browser URLs when the server binds broadly."""
    h = listen_host.strip().lower()
    if h in ("0.0.0.0", "::", "[::]"):
        return "127.0.0.1"
    return listen_host


def _browser_base_url(listen_host: str, port: int) -> str:
    """HTTP URL for the web UI on the same machine as the agent process."""
    ch = _client_host_for_listen(listen_host)
    return f"http://{ch}:{port}/"


def _find_chrome_executable() -> str | None:
    """Return the path to a Chromium-based browser, or *None*."""
    candidates = [
        "google-chrome",
        "google-chrome-stable",
        "chromium",
        "chromium-browser",
        "microsoft-edge",
    ]
    if sys.platform == "darwin":
        candidates = [
            "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
            "/Applications/Chromium.app/Contents/MacOS/Chromium",
            "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
        ] + candidates
    for name in candidates:
        path = shutil.which(name)
        if path:
            return path
        # Only treat *name* as a filesystem path if it is absolute or has a
        # directory component — avoids executing a same-named file in CWD when
        # *name* is a bare executable name (e.g. "google-chrome").
        if os.path.isabs(name) or os.path.dirname(name):
            if os.path.isfile(name) and os.access(name, os.X_OK):
                return name
    return None


def _schedule_open_browser(
    *, listen_host: str, port: int, app_mode: bool = False
) -> None:
    """After the API port accepts connections, open the web UI in a browser.

    When *app_mode* is ``True``, launch a Chromium-based browser with
    ``--app=<url>`` for a chromeless window.  Falls back to the normal
    ``webbrowser.open`` if no supported browser is found.
    """

    def _run() -> None:
        probe_host = _client_host_for_listen(listen_host)
        if not _wait_for_port(probe_host, port, "API server", timeout=120):
            return
        url = _browser_base_url(listen_host, port)
        try:
            if app_mode:
                chrome = _find_chrome_executable()
                if chrome:
                    subprocess.Popen(
                        [chrome, f"--app={url}"],
                        stdout=subprocess.DEVNULL,
                        stderr=subprocess.DEVNULL,
                    )
                    logger.info("Opened browser in app mode: %s", url)
                else:
                    logger.warning(
                        "No Chromium-based browser found for app mode; "
                        "falling back to default browser"
                    )
                    webbrowser.open(url)
                    logger.info("Opened browser: %s", url)
            else:
                webbrowser.open(url)
                logger.info("Opened browser: %s", url)
        except Exception as exc:
            logger.warning("Could not open browser (%s): %s", url, exc)

    threading.Thread(target=_run, daemon=True).start()


def _schedule_ready_message(*, listen_host: str, port: int, url: str) -> None:
    """Wait for the server to be ready, then print a user-friendly hint."""

    def _run() -> None:
        probe_host = _client_host_for_listen(listen_host)
        if not _wait_for_port(probe_host, port, "API server", timeout=120):
            return
        print(
            f"\n"
            f"  ✔  mtv-agent is ready\n"
            f"     {url}\n"
            f"\n"
            f"     Tip: use --open to launch the browser automatically\n",
            flush=True,
        )

    threading.Thread(target=_run, daemon=True).start()


# ---------------------------------------------------------------------------
# Container lifecycle
# ---------------------------------------------------------------------------


def _run_container(
    runtime: str,
    name: str,
    image: str,
    host_port: int,
    *,
    skip_tls: bool = False,
) -> None:
    """Start a single MCP container in detached mode.

    Credentials are **not** baked into the container; the API server
    sends them as HTTP headers on each MCP connection instead.
    """
    if skip_tls and runtime != "podman":
        raise RuntimeError(
            "--skip-tls is only supported with podman. "
            "For Docker, configure insecure registries in daemon.json instead."
        )
    subprocess.run(
        [runtime, "rm", "-f", name],
        capture_output=True,
    )
    cmd = [
        runtime,
        "run",
        *(["--tls-verify=false"] if skip_tls else []),
        "--pull=always",
        "--rm",
        "-d",
        "--name",
        name,
        "-p",
        f"{host_port}:{_CONTAINER_PORT}",
        "-e",
        f"MCP_KUBE_INSECURE={_KUBE_INSECURE}",
        image,
    ]
    subprocess.run(cmd, capture_output=True, check=True)
    logger.info("  %s -> http://localhost:%d/mcp", name, host_port)


def start_mcp_containers(
    runtime: str,
    mcp_raw: dict | None = None,
    *,
    skip_tls: bool = False,
) -> list[str]:
    """Start MCP server containers, waiting for each to become ready.

    Iterates over ``mcpServers`` in *mcp_raw* (the parsed ``mcp.json``).
    Entries with an ``image`` key get a local container; entries without
    are assumed to be running remotely and are skipped.

    The host port is parsed from the entry's ``url`` field.
    """
    if not mcp_raw:
        return []
    mcp_section = mcp_raw.get("mcpServers", {})
    if not isinstance(mcp_section, dict):
        return []

    logger.info("Starting MCP servers (%s)...", runtime)
    names: list[str] = []
    try:
        for key, entry in mcp_section.items():
            if not isinstance(entry, dict):
                continue
            if not entry.get("enabled", True):
                logger.info("  %s -- disabled, skipping", key)
                continue
            image = entry.get("image")
            if not image:
                logger.info("  %s -- no image configured, skipping (remote)", key)
                continue
            url = entry.get("url", "")
            host_port = urlparse(url).port or _CONTAINER_PORT
            name = _container_name(key)
            _run_container(runtime, name, image, host_port, skip_tls=skip_tls)
            names.append(name)
            if not _wait_for_port("localhost", host_port, name):
                raise RuntimeError(
                    f"MCP server {name!r} failed to become ready on port {host_port}"
                )
    except Exception:
        if names:
            stop_containers(runtime, names)
        raise
    return names


def stop_containers(runtime: str, names: list[str]) -> None:
    """Stop and remove the given containers."""
    for name in names:
        subprocess.run(
            [runtime, "stop", "--time=2", name],
            capture_output=True,
        )


def stop_mcp_containers_any_runtime() -> None:
    """Best-effort stop of MCP containers using any available runtime."""
    mcp_section = config.mcp_raw_config.get("mcpServers", {})
    names = [_container_name(key) for key in mcp_section]
    for candidate in ("docker", "podman"):
        if not shutil.which(candidate):
            continue
        for name in names:
            subprocess.run(
                [candidate, "stop", name],
                capture_output=True,
            )


# ---------------------------------------------------------------------------
# Claude OpenAI Proxy
# ---------------------------------------------------------------------------


def start_cop() -> subprocess.Popen:
    """Start claude-openai-proxy as a background subprocess."""
    logger.info("Starting claude-openai-proxy on port %d...", _COP_PORT)
    env = {**os.environ, "PORT": str(_COP_PORT)}
    proc = subprocess.Popen(
        [sys.executable, "-m", "claude_openai_proxy"],
        env=env,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    logger.info("  claude-openai-proxy -> http://localhost:%d", _COP_PORT)
    return proc


def stop_cop(proc: subprocess.Popen | None) -> None:
    """Terminate the COP subprocess if running."""
    if proc is None:
        return
    proc.terminate()
    try:
        proc.wait(timeout=5)
    except subprocess.TimeoutExpired:
        proc.kill()


def stop_cop_by_name() -> None:
    """Best-effort kill of any running claude-openai-proxy process."""
    subprocess.run(
        ["pkill", "-f", "claude_openai_proxy"],
        capture_output=True,
    )


# ---------------------------------------------------------------------------
# Config helpers
# ---------------------------------------------------------------------------


def get_default_config_text() -> str:
    """Return the default agent config JSON as a formatted string."""
    return bundled_config_example().read_text(encoding="utf-8")


def _safe_reload_config(
    config_path_arg: str | None = None,
    mcp_config_path_arg: str | None = None,
) -> None:
    """Reload config, converting missing-file errors into clean CLI exits."""
    try:
        config.reload(
            config_path_arg=config_path_arg,
            mcp_config_path_arg=mcp_config_path_arg,
        )
    except (FileNotFoundError, OSError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)


def _require_config_files() -> None:
    """Exit with an error if either config file is missing."""
    if not config.config_path:
        print(
            "Error: config.json not found.\n  Run 'mtv-agent init' to create one.",
            file=sys.stderr,
        )
        sys.exit(1)
    if not config.mcp_config_path:
        print(
            "Error: mcp.json not found.\n  Run 'mtv-agent init' to create one.",
            file=sys.stderr,
        )
        sys.exit(1)


# ---------------------------------------------------------------------------
# Workspace initialisation
# ---------------------------------------------------------------------------


def init_workspace(target: Path | None = None, *, force: bool = False) -> Path:
    """Copy bundled config, skills, and playbooks into a local workspace.

    Returns the directory that was initialised.  Files that already exist
    are skipped unless *force* is ``True``.
    """
    dest = (target or config.USER_DIR).expanduser().resolve()
    dest.mkdir(parents=True, exist_ok=True)

    created: list[str] = []
    skipped: list[str] = []

    # Agent config is user-editable -- only overwrite with --force.
    config_src = bundled_config_example()
    config_dst = dest / "config.json"
    if config_dst.exists() and not force:
        skipped.append("config.json")
    else:
        shutil.copy2(config_src, config_dst)
        created.append("config.json")

    # MCP config is user-editable -- only overwrite with --force.
    mcp_src = bundled_mcp_example()
    mcp_dst = dest / "mcp.json"
    if mcp_dst.exists() and not force:
        skipped.append("mcp.json")
    else:
        shutil.copy2(mcp_src, mcp_dst)
        created.append("mcp.json")

    # Skills and playbooks are bundled defaults -- always refresh so
    # users get updates on new versions without needing --force.
    skills_src = _bundled_data_path("skills")
    skills_dst = dest / "skills"
    if skills_dst.exists():
        shutil.rmtree(skills_dst)
    shutil.copytree(skills_src, skills_dst)
    created.append("skills/")

    playbooks_src = _bundled_data_path("playbooks")
    playbooks_dst = dest / "playbooks"
    if playbooks_dst.exists():
        shutil.rmtree(playbooks_dst)
    shutil.copytree(playbooks_src, playbooks_dst)
    created.append("playbooks/")

    logger.info("Initialised workspace: %s", dest)
    if created:
        logger.info("  created/updated: %s", ", ".join(created))
    if skipped:
        logger.info("  skipped (already exist): %s", ", ".join(skipped))

    return dest


# ---------------------------------------------------------------------------
# Cleanup
# ---------------------------------------------------------------------------


def _cleanup() -> None:
    """Shut down all managed processes and containers."""
    logger.info("Shutting down...")
    stop_cop(_state.cop_proc)
    _state.cop_proc = None
    if _state.runtime and _state.container_names:
        stop_containers(_state.runtime, _state.container_names)
        _state.container_names.clear()
    logger.info("Done.")


def _signal_handler(signum: int, frame) -> None:
    _cleanup()
    sys.exit(0)


# ---------------------------------------------------------------------------
# Full-stack launch
# ---------------------------------------------------------------------------


def _ensure_cleanup_registered() -> None:
    """Register process cleanup handlers (idempotent)."""
    if getattr(_ensure_cleanup_registered, "_done", False):
        return
    signal.signal(signal.SIGINT, _signal_handler)
    signal.signal(signal.SIGTERM, _signal_handler)
    atexit.register(_cleanup)
    _ensure_cleanup_registered._done = True  # type: ignore[attr-defined]


def _maybe_start_cop() -> None:
    """Start the COP proxy if llm.type is ``claude-vertex``.

    Overrides ``llm_base_url`` and ``llm_api_key`` so the rest of the
    stack talks to the proxy instead of the values in the config file.
    """
    if config.settings.llm_type != "claude-vertex":
        return

    _ensure_cleanup_registered()
    _state.cop_proc = start_cop()
    if not _wait_for_port("localhost", _COP_PORT, "claude-openai-proxy"):
        stop_cop(_state.cop_proc)
        _state.cop_proc = None
        print(
            f"\n"
            f"  ✘  Cannot start claude-openai-proxy\n"
            f"     http://localhost:{_COP_PORT}\n"
            f"\n"
            f"     The proxy translates OpenAI-compatible requests to\n"
            f"     Claude on Google Cloud (Vertex AI).\n"
            f"\n"
            f"     To fix this:\n"
            f"     • Run: gcloud auth application-default login\n"
            f"     • Export CLOUD_ML_REGION and ANTHROPIC_VERTEX_PROJECT_ID\n"
            f"     • Restart the agent\n",
            flush=True,
        )
        sys.exit(1)

    config.settings.llm_base_url = f"http://localhost:{_COP_PORT}/v1"
    config.settings.llm_api_key = "not-needed"
    logger.info(
        "claude-vertex mode: overriding LLM URL to %s",
        config.settings.llm_base_url,
    )


def start_all(
    *,
    with_cop: bool = False,
    config_path: str | None = None,
    mcp_config_path: str | None = None,
    runtime: str | None = None,
    host: str | None = None,
    port: int | None = None,
    no_web: bool = False,
    skip_tls: bool = False,
    kube_api_url: str | None = None,
    kube_token: str | None = None,
    kubeconfig: str | None = None,
    kube_context: str | None = None,
    open_browser: bool = False,
    open_app: bool = False,
) -> None:
    """Start MCP containers, optionally COP, then the API server (blocking)."""
    try:
        api_url, token = resolve_kube_credentials(
            kube_api_url, kube_token, kubeconfig, kube_context
        )
    except KubeApiUnreachableError as exc:
        print(
            f"\n"
            f"  ✘  Cannot reach Kubernetes API server\n"
            f"     {exc.api_url}\n"
            f"\n"
            f"     The cluster may be down or your network/VPN may be\n"
            f"     disconnected.\n"
            f"\n"
            f"     To fix this:\n"
            f"     • Check that the cluster is running\n"
            f"     • Verify your VPN or network connection\n"
            f"     • Confirm the correct kubeconfig context is selected\n"
            f"       (kubectl config current-context)\n",
            flush=True,
        )
        sys.exit(1)
    if not api_url:
        print(
            "\n"
            "  ✘  Kubernetes API URL not found\n"
            "\n"
            "     The agent needs a Kubernetes cluster to connect to,\n"
            "     but no API URL was provided or discovered.\n"
            "\n"
            "     To fix this:\n"
            "     • Pass --kube-api-url on the command line\n"
            "     • Set the KUBE_API_URL environment variable\n"
            "     • Configure a kubeconfig (e.g. ~/.kube/config)\n",
            flush=True,
        )
        sys.exit(1)
    if not token:
        print(
            "\n"
            "  ✘  Kubernetes token not found\n"
            "\n"
            f"     An API URL was found ({api_url}) but no bearer\n"
            "     token is available for authentication.\n"
            "\n"
            "     To fix this:\n"
            "     • Pass --kube-token on the command line\n"
            "     • Set the KUBE_TOKEN environment variable\n"
            "     • Use a kubeconfig with a valid token or exec plugin\n",
            flush=True,
        )
        sys.exit(1)

    rt = detect_runtime(runtime)
    _state.runtime = rt

    _ensure_cleanup_registered()

    _safe_reload_config(
        config_path_arg=config_path, mcp_config_path_arg=mcp_config_path
    )
    _require_config_files()

    # Legacy --with-cop flag: force claude-vertex mode for this run.
    if with_cop:
        config.settings.llm_type = "claude-vertex"

    _maybe_start_cop()

    _state.container_names = start_mcp_containers(
        rt, mcp_raw=config.mcp_raw_config, skip_tls=skip_tls
    )

    serve(
        host=host,
        port=port,
        no_web=no_web,
        kube_api_url=api_url,
        kube_token=token,
        open_browser=open_browser,
        open_app=open_app,
    )


# ---------------------------------------------------------------------------
# API-only launch
# ---------------------------------------------------------------------------


def serve(
    *,
    host: str | None = None,
    port: int | None = None,
    config_path: str | None = None,
    mcp_config_path: str | None = None,
    no_web: bool = False,
    kube_api_url: str | None = None,
    kube_token: str | None = None,
    kubeconfig: str | None = None,
    kube_context: str | None = None,
    open_browser: bool = False,
    open_app: bool = False,
) -> None:
    """Start just the FastAPI/Uvicorn server (blocking).

    When kube credentials are supplied they are stored in module-level
    state so the API server lifespan can inject them as MCP auth
    headers.
    """
    if config_path or mcp_config_path:
        _safe_reload_config(
            config_path_arg=config_path,
            mcp_config_path_arg=mcp_config_path,
        )
    _require_config_files()

    if _state.cop_proc is None or _state.cop_proc.poll() is not None:
        _state.cop_proc = None
        _maybe_start_cop()

    if no_web:
        config.no_web = True

    if kube_api_url or kube_token or kubeconfig or kube_context:
        try:
            api_url, token = resolve_kube_credentials(
                kube_api_url, kube_token, kubeconfig, kube_context
            )
        except KubeApiUnreachableError as exc:
            logger.warning(
                "Kubernetes API unreachable (%s) -- continuing without kube credentials",
                exc.api_url,
            )
            api_url, token = "", ""
        if api_url or token:
            set_kube_credentials(api_url, token)

    bind_host = host or config.settings.server_host
    bind_port = port or config.settings.server_port

    if open_browser or open_app:
        if no_web:
            logger.info("Not opening browser (--no-web)")
        else:
            _schedule_open_browser(
                listen_host=bind_host, port=bind_port, app_mode=open_app
            )
    elif not no_web:
        url = _browser_base_url(bind_host, bind_port)
        _schedule_ready_message(listen_host=bind_host, port=bind_port, url=url)

    uvicorn.run(
        "mtv_agent.main:app",
        host=bind_host,
        port=bind_port,
        timeout_graceful_shutdown=8,
    )
