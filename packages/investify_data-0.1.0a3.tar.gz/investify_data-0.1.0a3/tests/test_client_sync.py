import httpx
import pytest
import respx

from investify_data import DataClient, Forbidden, NotFound, ServerError, Unauthorized


@respx.mock
def test_catalog_list_tables_sends_auth_and_agent(api_key, base_url):
    route = respx.get(f"{base_url}/v1/catalog/tables").mock(return_value=httpx.Response(200, json={"tables": []}))
    with DataClient(api_key=api_key, base_url=base_url) as client:
        result = client.catalog.list_tables()

    assert result == {"tables": []}
    sent = route.calls[-1].request
    assert sent.headers["authorization"] == f"Bearer {api_key}"
    assert "investify-data" in sent.headers["user-agent"]


@respx.mock
def test_catalog_list_tables_category_filter(api_key, base_url):
    route = respx.get(f"{base_url}/v1/catalog/tables").mock(return_value=httpx.Response(200, json={"tables": []}))
    with DataClient(api_key=api_key, base_url=base_url) as client:
        client.catalog.list_tables(category="equities")

    assert route.calls[-1].request.url.params.get("category") == "equities"


@respx.mock
def test_describe_table_group_string_and_list(api_key, base_url):
    respx.get(f"{base_url}/v1/catalog/tables/financial_ratio").mock(return_value=httpx.Response(200, json={"table_id": "financial_ratio"}))
    with DataClient(api_key=api_key, base_url=base_url) as client:
        client.catalog.describe_table("financial_ratio", group="valuation")
        client.catalog.describe_table("financial_ratio", group=["valuation", "growth"])

    calls = respx.calls
    assert calls[-2].request.url.params.get("group") == "valuation"
    assert calls[-1].request.url.params.get("group") == "valuation,growth"


@respx.mock
def test_tables_query_serializes_filters_and_columns(api_key, base_url):
    route = respx.get(f"{base_url}/v1/tables/stock_price_history").mock(return_value=httpx.Response(200, json={"columns": [], "rows": [], "count": 0}))
    with DataClient(api_key=api_key, base_url=base_url) as client:
        client.tables.query(
            "stock_price_history",
            columns=["symbol", "date", "close"],
            filters={"symbol": "VNM", "date": {"gte": "-30d"}},
            sort="date.desc",
            limit=5,
        )

    url = route.calls[-1].request.url
    assert url.params.get("columns") == "symbol,date,close"
    assert url.params.get("symbol") == "VNM"
    assert url.params.get("date") == '{"gte":"-30d"}'
    assert url.params.get("sort") == "date.desc"
    assert url.params.get("limit") == "5"


@respx.mock
def test_collections_search_sends_q_and_metadata_filters(api_key, base_url):
    route = respx.get(f"{base_url}/v1/collections/market_news").mock(return_value=httpx.Response(200, json={"hits": []}))
    with DataClient(api_key=api_key, base_url=base_url) as client:
        client.collections.search(
            "market_news",
            q="lãi suất",
            metadata_filters={"topic": {"in": ["banking", "macro"]}},
            limit=3,
            include_matches=True,
        )

    params = route.calls[-1].request.url.params
    assert params.get("q") == "lãi suất"
    assert params.get("limit") == "3"
    assert params.get("include_matches") == "true"
    assert params.get("topic") == '{"in":["banking","macro"]}'


@respx.mock
def test_collections_get_by_id(api_key, base_url):
    route = respx.get(f"{base_url}/v1/collections/market_news/abc-123").mock(
        return_value=httpx.Response(200, json={"id": "abc-123", "text": "…", "metadata": {}})
    )
    with DataClient(api_key=api_key, base_url=base_url) as client:
        doc = client.collections.get("market_news", "abc-123")

    assert doc["id"] == "abc-123"
    assert route.calls.call_count == 1


@respx.mock
def test_error_mapping(api_key, base_url):
    respx.get(f"{base_url}/v1/tables/missing").mock(
        return_value=httpx.Response(404, json={"detail": {"code": "RESOURCE_NOT_FOUND", "message": "table not found"}})
    )
    respx.get(f"{base_url}/v1/tables/forbidden").mock(return_value=httpx.Response(403, json={"detail": {"code": "FORBIDDEN", "message": "blocked"}}))
    respx.get(f"{base_url}/v1/tables/bad_auth").mock(return_value=httpx.Response(401, json={"detail": "invalid credentials"}))
    respx.get(f"{base_url}/v1/tables/boom").mock(return_value=httpx.Response(500, text="oops"))

    with DataClient(api_key=api_key, base_url=base_url) as client:
        with pytest.raises(NotFound) as exc:
            client.tables.query("missing")
        assert exc.value.code == "RESOURCE_NOT_FOUND"
        assert exc.value.status_code == 404

        with pytest.raises(Forbidden):
            client.tables.query("forbidden")

        with pytest.raises(Unauthorized):
            client.tables.query("bad_auth")

        with pytest.raises(ServerError):
            client.tables.query("boom")


def test_rejects_bad_api_key_format(base_url):
    with pytest.raises(ValueError):
        DataClient(api_key="not-a-key", base_url=base_url)


def test_repr_does_not_leak_key(api_key, base_url):
    with DataClient(api_key=api_key, base_url=base_url) as client:
        rep = repr(client)
    assert api_key not in rep
    assert "ifyu_***" in rep


def test_warns_on_plaintext_production_url(api_key):
    with pytest.warns(UserWarning, match="plaintext"):
        DataClient(api_key=api_key, base_url="http://example.com").close()


def test_no_warning_on_localhost_plaintext(api_key, recwarn):
    DataClient(api_key=api_key, base_url="http://localhost:7002").close()
    DataClient(api_key=api_key, base_url="http://investify.k8s:30702").close()
    for w in recwarn:
        assert "plaintext" not in str(w.message)
