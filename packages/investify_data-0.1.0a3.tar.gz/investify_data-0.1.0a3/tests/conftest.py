import pytest

API_KEY = "ifyu_abcdefghijklmnopqrstuvwxyz012345"
BASE_URL = "https://data.test.invalid"


@pytest.fixture
def api_key() -> str:
    return API_KEY


@pytest.fixture
def base_url() -> str:
    return BASE_URL
