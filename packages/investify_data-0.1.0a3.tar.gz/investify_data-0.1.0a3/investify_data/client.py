"""Sync client for the Investify Data API."""

from __future__ import annotations

from typing import Any

import httpx

from investify_data._base import (
    DEFAULT_BASE_URL,
    USER_AGENT,
    build_headers,
    redact_key,
    safe_json,
    validate_api_key,
    warn_if_insecure,
)
from investify_data._resources_sync import CatalogResource, CollectionsResource, TablesResource
from investify_data.exceptions import TransportError, raise_for_response


class DataClient:
    """Synchronous client for the Investify Data API.

    Minimal usage:
        client = DataClient(api_key="ifyu_...")
        rows = client.tables.query("stock_price_history", filters={"symbol": "VNM"}, limit=5)
        client.close()

    As a context manager (preferred — closes the underlying pool):
        with DataClient(api_key="ifyu_...") as client:
            ...

    Args:
        api_key: `ifyu_*` (user key), `ifys_*` (tenant key), or `ifym_*` (master key).
        base_url: API base URL. Defaults to production. Override for dev/LAN.
        on_behalf_of: User UUID — only valid with `ifys_*` or `ifym_*` keys.
        timeout: Per-request timeout in seconds.
        user_agent: Override User-Agent header (useful for observability).
    """

    def __init__(
        self,
        *,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        on_behalf_of: str | None = None,
        timeout: float = 30.0,
        user_agent: str = USER_AGENT,
    ) -> None:
        validate_api_key(api_key)
        warn_if_insecure(base_url, api_key)

        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._on_behalf_of = on_behalf_of
        self._user_agent = user_agent

        self._http = httpx.Client(
            base_url=self._base_url,
            timeout=timeout,
            headers=build_headers(api_key, on_behalf_of, user_agent),
        )

        self.catalog = CatalogResource(self)
        self.tables = TablesResource(self)
        self.collections = CollectionsResource(self)

    def __repr__(self) -> str:
        return f"DataClient(base_url={self._base_url!r}, api_key={redact_key(self._api_key)!r})"

    def __enter__(self) -> DataClient:
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    def close(self) -> None:
        self._http.close()

    # ─── Internal ────────────────────────────────────────────────────────────

    def _get_json(self, path: str, *, params: list[tuple[str, str]] | None = None) -> Any:
        try:
            response = self._http.get(path, params=params)
        except httpx.HTTPError as exc:
            raise TransportError(f"network error calling {path}: {type(exc).__name__}") from exc

        body = safe_json(response)
        raise_for_response(response.status_code, body)
        return body
