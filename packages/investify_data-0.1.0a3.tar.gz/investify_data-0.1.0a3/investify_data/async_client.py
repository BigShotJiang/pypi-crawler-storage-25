"""Async client — mirrors DataClient via httpx.AsyncClient."""

from __future__ import annotations

from typing import Any

import httpx

from investify_data._base import (
    DEFAULT_BASE_URL,
    USER_AGENT,
    build_headers,
    redact_key,
    safe_json,
    validate_api_key,
    warn_if_insecure,
)
from investify_data._resources_async import (
    AsyncCatalogResource,
    AsyncCollectionsResource,
    AsyncTablesResource,
)
from investify_data.exceptions import TransportError, raise_for_response


class AsyncDataClient:
    """Asynchronous Investify Data API client. Same surface as DataClient, all coroutines.

    Example:
        async with AsyncDataClient(api_key="ifyu_...") as client:
            rows = await client.tables.query("stock_price_history", filters={"symbol": "VNM"})
    """

    def __init__(
        self,
        *,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        on_behalf_of: str | None = None,
        timeout: float = 30.0,
        user_agent: str = USER_AGENT,
    ) -> None:
        validate_api_key(api_key)
        warn_if_insecure(base_url, api_key)

        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._on_behalf_of = on_behalf_of
        self._user_agent = user_agent

        self._http = httpx.AsyncClient(
            base_url=self._base_url,
            timeout=timeout,
            headers=build_headers(api_key, on_behalf_of, user_agent),
        )

        self.catalog = AsyncCatalogResource(self)
        self.tables = AsyncTablesResource(self)
        self.collections = AsyncCollectionsResource(self)

    def __repr__(self) -> str:
        return f"AsyncDataClient(base_url={self._base_url!r}, api_key={redact_key(self._api_key)!r})"

    async def __aenter__(self) -> AsyncDataClient:
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        await self.close()

    async def close(self) -> None:
        await self._http.aclose()

    # ─── Internal ────────────────────────────────────────────────────────────

    async def _get_json(self, path: str, *, params: list[tuple[str, str]] | None = None) -> Any:
        try:
            response = await self._http.get(path, params=params)
        except httpx.HTTPError as exc:
            raise TransportError(f"network error calling {path}: {type(exc).__name__}") from exc

        body = safe_json(response)
        raise_for_response(response.status_code, body)
        return body
