"""investify-data — Python client for the Investify Data API.

Install:
    pip install investify-data

Quickstart:
    from investify_data import DataClient

    with DataClient(api_key="ifyu_…") as client:
        categories = client.catalog.list_categories()
        rows = client.tables.query("stock_price_history", filters={"symbol": "VNM"}, limit=5)
        hits = client.collections.search("market_news", q="lãi suất ngân hàng", limit=3)

Async:
    from investify_data import AsyncDataClient

    async with AsyncDataClient(api_key="ifyu_…") as client:
        await client.tables.query(...)
"""

from investify_data._base import DEFAULT_BASE_URL
from investify_data.async_client import AsyncDataClient
from investify_data.client import DataClient
from investify_data.exceptions import (
    APIError,
    Forbidden,
    InvalidRequest,
    InvestifyDataError,
    NotFound,
    RateLimited,
    ServerError,
    TransportError,
    Unauthorized,
)

__version__ = "0.1.0a3"

__all__ = [
    "DataClient",
    "AsyncDataClient",
    "DEFAULT_BASE_URL",
    "InvestifyDataError",
    "APIError",
    "TransportError",
    "Unauthorized",
    "Forbidden",
    "NotFound",
    "InvalidRequest",
    "RateLimited",
    "ServerError",
    "__version__",
]
