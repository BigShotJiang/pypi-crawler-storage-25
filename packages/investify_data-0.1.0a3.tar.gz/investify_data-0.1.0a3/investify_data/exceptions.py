"""Exception hierarchy for investify-data.

Raised by both sync and async clients. Server error codes (INVALID_FILTER,
UNKNOWN_COLUMN, …) map to specific subclasses when possible so callers can
catch precisely.
"""

from typing import Any


class InvestifyDataError(Exception):
    """Base exception. All other exceptions in this package derive from this."""

    def __init__(
        self,
        message: str,
        *,
        status_code: int | None = None,
        code: str | None = None,
        detail: Any = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.code = code
        self.detail = detail


class TransportError(InvestifyDataError):
    """Network-level failure (DNS, TCP, TLS, timeout)."""


class APIError(InvestifyDataError):
    """Server returned a non-2xx response."""


class Unauthorized(APIError):
    """401 — missing/malformed/revoked key."""


class Forbidden(APIError):
    """403 — credential lacks required role or resource not reachable."""


class NotFound(APIError):
    """404 — table/collection/document id not found."""


class InvalidRequest(APIError):
    """400 — malformed filter/column/argument."""


class RateLimited(APIError):
    """429 — rate limit exceeded."""


class ServerError(APIError):
    """5xx — server-side issue (including QUERY_TIMEOUT)."""


_STATUS_MAP: dict[int, type[APIError]] = {
    400: InvalidRequest,
    401: Unauthorized,
    403: Forbidden,
    404: NotFound,
    429: RateLimited,
}


def raise_for_response(status_code: int, body: Any) -> None:
    """Translate a non-2xx response into the right exception class."""
    if 200 <= status_code < 300:
        return

    detail = body
    code = None
    message = f"HTTP {status_code}"

    if isinstance(body, dict):
        err = body.get("error")
        if isinstance(err, dict):
            code = err.get("code")
            message = err.get("message") or message
            detail = err.get("detail", detail)
        elif "detail" in body:
            raw = body["detail"]
            if isinstance(raw, dict):
                code = raw.get("code")
                message = raw.get("message") or message
            else:
                message = str(raw)

    if status_code >= 500:
        cls: type[APIError] = ServerError
    else:
        cls = _STATUS_MAP.get(status_code, APIError)

    raise cls(message, status_code=status_code, code=code, detail=detail)
