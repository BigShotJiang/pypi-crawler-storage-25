"""Sync resource namespaces: catalog, tables, collections."""

from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any

from investify_data._base import build_query_params

if TYPE_CHECKING:
    from investify_data.client import DataClient


class CatalogResource:
    def __init__(self, client: DataClient) -> None:
        self._client = client

    def list_table_categories(self) -> dict[str, Any]:
        return self._client._get_json("/v1/catalog/table-categories")

    def list_tables(self, category: str | None = None) -> dict[str, Any]:
        params = [("category", category)] if category else []
        return self._client._get_json("/v1/catalog/tables", params=params)

    def describe_table(self, table_id: str, *, group: str | list[str] | None = None) -> dict[str, Any]:
        params: list[tuple[str, str]] = []
        if group is not None:
            value = group if isinstance(group, str) else ",".join(group)
            params.append(("group", value))
        return self._client._get_json(f"/v1/catalog/tables/{table_id}", params=params)

    def list_collections(self) -> dict[str, Any]:
        return self._client._get_json("/v1/catalog/collections")

    def describe_collection(self, collection_id: str) -> dict[str, Any]:
        return self._client._get_json(f"/v1/catalog/collections/{collection_id}")


class TablesResource:
    def __init__(self, client: DataClient) -> None:
        self._client = client

    def query(
        self,
        table_id: str,
        *,
        columns: list[str] | None = None,
        filters: Mapping[str, Any] | None = None,
        sort: str | None = None,
        limit: int = 100,
        offset: int = 0,
    ) -> dict[str, Any]:
        params = build_query_params(
            columns=columns,
            sort=sort,
            limit=limit,
            offset=offset,
            filters=filters,
        )
        return self._client._get_json(f"/v1/tables/{table_id}", params=params)


class CollectionsResource:
    def __init__(self, client: DataClient) -> None:
        self._client = client

    def search(
        self,
        collection_id: str,
        *,
        q: str | None = None,
        mode: str = "semantic",
        metadata_filters: Mapping[str, Any] | None = None,
        limit: int = 10,
        offset: int = 0,
        sort: str | None = None,
        include_matches: bool = False,
    ) -> dict[str, Any]:
        """Retrieve documents from a collection.

        Pass `q` for semantic search. Omit `q` for metadata-only list mode;
        use `sort` (e.g. "published_at.desc") to order. Response shape is
        the same; `score` is None in list mode.
        """
        params = build_query_params(
            limit=limit,
            offset=offset,
            filters=metadata_filters,
            extra={
                "q": q,
                "mode": mode if q is not None else None,
                "sort": sort,
                "include_matches": include_matches if q is not None else None,
            },
        )
        return self._client._get_json(f"/v1/collections/{collection_id}", params=params)

    def get(self, collection_id: str, doc_id: str) -> dict[str, Any]:
        return self._client._get_json(f"/v1/collections/{collection_id}/{doc_id}")
