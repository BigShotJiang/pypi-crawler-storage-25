"""CrewAI adapter — coming soon."""


def protect_crewai(*args, **kwargs):
    raise NotImplementedError(
        "The CrewAI adapter is not yet implemented. "
        "Use sentinely.protect() directly to wrap your agent. "
        "See https://sentinely.ai/docs for examples."
    )
