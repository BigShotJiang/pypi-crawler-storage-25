"""Auto-detect available LLM providers from environment variables."""

import os

PROVIDER_ENV_MAP = {
    'openai':      {'keys': ['OPENAI_API_KEY'],                    'label': 'OpenAI GPT-5.4',       'model': 'gpt-5.4'},
    'anthropic':   {'keys': ['ANTHROPIC_API_KEY'],                 'label': 'Claude Sonnet 4.6',     'model': 'claude-sonnet-4-6'},
    'xai':         {'keys': ['XAI_API_KEY', 'GROK_API_KEY'],      'label': 'xAI Grok 4',           'model': 'grok-4'},
    'mistral':     {'keys': ['MISTRAL_API_KEY'],                   'label': 'Mistral Large',         'model': 'mistral-large-latest'},
    'cohere':      {'keys': ['COHERE_API_KEY'],                    'label': 'Cohere Command R+',     'model': 'command-r-plus-08-2024'},
    'gemini':      {'keys': ['GEMINI_API_KEY'],                    'label': 'Google Gemini 2.5',     'model': 'gemini-2.5-flash'},
    'perplexity':  {'keys': ['PERPLEXITY_API_KEY'],                'label': 'Perplexity Sonar Pro',  'model': 'sonar-pro'},
    'groq':        {'keys': ['GROQ_API_KEY'],                      'label': 'Groq',                  'model': 'llama-3.3-70b-versatile'},
    'huggingface': {'keys': ['HF_API_KEY', 'HUGGINGFACE_API_KEY'], 'label': 'HuggingFace Qwen 3.5',  'model': 'Qwen/Qwen3.5-9B'},
}


def detect_providers():
    """Scan env vars for provider API keys. Returns list of dicts."""
    found = []
    for name, config in PROVIDER_ENV_MAP.items():
        for env_key in config['keys']:
            if os.environ.get(env_key):
                found.append({
                    'name': name,
                    'label': config['label'],
                    'model': config['model'],
                    'env_key': env_key,
                })
                break

    # Check Ollama (no key needed)
    try:
        import requests
        r = requests.get(
            os.environ.get('OLLAMA_HOST', 'http://localhost:11434') + '/api/tags',
            timeout=1.5,
        )
        if r.ok:
            found.append({
                'name': 'ollama',
                'label': 'Ollama (Local)',
                'model': 'llama3.2:3b',
                'env_key': '',
            })
    except Exception:
        pass

    return found
