"""Direct provider calls using geepers-kernel ProviderFactory."""

import json
import sys

# geepers-kernel is installed as a package (geepers-kernel>=1.4.0)
# but also available at ~/shared/ on the dev server
if '/home/coolhand/shared' not in sys.path:
    sys.path.insert(0, '/home/coolhand/shared')

from flask import Response


def stream_direct(data):
    """Stream chat response directly from a provider via geepers-kernel."""
    from llm_providers import ProviderFactory

    provider_name = data.get('provider', 'xai')
    model = data.get('model')
    messages_raw = data.get('messages', [])

    provider = ProviderFactory.get_provider(provider_name)

    # Build messages for the provider
    from llm_providers.base import Message
    msgs = [Message(role=m['role'], content=m['content']) for m in messages_raw]

    kwargs = {}
    if model:
        kwargs['model'] = model

    def generate():
        try:
            for chunk in provider.stream_complete(msgs, **kwargs):
                text = chunk.content if hasattr(chunk, 'content') else str(chunk)
                yield f"data: {json.dumps({'content': text})}\n\n"
            yield f"data: {json.dumps({'done': True})}\n\n"
        except Exception as e:
            yield f"data: {json.dumps({'error': str(e)})}\n\n"

    return Response(generate(), mimetype='text/event-stream')
