"""Entry point for `python -m geepers_chat`."""

import argparse
import sys
import webbrowser
from .detect import detect_providers
from .server import create_app


def main():
    parser = argparse.ArgumentParser(
        description='Geepers Chat - Multi-provider LLM chat UI',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Environment variables:
  Set provider API keys to enable direct mode:
    OPENAI_API_KEY, ANTHROPIC_API_KEY, XAI_API_KEY,
    MISTRAL_API_KEY, COHERE_API_KEY, GEMINI_API_KEY,
    PERPLEXITY_API_KEY, GROQ_API_KEY, HF_API_KEY

  Or use gateway mode:
    GATEWAY_API_KEY    Key for the gateway API
""",
    )
    parser.add_argument('--port', type=int, default=3456, help='Port to listen on (default: 3456)')
    parser.add_argument('--host', default='127.0.0.1', help='Bind address (default: 127.0.0.1)')
    parser.add_argument('--gateway', nargs='?', const='https://api.dr.eamer.dev/v1', default=None,
                        help='Use gateway mode (default URL: api.dr.eamer.dev)')
    parser.add_argument('--no-open', action='store_true', help="Don't open browser automatically")
    args = parser.parse_args()

    providers = detect_providers()

    if args.gateway or not providers:
        mode = 'gateway'
        gateway_url = args.gateway or 'https://api.dr.eamer.dev/v1'
    else:
        mode = 'direct'
        gateway_url = 'https://api.dr.eamer.dev/v1'

    app = create_app(mode=mode, providers=providers, gateway_url=gateway_url)

    url = f"http://{'localhost' if args.host == '0.0.0.0' else args.host}:{args.port}"

    provider_names = ', '.join(p['name'] for p in providers) if providers else 'none (gateway handles routing)'
    mode_desc = f"Direct ({len(providers)} provider{'s' if len(providers) != 1 else ''})" if mode == 'direct' else f"Gateway ({gateway_url})"

    print(f"""
  \033[1mgeepers-chat\033[0m

  Mode:      {mode_desc}
  Providers: {provider_names}
  URL:       {url}

  Press Ctrl+C to stop
""")

    if not args.no_open:
        webbrowser.open(url)

    app.run(host=args.host, port=args.port, debug=False)


if __name__ == '__main__':
    main()
