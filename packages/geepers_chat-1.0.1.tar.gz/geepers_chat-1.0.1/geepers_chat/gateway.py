"""Gateway proxy mode — forward requests to a remote gateway."""

import json
import os
import requests
from flask import Response


def proxy_to_gateway(data, gateway_url):
    """Proxy a chat request to a gateway API and stream SSE back."""
    api_key = os.environ.get('GATEWAY_API_KEY', '')

    try:
        upstream = requests.post(
            f"{gateway_url}/llm/chat",
            json={**data, 'stream': True},
            headers={
                'Content-Type': 'application/json',
                'X-API-Key': api_key,
            },
            stream=True,
            timeout=60,
        )

        if upstream.status_code != 200:
            return Response(
                f"data: {json.dumps({'error': upstream.text})}\n\n",
                mimetype='text/event-stream',
                status=upstream.status_code,
            )

        def generate():
            for line in upstream.iter_lines(decode_unicode=True):
                if line:
                    yield line + '\n\n'

        return Response(generate(), mimetype='text/event-stream')

    except Exception as e:
        return Response(
            f"data: {json.dumps({'error': str(e)})}\n\n",
            mimetype='text/event-stream',
        )
