"""Flask app factory for geepers-chat."""

import json
import os
from flask import Flask, request, jsonify
from .providers import stream_direct
from .gateway import proxy_to_gateway


def create_app(mode='direct', providers=None, gateway_url='https://api.dr.eamer.dev/v1'):
    """Create and configure the Flask application."""
    static_dir = os.path.join(os.path.dirname(__file__), 'static')
    app = Flask(__name__, static_folder=static_dir, static_url_path='/static')
    providers = providers or []

    first_provider = providers[0]['name'] if providers else 'xai'
    available_json = json.dumps([p['name'] for p in providers])

    html_template = f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Geepers Chat</title>
  <style>html, body {{ margin: 0; padding: 0; height: 100%; background: #09090b; }} #app {{ height: 100%; }}</style>
</head>
<body>
  <div id="app"></div>
  <script src="/dist/index.iife.global.js"></script>
  <script>
    (function() {{
      var chat = new GChat.ChatUI('#app', {{
        gateway: '',
        apiKey: 'local',
        provider: '{first_provider}',
        theme: 'dark',
      }});
      var available = new Set({available_json});
      var select = document.querySelector('.gchat-provider-select');
      if (select) {{
        Array.from(select.options).forEach(function(opt) {{
          if (!available.has(opt.value)) opt.remove();
        }});
      }}
    }})();
  </script>
</body>
</html>"""

    @app.route('/')
    def index():
        return html_template, 200, {'Content-Type': 'text/html'}

    @app.route('/dist/index.iife.global.js')
    def iife_bundle():
        return app.send_static_file('index.iife.global.js')

    @app.route('/providers')
    def list_providers():
        return jsonify([{'name': p['name'], 'label': p['label'], 'model': p['model']} for p in providers])

    @app.route('/health')
    def health():
        return jsonify({'status': 'ok', 'mode': mode, 'providers': [p['name'] for p in providers]})

    @app.route('/llm/chat', methods=['POST'])
    def chat():
        data = request.get_json()
        if mode == 'gateway':
            return proxy_to_gateway(data, gateway_url)
        return stream_direct(data)

    return app
