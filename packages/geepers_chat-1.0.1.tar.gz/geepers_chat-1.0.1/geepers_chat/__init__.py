"""geepers-chat: One-command multi-provider LLM chat UI."""

__version__ = "1.0.1"
