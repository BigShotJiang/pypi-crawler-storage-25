var GChat = (function (exports) {
  'use strict';

  // node_modules/@geepers/sse/dist/index.js
  function extractContent(parsed) {
    if (typeof parsed.content === "string")
      return parsed.content;
    const choices = parsed.choices;
    if (choices?.[0]) {
      const delta2 = choices[0].delta;
      if (delta2?.content)
        return delta2.content;
    }
    const message = parsed.message;
    if (message?.content)
      return message.content;
    const contentBlock = parsed.content_block;
    if (contentBlock?.text)
      return contentBlock.text;
    const delta = parsed.delta;
    if (delta?.text)
      return delta.text;
    return "";
  }
  var SSEChat = class {
    constructor(options) {
      this.apiUrl = options.apiUrl;
      this.apiKey = options.apiKey;
      this.headers = options.headers ?? {};
    }
    /** Update the API key at runtime */
    setApiKey(key) {
      this.apiKey = key;
    }
    /**
     * Send a chat message and stream the response via SSE.
     * Returns a promise that resolves with the full response text.
     */
    async send(options) {
      const { provider, model, messages, onChunk, onDone, onError, signal, extraParams } = options;
      const headers = {
        "Content-Type": "application/json",
        "Accept": "text/event-stream",
        ...this.headers
      };
      if (this.apiKey) {
        headers["X-API-Key"] = this.apiKey;
      }
      let fullContent = "";
      try {
        const response = await fetch(this.apiUrl, {
          method: "POST",
          headers,
          body: JSON.stringify({
            provider,
            model,
            messages,
            stream: true,
            ...extraParams
          }),
          signal
        });
        if (!response.ok) {
          const errorText = await response.text();
          const error = new Error(response.status === 401 ? "Invalid API key" : response.status === 429 ? "Rate limit exceeded" : `HTTP ${response.status}: ${errorText}`);
          onError?.(error);
          throw error;
        }
        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        let buffer = "";
        while (true) {
          const { done, value } = await reader.read();
          if (done)
            break;
          buffer += decoder.decode(value, { stream: true });
          const lines = buffer.split("\n");
          buffer = lines.pop() ?? "";
          for (const line of lines) {
            if (line.trim() === "" || !line.startsWith("data: "))
              continue;
            const data = line.slice(6);
            if (data === "[DONE]")
              continue;
            try {
              const parsed = JSON.parse(data);
              const chunk = extractContent(parsed);
              if (chunk) {
                fullContent += chunk;
                onChunk?.(chunk, fullContent);
              }
            } catch {
            }
          }
        }
        onDone?.(fullContent);
        return fullContent;
      } catch (error) {
        if (error instanceof Error && error.name === "AbortError") {
          onDone?.(fullContent);
          return fullContent;
        }
        const err = error instanceof Error ? error : new Error(String(error));
        onError?.(err);
        throw err;
      }
    }
  };

  // src/core/providers.ts
  var MODELS = {
    xai: {
      model: "grok-4",
      label: "xAI Grok 4"
    },
    anthropic: {
      model: "claude-sonnet-4-6",
      label: "Claude Sonnet 4.6"
    },
    openai: {
      model: "gpt-5.4",
      label: "OpenAI GPT-5.4"
    },
    cohere: {
      model: "command-r-plus-08-2024",
      label: "Cohere Command R+"
    },
    mistral: {
      model: "mistral-large-latest",
      label: "Mistral Large"
    },
    perplexity: {
      model: "sonar-pro",
      label: "Perplexity Sonar Pro"
    },
    huggingface: {
      model: "Qwen/Qwen3.5-9B",
      label: "HuggingFace Qwen 3.5"
    },
    gemini: {
      model: "gemini-2.5-flash",
      label: "Google Gemini 2.5"
    },
    ollama: {
      model: "llama3.2:3b",
      label: "Ollama (Local)"
    }
  };
  var PROVIDER_KEYS = Object.keys(MODELS);
  function isKnownProvider(value) {
    const known = PROVIDER_KEYS.includes(value);
    if (!known) {
      console.warn(`[@geepers/chat] Unknown provider: "${value}". Known providers: ${PROVIDER_KEYS.join(", ")}`);
    }
    return known;
  }
  function getProviderConfig(provider) {
    if (isKnownProvider(provider)) {
      return MODELS[provider];
    }
    return MODELS.xai;
  }

  // src/core/storage.ts
  var DEFAULT_KEY = "gchat_conversations";
  var MAX_CONVOS = 20;
  var ConversationStorage = class {
    constructor(storageKey = DEFAULT_KEY) {
      this.key = storageKey;
    }
    read() {
      try {
        return JSON.parse(localStorage.getItem(this.key) || "{}");
      } catch {
        return {};
      }
    }
    write(data) {
      try {
        localStorage.setItem(this.key, JSON.stringify(data));
      } catch {
      }
    }
    all() {
      const data = this.read();
      return Object.values(data).sort((a, b) => b.updatedAt - a.updatedAt);
    }
    get(id) {
      return this.read()[id];
    }
    save(record) {
      const data = this.read();
      data[record.id] = record;
      const sorted = Object.keys(data).sort(
        (a, b) => data[b].updatedAt - data[a].updatedAt
      );
      if (sorted.length > MAX_CONVOS) {
        sorted.slice(MAX_CONVOS).forEach((k) => delete data[k]);
      }
      this.write(data);
    }
    delete(id) {
      const data = this.read();
      delete data[id];
      this.write(data);
    }
    /** Create a new ConversationRecord from the given messages */
    static build(id, messages, provider, systemPrompt) {
      const first = messages.find((m) => m.role === "user");
      const title = first ? first.content.slice(0, 50) + (first.content.length > 50 ? "\u2026" : "") : "New conversation";
      return {
        id,
        title,
        messages,
        provider,
        systemPrompt,
        createdAt: Date.now(),
        updatedAt: Date.now()
      };
    }
  };

  // src/core/ChatCore.ts
  var DEFAULT_GATEWAY = "https://api.dr.eamer.dev/v1";
  var DEFAULT_STORAGE_KEY = "gchat_conversations";
  function generateId() {
    if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") {
      return crypto.randomUUID();
    }
    return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`;
  }
  function generateMessageId() {
    return generateId();
  }
  function now() {
    return Date.now();
  }
  var EventEmitter = class {
    constructor() {
      this.handlers = /* @__PURE__ */ new Map();
    }
    on(type, handler) {
      if (!this.handlers.has(type)) {
        this.handlers.set(type, /* @__PURE__ */ new Set());
      }
      this.handlers.get(type).add(handler);
    }
    off(type, handler) {
      this.handlers.get(type)?.delete(handler);
    }
    emit(event) {
      this.handlers.get(event.type)?.forEach((h) => h(event));
    }
  };
  var ChatCore = class {
    constructor(config = {}) {
      this.config = {
        gateway: DEFAULT_GATEWAY,
        storageKey: DEFAULT_STORAGE_KEY,
        theme: "auto",
        ...config
      };
      this.emitter = new EventEmitter();
      const initialProvider = config.provider && isKnownProvider(config.provider) ? config.provider : "xai";
      this._provider = initialProvider;
      this._model = config.model ?? MODELS[initialProvider].model;
      this._systemPrompt = config.systemPrompt ?? "";
      this._messages = [];
      this._conversationId = null;
      this._isStreaming = false;
      this._abortController = null;
      this.sseClient = new SSEChat({
        apiUrl: `${this.config.gateway}/llm/chat`,
        apiKey: this._resolveApiKey()
      });
      this.storage = new ConversationStorage(this.config.storageKey);
      if (config.conversationId) {
        this.loadConversation(config.conversationId);
      } else {
        this._conversationId = generateId();
      }
    }
    // ========== Getters ==========
    get provider() {
      return this._provider;
    }
    get model() {
      return this._model;
    }
    get systemPrompt() {
      return this._systemPrompt;
    }
    get messages() {
      return this._messages;
    }
    get conversationId() {
      return this._conversationId;
    }
    get isStreaming() {
      return this._isStreaming;
    }
    // ========== Event subscriptions ==========
    on(type, handler) {
      this.emitter.on(type, handler);
    }
    off(type, handler) {
      this.emitter.off(type, handler);
    }
    // ========== Configuration mutations ==========
    setProvider(provider) {
      if (!isKnownProvider(provider)) return;
      this._provider = provider;
      this._model = MODELS[provider].model;
      this.sseClient.setApiKey(this._resolveApiKey());
    }
    setModel(model) {
      this._model = model;
    }
    setSystemPrompt(prompt) {
      this._systemPrompt = prompt;
    }
    setApiKey(key) {
      this.sseClient.setApiKey(key);
    }
    // ========== Core actions ==========
    /**
     * Send a user message and stream the assistant response.
     * Rejects if a stream is already active.
     */
    async send(content) {
      if (this._isStreaming) {
        throw new Error("A stream is already in progress. Call stop() first.");
      }
      if (!content.trim()) return;
      const userMessage = this._addMessage("user", content);
      this.emitter.emit({ type: "message", message: userMessage });
      const assistantId = generateMessageId();
      const assistantPlaceholder = {
        id: assistantId,
        role: "assistant",
        content: "",
        timestamp: now(),
        provider: this._provider
      };
      this._messages.push(assistantPlaceholder);
      this._isStreaming = true;
      this._abortController = new AbortController();
      this.emitter.emit({ type: "stream-start", messageId: assistantId });
      this.config.onStreamStart?.(assistantId);
      const apiMessages = [];
      if (this._systemPrompt.trim()) {
        apiMessages.push({ role: "system", content: this._systemPrompt.trim() });
      }
      for (const m of this._messages) {
        if (m.role !== "system" && m.id !== assistantId) {
          apiMessages.push({ role: m.role, content: m.content });
        }
      }
      let accumulated = "";
      try {
        await this.sseClient.send({
          provider: this._provider,
          model: this._model,
          messages: apiMessages,
          signal: this._abortController.signal,
          onChunk: (chunk, acc) => {
            accumulated = acc;
            assistantPlaceholder.content = acc;
            this.emitter.emit({
              type: "stream-chunk",
              chunk,
              accumulated: acc,
              messageId: assistantId
            });
          },
          onDone: (fullText) => {
            assistantPlaceholder.content = fullText;
            assistantPlaceholder.timestamp = now();
          },
          onError: (error) => {
            this.emitter.emit({ type: "error", error });
            this.config.onError?.(error);
          }
        });
      } catch (error) {
        if (!(error instanceof Error && error.name === "AbortError")) {
          const err = error instanceof Error ? error : new Error(String(error));
          this.emitter.emit({ type: "error", error: err });
          this.config.onError?.(err);
        }
      } finally {
        this._isStreaming = false;
        this._abortController = null;
        const finalMessage = { ...assistantPlaceholder, content: accumulated || assistantPlaceholder.content };
        assistantPlaceholder.content = finalMessage.content;
        this.emitter.emit({ type: "stream-end", message: assistantPlaceholder });
        this.config.onStreamEnd?.(assistantPlaceholder);
        this.config.onMessage?.(assistantPlaceholder);
        this._saveCurrentConversation();
      }
    }
    /**
     * Abort the current stream. The partial assistant response is kept.
     */
    stop() {
      if (this._abortController) {
        this._abortController.abort();
      }
    }
    /**
     * Clear messages and start a fresh conversation with a new UUID.
     * Saves the current conversation before clearing if it has messages.
     */
    clearHistory() {
      this._saveCurrentConversation();
      this._messages = [];
      this._conversationId = generateId();
      this.emitter.emit({ type: "conversation-change", conversationId: this._conversationId });
    }
    // ========== Persistence ==========
    /**
     * Load a saved conversation by ID.
     * Saves the current conversation first.
     */
    loadConversation(id) {
      this._saveCurrentConversation();
      const record = this.storage.get(id);
      if (!record) return false;
      this._conversationId = id;
      this._messages = record.messages ?? [];
      this._provider = isKnownProvider(record.provider) ? record.provider : "xai";
      this._model = MODELS[this._provider].model;
      this._systemPrompt = record.systemPrompt ?? "";
      this.emitter.emit({ type: "conversation-change", conversationId: id });
      return true;
    }
    /**
     * Return all saved conversations, sorted newest first.
     */
    getConversations() {
      return this.storage.all();
    }
    /**
     * Delete a saved conversation by ID.
     * If deleting the active conversation, starts a fresh one.
     */
    deleteConversation(id) {
      this.storage.delete(id);
      if (id === this._conversationId) {
        this.clearHistory();
      }
    }
    // ========== Private helpers ==========
    _resolveApiKey() {
      if (this.config.apiKey) return this.config.apiKey;
      try {
        return localStorage.getItem("api_key") ?? "";
      } catch {
        return "";
      }
    }
    _addMessage(role, content, provider) {
      const message = {
        id: generateMessageId(),
        role,
        content,
        timestamp: now(),
        provider
      };
      this._messages.push(message);
      return message;
    }
    _saveCurrentConversation() {
      if (!this._conversationId || this._messages.length === 0) return;
      const existing = this.storage.get(this._conversationId);
      const record = ConversationStorage.build(
        this._conversationId,
        [...this._messages],
        this._provider,
        this._systemPrompt
      );
      if (existing) record.createdAt = existing.createdAt;
      this.storage.save(record);
    }
  };

  // src/ui/styles.ts
  var CHAT_CSS = `
/**
 * @geepers/chat \u2014 default UI styles
 * Self-contained: injected as a <style> tag when ChatUI mounts.
 * Uses CSS custom properties so host page can override any token.
 */

/* ========== Reset & Scope ========== */
.gchat-root,
.gchat-root * {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}

/* ========== Tokens ========== */
.gchat-root {
  /* Light theme defaults */
  --gchat-bg-0:     #ffffff;
  --gchat-bg-1:     #f4f4f5;
  --gchat-bg-2:     #e4e4e7;
  --gchat-text-0:   #18181b;
  --gchat-text-1:   #3f3f46;
  --gchat-text-2:   #71717a;
  --gchat-border:   #d4d4d8;
  --gchat-accent:   #6366f1;
  --gchat-accent-h: #4f46e5;
  --gchat-error:    #ef4444;
  --gchat-radius:   8px;
  --gchat-radius-sm:4px;
  --gchat-shadow:   0 1px 3px rgba(0,0,0,0.08);
  --gchat-font:     -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
  --gchat-mono:     'SFMono-Regular', Consolas, 'Liberation Mono', monospace;
  --gchat-ease:     150ms ease;
  --gchat-sidebar-w:260px;
}

/* Dark theme override */
.gchat-root[data-theme="dark"] {
  --gchat-bg-0:   #09090b;
  --gchat-bg-1:   #18181b;
  --gchat-bg-2:   #27272a;
  --gchat-text-0: #fafafa;
  --gchat-text-1: #d4d4d8;
  --gchat-text-2: #71717a;
  --gchat-border: #3f3f46;
  --gchat-shadow: 0 1px 3px rgba(0,0,0,0.4);
}

/* ========== Root Layout ========== */
.gchat-root {
  font-family: var(--gchat-font);
  font-size: 14px;
  color: var(--gchat-text-0);
  background: var(--gchat-bg-0);
  display: flex;
  height: 100%;
  min-height: 400px;
  overflow: hidden;
  position: relative;
}

/* ========== Sidebar ========== */
.gchat-sidebar {
  width: var(--gchat-sidebar-w);
  flex-shrink: 0;
  background: var(--gchat-bg-1);
  border-right: 1px solid var(--gchat-border);
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

.gchat-sidebar-header {
  padding: 12px 14px;
  border-bottom: 1px solid var(--gchat-border);
  display: flex;
  align-items: center;
  gap: 8px;
}

.gchat-sidebar-title {
  font-size: 0.8rem;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.06em;
  color: var(--gchat-text-2);
  flex: 1;
}

.gchat-new-btn {
  padding: 5px 10px;
  background: var(--gchat-accent);
  color: #fff;
  border: none;
  border-radius: var(--gchat-radius-sm);
  font-size: 0.8rem;
  font-weight: 600;
  cursor: pointer;
  transition: background var(--gchat-ease);
  white-space: nowrap;
}
.gchat-new-btn:hover { background: var(--gchat-accent-h); }

.gchat-history {
  flex: 1;
  overflow-y: auto;
  padding: 8px;
}

.gchat-history-empty {
  padding: 16px;
  font-size: 0.8rem;
  color: var(--gchat-text-2);
  text-align: center;
}

.gchat-history-item {
  display: flex;
  align-items: center;
  gap: 4px;
  padding: 8px 10px;
  border-radius: var(--gchat-radius-sm);
  cursor: pointer;
  transition: background var(--gchat-ease);
}
.gchat-history-item:hover { background: var(--gchat-bg-2); }
.gchat-history-item.active {
  background: var(--gchat-accent);
  color: #fff;
}

.gchat-history-item-title {
  flex: 1;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-size: 0.82rem;
}

.gchat-history-item-del {
  background: none;
  border: none;
  cursor: pointer;
  color: inherit;
  opacity: 0.4;
  font-size: 0.75rem;
  padding: 2px 4px;
  border-radius: 2px;
  transition: opacity var(--gchat-ease);
  flex-shrink: 0;
}
.gchat-history-item-del:hover { opacity: 1; }

/* ========== Main Area ========== */
.gchat-main {
  flex: 1;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  background: var(--gchat-bg-0);
}

/* ========== Top bar ========== */
.gchat-topbar {
  padding: 10px 14px;
  border-bottom: 1px solid var(--gchat-border);
  display: flex;
  align-items: center;
  gap: 10px;
  flex-shrink: 0;
}

.gchat-mobile-toggle {
  display: none;
  background: none;
  border: 1px solid var(--gchat-border);
  border-radius: var(--gchat-radius-sm);
  padding: 5px 8px;
  cursor: pointer;
  color: var(--gchat-text-0);
  font-size: 0.85rem;
}

.gchat-provider-select {
  padding: 5px 8px;
  border: 1px solid var(--gchat-border);
  border-radius: var(--gchat-radius-sm);
  background: var(--gchat-bg-0);
  color: var(--gchat-text-0);
  font-size: 0.82rem;
  cursor: pointer;
}

.gchat-topbar-spacer { flex: 1; }

.gchat-provider-badge {
  font-size: 0.75rem;
  font-weight: 600;
  color: var(--gchat-accent);
  white-space: nowrap;
}

/* System prompt toggle */
.gchat-sys-toggle {
  background: none;
  border: 1px solid var(--gchat-border);
  border-radius: var(--gchat-radius-sm);
  padding: 4px 8px;
  font-size: 0.75rem;
  cursor: pointer;
  color: var(--gchat-text-2);
  transition: all var(--gchat-ease);
}
.gchat-sys-toggle:hover { color: var(--gchat-text-0); border-color: var(--gchat-accent); }

/* System prompt panel */
.gchat-sysprompt-panel {
  padding: 8px 14px;
  border-bottom: 1px solid var(--gchat-border);
  background: var(--gchat-bg-1);
}
.gchat-sysprompt-panel.hidden { display: none; }

.gchat-sysprompt-input {
  width: 100%;
  padding: 7px 10px;
  border: 1px solid var(--gchat-border);
  border-radius: var(--gchat-radius-sm);
  background: var(--gchat-bg-0);
  color: var(--gchat-text-0);
  font-family: var(--gchat-font);
  font-size: 0.82rem;
  resize: vertical;
  min-height: 60px;
}
.gchat-sysprompt-input:focus {
  outline: none;
  border-color: var(--gchat-accent);
}

/* ========== Messages ========== */
.gchat-messages {
  flex: 1;
  overflow-y: auto;
  padding: 16px 14px;
  scroll-behavior: smooth;
}

/* Welcome screen */
.gchat-welcome {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  text-align: center;
  padding: 40px 24px;
  height: 100%;
  min-height: 200px;
}

.gchat-welcome h2 {
  font-size: 1.5rem;
  font-weight: 700;
  margin-bottom: 8px;
}

.gchat-welcome p {
  color: var(--gchat-text-2);
  margin-bottom: 20px;
  font-size: 0.9rem;
}

.gchat-hints {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  justify-content: center;
}

.gchat-hint-chip {
  padding: 7px 14px;
  border: 1px solid var(--gchat-border);
  border-radius: 20px;
  background: var(--gchat-bg-1);
  color: var(--gchat-text-1);
  font-size: 0.82rem;
  cursor: pointer;
  transition: all var(--gchat-ease);
}
.gchat-hint-chip:hover {
  border-color: var(--gchat-accent);
  color: var(--gchat-accent);
  background: var(--gchat-bg-0);
}

/* Message bubbles */
.gchat-msg {
  margin-bottom: 16px;
  max-width: 100%;
}

.gchat-msg-header {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 4px;
}

.gchat-msg-role {
  font-size: 0.75rem;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  color: var(--gchat-text-2);
}

.gchat-msg-actions {
  display: flex;
  gap: 4px;
  margin-left: auto;
  opacity: 0;
  transition: opacity var(--gchat-ease);
}
.gchat-msg:hover .gchat-msg-actions { opacity: 1; }

.gchat-msg-action-btn {
  background: none;
  border: 1px solid var(--gchat-border);
  border-radius: var(--gchat-radius-sm);
  padding: 2px 7px;
  font-size: 0.72rem;
  cursor: pointer;
  color: var(--gchat-text-2);
  transition: all var(--gchat-ease);
}
.gchat-msg-action-btn:hover { color: var(--gchat-text-0); border-color: var(--gchat-accent); }

.gchat-msg-body {
  line-height: 1.65;
  word-break: break-word;
}

.gchat-msg.user .gchat-msg-body {
  white-space: pre-wrap;
}

/* Loading animation */
.gchat-msg.loading .gchat-msg-body::after {
  content: '\u258B';
  display: inline-block;
  animation: gchat-blink 1s step-end infinite;
  color: var(--gchat-accent);
  margin-left: 2px;
}

@keyframes gchat-blink {
  0%, 100% { opacity: 1; }
  50% { opacity: 0; }
}

/* Error message */
.gchat-msg.error .gchat-msg-body {
  color: var(--gchat-error);
  font-style: italic;
}

/* Markdown content */
.gchat-msg-body p { margin-bottom: 0.75em; }
.gchat-msg-body p:last-child { margin-bottom: 0; }
.gchat-msg-body ul, .gchat-msg-body ol { padding-left: 1.4em; margin-bottom: 0.75em; }
.gchat-msg-body li { margin-bottom: 0.25em; }
.gchat-msg-body h1, .gchat-msg-body h2, .gchat-msg-body h3 {
  margin: 1em 0 0.4em;
  font-weight: 700;
}
.gchat-msg-body h1 { font-size: 1.2em; }
.gchat-msg-body h2 { font-size: 1.1em; }
.gchat-msg-body h3 { font-size: 1em; }
.gchat-msg-body code {
  font-family: var(--gchat-mono);
  font-size: 0.88em;
  background: var(--gchat-bg-2);
  padding: 0.15em 0.35em;
  border-radius: 3px;
}
.gchat-msg-body pre {
  background: var(--gchat-bg-2);
  border: 1px solid var(--gchat-border);
  border-radius: var(--gchat-radius-sm);
  padding: 12px 14px;
  overflow-x: auto;
  margin-bottom: 0.75em;
  position: relative;
}
.gchat-msg-body pre code {
  background: none;
  padding: 0;
  font-size: 0.85em;
}
.gchat-msg-body blockquote {
  border-left: 3px solid var(--gchat-accent);
  padding-left: 12px;
  color: var(--gchat-text-2);
  margin: 0.5em 0;
}
.gchat-msg-body a { color: var(--gchat-accent); text-decoration: underline; }
.gchat-msg-body table { border-collapse: collapse; margin-bottom: 0.75em; width: 100%; }
.gchat-msg-body th, .gchat-msg-body td {
  border: 1px solid var(--gchat-border);
  padding: 6px 10px;
  font-size: 0.85em;
}
.gchat-msg-body th { background: var(--gchat-bg-1); font-weight: 600; }

/* Code block copy button */
.gchat-code-copy {
  position: absolute;
  top: 6px;
  right: 8px;
  padding: 2px 7px;
  font-size: 0.72rem;
  background: var(--gchat-bg-1);
  border: 1px solid var(--gchat-border);
  border-radius: 3px;
  cursor: pointer;
  color: var(--gchat-text-2);
  transition: all var(--gchat-ease);
  opacity: 0;
}
.gchat-msg-body pre:hover .gchat-code-copy { opacity: 1; }
.gchat-code-copy:hover { color: var(--gchat-text-0); }

/* ========== Input Bar ========== */
.gchat-input-bar {
  padding: 12px 14px;
  border-top: 1px solid var(--gchat-border);
  background: var(--gchat-bg-0);
  flex-shrink: 0;
}

.gchat-input-row {
  display: flex;
  gap: 8px;
  align-items: flex-end;
}

.gchat-textarea {
  flex: 1;
  padding: 9px 12px;
  border: 1px solid var(--gchat-border);
  border-radius: var(--gchat-radius);
  background: var(--gchat-bg-1);
  color: var(--gchat-text-0);
  font-family: var(--gchat-font);
  font-size: 0.9rem;
  line-height: 1.5;
  resize: none;
  min-height: 44px;
  max-height: 200px;
  overflow-y: auto;
  transition: border-color var(--gchat-ease);
}
.gchat-textarea:focus {
  outline: none;
  border-color: var(--gchat-accent);
}
.gchat-textarea::placeholder { color: var(--gchat-text-2); }

.gchat-send-btn,
.gchat-stop-btn {
  padding: 9px 16px;
  border: none;
  border-radius: var(--gchat-radius);
  font-size: 0.88rem;
  font-weight: 600;
  cursor: pointer;
  transition: all var(--gchat-ease);
  white-space: nowrap;
  flex-shrink: 0;
  height: 44px;
}

.gchat-send-btn {
  background: var(--gchat-accent);
  color: #fff;
}
.gchat-send-btn:hover:not(:disabled) { background: var(--gchat-accent-h); }
.gchat-send-btn:disabled { opacity: 0.5; cursor: not-allowed; }

.gchat-stop-btn {
  background: var(--gchat-bg-2);
  color: var(--gchat-text-0);
  border: 1px solid var(--gchat-border);
}
.gchat-stop-btn:hover { background: var(--gchat-error); color: #fff; border-color: var(--gchat-error); }
.gchat-stop-btn.hidden { display: none; }

/* ========== Sidebar overlay (mobile) ========== */
.gchat-overlay {
  display: none;
  position: absolute;
  inset: 0;
  background: rgba(0,0,0,0.4);
  z-index: 10;
}
.gchat-overlay.visible { display: block; }

/* ========== Toast ========== */
.gchat-toast {
  position: absolute;
  bottom: 20px;
  left: 50%;
  transform: translateX(-50%) translateY(10px);
  background: var(--gchat-text-0);
  color: var(--gchat-bg-0);
  padding: 8px 16px;
  border-radius: var(--gchat-radius);
  font-size: 0.82rem;
  font-weight: 600;
  white-space: nowrap;
  pointer-events: none;
  opacity: 0;
  transition: opacity 200ms, transform 200ms;
  z-index: 100;
}
.gchat-toast.show {
  opacity: 1;
  transform: translateX(-50%) translateY(0);
}

/* ========== Mobile ========== */
@media (max-width: 640px) {
  .gchat-sidebar {
    position: absolute;
    top: 0;
    left: 0;
    height: 100%;
    z-index: 20;
    transform: translateX(-100%);
    transition: transform 200ms ease;
  }
  .gchat-sidebar.open {
    transform: translateX(0);
  }
  .gchat-mobile-toggle { display: block; }
}
`;

  // src/ui/ChatUI.ts
  var DEFAULT_HINTS = [
    { label: "How do LLMs work?", prompt: "Explain how large language models work in plain language." },
    { label: "Write a function", prompt: "Write a Python function that finds all prime numbers up to N using the Sieve of Eratosthenes." },
    { label: "REST vs GraphQL", prompt: "Compare REST and GraphQL APIs \u2014 when should I use each?" }
  ];
  function escHtml(s) {
    return String(s ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  }
  function resolveTarget(target) {
    if (typeof target === "string") {
      const el = document.querySelector(target);
      if (!el) throw new Error(`[@geepers/chat] Target not found: "${target}"`);
      return el;
    }
    return target;
  }
  function renderMarkdown(text) {
    const w = globalThis;
    if (w["marked"] && typeof w["marked"]["parse"] === "function") {
      return w["marked"]["parse"](text);
    }
    return escHtml(text).replace(/\n/g, "<br>");
  }
  var _ChatUI = class _ChatUI {
    constructor(target, config = {}) {
      this.welcomeEl = null;
      this.toastTimer = null;
      this.container = resolveTarget(target);
      this.config = {
        ...config,
        welcomeHints: config.welcomeHints ?? DEFAULT_HINTS
      };
      _ChatUI.injectStyles();
      this.core = new ChatCore(config);
      this.buildDOM();
      this.wireEvents();
      this.renderHistory();
      this.showWelcome();
      if (this.core.messages.length > 0) {
        this.reRenderMessages();
      }
    }
    // ========== Public API ==========
    get chatCore() {
      return this.core;
    }
    send(text) {
      return this.core.send(text);
    }
    stop() {
      this.core.stop();
    }
    focus() {
      this.textarea?.focus();
    }
    setProvider(provider) {
      this.core.setProvider(provider);
      this.providerSelect.value = provider;
      this.providerBadge.textContent = MODELS[provider]?.label ?? provider;
    }
    setSystemPrompt(prompt) {
      this.core.setSystemPrompt(prompt);
      this.syspromptInput.value = prompt;
    }
    newConversation() {
      this.core.clearHistory();
      this.messagesEl.innerHTML = "";
      this.welcomeEl = null;
      this.showWelcome();
      this.renderHistory();
    }
    destroy() {
      this.container.innerHTML = "";
    }
    static injectStyles() {
      if (_ChatUI.stylesInjected || typeof document === "undefined") return;
      const style = document.createElement("style");
      style.setAttribute("data-gchat", "");
      style.textContent = CHAT_CSS;
      document.head.appendChild(style);
      _ChatUI.stylesInjected = true;
    }
    // ========== DOM Construction ==========
    buildDOM() {
      const theme = this.resolveTheme();
      this.root = document.createElement("div");
      this.root.className = "gchat-root";
      this.root.dataset["theme"] = theme;
      this.root.style.cssText = "width:100%;height:100%;";
      this.sidebar = document.createElement("aside");
      this.sidebar.className = "gchat-sidebar";
      const sidebarHeader = document.createElement("div");
      sidebarHeader.className = "gchat-sidebar-header";
      const sidebarTitle = document.createElement("span");
      sidebarTitle.className = "gchat-sidebar-title";
      sidebarTitle.textContent = "History";
      const newBtn = document.createElement("button");
      newBtn.className = "gchat-new-btn";
      newBtn.type = "button";
      newBtn.textContent = "New";
      newBtn.addEventListener("click", () => this.newConversation());
      sidebarHeader.appendChild(sidebarTitle);
      sidebarHeader.appendChild(newBtn);
      this.sidebar.appendChild(sidebarHeader);
      this.historyEl = document.createElement("div");
      this.historyEl.className = "gchat-history";
      this.sidebar.appendChild(this.historyEl);
      const main = document.createElement("div");
      main.className = "gchat-main";
      const topbar = document.createElement("div");
      topbar.className = "gchat-topbar";
      const mobileToggle = document.createElement("button");
      mobileToggle.className = "gchat-mobile-toggle";
      mobileToggle.type = "button";
      mobileToggle.textContent = "\u2630";
      mobileToggle.setAttribute("aria-label", "Toggle history");
      mobileToggle.addEventListener("click", () => this.toggleSidebar());
      topbar.appendChild(mobileToggle);
      this.providerSelect = document.createElement("select");
      this.providerSelect.className = "gchat-provider-select";
      this.providerSelect.setAttribute("aria-label", "Select model provider");
      PROVIDER_KEYS.forEach((key) => {
        const opt = document.createElement("option");
        opt.value = key;
        opt.textContent = MODELS[key].label;
        if (key === this.core.provider) opt.selected = true;
        this.providerSelect.appendChild(opt);
      });
      this.providerSelect.addEventListener("change", () => {
        this.core.setProvider(this.providerSelect.value);
        this.providerBadge.textContent = MODELS[this.core.provider].label;
      });
      topbar.appendChild(this.providerSelect);
      const spacer = document.createElement("span");
      spacer.className = "gchat-topbar-spacer";
      topbar.appendChild(spacer);
      this.providerBadge = document.createElement("span");
      this.providerBadge.className = "gchat-provider-badge";
      this.providerBadge.textContent = MODELS[this.core.provider].label;
      topbar.appendChild(this.providerBadge);
      const sysToggle = document.createElement("button");
      sysToggle.className = "gchat-sys-toggle";
      sysToggle.type = "button";
      sysToggle.textContent = "System";
      sysToggle.setAttribute("aria-label", "Toggle system prompt");
      sysToggle.addEventListener("click", () => {
        this.syspromptPanel.classList.toggle("hidden");
      });
      topbar.appendChild(sysToggle);
      main.appendChild(topbar);
      this.syspromptPanel = document.createElement("div");
      this.syspromptPanel.className = "gchat-sysprompt-panel hidden";
      this.syspromptInput = document.createElement("textarea");
      this.syspromptInput.className = "gchat-sysprompt-input";
      this.syspromptInput.placeholder = "System prompt (optional)\u2026";
      this.syspromptInput.value = this.core.systemPrompt;
      this.syspromptInput.rows = 3;
      this.syspromptInput.setAttribute("aria-label", "System prompt");
      this.syspromptInput.addEventListener("input", () => {
        this.core.setSystemPrompt(this.syspromptInput.value);
      });
      this.syspromptPanel.appendChild(this.syspromptInput);
      main.appendChild(this.syspromptPanel);
      this.messagesEl = document.createElement("div");
      this.messagesEl.className = "gchat-messages";
      this.messagesEl.setAttribute("role", "log");
      this.messagesEl.setAttribute("aria-live", "polite");
      this.messagesEl.setAttribute("aria-label", "Chat messages");
      main.appendChild(this.messagesEl);
      const inputBar = document.createElement("div");
      inputBar.className = "gchat-input-bar";
      const inputRow = document.createElement("div");
      inputRow.className = "gchat-input-row";
      this.textarea = document.createElement("textarea");
      this.textarea.className = "gchat-textarea";
      this.textarea.placeholder = "Message\u2026 (Enter to send, Shift+Enter for newline)";
      this.textarea.rows = 1;
      this.textarea.setAttribute("aria-label", "Chat message");
      this.textarea.addEventListener("input", () => this.autoResize());
      this.textarea.addEventListener("keydown", (e) => {
        if (e.key === "Enter" && !e.shiftKey) {
          e.preventDefault();
          void this.submitMessage();
        }
      });
      inputRow.appendChild(this.textarea);
      this.sendBtn = document.createElement("button");
      this.sendBtn.className = "gchat-send-btn";
      this.sendBtn.type = "button";
      this.sendBtn.textContent = "Send";
      this.sendBtn.addEventListener("click", () => void this.submitMessage());
      inputRow.appendChild(this.sendBtn);
      this.stopBtn = document.createElement("button");
      this.stopBtn.className = "gchat-stop-btn hidden";
      this.stopBtn.type = "button";
      this.stopBtn.textContent = "Stop";
      this.stopBtn.addEventListener("click", () => this.core.stop());
      inputRow.appendChild(this.stopBtn);
      inputBar.appendChild(inputRow);
      main.appendChild(inputBar);
      this.overlayEl = document.createElement("div");
      this.overlayEl.className = "gchat-overlay";
      this.overlayEl.setAttribute("aria-hidden", "true");
      this.overlayEl.addEventListener("click", () => this.toggleSidebar());
      this.toastEl = document.createElement("div");
      this.toastEl.className = "gchat-toast";
      this.toastEl.setAttribute("role", "status");
      this.toastEl.setAttribute("aria-live", "polite");
      this.root.appendChild(this.sidebar);
      this.root.appendChild(main);
      this.root.appendChild(this.overlayEl);
      this.root.appendChild(this.toastEl);
      this.container.appendChild(this.root);
    }
    // ========== Event wiring ==========
    wireEvents() {
      this.core.on("message", (e) => {
        if (e.message.role === "user") {
          this.removeWelcome();
          this.appendMessage(e.message);
        }
      });
      this.core.on("stream-start", (e) => {
        this.sendBtn.disabled = true;
        this.stopBtn.classList.remove("hidden");
        this.appendLoadingMessage(e.messageId);
      });
      this.core.on("stream-chunk", (e) => {
        this.updateStreamingMessage(e.messageId, e.accumulated);
      });
      this.core.on("stream-end", (e) => {
        this.sendBtn.disabled = false;
        this.stopBtn.classList.add("hidden");
        this.finalizeMessage(e.message);
        this.renderHistory();
      });
      this.core.on("error", (e) => {
        this.sendBtn.disabled = false;
        this.stopBtn.classList.add("hidden");
        this.showErrorMessage(e.error.message);
      });
      this.core.on("conversation-change", () => {
        this.messagesEl.innerHTML = "";
        this.welcomeEl = null;
        this.showWelcome();
        this.renderHistory();
      });
    }
    // ========== Message rendering ==========
    appendMessage(msg) {
      const el = document.createElement("div");
      el.className = `gchat-msg ${msg.role}`;
      el.dataset["msgId"] = msg.id;
      const header = document.createElement("div");
      header.className = "gchat-msg-header";
      const roleSpan = document.createElement("span");
      roleSpan.className = "gchat-msg-role";
      roleSpan.textContent = msg.role === "user" ? "You" : MODELS[msg.provider ?? this.core.provider]?.label ?? "Assistant";
      header.appendChild(roleSpan);
      const actions = document.createElement("div");
      actions.className = "gchat-msg-actions";
      const copyBtn = this.makeCopyBtn(() => msg.content);
      actions.appendChild(copyBtn);
      header.appendChild(actions);
      const body = document.createElement("div");
      body.className = "gchat-msg-body";
      if (msg.role === "user") {
        body.textContent = msg.content;
      } else {
        body.innerHTML = renderMarkdown(msg.content);
        this.addCodeCopyButtons(body);
      }
      el.appendChild(header);
      el.appendChild(body);
      this.messagesEl.appendChild(el);
      this.scrollToBottom();
      return el;
    }
    appendLoadingMessage(messageId) {
      const el = document.createElement("div");
      el.className = "gchat-msg assistant loading";
      el.dataset["msgId"] = messageId;
      const header = document.createElement("div");
      header.className = "gchat-msg-header";
      const roleSpan = document.createElement("span");
      roleSpan.className = "gchat-msg-role";
      roleSpan.textContent = MODELS[this.core.provider]?.label ?? "Assistant";
      header.appendChild(roleSpan);
      el.appendChild(header);
      const body = document.createElement("div");
      body.className = "gchat-msg-body";
      el.appendChild(body);
      this.messagesEl.appendChild(el);
      this.scrollToBottom();
    }
    updateStreamingMessage(messageId, content) {
      const el = this.messagesEl.querySelector(`[data-msg-id="${messageId}"]`);
      if (!el) return;
      el.classList.remove("loading");
      const body = el.querySelector(".gchat-msg-body");
      if (!body) return;
      body.innerHTML = renderMarkdown(content);
      this.addCodeCopyButtons(body);
      this.scrollToBottom();
    }
    finalizeMessage(msg) {
      const el = this.messagesEl.querySelector(`[data-msg-id="${msg.id}"]`);
      if (!el) return;
      el.classList.remove("loading");
      let actions = el.querySelector(".gchat-msg-actions");
      if (!actions) {
        actions = document.createElement("div");
        actions.className = "gchat-msg-actions";
        el.querySelector(".gchat-msg-header")?.appendChild(actions);
      }
      if (!actions.querySelector(".gchat-msg-action-btn")) {
        actions.appendChild(this.makeCopyBtn(() => msg.content));
      }
      const body = el.querySelector(".gchat-msg-body");
      if (body) {
        body.innerHTML = renderMarkdown(msg.content);
        this.addCodeCopyButtons(body);
      }
      this.scrollToBottom();
    }
    showErrorMessage(message) {
      const loading = this.messagesEl.querySelector(".gchat-msg.loading");
      const el = loading ?? document.createElement("div");
      el.classList.remove("loading");
      el.classList.add("gchat-msg", "assistant", "error");
      const body = el.querySelector(".gchat-msg-body") ?? (() => {
        const b = document.createElement("div");
        b.className = "gchat-msg-body";
        el.appendChild(b);
        return b;
      })();
      body.textContent = `Error: ${message}`;
      if (!loading) this.messagesEl.appendChild(el);
      this.scrollToBottom();
      this.toast("Error sending message");
    }
    reRenderMessages() {
      this.messagesEl.innerHTML = "";
      this.welcomeEl = null;
      for (const msg of this.core.messages) {
        this.appendMessage(msg);
      }
    }
    // ========== Welcome ==========
    showWelcome() {
      if (this.welcomeEl || this.core.messages.length > 0) return;
      const el = document.createElement("div");
      el.className = "gchat-welcome";
      const h2 = document.createElement("h2");
      h2.textContent = "Chat";
      el.appendChild(h2);
      const p = document.createElement("p");
      p.textContent = "Pick a model and start a conversation.";
      el.appendChild(p);
      const hints = this.config.welcomeHints ?? [];
      if (hints.length > 0) {
        const hintRow = document.createElement("div");
        hintRow.className = "gchat-hints";
        hints.forEach((h) => {
          const chip = document.createElement("button");
          chip.className = "gchat-hint-chip";
          chip.type = "button";
          chip.textContent = h.label;
          chip.addEventListener("click", () => {
            this.textarea.value = h.prompt;
            void this.submitMessage();
          });
          hintRow.appendChild(chip);
        });
        el.appendChild(hintRow);
      }
      this.messagesEl.appendChild(el);
      this.welcomeEl = el;
    }
    removeWelcome() {
      if (this.welcomeEl) {
        this.welcomeEl.remove();
        this.welcomeEl = null;
      }
    }
    // ========== History sidebar ==========
    renderHistory() {
      const convos = this.core.getConversations();
      this.historyEl.innerHTML = "";
      if (convos.length === 0) {
        const empty = document.createElement("p");
        empty.className = "gchat-history-empty";
        empty.textContent = "No saved conversations";
        this.historyEl.appendChild(empty);
        return;
      }
      convos.forEach((convo) => {
        const item = document.createElement("div");
        item.className = "gchat-history-item" + (convo.id === this.core.conversationId ? " active" : "");
        const title = document.createElement("span");
        title.className = "gchat-history-item-title";
        title.textContent = convo.title;
        title.title = convo.title;
        title.addEventListener("click", () => {
          if (this.core.loadConversation(convo.id)) {
            this.reRenderMessages();
            this.renderHistory();
            this.closeSidebar();
            this.providerSelect.value = this.core.provider;
            this.providerBadge.textContent = MODELS[this.core.provider].label;
            this.syspromptInput.value = this.core.systemPrompt;
          }
        });
        const del = document.createElement("button");
        del.className = "gchat-history-item-del";
        del.textContent = "\xD7";
        del.setAttribute("aria-label", `Delete "${convo.title}"`);
        del.addEventListener("click", (e) => {
          e.stopPropagation();
          this.core.deleteConversation(convo.id);
          this.renderHistory();
        });
        item.appendChild(title);
        item.appendChild(del);
        this.historyEl.appendChild(item);
      });
    }
    // ========== Code copy buttons ==========
    addCodeCopyButtons(container) {
      container.querySelectorAll("pre").forEach((pre) => {
        if (pre.querySelector(".gchat-code-copy")) return;
        const btn = document.createElement("button");
        btn.className = "gchat-code-copy";
        btn.type = "button";
        btn.textContent = "Copy";
        btn.addEventListener("click", () => {
          const code = pre.querySelector("code")?.textContent ?? pre.textContent ?? "";
          navigator.clipboard.writeText(code).then(() => {
            btn.textContent = "Copied";
            setTimeout(() => {
              btn.textContent = "Copy";
            }, 1500);
          });
        });
        pre.style.position = "relative";
        pre.appendChild(btn);
      });
    }
    // ========== Submit ==========
    async submitMessage() {
      const text = this.textarea.value.trim();
      if (!text || this.core.isStreaming) return;
      this.textarea.value = "";
      this.textarea.style.height = "auto";
      await this.core.send(text);
    }
    // ========== Helpers ==========
    makeCopyBtn(getContent) {
      const btn = document.createElement("button");
      btn.className = "gchat-msg-action-btn";
      btn.type = "button";
      btn.textContent = "Copy";
      btn.addEventListener("click", () => {
        navigator.clipboard.writeText(getContent()).then(() => this.toast("Copied"));
      });
      return btn;
    }
    autoResize() {
      this.textarea.style.height = "auto";
      this.textarea.style.height = Math.min(this.textarea.scrollHeight, 200) + "px";
    }
    scrollToBottom() {
      this.messagesEl.scrollTop = this.messagesEl.scrollHeight;
    }
    toggleSidebar() {
      const open = this.sidebar.classList.toggle("open");
      this.overlayEl.classList.toggle("visible", open);
      this.overlayEl.setAttribute("aria-hidden", open ? "false" : "true");
    }
    closeSidebar() {
      this.sidebar.classList.remove("open");
      this.overlayEl.classList.remove("visible");
      this.overlayEl.setAttribute("aria-hidden", "true");
    }
    toast(message) {
      this.toastEl.textContent = message;
      this.toastEl.classList.add("show");
      if (this.toastTimer) clearTimeout(this.toastTimer);
      this.toastTimer = setTimeout(() => this.toastEl.classList.remove("show"), 2500);
    }
    resolveTheme() {
      const t = this.config.theme ?? "auto";
      if (t === "auto") {
        try {
          return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
        } catch {
          return "light";
        }
      }
      return t;
    }
  };
  // ========== Style injection ==========
  _ChatUI.stylesInjected = false;
  var ChatUI = _ChatUI;

  exports.ChatCore = ChatCore;
  exports.ChatUI = ChatUI;
  exports.ConversationStorage = ConversationStorage;
  exports.MODELS = MODELS;
  exports.PROVIDER_KEYS = PROVIDER_KEYS;
  exports.default = ChatUI;
  exports.getProviderConfig = getProviderConfig;
  exports.isKnownProvider = isKnownProvider;

  Object.defineProperty(exports, '__esModule', { value: true });

  return exports;

})({});
//# sourceMappingURL=index.iife.global.js.map
//# sourceMappingURL=index.iife.global.js.map