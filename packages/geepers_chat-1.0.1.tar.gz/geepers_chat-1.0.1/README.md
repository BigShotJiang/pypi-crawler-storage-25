# geepers-chat

One-command multi-provider LLM chat UI. Install, run, chat.

Supports 18 providers out of the box via [geepers-kernel](https://pypi.org/project/geepers-kernel/): Anthropic, OpenAI, xAI, Mistral, Cohere, Gemini, Perplexity, Groq, HuggingFace, Ollama, and more.

## Quick start

```bash
pip install geepers-chat
export ANTHROPIC_API_KEY=sk-ant-...
python -m geepers_chat
```

Browser opens with a full chat UI. Pick a model, start chatting.

## How it works

The package runs a local Flask server that:

1. Detects which providers you have API keys for (from env vars)
2. Serves a chat interface (the [@geepers/chat](https://www.npmjs.com/package/@geepers/chat) widget)
3. Proxies your messages to provider APIs and streams responses back

No API keys leave your machine unless you're using gateway mode.

## Gateway mode

If you don't have provider keys, the package can proxy through a gateway:

```bash
export GATEWAY_API_KEY=sk_...
python -m geepers_chat --gateway
```

Default gateway: `https://api.dr.eamer.dev/v1`

## Options

```
python -m geepers_chat [options]

  --port <n>       Port (default: 3456)
  --host <addr>    Bind address (default: 127.0.0.1)
  --gateway [url]  Use gateway mode
  --no-open        Don't open browser
```

## Environment variables

Set any of these to enable direct provider access:

| Variable | Provider |
|----------|----------|
| `ANTHROPIC_API_KEY` | Anthropic (Claude) |
| `OPENAI_API_KEY` | OpenAI (GPT) |
| `XAI_API_KEY` | xAI (Grok) |
| `MISTRAL_API_KEY` | Mistral |
| `COHERE_API_KEY` | Cohere |
| `GEMINI_API_KEY` | Google Gemini |
| `PERPLEXITY_API_KEY` | Perplexity |
| `GROQ_API_KEY` | Groq |
| `HF_API_KEY` | HuggingFace |
| *(none needed)* | Ollama (auto-detected if running locally) |

## License

MIT — [Luke Steuber](https://lukesteuber.com)
