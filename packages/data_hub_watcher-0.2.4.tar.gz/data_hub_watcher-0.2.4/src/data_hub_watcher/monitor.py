"""File monitoring with watchdog and stability detection.

`FileMonitor` watches a directory for new/modified files, filters them
by glob patterns, waits for each file to become "stable" (size + mtime
unchanged for the configured period), then invokes a callback.
"""

from __future__ import annotations
import fnmatch
import logging
import os
import threading
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path

from watchdog.events import (
    FileCreatedEvent,
    FileModifiedEvent,
    FileSystemEvent,
    FileSystemEventHandler,
)
from watchdog.observers import Observer

from data_hub_watcher.constants import MAX_STABILITY_WAIT_SECONDS
from data_hub_watcher.events import EventReporter
from data_hub_watcher.state import StateDB

logger = logging.getLogger(__name__)


@dataclass
class _PendingFile:
    """Tracks a file waiting to become stable."""

    path: Path
    size: int
    mtime: float
    first_seen: float = field(default_factory=time.monotonic)
    last_changed: float = field(default_factory=time.monotonic)


class _EventHandler(FileSystemEventHandler):
    """Watchdog handler that forwards matching create/modify events."""

    def __init__(
        self,
        file_patterns: list[str],
        on_event: Callable[[Path], None],
        recursive: bool,
    ) -> None:
        super().__init__()
        self._patterns = file_patterns
        self._on_event = on_event
        self._recursive = recursive

    def _matches(self, path: Path) -> bool:
        return any(fnmatch.fnmatch(path.name, pat) for pat in self._patterns)

    def on_created(self, event: FileSystemEvent) -> None:
        if isinstance(event, FileCreatedEvent) and not event.is_directory:
            p = Path(str(event.src_path))
            if self._matches(p):
                self._on_event(p)

    def on_modified(self, event: FileSystemEvent) -> None:
        if isinstance(event, FileModifiedEvent) and not event.is_directory:
            p = Path(str(event.src_path))
            if self._matches(p):
                self._on_event(p)


class FileMonitor:
    """Watches a directory, detects stable files, and invokes a callback.

    Parameters
    ----------
    watch_directory:
        Top-level directory to monitor.
    file_patterns:
        Glob patterns (e.g. `["*.csv", "*.txt"]`) matched against filenames.
    stability_period:
        Seconds a file's size + mtime must remain unchanged before it is
        considered stable.
    on_stable_file:
        Called with the `Path` of each stable file.
    state_db:
        Used to skip files that have already been uploaded.
    recursive:
        Whether to monitor subdirectories (`True` for directory-mode run
        detection, `False` otherwise).
    """

    def __init__(
        self,
        watch_directory: Path,
        file_patterns: list[str],
        stability_period: int,
        on_stable_file: Callable[[Path], None],
        state_db: StateDB,
        recursive: bool = False,
        event_reporter: EventReporter | None = None,
    ) -> None:
        self._watch_dir = watch_directory
        self._patterns = file_patterns
        self._stability_period = stability_period
        self._on_stable = on_stable_file
        self._state_db = state_db
        self._recursive = recursive
        # Optional so unit tests that build a FileMonitor in isolation
        # don't have to construct a full reporter graph. In production
        # the reporter is always wired by ``runtime.build_runtime``.
        self._reporter = event_reporter

        self._pending: dict[Path, _PendingFile] = {}
        self._lock = threading.Lock()

        self._observer = Observer()
        self._checker_stop = threading.Event()
        self._checker_thread: threading.Thread | None = None

    # ------------------------------------------------------------------
    # public API
    # ------------------------------------------------------------------

    def start(self) -> None:
        """Run the initial scan, start the watchdog observer, and begin the stability checker."""
        self._initial_scan()

        handler = _EventHandler(self._patterns, self._enqueue, self._recursive)
        self._observer.schedule(handler, str(self._watch_dir), recursive=self._recursive)
        self._observer.start()

        self._checker_stop.clear()
        self._checker_thread = threading.Thread(
            target=self._stability_loop, daemon=True, name="stability-checker"
        )
        self._checker_thread.start()
        logger.info(
            "FileMonitor started (dir=%s, patterns=%s, recursive=%s)",
            self._watch_dir,
            self._patterns,
            self._recursive,
        )

    def stop(self) -> None:
        """Stop the observer and stability-checker thread."""
        self._checker_stop.set()
        self._observer.stop()
        self._observer.join(timeout=5)
        if self._checker_thread and self._checker_thread.is_alive():
            self._checker_thread.join(timeout=5)
        logger.info("FileMonitor stopped")

    # ------------------------------------------------------------------
    # initial scan
    # ------------------------------------------------------------------

    def _initial_scan(self) -> None:
        """Walk the directory for existing files and enqueue unuploaded ones.

        This catches files that appeared while the watcher was stopped (e.g.
        between a crash and restart, or overnight when running as a service).

        Identity for "already uploaded" is `(relative_path, size, mtime)` —
        a cheap `stat()` rather than a full-content SHA-256. The path is
        relative to the watch directory, so same-named files in different
        subdirectories don't collide. For write-once instrument output this
        is a safe and much faster heuristic. The uploader still computes a
        real SHA-256 on its way out, so content integrity is not
        compromised. See also: `StateDB.has_stat_match`.

        In addition to `uploaded_files`, files recorded in `detected_files`
        (i.e. already part of a reported run's manifest) are also skipped.
        This matters in manual mode where the uploader never runs locally
        and `uploaded_files` stays empty — without this, every restart
        would re-POST / PATCH the full manifest.
        See also: `StateDB.has_detected_stat_match`.
        """
        logger.info(
            "Initial scan starting (dir=%s, patterns=%s, recursive=%s)…",
            self._watch_dir,
            self._patterns,
            self._recursive,
        )
        iterator = self._watch_dir.rglob("*") if self._recursive else self._watch_dir.iterdir()
        total = 0
        queued = 0
        skipped = 0
        for entry in iterator:
            if not entry.is_file():
                continue
            if not any(fnmatch.fnmatch(entry.name, pat) for pat in self._patterns):
                continue
            total += 1
            try:
                st = entry.stat()
            except OSError:
                continue
            try:
                rel_path = entry.relative_to(self._watch_dir).as_posix()
            except ValueError:
                # Symlinks or oddities outside the watch dir: fall back to
                # basename so the lookup degrades gracefully instead of
                # raising.
                rel_path = entry.name
            if self._state_db.has_stat_match(
                rel_path, st.st_size, st.st_mtime
            ) or self._state_db.has_detected_stat_match(rel_path, st.st_size, st.st_mtime):
                skipped += 1
                continue
            # Pass `st` through so `_enqueue` doesn't issue a redundant
            # stat() syscall — halves the stat cost on initial scans of
            # large directories.
            self._enqueue(entry, stat_result=st)
            queued += 1
            if total % 100 == 0:
                logger.info(
                    "Initial scan progress: %d scanned, %d queued, %d skipped",
                    total,
                    queued,
                    skipped,
                )

        logger.info(
            "Initial scan complete: %d scanned, %d queued, %d skipped",
            total,
            queued,
            skipped,
        )

    # ------------------------------------------------------------------
    # stability tracking
    # ------------------------------------------------------------------

    def _enqueue(self, path: Path, *, stat_result: os.stat_result | None = None) -> None:
        """Add or refresh a file in the pending-stability dict.

        *stat_result* lets callers that already hold a fresh `stat()`
        (notably `_initial_scan`) avoid a redundant syscall. Watchdog
        event callbacks don't have one and pass `None`.
        """
        if stat_result is None:
            try:
                stat_result = path.stat()
            except OSError:
                return
        with self._lock:
            existing = self._pending.get(path)
            if existing is None:
                self._pending[path] = _PendingFile(
                    path=path, size=stat_result.st_size, mtime=stat_result.st_mtime
                )
            else:
                if stat_result.st_size != existing.size or stat_result.st_mtime != existing.mtime:
                    existing.size = stat_result.st_size
                    existing.mtime = stat_result.st_mtime
                    existing.last_changed = time.monotonic()

    def _stability_loop(self) -> None:
        """Periodically check pending files for stability or timeout."""
        while not self._checker_stop.wait(timeout=1.0):
            self._check_pending()

    def _check_pending(self) -> None:
        """Poll each pending file's size + mtime against its last-known values.

        A file is "stable" when its size and mtime haven't changed for the full
        stability period.  If the file keeps changing beyond
        MAX_STABILITY_WAIT_SECONDS it is abandoned — this guards against files
        that are continuously appended to (e.g. active log streams).
        """
        now = time.monotonic()
        stable: list[Path] = []
        timed_out: list[Path] = []

        with self._lock:
            for path, pf in list(self._pending.items()):
                try:
                    stat = path.stat()
                except OSError:
                    del self._pending[path]
                    continue

                if stat.st_size != pf.size or stat.st_mtime != pf.mtime:
                    pf.size = stat.st_size
                    pf.mtime = stat.st_mtime
                    pf.last_changed = now
                    continue

                elapsed_since_change = now - pf.last_changed
                if elapsed_since_change >= self._stability_period:
                    stable.append(path)
                    del self._pending[path]
                elif (now - pf.first_seen) >= MAX_STABILITY_WAIT_SECONDS:
                    timed_out.append(path)
                    del self._pending[path]

        for path in timed_out:
            logger.error(
                "File %s did not stabilise within %ds — skipping",
                path,
                MAX_STABILITY_WAIT_SECONDS,
            )
            if self._reporter is not None:
                self._reporter.report_error(
                    "stability_timeout",
                    f"File {path.name} did not stabilise within {MAX_STABILITY_WAIT_SECONDS}s",
                    path=str(path),
                    max_wait_seconds=MAX_STABILITY_WAIT_SECONDS,
                )

        for path in stable:
            logger.info("File stable: %s", path)
            try:
                self._on_stable(path)
            except Exception as exc:
                logger.exception("Callback failed for %s", path)
                if self._reporter is not None:
                    self._reporter.report_error(
                        "stable_callback_failed",
                        f"Stable-file callback failed for {path.name}: {exc}",
                        path=str(path),
                        error=str(exc),
                    )
