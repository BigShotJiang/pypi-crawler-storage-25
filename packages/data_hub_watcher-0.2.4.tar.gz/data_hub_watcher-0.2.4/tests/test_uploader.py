"""Unit tests for the presigned-URL upload flow in Uploader."""

from __future__ import annotations
from collections.abc import Generator
from pathlib import Path
from typing import cast
from unittest.mock import MagicMock, patch

import pytest

from data_hub_watcher.api_client import ApiError
from data_hub_watcher.events import EventReporter
from data_hub_watcher.heartbeat import WatcherCounters
from data_hub_watcher.models import PresignedUploadResponse
from data_hub_watcher.state import StateDB
from data_hub_watcher.uploader import Uploader


@pytest.fixture()
def tmp_file(tmp_path: Path) -> Path:
    f = tmp_path / "test_data.csv"
    f.write_text("a,b,c\n1,2,3\n")
    return f


@pytest.fixture()
def mock_client() -> MagicMock:
    return MagicMock()


@pytest.fixture()
def state_db(tmp_path: Path) -> Generator[StateDB, None, None]:
    db = StateDB(tmp_path / "test.db")
    yield db
    db.close()


@pytest.fixture()
def uploader(mock_client: MagicMock, state_db: StateDB, tmp_path: Path) -> Uploader:
    return Uploader(
        client=mock_client,
        state_db=state_db,
        event_reporter=MagicMock(spec=EventReporter),
        counters=WatcherCounters(),
        instrument_id="test-instrument",
        watcher_id="watcher-123",
        watch_directory=tmp_path,
    )


class TestUploadSingle:
    def test_successful_upload(
        self,
        uploader: Uploader,
        mock_client: MagicMock,
        tmp_file: Path,
        state_db: StateDB,
    ) -> None:
        mock_client.request_upload_url.return_value = PresignedUploadResponse(
            upload_url="https://s3.example.com/presigned",
            s3_bucket="test-bucket",
            s3_key="test-instrument/RUN-001/test_data.csv",
            file_id=42,
            expires_in=3600,
            already_uploaded=False,
        )
        mock_client.mark_file_uploaded.return_value = MagicMock()

        with patch.object(Uploader, "_put_to_presigned_url") as mock_put:
            result = uploader._upload_single(tmp_file, "RUN-001")

        assert result is True
        mock_put.assert_called_once()
        mock_client.mark_file_uploaded.assert_called_once_with(
            42,
            {
                "s3_bucket": "test-bucket",
                "s3_key": "test-instrument/RUN-001/test_data.csv",
                "content_type": "text/csv",
                "status": "uploaded",
            },
        )
        assert uploader._counters.files_uploaded == 1

        # Stat columns must be populated (keyed on the watch-dir-relative
        # path) so subsequent initial scans can skip this file without
        # re-hashing its contents.
        st = tmp_file.stat()
        rel_path = tmp_file.relative_to(uploader._watch_dir).as_posix()
        assert state_db.has_stat_match(rel_path, st.st_size, st.st_mtime) is True

        # request_upload_url is invoked with the on-disk creation time so
        # the API can persist files.file_created_at.
        kwargs = mock_client.request_upload_url.call_args.kwargs
        assert "file_created_at_ts" in kwargs
        assert kwargs["file_created_at_ts"] > 0

    def test_already_uploaded_skips(
        self,
        uploader: Uploader,
        mock_client: MagicMock,
        tmp_file: Path,
    ) -> None:
        mock_client.request_upload_url.return_value = PresignedUploadResponse(
            upload_url="",
            s3_bucket="test-bucket",
            s3_key="test-instrument/RUN-001/test_data.csv",
            file_id=42,
            expires_in=3600,
            already_uploaded=True,
        )

        with patch.object(Uploader, "_put_to_presigned_url") as mock_put:
            result = uploader._upload_single(tmp_file, "RUN-001")

        assert result is True
        mock_put.assert_not_called()
        mock_client.mark_file_uploaded.assert_not_called()

    def test_presigned_url_request_failure(
        self,
        uploader: Uploader,
        mock_client: MagicMock,
        tmp_file: Path,
    ) -> None:
        mock_client.request_upload_url.side_effect = ApiError("Server error", status_code=500)

        result = uploader._upload_single(tmp_file, "RUN-001")

        assert result is False
        assert uploader._counters.errors == 1

    def test_put_failure_retries_then_fails(
        self,
        uploader: Uploader,
        mock_client: MagicMock,
        tmp_file: Path,
    ) -> None:
        mock_client.request_upload_url.return_value = PresignedUploadResponse(
            upload_url="https://s3.example.com/presigned",
            s3_bucket="test-bucket",
            s3_key="test-instrument/RUN-001/test_data.csv",
            file_id=42,
            expires_in=3600,
            already_uploaded=False,
        )

        with (
            patch.object(
                Uploader, "_put_to_presigned_url", side_effect=ConnectionError("network down")
            ),
            patch("data_hub_watcher.uploader.time.sleep"),
        ):
            result = uploader._upload_single(tmp_file, "RUN-001")

        assert result is False
        assert uploader._counters.errors == 1
        mock_client.mark_file_uploaded.assert_not_called()

    def test_mark_uploaded_failure(
        self,
        uploader: Uploader,
        mock_client: MagicMock,
        tmp_file: Path,
    ) -> None:
        mock_client.request_upload_url.return_value = PresignedUploadResponse(
            upload_url="https://s3.example.com/presigned",
            s3_bucket="test-bucket",
            s3_key="test-instrument/RUN-001/test_data.csv",
            file_id=42,
            expires_in=3600,
            already_uploaded=False,
        )
        mock_client.mark_file_uploaded.side_effect = ApiError("Server error", status_code=500)

        with patch.object(Uploader, "_put_to_presigned_url"):
            result = uploader._upload_single(tmp_file, "RUN-001")

        assert result is False
        assert uploader._counters.errors == 1


class TestUploadQueuePollFailures:
    """Manual-mode upload-queue poll failures must be visible in the dashboard.

    Today the failure only bumps an opaque counter, so a sustained
    ACL/network outage looks identical to a healthy queue. The fix
    surfaces a ``kind=upload_queue_poll_failed`` event on the 1st
    failure and every 10th repeat. Throttling matters because the
    poll fires every heartbeat (~60 s) — without it a half-day outage
    would emit 720 events.
    """

    def test_emits_on_first_and_every_tenth_failure(
        self, uploader: Uploader, mock_client: MagicMock
    ) -> None:
        mock_client.get_upload_queue.side_effect = ApiError("ACL", status_code=403)

        # 25 failures: events emitted at attempts 1, 10, 20.
        for _ in range(25):
            uploader.poll_upload_queue()

        reporter_mock = cast(MagicMock, uploader._reporter)
        kinds = [c.args[0] for c in reporter_mock.report_error.call_args_list]
        assert kinds.count("upload_queue_poll_failed") == 3
        # And the consecutive-failure count is reported correctly.
        consec = [
            c.kwargs["consecutive_failures"]
            for c in reporter_mock.report_error.call_args_list
            if c.args[0] == "upload_queue_poll_failed"
        ]
        assert consec == [1, 10, 20]

    def test_recovery_resets_counter(self, uploader: Uploader, mock_client: MagicMock) -> None:
        from data_hub_watcher.models import UploadQueueResponse

        mock_client.get_upload_queue.side_effect = [
            ApiError("ACL", status_code=403),
            UploadQueueResponse(files=[]),
            ApiError("ACL", status_code=403),
        ]

        uploader.poll_upload_queue()  # fail 1 -> emits
        uploader.poll_upload_queue()  # success -> resets counter
        uploader.poll_upload_queue()  # fail again, treated as 1st of new outage -> emits

        reporter_mock = cast(MagicMock, uploader._reporter)
        consec = [
            c.kwargs["consecutive_failures"]
            for c in reporter_mock.report_error.call_args_list
            if c.args[0] == "upload_queue_poll_failed"
        ]
        assert consec == [1, 1]


class TestPutToPresignedUrl:
    def test_successful_put(self, tmp_file: Path) -> None:
        with patch("data_hub_watcher.uploader.http_requests.put") as mock_put:
            mock_put.return_value = MagicMock(status_code=200)
            mock_put.return_value.raise_for_status = MagicMock()

            Uploader._put_to_presigned_url("https://s3.example.com/presigned", tmp_file, "text/csv")

        mock_put.assert_called_once()
        call_kwargs = mock_put.call_args
        assert call_kwargs.kwargs["headers"]["Content-Type"] == "text/csv"
        assert call_kwargs.kwargs["timeout"] == 300
