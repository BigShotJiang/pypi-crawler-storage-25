<a href="https://explosion.ai"><img src="https://explosion.ai/assets/img/logo.svg" width="125" height="125" align="right" /></a>

# Ellf PAM SDK

The `models.py` is auto-generated using the OpenAPI spec and [`datamodel-code-generator`](https://koxudaxi.github.io/datamodel-code-generator/). To generate the SDK, make sure you have all requirements installed and run the following from the project root directory:

```bash
pdcli dev generate-sdks --sdks pam,app
```
