from __future__ import annotations

from datetime import datetime
from typing import cast
from uuid import UUID

from pydantic import BaseModel, Field

from .base import BaseClient


class ProjectPlanSummary(BaseModel):
    id: UUID
    project_id: UUID
    name: str
    created: datetime
    updated: datetime


class ProjectPlanDetail(BaseModel):
    id: UUID
    project_id: UUID
    name: str
    content: str
    created: datetime
    updated: datetime


class _ProjectPlanListResponse(BaseModel):
    items: list[ProjectPlanSummary] = Field(default_factory=list)


class ProjectPlan(BaseClient):
    def list(self, project_id: UUID) -> list[ProjectPlanSummary]:
        # The list endpoint lives at /api/v1/project-plans/list (plural)
        result = self.request(
            "POST",
            endpoint="/api/v1/project-plans/list",
            data={"project_id": str(project_id)},
            return_model=_ProjectPlanListResponse,
        )
        return cast(_ProjectPlanListResponse, result).items

    def read(
        self,
        *,
        id: UUID | None = None,
        project_id: UUID | None = None,
        name: str | None = None,
    ) -> ProjectPlanDetail | None:
        body: dict = {}
        if id is not None:
            body["id"] = str(id)
        if project_id is not None:
            body["project_id"] = str(project_id)
        if name is not None:
            body["name"] = name
        from .. import errors

        try:
            result = self.request(
                "POST",
                endpoint="read",
                data=body,
                return_model=ProjectPlanDetail,
            )
            return cast(ProjectPlanDetail, result)
        except errors.NotFound:
            return None

    def upsert(
        self,
        project_id: UUID,
        name: str = "project_plan",
        *,
        content: str,
    ) -> ProjectPlanDetail:
        result = self.request(
            "POST",
            endpoint="upsert",
            data={"project_id": str(project_id), "name": name, "content": content},
            return_model=ProjectPlanDetail,
        )
        return cast(ProjectPlanDetail, result)

    def delete(
        self,
        *,
        id: UUID | None = None,
        project_id: UUID | None = None,
        name: str | None = None,
    ) -> None:
        body: dict = {}
        if id is not None:
            body["id"] = str(id)
        if project_id is not None:
            body["project_id"] = str(project_id)
        if name is not None:
            body["name"] = name
        self.request("POST", endpoint="delete", data=body)
