from ..models import (
    TodoCreating,
    TodoDeleting,
    TodoDetail,
    TodoReading,
    TodoSummary,
    TodoUpdating,
)
from .base import ModelClient


class Todo(
    ModelClient[
        TodoCreating,
        TodoReading,
        TodoUpdating,
        TodoDeleting,
        TodoSummary,
        TodoDetail,
    ]
):
    Creating = TodoCreating
    Reading = TodoReading
    Updating = TodoUpdating
    Deleting = TodoDeleting
    Summary = TodoSummary
    Detail = TodoDetail
