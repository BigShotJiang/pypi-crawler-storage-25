from ..models import (
    ConversationCreating,
    ConversationDeleting,
    ConversationDetail,
    ConversationReading,
    ConversationSummary,
    ConversationUpdating,
)
from .base import ModelClient


class Conversation(
    ModelClient[
        ConversationCreating,
        ConversationReading,
        ConversationUpdating,
        ConversationDeleting,
        ConversationSummary,
        ConversationDetail,
    ]
):
    Creating = ConversationCreating
    Reading = ConversationReading
    Updating = ConversationUpdating
    Deleting = ConversationDeleting
    Summary = ConversationSummary
    Detail = ConversationDetail
