from ..models import (
    ConversationMessageCreating,
    ConversationMessageDetail,
    ConversationMessageReading,
    ConversationMessageSummary,
)
from .base import ModelClient


# ConversationMessage has no Updating schema (messages are immutable),
# but ModelClient requires one.  We reuse Creating as a placeholder.
class ConversationMessage(
    ModelClient[
        ConversationMessageCreating,
        ConversationMessageReading,
        ConversationMessageCreating,  # no updates
        ConversationMessageCreating,
        ConversationMessageSummary,
        ConversationMessageDetail,
    ]
):
    Creating = ConversationMessageCreating
    Reading = ConversationMessageReading
    Updating = ConversationMessageCreating  # not used
    Deleting = ConversationMessageCreating
    Summary = ConversationMessageSummary
    Detail = ConversationMessageDetail
