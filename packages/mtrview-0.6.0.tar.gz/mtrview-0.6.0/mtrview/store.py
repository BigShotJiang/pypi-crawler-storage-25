from __future__ import annotations

import json
import logging
import threading
from datetime import UTC, datetime
from typing import Any

from mtrview.config import Settings
from mtrview.models import ReadingView
from mtrview.normalization import normalize_summary

LOGGER = logging.getLogger(__name__)

READING_FIELDS = ("description", "location", "measured_at", "quantity", "unit", "value", "zone")


class SummaryStore:
    def __init__(self, settings: Settings) -> None:
        self._settings = settings
        self._lock = threading.RLock()
        self._raw_by_receiver: dict[str, dict[str, Any]] = {}
        self._last_message_at: datetime | None = None

    def update_from_json(self, receiver_hint: str, payload: bytes | str) -> None:
        payload_size = _payload_size(payload)
        if payload_size > self._settings.mqtt_max_payload_bytes:
            LOGGER.warning(
                "Ignoring MQTT summary payload for %s: %s bytes exceeds limit of %s",
                receiver_hint,
                payload_size,
                self._settings.mqtt_max_payload_bytes,
            )
            return

        try:
            decoded = payload.decode("utf-8") if isinstance(payload, bytes) else payload
            data = json.loads(decoded)
        except (UnicodeDecodeError, json.JSONDecodeError):
            LOGGER.exception("Failed to decode MQTT summary payload for %s", receiver_hint)
            return

        if not isinstance(data, dict):
            LOGGER.warning("Ignoring non-object MQTT summary payload for %s", receiver_hint)
            return

        receiver = str(data.get("receiver") or receiver_hint or "unknown")
        if _has_overlong_string(data, self._settings.mqtt_max_field_length):
            LOGGER.warning(
                "Ignoring MQTT summary payload for %s: string field exceeds limit of %s",
                receiver,
                self._settings.mqtt_max_field_length,
            )
            return

        transmitters = data.get("transmitters")
        if (
            isinstance(transmitters, dict)
            and len(transmitters) > self._settings.mqtt_max_transmitters_per_summary
        ):
            LOGGER.warning(
                "Ignoring MQTT summary payload for %s: %s transmitters exceeds limit of %s",
                receiver,
                len(transmitters),
                self._settings.mqtt_max_transmitters_per_summary,
            )
            return

        with self._lock:
            if (
                receiver not in self._raw_by_receiver
                and len(self._raw_by_receiver) >= self._settings.mqtt_max_receivers
            ):
                LOGGER.warning(
                    "Ignoring MQTT summary payload for %s: receiver limit of %s reached",
                    receiver,
                    self._settings.mqtt_max_receivers,
                )
                return

            previous = self._raw_by_receiver.get(receiver)
            self._raw_by_receiver[receiver] = _merge_summary(previous, data)
            self._last_message_at = datetime.now(UTC)

    def readings(self, now: datetime | None = None) -> list[ReadingView]:
        now = now or datetime.now(UTC)
        with self._lock:
            snapshots = list(self._raw_by_receiver.items())
        readings: list[ReadingView] = []
        for receiver, payload in snapshots:
            readings.extend(normalize_summary(receiver, payload, self._settings, now=now))
        return sorted(readings, key=lambda item: item.sort_key)

    def snapshot(self) -> dict[str, object]:
        readings = self.readings()
        receivers = sorted({reading.receiver for reading in readings})
        zones = sorted({reading.zone for reading in readings})
        counts = _counts(readings, len(receivers))
        return {
            "generated_at": datetime.now(UTC).isoformat().replace("+00:00", "Z"),
            "last_message_at": self.last_message_at,
            "mqtt": {"last_message_at": self.last_message_at},
            "counts": counts,
            "receivers": receivers,
            "zones": zones,
            "readings": [reading.to_dict() for reading in readings],
        }

    @property
    def last_message_at(self) -> str | None:
        with self._lock:
            if self._last_message_at is None:
                return None
            return self._last_message_at.isoformat().replace("+00:00", "Z")


def _counts(readings: list[ReadingView], receiver_count: int) -> dict[str, int]:
    return {
        "total": len(readings),
        "online": sum(1 for reading in readings if reading.status == "online"),
        "offline": sum(1 for reading in readings if reading.status != "online"),
        "receivers": receiver_count,
    }


def _merge_summary(previous: dict[str, Any] | None, incoming: dict[str, Any]) -> dict[str, Any]:
    if previous is None:
        return incoming

    previous_transmitters = previous.get("transmitters")
    incoming_transmitters = incoming.get("transmitters")
    if not isinstance(previous_transmitters, dict) or not isinstance(incoming_transmitters, dict):
        return incoming

    merged = dict(incoming)
    merged_transmitters = dict(incoming_transmitters)
    for transmitter_id, incoming_reading in incoming_transmitters.items():
        if not isinstance(incoming_reading, dict) or _has_reading(incoming_reading):
            continue

        previous_reading = previous_transmitters.get(transmitter_id)
        if not isinstance(previous_reading, dict) or not _has_reading(previous_reading):
            continue

        preserved_reading = dict(incoming_reading)
        for key in READING_FIELDS:
            if key in previous_reading:
                preserved_reading[key] = previous_reading[key]
        merged_transmitters[transmitter_id] = preserved_reading

    merged["transmitters"] = merged_transmitters
    return merged


def _has_reading(raw: dict[str, Any]) -> bool:
    value = raw.get("value")
    return value is not None and value != ""


def _payload_size(payload: bytes | str) -> int:
    if isinstance(payload, bytes):
        return len(payload)
    return len(payload.encode("utf-8"))


def _has_overlong_string(value: Any, max_length: int) -> bool:
    if isinstance(value, str):
        return len(value) > max_length
    if isinstance(value, dict):
        return any(
            _has_overlong_string(key, max_length) or _has_overlong_string(item, max_length)
            for key, item in value.items()
        )
    if isinstance(value, list):
        return any(_has_overlong_string(item, max_length) for item in value)
    return False
