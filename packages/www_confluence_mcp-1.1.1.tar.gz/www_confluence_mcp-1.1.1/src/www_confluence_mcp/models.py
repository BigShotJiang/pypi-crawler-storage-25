"""Pydantic models for Confluence Markdown converter and API responses."""

from __future__ import annotations

from typing import Any, Optional

from pydantic import BaseModel, ConfigDict, Field


class ConfluenceMarkdownMeta(BaseModel):
    """Metadata for Markdown from YAML frontmatter.

    Attributes:
        pageId: Confluence page ID.
        space: Space key.
        title: Page title.
        version: Page version number.
        last_updated: Last update timestamp.
        url: Page URL.
    """

    pageId: str = Field(..., description="Confluence page ID")
    space: str = Field(..., description="Space key")
    title: str = Field("", description="Page title")
    version: int = Field(1, description="Page version number")
    last_updated: str = Field("", description="Last update timestamp")
    url: str = Field("", description="Page URL")


class ConfluenceMarkdownDocument(BaseModel):
    """Structure of a Markdown document.

    Attributes:
        confluence: Metadata about the Confluence page.
        format: Document format identifier.
        conversion_timestamp: Timestamp of conversion.
    """

    confluence: ConfluenceMarkdownMeta
    format: str = Field("confluence_markdown")
    conversion_timestamp: str = Field("")

    model_config = ConfigDict(extra="allow", coerce_numbers_to_str=True)


class ConversionResult(BaseModel):
    """Result of a conversion operation.

    Attributes:
        status: Conversion status (ok or error).
        page_id: Confluence page ID.
        title: Page title.
        format: Output format.
        file_path: Path to the converted file.
        elements_preserved: Number of preserved Confluence elements.
        warnings: List of conversion warnings.
        error: Error message if conversion failed.
    """

    status: str = Field(..., description="ok or error")
    page_id: str = Field("")
    title: str = Field("")
    format: str = Field("")
    file_path: str = Field("")
    elements_preserved: int = Field(
        0, description="Number of preserved Confluence elements"
    )
    warnings: list[str] = Field(default_factory=list)
    error: Optional[str] = None


class ConfluenceMacroPreserved(BaseModel):
    """A preserved Confluence macro during conversion.

    Attributes:
        name: Macro name.
        schema_version: Schema version identifier.
        macro_id: Unique macro identifier.
        parameters: Macro parameters as key-value pairs.
        body_preview: First 200 characters of macro body.
        original_html: Full original HTML for round-trip conversion.
    """

    name: str = Field(..., description="Macro name")
    schema_version: str = Field("")
    macro_id: str = Field("")
    parameters: dict[str, str] = Field(default_factory=dict)
    body_preview: str = Field("", description="First 200 chars of body")
    original_html: str = Field("", description="Full original HTML for round-trip")


class PageData(BaseModel):
    """Page data from Confluence API.

    Attributes:
        id: Page ID.
        title: Page title.
        type: Page type (default: "page").
        status: Page status (default: "current").
        space_key: Space key.
        version_number: Version number.
        version_when: Version timestamp.
        body_storage: Body content in storage format.
    """

    id: str = Field("", description="Page ID")
    title: str = Field("", description="Page title")
    type: str = Field("page", description="Page type")
    status: str = Field("current", description="Page status")
    space_key: str = Field("", description="Space key")
    version_number: int = Field(1, description="Version number")
    version_when: str = Field("", description="Version timestamp")
    body_storage: str = Field("", description="Body content in storage format")

    model_config = ConfigDict(extra="allow", coerce_numbers_to_str=True)


# =============================================================================
# Core Confluence API Response Models
# =============================================================================


class User(BaseModel):
    """Confluence user model.

    Attributes:
        username: User's username/account ID.
        displayName: User's display name.
        email: User's email address (may be empty if not visible).
        profile_picture: URL to user's profile picture.
        links: Link relations for the user resource.
    """

    username: str = Field("", description="User's username/account ID")
    displayName: str = Field("", description="User's display name")
    email: Optional[str] = Field(None, description="User's email address")
    profile_picture: Optional[str] = Field(None, description="Profile picture URL")
    links: dict[str, Any] = Field(
        default_factory=dict, description="Link relations", alias="_links"
    )

    model_config = ConfigDict(extra="allow", coerce_numbers_to_str=True)


class Space(BaseModel):
    """Confluence space model.

    Attributes:
        id: Space ID.
        key: Space key (e.g., 'DEV', 'PROJ').
        name: Space name.
        description: Space description (may be empty).
        type: Space type (e.g., 'global', 'personal').
        status: Space status (e.g., 'current', 'archived').
        links: Link relations for the space resource.
    """

    id: str = Field("", description="Space ID")
    key: str = Field("", description="Space key")
    name: str = Field("", description="Space name")
    description: Optional[str] = Field(None, description="Space description")
    type: str = Field("global", description="Space type")
    status: str = Field("current", description="Space status")
    links: dict[str, Any] = Field(
        default_factory=dict, description="Link relations", alias="_links"
    )

    model_config = ConfigDict(extra="allow", coerce_numbers_to_str=True)


class Version(BaseModel):
    """Confluence version model for content versioning.

    Attributes:
        number: Version number.
        when: Timestamp of when this version was created.
        message: Version change message.
        by: User who made this version.
    """

    number: int = Field(1, description="Version number")
    when: str = Field("", description="Version timestamp")
    message: Optional[str] = Field(None, description="Version change message")
    by: Optional[User] = Field(None, description="User who made this version")

    model_config = ConfigDict(extra="allow", coerce_numbers_to_str=True)


class Attachment(BaseModel):
    """Confluence attachment model.

    Attributes:
        id: Attachment ID.
        title: Attachment title/filename.
        type: Content type (e.g., 'attachment').
        status: Attachment status.
        mediaType: MIME type of the attachment.
        filename: Original filename.
        fileSize: File size in bytes.
        extensions: Extension metadata (mediaType, fileSize, etc.).
        version: Version information.
        links: Link relations including download URL.
    """

    id: str = Field("", description="Attachment ID")
    title: str = Field("", description="Attachment title/filename")
    type: str = Field("attachment", description="Content type")
    status: str = Field("current", description="Attachment status")
    mediaType: Optional[str] = Field(None, description="MIME type")
    filename: Optional[str] = Field(None, description="Original filename")
    fileSize: Optional[int] = Field(None, description="File size in bytes")
    extensions: dict[str, Any] = Field(
        default_factory=dict, description="Extension metadata"
    )
    version: Optional[Version] = Field(None, description="Version information")
    links: dict[str, Any] = Field(
        default_factory=dict, description="Link relations", alias="_links"
    )

    model_config = ConfigDict(extra="allow", coerce_numbers_to_str=True)


class Comment(BaseModel):
    """Confluence comment model.

    Attributes:
        id: Comment ID.
        title: Comment title (may be empty for comments).
        type: Content type (e.g., 'comment').
        status: Comment status.
        body: Comment body content (may contain 'storage', 'view', etc.).
        version: Version information.
        container: Parent container (page or comment being replied to).
        author: Comment author.
        links: Link relations for the comment.
    """

    id: str = Field("", description="Comment ID")
    title: str = Field("", description="Comment title")
    type: str = Field("comment", description="Content type")
    status: str = Field("current", description="Comment status")
    body: dict[str, Any] = Field(default_factory=dict, description="Comment body")
    version: Optional[Version] = Field(None, description="Version information")
    container: dict[str, Any] = Field(
        default_factory=dict, description="Parent container"
    )
    author: Optional[User] = Field(None, description="Comment author")
    links: dict[str, Any] = Field(
        default_factory=dict, description="Link relations", alias="_links"
    )

    model_config = ConfigDict(extra="allow", coerce_numbers_to_str=True)


class Page(BaseModel):
    """Confluence page model.

    Attributes:
        id: Page ID.
        title: Page title.
        type: Content type (e.g., 'page', 'blogpost').
        status: Page status (e.g., 'current', 'draft', 'archived').
        space: Space information.
        version: Version information.
        body: Page body content (may contain 'storage', 'view', 'export_view', etc.).
        ancestors: List of ancestor pages (breadcrumb).
        children: Child pages/attachments/comments info.
        descendants: Descendant count/info.
        history: History metadata.
        links: Link relations for the page.
    """

    id: str = Field("", description="Page ID")
    title: str = Field("", description="Page title")
    type: str = Field("page", description="Content type")
    status: str = Field("current", description="Page status")
    space: Optional[Space] = Field(None, description="Space information")
    version: Optional[Version] = Field(None, description="Version information")
    body: dict[str, Any] = Field(default_factory=dict, description="Page body content")
    ancestors: list[dict[str, Any]] = Field(
        default_factory=list, description="Ancestor pages"
    )
    children: dict[str, Any] = Field(
        default_factory=dict, description="Child content info"
    )
    descendants: dict[str, Any] = Field(
        default_factory=dict, description="Descendant info"
    )
    history: dict[str, Any] = Field(
        default_factory=dict, description="History metadata"
    )
    links: dict[str, Any] = Field(
        default_factory=dict, description="Link relations", alias="_links"
    )

    model_config = ConfigDict(extra="allow", coerce_numbers_to_str=True)


class SearchResult(BaseModel):
    """Confluence search result model.

    Attributes:
        id: Content ID.
        title: Content title.
        type: Content type (e.g., 'page', 'blogpost', 'comment', 'attachment').
        status: Content status.
        space: Space information.
        version: Version information.
        excerpt: Search excerpt/snippet.
        highlights: Highlighted search matches.
        breadcrumbs: Breadcrumb navigation.
        links: Link relations for the content.
    """

    id: str = Field("", description="Content ID")
    title: str = Field("", description="Content title")
    type: str = Field("", description="Content type")
    status: str = Field("current", description="Content status")
    space: Optional[Space] = Field(None, description="Space information")
    version: Optional[Version] = Field(None, description="Version information")
    excerpt: Optional[str] = Field(None, description="Search excerpt/snippet")
    highlights: dict[str, Any] = Field(
        default_factory=dict, description="Highlighted matches"
    )
    breadcrumbs: list[dict[str, Any]] = Field(
        default_factory=list, description="Breadcrumb navigation"
    )
    links: dict[str, Any] = Field(
        default_factory=dict, description="Link relations", alias="_links"
    )

    model_config = ConfigDict(extra="allow", coerce_numbers_to_str=True)


class SearchResponse(BaseModel):
    """Confluence search API response wrapper.

    Attributes:
        results: List of search results.
        start: Starting index for pagination.
        limit: Maximum results per page.
        size: Actual number of results returned.
        total: Total number of matching results.
        cql: The CQL query that was executed.
        search_duration: Search execution time in milliseconds.
        links: Link relations for pagination.
    """

    results: list[SearchResult] = Field(
        default_factory=list, description="Search results"
    )
    start: int = Field(0, description="Starting index")
    limit: int = Field(25, description="Maximum results per page")
    size: int = Field(0, description="Actual results returned")
    total: int = Field(0, description="Total matching results")
    cql: str = Field("", description="Executed CQL query")
    search_duration: Optional[str] = Field(None, description="Search duration")
    links: dict[str, Any] = Field(
        default_factory=dict, description="Link relations", alias="_links"
    )

    model_config = ConfigDict(extra="allow", coerce_numbers_to_str=True)


class SpaceResponse(BaseModel):
    """Confluence spaces API response wrapper.

    Attributes:
        results: List of space results.
        start: Starting index for pagination.
        limit: Maximum results per page.
        size: Actual number of results returned.
        links: Link relations for pagination.
    """

    results: list[Space] = Field(default_factory=list, description="Space results")
    start: int = Field(0, description="Starting index")
    limit: int = Field(25, description="Maximum results per page")
    size: int = Field(0, description="Actual results returned")
    links: dict[str, Any] = Field(
        default_factory=dict, description="Link relations", alias="_links"
    )

    model_config = ConfigDict(extra="allow", coerce_numbers_to_str=True)


class AttachmentResponse(BaseModel):
    """Confluence attachments API response wrapper.

    Attributes:
        results: List of attachment results.
        start: Starting index for pagination.
        limit: Maximum results per page.
        size: Actual number of results returned.
        links: Link relations for pagination.
    """

    results: list[Attachment] = Field(
        default_factory=list, description="Attachment results"
    )
    start: int = Field(0, description="Starting index")
    limit: int = Field(25, description="Maximum results per page")
    size: int = Field(0, description="Actual results returned")
    links: dict[str, Any] = Field(
        default_factory=dict, description="Link relations", alias="_links"
    )

    model_config = ConfigDict(extra="allow", coerce_numbers_to_str=True)


class CommentResponse(BaseModel):
    """Confluence comments API response wrapper.

    Attributes:
        results: List of comment results.
        start: Starting index for pagination.
        limit: Maximum results per page.
        size: Actual number of results returned.
        links: Link relations for pagination.
    """

    results: list[Comment] = Field(default_factory=list, description="Comment results")
    start: int = Field(0, description="Starting index")
    limit: int = Field(25, description="Maximum results per page")
    size: int = Field(0, description="Actual results returned")
    links: dict[str, Any] = Field(
        default_factory=dict, description="Link relations", alias="_links"
    )

    model_config = ConfigDict(extra="allow", coerce_numbers_to_str=True)


class PageResponse(BaseModel):
    """Confluence pages API response wrapper.

    Attributes:
        results: List of page results.
        start: Starting index for pagination.
        limit: Maximum results per page.
        size: Actual number of results returned.
        total: Total number of matching results.
        links: Link relations for pagination.
    """

    results: list[Page] = Field(default_factory=list, description="Page results")
    start: int = Field(0, description="Starting index")
    limit: int = Field(25, description="Maximum results per page")
    size: int = Field(0, description="Actual results returned")
    total: int = Field(0, description="Total matching results")
    links: dict[str, Any] = Field(
        default_factory=dict, description="Link relations", alias="_links"
    )

    model_config = ConfigDict(extra="allow", coerce_numbers_to_str=True)


class Label(BaseModel):
    """Confluence label model.

    Attributes:
        id: Label ID.
        name: Label name.
        prefix: Label prefix (e.g., 'global', 'my').
    """

    id: str = Field("", description="Label ID")
    name: str = Field("", description="Label name")
    prefix: str = Field("global", description="Label prefix")

    model_config = ConfigDict(extra="allow", coerce_numbers_to_str=True)


class LabelResponse(BaseModel):
    """Confluence labels API response wrapper.

    Attributes:
        results: List of label results.
        start: Starting index for pagination.
        limit: Maximum results per page.
        size: Actual number of results returned.
        links: Link relations for pagination.
    """

    results: list[Label] = Field(default_factory=list, description="Label results")
    start: int = Field(0, description="Starting index")
    limit: int = Field(25, description="Maximum results per page")
    size: int = Field(0, description="Actual results returned")
    links: dict[str, Any] = Field(
        default_factory=dict, description="Link relations", alias="_links"
    )

    model_config = ConfigDict(extra="allow", coerce_numbers_to_str=True)


class AttachmentDownloadResult(BaseModel):
    """Result of downloading a single attachment.

    Attributes:
        status: Download status ("downloaded").
        attachment_id: The attachment ID.
        saved_to: Absolute path where the file was saved.
        bytes: Number of bytes downloaded.
    """

    status: str = Field("downloaded", description="Download status")
    attachment_id: str = Field("", description="The attachment ID")
    saved_to: str = Field("", description="Absolute path where file was saved")
    bytes: int = Field(0, description="Number of bytes downloaded")

    model_config = ConfigDict(extra="allow", coerce_numbers_to_str=True)


class AttachmentDeletionResult(BaseModel):
    """Result of deleting an attachment.

    Attributes:
        status: Deletion status ("deleted").
        attachment_id: The attachment ID that was deleted.
    """

    status: str = Field("deleted", description="Deletion status")
    attachment_id: str = Field("", description="The attachment ID that was deleted")

    model_config = ConfigDict(extra="allow", coerce_numbers_to_str=True)


class AttachmentUploadResult(BaseModel):
    """Result of uploading a single attachment.

    Attributes:
        id: Attachment ID.
        title: Attachment title/filename.
        status: Upload status ("uploaded" or "error").
        reason: Error description (if failed).
    """

    id: Optional[str] = Field(None, description="Attachment ID")
    title: str = Field("", description="Attachment title/filename")
    status: str = Field("", description="Upload status (uploaded/error)")
    reason: Optional[str] = Field(None, description="Error description if failed")

    model_config = ConfigDict(extra="allow", coerce_numbers_to_str=True)


class AttachmentUploadBatchResponse(BaseModel):
    """Batch response for uploading multiple attachments.

    Attributes:
        results: List of upload results, one per file.
        total: Total number of files attempted.
        uploaded: Number of successfully uploaded files.
        failed: Number of failed uploads.
    """

    results: list[AttachmentUploadResult] = Field(
        default_factory=list, description="Upload results"
    )
    total: int = Field(0, description="Total files attempted")
    uploaded: int = Field(0, description="Number of successful uploads")
    failed: int = Field(0, description="Number of failed uploads")

    model_config = ConfigDict(extra="allow", coerce_numbers_to_str=True)


class ContentAttachmentDownloadResult(BaseModel):
    """Result of downloading a single content attachment.

    Attributes:
        id: Attachment ID.
        title: Attachment title.
        status: Download status ("downloaded", "skipped", or "error").
        bytes: Number of bytes downloaded (if downloaded).
        saved_to: Path where saved (if downloaded).
        reason: Error/skip reason (if applicable).
    """

    id: str = Field("", description="Attachment ID")
    title: str = Field("", description="Attachment title")
    status: str = Field("", description="Download status")
    bytes: Optional[int] = Field(None, description="Number of bytes downloaded")
    saved_to: Optional[str] = Field(None, description="Path where saved")
    reason: Optional[str] = Field(None, description="Error/skip reason")

    model_config = ConfigDict(extra="allow", coerce_numbers_to_str=True)


class ContentAttachmentDownloadBatchResponse(BaseModel):
    """Batch response for downloading all content attachments.

    Attributes:
        results: List of download results, one per attachment.
        total: Total number of attachments attempted.
        downloaded: Number of successfully downloaded attachments.
        skipped: Number of skipped attachments.
        failed: Number of failed downloads.
    """

    results: list[ContentAttachmentDownloadResult] = Field(
        default_factory=list, description="Download results"
    )
    total: int = Field(0, description="Total attachments attempted")
    downloaded: int = Field(0, description="Number of successful downloads")
    skipped: int = Field(0, description="Number of skipped attachments")
    failed: int = Field(0, description="Number of failed downloads")

    model_config = ConfigDict(extra="allow", coerce_numbers_to_str=True)


class ImageResult(BaseModel):
    """Result of getting image data from an attachment.

    Attributes:
        id: Attachment ID.
        title: Image filename/title.
        mime_type: Resolved MIME type.
        size: Size in bytes.
        data: Base64-encoded image data.
        status: Processing status ("ok", "skipped", or "error").
        reason: Description of why it was skipped/failed (if applicable).
    """

    id: str = Field("", description="Attachment ID")
    title: str = Field("", description="Image filename/title")
    mime_type: Optional[str] = Field(None, description="Resolved MIME type")
    size: Optional[int] = Field(None, description="Size in bytes")
    data: Optional[str] = Field(None, description="Base64-encoded image data")
    status: str = Field("ok", description="Processing status")
    reason: Optional[str] = Field(None, description="Skip/fail reason")

    model_config = ConfigDict(extra="allow", coerce_numbers_to_str=True)


class PageHistoryResult(BaseModel):
    """Result of getting page history.

    Attributes:
        page_id: The page ID.
        title: The page title.
        version: Version information with number, by, when, message.
        history: History metadata with created_by, created_date, etc.
    """

    page_id: str = Field("", description="The page ID")
    title: str = Field("", description="The page title")
    version: dict[str, Any] = Field(default_factory=dict, description="Version info")
    history: dict[str, Any] = Field(
        default_factory=dict, description="History metadata"
    )

    model_config = ConfigDict(extra="allow", coerce_numbers_to_str=True)
