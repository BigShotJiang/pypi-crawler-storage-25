"""MCP tool for listing and reading external prompts.

Provides one tool:

- ``confluence_mcp_prompts`` — lists all loaded external prompts, or
  returns full prompt content if ``name`` argument is provided.
"""

from __future__ import annotations

import logging
from typing import Any

from mcp.server.fastmcp import Context

from .server import mcp

logger = logging.getLogger("www-confluence-mcp")


@mcp.tool(
    name="confluence_mcp_prompts",
    title="List / Get External Prompts",
    description=(
        "List all loaded external prompt definitions, or get full prompt content. "
        "Without arguments: returns list of prompts with names, descriptions, "
        "and argument signatures. "
        "With 'name' argument: returns the full prompt template and arguments "
        "so you can understand what the prompt does before executing it."
    ),
)
async def confluence_mcp_prompts(
    name: str | None = None,
    ctx: Context | None = None,
) -> dict[str, Any]:
    """List prompts or get full prompt content by name."""
    # Extract credentials from request headers (HTTP mode)
    from .utils.auth import extract_credentials

    await extract_credentials(ctx)

    from .prompt_loader import get_loaded_prompts

    loaded = get_loaded_prompts()

    # If name provided — return full prompt content
    if name:
        if name not in loaded:
            return {
                "status": "error",
                "reason": f"Prompt '{name}' not found. Available: {list(loaded.keys())}",
            }
        data = loaded[name]
        return {
            "status": "ok",
            "name": name,
            "description": data.get("description", ""),
            "arguments": data.get("arguments", []),
            "template": data.get("template", ""),
        }

    # No name — return list of all prompts
    if not loaded:
        return {"status": "ok", "count": 0, "prompts": []}

    prompts = []
    for pname, data in sorted(loaded.items()):
        prompts.append(
            {
                "name": pname,
                "description": data.get("description", ""),
                "arguments": [
                    {
                        "name": a.get("name", ""),
                        "required": a.get("required", True),
                        "description": a.get("description", ""),
                    }
                    for a in data.get("arguments", [])
                ],
            }
        )

    return {"status": "ok", "count": len(prompts), "prompts": prompts}
