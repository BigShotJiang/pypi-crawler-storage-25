"""Custom exception hierarchy for Confluence API errors."""

from __future__ import annotations


class ConfluenceError(Exception):
    """Base exception for Confluence API errors.

    Attributes:
        message: Error message describing the exception.
        status_code: HTTP status code from the API response.
        url: URL that caused the error.
        retryable: Whether the operation can be retried.
        suggested_action: Hint for the caller on how to resolve.
    """

    def __init__(
        self,
        message: str,
        status_code: int | None = None,
        url: str | None = None,
        retryable: bool = False,
        suggested_action: str = "",
    ) -> None:
        """Initialize ConfluenceError.

        Args:
            message: Error message describing the exception.
            status_code: HTTP status code from the API response.
            url: URL that caused the error.
            retryable: Whether the operation can be retried.
            suggested_action: Hint for the caller on how to resolve.
        """
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.url = url
        self.retryable = retryable
        self.suggested_action = suggested_action


class ConfluenceNotFoundError(ConfluenceError):
    """Exception raised when a resource is not found (404).

    This error is not retryable as the resource does not exist.
    """

    def __init__(self, message: str, url: str | None = None) -> None:
        """Initialize ConfluenceNotFoundError.

        Args:
            message: Error message describing the exception.
            url: URL that caused the error.
        """
        super().__init__(message, status_code=404, url=url, retryable=False)


class ConfluencePermissionError(ConfluenceError):
    """Exception raised when access is forbidden (403).

    This error is not retryable as permissions won't change without
    user intervention.
    """

    def __init__(self, message: str) -> None:
        """Initialize ConfluencePermissionError.

        Args:
            message: Error message describing the exception.
        """
        super().__init__(message, status_code=403, retryable=False)


class ConfluenceConflictError(ConfluenceError):
    """Exception raised when there is a version conflict (409).

    This error occurs when trying to update a resource with an outdated
    version number. Not retryable without resolving the conflict.
    """

    def __init__(self, message: str) -> None:
        """Initialize ConfluenceConflictError.

        Args:
            message: Error message describing the exception.
        """
        super().__init__(message, status_code=409, retryable=False)


class ConfluenceRateLimitError(ConfluenceError):
    """Exception raised when rate limit is exceeded (429).

    This error is retryable after waiting for the specified retry_after
    duration.

    Attributes:
        retry_after: Seconds to wait before retrying (from Retry-After header).
    """

    def __init__(
        self,
        message: str,
        retry_after: float | None = None,
    ) -> None:
        """Initialize ConfluenceRateLimitError.

        Args:
            message: Error message describing the exception.
            retry_after: Seconds to wait before retrying.
        """
        super().__init__(message, status_code=429, retryable=True)
        self.retry_after: float | None = retry_after


class ConfluenceTimeoutError(ConfluenceError):
    """Exception raised when a request times out.

    This error is retryable as timeouts are often transient.
    """

    def __init__(self, message: str) -> None:
        """Initialize ConfluenceTimeoutError.

        Args:
            message: Error message describing the exception.
        """
        super().__init__(message, retryable=True)


class ConfluenceAPIError(ConfluenceError):
    """Exception raised for 5xx server errors.

    This error is retryable as server errors are often transient.
    """

    def __init__(self, message: str, status_code: int = 500) -> None:
        """Initialize ConfluenceAPIError.

        Args:
            message: Error message describing the exception.
            status_code: HTTP status code (default 500).
        """
        super().__init__(message, status_code=status_code, retryable=True)


# ---------------------------------------------------------------------------
# Converter-specific exceptions
# ---------------------------------------------------------------------------


class ConverterError(ConfluenceError):
    """Base error for converter operations.

    Attributes:
        suggested_action: Hint for the caller on how to resolve.
    """

    def __init__(
        self,
        message: str,
        *,
        retryable: bool = False,
        suggested_action: str = "",
    ) -> None:
        """Initialize ConverterError.

        Args:
            message: Error message describing the exception.
            retryable: Whether the operation can be retried.
            suggested_action: Hint for the caller on how to resolve.
        """
        super().__init__(message, retryable=retryable)
        self.suggested_action = suggested_action


class ParseError(ConverterError):
    """Error parsing HTML or Markdown.

    Attributes:
        element: The element that caused the parse error.
    """

    def __init__(self, message: str, *, element: str = "") -> None:
        """Initialize ParseError.

        Args:
            message: Error message describing the exception.
            element: The element that caused the parse error.
        """
        super().__init__(message, retryable=False)
        self.element = element


class MacroPreservationError(ConverterError):
    """Error preserving Confluence macro during conversion.

    Attributes:
        macro_name: Name of the macro that failed preservation.
    """

    def __init__(self, message: str, *, macro_name: str = "") -> None:
        """Initialize MacroPreservationError.

        Args:
            message: Error message describing the exception.
            macro_name: Name of the macro that failed preservation.
        """
        super().__init__(message, retryable=False)
        self.macro_name = macro_name


class RoundTripError(ConverterError):
    """Error during round-trip restoration.

    Attributes:
        element_type: Type of element that failed restoration.
    """

    def __init__(self, message: str, *, element_type: str = "") -> None:
        """Initialize RoundTripError.

        Args:
            message: Error message describing the exception.
            element_type: Type of element that failed restoration.
        """
        super().__init__(message, retryable=False)
        self.element_type = element_type
