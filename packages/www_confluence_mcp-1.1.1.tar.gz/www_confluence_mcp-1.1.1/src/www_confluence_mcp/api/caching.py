"""Page caching utilities for Confluence API client."""

from __future__ import annotations

import logging
from typing import Any

from ..utils.cache import page_cache

logger = logging.getLogger("www-confluence-mcp")


async def get_page_cached(
    page_id: str,
    body_format: str = "storage",
    ttl: int | None = None,
) -> dict[str, Any] | Any:
    """Fetch a page with TTL caching.

    Returns cached data if available and not expired.
    Otherwise fetches from API and caches the result.

    Args:
        page_id: Confluence page ID.
        body_format: Content format (default "storage").
        ttl: Optional TTL override in seconds. Uses
            page_cache default if None.

    Returns:
        Page data dict from API or cache.
    """
    cache_key = f"page:{page_id}:{body_format}"
    cached = await page_cache.get(cache_key)
    if cached is not None:
        logger.debug("Cache hit for page %s", page_id)
        return cached

    # Import here to avoid circular import
    from .pages import get_page

    result = await get_page(page_id, body_format=body_format)
    await page_cache.set(cache_key, result)
    logger.debug("Cached page %s", page_id)
    return result


async def invalidate_page_cache(page_id: str) -> None:
    """Remove a page from cache (call after update/delete).

    Args:
        page_id: Confluence page ID to evict.
    """
    for fmt in ("storage", "editor", "view"):
        await page_cache.invalidate(f"page:{page_id}:{fmt}")
    logger.debug("Invalidated cache for page %s", page_id)
