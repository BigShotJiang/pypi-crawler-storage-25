"""Labels API endpoints for Confluence v1."""

from __future__ import annotations

import urllib.parse

from ..config import IdLike, get_id
from .session import request, safe_path_segment, api_path
from ..models import Label, LabelResponse
from ..utils.content import model_from_dict


async def get_page_labels(page_id: IdLike) -> LabelResponse:
    """Get labels on a page (v1).

    Args:
        page_id: The ID of the page to get labels from.
            Can be a string or dict with 'id'.

    Returns:
        LabelResponse with results list and pagination metadata.

    Raises:
        ConfluenceError: If the API request fails.
    """
    data = await request(
        "GET", api_path(f"/content/{safe_path_segment(get_id(page_id, 'id'))}/label")
    )
    if data is None:
        return LabelResponse()

    results = data.get("results", [])
    labels = [model_from_dict(Label, lbl) for lbl in results]

    return LabelResponse.model_validate(
        {
            "results": labels,
            "start": data.get("start", 0),
            "limit": data.get("limit", 25),
            "size": data.get("size", len(labels)),
            "_links": data.get("_links", {}),
        }
    )


async def add_page_labels(page_id: IdLike, labels: list[str]) -> LabelResponse:
    """Add labels to a page (v1).

    Args:
        page_id: The ID of the page to add labels to.
            Can be a string or dict with 'id'.
        labels: List of label names to add. Each label is added with the
            'global' prefix.

    Returns:
        LabelResponse with results list containing added labels.

    Raises:
        ConfluenceError: If the API request fails.
        ConfluencePermissionError: If user lacks permission to add labels.
    """
    data = await request(
        "POST",
        api_path(f"/content/{safe_path_segment(get_id(page_id, 'id'))}/label"),
        json=[{"prefix": "global", "name": lbl} for lbl in labels],
    )
    if data is None:
        return LabelResponse()

    results = data.get("results", [])
    added_labels = [model_from_dict(Label, lbl) for lbl in results]

    return LabelResponse.model_validate(
        {
            "results": added_labels,
            "start": data.get("start", 0),
            "limit": data.get("limit", 25),
            "size": data.get("size", len(added_labels)),
            "_links": data.get("_links", {}),
        }
    )


async def delete_page_label(page_id: IdLike, label: str) -> None:
    """Remove a label from a page (v1).

    Args:
        page_id: The ID of the page to remove the label from.
            Can be a string or dict with 'id'.
        label: The name of the label to remove.

    Raises:
        ConfluenceError: If the API request fails.
        ConfluenceNotFoundError: If the page or label does not exist.
        ConfluencePermissionError: If user lacks permission to remove labels.
    """
    encoded_id = safe_path_segment(get_id(page_id, "id"))
    encoded_label = urllib.parse.quote(label, safe="")
    await request("DELETE", api_path(f"/content/{encoded_id}/label/{encoded_label}"))
