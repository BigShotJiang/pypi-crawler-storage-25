"""Comments API endpoints for Confluence v1."""

from __future__ import annotations

from typing import Any

from ..config import IdLike, get_id
from .session import request, safe_path_segment, api_path
from ..models import Comment, CommentResponse
from ..utils.content import model_from_dict


async def get_footer_comments(
    page_id: IdLike,
    limit: int = 25,
    start: int = 0,
) -> CommentResponse:
    """Get footer comments on a page (v1 child endpoint).

    Args:
        page_id: The ID of the page to get comments from.
            Can be a string or dict with 'id'.
        limit: Maximum number of comments to return (default: 25).
        start: Starting index for pagination (default: 0).

    Returns:
        CommentResponse with results list and pagination metadata.

    Raises:
        ConfluenceError: If the API request fails.
    """
    params: dict[str, Any] = {"limit": limit, "start": start, "expand": "version"}
    data = await request(
        "GET",
        api_path(f"/content/{safe_path_segment(get_id(page_id, 'id'))}/child/comment"),
        params=params,
    )
    if data is None:
        return CommentResponse()

    results = data.get("results", [])
    comments = [model_from_dict(Comment, c) for c in results]

    return CommentResponse.model_validate(
        {
            "results": comments,
            "start": data.get("start", 0),
            "limit": data.get("limit", 25),
            "size": data.get("size", len(comments)),
            "_links": data.get("_links", {}),
        }
    )


async def create_comment(
    page_id: IdLike,
    body_value: str,
) -> Comment:
    """Add a comment to a page (v1 content endpoint).

    Args:
        page_id: The ID of the page to add the comment to.
            Can be a string or dict with 'id'.
        body_value: The comment body in storage format (Confluence storage format).

    Returns:
        Comment model with id, title, body, and version.

    Raises:
        ConfluenceError: If the API request fails.
        ConfluencePermissionError: If user lacks permission to comment.
    """
    payload: dict[str, Any] = {
        "type": "comment",
        "body": {"storage": {"value": body_value, "representation": "storage"}},
        "container": {"id": get_id(page_id, "id"), "type": "page"},
    }
    data = await request("POST", api_path("/content"), json=payload)
    return model_from_dict(Comment, data or {})


async def reply_to_comment(
    comment_id: IdLike,
    body_value: str,
) -> Comment:
    """Reply to an existing comment (v1 content endpoint).

    Args:
        comment_id: The ID of the comment to reply to.
            Can be a string or dict with 'id'.
        body_value: The reply body in storage format (Confluence storage format).

    Returns:
        Comment model with id, title, body, and version.

    Raises:
        ConfluenceError: If the API request fails.
        ConfluencePermissionError: If user lacks permission to comment.
    """
    payload: dict[str, Any] = {
        "type": "comment",
        "body": {"storage": {"value": body_value, "representation": "storage"}},
        "container": {"id": get_id(comment_id, "id"), "type": "comment"},
    }
    data = await request("POST", api_path("/content"), json=payload)
    return model_from_dict(Comment, data or {})
