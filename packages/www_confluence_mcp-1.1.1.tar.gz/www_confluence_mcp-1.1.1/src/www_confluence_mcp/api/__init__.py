"""Confluence API v1 client modules."""

from __future__ import annotations

from .attachments import (
    _fetch_all_attachments,
    delete_attachment,
    download_attachment,
    download_content_attachments,
    get_attachments,
    upload_attachment,
    upload_attachments,
)
from .comments import create_comment, get_footer_comments, reply_to_comment
from .images import get_page_images
from .labels import add_page_labels, delete_page_label, get_page_labels
from .pages import (
    create_page,
    delete_page,
    get_child_pages,
    get_page,
    get_page_ancestors,
    get_page_by_title,
    get_page_history,
    get_pages_in_space,
    move_page,
    update_page,
)
from .caching import get_page_cached, invalidate_page_cache
from .search import search_cql
from .session import (
    _CQL_FIELD_RE,
    _IMAGE_MIME_TYPES,
    _MAX_IMAGE_BYTES,
    get_extension_from_mime,
    is_image,
    join_download_url,
    close_client,
    get_client,
)
from .space_tree import get_space_page_tree
from .spaces import get_space, get_spaces
from .users import search_user

__all__ = [
    # Session
    "get_client",
    "close_client",
    "_CQL_FIELD_RE",
    "_IMAGE_MIME_TYPES",
    "_MAX_IMAGE_BYTES",
    "is_image",
    "get_extension_from_mime",
    "join_download_url",
    "get_page_cached",
    "invalidate_page_cache",
    # Spaces
    "get_spaces",
    "get_space",
    # Pages
    "get_page",
    "get_page_by_title",
    "get_pages_in_space",
    "get_child_pages",
    "get_page_ancestors",
    "create_page",
    "update_page",
    "delete_page",
    "get_page_history",
    "move_page",
    # Labels
    "get_page_labels",
    "add_page_labels",
    "delete_page_label",
    # Comments
    "get_footer_comments",
    "create_comment",
    "reply_to_comment",
    # Search
    "search_cql",
    # Attachments
    "get_attachments",
    "upload_attachment",
    "download_attachment",
    "delete_attachment",
    "_fetch_all_attachments",
    "download_content_attachments",
    "upload_attachments",
    # Users
    "search_user",
    # Space tree
    "get_space_page_tree",
    # Images
    "get_page_images",
]
