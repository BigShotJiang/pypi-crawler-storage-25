"""Search functionality for Confluence API client using CQL."""

from __future__ import annotations

from typing import Any

from .session import _CQL_FIELD_RE, request, api_path
from ..models import SearchResult, SearchResponse
from ..utils.content import model_from_dict
from ..utils.cql import escape_cql_value


async def search_cql(
    query: str,
    spaces: list[str] | None = None,
    content_types: list[str] | None = None,
    limit: int = 25,
    start: int = 0,
) -> SearchResponse:
    """Search Confluence content using CQL via the v1 REST API.

    Automatically detects if the query is already CQL or should be treated
    as a simple text search (converted to 'text ~ "query"').

    Args:
        query: Search query string or CQL expression.
        spaces: Optional list of space keys to filter results.
            If provided, results are limited to these spaces.
        content_types: Optional list of content types to filter results.
            Common values: "page", "blogpost", "comment", "attachment".
        limit: Maximum number of results to return (default: 25).
        start: Starting index for pagination (default: 0).

    Returns:
        SearchResponse with results list and pagination metadata.

    Raises:
        ConfluenceError: If the API request fails.
    """
    cql_parts: list[str] = []

    # Detect if query is already CQL — require structural patterns to avoid
    # false positives on queries like "price > 100" or "a = b".
    has_cql = (
        bool(_CQL_FIELD_RE.search(query))
        or any(f" {kw} " in query.upper() for kw in ("AND", "OR", "NOT"))
        or "ORDER BY " in query.upper()
    )

    if has_cql:
        cql_parts.append(query)
    else:
        cql_parts.append(f'text ~ "{escape_cql_value(query)}"')

    if spaces:
        space_clause = " OR ".join(f'space = "{escape_cql_value(s)}"' for s in spaces)
        cql_parts.append(f"({space_clause})")
    if content_types:
        type_clause = " OR ".join(
            f'type = "{escape_cql_value(t)}"' for t in content_types
        )
        cql_parts.append(f"({type_clause})")

    cql = " AND ".join(cql_parts)

    params: dict[str, Any] = {
        "cql": cql,
        "limit": limit,
        "start": start,
        "expand": "space,version,ancestors",
    }
    data = await request("GET", api_path("/content/search"), params=params)
    if data is None:
        return SearchResponse()

    results = data.get("results", [])
    search_results = [model_from_dict(SearchResult, r) for r in results]

    return SearchResponse.model_validate(
        {
            "results": search_results,
            "start": data.get("start", 0),
            "limit": data.get("limit", 25),
            "size": data.get("size", len(search_results)),
            "total": data.get("total", len(search_results)),
            "cql": data.get("cql", cql),
            "searchDuration": data.get("searchDuration"),
            "_links": data.get("_links", {}),
        }
    )
