"""User search API for Confluence."""

from __future__ import annotations


from .session import request, api_path
from ..models import User
from ..utils.content import model_from_dict
from ..utils.cql import escape_cql_value


async def search_user(
    query: str,
    limit: int = 25,
    start: int = 0,
) -> list[User]:
    """Search for users (v1 CQL search).

    Uses CQL to search for users by their full name.

    Args:
        query: The user search query (matched against fullname).
        limit: Maximum number of results to return (default: 25).
        start: Starting index for pagination (default: 0).

    Returns:
        List of User models with username, displayName, and links.

    Raises:
        ConfluenceError: If the API request fails.
    """
    cql = f'type=user AND user.fullname ~ "{escape_cql_value(query)}"'
    data = await request(
        "GET",
        api_path("/search"),
        params={"cql": cql, "limit": limit, "start": start},
    )
    if data is None:
        return []

    results = data.get("results", [])
    # User data is nested inside 'user' sub-field in search results
    users = []
    for r in results:
        user_data = r.get(
            "user", r
        )  # Extract nested user data, or use r if already flat
        users.append(model_from_dict(User, user_data))
    return users
