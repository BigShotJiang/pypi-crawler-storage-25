"""Core HTTP session infrastructure for Confluence API client."""

from __future__ import annotations

import asyncio
import base64
import contextvars
import json
import logging
import os
import re
import ssl
import time
import urllib.parse
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from pathlib import Path
from typing import Any

import niquests
import truststore

from ..config import (
    API_VERSION,
    AUTH_TYPE,
    HTTP_PROXY,
    HTTPS_PROXY,
    PASSWORD,
    PERSONAL_TOKEN,
    RATE_LIMIT_MAX_TOKENS,
    RATE_LIMIT_TOKENS_PER_SECOND,
    SSL_PATH,
    SSL_VERIFY,
    TIMEOUT_CONFIG,
    URL,
    USERNAME,
)
from ..exceptions import (
    ConfluenceAPIError,
    ConfluenceConflictError,
    ConfluenceError,
    ConfluenceNotFoundError,
    ConfluencePermissionError,
    ConfluenceRateLimitError,
    ConfluenceTimeoutError,
)
from ..utils.retry import RetryConfig, with_retry

logger = logging.getLogger("www-confluence-mcp")

# ---------------------------------------------------------------------------
# Per-request credentials (set by auth.extract_credentials from HTTP headers)
# ---------------------------------------------------------------------------

_req_confluence_url: contextvars.ContextVar[str | None] = contextvars.ContextVar(
    "_req_confluence_url", default=None
)
_req_confluence_token: contextvars.ContextVar[str | None] = contextvars.ContextVar(
    "_req_confluence_token", default=None
)
_req_confluence_username: contextvars.ContextVar[str | None] = contextvars.ContextVar(
    "_req_confluence_username", default=None
)
_req_confluence_password: contextvars.ContextVar[str | None] = contextvars.ContextVar(
    "_req_confluence_password", default=None
)

# Per-user client cache (for remote/HTTP mode)
_user_clients: dict[str, niquests.AsyncSession] = {}
_user_client_times: dict[str, float] = {}
_USER_CLIENT_TTL = 3600  # 1 hour

# Pre-compiled CQL detection regex — avoids re-compilation on every search() call.
_CQL_FIELD_RE = re.compile(
    r"(?:title|text|space|type|label|creator|contributor|lastmodified|created)"
    r"\s*[=~><]",
    re.IGNORECASE,
)

# ---------------------------------------------------------------------------
# Rate Limiter
# ---------------------------------------------------------------------------


class AsyncRateLimiter:
    """Token bucket rate limiter for controlling API request rate.

    Uses a token bucket algorithm where tokens are added at a constant
    rate and requests consume tokens. If no tokens are available, the
    request waits until tokens are replenished.

    Attributes:
        max_tokens: Maximum number of tokens in the bucket.
        tokens_per_second: Rate at which tokens are replenished.
        _tokens: Current number of available tokens.
        _last_update: Time of last token replenishment.
        _condition: asyncio.Condition for thread-safe wait/notify.
    """

    def __init__(
        self, tokens_per_second: float = 100.0, max_tokens: float = 1000.0
    ) -> None:
        self.max_tokens = max_tokens
        self.tokens_per_second = tokens_per_second
        self._tokens = max_tokens  # Start with full bucket
        self._last_update = time.monotonic()
        self._condition = asyncio.Condition()

    async def acquire(self, tokens: int = 1) -> None:
        """Acquire tokens from the bucket, waiting if necessary.

        Args:
            tokens: Number of tokens to acquire (default: 1).

        Raises:
            ValueError: If tokens requested exceeds max capacity.
        """
        if tokens > self.max_tokens:
            raise ValueError(
                f"Cannot acquire {tokens} tokens, max capacity is {self.max_tokens}"
            )

        async with self._condition:
            while True:
                self._replenish()

                if self._tokens >= tokens:
                    self._tokens -= tokens
                    self._condition.notify_all()
                    return

                # Calculate wait time for next token
                tokens_needed = tokens - self._tokens
                wait_time = tokens_needed / self.tokens_per_second

                # Wait with timeout, then re-check tokens
                try:
                    await asyncio.wait_for(self._condition.wait(), timeout=wait_time)
                except asyncio.TimeoutError:
                    # Timeout expected - continue loop to re-check tokens
                    pass

    def _replenish(self) -> None:
        """Replenish tokens based on elapsed time.

        Adds tokens proportional to time elapsed since last update,
        capped at maximum capacity.
        """
        now = time.monotonic()
        elapsed = now - self._last_update
        self._tokens = min(
            self.max_tokens, self._tokens + elapsed * self.tokens_per_second
        )
        self._last_update = now

    @property
    def available_tokens(self) -> float:
        """Get current number of available tokens (approximate)."""
        self._replenish()
        return self._tokens


# Global rate limiter instance (lazily initialized)
_rate_limiter: AsyncRateLimiter | None = None
_rate_limiter_lock = asyncio.Lock()


async def get_rate_limiter() -> AsyncRateLimiter:
    """Get or create the global rate limiter instance.

    Returns:
        Configured AsyncRateLimiter instance.
    """
    global _rate_limiter
    async with _rate_limiter_lock:
        if _rate_limiter is None:
            _rate_limiter = AsyncRateLimiter(
                tokens_per_second=RATE_LIMIT_TOKENS_PER_SECOND,
                max_tokens=RATE_LIMIT_MAX_TOKENS,
            )
        return _rate_limiter


# ---------------------------------------------------------------------------
# Client singleton (local mode) and per-user cache (remote mode)
# ---------------------------------------------------------------------------

_CLIENT: niquests.AsyncSession | None = None
_CLIENT_LOCK = asyncio.Lock()


async def _get_singleton_client() -> niquests.AsyncSession:
    """Return (or lazily create) the shared async HTTP client for local mode.

    Returns:
        The shared niquests.AsyncSession instance configured with Confluence
        authentication and SSL settings.

    Raises:
        RuntimeError: If Confluence is not configured (missing URL or AUTH_TYPE).
    """
    global _CLIENT
    async with _CLIENT_LOCK:
        if _CLIENT is not None:
            return _CLIENT

        if not URL or not AUTH_TYPE:
            raise RuntimeError(
                "Confluence is not configured. Set CONFLUENCE_URL and "
                "CONFLUENCE_PERSONAL_TOKEN (or CONFLUENCE_USERNAME + CONFLUENCE_PASSWORD) "
                "environment variables."
            )

        headers: dict[str, str] = {
            "Accept": "application/json",
        }

        if AUTH_TYPE == "pat":
            headers["Authorization"] = f"Bearer {PERSONAL_TOKEN}"
        else:
            credentials = base64.b64encode(f"{USERNAME}:{PASSWORD}".encode()).decode()
            headers["Authorization"] = f"Basic {credentials}"

        proxy = HTTPS_PROXY or HTTP_PROXY

        session = niquests.AsyncSession(
            multiplexed=True,
            timeout=TIMEOUT_CONFIG,
            headers=headers,
            pool_connections=25,
            pool_maxsize=25,
            happy_eyeballs=True,
        )
        session.verify = _build_ssl_context()  # ty: ignore[invalid-assignment]  # niquests accepts SSLContext at runtime
        session.base_url = URL.rstrip("/")

        if proxy:
            session.proxies.update({"http": proxy, "https": proxy})

        _CLIENT = session
        return _CLIENT


def _get_user_client_cache_key(
    url: str, token: str | None, username: str | None, password: str | None
) -> str:
    """Generate a cache key for per-user client based on credentials."""
    return f"{url}|{token or ''}|{username or ''}|{password or ''}"


async def _get_user_client(
    url: str,
    token: str | None,
    username: str | None,
    password: str | None,
) -> niquests.AsyncSession:
    """Get or create a per-user HTTP client for remote mode.

    Args:
        url: Confluence URL
        token: Personal access token (for PAT auth)
        username: Username (for Basic auth)
        password: Password or API token (for Basic auth)

    Returns:
        Cached niquests.AsyncSession instance for this credential set.
    """
    import time

    cache_key = _get_user_client_cache_key(url, token, username, password)
    current_time = time.time()

    # Check if we have a cached client that hasn't expired
    if cache_key in _user_clients:
        if current_time - _user_client_times.get(cache_key, 0) < _USER_CLIENT_TTL:
            return _user_clients[cache_key]
        # Client expired, clean it up
        old_client = _user_clients.pop(cache_key, None)
        if old_client:
            try:
                await old_client.close()
            except Exception:
                logger.debug("Failed to close expired user client", exc_info=True)
        _user_client_times.pop(cache_key, None)

    # Create new client for this user
    headers: dict[str, str] = {
        "Accept": "application/json",
    }

    if token:
        headers["Authorization"] = f"Bearer {token}"
    elif username and password:
        credentials = base64.b64encode(f"{username}:{password}".encode()).decode()
        headers["Authorization"] = f"Basic {credentials}"
    else:
        raise RuntimeError(
            "Confluence credentials not provided. Set CONFLUENCE_PERSONAL_TOKEN "
            "or CONFLUENCE_USERNAME + CONFLUENCE_PASSWORD."
        )

    proxy = HTTPS_PROXY or HTTP_PROXY

    session = niquests.AsyncSession(
        multiplexed=True,
        timeout=TIMEOUT_CONFIG,
        headers=headers,
        pool_connections=25,
        pool_maxsize=25,
        happy_eyeballs=True,
    )
    session.verify = _build_ssl_context()  # ty: ignore[invalid-assignment]  # niquests accepts SSLContext at runtime
    session.base_url = url.rstrip("/")

    if proxy:
        session.proxies.update({"http": proxy, "https": proxy})

    _user_clients[cache_key] = session
    _user_client_times[cache_key] = current_time
    return session


async def get_client() -> niquests.AsyncSession:
    """Return the HTTP client for the current request context.

    In remote mode (HTTP headers present), returns a per-user cached client.
    In local mode (no headers), returns the shared singleton.
    """
    # Check if we're in remote mode (per-request credentials)
    req_url = _req_confluence_url.get()
    req_token = _req_confluence_token.get()
    req_username = _req_confluence_username.get()
    req_password = _req_confluence_password.get()

    if req_url:
        # Remote mode: create/retrieve per-user client
        return await _get_user_client(req_url, req_token, req_username, req_password)

    # Local mode: singleton (existing behavior, unchanged)
    return await _get_singleton_client()


def _build_ssl_context() -> ssl.SSLContext:
    """Build the SSL context used by the shared HTTP client.

    Policy:
      * ``SSL_VERIFY=False`` -> permissive context (CERT_NONE, no hostname check).
      * ``SSL_VERIFY=True`` (default) -> ``truststore.SSLContext`` backed by the
        operating system trust store (macOS Keychain, Windows Cert Store,
        OpenSSL paths on Linux).
      * If ``SSL_PATH`` is set, it is loaded *in addition to* the system
        trust store as an extra CA source (PEM file or OpenSSL-hashed dir).
    """
    if SSL_VERIFY is False:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        return ctx

    # Default: system trust store via truststore.
    ctx = truststore.SSLContext(ssl.PROTOCOL_TLS_CLIENT)

    if SSL_PATH:
        p = Path(SSL_PATH).expanduser()
        if not p.exists():
            raise RuntimeError(
                f"CONFLUENCE_SSL_PATH points to a non-existent path: {p}"
            )
        try:
            if p.is_dir():
                ctx.load_verify_locations(capath=os.fspath(p))
            else:
                ctx.load_verify_locations(cafile=os.fspath(p))
        except ssl.SSLError as exc:
            raise RuntimeError(f"Failed to load CA bundle from {p}: {exc}") from exc

    return ctx


async def close_client() -> None:
    """Close the shared HTTP client."""
    global _CLIENT
    async with _CLIENT_LOCK:
        try:
            if _CLIENT is not None:
                await _CLIENT.close()
        finally:
            _CLIENT = None


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def api_path(path: str, version: str = API_VERSION) -> str:
    """Prepend the REST API prefix with optional version segment.

    Args:
        path: The API path to prepend the prefix to.
        version: API version (default from ``CONFLUENCE_API_VERSION``).
            ``"latest"`` or empty string omits the version segment.

    Returns:
        The full API path, e.g. ``/rest/api/content`` or
        ``/rest/api/v2/content``.
    """
    if not version or version.lower() == "latest":
        return f"/rest/api{path}"
    return f"/rest/api/{version}{path}"


def safe_path_segment(segment: str) -> str:
    """URL-encode a path segment to prevent path injection via '/' or special chars.

    Args:
        segment: The path segment to URL-encode.

    Returns:
        The URL-encoded path segment with all special characters percent-encoded.
    """
    return urllib.parse.quote(str(segment), safe="")


def join_download_url(base: str, relative: str) -> str:
    """Join a base URL with a relative download path, ensuring exactly one '/'.

    Args:
        base: The base URL to join from.
        relative: The relative path to join to the base.

    Returns:
        The combined URL with exactly one '/' separator between base and relative.
    """
    base = base.rstrip("/")
    relative = relative.lstrip("/")
    return f"{base}/{relative}"


async def request(method: str, url: str, **kwargs: Any) -> Any:
    """Make an API request and return parsed JSON. Raises on HTTP errors.

    Args:
        method: HTTP method (GET, POST, PUT, DELETE, etc.).
        url: The API endpoint URL (relative to base URL).
        **kwargs: Additional arguments passed to niquests.AsyncSession.request().

    Returns:
        Parsed JSON response data, or None for 204 No Content responses.

    Raises:
        ConfluenceTimeoutError: If the request times out.
        ConfluenceNotFoundError: If the resource is not found (404).
        ConfluencePermissionError: If access is denied (403).
        ConfluenceConflictError: If there's a conflict (409).
        ConfluenceRateLimitError: If rate limited (429).
        ConfluenceAPIError: For server errors (5xx).
        ConfluenceError: For other HTTP errors or non-JSON responses.
    """
    # Apply client-side rate limiting before making the request
    limiter = await get_rate_limiter()
    await limiter.acquire()

    client = await get_client()
    full_url = f"{URL.rstrip('/')}{url}"
    resp: niquests.Response | None = None
    try:
        resp = await client.request(method, full_url, **kwargs)
        await client.gather(resp)
        resp.raise_for_status()
    except niquests.exceptions.Timeout as exc:
        raise ConfluenceTimeoutError(f"Request timed out: {exc}") from exc
    except niquests.exceptions.HTTPError as exc:
        # Get response from the exception object.
        # IMPORTANT: use `is not None` — niquests Response.__bool__ returns
        # self.ok, so bool(resp) is False for 4xx/5xx status codes.
        error_resp = exc.response
        if error_resp is None or error_resp.status_code is None:
            raise ConfluenceError("No response from server", url=full_url) from exc
        status_code = error_resp.status_code
        body = error_resp.text[:500]  # ty: ignore[not-subscriptable]  # ty fails to narrow error_resp after None guard
        error_message = f"Confluence API error {status_code}: {body}"

        if status_code == 404:
            raise ConfluenceNotFoundError(error_message, url=full_url) from exc
        elif status_code == 403:
            raise ConfluencePermissionError(error_message) from exc
        elif status_code == 409:
            raise ConfluenceConflictError(error_message) from exc
        elif status_code == 429:
            retry_after = parse_retry_after_header(
                str(error_resp.headers.get("Retry-After", ""))
            )
            raise ConfluenceRateLimitError(
                error_message, retry_after=retry_after
            ) from exc
        elif 500 <= status_code < 600:
            raise ConfluenceAPIError(error_message, status_code=status_code) from exc
        else:
            raise ConfluenceError(
                error_message, status_code=status_code, url=full_url
            ) from exc
    except niquests.exceptions.RequestException as exc:
        raise ConfluenceError(f"Confluence request failed: {exc}") from exc

    if resp.status_code == 204 or not resp.content:
        return None
    try:
        return resp.json()
    except (json.JSONDecodeError, ValueError) as exc:
        raise ConfluenceError(
            f"Confluence returned non-JSON response (status {resp.status_code}): "
            f"{resp.text[:300]}"
        ) from exc


def parse_retry_after_header(header_value: str | None) -> float | None:
    """Parse the Retry-After header and return delay in seconds.

    The Retry-After header may contain either:
    - An integer (delta-seconds)
    - An HTTP-date (RFC 2822 format)

    Args:
        header_value: Value from Retry-After header.

    Returns:
        Delay in seconds as float, or None if parsing fails.
    """
    if not header_value:
        return None

    try:
        return float(header_value)
    except (TypeError, ValueError):
        pass

    try:
        retry_after_dt = parsedate_to_datetime(header_value)
        if retry_after_dt.tzinfo is None:
            retry_after_dt = retry_after_dt.replace(tzinfo=timezone.utc)
        delay = (retry_after_dt - datetime.now(timezone.utc)).total_seconds()
        return max(0.0, delay)
    except (ValueError, TypeError):
        return None


async def _request_with_retry(
    method: str,
    url: str,
    max_retries: int = 3,
    base_delay: float = 1.0,
    max_delay: float = 180.0,
    retryable_statuses: set[int] | None = None,
    **kwargs: Any,
) -> Any:
    """Make an API request with automatic retry on rate limit and server errors.

    This function wraps `request()` with retry logic using exponential backoff.
    It retries on:
    - 429 (Rate Limit): Respects Retry-After header if provided
    - 5xx (Server Errors): Uses exponential backoff

    Args:
        method: HTTP method (GET, POST, PUT, DELETE, etc.).
        url: The API endpoint URL (relative to base URL).
        max_retries: Maximum number of retry attempts (default: 3).
        base_delay: Base delay in seconds for exponential backoff (default: 1.0).
        max_delay: Maximum delay in seconds between retries (default: 180.0).
        retryable_statuses: Set of HTTP status codes that trigger retries
            (default: {429, 500, 502, 503, 504}).
        **kwargs: Additional arguments passed to `request()`.

    Returns:
        Parsed JSON response data, or None for 204 No Content responses.

    Raises:
        ConfluenceTimeoutError: If the request times out.
        ConfluenceNotFoundError: If the resource is not found (404).
        ConfluencePermissionError: If access is denied (403).
        ConfluenceConflictError: If there's a conflict (409).
        ConfluenceRateLimitError: If rate limited after all retries exhausted.
        ConfluenceAPIError: For server errors after all retries exhausted.
        ConfluenceError: For other HTTP errors or non-JSON responses.

    Example:
        >>> # Basic usage with defaults (3 retries, exponential backoff)
        >>> result = await _request_with_retry("GET", "/rest/api/content/123")
        >>>
        >>> # Custom retry configuration
        >>> result = await _request_with_retry(
        ...     "POST", "/rest/api/content",
        ...     max_retries=5,
        ...     base_delay=2.0,
        ...     json={"title": "Page"}
        ... )
    """
    # Default retryable statuses: 429 (rate limit) + 5xx server errors
    if retryable_statuses is None:
        retryable_statuses = {429, 500, 502, 503, 504}

    retry_config = RetryConfig(
        max_retries=max_retries,
        base_delay=base_delay,
        max_delay=max_delay,
        retryable_statuses=retryable_statuses,
    )

    # Create a closure that captures the request parameters
    async def make_request() -> Any:
        return await request(method, url, **kwargs)

    # Wrap with retry decorator
    wrapped_request = with_retry(make_request, retry_config)
    return await wrapped_request()


# ---------------------------------------------------------------------------
# Image handling constants and utilities
# ---------------------------------------------------------------------------

_IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".svg", ".bmp"}
_IMAGE_MIME_TYPES = {
    "image/png",
    "image/jpeg",
    "image/gif",
    "image/webp",
    "image/svg+xml",
    "image/bmp",
}

_MAX_IMAGE_BYTES = 10 * 1024 * 1024  # 10 MB — skip images larger than this


def is_image(mime_type: str | None, filename: str | None) -> bool:
    """Check if an attachment is an image by MIME type or filename.

    Args:
        mime_type: The MIME type of the attachment (e.g., 'image/png').
        filename: The filename of the attachment.

    Returns:
        True if the attachment appears to be an image, False otherwise.
    """
    if mime_type and mime_type.lower() in _IMAGE_MIME_TYPES:
        return True
    if filename:
        ext = Path(filename).suffix.lower()
        if ext in _IMAGE_EXTENSIONS:
            return True
    return False


def get_extension_from_mime(mime_type: str) -> str:
    """Get file extension from MIME type.

    Args:
        mime_type: The MIME type string (e.g., 'image/png', 'application/pdf').

    Returns:
        The file extension including the dot (e.g., '.png', '.pdf'), or empty
        string if MIME type is not recognized.
    """
    mime_ext_map = {
        "application/vnd.jgraph.mxfile": ".drawio",
        "application/x-drawio-draft": ".drawio",
        "image/png": ".png",
        "image/jpeg": ".jpg",
        "image/jpg": ".jpg",
        "image/gif": ".gif",
        "image/webp": ".webp",
        "image/svg+xml": ".svg",
        "image/bmp": ".bmp",
        "application/pdf": ".pdf",
        "text/plain": ".txt",
        "application/json": ".json",
        "application/xml": ".xml",
        "text/csv": ".csv",
        "application/vnd.ms-excel": ".xls",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": ".xlsx",
        "application/msword": ".doc",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document": ".docx",
        "application/vnd.ms-powerpoint": ".ppt",
        "application/vnd.openxmlformats-officedocument.presentationml.presentation": ".pptx",
        "text/markdown": ".md",
    }
    return mime_ext_map.get(mime_type.lower(), "")


# ---------------------------------------------------------------------------
# Re-exports for backward compatibility
# ---------------------------------------------------------------------------

# These are now in api/caching.py to avoid circular imports
# Keep re-exports here for backward compatibility
from .caching import get_page_cached, invalidate_page_cache  # noqa: E402

__all__ = [
    "get_client",
    "close_client",
    "get_page_cached",
    "invalidate_page_cache",
    "request",
    "_request_with_retry",
    "api_path",
    "safe_path_segment",
    "parse_retry_after_header",
    # Rate limiting
    "AsyncRateLimiter",
    "get_rate_limiter",
    # Contextvars for per-request credentials
    "_req_confluence_url",
    "_req_confluence_token",
    "_req_confluence_username",
    "_req_confluence_password",
]
