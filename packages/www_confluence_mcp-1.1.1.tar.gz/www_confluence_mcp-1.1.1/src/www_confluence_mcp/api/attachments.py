"""Attachment management operations for Confluence API client."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import niquests

from .session import (
    get_extension_from_mime,
    join_download_url,
    parse_retry_after_header,
    request,
    safe_path_segment,
    api_path,
    get_client,
)
from ..config import (
    IdLike,
    get_id,
)
from ..exceptions import (
    ConfluenceAPIError,
    ConfluenceConflictError,
    ConfluenceError,
    ConfluenceNotFoundError,
    ConfluencePermissionError,
    ConfluenceRateLimitError,
    ConfluenceTimeoutError,
)
from ..models import (
    Attachment,
    AttachmentResponse,
    AttachmentDownloadResult,
    AttachmentDeletionResult,
    AttachmentUploadResult,
    AttachmentUploadBatchResponse,
    ContentAttachmentDownloadResult,
    ContentAttachmentDownloadBatchResponse,
)
from ..utils.content import model_from_dict
from ..utils.io import atomic_write
from ..utils.pagination import paginate_all


async def get_attachments(
    page_id: IdLike,
    limit: int = 25,
    start: int = 0,
) -> AttachmentResponse:
    """List attachments on a page (v1).

    Args:
        page_id: The ID of the page to list attachments from.
            Can be a string or dict with 'id'.
        limit: Maximum number of attachments to return (default: 25).
        start: Starting index for pagination (default: 0).

    Returns:
        AttachmentResponse with results list and pagination metadata.

    Raises:
        ConfluenceError: If the API request fails.
    """
    params: dict[str, Any] = {"limit": limit, "start": start, "expand": "version"}
    data = await request(
        "GET",
        api_path(
            f"/content/{safe_path_segment(get_id(page_id, 'id'))}/child/attachment"
        ),
        params=params,
    )
    if data is None:
        return AttachmentResponse()

    results = data.get("results", [])
    attachments = [model_from_dict(Attachment, a) for a in results]

    return AttachmentResponse.model_validate(
        {
            "results": attachments,
            "start": data.get("start", 0),
            "limit": data.get("limit", 25),
            "size": data.get("size", len(attachments)),
            "_links": data.get("_links", {}),
        }
    )


async def upload_attachment(
    page_id: IdLike,
    file_path: str,
    comment: str = "",
) -> Attachment:
    """Upload a file as an attachment to a Confluence page (v1 multipart).

    Args:
        page_id: The ID of the page to upload the attachment to.
            Can be a string or dict with 'id'.
        file_path: The local filesystem path to the file to upload.
        comment: Optional comment to attach to the uploaded file.

    Returns:
        Attachment model with id, title, mediaType, and links.

    Raises:
        FileNotFoundError: If the file does not exist.
        ValueError: If the path is not a file.
        ConfluenceError: If the API request fails.
        ConfluencePermissionError: If user lacks permission to upload.
        ConfluenceConflictError: If an attachment with the same name exists.
    """
    client = await get_client()
    path = Path(file_path)

    if not path.exists():
        raise FileNotFoundError(f"File not found: {file_path}")
    if not path.is_file():
        raise ValueError(f"Path is not a file: {file_path}")

    url = api_path(
        f"/content/{safe_path_segment(get_id(page_id, 'id'))}/child/attachment"
    )

    with open(path, "rb") as fobj:
        files = {"file": (path.name, fobj)}
        data: dict[str, str] = {}
        if comment:
            data["comment"] = comment

        headers = {"X-Atlassian-Token": "no-check"}

        try:
            resp = await client.post(url, files=files, data=data, headers=headers)  # ty: ignore[invalid-argument-type]  # niquests stubs don't include tuple overload for multipart files
            await client.gather(resp)
            resp.raise_for_status()
        except niquests.exceptions.Timeout as exc:
            raise ConfluenceTimeoutError(f"Upload request timed out: {exc}") from exc
        except niquests.exceptions.HTTPError as exc:
            resp = exc.response
            if resp is None or resp.status_code is None:
                raise ConfluenceError("No response from server") from exc
            status_code = resp.status_code
            body = resp.text[:300]  # ty: ignore[not-subscriptable]  # ty fails to narrow resp after None guard
            error_message = f"Failed to upload attachment: {status_code} {body}"

            if status_code == 404:
                raise ConfluenceNotFoundError(error_message) from exc
            elif status_code == 403:
                raise ConfluencePermissionError(error_message) from exc
            elif status_code == 409:
                raise ConfluenceConflictError(error_message) from exc
            elif status_code == 429:
                retry_after = parse_retry_after_header(
                    str(resp.headers.get("Retry-After"))
                )
                raise ConfluenceRateLimitError(
                    error_message, retry_after=retry_after
                ) from exc
            elif 500 <= status_code < 600:
                raise ConfluenceAPIError(
                    error_message, status_code=status_code
                ) from exc
            else:
                raise ConfluenceError(error_message, status_code=status_code) from exc
        except niquests.exceptions.RequestException as exc:
            raise ConfluenceError(f"Failed to upload attachment: {exc}") from exc

    try:
        data = resp.json()
        results = data.get("results", [data]) if isinstance(data, dict) else [data]
        if results:
            return model_from_dict(Attachment, results[0])
        return Attachment()
    except (json.JSONDecodeError, ValueError) as exc:
        raise ConfluenceError(
            f"Confluence returned non-JSON response after upload "
            f"(status {resp.status_code}): {resp.text[:300]}"
        ) from exc
    except UnboundLocalError:
        raise ConfluenceError("Upload failed: no response received from Confluence")


async def download_attachment(
    attachment_id: IdLike,
    save_path: str,
) -> AttachmentDownloadResult:
    """Download an attachment by its content ID and save to disk (v1).

    Args:
        attachment_id: The ID of the attachment to download.
            Can be a string or dict with 'id'.
        save_path: The local filesystem path where the file should be saved.
            Must be a file path, not a directory.

    Returns:
        AttachmentDownloadResult with status, attachment_id, saved_to, and bytes.

    Raises:
        ValueError: If attachment not found or save_path is a directory.
        ConfluenceError: If the API request fails.
        ConfluenceNotFoundError: If the attachment does not exist.
        ConfluencePermissionError: If user lacks permission to download.
        ConfluenceTimeoutError: If the download request times out.
    """
    client = await get_client()

    # Get attachment metadata via v1 content endpoint
    attach_data = await request(
        "GET",
        api_path(f"/content/{safe_path_segment(get_id(attachment_id, 'id'))}"),
        params={"expand": "version"},
    )
    if attach_data is None:
        raise ValueError(f"Attachment {attachment_id} not found")

    download_link = ""
    links = attach_data.get("_links", {})
    dl = links.get("download", "")
    if dl:
        download_link = join_download_url(str(client.base_url), dl)

    if not download_link:
        raise ValueError(
            f"Cannot determine download URL for attachment {get_id(attachment_id, 'id')}"
        )

    target = Path(save_path).resolve()

    if target.exists() and target.is_dir():
        raise ValueError(f"save_path must be a file path, not a directory: {save_path}")

    try:
        resp = await client.get(download_link)
        await client.gather(resp)
        resp.raise_for_status()
        content = resp.content
        if content is None:
            raise ConfluenceError("Response content is empty")
        # Use atomic write to prevent partial file writes
        with atomic_write(str(target), "wb") as fout:
            fout.write(content)
        total_bytes = len(content)
    except niquests.exceptions.Timeout as exc:
        raise ConfluenceTimeoutError(f"Download request timed out: {exc}") from exc
    except niquests.exceptions.HTTPError as exc:
        resp = exc.response
        if resp is None or resp.status_code is None:
            raise ConfluenceError("No response from server") from exc
        status_code = resp.status_code
        error_message = f"Failed to download attachment: {status_code}"

        if status_code == 404:
            raise ConfluenceNotFoundError(error_message) from exc
        elif status_code == 403:
            raise ConfluencePermissionError(error_message) from exc
        elif status_code == 429:
            retry_after = parse_retry_after_header(
                str(resp.headers.get("Retry-After", ""))
            )
            raise ConfluenceRateLimitError(
                error_message, retry_after=retry_after
            ) from exc
        elif 500 <= status_code < 600:
            raise ConfluenceAPIError(error_message, status_code=status_code) from exc
        else:
            raise ConfluenceError(error_message, status_code=status_code) from exc
    except niquests.exceptions.RequestException as exc:
        raise ConfluenceError(f"Failed to download attachment: {exc}") from exc
    except OSError as exc:
        raise ConfluenceError(f"Failed to save attachment to disk: {exc}") from exc

    return AttachmentDownloadResult(
        status="downloaded",
        attachment_id=get_id(attachment_id, "id"),
        saved_to=str(target),
        bytes=total_bytes,
    )


async def delete_attachment(attachment_id: IdLike) -> AttachmentDeletionResult:
    """Delete an attachment by its content ID (v1).

    Args:
        attachment_id: The ID of the attachment to delete.
            Can be a string or dict with 'id'.

    Returns:
        AttachmentDeletionResult with status and attachment_id.

    Raises:
        ConfluenceError: If the API request fails.
        ConfluenceNotFoundError: If the attachment does not exist.
        ConfluencePermissionError: If user lacks permission to delete.
    """
    await request(
        "DELETE", api_path(f"/content/{safe_path_segment(get_id(attachment_id, 'id'))}")
    )
    return AttachmentDeletionResult(
        status="deleted",
        attachment_id=get_id(attachment_id, "id"),
    )


async def _fetch_all_attachments(page_id: IdLike) -> list[Attachment]:
    """Fetch all attachments for a page, handling v1 pagination.

    Iteratively fetches all attachments using pagination until no more
    results are available or the safety limit is reached.

    Args:
        page_id: The ID of the page to fetch attachments from.
            Can be a string or dict with 'id'.

    Returns:
        List of all Attachment models. Each attachment contains
        metadata such as id, title, extensions, and _links.
    """
    raw_results = await paginate_all(
        request,
        api_path(
            f"/content/{safe_path_segment(get_id(page_id, 'id'))}/child/attachment"
        ),
        base_params={"expand": "version"},
        max_results=20000,  # High limit to fetch all (200 iterations * 100 page_size)
        page_size=100,
    )
    return [model_from_dict(Attachment, a) for a in raw_results]


async def download_content_attachments(
    content_id: IdLike,
    save_dir: str,
) -> ContentAttachmentDownloadBatchResponse:
    """Download all attachments for a content item to a directory.

    Fetches all attachments for a page/content and downloads them to
    the specified directory, handling filename conflicts and errors.

    Args:
        content_id: The ID of the content to download attachments from.
            Can be a string or dict with 'id'.
        save_dir: The directory path where files should be saved.
            Created if it does not exist.

    Returns:
        ContentAttachmentDownloadBatchResponse with results list and summary counts.
        Each result in results contains:
        - id: Attachment ID
        - title: Attachment title
        - status: "downloaded", "skipped", or "error"
        - bytes: Number of bytes (if downloaded)
        - saved_to: Path where saved (if downloaded)
        - reason: Error/skip reason (if applicable)
    """
    client = await get_client()
    attachments = await _fetch_all_attachments(get_id(content_id, "id"))
    if not attachments:
        return ContentAttachmentDownloadBatchResponse()

    save_path = Path(save_dir)
    save_path.mkdir(parents=True, exist_ok=True)

    results: list[ContentAttachmentDownloadResult] = []
    used_names: set[str] = set()
    for att in attachments:
        att_id = att.id or "unknown"
        title = att.title or f"attachment_{att_id}"

        download_link = ""
        if att.links:
            dl = att.links.get("download", "")
            if dl:
                download_link = join_download_url(str(client.base_url), dl)

        if not download_link:
            results.append(
                ContentAttachmentDownloadResult(
                    id=att_id,
                    title=title,
                    status="skipped",
                    reason="no download URL",
                )
            )
            continue

        # Avoid overwriting files with the same name
        safe_name = Path(title).name

        # Try to get extension from MIME type if filename has no extension
        mime_type = att.mediaType or ""
        if not Path(safe_name).suffix and mime_type:
            mime_ext = get_extension_from_mime(mime_type)
            if mime_ext:
                safe_name += mime_ext

        # Guard against path traversal: reject "." and ".." names
        if safe_name in (".", ".."):
            safe_name = f"attachment_{att_id}"
        if safe_name in used_names:
            stem = Path(safe_name).stem
            suffix = Path(safe_name).suffix
            safe_name = f"{stem}_{att_id}{suffix}"
        used_names.add(safe_name)
        target = save_path / safe_name
        try:
            resp = await client.get(download_link)
            await client.gather(resp)
            resp.raise_for_status()
            content = resp.content
            if content is None:
                raise ConfluenceError("Response content is empty")
            # Use atomic write to prevent partial file writes
            with atomic_write(str(target), "wb") as fout:
                fout.write(content)
            total_bytes = len(content)
            results.append(
                ContentAttachmentDownloadResult(
                    id=att_id,
                    title=title,
                    bytes=total_bytes,
                    saved_to=str(target),
                    status="downloaded",
                )
            )
        except niquests.exceptions.RequestException as exc:
            results.append(
                ContentAttachmentDownloadResult(
                    id=att_id,
                    title=title,
                    status="error",
                    reason=str(exc),
                )
            )
        except OSError as exc:
            results.append(
                ContentAttachmentDownloadResult(
                    id=att_id,
                    title=title,
                    status="error",
                    reason=f"Disk write error: {exc}",
                )
            )

    # Calculate summary counts
    downloaded_count = sum(1 for r in results if r.status == "downloaded")
    skipped_count = sum(1 for r in results if r.status == "skipped")
    failed_count = sum(1 for r in results if r.status == "error")

    return ContentAttachmentDownloadBatchResponse(
        results=results,
        total=len(results),
        downloaded=downloaded_count,
        skipped=skipped_count,
        failed=failed_count,
    )


async def upload_attachments(
    page_id: IdLike,
    file_paths: list[str],
    comment: str = "",
) -> AttachmentUploadBatchResponse:
    """Upload multiple files as attachments to a Confluence page.

    Uploads each file individually and collects results. Continues uploading
    even if individual files fail.

    Args:
        page_id: The ID of the page to upload attachments to.
            Can be a string or dict with 'id'.
        file_paths: List of local filesystem paths to files to upload.
        comment: Optional comment to attach to all uploaded files.

    Returns:
        AttachmentUploadBatchResponse with results list and summary counts.
        Each result in results contains:
        - id: Attachment ID (if uploaded)
        - title: File/attachment title
        - status: "uploaded" or "error"
        - reason: Error description (if failed)
    """
    results: list[AttachmentUploadResult] = []
    for fp in file_paths:
        try:
            attachment = await upload_attachment(
                get_id(page_id, "id"),
                fp,
                comment=comment,
            )
            results.append(
                AttachmentUploadResult(
                    id=attachment.id,
                    title=attachment.title,
                    status="uploaded",
                )
            )
        except Exception as exc:
            if isinstance(exc, (KeyboardInterrupt, SystemExit)):
                raise
            path = Path(fp)
            results.append(
                AttachmentUploadResult(
                    title=path.name,
                    status="error",
                    reason=str(exc),
                )
            )

    # Calculate summary counts
    uploaded_count = sum(1 for r in results if r.status == "uploaded")
    failed_count = sum(1 for r in results if r.status == "error")

    return AttachmentUploadBatchResponse(
        results=results,
        total=len(results),
        uploaded=uploaded_count,
        failed=failed_count,
    )
