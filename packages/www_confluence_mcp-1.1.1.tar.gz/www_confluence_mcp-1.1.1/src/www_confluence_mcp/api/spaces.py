"""Spaces API endpoints for Confluence v1."""

from __future__ import annotations


from .session import request, safe_path_segment, api_path
from ..models import Space, SpaceResponse
from ..utils.content import model_from_dict


async def get_spaces(
    limit: int = 25,
    start: int = 0,
) -> SpaceResponse:
    """List Confluence spaces (v1).

    Args:
        limit: Maximum number of spaces to return. Defaults to 25.
        start: Starting index for pagination. Defaults to 0.

    Returns:
        SpaceResponse with results list and pagination metadata.
    """
    data = await request(
        "GET", api_path("/space"), params={"limit": limit, "start": start}
    )
    if data is None:
        return SpaceResponse()

    results = data.get("results", [])
    spaces = [model_from_dict(Space, s) for s in results]

    return SpaceResponse.model_validate(
        {
            "results": spaces,
            "start": data.get("start", 0),
            "limit": data.get("limit", 25),
            "size": data.get("size", len(spaces)),
            "_links": data.get("_links", {}),
        }
    )


async def get_space(space_key: str) -> Space:
    """Get a space by its key (v1).

    Args:
        space_key: The unique key of the space (e.g., 'PROJ', 'DEV').

    Returns:
        Space model with id, key, name, description, and links.
    """
    data = await request("GET", api_path(f"/space/{safe_path_segment(space_key)}"))
    return model_from_dict(Space, data or {})
