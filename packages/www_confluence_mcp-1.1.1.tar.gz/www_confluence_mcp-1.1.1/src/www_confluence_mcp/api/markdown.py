"""Markdown converter API integration.

Pure conversion functions only. Business logic moved to tools/write_helpers.py.
"""

from __future__ import annotations

import logging


logger = logging.getLogger("www-confluence-mcp.markdown")
