"""Page operations for Confluence API v1."""

from __future__ import annotations

from typing import Any

from .session import (
    request,
    safe_path_segment,
    api_path,
)
from ..config import (
    IdLike,
    OptIdLike,
    get_id,
)
from ..exceptions import (
    ConfluenceNotFoundError,
)
from ..models import Page, PageResponse
from ..utils.content import model_from_dict


async def get_page(
    page_id: IdLike,
    body_format: str = "storage",
) -> Page:
    """Get a page by ID (v1 content endpoint).

    Args:
        page_id: The ID of the page to retrieve. Can be a string or dict with 'id'.
        body_format: The format of the page body to expand (default: "storage").
            Common values: "storage", "view", "export_view".

    Returns:
        Page model with id, title, space, version, body, ancestors, and links.

    Raises:
        ConfluenceError: If the API request fails.
    """
    expand = f"body.{body_format},version,space,ancestors"
    data = await request(
        "GET",
        api_path(f"/content/{safe_path_segment(get_id(page_id, 'id'))}"),
        params={"expand": expand},
    )
    return model_from_dict(Page, data or {})


async def get_page_by_title(
    space_key: str,
    title: str,
    body_format: str = "storage",
) -> Page:
    """Look up a page by exact title within a space (v1).

    Args:
        space_key: The key of the space to search in.
        title: The exact title of the page to find.
        body_format: The format of the page body to expand (default: "storage").

    Returns:
        The first matching Page model.

    Raises:
        ValueError: If no page with the given title exists in the space.
    """
    results = await request(
        "GET",
        api_path("/content"),
        params={
            "spaceKey": space_key,
            "title": title,
            "expand": f"body.{body_format},version,space",
        },
    )
    if results is None:
        raise ValueError(f"Page '{title}' not found in space '{space_key}'")
    pages = results.get("results", [])
    if not pages:
        raise ValueError(f"Page '{title}' not found in space '{space_key}'")
    return model_from_dict(Page, pages[0])


async def get_pages_in_space(
    space_key: str,
    title: str | None = None,
    status: str = "current",
    limit: int = 25,
    start: int = 0,
) -> PageResponse:
    """List pages in a space (v1 content endpoint).

    Args:
        space_key: The key of the space to list pages from.
        title: Optional title filter for pages. If None, returns all pages.
        status: The status of pages to retrieve (default: "current").
            Common values: "current", "draft", "archived".
        limit: Maximum number of pages to return (default: 25).
        start: Starting index for pagination (default: 0).

    Returns:
        PageResponse with results list and pagination metadata.

    Raises:
        ConfluenceError: If the API request fails.
    """
    params: dict[str, Any] = {
        "spaceKey": space_key,
        "status": status,
        "limit": limit,
        "start": start,
        "expand": "version,space",
    }
    if title:
        params["title"] = title
    data = await request("GET", api_path("/content"), params=params)
    if data is None:
        return PageResponse()

    results = data.get("results", [])
    pages = [model_from_dict(Page, p) for p in results]

    return PageResponse.model_validate(
        {
            "results": pages,
            "start": data.get("start", 0),
            "limit": data.get("limit", 25),
            "size": data.get("size", len(pages)),
            "total": data.get("total", len(pages)),
            "_links": data.get("_links", {}),
        }
    )


async def get_child_pages(
    page_id: IdLike,
    limit: int = 25,
    start: int = 0,
) -> PageResponse:
    """Get child pages of a page (v1).

    Args:
        page_id: The ID of the parent page. Can be a string or dict with 'id'.
        limit: Maximum number of child pages to return (default: 25).
        start: Starting index for pagination (default: 0).

    Returns:
        PageResponse with child pages in results and pagination metadata.

    Raises:
        ConfluenceError: If the API request fails.
    """
    params: dict[str, Any] = {"limit": limit, "start": start, "expand": "version,space"}
    data = await request(
        "GET",
        api_path(f"/content/{safe_path_segment(get_id(page_id, 'id'))}/child/page"),
        params=params,
    )
    if data is None:
        return PageResponse()

    results = data.get("results", [])
    pages = [model_from_dict(Page, p) for p in results]

    return PageResponse.model_validate(
        {
            "results": pages,
            "start": data.get("start", 0),
            "limit": data.get("limit", 25),
            "size": data.get("size", len(pages)),
            "total": data.get("total", len(pages)),
            "_links": data.get("_links", {}),
        }
    )


async def get_page_ancestors(page_id: IdLike) -> list[dict[str, Any]]:
    """Get ancestor pages (breadcrumb) by expanding ancestors on the page (v1).

    Args:
        page_id: The ID of the page to get ancestors for.
            Can be a string or dict with 'id'.

    Returns:
        List of ancestor page dicts. Each ancestor has 'id', 'title', and 'type' fields.

    Raises:
        ConfluenceError: If the API request fails.
    """
    data = await request(
        "GET",
        api_path(f"/content/{safe_path_segment(get_id(page_id, 'id'))}"),
        params={"expand": "ancestors"},
    )
    if data is None:
        return []
    return data.get("ancestors", [])


async def create_page(
    space_key: str,
    title: str,
    body_value: str,
    parent_id: OptIdLike = None,
    body_representation: str = "storage",
    status: str = "current",
) -> Page:
    """Create a new page (v1 content endpoint).

    Args:
        space_key: The key of the space to create the page in.
        title: The title of the new page.
        body_value: The content of the page in the specified representation.
        parent_id: Optional ID of the parent page. If None, page is created at
            the space root.
        body_representation: The representation format of the body
            (default: "storage"). Common values: "storage", "wiki", "atlas_doc_format".
        status: The status of the page (default: "current").

    Returns:
        Page model with id, title, space, version, and body.

    Raises:
        ConfluenceError: If the API request fails.
        ConfluencePermissionError: If user lacks permission to create pages.
    """
    payload: dict[str, Any] = {
        "type": "page",
        "title": title,
        "space": {"key": space_key},
        "body": {
            body_representation: {
                "value": body_value,
                "representation": body_representation,
            }
        },
        "status": status,
    }
    if parent_id:
        payload["ancestors"] = [{"id": get_id(parent_id, "id")}]
    data = await request("POST", api_path("/content"), json=payload)
    return model_from_dict(Page, data or {})


async def update_page(
    page_id: IdLike,
    title: str,
    body_value: str,
    version_number: int,
    body_representation: str = "storage",
    status: str = "current",
) -> Page:
    """Update an existing page (v1 content endpoint).

    Args:
        page_id: The ID of the page to update. Can be a string or dict with 'id'.
        title: The new title of the page.
        body_value: The new content of the page.
        version_number: The next version number (must be current + 1).
        body_representation: The representation format of the body
            (default: "storage"). Common values: "storage", "wiki", "atlas_doc_format".
        status: The status of the page (default: "current").

    Returns:
        Page model with updated id, title, space, and version.

    Raises:
        ConfluenceError: If the API request fails.
        ConfluenceConflictError: If version number is incorrect.
        ConfluencePermissionError: If user lacks permission to edit the page.
    """
    payload: dict[str, Any] = {
        "type": "page",
        "title": title,
        "version": {"number": version_number, "message": "Updated via MCP"},
        "body": {
            body_representation: {
                "value": body_value,
                "representation": body_representation,
            }
        },
        "status": status,
    }
    data = await request(
        "PUT",
        api_path(f"/content/{safe_path_segment(get_id(page_id, 'id'))}"),
        json=payload,
    )
    return model_from_dict(Page, data or {})


async def delete_page(page_id: IdLike) -> None:
    """Delete a page (v1 content endpoint).

    Args:
        page_id: The ID of the page to delete. Can be a string or dict with 'id'.

    Raises:
        ConfluenceError: If the API request fails.
        ConfluenceNotFoundError: If the page does not exist.
        ConfluencePermissionError: If user lacks permission to delete the page.
    """
    await request(
        "DELETE", api_path(f"/content/{safe_path_segment(get_id(page_id, 'id'))}")
    )


async def get_page_history(page_id: str) -> dict[str, Any]:
    """Get page version history (v1 — uses content expand=version+history).

    Returns structured metadata about the page's creation and current version.
    Note: This endpoint returns only the current version info and history metadata,
    not a paginated list of historical versions. For full version history with
    pagination, use the Confluence REST API v2 history endpoint directly.

    Args:
        page_id: The ID of the page to get history for.

    Returns:
        A dictionary containing version and history metadata with keys:
        - 'page_id': The page ID
        - 'title': The page title
        - 'version': Dict with number, by, when, message
        - 'history': Dict with created_by, created_date, last_updated_by, last_updated_date

    Raises:
        ConfluenceError: If the API request fails.
    """
    data = await request(
        "GET",
        api_path(f"/content/{safe_path_segment(get_id(page_id, 'id'))}"),
        params={"expand": "version,history"},
    )
    if data is None:
        return {"page_id": get_id(page_id, "id"), "version": {}, "history": {}}

    version = data.get("version", {})
    history = data.get("history", {})

    return {
        "page_id": get_id(page_id, "id"),
        "title": data.get("title", ""),
        "version": {
            "number": version.get("number"),
            "by": version.get("by", {}).get("displayName", ""),
            "when": version.get("when", ""),
            "message": version.get("message", ""),
        },
        "history": {
            "created_by": history.get("createdBy", {}).get("displayName", ""),
            "created_date": history.get("createdDate", ""),
            "last_updated_by": history.get("lastUpdated", {})
            .get("by", {})
            .get("displayName", ""),
            "last_updated_date": history.get("lastUpdated", {}).get("when", ""),
        },
    }


async def move_page(
    page_id: str,
    space_key: str | None = None,
    parent_id: str | None = None,
    page_data: dict[str, Any] | None = None,
) -> Page:
    """Move a page to a different space and/or parent (v1).

    Requires the current page data to send a complete update payload.
    The caller is responsible for fetching the page data before calling this
    function. This separates concerns: fetching (GET) is done by the caller,
    moving (PUT) is done by this function.

    Args:
        page_id: The ID of the page to move.
        space_key: Optional new space key. If None, keeps current space.
        parent_id: Optional new parent page ID. If None and space_key is None,
            keeps current parent. If None but space_key is provided, page becomes
            a root page in the new space.
        page_data: Optional pre-fetched page data. If provided, uses this data
            instead of fetching internally. Must include 'body.storage', 'version',
            'space', 'title', 'ancestors', and 'status' keys.

    Returns:
        Page model with updated space and/or parent after the move.

    Raises:
        ConfluenceNotFoundError: If the page cannot be fetched.
        ConfluenceError: If the API request fails.
        ConfluencePermissionError: If user lacks permission to move the page.
    """
    # Fetch page data if not provided by caller
    if page_data is None:
        page_data = await request(
            "GET",
            api_path(f"/content/{safe_path_segment(get_id(page_id, 'id'))}"),
            params={"expand": "body.storage,version,space,ancestors"},
        )
        if not page_data:
            raise ConfluenceNotFoundError(f"Failed to fetch page {page_id} for move")

    version = page_data.get("version", {}).get("number") or 0
    body_storage = page_data.get("body", {}).get("storage", {})

    payload: dict[str, Any] = {
        "type": "page",
        "title": page_data.get("title", ""),
        "version": {"number": version + 1, "message": "Moved via MCP"},
        "body": {
            "storage": {
                "value": body_storage.get("value", ""),
                "representation": "storage",
            }
        },
        "status": page_data.get("status", "current"),
    }

    # Set space — use new space_key or keep current
    current_space = page_data.get("space", {}).get("key")
    target_space = space_key or current_space
    if target_space:
        payload["space"] = {"key": target_space}

    # Set parent — only if explicitly provided or keeping current parent
    if parent_id:
        payload["ancestors"] = [{"id": get_id(parent_id, "id")}]
    elif not space_key:
        # Keep current parent only if not changing space
        ancestors = page_data.get("ancestors", [])
        if ancestors:
            payload["ancestors"] = [{"id": ancestors[-1].get("id")}]

    data = await request(
        "PUT",
        api_path(f"/content/{safe_path_segment(get_id(page_id, 'id'))}"),
        json=payload,
    )
    return model_from_dict(Page, data or {})
