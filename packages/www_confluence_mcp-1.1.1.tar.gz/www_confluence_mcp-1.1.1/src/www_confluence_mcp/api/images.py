"""Image handling API for Confluence pages."""

from __future__ import annotations

import base64

import niquests

from .attachments import _fetch_all_attachments
from .session import (
    _IMAGE_MIME_TYPES,
    _MAX_IMAGE_BYTES,
    is_image,
    join_download_url,
    get_client,
)
from ..models import ImageResult


async def get_page_images(
    page_id: str,
) -> list[ImageResult]:
    """Get all images attached to a page, returning base64-encoded data.

    Fetches all attachments for a page, filters for images, and returns
    their base64-encoded content along with metadata.

    Args:
        page_id: The Confluence page ID to get images from.

    Returns:
        A list of ImageResult models. Each result contains:
        - id: Attachment ID
        - title: Image filename/title
        - mime_type: Resolved MIME type
        - size: Size in bytes
        - data: Base64-encoded image data
        - status: "ok", "skipped", or "error"
        - reason: Description of why it was skipped/failed (if applicable)
    """
    client = await get_client()
    attachments = await _fetch_all_attachments(page_id)
    if not attachments:
        return []

    images: list[ImageResult] = []
    for att in attachments:
        media_type = att.mediaType or ""
        filename = att.title or ""
        if not is_image(media_type, filename):
            continue

        download_link = ""
        if att.links:
            dl = att.links.get("download", "")
            if dl:
                download_link = join_download_url(str(client.base_url), dl)

        if not download_link:
            continue

        try:
            # Check size via Content-Length header before downloading the full body
            resp = await client.head(download_link)
            await client.gather(resp)
            if resp.status_code == 200:
                content_length = resp.headers.get("content-length")
                if content_length and int(content_length) > _MAX_IMAGE_BYTES:
                    images.append(
                        ImageResult(
                            id=att.id or "",
                            title=filename,
                            status="skipped",
                            reason=f"Image too large ({content_length} bytes, max {_MAX_IMAGE_BYTES})",
                        )
                    )
                    continue
            # Fallback: GET the full body and check size
            resp = await client.get(download_link)
            await client.gather(resp)
            resp.raise_for_status()
            content = resp.content
            if content is None:
                continue
            if len(content) > _MAX_IMAGE_BYTES:
                images.append(
                    ImageResult(
                        id=att.id or "",
                        title=filename,
                        status="skipped",
                        reason=f"Image too large ({len(content)} bytes, max {_MAX_IMAGE_BYTES})",
                    )
                )
                continue
            encoded = base64.b64encode(content).decode()
            resolved_mime = (
                media_type
                if media_type and media_type.lower() in _IMAGE_MIME_TYPES
                else "image/png"
            )
            images.append(
                ImageResult(
                    id=att.id or "",
                    title=filename,
                    mime_type=resolved_mime,
                    size=len(content),
                    data=encoded,
                    status="ok",
                )
            )
        except niquests.exceptions.RequestException as exc:
            images.append(
                ImageResult(
                    id=att.id or "",
                    title=filename,
                    status="error",
                    reason=str(exc),
                )
            )

    return images
