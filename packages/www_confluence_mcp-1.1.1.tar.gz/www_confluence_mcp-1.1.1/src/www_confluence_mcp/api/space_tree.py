"""Space page tree API for Confluence."""

from __future__ import annotations

from typing import Any

from .session import request, api_path
from ..utils.pagination import paginate_all


async def get_space_page_tree(
    space_key: str,
    limit: int = 500,
) -> dict[str, Any]:
    """Get hierarchical page tree for a space as a flat list (v1).

    Fetches all pages in a space and returns them sorted by hierarchy
    (depth, position, title).

    Args:
        space_key: The Confluence space key to fetch pages from.
        limit: Maximum number of pages to return (default: 500).

    Returns:
        A dict containing:
        - 'space_key': The space key
        - 'total_pages': Number of pages returned
        - 'has_more': True if there are more pages available
        - 'pages': List of page dicts, each with:
            - 'id': Page ID
            - 'title': Page title
            - 'parent_id': Parent page ID or None for root pages
            - 'position': Position in parent's children list
            - 'depth': Depth in hierarchy (0 for root pages)
    """
    # Use shared pagination helper with page_size=200 to match original behavior
    all_pages = await paginate_all(
        request,
        api_path("/content"),
        base_params={
            "spaceKey": space_key,
            "expand": "ancestors",
            "status": "current",
        },
        max_results=limit,
        page_size=200,
    )

    # Determine has_more: True if we hit the limit and there might be more
    # (we can't know for sure without an extra request, so use original logic)
    has_more = len(all_pages) >= limit

    result_pages = []
    for page in all_pages:
        page_id = page.get("id")
        title = page.get("title", "Untitled")
        position = page.get("extensions", {}).get("position")
        ancestors = page.get("ancestors", [])
        if ancestors:
            parent_id = ancestors[-1].get("id")
            depth = len(ancestors)
        else:
            parent_id = None
            depth = 0
        # Convert position to numeric if possible
        if position is not None and position != "none":
            try:
                position_val = int(position)
            except (ValueError, TypeError):
                position_val = 999999
        else:
            position_val = 999999

        result_pages.append(
            {
                "id": page_id,
                "title": title,
                "parent_id": parent_id,
                "position": position_val,
                "depth": depth,
            }
        )

    result_pages.sort(
        key=lambda p: (
            p["depth"],
            p["position"],
            p["title"],
        )
    )

    return {
        "space_key": space_key,
        "total_pages": len(result_pages),
        "has_more": has_more,
        "pages": result_pages,
    }
