"""Load external prompt definitions from a directory and register them as MCP prompts."""

from __future__ import annotations

import logging
from pathlib import Path

from .prompt_schema import (
    load_prompt_file,
    render_template,
)
from .server import mcp

logger = logging.getLogger("www-confluence-mcp")

_LOADED_PROMPTS: dict[str, dict] = {}  # name -> raw prompt data (for introspection)


def load_prompts_from_dir(prompts_dir: Path) -> int:
    """Scan *prompts_dir* for .json/.yaml/.yml files and register each as an MCP prompt.

    Returns the number of prompts successfully loaded.
    """
    global _LOADED_PROMPTS  # noqa: PLW0603

    if not prompts_dir.is_dir():
        logger.warning("Prompts directory does not exist: %s", prompts_dir)
        return 0

    count = 0
    for path in sorted(prompts_dir.iterdir()):
        if path.suffix.lower() not in (".json", ".yaml", ".yml"):
            continue
        if path.name.startswith("."):
            continue

        data = load_prompt_file(path)
        if data is None:
            continue

        name = data["name"]
        description = data["description"]
        arg_defs = data.get("arguments", [])
        template = data["template"]

        # Build a parameter-less prompt function dynamically.
        # MCP prompts with arguments use **kwargs injected by the framework.
        def _make_prompt(
            tpl: str,
            arg_names: list[str],
            doc: str,
        ) -> object:
            """Create a prompt function with the right signature for FastMCP."""

            # We accept all known args as keyword string args with default ""
            import inspect

            params = [
                inspect.Parameter(n, inspect.Parameter.KEYWORD_ONLY, default="")
                for n in arg_names
            ]
            sig = inspect.Signature(params)

            def _prompt_fn(**kwargs: str) -> str:
                return render_template(tpl, kwargs)

            _prompt_fn.__signature__ = sig  # ty: ignore[unresolved-attribute]  # dynamic attribute for MCP introspection
            _prompt_fn.__doc__ = doc
            return _prompt_fn

        fn = _make_prompt(template, [a["name"] for a in arg_defs], description)

        # Register on the MCP server
        try:
            mcp.prompt(name=name)(fn)  # ty: ignore[invalid-argument-type]  # MCP library accepts any callable at runtime
        except Exception:
            # Prompt might already be registered (built-in with same name)
            logger.warning(
                "Skipping external prompt '%s' — a prompt with this name is already registered",
                name,
            )
            continue

        _LOADED_PROMPTS[name] = data
        count += 1
        logger.info("Loaded external prompt '%s' from %s", name, path.name)

    return count


def get_loaded_prompts() -> dict[str, dict]:
    """Return a copy of currently loaded external prompt definitions."""
    return dict(_LOADED_PROMPTS)


def clear_loaded_prompts() -> None:
    """Clear the registry of loaded external prompts (for tests)."""
    global _LOADED_PROMPTS  # noqa: PLW0603
    _LOADED_PROMPTS = {}
