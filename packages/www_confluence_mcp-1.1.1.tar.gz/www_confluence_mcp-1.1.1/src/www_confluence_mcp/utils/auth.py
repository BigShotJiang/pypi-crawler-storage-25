"""Authentication helper for multi-user MCP deployments.

In remote (HTTP) mode, users pass their Confluence credentials as HTTP headers
matching the same env var names used locally:

    CONFLUENCE_URL, CONFLUENCE_PERSONAL_TOKEN,
    CONFLUENCE_USERNAME, CONFLUENCE_PASSWORD

In local (stdio) mode, these headers are absent and env vars are used directly.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from mcp.server.fastmcp import Context

logger = logging.getLogger("www-confluence-mcp")

# Header-to-contextvar mapping
_HEADER_KEYS = (
    "CONFLUENCE_URL",
    "CONFLUENCE_PERSONAL_TOKEN",
    "CONFLUENCE_USERNAME",
    "CONFLUENCE_PASSWORD",
    "CONFLUENCE_API_TOKEN",
)


async def extract_credentials(ctx: Context | None) -> None:
    """Extract Confluence credentials from MCP request headers into contextvars.

    If headers are present (HTTP mode), sets per-request contextvars.
    If absent (stdio mode), contextvars stay at their defaults (None),
    and get_client() falls back to env vars.
    """
    if ctx is None:
        return

    from ..api.session import (
        _req_confluence_url,
        _req_confluence_token,
        _req_confluence_username,
        _req_confluence_password,
    )

    try:
        request = ctx.request_context.request
        if request is None:
            return
        headers = request.headers
    except (AttributeError, LookupError):
        return

    url = headers.get("CONFLUENCE_URL") or headers.get("confluence-url")
    token = headers.get("CONFLUENCE_PERSONAL_TOKEN") or headers.get(
        "confluence-personal-token"
    )
    username = headers.get("CONFLUENCE_USERNAME") or headers.get("confluence-username")
    password = (
        headers.get("CONFLUENCE_PASSWORD")
        or headers.get("confluence-password")
        or headers.get("CONFLUENCE_API_TOKEN")
        or headers.get("confluence-api-token")
    )

    if url:
        _req_confluence_url.set(url)
    if token:
        _req_confluence_token.set(token)
    if username:
        _req_confluence_username.set(username)
    if password:
        _req_confluence_password.set(password)
