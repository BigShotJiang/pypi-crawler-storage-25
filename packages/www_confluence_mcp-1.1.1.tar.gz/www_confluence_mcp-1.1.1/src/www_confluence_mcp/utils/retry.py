"""Retry decorator with exponential backoff for async operations."""

from __future__ import annotations

import asyncio
import logging
import secrets
from dataclasses import dataclass
from functools import wraps
from typing import Any, Awaitable, Callable, Set

from www_confluence_mcp.exceptions import ConfluenceError

logger = logging.getLogger(__name__)


@dataclass
class RetryConfig:
    """Configuration for retry behavior with exponential backoff.

    Attributes:
        max_retries: Maximum number of retry attempts (default: 3).
        base_delay: Base delay in seconds for exponential backoff (default: 1.0).
        max_delay: Maximum delay in seconds between retries (default: 180.0).
        retryable_statuses: Set of HTTP status codes that trigger retries
            (default: {429, 503, 504}).
    """

    max_retries: int = 3
    base_delay: float = 1.0
    max_delay: float = 180.0
    retryable_statuses: Set[int] | None = None

    def __post_init__(self) -> None:
        """Initialize default retryable statuses if not provided."""
        if self.retryable_statuses is None:
            self.retryable_statuses = {429, 503, 504}


def _calculate_backoff(
    retry_count: int,
    backoff_factor: float = 1.0,
    backoff_jitter: float = 0.0,
    max_backoff: float | None = None,
) -> float:
    """Calculate exponential backoff delay with optional jitter.

    Args:
        retry_count: Current retry attempt number (1-indexed).
        backoff_factor: Multiplier for exponential growth (default: 1.0).
        backoff_jitter: Random jitter factor 0.0-1.0 (default: 0.0).
        max_backoff: Maximum delay to clamp to (default: None, no clamp).

    Returns:
        Delay in seconds to wait before next retry.
    """
    # Exponential backoff: base_delay * (2 ^ retry_count)
    delay = backoff_factor * (2**retry_count)

    # Add jitter if configured
    if backoff_jitter > 0:
        jitter_range = delay * backoff_jitter
        delay += secrets.SystemRandom().uniform(-jitter_range, jitter_range)

    # Clamp to max_backoff if specified
    if max_backoff is not None:
        delay = min(delay, max_backoff)

    return max(0.0, delay)


def with_retry(
    func: Callable[[], Awaitable[Any]],
    config: RetryConfig,
) -> Callable[[], Awaitable[Any]]:
    """Wrap an async function with retry logic and exponential backoff.

    This decorator retries the function on retryable HTTP status codes
    (429, 503, 504 by default) with exponential backoff between attempts.
    If the exception has a `retry_after` attribute (e.g., ConfluenceRateLimitError),
    that value is used instead of exponential backoff.

    Args:
        func: Async function to wrap (must be callable with no arguments).
        config: RetryConfig instance controlling retry behavior.

    Returns:
        Wrapped async function that implements retry logic.

    Example:
        >>> config = RetryConfig(max_retries=3, base_delay=1.0)
        >>> async def fetch_data():
        ...     # May raise ConfluenceAPIError
        ...     pass
        >>> wrapped = with_retry(fetch_data, config)
        >>> result = await wrapped()
    """

    @wraps(func)
    async def wrapper() -> Any:
        """Execute func with retry on retryable errors."""
        last_exception: ConfluenceError | None = None

        for attempt in range(config.max_retries + 1):
            try:
                return await func()
            except ConfluenceError as exc:
                last_exception = exc

                # Check if status code is retryable
                # Safely access status_code attribute - some exceptions may not have it
                status_code = getattr(exc, "status_code", None)
                if config.retryable_statuses is None:
                    raise
                if status_code is None or status_code not in config.retryable_statuses:
                    raise

                # Don't retry if we've exhausted attempts
                if attempt >= config.max_retries:
                    raise

                # Use retry_after from exception if available, otherwise exponential backoff
                retry_after = getattr(exc, "retry_after", None)
                if retry_after is not None and retry_after > 0:
                    # Respect server's retry_after, but still cap at max_delay to avoid excessive waits
                    delay = retry_after
                else:
                    delay = _calculate_backoff(
                        retry_count=attempt + 1,
                        backoff_factor=config.base_delay,
                        backoff_jitter=0.1,  # 10% jitter
                        max_backoff=config.max_delay,
                    )

                # Log retry attempt
                logger.warning(
                    "Retry %d/%d for %s: status=%d, delay=%.1fs",
                    attempt + 1,
                    config.max_retries,
                    getattr(func, "__name__", repr(func)),
                    status_code,
                    delay,
                )

                await asyncio.sleep(delay)

        # Should not reach here, but raise last exception if we do
        if last_exception is not None:
            raise last_exception
        raise RuntimeError("Unexpected retry loop exit")

    return wrapper
