"""Backward compatibility wrapper for markdown_converter.

This module re-exports the public API from utils.converter to maintain
backward compatibility with existing imports.

Deprecated: Use `from www_confluence_mcp.utils.converter import ...` instead.
"""

from __future__ import annotations

from .converter import (
    CONFLUENCE_PRESERVED,
    EMOTICON_EMOJI,
    MARKDOWN_NATIVE,
    build_frontmatter,
    markdown_to_storage,
    parse_frontmatter,
    storage_to_markdown,
    validate_roundtrip,
)

__all__ = [
    "storage_to_markdown",
    "markdown_to_storage",
    "build_frontmatter",
    "parse_frontmatter",
    "validate_roundtrip",
    "MARKDOWN_NATIVE",
    "CONFLUENCE_PRESERVED",
    "EMOTICON_EMOJI",
]
