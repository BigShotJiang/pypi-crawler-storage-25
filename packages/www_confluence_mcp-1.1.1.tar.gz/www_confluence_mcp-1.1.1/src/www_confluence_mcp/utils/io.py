"""I/O utility functions for www_confluence_mcp."""

from __future__ import annotations

import os
import tempfile
from contextlib import contextmanager
from pathlib import Path
from typing import IO, Any, Generator


def ensure_file_extension(file_path: str, extension: str) -> str:
    """Ensure a file path has the specified extension.

    If the file path does not have the specified extension,
    it will be replaced with the correct one.

    Args:
        file_path: The file path to check.
        extension: The desired extension (e.g., '.md', '.html').

    Returns:
        The file path with the correct extension.
    """
    path = Path(file_path)
    if path.suffix != extension:
        return str(path.with_suffix(extension))
    return file_path


@contextmanager
def atomic_write(file_path: str, mode: str = "wb") -> Generator[IO[Any], None, None]:
    """Context manager for atomic file writes using temporary files.

    This ensures that file writes are atomic by writing to a temporary file
    first, then renaming it to the target path. If an error occurs during
    writing, the temporary file is cleaned up and the target file is not
    modified.

    Args:
        file_path: The target file path to write to.
        mode: File mode for the temporary file (default: 'wb').

    Yields:
        A file-like object for writing.

    Example:
        >>> with atomic_write("/path/to/file.txt", "wb") as f:
        ...     f.write(b"content")
        # File is atomically written to /path/to/file.txt
    """
    target_path = Path(file_path).resolve()

    # Ensure parent directory exists
    target_path.parent.mkdir(parents=True, exist_ok=True)

    # Create temporary file in the same directory to ensure atomic rename
    temp_fd = None
    temp_path = None
    try:
        # Create temp file in same directory for atomic rename
        temp_fd, temp_path = tempfile.mkstemp(
            dir=str(target_path.parent),
            prefix=f".tmp_{target_path.name}_",
            suffix=".tmp",
        )

        # Open the temp file with the specified mode
        with os.fdopen(temp_fd, mode) as temp_file:
            temp_fd = None  # Mark as transferred to context manager
            yield temp_file

        # Atomic rename on success
        os.replace(temp_path, str(target_path))
        temp_path = None  # Mark as successfully renamed
    except Exception:
        # Clean up temp file on failure
        if temp_fd is not None:
            try:
                os.close(temp_fd)
            except OSError:
                pass
        if temp_path is not None and Path(temp_path).exists():
            try:
                Path(temp_path).unlink()
            except OSError:
                pass
        raise


def read_file_content(file_path: str) -> str:
    """Read and validate a file.

    Args:
        file_path: Path to the file to read.

    Returns:
        File content as string.

    Raises:
        FileNotFoundError: If file doesn't exist.
        PermissionError: If file is not readable.
        ValueError: If content is empty.
    """
    path = Path(file_path)
    if not path.exists():
        raise FileNotFoundError(f"File not found: {file_path}")
    try:
        content = path.read_text(encoding="utf-8")
    except PermissionError:
        raise PermissionError(f"Permission denied: {file_path}")
    if not content or not content.strip():
        raise ValueError(f"File is empty: {file_path}")
    return content
