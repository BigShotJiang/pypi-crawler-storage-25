"""Pagination utilities for Confluence API responses."""

from __future__ import annotations

from typing import Any, Awaitable, Callable
from urllib.parse import parse_qs, urlparse


def extract_next_start(links: dict[str, Any]) -> str | None:
    """Extract the next-page start offset from API _links.next (v1 pagination).

    Args:
        links: The _links dictionary from a Confluence API response.

    Returns:
        The start offset for the next page as a string, or None if no next page.
    """
    next_url = links.get("next")
    if not next_url:
        return None
    qs = parse_qs(urlparse(next_url).query)
    return qs.get("start", [None])[0]


async def paginate_all(
    request_method: Callable[..., Awaitable[Any]],
    path: str,
    base_params: dict[str, Any],
    max_results: int = 500,
    page_size: int = 50,
) -> list[dict[str, Any]]:
    """Fetch all paginated results from a Confluence API endpoint.

    This helper abstracts the common pagination loop pattern used across
    the Confluence API client, handling offset-based pagination with
    safety limits.

    Args:
        request_method: Async callable to make API requests, e.g., _request.
            Signature: method("GET", path, params=...) -> dict[str, Any]
        path: The API endpoint path (e.g., "/content").
        base_params: Base query parameters for the request.
            Must include any required params like spaceKey, expand, etc.
            The 'limit' and 'start' params are managed by this function.
        max_results: Maximum total results to fetch (default: 500).
        page_size: Number of results per page (default: 50).

    Returns:
        List of all result dictionaries from paginated responses.
    """
    all_results: list[dict[str, Any]] = []
    start = 0
    max_iterations = 500  # Safety limit

    for _ in range(max_iterations):
        if len(all_results) >= max_results:
            break

        fetch_limit = min(page_size, max_results - len(all_results))
        params = {**base_params, "limit": fetch_limit, "start": start}

        data = await request_method("GET", path, params=params)
        if data is None:
            break

        batch = data.get("results", [])
        all_results.extend(batch)

        # Check for next page via _links.next
        next_link = data.get("_links", {}).get("next")
        if not batch or not next_link:
            break

        # Parse next start offset from URL query string
        next_start = extract_next_start(data.get("_links", {}))
        if next_start is not None:
            try:
                start = int(next_start)
            except (ValueError, TypeError):
                start += len(batch)
        else:
            start += len(batch)

    return all_results
