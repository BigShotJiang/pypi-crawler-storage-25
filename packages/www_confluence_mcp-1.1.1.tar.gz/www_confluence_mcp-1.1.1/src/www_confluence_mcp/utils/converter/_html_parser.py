"""HTML parsing utilities for Confluence Storage Format conversion.

This module provides low-level HTML parsing functions used throughout
the conversion process.
"""

from __future__ import annotations

import re

from parsel import Selector


def _get_attrib(sel: Selector, name: str, default: str = "") -> str:
    """Get an attribute from a Selector with a default value.

    Args:
        sel: The selector node.
        name: Attribute name (supports 'name', 'ac:name', 'ri:name' formats).
        default: Default value if attribute not found.

    Returns:
        Attribute value or default.
    """
    # Build list of possible attribute names to try
    possible_names = [name]

    # Add namespace-prefixed variants
    if not name.startswith("ac:") and not name.startswith("ri:"):
        # Try with ac: prefix
        possible_names.append(f"ac:{name}")
        # Try with expanded ac namespace
        possible_names.append(f"{{http://atlassian.com/content}}{name}")
        # Try with ri: prefix
        possible_names.append(f"ri:{name}")
        # Try with expanded ri namespace
        possible_names.append(f"{{http://atlassian.com/resource/identifier}}{name}")
    elif name.startswith("ac:"):
        # name is like "ac:task-status"
        attr_name = name[3:]
        possible_names.append(f"ac:{attr_name}")
        possible_names.append(f"{{http://atlassian.com/content}}{attr_name}")
    elif name.startswith("ri:"):
        # name is like "ri:username"
        attr_name = name[3:]
        possible_names.append(f"ri:{attr_name}")
        possible_names.append(
            f"{{http://atlassian.com/resource/identifier}}{attr_name}"
        )

    # Try each possible name
    for possible_name in possible_names:
        value = sel.attrib.get(possible_name)
        if value is not None:
            return value

    return default


def _strip_default_namespace(html: str) -> str:
    """Strip the default XML namespace from HTML content.

    When Confluence Storage Format uses a default namespace (xmlns="..."),
    elements like <ul>, <li>, <table>, <tr>, <td>, <th> become
    {namespace}ul in the XML tree, causing xpath queries to fail.

    This function removes the default namespace declaration and normalizes
    prefixed namespace URIs to the expected values (ac: and ri:).

    Args:
        html: HTML string that may contain a default namespace.

    Returns:
        HTML string with default namespace removed and prefixed namespaces normalized.
    """
    # Match default namespace declaration: xmlns="..."
    # This regex finds xmlns="URL" that is NOT prefixed (i.e., not xmlns:ac= or xmlns:ri=)
    pattern = r'\s+xmlns="[^"]*"'
    html = re.sub(pattern, "", html)

    # Normalize ac: namespace variants to the expected URI
    # Common variants: http://www.atlassian.com/schema/confluence/4/, http://atlassian.com/content
    html = re.sub(
        r'xmlns:ac="[^"]*"',
        'xmlns:ac="http://atlassian.com/content"',
        html,
    )

    # Normalize ri: namespace variants to the expected URI
    # Common variants: http://www.atlassian.com/schema/confluence/ri/, http://atlassian.com/resource/identifier
    html = re.sub(
        r'xmlns:ri="[^"]*"',
        'xmlns:ri="http://atlassian.com/resource/identifier"',
        html,
    )

    return html
