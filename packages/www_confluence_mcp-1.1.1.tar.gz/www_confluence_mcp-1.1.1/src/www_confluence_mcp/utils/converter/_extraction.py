"""Extraction logic for preserved Confluence elements.

This module provides the stack-based parser for extracting preserved
Confluence elements from hybrid markdown, using UUID placeholders
to preserve string positions during conversion.
"""

from __future__ import annotations

import re
from typing import Any
from uuid import uuid4


def _extract_preserved_by_stack(content: str, preserved: dict[str, dict]) -> str:
    """Extract HTML comment markers using stack-based parsing.

    Uses a stack to handle nested CONFLUENCE_* comments. Replaces extracted
    elements with UUID placeholders to preserve string positions.

    Special handling for CONFLUENCE_TABLE blocks which don't have closing markers:
    - CONFLUENCE_TABLE is followed by CONFLUENCE_RAW_HTML block and markdown table
    - The block extends until the next non-table markdown line
    - CONFLUENCE_TABLE blocks are extracted FIRST to avoid conflicts with nested markers

    Args:
        content: Hybrid markdown content with comment markers.
        preserved: Dictionary to store extracted elements by UUID key.
            Each value is a dict with keys: type, attrs, content.

    Returns:
        Content with comment markers replaced by UUID placeholders.
    """
    # Regex to match opening and closing comment markers
    open_pattern = r"<!--\s*(CONFLUENCE_\w+):?\s+(.*?)\s*-->"
    close_pattern = r"<!--\s*/(CONFLUENCE_\w+)\s*-->"

    result = content

    # STEP 1: Extract CONFLUENCE_TABLE blocks FIRST (they may contain other markers)
    # Format: <!-- CONFLUENCE_TABLE attrs --> followed by <!-- CONFLUENCE_RAW_HTML\n{html}\n--> then markdown table

    # Find TABLE markers - attrs can contain | and other chars, so match until -->
    table_open_pattern = r"<!--\s*CONFLUENCE_TABLE\s+(.*?)\s*-->"

    table_elements: list[tuple[int, int, str, str]] = []  # (start, end, attrs, content)

    for match in re.finditer(table_open_pattern, content):
        table_start = match.start()
        table_attrs = match.group(1)
        table_marker_end = match.end()

        # Find the RAW_HTML block that follows
        raw_html_pattern = r"<!--\s*CONFLUENCE_RAW_HTML\s*\n(.*?)\n\s*-->"
        raw_html_match = re.search(
            raw_html_pattern, content[table_marker_end:], re.DOTALL
        )

        if not raw_html_match:
            continue

        raw_html_end = table_marker_end + raw_html_match.end()

        # Find the markdown table that follows
        # Table lines start with | and continue until a non-table, non-empty line
        content_after = content[raw_html_end:]
        lines = content_after.split("\n")
        table_md_end = raw_html_end
        last_non_empty_end = raw_html_end

        for i, line in enumerate(lines):
            stripped = line.strip()

            # Table line
            if stripped.startswith("|"):
                table_md_end = raw_html_end + sum(
                    len(line) + 1 for line in lines[: i + 1]
                )
                last_non_empty_end = table_md_end
                continue

            # Empty lines are OK within table, but don't update last_non_empty_end
            if not stripped:
                table_md_end = raw_html_end + sum(
                    len(line) + 1 for line in lines[: i + 1]
                )
                continue

            # Non-table content - stop
            break

        # Use last_non_empty_end to avoid consuming trailing blank lines
        # This preserves blank lines after tables for proper markdown parsing
        table_md_end = last_non_empty_end

        # Extract content from after TABLE marker to end of markdown table
        elem_content = content[table_marker_end:table_md_end].strip()
        table_elements.append((table_start, table_md_end, table_attrs, elem_content))

    # Replace table elements FIRST (in reverse order to preserve positions)
    table_elements.sort(key=lambda x: x[0], reverse=True)
    for start, end, attrs, elem_content in table_elements:
        uuid = uuid4().hex
        placeholder = f"{{{{{uuid}}}}}"
        preserved[placeholder] = {
            "type": "CONFLUENCE_TABLE",
            "attrs": attrs,
            "content": elem_content,
        }
        result = result[:start] + placeholder + result[end:]

    # Ensure table placeholders are followed by a blank line (\n\n) so
    # markdown treats the placeholder as a separate block element.
    # Without this, the placeholder and the next line merge into one
    # paragraph, causing orphan </p> tags after post-processing.
    for placeholder in preserved:
        if preserved[placeholder]["type"] != "CONFLUENCE_TABLE":
            continue
        idx = result.find(placeholder)
        if idx < 0:
            continue
        after = idx + len(placeholder)
        if after >= len(result):
            continue
        # If followed by exactly one \n (no blank line), add another \n
        if result[after] == "\n" and (
            after + 1 >= len(result) or result[after + 1] != "\n"
        ):
            result = result[:after] + "\n" + result[after:]

    # STEP 2: Extract other CONFLUENCE_* blocks from the modified content
    elements: list[tuple[int, int, str, str, str]] = []
    stack: list[tuple[int, str, str, int]] = []

    # Find all matches in the MODIFIED content
    open_matches = list(re.finditer(open_pattern, result, re.DOTALL))
    close_matches = list(re.finditer(close_pattern, result))

    events: list[tuple[int, int, Any]] = []
    for match in open_matches:
        events.append((match.start(), 0, match))
    for match in close_matches:
        events.append((match.start(), 1, match))

    events.sort(key=lambda x: x[0])

    for pos, event_type, match in events:
        if event_type == 0:  # Open marker
            tag_type = match.group(1)

            # Skip TABLE and RAW_HTML - already processed
            if tag_type in ("CONFLUENCE_TABLE", "CONFLUENCE_RAW_HTML"):
                continue

            attrs = match.group(2) or ""
            open_end = match.end()
            stack.append((pos, tag_type, attrs, open_end))
        else:  # Close marker
            tag_type = match.group(1)

            if tag_type in ("CONFLUENCE_TABLE", "CONFLUENCE_RAW_HTML"):
                continue

            close_end = match.end()

            for i in range(len(stack) - 1, -1, -1):
                if stack[i][1] == tag_type:
                    start_pos, _, start_attrs, open_end = stack.pop(i)
                    elem_content = result[open_end:pos]
                    elements.append(
                        (start_pos, close_end, tag_type, start_attrs, elem_content)
                    )
                    break

    # Replace other elements
    elements.sort(key=lambda x: x[0], reverse=True)
    for start, end, tag_type, attrs, elem_content in elements:
        uuid = uuid4().hex
        placeholder = f"{{{{{uuid}}}}}"
        preserved[placeholder] = {
            "type": tag_type,
            "attrs": attrs,
            "content": elem_content,
        }
        result = result[:start] + placeholder + result[end:]

    return result
