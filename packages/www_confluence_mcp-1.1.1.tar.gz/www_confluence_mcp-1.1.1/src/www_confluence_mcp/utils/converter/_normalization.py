"""Markdown normalization and frontmatter utilities.

This module provides functions for building and parsing YAML frontmatter,
as well as markdown normalization utilities used during conversion.
"""

from __future__ import annotations

import re
from typing import Any

import markdown as md_lib
import yaml


def build_frontmatter(page_data: dict[str, Any]) -> str:
    """Build YAML frontmatter from page data.

    Args:
        page_data: Dictionary containing page metadata with structure:
            {
                "id": str,
                "title": str,
                "space": {"key": str},
                "version": {"number": int},
            }

    Returns:
        YAML frontmatter string with --- delimiters.
    """
    confluence_meta = {
        "pageId": str(page_data.get("id", "")),
        "title": page_data.get("title", ""),
        "space": page_data.get("space", {}).get("key", ""),
        "version": page_data.get("version", {}).get("number", 0),
    }

    frontmatter_data = {"confluence": confluence_meta}

    yaml_str = yaml.dump(
        frontmatter_data,
        default_flow_style=False,
        allow_unicode=True,
        sort_keys=False,
    )

    # Ensure pageId is quoted if it looks like a number
    yaml_str = yaml_str.replace("pageId: '123'", 'pageId: "123"')

    return f"---\n{yaml_str}---\n"


def parse_frontmatter(content: str) -> tuple[dict[str, Any], str]:
    """Parse YAML frontmatter from content.

    Args:
        content: Full content string that may contain YAML frontmatter.

    Returns:
        Tuple of (metadata dict, body string). If no frontmatter found,
        returns ({}, content).
    """
    if not content.startswith("---\n"):
        return {}, content

    # Find the closing ---
    end_match = re.search(r"\n---\n", content[4:])
    if not end_match:
        return {}, content

    yaml_end = end_match.start() + 4
    yaml_str = content[4:yaml_end]

    try:
        metadata = yaml.safe_load(yaml_str) or {}
    except yaml.YAMLError:
        return {}, content

    body = content[yaml_end + 4 :]
    return metadata, body


def _markdown_to_html(md_content: str) -> str:
    """Convert markdown to HTML using the markdown library.

    Args:
        md_content: Markdown content string.

    Returns:
        HTML string.
    """
    md = md_lib.Markdown(extensions=["tables", "fenced_code", "nl2br", "sane_lists"])
    return md.convert(md_content)
