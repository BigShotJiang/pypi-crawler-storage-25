"""Constants for Confluence Storage Format to Markdown conversion.

This module defines classification sets and mappings used throughout
the conversion process.
"""

from __future__ import annotations


# Element classification sets
MARKDOWN_NATIVE: set[str] = {
    "h1",
    "h2",
    "h3",
    "h4",
    "h5",
    "h6",
    "p",
    "strong",
    "b",
    "em",
    "i",
    "code",
    "pre",
    "a",
    "ul",
    "ol",
    "li",
    "br",
    "hr",
    "blockquote",
    "time",
    # Table elements
    "table",
    "tbody",
    "thead",
    "tfoot",
    "tr",
    "th",
    "td",
    "colgroup",
    "col",
}

CONFLUENCE_PRESERVED: set[str] = {
    "ac:structured-macro",
    "ac:task-list",
    "ac:task",
    "ac:task-body",
    "ri:user",
    "ri:page",
    "ri:attachment",
    "ri:content-entity",
    "ri:blog-post",
    "ri:space",
    "ri:url",
    "ac:image",
    "ac:link",
    "ac:emoticon",
    "ac:inline-comment-marker",
    "ac:layout",
    "ac:layout-section",
    "ac:layout-cell",
    "ac:caption",
    "ac:macro",
    "ac:default-parameter",
    "ac:plain-text-link-body",
    "ac:rich-text-body",
    "ac:plain-text-body",
}

# Emoticon to emoji mapping
EMOTICON_EMOJI: dict[str, str] = {
    "smile": "😊",
    "sad": "😢",
    "tick": "✅",
    "cross": "❌",
    "warning": "⚠️",
    "info": "ℹ️",
    "light-on": "💡",
    "light-off": "💡",
    "plus": "➕",
    "minus": "➖",
    "star": "⭐",
    "heart": "❤️",
    "laugh": "😄",
    "angry": "😠",
    "confused": "😕",
    "wink": "😉",
    "thumbs-up": "👍",
    "thumbs-down": "👎",
}
