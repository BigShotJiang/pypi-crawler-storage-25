"""Confluence element preservation and restoration logic.

This module handles preservation of Confluence-specific elements during
conversion to Markdown, and their restoration during backward conversion.
Includes: task lists, images, links, emoticons, users, tables.
"""

from __future__ import annotations

import html
import re

from parsel import Selector

from ._constants import EMOTICON_EMOJI
from ._html_parser import _get_attrib
from ._macro_handler import (
    _extract_raw_html,
    _format_preserved_block,
    _parse_attrs,
    _strip_raw_html_block,
)


def _preserve_user(node: Selector) -> str:
    """Preserve a user reference element.

    Args:
        node: The user selector node.

    Returns:
        Preserved user reference as inline comment with raw HTML block.
    """
    user_xml = node.get()
    username = _get_attrib(node, "username", "")
    userkey = _get_attrib(node, "userkey", "")

    opening = f"<!-- CONFLUENCE_USER {user_xml} -->"

    # Add raw HTML block for round-trip conversion
    raw_html_block = f"<!-- CONFLUENCE_RAW_HTML\n{user_xml}\n-->"

    content = (
        f"{raw_html_block}\n@{username}"
        if username
        else f"{raw_html_block}\n@{userkey}"
    )
    closing = "<!-- /CONFLUENCE_USER -->"

    return _format_preserved_block(opening, content, closing, inline=True)


def _preserve_page_link(node: Selector) -> str:
    """Preserve a page link element.

    Args:
        node: The page link selector node. Can be ac:link, ri:page, or ac:link containing ri:page.

    Returns:
        Preserved page link as inline comment with markdown link and raw HTML block.
    """
    link_xml = node.get()

    # Determine the tag name
    tag = node.xpath("name()").get()

    content_title = ""
    space_key = ""

    # Check if the current node IS ri:page
    if tag == "ri:page":
        content_title = _get_attrib(node, "content-title", "")
        space_key = _get_attrib(node, "space-key", "")
    else:
        # Look for ri:page inside (e.g., node is ac:link)
        ri_page = node.xpath(
            ".//ri:page", namespaces={"ri": "http://atlassian.com/resource/identifier"}
        )
        if ri_page:
            content_title = _get_attrib(ri_page[0], "content-title", "")
            space_key = _get_attrib(ri_page[0], "space-key", "")

    # Build markdown link
    link_text = content_title or "Page"
    markdown_link = f"[{link_text}](page:{space_key}:{content_title})"

    opening = f"<!-- CONFLUENCE_PAGE_LINK {link_xml} -->"

    # Add raw HTML block for round-trip conversion
    raw_html_block = f"<!-- CONFLUENCE_RAW_HTML\n{link_xml}\n-->"

    full_content = f"{raw_html_block}\n{markdown_link}"
    closing = "<!-- /CONFLUENCE_PAGE_LINK -->"

    return _format_preserved_block(opening, full_content, closing, inline=True)


def _preserve_image(node: Selector) -> str:
    """Preserve an image element.

    Args:
        node: The image selector node.

    Returns:
        Preserved image as inline comment with markdown image and raw HTML block.
    """
    image_xml = node.get()

    # Find ri:attachment or ri:attachment element
    ri_attachment = node.xpath(
        ".//ri:attachment",
        namespaces={"ri": "http://atlassian.com/resource/identifier"},
    )

    filename = ""
    if ri_attachment:
        filename = _get_attrib(ri_attachment[0], "filename", "")

    # Build markdown image
    alt_text = filename or "image"
    image_path = f"attachments/{filename}" if filename else "#"
    markdown_image = f"![{alt_text}]({image_path})"

    opening = f"<!-- CONFLUENCE_IMAGE {image_xml} -->"

    # Add raw HTML block for round-trip conversion
    raw_html_block = f"<!-- CONFLUENCE_RAW_HTML\n{image_xml}\n-->"

    full_content = f"{raw_html_block}\n{markdown_image}"
    closing = "<!-- /CONFLUENCE_IMAGE -->"

    return _format_preserved_block(opening, full_content, closing, inline=True)


def _preserve_emoticon(node: Selector) -> str:
    """Preserve an emoticon element.

    Args:
        node: The emoticon selector node.

    Returns:
        Preserved emoticon as emoji or marker with raw HTML block.
    """
    emoticon_xml = node.get()
    name = _get_attrib(node, "name", "")

    # Map to emoji
    emoji = EMOTICON_EMOJI.get(name, f":{name}:")

    opening = f"<!-- CONFLUENCE_EMOTICON {emoticon_xml} -->"

    # Add raw HTML block for round-trip conversion
    raw_html_block = f"<!-- CONFLUENCE_RAW_HTML\n{emoticon_xml}\n-->"

    full_content = f"{raw_html_block}\n{emoji}"
    closing = "<!-- /CONFLUENCE_EMOTICON -->"

    return _format_preserved_block(opening, full_content, closing, inline=True)


def _preserve_task_list(node: Selector) -> str:
    """Preserve a task list element.

    Args:
        node: The task list selector node.

    Returns:
        Preserved task list as markdown checkboxes with raw HTML block.
    """
    tasks = node.xpath(".//ac:task", namespaces={"ac": "http://atlassian.com/content"})

    lines = []
    for task in tasks:
        status = _get_attrib(task, "task-status", "incomplete")
        task_id = _get_attrib(task, "task-id", "")

        # Get task body
        task_body = task.xpath(
            ".//ac:task-body", namespaces={"ac": "http://atlassian.com/content"}
        )
        body = ""
        if task_body:
            text = task_body[0].xpath("string()").get()
            if text:
                body = text.strip()

        # Checkbox
        checkbox = "[x]" if status == "complete" else "[ ]"

        # Format task line (no double space for empty body)
        task_line = f"{checkbox} {body}" if body else checkbox

        # Add task-id comment
        if task_id:
            task_line = f"{task_line} <!-- task-id: {task_id} -->"

        lines.append(task_line)

    # Get raw task list HTML for round-trip conversion
    task_list_xml = node.get()
    raw_html_block = f"<!-- CONFLUENCE_RAW_HTML\n{task_list_xml}\n-->"

    # Wrap with task list markers and raw HTML
    opening = f"<!-- CONFLUENCE_TASKS {task_list_xml} -->"
    closing = "<!-- /CONFLUENCE_TASKS -->"

    full_content = f"{raw_html_block}\n" + "\n".join(lines)
    return _format_preserved_block(opening, full_content, closing)


def _preserve_task(node: Selector) -> str:
    """Preserve a single task element.

    Args:
        node: The task selector node.

    Returns:
        Preserved task as markdown checkbox with raw HTML block.
    """
    status = _get_attrib(node, "task-status", "incomplete")
    task_id = _get_attrib(node, "task-id", "")

    # Get task body
    task_body = node.xpath(
        ".//ac:task-body", namespaces={"ac": "http://atlassian.com/content"}
    )
    body = ""
    if task_body:
        text = task_body[0].xpath("string()").get()
        if text:
            body = text.strip()

    # Checkbox
    checkbox = "[x]" if status == "complete" else "[ ]"

    # Format task line
    task_line = f"{checkbox} {body}" if body else checkbox

    # Add task-id comment
    if task_id:
        task_line = f"{task_line} <!-- task-id: {task_id} -->"

    # Add raw HTML block for round-trip conversion
    task_xml = node.get()
    raw_html_block = f"<!-- CONFLUENCE_RAW_HTML\n{task_xml}\n-->"

    return f"{raw_html_block}\n{task_line}"


def _convert_table(node: Selector) -> str:
    """Convert an HTML table to Markdown table format.

    Args:
        node: The table selector node.

    Returns:
        Markdown table with preserved attributes in comment and raw HTML block.
    """
    # Extract table attributes for comment
    table_attrs = []
    for attr_name, attr_value in node.attrib.items():
        table_attrs.append(f'{attr_name}="{attr_value}"')

    # Extract colgroup styles
    col_styles = []
    colgroups = node.xpath(".//colgroup")
    for cg in colgroups:
        for col in cg.xpath(".//col"):
            style = _get_attrib(col, "style", "")
            if style:
                col_styles.append(style)

    # Build comment
    comment_parts = []
    if table_attrs:
        comment_parts.append(" ".join(table_attrs))
    if col_styles:
        comment_parts.append(f"colgroup: {'; '.join(col_styles)}")

    comment = f"<!-- CONFLUENCE_TABLE {' | '.join(comment_parts)} -->"

    # Get raw table HTML for round-trip conversion
    table_xml = node.get()
    raw_html_block = f"<!-- CONFLUENCE_RAW_HTML\n{table_xml}\n-->"

    # Process rows
    rows = node.xpath(".//tr")
    if not rows:
        return comment + "\n" + raw_html_block

    lines = []
    header_done = False

    for row in rows:
        cells = row.xpath(".//th|.//td")
        if not cells:
            continue

        cell_values = []
        is_header = False

        for cell in cells:
            tag_name = cell.xpath("name()").get()
            if tag_name == "th":
                is_header = True

            # Get cell content
            content = cell.xpath("string()").get()
            if content:
                content = content.strip()
            else:
                content = ""

            # Handle colspan
            colspan = _get_attrib(cell, "colspan", "")
            if colspan and colspan != "1":
                content = f"{{colspan={colspan}}} {content}"

            # Handle rowspan
            rowspan = _get_attrib(cell, "rowspan", "")
            if rowspan and rowspan != "1":
                content = f"{{rowspan={rowspan}}} {content}"

            cell_values.append(content)

        line = "| " + " | ".join(cell_values) + " |"
        lines.append(line)

        # Add separator after header
        if is_header and not header_done:
            header_done = True
            separator_parts = []
            for cell in cells:
                colspan = _get_attrib(cell, "colspan", "1")
                sep = "---"
                if colspan and colspan != "1":
                    sep = f"{{colspan={colspan}}} ---"
                separator_parts.append(sep)
            separator = "| " + " | ".join(separator_parts) + " |"
            lines.append(separator)

    return comment + "\n" + raw_html_block + "\n" + "\n".join(lines)


def _restore_user(attrs_str: str, display: str) -> str:
    """Restore a Confluence user reference.

    Args:
        attrs_str: Attribute string with userkey, username (may have ri: prefix).
        display: Display text (e.g., "@jdoe").

    Returns:
        Confluence Storage Format XML for user reference.
    """
    # If raw HTML block exists, use it directly (preserves all attributes)
    raw = _extract_raw_html(display)
    if raw:
        return raw

    # Strip raw HTML block from display if present
    display = _strip_raw_html_block(display)

    attrs = _parse_attrs(attrs_str)
    # Handle both prefixed and non-prefixed attribute names
    userkey = attrs.get("ri:userkey", attrs.get("userkey", ""))
    username = attrs.get("ri:username", attrs.get("username", ""))

    parts = ["<ac:link>"]
    parts.append("<ri:user")
    if userkey:
        parts.append(f' ri:userkey="{html.escape(userkey)}"')
    if username:
        parts.append(f' ri:username="{html.escape(username)}"')
    parts.append("/>")
    parts.append("</ac:link>")

    return "".join(parts)


def _restore_page_link(attrs_str: str, display: str) -> str:
    """Restore a Confluence page link.

    Args:
        attrs_str: Attribute string with content-title, space-key (may have ri: prefix).
        display: Display text or markdown link.

    Returns:
        Confluence Storage Format XML for page link.
    """
    # If raw HTML block exists, use it directly (preserves all attributes)
    raw = _extract_raw_html(display)
    if raw:
        return raw

    # Strip raw HTML block from display if present
    display = _strip_raw_html_block(display)

    attrs = _parse_attrs(attrs_str)
    # Handle both prefixed and non-prefixed attribute names
    content_title = attrs.get("ri:content-title", attrs.get("content-title", ""))
    space_key = attrs.get("ri:space-key", attrs.get("space-key", ""))

    parts = ["<ac:link>"]
    parts.append("<ri:page")
    if content_title:
        parts.append(f' ri:content-title="{html.escape(content_title)}"')
    if space_key:
        parts.append(f' ri:space-key="{html.escape(space_key)}"')
    parts.append("/>")
    parts.append("</ac:link>")

    return "".join(parts)


def _restore_image(attrs_str: str, display: str) -> str:
    """Restore a Confluence image element.

    Args:
        attrs_str: Attribute string with ri:filename, ri:url, etc.
        display: Markdown image syntax.

    Returns:
        Confluence Storage Format XML for image.
    """
    # If raw HTML block exists, use it directly (preserves all attributes)
    raw = _extract_raw_html(display)
    if raw:
        return raw

    # Strip raw HTML block from display if present
    display = _strip_raw_html_block(display)

    attrs = _parse_attrs(attrs_str)

    parts = ["<ac:image>"]

    # Check if it's a URL or attachment
    if "ri:url" in attrs:
        url = attrs["ri:url"]
        parts.append(f'<ri:url ri:value="{html.escape(url)}"/>')
    else:
        # Attachment
        parts.append("<ri:attachment")
        for key, value in attrs.items():
            if key.startswith("ri:"):
                attr_name = key.replace("ri:", "")
                parts.append(f' {attr_name}="{html.escape(value)}"')
        parts.append("/>")

    parts.append("</ac:image>")

    return "".join(parts)


def _restore_emoticon(attrs_str: str, display: str) -> str:
    """Restore a Confluence emoticon element.

    Args:
        attrs_str: Attribute string with ac:name (the emoticon name).
        display: Emoji or fallback text.

    Returns:
        Confluence Storage Format XML for emoticon.
    """
    # If raw HTML block exists, use it directly (preserves all attributes)
    raw = _extract_raw_html(display)
    if raw:
        return raw

    # Strip raw HTML block from display if present
    display = _strip_raw_html_block(display)

    attrs = _parse_attrs(attrs_str)
    # Handle both prefixed and non-prefixed attribute names
    name = attrs.get("ac:name", attrs.get("name", ""))

    if not name:
        # If no name in attrs, try to infer from emoji
        emoji_to_name = {v: k for k, v in EMOTICON_EMOJI.items()}
        # Extract emoji from display text
        for emoji, emoticon_name in emoji_to_name.items():
            if emoji in display:
                name = emoticon_name
                break

    parts = ["<ac:emoticon"]
    if name:
        parts.append(f' ac:name="{html.escape(name)}"')
    parts.append("/>")

    return "".join(parts)


def _restore_tasks(attrs_str: str, content: str) -> str:
    """Restore a Confluence task list from markdown checkboxes.

    Args:
        attrs_str: Unused placeholder attribute string.
        content: Markdown content with checkboxes and task-id comments.

    Returns:
        Confluence Storage Format XML for task list.
    """
    # If raw HTML block exists, use it directly (preserves all attributes)
    raw = _extract_raw_html(content)
    if raw:
        return raw

    # Strip raw HTML block from content if present
    content = _strip_raw_html_block(content)

    lines = content.strip().split("\n")
    tasks: list[tuple[str, str, str]] = []  # (status, body, task_id)

    for line in lines:
        line = line.strip()
        if not line:
            continue

        # Extract task-id if present
        task_id = ""
        task_id_match = re.search(r"<!--\s*task-id:\s*(\d+)\s*-->", line)
        if task_id_match:
            task_id = task_id_match.group(1)
            line = re.sub(r"\s*<!--\s*task-id:\s*\d+\s*-->", "", line)

        # Determine status from checkbox
        if line.startswith("- [x]"):
            status = "complete"
            body = line[5:].strip()
        elif line.startswith("- [ ]"):
            status = "incomplete"
            body = line[5:].strip()
        else:
            continue

        tasks.append((status, body, task_id))

    # Build task list XML
    parts = ["<ac:task-list>"]
    for status, body, task_id in tasks:
        parts.append(f'<ac:task ac:task-status="{status}"')
        if task_id:
            parts.append(f' ac:task-id="{task_id}"')
        parts.append(">")
        if body:
            parts.append(f"<ac:task-body>{html.escape(body)}</ac:task-body>")
        parts.append("</ac:task>")

    parts.append("</ac:task-list>")

    return "".join(parts)


def _restore_table(attrs_str: str, table_md: str) -> str:
    """Restore a Confluence HTML table from markdown table.

    Args:
        attrs_str: Attribute string with table class, styles.
        table_md: Markdown table content.

    Returns:
        HTML table element for Confluence Storage Format.
    """
    # If raw HTML block exists, use it directly (preserves all attributes)
    raw = _extract_raw_html(table_md)
    if raw:
        return raw

    # Strip raw HTML block from table_md if present
    table_md = _strip_raw_html_block(table_md)

    attrs = _parse_attrs(attrs_str)

    lines = table_md.strip().split("\n")
    if not lines:
        return "<table/>"

    # Parse table structure
    rows: list[
        list[tuple[str, str, str]]
    ] = []  # List of rows, each cell: (content, colspan, rowspan)

    for line in lines:
        line = line.strip()
        if not line:
            continue

        # Skip separator line (|---|---|)
        if re.match(r"^\|[\s\-\{:]+\|$", line):
            # Check alignment for previous row
            if rows:
                align_matches = re.findall(r":-+:|:---+|---+:|---+", line)
                for i, align in enumerate(align_matches):
                    if i < len(rows[-1]):
                        content, colspan, rowspan = rows[-1][i]
                        if ":---:" in align or ":-+: " in align:
                            pass  # Center alignment (not directly supported)
                        elif "---:" in align:
                            pass  # Right alignment
            continue

        # Parse cells
        cells = []
        cell_parts = line.split("|")
        cell_parts = [p.strip() for p in cell_parts if p.strip()]

        for cell in cell_parts:
            colspan = ""
            rowspan = ""
            content = cell

            # Check for colspan/rowspan markers
            colspan_match = re.match(r"^\{colspan=(\d+)\}\s*(.*)$", cell)
            if colspan_match:
                colspan = colspan_match.group(1)
                content = colspan_match.group(2)

            rowspan_match = re.match(r"^\{rowspan=(\d+)\}\s*(.*)$", cell)
            if rowspan_match:
                rowspan = rowspan_match.group(1)
                content = rowspan_match.group(2)

            cells.append((content, colspan, rowspan))

        if cells:
            rows.append(cells)

    if not rows:
        return "<table/>"

    # Build HTML table
    parts = ["<table"]
    for key, value in attrs.items():
        parts.append(f' {key}="{html.escape(value)}"')
    parts.append(">")

    # Add colgroup if we have alignment info
    # (simplified - full alignment support would require more complex parsing)

    for row_idx, row in enumerate(rows):
        # Skip separator row
        if all(
            content == "---" or content.startswith("{colspan=") for content, _, _ in row
        ):
            continue

        parts.append("<tr>")
        for cell_idx, (content, colspan, rowspan) in enumerate(row):
            # Determine if header row
            is_header = row_idx == 0 and not any(
                c.startswith("---") for c, _, _ in rows[row_idx] if row_idx < len(rows)
            )

            if is_header:
                parts.append("<th")
            else:
                parts.append("<td")

            if colspan:
                parts.append(f' colspan="{html.escape(colspan)}"')
            if rowspan:
                parts.append(f' rowspan="{html.escape(rowspan)}"')

            parts.append(">")
            parts.append(html.escape(content))
            parts.append("</th>" if is_header else "</td>")

        parts.append("</tr>")

    parts.append("</table>")

    return "".join(parts)


def _restore_preserved(attrs_str: str, content: str) -> str:
    """Restore a Confluence preserved element.

    For CONFLUENCE_PRESERVED, the entire XML is stored in the attrs_str.

    Args:
        attrs_str: Attribute string containing the full XML element.
        content: Unused content (empty for inline preserved elements).

    Returns:
        Original Confluence Storage Format XML.
    """
    # The XML is in attrs_str - just return it
    return attrs_str.strip()
