"""Confluence macro preservation and restoration logic.

This module handles the preservation of Confluence structured macros
during conversion to Markdown, and their restoration during backward conversion.
"""

from __future__ import annotations

import html
import re

from parsel import Selector

from ._html_parser import _get_attrib


def _format_preserved_block(
    opening: str, content: str, closing: str, inline: bool = False
) -> str:
    """Format a preserved element block.

    Args:
        opening: Opening marker or comment.
        content: Content between markers.
        closing: Closing marker or comment.
        inline: If True, format as inline (no newlines).

    Returns:
        Formatted string.
    """
    if inline:
        return f"{opening}{content}{closing}"
    return f"{opening}\n{content}\n{closing}"


def _generate_macro_preview(name: str, body: str, node: Selector) -> str:
    """Generate a readable preview for a Confluence macro.

    Args:
        name: Macro name (e.g., "info", "code", "toc").
        body: Body content of the macro.
        node: The macro selector node.

    Returns:
        Markdown preview string.
    """
    # Get title parameter if present
    title = ""
    for param in node.xpath(
        ".//ac:parameter", namespaces={"ac": "http://atlassian.com/content"}
    ):
        param_name = _get_attrib(param, "name", "")
        if param_name == "title":
            text = param.xpath("string()").get()
            if text:
                title = text
            break

    if name in ("info", "note", "tip"):
        icon = "ℹ️"
        if name == "tip":
            icon = "💡"
        preview = f"> {icon} **{title}:**\n> {body}" if title else f"> {icon}\n> {body}"
        return preview
    elif name == "warning":
        preview = f"> ⚠️ **{title}:**\n> {body}" if title else f"> ⚠️\n> {body}"
        return preview
    elif name == "code":
        # Get language parameter
        language = ""
        for param in node.xpath(
            ".//ac:parameter", namespaces={"ac": "http://atlassian.com/content"}
        ):
            param_name = _get_attrib(param, "name", "")
            if param_name == "language":
                text = param.xpath("string()").get()
                if text:
                    language = text
                break
        if language:
            return f"```{language}\n{body}\n```"
        return f"```\n{body}\n```"
    elif name == "toc":
        return "[TOC]"
    elif name == "expand":
        preview = f"> 📂 **{title}:**\n> {body}" if title else f"> 📂\n> {body}"
        return preview
    elif name == "ui-tab":
        if title:
            return f"### {title}\n\n{body}"
        return body
    elif name == "ui-tabs":
        return body  # Tabs container, content is in children
    else:
        # Generic macro preview
        if title:
            return f"> **{name}:** {title}\n> {body}"
        return f"> **{name}**\n> {body}"


def _preserve_macro(node: Selector) -> str:
    """Preserve a Confluence structured macro.

    Args:
        node: The macro selector node.

    Returns:
        Preserved macro as HTML comment with preview and raw HTML block.
    """
    # Build the full macro XML
    macro_xml = node.get()

    # Get macro name
    name = _get_attrib(node, "name", "unknown")

    # Extract body content
    body_parts = []

    # Try rich-text-body first
    rich_body = node.xpath(
        ".//ac:rich-text-body", namespaces={"ac": "http://atlassian.com/content"}
    )
    if rich_body:
        for rb in rich_body:
            # Get text content recursively
            text = rb.xpath("string()").get()
            if text:
                body_parts.append(text)

    # Try plain-text-body
    plain_body = node.xpath(
        ".//ac:plain-text-body", namespaces={"ac": "http://atlassian.com/content"}
    )
    if plain_body:
        for pb in plain_body:
            text = pb.xpath("string()").get()
            if text:
                body_parts.append(text)

    body = "\n".join(body_parts).strip()

    # Generate preview
    preview = _generate_macro_preview(name, body, node)

    # Build comment with all attributes
    opening = f"<!-- CONFLUENCE_MACRO {macro_xml} -->"

    # Add raw HTML block for round-trip conversion
    raw_html_block = f"<!-- CONFLUENCE_RAW_HTML\n{macro_xml}\n-->"

    # Combine opening comment, raw HTML, preview, and closing
    full_content = f"{raw_html_block}\n{preview}"
    closing = "<!-- /CONFLUENCE_MACRO -->"

    return _format_preserved_block(opening, full_content, closing)


def _strip_raw_html_block(content: str) -> str:
    """Strip CONFLUENCE_RAW_HTML block from content.

    Args:
        content: Content that may contain <!-- CONFLUENCE_RAW_HTML ... --> block.

    Returns:
        Content with raw HTML block removed.
    """
    # Pattern to match <!-- CONFLUENCE_RAW_HTML\n{xml}\n-->
    # The block starts with <!-- CONFLUENCE_RAW_HTML and ends with -->
    # We need to match until we find a --> that's followed by whitespace/newline
    pattern = r"<!--\s*CONFLUENCE_RAW_HTML\s*\n.*?\n\s*-->\s*\n?"
    # Use DOTALL to match across newlines
    return re.sub(pattern, "", content, flags=re.DOTALL).strip()


def _extract_raw_html(display: str) -> str | None:
    """Extract raw HTML from CONFLUENCE_RAW_HTML block if present.

    Strips Confluence editor artifact wrappers like <div class="content-wrapper">
    to produce valid XHTML.

    Args:
        display: Content that may contain <!-- CONFLUENCE_RAW_HTML ... --> block.

    Returns:
        Raw HTML string if found (with wrappers stripped), None otherwise.
    """
    match = re.search(
        r"<!--\s*CONFLUENCE_RAW_HTML\s*\n(.*?)\n\s*-->", display, re.DOTALL
    )
    if match:
        raw_html = match.group(1).strip()
        # Strip <div class="content-wrapper"> wrappers - these are Confluence
        # editor artifacts that cause invalid XHTML nesting when restored.
        # We need to remove both opening and closing tags while preserving
        # the inner content and proper tag nesting.

        # Pattern 1: <div class="content-wrapper"> or <div class="content-wrapper" title="">
        # Replace with empty string
        raw_html = re.sub(
            r'<div\s+class="content-wrapper"[^>]*>',
            "",
            raw_html,
        )

        # Pattern 2: </div> that closes content-wrapper
        # These appear before </td> or </th>
        # Just remove the </div> tag, preserve everything else
        raw_html = re.sub(
            r"</div>(\s*(?:</td>|</th>|$))",
            r"\1",
            raw_html,
        )

        # Strip <p> wrappers around self-closing Confluence elements (ac:*, ri:*)
        # These are editor artifacts that cause XHTML validation failures when
        # the outer <p> is removed by post-processing but inner </p> remains.
        raw_html = re.sub(r"<p>\s*(<(?:ac:|ri:)[^>]*?/>)\s*</p>", r"\1", raw_html)

        return raw_html
    return None


def _parse_attrs(attrs_str: str) -> dict[str, str]:
    """Parse key="value" attributes from a string.

    Handles:
    - Basic key="value" pairs
    - Equals signs inside values
    - Empty values
    - Multiple parameters with same name (preserved as-is)

    Only extracts attributes from the opening tag (up to the first '>').

    Args:
        attrs_str: String of attributes like 'ac:name="info" ac:schema-version="1"'
            or full XML element like '<ac:structured-macro ac:name="info">...</ac:structured-macro>'

    Returns:
        Dictionary of attribute key-value pairs.
    """
    result: dict[str, str] = {}

    # Extract only the opening tag (up to the first '>')
    # This prevents parsing attributes from child elements
    if "<" in attrs_str:
        # Find the opening tag
        tag_start = attrs_str.find("<")
        tag_end = attrs_str.find(">", tag_start)
        if tag_end != -1:
            attrs_str = attrs_str[tag_start : tag_end + 1]

    # Match key="value" patterns, handling = inside values
    # Pattern: word characters, hyphens, colons for key, then ="...", including = in value
    pattern = r'([\w:-]+)="([^"]*)"'

    for match in re.finditer(pattern, attrs_str):
        key = match.group(1)
        value = match.group(2)
        result[key] = value

    return result


def _restore_macro(attrs_str: str, preview: str) -> str:
    """Restore a Confluence structured macro from preserved data.

    Args:
        attrs_str: Attribute string from comment like 'ac:name="info" ac:schema-version="1"'
        preview: Markdown preview content (blockquote, code block, etc.)

    Returns:
        Confluence Storage Format XML for the macro.
    """
    # If raw HTML block exists, use it directly (preserves all attributes)
    raw = _extract_raw_html(preview)
    if raw:
        return raw

    # Strip raw HTML block from preview if present
    preview = _strip_raw_html_block(preview)

    attrs = _parse_attrs(attrs_str)
    name = attrs.get("ac:name", "unknown")

    # Build macro XML
    macro_parts = ["<ac:structured-macro"]

    # Add macro attributes
    for key, value in attrs.items():
        if key.startswith("ac:") and key != "ac:parameter:":
            macro_parts.append(f' {key}="{html.escape(value)}"')

    macro_parts.append(">")

    # Add parameters (ac:parameter:name="value" format)
    for key, value in attrs.items():
        if key.startswith("ac:parameter:"):
            param_name = key.replace("ac:parameter:", "")
            macro_parts.append(
                f'<ac:parameter ac:name="{html.escape(param_name)}">'
                f"{html.escape(value)}"
                f"</ac:parameter>"
            )

    # Add body based on macro type
    if name == "code":
        # Code macro: extract language and content from code block
        language = ""
        code_content = preview

        # Check for code block with language
        code_match = re.match(r"^```(\w*)\n?(.*?)\n?```$", preview, re.DOTALL)
        if code_match:
            language = code_match.group(1)
            code_content = code_match.group(2)

            # Add language parameter
            if language:
                macro_parts.append(
                    f'<ac:parameter ac:name="language">{html.escape(language)}</ac:parameter>'
                )

        macro_parts.append("<ac:plain-text-body>")
        macro_parts.append(html.escape(code_content))
        macro_parts.append("</ac:plain-text-body>")
    else:
        # Other macros: use rich-text-body
        macro_parts.append("<ac:rich-text-body>")
        # Convert markdown preview back to simple HTML
        body_content = preview
        # Remove blockquote markers if present
        body_content = re.sub(r"^>\s*", "", body_content, flags=re.MULTILINE)
        body_content = re.sub(
            r"^\*\*[^*]+\*\*:\s*", "", body_content, flags=re.MULTILINE
        )
        body_content = re.sub(r"^[ℹ️💡⚠️📂]\s*", "", body_content, flags=re.MULTILINE)
        body_content = body_content.strip()

        if body_content:
            macro_parts.append(f"<p>{body_content}</p>")
        macro_parts.append("</ac:rich-text-body>")

    macro_parts.append("</ac:structured-macro>")

    return "".join(macro_parts)
