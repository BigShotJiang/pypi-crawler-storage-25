"""Hybrid Confluence ↔ Markdown converter.

This module provides bidirectional conversion between Confluence Storage Format
(CSF) and Hybrid Markdown (Markdown with preserved Confluence elements).

Public API:
    - storage_to_markdown: Convert Confluence Storage Format to Markdown
    - markdown_to_storage: Convert Markdown to Confluence Storage Format
    - build_frontmatter: Build YAML frontmatter from page data
    - parse_frontmatter: Parse YAML frontmatter from content
    - validate_roundtrip: Validate round-trip conversion fidelity
"""

from __future__ import annotations

import html
import re
from typing import Any

from parsel import Selector

from ._constants import CONFLUENCE_PRESERVED, EMOTICON_EMOJI, MARKDOWN_NATIVE
from ._element_preservation import (
    _convert_table,
    _parse_attrs,
    _preserve_emoticon,
    _preserve_image,
    _preserve_page_link,
    _preserve_task,
    _preserve_task_list,
    _preserve_user,
    _restore_emoticon,
    _restore_image,
    _restore_page_link,
    _restore_preserved,
    _restore_table,
    _restore_tasks,
    _restore_user,
)
from ._extraction import _extract_preserved_by_stack
from ._html_parser import _get_attrib, _strip_default_namespace
from ._macro_handler import (
    _preserve_macro,
    _restore_macro,
)
from ._normalization import build_frontmatter, parse_frontmatter

# Re-export public API
__all__ = [
    "storage_to_markdown",
    "markdown_to_storage",
    "build_frontmatter",
    "parse_frontmatter",
    "validate_roundtrip",
    # Internal functions (for testing)
    "_parse_attrs",
    # Constants (for advanced usage)
    "MARKDOWN_NATIVE",
    "CONFLUENCE_PRESERVED",
    "EMOTICON_EMOJI",
]


# Namespace declarations for Confluence Storage Format
CSF_NAMESPACES = (
    'xmlns:ac="http://atlassian.com/content" '
    'xmlns:ri="http://atlassian.com/resource/identifier"'
)


def _process_children(node: Selector) -> str:
    """Process all children of a node.

    Args:
        node: The parent selector node.

    Returns:
        Processed children string.
    """
    parts = []

    # Use xpath("node()") to get all child nodes including text
    children = node.xpath("node()")

    for child in children:
        # Check if it's an element node by trying to get the name
        try:
            child_type = child.xpath("name()").get()
        except ValueError:
            # Text node - xpath doesn't work on text selectors
            text = child.get()
            if text:
                parts.append(text)
            continue

        if not child_type:
            # Text node
            text = child.get()
            if text:
                parts.append(text)
        else:
            # Element node
            child_sel = Selector(text=child.get(), type="xml")
            parts.append(_process_node(child_sel))

    return "".join(parts)


def _process_inline_children(node: Selector) -> str:
    """Process inline children of a node.

    Args:
        node: The parent selector node.

    Returns:
        Processed inline content string.
    """
    parts = []
    children = node.xpath("node()")

    for child in children:
        child_type = child.xpath("name()").get()

        if not child_type:
            # Text node
            text = child.get()
            if text:
                parts.append(text)
        elif child_type in MARKDOWN_NATIVE:
            child_sel = Selector(text=child.get(), type="xml")
            parts.append(_convert_to_markdown(child_sel))
        else:
            child_sel = Selector(text=child.get(), type="xml")
            parts.append(_preserve_element(child_sel))

    return "".join(parts)


def _process_node(node: Selector) -> str:
    """Process a single node in the tree.

    Args:
        node: The selector node to process.

    Returns:
        Processed node string.
    """
    tag = node.xpath("name()").get()

    if not tag:
        # Text node at root level
        text = node.get()
        return text if text else ""

    if tag in MARKDOWN_NATIVE:
        return _convert_to_markdown(node)
    elif tag in CONFLUENCE_PRESERVED or tag.startswith("ac:") or tag.startswith("ri:"):
        return _preserve_element(node)
    else:
        # Unknown element - try to process children
        return _process_children(node)


def _process_element_tree(sel: Selector) -> str:
    """Recursively process an element tree.

    Args:
        sel: The selector to process.

    Returns:
        Processed tree string.
    """
    return _process_node(sel)


def _convert_to_markdown(node: Selector) -> str:
    """Convert an HTML element to Markdown.

    Args:
        node: The selector node to convert.

    Returns:
        Markdown string.
    """
    tag_name = node.xpath("name()").get()
    if not tag_name:
        return ""

    tag = tag_name.lower()

    if tag in ("h1", "h2", "h3", "h4", "h5", "h6"):
        level = int(tag[1])
        # Check if heading has Confluence elements at ANY depth
        # (e.g. <h2><strong><ac:structured-macro/></strong></h2>)
        ac_descendants = node.xpath(
            ".//*[starts-with(name(), 'ac:') or starts-with(name(), 'ri:')]"
        )
        has_confluence_children = len(ac_descendants) > 0
        # Check for text outside Confluence elements
        plain_text = node.xpath("string()").get() or ""
        has_text_content = bool(plain_text.strip())

        if has_confluence_children:
            # Process children properly to preserve Confluence elements
            children_text = _process_children(node)
            children_text = children_text.strip()

            if not has_text_content:
                # Heading has ONLY macros — output without empty heading
                return children_text
            else:
                # Heading has both text and macros
                return "#" * level + " " + children_text
        else:
            # Simple text heading
            content = node.xpath("string()").get()
            if content:
                content = content.strip()
            else:
                content = ""
            return "#" * level + " " + content
    elif tag == "p":
        return _convert_paragraph(node)
    elif tag in ("strong", "b"):
        ac_desc = node.xpath(
            ".//*[starts-with(name(), 'ac:') or starts-with(name(), 'ri:')]"
        )
        if ac_desc:
            # Don't wrap Confluence elements in bold — <strong> is a
            # Confluence editor artifact, not intentional formatting
            return _process_inline_children(node)
        content = node.xpath("string()").get()
        return f"**{content or ''}**"
    elif tag in ("em", "i"):
        ac_desc = node.xpath(
            ".//*[starts-with(name(), 'ac:') or starts-with(name(), 'ri:')]"
        )
        if ac_desc:
            return _process_inline_children(node)
        content = node.xpath("string()").get()
        return f"*{content or ''}*"
    elif tag == "code":
        content = node.xpath("string()").get()
        return f"`{content or ''}`"
    elif tag == "a":
        href = _get_attrib(node, "href", "")
        content = node.xpath("string()").get()
        return f"[{content or ''}]({href})"
    elif tag == "time":
        datetime_attr = _get_attrib(node, "datetime", "")
        content = node.xpath("string()").get()
        if datetime_attr:
            # Use markdown link syntax so backward conversion can restore it
            return f"[{content or ''}](`{datetime_attr}`)"
        return content or ""
    elif tag == "br":
        return "  \n"
    elif tag == "hr":
        return "---"
    elif tag == "blockquote":
        content = node.xpath("string()").get()
        if content:
            content = content.strip()
        else:
            content = ""
        lines = content.split("\n")
        return "\n".join(f"> {line}" for line in lines)
    elif tag == "ul":
        return _convert_list(node, "ul", 0)
    elif tag == "ol":
        return _convert_list(node, "ol", 0)
    elif tag == "li":
        # Process children to preserve Confluence elements inside li
        # (e.g., <li>text <ac:link>...</ac:link></li>)
        content = _process_inline_children(node)
        content = content.strip()
        return f"- {content}"
    elif tag == "pre":
        content = node.xpath("string()").get()
        return f"```\n{content or ''}\n```"
    elif tag == "table":
        return _convert_table(node)
    elif tag in ("tbody", "thead", "tfoot", "colgroup", "col"):
        # Process children of table structure elements
        return _process_children(node)
    elif tag in ("tr", "th", "td"):
        # These are handled by _convert_table
        content = node.xpath("string()").get()
        return content or ""
    else:
        # Fallback: just get text content
        text = node.xpath("string()").get()
        return text or ""


def _convert_paragraph(node: Selector) -> str:
    """Convert a paragraph element with mixed content.

    Args:
        node: The paragraph selector node.

    Returns:
        Markdown paragraph string.
    """
    # Process children
    parts = []

    # Get all child nodes including text
    children = node.xpath("node()")

    for child in children:
        child_type = child.xpath("name()").get()

        if not child_type:
            # Text node
            text = child.get()
            if text:
                parts.append(text)
        elif child_type in MARKDOWN_NATIVE:
            # Markdown-native element
            child_sel = Selector(text=child.get(), type="xml")
            parts.append(_convert_to_markdown(child_sel))
        else:
            # Confluence element - preserve it
            child_sel = Selector(text=child.get(), type="xml")
            parts.append(_preserve_element(child_sel))

    return "".join(parts)


def _convert_list(node: Selector, tag: str, level: int) -> str:
    """Convert a list element (ul or ol).

    Args:
        node: The list selector node.
        tag: The list tag ("ul" or "ol").
        level: Nesting level (0-based).

    Returns:
        Markdown list string.
    """
    items = node.xpath(".//li")
    lines = []
    indent = "  " * level

    for item in items:
        # Check for nested lists
        nested_ul = item.xpath(".//ul")
        nested_ol = item.xpath(".//ol")

        # Get item text (excluding nested lists)
        item_text = ""
        for child in item.xpath("node()"):
            child_type = child.xpath("name()").get()
            if child_type not in ("ul", "ol"):
                if child_type:
                    child_sel = Selector(text=child.get(), type="xml")
                    # Use _process_node to handle Confluence elements
                    item_text += _process_node(child_sel)
                else:
                    text = child.get()
                    if text:
                        item_text += text

        item_text = item_text.strip()

        if tag == "ul":
            prefix = "-"
        else:
            # For ordered lists, we need to track numbers
            prefix = "1."

        lines.append(f"{indent}{prefix} {item_text}")

        # Process nested lists
        for nested in nested_ul:
            nested_sel = Selector(text=nested.get(), type="xml")
            lines.append(_convert_list(nested_sel, "ul", level + 1))

        for nested in nested_ol:
            nested_sel = Selector(text=nested.get(), type="xml")
            lines.append(_convert_list(nested_sel, "ol", level + 1))

    return "\n".join(lines)


def _preserve_element(node: Selector) -> str:
    """Preserve a Confluence element.

    Args:
        node: The element selector node.

    Returns:
        Preserved element string.
    """
    tag = node.xpath("name()").get()
    if not tag:
        return ""

    if tag == "ac:structured-macro":
        return _preserve_macro(node)
    elif tag == "ac:task-list":
        return _preserve_task_list(node)
    elif tag == "ac:task":
        return _preserve_task(node)
    elif tag == "ri:user":
        return _preserve_user(node)
    elif tag == "ri:page":
        return _preserve_page_link(node)
    elif tag == "ac:link":
        # ac:link may contain ri:user, ri:page, etc.
        # Check what's inside, but pass the FULL ac:link node to preserve the wrapper
        ri_user = node.xpath(
            ".//ri:user", namespaces={"ri": "http://atlassian.com/resource/identifier"}
        )
        if ri_user:
            return _preserve_user(node)  # Pass full ac:link node
        ri_page = node.xpath(
            ".//ri:page", namespaces={"ri": "http://atlassian.com/resource/identifier"}
        )
        if ri_page:
            return _preserve_page_link(node)  # Pass full ac:link node
        # Generic link
        return _preserve_page_link(node)
    elif tag == "ac:image":
        return _preserve_image(node)
    elif tag == "ac:emoticon":
        return _preserve_emoticon(node)
    else:
        # Generic preservation for unknown Confluence elements
        xml = node.get()
        opening = f"<!-- CONFLUENCE_PRESERVED {xml} -->"
        closing = "<!-- /CONFLUENCE_PRESERVED -->"
        from ._macro_handler import _format_preserved_block

        return _format_preserved_block(opening, "", closing, inline=True)


def _get_restorer_for_tag(tag_type: str):
    """Get the restoration function for a tag type.

    Args:
        tag_type: Tag type string (e.g., "CONFLUENCE_MACRO", "CONFLUENCE_USER").

    Returns:
        Restoration function or None if not found.
    """
    restorers = {
        "CONFLUENCE_MACRO": _restore_macro,
        "CONFLUENCE_TASKS": _restore_tasks,
        "CONFLUENCE_USER": _restore_user,
        "CONFLUENCE_PAGE_LINK": _restore_page_link,
        "CONFLUENCE_IMAGE": _restore_image,
        "CONFLUENCE_EMOTICON": _restore_emoticon,
        "CONFLUENCE_TABLE": _restore_table,
        "CONFLUENCE_PRESERVED": _restore_preserved,
    }
    return restorers.get(tag_type)


def storage_to_markdown(html: str, page_data: dict[str, Any]) -> str:
    """Convert Confluence Storage Format to Markdown.

    Args:
        html: Confluence Storage Format HTML string.
        page_data: Page metadata dictionary.

    Returns:
        Markdown string with frontmatter.
    """
    # Strip default namespace to prevent elements from being prefixed with {namespace}
    # This allows xpath queries like .//ul, .//li, .//table to work correctly
    html = _strip_default_namespace(html)

    # Wrap in a root element with namespace declarations to handle multiple top-level elements
    wrapped_html = (
        '<root xmlns:ac="http://atlassian.com/content" '
        'xmlns:ri="http://atlassian.com/resource/identifier">'
        f"{html}</root>"
    )

    # Parse as XML to preserve namespace prefixes
    sel = Selector(text=wrapped_html, type="xml")

    # Process the tree
    content_parts = []

    # Get all children of the root element
    root_children = sel.xpath("/root/node()")

    for child in root_children:
        try:
            child_type = child.xpath("name()").get()
        except ValueError:
            # Text node
            text = child.get()
            if text and text.strip():
                content_parts.append(text.strip())
            continue

        if child_type:
            # Element node
            child_sel = Selector(text=child.get(), type="xml")
            content_parts.append(_process_element_tree(child_sel))
        else:
            # Text node
            text = child.get()
            if text and text.strip():
                content_parts.append(text.strip())

    content = "\n\n".join(part for part in content_parts if part.strip())

    # Build frontmatter
    frontmatter = build_frontmatter(page_data)

    return frontmatter + "\n" + content


def markdown_to_storage(content: str) -> str:
    """Convert Markdown to Confluence Storage Format.

    Main entry point for backward conversion. Performs:
    1. Frontmatter parsing
    2. Preserved element extraction (stack-based parser)
    3. Markdown to HTML conversion
    4. Placeholder replacement with Confluence elements
    5. Post-processing to clean up wrappers
    6. Namespace declaration injection

    Args:
        content: Markdown content with frontmatter and comment markers.

    Returns:
        Confluence Storage Format HTML string with namespace declarations.
    """
    # Parse frontmatter
    metadata, body = parse_frontmatter(content)

    # Extract preserved elements
    preserved: dict[str, dict] = {}
    body = _extract_preserved_by_stack(body, preserved)

    # Convert markdown to HTML
    # The {{uuid}} placeholders will be passed through as text
    from ._normalization import _markdown_to_html

    html_content = _markdown_to_html(body)

    # Replace placeholders with restored elements
    # Sort by length descending to avoid partial matches
    placeholders = sorted(preserved.keys(), key=len, reverse=True)

    for placeholder in placeholders:
        elem_data = preserved[str(placeholder)]
        tag_type = elem_data["type"]
        attrs_str = elem_data["attrs"]
        elem_content = elem_data["content"]

        restorer = _get_restorer_for_tag(tag_type)
        if restorer:
            restored_xml = restorer(attrs_str, elem_content)
            # The placeholder may be wrapped in <p> or escaped - handle both
            html_content = html_content.replace(str(placeholder), restored_xml)
            # Also handle HTML-escaped version
            escaped_placeholder = html.escape(str(placeholder))
            html_content = html_content.replace(escaped_placeholder, restored_xml)

    # Post-processing: remove <p> wrappers around Confluence elements
    # Only remove wrappers around top-level Confluence elements (structured-macro, table, etc.)
    # NOT around child elements like ac:parameter
    # Match <p> with or without attributes
    # ReDoS protection: use possessive-like patterns with [^>]*? (non-greedy) and atomic groups
    html_content = re.sub(
        r"<p(?:\s[^>]*?)?>\s*(<ac:structured-macro[^>]*?>)", r"\1", html_content
    )
    html_content = re.sub(r"(</ac:structured-macro>)\s*</p>", r"\1", html_content)
    # Handle self-closing ac: tags (like ac:emoticon, ac:image)
    html_content = re.sub(
        r"(<ac:(?:emoticon|image|link)[^>]*?>\s*)</p>", r"\1", html_content
    )
    html_content = re.sub(r"<p>\s*(<ri:[^>]+/>)", r"\1", html_content)
    html_content = re.sub(r"(<ri:[^>]+/>)\s*</p>", r"\1", html_content)
    html_content = re.sub(r"<p>\s*(<table[^>]*?>)", r"\1", html_content)
    html_content = re.sub(r"(</table>)\s*</p>", r"\1", html_content)
    # Handle task lists
    html_content = re.sub(r"<p>\s*(<ac:task-list[^>]*?>)", r"\1", html_content)
    html_content = re.sub(r"(</ac:task-list>)\s*</p>", r"\1", html_content)
    # Handle orphaned </p> after self-closing ac: elements (e.g., self-closing macros)
    html_content = re.sub(
        r"(<ac:(?:structured-macro|emoticon|image|link)[^>]*?/>)\s*</p>",
        r"\1",
        html_content,
    )

    # Remove empty <p> tags that may have been left behind
    html_content = re.sub(r"<p>\s*</p>", "", html_content)

    # Restore <time> elements from markdown link pattern
    # Pattern: <a href="ISO-datetime">text</a> → <time datetime="...">text</time>
    # ISO 8601 datetime pattern: YYYY-MM-DD or YYYY-MM-DDTHH:MM:SSZ
    # ReDoS protection: non-greedy quantifiers and limited repetition
    html_content = re.sub(
        r'<a href="(\d{4}-\d{2}-\d{2}(?:T\d{2}:\d{2}:\d{2}Z)?)">([^<]*)</a>',
        r'<time datetime="\1">\2</time>',
        html_content,
    )

    # Add namespace declarations if ac: or ri: elements present
    # Instead of wrapping in <div>, add namespaces to the first ac:/ri: element
    if "ac:" in html_content or "ri:" in html_content:
        # Find the first element that uses ac: or ri: prefix and add namespaces
        # Pattern matches opening tags like <ac:... or <ri:...
        def add_namespaces_to_first_element(match):
            """Add namespace declarations to the first Confluence element."""
            opening_tag = match.group(0)
            # Check if namespaces already present
            if 'xmlns:ac="' in opening_tag or 'xmlns:ri="' in opening_tag:
                return opening_tag
            # Add namespaces after the tag name
            # Match: <ac:tagname or <ri:tagname
            return re.sub(
                r"^(<(?:ac|ri):[^>\s]*)",
                rf"\1 {CSF_NAMESPACES}",
                opening_tag,
            )

        # Find first ac: or ri: opening tag and add namespaces
        first_element_pattern = r"<(ac|ri):[^>]*>"
        match = re.search(first_element_pattern, html_content)
        if match:
            html_content = re.sub(
                first_element_pattern,
                add_namespaces_to_first_element,
                html_content,
                count=1,  # Only replace the first match
            )

    return html_content


def validate_roundtrip(
    original_html: str, restored_html: str
) -> tuple[bool, list[str]]:
    """Compare Confluence element counts before and after round-trip.

    Validates that critical Confluence elements are preserved during the
    CSF → Hybrid MD → CSF conversion cycle by comparing element counts.

    Args:
        original_html: Original Confluence Storage Format HTML.
        restored_html: HTML after round-trip conversion.

    Returns:
        Tuple of (is_valid, errors) where:
            - is_valid: True if element counts match, False otherwise
            - errors: List of error messages (empty if valid)
    """
    errors: list[str] = []

    # Count critical elements
    elements_to_check: list[tuple[str, str]] = [
        ("ac:structured-macro", "macros"),
        ("ac:image", "images"),
        ("ri:user", "users"),
        ("ri:page", "page links"),
        ("ri:attachment", "attachments"),
        ("ac:task-list", "task lists"),
    ]

    for element, name in elements_to_check:
        orig_count = original_html.count(f"<{element}")
        rest_count = restored_html.count(f"<{element}")
        if orig_count != rest_count:
            errors.append(f"{name} count mismatch: {orig_count} → {rest_count}")

    return (len(errors) == 0, errors)
