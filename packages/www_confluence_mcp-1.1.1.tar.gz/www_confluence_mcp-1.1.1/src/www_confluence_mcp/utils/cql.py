"""CQL (Confluence Query Language) utilities."""

from __future__ import annotations


def escape_cql_value(val: str) -> str:
    """Escape backslashes and double-quotes for CQL string literals.

    Args:
        val: The string value to escape for use in CQL.

    Returns:
        The escaped string safe for inclusion in CQL queries.
    """
    return val.replace("\\", "\\\\").replace('"', r"\"")
