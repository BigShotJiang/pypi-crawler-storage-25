"""Conversion metrics and observability."""

from __future__ import annotations

import logging
import time
from collections import deque
from contextlib import contextmanager
from dataclasses import dataclass, field

logger = logging.getLogger("www-confluence-mcp.converter")


@dataclass
class ConversionMetrics:
    """Metrics for Confluence ↔ Markdown conversions.

    Tracks latency, element counts, and errors. Use the track()
    context manager for automatic latency measurement.

    Note: In async context, protect mutations with asyncio.Lock.
    Current implementation is synchronous (safe for single-threaded
    use in context managers).

    Attributes:
        total_conversions: Number of completed conversions.
        total_elements_preserved: Total Confluence elements preserved.
        total_elements_converted: Total elements converted to Markdown.
        errors: List of error descriptions.
        latencies: Bounded deque of measured latencies in seconds (max 1000).
    """

    total_conversions: int = 0
    total_elements_preserved: int = 0
    total_elements_converted: int = 0
    errors: list[str] = field(default_factory=list)
    latencies: deque[float] = field(default_factory=lambda: deque(maxlen=1000))

    @contextmanager
    def track(self, page_id: str, direction: str):
        """Context manager to measure conversion latency.

        Args:
            page_id: Confluence page ID being converted.
            direction: "download" or "upload".

        Yields:
            self — for access to metrics during conversion.
        """
        start = time.monotonic()
        try:
            yield self
            self.total_conversions += 1
        except Exception as exc:
            self.errors.append(f"{direction}:{page_id}:{exc}")
            raise
        finally:
            elapsed = time.monotonic() - start
            self.latencies.append(elapsed)
            logger.info(
                "Conversion %s page=%s latency=%.3fs elements=%d",
                direction,
                page_id,
                elapsed,
                self.total_elements_preserved,
            )

    def summary(self) -> dict[str, int | float]:
        """Return summary of all collected metrics.

        Returns:
            Dict with total_conversions, avg_latency_ms,
            total_errors, elements_preserved, elements_converted.
        """
        return {
            "total_conversions": self.total_conversions,
            "avg_latency_ms": (
                (sum(self.latencies) / len(self.latencies) * 1000)
                if self.latencies
                else 0.0
            ),
            "total_errors": len(self.errors),
            "elements_preserved": self.total_elements_preserved,
            "elements_converted": self.total_elements_converted,
        }

    def reset(self) -> None:
        """Reset all metrics to zero."""
        self.total_conversions = 0
        self.total_elements_preserved = 0
        self.total_elements_converted = 0
        self.errors.clear()
        self.latencies.clear()  # deque.clear() works the same as list.clear()


# Global metrics instance
conversion_metrics = ConversionMetrics()
