"""Markdown utilities for www_confluence_mcp."""

from __future__ import annotations

import re


def strip_confluence_wrappers(text: str) -> str:
    """Strip all CONFLUENCE_* HTML comment wrappers from markdown text.

    Removes:
      - Self-closing blocks: <!-- CONFLUENCE_RAW_HTML ... -->
      - Paired blocks: <!-- CONFLUENCE_MACRO ... -->...<!-- /CONFLUENCE_MACRO -->
      - Any remaining standalone <!-- CONFLUENCE_* --> comments

    Args:
        text: Markdown text with Confluence comment wrappers.

    Returns:
        Clean markdown text without any CONFLUENCE_* comment blocks.
    """
    # Step 1: Remove CONFLUENCE_RAW_HTML blocks (self-closing, multi-line)
    text = re.sub(
        r"<!--\s*CONFLUENCE_RAW_HTML\s*\n.*?\n\s*-->", "", text, flags=re.DOTALL
    )
    # Step 2: Remove paired CONFLUENCE_* blocks (opening + content + closing)
    text = re.sub(
        r"<!--\s*CONFLUENCE_\w+[\s\S]*?-->[\s\S]*?<!--\s*/CONFLUENCE_\w+\s*-->",
        "",
        text,
    )
    # Step 3: Remove any remaining standalone CONFLUENCE_* comments
    # Use [\s\S]*? instead of [^>]* to handle XML with > inside comments
    text = re.sub(r"<!--\s*/?CONFLUENCE_[\s\S]*?-->", "", text)
    return text
