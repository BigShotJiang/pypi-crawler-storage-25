"""URL utilities for www_confluence_mcp."""

from __future__ import annotations

from urllib.parse import parse_qs, urlparse, unquote

from ..config import get_id


def parse_confluence_url(url: str) -> dict[str, str | None]:
    """Parse a Confluence URL and extract page identification.

    Supported formats:
      1. Direct pageId query param: /pages/viewpage.action?pageId=123
      2. Cloud URL with pageId: /wiki/spaces/SPACE/pages/123/Title
      3. Display URL: /display/SPACE/TITLE

    Returns:
        Dict with optional keys:
          - page_id: if format 1 or 2
          - space_key: if format 3
          - title: if format 3
    """
    parsed = urlparse(url)
    qs = parse_qs(parsed.query)

    # Format 1: ?pageId=123
    if "pageId" in qs:
        return {"page_id": qs["pageId"][0]}

    # Format 2: /wiki/spaces/SPACE/pages/123/Title
    if "/spaces/" in parsed.path and "/pages/" in parsed.path:
        parts = parsed.path.split("/")
        try:
            pages_idx = parts.index("pages")
            if pages_idx + 1 < len(parts):
                return {"page_id": parts[pages_idx + 1]}
        except ValueError:
            pass

    # Format 3: /display/SPACE/TITLE
    if "/display/" in parsed.path:
        parts = parsed.path.split("/")
        try:
            display_idx = parts.index("display")
            if display_idx + 2 < len(parts):
                space_key = parts[display_idx + 1]
                title = parts[display_idx + 2]
                # URL decode the title (replace + with space, handle % encoding)
                title = unquote(title.replace("+", " "))
                return {"space_key": space_key, "title": title}
        except ValueError:
            pass

    return {"page_id": None, "space_key": None, "title": None}


async def search_page_id(space_key: str, title: str) -> str:
    """Resolve a page ID from space key and title via Confluence API.

    Args:
        space_key: The Confluence space key.
        title: The exact page title.

    Returns:
        The page ID as a string.

    Raises:
        ValueError: If the page is not found.
    """
    from ..api.pages import get_page_by_title

    page = await get_page_by_title(space_key, title)
    return str(page.id)


async def get_page_id(value: str, name: str = "page_id") -> str:
    """Normalize a page ID value, extracting it from a Confluence URL if needed.

    Supports three URL formats:
      - ``?pageId=123`` — returns ``123``
      - ``/wiki/spaces/SPACE/pages/123/Title`` — returns ``123``
      - ``/display/SPACE/TITLE`` — calls :func:`search_page_id` via API lookup

    Args:
        value: The value to normalize. Can be a plain page ID or a Confluence URL.
        name: Parameter name used in error messages.

    Returns:
        A non-empty string page ID.

    Raises:
        ValueError: If value is blank or the page cannot be resolved.
    """
    url_indicators = ("http://", "https://", "/pages/", "/display/", "/wiki/spaces/")
    is_url = any(indicator in value for indicator in url_indicators)

    if is_url:
        parsed = parse_confluence_url(value)

        if parsed.get("page_id"):
            return get_id(parsed["page_id"], name=name)

        if parsed.get("space_key") and parsed.get("title"):
            page_id = await search_page_id(
                str(parsed["space_key"]), str(parsed["title"])
            )
            return get_id(page_id, name=name)

        raise ValueError(f"Could not extract page_id from URL: {value}")

    return get_id(value, name=name)
