"""Content utilities for Confluence page data and response formatting."""

from __future__ import annotations

from typing import Any, TypeVar


T = TypeVar("T")


def model_from_dict(model_class: type[T], data: dict[str, Any] | None) -> T:
    """Convert an API response dict to a Pydantic model.

    Args:
        model_class: The Pydantic model class to instantiate.
        data: The API response dictionary, or None.

    Returns:
        An instance of the model class. If data is None or empty,
        returns an empty model instance.
    """
    if not data:
        return model_class()
    return model_class(**data)


def to_dict(obj: Any) -> dict[str, Any]:
    """Convert a Pydantic model to dict, or return dict as-is.

    Args:
        obj: A Pydantic model or dict.

    Returns:
        A dictionary representation of the object.
    """
    if obj is None:
        return {}
    if isinstance(obj, dict):
        return obj
    if hasattr(obj, "model_dump"):
        return obj.model_dump()
    return obj


def safe_get(obj: Any, key: str, default: Any = None) -> Any:
    """Safely get a value from a dict or Pydantic model.

    Args:
        obj: A dict, Pydantic model, or None.
        key: The key/attribute name to retrieve.
        default: Default value if key is not found.

    Returns:
        The value of the key/attribute, or default if not found.
    """
    if obj is None:
        return default
    if hasattr(obj, key):
        return getattr(obj, key)
    if isinstance(obj, dict):
        return obj.get(key, default)
    return default


def extract_page_metadata(data: dict[str, Any]) -> dict[str, Any]:
    """Extract standard page metadata from a Confluence API response.

    Args:
        data: The page data dictionary from a Confluence API response.

    Returns:
        Dictionary with standardized page metadata:
            {
                "page_id": <id>,
                "title": <title>,
                "space": <space_key>,
                "version": <version_number>
            }
    """
    return {
        "page_id": data.get("id"),
        "title": data.get("title"),
        "space": data.get("space", {}).get("key", ""),
        "version": data.get("version", {}).get("number", 0),
    }
