"""Round-trip validation for Confluence ↔ Markdown conversions."""

from __future__ import annotations

import logging
import re

logger = logging.getLogger("www-confluence-mcp.roundtrip")


class RoundTripValidator:
    """Validator for round-trip Confluence ↔ Markdown conversions.

    Compares original and restored Confluence Storage Format HTML
    to ensure all critical elements survived the conversion cycle.

    Attributes:
        CRITICAL_ELEMENTS: List of Confluence XML element tags to check.
    """

    CRITICAL_ELEMENTS: list[str] = [
        "ac:structured-macro",
        "ac:task-list",
        "ri:user",
        "ri:page",
        "ri:attachment",
        "ac:image",
    ]

    def validate(self, original: str, restored: str) -> list[str]:
        """Compare original and restored HTML for critical element preservation.

        Checks:
        1. Element count parity for each CRITICAL_ELEMENTS tag.
        2. All macro-id values preserved.
        3. All task-id values preserved.

        Args:
            original: Original Confluence Storage Format HTML.
            restored: Restored Confluence Storage Format HTML.

        Returns:
            List of warning strings. Empty list means validation passed.
        """
        warnings: list[str] = []

        # 1. Check element counts
        for element in self.CRITICAL_ELEMENTS:
            orig_count = original.count(f"<{element}")
            rest_count = restored.count(f"<{element}")

            if orig_count != rest_count:
                warnings.append(
                    f"Element count mismatch for {element}: "
                    f"original={orig_count}, restored={rest_count}"
                )

        # 2. Check macro-id preservation
        orig_ids = set(re.findall(r'ac:macro-id="([^"]+)"', original))
        rest_ids = set(re.findall(r'ac:macro-id="([^"]+)"', restored))

        missing = orig_ids - rest_ids
        if missing:
            warnings.append(f"Missing macro IDs after restore: {missing}")

        # 3. Check task-id preservation
        orig_tasks = set(re.findall(r"<ac:task-id>(\d+)</ac:task-id>", original))
        rest_tasks = set(re.findall(r"<ac:task-id>(\d+)</ac:task-id>", restored))

        missing_tasks = orig_tasks - rest_tasks
        if missing_tasks:
            warnings.append(f"Missing task IDs after restore: {missing_tasks}")

        if not warnings:
            logger.info("Round-trip validation passed: all critical elements preserved")
        else:
            logger.warning(
                "Round-trip validation found %d issues: %s",
                len(warnings),
                warnings,
            )

        return warnings


# Global validator instance
roundtrip_validator = RoundTripValidator()
