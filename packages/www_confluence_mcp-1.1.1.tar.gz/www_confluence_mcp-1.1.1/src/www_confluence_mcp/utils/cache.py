"""TTL + LRU cache for Confluence pages."""

from __future__ import annotations

import asyncio
import time
from collections import OrderedDict
from typing import Any

# Threshold for triggering proactive cleanup on get()
# If cache has more than this many entries, cleanup is triggered
_CLEANUP_THRESHOLD = 64


class TTLCache:
    """TTL + LRU cache for Confluence pages.

    Thread-safe with asyncio.Lock. Expired entries are lazily evicted
    on get() and proactively evicted on set() when at capacity.

    Attributes:
        _cache: OrderedDict storing (timestamp, value) tuples.
        _maxsize: Maximum number of entries.
        _ttl: Time-to-live in seconds.
        _lock: asyncio.Lock for thread safety.
        _hits: Counter for cache hits.
        _misses: Counter for cache misses.
    """

    def __init__(self, maxsize: int = 128, ttl: int = 300) -> None:
        self._cache: OrderedDict[str, tuple[float, Any]] = OrderedDict()
        self._maxsize = maxsize
        self._ttl = ttl
        self._lock = asyncio.Lock()
        self._hits = 0
        self._misses = 0
        self._cleanup_count = 0

    async def get(self, key: str) -> Any | None:
        """Get value from cache. Returns None if missing or expired.

        Proactively cleans up expired entries if cache size exceeds
        _CLEANUP_THRESHOLD to prevent memory accumulation.
        """
        async with self._lock:
            # Proactive cleanup if cache is large
            if len(self._cache) > _CLEANUP_THRESHOLD:
                self._cleanup_expired_locked()

            if key in self._cache:
                ts, val = self._cache[key]
                if time.monotonic() - ts < self._ttl:
                    self._cache.move_to_end(key)
                    self._hits += 1
                    return val
                else:
                    del self._cache[key]
            self._misses += 1
            return None

    async def set(self, key: str, value: Any) -> None:
        """Set value in cache. Evicts LRU if at capacity.

        Also performs proactive cleanup of expired entries to prevent
        memory accumulation of stale data.
        """
        async with self._lock:
            # Proactive cleanup on set to free space
            self._cleanup_expired_locked()

            if key in self._cache:
                self._cache.move_to_end(key)
            elif len(self._cache) >= self._maxsize:
                self._cache.popitem(last=False)
            self._cache[key] = (time.monotonic(), value)

    def _cleanup_expired_locked(self) -> int:
        """Remove expired entries from cache. Must be called with lock held.

        This is a synchronous method that should only be called when
        the lock is already acquired.

        Returns:
            Number of entries removed.
        """
        current_time = time.monotonic()
        expired_keys = [
            key
            for key, (ts, _) in self._cache.items()
            if current_time - ts >= self._ttl
        ]
        for key in expired_keys:
            del self._cache[key]
        self._cleanup_count += len(expired_keys)
        return len(expired_keys)

    async def invalidate(self, key: str) -> None:
        """Remove a specific key from cache."""
        async with self._lock:
            self._cache.pop(key, None)

    async def clear(self) -> None:
        """Clear entire cache."""
        async with self._lock:
            self._cache.clear()

    async def cleanup_expired(self) -> int:
        """Remove all expired entries from the cache.

        This method can be called periodically (e.g., via a background task)
        to proactively clean up expired entries and free memory.

        Returns:
            Number of entries removed.
        """
        async with self._lock:
            return self._cleanup_expired_locked()

    @property
    def size(self) -> int:
        """Current cache size (not thread-safe, informational only)."""
        return len(self._cache)

    @property
    def cleanup_count(self) -> int:
        """Number of items removed by cleanup operations."""
        return self._cleanup_count

    async def stats(self) -> dict[str, int | float]:
        """Return cache statistics including hits, misses, and hit rate.

        Thread-safe access to counters using async lock to prevent
        race conditions during concurrent reads/writes.

        Returns:
            Dictionary with hits, misses, hit_rate (0.0-1.0), size, and cleanup_count.
        """
        async with self._lock:
            total = self._hits + self._misses
            return {
                "hits": self._hits,
                "misses": self._misses,
                "hit_rate": self._hits / total if total else 0.0,
                "size": len(self._cache),
                "cleanup_count": self._cleanup_count,
            }


# Global page cache instance
page_cache = TTLCache(maxsize=64, ttl=300)
