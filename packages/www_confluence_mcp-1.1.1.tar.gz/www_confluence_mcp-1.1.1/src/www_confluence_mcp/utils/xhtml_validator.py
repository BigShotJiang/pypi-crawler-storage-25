"""XHTML validator for Confluence API compatibility."""

from __future__ import annotations

import re


def validate_xhtml(html: str) -> tuple[bool, list[str], list[str]]:
    """Validate XHTML for Confluence API compatibility.

    Checks:
    - Tag balance (all opening tags have closing tags)
    - No <div> inside <p> (BLOCK inside INLINE)
    - Confluence-specific elements properly structured
    - Self-closing tags correct
    - CDATA sections in ac:plain-text-body

    Args:
        html: XHTML/HTML content to validate.

    Returns:
        Tuple of (is_valid, errors, info) where:
            - is_valid: True if XHTML is valid, False otherwise
            - errors: List of error messages (empty if valid)
            - info: List of informational messages
    """
    errors: list[str] = []
    info: list[str] = []

    # 1. Tag balance check
    tag_errors = _check_tag_balance(html)
    errors.extend(tag_errors)

    # 2. Block-in-inline check
    block_inline_errors = _check_block_in_inline(html)
    errors.extend(block_inline_errors)

    # 3. Confluence macros structure check
    macro_errors = _check_confluence_macros(html)
    errors.extend(macro_errors)

    # 4. Namespace declarations check (info only)
    _, ns_info = _check_namespace_declarations(html)
    info.extend(ns_info)

    # 5. CDATA sections check
    cdata_errors = _check_cdata_sections(html)
    errors.extend(cdata_errors)

    is_valid = len(errors) == 0

    return (is_valid, errors, info)


def _check_tag_balance(html: str) -> list[str]:
    """Check that all opening tags have matching closing tags.

    Uses a stack-based approach to verify tag balance.
    Handles self-closing tags and void elements.

    Args:
        html: HTML content to check.

    Returns:
        List of error messages for unbalanced tags.
    """
    errors: list[str] = []
    stack: list[tuple[str, int]] = []  # (tag_name, position)

    # Self-closing tags that don't need closing tags
    void_elements = {
        "br",
        "hr",
        "img",
        "input",
        "meta",
        "link",
        "area",
        "base",
        "col",
        "embed",
        "param",
        "source",
        "track",
        "wbr",
        # Confluence self-closing
        "ri:user",
        "ri:page",
        "ri:attachment",
        "ac:emoticon",
        "ac:image",
        "time",
    }

    # Pattern to match opening and closing tags
    # Captures: tag name, attributes, self-closing slash
    tag_pattern = re.compile(r"<(/?)([\w:]+)(?:\s[^>]*)?(\s*/)?\s*>", re.IGNORECASE)

    for match in tag_pattern.finditer(html):
        is_closing = match.group(1) == "/"
        tag_name = match.group(2).lower()
        is_self_closing = match.group(3) is not None

        if is_closing:
            # Closing tag - should match most recent opening tag
            if not stack:
                errors.append(f"Orphaned closing tag: </{tag_name}>")
            elif stack[-1][0] != tag_name:
                errors.append(
                    f"Mismatched closing tag: expected </{stack[-1][0]}>, "
                    f"found </{tag_name}>"
                )
                # Try to find if this tag exists in stack
                found_idx = None
                for i, (t, _) in enumerate(reversed(stack)):
                    if t == tag_name:
                        found_idx = len(stack) - 1 - i
                        break
                if found_idx is not None:
                    # Remove tags from found_idx to end
                    unclosed = stack[found_idx:]
                    errors.append(
                        f"Unclosed tags before </{tag_name}>: "
                        f"{', '.join(t for t, _ in unclosed)}"
                    )
                    stack = stack[:found_idx]
                else:
                    errors.append(f"Unknown closing tag: </{tag_name}>")
            else:
                stack.pop()
        elif is_self_closing or tag_name in void_elements:
            # Self-closing or void element - no need to push to stack
            pass
        else:
            # Opening tag - push to stack
            stack.append((tag_name, match.start()))

    # Report any remaining unclosed tags
    for tag_name, pos in stack:
        errors.append(f"Unclosed tag: <{tag_name}> (at position {pos})")

    return errors


def _check_block_in_inline(html: str) -> list[str]:
    """Check for block-level elements inside inline elements.

    Detects invalid nesting like:
    - <div> inside <p>
    - <table> inside <span>
    - <ul>/<ol> inside <a>

    Args:
        html: HTML content to check.

    Returns:
        List of error messages for invalid nesting.
    """
    errors: list[str] = []

    # Block-level elements
    block_elements = {
        "div",
        "p",
        "table",
        "ul",
        "ol",
        "li",
        "dl",
        "dt",
        "dd",
        "h1",
        "h2",
        "h3",
        "h4",
        "h5",
        "h6",
        "blockquote",
        "pre",
        "article",
        "section",
        "nav",
        "aside",
        "header",
        "footer",
        "main",
        "figure",
        "figcaption",
        "details",
        "summary",
    }

    # Inline elements that cannot contain blocks
    # NOTE: strong, em, span, time, a are EXCLUDED — Confluence uses them
    # as transparent wrappers that CAN contain block elements (loose XHTML)
    inline_elements = {
        "code",
        "b",
        "i",
        "u",
        "small",
        "sub",
        "sup",
        "mark",
        "del",
        "ins",
        "abbr",
        "cite",
        "dfn",
        "var",
        "samp",
        "kbd",
        "q",
        "label",
    }

    # Track open tags with a stack
    stack: list[str] = []

    tag_pattern = re.compile(r"<(/?)([\w:]+)(?:\s[^>]*)?>", re.IGNORECASE)

    for match in tag_pattern.finditer(html):
        is_closing = match.group(1) == "/"
        tag_name = match.group(2).lower()

        if is_closing:
            if stack and stack[-1] == tag_name:
                stack.pop()
        else:
            # Check if this is a block element inside an inline element
            if tag_name in block_elements:
                for parent in reversed(stack):
                    if parent in inline_elements:
                        errors.append(
                            f"Block element <{tag_name}> inside inline "
                            f"element <{parent}>"
                        )
                        break
            elif tag_name in inline_elements:
                pass  # Just add to stack

            # Check if it's not a void/self-closing element
            void_elements = {
                "br",
                "hr",
                "img",
                "input",
                "meta",
                "link",
                "area",
                "base",
                "col",
                "embed",
                "param",
                "source",
                "track",
                "wbr",
            }
            if tag_name not in void_elements:
                stack.append(tag_name)

    return errors


def _check_confluence_macros(html: str) -> list[str]:
    """Check Confluence-specific macro structure.

    Validates:
    - ac:structured-macro has required children (ac:parameter or ac:plain-text-body)
    - ac:link has ri:page or ri:user or body content
    - ac:task-list contains ac:task elements

    Args:
        html: HTML content with Confluence macros.

    Returns:
        List of error messages for malformed macros.
    """
    errors: list[str] = []

    # Check ac:structured-macro elements
    macro_pattern = re.compile(
        r"<ac:structured-macro([^>]*)>(.*?)</ac:structured-macro>",
        re.DOTALL | re.IGNORECASE,
    )

    for match in macro_pattern.finditer(html):
        content = match.group(2)

        # Must have either ac:parameter or ac:plain-text-body
        has_parameter = "<ac:parameter" in content
        has_body = "<ac:plain-text-body" in content

        if not has_parameter and not has_body:
            # Check if it's self-closing style (shouldn't be, but handle it)
            if not content.strip():
                errors.append(
                    "ac:structured-macro must have ac:parameter or "
                    "ac:plain-text-body child"
                )

    # Check ac:plain-text-body contains CDATA
    body_pattern = re.compile(
        r"<ac:plain-text-body[^>]*>(.*?)</ac:plain-text-body>",
        re.DOTALL | re.IGNORECASE,
    )

    for match in body_pattern.finditer(html):
        content = match.group(1).strip()
        # Should contain CDATA section
        if not re.search(r"<!\[CDATA\[", content):
            errors.append("ac:plain-text-body must contain <![CDATA[...]]> section")

    # Check ac:task-list contains ac:task
    task_list_pattern = re.compile(
        r"<ac:task-list[^>]*>(.*?)</ac:task-list>", re.DOTALL | re.IGNORECASE
    )

    for match in task_list_pattern.finditer(html):
        content = match.group(1)
        if "<ac:task" not in content:
            errors.append("ac:task-list should contain ac:task elements")

    # Check ac:link has content or ri:page/ri:user
    link_pattern = re.compile(
        r"<ac:link[^>]*>(.*?)</ac:link>", re.DOTALL | re.IGNORECASE
    )

    for match in link_pattern.finditer(html):
        content = match.group(1).strip()
        has_ri = "<ri:page" in content or "<ri:user" in content
        has_body = bool(content) and not has_ri

        # Empty link without ri: reference
        if not content.strip() and not has_ri:
            errors.append("ac:link should have ri:page/ri:user or body content")

    return errors


def _check_namespace_declarations(html: str) -> tuple[list[str], list[str]]:
    """Check for namespace declarations in Confluence elements.

    Confluence storage format does not require xmlns declarations in the
    body — they are only needed for standalone XHTML documents. These are
    informational, not errors.

    Args:
        html: HTML content to check.

    Returns:
        Tuple of (errors, info) — errors is always empty, info contains
        namespace observations.
    """
    info: list[str] = []

    has_ac_elements = bool(re.search(r"<ac:", html))
    has_ri_elements = bool(re.search(r"<ri:", html))

    if has_ac_elements or has_ri_elements:
        has_ac_ns = 'xmlns:ac="' in html
        has_ri_ns = 'xmlns:ri="' in html

        if has_ac_elements and not has_ac_ns:
            info.append(
                "No xmlns:ac declaration (normal for Confluence storage format)"
            )

        if has_ri_elements and not has_ri_ns:
            info.append(
                "No xmlns:ri declaration (normal for Confluence storage format)"
            )

    return ([], info)


def _check_cdata_sections(html: str) -> list[str]:
    """Check CDATA section validity.

    Validates:
    - CDATA sections are properly opened and closed
    - CDATA sections are used where required (ac:plain-text-body)

    Args:
        html: HTML content to check.

    Returns:
        List of error messages for malformed CDATA.
    """
    errors: list[str] = []

    # Check for malformed CDATA
    cdata_open = html.count("<![CDATA[")
    cdata_close = html.count("]]>")

    if cdata_open != cdata_close:
        errors.append(
            f"CDATA section mismatch: {cdata_open} opening, {cdata_close} closing"
        )

    # Check for CDATA outside of proper context
    # CDATA should only appear inside ac:plain-text-body or similar
    cdata_pattern = re.compile(r"<!\[CDATA\[(.*?)\]\]>", re.DOTALL)

    for match in cdata_pattern.finditer(html):
        # Check if this CDATA is inside ac:plain-text-body
        start_pos = match.start()
        # Look backwards for ac:plain-text-body
        preceding = html[max(0, start_pos - 200) : start_pos]

        if "<ac:plain-text-body" not in preceding:
            # CDATA outside of ac:plain-text-body - might be intentional
            # but worth noting
            pass  # Not an error, just a warning if needed

    return errors


def is_markdown_content(content: str, file_path: str | None = None) -> bool:
    """Detect if content is markdown vs raw HTML.

    Detection rules:
    - Has frontmatter (--- delimiters) → markdown
    - File extension .md → markdown
    - Contains <html or <ac: or <p> → HTML
    - Default → treat as markdown

    Args:
        content: The content string to analyze.
        file_path: Optional file path for extension check.

    Returns:
        True if content appears to be markdown, False if HTML.
    """
    # Check for frontmatter
    if content.strip().startswith("---"):
        lines = content.split("\n")
        if len(lines) > 1 and "---" in lines[1:]:
            return True

    # Check file extension
    if file_path and file_path.endswith(".md"):
        return True

    # Check for HTML indicators
    html_indicators = ["<html", "<ac:", "<p>", "<div", "<span"]
    for indicator in html_indicators:
        if indicator.lower() in content.lower():
            return False

    # Default to markdown
    return True
