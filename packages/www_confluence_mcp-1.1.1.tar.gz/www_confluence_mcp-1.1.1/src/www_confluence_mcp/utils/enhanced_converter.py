"""
Enhanced HTML to Markdown Converter for Confluence
Supports new elements: ui-tabs, ui-tab, task lists, user links
"""

import parsel
import html
from typing import Dict, List


class EnhancedHTMLToMarkdownConverter:
    """HTML to Markdown converter with support for new Confluence elements"""

    def __init__(self):
        # Icon map for info blocks
        self.icon_map = {
            "info": "ℹ️",
            "note": "📝",
            "warning": "⚠️",
            "tip": "💡",
            "success": "✅",
        }

    def convert(self, html_content: str) -> str:
        """Convert HTML to Markdown using parsel"""
        # Wrap in root element with namespace declarations for ac: and ri: prefixes
        wrapped_html = (
            '<root xmlns:ac="http://atlassian.com/content" '
            'xmlns:ri="http://atlassian.com/resource/identifier">'
            f"{html_content}</root>"
        )
        selector = parsel.Selector(
            wrapped_html,
            type="xml",
            namespaces={
                "ac": "http://atlassian.com/content",
                "ri": "http://atlassian.com/resource/identifier",
            },
        )

        # Process various elements
        markdown_parts = []

        # Process tabs (ui-tabs)
        tabs = self.extract_ui_tabs(selector)
        if tabs:
            markdown_parts.append(self.convert_ui_tabs(tabs))

        # Process task lists
        task_lists = self.extract_task_lists(selector)
        if task_lists:
            for task_list in task_lists:
                markdown_parts.append(self.convert_task_list(task_list))

        # Headings (h1-h6) - including code-line class
        for heading in selector.xpath("//h1|//h2|//h3|//h4|//h5|//h6"):
            tag_name = heading.xpath("name()").get("")
            level = int(tag_name[1]) if tag_name else 1
            text = heading.xpath("string()").get("")
            # Preserve code-line class if present
            css_class = heading.xpath("@class").get("")
            header_text = "#" * level + " " + text
            if css_class and "code-line" in css_class:
                header_text = "```\n" + header_text + "\n```"
            markdown_parts.append(header_text)

        # Paragraphs - with special character handling
        for p in selector.xpath("//p"):
            # Skip paragraphs inside already processed elements
            if p.xpath(
                'ancestor::ac:task-list | ancestor::ac:structured-macro[@ac:name="ui-tabs"]'
            ):
                continue

            text = (
                p.xpath("string()").get("").replace("&xa0;", " ")
            )  # Replace non-breaking spaces
            if text.strip():
                markdown_parts.append(text)

        # Confluence macros
        macros = self.extract_macros(selector)
        for macro in macros:
            if macro["name"] in ["toc", "datelastupdate", "info", "note", "warning"]:
                # Skip already processed tabs
                if macro["name"] not in ["ui-tabs", "ui-tab"]:
                    markdown_parts.append(self.convert_macro(macro))

        # Tables
        for table in selector.xpath(
            '//table[contains(@class, "wrapped") or contains(@class, "relative-table")]'
        ):
            markdown_parts.append(self.convert_table(table))

        # Process regular links
        for link in selector.xpath("//a[@href]"):
            # Skip links inside already processed elements
            if link.xpath("ancestor::ac:task-list | ancestor::ac:structured-macro"):
                continue

            href = link.xpath("@href").get("")
            text = link.xpath("string()").get("")
            if text:
                # Decode URL if needed
                decoded_url = html.unescape(href)
                markdown_parts.append(f"[{text}]({decoded_url})")

        # User links
        user_links = self.extract_user_links(selector)
        for user_link in user_links:
            markdown_parts.append(user_link["markdown"])

        # Lists (non-task)
        for list_elem in selector.xpath("//ul | //ol"):
            # Skip lists inside already processed elements
            if list_elem.xpath(
                "ancestor::ac:task-list | ancestor::ac:structured-macro"
            ):
                continue

            list_type = "ordered" if list_elem.root.tag == "ol" else "unordered"
            markdown_parts.append(self.convert_list(list_elem, list_type))

        return "\n\n".join(filter(None, markdown_parts))

    def extract_ui_tabs(self, selector: parsel.Selector) -> List[Dict]:
        """Extract tabs from content"""
        tabs_containers = []

        for tabs_macro in selector.xpath('//ac:structured-macro[@ac:name="ui-tabs"]'):
            tabs_container = {"type": "ui-tabs", "tabs": []}

            # Extract child tabs
            for tab_macro in tabs_macro.xpath(
                './/ac:structured-macro[@ac:name="ui-tab"]'
            ):
                tab_title = tab_macro.xpath(
                    './/ac:parameter[@ac:name="title"]/text()'
                ).get("")
                tab_body = (
                    tab_macro.xpath(".//ac:rich-text-body").xpath("string()").get("")
                )

                if tab_title:
                    tabs_container["tabs"].append(
                        {"title": tab_title, "content": tab_body}
                    )

            if tabs_container["tabs"]:
                tabs_containers.append(tabs_container)

        return tabs_containers

    def convert_ui_tabs(self, tabs_containers: List[Dict]) -> str:
        """Convert tabs to Markdown format"""
        result_parts = []

        for tabs_container in tabs_containers:
            for tab in tabs_container["tabs"]:
                # Use ### for tab headings
                result_parts.append(f"### {tab['title']}")
                result_parts.append(tab["content"])

        return "\n\n".join(result_parts)

    def extract_task_lists(self, selector: parsel.Selector) -> List[Dict]:
        """Extract task lists from Confluence"""
        task_lists = []

        for task_list in selector.xpath("//ac:task-list"):
            list_info = {"tasks": []}

            # Extract individual tasks
            for task in task_list.xpath(".//ac:task"):
                task_info = {
                    "id": task.xpath("@ac:task-id").get(""),
                    "status": task.xpath("@ac:task-status").get(""),
                    "body": task.xpath(".//ac:task-body").xpath("string()").get(""),
                }

                list_info["tasks"].append(task_info)

            if list_info["tasks"]:
                task_lists.append(list_info)

        return task_lists

    def convert_task_list(self, task_list: Dict) -> str:
        """Convert task list to Markdown format"""
        markdown_tasks = []

        for task in task_list["tasks"]:
            checkbox = "[x]" if task["status"] == "complete" else "[ ]"
            markdown_tasks.append(f"{checkbox} {task['body']}")

        return "\n".join(markdown_tasks)

    def extract_macros(self, selector: parsel.Selector) -> List[Dict]:
        """Extract Confluence macros"""
        macros = []

        for macro in selector.xpath("//ac:structured-macro"):
            macro_info = {
                "name": macro.xpath("@ac:name").get(""),
                "parameters": {},
                "body": "",
            }

            # Macro parameters
            for param in macro.xpath(".//ac:parameter"):
                name = param.xpath("@ac:name").get("")
                value = param.xpath("text()").get("")
                if name:
                    macro_info["parameters"][name] = value

            # Macro body
            body = macro.xpath(".//ac:rich-text-body").xpath("string()").get("")
            if body:
                macro_info["body"] = body

            macros.append(macro_info)

        return macros

    def convert_macro(self, macro: Dict) -> str:
        """Convert macro to Markdown format"""
        if macro["name"] in ["info", "note", "warning", "tip", "success"]:
            title = macro["parameters"].get("title", macro["name"].title())
            icon = self.icon_map.get(macro["name"], "")
            return f"> {icon} **{title}:** {macro['body']}"
        elif macro["name"] == "toc":
            return "## Table of Contents\n*(automatically generated)*"
        elif macro["name"] == "datelastupdate":
            return f"Last updated: {macro['parameters'].get('date', '')}"

        return ""

    def convert_table(self, table) -> str:
        """Convert table to Markdown format"""
        markdown_table = []

        # Headers
        for row in table.xpath(".//thead/tr | .//tr[1]"):
            header_cells = []
            for th in row.xpath(".//th | .//td"):
                text = th.xpath("string()").get("").strip()
                header_cells.append(text)

            if header_cells:
                markdown_table.append("| " + " | ".join(header_cells) + " |")
                markdown_table.append("|" + "---|" * len(header_cells))

        # Table body
        for row in table.xpath(".//tbody/tr | .//tr[position()>1]"):
            body_cells = []
            for td in row.xpath(".//td"):
                text = td.xpath("string()").get("").strip()
                body_cells.append(text)

            if body_cells:
                markdown_table.append("| " + " | ".join(body_cells) + " |")

        return "\n".join(markdown_table)

    def extract_user_links(self, selector: parsel.Selector) -> List[Dict]:
        """Extract user links"""
        user_links = []

        for user_link in selector.xpath("//ri:user"):
            user_info = {
                "user_key": user_link.xpath("@ri:userkey").get(""),
                "username": user_link.xpath("@ri:username").get(""),
                "full_name": "",  # May require additional API call
            }

            # Output in @username format for convenience
            if user_info["username"]:
                user_info["markdown"] = f"@{user_info['username']}"
            elif user_info["user_key"]:
                user_info["markdown"] = f"@{user_info['user_key']}"
            else:
                user_info["markdown"] = "@unknown"

            user_links.append(user_info)

        return user_links

    def convert_list(self, list_elem, list_type: str) -> str:
        """Convert list to Markdown format"""
        items = []

        for li in list_elem.xpath(".//li"):
            text = li.xpath("string()").get("").strip()
            if list_type == "ordered":
                items.append(f"1. {text}")
            else:
                items.append(f"- {text}")

        return "\n".join(items)
