"""Utility decorators for the Confluence MCP server."""

from __future__ import annotations

import logging
import time
from functools import wraps
from typing import Any, Callable, TypeVar

# Type alias for async functions
AnyAsyncFunction = Callable[..., Any]
T = TypeVar("T", bound=AnyAsyncFunction)

logger = logging.getLogger("www-confluence-mcp")


def tool_logging_middleware(tool_name: str | None = None) -> Callable[[T], T]:
    """Decorator that adds logging middleware to tool functions.

    This middleware logs:
    1. Tool name before execution
    2. Tool name + duration after successful execution
    3. Tool name + error on failure

    Args:
        tool_name: Optional custom name for the tool. If None, uses function name.

    Returns:
        Decorator function that wraps the tool with logging.

    Example:
        @mcp.tool()
        @tool_logging_middleware()
        async def confluence_search_cql(query: str) -> dict:
            ...

        @mcp.tool()
        @tool_logging_middleware("custom_search")
        async def search(query: str) -> dict:
            ...
    """

    def decorator(func: T) -> T:
        actual_tool_name = tool_name or func.__name__

        @wraps(func)
        async def wrapper(*args: Any, **kwargs: Any) -> Any:
            # Log before execution
            logger.info("Tool call: %s", actual_tool_name)
            start_time = time.monotonic()

            try:
                result = await func(*args, **kwargs)
                duration_ms = (time.monotonic() - start_time) * 1000
                logger.info(
                    "Tool completed: %s (%.2f ms)", actual_tool_name, duration_ms
                )
                return result
            except Exception as e:
                duration_ms = (time.monotonic() - start_time) * 1000
                logger.error(
                    "Tool failed: %s after %.2f ms - %s: %s",
                    actual_tool_name,
                    duration_ms,
                    type(e).__name__,
                    e,
                )
                raise

        return wrapper  # ty: ignore[invalid-return-type]  # @wraps preserves signature; ty can't verify through wrapper

    return decorator
