"""Batch operation utilities for Confluence operations."""

from __future__ import annotations

import logging
from typing import Any, Awaitable, Callable

logger = logging.getLogger(__name__)


async def process_batch_items(
    items: list[dict[str, Any]],
    operation: Callable[[dict[str, Any]], Awaitable[dict[str, Any]]],
    id_key: str,
    item_type: str,
    required_keys: list[str] | None = None,
    logger_obj: logging.Logger | None = None,
) -> dict[str, Any]:
    """Process a batch of items with validation, error handling, and result collection.

    This helper encapsulates the common batch operation pattern:
    1. Validate input is non-empty list
    2. For each item: validate format, check required keys
    3. Try operation, catch exceptions, collect results
    4. Return standardized response

    Args:
        items: List of dicts to process.
        operation: Async function to call for each valid item. Receives the item
            dict and returns a result dict.
        id_key: The key in the item dict to use as the ID (e.g., "page_id").
        item_type: Name of the item type for error messages (e.g., "page", "attachment").
        required_keys: List of required keys that must be present in each item dict.
            Defaults to [id_key].
        logger_obj: Logger instance for logging. Uses module logger if None.

    Returns:
        Dict with status and results list:
            {
                "status": "ok",
                "results": [...]
            }

    Raises:
        ValueError: If items is empty or not a list.
    """
    log = logger_obj or logger
    keys_to_check = required_keys or [id_key]

    # Validate input
    if not items or not isinstance(items, list):
        raise ValueError(f"{item_type}s must be a non-empty list")

    results: list[dict[str, Any]] = []

    for item in items:
        # Validate item format
        if not isinstance(item, dict):
            results.append(
                {
                    id_key: str(item),
                    "status": "error",
                    "error": "Invalid item format: expected dict",
                }
            )
            continue

        # Check required keys
        missing_keys = [k for k in keys_to_check if k not in item]
        if missing_keys:
            results.append(
                {
                    id_key: str(item),
                    "status": "error",
                    "error": f"Missing required key{'s' if len(missing_keys) > 1 else ''}: {', '.join(missing_keys)}",
                }
            )
            continue

        item_id = item[id_key]

        try:
            result = await operation(item)
            results.append(result)
        except Exception as e:
            log.exception(
                "process_batch_items: failed to process %s %s=%s",
                item_type,
                id_key,
                item_id,
            )
            results.append(
                {
                    id_key: str(item_id),
                    "status": "error",
                    "error": str(e),
                }
            )

    return {"status": "ok", "results": results}


async def process_nested_batch_items(
    items: list[dict[str, Any]],
    inner_operation: Callable[[str, str], Awaitable[dict[str, Any]]],
    parent_id_key: str,
    inner_key: str,
    item_type: str,
    inner_item_type: str,
    required_keys: list[str] | None = None,
    logger_obj: logging.Logger | None = None,
) -> dict[str, Any]:
    """Process a batch of items with nested sub-items.

    This helper handles the pattern where each item has a list of sub-items
    to process (e.g., deleting multiple labels from multiple pages).

    Args:
        items: List of dicts to process. Each dict must have parent_id_key and inner_key.
        inner_operation: Async function to call for each sub-item. Receives
            (parent_id, inner_value) and returns a result dict.
        parent_id_key: The key in the item dict for the parent ID (e.g., "page_id").
        inner_key: The key in the item dict for the list of sub-items (e.g., "labels").
        item_type: Name of the parent item type for error messages.
        inner_item_type: Name of the sub-item type for error messages.
        required_keys: List of required keys that must be present in each item dict.
            Defaults to [parent_id_key, inner_key].
        logger_obj: Logger instance for logging. Uses module logger if None.

    Returns:
        Dict with status and results list containing per-item results with nested results.

    Raises:
        ValueError: If items is empty or not a list.
    """
    log = logger_obj or logger
    keys_to_check = required_keys or [parent_id_key, inner_key]

    # Validate input
    if not items or not isinstance(items, list):
        raise ValueError(f"{item_type}s must be a non-empty list")

    results: list[dict[str, Any]] = []

    for item in items:
        # Validate item format
        if not isinstance(item, dict):
            results.append(
                {
                    parent_id_key: str(item),
                    "status": "error",
                    "error": "Invalid item format: expected dict",
                }
            )
            continue

        # Check required keys
        missing_keys = [k for k in keys_to_check if k not in item]
        if missing_keys:
            results.append(
                {
                    parent_id_key: str(item),
                    "status": "error",
                    "error": f"Missing required key{'s' if len(missing_keys) > 1 else ''}: {', '.join(missing_keys)}",
                }
            )
            continue

        parent_id = item[parent_id_key]
        inner_items = item[inner_key]

        # Validate parent_id
        try:
            from ..config import get_id

            parent_id = get_id(parent_id, parent_id_key)
        except Exception as e:
            results.append(
                {
                    parent_id_key: str(parent_id),
                    "status": "error",
                    "error": f"Invalid {parent_id_key}: {e}",
                }
            )
            continue

        # Validate inner_items is a list
        if not isinstance(inner_items, list):
            results.append(
                {
                    parent_id_key: str(parent_id),
                    "status": "error",
                    "error": f"{inner_key} must be a list",
                }
            )
            continue

        # Process inner items
        inner_results: list[dict[str, Any]] = []

        for inner_item in inner_items:
            if not isinstance(inner_item, str):
                inner_results.append(
                    {
                        inner_item_type: str(inner_item),
                        "status": "error",
                        "error": f"{inner_item_type.capitalize()} must be a string",
                    }
                )
                continue

            inner_item = inner_item.strip()
            if not inner_item:
                inner_results.append(
                    {
                        inner_item_type: str(inner_item),
                        "status": "error",
                        "error": f"{inner_item_type.capitalize()} must not be empty",
                    }
                )
                continue

            try:
                result = await inner_operation(parent_id, inner_item)
                inner_results.append(result)
            except Exception as e:
                log.exception(
                    "process_nested_batch_items: failed to process %s %s=%s %s=%s",
                    item_type,
                    parent_id_key,
                    parent_id,
                    inner_item_type,
                    inner_item,
                )
                inner_results.append(
                    {
                        inner_item_type: inner_item,
                        "status": "error",
                        "error": str(e),
                    }
                )

        results.append(
            {
                parent_id_key: parent_id,
                inner_key: inner_results,
            }
        )

    return {"status": "ok", "results": results}
