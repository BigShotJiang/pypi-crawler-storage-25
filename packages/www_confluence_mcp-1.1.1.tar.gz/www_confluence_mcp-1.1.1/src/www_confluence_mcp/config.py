"""Environment-driven configuration and shared constants (Server/DC only)."""

from __future__ import annotations

import logging
import os
from typing import Optional, TypeAlias, Union

import niquests

logger = logging.getLogger("www-confluence-mcp")

# ---------------------------------------------------------------------------
# ID type aliases + canonical normalizer
# ---------------------------------------------------------------------------
# FastMCP schema generation expects Optional[Union[...]] rather than PEP 604
# `str | int | None`, so we use an explicit TypeAlias built from typing.Union /
# Optional. The alias is resolved by typing.get_type_hints at introspection
# time into a canonical form pydantic can turn into a JSON schema.

IdLike: TypeAlias = Union[str, int]
OptIdLike: TypeAlias = Optional[IdLike]


def get_id(value: OptIdLike, name: str = "id") -> str:
    """Normalize an ID value to a non-empty string.

    Accepts ``int`` or ``str`` (leading/trailing whitespace stripped). Raises
    ``ValueError`` if ``value`` is ``None`` or blank after stripping. This is
    the single entry point for every ``*_id`` parameter across the package.
    """
    if value is None:
        raise ValueError(f"{name} must not be None")
    v = str(value).strip()
    if not v:
        raise ValueError(f"{name} must not be empty")
    return v


# ---------------------------------------------------------------------------
# Env helpers
# ---------------------------------------------------------------------------


def _env_str(name: str, default: str = "") -> str:
    return os.getenv(name, default).strip()


def _env_int(
    name: str, default: int, lo: int | None = None, hi: int | None = None
) -> int:
    try:
        val = int(os.getenv(name, str(default)))
    except (ValueError, TypeError):
        logger.warning("Invalid %s, using default %d", name, default)
        val = default
    if lo is not None:
        val = max(lo, val)
    if hi is not None:
        val = min(hi, val)
    return val


_TRUE_SET = {"1", "true", "yes", "on", "y", "t"}
_FALSE_SET = {"0", "false", "no", "off", "n", "f"}


def _parse_bool(raw: str) -> bool | None:
    """Parse a string into a bool. Returns None if not recognized."""
    v = raw.strip().lower()
    if v in _TRUE_SET:
        return True
    if v in _FALSE_SET:
        return False
    return None


def _env_bool(name: str, default: bool = True) -> bool:
    raw = os.getenv(name)
    if raw is None or not raw.strip():
        return default
    parsed = _parse_bool(raw)
    if parsed is None:
        logger.warning(
            "Environment variable %s=%r not a valid bool, using default %s",
            name,
            raw,
            default,
        )
        return default
    return parsed


# ---------------------------------------------------------------------------
# Auth type detection (Server/Data Center only)
# ---------------------------------------------------------------------------

AuthType = str  # "basic" | "pat"


def _detect_auth() -> tuple[AuthType, str, str, str]:
    """Detect authentication method from environment variables.

    Returns (auth_type, username, password, personal_token).
    Raises ValueError if auth is not configured.
    """
    url = _env_str("CONFLUENCE_URL")
    username = _env_str("CONFLUENCE_USERNAME")
    password = _env_str("CONFLUENCE_PASSWORD") or _env_str("CONFLUENCE_API_TOKEN")
    personal_token = _env_str("CONFLUENCE_PERSONAL_TOKEN")

    if not url:
        raise ValueError(
            "CONFLUENCE_URL is required. "
            "Set it to your Confluence Server/DC base URL, "
            "e.g. https://confluence.example.com"
        )

    # PAT is preferred for Server/DC
    if personal_token:
        return "pat", "", "", personal_token
    if username and password:
        return "basic", username, password, ""
    raise ValueError(
        "Confluence Server/Data Center requires CONFLUENCE_PERSONAL_TOKEN "
        "or both CONFLUENCE_USERNAME and CONFLUENCE_PASSWORD."
    )


# ---------------------------------------------------------------------------
# Resolved settings (read once at import time)
# ---------------------------------------------------------------------------

URL: str = _env_str("CONFLUENCE_URL")
TIMEOUT: int = _env_int("CONFLUENCE_TIMEOUT", 30, lo=1)
TIMEOUT_CONFIG: niquests.TimeoutConfiguration = niquests.TimeoutConfiguration(
    connect=5,
    read=max(1, TIMEOUT - 5),
    total=TIMEOUT,
)
MAX_RESULTS: int = _env_int("CONFLUENCE_MAX_RESULTS", 25, lo=1, hi=100)
SSL_VERIFY: bool = _env_bool("CONFLUENCE_SSL_VERIFY", default=True)
# Optional path to extra trusted CA certificates (PEM file or directory with
# OpenSSL-hashed certs). Loaded *in addition to* the system trust store, not
# as a replacement. Ignored when SSL_VERIFY is False.
SSL_PATH: str | None = _env_str("CONFLUENCE_SSL_PATH") or None
if not SSL_VERIFY:
    logger.warning(
        "CONFLUENCE_SSL_VERIFY=false: TLS certificate verification is DISABLED (insecure)"
    )
elif SSL_PATH:
    logger.info("CONFLUENCE_SSL_PATH: adding extra CA trust from %r", SSL_PATH)
READ_ONLY: bool = _env_bool("CONFLUENCE_READ_ONLY", default=True)
SPACES_FILTER: str = _env_str("CONFLUENCE_SPACES_FILTER")
HTTP_PROXY: str | None = _env_str("CONFLUENCE_HTTP_PROXY") or None
HTTPS_PROXY: str | None = _env_str("CONFLUENCE_HTTPS_PROXY") or None
PROMPTS_DIR: str = _env_str("CONFLUENCE_PROMPTS_DIR")
API_VERSION: str = _env_str("CONFLUENCE_API_VERSION", "latest")

# Transport mode: "stdio" (default) or "http"
# In HTTP mode, file-related arguments are stripped from tool schemas
MCP_TRANSPORT: str = _env_str("CONFLUENCE_MCP_TRANSPORT", "stdio")
IS_HTTP_MODE: bool = MCP_TRANSPORT == "http"

# Rate limiting configuration for client-side throttling
# Tokens per second for API requests (prevents overwhelming the server)
RATE_LIMIT_TOKENS_PER_SECOND: float = float(
    os.getenv("CONFLUENCE_RATE_LIMIT_TOKENS", "10.0")
)
# Maximum burst size (max tokens in the bucket)
RATE_LIMIT_MAX_TOKENS: int = _env_int("CONFLUENCE_RATE_LIMIT_BURST", 20, lo=1)

try:
    _auth_type, _username, _password, _personal_token = _detect_auth()
    AUTH_TYPE: AuthType = _auth_type
    USERNAME: str = _username
    PASSWORD: str = _password
    PERSONAL_TOKEN: str = _personal_token
except ValueError:
    # Allow importing the module without configured env vars (e.g. for tests).
    # The client will raise at runtime if auth is missing.
    AUTH_TYPE = ""
    USERNAME = ""
    PASSWORD = ""  # nosec B105 — empty default, not a real credential
    PERSONAL_TOKEN = ""  # nosec B105 — empty default, not a real credential
    logger.debug(
        "Confluence auth not configured — tools will be unavailable until env vars are set."
    )
