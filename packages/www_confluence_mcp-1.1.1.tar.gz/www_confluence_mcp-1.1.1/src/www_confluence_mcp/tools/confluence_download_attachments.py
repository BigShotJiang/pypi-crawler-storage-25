"""Download attachments tool - download attachments from a Confluence page to disk."""

from __future__ import annotations

import logging
from typing import Any

from mcp.server.fastmcp import Context

from ..api.attachments import download_attachment, download_content_attachments
from ..config import get_id
from ..info import tool_description, tool_title
from ..server import mcp
from ..utils.content import to_dict
from pathlib import Path
from ..utils.url import get_page_id

logger = logging.getLogger("www-confluence-mcp")


@mcp.tool(
    name="confluence_download_attachments",
    title=tool_title("confluence_download_attachments"),
    description=tool_description("confluence_download_attachments"),
)
async def confluence_download_attachments(
    page: str,
    save_dir: str,
    attachment_ids: list[str] | None = None,
    ctx: Context | None = None,
) -> dict[str, Any]:
    """Download attachments from a page to disk.

    Accepts page ID or Confluence URL.
    """
    # Extract credentials from request headers (HTTP mode)
    from ..utils.auth import extract_credentials

    await extract_credentials(ctx)

    page_id = await get_page_id(page)
    save_dir = save_dir.strip()
    if not save_dir:
        raise ValueError("save_dir must not be empty")

    save_dir = str(Path(save_dir).resolve())

    if attachment_ids:
        logger.info(
            "confluence_download_attachments: page=%s count=%d",
            page,
            len(attachment_ids),
        )
        normalized_attachment_ids = [
            get_id(att_id, "attachment_id") for att_id in attachment_ids
        ]
        results = []
        for normalized_att_id in normalized_attachment_ids:
            results.append(await download_attachment(normalized_att_id, save_dir))
    else:
        logger.info("confluence_download_attachments: page=%s dir=%s", page, save_dir)
        batch_response = await download_content_attachments(page_id, save_dir)
        results = [to_dict(r) for r in batch_response.results]
    return {
        "status": "ok",
        "page_id": page_id,
        "downloaded": len([r for r in results if r.get("status") == "downloaded"]),
        "results": results,
    }
