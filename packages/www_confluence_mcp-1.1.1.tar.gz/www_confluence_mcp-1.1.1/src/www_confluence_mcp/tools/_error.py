"""Shared error response formatting for MCP tools."""

from __future__ import annotations

import logging
from typing import Any

from ..exceptions import (
    ConfluenceError,
    ConfluenceNotFoundError,
    ConfluencePermissionError,
    ConfluenceConflictError,
    ConfluenceRateLimitError,
    ConfluenceTimeoutError,
    ConfluenceAPIError,
    ConverterError,
    ParseError,
    MacroPreservationError,
    RoundTripError,
)

logger = logging.getLogger("www-confluence-mcp.tools")


def make_error_response(
    error: Exception,
    tool_name: str = "",
    page_id: str = "",
    **kwargs: Any,
) -> dict[str, Any]:
    """Format exception as structured MCP tool error response.

    Maps exception types to error codes and suggested actions.
    Includes configuration hints and alternative actions where applicable.

    Args:
        error: The caught exception.
        tool_name: Name of the tool that failed.
        page_id: Page ID involved in the operation.

    Returns:
        Dict with status, error, error_code, suggested_action, and optional
        configuration_hint, alternative_action, documentation_url.
    """
    error_code = "UNKNOWN_ERROR"
    suggested_action = ""
    configuration_hint: str | None = None
    alternative_action: str | None = None
    documentation_url: str | None = None
    message = str(error)
    retryable = False

    if isinstance(error, ConfluenceNotFoundError):
        error_code = "NOT_FOUND"
        suggested_action = (
            "Verify page_id exists. Try confluence_search_cql to find the page."
        )
        alternative_action = "Use confluence_get_page with title + space_key instead."
        documentation_url = "https://developer.atlassian.com/cloud/confluence/rest/v1/api-group-content/#api-wiki-rest-api-content-get"
    elif isinstance(error, ConfluencePermissionError):
        error_code = "PERMISSION_DENIED"
        suggested_action = "Check CONFLUENCE_PERSONAL_TOKEN has access to this space."
        configuration_hint = "Verify CONFLUENCE_URL and auth credentials in .env"
        documentation_url = "https://confluence.atlassian.com/doc/confluence-api-token-authentication-1141481943.html"
    elif isinstance(error, ConfluenceConflictError):
        error_code = "VERSION_CONFLICT"
        suggested_action = "Fetch latest version and retry."
        alternative_action = (
            "Use confluence_get_page to get current version before updating."
        )
    elif isinstance(error, ConfluenceRateLimitError):
        error_code = "RATE_LIMITED"
        retryable = True
        if error.retry_after:
            suggested_action = f"Retry after {error.retry_after}s."
        else:
            suggested_action = "Wait and retry."
        configuration_hint = "Consider implementing request throttling or caching."
    elif isinstance(error, ConfluenceTimeoutError):
        error_code = "TIMEOUT"
        retryable = True
        suggested_action = "Retry with smaller payload or later."
        configuration_hint = (
            "Increase CONFLUENCE_TIMEOUT environment variable if persistent."
        )
    elif isinstance(error, ConfluenceAPIError):
        error_code = f"API_ERROR_{error.status_code}"
        retryable = error.retryable
        if error.status_code and error.status_code >= 500:
            configuration_hint = "Confluence server error - check server status."
    elif isinstance(error, ParseError):
        error_code = "PARSE_ERROR"
        suggested_action = f"Check element: {error.element}" if error.element else ""
    elif isinstance(error, MacroPreservationError):
        error_code = "MACRO_ERROR"
        suggested_action = f"Macro: {error.macro_name}" if error.macro_name else ""
    elif isinstance(error, RoundTripError):
        error_code = "ROUNDTRIP_ERROR"
    elif isinstance(error, ConverterError):
        error_code = "CONVERTER_ERROR"
        suggested_action = error.suggested_action
    elif isinstance(error, ConfluenceError):
        error_code = f"CONFLUENCE_ERROR_{error.status_code or 0}"
        if error.suggested_action:
            suggested_action = error.suggested_action

    result: dict[str, Any] = {
        "status": "error",
        "error": message,
        "error_code": error_code,
    }
    if suggested_action:
        result["suggested_action"] = suggested_action
    if configuration_hint:
        result["configuration_hint"] = configuration_hint
    if alternative_action:
        result["alternative_action"] = alternative_action
    if documentation_url:
        result["documentation_url"] = documentation_url
    if retryable:
        result["retryable"] = True
    if page_id:
        result["page_id"] = page_id

    logger.error(
        "[%s] %s: %s (code=%s)",
        tool_name,
        error_code,
        message[:200],
        error_code,
    )
    return result
