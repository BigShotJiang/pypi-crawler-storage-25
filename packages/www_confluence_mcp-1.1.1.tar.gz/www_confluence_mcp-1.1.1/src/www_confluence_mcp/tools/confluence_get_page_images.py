"""Get page images tool - retrieve images from a Confluence page as base64."""

from __future__ import annotations

import logging
from typing import Any

from mcp.server.fastmcp import Context

from ..api.images import get_page_images
from ..info import tool_description, tool_title
from ..server import mcp
from ..utils.url import get_page_id

logger = logging.getLogger("www-confluence-mcp")


@mcp.tool(
    name="confluence_get_page_images",
    title=tool_title("confluence_get_page_images"),
    description=tool_description("confluence_get_page_images"),
)
async def confluence_get_page_images(
    page: str,
    limit: int = 5,
    ctx: Context | None = None,
) -> dict[str, Any]:
    """Get images from a Confluence page as base64-encoded data.

    Accepts page ID or Confluence URL.
    """
    # Extract credentials from request headers (HTTP mode)
    from ..utils.auth import extract_credentials

    await extract_credentials(ctx)

    page_id = await get_page_id(page)
    logger.info("confluence_get_page_images: page=%s", page)
    images = await get_page_images(page_id)
    errors = [i for i in images if getattr(i, "status", None) == "error"]
    skipped = [i for i in images if getattr(i, "status", None) == "skipped"]
    successful = [
        i for i in images if getattr(i, "status", None) not in ("error", "skipped")
    ]
    return {
        "status": "ok",
        "page_id": page_id,
        "total_images": len(images),
        "downloaded": len(successful),
        "skipped": skipped,
        "failed": errors,
        "images": successful,
    }
