"""Create new Confluence page tool."""

from __future__ import annotations

import logging
from typing import Any

from mcp.server.fastmcp import Context

from ..api.pages import create_page
from ..config import OptIdLike, get_id
from ..info import tool_description, tool_title
from ..server import mcp
from ..utils.content import to_dict

logger = logging.getLogger("www-confluence-mcp")


@mcp.tool(
    name="confluence_new_page",
    title=tool_title("confluence_new_page"),
    description=tool_description("confluence_new_page"),
)
async def confluence_new_page(
    space_key: str,
    title: str,
    content: str = "",
    parent_id: OptIdLike = None,
    content_format: str = "storage",
    status: str = "current",
    ctx: Context | None = None,
) -> dict[str, Any]:
    # Extract credentials from request headers (HTTP mode)
    from ..utils.auth import extract_credentials

    await extract_credentials(ctx)

    parent_id = get_id(parent_id, "parent_id") if parent_id is not None else None
    space_key = space_key.strip()
    title = title.strip()
    if not title:
        raise ValueError("title must not be empty")
    content = content.strip()
    if not content:
        raise ValueError("content must not be empty")
    if status not in ("current", "draft"):
        raise ValueError("status must be 'current' or 'draft'")

    logger.info("confluence_new_page: space=%s title=%r", space_key, title)
    data = await create_page(
        space_key=space_key,
        title=title,
        body_value=content,
        parent_id=parent_id,
        body_representation=content_format,
        status=status,
    )
    if data is None:
        return {"status": "created", "page_id": None, "title": title}
    data = to_dict(data)
    return {"status": "created", "page_id": data.get("id"), "title": data.get("title")}
