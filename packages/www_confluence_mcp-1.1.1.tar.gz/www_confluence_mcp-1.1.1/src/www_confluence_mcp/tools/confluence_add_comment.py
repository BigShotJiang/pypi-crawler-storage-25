"""Add comment to Confluence page tool."""

from __future__ import annotations

import logging
from typing import Any

from mcp.server.fastmcp import Context

from ..api.comments import create_comment
from ..info import tool_description, tool_title
from ..server import mcp
from ..utils.content import to_dict
from ..utils.url import get_page_id

logger = logging.getLogger("www-confluence-mcp")


@mcp.tool(
    name="confluence_add_comment",
    title=tool_title("confluence_add_comment"),
    description=tool_description("confluence_add_comment"),
)
async def confluence_add_comment(
    page: str,
    content: str,
    content_format: str = "storage",
    ctx: Context | None = None,
) -> dict[str, Any]:
    """Add a comment to a Confluence page.

    Accepts page ID or Confluence URL.

    Args:
        page: The Confluence page ID or URL to add comment to.
        content: Comment text content.
        content_format: Format of content: "storage" or "plain" (default: "storage").

    Returns:
        Dictionary with comment creation status.

    Raises:
        ValueError: If content is empty.
    """
    # Extract credentials from request headers (HTTP mode)
    from ..utils.auth import extract_credentials

    await extract_credentials(ctx)

    page_id = await get_page_id(page)
    content = content.strip()
    if not content:
        raise ValueError("content must not be empty")

    logger.info("confluence_add_comment: page=%s", page)
    data = await create_comment(page_id, content)
    if data is None:
        return {"status": "created", "comment_id": None}
    data = to_dict(data)
    return {"status": "created", "comment_id": data.get("id")}
