"""Delete Confluence pages tool (batch operation)."""

from __future__ import annotations

import logging
from typing import Any

from mcp.server.fastmcp import Context

from ..api.pages import delete_page
from ..info import tool_description, tool_title
from ..server import mcp
from ..utils.batch import process_batch_items
from ..utils.url import get_page_id

logger = logging.getLogger("www-confluence-mcp")


async def _delete_page_operation(item: dict[str, str]) -> dict[str, Any]:
    """Delete a single page.

    Args:
        item: Dict with page_id key.

    Returns:
        Result dict with page_id and status.
    """
    page_id = await get_page_id(item["page_id"])
    logger.info("confluence_delete_pages: page_id=%s", page_id)
    await delete_page(page_id)
    return {"page_id": page_id, "status": "ok"}


@mcp.tool(
    name="confluence_delete_pages",
    title=tool_title("confluence_delete_pages"),
    description=tool_description("confluence_delete_pages"),
)
async def confluence_delete_pages(
    pages: list[dict[str, str]],
    ctx: Context | None = None,
) -> dict[str, Any]:
    """Delete multiple Confluence pages in batch.

    Args:
        pages: List of dicts with page_id keys.
            Example: [{"page_id": "123"}, {"page_id": "456"}]

    Returns:
        Dict with status and results list containing per-page results.
        Example:
            {
                "status": "ok",
                "results": [
                    {"page_id": "123", "status": "ok"},
                    {"page_id": "456", "status": "error", "error": "..."}
                ]
            }
    """
    # Extract credentials from request headers (HTTP mode)
    from ..utils.auth import extract_credentials

    await extract_credentials(ctx)

    return await process_batch_items(
        items=pages,
        operation=_delete_page_operation,
        id_key="page_id",
        item_type="page",
        required_keys=["page_id"],
        logger_obj=logger,
    )
