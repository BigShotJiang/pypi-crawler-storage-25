"""Get page history tool - retrieve version history of a Confluence page."""

from __future__ import annotations

import logging
from typing import Any

from mcp.server.fastmcp import Context

from ..api.pages import get_page_history
from ..info import tool_description, tool_title
from ..server import mcp
from ..utils.url import get_page_id

logger = logging.getLogger("www-confluence-mcp")


@mcp.tool(
    name="confluence_get_page_history",
    title=tool_title("confluence_get_page_history"),
    description=tool_description("confluence_get_page_history"),
)
async def confluence_get_page_history(
    page: str,
    ctx: Context | None = None,
) -> dict[str, Any]:
    """Get page version history.

    Accepts page ID or Confluence URL.
    """
    # Extract credentials from request headers (HTTP mode)
    from ..utils.auth import extract_credentials

    await extract_credentials(ctx)

    page_id = await get_page_id(page)
    logger.info("confluence_get_page_history: page=%s", page)
    data = await get_page_history(page_id)
    return data if data is not None else {"results": []}
