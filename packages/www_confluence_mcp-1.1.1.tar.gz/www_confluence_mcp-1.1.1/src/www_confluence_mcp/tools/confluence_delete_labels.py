"""Delete labels from Confluence pages tool (batch operation)."""

from __future__ import annotations

import logging
from typing import Any

from mcp.server.fastmcp import Context

from ..api.labels import delete_page_label
from ..info import tool_description, tool_title
from ..server import mcp
from ..utils.batch import process_nested_batch_items

logger = logging.getLogger("www-confluence-mcp")


async def _delete_label_operation(page_id: str, label: str) -> dict[str, Any]:
    """Delete a single label from a page.

    Args:
        page_id: The page ID (already normalized by batch utility).
        label: The label to delete.

    Returns:
        Result dict with label and status.
    """
    logger.info("confluence_delete_labels: page_id=%s label=%s", page_id, label)
    await delete_page_label(page_id, label)
    return {"label": label, "status": "ok"}


@mcp.tool(
    name="confluence_delete_labels",
    title=tool_title("confluence_delete_labels"),
    description=tool_description("confluence_delete_labels"),
)
async def confluence_delete_labels(
    items: list[dict[str, Any]],
    ctx: Context | None = None,
) -> dict[str, Any]:
    """Delete multiple labels from multiple Confluence pages in batch.

    Args:
        items: List of dicts with page_id and labels keys.
            Example: [{"page_id": "123", "labels": ["tag1", "tag2"]}, {"page_id": "456", "labels": ["tag3"]}]

    Returns:
        Dict with status and results list containing per-item per-label results.
        Example:
            {
                "status": "ok",
                "results": [
                    {
                        "page_id": "123",
                        "labels": [
                            {"label": "tag1", "status": "ok"},
                            {"label": "tag2", "status": "error", "error": "..."}
                        ]
                    },
                    {
                        "page_id": "456",
                        "labels": [
                            {"label": "tag3", "status": "ok"}
                        ]
                    }
                ]
            }
    """
    # Extract credentials from request headers (HTTP mode)
    from ..utils.auth import extract_credentials

    await extract_credentials(ctx)

    return await process_nested_batch_items(
        items=items,
        inner_operation=_delete_label_operation,
        parent_id_key="page_id",
        inner_key="labels",
        item_type="page",
        inner_item_type="label",
        required_keys=["page_id", "labels"],
        logger_obj=logger,
    )
