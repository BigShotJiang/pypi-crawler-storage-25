"""Markdown upload/update helpers for Confluence MCP tools.

This module contains business logic for uploading and updating Confluence
pages from Markdown content. Pure conversion functions remain in the API layer.
"""

from __future__ import annotations

import logging
from typing import Any

from ..api.pages import get_page, create_page, update_page
from ..utils.converter import parse_frontmatter, markdown_to_storage
from ..utils.content import to_dict

logger = logging.getLogger("www-confluence-mcp.tools.markdown_helpers")

# Module-level backup storage for error recovery
_backup_html: dict[str, str] = {}


async def upload_page_from_markdown(
    space_key: str,
    markdown_content: str,
    parent_id: str | None = None,
    title: str | None = None,
) -> dict[str, Any]:
    """Create or update page from markdown.

    Args:
        space_key: The Confluence space key for new pages.
        markdown_content: Markdown content with frontmatter.
        parent_id: Optional parent page ID for new pages.
        title: Optional title override (uses frontmatter if not provided).

    Returns:
        Dictionary with the created/updated page data.

    Raises:
        ConfluenceError: If the page operation fails.
    """
    meta, _ = parse_frontmatter(markdown_content)
    confluence_meta = meta.get("confluence", {})

    page_title = title or confluence_meta.get("title", "Untitled")
    storage_html = markdown_to_storage(markdown_content)

    page_id = confluence_meta.get("pageId")

    # Backup original HTML before upload (for error recovery)
    current_version = 1
    if page_id:
        try:
            current_page = await get_page(page_id)
            page_dict = to_dict(current_page)
            original_html = (
                page_dict.get("body", {}).get("storage", {}).get("value", "")
            )
            _backup_html[page_id] = original_html
            current_version = page_dict.get("version", {}).get("number", 1)
        except Exception:
            # Best-effort backup fetch — ignore failures
            logger.debug("Failed to fetch backup for page %s", page_id, exc_info=True)

    try:
        if page_id:
            result = await update_page(
                page_id=page_id,
                title=page_title,
                body_value=storage_html,
                version_number=current_version + 1,
            )
            return to_dict(result)
        else:
            result = await create_page(
                space_key=space_key,
                title=page_title,
                body_value=storage_html,
                parent_id=parent_id,
            )
            return to_dict(result)
    except Exception:
        # Restore on error
        if page_id and page_id in _backup_html:
            try:
                await update_page(
                    page_id=page_id,
                    title=page_title,
                    body_value=_backup_html[page_id],
                    version_number=current_version + 1,
                )
            except Exception:
                # Best-effort restore — already in error path, nothing more to do
                logger.debug("Failed to restore page %s", page_id, exc_info=True)
        raise
    finally:
        _backup_html.pop(page_id, None)


async def update_page_from_markdown(
    page_id: str,
    markdown_content: str,
    version_number: int,
) -> dict[str, Any]:
    """Update existing page from markdown.

    Args:
        page_id: The Confluence page ID to update.
        markdown_content: Markdown content with frontmatter.
        version_number: The new version number for the page.

    Returns:
        Dictionary with the updated page data.

    Raises:
        ConfluenceError: If the page update fails.
    """
    # Get current page to preserve title
    current_page = await get_page(page_id)
    page_dict = to_dict(current_page)
    page_title = page_dict.get("title", "Untitled")
    storage_html = markdown_to_storage(markdown_content)
    result = await update_page(
        page_id=page_id,
        title=page_title,
        body_value=storage_html,
        version_number=version_number,
    )
    return to_dict(result)


async def update_page_with_version_check(
    page_id: str,
    markdown_content: str,
    expected_version: int,
) -> dict[str, Any]:
    """Update page only if current version matches expected.

    Performs optimistic locking by checking the current version
    before updating. Raises ConfluenceConflictError on version mismatch.

    Args:
        page_id: The Confluence page ID to update.
        markdown_content: Markdown content with frontmatter.
        expected_version: Expected current version number.

    Returns:
        Dictionary with the updated page data.

    Raises:
        ConfluenceConflictError: If version mismatch detected.
        ConfluenceError: If the page update fails.
    """
    current_page = await get_page(page_id)
    page_dict = to_dict(current_page)
    current_version = page_dict.get("version", {}).get("number", 0)

    if current_version != expected_version:
        from ..exceptions import ConfluenceConflictError

        raise ConfluenceConflictError(
            f"Version conflict: expected {expected_version}, "
            f"got {current_version} for page {page_id}"
        )

    return await update_page_from_markdown(
        page_id, markdown_content, current_version + 1
    )
