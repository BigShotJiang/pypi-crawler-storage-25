"""Get page comments tool - retrieve comments on a Confluence page."""

from __future__ import annotations

import logging
from typing import Any

from mcp.server.fastmcp import Context

from ..api.comments import get_footer_comments
from ..info import tool_description, tool_title
from ..server import mcp
from ..utils.pagination import extract_next_start
from ..utils.content import to_dict
from ..utils.url import get_page_id

logger = logging.getLogger("www-confluence-mcp")


@mcp.tool(
    name="confluence_get_page_comments",
    title=tool_title("confluence_get_page_comments"),
    description=tool_description("confluence_get_page_comments"),
)
async def confluence_get_page_comments(
    page: str,
    limit: int = 5,
    start: str | None = None,
    ctx: Context | None = None,
) -> dict[str, Any]:
    """Get comments on a Confluence page.

    Accepts page ID or Confluence URL.
    """
    # Extract credentials from request headers (HTTP mode)
    from ..utils.auth import extract_credentials

    await extract_credentials(ctx)

    page_id = await get_page_id(page)
    logger.info("confluence_get_page_comments: page=%s", page)
    start_int = int(start) if start else 0
    response = await get_footer_comments(page_id, limit=limit, start=start_int)
    if response is None:
        return {"results": []}
    data = to_dict(response)
    links = data.pop("_links", None) or {}
    return {
        "results": data.get("results", []),
        "next_start": extract_next_start(links),
    }
