"""Get Confluence spaces tool - list spaces or get specific space details."""

from __future__ import annotations

import logging
from typing import Any

from mcp.server.fastmcp import Context

from ..api.spaces import get_space, get_spaces
from ..config import get_id
from ..info import tool_description, tool_title
from ..server import mcp
from ..utils.pagination import extract_next_start
from ..utils.content import to_dict

logger = logging.getLogger("www-confluence-mcp")


@mcp.tool(
    name="confluence_get_spaces",
    title=tool_title("confluence_get_spaces"),
    description=tool_description("confluence_get_spaces"),
)
async def confluence_get_spaces(
    space_key: str | None = None,
    limit: int = 5,
    start: str | None = None,
    ctx: Context | None = None,
) -> dict[str, Any]:
    # Extract credentials from request headers (HTTP mode)
    from ..utils.auth import extract_credentials

    await extract_credentials(ctx)

    if space_key:
        space_key = get_id(space_key, "space_key")
        logger.info("confluence_get_spaces: space_key=%s", space_key)
        space = await get_space(space_key)
        # Convert Pydantic model to dict for backward compatibility
        return to_dict(space)
    logger.info("confluence_get_spaces: limit=%d", limit)
    start_int = int(start) if start else 0
    data = await get_spaces(limit=limit, start=start_int)
    if data is None:
        return {"results": []}
    # Convert Pydantic model to dict for backward compatibility
    data_dict = to_dict(data)
    links = data_dict.pop("_links", None) or {}
    return {
        "results": data_dict.get("results", []),
        "next_start": extract_next_start(links),
    }
