"""Get page ancestors tool - retrieve breadcrumb path of a Confluence page."""

from __future__ import annotations

import logging
from typing import Any

from mcp.server.fastmcp import Context

from ..api.pages import get_page_ancestors
from ..info import tool_description, tool_title
from ..server import mcp
from ..utils.url import get_page_id

logger = logging.getLogger("www-confluence-mcp")


@mcp.tool(
    name="confluence_get_page_ancestors",
    title=tool_title("confluence_get_page_ancestors"),
    description=tool_description("confluence_get_page_ancestors"),
)
async def confluence_get_page_ancestors(
    page: str,
    limit: int = 5,
    ctx: Context | None = None,
) -> dict[str, Any]:
    """Get ancestor pages (breadcrumb) for a page.

    Accepts page ID or Confluence URL.
    """
    # Extract credentials from request headers (HTTP mode)
    from ..utils.auth import extract_credentials

    await extract_credentials(ctx)

    page_id = await get_page_id(page)
    logger.info("confluence_get_page_ancestors: page=%s", page)
    ancestors = await get_page_ancestors(page_id)
    return {"results": ancestors or []}
