"""Get page labels tool - retrieve labels attached to a Confluence page."""

from __future__ import annotations

import logging
from typing import Any

from mcp.server.fastmcp import Context

from ..api.labels import get_page_labels
from ..info import tool_description, tool_title
from ..server import mcp
from ..utils.content import to_dict
from ..utils.url import get_page_id

logger = logging.getLogger("www-confluence-mcp")


@mcp.tool(
    name="confluence_get_page_labels",
    title=tool_title("confluence_get_page_labels"),
    description=tool_description("confluence_get_page_labels"),
)
async def confluence_get_page_labels(
    page: str,
    limit: int = 5,
    ctx: Context | None = None,
) -> dict[str, Any]:
    """Get labels on a Confluence page.

    Accepts page ID or Confluence URL.
    """
    # Extract credentials from request headers (HTTP mode)
    from ..utils.auth import extract_credentials

    await extract_credentials(ctx)

    page_id = await get_page_id(page)
    logger.info("confluence_get_page_labels: page=%s", page)
    response = await get_page_labels(page_id)
    if response is None:
        return {"results": []}
    return to_dict(response)
