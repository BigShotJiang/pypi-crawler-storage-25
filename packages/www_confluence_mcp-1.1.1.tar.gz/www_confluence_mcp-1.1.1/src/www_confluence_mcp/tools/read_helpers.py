"""Shared content resolution helpers for MCP tools.

Provides unified functions to resolve content from various sources
(file, inline content, Confluence page) into Confluence Storage Format HTML.
"""

from __future__ import annotations

import logging
from typing import Any

from ..api.pages import get_page
from ..utils.content import to_dict
from ..utils.io import read_file_content
from ..utils.converter import markdown_to_storage, parse_frontmatter

logger = logging.getLogger("www-confluence-mcp.tools.content")


def validate_and_convert_content(
    content: str,
    expected_page_id: str | None = None,
) -> tuple[str, dict[str, Any]]:
    """Parse frontmatter, validate, and convert to storage format.

    Args:
        content: Markdown content (markdown or plain).
        expected_page_id: If set, frontmatter pageId must match.

    Returns:
        Tuple of (storage_html, metadata_dict).

    Raises:
        ValueError: If content is empty, frontmatter is malformed,
            pageId mismatches, or conversion fails.
    """
    if not content or not content.strip():
        raise ValueError("Content is empty")

    meta, body = parse_frontmatter(content)

    # Validate frontmatter YAML (parse_frontmatter returns {} on error,
    # but we check if body equals content when frontmatter expected)
    confluence_meta = meta.get("confluence", {})

    # Auto-replace frontmatter pageId to match target page
    frontmatter_page_id = confluence_meta.get("pageId")
    if expected_page_id and frontmatter_page_id is not None:
        if str(frontmatter_page_id) != str(expected_page_id):
            logger.info(
                "Auto-replacing frontmatter pageId: %s -> %s",
                frontmatter_page_id,
                expected_page_id,
            )
            content = content.replace(
                f"pageId: '{frontmatter_page_id}'",
                f"pageId: '{expected_page_id}'",
            )

    # Convert to storage format
    try:
        storage_html = markdown_to_storage(content)
    except Exception as e:
        raise ValueError(f"Failed to convert content: {e}") from e

    return storage_html, meta


async def fetch_page_storage(page_id: str) -> tuple[str, str, dict[str, Any]]:
    """Fetch a Confluence page and extract storage HTML.

    Args:
        page_id: The Confluence page ID.

    Returns:
        Tuple of (storage_html, title, page_data).

    Raises:
        ValueError: If page not found or fetch fails.
    """
    try:
        page_data = await get_page(page_id, body_format="storage")
    except Exception as e:
        raise ValueError(f"Page not found: {page_id} - {e}") from e

    if page_data is None:
        raise ValueError(f"Page not found: {page_id}")

    page_data = to_dict(page_data)
    storage_html = page_data.get("body", {}).get("storage", {}).get("value", "")
    title = page_data.get("title", "")

    return storage_html, title, page_data


async def resolve_content_to_storage(
    file_path: str | None = None,
    content: str | None = None,
    page_id: str | None = None,
    expected_page_id: str | None = None,
) -> tuple[str, str, dict[str, Any]]:
    """Resolve any source to storage format HTML.

    Exactly ONE of file_path, content, page_id must be provided.

    Args:
        file_path: Path to Markdown file.
        content: Markdown content string.
        page_id: Confluence page ID to fetch.
        expected_page_id: If set, validates frontmatter pageId matches.

    Returns:
        Tuple of (storage_html, source_label, metadata).
        - source_label: human-readable source description for diff output
        - metadata: dict with frontmatter (for markdown) or page_data (for page)

    Raises:
        ValueError: If zero or multiple sources provided, or validation fails.
    """
    sources = {
        "file_path": file_path is not None,
        "content": content is not None,
        "page_id": page_id is not None,
    }

    provided = [k for k, v in sources.items() if v]

    if len(provided) == 0:
        raise ValueError("Must specify one source: file_path, content, or page_id")
    if len(provided) > 1:
        raise ValueError(f"Must specify exactly one source, got: {', '.join(provided)}")

    if file_path is not None:
        raw = read_file_content(file_path)
        storage_html, meta = validate_and_convert_content(raw, expected_page_id)
        return storage_html, f"file:{file_path}", meta

    if content is not None:
        storage_html, meta = validate_and_convert_content(content, expected_page_id)
        return storage_html, "inline content", meta

    # page_id
    if page_id is None:
        raise ValueError("page_id is required")
    storage_html, title, page_data = await fetch_page_storage(page_id)
    return storage_html, f"page:{page_id} ({title})", page_data
