"""Upload attachments to Confluence page tool."""

from __future__ import annotations

import logging
from typing import Any

from mcp.server.fastmcp import Context

from ..api.attachments import upload_attachments
from ..info import tool_description, tool_title
from ..server import mcp
from ..utils.content import to_dict
from ..utils.url import get_page_id

logger = logging.getLogger("www-confluence-mcp")


@mcp.tool(
    name="confluence_upload_attachments",
    title=tool_title("confluence_upload_attachments"),
    description=tool_description("confluence_upload_attachments"),
)
async def confluence_upload_attachments(
    page: str,
    file_paths: list[str],
    comment: str = "",
    ctx: Context | None = None,
) -> dict[str, Any]:
    """Upload one or more files as attachments to a Confluence page.

    Accepts page ID or Confluence URL.
    """
    # Extract credentials from request headers (HTTP mode)
    from ..utils.auth import extract_credentials

    await extract_credentials(ctx)

    page_id = await get_page_id(page)
    if not file_paths:
        raise ValueError("file_paths must not be empty")
    logger.info(
        "confluence_upload_attachments: page=%s count=%d", page, len(file_paths)
    )
    results = await upload_attachments(page_id, file_paths, comment=comment)
    results_dict = to_dict(results)
    results = results_dict.get("results", [])
    return {
        "status": "ok",
        "page_id": page_id,
        "uploaded": len([r for r in results if r.get("status") == "uploaded"]),
        "results": results,
    }
