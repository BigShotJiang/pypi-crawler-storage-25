"""Get pages tool - retrieve pages from a space or child pages."""

from __future__ import annotations

import logging
from typing import Any

from mcp.server.fastmcp import Context

from ..api.pages import get_child_pages
from ..api.space_tree import get_space_page_tree
from ..info import tool_description, tool_title
from ..config import OptIdLike, get_id
from ..server import mcp
from ..utils.pagination import extract_next_start
from ..utils.content import to_dict

logger = logging.getLogger("www-confluence-mcp")


@mcp.tool(
    name="confluence_get_pages",
    title=tool_title("confluence_get_pages"),
    description=tool_description("confluence_get_pages"),
)
async def confluence_get_pages(
    space_key: str | None = None,
    parent_page_id: OptIdLike = None,
    limit: int = 5,
    ctx: Context | None = None,
) -> dict[str, Any]:
    # Extract credentials from request headers (HTTP mode)
    from ..utils.auth import extract_credentials

    await extract_credentials(ctx)

    # Convert limit to int (MCP may pass it as string)
    try:
        limit = int(limit)
    except (ValueError, TypeError):
        limit = 5

    if parent_page_id:
        parent_page_id = get_id(parent_page_id, "parent_page_id")
        logger.info("confluence_get_pages: parent_page_id=%s", parent_page_id)
        data = await get_child_pages(parent_page_id, limit=limit, start=0)
        if data is None:
            return {"results": []}
        data_dict = to_dict(data)
        links = data_dict.pop("_links", None) or {}
        return {
            "results": data_dict.get("results", []),
            "next_start": extract_next_start(links),
        }
    elif space_key:
        space_key = get_id(space_key, "space_key")
        logger.info("confluence_get_pages: space_key=%s", space_key)
        return await get_space_page_tree(space_key=space_key, limit=limit)
    else:
        raise ValueError("Provide space_key and/or parent_page_id")
