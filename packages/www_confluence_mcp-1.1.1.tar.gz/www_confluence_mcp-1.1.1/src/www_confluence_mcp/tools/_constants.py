"""Shared constants for tool tags and annotations.

This module provides standardized tags and annotations for all MCP tool decorators
to enable consistent tool categorization and behavior hints.

Note: Tags are stored in the 'meta' parameter as {"tags": [...]} since FastMCP
doesn't support tags directly. Annotations use ToolAnnotations from mcp.types.
"""

from __future__ import annotations

from mcp.types import ToolAnnotations

# =============================================================================
# Tag Constants
# =============================================================================

#: Read-only tools that don't modify data
TAG_READ_ONLY = "read-only"

#: Write tools that modify data
TAG_WRITE = "write"

#: Markdown-related tools
TAG_MARKDOWN = "markdown"

#: Tools that operate on pages
TAG_PAGE_CRUD = "page-crud"

#: Tools that operate on attachments
TAG_ATTACHMENTS = "attachments"

#: Tools that perform search operations
TAG_SEARCH = "search"


# =============================================================================
# Annotation Constants
# =============================================================================

#: Read-only tool annotations (doesn't modify data)
ANNOTATIONS_READ_ONLY = ToolAnnotations(
    readOnlyHint=True,
    destructiveHint=False,
    idempotentHint=True,
    openWorldHint=False,
)

#: Write tool annotations (destructive operations)
ANNOTATIONS_WRITE_DESTRUCTIVE = ToolAnnotations(
    readOnlyHint=False,
    destructiveHint=True,
    idempotentHint=True,
    openWorldHint=False,
)

#: Write tool annotations (non-destructive operations)
ANNOTATIONS_WRITE_SAFE = ToolAnnotations(
    readOnlyHint=False,
    destructiveHint=False,
    idempotentHint=False,
    openWorldHint=False,
)

#: Markdown tool annotations (read operation)
ANNOTATIONS_MARKDOWN_READ = ToolAnnotations(
    readOnlyHint=True,
    destructiveHint=False,
    idempotentHint=True,
    openWorldHint=False,
)

#: Markdown tool annotations (write operation)
ANNOTATIONS_MARKDOWN_WRITE = ToolAnnotations(
    readOnlyHint=False,
    destructiveHint=False,
    idempotentHint=False,
    openWorldHint=False,
)

#: Markdown tool annotations (destructive operation)
ANNOTATIONS_MARKDOWN_DESTRUCTIVE = ToolAnnotations(
    readOnlyHint=False,
    destructiveHint=True,
    idempotentHint=True,
    openWorldHint=False,
)
