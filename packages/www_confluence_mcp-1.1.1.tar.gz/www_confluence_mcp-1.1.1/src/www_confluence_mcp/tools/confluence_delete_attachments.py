"""Delete attachments from Confluence tool (batch operation)."""

from __future__ import annotations

import logging
from typing import Any

from mcp.server.fastmcp import Context

from ..api.attachments import delete_attachment
from ..info import tool_description, tool_title
from ..config import get_id
from ..server import mcp
from ..utils.batch import process_batch_items

logger = logging.getLogger("www-confluence-mcp")


async def _delete_attachment_operation(item: dict[str, str]) -> dict[str, Any]:
    """Delete a single attachment.

    Args:
        item: Dict with attachment_id key.

    Returns:
        Result dict with attachment_id and status.
    """
    attachment_id = item["attachment_id"]
    attachment_id = get_id(attachment_id, "attachment_id")
    logger.info("confluence_delete_attachments: attachment_id=%s", attachment_id)
    await delete_attachment(attachment_id)
    return {"attachment_id": attachment_id, "status": "ok"}


@mcp.tool(
    name="confluence_delete_attachments",
    title=tool_title("confluence_delete_attachments"),
    description=tool_description("confluence_delete_attachments"),
)
async def confluence_delete_attachments(
    attachments: list[dict[str, str]],
    ctx: Context | None = None,
) -> dict[str, Any]:
    """Delete multiple Confluence attachments in batch.

    Args:
        attachments: List of dicts with attachment_id keys.
            Example: [{"attachment_id": "att1"}, {"attachment_id": "att2"}]

    Returns:
        Dict with status and results list containing per-attachment results.
        Example:
            {
                "status": "ok",
                "results": [
                    {"attachment_id": "att1", "status": "ok"},
                    {"attachment_id": "att2", "status": "error", "error": "..."}
                ]
            }
    """
    # Extract credentials from request headers (HTTP mode)
    from ..utils.auth import extract_credentials

    await extract_credentials(ctx)

    return await process_batch_items(
        items=attachments,
        operation=_delete_attachment_operation,
        id_key="attachment_id",
        item_type="attachment",
        required_keys=["attachment_id"],
        logger_obj=logger,
    )
