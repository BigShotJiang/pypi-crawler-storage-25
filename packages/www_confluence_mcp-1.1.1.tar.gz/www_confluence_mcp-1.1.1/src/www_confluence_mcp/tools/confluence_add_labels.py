"""Add labels to Confluence page tool."""

from __future__ import annotations

import logging
from typing import Any

from mcp.server.fastmcp import Context

from ..api.labels import add_page_labels
from ..info import tool_description, tool_title
from ..server import mcp
from ..utils.url import get_page_id

logger = logging.getLogger("www-confluence-mcp")


@mcp.tool(
    name="confluence_add_labels",
    title=tool_title("confluence_add_labels"),
    description=tool_description("confluence_add_labels"),
)
async def confluence_add_labels(
    page: str,
    labels: list[str],
    ctx: Context | None = None,
) -> dict[str, Any]:
    """Add labels to a Confluence page.

    Accepts page ID or Confluence URL.
    """
    # Extract credentials from request headers (HTTP mode)
    from ..utils.auth import extract_credentials

    await extract_credentials(ctx)

    page_id = await get_page_id(page)
    if not labels:
        raise ValueError("labels must not be empty")
    cleaned = [lbl.strip() for lbl in labels if lbl.strip()]
    if not cleaned:
        raise ValueError("labels must contain at least one non-empty label")
    logger.info("confluence_add_labels: page=%s labels=%s", page, cleaned)
    await add_page_labels(page_id, cleaned)
    return {"status": "ok", "page_id": page_id, "labels_added": len(cleaned)}
