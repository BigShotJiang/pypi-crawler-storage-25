"""Search Confluence users tool - find users by name."""

from __future__ import annotations

import logging
from typing import Any

from mcp.server.fastmcp import Context

from ..api.users import search_user
from ..config import MAX_RESULTS
from ..info import tool_description, tool_title
from ..server import mcp
from ..utils.content import to_dict

logger = logging.getLogger("www-confluence-mcp")


@mcp.tool(
    name="confluence_get_user",
    title=tool_title("confluence_get_user"),
    description=tool_description("confluence_get_user"),
)
async def confluence_get_user(
    query: str,
    limit: int = MAX_RESULTS,
    start: str | None = None,
    ctx: Context | None = None,
) -> dict[str, Any]:
    # Extract credentials from request headers (HTTP mode)
    from ..utils.auth import extract_credentials

    await extract_credentials(ctx)

    query = query.strip()
    if not query:
        raise ValueError("query must not be empty")
    logger.info("confluence_get_user: query=%r", query)
    start_int = int(start) if start else 0
    users = await search_user(query, limit=limit, start=start_int)
    if users is None:
        return {
            "status": "no_results",
            "query": query,
            "result_count": 0,
            "results": [],
        }
    # Convert list of Pydantic models to list of dicts
    results = [to_dict(u) for u in users]
    # Calculate next start offset for pagination
    next_start_val = start_int + limit if results else None
    return {
        "status": "ok" if results else "no_results",
        "query": query,
        "result_count": len(results),
        "results": results,
        "next_start": str(next_start_val) if next_start_val is not None else None,
    }
