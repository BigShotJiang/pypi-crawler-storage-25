"""Tests for TTLCache implementation."""

from __future__ import annotations

import asyncio
import time

import pytest

from www_confluence_mcp.utils.cache import TTLCache, page_cache


class TestTTLCache:
    @pytest.mark.asyncio
    async def test_get_missing_key_returns_none(self):
        """Returns None for missing keys."""
        cache = TTLCache()
        result = await cache.get("nonexistent")
        assert result is None

    @pytest.mark.asyncio
    async def test_set_and_get(self):
        """Stores and retrieves values correctly."""
        cache = TTLCache()
        await cache.set("key1", "value1")
        result = await cache.get("key1")
        assert result == "value1"

    @pytest.mark.asyncio
    async def test_ttl_expiry(self, monkeypatch):
        """Expires entries after TTL."""
        cache = TTLCache(ttl=10)
        mock_time = 100.0

        def mock_monotonic():
            return mock_time

        monkeypatch.setattr(time, "monotonic", mock_monotonic)

        await cache.set("key1", "value1")
        result = await cache.get("key1")
        assert result == "value1"

        # Advance time past TTL
        mock_time = 115.0
        result = await cache.get("key1")
        assert result is None

    @pytest.mark.asyncio
    async def test_lru_eviction_when_full(self):
        """Evicts least recently used entry when at capacity."""
        cache = TTLCache(maxsize=3)
        await cache.set("key1", "value1")
        await cache.set("key2", "value2")
        await cache.set("key3", "value3")

        # Add fourth key, should evict key1 (LRU)
        await cache.set("key4", "value4")

        result1 = await cache.get("key1")
        result2 = await cache.get("key2")
        result4 = await cache.get("key4")

        assert result1 is None  # Evicted
        assert result2 == "value2"
        assert result4 == "value4"

    @pytest.mark.asyncio
    async def test_update_existing_key_moves_to_end(self):
        """Updating existing key moves it to end (most recently used)."""
        cache = TTLCache(maxsize=3)
        await cache.set("key1", "value1")
        await cache.set("key2", "value2")
        await cache.set("key3", "value3")

        # Update key1 (moves to end)
        await cache.set("key1", "updated_value1")

        # Add new key, should evict key2 (now LRU)
        await cache.set("key4", "value4")

        result1 = await cache.get("key1")
        result2 = await cache.get("key2")

        assert result1 == "updated_value1"
        assert result2 is None  # Evicted

    @pytest.mark.asyncio
    async def test_invalidate(self):
        """Removes specific key from cache."""
        cache = TTLCache()
        await cache.set("key1", "value1")
        await cache.set("key2", "value2")

        await cache.invalidate("key1")

        result1 = await cache.get("key1")
        result2 = await cache.get("key2")

        assert result1 is None
        assert result2 == "value2"

    @pytest.mark.asyncio
    async def test_clear(self):
        """Clears entire cache."""
        cache = TTLCache()
        await cache.set("key1", "value1")
        await cache.set("key2", "value2")
        await cache.set("key3", "value3")

        await cache.clear()

        result1 = await cache.get("key1")
        result2 = await cache.get("key2")

        assert result1 is None
        assert result2 is None
        assert cache.size == 0

    @pytest.mark.asyncio
    async def test_concurrent_access(self):
        """Handles concurrent access safely."""
        cache = TTLCache(maxsize=100)
        results = []

        async def worker(worker_id: int) -> None:
            for i in range(10):
                key = f"worker{worker_id}_key{i}"
                await cache.set(key, f"value{i}")
                val = await cache.get(key)
                results.append((key, val))

        # Run multiple workers concurrently
        await asyncio.gather(*[worker(i) for i in range(5)])

        # All results should have correct values
        for key, val in results:
            expected_val = val.replace("value", "")
            assert val is not None
            assert val.endswith(expected_val)

    def test_page_cache_global_instance_exists(self):
        """Global page_cache instance exists with correct config."""
        assert isinstance(page_cache, TTLCache)
        assert page_cache._maxsize == 64
        assert page_cache._ttl == 300


class TestTTLCacheStats:
    @pytest.mark.asyncio
    async def test_stats_initial_values(self):
        """Stats returns correct initial values."""
        cache = TTLCache()
        stats = await cache.stats()
        assert stats["hits"] == 0
        assert stats["misses"] == 0
        assert stats["hit_rate"] == 0.0
        assert stats["size"] == 0

    @pytest.mark.asyncio
    async def test_stats_tracks_hits_and_misses(self):
        """Stats correctly tracks hits and misses."""
        cache = TTLCache()

        # First get is a miss
        await cache.get("key1")
        stats = await cache.stats()
        assert stats["hits"] == 0
        assert stats["misses"] == 1

        # Set and get is a hit
        await cache.set("key1", "value1")
        await cache.get("key1")
        stats = await cache.stats()
        assert stats["hits"] == 1
        assert stats["misses"] == 1

        # Another get is a hit
        await cache.get("key1")
        stats = await cache.stats()
        assert stats["hits"] == 2
        assert stats["misses"] == 1

    @pytest.mark.asyncio
    async def test_stats_hit_rate_calculation(self):
        """Stats calculates hit rate correctly."""
        cache = TTLCache()

        # 3 misses
        await cache.get("key1")
        await cache.get("key2")
        await cache.get("key3")

        # 2 hits
        await cache.set("key1", "value1")
        await cache.set("key2", "value2")
        await cache.get("key1")
        await cache.get("key2")

        stats = await cache.stats()
        assert stats["hits"] == 2
        assert stats["misses"] == 3
        # hit_rate = 2 / (2 + 3) = 0.4
        assert stats["hit_rate"] == 0.4
        assert stats["size"] == 2

    @pytest.mark.asyncio
    async def test_stats_empty_cache_hit_rate(self):
        """Stats returns 0 hit rate for empty access history."""
        cache = TTLCache()
        stats = await cache.stats()
        assert stats["hit_rate"] == 0.0

    @pytest.mark.asyncio
    async def test_stats_is_async_method(self):
        """Stats is now an async method requiring await."""
        cache = TTLCache()
        # Should require await
        stats = await cache.stats()
        assert isinstance(stats, dict)
        assert "hits" in stats
        assert "misses" in stats
        assert "hit_rate" in stats
        assert "size" in stats

    @pytest.mark.asyncio
    async def test_stats_thread_safe_concurrent_access(self):
        """Stats method is thread-safe under concurrent access."""
        cache = TTLCache(maxsize=1000)

        async def worker(worker_id: int) -> None:
            # Mix of reads and writes
            for i in range(50):
                key = f"worker{worker_id}_key{i}"
                await cache.set(key, f"value{i}")
                await cache.get(key)
                # Concurrent stats reads
                stats = await cache.stats()
                assert stats["hits"] >= 0
                assert stats["misses"] >= 0
                assert 0.0 <= stats["hit_rate"] <= 1.0

        # Run multiple workers concurrently
        await asyncio.gather(*[worker(i) for i in range(10)])

        # Final stats should be consistent
        final_stats = await cache.stats()
        assert final_stats["hits"] > 0
        assert final_stats["misses"] >= 0
        total = final_stats["hits"] + final_stats["misses"]
        if total > 0:
            assert 0.0 <= final_stats["hit_rate"] <= 1.0


class TestTTLCacheCleanup:
    """Tests for proactive cache cleanup functionality."""

    @pytest.mark.asyncio
    async def test_cleanup_expired_removes_expired_entries(self, monkeypatch):
        """cleanup_expired removes all expired entries."""
        cache = TTLCache(maxsize=10, ttl=10)
        mock_time = 100.0

        def mock_monotonic():
            return mock_time

        monkeypatch.setattr(
            "www_confluence_mcp.utils.cache.time.monotonic", mock_monotonic
        )

        # Add entries
        await cache.set("key1", "value1")
        await cache.set("key2", "value2")
        await cache.set("key3", "value3")

        # Advance time past TTL
        mock_time = 115.0

        # Cleanup should remove all 3
        removed = await cache.cleanup_expired()
        assert removed == 3
        assert cache.size == 0

    @pytest.mark.asyncio
    async def test_cleanup_expired_partial_removal(self, monkeypatch):
        """cleanup_expired removes only expired entries."""
        cache = TTLCache(maxsize=10, ttl=10)
        mock_time = 100.0

        def mock_monotonic():
            return mock_time

        monkeypatch.setattr(
            "www_confluence_mcp.utils.cache.time.monotonic", mock_monotonic
        )

        # Add entries at different times
        await cache.set("key1", "value1")
        mock_time = 105.0
        await cache.set("key2", "value2")
        mock_time = 108.0
        await cache.set("key3", "value3")

        # Advance time - only key1 should be expired
        mock_time = 112.0

        removed = await cache.cleanup_expired()
        assert removed == 1
        assert cache.size == 2
        assert await cache.get("key1") is None
        assert await cache.get("key2") == "value2"
        assert await cache.get("key3") == "value3"

    @pytest.mark.asyncio
    async def test_cleanup_expired_tracks_count(self, monkeypatch):
        """cleanup_count tracks number of cleanup operations."""
        cache = TTLCache(maxsize=10, ttl=10)
        mock_time = 100.0

        def mock_monotonic():
            return mock_time

        monkeypatch.setattr(
            "www_confluence_mcp.utils.cache.time.monotonic", mock_monotonic
        )

        assert cache.cleanup_count == 0

        # First cleanup (no expired entries)
        await cache.cleanup_expired()
        assert cache.cleanup_count == 0

        # Add and expire entries
        await cache.set("key1", "value1")
        mock_time = 115.0
        await cache.cleanup_expired()
        assert cache.cleanup_count == 1

        # Second cleanup
        await cache.set("key2", "value2")
        mock_time = 130.0
        await cache.cleanup_expired()
        assert cache.cleanup_count == 2

    @pytest.mark.asyncio
    async def test_cleanup_triggered_on_get_when_large(self, monkeypatch):
        """Proactive cleanup triggered on get() when cache exceeds threshold."""
        # Create cache with small threshold for testing
        cache = TTLCache(maxsize=100, ttl=10)
        mock_time = 100.0

        def mock_monotonic():
            return mock_time

        monkeypatch.setattr(time, "monotonic", mock_monotonic)

        # Fill cache beyond threshold (64)
        for i in range(70):
            await cache.set(f"key{i}", f"value{i}")
            # Advance time slightly for each entry
            mock_time += 0.5

        # Advance time past TTL for early entries
        mock_time = 140.0

        # Get should trigger cleanup
        result = await cache.get("key69")
        assert result == "value69"

        # Cache should be smaller after cleanup
        stats = await cache.stats()
        # Early entries should be cleaned up
        assert stats["size"] < 70

    @pytest.mark.asyncio
    async def test_cleanup_triggered_on_set(self, monkeypatch):
        """Proactive cleanup triggered on set()."""
        cache = TTLCache(maxsize=100, ttl=10)
        mock_time = 100.0

        def mock_monotonic():
            return mock_time

        monkeypatch.setattr(time, "monotonic", mock_monotonic)

        # Fill cache
        for i in range(70):
            await cache.set(f"key{i}", f"value{i}")
            mock_time += 0.5

        # Advance time past TTL
        mock_time = 140.0

        # Set should trigger cleanup
        await cache.set("new_key", "new_value")

        # Early entries should be cleaned up
        stats = await cache.stats()
        assert stats["size"] < 71

    @pytest.mark.asyncio
    async def test_stats_includes_cleanup_count(self, monkeypatch):
        """Stats includes cleanup_count field."""
        cache = TTLCache(maxsize=10, ttl=10)
        mock_time = 100.0

        def mock_monotonic():
            return mock_time

        monkeypatch.setattr(
            "www_confluence_mcp.utils.cache.time.monotonic", mock_monotonic
        )

        await cache.set("key1", "value1")
        mock_time = 115.0

        await cache.cleanup_expired()

        stats = await cache.stats()
        assert "cleanup_count" in stats
        assert stats["cleanup_count"] == 1
