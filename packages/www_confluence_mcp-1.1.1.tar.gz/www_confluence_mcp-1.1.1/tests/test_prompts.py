"""Tests for external prompt schema, loader, and generator tools."""

import json
from pathlib import Path


from www_confluence_mcp.prompt_schema import (
    load_prompt_file,
    render_template,
    validate_prompt,
)
from www_confluence_mcp.prompt_loader import (
    get_loaded_prompts,
    load_prompts_from_dir,
)
from www_confluence_mcp.prompt_generate import (
    confluence_mcp_prompts,
)


# ---------------------------------------------------------------------------
# Schema validation
# ---------------------------------------------------------------------------


class TestValidatePrompt:
    def test_valid_minimal(self):
        data = {
            "name": "hello",
            "description": "Says hello",
            "arguments": [
                {"name": "user", "required": True},
            ],
            "template": "Hello {user}!",
        }
        assert validate_prompt(data) == []

    def test_valid_with_descriptions(self):
        data = {
            "name": "bug_report",
            "description": "Create bug report",
            "arguments": [
                {"name": "title", "required": True, "description": "Bug title"},
                {
                    "name": "severity",
                    "required": False,
                    "description": "critical/major/minor",
                },
            ],
            "template": "Bug: {title} [{severity}]",
        }
        assert validate_prompt(data) == []

    def test_missing_name(self):
        data = {
            "description": "desc",
            "arguments": [],
            "template": "Hello",
        }
        errors = validate_prompt(data)
        assert any("'name'" in e for e in errors)

    def test_missing_template(self):
        data = {
            "name": "test",
            "description": "desc",
            "arguments": [],
        }
        errors = validate_prompt(data)
        assert any("'template'" in e for e in errors)

    def test_invalid_name_chars(self):
        data = {
            "name": "my-prompt!",
            "description": "desc",
            "arguments": [],
            "template": "hello",
        }
        errors = validate_prompt(data)
        assert any("name" in e for e in errors)

    def test_duplicate_arg_names(self):
        data = {
            "name": "test",
            "description": "desc",
            "arguments": [
                {"name": "x", "required": True},
                {"name": "x", "required": False},
            ],
            "template": "{x}",
        }
        errors = validate_prompt(data)
        assert any("duplicate" in e for e in errors)

    def test_undefined_placeholder(self):
        data = {
            "name": "test",
            "description": "desc",
            "arguments": [
                {"name": "x", "required": True},
            ],
            "template": "{x} and {y}",
        }
        errors = validate_prompt(data)
        assert any("not defined in arguments" in e for e in errors)

    def test_extra_top_keys(self):
        data = {
            "name": "test",
            "description": "desc",
            "arguments": [],
            "template": "hello",
            "extra_field": "oops",
        }
        errors = validate_prompt(data)
        assert any("Unknown top-level" in e for e in errors)

    def test_arguments_not_list(self):
        data = {
            "name": "test",
            "description": "desc",
            "arguments": "not a list",
            "template": "hello",
        }
        errors = validate_prompt(data)
        assert any("list" in e for e in errors)


# ---------------------------------------------------------------------------
# File loading
# ---------------------------------------------------------------------------


class TestLoadPromptFile:
    def test_load_valid_json(self, tmp_path):
        f = tmp_path / "test.json"
        f.write_text(
            json.dumps(
                {
                    "name": "test_prompt",
                    "description": "A test",
                    "arguments": [{"name": "x", "required": True}],
                    "template": "Value: {x}",
                }
            )
        )
        data = load_prompt_file(f)
        assert data is not None
        assert data["name"] == "test_prompt"

    def test_load_invalid_json(self, tmp_path):
        f = tmp_path / "bad.json"
        f.write_text("{invalid json")
        assert load_prompt_file(f) is None

    def test_load_valid_yaml(self, tmp_path):
        f = tmp_path / "test.yaml"
        f.write_text(
            "name: yaml_prompt\n"
            "description: YAML test\n"
            "arguments:\n"
            "  - name: key\n"
            "    required: true\n"
            "template: 'Result: {key}'\n"
        )
        data = load_prompt_file(f)
        assert data is not None
        assert data["name"] == "yaml_prompt"

    def test_load_invalid_yaml(self, tmp_path):
        f = tmp_path / "bad.yaml"
        f.write_text("name: [\n  invalid\n")
        assert load_prompt_file(f) is None

    def test_load_unsupported_format(self, tmp_path):
        f = tmp_path / "test.toml"
        f.write_text("name = 'test'")
        assert load_prompt_file(f) is None

    def test_load_validation_fails(self, tmp_path):
        f = tmp_path / "bad.json"
        f.write_text(
            json.dumps({"name": "", "description": "", "arguments": [], "template": ""})
        )
        assert load_prompt_file(f) is None


# ---------------------------------------------------------------------------
# Template rendering
# ---------------------------------------------------------------------------


class TestRenderTemplate:
    def test_full_substitution(self):
        result = render_template(
            "Hello {name}, severity={level}!", {"name": "World", "level": "high"}
        )
        assert result == "Hello World, severity=high!"

    def test_missing_args_kept_as_placeholders(self):
        result = render_template("Hello {name}, {missing}!", {"name": "World"})
        assert result == "Hello World, {missing}!"

    def test_empty_value_kept_as_placeholder(self):
        result = render_template("Hello {name}!", {"name": ""})
        assert result == "Hello {name}!"

    def test_no_placeholders(self):
        result = render_template("Plain text", {"irrelevant": "value"})
        assert result == "Plain text"


# ---------------------------------------------------------------------------
# Directory loader
# ---------------------------------------------------------------------------


class TestLoadPromptsFromDir:
    def test_loads_json_and_yaml(self, tmp_path):
        (tmp_path / "a.json").write_text(
            json.dumps(
                {
                    "name": "prompt_a",
                    "description": "Prompt A",
                    "arguments": [{"name": "x", "required": True}],
                    "template": "{x}",
                }
            )
        )
        (tmp_path / "b.yaml").write_text(
            "name: prompt_b\ndescription: Prompt B\narguments: []\ntemplate: hello\n"
        )
        count = load_prompts_from_dir(tmp_path)
        assert count == 2
        loaded = get_loaded_prompts()
        assert "prompt_a" in loaded
        assert "prompt_b" in loaded

    def test_skips_dotfiles(self, tmp_path):
        (tmp_path / ".hidden.json").write_text("{}")
        count = load_prompts_from_dir(tmp_path)
        assert count == 0

    def test_skips_non_prompt_files(self, tmp_path):
        (tmp_path / "readme.txt").write_text("not a prompt")
        count = load_prompts_from_dir(tmp_path)
        assert count == 0

    def test_nonexistent_dir(self):
        count = load_prompts_from_dir(Path("/nonexistent_xyz"))
        assert count == 0


# ---------------------------------------------------------------------------
# List prompts tool
# ---------------------------------------------------------------------------


class TestListPromptsTool:
    async def test_list_empty(self):
        result = await confluence_mcp_prompts()
        assert result["status"] == "ok"
        assert result["count"] == 0
