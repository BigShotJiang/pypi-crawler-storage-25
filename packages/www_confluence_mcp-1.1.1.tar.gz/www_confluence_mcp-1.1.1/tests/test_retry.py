"""Tests for retry decorator with exponential backoff."""

import time
from unittest.mock import patch

import pytest
from www_confluence_mcp.exceptions import (
    ConfluenceAPIError,
    ConfluenceError,
    ConfluenceNotFoundError,
    ConfluenceRateLimitError,
)
from www_confluence_mcp.utils.retry import (
    RetryConfig,
    with_retry,
    _calculate_backoff,
)


class TestCalculateBackoff:
    def test_exponential_increase(self):
        """Backoff increases exponentially."""
        d1 = _calculate_backoff(1, backoff_factor=1.0, backoff_jitter=0.0)
        d2 = _calculate_backoff(2, backoff_factor=1.0, backoff_jitter=0.0)
        d3 = _calculate_backoff(3, backoff_factor=1.0, backoff_jitter=0.0)
        assert d1 < d2 < d3

    def test_max_backoff_clamp(self):
        """Backoff is clamped to max_backoff."""
        d = _calculate_backoff(
            100, backoff_factor=1.0, backoff_jitter=0.0, max_backoff=60.0
        )
        assert d <= 60.0

    def test_jitter_adds_variation(self):
        """Jitter adds random variation."""
        delays = [
            _calculate_backoff(1, backoff_factor=1.0, backoff_jitter=1.0)
            for _ in range(100)
        ]
        # With jitter, not all delays should be identical
        assert len(set(delays)) > 1


class TestRetryConfig:
    def test_defaults(self):
        """RetryConfig has correct defaults."""
        config = RetryConfig()
        assert config.max_retries == 3
        assert config.base_delay == 1.0
        assert config.max_delay == 180.0
        assert 429 in config.retryable_statuses
        assert 503 in config.retryable_statuses

    def test_custom_config(self):
        """RetryConfig accepts custom values."""
        config = RetryConfig(max_retries=5, base_delay=2.0, max_delay=120.0)
        assert config.max_retries == 5
        assert config.base_delay == 2.0
        assert config.max_delay == 120.0


class TestWithRetry:
    @pytest.mark.asyncio
    async def test_retry_on_429(self):
        """Retries on 429 status, succeeds on 3rd attempt."""
        call_count = 0

        async def failing_func():
            nonlocal call_count
            call_count += 1
            if call_count < 3:
                raise ConfluenceRateLimitError("rate limited", retry_after=0.01)
            return "success"

        # Wrap with retry
        config = RetryConfig(
            max_retries=3,
            base_delay=0.01,
            max_delay=0.1,
            retryable_statuses={429},
        )
        result = await with_retry(failing_func, config)()
        assert result == "success"
        assert call_count == 3

    @pytest.mark.asyncio
    async def test_max_retries_exceeded(self):
        """Raises error after max_retries attempts."""

        async def always_fail():
            raise ConfluenceRateLimitError("rate limited", retry_after=0.01)

        config = RetryConfig(
            max_retries=2,
            base_delay=0.01,
            max_delay=0.1,
            retryable_statuses={429},
        )
        with pytest.raises(ConfluenceRateLimitError):
            await with_retry(always_fail, config)()

    @pytest.mark.asyncio
    async def test_non_retryable_status(self):
        """No retry on 400/401/404."""
        call_count = 0

        async def fail_404():
            nonlocal call_count
            call_count += 1
            raise ConfluenceNotFoundError("not found")

        config = RetryConfig(
            max_retries=3,
            base_delay=0.01,
            max_delay=0.1,
            retryable_statuses={429, 503},
        )
        with pytest.raises(ConfluenceNotFoundError):
            await with_retry(fail_404, config)()
        assert call_count == 1  # No retry for 404

    @pytest.mark.asyncio
    async def test_retry_on_503(self):
        """Retries on 503 status."""
        call_count = 0

        async def fail_then_succeed():
            nonlocal call_count
            call_count += 1
            if call_count < 2:
                raise ConfluenceAPIError("server error", status_code=503)
            return "ok"

        config = RetryConfig(
            max_retries=3,
            base_delay=0.01,
            max_delay=0.1,
            retryable_statuses={503},
        )
        result = await with_retry(fail_then_succeed, config)()
        assert result == "ok"
        assert call_count == 2

    @pytest.mark.asyncio
    async def test_retry_after_header_integer(self):
        """Respects Retry-After header as integer seconds."""
        call_count = 0
        start_time = 0.0
        elapsed_time = 0.0

        async def fail_then_succeed():
            nonlocal call_count, start_time, elapsed_time
            call_count += 1
            if call_count == 1:
                start_time = time.monotonic()
                raise ConfluenceRateLimitError("rate limited", retry_after=0.1)
            elapsed_time = time.monotonic() - start_time
            return "ok"

        config = RetryConfig(
            max_retries=1,
            base_delay=0.01,
            max_delay=0.01,
            retryable_statuses={429},
        )
        result = await with_retry(fail_then_succeed, config)()
        assert result == "ok"
        assert call_count == 2
        # Should have waited ~0.1s (the retry_after value), not exponential backoff
        assert elapsed_time >= 0.08  # Allow some tolerance
        assert elapsed_time < 0.2  # Should not wait too long

    @pytest.mark.asyncio
    async def test_retry_after_header_http_date(self):
        """Respects Retry-After header as HTTP-date format.

        Note: The HTTP-date parsing is done in the client layer.
        This test verifies that when retry_after is set (from a parsed
        HTTP-date), the retry decorator respects it.
        """
        call_count = 0
        start_time = 0.0
        elapsed_time = 0.0

        async def fail_then_succeed():
            nonlocal call_count, start_time, elapsed_time
            call_count += 1
            if call_count == 1:
                start_time = time.monotonic()
                # Simulate a parsed HTTP-date Retry-After header value
                # In production, this would be parsed from the header by the client
                raise ConfluenceRateLimitError(
                    "rate limited",
                    retry_after=0.15,  # Parsed from HTTP-date header
                )
            elapsed_time = time.monotonic() - start_time
            return "ok"

        config = RetryConfig(
            max_retries=1,
            base_delay=0.01,
            max_delay=0.01,
            retryable_statuses={429},
        )
        result = await with_retry(fail_then_succeed, config)()
        assert result == "ok"
        assert call_count == 2
        # Should have waited ~0.15s (the retry_after value from parsed HTTP-date)
        assert elapsed_time >= 0.12  # Allow some tolerance
        assert elapsed_time < 0.25  # Should not wait too long


class TestRetryLogging:
    @pytest.mark.asyncio
    async def test_retry_logs_warning(self):
        """Logs warning on retry attempt."""
        call_count = 0

        async def fail_then_succeed():
            nonlocal call_count
            call_count += 1
            if call_count < 2:
                raise ConfluenceRateLimitError("rate limited", retry_after=0.01)
            return "ok"

        config = RetryConfig(
            max_retries=3,
            base_delay=0.01,
            max_delay=0.1,
            retryable_statuses={429},
        )

        # Capture log messages
        with patch("www_confluence_mcp.utils.retry.logger") as mock_logger:
            result = await with_retry(fail_then_succeed, config)()

        assert result == "ok"
        assert call_count == 2
        # Should have logged one warning for the retry
        mock_logger.warning.assert_called_once()
        # Verify the log message format
        args, kwargs = mock_logger.warning.call_args
        assert "Retry" in args[0]
        assert "status=429" in args[0] or 429 in args

    @pytest.mark.asyncio
    async def test_retry_log_message_content(self):
        """Retry log contains expected information."""
        call_count = 0

        async def fail_twice_then_succeed():
            nonlocal call_count
            call_count += 1
            if call_count < 3:
                raise ConfluenceAPIError("server error", status_code=503)
            return "success"

        config = RetryConfig(
            max_retries=3,
            base_delay=0.01,
            max_delay=0.1,
            retryable_statuses={503},
        )

        with patch("www_confluence_mcp.utils.retry.logger") as mock_logger:
            result = await with_retry(fail_twice_then_succeed, config)()

        assert result == "success"
        assert call_count == 3
        # Should have logged two warnings (for retry 1 and retry 2)
        assert mock_logger.warning.call_count == 2


class TestStatusCodeValidation:
    @pytest.mark.asyncio
    async def test_exception_without_status_code_attribute(self):
        """Handles exceptions without status_code attribute gracefully.

        This test ensures that if an exception doesn't have a status_code
        attribute, we don't raise AttributeError when checking retryability.
        """
        call_count = 0

        async def fail_without_status():
            nonlocal call_count
            call_count += 1
            # Raise an exception without status_code attribute
            raise ConfluenceError("error without status code")

        config = RetryConfig(
            max_retries=3,
            base_delay=0.01,
            max_delay=0.1,
            retryable_statuses={429, 503},
        )

        # Should raise immediately without AttributeError
        with pytest.raises(ConfluenceError, match="error without status code"):
            await with_retry(fail_without_status, config)()

        # Should only be called once (no retry)
        assert call_count == 1

    @pytest.mark.asyncio
    async def test_exception_with_none_status_code(self):
        """Handles exceptions with None status_code gracefully."""
        call_count = 0

        class CustomConfluenceError(ConfluenceError):
            def __init__(self, message: str):
                super().__init__(message)
                self.status_code = None

        async def fail_with_none_status():
            nonlocal call_count
            call_count += 1
            raise CustomConfluenceError("error with None status")

        config = RetryConfig(
            max_retries=3,
            base_delay=0.01,
            max_delay=0.1,
            retryable_statuses={429, 503},
        )

        # Should raise immediately without AttributeError
        with pytest.raises(CustomConfluenceError, match="error with None status"):
            await with_retry(fail_with_none_status, config)()

        # Should only be called once (no retry)
        assert call_count == 1

    @pytest.mark.asyncio
    async def test_exception_with_zero_status_code(self):
        """Handles exceptions with 0 status_code gracefully."""
        call_count = 0

        class CustomConfluenceError(ConfluenceError):
            def __init__(self, message: str):
                super().__init__(message)
                self.status_code = 0

        async def fail_with_zero_status():
            nonlocal call_count
            call_count += 1
            raise CustomConfluenceError("error with 0 status")

        config = RetryConfig(
            max_retries=3,
            base_delay=0.01,
            max_delay=0.1,
            retryable_statuses={429, 503},
        )

        # Should raise immediately (0 is not retryable)
        with pytest.raises(CustomConfluenceError, match="error with 0 status"):
            await with_retry(fail_with_zero_status, config)()

        # Should only be called once (no retry)
        assert call_count == 1
