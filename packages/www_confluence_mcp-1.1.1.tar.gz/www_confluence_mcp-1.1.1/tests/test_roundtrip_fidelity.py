"""Test that HTML → markdown → HTML round-trip produces equivalent output.

This module contains round-trip fidelity tests for the Confluence converter.
Each test verifies that converting HTML to markdown and back produces equivalent output.
"""

from pathlib import Path

import pytest

from conftest import (
    normalize_confluence_artifacts,
    normalize_whitespace,
    normalize_br_after_table,
    normalize_stray_headings,
    normalize_trailing_hr,
    normalize_p_strong_pattern,
    strip_namespace_declarations,
    strip_div_wrapper,
)
from www_confluence_mcp.utils.converter import markdown_to_storage


def normalize_html(html_content: str) -> str:
    """Apply all normalizations to HTML content for comparison."""
    result = html_content

    # Step 1: Strip wrapper div
    result = strip_div_wrapper(result)

    # Step 2: Strip namespace declarations
    result = strip_namespace_declarations(result)

    # Step 3: Normalize Confluence editor artifacts
    result = normalize_confluence_artifacts(result)

    # Step 4: Normalize <br> after tables
    result = normalize_br_after_table(result)

    # Step 5: Normalize stray headings
    result = normalize_stray_headings(result)

    # Step 6: Normalize trailing <hr>
    result = normalize_trailing_hr(result)

    # Step 7: Normalize <p><strong> pattern
    result = normalize_p_strong_pattern(result)

    # Step 8: Normalize whitespace
    result = normalize_whitespace(result)

    return result


def run_roundtrip_test(html_file: str, md_file: str) -> None:
    """Run round-trip fidelity test for a given HTML/MD file pair.

    Args:
        html_file: Path to the original HTML file
        md_file: Path to the markdown file

    Raises:
        AssertionError: If round-trip produces different output
    """
    # Read original files
    with open(html_file) as f:
        original_html = f.read()

    with open(md_file) as f:
        markdown_content = f.read()

    # Convert markdown back to HTML
    restored_html = markdown_to_storage(markdown_content)

    # Normalize both original and restored HTML
    orig_normalized = normalize_html(original_html)
    rest_normalized = normalize_html(restored_html)

    # Compare
    if orig_normalized != rest_normalized:
        # Find first difference for debugging
        for i, (a, b) in enumerate(zip(orig_normalized, rest_normalized)):
            if a != b:
                context_start = max(0, i - 50)
                context_end = min(len(orig_normalized), i + 50)
                print(f"First difference at position {i}:")
                print(f"  Original: ...{orig_normalized[context_start:context_end]}...")
                print(f"  Restored: ...{rest_normalized[context_start:context_end]}...")
                break
        else:
            print(
                f"Length mismatch: original={len(orig_normalized)}, "
                f"restored={len(rest_normalized)}"
            )

        # Write restored to file for inspection
        restored_file = html_file.replace(".html", "_restored.html")
        with open(restored_file, "w") as f:
            f.write(restored_html)

        pytest.fail(
            f"Round-trip fidelity check failed for {html_file}. "
            f"See {restored_file} for restored HTML."
        )


# Test data directory
TEST_DATA_DIR = Path(__file__).parent


def test_roundtrip_fidelity_page_2333535448():
    """Test round-trip fidelity for page 2333535448.

    HTML → markdown → HTML must match original after normalization.
    """
    html_file = TEST_DATA_DIR / "page_2333535448.html"
    md_file = TEST_DATA_DIR / "page_2333535448.md"

    # Skip if test data files don't exist
    if not html_file.exists() or not md_file.exists():
        pytest.skip("Test data files not found")

    run_roundtrip_test(str(html_file), str(md_file))


# Add more test cases here as needed:
# def test_roundtrip_fidelity_page_xxxxx():
#     html_file = TEST_DATA_DIR / "page_xxxxx.html"
#     md_file = TEST_DATA_DIR / "page_xxxxx.md"
#     if not html_file.exists() or not md_file.exists():
#         pytest.skip("Test data files not found")
#     run_roundtrip_test(str(html_file), str(md_file))
