"""End-to-end round-trip tests using fixture files."""

from pathlib import Path
from www_confluence_mcp.utils.converter import (
    storage_to_markdown,
    markdown_to_storage,
    validate_roundtrip,
)

FIXTURES = Path(__file__).parent / "fixtures"


class TestEndToEndRoundTrip:
    """Full round-trip tests: CSF → MD → CSF using fixture files."""

    def test_simple_page_round_trip(self, page_data):
        """Simple page (headings, paragraphs, lists) survives round-trip."""
        html = (FIXTURES / "simple_page.html").read_text()
        md_content = storage_to_markdown(html, page_data)
        restored = markdown_to_storage(md_content)

        # Content preserved
        assert "Simple Page" in restored
        assert "bold" in restored or "strong" in restored
        assert "Item 1" in restored

    def test_macros_page_round_trip(self, page_data):
        """Page with macros (info, code, toc) survives round-trip."""
        html = (FIXTURES / "macros_page.html").read_text()
        md_content = storage_to_markdown(html, page_data)
        restored = markdown_to_storage(md_content)

        # Macros preserved
        assert "ac:structured-macro" in restored
        assert "info" in restored or "code" in restored
        # Content preserved
        assert "Active" in restored or "Status" in restored

    def test_tables_page_round_trip(self, page_data):
        """Page with tables survives round-trip."""
        html = (FIXTURES / "tables_page.html").read_text()
        md_content = storage_to_markdown(html, page_data)
        restored = markdown_to_storage(md_content)

        # Table content preserved
        assert "Header 1" in restored or "Cell 1" in restored

    def test_nested_macros_round_trip(self, page_data):
        """Nested macros (ui-tabs → ui-tab → info) survive round-trip."""
        html = (FIXTURES / "nested_macros.html").read_text()
        md_content = storage_to_markdown(html, page_data)
        restored = markdown_to_storage(md_content)

        # Nested structure preserved
        assert "ui-tabs" in restored or "ui-tab" in restored
        assert "Information" in restored or "Tab Info" in restored

    def test_task_list_round_trip(self, page_data):
        """Task list survives round-trip."""
        html = (FIXTURES / "task_list.html").read_text()
        md_content = storage_to_markdown(html, page_data)
        restored = markdown_to_storage(md_content)

        # Tasks preserved
        assert "Задача выполнена" in restored or "task" in restored.lower()

    def test_inline_elements_round_trip(self, page_data):
        """Inline elements (user, page link, image, emoticon) survive round-trip."""
        html = (FIXTURES / "inline_elements.html").read_text()
        md_content = storage_to_markdown(html, page_data)
        restored = markdown_to_storage(md_content)

        # Inline elements preserved
        assert "kiselyovpa" in restored or "user" in restored.lower()
        assert "Документация" in restored or "Docs" in restored or "DOC" in restored
        assert "diagram.png" in restored

    def test_double_round_trip(self, page_data):
        """Double round-trip: CSF → MD → CSF → MD → CSF."""
        html = (FIXTURES / "simple_page.html").read_text()

        # First round-trip
        md1 = storage_to_markdown(html, page_data)
        csf1 = markdown_to_storage(md1)

        # Second round-trip
        md2 = storage_to_markdown(csf1, page_data)
        csf2 = markdown_to_storage(md2)

        # Content stable after double round-trip
        assert "Simple Page" in csf2
        assert "bold" in csf2 or "strong" in csf2

    def test_element_count_validation(self, page_data):
        """Element counts match after round-trip."""
        html = (FIXTURES / "macros_page.html").read_text()
        md_content = storage_to_markdown(html, page_data)
        restored = markdown_to_storage(md_content)

        is_valid, errors = validate_roundtrip(html, restored)
        assert is_valid, f"Round-trip validation failed: {errors}"

    def test_markdown_format_structure(self, page_data):
        """Markdown has correct structure: frontmatter + content."""
        html = (FIXTURES / "simple_page.html").read_text()
        md_content = storage_to_markdown(html, page_data)

        # Has frontmatter
        assert md_content.startswith("---\n")
        assert "confluence:" in md_content
        assert "pageId:" in md_content

        # Has content after frontmatter
        parts = md_content.split("---\n")
        assert len(parts) >= 3  # ---, frontmatter, ---, content
