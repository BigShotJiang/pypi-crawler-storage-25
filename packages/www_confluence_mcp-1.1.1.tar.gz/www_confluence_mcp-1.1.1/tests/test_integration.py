"""Integration tests with real Confluence API.

Requires CONFLUENCE_TEST_PATH environment variable pointing to a test page.
All operations are limited to children of that test page.
Tests are skipped if CONFLUENCE_TEST_PATH is not set.
"""

from __future__ import annotations

import os
import re
import uuid

import pytest

from www_confluence_mcp.api.session import close_client
from www_confluence_mcp.api.pages import create_page, delete_page, get_page, update_page
from www_confluence_mcp.exceptions import ConfluenceNotFoundError
from www_confluence_mcp.utils.converter import (
    markdown_to_storage,
    storage_to_markdown,
)

# ---------------------------------------------------------------------------
# Skip if no test path configured
# ---------------------------------------------------------------------------

TEST_PATH = os.getenv("CONFLUENCE_TEST_PATH", "").strip()

pytestmark = pytest.mark.skipif(
    not TEST_PATH,
    reason="CONFLUENCE_TEST_PATH not set — integration tests disabled",
)


def _parse_page_id(url: str) -> str:
    """Extract pageId from Confluence URL."""
    match = re.search(r"pageId=(\d+)", url)
    if not match:
        raise ValueError(f"Cannot parse pageId from: {url}")
    return match.group(1)


TEST_PAGE_ID = _parse_page_id(TEST_PATH) if TEST_PATH else ""


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture(autouse=True)
async def _close_client_after_test():
    """Close niquests singleton after each test to avoid stale connections."""
    yield
    await close_client()


@pytest.fixture
def unique_title():
    """Generate unique page title for test isolation."""
    return f"MCP-TEST-{uuid.uuid4().hex[:8]}"


@pytest.fixture
async def test_child_page(unique_title):
    """Create and delete a child page under the test page.

    Yields (page_id, page_data).  Always deletes on teardown.
    """
    body = "<h1>Integration Test</h1><p>Auto-generated page. Safe to delete.</p>"
    created = await create_page(
        space_key="CDP",
        title=unique_title,
        body_value=body,
        parent_id=TEST_PAGE_ID,
    )
    page_id = str(created["id"])
    try:
        yield page_id, created
    finally:
        try:
            await delete_page(page_id)
        except Exception:
            pass  # best-effort cleanup


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestConnection:
    """Verify API connectivity (one call only)."""

    @pytest.mark.asyncio
    async def test_get_test_page(self):
        """Fetch the test page — confirms auth works."""
        page = await get_page(TEST_PAGE_ID, body_format="storage")
        assert page.get("id") == TEST_PAGE_ID
        assert "title" in page


class TestDownloadUpload:
    """Test download → convert → upload flow within test page."""

    @pytest.mark.asyncio
    async def test_download_convert_upload_roundtrip(self, test_child_page):
        """Create child → download as MD → upload back → verify."""
        page_id, page_data = test_child_page

        # Download as markdown
        downloaded = await get_page(page_id, body_format="storage")
        html = downloaded.get("body", {}).get("storage", {}).get("value", "")
        assert html, "Downloaded page has no body"

        # Convert to markdown
        md_content = storage_to_markdown(html, downloaded)
        assert "---" in md_content  # has frontmatter
        assert "Integration Test" in md_content

        # Convert back to storage format
        restored_html = markdown_to_storage(md_content)
        assert "Integration Test" in restored_html

        # Upload restored content
        current_version = downloaded.get("version", {}).get("number", 1)
        updated = await update_page(
            page_id=page_id,
            title=downloaded["title"],
            body_value=restored_html,
            version_number=current_version + 1,
        )
        assert str(updated.get("id")) == page_id

        # Re-download and verify content preserved
        redownloaded = await get_page(page_id, body_format="storage")
        new_body = redownloaded.get("body", {}).get("storage", {}).get("value", "")
        assert "Integration Test" in new_body


class TestErrorHandling:
    """Test error handling with real API (one call per error type)."""

    @pytest.mark.asyncio
    async def test_404_returns_error(self):
        """Fetching non-existent page raises ConfluenceNotFoundError."""
        with pytest.raises(ConfluenceNotFoundError, match="404"):
            await get_page("999999999")

    @pytest.mark.asyncio
    async def test_create_delete_cleanup(self, unique_title):
        """Create and immediately delete — tests both endpoints."""
        body = "<p>Temporary</p>"
        created = await create_page(
            space_key="CDP",
            title=unique_title,
            body_value=body,
            parent_id=TEST_PAGE_ID,
        )
        page_id = str(created["id"])
        assert page_id

        # Verify it exists
        fetched = await get_page(page_id)
        assert fetched.get("title") == unique_title

        # Delete it
        await delete_page(page_id)

        # Verify it's gone (should 404)
        with pytest.raises(ConfluenceNotFoundError, match="404"):
            await get_page(page_id)
