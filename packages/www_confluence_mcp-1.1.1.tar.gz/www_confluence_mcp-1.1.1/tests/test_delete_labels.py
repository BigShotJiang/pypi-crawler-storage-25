"""Tests for confluence_delete_labels tool."""

import pytest
from unittest.mock import AsyncMock, patch

from www_confluence_mcp.tools.confluence_delete_labels import confluence_delete_labels


class TestConfluenceDeleteLabels:
    """Tests for confluence_delete_labels batch tool."""

    async def test_empty_list_input(self):
        """Empty list should raise ValueError."""
        with pytest.raises(ValueError, match="pages must be a non-empty list"):
            await confluence_delete_labels(items=[])

    async def test_invalid_item_format(self):
        """Non-dict items should return error results."""
        with patch(
            "www_confluence_mcp.tools.confluence_delete_labels.delete_page_label",
            new_callable=AsyncMock,
        ):
            result = await confluence_delete_labels(items=["not_a_dict", 123])
        assert result["status"] == "ok"
        assert len(result["results"]) == 2
        for res in result["results"]:
            assert res["status"] == "error"
            assert "Invalid item format: expected dict" in res["error"]

    async def test_missing_required_keys(self):
        """Items missing required keys should return error results."""
        with patch(
            "www_confluence_mcp.tools.confluence_delete_labels.delete_page_label",
            new_callable=AsyncMock,
        ):
            # Missing labels key
            result = await confluence_delete_labels(items=[{"page_id": "123"}])
        assert result["status"] == "ok"
        assert len(result["results"]) == 1
        assert result["results"][0]["status"] == "error"
        assert "Missing required key: labels" in result["results"][0]["error"]

        # Missing page_id key
        with patch(
            "www_confluence_mcp.tools.confluence_delete_labels.delete_page_label",
            new_callable=AsyncMock,
        ):
            result = await confluence_delete_labels(items=[{"labels": ["tag1"]}])
        assert result["status"] == "ok"
        assert len(result["results"]) == 1
        assert result["results"][0]["status"] == "error"
        assert "Missing required key: page_id" in result["results"][0]["error"]

    async def test_successful_label_deletion(self):
        """Single label deletion from single page returns success."""
        mock_delete = AsyncMock(return_value=None)
        with patch(
            "www_confluence_mcp.tools.confluence_delete_labels.delete_page_label",
            mock_delete,
        ):
            result = await confluence_delete_labels(
                items=[{"page_id": "123", "labels": ["tag1"]}]
            )
        assert result["status"] == "ok"
        assert len(result["results"]) == 1
        assert result["results"][0]["page_id"] == "123"
        assert len(result["results"][0]["labels"]) == 1
        assert result["results"][0]["labels"][0]["label"] == "tag1"
        assert result["results"][0]["labels"][0]["status"] == "ok"
        mock_delete.assert_called_once_with("123", "tag1")

    async def test_batch_deletion_with_errors(self):
        """Batch deletion with some label deletions failing."""

        async def delete_label_side_effect(page_id, label):
            if label == "tag2":
                raise Exception("Label not found")
            return None

        mock_delete = AsyncMock(side_effect=delete_label_side_effect)
        with patch(
            "www_confluence_mcp.tools.confluence_delete_labels.delete_page_label",
            mock_delete,
        ):
            result = await confluence_delete_labels(
                items=[
                    {"page_id": "123", "labels": ["tag1", "tag2"]},
                    {"page_id": "456", "labels": ["tag3"]},
                ]
            )
        assert result["status"] == "ok"
        assert len(result["results"]) == 2

        # First page: mixed results
        assert result["results"][0]["page_id"] == "123"
        assert len(result["results"][0]["labels"]) == 2
        assert result["results"][0]["labels"][0]["label"] == "tag1"
        assert result["results"][0]["labels"][0]["status"] == "ok"
        assert result["results"][0]["labels"][1]["label"] == "tag2"
        assert result["results"][0]["labels"][1]["status"] == "error"
        assert "Label not found" in result["results"][0]["labels"][1]["error"]

        # Second page: success
        assert result["results"][1]["page_id"] == "456"
        assert len(result["results"][1]["labels"]) == 1
        assert result["results"][1]["labels"][0]["label"] == "tag3"
        assert result["results"][1]["labels"][0]["status"] == "ok"
