"""
Tests for the enhanced HTML to Markdown converter
"""

from www_confluence_mcp.utils.enhanced_converter import EnhancedHTMLToMarkdownConverter


class TestEnhancedConverter:
    """Tests for the enhanced converter"""

    def test_ui_tabs_conversion(self):
        """Test UI tabs conversion"""
        converter = EnhancedHTMLToMarkdownConverter()

        html = """
        <ac:structured-macro ac:name="ui-tabs">
            <ac:rich-text-body>
                <ac:structured-macro ac:name="ui-tab">
                    <ac:parameter ac:name="title">Первый таб</ac:parameter>
                    <ac:rich-text-body>Содержимое первого таба</ac:rich-text-body>
                </ac:structured-macro>
                <ac:structured-macro ac:name="ui-tab">
                    <ac:parameter ac:name="title">Второй таб</ac:parameter>
                    <ac:rich-text-body>Содержимое второго таба</ac:rich-text-body>
                </ac:structured-macro>
            </ac:rich-text-body>
        </ac:structured-macro>
        """

        result = converter.convert(html)

        assert "### Первый таб" in result
        assert "Содержимое первого таба" in result
        assert "### Второй таб" in result
        assert "Содержимое второго таба" in result

    def test_task_list_conversion(self):
        """Test task list conversion"""
        converter = EnhancedHTMLToMarkdownConverter()

        html = """
        <ac:task-list>
            <ac:task ac:task-id="1" ac:task-status="complete">
                <ac:task-body>Выполненная задача</ac:task-body>
            </ac:task>
            <ac:task ac:task-id="2" ac:task-status="incomplete">
                <ac:task-body>Невыполненная задача</ac:task-body>
            </ac:task>
        </ac:task-list>
        """

        result = converter.convert(html)

        assert "[x] Выполненная задача" in result
        assert "[ ] Невыполненная задача" in result

    def test_info_macro_with_title(self):
        """Test info macro with title"""
        converter = EnhancedHTMLToMarkdownConverter()

        html = """
        <ac:structured-macro ac:name="info">
            <ac:parameter ac:name="title">Важная информация</ac:parameter>
            <ac:rich-text-body>Текст информационного блока</ac:rich-text-body>
        </ac:structured-macro>
        """

        result = converter.convert(html)

        assert "ℹ️ **Важная информация:** Текст информационного блока" in result

    def test_user_links(self):
        """Test user links"""
        converter = EnhancedHTMLToMarkdownConverter()

        html = """
        <p>Ответственный: <ri:user ri:username="john.doe" /></p>
        <p>Исполнитель: <ri:user ri:userkey="4032868d:5f45e208-7f75-46a0-a490-1a6b12c57e01" /></p>
        """

        result = converter.convert(html)

        assert "@john.doe" in result
        assert "@4032868d:5f45e208-7f75-46a0-a490-1a6b12c57e01" in result

    def test_nested_content(self):
        """Test nested content"""
        converter = EnhancedHTMLToMarkdownConverter()

        html = """
        <h1>Заголовок</h1>
        <p>Простой параграф</p>
        <ac:structured-macro ac:name="ui-tabs">
            <ac:rich-text-body>
                <ac:structured-macro ac:name="ui-tab">
                    <ac:parameter ac:name="title">Таб с задачами</ac:parameter>
                    <ac:rich-text-body>
                        <ac:task-list>
                            <ac:task ac:task-id="1" ac:task-status="complete">
                                <ac:task-body>Задача в табе</ac:task-body>
                            </ac:task>
                        </ac:task-list>
                    </ac:rich-text-body>
                </ac:structured-macro>
            </ac:rich-text-body>
        </ac:structured-macro>
        """

        result = converter.convert(html)

        assert "# Заголовок" in result
        assert "Простой параграф" in result
        assert "### Таб с задачами" in result
        assert "[x] Задача в табе" in result
