"""Tests for confluence_mcp_health MCP tool."""

from unittest.mock import AsyncMock

from www_confluence_mcp.tools.confluence_mcp_health import (
    _check_confluence_connectivity,
    _get_cache_stats,
    confluence_mcp_health,
)


class TestHealthReturnsStatus:
    """Test that confluence_mcp_health returns proper status structure."""

    async def test_health_returns_status(self, monkeypatch):
        """Verify health check returns all required status fields."""
        # Mock the API call to simulate successful connectivity
        monkeypatch.setattr(
            "www_confluence_mcp.tools.confluence_mcp_health.get_spaces",
            AsyncMock(return_value={"results": [{"key": "DEV"}]}),
        )

        result = await confluence_mcp_health()

        # Check required fields exist
        assert "status" in result
        assert "timestamp" in result
        assert "uptime_seconds" in result
        assert "version" in result
        assert "tool_count" in result
        assert "confluence_connection" in result
        assert "cache_stats" in result
        assert "conversion_metrics" in result

        # Check status values
        assert result["status"] in ["healthy", "degraded"]
        assert result["version"] == "2.0.0"
        assert isinstance(result["uptime_seconds"], (int, float))
        assert result["uptime_seconds"] >= 0
        assert isinstance(result["tool_count"], int)
        assert result["tool_count"] > 0

    async def test_health_status_degraded_on_connection_failure(self, monkeypatch):
        """Verify health check returns degraded status when Confluence is unreachable."""
        # Mock the API call to simulate connection failure
        monkeypatch.setattr(
            "www_confluence_mcp.tools.confluence_mcp_health.get_spaces",
            AsyncMock(side_effect=Exception("Connection refused")),
        )

        result = await confluence_mcp_health()

        assert result["status"] == "degraded"
        assert result["confluence_connection"]["reachable"] is False
        assert "error" in result["confluence_connection"]


class TestHealthReportsConfluenceConnectivity:
    """Test Confluence connectivity checking."""

    async def test_health_reports_confluence_connectivity_success(self, monkeypatch):
        """Verify connectivity check succeeds when Confluence is reachable."""
        monkeypatch.setattr(
            "www_confluence_mcp.tools.confluence_mcp_health.get_spaces",
            AsyncMock(
                return_value={"results": [{"key": "DEV", "name": "Development"}]}
            ),
        )

        connectivity = await _check_confluence_connectivity()

        assert connectivity["status"] == "connected"
        assert connectivity["reachable"] is True

    async def test_health_reports_confluence_connectivity_failure(self, monkeypatch):
        """Verify connectivity check fails gracefully when Confluence is unreachable."""
        monkeypatch.setattr(
            "www_confluence_mcp.tools.confluence_mcp_health.get_spaces",
            AsyncMock(side_effect=ConnectionError("Network error")),
        )

        connectivity = await _check_confluence_connectivity()

        assert connectivity["status"] == "error"
        assert connectivity["reachable"] is False
        assert "Network error" in connectivity["error"]

    async def test_health_reports_confluence_connectivity_timeout(self, monkeypatch):
        """Verify connectivity check handles timeout errors."""
        monkeypatch.setattr(
            "www_confluence_mcp.tools.confluence_mcp_health.get_spaces",
            AsyncMock(side_effect=TimeoutError("Request timeout")),
        )

        connectivity = await _check_confluence_connectivity()

        assert connectivity["status"] == "error"
        assert connectivity["reachable"] is False
        assert "Request timeout" in connectivity["error"]


class TestHealthReportsMetrics:
    """Test metrics reporting in health check."""

    def test_cache_stats_returns_structure(self):
        """Verify cache stats returns proper structure."""
        stats = _get_cache_stats()

        assert "hits" in stats
        assert "misses" in stats
        assert "hit_rate" in stats
        assert "size" in stats

        assert isinstance(stats["hits"], int)
        assert isinstance(stats["misses"], int)
        assert isinstance(stats["hit_rate"], float)
        assert isinstance(stats["size"], int)
        assert stats["hit_rate"] >= 0.0
        assert stats["hit_rate"] <= 1.0

    async def test_health_reports_conversion_metrics(self, monkeypatch):
        """Verify health check includes conversion metrics summary."""
        monkeypatch.setattr(
            "www_confluence_mcp.tools.confluence_mcp_health.get_spaces",
            AsyncMock(return_value={"results": []}),
        )

        result = await confluence_mcp_health()

        metrics = result["conversion_metrics"]
        assert "total_conversions" in metrics
        assert "avg_latency_ms" in metrics
        assert "total_errors" in metrics
        assert "elements_preserved" in metrics
        assert "elements_converted" in metrics

    async def test_health_increments_tool_count(self, monkeypatch):
        """Verify tool count reflects registered tools."""
        monkeypatch.setattr(
            "www_confluence_mcp.tools.confluence_mcp_health.get_spaces",
            AsyncMock(return_value={"results": []}),
        )

        result = await confluence_mcp_health()

        # Should have at least 25+ tools registered
        assert result["tool_count"] >= 25

    async def test_health_uptime_increases(self, monkeypatch):
        """Verify uptime increases between calls."""
        monkeypatch.setattr(
            "www_confluence_mcp.tools.confluence_mcp_health.get_spaces",
            AsyncMock(return_value={"results": []}),
        )

        result1 = await confluence_mcp_health()
        # Small delay to ensure uptime difference
        import time

        time.sleep(0.1)
        result2 = await confluence_mcp_health()

        assert result2["uptime_seconds"] >= result1["uptime_seconds"]
