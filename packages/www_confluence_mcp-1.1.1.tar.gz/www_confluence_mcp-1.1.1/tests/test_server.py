"""Tests for www_confluence_mcp — config, client, and server tools (Server/DC v1 API)."""

from pathlib import Path
from unittest.mock import AsyncMock

import pytest

from www_confluence_mcp.config import (
    _env_bool,
    _env_int,
    _env_str,
    _detect_auth,
)
from www_confluence_mcp.server import (
    main,
    mcp,
    get_request_count,
    increment_request_count,
)
from www_confluence_mcp.tools.confluence_get_page import confluence_get_page
from www_confluence_mcp.tools.confluence_search_cql import confluence_search_cql
from www_confluence_mcp.tools.confluence_get_pages import confluence_get_pages
from www_confluence_mcp.tools.confluence_get_page_history import (
    confluence_get_page_history,
)
from www_confluence_mcp.tools.confluence_get_page_ancestors import (
    confluence_get_page_ancestors,
)
from www_confluence_mcp.tools.confluence_get_spaces import confluence_get_spaces
from www_confluence_mcp.tools.confluence_get_page_comments import (
    confluence_get_page_comments,
)
from www_confluence_mcp.utils.url import parse_confluence_url as _parse_confluence_url
from www_confluence_mcp.tools.confluence_get_page_labels import (
    confluence_get_page_labels,
)
from www_confluence_mcp.tools.confluence_get_page_attachments import (
    confluence_get_page_attachments,
)
from www_confluence_mcp.tools.confluence_download_attachments import (
    confluence_download_attachments,
)
from www_confluence_mcp.tools.confluence_get_page_images import (
    confluence_get_page_images,
)
from www_confluence_mcp.info import confluence_mcp_info
from www_confluence_mcp.tools.confluence_add_comment import confluence_add_comment
from www_confluence_mcp.tools.confluence_add_labels import confluence_add_labels
from www_confluence_mcp.tools.confluence_new_page import confluence_new_page
from www_confluence_mcp.tools.confluence_move_page import confluence_move_page
from www_confluence_mcp.tools.confluence_update_page import confluence_update_page
from www_confluence_mcp.tools.confluence_upload_attachments import (
    confluence_upload_attachments,
)
from www_confluence_mcp.tools.confluence_validate_page import (
    confluence_validate_page,
)
from www_confluence_mcp.tools.confluence_delete_attachments import (
    confluence_delete_attachments,
)


# ---------------------------------------------------------------------------
# Config tests
# ---------------------------------------------------------------------------


class TestEnvHelpers:
    def test_env_str(self, monkeypatch):
        monkeypatch.setenv("TEST_STR", "  hello  ")
        assert _env_str("TEST_STR") == "hello"

    def test_env_str_default(self):
        assert _env_str("NONEXISTENT_VAR_XYZ") == ""

    def test_env_int(self, monkeypatch):
        monkeypatch.setenv("TEST_INT", "42")
        assert _env_int("TEST_INT", 10) == 42

    def test_env_int_default(self):
        assert _env_int("NONEXISTENT_VAR_XYZ", 10) == 10

    def test_env_int_clamp(self, monkeypatch):
        monkeypatch.setenv("TEST_CLAMP", "200")
        assert _env_int("TEST_CLAMP", 10, hi=100) == 100

    def test_env_bool_true(self, monkeypatch):
        monkeypatch.setenv("TEST_BOOL", "true")
        assert _env_bool("TEST_BOOL") is True

    def test_env_bool_false(self, monkeypatch):
        monkeypatch.setenv("TEST_BOOL", "no")
        assert _env_bool("TEST_BOOL") is False  # "no" is not in truthy set

    def test_env_bool_false_correct(self, monkeypatch):
        monkeypatch.setenv("TEST_BOOL2", "false")
        assert _env_bool("TEST_BOOL2", default=True) is False

    def test_env_bool_default(self):
        assert _env_bool("NONEXISTENT_VAR_XYZ", default=True) is True
        assert _env_bool("NONEXISTENT_VAR_XYZ", default=False) is False


class TestAuthDetect:
    def test_dc_pat(self, monkeypatch):
        monkeypatch.setenv("CONFLUENCE_URL", "https://confluence.internal.com")
        monkeypatch.setenv("CONFLUENCE_PERSONAL_TOKEN", "my-pat-token")
        auth_type, user, token, pat = _detect_auth()
        assert auth_type == "pat"
        assert pat == "my-pat-token"

    def test_dc_basic(self, monkeypatch):
        monkeypatch.setenv("CONFLUENCE_URL", "https://confluence.internal.com")
        monkeypatch.setenv("CONFLUENCE_USERNAME", "admin")
        monkeypatch.setenv("CONFLUENCE_PASSWORD", "pass")
        monkeypatch.delenv("CONFLUENCE_PERSONAL_TOKEN", raising=False)
        auth_type, user, password, pat = _detect_auth()
        assert auth_type == "basic"
        assert password == "pass"

    def test_dc_no_auth(self, monkeypatch):
        monkeypatch.setenv("CONFLUENCE_URL", "https://confluence.internal.com")
        monkeypatch.delenv("CONFLUENCE_USERNAME", raising=False)
        monkeypatch.delenv("CONFLUENCE_PASSWORD", raising=False)
        monkeypatch.delenv("CONFLUENCE_API_TOKEN", raising=False)
        monkeypatch.delenv("CONFLUENCE_PERSONAL_TOKEN", raising=False)
        with pytest.raises(ValueError, match="CONFLUENCE_PASSWORD"):
            _detect_auth()

    def test_no_url(self, monkeypatch):
        monkeypatch.delenv("CONFLUENCE_URL", raising=False)
        with pytest.raises(ValueError, match="CONFLUENCE_URL"):
            _detect_auth()

    def test_pat_takes_priority_over_basic(self, monkeypatch):
        monkeypatch.setenv("CONFLUENCE_URL", "https://confluence.example.com")
        monkeypatch.setenv("CONFLUENCE_PERSONAL_TOKEN", "my-pat")
        monkeypatch.setenv("CONFLUENCE_USERNAME", "admin")
        monkeypatch.setenv("CONFLUENCE_PASSWORD", "pass")
        auth_type, _, _, pat = _detect_auth()
        assert auth_type == "pat"
        assert pat == "my-pat"

    def test_api_token_backward_compat(self, monkeypatch):
        """CONFLUENCE_API_TOKEN still works as fallback for CONFLUENCE_PASSWORD."""
        monkeypatch.setenv("CONFLUENCE_URL", "https://confluence.example.com")
        monkeypatch.setenv("CONFLUENCE_USERNAME", "admin")
        monkeypatch.setenv("CONFLUENCE_API_TOKEN", "legacy-pass")
        monkeypatch.delenv("CONFLUENCE_PASSWORD", raising=False)
        monkeypatch.delenv("CONFLUENCE_PERSONAL_TOKEN", raising=False)
        auth_type, _, password, _ = _detect_auth()
        assert auth_type == "basic"
        assert password == "legacy-pass"

    def test_password_takes_priority_over_api_token(self, monkeypatch):
        """CONFLUENCE_PASSWORD takes priority over CONFLUENCE_API_TOKEN."""
        monkeypatch.setenv("CONFLUENCE_URL", "https://confluence.example.com")
        monkeypatch.setenv("CONFLUENCE_USERNAME", "admin")
        monkeypatch.setenv("CONFLUENCE_PASSWORD", "new-pass")
        monkeypatch.setenv("CONFLUENCE_API_TOKEN", "old-pass")
        monkeypatch.delenv("CONFLUENCE_PERSONAL_TOKEN", raising=False)
        _, _, password, _ = _detect_auth()
        assert password == "new-pass"


# ---------------------------------------------------------------------------
# Server tool tests (mocked API)
# ---------------------------------------------------------------------------


class TestReadOnly:
    def test_write_tools_not_registered_in_read_only(self, monkeypatch):
        """When READ_ONLY=true, write tools are not registered on the MCP server."""
        write_tool_names = {
            "confluence_new_page",
            "confluence_update_page",
            "confluence_delete_pages",
            "confluence_add_comment",
            "confluence_add_labels",
            "confluence_delete_labels",
            "confluence_upload_attachments",
            "confluence_delete_attachments",
            "confluence_move_page",
        }
        registered = {t.name for t in mcp._tool_manager._tools.values()}
        assert write_tool_names.issubset(registered), (
            f"Missing: {write_tool_names - registered}"
        )

    async def test_write_allowed_when_not_read_only(self, mock_confluence, monkeypatch):
        monkeypatch.setattr("www_confluence_mcp.config.READ_ONLY", False)
        mock_confluence.create_page.return_value = {"id": "new1", "title": "New"}
        result = await confluence_new_page(space_key="DEV", title="New", content="x")
        assert result["status"] == "created"

    async def test_read_not_blocked_in_read_only(self, mock_confluence, monkeypatch):
        monkeypatch.setattr("www_confluence_mcp.config.READ_ONLY", True)
        from www_confluence_mcp.models import SearchResponse

        mock_confluence.search_cql.return_value = SearchResponse(results=[], links={})
        result = await confluence_search_cql("test")
        assert result["status"] == "no_results"


class TestMain:
    def test_main_is_callable(self):
        assert callable(main)


class TestRequestCounting:
    def test_get_request_count_initial(self):
        """Initial request count is 0."""
        # Note: This test assumes a fresh module load
        # In practice, the counter may have been incremented by other tests
        count = get_request_count()
        assert isinstance(count, int)
        assert count >= 0

    def test_increment_request_count(self):
        """increment_request_count increases counter."""
        initial = get_request_count()
        new_count = increment_request_count()
        assert new_count == initial + 1
        assert get_request_count() == new_count

    def test_get_request_count_after_increment(self):
        """get_request_count returns updated value after increment."""
        initial = get_request_count()
        increment_request_count()
        assert get_request_count() == initial + 1


class TestSearchTool:
    async def test_search_returns_results(self, mock_confluence):
        from www_confluence_mcp.models import SearchResponse, SearchResult

        mock_confluence.search_cql.return_value = SearchResponse(
            results=[SearchResult(id="1", title="Test Page", type="page")],
            links={"next": "/rest/api/content/search?cql=test&start=25&limit=25"},
        )
        result = await confluence_search_cql("test query")
        assert result["status"] == "ok"
        assert result["result_count"] == 1
        assert result["next_start"] == "25"

    async def test_search_no_results(self, mock_confluence):
        from www_confluence_mcp.models import SearchResponse

        mock_confluence.search_cql.return_value = SearchResponse(results=[], links={})
        result = await confluence_search_cql("nonexistent")
        assert result["status"] == "no_results"
        assert result["next_start"] is None

    async def test_search_empty_query(self, mock_confluence):
        with pytest.raises(ValueError):
            await confluence_search_cql("   ")


class TestParseConfluenceUrl:
    def test_viewpage_action(self):
        result = _parse_confluence_url(
            "https://confluence.example.com/pages/viewpage.action?pageId=1234567890123"
        )
        assert result["page_id"] == "1234567890123"

    def test_display_url(self):
        result = _parse_confluence_url(
            "https://confluence.example.com/display/DEV/My+Page+Title"
        )
        assert result["space_key"] == "DEV"
        assert result["title"] == "My Page Title"

    def test_viewpage_no_query(self):
        result = _parse_confluence_url(
            "https://confluence.example.com/pages/viewpage.action"
        )
        assert result == {"page_id": None, "space_key": None, "title": None}

    def test_display_with_context_path(self):
        result = _parse_confluence_url(
            "https://confluence.example.com/confluence/display/DEV/My+Page"
        )
        assert result["space_key"] == "DEV"
        assert result["title"] == "My Page"


class TestGetPageTool:
    async def test_get_page_by_id(self, mock_confluence):
        mock_confluence.get_page.return_value = {
            "id": "123",
            "title": "My Page",
            "space": {"key": "DEV"},
            "version": {"number": 1},
            "body": {"storage": {"value": "<h1>Test</h1>"}},
        }
        result = await confluence_get_page(page="123")
        assert result["status"] == "ok"
        assert result["page_id"] == "123"
        assert result["format"] == "markdown"
        assert "content" in result

    async def test_get_page_by_url(self, mock_confluence):
        mock_confluence.get_page.return_value = {
            "id": "1234567890123",
            "title": "Server Page",
            "space": {"key": "DEV"},
            "version": {"number": 1},
            "body": {"storage": {"value": "<h1>Test</h1>"}},
        }
        result = await confluence_get_page(
            page="https://confluence.example.com/pages/viewpage.action?pageId=1234567890123"
        )
        assert result["status"] == "ok"
        assert result["page_id"] == "1234567890123"
        mock_confluence.get_page.assert_called_once_with(
            "1234567890123", body_format="storage"
        )

    async def test_get_page_no_args(self, mock_confluence):
        with pytest.raises(TypeError, match="missing 1 required positional argument"):
            await confluence_get_page()

    async def test_get_page_both_args(self, mock_confluence):
        # The actual API only accepts 'page' parameter, not both page_id and page_url
        # This test is no longer applicable - the API uses a single 'page' parameter
        pass

    async def test_get_page_with_file_path(self, mock_confluence, tmp_path):
        mock_confluence.get_page.return_value = {
            "id": "123",
            "title": "My Page",
            "space": {"key": "DEV"},
            "version": {"number": 1},
            "body": {"storage": {"value": "<h1>Test</h1>"}},
        }
        file_path = str(tmp_path / "page.md")
        result = await confluence_get_page(page="123", file_path=file_path)
        assert result["status"] == "ok"
        assert result["file_path"] == file_path
        assert result["format"] == "markdown"
        # Verify file was created
        assert Path(file_path).exists()


class TestSpacesTools:
    async def test_get_spaces_list(self, mock_confluence):
        mock_confluence.get_spaces.return_value = {
            "results": [{"key": "DEV", "name": "Development"}]
        }
        result = await confluence_get_spaces()
        assert "results" in result

    async def test_get_space_by_key(self, mock_confluence):
        mock_confluence.get_space.return_value = {"key": "DEV", "name": "Development"}
        result = await confluence_get_spaces(space_key="DEV")
        assert result["key"] == "DEV"

    async def test_get_space_empty_key(self, mock_confluence):
        with pytest.raises(ValueError):
            await confluence_get_spaces(space_key="   ")


class TestAncestorsTool:
    async def test_get_ancestors(self, mock_confluence):
        mock_confluence.get_page_ancestors.return_value = [{"id": "0"}]
        result = await confluence_get_page_ancestors(page="1")
        assert "results" in result


class TestCommentsTools:
    async def test_get_comments(self, mock_confluence):
        mock_confluence.get_footer_comments.return_value = {"results": []}
        result = await confluence_get_page_comments(page="1")
        assert "results" in result

    async def test_add_comment(self, mock_confluence):
        mock_confluence.create_comment.return_value = {"id": "c1"}
        result = await confluence_add_comment(page="1", content="Nice!")
        assert result["status"] == "created"


class TestLabelsTools:
    async def test_get_labels(self, mock_confluence):
        mock_confluence.get_page_labels.return_value = {"results": [{"name": "docs"}]}
        result = await confluence_get_page_labels(page="1")
        assert "results" in result

    async def test_add_labels(self, mock_confluence):
        mock_confluence.add_page_labels.return_value = {"results": []}
        result = await confluence_add_labels(page="1", labels=["docs", "api"])
        assert result["labels_added"] == 2

    async def test_add_labels_empty(self, mock_confluence):
        with pytest.raises(ValueError):
            await confluence_add_labels(page="1", labels=[])


class TestAttachmentsTools:
    async def test_get_attachments(self, mock_confluence):
        mock_confluence.get_attachments.return_value = {"results": []}
        result = await confluence_get_page_attachments(page="1")
        assert "results" in result


class TestPageCrudTools:
    async def test_create_page(self, mock_confluence):
        mock_confluence.create_page.return_value = {"id": "new1", "title": "New"}
        result = await confluence_new_page(
            space_key="DEV", title="New", content="<p>Hi</p>"
        )
        assert result["status"] == "created"

    async def test_create_page_empty_title(self, mock_confluence):
        with pytest.raises(ValueError):
            await confluence_new_page(space_key="DEV", title="  ", content="x")

    async def test_update_page(self, mock_confluence):
        mock_confluence.update_page.return_value = {
            "id": "1",
            "version": {"number": 3},
        }
        result = await confluence_update_page(
            page="1",
            title="Updated",
            content_source="<p>x</p>",
            version_number=3,
        )
        assert result["status"] == "updated"


class TestPagesTool:
    async def test_get_pages_by_space(self, mock_confluence):
        mock_confluence.get_space_page_tree.return_value = {
            "space_key": "DEV",
            "total_pages": 2,
            "has_more": False,
            "pages": [],
        }
        result = await confluence_get_pages(space_key="DEV")
        assert "pages" in result

    async def test_get_pages_by_page_id(self, mock_confluence):
        mock_confluence.get_child_pages.return_value = {
            "results": [{"id": "2"}],
            "_links": {},
        }
        result = await confluence_get_pages(parent_page_id="1")
        assert "results" in result

    async def test_get_pages_no_args(self, mock_confluence):
        with pytest.raises(ValueError):
            await confluence_get_pages()


class TestDownloadAttachmentsTool:
    async def test_download_all_attachments(self, mock_confluence):
        from www_confluence_mcp.models import (
            ContentAttachmentDownloadBatchResponse,
            ContentAttachmentDownloadResult,
        )

        mock_confluence.download_content_attachments.return_value = (
            ContentAttachmentDownloadBatchResponse(
                results=[
                    ContentAttachmentDownloadResult(
                        id="a1", status="downloaded", bytes=10
                    ),
                ],
                downloaded=1,
            )
        )
        result = await confluence_download_attachments(
            page="1",
            save_dir="/tmp/atts",
        )
        assert result["downloaded"] == 1

    async def test_download_specific_attachments(self, mock_confluence):
        mock_confluence.download_attachment.return_value = {
            "status": "downloaded",
            "bytes": 42,
            "saved_to": "/tmp/test.txt",
        }
        result = await confluence_download_attachments(
            page="1",
            save_dir="/tmp/atts",
            attachment_ids=["a1"],
        )
        assert result["downloaded"] == 1


class TestPageHistoryTool:
    async def test_get_page_history(self, mock_confluence):
        mock_confluence.get_page_history.return_value = {
            "results": [{"number": 1}],
            "version": {"number": 1},
        }
        result = await confluence_get_page_history(page="1")
        assert "results" in result


class TestMovePageTool:
    async def test_move_page(self, mock_confluence):
        mock_confluence.move_page.return_value = {"id": "1"}
        result = await confluence_move_page(page="1", parent_id_dest="2")
        assert result["status"] == "moved"

    async def test_move_page_no_args(self, mock_confluence):
        with pytest.raises(ValueError):
            await confluence_move_page(page="1")


class TestUploadAttachmentsTool:
    async def test_upload_attachments(self, mock_confluence):
        from www_confluence_mcp.models import (
            AttachmentUploadBatchResponse,
            AttachmentUploadResult,
        )

        mock_confluence.upload_attachments.return_value = AttachmentUploadBatchResponse(
            results=[
                AttachmentUploadResult(id="a1", title="f1.txt", status="uploaded")
            ],
            total=1,
            uploaded=1,
            failed=0,
        )
        result = await confluence_upload_attachments(
            page="1",
            file_paths=["/tmp/f1.txt"],
        )
        assert result["uploaded"] == 1

    async def test_upload_attachments_empty(self, mock_confluence):
        with pytest.raises(ValueError):
            await confluence_upload_attachments(page="1", file_paths=[])


class TestPageImagesTool:
    async def test_get_page_images(self, mock_confluence):
        mock_confluence.get_page_images.return_value = [
            {
                "id": "a1",
                "title": "pic.png",
                "mime_type": "image/png",
                "size": 100,
                "data": "base64...",
            },
        ]
        result = await confluence_get_page_images(page="1")
        assert result["total_images"] == 1
        assert result["downloaded"] == 1

    async def test_get_page_images_empty(self, mock_confluence):
        mock_confluence.get_page_images.return_value = []
        result = await confluence_get_page_images(page="1")
        assert result["total_images"] == 0


class TestMcpInfoTool:
    async def test_mcp_info_returns_configuration(self, monkeypatch):
        """confluence_mcp_info should return configuration information."""
        # Set some environment variables for testing
        monkeypatch.setenv("CONFLUENCE_URL", "https://test.confluence.com")
        monkeypatch.setenv("CONFLUENCE_MAX_RESULTS", "50")
        monkeypatch.setenv("CONFLUENCE_READ_ONLY", "false")

        result = await confluence_mcp_info()

        assert result["status"] == "ok"
        assert result["server_name"] == "www-confluence-mcp"
        assert "auth" in result
        assert "environment_variables" in result
        assert "notes" in result

        # Check that key environment variables are documented
        env_var_names = [var["name"] for var in result["environment_variables"]]
        expected_vars = [
            "CONFLUENCE_URL",
            "CONFLUENCE_PERSONAL_TOKEN",
            "CONFLUENCE_USERNAME",
            "CONFLUENCE_PASSWORD",
            "CONFLUENCE_SSL_VERIFY",
            "CONFLUENCE_TIMEOUT",
            "CONFLUENCE_MAX_RESULTS",
            "CONFLUENCE_READ_ONLY",
        ]
        for var in expected_vars:
            assert var in env_var_names

        # Check structure of each environment variable entry
        for var in result["environment_variables"]:
            assert "name" in var
            assert "description" in var
            assert "default" in var
            assert "current" in var
            assert "format" in var
            assert "example" in var
            assert "purpose" in var

        # Check that sensitive values are masked
        pat_var = next(
            v
            for v in result["environment_variables"]
            if v["name"] == "CONFLUENCE_PERSONAL_TOKEN"
        )
        # PAT should be masked if set, shown as None if not set
        assert pat_var["current"] is None or pat_var["current"] == "***"

        # Check notes
        assert len(result["notes"]) > 0
        assert any("PAT authentication" in note for note in result["notes"])

        # Check auth status
        assert result["auth"]["type"] in ["not_configured", "pat", "basic"]
        assert "configured" in result["auth"]
        assert "method" in result["auth"]

    async def test_mcp_info_with_auth_configured(self, monkeypatch):
        """confluence_mcp_info should show auth status when configured."""
        # Set up PAT authentication
        monkeypatch.setenv("CONFLUENCE_URL", "https://test.confluence.com")
        monkeypatch.setenv("CONFLUENCE_PERSONAL_TOKEN", "test-pat-token")

        # Reload the module to pick up the new auth
        import www_confluence_mcp
        import importlib

        importlib.reload(www_confluence_mcp.config)
        importlib.reload(www_confluence_mcp.info)

        # Import the reloaded function
        from www_confluence_mcp.info import confluence_mcp_info as reloaded_info

        result = await reloaded_info()

        assert result["auth"]["type"] == "pat"
        assert result["auth"]["configured"] is True
        assert result["auth"]["method"] == "Personal Access Token"

        # Check PAT is masked
        pat_var = next(
            v
            for v in result["environment_variables"]
            if v["name"] == "CONFLUENCE_PERSONAL_TOKEN"
        )
        assert pat_var["current"] == "***"


# ---------------------------------------------------------------------------
# Tests for additional MCP tools (coverage for uncovered tools)
# ---------------------------------------------------------------------------


class TestConfluenceValidatePage:
    """Tests for confluence_validate_page tool."""

    async def test_validate_page_mode_valid(self, monkeypatch):
        """Validate page mode with valid page."""
        import www_confluence_mcp.tools.confluence_validate_page as val_mod

        monkeypatch.setattr(
            val_mod,
            "get_page",
            AsyncMock(
                return_value={
                    "id": "123",
                    "title": "Test Page",
                    "body": {"storage": {"value": "<h1>Test</h1><p>Content</p>"}},
                }
            ),
        )
        monkeypatch.setattr(
            val_mod,
            "storage_to_markdown",
            lambda html, data: "---\nconfluence:\n  pageId: '123'\n---\n\n# Test",
        )
        monkeypatch.setattr(
            val_mod, "markdown_to_storage", lambda md: "<h1>Test</h1><p>Content</p>"
        )
        monkeypatch.setattr(
            val_mod, "validate_roundtrip", lambda orig, restored: (True, [])
        )
        # Mock xhtml_validator
        monkeypatch.setattr(val_mod, "validate_xhtml", lambda html: (True, [], []))

        result = await confluence_validate_page(page="123")
        assert result["is_valid"] is True
        assert result["page_id"] == "123"
        assert "original_elements" in result

    async def test_validate_page_mode_invalid(self, monkeypatch):
        """Validate page mode detects differences."""
        import www_confluence_mcp.tools.confluence_validate_page as val_mod

        monkeypatch.setattr(
            val_mod,
            "get_page",
            AsyncMock(
                return_value={
                    "id": "456",
                    "title": "Test Page",
                    "body": {
                        "storage": {"value": "<h1>Test</h1><ac:structured-macro/>"}
                    },
                }
            ),
        )
        monkeypatch.setattr(
            val_mod,
            "storage_to_markdown",
            lambda html, data: "---\nconfluence:\n  pageId: '456'\n---\n\n# Test",
        )
        monkeypatch.setattr(val_mod, "markdown_to_storage", lambda md: "<h1>Test</h1>")
        monkeypatch.setattr(
            val_mod,
            "validate_roundtrip",
            lambda orig, restored: (False, ["Missing macro"]),
        )
        monkeypatch.setattr(val_mod, "validate_xhtml", lambda html: (True, [], []))

        result = await confluence_validate_page(page="456")
        assert result["roundtrip_valid"] is False
        assert len(result["errors"]["roundtrip"]) > 0

    async def test_validate_page_mode_error(self, monkeypatch):
        """Error handling for validate page."""
        import www_confluence_mcp.tools.confluence_validate_page as val_mod

        monkeypatch.setattr(
            val_mod, "get_page", AsyncMock(side_effect=Exception("Page not found"))
        )

        result = await confluence_validate_page(page="999")
        assert "error" in result or result.get("status") == "error"

    async def test_validate_file_mode_not_found(self):
        """File mode with non-existent file."""
        result = await confluence_validate_page(file_source="/nonexistent/file.md")
        assert "error" in result or result.get("is_valid") is False

    async def test_validate_content_mode_markdown(self, monkeypatch):
        """Content mode with markdown input."""
        import www_confluence_mcp.tools.confluence_validate_page as val_mod

        monkeypatch.setattr(val_mod, "markdown_to_storage", lambda md: "<h1>Test</h1>")
        monkeypatch.setattr(val_mod, "validate_xhtml", lambda html: (True, [], []))

        result = await confluence_validate_page(content_source="# Test Heading")
        assert result["content_type"] == "markdown"
        assert result["is_valid"] is True

    async def test_validate_content_mode_html(self, monkeypatch):
        """Content mode with HTML input."""
        import www_confluence_mcp.tools.confluence_validate_page as val_mod

        monkeypatch.setattr(val_mod, "validate_xhtml", lambda html: (True, [], []))

        result = await confluence_validate_page(content_source="<h1>Test</h1>")
        # Note: HTML without Confluence macros is detected as markdown by is_markdown_content
        assert result["is_valid"] is True

    async def test_validate_no_mode_provided(self):
        """Error when no mode is provided."""
        result = await confluence_validate_page()
        assert "error" in result or result.get("is_valid") is False

    async def test_validate_multiple_modes_provided(self):
        """Error when multiple modes are provided."""
        result = await confluence_validate_page(page="123", file_source="/tmp/test.md")
        assert "error" in result or result.get("is_valid") is False


class TestConfluenceDeleteAttachments:
    """Tests for confluence_delete_attachments batch tool."""

    async def test_delete_attachments_batch(self, mock_confluence):
        """Delete multiple attachments in batch."""
        mock_confluence.delete_attachment.return_value = None

        result = await confluence_delete_attachments(
            attachments=[{"attachment_id": "att123"}, {"attachment_id": "att456"}]
        )
        assert result["status"] == "ok"
        assert len(result["results"]) == 2
