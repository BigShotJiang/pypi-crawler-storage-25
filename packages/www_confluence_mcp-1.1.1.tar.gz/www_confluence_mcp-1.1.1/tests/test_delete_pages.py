"""Tests for confluence_delete_pages tool."""

import pytest
from unittest.mock import AsyncMock, patch

from www_confluence_mcp.tools.confluence_delete_pages import confluence_delete_pages


class TestConfluenceDeletePages:
    """Tests for confluence_delete_pages batch tool."""

    async def test_empty_list_input(self):
        """Empty list should raise ValueError."""
        with pytest.raises(ValueError, match="pages must be a non-empty list"):
            await confluence_delete_pages(pages=[])

    async def test_invalid_item_format(self):
        """Non-dict items should return error results."""
        mock_delete = AsyncMock()
        with patch(
            "www_confluence_mcp.tools.confluence_delete_pages.delete_page", mock_delete
        ):
            result = await confluence_delete_pages(pages=["not_a_dict", 123])
        assert result["status"] == "ok"
        assert len(result["results"]) == 2
        for res in result["results"]:
            assert res["status"] == "error"
            assert "Invalid item format: expected dict" in res["error"]

    async def test_missing_required_key(self):
        """Items missing page_id should return error results."""
        mock_delete = AsyncMock()
        with patch(
            "www_confluence_mcp.tools.confluence_delete_pages.delete_page", mock_delete
        ):
            result = await confluence_delete_pages(pages=[{"wrong_key": "123"}])
        assert result["status"] == "ok"
        assert len(result["results"]) == 1
        assert result["results"][0]["status"] == "error"
        assert "Missing required key: page_id" in result["results"][0]["error"]

    async def test_successful_deletion_single_page(self):
        """Single page deletion returns success."""
        mock_delete = AsyncMock(return_value=None)
        with patch(
            "www_confluence_mcp.tools.confluence_delete_pages.delete_page", mock_delete
        ):
            result = await confluence_delete_pages(pages=[{"page_id": "123"}])
        assert result["status"] == "ok"
        assert len(result["results"]) == 1
        assert result["results"][0]["page_id"] == "123"
        assert result["results"][0]["status"] == "ok"
        mock_delete.assert_called_once_with("123")

    async def test_batch_deletion_multiple_pages(self):
        """Batch deletion of multiple pages."""
        mock_delete = AsyncMock(return_value=None)
        with patch(
            "www_confluence_mcp.tools.confluence_delete_pages.delete_page", mock_delete
        ):
            result = await confluence_delete_pages(
                pages=[{"page_id": "123"}, {"page_id": "456"}, {"page_id": "789"}]
            )
        assert result["status"] == "ok"
        assert len(result["results"]) == 3
        page_ids = [r["page_id"] for r in result["results"]]
        assert page_ids == ["123", "456", "789"]
        assert all(r["status"] == "ok" for r in result["results"])
        assert mock_delete.call_count == 3

    async def test_mixed_success_error_results(self):
        """Mixed results when some deletions fail."""

        async def delete_side_effect(page_id):
            if page_id == "456":
                raise Exception("Permission denied")
            return None

        mock_delete = AsyncMock(side_effect=delete_side_effect)
        with patch(
            "www_confluence_mcp.tools.confluence_delete_pages.delete_page", mock_delete
        ):
            result = await confluence_delete_pages(
                pages=[{"page_id": "123"}, {"page_id": "456"}, {"page_id": "789"}]
            )
        assert result["status"] == "ok"
        assert len(result["results"]) == 3
        # First page: success
        assert result["results"][0]["page_id"] == "123"
        assert result["results"][0]["status"] == "ok"
        # Second page: error
        assert result["results"][1]["page_id"] == "456"
        assert result["results"][1]["status"] == "error"
        assert "Permission denied" in result["results"][1]["error"]
        # Third page: success
        assert result["results"][2]["page_id"] == "789"
        assert result["results"][2]["status"] == "ok"

    async def test_exception_handling(self):
        """Exception during deletion is caught and reported."""
        mock_delete = AsyncMock(side_effect=Exception("API error"))
        with patch(
            "www_confluence_mcp.tools.confluence_delete_pages.delete_page", mock_delete
        ):
            result = await confluence_delete_pages(pages=[{"page_id": "123"}])
        assert result["status"] == "ok"
        assert len(result["results"]) == 1
        assert result["results"][0]["page_id"] == "123"
        assert result["results"][0]["status"] == "error"
        assert "API error" in result["results"][0]["error"]
