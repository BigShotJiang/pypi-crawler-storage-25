"""Shared pytest fixtures for www-confluence-mcp tests."""

import re
from pathlib import Path
from unittest.mock import AsyncMock

import pytest


# ---------------------------------------------------------------------------
# Shared test data fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def page_data():
    """Standard page data dict for testing.

    Returns a typical Confluence page structure with id, title, space, version,
    and _links. Suitable for most converter and API tests.
    """
    return {
        "id": "123",
        "title": "Test Page",
        "space": {"key": "TEST"},
        "version": {"number": 1},
        "_links": {
            "base": "https://confluence.example.com",
            "webui": "/pages/123",
        },
    }


# ---------------------------------------------------------------------------
# Mock client fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def mock_confluence(monkeypatch):
    """Patch the API client module to return mock responses.

    Creates an AsyncMock and patches all API functions.
    Tests can configure mock return values via mock_confluence.<method>.return_value.

    The same mock functions are both:
    1. Patched into the API modules (so calls use the mock)
    2. Set as attributes on the returned mock object (so tests can configure them)

    Usage:
        async def test_something(mock_confluence):
            mock_confluence.get_page.return_value = {"id": "123"}
            result = await confluence_get_page(page="123")
    """
    import importlib
    import www_confluence_mcp.api.session as session_mod
    import www_confluence_mcp.api.pages as pages_mod
    import www_confluence_mcp.api.spaces as spaces_mod
    import www_confluence_mcp.api.comments as comments_mod
    import www_confluence_mcp.api.labels as labels_mod
    import www_confluence_mcp.api.attachments as attachments_mod
    import www_confluence_mcp.api.users as users_mod
    import www_confluence_mcp.api.images as images_mod
    import www_confluence_mcp.api.space_tree as space_tree_mod

    # Import search module properly (not the function)
    search_mod = importlib.import_module("www_confluence_mcp.api.search")

    # Import tool modules that import API functions
    import www_confluence_mcp.tools.confluence_get_page as tool_get_page_mod
    import www_confluence_mcp.tools.confluence_get_page_history as tool_get_page_history_mod
    import www_confluence_mcp.tools.confluence_get_page_ancestors as tool_get_page_ancestors_mod
    import www_confluence_mcp.tools.confluence_get_spaces as tool_get_spaces_mod
    import www_confluence_mcp.tools.confluence_get_pages as tool_get_pages_mod
    import www_confluence_mcp.tools.confluence_get_page_comments as tool_get_comments_mod
    import www_confluence_mcp.tools.confluence_get_page_labels as tool_get_labels_mod
    import www_confluence_mcp.tools.confluence_get_page_attachments as tool_get_attachments_mod
    import www_confluence_mcp.tools.confluence_get_page_images as tool_get_images_mod
    import www_confluence_mcp.tools.confluence_add_comment as tool_add_comment_mod
    import www_confluence_mcp.tools.confluence_add_labels as tool_add_labels_mod
    import www_confluence_mcp.tools.confluence_new_page as tool_new_page_mod
    import www_confluence_mcp.tools.confluence_update_page as tool_update_page_mod
    import www_confluence_mcp.tools.confluence_move_page as tool_move_page_mod
    import www_confluence_mcp.tools.confluence_download_attachments as tool_download_attachments_mod
    import www_confluence_mcp.tools.confluence_upload_attachments as tool_upload_attachments_mod
    import www_confluence_mcp.tools.confluence_delete_attachments as tool_delete_attachments_mod
    import www_confluence_mcp.tools.read_helpers as read_helpers_mod
    import www_confluence_mcp.tools.write_helpers as write_helpers_mod

    # Create the main mock object
    mock = AsyncMock()

    # Helper to create mock, patch module, and set on mock object
    def create_and_patch(modules_and_names):
        """Patch a function in multiple modules and add to mock object."""
        mock_func = AsyncMock()
        for module, name in modules_and_names:
            monkeypatch.setattr(module, name, mock_func)
        setattr(mock, name, mock_func)
        return mock_func

    # Mock the request function to prevent actual API calls
    async def mock_request(*args, **kwargs):
        return {}

    monkeypatch.setattr(session_mod, "request", mock_request)
    monkeypatch.setattr(session_mod, "get_client", mock)

    # Pages module - patch in API and all tool modules that import it
    for name in [
        "get_page",
        "get_page_by_title",
        "get_child_pages",
        "get_page_ancestors",
        "create_page",
        "update_page",
        "delete_page",
        "get_page_history",
        "move_page",
    ]:
        modules_to_patch = [(pages_mod, name)]
        # Add tool modules that import this function
        if name == "get_page":
            modules_to_patch.extend(
                [
                    (tool_get_page_mod, name),
                    (tool_update_page_mod, name),
                    (tool_move_page_mod, name),
                    (read_helpers_mod, name),
                    (write_helpers_mod, name),
                ]
            )
        elif name == "get_page_by_title":
            if hasattr(write_helpers_mod, name):
                modules_to_patch.append((write_helpers_mod, name))
        elif name == "get_child_pages":
            if hasattr(tool_get_pages_mod, name):
                modules_to_patch.append((tool_get_pages_mod, name))
        elif name == "get_page_ancestors":
            if hasattr(tool_get_page_ancestors_mod, name):
                modules_to_patch.append((tool_get_page_ancestors_mod, name))
        elif name == "create_page":
            modules_to_patch.extend(
                [
                    (tool_new_page_mod, name),
                    (write_helpers_mod, name),
                ]
            )
        elif name == "update_page":
            modules_to_patch.extend(
                [
                    (tool_update_page_mod, name),
                    (write_helpers_mod, name),
                ]
            )
        elif name == "get_page_history":
            if hasattr(tool_get_page_history_mod, name):
                modules_to_patch.append((tool_get_page_history_mod, name))
        elif name == "move_page":
            if hasattr(tool_move_page_mod, name):
                modules_to_patch.append((tool_move_page_mod, name))

        create_and_patch(modules_to_patch)

    # Spaces module
    for name in ["get_spaces", "get_space"]:
        modules_to_patch = [(spaces_mod, name)]
        if hasattr(tool_get_spaces_mod, name):
            modules_to_patch.append((tool_get_spaces_mod, name))
        create_and_patch(modules_to_patch)

    # Comments module
    for name in ["get_footer_comments", "create_comment", "reply_to_comment"]:
        modules_to_patch = [(comments_mod, name)]
        if name == "get_footer_comments":
            modules_to_patch.append((tool_get_comments_mod, name))
        elif name == "create_comment":
            modules_to_patch.append((tool_add_comment_mod, name))
        create_and_patch(modules_to_patch)

    # Labels module
    for name in ["get_page_labels", "add_page_labels", "delete_page_label"]:
        modules_to_patch = [(labels_mod, name)]
        if name == "get_page_labels":
            modules_to_patch.append((tool_get_labels_mod, name))
        elif name == "add_page_labels":
            modules_to_patch.append((tool_add_labels_mod, name))
        create_and_patch(modules_to_patch)

    # Search module - patch search_cql
    import www_confluence_mcp.tools.confluence_search_cql as tool_search_mod

    mock_search = AsyncMock()
    monkeypatch.setattr(search_mod, "search_cql", mock_search)
    if hasattr(tool_search_mod, "search_cql"):
        monkeypatch.setattr(tool_search_mod, "search_cql", mock_search)
    setattr(mock, "search_cql", mock_search)

    # Attachments module
    for name in [
        "get_attachments",
        "upload_attachment",
        "download_attachment",
        "delete_attachment",
        "download_content_attachments",
        "upload_attachments",
    ]:
        modules_to_patch = [(attachments_mod, name)]
        if name == "get_attachments":
            modules_to_patch.append((tool_get_attachments_mod, name))
        elif name == "download_attachment":
            modules_to_patch.append((tool_download_attachments_mod, name))
        elif name == "delete_attachment":
            modules_to_patch.append((tool_delete_attachments_mod, name))
        elif name == "download_content_attachments":
            modules_to_patch.append((tool_download_attachments_mod, name))
        elif name == "upload_attachments":
            modules_to_patch.append((tool_upload_attachments_mod, name))
        create_and_patch(modules_to_patch)

    # Users module
    for name in ["search_user"]:
        create_and_patch([(users_mod, name)])

    # Images module
    for name in ["get_page_images"]:
        modules_to_patch = [(images_mod, name)]
        if name == "get_page_images":
            modules_to_patch.append((tool_get_images_mod, name))
        create_and_patch(modules_to_patch)

    # Space tree module
    for name in ["get_space_page_tree"]:
        modules_to_patch = [(space_tree_mod, name)]
        if name == "get_space_page_tree":
            modules_to_patch.append((tool_get_pages_mod, name))
        create_and_patch(modules_to_patch)

    return mock


# ---------------------------------------------------------------------------
# State reset fixtures
# ---------------------------------------------------------------------------


@pytest.fixture(autouse=True)
def reset_state(monkeypatch):
    """Reset shared client and caches between tests.

    Autouse fixture that runs before and after each test to ensure
    test isolation. Resets the global client instance and disables
    read-only mode for tests.
    """
    import www_confluence_mcp.api.session as session_mod

    session_mod._CLIENT = None
    # Tests need write access enabled
    monkeypatch.setattr("www_confluence_mcp.config.READ_ONLY", False)
    yield
    session_mod._CLIENT = None


@pytest.fixture(autouse=True)
def _reset_prompts():
    """Reset external prompts state between tests."""
    from www_confluence_mcp.prompt_loader import clear_loaded_prompts

    clear_loaded_prompts()
    yield
    clear_loaded_prompts()


# ---------------------------------------------------------------------------
# Directory fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def fixtures_dir():
    """Path to the test fixtures directory.

    Returns the absolute path to tests/fixtures/ for loading test data files.
    """
    return Path(__file__).parent / "fixtures"


# ---------------------------------------------------------------------------
# Normalization helpers for round-trip fidelity tests
# ---------------------------------------------------------------------------


def normalize_confluence_artifacts(html: str) -> str:
    """Normalize Confluence editor artifacts for fair comparison.

    Strips class attributes, wrapper elements, and other editor-generated
    artifacts that don't affect semantic content.

    Args:
        html: HTML string to normalize.

    Returns:
        Normalized HTML string.
    """
    # Strip class="code-line" from headings
    html = re.sub(r'\s+class="code-line"', "", html)

    # Strip <strong> wrappers around Confluence macros
    html = re.sub(r"<strong>\s*(<ac:structured-macro[^>]*/?>)\s*</strong>", r"\1", html)

    # Strip <h2> wrappers around standalone macros (macro replaces the heading)
    html = re.sub(r"<h2[^>]*>\s*(<ac:structured-macro[^>]*/?>)\s*</h2>", r"\1", html)

    # Strip <p> wrappers around Confluence elements (macros, links, etc.)
    # Match <p> containing only a single Confluence element
    html = re.sub(r"<p>\s*(<ac:[^>]+/>\s*)</p>", r"\1", html)
    html = re.sub(
        r"<p>\s*(<ac:[^>]+>.*?</ac:[^>]+>\s*)</p>", r"\1", html, flags=re.DOTALL
    )

    # Strip CDATA wrappers (functionally equivalent to plain text)
    html = re.sub(r"<!\[CDATA\[", "", html)
    html = re.sub(r"\]\]>", "", html)

    # Normalize non-breaking spaces
    html = html.replace("\xa0", " ")
    html = html.replace("&nbsp;", " ")

    # Normalize self-closing tag spacing
    html = re.sub(r"\s*/>", "/>", html)

    # Strip empty paragraphs
    html = re.sub(r"<p>\s*</p>", "", html)
    html = re.sub(r"<p>\s*<br\s*/>\s*</p>", "", html)

    return html


def strip_namespace_declarations(html: str) -> str:
    """Strip xmlns:ac and xmlns:ri declarations and attributes for comparison.

    Args:
        html: HTML string to process.

    Returns:
        HTML string without namespace declarations.
    """
    # Strip xmlns declarations from root element
    html = re.sub(r'\s+xmlns:ac="[^"]*"', "", html)
    html = re.sub(r'\s+xmlns:ri="[^"]*"', "", html)
    # Strip xmlns:ac and xmlns:ri attributes from individual elements
    html = re.sub(r'\s+xmlns:ac="[^"]*"', "", html)
    html = re.sub(r'\s+xmlns:ri="[^"]*"', "", html)
    return html


def strip_div_wrapper(html: str) -> str:
    """Strip outer <div> wrapper if present.

    Args:
        html: HTML string to process.

    Returns:
        HTML string without outer div wrapper.
    """
    html = re.sub(r"^<div[^>]*>", "", html)
    html = re.sub(r"</div>$", "", html)
    return html


def normalize_br_after_table(html: str) -> str:
    """Normalize <br> tags after tables (editor artifact vs converter output).

    Args:
        html: HTML string to process.

    Returns:
        HTML string with <br> tags after tables removed.
    """
    # Convert <br />\n or <br/> or <br> after </table> to nothing
    html = re.sub(r"</table>\s*<br\s*/>\s*\n?", "</table>", html)
    html = re.sub(r"</table>\s*<br>\s*\n?", "</table>", html)
    return html


def normalize_stray_headings(html: str) -> str:
    """Strip stray heading tags that wrap non-text content (converter artifacts).

    Args:
        html: HTML string to process.

    Returns:
        HTML string with stray heading wrappers removed.
    """
    # Strip <h2>...</h2> that contains only whitespace and a table (not valid heading content)
    # Handle both <h2><table and <h2>...<table patterns
    html = re.sub(r"<h2[^>]*>\s*<table", r"<table", html)
    html = re.sub(r"</table>\s*</h2>", r"</table>", html)
    # Also handle newlines: <h2>\n<table
    html = re.sub(r"<h2[^>]*>\s*\n\s*<table", r"<table", html)
    html = re.sub(r"</table>\s*\n\s*</h2>", r"</table>", html)
    return html


def normalize_trailing_hr(html: str) -> str:
    """Strip trailing <hr> tags and empty paragraphs after tables (editor formatting).

    Args:
        html: HTML string to process.

    Returns:
        HTML string with trailing <hr> and empty paragraphs removed.
    """
    # Strip <hr/> or <hr> at the end of the document
    html = re.sub(r"<hr\s*/?>\s*$", "", html)
    # Strip trailing empty paragraphs
    html = re.sub(r"<p[^>]*><br\s*/?>\s*</p>\s*$", "", html)
    html = re.sub(r"<p[^>]*>\s*</p>\s*$", "", html)
    return html


def normalize_p_strong_pattern(html: str) -> str:
    """Normalize <p><strong> pattern - strip <p> wrapper when it contains only <strong>.

    Args:
        html: HTML string to process.

    Returns:
        HTML string with <p> wrappers around <strong> removed.
    """
    # Match <p...><strong>...</strong></p> and strip the <p> wrapper
    html = re.sub(r"<p[^>]*>\s*<strong>", "<strong>", html)
    html = re.sub(r"</strong>\s*</p>", "</strong>", html)
    return html


def normalize_whitespace(html: str) -> str:
    """Normalize whitespace for comparison.

    Args:
        html: HTML string to process.

    Returns:
        Normalized HTML string with consistent whitespace.
    """
    # Convert non-breaking spaces to regular spaces
    html = html.replace("\u00a0", " ")
    html = html.replace("&nbsp;", " ")
    # Collapse whitespace between tags
    html = re.sub(r">\s+<", "><", html)
    html = re.sub(r"\s+", " ", html)
    # Normalize self-closing tag spacing: <tag ... /> → <tag .../>
    html = re.sub(r"\s+/>", "/>", html)
    # Strip trailing whitespace before closing tags: text </tag> → text</tag>
    html = re.sub(r" +</", "</", html)
    return html.strip()
