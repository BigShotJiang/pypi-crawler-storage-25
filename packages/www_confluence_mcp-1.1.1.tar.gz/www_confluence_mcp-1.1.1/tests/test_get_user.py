"""Tests for confluence_get_user tool."""

import pytest
from unittest.mock import AsyncMock, patch

from www_confluence_mcp.models import User
from www_confluence_mcp.tools.confluence_get_user import confluence_get_user


class TestConfluenceGetUser:
    """Tests for confluence_get_user tool."""

    async def test_empty_query_validation(self):
        """Empty query should raise ValueError."""
        with pytest.raises(ValueError, match="query must not be empty"):
            await confluence_get_user(query="   ")

    async def test_successful_user_search(self):
        """Successful search returns user results."""
        mock_search = AsyncMock(
            return_value=[
                User(
                    accountId="user123",
                    displayName="John Doe",
                    email="john@example.com",
                    profilePicturePath="/wiki/aa-avatar/user123",
                ),
            ]
        )
        with patch(
            "www_confluence_mcp.tools.confluence_get_user.search_user", mock_search
        ):
            result = await confluence_get_user(query="John")
        assert result["status"] == "ok"
        assert result["query"] == "John"
        assert result["result_count"] == 1
        assert len(result["results"]) == 1
        assert result["next_start"] == "25"

    async def test_no_results_found(self):
        """Search with no matching users returns no_results status."""
        mock_search = AsyncMock(return_value=[])
        with patch(
            "www_confluence_mcp.tools.confluence_get_user.search_user", mock_search
        ):
            result = await confluence_get_user(query="Nonexistent User")
        assert result["status"] == "no_results"
        assert result["query"] == "Nonexistent User"
        assert result["result_count"] == 0
        assert result["results"] == []
        assert result["next_start"] is None

    async def test_pagination(self):
        """Pagination with start parameter works correctly."""
        mock_search = AsyncMock(
            return_value=[
                User(
                    accountId="user456",
                    displayName="Jane Smith",
                    email="jane@example.com",
                    profilePicturePath="/wiki/aa-avatar/user456",
                ),
            ]
        )
        with patch(
            "www_confluence_mcp.tools.confluence_get_user.search_user", mock_search
        ):
            result = await confluence_get_user(query="Jane", limit=25, start="25")
        assert result["status"] == "ok"
        assert result["result_count"] == 1
        assert result["next_start"] == "50"
        # Verify the API was called with correct pagination params
        mock_search.assert_called_once()
        call_args = mock_search.call_args
        assert call_args[1]["limit"] == 25
