"""Tests for logging middleware in server.py."""

import asyncio
import logging
import re

import pytest

from www_confluence_mcp.utils.decorators import tool_logging_middleware


class TestToolLoggingMiddleware:
    """Tests for the tool_logging_middleware decorator."""

    @pytest.mark.asyncio
    async def test_middleware_logs_tool_call_and_completion(self, caplog):
        """Middleware should log tool call before and completion after."""
        caplog.set_level(logging.INFO)

        @tool_logging_middleware()
        async def test_tool(x: int) -> int:
            return x * 2

        result = await test_tool(5)

        assert result == 10

        # Check that we have INFO level logs
        info_records = [r for r in caplog.records if r.levelno == logging.INFO]
        assert len(info_records) >= 2, "Should have at least 2 INFO log messages"

        # First message should be "Tool call: test_tool"
        assert "Tool call:" in info_records[0].message
        assert "test_tool" in info_records[0].message

        # Last message should be "Tool completed: test_tool (... ms)"
        assert "Tool completed:" in info_records[-1].message
        assert "test_tool" in info_records[-1].message
        assert "ms" in info_records[-1].message

    @pytest.mark.asyncio
    async def test_middleware_logs_error_on_failure(self, caplog):
        """Middleware should log error when tool fails."""
        caplog.set_level(logging.ERROR)

        @tool_logging_middleware()
        async def failing_tool() -> None:
            raise ValueError("Test error")

        with pytest.raises(ValueError, match="Test error"):
            await failing_tool()

        # Check that logger.error was called
        error_records = [r for r in caplog.records if r.levelno == logging.ERROR]
        assert len(error_records) >= 1, "Should have at least 1 ERROR log message"

        error_msg = error_records[0].message
        assert "Tool failed:" in error_msg
        assert "failing_tool" in error_msg
        assert "ValueError" in error_msg
        assert "Test error" in error_msg

    @pytest.mark.asyncio
    async def test_middleware_with_custom_tool_name(self, caplog):
        """Middleware should use custom tool name if provided."""
        caplog.set_level(logging.INFO)

        @tool_logging_middleware("custom_search_tool")
        async def search(query: str) -> str:
            return f"Results for: {query}"

        result = await search("test query")

        assert result == "Results for: test query"

        # Check that custom name is used in logs
        found_custom_name = False
        for record in caplog.records:
            if "custom_search_tool" in record.message:
                found_custom_name = True
                break

        assert found_custom_name, "Custom tool name should appear in logs"

    @pytest.mark.asyncio
    async def test_middleware_measures_duration(self, caplog):
        """Middleware should measure and log execution duration."""
        caplog.set_level(logging.INFO)

        @tool_logging_middleware()
        async def slow_tool() -> None:
            await asyncio.sleep(0.05)  # 50ms delay

        await slow_tool()

        # Check that duration was logged (should be at least 50ms)
        for record in caplog.records:
            msg = record.message
            if "Tool completed:" in msg and "slow_tool" in msg:
                # Extract duration from log message
                # Format: "Tool completed: slow_tool (XX.XX ms)"
                match = re.search(r"\((\d+\.?\d*)\s*ms\)", msg)
                assert match, f"Duration should be in log message: {msg}"
                duration_ms = float(match.group(1))
                assert duration_ms >= 45, (
                    f"Duration should be at least 45ms, got {duration_ms}ms"
                )
                break
        else:
            pytest.fail("Tool completed log not found")

    @pytest.mark.asyncio
    async def test_middleware_preserves_function_metadata(self):
        """Middleware should preserve wrapped function metadata."""

        @tool_logging_middleware()
        async def documented_tool(x: int) -> int:
            """This is a documented tool."""
            return x

        # Check that metadata is preserved by functools.wraps
        assert documented_tool.__name__ == "documented_tool"
        assert documented_tool.__doc__ == "This is a documented tool."

    @pytest.mark.asyncio
    async def test_middleware_with_no_tool_name_uses_function_name(self, caplog):
        """When tool_name is None, should use function name."""
        caplog.set_level(logging.INFO)

        @tool_logging_middleware(tool_name=None)
        async def auto_named_tool() -> str:
            return "auto"

        await auto_named_tool()

        # Check that function name is used
        found_func_name = False
        for record in caplog.records:
            if "auto_named_tool" in record.message:
                found_func_name = True
                break

        assert found_func_name, "Function name should be used when tool_name is None"


class TestMiddlewareIntegration:
    """Integration tests for middleware with actual logging."""

    @pytest.mark.asyncio
    async def test_middleware_with_real_logging(self, caplog):
        """Test middleware with actual logging capture."""
        caplog.set_level(logging.INFO)

        @tool_logging_middleware()
        async def integration_tool() -> str:
            return "done"

        result = await integration_tool()

        assert result == "done"

        # Check log records
        info_messages = [
            record.message
            for record in caplog.records
            if record.levelno == logging.INFO
        ]

        assert len(info_messages) >= 2, "Should have at least 2 INFO log messages"

        # First message should be tool call
        assert any("Tool call:" in msg for msg in info_messages)

        # Last message should be tool completion
        assert any("Tool completed:" in msg for msg in info_messages)

    @pytest.mark.asyncio
    async def test_middleware_error_with_real_logging(self, caplog):
        """Test middleware error logging with actual logging capture."""
        caplog.set_level(logging.ERROR)

        @tool_logging_middleware()
        async def error_tool() -> None:
            raise RuntimeError("Integration test error")

        with pytest.raises(RuntimeError):
            await error_tool()

        # Check log records
        error_messages = [
            record.message
            for record in caplog.records
            if record.levelno == logging.ERROR
        ]

        assert len(error_messages) >= 1, "Should have at least 1 ERROR log message"
        assert any("Tool failed:" in msg for msg in error_messages)
        assert any("error_tool" in msg for msg in error_messages)
