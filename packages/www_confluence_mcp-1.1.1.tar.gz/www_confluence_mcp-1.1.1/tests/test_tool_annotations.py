"""Verify all tools have proper metadata in info.py."""

from www_confluence_mcp.info import _TOOL_META, tool_meta, TOOL_CATALOG


class TestToolMetadata:
    def test_all_registered_tools_have_meta(self):
        """Every tool in TOOL_CATALOG should have an entry in _TOOL_META."""
        for tool in TOOL_CATALOG:
            name = tool["name"]
            assert name in _TOOL_META, f"Missing metadata for {name}"

    def test_all_meta_entries_have_tags(self):
        """Every _TOOL_META entry should have a non-empty tags set."""
        for name, meta in _TOOL_META.items():
            assert "tags" in meta, f"{name} missing tags"
            assert len(meta["tags"]) > 0, f"{name} has empty tags"

    def test_read_only_tools_have_readonly_hint(self):
        """Tools tagged read-only should have readOnlyHint=True."""
        for name, meta in _TOOL_META.items():
            if "read-only" in meta["tags"]:
                assert meta.get("read_only") is True, (
                    f"{name} tagged read-only but read_only!=True"
                )

    def test_write_tools_have_destructive_hint(self):
        """Tools tagged write and destructive should have destructiveHint=True."""
        destructive = {
            "confluence_new_page",
            "confluence_update_page",
            "confluence_delete_pages",
            "confluence_move_page",
            "confluence_delete_attachments",
            "confluence_delete_labels",
            "confluence_add_comment",
            "confluence_add_labels",
            "confluence_upload_attachments",
        }
        for name in destructive:
            meta = _TOOL_META[name]
            assert meta.get("destructive") is True, (
                f"{name} should have destructive=True"
            )

    def test_search_tools_have_search_tag(self):
        """Search tools should have 'search' tag."""
        meta = _TOOL_META["confluence_search_cql"]
        assert "search" in meta["tags"]

    def test_page_tools_have_page_crud_tag(self):
        """Page CRUD tools should have 'page-crud' tag."""
        page_tools = {
            "confluence_get_page",
            "confluence_new_page",
            "confluence_update_page",
            "confluence_delete_pages",
            "confluence_move_page",
        }
        for name in page_tools:
            meta = _TOOL_META[name]
            assert "page-crud" in meta["tags"], f"{name} missing page-crud tag"

    def test_attachment_tools_have_attachments_tag(self):
        """Attachment tools should have 'attachments' tag."""
        att_tools = {
            "confluence_get_page_attachments",
            "confluence_upload_attachments",
            "confluence_download_attachments",
            "confluence_delete_attachments",
        }
        for name in att_tools:
            meta = _TOOL_META[name]
            assert "attachments" in meta["tags"], f"{name} missing attachments tag"

    def test_markdown_tools_have_markdown_tag(self):
        """Markdown converter tools should have 'markdown' tag."""
        markdown_tools = {
            "confluence_validate_page",
        }
        for name in markdown_tools:
            meta = _TOOL_META[name]
            assert "markdown" in meta["tags"], f"{name} missing markdown tag"

    def test_tool_meta_returns_tuple(self):
        """tool_meta() should return (icons, annotations, meta) tuple."""
        result = tool_meta("confluence_search_cql")
        assert isinstance(result, tuple)
        assert len(result) == 3

    def test_tools_json_exists(self):
        """tools.json should exist and be valid JSON."""
        import json
        from pathlib import Path

        path = (
            Path(__file__).parent.parent
            / "src"
            / "www_confluence_mcp"
            / "data"
            / "tools.json"
        )
        assert path.exists(), "tools.json not found"
        data = json.loads(path.read_text())
        assert isinstance(data, dict)
        assert len(data) > 0
