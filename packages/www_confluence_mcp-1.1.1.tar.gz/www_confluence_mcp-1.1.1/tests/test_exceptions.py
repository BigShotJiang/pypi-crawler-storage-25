"""Tests for custom Confluence API exception hierarchy."""

from www_confluence_mcp.exceptions import (
    ConfluenceError,
    ConfluenceNotFoundError,
    ConfluencePermissionError,
    ConfluenceConflictError,
    ConfluenceRateLimitError,
    ConfluenceTimeoutError,
    ConfluenceAPIError,
    ConverterError,
    ParseError,
    MacroPreservationError,
    RoundTripError,
)
from www_confluence_mcp.tools._error import make_error_response


class TestConfluenceError:
    def test_base_error_message(self):
        """Base error stores message, status_code, url."""
        err = ConfluenceError("test error", status_code=400, url="https://example.com")
        assert str(err) == "test error"
        assert err.status_code == 400
        assert err.url == "https://example.com"
        assert err.retryable is False

    def test_not_found_error(self):
        """404 error with retryable=False."""
        err = ConfluenceNotFoundError(
            "not found", url="https://example.com/api/page/123"
        )
        assert err.status_code == 404
        assert err.retryable is False
        assert "not found" in str(err).lower()

    def test_permission_error(self):
        """403 error with retryable=False."""
        err = ConfluencePermissionError("forbidden")
        assert err.status_code == 403
        assert err.retryable is False

    def test_conflict_error(self):
        """409 error with retryable=False."""
        err = ConfluenceConflictError("version conflict")
        assert err.status_code == 409
        assert err.retryable is False

    def test_rate_limit_error(self):
        """429 error with retryable=True, retry_after parsed."""
        err = ConfluenceRateLimitError("rate limited", retry_after=5.0)
        assert err.status_code == 429
        assert err.retryable is True
        assert err.retry_after == 5.0

    def test_timeout_error(self):
        """Timeout error with retryable=True."""
        err = ConfluenceTimeoutError("request timed out")
        assert err.retryable is True

    def test_api_error_5xx(self):
        """5xx error with retryable=True."""
        err = ConfluenceAPIError("server error", status_code=503)
        assert err.status_code == 503
        assert err.retryable is True

    def test_api_error_500(self):
        """500 error with retryable=True."""
        err = ConfluenceAPIError("internal error", status_code=500)
        assert err.retryable is True

    def test_retry_after_integer(self):
        """Retry-After header with integer seconds."""
        err = ConfluenceRateLimitError("rate limited", retry_after=10)
        assert err.retry_after == 10.0

    def test_retry_after_none(self):
        """Rate limit error without retry_after."""
        err = ConfluenceRateLimitError("rate limited")
        assert err.retry_after is None

    def test_base_error_suggested_action_default_empty(self):
        """Base error has empty suggested_action by default."""
        err = ConfluenceError("test")
        assert err.suggested_action == ""

    def test_base_error_suggested_action(self):
        """Base error stores suggested_action."""
        err = ConfluenceError("test", suggested_action="Retry later")
        assert err.suggested_action == "Retry later"


class TestConverterExceptions:
    def test_converter_error_with_suggested_action(self):
        """ConverterError stores suggested_action."""
        err = ConverterError("fail", suggested_action="Check input")
        assert err.suggested_action == "Check input"
        assert err.retryable is False

    def test_converter_error_inherits_confluence_error(self):
        """ConverterError is a ConfluenceError."""
        err = ConverterError("test")
        assert isinstance(err, ConfluenceError)

    def test_parse_error_with_element(self):
        """ParseError stores element."""
        err = ParseError("bad HTML", element="<div>")
        assert err.element == "<div>"
        assert err.retryable is False

    def test_macro_preservation_error_with_macro_name(self):
        """MacroPreservationError stores macro_name."""
        err = MacroPreservationError("lost macro", macro_name="info")
        assert err.macro_name == "info"

    def test_roundtrip_error_with_element_type(self):
        """RoundTripError stores element_type."""
        err = RoundTripError("mismatch", element_type="task-list")
        assert err.element_type == "task-list"


class TestMakeErrorResponse:
    """Tests for make_error_response function with enhanced error fields."""

    def test_not_found_error_with_alternative_action(self):
        """ConfluenceNotFoundError includes alternative_action and documentation_url."""
        err = ConfluenceNotFoundError("Page not found")
        response = make_error_response(err, "confluence_get_page", "123")

        assert response["status"] == "error"
        assert response["error_code"] == "NOT_FOUND"
        assert "Verify page_id exists" in response["suggested_action"]
        assert (
            response["alternative_action"]
            == "Use confluence_get_page with title + space_key instead."
        )
        assert "developer.atlassian.com" in response["documentation_url"]
        assert response["page_id"] == "123"

    def test_permission_error_with_configuration_hint(self):
        """ConfluencePermissionError includes configuration_hint and documentation_url."""
        err = ConfluencePermissionError("Access denied")
        response = make_error_response(err, "confluence_get_page")

        assert response["error_code"] == "PERMISSION_DENIED"
        assert "CONFLUENCE_PERSONAL_TOKEN" in response["suggested_action"]
        assert "Verify CONFLUENCE_URL" in response["configuration_hint"]
        assert "confluence.atlassian.com" in response["documentation_url"]

    def test_conflict_error_with_alternative_action(self):
        """ConfluenceConflictError includes alternative_action."""
        err = ConfluenceConflictError("Version conflict")
        response = make_error_response(err, "confluence_update_page")

        assert response["error_code"] == "VERSION_CONFLICT"
        assert "Fetch latest version" in response["suggested_action"]
        assert (
            response["alternative_action"]
            == "Use confluence_get_page to get current version before updating."
        )

    def test_rate_limit_error_with_configuration_hint(self):
        """ConfluenceRateLimitError includes configuration_hint."""
        err = ConfluenceRateLimitError("Rate limited", retry_after=30)
        response = make_error_response(err, "confluence_search_cql")

        assert response["error_code"] == "RATE_LIMITED"
        assert response["retryable"] is True
        assert "Retry after 30s" in response["suggested_action"]
        assert "request throttling" in response["configuration_hint"]

    def test_timeout_error_with_configuration_hint(self):
        """ConfluenceTimeoutError includes configuration_hint."""
        err = ConfluenceTimeoutError("Request timed out")
        response = make_error_response(err, "confluence_get_page")

        assert response["error_code"] == "TIMEOUT"
        assert response["retryable"] is True
        assert "smaller payload" in response["suggested_action"]
        assert "CONFLUENCE_TIMEOUT" in response["configuration_hint"]

    def test_api_5xx_error_with_configuration_hint(self):
        """ConfluenceAPIError with 5xx includes configuration_hint."""
        err = ConfluenceAPIError("Server error", status_code=503)
        response = make_error_response(err, "confluence_search_cql")

        assert response["error_code"] == "API_ERROR_503"
        assert response["retryable"] is True
        assert "server error" in response["configuration_hint"]

    def test_api_4xx_error_without_configuration_hint(self):
        """ConfluenceAPIError with 4xx does not include configuration_hint."""
        err = ConfluenceAPIError("Bad request", status_code=400)
        response = make_error_response(err, "confluence_create_page")

        assert response["error_code"] == "API_ERROR_400"
        assert "configuration_hint" not in response

    def test_error_response_minimal_fields(self):
        """Error response always includes status, error, error_code."""
        err = ConfluenceError("Generic error")
        response = make_error_response(err, "test_tool")

        assert "status" in response
        assert "error" in response
        assert "error_code" in response
        assert response["status"] == "error"

    def test_error_response_optional_fields(self):
        """Optional fields only included when applicable."""
        err = ConfluenceError("Generic error")
        response = make_error_response(err)

        assert "suggested_action" not in response
        assert "configuration_hint" not in response
        assert "alternative_action" not in response
        assert "documentation_url" not in response
        assert "retryable" not in response
        assert "page_id" not in response

    def test_parse_error_with_element(self):
        """ParseError includes element in suggested_action."""
        err = ParseError("Invalid HTML", element="<table>")
        response = make_error_response(err, "converter")

        assert response["error_code"] == "PARSE_ERROR"
        assert response["suggested_action"] == "Check element: <table>"

    def test_macro_error_with_macro_name(self):
        """MacroPreservationError includes macro_name in suggested_action."""
        err = MacroPreservationError("Macro failed", macro_name="info")
        response = make_error_response(err, "converter")

        assert response["error_code"] == "MACRO_ERROR"
        assert response["suggested_action"] == "Macro: info"

    def test_converter_error_with_suggested_action(self):
        """ConverterError includes suggested_action from exception."""
        err = ConverterError("Conversion failed", suggested_action="Check input format")
        response = make_error_response(err, "converter")

        assert response["error_code"] == "CONVERTER_ERROR"
        assert response["suggested_action"] == "Check input format"
