"""Tests for RoundTripValidator."""

from www_confluence_mcp.utils.roundtrip_validator import (
    RoundTripValidator,
    roundtrip_validator,
)


class TestRoundTripValidator:
    """Test suite for RoundTripValidator."""

    def test_validate_identical_html_no_warnings(self):
        """No warnings when original and restored HTML are identical."""
        validator = RoundTripValidator()
        html = """
        <ac:structured-macro ac:macro-id="abc123">
            <ac:task-list>
                <ac:task-id>1</ac:task-id>
            </ac:task-list>
        </ac:structured-macro>
        """
        warnings = validator.validate(html, html)
        assert len(warnings) == 0

    def test_validate_missing_macro_element(self):
        """Warning when a structured-macro element is missing."""
        validator = RoundTripValidator()
        original = '<ac:structured-macro ac:macro-id="abc123"></ac:structured-macro>'
        restored = ""
        warnings = validator.validate(original, restored)
        assert len(warnings) >= 1
        assert "Element count mismatch for ac:structured-macro" in warnings[0]
        assert "original=1" in warnings[0]
        assert "restored=0" in warnings[0]

    def test_validate_missing_macro_id(self):
        """Warning when macro-id is missing in restored HTML."""
        validator = RoundTripValidator()
        original = '<ac:structured-macro ac:macro-id="abc123"></ac:structured-macro>'
        restored = '<ac:structured-macro ac:macro-id="xyz789"></ac:structured-macro>'
        warnings = validator.validate(original, restored)
        assert len(warnings) == 1
        assert "Missing macro IDs after restore" in warnings[0]
        assert "abc123" in warnings[0]

    def test_validate_missing_task_id(self):
        """Warning when task-id is missing in restored HTML."""
        validator = RoundTripValidator()
        original = "<ac:task-id>42</ac:task-id>"
        restored = "<ac:task-id>99</ac:task-id>"
        warnings = validator.validate(original, restored)
        assert len(warnings) == 1
        assert "Missing task IDs after restore" in warnings[0]
        assert "42" in warnings[0]

    def test_validate_multiple_issues(self):
        """Multiple warnings when multiple issues exist."""
        validator = RoundTripValidator()
        original = """
        <ac:structured-macro ac:macro-id="macro1">
            <ac:task-id>1</ac:task-id>
        </ac:structured-macro>
        <ri:user ri:account-id="user123" />
        """
        restored = """
        <ac:structured-macro ac:macro-id="macro2">
            <ac:task-id>2</ac:task-id>
        </ac:structured-macro>
        """
        warnings = validator.validate(original, restored)
        assert len(warnings) >= 2
        warning_text = " ".join(warnings)
        assert "macro1" in warning_text or "Missing macro IDs" in warning_text
        assert "Missing task IDs" in warning_text or "1" in warning_text

    def test_validate_all_critical_elements_present(self):
        """All critical elements are properly detected."""
        validator = RoundTripValidator()
        original = """
        <ac:structured-macro ac:macro-id="m1"></ac:structured-macro>
        <ac:task-list><ac:task-id>1</ac:task-id></ac:task-list>
        <ri:user ri:account-id="u1" />
        <ri:page ri:content-id="p1" />
        <ri:attachment ri:filename="a1" />
        <ac:image ac:alt="test"></ac:image>
        """
        restored = original
        warnings = validator.validate(original, restored)
        assert len(warnings) == 0

    def test_validate_empty_strings(self):
        """Empty strings produce no warnings."""
        validator = RoundTripValidator()
        warnings = validator.validate("", "")
        assert len(warnings) == 0

    def test_validate_nested_macros(self):
        """Nested macros are correctly counted."""
        validator = RoundTripValidator()
        original = """
        <ac:structured-macro ac:macro-id="outer">
            <ac:structured-macro ac:macro-id="inner">
                <ac:task-id>5</ac:task-id>
            </ac:structured-macro>
        </ac:structured-macro>
        """
        restored = original
        warnings = validator.validate(original, restored)
        assert len(warnings) == 0
        # Verify count detection works for nested elements
        assert original.count("<ac:structured-macro") == 2

    def test_global_instance_exists(self):
        """Global roundtrip_validator instance exists."""
        assert roundtrip_validator is not None
        assert isinstance(roundtrip_validator, RoundTripValidator)
