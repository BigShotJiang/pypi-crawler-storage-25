---
confluence:
  pageId: "1002"
  space: TEST
  title: "Macros Page"
  version: 1
  last_updated: "2026-05-12T10:00:00"
  url: "https://confluence.example.com/pages/viewpage.action?pageId=1002"
format: confluence_hybrid_markdown
conversion_timestamp: "2026-05-12T10:00:00"
---

<!-- CONFLUENCE_MACRO: ac:name="info" ac:schema-version="1" ac:parameter:title="Status" -->
> **Status:**
> Active
<!-- /CONFLUENCE_MACRO -->

<!-- CONFLUENCE_MACRO: ac:name="code" ac:schema-version="1" ac:parameter:language="python" -->
```python
print("hello")
```
<!-- /CONFLUENCE_MACRO -->

<!-- CONFLUENCE_MACRO: ac:name="toc" ac:schema-version="1" -->
[TOC]
<!-- /CONFLUENCE_MACRO -->

<!-- CONFLUENCE_MACRO: ac:name="warning" ac:schema-version="1" -->
> ⚠️ **Warning:**
> Be careful
<!-- /CONFLUENCE_MACRO -->
