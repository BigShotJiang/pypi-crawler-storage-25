---
confluence:
  pageId: "1001"
  space: TEST
  title: "Simple Page"
  version: 1
  last_updated: "2026-05-12T10:00:00"
  url: "https://confluence.example.com/pages/viewpage.action?pageId=1001"
format: confluence_hybrid_markdown
conversion_timestamp: "2026-05-12T10:00:00"
---

# Simple Page

Paragraph with **bold** and *italic*.

- Item 1
- Item 2

[Example](https://example.com)
