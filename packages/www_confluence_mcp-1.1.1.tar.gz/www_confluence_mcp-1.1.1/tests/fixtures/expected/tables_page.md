---
confluence:
  pageId: "1003"
  space: TEST
  title: "Tables Page"
  version: 1
  last_updated: "2026-05-12T10:00:00"
  url: "https://confluence.example.com/pages/viewpage.action?pageId=1003"
format: confluence_hybrid_markdown
conversion_timestamp: "2026-05-12T10:00:00"
---

<!-- CONFLUENCE_TABLE: class="wrapped" style="width: 100%" colgroup="width: 50%;width: 50%" -->
| Header 1 | Header 2 |
|---|---|
| Cell 1 | Cell 2 |
<!-- /CONFLUENCE_TABLE -->
