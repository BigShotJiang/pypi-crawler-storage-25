"""Performance tests for markdown converter."""

import asyncio
import time

import pytest
import tracemalloc

from www_confluence_mcp.utils.converter import (
    markdown_to_storage,
    storage_to_markdown,
)


def _generate_macros_page(count: int) -> str:
    """Generate HTML with N macros."""
    macros = []
    for i in range(count):
        macros.append(
            f'<ac:structured-macro ac:name="info" ac:schema-version="1">'
            f'<ac:parameter ac:name="title">Info {i}</ac:parameter>'
            f"<ac:rich-text-body><p>Content {i}</p></ac:rich-text-body>"
            f"</ac:structured-macro>"
        )
    return "\n".join(macros)


def _generate_table_page(rows: int, cols: int = 5) -> str:
    """Generate HTML table with N rows and M columns."""
    header = "".join(f"<th>Header {c}</th>" for c in range(cols))
    body_rows = []
    for r in range(rows):
        cells = "".join(f"<td>Cell {r}-{c}</td>" for c in range(cols))
        body_rows.append(f"<tr>{cells}</tr>")
    return (
        f'<table class="wrapped">'
        f"<thead><tr>{header}</tr></thead>"
        f"<tbody>{''.join(body_rows)}</tbody>"
        f"</table>"
    )


def _generate_mixed_page(element_count: int) -> str:
    """Generate HTML with mixed elements."""
    parts = []
    for i in range(element_count):
        if i % 4 == 0:
            parts.append(
                f'<ac:structured-macro ac:name="info" ac:schema-version="1">'
                f"<ac:rich-text-body><p>Info {i}</p></ac:rich-text-body>"
                f"</ac:structured-macro>"
            )
        elif i % 4 == 1:
            parts.append(f"<p>Paragraph <strong>bold {i}</strong> text</p>")
        elif i % 4 == 2:
            parts.append(f"<h2>Heading {i}</h2>")
        else:
            parts.append(
                f'<ac:link><ri:user ri:userkey="user{i}" '
                f'ri:username="user{i}" /></ac:link>'
            )
    return "\n".join(parts)


class TestPerformance:
    def test_100_macros_performance(self, page_data):
        """Page with 100 macros converts in < 5 seconds."""
        html = _generate_macros_page(100)
        start = time.monotonic()
        storage_to_markdown(html, page_data)
        elapsed = time.monotonic() - start
        assert elapsed < 5.0, f"100 macros took {elapsed:.2f}s (limit: 5s)"

    def test_50_table_rows_performance(self, page_data):
        """Page with 50 table rows converts in < 2 seconds."""
        html = _generate_table_page(50)
        start = time.monotonic()
        storage_to_markdown(html, page_data)
        elapsed = time.monotonic() - start
        assert elapsed < 2.0, f"50 table rows took {elapsed:.2f}s (limit: 2s)"

    def test_1000_elements_performance(self, page_data):
        """Page with 1000 mixed elements converts in < 10 seconds."""
        html = _generate_mixed_page(1000)
        start = time.monotonic()
        storage_to_markdown(html, page_data)
        elapsed = time.monotonic() - start
        assert elapsed < 10.0, f"1000 elements took {elapsed:.2f}s (limit: 10s)"

    def test_round_trip_100_macros(self, page_data):
        """Round-trip with 100 macros completes in < 10 seconds."""
        html = _generate_macros_page(100)
        start = time.monotonic()
        md_content = storage_to_markdown(html, page_data)
        markdown_to_storage(md_content)
        elapsed = time.monotonic() - start
        assert elapsed < 10.0, f"Round-trip 100 macros took {elapsed:.2f}s (limit: 10s)"

    def test_memory_1000_elements(self, page_data):
        """Memory usage for 1000 elements stays under 50MB."""
        html = _generate_mixed_page(1000)

        tracemalloc.start()
        md_content = storage_to_markdown(html, page_data)
        markdown_to_storage(md_content)
        current, peak = tracemalloc.get_traced_memory()
        tracemalloc.stop()

        peak_mb = peak / (1024 * 1024)
        assert peak_mb < 50, f"Peak memory: {peak_mb:.1f}MB (limit: 50MB)"

    @pytest.mark.asyncio
    async def test_concurrent_conversions(self, page_data):
        """Concurrent conversions don't interfere."""
        html = _generate_macros_page(10)

        async def convert():
            return storage_to_markdown(html, page_data)

        results = await asyncio.gather(*[convert() for _ in range(10)])
        # All results should be identical
        assert all(r == results[0] for r in results)
