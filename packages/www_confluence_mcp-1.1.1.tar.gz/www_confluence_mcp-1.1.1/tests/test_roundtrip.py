"""Tests for round-trip validation."""

from www_confluence_mcp.utils.converter import (
    storage_to_markdown,
    markdown_to_storage,
    validate_roundtrip,
)


class TestRoundtripValidation:
    def test_valid_round_trip(self, page_data):
        """Valid round-trip: CSF → MD → CSF preserves elements."""
        html = (
            '<ac:structured-macro ac:name="info" ac:schema-version="1">'
            '<ac:parameter ac:name="title">Status</ac:parameter>'
            "<ac:rich-text-body><p>Active</p></ac:rich-text-body>"
            "</ac:structured-macro>"
        )
        md_content = storage_to_markdown(html, page_data)
        restored = markdown_to_storage(md_content)
        is_valid, errors = validate_roundtrip(html, restored)
        assert is_valid is True or len(errors) == 0  # May have minor differences

    def test_element_count_comparison(self, page_data):
        """Compares element counts before/after."""
        html = (
            '<ac:structured-macro ac:name="info" ac:schema-version="1">'
            "<ac:rich-text-body><p>Text</p></ac:rich-text-body>"
            "</ac:structured-macro>"
        )
        md_content = storage_to_markdown(html, page_data)
        restored = markdown_to_storage(md_content)
        is_valid, errors = validate_roundtrip(html, restored)
        # Macro count should match
        assert isinstance(is_valid, bool)
        assert isinstance(errors, list)

    def test_missing_macro_error(self):
        """Missing macro detected."""
        original = '<ac:structured-macro ac:name="info">...</ac:structured-macro>'
        restored = "<p>Just text</p>"
        is_valid, errors = validate_roundtrip(original, restored)
        assert is_valid is False
        assert len(errors) > 0

    def test_returns_tuple_bool_list(self):
        """Returns (is_valid: bool, errors: list[str])."""
        is_valid, errors = validate_roundtrip("<p>same</p>", "<p>same</p>")
        assert isinstance(is_valid, bool)
        assert isinstance(errors, list)

    def test_user_count_preserved(self, page_data):
        """User count preserved in round-trip."""
        html = (
            '<ac:link><ri:user ri:userkey="abc" ri:username="jdoe" /></ac:link>'
            '<ac:link><ri:user ri:userkey="def" ri:username="jane" /></ac:link>'
        )
        md_content = storage_to_markdown(html, page_data)
        restored = markdown_to_storage(md_content)
        is_valid, errors = validate_roundtrip(html, restored)
        # Should preserve user count
        assert isinstance(is_valid, bool)
