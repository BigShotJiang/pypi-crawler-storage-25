"""Tests for converter metrics module."""

from __future__ import annotations

import time

import pytest

from www_confluence_mcp.utils.converter_metrics import (
    ConversionMetrics,
    conversion_metrics,
)


class TestConversionMetrics:
    """Test ConversionMetrics class."""

    def test_track_success_increments_conversions(self) -> None:
        """Test that successful conversion increments total_conversions."""
        metrics = ConversionMetrics()
        assert metrics.total_conversions == 0

        with metrics.track(page_id="123", direction="download"):
            pass

        assert metrics.total_conversions == 1

    def test_track_exception_records_error(self) -> None:
        """Test that exceptions are recorded in errors list."""
        metrics = ConversionMetrics()
        assert len(metrics.errors) == 0

        with pytest.raises(ValueError, match="test error"):
            with metrics.track(page_id="456", direction="upload"):
                raise ValueError("test error")

        assert len(metrics.errors) == 1
        assert "upload:456:test error" in metrics.errors

    def test_track_measures_latency(self) -> None:
        """Test that track context manager measures latency."""
        metrics = ConversionMetrics()
        assert len(metrics.latencies) == 0

        with metrics.track(page_id="789", direction="download"):
            time.sleep(0.01)  # Sleep 10ms to ensure measurable latency

        assert len(metrics.latencies) == 1
        assert metrics.latencies[0] >= 0.01

    def test_summary_empty(self) -> None:
        """Test summary with no data."""
        metrics = ConversionMetrics()
        summary = metrics.summary()

        assert summary == {
            "total_conversions": 0,
            "avg_latency_ms": 0,
            "total_errors": 0,
            "elements_preserved": 0,
            "elements_converted": 0,
        }

    def test_summary_with_data(self) -> None:
        """Test summary with collected data."""
        metrics = ConversionMetrics()
        metrics.total_conversions = 3
        metrics.total_elements_preserved = 10
        metrics.total_elements_converted = 8
        metrics.latencies = [0.1, 0.2, 0.3]  # 100ms, 200ms, 300ms
        metrics.errors = ["error1", "error2"]

        summary = metrics.summary()

        assert summary["total_conversions"] == 3
        assert summary["avg_latency_ms"] == pytest.approx(200.0)
        assert summary["total_errors"] == 2
        assert summary["elements_preserved"] == 10
        assert summary["elements_converted"] == 8

    def test_reset(self) -> None:
        """Test that reset clears all metrics."""
        metrics = ConversionMetrics()
        metrics.total_conversions = 5
        metrics.total_elements_preserved = 20
        metrics.total_elements_converted = 15
        metrics.latencies.append(0.5)
        metrics.errors.append("some error")

        metrics.reset()

        assert metrics.total_conversions == 0
        assert metrics.total_elements_preserved == 0
        assert metrics.total_elements_converted == 0
        assert len(metrics.latencies) == 0
        assert len(metrics.errors) == 0

    def test_global_instance_exists(self) -> None:
        """Test that global conversion_metrics instance exists."""
        assert conversion_metrics is not None
        assert isinstance(conversion_metrics, ConversionMetrics)

    def test_multiple_tracks_accumulate(self) -> None:
        """Test that multiple track calls accumulate metrics."""
        metrics = ConversionMetrics()

        with metrics.track(page_id="1", direction="download"):
            pass

        with metrics.track(page_id="2", direction="upload"):
            pass

        with metrics.track(page_id="3", direction="download"):
            pass

        assert metrics.total_conversions == 3
        assert len(metrics.latencies) == 3
        assert len(metrics.errors) == 0

    def test_latencies_bounded_to_maxlen(self) -> None:
        """Test that latencies deque is bounded to prevent memory leaks."""
        from collections import deque

        metrics = ConversionMetrics()

        # Verify latencies is a deque
        assert isinstance(metrics.latencies, deque)

        # Verify maxlen is set (should be 1000)
        assert metrics.latencies.maxlen == 1000

        # Add more than maxlen items
        for i in range(1500):
            metrics.latencies.append(float(i))

        # Should only keep the last 1000 items
        assert len(metrics.latencies) == 1000
        # First item should be 500.0 (items 0-499 were evicted)
        assert metrics.latencies[0] == 500.0
        # Last item should be 1499.0
        assert metrics.latencies[-1] == 1499.0

    def test_summary_with_bounded_latencies(self) -> None:
        """Test that summary works correctly with bounded deque."""
        metrics = ConversionMetrics()

        # Add many latencies
        for i in range(1500):
            metrics.latencies.append(0.1)
            metrics.total_conversions += 1

        # Summary should still work
        summary = metrics.summary()
        assert summary["total_conversions"] == 1500
        assert summary["avg_latency_ms"] == pytest.approx(100.0, rel=1e-9)  # 0.1 seconds = 100ms
        assert len(metrics.latencies) == 1000  # Bounded
