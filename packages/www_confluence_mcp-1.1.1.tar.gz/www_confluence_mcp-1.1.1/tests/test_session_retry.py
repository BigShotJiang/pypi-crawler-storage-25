"""Tests for _request_with_retry() function in session.py."""

import asyncio
import time
from unittest.mock import patch

import pytest
from www_confluence_mcp.api.session import _request_with_retry
from www_confluence_mcp.exceptions import (
    ConfluenceAPIError,
    ConfluenceNotFoundError,
    ConfluenceRateLimitError,
)


class TestRequestWithRetryDefaults:
    """Test _request_with_retry with default configuration."""

    @pytest.mark.asyncio
    async def test_success_no_retry(self):
        """Returns immediately on success without retrying."""
        call_count = 0

        async def mock_request(method, url, **kwargs):
            nonlocal call_count
            call_count += 1
            return {"status": "success"}

        with patch("www_confluence_mcp.api.session.request", mock_request):
            result = await _request_with_retry("GET", "/test")

        assert result == {"status": "success"}
        assert call_count == 1

    @pytest.mark.asyncio
    async def test_retry_on_429_rate_limit(self):
        """Retries on 429 status code (rate limit)."""
        call_count = 0

        async def mock_request(method, url, **kwargs):
            nonlocal call_count
            call_count += 1
            if call_count < 3:
                raise ConfluenceRateLimitError("rate limited", retry_after=0.01)
            return {"status": "success"}

        with patch("www_confluence_mcp.api.session.request", mock_request):
            result = await _request_with_retry(
                "GET",
                "/test",
                max_retries=3,
                base_delay=0.01,
                max_delay=0.1,
            )

        assert result == {"status": "success"}
        assert call_count == 3

    @pytest.mark.asyncio
    async def test_retry_on_500_server_error(self):
        """Retries on 500 status code (server error)."""
        call_count = 0

        async def mock_request(method, url, **kwargs):
            nonlocal call_count
            call_count += 1
            if call_count < 2:
                raise ConfluenceAPIError("server error", status_code=500)
            return {"status": "success"}

        with patch("www_confluence_mcp.api.session.request", mock_request):
            result = await _request_with_retry(
                "GET",
                "/test",
                max_retries=3,
                base_delay=0.01,
                max_delay=0.1,
            )

        assert result == {"status": "success"}
        assert call_count == 2

    @pytest.mark.asyncio
    async def test_retry_on_502_bad_gateway(self):
        """Retries on 502 status code (bad gateway)."""
        call_count = 0

        async def mock_request(method, url, **kwargs):
            nonlocal call_count
            call_count += 1
            if call_count < 2:
                raise ConfluenceAPIError("bad gateway", status_code=502)
            return {"status": "success"}

        with patch("www_confluence_mcp.api.session.request", mock_request):
            result = await _request_with_retry(
                "GET",
                "/test",
                max_retries=3,
                base_delay=0.01,
                max_delay=0.1,
            )

        assert result == {"status": "success"}
        assert call_count == 2

    @pytest.mark.asyncio
    async def test_retry_on_503_unavailable(self):
        """Retries on 503 status code (service unavailable)."""
        call_count = 0

        async def mock_request(method, url, **kwargs):
            nonlocal call_count
            call_count += 1
            if call_count < 2:
                raise ConfluenceAPIError("unavailable", status_code=503)
            return {"status": "success"}

        with patch("www_confluence_mcp.api.session.request", mock_request):
            result = await _request_with_retry(
                "GET",
                "/test",
                max_retries=3,
                base_delay=0.01,
                max_delay=0.1,
            )

        assert result == {"status": "success"}
        assert call_count == 2

    @pytest.mark.asyncio
    async def test_retry_on_504_gateway_timeout(self):
        """Retries on 504 status code (gateway timeout)."""
        call_count = 0

        async def mock_request(method, url, **kwargs):
            nonlocal call_count
            call_count += 1
            if call_count < 2:
                raise ConfluenceAPIError("gateway timeout", status_code=504)
            return {"status": "success"}

        with patch("www_confluence_mcp.api.session.request", mock_request):
            result = await _request_with_retry(
                "GET",
                "/test",
                max_retries=3,
                base_delay=0.01,
                max_delay=0.1,
            )

        assert result == {"status": "success"}
        assert call_count == 2


class TestRequestWithRetryNonRetryable:
    """Test _request_with_retry does not retry non-retryable errors."""

    @pytest.mark.asyncio
    async def test_no_retry_on_404_not_found(self):
        """Does not retry on 404 status code."""
        call_count = 0

        async def mock_request(method, url, **kwargs):
            nonlocal call_count
            call_count += 1
            raise ConfluenceNotFoundError("not found")

        with patch("www_confluence_mcp.api.session.request", mock_request):
            with pytest.raises(ConfluenceNotFoundError):
                await _request_with_retry(
                    "GET",
                    "/test",
                    max_retries=3,
                    base_delay=0.01,
                    max_delay=0.1,
                )

        assert call_count == 1  # No retry

    @pytest.mark.asyncio
    async def test_no_retry_on_403_forbidden(self):
        """Does not retry on 403 status code."""
        call_count = 0

        from www_confluence_mcp.exceptions import ConfluencePermissionError

        async def mock_request(method, url, **kwargs):
            nonlocal call_count
            call_count += 1
            raise ConfluencePermissionError("forbidden")

        with patch("www_confluence_mcp.api.session.request", mock_request):
            with pytest.raises(ConfluencePermissionError):
                await _request_with_retry(
                    "GET",
                    "/test",
                    max_retries=3,
                    base_delay=0.01,
                    max_delay=0.1,
                )

        assert call_count == 1  # No retry

    @pytest.mark.asyncio
    async def test_no_retry_on_409_conflict(self):
        """Does not retry on 409 status code."""
        call_count = 0

        from www_confluence_mcp.exceptions import ConfluenceConflictError

        async def mock_request(method, url, **kwargs):
            nonlocal call_count
            call_count += 1
            raise ConfluenceConflictError("conflict")

        with patch("www_confluence_mcp.api.session.request", mock_request):
            with pytest.raises(ConfluenceConflictError):
                await _request_with_retry(
                    "GET",
                    "/test",
                    max_retries=3,
                    base_delay=0.01,
                    max_delay=0.1,
                )

        assert call_count == 1  # No retry


class TestRequestWithRetryMaxRetries:
    """Test _request_with_retry respects max_retries limit."""

    @pytest.mark.asyncio
    async def test_max_retries_exceeded(self):
        """Raises error after max_retries attempts."""
        call_count = 0

        async def mock_request(method, url, **kwargs):
            nonlocal call_count
            call_count += 1
            raise ConfluenceRateLimitError("rate limited", retry_after=0.01)

        with patch("www_confluence_mcp.api.session.request", mock_request):
            with pytest.raises(ConfluenceRateLimitError):
                await _request_with_retry(
                    "GET",
                    "/test",
                    max_retries=3,
                    base_delay=0.01,
                    max_delay=0.1,
                )

        assert call_count == 4  # Initial + 3 retries

    @pytest.mark.asyncio
    async def test_max_retries_custom(self):
        """Respects custom max_retries value."""
        call_count = 0

        async def mock_request(method, url, **kwargs):
            nonlocal call_count
            call_count += 1
            raise ConfluenceAPIError("server error", status_code=500)

        with patch("www_confluence_mcp.api.session.request", mock_request):
            with pytest.raises(ConfluenceAPIError):
                await _request_with_retry(
                    "GET",
                    "/test",
                    max_retries=5,
                    base_delay=0.01,
                    max_delay=0.1,
                )

        assert call_count == 6  # Initial + 5 retries


class TestRequestWithRetryBackoff:
    """Test _request_with_retry exponential backoff behavior."""

    @pytest.mark.asyncio
    async def test_respects_retry_after_header(self):
        """Respects retry_after value from exception."""
        call_count = 0
        elapsed_time = 0.0
        start_time = 0.0

        async def mock_request(method, url, **kwargs):
            nonlocal call_count, start_time, elapsed_time
            call_count += 1
            if call_count == 1:
                start_time = time.monotonic()
                raise ConfluenceRateLimitError("rate limited", retry_after=0.15)
            elapsed_time = time.monotonic() - start_time
            return {"status": "success"}

        with patch("www_confluence_mcp.api.session.request", mock_request):
            result = await _request_with_retry(
                "GET",
                "/test",
                max_retries=3,
                base_delay=0.01,
                max_delay=0.1,
            )

        assert result == {"status": "success"}
        assert call_count == 2
        # Should have waited ~0.15s (the retry_after value)
        assert elapsed_time >= 0.12  # Allow some tolerance
        assert elapsed_time < 0.25

    @pytest.mark.asyncio
    async def test_exponential_backoff_without_retry_after(self):
        """Uses exponential backoff when retry_after not provided."""
        call_count = 0
        delays = []
        last_call_time = 0.0

        async def mock_request(method, url, **kwargs):
            nonlocal call_count, delays, last_call_time
            current_time = time.monotonic()
            if call_count > 0:
                delays.append(current_time - last_call_time)
            call_count += 1
            last_call_time = current_time
            if call_count < 4:
                raise ConfluenceAPIError("server error", status_code=500)
            return {"status": "success"}

        with patch("www_confluence_mcp.api.session.request", mock_request):
            result = await _request_with_retry(
                "GET",
                "/test",
                max_retries=3,
                base_delay=0.05,  # 50ms base
                max_delay=1.0,
            )

        assert result == {"status": "success"}
        assert call_count == 4
        # Verify exponential backoff: delays should increase
        # With base_delay=0.05 and jitter=0.1:
        # retry 1: 0.05 * 2^1 = 0.1s
        # retry 2: 0.05 * 2^2 = 0.2s
        # retry 3: 0.05 * 2^3 = 0.4s
        assert len(delays) == 3
        # Delays should generally increase (allowing for jitter)
        assert delays[0] < delays[2]  # First delay < last delay


class TestRequestWithRetryCustomStatuses:
    """Test _request_with_retry with custom retryable statuses."""

    @pytest.mark.asyncio
    async def test_custom_retryable_statuses(self):
        """Retries on custom status codes."""
        call_count = 0

        async def mock_request(method, url, **kwargs):
            nonlocal call_count
            call_count += 1
            if call_count < 2:
                raise ConfluenceAPIError("custom error", status_code=408)
            return {"status": "success"}

        with patch("www_confluence_mcp.api.session.request", mock_request):
            result = await _request_with_retry(
                "GET",
                "/test",
                max_retries=3,
                base_delay=0.01,
                max_delay=0.1,
                retryable_statuses={408, 429, 500, 502, 503, 504},
            )

        assert result == {"status": "success"}
        assert call_count == 2

    @pytest.mark.asyncio
    async def test_excluded_from_default_retryable(self):
        """Does not retry on statuses not in default set."""
        call_count = 0

        async def mock_request(method, url, **kwargs):
            nonlocal call_count
            call_count += 1
            raise ConfluenceAPIError("custom error", status_code=408)

        with patch("www_confluence_mcp.api.session.request", mock_request):
            with pytest.raises(ConfluenceAPIError):
                await _request_with_retry(
                    "GET",
                    "/test",
                    max_retries=3,
                    base_delay=0.01,
                    max_delay=0.1,
                    # Using default retryable_statuses (doesn't include 408)
                )

        assert call_count == 1  # No retry


class TestRequestWithRetryKwargs:
    """Test _request_with_retry passes kwargs to _request."""

    @pytest.mark.asyncio
    async def test_passes_json_parameter(self):
        """Passes json parameter to _request."""
        received_json = None

        async def mock_request(method, url, **kwargs):
            nonlocal received_json
            received_json = kwargs.get("json")
            return {"status": "success"}

        test_json = {"title": "Test", "body": "Content"}
        with patch("www_confluence_mcp.api.session.request", mock_request):
            await _request_with_retry(
                "POST",
                "/test",
                json=test_json,
            )

        assert received_json == test_json

    @pytest.mark.asyncio
    async def test_passes_params_parameter(self):
        """Passes params parameter to _request."""
        received_params = None

        async def mock_request(method, url, **kwargs):
            nonlocal received_params
            received_params = kwargs.get("params")
            return {"status": "success"}

        test_params = {"expand": "body.storage", "limit": 10}
        with patch("www_confluence_mcp.api.session.request", mock_request):
            await _request_with_retry(
                "GET",
                "/test",
                params=test_params,
            )

        assert received_params == test_params

    @pytest.mark.asyncio
    async def test_passes_multiple_parameters(self):
        """Passes multiple parameters to _request."""
        received_kwargs = None

        async def mock_request(method, url, **kwargs):
            nonlocal received_kwargs
            received_kwargs = kwargs
            return {"status": "success"}

        with patch("www_confluence_mcp.api.session.request", mock_request):
            await _request_with_retry(
                "PUT",
                "/test",
                json={"data": "value"},
                params={"expand": "version"},
                headers={"X-Custom": "header"},
            )

        assert received_kwargs is not None
        assert received_kwargs.get("json") == {"data": "value"}
        assert received_kwargs.get("params") == {"expand": "version"}
        assert received_kwargs.get("headers") == {"X-Custom": "header"}


class TestAsyncRateLimiter:
    """Tests for AsyncRateLimiter class."""

    @pytest.mark.asyncio
    async def test_rate_limiter_initialization(self):
        """Rate limiter initializes with correct values."""
        from www_confluence_mcp.api.session import AsyncRateLimiter

        limiter = AsyncRateLimiter(tokens_per_second=10.0, max_tokens=20)
        assert limiter.tokens_per_second == 10.0
        assert limiter.max_tokens == 20
        assert limiter.available_tokens == 20.0

    @pytest.mark.asyncio
    async def test_acquire_single_token(self):
        """Acquiring single token succeeds immediately when available."""
        from www_confluence_mcp.api.session import AsyncRateLimiter

        limiter = AsyncRateLimiter(tokens_per_second=10.0, max_tokens=5)
        await limiter.acquire()
        assert limiter.available_tokens < 5.0

    @pytest.mark.asyncio
    async def test_acquire_multiple_tokens(self):
        """Acquiring multiple tokens reduces count correctly."""
        from www_confluence_mcp.api.session import AsyncRateLimiter

        limiter = AsyncRateLimiter(tokens_per_second=10.0, max_tokens=10)
        await limiter.acquire(3)
        assert limiter.available_tokens < 8.0  # Allow for small replenishment

    @pytest.mark.asyncio
    async def test_acquire_waits_when_empty(self):
        """Acquire waits when no tokens available."""
        from www_confluence_mcp.api.session import AsyncRateLimiter

        limiter = AsyncRateLimiter(tokens_per_second=100.0, max_tokens=2)
        # Drain all tokens
        await limiter.acquire(2)
        assert limiter.available_tokens < 1.0

        # Next acquire should wait for replenishment
        start = time.monotonic()
        await limiter.acquire(1)
        elapsed = time.monotonic() - start

        # Should have waited for token replenishment
        assert elapsed > 0.0

    @pytest.mark.asyncio
    async def test_acquire_rejects_exceeding_max(self):
        """Acquire raises ValueError if tokens > max_tokens."""
        from www_confluence_mcp.api.session import AsyncRateLimiter

        limiter = AsyncRateLimiter(tokens_per_second=10.0, max_tokens=5)
        with pytest.raises(ValueError, match="Cannot acquire"):
            await limiter.acquire(10)

    @pytest.mark.asyncio
    async def test_token_replenishment(self):
        """Tokens are replenished over time."""
        from www_confluence_mcp.api.session import AsyncRateLimiter

        limiter = AsyncRateLimiter(tokens_per_second=100.0, max_tokens=10)
        initial = limiter.available_tokens

        # Drain tokens
        await limiter.acquire(10)
        after_drain = limiter.available_tokens
        assert after_drain < initial

        # Wait for replenishment
        await asyncio.sleep(0.05)  # 50ms = 5 tokens at 100/s
        after_wait = limiter.available_tokens
        assert after_wait > after_drain

    @pytest.mark.asyncio
    async def test_tokens_capped_at_max(self):
        """Tokens don't exceed max_tokens even after long wait."""
        from www_confluence_mcp.api.session import AsyncRateLimiter

        limiter = AsyncRateLimiter(tokens_per_second=100.0, max_tokens=10)
        await limiter.acquire(5)

        # Wait for full replenishment
        await asyncio.sleep(0.2)
        assert limiter.available_tokens <= 10.0

    @pytest.mark.asyncio
    async def test_rate_limiter_integration_with_request(self):
        """Request function uses rate limiter."""
        from unittest.mock import MagicMock, patch

        from www_confluence_mcp.api.session import request

        # Mock the client and response
        mock_client = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.content = b'{"result": "ok"}'
        mock_response.json = MagicMock(return_value={"result": "ok"})
        mock_response.raise_for_status = MagicMock()

        async def mock_request(*args, **kwargs):
            return mock_response

        async def mock_gather(resp):
            return resp

        mock_client.request = mock_request
        mock_client.gather = mock_gather

        with patch(
            "www_confluence_mcp.api.session.get_client", return_value=mock_client
        ):
            with patch("www_confluence_mcp.api.session.URL", "http://test.com"):
                # Clear the rate limiter singleton
                from www_confluence_mcp.api.session import (
                    _rate_limiter,
                    _rate_limiter_lock,
                )

                async with _rate_limiter_lock:
                    old_limiter = _rate_limiter
                    import www_confluence_mcp.api.session as session_module

                    session_module._rate_limiter = None

                try:
                    result = await request("GET", "/test")
                    assert result == {"result": "ok"}
                finally:
                    # Restore old limiter
                    async with _rate_limiter_lock:
                        session_module._rate_limiter = old_limiter

    @pytest.mark.asyncio
    async def test_get_rate_limiter_singleton(self):
        """get_rate_limiter returns same instance."""
        from www_confluence_mcp.api.session import get_rate_limiter

        limiter1 = await get_rate_limiter()
        limiter2 = await get_rate_limiter()
        assert limiter1 is limiter2
