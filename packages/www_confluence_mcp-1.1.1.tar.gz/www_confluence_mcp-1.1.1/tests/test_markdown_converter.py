"""Tests for Confluence ↔ Markdown converter — forward and backward."""

from pathlib import Path
from www_confluence_mcp.utils.converter import (
    build_frontmatter,
    parse_frontmatter,
    storage_to_markdown,
    markdown_to_storage,
    _extract_preserved_by_stack,
    _restore_macro,
    _restore_tasks,
    _restore_user,
    _restore_page_link,
    _restore_image,
    _restore_table,
    _parse_attrs,
    MARKDOWN_NATIVE,
    CONFLUENCE_PRESERVED,
)

FIXTURES = Path(__file__).parent / "fixtures"


class TestFrontmatter:
    def test_build_frontmatter_basic(self, page_data):
        """Basic dict → YAML string with --- delimiters."""
        result = build_frontmatter(page_data)
        assert result.startswith("---\n")
        assert result.endswith("---\n")
        assert "pageId" in result
        assert '"123"' in result

    def test_build_frontmatter_cyrillic(self, page_data):
        """Cyrillic title preserved."""
        page_data["title"] = "Тестовая страница"
        result = build_frontmatter(page_data)
        assert "Тестовая страница" in result

    def test_build_frontmatter_special_yaml_chars(self, page_data):
        """Handles :, #, [] with quotes."""
        page_data["title"] = "Title: with colon #hash [brackets]"
        result = build_frontmatter(page_data)
        meta, _ = parse_frontmatter(result + "\nbody")
        assert "Title: with colon" in meta.get("confluence", {}).get("title", "")

    def test_parse_frontmatter_round_trip(self, page_data):
        """parse(build(x)) == x."""
        page_data["version"]["number"] = 5
        fm = build_frontmatter(page_data)
        meta, body = parse_frontmatter(fm + "\nContent here")
        assert meta["confluence"]["pageId"] == "123"
        assert meta["confluence"]["space"] == "TEST"
        assert "Content here" in body

    def test_parse_frontmatter_empty_meta(self, page_data):
        """Empty dict returns valid frontmatter."""
        page_data["id"] = ""
        page_data["title"] = ""
        page_data["space"]["key"] = ""
        page_data["version"]["number"] = 0
        fm = build_frontmatter(page_data)
        assert fm.startswith("---\n")

    def test_parse_frontmatter_missing(self):
        """Content without frontmatter returns (empty dict, content)."""
        meta, body = parse_frontmatter("# Just markdown\n\nNo frontmatter here")
        assert meta == {}
        assert "Just markdown" in body


class TestElementClassification:
    def test_markdown_native_elements(self):
        """Standard HTML elements are handled by converter."""
        expected = {
            "h1",
            "h2",
            "h3",
            "h4",
            "h5",
            "h6",
            "p",
            "strong",
            "b",
            "em",
            "i",
            "code",
            "pre",
            "a",
            "ul",
            "ol",
            "li",
            "br",
            "hr",
            "blockquote",
        }
        assert expected.issubset(MARKDOWN_NATIVE)

    def test_confluence_preserved_elements(self):
        """Confluence elements are in preserved set."""
        expected = {
            "ac:structured-macro",
            "ac:task-list",
            "ac:task",
            "ri:user",
            "ri:page",
            "ri:attachment",
            "ac:image",
            "ac:link",
            "ac:emoticon",
        }
        assert expected.issubset(CONFLUENCE_PRESERVED)


class TestHTMLToMarkdown:
    def test_convert_headings(self):
        """h1-h6 → # through ######."""
        result = storage_to_markdown("<h1>Title</h1><h2>Sub</h2>", {})
        assert "# Title" in result
        assert "## Sub" in result

    def test_heading_with_toc_macro(self):
        """Heading containing ONLY TOC macro preserves the macro (no empty heading)."""
        html = '<h2><ac:structured-macro ac:name="toc" ac:schema-version="1"/></h2>'
        result = storage_to_markdown(html, {})

        # Should produce: <!-- CONFLUENCE_MACRO ... -->[TOC]<!-- /CONFLUENCE_MACRO -->
        # NOT: ## (empty heading)
        # When a heading contains ONLY macros, we output the macros without an empty heading
        assert "##" not in result  # No empty heading
        assert "CONFLUENCE_MACRO" in result
        assert "ac:structured-macro" in result
        assert 'ac:name="toc"' in result
        assert "[TOC]" in result

    def test_convert_bold_italic(self):
        """strong → **text**, em → *text*."""
        result = storage_to_markdown(
            "<p><strong>bold</strong> and <em>italic</em></p>", {}
        )
        assert "**bold**" in result
        assert "*italic*" in result

    def test_convert_code(self):
        """code → `code`."""
        result = storage_to_markdown("<p>Use <code>foo()</code></p>", {})
        assert "`foo()`" in result

    def test_convert_links(self):
        """a href → [text](url)."""
        result = storage_to_markdown(
            '<p><a href="https://example.com">Example</a></p>', {}
        )
        assert "[Example](https://example.com)" in result

    def test_convert_hr(self):
        """hr → ---."""
        result = storage_to_markdown("<hr/>", {})
        assert "---" in result

    def test_convert_nested_lists(self):
        """ul/ol with nesting."""
        result = storage_to_markdown("<ul><li>Item 1</li><li>Item 2</li></ul>", {})
        assert "- Item 1" in result
        assert "- Item 2" in result


class TestMacroPreservation:
    def test_info_macro_preview(self):
        """info macro generates blockquote preview."""
        result = storage_to_markdown(
            '<ac:structured-macro ac:name="info" ac:schema-version="1">'
            '<ac:parameter ac:name="title">Status</ac:parameter>'
            "<ac:rich-text-body><p>Active</p></ac:rich-text-body>"
            "</ac:structured-macro>",
            {},
        )
        assert "CONFLUENCE_MACRO" in result
        assert 'ac:name="info"' in result
        assert "Active" in result

    def test_code_macro_preview(self):
        """code macro generates code block preview."""
        result = storage_to_markdown(
            '<ac:structured-macro ac:name="code" ac:schema-version="1">'
            '<ac:parameter ac:name="language">python</ac:parameter>'
            '<ac:plain-text-body>print("hi")</ac:plain-text-body>'
            "</ac:structured-macro>",
            {},
        )
        assert "CONFLUENCE_MACRO" in result
        assert "python" in result
        assert "print" in result

    def test_toc_macro_preview(self):
        """toc macro generates [TOC] preview."""
        result = storage_to_markdown(
            '<ac:structured-macro ac:name="toc" ac:schema-version="1"/>', {}
        )
        assert "[TOC]" in result
        assert "toc" in result

    def test_toc_macro_has_raw_html(self):
        """toc macro includes CONFLUENCE_RAW_HTML block."""
        result = storage_to_markdown(
            '<ac:structured-macro ac:name="toc" ac:schema-version="1"/>', {}
        )
        assert "CONFLUENCE_RAW_HTML" in result
        assert "ac:structured-macro" in result
        assert 'ac:name="toc"' in result

    def test_warning_macro_preview(self):
        """warning macro generates warning preview."""
        result = storage_to_markdown(
            '<ac:structured-macro ac:name="warning" ac:schema-version="1">'
            "<ac:rich-text-body><p>Be careful</p></ac:rich-text-body>"
            "</ac:structured-macro>",
            {},
        )
        assert "Be careful" in result

    def test_nested_macros(self):
        """Macro inside macro preserved."""
        result = storage_to_markdown(
            '<ac:structured-macro ac:name="ui-tabs" ac:schema-version="1">'
            '<ac:structured-macro ac:name="ui-tab" ac:schema-version="1">'
            '<ac:parameter ac:name="title">Tab 1</ac:parameter>'
            "<ac:rich-text-body><p>Content</p></ac:rich-text-body>"
            "</ac:structured-macro>"
            "</ac:structured-macro>",
            {},
        )
        assert "ui-tabs" in result
        assert "ui-tab" in result

    def test_macro_has_raw_html_block(self):
        """All macros include CONFLUENCE_RAW_HTML block."""
        result = storage_to_markdown(
            '<ac:structured-macro ac:name="info" ac:schema-version="1">'
            "<ac:rich-text-body><p>Info</p></ac:rich-text-body>"
            "</ac:structured-macro>",
            {},
        )
        assert "CONFLUENCE_RAW_HTML" in result
        assert "ac:structured-macro" in result


class TestStandaloneMacros:
    """Tests for standalone (non-nested) Confluence macros.

    These tests ensure that macros at the top level (not inside tables or other
    containers) are properly detected and preserved.
    """

    def test_standalone_toc_macro(self):
        """Standalone TOC macro produces [TOC] preview + raw HTML."""
        html = '<ac:structured-macro ac:name="toc" ac:schema-version="1"/>'
        result = storage_to_markdown(html, {})

        # Check macro is preserved
        assert "CONFLUENCE_MACRO" in result
        assert "ac:structured-macro" in result
        assert 'ac:name="toc"' in result

        # Check raw HTML block exists
        assert "CONFLUENCE_RAW_HTML" in result

        # Check preview is [TOC]
        assert "[TOC]" in result

    def test_standalone_info_macro(self):
        """Standalone info macro produces blockquote preview + raw HTML."""
        html = (
            '<ac:structured-macro ac:name="info" ac:schema-version="1">'
            '<ac:parameter ac:name="title">Status</ac:parameter>'
            "<ac:rich-text-body><p>Active</p></ac:rich-text-body>"
            "</ac:structured-macro>"
        )
        result = storage_to_markdown(html, {})

        # Check macro is preserved
        assert "CONFLUENCE_MACRO" in result
        assert 'ac:name="info"' in result

        # Check raw HTML block exists
        assert "CONFLUENCE_RAW_HTML" in result

        # Check blockquote preview
        assert "> ℹ️" in result or "> **Status:**" in result
        assert "Active" in result

    def test_standalone_warning_macro(self):
        """Standalone warning macro produces warning preview + raw HTML."""
        html = (
            '<ac:structured-macro ac:name="warning" ac:schema-version="1">'
            "<ac:rich-text-body><p>Be careful!</p></ac:rich-text-body>"
            "</ac:structured-macro>"
        )
        result = storage_to_markdown(html, {})

        # Check macro is preserved
        assert "CONFLUENCE_MACRO" in result
        assert 'ac:name="warning"' in result

        # Check raw HTML block exists
        assert "CONFLUENCE_RAW_HTML" in result

        # Check warning preview
        assert "> ⚠️" in result
        assert "Be careful" in result

    def test_standalone_code_macro(self):
        """Standalone code macro produces fenced code preview + raw HTML."""
        html = (
            '<ac:structured-macro ac:name="code" ac:schema-version="1">'
            '<ac:parameter ac:name="language">python</ac:parameter>'
            '<ac:plain-text-body>print("hello")</ac:plain-text-body>'
            "</ac:structured-macro>"
        )
        result = storage_to_markdown(html, {})

        # Check macro is preserved
        assert "CONFLUENCE_MACRO" in result
        assert 'ac:name="code"' in result

        # Check raw HTML block exists
        assert "CONFLUENCE_RAW_HTML" in result

        # Check fenced code preview
        assert "```python" in result
        assert 'print("hello")' in result
        assert "```" in result

    def test_standalone_expand_macro(self):
        """Standalone expand macro produces details preview + raw HTML."""
        html = (
            '<ac:structured-macro ac:name="expand" ac:schema-version="1">'
            '<ac:parameter ac:name="title">Click to expand</ac:parameter>'
            "<ac:rich-text-body><p>Hidden content</p></ac:rich-text-body>"
            "</ac:structured-macro>"
        )
        result = storage_to_markdown(html, {})

        # Check macro is preserved
        assert "CONFLUENCE_MACRO" in result
        assert 'ac:name="expand"' in result

        # Check raw HTML block exists
        assert "CONFLUENCE_RAW_HTML" in result

        # Check expand preview (blockquote with 📂)
        assert "> 📂" in result or "> **Click to expand:**" in result
        assert "Hidden content" in result

    def test_standalone_emoticon(self):
        """Standalone emoticon produces emoji + raw HTML."""
        html = '<ac:emoticon ac:name="smile"/>'
        result = storage_to_markdown(html, {})

        # Check emoticon is preserved
        assert "CONFLUENCE_EMOTICON" in result
        assert "ac:emoticon" in result

        # Check raw HTML block exists
        assert "CONFLUENCE_RAW_HTML" in result

        # Check emoji
        assert "😊" in result

    def test_standalone_image(self):
        """Standalone image produces markdown image + raw HTML."""
        html = '<ac:image><ri:attachment ri:filename="test.png"/></ac:image>'
        result = storage_to_markdown(html, {})

        # Check image is preserved
        assert "CONFLUENCE_IMAGE" in result
        assert "ac:image" in result

        # Check raw HTML block exists
        assert "CONFLUENCE_RAW_HTML" in result

        # Check markdown image
        assert "![test.png]" in result

    def test_standalone_task_list(self):
        """Standalone task list produces checkboxes + raw HTML."""
        html = (
            "<ac:task-list>"
            '<ac:task ac:task-status="complete"><ac:task-body>Done</ac:task-body></ac:task>'
            '<ac:task ac:task-status="incomplete"><ac:task-body>Todo</ac:task-body></ac:task>'
            "</ac:task-list>"
        )
        result = storage_to_markdown(html, {})

        # Check task list is preserved
        assert "CONFLUENCE_TASKS" in result
        assert "ac:task-list" in result

        # Check raw HTML block exists
        assert "CONFLUENCE_RAW_HTML" in result

        # Check checkboxes
        assert "[x] Done" in result
        assert "[ ] Todo" in result

    def test_standalone_page_link(self):
        """Standalone page link produces markdown link + raw HTML."""
        html = (
            '<ac:link><ri:page ri:content-title="Docs" ri:space-key="DOC"/></ac:link>'
        )
        result = storage_to_markdown(html, {})

        # Check link is preserved
        assert "CONFLUENCE_PAGE_LINK" in result

        # Check raw HTML block exists
        assert "CONFLUENCE_RAW_HTML" in result

        # Check markdown link
        assert "[Docs]" in result

    def test_multiple_standalone_macros(self):
        """Multiple standalone macros in sequence are all preserved."""
        html = (
            '<ac:structured-macro ac:name="toc" ac:schema-version="1"/>'
            '<ac:structured-macro ac:name="info" ac:schema-version="1">'
            "<ac:rich-text-body><p>Info</p></ac:rich-text-body>"
            "</ac:structured-macro>"
            '<ac:structured-macro ac:name="code" ac:schema-version="1">'
            "<ac:plain-text-body>code</ac:plain-text-body>"
            "</ac:structured-macro>"
        )
        result = storage_to_markdown(html, {})

        # Check all macros are preserved
        assert result.count("CONFLUENCE_MACRO") >= 3
        assert 'ac:name="toc"' in result
        assert 'ac:name="info"' in result
        assert 'ac:name="code"' in result

        # Check all have raw HTML blocks
        assert result.count("CONFLUENCE_RAW_HTML") >= 3

        # Check previews
        assert "[TOC]" in result
        assert "Info" in result
        assert "code" in result


class TestElementPreservation:
    def test_user_inline_format(self):
        """User mention inline format (no newlines)."""
        result = storage_to_markdown(
            '<p>Responsible: <ac:link><ri:user ri:userkey="abc" ri:username="jdoe" /></ac:link></p>',
            {},
        )
        assert "jdoe" in result
        assert "CONFLUENCE_USER" in result or "CONFLUENCE_MACRO" in result

    def test_user_has_raw_html(self):
        """User mention includes CONFLUENCE_RAW_HTML block."""
        result = storage_to_markdown(
            '<p><ri:user ri:userkey="abc" ri:username="jdoe"/></p>',
            {},
        )
        assert "CONFLUENCE_RAW_HTML" in result
        assert "ri:user" in result

    def test_page_link_attributes(self):
        """Page link: content-title, space-key preserved."""
        result = storage_to_markdown(
            '<ac:link><ri:page ri:content-title="Docs" ri:space-key="DOC" /></ac:link>',
            {},
        )
        assert "Docs" in result

    def test_page_link_has_raw_html(self):
        """Page link includes CONFLUENCE_RAW_HTML block."""
        result = storage_to_markdown(
            '<ri:page ri:content-title="Docs" ri:space-key="DOC"/>',
            {},
        )
        assert "CONFLUENCE_RAW_HTML" in result
        assert "ri:page" in result

    def test_image_ri_attachment(self):
        """Image with ri:attachment preserved."""
        result = storage_to_markdown(
            '<ac:image><ri:attachment ri:filename="diagram.png" ri:version-at-save="1" /></ac:image>',
            {},
        )
        assert "diagram.png" in result

    def test_image_has_raw_html(self):
        """Image includes CONFLUENCE_RAW_HTML block."""
        result = storage_to_markdown(
            '<ac:image><ri:attachment ri:filename="test.png"/></ac:image>',
            {},
        )
        assert "CONFLUENCE_RAW_HTML" in result
        assert "ac:image" in result

    def test_emoticon_emoji_mapping(self):
        """Emoticon mapped to emoji."""
        result = storage_to_markdown('<p><ac:emoticon ac:name="smile" /></p>', {})
        # Should contain emoji or :smile: marker
        assert "😊" in result or "smile" in result

    def test_emoticon_has_raw_html(self):
        """Emoticon includes CONFLUENCE_RAW_HTML block."""
        result = storage_to_markdown('<ac:emoticon ac:name="smile"/>', {})
        assert "CONFLUENCE_RAW_HTML" in result
        assert "ac:emoticon" in result


class TestTableConversion:
    def test_basic_table(self):
        """Simple table → Markdown table."""
        result = storage_to_markdown(
            "<table><tbody><tr><th>A</th><th>B</th></tr>"
            "<tr><td>1</td><td>2</td></tr></tbody></table>",
            {},
        )
        assert "| A | B |" in result
        assert "| 1 | 2 |" in result

    def test_colspan(self):
        """colspan preserved in marker."""
        result = storage_to_markdown(
            '<table><tbody><tr><th colspan="2">Merged</th></tr>'
            "<tr><td>A</td><td>B</td></tr></tbody></table>",
            {},
        )
        assert "Merged" in result

    def test_colgroup_styles(self):
        """Colgroup styles preserved in comment."""
        result = storage_to_markdown(
            '<table class="wrapped" style="width: 100%">'
            '<colgroup><col style="width: 50%" /><col style="width: 50%" /></colgroup>'
            "<tbody><tr><th>A</th><th>B</th></tr>"
            "<tr><td>1</td><td>2</td></tr></tbody></table>",
            {},
        )
        assert "CONFLUENCE_TABLE" in result
        assert "A" in result

    def test_table_has_raw_html(self):
        """Tables include CONFLUENCE_RAW_HTML block."""
        result = storage_to_markdown(
            '<table class="wrapped"><tbody><tr><th>A</th></tr></tbody></table>',
            {},
        )
        assert "CONFLUENCE_RAW_HTML" in result
        assert 'class="wrapped"' in result
        assert "| A |" in result
        assert "<table" in result


class TestTaskList:
    def test_task_list_checkbox(self):
        """Task list → checkbox format."""
        result = storage_to_markdown(
            "<ac:task-list>"
            '<ac:task ac:task-status="complete" ac:task-id="33">'
            "<ac:task-body>Done</ac:task-body></ac:task>"
            '<ac:task ac:task-status="incomplete" ac:task-id="35">'
            "<ac:task-body>Todo</ac:task-body></ac:task>"
            "</ac:task-list>",
            {},
        )
        assert "[x]" in result or "✅" in result
        assert "[ ]" in result or "⬜" in result
        assert "Done" in result
        assert "Todo" in result

    def test_task_list_has_raw_html(self):
        """Task list includes CONFLUENCE_RAW_HTML block."""
        result = storage_to_markdown(
            "<ac:task-list>"
            '<ac:task ac:task-status="complete">'
            "<ac:task-body>Done</ac:task-body></ac:task>"
            "</ac:task-list>",
            {},
        )
        assert "CONFLUENCE_RAW_HTML" in result
        assert "ac:task-list" in result


class TestStorageToHybrid:
    def test_basic_page(self):
        """Basic page with headings, paragraphs."""
        html = "<h1>Title</h1><p>Text</p>"
        result = storage_to_markdown(
            html,
            {"id": "1", "title": "T", "space": {"key": "S"}, "version": {"number": 1}},
        )
        assert "# Title" in result
        assert "Text" in result
        assert "---" in result  # frontmatter

    def test_page_with_macros(self):
        """Page with macros preserved."""
        html = (
            '<ac:structured-macro ac:name="info" ac:schema-version="1">'
            "<ac:rich-text-body><p>Info</p></ac:rich-text-body>"
            "</ac:structured-macro>"
        )
        result = storage_to_markdown(
            html,
            {"id": "1", "title": "T", "space": {"key": "S"}, "version": {"number": 1}},
        )
        assert "CONFLUENCE_MACRO" in result
        assert "Info" in result

    def test_page_with_mixed_content(self):
        """Page with mixed HTML + Confluence elements."""
        html = (
            "<h1>Title</h1>"
            "<p>Text with <strong>bold</strong></p>"
            '<ac:structured-macro ac:name="toc" ac:schema-version="1"/>'
        )
        result = storage_to_markdown(
            html,
            {"id": "1", "title": "T", "space": {"key": "S"}, "version": {"number": 1}},
        )
        assert "# Title" in result
        assert "**bold**" in result
        assert "[TOC]" in result

    def test_page_with_toc_and_tables_and_elements(self, page_data):
        """Page with TOC macro, tables, and preserved elements (simulates real page)."""
        html = (
            "<h1>Product Passport</h1>"
            '<ac:structured-macro ac:name="toc" ac:schema-version="1"/>'
            '<p>Responsible: <ri:user ri:username="jdoe" ri:userkey="abc"/></p>'
            '<table class="wrapped" style="width: 100%">'
            '<colgroup><col style="width: 50%"/></colgroup>'
            "<tbody><tr><th>Feature</th><th>Status</th></tr>"
            "<tr><td>Auth</td><td>Done</td></tr></tbody></table>"
            '<ac:image><ri:attachment ri:filename="diagram.png"/></ac:image>'
            '<ac:emoticon ac:name="smile"/>'
            "<ac:task-list>"
            '<ac:task ac:task-status="complete"><ac:task-body>Done</ac:task-body></ac:task>'
            "</ac:task-list>"
        )
        page_data["id"] = "2333535450"
        result = storage_to_markdown(
            html,
            page_data,
        )
        # Verify TOC is present
        assert "CONFLUENCE_MACRO" in result
        assert "toc" in result
        assert "[TOC]" in result
        # Verify raw HTML blocks are present
        assert "CONFLUENCE_RAW_HTML" in result
        # Verify table is present
        assert "CONFLUENCE_TABLE" in result
        assert "| Feature | Status |" in result
        # Verify user is present
        assert "jdoe" in result
        # Verify image is present
        assert "diagram.png" in result
        # Verify emoticon is present
        assert "smile" in result or "😊" in result
        # Verify task list is present
        assert "[x]" in result or "Done" in result


# === BACKWARD CONVERTER TESTS ===


class TestStackParser:
    def test_basic_extraction(self):
        """Extract single CONFLUENCE_MACRO comment."""
        content = '<!-- CONFLUENCE_MACRO: ac:name="info" -->\n> Info body\n<!-- /CONFLUENCE_MACRO -->'
        preserved = {}
        result = _extract_preserved_by_stack(content, preserved)
        assert len(preserved) == 1
        # Result should have placeholder
        assert "__CONFLUENCE_ELEMENT" in result or "CONFLUENCE_MACRO" not in result

    def test_2_level_nesting(self):
        """Extract nested CONFLUENCE_MACRO comments."""
        content = (
            '<!-- CONFLUENCE_MACRO: ac:name="outer" -->\n'
            '<!-- CONFLUENCE_MACRO: ac:name="inner" -->\n'
            "Inner content\n"
            "<!-- /CONFLUENCE_MACRO -->\n"
            "<!-- /CONFLUENCE_MACRO -->"
        )
        preserved = {}
        _extract_preserved_by_stack(content, preserved)
        assert len(preserved) >= 1

    def test_uuid_uniqueness(self):
        """UUID placeholders are unique."""
        content = (
            '<!-- CONFLUENCE_MACRO: ac:name="a" -->\nA\n<!-- /CONFLUENCE_MACRO -->\n'
            '<!-- CONFLUENCE_MACRO: ac:name="b" -->\nB\n<!-- /CONFLUENCE_MACRO -->'
        )
        preserved = {}
        _extract_preserved_by_stack(content, preserved)
        assert len(preserved) == 2
        keys = list(preserved.keys())
        assert keys[0] != keys[1]

    def test_tasks_extraction(self):
        """Extract CONFLUENCE_TASKS comment."""
        content = "<!-- CONFLUENCE_TASKS -->\n- [x] Done <!-- task-id: 33 -->\n<!-- /CONFLUENCE_TASKS -->"
        preserved = {}
        _extract_preserved_by_stack(content, preserved)
        assert len(preserved) == 1

    def test_user_extraction(self):
        """Extract CONFLUENCE_USER comment (inline)."""
        content = '<!-- CONFLUENCE_USER: userkey="abc" username="jdoe" -->@jdoe<!-- /CONFLUENCE_USER -->'
        preserved = {}
        _extract_preserved_by_stack(content, preserved)
        assert len(preserved) == 1

    def test_malformed_missing_closing(self):
        """Handles malformed input gracefully."""
        content = '<!-- CONFLUENCE_MACRO: ac:name="info" -->\n> Info\n<!-- /CONFLUENCE_MACRO -->'
        preserved = {}
        # Should not raise
        result = _extract_preserved_by_stack(content, preserved)
        assert isinstance(result, str)


class TestParseAttrs:
    def test_basic_attrs(self):
        """Parse basic key=value attributes."""
        result = _parse_attrs('ac:name="info" ac:schema-version="1"')
        assert result["ac:name"] == "info"
        assert result["ac:schema-version"] == "1"

    def test_equals_in_value(self):
        """Handles = inside values."""
        result = _parse_attrs('key="a=b"')
        assert result["key"] == "a=b"

    def test_empty_values(self):
        """Handles empty values."""
        result = _parse_attrs('key=""')
        assert result["key"] == ""

    def test_multiple_params(self):
        """Parse multiple parameters."""
        result = _parse_attrs('userkey="abc" username="jdoe"')
        assert result["userkey"] == "abc"
        assert result["username"] == "jdoe"


class TestRestoreMacro:
    def test_basic_macro_restore(self):
        """Restore basic macro."""
        result = _restore_macro('ac:name="info" ac:schema-version="1"', "> Body")
        assert "ac:structured-macro" in result
        assert 'ac:name="info"' in result
        assert "Body" in result

    def test_macro_with_params(self):
        """Restore macro with parameters."""
        result = _restore_macro('ac:name="info" ac:parameter:title="Status"', "> Body")
        assert "ac:structured-macro" in result
        assert "Status" in result

    def test_code_macro_restore(self):
        """Restore code macro with language."""
        result = _restore_macro(
            'ac:name="code" ac:parameter:language="python"',
            '```python\nprint("hi")\n```',
        )
        assert "ac:structured-macro" in result
        assert "python" in result


class TestRestoreTasks:
    def test_restore_tasks(self):
        """Restore task list from checkboxes."""
        content = "- [x] Done <!-- task-id: 33 -->\n- [ ] Todo <!-- task-id: 35 -->"
        result = _restore_tasks("", content)
        assert "ac:task-list" in result
        assert "ac:task" in result
        assert "complete" in result
        assert "incomplete" in result
        assert "33" in result
        assert "35" in result


class TestRestoreUser:
    def test_restore_user(self):
        """Restore ri:user."""
        result = _restore_user('userkey="abc" username="jdoe"', "@jdoe")
        assert "ri:user" in result
        assert "abc" in result
        assert "jdoe" in result


class TestRestorePageLink:
    def test_restore_page_link(self):
        """Restore ri:page link."""
        result = _restore_page_link(
            'content-title="Docs" space-key="DOC"', "[Docs](Docs)"
        )
        assert "ri:page" in result
        assert "Docs" in result


class TestRestoreImage:
    def test_restore_image_attachment(self):
        """Restore ac:image with ri:attachment."""
        result = _restore_image(
            'ri:filename="diagram.png" ri:version-at-save="1"',
            "![diagram.png](attachments/diagram.png)",
        )
        assert "ac:image" in result
        assert "diagram.png" in result

    def test_restore_image_url(self):
        """Restore ac:image with ri:url."""
        result = _restore_image(
            'ri:url="https://example.com/img.png"',
            "![image](https://example.com/img.png)",
        )
        assert "ac:image" in result


class TestRestoreTable:
    def test_restore_table_basic(self):
        """Restore basic table."""
        table_md = "| A | B |\n|---|---|\n| 1 | 2 |"
        result = _restore_table('class="wrapped"', table_md)
        assert "<table" in result
        assert "A" in result
        assert "1" in result

    def test_restore_table_colspan(self):
        """Restore table with colspan."""
        table_md = "| {colspan=2} Merged |\n|---|---|\n| A | B |"
        result = _restore_table("", table_md)
        assert "colspan" in result
        assert "Merged" in result

    def test_restore_table_alignment(self):
        """Restore table alignment from :---: markers."""
        table_md = "| A | B |\n|:---:|---:|\n| 1 | 2 |"
        result = _restore_table("", table_md)
        assert "<table" in result


class TestHybridToStorage:
    def test_basic_markdown(self):
        """Basic markdown → HTML."""
        md = "# Title\n\nParagraph text."
        result = markdown_to_storage(md)
        assert "Title" in result
        assert "Paragraph" in result

    def test_macro_restoration(self):
        """Macro comments → ac: structured-macro."""
        md = (
            '---\nconfluence:\n  pageId: "1"\nformat: confluence_markdown\n---\n\n'
            '<!-- CONFLUENCE_MACRO: ac:name="info" ac:schema-version="1" -->\n'
            "> Info body\n"
            "<!-- /CONFLUENCE_MACRO -->"
        )
        result = markdown_to_storage(md)
        assert "ac:structured-macro" in result
        assert 'ac:name="info"' in result

    def test_user_restoration(self):
        """User comments → ri:user."""
        md = (
            '---\nconfluence:\n  pageId: "1"\nformat: confluence_markdown\n---\n\n'
            '<!-- CONFLUENCE_USER: userkey="abc" username="jdoe" -->@jdoe<!-- /CONFLUENCE_USER -->'
        )
        result = markdown_to_storage(md)
        assert "ri:user" in result
        assert "abc" in result

    def test_task_restoration(self):
        """Task comments → ac:task-list."""
        md = (
            '---\nconfluence:\n  pageId: "1"\nformat: confluence_markdown\n---\n\n'
            "<!-- CONFLUENCE_TASKS -->\n"
            "- [x] Done <!-- task-id: 33 -->\n"
            "- [ ] Todo <!-- task-id: 35 -->\n"
            "<!-- /CONFLUENCE_TASKS -->"
        )
        result = markdown_to_storage(md)
        assert "ac:task-list" in result
        assert "complete" in result

    def test_table_restoration(self):
        """Table comments → HTML table."""
        md = (
            '---\nconfluence:\n  pageId: "1"\nformat: confluence_markdown\n---\n\n'
            '<!-- CONFLUENCE_TABLE: class="wrapped" -->\n'
            "| A | B |\n|---|---|\n| 1 | 2 |\n"
            "<!-- /CONFLUENCE_TABLE -->"
        )
        result = markdown_to_storage(md)
        assert "<table" in result
        assert "A" in result

    def test_namespace_declarations(self):
        """Output has namespace declarations on first ac:/ri: element."""
        md = (
            '---\nconfluence:\n  pageId: "1"\nformat: confluence_markdown\n---\n\n'
            '<!-- CONFLUENCE_MACRO: ac:name="toc" ac:schema-version="1" -->\n[TOC]\n<!-- /CONFLUENCE_MACRO -->'
        )
        result = markdown_to_storage(md)
        assert "ac:structured-macro" in result
        # Namespace declarations should be on the first ac: element, not in a wrapper div
        assert 'xmlns:ac="http://atlassian.com/content"' in result
        assert 'xmlns:ri="http://atlassian.com/resource/identifier"' in result
        # Should NOT have div wrapper
        assert "<div" not in result


class TestRoundTrip:
    def test_basic_round_trip(self, page_data):
        """Basic page survives round-trip."""
        html = "<h1>Title</h1><p>Text</p>"
        md_content = storage_to_markdown(html, page_data)
        restored = markdown_to_storage(md_content)
        assert "Title" in restored
        assert "Text" in restored

    def test_macro_round_trip(self, page_data):
        """Macro survives round-trip."""
        html = (
            '<ac:structured-macro ac:name="info" ac:schema-version="1">'
            '<ac:parameter ac:name="title">Status</ac:parameter>'
            "<ac:rich-text-body><p>Active</p></ac:rich-text-body>"
            "</ac:structured-macro>"
        )
        md_content = storage_to_markdown(html, page_data)
        restored = markdown_to_storage(md_content)
        assert "ac:structured-macro" in restored
        assert "Active" in restored


class TestTimeElement:
    def test_time_forward_conversion(self):
        """time element → markdown with datetime."""
        result = storage_to_markdown(
            '<time datetime="2026-03-10">10 марта 2026</time>', {}
        )
        assert "10 марта 2026" in result
        assert "2026-03-10" in result
        # Should be in link format: [text](`datetime`)
        assert "[10 марта 2026](`2026-03-10`)" in result

    def test_time_round_trip(self, page_data):
        """time element survives round-trip."""
        html = '<p>Updated: <time datetime="2026-03-10T15:30:00Z">15:30</time></p>'
        md_content = storage_to_markdown(html, page_data)
        restored = markdown_to_storage(md_content)
        assert "time" in restored
        assert "2026-03-10T15:30:00Z" in restored

    def test_time_with_text_only(self):
        """time element without datetime attribute."""
        result = storage_to_markdown("<time>just text</time>", {})
        assert "just text" in result
