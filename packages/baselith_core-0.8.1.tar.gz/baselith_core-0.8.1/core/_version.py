"""Single source of truth for the framework version."""

__version__ = "0.8.1"
