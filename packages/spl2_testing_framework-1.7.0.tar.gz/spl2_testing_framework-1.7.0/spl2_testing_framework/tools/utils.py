# Copyright 2026 Splunk Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
import ast
import json
import logging
import pathlib
import re
from functools import lru_cache

_LOGGER = logging.getLogger(__name__)


def get_framework_root() -> pathlib.Path:
    framework_root = pathlib.Path(__file__).parents[1]
    return framework_root


def _make_functions_visible_for_testing(code_module_path):
    code_module = code_module_path.read_text(encoding="utf-8")
    functions = re.findall(r"^function\s+([^(]+)\(", code_module, flags=re.M)
    for function in functions:
        if not re.search(r"export\s" + function, code_module):
            code_module = re.sub(
                r"^function\s+" + function,
                f"export function {function}",
                code_module,
                flags=re.M,
            )
    return code_module


@lru_cache(None)
def read_assertions_module():
    root_folder = get_framework_root()
    assertions_file = root_folder / "spl2_utils" / "assertions.spl2"
    return assertions_file.read_text(encoding="utf-8")


@lru_cache(None)
def read_commands_modules():
    root_folder = get_framework_root()
    commands_module = root_folder / "spl2_utils" / "logs_to_metrics.spl2"
    return commands_module.read_text(encoding="utf-8")


def calculate_reduction_rate(original_event, reduced_event):
    """Calculate how much the event was reduced."""
    reduction_rates = []
    for original, reduced in zip(original_event, reduced_event):
        original_event_len = len(str(original))
        reduced_event_len = len(str(reduced))

        reduction_rates.append(
            (original_event_len - reduced_event_len) / original_event_len
        )
    return reduction_rates


def validate_compatibility(expected, parsed_output):
    """Validate if all fields from parsed_output are present in expected and have the same value."""
    extracted_but_wrong = {}
    not_extracted = {}
    for field, value in expected.items():
        if field in parsed_output:
            if parsed_output[field] == value:
                _LOGGER.info(f"FIELD {field} in reduced event")
                continue
            else:
                extracted_but_wrong[field] = value
                _LOGGER.error(f"FIELD {field} in reduced event has wrong value")

        else:
            not_extracted[field] = value
            _LOGGER.error(f"FIELD {field} is not present in the reduced event")

    _LOGGER.info(f"Checking wrong extractions")
    assert extracted_but_wrong == {}
    _LOGGER.info(f"Checking missing extractions")
    assert not_extracted == {}


def parse_raw_from_input(input_str):
    """Parse SPL2-style or JSON array of events and return list of _raw field values.
    Handles unquoted keys (e.g. {_raw: "x"}) by converting them to JSON-quoted keys.
    """
    # Only replace unquoted keys: key must be preceded by { or , (and optional space)
    key_pattern = re.compile(
        r"(\{|,)\s*(_raw|source|sourcetype|host)\s*:", re.MULTILINE
    )

    def quote_key(match):
        return f'{match.group(1)}"{match.group(2)}":'

    normalized = key_pattern.sub(quote_key, input_str)
    try:
        parsed = json.loads(normalized)
    except json.JSONDecodeError:
        parsed = ast.literal_eval(normalized)
    return [item["_raw"] for item in parsed]


def parse_raw_from_reduced_events(events):
    return [str(x["_raw"]) for x in events]
