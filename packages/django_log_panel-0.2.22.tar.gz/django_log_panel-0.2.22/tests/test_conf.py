import logging
import warnings

import pytest
from django.core.exceptions import ImproperlyConfigured
from django.test import override_settings

from log_panel.backends.sql import OrmBackend
from log_panel.conf import (
    get_backend,
    get_database_alias,
    get_ignored_logger_names,
    get_ignored_logger_prefixes,
    get_ignored_message_substrings,
    get_level_colors,
    get_permission_callback,
    get_ranges,
    get_setting,
    get_thresholds,
)
from log_panel.handlers import DatabaseHandler
from log_panel.types import RangeConfig


@pytest.fixture()
def clean_root_logger():
    """Remove any log_panel handlers from the root logger after test."""
    yield
    root = logging.getLogger()
    for h in list(root.handlers):
        if isinstance(h, DatabaseHandler):
            root.removeHandler(h)


def test_get_setting_returns_default_when_not_configured():
    assert get_setting("RETENTION_DAYS") == 90


@override_settings(LOG_PANEL={"RETENTION_DAYS": 30})
def test_get_setting_returns_user_value():
    assert get_setting("RETENTION_DAYS") == 30


@override_settings(LOG_PANEL={"RETENTION_DAYS": 14})
def test_get_setting_falls_back_for_partial_config():
    assert get_setting("RETENTION_DAYS") == 14
    assert get_setting("TABLE_PAGE_SIZE") == 10
    assert get_setting("TITLE") == "Log Panel"


def test_get_ranges_returns_typed_range_configs():
    ranges = get_ranges()
    for cfg in ranges.values():
        assert isinstance(cfg, RangeConfig)


def test_get_ranges_returns_all_default_keys():
    ranges = get_ranges()
    assert set(ranges.keys()) == {"24h", "30d", "90d"}


@override_settings(
    LOG_PANEL={
        "RANGES": {
            "1h": {
                "delta": __import__("datetime").timedelta(hours=1),
                "unit": "hour",
                "slots": 1,
                "format": "%H:00",
                "label": "Last hour",
            }
        }
    }
)
def test_get_ranges_normalises_dict_values():
    ranges = get_ranges()
    assert "1h" in ranges
    assert isinstance(ranges["1h"], RangeConfig)
    assert ranges["1h"].label == "Last hour"


def test_get_database_alias_returns_none_by_default():
    assert get_database_alias() is None


@override_settings(LOG_PANEL={"DATABASE_ALIAS": "logs"})
def test_get_database_alias_returns_configured_alias():
    assert get_database_alias() == "logs"


def test_get_backend_returns_none_when_nothing_configured():
    assert get_backend() is None


@override_settings(LOG_PANEL={"DATABASE_ALIAS": "default"})
def test_get_backend_returns_sql_backend_when_alias_configured():
    backend = get_backend()
    assert isinstance(backend, OrmBackend)


@override_settings(LOG_PANEL={"BACKEND": "log_panel.backends.sql.OrmBackend"})
def test_get_backend_returns_explicit_backend_when_backend_key_set():
    backend = get_backend()
    assert isinstance(backend, OrmBackend)


@override_settings(LOG_PANEL={"DATABASE_ALIAS": "default"})
def test_get_backend_returns_cached_instance_on_second_call():
    first = get_backend()
    second = get_backend()
    assert first is second


@override_settings(
    LOG_PANEL={
        "BACKEND": "log_panel.backends.sql.OrmBackend",
        "DATABASE_ALIAS": "default",
    }
)
def test_get_backend_explicit_takes_priority_over_alias():
    backend = get_backend()
    assert isinstance(backend, OrmBackend)


@override_settings(
    LOG_PANEL={"DATABASE_ALIAS": "logs"},
    DATABASE_ROUTERS=[],
)
def test_ready_raises_improperly_configured_when_alias_set_without_router():
    import log_panel
    from log_panel.apps import LogPanelConfig

    config = LogPanelConfig("log_panel", log_panel)
    with pytest.raises(ImproperlyConfigured, match="LogsRouter"):
        config.ready()


@override_settings(
    LOG_PANEL={"DATABASE_ALIAS": "logs"},
    DATABASE_ROUTERS=["log_panel.routers.LogsRouter"],
)
def test_ready_does_not_raise_when_router_is_present():
    import log_panel
    from log_panel.apps import LogPanelConfig

    config = LogPanelConfig("log_panel", log_panel)
    config.ready()


def test_thresholds_defaults():
    thresholds = get_thresholds()
    assert thresholds["WARNING"] == 1
    assert thresholds["ERROR"] == 1
    assert thresholds["CRITICAL"] == 1


@override_settings(LOG_PANEL={"THRESHOLDS": {"ERROR": 5, "WARNING": 3}})
def test_thresholds_can_be_overridden():
    thresholds = get_thresholds()
    assert thresholds["ERROR"] == 5
    assert thresholds["WARNING"] == 3
    assert thresholds["CRITICAL"] == 1


@override_settings(LOG_PANEL={"THRESHOLDS": {"WARNING": None}})
def test_threshold_can_be_disabled():
    assert get_thresholds()["WARNING"] is None


def test_get_ignored_logger_prefixes_includes_pymongo_by_default():
    assert get_ignored_logger_prefixes() == ("pymongo",)


@override_settings(LOG_PANEL={"IGNORED_LOGGER_PREFIXES": ("silk",)})
def test_get_ignored_logger_prefixes_extends_defaults():
    assert get_ignored_logger_prefixes() == ("pymongo", "silk")


@override_settings(LOG_PANEL={"IGNORED_LOGGER_PREFIXES": ("pymongo", "silk")})
def test_get_ignored_logger_prefixes_deduplicates_defaults():
    assert get_ignored_logger_prefixes() == ("pymongo", "silk")


def test_get_ignored_logger_names_defaults_to_empty_tuple():
    assert get_ignored_logger_names() == ()


@override_settings(LOG_PANEL={"IGNORED_LOGGER_NAMES": ("myapp.noisy",)})
def test_get_ignored_logger_names_returns_configured_names():
    assert get_ignored_logger_names() == ("myapp.noisy",)


def test_get_ignored_message_substrings_defaults_to_empty_tuple():
    assert get_ignored_message_substrings() == ()


@override_settings(LOG_PANEL={"IGNORED_MESSAGE_SUBSTRINGS": ('"silk_response"',)})
def test_get_ignored_message_substrings_returns_configured_values():
    assert get_ignored_message_substrings() == ('"silk_response"',)


def test_ready_does_not_raise_when_no_alias_configured():
    import log_panel
    from log_panel.apps import LogPanelConfig

    config = LogPanelConfig("log_panel", log_panel)
    config.ready()


def test_get_level_colors_returns_all_defaults():
    colors = get_level_colors()
    assert colors["NOTSET"] == "#888"
    assert colors["DEBUG"] == "#888"
    assert colors["INFO"] == "#417690"
    assert colors["WARNING"] == "#c0a000"
    assert colors["ERROR"] == "#c47900"
    assert colors["CRITICAL"] == "#ba2121"


@override_settings(LOG_PANEL={"LEVEL_COLORS": {"ERROR": "#ff0000"}})
def test_get_level_colors_user_override_merges_with_defaults():
    colors = get_level_colors()
    assert colors["ERROR"] == "#ff0000"
    assert colors["WARNING"] == "#c0a000"


@override_settings(LOG_PANEL={"LEVEL_COLORS": {"MY_AUDIT": "#0055aa"}})
def test_get_level_colors_custom_level_added():
    colors = get_level_colors()
    assert colors["MY_AUDIT"] == "#0055aa"
    assert "ERROR" in colors


def test_get_permission_callback_returns_none_by_default():
    assert get_permission_callback() is None


@override_settings(LOG_PANEL={"PERMISSION_CALLBACK": "tests.helpers.allow_all"})
def test_get_permission_callback_returns_callable():
    from tests.helpers import allow_all

    callback = get_permission_callback()
    assert callback is allow_all


@override_settings(LOG_PANEL={"PERMISSION_CALLBACK": "tests.nonexistent.func"})
def test_get_permission_callback_raises_on_bad_path():
    with pytest.raises(ImproperlyConfigured, match="PERMISSION_CALLBACK"):
        get_permission_callback()


def test_get_level_colors_includes_all_standard_levels_by_default():
    colors = get_level_colors()
    for level in ("CRITICAL", "ERROR", "WARNING", "INFO", "DEBUG", "NOTSET"):
        assert level in colors


def test_attach_root_handler_default_is_true():
    assert get_setting("ATTACH_ROOT_HANDLER") is True


def test_log_level_default_is_info():
    assert get_setting("LOG_LEVEL") == "INFO"


@override_settings(
    LOG_PANEL={
        "DATABASE_ALIAS": "logs",
    },
    DATABASE_ROUTERS=["log_panel.routers.LogsRouter"],
)
def test_ready_attaches_database_handler_to_root_logger(clean_root_logger):
    import log_panel
    from log_panel.apps import LogPanelConfig

    config = LogPanelConfig("log_panel", log_panel)
    config.ready()

    root = logging.getLogger()
    assert any(isinstance(h, DatabaseHandler) for h in root.handlers)


@override_settings(
    LOG_PANEL={
        "DATABASE_ALIAS": "logs",
        "ATTACH_ROOT_HANDLER": False,
    },
    DATABASE_ROUTERS=["log_panel.routers.LogsRouter"],
)
def test_ready_skips_attach_when_disabled(clean_root_logger):
    import log_panel
    from log_panel.apps import LogPanelConfig

    config = LogPanelConfig("log_panel", log_panel)
    config.ready()

    root = logging.getLogger()
    assert not any(isinstance(h, DatabaseHandler) for h in root.handlers)


@override_settings(
    LOG_PANEL={
        "DATABASE_ALIAS": "logs",
    },
    DATABASE_ROUTERS=["log_panel.routers.LogsRouter"],
)
def test_ready_warns_and_skips_when_handler_already_on_root(clean_root_logger):
    import log_panel
    from log_panel.apps import LogPanelConfig

    root = logging.getLogger()
    existing = DatabaseHandler()
    root.addHandler(existing)

    config = LogPanelConfig("log_panel", log_panel)
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        config.ready()

    assert any("ATTACH_ROOT_HANDLER" in str(w.message) for w in caught)
    db_handlers = [h for h in root.handlers if isinstance(h, DatabaseHandler)]
    assert len(db_handlers) == 1


@override_settings(
    LOG_PANEL={
        "DATABASE_ALIAS": "logs",
        "LOG_LEVEL": "WARNING",
    },
    DATABASE_ROUTERS=["log_panel.routers.LogsRouter"],
)
def test_ready_respects_log_level_setting(clean_root_logger):
    import log_panel
    from log_panel.apps import LogPanelConfig

    config = LogPanelConfig("log_panel", log_panel)
    config.ready()

    root = logging.getLogger()
    handler = next(h for h in root.handlers if isinstance(h, DatabaseHandler))
    assert handler.level == logging.WARNING


@override_settings(LOG_PANEL={"LEVEL_COLORS": {"MY_AUDIT": "#0055aa"}})
def test_get_level_colors_custom_level_preserves_defaults():
    colors = get_level_colors()
    assert colors["MY_AUDIT"] == "#0055aa"
    assert colors["ERROR"] == "#c47900"
