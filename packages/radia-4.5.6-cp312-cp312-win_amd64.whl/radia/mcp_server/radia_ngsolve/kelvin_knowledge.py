"""
Kelvin transformation knowledge base for Radia MCP server.

Covers the Kelvin inversion technique for open boundary FEM problems
using NGSolve, as implemented in examples/kelvin_transformation/.
"""

KELVIN_OVERVIEW = """
# Kelvin Transformation for Open Boundary Problems

The Kelvin transformation maps an unbounded exterior domain to a bounded
computational domain, enabling FEM solutions for open boundary
magnetostatic/electromagnetic problems without artificial truncation.

## Mathematical Foundation

### 2D (Circle Inversion)
- Maps: r' = R^2 / r
- Physical exterior: r > R  ->  Computational interior: 0 < r' < R
- Metric factor: dr'/dr = -R^2/r^2

### 3D (Sphere Inversion)
- Maps: rho' = R^2 / rho
- Physical exterior: rho > R  ->  Computational interior: 0 < rho' < R
- Metric factor: drho'/drho = -R^2/rho^2

## Key Principles

1. **Two Identical Spheres, Offset in Space**:
   - Interior sphere: physical domain (coil + iron + surrounding air), radius R
   - Exterior sphere (Kelvin): same radius R, offset in space (e.g., offset_x = 3R)
   - Both spheres have **identical radius and identical surface mesh**
   - Periodic BC couples DOFs 1:1 between the two boundaries via TRANSLATION
   - **WRONG**: concentric shell (R_inner to R_outer) -- this is NOT Kelvin
   - **CORRECT**: two separate spheres of the SAME radius R, placed apart

2. **Identical DOF Structure**:
   - Periodic BC requires the two identified boundaries to have matching DOFs
   - Both sphere surfaces must have the same mesh topology (same nodes, same elements)
   - OCC workflow: `Identify()` + `GenerateMesh()` handles this automatically
   - Cubit workflow: `copy mesh surface` from interior sphere to exterior sphere
     (MANDATORY -- without it, tet mesh gives different triangulations)
   - The relationship between identified nodes is a pure TRANSLATION (offset)

3. **Material Modulation** (exterior domain):

   **Physical principle**: Kelvin transformation is a numerical technique
   close to the physics of EM. It only **distorts material properties** -- the
   PDE itself is unchanged. The "image of infinity" is at rho'=0 (Kelvin
   sphere center), where:

   - **Direct material quantities** (mu, eps, sigma) -> **infinity** at rho'=0
   - **Reciprocal quantities** (nu = 1/mu, rho = 1/sigma) -> **0** at rho'=0

   For the 3D Kelvin inversion rho -> R^2/rho', the modulation is:

   | Quantity   | Formula                  | rho'=0 (infinity) | rho'=R (boundary) |
   |------------|--------------------------|-------------------|-------------------|
   | mu'        | (R / rho')^2 * mu_0      | infinity          | mu_0 (continuous) |
   | epsilon'   | (R / rho')^2 * eps_0     | infinity          | eps_0             |
   | sigma'     | (R / rho')^2 * sigma     | infinity          | sigma             |
   | nu' = 1/mu'| (rho' / R)^2 * nu_0      | **0**             | nu_0              |
   | rho_e'    | (rho' / R)^2 * rho_e     | **0**             | rho_e             |

   - rho' = distance from the CENTER of the exterior sphere
   - The factor is the same regardless of formulation (H, A, or Omega)
   - Use mu' for H1/Omega scalar potential, nu' for HCurl A-formulation

4. **Background Field Modulation** (exterior domain):
   - Physical Kelvin-transformed field: H'_i = -(R/r')^2 * H_i(R^2/r')
   - The sign flip comes from the negative Jacobian (orientation reversal)
   - For uniform dipole H_s=(0,0,1): exterior H'_s = (0, 0, -(R/r')^2)
   - For quadrupole H_s=(-z,0,-x): exterior H'_s = +(R^4/r'^4)*(z',0,x')
     (positive because the double negation: field already negative + Kelvin sign flip)
   - At the Kelvin boundary r'=R, the rule simplifies to H'(R) = -H(R)

5. **Periodic Boundary Conditions**:
   - Identify interior outer boundary with exterior outer boundary
   - Ensures field continuity at the inversion sphere/circle
   - Uses NGSolve `Periodic()` FE space wrapper
   - Boundary terms in the weak form AUTO-CANCEL with periodic BC

6. **GND Point (Dirichlet at Infinity)**:
   - Place vertex at exterior domain center (r'=0)
   - Corresponds to physical infinity
   - **H1 (scalar potential)**: Essential for uniqueness: `dirichlet_bbnd="GND"`
   - **HCurl (vector potential)**: Optional but recommended. Gauge
     regularization (`reg * nu0 * u * v * dx`) provides uniqueness without GND.
     GND improves convergence for iterative solvers.
   - Cubit: create vertex at Kelvin sphere center, assign as nodeset "GND"

## Cubit Workflow: Offset Spheres (3D with .vol export)

For Cubit-based meshes exported via `radia_export netgen`.
Verified with NGSolve 6.2.2603, Coreform Cubit 2025.3.

### Step-by-step procedure

```
1. Create interior sphere (radius R) centered at origin
   - Contains coil + iron + air
2. Create exterior sphere (SAME radius R) at offset position (e.g., x = 3R)
   - Contains only air (Kelvin domain)
3. Webcut BOTH spheres with the SAME plane (e.g., zplane)
   - ACIS sphere has 0 curves by default -- webcut creates 1 curve per hemisphere
   - This matching topology is required for copy mesh surface
4. Merge BOTH pairs of half-spheres:
   - imprint volume <inner_top> <inner_bottom>; merge volume <inner_top> <inner_bottom>
   - imprint volume <outer_top> <outer_bottom>; merge volume <outer_top> <outer_bottom>
   - This ensures equator nodes are shared -> inner node count = outer node count
5. Imprint/merge coil with air (interior sphere only, NOT with exterior)
6. Mesh interior hemisphere SURFACES first:
   - The air outer surface must be triangulated before copy mesh
   - `mesh volume {air_top} {air_bot}` creates the surface mesh as a side effect
   - Alternatively: `surface <N> scheme trimesh; mesh surface <N>` explicitly
7. copy mesh surface: interior sphere -> exterior sphere (MANDATORY)
   - copy mesh surface <in_sid> onto surface <out_sid> source curve <ic>
     source vertex <iv> target curve <ec> target vertex <ev>
   - Identify surfaces by area: hemisphere = largest area surface per volume
   - Guarantees 1:1 node correspondence for Periodic BC
   - WITHOUT copy mesh, tet meshing produces different triangulations -> crash
8. Mesh all volumes (tet mesh, using existing surface mesh as boundary constraint)
   - Do NOT set volume size for Kelvin volumes after copy (overrides copied mesh)
9. Set blocks (coil, air, kelvin) and sidesets (source, sink, kelvin_int, kelvin_ext)
   - sideset "kelvin_int": interior sphere outer surface (air boundary)
   - sideset "kelvin_ext": exterior sphere surface (kelvin boundary)
   - These MUST be set explicitly in the .py -- offset spheres do not share
     a face, so DomainIn/DomainOut auto-detection does NOT work
10. radia_export netgen: writes periodic identification as TRANSLATION
    - C++ reads bc names "kelvin_int" / "kelvin_ext" from sidesets
    - Computes offset = mean(kelvin_ext vertices) - mean(kelvin_int vertices)
    - Bijective nearest-neighbor matching (no duplicate targets)
    - Writes ident.Add() pairs to .vol (NGSolve Periodic() reads them)
```

### Copy mesh: dynamic surface identification (Cubit Python)

APREPRO cannot iterate over surfaces or compare areas. Use Cubit Python
for the mesh copy step:

```python
import math
A_hemi = 2.0 * math.pi * R**2  # hemisphere area

for inner_vid, outer_vid in [(air_top, kelvin_top), (air_bot, kelvin_bot)]:
    # Find hemisphere surface (largest area) in each volume
    inner_surfs = cubit.get_relatives("volume", inner_vid, "surface")
    outer_surfs = cubit.get_relatives("volume", outer_vid, "surface")
    src = max(inner_surfs, key=lambda s: cubit.surface(s).area())
    dst = max(outer_surfs, key=lambda s: cubit.surface(s).area())

    # Pick longest curve (equator) for orientation reference
    src_c = max(cubit.get_relatives("surface", src, "curve"),
                key=lambda c: cubit.curve(c).length())
    dst_c = max(cubit.get_relatives("surface", dst, "curve"),
                key=lambda c: cubit.curve(c).length())
    src_v = cubit.get_relatives("curve", src_c, "vertex")[0]
    dst_v = cubit.get_relatives("curve", dst_c, "vertex")[0]

    cubit.cmd(f"copy mesh surface {src} onto surface {dst} "
              f"source curve {src_c} source vertex {src_v} "
              f"target curve {dst_c} target vertex {dst_v}")
```

### Critical gotchas

| Issue | Symptom | Fix |
|-------|---------|-----|
| No mesh copy | different inner/outer vertex counts, crash | `copy mesh surface` is MANDATORY |
| Volume size after copy | Extra nodes on copied surface | Do NOT set kelvin volume size |
| ACIS sphere has 0 curves | copy mesh fails (no curve) | `webcut with plane zplane` |
| Coil imprinted with kelvin | Extra nodes on kelvin boundary | Only imprint coil with air, NOT kelvin |
| `mesh volume` without surface | copy mesh produces 0 tris | Mesh air volumes first |

### Verified result (2026-04-13)

```
copy mesh: surface 10 -> 14, surface 12 -> 16 (1:1 hemisphere copy)
Kelvin periodic: 270 inner, 270 outer verts (mesh copy guarantees match)
offset=(0.1990, 0.0000, -0.0001), max_dist=9.65e-04, 0 unmatched
Periodic HCurl: ndof=38333, FreeDofs: 38333 -> 37529 (804 coupled)
FEM-Kelvin L=80.46 nH (7000 Hz, copper cylinder workpiece)
```

**Do NOT use**:
- Concentric shells (R_inner to R_outer) -- this is NOT Kelvin transformation
- Radial scaling for node pairing -- use translation (offset)
- Independent tet mesh on both spheres without copy mesh -- different triangulations

## Material Modulation -- The Only Thing You Change

Kelvin transformation does not change the PDE -- you write the standard
weak form on the bounded computational domain (interior + Kelvin sphere)
and **only modify the material coefficients in the Kelvin region**.

| Formulation | Bilinear form           | Kelvin region material        |
|-------------|------------------------|-------------------------------|
| H1 / Omega  | int mu * grad u . grad v dx | mu = (R/r')^2 * mu_0     |
| HCurl A     | int nu * curl u . curl v dx | nu = (r'/R)^2 * nu_0     |
| H1 (eddy)   | + sigma * u * v dx          | sigma = (R/r')^2 * sigma_0|
| HCurl (eddy)| + (1/sigma) curl u * curl v | rho = (r'/R)^2 * rho_0   |

**The rule is the physical rule** (no coordinate substitution needed):

- mu, eps, sigma diverge to infinity at r'=0 (image of physical infinity)
- nu, rho_e (reciprocals) vanish to 0 at r'=0
- All factors are continuous (= material_0) at r'=R (kelvin boundary)

NGSolve example:
```python
nu_dict = {}
for m in mesh.GetMaterials():
    if "kelvin" in m.lower():
        rp_sq = (x-kx)**2 + (y-ky)**2 + (z-kz)**2 + 1e-20
        nu_dict[m] = NU_0 * rp_sq / R**2   # (r'/R)^2 * nu_0  -- vanishes at r'=0
    else:
        nu_dict[m] = NU_0
nu_cf = mesh.MaterialCF(nu_dict, default=NU_0)
```

The periodic BC at r'=R ensures continuity of the field across the
inversion boundary, completing the open-boundary closure.

## Supported Formulations

| Formulation | Primary Variable | Use Case |
|-------------|-----------------|----------|
| H-formulation | Perturbation potential phi | Permanent magnets, soft iron |
| A-formulation | Vector potential A | Coils, eddy currents |
| Omega-ReducedOmega | Scalar potentials | Domain decomposition |

## Advantages over Truncation

- **Exact**: No artificial boundary approximation
- **No PML tuning**: Eliminates absorbing layer parameters
- **Compact mesh**: Bounded domain even for infinite problems
- **Analytical validation**: Interior fields match exact solutions
"""

KELVIN_H_FORMULATION = """
# H-Formulation with Kelvin Transformation

The perturbation potential formulation: H = H_s - grad(phi)
where H_s is the known source field and phi is the unknown perturbation.

## Setup Steps

### 1. Geometry (OCC-based)

```python
from netgen.occ import *

circle_radius = 0.5    # Material radius [m]
kelvin_radius = 1.0    # Inversion radius [m]
offset_x = 3.0         # Separate interior/exterior domains

# Interior domain
wp = WorkPlane()
mag_circle = wp.Circle(circle_radius).Face()
mag_circle.name = "magnetic"
inner_boundary = wp.Circle(kelvin_radius).Face()
inner_air = inner_boundary - mag_circle
inner_air.name = "air_inner"

# Exterior (Kelvin) domain
wp_ext = WorkPlane(Axes(Pnt(offset_x, 0, 0), n=Z, h=X))
outer_circle = wp_ext.Circle(kelvin_radius).Face()
outer_circle.name = "air_outer"

# GND vertex at exterior center (= physical infinity)
gnd = Vertex(Pnt(offset_x, 0, 0))
gnd.name = "GND"
```

### 2. Periodic Identification

```python
# Name Kelvin boundary edges BEFORE boolean operations
for edge in inner_boundary.edges:
    edge.name = "kelvin_int"
for edge in outer_circle.edges:
    edge.name = "kelvin_ext"

# Boolean subtraction preserves edge names
inner_air = inner_boundary - mag_circle
inner_air.name = "air_inner"

shape = Glue([inner_air, mag_circle, outer_circle, gnd])

# Find edges by name and identify
kelvin_int = [e for e in shape.edges if e.name == "kelvin_int"]
kelvin_ext = [e for e in shape.edges if e.name == "kelvin_ext"]
for ie, ee in zip(kelvin_int, kelvin_ext):
    ie.Identify(ee, "periodic", IdentificationType.PERIODIC)

geo = OCCGeometry(shape, dim=2)
```

See topic `identify` for detailed best practices and anti-patterns.

### 3. FE Space with Periodic BC

```python
from ngsolve import *

mesh = Mesh(geo.GenerateMesh(maxh=0.03, grading=0.7))

fes_before = H1(mesh, order=3, dirichlet_bbnd="GND")
fes = Periodic(fes_before)  # Couples identified DOFs

# Verify DOF reduction
n_before = sum(1 for d in fes_before.FreeDofs() if d)
n_after = sum(1 for d in fes.FreeDofs() if d)
print(f"FreeDofs: {n_before} -> {n_after} (coupled: {n_before - n_after})")

u, v = fes.TnT()
```

### 4. Material Properties

```python
mu0 = 4 * pi * 1e-7
mu_r = 100

mu_dict = {
    "air_inner": mu0,
    "magnetic": mu_r * mu0,
    "air_outer": mu0,   # Will be modulated by Kelvin metric
}
mu = CoefficientFunction([mu_dict[m] for m in mesh.GetMaterials()])
```

### 5. Background Field (with Kelvin modulation)

```python
# Interior: uniform applied field
Hs_y_inner = 1.0

# Exterior: modulated by Kelvin metric
# H_s_exterior = -(rho'/R)^2 * H_s_interior
x_local = x - offset_x
r_prime = sqrt(x_local**2 + y**2)
Hs_y_outer = -(r_prime / kelvin_radius)**2 * Hs_y_inner

# Domain switching
is_exterior = IfPos(x - offset_x / 2, 1.0, 0.0)
Hs_y = (1 - is_exterior) * Hs_y_inner + is_exterior * Hs_y_outer
Hs = CoefficientFunction((0, Hs_y))
```

### 6. Weak Form and Solve

```python
# Bilinear: integral(mu * grad(u) . grad(v))
a = BilinearForm(fes)
a += mu * grad(u) * grad(v) * dx

# Linear: integral(mu * grad(v) . Hs)  -- NO boundary terms with Kelvin!
f = LinearForm(fes)
f += mu * InnerProduct(grad(v), Hs) * dx

a.Assemble()
f.Assemble()

gfu = GridFunction(fes)
c = Preconditioner(a, type="local")
solvers.CG(sol=gfu.vec, rhs=f.vec, mat=a.mat, pre=c.mat,
           tol=1e-8, printrates=True, maxsteps=10000)
```

### 7. Post-processing

```python
H_pert = -grad(gfu)   # Perturbation field

# Analytical solution for 2D cylinder in uniform field
H_interior_analytical = -1.0 + 2.0 / (mu_r + 1)

# Evaluate
H_numerical = H_pert[1](mesh(0, 0))
error = abs(H_numerical - H_interior_analytical) / abs(H_interior_analytical)
print(f"Error: {error*100:.3f}%")
```
"""

KELVIN_A_FORMULATION = """
# A-Formulation with Kelvin Transformation

Vector potential formulation, particularly useful for coil problems.

## Axisymmetric Coil Example (Z-offset Kelvin)

In axisymmetric problems, the z-offset strategy keeps the r-coordinate
unchanged between interior and exterior domains, simplifying the
transformation. The physical domain lives on x >= 0 (r = x, z = y)
and uses H1 scalar FES with u = r * A_phi substitution.

**Verified 2026-04-14**: L is independent of Kelvin radius R within
0.07% for R in [0.08, 0.25] m on a R_coil=30mm + R_wp=25mm test case,
confirming the reluctivity modulation formula nu_0 * (rho'/R)^2 is
correct.

**Helper function** (`src/radia/panels/add_kelvin.py`):

```python
from add_kelvin import add_kelvin_2d_axisym
# interior_shape: your 2D OCC face on x>=0 with outer arc named "kelvin_int"
shape, info = add_kelvin_2d_axisym(interior_shape, R=0.10, z_offset=0.25)
# info['axis_labels']  -> "axis|axis_ext" (pass to H1 dirichlet=...)
# info['z_offset']     -> z_offset used
# Periodic pairs are established; GND vertex at (0, z_offset) is added.
```

The caller is responsible for:
  1. Building the interior half-circle on x >= 0 with physical inclusions
     subtracted (coil, workpiece, etc.)
  2. Naming the outer arc edge(s) "kelvin_int" BEFORE passing to this function
  3. Naming "axis" on x = 0 edges (interior)
  4. Passing `dirichlet="axis|axis_ext"` and `dirichlet_bbnd="GND"` to
     the H1 FES, wrapping with `Periodic()`

```python
from ngsolve import *
from netgen.occ import *

coil_radius = 0.6       # Coil center radius [m]
kelvin_radius = 1.0     # Inversion radius
z_offset = 2.5          # Vertical offset for Kelvin domain

# Geometry: half-plane (r >= 0)
# Interior at z=0, Exterior at z=z_offset

# FE Space: u = r * A_theta
fes = H1(mesh, order=3, dirichlet="axis|axis_ext",
         dirichlet_bbnd="GND")
fes = Periodic(fes)
u, v = fes.TnT()

# Reluctivity with Kelvin modulation
mu0 = 4 * pi * 1e-7
nu0 = 1 / mu0
rho_prime = sqrt(x**2 + (y - z_offset)**2)
nu_outer = nu0 * (rho_prime / kelvin_radius)**2

nu = CoefficientFunction([nu_dict[m] for m in mesh.GetMaterials()])

# Weak form for axisymmetric A-formulation
r_coord = IfPos(x - 1e-10, x, 1e-10)  # Avoid r=0 singularity

a = BilinearForm(fes)
a += nu / r_coord * grad(u) * grad(v) * dx

f = LinearForm(fes)
f += J0 * v * dx("coil")  # J_theta source

a.Assemble()
f.Assemble()

# Solve and recover B-field
gfu = GridFunction(fes)
solvers.CG(sol=gfu.vec, rhs=f.vec, mat=a.mat, pre=c.mat,
           tol=1e-8, maxsteps=10000)

# B-field: Br = -(1/r)*du/dz, Bz = (1/r)*du/dr
grad_u = grad(gfu)
Br = -grad_u[1] / r_coord
Bz = grad_u[0] / r_coord
```
"""

KELVIN_3D = """
# 3D Kelvin Transformation

## 3D Sphere in Uniform Field (H-formulation)

```python
from ngsolve import *
from netgen.occ import *

sphere_radius = 0.5
kelvin_radius = 1.0
offset_x = 3.0

# Interior: sphere + air shell
mag_sphere = Sphere(Pnt(0, 0, 0), sphere_radius)
mag_sphere.mat("magnetic")
inner_sphere = Sphere(Pnt(0, 0, 0), kelvin_radius)
inner_air = inner_sphere - mag_sphere
inner_air.mat("air_inner")

# Exterior: Kelvin domain
outer_sphere = Sphere(Pnt(offset_x, 0, 0), kelvin_radius)
outer_sphere.mat("air_outer")

# GND at center of exterior
gnd = Vertex(Pnt(offset_x, 0, 0))
gnd.name = "GND"

# Name Kelvin boundary faces BEFORE boolean operations
for face in inner_sphere.faces:
    face.name = "kelvin_int"
for face in outer_sphere.faces:
    face.name = "kelvin_ext"

inner_air = inner_sphere - mag_sphere
inner_air.mat("air_inner")

shape = Glue([inner_air, mag_sphere, outer_sphere, gnd])

# Identify by name (see topic "identify" for details)
int_face = next(f for s in shape.solids for f in s.faces if f.name == "kelvin_int")
ext_face = next(f for s in shape.solids for f in s.faces if f.name == "kelvin_ext")
int_face.Identify(ext_face, "periodic", IdentificationType.PERIODIC)
geo = OCCGeometry(shape)
mesh = Mesh(geo.GenerateMesh(maxh=0.03))

# Periodic FE space
fes_before = H1(mesh, order=3, dirichlet="GND")
fes = Periodic(fes_before)
u, v = fes.TnT()

# 3D Kelvin permeability modulation
x_local = x - offset_x
r_prime_sq = x_local**2 + y**2 + z**2
mu_outer = kelvin_radius**2 / (r_prime_sq + 1e-20) * mu0

# 3D Kelvin background field modulation
r_prime = sqrt(r_prime_sq)
Hz_outer = -(r_prime / kelvin_radius)**2 * Hz_interior

# Solve (same pattern as 2D)
a = BilinearForm(fes)
a += mu * grad(u) * grad(v) * dx

f = LinearForm(fes)
f += mu * InnerProduct(grad(v), Hs) * dx

# Analytical validation for 3D sphere
Hz_analytical = 3.0 / (mu_r + 2)  # Interior field
```

## Key Differences from 2D

| Aspect | 2D | 3D |
|--------|----|----|
| Inversion | Circle: r' = R^2/r | Sphere: rho' = R^2/rho |
| mu modulation (H1)   | mu = (R/r')^2 * mu_0 | mu = (R/r')^2 * mu_0 |
| nu modulation (HCurl)| nu = (r'/R)^2 * nu_0 | nu = (r'/R)^2 * nu_0 |
| Linear form Kelvin factor | (R/r')^2 | (R/r')^4 |
| Physical H' (uniform) | H' = -H (no spatial variation) | H'_z = -(R/r')^2 |
| Analytical (dipole) | 2/(mu_r+1) | 3/(mu_r+2) |

**Physical rule**: mu, eps, sigma -> infinity at r'=0; nu, rho_e -> 0 at r'=0.

**Note on 2D anisotropy**: In 2D, the metric-based permeability is
anisotropic: constant in the r-direction, (R/r')^2 in the theta-direction.
However, in Cartesian coordinates with isotropic materials, these factors
cancel in the bilinear form, so the effective isotropic mu' = mu0 suffices.
"""

KELVIN_HCURL_3D = """
# 3D HCurl A-Formulation with Kelvin (calc_fem_kelvin.py)

The HCurl formulation solves for vector potential A directly in 3D,
used for coil problems with SIBC workpieces (induction heating).
This is what `calc_fem_kelvin.py` implements.

## Key Difference from H1 Formulations

| Aspect | H1 (phi/Omega) | HCurl (A) |
|--------|----------------|-----------|
| Primary variable | Scalar potential phi | Vector potential A |
| Bilinear form | mu * grad(u) * grad(v) | **nu** * curl(u) * curl(v) |
| Kelvin factor in bilinear | mu' = (R/r')^2 * mu0 | **nu' = (r'/R)^2 * nu0** |
| GND requirement | Essential (uniqueness) | Optional (gauge reg suffices) |
| Source term | mu * grad(v) . Hs dx | J * v * dx("coil") |
| Source modulation | Hs modulated in exterior | **No modulation** (J=0 in Kelvin) |

## Why nu = (r'/R)^2 * nu0

This follows directly from the Kelvin physical rule: under the inversion
r -> R^2/r', the image of physical infinity is at r'=0. Material quantities
behave at r'=0 according to whether they are direct or reciprocal:

| Quantity | At r'=0 (image of infinity) | Modulation                |
|----------|------------------------------|---------------------------|
| mu       | infinity                     | mu = (R/r')^2 * mu_0      |
| eps      | infinity                     | eps = (R/r')^2 * eps_0    |
| sigma    | infinity                     | sigma = (R/r')^2 * sigma_0|
| **nu = 1/mu**  | **0**                  | **nu = (r'/R)^2 * nu_0**  |
| rho_e = 1/sigma| 0                      | rho_e = (r'/R)^2 * rho_e_0|

The HCurl A-formulation uses nu in the bilinear form, hence:
```
nu_kelvin = (r'/R)^2 * nu_0     -- vanishes at the kelvin center (r'=0)
nu_kelvin = nu_0 at r'=R         -- continuous with the air domain
```

This is purely a **material distortion** -- the PDE is unchanged.
Kelvin transformation is among the most physical of numerical techniques
for open boundary problems precisely because it does not modify the weak
form, only the constitutive coefficient in the Kelvin domain.

## Implementation (from calc_fem_kelvin.py)

```python
from ngsolve import *

MU_0 = 4e-7 * pi
NU_0 = 1.0 / MU_0

mesh = Mesh("model.vol")  # Contains "coil", "air", "kelvin" materials

# Detect Kelvin sphere
kelvin_center = detect_kelvin_offset(mesh)  # centroid of "kelvin" elements
a_kelvin = estimate_kelvin_radius(mesh)     # min vertex distance from center

# Reluctivity with Kelvin modulation
kx, ky, kz = kelvin_center
nu_dict = {}
for m in mesh.GetMaterials():
    if "kelvin" in m.lower():
        dx_k = x - kx
        dy_k = y - ky
        dz_k = z - kz
        rp_sq = dx_k*dx_k + dy_k*dy_k + dz_k*dz_k + 1e-20
        kelvin_fac = rp_sq / a_kelvin**2  # (r'/R)^2
        nu_dict[m] = NU_0 * kelvin_fac
    else:
        nu_dict[m] = NU_0
nu_cf = mesh.MaterialCF(nu_dict, default=NU_0)

# FE space: HCurl + Periodic (no GND needed for HCurl)
dirichlet_bnd = "GND" if "GND" in mesh.GetBoundaries() else ""
base_fes = HCurl(mesh, order=1, complex=True, nograds=True, dirichlet=dirichlet_bnd)
fes = Periodic(base_fes)  # Couples Kelvin sphere DOFs
u, v = fes.TnT()

# Bilinear form: curl-curl with Kelvin-modulated nu
a = BilinearForm(fes)
a += nu_cf * curl(u) * curl(v) * dx(bonus_intorder=4)
a += reg * NU_0 * u * v * dx  # gauge regularization (HCurl uniqueness)

# SIBC = Robin BC on hole boundary (conductor NOT meshed, NOT solved)
# Validated 2026-04-14: 2D axisym Kelvin + SIBC (3D HCurl, hole approach)
#   matches within 2% in L, 4% in P vs 2D full-res with delta/5 mesh.
#   WARNING: an earlier claim of "L<1%, P<2%" compared 2D SIBC against a
#   COARSE 2D full-res (mesh/3, not delta/5); both were under-converged.
#   True full-res reference is reference_2d_axisym.solve_2d_axisym(kelvin=True)
#   which auto-refines WP to max(delta/5, 0.2mm).
# Z_s for solid cylinder: rho*gamma*I1(ga)/I0(ga), gamma=sqrt(jw*mu*sigma)
if has_sibc:
    robin = 1j * omega / Z_s
    a += robin * u.Trace() * v.Trace() * ds("sibc")

# Source: J in coil only (NO source modulation in Kelvin domain)
f = LinearForm(fes)
f += J_source * v * dx("coil")

a.Assemble()
f.Assemble()

gfu = GridFunction(fes)
gfu.vec.data = a.mat.Inverse(fes.FreeDofs(), inverse="pardiso") * f.vec

# Inductance from magnetic energy (nu_cf includes Kelvin modulation)
W_mag = Integrate(0.5 * nu_cf * curl(gfu) * Conj(curl(gfu)),
                  mesh, order=10).real
L = 2 * W_mag / I_total**2
```

## Why No Source Modulation is Needed

Unlike H-formulation where Hs must be modulated in the exterior domain,
the HCurl A-formulation has J_source = 0 in the Kelvin domain (no coil there).
The linear form `J * v * dx("coil")` only integrates over the coil region
in the interior sphere. The Kelvin domain contribution comes entirely from
the bilinear form (curl-curl stiffness with nu' modulation).

## GND Vertex in Cubit Workflow

For HCurl, GND is optional but improves iterative solver convergence:

```
# In Cubit journal (after creating exterior sphere):
create vertex X {kelvin_offset_x} Y 0 Z 0
nodeset 100 add vertex {last_vertex_id}
nodeset 100 name "GND"
```

The vertex at the Kelvin sphere center maps to physical infinity (r -> inf).
Setting A = 0 there is physically correct (no field at infinity).

## bonus_intorder for Kelvin Domain

The varying nu_cf = (r'/R)^2 * nu0 is a rational function of coordinates.
Standard quadrature rules are insufficient. Use `bonus_intorder=4`:

```python
a += nu_cf * curl(u) * curl(v) * dx(bonus_intorder=4)
```

Without bonus_intorder, integration error in the Kelvin domain can reach
several percent, leading to incorrect inductance values.
"""

KELVIN_ADAPTIVE = """
# Adaptive Mesh Refinement with Kelvin

## Error Estimators

1. **Zienkiewicz-Zhu (ZZ)**: Patch-recovery based, automatic
2. **Metric-based**: Remeshing with element-size control
3. **Uniform refinement**: Simple h-refinement for convergence study

## Workflow

```python
from ngsolve import *

for level in range(max_refinements):
    # Solve
    a.Assemble()
    f.Assemble()
    solvers.CG(sol=gfu.vec, rhs=f.vec, mat=a.mat, pre=c.mat,
               tol=1e-8, maxsteps=10000)

    # Compute error estimator (ZZ)
    flux = -mu * grad(gfu)
    fes_flux = VectorL2(mesh, order=order - 1)
    gf_flux = GridFunction(fes_flux)
    gf_flux.Set(flux)

    # Element-wise error
    err = Integrate(
        InnerProduct(flux - gf_flux, flux - gf_flux),
        mesh, element_wise=True
    )

    # Mark elements (Doerfler marking)
    max_err = max(err)
    for el in mesh.Elements():
        if err[el.nr] > 0.5 * max_err:
            mesh.SetRefinementFlag(el, True)

    # Refine
    mesh.Refine()

    # Update spaces
    fes.Update()
    gfu.Update()
    a.Assemble()
    f.Assemble()
```

## Typical Orders and Accuracy

| Order | Elements | Error (vs analytical) |
|-------|----------|-----------------------|
| 2     | 5,000    | ~0.5%                 |
| 3     | 5,000    | ~0.05%                |
| 4     | 5,000    | ~0.005%               |
| 3     | 20,000   | ~0.01%                |
"""

KELVIN_IDENTIFY = """
# Periodic Boundary Identification (Identify Method)

The `Identify()` method pairs geometric edges (2D) or faces (3D) on the
Kelvin boundary so that NGSolve's `Periodic()` FE space couples their DOFs.
Correct identification is critical -- if it fails silently, the solver runs
but produces wrong results.

## Recommended Approaches (Best to Worst)

### 1. Named Edge/Face Approach (Best for H-formulation with offset)

Name edges/faces during geometry construction **before** Boolean operations
(subtraction, Glue). Names survive OCC Boolean operations.

```python
# 2D Example: Name edges before subtraction
for edge in inner_circle.edges:
    edge.name = "kelvin_int"

inner_air = inner_circle - mag_circle  # Name survives subtraction

for edge in outer_circle.edges:
    edge.name = "kelvin_ext"

# After Glue, find by name
shape = Glue([inner_air, mag_circle, outer_circle, gnd])

kelvin_int_edges = [e for e in shape.edges if e.name == "kelvin_int"]
kelvin_ext_edges = [e for e in shape.edges if e.name == "kelvin_ext"]

for int_edge, ext_edge in zip(kelvin_int_edges, kelvin_ext_edges):
    int_edge.Identify(ext_edge, "periodic", IdentificationType.PERIODIC)
```

```python
# 3D Example: Name faces before subtraction
for face in inner_sphere.faces:
    face.name = "kelvin_int"

inner_air = inner_sphere - mag_sphere  # Name survives

for face in outer_sphere.faces:
    face.name = "kelvin_ext"

shape = Glue([inner_air, mag_sphere, outer_sphere, gnd])

kelvin_int_face = None
kelvin_ext_face = None
for solid in shape.solids:
    for face in solid.faces:
        if face.name == "kelvin_int":
            kelvin_int_face = face
        elif face.name == "kelvin_ext":
            kelvin_ext_face = face

kelvin_int_face.Identify(kelvin_ext_face, "periodic",
                         IdentificationType.PERIODIC)
```

### 2. Geometric Distance Predicate (Best for AdaptiveMesh / distance-based)

Use `abs(dist - kelvin_radius) < tolerance` to identify edges/faces on the
Kelvin boundary. The symmetric band avoids false matches.

```python
# Correct: symmetric band around Kelvin radius
for edge in air_inner.edges:
    dist = sqrt(edge.center.x**2 + edge.center.y**2)
    if abs(dist - kelvin_radius) < kelvin_radius * 0.2:
        edge.name = "kelvin_int"
```

### 3. Vertex Distance (Good for A-formulation)

For edges that are full circles (where `edge.center` returns the geometric
center, NOT a point on the circle), use `edge.start` or `edge.vertices`
instead.

```python
for edge in air_inner.edges:
    p = edge.start
    dist = sqrt(p.x**2 + p.y**2)
    if abs(dist - kelvin_radius) < kelvin_radius * 0.1:
        edge.name = "kelvin_int"
```

## Anti-Patterns (Do NOT Use)

### Bounding Box Heuristic
```python
# BAD: Fragile, depends on geometry ordering
max_bbox = 0
for i, edge in enumerate(shape.edges):
    bbox = edge.bounding_box
    size = max(bbox[3]-bbox[0], bbox[4]-bbox[1], bbox[5]-bbox[2])
    if size > max_bbox:
        max_bbox = size
        kelvin_edge = edge
```

### Direct Index Access
```python
# BAD: Index depends on OCC internal ordering, breaks silently
geo.solids[0].faces[0].Identify(geo.solids[1].faces[0], "periodic")
```

### One-Sided Threshold
```python
# BAD: Matches everything beyond 80% of R (too broad)
if dist > kelvin_radius * 0.8:
    face.name = "kelvin_int"

# GOOD: Symmetric band centered on R
if abs(dist - kelvin_radius) < kelvin_radius * 0.2:
    face.name = "kelvin_int"
```

### WorkPlane.Arc for Azimuthal Sectors
```python
# BAD: WorkPlane.Arc creates a TANGENTIAL arc (center ≠ origin)
wp = WorkPlane(Axes(Pnt(0,0,-R-0.1), n=Vec(0,0,1), h=Vec(1,0,0)))
wp.MoveTo(0, 0); wp.LineTo(R, 0)
wp.Arc(R, 60)   # Arc center is at (R, R, ...) NOT at origin!
wp.LineTo(0, 0)

# The resulting shape is NOT a circular sector!
# Vertex verification: Arc(R=4, 60°) from (4,0) gives endpoint (7.46, 2.0),
# NOT the expected (2.0, 3.46) for a true 60° rotation.

# GOOD: Use HalfSpace intersection for azimuthal wedges
import math
dphi = 2*math.pi/6
big_ball = Sphere(Pnt(0,0,0), R_large + 0.1)
h1 = HalfSpace(Pnt(0,0,0), Vec(0, -1, 0))
h2 = HalfSpace(Pnt(0,0,0), Vec(-math.sin(dphi), math.cos(dphi), 0))
wedge_vol = big_ball * h1 * h2
```

### Identify AFTER Glue on Glued Geometry's Faces
```python
# BAD: After Glue(), identifying faces of the glued shape
#       → NrIdentifications = 0 (silently fails)
geo_obj = Glue([inner_sec, outer_sec])
geo_obj.faces[2].Identify(geo_obj.faces[1], 'periodic', IdentificationType.PERIODIC, rot)

# GOOD: Identify BEFORE Glue on individual solid faces
inner_sec.faces[2].Identify(inner_sec.faces[1], 'periodic', IdentificationType.PERIODIC, rot)
outer_sec.faces[2].Identify(outer_sec.faces[1], 'periodic', IdentificationType.PERIODIC, rot)
geo_obj = Glue([inner_sec, outer_sec])  # Glue preserves identifications
```

## Verification: FreeDofs Check

Always verify that `Periodic()` actually coupled DOFs:

```python
fes_before = H1(mesh, order=3, dirichlet_bbnd="GND")
freedof_before = sum(1 for d in fes_before.FreeDofs() if d)

fes = Periodic(fes_before)
freedof_after = sum(1 for d in fes.FreeDofs() if d)

print(f"FreeDofs: {freedof_before} -> {freedof_after}")
if freedof_before == freedof_after:
    raise RuntimeError("Periodic BC NOT working! Check Identify() setup.")
```

If FreeDofs does not decrease, the identification failed silently.
Common causes:
- Names lost during Boolean operations (name before subtraction/Glue)
- Wrong tolerance in distance predicate
- `edge.center` returns geometric center for full circles (use `edge.start`)

## Axisymmetric Identification (Named Edge + Z-Sign)

For axisymmetric problems with z-offset, match interior/exterior edges
by name and z-coordinate sign:

```python
int_edges = [(e, e.center.y) for e in shape.edges if e.name == "kelvin_int"]
ext_edges = [(e, e.center.y) for e in shape.edges if e.name == "kelvin_ext"]

for ie, iy in int_edges:
    for ee, ey in ext_edges:
        if iy * ey > 0:  # Same z-sign
            ie.Identify(ee, "periodic", IdentificationType.PERIODIC)
```
"""

KELVIN_VERIFICATION = """
# Kelvin変換の数値検証 (Single-Domain Approach)

## 概要

Kelvin 変換の理論的正しさを FEM で検証する最も簡潔な方法は、
**単一の有限領域** (大球) で Poisson 方程式を解き、その FEM 解に対して
Kelvin 変換恒等式を後処理として確認することである。

## 手法: 単一大球 + 厳密 Dirichlet BC

### 設定
- 電荷球: 半径 R_in=0.5, 一様電荷密度 ρ=3.0
- 計算領域: 半径 R_large=3.0 の大球 (外側境界に厳密値を与える)
- Kelvin 変換半径: R_K=1.0

### 理論 (モノポール解)
外部解: φ(r) = ρ·R_in³ / (3r) = 0.125/r
Kelvin 変換: φ*(r*) = (R_K/r*) · φ(R_K²/r*) = ρ·R_in³/(3·R_K) = 0.125 (定数)

### NGSolve 実装

```python
from ngsolve import *
import netgen.occ as occ
import numpy as np

R_in = 0.5; R_K = 1.0; R_large = 3.0; rho_val = 3.0

phi_BC         = rho_val * R_in**3 / (3.0 * R_large)   # 0.041667 (外側Dirichlet)
phi_star_exact = rho_val * R_in**3 / (3.0 * R_K)        # 0.125000 (Kelvin定数)

# ジオメトリ: 内球 + 外殻
inner = occ.Sphere(occ.Pnt(0,0,0), R_in); inner.mat('inner'); inner.maxh = 0.05
outer_ball = occ.Sphere(occ.Pnt(0,0,0), R_large); outer_ball.bc('dirichlet_outer')
outer = outer_ball - occ.Sphere(occ.Pnt(0,0,0), R_in); outer.mat('outer'); outer.maxh = 0.2

geo  = occ.OCCGeometry(occ.Glue([inner, outer]))
mesh = Mesh(geo.GenerateMesh(maxh=0.2))
# → ~87,421 要素, 16,564 節点, 123,700 DOF

fes = H1(mesh, order=2, dirichlet='dirichlet_outer')
u, v = fes.TnT()
a = BilinearForm(fes); a += grad(u)*grad(v)*dx; a.Assemble()
f = LinearForm(fes);   f += rho_val*v*dx('inner'); f.Assemble()

gfu = GridFunction(fes)
gfu.Set(phi_BC, definedon=mesh.Boundaries('dirichlet_outer'))
inv = a.mat.Inverse(fes.FreeDofs(), inverse='sparsecholesky')
gfu.vec.data += inv * (f.vec - a.mat * gfu.vec)
```

### 検証 1: 物理中間領域 FEM vs 解析解

```python
sample_r = np.linspace(R_in*1.05, R_K*0.95, 25)
phi_fem = np.array([gfu(mesh(r, 0, 0)) for r in sample_r])
phi_ana = np.array([rho_val*R_in**3/(3.0*r) for r in sample_r])
err_mid = np.abs(phi_fem - phi_ana) / np.abs(phi_ana)
print(f'最大相対誤差: {err_mid.max():.2e}')  # 期待値: < 0.5%
```

### 検証 2: Kelvin 変換恒等式

```python
sample_rstar = np.linspace(R_K**2/R_large*1.1, R_K*0.95, 25)
phi_star_fem = np.array([
    (R_K/rs) * gfu(mesh(R_K**2/rs, 0, 0))
    for rs in sample_rstar
])
err_kelvin = np.abs(phi_star_fem - phi_star_exact) / phi_star_exact
print(f'Kelvin 恒等式 最大誤差: {err_kelvin.max():.2e}')  # 期待値: < 0.4%
print(f'phi* 範囲: [{phi_star_fem.min():.5f}, {phi_star_fem.max():.5f}]')
# 期待: [0.12465, 0.12489] (理想: 0.12500)
```

## 確認済み精度 (NGSolve 6.2.2601, maxh=0.2)

| 検証項目 | 最大相対誤差 | 平均相対誤差 |
|----------|-------------|-------------|
| 物理中間領域 FEM vs 解析解 | 3.53e-03 (0.35%) | 3.07e-03 |
| Kelvin 恒等式 φ*(r*) 定数性 | 2.81e-03 (0.28%) | 2.06e-03 |

## メッシュ精度の影響

精度を上げるには:
- `inner.maxh = 0.05` → 電荷球内を細かく (必須)
- `outer.maxh = 0.2`  → 外殻は粗くてよい
- `R_large` は大きいほど精度良いが、`R_large=3` で十分 (< 0.4% 誤差)
- `R_large=5` かつ `maxh=0.3` では誤差 ~9.7% (粗すぎ)

## 旧来の TnT() 呼び出し注意

```python
# NGSolve 6.2.2601: キーワード引数不可
u, v = fes.TnT()           # OK
u, v = fes.TnT(u_='u', v_='v')  # TypeError: NGSolve 6.2.2601 では不可
```
"""

KELVIN_PERIODIC_WEDGE = """
# 周期境界条件: 扇形セクタの DOF 削減

## 概要

軸対称・回転対称問題では、全球の代わりに **1/n セクタ** のみを解くことで計算コストを削減できる。
NGSolve では `Identify` + `Periodic(FESpace)` でこれを実現する。

## 正しい扇形ウェッジの作成

`WorkPlane.Arc` は **接線方向弧**（中心が原点でない）を作るため扇形 (pizza slice) にならない。
`HalfSpace` で 2 枚の半空間を切り出すのが正確。

```python
from netgen.occ import HalfSpace, Pnt, Vec, Sphere, Glue, OCCGeometry, IdentificationType, Rotation
import math

n_sector = 6                     # 6 分割 → 60° セクタ
dphi     = 2 * math.pi / n_sector

# NG: 半径 R_large+0.1 の大球を 2 つの HalfSpace で切断
big_ball = Sphere(Pnt(0,0,0), R_large + 0.1)
h1 = HalfSpace(Pnt(0,0,0), Vec(0, -1, 0))                              # y >= 0 (φ >= 0°)
h2 = HalfSpace(Pnt(0,0,0), Vec(-math.sin(dphi), math.cos(dphi), 0))    # φ <= dphi
wedge_vol = big_ball * h1 * h2

# 球殻をウェッジで切断
inner_sec = Sphere(Pnt(0,0,0), R_in)                       * wedge_vol
outer_sec = (Sphere(Pnt(0,0,0), R_large) - Sphere(Pnt(0,0,0), R_in)) * wedge_vol
inner_sec.mat('inner'); outer_sec.mat('outer')
outer_sec.faces[0].name = 'dirichlet_outer'   # 最大面積の外球面
```

## 周期境界の識別 (Identify)

**重要**: Identify は `Glue()` より**前**に個別のソリッド上の face で呼び出す。

```python
# face[2]: φ=0° 面 (y≈0 側), face[1]: φ=dphi 面 (y>0 側)
# → 面積と重心 y 座標で確認可能:
#     face[2]: area≈π·R²/2, y_center≈0
#     face[1]: area≈π·R²/2, y_center>0

rot = Rotation(Pnt(0,0,0), Vec(0,0,1), math.degrees(dphi))
inner_sec.faces[2].Identify(inner_sec.faces[1], 'periodic', IdentificationType.PERIODIC, rot)
outer_sec.faces[2].Identify(outer_sec.faces[1], 'periodic', IdentificationType.PERIODIC, rot)
# ↑ Glue() の前に実行

geo_obj  = Glue([inner_sec, outer_sec])
geo      = OCCGeometry(geo_obj)
mesh_sec = Mesh(geo.GenerateMesh(maxh=0.2))
```

## DOF 削減の確認

```python
pairs = mesh_sec.GetPeriodicNodePairs(VERTEX)
print(f'周期頂点対数: {len(list(pairs))}')   # 0 なら Identify 失敗

fes_plain = H1(mesh_sec, order=2, dirichlet='dirichlet_outer')
fes_per   = Periodic(H1(mesh_sec, order=2, dirichlet='dirichlet_outer'))

free_plain = sum(fes_plain.FreeDofs())
free_per   = sum(fes_per.FreeDofs())

print(f'ndof (変化なし): {fes_plain.ndof}')
print(f'FreeDofs 前: {free_plain}')
print(f'FreeDofs 後: {free_per}  (削減: {free_plain - free_per})')
# 例: 12022 → 10555 (1467 DOF 削減, ~12%)
```

**注意**: `ndof` は同じまま、`FreeDofs()` が減る。
周期スレーブ DOF は拘束扱いとなり線形系から除外される。

## Identify が失敗する典型的な原因

| 現象 | 原因 | 対処 |
|------|------|------|
| 周期頂点対数 = 0 | Glue 後の face オブジェクトに対して Identify | Glue 前に呼び出す |
| 周期頂点対数 > 0 でも FreeDofs 変化なし | Rotation の方向が逆 | `dphi` の符号を確認 |
| NrIdentifications = 0 | WorkPlane.Arc で作った扇形 (幾何的に一致しない) | HalfSpace を使用 |

## 確認済み数値 (NGSolve 6.2.2601, 1/6 セクタ, maxh=0.2)

| 項目 | 値 |
|------|----|
| 要素数 | 2,738 |
| 節点数 | 781 |
| 周期頂点対数 | 198 |
| FreeDofs (Periodic なし) | 12,022 |
| FreeDofs (Periodic あり) | 10,555 |
| 削減 DOF 数 | 1,467 (12.2%) |
| セクタ中央 最大誤差 | < 1.5% (maxh=0.2) / < 1% (maxh=0.1) |
"""

KELVIN_TIPS = """
# Kelvin Transformation: Tips and Pitfalls

## Common Mistakes

1. **Forgetting material modulation in exterior domain**
   - **Direct quantities** (mu, eps, sigma): diverge at r'=0
       mu = (R/rho')^2 * mu_0
   - **Reciprocal quantities** (nu, rho_e): vanish at r'=0
       nu = (rho'/R)^2 * nu_0
   - Use mu modulation for H1/Omega (scalar potential)
   - Use nu modulation for HCurl A-formulation
   - The PDE itself is unchanged -- only the material is distorted

2. **Wrong sign on background field modulation**
   - The Kelvin BC at r'=R requires: H'(R) = -H(R) (sign flip)
   - For uniform dipole field: sign flip needed (interior positive -> exterior negative)
   - For quadrupole H_s=(-z,0,-x): NO explicit sign flip needed in code
     (interior already negative -> Kelvin negation makes it positive)
   - Rule: the physical transformed field is H'_i = -(R/r')^2 * H_i(R^2/r')

3. **Missing GND point**
   - **H1 (phi, Omega)**: Without GND, solution is non-unique. Essential.
   - **HCurl (A)**: Gauge regularization provides uniqueness. GND is optional
     but improves iterative solver convergence.
   - Place vertex at center of exterior sphere (maps to physical infinity).
   - Cubit: `create vertex X {offset} Y 0 Z 0; nodeset N name "GND"`

4. **Boundary terms in linear form**
   - With Kelvin + Periodic BC, boundary terms CANCEL
   - Only volume integral remains: f(v) = int(mu * grad(v) . Hs) dx
   - Adding boundary terms leads to wrong results

5. **Domain offset too small**
   - Interior and exterior domains must NOT overlap in mesh
   - offset_x should be >= 2 * kelvin_radius

6. **Face identification order**
   - Identify interior outer face WITH exterior outer face
   - Order matters for orientation of periodic coupling

7. **HCurl without nograds=True**
   - HCurl basis functions include gradients of H1 basis which form the
     curl-curl kernel (curl(grad phi) = 0 = gauge freedom)
   - Use `HCurl(mesh, order=p, complex=..., nograds=True, dirichlet=...)`
     at ANY polynomial order p (including p=1).
   - Reference: NGSolve Maxwell tutorial unit-2.4
     `HCurl(mesh, order=3, dirichlet="outer", nograds=True)`
   - Without nograds, the curl-curl system is rank deficient by the
     gradient subspace dimension. PARDISO pseudo-inverses and returns a
     solution polluted by an arbitrary gradient field; inductance or
     magnetic energy values are then order-dependent and unreliable.

8. **Cubit coil: sweep, NOT webcut**
   - `create torus + webcut + delete` can silently produce a half-coil
     (BEM = 46 nH instead of 87 nH for R=30mm/a=3mm/gap=5 deg)
   - `webcut` also breaks p-convergence of curved surface elements
   - Correct: build a disk cross section and sweep about the axis:
     `create curve arc ... normal 0 1 0 full;
      create surface curve 1;
      sweep surface 1 axis 0 0 0 0 0 1 angle 355`
   - Verified p-convergence O1 → O5: -3.35% → -1.8e-05%

## Performance Tips

- Use `Preconditioner(a, type="local")` for small-medium problems
- Use `Preconditioner(a, type="multigrid")` for large problems
- Kelvin domain typically needs FEWER elements than interior
- Higher polynomial order (3-4) is more efficient than h-refinement

## When to Use Kelvin

| Problem Type | Kelvin? | Alternative |
|-------------|---------|-------------|
| Permanent magnet stray field | Yes | Truncation with large air box |
| Coil field in free space | Yes | Biot-Savart (analytical) |
| Soft iron in external field | Yes | Infinite element methods |
| Enclosed cavity | No | Standard FEM (bounded domain) |
| Waveguide (1D open) | No | PML (absorbing boundary) |
"""


KELVIN_ROBUSTNESS = """
# Kelvin Robustness Checklist (2026-04-14)

## POLICY: Kelvin Only -- No Dirichlet Truncation

Use Kelvin transformation for ALL FEM open boundary problems.
Do NOT use large Dirichlet truncation spheres. Kelvin provides exact
open boundary with zero truncation error. Dirichlet truncation introduces
uncontrolled error that depends on sphere size and cannot be bounded.

## Checklist: Steps That MUST Succeed

### 1. Mesh Copy (Interior -> Exterior Sphere)

Both sphere surfaces must have **identical mesh topology** (1:1 node
correspondence). Without this, Periodic BC cannot pair DOFs.

**OCC workflow**: `Identify()` before `GenerateMesh()` handles this
automatically. Netgen matches identified surfaces during mesh generation.

**Cubit workflow**: `copy mesh surface` is MANDATORY:
```python
# After meshing interior air volumes (which creates their surface mesh):
copy mesh surface <interior_hemi> onto surface <exterior_hemi> \\
    source curve <ic> source vertex <iv> \\
    target curve <ec> target vertex <ev>
```
Do NOT set volume size on the exterior Kelvin volumes after copy
(this adds extra nodes and breaks the 1:1 correspondence).

**Verification**:
```python
# After export, check vertex counts
kelvin_int_verts = set()
kelvin_ext_verts = set()
for el in mesh.Elements(BND):
    bnd = mesh.GetBoundaries()[el.index]
    for v in el.vertices:
        if "kelvin_int" in bnd: kelvin_int_verts.add(v.nr)
        elif "kelvin_ext" in bnd: kelvin_ext_verts.add(v.nr)
assert len(kelvin_int_verts) == len(kelvin_ext_verts), \\
    f"Mesh copy failed: {len(kelvin_int_verts)} int vs {len(kelvin_ext_verts)} ext"
```

### 2. Exterior Sphere Must Be Meshed

The exterior (Kelvin) sphere is a real computational domain -- it must
contain volume elements with material "kelvin". It is NOT just a boundary.

**Common mistake**: creating the exterior sphere but forgetting to mesh it
or forgetting to assign it to a block.

```python
# Cubit: exterior sphere MUST be meshed
volume {kelvin_top} {kelvin_bot} scheme tetmesh
mesh volume {kelvin_top} {kelvin_bot}

block N add volume {kelvin_top} {kelvin_bot}
block N name "kelvin"
```

### 3. Material Scaling in Kelvin Domain

Kelvin transformation **only distorts material properties** -- the PDE is
unchanged. The image of physical infinity is at r'=0 (Kelvin sphere center).

| Quantity | Physical (r→inf) | Kelvin (r'→0) | Modulation |
|----------|-----------------|---------------|------------|
| mu       | mu_0            | **infinity**  | mu = (R/r')^2 * mu_0 |
| eps      | eps_0           | **infinity**  | eps = (R/r')^2 * eps_0 |
| sigma    | 0 (air)         | 0             | sigma = (R/r')^2 * sigma (0 for air) |
| **nu = 1/mu** | nu_0      | **0**         | **nu = (r'/R)^2 * nu_0** |
| rho_e = 1/sigma | inf     | inf           | rho_e = (r'/R)^2 * rho_e |

**Implementation**:
```python
# HCurl A-formulation: uses nu (not mu)
for m in mesh.GetMaterials():
    if "kelvin" in m.lower():
        rp_sq = (x-kx)**2 + (y-ky)**2 + (z-kz)**2 + 1e-20
        nu_dict[m] = NU_0 * rp_sq / R**2   # -> 0 at r'=0
    else:
        nu_dict[m] = NU_0
```

**The 1e-20 epsilon prevents division by zero but is NOT a hack**:
at r'=0 exactly, nu=0 (correct), and the 1e-20 ensures no NaN.
The gauge regularization `reg * NU_0 * u * v * dx` in the bilinear form
provides the missing mass term where nu vanishes.

**IMPORTANT for gauge regularization with Kelvin**:
Do NOT apply `reg * NU_0 * u * v * dx` in the Kelvin domain -- the
nu_cf = (r'/R)^2 * nu0 vanishes near r'=0, so a constant NU_0 mass
term would dominate and corrupt the magnetic energy integral there.
Restrict regularization to non-kelvin materials:
```python
non_kelvin_mats = [m for m in materials if "kelvin" not in m.lower()]
if non_kelvin_mats:
    a += reg * NU_0 * u * v * dx("|".join(non_kelvin_mats))
```

### 4. kelvin_int / kelvin_ext Identification

The periodic identification pairs must be embedded in the .vol file.
Without it, the Kelvin sphere is just a disconnected air domain with
Neumann BC (silently wrong, looks like a small Dirichlet truncation).

**OCC**: Call `Identify()` before `GenerateMesh()`:
```python
int_face.Identify(ext_face, "kelvin", IdentificationType.PERIODIC)
```

**Cubit**: The C++ exporter (`radia_export netgen`) reads sideset names
"kelvin_int" and "kelvin_ext", computes the translation offset, and writes
`ident.Add()` pairs to the .vol automatically.

**Detection in calc_fem_kelvin.py**:
```python
n_ident = mesh.ngmesh.GetNrIdentifications()
if n_ident == 0:
    raise RuntimeError("Kelvin without periodic identification!")
```

### 5. FreeDofs Decrease After Periodic()

This is the **definitive verification** that periodic identification is
working. If FreeDofs does not decrease, the identification failed silently.

```python
base_fes = HCurl(mesh, order=1, complex=True, nograds=True, dirichlet="GND")
n_before = sum(1 for d in base_fes.FreeDofs() if d)

fes = Periodic(base_fes)
n_after = sum(1 for d in fes.FreeDofs() if d)

n_coupled = n_before - n_after
print(f"FreeDofs: {n_before} -> {n_after} (coupled: {n_coupled})")
if n_coupled == 0:
    raise RuntimeError(
        "Periodic BC NOT working! FreeDofs unchanged. "
        "Check: (1) Identify() before GenerateMesh/Glue, "
        "(2) sideset names kelvin_int/kelvin_ext in .jou, "
        "(3) radia_export netgen wrote identification pairs.")
```

Typical: ~2-5% of DOFs are coupled (boundary DOFs on the Kelvin spheres).
Example: ndof=49244, FreeDofs: 49244 -> 48440 (804 coupled).

### 6. Symmetry Models: 1/2, 1/4, 1/8

Kelvin + symmetry = periodic wedge + Kelvin open boundary.

**1/2 model** (one symmetry plane, e.g., z=0):
- Webcut interior AND exterior spheres with the symmetry plane
- Symmetry BC (Neumann for A_n=0, Dirichlet for A_t=0)
- Kelvin identification only between matching hemispheres

**1/4 model** (two symmetry planes):
- Webcut with both planes
- HalfSpace intersection for clean wedge geometry
- Identify BEFORE Glue (critical for OCC)

**1/8 model** (three symmetry planes):
- Use HalfSpace intersection to create octant
- Same Kelvin principles apply

**Critical**: the symmetry planes must cut BOTH interior and exterior
spheres identically. The mesh copy must respect the symmetry boundary.

**Example (1/2 model with z-symmetry)**:
```python
# In Cubit .jou:
webcut volume {air_vid} with plane zplane
webcut volume {kelvin_vid} with plane zplane
# Keep only z>0 halves for mesh copy + identification
# Apply symmetry BC (Neumann or Dirichlet) on z=0 faces
```

### 7. GND at Infinity

The vertex at the exterior sphere center maps to physical infinity.

| Formulation | GND requirement |
|-------------|----------------|
| **H1 (phi, Omega)** | **Essential** -- uniqueness of scalar potential |
| **HCurl (A)** | Optional -- gauge `reg * nu * u * v * dx` suffices |
| **HCurl + iterative solver** | Recommended -- improves convergence |
| **HCurl + PARDISO** | Optional -- PARDISO handles near-singular |

**Implementation**:
```python
# In Cubit .jou:
create vertex X {kelvin_offset_x} Y 0 Z 0
nodeset 100 add vertex {last_vertex_id}
nodeset 100 name "GND"

# In calc_fem_kelvin.py:
if "GND" in boundaries:
    dirichlet_bnd = "GND"  # A(infinity) = 0
```

**For OCC workflow**:
```python
gnd = Vertex(Pnt(kelvin_offset, 0, 0))
gnd.name = "GND"
# Include in Glue
shape = Glue([air, torus, ext_sphere, gnd])
```

### 8. Kelvin Domain: Tet Only (No Hex)

**POLICY**: Kelvin domain must use **tetrahedral** mesh, not hexahedral.

Spherical geometry is best approximated by triangular high-order elements.
Hex elements on a sphere surface introduce systematic geometry error that
worsens with mesh refinement (opposite of convergence).

- OCC workflow: always produces tets (correct by default)
- Cubit workflow: use `scheme tetmesh` for Kelvin volumes
- Do NOT use hex sweep or mapped mesh on the Kelvin sphere

This is why the Kelvin sphere is always a Netgen/OCC tet mesh, even when
the physical domain (coil, iron yoke) uses Cubit hex mesh.

## Diagnostic Summary

| Check | Expected | If Wrong |
|-------|----------|----------|
| Interior/exterior vertex count | Equal | Mesh copy failed |
| kelvin material in mesh | Present | Exterior sphere not meshed/blocked |
| nu at r'=0 | 0 | Wrong material scaling (mu not nu) |
| NrIdentifications > 0 | True | No periodic ID in .vol |
| FreeDofs decrease | Yes (2-5%) | Identification failed silently |
| L vs analytical | < 5% | Check all above + mesh size |
| Iterative solver converges | Yes | Check GND, reg, nograds |

## Validated Results (2026-04-14)

| Test case | L [nH] | Analytical | Error | Configuration |
|-----------|--------|------------|-------|---------------|
| Torus R=30mm a=3mm 5deg gap (3D) | 90.71 | 88.5 | +2.5% | Kelvin, Cu 50kHz, hole SIBC |
| Torus (2D axisym) | ~89 | 88.5 | <1% | Kelvin, static |
| C-magnet york.jou (3D) | 80.46 | -- | -- | Kelvin, 7kHz, mesh copy |
"""


def get_kelvin_documentation(topic: str = "all") -> str:
    """Return Kelvin transformation documentation by topic."""
    topics = {
        "overview": KELVIN_OVERVIEW,
        "h_formulation": KELVIN_H_FORMULATION,
        "a_formulation": KELVIN_A_FORMULATION,
        "3d": KELVIN_3D,
        "hcurl_3d": KELVIN_HCURL_3D,
        "adaptive": KELVIN_ADAPTIVE,
        "identify": KELVIN_IDENTIFY,
        "tips": KELVIN_TIPS,
        "verification": KELVIN_VERIFICATION,
        "periodic_wedge": KELVIN_PERIODIC_WEDGE,
        "robustness": KELVIN_ROBUSTNESS,
    }

    topic = topic.lower().strip()
    if topic == "all":
        return "\n\n".join(topics.values())
    elif topic in topics:
        return topics[topic]
    else:
        return (
            f"Unknown topic: '{topic}'. "
            f"Available: all, {', '.join(topics.keys())}"
        )
