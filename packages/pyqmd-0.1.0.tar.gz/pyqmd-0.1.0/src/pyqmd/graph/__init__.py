"""GraphRAG integration for pyqmd."""
