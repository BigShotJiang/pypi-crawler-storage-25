"""Recipe system: curated knowledge bundles.

Recipes are collections of knowledge items that can be searched, inspected,
and installed into a project's knowledge store.

Sources:
  - Presets: built-in recipes shipped with sidecar
  - Extracted: generated from scanning a project
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

import yaml

from .knowledge import learn, require_sidecar_dir


@dataclass
class Recipe:
    name: str
    description: str = ""
    version: str = "1.0"
    items: list[dict] = field(default_factory=list)
    source: str = "preset"  # "preset", "extracted"
    stack: str = ""


def load_preset_index() -> list[Recipe]:
    """Load built-in preset recipes from recipes/ directory."""
    recipes_dir = Path(__file__).parent / "recipes"
    if not recipes_dir.exists():
        return []

    recipes: list[Recipe] = []
    for f in sorted(recipes_dir.glob("*.yaml")):
        try:
            data = yaml.safe_load(f.read_text()) or {}
            recipes.append(
                Recipe(
                    name=data.get("name", f.stem),
                    description=data.get("description", ""),
                    version=data.get("version", "1.0"),
                    items=data.get("items", []),
                    source="preset",
                    stack=data.get("stack", ""),
                )
            )
        except (yaml.YAMLError, OSError):
            continue

    return recipes


def search_recipes(query: str, index: list[Recipe] | None = None) -> list[Recipe]:
    """Search available recipes by name/stack/description."""
    if index is None:
        index = load_preset_index()

    query_lower = query.lower()
    results = []
    for recipe in index:
        if (
            query_lower in recipe.name.lower()
            or query_lower in recipe.description.lower()
            or query_lower in recipe.stack.lower()
        ):
            results.append(recipe)

    return results


def inspect_recipe(recipe: Recipe) -> str:
    """Format recipe contents for preview."""
    lines = [
        f"Name: {recipe.name}",
        f"Description: {recipe.description}",
        f"Version: {recipe.version}",
        f"Stack: {recipe.stack}",
        f"Items: {len(recipe.items)}",
        f"Source: {recipe.source}",
        "",
        "Contents:",
    ]

    for item in recipe.items:
        item_type = item.get("type", "decision")
        content = item.get("content", "")
        domain = item.get("domain", "")
        domain_str = f" [{domain}]" if domain else ""
        lines.append(f"  [{item_type}]{domain_str} {content}")

    return "\n".join(lines)


def install_recipe(
    recipe: Recipe,
    sidecar_dir: Path | None = None,
) -> int:
    """Install recipe items into knowledge store. Returns count created."""
    sdir = sidecar_dir or require_sidecar_dir()

    created = 0
    for item_data in recipe.items:
        content = item_data.get("content", "")
        if not content or not content.strip():
            continue

        try:
            item = learn(
                content,
                type=item_data.get("type", "decision"),
                domain=item_data.get("domain"),
                tags=item_data.get("tags"),
                min_phase=item_data.get("min_phase"),
                source=f"recipe:{recipe.name}",
                sidecar_dir=sdir,
            )
        except ValueError:
            continue

        # learn() returns existing item if duplicate — check if it's new
        if item.source == f"recipe:{recipe.name}":
            created += 1

    # Track installed recipe in config
    _record_installation(sdir, recipe, created)

    return created


def _record_installation(sdir: Path, recipe: Recipe, item_count: int) -> None:
    """Record recipe installation in config.yaml."""
    from datetime import UTC, datetime

    config_path = sdir / "config.yaml"
    config = {}
    if config_path.exists():
        config = yaml.safe_load(config_path.read_text()) or {}

    if "installed_recipes" not in config:
        config["installed_recipes"] = []

    # Remove existing entry for same recipe
    config["installed_recipes"] = [
        r for r in config["installed_recipes"] if r.get("name") != recipe.name
    ]

    config["installed_recipes"].append(
        {
            "name": recipe.name,
            "version": recipe.version,
            "installed_at": datetime.now(UTC).isoformat(),
            "item_count": item_count,
        }
    )

    config_path.write_text(yaml.dump(config, default_flow_style=False))


def list_installed(sidecar_dir: Path | None = None) -> list[dict]:
    """List installed recipes from config."""
    sdir = sidecar_dir or require_sidecar_dir()
    config_path = sdir / "config.yaml"
    if not config_path.exists():
        return []

    config = yaml.safe_load(config_path.read_text()) or {}
    return config.get("installed_recipes", [])


def extract_recipe(
    project_dir: Path,
    sidecar_dir: Path | None = None,
) -> Recipe:
    """Extract a recipe from a project's existing knowledge."""
    sdir = sidecar_dir or require_sidecar_dir()

    from .db import get_db, query_knowledge

    conn = get_db(sdir / "db.sqlite")
    items = query_knowledge(conn)
    conn.close()

    recipe_items = []
    for item in items:
        recipe_items.append(
            {
                "content": item.content,
                "type": item.type,
                "domain": item.domain,
                "tags": item.tags,
            }
        )

    config_path = sdir / "config.yaml"
    project_name = ""
    if config_path.exists():
        config = yaml.safe_load(config_path.read_text()) or {}
        project_name = config.get("project_name", project_dir.name)

    return Recipe(
        name=project_name or project_dir.name,
        description=f"Extracted from {project_name or project_dir.name}",
        items=recipe_items,
        source="extracted",
    )
