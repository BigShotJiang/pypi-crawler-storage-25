---
name: sidecar
description: Query project memory for decisions, constraints, relationships, and lessons. Use when starting a new task, when unsure about architectural choices, or when modifying components with known dependencies.
---

# Sidecar: Project Memory

Sidecar provides persistent project knowledge that survives across sessions and tools.

## Available Commands

### Get a context brief before starting work
```bash
sidecar brief "<task description>"
```
Returns relevant decisions, constraints, relationships, and lessons for your task.

### Search project knowledge
```bash
sidecar recall "<query>"
sidecar recall --type constraint "<query>"
```
Search for specific knowledge by topic or type.

### Record a decision or lesson
```bash
sidecar learn "<knowledge>"
sidecar learn --constraint "<rule>"
sidecar learn --lesson "<what went wrong>"
sidecar learn --relationship "<what connects to what>"
```

### End-of-session capture
```bash
sidecar reflect --summary "<what you did>" --decision "<choice made>" --lesson "<what you learned>"
sidecar reflect --auto
```

### Check knowledge store
```bash
sidecar status
```

## When to Use

- **Starting a task**: Run `sidecar brief` to get relevant context
- **Making an architectural decision**: Record it with `sidecar learn`
- **Something went wrong**: Capture the lesson with `sidecar learn --lesson`
- **Ending a session**: Run `sidecar reflect` to preserve context for next time
- **Unsure about constraints**: Run `sidecar recall --type constraint`
