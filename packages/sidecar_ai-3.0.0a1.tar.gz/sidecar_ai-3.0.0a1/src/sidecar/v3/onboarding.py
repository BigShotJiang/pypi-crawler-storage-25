"""Project onboarding: auto-discover and import project knowledge.

Scans for importable files (README, CLAUDE.md, ADRs), extracts constraints
from config files (pyproject.toml, .eslintrc, tsconfig.json), detects tech
stack, and creates knowledge items with confirmation.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from pathlib import Path

try:
    import tomllib
except ModuleNotFoundError:  # Python < 3.11
    tomllib = None  # type: ignore[assignment]


@dataclass
class OnboardingFinding:
    """A single finding from the onboarding scan."""

    source: str
    category: str  # "importable_file", "config_constraint", "tech_stack"
    items: list[dict] = field(default_factory=list)
    description: str = ""


def scan_project(project_dir: Path) -> list[OnboardingFinding]:
    """Scan a project directory for importable knowledge. Non-destructive."""
    findings: list[OnboardingFinding] = []
    findings.extend(_discover_importable_files(project_dir))
    findings.extend(_discover_doc_directories(project_dir))
    findings.extend(_extract_config_constraints(project_dir))
    findings.extend(_detect_tech_stack(project_dir))
    findings = [f for f in findings if f.items]

    # B25: Cross-reference README claims against manifest files
    manifest = _load_manifest_versions(project_dir)
    if manifest:
        _cross_reference_findings(findings, manifest)

    return findings


def apply_findings(
    findings: list[OnboardingFinding],
    sidecar_dir: Path,
) -> int:
    """Import findings into the knowledge store. Returns count of items created."""
    from .knowledge import learn

    created = 0
    for finding in findings:
        for item_data in finding.items:
            try:
                learn(
                    item_data["content"],
                    type=item_data.get("type", "decision"),
                    tags=item_data.get("tags"),
                    domain=item_data.get("domain"),
                    source=f"onboard:{finding.source}",
                    sidecar_dir=sidecar_dir,
                )
                created += 1
            except (ValueError, FileNotFoundError):
                continue
    return created


# ── File Discovery ───────────────────────────────────────────────────────


_IMPORTABLE_FILES = [
    ("README.md", "decision"),
    ("README.rst", "decision"),
    ("CLAUDE.md", "constraint"),
    (".claude/CLAUDE.md", "constraint"),
    ("ARCHITECTURE.md", "decision"),
    ("CONTRIBUTING.md", "constraint"),
]

_IMPORTABLE_DIRS = [
    ("docs/adr", "decision"),
    ("docs/adrs", "decision"),
    ("doc/adr", "decision"),
    ("adr", "decision"),
]


def _discover_importable_files(project_dir: Path) -> list[OnboardingFinding]:
    """Find importable markdown files and directories."""
    findings: list[OnboardingFinding] = []

    for rel_path, ktype in _IMPORTABLE_FILES:
        path = project_dir / rel_path
        if path.exists() and path.is_file():
            # Dry-parse without importing (just extract items)
            items = _dry_parse_file(path, ktype)
            if items:
                findings.append(
                    OnboardingFinding(
                        source=rel_path,
                        category="importable_file",
                        items=items,
                        description=f"Found {rel_path} ({len(items)} items)",
                    )
                )

    for rel_dir, ktype in _IMPORTABLE_DIRS:
        dir_path = project_dir / rel_dir
        if dir_path.exists() and dir_path.is_dir():
            md_files = list(dir_path.glob("*.md"))
            if md_files:
                all_items = []
                for f in md_files:
                    all_items.extend(_dry_parse_file(f, ktype))
                if all_items:
                    findings.append(
                        OnboardingFinding(
                            source=rel_dir,
                            category="importable_file",
                            items=all_items,
                            description=f"Found {len(md_files)} ADRs in {rel_dir}/ ({len(all_items)} items)",
                        )
                    )

    return findings


# ── B26: Non-standard doc directory discovery ──────────────────────────

# Directories to skip during discovery (build artifacts, deps, etc.)
_SKIP_DIRS = {
    "node_modules",
    ".git",
    ".sidecar",
    "__pycache__",
    ".venv",
    "venv",
    "env",
    ".env",
    "dist",
    "build",
    ".next",
    ".nuxt",
    "coverage",
    "htmlcov",
    ".pytest_cache",
    ".mypy_cache",
    ".ruff_cache",
    ".tox",
    "vendor",
    "target",
    "out",
    ".turbo",
}

# Standard dirs already checked by _discover_importable_files
_STANDARD_DIRS = {"docs/adr", "docs/adrs", "doc/adr", "adr"}

# Minimum markdown files to consider a directory a doc source
_MIN_MD_FILES = 3


def _discover_doc_directories(project_dir: Path) -> list[OnboardingFinding]:
    """B26: Discover non-standard doc directories with 3+ markdown files.

    Scans up to 2 levels deep for directories like .agent/, docs/architecture/,
    etc. that contain significant markdown documentation.
    """
    findings: list[OnboardingFinding] = []
    already_found: set[str] = set()

    # Collect dirs already handled by standard discovery
    for rel_dir, _ in _IMPORTABLE_DIRS:
        already_found.add(rel_dir)

    # Scan top-level and one level deep
    for depth_dir in [project_dir, *project_dir.iterdir()]:
        if not depth_dir.is_dir():
            continue
        if depth_dir.name.startswith(".") and depth_dir != project_dir:
            # Check dotdirs at top level (e.g. .agent/) but not nested
            _check_doc_dir(depth_dir, project_dir, already_found, findings)
            continue
        if depth_dir == project_dir:
            continue
        if depth_dir.name in _SKIP_DIRS:
            continue

        # Check this directory itself
        _check_doc_dir(depth_dir, project_dir, already_found, findings)

        # Check one level deeper (e.g. docs/architecture/, docs/decisions/)
        try:
            for subdir in depth_dir.iterdir():
                if subdir.is_dir() and subdir.name not in _SKIP_DIRS:
                    _check_doc_dir(subdir, project_dir, already_found, findings)
        except PermissionError:
            continue

    return findings


# Directories that are likely low-value archives
_ARCHIVE_DIRS = {"archive", "archived", "old", "deprecated", "backup", "legacy"}

# Max items per discovered directory (prevents huge dirs from flooding)
_MAX_ITEMS_PER_DIR = 50


def _check_doc_dir(
    dir_path: Path,
    project_dir: Path,
    already_found: set[str],
    findings: list[OnboardingFinding],
) -> None:
    """Check if a directory qualifies as a doc source and add to findings."""
    rel = str(dir_path.relative_to(project_dir))
    if rel in already_found:
        return

    # Skip archive-type directories
    if dir_path.name.lower() in _ARCHIVE_DIRS:
        return

    md_files = [f for f in dir_path.glob("*.md") if f.is_file()]
    if len(md_files) < _MIN_MD_FILES:
        return

    already_found.add(rel)

    all_items: list[dict] = []
    for f in sorted(md_files):
        all_items.extend(_dry_parse_file(f, "decision"))
        # Early exit if we already have enough
        if len(all_items) >= _MAX_ITEMS_PER_DIR * 2:
            break

    if not all_items:
        return

    # Cap total items from this directory
    if len(all_items) > _MAX_ITEMS_PER_DIR:
        from .importer import KnowledgeItem, _score_item

        # Score and keep the best items
        scored = sorted(
            all_items,
            key=lambda d: _score_item(
                KnowledgeItem(
                    id="",
                    type=d.get("type", "decision"),
                    content=d["content"],
                    tags=d.get("tags", ""),
                    source="",
                )
            ),
            reverse=True,
        )
        all_items = scored[:_MAX_ITEMS_PER_DIR]

    findings.append(
        OnboardingFinding(
            source=rel,
            category="discovered_docs",
            items=all_items,
            description=f"Discovered {rel}/ with {len(md_files)} docs ({len(all_items)} items)",
        )
    )


def _dry_parse_file(path: Path, default_type: str) -> list[dict]:
    """Parse a file into item dicts without importing. For preview.

    Applies the same quality gate (per-file cap, low-signal filter) as the importer.
    """
    from .importer import (
        _cap_items,
        _looks_like_adr,
        _parse_adr,
        _parse_claude_md,
        _parse_generic_markdown,
        _parse_readme,
    )

    try:
        content = path.read_text()
    except (OSError, UnicodeDecodeError):
        return []

    # Skip sidecar-generated files
    if "Generated by sidecar compile" in content[:200]:
        return []

    name = path.name.lower()

    if "adr" in name or _looks_like_adr(content):
        items = _parse_adr(content, path.stem.lower())
    elif name in ("claude.md", "claude_md"):
        items = _parse_claude_md(content, path.stem.lower())
    elif name == "readme.md":
        items = _parse_readme(content, path.stem.lower())
    else:
        items = _parse_generic_markdown(content, path.stem.lower(), default_type)

    # Apply quality gate: cap items per file
    items = _cap_items(items)

    return [
        {
            "content": item.content,
            "type": item.type,
            "tags": item.tags,
        }
        for item in items
    ]


# ── Config Constraint Extraction ─────────────────────────────────────────


def _extract_config_constraints(project_dir: Path) -> list[OnboardingFinding]:
    """Extract constraints from project config files."""
    findings: list[OnboardingFinding] = []

    # pyproject.toml
    pyproject = project_dir / "pyproject.toml"
    if pyproject.exists() and tomllib is not None:
        items = _parse_pyproject(pyproject)
        if items:
            findings.append(
                OnboardingFinding(
                    source="pyproject.toml",
                    category="config_constraint",
                    items=items,
                    description=f"Extracted {len(items)} constraints from pyproject.toml",
                )
            )

    # package.json
    pkg_json = project_dir / "package.json"
    if pkg_json.exists():
        items = _parse_package_json(pkg_json)
        if items:
            findings.append(
                OnboardingFinding(
                    source="package.json",
                    category="config_constraint",
                    items=items,
                    description=f"Extracted {len(items)} constraints from package.json",
                )
            )

    # tsconfig.json
    tsconfig = project_dir / "tsconfig.json"
    if tsconfig.exists():
        items = _parse_tsconfig(tsconfig)
        if items:
            findings.append(
                OnboardingFinding(
                    source="tsconfig.json",
                    category="config_constraint",
                    items=items,
                    description=f"Extracted {len(items)} constraints from tsconfig.json",
                )
            )

    # Dockerfile
    dockerfile = project_dir / "Dockerfile"
    if dockerfile.exists():
        items = _parse_dockerfile(dockerfile)
        if items:
            findings.append(
                OnboardingFinding(
                    source="Dockerfile",
                    category="config_constraint",
                    items=items,
                    description=f"Extracted {len(items)} items from Dockerfile",
                )
            )

    return findings


def _parse_pyproject(path: Path) -> list[dict]:
    """Extract constraints from pyproject.toml."""
    items: list[dict] = []
    try:
        with open(path, "rb") as f:
            data = tomllib.load(f)
    except Exception:
        return items

    # Python version requirement
    project = data.get("project", {})
    requires_python = project.get("requires-python")
    if requires_python:
        items.append(
            {
                "content": f"Project requires Python {requires_python}",
                "type": "constraint",
                "tags": "python,version",
                "domain": "backend",
            }
        )

    # Ruff config
    ruff = data.get("tool", {}).get("ruff", {})
    if ruff:
        line_length = ruff.get("line-length")
        if line_length:
            items.append(
                {
                    "content": f"Line length limit: {line_length} characters (ruff)",
                    "type": "constraint",
                    "tags": "lint,style",
                    "domain": "backend",
                }
            )
        target = ruff.get("target-version")
        if target:
            items.append(
                {
                    "content": f"Ruff target version: {target}",
                    "type": "constraint",
                    "tags": "lint,python",
                    "domain": "backend",
                }
            )

    # Pytest config
    pytest_cfg = data.get("tool", {}).get("pytest", {}).get("ini_options", {})
    testpaths = pytest_cfg.get("testpaths")
    if testpaths:
        items.append(
            {
                "content": f"Tests located in: {', '.join(testpaths) if isinstance(testpaths, list) else testpaths}",
                "type": "decision",
                "tags": "testing",
                "domain": "testing",
            }
        )

    return items


def _parse_package_json(path: Path) -> list[dict]:
    """Extract constraints from package.json."""
    items: list[dict] = []
    try:
        data = json.loads(path.read_text())
    except (json.JSONDecodeError, OSError):
        return items

    # Node version
    engines = data.get("engines", {})
    if "node" in engines:
        items.append(
            {
                "content": f"Required Node.js version: {engines['node']}",
                "type": "constraint",
                "tags": "node,version",
                "domain": "frontend",
            }
        )

    # Key scripts
    scripts = data.get("scripts", {})
    for key in ("test", "lint", "build", "typecheck"):
        if key in scripts:
            items.append(
                {
                    "content": f"npm script '{key}': {scripts[key]}",
                    "type": "decision",
                    "tags": f"scripts,{key}",
                    "domain": "frontend" if key != "test" else "testing",
                }
            )

    # TypeScript dependency
    deps = {**data.get("dependencies", {}), **data.get("devDependencies", {})}
    if "typescript" in deps:
        items.append(
            {
                "content": f"TypeScript {deps['typescript']} is used",
                "type": "relationship",
                "tags": "typescript",
                "domain": "frontend",
            }
        )

    return items


def _parse_tsconfig(path: Path) -> list[dict]:
    """Extract constraints from tsconfig.json."""
    items: list[dict] = []
    try:
        # tsconfig can have comments, strip them
        text = re.sub(r"//.*$", "", path.read_text(), flags=re.M)
        data = json.loads(text)
    except (json.JSONDecodeError, OSError):
        return items

    compiler = data.get("compilerOptions", {})
    if compiler.get("strict"):
        items.append(
            {
                "content": "TypeScript strict mode is enabled",
                "type": "constraint",
                "tags": "typescript,strict",
                "domain": "frontend",
            }
        )
    target = compiler.get("target")
    if target:
        items.append(
            {
                "content": f"TypeScript compilation target: {target}",
                "type": "decision",
                "tags": "typescript",
                "domain": "frontend",
            }
        )

    return items


def _parse_dockerfile(path: Path) -> list[dict]:
    """Extract decisions from Dockerfile."""
    items: list[dict] = []
    try:
        content = path.read_text()
    except OSError:
        return items

    # Base image
    from_match = re.search(r"^FROM\s+(\S+)", content, re.M)
    if from_match:
        items.append(
            {
                "content": f"Docker base image: {from_match.group(1)}",
                "type": "decision",
                "tags": "docker,infrastructure",
                "domain": "devops",
            }
        )

    # Exposed ports
    ports = re.findall(r"^EXPOSE\s+(\d+)", content, re.M)
    if ports:
        items.append(
            {
                "content": f"Docker exposed ports: {', '.join(ports)}",
                "type": "relationship",
                "tags": "docker,ports",
                "domain": "devops",
            }
        )

    return items


# ── Tech Stack Detection ─────────────────────────────────────────────────


_STACK_SIGNALS: list[tuple[str, str, str]] = [
    ("pyproject.toml", "Python project (pyproject.toml)", "backend"),
    ("setup.py", "Python project (setup.py)", "backend"),
    ("package.json", "Node.js project (package.json)", "frontend"),
    ("tsconfig.json", "TypeScript project (tsconfig.json)", "frontend"),
    ("Dockerfile", "Docker containerized", "devops"),
    ("docker-compose.yml", "Docker Compose multi-service", "devops"),
    ("docker-compose.yaml", "Docker Compose multi-service", "devops"),
    ("Makefile", "Makefile build system", "backend"),
    (".github/workflows", "GitHub Actions CI/CD", "devops"),
    (".gitlab-ci.yml", "GitLab CI/CD", "devops"),
]


def _detect_tech_stack(project_dir: Path) -> list[OnboardingFinding]:
    """Detect tech stack and create relationship items."""
    items: list[dict] = []

    for rel_path, description, domain in _STACK_SIGNALS:
        path = project_dir / rel_path
        if path.exists():
            items.append(
                {
                    "content": f"Tech stack: {description}",
                    "type": "relationship",
                    "tags": "tech-stack",
                    "domain": domain,
                }
            )

    if not items:
        return []

    return [
        OnboardingFinding(
            source="file-scan",
            category="tech_stack",
            items=items,
            description=f"Detected {len(items)} tech stack signals",
        )
    ]


# ── B25: Cross-reference README claims ─────────────────────────────────

# Aspirational language that signals unreliable claims
_ASPIRATIONAL = re.compile(
    r"\b(planned|coming soon|will support|roadmap|future|upcoming|"
    r"in development|not yet|todo|experimental|alpha|beta|wip)\b",
    re.I,
)

# Version pattern: "Name version" or "Name vX.Y" — captures name and version
_VERSION_CLAIM = re.compile(
    r"\b(react|next\.?js|vue|angular|svelte|nuxt|node|python|typescript|"
    r"fastapi|flask|django|express|tailwind|prisma|drizzle)\s*"
    r"v?(\d+(?:\.\d+)*)\b",
    re.I,
)


def _load_manifest_versions(project_dir: Path) -> dict[str, str]:
    """Load actual dependency versions from manifest files.

    Returns dict of normalized name -> version string.
    """
    versions: dict[str, str] = {}

    # package.json
    pkg_json = project_dir / "package.json"
    if pkg_json.exists():
        try:
            data = json.loads(pkg_json.read_text())
            all_deps = {**data.get("dependencies", {}), **data.get("devDependencies", {})}
            # Normalize common package names
            name_map = {
                "next": "next.js",
                "react": "react",
                "vue": "vue",
                "@angular/core": "angular",
                "svelte": "svelte",
                "typescript": "typescript",
                "tailwindcss": "tailwind",
                "prisma": "prisma",
                "drizzle-orm": "drizzle",
                "express": "express",
                "fastify": "fastify",
            }
            for pkg_name, canonical in name_map.items():
                if pkg_name in all_deps:
                    ver = all_deps[pkg_name].lstrip("^~>=<")
                    versions[canonical] = ver
        except (json.JSONDecodeError, OSError):
            pass

    # pyproject.toml
    pyproject = project_dir / "pyproject.toml"
    if pyproject.exists() and tomllib is not None:
        try:
            with open(pyproject, "rb") as f:
                data = tomllib.load(f)
            requires_python = data.get("project", {}).get("requires-python", "")
            if requires_python:
                ver = requires_python.lstrip("^~>=<")
                versions["python"] = ver
        except Exception:
            pass

    return versions


def _cross_reference_findings(
    findings: list[OnboardingFinding],
    manifest: dict[str, str],
) -> None:
    """Cross-reference README findings against manifest versions.

    Modifies findings in-place:
    - Removes items with wrong version claims
    - Removes items with aspirational language
    - Adds warnings for corrected items
    """
    corrected: list[str] = []

    for finding in findings:
        if finding.category not in ("importable_file", "discovered_docs"):
            continue

        filtered_items: list[dict] = []
        for item in finding.items:
            content = item["content"]

            # Skip aspirational claims
            if _ASPIRATIONAL.search(content):
                corrected.append(f"Skipped aspirational: {content[:60]}...")
                continue

            # Check version claims against manifest
            version_ok = True
            for match in _VERSION_CLAIM.finditer(content):
                tech_name = match.group(1).lower()
                # Normalize: "next.js" / "nextjs" / "next" -> "next.js"
                if tech_name in ("next", "nextjs", "next.js"):
                    tech_name = "next.js"
                claimed_ver = match.group(2)
                actual_ver = manifest.get(tech_name)

                if actual_ver and not actual_ver.startswith(claimed_ver.split(".")[0]):
                    # Major version mismatch
                    corrected.append(
                        f"Wrong version: {tech_name} claimed {claimed_ver}, actual {actual_ver}"
                    )
                    version_ok = False

            if version_ok:
                filtered_items.append(item)

        finding.items = filtered_items
        if corrected:
            finding.description += f" ({len(corrected)} items filtered by cross-reference)"
