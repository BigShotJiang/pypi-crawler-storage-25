"""Brief generation: compile relevant knowledge into a targeted context package.

The brief is the premium output of sidecar — a natural language document
that gives an AI agent everything it needs to know for a specific task.
"""

from __future__ import annotations

from pathlib import Path

from .db import KnowledgeItem, get_db, query_knowledge
from .git_context import format_git_context, get_git_context
from .retrieval import search
from .sessions import get_last_session, read_primer


def generate_brief(
    task: str,
    *,
    sidecar_dir: Path,
    cwd: Path | None = None,
    top_k: int = 15,
) -> str:
    """Generate a targeted context brief for a task.

    Compiles: relevant knowledge (by type), session context, git context.
    Returns a natural language document.
    """
    conn = get_db(sidecar_dir / "db.sqlite")
    all_items = query_knowledge(conn)
    conn.close()

    # Search for relevant knowledge
    results = search(task, all_items, top_k=top_k, min_score=0.005)

    # Group by type
    by_type: dict[str, list[tuple[KnowledgeItem, float]]] = {}
    for item, score in results:
        by_type.setdefault(item.type, []).append((item, score))

    # Build brief sections
    sections: list[str] = []
    sections.append(f"BRIEF: {task}")
    sections.append("=" * (len(task) + 7))

    # Knowledge sections in priority order
    type_order = [
        ("decision", "DECISIONS that apply"),
        ("constraint", "CONSTRAINTS"),
        ("relationship", "RELATIONSHIPS"),
        ("lesson", "LESSONS (watch out for these)"),
    ]

    for ktype, header in type_order:
        items = by_type.get(ktype, [])
        if items:
            lines = [f"\n{header}:"]
            for item, _score in items:
                date = item.created_at[:10] if item.created_at else ""
                confidence = " (auto-captured)" if item.confidence < 1.0 else ""
                lines.append(f"  - {item.content}{confidence} ({date})")
            sections.append("\n".join(lines))

    # Session context
    last_session = get_last_session(sidecar_dir)
    if last_session and last_session.summary:
        session_lines = ["\nRECENT SESSION CONTEXT:"]
        date = last_session.ended_at[:10] if last_session.ended_at else "ongoing"
        session_lines.append(f"  Last session ({date}): {last_session.summary}")
        if last_session.files_touched:
            touched = last_session.files_touched[:5]
            session_lines.append(f"  Files touched: {', '.join(touched)}")
            if len(last_session.files_touched) > 5:
                session_lines.append(f"    ... and {len(last_session.files_touched) - 5} more")
        sections.append("\n".join(session_lines))

    # Primer context (previous session handoff)
    primer = read_primer(sidecar_dir)
    if primer and not last_session:
        # Only include primer if no session context (avoids duplication)
        sections.append(f"\nSESSION HANDOFF (from primer.md):\n{primer[:500]}")

    # Git context
    git_ctx = get_git_context(cwd)
    if git_ctx.is_repo:
        git_text = format_git_context(git_ctx)
        if git_text:
            sections.append(f"\nGIT CONTEXT:\n{git_text}")

    # No knowledge found
    if not results:
        sections.append(
            "\nNo specific knowledge found for this task. "
            "Use 'sidecar learn' to capture decisions, constraints, and lessons."
        )

    return "\n\n".join(sections)


def generate_brief_json(
    task: str,
    *,
    sidecar_dir: Path,
    cwd: Path | None = None,
    top_k: int = 15,
) -> dict:
    """Generate brief as structured data for programmatic consumption."""
    conn = get_db(sidecar_dir / "db.sqlite")
    all_items = query_knowledge(conn)
    conn.close()

    results = search(task, all_items, top_k=top_k, min_score=0.005)
    git_ctx = get_git_context(cwd)
    last_session = get_last_session(sidecar_dir)

    return {
        "task": task,
        "knowledge": [
            {
                "id": item.id,
                "type": item.type,
                "content": item.content,
                "tags": item.tags,
                "score": round(score, 4),
                "confidence": item.confidence,
            }
            for item, score in results
        ],
        "session": {
            "summary": last_session.summary if last_session else None,
            "files_touched": last_session.files_touched if last_session else [],
        },
        "git": {
            "branch": git_ctx.branch,
            "recent_commits": git_ctx.recent_commits[:5],
            "dirty_files": git_ctx.dirty_files[:10],
        },
    }
