"""Hybrid retrieval engine: semantic search + keyword fallback.

Semantic search uses sentence-transformers (optional, lazy-loaded).
Keyword fallback uses TF-IDF-style scoring with stdlib only.
"""

from __future__ import annotations

import math
import re
import struct
from collections import Counter

from .db import KnowledgeItem

# Lazy-loaded sentence-transformers model
_model = None
_model_load_attempted = False


def _get_embedding_model():
    """Lazy-load the sentence-transformers model. Returns None if unavailable."""
    global _model, _model_load_attempted
    if _model_load_attempted:
        return _model
    _model_load_attempted = True
    try:
        import logging
        import os

        # Suppress HuggingFace/sentence-transformers progress output
        os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
        logging.getLogger("sentence_transformers").setLevel(logging.WARNING)

        from sentence_transformers import SentenceTransformer

        _model = SentenceTransformer("all-MiniLM-L6-v2", device="cpu")
    except ImportError:
        _model = None
    return _model


def compute_embedding(text: str) -> bytes | None:
    """Compute embedding for text. Returns packed floats or None if no model."""
    model = _get_embedding_model()
    if model is None:
        return None
    vec = model.encode(text, normalize_embeddings=True, show_progress_bar=False)
    return struct.pack(f"{len(vec)}f", *vec)


def _unpack_embedding(blob: bytes) -> list[float]:
    """Unpack embedding bytes to float list."""
    n = len(blob) // 4
    return list(struct.unpack(f"{n}f", blob))


def _cosine_similarity(a: list[float], b: list[float]) -> float:
    """Cosine similarity between two vectors (assumed normalized)."""
    return sum(x * y for x, y in zip(a, b))


def _tokenize(text: str) -> list[str]:
    """Simple word tokenizer: lowercase, split on non-alphanumeric."""
    return re.findall(r"[a-z0-9]+", text.lower())


def _keyword_score(
    query_tokens: list[str],
    content_tokens: list[str],
    doc_freq: dict[str, int] | None = None,
    total_docs: int = 1,
) -> float:
    """TF-IDF keyword relevance score.

    Uses term frequency in content weighted by inverse document frequency
    across the corpus when doc_freq is provided, otherwise falls back to
    a length-normalized term match score.
    """
    if not query_tokens or not content_tokens:
        return 0.0

    content_counts = Counter(content_tokens)
    content_len = len(content_tokens)

    score = 0.0
    for token in query_tokens:
        tf = content_counts.get(token, 0) / content_len
        if doc_freq is not None:
            # Proper IDF: log(total_docs / docs_containing_term)
            df = doc_freq.get(token, 0)
            idf = math.log(1.0 + total_docs / (1.0 + df))
        else:
            # Fallback: simple presence weighting
            idf = 1.0 if content_counts.get(token, 0) > 0 else 0.0
        score += tf * idf

    # Normalize by query length
    return score / len(query_tokens)


def _tag_score(query_tokens: list[str], tags: str | None) -> float:
    """Score based on tag matches. Tags are high-signal, so matches score highly."""
    if not tags:
        return 0.0
    tag_tokens = set(_tokenize(tags))
    if not tag_tokens:
        return 0.0
    matches = sum(1 for t in query_tokens if t in tag_tokens)
    return matches / len(query_tokens)


def rank_items(
    query: str,
    items: list[KnowledgeItem],
    *,
    query_embedding: bytes | None = None,
) -> list[tuple[KnowledgeItem, float]]:
    """Rank knowledge items by relevance to query.

    Uses semantic similarity when embeddings are available,
    falls back to keyword + tag scoring otherwise.

    Returns items sorted by score descending, with scores.
    """
    if not items:
        return []

    query_tokens = _tokenize(query)
    has_semantic = query_embedding is not None
    query_vec = _unpack_embedding(query_embedding) if query_embedding else None

    # Compute corpus-level document frequencies for proper IDF
    all_token_sets = [set(_tokenize(item.content)) for item in items]
    doc_freq: dict[str, int] = Counter(token for token_set in all_token_sets for token in token_set)
    total_docs = len(items)

    scored: list[tuple[KnowledgeItem, float]] = []

    for item in items:
        # Keyword score (always computed)
        kw = _keyword_score(query_tokens, _tokenize(item.content), doc_freq, total_docs)

        # Tag score
        ts = _tag_score(query_tokens, item.tags)

        # Semantic score (if available)
        sem = 0.0
        if has_semantic and query_vec and item.embedding:
            item_vec = _unpack_embedding(item.embedding)
            sem = max(0.0, _cosine_similarity(query_vec, item_vec))

        # Combine scores
        if has_semantic and item.embedding:
            # When semantic is available: 55% semantic, 25% keyword, 20% tag
            score = 0.55 * sem + 0.25 * kw + 0.20 * ts
        else:
            # Keyword-only: 60% keyword, 40% tag
            score = 0.60 * kw + 0.40 * ts

        # Type boost: constraints and lessons are higher signal for task queries
        if item.type == "constraint":
            score *= 1.2
        elif item.type == "lesson":
            score *= 1.15

        # Confidence weight: soften penalty for imported items (0.7 → 0.85 effective)
        # Full confidence (1.0) = 1.0, imported (0.7) = 0.85, low (0.5) = 0.75
        score *= 0.5 + 0.5 * item.confidence

        if score > 0.0:
            scored.append((item, score))

    scored.sort(key=lambda x: x[1], reverse=True)
    return scored


def search(
    query: str,
    items: list[KnowledgeItem],
    *,
    top_k: int = 10,
    min_score: float = 0.01,
) -> list[tuple[KnowledgeItem, float]]:
    """Search knowledge items for a query. Returns top-k results above min_score."""
    query_embedding = compute_embedding(query)
    ranked = rank_items(query, items, query_embedding=query_embedding)
    return [(item, score) for item, score in ranked[:top_k] if score >= min_score]
