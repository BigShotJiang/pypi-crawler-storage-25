"""Knowledge operations: the core logic behind learn, recall, and init.

This module ties together db, retrieval, and mirror into coherent operations.
"""

from __future__ import annotations

import re
from pathlib import Path

import yaml

from .db import (
    KnowledgeItem,
    count_knowledge,
    find_duplicate,
    get_db,
    insert_knowledge,
    query_knowledge,
)
from .importer import import_file as _import_file_parsed
from .mirror import ensure_knowledge_dirs, write_mirror
from .retrieval import compute_embedding, search

VALID_TYPES = {"decision", "constraint", "relationship", "lesson"}

# Domain detection patterns — used by _extract_domains() and hooks.py
DOMAIN_PATTERNS: dict[str, list[str]] = {
    "frontend": [
        r"\b(react|vue|angular|svelte|css|scss|sass|html|dom|component|ui|ux|layout|tailwind|styled|browser|spa|responsive|next\.?js|page|form|modal|button|sidebar|header|footer|dashboard|widget)\b",
    ],
    "backend": [
        r"\b(server|api|endpoint|middleware|route|handler|controller|fastapi|flask|express|django|backend|back-end|server-side)\b",
    ],
    "database": [
        r"\b(sql|postgres|mysql|sqlite|redis|mongo|migration|schema|query|orm|index|table|database|db|datastore)\b",
    ],
    "testing": [
        r"\b(test|pytest|jest|mocha|unittest|coverage|fixture|mock|stub|assertion|testing|tdd|e2e|unit-test)\b",
    ],
    "security": [
        r"\b(auth|oauth|jwt|token|secret|password|credential|encryption|rbac|permission|security|vulnerability|xss|csrf|injection|sanitize)\b",
    ],
    "devops": [
        r"\b(docker|kubernetes|k8s|ci|cd|pipeline|deploy|terraform|aws|gcp|azure|devops|infrastructure|monitoring)\b",
    ],
    "mobile": [
        r"\b(ios|android|react-native|flutter|swift|kotlin|mobile|app-store)\b",
    ],
}
PHASES = ("prototype", "mvp", "production", "scale")
PHASE_ORDER = {phase: i for i, phase in enumerate(PHASES)}

DEFAULT_CONFIG = {
    "version": 3,
    "project_name": "",
    "auto_embed": True,
    "phase": "prototype",
}


def find_sidecar_dir(start: Path | None = None) -> Path | None:
    """Walk up from start to find the nearest .sidecar/ directory."""
    path = (start or Path.cwd()).resolve()
    for parent in [path, *path.parents]:
        candidate = parent / ".sidecar"
        if candidate.is_dir() and (candidate / "config.yaml").exists():
            return candidate
    return None


def require_sidecar_dir(start: Path | None = None) -> Path:
    """Find .sidecar/ or raise an error."""
    d = find_sidecar_dir(start)
    if d is None:
        raise FileNotFoundError("No .sidecar/ directory found. Run 'sidecar init' first.")
    return d


def init_project(
    project_dir: Path,
    project_name: str | None = None,
    import_files: list[Path] | None = None,
) -> Path:
    """Initialize sidecar for a project. Returns the .sidecar/ directory path."""
    sidecar_dir = project_dir / ".sidecar"
    sidecar_dir.mkdir(exist_ok=True)

    # Config
    config = DEFAULT_CONFIG.copy()
    config["project_name"] = project_name or project_dir.name
    config_path = sidecar_dir / "config.yaml"
    if not config_path.exists():
        config_path.write_text(yaml.dump(config, default_flow_style=False))

    # Database
    db_path = sidecar_dir / "db.sqlite"
    conn = get_db(db_path)
    conn.close()

    # Knowledge directories
    ensure_knowledge_dirs(sidecar_dir)

    # Import files if provided
    if import_files:
        conn = get_db(db_path)
        for f in import_files:
            if f.exists():
                _import_file(conn, sidecar_dir, f)
        conn.close()

    return sidecar_dir


def _import_file(conn, sidecar_dir: Path, file_path: Path) -> int:  # noqa: ARG001
    """Import knowledge from a markdown/text file. Returns count of items imported."""
    items = _import_file_parsed(file_path, sidecar_dir)
    return len(items)


def _extract_domains(content: str) -> str:
    """Auto-detect domains from content text. Returns comma-separated string."""
    found: set[str] = set()
    lower = content.lower()
    for domain, patterns in DOMAIN_PATTERNS.items():
        for pattern in patterns:
            if re.search(pattern, lower):
                found.add(domain)
                break
    return ",".join(sorted(found)) if found else ""


def _extract_tags(content: str) -> str:
    """Auto-extract tags from content text."""
    # Common technical terms that make good tags
    tech_patterns = [
        r"\b(api|auth|database|db|cache|redis|postgres|mysql|sqlite)\b",
        r"\b(frontend|backend|mobile|web|server|client)\b",
        r"\b(token|session|cookie|jwt|oauth)\b",
        r"\b(deploy|ci|cd|pipeline|docker|kubernetes|k8s)\b",
        r"\b(test|lint|format|build|compile)\b",
        r"\b(react|vue|angular|next|node|python|go|rust|typescript)\b",
        r"\b(stripe|aws|gcp|azure|cloudflare)\b",
        r"\b(security|performance|accessibility|a11y)\b",
    ]

    found: set[str] = set()
    lower = content.lower()
    for pattern in tech_patterns:
        matches = re.findall(pattern, lower)
        found.update(matches)

    return ",".join(sorted(found)) if found else ""


def learn(
    content: str,
    *,
    type: str = "decision",
    tags: str | None = None,
    domain: str | None = None,
    min_phase: str | None = None,
    source: str = "explicit",
    confidence: float = 1.0,
    sidecar_dir: Path | None = None,
) -> KnowledgeItem:
    """Store a piece of knowledge. Returns the created item."""
    content = content.strip()
    if len(content) < 5:
        raise ValueError("Content too short (minimum 5 characters).")

    if type not in VALID_TYPES:
        raise ValueError(f"Invalid type '{type}'. Must be one of: {', '.join(sorted(VALID_TYPES))}")

    sdir = sidecar_dir or require_sidecar_dir()

    # Auto-extract tags if not provided
    if tags is None:
        tags = _extract_tags(content)

    # Auto-detect domain if not provided
    if domain is None:
        domain = _extract_domains(content)

    item = KnowledgeItem(
        id="",
        type=type,
        content=content,
        tags=tags or None,
        domain=domain or None,
        min_phase=min_phase,
        source=source,
        confidence=confidence,
    )

    # Check for duplicates
    conn = get_db(sdir / "db.sqlite")
    existing = find_duplicate(conn, content, type_filter=type)
    if existing:
        conn.close()
        return existing

    # Compute embedding (returns None if sentence-transformers not available)
    item.embedding = compute_embedding(content)

    # Store in database
    insert_knowledge(conn, item)
    conn.close()

    # Mirror to markdown
    write_mirror(sdir, item)

    return item


def recall(
    query: str,
    *,
    type_filter: str | None = None,
    top_k: int = 10,
    sidecar_dir: Path | None = None,
) -> list[tuple[KnowledgeItem, float]]:
    """Retrieve relevant knowledge for a query. Returns items with scores."""
    sdir = sidecar_dir or require_sidecar_dir()

    conn = get_db(sdir / "db.sqlite")
    items = query_knowledge(conn, type_filter=type_filter)
    conn.close()

    if not items:
        return []

    return search(query, items, top_k=top_k)


def format_recall_results(results: list[tuple[KnowledgeItem, float]]) -> str:
    """Format recall results as natural language."""
    if not results:
        return "No relevant knowledge found."

    sections: dict[str, list[str]] = {}
    for item, _score in results:
        label = item.type.upper() + "S"
        if label not in sections:
            sections[label] = []
        date = item.created_at[:10] if item.created_at else "unknown"
        tags_str = f" [{item.tags}]" if item.tags else ""
        confidence_str = " (auto-captured)" if item.confidence < 1.0 else ""
        sections[label].append(f"  - {item.content}{tags_str}{confidence_str} ({date})")

    lines: list[str] = []
    # Order: decisions, constraints, relationships, lessons
    type_order = ["DECISIONS", "CONSTRAINTS", "RELATIONSHIPS", "LESSONS"]
    for type_label in type_order:
        if type_label in sections:
            lines.append(f"\n{type_label}:")
            lines.extend(sections[type_label])

    # Any other types
    for type_label, items in sections.items():
        if type_label not in type_order:
            lines.append(f"\n{type_label}:")
            lines.extend(items)

    return "\n".join(lines).strip()


VALID_MODES = {"active", "observe", "disabled"}


def get_mode(sidecar_dir: Path | None = None) -> str:
    """Read the current sidecar mode from config.yaml. Default: 'active'."""
    sdir = sidecar_dir or require_sidecar_dir()
    config_path = sdir / "config.yaml"
    if not config_path.exists():
        return "active"
    config = yaml.safe_load(config_path.read_text()) or {}
    return config.get("mode", "active")


def set_mode(mode: str, sidecar_dir: Path | None = None) -> None:
    """Set the sidecar mode in config.yaml."""
    if mode not in VALID_MODES:
        raise ValueError(f"Invalid mode '{mode}'. Must be one of: {', '.join(sorted(VALID_MODES))}")
    sdir = sidecar_dir or require_sidecar_dir()
    config_path = sdir / "config.yaml"
    config = {}
    if config_path.exists():
        config = yaml.safe_load(config_path.read_text()) or {}
    config["mode"] = mode
    config_path.write_text(yaml.dump(config, default_flow_style=False))


def get_dogfood(sidecar_dir: Path | None = None) -> bool:
    """Check if dogfood mode is enabled."""
    sdir = sidecar_dir or require_sidecar_dir()
    config_path = sdir / "config.yaml"
    if not config_path.exists():
        return False
    config = yaml.safe_load(config_path.read_text()) or {}
    return bool(config.get("dogfood", False))


def set_dogfood(enabled: bool, sidecar_dir: Path | None = None) -> None:
    """Enable or disable dogfood mode."""
    sdir = sidecar_dir or require_sidecar_dir()
    config_path = sdir / "config.yaml"
    config = {}
    if config_path.exists():
        config = yaml.safe_load(config_path.read_text()) or {}
    config["dogfood"] = enabled
    config_path.write_text(yaml.dump(config, default_flow_style=False))


def append_feedback(
    content: str,
    feedback_type: str = "observation",
    sidecar_dir: Path | None = None,
) -> Path:
    """Append a feedback entry to .sidecar/feedback.md. Returns the file path."""
    from datetime import UTC, datetime

    sdir = sidecar_dir or require_sidecar_dir()
    feedback_path = sdir / "feedback.md"

    if not feedback_path.exists():
        feedback_path.write_text("# Sidecar Feedback Log\n\n")

    timestamp = datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%S")
    entry = f"## {timestamp} [{feedback_type}]\n{content}\n\n"

    with open(feedback_path, "a") as f:
        f.write(entry)

    return feedback_path


def get_phase(sidecar_dir: Path | None = None) -> str:
    """Read the current project phase from config.yaml. Default: 'prototype'."""
    sdir = sidecar_dir or require_sidecar_dir()
    config_path = sdir / "config.yaml"
    if not config_path.exists():
        return "prototype"
    config = yaml.safe_load(config_path.read_text()) or {}
    return config.get("phase", "prototype")


def set_phase(phase: str, sidecar_dir: Path | None = None) -> None:
    """Set the project phase in config.yaml."""
    if phase not in PHASES:
        raise ValueError(f"Invalid phase '{phase}'. Must be one of: {', '.join(PHASES)}")
    sdir = sidecar_dir or require_sidecar_dir()
    config_path = sdir / "config.yaml"
    config = yaml.safe_load(config_path.read_text()) or {}
    config["phase"] = phase
    config_path.write_text(yaml.dump(config, default_flow_style=False))


def backfill_domains(sidecar_dir: Path | None = None) -> int:
    """Infer and set domains for items that have none. Returns count updated."""
    sdir = sidecar_dir or require_sidecar_dir()
    conn = get_db(sdir / "db.sqlite")
    items = query_knowledge(conn)
    updated = 0
    for item in items:
        if not item.domain:
            domain = _extract_domains(item.content)
            if not domain and item.tags:
                domain = _extract_domains(item.tags)
            if domain:
                conn.execute(
                    "UPDATE knowledge SET domain = ? WHERE id = ?",
                    (domain, item.id),
                )
                updated += 1
    conn.commit()
    conn.close()
    return updated


def get_stale_items(sidecar_dir: Path | None = None, *, days: int = 90) -> list[KnowledgeItem]:
    """Return active items older than `days` days."""
    sdir = sidecar_dir or require_sidecar_dir()
    conn = get_db(sdir / "db.sqlite")
    rows = conn.execute(
        "SELECT * FROM knowledge WHERE superseded_by IS NULL "
        f"AND created_at < datetime('now', '-{int(days)} days') "
        "ORDER BY created_at ASC"
    ).fetchall()
    conn.close()
    return [KnowledgeItem(**dict(row)) for row in rows]


def refresh_item(item_id: str, sidecar_dir: Path | None = None) -> bool:
    """Mark an item as re-validated by updating created_at to now."""
    from datetime import UTC, datetime

    sdir = sidecar_dir or require_sidecar_dir()
    conn = get_db(sdir / "db.sqlite")
    now = datetime.now(UTC).isoformat()
    cursor = conn.execute(
        "UPDATE knowledge SET created_at = ? WHERE id = ? AND superseded_by IS NULL",
        (now, item_id),
    )
    conn.commit()
    updated = cursor.rowcount > 0
    conn.close()
    return updated


def detect_conflicts(
    sidecar_dir: Path | None = None,
) -> list[tuple[KnowledgeItem, KnowledgeItem, str]]:
    """Find potentially conflicting knowledge items.

    Returns (item1, item2, reason) tuples. Conflict signals:
    - Same type + high keyword overlap + opposing sentiment
    - Contradictory verbs ("always" vs "never", "use" vs "don't use")
    - Different decisions about the same technology
    """
    sdir = sidecar_dir or require_sidecar_dir()
    conn = get_db(sdir / "db.sqlite")
    items = query_knowledge(conn)
    conn.close()

    if len(items) < 2:
        return []

    conflicts: list[tuple[KnowledgeItem, KnowledgeItem, str]] = []
    seen: set[tuple[str, str]] = set()

    for i, a in enumerate(items):
        for b in items[i + 1 :]:
            pair_key = (min(a.id, b.id), max(a.id, b.id))
            if pair_key in seen:
                continue

            reason = _check_conflict(a, b)
            if reason:
                seen.add(pair_key)
                conflicts.append((a, b, reason))

    return conflicts


def _check_conflict(a: KnowledgeItem, b: KnowledgeItem) -> str | None:
    """Check if two items conflict. Returns reason string or None.

    Strict matching to avoid false positives:
    - Opposing guidance: same type, same domain, high word overlap, opposing verbs
    - Competing decisions: same domain, "use X" vs "use Y" for same purpose
    """
    # Same type required — a constraint can't conflict with a relationship
    if a.type != b.type:
        return None

    # Same domain required (or both unset) — frontend can't conflict with backend
    a_domain = (a.domain or "").strip().lower()
    b_domain = (b.domain or "").strip().lower()
    if a_domain != b_domain:
        return None

    a_lower = a.content.lower()
    b_lower = b.content.lower()

    # Extract meaningful words (4+ chars to skip noise)
    stop = {
        "the",
        "and",
        "for",
        "use",
        "all",
        "with",
        "that",
        "this",
        "from",
        "not",
        "are",
        "was",
        "has",
        "have",
        "been",
        "will",
        "can",
        "should",
        "must",
        "does",
        "into",
        "when",
        "then",
        "also",
        "each",
        "every",
        "file",
        "code",
        "data",
        "type",
        "name",
        "item",
        "list",
        "check",
        "make",
        "need",
        "used",
        "using",
        "problem",
        "decision",
    }
    a_words = set(re.findall(r"\w{4,}", a_lower)) - stop
    b_words = set(re.findall(r"\w{4,}", b_lower)) - stop

    if not a_words or not b_words:
        return None

    overlap = a_words & b_words
    # Require substantial overlap — shared topic, not just incidental words
    overlap_ratio = len(overlap) / min(len(a_words), len(b_words)) if a_words and b_words else 0
    if overlap_ratio < 0.3 or len(overlap) < 3:
        return None

    # Check for opposing sentiment patterns — both items must be about same topic
    negation_pairs = [
        (r"\buse\b", r"\bdon'?t use\b"),
        (r"\buse\b", r"\bavoid\b"),
        (r"\balways\b", r"\bnever\b"),
        (r"\bmust\b", r"\bmust not\b"),
        (r"\brequired\b", r"\bforbidden\b"),
        (r"\benable\b", r"\bdisable\b"),
    ]

    for pos, neg in negation_pairs:
        if (re.search(pos, a_lower) and re.search(neg, b_lower)) or (
            re.search(neg, a_lower) and re.search(pos, b_lower)
        ):
            shared_topic = ", ".join(sorted(list(overlap)[:5]))
            return f"Opposing guidance on: {shared_topic}"

    # Check for competing tech choices — only within same domain and purpose
    if a.type == "decision":
        a_techs = _extract_tech_names(a_lower)
        b_techs = _extract_tech_names(b_lower)
        # Both must mention exactly 1-2 techs (clear "we chose X" items)
        if (
            a_techs
            and b_techs
            and not (a_techs & b_techs)
            and len(a_techs) <= 2
            and len(b_techs) <= 2
        ):
            # Must share significant non-tech topic words
            non_tech_overlap = overlap - a_techs - b_techs
            if len(non_tech_overlap) >= 3 and overlap_ratio >= 0.4:
                return (
                    f"Competing decisions: {', '.join(sorted(a_techs)[:2])} "
                    f"vs {', '.join(sorted(b_techs)[:2])}"
                )

    return None


def _extract_tech_names(text: str) -> set[str]:
    """Extract technology names from text."""
    tech_pattern = re.compile(
        r"\b(react|vue|angular|svelte|next|nuxt|fastapi|flask|django|express|"
        r"postgres|mysql|sqlite|redis|mongo|rabbitmq|kafka|"
        r"docker|kubernetes|terraform|"
        r"python|typescript|javascript|golang|rust|java|"
        r"jest|pytest|mocha|vitest|"
        r"tailwind|bootstrap|material|"
        r"graphql|rest|grpc|websocket|"
        r"aws|gcp|azure|cloudflare|vercel|netlify)\b"
    )
    return set(tech_pattern.findall(text))


def _quick_conflict_check(conn, item: KnowledgeItem) -> list[tuple[KnowledgeItem, str]]:
    """Lightweight conflict check for a new item against existing items.

    Called during learn() to flag potential conflicts (non-blocking).
    """
    # Only check items of the same type and domain
    existing = query_knowledge(
        conn,
        type_filter=item.type,
        domain_filter=item.domain if item.domain else None,
        limit=50,
    )

    conflicts = []
    for other in existing:
        if other.id == item.id:
            continue
        reason = _check_conflict(item, other)
        if reason:
            conflicts.append((other, reason))

    return conflicts


def get_stats(sidecar_dir: Path | None = None) -> dict:
    """Get knowledge store statistics."""
    sdir = sidecar_dir or require_sidecar_dir()
    conn = get_db(sdir / "db.sqlite")
    counts = count_knowledge(conn)
    conn.close()
    total = sum(counts.values())
    return {"total": total, "by_type": counts}


def get_detailed_stats(sidecar_dir: Path | None = None) -> dict:
    """Get comprehensive knowledge store statistics."""

    from .sessions import get_last_session

    sdir = sidecar_dir or require_sidecar_dir()
    conn = get_db(sdir / "db.sqlite")

    counts = count_knowledge(conn)
    total = sum(counts.values())

    # Staleness: items older than 90 days
    stale_count = conn.execute(
        "SELECT COUNT(*) FROM knowledge WHERE superseded_by IS NULL "
        "AND created_at < datetime('now', '-90 days')"
    ).fetchone()[0]

    # Domain distribution
    domain_rows = conn.execute(
        "SELECT domain, COUNT(*) as cnt FROM knowledge "
        "WHERE superseded_by IS NULL AND domain IS NOT NULL AND domain != '' "
        "GROUP BY domain ORDER BY cnt DESC"
    ).fetchall()
    domains = {row[0]: row[1] for row in domain_rows}

    conn.close()

    # Last session
    last_session = get_last_session(sdir)

    # Phase
    phase = get_phase(sdir)

    # Hook installation status
    project_dir = sdir.parent
    hooks_installed = _check_hooks_installed(project_dir)

    return {
        "total": total,
        "by_type": counts,
        "stale_count": stale_count,
        "domains": domains,
        "phase": phase,
        "last_session": last_session,
        "hooks_installed": hooks_installed,
    }


def _check_hooks_installed(project_dir: Path) -> dict[str, bool]:
    """Check if hooks are installed."""
    import json

    claude_settings = project_dir / ".claude" / "settings.local.json"
    claude_ok = False
    if claude_settings.exists():
        try:
            data = json.loads(claude_settings.read_text())
            claude_ok = "sidecar" in json.dumps(data.get("hooks", {}))
        except (json.JSONDecodeError, OSError):
            pass

    git_hooks_dir = project_dir / ".git" / "hooks"
    git_ok = False
    for hook_name in ("post-commit", "pre-commit"):
        hook_path = git_hooks_dir / hook_name
        if hook_path.exists() and "sidecar" in hook_path.read_text():
            git_ok = True
            break

    return {"claude": claude_ok, "git": git_ok}
