"""Ecosystem curator: discover, recommend, and install AI coding tools.

Maps project profiles against a curated index of tools, skills, hooks,
and configurations. Helps teams navigate the fragmented AI tools landscape
by matching what they need to what's available.

Tool categories:
  - skills: Claude Code SKILL.md files (gstack, CARL, etc.)
  - hooks: Claude Code hook scripts
  - rules: Coding standards and constraint files (PAUL, etc.)
  - mcp: MCP server configurations
  - configs: Editor/tool configurations
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

import yaml

from .db import get_db, query_knowledge

# ── Tool Index ────────────────────────────────────────────────────────────


@dataclass
class Tool:
    """A tool/skill/hook in the ecosystem index."""

    name: str
    category: str  # skill, hook, rule, mcp, config
    description: str
    domains: list[str] = field(default_factory=list)  # e.g. ["python", "web", "api"]
    tags: list[str] = field(default_factory=list)
    source: str = ""  # URL or path
    install_type: str = "file"  # file, npm, pip, manual
    install_target: str = ""  # where to install (e.g. ".claude/skills/")
    requires: list[str] = field(default_factory=list)  # dependencies


# Built-in curated index — extensible via .sidecar/ecosystem.yaml
# Only lists tools that are real and installable via sidecar commands.
BUILTIN_INDEX: list[dict] = [
    {
        "name": "sidecar-skill",
        "category": "skill",
        "description": "Sidecar knowledge management commands for Claude Code",
        "domains": ["all"],
        "tags": ["knowledge", "memory", "context"],
        "install_type": "command",
        "install_target": ".claude/skills/sidecar/SKILL.md",
        "install_command": "sidecar install-skill",
    },
    {
        "name": "sidecar-hooks",
        "category": "hook",
        "description": "Auto-inject project knowledge into Claude Code sessions",
        "domains": ["all"],
        "tags": ["prompt", "enhancement", "context"],
        "install_type": "command",
        "install_target": ".claude/settings.local.json",
        "install_command": "sidecar install-hooks",
    },
    {
        "name": "git-commit-capture",
        "category": "hook",
        "description": "Auto-capture decisions from commit messages via git post-commit hook",
        "domains": ["all"],
        "tags": ["git", "capture", "decisions"],
        "install_type": "command",
        "install_target": ".git/hooks/post-commit",
        "install_command": "sidecar install-git-hooks",
    },
    {
        "name": "git-impact-warnings",
        "category": "hook",
        "description": "Surface constraint/lesson warnings in git pre-commit when touching sensitive areas",
        "domains": ["all"],
        "tags": ["git", "safety", "constraints"],
        "install_type": "command",
        "install_target": ".git/hooks/pre-commit",
        "install_command": "sidecar install-git-hooks",
    },
]


def _parse_tool(data: dict) -> Tool:
    """Parse a dict into a Tool."""
    return Tool(
        name=data.get("name", ""),
        category=data.get("category", ""),
        description=data.get("description", ""),
        domains=data.get("domains", []),
        tags=data.get("tags", []),
        source=data.get("source", ""),
        install_type=data.get("install_type", "file"),
        install_target=data.get("install_target", ""),
        requires=data.get("requires", []),
    )


def load_index(sidecar_dir: Path | None = None) -> list[Tool]:
    """Load the full tool index: built-in + custom entries."""
    tools = [_parse_tool(d) for d in BUILTIN_INDEX]

    # Load custom index if present
    if sidecar_dir:
        custom_path = sidecar_dir / "ecosystem.yaml"
        if custom_path.exists():
            try:
                custom = yaml.safe_load(custom_path.read_text()) or {}
                for entry in custom.get("tools", []):
                    tools.append(_parse_tool(entry))
            except (yaml.YAMLError, OSError):
                pass

    return tools


# ── Project Profile ───────────────────────────────────────────────────────


@dataclass
class ProjectProfile:
    """Derived profile of a project based on its knowledge store and files."""

    domains: set[str] = field(default_factory=set)
    technologies: set[str] = field(default_factory=set)
    concerns: set[str] = field(default_factory=set)  # areas of focus/risk


# Domain detection patterns
DOMAIN_SIGNALS = {
    "python": [".py", "pyproject.toml", "setup.py", "requirements.txt", "pipfile"],
    "javascript": [".js", ".jsx", "package.json"],
    "typescript": [".ts", ".tsx", "tsconfig.json"],
    "web": [".html", ".css", ".scss", "webpack", "vite"],
    "api": ["fastapi", "flask", "express", "django", "rest", "graphql", "endpoint"],
    "backend": ["server", "api", "database", "queue", "worker"],
    "database": ["sql", "migration", "postgres", "mysql", "sqlite", "redis", "mongo"],
    "mobile": ["react-native", "flutter", "swift", "kotlin", "ios", "android"],
    "devops": ["docker", "kubernetes", "terraform", "ci", "cd", "pipeline"],
}


def build_profile(
    sidecar_dir: Path | None = None,
    project_dir: Path | None = None,
) -> ProjectProfile:
    """Build a project profile from knowledge store and file structure."""
    profile = ProjectProfile()

    # Scan knowledge for domain signals
    if sidecar_dir and (sidecar_dir / "db.sqlite").exists():
        conn = get_db(sidecar_dir / "db.sqlite")
        items = query_knowledge(conn)
        conn.close()

        all_text = " ".join((item.content + " " + (item.tags or "")).lower() for item in items)

        for domain, signals in DOMAIN_SIGNALS.items():
            if any(sig in all_text for sig in signals):
                profile.domains.add(domain)

        # Extract technology mentions
        tech_pattern = re.compile(
            r"\b(react|vue|angular|django|flask|fastapi|express|next\.?js|"
            r"postgres|mysql|redis|mongodb|docker|kubernetes|terraform|"
            r"typescript|python|golang|rust|java|swift|kotlin)\b",
            re.I,
        )
        profile.technologies = {m.lower() for m in tech_pattern.findall(all_text)}

        # Extract concern areas from constraints/lessons
        concern_keywords = {
            "security",
            "performance",
            "testing",
            "migration",
            "auth",
            "deployment",
            "scaling",
            "monitoring",
        }
        for item in items:
            if item.type in ("constraint", "lesson"):
                item_text = (item.content + " " + (item.tags or "")).lower()
                item_words = set(re.findall(r"\w+", item_text))
                profile.concerns |= item_words & concern_keywords

    # Scan project directory for file-based signals
    if project_dir and project_dir.exists():
        _scan_files_for_domains(project_dir, profile)

    return profile


def _scan_files_for_domains(project_dir: Path, profile: ProjectProfile) -> None:
    """Quick scan of project files to detect domains."""
    # Check for key config files (don't recurse deeply)
    for check_path, domain in [
        ("pyproject.toml", "python"),
        ("setup.py", "python"),
        ("package.json", "javascript"),
        ("tsconfig.json", "typescript"),
        ("Dockerfile", "devops"),
        ("docker-compose.yml", "devops"),
        ("Makefile", "backend"),
    ]:
        if (project_dir / check_path).exists():
            profile.domains.add(domain)

    # Check src/ directory for language-specific files
    src_dir = project_dir / "src"
    if src_dir.exists():
        for ext, domain in [(".py", "python"), (".ts", "typescript"), (".js", "javascript")]:
            if list(src_dir.glob(f"**/*{ext}"))[:1]:  # Just check if any exist
                profile.domains.add(domain)


# ── Recommendation Engine ────────────────────────────────────────────────


@dataclass
class Recommendation:
    """A recommended tool with match reasoning."""

    tool: Tool
    score: float
    reasons: list[str] = field(default_factory=list)


def recommend(
    profile: ProjectProfile,
    index: list[Tool] | None = None,
    sidecar_dir: Path | None = None,
    *,
    top_k: int = 10,
) -> list[Recommendation]:
    """Recommend tools based on project profile."""
    if index is None:
        index = load_index(sidecar_dir)

    recommendations = []

    for tool in index:
        score = 0.0
        reasons = []

        # Domain match
        if "all" in tool.domains:
            score += 0.3
            reasons.append("universal tool")
        else:
            domain_overlap = profile.domains & set(tool.domains)
            if domain_overlap:
                score += 0.5 * (len(domain_overlap) / len(tool.domains))
                reasons.append(f"matches domains: {', '.join(domain_overlap)}")

        # Tag match against concerns
        tag_overlap = profile.concerns & set(tool.tags)
        if tag_overlap:
            score += 0.3 * (len(tag_overlap) / max(len(tool.tags), 1))
            reasons.append(f"addresses concerns: {', '.join(tag_overlap)}")

        # Technology match
        tech_overlap = profile.technologies & set(tool.tags)
        if tech_overlap:
            score += 0.2
            reasons.append(f"matches tech: {', '.join(tech_overlap)}")

        if score > 0:
            recommendations.append(Recommendation(tool=tool, score=score, reasons=reasons))

    recommendations.sort(key=lambda r: r.score, reverse=True)
    return recommendations[:top_k]


# ── Scan (discovery) ─────────────────────────────────────────────────────


def scan(sidecar_dir: Path | None = None) -> list[Tool]:
    """List all available tools in the index."""
    return load_index(sidecar_dir)


# ── Format Output ────────────────────────────────────────────────────────


def format_scan_results(tools: list[Tool]) -> str:
    """Format tool list for display."""
    if not tools:
        return "No tools in index."

    lines = []
    by_category: dict[str, list[Tool]] = {}
    for tool in tools:
        by_category.setdefault(tool.category, []).append(tool)

    for cat in ["skill", "hook", "rule", "mcp", "config"]:
        cat_tools = by_category.get(cat, [])
        if not cat_tools:
            continue
        lines.append(f"\n{cat.upper()}S:")
        for t in cat_tools:
            domains = ", ".join(t.domains) if t.domains else "all"
            lines.append(f"  {t.name:<30} {t.description}")
            lines.append(f"  {'':30} domains: {domains}")

    return "\n".join(lines)


def format_recommendations(recs: list[Recommendation]) -> str:
    """Format recommendations for display."""
    if not recs:
        return "No recommendations for this project profile."

    lines = ["Recommended tools for your project:\n"]
    for i, rec in enumerate(recs, 1):
        score_pct = int(rec.score * 100)
        lines.append(f"  {i}. {rec.tool.name} ({score_pct}% match)")
        lines.append(f"     {rec.tool.description}")
        if rec.reasons:
            lines.append(f"     Why: {'; '.join(rec.reasons)}")
        lines.append("")

    return "\n".join(lines)
