"""Markdown mirroring: every knowledge item is also a readable .md file.

Files are organized by type under .sidecar/knowledge/<type>/.
This ensures knowledge is human-reviewable, git-trackable, and survives DB loss.
"""

from __future__ import annotations

import re
from pathlib import Path

from .db import KnowledgeItem

TYPE_DIRS = {
    "decision": "decisions",
    "constraint": "constraints",
    "relationship": "relationships",
    "lesson": "lessons",
}


def _slug(text: str, max_len: int = 50) -> str:
    """Create a filename-safe slug from text."""
    slug = re.sub(r"[^a-z0-9]+", "-", text.lower().strip())
    slug = slug.strip("-")
    if len(slug) > max_len:
        slug = slug[:max_len].rsplit("-", 1)[0]
    return slug or "untitled"


def mirror_path(sidecar_dir: Path, item: KnowledgeItem) -> Path:
    """Get the markdown mirror path for a knowledge item."""
    type_dir = TYPE_DIRS.get(item.type, item.type + "s")
    slug = _slug(item.content)
    return sidecar_dir / "knowledge" / type_dir / f"{item.id}-{slug}.md"


def write_mirror(sidecar_dir: Path, item: KnowledgeItem) -> Path:
    """Write a knowledge item as a markdown file. Returns the file path."""
    path = mirror_path(sidecar_dir, item)
    path.parent.mkdir(parents=True, exist_ok=True)

    tags_line = f"tags: {item.tags}" if item.tags else ""
    source_line = f"source: {item.source}"
    confidence_line = f"confidence: {item.confidence}" if item.confidence < 1.0 else ""

    meta_lines = [
        f"type: {item.type}",
        f"created: {item.created_at}",
        source_line,
    ]
    if tags_line:
        meta_lines.append(tags_line)
    if confidence_line:
        meta_lines.append(confidence_line)
    if item.domain:
        meta_lines.append(f"domain: {item.domain}")
    if item.min_phase:
        meta_lines.append(f"min_phase: {item.min_phase}")
    if item.superseded_by:
        meta_lines.append(f"superseded_by: {item.superseded_by}")

    content = f"""---
{chr(10).join(meta_lines)}
---

{item.content}
"""
    path.write_text(content)
    return path


def delete_mirror(sidecar_dir: Path, item: KnowledgeItem) -> None:
    """Delete the markdown mirror for a knowledge item."""
    path = mirror_path(sidecar_dir, item)
    if path.exists():
        path.unlink()


def ensure_knowledge_dirs(sidecar_dir: Path) -> None:
    """Create the knowledge subdirectories."""
    for type_dir in TYPE_DIRS.values():
        (sidecar_dir / "knowledge" / type_dir).mkdir(parents=True, exist_ok=True)


# Reverse map: directory name → knowledge type
_DIR_TO_TYPE = {v: k for k, v in TYPE_DIRS.items()}


def read_mirrors(sidecar_dir: Path) -> list[KnowledgeItem]:
    """Read all mirror files back into KnowledgeItem objects.

    Used for disaster recovery when the database is lost or corrupted.
    """
    knowledge_dir = sidecar_dir / "knowledge"
    if not knowledge_dir.exists():
        return []

    items = []
    for type_dir_path in knowledge_dir.iterdir():
        if not type_dir_path.is_dir():
            continue
        ktype = _DIR_TO_TYPE.get(type_dir_path.name, type_dir_path.name.rstrip("s"))

        for md_file in sorted(type_dir_path.glob("*.md")):
            item = _parse_mirror_file(md_file, ktype)
            if item:
                items.append(item)

    return items


def _parse_mirror_file(path: Path, default_type: str) -> KnowledgeItem | None:
    """Parse a mirror markdown file back into a KnowledgeItem."""
    text = path.read_text()

    # Extract frontmatter
    if not text.startswith("---"):
        return None

    parts = text.split("---", 2)
    if len(parts) < 3:
        return None

    meta_text = parts[1].strip()
    content = parts[2].strip()

    if not content:
        return None

    # Parse frontmatter key-value pairs
    meta: dict[str, str] = {}
    for line in meta_text.splitlines():
        if ":" in line:
            key, _, value = line.partition(":")
            meta[key.strip()] = value.strip()

    # Extract ID from filename (format: {id}-{slug}.md)
    stem = path.stem
    item_id = stem.split("-", 1)[0] if "-" in stem else stem

    return KnowledgeItem(
        id=item_id,
        type=meta.get("type", default_type),
        content=content,
        tags=meta.get("tags") or None,
        source=meta.get("source", "mirror-rebuild"),
        confidence=float(meta.get("confidence", "1.0")),
        created_at=meta.get("created", ""),
        superseded_by=meta.get("superseded_by") or None,
        domain=meta.get("domain") or None,
        min_phase=meta.get("min_phase") or None,
    )
