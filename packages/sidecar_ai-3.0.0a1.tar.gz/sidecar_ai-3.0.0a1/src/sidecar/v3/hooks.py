"""Claude Code hook integration: auto-inject knowledge, context brackets, prompt enhancement.

Two hook entry points:
  - prompt_hook: runs on UserPromptSubmit, injects relevant knowledge + prompt enrichment
  - stop_hook: runs on Stop, nudges reflect if session was substantive

Context brackets adapt injection depth based on conversation position:
  - FRESH (prompts 1-3): full brief with all relevant knowledge
  - MODERATE (prompts 4-15): targeted — only constraints and lessons for touched areas
  - DEPLETED (prompts 16+): minimal — critical constraints only, suggest reflect

Prompt enhancement layer:
  - Detects vague/short prompts and suggests structure
  - Surfaces safety reminders when prompt touches sensitive areas
  - Injects project coding standards from constraints on first prompt
  - Config-driven prompt rules from .sidecar/config.yaml

State tracked in .sidecar/.hook-state (JSON file).
"""

from __future__ import annotations

import json
import re
import time
from datetime import UTC, datetime
from pathlib import Path

import yaml

from .db import get_db, query_knowledge
from .knowledge import find_sidecar_dir, format_recall_results, get_mode
from .retrieval import search
from .sessions import get_last_session, read_primer

BRACKET_FRESH = "FRESH"
BRACKET_MODERATE = "MODERATE"
BRACKET_DEPLETED = "DEPLETED"

FRESH_MAX = 3
MODERATE_MAX = 15
# Session considered stale after 2 hours of inactivity
SESSION_STALE_SECONDS = 7200


def _state_path(sidecar_dir: Path) -> Path:
    return sidecar_dir / ".hook-state"


def _read_state(sidecar_dir: Path) -> dict:
    """Read hook state. Returns defaults if missing or stale."""
    path = _state_path(sidecar_dir)
    if not path.exists():
        return _default_state()

    try:
        state = json.loads(path.read_text())
    except (json.JSONDecodeError, OSError):
        return _default_state()

    # Check staleness — reset if last prompt was too long ago
    last_ts = state.get("last_prompt_ts", 0)
    if time.time() - last_ts > SESSION_STALE_SECONDS:
        return _default_state()

    return state


def _default_state() -> dict:
    return {
        "prompt_count": 0,
        "last_prompt_ts": 0,
        "files_mentioned": [],
        "knowledge_injected": [],
    }


def _write_state(sidecar_dir: Path, state: dict) -> None:
    path = _state_path(sidecar_dir)
    path.write_text(json.dumps(state))


def get_bracket(prompt_count: int) -> str:
    """Determine context bracket from prompt count."""
    if prompt_count <= FRESH_MAX:
        return BRACKET_FRESH
    elif prompt_count <= MODERATE_MAX:
        return BRACKET_MODERATE
    else:
        return BRACKET_DEPLETED


# ── Prompt Enhancement ────────────────────────────────────────────────────

# Patterns that suggest a prompt is too vague to act on well
VAGUE_PATTERNS = [
    re.compile(r"^(fix|do|change|update|make|handle)\s+(it|this|that|the thing)\.?$", re.I),
    re.compile(r"^(help|please|can you|could you)\s*$", re.I),
    re.compile(r"^(yeah?|yep|ok|sure|go ahead|continue|next|proceed|same)\.?$", re.I),
    re.compile(r"^(do|make)\s+(the\s+)?(same|rest|other|remaining)\s*(ones?)?\.?$", re.I),
    re.compile(r"^(it|that)\s*(doesn'?t|isn'?t|won'?t)\s+(work|run|compile|build)\.?$", re.I),
    re.compile(r"^(what|why|how)\s+(about|now)\??\s*$", re.I),
]

# Keywords that signal sensitive areas — matched against constraints/lessons
SENSITIVE_KEYWORDS = {
    "auth",
    "authentication",
    "token",
    "secret",
    "password",
    "credential",
    "migration",
    "database",
    "schema",
    "deploy",
    "production",
    "security",
    "payment",
    "billing",
    "api-key",
    "encryption",
    "permission",
    "rbac",
}


def _detect_prompt_domains(prompt_text: str) -> set[str]:
    """Analyze prompt to determine which knowledge domains are relevant."""
    from .knowledge import DOMAIN_PATTERNS

    found: set[str] = set()
    lower = prompt_text.lower()
    for domain, patterns in DOMAIN_PATTERNS.items():
        for pattern in patterns:
            if re.search(pattern, lower):
                found.add(domain)
                break
    return found


def _filter_by_domain(items: list, active_domains: set[str]) -> list:
    """Filter items by domain. Items without domain always pass through."""
    if not active_domains:
        return items
    return [
        item
        for item in items
        if not item.domain or any(d in item.domain.split(",") for d in active_domains)
    ]


def _filter_by_phase(items: list, current_phase: str) -> list:
    """Filter items by phase threshold. Items with min_phase higher than current are excluded."""
    from .knowledge import PHASE_ORDER

    current_order = PHASE_ORDER.get(current_phase, 0)
    return [
        item
        for item in items
        if not item.min_phase or PHASE_ORDER.get(item.min_phase, 0) <= current_order
    ]


def _load_prompt_rules(sidecar_dir: Path) -> dict:
    """Load prompt enhancement rules from config.yaml."""
    config_path = sidecar_dir / "config.yaml"
    if not config_path.exists():
        return {}
    try:
        config = yaml.safe_load(config_path.read_text()) or {}
        return config.get("prompt_rules", {})
    except (yaml.YAMLError, OSError):
        return {}


def _detect_vague_prompt(prompt_text: str) -> str | None:
    """Detect vague prompts and return a structure suggestion."""
    text = prompt_text.strip()

    # Very short prompts (under 20 chars, no code references)
    # Skip if it contains code-like tokens (paths, functions, symbols)
    has_code_ref = any(c in text for c in "/.(){}[]<>::#@") or re.search(r"\b\w+\.\w+\b", text)
    if len(text) < 20 and not has_code_ref:
        return (
            "Tip: This prompt is quite short. For better results, try including:\n"
            "  - What file/component to change\n"
            "  - What the expected behavior should be\n"
            "  - Any constraints or requirements"
        )

    # Known vague patterns
    for pattern in VAGUE_PATTERNS:
        if pattern.match(text):
            return (
                "Tip: This prompt is ambiguous. Try being specific about:\n"
                "  - Which file or function to modify\n"
                "  - What the current vs desired behavior is"
            )

    return None


def _detect_sensitive_areas(prompt_text: str, all_items: list) -> list[str]:
    """Find safety reminders when prompt touches sensitive areas."""
    prompt_lower = prompt_text.lower()
    prompt_words = set(re.findall(r"\w+", prompt_lower))

    # Check if prompt mentions any sensitive keywords (exact or substring match)
    touched = prompt_words & SENSITIVE_KEYWORDS
    # Also check if any prompt word contains a sensitive keyword as substring
    for word in prompt_words:
        for kw in SENSITIVE_KEYWORDS:
            if kw in word and kw not in touched:
                touched.add(kw)
    if not touched:
        return []

    # Find constraints/lessons that match the sensitive area
    warnings = []
    for item in all_items:
        if item.type not in ("constraint", "lesson"):
            continue
        item_lower = item.content.lower()
        item_tags = set((item.tags or "").lower().split(","))
        # Match if the sensitive keyword appears in the item content or tags
        if any(kw in item_lower or kw in item_tags for kw in touched):
            warnings.append(item.content)

    return warnings[:5]  # Cap at 5


def _get_coding_standards(all_items: list, active_domains: set[str] | None = None) -> list[str]:
    """Extract coding standards from constraints for first-prompt injection."""
    standards = []
    for item in all_items:
        if item.type == "constraint" and item.confidence >= 1.0:
            if active_domains and item.domain:
                item_domains = set(item.domain.split(","))
                if not (item_domains & active_domains):
                    continue
            standards.append(item.content)
    return standards[:10]  # Cap at 10


def _apply_prompt_rules(prompt_text: str, rules: dict) -> list[str]:
    """Apply config-driven prompt rules. Returns additional guidance lines."""
    guidance = []

    # Custom reminders triggered by keyword match
    reminders = rules.get("reminders", [])
    for reminder in reminders:
        triggers = reminder.get("when", [])
        message = reminder.get("say", "")
        if not triggers or not message:
            continue
        prompt_lower = prompt_text.lower()
        if any(t.lower() in prompt_lower for t in triggers):
            guidance.append(message)

    # Always-inject rules (shown on every prompt)
    always = rules.get("always", [])
    for rule in always:
        if isinstance(rule, str):
            guidance.append(rule)

    return guidance


def _enhance_prompt(
    prompt_text: str,
    bracket: str,
    all_items: list,
    sdir: Path,
    state: dict,
    active_domains: set[str] | None = None,
) -> list[str]:
    """Build prompt enhancement lines. Returns list of strings to prepend."""
    enhancements: list[str] = []
    rules = _load_prompt_rules(sdir)

    # Vague prompt detection (all brackets)
    vague_hint = _detect_vague_prompt(prompt_text)
    if vague_hint:
        enhancements.append(vague_hint)

    # Safety reminders when touching sensitive areas (all brackets)
    warnings = _detect_sensitive_areas(prompt_text, all_items)
    if warnings:
        enhancements.append("[Sidecar: Safety reminders for this area]")
        for w in warnings:
            enhancements.append(f"  - {w}")

    # Coding standards on first prompt only
    if state["prompt_count"] == 1 and bracket == BRACKET_FRESH:
        standards = _get_coding_standards(all_items, active_domains)
        if standards:
            enhancements.append("[Sidecar: Project coding standards]")
            for s in standards:
                enhancements.append(f"  - {s}")

    # Config-driven rules
    if rules:
        rule_lines = _apply_prompt_rules(prompt_text, rules)
        if rule_lines:
            enhancements.append("[Sidecar: Project guidance]")
            for line in rule_lines:
                enhancements.append(f"  - {line}")

    return enhancements


def prompt_hook(prompt_text: str, sidecar_dir: Path | None = None) -> str:
    """Process a user prompt and return knowledge to inject.

    Called by Claude Code's UserPromptSubmit hook. Output goes to stdout
    and is injected into the agent's context.

    Returns empty string if no relevant knowledge found.
    """
    sdir = sidecar_dir or find_sidecar_dir()
    if not sdir or not (sdir / "db.sqlite").exists():
        return ""

    # Check mode — disabled = full bypass, observe = skip injection but track state
    mode = get_mode(sdir)
    if mode == "disabled":
        return ""

    # Read and update state
    state = _read_state(sdir)
    state["prompt_count"] += 1
    state["last_prompt_ts"] = time.time()
    bracket = get_bracket(state["prompt_count"])

    # Detect active domains from prompt for semantic filtering
    active_domains = _detect_prompt_domains(prompt_text)

    # Get knowledge items — cap at 200 to stay within hook timeout.
    # Retrieval scoring handles ranking; loading thousands is wasteful.
    conn = get_db(sdir / "db.sqlite")
    all_items = query_knowledge(conn, limit=200)
    conn.close()

    if not all_items:
        # Still check for vague prompt and config rules even without knowledge
        enhancement_lines = _enhance_prompt(prompt_text, bracket, [], sdir, state, active_domains)
        _write_state(sdir, state)
        if mode == "observe":
            return ""
        return "\n".join(enhancement_lines) if enhancement_lines else ""

    # Domain filter: keep items matching active domains or untagged items
    all_items = _filter_by_domain(all_items, active_domains)

    # Phase filter: exclude items above current project phase
    from .knowledge import get_phase

    try:
        current_phase = get_phase(sdir)
    except (FileNotFoundError, OSError):
        current_phase = "prototype"
    all_items = _filter_by_phase(all_items, current_phase)

    # Search for relevant knowledge
    results = search(prompt_text, all_items, top_k=_top_k_for_bracket(bracket))

    # Prompt enhancement layer (runs even if no search results)
    enhancement_lines = _enhance_prompt(
        prompt_text, bracket, all_items, sdir, state, active_domains
    )

    if not results:
        _write_state(sdir, state)
        if mode == "observe":
            return ""
        return "\n".join(enhancement_lines) if enhancement_lines else ""

    # Filter by bracket
    knowledge_output = _format_for_bracket(bracket, results, sdir, state)

    # Track what we injected — IDs for dedup, keywords for relevance scoring
    injected_ids = [item.id for item, _ in results]
    state["knowledge_injected"] = list(set(state.get("knowledge_injected", []) + injected_ids))[
        -50:
    ]  # Keep last 50

    # Track injected item keywords for relevance scoring in stop_hook
    injected_keywords: list[str] = []
    for item, _ in results:
        # Extract file/module names and key terms from content
        words = re.findall(r"[\w][\w.-]+", item.content.lower())
        injected_keywords.extend(w for w in words if len(w) > 3)
    state["injected_keywords"] = list(set(state.get("injected_keywords", []) + injected_keywords))[
        -100:
    ]

    _write_state(sdir, state)

    # Observe mode: track state but don't inject
    if mode == "observe":
        return ""

    # Combine enhancement + knowledge
    parts = []
    if enhancement_lines:
        parts.append("\n".join(enhancement_lines))
    if knowledge_output:
        parts.append(knowledge_output)

    return "\n\n".join(parts) if parts else ""


def _top_k_for_bracket(bracket: str) -> int:
    if bracket == BRACKET_FRESH:
        return 10
    elif bracket == BRACKET_MODERATE:
        return 5
    else:
        return 3


def _format_for_bracket(
    bracket: str,
    results: list,
    sdir: Path,
    state: dict,
) -> str:
    """Format knowledge output based on context bracket."""
    lines: list[str] = []

    if bracket == BRACKET_FRESH:
        # Full context: all types, session primer
        lines.append("[Sidecar: Project Knowledge]")

        # Include primer on first prompt
        if state["prompt_count"] == 1:
            primer = read_primer(sdir)
            if primer:
                # Truncate primer to keep injection reasonable
                primer_short = primer[:800]
                if len(primer) > 800:
                    primer_short += "\n..."
                lines.append(f"\nLast session:\n{primer_short}")

        formatted = format_recall_results(results)
        if formatted and formatted != "No relevant knowledge found.":
            lines.append(f"\nRelevant knowledge:\n{formatted}")

    elif bracket == BRACKET_MODERATE:
        # Targeted: only constraints and lessons, skip already-injected
        already = set(state.get("knowledge_injected", []))
        filtered = [
            (item, score)
            for item, score in results
            if item.type in ("constraint", "lesson") and item.id not in already
        ]
        if filtered:
            lines.append("[Sidecar: Relevant constraints/lessons]")
            formatted = format_recall_results(filtered)
            lines.append(formatted)

    else:  # DEPLETED
        # Minimal: only critical constraints
        critical = [(item, score) for item, score in results if item.type == "constraint"]
        if critical:
            lines.append("[Sidecar: Critical constraints]")
            for item, _ in critical[:3]:
                lines.append(f"  - {item.content}")
        lines.append(
            "\n[Context running long — consider running `sidecar reflect` to capture progress]"
        )

    return "\n".join(lines) if lines else ""


def stop_hook(sidecar_dir: Path | None = None) -> str:
    """Process a Stop event. Returns a nudge message if session was substantive.

    Called by Claude Code's Stop hook. Also logs session instrumentation
    (what was injected vs what files changed) for relevance tracking.
    """
    sdir = sidecar_dir or find_sidecar_dir()
    if not sdir:
        return ""

    # Disabled mode: full bypass
    try:
        mode = get_mode(sdir)
    except (FileNotFoundError, OSError):
        mode = "active"
    if mode == "disabled":
        return ""

    state = _read_state(sdir)
    prompt_count = state.get("prompt_count", 0)

    # Auto-instrumentation: log session metrics regardless of prompt count
    _log_session_metrics(sdir, state)

    # Only nudge if the session was substantive (3+ prompts)
    if prompt_count < 3:
        _write_state(sdir, _default_state())
        return ""

    # Check if there's already a recent session
    last = get_last_session(sdir)
    if last and last.ended_at:
        ended = last.ended_at
        try:
            ended_dt = datetime.fromisoformat(ended)
            now = datetime.now(UTC)
            if (now - ended_dt).total_seconds() < 300:
                return ""
        except (ValueError, TypeError):
            pass

    # Reset state for next conversation
    _write_state(sdir, _default_state())

    message = (
        f"Session had {prompt_count} exchanges. "
        f"Consider running `sidecar reflect` to capture decisions and lessons, "
        f"or `sidecar reflect --auto` for automatic capture from git history."
    )

    # Staleness nudge: if >5 stale items, mention it
    try:
        from .knowledge import get_stale_items

        stale_items = get_stale_items(sidecar_dir=sdir)
        if len(stale_items) > 5:
            message += (
                f"\n\nYou have {len(stale_items)} stale knowledge items (>90 days). "
                f"Run `sidecar stale` to review."
            )
    except (FileNotFoundError, OSError):
        pass

    return message


def _log_session_metrics(sdir: Path, state: dict) -> None:
    """Log session instrumentation to .sidecar/sessions-log.jsonl.

    Captures: prompt count, items injected, files changed, relevance score.
    Relevance = overlap between injected knowledge keywords and modified file paths.
    """
    prompt_count = state.get("prompt_count", 0)
    if prompt_count == 0:
        return

    try:
        from .git_context import get_git_context

        # Find project root (parent of .sidecar/)
        project_dir = sdir.parent
        ctx = get_git_context(cwd=project_dir)
        changed_files = ctx.dirty_files
    except (ImportError, OSError):
        changed_files = []

    injected_ids = state.get("knowledge_injected", [])
    injected_keywords = set(state.get("injected_keywords", []))

    # Compute relevance: how many changed files have keywords that overlap
    # with injected knowledge terms
    relevance_hits = 0
    if changed_files and injected_keywords:
        for filepath in changed_files:
            # Extract meaningful parts from file path
            path_parts = set(re.findall(r"[\w][\w.-]+", filepath.lower()))
            if path_parts & injected_keywords:
                relevance_hits += 1

    relevance_score = round(relevance_hits / len(changed_files), 2) if changed_files else 0.0

    entry = {
        "timestamp": datetime.now(UTC).isoformat(),
        "prompt_count": prompt_count,
        "items_injected": len(injected_ids),
        "files_changed": len(changed_files),
        "relevance_hits": relevance_hits,
        "relevance_score": relevance_score,
        "changed_files": changed_files[:20],
    }

    log_path = sdir / "sessions-log.jsonl"
    try:
        with open(log_path, "a") as f:
            f.write(json.dumps(entry) + "\n")
    except OSError:
        pass
