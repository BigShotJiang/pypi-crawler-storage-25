"""Cross-project knowledge: recall, export, import, supersession.

Enables querying knowledge from other sidecar projects and
sharing knowledge packages as portable JSON files.
"""

from __future__ import annotations

from datetime import UTC, datetime
from pathlib import Path

from .db import KnowledgeItem, find_duplicate, get_db, insert_knowledge, query_knowledge
from .mirror import write_mirror
from .retrieval import compute_embedding, search


def recall_from_project(
    query: str,
    project_path: Path,
    *,
    type_filter: str | None = None,
    top_k: int = 10,
) -> list[tuple[KnowledgeItem, float]]:
    """Recall knowledge from another project's sidecar database."""
    sdir = project_path / ".sidecar"
    db_path = sdir / "db.sqlite"

    if not db_path.exists():
        return []

    conn = get_db(db_path)
    items = query_knowledge(conn, type_filter=type_filter)
    conn.close()

    if not items:
        return []

    return search(query, items, top_k=top_k)


def export_knowledge(
    sidecar_dir: Path,
    *,
    tags: str | None = None,
    type_filter: str | None = None,
) -> dict:
    """Export knowledge as a portable JSON package.

    Returns a dict ready for json.dumps. Does not include embeddings
    (they are recomputed on import).
    """
    conn = get_db(sidecar_dir / "db.sqlite")
    items = query_knowledge(
        conn,
        type_filter=type_filter,
        tag_filter=tags,
    )
    conn.close()

    return {
        "sidecar_version": 3,
        "exported_at": datetime.now(UTC).isoformat(),
        "source_project": sidecar_dir.parent.name,
        "item_count": len(items),
        "knowledge": [
            {
                "type": item.type,
                "content": item.content,
                "tags": item.tags,
                "source": item.source,
                "confidence": item.confidence,
                "created_at": item.created_at,
            }
            for item in items
        ],
    }


def import_knowledge_package(
    sidecar_dir: Path,
    package: dict,
) -> list[KnowledgeItem]:
    """Import knowledge from a portable JSON package.

    Recomputes embeddings on import. Returns list of created items.
    """
    items_data = package.get("knowledge", [])
    if not items_data:
        return []

    source_project = package.get("source_project", "unknown")

    conn = get_db(sidecar_dir / "db.sqlite")
    created = []
    skipped = 0

    for data in items_data:
        content = data["content"]
        item_type = data.get("type", "decision")

        # Skip exact duplicates
        if find_duplicate(conn, content, type_filter=item_type):
            skipped += 1
            continue

        item = KnowledgeItem(
            id="",
            type=item_type,
            content=content,
            tags=data.get("tags"),
            source=f"import:{source_project}",
            confidence=data.get("confidence", 1.0),
        )
        item.embedding = compute_embedding(item.content)
        insert_knowledge(conn, item)
        write_mirror(sidecar_dir, item)
        created.append(item)

    conn.close()
    return created


def supersede_knowledge(
    sidecar_dir: Path,
    old_id: str,
    new_content: str,
    *,
    knowledge_type: str | None = None,
) -> KnowledgeItem | None:
    """Supersede a knowledge item with new content.

    Marks the old item as superseded and creates a new item.
    Returns the new item, or None if old_id not found.
    """
    conn = get_db(sidecar_dir / "db.sqlite")

    # Check old item exists
    old = conn.execute("SELECT * FROM knowledge WHERE id = ?", (old_id,)).fetchone()
    if not old:
        conn.close()
        return None

    # Create new item
    new_item = KnowledgeItem(
        id="",
        type=knowledge_type or old["type"],
        content=new_content,
        tags=old["tags"],
        source="explicit",
    )
    new_item.embedding = compute_embedding(new_content)
    insert_knowledge(conn, new_item)

    # Mark old as superseded
    conn.execute(
        "UPDATE knowledge SET superseded_by = ? WHERE id = ?",
        (new_item.id, old_id),
    )
    conn.commit()
    conn.close()

    write_mirror(sidecar_dir, new_item)
    return new_item
