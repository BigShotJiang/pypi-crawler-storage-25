"""Sidecar v3 CLI: 5 commands for project memory.

Commands: init, learn, recall, brief, reflect.
Utilities: status, hook (prompt/stop), install-hooks.
"""

from __future__ import annotations

import contextlib
import json
from pathlib import Path

import click
import yaml
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from . import __version__
from .brief import generate_brief, generate_brief_json
from .cross_project import (
    export_knowledge,
    import_knowledge_package,
    recall_from_project,
    supersede_knowledge,
)
from .ecosystem import (
    build_profile,
    format_recommendations,
    format_scan_results,
    recommend,
    scan,
)
from .git_hooks import (
    install_git_hooks as _install_git_hooks,
)
from .git_hooks import (
    post_commit as _post_commit,
)
from .git_hooks import (
    pre_commit_warnings as _pre_commit_warnings,
)
from .hooks import prompt_hook, stop_hook
from .importer import import_directory, import_file, list_low_confidence, promote_knowledge
from .knowledge import (
    PHASES,
    detect_conflicts,
    find_sidecar_dir,
    format_recall_results,
    get_detailed_stats,
    get_phase,
    get_stale_items,
    get_stats,
    init_project,
    learn,
    recall,
    refresh_item,
    require_sidecar_dir,
    set_phase,
)
from .mirror import read_mirrors
from .sessions import auto_reflect, interactive_reflect

console = Console()


@click.group()
@click.version_option(version=__version__, prog_name="sidecar")
@click.option("-v", "--verbose", is_flag=True, help="Show detailed output")
@click.option("-q", "--quiet", is_flag=True, help="Suppress non-essential output")
@click.pass_context
def cli(ctx: click.Context, verbose: bool, quiet: bool) -> None:
    """Sidecar: Project memory for AI agents."""
    ctx.ensure_object(dict)
    ctx.obj["verbose"] = verbose
    ctx.obj["quiet"] = quiet


@cli.command()
@click.option("--name", help="Project name (defaults to directory name)")
@click.option(
    "--import-file",
    "import_files",
    multiple=True,
    type=click.Path(exists=True, path_type=Path),
    help="Import knowledge from existing files",
)
def init(name: str | None, import_files: tuple[Path, ...]) -> None:
    """Initialize sidecar for this project."""
    project_dir = Path.cwd()

    existing = find_sidecar_dir(project_dir)
    if existing and existing.parent == project_dir:
        console.print("[yellow]Sidecar already initialized in this directory.[/yellow]")
        stats = get_stats(existing)
        console.print(f"  Knowledge items: {stats['total']}")
        return

    files = list(import_files) if import_files else None
    sidecar_dir = init_project(project_dir, project_name=name, import_files=files)

    console.print(
        Panel(
            f"[green]Sidecar initialized![/green]\n\n"
            f"Directory: {sidecar_dir}\n"
            f"Database: {sidecar_dir / 'db.sqlite'}\n\n"
            f"Next steps:\n"
            f'  sidecar learn "your first decision or constraint"\n'
            f'  sidecar recall "query to test retrieval"',
            title="sidecar init",
        )
    )


@cli.command()
@click.argument("content")
@click.option(
    "--type",
    "knowledge_type",
    type=click.Choice(["decision", "constraint", "relationship", "lesson"]),
    default=None,
    help="Knowledge type (default: decision)",
)
@click.option("--constraint", "is_constraint", is_flag=True, help="Shorthand for --type constraint")
@click.option(
    "--relationship", "is_relationship", is_flag=True, help="Shorthand for --type relationship"
)
@click.option("--lesson", "is_lesson", is_flag=True, help="Shorthand for --type lesson")
@click.option("--tags", help="Comma-separated tags for better retrieval")
@click.option("--domain", help="Knowledge domain (e.g., frontend, backend, security)")
@click.option(
    "--min-phase",
    type=click.Choice(["prototype", "mvp", "production", "scale"]),
    help="Minimum project phase for this item to activate",
)
@click.option("--json-output", "json_out", is_flag=True, help="Output as JSON")
def learn_cmd(
    content: str,
    knowledge_type: str | None,
    is_constraint: bool,
    is_relationship: bool,
    is_lesson: bool,
    tags: str | None,
    domain: str | None,
    min_phase: str | None,
    json_out: bool,
) -> None:
    """Record a piece of project knowledge.

    CONTENT is the knowledge to store, in natural language.

    Examples:
      sidecar learn "We use design tokens for all theming"
      sidecar learn --constraint "All APIs must return X-Request-ID"
      sidecar learn --lesson "Changing token format requires mobile release"
      sidecar learn --tags auth,mobile "Tokens cached for 24h in mobile app"
    """
    # Resolve type from flags
    if is_constraint:
        knowledge_type = "constraint"
    elif is_relationship:
        knowledge_type = "relationship"
    elif is_lesson:
        knowledge_type = "lesson"
    elif knowledge_type is None:
        knowledge_type = "decision"

    try:
        item = learn(content, type=knowledge_type, tags=tags, domain=domain, min_phase=min_phase)
    except FileNotFoundError as e:
        console.print(f"[red]{e}[/red]")
        raise SystemExit(1) from None

    if json_out:
        click.echo(
            json.dumps(
                {
                    "id": item.id,
                    "type": item.type,
                    "content": item.content,
                    "tags": item.tags,
                    "created_at": item.created_at,
                },
                indent=2,
            )
        )
    else:
        has_embedding = item.embedding is not None
        embed_status = (
            "[green]with embedding[/green]"
            if has_embedding
            else "[dim]no embedding (install sentence-transformers for semantic search)[/dim]"
        )
        console.print(
            f"[green]Learned[/green] [{item.type}] {embed_status}\n"
            f"  {item.content}\n"
            f"  ID: {item.id}" + (f"  Tags: {item.tags}" if item.tags else "")
        )


# Register learn command under the name "learn"
cli.add_command(learn_cmd, "learn")


@cli.command()
@click.argument("query")
@click.option(
    "--type",
    "type_filter",
    type=click.Choice(["decision", "constraint", "relationship", "lesson"]),
    help="Filter by knowledge type",
)
@click.option("--top-k", default=10, help="Maximum results to return")
@click.option("--json-output", "json_out", is_flag=True, help="Output as JSON")
@click.option(
    "--project",
    "project_path",
    type=click.Path(exists=True, path_type=Path),
    help="Query another project's knowledge",
)
def recall_cmd(
    query: str,
    type_filter: str | None,
    top_k: int,
    json_out: bool,
    project_path: Path | None,
) -> None:
    """Search project knowledge.

    QUERY is what you're looking for, in natural language.

    Examples:
      sidecar recall "authentication"
      sidecar recall "what database do we use?"
      sidecar recall --type constraint "API design"
      sidecar recall --project ~/other-repo "auth patterns"
    """
    try:
        if project_path:
            results = recall_from_project(query, project_path, type_filter=type_filter, top_k=top_k)
        else:
            results = recall(query, type_filter=type_filter, top_k=top_k)
    except FileNotFoundError as e:
        console.print(f"[red]{e}[/red]")
        raise SystemExit(1) from None

    if json_out:
        click.echo(
            json.dumps(
                [
                    {
                        "id": item.id,
                        "type": item.type,
                        "content": item.content,
                        "tags": item.tags,
                        "score": round(score, 4),
                        "created_at": item.created_at,
                    }
                    for item, score in results
                ],
                indent=2,
            )
        )
    else:
        if not results:
            console.print("[dim]No relevant knowledge found.[/dim]")
            return

        formatted = format_recall_results(results)
        console.print(Panel(formatted, title=f"recall: {query}"))


cli.add_command(recall_cmd, "recall")


@cli.command()
@click.argument("task")
@click.option("--primer", "write_primer", is_flag=True, help="Write output to .sidecar/primer.md")
@click.option("--json-output", "json_out", is_flag=True, help="Output as JSON")
@click.option("--top-k", default=15, help="Maximum knowledge items to include")
def brief(task: str, write_primer: bool, json_out: bool, top_k: int) -> None:
    """Generate a targeted context brief for a task.

    TASK is a description of what you're about to work on.

    Examples:
      sidecar brief "add dark mode support"
      sidecar brief "fix authentication bug" --primer
      sidecar brief "refactor payment flow" --json-output
    """
    try:
        sdir = require_sidecar_dir()
    except FileNotFoundError as e:
        console.print(f"[red]{e}[/red]")
        raise SystemExit(1) from None

    if json_out:
        data = generate_brief_json(task, sidecar_dir=sdir, top_k=top_k)
        click.echo(json.dumps(data, indent=2))
    else:
        text = generate_brief(task, sidecar_dir=sdir, top_k=top_k)
        console.print(Panel(text, title="sidecar brief", border_style="blue"))

        if write_primer:
            primer_path = sdir / "primer.md"
            primer_path.write_text(text + "\n")
            console.print(f"\n[green]Primer written to {primer_path}[/green]")


@cli.command()
@click.option(
    "--auto", "auto_mode", is_flag=True, help="Auto-reflect from git history (non-interactive)"
)
@click.option("--summary", help="What you accomplished this session")
@click.option("--decision", "decisions", multiple=True, help="Decision made (repeatable)")
@click.option("--lesson", "lessons", multiple=True, help="Lesson learned (repeatable)")
@click.option("--notes", help="Notes for the next session")
def reflect(
    auto_mode: bool,
    summary: str | None,
    decisions: tuple[str, ...],
    lessons: tuple[str, ...],
    notes: str | None,
) -> None:
    """Capture session knowledge and write primer for next session.

    Interactive mode (default) prompts for what happened.
    Auto mode (--auto) infers from git history.

    Examples:
      sidecar reflect --auto
      sidecar reflect --summary "Added dark mode" --decision "Used CSS variables"
      sidecar reflect --lesson "Theme changes need email template updates"
    """
    try:
        sdir = require_sidecar_dir()
    except FileNotFoundError as e:
        console.print(f"[red]{e}[/red]")
        raise SystemExit(1) from None

    if auto_mode:
        result = auto_reflect(sdir)
        console.print(
            Panel(
                f"[green]Auto-reflect complete[/green]\n\n"
                f"Commits analyzed: {result['commits_analyzed']}\n"
                f"Decisions captured: {result['decisions_found']}\n"
                f"Summary: {result['summary']}\n\n"
                f"Primer written to: {result['primer_path']}",
                title="sidecar reflect --auto",
            )
        )
    elif summary or decisions or lessons:
        # Non-interactive with flags
        result = interactive_reflect(
            sdir,
            accomplishments=summary or "Session completed",
            decisions=list(decisions) if decisions else None,
            lessons=list(lessons) if lessons else None,
            next_session_notes=notes,
        )
        console.print(
            Panel(
                f"[green]Reflect complete[/green]\n\n"
                f"Knowledge items created: {result['knowledge_created']}\n"
                f"Primer written to: {result['primer_path']}",
                title="sidecar reflect",
            )
        )
    else:
        # Interactive mode — prompt for each field
        console.print("[bold]Session Reflection[/bold]\n")

        summary_input = click.prompt("What did you accomplish this session?")

        decision_list = []
        if click.confirm("Any decisions made?", default=False):
            while True:
                d = click.prompt("Decision (or 'done' to finish)", default="done")
                if d.lower() == "done":
                    break
                decision_list.append(d)

        lesson_list = []
        if click.confirm("Any lessons learned?", default=False):
            while True:
                lesson = click.prompt("Lesson (or 'done' to finish)", default="done")
                if lesson.lower() == "done":
                    break
                lesson_list.append(lesson)

        notes_input = click.prompt("Notes for next session?", default="", show_default=False)

        result = interactive_reflect(
            sdir,
            accomplishments=summary_input,
            decisions=decision_list or None,
            lessons=lesson_list or None,
            next_session_notes=notes_input or None,
        )
        console.print(
            Panel(
                f"[green]Reflect complete[/green]\n\n"
                f"Knowledge items created: {result['knowledge_created']}\n"
                f"Primer written to: {result['primer_path']}",
                title="sidecar reflect",
            )
        )


@cli.command()
@click.option("--json-output", "json_out", is_flag=True, help="Output as JSON")
def status(json_out: bool) -> None:
    """Show sidecar project health and status."""
    sdir = find_sidecar_dir()
    if not sdir:
        console.print("[dim]No sidecar project found. Run 'sidecar init'.[/dim]")
        return

    stats = get_detailed_stats(sdir)

    if json_out:
        out = {
            "phase": stats["phase"],
            "total": stats["total"],
            "by_type": stats["by_type"],
            "stale_count": stats["stale_count"],
            "domains": stats["domains"],
            "hooks": stats["hooks_installed"],
        }
        if stats["last_session"]:
            out["last_session"] = {
                "id": stats["last_session"].id,
                "ended_at": stats["last_session"].ended_at,
                "summary": stats["last_session"].summary,
            }
        click.echo(json.dumps(out, indent=2))
        return

    # Phase
    console.print(f"[bold]Phase:[/bold] {stats['phase']}")
    console.print()

    # Item counts table
    table = Table(title="Knowledge Store")
    table.add_column("Type", style="cyan")
    table.add_column("Count", style="green", justify="right")

    for ktype, count in sorted(stats["by_type"].items()):
        table.add_row(ktype, str(count))
    table.add_row("TOTAL", str(stats["total"]), style="bold")

    console.print(table)

    # Staleness warning
    if stats["stale_count"] > 0:
        console.print(f"\n[yellow]Stale items (>90 days): {stats['stale_count']}[/yellow]")

    # Domain distribution
    if stats["domains"]:
        console.print("\n[bold]Domains:[/bold]")
        for domain, count in stats["domains"].items():
            console.print(f"  {domain}: {count}")

    # Last session
    if stats["last_session"]:
        s = stats["last_session"]
        date = s.ended_at[:10] if s.ended_at else s.started_at[:10] if s.started_at else "unknown"
        console.print(f"\n[bold]Last session:[/bold] {date}")
        if s.summary:
            console.print(f"  {s.summary[:80]}")

    # Hook status
    hooks = stats["hooks_installed"]
    claude_status = (
        "[green]installed[/green]" if hooks.get("claude") else "[dim]not installed[/dim]"
    )
    git_status = "[green]installed[/green]" if hooks.get("git") else "[dim]not installed[/dim]"
    console.print("\n[bold]Hooks:[/bold]")
    console.print(f"  Claude Code: {claude_status}")
    console.print(f"  Git hooks:   {git_status}")


# ── Onboard Command ─────────────────────────────────────────────────────


@cli.command()
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation")
@click.option("--dry-run", is_flag=True, help="Show what would be imported without importing")
def onboard(yes: bool, dry_run: bool) -> None:
    """Auto-discover and import project knowledge.

    Scans for README, CLAUDE.md, ADRs, config files, and tech stack.
    Shows findings and confirms before importing.

    Examples:
      sidecar onboard            # Interactive scan + confirm
      sidecar onboard --dry-run  # Show what would be imported
      sidecar onboard -y         # Import without confirmation
    """
    try:
        sdir = require_sidecar_dir()
    except FileNotFoundError as e:
        console.print(f"[red]{e}[/red]")
        raise SystemExit(1) from None

    from .onboarding import apply_findings, scan_project

    project_dir = sdir.parent
    findings = scan_project(project_dir)

    if not findings:
        console.print("[dim]No importable knowledge found in this project.[/dim]")
        return

    # Display findings
    table = Table(title="Onboarding Scan Results")
    table.add_column("Source", style="cyan")
    table.add_column("Category", style="yellow")
    table.add_column("Items", style="green", justify="right")
    table.add_column("Description")

    total_items = 0
    for finding in findings:
        table.add_row(
            finding.source,
            finding.category,
            str(len(finding.items)),
            finding.description,
        )
        total_items += len(finding.items)

    console.print(table)
    console.print(f"\nTotal items to import: [bold]{total_items}[/bold]")

    if dry_run:
        console.print("\n[dim]Dry run — nothing imported.[/dim]")
        return

    if not yes and not click.confirm(f"\nImport {total_items} items?"):
        console.print("[dim]Cancelled.[/dim]")
        return

    created = apply_findings(findings, sdir)
    console.print(f"\n[green]Imported {created} knowledge items.[/green]")


# ── Depth (Phase) Command ────────────────────────────────────────────────


@cli.command()
@click.argument(
    "phase",
    required=False,
    type=click.Choice(["prototype", "mvp", "production", "scale"]),
)
def depth(phase: str | None) -> None:
    """Set or show the project phase (depth level).

    Phase affects which constraints are active:
      prototype  — minimal constraints, move fast
      mvp        — basic quality gates
      production — full constraints, safety checks
      scale      — performance + reliability constraints

    Examples:
      sidecar depth              # Show current phase
      sidecar depth production   # Set to production
    """
    try:
        sdir = require_sidecar_dir()
    except FileNotFoundError as e:
        console.print(f"[red]{e}[/red]")
        raise SystemExit(1) from None

    if phase is None:
        current = get_phase(sdir)
        console.print(f"Current phase: [bold]{current}[/bold]")
        console.print(f"\nAvailable: {', '.join(PHASES)}")
        console.print(
            "\nUse [cyan]sidecar depth <phase>[/cyan] to set, "
            "or [cyan]sidecar upgrade <phase>[/cyan] to audit and upgrade."
        )
        return

    set_phase(phase, sdir)
    console.print(f"[green]Phase set to: {phase}[/green]")


@cli.command("upgrade")
@click.argument(
    "target_phase",
    type=click.Choice(["mvp", "production", "scale"]),
)
@click.option("--auto", "auto_accept", is_flag=True, help="Auto-accept all critical findings")
def upgrade_cmd(target_phase: str, auto_accept: bool) -> None:
    """Audit and upgrade to a target phase.

    Runs gap analysis, shows findings, and optionally converts
    critical findings into constraints.

    Examples:
      sidecar upgrade production       # Audit + confirm each finding
      sidecar upgrade production --auto  # Auto-accept critical findings
    """
    try:
        sdir = require_sidecar_dir()
    except FileNotFoundError as e:
        console.print(f"[red]{e}[/red]")
        raise SystemExit(1) from None

    from .audit import run_audit

    current = get_phase(sdir)
    project_dir = sdir.parent

    findings = run_audit(project_dir, target_phase, current)

    if not findings:
        set_phase(target_phase, sdir)
        console.print(f"[green]No issues found. Phase upgraded to: {target_phase}[/green]")
        return

    # Display findings
    table = Table(title=f"Audit: {current} → {target_phase}")
    table.add_column("Severity", width=10)
    table.add_column("Category", style="yellow", width=14)
    table.add_column("Description")
    table.add_column("File", style="dim", width=30)

    critical_count = 0
    for f in findings:
        sev_style = "red bold" if f.severity == "critical" else "yellow"
        table.add_row(
            f"[{sev_style}]{f.severity}[/{sev_style}]",
            f.category,
            f.description,
            f.file_path or "",
        )
        if f.severity == "critical":
            critical_count += 1

    console.print(table)
    console.print(
        f"\n{len(findings)} findings ({critical_count} critical, "
        f"{len(findings) - critical_count} moderate)"
    )

    # Accept findings as constraints
    accepted = 0
    for f in findings:
        if not f.suggested_constraint:
            continue

        if auto_accept and f.severity == "critical":
            accept = True
        elif auto_accept:
            accept = False
        else:
            console.print(f"\n[bold]{f.description}[/bold]")
            console.print(f"  Suggested constraint: {f.suggested_constraint}")
            accept = click.confirm("  Accept as constraint?", default=f.severity == "critical")

        if accept:
            learn(
                f.suggested_constraint,
                type="constraint",
                min_phase=target_phase,
                source="audit",
            )
            accepted += 1

    if accepted:
        console.print(f"\n[green]Accepted {accepted} findings as constraints.[/green]")

    # Upgrade the phase
    set_phase(target_phase, sdir)
    console.print(f"[green]Phase upgraded to: {target_phase}[/green]")


# ── Export Command ────────────────────────────────────────────────────────


@cli.command("export")
@click.option("--tags", help="Filter by tags")
@click.option(
    "--type",
    "type_filter",
    type=click.Choice(["decision", "constraint", "relationship", "lesson"]),
    help="Filter by type",
)
@click.option(
    "--output",
    "-o",
    "output_file",
    type=click.Path(path_type=Path),
    help="Write to file instead of stdout",
)
def export_cmd(tags: str | None, type_filter: str | None, output_file: Path | None) -> None:
    """Export knowledge as a portable JSON package.

    Examples:
      sidecar export > knowledge.json
      sidecar export --tags auth,security -o auth-knowledge.json
      sidecar export --type constraint
    """
    try:
        sdir = require_sidecar_dir()
    except FileNotFoundError as e:
        console.print(f"[red]{e}[/red]")
        raise SystemExit(1) from None

    package = export_knowledge(sdir, tags=tags, type_filter=type_filter)

    output = json.dumps(package, indent=2)

    if output_file:
        output_file.write_text(output + "\n")
        console.print(f"[green]Exported {package['item_count']} items to {output_file}[/green]")
    else:
        click.echo(output)


# ── Import Package Command ───────────────────────────────────────────────


@cli.command("import-package")
@click.argument("package_file", type=click.Path(exists=True, path_type=Path))
def import_package_cmd(package_file: Path) -> None:
    """Import knowledge from a portable JSON package.

    Import packages created by 'sidecar export'.

    Examples:
      sidecar import-package knowledge.json
      sidecar import-package ~/other-project/auth-knowledge.json
    """
    try:
        sdir = require_sidecar_dir()
    except FileNotFoundError as e:
        console.print(f"[red]{e}[/red]")
        raise SystemExit(1) from None

    try:
        package = json.loads(package_file.read_text())
    except json.JSONDecodeError:
        console.print(f"[red]Invalid JSON in {package_file}[/red]")
        raise SystemExit(1) from None

    items = import_knowledge_package(sdir, package)
    source = package.get("source_project", "unknown")
    console.print(f"[green]Imported {len(items)} items from {source}[/green]")


# ── Supersede Command ────────────────────────────────────────────────────


@cli.command()
@click.argument("old_id_or_query")
@click.argument("new_content")
def supersede(old_id_or_query: str, new_content: str) -> None:
    """Replace a knowledge item with updated content.

    Accepts an item ID or a search query. If a query is given,
    finds the best match and confirms before superseding.

    Examples:
      sidecar supersede abc123 "Now using Redis 7 instead of Redis 6"
      sidecar supersede "Next.js 15" "Next.js 16.0.7 with App Router"
    """
    import re

    try:
        sdir = require_sidecar_dir()
    except FileNotFoundError as e:
        console.print(f"[red]{e}[/red]")
        raise SystemExit(1) from None

    old_id = old_id_or_query

    # If it doesn't look like a hex ID, treat as search query
    if not re.match(r"^[0-9a-f]{8,}$", old_id_or_query):
        results = recall(old_id_or_query, sidecar_dir=sdir)
        if not results:
            console.print(f'[yellow]No items matching "{old_id_or_query}".[/yellow]')
            raise SystemExit(1) from None

        # Show best match and confirm
        best = results[0]
        console.print(f"[bold]Best match:[/bold] [{best.id}] {best.content[:80]}")
        if not click.confirm("Supersede this item?", default=True):
            console.print("[dim]Cancelled.[/dim]")
            return
        old_id = best.id

    new_item = supersede_knowledge(sdir, old_id, new_content)
    if new_item:
        console.print(
            f"[green]Superseded {old_id} with new item {new_item.id}[/green]\n  {new_content}"
        )
    else:
        console.print(f"[yellow]Item {old_id} not found.[/yellow]")


# ── Hook Commands (for Claude Code integration) ──────────────────────────


@cli.group()
def hook() -> None:
    """Hook commands for Claude Code integration."""
    pass


@hook.command("prompt")
@click.argument("prompt_text", required=False, default=None)
def hook_prompt(prompt_text: str | None) -> None:
    """Process a user prompt and output relevant knowledge.

    Used as a Claude Code UserPromptSubmit hook. Output is injected
    into the agent's context. Reads prompt from argument, USER_PROMPT
    env var, or stdin.

    Example hook config:
      "command": "sidecar hook prompt"
    """
    import os
    import sys

    if not prompt_text:
        # Try env var (Claude Code sets USER_PROMPT for hooks)
        prompt_text = os.environ.get("USER_PROMPT", "")
    if not prompt_text and not sys.stdin.isatty():
        # Fallback: read from stdin
        prompt_text = sys.stdin.read().strip()
    if not prompt_text:
        prompt_text = ""

    output = prompt_hook(prompt_text)
    if output:
        click.echo(output)


@hook.command("stop")
def hook_stop() -> None:
    """Process a session stop event.

    Used as a Claude Code Stop hook. Outputs a reflect nudge
    if the session was substantive.

    Example hook config:
      "command": "sidecar hook stop"
    """
    output = stop_hook()
    if output:
        click.echo(output)


@hook.command("post-commit")
def hook_post_commit() -> None:
    """Process a post-commit event. Extracts decisions from commit messages.

    Used as a git post-commit hook.
    """
    result = _post_commit()
    if result["decisions_found"] > 0:
        for item in result["items_created"]:
            click.echo(f"[sidecar] Auto-captured decision: {item['content'][:80]}")


@hook.command("pre-commit")
def hook_pre_commit() -> None:
    """Process a pre-commit event. Surfaces impact warnings.

    Used as a git pre-commit hook. Never blocks the commit.
    """
    warnings = _pre_commit_warnings()
    for w in warnings:
        click.echo(f"[sidecar] {w}")


# ── Import Command ───────────────────────────────────────────────────────


@cli.command("import")
@click.argument("path", type=click.Path(exists=True, path_type=Path))
@click.option(
    "--type",
    "knowledge_type",
    default="decision",
    type=click.Choice(["decision", "constraint", "relationship", "lesson"]),
    help="Default knowledge type for imported items",
)
@click.option("--tag", help="Additional tag for imported items")
@click.option("--recursive", is_flag=True, help="Import all .md files from directory")
def import_cmd(path: Path, knowledge_type: str, tag: str | None, recursive: bool) -> None:  # noqa: ARG001
    """Import knowledge from markdown files or directories.

    Parses headings, bullets, and ADR format into separate knowledge items.

    Examples:
      sidecar import docs/architecture.md
      sidecar import docs/adrs/ --recursive
      sidecar import CLAUDE.md --type constraint
    """
    try:
        sdir = require_sidecar_dir()
    except FileNotFoundError as e:
        console.print(f"[red]{e}[/red]")
        raise SystemExit(1) from None

    if path.is_dir():
        items = import_directory(path, sdir, knowledge_type=knowledge_type)
    else:
        items = import_file(path, sdir, knowledge_type=knowledge_type, source_tag=tag)

    if items:
        console.print(f"[green]Imported {len(items)} knowledge items from {path}[/green]")
        for item in items[:5]:
            console.print(f"  [{item.type}] {item.content[:80]}")
        if len(items) > 5:
            console.print(f"  ... and {len(items) - 5} more")
    else:
        console.print(f"[dim]No knowledge items extracted from {path}[/dim]")


# ── Promote Command ──────────────────────────────────────────────────────


@cli.command()
@click.argument("item_id", required=False)
@click.option(
    "--list", "list_pending", is_flag=True, help="List auto-captured items awaiting promotion"
)
def promote(item_id: str | None, list_pending: bool) -> None:
    """Promote auto-captured knowledge to full confidence.

    Auto-captured items (from commits, auto-reflect) start at 0.7 confidence.
    Promoting them to 1.0 confirms they are accurate project knowledge.

    Examples:
      sidecar promote --list          # Show pending items
      sidecar promote abc123def456    # Promote specific item
    """
    try:
        sdir = require_sidecar_dir()
    except FileNotFoundError as e:
        console.print(f"[red]{e}[/red]")
        raise SystemExit(1) from None

    if list_pending:
        items = list_low_confidence(sdir)
        if not items:
            console.print("[dim]No auto-captured items pending promotion.[/dim]")
            return

        table = Table(title="Auto-captured Knowledge (pending promotion)")
        table.add_column("ID", style="cyan", width=14)
        table.add_column("Type", style="yellow", width=12)
        table.add_column("Content", style="white")
        table.add_column("Source", style="dim", width=10)

        for item in items:
            table.add_row(
                item.id,
                item.type,
                item.content[:60] + ("..." if len(item.content) > 60 else ""),
                item.source,
            )

        console.print(table)
        console.print("\nRun [cyan]sidecar promote <ID>[/cyan] to confirm an item.")
        return

    if not item_id:
        console.print("[yellow]Provide an item ID or use --list to see pending items.[/yellow]")
        return

    if promote_knowledge(sdir, item_id):
        console.print(f"[green]Promoted {item_id} to full confidence.[/green]")
    else:
        console.print(f"[yellow]Item {item_id} not found or already at full confidence.[/yellow]")


# ── Install Git Hooks Command ────────────────────────────────────────────


@cli.command("install-git-hooks")
def install_git_hooks_cmd() -> None:
    """Install git hooks for passive knowledge capture.

    Installs post-commit (decision extraction) and pre-commit (impact warnings).
    """
    result = _install_git_hooks()

    if "error" in result:
        console.print(f"[red]{result['error']}[/red]")
        raise SystemExit(1) from None

    for hook_info in result["hooks_installed"]:
        status = hook_info["status"]
        name = hook_info["name"]
        if status == "created":
            console.print(f"  [green]Created {name} hook[/green]")
        elif status == "appended":
            console.print(f"  [yellow]Appended to existing {name} hook[/yellow]")
        elif status == "already_installed":
            console.print(f"  [dim]{name} hook already has sidecar[/dim]")

    console.print(f"\nHooks directory: {result.get('paths', 'unknown')}")


# ── Install Claude Code Hooks Command ────────────────────────────────────


HOOKS_CONFIG = {
    "hooks": {
        "UserPromptSubmit": [
            {
                "matcher": "",
                "hooks": [
                    {
                        "type": "command",
                        "command": "sidecar hook prompt",
                        "timeout": 2000,
                    }
                ],
            }
        ],
        "Stop": [
            {
                "matcher": "",
                "hooks": [
                    {
                        "type": "command",
                        "command": "sidecar hook stop",
                        "timeout": 2000,
                    }
                ],
            }
        ],
    }
}


def _merge_claude_hooks(project_dir: Path) -> Path:
    """Merge sidecar hooks into .claude/settings.local.json. Returns settings path."""
    claude_dir = project_dir / ".claude"
    settings_path = claude_dir / "settings.local.json"

    existing = {}
    if settings_path.exists():
        with contextlib.suppress(json.JSONDecodeError):
            existing = json.loads(settings_path.read_text())

    if "hooks" not in existing:
        existing["hooks"] = {}

    for event, matcher_groups in HOOKS_CONFIG["hooks"].items():
        if event not in existing["hooks"]:
            existing["hooks"][event] = []

        # Collect all existing hook commands to avoid duplicates
        existing_cmds: set[str] = set()
        for group in existing["hooks"][event]:
            for hook in group.get("hooks", []):
                existing_cmds.add(hook.get("command", ""))

        for new_group in matcher_groups:
            # Check if any hook in this group is already installed
            new_hooks = [h for h in new_group["hooks"] if h["command"] not in existing_cmds]
            if new_hooks:
                existing["hooks"][event].append(
                    {"matcher": new_group["matcher"], "hooks": new_hooks}
                )

    claude_dir.mkdir(exist_ok=True)
    settings_path.write_text(json.dumps(existing, indent=2) + "\n")
    return settings_path


@cli.command("install-hooks")
@click.option("--dry-run", is_flag=True, help="Show what would be written without modifying files")
def install_hooks(dry_run: bool) -> None:
    """Install Claude Code hooks for auto-injection.

    Writes hook configuration to .claude/settings.local.json.
    """
    project_dir = Path.cwd()

    if dry_run:
        settings_path = project_dir / ".claude" / "settings.local.json"
        console.print("[bold]Would write to:[/bold]", str(settings_path))
        console.print(json.dumps(HOOKS_CONFIG, indent=2))
        return

    settings_path = _merge_claude_hooks(project_dir)

    console.print(
        Panel(
            f"[green]Hooks installed![/green]\n\n"
            f"Written to: {settings_path}\n\n"
            f"Hooks configured:\n"
            f"  UserPromptSubmit: auto-inject relevant knowledge\n"
            f"  Stop: suggest reflect at session end\n\n"
            f"Sidecar will now automatically inject project knowledge\n"
            f"into your Claude Code sessions.",
            title="sidecar install-hooks",
        )
    )


@cli.command("install-skill")
def install_skill() -> None:
    """Install the sidecar Claude Code skill.

    Copies SKILL.md to .claude/skills/sidecar/ for Claude Code discovery.
    """
    project_dir = Path.cwd()
    skill_dir = project_dir / ".claude" / "skills" / "sidecar"
    skill_dir.mkdir(parents=True, exist_ok=True)

    # Read the bundled skill template
    template = Path(__file__).parent / "templates" / "skill.md"
    if not template.exists():
        console.print("[red]Skill template not found.[/red]")
        raise SystemExit(1) from None

    dest = skill_dir / "SKILL.md"
    dest.write_text(template.read_text())
    console.print(f"[green]Skill installed to {dest}[/green]")


_SIDECAR_KNOWLEDGE = [
    {
        "content": 'To update a knowledge item: run `sidecar recall "search terms"` to find the item ID, then `sidecar supersede <ID> "new content"`',
        "type": "decision",
        "domain": "sidecar",
        "tags": "sidecar,commands",
    },
    {
        "content": 'To store project knowledge: `sidecar learn "content"` (decision), `sidecar learn --constraint "rule"`, `sidecar learn --lesson "insight"`',
        "type": "decision",
        "domain": "sidecar",
        "tags": "sidecar,commands",
    },
    {
        "content": 'To search knowledge: `sidecar recall "query"`. To delete: `sidecar delete <ID>`. To see status: `sidecar status`',
        "type": "decision",
        "domain": "sidecar",
        "tags": "sidecar,commands",
    },
    {
        "content": 'To log sidecar feedback: `sidecar feedback "description"` with optional `--type bug|enhancement|observation`',
        "type": "decision",
        "domain": "sidecar",
        "tags": "sidecar,commands",
    },
    {
        "content": "To compile knowledge into documents: `sidecar compile -o CLAUDE.md` or `sidecar compile --format skill -o SKILL.md`",
        "type": "decision",
        "domain": "sidecar",
        "tags": "sidecar,commands",
    },
]


def _seed_sidecar_knowledge(sdir: Path) -> int:
    """Seed sidecar command usage knowledge. Returns count of new items."""
    created = 0
    for item_data in _SIDECAR_KNOWLEDGE:
        try:
            item = learn(
                item_data["content"],
                type=item_data["type"],
                domain=item_data["domain"],
                tags=item_data["tags"],
                source="sidecar:setup",
                sidecar_dir=sdir,
            )
            if item.source == "sidecar:setup":
                created += 1
        except (ValueError, FileNotFoundError):
            continue
    return created


@cli.command("setup")
def setup() -> None:
    """One-command setup: init + install hooks + install skill.

    Initializes sidecar, installs Claude Code hooks, and installs the skill.
    """
    project_dir = Path.cwd()

    # Init
    sdir = find_sidecar_dir(project_dir)
    if not sdir or sdir.parent != project_dir:
        init_project(project_dir)
        console.print("[green]Initialized .sidecar/[/green]")
    else:
        console.print("[dim].sidecar/ already exists[/dim]")

    # Install hooks
    _merge_claude_hooks(project_dir)
    console.print("[green]Installed Claude Code hooks[/green]")

    # Install skill
    skill_dir = project_dir / ".claude" / "skills" / "sidecar"
    skill_dir.mkdir(parents=True, exist_ok=True)
    template = Path(__file__).parent / "templates" / "skill.md"
    if template.exists():
        (skill_dir / "SKILL.md").write_text(template.read_text())
        console.print("[green]Installed Claude Code skill[/green]")

    # Install git hooks (only if in a git repo)
    try:
        git_result = _install_git_hooks()
        if "error" not in git_result:
            console.print("[green]Installed git hooks (post-commit, pre-commit)[/green]")
        else:
            console.print(f"[dim]Skipped git hooks: {git_result.get('error', 'unknown')}[/dim]")
    except (OSError, FileNotFoundError):
        console.print("[dim]Skipped git hooks (not a git repository)[/dim]")

    # Seed sidecar command knowledge
    sdir = find_sidecar_dir(project_dir)
    if sdir:
        seeded = _seed_sidecar_knowledge(sdir)
        if seeded:
            console.print(f"[green]Seeded {seeded} sidecar usage hints[/green]")

    console.print(
        Panel(
            "Sidecar is ready!\n\n"
            "Next steps:\n"
            '  sidecar learn "your first project decision"\n'
            '  sidecar recall "test a query"\n\n'
            "Knowledge will auto-inject into your Claude Code sessions.\n"
            "Decisions will auto-capture from commit messages.",
            title="sidecar setup",
            border_style="green",
        )
    )


# ── Rebuild Command ───────────────────────────────────────────────────────


@cli.command()
def rebuild() -> None:
    """Rebuild the database from mirror markdown files.

    Use this when the database is corrupted or lost. Reads all .md files
    from .sidecar/knowledge/ and reconstructs the database.
    """
    try:
        sdir = require_sidecar_dir()
    except FileNotFoundError as e:
        console.print(f"[red]{e}[/red]")
        raise SystemExit(1) from None

    items = read_mirrors(sdir)
    if not items:
        console.print("[yellow]No mirror files found to rebuild from.[/yellow]")
        return

    from .db import get_db, insert_knowledge
    from .retrieval import compute_embedding

    # Remove old database and create fresh
    db_path = sdir / "db.sqlite"
    if db_path.exists():
        backup = db_path.with_suffix(".sqlite.bak")
        db_path.rename(backup)
        console.print(f"[dim]Backed up existing database to {backup.name}[/dim]")

    conn = get_db(db_path)
    restored = 0
    for item in items:
        item.embedding = compute_embedding(item.content)
        insert_knowledge(conn, item)
        restored += 1
    conn.close()

    console.print(f"[green]Rebuilt database with {restored} items from mirror files.[/green]")


# ── Delete Command ────────────────────────────────────────────────────────


@cli.command()
@click.argument("item_id")
@click.option("--force", is_flag=True, help="Skip confirmation")
def delete(item_id: str, force: bool) -> None:
    """Delete a knowledge item permanently.

    Removes the item from the database and its mirror file.

    Examples:
      sidecar delete abc123def456
      sidecar delete abc123def456 --force
    """
    try:
        sdir = require_sidecar_dir()
    except FileNotFoundError as e:
        console.print(f"[red]{e}[/red]")
        raise SystemExit(1) from None

    from .db import get_db, get_knowledge_by_id
    from .mirror import delete_mirror

    conn = get_db(sdir / "db.sqlite")
    item = get_knowledge_by_id(conn, item_id)

    if not item:
        conn.close()
        console.print(f"[yellow]Item {item_id} not found.[/yellow]")
        return

    if not force:
        console.print(f"  [{item.type}] {item.content[:80]}")
        if not click.confirm("Delete this item?"):
            conn.close()
            return

    conn.execute("DELETE FROM knowledge WHERE id = ?", (item_id,))
    conn.commit()
    conn.close()

    delete_mirror(sdir, item)
    console.print(f"[green]Deleted {item_id}.[/green]")


# ── Backfill Domains Command ──────────────────────────────────────────────


@cli.command("backfill-domains")
def backfill_domains_cmd() -> None:
    """Infer and set domains for existing knowledge items.

    Analyzes content of items without domains and auto-assigns
    detected domains (frontend, backend, security, etc.).
    """
    try:
        sdir = require_sidecar_dir()
    except FileNotFoundError as e:
        console.print(f"[red]{e}[/red]")
        raise SystemExit(1) from None

    from .knowledge import backfill_domains

    updated = backfill_domains(sdir)
    console.print(f"[green]Updated {updated} items with auto-detected domains.[/green]")


# ── Compile Command ──────────────────────────────────────────────────────


@cli.command("compile")
@click.option(
    "--format",
    "fmt",
    type=click.Choice(["claude-md", "skill", "primer"]),
    default="claude-md",
    help="Output format (default: claude-md)",
)
@click.option(
    "--output",
    "-o",
    "output_file",
    type=click.Path(path_type=Path),
    help="Write to file instead of stdout",
)
@click.option("--domain", help="Filter by domain")
def compile_cmd(fmt: str, output_file: Path | None, domain: str | None) -> None:
    """Compile knowledge store into a document.

    Formats:
      claude-md  — CLAUDE.md-style project document (default)
      skill      — SKILL.md with progressive disclosure
      primer     — Session primer for next session

    Examples:
      sidecar compile                          # CLAUDE.md to stdout
      sidecar compile --format skill           # SKILL.md format
      sidecar compile --format primer          # Session primer
      sidecar compile -o CLAUDE.md             # Write to file
      sidecar compile --domain backend         # Filter by domain
    """
    try:
        sdir = require_sidecar_dir()
    except FileNotFoundError as e:
        console.print(f"[red]{e}[/red]")
        raise SystemExit(1) from None

    from .compiler import compile_knowledge

    output = compile_knowledge(sidecar_dir=sdir, format=fmt, domain_filter=domain)

    if output_file:
        output_file.write_text(output)
        console.print(f"[green]Compiled {fmt} written to {output_file}[/green]")
    else:
        click.echo(output)


# ── Conflicts Command ────────────────────────────────────────────────────


@cli.command()
def conflicts() -> None:
    """Detect potentially conflicting knowledge items.

    Finds items that may contradict each other based on:
    - Opposing guidance (use X vs don't use X)
    - Competing technology decisions
    - Contradictory constraints (always vs never)

    Examples:
      sidecar conflicts
    """
    try:
        sdir = require_sidecar_dir()
    except FileNotFoundError as e:
        console.print(f"[red]{e}[/red]")
        raise SystemExit(1) from None

    found = detect_conflicts(sidecar_dir=sdir)

    if not found:
        console.print("[green]No conflicts detected.[/green]")
        return

    console.print(f"[yellow]Found {len(found)} potential conflict(s):[/yellow]\n")

    for i, (a, b, reason) in enumerate(found, 1):
        console.print(f"[bold]Conflict {i}:[/bold] {reason}")
        console.print(f"  [cyan]{a.id}[/cyan] [{a.type}] {a.content[:70]}")
        console.print(f"  [cyan]{b.id}[/cyan] [{b.type}] {b.content[:70]}")
        console.print()

    console.print(
        "Actions:\n"
        '  [cyan]sidecar supersede <ID> "updated content"[/cyan]  — replace the outdated one\n'
        "  [cyan]sidecar delete <ID>[/cyan]  — remove the wrong one"
    )


# ── Stale Command ────────────────────────────────────────────────────────


@cli.command()
@click.option("--days", default=90, help="Staleness threshold in days (default: 90)")
@click.option("--refresh", "refresh_id", help="Re-validate an item by ID")
def stale(days: int, refresh_id: str | None) -> None:
    """List stale knowledge items or refresh them.

    Items older than the threshold (default 90 days) may be outdated.
    Review and either refresh (re-validate) or supersede/delete them.

    Examples:
      sidecar stale              # List stale items (>90 days)
      sidecar stale --days 30    # Custom threshold
      sidecar stale --refresh ID # Re-validate an item
    """
    try:
        sdir = require_sidecar_dir()
    except FileNotFoundError as e:
        console.print(f"[red]{e}[/red]")
        raise SystemExit(1) from None

    if refresh_id:
        if refresh_item(refresh_id, sidecar_dir=sdir):
            console.print(f"[green]Refreshed {refresh_id} — marked as re-validated.[/green]")
        else:
            console.print(f"[yellow]Item {refresh_id} not found or already superseded.[/yellow]")
        return

    items = get_stale_items(sidecar_dir=sdir, days=days)

    if not items:
        console.print(f"[green]No stale items (threshold: {days} days).[/green]")
        return

    table = Table(title=f"Stale Knowledge Items (>{days} days)")
    table.add_column("ID", style="cyan", width=14)
    table.add_column("Type", style="yellow", width=12)
    table.add_column("Content", style="white")
    table.add_column("Age", style="red", justify="right", width=8)

    for item in items:
        age = ""
        if item.created_at:
            from datetime import UTC, datetime

            try:
                created = datetime.fromisoformat(item.created_at)
                age_days = (datetime.now(UTC) - created).days
                age = f"{age_days}d"
            except (ValueError, TypeError):
                age = "?"

        table.add_row(
            item.id,
            item.type,
            item.content[:60] + ("..." if len(item.content) > 60 else ""),
            age,
        )

    console.print(table)
    console.print(
        f"\n{len(items)} stale items. Actions:\n"
        f"  [cyan]sidecar stale --refresh <ID>[/cyan]  — re-validate\n"
        f'  [cyan]sidecar supersede <ID> "new content"[/cyan]  — replace\n'
        f"  [cyan]sidecar delete <ID>[/cyan]  — remove"
    )


# ── Feedback & Dogfood Commands ──────────────────────────────────────────


@cli.command()
@click.argument("content")
@click.option(
    "--type",
    "feedback_type",
    type=click.Choice(["bug", "enhancement", "observation"]),
    default="observation",
    help="Feedback type",
)
def feedback(content: str, feedback_type: str) -> None:
    """Log feedback about sidecar's behavior.

    Used during dogfood testing to capture issues, enhancements,
    and observations. Entries are appended to .sidecar/feedback.md.

    Examples:
      sidecar feedback "recall results were noisy for auth queries"
      sidecar feedback --type bug "hook timed out on large prompt"
      sidecar feedback --type enhancement "want confidence filter on recall"
    """
    from .knowledge import append_feedback

    try:
        sdir = require_sidecar_dir()
    except FileNotFoundError as e:
        console.print(f"[red]{e}[/red]")
        raise SystemExit(1) from None

    path = append_feedback(content, feedback_type=feedback_type, sidecar_dir=sdir)
    console.print(f"[green]Feedback logged to {path}[/green]")


@cli.command("feedback-list")
def feedback_list() -> None:
    """Show collected feedback entries."""
    try:
        sdir = require_sidecar_dir()
    except FileNotFoundError as e:
        console.print(f"[red]{e}[/red]")
        raise SystemExit(1) from None

    feedback_path = sdir / "feedback.md"
    if not feedback_path.exists():
        console.print("[yellow]No feedback logged yet.[/yellow]")
        return

    console.print(feedback_path.read_text())


@cli.command("feedback-export")
@click.option(
    "--output", "-o", "output_file", type=click.Path(path_type=Path), help="Write to file"
)
def feedback_export(output_file: Path | None) -> None:
    """Export feedback as JSON."""
    import re

    try:
        sdir = require_sidecar_dir()
    except FileNotFoundError as e:
        console.print(f"[red]{e}[/red]")
        raise SystemExit(1) from None

    feedback_path = sdir / "feedback.md"
    if not feedback_path.exists():
        console.print("[yellow]No feedback to export.[/yellow]")
        return

    # Parse markdown entries
    entries = []
    text = feedback_path.read_text()
    pattern = re.compile(r"## (\S+) \[(\w+)\]\n(.+?)(?=\n## |\Z)", re.DOTALL)
    for match in pattern.finditer(text):
        entries.append(
            {
                "timestamp": match.group(1),
                "type": match.group(2),
                "content": match.group(3).strip(),
            }
        )

    output = json.dumps(entries, indent=2)
    if output_file:
        output_file.write_text(output)
        console.print(f"[green]Exported {len(entries)} entries to {output_file}[/green]")
    else:
        click.echo(output)


@cli.command()
def sessions() -> None:
    """Show session instrumentation metrics.

    Displays logged session data: prompt counts, items injected,
    files changed, and relevance scores. Relevance measures how
    well injected knowledge matched the files that were modified.

    Examples:
      sidecar sessions        # Show recent session metrics
    """
    try:
        sdir = require_sidecar_dir()
    except FileNotFoundError as e:
        console.print(f"[red]{e}[/red]")
        raise SystemExit(1) from None

    log_path = sdir / "sessions-log.jsonl"
    if not log_path.exists():
        console.print(
            "[yellow]No session data yet. Sessions are logged automatically by hooks.[/yellow]"
        )
        return

    import json as json_mod

    entries = []
    for line in log_path.read_text().splitlines():
        line = line.strip()
        if line:
            try:
                entries.append(json_mod.loads(line))
            except json_mod.JSONDecodeError:
                continue

    if not entries:
        console.print("[yellow]No session data recorded.[/yellow]")
        return

    from rich.table import Table

    table = Table(title="Session Metrics")
    table.add_column("Date", style="dim")
    table.add_column("Prompts", justify="right")
    table.add_column("Injected", justify="right")
    table.add_column("Files Changed", justify="right")
    table.add_column("Relevance Hits", justify="right")
    table.add_column("Relevance %", justify="right")

    for entry in entries[-20:]:  # Last 20 sessions
        ts = entry.get("timestamp", "")[:16]
        relevance_pct = f"{entry.get('relevance_score', 0) * 100:.0f}%"
        style = ""
        score = entry.get("relevance_score", 0)
        if score >= 0.5:
            style = "green"
        elif score >= 0.2:
            style = "yellow"
        elif entry.get("files_changed", 0) > 0:
            style = "red"

        table.add_row(
            ts,
            str(entry.get("prompt_count", 0)),
            str(entry.get("items_injected", 0)),
            str(entry.get("files_changed", 0)),
            str(entry.get("relevance_hits", 0)),
            relevance_pct,
            style=style,
        )

    console.print(table)

    # Summary stats
    if len(entries) >= 2:
        avg_relevance = sum(e.get("relevance_score", 0) for e in entries) / len(entries)
        avg_prompts = sum(e.get("prompt_count", 0) for e in entries) / len(entries)
        total_injected = sum(e.get("items_injected", 0) for e in entries)
        console.print(
            f"\n[dim]Avg relevance: {avg_relevance * 100:.0f}% | "
            f"Avg prompts/session: {avg_prompts:.1f} | "
            f"Total items injected: {total_injected}[/dim]"
        )


# ── Mode Command ─────────────────────────────────────────────────────────


@cli.command()
@click.argument("new_mode", required=False, type=click.Choice(["active", "observe", "disabled"]))
def mode(new_mode: str | None) -> None:
    """Show or set sidecar mode.

    Modes:
      active    — inject knowledge + capture at session end (default)
      observe   — capture only, no injection into prompts
      disabled  — hooks are fully bypassed

    Examples:
      sidecar mode              # Show current mode
      sidecar mode observe      # Switch to observe
      sidecar mode active       # Back to normal
    """
    from .knowledge import get_mode, set_mode

    try:
        sdir = require_sidecar_dir()
    except FileNotFoundError as e:
        console.print(f"[red]{e}[/red]")
        raise SystemExit(1) from None

    if new_mode is None:
        current = get_mode(sdir)
        descriptions = {
            "active": "inject knowledge + capture at session end",
            "observe": "capture only, no injection into prompts",
            "disabled": "hooks are fully bypassed",
        }
        console.print(f"Current mode: [bold]{current}[/bold] — {descriptions[current]}")
        return

    set_mode(new_mode, sdir)
    console.print(f"[green]Mode set to: {new_mode}[/green]")


# ── Ecosystem Commands ────────────────────────────────────────────────────


@cli.group()
def ecosystem() -> None:
    """Discover, recommend, and manage AI coding tools."""
    pass


@ecosystem.command("scan")
def ecosystem_scan() -> None:
    """List all available tools in the ecosystem index."""
    sdir = find_sidecar_dir()
    tools = scan(sdir)
    console.print(format_scan_results(tools))


@ecosystem.command("recommend")
@click.option("--top", "top_k", default=5, help="Number of recommendations")
def ecosystem_recommend(top_k: int) -> None:
    """Recommend tools based on your project profile."""
    sdir = find_sidecar_dir()
    project_dir = sdir.parent if sdir else Path.cwd()
    profile = build_profile(sdir, project_dir)

    if not profile.domains:
        console.print(
            "[yellow]Could not detect project profile. Add knowledge with 'sidecar learn' first.[/yellow]"
        )
        return

    console.print(f"[dim]Detected domains: {', '.join(profile.domains)}[/dim]")
    if profile.technologies:
        console.print(f"[dim]Technologies: {', '.join(profile.technologies)}[/dim]")
    if profile.concerns:
        console.print(f"[dim]Concerns: {', '.join(profile.concerns)}[/dim]")
    console.print()

    recs = recommend(profile, sidecar_dir=sdir, top_k=top_k)
    console.print(format_recommendations(recs))


@ecosystem.command("profile")
def ecosystem_profile() -> None:
    """Show the detected project profile."""
    sdir = find_sidecar_dir()
    project_dir = sdir.parent if sdir else Path.cwd()
    profile = build_profile(sdir, project_dir)

    table = Table(title="Project Profile")
    table.add_column("Attribute", style="cyan")
    table.add_column("Values")

    table.add_row("Domains", ", ".join(sorted(profile.domains)) or "none detected")
    table.add_row("Technologies", ", ".join(sorted(profile.technologies)) or "none detected")
    table.add_row("Concerns", ", ".join(sorted(profile.concerns)) or "none detected")

    console.print(table)


# ── Recipe Commands ──────────────────────────────────────────────────────


@cli.group()
def recipe() -> None:
    """Manage curated knowledge bundles (recipes)."""
    pass


@recipe.command("search")
@click.argument("query")
def recipe_search(query: str) -> None:
    """Search available recipes.

    Examples:
      sidecar recipe search "python"
      sidecar recipe search "react"
    """
    from .recipes import load_preset_index, search_recipes

    index = load_preset_index()
    results = search_recipes(query, index)

    if not results:
        console.print(f"[dim]No recipes matching '{query}'.[/dim]")
        return

    table = Table(title=f"Recipes matching '{query}'")
    table.add_column("Name", style="cyan")
    table.add_column("Stack", style="yellow")
    table.add_column("Items", justify="right")
    table.add_column("Description")

    for r in results:
        table.add_row(r.name, r.stack, str(len(r.items)), r.description)

    console.print(table)


@recipe.command("inspect")
@click.argument("name")
def recipe_inspect(name: str) -> None:
    """Preview a recipe's contents.

    Examples:
      sidecar recipe inspect fastapi
    """
    from .recipes import inspect_recipe, load_preset_index

    index = load_preset_index()
    match = next((r for r in index if r.name == name), None)

    if not match:
        console.print(f"[yellow]Recipe '{name}' not found.[/yellow]")
        available = ", ".join(r.name for r in index)
        if available:
            console.print(f"Available: {available}")
        return

    console.print(Panel(inspect_recipe(match), title=f"Recipe: {name}"))


@recipe.command("install")
@click.argument("name")
def recipe_install(name: str) -> None:
    """Install a recipe into the knowledge store.

    Examples:
      sidecar recipe install fastapi
      sidecar recipe install cli-python
    """
    try:
        sdir = require_sidecar_dir()
    except FileNotFoundError as e:
        console.print(f"[red]{e}[/red]")
        raise SystemExit(1) from None

    from .recipes import install_recipe, load_preset_index

    index = load_preset_index()
    match = next((r for r in index if r.name == name), None)

    if not match:
        console.print(f"[yellow]Recipe '{name}' not found.[/yellow]")
        return

    created = install_recipe(match, sidecar_dir=sdir)
    console.print(f"[green]Installed recipe '{name}': {created} items added.[/green]")


@recipe.command("list")
def recipe_list() -> None:
    """Show installed recipes.

    Examples:
      sidecar recipe list
    """
    try:
        sdir = require_sidecar_dir()
    except FileNotFoundError as e:
        console.print(f"[red]{e}[/red]")
        raise SystemExit(1) from None

    from .recipes import list_installed

    installed = list_installed(sidecar_dir=sdir)

    if not installed:
        console.print("[dim]No recipes installed.[/dim]")
        return

    table = Table(title="Installed Recipes")
    table.add_column("Name", style="cyan")
    table.add_column("Version", style="yellow")
    table.add_column("Items", justify="right")
    table.add_column("Installed", style="dim")

    for r in installed:
        date = r.get("installed_at", "")[:10]
        table.add_row(r["name"], r.get("version", "?"), str(r.get("item_count", 0)), date)

    console.print(table)


@recipe.command("extract")
@click.option(
    "--output",
    "-o",
    "output_file",
    type=click.Path(path_type=Path),
    help="Write recipe to YAML file",
)
def recipe_extract(output_file: Path | None) -> None:
    """Extract a recipe from this project's knowledge.

    Packages all knowledge items into a portable recipe format.

    Examples:
      sidecar recipe extract -o my-project.yaml
    """
    try:
        sdir = require_sidecar_dir()
    except FileNotFoundError as e:
        console.print(f"[red]{e}[/red]")
        raise SystemExit(1) from None

    from .recipes import extract_recipe

    project_dir = sdir.parent
    extracted = extract_recipe(project_dir, sidecar_dir=sdir)

    recipe_data = {
        "name": extracted.name,
        "description": extracted.description,
        "version": extracted.version,
        "stack": extracted.stack,
        "items": extracted.items,
    }

    output = yaml.dump(recipe_data, default_flow_style=False)

    if output_file:
        output_file.write_text(output)
        console.print(
            f"[green]Extracted recipe '{extracted.name}' with "
            f"{len(extracted.items)} items to {output_file}[/green]"
        )
    else:
        click.echo(output)


def main() -> None:
    cli()


if __name__ == "__main__":
    main()
