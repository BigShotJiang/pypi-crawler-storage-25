"""SQLite database layer using stdlib sqlite3.

Two tables: knowledge and sessions. No ORM. Schema versioned via PRAGMA user_version.
"""

from __future__ import annotations

import sqlite3
import uuid
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path

SCHEMA_VERSION = 3

SCHEMA_V1 = """\
CREATE TABLE IF NOT EXISTS knowledge (
    id TEXT PRIMARY KEY,
    type TEXT NOT NULL,
    content TEXT NOT NULL,
    tags TEXT,
    source TEXT NOT NULL DEFAULT 'explicit',
    confidence REAL NOT NULL DEFAULT 1.0,
    created_at TEXT NOT NULL,
    superseded_by TEXT,
    project TEXT,
    embedding BLOB,
    domain TEXT,
    min_phase TEXT
);

CREATE TABLE IF NOT EXISTS sessions (
    id TEXT PRIMARY KEY,
    started_at TEXT,
    ended_at TEXT,
    summary TEXT,
    files_touched TEXT,
    knowledge_ids TEXT
);

CREATE INDEX IF NOT EXISTS idx_knowledge_type ON knowledge(type);
CREATE INDEX IF NOT EXISTS idx_knowledge_tags ON knowledge(tags);
CREATE INDEX IF NOT EXISTS idx_knowledge_project ON knowledge(project);
CREATE INDEX IF NOT EXISTS idx_knowledge_domain ON knowledge(domain);
"""

MIGRATIONS: dict[int, str] = {
    2: """\
CREATE INDEX IF NOT EXISTS idx_knowledge_confidence ON knowledge(confidence);
CREATE INDEX IF NOT EXISTS idx_knowledge_superseded ON knowledge(superseded_by);
""",
    3: """\
ALTER TABLE knowledge ADD COLUMN domain TEXT;
ALTER TABLE knowledge ADD COLUMN min_phase TEXT;
CREATE INDEX IF NOT EXISTS idx_knowledge_domain ON knowledge(domain);
""",
}


def _migrate(conn: sqlite3.Connection, from_version: int) -> None:
    """Run incremental migrations from from_version to SCHEMA_VERSION."""
    for version in range(from_version + 1, SCHEMA_VERSION + 1):
        migration_sql = MIGRATIONS.get(version)
        if migration_sql:
            conn.executescript(migration_sql)
    conn.execute(f"PRAGMA user_version = {SCHEMA_VERSION}")
    conn.commit()


@dataclass
class KnowledgeItem:
    id: str
    type: str  # 'decision', 'constraint', 'relationship', 'lesson'
    content: str
    tags: str | None = None
    source: str = "explicit"
    confidence: float = 1.0
    created_at: str = ""
    superseded_by: str | None = None
    project: str | None = None
    embedding: bytes | None = None
    domain: str | None = None
    min_phase: str | None = None

    def __post_init__(self) -> None:
        if not self.id:
            self.id = uuid.uuid4().hex[:12]
        if not self.created_at:
            self.created_at = datetime.now(UTC).isoformat()


@dataclass
class Session:
    id: str
    started_at: str | None = None
    ended_at: str | None = None
    summary: str | None = None
    files_touched: list[str] = field(default_factory=list)
    knowledge_ids: list[str] = field(default_factory=list)


class DatabaseError(Exception):
    """Raised when the sidecar database is corrupted or inaccessible."""


def get_db(db_path: Path) -> sqlite3.Connection:
    """Open (or create) the sidecar database and ensure schema is current."""
    try:
        conn = sqlite3.connect(str(db_path))
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA foreign_keys=ON")

        # Quick integrity check on existing databases
        if db_path.stat().st_size > 0:
            result = conn.execute("PRAGMA quick_check").fetchone()
            if result[0] != "ok":
                conn.close()
                raise DatabaseError(
                    f"Database corruption detected in {db_path}. "
                    f"Run 'sidecar rebuild' to restore from mirror files, "
                    f"or delete {db_path} and run 'sidecar init'."
                )

        version = conn.execute("PRAGMA user_version").fetchone()[0]
        if version == 0:
            # Fresh database — apply initial schema
            conn.executescript(SCHEMA_V1)
            conn.execute(f"PRAGMA user_version = {SCHEMA_VERSION}")
            conn.commit()
        elif version < SCHEMA_VERSION:
            # Existing database — run incremental migrations
            _migrate(conn, version)

        return conn
    except sqlite3.DatabaseError as e:
        raise DatabaseError(
            f"Cannot open database {db_path}: {e}. "
            f"The file may be corrupted. Delete it and run 'sidecar init', "
            f"or run 'sidecar rebuild' to restore from mirror files."
        ) from None


def insert_knowledge(conn: sqlite3.Connection, item: KnowledgeItem) -> str:
    """Insert a knowledge item. Returns the item id."""
    conn.execute(
        """INSERT INTO knowledge (id, type, content, tags, source, confidence,
           created_at, superseded_by, project, embedding, domain, min_phase)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (
            item.id,
            item.type,
            item.content,
            item.tags,
            item.source,
            item.confidence,
            item.created_at,
            item.superseded_by,
            item.project,
            item.embedding,
            item.domain,
            item.min_phase,
        ),
    )
    conn.commit()
    return item.id


def query_knowledge(
    conn: sqlite3.Connection,
    *,
    type_filter: str | None = None,
    tag_filter: str | None = None,
    domain_filter: str | None = None,
    project_filter: str | None = None,
    include_superseded: bool = False,
    limit: int | None = None,
) -> list[KnowledgeItem]:
    """Query knowledge items with optional filters."""
    clauses: list[str] = []
    params: list[str | float] = []

    if not include_superseded:
        clauses.append("superseded_by IS NULL")

    if type_filter:
        clauses.append("type = ?")
        params.append(type_filter)

    if tag_filter:
        clauses.append("tags LIKE ?")
        params.append(f"%{tag_filter}%")

    if domain_filter:
        clauses.append("domain LIKE ?")
        params.append(f"%{domain_filter}%")

    if project_filter:
        clauses.append("project = ?")
        params.append(project_filter)

    where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
    limit_clause = f" LIMIT {int(limit)}" if limit is not None else ""
    rows = conn.execute(
        f"SELECT * FROM knowledge {where} ORDER BY created_at DESC{limit_clause}", params
    ).fetchall()

    return [KnowledgeItem(**dict(row)) for row in rows]


def get_knowledge_by_id(conn: sqlite3.Connection, item_id: str) -> KnowledgeItem | None:
    """Fetch a single knowledge item by ID."""
    row = conn.execute("SELECT * FROM knowledge WHERE id = ?", (item_id,)).fetchone()
    if row:
        return KnowledgeItem(**dict(row))
    return None


def find_duplicate(
    conn: sqlite3.Connection, content: str, type_filter: str | None = None
) -> KnowledgeItem | None:
    """Check if a knowledge item with identical content already exists."""
    clauses = ["content = ?", "superseded_by IS NULL"]
    params: list[str] = [content]
    if type_filter:
        clauses.append("type = ?")
        params.append(type_filter)
    row = conn.execute(
        f"SELECT * FROM knowledge WHERE {' AND '.join(clauses)} LIMIT 1", params
    ).fetchone()
    if row:
        return KnowledgeItem(**dict(row))
    return None


def count_knowledge(conn: sqlite3.Connection) -> dict[str, int]:
    """Return counts by type."""
    rows = conn.execute(
        "SELECT type, COUNT(*) as cnt FROM knowledge WHERE superseded_by IS NULL GROUP BY type"
    ).fetchall()
    return {row["type"]: row["cnt"] for row in rows}
