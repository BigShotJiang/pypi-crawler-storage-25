"""Session management: tracking, primer.md generation, and reflection.

Sessions represent a unit of work. Each session captures what was done,
what was learned, and writes a primer for the next session.
"""

from __future__ import annotations

import json
import re
import uuid
from datetime import UTC, datetime
from pathlib import Path

from .db import KnowledgeItem, Session, get_db, insert_knowledge
from .git_context import format_git_context, get_commits_since, get_git_context
from .mirror import write_mirror
from .retrieval import compute_embedding

# Patterns that suggest a commit message contains a decision
DECISION_PATTERNS = [
    re.compile(r"(?:decided|chose|switched|migrated|adopted|selected)\s+(?:to\s+)?(.+)", re.I),
    re.compile(r"(?:use|using|chose)\s+(\S+)\s+(?:over|instead of|rather than)\s+(\S+)", re.I),
    re.compile(r"(?:because|reason|rationale)[:\s]+(.+)", re.I),
]


def _now_iso() -> str:
    return datetime.now(UTC).isoformat()


def start_session(sidecar_dir: Path) -> Session:
    """Start a new session. Returns the session object."""
    session = Session(
        id=uuid.uuid4().hex[:12],
        started_at=_now_iso(),
    )
    conn = get_db(sidecar_dir / "db.sqlite")
    conn.execute(
        "INSERT INTO sessions (id, started_at) VALUES (?, ?)",
        (session.id, session.started_at),
    )
    conn.commit()
    conn.close()
    return session


def end_session(
    sidecar_dir: Path,
    session_id: str,
    summary: str,
    files_touched: list[str] | None = None,
    knowledge_ids: list[str] | None = None,
) -> None:
    """End a session with a summary."""
    conn = get_db(sidecar_dir / "db.sqlite")
    conn.execute(
        """UPDATE sessions SET ended_at = ?, summary = ?, files_touched = ?, knowledge_ids = ?
           WHERE id = ?""",
        (
            _now_iso(),
            summary,
            json.dumps(files_touched or []),
            json.dumps(knowledge_ids or []),
            session_id,
        ),
    )
    conn.commit()
    conn.close()


def get_last_session(sidecar_dir: Path) -> Session | None:
    """Get the most recent session."""
    conn = get_db(sidecar_dir / "db.sqlite")
    row = conn.execute("SELECT * FROM sessions ORDER BY started_at DESC LIMIT 1").fetchone()
    conn.close()

    if row:
        return Session(
            id=row["id"],
            started_at=row["started_at"],
            ended_at=row["ended_at"],
            summary=row["summary"],
            files_touched=json.loads(row["files_touched"]) if row["files_touched"] else [],
            knowledge_ids=json.loads(row["knowledge_ids"]) if row["knowledge_ids"] else [],
        )
    return None


def extract_decisions_from_commits(commits: list[dict[str, str]]) -> list[str]:
    """Extract decision-like statements from commit messages."""
    decisions = []
    for commit in commits:
        msg = commit["message"]
        for pattern in DECISION_PATTERNS:
            match = pattern.search(msg)
            if match:
                decisions.append(f"{msg} (commit {commit['hash']})")
                break
    return decisions


def auto_reflect(sidecar_dir: Path, cwd: Path | None = None) -> dict:
    """Auto-reflect from git history since last session.

    Returns dict with: session_id, summary, decisions_found, primer_path.
    """
    last = get_last_session(sidecar_dir)
    since = last.started_at if last and last.started_at else "1 week ago"

    # Get commits since last session
    commits = get_commits_since(since, cwd)
    git_ctx = get_git_context(cwd)

    # Extract decisions
    decisions = extract_decisions_from_commits(commits)

    # Build summary
    commit_summaries = [c["message"] for c in commits[:10]]
    summary_parts = []
    if commit_summaries:
        summary_parts.append(f"Commits: {', '.join(commit_summaries[:5])}")
    if decisions:
        summary_parts.append(f"Decisions detected: {len(decisions)}")

    summary = "; ".join(summary_parts) if summary_parts else "No activity detected"

    # Start and end session
    session = start_session(sidecar_dir)
    knowledge_ids = []

    # Store auto-captured decisions
    conn = get_db(sidecar_dir / "db.sqlite")
    for decision_text in decisions:
        item = KnowledgeItem(
            id="",
            type="decision",
            content=decision_text,
            source="commit",
            confidence=0.7,
        )
        item.embedding = compute_embedding(item.content)
        insert_knowledge(conn, item)
        write_mirror(sidecar_dir, item)
        knowledge_ids.append(item.id)
    conn.close()

    # Determine files touched from git
    files_touched = git_ctx.dirty_files if git_ctx.dirty_files else []

    end_session(sidecar_dir, session.id, summary, files_touched, knowledge_ids)

    # Write primer
    primer_path = write_primer(sidecar_dir, summary, git_ctx, decisions)

    return {
        "session_id": session.id,
        "summary": summary,
        "decisions_found": len(decisions),
        "commits_analyzed": len(commits),
        "primer_path": str(primer_path),
    }


def interactive_reflect(
    sidecar_dir: Path,
    accomplishments: str,
    decisions: list[str] | None = None,
    lessons: list[str] | None = None,
    next_session_notes: str | None = None,
    cwd: Path | None = None,
) -> dict:
    """Interactive reflect with user-provided content.

    Returns dict with: session_id, knowledge_created, primer_path.
    """
    git_ctx = get_git_context(cwd)
    session = start_session(sidecar_dir)
    knowledge_ids = []

    conn = get_db(sidecar_dir / "db.sqlite")

    # Store decisions
    if decisions:
        for d in decisions:
            item = KnowledgeItem(id="", type="decision", content=d, source="reflect")
            item.embedding = compute_embedding(item.content)
            insert_knowledge(conn, item)
            write_mirror(sidecar_dir, item)
            knowledge_ids.append(item.id)

    # Store lessons
    if lessons:
        for lesson in lessons:
            item = KnowledgeItem(id="", type="lesson", content=lesson, source="reflect")
            item.embedding = compute_embedding(item.content)
            insert_knowledge(conn, item)
            write_mirror(sidecar_dir, item)
            knowledge_ids.append(item.id)

    conn.close()

    files_touched = git_ctx.dirty_files if git_ctx.dirty_files else []
    end_session(sidecar_dir, session.id, accomplishments, files_touched, knowledge_ids)

    # Build summary for primer
    summary = accomplishments
    if next_session_notes:
        summary += f"\n\nNotes for next session: {next_session_notes}"

    primer_path = write_primer(sidecar_dir, summary, git_ctx, decisions or [])

    return {
        "session_id": session.id,
        "knowledge_created": len(knowledge_ids),
        "primer_path": str(primer_path),
    }


def write_primer(
    sidecar_dir: Path,
    summary: str,
    git_ctx,
    decisions: list[str],
) -> Path:
    """Write the primer.md handoff document for the next session."""
    primer_path = sidecar_dir / "primer.md"

    sections = []
    sections.append(f"# Session Primer\n\n*Generated: {_now_iso()}*")

    # Last session summary
    sections.append(f"## What Happened\n\n{summary}")

    # Decisions made
    if decisions:
        items = "\n".join(f"- {d}" for d in decisions)
        sections.append(f"## Decisions Made\n\n{items}")

    # Git context
    git_text = format_git_context(git_ctx)
    if git_text:
        sections.append(f"## Git Context\n\n{git_text}")

    primer_path.write_text("\n\n".join(sections) + "\n")
    return primer_path


def read_primer(sidecar_dir: Path) -> str | None:
    """Read the current primer.md if it exists."""
    primer_path = sidecar_dir / "primer.md"
    if primer_path.exists():
        return primer_path.read_text()
    return None
