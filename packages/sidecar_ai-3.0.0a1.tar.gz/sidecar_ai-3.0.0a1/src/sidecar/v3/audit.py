"""Phase transition audit: gap analysis when upgrading project phase.

Scans source files for issues that should be resolved before moving
to a higher phase. Findings can be accepted as constraints.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path


@dataclass
class AuditFinding:
    severity: str  # "critical" or "moderate"
    category: str  # "stub", "config", "error-handling", "testing", etc.
    description: str
    file_path: str | None = None
    suggested_constraint: str = ""


def run_audit(
    project_dir: Path,
    target_phase: str,
    current_phase: str,
) -> list[AuditFinding]:
    """Run phase-transition audit. Returns findings."""
    from .knowledge import PHASE_ORDER

    current_order = PHASE_ORDER.get(current_phase, 0)
    target_order = PHASE_ORDER.get(target_phase, 0)

    if target_order <= current_order:
        return []

    findings: list[AuditFinding] = []

    # Collect source files
    src_files = _collect_source_files(project_dir)

    # Run checks for each phase we're passing through
    if target_order >= PHASE_ORDER.get("mvp", 1) and current_order < PHASE_ORDER.get("mvp", 1):
        findings.extend(_check_mvp(project_dir, src_files))

    if target_order >= PHASE_ORDER.get("production", 2) and current_order < PHASE_ORDER.get(
        "production", 2
    ):
        findings.extend(_check_production(project_dir, src_files))

    if target_order >= PHASE_ORDER.get("scale", 3) and current_order < PHASE_ORDER.get("scale", 3):
        findings.extend(_check_scale(project_dir, src_files))

    return findings


def _collect_source_files(project_dir: Path) -> list[Path]:
    """Collect source files for scanning, excluding common non-source dirs."""
    exclude = {
        ".git",
        ".sidecar",
        "node_modules",
        "__pycache__",
        ".venv",
        "venv",
        ".tox",
        "dist",
        "build",
        ".eggs",
        "htmlcov",
    }
    files: list[Path] = []
    for ext in ("*.py", "*.js", "*.ts", "*.tsx", "*.jsx", "*.go", "*.rs", "*.java"):
        for f in project_dir.rglob(ext):
            if not any(part in exclude for part in f.parts):
                files.append(f)
    return files[:500]  # Cap to avoid scanning huge repos


# ── MVP Checks ──────────────────────────────────────────────────────────


def _check_mvp(project_dir: Path, src_files: list[Path]) -> list[AuditFinding]:
    findings: list[AuditFinding] = []

    # Check for README
    has_readme = any(
        (project_dir / name).exists()
        for name in ("README.md", "README.rst", "README.txt", "README")
    )
    if not has_readme:
        findings.append(
            AuditFinding(
                severity="moderate",
                category="documentation",
                description="No README found",
                suggested_constraint="Project must have a README with install and usage instructions",
            )
        )

    # Check for at least one test file
    test_files = list(project_dir.rglob("test_*.py")) + list(project_dir.rglob("*_test.py"))
    test_files += list(project_dir.rglob("*.test.js")) + list(project_dir.rglob("*.test.ts"))
    test_files += list(project_dir.rglob("*.spec.js")) + list(project_dir.rglob("*.spec.ts"))
    if not test_files:
        findings.append(
            AuditFinding(
                severity="critical",
                category="testing",
                description="No test files found",
                suggested_constraint="All features must have corresponding tests",
            )
        )

    # Check for bare except clauses
    for f in src_files:
        if f.suffix == ".py":
            try:
                content = f.read_text(errors="replace")
                for i, line in enumerate(content.splitlines(), 1):
                    if re.match(r"\s*except\s*:", line):
                        findings.append(
                            AuditFinding(
                                severity="moderate",
                                category="error-handling",
                                description=f"Bare except clause at line {i}",
                                file_path=str(f.relative_to(project_dir)),
                                suggested_constraint="Never use bare except clauses — always catch specific exceptions",
                            )
                        )
                        break  # One per file is enough
            except OSError:
                pass

    return findings


# ── Production Checks ───────────────────────────────────────────────────


def _check_production(project_dir: Path, src_files: list[Path]) -> list[AuditFinding]:
    findings: list[AuditFinding] = []

    stub_pattern = re.compile(r"\b(TODO|FIXME|HACK|XXX|STUB)\b", re.I)
    hardcoded_pattern = re.compile(
        r"(localhost|127\.0\.0\.1|0\.0\.0\.0|:3000|:8000|:8080|:5432|:6379)"
    )
    print_pattern = re.compile(r"^\s*print\s*\(")

    stubs_found = 0
    hardcoded_found = 0
    prints_found = 0

    for f in src_files:
        try:
            content = f.read_text(errors="replace")
        except OSError:
            continue

        rel = str(f.relative_to(project_dir))

        # Skip test files, scripts, and migrations for production checks
        is_test = "test" in rel.lower()
        is_support = any(
            rel.startswith(d) for d in ("scripts/", "migrations/", "docs/", "examples/")
        )

        if not is_test and not is_support:
            for line in content.splitlines():
                if stub_pattern.search(line) and stubs_found < 5:
                    stubs_found += 1
                    findings.append(
                        AuditFinding(
                            severity="critical",
                            category="stub",
                            description=f"TODO/FIXME/HACK comment in {rel}",
                            file_path=rel,
                            suggested_constraint="No TODO/FIXME/HACK comments in production code",
                        )
                    )
                    break  # One per file

        if not is_test and not is_support:
            for line in content.splitlines():
                if hardcoded_pattern.search(line) and hardcoded_found < 5:
                    # Skip comments and regex pattern definitions
                    stripped = line.lstrip()
                    if stripped.startswith("#") or stripped.startswith("//"):
                        continue
                    if "re.compile" in line or 'r"' in line or "r'" in line:
                        continue
                    hardcoded_found += 1
                    findings.append(
                        AuditFinding(
                            severity="moderate",
                            category="config",
                            description=f"Hardcoded address/port in {rel}",
                            file_path=rel,
                            suggested_constraint="Use environment variables or config files for hosts and ports",
                        )
                    )
                    break

        if f.suffix == ".py" and not is_test:
            for line in content.splitlines():
                if print_pattern.match(line) and prints_found < 3:
                    prints_found += 1
                    findings.append(
                        AuditFinding(
                            severity="moderate",
                            category="logging",
                            description=f"print() used instead of logging in {rel}",
                            file_path=rel,
                            suggested_constraint="Use structured logging instead of print() in production code",
                        )
                    )
                    break

    # Check for .env or config management
    has_config = any(
        (project_dir / name).exists()
        for name in (".env", ".env.example", "config.yaml", "config.json", "settings.py")
    )
    if not has_config and src_files:
        findings.append(
            AuditFinding(
                severity="moderate",
                category="config",
                description="No configuration management (.env, config file) found",
                suggested_constraint="Use environment-based configuration management",
            )
        )

    return findings


# ── Scale Checks ────────────────────────────────────────────────────────


def _check_scale(project_dir: Path, src_files: list[Path]) -> list[AuditFinding]:  # noqa: ARG001
    findings: list[AuditFinding] = []

    # These are advisory — we check for common patterns
    has_caching = False
    has_monitoring = False

    for f in src_files:
        try:
            content = f.read_text(errors="replace").lower()
        except OSError:
            continue

        if re.search(r"\b(cache|redis|memcache|lru_cache|@cache)\b", content):
            has_caching = True
        if re.search(
            r"\b(metrics|prometheus|statsd|datadog|monitoring|opentelemetry|otlp)\b", content
        ):
            has_monitoring = True

    if not has_caching:
        findings.append(
            AuditFinding(
                severity="moderate",
                category="performance",
                description="No caching patterns detected",
                suggested_constraint="Implement caching for frequently accessed data",
            )
        )

    if not has_monitoring:
        findings.append(
            AuditFinding(
                severity="moderate",
                category="observability",
                description="No monitoring/metrics patterns detected",
                suggested_constraint="Implement metrics collection and monitoring",
            )
        )

    return findings
