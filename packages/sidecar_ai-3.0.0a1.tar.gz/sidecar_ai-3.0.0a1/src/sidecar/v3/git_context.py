"""Git context: extract branch, recent commits, dirty files, and diff stats.

All functions are safe to call outside a git repo — they return empty/None.
"""

from __future__ import annotations

import subprocess
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class GitContext:
    branch: str | None = None
    recent_commits: list[str] = field(default_factory=list)
    dirty_files: list[str] = field(default_factory=list)
    is_repo: bool = False


def _run_git(args: list[str], cwd: Path | None = None) -> str | None:
    """Run a git command, return stdout or None on failure."""
    try:
        result = subprocess.run(
            ["git", *args],
            capture_output=True,
            text=True,
            cwd=cwd,
            timeout=5,
        )
        if result.returncode == 0:
            return result.stdout.strip()
    except (subprocess.TimeoutExpired, FileNotFoundError):
        pass
    return None


def get_git_context(cwd: Path | None = None, max_commits: int = 5) -> GitContext:
    """Gather git context for the current project."""
    ctx = GitContext()

    # Check if we're in a git repo
    toplevel = _run_git(["rev-parse", "--show-toplevel"], cwd)
    if not toplevel:
        return ctx
    ctx.is_repo = True

    # Branch
    ctx.branch = _run_git(["rev-parse", "--abbrev-ref", "HEAD"], cwd)

    # Recent commits (one-line format)
    log = _run_git(
        ["log", f"-{max_commits}", "--oneline", "--no-decorate"],
        cwd,
    )
    if log:
        ctx.recent_commits = [line for line in log.splitlines() if line.strip()]

    # Dirty files (modified + staged only, skip untracked for speed on large repos)
    status = _run_git(["status", "--porcelain", "-uno"], cwd)
    if status:
        ctx.dirty_files = [line[3:] for line in status.splitlines() if line.strip()]

    return ctx


def get_commits_since(since: str, cwd: Path | None = None) -> list[dict[str, str]]:
    """Get commits since a timestamp. Returns list of {hash, message, date}."""
    log = _run_git(
        ["log", f"--since={since}", "--format=%H|%s|%ai", "--no-decorate"],
        cwd,
    )
    if not log:
        return []

    commits = []
    for line in log.splitlines():
        parts = line.split("|", 2)
        if len(parts) == 3:
            commits.append(
                {
                    "hash": parts[0][:8],
                    "message": parts[1],
                    "date": parts[2],
                }
            )
    return commits


def get_diff_stat(since_commit: str | None = None, cwd: Path | None = None) -> list[str]:
    """Get list of files changed (diffstat). If since_commit is None, shows uncommitted changes."""
    if since_commit:
        output = _run_git(["diff", "--name-only", since_commit], cwd)
    else:
        output = _run_git(["diff", "--name-only", "HEAD"], cwd)

    if not output:
        return []
    return [f for f in output.splitlines() if f.strip()]


def format_git_context(ctx: GitContext) -> str:
    """Format git context as readable text for briefs."""
    if not ctx.is_repo:
        return ""

    lines = []
    if ctx.branch:
        lines.append(f"Branch: {ctx.branch}")

    if ctx.recent_commits:
        lines.append("Recent commits:")
        for commit in ctx.recent_commits[:5]:
            lines.append(f"  - {commit}")

    if ctx.dirty_files:
        lines.append(f"Uncommitted changes ({len(ctx.dirty_files)} files):")
        for f in ctx.dirty_files[:10]:
            lines.append(f"  - {f}")
        if len(ctx.dirty_files) > 10:
            lines.append(f"  ... and {len(ctx.dirty_files) - 10} more")

    return "\n".join(lines)
