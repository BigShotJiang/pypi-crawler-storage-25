"""Git hook scripts for passive knowledge capture.

post-commit: extracts decision-like statements from commit messages,
             stores them as low-confidence knowledge.
pre-commit:  surfaces impact warnings when modifying files related
             to known constraints or lessons.

Both hooks are designed to complete in <500ms.
"""

from __future__ import annotations

import re
import subprocess
from pathlib import Path

from .db import KnowledgeItem, get_db, insert_knowledge, query_knowledge
from .knowledge import find_sidecar_dir
from .mirror import write_mirror
from .retrieval import compute_embedding, search

# Patterns that suggest a commit message contains a decision
DECISION_PATTERNS = [
    re.compile(r"\b(?:decided|chose|selected|adopted|switched)\s+(?:to\s+)?(.+)", re.I),
    re.compile(r"\b(?:use|using)\s+(\S+)\s+(?:over|instead of|rather than)\s+(\S+)", re.I),
    re.compile(r"\b(?:migrated?|moved?|converted?)\s+(?:from\s+)?(\S+)\s+to\s+(\S+)", re.I),
    re.compile(r"\b(?:replaced?)\s+(\S+)\s+with\s+(\S+)", re.I),
]

# Patterns that suggest rationale (useful context but not standalone decisions)
RATIONALE_PATTERNS = [
    re.compile(r"\b(?:because|reason|rationale|due to|in order to)[:\s]+(.+)", re.I),
]


def extract_decisions(message: str) -> list[str]:
    """Extract decision-like statements from a commit message.

    Returns list of decision strings found. Empty list if none detected.
    """
    decisions = []

    # Skip very short or conventional-only messages
    clean = message.strip()
    if len(clean) < 15:
        return []

    # Strip conventional commit prefix (feat:, fix:, etc.)
    stripped = re.sub(
        r"^(?:feat|fix|chore|docs|style|refactor|test|ci|build|perf)\([^)]*\):\s*", "", clean
    )
    stripped = re.sub(
        r"^(?:feat|fix|chore|docs|style|refactor|test|ci|build|perf):\s*", "", stripped
    )

    for pattern in DECISION_PATTERNS:
        match = pattern.search(stripped)
        if match:
            decisions.append(clean)
            break

    return decisions


def get_last_commit_message(cwd: Path | None = None) -> str | None:
    """Get the most recent commit message."""
    try:
        result = subprocess.run(
            ["git", "log", "-1", "--format=%B"],
            capture_output=True,
            text=True,
            cwd=cwd,
            timeout=5,
        )
        if result.returncode == 0:
            return result.stdout.strip()
    except (subprocess.TimeoutExpired, FileNotFoundError):
        pass
    return None


def get_staged_files(cwd: Path | None = None) -> list[str]:
    """Get list of staged files (for pre-commit)."""
    try:
        result = subprocess.run(
            ["git", "diff", "--cached", "--name-only"],
            capture_output=True,
            text=True,
            cwd=cwd,
            timeout=5,
        )
        if result.returncode == 0:
            return [f for f in result.stdout.strip().splitlines() if f]
    except (subprocess.TimeoutExpired, FileNotFoundError):
        pass
    return []


def post_commit(cwd: Path | None = None) -> dict:
    """Post-commit hook: extract decisions from latest commit message.

    Returns dict with: decisions_found, items_created.
    """
    sdir = find_sidecar_dir(cwd)
    if not sdir:
        return {"decisions_found": 0, "items_created": []}

    message = get_last_commit_message(cwd)
    if not message:
        return {"decisions_found": 0, "items_created": []}

    decisions = extract_decisions(message)
    if not decisions:
        return {"decisions_found": 0, "items_created": []}

    conn = get_db(sdir / "db.sqlite")
    created = []

    for decision_text in decisions:
        item = KnowledgeItem(
            id="",
            type="decision",
            content=decision_text,
            source="commit",
            confidence=0.7,
        )
        item.embedding = compute_embedding(item.content)
        insert_knowledge(conn, item)
        write_mirror(sdir, item)
        created.append({"id": item.id, "content": item.content})

    conn.close()

    return {"decisions_found": len(decisions), "items_created": created}


def pre_commit_warnings(cwd: Path | None = None) -> list[str]:
    """Pre-commit hook: surface impact warnings for staged files.

    Checks if staged files are related to known constraints or lessons.
    Returns list of warning strings.
    """
    sdir = find_sidecar_dir(cwd)
    if not sdir:
        return []

    staged = get_staged_files(cwd)
    if not staged:
        return []

    conn = get_db(sdir / "db.sqlite")
    # Only check constraints and lessons — these are the high-signal types
    constraints = query_knowledge(conn, type_filter="constraint")
    lessons = query_knowledge(conn, type_filter="lesson")
    conn.close()

    warning_items = constraints + lessons
    if not warning_items:
        return []

    warnings = []

    # Build a query from staged file paths
    # Extract meaningful parts: directory names, file stems
    path_keywords = set()
    for f in staged:
        parts = Path(f).parts
        for part in parts:
            # Skip generic names
            if part not in ("src", "lib", "test", "tests", "index", "__init__"):
                stem = Path(part).stem
                if len(stem) > 2:
                    path_keywords.add(stem.lower())

    if not path_keywords:
        return []

    query = " ".join(path_keywords)
    results = search(query, warning_items, top_k=5, min_score=0.02)

    for item, _score in results:
        prefix = "CONSTRAINT" if item.type == "constraint" else "LESSON"
        warnings.append(f"[{prefix}] {item.content}")

    return warnings


# ── Shell script templates for git hooks ──────────────────────────────────

POST_COMMIT_SCRIPT = """\
#!/bin/sh
# Sidecar post-commit hook: auto-capture decisions from commit messages
# Installed by: sidecar install-git-hooks

if command -v sidecar >/dev/null 2>&1; then
    sidecar hook post-commit 2>/dev/null || true
fi
"""

PRE_COMMIT_SCRIPT = """\
#!/bin/sh
# Sidecar pre-commit hook: surface impact warnings
# Installed by: sidecar install-git-hooks

if command -v sidecar >/dev/null 2>&1; then
    sidecar hook pre-commit 2>/dev/null || true
fi

# Always allow the commit — warnings are informational only
exit 0
"""


def install_git_hooks(cwd: Path | None = None) -> dict:
    """Install git hooks for passive capture.

    Returns dict with: hooks_installed, paths.
    """
    repo_root = cwd or Path.cwd()

    # Find .git directory
    git_dir = repo_root / ".git"
    if not git_dir.is_dir():
        # Could be in a subdirectory
        try:
            result = subprocess.run(
                ["git", "rev-parse", "--git-dir"],
                capture_output=True,
                text=True,
                cwd=repo_root,
                timeout=5,
            )
            if result.returncode == 0:
                git_dir = Path(result.stdout.strip())
                if not git_dir.is_absolute():
                    git_dir = repo_root / git_dir
        except (subprocess.TimeoutExpired, FileNotFoundError):
            return {"hooks_installed": [], "error": "Not a git repository"}

    hooks_dir = git_dir / "hooks"
    hooks_dir.mkdir(exist_ok=True)

    installed = []

    for name, script in [
        ("post-commit", POST_COMMIT_SCRIPT),
        ("pre-commit", PRE_COMMIT_SCRIPT),
    ]:
        hook_path = hooks_dir / name
        if hook_path.exists():
            existing = hook_path.read_text()
            if "sidecar" in existing:
                # Already has sidecar hook
                installed.append({"name": name, "status": "already_installed"})
                continue
            # Append to existing hook
            with open(hook_path, "a") as f:
                f.write("\n# --- Sidecar hook (appended) ---\n")
                # Write just the sidecar command part, not the shebang
                for line in script.splitlines():
                    if not line.startswith("#!"):
                        f.write(line + "\n")
            installed.append({"name": name, "status": "appended"})
        else:
            hook_path.write_text(script)
            hook_path.chmod(0o755)
            installed.append({"name": name, "status": "created"})

    return {"hooks_installed": installed, "paths": str(hooks_dir)}
