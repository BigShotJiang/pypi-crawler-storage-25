"""Sidecar: Project Memory for AI Agents."""

__version__ = "3.0.0a1"
