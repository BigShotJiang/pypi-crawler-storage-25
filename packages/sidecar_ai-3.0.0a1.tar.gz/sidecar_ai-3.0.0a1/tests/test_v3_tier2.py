"""Tests for sidecar v3 Tier 2: staleness, conflicts, compile, audit, recipes."""

import os
from datetime import UTC, datetime, timedelta

import pytest
import yaml
from click.testing import CliRunner

from sidecar.v3.audit import run_audit
from sidecar.v3.cli import cli
from sidecar.v3.compiler import compile_knowledge
from sidecar.v3.db import get_db
from sidecar.v3.knowledge import (
    detect_conflicts,
    get_stale_items,
    init_project,
    learn,
    refresh_item,
    set_phase,
)
from sidecar.v3.recipes import (
    extract_recipe,
    inspect_recipe,
    install_recipe,
    list_installed,
    load_preset_index,
    search_recipes,
)


@pytest.fixture
def tmp_project(tmp_path):
    init_project(tmp_path)
    return tmp_path


@pytest.fixture
def runner():
    return CliRunner()


@pytest.fixture
def project_with_knowledge(tmp_project):
    sdir = tmp_project / ".sidecar"
    learn("Use FastAPI for REST API", type="decision", domain="backend", sidecar_dir=sdir)
    learn(
        "All endpoints validate with Pydantic",
        type="constraint",
        domain="backend",
        sidecar_dir=sdir,
    )
    learn("PostgreSQL for persistence", type="decision", domain="database", sidecar_dir=sdir)
    learn("Auth tokens rotate every 24h", type="constraint", domain="security", sidecar_dir=sdir)
    learn(
        "Migration rollback failed last month", type="lesson", domain="database", sidecar_dir=sdir
    )
    learn("Frontend uses React with Next.js", type="decision", domain="frontend", sidecar_dir=sdir)
    learn(
        "API gateway routes to backend services",
        type="relationship",
        domain="backend",
        sidecar_dir=sdir,
    )
    return tmp_project


# ── B22: Staleness Tests ─────────────────────────────────────────────────


class TestStaleness:
    def test_no_stale_items_fresh_project(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        learn("Fresh item", type="decision", sidecar_dir=sdir)
        items = get_stale_items(sidecar_dir=sdir, days=90)
        assert len(items) == 0

    def test_stale_items_detected(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        # Insert item with old timestamp
        conn = get_db(sdir / "db.sqlite")
        old_date = (datetime.now(UTC) - timedelta(days=100)).isoformat()
        conn.execute(
            "INSERT INTO knowledge (id, type, content, source, confidence, created_at) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            ("old001", "decision", "Old decision", "explicit", 1.0, old_date),
        )
        conn.commit()
        conn.close()

        items = get_stale_items(sidecar_dir=sdir, days=90)
        assert len(items) == 1
        assert items[0].id == "old001"

    def test_custom_staleness_threshold(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        conn = get_db(sdir / "db.sqlite")
        old_date = (datetime.now(UTC) - timedelta(days=15)).isoformat()
        conn.execute(
            "INSERT INTO knowledge (id, type, content, source, confidence, created_at) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            ("mid001", "decision", "Semi-old decision", "explicit", 1.0, old_date),
        )
        conn.commit()
        conn.close()

        assert len(get_stale_items(sidecar_dir=sdir, days=10)) == 1
        assert len(get_stale_items(sidecar_dir=sdir, days=30)) == 0

    def test_refresh_item(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        conn = get_db(sdir / "db.sqlite")
        old_date = (datetime.now(UTC) - timedelta(days=100)).isoformat()
        conn.execute(
            "INSERT INTO knowledge (id, type, content, source, confidence, created_at) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            ("ref001", "decision", "To refresh", "explicit", 1.0, old_date),
        )
        conn.commit()
        conn.close()

        assert len(get_stale_items(sidecar_dir=sdir, days=90)) == 1
        assert refresh_item("ref001", sidecar_dir=sdir)
        assert len(get_stale_items(sidecar_dir=sdir, days=90)) == 0

    def test_refresh_nonexistent_item(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        assert not refresh_item("nonexistent", sidecar_dir=sdir)

    def test_stale_cli_no_stale(self, runner, tmp_project):
        old_cwd = os.getcwd()
        os.chdir(tmp_project)
        try:
            result = runner.invoke(cli, ["stale"], catch_exceptions=False)
            assert result.exit_code == 0
            assert "No stale items" in result.output
        finally:
            os.chdir(old_cwd)

    def test_stale_cli_with_items(self, runner, tmp_project):
        sdir = tmp_project / ".sidecar"
        conn = get_db(sdir / "db.sqlite")
        old_date = (datetime.now(UTC) - timedelta(days=100)).isoformat()
        conn.execute(
            "INSERT INTO knowledge (id, type, content, source, confidence, created_at) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            ("cli001", "decision", "Old CLI decision", "explicit", 1.0, old_date),
        )
        conn.commit()
        conn.close()

        old_cwd = os.getcwd()
        os.chdir(tmp_project)
        try:
            result = runner.invoke(cli, ["stale"], catch_exceptions=False)
            assert result.exit_code == 0
            assert "cli001" in result.output
            assert "1 stale items" in result.output
        finally:
            os.chdir(old_cwd)

    def test_stale_cli_refresh(self, runner, tmp_project):
        sdir = tmp_project / ".sidecar"
        conn = get_db(sdir / "db.sqlite")
        old_date = (datetime.now(UTC) - timedelta(days=100)).isoformat()
        conn.execute(
            "INSERT INTO knowledge (id, type, content, source, confidence, created_at) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            ("rfr001", "decision", "To refresh via CLI", "explicit", 1.0, old_date),
        )
        conn.commit()
        conn.close()

        old_cwd = os.getcwd()
        os.chdir(tmp_project)
        try:
            result = runner.invoke(cli, ["stale", "--refresh", "rfr001"], catch_exceptions=False)
            assert result.exit_code == 0
            assert "Refreshed" in result.output
        finally:
            os.chdir(old_cwd)


# ── B23: Conflict Detection Tests ────────────────────────────────────────


class TestConflicts:
    def test_no_conflicts_empty(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        conflicts = detect_conflicts(sidecar_dir=sdir)
        assert len(conflicts) == 0

    def test_no_conflicts_compatible(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        learn("Use PostgreSQL for the database", type="decision", sidecar_dir=sdir)
        learn("Use Redis for caching", type="decision", sidecar_dir=sdir)
        conflicts = detect_conflicts(sidecar_dir=sdir)
        assert len(conflicts) == 0

    def test_detect_opposing_guidance(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        learn(
            "Always use connection pooling for database connections",
            type="constraint",
            sidecar_dir=sdir,
        )
        learn(
            "Never use connection pooling for database connections",
            type="constraint",
            sidecar_dir=sdir,
        )
        conflicts = detect_conflicts(sidecar_dir=sdir)
        assert len(conflicts) >= 1
        assert "Opposing" in conflicts[0][2]

    def test_detect_use_vs_avoid(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        learn("Use SQLAlchemy ORM for all database queries", type="decision", sidecar_dir=sdir)
        learn(
            "Avoid SQLAlchemy ORM for database queries, use raw SQL",
            type="decision",
            sidecar_dir=sdir,
        )
        conflicts = detect_conflicts(sidecar_dir=sdir)
        assert len(conflicts) >= 1

    def test_conflicts_cli(self, runner, tmp_project):
        sdir = tmp_project / ".sidecar"
        learn("Always validate input with strict schemas", type="constraint", sidecar_dir=sdir)
        learn(
            "Never validate input with strict schemas, use loose parsing",
            type="constraint",
            sidecar_dir=sdir,
        )

        old_cwd = os.getcwd()
        os.chdir(tmp_project)
        try:
            result = runner.invoke(cli, ["conflicts"], catch_exceptions=False)
            assert result.exit_code == 0
            assert "Conflict" in result.output
        finally:
            os.chdir(old_cwd)

    def test_conflicts_cli_no_conflicts(self, runner, tmp_project):
        old_cwd = os.getcwd()
        os.chdir(tmp_project)
        try:
            result = runner.invoke(cli, ["conflicts"], catch_exceptions=False)
            assert result.exit_code == 0
            assert "No conflicts" in result.output
        finally:
            os.chdir(old_cwd)


# ── B2: Knowledge Compilation Tests ──────────────────────────────────────


class TestCompilation:
    def test_compile_claude_md(self, project_with_knowledge):
        sdir = project_with_knowledge / ".sidecar"
        output = compile_knowledge(sidecar_dir=sdir, format="claude-md")
        assert "## Coding Standards" in output
        assert "## Architecture Decisions" in output
        assert "Pydantic" in output
        assert "FastAPI" in output

    def test_compile_skill(self, project_with_knowledge):
        sdir = project_with_knowledge / ".sidecar"
        output = compile_knowledge(sidecar_dir=sdir, format="skill")
        assert "Sidecar Skill" in output
        assert "## Constraints" in output
        assert "## Key Decisions" in output

    def test_compile_primer(self, project_with_knowledge):
        sdir = project_with_knowledge / ".sidecar"
        output = compile_knowledge(sidecar_dir=sdir, format="primer")
        assert "Session Primer" in output
        assert "## Active Constraints" in output

    def test_compile_empty_project(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        output = compile_knowledge(sidecar_dir=sdir, format="claude-md")
        assert "No knowledge items found" in output

    def test_compile_with_domain_filter(self, project_with_knowledge):
        sdir = project_with_knowledge / ".sidecar"
        output = compile_knowledge(sidecar_dir=sdir, format="claude-md", domain_filter="security")
        assert "Auth tokens" in output
        # Backend-only items should be filtered out
        assert "FastAPI" not in output

    def test_compile_includes_phase(self, project_with_knowledge):
        sdir = project_with_knowledge / ".sidecar"
        set_phase("production", sdir)
        output = compile_knowledge(sidecar_dir=sdir, format="claude-md")
        assert "production" in output

    def test_compile_cli_stdout(self, runner, project_with_knowledge):
        old_cwd = os.getcwd()
        os.chdir(project_with_knowledge)
        try:
            result = runner.invoke(cli, ["compile"], catch_exceptions=False)
            assert result.exit_code == 0
            assert "Architecture" in result.output or "Coding Standards" in result.output
        finally:
            os.chdir(old_cwd)

    def test_compile_cli_to_file(self, runner, project_with_knowledge):
        old_cwd = os.getcwd()
        os.chdir(project_with_knowledge)
        try:
            outfile = project_with_knowledge / "CLAUDE.md"
            result = runner.invoke(cli, ["compile", "-o", str(outfile)], catch_exceptions=False)
            assert result.exit_code == 0
            assert outfile.exists()
            content = outfile.read_text()
            assert "Decisions" in content or "Standards" in content
        finally:
            os.chdir(old_cwd)

    def test_compile_cli_skill_format(self, runner, project_with_knowledge):
        old_cwd = os.getcwd()
        os.chdir(project_with_knowledge)
        try:
            result = runner.invoke(cli, ["compile", "--format", "skill"], catch_exceptions=False)
            assert result.exit_code == 0
            assert "Sidecar Skill" in result.output
        finally:
            os.chdir(old_cwd)


# ── B18b: Transition Audit Tests ─────────────────────────────────────────


class TestAudit:
    def test_no_findings_same_phase(self, tmp_project):
        findings = run_audit(tmp_project, "prototype", "prototype")
        assert len(findings) == 0

    def test_mvp_check_readme(self, tmp_path):
        findings = run_audit(tmp_path, "mvp", "prototype")
        readme_findings = [f for f in findings if f.category == "documentation"]
        assert len(readme_findings) >= 1

    def test_mvp_check_readme_exists(self, tmp_path):
        (tmp_path / "README.md").write_text("# My Project\n")
        findings = run_audit(tmp_path, "mvp", "prototype")
        readme_findings = [f for f in findings if f.category == "documentation"]
        assert len(readme_findings) == 0

    def test_mvp_check_tests(self, tmp_path):
        findings = run_audit(tmp_path, "mvp", "prototype")
        test_findings = [f for f in findings if f.category == "testing"]
        assert len(test_findings) >= 1

    def test_mvp_bare_except(self, tmp_path):
        src = tmp_path / "app.py"
        src.write_text("try:\n    pass\nexcept:\n    pass\n")
        findings = run_audit(tmp_path, "mvp", "prototype")
        error_findings = [f for f in findings if f.category == "error-handling"]
        assert len(error_findings) >= 1

    def test_production_todo_check(self, tmp_path):
        src = tmp_path / "app.py"
        src.write_text("# TODO: fix this later\ndef main(): pass\n")
        findings = run_audit(tmp_path, "production", "prototype")
        stub_findings = [f for f in findings if f.category == "stub"]
        assert len(stub_findings) >= 1

    def test_production_hardcoded_config(self, tmp_path):
        src = tmp_path / "server.py"
        src.write_text('HOST = "localhost"\nPORT = 8080\n')
        findings = run_audit(tmp_path, "production", "prototype")
        config_findings = [f for f in findings if f.category == "config"]
        assert any("Hardcoded" in f.description for f in config_findings)

    def test_scale_checks(self, tmp_path):
        src = tmp_path / "app.py"
        src.write_text("def main(): pass\n")
        findings = run_audit(tmp_path, "scale", "production")
        categories = {f.category for f in findings}
        assert "performance" in categories or "observability" in categories

    def test_finding_has_suggested_constraint(self, tmp_path):
        findings = run_audit(tmp_path, "mvp", "prototype")
        for f in findings:
            assert f.suggested_constraint, f"Finding {f.description} missing constraint"

    def test_upgrade_cli(self, runner, tmp_project):
        (tmp_project / "README.md").write_text("# Test\n")
        (tmp_project / "test_app.py").write_text("def test_x(): pass\n")
        init_project(tmp_project)

        old_cwd = os.getcwd()
        os.chdir(tmp_project)
        try:
            result = runner.invoke(cli, ["upgrade", "mvp", "--auto"], catch_exceptions=False)
            assert result.exit_code == 0
            assert "upgraded to: mvp" in result.output
        finally:
            os.chdir(old_cwd)


# ── B17: Recipe System Tests ────────────────────────────────────────────


class TestRecipes:
    def test_load_preset_index(self):
        index = load_preset_index()
        assert len(index) >= 3
        names = {r.name for r in index}
        assert "fastapi" in names
        assert "nextjs" in names
        assert "cli-python" in names

    def test_search_recipes_match(self):
        results = search_recipes("python")
        assert len(results) >= 1
        assert any(r.name == "cli-python" for r in results)

    def test_search_recipes_no_match(self):
        results = search_recipes("nonexistent-framework-xyz")
        assert len(results) == 0

    def test_search_by_stack(self):
        results = search_recipes("fastapi")
        assert len(results) >= 1

    def test_inspect_recipe(self):
        index = load_preset_index()
        fastapi = next(r for r in index if r.name == "fastapi")
        output = inspect_recipe(fastapi)
        assert "fastapi" in output.lower()
        assert "Pydantic" in output
        assert "[constraint]" in output or "[decision]" in output

    def test_install_recipe(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        index = load_preset_index()
        fastapi = next(r for r in index if r.name == "fastapi")
        created = install_recipe(fastapi, sidecar_dir=sdir)
        assert created > 0

    def test_install_recipe_deduplicates(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        index = load_preset_index()
        fastapi = next(r for r in index if r.name == "fastapi")
        created1 = install_recipe(fastapi, sidecar_dir=sdir)
        created2 = install_recipe(fastapi, sidecar_dir=sdir)
        # Second install should have fewer new items (dedup)
        assert created2 <= created1

    def test_list_installed_empty(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        assert list_installed(sidecar_dir=sdir) == []

    def test_list_installed_after_install(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        index = load_preset_index()
        fastapi = next(r for r in index if r.name == "fastapi")
        install_recipe(fastapi, sidecar_dir=sdir)
        installed = list_installed(sidecar_dir=sdir)
        assert len(installed) == 1
        assert installed[0]["name"] == "fastapi"

    def test_extract_recipe(self, project_with_knowledge):
        sdir = project_with_knowledge / ".sidecar"
        recipe = extract_recipe(project_with_knowledge, sidecar_dir=sdir)
        assert len(recipe.items) >= 5
        assert recipe.source == "extracted"

    def test_recipe_search_cli(self, runner, tmp_project):
        old_cwd = os.getcwd()
        os.chdir(tmp_project)
        try:
            result = runner.invoke(cli, ["recipe", "search", "python"], catch_exceptions=False)
            assert result.exit_code == 0
            assert "cli-python" in result.output
        finally:
            os.chdir(old_cwd)

    def test_recipe_inspect_cli(self, runner, tmp_project):
        old_cwd = os.getcwd()
        os.chdir(tmp_project)
        try:
            result = runner.invoke(cli, ["recipe", "inspect", "fastapi"], catch_exceptions=False)
            assert result.exit_code == 0
            assert "Pydantic" in result.output
        finally:
            os.chdir(old_cwd)

    def test_recipe_install_cli(self, runner, tmp_project):
        old_cwd = os.getcwd()
        os.chdir(tmp_project)
        try:
            result = runner.invoke(cli, ["recipe", "install", "cli-python"], catch_exceptions=False)
            assert result.exit_code == 0
            assert "Installed" in result.output
        finally:
            os.chdir(old_cwd)

    def test_recipe_list_cli(self, runner, tmp_project):
        old_cwd = os.getcwd()
        os.chdir(tmp_project)
        try:
            # Install first
            runner.invoke(cli, ["recipe", "install", "fastapi"], catch_exceptions=False)
            result = runner.invoke(cli, ["recipe", "list"], catch_exceptions=False)
            assert result.exit_code == 0
            assert "fastapi" in result.output
        finally:
            os.chdir(old_cwd)

    def test_recipe_extract_cli(self, runner, project_with_knowledge):
        old_cwd = os.getcwd()
        os.chdir(project_with_knowledge)
        try:
            outfile = project_with_knowledge / "extracted.yaml"
            result = runner.invoke(
                cli, ["recipe", "extract", "-o", str(outfile)], catch_exceptions=False
            )
            assert result.exit_code == 0
            assert outfile.exists()
            data = yaml.safe_load(outfile.read_text())
            assert len(data["items"]) >= 5
        finally:
            os.chdir(old_cwd)

    def test_recipe_not_found(self, runner, tmp_project):
        old_cwd = os.getcwd()
        os.chdir(tmp_project)
        try:
            result = runner.invoke(
                cli, ["recipe", "inspect", "nonexistent"], catch_exceptions=False
            )
            assert result.exit_code == 0
            assert "not found" in result.output
        finally:
            os.chdir(old_cwd)
