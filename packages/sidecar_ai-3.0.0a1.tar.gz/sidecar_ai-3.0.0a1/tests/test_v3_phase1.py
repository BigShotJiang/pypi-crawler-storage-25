"""Tests for sidecar v3 Phase 1: brief, reflect, sessions, git context."""

import json
import os
from pathlib import Path

import pytest
from click.testing import CliRunner

from sidecar.v3.brief import generate_brief, generate_brief_json
from sidecar.v3.cli import cli
from sidecar.v3.git_context import GitContext, format_git_context, get_git_context
from sidecar.v3.knowledge import init_project, learn
from sidecar.v3.sessions import (
    auto_reflect,
    end_session,
    extract_decisions_from_commits,
    get_last_session,
    interactive_reflect,
    read_primer,
    start_session,
    write_primer,
)


@pytest.fixture
def tmp_project(tmp_path):
    init_project(tmp_path)
    return tmp_path


@pytest.fixture
def sidecar_dir(tmp_project):
    return tmp_project / ".sidecar"


@pytest.fixture
def populated_project(tmp_project):
    """Project with several knowledge items."""
    sdir = tmp_project / ".sidecar"
    learn("Design tokens for all theming in src/theme/", tags="theme,design", sidecar_dir=sdir)
    learn("PostgreSQL for production database", tags="database", sidecar_dir=sdir)
    learn("Never hardcode API keys", type="constraint", tags="security,api", sidecar_dir=sdir)
    learn(
        "Auth token changes broke mobile for 3 days",
        type="lesson",
        tags="auth,mobile",
        sidecar_dir=sdir,
    )
    learn(
        "POST /auth/token consumed by mobile and admin",
        type="relationship",
        tags="auth,api",
        sidecar_dir=sdir,
    )
    return tmp_project


@pytest.fixture
def runner():
    return CliRunner()


# ── Git Context Tests ─────────────────────────────────────────────────────


class TestGitContext:
    def test_format_git_context_empty(self):
        ctx = GitContext(is_repo=False)
        assert format_git_context(ctx) == ""

    def test_format_git_context_with_data(self):
        ctx = GitContext(
            is_repo=True,
            branch="feature/dark-mode",
            recent_commits=["abc1234 Add theme support", "def5678 Fix colors"],
            dirty_files=["src/theme.ts", "src/app.css"],
        )
        text = format_git_context(ctx)
        assert "feature/dark-mode" in text
        assert "Add theme support" in text
        assert "src/theme.ts" in text

    def test_get_git_context_in_repo(self):
        # This test runs inside the sidecar repo itself
        ctx = get_git_context(Path("/Users/okasha/AntiGravity/sidecar"))
        assert ctx.is_repo
        assert ctx.branch is not None

    def test_get_git_context_not_repo(self, tmp_path):
        ctx = get_git_context(tmp_path)
        assert not ctx.is_repo


# ── Session Tests ─────────────────────────────────────────────────────────


class TestSessions:
    def test_start_session(self, sidecar_dir):
        session = start_session(sidecar_dir)
        assert session.id
        assert session.started_at

    def test_end_session(self, sidecar_dir):
        session = start_session(sidecar_dir)
        end_session(sidecar_dir, session.id, "Did some work", ["file1.py"], ["k1"])
        last = get_last_session(sidecar_dir)
        assert last is not None
        assert last.summary == "Did some work"
        assert last.ended_at is not None

    def test_get_last_session_empty(self, sidecar_dir):
        assert get_last_session(sidecar_dir) is None

    def test_extract_decisions_from_commits(self):
        commits = [
            {"hash": "abc123", "message": "decided to use Redis for caching", "date": "2026-03-25"},
            {"hash": "def456", "message": "fix typo in readme", "date": "2026-03-25"},
            {
                "hash": "ghi789",
                "message": "chose PostgreSQL over MySQL because of JSONB",
                "date": "2026-03-25",
            },
            {"hash": "jkl012", "message": "switched from REST to GraphQL", "date": "2026-03-25"},
        ]
        decisions = extract_decisions_from_commits(commits)
        assert len(decisions) == 3
        assert any("Redis" in d for d in decisions)
        assert any("PostgreSQL" in d for d in decisions)
        assert any("GraphQL" in d for d in decisions)

    def test_extract_no_decisions(self):
        commits = [
            {"hash": "abc", "message": "fix bug", "date": "2026-03-25"},
            {"hash": "def", "message": "add tests", "date": "2026-03-25"},
        ]
        assert extract_decisions_from_commits(commits) == []


# ── Primer Tests ──────────────────────────────────────────────────────────


class TestPrimer:
    def test_write_primer(self, sidecar_dir):
        git_ctx = GitContext(
            is_repo=True,
            branch="main",
            recent_commits=["abc Fix bug"],
            dirty_files=[],
        )
        path = write_primer(sidecar_dir, "Built the auth module", git_ctx, ["Used JWT tokens"])
        assert path.exists()
        content = path.read_text()
        assert "Built the auth module" in content
        assert "Used JWT tokens" in content
        assert "main" in content

    def test_read_primer(self, sidecar_dir):
        assert read_primer(sidecar_dir) is None

        (sidecar_dir / "primer.md").write_text("test primer content")
        assert read_primer(sidecar_dir) == "test primer content"

    def test_write_primer_no_decisions(self, sidecar_dir):
        git_ctx = GitContext(is_repo=False)
        path = write_primer(sidecar_dir, "Did some work", git_ctx, [])
        content = path.read_text()
        assert "Did some work" in content
        assert "Decisions" not in content


# ── Reflect Tests ─────────────────────────────────────────────────────────


class TestReflect:
    def test_interactive_reflect(self, sidecar_dir):
        result = interactive_reflect(
            sidecar_dir,
            accomplishments="Added authentication",
            decisions=["Use JWT for API auth"],
            lessons=["Token rotation needs careful rollout"],
            next_session_notes="Start on authorization next",
        )
        assert result["knowledge_created"] == 2  # 1 decision + 1 lesson
        assert Path(result["primer_path"]).exists()

        # Knowledge should be queryable
        from sidecar.v3.knowledge import recall

        results = recall("JWT authentication", sidecar_dir=sidecar_dir)
        assert len(results) > 0

    def test_interactive_reflect_no_knowledge(self, sidecar_dir):
        result = interactive_reflect(
            sidecar_dir,
            accomplishments="Just reviewed code",
        )
        assert result["knowledge_created"] == 0
        assert Path(result["primer_path"]).exists()

    def test_auto_reflect_no_git(self, sidecar_dir):
        # Auto-reflect in non-git directory should still work
        result = auto_reflect(sidecar_dir, cwd=sidecar_dir)
        assert "session_id" in result
        assert Path(result["primer_path"]).exists()


# ── Brief Tests ───────────────────────────────────────────────────────────


class TestBrief:
    def test_generate_brief_with_knowledge(self, populated_project):
        sdir = populated_project / ".sidecar"
        text = generate_brief("add dark mode", sidecar_dir=sdir)
        assert "BRIEF:" in text
        assert "dark mode" in text
        # Should find theming-related knowledge
        assert "DECISIONS" in text or "CONSTRAINTS" in text or "LESSONS" in text

    def test_generate_brief_empty_store(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        text = generate_brief("anything", sidecar_dir=sdir)
        assert "No specific knowledge found" in text

    def test_generate_brief_json(self, populated_project):
        sdir = populated_project / ".sidecar"
        data = generate_brief_json("database query", sidecar_dir=sdir)
        assert data["task"] == "database query"
        assert isinstance(data["knowledge"], list)
        assert "git" in data
        assert "session" in data

    def test_brief_includes_session_context(self, populated_project):
        sdir = populated_project / ".sidecar"
        interactive_reflect(
            sdir,
            accomplishments="Set up theming infrastructure",
            decisions=["CSS variables for runtime theming"],
        )
        text = generate_brief("continue theming", sidecar_dir=sdir)
        assert "SESSION CONTEXT" in text
        assert "theming infrastructure" in text

    def test_brief_with_git_context(self, populated_project):
        sdir = populated_project / ".sidecar"
        # Brief from the sidecar repo should include git context
        text = generate_brief(
            "test task",
            sidecar_dir=sdir,
            cwd=Path("/Users/okasha/AntiGravity/sidecar"),
        )
        assert "GIT CONTEXT" in text


# ── CLI Tests for Brief + Reflect ─────────────────────────────────────────


class TestCLIPhase1:
    def test_brief_command(self, runner, populated_project):
        old_cwd = os.getcwd()
        os.chdir(populated_project)
        try:
            result = runner.invoke(cli, ["brief", "add dark mode"], catch_exceptions=False)
            assert result.exit_code == 0
            assert "BRIEF" in result.output
        finally:
            os.chdir(old_cwd)

    def test_brief_json(self, runner, populated_project):
        old_cwd = os.getcwd()
        os.chdir(populated_project)
        try:
            result = runner.invoke(
                cli, ["brief", "database work", "--json-output"], catch_exceptions=False
            )
            assert result.exit_code == 0
            data = json.loads(result.output)
            assert data["task"] == "database work"
        finally:
            os.chdir(old_cwd)

    def test_brief_primer_flag(self, runner, populated_project):
        old_cwd = os.getcwd()
        os.chdir(populated_project)
        try:
            result = runner.invoke(cli, ["brief", "test task", "--primer"], catch_exceptions=False)
            assert result.exit_code == 0
            assert (populated_project / ".sidecar" / "primer.md").exists()
        finally:
            os.chdir(old_cwd)

    def test_reflect_with_flags(self, runner, populated_project):
        old_cwd = os.getcwd()
        os.chdir(populated_project)
        try:
            result = runner.invoke(
                cli,
                [
                    "reflect",
                    "--summary",
                    "Built the dark mode",
                    "--decision",
                    "Used CSS variables",
                    "--lesson",
                    "Email templates need fallbacks",
                ],
                catch_exceptions=False,
            )
            assert result.exit_code == 0
            assert "Reflect complete" in result.output
            assert "Knowledge items created: 2" in result.output
        finally:
            os.chdir(old_cwd)

    def test_reflect_auto(self, runner, populated_project):
        old_cwd = os.getcwd()
        os.chdir(populated_project)
        try:
            result = runner.invoke(cli, ["reflect", "--auto"], catch_exceptions=False)
            assert result.exit_code == 0
            assert "Auto-reflect complete" in result.output
        finally:
            os.chdir(old_cwd)

    def test_full_workflow(self, runner, tmp_path):
        """Test the complete init -> learn -> brief -> reflect -> brief cycle."""
        old_cwd = os.getcwd()
        os.chdir(tmp_path)
        try:
            # Init
            runner.invoke(cli, ["init"], catch_exceptions=False)

            # Learn
            runner.invoke(
                cli,
                ["learn", "Design tokens for theming", "--tags", "theme"],
                catch_exceptions=False,
            )
            runner.invoke(
                cli,
                ["learn", "--constraint", "All colors from tokens, never hardcoded"],
                catch_exceptions=False,
            )

            # Brief
            result = runner.invoke(cli, ["brief", "add dark mode"], catch_exceptions=False)
            assert result.exit_code == 0
            assert "BRIEF" in result.output

            # Reflect
            result = runner.invoke(
                cli,
                ["reflect", "--summary", "Added dark mode support", "--decision", "Used CSS vars"],
                catch_exceptions=False,
            )
            assert result.exit_code == 0

            # Brief again — should include session context
            result = runner.invoke(cli, ["brief", "continue dark mode"], catch_exceptions=False)
            assert result.exit_code == 0
            assert "SESSION CONTEXT" in result.output

            # Status
            result = runner.invoke(cli, ["status"], catch_exceptions=False)
            assert result.exit_code == 0
        finally:
            os.chdir(old_cwd)
