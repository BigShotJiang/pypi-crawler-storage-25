"""Tests for sidecar v3 prompt enhancement: vague detection, safety, standards, rules."""

import pytest
import yaml

from sidecar.v3.db import KnowledgeItem
from sidecar.v3.hooks import (
    BRACKET_FRESH,
    BRACKET_MODERATE,
    _apply_prompt_rules,
    _default_state,
    _detect_sensitive_areas,
    _detect_vague_prompt,
    _enhance_prompt,
    _get_coding_standards,
    _load_prompt_rules,
    _write_state,
    prompt_hook,
)
from sidecar.v3.knowledge import init_project, learn


@pytest.fixture
def tmp_project(tmp_path):
    init_project(tmp_path)
    return tmp_path


@pytest.fixture
def project_with_constraints(tmp_project):
    sdir = tmp_project / ".sidecar"
    learn(
        "All API responses must include pagination", type="constraint", tags="api", sidecar_dir=sdir
    )
    learn(
        "Never store secrets in environment variables in code",
        type="constraint",
        tags="security",
        sidecar_dir=sdir,
    )
    learn(
        "Use TypeScript strict mode for all new files",
        type="constraint",
        tags="typescript",
        sidecar_dir=sdir,
    )
    learn(
        "Auth token rotation broke mobile clients for 3 days",
        type="lesson",
        tags="auth,mobile",
        sidecar_dir=sdir,
    )
    learn(
        "Database migrations must be reversible",
        type="constraint",
        tags="database,migration",
        sidecar_dir=sdir,
    )
    return tmp_project


# ── Vague Prompt Detection ────────────────────────────────────────────────


class TestVaguePromptDetection:
    def test_short_prompt(self):
        result = _detect_vague_prompt("fix bug")
        assert result is not None
        assert "short" in result.lower()

    def test_vague_pattern_fix_it(self):
        result = _detect_vague_prompt("fix it")
        assert result is not None
        # "fix it" is short (6 chars), so triggers short-prompt detection

    def test_vague_pattern_change_that(self):
        result = _detect_vague_prompt("change that")
        assert result is not None

    def test_vague_pattern_help(self):
        result = _detect_vague_prompt("help")
        assert result is not None

    def test_not_vague_with_detail(self):
        result = _detect_vague_prompt(
            "refactor the authentication middleware to use JWT tokens instead of session cookies"
        )
        assert result is None

    def test_not_vague_with_file_ref(self):
        result = _detect_vague_prompt("fix ./src/auth.py")
        assert result is None

    def test_not_vague_with_code_ref(self):
        result = _detect_vague_prompt("fix foo()")
        assert result is None

    def test_empty_prompt(self):
        result = _detect_vague_prompt("")
        assert result is not None


# ── Sensitive Area Detection ──────────────────────────────────────────────


class TestSensitiveAreaDetection:
    def _make_items(self):
        return [
            KnowledgeItem(
                id="1", type="constraint", content="Never store secrets in code", tags="security"
            ),
            KnowledgeItem(
                id="2", type="lesson", content="Auth token rotation broke mobile", tags="auth"
            ),
            KnowledgeItem(id="3", type="decision", content="Use Redis for caching", tags="cache"),
            KnowledgeItem(
                id="4",
                type="constraint",
                content="Database migrations must be reversible",
                tags="database",
            ),
        ]

    def test_detects_security_keyword(self):
        warnings = _detect_sensitive_areas("update security middleware", self._make_items())
        assert len(warnings) >= 1
        assert any("secret" in w.lower() for w in warnings)

    def test_detects_auth_keyword(self):
        warnings = _detect_sensitive_areas("change authentication flow", self._make_items())
        assert len(warnings) >= 1
        # "authentication" contains "auth" as substring, should match

    def test_detects_database_keyword(self):
        warnings = _detect_sensitive_areas("add database migration", self._make_items())
        assert len(warnings) >= 1

    def test_no_sensitive_keywords(self):
        warnings = _detect_sensitive_areas("add dark mode toggle to settings", self._make_items())
        assert warnings == []

    def test_caps_at_five(self):
        items = [
            KnowledgeItem(
                id=str(i), type="constraint", content=f"Security rule {i}", tags="security"
            )
            for i in range(10)
        ]
        warnings = _detect_sensitive_areas("update security", items)
        assert len(warnings) <= 5

    def test_only_constraints_and_lessons(self):
        items = [
            KnowledgeItem(id="1", type="decision", content="Use JWT for auth", tags="auth"),
        ]
        warnings = _detect_sensitive_areas("authentication change", items)
        assert warnings == []  # Decisions are not surfaced as safety warnings


# ── Coding Standards ──────────────────────────────────────────────────────


class TestCodingStandards:
    def test_extracts_constraints(self):
        items = [
            KnowledgeItem(id="1", type="constraint", content="Use strict mode", confidence=1.0),
            KnowledgeItem(id="2", type="decision", content="Redis for cache", confidence=1.0),
            KnowledgeItem(id="3", type="constraint", content="All tests required", confidence=1.0),
        ]
        standards = _get_coding_standards(items)
        assert len(standards) == 2
        assert "strict mode" in standards[0].lower()

    def test_skips_low_confidence(self):
        items = [
            KnowledgeItem(id="1", type="constraint", content="Maybe use tabs", confidence=0.7),
        ]
        assert _get_coding_standards(items) == []

    def test_caps_at_ten(self):
        items = [
            KnowledgeItem(id=str(i), type="constraint", content=f"Rule {i}", confidence=1.0)
            for i in range(15)
        ]
        assert len(_get_coding_standards(items)) == 10


# ── Config-Driven Prompt Rules ───────────────────────────────────────────


class TestPromptRules:
    def test_load_prompt_rules(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        config = yaml.safe_load((sdir / "config.yaml").read_text()) or {}
        config["prompt_rules"] = {
            "always": ["Run tests before committing"],
            "reminders": [{"when": ["deploy"], "say": "Check staging first"}],
        }
        (sdir / "config.yaml").write_text(yaml.dump(config))

        rules = _load_prompt_rules(sdir)
        assert "always" in rules
        assert len(rules["reminders"]) == 1

    def test_load_empty_config(self, tmp_project):
        rules = _load_prompt_rules(tmp_project / ".sidecar")
        assert rules == {} or isinstance(rules, dict)

    def test_load_missing_config(self, tmp_path):
        rules = _load_prompt_rules(tmp_path / "nonexistent")
        assert rules == {}

    def test_apply_always_rules(self):
        rules = {"always": ["Always write tests", "Use type annotations"]}
        result = _apply_prompt_rules("add a new endpoint", rules)
        assert len(result) == 2

    def test_apply_reminder_match(self):
        rules = {
            "reminders": [
                {"when": ["deploy", "release"], "say": "Check staging environment first"},
            ]
        }
        result = _apply_prompt_rules("deploy to production", rules)
        assert len(result) == 1
        assert "staging" in result[0]

    def test_apply_reminder_no_match(self):
        rules = {
            "reminders": [
                {"when": ["deploy"], "say": "Check staging"},
            ]
        }
        result = _apply_prompt_rules("add dark mode", rules)
        assert result == []

    def test_apply_empty_rules(self):
        assert _apply_prompt_rules("anything", {}) == []


# ── Integration: _enhance_prompt ──────────────────────────────────────────


class TestEnhancePrompt:
    def test_vague_prompt_enhancement(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        state = _default_state()
        state["prompt_count"] = 1
        result = _enhance_prompt("fix it", BRACKET_FRESH, [], sdir, state)
        assert any("short" in line.lower() or "ambiguous" in line.lower() for line in result)

    def test_safety_reminders(self, project_with_constraints):
        sdir = project_with_constraints / ".sidecar"
        from sidecar.v3.db import get_db, query_knowledge

        conn = get_db(sdir / "db.sqlite")
        items = query_knowledge(conn)
        conn.close()

        state = _default_state()
        state["prompt_count"] = 5
        result = _enhance_prompt(
            "update authentication middleware", BRACKET_MODERATE, items, sdir, state
        )
        assert any("Safety reminders" in line for line in result)

    def test_coding_standards_first_prompt(self, project_with_constraints):
        sdir = project_with_constraints / ".sidecar"
        from sidecar.v3.db import get_db, query_knowledge

        conn = get_db(sdir / "db.sqlite")
        items = query_knowledge(conn)
        conn.close()

        state = _default_state()
        state["prompt_count"] = 1
        result = _enhance_prompt("start working on the API", BRACKET_FRESH, items, sdir, state)
        assert any("coding standards" in line.lower() for line in result)

    def test_no_standards_after_first_prompt(self, project_with_constraints):
        sdir = project_with_constraints / ".sidecar"
        from sidecar.v3.db import get_db, query_knowledge

        conn = get_db(sdir / "db.sqlite")
        items = query_knowledge(conn)
        conn.close()

        state = _default_state()
        state["prompt_count"] = 2  # Not first prompt
        result = _enhance_prompt("start working on the API", BRACKET_FRESH, items, sdir, state)
        assert not any("coding standards" in line.lower() for line in result)

    def test_config_rules_injection(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        config = yaml.safe_load((sdir / "config.yaml").read_text()) or {}
        config["prompt_rules"] = {
            "always": ["Remember to write tests"],
        }
        (sdir / "config.yaml").write_text(yaml.dump(config))

        state = _default_state()
        state["prompt_count"] = 5
        result = _enhance_prompt("add feature X", BRACKET_MODERATE, [], sdir, state)
        assert any("Project guidance" in line for line in result)
        assert any("tests" in line.lower() for line in result)


# ── Integration: prompt_hook with enhancement ────────────────────────────


class TestPromptHookEnhancement:
    def test_vague_prompt_gets_tip(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        output = prompt_hook("fix it", sidecar_dir=sdir)
        assert "tip" in output.lower()

    def test_sensitive_area_warning(self, project_with_constraints):
        sdir = project_with_constraints / ".sidecar"
        _write_state(sdir, _default_state())
        output = prompt_hook(
            "refactor the authentication module to support OAuth", sidecar_dir=sdir
        )
        assert "Safety reminders" in output

    def test_first_prompt_includes_standards(self, project_with_constraints):
        sdir = project_with_constraints / ".sidecar"
        _write_state(sdir, _default_state())
        output = prompt_hook(
            "start working on the new feature for the application settings page", sidecar_dir=sdir
        )
        assert "coding standards" in output.lower()

    def test_normal_prompt_no_extra_noise(self, project_with_constraints):
        sdir = project_with_constraints / ".sidecar"
        # Set state past first prompt, no sensitive keywords
        state = _default_state()
        state["prompt_count"] = 5
        state["last_prompt_ts"] = __import__("time").time()
        _write_state(sdir, state)
        output = prompt_hook(
            "add a toggle for dark mode in the user preferences panel", sidecar_dir=sdir
        )
        # Should not have vague warning or safety reminders
        assert "ambiguous" not in output.lower()
        assert "Safety reminders" not in output
