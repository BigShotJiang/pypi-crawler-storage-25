"""Tests for sidecar v3 core: db, knowledge, retrieval, mirror, cli."""

import json

import pytest
from click.testing import CliRunner

from sidecar.v3.cli import cli
from sidecar.v3.db import (
    KnowledgeItem,
    count_knowledge,
    get_db,
    insert_knowledge,
    query_knowledge,
)
from sidecar.v3.knowledge import (
    find_sidecar_dir,
    format_recall_results,
    init_project,
    learn,
    recall,
)
from sidecar.v3.mirror import mirror_path, write_mirror
from sidecar.v3.retrieval import _keyword_score, _tokenize, rank_items

# ── Fixtures ──────────────────────────────────────────────────────────────


@pytest.fixture
def tmp_project(tmp_path):
    """Create a temporary project with sidecar initialized."""
    init_project(tmp_path)
    return tmp_path


@pytest.fixture
def sidecar_dir(tmp_project):
    return tmp_project / ".sidecar"


@pytest.fixture
def db_conn(sidecar_dir):
    conn = get_db(sidecar_dir / "db.sqlite")
    yield conn
    conn.close()


@pytest.fixture
def runner():
    return CliRunner()


# ── Database Tests ────────────────────────────────────────────────────────


class TestDatabase:
    def test_schema_creation(self, db_conn):
        tables = db_conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"
        ).fetchall()
        names = [t["name"] for t in tables]
        assert "knowledge" in names
        assert "sessions" in names

    def test_schema_version(self, db_conn):
        version = db_conn.execute("PRAGMA user_version").fetchone()[0]
        assert version == 3

    def test_insert_and_query(self, db_conn):
        item = KnowledgeItem(id="test1", type="decision", content="Use PostgreSQL")
        insert_knowledge(db_conn, item)

        results = query_knowledge(db_conn)
        assert len(results) == 1
        assert results[0].content == "Use PostgreSQL"
        assert results[0].type == "decision"

    def test_type_filter(self, db_conn):
        insert_knowledge(
            db_conn,
            KnowledgeItem(id="d1", type="decision", content="Decision one"),
        )
        insert_knowledge(
            db_conn,
            KnowledgeItem(id="c1", type="constraint", content="Constraint one"),
        )

        decisions = query_knowledge(db_conn, type_filter="decision")
        assert len(decisions) == 1
        assert decisions[0].type == "decision"

        constraints = query_knowledge(db_conn, type_filter="constraint")
        assert len(constraints) == 1
        assert constraints[0].type == "constraint"

    def test_superseded_filtering(self, db_conn):
        insert_knowledge(
            db_conn,
            KnowledgeItem(id="old", type="decision", content="Old decision", superseded_by="new"),
        )
        insert_knowledge(
            db_conn,
            KnowledgeItem(id="new", type="decision", content="New decision"),
        )

        active = query_knowledge(db_conn)
        assert len(active) == 1
        assert active[0].id == "new"

        all_items = query_knowledge(db_conn, include_superseded=True)
        assert len(all_items) == 2

    def test_count_knowledge(self, db_conn):
        insert_knowledge(
            db_conn,
            KnowledgeItem(id="d1", type="decision", content="D1"),
        )
        insert_knowledge(
            db_conn,
            KnowledgeItem(id="d2", type="decision", content="D2"),
        )
        insert_knowledge(
            db_conn,
            KnowledgeItem(id="c1", type="constraint", content="C1"),
        )

        counts = count_knowledge(db_conn)
        assert counts["decision"] == 2
        assert counts["constraint"] == 1


# ── Retrieval Tests ───────────────────────────────────────────────────────


class TestRetrieval:
    def test_tokenize(self):
        tokens = _tokenize("Use PostgreSQL for database!")
        assert tokens == ["use", "postgresql", "for", "database"]

    def test_keyword_score_match(self):
        query = _tokenize("database")
        content = _tokenize("PostgreSQL chosen for database concurrent writes")
        score = _keyword_score(query, content)
        assert score > 0

    def test_keyword_score_no_match(self):
        query = _tokenize("database")
        content = _tokenize("design tokens for theming in frontend")
        score = _keyword_score(query, content)
        assert score == 0

    def test_rank_items_keyword_relevance(self):
        """Items with matching keywords should rank higher."""
        items = [
            KnowledgeItem(id="1", type="decision", content="Design tokens for theming"),
            KnowledgeItem(id="2", type="decision", content="PostgreSQL for database storage"),
            KnowledgeItem(id="3", type="lesson", content="Database migration broke production"),
        ]

        ranked = rank_items("database", items)
        ids = [item.id for item, _ in ranked]

        # Items 2 and 3 mention "database", item 1 does not
        assert "1" not in ids
        assert "2" in ids
        assert "3" in ids

    def test_rank_items_tag_boost(self):
        """Items with matching tags should score higher."""
        items = [
            KnowledgeItem(
                id="1", type="decision", content="Some general config", tags="database,postgres"
            ),
            KnowledgeItem(
                id="2", type="decision", content="Some other config", tags="frontend,css"
            ),
        ]

        ranked = rank_items("database", items)
        assert len(ranked) > 0
        assert ranked[0][0].id == "1"

    def test_rank_items_empty(self):
        ranked = rank_items("anything", [])
        assert ranked == []

    def test_confidence_weighting(self):
        """Auto-captured items (confidence < 1.0) should rank lower."""
        items = [
            KnowledgeItem(id="1", type="decision", content="database choice", confidence=0.7),
            KnowledgeItem(id="2", type="decision", content="database choice", confidence=1.0),
        ]

        ranked = rank_items("database", items)
        assert ranked[0][0].id == "2"  # Higher confidence ranks first


# ── Knowledge Operations Tests ────────────────────────────────────────────


class TestKnowledge:
    def test_init_project(self, tmp_path):
        sdir = init_project(tmp_path, project_name="test-proj")
        assert (sdir / "config.yaml").exists()
        assert (sdir / "db.sqlite").exists()
        assert (sdir / "knowledge" / "decisions").is_dir()
        assert (sdir / "knowledge" / "constraints").is_dir()
        assert (sdir / "knowledge" / "relationships").is_dir()
        assert (sdir / "knowledge" / "lessons").is_dir()

    def test_find_sidecar_dir(self, tmp_project):
        found = find_sidecar_dir(tmp_project)
        assert found == tmp_project / ".sidecar"

        # Should also work from a subdirectory
        sub = tmp_project / "src" / "deep"
        sub.mkdir(parents=True)
        found = find_sidecar_dir(sub)
        assert found == tmp_project / ".sidecar"

    def test_learn_creates_item(self, tmp_project):
        item = learn(
            "Use TypeScript strict mode",
            type="decision",
            tags="typescript,config",
            sidecar_dir=tmp_project / ".sidecar",
        )
        assert item.type == "decision"
        assert item.content == "Use TypeScript strict mode"
        assert item.tags == "typescript,config"
        assert item.id  # Should have auto-generated ID

    def test_learn_auto_tags(self, tmp_project):
        item = learn(
            "All API endpoints must use authentication via OAuth",
            sidecar_dir=tmp_project / ".sidecar",
        )
        assert "api" in item.tags
        assert "auth" in item.tags

    def test_learn_invalid_type(self, tmp_project):
        with pytest.raises(ValueError, match="Invalid type"):
            learn("something", type="invalid", sidecar_dir=tmp_project / ".sidecar")

    def test_learn_and_recall(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        learn("Design tokens for all theming in src/theme/", tags="theme,design", sidecar_dir=sdir)
        learn("PostgreSQL for production database", tags="database", sidecar_dir=sdir)
        learn(
            "Never hardcode API keys",
            type="constraint",
            tags="security",
            sidecar_dir=sdir,
        )

        # Recall should find relevant items
        results = recall("theming", sidecar_dir=sdir)
        assert len(results) > 0
        contents = [item.content for item, _ in results]
        assert any("design tokens" in c.lower() or "theming" in c.lower() for c in contents)

    def test_recall_type_filter(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        learn("Decision about auth", sidecar_dir=sdir)
        learn("Auth constraint", type="constraint", sidecar_dir=sdir)

        results = recall("auth", type_filter="constraint", sidecar_dir=sdir)
        for item, _ in results:
            assert item.type == "constraint"

    def test_recall_empty_store(self, tmp_project):
        results = recall("anything", sidecar_dir=tmp_project / ".sidecar")
        assert results == []

    def test_format_recall_results(self):
        results = [
            (
                KnowledgeItem(id="1", type="decision", content="Use TS", created_at="2026-03-25"),
                0.9,
            ),
            (
                KnowledgeItem(
                    id="2", type="constraint", content="No Redis", created_at="2026-03-25"
                ),
                0.8,
            ),
            (
                KnowledgeItem(
                    id="3", type="lesson", content="Bug in auth", created_at="2026-03-25"
                ),
                0.7,
            ),
        ]
        text = format_recall_results(results)
        assert "DECISIONS:" in text
        assert "Use TS" in text
        assert "CONSTRAINTS:" in text
        assert "No Redis" in text
        assert "LESSONS:" in text
        assert "Bug in auth" in text

    def test_format_empty(self):
        assert format_recall_results([]) == "No relevant knowledge found."


# ── Mirror Tests ──────────────────────────────────────────────────────────


class TestMirror:
    def test_write_mirror(self, sidecar_dir):
        item = KnowledgeItem(
            id="abc123",
            type="decision",
            content="Use design tokens for theming",
            tags="theme,frontend",
            created_at="2026-03-25T00:00:00Z",
        )
        path = write_mirror(sidecar_dir, item)
        assert path.exists()
        text = path.read_text()
        assert "type: decision" in text
        assert "Use design tokens for theming" in text
        assert "tags: theme,frontend" in text

    def test_mirror_path_organization(self, sidecar_dir):
        for ktype, expected_dir in [
            ("decision", "decisions"),
            ("constraint", "constraints"),
            ("relationship", "relationships"),
            ("lesson", "lessons"),
        ]:
            item = KnowledgeItem(id="x", type=ktype, content="test")
            path = mirror_path(sidecar_dir, item)
            assert expected_dir in str(path)

    def test_learn_creates_mirror(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        learn("PostgreSQL for database", tags="db", sidecar_dir=sdir)

        md_files = list((sdir / "knowledge" / "decisions").glob("*.md"))
        assert len(md_files) == 1
        assert "postgresql" in md_files[0].name.lower()


# ── CLI Tests ─────────────────────────────────────────────────────────────


class TestCLI:
    def test_version(self, runner):
        result = runner.invoke(cli, ["--version"])
        assert result.exit_code == 0
        assert "3.0.0" in result.output

    def test_init_command(self, runner, tmp_path):
        result = runner.invoke(cli, ["init"], catch_exceptions=False)
        # May fail if already initialized or wrong dir, but shouldn't crash
        assert result.exit_code in (0, 1)

    def test_learn_no_init(self, runner, tmp_path):
        """Learn should fail gracefully without init."""
        import os

        old_cwd = os.getcwd()
        os.chdir(tmp_path)
        try:
            result = runner.invoke(cli, ["learn", "test knowledge"])
            assert result.exit_code == 1
            assert "sidecar init" in result.output.lower() or "no .sidecar" in result.output.lower()
        finally:
            os.chdir(old_cwd)

    def test_learn_json_output(self, runner, tmp_project):
        import os

        old_cwd = os.getcwd()
        os.chdir(tmp_project)
        try:
            result = runner.invoke(
                cli, ["learn", "Test decision", "--json-output"], catch_exceptions=False
            )
            assert result.exit_code == 0
            data = json.loads(result.output)
            assert data["type"] == "decision"
            assert data["content"] == "Test decision"
        finally:
            os.chdir(old_cwd)

    def test_recall_json_output(self, runner, tmp_project):
        import os

        old_cwd = os.getcwd()
        os.chdir(tmp_project)
        try:
            runner.invoke(cli, ["learn", "Design tokens for theming", "--tags", "theme"])
            result = runner.invoke(
                cli, ["recall", "theming", "--json-output"], catch_exceptions=False
            )
            assert result.exit_code == 0
            data = json.loads(result.output)
            assert isinstance(data, list)
        finally:
            os.chdir(old_cwd)

    def test_status_command(self, runner, tmp_project):
        import os

        old_cwd = os.getcwd()
        os.chdir(tmp_project)
        try:
            runner.invoke(cli, ["learn", "Some knowledge"])
            result = runner.invoke(cli, ["status"], catch_exceptions=False)
            assert result.exit_code == 0
            assert "1" in result.output  # At least 1 item
        finally:
            os.chdir(old_cwd)
