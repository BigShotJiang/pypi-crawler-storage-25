"""Tests for sidecar v3 Phase 2: hooks, context brackets, install commands."""

import json
import os
import time
from pathlib import Path

import pytest
from click.testing import CliRunner

from sidecar.v3.cli import cli
from sidecar.v3.hooks import (
    BRACKET_DEPLETED,
    BRACKET_FRESH,
    BRACKET_MODERATE,
    _default_state,
    _read_state,
    _write_state,
    get_bracket,
    prompt_hook,
    stop_hook,
)
from sidecar.v3.knowledge import init_project, learn


@pytest.fixture
def tmp_project(tmp_path):
    init_project(tmp_path)
    return tmp_path


@pytest.fixture
def sidecar_dir(tmp_project):
    return tmp_project / ".sidecar"


@pytest.fixture
def populated_project(tmp_project):
    sdir = tmp_project / ".sidecar"
    learn("Design tokens for all theming", tags="theme,design", sidecar_dir=sdir)
    learn("Never hardcode API keys", type="constraint", tags="security", sidecar_dir=sdir)
    learn(
        "Auth token changes broke mobile for 3 days",
        type="lesson",
        tags="auth,mobile",
        sidecar_dir=sdir,
    )
    return tmp_project


@pytest.fixture
def runner():
    return CliRunner()


# ── Context Bracket Tests ─────────────────────────────────────────────────


class TestContextBrackets:
    def test_fresh_bracket(self):
        assert get_bracket(1) == BRACKET_FRESH
        assert get_bracket(2) == BRACKET_FRESH
        assert get_bracket(3) == BRACKET_FRESH

    def test_moderate_bracket(self):
        assert get_bracket(4) == BRACKET_MODERATE
        assert get_bracket(10) == BRACKET_MODERATE
        assert get_bracket(15) == BRACKET_MODERATE

    def test_depleted_bracket(self):
        assert get_bracket(16) == BRACKET_DEPLETED
        assert get_bracket(50) == BRACKET_DEPLETED

    def test_state_default(self):
        state = _default_state()
        assert state["prompt_count"] == 0
        assert state["last_prompt_ts"] == 0
        assert state["knowledge_injected"] == []

    def test_state_read_write(self, sidecar_dir):
        state = {"prompt_count": 5, "last_prompt_ts": time.time(), "knowledge_injected": ["a"]}
        _write_state(sidecar_dir, state)
        loaded = _read_state(sidecar_dir)
        assert loaded["prompt_count"] == 5

    def test_state_stale_reset(self, sidecar_dir):
        # Write state with old timestamp
        state = {
            "prompt_count": 10,
            "last_prompt_ts": time.time() - 10000,
            "knowledge_injected": [],
        }
        _write_state(sidecar_dir, state)
        loaded = _read_state(sidecar_dir)
        # Should reset because it's stale
        assert loaded["prompt_count"] == 0

    def test_state_missing_file(self, sidecar_dir):
        loaded = _read_state(sidecar_dir)
        assert loaded["prompt_count"] == 0


# ── Prompt Hook Tests ─────────────────────────────────────────────────────


class TestPromptHook:
    def test_prompt_hook_empty_store(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        output = prompt_hook("add dark mode to the settings panel", sidecar_dir=sdir)
        assert output == ""

    def test_prompt_hook_returns_knowledge(self, populated_project):
        sdir = populated_project / ".sidecar"
        output = prompt_hook("add theming support", sidecar_dir=sdir)
        assert "Sidecar" in output
        assert "design tokens" in output.lower() or "theming" in output.lower()

    def test_prompt_hook_fresh_includes_all_types(self, populated_project):
        sdir = populated_project / ".sidecar"
        output = prompt_hook("security and API design", sidecar_dir=sdir)
        # FRESH bracket should include all types
        assert "Project Knowledge" in output

    def test_prompt_hook_bracket_progression(self, populated_project):
        sdir = populated_project / ".sidecar"
        # Reset state
        _write_state(sdir, _default_state())

        # Prompt 1-3: FRESH
        out1 = prompt_hook("theming", sidecar_dir=sdir)
        assert "Project Knowledge" in out1  # FRESH header

        prompt_hook("colors", sidecar_dir=sdir)
        prompt_hook("fonts", sidecar_dir=sdir)

        # Prompt 4: MODERATE — should only show constraints/lessons not yet injected
        out4 = prompt_hook("security", sidecar_dir=sdir)
        # MODERATE outputs only constraints/lessons not already injected
        if out4:
            assert "constraints" in out4.lower() or "lessons" in out4.lower() or out4 == ""

    def test_prompt_hook_no_sidecar(self):
        output = prompt_hook("anything", sidecar_dir=Path("/nonexistent"))
        assert output == ""

    def test_prompt_hook_increments_count(self, populated_project):
        sdir = populated_project / ".sidecar"
        _write_state(sdir, _default_state())

        prompt_hook("test", sidecar_dir=sdir)
        state = _read_state(sdir)
        assert state["prompt_count"] == 1

        prompt_hook("test again", sidecar_dir=sdir)
        state = _read_state(sdir)
        assert state["prompt_count"] == 2


# ── Stop Hook Tests ───────────────────────────────────────────────────────


class TestStopHook:
    def test_stop_hook_no_activity(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        output = stop_hook(sidecar_dir=sdir)
        assert output == ""  # No prompts, no nudge

    def test_stop_hook_after_activity(self, populated_project):
        sdir = populated_project / ".sidecar"
        # Simulate 5 prompts
        state = {"prompt_count": 5, "last_prompt_ts": time.time(), "knowledge_injected": []}
        _write_state(sdir, state)

        output = stop_hook(sidecar_dir=sdir)
        assert "5 exchanges" in output
        assert "sidecar reflect" in output

    def test_stop_hook_resets_state(self, populated_project):
        sdir = populated_project / ".sidecar"
        state = {"prompt_count": 5, "last_prompt_ts": time.time(), "knowledge_injected": []}
        _write_state(sdir, state)

        stop_hook(sidecar_dir=sdir)
        new_state = _read_state(sdir)
        assert new_state["prompt_count"] == 0

    def test_stop_hook_too_few_prompts(self, populated_project):
        sdir = populated_project / ".sidecar"
        state = {"prompt_count": 2, "last_prompt_ts": time.time(), "knowledge_injected": []}
        _write_state(sdir, state)

        output = stop_hook(sidecar_dir=sdir)
        assert output == ""  # < 3 prompts, no nudge


# ── CLI Hook Tests ────────────────────────────────────────────────────────


class TestCLIHooks:
    def test_hook_prompt_command(self, runner, populated_project):
        old_cwd = os.getcwd()
        os.chdir(populated_project)
        try:
            result = runner.invoke(cli, ["hook", "prompt", "add dark mode"], catch_exceptions=False)
            assert result.exit_code == 0
        finally:
            os.chdir(old_cwd)

    def test_hook_stop_command(self, runner, populated_project):
        old_cwd = os.getcwd()
        os.chdir(populated_project)
        try:
            result = runner.invoke(cli, ["hook", "stop"], catch_exceptions=False)
            assert result.exit_code == 0
        finally:
            os.chdir(old_cwd)


# ── Install Commands Tests ────────────────────────────────────────────────


class TestInstallCommands:
    def test_install_hooks_dry_run(self, runner, tmp_project):
        old_cwd = os.getcwd()
        os.chdir(tmp_project)
        try:
            result = runner.invoke(cli, ["install-hooks", "--dry-run"], catch_exceptions=False)
            assert result.exit_code == 0
            assert "UserPromptSubmit" in result.output
            assert "sidecar hook prompt" in result.output
        finally:
            os.chdir(old_cwd)

    def test_install_hooks_writes_file(self, runner, tmp_project):
        old_cwd = os.getcwd()
        os.chdir(tmp_project)
        try:
            result = runner.invoke(cli, ["install-hooks"], catch_exceptions=False)
            assert result.exit_code == 0

            settings = json.loads((tmp_project / ".claude" / "settings.local.json").read_text())
            assert "hooks" in settings
            assert "UserPromptSubmit" in settings["hooks"]
            assert "Stop" in settings["hooks"]
        finally:
            os.chdir(old_cwd)

    def test_install_hooks_no_duplicate(self, runner, tmp_project):
        old_cwd = os.getcwd()
        os.chdir(tmp_project)
        try:
            runner.invoke(cli, ["install-hooks"], catch_exceptions=False)
            runner.invoke(cli, ["install-hooks"], catch_exceptions=False)

            settings = json.loads((tmp_project / ".claude" / "settings.local.json").read_text())
            # Should not have duplicate handlers
            assert len(settings["hooks"]["UserPromptSubmit"]) == 1
            assert len(settings["hooks"]["Stop"]) == 1
        finally:
            os.chdir(old_cwd)

    def test_install_hooks_preserves_existing(self, runner, tmp_project):
        old_cwd = os.getcwd()
        os.chdir(tmp_project)
        try:
            # Write existing settings
            claude_dir = tmp_project / ".claude"
            claude_dir.mkdir(exist_ok=True)
            existing = {"permissions": {"allow": ["sidecar"]}, "hooks": {}}
            (claude_dir / "settings.local.json").write_text(json.dumps(existing))

            runner.invoke(cli, ["install-hooks"], catch_exceptions=False)

            settings = json.loads((claude_dir / "settings.local.json").read_text())
            assert settings["permissions"]["allow"] == ["sidecar"]
            assert "UserPromptSubmit" in settings["hooks"]
        finally:
            os.chdir(old_cwd)

    def test_install_skill(self, runner, tmp_project):
        old_cwd = os.getcwd()
        os.chdir(tmp_project)
        try:
            result = runner.invoke(cli, ["install-skill"], catch_exceptions=False)
            assert result.exit_code == 0
            skill_path = tmp_project / ".claude" / "skills" / "sidecar" / "SKILL.md"
            assert skill_path.exists()
            content = skill_path.read_text()
            assert "sidecar" in content
            assert "brief" in content
        finally:
            os.chdir(old_cwd)

    def test_setup_command(self, runner, tmp_path):
        old_cwd = os.getcwd()
        os.chdir(tmp_path)
        try:
            result = runner.invoke(cli, ["setup"], catch_exceptions=False)
            assert result.exit_code == 0

            # Should have created everything
            assert (tmp_path / ".sidecar" / "db.sqlite").exists()
            assert (tmp_path / ".claude" / "settings.local.json").exists()
            assert (tmp_path / ".claude" / "skills" / "sidecar" / "SKILL.md").exists()
        finally:
            os.chdir(old_cwd)
