"""End-to-end integration tests for sidecar v3.

Tests full workflows across features, not individual units.
"""

import json
import os
from datetime import UTC, datetime, timedelta

import pytest
import yaml
from click.testing import CliRunner

from sidecar.v3.cli import cli
from sidecar.v3.db import get_db
from sidecar.v3.knowledge import init_project


@pytest.fixture
def runner():
    return CliRunner()


@pytest.fixture
def fresh_project(tmp_path):
    """A project directory with basic files but NO sidecar init."""
    (tmp_path / "README.md").write_text("# My Project\nA test project.\n")
    (tmp_path / "pyproject.toml").write_text(
        '[project]\nname = "my-project"\nrequires-python = ">=3.11"\n'
    )
    src = tmp_path / "src"
    src.mkdir()
    (src / "main.py").write_text(
        "from fastapi import FastAPI\n\napp = FastAPI()\n\n"
        "@app.get('/health')\ndef health(): return {'ok': True}\n"
    )
    tests = tmp_path / "tests"
    tests.mkdir()
    (tests / "test_main.py").write_text("def test_health(): assert True\n")
    return tmp_path


# ── Full Lifecycle ──────────────────────────────────────────────────────


class TestFullLifecycle:
    """Test the complete sidecar workflow from init to compile."""

    def test_init_learn_recall_compile(self, runner, fresh_project):
        old_cwd = os.getcwd()
        os.chdir(fresh_project)
        try:
            # 1. Init
            result = runner.invoke(cli, ["init"], catch_exceptions=False)
            assert result.exit_code == 0
            assert (fresh_project / ".sidecar" / "db.sqlite").exists()

            # 2. Learn some knowledge
            result = runner.invoke(
                cli,
                ["learn", "Use FastAPI for REST API", "--type", "decision", "--domain", "backend"],
                catch_exceptions=False,
            )
            assert result.exit_code == 0
            assert "Learned" in result.output

            result = runner.invoke(
                cli,
                ["learn", "All APIs must return JSON", "--constraint"],
                catch_exceptions=False,
            )
            assert result.exit_code == 0

            result = runner.invoke(
                cli,
                ["learn", "Migration failed when we skipped testing", "--lesson"],
                catch_exceptions=False,
            )
            assert result.exit_code == 0

            # 3. Recall
            result = runner.invoke(cli, ["recall", "API design"], catch_exceptions=False)
            assert result.exit_code == 0
            assert "FastAPI" in result.output or "JSON" in result.output

            # 4. Compile
            result = runner.invoke(cli, ["compile"], catch_exceptions=False)
            assert result.exit_code == 0
            assert "Coding Standards" in result.output
            assert "Architecture Decisions" in result.output

            # 5. Status
            result = runner.invoke(cli, ["status"], catch_exceptions=False)
            assert result.exit_code == 0
            assert "decision" in result.output
            assert "constraint" in result.output

        finally:
            os.chdir(old_cwd)

    def test_init_onboard_compile_workflow(self, runner, fresh_project):
        old_cwd = os.getcwd()
        os.chdir(fresh_project)
        try:
            # 1. Init
            runner.invoke(cli, ["init"], catch_exceptions=False)

            # 2. Onboard
            result = runner.invoke(cli, ["onboard", "-y"], catch_exceptions=False)
            assert result.exit_code == 0

            # 3. Status should show imported items
            result = runner.invoke(cli, ["status"], catch_exceptions=False)
            assert result.exit_code == 0

            # 4. Compile should produce output from onboarded knowledge
            result = runner.invoke(cli, ["compile", "--format", "skill"], catch_exceptions=False)
            assert result.exit_code == 0

        finally:
            os.chdir(old_cwd)

    def test_learn_supersede_recall_flow(self, runner, fresh_project):
        old_cwd = os.getcwd()
        os.chdir(fresh_project)
        try:
            runner.invoke(cli, ["init"], catch_exceptions=False)

            # Learn original
            result = runner.invoke(
                cli,
                ["learn", "Use Redis 6 for caching", "--json-output"],
                catch_exceptions=False,
            )
            item_id = json.loads(result.output)["id"]

            # Supersede it
            result = runner.invoke(
                cli,
                ["supersede", item_id, "Use Redis 7 for caching"],
                catch_exceptions=False,
            )
            assert result.exit_code == 0
            assert "Superseded" in result.output

            # Recall should show new, not old
            result = runner.invoke(
                cli, ["recall", "caching", "--json-output"], catch_exceptions=False
            )
            items = json.loads(result.output)
            contents = [i["content"] for i in items]
            assert "Use Redis 7 for caching" in contents
            assert "Use Redis 6 for caching" not in contents

        finally:
            os.chdir(old_cwd)


# ── Recipe + Knowledge Integration ──────────────────────────────────────


class TestRecipeIntegration:
    def test_install_recipe_then_compile(self, runner, fresh_project):
        old_cwd = os.getcwd()
        os.chdir(fresh_project)
        try:
            runner.invoke(cli, ["init"], catch_exceptions=False)

            # Install recipe
            result = runner.invoke(cli, ["recipe", "install", "cli-python"], catch_exceptions=False)
            assert result.exit_code == 0
            assert "Installed" in result.output

            # Compile should include recipe items
            result = runner.invoke(cli, ["compile"], catch_exceptions=False)
            assert result.exit_code == 0
            assert "Click" in result.output or "exit codes" in result.output.lower()

            # Recipe should appear in list
            result = runner.invoke(cli, ["recipe", "list"], catch_exceptions=False)
            assert "cli-python" in result.output

        finally:
            os.chdir(old_cwd)

    def test_install_recipe_then_detect_conflicts(self, runner, fresh_project):
        old_cwd = os.getcwd()
        os.chdir(fresh_project)
        try:
            runner.invoke(cli, ["init"], catch_exceptions=False)

            # Install recipe
            runner.invoke(cli, ["recipe", "install", "fastapi"], catch_exceptions=False)

            # Add a conflicting decision
            runner.invoke(
                cli,
                ["learn", "Avoid Pydantic models, use raw dicts for API schemas"],
                catch_exceptions=False,
            )

            # Check conflicts — may or may not detect depending on keyword overlap
            result = runner.invoke(cli, ["conflicts"], catch_exceptions=False)
            assert result.exit_code == 0

        finally:
            os.chdir(old_cwd)

    def test_extract_then_inspect(self, runner, fresh_project):
        old_cwd = os.getcwd()
        os.chdir(fresh_project)
        try:
            runner.invoke(cli, ["init"], catch_exceptions=False)
            runner.invoke(
                cli, ["learn", "Use PostgreSQL", "--type", "decision"], catch_exceptions=False
            )
            runner.invoke(
                cli,
                ["learn", "All queries must use parameterized SQL", "--constraint"],
                catch_exceptions=False,
            )

            # Extract
            outfile = fresh_project / "my-recipe.yaml"
            result = runner.invoke(
                cli, ["recipe", "extract", "-o", str(outfile)], catch_exceptions=False
            )
            assert result.exit_code == 0
            assert outfile.exists()

            # Verify YAML is valid and contains items
            data = yaml.safe_load(outfile.read_text())
            assert len(data["items"]) >= 2

        finally:
            os.chdir(old_cwd)


# ── Phase + Audit Integration ───────────────────────────────────────────


class TestPhaseIntegration:
    def test_upgrade_creates_constraints_that_compile_shows(self, runner, fresh_project):
        old_cwd = os.getcwd()
        os.chdir(fresh_project)
        try:
            runner.invoke(cli, ["init"], catch_exceptions=False)

            # Upgrade to mvp (auto-accept findings)
            result = runner.invoke(cli, ["upgrade", "mvp", "--auto"], catch_exceptions=False)
            assert result.exit_code == 0

            # Phase should be mvp now
            result = runner.invoke(cli, ["depth"], catch_exceptions=False)
            assert "mvp" in result.output

            # Compile should show any audit-created constraints
            result = runner.invoke(cli, ["compile"], catch_exceptions=False)
            assert result.exit_code == 0
            assert "mvp" in result.output

        finally:
            os.chdir(old_cwd)

    def test_phase_affects_hook_filtering(self, fresh_project):
        """Items with min_phase above current should be excluded from hooks."""
        from sidecar.v3.hooks import prompt_hook
        from sidecar.v3.knowledge import learn, set_phase

        init_project(fresh_project)
        sdir = fresh_project / ".sidecar"

        # Learn items at different phases
        learn(
            "Basic validation required",
            type="constraint",
            min_phase="prototype",
            sidecar_dir=sdir,
        )
        learn(
            "Full audit logging required",
            type="constraint",
            min_phase="production",
            sidecar_dir=sdir,
        )

        # At prototype phase, production constraint should be excluded
        set_phase("prototype", sdir)
        output = prompt_hook("add a new endpoint", sidecar_dir=sdir)
        assert "Basic validation" in output or output == ""  # May not match query
        # Production constraint should NOT appear at prototype phase
        if output:
            assert "audit logging" not in output.lower()


# ── Staleness + Lifecycle ───────────────────────────────────────────────


class TestStalenessIntegration:
    def test_stale_refresh_cycle(self, runner, fresh_project):
        old_cwd = os.getcwd()
        os.chdir(fresh_project)
        try:
            runner.invoke(cli, ["init"], catch_exceptions=False)
            sdir = fresh_project / ".sidecar"

            # Create an old item
            conn = get_db(sdir / "db.sqlite")
            old_date = (datetime.now(UTC) - timedelta(days=100)).isoformat()
            conn.execute(
                "INSERT INTO knowledge (id, type, content, source, confidence, created_at) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                ("stale01", "decision", "Use old framework", "explicit", 1.0, old_date),
            )
            conn.commit()
            conn.close()

            # Stale should find it
            result = runner.invoke(cli, ["stale"], catch_exceptions=False)
            assert "stale01" in result.output
            assert "1 stale" in result.output

            # Refresh it
            result = runner.invoke(cli, ["stale", "--refresh", "stale01"], catch_exceptions=False)
            assert "Refreshed" in result.output

            # Should no longer be stale
            result = runner.invoke(cli, ["stale"], catch_exceptions=False)
            assert "No stale items" in result.output

        finally:
            os.chdir(old_cwd)


# ── Hook Integration ────────────────────────────────────────────────────


class TestHookIntegration:
    def test_prompt_hook_returns_knowledge(self, fresh_project):
        from sidecar.v3.hooks import prompt_hook
        from sidecar.v3.knowledge import learn

        init_project(fresh_project)
        sdir = fresh_project / ".sidecar"

        learn("Never store secrets in code", type="constraint", sidecar_dir=sdir)
        learn("Use environment variables for config", type="decision", sidecar_dir=sdir)

        output = prompt_hook("how should I handle secrets", sidecar_dir=sdir)
        # Should inject relevant knowledge
        assert len(output) > 0

    def test_stop_hook_after_substantive_session(self, fresh_project):
        from sidecar.v3.hooks import _write_state, stop_hook

        init_project(fresh_project)
        sdir = fresh_project / ".sidecar"

        import time

        # Simulate a substantive session (5 prompts)
        _write_state(
            sdir,
            {
                "prompt_count": 5,
                "last_prompt_ts": time.time(),
                "files_mentioned": [],
                "knowledge_injected": [],
            },
        )

        output = stop_hook(sidecar_dir=sdir)
        assert "reflect" in output.lower()

    def test_stop_hook_short_session_no_output(self, fresh_project):
        from sidecar.v3.hooks import _write_state, stop_hook

        init_project(fresh_project)
        sdir = fresh_project / ".sidecar"

        import time

        _write_state(
            sdir,
            {
                "prompt_count": 1,
                "last_prompt_ts": time.time(),
                "files_mentioned": [],
                "knowledge_injected": [],
            },
        )

        output = stop_hook(sidecar_dir=sdir)
        assert output == ""

    def test_prompt_hook_cli_invocation(self, runner, fresh_project):
        old_cwd = os.getcwd()
        os.chdir(fresh_project)
        try:
            runner.invoke(cli, ["init"], catch_exceptions=False)
            runner.invoke(
                cli,
                ["learn", "Always use parameterized queries", "--constraint"],
                catch_exceptions=False,
            )

            result = runner.invoke(
                cli, ["hook", "prompt", "write a database query"], catch_exceptions=False
            )
            assert result.exit_code == 0

        finally:
            os.chdir(old_cwd)


# ── Export/Import Round-Trip ────────────────────────────────────────────


class TestExportImportRoundTrip:
    def test_export_import_preserves_knowledge(self, runner, fresh_project, tmp_path):
        old_cwd = os.getcwd()
        os.chdir(fresh_project)
        try:
            runner.invoke(cli, ["init"], catch_exceptions=False)
            runner.invoke(
                cli, ["learn", "Use PostgreSQL", "--type", "decision"], catch_exceptions=False
            )
            runner.invoke(
                cli,
                [
                    "learn",
                    "All queries parameterized",
                    "--constraint",
                    "--tags",
                    "database,security",
                ],
                catch_exceptions=False,
            )

            # Export
            export_file = tmp_path / "export.json"
            result = runner.invoke(cli, ["export", "-o", str(export_file)], catch_exceptions=False)
            assert result.exit_code == 0
            assert export_file.exists()

            data = json.loads(export_file.read_text())
            assert data["item_count"] == 2

            # Import into a different project
            other_project = tmp_path / "other"
            other_project.mkdir()
            os.chdir(other_project)
            runner.invoke(cli, ["init"], catch_exceptions=False)

            result = runner.invoke(
                cli, ["import-package", str(export_file)], catch_exceptions=False
            )
            assert result.exit_code == 0
            assert "Imported 2" in result.output

            # Verify knowledge is there
            result = runner.invoke(
                cli, ["recall", "database", "--json-output"], catch_exceptions=False
            )
            items = json.loads(result.output)
            contents = [i["content"] for i in items]
            assert "Use PostgreSQL" in contents

        finally:
            os.chdir(old_cwd)


# ── Compile Output File ────────────────────────────────────────────────


class TestCompileToFile:
    def test_compile_to_claude_md_file(self, runner, fresh_project):
        old_cwd = os.getcwd()
        os.chdir(fresh_project)
        try:
            runner.invoke(cli, ["init"], catch_exceptions=False)
            runner.invoke(
                cli,
                ["learn", "Use React for frontend", "--type", "decision"],
                catch_exceptions=False,
            )

            outfile = fresh_project / "CLAUDE.md"
            result = runner.invoke(cli, ["compile", "-o", str(outfile)], catch_exceptions=False)
            assert result.exit_code == 0
            assert outfile.exists()

            content = outfile.read_text()
            assert "React" in content
            assert content.endswith("\n")

        finally:
            os.chdir(old_cwd)


# ── Double Init Safety ──────────────────────────────────────────────────


class TestDoubleInit:
    def test_init_twice_is_safe(self, runner, fresh_project):
        old_cwd = os.getcwd()
        os.chdir(fresh_project)
        try:
            result1 = runner.invoke(cli, ["init"], catch_exceptions=False)
            assert result1.exit_code == 0

            # Learn something
            runner.invoke(cli, ["learn", "Important decision"], catch_exceptions=False)

            # Init again should not destroy knowledge
            result2 = runner.invoke(cli, ["init"], catch_exceptions=False)
            assert result2.exit_code == 0
            assert "already initialized" in result2.output

            # Knowledge should still be there
            result = runner.invoke(
                cli, ["recall", "decision", "--json-output"], catch_exceptions=False
            )
            items = json.loads(result.output)
            assert any("Important decision" in i["content"] for i in items)

        finally:
            os.chdir(old_cwd)
