"""Tests for sidecar v3 ecosystem curator: scan, profile, recommend."""

import os

import pytest
import yaml
from click.testing import CliRunner

from sidecar.v3.cli import cli
from sidecar.v3.ecosystem import (
    ProjectProfile,
    Recommendation,
    Tool,
    _parse_tool,
    build_profile,
    format_recommendations,
    format_scan_results,
    load_index,
    recommend,
    scan,
)
from sidecar.v3.knowledge import init_project, learn


@pytest.fixture
def tmp_project(tmp_path):
    init_project(tmp_path)
    return tmp_path


@pytest.fixture
def python_api_project(tmp_project):
    """A project that looks like a Python API."""
    sdir = tmp_project / ".sidecar"
    learn(
        "Use FastAPI for the REST API layer",
        type="decision",
        tags="api,python,fastapi",
        sidecar_dir=sdir,
    )
    learn(
        "PostgreSQL for all persistence",
        type="decision",
        tags="database,postgres",
        sidecar_dir=sdir,
    )
    learn(
        "All endpoints must validate input with Pydantic",
        type="constraint",
        tags="api,validation",
        sidecar_dir=sdir,
    )
    learn(
        "Auth tokens must rotate every 24h",
        type="constraint",
        tags="auth,security",
        sidecar_dir=sdir,
    )
    learn(
        "Migration rollback failed in production last month",
        type="lesson",
        tags="database,migration",
        sidecar_dir=sdir,
    )

    # Create some files to signal Python project
    (tmp_project / "pyproject.toml").write_text("[project]\nname = 'test'\n")
    src = tmp_project / "src"
    src.mkdir()
    (src / "main.py").write_text("# app entry point\n")

    return tmp_project


@pytest.fixture
def runner():
    return CliRunner()


# ── Tool Parsing ──────────────────────────────────────────────────────────


class TestToolParsing:
    def test_parse_tool(self):
        data = {
            "name": "test-tool",
            "category": "skill",
            "description": "A test tool",
            "domains": ["python"],
            "tags": ["testing"],
        }
        tool = _parse_tool(data)
        assert tool.name == "test-tool"
        assert tool.category == "skill"
        assert tool.domains == ["python"]

    def test_parse_tool_defaults(self):
        tool = _parse_tool({"name": "minimal"})
        assert tool.category == ""
        assert tool.domains == []
        assert tool.install_type == "file"


# ── Index Loading ────────────────────────────────────────────────────────


class TestLoadIndex:
    def test_builtin_index_loads(self):
        tools = load_index()
        assert len(tools) > 0
        assert any(t.name == "sidecar-skill" for t in tools)

    def test_custom_index_extends(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        custom = {
            "tools": [
                {
                    "name": "custom-tool",
                    "category": "skill",
                    "description": "My custom tool",
                    "domains": ["python"],
                }
            ]
        }
        (sdir / "ecosystem.yaml").write_text(yaml.dump(custom))

        tools = load_index(sdir)
        assert any(t.name == "custom-tool" for t in tools)
        # Should also include builtins
        assert any(t.name == "sidecar-skill" for t in tools)

    def test_missing_custom_index(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        tools = load_index(sdir)
        # Should still return builtins
        assert len(tools) > 0


# ── Project Profile ──────────────────────────────────────────────────────


class TestProjectProfile:
    def test_profile_from_knowledge(self, python_api_project):
        sdir = python_api_project / ".sidecar"
        profile = build_profile(sdir, python_api_project)
        assert "python" in profile.domains
        assert "api" in profile.domains
        assert "database" in profile.domains

    def test_profile_technologies(self, python_api_project):
        sdir = python_api_project / ".sidecar"
        profile = build_profile(sdir, python_api_project)
        assert "fastapi" in profile.technologies
        assert "postgres" in profile.technologies or "postgresql" in profile.technologies

    def test_profile_concerns(self, python_api_project):
        sdir = python_api_project / ".sidecar"
        profile = build_profile(sdir, python_api_project)
        assert "security" in profile.concerns
        assert "migration" in profile.concerns

    def test_profile_from_files(self, tmp_project):
        (tmp_project / "pyproject.toml").write_text("[project]\nname='x'\n")
        (tmp_project / "tsconfig.json").write_text("{}")
        profile = build_profile(project_dir=tmp_project)
        assert "python" in profile.domains
        assert "typescript" in profile.domains

    def test_empty_profile(self, tmp_path):
        profile = build_profile()
        assert len(profile.domains) == 0

    def test_profile_no_db(self, tmp_project):
        # Project init'd but no knowledge
        sdir = tmp_project / ".sidecar"
        profile = build_profile(sdir, tmp_project)
        # Should still work, just empty domains from knowledge
        assert isinstance(profile, ProjectProfile)


# ── Recommendation Engine ────────────────────────────────────────────────


class TestRecommendation:
    def test_recommend_for_python_api(self, python_api_project):
        sdir = python_api_project / ".sidecar"
        profile = build_profile(sdir, python_api_project)
        recs = recommend(profile, sidecar_dir=sdir)
        assert len(recs) > 0
        # Real tools should be recommended
        names = [r.tool.name for r in recs]
        assert any(
            name in names
            for name in [
                "sidecar-skill",
                "sidecar-hooks",
                "git-commit-capture",
                "git-impact-warnings",
            ]
        )

    def test_recommend_security_concern(self, python_api_project):
        sdir = python_api_project / ".sidecar"
        profile = build_profile(sdir, python_api_project)
        recs = recommend(profile, sidecar_dir=sdir)
        # Real tools should be recommended for this project
        names = [r.tool.name for r in recs]
        assert len(names) > 0

    def test_universal_tools_always_recommended(self):
        profile = ProjectProfile(domains={"python"})
        recs = recommend(profile)
        names = [r.tool.name for r in recs]
        assert "sidecar-skill" in names  # Universal tool

    def test_recommend_top_k(self, python_api_project):
        sdir = python_api_project / ".sidecar"
        profile = build_profile(sdir, python_api_project)
        recs = recommend(profile, sidecar_dir=sdir, top_k=3)
        assert len(recs) <= 3

    def test_recommend_sorted_by_score(self, python_api_project):
        sdir = python_api_project / ".sidecar"
        profile = build_profile(sdir, python_api_project)
        recs = recommend(profile, sidecar_dir=sdir)
        scores = [r.score for r in recs]
        assert scores == sorted(scores, reverse=True)

    def test_recommend_empty_profile(self):
        profile = ProjectProfile()
        recs = recommend(profile)
        # Universal tools still recommended
        assert any(r.tool.name == "sidecar-skill" for r in recs)


# ── Scan ──────────────────────────────────────────────────────────────────


class TestScan:
    def test_scan_returns_all_tools(self):
        tools = scan()
        assert len(tools) > 0
        categories = {t.category for t in tools}
        assert "skill" in categories
        assert "hook" in categories
        # Only real categories: skill and hook (phantom rules removed)


# ── Formatting ────────────────────────────────────────────────────────────


class TestFormatting:
    def test_format_scan_results(self):
        tools = [
            Tool(name="test-skill", category="skill", description="A skill", domains=["python"]),
            Tool(name="test-hook", category="hook", description="A hook", domains=["all"]),
        ]
        output = format_scan_results(tools)
        assert "SKILLS:" in output
        assert "HOOKS:" in output
        assert "test-skill" in output

    def test_format_empty_scan(self):
        assert "No tools" in format_scan_results([])

    def test_format_recommendations(self):
        tool = Tool(name="my-tool", category="rule", description="A great tool")
        recs = [Recommendation(tool=tool, score=0.8, reasons=["matches domains: python"])]
        output = format_recommendations(recs)
        assert "my-tool" in output
        assert "80%" in output
        assert "python" in output

    def test_format_no_recommendations(self):
        output = format_recommendations([])
        assert "No recommendations" in output


# ── CLI Tests ─────────────────────────────────────────────────────────────


class TestCLIEcosystem:
    def test_ecosystem_scan_command(self, runner, tmp_project):
        old_cwd = os.getcwd()
        os.chdir(tmp_project)
        try:
            result = runner.invoke(cli, ["ecosystem", "scan"], catch_exceptions=False)
            assert result.exit_code == 0
            assert "SKILL" in result.output or "skill" in result.output.lower()
        finally:
            os.chdir(old_cwd)

    def test_ecosystem_recommend_command(self, runner, python_api_project):
        old_cwd = os.getcwd()
        os.chdir(python_api_project)
        try:
            result = runner.invoke(cli, ["ecosystem", "recommend"], catch_exceptions=False)
            assert result.exit_code == 0
        finally:
            os.chdir(old_cwd)

    def test_ecosystem_profile_command(self, runner, python_api_project):
        old_cwd = os.getcwd()
        os.chdir(python_api_project)
        try:
            result = runner.invoke(cli, ["ecosystem", "profile"], catch_exceptions=False)
            assert result.exit_code == 0
            assert "python" in result.output.lower()
        finally:
            os.chdir(old_cwd)
