"""Edge case and unhappy path tests for sidecar v3.

Tests error handling, corrupt state, boundary conditions, and unusual inputs.
"""

import os

import pytest
import yaml
from click.testing import CliRunner

from sidecar.v3.cli import cli
from sidecar.v3.compiler import compile_knowledge
from sidecar.v3.db import DatabaseError, get_db
from sidecar.v3.hooks import prompt_hook, stop_hook
from sidecar.v3.knowledge import (
    _extract_domains,
    _extract_tags,
    detect_conflicts,
    find_sidecar_dir,
    get_stale_items,
    init_project,
    learn,
    recall,
    require_sidecar_dir,
)
from sidecar.v3.recipes import install_recipe, load_preset_index, search_recipes


@pytest.fixture
def runner():
    return CliRunner()


@pytest.fixture
def tmp_project(tmp_path):
    init_project(tmp_path)
    return tmp_path


# ── Empty Store Edge Cases ──────────────────────────────────────────────


class TestEmptyStore:
    def test_recall_empty_store(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        results = recall("anything", sidecar_dir=sdir)
        assert results == []

    def test_compile_empty_store(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        output = compile_knowledge(sidecar_dir=sdir, format="claude-md")
        assert "No knowledge items found" in output

    def test_conflicts_empty_store(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        assert detect_conflicts(sidecar_dir=sdir) == []

    def test_stale_empty_store(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        assert get_stale_items(sidecar_dir=sdir) == []

    def test_prompt_hook_empty_store(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        output = prompt_hook("anything", sidecar_dir=sdir)
        # Should not crash, may return empty or just enhancement
        assert isinstance(output, str)

    def test_stop_hook_empty_store(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        output = stop_hook(sidecar_dir=sdir)
        assert output == ""


# ── Missing .sidecar/ Directory ─────────────────────────────────────────


class TestMissingSidecar:
    def test_find_sidecar_dir_nonexistent(self, tmp_path):
        result = find_sidecar_dir(tmp_path)
        assert result is None

    def test_require_sidecar_dir_raises(self, tmp_path):
        with pytest.raises(FileNotFoundError, match="No .sidecar"):
            require_sidecar_dir(tmp_path)

    def test_learn_without_init_fails(self, runner, tmp_path):
        old_cwd = os.getcwd()
        os.chdir(tmp_path)
        try:
            result = runner.invoke(cli, ["learn", "something"], catch_exceptions=False)
            assert result.exit_code == 1
        finally:
            os.chdir(old_cwd)

    def test_recall_without_init_fails(self, runner, tmp_path):
        old_cwd = os.getcwd()
        os.chdir(tmp_path)
        try:
            result = runner.invoke(cli, ["recall", "something"], catch_exceptions=False)
            assert result.exit_code == 1
        finally:
            os.chdir(old_cwd)

    def test_compile_without_init_fails(self, runner, tmp_path):
        old_cwd = os.getcwd()
        os.chdir(tmp_path)
        try:
            result = runner.invoke(cli, ["compile"], catch_exceptions=False)
            assert result.exit_code == 1
        finally:
            os.chdir(old_cwd)

    def test_prompt_hook_no_sidecar_returns_empty(self, tmp_path):
        output = prompt_hook("anything", sidecar_dir=tmp_path / ".sidecar")
        assert output == ""


# ── Special Characters in Content ───────────────────────────────────────


class TestSpecialCharacters:
    def test_learn_with_quotes(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        item = learn('Use "double quotes" for JSON strings', type="decision", sidecar_dir=sdir)
        assert '"double quotes"' in item.content

    def test_learn_with_unicode(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        item = learn("Use → arrows and • bullets in docs", type="decision", sidecar_dir=sdir)
        assert "→" in item.content

    def test_learn_with_newlines(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        item = learn("First line\nSecond line\nThird line", type="decision", sidecar_dir=sdir)
        assert "\n" in item.content

    def test_learn_with_sql_injection_attempt(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        item = learn(
            "Robert'); DROP TABLE knowledge;--",
            type="lesson",
            sidecar_dir=sdir,
        )
        assert "DROP TABLE" in item.content
        # DB should still work
        results = recall("Robert", sidecar_dir=sdir)
        assert len(results) > 0

    def test_learn_very_long_content(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        long_content = "A" * 10000
        item = learn(long_content, type="decision", sidecar_dir=sdir)
        assert len(item.content) == 10000

    def test_learn_empty_content_rejected(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        with pytest.raises(ValueError, match="too short"):
            learn(" ", type="decision", sidecar_dir=sdir)

    def test_learn_short_content_rejected(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        with pytest.raises(ValueError, match="too short"):
            learn("ab", type="decision", sidecar_dir=sdir)


# ── Duplicate Handling ──────────────────────────────────────────────────


class TestDuplicates:
    def test_learn_exact_duplicate_returns_existing(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        item1 = learn("Use React for frontend", type="decision", sidecar_dir=sdir)
        item2 = learn("Use React for frontend", type="decision", sidecar_dir=sdir)
        assert item1.id == item2.id

    def test_learn_same_content_different_type_is_not_duplicate(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        item1 = learn("Use React for frontend", type="decision", sidecar_dir=sdir)
        item2 = learn("Use React for frontend", type="constraint", sidecar_dir=sdir)
        assert item1.id != item2.id

    def test_recipe_install_deduplicates(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        # Pre-learn an item that's in the recipe
        learn(
            "Use Pydantic models for all request/response schemas",
            type="constraint",
            sidecar_dir=sdir,
        )
        # Install recipe that contains same item
        index = load_preset_index()
        fastapi = next(r for r in index if r.name == "fastapi")
        created = install_recipe(fastapi, sidecar_dir=sdir)
        # Should be fewer than total recipe items (one was deduped)
        assert created < len(fastapi.items)


# ── Corrupt State ───────────────────────────────────────────────────────


class TestCorruptState:
    def test_corrupt_hook_state_resets(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        # Write invalid JSON to hook state
        (sdir / ".hook-state").write_text("{invalid json!!!")
        # Hook should recover gracefully
        output = prompt_hook("test prompt", sidecar_dir=sdir)
        assert isinstance(output, str)

    def test_corrupt_config_yaml(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        (sdir / "config.yaml").write_text("{{invalid yaml")
        # Phase read should fallback to default
        from sidecar.v3.knowledge import get_phase

        # Should not crash — may raise or return default
        try:
            phase = get_phase(sdir)
            assert phase == "prototype"  # fallback
        except (yaml.YAMLError, Exception):
            pass  # Also acceptable

    def test_missing_db_file(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        db_path = sdir / "db.sqlite"
        db_path.unlink()
        # get_db should recreate it
        conn = get_db(db_path)
        assert conn is not None
        conn.close()

    def test_corrupt_db_detected(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        db_path = sdir / "db.sqlite"
        # Write garbage to the db file
        db_path.write_bytes(b"this is not a database")
        with pytest.raises(DatabaseError):
            get_db(db_path)


# ── Domain/Tag Extraction Edge Cases ────────────────────────────────────


class TestExtractionEdgeCases:
    def test_extract_domains_empty_string(self):
        assert _extract_domains("") == ""

    def test_extract_domains_no_match(self):
        assert _extract_domains("The sky is blue") == ""

    def test_extract_domains_multiple(self):
        result = _extract_domains("Use React for frontend and FastAPI for backend API")
        domains = set(result.split(","))
        assert "frontend" in domains
        assert "backend" in domains

    def test_extract_tags_empty(self):
        assert _extract_tags("") == ""

    def test_extract_tags_no_match(self):
        assert _extract_tags("The sky is blue") == ""


# ── Invalid Type ────────────────────────────────────────────────────────


class TestInvalidInputs:
    def test_learn_invalid_type(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        with pytest.raises(ValueError, match="Invalid type"):
            learn("content", type="invalid_type", sidecar_dir=sdir)

    def test_set_invalid_phase(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        from sidecar.v3.knowledge import set_phase

        with pytest.raises(ValueError, match="Invalid phase"):
            set_phase("invalid_phase", sdir)


# ── Recipe Edge Cases ──────────────────────────────────────────────────


class TestRecipeEdgeCases:
    def test_search_empty_query(self):
        # Empty string matches everything
        results = search_recipes("")
        assert len(results) >= 3

    def test_install_empty_recipe(self, tmp_project):
        from sidecar.v3.recipes import Recipe

        sdir = tmp_project / ".sidecar"
        empty = Recipe(name="empty", items=[])
        created = install_recipe(empty, sidecar_dir=sdir)
        assert created == 0

    def test_install_recipe_with_empty_content_items(self, tmp_project):
        from sidecar.v3.recipes import Recipe

        sdir = tmp_project / ".sidecar"
        recipe = Recipe(
            name="bad",
            items=[
                {"content": ""},
                {"content": "  "},
                {"content": "This is a valid recipe item"},
            ],
        )
        created = install_recipe(recipe, sidecar_dir=sdir)
        # Only the valid item should be created (empty/short content rejected by learn)
        assert created == 1


# ── Audit Edge Cases ───────────────────────────────────────────────────


class TestAuditEdgeCases:
    def test_audit_empty_project(self, tmp_path):
        from sidecar.v3.audit import run_audit

        findings = run_audit(tmp_path, "production", "prototype")
        # Should find issues (no readme, no tests, no config) but not crash
        assert isinstance(findings, list)

    def test_audit_downgrade_returns_nothing(self, tmp_path):
        from sidecar.v3.audit import run_audit

        findings = run_audit(tmp_path, "prototype", "production")
        assert findings == []

    def test_audit_same_phase_returns_nothing(self, tmp_path):
        from sidecar.v3.audit import run_audit

        findings = run_audit(tmp_path, "mvp", "mvp")
        assert findings == []

    def test_audit_unreadable_file(self, tmp_path):
        from sidecar.v3.audit import run_audit

        # Create a binary file with .py extension
        (tmp_path / "binary.py").write_bytes(b"\x00\x01\x02\xff\xfe")
        findings = run_audit(tmp_path, "production", "prototype")
        # Should not crash
        assert isinstance(findings, list)


# ── Compiler Edge Cases ─────────────────────────────────────────────────


class TestCompilerEdgeCases:
    def test_compile_nonexistent_domain_filter(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        learn("Some decision", type="decision", domain="backend", sidecar_dir=sdir)
        output = compile_knowledge(sidecar_dir=sdir, domain_filter="nonexistent")
        assert "No knowledge items found" in output

    def test_compile_all_formats_empty(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        for fmt in ("claude-md", "skill", "primer"):
            output = compile_knowledge(sidecar_dir=sdir, format=fmt)
            assert isinstance(output, str)
            assert len(output) > 0


# ── Conflict Detection Edge Cases ───────────────────────────────────────


class TestConflictEdgeCases:
    def test_single_item_no_conflicts(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        learn("Only one item", type="decision", sidecar_dir=sdir)
        assert detect_conflicts(sidecar_dir=sdir) == []

    def test_very_short_items_no_false_conflicts(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        learn("Use A", type="decision", sidecar_dir=sdir)
        learn("Use B", type="decision", sidecar_dir=sdir)
        # Too short to have meaningful keyword overlap
        conflicts = detect_conflicts(sidecar_dir=sdir)
        assert len(conflicts) == 0
