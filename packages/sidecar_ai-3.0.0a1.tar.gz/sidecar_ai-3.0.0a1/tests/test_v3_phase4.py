"""Tests for sidecar v3 Phase 4: cross-project, export/import, supersession."""

import json
import os

import pytest
from click.testing import CliRunner

from sidecar.v3.cli import cli
from sidecar.v3.cross_project import (
    export_knowledge,
    import_knowledge_package,
    recall_from_project,
    supersede_knowledge,
)
from sidecar.v3.knowledge import init_project, learn, recall


@pytest.fixture
def project_a(tmp_path):
    """First project with knowledge."""
    p = tmp_path / "project_a"
    p.mkdir()
    init_project(p, project_name="project-a")
    sdir = p / ".sidecar"
    learn("Use Redis for caching", tags="cache,redis", sidecar_dir=sdir)
    learn("JWT for API authentication", tags="auth,jwt", sidecar_dir=sdir)
    learn("All APIs must return pagination", type="constraint", tags="api", sidecar_dir=sdir)
    return p


@pytest.fixture
def project_b(tmp_path):
    """Second project (empty) for cross-project testing."""
    p = tmp_path / "project_b"
    p.mkdir()
    init_project(p, project_name="project-b")
    return p


@pytest.fixture
def runner():
    return CliRunner()


# ── Cross-Project Recall Tests ────────────────────────────────────────────


class TestCrossProjectRecall:
    def test_recall_from_other_project(self, project_a, project_b):
        results = recall_from_project("caching", project_a)
        assert len(results) > 0
        contents = [item.content for item, _ in results]
        assert any("Redis" in c or "caching" in c.lower() for c in contents)

    def test_recall_type_filter(self, project_a):
        results = recall_from_project("API", project_a, type_filter="constraint")
        for item, _ in results:
            assert item.type == "constraint"

    def test_recall_nonexistent_project(self, tmp_path):
        results = recall_from_project("anything", tmp_path / "nonexistent")
        assert results == []


# ── Export Tests ──────────────────────────────────────────────────────────


class TestExport:
    def test_export_all(self, project_a):
        sdir = project_a / ".sidecar"
        package = export_knowledge(sdir)
        assert package["sidecar_version"] == 3
        assert package["item_count"] == 3
        assert len(package["knowledge"]) == 3
        assert package["source_project"] == "project_a"

    def test_export_filtered_by_tags(self, project_a):
        sdir = project_a / ".sidecar"
        package = export_knowledge(sdir, tags="auth")
        assert package["item_count"] >= 1
        for item in package["knowledge"]:
            assert "auth" in (item.get("tags") or "")

    def test_export_filtered_by_type(self, project_a):
        sdir = project_a / ".sidecar"
        package = export_knowledge(sdir, type_filter="constraint")
        for item in package["knowledge"]:
            assert item["type"] == "constraint"

    def test_export_no_embeddings(self, project_a):
        sdir = project_a / ".sidecar"
        package = export_knowledge(sdir)
        for item in package["knowledge"]:
            assert "embedding" not in item


# ── Import Package Tests ─────────────────────────────────────────────────


class TestImportPackage:
    def test_import_package(self, project_a, project_b):
        sdir_a = project_a / ".sidecar"
        sdir_b = project_b / ".sidecar"

        # Export from A, import to B
        package = export_knowledge(sdir_a)
        items = import_knowledge_package(sdir_b, package)
        assert len(items) == 3

        # Verify imported items are queryable in B
        results = recall("caching", sidecar_dir=sdir_b)
        assert len(results) > 0

    def test_import_preserves_source(self, project_a, project_b):
        sdir_a = project_a / ".sidecar"
        sdir_b = project_b / ".sidecar"

        package = export_knowledge(sdir_a)
        items = import_knowledge_package(sdir_b, package)
        for item in items:
            assert item.source == "import:project_a"

    def test_import_empty_package(self, project_b):
        sdir = project_b / ".sidecar"
        items = import_knowledge_package(sdir, {"knowledge": []})
        assert items == []


# ── Supersession Tests ────────────────────────────────────────────────────


class TestSupersession:
    def test_supersede_item(self, project_a):
        sdir = project_a / ".sidecar"

        # Get an item to supersede
        results = recall("Redis", sidecar_dir=sdir)
        assert len(results) > 0
        old_id = results[0][0].id

        new_item = supersede_knowledge(sdir, old_id, "Use Valkey instead of Redis (fork)")
        assert new_item is not None
        assert "Valkey" in new_item.content

        # Old item should not appear in recall
        results_after = recall("Redis", sidecar_dir=sdir)
        old_ids = [item.id for item, _ in results_after]
        assert old_id not in old_ids

        # New item should appear
        results_new = recall("Valkey", sidecar_dir=sdir)
        assert any(item.id == new_item.id for item, _ in results_new)

    def test_supersede_nonexistent(self, project_a):
        sdir = project_a / ".sidecar"
        result = supersede_knowledge(sdir, "nonexistent123", "New content")
        assert result is None


# ── CLI Tests ─────────────────────────────────────────────────────────────


class TestCLIPhase4:
    def test_recall_cross_project(self, runner, project_a, project_b):
        old_cwd = os.getcwd()
        os.chdir(project_b)
        try:
            result = runner.invoke(
                cli,
                ["recall", "caching", "--project", str(project_a)],
                catch_exceptions=False,
            )
            assert result.exit_code == 0
        finally:
            os.chdir(old_cwd)

    def test_export_command(self, runner, project_a):
        old_cwd = os.getcwd()
        os.chdir(project_a)
        try:
            result = runner.invoke(cli, ["export"], catch_exceptions=False)
            assert result.exit_code == 0
            package = json.loads(result.output)
            assert package["item_count"] == 3
        finally:
            os.chdir(old_cwd)

    def test_export_to_file(self, runner, project_a, tmp_path):
        out_file = tmp_path / "export.json"
        old_cwd = os.getcwd()
        os.chdir(project_a)
        try:
            result = runner.invoke(cli, ["export", "-o", str(out_file)], catch_exceptions=False)
            assert result.exit_code == 0
            assert out_file.exists()
            package = json.loads(out_file.read_text())
            assert package["item_count"] == 3
        finally:
            os.chdir(old_cwd)

    def test_import_package_command(self, runner, project_a, project_b, tmp_path):
        # Export from A
        old_cwd = os.getcwd()
        os.chdir(project_a)
        try:
            pkg_file = tmp_path / "pkg.json"
            runner.invoke(cli, ["export", "-o", str(pkg_file)], catch_exceptions=False)
        finally:
            os.chdir(old_cwd)

        # Import to B
        os.chdir(project_b)
        try:
            result = runner.invoke(cli, ["import-package", str(pkg_file)], catch_exceptions=False)
            assert result.exit_code == 0
            assert "Imported 3 items" in result.output
        finally:
            os.chdir(old_cwd)

    def test_supersede_command(self, runner, project_a):
        old_cwd = os.getcwd()
        os.chdir(project_a)
        try:
            # Get an item ID
            result = runner.invoke(
                cli, ["recall", "Redis", "--json-output"], catch_exceptions=False
            )
            items = json.loads(result.output)
            assert len(items) > 0
            old_id = items[0]["id"]

            # Supersede it
            result = runner.invoke(
                cli,
                ["supersede", old_id, "Switched to Valkey (Redis fork)"],
                catch_exceptions=False,
            )
            assert result.exit_code == 0
            assert "Superseded" in result.output
        finally:
            os.chdir(old_cwd)

    def test_full_cross_project_workflow(self, runner, project_a, project_b, tmp_path):
        """End-to-end: export from A, import to B, recall in B."""
        old_cwd = os.getcwd()

        # Export
        os.chdir(project_a)
        pkg_file = tmp_path / "shared.json"
        runner.invoke(
            cli, ["export", "--tags", "auth", "-o", str(pkg_file)], catch_exceptions=False
        )

        # Import
        os.chdir(project_b)
        runner.invoke(cli, ["import-package", str(pkg_file)], catch_exceptions=False)

        # Recall
        result = runner.invoke(cli, ["recall", "authentication"], catch_exceptions=False)
        assert result.exit_code == 0

        os.chdir(old_cwd)
