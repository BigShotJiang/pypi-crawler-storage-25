"""Tests for mode system and feedback/dogfood features."""

import json

import pytest
from click.testing import CliRunner

from sidecar.v3.cli import cli
from sidecar.v3.hooks import prompt_hook, stop_hook
from sidecar.v3.knowledge import (
    append_feedback,
    get_dogfood,
    get_mode,
    init_project,
    learn,
    set_dogfood,
    set_mode,
)


@pytest.fixture
def runner():
    return CliRunner()


@pytest.fixture
def tmp_project(tmp_path):
    init_project(tmp_path)
    return tmp_path


# ── Mode System ──────────────────────────────────────────────────────────


class TestModeSystem:
    def test_default_mode_is_active(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        assert get_mode(sdir) == "active"

    def test_set_mode_observe(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        set_mode("observe", sdir)
        assert get_mode(sdir) == "observe"

    def test_set_mode_disabled(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        set_mode("disabled", sdir)
        assert get_mode(sdir) == "disabled"

    def test_set_mode_active(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        set_mode("disabled", sdir)
        set_mode("active", sdir)
        assert get_mode(sdir) == "active"

    def test_set_invalid_mode_raises(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        with pytest.raises(ValueError, match="Invalid mode"):
            set_mode("turbo", sdir)

    def test_mode_cli_show(self, runner, tmp_project):
        import os

        old_cwd = os.getcwd()
        os.chdir(tmp_project)
        try:
            result = runner.invoke(cli, ["mode"], catch_exceptions=False)
            assert result.exit_code == 0
            assert "active" in result.output
        finally:
            os.chdir(old_cwd)

    def test_mode_cli_set(self, runner, tmp_project):
        import os

        old_cwd = os.getcwd()
        os.chdir(tmp_project)
        try:
            result = runner.invoke(cli, ["mode", "observe"], catch_exceptions=False)
            assert result.exit_code == 0
            assert "observe" in result.output
            sdir = tmp_project / ".sidecar"
            assert get_mode(sdir) == "observe"
        finally:
            os.chdir(old_cwd)


# ── Mode affects hooks ───────────────────────────────────────────────────


class TestModeHooks:
    def test_disabled_mode_prompt_hook_returns_empty(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        learn("Use React for frontend", type="decision", sidecar_dir=sdir)
        set_mode("disabled", sdir)
        output = prompt_hook("frontend", sidecar_dir=sdir)
        assert output == ""

    def test_observe_mode_prompt_hook_returns_empty(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        learn("Use React for frontend", type="decision", sidecar_dir=sdir)
        set_mode("observe", sdir)
        output = prompt_hook("frontend", sidecar_dir=sdir)
        assert output == ""

    def test_observe_mode_still_tracks_state(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        learn("Use React for frontend", type="decision", sidecar_dir=sdir)
        set_mode("observe", sdir)
        prompt_hook("frontend", sidecar_dir=sdir)
        prompt_hook("backend", sidecar_dir=sdir)
        # State file should exist and show 2 prompts
        state_path = sdir / ".hook-state"
        assert state_path.exists()
        import json

        state = json.loads(state_path.read_text())
        assert state["prompt_count"] == 2

    def test_active_mode_prompt_hook_returns_content(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        learn("Use React for frontend", type="decision", sidecar_dir=sdir)
        set_mode("active", sdir)
        output = prompt_hook("frontend React", sidecar_dir=sdir)
        assert len(output) > 0

    def test_disabled_mode_stop_hook_returns_empty(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        set_mode("disabled", sdir)
        # Simulate substantive session
        for _ in range(5):
            prompt_hook("test", sidecar_dir=sdir)
        # stop_hook should be bypassed because mode was disabled
        # but prompt_hook didn't track state, so stop_hook sees 0 prompts
        output = stop_hook(sidecar_dir=sdir)
        assert output == ""


# ── Dogfood System ───────────────────────────────────────────────────────


class TestDogfood:
    def test_default_dogfood_off(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        assert get_dogfood(sdir) is False

    def test_set_dogfood_on(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        set_dogfood(True, sdir)
        assert get_dogfood(sdir) is True

    def test_set_dogfood_off(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        set_dogfood(True, sdir)
        set_dogfood(False, sdir)
        assert get_dogfood(sdir) is False

    def test_sessions_cli_empty(self, runner, tmp_project):
        import os

        old_cwd = os.getcwd()
        os.chdir(tmp_project)
        try:
            result = runner.invoke(cli, ["sessions"], catch_exceptions=False)
            assert result.exit_code == 0
            assert "No session data" in result.output
        finally:
            os.chdir(old_cwd)

    def test_stop_hook_logs_session_metrics(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        learn("Use React for frontend", type="decision", sidecar_dir=sdir)
        # Simulate substantive session
        for i in range(5):
            prompt_hook(f"test prompt {i}", sidecar_dir=sdir)
        stop_hook(sidecar_dir=sdir)
        log_path = sdir / "sessions-log.jsonl"
        assert log_path.exists()
        import json

        entry = json.loads(log_path.read_text().strip().splitlines()[-1])
        assert entry["prompt_count"] == 5
        assert "items_injected" in entry
        assert "relevance_score" in entry

    def test_prompt_hook_tracks_injected_keywords(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        learn("Use React for frontend components", type="decision", sidecar_dir=sdir)
        prompt_hook("frontend React", sidecar_dir=sdir)
        import json

        state = json.loads((sdir / ".hook-state").read_text())
        assert "injected_keywords" in state
        assert len(state["injected_keywords"]) > 0

    def test_stop_hook_no_dogfood_prompt(self, tmp_project):
        """Stop hook should not contain dogfood/feedback prompts."""
        sdir = tmp_project / ".sidecar"
        set_dogfood(True, sdir)
        for i in range(5):
            prompt_hook(f"test prompt {i}", sidecar_dir=sdir)
        output = stop_hook(sidecar_dir=sdir)
        assert "Dogfood" not in output
        assert "sidecar feedback" not in output


# ── Feedback System ──────────────────────────────────────────────────────


class TestFeedback:
    def test_append_feedback(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        path = append_feedback("recall was noisy", sidecar_dir=sdir)
        assert path.exists()
        content = path.read_text()
        assert "recall was noisy" in content
        assert "[observation]" in content

    def test_append_feedback_with_type(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        append_feedback("hook timeout", feedback_type="bug", sidecar_dir=sdir)
        content = (sdir / "feedback.md").read_text()
        assert "[bug]" in content

    def test_append_multiple_feedback(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        append_feedback("first issue", sidecar_dir=sdir)
        append_feedback("second issue", feedback_type="enhancement", sidecar_dir=sdir)
        content = (sdir / "feedback.md").read_text()
        assert "first issue" in content
        assert "second issue" in content
        assert content.count("##") == 2

    def test_feedback_cli(self, runner, tmp_project):
        import os

        old_cwd = os.getcwd()
        os.chdir(tmp_project)
        try:
            result = runner.invoke(cli, ["feedback", "recall was noisy"], catch_exceptions=False)
            assert result.exit_code == 0
            assert "Feedback logged" in result.output
        finally:
            os.chdir(old_cwd)

    def test_feedback_cli_with_type(self, runner, tmp_project):
        import os

        old_cwd = os.getcwd()
        os.chdir(tmp_project)
        try:
            result = runner.invoke(
                cli, ["feedback", "--type", "bug", "hook crash"], catch_exceptions=False
            )
            assert result.exit_code == 0
        finally:
            os.chdir(old_cwd)

    def test_feedback_list_empty(self, runner, tmp_project):
        import os

        old_cwd = os.getcwd()
        os.chdir(tmp_project)
        try:
            result = runner.invoke(cli, ["feedback-list"], catch_exceptions=False)
            assert result.exit_code == 0
            assert "No feedback" in result.output
        finally:
            os.chdir(old_cwd)

    def test_feedback_list_with_entries(self, runner, tmp_project):
        import os

        old_cwd = os.getcwd()
        os.chdir(tmp_project)
        try:
            runner.invoke(cli, ["feedback", "first"], catch_exceptions=False)
            runner.invoke(cli, ["feedback", "second"], catch_exceptions=False)
            result = runner.invoke(cli, ["feedback-list"], catch_exceptions=False)
            assert result.exit_code == 0
            assert "first" in result.output
            assert "second" in result.output
        finally:
            os.chdir(old_cwd)

    def test_feedback_export_json(self, runner, tmp_project):
        import os

        old_cwd = os.getcwd()
        os.chdir(tmp_project)
        try:
            runner.invoke(cli, ["feedback", "issue one"], catch_exceptions=False)
            runner.invoke(cli, ["feedback", "--type", "bug", "issue two"], catch_exceptions=False)
            result = runner.invoke(cli, ["feedback-export"], catch_exceptions=False)
            assert result.exit_code == 0
            entries = json.loads(result.output)
            assert len(entries) == 2
            assert entries[0]["content"] == "issue one"
            assert entries[1]["type"] == "bug"
        finally:
            os.chdir(old_cwd)

    def test_feedback_export_to_file(self, runner, tmp_project):
        import os

        old_cwd = os.getcwd()
        os.chdir(tmp_project)
        try:
            runner.invoke(cli, ["feedback", "test entry"], catch_exceptions=False)
            out_path = tmp_project / "feedback.json"
            result = runner.invoke(
                cli, ["feedback-export", "-o", str(out_path)], catch_exceptions=False
            )
            assert result.exit_code == 0
            assert out_path.exists()
            entries = json.loads(out_path.read_text())
            assert len(entries) == 1
        finally:
            os.chdir(old_cwd)

    def test_feedback_export_empty(self, runner, tmp_project):
        import os

        old_cwd = os.getcwd()
        os.chdir(tmp_project)
        try:
            result = runner.invoke(cli, ["feedback-export"], catch_exceptions=False)
            assert result.exit_code == 0
            assert "No feedback" in result.output
        finally:
            os.chdir(old_cwd)
