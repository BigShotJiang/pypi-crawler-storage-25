"""Tests for sidecar v3 Tier 1: semantic filtering, phase system, onboarding, enhanced status."""

import json

import pytest
from click.testing import CliRunner

from sidecar.v3.cli import cli
from sidecar.v3.db import KnowledgeItem, get_db, insert_knowledge
from sidecar.v3.hooks import (
    _detect_prompt_domains,
    _filter_by_domain,
    _filter_by_phase,
    _get_coding_standards,
)
from sidecar.v3.knowledge import (
    PHASES,
    _extract_domains,
    backfill_domains,
    get_detailed_stats,
    get_phase,
    init_project,
    learn,
    set_phase,
)
from sidecar.v3.onboarding import OnboardingFinding, apply_findings, scan_project

# ── Fixtures ──────────────────────────────────────────────────────────────


@pytest.fixture
def tmp_project(tmp_path):
    """Create a temporary project with sidecar initialized."""
    init_project(tmp_path)
    return tmp_path


@pytest.fixture
def sidecar_dir(tmp_project):
    return tmp_project / ".sidecar"


@pytest.fixture
def db_conn(sidecar_dir):
    conn = get_db(sidecar_dir / "db.sqlite")
    yield conn
    conn.close()


@pytest.fixture
def runner():
    return CliRunner()


# ── DB Migration v3 ─────────────────────────────────────────────────────


class TestMigrationV3:
    def test_schema_version_is_3(self, db_conn):
        version = db_conn.execute("PRAGMA user_version").fetchone()[0]
        assert version == 3

    def test_domain_column_exists(self, db_conn):
        rows = db_conn.execute("PRAGMA table_info(knowledge)").fetchall()
        columns = [r[1] for r in rows]
        assert "domain" in columns
        assert "min_phase" in columns

    def test_insert_with_domain(self, db_conn):
        item = KnowledgeItem(id="d1", type="constraint", content="Use React", domain="frontend")
        insert_knowledge(db_conn, item)
        row = db_conn.execute("SELECT domain FROM knowledge WHERE id = 'd1'").fetchone()
        assert row[0] == "frontend"

    def test_insert_with_min_phase(self, db_conn):
        item = KnowledgeItem(
            id="p1", type="constraint", content="Run load tests", min_phase="production"
        )
        insert_knowledge(db_conn, item)
        row = db_conn.execute("SELECT min_phase FROM knowledge WHERE id = 'p1'").fetchone()
        assert row[0] == "production"


# ── Domain Detection (B9) ───────────────────────────────────────────────


class TestDomainDetection:
    def test_extract_frontend(self):
        assert "frontend" in _extract_domains("Use React components for all UI")

    def test_extract_backend(self):
        assert "backend" in _extract_domains("FastAPI endpoint for user management")

    def test_extract_database(self):
        assert "database" in _extract_domains("PostgreSQL migration for user table")

    def test_extract_security(self):
        assert "security" in _extract_domains("JWT authentication tokens must expire")

    def test_extract_testing(self):
        assert "testing" in _extract_domains("Run pytest with coverage enabled")

    def test_extract_devops(self):
        assert "devops" in _extract_domains("Deploy using Docker and Kubernetes")

    def test_extract_multiple(self):
        domains = _extract_domains("API endpoint queries PostgreSQL database")
        assert "backend" in domains
        assert "database" in domains

    def test_extract_empty(self):
        assert _extract_domains("just a random thought about life") == ""

    def test_learn_auto_detects_domain(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        item = learn("Always use React hooks", type="constraint", sidecar_dir=sdir)
        assert item.domain is not None
        assert "frontend" in item.domain

    def test_learn_explicit_domain(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        item = learn("No hardcoded values", type="constraint", domain="backend", sidecar_dir=sdir)
        assert item.domain == "backend"


class TestPromptDomainDetection:
    def test_detect_frontend_prompt(self):
        domains = _detect_prompt_domains("fix the React component rendering bug")
        assert "frontend" in domains

    def test_detect_database_prompt(self):
        domains = _detect_prompt_domains("fix the database migration")
        assert "database" in domains

    def test_detect_nothing(self):
        domains = _detect_prompt_domains("what time is it")
        assert len(domains) == 0


class TestDomainFiltering:
    def test_filter_keeps_matching(self):
        items = [
            KnowledgeItem(id="1", type="constraint", content="a", domain="frontend"),
            KnowledgeItem(id="2", type="constraint", content="b", domain="backend"),
        ]
        filtered = _filter_by_domain(items, {"frontend"})
        assert len(filtered) == 1
        assert filtered[0].id == "1"

    def test_filter_keeps_untagged(self):
        items = [
            KnowledgeItem(id="1", type="constraint", content="a", domain="frontend"),
            KnowledgeItem(id="2", type="constraint", content="b"),  # no domain
        ]
        filtered = _filter_by_domain(items, {"backend"})
        assert len(filtered) == 1
        assert filtered[0].id == "2"  # untagged passes through

    def test_filter_no_active_domains_returns_all(self):
        items = [
            KnowledgeItem(id="1", type="constraint", content="a", domain="frontend"),
            KnowledgeItem(id="2", type="constraint", content="b", domain="backend"),
        ]
        filtered = _filter_by_domain(items, set())
        assert len(filtered) == 2

    def test_coding_standards_filtered_by_domain(self):
        items = [
            KnowledgeItem(id="1", type="constraint", content="Use React hooks", domain="frontend"),
            KnowledgeItem(id="2", type="constraint", content="Use PostgreSQL", domain="database"),
            KnowledgeItem(id="3", type="constraint", content="Always lint", domain=None),
        ]
        standards = _get_coding_standards(items, {"database"})
        assert "Use PostgreSQL" in standards
        assert "Always lint" in standards
        assert "Use React hooks" not in standards


class TestBackfillDomains:
    def test_backfill(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        # Create item without domain
        conn = get_db(sdir / "db.sqlite")
        item = KnowledgeItem(id="bf1", type="constraint", content="Always run pytest before commit")
        insert_knowledge(conn, item)
        conn.close()

        updated = backfill_domains(sdir)
        assert updated == 1

        # Verify domain was set
        conn = get_db(sdir / "db.sqlite")
        row = conn.execute("SELECT domain FROM knowledge WHERE id = 'bf1'").fetchone()
        conn.close()
        assert row[0] is not None
        assert "testing" in row[0]


# ── Phase System (B18a) ─────────────────────────────────────────────────


class TestPhase:
    def test_default_phase(self, tmp_project):
        assert get_phase(tmp_project / ".sidecar") == "prototype"

    def test_set_and_get_phase(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        set_phase("production", sdir)
        assert get_phase(sdir) == "production"

    def test_invalid_phase(self, tmp_project):
        with pytest.raises(ValueError, match="Invalid phase"):
            set_phase("invalid", tmp_project / ".sidecar")

    def test_all_phases_valid(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        for phase in PHASES:
            set_phase(phase, sdir)
            assert get_phase(sdir) == phase


class TestPhaseFiltering:
    def test_prototype_excludes_production(self):
        items = [
            KnowledgeItem(id="1", type="constraint", content="a"),  # no min_phase
            KnowledgeItem(id="2", type="constraint", content="b", min_phase="production"),
        ]
        filtered = _filter_by_phase(items, "prototype")
        assert len(filtered) == 1
        assert filtered[0].id == "1"

    def test_production_includes_mvp(self):
        items = [
            KnowledgeItem(id="1", type="constraint", content="a", min_phase="mvp"),
            KnowledgeItem(id="2", type="constraint", content="b", min_phase="production"),
        ]
        filtered = _filter_by_phase(items, "production")
        assert len(filtered) == 2

    def test_no_min_phase_always_passes(self):
        items = [
            KnowledgeItem(id="1", type="constraint", content="a"),
        ]
        filtered = _filter_by_phase(items, "prototype")
        assert len(filtered) == 1

    def test_scale_includes_all(self):
        items = [
            KnowledgeItem(id="1", type="constraint", content="a", min_phase="prototype"),
            KnowledgeItem(id="2", type="constraint", content="b", min_phase="mvp"),
            KnowledgeItem(id="3", type="constraint", content="c", min_phase="production"),
            KnowledgeItem(id="4", type="constraint", content="d", min_phase="scale"),
        ]
        filtered = _filter_by_phase(items, "scale")
        assert len(filtered) == 4


class TestDepthCLI:
    def test_depth_show(self, runner, tmp_project):
        result = runner.invoke(cli, ["depth"], catch_exceptions=False)
        assert result.exit_code == 0
        assert "prototype" in result.output

    def test_depth_set(self, runner, tmp_project):
        result = runner.invoke(cli, ["depth", "production"], catch_exceptions=False)
        assert result.exit_code == 0
        assert "production" in result.output

    def test_depth_set_then_show(self, runner, tmp_project):
        runner.invoke(cli, ["depth", "mvp"], catch_exceptions=False)
        result = runner.invoke(cli, ["depth"], catch_exceptions=False)
        assert "mvp" in result.output


# ── Onboarding (B1) ─────────────────────────────────────────────────────


class TestOnboardingScan:
    def test_scan_finds_readme(self, tmp_path):
        (tmp_path / "README.md").write_text(
            "# My Project\n\n## Architecture\n\nUses FastAPI with PostgreSQL.\n"
        )
        findings = scan_project(tmp_path)
        assert any(f.category == "importable_file" for f in findings)

    def test_scan_finds_pyproject(self, tmp_path):
        (tmp_path / "pyproject.toml").write_text(
            '[tool.ruff]\nline-length = 100\n\n[project]\nrequires-python = ">=3.11"\n'
        )
        findings = scan_project(tmp_path)
        assert any(f.category == "config_constraint" for f in findings)

    def test_scan_finds_package_json(self, tmp_path):
        pkg = {"name": "test", "scripts": {"test": "jest", "lint": "eslint ."}}
        (tmp_path / "package.json").write_text(json.dumps(pkg))
        findings = scan_project(tmp_path)
        assert any(f.source == "package.json" for f in findings)

    def test_scan_finds_dockerfile(self, tmp_path):
        (tmp_path / "Dockerfile").write_text("FROM python:3.11-slim\nEXPOSE 8000\n")
        findings = scan_project(tmp_path)
        assert any(f.source == "Dockerfile" for f in findings)

    def test_scan_finds_tech_stack(self, tmp_path):
        (tmp_path / "pyproject.toml").write_text("[project]\nname='test'\n")
        (tmp_path / "Dockerfile").write_text("FROM python:3.11\n")
        findings = scan_project(tmp_path)
        assert any(f.category == "tech_stack" for f in findings)

    def test_scan_empty_project(self, tmp_path):
        findings = scan_project(tmp_path)
        assert findings == []

    def test_scan_finds_claude_md(self, tmp_path):
        (tmp_path / "CLAUDE.md").write_text(
            "# Rules\n\n- Always use type hints\n- Never use print() in production\n"
        )
        findings = scan_project(tmp_path)
        assert any(f.source == "CLAUDE.md" for f in findings)


class TestOnboardingApply:
    def test_apply_findings(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        findings = [
            OnboardingFinding(
                source="test",
                category="config_constraint",
                items=[
                    {"content": "Line length: 100", "type": "constraint", "tags": "lint"},
                    {"content": "Python >= 3.11", "type": "constraint", "tags": "python"},
                ],
                description="test finding",
            )
        ]
        created = apply_findings(findings, sdir)
        assert created == 2


class TestOnboardCLI:
    def test_onboard_dry_run(self, runner, tmp_project):
        (tmp_project / "README.md").write_text("# Test\n\n## Architecture\n\nUses Python.\n")
        result = runner.invoke(cli, ["onboard", "--dry-run"], catch_exceptions=False)
        assert result.exit_code == 0
        assert "Dry run" in result.output

    def test_onboard_yes(self, runner, tmp_project):
        (tmp_project / "pyproject.toml").write_text('[project]\nrequires-python = ">=3.11"\n')
        result = runner.invoke(cli, ["onboard", "-y"], catch_exceptions=False)
        assert result.exit_code == 0
        assert "Imported" in result.output

    def test_onboard_empty_project(self, runner, tmp_path):
        # Use a truly empty dir (not tmp_project which may inherit CWD files)
        empty = tmp_path / "empty"
        empty.mkdir()
        init_project(empty)
        result = runner.invoke(
            cli,
            ["onboard", "--dry-run"],
            catch_exceptions=False,
        )
        # The scan runs from CWD, which may have project files. Just check it doesn't crash.
        assert result.exit_code == 0


# ── Enhanced Status (B24) ───────────────────────────────────────────────


class TestEnhancedStatus:
    def test_status_shows_phase(self, runner, tmp_project):
        result = runner.invoke(cli, ["status"], catch_exceptions=False)
        assert result.exit_code == 0
        assert "Phase:" in result.output

    def test_status_shows_hooks(self, runner, tmp_project):
        result = runner.invoke(cli, ["status"], catch_exceptions=False)
        assert "Hooks:" in result.output

    def test_status_json(self, runner, tmp_project):
        result = runner.invoke(cli, ["status", "--json-output"], catch_exceptions=False)
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert "phase" in data
        assert "total" in data
        assert "hooks" in data

    def test_status_with_items(self, runner, tmp_project):
        sdir = tmp_project / ".sidecar"
        learn(
            "Use PostgreSQL for all storage", type="decision", domain="database", sidecar_dir=sdir
        )
        learn("Always validate auth tokens", type="constraint", domain="security", sidecar_dir=sdir)
        result = runner.invoke(cli, ["status"], catch_exceptions=False)
        assert "Knowledge Store" in result.output

    def test_status_json_with_domains(self, runner, tmp_project):
        sdir = tmp_project / ".sidecar"
        learn("Use React", type="decision", domain="frontend", sidecar_dir=sdir)
        result = runner.invoke(cli, ["status", "--json-output"], catch_exceptions=False)
        data = json.loads(result.output)
        assert "domains" in data

    def test_detailed_stats(self, tmp_project):
        sdir = tmp_project / ".sidecar"
        learn("Test content", type="decision", sidecar_dir=sdir)
        stats = get_detailed_stats(sdir)
        assert stats["total"] == 1
        assert stats["phase"] == "prototype"
        assert "claude" in stats["hooks_installed"]
        assert "git" in stats["hooks_installed"]
        assert stats["stale_count"] == 0


# ── CLI Integration ─────────────────────────────────────────────────────


class TestLearnCLIDomainPhase:
    def test_learn_with_domain(self, runner, tmp_project):
        result = runner.invoke(
            cli,
            ["learn", "--domain", "security", "Always hash passwords"],
            catch_exceptions=False,
        )
        assert result.exit_code == 0
        assert "Learned" in result.output

    def test_learn_with_min_phase(self, runner, tmp_project):
        result = runner.invoke(
            cli,
            ["learn", "--min-phase", "production", "--constraint", "No hardcoded secrets"],
            catch_exceptions=False,
        )
        assert result.exit_code == 0

    def test_backfill_domains(self, runner, tmp_project):
        sdir = tmp_project / ".sidecar"
        conn = get_db(sdir / "db.sqlite")
        item = KnowledgeItem(id="x1", type="constraint", content="Run pytest before merge")
        insert_knowledge(conn, item)
        conn.close()

        result = runner.invoke(cli, ["backfill-domains"], catch_exceptions=False)
        assert result.exit_code == 0
        assert "Updated" in result.output
