# brigli

**Fast, beautiful EDA and ML statistics for Python developers.**

[![PyPI version](https://badge.fury.io/py/brigli.svg)](https://badge.fury.io/py/brigli)
[![Python](https://img.shields.io/pypi/pyversions/brigli)](https://pypi.org/project/brigli/)
[![CI](https://github.com/yourusername/brigli/actions/workflows/ci.yml/badge.svg)](https://github.com/yourusername/brigli/actions)
[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](https://opensource.org/licenses/MIT)

Turn 50 lines of pandas + matplotlib into **one line**.

```python
import brigli

report = brigli.analyze(df)
report.show()   # beautiful visual summary
print(report)   # clean text summary
```

---

## Install

```bash
pip install brigli
```

## Quick start

```python
import pandas as pd
import brigli

df = pd.read_csv("my_data.csv")

# Full EDA report — stats + visual plots
report = brigli.analyze(df)
report.show()

# Only want specific columns?
report = brigli.analyze(df, columns=["age", "salary", "city"])

# Just histograms
brigli.plot_distributions(df)

# Save to file instead of opening a window
brigli.plot_distributions(df, save_path="distributions.png")
```

## What you get from `analyze(df)`

For **numeric columns**: mean, std, min/max, quartiles, skewness, null count.

For **categorical columns**: unique count, top-N value frequency, null count.

For the **whole dataset**: shape, memory usage, total missing % .

## Why brigli?

- **One line** — `analyze(df)` does what normally takes 50+ lines.
- **ML-first** — metrics chosen for pre-training EDA, not generic stats.
- **Clean aesthetic** — plots you can drop straight into reports.
- **Production-safe** — strict input validation, no `eval()`, thread-safe.
- **Typed** — full Python type hints throughout.

## Requirements

- Python 3.9+
- pandas ≥ 1.5
- numpy ≥ 1.23
- matplotlib ≥ 3.6
- scipy ≥ 1.9

## License

MIT — see [LICENSE](LICENSE).