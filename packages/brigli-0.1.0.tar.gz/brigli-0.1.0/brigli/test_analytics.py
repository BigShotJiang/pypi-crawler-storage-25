"""Unit tests for brigli.analytics.

Run with:
    pytest tests/test_analytics.py -v
"""

import numpy as np
import pandas as pd
import pytest

from brigli.analytics import analyze, DatasetReport, ColumnReport
from brigli.exceptions import (
    EmptyDataError,
    InvalidDataError,
    InsufficientDataError,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture()
def simple_df() -> pd.DataFrame:
    return pd.DataFrame({
        "age": [25, 32, 41, 28, 55, 19, 60],
        "salary": [30_000.0, 50_000.0, 80_000.0, 45_000.0, 95_000.0, 22_000.0, 110_000.0],
        "city": ["NY", "LA", "NY", "SF", "LA", "NY", "SF"],
        "role": ["junior", "senior", "lead", "junior", "lead", "intern", "senior"],
    })


@pytest.fixture()
def df_with_nulls() -> pd.DataFrame:
    return pd.DataFrame({
        "x": [1.0, 2.0, None, 4.0, 5.0],
        "y": [None, "a", "b", "a", None],
    })


# ---------------------------------------------------------------------------
# Happy path
# ---------------------------------------------------------------------------

class TestAnalyzeHappyPath:
    def test_returns_dataset_report(self, simple_df: pd.DataFrame) -> None:
        report = analyze(simple_df)
        assert isinstance(report, DatasetReport)

    def test_shape_is_correct(self, simple_df: pd.DataFrame) -> None:
        report = analyze(simple_df)
        assert report.shape == (7, 4)

    def test_numeric_columns_detected(self, simple_df: pd.DataFrame) -> None:
        report = analyze(simple_df)
        assert set(report.numeric_columns) == {"age", "salary"}

    def test_categorical_columns_detected(self, simple_df: pd.DataFrame) -> None:
        report = analyze(simple_df)
        assert set(report.categorical_columns) == {"city", "role"}

    def test_column_reports_exist_for_all_columns(self, simple_df: pd.DataFrame) -> None:
        report = analyze(simple_df)
        assert set(report.columns.keys()) == set(simple_df.columns)

    def test_numeric_column_has_stats(self, simple_df: pd.DataFrame) -> None:
        report = analyze(simple_df)
        age = report.columns["age"]
        assert isinstance(age, ColumnReport)
        assert age.is_numeric is True
        assert age.mean is not None
        assert age.std is not None
        assert age.min is not None
        assert age.max is not None
        assert age.median is not None
        assert age.skewness is not None

    def test_categorical_column_has_top_values(self, simple_df: pd.DataFrame) -> None:
        report = analyze(simple_df)
        city = report.columns["city"]
        assert isinstance(city, ColumnReport)
        assert city.is_numeric is False
        assert "NY" in city.top_values
        assert city.top_values["NY"] == 3

    def test_no_missing_data_flag(self, simple_df: pd.DataFrame) -> None:
        report = analyze(simple_df)
        assert report.has_missing_data is False
        assert report.total_null_pct == 0.0

    def test_subset_columns(self, simple_df: pd.DataFrame) -> None:
        report = analyze(simple_df, columns=["age", "city"])
        assert set(report.columns.keys()) == {"age", "city"}


class TestAnalyzeWithNulls:
    def test_null_count_is_correct(self, df_with_nulls: pd.DataFrame) -> None:
        report = analyze(df_with_nulls)
        assert report.columns["x"].null_count == 1
        assert report.columns["y"].null_count == 2

    def test_has_missing_data_flag(self, df_with_nulls: pd.DataFrame) -> None:
        report = analyze(df_with_nulls)
        assert report.has_missing_data is True


# ---------------------------------------------------------------------------
# Input validation
# ---------------------------------------------------------------------------

class TestAnalyzeValidation:
    def test_raises_on_non_dataframe(self) -> None:
        with pytest.raises(InvalidDataError):
            analyze([1, 2, 3])  # type: ignore[arg-type]

    def test_raises_on_empty_dataframe(self) -> None:
        with pytest.raises(EmptyDataError):
            analyze(pd.DataFrame())

    def test_raises_on_too_few_rows(self) -> None:
        with pytest.raises(InsufficientDataError):
            analyze(pd.DataFrame({"a": [1, 2]}))

    def test_raises_on_invalid_columns(self, simple_df: pd.DataFrame) -> None:
        with pytest.raises(InvalidDataError):
            analyze(simple_df, columns=["age", "nonexistent_column"])

    def test_raises_on_invalid_top_n(self, simple_df: pd.DataFrame) -> None:
        with pytest.raises(ValueError):
            analyze(simple_df, top_n_values=0)

        with pytest.raises(ValueError):
            analyze(simple_df, top_n_values=51)

    def test_raises_on_all_null_dataframe(self) -> None:
        all_null = pd.DataFrame({"a": [None, None, None], "b": [None, None, None]})
        with pytest.raises(InvalidDataError):
            analyze(all_null)

    def test_raises_on_dict_input(self) -> None:
        with pytest.raises(InvalidDataError):
            analyze({"a": [1, 2, 3]})  # type: ignore[arg-type]


# ---------------------------------------------------------------------------
# DatasetReport properties
# ---------------------------------------------------------------------------

class TestDatasetReportProperties:
    def test_n_rows(self, simple_df: pd.DataFrame) -> None:
        report = analyze(simple_df)
        assert report.n_rows == 7

    def test_n_cols(self, simple_df: pd.DataFrame) -> None:
        report = analyze(simple_df)
        assert report.n_cols == 4

    def test_repr_is_string(self, simple_df: pd.DataFrame) -> None:
        report = analyze(simple_df)
        result = repr(report)
        assert isinstance(result, str)
        assert "DatasetReport" in result

    def test_memory_mb_is_positive(self, simple_df: pd.DataFrame) -> None:
        report = analyze(simple_df)
        assert report.memory_mb >= 0.0


# ---------------------------------------------------------------------------
# Edge cases
# ---------------------------------------------------------------------------

class TestEdgeCases:
    def test_single_numeric_column(self) -> None:
        df = pd.DataFrame({"x": range(10)})
        report = analyze(df)
        assert len(report.columns) == 1
        assert report.columns["x"].is_numeric is True

    def test_very_large_values(self) -> None:
        df = pd.DataFrame({"big": [1e15, 2e15, 3e15, 4e15, 5e15]})
        report = analyze(df)
        assert report.columns["big"].mean is not None

    def test_negative_values(self) -> None:
        df = pd.DataFrame({"neg": [-10, -5, 0, 5, 10]})
        report = analyze(df)
        assert report.columns["neg"].min == -10.0
        assert report.columns["neg"].max == 10.0