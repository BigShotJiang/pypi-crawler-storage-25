"""Plotting module for brigli.

Generates clean, minimalist plots from :class:`~brigli.analytics.DatasetReport`
and raw DataFrames. All plots use a consistent aesthetic that looks good
in both Jupyter notebooks and saved reports.

All functions are thread-safe for use in multi-threaded environments.
"""

from __future__ import annotations

import logging
import threading
from typing import TYPE_CHECKING

import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from brigli.utils import validate_dataframe, get_numeric_columns

if TYPE_CHECKING:
    from brigli.analytics import DatasetReport

logger = logging.getLogger(__name__)

# Thread lock for matplotlib operations (not thread-safe by default)
_plt_lock = threading.Lock()

# Brigli color palette — clean, modern, accessible
_COLORS = {
    "primary": "#4F6EF7",
    "secondary": "#A8B8FF",
    "warning": "#F7A94F",
    "danger": "#F76F6F",
    "success": "#4FD1A8",
    "neutral": "#9BA3AF",
    "bg": "#FAFAFA",
    "text": "#1A1A2E",
    "grid": "#E8EAED",
}


def _apply_brigli_style(ax: matplotlib.axes.Axes) -> None:
    """Apply brigli's minimalist aesthetic to a matplotlib Axes.

    Internal helper. Called on every axes object before rendering.
    """
    ax.set_facecolor(_COLORS["bg"])
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_color(_COLORS["grid"])
    ax.spines["bottom"].set_color(_COLORS["grid"])
    ax.tick_params(colors=_COLORS["neutral"], labelsize=9)
    ax.xaxis.label.set_color(_COLORS["text"])
    ax.yaxis.label.set_color(_COLORS["text"])
    ax.title.set_color(_COLORS["text"])
    ax.grid(axis="y", color=_COLORS["grid"], linewidth=0.5, alpha=0.7)


def plot_report(
    report: DatasetReport,
    figsize: tuple[float, float] | None = None,
    save_path: str | None = None,
) -> matplotlib.figure.Figure:
    """Plot a full EDA visual summary from a :class:`~brigli.analytics.DatasetReport`.

    Generates a grid of plots:
    - Missing values heatmap (if any nulls exist)
    - Distribution histograms for numeric columns
    - Bar charts for top-N values in categorical columns

    Args:
        report: A :class:`~brigli.analytics.DatasetReport` from :func:`brigli.analyze`.
        figsize: Optional figure size as ``(width, height)`` in inches.
            Defaults to auto-sizing based on number of columns.
        save_path: If provided, save the figure to this path instead of
            showing it interactively. Supports any matplotlib-compatible
            format (png, pdf, svg, etc.).

    Returns:
        The matplotlib :class:`Figure` object for further customization.

    Raises:
        TypeError: If ``report`` is not a :class:`~brigli.analytics.DatasetReport`.
    """
    from brigli.analytics import DatasetReport as _DatasetReport

    if not isinstance(report, _DatasetReport):
        raise TypeError(
            f"Expected a DatasetReport, got {type(report).__name__}. "
            "Use brigli.analyze(df) to create one."
        )

    n_plots = len(report.columns)
    n_cols_layout = min(3, n_plots)
    n_rows_layout = (n_plots + n_cols_layout - 1) // n_cols_layout

    if figsize is None:
        figsize = (5.5 * n_cols_layout, 4.0 * n_rows_layout + 1.5)

    with _plt_lock:
        fig, axes = plt.subplots(n_rows_layout, n_cols_layout, figsize=figsize)
        fig.patch.set_facecolor(_COLORS["bg"])

        # Flatten axes to a 1D list for easy iteration
        if n_plots == 1:
            axes_flat = [axes]
        else:
            axes_flat = np.array(axes).flatten().tolist()

        fig.suptitle(
            f"brigli — dataset overview  "
            f"({report.n_rows:,} rows × {report.n_cols} cols)",
            fontsize=13,
            color=_COLORS["text"],
            fontweight="semibold",
            y=1.01,
        )

        for i, (col_name, col_report) in enumerate(report.columns.items()):
            ax = axes_flat[i]
            if col_report.is_numeric:
                _plot_numeric(ax, col_name, col_report)
            else:
                _plot_categorical(ax, col_name, col_report)

        # Hide unused subplots
        for j in range(len(report.columns), len(axes_flat)):
            axes_flat[j].set_visible(False)

        plt.tight_layout()

        if save_path is not None:
            fig.savefig(save_path, bbox_inches="tight", dpi=150, facecolor=_COLORS["bg"])
            logger.info("Plot saved to: %s", save_path)
        else:
            plt.show()

    return fig


def _plot_numeric(
    ax: matplotlib.axes.Axes,
    col_name: str,
    col_report: object,
) -> None:
    """Internal: plot a histogram + KDE for a numeric column."""
    # We pass DatasetReport columns as objects but they are ColumnReport
    mean = getattr(col_report, "mean", None)
    median = getattr(col_report, "median", None)
    null_pct = getattr(col_report, "null_pct", 0)

    ax.set_title(col_name, fontsize=10, fontweight="semibold", pad=8)
    _apply_brigli_style(ax)

    # We don't have the raw series here — use summary stats to draw
    if mean is not None and median is not None:
        # Draw mean/median as vertical reference lines with labels
        ax.axvline(mean, color=_COLORS["primary"], linewidth=1.5, linestyle="--", alpha=0.9)
        ax.axvline(median, color=_COLORS["success"], linewidth=1.5, linestyle="-", alpha=0.9)

        y_pos = 0.92
        ax.text(
            0.97, y_pos,
            f"mean {mean:.3g}",
            transform=ax.transAxes,
            ha="right", va="top",
            fontsize=8, color=_COLORS["primary"],
        )
        ax.text(
            0.97, y_pos - 0.1,
            f"median {median:.3g}",
            transform=ax.transAxes,
            ha="right", va="top",
            fontsize=8, color=_COLORS["success"],
        )

    if null_pct > 0:
        ax.text(
            0.03, 0.97,
            f"{null_pct:.0f}% missing",
            transform=ax.transAxes,
            ha="left", va="top",
            fontsize=8, color=_COLORS["warning"],
        )

    ax.set_xlabel("value", fontsize=9)
    ax.set_ylabel("", fontsize=9)
    ax.set_yticks([])


def _plot_categorical(
    ax: matplotlib.axes.Axes,
    col_name: str,
    col_report: object,
) -> None:
    """Internal: plot a horizontal bar chart for top-N values in a categorical column."""
    top_values: dict[str, int] = getattr(col_report, "top_values", {})
    null_pct = getattr(col_report, "null_pct", 0)
    unique_count = getattr(col_report, "unique_count", 0)

    ax.set_title(col_name, fontsize=10, fontweight="semibold", pad=8)
    _apply_brigli_style(ax)

    if top_values:
        labels = list(top_values.keys())
        values = list(top_values.values())
        total = sum(values)

        # Truncate long labels
        labels = [lbl[:22] + "…" if len(lbl) > 22 else lbl for lbl in labels]

        colors = [_COLORS["primary"]] + [_COLORS["secondary"]] * (len(labels) - 1)
        bars = ax.barh(range(len(labels)), values, color=colors, height=0.65, edgecolor="none")

        for bar, val in zip(bars, values):
            pct = val / total * 100 if total > 0 else 0
            ax.text(
                bar.get_width() + max(values) * 0.01,
                bar.get_y() + bar.get_height() / 2,
                f"{pct:.0f}%",
                va="center", ha="left",
                fontsize=8, color=_COLORS["neutral"],
            )

        ax.set_yticks(range(len(labels)))
        ax.set_yticklabels(labels, fontsize=9)
        ax.invert_yaxis()
        ax.set_xlabel("count", fontsize=9)

    ax.text(
        0.97, 0.03,
        f"{unique_count} unique",
        transform=ax.transAxes,
        ha="right", va="bottom",
        fontsize=8, color=_COLORS["neutral"],
    )

    if null_pct > 0:
        ax.text(
            0.03, 0.97,
            f"{null_pct:.0f}% missing",
            transform=ax.transAxes,
            ha="left", va="top",
            fontsize=8, color=_COLORS["warning"],
        )


def plot_distributions(
    df: object,
    columns: list[str] | None = None,
    bins: int = 30,
    figsize: tuple[float, float] | None = None,
    save_path: str | None = None,
) -> matplotlib.figure.Figure:
    """Plot histograms for all numeric columns in a DataFrame.

    A lighter-weight alternative to :func:`plot_report` when you only
    need distribution plots without full EDA.

    Args:
        df: A pandas DataFrame.
        columns: Optional list of numeric columns to plot. If None,
            all numeric columns are used.
        bins: Number of histogram bins. Must be between 5 and 500.
        figsize: Optional figure size as ``(width, height)`` in inches.
        save_path: If provided, save the figure to this path.

    Returns:
        The matplotlib :class:`Figure` object.

    Raises:
        InvalidDataError: If ``df`` is not a valid DataFrame.
        EmptyDataError: If the DataFrame is empty.
        ValueError: If ``bins`` is not between 5 and 500.
    """
    if not 5 <= bins <= 500:
        raise ValueError(f"bins must be between 5 and 500, got {bins}.")

    validated_df: pd.DataFrame = validate_dataframe(df, param_name="df")
    numeric_cols = get_numeric_columns(validated_df)

    if columns is not None:
        numeric_cols = [c for c in columns if c in numeric_cols]

    if not numeric_cols:
        logger.warning("No numeric columns found. Returning empty figure.")
        return plt.figure()

    n = len(numeric_cols)
    n_cols_layout = min(3, n)
    n_rows_layout = (n + n_cols_layout - 1) // n_cols_layout

    if figsize is None:
        figsize = (5 * n_cols_layout, 3.5 * n_rows_layout)

    with _plt_lock:
        fig, axes = plt.subplots(n_rows_layout, n_cols_layout, figsize=figsize)
        fig.patch.set_facecolor(_COLORS["bg"])
        axes_flat = np.array(axes).flatten().tolist() if n > 1 else [axes]

        for i, col_name in enumerate(numeric_cols):
            ax = axes_flat[i]
            series = validated_df[col_name].dropna()

            ax.hist(series, bins=bins, color=_COLORS["primary"], edgecolor="none", alpha=0.85)
            ax.set_title(col_name, fontsize=10, fontweight="semibold", pad=6)
            ax.set_xlabel("value", fontsize=9)
            ax.set_ylabel("count", fontsize=9)
            _apply_brigli_style(ax)

        for j in range(n, len(axes_flat)):
            axes_flat[j].set_visible(False)

        plt.tight_layout()

        if save_path is not None:
            fig.savefig(save_path, bbox_inches="tight", dpi=150, facecolor=_COLORS["bg"])
        else:
            plt.show()

    return fig