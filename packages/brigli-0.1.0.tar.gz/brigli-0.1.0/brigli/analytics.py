"""Core analytics module for brigli.

Provides fast, beautiful Exploratory Data Analysis (EDA) for DataFrames.
The main entry point is the :func:`analyze` function, which generates
a complete statistical summary with minimal code.

Example:
    >>> import pandas as pd
    >>> import brigli
    >>> df = pd.read_csv("my_data.csv")
    >>> report = brigli.analyze(df)
    >>> report.show()   # opens a visual summary
    >>> print(report)   # prints a text summary
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field

import numpy as np
import pandas as pd
from scipy import stats

from brigli.exceptions import InsufficientDataError
from brigli.utils import (
    get_categorical_columns,
    get_numeric_columns,
    safe_column_subset,
    validate_dataframe,
)

logger = logging.getLogger(__name__)

_MIN_ROWS_FOR_STATS = 3


@dataclass
class ColumnReport:
    """Statistical summary for a single column.

    Attributes:
        name: Column name.
        dtype: Pandas dtype string.
        null_count: Number of null values.
        null_pct: Percentage of null values (0-100).
        unique_count: Number of unique non-null values.
        is_numeric: Whether the column is numeric.
        mean: Mean (numeric columns only).
        std: Standard deviation (numeric columns only).
        min: Minimum value (numeric columns only).
        q25: 25th percentile (numeric columns only).
        median: Median value (numeric columns only).
        q75: 75th percentile (numeric columns only).
        max: Maximum value (numeric columns only).
        skewness: Skewness (numeric columns only).
        top_values: Most frequent values and their counts (categorical columns).
    """

    name: str
    dtype: str
    null_count: int
    null_pct: float
    unique_count: int
    is_numeric: bool
    mean: float | None = None
    std: float | None = None
    min: float | None = None
    q25: float | None = None
    median: float | None = None
    q75: float | None = None
    max: float | None = None
    skewness: float | None = None
    top_values: dict[str, int] = field(default_factory=dict)

    @property
    def has_nulls(self) -> bool:
        """True if the column contains any null values."""
        return self.null_count > 0

    @property
    def is_high_cardinality(self) -> bool:
        """True if the column has more than 50 unique values (for categoricals)."""
        return not self.is_numeric and self.unique_count > 50


@dataclass
class DatasetReport:
    """Full EDA report for a DataFrame.

    Attributes:
        shape: (rows, columns) tuple.
        memory_mb: Approximate memory usage in megabytes.
        total_null_pct: Percentage of all values that are null.
        numeric_columns: Names of numeric columns.
        categorical_columns: Names of categorical/object columns.
        datetime_columns: Names of datetime columns.
        columns: Detailed per-column reports.
    """

    shape: tuple[int, int]
    memory_mb: float
    total_null_pct: float
    numeric_columns: list[str]
    categorical_columns: list[str]
    datetime_columns: list[str]
    columns: dict[str, ColumnReport]

    @property
    def n_rows(self) -> int:
        """Number of rows."""
        return self.shape[0]

    @property
    def n_cols(self) -> int:
        """Number of columns."""
        return self.shape[1]

    @property
    def has_missing_data(self) -> bool:
        """True if any column has missing data."""
        return self.total_null_pct > 0.0

    def show(self) -> None:
        """Open a visual summary plot.

        This is a convenience method that calls :func:`brigli.plotting.plot_report`.
        """
        from brigli.plotting import plot_report
        plot_report(self)

    def __repr__(self) -> str:
        lines = [
            f"DatasetReport({self.n_rows} rows × {self.n_cols} cols | "
            f"{self.memory_mb:.2f} MB | "
            f"{self.total_null_pct:.1f}% missing)",
        ]
        for name, col in self.columns.items():
            null_info = f"  {col.null_pct:.0f}% null" if col.has_nulls else ""
            if col.is_numeric:
                lines.append(
                    f"  {name} [numeric] mean={col.mean:.3g} "
                    f"std={col.std:.3g}{null_info}"
                )
            else:
                lines.append(
                    f"  {name} [categorical] {col.unique_count} unique{null_info}"
                )
        return "\n".join(lines)


def analyze(
    df: object,
    columns: list[str] | None = None,
    top_n_values: int = 5,
) -> DatasetReport:
    """Analyze a DataFrame and return a full EDA report.

    This is brigli's main entry point. Pass any pandas DataFrame and
    get back a :class:`DatasetReport` with statistics, null counts,
    distributions, and more — ready to display or plot.

    Args:
        df: A pandas DataFrame to analyze.
        columns: Optional list of column names to include. If None,
            all columns are analyzed.
        top_n_values: For categorical columns, how many top values to include
            in the frequency table. Must be between 1 and 50.

    Returns:
        A :class:`DatasetReport` with per-column statistics.

    Raises:
        InvalidDataError: If ``df`` is not a pandas DataFrame,
            or ``columns`` contains names not in the DataFrame.
        EmptyDataError: If the DataFrame is empty.
        InsufficientDataError: If the DataFrame has fewer than 3 rows
            (the minimum for meaningful statistics).
        ValueError: If ``top_n_values`` is not between 1 and 50.

    Example:
        >>> import pandas as pd
        >>> import brigli
        >>> df = pd.DataFrame({"age": [25, 32, 41], "city": ["NY", "LA", "NY"]})
        >>> report = brigli.analyze(df)
        >>> print(report)
        DatasetReport(3 rows × 2 cols | 0.00 MB | 0.0% missing)
          age [numeric] mean=32.7 std=8.08
          city [categorical] 2 unique
    """
    if not 1 <= top_n_values <= 50:
        raise ValueError(
            f"top_n_values must be between 1 and 50, got {top_n_values}."
        )

    validated_df: pd.DataFrame = validate_dataframe(df, param_name="df", min_rows=_MIN_ROWS_FOR_STATS)

    if len(validated_df) < _MIN_ROWS_FOR_STATS:
        raise InsufficientDataError(
            minimum=_MIN_ROWS_FOR_STATS,
            received=len(validated_df),
            analysis="brigli.analyze()",
        )

    selected_cols = safe_column_subset(validated_df, columns, param_name="columns")
    subset = validated_df[selected_cols]

    numeric_cols = get_numeric_columns(subset)
    categorical_cols = get_categorical_columns(subset)
    datetime_cols = subset.select_dtypes(include=["datetime64"]).columns.tolist()

    total_cells = subset.size
    total_nulls = int(subset.isnull().sum().sum())
    total_null_pct = (total_nulls / total_cells * 100) if total_cells > 0 else 0.0
    memory_mb = subset.memory_usage(deep=True).sum() / (1024 ** 2)

    column_reports: dict[str, ColumnReport] = {}
    for col_name in selected_cols:
        column_reports[col_name] = _analyze_column(
            series=subset[col_name],
            top_n_values=top_n_values,
        )

    logger.info(
        "Analysis complete: %d rows, %d cols, %.1f%% missing",
        len(subset),
        len(selected_cols),
        total_null_pct,
    )

    return DatasetReport(
        shape=(len(subset), len(selected_cols)),
        memory_mb=round(memory_mb, 4),
        total_null_pct=round(total_null_pct, 2),
        numeric_columns=numeric_cols,
        categorical_columns=categorical_cols,
        datetime_columns=datetime_cols,
        columns=column_reports,
    )


def _analyze_column(series: pd.Series, top_n_values: int) -> ColumnReport:
    """Compute statistics for a single column.

    This is an internal function. All input validation happens in :func:`analyze`.
    """
    null_count = int(series.isnull().sum())
    null_pct = round(null_count / len(series) * 100, 2)
    unique_count = int(series.nunique(dropna=True))
    is_numeric = pd.api.types.is_numeric_dtype(series)

    base = dict(
        name=series.name,
        dtype=str(series.dtype),
        null_count=null_count,
        null_pct=null_pct,
        unique_count=unique_count,
        is_numeric=is_numeric,
    )

    if is_numeric:
        clean = series.dropna()
        skew_val = float(stats.skew(clean)) if len(clean) >= 3 else None
        return ColumnReport(
            **base,
            mean=round(float(np.mean(clean)), 6),
            std=round(float(np.std(clean, ddof=1)), 6),
            min=float(np.min(clean)),
            q25=float(np.percentile(clean, 25)),
            median=float(np.median(clean)),
            q75=float(np.percentile(clean, 75)),
            max=float(np.max(clean)),
            skewness=round(skew_val, 4) if skew_val is not None else None,
        )

    top = (
        series.value_counts(dropna=True)
        .head(top_n_values)
        .to_dict()
    )
    return ColumnReport(**base, top_values={str(k): int(v) for k, v in top.items()})