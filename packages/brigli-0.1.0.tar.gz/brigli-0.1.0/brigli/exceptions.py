"""Custom exceptions for brigli.

All exceptions provide clear, developer-friendly messages explaining
what went wrong and how to fix it.
"""


class BrigliError(Exception):
    """Base exception for all brigli errors."""
    pass


class InvalidDataError(BrigliError):
    """Raised when input data is invalid or has unexpected format."""

    def __init__(self, message: str, received_type: str | None = None) -> None:
        if received_type:
            message = f"{message} (received: {received_type})"
        super().__init__(message)


class EmptyDataError(BrigliError):
    """Raised when a DataFrame or array is empty."""

    def __init__(self, param_name: str = "data") -> None:
        super().__init__(
            f"'{param_name}' cannot be empty. "
            "Please provide a DataFrame with at least one row and one column."
        )


class InsufficientDataError(BrigliError):
    """Raised when there is not enough data for a meaningful analysis."""

    def __init__(self, minimum: int, received: int, analysis: str = "this analysis") -> None:
        super().__init__(
            f"{analysis} requires at least {minimum} rows, but only {received} were provided."
        )