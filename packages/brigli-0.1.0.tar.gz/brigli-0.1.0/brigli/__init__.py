"""brigli — fast, beautiful EDA and ML statistics for Python.

Usage:
    >>> import pandas as pd
    >>> import brigli
    >>>
    >>> df = pd.read_csv("my_data.csv")
    >>> report = brigli.analyze(df)
    >>> print(report)        # text summary
    >>> report.show()        # visual plots

Public API:
    - :func:`analyze`: Full EDA report from a DataFrame.
    - :func:`plot_distributions`: Quick histogram grid.
    - :class:`DatasetReport`: The report object returned by :func:`analyze`.
    - :class:`ColumnReport`: Per-column stats within a :class:`DatasetReport`.
"""

from brigli.analytics import analyze, DatasetReport, ColumnReport
from brigli.plotting import plot_distributions
from brigli.exceptions import (
    BrigliError,
    InvalidDataError,
    EmptyDataError,
    InsufficientDataError,
)

__version__ = "0.1.0"
__author__ = "Brigli Bushati's Coding"
__license__ = "MIT"

__all__ = [
    "analyze",
    "plot_distributions",
    "DatasetReport",
    "ColumnReport",
    "BrigliError",
    "InvalidDataError",
    "EmptyDataError",
    "InsufficientDataError",
]