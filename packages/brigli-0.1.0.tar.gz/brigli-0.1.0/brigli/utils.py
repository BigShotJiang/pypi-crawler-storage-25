"""Internal utility functions for brigli.

These are NOT part of the public API. They are used internally
to validate inputs and ensure safe, consistent behavior.

Security notes:
- No eval() or exec() usage anywhere in this codebase.
- All user inputs are validated before processing.
- No dynamic code execution from string inputs.
"""

from __future__ import annotations

import logging
from typing import Sequence

import pandas as pd

from brigli.exceptions import EmptyDataError, InvalidDataError, InsufficientDataError

logger = logging.getLogger(__name__)


def validate_dataframe(
    df: object,
    param_name: str = "df",
    min_rows: int = 1,
    min_cols: int = 1,
    allow_all_null: bool = False,
) -> pd.DataFrame:
    """Validate that an object is a non-empty pandas DataFrame.

    Args:
        df: The object to validate.
        param_name: The parameter name, used in error messages.
        min_rows: Minimum number of rows required.
        min_cols: Minimum number of columns required.
        allow_all_null: If False, raises an error when all values are null.

    Returns:
        The validated DataFrame.

    Raises:
        InvalidDataError: If the input is not a pandas DataFrame.
        EmptyDataError: If the DataFrame is empty.
        InsufficientDataError: If the DataFrame doesn't have enough rows/cols.
    """
    if not isinstance(df, pd.DataFrame):
        raise InvalidDataError(
            f"'{param_name}' must be a pandas DataFrame",
            received_type=type(df).__name__,
        )

    if df.empty:
        raise EmptyDataError(param_name)

    if len(df) < min_rows:
        raise InsufficientDataError(
            minimum=min_rows,
            received=len(df),
            analysis="analysis",
        )

    if len(df.columns) < min_cols:
        raise InvalidDataError(
            f"'{param_name}' must have at least {min_cols} column(s), "
            f"but has {len(df.columns)}."
        )

    if not allow_all_null and df.isnull().all().all():
        raise InvalidDataError(
            f"'{param_name}' contains only null values. "
            "Please provide a DataFrame with at least some non-null data."
        )

    logger.debug("DataFrame validated: %d rows, %d cols", len(df), len(df.columns))
    return df


def get_numeric_columns(df: pd.DataFrame) -> list[str]:
    """Return a list of numeric column names from a DataFrame.

    Args:
        df: A validated pandas DataFrame.

    Returns:
        List of column names with numeric dtypes.
    """
    return df.select_dtypes(include="number").columns.tolist()


def get_categorical_columns(df: pd.DataFrame) -> list[str]:
    """Return a list of categorical/object column names from a DataFrame.

    Args:
        df: A validated pandas DataFrame.

    Returns:
        List of column names with object or category dtypes.
    """
    return df.select_dtypes(include=["object", "category"]).columns.tolist()


def safe_column_subset(
    df: pd.DataFrame,
    columns: Sequence[str] | None,
    param_name: str = "columns",
) -> list[str]:
    """Safely resolve a column subset, falling back to all columns if None.

    Args:
        df: The DataFrame to check columns against.
        columns: A list of column names, or None to use all columns.
        param_name: The parameter name for error messages.

    Returns:
        A list of valid column names.

    Raises:
        InvalidDataError: If any of the specified columns are not in the DataFrame.
    """
    if columns is None:
        return df.columns.tolist()

    invalid = [c for c in columns if c not in df.columns]
    if invalid:
        raise InvalidDataError(
            f"'{param_name}' contains columns not found in the DataFrame: {invalid}. "
            f"Available columns: {df.columns.tolist()}"
        )
    return list(columns)