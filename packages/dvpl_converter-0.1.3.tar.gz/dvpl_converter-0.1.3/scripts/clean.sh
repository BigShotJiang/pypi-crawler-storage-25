#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

echo "cleaning build artifacts..."

rm -rf dist/
rm -rf build/
rm -rf *.egg-info/

rm -rf .mypy_cache/
rm -rf .ruff_cache/
rm -rf .pytest_cache/

find . -type d -name __pycache__ -exec rm -rf {} + 2>/dev/null || true
find . -path ./.venv -prune -o -path ./target -prune -o -name '*.so' -print -exec rm -f {} + 2>/dev/null || true

echo "done"
