# Changelog

All notable changes to this project.

## [0.1.3] - 2026-04-16

### Fixed

- Clippy `doc_markdown` failure on numpy-style docstrings in `src/python.rs` that blocked the 0.1.2 release; file-level `#![allow(clippy::doc_markdown)]` keeps the Python hover clean

## [0.1.2] - 2026-04-16 [YANKED]

### Fixed

- Python wheel was missing the `dvpl_converter` package, which broke the `dvpl-converter` CLI entry point after `pip install`

### Changed

- Renamed the standalone script from `dvpl_converter.py` to `standalone.py` so it no longer shadows the installed package when run from the repo
- Switched PyO3 function docstrings to numpy style for richer IDE hover
- Added `py.typed` marker to the `dvpl_engine` package so PEP 561 type tooling trusts the stubs

## [0.1.1] - 2026-04-16

### Fixed

- docs.rs build broke when `cdylib` was in the default `crate-type`; moved Python bindings behind the `python` feature flag
- Added `[package.metadata.docs.rs]` so docs build without the `python` feature

## [0.1.0] - 2026-04-16

### Added

- DVPL encode and decode with LZ4 and LZ4-HC support
- Rust engine (`dvpl-engine`) with Python bindings via PyO3 and maturin
- Python CLI (`dvpl-converter`) with batch conversion and output directory
- `python -m dvpl_converter` entry point
- CRC32 integrity verification on decode
- Standalone `standalone.py` for zero-install use (requires only `lz4`)
- 4.4x faster than the pure-Python equivalent on 18k game files
