# dvpl-converter

dvpl-converter encodes and decodes DVPL-compressed World of Tanks Blitz assets with [LZ4 and LZ4-HC](https://lz4.org) support. By default, it decodes, verifies [CRC32](https://en.wikipedia.org/wiki/Cyclic_redundancy_check) integrity, and writes output next to the input file. It ships as a Rust crate (`dvpl-engine`), a Python CLI installable via pip, and a single-file standalone script that only needs `lz4`.

[![crates.io](https://img.shields.io/crates/v/dvpl-engine.svg)](https://crates.io/crates/dvpl-engine)
[![PyPI](https://img.shields.io/pypi/v/dvpl-converter.svg)](https://pypi.org/project/dvpl-converter)
[![CI](https://github.com/MihaiStreames/dvpl-converter/actions/workflows/ci.yml/badge.svg)](https://github.com/MihaiStreames/dvpl-converter/actions/workflows/ci.yml)
[![License](https://img.shields.io/github/license/MihaiStreames/dvpl-converter)](LICENSE)

Licensed under MIT.

## About

Originally a 180-line script I wrote because I couldn't open Blitz's asset files for a side project. I wanted to learn [maturin](https://www.maturin.rs), so the script became a Rust engine bridged to Python through [PyO3](https://pyo3.rs). Mildly overkill for the job, but it's fast and it was fun to build.

## Install

Python CLI:

```sh
pip install dvpl-converter
```

Rust crate:

```sh
cargo add dvpl-engine
```

Standalone script (no Rust toolchain, only needs `lz4`):

```sh
pip install lz4
python standalone.py file.xml.dvpl
```

## Usage

```sh
dvpl-converter file.xml.dvpl        # decode (default)
dvpl-converter -e file.xml          # encode with LZ4-HC
dvpl-converter *.dvpl               # batch
dvpl-converter -o out/ *.dvpl      # output directory
```

| Flag            | Short | Description                                    |
| --------------- | ----- | ---------------------------------------------- |
| `--encode`      | `-e`  | Encode to DVPL (default is decode)             |
| `--compression` | `-c`  | `0` none, `1` LZ4, `2` LZ4-HC (default: `2`)   |
| `--output-dir`  | `-o`  | Output directory                               |

## Rust API

```rust
use dvpl_engine::{decode, encode, COMP_LZ4_HC};

let blob = encode(b"hello DVPL", COMP_LZ4_HC)?;
let out = decode(&blob)?;
assert_eq!(out, b"hello DVPL");
```

Full API on [docs.rs/dvpl-engine](https://docs.rs/dvpl-engine).

## DVPL format

A `.dvpl` file is a payload followed by a 20-byte footer:

| Field             | Size    | Encoding      |
| ----------------- | ------- | ------------- |
| `original_size`   | 4 bytes | little-endian |
| `compressed_size` | 4 bytes | little-endian |
| `crc32`           | 4 bytes | little-endian |
| `compression`     | 4 bytes | little-endian |
| `magic`           | 4 bytes | `DVPL`        |

Compression types: `0` none, `1` LZ4, `2` LZ4-HC.

## Development

```sh
git clone https://github.com/MihaiStreames/dvpl-converter.git
cd dvpl-converter
maturin develop --release
```

## License

MIT. See [LICENSE](LICENSE).

<div align="center">
  Made with ❤️
</div>
