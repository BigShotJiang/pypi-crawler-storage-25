"""DVPL file format converter for World of Tanks Blitz"""

from dvpl_engine import COMP_LZ4 as COMP_LZ4
from dvpl_engine import COMP_LZ4_HC as COMP_LZ4_HC
from dvpl_engine import COMP_NONE as COMP_NONE
from dvpl_engine import BadMagicError as BadMagicError
from dvpl_engine import CrcMismatchError as CrcMismatchError
from dvpl_engine import DecompressedSizeMismatchError as DecompressedSizeMismatchError
from dvpl_engine import DvplError as DvplError
from dvpl_engine import Lz4Error as Lz4Error
from dvpl_engine import SizeMismatchError as SizeMismatchError
from dvpl_engine import TooSmallError as TooSmallError
from dvpl_engine import UnknownCompressionError as UnknownCompressionError
from dvpl_engine import decode as decode
from dvpl_engine import encode as encode

from dvpl_converter._cli import main as main


__all__ = [
    "BadMagicError",
    "COMP_LZ4",
    "COMP_LZ4_HC",
    "COMP_NONE",
    "CrcMismatchError",
    "DecompressedSizeMismatchError",
    "DvplError",
    "Lz4Error",
    "SizeMismatchError",
    "TooSmallError",
    "UnknownCompressionError",
    "decode",
    "encode",
    "main",
]
