"""Allow running as `python -m dvpl_converter`"""

from dvpl_converter._cli import main


main()
