"""CLI entry point for DVPL conversion"""

from __future__ import annotations

from argparse import ArgumentParser
from pathlib import Path
from sys import exit as sys_exit
from sys import stderr

from dvpl_engine import COMP_LZ4_HC
from dvpl_engine import decode
from dvpl_engine import encode


def _convert_file(path: Path, *, to_dvpl: bool, comp_type: int, output_dir: Path | None) -> Path:
    """Convert a single file, return output path"""
    data = path.read_bytes()

    if to_dvpl:
        result = encode(data, comp_type)
        out_path = (output_dir or path.parent) / (path.name + ".dvpl")
    else:
        result = decode(data)
        stem = (
            path.name.removesuffix(".dvpl")
            if path.name.endswith(".dvpl")
            else path.name + ".decoded"
        )
        out_path = (output_dir or path.parent) / stem

    out_path.write_bytes(result)
    return out_path


def main() -> None:
    """CLI entry point for DVPL conversion"""
    parser = ArgumentParser(description="Convert DVPL files (World of Tanks Blitz)")
    parser.add_argument("files", nargs="+", type=Path, help="Files to convert")
    parser.add_argument(
        "-e",
        "--encode",
        action="store_true",
        help="Encode to DVPL (default is decode)",
    )
    parser.add_argument(
        "-c",
        "--compression",
        type=int,
        default=COMP_LZ4_HC,
        choices=[0, 1, 2],
        help="Compression type for encoding: 0=none, 1=lz4, 2=lz4-hc (default: 2)",
    )
    parser.add_argument("-o", "--output-dir", type=Path, help="Output directory")
    args = parser.parse_args()

    if args.output_dir:
        args.output_dir.mkdir(parents=True, exist_ok=True)

    errors = 0
    for path in args.files:
        if not path.is_file():
            print(f"Skip: {path} (not a file)", file=stderr)
            errors += 1
            continue

        try:
            out = _convert_file(
                path,
                to_dvpl=args.encode,
                comp_type=args.compression,
                output_dir=args.output_dir,
            )
            print(f"{'Encoded' if args.encode else 'Decoded'}: {path} -> {out}")

        except Exception as e:
            print(f"Error: {path}: {e}", file=stderr)
            errors += 1

    if errors:
        sys_exit(1)
