from pathlib import Path
from typing import Any
from unittest import mock

import pytest
from mopidy import backend as backend_api
from mopidy.models import Album, Artist
from mopidy.types import Uri

from mopidy_spotify import backend, utils, web
from mopidy_spotify.library import SpotifyLibraryProvider


@pytest.fixture
def caplog(caplog: pytest.LogCaptureFixture) -> pytest.LogCaptureFixture:
    caplog.set_level(utils.TRACE)
    return caplog


@pytest.fixture
def config(tmp_path: Path) -> dict[str, Any]:
    return {
        "core": {
            "cache_dir": str(tmp_path / "cache"),
            "data_dir": str(tmp_path / "data"),
        },
        "proxy": {},
        "spotify": {
            "bitrate": 160,
            "volume_normalization": True,
            "timeout": 10,
            "allow_cache": True,
            "cache_size": 8192,
            "allow_playlists": True,
            "search_album_count": 20,
            "search_artist_count": 10,
            "search_track_count": 50,
            "client_id": "abcd1234",
            "client_secret": "YWJjZDEyMzQ=",
        },
    }


@pytest.fixture
def web_mock():
    patcher = mock.patch.object(backend, "web", spec=web)
    yield patcher.start()
    patcher.stop()


@pytest.fixture
def web_search_mock(
    web_album_mock_base: dict[str, Any],
    web_artist_mock: dict[str, Any],
    web_track_mock: dict[str, Any],
) -> dict[str, Any]:
    return {
        "albums": {"items": [web_album_mock_base]},
        "artists": {"items": [web_artist_mock]},
        "tracks": {"items": [web_track_mock, web_track_mock]},
    }


@pytest.fixture
def web_search_mock_large(
    web_album_mock: dict[str, Any],
    web_artist_mock: dict[str, Any],
    web_track_mock: dict[str, Any],
) -> dict[str, Any]:
    return {
        "albums": {"items": [web_album_mock] * 10},
        "artists": {"items": [web_artist_mock] * 10},
        "tracks": {"items": [web_track_mock] * 10},
    }


@pytest.fixture
def web_artist_mock() -> dict[str, Any]:
    return {"name": "ABBA", "uri": "spotify:artist:abba", "type": "artist"}


@pytest.fixture
def web_track_mock_base(web_artist_mock: dict[str, Any]) -> dict[str, Any]:
    return {
        "artists": [web_artist_mock],
        "disc_number": 1,
        "duration_ms": 174300,
        "name": "ABC 123",
        "track_number": 7,
        "uri": "spotify:track:abc",
        "id": "abc",
        "type": "track",
        "is_playable": True,
    }


@pytest.fixture
def web_album_mock_base(web_artist_mock: dict[str, Any]) -> dict[str, Any]:
    return {
        "name": "DEF 456",
        "uri": "spotify:album:def",
        "id": "def",
        "type": "album",
        "album_type": "album",
        "artists": [web_artist_mock],
    }


@pytest.fixture
def web_album_mock(
    web_album_mock_base: dict[str, Any],
    web_track_mock_base: dict[str, Any],
) -> dict[str, Any]:
    return {
        **web_album_mock_base,
        "tracks": {"items": [web_track_mock_base] * 10},
        "is_playable": True,
    }


@pytest.fixture
def web_album_mock_base2(web_artist_mock: dict[str, Any]) -> dict[str, Any]:
    return {
        "name": "XYZ 789",
        "uri": "spotify:album:xyz",
        "id": "xyz",
        "type": "album",
        "album_type": "album",
        "artists": [web_artist_mock],
    }


@pytest.fixture
def web_album_mock2(
    web_album_mock_base2: dict[str, Any],
    web_track_mock_base: dict[str, Any],
) -> dict[str, Any]:
    return {
        **web_album_mock_base2,
        "tracks": {"items": [web_track_mock_base] * 2},
        "is_playable": True,
    }


@pytest.fixture
def web_track_mock(
    web_track_mock_base: dict[str, Any],
    web_album_mock_base: dict[str, Any],
) -> dict[str, Any]:
    return {
        **web_track_mock_base,
        "album": web_album_mock_base,
    }


@pytest.fixture
def web_track_mock_link(web_track_mock: dict[str, Any]) -> web.WebLink:
    return web.WebLink.from_uri(web_track_mock["uri"])


@pytest.fixture
def web_album_mock_link(web_album_mock: dict[str, Any]) -> web.WebLink:
    return web.WebLink.from_uri(web_album_mock["uri"])


@pytest.fixture
def web_response_mock(web_track_mock: dict[str, Any]) -> web.WebResponse:
    return web.WebResponse(
        "https://api.spotify.com/v1/tracks/abc",
        web_track_mock,
        expires=1000,
        status_code=200,
    )


@pytest.fixture
def web_response_mock_etag(web_response_mock: web.WebResponse) -> web.WebResponse:
    web_response_mock._etag = '"1234"'
    return web_response_mock


@pytest.fixture
def web_oauth_mock() -> dict[str, Any]:
    return {
        "access_token": "NgCXRK...MzYjw",
        "token_type": "Bearer",
        "scope": "user-read-private user-read-email",
        "expires_in": 3600,
    }


@pytest.fixture
def web_playlist_mock(web_track_mock: dict[str, Any]) -> dict[str, Any]:
    return {
        "owner": {"id": "alice"},
        "name": "Foo",
        "tracks": {"items": [{"track": web_track_mock}]},
        "snapshot_id": "abcderfg12364",
        "uri": "spotify:user:alice:playlist:foo",
        "type": "playlist",
    }


@pytest.fixture
def mopidy_artist_mock() -> Artist:
    return Artist(name="ABBA", uri=Uri("spotify:artist:abba"))


@pytest.fixture
def mopidy_album_mock(mopidy_artist_mock: Artist) -> Album:
    return Album(
        artists=[mopidy_artist_mock],
        date="2001",
        name="DEF 456",
        uri=Uri("spotify:album:def"),
    )


@pytest.fixture
def web_client_mock() -> mock.MagicMock:
    web_client_mock = mock.MagicMock(spec=web.SpotifyOAuthClient)
    web_client_mock.user_id = "alice"
    web_client_mock.get_user_playlists.return_value = []
    return web_client_mock


@pytest.fixture
def backend_mock(
    config: dict[str, Any],
    web_client_mock: mock.MagicMock,
) -> mock.Mock:
    backend_mock = mock.Mock(spec=backend.SpotifyBackend)
    backend_mock._config = config
    backend_mock._bitrate = 160
    backend_mock._web_client = web_client_mock
    return backend_mock


@pytest.fixture
def backend_listener_mock():
    patcher = mock.patch.object(
        backend_api, "BackendListener", spec=backend_api.BackendListener
    )
    yield patcher.start()
    patcher.stop()


@pytest.fixture
def provider(backend_mock: mock.Mock) -> SpotifyLibraryProvider:
    return SpotifyLibraryProvider(backend_mock)
