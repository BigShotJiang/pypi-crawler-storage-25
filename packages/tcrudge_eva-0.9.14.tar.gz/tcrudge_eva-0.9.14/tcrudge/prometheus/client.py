import copy
from typing import Any, Dict, Optional

from tornado.web import RequestHandler

from prometheus_client import REGISTRY, Histogram
from tcrudge.prometheus.defaults import DEFAULT_METRICS_SETTINGS


class Prometheus:
    metrics_settings = copy.deepcopy(DEFAULT_METRICS_SETTINGS)

    def __init__(
            self,
            namespace: str,
            registry: REGISTRY = REGISTRY,
            metrics_settings: Optional[Dict] = None,
    ) -> None:
        self.namespace = namespace
        self.registry = registry

        if metrics_settings:
            self.metrics_settings.update(metrics_settings)

        # Metrics
        self._request_time_histogram = None

    @property
    def request_time_histogram(self) -> Histogram:
        """
        Default metric with request time.
        """
        if not self._request_time_histogram:
            self._request_time_histogram = Histogram(
                namespace=self.namespace,
                **self.metrics_settings["request_time_histogram"],
            )
        return self._request_time_histogram

    def collect_request_time_metrics(
            self,
            handler: RequestHandler,
            request_info: Optional[Dict] = None,
            request_result: Any = None,
    ) -> None:
        if not request_info:
            request_info = {
                'handler': type(handler).__name__,
                'method': handler.request.method.upper(),
                'code': int(handler.get_status()),
            }
        if not request_result:
            request_result = handler.request.request_time()

        self.request_time_histogram \
            .labels(**request_info) \
            .observe(request_result)
