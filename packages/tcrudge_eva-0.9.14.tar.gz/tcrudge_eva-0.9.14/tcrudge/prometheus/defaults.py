from prometheus_client.core import _INF

DEFAULT_METRICS_SETTINGS = {
    "request_time_histogram": {
        "labelnames": (
            "handler", "method", "code"
        ),
        "name": "http_response_time_milliseconds",
        "documentation": "Histogram of RT for HTTP requests (ms).",
        "buckets": (
            .001, .003, .005, .01, .015, .02, .03, .05, .07, .1, .15, .2,
            .3, .4, .5, .75, 1, 1.4, 2, 3, 5, 7, 9, 11, 13, 15, 20, _INF
        ),
    },
}
