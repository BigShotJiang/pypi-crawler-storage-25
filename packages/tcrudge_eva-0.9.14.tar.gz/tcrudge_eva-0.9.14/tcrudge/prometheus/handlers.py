from typing import Any

from tornado.web import RequestHandler

from prometheus_client import CONTENT_TYPE_LATEST, generate_latest


class PrometheusHandler(RequestHandler):
    def get(self, *args: Any, **kwargs: Any) -> None:
        self.set_header('Content-Type', CONTENT_TYPE_LATEST)
        self.write(generate_latest())
