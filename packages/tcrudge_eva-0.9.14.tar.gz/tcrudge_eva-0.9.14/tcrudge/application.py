from typing import Any, Dict, Iterable, Optional, Tuple

from tornado.web import Application, RequestHandler

from tcrudge.prometheus.client import Prometheus
from tcrudge.prometheus.handlers import PrometheusHandler


class TcrudgeApplication(Application):
    """
    Base tcrudge application class, includes:
        - prometheus client
        Prometheus settings dict:
            {
                'namespace': '',
                'registry': Instance of REGISTRY, have default,
                'metrics_url': r'^/metrics/?$' - default,
                'metrics_handler': PrometheusHandler - default,
                'metrics_settings': {
                    "request_time_histogram": {
                        "labelnames": (
                            "handler", "method", "code"
                        ),
                        "name": "http_response_time_milliseconds",
                        "documentation": "Histogram of RT for HTTP requests (ms).",
                        "buckets": (
                            .001, .003, .005, .01, .015, .02, .03, .05, .07, .1, .15, .2,
                            .3, .4, .5, .75, 1, 1.4, 2, 3, 5, 7, 9, 11, 13, 15, 20, _INF
                        ),
                    },
                    ...
                },
}
    """
    def __init__(
            self,
            handlers: Optional[Iterable] = None,
            prometheus_settings: Optional[Dict] = None,
            *args: Any,
            **kwargs: Any
    ) -> None:
        """
        Initialize base tornado app and prometheus.
        """
        self.prometheus = Prometheus(**prometheus_settings)
        if not handlers:
            handlers = []
        handlers.append(self._get_prometheus_route(prometheus_settings))

        super(TcrudgeApplication, self).__init__(handlers, *args, **kwargs)

    def log_request(self, handler: RequestHandler) -> None:
        """
        Function for logging info about request.
        Modificated to send info to prometheus.
        """
        super(TcrudgeApplication, self).log_request(handler)
        self.prometheus.collect_request_time_metrics(handler)
    
    def _get_prometheus_route(self, prometheus_settings: Dict) -> Tuple:
        prometheus_handler = prometheus_settings.get('metrics_handler', None) or PrometheusHandler
        prometheus_url = prometheus_settings.get('metrics_url', None) or r'^/metrics/?$'
        return prometheus_url, prometheus_handler
