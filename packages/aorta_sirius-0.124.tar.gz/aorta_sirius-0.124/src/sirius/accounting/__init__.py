import datetime
import re
from abc import ABC, abstractmethod, ABCMeta
from decimal import Decimal
from enum import Enum, EnumMeta
from typing import List
from zoneinfo import ZoneInfo

from async_lru import alru_cache
from pydantic import computed_field

from sirius import common, wise
from sirius.common import DataClass
from sirius.constants import SiriusEnvironmentSecretKey
from sirius.http_requests import AsyncHTTPSession, HTTPResponse
from sirius.market_data.ibkr import IBKRTrade


class Transaction(DataClass):
    description: str
    date: datetime.date
    amount: Decimal

    @staticmethod
    @alru_cache(maxsize=50, ttl=3600)  # 1 hour cache
    async def _get_long_term_ibkr_transaction_list() -> List["Transaction"]:
        transaction_list: List[Transaction] = []
        session: AsyncHTTPSession = AsyncHTTPSession("https://ndcdyn.interactivebrokers.com")
        flex_query_token: str = await common.get_environmental_secret(SiriusEnvironmentSecretKey.IBKR_FLEX_QUERY_TOKEN)
        flex_query_id: str = await common.get_environmental_secret(SiriusEnvironmentSecretKey.IBKR_FLEX_QUERY_ID)
        reference_code_response: HTTPResponse = await session.get(f"https://ndcdyn.interactivebrokers.com/AccountManagement/FlexWebService/SendRequest?t={flex_query_token}&q={flex_query_id}&v=3")
        reference_code: str = re.search(r"<ReferenceCode>(.*?)</ReferenceCode>", reference_code_response.response_text).group(1)

        transaction_response: HTTPResponse = await session.get(f"https://ndcdyn.interactivebrokers.com/AccountManagement/FlexWebService/GetStatement?t={flex_query_token}&q={reference_code}&v=3")
        for transaction_response_data in transaction_response.response_text.split("\n")[1:-1]:
            transaction_response_str_list: List[str] = [s.replace("\"", "").replace("'", "") for s in transaction_response_data.split(",")]
            description: str = transaction_response_str_list[31]
            date: datetime.date = datetime.datetime.strptime(transaction_response_str_list[28], "%Y-%m-%d").date()
            total_amount: Decimal = Decimal(transaction_response_str_list[43])
            activity_code: str = transaction_response_str_list[30]
            id: str = transaction_response_str_list[47]

            if activity_code == "":
                continue

            if activity_code == "BUY":
                cost_of_trade: Decimal = Decimal(transaction_response_str_list[38])
                commission: Decimal = total_amount - cost_of_trade

                transaction_list.append(Transaction(
                    description=description,
                    amount=cost_of_trade,
                    date=date
                ))
                transaction_list.append(Transaction(
                    description=f"IBKR Commission: {description}",
                    amount=commission,
                    date=date
                ))

            else:
                transaction_list.append(Transaction(
                    description=description,
                    amount=total_amount,
                    date=date
                ))

        return transaction_list

    @staticmethod
    @alru_cache(maxsize=50, ttl=60)  # 60 cache
    async def _get_short_term_ibkr_transaction_list() -> List["Transaction"]:
        transaction_list: List[Transaction] = []
        latest_long_term_transaction_date: datetime.date = max(t.date for t in await Transaction._get_long_term_ibkr_transaction_list())
        trade_list: List[IBKRTrade] = await IBKRTrade.get_past_seven_days_trades()
        trades_not_in_long_term_transaction_list: List[IBKRTrade] = list(t for t in trade_list if t.timestamp.astimezone(ZoneInfo("America/New_York")).date() > latest_long_term_transaction_date)

        for trade in trades_not_in_long_term_transaction_list:
            date: datetime.date = trade.timestamp.astimezone(ZoneInfo("America/New_York")).date()
            transaction_list.append(Transaction(
                description=f"Trade for Buy/Sell of {trade.quantity} of contract with ID {trade.contract_id}",
                date=date,
                amount=-trade.quantity * Decimal("100") * trade.price  # TODO: Change here when adding in stocks
            ))
            transaction_list.append(Transaction(
                description=f"IBKR Commission for the trade for transfer of {trade.quantity} of contract with ID {trade.contract_id}",
                date=date,
                amount=-trade.commission
            ))

        return transaction_list

    @staticmethod
    @alru_cache(maxsize=50, ttl=60)  # 60 second cache
    async def get_all_wise() -> List["Transaction"]:
        wise_account: wise.WiseAccount = await wise.WiseAccount.get()
        account_list: List[wise.Account] = await wise_account.business_profile.account_list
        account: wise.Account = next(filter(lambda a: a.type == wise.AccountType.STANDARD, account_list))
        from_datetime = datetime.datetime.combine(datetime.date(2026, 4, 1), datetime.time.min, tzinfo=ZoneInfo("Pacific/Auckland"))
        to_datetime = (datetime.datetime.now(ZoneInfo("America/New_York")) - datetime.timedelta(days=1)).replace(hour=23, minute=59, second=0, microsecond=0)

        transaction_list: List[Transaction] = [
            Transaction(
                description=transaction.description,
                date=transaction.timestamp.date(),
                amount=transaction.amount,
            ) for transaction in await account.get_transactions(from_datetime, to_datetime)]

        transaction_list.sort(key=lambda x: x.date)
        return transaction_list

    @staticmethod
    @alru_cache(maxsize=50, ttl=3600)  # 1 hour cache
    async def get_all_ibkr() -> List["Transaction"]:
        transaction_list: List[Transaction] = await Transaction._get_long_term_ibkr_transaction_list() + await Transaction._get_short_term_ibkr_transaction_list()
        transaction_list.sort(key=lambda x: x.date)
        return transaction_list


class AccountNameMeta(EnumMeta, ABCMeta):
    pass


class AccountName(ABC):

    @staticmethod
    @abstractmethod
    def get_account_name(transaction: Transaction) -> "AccountName":
        ...


class ExpenseAccountName(AccountName, ABC):
    pass


class IncomeAccountName(AccountName, ABC):
    pass


class EquityAccountName(AccountName, ABC):
    pass


class AssetOrLiabilityAccountName(AccountName, ABC):
    pass


class AccountType(Enum):
    INCOME = "INCOME"
    EXPENSE = "EXPENSE"
    EQUITY = "EQUITY"
    ASSET_OR_LIABILITY = "ASSET_OR_LIABILITY"

    @staticmethod
    def get_account_type(name: AccountName) -> AccountType:
        if isinstance(name, ExpenseAccountName):
            return AccountType.EXPENSE
        elif isinstance(name, IncomeAccountName):
            return AccountType.INCOME
        elif isinstance(name, EquityAccountName):
            return AccountType.EQUITY
        else:
            return AccountType.ASSET_OR_LIABILITY


class Account(DataClass, ABC):
    name: AccountName
    transaction_list: List[Transaction] = []

    @computed_field
    @property
    def value(self) -> Decimal:
        return sum([transaction.amount for transaction in self.transaction_list])  # type: ignore[return-value]

    @computed_field
    @property
    def type(self) -> AccountType:
        return AccountType.get_account_type(self.name)

    @staticmethod
    async def get_cash_flow_statement(from_date: datetime.date | None = None, to_date: datetime.date | None = None) -> List["Transaction"]:
        from_date = datetime.date(2026, 4, 1) if from_date is None else from_date
        to_date = datetime.date.today() if to_date is None else to_date
        ibkr_transactions_list: List[Transaction] = list(filter(lambda t: "Electronic Fund Transfer (FROM WISE US INC)".lower() not in t.description.lower(), await Transaction.get_all_ibkr()))
        wise_transactions_list: List[Transaction] = await Transaction.get_all_wise()
        transaction_list: List[Transaction] = list(filter(lambda t: from_date <= t.date <= to_date, wise_transactions_list + ibkr_transactions_list))

        transaction_list.sort(key=lambda x: x.date)
        return transaction_list
