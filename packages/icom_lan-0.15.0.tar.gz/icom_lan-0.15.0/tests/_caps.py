# Full IC-7610 capability tag set — shared across tests to avoid duplication.
FULL_ICOM_CAPS: frozenset[str] = frozenset({
    "audio", "scope", "meters", "power_control", "af_level", "rf_gain",
    "squelch", "cw", "attenuator", "preamp", "antenna", "rx_antenna",
    "system_settings", "dual_watch", "tuner", "data_mode", "nb", "nr",
    "ip_plus", "digisel", "vox", "compressor", "break_in", "notch",
    "apf", "repeater_tone", "tsql", "main_sub_tracking", "ssb_tx_bw",
    "filter_width", "filter_shape", "tx", "dual_rx", "agc",
    "tuning_step", "band_edge", "xfc", "pbt", "rit", "monitor",
})
