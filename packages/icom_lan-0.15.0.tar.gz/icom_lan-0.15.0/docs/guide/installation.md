# Installation

## Requirements

- **Python 3.11+**
- An Icom radio with LAN/WiFi connectivity (IC-7610, IC-705, IC-9700, etc.) or USB serial (IC-7300, IC-7610, etc.)
- Network access to the radio (same LAN/subnet)

## Install from PyPI

```bash
pip install icom-lan
```

## Install from Source

```bash
git clone https://github.com/morozsm/icom-lan.git
cd icom-lan
pip install -e .
```

## Development Install

For running tests and contributing:

```bash
git clone https://github.com/morozsm/icom-lan.git
cd icom-lan
pip install -e ".[dev]"
```

## Optional Dependencies

```bash
pip install icom-lan[audio]    # Opus codec (opuslib)
pip install icom-lan[bridge]   # Audio bridge (opuslib, sounddevice, numpy)
pip install icom-lan[scope]    # Scope PNG rendering (pillow)
pip install icom-lan[tls]      # HTTPS with auto-generated certs (cryptography)
```

Audio support (`[audio]`) installs `opuslib` for Opus codec. Not required for PCM/uLaw audio.

## Verify Installation

```bash
# Check the CLI is available
icom-lan --help

# Or run as a module
python -m icom_lan --help
```

## Radio Setup

Before connecting, ensure your radio is configured for LAN control:

### IC-7610

1. **Menu → Set → Network** — configure IP address (static recommended)
2. **Menu → Set → Network → Remote Control** — enable "Network Control"
3. **Menu → Set → Network → Network User** — create a username/password
4. Default port: **50001**

### IC-705

1. **Menu → Set → WLAN Set** — connect to your WiFi network
2. **Menu → Set → Network → Remote Control** — enable
3. **Menu → Set → Network → Network User** — create credentials

### IC-7300

The IC-7300 does **not** have LAN/WiFi connectivity. Use the **USB serial backend** instead:

```bash
icom-lan --backend serial --model IC-7300 --serial-port /dev/cu.usbserial-XXXXX status
```

See the [IC-7300 USB Setup guide](ic7300-usb-setup.md) for details.

!!! tip "Static IP Recommended"
    Assign a static IP to your radio to avoid connection issues after DHCP lease changes.

!!! warning "Firewall"
    Ensure UDP ports **50001-50003** are open between your computer and the radio.
