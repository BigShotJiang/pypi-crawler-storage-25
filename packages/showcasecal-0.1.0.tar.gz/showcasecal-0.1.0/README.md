# showcasecal

A simple calculator package for Python.

## Installation

```bash
pip install showcasecal