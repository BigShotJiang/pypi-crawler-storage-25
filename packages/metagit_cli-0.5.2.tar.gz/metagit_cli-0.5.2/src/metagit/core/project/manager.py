#!/usr/bin/env python
"""
Class for managing projects.
"""

import concurrent.futures
import os
import shutil
from pathlib import Path
from typing import List, Optional, Union

import git
from tqdm import tqdm

from metagit.core.appconfig.models import (
    AppConfig,
    WorkspaceDedupeConfig,
    WorkspaceDedupeScope,
)
from metagit.core.config.manager import MetagitConfigManager
from metagit.core.config.models import MetagitConfig
from metagit.core.project.models import ProjectPath
from metagit.core.workspace import workspace_dedupe
from metagit.core.workspace.hydrate import materialize_symlink_mount
from metagit.core.utils.common import create_vscode_workspace
from metagit.core.utils.fuzzyfinder import (
    FuzzyFinder,
    FuzzyFinderConfig,
    FuzzyFinderTarget,
)
from metagit.core.utils.files import parse_gitignore, should_ignore_path
from metagit.core.utils.logging import UnifiedLogger
from metagit.core.utils.userprompt import UserPrompt
from metagit.core.workspace.dedupe_resolver import resolve_effective_dedupe
from metagit.core.workspace.layout_resolver import find_project
from metagit.core.workspace.models import WorkspaceProject


def project_manager_from_app(
    app_config: AppConfig,
    logger: UnifiedLogger,
    *,
    metagit_config: Optional[MetagitConfig] = None,
    project_name: Optional[str] = None,
) -> "ProjectManager":
    """Construct a ProjectManager using workspace path and effective dedupe settings."""
    project: Optional[WorkspaceProject] = None
    if metagit_config is not None and project_name:
        project = find_project(metagit_config, project_name)
    dedupe = resolve_effective_dedupe(app_config.workspace.dedupe, project)
    return ProjectManager(
        app_config.workspace.path,
        logger,
        dedupe=dedupe,
    )


class ProjectManager:
    """
    Manager class for handling projects within a workspace.
    """

    def __init__(
        self,
        workspace_path: Union[str, Path],
        logger: UnifiedLogger,
        *,
        dedupe: Optional[WorkspaceDedupeConfig] = None,
    ) -> None:
        """
        Initialize the ProjectManager.

        Args:
            workspace_path: The root path of the workspace.
            logger: The logger instance for output.
            dedupe: When enabled, sync uses a canonical directory and project symlinks.
        """
        self.workspace_path = Path(workspace_path).expanduser().resolve()
        self.logger = logger
        self.logger.set_level("INFO")
        self._dedupe = dedupe if dedupe is not None and dedupe.enabled else None

    def add(
        self,
        config_path: Path,
        project_name: str,
        repo: Union[ProjectPath, None],
        metagit_config: MetagitConfig,
        *,
        agent_mode: bool = False,
    ) -> Union[ProjectPath, Exception]:
        """
        Add a repository to a specific project in the configuration.

        Args:
            project_name: The name of the project to add the repository to.
            repo: The ProjectPath object representing the repository to add. If None, will prompt for data.
            metagit_config: The MetagitConfig instance to work with configuration data.

        Returns:
            Union[ProjectPath, Exception]: ProjectPath if successful, Exception if failed.
        """
        config_manager = MetagitConfigManager(metagit_config=metagit_config)
        try:
            # Validate inputs
            if not project_name or not isinstance(project_name, str):
                raise ValueError("Project name must be a non-empty string")

            # Check if workspace configuration exists
            if not metagit_config.workspace:
                raise ValueError("No workspace configuration found in the config file")
            # Find the target project
            target_project = None
            for project in metagit_config.workspace.projects:
                if project.name == project_name:
                    target_project = project
                    break

            if not target_project:
                raise ValueError(
                    f"Project '{project_name}' not found in workspace configuration"
                )

            if repo is None and agent_mode:
                return ValueError(
                    "Interactive repo add is disabled in agent mode; "
                    "pass --name/--path/--url or use catalog/MCP tools"
                )
            if repo is None:
                self.logger.debug(
                    "No repository data provided. Prompting for information..."
                )
                repo_result = UserPrompt.prompt_for_model(
                    ProjectPath,
                    title="Add git repository or local path to project group",
                    fields_to_prompt=["name", "path", "url", "description"],
                )
                if isinstance(repo_result, Exception):
                    return repo_result
                if repo_result.path is None and repo_result.url is None:
                    raise ValueError(
                        "No local path or remote URL provided. Please provide one of them."
                    )
                repo = repo_result

            # Check if name already exists in the project
            for existing_repo in target_project.repos:
                if existing_repo.name == repo.name:
                    raise ValueError(
                        f"Repository '{repo.name}' already exists in project '{project_name}'"
                    )

            duplicates = workspace_dedupe.find_duplicate_identities(
                metagit_config,
                repo,
            )
            if duplicates:
                locations = ", ".join(f"{proj}/{name}" for proj, name in duplicates)
                raise ValueError(
                    "Repo identity already registered as "
                    f"{locations}; reuse that entry or enable workspace dedupe"
                )

            # Add the repository to the project
            target_project.repos.append(repo)

            # Save the updated configuration
            save_result = config_manager.save_config(metagit_config, config_path)
            if isinstance(save_result, Exception):
                return save_result

            self.logger.debug(
                f"Successfully added repository '{repo.name}' to project '{project_name}' in configuration"
            )
            return repo

        except Exception as e:
            self.logger.error(
                f"Failed to add repository '{repo.name if repo else 'unknown'}' to project '{project_name}': {str(e)}"
            )
            return e

    def sync(self, project: WorkspaceProject, *, hydrate: bool = False) -> bool:
        """
        Sync a workspace project concurrently.

        Iterates through each repository in the project and either creates a
        symbolic link for local paths or clones it if it's a remote repository.
        After syncing, creates a VS Code workspace file.

        When ``hydrate`` is True, symlink mounts are replaced with full directory
        copies (see ``hydrate_project``).

        Returns:
            bool: True if sync is successful, False otherwise.
        """
        project_dir = os.path.join(self.workspace_path, project.name)
        os.makedirs(project_dir, exist_ok=True)
        tqdm.write(f"Syncing {project.name} project to {project_dir}...")

        with concurrent.futures.ThreadPoolExecutor() as executor:
            future_to_repo = {
                executor.submit(
                    self._sync_repo,
                    repo,
                    project_dir,
                    i,
                    project_name=project.name,
                ): repo
                for i, repo in enumerate(project.repos)
            }
            for future in concurrent.futures.as_completed(future_to_repo):
                repo = future_to_repo[future]
                try:
                    future.result()
                except Exception as exc:
                    tqdm.write(f"{repo.name} generated an exception: {exc}")
                    return False

        if hydrate:
            hydrate_ok = self.hydrate_project(project)
            if not hydrate_ok:
                return False

        # Create VS Code workspace file after successful sync
        workspace_result = self._create_vscode_workspace(project, project_dir)
        if isinstance(workspace_result, Exception):
            tqdm.write(f"Failed to create VS Code workspace file: {workspace_result}")
            # Don't fail the entire sync for workspace file creation issues
        # else:
        #     tqdm.write(f"Created VS Code workspace file: {workspace_result}")

        return True

    def hydrate_project(self, project: WorkspaceProject) -> bool:
        """
        Materialize symlink mounts under a project into full directory copies.

        Returns:
            bool: True when all hydrate steps succeed or are skipped cleanly.
        """
        project_dir = self.workspace_path / project.name
        if not project_dir.is_dir():
            tqdm.write(f"Hydrate skipped: project folder missing: {project_dir}")
            return False

        tqdm.write(f"Hydrating {project.name} (symlink mounts → full copies)...")
        ok = True
        for index, repo in enumerate(project.repos):
            mount = project_dir / repo.name
            if not mount.exists() and not mount.is_symlink():
                tqdm.write(f"  ⏭️  {repo.name}: mount missing (sync first)")
                continue
            if mount.is_dir() and not mount.is_symlink():
                tqdm.write(f"  ✓  {repo.name}: already a directory")
                continue
            changed, error = materialize_symlink_mount(
                mount,
                position=index,
                repo_label=repo.name,
            )
            if error:
                tqdm.write(f"  ❌ {repo.name}: {error}")
                ok = False
            elif not changed:
                tqdm.write(f"  ⏭️  {repo.name}: not a symlink")
        return ok

    def _create_vscode_workspace(
        self, project: WorkspaceProject, project_dir: str
    ) -> Union[str, Exception]:
        """
        Create a VS Code workspace file for the project.

        Args:
            project: The workspace project containing repository information
            project_dir: The directory where the project is located

        Returns:
            Path to the created workspace file on success, Exception on failure
        """
        try:
            # Get list of repository names that were successfully synced
            repo_names = []
            for repo in project.repos:
                repo_path = os.path.join(project_dir, repo.name)
                if os.path.exists(repo_path):
                    repo_names.append(repo.name)

            if not repo_names:
                return Exception("No repositories found to include in workspace")

            # Create workspace file content
            workspace_content = create_vscode_workspace(project.name, repo_names)
            if isinstance(workspace_content, Exception):
                return workspace_content

            # Write workspace file
            workspace_file_path = os.path.join(project_dir, "workspace.code-workspace")
            with open(workspace_file_path, "w") as f:
                f.write(workspace_content)

            return workspace_file_path

        except Exception as e:
            return e

    def _sync_repo(
        self,
        repo: ProjectPath,
        project_dir: str,
        position: int,
        *,
        project_name: str,
    ) -> None:
        """
        Sync a single repository.

        This method is called by the thread pool executor.
        """
        mount_path = os.path.join(project_dir, repo.name)
        if (
            self._dedupe is not None
            and self._dedupe.scope == WorkspaceDedupeScope.WORKSPACE
        ):
            self._sync_repo_deduped(
                repo=repo,
                project_name=project_name,
                mount_path=mount_path,
                position=position,
            )
            return

        if repo.path:
            self._sync_local(repo, mount_path, position)
        elif repo.url:
            self._sync_remote(repo, mount_path, position)
        else:
            tqdm.write(f"Skipping {repo.name}: No local path or remote URL provided.")

    def _sync_repo_deduped(
        self,
        *,
        repo: ProjectPath,
        project_name: str,
        mount_path: str,
        position: int,
    ) -> None:
        """Sync using canonical storage and a per-project symlink mount."""
        if self._dedupe is None:
            return
        identity = workspace_dedupe.build_repo_identity(repo)
        if identity is None:
            tqdm.write(f"Skipping {repo.name}: No local path or remote URL provided.")
            return

        canonical = workspace_dedupe.canonical_path(
            self.workspace_path,
            self._dedupe,
            identity.repo_key,
        )
        mount = Path(mount_path)

        if repo.path:
            self._sync_local_canonical(
                repo=repo,
                source_path=Path(repo.path).expanduser().resolve(),
                canonical=canonical,
                mount=mount,
                position=position,
            )
            return

        self._sync_remote_canonical(
            repo=repo,
            canonical=canonical,
            mount=mount,
            position=position,
        )

    def _sync_local_canonical(
        self,
        *,
        repo: ProjectPath,
        source_path: Path,
        canonical: Path,
        mount: Path,
        position: int,
    ) -> None:
        """Place source under canonical (symlink) and mount project symlink."""
        if not source_path.exists():
            tqdm.write(f"Source path for {repo.name} does not exist: {source_path}")
            return

        desc = f"  ✅   🔗 {repo.name}"
        if not canonical.exists():
            canonical.parent.mkdir(parents=True, exist_ok=True)
            try:
                os.symlink(
                    source_path,
                    canonical,
                    target_is_directory=source_path.is_dir(),
                )
            except OSError as exc:
                tqdm.write(f"Failed to create canonical link for {repo.name}: {exc}")
                return

        changed, error = workspace_dedupe.ensure_symlink(mount, canonical)
        if error:
            tqdm.write(f"Failed to mount {repo.name}: {error}")
            return
        bar_format = (
            "{l_bar}Symlinked{r_bar}" if changed else "{l_bar} 🟠 Already exists{r_bar}"
        )
        with tqdm(total=1, desc=desc, position=position, bar_format=bar_format) as pbar:
            pbar.update(1)

    def _sync_remote_canonical(
        self,
        *,
        repo: ProjectPath,
        canonical: Path,
        mount: Path,
        position: int,
    ) -> None:
        """Clone into canonical when missing, then symlink the project mount."""
        if not canonical.exists():
            self._sync_remote(repo, str(canonical), position)
        if not canonical.exists():
            return
        changed, error = workspace_dedupe.ensure_symlink(mount, canonical)
        if error:
            tqdm.write(f"Failed to mount {repo.name}: {error}")
            return
        desc = f"  🔗 {repo.name}"
        bar_format = (
            "{l_bar}Mounted{r_bar}" if changed else "{l_bar} 🟠 Already exists{r_bar}"
        )
        with tqdm(total=1, desc=desc, position=position, bar_format=bar_format) as pbar:
            pbar.update(1)

    def _sync_local(self, repo: ProjectPath, target_path: str, position: int) -> None:
        """Handle syncing of a local repository via symlink."""
        source_path = Path(repo.path).expanduser().resolve()
        if not source_path.exists():
            tqdm.write(f"Source path for {repo.name} does not exist: {source_path}")
            return

        desc = f"  ✅   🔗 {repo.name}"
        mount = Path(target_path)
        if mount.exists() or mount.is_symlink():
            desc = f"  🔗 {repo.name}"
            with tqdm(
                total=1,
                desc=desc,
                position=position,
                bar_format="{l_bar} 🟠 Already exists{r_bar}",
            ) as pbar:
                pbar.update(1)
            return

        changed, error = workspace_dedupe.ensure_symlink(mount, source_path)
        if error:
            tqdm.write(f"Failed to create symbolic link for {repo.name}: {error}")
            return
        with tqdm(
            total=1,
            desc=desc,
            position=position,
            bar_format="{l_bar}Symlinked{r_bar}",
        ) as pbar:
            pbar.update(1)

    def _sync_remote(self, repo: ProjectPath, target_path: str, position: int) -> None:
        """Handle syncing of a remote repository via git clone."""

        class CloneProgressHandler(git.RemoteProgress):
            def __init__(self, pbar: tqdm) -> None:
                super().__init__()
                self.pbar = pbar
                self.pbar.total = 100

            def update(
                self,
                op_code: int,  # noqa: ARG002
                cur_count: Union[str, float],
                max_count: Union[str, float, None] = None,
                message: str = "",
            ) -> None:
                if max_count:
                    self.pbar.total = float(max_count)
                self.pbar.n = float(cur_count)
                if message:
                    self.pbar.set_postfix_str(message.strip(), refresh=True)
                self.pbar.update(0)  # Manually update the progress bar

        desc = f"  ⤵️ {repo.name}"
        if os.path.exists(target_path):
            with tqdm(
                total=1,
                desc=desc,
                position=position,
                bar_format="{l_bar} 🟠 Already exists{r_bar}",
            ) as pbar:
                pbar.update(1)
            return

        with tqdm(
            desc=desc,
            position=position,
            unit="B",
            unit_scale=True,
            unit_divisor=1024,
            miniters=1,
        ) as pbar:
            try:
                git.Repo.clone_from(
                    str(repo.url),
                    target_path,
                    progress=CloneProgressHandler(pbar),
                )
                pbar.set_description(f"  ✅ {desc} Cloned")
            except git.exc.GitCommandError as e:
                pbar.set_description(f"  ❌ {desc} Failed")
                tqdm.write(
                    f"Failed to clone repository {repo.name}.\n"
                    f"URL: {repo.url}\n"
                    f"Error: {e.stderr}"
                )

    def list_unmanaged_sync_directories(
        self,
        metagit_config: MetagitConfig,
        project: str,
        *,
        ignore_hidden: bool,
    ) -> List[Path]:
        """
        Directories or symlinks under the project sync folder that are not declared repos.

        Uses the same .gitignore rules as the repo picker. When ``ignore_hidden`` is true,
        dotfiles and dot-directories are skipped.
        """
        project_path = Path(self.workspace_path) / project
        if project == "local":
            workspace_project = metagit_config.local_workspace_project
        else:
            matches = [
                p
                for p in (metagit_config.workspace.projects or [])
                if p.name == project
            ]
            if not matches:
                return []
            workspace_project = matches[0]

        if not project_path.exists(follow_symlinks=True):
            return []

        managed = {repo.name for repo in workspace_project.repos}
        ignore_patterns = parse_gitignore(project_path / ".gitignore")
        unmanaged: List[Path] = []
        for entry in project_path.iterdir():
            if not (entry.is_dir() or entry.is_symlink()):
                continue
            if ignore_hidden and entry.name.startswith("."):
                continue
            if should_ignore_path(entry, ignore_patterns, project_path):
                continue
            if entry.name in managed:
                continue
            unmanaged.append(entry)
        return sorted(unmanaged, key=lambda p: p.name.lower())

    @staticmethod
    def remove_sync_directory(path: Path) -> None:
        """Remove a synced repo directory or symlink under a project folder."""
        if path.is_symlink() or path.is_file():
            path.unlink(missing_ok=False)
        elif path.is_dir():
            shutil.rmtree(path)

    def select_repo(
        self,
        metagit_config: MetagitConfig,
        project: str,
        show_preview: bool = False,
        menu_length: int = 10,
        ignore_hidden: bool = True,
        agent_mode: bool = False,
    ) -> ProjectPath:
        """
        Select a repository from a synced project.
        """
        if agent_mode:
            return ValueError(
                "Interactive repo selection is disabled in agent mode; "
                "use `metagit project repo list --json` or specify a repo in commands"
            )
        project_path: str = os.path.join(self.workspace_path, project)
        if project == "local":
            workspace_project = metagit_config.local_workspace_project
        else:
            workspace_project = [
                target_project
                for target_project in metagit_config.workspace.projects
                if target_project.name == project
            ][0]

        if not Path(project_path).exists(follow_symlinks=True):
            self.logger.warning(
                f"Project path does not exist for project: {project_path}"
            )
            self.logger.warning(
                f"You can sync the project with `metagit workspace sync --project {project_path}`"
            )
            return
        project_dict = {}
        ignore_patterns = parse_gitignore(Path(project_path) / ".gitignore")
        # Iterate through the project path and add the directories and symlinks to the project_dict
        for f in Path(project_path).iterdir():
            if f.is_dir() or f.is_symlink():
                if ignore_hidden and f.name.startswith("."):
                    continue
                if should_ignore_path(f, ignore_patterns, Path(project_path)):
                    continue
                # Determine type
                item_type = "Symlink" if f.is_symlink() else "Directory"

                # Check for git repository
                has_git = (f / ".git").exists() if f.is_dir() else False

                # Check for .metagit.yml file
                has_metagit_yml = (f / ".metagit.yml").exists() if f.is_dir() else False

                # Build initial description
                description_parts = [
                    f"Name: {f.name}",
                    f"Type: {item_type}",
                ]

                if f.is_symlink():
                    target_path = f.readlink()
                    # Convert absolute path to relative path from project_path
                    try:
                        if target_path.is_absolute():
                            relative_target = os.path.relpath(target_path, project_path)
                            description_parts.append(f"Target: {relative_target}")
                        else:
                            description_parts.append(f"Target: {target_path}")
                    except (ValueError, OSError):
                        # Fallback to original path if relative path calculation fails
                        description_parts.append(f"Target: {target_path}")

                # Add git and metagit info
                if has_git:
                    description_parts.append("Git: ✅ Repository")
                else:
                    description_parts.append("Git: ❌ No repository")

                if has_metagit_yml:
                    description_parts.append("MetaGit: ✅ .metagit.yml found")
                else:
                    description_parts.append("MetaGit: ❌ No .metagit.yml")

                project_dict[f.name] = self._build_preview_sections(description_parts)

        # Track which items exist in the project configuration
        managed_repos = {repo.name for repo in workspace_project.repos}

        # Iterate through the workspace project and add the repo descriptions to the project_dict
        for repo in workspace_project.repos:
            if repo.name in project_dict:
                # Update the description with management status and repo description
                summary_lines = self._build_project_repo_summary(repo)
                project_dict[repo.name] = self._append_preview_lines(
                    project_dict[repo.name], summary_lines
                )
            else:
                # This repo is configured but doesn't exist on filesystem
                description_parts = [
                    f"Name: {repo.name}",
                    "Type: Missing (configured but not synced)",
                    "Status: ⚠️ Configured but missing",
                    "Git: ❓ Unknown (not synced)",
                    "MetaGit: ❓ Unknown (not synced)",
                ]

                description_parts.extend(self._build_project_repo_summary(repo))
                project_dict[repo.name] = self._build_preview_sections(
                    description_parts
                )

        # Add unmanaged status to items that exist on filesystem but not in config
        for item_name in list(project_dict.keys()):
            if item_name not in managed_repos:
                current_description = project_dict[item_name]
                current_description += "\nStatus: ❌ Unmanaged"
                project_dict[item_name] = current_description

        projects: List[FuzzyFinderTarget] = []
        for target in project_dict:
            # Determine color based on directory type (check filesystem)
            target_path = Path(project_path) / target
            is_symlink = target_path.is_symlink()

            # Set color: white for directories, light blue for symlinks
            color = (
                "#87ceeb" if is_symlink else "white"
            )  # light blue for symlinks, white for directories

            # Set opacity: 1.0 if managed (exists in project list), 0.5 if not managed
            opacity = 1.0 if target in managed_repos else 0.5

            projects.append(
                FuzzyFinderTarget(
                    name=target,
                    description=project_dict[target],
                    color=color,
                    opacity=opacity,
                )
            )
        if len(projects) == 0:
            self.logger.warning(f"No projects found in workspace: {project_path}")
            return
        finder_config = FuzzyFinderConfig(
            items=projects,
            prompt_text="🔍 Search projects: ",
            max_results=menu_length,
            total_count=len(projects),
            query_mode_label="matches",
            score_threshold=60.0,
            highlight_color="bold white bg:#0066cc",
            normal_color="cyan",
            prompt_color="bold green",
            separator_color="gray",
            enable_preview=show_preview,
            display_field="name",
            preview_field="description",
        )
        finder = FuzzyFinder(finder_config)
        selected = finder.run()
        if isinstance(selected, Exception):
            raise selected
        if selected is None:
            return None
        else:
            selected_path = os.path.join(project_path, selected.name)
            # If the path starts with ../../, replace it with ./
            if selected_path.startswith("../../"):
                selected_path = selected_path.replace("../../", "./", 1)
            return selected_path

    @staticmethod
    def _append_preview_lines(existing: str, lines: List[str]) -> str:
        """Append non-empty lines to an existing preview block."""
        final_lines = [line for line in lines if line]
        if not final_lines:
            return existing
        return f"{existing}\n" + "\n".join(final_lines)

    @staticmethod
    def _build_preview_sections(lines: List[str]) -> str:
        """Build a readable preview body from collected lines."""
        return "\n".join([line for line in lines if line])

    @staticmethod
    def _build_project_repo_summary(repo: ProjectPath) -> List[str]:
        """Build metadata lines for configured project repositories."""
        summary_lines = ["Status: ✅ Managed"]
        summary_lines.append(
            f"Description: {repo.description or 'No description available'}"
        )
        if repo.path:
            summary_lines.append(f"Path: {repo.path}")
        if repo.url:
            summary_lines.append(f"URL: {repo.url}")
        if repo.kind:
            summary_lines.append(f"Kind: {repo.kind}")
        if repo.ref:
            summary_lines.append(f"Ref: {repo.ref}")
        if repo.language:
            summary_lines.append(f"Language: {repo.language}")
        if repo.language_version:
            summary_lines.append(f"Language Version: {repo.language_version}")
        if repo.package_manager:
            summary_lines.append(f"Package Manager: {repo.package_manager}")
        if repo.frameworks:
            summary_lines.append(f"Frameworks: {', '.join(repo.frameworks)}")
        if repo.source_provider:
            summary_lines.append(f"Source Provider: {repo.source_provider}")
        if repo.source_namespace:
            summary_lines.append(f"Source Namespace: {repo.source_namespace}")
        if repo.protected is not None:
            summary_lines.append(f"Protected: {repo.protected}")
        return summary_lines
