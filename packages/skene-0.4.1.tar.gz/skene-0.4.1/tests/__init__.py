"""
Tests for skene.
"""
