"""Tests for the live-runtime reviewer pipeline (LLM mocked)."""

from __future__ import annotations

import asyncio
from datetime import datetime
from typing import Any
from unittest.mock import patch

from surveyshield.categories import Category
from surveyshield.live.category_prompts import (
    LIVE_PROMPTS,
    LIVE_PROMPTS_BY_CATEGORY,
    LiveCategoryOutput,
)
from surveyshield.live.reviewer import (
    LiveConsolidationResult,
    aggregate_live,
    consolidate_and_summarize_live,
    drop_unverified_evidence,
    render_live_html,
    review_live_category,
    review_run,
)
from surveyshield.models._shared import (
    CategoryReview,
    EditKind,
    Finding,
    OverallFeedback,
    Severity,
)
from surveyshield.models.survey_result import LiveRunEvidence, LiveRunStep


# ---------------------------------------------------------------------------
# Stubs
# ---------------------------------------------------------------------------


class _StubStructured:
    def __init__(self, return_value: Any) -> None:
        self._rv = return_value

    async def ainvoke(self, prompt: str) -> Any:  # noqa: ARG002
        return self._rv


class _StubLLM:
    def __init__(self, return_value: Any) -> None:
        self._rv = return_value

    def with_structured_output(self, schema: type) -> _StubStructured:  # noqa: ARG002
        return _StubStructured(self._rv)


def _evidence(
    *,
    blocked_phrase_hits=None,
    looped_at_step=None,
    is_done: bool = True,
    n_steps: int = 3,
    max_steps: int = 150,
) -> LiveRunEvidence:
    return LiveRunEvidence(
        survey_url="https://q.example.com/SV_x",
        survey_domain="q.example.com",
        started_at=datetime(2026, 5, 9, 12, 0, 0),
        finished_at=datetime(2026, 5, 9, 12, 5, 0),
        model_name="gpt-4o-mini",
        max_steps=max_steps,
        steps=[
            LiveRunStep(
                index=i + 1,
                evaluation_previous_goal=f"prev goal {i+1}",
                memory=f"memory {i+1}",
                next_goal=f"next goal {i+1}",
                extracted_content=f"extracted text for step {i+1}",
            )
            for i in range(n_steps)
        ],
        final_result="Run complete.",
        is_done=is_done,
        blocked_phrase_hits=blocked_phrase_hits or [],
        looped_at_step=looped_at_step,
    )


def _good_finding() -> Finding:
    return Finding(
        locator="step:2",
        excerpt="extracted text for step 2",  # matches haystack
        severity=Severity.HIGH,
        confidence=0.9,
        rationale="agent looped here",
        recommended_edit_kind=EditKind.ADD_ATTENTION_CHECK,
    )


# ---------------------------------------------------------------------------
# review_live_category
# ---------------------------------------------------------------------------


def test_review_live_category_clamps_score_and_records_duration() -> None:
    out = LiveCategoryOutput(
        score=200.0, findings=[_good_finding()], summary="ok"
    )
    prompt = LIVE_PROMPTS[0]
    with patch("surveyshield.live.reviewer._make_llm", return_value=_StubLLM(out)):
        result = asyncio.run(
            review_live_category("blob", prompt, model="gpt-4o-mini")
        )
    assert result.score == 100.0
    assert result.findings == [out.findings[0]]
    assert result.duration_seconds >= 0.0
    assert result.error is None
    assert result.category == prompt.category


def test_review_live_category_captures_exception() -> None:
    class _Boom:
        def with_structured_output(self, schema):  # noqa: ARG002
            class _BoomSO:
                async def ainvoke(self, prompt):  # noqa: ARG002
                    raise RuntimeError("provider down")
            return _BoomSO()

    with patch("surveyshield.live.reviewer._make_llm", return_value=_Boom()):
        result = asyncio.run(
            review_live_category("blob", LIVE_PROMPTS[0], model="m")
        )
    assert result.error is not None and "RuntimeError" in result.error
    assert result.score == 0.0


# ---------------------------------------------------------------------------
# drop_unverified_evidence
# ---------------------------------------------------------------------------


def test_drop_unverified_evidence_keeps_verbatim_step_quotes() -> None:
    ev = _evidence()
    good = Finding(
        locator="step:2",
        excerpt="extracted text for step 2",
        severity=Severity.MED,
        confidence=0.9,
        rationale="r",
    )
    fabricated = Finding(
        locator="step:2",
        excerpt="this never appeared",
        severity=Severity.MED,
        confidence=0.9,
        rationale="r",
    )
    unknown_step = Finding(
        locator="step:99",
        excerpt="extracted text for step 2",  # exists in another step
        severity=Severity.MED,
        confidence=0.9,
        rationale="r",
    )
    review = CategoryReview(
        category=Category.CONTENT_TRAPS,
        score=50.0,
        findings=[good, fabricated, unknown_step],
        summary="",
        model="m",
        duration_seconds=0.0,
    )
    out = drop_unverified_evidence([review], ev)
    assert out[0].findings == [good]


def test_drop_unverified_evidence_run_level_finding_uses_union_haystack() -> None:
    ev = _evidence()
    run_level = Finding(
        locator=None,
        excerpt="memory 1",  # appears in step 1's memory field
        severity=Severity.LOW,
        confidence=0.5,
        rationale="r",
    )
    review = CategoryReview(
        category=Category.LOGICAL,
        score=80.0,
        findings=[run_level],
        summary="",
        model="m",
        duration_seconds=0.0,
    )
    out = drop_unverified_evidence([review], ev)
    assert out[0].findings == [run_level]


# ---------------------------------------------------------------------------
# consolidate_and_summarize_live
# ---------------------------------------------------------------------------


def test_consolidate_short_circuits_when_no_findings() -> None:
    reviews = [
        CategoryReview(
            category=p.category, score=80.0, findings=[], summary="",
            model="m", duration_seconds=0.0,
        )
        for p in LIVE_PROMPTS[:2]
    ]
    result = asyncio.run(
        consolidate_and_summarize_live("blob", reviews, model="m")
    )
    assert isinstance(result, LiveConsolidationResult)
    assert result.consolidated_findings == []
    assert "No category surfaced" in result.overall_feedback.headline


def test_consolidate_returns_none_on_llm_error() -> None:
    reviews = [
        CategoryReview(
            category=Category.CONTENT_TRAPS, score=40.0,
            findings=[_good_finding()],
            summary="", model="m", duration_seconds=0.0,
        )
    ]

    class _Boom:
        def with_structured_output(self, schema):  # noqa: ARG002
            class _BoomSO:
                async def ainvoke(self, prompt):  # noqa: ARG002
                    raise RuntimeError("nope")
            return _BoomSO()

    with patch("surveyshield.live.reviewer._make_llm", return_value=_Boom()):
        result = asyncio.run(
            consolidate_and_summarize_live("blob", reviews, model="m")
        )
    assert result is None


# ---------------------------------------------------------------------------
# aggregate_live — the big one (fixes 0.1.4 92%-on-blocked-survey bug)
# ---------------------------------------------------------------------------


def test_aggregate_live_caps_completion_when_agent_blocked() -> None:
    """The deterministic _detect_agent_blocked sentinel forces
    bot_completion_likelihood < 50 even if per-category scores are high."""
    ev = _evidence(blocked_phrase_hits=["validation error"])
    # All 8 categories report easy-survey-easy-bot with high "completion"
    # signal (low defense scores → high inverse → high bot completion).
    reviews = [
        CategoryReview(
            category=p.category, score=10.0, findings=[],
            summary="", model="m", duration_seconds=0.0,
        )
        for p in LIVE_PROMPTS
    ]
    result = aggregate_live(
        ev, reviews, analysis_id="x", model="m", consolidation=None,
    )
    # Defense score is low (~10), so bot_completion would be ~90 without
    # the cap. With the cap it's at most 49.0.
    assert result.bot_completion_likelihood <= 49.0
    # And `completed` reflects the override.
    assert result.completed is False


def test_aggregate_live_respects_strong_defense_when_no_block() -> None:
    """Without a block sentinel, bot_completion_likelihood follows the
    weighted scores normally."""
    ev = _evidence()  # no block hits, no loop, is_done=True
    reviews = [
        CategoryReview(
            category=p.category, score=80.0, findings=[],
            summary="", model="m", duration_seconds=0.0,
        )
        for p in LIVE_PROMPTS
    ]
    result = aggregate_live(
        ev, reviews, analysis_id="x", model="m", consolidation=None,
    )
    assert result.defense_score >= 70.0
    assert result.bot_completion_likelihood < 50.0
    # No block override fired — `completed` matches is_done.
    assert result.completed is True


def test_aggregate_live_uses_consolidation_overall_feedback() -> None:
    ev = _evidence()
    reviews = [
        CategoryReview(
            category=Category.CONTENT_TRAPS, score=40.0,
            findings=[_good_finding()],
            summary="", model="m", duration_seconds=0.0,
        )
    ]
    consolidation = LiveConsolidationResult(
        consolidated_findings=[
            Finding(
                locator="step:2",
                excerpt="extracted text for step 2",
                severity=Severity.HIGH,
                confidence=0.9,
                rationale="merged",
                suggested_fix="add an IMC",
                recommended_edit_kind=EditKind.ADD_ATTENTION_CHECK,
                contributing_categories=[Category.CONTENT_TRAPS, Category.ECLAIRE],
            )
        ],
        overall_feedback=OverallFeedback(headline="Verdict", paragraphs=["P"]),
    )
    result = aggregate_live(
        ev, reviews, analysis_id="x", model="m",
        consolidation=consolidation,
    )
    assert result.overall_feedback.headline == "Verdict"
    assert len(result.recommendations) == 1
    assert set(result.recommendations[0].related_categories) == {
        Category.CONTENT_TRAPS, Category.ECLAIRE,
    }


def test_aggregate_live_blocked_when_max_steps_exhausted() -> None:
    """Even without explicit phrase hits or loops, hitting max_steps
    without the agent emitting `done` triggers the block sentinel."""
    ev = _evidence(is_done=False, n_steps=10, max_steps=10)
    reviews = [
        CategoryReview(
            category=Category.LOGICAL, score=80.0, findings=[],
            summary="", model="m", duration_seconds=0.0,
        )
    ]
    result = aggregate_live(
        ev, reviews, analysis_id="x", model="m", consolidation=None,
    )
    assert result.completed is False
    assert result.bot_completion_likelihood <= 49.0


# ---------------------------------------------------------------------------
# render_live_html
# ---------------------------------------------------------------------------


def test_render_live_html_smoke() -> None:
    """End-to-end render: produce a SurveyAnalysisResult and confirm the
    HTML contains the headline and step markers."""
    ev = _evidence(blocked_phrase_hits=["validation error"])
    reviews = [
        CategoryReview(
            category=p.category, score=80.0, findings=[],
            summary="reviewer summary",
            model="m", duration_seconds=0.0,
        )
        for p in LIVE_PROMPTS
    ]
    result = aggregate_live(
        ev, reviews, analysis_id="abc",
        model="gpt-4o-mini", consolidation=None,
    )
    # Evidence is folded onto the result by aggregate_live; no separate arg.
    assert result.evidence is not None
    html = render_live_html(result)
    assert "<!DOCTYPE html>" in html
    assert "Live runtime review" in html
    assert "step:1" in html  # at least one step rendered
    assert "validation error" in html  # block sentinel banner

    # Calling without evidence raises a clear error rather than producing
    # a half-baked report.
    import pytest
    from surveyshield.models.survey_result import SurveyAnalysisResult

    bare = SurveyAnalysisResult(**result.model_dump(exclude={"evidence"}))
    with pytest.raises(ValueError, match="evidence"):
        render_live_html(bare)


# ---------------------------------------------------------------------------
# review_run (high-level facade)
# ---------------------------------------------------------------------------


def test_review_run_filters_by_categories() -> None:
    """When `categories=` is provided, only those prompts are run."""
    ev = _evidence()

    out = LiveCategoryOutput(score=70.0, findings=[], summary="ok")

    with patch("surveyshield.live.reviewer._make_llm", return_value=_StubLLM(out)):
        result, _ = asyncio.run(
            review_run(
                ev, analysis_id="x", model="m",
                categories=["logical", "content-traps"],
            )
        )

    assert {c.category for c in result.categories} == {
        Category.LOGICAL, Category.CONTENT_TRAPS,
    }
