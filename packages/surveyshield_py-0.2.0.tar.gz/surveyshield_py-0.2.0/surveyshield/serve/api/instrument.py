"""Instrument-review API endpoints.

POST /review accepts a Qualtrics QSF, fans out the static review pipeline
on FastAPI's BackgroundTasks, and stores the result for later retrieval.
The status / results / report / delete endpoints are wired by the
shared ``attach_job_endpoints`` factory; the FIFO storage is in
``review_store``.
"""

import logging
import uuid
from typing import Optional

from fastapi import APIRouter, BackgroundTasks, File, Form, HTTPException, Request, UploadFile

from surveyshield.models.instrument_review import InstrumentReview
from surveyshield.review.parser import QSFParseError
from surveyshield.review.reviewer import render_html, review_qsf
from surveyshield.serve._jobs import JobStore, attach_job_endpoints
from surveyshield.serve.limits import INSTRUMENT_LIMIT, limiter

router = APIRouter()
logger = logging.getLogger(__name__)

review_store = JobStore(max_retained=100)


async def _run_review_task(
    review_id: str,
    raw: bytes,
    filename: str,
    model_name: str,
    category_names: Optional[list[str]],
) -> None:
    try:
        review_store.record_status(review_id, "running")
        result, _parsed = await review_qsf(
            raw,
            model=model_name,
            categories=category_names,
            filename=filename,
            review_id=review_id,
        )
        review_store.record_result(review_id, result.model_dump(mode="json"))
        review_store.record_status(review_id, "completed")

    except QSFParseError as e:
        logger.warning("QSF parse failed: review=%s err=%s", review_id, e)
        review_store.record_status(review_id, "failed")
        review_store.record_result(
            review_id,
            {"error": str(e), "error_type": "QSFParseError", "completed": False},
        )
    except Exception as e:  # noqa: BLE001
        logger.exception("review failed: review=%s", review_id)
        review_store.record_status(review_id, "failed")
        review_store.record_result(
            review_id,
            {"error": str(e), "error_type": type(e).__name__, "completed": False},
        )


@router.post("/review")
@limiter.limit(INSTRUMENT_LIMIT)
async def submit_instrument_review(
    request: Request,
    background_tasks: BackgroundTasks,
    file: UploadFile = File(..., description="Qualtrics QSF export"),
    model_name: str = Form("gpt-4o-mini"),
    categories: Optional[str] = Form(
        None, description="Comma-separated category ids; omit for all."
    ),
):
    """Upload a QSF and start a static review."""
    raw = await file.read()
    if not raw:
        raise HTTPException(status_code=400, detail="empty upload")

    review_id = str(uuid.uuid4())
    review_store.record_status(review_id, "queued")

    cat_names = (
        [n.strip() for n in categories.split(",") if n.strip()]
        if categories
        else None
    )

    background_tasks.add_task(
        _run_review_task,
        review_id,
        raw,
        file.filename or "upload.qsf",
        model_name,
        cat_names,
    )

    return {
        "review_id": review_id,
        "status": "queued",
        "message": "Review started. Poll /status/{id} until completed.",
        "estimated_time": "30-90 seconds",
    }


def _instrument_download_filename(review: InstrumentReview) -> str:
    """``<filename>_review.html`` (the .qsf suffix stripped)."""
    stem = review.filename
    if stem.lower().endswith(".qsf"):
        stem = stem[:-4]
    return f"{stem or 'survey'}_review.html"


attach_job_endpoints(
    router,
    job_label="review",
    job_id_key="review_id",
    store=review_store,
    result_model=InstrumentReview,
    render_html=render_html,
    download_filename=_instrument_download_filename,
)


@router.get("/health")
async def health_check():
    from surveyshield.categories import CATEGORIES

    return {
        "status": "healthy",
        "service": "Survey Shield Instrument Review",
        "version": "1.0.0",
        "categories": [c.id.value for c in CATEGORIES],
    }
