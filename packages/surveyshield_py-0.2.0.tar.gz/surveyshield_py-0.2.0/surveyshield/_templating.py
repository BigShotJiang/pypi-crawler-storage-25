"""Cached Jinja2 ``Environment`` per template directory.

Both reviewer modules render self-contained HTML reports via Jinja2 and
both want the same configuration (autoescape on for HTML). They differ
only in the tool-specific template directory.

The Environment is configured with a ``ChoiceLoader`` so child templates
can ``{% include "_styles.css" %}`` / ``{% import "_macros.html" as ui %}``
from the shared ``surveyshield/templates/`` directory in addition to
their tool-local templates.
"""

from functools import lru_cache
from pathlib import Path

from jinja2 import ChoiceLoader, Environment, FileSystemLoader, select_autoescape

_SHARED_TEMPLATE_DIR = Path(__file__).resolve().parent / "templates"


@lru_cache(maxsize=8)
def env_for(template_dir: Path) -> Environment:
    return Environment(
        loader=ChoiceLoader([
            FileSystemLoader(str(template_dir)),
            FileSystemLoader(str(_SHARED_TEMPLATE_DIR)),
        ]),
        autoescape=select_autoescape(["html"]),
        auto_reload=False,
    )
