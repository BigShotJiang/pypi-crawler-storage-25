"""Shared 8-category bot-resistance rubric used by both the static-review and
live-runtime tools.

The taxonomy is the eight-category framework from the Polarization Research
Lab's Daneel project (americaspoliticalpulse.com/ai/how-daneel-works), which
in turn builds on Westwood et al. (PNAS 2025). The same eight categories
apply to both Survey Shield tools — they just consume different evidence
bases:

- The static review asks "is this category's defense *implemented* in the
  QSF?" — signal is question text plus the per-question ``embedded_html``
  Qualtrics block (where authors wire keystroke-tracking JS, reCAPTCHA
  widgets, weather-API checks, etc.).

- The live runtime asks "did this category's defense *work* during the
  actual browser-use run?" — signal is the agent's per-step reasoning,
  todo, and final result.

Per-tool prompt templates live alongside the tool that consumes them
(see ``surveyshield/review/category_prompts.py`` and
``surveyshield/live/category_prompts.py``); this module is plain data so
both subsystems can import it without circular dependencies.
"""

from enum import Enum
from typing import Dict, List

from pydantic import BaseModel


class Category(str, Enum):
    """The eight-category bot-resistance rubric. The string values match the
    Daneel framework's category ids so research-side data lines up cleanly."""

    LOGICAL = "logical"
    VISUAL = "visual"
    CONTENT_TRAPS = "content-traps"
    OPEN_ENDS = "open-ends"
    MOUSE_KEYBOARD = "mouse-keyboard"
    BEHAVIORAL = "behavioral"
    LOCAL_AWARENESS = "local-awareness"
    ECLAIRE = "eclaire"


class CategoryMeta(BaseModel):
    """Cross-tool metadata for one category. Per-tool prompt templates live
    in ``surveyshield/review/category_prompts.py`` and
    ``surveyshield/live/category_prompts.py``."""

    id: Category
    name: str  # display name (e.g., "Visual Reasoning")
    description: str  # one-line summary used in HTML reports + methods
    weight: float = 1.0  # weight in the defense-score blend
    completion_weight: float = 0.5  # weight in the bot-completion-likelihood blend


CATEGORY_RUBRIC_VERSION = "v2-daneel-2026-05"

CATEGORIES: List[CategoryMeta] = [
    CategoryMeta(
        id=Category.LOGICAL,
        name="Logic",
        description=(
            "Reasoning items where humans show specific error patterns AI "
            "doesn't replicate — Cognitive Reflection Test, Sally-Anne "
            "theory-of-mind tasks, syllogisms, impossible-event probes."
        ),
    ),
    CategoryMeta(
        id=Category.VISUAL,
        name="Visual Reasoning",
        description=(
            "Information only available by actually rendering and seeing the "
            "page — image-based illusions (Ebbinghaus circles), counting "
            "elements in a picture, layout-perceptual traps."
        ),
    ),
    CategoryMeta(
        id=Category.CONTENT_TRAPS,
        name="Traps",
        description=(
            "Explicit traps embedded in instructions or markup that humans "
            "navigate but AI flags, refuses, or misses — \"I solemnly swear "
            "I am a human participant\" oaths, invisible-text instructions "
            "in black rectangles, instructional manipulation checks (IMCs)."
        ),
    ),
    CategoryMeta(
        id=Category.OPEN_ENDS,
        name="Open Ends",
        description=(
            "Open-text questions where AI's encyclopedic knowledge or "
            "verbatim recall betrays it — \"What is the first paragraph of "
            "the US Constitution? Don't search.\" — humans can't, AI can."
        ),
    ),
    CategoryMeta(
        id=Category.MOUSE_KEYBOARD,
        name="Mouse and Keyboard Input",
        description=(
            "Defenses that depend on physical input modalities — keystroke "
            "timing, click-target patterns, map clicks, drag-and-drop. In "
            "QSFs these usually live as embedded JavaScript on a question."
        ),
    ),
    CategoryMeta(
        id=Category.BEHAVIORAL,
        name="Behavioral",
        description=(
            "Client-side behavioral telemetry collected during the session "
            "— reCAPTCHA v3 score, IAT response latencies, total survey "
            "time, mouse/scroll trajectory analysis."
        ),
    ),
    CategoryMeta(
        id=Category.LOCAL_AWARENESS,
        name="Context Awareness",
        description=(
            "Verifiable real-world context probes — \"is it raining where "
            "you are?\" (graded against a weather API for the respondent's "
            "zipcode), local time, which recruitment platform was used."
        ),
    ),
    CategoryMeta(
        id=Category.ECLAIRE,
        name="ECLAIR",
        description=(
            "Refusal probes — questions safety-tuned LLMs systematically "
            "refuse but humans answer (e.g., descriptions of minor "
            "transgressions). Inverts the usual \"can the bot do it?\" "
            "framing: here the *refusal* is the bot signature."
        ),
    ),
]

CATEGORIES_BY_ID: Dict[Category, CategoryMeta] = {c.id: c for c in CATEGORIES}


def category_meta(category: Category) -> CategoryMeta:
    """Look up the metadata for a category. Raises KeyError on unknown."""
    return CATEGORIES_BY_ID[category]


def display_name(category: Category) -> str:
    """Return a category's display name; falls back to the enum value if
    the category isn't in ``CATEGORIES_BY_ID`` (defensive)."""
    meta = CATEGORIES_BY_ID.get(category)
    return meta.name if meta else category.value


__all__ = [
    "Category",
    "CategoryMeta",
    "CATEGORIES",
    "CATEGORIES_BY_ID",
    "CATEGORY_RUBRIC_VERSION",
    "category_meta",
    "display_name",
]
