"""Static-instrument reviewer.

Pure functions composed by the router's BackgroundTasks worker:

- ``review_dimension``: one LLM call with structured output, wrapped in a
  per-call timeout. Failures are captured in ``CategoryReview.error``
  rather than raised, so one stuck reviewer never poisons the whole review.
- ``run_review``: fan out reviewers via ``asyncio.gather`` under a
  semaphore. Renders the shared survey blob ONCE and prepends it to every
  prompt — identical prefix means OpenAI's automatic prompt cache hits
  across reviewers.
- ``aggregate``: pure compute — overall_score, completion_likelihood,
  recommendations, narrative summary. No LLM call.
- ``build_methods_statement``: pure compute — copy-paste-ready paragraph
  for researchers' Methods sections.
- ``render_html``: Jinja2 render of the report template.

State management (FIFO storage, status transitions) lives in the router.
"""

from __future__ import annotations

import asyncio
import logging
import os
import time
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from jinja2 import Template
from pydantic import BaseModel

from surveyshield._aggregation import (
    build_recommendations_from_findings,
    build_recommendations_from_reviews,
    weighted_mean,
)
from surveyshield._llm import make_llm as _make_llm  # patched in tests
from surveyshield._providers import provider_env_var
from surveyshield._templating import env_for
from surveyshield._text import drop_unverified_findings, normalize
from surveyshield.categories import (
    CATEGORIES_BY_ID,
    CATEGORY_RUBRIC_VERSION,
    Category,
    display_name as _category_display,
)
from surveyshield.models.instrument_review import (
    CategoryReview,
    Finding,
    InstrumentReview,
    OverallFeedback,
    ParsedSurvey,
    Recommendation,
    Severity,
)
from .dimensions import (
    DIMENSIONS,
    DIMENSIONS_BY_CATEGORY,
    DIMENSIONS_BY_NAME,
    Dimension,
    DimensionOutput,
)

logger = logging.getLogger(__name__)


# Survey Shield citation. Single source of truth — update once when the
# paper is finalized and every report picks it up.
SURVEY_SHIELD_CITATION = {
    "short": "Fernandez et al., 2026",
    "apa": (
        "Fernandez, K., Low, A., Bogard, J., & Fox, C. R. (2026). Survey "
        "Shield: Static review of online survey instruments for resistance "
        "to non-human responses. [Manuscript in preparation]."
    ),
    "bibtex": (
        "@misc{fernandez2026surveyshield,\n"
        "  author = {Fernandez, K. and Low, A. and Bogard, J. and Fox, C. R.},\n"
        "  title = {Survey Shield: Static review of online survey instruments "
        "for resistance to non-human responses},\n"
        "  year = {2026},\n"
        "  note = {Manuscript in preparation},\n"
        "}"
    ),
}


# ---------------------------------------------------------------------------
# Shared survey blob
# ---------------------------------------------------------------------------

# Rendered once per ``run_review`` and prepended to every reviewer's prompt.
# Identical prefix across reviewers = automatic prompt-cache hits on OpenAI.
_SURVEY_BLOB_TEMPLATE = Template(
    "Survey: {{ survey.name }}\n"
    "Description: {{ survey.description or '(none)' }}\n"
    "Total questions: {{ survey.questions|length }}\n"
    "Total blocks: {{ survey.blocks|length }}\n"
    "\n"
    "Questions:\n"
    "{% for q in survey.questions %}"
    "[{{ q.qid }} | type={{ q.type }}{% if q.subtype %}/{{ q.subtype }}{% endif %} | force_response={{ q.force_response }}{% if q.hidden %} | hidden{% endif %}]\n"
    "{{ q.text }}\n"
    "{% if q.choices %}choices: {{ q.choices|join(' | ') }}\n{% endif %}"
    "{% if q.embedded_html %}embedded: {{ q.embedded_html[:1500] }}\n{% endif %}"
    "{% endfor %}"
)


def _render_survey_blob(survey: ParsedSurvey) -> str:
    return _SURVEY_BLOB_TEMPLATE.render(survey=survey)


# ---------------------------------------------------------------------------
# Per-category LLM call
# ---------------------------------------------------------------------------


async def review_dimension(
    survey_blob: str,
    dim: Dimension,
    *,
    model: str,
    timeout: float = 60.0,
) -> CategoryReview:
    """Run one reviewer agent. Always returns a CategoryReview; failures
    are captured in ``.error`` rather than raised."""
    start = time.monotonic()
    # Survey blob first so the identical prefix triggers OpenAI's prompt
    # cache for second-and-beyond reviewers in the fan-out.
    prompt = f"{survey_blob}\n\n{dim.prompt_template}"

    try:
        llm = _make_llm(model).with_structured_output(dim.output_schema)
        result: DimensionOutput = await asyncio.wait_for(
            llm.ainvoke(prompt), timeout=timeout
        )
        score = max(0.0, min(100.0, float(result.score)))
        return CategoryReview(
            category=dim.category,
            score=score,
            findings=list(result.findings or []),
            summary=result.summary or "",
            model=model,
            duration_seconds=time.monotonic() - start,
        )
    except asyncio.TimeoutError:
        logger.warning(
            "reviewer timeout: category=%s timeout=%ss", dim.category.value, timeout
        )
        return CategoryReview(
            category=dim.category,
            score=0.0,
            findings=[],
            summary="(reviewer timed out)",
            model=model,
            duration_seconds=time.monotonic() - start,
            error=f"timeout after {timeout}s",
        )
    except Exception as e:  # noqa: BLE001 — failure capture is the point
        logger.exception("reviewer failed: category=%s", dim.category.value)
        return CategoryReview(
            category=dim.category,
            score=0.0,
            findings=[],
            summary="(reviewer failed)",
            model=model,
            duration_seconds=time.monotonic() - start,
            error=f"{type(e).__name__}: {e}",
        )


# ---------------------------------------------------------------------------
# Fan-out
# ---------------------------------------------------------------------------


# Categories whose defenses live exclusively in per-question embedded JS /
# Display Logic / Embedded Data. If a QSF has zero embedded_html across all
# questions, these reviewers are guaranteed to score 0 with a survey-level
# "no implementation" finding — short-circuit the LLM call.
_TELEMETRY_CATEGORIES = frozenset(
    {Category.MOUSE_KEYBOARD, Category.BEHAVIORAL, Category.LOCAL_AWARENESS}
)


def _synthesize_no_implementation_review(
    dim: Dimension, model: str
) -> CategoryReview:
    return CategoryReview(
        category=dim.category,
        score=0.0,
        findings=[],
        summary=(
            "No embedded JS, Display Logic, or Embedded Data surfaces in "
            "the QSF; this category's defense is not implemented."
        ),
        model=model,
        duration_seconds=0.0,
    )


async def run_review(
    survey: ParsedSurvey,
    dims: List[Dimension],
    *,
    model: str,
    max_concurrency: int = 6,
) -> Tuple[List[CategoryReview], str]:
    """Run all reviewers in parallel, semaphore-bounded.

    Returns ``(reviews, survey_blob)``. The blob is rendered once here and
    handed back so the orchestrator can also feed it to
    ``consolidate_and_summarize`` without a second render.
    """
    survey_blob = _render_survey_blob(survey)
    sem = asyncio.Semaphore(max_concurrency)

    async def _one(d: Dimension) -> CategoryReview:
        async with sem:
            return await review_dimension(survey_blob, d, model=model)

    has_embedded = any(q.embedded_html for q in survey.questions)
    if has_embedded:
        live_dims = list(dims)
        synthesized: List[CategoryReview] = []
    else:
        live_dims = [d for d in dims if d.category not in _TELEMETRY_CATEGORIES]
        synthesized = [
            _synthesize_no_implementation_review(d, model)
            for d in dims
            if d.category in _TELEMETRY_CATEGORIES
        ]

    reviews = await asyncio.gather(*(_one(d) for d in live_dims))
    return list(reviews) + synthesized, survey_blob


# ---------------------------------------------------------------------------
# Quote verification (post-fan-out, pre-aggregation)
# ---------------------------------------------------------------------------


def _build_question_haystacks(parsed: ParsedSurvey) -> Tuple[Dict[str, str], str]:
    """Pre-build the normalized haystacks once per review.

    Returns ``(per_question, survey_level)`` where ``per_question[qid]`` is
    the normalized concat of one question's text + description + choices,
    and ``survey_level`` is the normalized concat of survey
    name/description + every question's text + every choice.
    """
    per_question: Dict[str, str] = {}
    parts: List[str] = [parsed.name, parsed.description or ""]
    for q in parsed.questions:
        q_parts = [q.text, q.description or "", *q.choices]
        per_question[q.qid] = normalize(" \n ".join(p for p in q_parts if p))
        parts.append(q.text)
        parts.extend(q.choices)
    survey_level = normalize(" \n ".join(p for p in parts if p))
    return per_question, survey_level


def drop_unverified_quotes(
    reviews: List[CategoryReview], parsed: ParsedSurvey
) -> List[CategoryReview]:
    """Drop findings whose excerpt can't be located in the source survey."""
    per_question, survey_level = _build_question_haystacks(parsed)
    return drop_unverified_findings(reviews, per_question, survey_level, what="finding")


# ---------------------------------------------------------------------------
# Second-stage LLM call: consolidation + holistic feedback (one round trip)
# ---------------------------------------------------------------------------


class ConsolidationResult(BaseModel):
    """Output of the second-stage LLM call. Service-layer-only — not exposed
    on the public API; ``aggregate`` unpacks it into the InstrumentReview."""

    consolidated_findings: List[Finding] = []
    overall_feedback: OverallFeedback


_CONSOLIDATION_PROMPT_HEADER = (
    "You are consolidating per-category findings about a Qualtrics survey "
    "instrument's resistance to AI/bot respondents. SCOPE IS STRICTLY "
    "BOT-RESISTANCE: you are NOT a peer reviewer of the survey's substantive "
    "research, question wording, or methodology. Do not introduce findings "
    "or commentary about topic, theoretical framing, demographics, length, "
    "ordering, accessibility, or general writing quality.\n\n"
    "Two tasks, returned together:\n\n"
    "1) CONSOLIDATE FINDINGS. Merge findings from different categories that "
    "flag the same underlying bot-resistance problem. When you merge, "
    "preserve the most specific locator (QID), the strongest rationale, and "
    "the most concrete suggested_fix. List the source categories in "
    "`contributing_categories`. Do NOT invent new findings, do NOT change "
    "quoted excerpts, do NOT add general-survey-design critique, and do NOT "
    "drop a finding just because no other reviewer flagged it.\n\n"
    "2) OVERALL FEEDBACK. Write a focused bot-resistance assessment:\n"
    "  - `headline`: one sentence verdict about how well this instrument "
    "resists AI respondents (e.g., \"This instrument has limited defenses "
    "against AI respondents and would benefit from a small set of targeted "
    "additions.\").\n"
    "  - `paragraphs`: one or two short paragraphs synthesizing the "
    "strongest bot-resistance themes across categories, naming the most "
    "pressing concrete fixes, and acknowledging which defenses the "
    "instrument already has. Reference categories by display name. Do NOT "
    "comment on the survey's substantive design, wording quality, or "
    "methodology — those are out of scope.\n\n"
    "Be concise, direct, and grounded in what the reviewers actually found."
)


def _build_consolidation_prompt(
    survey_blob: str, reviews: List[CategoryReview]
) -> str:
    chunks: List[str] = [_CONSOLIDATION_PROMPT_HEADER, "", "SURVEY:", survey_blob, ""]
    for r in reviews:
        if r.error is not None:
            continue
        chunks.append(
            f"--- CATEGORY: {_category_display(r.category)} (score {r.score:.0f}/100) ---"
        )
        chunks.append(f"Summary: {r.summary}")
        if not r.findings:
            chunks.append("No findings.")
        else:
            for i, f in enumerate(r.findings, 1):
                qid = f.locator or "(survey-level)"
                chunks.append(
                    f"{i}. [{qid}] severity={f.severity.name} "
                    f"confidence={f.confidence:.2f} "
                    f"edit_kind={f.recommended_edit_kind.value}"
                )
                chunks.append(f"   excerpt: {f.excerpt}")
                chunks.append(f"   rationale: {f.rationale}")
                if f.suggested_fix:
                    chunks.append(f"   fix: {f.suggested_fix}")
        chunks.append("")
    return "\n".join(chunks)


async def consolidate_and_summarize(
    survey_blob: str,
    reviews: List[CategoryReview],
    *,
    model: str,
    timeout: float = 90.0,
) -> Optional[ConsolidationResult]:
    """Second-stage LLM call. Returns None on timeout/error so the pipeline
    can fall back to the pure-Python aggregation path.

    Takes the pre-rendered survey blob (rendered once by the orchestrator
    and reused across reviewer + consolidation calls). Timeout is 90s vs
    the per-reviewer 60s because consolidation has more context to chew on.
    """
    if not any(r.findings for r in reviews if r.error is None):
        return ConsolidationResult(
            consolidated_findings=[],
            overall_feedback=OverallFeedback(
                headline="No category surfaced specific findings.",
                paragraphs=[
                    "Reviewers completed without flagging any concrete issues. "
                    "See the per-category scores and narrative summary for the "
                    "high-level verdict."
                ],
            ),
        )

    prompt = _build_consolidation_prompt(survey_blob, reviews)

    try:
        llm = _make_llm(model).with_structured_output(ConsolidationResult)
        return await asyncio.wait_for(llm.ainvoke(prompt), timeout=timeout)
    except Exception as e:  # noqa: BLE001
        logger.exception("consolidate_and_summarize failed: %s", e)
        return None


# ---------------------------------------------------------------------------
# Aggregation (pure compute)
# ---------------------------------------------------------------------------


def aggregate(
    survey: ParsedSurvey,
    reviews: List[CategoryReview],
    *,
    review_id: str,
    filename: str,
    parsed_summary: Dict[str, Any],
    model: str,
    consolidation: Optional[ConsolidationResult] = None,
) -> InstrumentReview:
    """Combine per-category reviews into the final InstrumentReview.

    ``consolidation`` is the second-stage LLM output: when present, its
    ``consolidated_findings`` drive the recommendations list and its
    ``overall_feedback`` is stored verbatim. When absent (LLM error or no
    findings to consolidate), we fall back to per-category findings with a
    pure-Python ``(edit_kind, locator)`` dedup.
    """
    timestamp = datetime.now()
    successful = [r for r in reviews if r.error is None]

    overall_score = weighted_mean(
        [(r.score, _category_weight(r.category)) for r in successful]
    )

    # ``completion_likelihood`` measures how easy this survey is for an
    # automated agent to complete — runs OPPOSITE to defense score.
    completion_pairs = [
        (100.0 - r.score, _category_completion_weight(r.category))
        for r in successful
        if _category_completion_weight(r.category) > 0
    ]
    if completion_pairs:
        completion_likelihood = weighted_mean(completion_pairs)
    else:
        completion_likelihood = 100.0 - overall_score

    if consolidation is not None:
        recommendations = build_recommendations_from_findings(
            consolidation.consolidated_findings
        )
        overall_feedback = consolidation.overall_feedback
    else:
        recommendations = build_recommendations_from_reviews(reviews)
        overall_feedback = OverallFeedback(
            headline="(holistic feedback unavailable; see narrative summary)",
            paragraphs=[],
        )

    narrative = _build_narrative(
        survey, reviews, overall_score, completion_likelihood
    )
    parameters = {
        "model": model,
        "category_rubric_version": CATEGORY_RUBRIC_VERSION,
    }

    methods = _compose_methods_statement(
        review_id=review_id,
        timestamp=timestamp,
        successful_categories=[r.category for r in successful],
        overall_score=overall_score,
        completion_likelihood=completion_likelihood,
    )

    return InstrumentReview(
        review_id=review_id,
        filename=filename,
        timestamp=timestamp,
        overall_score=round(overall_score, 1),
        completion_likelihood=round(completion_likelihood, 1),
        parsed_summary=parsed_summary,
        categories=reviews,
        recommendations=recommendations,
        overall_feedback=overall_feedback,
        narrative_summary=narrative,
        methods_statement=methods,
        parameters=parameters,
        parsed_survey=survey,
    )


def _category_weight(category: Category) -> float:
    """Resolve weight from the static-review's `Dimension` registry first
    (which can override per-prompt) and fall back to the rubric default."""
    d = DIMENSIONS_BY_CATEGORY.get(category)
    if d is not None:
        return d.weight
    meta = CATEGORIES_BY_ID.get(category)
    return meta.weight if meta else 1.0


def _category_completion_weight(category: Category) -> float:
    d = DIMENSIONS_BY_CATEGORY.get(category)
    if d is not None:
        return d.completion_weight
    meta = CATEGORIES_BY_ID.get(category)
    return meta.completion_weight if meta else 0.0




def _build_narrative(
    survey: ParsedSurvey,
    reviews: List[CategoryReview],
    overall_score: float,
    completion_likelihood: float,
) -> str:
    """Compose a prose paragraph from structured findings, no LLM call."""
    n = len(survey.questions)
    lines: List[str] = []
    lines.append(
        f"This instrument has {n} question{'s' if n != 1 else ''} across "
        f"{len(survey.blocks)} block{'s' if len(survey.blocks) != 1 else ''}. "
        f"Reviewed across {len(reviews)} categor{'ies' if len(reviews) != 1 else 'y'}, "
        f"the overall defense score is {overall_score:.0f}/100 and the "
        f"estimated completion-likelihood for an automated agent is "
        f"{completion_likelihood:.0f}/100."
    )

    failed = [r for r in reviews if r.error is not None]
    if failed:
        names = ", ".join(_category_display(r.category) for r in failed)
        lines.append(
            f"\nNote: the following categories did not complete and were "
            f"weighted at zero in the overall score: {names}."
        )

    successful = [r for r in reviews if r.error is None]
    if successful:
        ranked = sorted(successful, key=lambda r: r.score)
        weakest = ranked[0]
        strongest = ranked[-1]
        if weakest.category != strongest.category:
            lines.append(
                f"\nThe weakest category is **{_category_display(weakest.category)}** "
                f"({weakest.score:.0f}/100). The strongest is "
                f"**{_category_display(strongest.category)}** "
                f"({strongest.score:.0f}/100)."
            )

    finding_counts = Counter(
        f.severity.name for r in successful for f in r.findings
    )
    if finding_counts:
        parts = [
            f"{finding_counts[s]} {s.lower()}"
            for s in ("HIGH", "MED", "LOW")
            if finding_counts[s]
        ]
        lines.append("\nFindings: " + ", ".join(parts) + ".")

    return " ".join(lines).strip()


def _compose_methods_statement(
    *,
    review_id: str,
    timestamp: datetime,
    successful_categories: List[Category],
    overall_score: float,
    completion_likelihood: float,
) -> str:
    cat_names = [_category_display(c) for c in successful_categories]
    cat_list = ", ".join(cat_names) or "none"
    return (
        f"We evaluated this instrument for resistance to non-human responses "
        f"using Survey Shield ({SURVEY_SHIELD_CITATION['short']}), "
        f"reviewing it across {len(cat_names)} categor"
        f"{'ies' if len(cat_names) != 1 else 'y'}: {cat_list}. The instrument "
        f"received an overall defense score of {overall_score:.0f}/100 "
        f"and an estimated completion-likelihood for automated agents of "
        f"{completion_likelihood:.0f}/100. Review ID: {review_id} "
        f"({timestamp.strftime('%Y-%m-%d')})."
    )


def build_methods_statement(review: InstrumentReview) -> str:
    """Re-derive the methods statement from a stored review (used by tests
    and by callers that want the string without re-running aggregation)."""
    successful = [c.category for c in review.categories if c.error is None]
    return _compose_methods_statement(
        review_id=review.review_id,
        timestamp=review.timestamp,
        successful_categories=successful,
        overall_score=review.overall_score,
        completion_likelihood=review.completion_likelihood,
    )


# ---------------------------------------------------------------------------
# HTML rendering
# ---------------------------------------------------------------------------


# Templates live at surveyshield/review/templates/. The ``__file__``-relative
# path works for both editable and built-wheel installs because pyproject.toml
# lists ``review/templates/*.html`` as package_data.
_TEMPLATE_DIR = Path(__file__).resolve().parent / "templates"


def render_html(review: InstrumentReview) -> str:
    """Render the instrument-review HTML report. Self-contained Jinja2 template.

    Reads the parsed survey from ``review.parsed_survey`` (populated by
    ``aggregate()``); raises if it's missing.
    """
    survey = review.parsed_survey
    if survey is None:
        raise ValueError(
            "render_html requires review.parsed_survey; populate it via "
            "aggregate() before rendering."
        )
    template = env_for(_TEMPLATE_DIR).get_template("instrument_report.html")
    findings_by_qid: Dict[str, List[Tuple[str, Finding]]] = defaultdict(list)
    for c in review.categories:
        if c.error is not None:
            continue
        for f in c.findings:
            if f.locator:
                findings_by_qid[f.locator].append((_category_display(c.category), f))
    return template.render(
        review=review,
        survey=survey,
        findings_by_qid=findings_by_qid,
        citation=SURVEY_SHIELD_CITATION,
        category_display=_category_display,
    )


# ---------------------------------------------------------------------------
# High-level facade for library users
# ---------------------------------------------------------------------------


def _resolve_qsf_input(
    qsf: "str | bytes | os.PathLike[str]",
    filename: Optional[str],
) -> Tuple[bytes, str]:
    """Accept a path, bytes, or JSON string; return ``(raw, filename)``."""
    if isinstance(qsf, bytes):
        return qsf, filename or "upload.qsf"
    if isinstance(qsf, str):
        try:
            path = Path(qsf)
            return path.read_bytes(), filename or path.name
        except (OSError, ValueError):
            return qsf.encode(), filename or "upload.qsf"
    path = Path(os.fspath(qsf))
    return path.read_bytes(), filename or path.name


async def review_qsf(
    qsf: "str | bytes | os.PathLike[str]",
    *,
    model: str = "gpt-4o-mini",
    api_key: Optional[str] = None,
    categories: Optional[List[str]] = None,
    filename: Optional[str] = None,
    review_id: Optional[str] = None,
) -> Tuple[InstrumentReview, ParsedSurvey]:
    """One-call entry point for the static review pipeline.

    Accepts a path-like, raw bytes, or a JSON string; runs parse →
    fan-out → quote-verification → consolidation → aggregate, and returns
    the ``(InstrumentReview, ParsedSurvey)`` pair so callers can render
    HTML or JSON without re-parsing.

    ``api_key`` is written into the right env var for ``model``. ``review_id``
    lets callers (e.g., the FastAPI router) preserve a queued ID. ``categories``
    is a list of category ids (e.g., ``["logical", "content-traps"]``) or the
    legacy display names (``["Logic", "Traps"]``); omit to run all.
    """
    import uuid

    from .parser import parse_qsf, summarize

    if api_key:
        os.environ[provider_env_var(model)] = api_key

    raw, resolved_filename = _resolve_qsf_input(qsf, filename)
    parsed, _raw_dict = parse_qsf(raw)

    if categories:
        dims = [DIMENSIONS_BY_NAME[n] for n in categories if n in DIMENSIONS_BY_NAME]
        if not dims:
            raise ValueError(
                f"no valid categories selected. Known: {sorted(set(DIMENSIONS_BY_NAME))}"
            )
    else:
        dims = DIMENSIONS

    reviews, survey_blob = await run_review(parsed, dims, model=model)
    reviews = drop_unverified_quotes(reviews, parsed)
    consolidation = await consolidate_and_summarize(survey_blob, reviews, model=model)
    review = aggregate(
        parsed,
        reviews,
        review_id=review_id or str(uuid.uuid4()),
        filename=resolved_filename,
        parsed_summary=summarize(parsed),
        model=model,
        consolidation=consolidation,
    )
    return review, parsed
