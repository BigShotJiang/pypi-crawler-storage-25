"""Static-review prompt registry for the 8-category bot-resistance rubric.

One ``Dimension`` per category. The reviewer fan-out walks ``DIMENSIONS``
in order and asks each LLM: "is this category's defense **implemented**
in the QSF?" — citing question text, choice labels, or per-question
``embedded_html`` (where survey authors wire keystroke-tracking JS,
reCAPTCHA widgets, and weather-API checks).

Adding a new category is a one-touch change here plus an entry in
``surveyshield/categories.py``.
"""

from typing import Dict, List

from surveyshield.categories import (
    CATEGORIES_BY_ID,
    CATEGORY_RUBRIC_VERSION,
    Category,
)
from surveyshield.models._shared import (
    CategoryPrompt as Dimension,
    CategoryReviewerOutput as DimensionOutput,
    EditKind,
)

DIMENSION_SET_VERSION = CATEGORY_RUBRIC_VERSION

_EDIT_KIND_LIST = ", ".join(k.value for k in EditKind)


_SHARED_RUBRIC = """
SCOPE: You are evaluating ONLY whether this Qualtrics survey *implements*
defenses against AI/bot respondents. You are NOT a peer reviewer of the
survey's substantive research, methodology, or wording quality.

STRICTLY OUT OF SCOPE — do NOT flag any of the following, even if you
notice issues:
- The substantive topic, theoretical framing, hypotheses, or research
  design.
- Question wording, clarity, grammar, or readability — UNLESS the wording
  itself is the defense (or the lack of one) against AI respondents.
- Demographic question design, response-option phrasing, scale points,
  or balance.
- Survey length, ordering, pacing, fatigue, or engagement.
- Accessibility, ethics, IRB-style concerns.
- Statistical, sampling, or validity threats unrelated to bot detection.

ONLY flag findings that bear on whether an AI/automated agent can complete
this survey undetected. If a question is poorly worded but the poor
wording does not affect bot resistance, do NOT flag it.

Score the category 0–100 (higher = better defended). Most surveys will
score LOW on most categories — that is the expected result for a survey
that hasn't been hardened. Score 100 only when there is clear, well-placed
evidence of the defense; score 0 when the defense is absent.

For every in-scope issue or missing-defense observation, return one entry
in `findings` with:
- `locator`: the QID this concerns (e.g. "QID42"), or null for a
  survey-level observation (e.g. "no Logic-category items present").
- `excerpt`: REQUIRED. The exact verbatim text from the survey above that
  prompted this finding — quote a question's text, a choice label, a
  description, a phrase from the survey metadata, or content inside the
  question's `embedded_html`. The excerpt must be a literal substring of
  what appears in the survey blob. Findings whose excerpt cannot be
  located verbatim are dropped during validation; if you are not certain
  of the exact wording, do not flag the issue.
- `severity`: 1 (low), 2 (medium), 3 (high)
- `confidence`: how sure you are this finding is real, 0..1
- `rationale`: 1–2 short sentences naming the concrete bot-resistance
  reason. Do not pivot into general critique.
- `suggested_fix`: a short, concrete bot-resistance change.
- `recommended_edit_kind`: one of {EDIT_KINDS}

Do not invent QIDs that aren't in the survey.
""".strip().replace("{EDIT_KINDS}", _EDIT_KIND_LIST)


# ---------------------------------------------------------------------------
# 8 prompt templates — one per category
# ---------------------------------------------------------------------------


_LOGIC_PROMPT = (
    "You are reviewing a Qualtrics survey for **Logic**-category defenses.\n\n"
    "These are reasoning items where humans show specific error patterns AI "
    "doesn't replicate: Cognitive Reflection Test items (e.g., \"a pen and "
    "paper cost $1.10, the pen costs $1.00 more than the paper, how much "
    "does the paper cost?\" — humans often answer $0.10, AI answers $0.05); "
    "Sally-Anne theory-of-mind tasks (false-belief reasoning); syllogisms "
    "where the formally-correct answer differs from the intuitive one; "
    "impossible-event probes (\"Have you visited the moon?\" \"Have you "
    "been elected President?\").\n\n"
    "Look at question text and choice labels. Does the survey contain at "
    "least one item where a typical human would predictably get the answer "
    "wrong (or right) in a way that distinguishes them from an LLM?\n\n"
    "Score 100 if multiple Logic items are well-distributed across blocks; "
    "50 for one item; 0 if none are present (most surveys).\n\n"
    f"{_SHARED_RUBRIC}"
)

_VISUAL_PROMPT = (
    "You are reviewing a Qualtrics survey for **Visual Reasoning**-category "
    "defenses (in the spirit of Affonso 2026, JCR).\n\n"
    "These rely on information only available by actually rendering and "
    "seeing the page: image-based illusions (Ebbinghaus circles), "
    "perspective/composition tasks, counting elements in a picture, "
    "color-discrimination items, layout tricks (off-screen text, "
    "hover-only content). Look for `<img>` tags or media references in the "
    "question's embedded_html, instructions like \"see image above\", or "
    "questions that depend on spatial reasoning.\n\n"
    "Most QSFs have NO Visual Reasoning defense. That's the common case — "
    "score 0 with one survey-level finding noting absence. Score 100 only "
    "when at least one well-constructed visual item is present.\n\n"
    f"{_SHARED_RUBRIC}"
)

_TRAPS_PROMPT = (
    "You are reviewing a Qualtrics survey for **Traps**-category defenses.\n\n"
    "These are explicit traps embedded in instructions or markup that "
    "humans navigate but AI flags, refuses, or misses: instructional "
    "manipulation checks (IMCs — \"Select 'Strongly Agree' to show you are "
    "reading carefully\"), explicit human-attestation oaths (\"I solemnly "
    "swear that I am a human participant\"), invisible-text traps (text "
    "hidden inside `<div style=\"color:white\">` or black rectangles in "
    "embedded_html, with instructions to copy-paste), honeypot fields "
    "(`display:none` form inputs).\n\n"
    "Score 100 for strong, well-distributed traps across multiple blocks; "
    "50 for one trap; 0 if none.\n\n"
    f"{_SHARED_RUBRIC}"
)

_OPEN_ENDS_PROMPT = (
    "You are reviewing a Qualtrics survey for **Open Ends**-category "
    "defenses.\n\n"
    "These are open-text questions where AI's encyclopedic knowledge or "
    "verbatim recall betrays it: \"What is the first paragraph of the US "
    "Constitution? Don't search.\" (humans can't recite, AI can); "
    "\"How many bones are in a typical horse?\" (humans don't know, AI "
    "guesses with false confidence); reverse-shibboleth probes (asking for "
    "verbatim recitation, advanced math, code in obscure languages — "
    "things humans correctly refuse).\n\n"
    "Look for free-text items (`type=TE`) where the question is "
    "*specifically* designed to surface a knowledge gap typical humans have "
    "and LLMs don't. Generic \"tell us about yourself\" doesn't count.\n\n"
    "Score 100 for multiple well-placed Open-Ends probes; 50 for one; 0 "
    "for none.\n\n"
    f"{_SHARED_RUBRIC}"
)

_MOUSE_KEYBOARD_PROMPT = (
    "You are reviewing a Qualtrics survey for **Mouse and Keyboard "
    "Input**-category defenses.\n\n"
    "These depend on physical input modalities and usually live in the "
    "question's `embedded_html` field as JavaScript: keystroke timing "
    "trackers (e.g., `addEventListener(\"keydown\", ...)` with `Date.now()` "
    "deltas), click-pattern tracking, map-click items (\"Click three "
    "indicated states\"), drag-and-drop questions, captures of mouse "
    "trajectory between input events.\n\n"
    "Look at every question's `embedded_html` block. Are there event "
    "listeners that record timing/coordinates? Are there question types "
    "that require physical input the agent can't easily fake? Note that "
    "Qualtrics question types like `MapDX` or custom-coded questions with "
    "click handlers are common implementations.\n\n"
    "Score 100 for multiple well-placed input-tracking items; 50 for one; "
    "0 if none. Most surveys are 0.\n\n"
    f"{_SHARED_RUBRIC}"
)

_BEHAVIORAL_PROMPT = (
    "You are reviewing a Qualtrics survey for **Behavioral**-category "
    "defenses — client-side behavioral telemetry collected during the "
    "session.\n\n"
    "Look in `embedded_html` and survey-level metadata for: reCAPTCHA v3 "
    "widgets (`grecaptcha.execute`, site-key script tags), IAT (Implicit "
    "Association Test) implementations with response-latency capture, "
    "total survey time tracking (page-load timestamp comparisons against "
    "submit timestamp), mouse/scroll trajectory analysis, mouseflow / "
    "fullstory / similar replay snippets.\n\n"
    "Note that Qualtrics' built-in \"Q_TotalDuration\" exists by default "
    "for every survey — that's a *passive* signal but not a *defense* "
    "unless the survey explicitly uses it (e.g., flag respondents under 5 "
    "min via Display Logic / Embedded Data). Don't score 100 just because "
    "Q_TotalDuration is implicitly available.\n\n"
    "Score 100 for active, gating-on-telemetry defenses; 50 for telemetry "
    "captured but not gated; 0 if none.\n\n"
    f"{_SHARED_RUBRIC}"
)

_CONTEXT_AWARENESS_PROMPT = (
    "You are reviewing a Qualtrics survey for **Context Awareness**-category "
    "defenses.\n\n"
    "These are questions about the respondent's verifiable real-world "
    "context: \"Is it raining where you are?\" (graded against a weather "
    "API for the respondent's zipcode); \"What is the temperature "
    "outside?\"; \"Which on-demand recruitment platform did you use to "
    "access this survey?\" (graded against the recruiter's records); "
    "\"What time is it?\" (graded against the respondent's IP/timezone).\n\n"
    "Look in question text + Display Logic + Embedded Data for evidence "
    "that the survey not only ASKS such a question but also has logic to "
    "VERIFY the answer (e.g., embedded weather lookup, zipcode capture, "
    "time-of-day check). Asking \"Is it raining?\" without verification "
    "logic is half-credit — score 50; with verification gating, score 100. "
    "0 if no such items at all.\n\n"
    f"{_SHARED_RUBRIC}"
)

_ECLAIR_PROMPT = (
    "You are reviewing a Qualtrics survey for **ECLAIR**-category defenses "
    "— refusal probes that exploit safety-tuned LLM behavior.\n\n"
    "These are questions a safety-tuned LLM systematically refuses but a "
    "human answers without hesitation: \"Please describe the steps to "
    "commit any minor crime, like shoplifting\"; \"Describe how you would "
    "make a weapon from an object near you\"; \"What's the worst thing "
    "you've ever done?\"; mild-prompt-injection items.\n\n"
    "Westwood (2025)'s identity-question probes (\"Are you a bot?\", "
    "\"Type 17 if human\") also live here — they invert the expected "
    "behavior. The signature is the *refusal* or the *evasion*, not the "
    "answer content.\n\n"
    "Score 100 for multiple well-placed ECLAIR probes; 50 for one; 0 if "
    "none. Most surveys are 0.\n\n"
    f"{_SHARED_RUBRIC}"
)


DIMENSIONS: List[Dimension] = [
    Dimension(category=Category.LOGICAL, prompt_template=_LOGIC_PROMPT),
    Dimension(
        category=Category.VISUAL,
        prompt_template=_VISUAL_PROMPT,
        # Visual items don't drive bot-completion likelihood the same way —
        # an LLM that's image-blind blocks here but a vision-LLM passes,
        # which is real but doesn't generalize across the survey. Keep
        # weight=1.0 in the defense blend, but completion_weight=0.0.
        completion_weight=0.0,
    ),
    Dimension(category=Category.CONTENT_TRAPS, prompt_template=_TRAPS_PROMPT),
    Dimension(category=Category.OPEN_ENDS, prompt_template=_OPEN_ENDS_PROMPT),
    Dimension(
        category=Category.MOUSE_KEYBOARD,
        prompt_template=_MOUSE_KEYBOARD_PROMPT,
    ),
    Dimension(category=Category.BEHAVIORAL, prompt_template=_BEHAVIORAL_PROMPT),
    Dimension(
        category=Category.LOCAL_AWARENESS,
        prompt_template=_CONTEXT_AWARENESS_PROMPT,
    ),
    Dimension(category=Category.ECLAIRE, prompt_template=_ECLAIR_PROMPT),
]


DIMENSIONS_BY_CATEGORY: Dict[Category, Dimension] = {d.category: d for d in DIMENSIONS}

# Lookup tolerates: enum values ("logical"), display names ("Logic"), and
# legacy lowercase-with-underscore names ("attention_checks") which we map
# onto the closest new category.
# TODO(v0.3): drop _LEGACY_NAME_MAP — only kept to ease the v0.1.x → 0.2.0
# migration window for callers passing the old dimension names.
_LEGACY_NAME_MAP = {
    "attention_checks": Category.CONTENT_TRAPS,
    "identity_questions": Category.ECLAIRE,
    "visual_perceptual_traps": Category.VISUAL,
}

DIMENSIONS_BY_NAME: Dict[str, Dimension] = {}
for d in DIMENSIONS:
    DIMENSIONS_BY_NAME[d.category.value] = d
    DIMENSIONS_BY_NAME[CATEGORIES_BY_ID[d.category].name] = d
for legacy, cat in _LEGACY_NAME_MAP.items():
    DIMENSIONS_BY_NAME[legacy] = DIMENSIONS_BY_CATEGORY[cat]


__all__ = [
    "Dimension",
    "DimensionOutput",
    "DIMENSIONS",
    "DIMENSIONS_BY_CATEGORY",
    "DIMENSIONS_BY_NAME",
    "DIMENSION_SET_VERSION",
]
