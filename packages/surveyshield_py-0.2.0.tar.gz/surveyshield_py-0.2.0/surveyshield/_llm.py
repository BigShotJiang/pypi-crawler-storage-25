"""Shared LLM-client factory used by the static-review and live-runtime
reviewers.

Both subsystems route by ``model`` prefix (``gemini*`` → Google,
everything else → OpenAI) and want langchain's ``with_structured_output``
shape. Constructing the langchain client does non-trivial work (httpx
setup, validators), so we cache; both reviewers calling
``make_llm("gpt-4o-mini")`` share one client.
"""

import os
from functools import lru_cache

from surveyshield._providers import provider_env_var


@lru_cache(maxsize=8)
def make_llm(model_name: str):
    """Return a langchain chat client appropriate for ``model_name``."""
    env_var = provider_env_var(model_name)
    if not os.getenv(env_var):
        raise RuntimeError(f"{env_var} not set; required for model {model_name!r}.")

    if env_var == "GOOGLE_API_KEY":
        try:
            from langchain_google_genai import ChatGoogleGenerativeAI
        except ImportError as e:
            raise RuntimeError(
                "Gemini reviewer requested but langchain-google-genai isn't installed."
            ) from e
        return ChatGoogleGenerativeAI(model=model_name)

    from langchain_openai import ChatOpenAI

    return ChatOpenAI(model=model_name)
