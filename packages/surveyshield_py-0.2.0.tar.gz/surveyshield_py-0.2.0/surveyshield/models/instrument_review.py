"""Pydantic models for the static-instrument-review tool.

Per-category schemas (``Severity``, ``EditKind``, ``Finding``,
``CategoryReview``, ``OverallFeedback``, ``Recommendation``) live in
``surveyshield.models._shared`` and are re-exported from here so callers
can import either path. Static-review-specific aggregates
(``InstrumentReview``, the parsed-survey shapes) live below.
"""

from datetime import datetime
from typing import Any, Dict, List, Optional

from pydantic import BaseModel

from surveyshield.models._shared import (
    CategoryReview,
    EditKind,
    Finding,
    OverallFeedback,
    Recommendation,
    Severity,
)

__all__ = [
    "Severity",
    "EditKind",
    "Finding",
    "CategoryReview",
    "OverallFeedback",
    "Recommendation",
    "InstrumentReview",
    "InstrumentReviewRequest",
    "ParsedQuestion",
    "ParsedBlock",
    "ParsedSurvey",
]


class ParsedQuestion(BaseModel):
    """Subset of a QSF SurveyElement (Element=SQ) that reviewers consume."""

    qid: str
    type: str
    subtype: Optional[str] = None
    text: str
    description: Optional[str] = None
    choices: List[str] = []
    display_logic: Optional[Dict[str, Any]] = None
    validation: Optional[Dict[str, Any]] = None
    force_response: bool = False
    hidden: bool = False
    embedded_html: Optional[str] = None


class ParsedBlock(BaseModel):
    block_id: str
    description: str
    question_ids: List[str] = []


class ParsedSurvey(BaseModel):
    """Typed view over a QSF file. Reviewers see only this — never the raw
    dict — so the prompt surface is deterministic. The raw dict is held
    alongside (in the service layer) for the modified-QSF feature."""

    name: str
    description: Optional[str] = None
    blocks: List[ParsedBlock] = []
    questions: List[ParsedQuestion] = []
    flow: List[Dict[str, Any]] = []


class InstrumentReview(BaseModel):
    """Top-level review result returned by the API.

    The parsed survey rides along on ``parsed_survey`` so the HTML report
    (and any downstream consumer) has one authoritative source. JSON
    consumers who only want scores can drop it via
    ``review.model_dump(exclude={'parsed_survey'})``.
    """

    review_id: str
    filename: str
    timestamp: datetime
    overall_score: float
    completion_likelihood: float
    parsed_summary: Dict[str, Any]
    categories: List[CategoryReview]
    recommendations: List[Recommendation]
    overall_feedback: OverallFeedback
    narrative_summary: str
    methods_statement: str
    parameters: Dict[str, Any]
    parsed_survey: Optional[ParsedSurvey] = None


class InstrumentReviewRequest(BaseModel):
    """Body for `POST /api/v1/instrument/review`. The QSF file itself is a
    multipart upload; this captures the optional form fields."""

    model_name: str = "gpt-4o-mini"
    categories: Optional[List[str]] = None
