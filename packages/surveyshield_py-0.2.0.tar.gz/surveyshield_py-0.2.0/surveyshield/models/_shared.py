"""Pydantic models shared by the static-review and live-runtime tools.

Both pipelines fan out to per-category reviewers, drop unverified excerpts,
consolidate, and aggregate. The schemas they emit are the same shape — only
the *evidence base* differs (parsed QSF vs agent run history). This module
holds those shared schemas; tool-specific aggregates live in their respective
``models/`` files.

Locator convention
==================

``Finding.locator`` is the evidence pointer. Two formats are canonical:

- ``"QID42"`` — a Qualtrics question id from the static review (any
  string starting ``"QID"`` and otherwise matching the survey's ids).
- ``"step:17"`` — the live runtime's reference to step #17 of the
  agent's ``AgentHistoryList``.

A null locator means the finding is *survey-/run-level* (no per-item
attribution). Static-review code uses the QID string directly (so
``locator="QID42"``); live-runtime code uses the ``step_locator`` helper
to format step indices. Consumers that need to branch can inspect
``Finding.locator_kind`` (``"qid" | "step" | None``). The verifier in
``surveyshield/_text.py`` drops findings whose locator fails to
resolve, so malformed values become a logged drop rather than a hard
crash.
"""

import warnings
from enum import Enum
from typing import List, Literal, Optional, Type

from pydantic import BaseModel

from surveyshield.categories import Category


def step_locator(index: int) -> str:
    """Return the canonical live-runtime locator for a run step index."""
    return f"step:{index}"


class Severity(int, Enum):
    LOW = 1
    MED = 2
    HIGH = 3


class EditKind(str, Enum):
    """Coarse hint at what kind of survey modification would resolve a finding."""

    NONE = "none"
    ADD_ATTENTION_CHECK = "add_attention_check"
    ADD_IDENTITY_QUESTION = "add_identity_question"
    ADD_IMPOSSIBLE_EVENT = "add_impossible_event"
    ADD_VISUAL_TRAP = "add_visual_trap"
    ADD_OPEN_END_PROBE = "add_open_end_probe"
    ADD_BEHAVIORAL_TELEMETRY = "add_behavioral_telemetry"
    ADD_CONTEXT_PROBE = "add_context_probe"
    ADD_ECLAIR_PROBE = "add_eclair_probe"
    ENABLE_FORCE_RESPONSE = "enable_force_response"
    ADD_DISPLAY_LOGIC = "add_display_logic"
    REMOVE_QUESTION = "remove_question"
    EDIT_QUESTION_TEXT = "edit_question_text"
    REORDER_OR_RANDOMIZE = "reorder_or_randomize"
    OTHER = "other"


class Finding(BaseModel):
    """A single issue surfaced by a per-category reviewer.

    Every finding cites a verbatim ``excerpt`` from the underlying evidence —
    a question/choice for static review, an agent step for live runtime — so
    by the time a Finding reaches the consumer it is grounded in real data
    (the verification pass drops fabricated quotes before consolidation).

    ``locator`` is the evidence pointer; see the module-level "Locator
    convention" docstring.
    """

    locator: Optional[str] = None
    excerpt: str
    severity: Severity
    confidence: float
    rationale: str
    suggested_fix: Optional[str] = None
    recommended_edit_kind: EditKind = EditKind.NONE
    contributing_categories: List[Category] = []

    @property
    def locator_kind(self) -> Optional[Literal["qid", "step"]]:
        """Infer the locator format. Returns ``None`` for survey-/run-level
        findings or for unrecognized formats (the verifier will drop those
        before they reach a consumer)."""
        if not self.locator:
            return None
        if self.locator.startswith("step:"):
            return "step"
        if self.locator.startswith("QID"):
            return "qid"
        return None

    @property
    def question_id(self) -> Optional[str]:
        # TODO(v0.3): drop. Renamed to `locator` in v0.2.0; alias kept for
        # one minor release to ease the v0.1.x → v0.2.0 transition.
        warnings.warn(
            "Finding.question_id is deprecated; use Finding.locator instead. "
            "The alias will be removed in v0.3.0.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.locator


class CategoryReview(BaseModel):
    """One reviewer agent's verdict for one category.

    ``score`` is 0–100, higher = stronger defense (the survey resists the
    bot for this category). Failures during the LLM call are captured in
    ``error`` rather than raised so a single stuck reviewer doesn't poison
    the whole review.
    """

    category: Category
    score: float
    findings: List[Finding] = []
    summary: str
    model: str
    duration_seconds: float
    error: Optional[str] = None


class Recommendation(BaseModel):
    title: str
    detail: str
    priority: int
    related_categories: List[Category] = []


class OverallFeedback(BaseModel):
    """LLM-written holistic peer-review-style assessment.

    Produced by the second-stage ``consolidate_and_summarize`` call. If
    that call errors, the aggregator falls back to a synthesized headline
    pointing readers at the deterministic narrative summary.
    """

    headline: str
    paragraphs: List[str] = []


class CategoryReviewerOutput(BaseModel):
    """Structured-output schema reviewers populate per category.

    Shared by both the static reviewer (``surveyshield.review.dimensions``)
    and the live reviewer (``surveyshield.live.category_prompts``)."""

    score: float
    findings: List[Finding] = []
    summary: str


class CategoryPrompt(BaseModel):
    """One per-category prompt entry.

    Each tool registers its own list of these (the static review's
    ``DIMENSIONS`` and the live runtime's ``LIVE_PROMPTS``). The
    ``output_schema`` lets a category override the default reviewer output
    if it ever needs more structured fields, but in practice both tools
    use the shared ``CategoryReviewerOutput``.
    """

    category: Category
    weight: float = 1.0
    completion_weight: float = 0.5
    prompt_template: str
    output_schema: Type[BaseModel] = CategoryReviewerOutput

    model_config = {"arbitrary_types_allowed": True}
