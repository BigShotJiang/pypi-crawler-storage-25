"""Survey Shield — review of online survey instruments for AI-bot resistance.

Two surfaces, both organized around the same eight bot-resistance categories
(Logic, Visual Reasoning, Traps, Open Ends, Mouse and Keyboard Input,
Behavioral, Context Awareness, ECLAIR — see
``surveyshield.categories.CATEGORIES``):

- ``review_qsf`` / ``render_html`` — always available; the static-review
  pipeline runs server-side with no browser, just an LLM provider key.
- ``take_survey`` — gated on the ``[live]`` extra. Drives a real Chromium
  through a Qualtrics URL via browser-use. ``pip install surveyshield-py[live]``
  pulls the deps; without them, ``take_survey`` resolves to ``None``.
"""

from surveyshield._version import __version__

# Shared rubric.
from surveyshield.categories import (
    CATEGORIES,
    CATEGORIES_BY_ID,
    CATEGORY_RUBRIC_VERSION,
    Category,
    CategoryMeta,
)

# Static review — always available.
from surveyshield.review.reviewer import (
    SURVEY_SHIELD_CITATION,
    aggregate,
    consolidate_and_summarize,
    drop_unverified_quotes,
    render_html,
    review_qsf,
    run_review,
)
from surveyshield.review.parser import QSFParseError, parse_qsf, summarize
from surveyshield.review.dimensions import (
    DIMENSIONS,
    DIMENSIONS_BY_CATEGORY,
    DIMENSIONS_BY_NAME,
    DIMENSION_SET_VERSION,
    Dimension,
    DimensionOutput,
)
from surveyshield.models.instrument_review import (
    CategoryReview,
    EditKind,
    Finding,
    InstrumentReview,
    OverallFeedback,
    ParsedBlock,
    ParsedQuestion,
    ParsedSurvey,
    Recommendation,
    Severity,
)


# Live runtime — optional. Importing surveyshield.live triggers a
# browser-use import; the [live] extra is what makes that succeed.
try:
    from surveyshield.live import take_survey  # noqa: F401
except ImportError:
    take_survey = None  # type: ignore[assignment]


__all__ = [
    "__version__",
    # high-level facades
    "review_qsf",
    "render_html",
    "take_survey",
    # pipeline seams (advanced users)
    "parse_qsf",
    "summarize",
    "run_review",
    "drop_unverified_quotes",
    "consolidate_and_summarize",
    "aggregate",
    "QSFParseError",
    # category registry
    "Category",
    "CategoryMeta",
    "CATEGORIES",
    "CATEGORIES_BY_ID",
    "CATEGORY_RUBRIC_VERSION",
    # static-review dimension shim (transitional)
    "DIMENSIONS",
    "DIMENSIONS_BY_CATEGORY",
    "DIMENSIONS_BY_NAME",
    "DIMENSION_SET_VERSION",
    "Dimension",
    "DimensionOutput",
    # models
    "InstrumentReview",
    "CategoryReview",
    "Finding",
    "OverallFeedback",
    "Recommendation",
    "ParsedSurvey",
    "ParsedBlock",
    "ParsedQuestion",
    "Severity",
    "EditKind",
    # citation
    "SURVEY_SHIELD_CITATION",
]
