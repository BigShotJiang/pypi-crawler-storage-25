"""Translate a browser-use ``AgentHistoryList`` into structured
``LiveRunEvidence`` that the per-category reviewers can consume.

The agent's per-step reasoning (``evaluation_previous_goal`` /
``memory`` / ``next_goal``), URL trace, and final result are the richest
signals of what actually happened during a run. This module preserves
that structure so reviewers can cite specific steps verbatim.
"""

from __future__ import annotations

import re
from datetime import datetime
from typing import TYPE_CHECKING, Any, List, Optional, Tuple
from urllib.parse import urlparse

from surveyshield.models.survey_result import LiveRunEvidence, LiveRunStep

if TYPE_CHECKING:  # pragma: no cover — browser-use is optional at type-check
    from browser_use.agent.views import AgentHistoryList


# Canonical "the survey caught the agent" phrases. Used as a deterministic
# sanity check on the LLM's verdict in ``_detect_agent_blocked``, not as
# the primary detection path. Each phrase is paired with a one-line note
# explaining why it's canonical so future contributors know what they're
# looking at and tests can probe the right scenarios.
#
# Patterns are joined into one anchored regex with word boundaries so
# substrings like "we did not pay attention to demographics" don't false-
# positive on the standalone phrase "did not pay attention".
_BLOCK_PHRASES: List[Tuple[str, str]] = [
    ("validation error", "Qualtrics' default screen-out + attention-check rejection text"),
    ("did not pay attention", "Standard IMC failure message"),
    ("failed attention check", "Explicit IMC-failure copy used by Cloud Research / Prolific"),
    ("instructional manipulation", "Direct reference to an IMC; agent is reading the failure UI"),
    ("you have been flagged", "Survey-side detection notice"),
    ("captcha failed", "reCAPTCHA challenge failed mid-survey"),
    ("not a robot", "reCAPTCHA / human-attestation block"),
    ("we cannot verify", "Identity / context-awareness verification failure"),
    ("respondent ineligible", "Screening logic returned ineligible"),
    ("screen out", "Generic screen-out language"),
    ("screened out", "Past-tense variant"),
]


_BLOCK_PHRASE_RE = re.compile(
    r"\b(?:" + "|".join(re.escape(p) for p, _ in _BLOCK_PHRASES) + r")\b",
    re.IGNORECASE,
)


def _safe_get(obj: Any, *path: str, default: Any = None) -> Any:
    """Walk an attribute chain, returning ``default`` if any step yields
    ``None`` or ``AttributeError``. Tolerates browser-use schema drift."""
    for attr in path:
        if obj is None:
            return default
        obj = getattr(obj, attr, None)
    return default if obj is None else obj


def _step_actions(step: Any) -> List[str]:
    """Best-effort short summaries of the step's ``ActionResult`` items."""
    results = _safe_get(step, "result", default=[]) or []
    out: List[str] = []
    for r in results:
        if isinstance(r, str):
            out.append(r[:200])
            continue
        # browser-use ActionResult has .extracted_content and .error
        ext = _safe_get(r, "extracted_content")
        err = _safe_get(r, "error")
        if err:
            out.append(f"error: {str(err)[:200]}")
        elif ext:
            out.append(str(ext)[:200])
    return out


def _step_url(step: Any) -> Optional[str]:
    return _safe_get(step, "state", "url") or _safe_get(step, "url")


def _step_page_title(step: Any) -> Optional[str]:
    return _safe_get(step, "state", "title") or _safe_get(step, "page_title")


def _step_extracted(step: Any) -> Optional[str]:
    """Concat any extracted-content strings on the step's results."""
    results = _safe_get(step, "result", default=[]) or []
    chunks = []
    for r in results:
        ext = _safe_get(r, "extracted_content")
        if ext:
            chunks.append(str(ext))
    if not chunks:
        return None
    return "\n".join(chunks)[:4000]  # cap per-step to keep evidence size reasonable


def _step_to_run_step(index: int, raw: Any) -> LiveRunStep:
    """Pull the fields we care about off one ``AgentHistory``-shaped step."""
    state = _safe_get(raw, "model_output", "current_state")
    return LiveRunStep(
        index=index,
        evaluation_previous_goal=_safe_get(state, "evaluation_previous_goal"),
        memory=_safe_get(state, "memory"),
        next_goal=_safe_get(state, "next_goal"),
        actions=_step_actions(raw),
        url=_step_url(raw),
        page_title=_step_page_title(raw),
        extracted_content=_step_extracted(raw),
    )


def _detect_block_signals(steps: List[LiveRunStep]) -> List[str]:
    """Scan structured step text for canonical block phrases.

    Used as a pure-Python sanity check the aggregator can compare to the
    LLM's holistic verdict — not the primary detection path. Returns the
    deduped, lowercased phrase strings (in source-order) that matched.
    """
    haystack_chunks: List[str] = []
    for s in steps:
        for piece in (
            s.evaluation_previous_goal,
            s.memory,
            s.next_goal,
            s.extracted_content,
        ):
            if piece:
                haystack_chunks.append(piece)
    haystack = " | ".join(haystack_chunks)
    matches = {m.group(0).lower() for m in _BLOCK_PHRASE_RE.finditer(haystack)}
    # Preserve source-list order so report output is deterministic.
    return [p for p, _ in _BLOCK_PHRASES if p in matches]


_GOAL_LOOP_THRESHOLD = 5


def _detect_loop_step(steps: List[LiveRunStep]) -> Optional[int]:
    """Return the step index where the same ``next_goal`` first repeats
    ``_GOAL_LOOP_THRESHOLD`` times in a row (a strong signal the agent got
    stuck), or ``None`` if no looping pattern is detected."""
    norm = re.compile(r"\s+")
    streak_value: Optional[str] = None
    streak_start: Optional[int] = None
    streak_len = 0
    for s in steps:
        if not s.next_goal:
            streak_value = None
            streak_len = 0
            continue
        normalized = norm.sub(" ", s.next_goal.strip().lower())[:200]
        if normalized == streak_value:
            streak_len += 1
            if streak_len >= _GOAL_LOOP_THRESHOLD and streak_start is not None:
                return streak_start
        else:
            streak_value = normalized
            streak_start = s.index
            streak_len = 1
    return None


def collect_run_evidence(
    history: "AgentHistoryList",
    *,
    survey_url: str,
    started_at: datetime,
    finished_at: datetime,
    model_name: str,
    max_steps: int,
) -> LiveRunEvidence:
    """Build a ``LiveRunEvidence`` from a browser-use run.

    Tolerant of the browser-use schema drifting between releases — every
    field walks via ``_safe_get`` and falls back to ``None`` rather than
    raising AttributeError.
    """
    raw_steps = list(getattr(history, "history", []) or [])
    steps = [_step_to_run_step(i + 1, s) for i, s in enumerate(raw_steps)]

    final_result_method = getattr(history, "final_result", None)
    final_result = final_result_method() if callable(final_result_method) else ""
    final_result = (final_result or "").strip()

    is_done_method = getattr(history, "is_done", None)
    is_done = is_done_method() if callable(is_done_method) else False

    domain = urlparse(survey_url).netloc or survey_url

    return LiveRunEvidence(
        survey_url=survey_url,
        survey_domain=domain,
        started_at=started_at,
        finished_at=finished_at,
        model_name=model_name,
        max_steps=max_steps,
        steps=steps,
        final_result=final_result,
        todo_md=None,  # see surveyshield/live/analyzer.py for tmp-dir scraping (out of scope here)
        is_done=is_done,
        blocked_phrase_hits=_detect_block_signals(steps),
        looped_at_step=_detect_loop_step(steps),
    )


def render_evidence_blob(evidence: LiveRunEvidence) -> str:
    """One-line-per-fact rendering passed to per-category reviewers as
    the prefix prompt. Same idea as ``_render_survey_blob`` for static
    reviews — identical prefix across reviewers triggers prompt-cache hits.
    """
    lines: List[str] = [
        f"Survey URL: {evidence.survey_url}",
        f"Survey domain: {evidence.survey_domain}",
        f"Model: {evidence.model_name}   max_steps: {evidence.max_steps}",
        f"Run started: {evidence.started_at.isoformat()}",
        f"Run finished: {evidence.finished_at.isoformat()}",
        f"Agent emitted `done`: {evidence.is_done}",
    ]
    if evidence.blocked_phrase_hits:
        lines.append(
            "Block-phrase hits (deterministic scan): "
            + ", ".join(repr(p) for p in evidence.blocked_phrase_hits)
        )
    if evidence.looped_at_step is not None:
        lines.append(
            f"Goal-loop sentinel: agent's next_goal first repeated "
            f"{_GOAL_LOOP_THRESHOLD}+ times in a row at step "
            f"{evidence.looped_at_step}."
        )
    if evidence.final_result:
        lines.append("")
        lines.append("Final agent result:")
        lines.append(evidence.final_result[:2000])
    lines.append("")
    lines.append("Steps:")
    norm_re = re.compile(r"\s+")
    last_goal_norm: Optional[str] = None
    repeat_run_start: Optional[int] = None
    repeat_run_count = 0
    elide_threshold = _GOAL_LOOP_THRESHOLD  # tolerate up to this before eliding

    def _flush_elision() -> None:
        nonlocal repeat_run_start, repeat_run_count
        if repeat_run_count > elide_threshold and repeat_run_start is not None:
            elided = repeat_run_count - elide_threshold
            lines.append(
                f"... [{elided} consecutive steps with the same next_goal "
                f"elided; first appears at step:{repeat_run_start}] ..."
            )
        repeat_run_start = None
        repeat_run_count = 0

    for s in evidence.steps:
        # Compress consecutive steps with the same `next_goal`: emit the
        # first ``elide_threshold`` verbatim, summarize the rest, then
        # resume verbatim once the goal changes.
        cur_goal = (
            norm_re.sub(" ", s.next_goal.strip().lower())[:200]
            if s.next_goal else None
        )
        if cur_goal is not None and cur_goal == last_goal_norm:
            repeat_run_count += 1
            if repeat_run_count > elide_threshold:
                continue  # accumulate; emit a single elision line at the end of the run
        else:
            _flush_elision()
            last_goal_norm = cur_goal
            repeat_run_start = s.index
            repeat_run_count = 1

        lines.append(f"--- step:{s.index} ---")
        if s.url:
            lines.append(f"  url: {s.url}")
        if s.page_title:
            lines.append(f"  page_title: {s.page_title}")
        if s.evaluation_previous_goal:
            lines.append(f"  eval_prev: {s.evaluation_previous_goal[:600]}")
        if s.memory:
            lines.append(f"  memory: {s.memory[:600]}")
        if s.next_goal:
            lines.append(f"  next_goal: {s.next_goal[:600]}")
        for a in s.actions:
            lines.append(f"  action: {a[:300]}")
        if s.extracted_content:
            lines.append(f"  extracted: {s.extracted_content[:400]}")
    _flush_elision()
    return "\n".join(lines)


__all__ = [
    "collect_run_evidence",
    "render_evidence_blob",
]
