"""Recommendation building + weighted-mean helpers shared by both
reviewer pipelines.

The static review and live runtime aggregate per-category findings into
a ranked recommendation list with the same shape: severity*confidence
ordering, capped output, priority sort. Only the data source differs
(parsed-survey reviews vs run-history reviews), so the helpers live here
and both reviewer modules import them.
"""

from __future__ import annotations

from typing import Dict, List, Optional, Sequence, Tuple

from surveyshield.categories import Category, display_name
from surveyshield.models._shared import (
    CategoryReview,
    Finding,
    Recommendation,
    Severity,
)


REC_CAP = 8


def weighted_mean(pairs: Sequence[Tuple[float, float]]) -> float:
    total_weight = sum(w for _, w in pairs)
    if total_weight <= 0:
        return 0.0
    return sum(v * w for v, w in pairs) / total_weight


def priority_for(severity: Severity) -> int:
    return {Severity.HIGH: 1, Severity.MED: 2, Severity.LOW: 3}.get(severity, 3)


def recommendation_title(finding: Finding, category: Optional[Category]) -> str:
    label = display_name(category) if category else "consolidated"
    if finding.locator:
        return f"[{label}] {finding.locator}: {finding.rationale[:80]}"
    return f"[{label}] {finding.rationale[:80]}"


def finalize_recommendations(
    items: List[Tuple[Finding, List[Category]]],
) -> List[Recommendation]:
    """Rank ``(finding, related_categories)`` pairs by severity*confidence,
    cap at ``REC_CAP``, build Recommendations, sort by priority."""
    items.sort(
        key=lambda pair: -(float(pair[0].severity) * float(pair[0].confidence))
    )
    out: List[Recommendation] = []
    for finding, related in items[:REC_CAP]:
        title_cat = related[0] if related else None
        out.append(
            Recommendation(
                title=recommendation_title(finding, title_cat),
                detail=finding.suggested_fix or finding.rationale,
                priority=priority_for(finding.severity),
                related_categories=related,
            )
        )
    out.sort(key=lambda r: r.priority)
    return out


def build_recommendations_from_reviews(
    reviews: Sequence[CategoryReview],
) -> List[Recommendation]:
    """Fallback path used when consolidation failed: pure-Python dedup by
    ``(recommended_edit_kind, locator)``. Two findings flagging the same
    fix on different locators both surface."""
    seen: Dict[Tuple[str, Optional[str]], List[Category]] = {}
    items: List[Tuple[Finding, List[Category]]] = []
    for r in reviews:
        if r.error is not None:
            continue
        for f in r.findings:
            kind = f.recommended_edit_kind.value
            key = (kind, f.locator)
            if kind != "none" and key in seen:
                related = seen[key]
                if r.category not in related:
                    related.append(r.category)
                continue
            related = [r.category]
            if kind != "none":
                seen[key] = related
            items.append((f, related))
    return finalize_recommendations(items)


def build_recommendations_from_findings(
    findings: Sequence[Finding],
) -> List[Recommendation]:
    """Happy path: consolidation already merged duplicates semantically."""
    return finalize_recommendations(
        [(f, list(f.contributing_categories)) for f in findings]
    )
