import attr
from terra_classic_sdk.core import Dec
from terra_classic_sdk.util.json import JSONSerializable

__all__ = ["Params", "Rate"]

@attr.s
class Params(JSONSerializable):
    max_zero: Dec = attr.ib()
    slope_base: Dec = attr.ib()
    slope_vp_impact: Dec = attr.ib()
    cap: Dec = attr.ib()

    @classmethod
    def from_data(cls, data: dict) -> "Params":
        return cls(
            max_zero=Dec(data["max_zero"]),
            slope_base=Dec(data["slope_base"]),
            slope_vp_impact=Dec(data["slope_vp_impact"]),
            cap=Dec(data["cap"]),
        )

    def to_data(self) -> dict:
        return {
            "max_zero": str(self.max_zero),
            "slope_base": str(self.slope_base),
            "slope_vp_impact": str(self.slope_vp_impact),
            "cap": str(self.cap),
        }

@attr.s
class Rate(JSONSerializable):
    rate: Dec = attr.ib()
    target: Dec = attr.ib()

    @classmethod
    def from_data(cls, data: dict) -> "Rate":
        return cls(
            rate=Dec(data["rate"]),
            target=Dec(data["target"]),
        )

    def to_data(self) -> dict:
        return {
            "rate": str(self.rate),
            "target": str(self.target),
        }
