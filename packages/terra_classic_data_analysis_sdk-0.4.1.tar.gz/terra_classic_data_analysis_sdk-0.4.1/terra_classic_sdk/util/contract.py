"""Useful contract-related functions."""

import base64
from typing import Dict, List, Union

from terra_classic_sdk.core import AccAddress
from terra_classic_sdk.core.auth import TxInfo
from terra_classic_sdk.core.broadcast import BlockTxBroadcastResult

__all__ = [
    "read_file_as_b64",
    "get_code_id",
    "get_contract_address",
    "get_contract_events",
]


def read_file_as_b64(path: Union[str, bytes, int]) -> str:
    """Reads a file's contents as binary bytes and encodes it in a base64-string.

    Args:
        path (Union[str, bytes, int]): binary file path

    Returns:
        str: file's bytes in base64-encoded string
    """
    with open(path, "rb") as contract_file:
        contract_bytes = base64.b64encode(contract_file.read()).decode()
        return contract_bytes


def get_code_id(
    tx_result: Union[BlockTxBroadcastResult, TxInfo], msg_index: int = 0
) -> str:
    """Utility function for extracting the code id from a ``MsgStoreCode`` message.

    Args:
        tx_result (BlockTxBroadcastResult): broadcast result
        msg_index (int, optional): index of ``MsgStoreCode`` inside tx. Defaults to 0.

    Returns:
        str: extracted code id
    """
    if tx_result.logs:
        code_id = tx_result.logs[msg_index].events_by_type["store_code"]["code_id"][0]
        return code_id
    elif hasattr(tx_result, 'events_by_type') and tx_result.events_by_type and "store_code" in tx_result.events_by_type:
        code_id = tx_result.events_by_type["store_code"]["code_id"][0]
        return code_id
    else:
        raise ValueError("could not parse code id -- tx logs and events are empty or do not contain store_code event.")


def get_contract_address(
    tx_result: Union[BlockTxBroadcastResult, TxInfo], msg_index: int = 0
) -> AccAddress:
    """Utility function for extracting the contract address from a ``MsgInstantiateContract``
    message.

    Args:
        tx_result (BlockTxBroadcastResult): broadcast result
        msg_index (int, optional): index of ``MsgInstantiateContract`` inside tx. Defaults to 0.

    Returns:
        str: extracted contract address
    """
    if tx_result.logs:
        # The event type can be 'instantiate_contract' or just 'instantiate'
        event_type = "instantiate_contract"
        if event_type not in tx_result.logs[msg_index].events_by_type:
            event_type = "instantiate"
        
        # The attribute key can be 'contract_address' or '_contract_address'
        key = "contract_address"
        if key not in tx_result.logs[msg_index].events_by_type[event_type]:
            key = "_contract_address"
            
        contract_address = tx_result.logs[msg_index].events_by_type[event_type][key][0]
        return AccAddress(contract_address)
    elif hasattr(tx_result, 'events_by_type') and tx_result.events_by_type:
        event_type = "instantiate_contract"
        if event_type not in tx_result.events_by_type:
            event_type = "instantiate"

        if event_type in tx_result.events_by_type:
            key = "contract_address"
            if key not in tx_result.events_by_type[event_type]:
                key = "_contract_address"
            
            if key in tx_result.events_by_type[event_type]:
                contract_address = tx_result.events_by_type[event_type][key][0]
                return AccAddress(contract_address)

    raise ValueError("could not parse contract address -- tx logs and events are empty or do not contain instantiate_contract event.")


def get_contract_events(
    tx_result: Union[BlockTxBroadcastResult, TxInfo], msg_index: int = 0
) -> List[Dict[str, str]]:
    if tx_result.logs:
        contract_events = []
        for event in tx_result.logs[msg_index].events:
            if event["type"] == "from_contract":
                event_data: Dict[str, str] = {}
                current_contract_address = event["attributes"][0]["value"]
                for att in event["attributes"]:
                    if (
                        att["key"] == "contract_address"
                        and current_contract_address != att["value"]
                    ):
                        contract_events.append(event_data)
                        event_data = {}
                        current_contract_address = att["value"]
                    event_data[att["key"]] = att["value"]
                contract_events.append(event_data)  # append remaining
                return contract_events
        raise ValueError("could not find event type 'from_contract' in logs")
    else:
        raise ValueError("could not parse contract events -- tx logs are empty.")
