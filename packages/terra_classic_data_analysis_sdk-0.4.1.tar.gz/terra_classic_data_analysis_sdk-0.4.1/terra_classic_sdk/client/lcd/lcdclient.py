from __future__ import annotations

from asyncio import AbstractEventLoop, get_event_loop
from json import JSONDecodeError
from typing import List, Optional, Union

import nest_asyncio
from aiohttp import ClientSession
import pandas as pd
from multidict import CIMultiDict

from terra_classic_sdk.core import Coins, Dec, Numeric
from terra_classic_sdk.exceptions import LCDResponseError
from terra_classic_sdk.key.key import Key
from terra_classic_sdk.util.json import dict_to_data
from terra_classic_sdk.util.url import urljoin

from .api.auth import AsyncAuthAPI, AuthAPI
from .api.authz import AsyncAuthzAPI, AuthzAPI
from .api.bank import AsyncBankAPI, BankAPI
from .api.distribution import AsyncDistributionAPI, DistributionAPI
from .api.dyncomm import AsyncDyncommAPI, DyncommAPI
from .api.feegrant import AsyncFeeGrantAPI, FeeGrantAPI
from .api.gov import AsyncGovAPI, GovAPI
from .api.ibc import AsyncIbcAPI, IbcAPI
from .api.ibc_transfer import AsyncIbcTransferAPI, IbcTransferAPI
from .api.market import AsyncMarketAPI, MarketAPI
from .api.mint import AsyncMintAPI, MintAPI
from .api.oracle import AsyncOracleAPI, OracleAPI
from .api.pool import AsyncPoolAPI, PoolAPI
from .api.slashing import AsyncSlashingAPI, SlashingAPI
from .api.staking import AsyncStakingAPI, StakingAPI
from .api.tendermint import AsyncTendermintAPI, TendermintAPI
from .api.treasury import AsyncTreasuryAPI, TreasuryAPI
from .api.tx import AsyncTxAPI, TxAPI
from .api.wasm import AsyncWasmAPI, WasmAPI
from .lcdutils import AsyncLCDUtils, LCDUtils
from .params import APIParams
from .wallet import AsyncWallet, Wallet

from .api.df.account import AsyncAccountAPI, AccountAPI
from .api.df.network import AsyncNetworkAPI, NetworkAPI
from .api.df.authz import AsyncAuthzAPI as AsyncAuthzDataAPI, AuthzAPI as AuthzDataAPI
from .api.df.stake import AsyncStakeAPI, StakeAPI
from .api.df.transfer import AsyncTransferAPI, TransferAPI
from .api.df.fees import AsyncFeesAPI, FeesAPI
from .api.df.burns import AsyncBurnsAPI, BurnsAPI
from .api.df.ibc import AsyncIbcAPI as AsyncIbcDataAPI, IbcAPI as IbcDataAPI
from .api.df.dex import AsyncDexAPI, DexAPI
from .api.df.gov import AsyncGovAPI as AsyncGovDataAPI, GovAPI as GovDataAPI
from .api.df.wasm import AsyncWasmAPI as AsyncWasmDataAPI, WasmAPI as WasmDataAPI
from .api.df.assets import AsyncAssetAPI as AsyncAssetAPI,AssetAPI as AssetAPI

class AsyncLCDClient:
    def __init__(
        self,
        url: str = "https://api-lunc-lcd.binodes.com",
        chain_id: Optional[str] = 'columbus-5',
        gas_prices: Optional[Coins.Input] = None,
        gas_adjustment: Optional[Numeric.Input] = None,
        loop: Optional[AbstractEventLoop] = None,
        _create_session: bool = True,  # don't create a session (used for sync LCDClient)
        df_url: str = "https://api.binodes.com",
        df_api_key: str = 'sk-78e5f4d3c2b1a09886543210fedcba66',
        df_coin: str = 'lunc',
        df_limit: int = 10000
    ):
        if loop is None:
            loop = get_event_loop()
        self.loop = loop
        if _create_session:
            self.session = ClientSession(
                headers={"Accept": "application/json"}, loop=self.loop
            )

        self.chain_id = chain_id
        self.url = url
        self.df_url = df_url
        self.df_api_key = df_api_key
        self.df_coin = df_coin
        self.df_limit = df_limit
        self.last_request_height = None

        default_price = Coins.from_str('28.325uluna')
        default_adjustment = 1.3
        self.gas_prices = Coins(gas_prices) if gas_prices else default_price
        self.gas_adjustment = gas_adjustment if gas_adjustment else default_adjustment

        self.auth = AsyncAuthAPI(self)
        self.bank = AsyncBankAPI(self)
        self.distribution = AsyncDistributionAPI(self)
        self.dyncomm = AsyncDyncommAPI(self)
        self.feegrant = AsyncFeeGrantAPI(self)
        self.gov = AsyncGovAPI(self)
        self.market = AsyncMarketAPI(self)
        self.mint = AsyncMintAPI(self)
        self.authz = AsyncAuthzAPI(self)
        self.oracle = AsyncOracleAPI(self)
        self.pool = PoolAPI(self)
        self.slashing = AsyncSlashingAPI(self)
        self.staking = AsyncStakingAPI(self)
        self.tendermint = AsyncTendermintAPI(self)
        self.treasury = AsyncTreasuryAPI(self)
        self.wasm = AsyncWasmAPI(self)
        self.ibc = AsyncIbcAPI(self)
        self.ibc_transfer = AsyncIbcTransferAPI(self)
        self.tx = AsyncTxAPI(self)
        self.utils = AsyncLCDUtils(self)

        self.df_account = AsyncAccountAPI(self)
        self.df_network = AsyncNetworkAPI(self)
        self.df_authz = AsyncAuthzDataAPI(self)
        self.df_stake = AsyncStakeAPI(self)
        self.df_transfer = AsyncTransferAPI(self)
        self.df_fees = AsyncFeesAPI(self)
        self.df_burns = AsyncBurnsAPI(self)
        self.df_ibc = AsyncIbcDataAPI(self)
        self.df_dex = AsyncDexAPI(self)
        self.df_gov = GovDataAPI(self)
        self.df_wasm = WasmDataAPI(self)
        self.df_assets = AsyncAssetAPI(self)

    def wallet(self, key: Key) -> AsyncWallet:
        return AsyncWallet(self, key)

    async def _get(
        self,
        endpoint: str,
        params: Optional[Union[APIParams, CIMultiDict, list, dict]] = None,
    ):
        if (
            params
            and hasattr(params, "to_dict")
            and callable(getattr(params, "to_dict"))
        ):
            params = params.to_dict()

        async with self.session.get(
            urljoin(self.url, endpoint), params=params
        ) as response:
            try:
                result = await response.json(content_type=None)
            except JSONDecodeError:
                raise LCDResponseError(message=str(response.reason), response=response)
            if not 200 <= response.status < 299:
                raise LCDResponseError(message=str(result), response=response)
        self.last_request_height = (
            result.get("height") if result else self.last_request_height
        )
        return result

    async def _post(
        self, endpoint: str, data: Optional[dict] = None
    ):
        async with self.session.post(
            urljoin(self.url, endpoint), json=data and dict_to_data(data)
        ) as response:
            try:
                result = await response.json(content_type=None)
            except JSONDecodeError:
                raise LCDResponseError(message=str(response.reason), response=response)
            if not 200 <= response.status < 299:
                raise LCDResponseError(message=result.get("message"), response=response)
        self.last_request_height = (
            result.get("height") if result else self.last_request_height
        )
        return result

    async def _get_df(
        self,
        endpoint: str,
        params: Optional[Union[APIParams, CIMultiDict, list, dict]] = None,
        parse_dates: Optional[List[str]] = None,
    ):
        if (
            params
            and hasattr(params, "to_dict")
            and callable(getattr(params, "to_dict"))
        ):
            params = params.to_dict()

        if params is None:
            params = {}
        else:
            params = params.copy()

        # Global limit protection
        if params.get('limit') is not None:
            params['limit'] = min(int(params['limit']), self.df_limit)

        # Global fields deal
        if params.get('fields') is not None and isinstance(params['fields'], list):
            params['fields'] = ','.join(params['fields'])

        # Filter out None values to let the API use its own defaults
        params = {k: v for k, v in params.items() if v is not None}

        params['coin'] = self.df_coin
        headers = {"x-api-key": self.df_api_key}

        async with self.session.get(
            urljoin(self.df_url, endpoint), params=params, headers=headers
        ) as response:
            try:
                result = await response.json(content_type=None)
            except JSONDecodeError:
                raise LCDResponseError(message=str(response.reason), response=response)
            if not 200 <= response.status < 299:
                raise LCDResponseError(message=str(result), response=response)
        
        data = result.get("data")
        if not data:
            return pd.DataFrame()
        
        df = pd.DataFrame(data)
        
        if parse_dates:
            for col in parse_dates:
                if col in df.columns:
                    df[col] = pd.to_datetime(df[col], errors='coerce')
        return df

    async def _post_df(
        self, endpoint: str, data: Optional[dict] = None, parse_dates: Optional[List[str]] = None
    ):
        if data is None:
            data = {}
        else:
            data = data.copy()

        # Global limit protection
        if data.get('limit') is not None:
            data['limit'] = min(int(data['limit']), self.df_limit)

        data['coin'] = self.df_coin
        headers = {"x-api-key": self.df_api_key}

        async with self.session.post(
            urljoin(self.df_url, endpoint), json=data and dict_to_data(data), headers=headers
        ) as response:
            try:
                result = await response.json(content_type=None)
            except JSONDecodeError:
                raise LCDResponseError(message=str(response.reason), response=response)
            if not 200 <= response.status < 299:
                raise LCDResponseError(message=result.get("message"), response=response)
        
        data = result.get("data")
        if not data:
            return pd.DataFrame()

        df = pd.DataFrame(data)

        if parse_dates:
            for col in parse_dates:
                if col in df.columns:
                    df[col] = pd.to_datetime(df[col], errors='coerce')
        return df

    async def _search(
        self,
        events: List[list],
        params: Optional[Union[APIParams, CIMultiDict, list, dict]] = None,
    ):
        actual_params = CIMultiDict()
        for event in events:
            if event[0] == "tx.height":
                actual_params.add("query", f"{event[0]}={event[1]}")
            else:
                actual_params.add("query", f"{event[0]}='{event[1]}'")
        if params:
            for p in params:
                actual_params.add(p, params[p])

        async with self.session.get(
            urljoin(self.url, "/cosmos/tx/v1beta1/txs"), params=actual_params
        ) as response:
            try:
                result = await response.json(content_type=None)
            except JSONDecodeError:
                raise LCDResponseError(message=str(response.reason), response=response)
            if not 200 <= response.status < 299:
                raise LCDResponseError(message=str(result), response=response)
        self.last_request_height = (
            result.get("height") if result else self.last_request_height
        )
        return result

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc, tb):
        await self.session.close()


class LCDClient(AsyncLCDClient):
    def __init__(self, *args, **kwargs):
        kwargs["_create_session"] = False
        kwargs["loop"] = nest_asyncio.apply(get_event_loop())
        super().__init__(*args, **kwargs)

        self.auth = AuthAPI(self)
        self.bank = BankAPI(self)
        self.distribution = DistributionAPI(self)
        self.dyncomm = DyncommAPI(self)
        self.gov = GovAPI(self)
        self.feegrant = FeeGrantAPI(self)
        self.market = MarketAPI(self)
        self.mint = MintAPI(self)
        self.authz = AuthzAPI(self)
        self.oracle = OracleAPI(self)
        self.pool = PoolAPI(self)
        self.slashing = SlashingAPI(self)
        self.staking = StakingAPI(self)
        self.tendermint = TendermintAPI(self)
        self.treasury = TreasuryAPI(self)
        self.wasm = WasmAPI(self)
        self.ibc = IbcAPI(self)
        self.ibc_transfer = IbcTransferAPI(self)
        self.tx = TxAPI(self)
        self.utils = LCDUtils(self)

        self.df_account = AccountAPI(self)
        self.df_network = NetworkAPI(self)
        self.df_authz = AuthzDataAPI(self)
        self.df_stake = StakeAPI(self)
        self.df_transfer = TransferAPI(self)
        self.df_fees = FeesAPI(self)
        self.df_burns = BurnsAPI(self)
        self.df_ibc = IbcDataAPI(self)
        self.df_dex = DexAPI(self)
        self.df_gov = GovDataAPI(self)
        self.df_wasm = WasmDataAPI(self)
        self.df_assets = AssetAPI(self)

    async def __aenter__(self):
        raise NotImplementedError("async context manager not implemented")

    async def __aexit__(self, exc_type, exc, tb):
        raise NotImplementedError("async context manager not implemented")

    def wallet(self, key: Key) -> Wallet:
        return Wallet(self, key)

    async def _get(self, *args, **kwargs):
        self.session = ClientSession(headers={"Accept": "application/json"}, loop=self.loop)
        try:
            result = await super()._get(*args, **kwargs)
        finally:
            await self.session.close()
        return result

    async def _get_df(self, *args, **kwargs):
        self.session = ClientSession(headers={"Accept": "application/json"}, loop=self.loop)
        try:
            result = await super()._get_df(*args, **kwargs)
        finally:
            await self.session.close()
        return result

    async def _post_df(self, *args, **kwargs):
        self.session = ClientSession(headers={"Accept": "application/json"}, loop=self.loop)
        try:
            result = await super()._post_df(*args, **kwargs)
        finally:
            await self.session.close()
        return result

    async def _post(self, *args, **kwargs):
        self.session = ClientSession(headers={"Accept": "application/json"}, loop=self.loop)
        try:
            result = await super()._post(*args, **kwargs)
        finally:
            await self.session.close()
        return result

    async def _search(self, *args, **kwargs):
        self.session = ClientSession(headers={"Accept": "application/json"}, loop=self.loop)
        try:
            result = await super()._search(*args, **kwargs)
        finally:
            await self.session.close()
        return result
