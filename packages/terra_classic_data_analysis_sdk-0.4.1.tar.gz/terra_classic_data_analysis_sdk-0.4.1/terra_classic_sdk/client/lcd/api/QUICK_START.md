# 快速开始 - 参数装饰器使用指南

## 问题

在开发 API 接口时，每个方法都需要手动将参数收集到 `params` 字典中：

```python
async def my_method(self, param1, param2, param3=None):
    params = {
        "param1": param1,
        "param2": param2,
        "param3": param3,
    }
    return await self._c._get_df("/endpoint", params=params)
```

这种重复代码既繁琐又容易出错。

## 解决方案

使用 `@auto_params()` 装饰器自动处理参数收集：

```python
from .._params_decorator import auto_params

@auto_params()
async def my_method(
    self,
    param1,
    param2,
    param3=None,
    params: Optional[dict] = None,  # 必须添加此参数
):
    # params 自动包含所有参数
    return await self._c._get_df("/endpoint", params=params)
```

## 三种使用场景

### 场景1：基本用法（90% 的情况）

```python
@auto_params()
async def module_accounts(
    self,
    fields: Optional[Union[str, List[str]]] = None,
    limit: Optional[int] = None,
    coin: Optional[str] = 'lunc',
    params: Optional[dict] = None,
) -> pd.DataFrame:
    """所有参数自动加入 params"""
    return await self._c._get_df(
        "/v1/account/module_accounts",
        params=params
    )
```

**对比传统方式：**
- ✅ 无需手动构建 params 字典
- ✅ 减少 5-10 行代码
- ✅ 避免遗漏参数

### 场景2：需要排除某些参数

```python
@auto_params(exclude_params=['internal_flag'])
async def my_method(
    self,
    public_param: str = "value",
    internal_flag: bool = False,  # 不会传给 API
    params: Optional[dict] = None,
):
    """internal_flag 用于内部逻辑，不传给 API"""
    if internal_flag:
        print("Internal processing...")
    
    return await self._c._get_df("/endpoint", params=params)
```

### 场景3：需要特殊处理参数

```python
def preprocess_freq(params: dict) -> dict:
    """预处理函数"""
    if params.get('freq'):
        params['freq'] = params['freq'].upper()
    return params

@auto_params(preprocessor=preprocess_freq)
async def activate_overview(
    self,
    freq: str = "HOUR",
    limit: int = 100,
    params: Optional[dict] = None,
):
    """freq 会被自动转为大写"""
    return await self._c._get_df("/endpoint", params=params)
```

## 实际案例对比

### 改造前（传统方式）

```python
async def rich_list(
    self,
    denom: str = "uluna",
    rank_start: int = 1,
    rank_end: int = 10,
    limit: Optional[int] = None,
    fields: Optional[Union[str, List[str]]] = None,
    coin: Optional[str] = 'lunc',
) -> pd.DataFrame:
    if limit is None:
        limit = rank_end - rank_start + 1

    params = {
        "denom": denom,
        "rank_start": rank_start,
        "rank_end": rank_end,
        "limit": limit,
    }
    if fields:
        params["fields"] = fields

    return await self._c._get_df(
        "/v1/account/rich_list", 
        params=params, 
        parse_dates=["lst_act_time"]
    )
```

### 改造后（使用装饰器）

```python
@auto_params()
async def rich_list(
    self,
    denom: str = "uluna",
    rank_start: int = 1,
    rank_end: int = 10,
    limit: Optional[int] = None,
    fields: Optional[Union[str, List[str]]] = None,
    coin: Optional[str] = 'lunc',
    params: Optional[dict] = None,
) -> pd.DataFrame:
    if params.get('limit') is None:
        params['limit'] = params.get('rank_end') - params.get('rank_start') + 1

    return await self._c._get_df(
        "/v1/account/rich_list", 
        params=params, 
        parse_dates=["lst_act_time"]
    )
```

**改进点：**
- ✅ 减少了 8 行参数收集代码
- ✅ 逻辑更清晰，专注于业务逻辑
- ✅ 更易维护

## 使用步骤

1. **导入装饰器**
   ```python
   from .._params_decorator import auto_params
   ```

2. **添加装饰器**
   ```python
   @auto_params()
   async def my_method(...):
   ```

3. **添加 params 参数**
   ```python
   async def my_method(
       self,
       # ... 其他参数
       params: Optional[dict] = None,  # 必须添加
   ):
   ```

4. **使用 params**
   ```python
   return await self._c._get_df("/endpoint", params=params)
   ```

## 注意事项

⚠️ **必须添加 `params` 参数**
```python
# ❌ 错误
@auto_params()
async def my_method(self, param1):
    pass

# ✅ 正确
@auto_params()
async def my_method(self, param1, params: Optional[dict] = None):
    pass
```

⚠️ **params 参数放在最后**
```python
async def my_method(
    self,
    param1,
    param2,
    params: Optional[dict] = None,  # 最后一个
):
```

## 优势总结

| 特性 | 传统方式 | 装饰器方式 |
|------|---------|-----------|
| 代码量 | 多（需手动构建 params） | 少（自动生成） |
| 可维护性 | 低（重复代码多） | 高（统一管理） |
| 出错概率 | 高（容易遗漏参数） | 低（自动收集） |
| 可读性 | 一般 | 好（逻辑清晰） |
| 扩展性 | 差 | 好（支持预处理） |

## 下一步

- 查看完整文档：[PARAMS_DECORATOR_README.md](./PARAMS_DECORATOR_README.md)
- 查看更多示例：[_params_example.py](./_params_example.py)
- 查看实际应用：[account.py](./df/account.py)