"""
批量迁移指南 - 如何将现有 API 方法迁移到使用 auto_params 装饰器

本脚本提供自动化的迁移建议和步骤。
"""

import re
from pathlib import Path


def analyze_file(file_path: str) -> dict:
    """分析文件，找出可以应用装饰器的方法"""
    
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # 查找所有异步方法
    async_methods = re.findall(
        r'async def (\w+)\s*\((.*?)\)\s*->\s*pd\.DataFrame:',
        content,
        re.DOTALL
    )
    
    results = []
    for method_name, params_block in async_methods:
        # 检查是否已经有 params 参数
        has_params = 'params:' in params_block or 'params :' in params_block
        
        # 检查是否有手动构建 params 的代码
        has_manual_params = bool(re.search(r'params\s*=\s*\{', params_block))
        
        # 统计参数数量
        param_count = len([p for p in params_block.split(',') if p.strip() and p.strip() != 'self'])
        
        results.append({
            'method': method_name,
            'has_params': has_params,
            'has_manual_params': has_manual_params,
            'param_count': param_count,
            'recommend': param_count >= 2 and not has_params
        })
    
    return {
        'file': file_path,
        'methods': results,
        'total': len(results),
        'can_migrate': sum(1 for m in results if m['recommend'])
    }


def generate_migration_code(method_info: dict) -> str:
    """生成迁移后的代码示例"""
    
    method_name = method_info['method']
    
    code = f"""
# 迁移前:
async def {method_name}(self, ...):
    params = {{
        # 手动构建 params
    }}
    return await self._c._get_df("/endpoint", params=params)

# 迁移后:
@auto_params()
async def {method_name}(
    self,
    # ... 原有参数
    params: Optional[dict] = None,  # 新增此行
) -> pd.DataFrame:
    # params 自动生成，无需手动构建
    return await self._c._get_df("/endpoint", params=params)
"""
    return code


def scan_directory(directory: str):
    """扫描目录中的所有 Python 文件"""
    
    print("=" * 70)
    print("Terra.py API 参数装饰器迁移分析工具")
    print("=" * 70)
    print()
    
    df_dir = Path(directory)
    py_files = list(df_dir.glob("*.py"))
    
    total_methods = 0
    migratable_methods = 0
    
    for py_file in py_files:
        if py_file.name.startswith('_'):
            continue
        
        print(f"\n📄 分析文件: {py_file.name}")
        print("-" * 70)
        
        try:
            result = analyze_file(str(py_file))
            
            if result['total'] == 0:
                print("  未找到符合条件的 API 方法")
                continue
            
            print(f"  找到 {result['total']} 个 API 方法")
            print(f"  可迁移: {result['can_migrate']} 个")
            
            total_methods += result['total']
            migratable_methods += result['can_migrate']
            
            # 显示可迁移的方法
            for method in result['methods']:
                if method['recommend']:
                    status = "✅ 推荐迁移" if not method['has_params'] else "⚠️  已有 params"
                    print(f"    - {method['method']} ({method['param_count']} 参数) {status}")
        
        except Exception as e:
            print(f"  ❌ 分析失败: {e}")
    
    print("\n" + "=" * 70)
    print(f"📊 总结:")
    print(f"  总方法数: {total_methods}")
    print(f"  可迁移: {migratable_methods}")
    print(f"  迁移率: {migratable_methods/total_methods*100:.1f}%" if total_methods > 0 else "  N/A")
    print("=" * 70)
    
    print("\n💡 迁移建议:")
    print("  1. 优先迁移参数较多的方法（收益更大）")
    print("  2. 先在新接口中使用，熟悉后再迁移旧接口")
    print("  3. 参考 QUICK_START.md 了解详细步骤")
    print("  4. 查看 account.py 作为实际案例")


if __name__ == "__main__":
    import sys
    
    # 默认扫描 df 目录
    directory = sys.argv[1] if len(sys.argv) > 1 else "C:/data/cloud_disk/BaiduSyncdisk/project/git/terra.py/terra_classic_sdk/client/lcd/api/df"
    
    scan_directory(directory)
    
    print("\n" + "=" * 70)
    print("📚 相关文档:")
    print("  - QUICK_START.md: 快速开始指南")
    print("  - PARAMS_DECORATOR_README.md: 完整文档")
    print("  - SOLUTION_SUMMARY.md: 方案总结")
    print("  - _params_example.py: 使用示例")
    print("=" * 70)