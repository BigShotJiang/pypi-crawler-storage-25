from datetime import datetime
from typing import Optional, List, Union
import pandas as pd

from .._base import BaseAsyncAPI, sync_bind
from ._common import FreqLiteral, _normalize_datetime
from .._params_decorator import auto_params

__all__ = ["AsyncBurnsAPI", "BurnsAPI"]


class AsyncBurnsAPI(BaseAsyncAPI):
    @auto_params()
    async def overview(
        self,
        start_time: Optional[Union[str, datetime]] = None,
        end_time: Optional[Union[str, datetime]] = None,
        freq: Optional[FreqLiteral] = "HOUR",
        fields: Optional[Union[str, List[str]]] = None,
        coin: Optional[str] = 'lunc',
        limit: Optional[int] = None,
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        """
        Network Overview. Token Burning Metrics including Voluntary Burns and Fee Burns. Updated hourly.

        Args:
            start_time (datetime, optional): Start time (UTC).
            end_time (datetime, optional): End time (UTC).
            freq (AggFreq, optional): Data aggregation frequency. Defaults to HOUR.
            fields (str, optional): Return field filtering, separated by commas.
            coin (str, optional): Coin type. Defaults to 'lunc'.
            limit (int, optional): Max rows to return.

        Returns:
            pd.DataFrame: DataFrame containing the burns overview data.
        """
        params['start_time'] = _normalize_datetime(params.get('start_time'))
        params['end_time'] = _normalize_datetime(params.get('end_time'))
        if params.get('freq'):
            params['freq'] = params['freq'].upper()

        return await self._c._get_df(
            "/v1/burns/overview",
            params=params,
            parse_dates=["dt"]
        )

    @auto_params()
    async def asset_overview(
        self,
        start_time: Optional[Union[str, datetime]] = None,
        end_time: Optional[Union[str, datetime]] = None,
        asset: Optional[str] = None,
        freq: Optional[FreqLiteral] = "HOUR",
        fields: Optional[Union[str, List[str]]] = None,
        limit: Optional[int] = None,
        coin: Optional[str] = "lunc",
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        """
        Burns overview for a specific asset or all assets. Updated hourly.

        Args:
            start_time (datetime, optional): Start time (UTC).
            end_time (datetime, optional): End time (UTC).
            asset (str, optional): Asset name.
            freq (AggFreq, optional): Data aggregation frequency. Defaults to HOUR.
            fields (str, optional): Return field filtering, separated by commas.
            coin (str, optional): Coin type. Defaults to 'lunc'.
            limit (int, optional): Max rows to return.

        Returns:
            pd.DataFrame: DataFrame containing the burns asset overview.
        """
        params['start_time'] = _normalize_datetime(params.get('start_time'))
        params['end_time'] = _normalize_datetime(params.get('end_time'))
        if params.get('freq'):
            params['freq'] = params['freq'].upper()

        return await self._c._get_df(
            "/v1/burns/assets_info",
            params=params,
            parse_dates=["dt"]
        )


class BurnsAPI(AsyncBurnsAPI):
    @sync_bind(AsyncBurnsAPI.overview)
    def overview(
        self,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None,
        freq: Optional[FreqLiteral] = "HOUR",
        fields: Optional[Union[str, List[str]]] = None,
        coin: Optional[str] = 'lunc',
        limit: Optional[int] = None,
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        pass

    overview.__doc__ = AsyncBurnsAPI.overview.__doc__

    @sync_bind(AsyncBurnsAPI.asset_overview)
    def asset_overview(
        self,
        start_time: Optional[Union[str, datetime]] = None,
        end_time: Optional[Union[str, datetime]] = None,
        asset: Optional[str] = None,
        freq: Optional[FreqLiteral] = "HOUR",
        fields: Optional[Union[str, List[str]]] = None,
        limit: Optional[int] = None,
        coin: Optional[str] = "lunc",
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        pass

    asset_overview.__doc__ = AsyncBurnsAPI.asset_overview.__doc__
