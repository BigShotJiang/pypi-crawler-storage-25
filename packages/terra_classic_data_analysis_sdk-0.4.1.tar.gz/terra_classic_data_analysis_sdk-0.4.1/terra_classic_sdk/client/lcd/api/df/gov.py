from datetime import datetime
from typing import Optional, Union, List, Literal
import pandas as pd

from .._base import BaseAsyncAPI, sync_bind
from ._common import FreqLiteral, _normalize_datetime
from .._params_decorator import auto_params

__all__ = ["AsyncGovAPI", "GovAPI"]

ProposalStatusLiteral = Literal[
    "ALL", "PROPOSAL_STATUS_DEPOSIT_PERIOD", "PROPOSAL_STATUS_FAILED",
    "PROPOSAL_STATUS_PASSED", "PROPOSAL_STATUS_REJECTED", "PROPOSAL_STATUS_VOTING_PERIOD",
    "all", "proposal_status_deposit_period", "proposal_status_failed",
    "proposal_status_passed", "proposal_status_rejected", "proposal_status_voting_period"
]

ProposalVoteRoleLiteral = Literal[
    "ALL", "VALIDATORS", "DELEGATORS",
    "all", "validators", "delegators"
]

ProposalVoteOptionLiteral = Literal[
    "ALL", "VOTE_OPTION_YES", "VOTE_OPTION_NO", "VOTE_OPTION_NO_WITH_VETO", "VOTE_OPTION_ABSTAIN",
    "all", "vote_option_yes", "vote_option_no", "vote_option_no_with_veto", "vote_option_abstain"
]


class AsyncGovAPI(BaseAsyncAPI):
    @auto_params()
    async def overview(
        self,
        start_time: Optional[Union[str, datetime]] = None,
        end_time: Optional[Union[str, datetime]] = None,
        freq: Optional[FreqLiteral] = "HOUR",
        fields: Optional[Union[str, List[str]]] = None,
        limit: Optional[int] = None,
        coin: Optional[str] = 'lunc',
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        """
        Governance Proposals, Deposits, and Voting Activities. Updated hourly.

        Args:
            start_time (datetime, optional): Start time (UTC).
            end_time (datetime, optional): End time (UTC).
            freq (AggFreq, optional): Data aggregation frequency. Defaults to HOUR.
            fields (str, optional): Return field filtering, separated by commas.
            coin (str, optional): Coin type. Defaults to 'lunc'.
            limit (int, optional): Max rows to return. Defaults to 100.

        Returns:
            pd.DataFrame: DataFrame containing the governance overview data.
        """
        params['start_time'] = _normalize_datetime(params.get('start_time'))
        params['end_time'] = _normalize_datetime(params.get('end_time'))
        if params.get('freq'):
            params['freq'] = params['freq'].upper()

        return await self._c._get_df(
            "/v1/governance/overview",
            params=params,
            parse_dates=["dt"]
        )


    @auto_params()
    async def asset_overview(
        self,
        start_time: Optional[Union[str, datetime]] = None,
        end_time: Optional[Union[str, datetime]] = None,
        asset: Optional[str] = None,
        freq: Optional[FreqLiteral] = "HOUR",
        fields: Optional[Union[str, List[str]]] = None,
        limit: Optional[int] = None,
        coin: Optional[str] = 'lunc',
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        """
        Asset Overview for Governance.

        Args:
            start_time (datetime, optional): Start time (UTC).
            end_time (datetime, optional): End time (UTC).
            asset (str, optional): Asset.
            freq (FreqLiteral, optional): Data aggregation frequency. Defaults to HOUR.
            fields (str, optional): Return field filtering, separated by commas.
            limit (int, optional): Max rows to return.
            coin (str, optional): Coin type. Defaults to 'lunc'.

        Returns:
            pd.DataFrame: DataFrame containing the governance asset overview data.
        """
        params['start_time'] = _normalize_datetime(params.get('start_time'))
        params['end_time'] = _normalize_datetime(params.get('end_time'))
        if params.get('freq'):
            params['freq'] = params['freq'].upper()

        return await self._c._get_df(
            "/v1/governance/assets_info",
            params=params,
            parse_dates=["dt"]
        )

    @auto_params()
    async def proposal_list(
        self,
        start_time: Optional[Union[str, datetime]] = None,
        end_time: Optional[Union[str, datetime]] = None,
        status: Optional[ProposalStatusLiteral] = "ALL",
        fields: Optional[Union[str, List[str]]] = None,
        coin: Optional[str] = 'lunc',
        limit: Optional[int] = None,
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        """
        Retrieve a list of governance proposals with their status, voting results, and deposit information.

        Args:
            start_time (Union[str, datetime], optional): Start time (UTC).
            end_time (Union[str, datetime], optional): End time (UTC).
            status (ProposalStatusLiteral, optional): Proposal status filter. Defaults to "ALL".
            fields (Union[str, List[str]], optional): Return field filtering, separated by commas.
            coin (str, optional): Coin type. Defaults to 'lunc'.
            limit (int, optional): Max rows to return.

        Returns:
            pd.DataFrame: DataFrame containing the governance proposals data.
        """
        params['start_time'] = _normalize_datetime(params.get('start_time'))
        params['end_time'] = _normalize_datetime(params.get('end_time'))
        if params.get('status'):
            params['status'] = params['status'].upper()

        return await self._c._get_df(
            "/v1/governance/proposals",
            params=params,
            parse_dates=["submit_time_utc", "voting_start_time_utc", "voting_end_time_utc", "deposit_end_time_utc"]
        )

    @auto_params()
    async def proposal_voters(
        self,
        proposal_id: int,
        vote_role: Optional[ProposalVoteRoleLiteral] = "ALL",
        vote_option: Optional[ProposalVoteOptionLiteral] = "ALL",
        fields: Optional[Union[str, List[str]]] = None,
        coin: Optional[str] = 'lunc',
        limit: Optional[int] = None,
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        """
        Retrieve a detailed list of voters for a specific proposal, including voting power and deduction details.

        Args:
            proposal_id (int): The unique identifier of the governance proposal.
            vote_role (ProposalVoteRoleLiteral, optional): Voter role filter. Defaults to "ALL".
            vote_option (ProposalVoteOptionLiteral, optional): Vote option filter. Defaults to "ALL".
            fields (Union[str, List[str]], optional): Return field filtering, separated by commas.
            coin (str, optional): Coin type. Defaults to 'lunc'.
            limit (int, optional): Max rows to return.

        Returns:
            pd.DataFrame: DataFrame containing the proposal voters data.
        """
        if params.get('vote_role'):
            params['vote_role'] = params['vote_role'].upper()
        if params.get('vote_option'):
            params['vote_option'] = params['vote_option'].upper()

        return await self._c._get_df(
            "/v1/governance/proposal_voters",
            params=params,
            parse_dates=["vote_time_utc"]
        )

    @auto_params()
    async def proposal_detail(
        self,
        proposal_id: int,
        fields: Optional[Union[str, List[str]]] = None,
        coin: Optional[str] = 'lunc',
        limit: Optional[int] = None,
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        """
        Retrieve comprehensive details of a specific governance proposal, including its content, status, and calculated voting results.

        Args:
            proposal_id (int): The unique identifier of the governance proposal.
            fields (Union[str, List[str]], optional): Return field filtering, separated by commas.
            coin (str, optional): Coin type. Defaults to 'lunc'.
            limit (int, optional): Max rows to return.

        Returns:
            pd.DataFrame: DataFrame containing the proposal detail data.
        """
        return await self._c._get_df(
            "/v1/governance/proposal_detail",
            params=params,
            parse_dates=["submit_time_utc", "voting_start_time_utc", "voting_end_time_utc", "deposit_end_time_utc"]
        )


class GovAPI(AsyncGovAPI):
    @sync_bind(AsyncGovAPI.overview)
    def overview(
        self,
        start_time: Optional[Union[str, datetime]] = None,
        end_time: Optional[Union[str, datetime]] = None,
        freq: Optional[FreqLiteral] = "HOUR",
        fields: Optional[Union[str, List[str]]] = None,
        limit: Optional[int] = None,
        coin: Optional[str] = 'lunc',
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        pass

    overview.__doc__ = AsyncGovAPI.overview.__doc__

    @sync_bind(AsyncGovAPI.asset_overview)
    def asset_overview(
        self,
        start_time: Optional[Union[str, datetime]] = None,
        end_time: Optional[Union[str, datetime]] = None,
        asset: Optional[str] = None,
        freq: Optional[FreqLiteral] = "HOUR",
        fields: Optional[Union[str, List[str]]] = None,
        limit: Optional[int] = None,
        coin: Optional[str] = 'lunc',
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        pass

    asset_overview.__doc__ = AsyncGovAPI.asset_overview.__doc__

    @sync_bind(AsyncGovAPI.proposal_list)
    def proposal_list(
        self,
        start_time: Optional[Union[str, datetime]] = None,
        end_time: Optional[Union[str, datetime]] = None,
        status: Optional[ProposalStatusLiteral] = "ALL",
        fields: Optional[Union[str, List[str]]] = None,
        coin: Optional[str] = 'lunc',
        limit: Optional[int] = None,
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        pass

    proposal_list.__doc__ = AsyncGovAPI.proposal_list.__doc__

    @sync_bind(AsyncGovAPI.proposal_voters)
    def proposal_voters(
        self,
        proposal_id: int,
        vote_role: Optional[ProposalVoteRoleLiteral] = "ALL",
        vote_option: Optional[ProposalVoteOptionLiteral] = "ALL",
        fields: Optional[Union[str, List[str]]] = None,
        coin: Optional[str] = 'lunc',
        limit: Optional[int] = None,
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        pass

    proposal_voters.__doc__ = AsyncGovAPI.proposal_voters.__doc__

    @sync_bind(AsyncGovAPI.proposal_detail)
    def proposal_detail(
        self,
        proposal_id: int,
        fields: Optional[Union[str, List[str]]] = None,
        coin: Optional[str] = 'lunc',
        limit: Optional[int] = None,
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        pass

    proposal_detail.__doc__ = AsyncGovAPI.proposal_detail.__doc__
