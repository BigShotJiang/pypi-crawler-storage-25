from datetime import datetime
from typing import Optional, Union, List
import pandas as pd

from .._base import BaseAsyncAPI, sync_bind
from ._common import FreqLiteral, _normalize_datetime
from .._params_decorator import auto_params

__all__ = ["AsyncTransferAPI", "TransferAPI"]


class AsyncTransferAPI(BaseAsyncAPI):
    @auto_params()
    async def overview(
        self,
        start_time: Optional[Union[str, datetime]] = None,
        end_time: Optional[Union[str, datetime]] = None,
        freq: Optional[FreqLiteral] = "HOUR",
        fields: Optional[Union[str, List[str]]] = None,
        limit: Optional[int] = None,
        coin: Optional[str] = 'lunc',
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        """
        On-chain Transfer and Peer-to-Peer Transfer Metrics. Updated hourly.

        Args:
            start_time (Union[str, datetime], optional): Start time (UTC).
            end_time (Union[str, datetime], optional): End time (UTC).
            freq (FreqLiteral, optional): Data aggregation frequency (HOUR, DAY, WEEK, MONTH, QUARTER, YEAR). Defaults to "HOUR".
            fields (Union[str, List[str]], optional): Return field filtering, separated by commas.
            limit (int, optional): Max rows to return.
            coin (str, optional): Coin type. Defaults to 'lunc'.

        Returns:
            pd.DataFrame: DataFrame containing transfer metrics.
        """
        params['start_time'] = _normalize_datetime(params.get('start_time'))
        params['end_time'] = _normalize_datetime(params.get('end_time'))
        if params.get('freq'):
            params['freq'] = params['freq'].upper()

        return await self._c._get_df(
            "/v1/transfer/overview",
            params=params,
            parse_dates=["dt"]
        )

    @auto_params()
    async def asset_overview(
        self,
        start_time: Optional[Union[str, datetime]] = None,
        end_time: Optional[Union[str, datetime]] = None,
        asset: Optional[str] = None,
        freq: Optional[FreqLiteral] = "HOUR",
        fields: Optional[Union[str, List[str]]] = None,
        limit: Optional[int] = None,
        coin: Optional[str] = 'lunc',
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        """
        Transfer metrics breakdown by asset. Updated hourly.

        Args:
            start_time (Union[str, datetime], optional): Start time (UTC).
            end_time (Union[str, datetime], optional): End time (UTC).
            asset (str, optional): Filter by specific asset.
            freq (FreqLiteral, optional): Data aggregation frequency. Defaults to "HOUR".
            fields (Union[str, List[str]], optional): Return field filtering, separated by commas.
            limit (int, optional): Max rows to return.
            coin (str, optional): Coin type. Defaults to 'lunc'.

        Returns:
            pd.DataFrame: DataFrame containing transfer metrics by asset.
        """
        params['start_time'] = _normalize_datetime(params.get('start_time'))
        params['end_time'] = _normalize_datetime(params.get('end_time'))
        if params.get('freq'):
            params['freq'] = params['freq'].upper()

        return await self._c._get_df(
            "/v1/transfer/assets_info",
            params=params,
            parse_dates=["dt"]
        )

    @auto_params()
    async def transfer_txs_details(
        self,
        start_time: Optional[Union[str, datetime]] = None,
        end_time: Optional[Union[str, datetime]] = None,
        asset: Optional[str] = None,
        tx_hash: Optional[str] = None,
        address: Optional[str] = None,
        code: Optional[int] = 0,
        fields: Optional[Union[str, List[str]]] = None,
        limit: Optional[int] = None,
        page: Optional[int] = None,
        page_size: Optional[int] = None,
        coin: Optional[str] = 'lunc',
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        """
        Comprehensive detailed transaction records for on-chain transfers. Updated hourly.

        Args:
            start_time (Union[str, datetime], optional): Start time (UTC).
            end_time (Union[str, datetime], optional): End time (UTC).
            asset (str, optional): Token identifier: denom or symbol (e.g., LUNC, USTC, uluna, uusd).
            tx_hash (str, optional): Transaction hash identifier.
            address (str, optional): The address involved in the transfer (either as sender or receiver).
            code (int, optional): Transaction response code (0 for success, others for failure). Defaults to 0.
            fields (Union[str, List[str]], optional): Return field filtering, separated by commas.
            limit (int, optional): Max rows to return.
            page (int, optional): Page number.
            page_size (int, optional): Page size.
            coin (str, optional): Coin type. Defaults to 'lunc'.

        Returns:
            pd.DataFrame: DataFrame containing transfer transaction details.
        """
        params['start_time'] = _normalize_datetime(params.get('start_time'))
        params['end_time'] = _normalize_datetime(params.get('end_time'))

        return await self._c._get_df(
            "/v1/transfer/tx_details",
            params=params,
            parse_dates=["timestamp_utc"]
        )


class TransferAPI(AsyncTransferAPI):
    @sync_bind(AsyncTransferAPI.overview)
    def overview(
        self,
        start_time: Optional[Union[str, datetime]] = None,
        end_time: Optional[Union[str, datetime]] = None,
        freq: Optional[FreqLiteral] = "HOUR",
        fields: Optional[Union[str, List[str]]] = None,
        limit: Optional[int] = None,
        coin: Optional[str] = 'lunc',
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        pass

    overview.__doc__ = AsyncTransferAPI.overview.__doc__

    @sync_bind(AsyncTransferAPI.asset_overview)
    def asset_overview(
        self,
        start_time: Optional[Union[str, datetime]] = None,
        end_time: Optional[Union[str, datetime]] = None,
        asset: Optional[str] = None,
        freq: Optional[FreqLiteral] = "HOUR",
        fields: Optional[Union[str, List[str]]] = None,
        limit: Optional[int] = None,
        coin: Optional[str] = 'lunc',
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        pass

    asset_overview.__doc__ = AsyncTransferAPI.asset_overview.__doc__

    @sync_bind(AsyncTransferAPI.transfer_txs_details)
    def transfer_txs_details(
        self,
        start_time: Optional[Union[str, datetime]] = None,
        end_time: Optional[Union[str, datetime]] = None,
        asset: Optional[str] = None,
        tx_hash: Optional[str] = None,
        address: Optional[str] = None,
        code: Optional[int] = 0,
        fields: Optional[Union[str, List[str]]] = None,
        limit: Optional[int] = None,
        page: Optional[int] = None,
        page_size: Optional[int] = None,
        coin: Optional[str] = 'lunc',
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        pass

    transfer_txs_details.__doc__ = AsyncTransferAPI.transfer_txs_details.__doc__
