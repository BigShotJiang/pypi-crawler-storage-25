from datetime import datetime
from typing import Optional, List, Union, Literal
import pandas as pd

from .._base import BaseAsyncAPI, sync_bind
from ._common import FreqLiteral, _normalize_datetime
from .._params_decorator import auto_params

__all__ = ["AsyncWasmAPI", "WasmAPI"]

WasmMsgTypeLiteral = Literal[
    "ALL", "EXECUTE", "INSTANTIATE", "MIGRATE", "STORE_CODE", "UPDATE_ADMIN", "CLEAR_ADMIN",
    "all", "execute", "instantiate", "migrate", "store_code", "update_admin", "clear_admin"
]


class AsyncWasmAPI(BaseAsyncAPI):
    @auto_params()
    async def cw20_asset_balance(
        self,
        rank_start: int = 1,
        rank_end: int = 10,
        wallet_addr: Optional[str] = None,
        contract_addr: Optional[str] = None,
        fields: Optional[Union[str, List[str]]] = None,
        coin: Optional[str] = 'lunc',
        limit: Optional[int] = None,
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        """Query CW20 token balances by wallet address or contract address with ranking.

        Args:
            rank_start (int, optional): Starting rank. Defaults to 1.
            rank_end (int, optional): Ending rank. Defaults to 10.
            wallet_addr (str, optional): The wallet address to query for CW20 balances.
            contract_addr (str, optional): The CW20 contract address (token identity).
            fields (str, optional): Return field filtering, separated by commas.
            coin (str, optional): Coin type. Defaults to 'lunc'.
            limit (int, optional): Max rows to return. If not provided, it will be calculated from rank_end - rank_start + 1.

        Returns:
            pd.DataFrame: DataFrame containing CW20 balance data with columns:
                - rank_num: Ranking position based on actual balance
                - contract_addr: CW20 contract address
                - wallet_addr: Wallet address of the token holder
                - symbol: Token symbol
                - name: Token full name
                - bal_raw: Raw balance in micro-units (string to prevent precision loss)
                - bal_actual: Human-readable balance adjusted by decimals
                - decimals: Token precision decimals
                - supply_raw: Total supply in micro-units
                - supply_actual: Human-readable total supply
                - is_mintable: Whether the token has minting permissions/risks
                - minter_info: Detailed minting authority information
        """
        if params.get('limit') is None:
            params['limit'] = params.get('rank_end') - params.get('rank_start') + 1

        return await self._c._get_df(
            "/v1/wasm/cw20_balance",
            params=params
        )

    @auto_params()
    async def wasm_txs_details(
        self,
        start_time: Optional[Union[str, datetime]] = None,
        end_time: Optional[Union[str, datetime]] = None,
        tx_hash: Optional[str] = None,
        address: Optional[str] = None,
        code: int = 0,
        msg_type: Optional[WasmMsgTypeLiteral] = "ALL",
        fields: Optional[Union[str, List[str]]] = None,
        coin: Optional[str] = 'lunc',
        limit: Optional[int] = None,
        page: int = 1,
        page_size: int = 20,
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        """Detailed information about smart contract (Wasm) transactions. Updated hourly.

        Args:
            start_time (str, optional): Start time (UTC).
            end_time (str, optional): End time (UTC).
            tx_hash (str, optional): Transaction hash identifier.
            address (str, optional): Sender or contract address.
            code (int, optional): Transaction response code (0 for success). Defaults to 0.
            msg_type (str, optional): Type of Wasm message (EXECUTE, INSTANTIATE, MIGRATE, STORE_CODE, UPDATE_ADMIN, CLEAR_ADMIN, ALL). Defaults to "ALL".
            fields (str, optional): Return field filtering, separated by commas.
            coin (str, optional): Coin type. Defaults to 'lunc'.
            limit (int, optional): Max rows to return.
            page (int, optional): Page number. Defaults to 1.
            page_size (int, optional): Page size. Defaults to 20.

        Returns:
            pd.DataFrame: DataFrame containing Wasm transaction details with columns:
                - timestamp_utc: Transaction execution time in UTC
                - code: Transaction status code (0: Success)
                - msg_type: Wasm message action type
                - sender_addr: Address of the message sender
                - contract_addr: Address of the smart contract
                - code_id: Wasm code template identifier
                - admin_addr: Contract administrator address
                - tx_hash: Unique transaction hash
        """
        params['start_time'] = _normalize_datetime(params.get('start_time'))
        params['end_time'] = _normalize_datetime(params.get('end_time'))
        if params.get('msg_type'):
            params['msg_type'] = params['msg_type'].upper()

        return await self._c._get_df(
            "/v1/wasm/tx_details",
            params=params,
            parse_dates=["timestamp_utc"]
        )

    @auto_params()
    async def overview(
        self,
        start_time: Optional[Union[str, datetime]] = None,
        end_time: Optional[Union[str, datetime]] = None,
        freq: Optional[FreqLiteral] = "HOUR",
        fields: Optional[Union[str, List[str]]] = None,
        coin: Optional[str] = 'lunc',
        limit: Optional[int] = None,
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        """
        Smart Contract (Wasm) Execution, Instantiation, and Migration Activity. Updated hourly.

        Args:
            start_time (datetime, optional): Start time (UTC).
            end_time (datetime, optional): End time (UTC).
            freq (AggFreq, optional): Data aggregation frequency. Defaults to HOUR.
            fields (str, optional): Return field filtering, separated by commas.
            coin (str, optional): Coin type. Defaults to 'lunc'.
            limit (int, optional): Max rows to return. Defaults to 100.

        Returns:
            pd.DataFrame: DataFrame containing the wasm overview data.
        """
        params['start_time'] = _normalize_datetime(params.get('start_time'))
        params['end_time'] = _normalize_datetime(params.get('end_time'))
        if params.get('freq'):
            params['freq'] = params['freq'].upper()

        return await self._c._get_df(
            "/v1/wasm/overview",
            params=params,
            parse_dates=["dt"]
        )


class WasmAPI(AsyncWasmAPI):
    @sync_bind(AsyncWasmAPI.cw20_asset_balance)
    def cw20_asset_balance(
        self,
        rank_start: int = 1,
        rank_end: int = 10,
        wallet_addr: Optional[str] = None,
        contract_addr: Optional[str] = None,
        fields: Optional[Union[str, List[str]]] = None,
        coin: Optional[str] = 'lunc',
        limit: Optional[int] = None,
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        pass

    cw20_asset_balance.__doc__ = AsyncWasmAPI.cw20_asset_balance.__doc__

    @sync_bind(AsyncWasmAPI.wasm_txs_details)
    def wasm_txs_details(
        self,
        start_time: Optional[Union[str, datetime]] = None,
        end_time: Optional[Union[str, datetime]] = None,
        tx_hash: Optional[str] = None,
        address: Optional[str] = None,
        code: int = 0,
        msg_type: Optional[WasmMsgTypeLiteral] = "ALL",
        fields: Optional[Union[str, List[str]]] = None,
        coin: Optional[str] = 'lunc',
        limit: Optional[int] = None,
        page: int = 1,
        page_size: int = 20,
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        pass

    wasm_txs_details.__doc__ = AsyncWasmAPI.wasm_txs_details.__doc__

    @sync_bind(AsyncWasmAPI.overview)
    def overview(
        self,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None,
        freq: Optional[FreqLiteral] = "HOUR",
        fields: Optional[Union[str, List[str]]] = None,
        coin: Optional[str] = 'lunc',
        limit: Optional[int] = None,
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        pass

    overview.__doc__ = AsyncWasmAPI.overview.__doc__
