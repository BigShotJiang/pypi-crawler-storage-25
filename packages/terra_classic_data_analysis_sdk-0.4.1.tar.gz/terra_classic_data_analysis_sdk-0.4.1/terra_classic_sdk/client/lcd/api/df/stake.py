from datetime import datetime
from typing import Optional, Union, List, Literal
import pandas as pd

from .._base import BaseAsyncAPI, sync_bind
from ._common import FreqLiteral, _normalize_datetime
from .._params_decorator import auto_params

__all__ = ["AsyncStakeAPI", "StakeAPI"]

BondStatusLiteral = Literal[
    "BOND_STATUS_BONDED",
    "BOND_STATUS_UNBONDED",
    "BOND_STATUS_UNBONDING",
    "bond_status_bonded",
    "bond_status_unbonded",
    "bond_status_unbonding",
]

PeriodLiteral = Literal[
    "1D", "7D", "14D", "28D", "3M", "6M",
    "1d", "7d", "14d", "28d", "3m", "6m"
]

DelegationTypeLiteral = Literal[
    "ALL", "DELEGATE", "UNDELEGATE", "BEGIN_REDELEGATE", "WITHDRAW_REWARD",
    "all", "delegate", "undelegate", "begin_redelegate", "withdraw_reward"
]

StakingMsgTypeLiteral = Literal[
    "ALL", "DELEGATE", "UNDELEGATE", "BEGIN_REDELEGATE", 
    "CREATE_VALIDATOR", "EDIT_VALIDATOR",
    "all", "delegate", "undelegate", "begin_redelegate",
    "create_validator", "edit_validator"
]

RewardMsgTypeLiteral = Literal[
    "ALL", "withdraw_reward", "withdraw_commission", "set_withdraw_address",
    "all", "WITHDRAW_REWARD", "WITHDRAW_COMMISSION", "SET_WITHDRAW_ADDRESS"
]

IsAuthzExecLiteral = Literal[
    "ALL", "YES", "NO",
    "all", "yes", "no"
]


class AsyncStakeAPI(BaseAsyncAPI):
    @auto_params()
    async def overview(
        self,
        start_time: Optional[Union[str, datetime]] = None,
        end_time: Optional[Union[str, datetime]] = None,
        freq: Optional[FreqLiteral] = "HOUR",
        fields: Optional[Union[str, List[str]]] = None,
        limit: Optional[int] = None,
        coin: Optional[str] = "lunc",
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        """
        Staking Activities including Delegations, Undelegations, and Redelegations. Updated hourly.

        Args:
            start_time (datetime, optional): Start time (UTC).
            end_time (datetime, optional): End time (UTC).
            freq (AggFreq, optional): Data aggregation frequency. Defaults to HOUR.
            fields (str, optional): Return field filtering, separated by commas.
            coin (str, optional): Coin type. Defaults to 'lunc'.
            limit (int, optional): Max rows to return. Defaults to 100.

        Returns:
            pd.DataFrame: DataFrame containing the stake overview data.
        """
        params['start_time'] = _normalize_datetime(params.get('start_time'))
        params['end_time'] = _normalize_datetime(params.get('end_time'))
        if params.get('freq'):
            params['freq'] = params['freq'].upper()

        return await self._c._get_df(
            "/v1/stake/overview", 
            params=params, 
            parse_dates=["dt"]
        )

    @auto_params()
    async def asset_overview(
        self,
        start_time: Optional[Union[str, datetime]] = None,
        end_time: Optional[Union[str, datetime]] = None,
        asset: Optional[str] = None,
        freq: Optional[FreqLiteral] = "HOUR",
        fields: Optional[Union[str, List[str]]] = None,
        limit: Optional[int] = None,
        coin: Optional[str] = "lunc",
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        """
        Staking Activities including Delegations, Undelegations, and Redelegations. Updated hourly.

        Args:
            start_time (datetime, optional): Start time (UTC).
            end_time (datetime, optional): End time (UTC).
            asset (str, optional): Asset.
            freq (AggFreq, optional): Data aggregation frequency. Defaults to HOUR.
            fields (str, optional): Return field filtering, separated by commas.
            coin (str, optional): Coin type. Defaults to 'lunc'.
            limit (int, optional): Max rows to return. Defaults to 100.

        Returns:
            pd.DataFrame: DataFrame containing the stake overview data.
        """
        params['start_time'] = _normalize_datetime(params.get('start_time'))
        params['end_time'] = _normalize_datetime(params.get('end_time'))
        if params.get('freq'):
            params['freq'] = params['freq'].upper()

        return await self._c._get_df(
            "/v1/stake/assets_info",
            params=params,
            parse_dates=["dt"]
        )

    @auto_params()
    async def validator_list(
        self,
        period: Optional[PeriodLiteral] = "1D",
        validator_addr: Optional[str] = None,
        fields: Optional[Union[str, List[str]]] = None,
        limit: Optional[int] = None,
        coin: Optional[str] = "lunc",
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        """
        Provides detailed validator statistics including uptime, voting power, delegators, and commission rates.

        Args:
            period (PeriodLiteral, optional): Time period for validator statistics. Defaults to '1D'.
            validator_addr (str, optional): Validator operator address.
            fields (str, optional): Return field filtering, separated by commas.
            limit (int, optional): Max rows to return. Defaults to 100.
            coin (str, optional): Coin type. Defaults to 'lunc'.

        Returns:
            pd.DataFrame: DataFrame containing the validator list data.
        """
        if params.get('period'):
            params['period'] = params['period'].upper()

        return await self._c._get_df(
            "/v1/stake/validator_list",
            params=params
        )

    @auto_params()
    async def validator_info(
        self,
        bond_status: Optional[BondStatusLiteral] = "BOND_STATUS_BONDED",
        validator_addr: Optional[str] = None,
        fields: Optional[Union[str, List[str]]] = None,
        limit: Optional[int] = None,
        coin: Optional[str] = "lunc",
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        """
        Provides detailed information for validators, filterable by bond status.

        Args:
            bond_status (BondStatusLiteral, optional): Filter by bond status. Defaults to 'BOND_STATUS_BONDED'.
            validator_addr (str, optional): Validator operator address.
            fields (str, optional): Return field filtering, separated by commas.
            limit (int, optional): Max rows to return. Defaults to 100.
            coin (str, optional): Coin type. Defaults to 'lunc'.

        Returns:
            pd.DataFrame: DataFrame containing the validator detailed info.
        """
        if params.get('bond_status'):
            params['bond_status'] = params['bond_status'].upper()

        return await self._c._get_df(
            "/v1/stake/validator_info",
            params=params,
            parse_dates=["unbonding_time_utc"]
        )

    @auto_params()
    async def validator_delegation_history(
        self,
        validator_addr: str,
        start_time: Optional[Union[str, datetime]] = None,
        end_time: Optional[Union[str, datetime]] = None,
        delegation_type: Optional[DelegationTypeLiteral] = "ALL",
        fields: Optional[Union[str, List[str]]] = None,
        limit: Optional[int] = None,
        coin: Optional[str] = "lunc",
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        """
        Detailed list of delegation-related transactions for a specific validator,
        including delegations, undelegations, and redelegations within a time range.

        Args:
            validator_addr (str): Validator operator address (required).
            start_time (datetime, optional): Start time (UTC).
            end_time (datetime, optional): End time (UTC).
            delegation_type (DelegationTypeLiteral, optional): Transaction message type filter. Defaults to 'ALL'.
            fields (str, optional): Return field filtering, separated by commas.
            limit (int, optional): Max rows to return.
            coin (str, optional): Coin type. Defaults to 'lunc'.

        Returns:
            pd.DataFrame: DataFrame containing the validator delegation history data.
        """
        params['start_time'] = _normalize_datetime(params.get('start_time'))
        params['end_time'] = _normalize_datetime(params.get('end_time'))
        if params.get('delegation_type'):
            params['delegation_type'] = params['delegation_type'].upper()

        return await self._c._get_df(
            "/v1/stake/validator_delegation_history",
            params=params,
            parse_dates=["timestamp_utc"]
        )

    @auto_params()
    async def validator_delegator_list(
        self,
        validator_addr: str,
        rank_start: int = 1,
        rank_end: int = 10,
        fields: Optional[Union[str, List[str]]] = None,
        limit: Optional[int] = None,
        coin: Optional[str] = "lunc",
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        """
        Provides a ranked list of delegators for a specific validator, filtered by balance and rank range.

        Args:
            validator_addr (str): Validator operator address (required).
            rank_start (int, optional): Starting rank. Defaults to 1.
            rank_end (int, optional): Ending rank. Defaults to 10.
            fields (str, optional): Return field filtering, separated by commas.
            limit (int, optional): Max rows to return. If not provided, it will be calculated from rank_end - rank_start + 1.
            coin (str, optional): Coin type. Defaults to 'lunc'.

        Returns:
            pd.DataFrame: DataFrame containing the validator delegator list data.
        """
        if params.get('limit') is None:
            params['limit'] = params.get('rank_end') - params.get('rank_start') + 1

        return await self._c._get_df(
            "/v1/stake/delegator_list",
            params=params
        )

    @auto_params()
    async def validator_vote_history(
        self,
        validator_addr: str,
        fields: Optional[Union[str, List[str]]] = None,
        limit: Optional[int] = None,
        coin: Optional[str] = "lunc",
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        """
        Provides the voting history for a specific validator on governance proposals,
        including vote options and proposal status.

        Args:
            validator_addr (str): Validator operator address (required).
            fields (str, optional): Return field filtering, separated by commas.
            limit (int, optional): Max rows to return. Defaults to 100.
            coin (str, optional): Coin type. Defaults to 'lunc'.

        Returns:
            pd.DataFrame: DataFrame containing the validator vote history data.
        """
        return await self._c._get_df(
            "/v1/stake/validator_vote_history",
            params=params,
            parse_dates=["vote_time_utc", "voting_end_time_utc"]
        )

    @auto_params()
    async def validator_performance(
        self,
        validator_addr: str,
        period: Optional[PeriodLiteral] = "7D",
        freq: Optional[FreqLiteral] = "HOUR",
        fields: Optional[Union[str, List[str]]] = None,
        limit: Optional[int] = None,
        coin: Optional[str] = "lunc",
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        """
        Provides historical performance metrics for a specific validator,
        including block signing uptime and oracle voting performance, grouped by hour or day.

        Args:
            validator_addr (str): Validator operator address (required).
            period (PeriodLiteral, optional): Time period for performance statistics. Defaults to '7D'.
            freq (FreqLiteral, optional): Frequency of data points (HOUR or DAY). Defaults to 'HOUR'.
            fields (str, optional): Return field filtering, separated by commas.
            limit (int, optional): Max rows to return. Defaults to 100.
            coin (str, optional): Coin type. Defaults to 'lunc'.

        Returns:
            pd.DataFrame: DataFrame containing the validator performance data.
        """
        if params.get('period'):
            params['period'] = params['period'].upper()
        if params.get('freq'):
            params['freq'] = params['freq'].upper()

        return await self._c._get_df(
            "/v1/stake/validator_performance",
            params=params,
            parse_dates=["block_time_utc"]
        )

    @auto_params()
    async def stake_txs_details(
        self,
        start_time: Optional[Union[str, datetime]] = None,
        end_time: Optional[Union[str, datetime]] = None,
        tx_hash: Optional[str] = None,
        address: Optional[str] = None,
        msg_type: Optional[StakingMsgTypeLiteral] = "ALL",
        is_authz_exec: Optional[IsAuthzExecLiteral] = "ALL",
        code: Optional[int] = 0,
        page: Optional[int] = 1,
        page_size: Optional[int] = 20,
        fields: Optional[Union[str, List[str]]] = None,
        limit: Optional[int] = None,
        coin: Optional[str] = "lunc",
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        """
        Detailed information about staking transactions including delegations, undelegations, and redelegations.
        Updated hourly.

        Args:
            start_time (datetime, optional): Start time (UTC).
            end_time (datetime, optional): End time (UTC).
            tx_hash (str, optional): Transaction hash identifier.
            address (str, optional): Address of delegator, validator, or source validator.
            msg_type (StakingMsgTypeLiteral, optional): Message type filter. Defaults to 'ALL'.
            is_authz_exec (IsAuthzExecLiteral, optional): Filter by whether executed via Authz. Defaults to 'ALL'.
            code (int, optional): Transaction response code (0 for success). Defaults to 0.
            page (int, optional): Page number. Defaults to 1.
            page_size (int, optional): Page size. Defaults to 20.
            fields (str, optional): Return field filtering, separated by commas.
            limit (int, optional): Max rows to return. Defaults to 100.
            coin (str, optional): Coin type. Defaults to 'lunc'.

        Returns:
            pd.DataFrame: DataFrame containing the staking transaction details.
        """
        params['start_time'] = _normalize_datetime(params.get('start_time'))
        params['end_time'] = _normalize_datetime(params.get('end_time'))
        if params.get('msg_type'):
            params['msg_type'] = params['msg_type'].upper()
        if params.get('is_authz_exec'):
            params['is_authz_exec'] = params['is_authz_exec'].upper()

        return await self._c._get_df(
            "/v1/stake/tx_details",
            params=params,
            parse_dates=["timestamp_utc"]
        )

    @auto_params()
    async def reward_txs_details(
        self,
        start_time: Optional[Union[str, datetime]] = None,
        end_time: Optional[Union[str, datetime]] = None,
        asset: Optional[str] = None,
        tx_hash: Optional[str] = None,
        address: Optional[str] = None,
        msg_type: Optional[RewardMsgTypeLiteral] = "ALL",
        is_authz_exec: Optional[IsAuthzExecLiteral] = "ALL",
        code: Optional[int] = 0,
        page: Optional[int] = 1,
        page_size: Optional[int] = 20,
        fields: Optional[Union[str, List[str]]] = None,
        limit: Optional[int] = None,
        coin: Optional[str] = "lunc",
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        """
        Detailed information about reward withdrawal transactions including rewards and commissions.
        Updated hourly.

        Args:
            start_time (datetime, optional): Start time (UTC).
            end_time (datetime, optional): End time (UTC).
            asset (str, optional): Token identifier: denom or symbol (e.g., LUNC, USTC, uluna, uusd). Defaults to 'LUNC'.
            tx_hash (str, optional): Transaction hash identifier.
            address (str, optional): Address of delegator or validator.
            msg_type (RewardMsgTypeLiteral, optional): Action type filter. Defaults to 'ALL'.
            is_authz_exec (IsAuthzExecLiteral, optional): Filter by whether executed via Authz. Defaults to 'ALL'.
            code (int, optional): Transaction response code (0 for success). Defaults to 0.
            page (int, optional): Page number. Defaults to 1.
            page_size (int, optional): Page size. Defaults to 20.
            fields (str, optional): Return field filtering, separated by commas.
            limit (int, optional): Max rows to return. Defaults to 100.
            coin (str, optional): Coin type. Defaults to 'lunc'.

        Returns:
            pd.DataFrame: DataFrame containing the reward transaction details.
        """
        params['start_time'] = _normalize_datetime(params.get('start_time'))
        params['end_time'] = _normalize_datetime(params.get('end_time'))
        if params.get('msg_type'):
            params['msg_type'] = params['msg_type'].upper()
        if params.get('is_authz_exec'):
            params['is_authz_exec'] = params['is_authz_exec'].upper()

        return await self._c._get_df(
            "/v1/stake/reward_tx_details",
            params=params,
            parse_dates=["timestamp_utc"]
        )


class StakeAPI(AsyncStakeAPI):
    @sync_bind(AsyncStakeAPI.overview)
    def overview(
        self,
        start_time: Optional[Union[str, datetime]] = None,
        end_time: Optional[Union[str, datetime]] = None,
        freq: Optional[FreqLiteral] = "HOUR",
        fields: Optional[Union[str, List[str]]] = None,
        limit: Optional[int] = None,
        coin: Optional[str] = "lunc",
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        pass

    overview.__doc__ = AsyncStakeAPI.overview.__doc__
    @sync_bind(AsyncStakeAPI.asset_overview)
    def asset_overview(
        self,
        start_time: Optional[Union[str, datetime]] = None,
        end_time: Optional[Union[str, datetime]] = None,
        asset: Optional[str] = None,
        freq: Optional[FreqLiteral] = "HOUR",
        fields: Optional[Union[str, List[str]]] = None,
        limit: Optional[int] = None,
        coin: Optional[str] = "lunc",
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        pass
    asset_overview.__doc__ = AsyncStakeAPI.asset_overview.__doc__

    @sync_bind(AsyncStakeAPI.validator_list)
    def validator_list(
        self,
        period: Optional[PeriodLiteral] = "1D",
        validator_addr: Optional[str] = None,
        fields: Optional[Union[str, List[str]]] = None,
        limit: Optional[int] = None,
        coin: Optional[str] = "lunc",
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        pass

    validator_list.__doc__ = AsyncStakeAPI.validator_list.__doc__

    @sync_bind(AsyncStakeAPI.validator_info)
    def validator_info(
        self,
        bond_status: Optional[BondStatusLiteral] = "BOND_STATUS_BONDED",
        validator_addr: Optional[str] = None,
        fields: Optional[Union[str, List[str]]] = None,
        limit: Optional[int] = None,
        coin: Optional[str] = "lunc",
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        pass

    validator_info.__doc__ = AsyncStakeAPI.validator_info.__doc__

    @sync_bind(AsyncStakeAPI.validator_delegation_history)
    def validator_delegation_history(
        self,
        validator_addr: str,
        start_time: Optional[Union[str, datetime]] = None,
        end_time: Optional[Union[str, datetime]] = None,
        delegation_type: Optional[DelegationTypeLiteral] = "ALL",
        fields: Optional[Union[str, List[str]]] = None,
        limit: Optional[int] = None,
        coin: Optional[str] = "lunc",
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        pass

    validator_delegation_history.__doc__ = AsyncStakeAPI.validator_delegation_history.__doc__

    @sync_bind(AsyncStakeAPI.validator_delegator_list)
    def validator_delegator_list(
        self,
        validator_addr: str,
        rank_start: int = 1,
        rank_end: int = 10,
        fields: Optional[Union[str, List[str]]] = None,
        limit: Optional[int] = None,
        coin: Optional[str] = "lunc",
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        pass

    validator_delegator_list.__doc__ = AsyncStakeAPI.validator_delegator_list.__doc__

    @sync_bind(AsyncStakeAPI.validator_vote_history)
    def validator_vote_history(
        self,
        validator_addr: str,
        fields: Optional[Union[str, List[str]]] = None,
        limit: Optional[int] = None,
        coin: Optional[str] = "lunc",
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        pass

    validator_vote_history.__doc__ = AsyncStakeAPI.validator_vote_history.__doc__

    @sync_bind(AsyncStakeAPI.validator_performance)
    def validator_performance(
        self,
        validator_addr: str,
        period: Optional[PeriodLiteral] = "7D",
        freq: Optional[FreqLiteral] = "HOUR",
        fields: Optional[Union[str, List[str]]] = None,
        limit: Optional[int] = None,
        coin: Optional[str] = "lunc",
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        pass

    validator_performance.__doc__ = AsyncStakeAPI.validator_performance.__doc__

    @sync_bind(AsyncStakeAPI.stake_txs_details)
    def stake_txs_details(
        self,
        start_time: Optional[Union[str, datetime]] = None,
        end_time: Optional[Union[str, datetime]] = None,
        tx_hash: Optional[str] = None,
        address: Optional[str] = None,
        msg_type: Optional[StakingMsgTypeLiteral] = "ALL",
        is_authz_exec: Optional[IsAuthzExecLiteral] = "ALL",
        code: Optional[int] = 0,
        page: Optional[int] = 1,
        page_size: Optional[int] = 20,
        fields: Optional[Union[str, List[str]]] = None,
        limit: Optional[int] = None,
        coin: Optional[str] = "lunc",
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        pass

    stake_txs_details.__doc__ = AsyncStakeAPI.stake_txs_details.__doc__

    @sync_bind(AsyncStakeAPI.reward_txs_details)
    def reward_txs_details(
        self,
        start_time: Optional[Union[str, datetime]] = None,
        end_time: Optional[Union[str, datetime]] = None,
        asset: Optional[str] = None,
        tx_hash: Optional[str] = None,
        address: Optional[str] = None,
        msg_type: Optional[RewardMsgTypeLiteral] = "ALL",
        is_authz_exec: Optional[IsAuthzExecLiteral] = "ALL",
        code: Optional[int] = 0,
        page: Optional[int] = 1,
        page_size: Optional[int] = 20,
        fields: Optional[Union[str, List[str]]] = None,
        limit: Optional[int] = None,
        coin: Optional[str] = "lunc",
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        pass

    reward_txs_details.__doc__ = AsyncStakeAPI.reward_txs_details.__doc__
