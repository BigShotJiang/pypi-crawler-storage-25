from datetime import datetime
from typing import Union, Optional, List
import pandas as pd
from terra_classic_sdk.core import AccAddress
from terra_classic_sdk.core.auth import Account, LazyGradedVestingAccount
from ._common import _normalize_datetime, FreqLiteral
from .._params_decorator import auto_params

from .._base import BaseAsyncAPI, sync_bind

__all__ = ["AsyncAccountAPI", "AccountAPI"]


class AsyncAccountAPI(BaseAsyncAPI):
    @auto_params()
    async def rich_list(
        self,
        denom: str = "uluna",
        rank_start: int = 1,
        rank_end: int = 10,
        limit: Optional[int] = None,
        fields: Optional[Union[str, List[str]]] = None,
        coin: Optional[str] = 'lunc',
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        """Retrieve account rankings based on on-chain balances.

        Args:
            denom (str, optional): The token type. Defaults to "uluna".
            rank_start (int, optional): Starting rank. Defaults to 1.
            rank_end (int, optional): Ending rank. Defaults to 10.
            limit (int, optional): Max rows to return. If not provided, it will be calculated from rank_end - rank_start + 1.
            fields (str, optional): Comma-separated fields to return.

        Returns:
            pd.DataFrame: DataFrame containing the rich list data.
        """
        
        if params.get('limit') is None:
            params['limit'] = params.get('rank_end') - params.get('rank_start') + 1

        return await self._c._get_df(
            "/v1/account/rich_list", 
            params=params, 
            parse_dates=["lst_act_time"]
        )

    @auto_params()
    async def module_accounts(
        self,
        fields: Optional[Union[str, List[str]]] = None,
        limit: Optional[int] = None,
        coin: Optional[str] = 'lunc',
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        """Retrieve module accounts list with balance changes.

        Args:
            fields (str, optional): Return field filtering, separated by commas.
            limit (int, optional): Max rows to return. Defaults to 100.

        Returns:
            pd.DataFrame: DataFrame containing the module accounts data.
        """
        return await self._c._get_df(
            "/v1/account/module_accounts",
            params=params
        )

    @auto_params()
    async def batch_info(
        self,
        addresses: Union[str, List[str]],
        fields: Optional[Union[str, List[str]]] = None,
        limit: Optional[int] = None,
        coin: Optional[str] = 'lunc',
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        """Retrieve detailed information for a list of account addresses.

        Args:
            addresses (Union[str, List[str]]): Wallet addresses. Supports multiple params or comma-separated.
            fields (str, optional): Return field filtering, separated by commas.
            limit (int, optional): Max rows to return. If not provided, it will be adapted based on the number of addresses.

        Returns:
            pd.DataFrame: DataFrame containing the account information.
        """
        
        if params.get('limit') is None:
            if isinstance(params.get('addresses'), list):
                params['limit'] = len(params.get('addresses'))
            else:
                params['limit'] = len(str(params.get('addresses')).split(","))

        return await self._c._get_df(
            "/v1/account/batch_info",
            params=params,
            parse_dates=["lst_act_time"]
        )

    @auto_params()
    async def distribution(
        self,
        denom: str = "uluna",
        custom_bins: Optional[str] = None,
        fields: Optional[Union[str, List[str]]] = None,
        limit: Optional[int] = None,
        coin: Optional[str] = 'lunc',
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        """Retrieve account distribution by balance ranges.

        Args:
            denom (str, optional): The token type corresponding to the balance. Defaults to "uluna".
            custom_bins (str, optional): Comma-separated list of upper bounds for bins, e.g. '10,100,1000'.
            fields (str, optional): Return field filtering, separated by commas.
            limit (int, optional): Max rows to return. Defaults to 100.

        Returns:
            pd.DataFrame: DataFrame containing the account distribution data.
        """

        return await self._c._get_df(
            "/v1/account/distribution",
            params=params
        )

    @auto_params()
    async def activate_overview(
        self,
        start_time: Optional[Union[str, datetime]] = None,
        end_time: Optional[Union[str, datetime]] = None,
        freq: Optional[FreqLiteral] = "HOUR",
        fields: Optional[Union[str, List[str]]] = None,
        limit: Optional[int] = None,
        coin: Optional[str] = 'lunc',
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        """On-chain User Growth & Whale Activity Tracking. Updated hourly.

        Args:
            start_time (str, optional): Start time (UTC).
            end_time (str, optional): End time (UTC).
            freq (str, optional): Data aggregation frequency (HOUR, DAY, WEEK, MONTH, QUARTER, YEAR). Defaults to "HOUR".
            coin (str, optional): Coin type. Defaults to "lunc".
            fields (str, optional): Return field filtering, separated by commas.
            limit (int, optional): Max rows to return. Max 10000 (SDK default).

        Returns:
            pd.DataFrame: DataFrame containing activation overview data.
        """
        params['start_time'] = _normalize_datetime(params.get('start_time'))
        params['end_time'] = _normalize_datetime(params.get('end_time'))
        if params.get('freq'):
            params['freq'] = params['freq'].upper()

        # 预处理函数已经处理了特殊参数
        return await self._c._get_df(
            "/v1/account/activate_overview",
            params=params,
            parse_dates=["dt"]
        )


class AccountAPI(AsyncAccountAPI):
    @sync_bind(AsyncAccountAPI.rich_list)
    def rich_list(
        self,
        denom: str = "uluna",
        rank_start: int = 1,
        rank_end: int = 10,
        limit: Optional[int] = None,
        fields: Optional[Union[str, List[str]]] = None,
        coin: Optional[str] = 'lunc',
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        pass

    rich_list.__doc__ = AsyncAccountAPI.rich_list.__doc__

    @sync_bind(AsyncAccountAPI.module_accounts)
    def module_accounts(
        self,
        fields: Optional[Union[str, List[str]]] = None,
        limit: Optional[int] = None,
        coin: Optional[str] = 'lunc',
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        pass

    module_accounts.__doc__ = AsyncAccountAPI.module_accounts.__doc__

    @sync_bind(AsyncAccountAPI.batch_info)
    def batch_info(
        self,
        addresses: Union[str, List[str]],
        fields: Optional[Union[str, List[str]]] = None,
        limit: Optional[int] = None,
        coin: Optional[str] = 'lunc',
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        pass

    batch_info.__doc__ = AsyncAccountAPI.batch_info.__doc__

    @sync_bind(AsyncAccountAPI.distribution)
    def distribution(
        self,
        denom: str = "uluna",
        custom_bins: Optional[str] = None,
        fields: Optional[Union[str, List[str]]] = None,
        limit: Optional[int] = None,
        coin: Optional[str] = 'lunc',
        params: Optional[dict] = None,

    ) -> pd.DataFrame:
        pass

    distribution.__doc__ = AsyncAccountAPI.distribution.__doc__

    @sync_bind(AsyncAccountAPI.activate_overview)
    def activate_overview(
        self,
        start_time: Optional[Union[str, datetime]] = None,
        end_time: Optional[Union[str, datetime]] = None,
        freq: Optional[FreqLiteral] = "HOUR",
        fields: Optional[Union[str, List[str]]] = None,
        limit: Optional[int] = None,
        coin: Optional[str] = 'lunc',
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        pass

    activate_overview.__doc__ = AsyncAccountAPI.activate_overview.__doc__
