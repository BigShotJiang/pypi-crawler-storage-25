from datetime import datetime
from typing import Optional, List, Union, Literal
import pandas as pd

from .._base import BaseAsyncAPI, sync_bind
from ._common import FreqLiteral, _normalize_datetime
from .._params_decorator import auto_params

__all__ = ["AsyncDexAPI", "DexAPI"]

LiquidityActionLiteral = Literal[
    "ALL", "PROVIDE_LIQUIDITY", "WITHDRAW_LIQUIDITY",
    "all", "provide_liquidity", "withdraw_liquidity"
]


class AsyncDexAPI(BaseAsyncAPI):
    @auto_params()
    async def overview(
        self,
        start_time: Optional[Union[str, datetime]] = None,
        end_time: Optional[Union[str, datetime]] = None,
        freq: Optional[FreqLiteral] = "HOUR",
        fields: Optional[Union[str, List[str]]] = None,
        coin: Optional[str] = 'lunc',
        limit: Optional[int] = None,
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        """
        Decentralized Exchange (DEX) metrics including volume, TVL, and liquidity operations. Updated hourly.

        Args:
            start_time (datetime, optional): Start time (UTC).
            end_time (datetime, optional): End time (UTC).
            freq (AggFreq, optional): Data aggregation frequency. Defaults to HOUR.
            fields (str, optional): Return field filtering, separated by commas.
            coin (str, optional): Coin type. Defaults to 'lunc'.
            limit (int, optional): Max rows to return.

        Returns:
            pd.DataFrame: DataFrame containing the DEX overview data.
        """
        params['start_time'] = _normalize_datetime(params.get('start_time'))
        params['end_time'] = _normalize_datetime(params.get('end_time'))
        if params.get('freq'):
            params['freq'] = params['freq'].upper()

        return await self._c._get_df(
            "/v1/dex/overview",
            params=params,
            parse_dates=["dt"]
        )


    @auto_params()
    async def asset_overview(
        self,
        start_time: Optional[Union[str, datetime]] = None,
        end_time: Optional[Union[str, datetime]] = None,
        asset: Optional[str] = None,
        freq: Optional[FreqLiteral] = "HOUR",
        fields: Optional[Union[str, List[str]]] = None,
        coin: Optional[str] = 'lunc',
        limit: Optional[int] = None,
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        """
        Asset Overview for DEX.

        Args:
            start_time (datetime, optional): Start time (UTC).
            end_time (datetime, optional): End time (UTC).
            asset (str, optional): Asset.
            freq (FreqLiteral, optional): Data aggregation frequency. Defaults to HOUR.
            fields (str, optional): Return field filtering, separated by commas.
            coin (str, optional): Coin type. Defaults to 'lunc'.
            limit (int, optional): Max rows to return.

        Returns:
            pd.DataFrame: DataFrame containing the DEX asset overview data.
        """
        params['start_time'] = _normalize_datetime(params.get('start_time'))
        params['end_time'] = _normalize_datetime(params.get('end_time'))
        if params.get('freq'):
            params['freq'] = params['freq'].upper()

        return await self._c._get_df(
            "/v1/dex/assets_info",
            params=params,
            parse_dates=["dt"]
        )

    @auto_params()
    async def pool_depth(
        self,
        pair_addr: Optional[str] = None,
        asset: Optional[str] = "LUNC",
        fields: Optional[Union[str, List[str]]] = None,
        coin: Optional[str] = 'lunc',
        limit: Optional[int] = None,
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        """
        Current liquidity depth and relative prices for DEX trading pairs.

        Args:
            pair_addr (str, optional): Specific pair address for precise query.
            asset (str, optional): Token identifier: denom or symbol (e.g., LUNC, USTC, uluna, uusd). Defaults to "LUNC".
            fields (str, optional): Return field filtering, separated by commas.
            coin (str, optional): Coin type. Defaults to 'lunc'.
            limit (int, optional): Max rows to return.

        Returns:
            pd.DataFrame: DataFrame containing the DEX pool depth data.
        """
        return await self._c._get_df(
            "/v1/dex/pool_depth",
            params=params
        )

    @auto_params()
    async def swap_txs_details(
        self,
        start_time: Optional[Union[str, datetime]] = None,
        end_time: Optional[Union[str, datetime]] = None,
        tx_hash: Optional[str] = None,
        address: Optional[str] = None,
        code: Optional[int] = 0,
        swap_asset: Optional[str] = None,
        fields: Optional[Union[str, List[str]]] = None,
        coin: Optional[str] = 'lunc',
        limit: Optional[int] = None,
        page: Optional[int] = None,
        page_size: Optional[int] = None,
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        """
        Detailed information about DEX swap transactions. Updated hourly.

        Args:
            start_time (Union[str, datetime], optional): Start time (UTC).
            end_time (Union[str, datetime], optional): End time (UTC).
            tx_hash (str, optional): Transaction hash.
            address (str, optional): Address (pair, sender or receiver).
            code (int, optional): Transaction response code (0 for success). Defaults to 0.
            swap_asset (str, optional): Swap asset identifier: denom or symbol.
            fields (Union[str, List[str]], optional): Return field filtering, separated by commas.
            coin (str, optional): Coin type. Defaults to 'lunc'.
            limit (int, optional): Max rows to return.
            page (int, optional): Page number.
            page_size (int, optional): Page size.

        Returns:
            pd.DataFrame: DataFrame containing the DEX swap transaction details.
        """
        params['start_time'] = _normalize_datetime(params.get('start_time'))
        params['end_time'] = _normalize_datetime(params.get('end_time'))

        return await self._c._get_df(
            "/v1/dex/tx_details",
            params=params,
            parse_dates=["timestamp_utc"]
        )

    @auto_params()
    async def liquidity_txs_details(
        self,
        start_time: Optional[Union[str, datetime]] = None,
        end_time: Optional[Union[str, datetime]] = None,
        tx_hash: Optional[str] = None,
        address: Optional[str] = None,
        code: Optional[int] = 0,
        oper_asset: Optional[str] = None,
        action: Optional[LiquidityActionLiteral] = "ALL",
        fields: Optional[Union[str, List[str]]] = None,
        coin: Optional[str] = 'lunc',
        limit: Optional[int] = None,
        page: Optional[int] = None,
        page_size: Optional[int] = None,
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        """
        Detailed records of liquidity provision and withdrawal operations. Updated hourly.

        Args:
            start_time (Union[str, datetime], optional): Start time (UTC).
            end_time (Union[str, datetime], optional): End time (UTC).
            tx_hash (str, optional): Transaction hash.
            address (str, optional): Address (pair or provider).
            code (int, optional): Transaction response code (0 for success). Defaults to 0.
            oper_asset (str, optional): Liquidity asset identifier: denom or symbol.
            action (LiquidityActionLiteral, optional): Liquidity operation type (ALL, PROVIDE_LIQUIDITY, WITHDRAW_LIQUIDITY). Defaults to "ALL".
            fields (Union[str, List[str]], optional): Return field filtering, separated by commas.
            coin (str, optional): Coin type. Defaults to 'lunc'.
            limit (int, optional): Max rows to return.
            page (int, optional): Page number.
            page_size (int, optional): Page size.

        Returns:
            pd.DataFrame: DataFrame containing the DEX liquidity transaction details.
        """
        params['start_time'] = _normalize_datetime(params.get('start_time'))
        params['end_time'] = _normalize_datetime(params.get('end_time'))
        if params.get('action'):
            params['action'] = params['action'].upper()

        return await self._c._get_df(
            "/v1/dex/liquidity_details",
            params=params,
            parse_dates=["timestamp_utc"]
        )


class DexAPI(AsyncDexAPI):
    @sync_bind(AsyncDexAPI.overview)
    def overview(
        self,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None,
        freq: Optional[FreqLiteral] = "HOUR",
        fields: Optional[Union[str, List[str]]] = None,
        coin: Optional[str] = 'lunc',
        limit: Optional[int] = None,
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        pass

    overview.__doc__ = AsyncDexAPI.overview.__doc__

    @sync_bind(AsyncDexAPI.asset_overview)
    def asset_overview(
        self,
        start_time: Optional[Union[str, datetime]] = None,
        end_time: Optional[Union[str, datetime]] = None,
        asset: Optional[str] = None,
        freq: Optional[FreqLiteral] = "HOUR",
        fields: Optional[Union[str, List[str]]] = None,
        coin: Optional[str] = 'lunc',
        limit: Optional[int] = None,
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        pass

    asset_overview.__doc__ = AsyncDexAPI.asset_overview.__doc__

    @sync_bind(AsyncDexAPI.pool_depth)
    def pool_depth(
        self,
        pair_addr: Optional[str] = None,
        asset: Optional[str] = "LUNC",
        fields: Optional[Union[str, List[str]]] = None,
        coin: Optional[str] = 'lunc',
        limit: Optional[int] = None,
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        pass

    pool_depth.__doc__ = AsyncDexAPI.pool_depth.__doc__

    @sync_bind(AsyncDexAPI.swap_txs_details)
    def swap_txs_details(
        self,
        start_time: Optional[Union[str, datetime]] = None,
        end_time: Optional[Union[str, datetime]] = None,
        tx_hash: Optional[str] = None,
        address: Optional[str] = None,
        code: Optional[int] = 0,
        swap_asset: Optional[str] = None,
        fields: Optional[Union[str, List[str]]] = None,
        coin: Optional[str] = 'lunc',
        limit: Optional[int] = None,
        page: Optional[int] = None,
        page_size: Optional[int] = None,
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        pass

    swap_txs_details.__doc__ = AsyncDexAPI.swap_txs_details.__doc__

    @sync_bind(AsyncDexAPI.liquidity_txs_details)
    def liquidity_txs_details(
        self,
        start_time: Optional[Union[str, datetime]] = None,
        end_time: Optional[Union[str, datetime]] = None,
        tx_hash: Optional[str] = None,
        address: Optional[str] = None,
        code: Optional[int] = 0,
        oper_asset: Optional[str] = None,
        action: Optional[LiquidityActionLiteral] = "ALL",
        fields: Optional[Union[str, List[str]]] = None,
        coin: Optional[str] = 'lunc',
        limit: Optional[int] = None,
        page: Optional[int] = None,
        page_size: Optional[int] = None,
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        pass

    liquidity_txs_details.__doc__ = AsyncDexAPI.liquidity_txs_details.__doc__
