from typing import Literal
from datetime import datetime
from typing import Optional, Union
import pandas as pd

FreqLiteral = Literal[
    "HOUR", "DAY", "WEEK", "QUARTER", "MONTH", "YEAR",
    "hour", "day", "week", "quarter", "month", "year"
]

AssetTypeLiteral = Literal[
    "ALL", "NATIVE", "IBC", "CW20",
    "all", "native", "ibc", "cw20"
]


DirectionLiteral = Literal[
    "ALL", "IN", "OUT",
    "all", "in", "out"
]


def _normalize_datetime(dt_input: Union[str, datetime, pd.Timestamp, None]) -> Optional[str]:
    if dt_input is None:
        return None

    dt = pd.to_datetime(dt_input)

    if dt.tzinfo is None:
        dt = dt.tz_localize("UTC")
    else:
        dt = dt.tz_convert("UTC")

    return dt.strftime("%Y-%m-%dT%H:%M:%SZ")