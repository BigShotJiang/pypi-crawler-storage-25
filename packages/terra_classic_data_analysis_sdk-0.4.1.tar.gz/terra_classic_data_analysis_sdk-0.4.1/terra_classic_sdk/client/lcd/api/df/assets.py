from datetime import datetime
from typing import Optional, Union, List
import pandas as pd

from .._base import BaseAsyncAPI, sync_bind
from ._common import FreqLiteral, AssetTypeLiteral, _normalize_datetime
from .._params_decorator import auto_params

__all__ = ["AsyncAssetAPI", "AssetAPI"]


class AsyncAssetAPI(BaseAsyncAPI):
    @auto_params()
    async def asset_overview(
        self,
        start_time: Optional[Union[str, datetime]] = None,
        end_time: Optional[Union[str, datetime]] = None,
        asset: Optional[str] = None,
        freq: Optional[FreqLiteral] = "HOUR",
        fields: Optional[Union[str, List[str]]] = None,
        limit: Optional[int] = None,
        coin: Optional[str] = "lunc",
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        """
        Staking Activities including Delegations, Undelegations, and Redelegations. Updated hourly.

        Args:
            start_time (datetime, optional): Start time (UTC).
            end_time (datetime, optional): End time (UTC).
            asset (str, optional): Asset.
            freq (AggFreq, optional): Data aggregation frequency. Defaults to HOUR.
            fields (str, optional): Return field filtering, separated by commas.
            coin (str, optional): Coin type. Defaults to 'lunc'.
            limit (int, optional): Max rows to return. Defaults to 100.

        Returns:
            pd.DataFrame: DataFrame containing the stake overview data.
        """
        params['start_time'] = _normalize_datetime(params.get('start_time'))
        params['end_time'] = _normalize_datetime(params.get('end_time'))
        if params.get('freq'):
            params['freq'] = params['freq'].upper()

        return await self._c._get_df(
            "/v1/assets/overview",
            params=params,
            parse_dates=["dt"]
        )

    @auto_params()
    async def assets_list(
        self,
        keyword: Optional[str] = "ustc",
        asset_type: Optional[AssetTypeLiteral] = None,
        fields: Optional[Union[str, List[str]]] = None,
        limit: Optional[int] = None,
        page: Optional[int] = None,
        page_size: Optional[int] = None,
        coin: Optional[str] = "lunc",
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        """
        Full-chain Asset Basic Information. Updated hourly.

        Args:
            keyword (str, optional): Search keyword: supports token name, Denom, or cross-chain hash/contract address. Defaults to "ustc".
            asset_type (AssetTypeLiteral, optional): Asset type filter. Returns all assets if not specified.
            fields (str, optional): Return field filtering, separated by commas.
            limit (int, optional): Max rows to return. Defaults to 100.
            page (int, optional): Page number. Defaults to 1.
            page_size (int, optional): Page size. Defaults to 20.
            coin (str, optional): Coin type. Defaults to 'lunc'.

        Returns:
            pd.DataFrame: DataFrame containing the assets list data.
        """
        if params.get('asset_type'):
            params['asset_type'] = params['asset_type'].upper()

        return await self._c._get_df(
            "/v1/assets/list",
            params=params
        )


class AssetAPI(AsyncAssetAPI):
    @sync_bind(AsyncAssetAPI.asset_overview)
    def asset_overview(
        self,
        start_time: Optional[Union[str, datetime]] = None,
        end_time: Optional[Union[str, datetime]] = None,
        asset: Optional[str] = None,
        freq: Optional[FreqLiteral] = "HOUR",
        fields: Optional[Union[str, List[str]]] = None,
        limit: Optional[int] = None,
        coin: Optional[str] = "lunc",
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        pass
    asset_overview.__doc__ = AsyncAssetAPI.asset_overview.__doc__

    @sync_bind(AsyncAssetAPI.assets_list)
    def assets_list(
        self,
        keyword: Optional[str] = "ustc",
        asset_type: Optional[AssetTypeLiteral] = None,
        fields: Optional[Union[str, List[str]]] = None,
        limit: Optional[int] = None,
        page: Optional[int] = None,
        page_size: Optional[int] = None,
        coin: Optional[str] = "lunc",
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        pass
    assets_list.__doc__ = AsyncAssetAPI.assets_list.__doc__