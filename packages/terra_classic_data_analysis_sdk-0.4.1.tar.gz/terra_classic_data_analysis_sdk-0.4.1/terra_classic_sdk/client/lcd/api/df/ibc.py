from datetime import datetime
from typing import Optional, List, Union, Literal
import pandas as pd

from .._base import BaseAsyncAPI, sync_bind
from ._common import FreqLiteral, DirectionLiteral, _normalize_datetime
from .._params_decorator import auto_params

__all__ = ["AsyncIbcAPI", "IbcAPI"]

MsgTypeLiteral = Literal[
    "ALL", "TRANSFER", "RECV_PACKET",
    "all", "transfer", "recv_packet"
]

class AsyncIbcAPI(BaseAsyncAPI):
    @auto_params()
    async def overview(
        self,
        start_time: Optional[Union[str, datetime]] = None,
        end_time: Optional[Union[str, datetime]] = None,
        freq: Optional[FreqLiteral] = "HOUR",
        fields: Optional[Union[str, List[str]]] = None,
        limit: Optional[int] = None,
        coin: Optional[str] = 'lunc',
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        """
        Network Overview.
        Inter-Blockchain Communication (IBC) transfer metrics including inflow, outflow, and net flow. Updated hourly.

        Args:
            start_time (Union[str, datetime], optional): Start time (UTC).
            end_time (Union[str, datetime], optional): End time (UTC).
            freq (FreqLiteral, optional): Data aggregation frequency (HOUR, DAY, WEEK, MONTH, QUARTER, YEAR). Defaults to "HOUR".
            fields (Union[str, List[str]], optional): Return field filtering, separated by commas.
            limit (int, optional): Max rows to return.
            coin (str, optional): Coin type. Defaults to 'lunc'.

        Returns:
            pd.DataFrame: DataFrame containing IBC metrics.
        """
        params['start_time'] = _normalize_datetime(params.get('start_time'))
        params['end_time'] = _normalize_datetime(params.get('end_time'))
        if params.get('freq'):
            params['freq'] = params['freq'].upper()

        return await self._c._get_df(
            "/v1/ibc/overview",
            params=params,
            parse_dates=["dt"]
        )


    @auto_params()
    async def asset_overview(
        self,
        start_time: Optional[Union[str, datetime]] = None,
        end_time: Optional[Union[str, datetime]] = None,
        asset: Optional[str] = None,
        freq: Optional[FreqLiteral] = "HOUR",
        fields: Optional[Union[str, List[str]]] = None,
        limit: Optional[int] = None,
        coin: Optional[str] = 'lunc',
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        """
        Asset Overview for IBC.

        Args:
            start_time (Union[str, datetime], optional): Start time (UTC).
            end_time (Union[str, datetime], optional): End time (UTC).
            asset (str, optional): Asset.
            freq (FreqLiteral, optional): Data aggregation frequency. Defaults to HOUR.
            fields (Union[str, List[str]], optional): Return field filtering, separated by commas.
            limit (int, optional): Max rows to return.
            coin (str, optional): Coin type. Defaults to 'lunc'.

        Returns:
            pd.DataFrame: DataFrame containing IBC asset overview data.
        """
        params['start_time'] = _normalize_datetime(params.get('start_time'))
        params['end_time'] = _normalize_datetime(params.get('end_time'))
        if params.get('freq'):
            params['freq'] = params['freq'].upper()

        return await self._c._get_df(
            "/v1/ibc/assets_info",
            params=params,
            parse_dates=["dt"]
        )

    @auto_params()
    async def ibc_txs_details(
        self,
        start_time: Optional[Union[str, datetime]] = None,
        end_time: Optional[Union[str, datetime]] = None,
        asset: Optional[str] = None,
        tx_hash: Optional[str] = None,
        address: Optional[str] = None,
        msg_type: Optional[MsgTypeLiteral] = "ALL",
        direction: Optional[DirectionLiteral] = "ALL",
        code: Optional[int] = 0,
        fields: Optional[Union[str, List[str]]] = None,
        limit: Optional[int] = None,
        page: Optional[int] = None,
        page_size: Optional[int] = None,
        coin: Optional[str] = 'lunc',
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        """
        IBC Transaction Details.
        Detailed information about Inter-Blockchain Communication (IBC) transfer transactions. Updated hourly.

        Args:
            start_time (Union[str, datetime], optional): Start time (UTC).
            end_time (Union[str, datetime], optional): End time (UTC).
            asset (str, optional): Asset denom or symbol (e.g., LUNC, USTC, uluna, uusd).
            tx_hash (str, optional): Transaction hash.
            address (str, optional): Send or receive address.
            msg_type (MsgTypeLiteral, optional): Message type (ALL, TRANSFER, RECV_PACKET). Defaults to "ALL".
            direction (DirectionLiteral, optional): IBC flow direction (ALL, IN, OUT). Defaults to "ALL".
            code (int, optional): Transaction response code (0 for success). Defaults to 0.
            fields (Union[str, List[str]], optional): Return field filtering, separated by commas.
            limit (int, optional): Max rows to return.
            page (int, optional): Page number.
            page_size (int, optional): Page size.
            coin (str, optional): Coin type. Defaults to 'lunc'.

        Returns:
            pd.DataFrame: DataFrame containing IBC transaction details.
        """
        params['start_time'] = _normalize_datetime(params.get('start_time'))
        params['end_time'] = _normalize_datetime(params.get('end_time'))
        if params.get('msg_type'):
            params['msg_type'] = params['msg_type'].upper()
        if params.get('direction'):
            params['direction'] = params['direction'].upper()

        return await self._c._get_df(
            "/v1/ibc/tx_details",
            params=params,
            parse_dates=["timestamp_utc"]
        )


class IbcAPI(AsyncIbcAPI):
    @sync_bind(AsyncIbcAPI.overview)
    def overview(
        self,
        start_time: Optional[Union[str, datetime]] = None,
        end_time: Optional[Union[str, datetime]] = None,
        freq: Optional[FreqLiteral] = "HOUR",
        fields: Optional[Union[str, List[str]]] = None,
        limit: Optional[int] = None,
        coin: Optional[str] = 'lunc',
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        pass

    overview.__doc__ = AsyncIbcAPI.overview.__doc__

    @sync_bind(AsyncIbcAPI.asset_overview)
    def asset_overview(
        self,
        start_time: Optional[Union[str, datetime]] = None,
        end_time: Optional[Union[str, datetime]] = None,
        asset: Optional[str] = None,
        freq: Optional[FreqLiteral] = "HOUR",
        fields: Optional[Union[str, List[str]]] = None,
        limit: Optional[int] = None,
        coin: Optional[str] = 'lunc',
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        pass

    asset_overview.__doc__ = AsyncIbcAPI.asset_overview.__doc__

    @sync_bind(AsyncIbcAPI.ibc_txs_details)
    def ibc_txs_details(
        self,
        start_time: Optional[Union[str, datetime]] = None,
        end_time: Optional[Union[str, datetime]] = None,
        asset: Optional[str] = None,
        tx_hash: Optional[str] = None,
        address: Optional[str] = None,
        msg_type: Optional[MsgTypeLiteral] = "ALL",
        direction: Optional[DirectionLiteral] = "ALL",
        code: Optional[int] = 0,
        fields: Optional[Union[str, List[str]]] = None,
        limit: Optional[int] = None,
        page: Optional[int] = None,
        page_size: Optional[int] = None,
        coin: Optional[str] = 'lunc',
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        pass

    ibc_txs_details.__doc__ = AsyncIbcAPI.ibc_txs_details.__doc__
