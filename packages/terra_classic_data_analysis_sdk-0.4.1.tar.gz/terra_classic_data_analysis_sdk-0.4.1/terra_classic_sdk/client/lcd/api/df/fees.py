from datetime import datetime
from typing import Optional, Union, List, Literal
import pandas as pd

from .._base import BaseAsyncAPI, sync_bind
from ._common import FreqLiteral, _normalize_datetime
from .._params_decorator import auto_params

__all__ = ["AsyncFeesAPI", "FeesAPI"]

FeeTypeLiteral = Literal[
    "ALL", "FEE_BURN", "FEE_CP", "FEE_GAS", "FEE_OP",
    "all", "fee_burn", "fee_cp", "fee_gas", "fee_op"
]


class AsyncFeesAPI(BaseAsyncAPI):
    @auto_params()
    async def overview(
        self,
        start_time: Optional[Union[str, datetime]] = None,
        end_time: Optional[Union[str, datetime]] = None,
        freq: Optional[FreqLiteral] = "HOUR",
        fields: Optional[Union[str, List[str]]] = None,
        coin: Optional[str] = 'lunc',
        limit: Optional[int] = None,
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        """
        Network Gas Consumption, Fees, and Pool Incomes. Updated hourly.

        Args:
            start_time (datetime, optional): Start time (UTC). Defaults to 7 days before end_time.
            end_time (datetime, optional): End time (UTC). Defaults to previous hour.
            freq (AggFreq, optional): Data aggregation frequency. Defaults to HOUR.
            fields (str, optional): Return field filtering, separated by commas.
            coin (str, optional): Coin type. Defaults to 'lunc'.
            limit (int, optional): Max rows to return.

        Returns:
            pd.DataFrame: DataFrame containing the fees metrics overview.
        """
        params['start_time'] = _normalize_datetime(params.get('start_time'))
        params['end_time'] = _normalize_datetime(params.get('end_time'))
        if params.get('freq'):
            params['freq'] = params['freq'].upper()

        return await self._c._get_df(
            "/v1/fees/overview",
            params=params,
            parse_dates=["dt"]
        )

    @auto_params()
    async def asset_overview(
        self,
        start_time: Optional[Union[str, datetime]] = None,
        end_time: Optional[Union[str, datetime]] = None,
        asset: Optional[str] = None,
        freq: Optional[FreqLiteral] = "HOUR",
        fields: Optional[Union[str, List[str]]] = None,
        limit: Optional[int] = None,
        coin: Optional[str] = "lunc",
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        """
        Fees overview for a specific asset or all assets. Updated hourly.

        Args:
            start_time (datetime, optional): Start time (UTC).
            end_time (datetime, optional): End time (UTC).
            asset (str, optional): Asset name.
            freq (AggFreq, optional): Data aggregation frequency. Defaults to HOUR.
            fields (str, optional): Return field filtering, separated by commas.
            coin (str, optional): Coin type. Defaults to 'lunc'.
            limit (int, optional): Max rows to return.

        Returns:
            pd.DataFrame: DataFrame containing the fees asset overview.
        """
        params['start_time'] = _normalize_datetime(params.get('start_time'))
        params['end_time'] = _normalize_datetime(params.get('end_time'))
        if params.get('freq'):
            params['freq'] = params['freq'].upper()

        return await self._c._get_df(
            "/v1/fees/assets_info",
            params=params,
            parse_dates=["dt"]
        )

    @auto_params()
    async def fee_txs_details(
        self,
        start_time: Optional[Union[str, datetime]] = None,
        end_time: Optional[Union[str, datetime]] = None,
        asset: Optional[str] = None,
        tx_hash: Optional[str] = None,
        code: Optional[int] = 0,
        fee_type: Optional[FeeTypeLiteral] = "ALL",
        page: Optional[int] = 1,
        page_size: Optional[int] = 20,
        fields: Optional[Union[str, List[str]]] = None,
        limit: Optional[int] = None,
        coin: Optional[str] = "lunc",
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        """
        Detailed transaction fee and tax records. Updated hourly.

        Args:
            start_time (datetime, optional): Start time (UTC).
            end_time (datetime, optional): End time (UTC).
            asset (str, optional): Token identifier: denom or symbol (e.g., LUNC, USTC, uluna, uusd). Defaults to 'LUNC'.
            tx_hash (str, optional): Transaction hash identifier.
            code (int, optional): Transaction response code (0 for success, others for failure). Defaults to 0.
            fee_type (FeeTypeLiteral, optional): Fee type filter. Defaults to 'ALL'.
            page (int, optional): Page number. Defaults to 1.
            page_size (int, optional): Page size. Defaults to 20.
            fields (str, optional): Return field filtering, separated by commas.
            limit (int, optional): Max rows to return.
            coin (str, optional): Coin type. Defaults to 'lunc'.

        Returns:
            pd.DataFrame: DataFrame containing the transaction fee details.
        """
        params['start_time'] = _normalize_datetime(params.get('start_time'))
        params['end_time'] = _normalize_datetime(params.get('end_time'))
        if params.get('fee_type'):
            params['fee_type'] = params['fee_type'].upper()

        return await self._c._get_df(
            "/v1/fees/tx_details",
            params=params,
            parse_dates=["timestamp_utc"]
        )


class FeesAPI(AsyncFeesAPI):
    @sync_bind(AsyncFeesAPI.overview)
    def overview(
        self,
        start_time: Optional[Union[str, datetime]] = None,
        end_time: Optional[Union[str, datetime]] = None,
        freq: Optional[FreqLiteral] = "HOUR",
        fields: Optional[Union[str, List[str]]] = None,
        coin: Optional[str] = 'lunc',
        limit: Optional[int] = None,
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        pass

    overview.__doc__ = AsyncFeesAPI.overview.__doc__

    @sync_bind(AsyncFeesAPI.asset_overview)
    def asset_overview(
        self,
        start_time: Optional[Union[str, datetime]] = None,
        end_time: Optional[Union[str, datetime]] = None,
        asset: Optional[str] = None,
        freq: Optional[FreqLiteral] = "HOUR",
        fields: Optional[Union[str, List[str]]] = None,
        limit: Optional[int] = None,
        coin: Optional[str] = "lunc",
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        pass

    asset_overview.__doc__ = AsyncFeesAPI.asset_overview.__doc__

    @sync_bind(AsyncFeesAPI.fee_txs_details)
    def fee_txs_details(
        self,
        start_time: Optional[Union[str, datetime]] = None,
        end_time: Optional[Union[str, datetime]] = None,
        asset: Optional[str] = None,
        tx_hash: Optional[str] = None,
        code: Optional[int] = 0,
        fee_type: Optional[FeeTypeLiteral] = "ALL",
        page: Optional[int] = 1,
        page_size: Optional[int] = 20,
        fields: Optional[Union[str, List[str]]] = None,
        limit: Optional[int] = None,
        coin: Optional[str] = "lunc",
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        pass

    fee_txs_details.__doc__ = AsyncFeesAPI.fee_txs_details.__doc__
