"""
参数装饰器使用示例
展示如何使用 auto_params 装饰器简化 API 接口开发
"""

from typing import Optional, Union, List
import pandas as pd
from datetime import datetime
from ._params_decorator import auto_params


# 示例1: 基本用法 - 所有参数自动加入 params
class ExampleAPI:
    @auto_params()
    async def simple_method(
        self,
        param1: str = "default1",
        param2: int = 100,
        param3: Optional[str] = None,
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        """
        简单示例：所有参数自动加入 params
        无需手动构建 params 字典
        """
        # params 自动包含: {"param1": "default1", "param2": 100, "param3": None}
        return await self._c._get_df("/endpoint", params=params)


# 示例2: 排除特定参数
class ExampleAPI2:
    @auto_params(exclude_params=['internal_flag'])
    async def method_with_exclusion(
        self,
        public_param: str = "value",
        internal_flag: bool = False,  # 这个参数不会加入 params
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        """
        排除不需要传递给 API 的参数
        """
        # params 只包含: {"public_param": "value"}
        # internal_flag 可用于内部逻辑但不传给 API
        if internal_flag:
            print("Internal processing...")
        
        return await self._c._get_df("/endpoint", params=params)


# 示例3: 使用预处理器处理特殊参数
def preprocess_freq(params: dict) -> dict:
    """预处理函数：将 freq 参数转为大写"""
    if params.get('freq'):
        params['freq'] = params['freq'].upper()
    return params


class ExampleAPI3:
    @auto_params(preprocessor=preprocess_freq)
    async def method_with_preprocessing(
        self,
        freq: str = "hour",
        limit: int = 100,
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        """
        使用预处理器处理需要特殊转换的参数
        """
        # params 中的 freq 已经被转为大写: {"freq": "HOUR", "limit": 100}
        return await self._c._get_df("/endpoint", params=params)


# 示例4: 复杂的预处理逻辑
def complex_preprocessor(params: dict) -> dict:
    """复杂预处理：处理时间、过滤 None 值等"""
    # 处理时间参数
    if params.get('start_time'):
        params['start_time'] = str(params['start_time'])
    if params.get('end_time'):
        params['end_time'] = str(params['end_time'])
    
    # 删除 None 值，让 API 使用默认值
    params = {k: v for k, v in params.items() if v is not None}
    
    return params


class ExampleAPI4:
    @auto_params(preprocessor=complex_preprocessor)
    async def method_with_complex_processing(
        self,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None,
        limit: Optional[int] = None,
        fields: Optional[List[str]] = None,
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        """
        复杂预处理示例
        """
        # 所有处理都在 preprocessor 中完成
        return await self._c._get_df("/endpoint", params=params)


# 示例5: 在方法中进行额外处理
class ExampleAPI5:
    @auto_params()
    async def method_with_post_processing(
        self,
        addresses: Union[str, List[str]],
        limit: Optional[int] = None,
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        """
        在装饰器基础上进行额外处理
        """
        # 装饰器已经构建了基础 params
        # 可以在此基础上进行修改
        if params.get('limit') is None:
            if isinstance(params.get('addresses'), list):
                params['limit'] = len(params.get('addresses'))
            else:
                params['limit'] = len(str(params.get('addresses')).split(","))
        
        return await self._c._get_df("/endpoint", params=params)


# 示例6: 同步方法同样适用
class ExampleAPI6:
    @auto_params()
    def sync_method(
        self,
        param1: str = "value",
        param2: int = 10,
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        """
        同步方法也可以使用相同的装饰器
        """
        # params 自动包含所有参数
        return self._c._get_df_sync("/endpoint", params=params)


"""
使用建议：

1. 基本场景：直接使用 @auto_params()
   - 所有参数自动加入 params
   - 最简单直接的用法

2. 需要排除某些参数：@auto_params(exclude_params=['param_name'])
   - 内部使用的参数不传给 API
   - 保持代码清晰

3. 需要参数转换：@auto_params(preprocessor=your_function)
   - 统一处理参数转换逻辑
   - 可复用的预处理函数

4. 复杂逻辑：装饰器 + 方法内处理
   - 装饰器处理基础参数收集
   - 方法内处理特殊业务逻辑
   - 灵活且清晰

优势：
- 减少重复代码
- 统一的参数处理逻辑
- 易于维护和扩展
- 支持异步和同步方法
"""