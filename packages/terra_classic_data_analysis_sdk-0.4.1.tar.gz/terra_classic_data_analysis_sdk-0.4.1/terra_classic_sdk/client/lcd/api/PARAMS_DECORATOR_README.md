# 通用参数处理装饰器

## 概述

为了简化 API 接口开发，避免在每个方法中重复编写参数收集代码，我们创建了 `auto_params` 装饰器。该装饰器可以自动将函数参数转换为 API 请求的 params 字典。

## 安装和使用

装饰器位于：`terra_classic_sdk.client.lcd.api._params_decorator`

```python
from .._params_decorator import auto_params
```

## 基本用法

### 1. 最简单的用法

所有参数自动加入 params：

```python
@auto_params()
async def my_method(
    self,
    param1: str = "default",
    param2: int = 100,
    param3: Optional[str] = None,
    params: Optional[dict] = None,  # 必须添加此参数
) -> pd.DataFrame:
    # params 自动包含: {"param1": "default", "param2": 100, "param3": None}
    return await self._c._get_df("/endpoint", params=params)
```

**对比传统方式：**

```python
# 传统方式 - 需要手动构建 params
async def my_method(
    self,
    param1: str = "default",
    param2: int = 100,
    param3: Optional[str] = None,
) -> pd.DataFrame:
    params = {
        "param1": param1,
        "param2": param2,
        "param3": param3,
    }
    return await self._c._get_df("/endpoint", params=params)
```

### 2. 排除特定参数

有些参数只用于内部逻辑，不应该传递给 API：

```python
@auto_params(exclude_params=['internal_flag'])
async def my_method(
    self,
    public_param: str = "value",
    internal_flag: bool = False,  # 不会加入 params
    params: Optional[dict] = None,
) -> pd.DataFrame:
    # params 只包含: {"public_param": "value"}
    if internal_flag:
        print("Internal processing...")
    
    return await self._c._get_df("/endpoint", params=params)
```

### 3. 使用预处理器处理特殊参数

当需要对参数进行转换时（如大写转换、时间格式化等）：

```python
def preprocess_freq(params: dict) -> dict:
    """预处理函数：将 freq 参数转为大写"""
    if params.get('freq'):
        params['freq'] = params['freq'].upper()
    return params

@auto_params(preprocessor=preprocess_freq)
async def my_method(
    self,
    freq: str = "hour",
    limit: int = 100,
    params: Optional[dict] = None,
) -> pd.DataFrame:
    # params 中的 freq 已经被转为大写: {"freq": "HOUR", "limit": 100}
    return await self._c._get_df("/endpoint", params=params)
```

### 4. 复杂的预处理逻辑

```python
def complex_preprocessor(params: dict) -> dict:
    """复杂预处理：处理时间、过滤 None 值等"""
    # 处理时间参数
    if params.get('start_time'):
        params['start_time'] = str(params['start_time'])
    if params.get('end_time'):
        params['end_time'] = str(params['end_time'])
    
    # 删除 None 值，让 API 使用默认值
    params = {k: v for k, v in params.items() if v is not None}
    
    return params

@auto_params(preprocessor=complex_preprocessor)
async def my_method(
    self,
    start_time: Optional[datetime] = None,
    end_time: Optional[datetime] = None,
    limit: Optional[int] = None,
    params: Optional[dict] = None,
) -> pd.DataFrame:
    return await self._c._get_df("/endpoint", params=params)
```

### 5. 装饰器 + 方法内处理

对于特别复杂的逻辑，可以结合使用：

```python
@auto_params()
async def batch_info(
    self,
    addresses: Union[str, List[str]],
    limit: Optional[int] = None,
    params: Optional[dict] = None,
) -> pd.DataFrame:
    # 装饰器已经构建了基础 params
    # 在此基础上进行额外处理
    if params.get('limit') is None:
        if isinstance(params.get('addresses'), list):
            params['limit'] = len(params.get('addresses'))
        else:
            params['limit'] = len(str(params.get('addresses')).split(","))
    
    return await self._c._get_df("/endpoint", params=params)
```

## 实际应用示例

查看 [account.py](file:///C:/data/cloud_disk/BaiduSyncdisk/project/git/terra.py/terra_classic_sdk/client/lcd/api/df/account.py) 中的实际使用：

```python
def _preprocess_activate_overview(params: dict) -> dict:
    """预处理 activate_overview 的参数"""
    params['start_time'] = _normalize_datetime(params.get('start_time'))
    params['end_time'] = _normalize_datetime(params.get('end_time'))
    if params.get('freq'):
        params['freq'] = params['freq'].upper()
    return params

class AsyncAccountAPI(BaseAsyncAPI):
    @auto_params(preprocessor=_preprocess_activate_overview)
    async def activate_overview(
        self,
        start_time: Optional[Union[str, datetime]] = None,
        end_time: Optional[Union[str, datetime]] = None,
        freq: Optional[FreqLiteral] = "HOUR",
        fields: Optional[Union[str, List[str]]] = None,
        limit: Optional[int] = None,
        coin: Optional[str] = 'lunc',
        params: Optional[dict] = None,
    ) -> pd.DataFrame:
        # 预处理函数已经处理了特殊参数
        return await self._c._get_df(
            "/v1/account/activate_overview",
            params=params,
            parse_dates=["dt"]
        )
```

## 优势

1. **减少重复代码**：不再需要手动构建 params 字典
2. **统一的参数处理**：所有接口使用相同的参数收集逻辑
3. **易于维护**：修改参数处理逻辑只需修改装饰器
4. **灵活性**：支持排除参数、预处理、后处理等多种场景
5. **兼容性**：同时支持异步和同步方法

## 注意事项

1. **必须添加 `params` 参数**：每个使用装饰器的方法都需要添加 `params: Optional[dict] = None` 参数
2. **参数顺序**：`params` 参数应该放在最后
3. **同步方法**：装饰器同样适用于同步方法，会自动检测并适配
4. **特殊处理**：对于需要特殊处理的参数，建议使用 preprocessor 或在方法内处理

## 最佳实践

1. **简单场景**：直接使用 `@auto_params()`
2. **排除参数**：使用 `@auto_params(exclude_params=['param_name'])`
3. **参数转换**：使用 `@auto_params(preprocessor=your_function)`
4. **复杂逻辑**：装饰器 + 方法内处理相结合

## 相关文件

- 装饰器实现：[_params_decorator.py](file:///C:/data/cloud_disk/BaiduSyncdisk/project/git/terra.py/terra_classic_sdk/client/lcd/api/_params_decorator.py)
- 使用示例：[_params_example.py](file:///C:/data/cloud_disk/BaiduSyncdisk/project/git/terra.py/terra_classic_sdk/client/lcd/api/_params_example.py)
- 实际应用：[account.py](file:///C:/data/cloud_disk/BaiduSyncdisk/project/git/terra.py/terra_classic_sdk/client/lcd/api/df/account.py)