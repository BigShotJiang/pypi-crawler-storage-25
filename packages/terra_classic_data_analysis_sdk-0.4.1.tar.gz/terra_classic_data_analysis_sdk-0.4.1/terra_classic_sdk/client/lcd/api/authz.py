from typing import List, Optional

from terra_classic_sdk.core import AccAddress
from terra_classic_sdk.core.authz import AuthorizationGrant

from ..params import APIParams
from ._base import BaseAsyncAPI, sync_bind

__all__ = ["AsyncAuthzAPI", "AuthzAPI"]


class AsyncAuthzAPI(BaseAsyncAPI):
    async def grants(
            self,
            granter: Optional[AccAddress] = None,
            grantee: Optional[AccAddress] = None,
            msg_type: Optional[str] = None,
            params: Optional[APIParams] = None,
    ) -> List[AuthorizationGrant]:
        """Fetches current active message authorization grants.

        Args:
            granter (AccAddress, optional): granter account address
            grantee (AccAddress, optional): grantee account address
            msg_type (str, optional): message type.
            params (APIParams, optional): additional params for the API like pagination

        Returns:
            List[AuthorizationGrant]: message authorization grants matching criteria
        """
        query_params = {}
        if granter:
            query_params["granter"] = granter
        if grantee:
            query_params["grantee"] = grantee
        if msg_type is not None:
            query_params["msg_type_url"] = msg_type

        if params is not None:
            query_params.update(params)

        res = await self._c._get("/cosmos/authz/v1beta1/grants", query_params)

        grants_data = res.get("grants", [])
        return [AuthorizationGrant.from_data(x) for x in grants_data]


class AuthzAPI(AsyncAuthzAPI):
    @sync_bind(AsyncAuthzAPI.grants)
    def grants(
            self,
            granter: Optional[AccAddress] = None,
            grantee: Optional[AccAddress] = None,
            msg_type: Optional[str] = None,
            params: Optional[APIParams] = None,
    ) -> List[AuthorizationGrant]:
        pass

    grants.__doc__ = AsyncAuthzAPI.grants.__doc__