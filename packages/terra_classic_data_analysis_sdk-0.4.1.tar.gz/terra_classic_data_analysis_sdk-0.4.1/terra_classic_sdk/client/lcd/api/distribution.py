from typing import Dict

import attr

from terra_classic_sdk.core import AccAddress, Coins, ValAddress
from terra_classic_sdk.util.json import JSONSerializable

from ._base import BaseAsyncAPI, sync_bind

__all__ = ["AsyncDistributionAPI", "DistributionAPI", "Rewards", "ValidatorDistributionInfo"]


@attr.s
class Rewards(JSONSerializable):
    rewards: Dict[ValAddress, Coins] = attr.ib()
    """Delegator rewards, indexed by validator operator address."""

    total: Coins = attr.ib()
    """Total sum of rewards."""


@attr.s
class ValidatorDistributionInfo(JSONSerializable):
    operator_address: ValAddress = attr.ib()
    self_bond_rewards: Coins = attr.ib()
    commission: Coins = attr.ib()


class AsyncDistributionAPI(BaseAsyncAPI):
    async def rewards(self, delegator: AccAddress) -> Rewards:
        """Fetches the staking reward data for a delegator.

        Args:
            delegator (AccAddress): delegator account address

        Returns:
            Rewards: delegator rewards
        """
        res = await self._c._get(
            f"/cosmos/distribution/v1beta1/delegators/{delegator}/rewards"
        )
        return Rewards(
            rewards={
                item["validator_address"]: Coins.from_data(item["reward"] or [])
                for item in res["rewards"]
            },
            total=Coins.from_data(res["total"]),
        )

    async def validator_distribution_info(self, validator: ValAddress) -> ValidatorDistributionInfo:
        """Fetches the validator commission and self-delegation rewards for validator.

        Args:
            validator (ValAddress): validator operator address

        Returns:
            ValidatorDistributionInfo: validator distribution info
        """
        res = await self._c._get(
            f"/cosmos/distribution/v1beta1/validators/{validator}"
        )
        return ValidatorDistributionInfo(
            operator_address=res["operator_address"],
            self_bond_rewards=Coins.from_data(res["self_bond_rewards"]),
            commission=Coins.from_data(res["commission"]),
        )

    async def validator_commission(self, validator: ValAddress) -> Coins:
        """Fetches the commission reward data for a validator.

        Args:
            validator (ValAddress): validator operator address

        Returns:
            ValidatorCommission: validator rewards
        """
        res = await self._c._get(
            f"/cosmos/distribution/v1beta1/validators/{validator}/commission"
        )
        commission = res["commission"]
        return Coins.from_data(commission["commission"])

    async def validator_outstanding_rewards(self, validator: ValAddress) -> Coins:
        """Fetches the outstanding reward data for a validator.

        Args:
            validator (ValAddress): validator operator address

        Returns:
            Coins: outstanding rewards for the validator
        """
        res = await self._c._get(
            f"/cosmos/distribution/v1beta1/validators/{validator}/outstanding_rewards"
        )
        rewards=res['rewards']
        return Coins.from_data(rewards["rewards"])

    async def withdraw_address(self, delegator: AccAddress) -> AccAddress:
        """Fetches the withdraw address associated with a delegator.

        Args:
            delegator (AccAddress): delegator account address

        Returns:
            AccAddress: withdraw address
        """
        res = await self._c._get(
            f"/cosmos/distribution/v1beta1/delegators/{delegator}/withdraw_address"
        )
        return res.get("withdraw_address")

    async def community_pool(self) -> Coins:
        """Fetches the community pool.

        Returns:
            Coins: community pool
        """
        res = await self._c._get("/cosmos/distribution/v1beta1/community_pool")
        return Coins.from_data(res.get("pool"))

    async def parameters(self) -> dict:
        """Fetches the Distribution module parameters.

        Returns:
            dict: Distribution module parameters
        """
        res = await self._c._get("/cosmos/distribution/v1beta1/params")
        return res.get("params")


class DistributionAPI(AsyncDistributionAPI):
    @sync_bind(AsyncDistributionAPI.rewards)
    def rewards(self, delegator: AccAddress) -> Rewards:
        pass

    rewards.__doc__ = AsyncDistributionAPI.rewards.__doc__

    @sync_bind(AsyncDistributionAPI.validator_distribution_info)
    def validator_distribution_info(self, validator: ValAddress) -> ValidatorDistributionInfo:
        pass

    validator_distribution_info.__doc__ = AsyncDistributionAPI.validator_distribution_info.__doc__

    @sync_bind(AsyncDistributionAPI.validator_commission)
    def validator_commission(self, validator: ValAddress) -> Coins:
        pass

    validator_commission.__doc__ = AsyncDistributionAPI.validator_commission.__doc__

    @sync_bind(AsyncDistributionAPI.validator_outstanding_rewards)
    def validator_outstanding_rewards(self, validator: ValAddress) -> Coins:
        pass

    validator_outstanding_rewards.__doc__ = AsyncDistributionAPI.validator_outstanding_rewards.__doc__

    @sync_bind(AsyncDistributionAPI.withdraw_address)
    def withdraw_address(self, delegator: AccAddress) -> AccAddress:
        pass

    withdraw_address.__doc__ = AsyncDistributionAPI.withdraw_address.__doc__

    @sync_bind(AsyncDistributionAPI.community_pool)
    def community_pool(self) -> Coins:
        pass

    community_pool.__doc__ = AsyncDistributionAPI.community_pool.__doc__

    @sync_bind(AsyncDistributionAPI.parameters)
    def parameters(self) -> dict:
        pass

    parameters.__doc__ = AsyncDistributionAPI.parameters.__doc__
