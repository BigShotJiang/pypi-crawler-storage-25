from terra_classic_sdk.core.dyncomm import Params, Rate
from terra_classic_sdk.core import ValAddress
from ._base import BaseAsyncAPI, sync_bind

__all__ = ["AsyncDyncommAPI", "DyncommAPI"]

class AsyncDyncommAPI(BaseAsyncAPI):
    async def parameters(self) -> Params:
        """Fetches the Dyncomm module parameters.

        Returns:
            Params: Dyncomm module parameters.
        """
        res = await self._c._get("/terra/dyncomm/v1beta1/params")
        return Params.from_data(res.get("params"))

    async def rate(self, validator_addr: ValAddress) -> Rate:
        """Fetches the Dyncomm rate for a validator.

        Args:
            validator_addr (ValAddress): validator address.

        Returns:
            Rate: Dyncomm rate.
        """
        res = await self._c._get(f"/terra/dyncomm/v1beta1/rate/{validator_addr}")
        return Rate.from_data(res)

class DyncommAPI(AsyncDyncommAPI):
    @sync_bind(AsyncDyncommAPI.parameters)
    def parameters(self) -> Params:
        pass

    parameters.__doc__ = AsyncDyncommAPI.parameters.__doc__

    @sync_bind(AsyncDyncommAPI.rate)
    def rate(self, validator_addr: ValAddress) -> Rate:
        pass

    rate.__doc__ = AsyncDyncommAPI.rate.__doc__
