"""
参数装饰器测试
"""
import asyncio
from typing import Optional, Union, List
from datetime import datetime
from ._params_decorator import auto_params


class MockClient:
    """模拟客户端用于测试"""
    async def _get_df(self, endpoint: str, params: dict = None, **kwargs):
        print(f"Endpoint: {endpoint}")
        print(f"Params: {params}")
        return params


class TestAPI:
    def __init__(self):
        self._c = MockClient()
    
    @auto_params()
    async def test_basic(
        self,
        param1: str = "value1",
        param2: int = 100,
        param3: Optional[str] = None,
        params: Optional[dict] = None,
    ):
        """测试基本用法"""
        return await self._c._get_df("/test/basic", params=params)
    
    @auto_params(exclude_params=['internal_flag'])
    async def test_exclude(
        self,
        public_param: str = "public",
        internal_flag: bool = False,
        params: Optional[dict] = None,
    ):
        """测试排除参数"""
        return await self._c._get_df("/test/exclude", params=params)
    
    @auto_params()
    async def test_post_process(
        self,
        addresses: Union[str, List[str]],
        limit: Optional[int] = None,
        params: Optional[dict] = None,
    ):
        """测试后处理"""
        if params.get('limit') is None:
            if isinstance(params.get('addresses'), list):
                params['limit'] = len(params.get('addresses'))
            else:
                params['limit'] = len(str(params.get('addresses')).split(","))
        return await self._c._get_df("/test/post", params=params)


def preprocess_upper(params: dict) -> dict:
    """预处理：将 value 转为大写"""
    if params.get('value'):
        params['value'] = params['value'].upper()
    return params


class TestAPIWithPreprocessor:
    def __init__(self):
        self._c = MockClient()
    
    @auto_params(preprocessor=preprocess_upper)
    async def test_preprocessor(
        self,
        value: str = "hello",
        params: Optional[dict] = None,
    ):
        """测试预处理器"""
        return await self._c._get_df("/test/pre", params=params)


async def run_tests():
    """运行所有测试"""
    print("=" * 50)
    print("测试1: 基本用法")
    print("=" * 50)
    api1 = TestAPI()
    result1 = await api1.test_basic(param1="test", param2=200)
    print(f"Result: {result1}\n")
    
    print("=" * 50)
    print("测试2: 排除参数")
    print("=" * 50)
    api2 = TestAPI()
    result2 = await api2.test_exclude(public_param="visible", internal_flag=True)
    print(f"Result: {result2}\n")
    
    print("=" * 50)
    print("测试3: 后处理")
    print("=" * 50)
    api3 = TestAPI()
    result3 = await api3.test_post_process(addresses=["addr1", "addr2", "addr3"])
    print(f"Result: {result3}\n")
    
    print("=" * 50)
    print("测试4: 预处理器")
    print("=" * 50)
    api4 = TestAPIWithPreprocessor()
    result4 = await api4.test_preprocessor(value="hello world")
    print(f"Result: {result4}\n")
    
    print("=" * 50)
    print("所有测试完成！")
    print("=" * 50)


if __name__ == "__main__":
    asyncio.run(run_tests())