from typing import List, Optional
from ._base import BaseAsyncAPI, sync_bind
from terra_classic_sdk.core.ibc.data import IdentifiedChannel
from ..params import APIParams

__all__ = ["AsyncIbcAPI", "IbcAPI"]


class AsyncIbcAPI(BaseAsyncAPI):
    async def parameters(self) -> dict:
        """Fetches the Ibc module's parameters.

        Returns:
            List: allowed clients
        """
        res = await self._c._get("/ibc/core/client/v1/params")
        return res["params"]

    async def channels(self, params: Optional[APIParams] = None) -> (List[IdentifiedChannel], dict):
        """Queries all the IBC channels of a chain.

        Args:
            params (APIParams, optional): additional params for the API like pagination

        Returns:
            List[IdentifiedChannel]: list of channels
            dict: pagination info
        """
        res = await self._c._get("/ibc/core/channel/v1/channels", params)
        channels = [IdentifiedChannel.from_data(channel) for channel in res.get("channels", [])]
        return channels, res.get("pagination", {})

    # TODO: functions for clients, connections and channels


class IbcAPI(AsyncIbcAPI):
    @sync_bind(AsyncIbcAPI.parameters)
    def parameters(self) -> dict:
        pass

    parameters.__doc__ = AsyncIbcAPI.parameters.__doc__

    @sync_bind(AsyncIbcAPI.channels)
    def channels(self, params: Optional[APIParams] = None) -> (List[IdentifiedChannel], dict):
        pass

    channels.__doc__ = AsyncIbcAPI.channels.__doc__
