"""
Generic parameter processing decorator module
Automatically converts function parameters to API request parameters
"""
import inspect
from functools import wraps
from typing import Optional, Union, List, Callable


def auto_params(exclude_params: Optional[List[str]] = None, preprocessor: Optional[Callable] = None):
    """
    Decorator: Automatically convert function parameters to params dictionary
    
    Args:
        exclude_params: List of parameter names to exclude (these won't be added to params)
        preprocessor: Preprocessing function that receives params dict and returns processed params
    
    Usage:
        @auto_params()
        async def my_method(self, param1, param2, param3=None):
            # All parameters except self will be automatically added to params
            return await self._c._get_df("/endpoint", params=params)
            
        @auto_params(exclude_params=['special_param'])
        async def my_method(self, param1, special_param, param2=None):
            # special_param won't be added to params
            return await self._c._get_df("/endpoint", params=params)
            
        def custom_preprocessor(params):
            # Custom processing logic
            if params.get('freq'):
                params['freq'] = params['freq'].upper()
            return params
            
        @auto_params(preprocessor=custom_preprocessor)
        async def my_method(self, freq="HOUR"):
            return await self._c._get_df("/endpoint", params=params)
    """
    if exclude_params is None:
        exclude_params = []
    
    def decorator(func):
        @wraps(func)
        async def async_wrapper(*args, **kwargs):
            # 获取函数签名
            sig = inspect.signature(func)
            bound_args = sig.bind(*args, **kwargs)
            bound_args.apply_defaults()
            
            # Build params dictionary, excluding self and specified parameters
            params = {}
            for name, value in bound_args.arguments.items():
                if name != 'self' and name not in exclude_params and name != 'params':
                    params[name] = value
            
            # Apply preprocessing function
            if preprocessor:
                params = preprocessor(params)
            
            # Add params to kwargs for the original function to use
            kwargs['params'] = params
            return await func(*args, **kwargs)
        
        @wraps(func)
        def sync_wrapper(*args, **kwargs):
            # 获取函数签名
            sig = inspect.signature(func)
            bound_args = sig.bind(*args, **kwargs)
            bound_args.apply_defaults()
            
            # Build params dictionary, excluding self and specified parameters
            params = {}
            for name, value in bound_args.arguments.items():
                if name != 'self' and name not in exclude_params and name != 'params':
                    params[name] = value
            
            # Apply preprocessing function
            if preprocessor:
                params = preprocessor(params)
            
            # Add params to kwargs for the original function to use
            kwargs['params'] = params
            return func(*args, **kwargs)
        
        # Determine which wrapper to return based on whether the original function is async
        if inspect.iscoroutinefunction(func):
            return async_wrapper
        else:
            return sync_wrapper
    
    return decorator


def smart_params(default_excludes: Optional[List[str]] = None):
    """
    Smarter parameter processing decorator with more customization options
    
    Args:
        default_excludes: Default list of parameter names to exclude
    
    Usage:
        @smart_params()
        async def my_method(self, param1: str, param2: int = 10, coin: str = 'lunc'):
            # Automatically process parameters, but allows additional processing
            params['coin'] = params.get('coin', 'lunc').upper()  # Can modify parameters
            return await self._c._get_df("/endpoint", params=params)
    """
    if default_excludes is None:
        default_excludes = ['self', 'params']
    
    def decorator(func):
        @wraps(func)
        async def async_wrapper(*args, **kwargs):
            # 获取函数签名
            sig = inspect.signature(func)
            bound_args = sig.bind(*args, **kwargs)
            bound_args.apply_defaults()
            
            # Build params dictionary
            params = {}
            for name, value in bound_args.arguments.items():
                if name not in default_excludes:
                    params[name] = value
            
            # Add params to kwargs for the original function to use
            kwargs['params'] = params
            return await func(*args, **kwargs)
        
        @wraps(func)
        def sync_wrapper(*args, **kwargs):
            # 获取函数签名
            sig = inspect.signature(func)
            bound_args = sig.bind(*args, **kwargs)
            bound_args.apply_defaults()
            
            # Build params dictionary
            params = {}
            for name, value in bound_args.arguments.items():
                if name not in default_excludes:
                    params[name] = value
            
            # Add params to kwargs for the original function to use
            kwargs['params'] = params
            return func(*args, **kwargs)
        
        if inspect.iscoroutinefunction(func):
            return async_wrapper
        else:
            return sync_wrapper
    
    return decorator