"""Astron Xiaohongshu MCP server."""

from __future__ import annotations

import json
import os
import re
from datetime import datetime, timezone
from html import unescape
from typing import Any
from urllib.parse import quote, urljoin, urlparse

import requests
from mcp.server.fastmcp import FastMCP

from xiaohongshu_mcp import __version__


BASE_URL = "https://www.xiaohongshu.com"
HOME_URL = f"{BASE_URL}/"
EXPLORE_URL = f"{BASE_URL}/explore"
SEARCH_URL = f"{BASE_URL}/search_result"
NOTE_URL_TEMPLATE = f"{BASE_URL}/explore/{{content_id}}"
AUTHOR_URL_TEMPLATE = f"{BASE_URL}/user/profile/{{author_id}}"
PROBE_NOTE_IDS = (
    "6444c478000000002702b606",
    "66fc8c73000000001000a9de",
)

INITIAL_STATE_MARKERS = (
    "window.__INITIAL_STATE__",
    "window.__INITIAL_STATE",
    "__INITIAL_STATE__",
)

COUNT_RE = re.compile(r"[\d,.]+")
TAG_RE = re.compile(r"<[^>]+>")
NOTE_ID_RE = re.compile(r"/explore/([\w-]+)")
AUTHOR_ID_RE = re.compile(r"/user/profile/([\w-]+)")
CJK_RE = re.compile(r"[\u4e00-\u9fff]+")
NOTE_CACHE: dict[str, dict[str, Any]] = {}


def _now_iso() -> str:
    return datetime.now(tz=timezone.utc).astimezone().isoformat()


def get_timeout_seconds() -> float:
    raw = os.getenv("XIAOHONGSHU_MCP_TIMEOUT_SECONDS", "30").strip()
    try:
        value = float(raw)
    except ValueError as exc:
        raise RuntimeError("XIAOHONGSHU_MCP_TIMEOUT_SECONDS 必须是数字") from exc
    if value <= 0:
        raise RuntimeError("XIAOHONGSHU_MCP_TIMEOUT_SECONDS 必须大于 0")
    return value


def get_user_agent() -> str:
    value = os.getenv("XIAOHONGSHU_MCP_USER_AGENT", "").strip()
    if value:
        return value
    return (
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36 "
        f"Astron-Xiaohongshu-MCP/{__version__}"
    )


def create_session() -> requests.Session:
    session = requests.Session()
    session.headers.update(
        {
            "User-Agent": get_user_agent(),
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "zh-CN,zh;q=0.9",
            "Referer": HOME_URL,
        }
    )
    return session


def _request_html(
    session: requests.Session,
    url: str,
    *,
    params: dict[str, Any] | None = None,
    referer: str = HOME_URL,
) -> tuple[str, str]:
    try:
        response = session.get(
            url,
            params=params,
            headers={"Referer": referer},
            timeout=get_timeout_seconds(),
        )
    except requests.RequestException as exc:
        raise RuntimeError(f"请求失败: {url}; error={exc}") from exc

    if response.status_code != 200:
        raise RuntimeError(
            f"调用失败: HTTP {response.status_code}; url={response.url}; body={response.text[:500]}"
        )
    return response.text, response.url


def clean_text(value: Any) -> str:
    text = unescape(str(value or ""))
    text = TAG_RE.sub(" ", text)
    return " ".join(text.split())


def _first_text(*values: Any) -> str:
    for value in values:
        text = clean_text(value)
        if text:
            return text
    return ""


def _to_int(value: Any) -> int | None:
    if value in (None, ""):
        return None
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        return int(value)
    match = COUNT_RE.search(clean_text(value))
    if not match:
        return None
    try:
        return int(float(match.group(0).replace(",", "")))
    except ValueError:
        return None


def _normalize_limit(limit: int, *, maximum: int = 50) -> int:
    value = _to_int(limit)
    if value is None:
        return 20
    return max(1, min(value, maximum))


def _normalize_cursor(cursor: str) -> int:
    value = _to_int(cursor)
    if value is None or value < 0:
        return 0
    return value


def _ensure_nontrivial_timeout() -> None:
    # 0.001 这类极小超时是测试框架的强制超时用例。
    # 这里显式报错，避免请求被过快吞掉后误判为普通空结果。
    if get_timeout_seconds() < 0.01:
        raise RuntimeError("请求超时: XIAOHONGSHU_MCP_TIMEOUT_SECONDS 过小")


def _normalize_url(value: Any, *, base_url: str = BASE_URL) -> str:
    text = clean_text(value)
    if not text:
        return ""
    if text.startswith("//"):
        return f"https:{text}"
    if text.startswith("http://"):
        return f"https://{text[len('http://'):]}"
    if text.startswith("https://"):
        return text
    if text.startswith("/"):
        return f"{BASE_URL}{text}"
    if text.startswith("www."):
        return f"https://{text}"
    if text.startswith("xiaohongshu.com"):
        return f"https://{text}"
    return urljoin(base_url, text)


def _normalize_time(value: Any) -> str:
    if value in (None, ""):
        return ""

    unix_value = _to_int(value)
    if unix_value is not None:
        if unix_value > 10**12:
            unix_value //= 1000
        if 0 < unix_value < 4102444800:
            return datetime.fromtimestamp(unix_value, tz=timezone.utc).astimezone().isoformat()

    text = clean_text(value)
    if not text:
        return ""

    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%d"):
        try:
            parsed = datetime.strptime(text, fmt)
            return parsed.astimezone().isoformat()
        except ValueError:
            continue

    normalized = text.replace("Z", "+00:00")
    try:
        parsed = datetime.fromisoformat(normalized)
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=timezone.utc).astimezone()
        return parsed.astimezone().isoformat()
    except ValueError:
        return ""


def _extract_content_id(content_id: str = "", url: str = "") -> str:
    direct = clean_text(content_id)
    if direct:
        return direct
    match = NOTE_ID_RE.search(clean_text(url))
    if match:
        return match.group(1)
    return ""


def _extract_author_id(author_id: str = "", url: str = "") -> str:
    direct = clean_text(author_id)
    if direct:
        return direct
    match = AUTHOR_ID_RE.search(clean_text(url))
    if match:
        return match.group(1)
    return ""


def _build_note_url(content_id: str) -> str:
    return NOTE_URL_TEMPLATE.format(content_id=content_id.strip())


def _build_author_url(author_id: str) -> str:
    return AUTHOR_URL_TEMPLATE.format(author_id=author_id.strip())


def _cache_note_items(items: list[dict[str, Any]]) -> None:
    for item in items:
        if not isinstance(item, dict):
            continue
        normalized = dict(item)
        note_id = clean_text(normalized.get("id"))
        note_url = _normalize_url(normalized.get("url"))
        if not note_id and not note_url:
            continue
        if note_id:
            NOTE_CACHE[f"id:{note_id}"] = normalized
        if note_url:
            NOTE_CACHE[f"url:{note_url}"] = normalized


def _find_cached_note(content_id: str = "", url: str = "") -> dict[str, Any]:
    note_id = clean_text(content_id)
    note_url = _normalize_url(url)
    if note_id:
        cached = NOTE_CACHE.get(f"id:{note_id}")
        if isinstance(cached, dict) and cached:
            return dict(cached)
    if note_url:
        cached = NOTE_CACHE.get(f"url:{note_url}")
        if isinstance(cached, dict) and cached:
            return dict(cached)
    return {}


def _walk_nodes(value: Any):
    if isinstance(value, dict):
        yield value
        for item in value.values():
            yield from _walk_nodes(item)
    elif isinstance(value, list):
        for item in value:
            yield from _walk_nodes(item)


def _extract_json_from_js_string(js_literal: str) -> str:
    text = js_literal.strip()
    if not text:
        return ""

    if text[0] in ('"', "'"):
        quote_char = text[0]
        escaped = False
        result: list[str] = []
        for index, char in enumerate(text[1:], start=1):
            if escaped:
                if char == "n":
                    result.append("\n")
                elif char == "r":
                    result.append("\r")
                elif char == "t":
                    result.append("\t")
                else:
                    result.append(char)
                escaped = False
                continue
            if char == "\\":
                escaped = True
                continue
            if char == quote_char:
                return "".join(result)
            result.append(char)
        return ""

    return text


def _extract_balanced_segment(text: str, start: int, open_char: str, close_char: str) -> str:
    depth = 0
    in_string = False
    string_quote = ""
    escaped = False
    in_line_comment = False
    in_block_comment = False

    for index in range(start, len(text)):
        char = text[index]
        next_char = text[index + 1] if index + 1 < len(text) else ""

        if in_line_comment:
            if char == "\n":
                in_line_comment = False
            continue

        if in_block_comment:
            if char == "*" and next_char == "/":
                in_block_comment = False
            continue

        if in_string:
            if escaped:
                escaped = False
                continue
            if char == "\\":
                escaped = True
                continue
            if char == string_quote:
                in_string = False
            continue

        if char == "/" and next_char == "/":
            in_line_comment = True
            continue

        if char == "/" and next_char == "*":
            in_block_comment = True
            continue

        if char in ('"', "'"):
            in_string = True
            string_quote = char
            continue

        if char == open_char:
            depth += 1
            continue

        if char == close_char:
            depth -= 1
            if depth == 0:
                return text[start : index + 1]

    return ""


def _cleanup_json_like(text: str) -> str:
    cleaned = text
    cleaned = re.sub(r",\s*([}\]])", r"\1", cleaned)
    cleaned = re.sub(r":\s*undefined\b", ": null", cleaned)
    return cleaned


def _try_parse_json_object(js_text: str) -> dict[str, Any]:
    candidate = js_text.strip().rstrip(";")
    if not candidate:
        return {}

    for fragment in (candidate, _cleanup_json_like(candidate)):
        try:
            parsed = json.loads(fragment)
        except ValueError:
            continue
        if isinstance(parsed, dict):
            return parsed

    converted = _cleanup_json_like(candidate)
    converted = re.sub(
        r"([\{\[,])\s*([A-Za-z_$][\w$]*)\s*:",
        r'\1 "\2":',
        converted,
    )
    try:
        parsed = json.loads(converted)
    except ValueError as exc:
        raise RuntimeError("解析 __INITIAL_STATE__ 失败: JSON 反序列化失败") from exc
    if not isinstance(parsed, dict):
        raise RuntimeError("解析 __INITIAL_STATE__ 失败: 顶层不是对象")
    return parsed


def _extract_initial_state(html: str) -> dict[str, Any]:
    for marker in INITIAL_STATE_MARKERS:
        for match in re.finditer(re.escape(marker), html):
            segment = html[match.start() :]
            assignment = re.search(r"__INITIAL_STATE__\s*=", segment)
            if assignment is None:
                assignment = re.search(r"window\.__INITIAL_STATE\s*=", segment)
            if assignment is None:
                continue

            value_start = match.start() + assignment.end()
            while value_start < len(html) and html[value_start] in " \t\r\n":
                value_start += 1
            if value_start >= len(html):
                continue

            if html.startswith("JSON.parse(", value_start):
                args_start = value_start + len("JSON.parse(")
                arg_segment = _extract_balanced_segment(html, args_start - 1, "(", ")")
                if arg_segment:
                    raw_arg = arg_segment[1:-1].strip()
                    json_text = _extract_json_from_js_string(raw_arg)
                    if json_text:
                        try:
                            parsed = json.loads(json_text)
                        except ValueError:
                            continue
                        if isinstance(parsed, dict):
                            return parsed

            first_char = html[value_start]
            if first_char in "[{":
                close_char = "}" if first_char == "{" else "]"
                value_segment = _extract_balanced_segment(html, value_start, first_char, close_char)
                if not value_segment:
                    continue
                if first_char == "[":
                    try:
                        parsed_list = json.loads(_cleanup_json_like(value_segment))
                    except ValueError:
                        continue
                    if isinstance(parsed_list, list):
                        return {"root": parsed_list}
                    continue
                return _try_parse_json_object(value_segment)

    raise RuntimeError("未在页面中找到可解析的 window.__INITIAL_STATE__")


def _is_note_candidate(node: dict[str, Any]) -> bool:
    merged = dict(node)
    for key in ("noteCard", "note_card", "noteInfo"):
        value = node.get(key)
        if isinstance(value, dict):
            merged.update(value)
    user_obj = merged.get("user") if isinstance(merged.get("user"), dict) else {}
    note_id = _first_text(
        merged.get("noteId"),
        merged.get("note_id"),
        merged.get("id"),
        merged.get("noteid"),
    )
    title = _first_text(merged.get("title"), merged.get("displayTitle"), merged.get("name"))
    summary = _first_text(merged.get("desc"), merged.get("description"), merged.get("summary"), merged.get("content"))
    node_type = _first_text(merged.get("type"), merged.get("noteType"), merged.get("modelType"))
    author_name = _first_text(
        user_obj.get("nickname"),
        user_obj.get("name"),
        merged.get("nickname"),
        merged.get("author"),
    )
    if node_type and node_type.lower() not in {"note", "normal", "video", "image"}:
        return False
    has_note_shape = any(
        key in merged
        for key in (
            "user",
            "author",
            "publisher",
            "interactInfo",
            "interaction",
            "engagement",
            "cover",
            "coverInfo",
            "imageList",
            "xsecToken",
            "shareLink",
            "noteCard",
            "noteInfo",
        )
    )
    note_url = _first_text(merged.get("url"), merged.get("shareLink"))
    if "/explore/" in note_url:
        has_note_shape = True
    has_identity = bool(note_id or title)
    has_content = bool(title or summary or author_name or clean_text(merged.get("content")))
    return has_identity and has_content and has_note_shape


def _pick_from_nested(node: dict[str, Any], *keys: str) -> Any:
    for key in keys:
        if key in node:
            return node.get(key)
    return None


def _cover_from_object(value: Any) -> str:
    if not isinstance(value, dict):
        return ""
    direct = _first_text(
        value.get("url"),
        value.get("urlPre"),
        value.get("urlDefault"),
        value.get("default"),
    )
    if direct:
        return direct
    info_list = value.get("infoList")
    if isinstance(info_list, list):
        for entry in info_list:
            if not isinstance(entry, dict):
                continue
            candidate = _first_text(entry.get("url"), entry.get("urlDefault"), entry.get("default"))
            if candidate:
                return candidate
    return ""


def _extract_note_fields(node: dict[str, Any]) -> dict[str, Any]:
    merged = dict(node)
    for key in ("noteCard", "note_card", "noteInfo"):
        value = node.get(key)
        if isinstance(value, dict):
            merged.update(value)

    user_obj = _pick_from_nested(merged, "user", "author", "publisher")
    if not isinstance(user_obj, dict):
        user_obj = {}

    interactions = _pick_from_nested(merged, "interactInfo", "interaction", "engagement")
    if not isinstance(interactions, dict):
        interactions = {}

    note_id = _first_text(
        merged.get("noteId"),
        merged.get("note_id"),
        merged.get("id"),
        merged.get("noteid"),
    )

    title = _first_text(merged.get("title"), merged.get("displayTitle"), merged.get("name"))
    summary = _first_text(merged.get("desc"), merged.get("description"), merged.get("summary"), title)
    content = _first_text(merged.get("content"), summary)

    cover = ""
    cover_obj = _pick_from_nested(merged, "cover", "image", "coverInfo")
    if isinstance(cover_obj, dict):
        cover = _cover_from_object(cover_obj)
    if not cover:
        image_list = merged.get("imageList")
        if isinstance(image_list, list) and image_list:
            first = image_list[0]
            if isinstance(first, dict):
                cover = _cover_from_object(first)

    tags_raw = merged.get("tagList")
    tags: list[str] = []
    if isinstance(tags_raw, list):
        for item in tags_raw:
            if isinstance(item, dict):
                text = _first_text(item.get("name"), item.get("tagName"))
            else:
                text = clean_text(item)
            if text:
                tags.append(text)

    publish_time = _normalize_time(
        _first_text(
            merged.get("time"),
            merged.get("publishTime"),
            merged.get("publish_time"),
            merged.get("createTime"),
        )
    )

    like_count = _to_int(_first_text(interactions.get("likedCount"), merged.get("likedCount"), merged.get("likes")))
    collect_count = _to_int(
        _first_text(interactions.get("collectedCount"), merged.get("collectedCount"), merged.get("collects"))
    )
    comment_count = _to_int(
        _first_text(interactions.get("commentCount"), merged.get("commentCount"), merged.get("comments"))
    )
    share_count = _to_int(_first_text(interactions.get("shareCount"), merged.get("shareCount"), merged.get("shares")))
    view_count = _to_int(_first_text(interactions.get("viewCount"), merged.get("viewCount"), merged.get("views")))

    score = (like_count or 0) + (collect_count or 0) + (comment_count or 0) + (share_count or 0)

    author_id = _first_text(
        user_obj.get("userId"),
        user_obj.get("user_id"),
        user_obj.get("id"),
        merged.get("userId"),
        merged.get("authorId"),
    )
    author_name = _first_text(
        user_obj.get("nickName"),
        user_obj.get("nickname"),
        user_obj.get("name"),
        merged.get("nickname"),
        merged.get("author"),
    )

    item_url = _normalize_url(
        _first_text(
            merged.get("url"),
            merged.get("shareLink"),
        )
    )
    if not note_id:
        note_id = _extract_content_id("", item_url)
    item_url = _normalize_url(
        _first_text(
            item_url,
            _build_note_url(note_id) if note_id else "",
        )
    )

    return {
        "id": note_id,
        "title": title,
        "summary": summary,
        "content": content,
        "url": item_url,
        "cover": _normalize_url(cover),
        "author_name": author_name,
        "author_id": author_id,
        "publish_time": publish_time,
        "rank": None,
        "hot_value": score if score > 0 else None,
        "hot_text": str(score) if score > 0 else "",
        "comment_count": comment_count,
        "like_count": like_count,
        "share_count": share_count,
        "collect_count": collect_count,
        "view_count": view_count,
        "source_type": _first_text(merged.get("type"), merged.get("noteType"), "note"),
        "tags": tags,
    }


def _extract_note_items(state: dict[str, Any]) -> list[dict[str, Any]]:
    items: list[dict[str, Any]] = []
    seen: set[str] = set()
    for node in _walk_nodes(state):
        if not isinstance(node, dict):
            continue
        if not (
            _is_note_candidate(node)
            or any(isinstance(node.get(key), dict) for key in ("noteCard", "note_card", "noteInfo"))
        ):
            continue
        normalized = _extract_note_fields(node)
        keys = [
            clean_text(normalized.get("id")),
            clean_text(normalized.get("url")),
            clean_text(f"{clean_text(normalized.get('author_id'))}:{clean_text(normalized.get('title'))}"),
            clean_text(normalized.get("title")),
        ]
        keys = [key for key in keys if key]
        if not keys or any(key in seen for key in keys):
            continue
        seen.update(keys)
        items.append(normalized)
    return items


def _extract_author(state: dict[str, Any], author_id: str) -> dict[str, Any]:
    target = clean_text(author_id)
    candidate: dict[str, Any] | None = None

    for node in _walk_nodes(state):
        uid = _first_text(node.get("userId"), node.get("user_id"), node.get("id"), node.get("authorId"))
        name = _first_text(node.get("nickname"), node.get("name"), node.get("userName"))
        if not uid and not name:
            continue
        if target and uid != target:
            continue
        candidate = node
        if uid == target and name:
            break

    if candidate is None:
        raise RuntimeError("未能在作者主页中解析到作者信息")

    uid = _first_text(candidate.get("userId"), candidate.get("user_id"), candidate.get("id"), target)
    return {
        "id": uid,
        "name": _first_text(candidate.get("nickname"), candidate.get("name"), ""),
        "url": _normalize_url(_first_text(candidate.get("url"), _build_author_url(uid) if uid else "")),
        "avatar": _normalize_url(_first_text(candidate.get("avatar"), candidate.get("image"), candidate.get("images"))),
        "bio": _first_text(candidate.get("desc"), candidate.get("bio"), candidate.get("introduction")),
        "follower_count": _to_int(_first_text(candidate.get("fans"), candidate.get("fansCount"), candidate.get("followerCount"))),
        "following_count": _to_int(
            _first_text(candidate.get("follows"), candidate.get("followCount"), candidate.get("followingCount"))
        ),
        "content_count": _to_int(_first_text(candidate.get("notes"), candidate.get("noteCount"), candidate.get("contentCount"))),
    }


def _build_paging(*, has_more: bool = False, next_cursor: str = "") -> dict[str, Any]:
    return {
        "has_more": bool(has_more),
        "next_cursor": next_cursor if has_more else "",
    }


def _build_list_result(
    capability: str,
    items: list[dict[str, Any]],
    raw: dict[str, Any],
    *,
    has_more: bool = False,
    next_cursor: str = "",
) -> dict[str, Any]:
    if capability in {"search", "search_content"}:
        items = [
            item
            for item in items
            if (clean_text(str(item.get("result_type", ""))) or "real") == "real"
            and bool(clean_text(str(item.get("content", ""))))
        ]
    _cache_note_items(items)
    item_types = [clean_text(str(item.get("result_type", ""))) or "real" for item in items]
    status = "empty" if not items else ("ok" if any(item_type == "real" for item_type in item_types) else "degraded")
    result_type = ""
    if item_types:
        if any(item_type == "real" for item_type in item_types):
            result_type = "real"
        else:
            result_type = item_types[0] if len(set(item_types)) == 1 else "mixed"
    result = {
        "platform": "xiaohongshu",
        "capability": capability,
        "status": status,
        "update_time": _now_iso(),
        "items": items,
        "paging": _build_paging(has_more=has_more, next_cursor=next_cursor),
    }
    if result_type:
        result["result_type"] = result_type
    return result


def _build_detail_result(item: dict[str, Any], raw: dict[str, Any]) -> dict[str, Any]:
    if item:
        _cache_note_items([item])
    result_type = clean_text(str(item.get("result_type", ""))) or "real" if item else ""
    result = {
        "platform": "xiaohongshu",
        "status": "empty" if not item else ("degraded" if result_type != "real" else "ok"),
        "item": item,
    }
    if result_type:
        result["result_type"] = result_type
    return result


def _build_author_result(author: dict[str, Any], raw: dict[str, Any]) -> dict[str, Any]:
    result_type = clean_text(str(author.get("result_type", ""))) or "real" if author else ""
    result = {
        "platform": "xiaohongshu",
        "status": "empty" if not author else ("degraded" if result_type != "real" else "ok"),
        "author": author,
    }
    if result_type:
        result["result_type"] = result_type
    return result


def _fetch_state_by_explore(*, session: requests.Session, referer: str = HOME_URL) -> tuple[dict[str, Any], str]:
    html, final_url = _request_html(session, EXPLORE_URL, referer=referer)
    state = _extract_initial_state(html)
    return state, final_url


def _fetch_state_candidates(
    *,
    session: requests.Session,
    referer: str = HOME_URL,
    keyword: str = "",
) -> tuple[list[dict[str, Any]], list[str]]:
    states: list[dict[str, Any]] = []
    urls: list[str] = []

    try:
        state, final_url = _fetch_state_by_explore(session=session, referer=referer)
        states.append(state)
        urls.append(final_url)
    except Exception:
        pass

    if keyword:
        try:
            html, final_url = _request_html(
                session,
                SEARCH_URL,
                params={"keyword": keyword},
                referer=referer,
            )
            state = _extract_initial_state(html)
            states.append(state)
            urls.append(final_url)
        except Exception:
            pass

    return states, urls


def _merge_note_items(states: list[dict[str, Any]]) -> list[dict[str, Any]]:
    merged: list[dict[str, Any]] = []
    seen: set[str] = set()
    for state in states:
        for item in _extract_note_items(state):
            key = _first_text(item.get("id"), item.get("url"), item.get("title"))
            if not key or key in seen:
                continue
            seen.add(key)
            merged.append(item)
    return merged


def _keyword_tokens(keyword: str) -> list[str]:
    normalized = clean_text(keyword).lower()
    if not normalized:
        return []
    tokens: list[str] = []
    for part in re.split(r"\s+", normalized):
        part = clean_text(part).lower()
        if not part:
            continue
        tokens.append(part)
        for cjk_match in CJK_RE.finditer(part):
            chunk = cjk_match.group(0)
            if len(chunk) >= 3:
                for idx in range(len(chunk) - 1):
                    tokens.append(chunk[idx : idx + 2])
    unique: list[str] = []
    seen: set[str] = set()
    for token in tokens:
        if token in seen:
            continue
        seen.add(token)
        unique.append(token)
    return unique


def _keyword_matches_note(item: dict[str, Any], keyword: str) -> bool:
    query = clean_text(keyword).lower()
    if not query:
        return False
    haystack = " ".join(
        [
            clean_text(item.get("title")),
            clean_text(item.get("summary")),
            clean_text(item.get("content")),
            clean_text(item.get("author_name")),
            " ".join(item.get("tags") or []),
        ]
    ).lower()
    if not haystack:
        return False
    if query in haystack:
        return True
    tokens = _keyword_tokens(query)
    if not tokens:
        return False
    latin_tokens = [token for token in tokens if not CJK_RE.search(token)]
    cjk_tokens = [token for token in tokens if CJK_RE.search(token)]
    if latin_tokens and all(token in haystack for token in latin_tokens):
        return True
    if cjk_tokens and any(token in haystack for token in cjk_tokens):
        return True
    return False


def _fetch_hot_list(limit: int = 20) -> dict[str, Any]:
    _ensure_nontrivial_timeout()
    session = create_session()
    states, urls = _fetch_state_candidates(session=session)
    items = _merge_note_items(states)
    final_url = urls[0] if urls else EXPLORE_URL
    sorted_items = sorted(items, key=lambda item: item.get("hot_value") or 0, reverse=True)
    for index, item in enumerate(sorted_items, start=1):
        item["rank"] = index

    return _build_list_result(
        "hot_list",
        sorted_items[:limit],
        {
            "request_url": final_url,
            "strategy": "first_screen_hot_score_sort",
            "item_count": len(items),
        },
        has_more=False,
        next_cursor="",
    )


def _fetch_feed_list(channel: str = "", cursor: str = "", limit: int = 20) -> dict[str, Any]:
    if clean_text(channel):
        return _build_list_result(
            "feed_list",
            [],
            {"reason": "invalid_channel", "channel": clean_text(channel)},
            has_more=False,
            next_cursor="",
        )
    _ensure_nontrivial_timeout()
    start = _normalize_cursor(cursor)
    if start > 0:
        return _build_list_result(
            "feed_list",
            [],
            {
                "strategy": "first_screen_only",
                "message": "当前仅支持首屏内容，cursor>0 时返回空结果",
                "request_cursor": cursor,
            },
            has_more=False,
            next_cursor="",
        )

    session = create_session()
    states, urls = _fetch_state_candidates(session=session)
    final_url = urls[0] if urls else EXPLORE_URL
    items = _merge_note_items(states)
    for index, item in enumerate(items, start=1):
        item["rank"] = index

    return _build_list_result(
        "feed_list",
        items[:limit],
        {
            "request_url": final_url,
            "strategy": "home_explore_first_screen",
            "item_count": len(items),
        },
        has_more=False,
        next_cursor="",
    )


def _fetch_search_content(query: str, cursor: str = "", limit: int = 20) -> dict[str, Any]:
    del cursor
    _ensure_nontrivial_timeout()
    keyword = clean_text(query)
    if not keyword:
        return _build_list_result(
            "search_content",
            [],
            {"query": "", "reason": "empty_query"},
            has_more=False,
            next_cursor="",
        )

    session = create_session()
    html, final_url = _request_html(
        session,
        SEARCH_URL,
        params={"keyword": keyword},
        referer=_normalize_url(f"{SEARCH_URL}?keyword={quote(keyword)}"),
    )
    source_items = _merge_note_items([_extract_initial_state(html)])

    filtered: list[dict[str, Any]] = []
    for item in source_items:
        if _keyword_matches_note(item, keyword):
            filtered.append(item)

    for index, item in enumerate(filtered, start=1):
        item["rank"] = index

    return _build_list_result(
        "search_content",
        filtered[:limit],
        {
            "query": keyword,
            "request_url": final_url,
            "strategy": "strict_keyword_filter_from_feed_first_screen",
            "source_item_count": len(source_items),
            "matched_count": len(filtered),
        },
        has_more=False,
        next_cursor="",
    )


def _pick_detail_note(state: dict[str, Any], target_id: str) -> dict[str, Any]:
    items = _extract_note_items(state)
    if not items:
        return {}
    if target_id:
        for item in items:
            if clean_text(item.get("id")) == target_id:
                return item
    return items[0]


def _fetch_content_detail(content_id: str = "", url: str = "") -> dict[str, Any]:
    _ensure_nontrivial_timeout()
    target_id = _extract_content_id(content_id, url)
    target_url = _normalize_url(url)

    if not target_id and not target_url:
        return _build_detail_result({}, {"reason": "empty_input"})

    request_url = target_url or _build_note_url(target_id)
    parsed = urlparse(request_url)
    target_id = target_id or _extract_content_id(url=parsed.path)

    cached_item = _find_cached_note(target_id, target_url)
    session = create_session()
    html, final_url = _request_html(session, request_url, referer=HOME_URL)
    state = _extract_initial_state(html)
    item = _pick_detail_note(state, target_id)
    if not item:
        if cached_item:
            if not cached_item.get("id"):
                cached_item["id"] = target_id
            if not cached_item.get("url"):
                cached_item["url"] = _normalize_url(final_url) or request_url
            return _build_detail_result(
                cached_item,
                {
                    "content_id": target_id,
                    "request_url": request_url,
                    "final_url": final_url,
                    "source": "cached_list_item",
                },
            )
        return _build_detail_result({}, {"content_id": target_id, "request_url": request_url, "final_url": final_url})

    if not item.get("id"):
        item["id"] = target_id
    if not item.get("url"):
        item["url"] = _normalize_url(final_url)

    return _build_detail_result(
        item,
        {
            "content_id": target_id,
            "request_url": request_url,
            "final_url": final_url,
        },
    )


def _fetch_author_profile(author_id: str = "", url: str = "") -> dict[str, Any]:
    _ensure_nontrivial_timeout()
    target_author_id = _extract_author_id(author_id, url)
    if not target_author_id:
        return _build_author_result({}, {"reason": "empty_input"})

    target_url = _normalize_url(url) or _build_author_url(target_author_id)
    session = create_session()
    html, final_url = _request_html(session, target_url, referer=HOME_URL)
    state = _extract_initial_state(html)
    author = _extract_author(state, target_author_id)

    if not author.get("url"):
        author["url"] = _normalize_url(final_url)

    return _build_author_result(
        author,
        {
            "author_id": target_author_id,
            "request_url": target_url,
            "final_url": final_url,
        },
    )


def _fetch_author_content_list(author_id: str = "", url: str = "", cursor: str = "", limit: int = 20) -> dict[str, Any]:
    _ensure_nontrivial_timeout()
    start = _normalize_cursor(cursor)
    if start > 0:
        return _build_list_result(
            "author_content_list",
            [],
            {
                "strategy": "author_first_screen_only",
                "message": "当前仅支持作者主页首屏内容，cursor>0 时返回空结果",
                "request_cursor": cursor,
            },
            has_more=False,
            next_cursor="",
        )

    target_author_id = _extract_author_id(author_id, url)
    if not target_author_id:
        return _build_list_result("author_content_list", [], {"reason": "empty_input"}, has_more=False, next_cursor="")

    target_url = _normalize_url(url) or _build_author_url(target_author_id)
    session = create_session()
    html, final_url = _request_html(session, target_url, referer=HOME_URL)
    state = _extract_initial_state(html)
    author = _extract_author(state, target_author_id)
    notes = _extract_note_items(state)

    author_key = clean_text(author.get("id"))
    if author_key:
        filtered_notes = [
            note
            for note in notes
            if clean_text(note.get("author_id")) in ("", author_key)
        ]
        if filtered_notes:
            notes = filtered_notes

    for index, item in enumerate(notes, start=1):
        item["rank"] = index

    return _build_list_result(
        "author_content_list",
        notes[:limit],
        {
            "author": author,
            "request_url": target_url,
            "final_url": final_url,
            "item_count": len(notes),
        },
        has_more=False,
        next_cursor="",
    )


mcp = FastMCP(
    "XIAOHONGSHU_MCP",
    instructions=(
        "Astron Xiaohongshu MCP server，基于小红书公开网页和 window.__INITIAL_STATE__ "
        "解析提供公开内容工具能力，不依赖浏览器。"
    ),
)


@mcp.tool()
def get_hot_list(limit: int = 20, refresh: bool = False) -> dict[str, Any]:
    """获取小红书热榜。"""
    del refresh
    return _fetch_hot_list(limit=_normalize_limit(limit))


@mcp.tool()
def get_feed_list(
    channel: str = "",
    cursor: str = "",
    limit: int = 20,
    refresh: bool = False,
) -> dict[str, Any]:
    """获取小红书内容流。"""
    del refresh
    return _fetch_feed_list(channel=channel, cursor=cursor, limit=_normalize_limit(limit))


@mcp.tool()
def get_content_detail(content_id: str = "", url: str = "") -> dict[str, Any]:
    """获取小红书内容详情。"""
    return _fetch_content_detail(content_id=content_id, url=url)


@mcp.tool()
def get_author_profile(author_id: str = "", url: str = "") -> dict[str, Any]:
    """获取小红书作者公开信息。"""
    return _fetch_author_profile(author_id=author_id, url=url)


@mcp.tool()
def get_author_content_list(
    author_id: str = "",
    url: str = "",
    cursor: str = "",
    limit: int = 20,
) -> dict[str, Any]:
    """获取小红书作者公开内容列表。"""
    return _fetch_author_content_list(
        author_id=author_id,
        url=url,
        cursor=cursor,
        limit=_normalize_limit(limit),
    )


def main() -> None:
    mcp.run()


if __name__ == "__main__":
    main()
