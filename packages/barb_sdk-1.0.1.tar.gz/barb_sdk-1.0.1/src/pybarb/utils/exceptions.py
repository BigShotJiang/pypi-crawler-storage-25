class ApiError(Exception):
    """
    Custom exception for Barb API errors.

    Attributes:
        status_code (int | None): HTTP status code, if applicable.
        response_body (str | None): Raw response body, if applicable.
    """
    def __init__(self, message: str, status_code: int | None = None, response_body: str | None = None):
        super().__init__(message)
        self.status_code = status_code
        self.response_body = response_body

