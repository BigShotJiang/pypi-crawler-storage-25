import pandas as pd
from functools import wraps
from typing import Any, Callable, Iterable, List, cast


def _get_col_name(default_columns: List[str] | None) -> str:
    """Get column name from defaults or use 'value'."""
    return default_columns[0] if default_columns else "value"


def _single_col_df(value_list: Any, default_columns: List[str] | None) -> pd.DataFrame:
    """Create single column DataFrame."""
    return pd.DataFrame({_get_col_name(default_columns): value_list})


def _process_iterable(value_list: List[Any],
                      default_columns: List[str] | None) -> pd.DataFrame | None:
    """Process iterable and return DataFrame if conditions match, else None."""
    if not value_list:
        return pd.DataFrame(columns=default_columns or [])
    
    if all(isinstance(x, dict) for x in value_list):
        return pd.DataFrame.from_records(value_list)
    
    if all(not isinstance(x, (dict, list, tuple, set)) for x in value_list):
        return _single_col_df(value_list, default_columns)
    
    return None


def _try_construct_df(value: Any, default_columns: List[str] | None) -> pd.DataFrame:
    """Try to construct DataFrame directly, fallback to single column."""
    try:
        return pd.DataFrame(value)
    except Exception:
        return _single_col_df([value], default_columns)


# Define your conversion policy in ONE place
def to_dataframe(value: Any,
                 default_columns: List[str] | None = None,
                 column_name_for_strings: str = "value") -> pd.DataFrame:
    """
    Converts value to a pandas DataFrame using a consistent policy.

    Rules:
    - DataFrame -> returned as-is
    - List[dict] -> DataFrame(records)
    - List[scalar] or tuple -> single column DataFrame
    - Dict -> one-row DataFrame
    - String -> single-column DataFrame with column_name_for_strings
    - None/empty -> empty DataFrame with optional default_columns
    """
    if isinstance(value, pd.DataFrame):
        return cast(pd.DataFrame, cast(object, value))
    
    if value is None:
        return pd.DataFrame(columns=default_columns or [])
    
    if isinstance(value, dict):
        return pd.DataFrame([value])
    
    if isinstance(value, str):
        return pd.DataFrame({column_name_for_strings: [value]})
    
    if isinstance(value, Iterable) and not isinstance(value, (str, bytes, dict)):
        value_list = list(value)
        result = _process_iterable(value_list, default_columns)
        return result if result is not None else _try_construct_df(value_list, default_columns)
    
    return _try_construct_df(value, default_columns)


def to_flat_dataframe(
    value: Any,
    *,
    record_path: str | list[str] | None = None,
    meta: list[str | list[str]] | None = None,
    default_columns: List[str] | None = None,
    column_name_for_strings: str = "value",
    sep: str = ".",
) -> pd.DataFrame:
    """Convert nested JSON-like payloads into a flattened DataFrame.

    - Uses ``pd.json_normalize`` for dict/list payloads.
    - Supports exploding nested list records via ``record_path`` and ``meta``.
    - Falls back to ``to_dataframe`` for scalar/non-JSON-like values.
    """
    if isinstance(value, pd.DataFrame):
        return cast(pd.DataFrame, cast(object, value))

    if value is None:
        return pd.DataFrame(columns=default_columns or [])

    if isinstance(value, str):
        return pd.DataFrame({column_name_for_strings: [value]})

    try:
        if record_path is not None:
            normalize_source = value if isinstance(value, list) else [value]
            return pd.json_normalize(
                normalize_source,
                record_path=record_path,
                meta=meta,
                sep=sep,
            )

        if isinstance(value, (dict, list, tuple)):
            return pd.json_normalize(value, sep=sep)
    except (TypeError, ValueError, KeyError):
        pass

    return to_dataframe(
        value,
        default_columns=default_columns,
        column_name_for_strings=column_name_for_strings,
    )


def ensure_dataframe(default_columns: List[str] | None = None,
                     column_name_for_strings: str = "value") -> Callable:
    """
    Decorator that ensures the wrapped function returns a pandas DataFrame.
    """
    def decorator(fn: Callable) -> Callable:
        @wraps(fn)
        def wrapper(*args, **kwargs) -> pd.DataFrame:
            result = fn(*args, **kwargs)
            return to_dataframe(result, default_columns=default_columns,
                                column_name_for_strings=column_name_for_strings)
        return wrapper
    return decorator