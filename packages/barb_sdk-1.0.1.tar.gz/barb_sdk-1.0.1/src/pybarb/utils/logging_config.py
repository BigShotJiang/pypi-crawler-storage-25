import logging
import os

from dotenv import load_dotenv

DEFAULT_LOG_LEVEL = "INFO"
LOG_LEVEL_ENV_VARS = ("PYBARB_LOG_LEVEL", "BARB_LOG_LEVEL")
_LOG_FORMAT = "%(asctime)s | %(name)s | %(levelname)s | %(message)s"
_LOGGING_INITIALIZED = False


def _resolve_log_level() -> int:
    for env_var in LOG_LEVEL_ENV_VARS:
        configured_level = os.getenv(env_var)
        if configured_level:
            level_name = configured_level.upper()
            level_value = logging.getLevelNamesMapping().get(level_name)
            if isinstance(level_value, int):
                return level_value
    return logging.getLevelNamesMapping()[DEFAULT_LOG_LEVEL]


def _initialize_logging() -> None:
    """Initialize logging lazily on first use (internal use only)."""
    global _LOGGING_INITIALIZED
    if _LOGGING_INITIALIZED:
        return
    
    load_dotenv()
    logger = logging.getLogger("pybarb")
    
    # Remove NullHandler if present and add StreamHandler
    logger.handlers = [h for h in logger.handlers if not isinstance(h, logging.NullHandler)]
    
    if not any(isinstance(h, logging.StreamHandler) for h in logger.handlers):
        handler = logging.StreamHandler()
        handler.setFormatter(logging.Formatter(_LOG_FORMAT))
        logger.addHandler(handler)
    
    logger.setLevel(_resolve_log_level())
    logger.propagate = False
    _LOGGING_INITIALIZED = True


def setup_logging() -> None:
    """Configure the pybarb namespace logger using values from environment/.env."""
    _initialize_logging()


def get_logger(name: str) -> logging.Logger:
    """Return a child logger under the pybarb namespace (auto-initializes logging on first call)."""
    _initialize_logging()
    if name.startswith("pybarb"):
        return logging.getLogger(name)
    return logging.getLogger(f"pybarb.{name}")

