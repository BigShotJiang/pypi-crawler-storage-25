# Connection logic for Barb API
import datetime
import json
import os
import requests
import webbrowser
from urllib.parse import urlparse, parse_qs
from http.server import BaseHTTPRequestHandler, HTTPServer

from dotenv import load_dotenv
from pybarb.constants.errors import CONNECTION_ERROR_MESSAGES, format_http_error
from pybarb.utils.logging_config import get_logger

logger = get_logger(__name__)


class OAuthCallbackHandler(BaseHTTPRequestHandler):
    """Minimal HTTP handler that captures the OAuth authorization code from the redirect."""

    def log_message(self, format, *args):  # noqa: A002
        pass  # Suppress HTTP server access logs

    def do_GET(self):
        query = urlparse(self.path).query
        params = parse_qs(query)
        self.server.auth_code = params.get("code", [None])[0]
        self.send_response(200)
        self.send_header("Content-type", "text/html")
        self.end_headers()
        self.wfile.write(
            b"<html><body><h1>Authentication successful!</h1>"
            b"<p>You can close this window and return to your terminal.</p></body></html>"
        )

# Environment variable names for the OAuth browser flow
_ENV_OAUTH_AUTHORIZE_URL = "BARB_OAUTH_AUTHORIZE_URL"
_ENV_OAUTH_CLIENT_ID     = "BARB_OAUTH_CLIENT_ID"
_ENV_OAUTH_REDIRECT_URI  = "BARB_OAUTH_REDIRECT_URI"
_ENV_OAUTH_SCOPE         = "BARB_OAUTH_SCOPE"
_ENV_OAUTH_CODE_CHALLENGE = "BARB_OAUTH_CODE_CHALLENGE"
_ENV_OAUTH_TOKEN_URL     = "BARB_OAUTH_TOKEN_URL"

# Fallback defaults (override via env vars)
_DEFAULT_REDIRECT_URI = "http://localhost:54321/callback"

class Connection:
    """
    Handles authentication and connection to the Barb API.
    Can load API credentials from a .env file as a JSON string.
    """
    def __init__(self, api_key: str | dict | None = None, api_root: str = "https://barb-api.co.uk/api/v3/"):
        load_dotenv()
        logger.debug("Initialising Connection — loading credentials and OAuth config from environment.")

        if api_key is None:
            api_key = os.getenv("BARB_API_KEY")
            if api_key:
                logger.debug("API key loaded from BARB_API_KEY environment variable.")
            else:
                logger.debug("No API key found in environment; will raise ValueError.")
        else:
            logger.debug("API key supplied directly via constructor argument.")

        if not api_key:
            raise ValueError(CONNECTION_ERROR_MESSAGES["api_key_required"])

        # Accept dict or JSON string
        try:
            if isinstance(api_key, dict):
                self.api_key_dict = api_key
                logger.debug("API key accepted as dict with %d key(s).", len(self.api_key_dict))
            elif isinstance(api_key, str):
                self.api_key_dict = json.loads(api_key)
                logger.debug("API key parsed from JSON string with %d key(s).", len(self.api_key_dict))
            else:
                raise ValueError(CONNECTION_ERROR_MESSAGES["api_key_invalid"])
        except (json.JSONDecodeError, TypeError) as e:
            logger.error("Failed to parse API key: %s", e)
            raise ValueError(f"{CONNECTION_ERROR_MESSAGES['api_key_invalid']} ({e})")

        self.api_key = api_key

        # Always override api_root with env if present
        env_api_root = os.getenv("BARB_API_ROOT")
        if env_api_root:
            self.api_root = env_api_root
            logger.debug("API root overridden by BARB_API_ROOT env var: %s", self.api_root)
        else:
            self.api_root = api_root
            logger.debug("API root set to constructor default: %s", self.api_root)

        self.headers: dict[str, str] | None = None
        self.connected: bool = False

        # --- OAuth browser-flow config (all from .env) ---
        self._oauth_authorize_url  = os.getenv(_ENV_OAUTH_AUTHORIZE_URL)
        self._oauth_client_id      = os.getenv(_ENV_OAUTH_CLIENT_ID)
        self._oauth_redirect_uri   = os.getenv(_ENV_OAUTH_REDIRECT_URI) or _DEFAULT_REDIRECT_URI
        self._oauth_scope          = os.getenv(_ENV_OAUTH_SCOPE)
        self._oauth_code_challenge = os.getenv(_ENV_OAUTH_CODE_CHALLENGE)
        self._oauth_token_url      = (
            os.getenv(_ENV_OAUTH_TOKEN_URL)
            or f"{self.api_root.rstrip('/')}/oauth/token"
        )

        # Log which OAuth env vars are present (values omitted for security)
        _oauth_loaded = [
            name for name, val in [
                (_ENV_OAUTH_AUTHORIZE_URL,  self._oauth_authorize_url),
                (_ENV_OAUTH_CLIENT_ID,      self._oauth_client_id),
                (_ENV_OAUTH_REDIRECT_URI,   self._oauth_redirect_uri),
                (_ENV_OAUTH_SCOPE,          self._oauth_scope),
                (_ENV_OAUTH_CODE_CHALLENGE, self._oauth_code_challenge),
            ]
            if val
        ]
        _oauth_missing = [
            name for name, val in [
                (_ENV_OAUTH_AUTHORIZE_URL,  self._oauth_authorize_url),
                (_ENV_OAUTH_CLIENT_ID,      self._oauth_client_id),
                (_ENV_OAUTH_SCOPE,          self._oauth_scope),
                (_ENV_OAUTH_CODE_CHALLENGE, self._oauth_code_challenge),
            ]
            if not val
        ]
        logger.debug("OAuth config loaded: [%s].", ", ".join(_oauth_loaded) if _oauth_loaded else "none")
        if _oauth_missing:
            logger.debug(
                "OAuth browser-flow env vars not set (required for connect_via_browser): [%s].",
                ", ".join(_oauth_missing),
            )
        logger.debug("OAuth redirect URI: %s", self._oauth_redirect_uri)
        logger.debug("OAuth token URL: %s", self._oauth_token_url)

        # --- OAuth token state ---
        self._oauth_refresh_token: str | None               = None
        self._oauth_expires_at:    datetime.datetime | None = None

        logger.info("Connection initialised. API root: %s", self.api_root)

    def connect(self) -> None:
        logger.info("Requesting API-key access token from %s.", self.api_root)

        if not self.api_key_dict:
            logger.error("Cannot connect — api_key_dict is empty.")
            raise RuntimeError(CONNECTION_ERROR_MESSAGES["missing_credentials"])
        if not self.api_root:
            logger.error("Cannot connect — api_root is not set.")
            raise RuntimeError(CONNECTION_ERROR_MESSAGES["missing_api_root"])

        token_request_url = self.api_root + "auth/token/"  # gitleaks:allow
        logger.debug("POST %s (grant_type=client_credentials).", token_request_url)
        data = self.api_key_dict.copy()

        try:
            response = requests.post(token_request_url, data=data)
            logger.debug("Token endpoint responded with HTTP %s.", response.status_code)
        except requests.exceptions.Timeout:
            self.connected = False
            logger.error("Connection timeout while requesting auth token from %s.", token_request_url)
            raise RuntimeError(CONNECTION_ERROR_MESSAGES["network_timeout"])
        except requests.exceptions.RequestException as exc:
            self.connected = False
            logger.error("Connection request failed while requesting auth token: %s", exc)
            raise RuntimeError(CONNECTION_ERROR_MESSAGES["network_unreachable"])

        if response.status_code != 200:
            self.connected = False
            logger.warning(
                "Auth token request failed — HTTP %s. Body: %s",
                response.status_code,
                str(response.text)[:200],
            )
            raise RuntimeError(format_http_error(response.status_code))

        try:
            resp_json = response.json()
            logger.debug("Token response parsed successfully. Keys: %s.", list(resp_json.keys()))
        except ValueError:
            self.connected = False
            logger.error("Auth token response was not valid JSON. Raw body: %s", str(response.text)[:200])
            raise RuntimeError(CONNECTION_ERROR_MESSAGES["invalid_token_response"])

        access_token = resp_json.get("access_token") or resp_json.get("access")
        if not access_token:
            self.connected = False
            logger.error("Auth token response did not contain 'access_token' or 'access'.")
            raise RuntimeError(CONNECTION_ERROR_MESSAGES["missing_access_token"])

        self.headers = {"Authorization": f"Bearer {access_token}"}
        self.connected = True
        logger.info("Successfully authenticated via API key. Connection established.")

    # ------------------------------------------------------------------
    # OAuth browser-flow methods (all config via environment variables)
    # ------------------------------------------------------------------

    def get_authorization_url(self) -> str:
        """
        Builds and returns the OAuth 2.0 authorization URL without opening a browser.
        All parameters are read from environment variables:

        +---------------------------+--------------------------------------------------+
        | Variable                  | Description                                      |
        +===========================+==================================================+
        | BARB_OAUTH_AUTHORIZE_URL  | Full Microsoft ``/authorize`` endpoint URL       |
        | BARB_OAUTH_CLIENT_ID      | OAuth application client ID                      |
        | BARB_OAUTH_REDIRECT_URI   | Redirect URI (default: localhost:54321/callback) |
        | BARB_OAUTH_SCOPE          | OAuth scope string                               |
        | BARB_OAUTH_CODE_CHALLENGE | PKCE code challenge value                        |
        +---------------------------+--------------------------------------------------+

        Use this alongside ``connect_via_redirect_url()`` to display the URL to a user
        who will authenticate manually.

        Returns:
            str: The full authorization URL.

        Raises:
            RuntimeError: If any required environment variable is missing.
        """
        logger.debug("Building OAuth authorization URL.")

        authorize_url   = self._oauth_authorize_url
        client_id       = self._oauth_client_id
        redirect_uri    = self._oauth_redirect_uri
        scope           = self._oauth_scope
        code_challenge  = self._oauth_code_challenge

        missing = [
            name for name, val in [
                (_ENV_OAUTH_AUTHORIZE_URL, authorize_url),
                (_ENV_OAUTH_CLIENT_ID,     client_id),
                (_ENV_OAUTH_SCOPE,         scope),
                (_ENV_OAUTH_CODE_CHALLENGE, code_challenge),
            ]
            if not val
        ]
        if missing:
            logger.error(
                "Cannot build authorization URL — missing env var(s): %s.",
                ", ".join(missing),
            )
            raise RuntimeError(
                f"Missing required environment variable(s) for OAuth flow: {', '.join(missing)}"
            )

        url = (
            f"{authorize_url}?"
            f"client_id={client_id}&"
            f"response_type=code&"
            f"redirect_uri={redirect_uri}&"
            f"response_mode=query&"
            f"scope={scope}&"
            f"state=12345&"
            f"code_challenge={code_challenge}&"
            f"code_challenge_method=S256"
        )
        logger.debug(
            "Authorization URL built. authorize_url=%s redirect_uri=%s scope=%s.",
            authorize_url, redirect_uri, scope,
        )
        return url

    def connect_via_browser(self) -> None:
        """
        **Automated browser flow.**

        Steps performed automatically:

        1. Builds the OAuth authorization URL from environment variables.
        2. Opens the URL in the user's default browser.
        3. Starts a temporary HTTP server on the ``BARB_OAUTH_REDIRECT_URI`` host/port
           (default ``http://localhost:54321/callback``) to receive the redirect.
        4. Extracts the ``code`` query parameter from the redirect.
        5. Exchanges the code for an access token and populates ``self.headers``.

        Required environment variables — see :meth:`get_authorization_url`.
        Also reads ``BARB_OAUTH_TOKEN_URL`` for the token endpoint
        (defaults to ``{api_root}oauth/token``).

        Raises:
            RuntimeError: If the redirect contains no auth code, or if the
                token exchange fails.
        """
        logger.info("Starting OAuth browser flow.")
        auth_url     = self.get_authorization_url()
        redirect_uri = self._oauth_redirect_uri

        logger.info("Opening browser to authorise with Microsoft...")
        print(f"If the browser does not open automatically, visit this URL:\n{auth_url}\n")
        webbrowser.open(auth_url)
        logger.debug("webbrowser.open() called.")

        parsed = urlparse(redirect_uri)
        host   = parsed.hostname or "localhost"
        port   = parsed.port or 54321
        logger.info("Listening on %s (host=%s port=%s) for the authorization redirect...", redirect_uri, host, port)
        print(f"Listening on {redirect_uri} for the authorization redirect...")

        httpd = HTTPServer((host, port), OAuthCallbackHandler)
        httpd.auth_code = None
        logger.debug("Temporary HTTP server started. Waiting for single redirect request...")
        httpd.handle_request()  # block until exactly one request arrives
        logger.debug("HTTP server received a request. auth_code present: %s.", bool(httpd.auth_code))

        if not httpd.auth_code:
            logger.error(
                "No authorization code in redirect. Check that the identity provider is "
                "configured to redirect to '%s'.", redirect_uri,
            )
            raise RuntimeError(
                "Authorization code extraction failed. "
                f"Ensure the redirect URI is '{redirect_uri}' and try again."
            )

        self.auth_code = httpd.auth_code
        logger.info("Authorization code captured successfully from redirect.")
        logger.debug("Exchanging authorization code for access token.")
        self._exchange_oauth_code(self.auth_code)

    def connect_via_redirect_url(self, redirect_url: str) -> None:
        """
        **Manual redirect-URL flow.**

        Use this when you already have the full redirect URL that the identity
        provider sent back after the user logged in — for example::

            http://localhost:54321/callback?code=0.AXXX...&state=12345

        Steps performed:

        1. Parses the ``code`` query parameter from ``redirect_url``.
        2. Exchanges the code for an access token and populates ``self.headers``.

        Required environment variables — see :meth:`get_authorization_url`.
        Also reads ``BARB_OAUTH_TOKEN_URL`` for the token endpoint
        (defaults to ``{api_root}oauth/token``).

        Args:
            redirect_url: The complete redirect URL received from the identity
                provider after login, containing the ``code`` query parameter.

        Raises:
            ValueError: If ``redirect_url`` is blank or contains no ``code`` param.
            RuntimeError: If the token exchange request fails.

        Example::

            conn = Connection()

            # Display the URL for the user to open manually
            print(conn.get_authorization_url())

            # After login, paste the full redirect URL
            conn.connect_via_redirect_url(
                "http://localhost:54321/callback?code=0.AXXX...&state=12345"
            )
        """
        logger.info("Starting OAuth redirect-URL flow.")
        logger.debug("Parsing authorization code from redirect URL.")

        if not redirect_url or not redirect_url.strip():
            logger.error("connect_via_redirect_url called with blank redirect_url.")
            raise ValueError("redirect_url must not be blank.")

        params      = parse_qs(urlparse(redirect_url).query)
        code_values = params.get("code")
        logger.debug(
            "Query parameters parsed from redirect URL. Keys present: %s.",
            list(params.keys()),
        )

        if not code_values or not code_values[0]:
            logger.error(
                "No 'code' parameter found in redirect URL. "
                "Parameters present: %s.", list(params.keys()),
            )
            raise ValueError(
                "The redirect URL does not contain a 'code' query parameter. "
                "Make sure you copy the full URL from the browser address bar after login."
            )

        self.auth_code = code_values[0]
        logger.info("Authorization code extracted from redirect URL successfully.")
        logger.debug("Exchanging authorization code for access token.")
        self._exchange_oauth_code(self.auth_code)

    # ------------------------------------------------------------------
    # Private OAuth helper
    # ------------------------------------------------------------------

    @property
    def is_token_expired(self) -> bool:
        if self._oauth_expires_at is None:
            logger.debug("is_token_expired: expires_at not set — assuming token is valid.")
            return False
        remaining = (self._oauth_expires_at - datetime.datetime.now()).total_seconds()
        expired   = remaining <= 30
        logger.debug(
            "is_token_expired: expires_at=%s remaining=%.0fs expired=%s.",
            self._oauth_expires_at.isoformat(), remaining, expired,
        )
        return expired

    def ensure_token_valid(self) -> None:
        logger.debug("ensure_token_valid called. is_token_expired=%s.", self.is_token_expired)
        if self.is_token_expired:
            if self._oauth_refresh_token:
                logger.info(
                    "OAuth access token is expired (or expires in ≤30 s) — refreshing automatically."
                )
                self._exchange_oauth_refresh_token()
            else:
                logger.warning(
                    "OAuth access token is expired and no refresh token is stored. "
                    "Re-authentication required."
                )
                raise RuntimeError(
                    "OAuth access token has expired and no refresh token is available. "
                    "Re-authenticate using connect_via_browser() or connect_via_redirect_url()."
                )
        elif self.connected and not self._oauth_expires_at:
            logger.debug(
                "ensure_token_valid: API-key flow detected (no expires_at). No action taken."
            )
        else:
            logger.debug("ensure_token_valid: token is still valid. No refresh needed.")

    def make_request(self, method: str, url: str, **kwargs) -> requests.Response:
        logger.debug("make_request called: %s %s.", method.upper(), url)
        self.ensure_token_valid()

        caller_headers = kwargs.pop("headers", {})
        merged_headers = {**(self.headers or {}), **caller_headers}
        logger.debug(
            "Sending %s %s (caller headers: %s).",
            method.upper(), url, list(caller_headers.keys()),
        )

        response = requests.request(method, url, headers=merged_headers, **kwargs)
        logger.info(
            "HTTP %s %s → %s.", method.upper(), url, response.status_code
        )

        if response.status_code == 401:
            if self._oauth_refresh_token:
                logger.warning(
                    "Received 401 on %s %s — refreshing OAuth access token and retrying.",
                    method.upper(), url,
                )
                self._exchange_oauth_refresh_token()
            else:
                logger.warning(
                    "Received 401 on %s %s — re-connecting with API key and retrying.",
                    method.upper(), url,
                )
                self.connect()
            merged_headers = {**(self.headers or {}), **caller_headers}
            response       = requests.request(method, url, headers=merged_headers, **kwargs)
            logger.info(
                "Retry %s %s → %s (after token refresh).",
                method.upper(), url, response.status_code,
            )

        return response

    def _exchange_oauth_refresh_token(self) -> None:
        logger.info("Refreshing OAuth access token via refresh_token grant.")
        logger.debug("POST %s (grant_type=refresh_token).", self._oauth_token_url)

        data = {
            "grant_type":    "refresh_token",
            "refresh_token": self._oauth_refresh_token,
            "client_id":     self._oauth_client_id,
            "redirect_uri":  self._oauth_redirect_uri,
        }
        req_headers = {"Content-Type": "application/x-www-form-urlencoded"}

        try:
            response = requests.post(self._oauth_token_url, data=data, headers=req_headers)
            logger.debug("Refresh token endpoint responded with HTTP %s.", response.status_code)
        except requests.exceptions.Timeout:
            self.connected = False
            logger.error("Timeout while refreshing OAuth access token from %s.", self._oauth_token_url)
            raise RuntimeError(CONNECTION_ERROR_MESSAGES["network_timeout"])
        except requests.exceptions.RequestException as exc:
            self.connected = False
            logger.error("Network error while refreshing OAuth access token: %s", exc)
            raise RuntimeError(CONNECTION_ERROR_MESSAGES["network_unreachable"])

        if response.status_code != 200:
            self.connected = False
            logger.warning(
                "OAuth token refresh failed — HTTP %s. Body: %s",
                response.status_code,
                str(response.text)[:200],
            )
            raise RuntimeError(format_http_error(response.status_code))

        try:
            resp_json = response.json()
            logger.debug("Refresh token response parsed. Keys: %s.", list(resp_json.keys()))
        except ValueError:
            self.connected = False
            logger.error("OAuth refresh response was not valid JSON. Raw body: %s", str(response.text)[:200])
            raise RuntimeError(CONNECTION_ERROR_MESSAGES["invalid_token_response"])

        access_token = resp_json.get("access_token") or resp_json.get("access")
        if not access_token:
            self.connected = False
            logger.error("OAuth refresh response did not contain 'access_token' or 'access'.")
            raise RuntimeError(CONNECTION_ERROR_MESSAGES["missing_access_token"])

        new_refresh = resp_json.get("refresh_token")
        if new_refresh:
            self._oauth_refresh_token = new_refresh
            logger.debug("Refresh token rotated — new refresh token stored.")
        else:
            logger.debug("No new refresh token in response — existing token retained.")

        expires_in = resp_json.get("expires_in")
        if expires_in:
            self._oauth_expires_at = datetime.datetime.now() + datetime.timedelta(seconds=int(expires_in))
            logger.debug(
                "New OAuth token expires in %ss (at %s).",
                expires_in,
                self._oauth_expires_at.isoformat(),
            )
        else:
            self._oauth_expires_at = None
            logger.debug("No expires_in in refresh response — expires_at cleared.")

        self.headers   = {"Authorization": f"Bearer {access_token}"}
        self.connected = True
        logger.info("OAuth access token refreshed successfully.")

    def _exchange_oauth_code(self, code: str) -> None:
        logger.info("Exchanging authorization code for OAuth access token.")
        logger.debug(
            "POST %s (grant_type=authorization_code, redirect_uri=%s).",
            self._oauth_token_url,
            self._oauth_redirect_uri,
        )

        client_id      = self._oauth_client_id
        redirect_uri   = self._oauth_redirect_uri
        code_challenge = self._oauth_code_challenge
        token_url      = self._oauth_token_url

        data = {
            "grant_type":    "authorization_code",
            "code":          code,
            "client_id":     client_id,
            "redirect_uri":  redirect_uri,
            "code_verifier": code_challenge,
        }
        headers = {"Content-Type": "application/x-www-form-urlencoded"}

        try:
            response = requests.post(token_url, data=data, headers=headers)
            logger.debug("Token endpoint responded with HTTP %s.", response.status_code)
        except requests.exceptions.Timeout:
            self.connected = False
            logger.error("Timeout while exchanging authorization code at %s.", token_url)
            raise RuntimeError(CONNECTION_ERROR_MESSAGES["network_timeout"])
        except requests.exceptions.RequestException as exc:
            self.connected = False
            logger.error("Network error while exchanging authorization code: %s", exc)
            raise RuntimeError(CONNECTION_ERROR_MESSAGES["network_unreachable"])

        if response.status_code != 200:
            self.connected = False
            logger.warning(
                "Authorization code exchange failed — HTTP %s. Body: %s",
                response.status_code,
                str(response.text)[:200],
            )
            raise RuntimeError(format_http_error(response.status_code))

        try:
            resp_json = response.json()
            logger.debug("Token response parsed. Keys: %s.", list(resp_json.keys()))
        except ValueError:
            self.connected = False
            logger.error("OAuth token response was not valid JSON. Raw body: %s", str(response.text)[:200])
            raise RuntimeError(CONNECTION_ERROR_MESSAGES["invalid_token_response"])

        access_token = resp_json.get("access_token") or resp_json.get("access")
        if not access_token:
            self.connected = False
            logger.error("OAuth token response did not contain 'access_token' or 'access'.")
            raise RuntimeError(CONNECTION_ERROR_MESSAGES["missing_access_token"])

        # Store refresh token and expiry for auto-refresh support
        new_refresh = resp_json.get("refresh_token")
        if new_refresh:
            self._oauth_refresh_token = new_refresh
            logger.debug("Refresh token stored for future auto-refresh.")
        else:
            logger.debug("No refresh token in code-exchange response.")

        expires_in = resp_json.get("expires_in")
        if expires_in:
            self._oauth_expires_at = datetime.datetime.now() + datetime.timedelta(seconds=int(expires_in))
            logger.debug(
                "OAuth access token expires in %ss (at %s).",
                expires_in,
                self._oauth_expires_at.isoformat(),
            )
        else:
            self._oauth_expires_at = None
            logger.debug("No expires_in in token response — expiry tracking disabled.")

        self.headers   = {"Authorization": f"Bearer {access_token}"}
        self.connected = True
        logger.info(
            "OAuth authentication successful. Token obtained. "
            "expires_at=%s refresh_token_present=%s.",
            self._oauth_expires_at.isoformat() if self._oauth_expires_at else "N/A",
            bool(self._oauth_refresh_token),
        )
