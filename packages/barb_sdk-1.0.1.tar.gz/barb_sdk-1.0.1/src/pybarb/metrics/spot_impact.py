from typing import Any

import pandas as pd
import requests

from pybarb.constants import format_http_error
from pybarb.constants.constants import SPOT_IMPACTS_COLUMN_MAP, SPOT_IMPACTS_OUTPUT_COLUMNS
from pybarb.constants.errors import SPOT_IMPACTS_ERROR_MESSAGES
from pybarb.metadata.utils.metadata_common import (
    fetch_metadata,
    parse_json_payload,
    raise_for_http_error,
    validate_connection_headers,
)
from pybarb.utils import ApiError
from pybarb.utils.dataframe_utils import to_flat_dataframe
from pybarb.utils.logging_config import get_logger

logger = get_logger(__name__)


class SpotImpact:
    def __init__(self, connection):
        self.connection = connection
        self.api_url = f"{self.connection.api_root.rstrip('/')}/metrics/spots/impacts"

    def get_spot_impact(
        self,
        min_transmission_date: str,
        max_transmission_date: str,
        station_code: str | None = None,
        consolidated: bool | None = None,
        limit: int | None = None,
        is_staggercast_station_code: bool | None = None,
    ) -> list[dict[str, Any]]:
        """
        Fetches spot impacts for a given date range and station.
        """
        validate_connection_headers(
            headers=self.connection.headers,
            headers_missing_message=SPOT_IMPACTS_ERROR_MESSAGES["headers_missing"],
            logger=logger,
            logger_message="Spot impacts data requested before connection headers were set",
        )

        if not isinstance(min_transmission_date, str) or not min_transmission_date.strip():
            raise ApiError(SPOT_IMPACTS_ERROR_MESSAGES["min_transmission_date_required"])

        if not isinstance(max_transmission_date, str) or not max_transmission_date.strip():
            raise ApiError(SPOT_IMPACTS_ERROR_MESSAGES["max_transmission_date_required"])

        params = {
            "min_transmission_date": min_transmission_date,
            "max_transmission_date": max_transmission_date,
        }
        
        if station_code is not None:
            params["station_code"] = station_code
        if consolidated is not None:
            params["consolidated"] = str(consolidated).lower()
        if limit is not None:
            params["limit"] = limit
        if is_staggercast_station_code is not None:
            params["is_staggercast_station_code"] = str(is_staggercast_station_code).lower()

        response = fetch_metadata(
            request_get=requests.get,
            api_url=self.api_url,
            headers=self.connection.headers,
            network_error_message=SPOT_IMPACTS_ERROR_MESSAGES["network_error"],
            params=params,
            logger=logger,
            logger_message="Spot impacts data fetch request",
        )

        raise_for_http_error(response, self._format_error)

        payload = parse_json_payload(
            response=response,
            malformed_json_message=SPOT_IMPACTS_ERROR_MESSAGES["malformed_json"],
        )

        events = payload.get("events") if isinstance(payload, dict) else None
        if not isinstance(events, list):
            raise ApiError(
                SPOT_IMPACTS_ERROR_MESSAGES["payload_not_list"].format(payload_type=type(payload).__name__),
                response_body=response.text,
            )

        if not events:
            raise ApiError(SPOT_IMPACTS_ERROR_MESSAGES["no_results"])

        return events

    def get_spot_impact_flat_dataframe(
        self,
        min_transmission_date: str,
        max_transmission_date: str,
        station_code: str | None = None,
        consolidated: bool | None = None,
        limit: int | None = None,
        is_staggercast_station_code: bool | None = None,
    ) -> pd.DataFrame:
        """
        Fetches spot impacts as a flattened DataFrame.
        """
        data = self.get_spot_impact(
            min_transmission_date=min_transmission_date,
            max_transmission_date=max_transmission_date,
            station_code=station_code,
            consolidated=consolidated,
            limit=limit,
            is_staggercast_station_code=is_staggercast_station_code,
        )

        flat_df = to_flat_dataframe(
            data,
            record_path="audience_views",
            meta=[
                "spot_type",
                "spot_duration",
                "break_duration",
                "preceding_programme_name",
                "succeeding_programme_name",
                "break_type",
                "broadcaster_spot_number",
                "commercial_number",
                "campaign_approval_id",
                "position_in_break",
                ["panel", "panel_code"],
                ["panel", "panel_region"],
                ["panel", "is_macro_region"],
                ["station", "station_code"],
                ["station", "station_name"],
                ["spot_start_datetime", "barb_reporting_datetime"],
                ["spot_start_datetime", "barb_polling_datetime"],
                ["spot_start_datetime", "standard_datetime"],
                ["break_start_datetime", "barb_reporting_datetime"],
                ["break_start_datetime", "barb_polling_datetime"],
                ["break_start_datetime", "standard_datetime"],
            ],
        )

        return self._map_and_order_flat_columns(flat_df)

    @staticmethod
    def _map_and_order_flat_columns(flat_df: pd.DataFrame) -> pd.DataFrame:
        """Apply requested output names and keep a stable ordered schema."""
        mapped_df = flat_df.rename(columns=SPOT_IMPACTS_COLUMN_MAP)
        return mapped_df.reindex(columns=SPOT_IMPACTS_OUTPUT_COLUMNS)

    @staticmethod
    def _format_error(status_code: int) -> str:
        return format_http_error(status_code)
