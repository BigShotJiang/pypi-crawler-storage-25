from typing import Any

import pandas as pd
import requests

from pybarb.constants import format_http_error
from pybarb.constants.constants import (
    STATION_AUDIENCES_COLUMN_MAP,
    STATION_AUDIENCES_OUTPUT_COLUMNS,
)
from pybarb.constants.errors import STATION_AUDIENCES_ERROR_MESSAGES
from pybarb.metadata.utils.metadata_common import (
    fetch_metadata,
    parse_json_payload,
    raise_for_http_error,
    validate_connection_headers,
)
from pybarb.utils import ApiError
from pybarb.utils.dataframe_utils import to_flat_dataframe
from pybarb.utils.logging_config import get_logger

logger = get_logger(__name__)


class StationAudiences:
    """Client for the station audiences metrics endpoint."""

    def __init__(self, connection):
        self.connection = connection
        self.api_url = f"{self.connection.api_root.rstrip('/')}/metrics/station/audiences"

    def get_station_audiences(
        self,
        min_transmission_date: str,
        max_transmission_date: str,
        station_code: int | str,
        panel_code: int | str,
        time_period_length: int | str,
        viewing_status: str,
        use_polling_days: bool | str = True,
        limit: int | str = 500,
        last_updated_greater_than: str | None = None,
    ) -> dict[str, Any]:
        """
        Fetch station audiences metrics for a given date range and station.

        Returns:
            Dict containing the ``stations_audiences`` key with a list of
            audience records.
        """
        validate_connection_headers(
            headers=self.connection.headers,
            headers_missing_message=STATION_AUDIENCES_ERROR_MESSAGES["headers_missing"],
            logger=logger,
            logger_message="Station audiences requested before connection headers were set",
        )

        if not isinstance(min_transmission_date, str) or not min_transmission_date.strip():
            raise ApiError(STATION_AUDIENCES_ERROR_MESSAGES["min_transmission_date_required"])

        if not isinstance(max_transmission_date, str) or not max_transmission_date.strip():
            raise ApiError(STATION_AUDIENCES_ERROR_MESSAGES["max_transmission_date_required"])

        if station_code is None or str(station_code).strip() == "":
            raise ApiError(STATION_AUDIENCES_ERROR_MESSAGES["station_code_required"])

        if panel_code is None or str(panel_code).strip() == "":
            raise ApiError(STATION_AUDIENCES_ERROR_MESSAGES["panel_code_required"])

        params = {
            "min_transmission_date": min_transmission_date,
            "max_transmission_date": max_transmission_date,
            "station_code": str(station_code),
            "panel_code": str(panel_code),
            "time_period_length": str(time_period_length),
            "viewing_status": viewing_status,
            "use_polling_days": str(use_polling_days).lower(),
            "limit": str(limit),
            "last_updated_greater_than": last_updated_greater_than,
        }

        response = fetch_metadata(
            request_get=requests.get,
            api_url=self.api_url,
            headers=self.connection.headers,
            network_error_message=STATION_AUDIENCES_ERROR_MESSAGES["network_error"],
            params=params,
            logger=logger,
            logger_message="Station audiences data fetch request failed",
        )

        raise_for_http_error(response, self._format_error)

        payload = parse_json_payload(
            response=response,
            malformed_json_message=STATION_AUDIENCES_ERROR_MESSAGES["malformed_json"],
        )

        if not isinstance(payload, dict):
            raise ApiError(
                STATION_AUDIENCES_ERROR_MESSAGES["payload_not_dict"].format(
                    payload_type=type(payload).__name__,
                ),
                response_body=response.text,
            )

        audiences = payload.get("stations_audiences")
        if not isinstance(audiences, list) or not audiences:
            raise ApiError(STATION_AUDIENCES_ERROR_MESSAGES["no_results"])

        return payload

    def get_station_audiences_flat_dataframe(
        self,
        min_transmission_date: str,
        max_transmission_date: str,
        station_code: int | str,
        panel_code: int | str,
        time_period_length: int | str,
        viewing_status: str,
        use_polling_days: bool | str = True,
        limit: int | str = 500,
        last_updated_greater_than: str | None = None,
    ) -> pd.DataFrame:
        """Return station audiences as a flattened DataFrame.

        The nested ``audience_views`` list is expanded into rows, with
        top-level station/panel metadata preserved as columns.
        """
        data = self.get_station_audiences(
            min_transmission_date=min_transmission_date,
            max_transmission_date=max_transmission_date,
            station_code=station_code,
            panel_code=panel_code,
            time_period_length=time_period_length,
            viewing_status=viewing_status,
            use_polling_days=use_polling_days,
            limit=limit,
            last_updated_greater_than=last_updated_greater_than,
        )

        flat_df = to_flat_dataframe(
            data["stations_audiences"],
            record_path="audience_views",
            meta=[
                "date_of_transmission",
                "activity",
                "transmission_time_period_duration_mins",
                ["station", "station_code"],
                ["station", "station_name"],
                ["panel", "panel_code"],
                ["panel", "panel_region"],
                ["panel", "is_macro_region"],
                "platforms",
                ["transmission_time_period_start", "barb_reporting_datetime"],
                ["transmission_time_period_start", "barb_polling_datetime"],
                ["transmission_time_period_start", "standard_datetime"],
            ],
        )

        return self._map_and_order_flat_columns(flat_df)

    @staticmethod
    def _map_and_order_flat_columns(flat_df: pd.DataFrame) -> pd.DataFrame:
        """Apply requested output names and keep a stable ordered schema."""
        mapped_df = flat_df.rename(columns=STATION_AUDIENCES_COLUMN_MAP)
        return mapped_df.reindex(columns=STATION_AUDIENCES_OUTPUT_COLUMNS)

    @staticmethod
    def _format_error(status_code: int) -> str:
        return format_http_error(status_code)
