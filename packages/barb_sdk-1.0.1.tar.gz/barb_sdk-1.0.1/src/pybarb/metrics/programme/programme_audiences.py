from typing import Any
import pandas as pd
import requests
from pybarb.constants import format_http_error
from pybarb.constants.constants import (
    PROGRAMME_AUDIENCES_COLUMN_MAP,
    PROGRAMME_AUDIENCES_OUTPUT_COLUMNS,
)
from pybarb.constants.errors import PROGRAMME_AUDIENCES_ERROR_MESSAGES
from pybarb.metadata.utils.metadata_common import (
    fetch_metadata,
    parse_json_payload,
    raise_for_http_error,
    validate_connection_headers,
)
from pybarb.utils import ApiError
from pybarb.utils.dataframe_utils import to_flat_dataframe
from pybarb.utils.logging_config import get_logger
logger = get_logger(__name__)
class ProgrammeAudiences:
    """Client for the programme audiences metrics endpoint."""
    def __init__(self, connection):
        self.connection = connection
        self.api_url = f"{self.connection.api_root.rstrip('/')}/metrics/programme/audiences"
    def get_programme_audiences(
        self,
        min_transmission_date: str,
        max_transmission_date: str,
        panel_code: int | str,
        consolidated: bool | str = False,
        limit: int | str = 500,
        last_updated_greater_than: str | None = None,
    ) -> dict[str, Any]:
        """
        Fetch programme audiences metrics for a given date range.
        Returns:
            Dict containing the ``programme_audiences`` key with a list of
            audience records.
        """
        validate_connection_headers(
            headers=self.connection.headers,
            headers_missing_message=PROGRAMME_AUDIENCES_ERROR_MESSAGES["headers_missing"],
            logger=logger,
            logger_message="Programme audiences requested before connection headers were set",
        )
        if not isinstance(min_transmission_date, str) or not min_transmission_date.strip():
            raise ApiError(PROGRAMME_AUDIENCES_ERROR_MESSAGES["min_transmission_date_required"])
        if not isinstance(max_transmission_date, str) or not max_transmission_date.strip():
            raise ApiError(PROGRAMME_AUDIENCES_ERROR_MESSAGES["max_transmission_date_required"])
        if panel_code is None or str(panel_code).strip() == "":
            raise ApiError(PROGRAMME_AUDIENCES_ERROR_MESSAGES["panel_code_required"])
        params = {
            "min_transmission_date": min_transmission_date,
            "max_transmission_date": max_transmission_date,
            "panel_code": str(panel_code),
            "consolidated": str(consolidated).lower(),
            "limit": str(limit),
            "last_updated_greater_than": last_updated_greater_than,
        }
        response = fetch_metadata(
            request_get=requests.get,
            api_url=self.api_url,
            headers=self.connection.headers,
            network_error_message=PROGRAMME_AUDIENCES_ERROR_MESSAGES["network_error"],
            params=params,
            logger=logger,
            logger_message="Programme audiences data fetch request failed",
        )
        raise_for_http_error(response, self._format_error)
        payload = parse_json_payload(
            response=response,
            malformed_json_message=PROGRAMME_AUDIENCES_ERROR_MESSAGES["malformed_json"],
        )

        if not isinstance(payload, dict):
            raise ApiError(
                PROGRAMME_AUDIENCES_ERROR_MESSAGES["payload_not_dict"].format(
                    payload_type=type(payload).__name__,
                ),
                response_body=response.text,
            )


        return payload
    def get_programme_audiences_flat_dataframe(
        self,
        min_transmission_date: str,
        max_transmission_date: str,
        panel_code: int | str,
        consolidated: bool | str = False,
        limit: int | str = 500,
        last_updated_greater_than: str | None = None,
    ) -> pd.DataFrame:
        """Return programme audiences as a flattened DataFrame."""
        data = self.get_programme_audiences(
            min_transmission_date=min_transmission_date,
            max_transmission_date=max_transmission_date,
            panel_code=panel_code,
            consolidated=consolidated,
            limit=limit,
            last_updated_greater_than=last_updated_greater_than,
        )

        audiences = data.get("programme_audiences", [])
        if not audiences:
            return pd.DataFrame(columns=PROGRAMME_AUDIENCES_OUTPUT_COLUMNS)

        flat_df = to_flat_dataframe(
            audiences,
            record_path="audience_views",
            meta=[
                "transmission_log_programme_name",
                "programme_type",
                "programme_duration",
                "programme_gross_duration",
                ["panel", "panel_code"],
                ["panel", "panel_region"],
                ["panel", "is_macro_region"],
                ["station", "station_code"],
                ["station", "station_name"],
                ["log_station", "station_code"],
                ["log_station", "station_name"],
                ["programme_start_datetime", "barb_reporting_datetime"],
                ["programme_start_datetime", "barb_polling_datetime"],
                ["programme_start_datetime", "standard_datetime"],
            ],
        )

        return self._map_and_order_flat_columns(flat_df)
    @staticmethod
    def _map_and_order_flat_columns(flat_df: pd.DataFrame) -> pd.DataFrame:
        """Apply requested output names."""
        mapped_df = flat_df.rename(columns=PROGRAMME_AUDIENCES_COLUMN_MAP)
        # Reindexing and expanding might drop unmapped or keep unmapped 
        # But for this purpose:
        final_cols = [c for c in PROGRAMME_AUDIENCES_OUTPUT_COLUMNS if c in mapped_df.columns]
        for c in PROGRAMME_AUDIENCES_OUTPUT_COLUMNS:
            if c not in final_cols:
                final_cols.append(c)
        return mapped_df.reindex(columns=final_cols)
    @staticmethod
    def _format_error(status_code: int) -> str:
        return format_http_error(status_code)
