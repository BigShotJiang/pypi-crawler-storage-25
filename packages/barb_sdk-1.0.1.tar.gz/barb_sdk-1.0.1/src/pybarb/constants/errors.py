"""Reusable SDK error messages and helpers."""

# Shared error messages (DRY principle)
_HEADERS_MISSING = "Connection headers not set. Call connect() first."
_SEARCH_STRING_REQUIRED = "search_string may not be blank."
_SEARCH_STRING_MIN_LENGTH = "search_string must be at least 3 characters long."
_PANEL_CODE_REQUIRED = "panel_code is required."
_MIN_TRANSMISSION_DATE_REQUIRED = "min_transmission_date is required."
_MAX_TRANSMISSION_DATE_REQUIRED = "max_transmission_date is required."

CONNECTION_ERROR_MESSAGES: dict[str, str] = {
	"api_key_required": "API key must be provided via argument or BARB_API_KEY.",
	"api_key_invalid": "API key must be a valid JSON string or dict.",
	"missing_credentials": "API key (client_id/client_secret) is missing.",
	"missing_api_root": "API root URL is missing.",
	"network_unreachable": "Unable to reach Barb API. Check your internet connection.",
	"network_timeout": "Request to Barb API timed out. Please try again.",
	"invalid_token_response": "Invalid response from Barb API.",
	"missing_access_token": "Authentication response did not include an access token.",
}

STATION_ERROR_MESSAGES: dict[str, str] = {
	"invalid_station_name": "station_name must be a non-empty string.",
	"headers_missing": _HEADERS_MISSING,
	"network_error": "Unable to fetch station metadata. Check your internet connection.",
	"malformed_json": "Invalid station metadata response from Barb API.",
	"no_stations": "No stations returned.",
	"payload_not_list": "Unexpected stations payload type: {payload_type}",
	"entry_not_dict": "Unexpected station entry type at index {index}: {entry_type}",
	"station_not_found": "Station name '{station_name}' not found.",
	"station_multiple_matches": "Multiple stations matched name '{station_name}'.",
}

SPLIT_STATION_FACTOR_ERROR_MESSAGES: dict[str, str] = {
	"headers_missing": _HEADERS_MISSING,
	"network_error": "Unable to fetch split station factors. Check your internet connection.",
	"malformed_json": "Invalid split station factor response from Barb API.",
	"payload_not_list": "Unexpected split station factor payload type: {payload_type}",
	"no_results": "No split station factors returned.",
	"station_name_required": "log_station_name must be a non-empty string.",
	"invalid_regex": "Invalid regex pattern for log_station_name.",
	"station_not_found": "Split station factor for '{station_name}' not found.",
}

VIEWING_STATIONS_ERROR_MESSAGES: dict[str, str] = {
	"headers_missing": _HEADERS_MISSING,
	"network_error": "Unable to fetch viewing stations. Check your internet connection.",
	"malformed_json": "Invalid viewing stations response from Barb API.",
	"payload_not_list": "Unexpected viewing stations payload type: {payload_type}",
	"no_results": "No viewing stations returned.",
	"station_name_required": "station_name must be a non-empty string.",
	"invalid_regex": "Invalid regex pattern for station_name.",
	"station_not_found": "Viewing station '{station_name}' not found.",
}
BUYER_ERROR_MESSAGES: dict[str, str] = {
	"headers_missing": _HEADERS_MISSING,
	"network_error": "Unable to fetch buyers. Check your internet connection.",
	"malformed_json": "Invalid buyers response from Barb API.",
	"no_results": "No buyers returned.",
	"payload_not_list": "Unexpected buyers payload type: {payload_type}",
}

ADVERTISER_ERROR_MESSAGES: dict[str, str] = {
	"headers_missing": _HEADERS_MISSING,
	"network_error": "Unable to fetch advertisers. Check your internet connection.",
	"malformed_json": "Invalid advertisers response from Barb API.",
	"no_results": "No advertisers returned.",
	"payload_not_list": "Unexpected advertisers payload type: {payload_type}",
}

PANEL_ERROR_MESSAGES: dict[str, str] = {
	"headers_missing": _HEADERS_MISSING,
	"network_error": "Unable to fetch panels. Check your internet connection.",
	"malformed_json": "Invalid panels response from Barb API.",
	"payload_not_list": "Unexpected panels payload type: {payload_type}",
	"no_results": "No panels returned.",
	"panel_region_required": "panel_region must be a non-empty string.",
	"invalid_regex": "Invalid regex pattern for panel_region.",
	"panel_not_found": "Panel region '{panel_region}' not found.",
	"panel_multiple_matches": "Multiple panels matched region '{panel_region}'.",
}

PROGRAMME_SCHEDULE : dict[str, str] = {
	"headers_missing": _HEADERS_MISSING,
	"max_schedule_date_required": "max_schedule_date is required.",
	"min_schedule_date_required": "min_schedule_date is required.",
	"network_error": "Unable to fetch {resource_name}. Check your internet connection.",
	"malformed_json": "Invalid {resource_name} response from Barb API.",
	"payload_not_list": "Unexpected {resource_name} payload type: {payload_type}",
	"no_results": "No {resource_name} results returned.",
}

HOUSEHOLDS_ERROR_MESSAGE = {
    "headers_missing": _HEADERS_MISSING,
    "panel_start_date_required": "panel_start_date is required.",
    "panel_end_date_required": "panel_end_date is required.",
    "network_error": "Unable to fetch households. Check your internet connection.",
    "malformed_json": "Invalid households response from Barb API.",
    "payload_not_list": "Unexpected households payload type: {payload_type}",
    "no_results": "No households returned.",
}

PANEL_MEMBERS_ERROR_MESSAGES = {
	"headers_missing": _HEADERS_MISSING,
    "panel_start_date_required": "panel_start_date is required.",
    "panel_end_date_required": "panel_end_date is required.",
    "network_error": "Unable to fetch panel members. Check your internet connection.",
    "malformed_json": "Invalid panel members response from Barb API.",
    "payload_not_list": "Unexpected panel members payload type: {payload_type}",
    "no_results": "No panel members returned.",
}

SPOT_SCHEDULE_ERROR_MESSAGES = {
	"headers_missing": _HEADERS_MISSING,
    "max_scheduled_date_required": "max_scheduled_date is required.",
    "min_scheduled_date_required": "min_scheduled_date is required.",
    "network_error": "Unable to fetch spot schedule. Check your internet connection.",
    "malformed_json": "Invalid spot schedule response from Barb API.",
    "payload_not_list": "Unexpected spot schedule payload type: {payload_type}",
    "no_results": "No spot schedule returned.",
}

TARGET_AUDIENCE_CATEGORIES_ERROR_MESSAGES = {
	"headers_missing": _HEADERS_MISSING,
    "max_date_required": "max_date is required.",
    "min_date_required": "min_date is required.",
    "panel_code_required": _PANEL_CODE_REQUIRED,
    "panel_code_limit": "panel_code accepts a maximum of 10 comma separated values.",
    "network_error": "Unable to fetch target audience categories. Check your internet connection.",
    "malformed_json": "Invalid target audience categories response from Barb API.",
    "payload_not_list": "Unexpected target audience categories payload type: {payload_type}",
    "no_results": "No target audience categories returned.",
}

STATION_AUDIENCES_ERROR_MESSAGES: dict[str, str] = {
    "headers_missing": _HEADERS_MISSING,
    "min_transmission_date_required": _MIN_TRANSMISSION_DATE_REQUIRED,
    "max_transmission_date_required": _MAX_TRANSMISSION_DATE_REQUIRED,
    "station_code_required": "station_code is required.",
    "panel_code_required": _PANEL_CODE_REQUIRED,
    "network_error": "Unable to fetch station audiences. Check your internet connection.",
    "malformed_json": "Invalid station audiences response from Barb API.",
    "payload_not_dict": "Unexpected station audiences payload type: {payload_type}",
    "no_results": "No station audiences returned.",
}

SPOT_IMPACTS_ERROR_MESSAGES = {
    "headers_missing": _HEADERS_MISSING,
    "min_transmission_date_required": _MIN_TRANSMISSION_DATE_REQUIRED,
    "max_transmission_date_required": _MAX_TRANSMISSION_DATE_REQUIRED,
    "station_code_required": "station_code is required.",
    "panel_code_required": _PANEL_CODE_REQUIRED,
    "payload_not_dict": "Unexpected station audiences payload type: {payload_type}",
    "network_error": "Unable to fetch spot impacts. Check your internet connection.",
    "malformed_json": "Invalid spot impacts response from Barb API.",
    "payload_not_list": "Unexpected spot impacts payload type: {payload_type}",
    "no_results": "No spot impacts returned.",
}

# Metadata search-based endpoints (shared pattern)
_METADATA_SEARCH_ERROR_MESSAGES_TEMPLATE = {
    "headers_missing": _HEADERS_MISSING,
    "search_string_required": _SEARCH_STRING_REQUIRED,
    "search_string_min_length": _SEARCH_STRING_MIN_LENGTH,
    "network_error": "Unable to fetch {resource_name}. Check your internet connection.",
    "malformed_json": "Invalid {resource_name} response from Barb API.",
    "payload_not_list": "Unexpected {resource_name} payload type: {{payload_type}}",
    "no_results": "No {resource_name} returned.",
}

def _create_metadata_error_messages(resource_name: str) -> dict[str, str]:
    """Create error messages for metadata search endpoints."""
    return {
        key: msg.format(resource_name=resource_name) if "{resource_name}" in msg else msg
        for key, msg in _METADATA_SEARCH_ERROR_MESSAGES_TEMPLATE.items()
    }


PROGRAMME_CONTENT_ERROR_MESSAGES = _create_metadata_error_messages(
    "programme content details"
)

TRANSMISSION_LOG_PROGRAMME_DETAILS_ERROR_MESSAGES = _create_metadata_error_messages(
    "transmission log programme details"
)

HTTP_STATUS_MESSAGES: dict[int, str] = {
	400: "Bad request to Barb API",
	401: "Unauthorized: invalid API credentials",
	403: "Forbidden: access denied by Barb API",
	404: "Barb API endpoint not found",
	429: "Too many requests to Barb API",
	500: "Barb API internal server error",
	502: "Barb API gateway error",
	503: "Barb API is temporarily unavailable",
	504: "Barb API gateway timeout",
}


def _format_http_error_generic(status_code: int, fallback_msg: str) -> str:
    """Generic HTTP error formatter."""
    base_message = HTTP_STATUS_MESSAGES.get(status_code, fallback_msg)
    return f"{base_message} (status {status_code})."


def format_http_error(status_code: int) -> str:
    """Return a concise HTTP failure message for connection/auth calls."""
    return _format_http_error_generic(status_code, "Barb API request failed")


def format_station_http_error(status_code: int) -> str:
    """Return a concise HTTP failure message for station metadata calls."""
    return _format_http_error_generic(status_code, "Failed to fetch stations")

def format_programme_content_http_error(status_code: int) -> str:
    """Return a concise HTTP failure message for programme content metadata calls."""
    return _format_http_error_generic(
        status_code, "Failed to fetch programme content details"
    )


def format_transmission_log_programme_details_http_error(status_code: int) -> str:
    """Return a concise HTTP failure message for transmission log programme details calls."""
    return _format_http_error_generic(
        status_code, "Failed to fetch transmission log programme details"
    )


def format_split_station_factor_http_error(status_code: int) -> str:
    """Return a concise HTTP failure message for split station factor metadata calls."""
    return _format_http_error_generic(
        status_code, "Failed to fetch split station factors"
    )


def format_panel_members_http_error(status_code: int) -> str:
    """Return a concise HTTP failure message for panel members metadata calls."""
    return _format_http_error_generic(status_code, "Failed to fetch panel members")
PROGRAMME_AUDIENCES_ERROR_MESSAGES: dict[str, str] = {
    "headers_missing": _HEADERS_MISSING,
    "min_transmission_date_required": _MIN_TRANSMISSION_DATE_REQUIRED,
    "max_transmission_date_required": _MAX_TRANSMISSION_DATE_REQUIRED,
    "panel_code_required": _PANEL_CODE_REQUIRED,
    "network_error": "Unable to fetch programme audiences. Check your internet connection.",
    "malformed_json": "Invalid programme audiences response from Barb API.",
    "payload_not_dict": "Unexpected programme audiences payload type: {payload_type}",
    "no_results": "No programme audiences returned.",
}
