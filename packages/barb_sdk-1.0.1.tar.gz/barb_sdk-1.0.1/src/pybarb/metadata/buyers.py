"""Buyers metadata endpoint."""
from typing import Any

import pandas as pd
import requests

from pybarb.constants.errors import BUYER_ERROR_MESSAGES, format_http_error
from pybarb.metadata.utils.metadata_common import (
    fetch_metadata,
    parse_required_string_list_payload,
    raise_for_http_error,
    validate_connection_headers,
)
from pybarb.utils import ApiError
from pybarb.utils.logging_config import get_logger

logger = get_logger(__name__)


class Buyers:
    def __init__(self, connection: Any):
        self.connection = connection
        self.api_url = f"{self.connection.api_root.rstrip('/')}/meta/buyers"

    def get_buyers(self) -> list[str]:
        """Fetch all buyer names from the API.

        Returns:
            list[str]: A list of buyer name strings.

        Raises:
            ApiError: If not connected, the request fails, or the response is malformed.
        """
        validate_connection_headers(
            headers=self.connection.headers,
            headers_missing_message=BUYER_ERROR_MESSAGES["headers_missing"],
            logger=logger,
            logger_message="Buyers requested before connection headers were set",
        )
        response = fetch_metadata(
            request_get=requests.get,
            api_url=self.api_url,
            headers=self.connection.headers,
            network_error_message=BUYER_ERROR_MESSAGES["network_error"],
            logger=logger,
            logger_message="Buyers request failed due to request exception",
        )
        raise_for_http_error(response, format_http_error)
        return parse_required_string_list_payload(
            response=response,
            malformed_json_message=BUYER_ERROR_MESSAGES["malformed_json"],
            payload_not_list_message=BUYER_ERROR_MESSAGES["payload_not_list"],
            empty_payload_message=BUYER_ERROR_MESSAGES["no_results"],
        )

    def get_buyers_dataframe(self) -> pd.DataFrame:
        """Fetch all buyers and return as a flat DataFrame.

        Returns:
            pd.DataFrame: Single-column DataFrame with a ``buyer_name`` column,
            one row per buyer.

        Raises:
            ApiError: If not connected, the request fails, or the response is malformed.
        """
        data = self.get_buyers()
        return pd.DataFrame({"buyer_name": data})

