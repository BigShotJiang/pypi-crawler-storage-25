from typing import Any

import requests

from pybarb.constants.errors import (
    PROGRAMME_CONTENT_ERROR_MESSAGES,
    format_programme_content_http_error,
)
from pybarb.metadata.utils.metadata_common import validate_connection_headers
from pybarb.metadata.utils.search_utils import (
    fetch_search_results,
    parse_required_list_payload,
    raise_for_search_http_error,
    validate_search_string,
)
from pybarb.utils.logging_config import get_logger


logger = get_logger(__name__)


class ProgrammeContentDetails:
    def __init__(self, connection: Any):
        self.connection = connection
        self.api_url = f"{self.connection.api_root.rstrip('/')}/meta/programme_content_details"

    def list_programme_content_details(self, search_string: str) -> list[dict[str, Any]]:
        """
        Fetches programme content details from the API.

        Args:
            search_string: Filter string for programme content.

        Returns:
            list[dict[str, Any]]: Programme content details.
        """
        validate_connection_headers(
            headers=self.connection.headers,
            headers_missing_message=PROGRAMME_CONTENT_ERROR_MESSAGES["headers_missing"],
            logger=logger,
            logger_message="Programme content details requested before connection headers were set",
        )
        normalized_search = validate_search_string(
            search_string,
            PROGRAMME_CONTENT_ERROR_MESSAGES["search_string_required"],
            PROGRAMME_CONTENT_ERROR_MESSAGES["search_string_min_length"],
        )
        response = fetch_search_results(
            request_get=requests.get,
            api_url=self.api_url,
            headers=self.connection.headers,
            search_string=normalized_search,
            network_error_message=PROGRAMME_CONTENT_ERROR_MESSAGES["network_error"],
            logger=logger,
            logger_message="Programme content details request failed due to request exception",
        )
        raise_for_search_http_error(
            response,
            format_programme_content_http_error,
            PROGRAMME_CONTENT_ERROR_MESSAGES["search_string_required"],
            PROGRAMME_CONTENT_ERROR_MESSAGES["search_string_min_length"],
        )
        return parse_required_list_payload(
            response,
            PROGRAMME_CONTENT_ERROR_MESSAGES["malformed_json"],
            PROGRAMME_CONTENT_ERROR_MESSAGES["payload_not_list"],
            PROGRAMME_CONTENT_ERROR_MESSAGES["no_results"],
        )

