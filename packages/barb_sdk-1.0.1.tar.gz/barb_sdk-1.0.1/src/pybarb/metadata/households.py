from typing import Any

import pandas as pd
import requests

from pybarb.constants import format_http_error
from pybarb.constants.constants import HOUSEHOLDS_COLUMN_MAP, HOUSEHOLDS_OUTPUT_COLUMNS
from pybarb.constants.errors import HOUSEHOLDS_ERROR_MESSAGE
from pybarb.metadata.utils.metadata_common import (
    fetch_metadata,
    parse_required_list_payload,
    raise_for_http_error,
    validate_connection_headers,
)

from pybarb.utils import ApiError
from pybarb.utils.logging_config import get_logger
from pybarb.utils.dataframe_utils import to_flat_dataframe

logger = get_logger(__name__)




class Households:
    def __init__(self, connection):
        self.connection = connection
        self.api_url = f"{self.connection.api_root.rstrip('/')}/meta/households"


    def get_households(
        self,
        panel_start_date: str,
        panel_end_date: str,
        last_updated_greater_than: str | None = None,
        panel_code: str | None = None,
        panel_region: str | None = None,
    ) -> list[dict[str, Any]]:

        """
        Fetches all households within a specified date range.
        """

        validate_connection_headers(
            headers=self.connection.headers,
            headers_missing_message=HOUSEHOLDS_ERROR_MESSAGE["headers_missing"],
            logger=logger,
            logger_message="Households data requested before connection headers were set",
        )

        if not isinstance(panel_start_date, str) or not panel_start_date.strip():
            raise ApiError(HOUSEHOLDS_ERROR_MESSAGE["panel_start_date_required"])

        if not isinstance(panel_end_date, str) or not panel_end_date.strip():
            raise ApiError(HOUSEHOLDS_ERROR_MESSAGE["panel_end_date_required"])

        params = {
            "panel_start_date": panel_start_date,
            "panel_end_date": panel_end_date,
            "last_updated_greater_than": last_updated_greater_than,
            "panel_code": panel_code,
            "panel_region": panel_region,
        }

        response = fetch_metadata(
            request_get=requests.get,
            api_url=self.api_url,
            headers=self.connection.headers,
            network_error_message=HOUSEHOLDS_ERROR_MESSAGE['network_error'],
            params=params,
            logger=logger,
            logger_message="Households data fetch request",
        )

        raise_for_http_error(response, self._format_error)

        return parse_required_list_payload(
            response=response,
            malformed_json_message=HOUSEHOLDS_ERROR_MESSAGE["malformed_json"],
            payload_not_list_message=HOUSEHOLDS_ERROR_MESSAGE["payload_not_list"],
            empty_payload_message=HOUSEHOLDS_ERROR_MESSAGE["no_results"],
        )


    def get_households_flat_dataframe(
        self,
        panel_start_date: str,
        panel_end_date: str,
        last_updated_greater_than: str | None = None,
        panel_code: str | None = None,
        panel_region: str | None = None,
    ) -> pd.DataFrame:
        """Return households as a flattened DataFrame.

        The nested ``devices`` list is expanded into rows and household
        metadata is preserved as top-level columns.
        """
        data = self.get_households(
            panel_start_date=panel_start_date,
            panel_end_date=panel_end_date,
            last_updated_greater_than=last_updated_greater_than,
            panel_code=panel_code,
            panel_region=panel_region,
        )

        flat_df = to_flat_dataframe(
            data,
            record_path="devices",
            meta=[
                ["household_data", "household_number"],
                ["household_data", "date_valid_for"],
                ["household_data", "mosaic_classification_2014"],
                ["household_data", "bbc_itv_segment"],
                ["household_data", "bbc_region_code"],
                ["household_data", "bbc_sub_reporting_region"],
                ["household_data", "broadband"],
                ["household_data", "demographic_cell"],
                ["household_data", "language_spoken_at_home"],
                ["household_data", "number_of_computers"],
                ["household_data", "number_of_dvds"],
                ["household_data", "number_of_people"],
                ["household_data", "number_of_pvrs"],
                ["household_data", "number_of_tv_sets"],
                ["household_data", "number_of_vcrs"],
                ["household_data", "number_of_dvd_players_not_recorders"],
                ["household_data", "number_of_dvd_recorders"],
                ["household_data", "number_of_other_pvrs"],
                ["household_data", "number_of_sky_plus_pvrs"],
                ["household_data", "panel_membership_status"],
                ["household_data", "presence_of_children"],
                ["household_data", "replication_factor"],
                ["household_data", "social_class"],
                ["household_data", "welsh_speaking_home"],
                ["household_data", "ad_tier"],
            ],
        )

        return self._map_and_order_flat_columns(flat_df)

    @staticmethod
    def _map_and_order_flat_columns(flat_df: pd.DataFrame) -> pd.DataFrame:
        """Apply requested output names and keep a stable ordered schema."""
        mapped_df = flat_df.rename(columns=HOUSEHOLDS_COLUMN_MAP)
        return mapped_df.reindex(columns=HOUSEHOLDS_OUTPUT_COLUMNS)

    @staticmethod
    def _format_error(status_code: int) -> str:
        return format_http_error(status_code)
