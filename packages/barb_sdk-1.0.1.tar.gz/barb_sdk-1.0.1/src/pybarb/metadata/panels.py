from typing import Any
import re

import requests

from pybarb.constants.errors import PANEL_ERROR_MESSAGES, format_http_error
from pybarb.metadata.utils.metadata_common import (
    fetch_metadata,
    parse_required_list_payload,
    raise_for_http_error,
    validate_connection_headers,
)
from pybarb.utils import ApiError

from pybarb.utils.logging_config import get_logger

logger = get_logger(__name__)


class Panels:
    def __init__(self, connection: Any):
        self.connection = connection
        self.api_url = f"{self.connection.api_root.rstrip('/')}/meta/panels"

    def get_panels(self) -> list[dict[str, Any]]:
        """Fetch all panel metadata records."""
        validate_connection_headers(
            headers=self.connection.headers,
            headers_missing_message=PANEL_ERROR_MESSAGES["headers_missing"],
            logger=logger,
            logger_message="Panels requested before connection headers were set",
        )
        response = fetch_metadata(
            request_get=requests.get,
            api_url=self.api_url,
            headers=self.connection.headers,
            network_error_message=PANEL_ERROR_MESSAGES["network_error"],
            logger=logger,
            logger_message="Panels request failed due to request exception",
        )
        raise_for_http_error(response, format_http_error)
        return parse_required_list_payload(
            response=response,
            malformed_json_message=PANEL_ERROR_MESSAGES["malformed_json"],
            payload_not_list_message=PANEL_ERROR_MESSAGES["payload_not_list"],
            empty_payload_message=PANEL_ERROR_MESSAGES["no_results"],
        )

    def list_panels(self, regex_filter: str | None = None) -> list[dict[str, Any]]:
        """Return all panel records, optionally filtered by panel_region regex."""
        if regex_filter is not None and not isinstance(regex_filter, str):
            raise ApiError(PANEL_ERROR_MESSAGES["invalid_regex"])

        pattern = None
        if regex_filter is not None:
            try:
                pattern = re.compile(regex_filter, flags=re.IGNORECASE)
            except re.error as exc:
                raise ApiError(PANEL_ERROR_MESSAGES["invalid_regex"]) from exc

        data = self.get_panels()
        if pattern is None:
            return data

        def _panel_region(item: dict[str, Any]) -> str:
            return item.get("panel_region") or item.get("PANEL_REGION") or ""

        matches = [
            item
            for item in data
            if isinstance(item, dict) and pattern.search(_panel_region(item))
        ]

        if not matches:
            raise ApiError(
                PANEL_ERROR_MESSAGES["panel_not_found"].format(panel_region=regex_filter)
            )
        return matches

    def get_panel_code(self, panel_region: str) -> str:
        """Return the panel code for an exact panel_region match."""
        if not isinstance(panel_region, str) or not panel_region.strip():
            raise ApiError(PANEL_ERROR_MESSAGES["panel_region_required"])

        panel_region_normalized = panel_region.strip().lower()
        panel_codes = [
            item.get("panel_code", item.get("PANEL_CODE"))
            for item in self.get_panels()
            if isinstance(item, dict)
            and isinstance(item.get("panel_region", item.get("PANEL_REGION")), str)
            and item.get("panel_region", item.get("PANEL_REGION")).strip().lower()
            == panel_region_normalized
        ]

        if len(panel_codes) == 1:
            return str(panel_codes[0])
        if not panel_codes:
            raise ApiError(
                PANEL_ERROR_MESSAGES["panel_not_found"].format(panel_region=panel_region)
            )
        raise ApiError(
            PANEL_ERROR_MESSAGES["panel_multiple_matches"].format(panel_region=panel_region)
        )

