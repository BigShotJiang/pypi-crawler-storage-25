# Station metadata endpoint
from typing import Any
import requests
import re

from pybarb.constants.errors import STATION_ERROR_MESSAGES, format_station_http_error
from pybarb.utils.logging_config import get_logger
from pybarb.utils import ApiError


logger = get_logger(__name__)


class Station:

    def __init__(self, connection: Any):
        self.connection = connection
        self.api_url = f"{self.connection.api_root.rstrip('/')}/meta/stations"


    def get_station_code(self, station_name: str) -> int | str:
        """
        Gets the station code for a given station name.

        Args:
            station_name (str): The name of the station to query.

        Returns:
            str: The station code.
        """
        if not station_name or not station_name.strip():
            logger.warning("Station code lookup called with empty station name")
            raise ApiError(STATION_ERROR_MESSAGES["invalid_station_name"])
        if not self.connection.headers:
            logger.error("Station code lookup requested before connection headers were set")
            raise ApiError(STATION_ERROR_MESSAGES["headers_missing"])

        try:
            logger.debug("Fetching station metadata for code lookup")
            r = requests.get(url=self.api_url, headers=self.connection.headers)
        except requests.exceptions.RequestException:
            logger.error("Station code lookup failed due to request exception")
            raise ApiError(STATION_ERROR_MESSAGES["network_error"])

        if r.status_code != 200:
            logger.warning("Station code lookup returned status=%s", r.status_code)
            raise ApiError(
                format_station_http_error(r.status_code),
                status_code=r.status_code,
                response_body=r.text,
            )

        try:
            api_data = r.json()
        except ValueError:
            logger.error("Station code lookup returned malformed JSON")
            raise ApiError(STATION_ERROR_MESSAGES["malformed_json"], response_body=r.text)

        if not isinstance(api_data, list):
            logger.error("Unexpected station metadata type: %s (expected list)", type(api_data).__name__)
            raise ApiError(
                STATION_ERROR_MESSAGES["payload_not_list"].format(payload_type=type(api_data).__name__),
                response_body=r.text,
            )

        station_name_normalized = station_name.strip().lower()
        station_codes: list[int | str] = []
        for station in api_data:
            if not isinstance(station, dict):
                continue
            candidate_name = station.get("station_name", station.get("STATION_NAME"))
            candidate_code = station.get("station_code", station.get("STATION_CODE"))
            if (
                isinstance(candidate_name, str)
                and isinstance(candidate_code, (str, int))
                and station_name_normalized == candidate_name.strip().lower()
            ):
                station_codes.append(candidate_code)

        if len(station_codes) == 1:
            return station_codes[0]
        if len(station_codes) == 0:
            logger.info("No station code found for station_name=%s", station_name.strip())
            raise ApiError(STATION_ERROR_MESSAGES["station_not_found"].format(station_name=station_name))
        logger.warning("Multiple station codes matched station_name=%s", station_name.strip())
        raise ApiError(STATION_ERROR_MESSAGES["station_multiple_matches"].format(station_name=station_name))


    def list_stations(self, regex_filter:str | None =None)-> list[str] :
        """
        Lists the stations available in the API.

        Returns:
            list: The stations result set.
        """
        if not self.connection.headers:
            logger.error("Station list requested before connection headers were set")
            raise ApiError(STATION_ERROR_MESSAGES["headers_missing"])

        try:
            logger.debug("Fetching station metadata for station list")
            api_response_data = requests.get(url=self.api_url, headers=self.connection.headers)
        except requests.exceptions.RequestException:
            logger.error("Station list request failed due to request exception")
            raise ApiError(STATION_ERROR_MESSAGES["network_error"])

        if api_response_data.status_code != 200:
            logger.warning("Station list request returned status=%s", api_response_data.status_code)
            raise ApiError(
                format_station_http_error(api_response_data.status_code),
                status_code=api_response_data.status_code,
                response_body=api_response_data.text,
            )

        try:
            payload = api_response_data.json()
        except ValueError:
            logger.error("Station list request returned malformed JSON")
            raise ApiError(STATION_ERROR_MESSAGES["malformed_json"], response_body=api_response_data.text)

        if not isinstance(payload, list):
            raise ApiError(
                STATION_ERROR_MESSAGES["payload_not_list"].format(payload_type=type(payload).__name__),
                response_body=api_response_data.text,
            )

        list_of_stations = []
        for station in payload:
            if not isinstance(station, dict):
                continue
            station_name = station.get("station_name", station.get("STATION_NAME"))
            if isinstance(station_name, str):
                list_of_stations.append(station_name)
        if len(list_of_stations) == 0:
            logger.info("Station list payload did not contain station names")
            raise ApiError(STATION_ERROR_MESSAGES["no_stations"])
        if regex_filter is not None:
            regex = re.compile(regex_filter, flags=re.IGNORECASE)
            list_of_stations = list(filter(regex.search, list_of_stations))
        return list_of_stations



    def get_stations(self) -> list[dict[str, Any]]:
        """
        Gets the full station data from the API.

        Returns:
            list[dict[str, Any]]: The full station data.

        Raises:
            ApiError: If not connected, the request fails, or the response is malformed.
        """
        if not self.connection.headers:
            logger.error("Full station payload requested before connection headers were set")
            raise ApiError(STATION_ERROR_MESSAGES["headers_missing"])
        try:
            logger.debug("Fetching full station payload")
            r = requests.get(url=self.api_url, headers=self.connection.headers)
        except requests.exceptions.RequestException:
            logger.error("Full station payload request failed due to request exception")
            raise ApiError(STATION_ERROR_MESSAGES["network_error"])
        if r.status_code != 200:
            logger.warning("Full station payload request returned status=%s", r.status_code)
            raise ApiError(
                format_station_http_error(r.status_code),
                status_code=r.status_code,
                response_body=r.text,
            )
        try:
            stations = r.json()
        except ValueError:
            logger.error("Full station payload response was malformed JSON")
            raise ApiError(STATION_ERROR_MESSAGES["malformed_json"], response_body=r.text)

        if not isinstance(stations, list):
            logger.error("Unexpected station payload type: %s (expected list)", type(stations).__name__)
            raise ApiError(
                STATION_ERROR_MESSAGES["payload_not_list"].format(payload_type=type(stations).__name__),
                response_body=r.text,
            )

        for idx, station in enumerate(stations):
            if not isinstance(station, dict):
                logger.error("Invalid station payload entry type=%s at index=%s", type(station).__name__, idx)
                raise ApiError(
                    STATION_ERROR_MESSAGES["entry_not_dict"].format(index=idx, entry_type=type(station).__name__),
                    response_body=r.text,
                )
        return stations

