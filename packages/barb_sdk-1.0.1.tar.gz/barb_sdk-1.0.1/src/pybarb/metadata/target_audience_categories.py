from typing import Any

import pandas as pd
import requests

from pybarb.constants import format_http_error
from pybarb.constants.constants import (
    TARGET_AUDIENCE_CATEGORIES_COLUMN_MAP,
    TARGET_AUDIENCE_CATEGORIES_OUTPUT_COLUMNS,
)
from pybarb.constants.errors import TARGET_AUDIENCE_CATEGORIES_ERROR_MESSAGES
from pybarb.metadata.utils.metadata_common import (
    fetch_metadata,
    parse_required_list_payload,
    raise_for_http_error,
    validate_connection_headers,
)

from pybarb.utils import ApiError
from pybarb.utils.logging_config import get_logger
from pybarb.utils.dataframe_utils import to_flat_dataframe

logger = get_logger(__name__)


class TargetAudienceCategories:
    def __init__(self, connection):
        self.connection = connection
        self.api_url = f"{self.connection.api_root.rstrip('/')}/meta/target_audience_categories"

    def get_target_audience_categories(
        self,
        max_date: str,
        min_date: str,
        panel_code: int | str | list[int | str],
    ) -> list[dict[str, Any]]:
        """
        Fetches target audience categories for a given date range and panel.
        """
        validate_connection_headers(
            headers=self.connection.headers,
            headers_missing_message=TARGET_AUDIENCE_CATEGORIES_ERROR_MESSAGES["headers_missing"],
            logger=logger,
            logger_message="Target audience categories requested before connection headers were set",
        )

        if not isinstance(max_date, str) or not max_date.strip():
            raise ApiError(TARGET_AUDIENCE_CATEGORIES_ERROR_MESSAGES["max_date_required"])

        if not isinstance(min_date, str) or not min_date.strip():
            raise ApiError(TARGET_AUDIENCE_CATEGORIES_ERROR_MESSAGES["min_date_required"])

        if panel_code is None:
            raise ApiError(TARGET_AUDIENCE_CATEGORIES_ERROR_MESSAGES["panel_code_required"])

        # Validate and format panel_code (max 10 items)
        if isinstance(panel_code, list):
            if len(panel_code) > 10:
                raise ApiError(TARGET_AUDIENCE_CATEGORIES_ERROR_MESSAGES["panel_code_limit"])
            panel_code = ",".join(map(str, panel_code))
        elif isinstance(panel_code, str):
            codes = [c.strip() for c in panel_code.split(",") if c.strip()]
            if len(codes) > 10:
                raise ApiError(TARGET_AUDIENCE_CATEGORIES_ERROR_MESSAGES["panel_code_limit"])

        params = {
            "max_date": max_date,
            "min_date": min_date,
            "panel_code": panel_code,
        }

        response = fetch_metadata(
            request_get=requests.get,
            api_url=self.api_url,
            headers=self.connection.headers,
            network_error_message=TARGET_AUDIENCE_CATEGORIES_ERROR_MESSAGES["network_error"],
            params=params,
            logger=logger,
            logger_message="Target audience categories data fetch request",
        )

        raise_for_http_error(response, self._format_error)

        return parse_required_list_payload(
            response=response,
            malformed_json_message=TARGET_AUDIENCE_CATEGORIES_ERROR_MESSAGES["malformed_json"],
            payload_not_list_message=TARGET_AUDIENCE_CATEGORIES_ERROR_MESSAGES["payload_not_list"],
            empty_payload_message=TARGET_AUDIENCE_CATEGORIES_ERROR_MESSAGES["no_results"],
        )

    def get_target_audience_categories_flat_dataframe(
        self,
        max_date: str,
        min_date: str,
        panel_code: int | str | list[int | str],
    ) -> pd.DataFrame:
        """
        Fetches target audience categories as a flattened DataFrame.
        """
        data = self.get_target_audience_categories(
            max_date=max_date,
            min_date=min_date,
            panel_code=panel_code,
        )

        flat_df = to_flat_dataframe(data)

        return self._map_and_order_flat_columns(flat_df)

    @staticmethod
    def _map_and_order_flat_columns(flat_df: pd.DataFrame) -> pd.DataFrame:
        """Apply requested output names and keep a stable ordered schema."""
        mapped_df = flat_df.rename(columns=TARGET_AUDIENCE_CATEGORIES_COLUMN_MAP)
        return mapped_df.reindex(columns=TARGET_AUDIENCE_CATEGORIES_OUTPUT_COLUMNS)

    @staticmethod
    def _format_error(status_code: int) -> str:
        return format_http_error(status_code)
