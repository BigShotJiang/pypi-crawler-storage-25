import io
from typing import Any

import pandas as pd
import pyarrow.ipc as ipc
import requests

from pybarb.constants import format_http_error
from pybarb.constants.constants import SPOT_SCHEDULE_COLUMN_MAP, SPOT_SCHEDULE_OUTPUT_COLUMNS
from pybarb.constants.errors import SPOT_SCHEDULE_ERROR_MESSAGES
from pybarb.metadata.utils.metadata_common import (
    fetch_metadata,
    raise_for_http_error,
    validate_connection_headers,
)
from pybarb.utils import ApiError
from pybarb.utils.logging_config import get_logger
from pybarb.utils.dataframe_utils import to_flat_dataframe

logger = get_logger(__name__)


class SpotScheduleArrow:
    def __init__(self, connection):
        self.connection = connection
        self.api_url = f"{self.connection.api_root.rstrip('/')}/meta/spot_schedule_new"

    def get_spot_schedule(
        self,
        min_scheduled_date: str,
        max_scheduled_date: str,
        station_code: str | None = None,
        last_updated_greater_than: str | None = None,
    ) -> bytes:
        """
        Fetches spot schedule metadata in Arrow stream format.
        """
        validate_connection_headers(
            headers=self.connection.headers,
            headers_missing_message=SPOT_SCHEDULE_ERROR_MESSAGES["headers_missing"],
            logger=logger,
            logger_message="Spot schedule Arrow data requested before connection headers were set",
        )

        if not isinstance(min_scheduled_date, str) or not min_scheduled_date.strip():
            raise ApiError(SPOT_SCHEDULE_ERROR_MESSAGES["min_scheduled_date_required"])

        if not isinstance(max_scheduled_date, str) or not max_scheduled_date.strip():
            raise ApiError(SPOT_SCHEDULE_ERROR_MESSAGES["max_scheduled_date_required"])

        params = {
            "min_scheduled_date": min_scheduled_date,
            "max_scheduled_date": max_scheduled_date,
            "station_code": station_code,
            "last_updated_greater_than": last_updated_greater_than,
        }

        headers = self.connection.headers.copy()

        response = fetch_metadata(
            request_get=requests.get,
            api_url=self.api_url,
            headers=headers,
            network_error_message=SPOT_SCHEDULE_ERROR_MESSAGES["network_error"],
            params=params,
            logger=logger,
            logger_message="Spot schedule Arrow data fetch request",
        )

        raise_for_http_error(response, self._format_error)

        return response.content

    def get_spot_schedule_dataframe(
        self,
        min_scheduled_date: str,
        max_scheduled_date: str,
        station_code: str | None = None,
        last_updated_greater_than: str | None = None,
    ) -> pd.DataFrame:
        """
        Fetches spot schedule as a DataFrame from Arrow stream.
        """
        content = self.get_spot_schedule(
            min_scheduled_date=min_scheduled_date,
            max_scheduled_date=max_scheduled_date,
            station_code=station_code,
            last_updated_greater_than=last_updated_greater_than,
        )

        if not content:
            return pd.DataFrame()

        with io.BytesIO(content) as buffer:
            with ipc.RecordBatchStreamReader(buffer) as reader:
                table = reader.read_all()
                df = table.to_pandas()
                return self._map_and_order_columns(df)

    @staticmethod
    def _map_and_order_columns(df: pd.DataFrame) -> pd.DataFrame:
        """Apply requested output names and keep a stable ordered schema."""
        # Snowflake columns are often uppercase; normalize to lowercase to match mapping keys
        df.columns = [col.lower() for col in df.columns]
        
        # If the data is wrapped in a single column (common for Snowflake Arrow streams), flatten it
        if "spot_schedule_data" in df.columns:
            import json
            # Handle list of JSON strings or similar
            raw_data = df["spot_schedule_data"].tolist()
            # If the data is JSON strings, parse them
            if isinstance(raw_data[0], str):
                raw_data = [json.loads(r) for r in raw_data if r]
                
            df = to_flat_dataframe(
                raw_data,
                record_path="spot_schedule",
                meta=[
                    "scheduled_date",
                    ["panel", "is_macro_region"],
                    ["panel", "panel_code"],
                    ["panel", "panel_region"],
                ],
            )
            df.columns = [col.lower() for col in df.columns]

        mapped_df = df.rename(columns=SPOT_SCHEDULE_COLUMN_MAP)
        return mapped_df.reindex(columns=SPOT_SCHEDULE_OUTPUT_COLUMNS)

    @staticmethod
    def _format_error(status_code: int) -> str:
        return format_http_error(status_code)
