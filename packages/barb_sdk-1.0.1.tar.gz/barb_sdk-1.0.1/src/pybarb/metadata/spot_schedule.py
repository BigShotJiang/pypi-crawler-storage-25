from typing import Any

import pandas as pd
import requests

from pybarb.constants import format_http_error
from pybarb.constants.constants import SPOT_SCHEDULE_COLUMN_MAP, SPOT_SCHEDULE_OUTPUT_COLUMNS
from pybarb.constants.errors import SPOT_SCHEDULE_ERROR_MESSAGES
from pybarb.metadata.utils.metadata_common import (
    fetch_metadata,
    parse_required_list_payload,
    raise_for_http_error,
    validate_connection_headers,
)

from pybarb.utils import ApiError
from pybarb.utils.logging_config import get_logger
from pybarb.utils.dataframe_utils import to_flat_dataframe

logger = get_logger(__name__)


class SpotSchedule:
    def __init__(self, connection):
        self.connection = connection
        self.api_url = f"{self.connection.api_root.rstrip('/')}/meta/spot_schedule"

    def get_spot_schedule(
        self,
        min_scheduled_date: str,
        max_scheduled_date: str,
        station_code: str | None = None,
        last_updated_greater_than: str | None = None,
    ) -> list[dict[str, Any]]:
        """
        Fetches spot schedule metadata for a given date range and station.
        """
        validate_connection_headers(
            headers=self.connection.headers,
            headers_missing_message=SPOT_SCHEDULE_ERROR_MESSAGES["headers_missing"],
            logger=logger,
            logger_message="Spot schedule data requested before connection headers were set",
        )

        if not isinstance(min_scheduled_date, str) or not min_scheduled_date.strip():
            raise ApiError(SPOT_SCHEDULE_ERROR_MESSAGES["min_scheduled_date_required"])

        if not isinstance(max_scheduled_date, str) or not max_scheduled_date.strip():
            raise ApiError(SPOT_SCHEDULE_ERROR_MESSAGES["max_scheduled_date_required"])

        params = {
            "min_scheduled_date": min_scheduled_date,
            "max_scheduled_date": max_scheduled_date,
            "station_code": station_code,
            "last_updated_greater_than": last_updated_greater_than,
        }

        response = fetch_metadata(
            request_get=requests.get,
            api_url=self.api_url,
            headers=self.connection.headers,
            network_error_message=SPOT_SCHEDULE_ERROR_MESSAGES["network_error"],
            params=params,
            logger=logger,
            logger_message="Spot schedule data fetch request",
        )

        raise_for_http_error(response, self._format_error)

        return parse_required_list_payload(
            response=response,
            malformed_json_message=SPOT_SCHEDULE_ERROR_MESSAGES["malformed_json"],
            payload_not_list_message=SPOT_SCHEDULE_ERROR_MESSAGES["payload_not_list"],
            empty_payload_message=SPOT_SCHEDULE_ERROR_MESSAGES["no_results"],
        )

    def get_spot_schedule_flat_dataframe(
        self,
        min_scheduled_date: str,
        max_scheduled_date: str,
        station_code: str | None = None,
        last_updated_greater_than: str | None = None,
    ) -> pd.DataFrame:
        """
        Fetches spot schedule as a flattened DataFrame.
        """
        data = self.get_spot_schedule(
            min_scheduled_date=min_scheduled_date,
            max_scheduled_date=max_scheduled_date,
            station_code=station_code,
            last_updated_greater_than=last_updated_greater_than,
        )

        flat_df = to_flat_dataframe(
            data,
            record_path="spot_schedule",
            meta=[
                "scheduled_date",
                ["panel", "is_macro_region"],
                ["panel", "panel_code"],
                ["panel", "panel_region"],
            ],
        )

        return self._map_and_order_flat_columns(flat_df)

    @staticmethod
    def _map_and_order_flat_columns(flat_df: pd.DataFrame) -> pd.DataFrame:
        """Apply requested output names and keep a stable ordered schema."""
        mapped_df = flat_df.rename(columns=SPOT_SCHEDULE_COLUMN_MAP)
        return mapped_df.reindex(columns=SPOT_SCHEDULE_OUTPUT_COLUMNS)

    @staticmethod
    def _format_error(status_code: int) -> str:
        return format_http_error(status_code)
