from typing import Any

import requests
import pandas as pd

from pybarb.constants import format_http_error
from pybarb.constants.constants import PROGRAMME_SCHEDULE_COLUMN_MAP, PROGRAMME_SCHEDULE_OUTPUT_COLUMNS
from pybarb.constants.errors import PROGRAMME_SCHEDULE
from pybarb.metadata.utils.metadata_common import (
    fetch_metadata,
    parse_required_list_payload,
    raise_for_http_error,
    validate_connection_headers,
)
from pybarb.utils import ApiError
from pybarb.utils.dataframe_utils import to_flat_dataframe
from pybarb.utils.logging_config import get_logger

logger = get_logger(__name__)


class ProgrammeSchedule:
    def __init__(self, connection):
        self.connection = connection
        self.api_url = f"{self.connection.api_root.rstrip('/')}/meta/programme_schedule"

    def get_programme_schedule(
        self,
        max_schedule_date: str,
        min_schedule_date: str,
        station_code: list[str] | str | None = None,
        last_updated_greater_than: str | None = None,
    ) -> list[dict[str, Any]]:
        """
        Fetches all the programme schedule data for given filters
        Returns:
            List of dicts.
        """
        validate_connection_headers(
            headers=self.connection.headers,
            headers_missing_message=PROGRAMME_SCHEDULE["headers_missing"],
            logger=logger,
            logger_message="Program schedule requested before connection headers were set",
        )

        if not isinstance(max_schedule_date, str) or not max_schedule_date.strip():
            raise ApiError(PROGRAMME_SCHEDULE["max_schedule_date_required"])

        if not isinstance(min_schedule_date, str) or not min_schedule_date.strip():
            raise ApiError(PROGRAMME_SCHEDULE["min_schedule_date_required"])

        normalized_station_code = (
            ",".join(station_code) if isinstance(station_code, list) else station_code
        )

        params = {
            "max_scheduled_date": max_schedule_date,
            "min_scheduled_date": min_schedule_date,
            "station_code": normalized_station_code,
            "last_updated_greater_than": last_updated_greater_than,
        }

        response = fetch_metadata(
            request_get=requests.get,
            api_url=self.api_url,
            headers=self.connection.headers,
            network_error_message=PROGRAMME_SCHEDULE["network_error"],
            logger=logger,
            logger_message="Program schedule requested Request failed due to request exception",
            params=params,
        )

        raise_for_http_error(response, self._format_error)

        return parse_required_list_payload(
            response=response,
            malformed_json_message=PROGRAMME_SCHEDULE["malformed_json"],
            payload_not_list_message=PROGRAMME_SCHEDULE["payload_not_list"],
            empty_payload_message=PROGRAMME_SCHEDULE["no_results"],
        )

    def get_programme_schedule_flat_dataframe(
        self,
        max_schedule_date: str,
        min_schedule_date: str,
        station_code: list[str] | str | None = None,
        last_updated_greater_than: str | None = None,
    ) -> pd.DataFrame:
        """Return programme schedule as a flattened DataFrame.

        The nested ``station_schedule`` list is expanded into rows and key
        schedule metadata is preserved as top-level columns.
        """
        data = self.get_programme_schedule(
            max_schedule_date=max_schedule_date,
            min_schedule_date=min_schedule_date,
            station_code=station_code,
            last_updated_greater_than=last_updated_greater_than,
        )

        flat_df = to_flat_dataframe(
            data,
            record_path="station_schedule",
            meta=[
                "scheduled_date",
                ["station", "station_code"],
                ["station", "station_name"],
                ["panel", "panel_code"],
                ["panel", "panel_region"],
                ["panel", "is_macro_region"],
            ],
        )

        return self._map_and_order_flat_columns(flat_df)

    @staticmethod
    def _map_and_order_flat_columns(flat_df: pd.DataFrame) -> pd.DataFrame:
        """Apply requested output names and keep a stable ordered schema."""
        mapped_df = flat_df.rename(columns=PROGRAMME_SCHEDULE_COLUMN_MAP)
        if "schedule_broadcaster_premier" in mapped_df.columns and "channel_premier" not in mapped_df.columns:
            mapped_df["channel_premier"] = mapped_df["schedule_broadcaster_premier"]
        return mapped_df.reindex(columns=PROGRAMME_SCHEDULE_OUTPUT_COLUMNS)

    @staticmethod
    def _format_error(status_code: int) -> str:
        return format_http_error(status_code)

