from typing import Any

import pandas as pd
import requests

from pybarb.constants import format_http_error
from pybarb.constants.constants import PANEL_MEMBERS_COLUMN_MAP, PANEL_MEMBERS_OUTPUT_COLUMNS
from pybarb.constants.errors import PANEL_MEMBERS_ERROR_MESSAGES
from pybarb.metadata.utils.metadata_common import (
    fetch_metadata,
    parse_required_list_payload,
    raise_for_http_error,
    validate_connection_headers,
)

from pybarb.utils import ApiError
from pybarb.utils.logging_config import get_logger
from pybarb.utils.dataframe_utils import to_flat_dataframe

logger = get_logger(__name__)


class PanelMembers:
    def __init__(self, connection):
        self.connection = connection
        self.api_url = f"{self.connection.api_root.rstrip('/')}/meta/panel_members"

    def get_panel_members(
        self,
        panel_start_date: str,
        panel_end_date: str,
        last_updated_greater_than: str | None = None,
        panel_code: str | None = None,
        panel_region: str | None = None,
    ) -> list[dict[str, Any]]:
        """
        Fetches all panel members within a specified date range.
        """

        validate_connection_headers(
            headers=self.connection.headers,
            headers_missing_message=PANEL_MEMBERS_ERROR_MESSAGES["headers_missing"],
            logger=logger,
            logger_message="Panel members data requested before connection headers were set",
        )

        if not isinstance(panel_start_date, str) or not panel_start_date.strip():
            raise ApiError(PANEL_MEMBERS_ERROR_MESSAGES["panel_start_date_required"])

        if not isinstance(panel_end_date, str) or not panel_end_date.strip():
            raise ApiError(PANEL_MEMBERS_ERROR_MESSAGES["panel_end_date_required"])

        params = {
            "panel_start_date": panel_start_date,
            "panel_end_date": panel_end_date,
            "last_updated_greater_than": last_updated_greater_than,
            "panel_code": panel_code,
            "panel_region": panel_region,
        }

        response = fetch_metadata(
            request_get=requests.get,
            api_url=self.api_url,
            headers=self.connection.headers,
            network_error_message=PANEL_MEMBERS_ERROR_MESSAGES["network_error"],
            params=params,
            logger=logger,
            logger_message="Panel members data fetch request",
        )

        raise_for_http_error(response, self._format_error)

        return parse_required_list_payload(
            response=response,
            malformed_json_message=PANEL_MEMBERS_ERROR_MESSAGES["malformed_json"],
            payload_not_list_message=PANEL_MEMBERS_ERROR_MESSAGES["payload_not_list"],
            empty_payload_message=PANEL_MEMBERS_ERROR_MESSAGES["no_results"],
        )

    def get_panel_members_flat_dataframe(
        self,
        panel_start_date: str,
        panel_end_date: str,
        last_updated_greater_than: str | None = None,
        panel_code: str | None = None,
        panel_region: str | None = None,
    ) -> pd.DataFrame:
        """Return panel members as a flattened DataFrame.

        The nested ``panel_member_weights`` list is expanded into rows and panel member
        metadata is preserved as top-level columns.
        """
        data = self.get_panel_members(
            panel_start_date=panel_start_date,
            panel_end_date=panel_end_date,
            last_updated_greater_than=last_updated_greater_than,
            panel_code=panel_code,
            panel_region=panel_region,
        )

        flat_df = to_flat_dataframe(
            data,
            record_path="panel_member_weights",
            meta=[
                "date_valid_for",
                "date_of_birth",
                "dependency_of_children",
                "disability",
                "grocery_shopper",
                "sensory_impairment",
                "understands_sign_language",
                "ethnic_origin",
                "gaelic_language",
                "household_number",
                "household_status",
                "last_updated",
                "life_stage",
                "marital_status",
                "person_membership_status",
                "person_number",
                "sex",
                "terminal_age_of_education",
                "welsh_language",
                "working_status",
            ],
        )

        return self._map_and_order_flat_columns(flat_df)

    @staticmethod
    def _map_and_order_flat_columns(flat_df: pd.DataFrame) -> pd.DataFrame:
        """Apply requested output names and keep a stable ordered schema."""
        mapped_df = flat_df.rename(columns=PANEL_MEMBERS_COLUMN_MAP)
        return mapped_df.reindex(columns=PANEL_MEMBERS_OUTPUT_COLUMNS)

    @staticmethod
    def _format_error(status_code: int) -> str:
        from pybarb.constants.errors import format_panel_members_http_error
        return format_panel_members_http_error(status_code)
