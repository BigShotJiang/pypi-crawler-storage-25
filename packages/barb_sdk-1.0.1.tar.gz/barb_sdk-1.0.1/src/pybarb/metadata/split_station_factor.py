from typing import Any
import re

import requests

from pybarb.constants.errors import SPLIT_STATION_FACTOR_ERROR_MESSAGES
from pybarb.metadata.utils.metadata_common import (
    fetch_metadata,
    parse_required_list_payload,
    raise_for_http_error,
    validate_connection_headers,
)
from pybarb.utils import ApiError
from pybarb.utils.logging_config import get_logger

logger = get_logger(__name__)


class SplitStationFactor:
    def __init__(self, connection: Any):
        self.connection = connection
        self.api_url = f"{self.connection.api_root.rstrip('/')}/meta/split_station_factor"

    def get_split_station_factor(self) -> list[dict[str, Any]]:
        """
        Fetch all split station factors.

        Returns:
            List of split station factor dicts.

        Raises:
            ApiError: If the API call fails or returns no data.
        """
        validate_connection_headers(
            headers=self.connection.headers,
            headers_missing_message=SPLIT_STATION_FACTOR_ERROR_MESSAGES["headers_missing"],
            logger=logger,
            logger_message="Split station factors requested before connection headers were set",
        )
        response = fetch_metadata(
            request_get=requests.get,
            api_url=self.api_url,
            headers=self.connection.headers,
            network_error_message=SPLIT_STATION_FACTOR_ERROR_MESSAGES["network_error"],
            logger=logger,
            logger_message="Split station factors request failed due to request exception",
        )
        raise_for_http_error(response, self._format_error)
        return parse_required_list_payload(
            response,
            SPLIT_STATION_FACTOR_ERROR_MESSAGES["malformed_json"],
            SPLIT_STATION_FACTOR_ERROR_MESSAGES["payload_not_list"],
            SPLIT_STATION_FACTOR_ERROR_MESSAGES["no_results"],
        )

    def list_split_station_factor(
        self,
        regex_filter: str | None = None,
    ) -> list[dict[str, Any]]:
        """
        List split station factor records, optionally filtered by station-name regex.

        Args:
            regex_filter: Optional regex station-name filter (case-insensitive search).

        Returns:
            List of all matching split factor dicts.

        Raises:
            ApiError: If the API call fails, returns no data, or no matching station found.
        """
        if regex_filter is not None and not isinstance(regex_filter, str):
            raise ApiError(SPLIT_STATION_FACTOR_ERROR_MESSAGES["invalid_regex"])

        validate_connection_headers(
            headers=self.connection.headers,
            headers_missing_message=SPLIT_STATION_FACTOR_ERROR_MESSAGES["headers_missing"],
            logger=logger,
            logger_message="Split station factor lookup requested before connection headers were set",
        )
        response = fetch_metadata(
            request_get=requests.get,
            api_url=self.api_url,
            headers=self.connection.headers,
            network_error_message=SPLIT_STATION_FACTOR_ERROR_MESSAGES["network_error"],
            logger=logger,
            logger_message="Split station factor lookup failed due to request exception",
            params=None,
        )
        raise_for_http_error(response, self._format_error)
        data = parse_required_list_payload(
            response,
            SPLIT_STATION_FACTOR_ERROR_MESSAGES["malformed_json"],
            SPLIT_STATION_FACTOR_ERROR_MESSAGES["payload_not_list"],
            SPLIT_STATION_FACTOR_ERROR_MESSAGES["no_results"],
        )
        pattern = None
        if regex_filter is not None:
            try:
                pattern = re.compile(regex_filter, flags=re.IGNORECASE)
            except re.error as exc:
                raise ApiError(
                    SPLIT_STATION_FACTOR_ERROR_MESSAGES["invalid_regex"]
                ) from exc

        def _station_name(item: dict[str, Any]) -> str:
            return item.get("LOG_STATION_NAME") or item.get("log_station_name") or ""

        matches = [
            item
            for item in data
            if isinstance(item, dict)
            and (pattern is None or pattern.search(_station_name(item)))
        ]

        if pattern is not None and not matches:
            raise ApiError(
                SPLIT_STATION_FACTOR_ERROR_MESSAGES["station_not_found"].format(
                    station_name=regex_filter
                )
            )
        return matches

    @staticmethod
    def _format_error(status_code: int) -> str:
        """Format HTTP error message for split station factor endpoint."""
        from pybarb.constants.errors import format_split_station_factor_http_error
        return format_split_station_factor_http_error(status_code)
