"""Advertisers metadata endpoint."""
from typing import Any

import pandas as pd
import requests

from pybarb.constants.errors import ADVERTISER_ERROR_MESSAGES, format_http_error
from pybarb.metadata.utils.metadata_common import (
    fetch_metadata,
    parse_required_list_payload,
    raise_for_http_error,
    validate_connection_headers,
)
from pybarb.utils import ApiError
from pybarb.utils.logging_config import get_logger

logger = get_logger(__name__)


class Advertisers:
    def __init__(self, connection: Any):
        self.connection = connection
        self.api_url = f"{self.connection.api_root.rstrip('/')}/meta/advertisers"

    def get_advertisers(self) -> list[dict[str, Any]]:
        """Fetch all advertiser records from the API.

        Each record contains an ``advertiser_name`` and a ``brands`` list,
        where every brand entry has a ``brand_name`` and a ``commercial_numbers``
        list.

        Returns:
            list[dict[str, Any]]: Raw advertiser records as returned by the API.

        Raises:
            ApiError: If not connected, the request fails, or the response is malformed.
        """
        validate_connection_headers(
            headers=self.connection.headers,
            headers_missing_message=ADVERTISER_ERROR_MESSAGES["headers_missing"],
            logger=logger,
            logger_message="Advertisers requested before connection headers were set",
        )
        response = fetch_metadata(
            request_get=requests.get,
            api_url=self.api_url,
            headers=self.connection.headers,
            network_error_message=ADVERTISER_ERROR_MESSAGES["network_error"],
            logger=logger,
            logger_message="Advertisers request failed due to request exception",
        )
        raise_for_http_error(response, format_http_error)
        return parse_required_list_payload(
            response=response,
            malformed_json_message=ADVERTISER_ERROR_MESSAGES["malformed_json"],
            payload_not_list_message=ADVERTISER_ERROR_MESSAGES["payload_not_list"],
            empty_payload_message=ADVERTISER_ERROR_MESSAGES["no_results"],
        )

    def get_advertisers_dataframe(self) -> pd.DataFrame:
        """Fetch all advertisers and return as a fully-flattened DataFrame.

        The three-level hierarchy (advertiser → brand → commercial_number) is
        normalised to one row per commercial number with the following columns:

        - ``advertiser_name``
        - ``brand_name``
        - ``commercial_number``

        Returns:
            pd.DataFrame: Flat DataFrame with one row per commercial number.

        Raises:
            ApiError: If not connected, the request fails, or the response is malformed.
        """
        data = self.get_advertisers()

        # Flatten advertiser → brands, carrying advertiser_name as metadata
        df = pd.json_normalize(data, record_path="brands", meta=["advertiser_name"])

        # Explode the commercial_numbers list so each number gets its own row
        df = df.explode("commercial_numbers").reset_index(drop=True)

        # Tidy up column names
        df = df.rename(columns={"commercial_numbers": "commercial_number"})

        # Reorder to most-to-least specific
        cols = ["advertiser_name", "brand_name", "commercial_number"]
        existing = [c for c in cols if c in df.columns]
        other = [c for c in df.columns if c not in cols]
        return df[existing + other]

