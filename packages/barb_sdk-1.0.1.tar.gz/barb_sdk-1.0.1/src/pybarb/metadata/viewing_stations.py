from typing import Any
import re

import pandas as pd
import requests

from pybarb import get_logger
from pybarb.constants.errors import format_http_error, VIEWING_STATIONS_ERROR_MESSAGES
from pybarb.utils.dataframe_utils import to_flat_dataframe
from pybarb.metadata.utils.metadata_common import (
    validate_connection_headers,
    fetch_metadata,
    raise_for_http_error,
    parse_required_list_payload,
)
from pybarb.utils import ApiError

logger = get_logger(__name__)


class ViewingStations:
    def __init__(self, connection: Any):
        self.connection = connection
        self.api_url = f"{self.connection.api_root.rstrip('/')}/meta/viewing_stations"

    def get_viewing_stations(self) -> list[dict[str, Any]]:
        """
        Fetch all viewing stations.

        Returns:
            list[dict[str, Any]]
        """
        validate_connection_headers(
            headers=self.connection.headers,
            headers_missing_message=VIEWING_STATIONS_ERROR_MESSAGES["headers_missing"],
            logger=logger,
            logger_message="Viewing stations requested before connection headers were set",
        )
        response = fetch_metadata(
            request_get=requests.get,
            api_url=self.api_url,
            headers=self.connection.headers,
            network_error_message=VIEWING_STATIONS_ERROR_MESSAGES["network_error"],
            logger=logger,
            logger_message="Viewing stations request failed due to request exception",
        )
        raise_for_http_error(response, self._format_error)
        return parse_required_list_payload(
            response=response,
            malformed_json_message=VIEWING_STATIONS_ERROR_MESSAGES["malformed_json"],
            payload_not_list_message=VIEWING_STATIONS_ERROR_MESSAGES["payload_not_list"],
            empty_payload_message=VIEWING_STATIONS_ERROR_MESSAGES["no_results"],
        )

    def list_viewing_stations(
        self,
        regex_filter: str | None = None,
    ) -> list[dict[str, Any]]:
        """
        List viewing stations, optionally filtered by station name regex.

        Args:
            regex_filter: Optional case-insensitive regex pattern matched against
                          viewing_station_name (or VIEWING_STATION_NAME).

        Returns:
            All records when no filter is given, otherwise only matching records.

        Raises:
            ApiError: If the API call fails, returns no data, or the regex matches nothing.
        """
        if regex_filter is not None and not isinstance(regex_filter, str):
            raise ApiError(VIEWING_STATIONS_ERROR_MESSAGES["invalid_regex"])

        data = self.get_viewing_stations()

        if regex_filter is None:
            return data

        try:
            pattern = re.compile(regex_filter, flags=re.IGNORECASE)
        except re.error as exc:
            raise ApiError(VIEWING_STATIONS_ERROR_MESSAGES["invalid_regex"]) from exc

        def _station_name(item: dict[str, Any]) -> str:
            return (
                item.get("viewing_station_name")
                or item.get("VIEWING_STATION_NAME")
                or ""
            )

        matches = [
            item
            for item in data
            if isinstance(item, dict) and pattern.search(_station_name(item))
        ]

        if not matches:
            raise ApiError(
                VIEWING_STATIONS_ERROR_MESSAGES["station_not_found"].format(station_name=regex_filter)
            )

        return matches


    def get_viewing_stations_flat_data_frame(self) -> pd.DataFrame:
        """
        Fetch all viewing stations and return as a flattened DataFrame.

        Nested fields like regionality.areas and regionality.region are flattened
        and renamed to areas and region (without prefix).

        Returns:
            pd.DataFrame with flattened viewing stations data.
        """
        data = self.get_viewing_stations()
        df = to_flat_dataframe(data)
        
        # Rename nested columns to remove regionality prefix
        rename_map = {
            "regionality.areas": "areas",
            "regionality.region": "region",
        }
        return df.rename(columns=rename_map)


    @staticmethod
    def _format_error(status_code: int) -> str:
        return format_http_error(status_code)

