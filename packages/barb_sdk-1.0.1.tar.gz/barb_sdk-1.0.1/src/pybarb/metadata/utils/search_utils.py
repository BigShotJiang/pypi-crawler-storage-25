from collections.abc import Callable
from typing import Any

import requests

from pybarb.utils import ApiError


def validate_search_string(
    search_string: str,
    search_string_required_message: str,
    search_string_min_length_message: str,
    *,
    min_length: int = 3,
) -> str:
    if not isinstance(search_string, str) or not search_string.strip():
        raise ApiError(search_string_required_message)

    normalized_search = search_string.strip()
    if len(normalized_search) < min_length:
        raise ApiError(search_string_min_length_message)
    return normalized_search


def fetch_search_results(
    *,
    request_get: Callable[..., requests.Response],
    api_url: str,
    headers: dict[str, Any],
    search_string: str,
    network_error_message: str,
    logger: Any,
    logger_message: str,
) -> requests.Response:
    try:
        return request_get(
            url=api_url,
            headers=headers,
            params={"search_string": search_string},
        )
    except requests.exceptions.RequestException:
        logger.error(logger_message)
        raise ApiError(network_error_message)


def raise_for_search_http_error(
    response: requests.Response,
    format_http_error: Callable[[int], str],
    search_string_required_message: str,
    search_string_min_length_message: str,
) -> None:
    if response.status_code == 200:
        return

    detail = _extract_error_detail(response)
    message = _map_http_error_message(
        status_code=response.status_code,
        detail=detail,
        format_http_error=format_http_error,
        search_string_required_message=search_string_required_message,
        search_string_min_length_message=search_string_min_length_message,
    )
    raise ApiError(
        message,
        status_code=response.status_code,
        response_body=response.text,
    )


def parse_required_list_payload(
    response: requests.Response,
    malformed_json_message: str,
    payload_not_list_message: str,
    empty_payload_message: str,
) -> list[dict[str, Any]]:
    try:
        payload = response.json()
    except ValueError:
        raise ApiError(
            malformed_json_message,
            response_body=response.text,
        )

    if not isinstance(payload, list):
        raise ApiError(
            payload_not_list_message.format(payload_type=type(payload).__name__),
            response_body=response.text,
        )

    if not payload:
        raise ApiError(empty_payload_message)

    return payload


def _extract_error_detail(response: requests.Response) -> str:
    try:
        error_json = response.json()
    except ValueError:
        return response.text

    if isinstance(error_json, dict):
        return str(
            error_json.get("message")
            or error_json.get("detail")
            or error_json.get("search_string")
            or error_json
        )
    return str(error_json)


def _map_http_error_message(
    *,
    status_code: int,
    detail: str,
    format_http_error: Callable[[int], str],
    search_string_required_message: str,
    search_string_min_length_message: str,
) -> str:
    if status_code != 400:
        return format_http_error(status_code)

    detail_lower = detail.lower()
    if "blank" in detail_lower:
        return search_string_required_message
    if (
        "at least 3" in detail_lower
        or "minimum" in detail_lower
        or "min_length" in detail_lower
    ):
        return search_string_min_length_message
    return format_http_error(status_code)

