"""Common metadata HTTP request/response handlers for non-search endpoints."""

from collections.abc import Callable
from typing import Any

import requests

from pybarb.utils import ApiError


def validate_connection_headers(
    headers: dict[str, Any] | None,
    headers_missing_message: str,
    logger: Any,
    logger_message: str,
) -> None:
    """Validate that connection headers are present."""
    if not headers:
        logger.error(logger_message)
        raise ApiError(headers_missing_message)


def fetch_metadata(
    *,
    request_get: Callable[..., requests.Response],
    api_url: str,
    headers: dict[str, Any],
    network_error_message: str,
    logger: Any,
    logger_message: str,
    params: dict[str, Any] | None = None,
) -> requests.Response:
    """Fetch metadata from API endpoint with error handling."""
    try:
        return request_get(
            url=api_url,
            headers=headers,
            params=params,
        )
    except requests.exceptions.RequestException:
        logger.error(logger_message)
        raise ApiError(network_error_message)


def raise_for_http_error(
    response: requests.Response,
    format_http_error: Callable[[int], str],
) -> None:
    """Raise ApiError for non-200 HTTP status codes."""
    if response.status_code == 200:
        return

    message = format_http_error(response.status_code)
    raise ApiError(
        message,
        status_code=response.status_code,
        response_body=response.text,
    )


def parse_json_payload(
    response: requests.Response,
    malformed_json_message: str,
) -> Any:
    """Parse and return JSON payload from response."""
    try:
        return response.json()
    except ValueError:
        raise ApiError(
            malformed_json_message,
            response_body=response.text,
        )


def parse_required_list_payload(
    response: requests.Response,
    malformed_json_message: str,
    payload_not_list_message: str,
    empty_payload_message: str,
) -> list[dict[str, Any]]:
    """Parse JSON response and validate it is a non-empty list of dicts."""
    payload = parse_json_payload(response, malformed_json_message)

    if not isinstance(payload, list):
        raise ApiError(
            payload_not_list_message.format(payload_type=type(payload).__name__),
            response_body=response.text,
        )

    if not payload:
        raise ApiError(empty_payload_message)

    return payload


def parse_required_string_list_payload(
    response: requests.Response,
    malformed_json_message: str,
    payload_not_list_message: str,
    empty_payload_message: str,
) -> list[str]:
    """Parse JSON response and validate it is a non-empty list of strings."""
    payload = parse_json_payload(response, malformed_json_message)

    if not isinstance(payload, list):
        raise ApiError(
            payload_not_list_message.format(payload_type=type(payload).__name__),
            response_body=response.text,
        )

    if not payload:
        raise ApiError(empty_payload_message)

    return payload


def _extract_error_detail(response: requests.Response) -> str:
    """Extract error detail message from response."""
    try:
        error_json = response.json()
    except ValueError:
        return response.text

    if isinstance(error_json, dict):
        return str(
            error_json.get("message")
            or error_json.get("detail")
            or error_json
        )
    return str(error_json)

