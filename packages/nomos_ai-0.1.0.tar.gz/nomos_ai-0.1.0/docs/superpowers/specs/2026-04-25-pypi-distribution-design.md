# NomosAI — PyPI Distribution Design

**Date:** 2026-04-25  
**Status:** Approved  

## Goal

Package NomosAI as a PyPI-distributed MCP server that non-technical legal professionals can install with a single command (`uv` installer) and configure in Claude Desktop by pasting one JSON snippet. No conda, no `pip install`, no `spacy download` — ever.

## Target Audience

Non-technical legal/compliance professionals (lawyers, paralegals, law firm staff) on Windows and Mac. IT may handle firm-wide deployment. One simple install step is acceptable; terminal commands beyond that are not.

## Distribution Strategy

**`uv` + PyPI.** Users install `uv` (one PowerShell or curl command), then Claude Desktop calls `uvx nomos-ai` automatically. `uv` manages an isolated Python environment per-tool — no conflicts with system Python, no conda required.

The spaCy large French model (`fr_core_news_lg`, ~550MB) is listed as a direct URL dependency in `pyproject.toml`, so it installs automatically with the package. No separate model download step.

**First-run experience:** `uvx nomos-ai` downloads the package + all dependencies on first invocation (~1–3 minutes). Subsequent starts are instant (uv caches the environment).

### User install instructions

**Windows (PowerShell):**
```
powershell -c "irm https://astral.sh/uv/install.ps1 | iex"
```

**Mac (Terminal):**
```
curl -LsSf https://astral.sh/uv/install.sh | sh
```

**Claude Desktop config** (`%APPDATA%\Claude\claude_desktop_config.json` on Windows, `~/Library/Application Support/Claude/claude_desktop_config.json` on Mac):
```json
{
  "mcpServers": {
    "nomos-ai": {
      "command": "uvx",
      "args": ["nomos-ai"]
    }
  }
}
```

## Package Structure

Standard `src` layout Python package. The existing `src/` directory is renamed to `src/nomosai/` to become a proper importable package name.

```
pyproject.toml              ← new, replaces requirements.txt
src/
  nomosai/
    __init__.py             ← unchanged
    engine.py               ← unchanged (imports updated)
    readers.py              ← unchanged (imports updated)
    formatter.py            ← unchanged (imports updated)
    recognizers_fr.py       ← unchanged (imports updated)
    server.py               ← renamed from mcp_server.py, adds main()
anonymize.py                ← kept for local CLI use (imports updated)
deanonymize.py              ← kept for local CLI use (imports updated)
requirements.txt            ← deleted (superseded by pyproject.toml)
```

## `pyproject.toml`

```toml
[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[tool.hatch.build.targets.wheel]
packages = ["src/nomosai"]

[project]
name = "nomos-ai"
version = "0.1.0"
description = "GDPR-compliant document anonymization MCP server for legal use"
requires-python = ">=3.10"
dependencies = [
    "presidio-analyzer>=2.2.351",
    "presidio-anonymizer>=2.2.351",
    "spacy>=3.7,<3.8",
    "fr_core_news_lg @ https://github.com/explosion/spacy-models/releases/download/fr_core_news_lg-3.7.0/fr_core_news_lg-3.7.0-py3-none-any.whl",  # URL must be verified at implementation time
    "python-docx>=1.1",
    "pdfplumber>=0.11",
    "pdfminer.six>=20221105",
    "pypdf>=4.0",
    "mcp[cli]>=1.0",
]

[project.scripts]
nomos-ai = "nomosai.server:main"
```

## Code Changes

### 1. Import updates (find-and-replace across 3 files)

In `anonymize.py`, `deanonymize.py`, and `src/nomosai/server.py`:
- `from src.engine import` → `from nomosai.engine import`
- `from src.readers import` → `from nomosai.readers import`
- `from src.formatter import` → `from nomosai.formatter import`
- `from src.recognizers_fr import` → `from nomosai.recognizers_fr import`

### 2. Entry point in `server.py`

Add at the bottom of the file (before `if __name__ == "__main__":`):

```python
def main():
    mcp.run()
```

Update the existing block:
```python
if __name__ == "__main__":
    main()
```

## Publish Workflow

One-time setup:
1. Create PyPI account at pypi.org
2. Generate an API token (Account Settings → API tokens)
3. Configure: `uv publish --token <token>` or store token in `~/.pypirc`

Per-release:
```bash
# bump version in pyproject.toml, then:
uv build
uv publish
```

## What Does NOT Change

- All anonymization logic (`engine.py`, `recognizers_fr.py`)
- All MCP tools (`anonymize_text`, `anonymize_file`, `deanonymize_file`, `list_entities`)
- The MCP transport (stdio — compatible with Claude Desktop and Claude Code)
- The warmup thread (loads French model in background at server start)
- Local CLI usage (`python anonymize.py`, `python deanonymize.py`) — still works from the repo

## Excluded

- VS Code extension — not suitable for the non-technical legal audience; the MCP server already works in VS Code via standard MCP config without an extension
- Cloud/hosted deployment — ruled out for GDPR and attorney-client privilege reasons
- Docker — viable alternative but heavier prerequisite for this audience
