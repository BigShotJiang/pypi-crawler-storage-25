# NomosAI PyPI Distribution Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Package NomosAI as a proper Python package published to PyPI, installable via `uvx nomos-ai` with no manual dependency steps for end users.

**Architecture:** Rename `src/` to `src/nomosai/` (standard src-layout), move `mcp_server.py` into the package as `server.py`, create `pyproject.toml` that lists spaCy + `fr_core_news_lg` as pip-installable URL dependencies, add a `nomos-ai` console script entry point.

**Tech Stack:** Python 3.10+, hatchling (build backend), uv (build + publish), spaCy 3.8, Presidio, MCP/FastMCP

---

## File Map

| Action | Path |
|--------|------|
| Create | `pyproject.toml` |
| Create | `.gitignore` |
| Rename dir | `src/` → `src/nomosai/` (move .py files) |
| Modify | `src/nomosai/engine.py` (update imports) |
| Modify | `src/nomosai/formatter.py` (update imports) |
| Move + Modify | `mcp_server.py` → `src/nomosai/server.py` (update imports + add `main()`) |
| Modify | `anonymize.py` (update imports) |
| Delete | `requirements.txt` |

`deanonymize.py` and `src/nomosai/readers.py` and `src/nomosai/recognizers_fr.py` require **no changes** — they have no `src.*` imports.

---

## Task 1: Initialize git repository

**Files:** Create `.gitignore`

- [ ] **Step 1: Initialize git**

```bash
git init
```

Expected output: `Initialized empty Git repository in ...`

- [ ] **Step 2: Create .gitignore**

Create `.gitignore` at the project root with this exact content:

```
__pycache__/
*.py[cod]
*.egg-info/
dist/
build/
.uv/
.venv/
*.whl
data/example/
```

- [ ] **Step 3: Stage and commit**

```bash
git add .gitignore
git commit -m "chore: initialize git repository"
```

---

## Task 2: Create pyproject.toml

**Files:** Create `pyproject.toml`

- [ ] **Step 1: Create pyproject.toml**

Create `pyproject.toml` at the project root with this exact content:

```toml
[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[tool.hatch.build.targets.wheel]
packages = ["src/nomosai"]

[project]
name = "nomos-ai"
version = "0.1.0"
description = "GDPR-compliant document anonymization MCP server for legal use"
readme = "README.md"
requires-python = ">=3.10"
dependencies = [
    "presidio-analyzer>=2.2.351",
    "presidio-anonymizer>=2.2.351",
    "spacy>=3.8,<3.9",
    "fr_core_news_lg @ https://github.com/explosion/spacy-models/releases/download/fr_core_news_lg-3.8.0/fr_core_news_lg-3.8.0-py3-none-any.whl",
    "python-docx>=1.1",
    "pdfplumber>=0.11",
    "pdfminer.six>=20221105",
    "pypdf>=4.0",
    "mcp[cli]>=1.0",
]

[project.scripts]
nomos-ai = "nomosai.server:main"
```

- [ ] **Step 2: Verify pyproject.toml parses correctly**

```bash
conda run -n nomosai python -c "import tomllib; tomllib.load(open('pyproject.toml','rb')); print('OK')"
```

Expected: `OK`

- [ ] **Step 3: Commit**

```bash
git add pyproject.toml
git commit -m "chore: add pyproject.toml for PyPI distribution"
```

---

## Task 3: Restructure src/ into src/nomosai/

**Files:** Move `src/*.py` → `src/nomosai/*.py`

- [ ] **Step 1: Create the nomosai subdirectory**

```bash
mkdir src/nomosai
```

- [ ] **Step 2: Move all Python source files**

```bash
mv src/__init__.py src/engine.py src/readers.py src/formatter.py src/recognizers_fr.py src/nomosai/
```

- [ ] **Step 3: Verify the new structure**

```bash
ls src/nomosai/
```

Expected output (order may vary):
```
__init__.py  engine.py  formatter.py  readers.py  recognizers_fr.py
```

- [ ] **Step 4: Commit**

```bash
git add src/
git commit -m "refactor: move src/ files into src/nomosai/ package"
```

---

## Task 4: Update imports in engine.py and formatter.py

**Files:** Modify `src/nomosai/engine.py`, `src/nomosai/formatter.py`

These two files import from other `src.*` modules — they break after the rename.

- [ ] **Step 1: Fix engine.py imports**

Open `src/nomosai/engine.py`. Find these two lines near the top (around line 16–17):

```python
from src.recognizers_fr import get_french_recognizers, FRENCH_ENTITY_LABELS
from src.readers import Block
```

Replace them with:

```python
from nomosai.recognizers_fr import get_french_recognizers, FRENCH_ENTITY_LABELS
from nomosai.readers import Block
```

- [ ] **Step 2: Fix formatter.py imports**

Open `src/nomosai/formatter.py`. Find these two lines near the top (around line 18–19):

```python
from src.readers import Block
from src.engine import ENTITY_LABELS
```

Replace them with:

```python
from nomosai.readers import Block
from nomosai.engine import ENTITY_LABELS
```

- [ ] **Step 3: Verify imports resolve**

Install the package in editable mode so `nomosai` is on the path:

```bash
conda run -n nomosai pip install -e . --no-deps --quiet
```

Then verify:

```bash
conda run -n nomosai python -c "from nomosai.engine import DocumentAnonymizer, build_analyzer; print('engine OK')"
conda run -n nomosai python -c "from nomosai.formatter import to_markdown; print('formatter OK')"
```

Expected:
```
engine OK
formatter OK
```

- [ ] **Step 4: Commit**

```bash
git add src/nomosai/engine.py src/nomosai/formatter.py
git commit -m "refactor: update internal src.* imports to nomosai.*"
```

---

## Task 5: Move mcp_server.py → src/nomosai/server.py

**Files:** Move `mcp_server.py` → `src/nomosai/server.py`, update imports, add `main()`

- [ ] **Step 1: Move the file**

```bash
mv mcp_server.py src/nomosai/server.py
```

- [ ] **Step 2: Update imports in server.py**

Open `src/nomosai/server.py`. Find these three import lines near the top:

```python
from src.engine import (
    build_analyzer,
    DocumentAnonymizer,
    DEFAULT_ENTITIES,
    ENTITY_LABELS,
)
from src.readers import read_document, SUPPORTED_EXTENSIONS
from src.formatter import to_markdown
```

Replace them with:

```python
from nomosai.engine import (
    build_analyzer,
    DocumentAnonymizer,
    DEFAULT_ENTITIES,
    ENTITY_LABELS,
)
from nomosai.readers import read_document, SUPPORTED_EXTENSIONS
from nomosai.formatter import to_markdown
```

- [ ] **Step 3: Add main() function**

At the very bottom of `src/nomosai/server.py`, find:

```python
if __name__ == "__main__":
    mcp.run()
```

Replace it with:

```python
def main():
    mcp.run()


if __name__ == "__main__":
    main()
```

- [ ] **Step 4: Verify server.py imports**

```bash
conda run -n nomosai python -c "from nomosai.server import mcp, main; print('server OK')"
```

Expected: `server OK`

(The warmup thread starts in background — that's fine, the import still resolves.)

- [ ] **Step 5: Commit**

```bash
git add src/nomosai/server.py
git commit -m "refactor: move mcp_server.py to nomosai/server.py, add main() entry point"
```

---

## Task 6: Update imports in anonymize.py

**Files:** Modify `anonymize.py`

- [ ] **Step 1: Fix the top-level imports**

Open `anonymize.py`. Find these three lines near the top (around lines 25–27):

```python
from src.readers import read_document, SUPPORTED_EXTENSIONS
from src.engine import build_analyzer, DocumentAnonymizer, DEFAULT_ENTITIES
from src.formatter import to_markdown
```

Replace them with:

```python
from nomosai.readers import read_document, SUPPORTED_EXTENSIONS
from nomosai.engine import build_analyzer, DocumentAnonymizer, DEFAULT_ENTITIES
from nomosai.formatter import to_markdown
```

- [ ] **Step 2: Fix the import inside _write_report()**

Still in `anonymize.py`, inside the `_write_report()` function (around line 194), find:

```python
    from src.engine import ENTITY_LABELS
```

Replace with:

```python
    from nomosai.engine import ENTITY_LABELS
```

- [ ] **Step 3: Verify anonymize.py imports**

```bash
conda run -n nomosai python -c "import anonymize; print('anonymize OK')"
```

Expected: `anonymize OK`

- [ ] **Step 4: Commit**

```bash
git add anonymize.py
git commit -m "refactor: update anonymize.py imports from src.* to nomosai.*"
```

---

## Task 7: Smoke test — MCP server starts

- [ ] **Step 1: Reinstall package to pick up server.py entry point**

```bash
conda run -n nomosai pip install -e . --quiet
```

- [ ] **Step 2: Verify the console script exists**

```bash
conda run -n nomosai nomos-ai --help
```

Expected: the command should fail immediately with `no such option: --help` or similar MCP startup output (MCP servers communicate over stdio, not args). The important thing is it does NOT fail with `command not found` or `ModuleNotFoundError`.

Alternatively:

```bash
conda run -n nomosai python -c "from nomosai.server import main; print('entry point OK')"
```

Expected: `entry point OK`

- [ ] **Step 3: Run a quick anonymization smoke test**

```bash
conda run -n nomosai python -c "
from nomosai.engine import build_analyzer, DocumentAnonymizer
analyzer = build_analyzer('fr')
anon = DocumentAnonymizer(analyzer, language='fr')
result = anon.anonymize_text('Bonjour, je suis Jean Dupont et mon email est jean@example.com.', ['PERSON', 'EMAIL_ADDRESS'])
print(result)
print('smoke test OK')
"
```

Expected: output contains `[PERSONNE_1]` and `[EMAIL_` placeholders, ending with `smoke test OK`.

---

## Task 8: Remove requirements.txt and build the wheel

**Files:** Delete `requirements.txt`, build `dist/`

- [ ] **Step 1: Delete requirements.txt**

```bash
rm requirements.txt
```

- [ ] **Step 2: Install uv if not already available**

Check first:

```bash
uv --version
```

If not found, install (Windows PowerShell):
```
powershell -c "irm https://astral.sh/uv/install.ps1 | iex"
```

Or Mac/Linux:
```bash
curl -LsSf https://astral.sh/uv/install.sh | sh
```

- [ ] **Step 3: Build the wheel**

```bash
uv build
```

Expected output ends with something like:
```
Successfully built dist/nomos_ai-0.1.0-py3-none-any.whl
```

- [ ] **Step 4: Verify wheel contents**

```bash
uv run python -c "
import zipfile, sys
whl = list(__import__('pathlib').Path('dist').glob('*.whl'))[0]
names = zipfile.ZipFile(whl).namelist()
expected = ['nomosai/server.py', 'nomosai/engine.py', 'nomosai/readers.py']
for f in expected:
    assert any(f in n for n in names), f'MISSING: {f}'
print('wheel contents OK')
"
```

Expected: `wheel contents OK`

- [ ] **Step 5: Final commit**

```bash
git add -A
git commit -m "feat: package as nomos-ai PyPI distribution with uvx support"
```

---

## Task 9: Publish to PyPI (one-time)

This task requires a PyPI account and API token. Run once when ready to publish.

- [ ] **Step 1: Create PyPI account**

Go to https://pypi.org/account/register/ and create an account.

- [ ] **Step 2: Generate an API token**

In PyPI account settings → API tokens → Add API token. Scope: "Entire account" for the first upload, then narrow to the project.

- [ ] **Step 3: Publish**

```bash
uv publish --token pypi-<YOUR_TOKEN_HERE>
```

Expected: `Uploading nomos_ai-0.1.0-py3-none-any.whl` followed by success.

- [ ] **Step 4: Verify installation works end-to-end**

On a machine that has `uv` installed but NOT the conda env:

```bash
uvx nomos-ai
```

Expected: MCP server starts (waits on stdio, no error output). Press Ctrl+C to stop.

---

## User-Facing Install Instructions (for documentation)

Once published, end users need only:

**Step 1 — Install uv (once per machine):**

- Windows: open PowerShell and paste:
  ```
  powershell -c "irm https://astral.sh/uv/install.ps1 | iex"
  ```
- Mac: open Terminal and paste:
  ```
  curl -LsSf https://astral.sh/uv/install.sh | sh
  ```

**Step 2 — Add to Claude Desktop config** (`%APPDATA%\Claude\claude_desktop_config.json` on Windows, `~/Library/Application Support/Claude/claude_desktop_config.json` on Mac):

```json
{
  "mcpServers": {
    "nomos-ai": {
      "command": "uvx",
      "args": ["nomos-ai"]
    }
  }
}
```

Restart Claude Desktop. On first use, `uvx` downloads ~600MB (package + model) — takes 1–3 minutes. Subsequent starts are instant.

---

## Future Releases

```bash
# 1. Bump version in pyproject.toml
# 2. Build and publish:
uv build
uv publish --token pypi-<TOKEN>
```
