"""
Moteur d'anonymisation Presidio.

Fonctionnalités clés :
  - Support natif du français (fr_core_news_lg) + reconnaisseurs personnalisés
  - Placeholders numérotés et stables : [PERSON_1], [PERSON_2]…
    La même entité source reçoit toujours le même placeholder dans un document.
  - Collecte des statistiques de détection pour le rapport RGPD.
"""

import re
import sys
from typing import Optional
from collections import defaultdict

from nomosai.recognizers_fr import get_french_recognizers, FRENCH_ENTITY_LABELS
from nomosai.readers import Block


# ---------------------------------------------------------------------------
# Labels globaux (entités Presidio standard → label lisible)
# ---------------------------------------------------------------------------

ENTITY_LABELS: dict[str, str] = {
    "PERSON":             "PERSONNE",
    "EMAIL_ADDRESS":      "EMAIL",
    "PHONE_NUMBER":       "TELEPHONE",
    "LOCATION":           "ADRESSE",
    "IP_ADDRESS":         "IP",
    "URL":                "URL",
    "CREDIT_CARD":        "CARTE_BANCAIRE",
    "IBAN_CODE":          "IBAN",
    "US_SSN":             "SSN",
    "DATE_TIME":          "DATE",
    "NRP":                "ID_NATIONAL",
    "MEDICAL_LICENSE":    "LICENCE_MEDICALE",
    "CRYPTO":             "CRYPTO",
    "ORGANIZATION":       "ORGANISATION",
    **FRENCH_ENTITY_LABELS,
}

# Entités RGPD activées par défaut.
# DATE_TIME : rarement PII seul et génère du bruit dans les rapports.
# FILE_PATH  : masqué seulement si l'utilisateur l'active explicitement
#              (sauf si le chemin contient un nom de personne — hors portée regex).
_ENTITIES_OPT_IN = {"DATE_TIME", "FILE_PATH"}

DEFAULT_ENTITIES = [e for e in ENTITY_LABELS if e not in _ENTITIES_OPT_IN]

# Score minimum par type d'entité (au-dessus du seuil global --score-threshold).
# spaCy fr_core_news_lg sur-détecte LOCATION dans les tableaux PDF et les données
# structurées → on relève son seuil minimum.
_ENTITY_MIN_SCORES: dict[str, float] = {
    "LOCATION":       0.80,   # trop de faux positifs dans texte structuré
    "FR_SIREN":       0.70,   # 9 chiffres ambigus sans contexte
    "FR_CNI":         0.70,   # 12 chiffres ambigus
    "FR_POSTAL_CODE": 0.70,   # 5 chiffres très ambigus
}

# ---------------------------------------------------------------------------
# Filtres de faux positifs évidents (indépendants du type d'entité)
# Ces patterns ne devraient jamais être traités comme des PII.
# ---------------------------------------------------------------------------
_FP_PATTERNS: list[re.Pattern] = [
    re.compile(r"^[A-Za-zÀ-ÿ]$"),                     # lettre seule  (F, P, E…)
    re.compile(r"^[A-Za-zÀ-ÿ]{1,3}$"),                # sigle ≤ 3 car. (NR, NC, ET…)
    re.compile(r"^\d[\d\s,.\-]*$"),                    # valeur numérique pure
    re.compile(r"^[Nn]\s*[=:]\s*[\d\s]+$"),            # effectif  N=1 035
    re.compile(r"^n\s*=\s*[\d\s]+$"),                  # effectif  n=5 991
    re.compile(r"^\.{2,}$"),                           # séparateur ……
    re.compile(r"^[IVXivx]+\.\d"),                     # numéro de section  II.4
    re.compile(r"^[A-Z]{1,2}\.\d"),                    # numéro de section  I.1
    re.compile(r"^[b-c]-\s*$"),                        # étiquette de liste  b-  c-
    re.compile(r"^[~\-–—]+$"),                         # tiret/tilde seul
]


# Patterns supplémentaires applicables uniquement à PERSON
_FP_PERSON_PATTERNS: list[re.Pattern] = [
    # Fragments en majuscules issus de tables (≥ 2 mots tout en caps)
    # ex. « REPARTITION DE LA », « RENAUX PORTEURS D »
    re.compile(r"^(?:[A-ZÀÂÉÈÊËÎÏÔÙÛÜ]{2,}\s+){1,}[A-ZÀÂÉÈÊËÎÏÔÙÛÜ]*$"),
    # Artefacts OCR : lettres isolées séparées par des espaces  « nais s ance »
    re.compile(r"(?<!\w)[a-z]\s[a-z](?!\w)"),
    # Fragments de phrase commençant en minuscule
    re.compile(r"^[a-zàâéèêëîïôùûü]"),
    # Numéro de section ou identifiant alphanumérique seul  « II.3 » « III.5 »
    re.compile(r"^[IVXivx]+\.\d"),
]


def _is_false_positive(text: str, entity_type: str = "") -> bool:
    """Retourne True si le texte est un faux positif évident pour le type donné."""
    stripped = text.strip()
    if not stripped:
        return True
    if len(stripped) <= 1:
        return True
    if any(p.fullmatch(stripped) for p in _FP_PATTERNS):
        return True
    if entity_type == "PERSON":
        for p in _FP_PERSON_PATTERNS:
            if p.search(stripped):
                return True
    return False


def _deduplicate_spans(results: list, text: str) -> list:
    """
    Élimine les spans qui se chevauchent APRÈS filtrage.

    Pourquoi c'est indispensable :
    La boucle de remplacement travaille de droite à gauche sur la MÊME chaîne
    `anonymized` en utilisant les indices de l'original.  Si deux spans
    (A=[0,17] et B=[3,17]) passent tous les deux le filtre, remplacer B en
    premier allonge/raccourcit `anonymized`, et le `end` de A pointe ensuite
    au mauvais endroit → corruption du type "[PERSONNE_15]ONNE_14]".

    Stratégie : pour chaque groupe de spans qui se chevauchent, garder celui
    qui a le meilleur score, puis la plus grande longueur à égalité.
    """
    if not results:
        return results

    # Priorité : score desc, puis longueur (span plus englobant) desc
    ranked = sorted(results, key=lambda r: (r.score, r.end - r.start), reverse=True)
    accepted: list = []
    for r in ranked:
        overlaps = any(r.start < a.end and r.end > a.start for a in accepted)
        if not overlaps:
            accepted.append(r)
    return accepted


# ---------------------------------------------------------------------------
# Construction de l'analyseur
# ---------------------------------------------------------------------------

def build_analyzer(language: str = "fr"):
    """Crée un AnalyzerEngine Presidio avec le modèle spaCy approprié."""
    try:
        from presidio_analyzer import AnalyzerEngine
        from presidio_analyzer.nlp_engine import NlpEngineProvider
    except ImportError:
        sys.exit("Dépendance manquante : pip install presidio-analyzer")

    spacy_models = {
        "fr": "fr_core_news_lg",
        "en": "en_core_web_lg",
        "de": "de_core_news_lg",
        "es": "es_core_news_lg",
        "it": "it_core_news_lg",
        "nl": "nl_core_news_lg",
        "pt": "pt_core_news_lg",
    }
    model_name = spacy_models.get(language, f"{language}_core_news_lg")

    provider = NlpEngineProvider(nlp_configuration={
        "nlp_engine_name": "spacy",
        "models": [{"lang_code": language, "model_name": model_name}],
    })
    nlp_engine = provider.create_engine()

    analyzer = AnalyzerEngine(
        nlp_engine=nlp_engine,
        supported_languages=[language],
    )

    # Ajout des reconnaisseurs français
    if language == "fr":
        registry = analyzer.registry
        for recognizer in get_french_recognizers():
            registry.add_recognizer(recognizer)

    return analyzer


# ---------------------------------------------------------------------------
# Anonymisation avec placeholders numérotés
# ---------------------------------------------------------------------------

class DocumentAnonymizer:
    """
    Anonymise un document en préservant la cohérence des références :
    la même entité source reçoit toujours le même placeholder numéroté.

    Exemple : "Jean Dupont" → "[PERSONNE_1]" partout dans le document.
    """

    def __init__(self, analyzer, language: str = "fr", score_threshold: float = 0.55):
        self.analyzer = analyzer
        self.language = language
        self.score_threshold = score_threshold

        # Mapping : (entity_type, original_lower) → placeholder "[TYPE_N]"
        self._registry: dict[tuple[str, str], str] = {}
        # Valeur originale (casse préservée) par placeholder
        self._originals: dict[str, str] = {}
        # Compteurs par type
        self._counters: dict[str, int] = defaultdict(int)
        # Statistiques : entity_type → count occurrences
        self.stats: dict[str, int] = defaultdict(int)

    def reset(self):
        """Réinitialise pour un nouveau document."""
        self._registry.clear()
        self._originals.clear()
        self._counters.clear()
        self.stats.clear()

    def _get_placeholder(self, entity_type: str, original: str) -> str:
        label = ENTITY_LABELS.get(entity_type, entity_type)
        key = (entity_type, original.lower().strip())
        if key not in self._registry:
            self._counters[entity_type] += 1
            placeholder = f"[{label}_{self._counters[entity_type]}]"
            self._registry[key] = placeholder
            self._originals[placeholder] = original.strip()
        return self._registry[key]

    def get_index(self) -> list[dict]:
        """
        Retourne la liste des correspondances placeholder ↔ valeur originale,
        triées par type d'entité puis par numéro.

        Chaque élément : {"placeholder": str, "original": str, "entity_type": str, "label": str}
        """
        entries = []
        for (entity_type, _), placeholder in self._registry.items():
            entries.append({
                "placeholder": placeholder,
                "original": self._originals.get(placeholder, ""),
                "entity_type": entity_type,
                "label": ENTITY_LABELS.get(entity_type, entity_type),
            })
        entries.sort(key=lambda e: (e["label"], e["placeholder"]))
        return entries

    def anonymize_text(
        self,
        text: str,
        entities: Optional[list[str]] = None,
    ) -> str:
        if not text.strip():
            return text

        target_entities = entities or DEFAULT_ENTITIES

        results = self.analyzer.analyze(
            text=text,
            language=self.language,
            entities=target_entities,
            score_threshold=self.score_threshold,
        )

        if not results:
            return text

        # ── Phase 1 : filtres (score par entité + faux positifs) ──────────────
        candidates = []
        for r in results:
            min_score = _ENTITY_MIN_SCORES.get(r.entity_type)
            if min_score is not None and r.score < min_score:
                continue
            if _is_false_positive(text[r.start:r.end], r.entity_type):
                continue
            candidates.append(r)

        if not candidates:
            return text

        # ── Phase 2 : déduplication des spans chevauchants ───────────────────
        # Indispensable : deux recognizers peuvent retourner des spans qui se
        # recouvrent partiellement.  Remplacer de droite à gauche avec des
        # indices issus du texte original devient incorrect dès qu'un span
        # précédent a modifié la longueur de la chaîne → corruption du type
        # "[PERSONNE_15]ONNE_14]".
        candidates = _deduplicate_spans(candidates, text)

        # ── Phase 3 : remplacement de droite à gauche ────────────────────────
        # Les indices sont stables car on traite les positions décroissantes
        # et les spans sont garantis non-chevauchants après la phase 2.
        candidates_sorted = sorted(candidates, key=lambda r: r.start, reverse=True)

        anonymized = text
        for r in candidates_sorted:
            original = text[r.start:r.end]
            placeholder = self._get_placeholder(r.entity_type, original)
            anonymized = anonymized[:r.start] + placeholder + anonymized[r.end:]
            self.stats[r.entity_type] += 1

        return anonymized

    def anonymize_blocks(
        self,
        blocks: list[Block],
        entities: Optional[list[str]] = None,
    ) -> list[Block]:
        """Anonymise une liste de blocs en place (retourne de nouveaux blocs)."""
        from nomosai.readers import Block as _Block
        result = []
        for block in blocks:
            anonymized_text = self.anonymize_text(block.text, entities)
            # Pour les tableaux, anonymiser aussi les cellules
            new_cells = None
            if block.cells:
                new_cells = [
                    [self.anonymize_text(cell, entities) for cell in row]
                    for row in block.cells
                ]
                # Reconstruire le texte depuis les cellules anonymisées
                anonymized_text = "\n".join(" | ".join(row) for row in new_cells)
            result.append(_Block(type=block.type, text=anonymized_text, cells=new_cells))
        return result
