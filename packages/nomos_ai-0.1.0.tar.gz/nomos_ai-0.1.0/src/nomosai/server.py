#!/usr/bin/env python3
"""
NomosAI MCP Server
==================
Expose les capacités d'anonymisation de NomosAI comme outils MCP pour agents LLM.

Transport : stdio (par défaut, compatible Claude Desktop / Claude Code)

Outils disponibles :
    anonymize_text   — anonymise du texte brut, retourne le texte anonymisé + l'index des remplacements
    anonymize_file   — traite un fichier (.docx, .pdf, .txt, .md, .rst), écrit le .md anonymisé
    list_entities    — liste les types de PII disponibles avec leurs descriptions

Usage :
    uvx nomos-ai

Configuration Claude Desktop (%APPDATA%\\Claude\\claude_desktop_config.json) :
    {
      "mcpServers": {
        "nomos-ai": {
          "command": "uvx",
          "args": ["nomos-ai"]
        }
      }
    }
"""

import datetime
import re
import threading
from pathlib import Path
from typing import Optional

from mcp.server.fastmcp import FastMCP

from nomosai.engine import (
    build_analyzer,
    DocumentAnonymizer,
    DEFAULT_ENTITIES,
    ENTITY_LABELS,
)
from nomosai.readers import read_document, SUPPORTED_EXTENSIONS
from nomosai.formatter import to_markdown


# ---------------------------------------------------------------------------
# Serveur MCP
# ---------------------------------------------------------------------------

mcp = FastMCP(
    name="nomos-ai",
    instructions=(
        "Serveur d'anonymisation NomosAI (RGPD). "
        "Utilisez anonymize_text pour anonymiser du texte en mémoire — retourne le texte "
        "anonymisé et l'index complet placeholder→valeur originale. "
        "Utilisez anonymize_file pour traiter un fichier (.docx, .pdf, .txt, .md, .rst) et "
        "écrire le Markdown anonymisé sur disque. "
        "Utilisez list_entities pour découvrir les types de PII détectables."
    ),
)


# ---------------------------------------------------------------------------
# Cache des analyseurs (build_analyzer est coûteux : ~5-10s par langue)
# ---------------------------------------------------------------------------

_analyzer_cache: dict[str, object] = {}
_cache_lock = threading.Lock()

SUPPORTED_LANGUAGES = {"fr", "en", "de", "es", "it", "nl", "pt"}

_SPACY_MODELS = {
    "fr": "fr_core_news_lg",
    "en": "en_core_web_lg",
    "de": "de_core_news_lg",
    "es": "es_core_news_lg",
    "it": "it_core_news_lg",
    "nl": "nl_core_news_lg",
    "pt": "pt_core_news_lg",
}

_OPT_IN_ENTITIES = {"DATE_TIME", "FILE_PATH"}

_FRENCH_ONLY = {
    "FR_NIR", "FR_SIRET", "FR_SIREN", "FR_TVA",
    "FR_PASSPORT", "FR_CNI", "FR_DRIVING_LICENSE", "FR_POSTAL_CODE",
    "FILE_PATH",
}

_ENTITY_DESCRIPTIONS = {
    "PERSON":             "Noms de personnes physiques",
    "ORGANIZATION":       "Noms d'organisations ou entreprises",
    "LOCATION":           "Lieux géographiques, adresses",
    "EMAIL_ADDRESS":      "Adresses e-mail",
    "PHONE_NUMBER":       "Numéros de téléphone",
    "IBAN_CODE":          "Codes IBAN bancaires",
    "CREDIT_CARD":        "Numéros de carte de crédit",
    "MEDICAL_LICENSE":    "Licences médicales",
    "URL":                "URLs et liens web",
    "IP_ADDRESS":         "Adresses IP",
    "FR_NIR":             "Numéro INSEE / Sécurité Sociale (15 chiffres)",
    "FR_SIRET":           "SIRET — identifiant établissement (14 chiffres)",
    "FR_SIREN":           "SIREN — identifiant entreprise (9 chiffres)",
    "FR_TVA":             "Numéro TVA intracommunautaire",
    "FR_PASSPORT":        "Numéro de passeport français",
    "FR_CNI":             "Carte Nationale d'Identité (12 chiffres)",
    "FR_DRIVING_LICENSE": "Permis de conduire format post-2013 (AA-NNN-AA)",
    "FR_POSTAL_CODE":     "Code postal français (avec contexte)",
    "DATE_TIME":          "Dates et heures — opt-in, génèrent du bruit par défaut",
    "FILE_PATH":          "Chemins de fichiers Windows/Unix — opt-in",
}


def _get_analyzer(language: str):
    """Retourne l'analyseur Presidio pour la langue, en le construisant une seule fois."""
    if language not in _analyzer_cache:
        with _cache_lock:
            if language not in _analyzer_cache:
                _analyzer_cache[language] = build_analyzer(language)
    return _analyzer_cache[language]


def _validate_entities(entities: Optional[list[str]]) -> tuple[list[str], list[str]]:
    """Retourne (entités_valides, entités_inconnues)."""
    if entities is None:
        return DEFAULT_ENTITIES, []
    all_known = set(ENTITY_LABELS.keys())
    valid = [e for e in entities if e in all_known]
    unknown = [e for e in entities if e not in all_known]
    return (valid if valid else DEFAULT_ENTITIES), unknown


def _write_index(output_path: Path, anonymizer: DocumentAnonymizer, source_path: Path) -> None:
    """Écrit <output_stem>-index.md avec la correspondance placeholder → valeur originale."""
    index_path = output_path.with_name(output_path.stem + "-index.md")
    entries = anonymizer.get_index()
    date_str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    lines = [
        "---",
        f"source: {source_path.name}",
        f"generated: {date_str}",
        f"total_entities: {len(entries)}",
        "---",
        "",
        "# Index d'anonymisation",
        "",
        f"**Source :** `{source_path.name}`  ",
        f"**Généré le :** {date_str}  ",
        f"**Entités uniques :** {len(entries)}  ",
        "",
        "> Ce fichier est **confidentiel** — il contient les données personnelles originales.",
        "> Ne pas inclure dans les exports anonymisés.",
        "",
        "| Placeholder | Valeur originale | Type |",
        "| --- | --- | --- |",
    ]
    for entry in entries:
        original = (
            entry["original"]
            .replace("|", "\\|")
            .replace("\r\n", "\\n")
            .replace("\n", "\\n")
            .replace("\r", "\\n")
        )
        lines.append(f"| `{entry['placeholder']}` | {original} | `{entry['label']}` |")

    lines += ["", "---", ""]
    index_path.write_text("\n".join(lines), encoding="utf-8")


# ---------------------------------------------------------------------------
# Outils MCP
# ---------------------------------------------------------------------------

@mcp.tool()
def anonymize_text(
    text: str,
    language: str = "fr",
    entities: Optional[list[str]] = None,
    score_threshold: float = 0.55,
) -> dict:
    """
    Anonymise du texte brut avec NomosAI / Presidio.

    Remplace les données personnelles détectées par des placeholders numérotés
    ([PERSONNE_1], [EMAIL_2]…) et retourne l'index complet des remplacements.

    Args:
        text: Texte à anonymiser (longueur quelconque).
        language: Code langue — 'fr' (défaut), 'en', 'de', 'es', 'it', 'nl', 'pt'.
        entities: Types d'entités à détecter. None = tous les types par défaut.
                  Appelez list_entities() pour voir les types disponibles.
        score_threshold: Seuil de confiance 0.0–1.0 (défaut 0.55).

    Returns:
        dict avec : success, anonymized_text, stats, total_entities, index
    """
    if language not in SUPPORTED_LANGUAGES:
        return {
            "success": False,
            "error_type": "UnsupportedLanguage",
            "error": f"Langue '{language}' non supportée. Supportées : {sorted(SUPPORTED_LANGUAGES)}",
        }

    valid_entities, unknown = _validate_entities(entities)

    try:
        analyzer = _get_analyzer(language)
    except OSError as e:
        model = _SPACY_MODELS.get(language, f"{language}_core_news_lg")
        return {
            "success": False,
            "error_type": "SpacyModelMissing",
            "error": (
                f"Le modèle spaCy pour '{language}' n'est pas installé. "
                f"Exécutez : python -m spacy download {model}"
            ),
            "detail": str(e),
        }
    except ImportError as e:
        return {
            "success": False,
            "error_type": "DependencyMissing",
            "error": "presidio-analyzer n'est pas installé. Exécutez : pip install presidio-analyzer",
            "detail": str(e),
        }

    anonymizer = DocumentAnonymizer(
        analyzer,
        language=language,
        score_threshold=score_threshold,
    )

    try:
        anonymized = anonymizer.anonymize_text(text, valid_entities)
    except Exception as e:
        return {"success": False, "error_type": "AnonymizationError", "error": str(e)}

    result = {
        "success": True,
        "anonymized_text": anonymized,
        "stats": dict(anonymizer.stats),
        "total_entities": sum(anonymizer.stats.values()),
        "index": anonymizer.get_index(),
        "language": language,
        "score_threshold": score_threshold,
    }
    if unknown:
        result["warnings"] = [f"Types d'entités inconnus ignorés : {unknown}"]
    return result


@mcp.tool()
def anonymize_file(
    file_path: str,
    output_path: Optional[str] = None,
    language: str = "fr",
    entities: Optional[list[str]] = None,
    score_threshold: float = 0.55,
    write_index: bool = True,
) -> dict:
    """
    Anonymise un fichier document (.docx, .pdf, .txt, .md, .rst).

    Lit le document, détecte et remplace les PII, puis écrit un fichier Markdown
    anonymisé avec frontmatter YAML et pied-de-page RGPD. Génère optionnellement
    un fichier d'index confidentiel (placeholder → valeur originale).

    Args:
        file_path: Chemin absolu ou relatif vers le document source.
        output_path: Chemin du fichier .md de sortie. Par défaut : <nom>_anonymise.md.
        language: Code langue — 'fr' (défaut), 'en', 'de', 'es', 'it', 'nl', 'pt'.
        entities: Types d'entités à détecter. None = tous les types par défaut.
        score_threshold: Seuil de confiance 0.0–1.0 (défaut 0.55).
        write_index: Écrire le fichier d'index confidentiel (défaut True).

    Returns:
        dict avec : success, input_path, output_path, index_path, stats, total_entities
    """
    input_p = Path(file_path).resolve()

    if not input_p.exists():
        return {
            "success": False,
            "error_type": "FileNotFound",
            "error": f"Fichier introuvable : {input_p}",
        }

    suffix = input_p.suffix.lower()
    if suffix not in SUPPORTED_EXTENSIONS:
        return {
            "success": False,
            "error_type": "UnsupportedFormat",
            "error": (
                f"Format '{suffix}' non supporté. "
                f"Supportés : {', '.join(sorted(SUPPORTED_EXTENSIONS))}"
            ),
        }

    if language not in SUPPORTED_LANGUAGES:
        return {
            "success": False,
            "error_type": "UnsupportedLanguage",
            "error": f"Langue '{language}' non supportée. Supportées : {sorted(SUPPORTED_LANGUAGES)}",
        }

    out_p = (
        Path(output_path).resolve()
        if output_path
        else input_p.with_name(input_p.stem + "_anonymise.md")
    )

    valid_entities, unknown = _validate_entities(entities)

    try:
        analyzer = _get_analyzer(language)
    except OSError as e:
        model = _SPACY_MODELS.get(language, f"{language}_core_news_lg")
        return {
            "success": False,
            "error_type": "SpacyModelMissing",
            "error": f"Exécutez : python -m spacy download {model}",
            "detail": str(e),
        }

    try:
        blocks = read_document(input_p)
    except Exception as e:
        return {"success": False, "error_type": "ReadError", "error": str(e)}

    if not blocks:
        return {
            "success": False,
            "error_type": "EmptyDocument",
            "error": f"Aucun texte extrait de {input_p.name}",
        }

    anonymizer = DocumentAnonymizer(
        analyzer,
        language=language,
        score_threshold=score_threshold,
    )

    try:
        anon_blocks = anonymizer.anonymize_blocks(blocks, valid_entities)
        md = to_markdown(
            anon_blocks,
            source_path=input_p,
            language=language,
            stats=dict(anonymizer.stats),
            score_threshold=score_threshold,
        )
        out_p.parent.mkdir(parents=True, exist_ok=True)
        out_p.write_text(md, encoding="utf-8")
    except Exception as e:
        return {"success": False, "error_type": "AnonymizationError", "error": str(e)}

    index_path_str = None
    if write_index:
        try:
            _write_index(out_p, anonymizer, input_p)
            index_path_str = str(out_p.with_name(out_p.stem + "-index.md"))
        except Exception:
            pass  # non bloquant : l'anonymisation a réussi

    result = {
        "success": True,
        "input_path": str(input_p),
        "output_path": str(out_p),
        "index_path": index_path_str,
        "format_detected": suffix,
        "stats": dict(anonymizer.stats),
        "total_entities": sum(anonymizer.stats.values()),
        "language": language,
        "score_threshold": score_threshold,
    }
    if unknown:
        result["warnings"] = [f"Types d'entités inconnus ignorés : {unknown}"]
    return result


@mcp.tool()
def deanonymize_file(
    anonymized_file_path: str,
    index_path: Optional[str] = None,
    output_path: Optional[str] = None,
) -> dict:
    """
    Restaure un document anonymisé NomosAI en remplaçant les placeholders
    ([PERSONNE_1], [EMAIL_2]…) par les valeurs originales stockées dans l'index.

    L'index est le fichier confidentiel <nom>-index.md généré lors de l'anonymisation.
    Si index_path est absent, il est cherché automatiquement à côté du fichier anonymisé
    sous le nom <stem>-index.md.

    Args:
        anonymized_file_path: Chemin vers le fichier .md anonymisé.
        index_path: Chemin vers le fichier index (-index.md). Auto-détecté si absent.
        output_path: Chemin de sortie. Par défaut : <stem>_restaure.md.

    Returns:
        dict avec : success, input_path, index_path, output_path, replacements_count
    """
    _ROW_RE = re.compile(
        r"^\|\s*`(\[[^\]]+\])`\s*\|\s*(.*?)\s*\|\s*`[^`]+`\s*\|$"
    )

    doc_p = Path(anonymized_file_path).resolve()

    if not doc_p.exists():
        return {
            "success": False,
            "error_type": "FileNotFound",
            "error": f"Fichier introuvable : {doc_p}",
        }

    if doc_p.suffix.lower() != ".md":
        return {
            "success": False,
            "error_type": "InvalidFormat",
            "error": f"Le fichier doit être un .md anonymisé (reçu : {doc_p.suffix!r})",
        }

    # Résolution de l'index
    if index_path:
        idx_p = Path(index_path).resolve()
        if not idx_p.exists():
            return {
                "success": False,
                "error_type": "FileNotFound",
                "error": f"Index introuvable : {idx_p}",
            }
    else:
        idx_p = doc_p.with_name(doc_p.stem + "-index.md")
        if not idx_p.exists():
            return {
                "success": False,
                "error_type": "IndexNotFound",
                "error": (
                    f"Index non trouvé : {idx_p}\n"
                    "Utilisez index_path pour en spécifier un explicitement."
                ),
            }

    # Parsing de l'index
    try:
        content = idx_p.read_text(encoding="utf-8")
        mapping: dict[str, str] = {}
        for line in content.splitlines():
            m = _ROW_RE.match(line.strip())
            if not m:
                continue
            placeholder = m.group(1)
            original = m.group(2).strip().replace(r"\|", "|").replace(r"\n", "\n")
            mapping[placeholder] = original
    except Exception as e:
        return {"success": False, "error_type": "IndexParseError", "error": str(e)}

    if not mapping:
        return {
            "success": False,
            "error_type": "EmptyIndex",
            "error": f"Aucun placeholder trouvé dans l'index : {idx_p}",
        }

    # Restauration du texte
    try:
        text = doc_p.read_text(encoding="utf-8")
        replacements = sum(text.count(ph) for ph in mapping)
        # Remplacer les plus longs en premier (évite [PERSONNE_1] avant [PERSONNE_10])
        for placeholder in sorted(mapping, key=len, reverse=True):
            text = text.replace(placeholder, mapping[placeholder])

        stem = doc_p.stem.removesuffix("_anonymise")
        out_p = Path(output_path).resolve() if output_path else doc_p.with_name(stem + "_restaure.md")
        out_p.parent.mkdir(parents=True, exist_ok=True)
        out_p.write_text(text, encoding="utf-8")
    except Exception as e:
        return {"success": False, "error_type": "RestoreError", "error": str(e)}

    return {
        "success": True,
        "input_path": str(doc_p),
        "index_path": str(idx_p),
        "output_path": str(out_p),
        "entries_in_index": len(mapping),
        "replacements_count": replacements,
    }


@mcp.tool()
def list_entities(language: str = "fr") -> dict:
    """
    Liste tous les types de PII que NomosAI peut détecter.

    Ne nécessite pas de chargement d'analyseur — répond instantanément.
    Les entités FR_* sont uniquement disponibles avec language='fr'.
    Les entités opt-in (DATE_TIME, FILE_PATH) doivent être explicitement
    listées dans le paramètre 'entities' de anonymize_text / anonymize_file.

    Args:
        language: Code langue pour filtrer les entités pertinentes.

    Returns:
        dict avec : default_entities, opt_in_entities, total_default, total_opt_in
    """
    default_list = []
    opt_in_list = []

    for entity_type, label in ENTITY_LABELS.items():
        is_opt_in = entity_type in _OPT_IN_ENTITIES
        is_french_only = entity_type in _FRENCH_ONLY

        if is_french_only and language != "fr":
            continue

        entry = {
            "entity_type": entity_type,
            "label": label,
            "description": _ENTITY_DESCRIPTIONS.get(entity_type, ""),
            "opt_in": is_opt_in,
        }
        if is_french_only:
            entry["french_only"] = True

        if is_opt_in:
            opt_in_list.append(entry)
        else:
            default_list.append(entry)

    return {
        "language": language,
        "default_entities": default_list,
        "opt_in_entities": opt_in_list,
        "total_default": len(default_list),
        "total_opt_in": len(opt_in_list),
        "note": (
            "Les entités opt_in doivent être explicitement listées dans le paramètre "
            "'entities' pour être activées."
        ),
    }


# ---------------------------------------------------------------------------
# Warm-up : charge le modèle français en arrière-plan au démarrage
# ---------------------------------------------------------------------------

def _warmup() -> None:
    try:
        _get_analyzer("fr")
    except OSError:
        # Modèle spaCy absent — téléchargement automatique au premier démarrage.
        # Le modèle est mis en cache dans l'environnement uvx et persiste entre les runs.
        import subprocess, sys
        subprocess.run(
            [sys.executable, "-m", "spacy", "download", "fr_core_news_lg"],
            check=False,
        )
        try:
            _get_analyzer("fr")
        except Exception:
            pass
    except Exception:
        pass


threading.Thread(target=_warmup, daemon=True, name="nomos-warmup").start()


# ---------------------------------------------------------------------------
# Point d'entrée
# ---------------------------------------------------------------------------

def main():
    mcp.run()


if __name__ == "__main__":
    main()
