#!/usr/bin/env python3
"""
NomosAI – Anonymiseur de documents juridiques (RGPD)
======================================================
Détecte et masque les données personnelles dans des documents .docx, .pdf,
.txt et .md, en produisant un Markdown structuré et exploitable par des LLMs.

Moteur : Microsoft Presidio + modèle spaCy français (fr_core_news_lg)
Reconnaisseurs supplémentaires : NIR, SIRET, SIREN, TVA, passeport, CNI,
                                  permis de conduire, téléphones français.

Utilisation :
    python anonymize.py contrat.pdf
    python anonymize.py dossier/ --output dossier_anonymise/
    python anonymize.py contrat.docx --language fr --output contrat_anon.md
    python anonymize.py dossier/ --recursive --language fr
"""

import argparse
import sys
import time
from pathlib import Path
from typing import Optional

from nomosai.readers import read_document, SUPPORTED_EXTENSIONS
from nomosai.engine import build_analyzer, DocumentAnonymizer, DEFAULT_ENTITIES
from nomosai.formatter import to_markdown


# ---------------------------------------------------------------------------
# Traitement d'un fichier unique
# ---------------------------------------------------------------------------

def process_file(
    input_path: Path,
    output_path: Path,
    anonymizer: DocumentAnonymizer,
    language: str,
    entities: Optional[list[str]],
    score_threshold: float,
    verbose: bool = True,
) -> dict[str, int]:
    """
    Anonymise un fichier et écrit le Markdown de sortie.
    Retourne les statistiques d'entités détectées.
    """
    if verbose:
        print(f"  Lecture       : {input_path}")

    blocks = read_document(input_path)
    if not blocks:
        print(f"  [AVERTISSEMENT] Aucun texte extrait de {input_path.name}", file=sys.stderr)
        return {}

    anonymizer.reset()
    anonymized_blocks = anonymizer.anonymize_blocks(blocks, entities)

    md = to_markdown(
        anonymized_blocks,
        source_path=input_path,
        language=language,
        stats=dict(anonymizer.stats),
        score_threshold=score_threshold,
    )

    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(md, encoding="utf-8")

    _write_index(output_path, anonymizer, input_path)

    total = sum(anonymizer.stats.values())
    if verbose:
        index_path = output_path.with_name(output_path.stem + "-index.md")
        print(f"  Anonymisé     : {total} entité(s) → {output_path}")
        print(f"  Index         : {index_path}")

    return dict(anonymizer.stats)


# ---------------------------------------------------------------------------
# Index d'anonymisation
# ---------------------------------------------------------------------------

def _write_index(
    output_path: Path,
    anonymizer: DocumentAnonymizer,
    source_path: Path,
) -> None:
    """Écrit un fichier <output_stem>-index.md qui mappe chaque placeholder à sa valeur originale."""
    import datetime

    index_path = output_path.with_name(output_path.stem + "-index.md")
    entries = anonymizer.get_index()
    date_str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    lines = [
        "---",
        f"source: {source_path.name}",
        f"generated: {date_str}",
        f"total_entities: {len(entries)}",
        "---",
        "",
        "# Index d'anonymisation",
        "",
        f"**Source :** `{source_path.name}`  ",
        f"**Généré le :** {date_str}  ",
        f"**Entités uniques :** {len(entries)}  ",
        "",
        "> Ce fichier est **confidentiel** — il contient les données personnelles originales.",
        "> Ne pas inclure dans les exports anonymisés.",
        "",
        "| Placeholder | Valeur originale | Type |",
        "| --- | --- | --- |",
    ]

    for entry in entries:
        placeholder = entry["placeholder"]
        # Échapper les | et les sauts de ligne pour rester sur une seule ligne
        # de tableau Markdown (nécessaire pour que deanonymize.py puisse parser).
        original = (
            entry["original"]
            .replace("|",  "\\|")   # séparateur de colonne Markdown
            .replace("\r\n", "\\n") # CRLF (Windows)
            .replace("\n",   "\\n") # LF
            .replace("\r",   "\\n") # CR seul
        )
        label = entry["label"]
        lines.append(f"| `{placeholder}` | {original} | `{label}` |")

    lines += ["", "---", ""]
    index_path.write_text("\n".join(lines), encoding="utf-8")


# ---------------------------------------------------------------------------
# Traitement d'un dossier
# ---------------------------------------------------------------------------

def process_folder(
    input_dir: Path,
    output_dir: Path,
    anonymizer: DocumentAnonymizer,
    language: str,
    entities: Optional[list[str]],
    score_threshold: float,
    recursive: bool = False,
) -> None:
    """Traite tous les documents supportés dans un dossier."""
    pattern = "**/*" if recursive else "*"
    files = [
        f for f in input_dir.glob(pattern)
        if f.is_file() and f.suffix.lower() in SUPPORTED_EXTENSIONS
    ]

    if not files:
        print(f"Aucun fichier supporté trouvé dans {input_dir}")
        return

    print(f"\nDossier source  : {input_dir}")
    print(f"Dossier sortie  : {output_dir}")
    print(f"Fichiers trouvés: {len(files)}\n")

    all_stats: list[dict] = []
    errors: list[str] = []

    for i, file in enumerate(files, 1):
        rel = file.relative_to(input_dir)
        out = output_dir / rel.with_suffix(".md")
        print(f"[{i}/{len(files)}] {rel}")
        t0 = time.perf_counter()
        try:
            stats = process_file(
                file, out, anonymizer, language,
                entities, score_threshold, verbose=True,
            )
            elapsed = time.perf_counter() - t0
            all_stats.append({"file": str(rel), "stats": stats, "elapsed": elapsed})
            print(f"  Durée         : {elapsed:.1f}s")
        except Exception as e:
            print(f"  [ERREUR] {e}", file=sys.stderr)
            errors.append(str(rel))
        print()

    _write_report(output_dir, all_stats, errors, language)


def _write_report(
    output_dir: Path,
    all_stats: list[dict],
    errors: list[str],
    language: str,
) -> None:
    """Écrit un rapport de synthèse RGPD dans le dossier de sortie."""
    import datetime
    from nomosai.engine import ENTITY_LABELS

    date_str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    total_files = len(all_stats)
    total_entities = sum(sum(d["stats"].values()) for d in all_stats)

    # Agrégation par type d'entité
    aggregate: dict[str, int] = {}
    for d in all_stats:
        for etype, count in d["stats"].items():
            aggregate[etype] = aggregate.get(etype, 0) + count

    lines = [
        "# Rapport d'anonymisation RGPD",
        "",
        f"**Date de traitement :** {date_str}  ",
        f"**Langue :** {language}  ",
        f"**Fichiers traités :** {total_files}  ",
        f"**Entités supprimées (total) :** {total_entities}  ",
        "",
        "## Détail par catégorie d'entité",
        "",
        "| Catégorie | Occurrences |",
        "| --- | --- |",
    ]
    for etype, count in sorted(aggregate.items(), key=lambda x: -x[1]):
        label = ENTITY_LABELS.get(etype, etype)
        lines.append(f"| `{label}` | {count} |")

    lines += [
        "",
        "## Fichiers traités",
        "",
        "| Fichier | Entités | Durée |",
        "| --- | --- | --- |",
    ]
    for d in all_stats:
        total_f = sum(d["stats"].values())
        lines.append(f"| `{d['file']}` | {total_f} | {d['elapsed']:.1f}s |")

    if errors:
        lines += [
            "",
            "## Erreurs",
            "",
        ]
        for e in errors:
            lines.append(f"- `{e}`")

    lines += [
        "",
        "---",
        "",
        "> *Ce rapport confirme que les documents listés ont été traités*  ",
        "> *conformément aux exigences du RGPD (Règlement UE 2016/679).*  ",
        "> *Aucune donnée personnelle originale n'est conservée dans les fichiers de sortie.*",
        "",
    ]

    report_path = output_dir / "RAPPORT_ANONYMISATION.md"
    output_dir.mkdir(parents=True, exist_ok=True)
    report_path.write_text("\n".join(lines), encoding="utf-8")
    print(f"Rapport RGPD    : {report_path}")


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Anonymise des documents juridiques (.docx, .pdf, .txt, .md) "
            "et produit un Markdown structuré et conforme RGPD."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    parser.add_argument(
        "input",
        type=Path,
        help="Fichier ou dossier source (.docx, .pdf, .txt, .md)",
    )
    parser.add_argument(
        "-o", "--output",
        type=Path,
        default=None,
        help=(
            "Fichier .md ou dossier de sortie. "
            "Par défaut : <input>_anonymise.md ou <input>_anonymise/"
        ),
    )
    parser.add_argument(
        "--language",
        default="fr",
        metavar="LANG",
        help="Code langue pour le modèle NLP (défaut : fr)",
    )
    parser.add_argument(
        "--entities",
        nargs="+",
        default=None,
        metavar="ENTITE",
        help=(
            "Limite la détection à des types spécifiques. "
            f"Disponibles : {' '.join(DEFAULT_ENTITIES)}"
        ),
    )
    parser.add_argument(
        "--score-threshold",
        type=float,
        default=0.55,
        metavar="SEUIL",
        help="Seuil de confiance minimum pour la détection (défaut : 0.55)",
    )
    parser.add_argument(
        "--recursive", "-r",
        action="store_true",
        help="Parcourt les sous-dossiers (mode dossier uniquement)",
    )
    parser.add_argument(
        "--quiet", "-q",
        action="store_true",
        help="Réduit la verbosité",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    input_path: Path = args.input.resolve()

    if not input_path.exists():
        sys.exit(f"Introuvable : {input_path}")

    print(f"Initialisation de Presidio (langue={args.language}) …")
    t0 = time.perf_counter()
    analyzer = build_analyzer(args.language)
    anonymizer = DocumentAnonymizer(
        analyzer,
        language=args.language,
        score_threshold=args.score_threshold,
    )
    print(f"Prêt ({time.perf_counter() - t0:.1f}s)\n")

    # --- Mode dossier ---
    if input_path.is_dir():
        output_dir = args.output or input_path.parent / (input_path.name + "_anonymise")
        process_folder(
            input_path, output_dir.resolve(),
            anonymizer, args.language,
            args.entities, args.score_threshold,
            recursive=args.recursive,
        )
        return

    # --- Mode fichier unique ---
    if input_path.suffix.lower() not in SUPPORTED_EXTENSIONS:
        sys.exit(
            f"Format non supporté '{input_path.suffix}'. "
            f"Supportés : {', '.join(SUPPORTED_EXTENSIONS)}"
        )

    output_path = args.output or input_path.with_name(input_path.stem + "_anonymise.md")
    process_file(
        input_path, output_path.resolve(),
        anonymizer, args.language,
        args.entities, args.score_threshold,
        verbose=not args.quiet,
    )


if __name__ == "__main__":
    main()
