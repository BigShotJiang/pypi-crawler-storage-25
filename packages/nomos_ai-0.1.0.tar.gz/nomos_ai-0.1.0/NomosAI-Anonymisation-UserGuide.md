# NomosAI — Guide d'utilisation (Serveur MCP)

NomosAI expose ses capacités d'anonymisation via un serveur MCP (Model Context Protocol),
ce qui permet à un agent LLM (Claude Code, Claude Desktop) d'anonymiser et de restaurer
des documents directement, sans passer par le CLI.

---

## Prérequis

**Première installation (une seule fois par machine) — installer `uv` :**

- **Windows** — ouvre PowerShell et colle :
  ```
  powershell -c "irm https://astral.sh/uv/install.ps1 | iex"
  ```
- **Mac** — ouvre Terminal et colle :
  ```bash
  curl -LsSf https://astral.sh/uv/install.sh | sh
  ```

`uv` gère automatiquement Python et toutes les dépendances (spaCy, Presidio, modèle
français `fr_core_news_lg`). Aucun conda, aucun `pip install`, aucun `spacy download`
n'est nécessaire.

> **Windows — important :** après l'installation, `uv` et `uvx` ne sont pas disponibles
> dans le terminal déjà ouvert. **Ferme et rouvre un nouveau terminal** (PowerShell ou
> cmd) avant de continuer — sans ça, toutes les commandes suivantes échoueront avec
> *"n'est pas reconnu comme commande"*.

> **Première utilisation :** au premier démarrage, `uvx` télécharge automatiquement
> le modèle spaCy `fr_core_news_lg` (~550 Mo) et installe ~80 paquets — cela prend
> **2 à 5 minutes** selon la connexion. Les démarrages suivants sont instantanés.

---

## 1. Brancher à Claude Desktop (recommandé)

Édite le fichier de configuration de Claude Desktop :

- **Windows :** `%APPDATA%\Claude\claude_desktop_config.json`
- **Mac :** `~/Library/Application Support/Claude/claude_desktop_config.json`

Ajoute (ou crée) ce contenu :

```json
{
  "mcpServers": {
    "nomos-ai": {
      "command": "uvx",
      "args": ["nomos-ai"]
    }
  }
}
```

Redémarre Claude Desktop. Le serveur apparaît dans la liste des outils (icône marteau).

---

## 2. Brancher à Claude Code

### Étape 1 — Enregistrer le serveur

Ouvre un terminal **dans le dossier du projet** et exécute cette commande **une seule fois** :

```bash
claude mcp add nomos-ai -- uvx --from "C:\chemin\vers\NomosAI" nomos-ai
```

Remplace `C:\chemin\vers\NomosAI` par le chemin absolu du dossier cloné.
Exemple : `C:\Users\prenom\Desktop\projects\NomosAI`.

### Étape 2 — Pré-chauffer l'environnement (première fois uniquement)

La première fois, `uvx` doit télécharger les dépendances (~550 Mo). Lance manuellement
le serveur une fois pour déclencher ce téléchargement **avant** de faire la vérification :

```bash
uvx --from "C:\chemin\vers\NomosAI" nomos-ai
```

Attends que les logs s'affichent (`INFO Loaded recognizer: ...`), puis interromps
avec `Ctrl+C`. Le cache est maintenant prêt.

### Étape 3 — Vérifier la connexion

```bash
claude mcp list
# → nomos-ai   uvx --from ...   ✓ Connected
```

> **"Failed to connect" à l'étape 3 ?** C'est normal si l'étape 2 n'est pas terminée
> (téléchargement encore en cours). Attend la fin du téléchargement et relance
> `claude mcp list`.

Le serveur démarre automatiquement quand Claude Code en a besoin.

---

## 3. Tester les outils manuellement (inspecteur MCP)

Pour explorer et tester les outils interactivement :

```bash
npx @modelcontextprotocol/inspector uvx nomos-ai
```

Ouvre ensuite `http://localhost:5173` dans un navigateur.

---

## 4. Anonymiser du texte brut

Demande à l'agent (dans Claude Code ou Claude Desktop) :

> *« Anonymise ce texte : "Le Dr Jean Dupont, joignable au 01 23 45 67 89, travaille
> à la clinique Saint-Louis. Son numéro de sécu est 1 85 06 75 123 456 78." »*

L'agent appelle l'outil `anonymize_text` et retourne dans sa réponse :

- le **texte anonymisé** avec les placeholders (`[PERSONNE_1]`, `[TELEPHONE_1]`…)
- les **statistiques** de détection par type d'entité
- l'**index complet** des remplacements (placeholder → valeur originale)

### Paramètres disponibles

| Paramètre | Défaut | Description |
|-----------|--------|-------------|
| `text` | — | Texte à anonymiser |
| `language` | `"fr"` | Langue NLP : `fr`, `en`, `de`, `es`, `it`, `nl`, `pt` |
| `entities` | tous | Limiter à certains types, ex. `["PERSON", "EMAIL_ADDRESS"]` |
| `score_threshold` | `0.55` | Seuil de confiance (0.0–1.0) |

---

## 5. Anonymiser un fichier

Formats supportés : `.docx`, `.pdf`, `.txt`, `.md`, `.rst`

Demande à l'agent :

> *« Anonymise le fichier `C:\dossiers\contrat.pdf` »*

ou avec options :

> *« Anonymise `C:\dossiers\contrat.pdf` en français, uniquement les noms et e-mails,
> et écris le résultat dans `C:\dossiers\anonymise\contrat.md` »*

L'agent appelle `anonymize_file` et génère deux fichiers :

| Fichier | Contenu | Confidentialité |
|---------|---------|-----------------|
| `contrat_anonymise.md` | Document anonymisé, partageable | Public |
| `contrat_anonymise-index.md` | Mapping placeholder → valeur originale | **Confidentiel** |

### Paramètres disponibles

| Paramètre | Défaut | Description |
|-----------|--------|-------------|
| `file_path` | — | Chemin absolu du fichier source |
| `output_path` | `<nom>_anonymise.md` | Chemin du `.md` de sortie |
| `language` | `"fr"` | Langue NLP |
| `entities` | tous | Types d'entités à détecter (voir section 7) |
| `score_threshold` | `0.55` | Seuil de confiance |
| `write_index` | `true` | Générer le fichier confidentiel `-index.md` |

> **Important :** Conserve le fichier `-index.md` si tu veux pouvoir restaurer le document
> original ultérieurement. Sans lui, la désanonymisation est impossible.

---

## 6. Désanonymiser un document

Demande à l'agent :

> *« Restaure le fichier `C:\dossiers\contrat_anonymise.md` »*

L'agent appelle `deanonymize_file`. Il cherche automatiquement `contrat_anonymise-index.md`
dans le même dossier et génère `contrat_restaure.md`.

Si l'index est dans un emplacement différent :

> *« Restaure `C:\dossiers\contrat_anonymise.md` avec l'index
> `C:\archives\contrat_anonymise-index.md` »*

### Paramètres disponibles

| Paramètre | Défaut | Description |
|-----------|--------|-------------|
| `anonymized_file_path` | — | Chemin du `.md` anonymisé |
| `index_path` | auto-détecté | Chemin de l'index si non standard |
| `output_path` | `<stem>_restaure.md` | Chemin du fichier restauré |

---

## 7. Découvrir les types de PII détectables

Demande à l'agent :

> *« Quels types d'entités NomosAI peut-il détecter en français ? »*

L'agent appelle `list_entities` et liste tous les types disponibles. Réponse instantanée,
sans chargement du modèle NLP.

### Types actifs par défaut (français)

| Type | Label | Description |
|------|-------|-------------|
| `PERSON` | `PERSONNE` | Noms de personnes physiques |
| `ORGANIZATION` | `ORGANISATION` | Noms d'organisations ou entreprises |
| `LOCATION` | `LIEU` | Lieux géographiques, adresses |
| `EMAIL_ADDRESS` | `EMAIL` | Adresses e-mail |
| `PHONE_NUMBER` | `TELEPHONE` | Numéros de téléphone |
| `IBAN_CODE` | `IBAN` | Codes IBAN bancaires |
| `CREDIT_CARD` | `CARTE_CREDIT` | Numéros de carte de crédit |
| `URL` | `URL` | URLs et liens web |
| `IP_ADDRESS` | `IP` | Adresses IP |
| `FR_NIR` | `NIR` | Numéro INSEE / Sécurité Sociale (15 chiffres) |
| `FR_SIRET` | `SIRET` | Identifiant établissement (14 chiffres) |
| `FR_SIREN` | `SIREN` | Identifiant entreprise (9 chiffres) |
| `FR_TVA` | `TVA` | Numéro TVA intracommunautaire |
| `FR_PASSPORT` | `PASSEPORT` | Numéro de passeport français |
| `FR_CNI` | `CNI` | Carte Nationale d'Identité (12 chiffres) |
| `FR_DRIVING_LICENSE` | `PERMIS` | Permis de conduire post-2013 (AA-NNN-AA) |
| `FR_POSTAL_CODE` | `CODE_POSTAL` | Code postal français (avec contexte) |

### Types opt-in (à activer explicitement)

Ces types génèrent du bruit s'ils sont activés par défaut ; ils doivent être demandés
explicitement dans le paramètre `entities` :

| Type | Label | Description |
|------|-------|-------------|
| `DATE_TIME` | `DATE` | Dates et heures |
| `FILE_PATH` | `CHEMIN_FICHIER` | Chemins de fichiers Windows/Unix (français uniquement) |

Exemple d'activation :

> *« Anonymise `rapport.pdf` en détectant aussi les dates »*
> → l'agent passe `entities: ["PERSON", "EMAIL_ADDRESS", ..., "DATE_TIME"]`

---

## 8. Récapitulatif des outils MCP

| Outil | Usage typique |
|-------|---------------|
| `anonymize_text` | Anonymiser un extrait de texte passé directement à l'agent |
| `anonymize_file` | Anonymiser un fichier `.docx/.pdf/.txt/.md/.rst` sur disque |
| `deanonymize_file` | Restaurer un `.md` anonymisé à partir de son index confidentiel |
| `list_entities` | Lister les types de PII détectables (réponse instantanée) |

---

## 9. Flux de travail typique

```
Document original (.pdf / .docx)
        │
        ▼
  anonymize_file
        │
        ├─► contrat_anonymise.md        ← partageable, traitable par LLM
        └─► contrat_anonymise-index.md  ← confidentiel, à conserver précieusement
                                                │
                                                ▼
                                       deanonymize_file
                                                │
                                                ▼
                                       contrat_restaure.md  ← document original restauré
```

---

## Utilisation locale (développeurs)

Pour les contributeurs qui travaillent sur le code source, l'environnement conda `nomosai`
reste utilisable :

```bash
conda activate nomosai
python -m nomosai.server          # démarre le serveur MCP manuellement
python anonymize.py rapport.pdf   # CLI d'anonymisation
python deanonymize.py rapport_anonymise.md  # CLI de restauration
```

Configuration Claude Code (développement local) :

```bash
claude mcp add nomos-ai \
  --cwd "C:\Users\corla\Desktop\projects\NomosAI" \
  -- "C:\Users\corla\anaconda3\envs\nomosai\python.exe" -m nomosai.server
```
