import pyautogui as pya
import pyperclip
import time


def copy_clipboard():
    pya.hotkey("ctrl", "c")
    pya.hotkey("ctrl", "c")
    time.sleep(0.5)
    return pyperclip.paste()