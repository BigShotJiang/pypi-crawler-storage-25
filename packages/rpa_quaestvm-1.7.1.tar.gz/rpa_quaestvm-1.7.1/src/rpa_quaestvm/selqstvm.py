import os
import time
from typing import Literal

from PyPDF2 import PdfReader
from selenium import webdriver
from selenium.common.exceptions import (
    ElementNotInteractableException,
    StaleElementReferenceException,
    TimeoutException,
)
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.webdriver import WebDriver
from selenium.webdriver.remote.webelement import WebElement
from selenium.webdriver.support.ui import WebDriverWait

from rpa_quaestvm.logger import Logger, LoggerInstance


class SelQstvm:
    logger: LoggerInstance
    download_dir: str | None
    headless: bool

    def __init__(
        self,
        logger: Logger = None,
        download_dir: str | None = None,
        headless: bool = False,
        driver: WebDriver | None = None,
    ):
        self.logger = logger or Logger.get_logger("logs/rpa.log")
        self.download_dir = download_dir
        self.headless = headless
        self.driver = driver or SelQstvm.criar_driver_com_download(
            download_dir=download_dir, headless=headless
        )

    @classmethod
    def criar_driver_com_download(
        cls, download_dir: str | None = None, headless: bool = False
    ):
        chrome_options = Options()

        # Opções para estabilidade em ambientes automatizados
        if headless:
            chrome_options.add_argument("--headless")

        chrome_options.add_argument("--no-sandbox")
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument("--disable-gpu")
        chrome_options.add_argument("--start-maximized")

        if download_dir is not None:
            # Configurações para o download
            chrome_prefs = {
                "download.default_directory": download_dir,
                "download.prompt_for_download": False,
                "download.directory_upgrade": True,
                "plugins.always_open_pdf_externally": True,
            }
            chrome_options.add_experimental_option("prefs", chrome_prefs)

        driver = webdriver.Chrome(options=chrome_options)
        return driver

    def captura_elemento(
        self, js_selector: str, timeout=30.0, intervalo=0.25, raise_error=True
    ) -> Literal[False] | WebElement:
        """
        Executa o JS `return {js_selector}` repetidamente até retornar um elemento não nulo
        ou até `timeout` segundos.

        `js_selector` é a expressão após `return` (ex.: document.querySelector(...)).

        Se `raise_error` for False e o elemento não for encontrado, retorna False em vez
        de lançar TimeoutException.
        """
        deadline = time.monotonic() + timeout
        ultimo_erro = None

        while time.monotonic() < deadline:
            try:
                elemento = self.driver.execute_script(f"return {js_selector}")
                if elemento is not None:
                    return elemento
            except Exception as e:
                ultimo_erro = e

            restante = deadline - time.monotonic()
            if restante <= 0:
                break
            time.sleep(min(intervalo, restante))

        if not raise_error:
            return False

        msg = f"Elemento não encontrado após {timeout} s."
        if ultimo_erro:
            raise TimeoutException(f"{msg} Último erro: {ultimo_erro}") from ultimo_erro
        raise TimeoutException(msg)

    def get_handles(self):
        """Retorna um set com o driver.window_handles"""
        return set(self.driver.window_handles)

    def alternar_para_nova_aba(self, handles_antes: set[str], timeout=25):
        """Após um clique que abre nova aba, espera um `window_handle` novo e foca nele.

        Importante: `handles_antes` deve ser o snapshot **antes** do clique; se for tirado
        depois que a aba já existe, nenhuma diferença será detectada.
        """
        handles_antes = set(handles_antes)
        n_antes = len(handles_antes)
        try:
            WebDriverWait(self.driver, timeout).until(
                lambda d: len(set(d.window_handles) - handles_antes) >= 1
            )
        except TimeoutException as e:
            n_agora = len(self.driver.window_handles)
            raise TimeoutException(
                f"Nenhuma nova aba em {timeout}s (abas antes: {n_antes}, agora: {n_agora}). "
                "Confirme se o botão abre outra aba ou só navega na mesma; no segundo caso, "
                "não use troca de aba — espere carregar na aba atual."
            ) from e
        nova = (set(self.driver.window_handles) - handles_antes).pop()
        self.driver.switch_to.window(nova)

    def clicar_via_js(self, js_expression: str):
        """Clica no nó retornado por uma expressão JS (ex.: document.querySelector(...)). Evita stale element."""
        self.driver.execute_script(
            f"var __e = {js_expression}; if (__e && typeof __e.click === 'function') {{ __e.click(); }}"
        )

    def digitar_lento(self, elemento: WebElement, texto: str, intervalo=0.08):
        """Envia `texto` um caractere por vez, com pausa entre teclas (imita digitação humana)."""
        for caractere in texto:
            elemento.send_keys(caractere)
            if intervalo:
                time.sleep(intervalo)

    def clicar_com_retry(self, elemento: WebElement, timeout=15.0, intervalo=0.3):
        """
        Tenta clicar repetidamente até funcionar ou estourar o timeout.

        Útil para casos de "element not interactable" porque o elemento ainda
        não está clicável (overlay, animação, etc.).
        """
        deadline = time.monotonic() + timeout
        ultimo_erro = None

        while time.monotonic() < deadline:
            try:
                elemento.click()
                return
            except (
                ElementNotInteractableException,
                StaleElementReferenceException,
            ) as e:
                ultimo_erro = e

            restante = deadline - time.monotonic()
            if restante <= 0:
                break
            time.sleep(min(intervalo, restante))

        msg = f"Não foi possível clicar no elemento após {timeout}s."
        if ultimo_erro:
            raise TimeoutException(f"{msg} Último erro: {ultimo_erro}") from ultimo_erro
        raise TimeoutException(msg)

    def aguardar_download(self, nome_esperado: str, timeout=120, validar_pdf: bool = False):
        """Aguarda até que o arquivo seja baixado"""
        self.logger.info(f"Aguardando download do arquivo com nome {nome_esperado}...")
        if not self.download_dir:
            raise ValueError("Diretório de download não definido")

        start_time = time.time()
        last_check_time = 0

        while time.time() - start_time < timeout:
            current_time = time.time()

            # Mostra progresso a cada 10 segundos
            if current_time - last_check_time >= 10:
                elapsed = int(current_time - start_time)
                self.logger.info(f"Aguardando download... ({elapsed}s)")
                last_check_time = current_time

            try:
                arquivos = [
                    f
                    for f in os.listdir(self.download_dir)
                    if (nome_esperado is not None and nome_esperado in f) and not f.endswith(".crdownload")
                ]

                if arquivos:
                    file_path = os.path.join(self.download_dir, arquivos[0])
                    if validar_pdf and self.validar_pdf(file_path):
                        self.logger.info(
                            f"Arquivo válido encontrado: {os.path.basename(file_path)}"
                        )
                    return file_path

            except Exception as e:
                self.logger.warning(f"Erro ao verificar downloads: {e}")

            time.sleep(2)

        self.logger.error("Timeout: Falha ao baixar o arquivo")
        return None

    def validar_pdf(self, pdf_path: str):
        """Valida se o arquivo está completo e válido"""
        try:
            file_size = os.path.getsize(pdf_path)
            if file_size > 1024:  # Pelo menos 1KB
                # Espera 1 segundo e verifica se o tamanho mudou
                time.sleep(1)
                new_size = os.path.getsize(pdf_path)

                if new_size != file_size:
                    return False
                
                # Arquivo parou de crescer
                with open(pdf_path, "rb") as f:
                    reader = PdfReader(f)
                    is_valid = len(reader.pages) > 0
                    if is_valid:
                        self.logger.debug(
                            f"PDF validado: {os.path.basename(pdf_path)} - {len(reader.pages)} páginas"
                        )
                    return is_valid
            return False
        except Exception as e:
            self.logger.warning(f"Erro ao validar PDF: {e}")
            return False