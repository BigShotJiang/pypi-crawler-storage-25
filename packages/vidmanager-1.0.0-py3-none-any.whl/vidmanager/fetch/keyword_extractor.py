import json
import os

from dotenv import find_dotenv, load_dotenv
from google import genai

from vidmanager.content_analyser.gemini import _retry

_PROMPT = """You are a stock-video search assistant.
Given a phrase (possibly in any language), return a JSON array of 3-6 English keywords
that would find relevant stock footage on sites like Pexels or Shutterstock.
Return ONLY the JSON array, no other text.

Example input: "sunset over a busy city"
Example output: ["sunset", "city", "skyline", "traffic", "golden hour"]
"""


class KeywordExtractor:
    """Uses Gemini to extract English stock-video search keywords from a phrase."""

    def __init__(self, model: str = "gemini-2.5-flash") -> None:
        load_dotenv(find_dotenv(usecwd=True))
        api_key: str | None = os.environ.get("GEMINI_API_KEY")
        if not api_key:
            raise ValueError(
                "GEMINI_API_KEY environment variable is not set. "
                "Set it in your environment or in a .env file."
            )
        self._client: genai.Client = genai.Client(api_key=api_key)
        self._model_name: str = model

    def extract(self, phrase: str) -> list[str]:
        """Return 3-6 English search keywords for *phrase*."""
        response = _retry(
            lambda: self._client.models.generate_content(
                model=self._model_name,
                contents=[f"{_PROMPT}\n\nInput: {phrase}"],
                config={"response_mime_type": "application/json"},
            )
        )
        assert response.text is not None, (
            f"Gemini returned an empty response for keyword extraction of '{phrase}'"
        )
        keywords: list[str] = json.loads(response.text)
        return keywords
