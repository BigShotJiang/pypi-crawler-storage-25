import os
from pathlib import Path
from typing import cast

import httpx
from dotenv import find_dotenv, load_dotenv
from pydantic import BaseModel

from vidmanager.fetch.base import BaseFetcher, FetchResult


# ---------------------------------------------------------------------------
# Pexels API response models (only the fields we need)
# ---------------------------------------------------------------------------


class PexelsVideoFile(BaseModel):
    """One rendition of a Pexels video."""

    id: int
    quality: str | None = None  # "hd", "sd", etc. — may be null in API response
    file_type: str | None = None  # "video/mp4", ... — may be null in API response
    width: int | None = None
    height: int | None = None
    link: str | None = None  # download URL


class PexelsVideo(BaseModel):
    """A single video entry from Pexels search results."""

    id: int
    video_files: list[PexelsVideoFile]


class PexelsSearchResponse(BaseModel):
    """Top-level response from the Pexels /videos/search endpoint."""

    videos: list[PexelsVideo]


# ---------------------------------------------------------------------------
# Fetcher
# ---------------------------------------------------------------------------


def _select_best_file(
    video_files: list[PexelsVideoFile], target_height: int = 1080
) -> PexelsVideoFile | None:
    """Pick the mp4 file closest to *target_height*.

    When two files are equally close, prefer the higher resolution one.
    Returns None if no mp4 files are available.
    """
    mp4_files: list[PexelsVideoFile] = [
        f
        for f in video_files
        if f.file_type == "video/mp4"
        and f.link is not None
        and f.width is not None
        and f.height is not None
    ]
    if not mp4_files:
        return None

    def sort_key(f: PexelsVideoFile) -> tuple[int, int]:
        if f.height is None:
            return (1000000, 0)  # just put files with unknown height at the end

        distance = abs(f.height - target_height)
        # Negate height so higher resolution wins on tie
        return (distance, -f.height)

    return min(mp4_files, key=sort_key)


class PexelsFetcher(BaseFetcher):
    """Fetches videos from the Pexels API."""

    _BASE_URL = "https://api.pexels.com"

    def __init__(self) -> None:
        load_dotenv(find_dotenv(usecwd=True))
        api_key: str | None = os.environ.get("PEXELS_API_KEY")
        if not api_key:
            raise ValueError(
                "PEXELS_API_KEY environment variable is not set. "
                "Set it in your environment or in a .env file."
            )
        self._client: httpx.Client = httpx.Client(
            base_url=self._BASE_URL,
            headers={"Authorization": api_key},
            timeout=30.0,
        )

    def search(
        self, query: str, orientation: str = "all", per_page: int = 15, page: int = 1
    ) -> list[FetchResult]:
        """Search Pexels for videos matching *query*."""
        params: dict[str, str | int] = {
            "query": query,
            "per_page": per_page,
            "page": page,
        }
        if orientation in ("landscape", "portrait"):
            params["orientation"] = orientation

        resp: httpx.Response = self._client.get("/v1/videos/search", params=params)
        resp.raise_for_status()

        data = PexelsSearchResponse.model_validate(resp.json())
        results: list[FetchResult] = []
        for video in data.videos:
            best = _select_best_file(video.video_files)
            if best is None:
                continue
            # best is guaranteed non-None for link/width/height by _select_best_file
            results.append(
                FetchResult(
                    source_id=f"pexels:{video.id}",
                    download_url=cast(str, best.link),
                    width=cast(int, best.width),
                    height=cast(int, best.height),
                )
            )
        return results

    def download(self, result: FetchResult, dest: Path) -> Path:
        """Stream-download a video to *dest* directory.

        File is named ``{pexels_id}_{width}x{height}.mp4``.
        """
        dest = Path(dest)
        dest.mkdir(parents=True, exist_ok=True)

        # Extract numeric id from source_id like "pexels:12345"
        pexels_id: str = result.source_id.split(":", 1)[1]
        filename: str = f"{pexels_id}_{result.width}x{result.height}.mp4"
        filepath: Path = dest / filename

        with httpx.stream("GET", result.download_url, timeout=120.0) as stream:
            stream.raise_for_status()
            with open(filepath, "wb") as f:
                for chunk in stream.iter_bytes(chunk_size=8192):
                    f.write(chunk)

        return filepath
