from abc import ABC, abstractmethod
from pathlib import Path

from pydantic import BaseModel, Field


class FetchResult(BaseModel):
    """A single video found by a fetcher, ready for download."""

    source_id: str = Field(description="Origin identifier, e.g. 'pexels:12345'")
    download_url: str = Field(description="Direct URL to the video file")
    width: int = Field(description="Video width in pixels")
    height: int = Field(description="Video height in pixels")


class BaseFetcher(ABC):
    """Abstract base for video source fetchers."""

    @abstractmethod
    def search(
        self, query: str, orientation: str = "all", per_page: int = 15
    ) -> list[FetchResult]:
        """Search for videos matching *query* and return candidate results."""
        ...

    @abstractmethod
    def download(self, result: FetchResult, dest: Path) -> Path:
        """Download a video to *dest* directory and return the saved file path."""
        ...
