from datetime import datetime, timezone
from pathlib import Path
from random import randint
from concurrent.futures import ThreadPoolExecutor
from typing import cast

import click

from vidmanager.content_analyser.gemini import GeminiAnalyser
from vidmanager.fetch.base import FetchResult


@click.group()
def main() -> None:
    """Vidmanager — Video management toolkit."""


@main.command()
@click.argument("video_path", type=click.Path(exists=True))
def analyse(video_path: str) -> None:
    """Analyse a single video file and print the result as JSON."""
    analyser = GeminiAnalyser()
    result = analyser.analyse(video_path)
    click.echo(result.model_dump_json(indent=2))


@main.group()
def index() -> None:
    """Manage the video index."""


@index.command()
@click.option(
    "--dir",
    "dirs",
    multiple=True,
    required=True,
    type=click.Path(exists=True),
    help="Directory to scan for videos (can be specified multiple times).",
)
@click.option(
    "--index-file",
    "index_file",
    default="video_index.jsonl",
    type=click.Path(),
    help="Path to the JSONL index file.",
)
def build(dirs: tuple[str, ...], index_file: str) -> None:
    """Scan directories and build/update the video index."""
    from vidmanager.video_index.builder import build_index
    from vidmanager.video_index.index import VideoIndex

    vid_index = VideoIndex(Path(index_file))
    analyser = GeminiAnalyser()
    build_index(vid_index, analyser, [Path(d) for d in dirs])


@index.command()
@click.argument("query")
@click.option(
    "--index-file",
    "index_file",
    default="video_index.jsonl",
    type=click.Path(exists=True),
    help="Path to the JSONL index file.",
)
def match(query: str, index_file: str) -> None:
    """Match videos by strict keyword search."""
    from vidmanager.video_index.index import VideoIndex

    vid_index = VideoIndex(Path(index_file))
    results = vid_index.match(query)

    if not results:
        click.echo("No matching videos found.")
        return

    click.echo(f"Found {len(results)} matching video(s):\n")
    for r in results:
        click.echo(f"  {r.entry.video_path}")
        for field, keywords in r.matched_fields.items():
            click.echo(f"    {field}: {', '.join(keywords)}")
        click.echo()


@main.command()
@click.argument("query")
@click.option(
    "--src",
    type=click.Choice(["pexels"]),
    default="pexels",
    help="Video source provider.",
)
@click.option(
    "--dest",
    type=click.Path(),
    default=".",
    help="Output directory for downloaded videos.",
)
@click.option(
    "--smart",
    is_flag=True,
    default=False,
    help="Use Gemini to extract keywords from natural language.",
)
@click.option(
    "--orientation",
    type=click.Choice(["landscape", "portrait", "all"]),
    default="all",
    help="Video orientation filter.",
)
@click.option(
    "--limit",
    type=int,
    default=7,
    help="Maximum number of videos to download.",
)
@click.option(
    "--index-file",
    "index_file",
    type=click.Path(),
    default=None,
    help="Path to the JSONL index file. Defaults to <dest>/video_index.jsonl.",
)
def fetch(
    query: str,
    src: str,
    dest: str,
    smart: bool,
    orientation: str,
    limit: int,
    index_file: str | None,
) -> None:
    """Fetch stock videos, analyse them, and add to the index."""
    from vidmanager.fetch.keyword_extractor import KeywordExtractor
    from vidmanager.fetch.pexels import PexelsFetcher
    from vidmanager.models import VideoIndexEntry
    from vidmanager.video_index.index import VideoIndex

    dest_path: Path = Path(dest).resolve()
    dest_path.mkdir(parents=True, exist_ok=True)

    if index_file is None:
        index_path: Path = dest_path / "video_index.jsonl"
    else:
        index_path = Path(index_file)

    # -- Resolve search query --
    search_query: str = query
    if smart:
        click.echo("Extracting keywords with Gemini...")
        extractor = KeywordExtractor()
        keywords: list[str] = extractor.extract(query)
        search_query = " ".join(keywords)
        click.echo(f"  Keywords: {search_query}")

    # -- Create fetcher --
    if src == "pexels":
        fetcher = PexelsFetcher()
    else:
        raise click.ClickException(f"Unknown source: {src}")

    # -- Search --
    click.echo(f"Searching {src} for '{search_query}'...")

    # randomize page to get more variety, since we might filter out some results later
    results: list[FetchResult] = fetcher.search(
        search_query, orientation=orientation, per_page=limit * 3, page=randint(1, 3)
    )

    vid_index = VideoIndex(index_path)
    existing: set[str] = vid_index.existing_sources()
    filtered_results = []

    for r in results:
        if r.source_id in existing:
            click.echo(f"  Skipping {r.source_id} (already in index)")
        else:
            filtered_results.append(r)
            existing.add(r.source_id)

    results = filtered_results

    # here we might get small less amount of results than requested and we don't loop for fetching,
    # because we don't want to find new videos all the time.
    if not results:
        click.echo("No new videos to download (all results already in index).")
        return

    # Limit to requested count
    results = results[:limit]
    click.echo(f"Downloading and analysing {len(results)} video(s)...\n")

    def download(result) -> tuple[Path, FetchResult] | None:
        try:
            filepath: Path = fetcher.download(result, dest_path)
            click.echo(f"  Saved to {filepath.name}")
            return filepath, result
        except Exception as e:
            click.echo(f"  Failed to download: {e}")
            return None

    with ThreadPoolExecutor(max_workers=10) as executor:
        click.echo(f"Downloading {len(results)} videos ...")
        filepath_result_tuples = cast(
            list[tuple[Path, FetchResult]],
            list(filter(bool, executor.map(download, results))),
        )

    analyser = GeminiAnalyser()
    for i, (filepath, result) in enumerate(filepath_result_tuples, 1):
        click.echo(f"[{i}/{len(results)}] analysing {result.source_id}...")
        try:
            analysis = analyser.analyse(filepath)

            entry = VideoIndexEntry(
                video_path=str(filepath),
                analysed_at=datetime.now(timezone.utc),
                analysis=analysis,
                source=result.source_id,
            )
            vid_index.upsert([entry])
            click.echo("  Done.")
        except Exception as e:
            click.echo(f"  Failed: {e}")
