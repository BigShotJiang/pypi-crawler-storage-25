from datetime import datetime, timezone
from pathlib import Path

from vidmanager.content_analyser.base import BaseAnalyser
from vidmanager.models import VideoIndexEntry
from vidmanager.video_index.index import VideoIndex

DEFAULT_EXTENSIONS: list[str] = [".mp4", ".mov", ".avi", ".mkv", ".webm"]


def discover_videos(
    dirs: list[Path],
    extensions: list[str] = DEFAULT_EXTENSIONS,
) -> list[Path]:
    """Recursively find all video files in the given directories."""
    videos: list[Path] = []
    seen: set[Path] = set()
    for d in dirs:
        d = d.resolve()
        if not d.is_dir():
            continue
        for ext in extensions:
            for path in d.rglob(f"*{ext}"):
                resolved = path.resolve()
                if resolved not in seen:
                    seen.add(resolved)
                    videos.append(resolved)
    return sorted(videos)


def build_index(
    index: VideoIndex,
    analyser: BaseAnalyser,
    video_dirs: list[Path],
    extensions: list[str] = DEFAULT_EXTENSIONS,
) -> None:
    """Discover videos, skip already-indexed ones, analyse new ones, upsert into index."""
    all_videos: list[Path] = discover_videos(video_dirs, extensions)
    indexed_paths: set[str] = {e.video_path for e in index.entries}

    new_videos: list[Path] = [v for v in all_videos if str(v) not in indexed_paths]

    if not new_videos:
        print("No new videos to index.")
        return

    total: int = len(new_videos)
    print(f"Found {total} new video(s) to analyse.")

    for i, video_path in enumerate(new_videos, 1):
        print(f"[{i}/{total}] Analysing {video_path.name}...")
        try:
            analysis = analyser.analyse(video_path)
            entry = VideoIndexEntry(
                video_path=str(video_path),
                analysed_at=datetime.now(timezone.utc),
                analysis=analysis,
            )
            index.upsert([entry])
            print("  Done.")
        except Exception as e:
            print(f"  Failed: {e}")
