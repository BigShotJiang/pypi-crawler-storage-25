from pathlib import Path

import Stemmer

from vidmanager.models import MatchResult, VideoIndexEntry

_LIST_FIELDS: tuple[str, ...] = ("tags", "keywords", "objects", "actions")
_SIMPLE_TEXT_FIELDS: tuple[str, ...] = ("setting", "mood")
_LONG_TEXT_FIELDS: tuple[str, ...] = (
    "scenes",
    "summary",
)  # for future use of semantic search


class VideoIndex:
    """Manages a JSONL index of video analysis results.

    On init, loads existing entries, prunes any whose video files
    no longer exist on disk, and builds per-entry stemmed token sets
    for fast search.
    """

    def __init__(self, index_path: Path) -> None:
        self._index_path: Path = Path(index_path)
        self._entries: dict[str, VideoIndexEntry] = {}
        self._stemmer: Stemmer.Stemmer = Stemmer.Stemmer("english")
        # video_path -> field_name -> set of stemmed tokens
        self._stems: dict[str, dict[str, set[str]]] = {}

        # call this method after declaring self._entries and self._stems
        self._load_prune_and_stem()

    def _stem_entry(self, entry: VideoIndexEntry) -> dict[str, set[str]]:
        """Build a mapping of field_name -> stemmed token set for one entry."""
        field_stems: dict[str, set[str]] = {}
        a = entry.analysis

        for field in _LIST_FIELDS:
            values: list[str] = getattr(a, field)
            field_stems[field] = {
                s for v in values for s in self._stemmer.stemWords(v.lower().split())
            }

        for field in _SIMPLE_TEXT_FIELDS:
            value: str = getattr(a, field)
            field_stems[field] = set(self._stemmer.stemWords(value.lower().split()))

        return field_stems

    def _load_prune_and_stem(self) -> None:
        """Load entries from JSONL, discard missing files, and build stem cache."""
        if not self._index_path.exists():
            return

        should_prune: bool = False
        for line in self._index_path.read_text().splitlines():
            line = line.strip()
            if not line:
                continue
            entry = VideoIndexEntry.model_validate_json(line)
            if Path(entry.video_path).exists():
                self._entries[entry.video_path] = entry
                self._stems[entry.video_path] = self._stem_entry(entry)
            else:
                should_prune = True

        if should_prune:
            self._persist()

    def upsert(self, entries: list[VideoIndexEntry]) -> None:
        """Insert or overwrite entries by video_path. Persists to JSONL."""
        for entry in entries:
            self._entries[entry.video_path] = entry
            self._stems[entry.video_path] = self._stem_entry(entry)
        self._persist()

    def remove(self, video_paths: list[str]) -> None:
        """Remove entries by video_path. Persists to JSONL."""
        for path in video_paths:
            self._entries.pop(path, None)
            self._stems.pop(path, None)
        self._persist()

    def match(self, query: str) -> list[MatchResult]:
        """Stemmed keyword match. ALL query keywords must appear in at least one field.

        Both query words and indexed field tokens are reduced to their stems
        (via Snowball stemmer) before comparison, so "running" matches "run".
        All comparisons are case-insensitive.
        """
        query_stems: list[str] = self._stemmer.stemWords(query.lower().split())
        if not query_stems:
            return []

        # Keep original query words for reporting
        query_words: list[str] = query.lower().split()

        results: list[MatchResult] = []

        all_fields = list(_LIST_FIELDS) + list(_SIMPLE_TEXT_FIELDS)

        for video_path, entry in self._entries.items():
            entry_stems: dict[str, set[str]] = self._stems[video_path]
            matched_fields: dict[str, list[str]] = {}
            all_matched: bool = True

            for stem, word in zip(query_stems, query_words):
                kw_matched: bool = False

                for field_name in all_fields:
                    if stem in entry_stems[field_name]:
                        matched_fields.setdefault(field_name, []).append(word)
                        kw_matched = True

                if not kw_matched:
                    all_matched = False
                    break

            if all_matched:
                results.append(MatchResult(entry=entry, matched_fields=matched_fields))

        return results

    def _persist(self) -> None:
        """Rewrite the entire JSONL file from in-memory state."""
        self._index_path.parent.mkdir(parents=True, exist_ok=True)
        lines: list[str] = [entry.model_dump_json() for entry in self._entries.values()]
        self._index_path.write_text("\n".join(lines) + "\n" if lines else "")

    def has_source(self, source_id: str) -> bool:
        """Check if any entry has the given source identifier."""
        return source_id in self.existing_sources()

    def existing_sources(self) -> set[str]:
        """Return all non-None source values currently in the index."""
        return {e.source for e in self._entries.values() if e.source is not None}

    @property
    def entries(self) -> list[VideoIndexEntry]:
        """All currently loaded entries."""
        return list(self._entries.values())

    def __len__(self) -> int:
        return len(self._entries)
