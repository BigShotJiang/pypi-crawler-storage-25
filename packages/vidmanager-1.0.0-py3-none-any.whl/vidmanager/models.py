from datetime import datetime

from pydantic import BaseModel, Field


class VideoAnalysis(BaseModel):
    """Structured metadata extracted from a single video by a content analyser."""

    # -- Long-text fields (reserved for future semantic search) --
    summary: str = Field(description="2-4 sentence description of the video content")
    scenes: list[str] = Field(
        description="Brief descriptions of each distinct scene/shot, in chronological order"
    )

    # -- List fields (used in stemmed keyword matching) --
    tags: list[str] = Field(
        description="Category labels: content type like people, landscape, animals, food, etc."
    )
    keywords: list[str] = Field(
        description="Specific nouns visible in the video, used for search and filtering"
    )
    actions: list[str] = Field(
        description="Actions or activities performed by people or animals"
    )
    objects: list[str] = Field(
        description="Notable physical objects visible in the video"
    )

    # -- Simple-text fields (used in stemmed keyword matching) --
    mood: str = Field(description="Overall mood or tone, e.g. joyful, tense, calm")
    setting: str = Field(
        description="Where the video takes place, e.g. indoor living room, outdoor beach"
    )


class VideoIndexEntry(BaseModel):
    """One row in the JSONL video index file."""

    video_path: str = Field(description="Absolute path to the video file on disk")
    analysed_at: datetime = Field(
        description="UTC timestamp of when the analysis was performed"
    )
    analysis: VideoAnalysis
    source: str | None = Field(
        default=None,
        description=(
            "Origin identifier in 'provider:id' format, e.g. 'pexels:12345'. "
            "None for local files."
        ),
    )


class MatchResult(BaseModel):
    """A single hit returned by VideoIndex.match()."""

    entry: VideoIndexEntry
    matched_fields: dict[str, list[str]] = Field(
        description="Mapping of field name to the query words that matched in that field"
    )
