import os
import time
from collections.abc import Callable
from pathlib import Path
from typing import TypeVar

from dotenv import find_dotenv, load_dotenv
from google import genai
from google.genai.errors import ServerError

from vidmanager.content_analyser.base import BaseAnalyser
from vidmanager.models import VideoAnalysis
from vidmanager.util.video_preprocessor import VideoPreprocessor

T = TypeVar("T")

_PROMPT = """Analyze this video and return a JSON object with exactly these fields:
- summary: a 2-4 sentence description of what happens in the video
- tags: a list of category labels such as content type (people, landscape, animals, food, etc.)
- keywords: a comprehensive list of specific nouns visible in the video — used for search and filtering
- scenes: a list of brief descriptions for each distinct scene or shot in the video, in chronological order
- mood: the overall mood or tone of the video (e.g. "joyful", "tense", "calm", "dramatic")
- actions: a list of actions or activities performed by people or animals in the video
- objects: a list of notable physical objects visible in the video
- setting: a short description of where the video takes place (e.g. "indoor living room", "outdoor beach")

Return only valid JSON. Example:
{"summary": "A golden retriever fetches a ball on a sunny beach while its owner watches.", "tags": ["animals", "outdoor", "recreation"], "keywords": ["dog", "golden retriever", "beach", "ball", "ocean"], "scenes": ["A dog runs across the sand toward the water", "The dog picks up a ball from the surf", "The dog returns the ball to its owner"], "mood": "joyful", "actions": ["running", "fetching", "swimming"], "objects": ["ball", "leash", "towel", "sunglasses"], "setting": "outdoor sandy beach on a sunny day"}"""


def _retry(fn: Callable[[], T], max_retries: int = 5, base_delay: float = 5.0) -> T:
    """Call *fn* with exponential backoff on transient Gemini errors."""
    for attempt in range(1, max_retries + 1):
        try:
            return fn()
        except ServerError as exc:
            if attempt == max_retries:
                raise
            delay = base_delay * (2 ** (attempt - 1))
            print(
                f"  Retry {attempt}/{max_retries} after {exc}, waiting {delay:.0f}s …"
            )
            time.sleep(delay)
    raise RuntimeError("unreachable")


class GeminiAnalyser(BaseAnalyser):
    def __init__(
        self,
        model: str = "gemini-2.5-flash",
        preprocess: bool = True,
    ):
        load_dotenv(find_dotenv(usecwd=True))
        api_key = os.environ.get("GEMINI_API_KEY")
        if not api_key:
            raise ValueError(
                "GEMINI_API_KEY environment variable is not set. "
                "Set it in your environment or in a .env file."
            )
        self._client = genai.Client(api_key=api_key)
        self._model_name = model
        self._preprocess = preprocess
        self._preprocessor = VideoPreprocessor() if preprocess else None

    def analyse(self, video_path: str | Path) -> VideoAnalysis:
        video_path = Path(video_path)
        if not video_path.exists():
            raise FileNotFoundError(f"Video file not found: {video_path}")

        upload_path = video_path
        preprocessed_path: Path | None = None
        try:
            if self._preprocessor is not None:
                preprocessed_path = self._preprocessor.process(video_path)
                upload_path = preprocessed_path

            video_file = _retry(lambda: self._client.files.upload(file=upload_path))

            assert video_file.state is not None, (
                f"Upload returned no state for '{video_path.name}' — the file may not have been accepted by the API"
            )
            while video_file.state.name == "PROCESSING":
                time.sleep(2)
                assert video_file.name is not None, (
                    f"Uploaded file for '{video_path.name}' has no resource name — cannot poll processing status"
                )
                video_file = self._client.files.get(name=video_file.name)
                assert video_file.state is not None, (
                    f"Polling returned no state for '{video_path.name}' — the file may have been deleted during processing"
                )

            if video_file.state.name == "FAILED":
                raise RuntimeError(
                    f"Gemini video processing failed for '{video_path.name}'. "
                    f"The file may be corrupted, in an unsupported format, or exceed size limits."
                )

            response = _retry(
                lambda: self._client.models.generate_content(
                    model=self._model_name,
                    contents=[video_file, _PROMPT],
                    config={"response_mime_type": "application/json"},
                )
            )

            assert response.text is not None, (
                f"Gemini returned an empty response for '{video_path.name}' — "
                f"the model may have refused the content or hit a safety filter"
            )
            return VideoAnalysis.model_validate_json(response.text)
        finally:
            if preprocessed_path is not None and preprocessed_path.exists():
                preprocessed_path.unlink()
