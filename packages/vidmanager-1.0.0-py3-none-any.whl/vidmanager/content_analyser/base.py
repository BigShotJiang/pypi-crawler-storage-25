from abc import ABC, abstractmethod
from pathlib import Path

from vidmanager.models import VideoAnalysis


class BaseAnalyser(ABC):
    @abstractmethod
    def analyse(self, video_path: str | Path) -> VideoAnalysis:
        """Analyse a video file and return structured metadata."""
        ...
