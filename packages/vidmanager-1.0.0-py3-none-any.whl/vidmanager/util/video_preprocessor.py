import json
import shutil
import subprocess
import tempfile
from pathlib import Path


class FFmpegNotFoundError(RuntimeError):
    """Raised when FFmpeg/ffprobe is not found on the system."""

    def __init__(self) -> None:
        super().__init__(
            "FFmpeg is not installed or not found in PATH.\n"
            "Install it with:\n"
            "  macOS:          brew install ffmpeg\n"
            "  Ubuntu/Debian:  sudo apt install ffmpeg\n"
            "  Windows:        winget install ffmpeg"
        )


class VideoPreprocessor:
    """Preprocess videos before uploading to Gemini API.

    Reduces resolution, dynamically adjusts frame rate to fit a target
    duration, and strips audio — all in a single FFmpeg pass.
    """

    def __init__(
        self,
        target_duration: int = 20,
        target_height: int = 360,
    ) -> None:
        self._target_duration = target_duration
        self._target_height = target_height
        self._ffmpeg = self._resolve_binary("ffmpeg")
        self._ffprobe = self._resolve_binary("ffprobe")

    @staticmethod
    def _resolve_binary(name: str) -> str:
        path = shutil.which(name)
        if path is None:
            raise FFmpegNotFoundError()
        return path

    def _probe_video(self, video_path: Path) -> dict:
        """Return ffprobe JSON with format and video stream info."""
        result = subprocess.run(
            [
                self._ffprobe,
                "-v",
                "quiet",
                "-print_format",
                "json",
                "-show_format",
                "-show_streams",
                "-select_streams",
                "v:0",
                str(video_path),
            ],
            capture_output=True,
            text=True,
            check=True,
        )
        return json.loads(result.stdout)

    def get_video_duration(self, video_path: Path) -> float:
        """Return video duration in seconds using ffprobe."""
        info = self._probe_video(video_path)
        return float(info["format"]["duration"])

    def _get_source_fps(self, video_path: Path) -> float:
        """Return the source video's frame rate."""
        info = self._probe_video(video_path)
        # r_frame_rate is a fraction like "24000/1001"
        num, den = info["streams"][0]["r_frame_rate"].split("/")
        return int(num) / int(den)

    def _calculate_select_step(
        self, source_duration: float, source_fps: float
    ) -> int | None:
        """Calculate frame step for select filter.

        Returns None if the source is already short enough (no resampling needed).
        Returns the number of source frames to skip between each selected frame.
        """
        if source_duration <= self._target_duration:
            return None
        total_frames = source_duration * source_fps
        target_frames = self._target_duration  # 1 frame per second of target
        step = int(total_frames / target_frames)
        return max(step, 2)

    def process(self, input_path: Path) -> Path:
        """Preprocess video: downscale, resample to target duration, strip audio.

        Returns path to a temporary processed file. Caller must delete it when done.
        """
        input_path = Path(input_path)
        if not input_path.exists():
            raise FileNotFoundError(f"Video file not found: {input_path}")

        source_duration = self.get_video_duration(input_path)
        source_fps = self._get_source_fps(input_path)
        select_step = self._calculate_select_step(source_duration, source_fps)

        # Build video filter chain
        filters: list[str] = [f"scale=-2:{self._target_height}"]
        if select_step is not None:
            # Use select (not fps) to sample frames — select preserves the
            # original timebase, so setpts=N/TB reliably produces 1-second
            # spacing.  The fps filter changes TB to 1/fps which makes
            # setpts=N/TB produce wrong durations.
            filters.append(f"select='not(mod(n\\,{select_step}))'")
            filters.append("setpts=N/TB")

        output_path = Path(
            tempfile.mkstemp(suffix=".mp4", prefix="vidmanager_preprocessed_")[1]
        )

        cmd = [
            self._ffmpeg,
            "-i",
            str(input_path),
            "-vf",
            ",".join(filters),
            "-an",  # strip audio
            "-c:v",
            "libx264",
            "-bf",
            "0",  # disable B-frames to avoid pts/dts muxer errors with setpts
            "-y",  # overwrite output
            str(output_path),
        ]

        subprocess.run(cmd, capture_output=True, text=True, check=True)
        return output_path
