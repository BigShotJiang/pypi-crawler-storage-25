# adiumentum

[Documentation]()

Utilities that I find myself using repeatedly in other projects.

Raise No issues and you will be told no lies.

## Highlights

### `adiumentum.fp`

Type-specific map and filter operations.

```python
from adiumentum.fp import tmap, smap, lmap, tfilter, sfilter, lfilter

original = [0, 1, 2, 3, 4]

def is_gt_2(i: int) -> bool:
    return i > 2


def halve(i: int) -> float:
    return i / 2


halved_tuple = tmap(halve, original)
halved_list = lmap(halve, original)
halved_set = smap(halve, original)

gt2_tuple = tfilter(is_gt_2, original)
gt2_list = lfilter(is_gt_2, original)
gt2_set = sfilter(is_gt_2, original)

truthy_tuple = tfilter(original)
truthy_list = lfilter(original)
truthy_set = sfilter(original)
```

## Development

With Nix installed, you can enter a development environment with all dependencies installed:

```sh
nix develop
```

## Roadmap

- [ ] fix docs; get running in CI
- [ ] full test coverage
- [ ] full documentation
- [ ] divide into a few smaller packages?
