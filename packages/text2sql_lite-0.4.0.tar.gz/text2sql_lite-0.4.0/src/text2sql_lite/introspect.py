from __future__ import annotations

from text2sql_lite.schema import Column, Table, TableSchema


def introspect_sqlite(path: str) -> TableSchema:
    import sqlite3

    con = sqlite3.connect(path)
    try:
        cur = con.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
        )
        tables: list[Table] = []
        for (name,) in cur.fetchall():
            cols_cur = con.execute(f'PRAGMA table_info("{name}")')
            columns = tuple(
                Column(row[1], row[2] or None) for row in cols_cur.fetchall()
            )
            tables.append(Table(name, columns))
        return TableSchema(tuple(tables))
    finally:
        con.close()


def introspect_postgres(conn: object) -> TableSchema:
    import importlib.util

    if importlib.util.find_spec("psycopg") is None:  # pragma: no cover
        raise ImportError(
            "Install the 'postgres' extra: pip install 'text2sql-lite[postgres]'"
        )

    if not hasattr(conn, "cursor"):
        raise TypeError("conn must be a psycopg connection")

    q_tables = """
        SELECT table_name
        FROM information_schema.tables
        WHERE table_schema = 'public' AND table_type = 'BASE TABLE'
        ORDER BY table_name
    """
    q_cols = """
        SELECT column_name, data_type
        FROM information_schema.columns
        WHERE table_schema = 'public' AND table_name = %s
        ORDER BY ordinal_position
    """
    tables: list[Table] = []
    with conn.cursor() as cur:
        cur.execute(q_tables)
        for (tname,) in cur.fetchall():
            cur.execute(q_cols, (tname,))
            columns = tuple(Column(r[0], r[1]) for r in cur.fetchall())
            tables.append(Table(tname, columns))
    return TableSchema(tuple(tables))


def introspect_mysql(conn: object) -> TableSchema:
    import importlib.util

    if importlib.util.find_spec("pymysql") is None:  # pragma: no cover
        raise ImportError(
            "Install the 'mysql' extra: pip install 'text2sql-lite[mysql]'"
        )

    if not hasattr(conn, "cursor"):
        raise TypeError("conn must be a PyMySQL connection")

    q_tables = """
        SELECT TABLE_NAME
        FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = DATABASE() AND TABLE_TYPE = 'BASE TABLE'
        ORDER BY TABLE_NAME
    """
    q_cols = """
        SELECT COLUMN_NAME, DATA_TYPE
        FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = %s
        ORDER BY ORDINAL_POSITION
    """
    tables: list[Table] = []
    with conn.cursor() as cur:
        cur.execute(q_tables)
        for (tname,) in cur.fetchall():
            cur.execute(q_cols, (tname,))
            columns = tuple(Column(r[0], r[1]) for r in cur.fetchall())
            tables.append(Table(tname, columns))
    return TableSchema(tuple(tables))
