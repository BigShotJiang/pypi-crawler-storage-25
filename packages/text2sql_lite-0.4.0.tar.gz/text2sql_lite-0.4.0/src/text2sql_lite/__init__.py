"""text2sql-lite: English → SQL with dialect-aware output and optional LLM backends."""

from text2sql_lite.api import TranslateResult, translate
from text2sql_lite.dialects import Dialect
from text2sql_lite.llm import (
    GeminiChatClient,
    LLMClient,
    MistralChatClient,
    OpenAIChatClient,
    translate_with_llm,
)
from text2sql_lite.schema import Column, Table, TableSchema

__all__ = [
    "Column",
    "Dialect",
    "GeminiChatClient",
    "LLMClient",
    "MistralChatClient",
    "OpenAIChatClient",
    "Table",
    "TableSchema",
    "TranslateResult",
    "translate",
    "translate_with_llm",
]

__version__ = "0.4.0"
