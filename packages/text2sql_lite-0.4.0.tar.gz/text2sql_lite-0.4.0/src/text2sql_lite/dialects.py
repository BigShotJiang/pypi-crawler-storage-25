from __future__ import annotations

from enum import Enum


class Dialect(str, Enum):
    SQLITE = "sqlite"
    POSTGRES = "postgres"
    MYSQL = "mysql"

    def quote_ident(self, name: str) -> str:
        if not name:
            return '""' if self == Dialect.POSTGRES else "``"
        if self == Dialect.POSTGRES:
            escaped = name.replace('"', '""')
            return f'"{escaped}"'
        escaped = name.replace("`", "``")
        return f"`{escaped}`"
