from __future__ import annotations


class MistralChatClient:
    """Mistral AI chat API (install: ``pip install 'text2sql-lite[llm_mistral]'``)."""

    def __init__(self, api_key: str | None = None, *, model: str = "mistral-small-latest") -> None:
        self._api_key = api_key
        self._model = model

    def complete(self, system: str, user: str) -> str:
        try:
            from mistralai.client import Mistral
        except ImportError as e:  # pragma: no cover
            raise ImportError(
                "Install the llm_mistral extra: pip install 'text2sql-lite[llm_mistral]'"
            ) from e

        from mistralai.client.models.systemmessage import SystemMessage
        from mistralai.client.models.usermessage import UserMessage

        client = Mistral(api_key=self._api_key)
        resp = client.chat.complete(
            model=self._model,
            temperature=0,
            messages=[  # type: ignore[arg-type]
                SystemMessage(content=system),
                UserMessage(content=user),
            ],
        )
        choice = resp.choices[0].message.content
        if choice is None:
            raise ValueError("No content in Mistral response")
        return str(choice)
