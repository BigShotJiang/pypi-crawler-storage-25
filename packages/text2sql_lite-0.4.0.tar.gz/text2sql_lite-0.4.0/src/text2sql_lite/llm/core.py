from __future__ import annotations

from typing import Protocol

from text2sql_lite.dialects import Dialect
from text2sql_lite.schema import TableSchema


class LLMClient(Protocol):
    """Any object that runs a single system+user completion and returns text."""

    def complete(self, system: str, user: str) -> str: ...


def _dialect_rules(dialect: Dialect) -> str:
    if dialect == Dialect.POSTGRES:
        return (
            "Target PostgreSQL. Use double-quoted identifiers only when needed. "
            "Prefer ILIKE for case-insensitive string matches on user text."
        )
    if dialect == Dialect.MYSQL:
        return (
            "Target MySQL. Use backticks for reserved identifiers when needed. "
            "For case-insensitive text matching use "
            "LOWER(column) LIKE LOWER(CONCAT('%', literal, '%')) "
            "or a similar safe pattern—MySQL has no ILIKE."
        )
    return (
        "Target SQLite. Use backticks for reserved identifiers if needed. "
        "Use LIKE for case-insensitive matching when appropriate."
    )


def translate_with_llm(
    text: str,
    *,
    dialect: Dialect,
    schema: TableSchema,
    client: LLMClient,
) -> tuple[str, str]:
    """Return (sql, rationale) from an LLM client."""

    schema_blob = schema.as_compact_ddl() or "No schema provided; infer sensible names."
    system = (
        "You are a careful SQL generator. Reply with exactly two lines: "
        "1) SQL ending with semicolon. 2) One short sentence explaining the query. "
        "Do not use markdown fences. "
        f"{_dialect_rules(dialect)} "
        "Never invent tables/columns that contradict the schema summary when it lists columns."
    )
    user = f"Question: {text.strip()}\nSchema: {schema_blob}\nDialect: {dialect.value}"
    raw = client.complete(system, user).strip()
    lines = [ln.strip() for ln in raw.splitlines() if ln.strip()]
    if not lines:
        raise ValueError("Empty LLM response")
    sql = lines[0]
    if not sql.endswith(";"):
        sql += ";"
    rationale = lines[1] if len(lines) > 1 else "LLM-generated SQL."
    return sql, rationale
