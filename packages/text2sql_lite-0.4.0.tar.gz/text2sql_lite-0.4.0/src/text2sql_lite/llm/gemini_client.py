from __future__ import annotations


class GeminiChatClient:
    """Google Gemini (install: ``pip install 'text2sql-lite[llm_gemini]'``)."""

    def __init__(self, api_key: str | None = None, *, model: str = "gemini-1.5-flash") -> None:
        self._api_key = api_key
        self._model = model

    def complete(self, system: str, user: str) -> str:
        try:
            import google.generativeai as genai
        except ImportError as e:  # pragma: no cover
            raise ImportError(
                "Install the llm_gemini extra: pip install 'text2sql-lite[llm_gemini]'"
            ) from e

        genai.configure(api_key=self._api_key)  # type: ignore[attr-defined]
        m = genai.GenerativeModel(  # type: ignore[attr-defined]
            self._model,
            system_instruction=system,
        )
        response = m.generate_content(
            user,
            generation_config=genai.GenerationConfig(temperature=0),  # type: ignore[attr-defined]
        )
        text = getattr(response, "text", None)
        if not text:
            raise ValueError("No content in Gemini response")
        return str(text)
