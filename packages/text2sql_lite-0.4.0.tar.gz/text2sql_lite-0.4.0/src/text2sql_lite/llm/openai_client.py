from __future__ import annotations


class OpenAIChatClient:
    """OpenAI Chat Completions API (install: ``pip install 'text2sql-lite[llm_openai]'``)."""

    def __init__(
        self,
        api_key: str | None = None,
        *,
        model: str = "gpt-4o-mini",
        base_url: str | None = None,
    ) -> None:
        try:
            from openai import OpenAI
        except ImportError as e:  # pragma: no cover
            raise ImportError(
                "Install the llm_openai extra: pip install 'text2sql-lite[llm_openai]'"
            ) from e
        if base_url is None:
            self._client = OpenAI(api_key=api_key)
        else:
            self._client = OpenAI(api_key=api_key, base_url=base_url)
        self._model = model

    def complete(self, system: str, user: str) -> str:
        resp = self._client.chat.completions.create(
            model=self._model,
            temperature=0,
            messages=[
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
        )
        choice = resp.choices[0].message.content
        if choice is None:
            raise ValueError("No content in LLM response")
        return str(choice)
