from __future__ import annotations

from dataclasses import dataclass

from text2sql_lite.dialects import Dialect
from text2sql_lite.heuristic import try_heuristic
from text2sql_lite.llm.core import LLMClient
from text2sql_lite.schema import TableSchema, empty_schema


@dataclass(frozen=True)
class TranslateResult:
    sql: str
    source: str
    confidence: float
    notes: str


def translate(
    text: str,
    *,
    dialect: Dialect = Dialect.SQLITE,
    schema: TableSchema | None = None,
    llm_client: LLMClient | None = None,
    prefer_llm: bool = False,
) -> TranslateResult:
    """
    Convert English to SQL.

    By default uses offline heuristics. Pass ``llm_client`` (OpenAI, Gemini, or Mistral
    wrapper from ``text2sql_lite.llm``) for model-generated SQL when heuristics miss or
    when ``prefer_llm=True`` to try the model first.
    """

    sch = schema or empty_schema()

    if prefer_llm and llm_client is not None:
        from text2sql_lite.llm.core import translate_with_llm

        try:
            sql, rationale = translate_with_llm(
                text,
                dialect=dialect,
                schema=sch,
                client=llm_client,
            )
            return TranslateResult(
                sql=sql,
                source="llm",
                confidence=0.85,
                notes=rationale,
            )
        except Exception as exc:  # pragma: no cover - network / provider variability
            h = try_heuristic(text, dialect=dialect, schema=sch)
            if h:
                return TranslateResult(
                    sql=h.sql,
                    source="heuristic_fallback",
                    confidence=h.confidence * 0.9,
                    notes=f"LLM failed ({exc!s}). {h.rationale}",
                )
            raise

    h = try_heuristic(text, dialect=dialect, schema=sch)
    if h:
        return TranslateResult(
            sql=h.sql,
            source="heuristic",
            confidence=h.confidence,
            notes=h.rationale,
        )

    if llm_client is not None:
        from text2sql_lite.llm.core import translate_with_llm

        sql, rationale = translate_with_llm(
            text,
            dialect=dialect,
            schema=sch,
            client=llm_client,
        )
        return TranslateResult(sql=sql, source="llm", confidence=0.85, notes=rationale)

    raise ValueError(
        "Could not parse the request heuristically. "
        "Try a supported pattern (e.g. 'show users from texas') or pass llm_client=...."
    )
