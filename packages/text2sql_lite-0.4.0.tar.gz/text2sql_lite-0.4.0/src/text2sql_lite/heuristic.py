from __future__ import annotations

import re
from dataclasses import dataclass

from text2sql_lite.dialects import Dialect
from text2sql_lite.schema import TableSchema

_LEADING_VERB = re.compile(
    r"^\s*(?:show|list|get|find|display|select|give\s+me|fetch)\s+",
    re.IGNORECASE,
)
_LIMIT_PREFIX = re.compile(
    r"^\s*(?:(?:first|top|limit)\s+(\d+)|(\d+)\s+(?:rows?\s+)?(?:of\s+)?)",
    re.IGNORECASE,
)
_MAIN = re.compile(
    r"""
    ^\s*
    (?:(?:all|every)\s+)?
    (?P<table>[a-z_][a-z0-9_]*)
    (?:
        \s+from\s+(?P<loc>[^?]+?)
    )?
    (?:
        \s+where\s+(?P<where>.+)
    )?
    \s*\.?\s*$
    """,
    re.IGNORECASE | re.VERBOSE,
)

_GEO_COLUMNS = ("state", "region", "province", "location", "city", "country")
_SIMPLE_WHERE = re.compile(
    r"^(?P<col>[a-z_][a-z0-9_]*)\s*(?P<op>=|!=|<>|>=|<=|>|<)\s*(?P<val>.+)$",
    re.IGNORECASE,
)


@dataclass(frozen=True)
class HeuristicOutcome:
    sql: str
    confidence: float
    rationale: str


def _strip_quotes(s: str) -> str:
    s = s.strip().rstrip(".")
    if (s.startswith("'") and s.endswith("'")) or (s.startswith('"') and s.endswith('"')):
        return s[1:-1]
    return s


def _pick_geo_column(schema: TableSchema, table: str) -> str | None:
    t = schema.table_by_name_ci(table)
    if not t or not t.columns:
        return "state"
    names = {c.name.lower(): c.name for c in t.columns}
    for candidate in _GEO_COLUMNS:
        if candidate in names:
            return names[candidate]
    return None


def _literal_sql(value: str, dialect: Dialect) -> str:
    v = value.replace("'", "''")
    return f"'{v}'"


def _format_ident(name: str, dialect: Dialect) -> str:
    return dialect.quote_ident(name)


def try_heuristic(
    text: str,
    *,
    dialect: Dialect,
    schema: TableSchema,
) -> HeuristicOutcome | None:
    s = text.strip()
    if not s or "?" in s:
        return None

    s = _LEADING_VERB.sub("", s)
    s = s.strip()

    limit: int | None = None
    lim_m = _LIMIT_PREFIX.match(s)
    if lim_m:
        g = lim_m.group(1) or lim_m.group(2)
        if g:
            limit = int(g)
        s = s[lim_m.end() :].strip()

    m = _MAIN.match(s)
    if not m:
        return None

    table_raw = m.group("table")
    loc_raw = (m.group("loc") or "").strip() or None
    where_raw = (m.group("where") or "").strip() or None

    table_sql = _format_ident(table_raw, dialect)

    parts = [f"SELECT * FROM {table_sql}"]
    rationale_parts: list[str] = []

    if where_raw:
        sw = _SIMPLE_WHERE.match(where_raw)
        if not sw:
            return None
        col = sw.group("col")
        op = sw.group("op")
        val = _strip_quotes(sw.group("val"))
        col_sql = _format_ident(col, dialect)
        parts.append(f"WHERE {col_sql} {op} {_literal_sql(val, dialect)}")
        rationale_parts.append("Parsed explicit WHERE clause.")

    elif loc_raw:
        geo = _pick_geo_column(schema, table_raw)
        if not geo:
            return None
        col_sql = _format_ident(geo, dialect)
        loc_val = _strip_quotes(loc_raw)
        if dialect == Dialect.POSTGRES:
            parts.append(
                f"WHERE {col_sql} ILIKE {_literal_sql(loc_val, dialect)} "
                f"OR {col_sql} ILIKE {_literal_sql(loc_val.title(), dialect)}"
            )
        elif dialect == Dialect.MYSQL:
            lit1 = _literal_sql(loc_val, dialect)
            lit2 = _literal_sql(loc_val.title(), dialect)
            parts.append(
                f"WHERE LOWER({col_sql}) LIKE LOWER(CONCAT('%', {lit1}, '%')) "
                f"OR LOWER({col_sql}) LIKE LOWER(CONCAT('%', {lit2}, '%'))"
            )
        else:
            parts.append(
                f"WHERE {col_sql} LIKE {_literal_sql(loc_val, dialect)} "
                f"OR {col_sql} LIKE {_literal_sql(loc_val.title(), dialect)}"
            )
        rationale_parts.append(
            f"Interpreted 'from {loc_raw}' as a filter on {geo} (heuristic)."
        )
    else:
        rationale_parts.append("No filter; returning all rows (heuristic).")

    sql_body = " ".join(parts)
    if limit is not None:
        sql = f"{sql_body} LIMIT {limit}"
        rationale_parts.append(f"Applied LIMIT {limit}.")
    else:
        sql = sql_body

    conf = 0.55
    if schema.table_by_name_ci(table_raw):
        conf += 0.2
    if where_raw or (loc_raw and _pick_geo_column(schema, table_raw)):
        conf += 0.1
    conf = min(conf, 0.95)

    return HeuristicOutcome(
        sql=sql + ";",
        confidence=conf,
        rationale=" ".join(rationale_parts),
    )
