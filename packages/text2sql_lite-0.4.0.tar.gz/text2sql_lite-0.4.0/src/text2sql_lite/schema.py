from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Column:
    name: str
    type_hint: str | None = None


@dataclass(frozen=True)
class Table:
    name: str
    columns: tuple[Column, ...] = ()

    def column_names(self) -> frozenset[str]:
        return frozenset(c.name for c in self.columns)


@dataclass(frozen=True)
class TableSchema:
    """Known tables/columns used to ground heuristics."""

    tables: tuple[Table, ...] = ()

    def table_by_name_ci(self, name: str) -> Table | None:
        n = name.lower()
        for t in self.tables:
            if t.name.lower() == n:
                return t
        return None

    def as_compact_ddl(self) -> str:
        lines: list[str] = []
        for t in self.tables:
            cols = ", ".join(c.name for c in t.columns) if t.columns else "*"
            lines.append(f"{t.name}({cols})")
        return "; ".join(lines)


def empty_schema() -> TableSchema:
    return TableSchema(())
