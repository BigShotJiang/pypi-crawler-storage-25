from text2sql_lite.dialects import Dialect


def test_quote_ident_mysql_backticks() -> None:
    assert Dialect.MYSQL.quote_ident("users") == "`users`"
    assert Dialect.MYSQL.quote_ident("a`b") == "`a``b`"


def test_quote_ident_postgres_double_quotes() -> None:
    assert Dialect.POSTGRES.quote_ident('u"sers') == '"u""sers"'
