import tempfile

from text2sql_lite.introspect import introspect_sqlite
from text2sql_lite.schema import TableSchema


def test_introspect_sqlite_reads_schema() -> None:
    with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
        path = f.name
    try:
        import sqlite3

        con = sqlite3.connect(path)
        con.execute("CREATE TABLE users (id INTEGER PRIMARY KEY, state TEXT)")
        con.commit()
        con.close()

        schema = introspect_sqlite(path)
        assert isinstance(schema, TableSchema)
        t = schema.table_by_name_ci("users")
        assert t is not None
        names = {c.name for c in t.columns}
        assert "state" in names
    finally:
        import os

        os.unlink(path)
