import pytest

from text2sql_lite import Dialect, translate
from text2sql_lite.schema import Column, Table, TableSchema


def test_translate_heuristic() -> None:
    r = translate("show users from texas", dialect=Dialect.SQLITE)
    assert r.source == "heuristic"
    assert "users" in r.sql.lower()


def test_translate_raises_when_unsupported() -> None:
    schema = TableSchema((Table("users", (Column("email"),)),))
    with pytest.raises(ValueError):
        translate("show users from texas", dialect=Dialect.SQLITE, schema=schema)


class _FakeLLM:
    def complete(self, system: str, user: str) -> str:
        return "SELECT email FROM users WHERE state = 'TX';\nUses state filter."


def test_translate_llm_when_heuristic_fails() -> None:
    schema = TableSchema((Table("users", (Column("email"),)),))
    r = translate(
        "show users from texas",
        dialect=Dialect.SQLITE,
        schema=schema,
        llm_client=_FakeLLM(),
    )
    assert r.source == "llm"
    assert "select" in r.sql.lower()


class _BrokenLLM:
    def complete(self, system: str, user: str) -> str:
        raise RuntimeError("network down")


def test_translate_prefer_llm_fallback_to_heuristic() -> None:
    r = translate(
        "show users from texas",
        dialect=Dialect.SQLITE,
        prefer_llm=True,
        llm_client=_BrokenLLM(),
    )
    assert r.source == "heuristic_fallback"
    assert "users" in r.sql.lower()


def test_translate_prefer_llm_success() -> None:
    r = translate(
        "emails for active customers last quarter",
        dialect=Dialect.POSTGRES,
        prefer_llm=True,
        llm_client=_FakeLLM(),
    )
    assert r.source == "llm"
