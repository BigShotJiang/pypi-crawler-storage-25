import pytest

from text2sql_lite.dialects import Dialect
from text2sql_lite.heuristic import try_heuristic
from text2sql_lite.schema import Column, Table, TableSchema, empty_schema


def test_show_users_from_texas_postgres() -> None:
    schema = TableSchema((Table("users", (Column("state"), Column("email"))),))
    out = try_heuristic("show users from texas", dialect=Dialect.POSTGRES, schema=schema)
    assert out is not None
    assert "users" in out.sql.lower()
    assert "state" in out.sql.lower()
    assert "ilike" in out.sql.lower()
    assert out.sql.strip().endswith(";")


def test_show_users_from_texas_sqlite_backticks() -> None:
    out = try_heuristic("show users from texas", dialect=Dialect.SQLITE, schema=empty_schema())
    assert out is not None
    assert "`users`" in out.sql
    assert "like" in out.sql.lower()


def test_show_users_from_texas_mysql_case_insensitive() -> None:
    schema = TableSchema((Table("users", (Column("state"), Column("email"))),))
    out = try_heuristic("show users from texas", dialect=Dialect.MYSQL, schema=schema)
    assert out is not None
    assert "`users`" in out.sql
    assert "lower(`state`)" in out.sql.lower()
    assert "concat('%'" in out.sql.lower()


def test_limit_prefix() -> None:
    schema = TableSchema((Table("orders", (Column("id"),)),))
    out = try_heuristic("show first 10 orders", dialect=Dialect.SQLITE, schema=schema)
    assert out is not None
    assert "limit 10" in out.sql.lower()


def test_simple_where() -> None:
    schema = TableSchema((Table("users", (Column("age"),)),))
    out = try_heuristic(
        "show users where age > 30", dialect=Dialect.POSTGRES, schema=schema
    )
    assert out is not None
    assert ">" in out.sql
    assert "30" in out.sql


def test_unknown_geo_column_returns_none_when_schema_contradicts() -> None:
    schema = TableSchema((Table("users", (Column("email"),)),))
    out = try_heuristic("show users from texas", dialect=Dialect.SQLITE, schema=schema)
    assert out is None


@pytest.mark.parametrize(
    "phrase",
    [
        "show users from texas",
        "List users from Texas.",
        "get users from texas",
    ],
)
def test_case_insensitive_phrases(phrase: str) -> None:
    out = try_heuristic(phrase, dialect=Dialect.SQLITE, schema=empty_schema())
    assert out is not None
