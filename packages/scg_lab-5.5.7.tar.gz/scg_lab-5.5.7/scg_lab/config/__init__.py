"""Config package init."""

from scg_lab.config.settings import Settings

__all__ = ["Settings"]
