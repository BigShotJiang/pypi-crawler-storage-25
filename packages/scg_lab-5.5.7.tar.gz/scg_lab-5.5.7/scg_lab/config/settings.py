"""Settings — reads/writes ~/.scglab/config.json.

Keys use dot-notation: 'ai.provider', 'ai.openai_key', etc.
"""

import json
import os
from pathlib import Path
from typing import Any


_KEY_MASK = {"openai_key", "anthropic_key", "hf_token", "api_key"}


def _config_dir() -> Path:
    d = Path.home() / ".scglab"
    d.mkdir(mode=0o700, exist_ok=True)
    return d


class Settings:
    """Persistent settings for SCG Lab."""

    def __init__(self):
        self._path = _config_dir() / "config.json"
        self._data: dict = self._load()

    def _load(self) -> dict:
        if self._path.exists():
            with open(self._path, "r", encoding="utf-8") as f:
                return json.load(f)
        return {}

    def _save(self) -> None:
        with open(self._path, "w", encoding="utf-8") as f:
            json.dump(self._data, f, indent=2)
        if os.name != "nt":
            os.chmod(self._path, 0o600)

    def get(self, key: str, default: Any = None) -> Any:
        """Get a setting value. Supports dot-notation: 'ai.provider'."""
        parts = key.split(".")
        node = self._data
        for p in parts:
            if not isinstance(node, dict):
                return default
            node = node.get(p)
            if node is None:
                return default
        return node

    def set(self, key: str, value: Any) -> None:
        """Set a setting value. Supports dot-notation: 'ai.openai_key'."""
        parts = key.split(".")
        node = self._data
        for p in parts[:-1]:
            node = node.setdefault(p, {})
        node[parts[-1]] = value
        self._save()

    def show(self) -> dict:
        """Return settings dict with sensitive keys masked."""
        import copy
        masked = copy.deepcopy(self._data)
        self._mask(masked)
        return masked

    def _mask(self, obj: Any) -> None:
        if isinstance(obj, dict):
            for k, v in obj.items():
                if k in _KEY_MASK and isinstance(v, str) and v:
                    obj[k] = v[:4] + "****"
                else:
                    self._mask(v)

    def all(self) -> dict:
        """Return raw settings (use show() for user-facing display)."""
        return self._data
