"""REST API for kernel management."""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from scg_lab.kernel.manager import kernel_manager

router = APIRouter(prefix="/kernels", tags=["kernels"])


class StartKernelRequest(BaseModel):
    lang: str = "python"
    env_path: str | None = None


@router.get("")
async def list_kernels():
    return {"kernels": kernel_manager.list_kernels()}


@router.post("")
async def start_kernel(body: StartKernelRequest):
    try:
        kernel = await kernel_manager.create_kernel(lang=body.lang, env_path=body.env_path)
    except (ValueError, RuntimeError) as e:
        raise HTTPException(status_code=400, detail=str(e))
    return {"id": kernel.kernel_id, "lang": kernel.lang, "status": kernel.status}


@router.get("/{kernel_id}")
async def get_kernel(kernel_id: str):
    k = kernel_manager.get_kernel(kernel_id)
    if not k:
        raise HTTPException(status_code=404, detail="Kernel not found")
    return {"id": k.kernel_id, "lang": k.lang, "status": k.status}


@router.delete("/{kernel_id}")
async def shutdown_kernel(kernel_id: str):
    ok = await kernel_manager.shutdown_kernel(kernel_id)
    if not ok:
        raise HTTPException(status_code=404, detail="Kernel not found")
    return {"status": "shutdown"}
