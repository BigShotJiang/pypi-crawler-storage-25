"""REST API for notebook sessions (kernel + notebook file pairing)."""

import uuid
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from scg_lab.kernel.manager import kernel_manager

router = APIRouter(prefix="/sessions", tags=["sessions"])

# In-memory session store (could persist to disk later)
_sessions: dict[str, dict] = {}


class CreateSessionRequest(BaseModel):
    notebook_path: str = "Untitled.ipynb"
    lang: str = "python"
    env_path: str | None = None


@router.get("")
async def list_sessions():
    return {"sessions": list(_sessions.values())}


@router.post("")
async def create_session(body: CreateSessionRequest):
    kernel = await kernel_manager.create_kernel(lang=body.lang, env_path=body.env_path)
    session_id = str(uuid.uuid4())
    session = {
        "id": session_id,
        "notebook_path": body.notebook_path,
        "kernel": {"id": kernel.kernel_id, "lang": kernel.lang},
    }
    _sessions[session_id] = session
    return session


@router.get("/{session_id}")
async def get_session(session_id: str):
    session = _sessions.get(session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    return session


@router.delete("/{session_id}")
async def delete_session(session_id: str):
    session = _sessions.pop(session_id, None)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    await kernel_manager.shutdown_kernel(session["kernel"]["id"])
    return {"status": "deleted"}
