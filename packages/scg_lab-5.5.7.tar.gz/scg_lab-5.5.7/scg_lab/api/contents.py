"""REST API for file system contents (notebooks, scripts, files)."""

import json
import os
from pathlib import Path

from fastapi import APIRouter, HTTPException
from fastapi.responses import JSONResponse
from pydantic import BaseModel

router = APIRouter(prefix="/contents", tags=["contents"])

# Root directory for file access — current working directory of the server
_WORKSPACE_ROOT = Path.cwd()


def _safe_path(rel: str) -> Path:
    """Resolve a relative path safely within the workspace root.

    Uses Path.relative_to() so that a path like '/workspace-other/secret'
    is correctly rejected even though it starts with '/workspace' as a string.
    """
    root = _WORKSPACE_ROOT.resolve()
    target = (root / rel).resolve()
    try:
        target.relative_to(root)
    except ValueError:
        raise HTTPException(status_code=403, detail="Path outside workspace")
    return target


@router.get("/{path:path}")
async def get_contents(path: str = ""):
    target = _safe_path(path)

    if target.is_dir():
        items = []
        for child in sorted(target.iterdir()):
            items.append({
                "name": child.name,
                "path": str(child.relative_to(_WORKSPACE_ROOT)),
                "type": "directory" if child.is_dir() else "file",
            })
        return {"type": "directory", "path": path, "content": items}

    if target.is_file():
        try:
            text = target.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            raise HTTPException(status_code=400, detail="Binary files not supported")

        if target.suffix == ".ipynb":
            try:
                return {"type": "notebook", "path": path, "content": json.loads(text)}
            except json.JSONDecodeError:
                pass

        return {"type": "file", "path": path, "content": text}

    raise HTTPException(status_code=404, detail="Path not found")


class SaveRequest(BaseModel):
    content: str | dict
    type: str = "file"   # "file" | "notebook"


@router.put("/{path:path}")
async def save_contents(path: str, body: SaveRequest):
    target = _safe_path(path)
    target.parent.mkdir(parents=True, exist_ok=True)

    if body.type == "notebook":
        content = json.dumps(body.content, indent=2) if isinstance(body.content, dict) else body.content
    else:
        content = body.content if isinstance(body.content, str) else json.dumps(body.content)

    target.write_text(content, encoding="utf-8")
    return {"status": "saved", "path": path}


@router.delete("/{path:path}")
async def delete_contents(path: str):
    target = _safe_path(path)
    if not target.exists():
        raise HTTPException(status_code=404, detail="Path not found")
    if target.is_dir():
        import shutil
        shutil.rmtree(target)
    else:
        target.unlink()
    return {"status": "deleted", "path": path}
