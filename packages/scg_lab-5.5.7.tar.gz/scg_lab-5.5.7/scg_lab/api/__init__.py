"""API package init — exports all routers."""

from scg_lab.api.kernels import router as kernels_router
from scg_lab.api.sessions import router as sessions_router
from scg_lab.api.contents import router as contents_router
from scg_lab.api.environments import router as environments_router

__all__ = [
    "kernels_router",
    "sessions_router",
    "contents_router",
    "environments_router",
]
