"""REST API for environment management."""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from scg_lab.env.registry import EnvironmentRegistry
from scg_lab.env.python_env import create_python_env, install_packages
from scg_lab.env.detector import detect_all
from pathlib import Path

router = APIRouter(prefix="/environments", tags=["environments"])


def _registry() -> EnvironmentRegistry:
    return EnvironmentRegistry()


class CreateEnvRequest(BaseModel):
    name: str
    lang: str = "python"
    packages: list[str] = []


class InstallRequest(BaseModel):
    packages: list[str]


@router.get("")
async def list_envs():
    return {"environments": _registry().list_envs()}


@router.get("/detect")
async def detect_runtimes():
    """Detect all installed language runtimes on the system."""
    return detect_all()


@router.post("")
async def create_env(body: CreateEnvRequest):
    reg = _registry()
    if reg.get_env(body.name):
        raise HTTPException(status_code=409, detail=f"Environment '{body.name}' already exists")

    if body.lang != "python":
        raise HTTPException(status_code=400,
                            detail=f"Creating managed environments for '{body.lang}' is not yet supported. "
                                   "Use the system runtime for this language.")

    try:
        env_path = create_python_env(body.name)
        if body.packages:
            install_packages(env_path, body.packages)
        reg.register(body.name, body.lang, str(env_path))
    except FileExistsError as e:
        raise HTTPException(status_code=409, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

    return {"name": body.name, "lang": body.lang, "path": str(env_path)}


@router.post("/{name}/install")
async def install_env_packages(name: str, body: InstallRequest):
    reg = _registry()
    env = reg.get_env(name)
    if not env:
        raise HTTPException(status_code=404, detail=f"Environment '{name}' not found")

    try:
        install_packages(Path(env["path"]), body.packages)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

    return {"status": "installed", "packages": body.packages}


@router.post("/{name}/activate")
async def activate_env(name: str):
    reg = _registry()
    try:
        reg.set_active(name)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    return {"status": "activated", "name": name}


@router.delete("/{name}")
async def delete_env(name: str):
    reg = _registry()
    env = reg.get_env(name)
    if not env:
        raise HTTPException(status_code=404, detail=f"Environment '{name}' not found")

    import shutil, os
    env_path = Path(env["path"])
    if env_path.exists():
        shutil.rmtree(env_path, ignore_errors=True)

    reg.delete(name)
    return {"status": "deleted", "name": name}
