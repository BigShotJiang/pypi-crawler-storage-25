"""Python kernel — uses ipykernel via jupyter-client (ZMQ-based, full Jupyter protocol)."""

import asyncio
import uuid
from typing import AsyncIterator

import jupyter_client
from jupyter_client.asynchronous import AsyncKernelClient

from scg_lab.kernel.base import BaseKernel, KernelMessage


class PythonKernel(BaseKernel):
    """Python kernel backed by ipykernel over ZMQ (full Jupyter Messaging Protocol)."""

    def __init__(self, kernel_id: str, env_path: str | None = None):
        super().__init__(kernel_id=kernel_id, lang="python")
        self._manager: jupyter_client.AsyncKernelManager | None = None
        self._client: AsyncKernelClient | None = None
        self._env_path = env_path

    async def start(self) -> None:
        """Start the ipykernel process."""
        km = jupyter_client.AsyncKernelManager(kernel_name="python3")

        if self._env_path:
            # Override python executable with environment-specific one.
            # kernel_cmd replaces kernel_spec.argv; jupyter-client substitutes
            # the {connection_file} placeholder when launching the process.
            import os
            py = os.path.join(self._env_path, "bin", "python") \
                if os.name != "nt" \
                else os.path.join(self._env_path, "Scripts", "python.exe")
            if not os.path.exists(py):
                raise RuntimeError(
                    f"Python executable not found in environment: {py}\n"
                    "Make sure the environment path is correct."
                )
            km.kernel_cmd = [py, "-m", "ipykernel_launcher", "-f", "{connection_file}"]

        await km.start_kernel()
        self._manager = km
        self._client = km.client()
        self._client.start_channels()
        await self._client.wait_for_ready(timeout=30)
        self.status = "idle"

    async def execute(self, code: str) -> AsyncIterator[KernelMessage]:
        """Execute code and stream results back."""
        if not self._client:
            raise RuntimeError("Kernel not started. Call start() first.")

        self.status = "busy"
        msg_id = self._client.execute(code)
        idle_emitted = False

        try:
            while True:
                try:
                    msg = await asyncio.wait_for(
                        self._client.get_iopub_msg(timeout=None), timeout=30.0
                    )
                except asyncio.TimeoutError:
                    break

                msg_type = msg["msg_type"]
                content = msg["content"]
                parent_id = msg.get("parent_header", {}).get("msg_id", "")

                if parent_id != msg_id:
                    continue

                if msg_type == "stream":
                    yield KernelMessage(
                        msg_type="stream",
                        content={"name": content["name"], "text": content["text"]},
                    )
                elif msg_type == "execute_result":
                    yield KernelMessage(
                        msg_type="execute_result",
                        content={"data": content["data"], "execution_count": content["execution_count"]},
                    )
                elif msg_type == "display_data":
                    yield KernelMessage(
                        msg_type="display_data",
                        content={"data": content["data"]},
                    )
                elif msg_type == "error":
                    yield KernelMessage(
                        msg_type="error",
                        content={
                            "ename": content["ename"],
                            "evalue": content["evalue"],
                            "traceback": content["traceback"],
                        },
                    )
                elif msg_type == "status" and content.get("execution_state") == "idle":
                    self.status = "idle"
                    # Forward idle status so the frontend marks the cell done.
                    yield KernelMessage(
                        msg_type="status",
                        content={"execution_state": "idle"},
                    )
                    idle_emitted = True
                    break
        finally:
            if self.status == "busy":
                self.status = "idle"

        # Belt-and-braces: if we exited the loop without ever forwarding idle
        # (e.g. iopub timeout), emit one now so the UI never sticks at "running".
        if not idle_emitted:
            yield KernelMessage(
                msg_type="status",
                content={"execution_state": "idle"},
            )

    async def interrupt(self) -> None:
        if self._manager:
            await self._manager.interrupt_kernel()

    async def shutdown(self) -> None:
        if self._client:
            self._client.stop_channels()
        if self._manager:
            await self._manager.shutdown_kernel(now=True)
        self.status = "dead"

    async def is_complete(self, code: str) -> dict:
        if not self._client:
            return {"status": "unknown"}
        # Send is_complete_request; the returned value is the msg_id we
        # sent (used by the kernel to correlate the reply, not needed here
        # since the shell channel is not shared concurrently).
        self._client.is_complete(code)
        try:
            reply = await asyncio.wait_for(
                self._client.get_shell_msg(timeout=None), timeout=5.0
            )
            return reply.get("content", {"status": "unknown"})
        except asyncio.TimeoutError:
            return {"status": "unknown"}
