"""Subprocess-based kernel for compiled/scripted languages (JS, C, C++).

These languages don't use ZMQ — they run as subprocesses and we stream stdout/stderr.
"""

import asyncio
import os
import shutil
import tempfile
import uuid
from typing import AsyncIterator

from scg_lab.kernel.base import BaseKernel, KernelMessage

# ── Execution templates per language ─────────────────────────────────────────

EXEC_CONFIGS = {
    "javascript": {
        "runtime": "node",
        "ext": ".js",
        "build_cmd": None,              # interpreted
        "run_cmd": lambda f, _: ["node", f],
    },
    "c": {
        "runtime": "gcc",
        "ext": ".c",
        "build_cmd": lambda src, out: ["gcc", src, "-o", out, "-lm"],
        "run_cmd": lambda _, out: [out],
    },
    "cpp": {
        "runtime": "g++",
        "ext": ".cpp",
        "build_cmd": lambda src, out: ["g++", src, "-o", out, "-std=c++17"],
        "run_cmd": lambda _, out: [out],
    },
}


class SubprocessKernel(BaseKernel):
    """Kernel that executes code in a subprocess (JS, C, C++)."""

    def __init__(self, kernel_id: str, lang: str):
        if lang not in EXEC_CONFIGS:
            raise ValueError(f"Unsupported language for SubprocessKernel: {lang}")
        super().__init__(kernel_id=kernel_id, lang=lang)
        self._config = EXEC_CONFIGS[lang]
        self._proc: asyncio.subprocess.Process | None = None

    async def start(self) -> None:
        """Check that the runtime is available."""
        runtime = self._config["runtime"]
        if not shutil.which(runtime):
            raise RuntimeError(
                f"Runtime '{runtime}' not found. "
                f"Please install it and make sure it is on your PATH."
            )
        self.status = "idle"

    async def execute(self, code: str) -> AsyncIterator[KernelMessage]:
        """Write code to a temp file, compile if needed, run and stream output."""
        self.status = "busy"
        config = self._config
        tmpdir = tempfile.mkdtemp(prefix="scglab_")

        try:
            # Write source file
            src_file = os.path.join(tmpdir, f"code{config['ext']}")
            with open(src_file, "w", encoding="utf-8") as f:
                f.write(code)

            out_file = os.path.join(tmpdir, "out")

            # Compile step (C / C++)
            if config["build_cmd"]:
                build_cmd = config["build_cmd"](src_file, out_file)
                compile_result = await asyncio.create_subprocess_exec(
                    *build_cmd,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )
                _, stderr = await compile_result.communicate()
                if compile_result.returncode != 0:
                    yield KernelMessage(
                        msg_type="error",
                        content={
                            "ename": "CompilationError",
                            "evalue": stderr.decode(),
                            "traceback": [],
                        },
                    )
                    self.status = "idle"
                    return

            # Run step
            run_cmd = config["run_cmd"](src_file, out_file)
            proc = await asyncio.create_subprocess_exec(
                *run_cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=tmpdir,
            )
            self._proc = proc

            # Read stdout and stderr concurrently to prevent pipe-buffer deadlock.
            # If we read stdout line-by-line while ignoring stderr, a process that
            # writes heavily to stderr will block (full buffer), stalling stdout too.
            stdout_data, stderr_data = await asyncio.gather(
                proc.stdout.read(),
                proc.stderr.read(),
            )
            await proc.wait()

            if stdout_data:
                for line in stdout_data.splitlines(keepends=True):
                    yield KernelMessage(
                        msg_type="stream",
                        content={"name": "stdout", "text": line.decode()},
                    )

            if stderr_data:
                yield KernelMessage(
                    msg_type="stream",
                    content={"name": "stderr", "text": stderr_data.decode()},
                )

            yield KernelMessage(
                msg_type="status",
                content={"execution_state": "idle"},
            )

        finally:
            import shutil as _shutil
            _shutil.rmtree(tmpdir, ignore_errors=True)
            self.status = "idle"
            self._proc = None

    async def interrupt(self) -> None:
        if self._proc and self._proc.returncode is None:
            self._proc.terminate()

    async def shutdown(self) -> None:
        await self.interrupt()
        self.status = "dead"

    async def is_complete(self, code: str) -> dict:
        return {"status": "complete"}
