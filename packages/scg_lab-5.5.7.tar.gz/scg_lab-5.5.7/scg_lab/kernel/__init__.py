"""Kernel package init."""

from scg_lab.kernel.manager import kernel_manager

__all__ = ["kernel_manager"]
