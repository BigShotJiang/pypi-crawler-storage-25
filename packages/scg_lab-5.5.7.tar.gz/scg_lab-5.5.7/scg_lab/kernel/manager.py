"""Kernel Manager — create, track, route, and destroy kernels."""

import uuid
from typing import Optional

from scg_lab.kernel.base import BaseKernel

# Supported languages → kernel class
_LANGUAGE_MAP: dict[str, str] = {
    "python":     "python",
    "javascript": "subprocess",
    "js":         "subprocess",
    "c":          "subprocess",
    "cpp":        "subprocess",
    "c++":        "subprocess",
}


def _make_kernel(lang: str, kernel_id: str, env_path: str | None = None) -> BaseKernel:
    """Factory: create the right kernel instance for a language."""
    lang_key = lang.lower()
    kernel_type = _LANGUAGE_MAP.get(lang_key)

    if kernel_type == "python":
        from scg_lab.kernel.python_kernel import PythonKernel
        return PythonKernel(kernel_id=kernel_id, env_path=env_path)

    elif kernel_type == "subprocess":
        from scg_lab.kernel.subprocess_kernel import SubprocessKernel
        # Normalize lang name
        normalized = {"js": "javascript", "c++": "cpp"}.get(lang_key, lang_key)
        return SubprocessKernel(kernel_id=kernel_id, lang=normalized)

    else:
        raise ValueError(f"Unsupported language: '{lang}'. Supported: {list(_LANGUAGE_MAP.keys())}")


class KernelManager:
    """Manages the lifecycle of all active kernels."""

    def __init__(self):
        self._kernels: dict[str, BaseKernel] = {}

    async def create_kernel(self, lang: str = "python", env_path: str | None = None) -> BaseKernel:
        """Create and start a new kernel."""
        kernel_id = str(uuid.uuid4())
        kernel = _make_kernel(lang=lang, kernel_id=kernel_id, env_path=env_path)
        await kernel.start()
        self._kernels[kernel_id] = kernel
        return kernel

    def get_kernel(self, kernel_id: str) -> Optional[BaseKernel]:
        """Get an existing kernel by ID."""
        return self._kernels.get(kernel_id)

    def list_kernels(self) -> list[dict]:
        """List all running kernels."""
        return [
            {
                "id": k.kernel_id,
                "lang": k.lang,
                "status": k.status,
            }
            for k in self._kernels.values()
        ]

    async def shutdown_kernel(self, kernel_id: str) -> bool:
        """Shut down a kernel by ID."""
        kernel = self._kernels.pop(kernel_id, None)
        if kernel:
            await kernel.shutdown()
            return True
        return False

    async def shutdown_all(self) -> None:
        """Shut down all running kernels."""
        for kernel in list(self._kernels.values()):
            await kernel.shutdown()
        self._kernels.clear()


# Module-level singleton — shared across the app
kernel_manager = KernelManager()
