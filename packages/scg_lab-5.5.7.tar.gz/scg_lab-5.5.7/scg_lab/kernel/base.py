"""Kernel base class — all language kernels implement this interface."""

from abc import ABC, abstractmethod
from typing import AsyncIterator
import uuid


class KernelMessage:
    """A message flowing between frontend and kernel."""

    def __init__(self, msg_type: str, content: dict, msg_id: str | None = None):
        self.msg_id = msg_id or str(uuid.uuid4())
        self.msg_type = msg_type
        self.content = content

    def to_dict(self) -> dict:
        return {
            "msg_id": self.msg_id,
            "msg_type": self.msg_type,
            "content": self.content,
        }


class BaseKernel(ABC):
    """Abstract base kernel. All language kernels extend this."""

    def __init__(self, kernel_id: str, lang: str):
        self.kernel_id = kernel_id
        self.lang = lang
        self.status = "starting"  # starting | idle | busy | dead

    @abstractmethod
    async def start(self) -> None:
        """Start the kernel process."""

    @abstractmethod
    async def execute(self, code: str) -> AsyncIterator[KernelMessage]:
        """Execute code and yield output messages."""

    @abstractmethod
    async def interrupt(self) -> None:
        """Interrupt running execution."""

    @abstractmethod
    async def shutdown(self) -> None:
        """Shut down the kernel cleanly."""

    @abstractmethod
    async def is_complete(self, code: str) -> dict:
        """Check if code is complete (for multi-line input)."""
