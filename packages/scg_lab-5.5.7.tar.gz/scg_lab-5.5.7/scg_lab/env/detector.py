"""Environment detection — find Python, R, Node, Go on the system."""

import os
import shutil
import subprocess
import sys
from pathlib import Path


def detect_python() -> list[dict]:
    """Detect available Python installations."""
    found = []
    candidates = ["python3", "python", "python3.12", "python3.11", "python3.10"]
    seen = set()

    for cmd in candidates:
        path = shutil.which(cmd)
        if path and path not in seen:
            seen.add(path)
            try:
                result = subprocess.run([path, "--version"], capture_output=True, text=True, timeout=5)
                version = result.stdout.strip() or result.stderr.strip()
                found.append({"runtime": "python", "path": path, "version": version})
            except Exception:
                pass

    # Also check VIRTUAL_ENV
    venv = os.environ.get("VIRTUAL_ENV")
    if venv:
        py = os.path.join(venv, "bin", "python") if os.name != "nt" \
            else os.path.join(venv, "Scripts", "python.exe")
        if os.path.exists(py) and py not in seen:
            found.append({"runtime": "python", "path": py, "version": "venv", "active_venv": True})

    return found


def detect_r() -> list[dict]:
    """Detect R installation."""
    found = []
    for cmd in ["Rscript", "R"]:
        path = shutil.which(cmd)
        if path:
            try:
                result = subprocess.run([path, "--version"], capture_output=True, text=True, timeout=5)
                version = result.stdout.split("\n")[0] if result.stdout else "R"
                found.append({"runtime": "r", "path": path, "version": version})
                break
            except Exception:
                pass
    return found


def detect_node() -> list[dict]:
    """Detect Node.js installation."""
    found = []
    path = shutil.which("node")
    if path:
        try:
            result = subprocess.run(["node", "--version"], capture_output=True, text=True, timeout=5)
            found.append({"runtime": "javascript", "path": path, "version": result.stdout.strip()})
        except Exception:
            pass
    return found


def detect_go() -> list[dict]:
    """Detect Go installation."""
    found = []
    path = shutil.which("go")
    if path:
        try:
            result = subprocess.run(["go", "version"], capture_output=True, text=True, timeout=5)
            found.append({"runtime": "go", "path": path, "version": result.stdout.strip()})
        except Exception:
            pass
    return found


def detect_c_cpp() -> list[dict]:
    """Detect C/C++ compilers."""
    found = []
    for compiler, lang in [("gcc", "c"), ("g++", "cpp"), ("cc", "c"), ("c++", "cpp")]:
        path = shutil.which(compiler)
        if path:
            try:
                result = subprocess.run([path, "--version"], capture_output=True, text=True, timeout=5)
                version = result.stdout.split("\n")[0]
                found.append({"runtime": lang, "path": path, "version": version, "compiler": compiler})
            except Exception:
                pass
    return found


def detect_all() -> dict:
    """Detect all available language runtimes on the system."""
    return {
        "python":     detect_python(),
        "r":          detect_r(),
        "javascript": detect_node(),
        "go":         detect_go(),
        "c":          detect_c_cpp(),
    }
