"""Python environment creation and management (venv + optional conda)."""

import os
import subprocess
import sys
import venv
from pathlib import Path


def _envs_dir() -> Path:
    """Return the directory where SCG Lab stores managed environments."""
    d = Path.home() / ".scglab" / "envs"
    d.mkdir(parents=True, exist_ok=True)
    return d


def create_python_env(name: str) -> Path:
    """Create a Python venv at ~/.scglab/envs/<name>."""
    env_path = _envs_dir() / name

    if env_path.exists():
        raise FileExistsError(f"Environment '{name}' already exists at {env_path}")

    venv.create(str(env_path), with_pip=True, clear=False)

    # Upgrade pip inside the new venv
    pip = _pip_exe(env_path)
    subprocess.run([str(pip), "install", "--upgrade", "pip"], check=True, capture_output=True)

    return env_path


def install_packages(env_path: Path, packages: list[str]) -> None:
    """Install packages into a venv using its pip."""
    pip = _pip_exe(env_path)
    subprocess.run([str(pip), "install"] + packages, check=True)


def list_packages(env_path: Path) -> list[dict]:
    """Return list of installed packages in a venv."""
    pip = _pip_exe(env_path)
    result = subprocess.run(
        [str(pip), "list", "--format=json"],
        capture_output=True, text=True, check=True
    )
    import json
    return json.loads(result.stdout)


def _pip_exe(env_path: Path) -> Path:
    if os.name == "nt":
        return env_path / "Scripts" / "pip.exe"
    return env_path / "bin" / "pip"


def python_exe(env_path: Path) -> Path:
    if os.name == "nt":
        return env_path / "Scripts" / "python.exe"
    return env_path / "bin" / "python"
