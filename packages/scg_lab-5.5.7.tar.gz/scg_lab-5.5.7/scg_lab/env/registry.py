"""Environment registry — stores and retrieves registered environments."""

import json
import os
from pathlib import Path
from typing import Optional


def _config_dir() -> Path:
    """Return ~/.scglab config directory, creating it if needed."""
    d = Path.home() / ".scglab"
    d.mkdir(mode=0o700, exist_ok=True)
    return d


class EnvironmentRegistry:
    """Reads/writes the environment registry at ~/.scglab/envs.json."""

    def __init__(self):
        self._path = _config_dir() / "envs.json"
        self._data = self._load()

    def _load(self) -> dict:
        if self._path.exists():
            with open(self._path, "r", encoding="utf-8") as f:
                return json.load(f)
        return {"active": None, "envs": {}}

    def _save(self) -> None:
        with open(self._path, "w", encoding="utf-8") as f:
            json.dump(self._data, f, indent=2)
        # Restrict permissions on Unix
        if os.name != "nt":
            os.chmod(self._path, 0o600)

    def register(self, name: str, lang: str, path: str) -> None:
        """Register a new environment."""
        self._data["envs"][name] = {"name": name, "lang": lang, "path": path}
        if not self._data["active"]:
            self._data["active"] = name
        self._save()

    def get_env(self, name: str) -> Optional[dict]:
        return self._data["envs"].get(name)

    def get_active(self) -> Optional[dict]:
        active = self._data.get("active")
        if active:
            return self._data["envs"].get(active)
        return None

    def set_active(self, name: str) -> None:
        if name not in self._data["envs"]:
            raise ValueError(f"Environment '{name}' not found in registry.")
        self._data["active"] = name
        self._save()

    def list_envs(self) -> list[dict]:
        active = self._data.get("active")
        result = []
        for name, env in self._data["envs"].items():
            result.append({**env, "active": name == active})
        return result

    def delete(self, name: str) -> None:
        self._data["envs"].pop(name, None)
        if self._data["active"] == name:
            remaining = list(self._data["envs"].keys())
            self._data["active"] = remaining[0] if remaining else None
        self._save()
