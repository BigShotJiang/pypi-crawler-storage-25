"""Entry point for python -m scg_lab."""

from scg_lab.cli import main

if __name__ == "__main__":
    main()
