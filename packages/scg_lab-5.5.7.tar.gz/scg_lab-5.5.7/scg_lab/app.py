"""SCG Lab FastAPI application."""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
import os
from pathlib import Path

from scg_lab.api.kernels import router as kernels_router
from scg_lab.api.sessions import router as sessions_router
from scg_lab.api.contents import router as contents_router
from scg_lab.api.environments import router as envs_router


def create_app() -> FastAPI:
    """Create and configure the SCG Lab FastAPI application."""

    app = FastAPI(
        title="SCG Lab",
        description="Multi-language interactive notebook environment",
        version="5.5.7",
        docs_url="/api/docs",
        redoc_url=None,
    )

    # CORS — localhost only for security
    # allow_origin_regex covers any port; explicit origins listed as fallback.
    app.add_middleware(
        CORSMiddleware,
        allow_origins=[
            "http://localhost",
            "http://localhost:5173",   # Vite dev server
            "http://localhost:8765",   # SCG Lab default port
            "http://127.0.0.1",
            "http://127.0.0.1:5173",
            "http://127.0.0.1:8765",
        ],
        allow_origin_regex=r"http://(localhost|127\.0\.0\.1)(:\d+)?",
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # API routes
    app.include_router(kernels_router, prefix="/api")
    app.include_router(sessions_router, prefix="/api")
    app.include_router(contents_router, prefix="/api")
    app.include_router(envs_router, prefix="/api")

    # WebSocket kernel endpoint
    from fastapi import WebSocket
    from scg_lab.ws.kernel_ws import kernel_ws_handler

    @app.websocket("/ws/kernels/{kernel_id}")
    async def ws_kernel(websocket: WebSocket, kernel_id: str):
        await kernel_ws_handler(websocket, kernel_id)

    # Health check
    @app.get("/api/health")
    async def health():
        return {"status": "ok", "app": "SCG Lab", "version": "5.5.7"}

    # Serve built frontend (static files)
    static_dir = Path(__file__).parent / "static"
    if static_dir.exists():
        # Serve index.html for SPA routes (must be before the static mount)
        @app.get("/")
        async def serve_root():
            return FileResponse(str(static_dir / "index.html"))

        @app.get("/{full_path:path}")
        async def serve_spa(full_path: str):
            """Serve static assets, or fall back to index.html for SPA routes."""
            # Try to serve the file directly
            requested = static_dir / full_path
            if requested.exists() and requested.is_file():
                return FileResponse(str(requested))
            # Fall back to SPA index for client-side routing
            index = static_dir / "index.html"
            if index.exists():
                return FileResponse(str(index))
            return {"message": "SCG Lab frontend not built yet. Run: cd frontend && npm run build"}
    else:
        @app.get("/")
        async def root():
            return {
                "name": "SCG Lab",
                "version": "5.5.7",
                "status": "running",
                "message": "Frontend not built. API available at /api/docs",
            }

    return app
