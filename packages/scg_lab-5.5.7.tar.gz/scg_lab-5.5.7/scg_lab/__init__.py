"""SCG Lab — Multi-language interactive notebook environment."""

__version__ = "5.5.7"
__author__ = "Squid Consultancy Group"
