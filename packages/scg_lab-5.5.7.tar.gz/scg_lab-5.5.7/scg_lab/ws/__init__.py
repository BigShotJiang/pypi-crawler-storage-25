"""WebSocket package init."""
