"""WebSocket endpoint for streaming kernel execution.

Protocol (client → server):
  { "msg_type": "execute_request",    "content": { "code": "print('hi')" } }
  { "msg_type": "interrupt_request",  "content": {} }
  { "msg_type": "shutdown_request",   "content": {} }
  { "msg_type": "is_complete_request","content": { "code": "..." } }

Protocol (server → client):
  { "msg_type": "stream",          "content": { "name": "stdout", "text": "hi\n" } }
  { "msg_type": "execute_result",  "content": { "data": {...}, "execution_count": 1 } }
  { "msg_type": "display_data",    "content": { "data": {...} } }
  { "msg_type": "error",           "content": { "ename": "...", "evalue": "...", "traceback": [...] } }
  { "msg_type": "status",          "content": { "execution_state": "busy"|"idle"|"dead" } }
"""

import asyncio
import json

from fastapi import WebSocket, WebSocketDisconnect

from scg_lab.kernel.manager import kernel_manager


async def kernel_ws_handler(websocket: WebSocket, kernel_id: str) -> None:
    """Handle a WebSocket connection for a specific kernel.

    A background receiver task continuously reads incoming messages into a
    queue.  The main loop pulls from that queue so that interrupt/shutdown
    requests are processed even while an execute_request is in flight.
    """
    await websocket.accept()

    kernel = kernel_manager.get_kernel(kernel_id)
    if not kernel:
        await websocket.send_text(json.dumps({
            "msg_type": "error",
            "content": {"ename": "KernelNotFound",
                        "evalue": f"No kernel with id {kernel_id}",
                        "traceback": []},
        }))
        await websocket.close()
        return

    # Unbounded queue — messages are small and the client is on localhost.
    message_queue: asyncio.Queue = asyncio.Queue()

    async def _receiver() -> None:
        """Push every incoming WS text frame into the queue; put None on disconnect."""
        try:
            while True:
                raw = await websocket.receive_text()
                await message_queue.put(raw)
        except WebSocketDisconnect:
            await message_queue.put(None)

    receiver_task = asyncio.create_task(_receiver())

    async def _send(payload: dict) -> None:
        try:
            await websocket.send_text(json.dumps(payload))
        except Exception:
            pass

    try:
        while True:
            raw = await message_queue.get()
            if raw is None:
                break  # client disconnected

            try:
                msg = json.loads(raw)
            except json.JSONDecodeError:
                await _send({"msg_type": "error",
                             "content": {"ename": "ParseError",
                                         "evalue": "Invalid JSON",
                                         "traceback": []}})
                continue

            msg_type = msg.get("msg_type", "")
            content = msg.get("content", {})

            if msg_type == "execute_request":
                code = content.get("code", "")

                # Run kernel execution as a background task so the main loop
                # can still receive interrupt/shutdown messages while streaming.
                exec_done = asyncio.Event()

                async def _stream_execution(c: str = code) -> None:
                    try:
                        async for kernel_msg in kernel.execute(c):
                            await _send(kernel_msg.to_dict())
                    finally:
                        exec_done.set()

                exec_task = asyncio.create_task(_stream_execution())

                # Drain control messages until execution finishes or is cancelled.
                while not exec_done.is_set():
                    try:
                        ctrl_raw = await asyncio.wait_for(
                            message_queue.get(), timeout=0.05
                        )
                    except asyncio.TimeoutError:
                        continue

                    if ctrl_raw is None:
                        exec_task.cancel()
                        return

                    try:
                        ctrl_msg = json.loads(ctrl_raw)
                    except json.JSONDecodeError:
                        continue

                    ctrl_type = ctrl_msg.get("msg_type", "")

                    if ctrl_type == "interrupt_request":
                        await kernel.interrupt()
                        await _send({"msg_type": "status",
                                     "content": {"execution_state": "idle"}})

                    elif ctrl_type == "shutdown_request":
                        exec_task.cancel()
                        await kernel_manager.shutdown_kernel(kernel_id)
                        await _send({"msg_type": "status",
                                     "content": {"execution_state": "dead"}})
                        return

                    # Other message types (e.g., is_complete) are re-queued for
                    # the outer loop to handle after execution completes.
                    else:
                        await message_queue.put(ctrl_raw)

                try:
                    await exec_task
                except asyncio.CancelledError:
                    pass

            elif msg_type == "interrupt_request":
                await kernel.interrupt()
                await _send({"msg_type": "status",
                             "content": {"execution_state": "idle"}})

            elif msg_type == "shutdown_request":
                await kernel_manager.shutdown_kernel(kernel_id)
                await _send({"msg_type": "status",
                             "content": {"execution_state": "dead"}})
                break

            elif msg_type == "is_complete_request":
                result = await kernel.is_complete(content.get("code", ""))
                await _send({"msg_type": "is_complete_reply", "content": result})

    except Exception as e:
        await _send({"msg_type": "error",
                     "content": {"ename": type(e).__name__,
                                 "evalue": str(e),
                                 "traceback": []}})
    finally:
        receiver_task.cancel()
        try:
            await receiver_task
        except asyncio.CancelledError:
            pass
