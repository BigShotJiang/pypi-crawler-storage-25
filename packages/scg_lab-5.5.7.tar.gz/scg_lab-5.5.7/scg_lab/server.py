"""SCG Lab server startup."""

import sys
import asyncio
import warnings
import uvicorn


def start_server(host: str = "127.0.0.1", port: int = 8765) -> None:
    """Start the SCG Lab uvicorn server."""
    # On Windows, suppress the benign zmq/tornado Proactor warning.
    # zmq automatically registers a selector thread fallback that works correctly;
    # the warning is purely informational and confuses end users.
    if sys.platform == "win32":
        asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
        warnings.filterwarnings(
            "ignore",
            message="Proactor event loop does not implement add_reader",
            category=RuntimeWarning,
        )

    from scg_lab.app import create_app  # noqa: PLC0415 – intentional late import
    app = create_app()
    uvicorn.run(
        app,
        host=host,
        port=port,
        # Stream live request / kernel logs into the terminal where the user ran
        # `scg-lab`, so they can see notebooks being served, kernels starting /
        # stopping, and websocket activity in real time.
        log_level="info",
        access_log=True,
        ws_ping_interval=20,
        ws_ping_timeout=20,
    )
