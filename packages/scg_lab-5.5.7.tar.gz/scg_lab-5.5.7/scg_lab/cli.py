"""SCG Lab CLI — the main entry point users run from terminal."""

import os
import sys
import webbrowser
import threading
import time

import click
from rich.console import Console
from rich.panel import Panel
from rich import print as rprint

console = Console()


@click.group(invoke_without_command=True)
@click.version_option(package_name="scg-lab")
@click.option("--port", "-p", default=8765, show_default=True, help="Port to run server on.")
@click.option("--host", default="127.0.0.1", show_default=True, help="Host to bind server to.")
@click.option("--no-browser", is_flag=True, default=False, help="Do not open browser automatically.")
@click.pass_context
def main(ctx: click.Context, port: int, host: str, no_browser: bool) -> None:
    """SCG Lab — Multi-language interactive notebook environment.

    Run 'scg-lab' to launch the lab in your browser.
    """
    if ctx.invoked_subcommand is None:
        # Default: launch the lab
        _launch(host=host, port=port, no_browser=no_browser)


def _launch(host: str, port: int, no_browser: bool) -> None:
    """Start the SCG Lab server and open browser."""
    from scg_lab.server import start_server

    url = f"http://{host}:{port}"

    console.print(
        Panel.fit(
            f"[bold cyan]SCG Lab[/bold cyan] [dim]v5.5.7[/dim]\n"
            f"[green]Server:[/green] {url}\n"
            f"[dim]Press Ctrl+C to stop[/dim]",
            border_style="cyan",
            title="[bold]Squid Consultancy Group[/bold]",
        )
    )

    if not no_browser:
        # Open browser after a short delay to let server start
        def _open():
            time.sleep(1.5)
            webbrowser.open(url)

        threading.Thread(target=_open, daemon=True).start()

    start_server(host=host, port=port)


# ─────────────────────────────────────────
# scg-lab env subcommands
# ─────────────────────────────────────────

@main.group()
def env() -> None:
    """Manage SCG Lab language environments."""


@env.command("list")
def env_list() -> None:
    """List all registered environments."""
    from scg_lab.env.registry import EnvironmentRegistry

    registry = EnvironmentRegistry()
    envs = registry.list_envs()

    if not envs:
        console.print("[yellow]No environments found.[/yellow] Run [bold]scg-lab env create[/bold] to add one.")
        return

    console.print(f"\n[bold]Registered Environments ({len(envs)}):[/bold]\n")
    for e in envs:
        active = " [green]← active[/green]" if e.get("active") else ""
        console.print(f"  [cyan]{e['name']}[/cyan]  [dim]{e['lang']}[/dim]  {e['path']}{active}")
    console.print()


@env.command("create")
@click.option("--name", "-n", required=True, help="Name for the new environment.")
@click.option("--lang", "-l", default="python",
              type=click.Choice(["python", "node", "c"], case_sensitive=False),
              show_default=True, help="Language for this environment.")
@click.option("--packages", "-pkg", default="", help="Comma-separated packages to install.")
def env_create(name: str, lang: str, packages: str) -> None:
    """Create a new language environment."""
    from scg_lab.env.python_env import create_python_env
    from scg_lab.env.registry import EnvironmentRegistry

    registry = EnvironmentRegistry()

    if lang == "python":
        console.print(f"[cyan]Creating Python environment:[/cyan] [bold]{name}[/bold] ...")
        env_path = create_python_env(name)
        registry.register(name=name, lang="python", path=str(env_path))

        if packages:
            pkg_list = [p.strip() for p in packages.split(",") if p.strip()]
            console.print(f"[cyan]Installing packages:[/cyan] {', '.join(pkg_list)}")
            import subprocess
            pip_exe = env_path / "bin" / "pip" if os.name != "nt" else env_path / "Scripts" / "pip.exe"
            subprocess.run([str(pip_exe), "install"] + pkg_list, check=True)

        console.print(f"[green]✓ Environment '{name}' created at {env_path}[/green]")
    else:
        console.print(f"[yellow]Environment type '{lang}' will be supported in Phase 3.[/yellow]")


@env.command("install")
@click.argument("packages", nargs=-1, required=True)
@click.option("--env-name", "-e", default=None, help="Target environment name (defaults to active).")
def env_install(packages: tuple, env_name: str | None) -> None:
    """Install packages into an environment."""
    from scg_lab.env.registry import EnvironmentRegistry
    import subprocess

    registry = EnvironmentRegistry()
    target = registry.get_env(env_name) if env_name else registry.get_active()

    if not target:
        console.print("[red]No active environment found. Run scg-lab env create first.[/red]")
        sys.exit(1)

    env_path = target["path"]
    lang = target["lang"]

    if lang == "python":
        pip = os.path.join(env_path, "bin", "pip") if os.name != "nt" \
            else os.path.join(env_path, "Scripts", "pip.exe")
        console.print(f"[cyan]Installing into '{target['name']}':[/cyan] {' '.join(packages)}")
        subprocess.run([pip, "install"] + list(packages), check=True)
        console.print("[green]✓ Done[/green]")
    else:
        console.print(f"[yellow]Install for '{lang}' not yet implemented.[/yellow]")


@env.command("activate")
@click.argument("name")
def env_activate(name: str) -> None:
    """Set an environment as the active default."""
    from scg_lab.env.registry import EnvironmentRegistry

    registry = EnvironmentRegistry()
    registry.set_active(name)
    console.print(f"[green]✓ '{name}' is now the active environment.[/green]")


if __name__ == "__main__":
    main()
