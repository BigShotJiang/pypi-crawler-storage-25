<p align="center">
  <img src="https://raw.githubusercontent.com/analyticswithharry/scg-lab/main/logo.webp" alt="SCG Lab" width="120" />
</p>

<h1 align="center">SCG Lab</h1>

<p align="center">
  A modern, offline-first multi-language notebook IDE — Jupyter Lab feel, single <code>pip install</code>.
  <br/>
  <em>by <strong>Squid Consultancy Group</strong> · <a href="https://github.com/analyticswithharry">@analyticswithharry</a></em>
</p>

---

## What is it?

SCG Lab is a browser-based notebook environment that runs **entirely on your machine**. It bundles a React/Monaco frontend with a FastAPI + Jupyter-kernel backend into one installable Python package.

- **Languages**: Python, JavaScript (Node), C, C++
- **Jupyter-style UI**: tabbed File / Edit / View / Insert / Cell / Run / Kernel / Tabs / Settings / Demo / Help menus, command palette, dark/light theme
- **Mandatory line numbers** in every code cell
- **Built-in demos** for every supported language (one click to load)
- **Environment manager**: create/activate per-project Python envs from the CLI

---

## Install (works on any machine)

```bash
pip install scg-lab
```

## Run

```bash
scg-lab                 # opens http://127.0.0.1:8765
scg-lab --port 9000
```

That's it — no Node, no extra build steps. The frontend ships pre-built inside the wheel.

## Brief Usage

1. `pip install scg-lab` then run `scg-lab`.
2. Pick a language tile from the **Launcher** (or click **Demo** in the menu bar to load a ready-made notebook).
3. Type code in a cell — line numbers are always on.
4. **Shift+Enter** to run, **Ctrl+Enter** to run in place.
5. Use the **Run** menu for *Run All / Run Above / Run Below / Restart & Run All*.

---


## Environment Management

```bash
# List environments
scg-lab env list

# Create a Python environment
scg-lab env create myenv --lang python

# Install packages into an environment
scg-lab env install myenv numpy pandas matplotlib

# Activate an environment
scg-lab env activate myenv
```

---

## Supported Languages

| Language   | Requirements                        |
|------------|-------------------------------------|
| Python     | Built-in (uses ipykernel)           |
| JavaScript | Node.js                             |
| C          | GCC                                 |
| C++        | G++                                 |

---

## Developer Build

```bash
cd frontend
npm install
npm run build    # outputs to ../scg_lab/static/

pip install -e ".[dev]"
scg-lab
```

---

## License

MIT © Squid Consultancy Group
