"""Layer-aware real-KV scan utilities for tiny-turboquant.

v0.12.0.1 hardens the layer-aware scan that measures how real or synthetic KV-cache
layers tolerate compressed page layouts.  It recommends K/V bit policies instead
of assuming one compression setting is safe for every layer.

This is a research diagnostic.  It does not claim production serving acceleration.
"""

from __future__ import annotations

import json
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple, Union

import torch
import torch.nn.functional as F

from .attention import attention_similarity, dense_attention
from .attention_perf import _resolve_device, _resolve_dtype, _runtime_warnings, _sync, triton_status
from .layout import CompressedKVPageTable, compressed_page_attention_reference


DEFAULT_SCAN_CANDIDATES: Tuple[str, ...] = (
    "8,8,affine",
    "8,6,affine",
    "8,4,affine",
    "6,4,affine",
    "4,4,residual-affine",
)


REAL_KV_SCAN_PRESETS: Dict[str, Dict[str, Any]] = {
    "strict": {
        "candidates": ("8,8,affine", "8,4,affine", "6,4,affine"),
        "boundary_layer_count": 2,
        "target_attention_cosine": 0.9995,
        "max_attention_relative_error": 0.03,
        "target_score_cosine": 0.9995,
        "max_softmax_kl": 0.0005,
    },
    "safe": {
        "candidates": ("8,8,affine", "8,4,affine", "6,4,affine"),
        "boundary_layer_count": 2,
        "target_attention_cosine": 0.999,
        "max_attention_relative_error": 0.05,
        "target_score_cosine": 0.999,
        "max_softmax_kl": 0.001,
    },
    "balanced": {
        "candidates": ("8,8,affine", "8,4,affine", "6,4,affine", "4,4,affine"),
        "boundary_layer_count": 2,
        "target_attention_cosine": 0.995,
        "max_attention_relative_error": 0.075,
        "target_score_cosine": 0.995,
        "max_softmax_kl": 0.005,
    },
    "aggressive": {
        "candidates": ("8,8,affine", "8,4,affine", "6,4,affine", "4,4,affine", "4,2,affine"),
        "boundary_layer_count": 1,
        "target_attention_cosine": 0.99,
        "max_attention_relative_error": 0.10,
        "target_score_cosine": 0.98,
        "max_softmax_kl": 0.05,
    },
}


def available_real_kv_scan_presets() -> List[str]:
    return list(REAL_KV_SCAN_PRESETS.keys())


def resolve_real_kv_scan_preset(preset: str = "safe", **overrides: Any) -> Dict[str, Any]:
    if preset not in REAL_KV_SCAN_PRESETS:
        valid = ", ".join(available_real_kv_scan_presets())
        raise ValueError(f"unknown real-KV scan preset {preset!r}; valid presets: {valid}")
    cfg = dict(REAL_KV_SCAN_PRESETS[preset])
    cfg["preset"] = preset
    for key, value in overrides.items():
        if value is not None:
            cfg[key] = value
    return cfg


LayerRecord = Union[Tuple[torch.Tensor, torch.Tensor], Tuple[torch.Tensor, torch.Tensor, Optional[torch.Tensor]]]


@dataclass
class RealKVLayerScanConfig:
    """Configuration for layer-aware KV compression scans."""

    preset: str = "safe"
    model: str = "sshleifer/tiny-gpt2"
    prompt: str = "Tiny TurboQuant studies compressed KV-cache attention for long-context inference."
    max_prompt_tokens: Optional[int] = None
    layers: str = "all"
    max_layers: Optional[int] = None
    layer_stride: int = 1
    page_size: int = 256
    candidates: Tuple[str, ...] = REAL_KV_SCAN_PRESETS["safe"]["candidates"]
    boundary_layer_count: int = int(REAL_KV_SCAN_PRESETS["safe"]["boundary_layer_count"])
    target_attention_cosine: float = float(REAL_KV_SCAN_PRESETS["safe"]["target_attention_cosine"])
    max_attention_relative_error: float = float(REAL_KV_SCAN_PRESETS["safe"]["max_attention_relative_error"])
    target_score_cosine: float = float(REAL_KV_SCAN_PRESETS["safe"]["target_score_cosine"])
    max_softmax_kl: float = float(REAL_KV_SCAN_PRESETS["safe"]["max_softmax_kl"])
    query_source: str = "model-hidden-q"  # model-hidden-q, last-key, random, random-normalized
    device: str = "auto"
    dtype: str = "auto"
    seed: int = 123
    local_files_only: bool = False
    trust_remote_code: bool = False
    synthetic: bool = False
    synthetic_layers: int = 4
    synthetic_batch_size: int = 1
    synthetic_heads: int = 4
    synthetic_seq_len: int = 64
    synthetic_head_dim: int = 32

    def __post_init__(self) -> None:
        if self.preset not in REAL_KV_SCAN_PRESETS:
            valid = ", ".join(available_real_kv_scan_presets())
            raise ValueError(f"preset must be one of: {valid}")
        if self.query_source not in {"model-hidden-q", "last-key", "random", "random-normalized"}:
            raise ValueError("query_source must be 'model-hidden-q', 'last-key', 'random', or 'random-normalized'")
        if int(self.page_size) < 1:
            raise ValueError("page_size must be >= 1")
        if int(self.layer_stride) < 1:
            raise ValueError("layer_stride must be >= 1")
        if int(self.boundary_layer_count) < 0:
            raise ValueError("boundary_layer_count must be >= 0")
        if not self.candidates:
            raise ValueError("at least one candidate layout is required")


def _safe_float(value: Any) -> Optional[float]:
    if value is None:
        return None
    try:
        x = float(value)
    except Exception:
        return None
    if not torch.isfinite(torch.tensor(x)).item():
        return None
    return x


def _quality_summary(reference: torch.Tensor, candidate: torch.Tensor) -> Dict[str, float]:
    ref = reference.float()
    cand = candidate.float()
    diff = cand - ref
    denom = ref.norm().clamp_min(1e-12)
    return {
        "mse": float((diff ** 2).mean().item()),
        "relative_error": float((diff.norm() / denom).item()),
        "cosine_similarity": float(F.cosine_similarity(ref.reshape(1, -1), cand.reshape(1, -1)).item()),
        "max_abs_error": float(diff.abs().max().item()),
    }


def _score_diagnostics(query: torch.Tensor, key: torch.Tensor, key_hat: torch.Tensor) -> Dict[str, float]:
    q = query.float()
    k = key.float()
    kh = key_hat.float()
    scale = q.shape[-1] ** -0.5
    scores = torch.matmul(q, k.transpose(-2, -1)) * scale
    scores_hat = torch.matmul(q, kh.transpose(-2, -1)) * scale
    probs = torch.softmax(scores, dim=-1)
    probs_hat = torch.softmax(scores_hat, dim=-1)
    kl = torch.sum(
        probs * (torch.log(probs.clamp_min(1e-12)) - torch.log(probs_hat.clamp_min(1e-12))),
        dim=-1,
    )
    diff = scores_hat - scores
    return {
        "score_mse": float((diff ** 2).mean().item()),
        "score_relative_error": float((diff.norm() / scores.norm().clamp_min(1e-12)).item()),
        "score_cosine_similarity": float(
            F.cosine_similarity(scores.reshape(1, -1), scores_hat.reshape(1, -1)).item()
        ),
        "inner_product_bias_mean": float(diff.mean().item()),
        "inner_product_bias_abs_mean": float(diff.abs().mean().item()),
        "inner_product_bias_max_abs": float(diff.abs().max().item()),
        "softmax_kl_mean": float(kl.mean().item()),
        "softmax_kl_max": float(kl.max().item()),
    }


def _parse_candidate(spec: str) -> Dict[str, Any]:
    raw = str(spec).strip()
    if not raw:
        raise ValueError("empty candidate spec")
    normalized = raw.replace("/", ",").replace(":", ",")
    parts = [p.strip() for p in normalized.split(",") if p.strip()]
    if len(parts) < 2:
        raise ValueError(f"candidate must be K,V[,mode], got {spec!r}")
    key_bits = int(parts[0])
    value_bits = int(parts[1])
    mode = parts[2] if len(parts) >= 3 else "affine"
    if not 1 <= key_bits <= 8 or not 1 <= value_bits <= 8:
        raise ValueError(f"candidate bits must be in [1, 8], got {spec!r}")
    if mode not in {"affine", "residual-affine", "codebook"}:
        raise ValueError("candidate mode must be affine, residual-affine, or codebook")
    return {
        "name": f"k{key_bits}_v{value_bits}_{mode}",
        "key_bits": key_bits,
        "value_bits": value_bits,
        "quantization_mode": mode,
        "spec": raw,
    }


def parse_scan_candidates(candidates: Sequence[str]) -> List[Dict[str, Any]]:
    """Parse CLI-friendly candidate specs like ``8,6`` or ``4,4,residual-affine``."""

    parsed: List[Dict[str, Any]] = []
    seen = set()
    for item in candidates:
        cand = _parse_candidate(item)
        key = (cand["key_bits"], cand["value_bits"], cand["quantization_mode"])
        if key not in seen:
            parsed.append(cand)
            seen.add(key)
    return parsed


def _largest_divisor_at_most(n: int, limit: int) -> int:
    n = max(1, int(n))
    limit = max(1, min(int(limit), n))
    for d in range(limit, 0, -1):
        if n % d == 0:
            return d
    return 1


def _effective_page_size(seq_len: int, requested_page_size: int) -> Tuple[int, Dict[str, Any]]:
    seq_len = max(1, int(seq_len))
    requested = max(1, int(requested_page_size))
    if seq_len % requested == 0:
        return requested, {
            "requested_page_size": requested,
            "effective_page_size": requested,
            "adjusted": False,
            "reason": "requested page size divides sequence length",
        }
    effective = _largest_divisor_at_most(seq_len, requested)
    return effective, {
        "requested_page_size": requested,
        "effective_page_size": effective,
        "adjusted": True,
        "reason": "sequence length is not divisible by requested page size; using largest divisor <= requested size to avoid padded-token artifacts",
    }


def _normalise_query_tensor(q: torch.Tensor) -> torch.Tensor:
    work = q.float()
    denom = work.norm(dim=-1, keepdim=True).clamp_min(1e-12)
    return (work / denom).to(q.dtype)


def _build_query_for_layer(
    k: torch.Tensor,
    *,
    query_source: str,
    seed: int,
    layer_index: int,
    model_query: Optional[torch.Tensor] = None,
) -> Tuple[torch.Tensor, str, Optional[str]]:
    if query_source == "model-hidden-q":
        if model_query is not None:
            q = _ensure_bhsd(model_query.detach().to(device=k.device, dtype=k.dtype)).contiguous()
            if q.shape[0] == k.shape[0] and q.shape[1] == k.shape[1] and q.shape[-1] == k.shape[-1]:
                return q[:, :, -1:, :].contiguous(), "model-hidden-q", None
            return _normalise_query_tensor(k[:, :, -1:, :].detach().clone()), "last-key", (
                f"model-hidden-q shape {tuple(q.shape)} does not match KV shape {tuple(k.shape)}; used last-key fallback"
            )
        return _normalise_query_tensor(k[:, :, -1:, :].detach().clone()), "last-key", (
            "model-hidden-q unavailable for this layer; used last-key fallback"
        )
    if query_source == "last-key":
        return _normalise_query_tensor(k[:, :, -1:, :].detach().clone()), "last-key", None
    g = torch.Generator(device=k.device)
    g.manual_seed(int(seed) + int(layer_index) * 1009)
    q = torch.randn(
        int(k.shape[0]),
        int(k.shape[1]),
        1,
        int(k.shape[3]),
        device=k.device,
        dtype=k.dtype,
        generator=g,
    )
    if query_source == "random-normalized":
        return _normalise_query_tensor(q), "random-normalized", None
    return q, "random", None


def _is_boundary_layer(layer_pos: int, total_selected: int, boundary_layer_count: int) -> bool:
    n = int(boundary_layer_count)
    if n <= 0:
        return False
    return layer_pos < n or layer_pos >= max(0, int(total_selected) - n)


def _passes_thresholds(candidate_row: Dict[str, Any], config: RealKVLayerScanConfig) -> bool:
    attn = candidate_row.get("attention", {})
    score = candidate_row.get("attention_scores", {})
    attn_cos = _safe_float(attn.get("cosine_similarity"))
    attn_rel = _safe_float(attn.get("relative_error"))
    score_cos = _safe_float(score.get("score_cosine_similarity"))
    softmax_kl = _safe_float(score.get("softmax_kl_mean"))
    if attn_cos is None or attn_rel is None or score_cos is None or softmax_kl is None:
        return False
    return bool(
        attn_cos >= float(config.target_attention_cosine)
        and attn_rel <= float(config.max_attention_relative_error)
        and score_cos >= float(config.target_score_cosine)
        and softmax_kl <= float(config.max_softmax_kl)
    )


def _risk_label(candidate_row: Optional[Dict[str, Any]], protected: bool, had_pass: bool) -> str:
    if protected:
        return "protected"
    if candidate_row is None:
        return "high"
    if not had_pass:
        return "high"
    attn = candidate_row.get("attention", {})
    attn_cos = _safe_float(attn.get("cosine_similarity")) or 0.0
    attn_rel = _safe_float(attn.get("relative_error")) or 999.0
    if attn_cos >= 0.995 and attn_rel <= 0.05:
        return "low"
    if attn_cos >= 0.99 and attn_rel <= 0.10:
        return "medium"
    return "high"


def _select_recommendation(
    candidate_rows: List[Dict[str, Any]],
    *,
    protected: bool,
    config: RealKVLayerScanConfig,
) -> Tuple[Dict[str, Any], str, bool]:
    # Boundary protection deliberately uses the highest precision measured layout
    # to avoid hiding first/last-layer sensitivity behind aggregate averages.
    if protected:
        quality_rows = [r for r in candidate_rows if r["key_bits"] == 8 and r["value_bits"] == 8]
        chosen = quality_rows[0] if quality_rows else max(candidate_rows, key=lambda r: (r["key_bits"], r["value_bits"]))
        return chosen, "boundary layer protected; use high-precision K/V for stable defaults", _passes_thresholds(chosen, config)

    passing = [r for r in candidate_rows if _passes_thresholds(r, config)]
    if passing:
        # Choose the smallest measured effective memory among candidates that pass.
        chosen = min(passing, key=lambda r: float((r.get("memory") or {}).get("actual_total_bytes", 10**30)))
        return chosen, "smallest measured layout that passes attention and score thresholds", True

    chosen = max(candidate_rows, key=lambda r: (r["key_bits"], r["value_bits"]))
    return chosen, "no candidate passed thresholds; fall back to highest precision measured layout", False


def _ensure_bhsd(x: torch.Tensor) -> torch.Tensor:
    if x.ndim != 4:
        raise ValueError(f"KV tensor must be rank-4; got shape {tuple(x.shape)}")
    if x.shape[1] > x.shape[2] and x.shape[2] <= 128:
        return x.permute(0, 2, 1, 3).contiguous()
    return x.contiguous()


def _select_layer_indices(total_layers: int, layer_spec: str, layer_stride: int, max_layers: Optional[int]) -> List[int]:
    total = int(total_layers)
    if total <= 0:
        return []
    spec = str(layer_spec or "all").strip().lower()
    if spec in {"all", "*"}:
        indices = list(range(0, total, max(1, int(layer_stride))))
    elif spec in {"first-last", "boundary"}:
        indices = sorted(set([0, total - 1]))
    else:
        indices = []
        for part in spec.replace(";", ",").split(","):
            part = part.strip()
            if not part:
                continue
            idx = int(part)
            if idx < 0:
                idx = total + idx
            if idx < 0 or idx >= total:
                raise IndexError(f"layer index {part!r} out of range for {total} layers")
            indices.append(idx)
        indices = sorted(set(indices))
    if max_layers is not None:
        indices = indices[: max(1, int(max_layers))]
    return indices


def _scan_one_layer(
    *,
    layer_index: int,
    layer_position: int,
    total_selected: int,
    key: torch.Tensor,
    value: torch.Tensor,
    model_query: Optional[torch.Tensor],
    config: RealKVLayerScanConfig,
    dtype_bytes: int,
) -> Dict[str, Any]:
    if key.shape != value.shape:
        raise ValueError(f"K/V shapes must match for layer {layer_index}: {tuple(key.shape)} vs {tuple(value.shape)}")
    k = _ensure_bhsd(key).contiguous()
    v = _ensure_bhsd(value).contiguous()
    q, query_source_actual, query_warning = _build_query_for_layer(
        k,
        query_source=config.query_source,
        seed=config.seed,
        layer_index=layer_index,
        model_query=model_query,
    )
    dense_out = dense_attention(q, k, v)
    effective_page, page_policy = _effective_page_size(int(k.shape[2]), int(config.page_size))
    candidate_rows: List[Dict[str, Any]] = []
    warnings: List[str] = []
    if query_warning:
        warnings.append(query_warning)
    for cand in parse_scan_candidates(config.candidates):
        t0 = time.perf_counter()
        try:
            table = CompressedKVPageTable.from_dense(
                k,
                v,
                key_bits=int(cand["key_bits"]),
                value_bits=int(cand["value_bits"]),
                page_size=effective_page,
                layer_id=int(layer_index),
                seed=int(config.seed) + int(layer_index) * 1009,
                dtype_bytes=int(dtype_bytes),
                quantization_mode=str(cand["quantization_mode"]),
            )
            compressed_out = compressed_page_attention_reference(q, table, rotate_query=True)
            k_hat, v_hat = table.to_dense()
            k_rot = table.key_quantizer.rotation.apply(k.float()).to(k.dtype)
            k_rot_hat = table.to_rotated_key_dense().to(k.dtype)
            row = {
                **cand,
                "status": "ok",
                "build_seconds": float(time.perf_counter() - t0),
                "page_size": int(effective_page),
                "page_count": int(table.page_count),
                "memory": table.memory_report().to_dict(),
                "key_reconstruction": _quality_summary(k, k_hat.to(k.dtype)),
                "rotated_key_reconstruction": _quality_summary(k_rot, k_rot_hat.to(k_rot.dtype)),
                "value_reconstruction": _quality_summary(v, v_hat.to(v.dtype)),
                "attention": attention_similarity(dense_out, compressed_out),
                "attention_scores": _score_diagnostics(table.rotate_query(q), k_rot, k_rot_hat),
            }
            row["passes_thresholds"] = _passes_thresholds(row, config)
            candidate_rows.append(row)
        except Exception as exc:
            warnings.append(f"candidate {cand.get('spec')} failed on layer {layer_index}: {exc!r}")
            candidate_rows.append({**cand, "status": "error", "error": repr(exc), "passes_thresholds": False})

    ok_rows = [r for r in candidate_rows if r.get("status") == "ok"]
    if not ok_rows:
        return {
            "layer": int(layer_index),
            "layer_position": int(layer_position),
            "kv_shape": list(k.shape),
            "query_source": config.query_source,
            "query_source_actual": query_source_actual,
            "error": "all candidates failed",
            "warnings": warnings,
            "candidates": candidate_rows,
        }

    protected = _is_boundary_layer(layer_position, total_selected, int(config.boundary_layer_count))
    chosen, reason, had_pass = _select_recommendation(ok_rows, protected=protected, config=config)
    risk = _risk_label(chosen, protected, had_pass)
    rec = {
        "recommended_k_bits": int(chosen["key_bits"]),
        "recommended_v_bits": int(chosen["value_bits"]),
        "recommended_quantization_mode": str(chosen["quantization_mode"]),
        "protect_layer": bool(protected),
        "risk_level": risk,
        "passes_thresholds": bool(had_pass),
        "reason": reason,
    }
    return {
        "layer": int(layer_index),
        "layer_position": int(layer_position),
        "kv_shape": list(k.shape),
        "query_source": config.query_source,
        "query_source_actual": query_source_actual,
        "page_size_policy": page_policy,
        "recommendation": rec,
        "k_mse": chosen.get("key_reconstruction", {}).get("mse"),
        "v_mse": chosen.get("value_reconstruction", {}).get("mse"),
        "k_cosine": chosen.get("key_reconstruction", {}).get("cosine_similarity"),
        "v_cosine": chosen.get("value_reconstruction", {}).get("cosine_similarity"),
        "attention_cosine": chosen.get("attention", {}).get("cosine_similarity"),
        "attention_relative_error": chosen.get("attention", {}).get("relative_error"),
        "score_cosine": chosen.get("attention_scores", {}).get("score_cosine_similarity"),
        "softmax_kl_mean": chosen.get("attention_scores", {}).get("softmax_kl_mean"),
        "first_divergence_risk": risk,
        "warnings": warnings,
        "selected_candidate": chosen.get("name"),
        "candidates": candidate_rows,
    }


def _make_synthetic_layers(config: RealKVLayerScanConfig, device: str, dtype: torch.dtype) -> List[LayerRecord]:
    g = torch.Generator(device=device)
    g.manual_seed(int(config.seed))
    layers: List[Tuple[torch.Tensor, torch.Tensor]] = []
    for layer in range(int(config.synthetic_layers)):
        base_scale = 1.0 + 0.08 * layer
        k = torch.randn(
            int(config.synthetic_batch_size),
            int(config.synthetic_heads),
            int(config.synthetic_seq_len),
            int(config.synthetic_head_dim),
            device=device,
            dtype=dtype,
            generator=g,
        ) * base_scale
        v = torch.randn_like(k) * (1.0 + 0.05 * layer)
        # Make boundary layers a little sharper so the protection policy is not
        # an empty label in tests or small demonstrations.
        if layer == 0 or layer == int(config.synthetic_layers) - 1:
            k = k * 1.25
        layers.append((k.contiguous(), v.contiguous()))
    return layers


def _import_transformers_for_scan():
    try:
        from transformers import AutoModelForCausalLM, AutoTokenizer  # type: ignore
    except Exception as exc:  # pragma: no cover - optional dependency
        raise RuntimeError(
            "real-model-kv-scan requires transformers for non-synthetic scans. "
            "Install with: pip install tiny-turboquant[llm]"
        ) from exc
    return AutoModelForCausalLM, AutoTokenizer


def _get_decoder_layers(model: Any) -> Optional[Sequence[Any]]:
    for path in (
        ("model", "layers"),
        ("transformer", "h"),
        ("gpt_neox", "layers"),
        ("decoder", "layers"),
    ):
        obj = model
        ok = True
        for attr in path:
            obj = getattr(obj, attr, None)
            if obj is None:
                ok = False
                break
        if ok and hasattr(obj, "__len__"):
            return obj
    return None


def _project_q_from_layer(layer: Any, hidden: torch.Tensor, kv_heads: int, head_dim: int) -> Optional[torch.Tensor]:
    attn = getattr(layer, "self_attn", None) or getattr(layer, "attn", None) or getattr(layer, "attention", None)
    if attn is None:
        return None
    q_proj = getattr(attn, "q_proj", None) or getattr(attn, "query", None)
    if q_proj is not None:
        q_flat = q_proj(hidden)
        bsz, seq_len, width = q_flat.shape
        if width % int(head_dim) != 0:
            return None
        q_heads = width // int(head_dim)
        q = q_flat.view(bsz, seq_len, q_heads, int(head_dim)).permute(0, 2, 1, 3).contiguous()
    else:
        # GPT-2 style fused c_attn projects QKV together. This path is best-effort
        # and mainly exists to avoid hard failure on common decoder variants.
        c_attn = getattr(attn, "c_attn", None)
        if c_attn is None:
            return None
        qkv = c_attn(hidden)
        bsz, seq_len, width = qkv.shape
        if width % 3 != 0:
            return None
        q_flat = qkv[..., : width // 3]
        if q_flat.shape[-1] % int(head_dim) != 0:
            return None
        q_heads = q_flat.shape[-1] // int(head_dim)
        q = q_flat.view(bsz, seq_len, q_heads, int(head_dim)).permute(0, 2, 1, 3).contiguous()

    if q.shape[1] == int(kv_heads):
        return q
    if q.shape[1] > int(kv_heads) and q.shape[1] % int(kv_heads) == 0:
        group = q.shape[1] // int(kv_heads)
        return q.view(q.shape[0], int(kv_heads), group, q.shape[2], q.shape[3]).mean(dim=2).contiguous()
    if q.shape[1] < int(kv_heads) and int(kv_heads) % q.shape[1] == 0:
        repeat = int(kv_heads) // q.shape[1]
        return q.repeat_interleave(repeat, dim=1).contiguous()
    return None


def _extract_model_query_tensors(
    model: Any,
    outputs: Any,
    raw_layers: Sequence[Tuple[torch.Tensor, torch.Tensor]],
    *,
    device: str,
    dtype: torch.dtype,
) -> Dict[int, torch.Tensor]:
    hidden_states = getattr(outputs, "hidden_states", None)
    decoder_layers = _get_decoder_layers(model)
    if hidden_states is None or decoder_layers is None:
        return {}
    queries: Dict[int, torch.Tensor] = {}
    layer_count = min(len(raw_layers), len(decoder_layers), max(0, len(hidden_states) - 1))
    for i in range(layer_count):
        try:
            k = _ensure_bhsd(raw_layers[i][0])
            hidden = hidden_states[i].detach().to(device=device, dtype=dtype)
            q = _project_q_from_layer(decoder_layers[i], hidden, kv_heads=int(k.shape[1]), head_dim=int(k.shape[-1]))
            if q is not None:
                queries[i] = q.detach().to(device=device, dtype=dtype).contiguous()
        except Exception:
            continue
    return queries


def _extract_real_model_layers(config: RealKVLayerScanConfig, device: str, dtype: torch.dtype) -> Tuple[List[LayerRecord], Dict[str, Any]]:
    # Reuse the battle-tested cache-normalisation helpers from the real-model KV
    # benchmark without making the scan depend on one benchmark command.
    from .fused_attention import _normalise_past_key_values  # local import avoids import cycles

    AutoModelForCausalLM, AutoTokenizer = _import_transformers_for_scan()
    load_kwargs = {
        "local_files_only": bool(config.local_files_only),
        "trust_remote_code": bool(config.trust_remote_code),
    }
    tokenizer = AutoTokenizer.from_pretrained(config.model, **load_kwargs)
    model_kwargs = dict(load_kwargs)
    if device == "cuda":
        model_kwargs["torch_dtype"] = dtype
    model = AutoModelForCausalLM.from_pretrained(config.model, **model_kwargs)
    model.eval()
    model.to(device)

    encoded = tokenizer(
        config.prompt,
        return_tensors="pt",
        truncation=bool(config.max_prompt_tokens),
        max_length=config.max_prompt_tokens,
    )
    input_ids = encoded["input_ids"].to(device)
    attention_mask = encoded.get("attention_mask")
    if attention_mask is not None:
        attention_mask = attention_mask.to(device)

    _sync(device)
    t0 = time.perf_counter()
    with torch.no_grad():
        outputs = model(
            input_ids=input_ids,
            attention_mask=attention_mask,
            use_cache=True,
            output_hidden_states=(config.query_source == "model-hidden-q"),
        )
    _sync(device)
    forward_seconds = float(time.perf_counter() - t0)

    raw_layers = list(_normalise_past_key_values(outputs.past_key_values))
    model_queries = _extract_model_query_tensors(model, outputs, raw_layers, device=device, dtype=dtype) if config.query_source == "model-hidden-q" else {}

    layers: List[LayerRecord] = []
    model_query_layers_available = 0
    for i, (k, v) in enumerate(raw_layers):
        kk = _ensure_bhsd(k).detach().to(device=device, dtype=dtype).contiguous()
        vv = _ensure_bhsd(v).detach().to(device=device, dtype=dtype).contiguous()
        q = model_queries.get(i)
        if q is not None:
            model_query_layers_available += 1
            layers.append((kk, vv, q.detach().to(device=device, dtype=dtype).contiguous()))
        else:
            layers.append((kk, vv))
    meta = {
        "model": config.model,
        "prompt_tokens": int(input_ids.shape[-1]),
        "model_forward_seconds": forward_seconds,
        "num_kv_layers": int(len(layers)),
        "source": "huggingface-past_key_values",
        "model_query_layers_available": int(model_query_layers_available),
    }
    return layers, meta


def run_real_kv_layer_scan(config: RealKVLayerScanConfig) -> Dict[str, Any]:
    """Run a layer-aware KV compression scan and return a JSON-serializable report."""

    requested_device = config.device
    requested_dtype = config.dtype
    device = _resolve_device(requested_device)
    dtype = _resolve_dtype(requested_dtype, device)
    warnings = list(_runtime_warnings(requested_device, device, requested_dtype, dtype))
    dtype_bytes = torch.empty((), dtype=dtype).element_size()

    try:
        if bool(config.synthetic):
            layers = _make_synthetic_layers(config, device, dtype)
            source = {
                "source": "synthetic",
                "num_kv_layers": int(len(layers)),
                "model": None,
                "prompt_tokens": None,
                "model_forward_seconds": None,
            }
        else:
            layers, source = _extract_real_model_layers(config, device, dtype)
        if not layers:
            raise RuntimeError("no KV layers available for scan")
        selected = _select_layer_indices(
            len(layers),
            config.layers,
            int(config.layer_stride),
            config.max_layers,
        )
        if not selected:
            raise RuntimeError("layer selection produced no layers")

        rows: List[Dict[str, Any]] = []
        for pos, layer_idx in enumerate(selected):
            layer_item = layers[layer_idx]
            if len(layer_item) == 3:
                k, v, q_model = layer_item  # type: ignore[misc]
            else:
                k, v = layer_item  # type: ignore[misc]
                q_model = None
            row = _scan_one_layer(
                layer_index=int(layer_idx),
                layer_position=int(pos),
                total_selected=int(len(selected)),
                key=k,
                value=v,
                model_query=q_model,
                config=config,
                dtype_bytes=dtype_bytes,
            )
            rows.append(row)
            warnings.extend(row.get("warnings") or [])

        risk_counts: Dict[str, int] = {}
        bit_policy_counts: Dict[str, int] = {}
        protected_layers: List[int] = []
        for row in rows:
            rec = row.get("recommendation") or {}
            risk = str(rec.get("risk_level", "error"))
            risk_counts[risk] = risk_counts.get(risk, 0) + 1
            if rec.get("protect_layer"):
                protected_layers.append(int(row.get("layer", -1)))
            if rec:
                policy = f"K{rec.get('recommended_k_bits')}/V{rec.get('recommended_v_bits')}/{rec.get('recommended_quantization_mode')}"
                bit_policy_counts[policy] = bit_policy_counts.get(policy, 0) + 1

        layer_errors = [row for row in rows if row.get("error")]
        failing_recommendations = [
            row for row in rows
            if row.get("recommendation") and not bool((row.get("recommendation") or {}).get("passes_thresholds"))
        ]
        non_protected_high = any(
            (row.get("recommendation") or {}).get("risk_level") == "high"
            and not (row.get("recommendation") or {}).get("protect_layer")
            for row in rows
        )
        compressed_recommendations = [
            row for row in rows
            if row.get("recommendation")
            and not ((row.get("recommendation") or {}).get("recommended_k_bits") == 8 and (row.get("recommendation") or {}).get("recommended_v_bits") == 8)
        ]
        if layer_errors:
            stable_verdict = "failed"
        elif failing_recommendations or non_protected_high:
            stable_verdict = "unstable-at-tested-thresholds"
        elif not compressed_recommendations:
            stable_verdict = "conservative-only"
        else:
            stable_verdict = "stable-at-tested-thresholds"

        summary_table = _summary_table_rows(rows)

        return {
            "version": "0.12.0.1",
            "benchmark": "layer-aware-real-kv-scan",
            "config": asdict(config),
            "runtime": {
                "requested_device": requested_device,
                "device": device,
                "requested_dtype": requested_dtype,
                "dtype": str(dtype).replace("torch.", ""),
                "dtype_bytes": int(dtype_bytes),
                "triton": triton_status(),
            },
            "source": source,
            "warnings": sorted(set(warnings)),
            "rows": rows,
            "summary": {
                "layers_scanned": int(len(rows)),
                "selected_layers": [int(i) for i in selected],
                "protected_layers": protected_layers,
                "risk_counts": risk_counts,
                "recommended_policy_counts": bit_policy_counts,
                "stable_verdict": stable_verdict,
                "failed_layers": [int(row.get("layer", -1)) for row in layer_errors],
                "failing_recommendation_layers": [int(row.get("layer", -1)) for row in failing_recommendations],
                "summary_table": summary_table,
                "boundary": "Layer-aware KV scan; recommendations are diagnostics, not production serving guarantees.",
            },
            "interpretation": (
                "v0.12.0.1 scans each selected KV layer independently, measures reconstruction, attention-score, "
                "and attention-output drift across candidate K/V bit layouts, then recommends conservative per-layer policies. "
                "Boundary layers are protected by default because uniform compression across all layers is not a stable assumption."
            ),
        }
    except Exception as exc:
        warnings.append(f"real KV layer scan failed: {exc!r}")
        return {
            "version": "0.12.0.1",
            "benchmark": "layer-aware-real-kv-scan",
            "config": asdict(config),
            "runtime": {
                "requested_device": requested_device,
                "device": device,
                "requested_dtype": requested_dtype,
                "dtype": str(dtype).replace("torch.", ""),
                "dtype_bytes": int(dtype_bytes),
                "triton": triton_status(),
            },
            "warnings": warnings,
            "rows": [],
            "summary": {
                "stable_verdict": "scan-failed",
                "boundary": "Real KV scan could not run in this environment.",
            },
            "error": repr(exc),
        }


def _summary_table_rows(rows: Sequence[Dict[str, Any]]) -> List[Dict[str, Any]]:
    compact: List[Dict[str, Any]] = []
    for row in rows:
        rec = row.get("recommendation") or {}
        if row.get("error") and not rec:
            compact.append({
                "layer": row.get("layer"),
                "protect": False,
                "selected": "ERROR",
                "attention_cosine": None,
                "score_cosine": None,
                "softmax_kl_mean": None,
                "effective_memory_saved_pct": None,
                "risk": "error",
            })
            continue
        mem = None
        selected = row.get("selected_candidate")
        for cand in row.get("candidates", []):
            if cand.get("name") == selected:
                mem = (cand.get("memory") or {}).get("effective_memory_saved_pct")
                break
        compact.append({
            "layer": row.get("layer"),
            "protect": bool(rec.get("protect_layer")),
            "selected": f"K{rec.get('recommended_k_bits')}/V{rec.get('recommended_v_bits')}",
            "mode": rec.get("recommended_quantization_mode"),
            "query_source_actual": row.get("query_source_actual"),
            "attention_cosine": row.get("attention_cosine"),
            "score_cosine": row.get("score_cosine"),
            "softmax_kl_mean": row.get("softmax_kl_mean"),
            "effective_memory_saved_pct": mem,
            "risk": rec.get("risk_level"),
        })
    return compact


def real_kv_layer_scan_summary_table(report: Dict[str, Any]) -> str:
    rows = ((report.get("summary") or {}).get("summary_table") or _summary_table_rows(report.get("rows", [])))
    lines = [
        "Layer | Protect | Selected | Query | AttnCos | ScoreCos | KL | EffSave% | Risk",
        "---:|:---:|:---|:---|---:|---:|---:|---:|:---",
    ]
    for row in rows:
        def f(value: Any, digits: int = 6) -> str:
            if value is None:
                return ""
            try:
                return f"{float(value):.{digits}g}"
            except Exception:
                return str(value)
        lines.append(
            "{layer} | {protect} | {selected} | {query} | {attn} | {score} | {kl} | {save} | {risk}".format(
                layer=row.get("layer"),
                protect="yes" if row.get("protect") else "no",
                selected=row.get("selected"),
                query=row.get("query_source_actual") or "",
                attn=f(row.get("attention_cosine")),
                score=f(row.get("score_cosine")),
                kl=f(row.get("softmax_kl_mean")),
                save=f(row.get("effective_memory_saved_pct"), 4),
                risk=row.get("risk"),
            )
        )
    return "\n".join(lines) + "\n"


def real_kv_layer_scan_markdown_report(report: Dict[str, Any]) -> str:
    lines = [
        "# tiny-turboquant layer-aware real-KV scan",
        "",
        "This report scans KV-cache layers independently and recommends K/V bit policies. It is not a production serving claim.",
        "",
        "## Summary",
        f"- Version: {report.get('version')}",
        f"- Verdict: {(report.get('summary') or {}).get('stable_verdict')}",
        f"- Layers scanned: {(report.get('summary') or {}).get('layers_scanned')}",
        f"- Protected layers: {(report.get('summary') or {}).get('protected_layers')}",
        f"- Risk counts: {(report.get('summary') or {}).get('risk_counts')}",
        f"- Source: {(report.get('source') or {}).get('source')}",
        f"- Model query layers available: {(report.get('source') or {}).get('model_query_layers_available')}",
        "",
        "## Compact summary",
        "",
        real_kv_layer_scan_summary_table(report),
        "",
        "## Layer recommendations",
        "",
        "| layer | K bits | V bits | mode | protect | risk | attn cosine | attn rel err | score cosine | softmax KL | reason |",
        "|---:|---:|---:|---|---:|---|---:|---:|---:|---:|---|",
    ]
    for row in report.get("rows", []):
        if "error" in row and "recommendation" not in row:
            lines.append(f"| {row.get('layer')} |  |  |  |  | error |  |  |  |  | {row.get('error')} |")
            continue
        rec = row.get("recommendation") or {}
        lines.append(
            "| {layer} | {kb} | {vb} | {mode} | {protect} | {risk} | {acos} | {arel} | {scos} | {kl} | {reason} |".format(
                layer=row.get("layer"),
                kb=rec.get("recommended_k_bits"),
                vb=rec.get("recommended_v_bits"),
                mode=rec.get("recommended_quantization_mode"),
                protect=rec.get("protect_layer"),
                risk=rec.get("risk_level"),
                acos=row.get("attention_cosine"),
                arel=row.get("attention_relative_error"),
                scos=row.get("score_cosine"),
                kl=row.get("softmax_kl_mean"),
                reason=str(rec.get("reason", "")).replace("|", "/"),
            )
        )
    lines.extend([
        "",
        "## Boundary",
        "Recommendations are based on the tested prompt, query proxy, thresholds, and candidate layouts. Validate with task metrics before claiming serving stability.",
    ])
    return "\n".join(lines) + "\n"


def save_real_kv_layer_scan_json(report: Dict[str, Any], path: str | Path) -> None:
    Path(path).write_text(json.dumps(report, indent=2), encoding="utf-8")


def save_real_kv_layer_scan_markdown(report: Dict[str, Any], path: str | Path) -> None:
    Path(path).write_text(real_kv_layer_scan_markdown_report(report), encoding="utf-8")
