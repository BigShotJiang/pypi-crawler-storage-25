"""Hugging Face compressed-KV generation backend."""

from __future__ import annotations

from dataclasses import dataclass, field
from time import perf_counter
from typing import Any, Dict, List, Optional

import torch

from ...kv.compression import TinyTurboKVCache
from ...kv.policy import KVPolicy, resolve_kv_policy


@dataclass
class TinyTurboGenerateResult:
    prompt: str
    text: str
    generated_text: str
    input_tokens: int
    output_tokens: int
    kv_policy: str
    elapsed_seconds: float
    tokens_per_second: float
    cache_report: dict[str, Any]
    token_ids: list[int] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "prompt": self.prompt,
            "text": self.text,
            "generated_text": self.generated_text,
            "input_tokens": self.input_tokens,
            "output_tokens": self.output_tokens,
            "kv_policy": self.kv_policy,
            "elapsed_seconds": self.elapsed_seconds,
            "tokens_per_second": self.tokens_per_second,
            "cache_report": self.cache_report,
            "token_ids": self.token_ids,
            "backend_boundary": "compressed KV is stored between decode steps; v0.12.0.2 dequantizes before stock HF attention",
        }


class TinyTurboHFEngine:
    """Minimal compressed-KV serving engine for Hugging Face decoder models.

    This engine intentionally starts conservative: it stores the cache compressed
    between forward passes and materializes dense past_key_values for the next
    stock Hugging Face call.  That is enough to make the package a real runtime
    backend foundation without pretending fused compressed attention is done.
    """

    def __init__(
        self,
        model_name: str,
        *,
        kv_policy: str | KVPolicy = "q8k-q8v",
        device: str = "auto",
        dtype: str = "auto",
        local_files_only: bool = False,
        trust_remote_code: bool = False,
    ) -> None:
        self.model_name = model_name
        self.policy = resolve_kv_policy(kv_policy)
        self.device = self._resolve_device(device)
        self.dtype = self._resolve_dtype(dtype, self.device)
        self.local_files_only = local_files_only
        self.trust_remote_code = trust_remote_code
        self.tokenizer = None
        self.model = None

    @staticmethod
    def _resolve_device(device: str) -> str:
        if device == "auto":
            return "cuda" if torch.cuda.is_available() else "cpu"
        if device == "cuda" and not torch.cuda.is_available():
            raise RuntimeError("CUDA requested but torch.cuda.is_available() is false")
        return device

    @staticmethod
    def _resolve_dtype(dtype: str, device: str) -> torch.dtype:
        key = str(dtype).lower()
        if key == "auto":
            return torch.float16 if device == "cuda" else torch.float32
        if key in {"float16", "fp16", "half"}:
            return torch.float16
        if key in {"bfloat16", "bf16"}:
            return torch.bfloat16
        if key in {"float32", "fp32"}:
            return torch.float32
        raise ValueError(f"unsupported dtype {dtype!r}")

    def load(self) -> "TinyTurboHFEngine":
        try:
            from transformers import AutoModelForCausalLM, AutoTokenizer
        except Exception as exc:  # pragma: no cover
            raise ImportError(
                "transformers is required for the HF serving backend. "
                "Install with: pip install 'tiny-turboquant[hf]'"
            ) from exc
        self.tokenizer = AutoTokenizer.from_pretrained(
            self.model_name,
            local_files_only=self.local_files_only,
            trust_remote_code=self.trust_remote_code,
        )
        if self.tokenizer.pad_token_id is None and self.tokenizer.eos_token_id is not None:
            self.tokenizer.pad_token = self.tokenizer.eos_token
        self.model = AutoModelForCausalLM.from_pretrained(
            self.model_name,
            torch_dtype=self.dtype,
            local_files_only=self.local_files_only,
            trust_remote_code=self.trust_remote_code,
        ).to(self.device)
        self.model.eval()
        return self

    def _ensure_loaded(self) -> None:
        if self.model is None or self.tokenizer is None:
            self.load()

    def generate(
        self,
        prompt: str,
        *,
        max_new_tokens: int = 64,
        temperature: float = 0.0,
        stop_on_eos: bool = True,
        seed: int = 123,
    ) -> TinyTurboGenerateResult:
        self._ensure_loaded()
        assert self.model is not None and self.tokenizer is not None
        torch.manual_seed(int(seed))
        encoded = self.tokenizer(prompt, return_tensors="pt")
        input_ids = encoded["input_ids"].to(self.device)
        attention_mask = encoded.get("attention_mask")
        if attention_mask is not None:
            attention_mask = attention_mask.to(self.device)
        generated: list[int] = []
        compressed_cache: TinyTurboKVCache | None = None
        next_input = input_ids
        t0 = perf_counter()
        with torch.no_grad():
            for step in range(int(max_new_tokens)):
                if compressed_cache is None:
                    outputs = self.model(input_ids=next_input, attention_mask=attention_mask, use_cache=True, return_dict=True)
                else:
                    past = compressed_cache.to_model_past(dtype=self.dtype, device=self.device)
                    outputs = self.model(input_ids=next_input, past_key_values=past, use_cache=True, return_dict=True)
                logits = outputs.logits[:, -1, :]
                if temperature and temperature > 0:
                    probs = torch.softmax(logits / float(temperature), dim=-1)
                    next_token = torch.multinomial(probs, num_samples=1)
                else:
                    next_token = torch.argmax(logits, dim=-1, keepdim=True)
                token_id = int(next_token.item())
                generated.append(token_id)
                compressed_cache = TinyTurboKVCache.from_past_key_values(
                    outputs.past_key_values,
                    self.policy,
                    dense_dtype=self.dtype,
                )
                next_input = next_token.to(self.device)
                attention_mask = None
                if stop_on_eos and self.tokenizer.eos_token_id is not None and token_id == int(self.tokenizer.eos_token_id):
                    break
        elapsed = perf_counter() - t0
        gen_text = self.tokenizer.decode(generated, skip_special_tokens=True)
        full_text = prompt + gen_text
        cache_report = compressed_cache.to_dict() if compressed_cache is not None else {}
        return TinyTurboGenerateResult(
            prompt=prompt,
            text=full_text,
            generated_text=gen_text,
            input_tokens=int(input_ids.shape[-1]),
            output_tokens=len(generated),
            kv_policy=self.policy.name,
            elapsed_seconds=elapsed,
            tokens_per_second=len(generated) / max(elapsed, 1e-9),
            cache_report=cache_report,
            token_ids=generated,
        )


def load_hf_engine(**kwargs: Any) -> TinyTurboHFEngine:
    return TinyTurboHFEngine(**kwargs).load()
