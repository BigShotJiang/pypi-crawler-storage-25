"""Validation and benchmark helpers for the compressed-KV HF backend."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Iterable, List

from ..backends.hf import TinyTurboHFEngine


@dataclass
class GenerationComparison:
    prompt: str
    baseline_text: str
    candidate_text: str
    baseline_generated: str
    candidate_generated: str
    same_prefix_tokens: int
    baseline_tokens: int
    candidate_tokens: int
    exact_text_match: bool

    def to_dict(self) -> dict[str, Any]:
        return self.__dict__.copy()


def same_prefix_len(a: list[int], b: list[int]) -> int:
    n = 0
    for x, y in zip(a, b):
        if x != y:
            break
        n += 1
    return n


def compare_backend_generation(
    *,
    model: str,
    prompt: str,
    candidate_policy: str,
    baseline_policy: str = "fp16",
    max_new_tokens: int = 32,
    device: str = "auto",
    dtype: str = "auto",
    local_files_only: bool = False,
    trust_remote_code: bool = False,
    seed: int = 123,
) -> dict[str, Any]:
    baseline_engine = TinyTurboHFEngine(
        model,
        kv_policy=baseline_policy,
        device=device,
        dtype=dtype,
        local_files_only=local_files_only,
        trust_remote_code=trust_remote_code,
    ).load()
    candidate_engine = TinyTurboHFEngine(
        model,
        kv_policy=candidate_policy,
        device=device,
        dtype=dtype,
        local_files_only=local_files_only,
        trust_remote_code=trust_remote_code,
    )
    candidate_engine.tokenizer = baseline_engine.tokenizer
    candidate_engine.model = baseline_engine.model
    base = baseline_engine.generate(prompt, max_new_tokens=max_new_tokens, seed=seed)
    cand = candidate_engine.generate(prompt, max_new_tokens=max_new_tokens, seed=seed)
    comparison = GenerationComparison(
        prompt=prompt,
        baseline_text=base.text,
        candidate_text=cand.text,
        baseline_generated=base.generated_text,
        candidate_generated=cand.generated_text,
        same_prefix_tokens=same_prefix_len(base.token_ids, cand.token_ids),
        baseline_tokens=len(base.token_ids),
        candidate_tokens=len(cand.token_ids),
        exact_text_match=base.token_ids == cand.token_ids,
    )
    return {
        "model": model,
        "baseline_policy": baseline_policy,
        "candidate_policy": candidate_policy,
        "comparison": comparison.to_dict(),
        "baseline": base.to_dict(),
        "candidate": cand.to_dict(),
        "boundary": "This validates compressed KV storage in the HF decode loop; it is not a fused-kernel throughput claim.",
    }
