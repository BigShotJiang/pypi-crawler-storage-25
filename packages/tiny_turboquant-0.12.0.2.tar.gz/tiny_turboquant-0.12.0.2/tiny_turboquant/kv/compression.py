"""Tensor compression primitives for the v0.12.0.2 serving backend."""

from __future__ import annotations

from dataclasses import dataclass
from math import ceil
from typing import Any, Iterable, Sequence, Tuple

import torch

from ..bitpack import pack_indices, unpack_indices, tensor_nbytes
from .policy import KVPolicy, resolve_kv_policy


def _extract_kv_pair(layer_entry: Any, layer_index: int) -> Tuple[torch.Tensor, torch.Tensor]:
    """Extract ``(key, value)`` from a Hugging Face cache layer entry.

    Different Transformers versions and model families may return cache layer
    entries as ``(key, value)``, ``(key, value, ...)``, lists, or small cache
    objects.  The compressed storage backend only owns K/V tensors, so it keeps
    the first two tensor-like entries and ignores auxiliary metadata such as
    cache positions or legacy attention-state fields.
    """
    if isinstance(layer_entry, (tuple, list)):
        tensors = [x for x in layer_entry if torch.is_tensor(x)]
        if len(tensors) >= 2:
            return tensors[0], tensors[1]
    if hasattr(layer_entry, "key_cache") and hasattr(layer_entry, "value_cache"):
        return layer_entry.key_cache, layer_entry.value_cache
    if hasattr(layer_entry, "keys") and hasattr(layer_entry, "values"):
        return layer_entry.keys, layer_entry.values
    raise ValueError(
        f"could not extract key/value tensors from past_key_values layer {layer_index}; "
        f"got {type(layer_entry).__name__}"
    )


def _to_legacy_past(past: Any) -> Tuple[Tuple[torch.Tensor, torch.Tensor], ...]:
    """Convert a Hugging Face cache object to normalized ``(K, V)`` tuples.

    This normalizer accepts both legacy tuple caches and newer Transformers
    cache objects.  It intentionally strips non-K/V auxiliary fields so the
    storage backend can remain model-family agnostic.
    """
    if past is None:
        return tuple()
    raw = past.to_legacy_cache() if hasattr(past, "to_legacy_cache") else past
    if isinstance(raw, dict):
        # Defensive support for cache-like mappings used by some wrappers.
        raw = raw.get("past_key_values") or raw.get("cache") or raw.values()
    return tuple(_extract_kv_pair(layer, idx) for idx, layer in enumerate(tuple(raw)))


def _legacy_to_dynamic_cache(legacy: Tuple[Tuple[torch.Tensor, torch.Tensor], ...]) -> Any:
    """Convert normalized legacy tuples back to a Transformers Cache object.

    Newer Transformers model families such as Qwen2 expect ``past_key_values``
    to implement methods like ``get_seq_length()`` during incremental decode.
    Passing a plain tuple works for older models but fails for these newer
    cache-only paths.  This helper keeps the serving backend version-tolerant:
    use ``DynamicCache.from_legacy_cache`` when available, otherwise build a
    DynamicCache by calling ``update`` layer by layer.
    """
    try:
        from transformers.cache_utils import DynamicCache  # type: ignore
    except Exception as exc:  # pragma: no cover - depends on optional transformers
        raise RuntimeError(
            "Transformers DynamicCache is required to feed this model's cache format back into decode."
        ) from exc

    if hasattr(DynamicCache, "from_legacy_cache"):
        try:
            return DynamicCache.from_legacy_cache(legacy)  # type: ignore[attr-defined]
        except TypeError:
            # Some versions expose the method but with changed annotations.
            pass

    cache = DynamicCache()
    for layer_idx, (key_states, value_states) in enumerate(legacy):
        cache.update(key_states, value_states, layer_idx)
    return cache


@dataclass
class CompressedTensor:
    """Compressed representation of a K or V tensor.

    Dense policy stores the original tensor.  Low-bit policy stores packed
    integer codes plus affine scale/min values.  The tensors stay on the same
    device as the source tensor so decode loops do not force CPU transfers.
    """

    bits: int
    shape: Tuple[int, ...]
    dtype: str
    device: str
    q_packed: torch.Tensor | None = None
    q_shape: Tuple[int, ...] | None = None
    scale: torch.Tensor | None = None
    offset: torch.Tensor | None = None
    dense: torch.Tensor | None = None

    @classmethod
    def from_tensor(cls, x: torch.Tensor, bits: int) -> "CompressedTensor":
        bits = int(bits)
        if bits >= 16:
            return cls(
                bits=16,
                shape=tuple(int(v) for v in x.shape),
                dtype=str(x.dtype).replace("torch.", ""),
                device=str(x.device),
                dense=x.detach().contiguous(),
            )
        if bits < 1 or bits > 8:
            raise ValueError(f"bits must be in [1, 8] or 16, got {bits}")
        xf = x.detach().to(torch.float32)
        x_min = xf.amin().reshape(1)
        x_max = xf.amax().reshape(1)
        levels = float((1 << bits) - 1)
        scale = ((x_max - x_min) / max(levels, 1.0)).clamp_min(1e-12)
        q = torch.round((xf - x_min) / scale).clamp(0, levels).to(torch.uint8)
        packed, q_shape = pack_indices(q, bits)
        return cls(
            bits=bits,
            shape=tuple(int(v) for v in x.shape),
            dtype=str(x.dtype).replace("torch.", ""),
            device=str(x.device),
            q_packed=packed.contiguous(),
            q_shape=tuple(int(v) for v in q_shape),
            scale=scale.to(device=x.device),
            offset=x_min.to(device=x.device),
        )

    def dequantize(self, *, dtype: torch.dtype | None = None, device: torch.device | str | None = None) -> torch.Tensor:
        if self.dense is not None:
            out = self.dense
            if device is not None:
                out = out.to(device)
            if dtype is not None:
                out = out.to(dtype=dtype)
            return out
        if self.q_packed is None or self.q_shape is None or self.scale is None or self.offset is None:
            raise RuntimeError("corrupt compressed tensor; missing packed data or affine metadata")
        q = unpack_indices(self.q_packed, self.bits, self.q_shape).to(torch.float32)
        scale = self.scale.to(device=q.device, dtype=torch.float32)
        offset = self.offset.to(device=q.device, dtype=torch.float32)
        out = (q * scale + offset).reshape(self.shape)
        if device is not None:
            out = out.to(device)
        if dtype is not None:
            out = out.to(dtype=dtype)
        return out

    def storage_bytes(self) -> int:
        total = 0
        for obj in (self.q_packed, self.scale, self.offset, self.dense):
            if obj is not None:
                total += tensor_nbytes(obj)
        return int(total)

    def dense_bytes(self, dtype_bytes: int = 2) -> int:
        n = 1
        for dim in self.shape:
            n *= int(dim)
        return int(n * dtype_bytes)

    def to_dict(self) -> dict[str, Any]:
        return {
            "bits": self.bits,
            "shape": list(self.shape),
            "dtype": self.dtype,
            "device": self.device,
            "storage_bytes": self.storage_bytes(),
            "dense_fp16_bytes": self.dense_bytes(2),
        }


@dataclass
class CompressedLayerKV:
    layer: int
    key: CompressedTensor
    value: CompressedTensor
    effective_policy: str

    def to_dense(self, *, dtype: torch.dtype | None = None, device: torch.device | str | None = None) -> tuple[torch.Tensor, torch.Tensor]:
        return self.key.dequantize(dtype=dtype, device=device), self.value.dequantize(dtype=dtype, device=device)

    def storage_bytes(self) -> int:
        return self.key.storage_bytes() + self.value.storage_bytes()

    def dense_bytes(self, dtype_bytes: int = 2) -> int:
        return self.key.dense_bytes(dtype_bytes) + self.value.dense_bytes(dtype_bytes)


class TinyTurboKVCache:
    """Compressed KV storage used by the HF serving backend.

    The cache stores K/V compressed between decode steps.  Before a stock HF
    model forward, it materializes a dense legacy ``past_key_values`` tuple.  It
    is therefore a real compressed-storage backend foundation, not yet a fused
    compressed-attention accelerator.
    """

    def __init__(
        self,
        layers: Sequence[CompressedLayerKV],
        *,
        policy: KVPolicy,
        dense_dtype: torch.dtype,
        source_cache_type: str = "legacy",
        source_requires_cache_object: bool = False,
    ):
        self.layers = list(layers)
        self.policy = policy
        self.dense_dtype = dense_dtype
        self.source_cache_type = str(source_cache_type)
        self.source_requires_cache_object = bool(source_requires_cache_object)

    @classmethod
    def from_past_key_values(
        cls,
        past_key_values: Any,
        policy: str | KVPolicy,
        *,
        dense_dtype: torch.dtype | None = None,
    ) -> "TinyTurboKVCache":
        source_cache_type = type(past_key_values).__name__ if past_key_values is not None else "None"
        source_requires_cache_object = bool(
            past_key_values is not None
            and not isinstance(past_key_values, (tuple, list))
            and (hasattr(past_key_values, "get_seq_length") or hasattr(past_key_values, "to_legacy_cache"))
        )
        legacy = _to_legacy_past(past_key_values)
        resolved = resolve_kv_policy(policy)
        if dense_dtype is None:
            dense_dtype = legacy[0][0].dtype if legacy else torch.float16
        total_layers = len(legacy)
        layers: list[CompressedLayerKV] = []
        for idx, (k, v) in enumerate(legacy):
            effective = resolved.layer_policy(idx, total_layers)
            layers.append(
                CompressedLayerKV(
                    layer=idx,
                    key=CompressedTensor.from_tensor(k.detach(), effective.key_bits),
                    value=CompressedTensor.from_tensor(v.detach(), effective.value_bits),
                    effective_policy=effective.name,
                )
            )
        return cls(
            layers,
            policy=resolved,
            dense_dtype=dense_dtype,
            source_cache_type=source_cache_type,
            source_requires_cache_object=source_requires_cache_object,
        )

    def to_past_key_values(self, *, dtype: torch.dtype | None = None, device: torch.device | str | None = None):
        target_dtype = dtype or self.dense_dtype
        return tuple(layer.to_dense(dtype=target_dtype, device=device) for layer in self.layers)

    def to_model_past(self, *, dtype: torch.dtype | None = None, device: torch.device | str | None = None):
        """Return dense past_key_values in the format expected by the source model.

        Legacy models accept ``tuple[(K, V), ...]``.  Newer Transformers models
        such as Qwen2 expect a ``Cache`` object with ``get_seq_length()``.
        The cache remembers the format returned by the model and reconstructs
        that format for the next incremental decode step.
        """
        legacy = self.to_past_key_values(dtype=dtype, device=device)
        if self.source_requires_cache_object:
            return _legacy_to_dynamic_cache(legacy)
        return legacy

    def storage_bytes(self) -> int:
        return int(sum(layer.storage_bytes() for layer in self.layers))

    def dense_bytes(self, dtype_bytes: int = 2) -> int:
        return int(sum(layer.dense_bytes(dtype_bytes) for layer in self.layers))

    def compression_ratio(self, dtype_bytes: int = 2) -> float:
        return self.dense_bytes(dtype_bytes) / max(self.storage_bytes(), 1)

    def memory_saved_pct(self, dtype_bytes: int = 2) -> float:
        dense = self.dense_bytes(dtype_bytes)
        return (1.0 - self.storage_bytes() / max(dense, 1)) * 100.0

    def seq_len(self) -> int:
        if not self.layers:
            return 0
        return int(self.layers[0].key.shape[-2])

    def to_dict(self) -> dict[str, Any]:
        dense = self.dense_bytes(2)
        storage = self.storage_bytes()
        return {
            "policy": self.policy.name,
            "layers": len(self.layers),
            "seq_len": self.seq_len(),
            "dense_fp16_bytes": dense,
            "compressed_storage_bytes": storage,
            "compression_ratio": dense / max(storage, 1),
            "memory_saved_pct": (1.0 - storage / max(dense, 1)) * 100.0,
            "layer_policies": [layer.effective_policy for layer in self.layers],
            "source_cache_type": self.source_cache_type,
            "source_requires_cache_object": self.source_requires_cache_object,
        }
