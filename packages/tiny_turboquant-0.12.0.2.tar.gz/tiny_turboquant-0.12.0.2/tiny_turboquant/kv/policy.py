"""Compressed KV policy definitions for the tiny-turboquant serving backend.

The policy layer is intentionally small.  It describes how K and V should be
stored between decode steps.  It does not claim fused compressed attention; the
v0.12.0.1 HF backend dequantizes the stored cache before calling the model again.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable


@dataclass(frozen=True)
class KVPolicy:
    """Storage policy for a compressed KV cache.

    Parameters
    ----------
    name:
        Public policy name used by the CLI and server.
    key_bits/value_bits:
        Bit width used for K and V storage.  ``16`` means dense fp16/bf16/fp32
        storage is preserved for that tensor.
    key_mode/value_mode:
        Human-readable storage mode.  In v0.12.0.1, ``turbo4`` is an alias for
        the int4 affine storage path so the serving UX can stabilize before
        fused TurboQuant kernels land.
    boundary_layer_count:
        First/last N transformer layers kept at least q8/q8 for safer defaults.
    """

    name: str
    key_bits: int
    value_bits: int
    key_mode: str = "affine"
    value_mode: str = "affine"
    boundary_layer_count: int = 0
    description: str = ""

    @property
    def compress_keys(self) -> bool:
        return self.key_bits < 16

    @property
    def compress_values(self) -> bool:
        return self.value_bits < 16

    @property
    def is_fp16(self) -> bool:
        return self.key_bits >= 16 and self.value_bits >= 16

    def layer_policy(self, layer_index: int, total_layers: int | None) -> "KVPolicy":
        """Return the effective policy for a layer.

        Boundary protection keeps the first and last N layers at q8/q8 if the
        base policy is more aggressive.  This mirrors the serving-safe habit of
        protecting sensitive layers without making the user pass a giant layer
        map on day one.
        """
        if self.boundary_layer_count <= 0 or total_layers is None:
            return self
        i = int(layer_index)
        n = int(total_layers)
        protect = i < self.boundary_layer_count or i >= max(0, n - self.boundary_layer_count)
        if not protect:
            return self
        return KVPolicy(
            name=f"{self.name}:boundary-q8",
            key_bits=max(self.key_bits, 8),
            value_bits=max(self.value_bits, 8),
            key_mode="affine",
            value_mode="affine",
            boundary_layer_count=0,
            description="boundary layer protected with at least q8/q8 storage",
        )


POLICIES: Dict[str, KVPolicy] = {
    "fp16": KVPolicy("fp16", 16, 16, "dense", "dense", 0, "store the Hugging Face KV cache densely"),
    "q8k-q8v": KVPolicy("q8k-q8v", 8, 8, "affine", "affine", 0, "conservative q8 key + q8 value cache"),
    "q8k-int4v": KVPolicy("q8k-int4v", 8, 4, "affine", "affine", 2, "q8 keys with int4 values and boundary protection"),
    "q8k-turbo4v": KVPolicy("q8k-turbo4v", 8, 4, "affine", "turbo4-alias", 2, "serving UX alias for q8 keys + 4-bit value storage"),
}


def available_kv_policies() -> list[str]:
    return sorted(POLICIES)


def resolve_kv_policy(name: str | KVPolicy) -> KVPolicy:
    if isinstance(name, KVPolicy):
        return name
    key = str(name).strip().lower()
    if key not in POLICIES:
        allowed = ", ".join(available_kv_policies())
        raise ValueError(f"unknown KV policy {name!r}; expected one of: {allowed}")
    return POLICIES[key]


def policy_table(policies: Iterable[str] | None = None) -> str:
    names = list(policies or available_kv_policies())
    lines = ["Policy | K | V | Boundary | Description", "---|---:|---:|---:|---"]
    for name in names:
        p = resolve_kv_policy(name)
        lines.append(f"{p.name} | {p.key_bits} | {p.value_bits} | {p.boundary_layer_count} | {p.description}")
    return "\n".join(lines)
