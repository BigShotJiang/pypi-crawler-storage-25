"""Experimental fused compressed decode-attention research utilities.

This module contains experimental fused compressed decode-attention prototypes, split-K diagnostics, and fixed-cache decode-loop benchmarks.  The supported fast path remains intentionally narrow:
query_len=1, batch_size=1, key_bits=8, affine per-page/per-channel K, and
value_bits in {4, 6, 8}.  Unsupported configurations fall back to the
quality-safe PyTorch compressed-page reference path and label that mode
explicitly. Reports include timing, quality, memory, setup/amortization, and speed/quality gaps against dense attention, SDPA, and Python reference paths.

This module does not claim production inference acceleration.
"""

from __future__ import annotations

import json
import time
from dataclasses import asdict, dataclass, replace
from pathlib import Path
from typing import Any, Dict, Optional, Tuple, List

import torch

try:  # optional dependency; Windows/CPU users should still import the package.
    import triton
    import triton.language as tl
except Exception:  # pragma: no cover - depends on runtime environment
    triton = None
    tl = None

from .attention import attention_similarity, dense_attention, sdpa_attention
from .attention_perf import _resolve_device, _resolve_dtype, _runtime_warnings, _sync, triton_status
from .layout import (
    CompressedKVPageTable,
    LayoutBenchConfig,
    compressed_page_attention_reference,
    resolve_layout_preset,
)


def _time_call(fn, *, device: str, warmup: int, repeats: int) -> Tuple[torch.Tensor, float]:
    out = None
    for _ in range(max(0, int(warmup))):
        out = fn()
    _sync(device)
    t0 = time.perf_counter()
    for _ in range(max(1, int(repeats))):
        out = fn()
    _sync(device)
    elapsed = (time.perf_counter() - t0) / max(1, int(repeats))
    assert out is not None
    return out, float(elapsed)


def _time_cuda_graph_call(fn, *, device: str, warmup: int, graph_replays: int) -> Tuple[Optional[torch.Tensor], Optional[float], Dict[str, Any]]:
    """Try to capture and replay a fixed-shape CUDA decode call.

    CUDA Graph replay is a benchmark mode, not a different algorithm. It can
    fail if the runtime, allocator, or called operators are not graph-safe. In
    that case the caller should keep the normal timing and report the reason.
    """
    if device != "cuda" or not torch.cuda.is_available():
        return None, None, {
            "attempted": False,
            "captured": False,
            "reason": "CUDA Graph replay requires a CUDA device",
        }
    if not hasattr(torch.cuda, "CUDAGraph"):
        return None, None, {
            "attempted": False,
            "captured": False,
            "reason": "torch.cuda.CUDAGraph is unavailable in this PyTorch build",
        }

    replays = max(1, int(graph_replays))
    try:
        out = None
        for _ in range(max(1, int(warmup))):
            out = fn()
        torch.cuda.synchronize()

        graph = torch.cuda.CUDAGraph()
        # Capture allocations into the graph memory pool. The captured output
        # tensor is reused on replay; the benchmark is valid for fixed-shape
        # decode microbenchmarks.
        with torch.cuda.graph(graph):
            out = fn()
        torch.cuda.synchronize()

        t0 = time.perf_counter()
        for _ in range(replays):
            graph.replay()
        torch.cuda.synchronize()
        seconds = (time.perf_counter() - t0) / replays
        assert out is not None
        return out, float(seconds), {
            "attempted": True,
            "captured": True,
            "replays": replays,
            "reason": "CUDA Graph capture and replay succeeded",
        }
    except Exception as exc:  # pragma: no cover - CUDA/runtime dependent
        try:
            torch.cuda.synchronize()
        except Exception:
            pass
        return None, None, {
            "attempted": True,
            "captured": False,
            "replays": replays,
            "reason": f"CUDA Graph capture/replay failed: {exc!r}",
        }


@dataclass
class FusedDecodeBenchConfig:
    """Configuration for experimental compressed decode-attention benchmarks."""

    batch_size: int = 1
    heads: int = 8
    query_len: int = 1
    seq_len: int = 2048
    head_dim: int = 64
    page_size: int = 128
    key_bits: int = 8
    value_bits: int = 6
    preset: Optional[str] = "safe-layout"
    quantization_mode: str = "affine"
    device: str = "auto"
    dtype: str = "auto"
    warmup: int = 1
    repeats: int = 3
    iters: Optional[int] = None
    seed: int = 123
    prefer_triton: bool = True
    kernel_block_m: int = 64
    kernel_num_warps: int = 4
    tune_kernel: bool = False
    tune_block_m_values: Tuple[int, ...] = (8, 16, 32, 64, 128)
    tune_num_warps: bool = False
    tune_num_warps_values: Tuple[int, ...] = (1, 2, 4, 8)
    tune_page_size: bool = False
    tune_page_size_values: Tuple[int, ...] = (64, 128, 256)
    cuda_graph: bool = False
    graph_replays: int = 100
    competitiveness_target: str = "sdpa"

    def __post_init__(self) -> None:
        if self.iters is not None:
            self.repeats = int(self.iters)
        if self.preset:
            cfg = resolve_layout_preset(self.preset)
            self.key_bits = int(cfg.get("key_bits", self.key_bits))
            self.value_bits = int(cfg.get("value_bits", self.value_bits))
            self.quantization_mode = str(cfg.get("quantization_mode", self.quantization_mode))
        if self.query_len != 1:
            # The v0.9 path is explicitly decode-only.  Keep this strict so
            # users do not confuse it with prefill attention.
            raise ValueError("FusedDecodeBenchConfig is decode-only: query_len must be 1")


def _triton_runtime_status() -> Dict[str, Any]:
    status = triton_status()
    # Keep a normalized field stable for reports.  v0.9.0 accidentally looked
    # for ``triton_available`` while triton_status() exposes ``available``.
    return {
        "available": bool(status.get("available", False)),
        "package_importable": bool(status.get("package_importable", False)),
        "cuda_available": bool(status.get("cuda_available", False)),
        "detail": status,
    }




if triton is not None and tl is not None:  # pragma: no cover - requires CUDA+Triton
    @triton.jit
    def _ttq_affine_decode_kernel(
        q_ptr,
        key_packed_ptr,
        value_packed_ptr,
        key_min_ptr,
        key_scale_ptr,
        value_min_ptr,
        value_scale_ptr,
        key_residual_packed_ptr,
        value_residual_packed_ptr,
        key_residual_scale_ptr,
        value_residual_scale_ptr,
        out_ptr,
        H: tl.constexpr,
        S: tl.constexpr,
        D: tl.constexpr,
        PAGE: tl.constexpr,
        PAGES: tl.constexpr,
        KEY_BITS: tl.constexpr,
        VALUE_BITS: tl.constexpr,
        HAS_RESIDUAL: tl.constexpr,
        BLOCK_M: tl.constexpr,
        BLOCK_D: tl.constexpr,
        SCALE: tl.constexpr,
    ):
        # One program computes one head for batch=1/query_len=1.  v0.10.9
        # extends the narrow Triton prototype to residual-affine pages and
        # low-bit K as well as V.  This is still an experimental microkernel,
        # not a general serving kernel.
        h = tl.program_id(0)
        offs_d = tl.arange(0, BLOCK_D)
        mask_d = offs_d < D
        q = tl.load(q_ptr + h * D + offs_d, mask=mask_d, other=0.0).to(tl.float32)

        m = tl.full((), -3.4028234663852886e38, tl.float32)
        l = tl.full((), 0.0, tl.float32)
        acc = tl.zeros((BLOCK_D,), tl.float32)
        offs_m = tl.arange(0, BLOCK_M)

        values_per_page = H * PAGE * D
        key_bytes_per_page = (values_per_page * KEY_BITS + 7) // 8
        value_bytes_per_page = (values_per_page * VALUE_BITS + 7) // 8
        residual_bytes_per_page = (values_per_page + 7) // 8

        for p in range(0, PAGES):
            k_min = tl.load(key_min_ptr + (p * H + h) * D + offs_d, mask=mask_d, other=0.0).to(tl.float32)
            k_scale = tl.load(key_scale_ptr + (p * H + h) * D + offs_d, mask=mask_d, other=1.0).to(tl.float32)
            v_min = tl.load(value_min_ptr + (p * H + h) * D + offs_d, mask=mask_d, other=0.0).to(tl.float32)
            v_scale = tl.load(value_scale_ptr + (p * H + h) * D + offs_d, mask=mask_d, other=1.0).to(tl.float32)

            if HAS_RESIDUAL:
                k_res_scale = tl.load(key_residual_scale_ptr + (p * H + h) * D + offs_d, mask=mask_d, other=0.0).to(tl.float32)
                v_res_scale = tl.load(value_residual_scale_ptr + (p * H + h) * D + offs_d, mask=mask_d, other=0.0).to(tl.float32)

            for start in range(0, PAGE, BLOCK_M):
                t = start + offs_m
                token_mask = t < PAGE
                flat = h * PAGE * D + t[:, None] * D + offs_d[None, :]
                mask = token_mask[:, None] & mask_d[None, :]

                if KEY_BITS == 8:
                    k_idx = tl.load(
                        key_packed_ptr + p * key_bytes_per_page + flat,
                        mask=mask,
                        other=0,
                    ).to(tl.float32)
                else:
                    k_bit_pos = flat * KEY_BITS
                    k_byte_pos = k_bit_pos // 8
                    k_shift = k_bit_pos - k_byte_pos * 8
                    kb0 = tl.load(
                        key_packed_ptr + p * key_bytes_per_page + k_byte_pos,
                        mask=mask,
                        other=0,
                    ).to(tl.uint32)
                    kb1 = tl.load(
                        key_packed_ptr + p * key_bytes_per_page + k_byte_pos + 1,
                        mask=mask & ((k_byte_pos + 1) < key_bytes_per_page),
                        other=0,
                    ).to(tl.uint32)
                    k_raw = kb0 | (kb1 << 8)
                    k_idx_i = (k_raw >> k_shift) & ((1 << KEY_BITS) - 1)
                    k_idx = k_idx_i.to(tl.float32)

                k_val = k_idx * k_scale[None, :] + k_min[None, :]

                if HAS_RESIDUAL:
                    sign_bit_pos = flat
                    sign_byte_pos = sign_bit_pos // 8
                    sign_shift = sign_bit_pos - sign_byte_pos * 8
                    ksb = tl.load(
                        key_residual_packed_ptr + p * residual_bytes_per_page + sign_byte_pos,
                        mask=mask,
                        other=0,
                    ).to(tl.uint32)
                    k_sign = ((ksb >> sign_shift) & 1).to(tl.float32) * 2.0 - 1.0
                    k_val = k_val + k_sign * k_res_scale[None, :]

                scores = tl.sum(k_val * q[None, :], axis=1) * SCALE
                scores = tl.where(token_mask, scores, -3.4028234663852886e38)
                block_m = tl.max(scores, axis=0)
                m_new = tl.maximum(m, block_m)
                alpha = tl.exp(m - m_new)
                probs = tl.exp(scores - m_new)

                if VALUE_BITS == 8:
                    v_idx = tl.load(
                        value_packed_ptr + p * value_bytes_per_page + flat,
                        mask=mask,
                        other=0,
                    ).to(tl.float32)
                else:
                    bit_pos = flat * VALUE_BITS
                    byte_pos = bit_pos // 8
                    shift = bit_pos - byte_pos * 8
                    b0 = tl.load(
                        value_packed_ptr + p * value_bytes_per_page + byte_pos,
                        mask=mask,
                        other=0,
                    ).to(tl.uint32)
                    b1 = tl.load(
                        value_packed_ptr + p * value_bytes_per_page + byte_pos + 1,
                        mask=mask & ((byte_pos + 1) < value_bytes_per_page),
                        other=0,
                    ).to(tl.uint32)
                    raw = b0 | (b1 << 8)
                    v_idx_i = (raw >> shift) & ((1 << VALUE_BITS) - 1)
                    v_idx = v_idx_i.to(tl.float32)

                v_val = v_idx * v_scale[None, :] + v_min[None, :]

                if HAS_RESIDUAL:
                    sign_bit_pos = flat
                    sign_byte_pos = sign_bit_pos // 8
                    sign_shift = sign_bit_pos - sign_byte_pos * 8
                    vsb = tl.load(
                        value_residual_packed_ptr + p * residual_bytes_per_page + sign_byte_pos,
                        mask=mask,
                        other=0,
                    ).to(tl.uint32)
                    v_sign = ((vsb >> sign_shift) & 1).to(tl.float32) * 2.0 - 1.0
                    v_val = v_val + v_sign * v_res_scale[None, :]

                acc = acc * alpha + tl.sum(probs[:, None] * v_val, axis=0)
                l = l * alpha + tl.sum(probs, axis=0)
                m = m_new

        out = acc / l
        tl.store(out_ptr + h * D + offs_d, out, mask=mask_d)

    @triton.jit
    def _ttq_split_k_stage1_kernel(
        q_ptr,
        key_packed_ptr,
        value_packed_ptr,
        key_min_ptr,
        key_scale_ptr,
        value_min_ptr,
        value_scale_ptr,
        key_residual_packed_ptr,
        value_residual_packed_ptr,
        key_residual_scale_ptr,
        value_residual_scale_ptr,
        partial_m_ptr,
        partial_l_ptr,
        partial_acc_ptr,
        H: tl.constexpr,
        S: tl.constexpr,
        D: tl.constexpr,
        PAGE: tl.constexpr,
        PAGES: tl.constexpr,
        SPLIT_K_SLABS: tl.constexpr,
        KEY_BITS: tl.constexpr,
        VALUE_BITS: tl.constexpr,
        HAS_RESIDUAL: tl.constexpr,
        BLOCK_M: tl.constexpr,
        BLOCK_D: tl.constexpr,
        SCALE: tl.constexpr,
    ):
        # v0.10.9 measured split-K Stage-1 partial kernel.  Each program
        # computes slab-local online-softmax statistics for one head and one
        # sequence slab.  Stage 2 reduction remains a Torch reference path in
        # this release.
        h = tl.program_id(0)
        slab = tl.program_id(1)
        offs_d = tl.arange(0, BLOCK_D)
        mask_d = offs_d < D
        q = tl.load(q_ptr + h * D + offs_d, mask=mask_d, other=0.0).to(tl.float32)

        m = tl.full((), -3.4028234663852886e38, tl.float32)
        l = tl.full((), 0.0, tl.float32)
        acc = tl.zeros((BLOCK_D,), tl.float32)
        offs_m = tl.arange(0, BLOCK_M)

        values_per_page = H * PAGE * D
        key_bytes_per_page = (values_per_page * KEY_BITS + 7) // 8
        value_bytes_per_page = (values_per_page * VALUE_BITS + 7) // 8
        residual_bytes_per_page = (values_per_page + 7) // 8
        pages_per_slab = (PAGES + SPLIT_K_SLABS - 1) // SPLIT_K_SLABS
        page_start = slab * pages_per_slab

        for local_p in range(0, pages_per_slab):
            p = page_start + local_p
            page_active = p < PAGES
            k_min = tl.load(key_min_ptr + (p * H + h) * D + offs_d, mask=page_active & mask_d, other=0.0).to(tl.float32)
            k_scale = tl.load(key_scale_ptr + (p * H + h) * D + offs_d, mask=page_active & mask_d, other=1.0).to(tl.float32)
            v_min = tl.load(value_min_ptr + (p * H + h) * D + offs_d, mask=page_active & mask_d, other=0.0).to(tl.float32)
            v_scale = tl.load(value_scale_ptr + (p * H + h) * D + offs_d, mask=page_active & mask_d, other=1.0).to(tl.float32)

            if HAS_RESIDUAL:
                k_res_scale = tl.load(key_residual_scale_ptr + (p * H + h) * D + offs_d, mask=page_active & mask_d, other=0.0).to(tl.float32)
                v_res_scale = tl.load(value_residual_scale_ptr + (p * H + h) * D + offs_d, mask=page_active & mask_d, other=0.0).to(tl.float32)

            for start in range(0, PAGE, BLOCK_M):
                t = start + offs_m
                token_mask = (t < PAGE) & page_active
                flat = h * PAGE * D + t[:, None] * D + offs_d[None, :]
                mask = token_mask[:, None] & mask_d[None, :]

                if KEY_BITS == 8:
                    k_idx = tl.load(
                        key_packed_ptr + p * key_bytes_per_page + flat,
                        mask=mask,
                        other=0,
                    ).to(tl.float32)
                else:
                    k_bit_pos = flat * KEY_BITS
                    k_byte_pos = k_bit_pos // 8
                    k_shift = k_bit_pos - k_byte_pos * 8
                    kb0 = tl.load(
                        key_packed_ptr + p * key_bytes_per_page + k_byte_pos,
                        mask=mask,
                        other=0,
                    ).to(tl.uint32)
                    kb1 = tl.load(
                        key_packed_ptr + p * key_bytes_per_page + k_byte_pos + 1,
                        mask=mask & ((k_byte_pos + 1) < key_bytes_per_page),
                        other=0,
                    ).to(tl.uint32)
                    k_raw = kb0 | (kb1 << 8)
                    k_idx_i = (k_raw >> k_shift) & ((1 << KEY_BITS) - 1)
                    k_idx = k_idx_i.to(tl.float32)

                k_val = k_idx * k_scale[None, :] + k_min[None, :]

                if HAS_RESIDUAL:
                    sign_bit_pos = flat
                    sign_byte_pos = sign_bit_pos // 8
                    sign_shift = sign_bit_pos - sign_byte_pos * 8
                    ksb = tl.load(
                        key_residual_packed_ptr + p * residual_bytes_per_page + sign_byte_pos,
                        mask=mask,
                        other=0,
                    ).to(tl.uint32)
                    k_sign = ((ksb >> sign_shift) & 1).to(tl.float32) * 2.0 - 1.0
                    k_val = k_val + k_sign * k_res_scale[None, :]

                scores = tl.sum(k_val * q[None, :], axis=1) * SCALE
                scores = tl.where(token_mask, scores, -3.4028234663852886e38)
                block_m = tl.max(scores, axis=0)
                m_new = tl.maximum(m, block_m)
                alpha = tl.exp(m - m_new)
                probs = tl.exp(scores - m_new)

                if VALUE_BITS == 8:
                    v_idx = tl.load(
                        value_packed_ptr + p * value_bytes_per_page + flat,
                        mask=mask,
                        other=0,
                    ).to(tl.float32)
                else:
                    bit_pos = flat * VALUE_BITS
                    byte_pos = bit_pos // 8
                    shift = bit_pos - byte_pos * 8
                    b0 = tl.load(
                        value_packed_ptr + p * value_bytes_per_page + byte_pos,
                        mask=mask,
                        other=0,
                    ).to(tl.uint32)
                    b1 = tl.load(
                        value_packed_ptr + p * value_bytes_per_page + byte_pos + 1,
                        mask=mask & ((byte_pos + 1) < value_bytes_per_page),
                        other=0,
                    ).to(tl.uint32)
                    raw = b0 | (b1 << 8)
                    v_idx_i = (raw >> shift) & ((1 << VALUE_BITS) - 1)
                    v_idx = v_idx_i.to(tl.float32)

                v_val = v_idx * v_scale[None, :] + v_min[None, :]

                if HAS_RESIDUAL:
                    sign_bit_pos = flat
                    sign_byte_pos = sign_bit_pos // 8
                    sign_shift = sign_bit_pos - sign_byte_pos * 8
                    vsb = tl.load(
                        value_residual_packed_ptr + p * residual_bytes_per_page + sign_byte_pos,
                        mask=mask,
                        other=0,
                    ).to(tl.uint32)
                    v_sign = ((vsb >> sign_shift) & 1).to(tl.float32) * 2.0 - 1.0
                    v_val = v_val + v_sign * v_res_scale[None, :]

                acc = acc * alpha + tl.sum(probs[:, None] * v_val, axis=0)
                l = l * alpha + tl.sum(probs, axis=0)
                m = m_new

        idx = slab * H + h
        tl.store(partial_m_ptr + idx, m)
        tl.store(partial_l_ptr + idx, l)
        tl.store(partial_acc_ptr + idx * D + offs_d, acc, mask=mask_d)

    @triton.jit
    def _ttq_split_k_stage2_reduce_kernel(
        partial_m_ptr,
        partial_l_ptr,
        partial_acc_ptr,
        out_ptr,
        H: tl.constexpr,
        D: tl.constexpr,
        SLABS: tl.constexpr,
        BLOCK_D: tl.constexpr,
    ):
        # v0.10.9 Triton Stage-2 reducer.  One program reduces all split-K
        # slab partials for one head.  The Stage-1 contract is:
        # partial_acc = sum(exp(score - local_max) * V), i.e. unnormalized.
        h = tl.program_id(0)
        offs_d = tl.arange(0, BLOCK_D)
        mask_d = offs_d < D

        global_m = tl.full((), -3.4028234663852886e38, tl.float32)
        for slab in range(0, SLABS):
            m = tl.load(partial_m_ptr + slab * H + h).to(tl.float32)
            global_m = tl.maximum(global_m, m)

        denom = tl.full((), 0.0, tl.float32)
        acc = tl.zeros((BLOCK_D,), tl.float32)
        for slab in range(0, SLABS):
            m = tl.load(partial_m_ptr + slab * H + h).to(tl.float32)
            l = tl.load(partial_l_ptr + slab * H + h).to(tl.float32)
            w = tl.exp(m - global_m)
            vals = tl.load(
                partial_acc_ptr + (slab * H + h) * D + offs_d,
                mask=mask_d,
                other=0.0,
            ).to(tl.float32)
            acc += w * vals
            denom += w * l

        out = acc / denom
        tl.store(out_ptr + h * D + offs_d, out, mask=mask_d)
else:  # pragma: no cover
    _ttq_affine_decode_kernel = None
    _ttq_split_k_stage1_kernel = None
    _ttq_split_k_stage2_reduce_kernel = None


def _is_supported_triton_config(query: torch.Tensor, page_table: CompressedKVPageTable) -> Tuple[bool, str]:
    if triton is None or tl is None or _ttq_affine_decode_kernel is None:
        return False, "triton package is not importable"
    if not query.is_cuda:
        return False, "query is not on CUDA"
    if query.ndim != 4 or query.shape[0] != 1 or query.shape[2] != 1:
        return False, "v0.10.9 Triton prototype supports batch=1 and query_len=1 only"
    if page_table.quantization_mode not in {"affine", "residual-affine"}:
        return False, "v0.10.9 Triton prototype supports affine and residual-affine layouts only"
    if page_table.page_count <= 0:
        return False, "page table is empty"
    if page_table.dense_shape[0] != 1:
        return False, "v0.10.9 Triton prototype supports batch=1 page tables only"
    if page_table.head_dim not in (32, 64, 128):
        return False, "v0.10.9 Triton prototype supports head_dim in {32,64,128}"
    if any(p.key_bits not in (4, 6, 8) for p in page_table.pages):
        return False, "v0.10.9 Triton prototype supports key_bits in {4,6,8}"
    if any(p.value_bits not in (4, 6, 8) for p in page_table.pages):
        return False, "v0.10.9 Triton prototype supports value_bits in {4,6,8}"
    if len({p.key_bits for p in page_table.pages}) != 1:
        return False, "all pages must use the same key_bits"
    if len({p.value_bits for p in page_table.pages}) != 1:
        return False, "all pages must use the same value_bits"
    if len({p.page_length for p in page_table.pages}) != 1:
        return False, "all pages must have the same page length"
    if page_table.pages[0].page_length != page_table.page_size:
        return False, "v0.10.9 Triton prototype requires full pages; pad or use divisible seq_len"
    if page_table.quantization_mode == "residual-affine":
        if any(p.key_residual_packed is None or p.value_residual_packed is None for p in page_table.pages):
            return False, "residual-affine pages must include residual sign payloads"
    return True, "supported"


def _concat_page_payloads(page_table: CompressedKVPageTable) -> Dict[str, torch.Tensor]:
    pages = page_table.pages
    key_packed = torch.cat([p.key_packed.reshape(-1) for p in pages]).contiguous()
    value_packed = torch.cat([p.value_packed.reshape(-1) for p in pages]).contiguous()
    key_min = torch.cat([p.key_min.squeeze(0).squeeze(1) for p in pages], dim=0).contiguous()
    key_scale = torch.cat([p.key_scale.squeeze(0).squeeze(1) for p in pages], dim=0).contiguous()
    value_min = torch.cat([p.value_min.squeeze(0).squeeze(1) for p in pages], dim=0).contiguous()
    value_scale = torch.cat([p.value_scale.squeeze(0).squeeze(1) for p in pages], dim=0).contiguous()

    device = key_packed.device
    if page_table.quantization_mode == "residual-affine":
        key_residual_packed = torch.cat([p.key_residual_packed.reshape(-1) for p in pages]).contiguous()
        value_residual_packed = torch.cat([p.value_residual_packed.reshape(-1) for p in pages]).contiguous()
        key_residual_scale = torch.cat([p.key_residual_scale.squeeze(0).squeeze(1) for p in pages], dim=0).contiguous()
        value_residual_scale = torch.cat([p.value_residual_scale.squeeze(0).squeeze(1) for p in pages], dim=0).contiguous()
    else:
        key_residual_packed = torch.empty(1, device=device, dtype=torch.uint8)
        value_residual_packed = torch.empty(1, device=device, dtype=torch.uint8)
        key_residual_scale = torch.empty_like(key_min)
        value_residual_scale = torch.empty_like(value_min)

    return {
        "key_packed": key_packed,
        "value_packed": value_packed,
        "key_min": key_min,
        "key_scale": key_scale,
        "value_min": value_min,
        "value_scale": value_scale,
        "key_residual_packed": key_residual_packed,
        "value_residual_packed": value_residual_packed,
        "key_residual_scale": key_residual_scale,
        "value_residual_scale": value_residual_scale,
    }


def _triton_fused_affine_decode_attention(
    query: torch.Tensor,
    page_table: CompressedKVPageTable,
    *,
    kernel_block_m: int = 64,
    kernel_num_warps: int = 4,
) -> torch.Tensor:
    ok, reason = _is_supported_triton_config(query, page_table)
    if not ok:
        raise RuntimeError(reason)
    if int(kernel_block_m) not in (8, 16, 32, 64, 128):
        raise RuntimeError("v0.10.9 Triton prototype supports kernel_block_m in {8,16,32,64,128}")
    if int(kernel_num_warps) not in (1, 2, 4, 8):
        raise RuntimeError("v0.10.9 Triton prototype supports kernel_num_warps in {1,2,4,8}")
    q_rot = page_table.rotate_query(query).contiguous()
    payloads = _concat_page_payloads(page_table)
    b, h, s, d = page_table.dense_shape
    page_size = int(page_table.page_size)
    pages = int(page_table.page_count)
    key_bits = int(page_table.pages[0].key_bits)
    value_bits = int(page_table.pages[0].value_bits)
    has_residual = page_table.quantization_mode == "residual-affine"
    out = torch.empty((1, h, 1, d), device=query.device, dtype=query.dtype)
    # v0.10.9 exposes BLOCK_M so users can tune page-loop granularity.
    block_d = 1 << ((d - 1).bit_length())
    block_m = int(kernel_block_m)
    _ttq_affine_decode_kernel[(h,)](
        q_rot,
        payloads["key_packed"],
        payloads["value_packed"],
        payloads["key_min"],
        payloads["key_scale"],
        payloads["value_min"],
        payloads["value_scale"],
        payloads["key_residual_packed"],
        payloads["value_residual_packed"],
        payloads["key_residual_scale"],
        payloads["value_residual_scale"],
        out,
        H=h,
        S=s,
        D=d,
        PAGE=page_size,
        PAGES=pages,
        KEY_BITS=key_bits,
        VALUE_BITS=value_bits,
        HAS_RESIDUAL=has_residual,
        BLOCK_M=block_m,
        BLOCK_D=block_d,
        SCALE=float(d ** -0.5),
        num_warps=int(kernel_num_warps),
    )
    return out

def triton_split_k_stage1_partials(
    query: torch.Tensor,
    page_table: CompressedKVPageTable,
    *,
    split_k_slabs: int = 4,
    kernel_block_m: int = 64,
    kernel_num_warps: int = 4,
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, Dict[str, Any]]:
    """Run the v0.10.9 Triton Stage-1 split-K partial-statistics kernel.

    Returns ``(partial_m, partial_l, partial_acc, metadata)`` where:
    - partial_m is shaped ``(slabs, heads)``
    - partial_l is shaped ``(slabs, heads)``
    - partial_acc is shaped ``(slabs, heads, head_dim)``

    This is only Stage 1. Stage 2 reduction is intentionally a separate
    reference step in v0.10.9.
    """
    ok, reason = _is_supported_triton_config(query, page_table)
    if not ok:
        raise RuntimeError(reason)
    if triton is None or tl is None or _ttq_split_k_stage1_kernel is None:
        raise RuntimeError("v0.10.9 Triton split-K Stage-1 kernel is unavailable")
    if int(kernel_block_m) not in (8, 16, 32, 64, 128):
        raise RuntimeError("v0.10.9 Triton split-K Stage-1 supports kernel_block_m in {8,16,32,64,128}")
    if int(kernel_num_warps) not in (1, 2, 4, 8):
        raise RuntimeError("v0.10.9 Triton split-K Stage-1 supports kernel_num_warps in {1,2,4,8}")
    slabs = max(1, int(split_k_slabs))
    q_rot = page_table.rotate_query(query).contiguous()
    payloads = _concat_page_payloads(page_table)
    b, h, s, d = page_table.dense_shape
    page_size = int(page_table.page_size)
    pages = int(page_table.page_count)
    key_bits = int(page_table.pages[0].key_bits)
    value_bits = int(page_table.pages[0].value_bits)
    has_residual = page_table.quantization_mode == "residual-affine"
    partial_m = torch.empty((slabs, h), device=query.device, dtype=torch.float32)
    partial_l = torch.empty((slabs, h), device=query.device, dtype=torch.float32)
    partial_acc = torch.empty((slabs, h, d), device=query.device, dtype=torch.float32)
    block_d = 1 << ((d - 1).bit_length())
    _ttq_split_k_stage1_kernel[(h, slabs)](
        q_rot,
        payloads["key_packed"],
        payloads["value_packed"],
        payloads["key_min"],
        payloads["key_scale"],
        payloads["value_min"],
        payloads["value_scale"],
        payloads["key_residual_packed"],
        payloads["value_residual_packed"],
        payloads["key_residual_scale"],
        payloads["value_residual_scale"],
        partial_m,
        partial_l,
        partial_acc,
        H=h,
        S=s,
        D=d,
        PAGE=page_size,
        PAGES=pages,
        SPLIT_K_SLABS=slabs,
        KEY_BITS=key_bits,
        VALUE_BITS=value_bits,
        HAS_RESIDUAL=has_residual,
        BLOCK_M=int(kernel_block_m),
        BLOCK_D=block_d,
        SCALE=float(d ** -0.5),
        num_warps=int(kernel_num_warps),
    )
    meta = {
        "mode": "triton-split-k-stage1-partials",
        "split_k_slabs": slabs,
        "kernel_block_m": int(kernel_block_m),
        "kernel_num_warps": int(kernel_num_warps),
        "quantization_mode": page_table.quantization_mode,
        "uses_compressed_pages_directly": True,
        "constructs_full_dense_kv": False,
        "boundary": "Stage-1 partial statistics only; Stage-2 Triton reducer is future work",
    }
    return partial_m, partial_l, partial_acc, meta


def triton_split_k_stage2_reduce(
    partial_m: torch.Tensor,
    partial_l: torch.Tensor,
    partial_acc: torch.Tensor,
    *,
    output_dtype: Optional[torch.dtype] = None,
    kernel_num_warps: int = 1,
) -> Tuple[torch.Tensor, Dict[str, Any]]:
    """Run the v0.10.9 Triton Stage-2 split-K reducer.

    Stage 1 must provide unnormalized accumulators:
    ``partial_acc = sum(exp(score - local_max) * V)``.  The reducer combines
    the slab-local statistics with log-sum-exp correction entirely in Triton.
    """
    if triton is None or tl is None or _ttq_split_k_stage2_reduce_kernel is None:
        raise RuntimeError("v0.10.9 Triton split-K Stage-2 reducer is unavailable")
    if not partial_m.is_cuda or not partial_l.is_cuda or not partial_acc.is_cuda:
        raise RuntimeError("v0.10.9 Triton split-K Stage-2 reducer requires CUDA tensors")
    if partial_m.ndim != 2 or partial_l.ndim != 2 or partial_acc.ndim != 3:
        raise ValueError("partial_m/partial_l/partial_acc must be shaped (slabs, heads), (slabs, heads), (slabs, heads, head_dim)")
    slabs, heads = partial_m.shape
    if partial_l.shape != (slabs, heads) or partial_acc.shape[:2] != (slabs, heads):
        raise ValueError("split-K partial tensor shapes do not agree")
    d = int(partial_acc.shape[-1])
    if d not in (32, 64, 128):
        raise RuntimeError("v0.10.9 Triton Stage-2 reducer supports head_dim in {32,64,128}")
    if int(kernel_num_warps) not in (1, 2, 4, 8):
        raise RuntimeError("v0.10.9 Triton Stage-2 reducer supports kernel_num_warps in {1,2,4,8}")
    dtype = output_dtype or partial_acc.dtype
    out = torch.empty((1, heads, 1, d), device=partial_acc.device, dtype=dtype)
    block_d = 1 << ((d - 1).bit_length())
    _ttq_split_k_stage2_reduce_kernel[(heads,)](
        partial_m.contiguous(),
        partial_l.contiguous(),
        partial_acc.contiguous(),
        out,
        H=int(heads),
        D=int(d),
        SLABS=int(slabs),
        BLOCK_D=int(block_d),
        num_warps=int(kernel_num_warps),
    )
    meta = {
        "mode": "triton-split-k-stage2-reducer",
        "split_k_slabs": int(slabs),
        "kernel_num_warps": int(kernel_num_warps),
        "output_dtype": str(dtype).replace("torch.", ""),
        "stage1_contract": "partial_acc is unnormalized sum(exp(score-local_max) * V)",
        "boundary": "Stage-2 reducer only; full production FlashDecoding remains future work",
    }
    return out, meta



def _triton_split_k_stage1_partials_prepared(
    q_rot: torch.Tensor,
    payloads: Dict[str, torch.Tensor],
    page_table: CompressedKVPageTable,
    partial_m: torch.Tensor,
    partial_l: torch.Tensor,
    partial_acc: torch.Tensor,
    *,
    split_k_slabs: int,
    kernel_block_m: int,
    kernel_num_warps: int,
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    """Launch Stage-1 with pre-rotated Q, concatenated payloads, and reusable outputs.

    v0.10.9 uses this in benchmarking to avoid counting repeated Python-side
    layout preparation, tensor concatenation, query rotation, and output
    allocation as part of the Stage-1 kernel timing.  The public
    ``triton_split_k_stage1_partials`` function remains unchanged and still
    performs preparation for convenience.
    """
    b, h, s, d = page_table.dense_shape
    page_size = int(page_table.page_size)
    pages = int(page_table.page_count)
    key_bits = int(page_table.pages[0].key_bits)
    value_bits = int(page_table.pages[0].value_bits)
    has_residual = page_table.quantization_mode == "residual-affine"
    block_d = 1 << ((d - 1).bit_length())
    _ttq_split_k_stage1_kernel[(h, int(split_k_slabs))](
        q_rot,
        payloads["key_packed"],
        payloads["value_packed"],
        payloads["key_min"],
        payloads["key_scale"],
        payloads["value_min"],
        payloads["value_scale"],
        payloads["key_residual_packed"],
        payloads["value_residual_packed"],
        payloads["key_residual_scale"],
        payloads["value_residual_scale"],
        partial_m,
        partial_l,
        partial_acc,
        H=h,
        S=s,
        D=d,
        PAGE=page_size,
        PAGES=pages,
        SPLIT_K_SLABS=int(split_k_slabs),
        KEY_BITS=key_bits,
        VALUE_BITS=value_bits,
        HAS_RESIDUAL=has_residual,
        BLOCK_M=int(kernel_block_m),
        BLOCK_D=block_d,
        SCALE=float(d ** -0.5),
        num_warps=int(kernel_num_warps),
    )
    return partial_m, partial_l, partial_acc


def _triton_split_k_stage2_reduce_prepared(
    partial_m: torch.Tensor,
    partial_l: torch.Tensor,
    partial_acc: torch.Tensor,
    out: torch.Tensor,
    *,
    kernel_num_warps: int = 1,
) -> torch.Tensor:
    """Launch Stage-2 into a reusable output tensor.

    This keeps v0.10.9 full split-K timing focused on Triton work rather than
    allocation overhead.
    """
    slabs, heads = partial_m.shape
    d = int(partial_acc.shape[-1])
    block_d = 1 << ((d - 1).bit_length())
    _ttq_split_k_stage2_reduce_kernel[(heads,)](
        partial_m,
        partial_l,
        partial_acc,
        out,
        H=int(heads),
        D=int(d),
        SLABS=int(slabs),
        BLOCK_D=int(block_d),
        num_warps=int(kernel_num_warps),
    )
    return out

def triton_split_k_full_attention_reference(
    query: torch.Tensor,
    page_table: CompressedKVPageTable,
    *,
    split_k_slabs: int = 4,
    kernel_block_m: int = 64,
    kernel_num_warps: int = 4,
    reducer_num_warps: int = 1,
) -> Tuple[torch.Tensor, Dict[str, Any]]:
    """Run real Triton Stage 1 plus real Triton Stage 2 reducer.

    This is the v0.10.9 measured full split-K research path.  It is still a
    microbenchmark prototype, not a production serving kernel.
    """
    pm, pl, pa, meta1 = triton_split_k_stage1_partials(
        query,
        page_table,
        split_k_slabs=split_k_slabs,
        kernel_block_m=kernel_block_m,
        kernel_num_warps=kernel_num_warps,
    )
    out, meta2 = triton_split_k_stage2_reduce(
        pm,
        pl,
        pa,
        output_dtype=query.dtype,
        kernel_num_warps=reducer_num_warps,
    )
    meta = {
        "mode": "triton-two-stage-split-k",
        "stage1": meta1,
        "stage2": meta2,
        "uses_compressed_pages_directly": True,
        "constructs_full_dense_kv": False,
        "boundary": "measured research split-K path; not a production serving kernel",
    }
    return out, meta


def reduce_split_k_partials(partial_m: torch.Tensor, partial_l: torch.Tensor, partial_acc: torch.Tensor, *, output_dtype: Optional[torch.dtype] = None) -> torch.Tensor:
    """Reference Stage-2 log-sum-exp reduction for Stage-1 split-K partials.

    Contract fixed in v0.10.9:
    ``partial_acc`` must be the **unnormalized** slab accumulator
    ``sum(exp(score - local_max) * V)``.  Therefore the global reducer must
    scale ``partial_acc`` only by ``exp(local_max - global_max)``.  It must not
    multiply ``partial_acc`` by ``partial_l`` again.  Multiplying by
    ``partial_l`` is only correct when Stage 1 stores a locally normalized
    attention output, which this package does not do.
    """
    m_global = torch.max(partial_m, dim=0).values  # (H,)
    slab_scale = torch.exp(partial_m - m_global.unsqueeze(0))
    denom = torch.sum(slab_scale * partial_l, dim=0).clamp_min(1e-30)
    acc = torch.sum(slab_scale.unsqueeze(-1) * partial_acc, dim=0) / denom.unsqueeze(-1)
    if output_dtype is not None:
        acc = acc.to(output_dtype)
    return acc.unsqueeze(0).unsqueeze(2)


def triton_split_k_stage1_attention_reference(
    query: torch.Tensor,
    page_table: CompressedKVPageTable,
    *,
    split_k_slabs: int = 4,
    kernel_block_m: int = 64,
    kernel_num_warps: int = 4,
) -> Tuple[torch.Tensor, Dict[str, Any]]:
    """Run Triton Stage 1 plus Torch Stage 2 reduction for correctness checks."""
    pm, pl, pa, meta = triton_split_k_stage1_partials(
        query,
        page_table,
        split_k_slabs=split_k_slabs,
        kernel_block_m=kernel_block_m,
        kernel_num_warps=kernel_num_warps,
    )
    out = reduce_split_k_partials(pm, pl, pa, output_dtype=query.dtype)
    meta = dict(meta)
    meta["mode"] = "triton-stage1-plus-torch-reduce-reference"
    meta["stage2"] = "torch-logsumexp-reference"
    return out, meta


def experimental_fused_compressed_decode_attention(
    query: torch.Tensor,
    page_table: CompressedKVPageTable,
    *,
    prefer_triton: bool = True,
    kernel_block_m: int = 64,
    kernel_num_warps: int = 4,
) -> Tuple[torch.Tensor, Dict[str, Any]]:
    """Run the v0.10.9 experimental compressed decode-attention path.

    The function consumes the compressed page table directly and avoids full
    dense K/V reconstruction.  When the narrow Triton prototype supports the
    supplied configuration, it runs that kernel.  Otherwise it falls back to the
    verified PyTorch compressed-page reference and reports the fallback clearly.
    """

    if query.ndim != 4:
        raise ValueError("query must be shaped (B, H, 1, D)")
    if query.shape[2] != 1:
        raise ValueError("experimental fused decode attention supports query_len=1 only")

    runtime = _triton_runtime_status()
    supported, support_reason = _is_supported_triton_config(query, page_table)
    can_attempt_triton = bool(prefer_triton) and runtime["available"] and runtime["cuda_available"] and supported

    triton_error: Optional[str] = None
    if can_attempt_triton:
        try:
            out = _triton_fused_affine_decode_attention(query, page_table, kernel_block_m=kernel_block_m, kernel_num_warps=kernel_num_warps)
            meta = {
                "mode": ("triton-fused-residual-affine-decode" if page_table.quantization_mode == "residual-affine" else "triton-fused-affine-decode"),
                "triton_attempted": True,
                "triton_runtime": runtime,
                "reason": ("minimal v0.10.9 Triton fused residual-affine decode kernel executed" if page_table.quantization_mode == "residual-affine" else "minimal v0.10.9 Triton fused affine decode kernel executed"),
                "support_check": support_reason,
                "query_len": int(query.shape[2]),
                "kernel_block_m": int(kernel_block_m),
                "kernel_num_warps": int(kernel_num_warps),
                "quantization_mode": page_table.quantization_mode,
                "uses_compressed_pages_directly": True,
                "constructs_full_dense_kv": False,
                "boundary": "experimental Triton prototype; not a production serving kernel",
            }
            return out, meta
        except Exception as exc:  # pragma: no cover - depends on Triton runtime/GPU
            triton_error = repr(exc)

    reason = support_reason
    if not prefer_triton:
        reason = "prefer_triton=False; using PyTorch compressed-page fallback"
    elif not runtime["available"] or not runtime["cuda_available"]:
        reason = "triton runtime unavailable"
    elif triton_error:
        reason = f"triton kernel failed; using fallback: {triton_error}"

    out = compressed_page_attention_reference(query, page_table, rotate_query=True)
    meta = {
        "mode": "torch-compressed-page-fallback",
        "triton_attempted": bool(can_attempt_triton),
        "triton_runtime": runtime,
        "reason": reason,
        "support_check": support_reason,
        "triton_error": triton_error,
        "query_len": int(query.shape[2]),
        "kernel_block_m": int(kernel_block_m),
        "kernel_num_warps": int(kernel_num_warps),
        "uses_compressed_pages_directly": True,
        "constructs_full_dense_kv": False,
        "boundary": "experimental research path; fallback is not a production fused CUDA/Triton kernel",
    }
    return out, meta

def _build_random_qkv(config: FusedDecodeBenchConfig, device: str, dtype: torch.dtype):
    torch.manual_seed(int(config.seed))
    q = torch.randn(config.batch_size, config.heads, 1, config.head_dim, device=device, dtype=dtype)
    k = torch.randn(config.batch_size, config.heads, config.seq_len, config.head_dim, device=device, dtype=dtype)
    v = torch.randn_like(k)
    return q, k, v


def _quality_warning(metrics: Dict[str, float]) -> str:
    rel = float(metrics.get("relative_error", 999.0))
    cos = float(metrics.get("cosine_similarity", 0.0))
    if cos >= 0.99 and rel <= 0.05:
        return "ok: fused prototype output is close to dense in this benchmark."
    if cos >= 0.95:
        return "caution: fused prototype is directionally close, but error is still material."
    return "weak: fused prototype quality is not safe for kernel work with this layout."




def _safe_ratio(numerator: float, denominator: float) -> Optional[float]:
    if denominator is None or denominator <= 0:
        return None
    return float(numerator) / float(denominator)


def _tensor_finite_status(x: Optional[torch.Tensor]) -> Dict[str, Any]:
    if x is None:
        return {"finite": False, "reason": "missing tensor"}
    with torch.no_grad():
        finite = torch.isfinite(x)
        finite_count = int(finite.sum().item())
        total = int(x.numel())
        nan_count = int(torch.isnan(x).sum().item())
        inf_count = int(torch.isinf(x).sum().item())
    return {
        "finite": bool(finite_count == total),
        "finite_count": finite_count,
        "total_count": total,
        "nan_count": nan_count,
        "inf_count": inf_count,
    }


def _safe_attention_similarity(reference: Optional[torch.Tensor], candidate: Optional[torch.Tensor]) -> Dict[str, Any]:
    ref_status = _tensor_finite_status(reference)
    cand_status = _tensor_finite_status(candidate)
    if not ref_status.get("finite") or not cand_status.get("finite"):
        return {
            "relative_error": None,
            "cosine_similarity": None,
            "reference_finite": ref_status,
            "candidate_finite": cand_status,
            "quality_valid": False,
        }
    metrics = attention_similarity(reference, candidate)  # type: ignore[arg-type]
    rel = metrics.get("relative_error")
    cos = metrics.get("cosine_similarity")
    rel_ok = rel is not None and torch.isfinite(torch.tensor(float(rel))).item()
    cos_ok = cos is not None and torch.isfinite(torch.tensor(float(cos))).item()
    if not rel_ok or not cos_ok:
        return {
            "relative_error": None,
            "cosine_similarity": None,
            "reference_finite": ref_status,
            "candidate_finite": cand_status,
            "quality_valid": False,
        }
    out = dict(metrics)
    out.update({
        "reference_finite": ref_status,
        "candidate_finite": cand_status,
        "quality_valid": True,
    })
    return out


def _candidate_block_values(config: FusedDecodeBenchConfig) -> List[int]:
    if config.tune_kernel:
        vals = [int(v) for v in config.tune_block_m_values]
    else:
        vals = [int(config.kernel_block_m)]
    out: List[int] = []
    for v in vals:
        if v in (8, 16, 32, 64, 128) and v not in out:
            out.append(v)
    if not out:
        out = [64]
    return out


def _candidate_warp_values(config: FusedDecodeBenchConfig) -> List[int]:
    if config.tune_num_warps:
        vals = [int(v) for v in config.tune_num_warps_values]
    else:
        vals = [int(config.kernel_num_warps)]
    out: List[int] = []
    for v in vals:
        if v in (1, 2, 4, 8) and v not in out:
            out.append(v)
    if not out:
        out = [4]
    return out

def _run_fused_decode_benchmark_core(config: FusedDecodeBenchConfig) -> Dict[str, Any]:
    """Benchmark dense, SDPA, compressed-page reference, and v0.9 fused path for one page size."""

    requested_device = config.device
    requested_dtype = config.dtype
    device = _resolve_device(requested_device)
    dtype = _resolve_dtype(requested_dtype, device)
    warnings = _runtime_warnings(requested_device, device, requested_dtype, dtype)

    q, k, v = _build_random_qkv(config, device, dtype)

    t0 = time.perf_counter()
    table = CompressedKVPageTable.from_dense(
        k,
        v,
        key_bits=config.key_bits,
        value_bits=config.value_bits,
        page_size=config.page_size,
        seed=config.seed,
        dtype_bytes=torch.empty((), dtype=dtype).element_size(),
        quantization_mode=config.quantization_mode,
    )
    layout_build_seconds = time.perf_counter() - t0

    dense_out, dense_seconds = _time_call(
        lambda: dense_attention(q, k, v),
        device=device,
        warmup=config.warmup,
        repeats=config.repeats,
    )

    try:
        sdpa_out, sdpa_seconds = _time_call(
            lambda: sdpa_attention(q, k, v),
            device=device,
            warmup=config.warmup,
            repeats=config.repeats,
        )
        sdpa_report: Optional[Dict[str, Any]] = {
            "seconds": sdpa_seconds,
            "similarity_to_dense": attention_similarity(dense_out, sdpa_out),
        }
    except Exception as exc:  # pragma: no cover depends on torch build/backend
        sdpa_report = {"error": repr(exc)}

    reference_out, reference_seconds = _time_call(
        lambda: compressed_page_attention_reference(q, table, rotate_query=True),
        device=device,
        warmup=config.warmup,
        repeats=config.repeats,
    )

    fused_meta_holder: Dict[str, Any] = {}
    tuning_rows: List[Dict[str, Any]] = []
    selected_block_m = int(config.kernel_block_m)
    fused_out: Optional[torch.Tensor] = None
    fused_seconds: float = 0.0

    selected_num_warps = int(config.kernel_num_warps)
    for block_m in _candidate_block_values(config):
        for num_warps in _candidate_warp_values(config):
            local_meta: Dict[str, Any] = {}

            def _run_fused(block_m=block_m, num_warps=num_warps):
                out, meta = experimental_fused_compressed_decode_attention(
                    q,
                    table,
                    prefer_triton=config.prefer_triton,
                    kernel_block_m=block_m,
                    kernel_num_warps=num_warps,
                )
                local_meta.clear()
                local_meta.update(meta)
                return out

            out_i, sec_i = _time_call(
                _run_fused,
                device=device,
                warmup=config.warmup,
                repeats=config.repeats,
            )
            q_i = attention_similarity(dense_out, out_i)
            row = {
                "kernel_block_m": int(block_m),
                "kernel_num_warps": int(num_warps),
                "seconds": float(sec_i),
                "mode": local_meta.get("mode"),
                "relative_error": q_i.get("relative_error"),
                "cosine_similarity": q_i.get("cosine_similarity"),
            }
            tuning_rows.append(row)

            if fused_out is None or sec_i < fused_seconds:
                fused_out = out_i
                fused_seconds = float(sec_i)
                selected_block_m = int(block_m)
                selected_num_warps = int(num_warps)
                fused_meta_holder.clear()
                fused_meta_holder.update(local_meta)

    assert fused_out is not None
    fused_meta_holder["selected_kernel_block_m"] = int(selected_block_m)
    fused_meta_holder["selected_kernel_num_warps"] = int(selected_num_warps)
    fused_meta_holder["tune_kernel"] = bool(config.tune_kernel)
    fused_meta_holder["tune_num_warps"] = bool(config.tune_num_warps)

    graph_report: Dict[str, Any] = {
        "enabled": bool(config.cuda_graph),
        "attempted": False,
        "captured": False,
        "seconds": None,
        "speedup_vs_normal_fused": None,
        "quality_vs_dense": None,
        "quality_vs_normal_fused": None,
        "reason": "CUDA Graph replay disabled",
    }
    if bool(config.cuda_graph):
        def _run_selected_fused():
            out, _meta = experimental_fused_compressed_decode_attention(
                q,
                table,
                prefer_triton=config.prefer_triton,
                kernel_block_m=selected_block_m,
                kernel_num_warps=selected_num_warps,
            )
            return out

        graph_out, graph_seconds, graph_meta = _time_cuda_graph_call(
            _run_selected_fused,
            device=device,
            warmup=config.warmup,
            graph_replays=config.graph_replays,
        )
        graph_report.update(graph_meta)
        if graph_seconds is not None and graph_out is not None:
            graph_report["seconds"] = float(graph_seconds)
            graph_report["speedup_vs_normal_fused"] = _safe_ratio(fused_seconds, graph_seconds)
            graph_report["quality_vs_dense"] = attention_similarity(dense_out, graph_out)
            graph_report["quality_vs_normal_fused"] = attention_similarity(fused_out, graph_out)

    fused_meta_holder["cuda_graph_enabled"] = bool(config.cuda_graph)
    fused_meta_holder["cuda_graph_captured"] = bool(graph_report.get("captured", False))

    mem = table.memory_report().to_dict()
    fused_quality = attention_similarity(dense_out, fused_out)
    reference_quality = attention_similarity(dense_out, reference_out)
    warning = _quality_warning(fused_quality)
    if warning.startswith("weak"):
        warnings = list(warnings) + [warning]

    return {
        "version": "0.10.9",
        "benchmark": "experimental-fused-compressed-decode-attention",
        "config": {
            **asdict(config),
            "device": device,
            "dtype": str(dtype).replace("torch.", ""),
            "requested_device": requested_device,
            "requested_dtype": requested_dtype,
            "iters": int(config.repeats),
        },
        "warnings": warnings,
        "execution": fused_meta_holder,
        "layout": table.to_dict(include_pages=False),
        "memory": mem,
        "timing": {
            "layout_build_seconds": float(layout_build_seconds),
            "dense_attention_seconds": float(dense_seconds),
            "sdpa": sdpa_report,
            "compressed_page_reference_seconds": float(reference_seconds),
            "experimental_fused_seconds": float(fused_seconds),
            "selected_kernel_block_m": int(selected_block_m),
            "selected_kernel_num_warps": int(selected_num_warps),
            "kernel_tuning": tuning_rows,
            "kernel_algorithm_note": "v0.10.9 tunes BLOCK_M and Triton num_warps for the safe-layout/residual microkernel; it does not add split-K or production serving integration.",
            "speedup_vs_compressed_page_reference": _safe_ratio(reference_seconds, fused_seconds),
            "speedup_vs_dense_manual": _safe_ratio(dense_seconds, fused_seconds),
            "speedup_vs_sdpa": (
                _safe_ratio(sdpa_report["seconds"], fused_seconds)
                if isinstance(sdpa_report, dict) and "seconds" in sdpa_report
                else None
            ),
            "cuda_graph": graph_report,
            "graph_fused_seconds": graph_report.get("seconds"),
            "graph_speedup_vs_normal_fused": graph_report.get("speedup_vs_normal_fused"),
            "note": (
                "Timing is diagnostic. v0.10.9 adds CUDA Graph replay diagnostics around the minimal fused-attention prototype; "
                "production acceleration is not claimed."
            ),
        },
        "quality": {
            "fused_vs_dense": fused_quality,
            "reference_vs_dense": reference_quality,
            "fused_vs_reference": attention_similarity(reference_out, fused_out),
            "quality_warning": warning,
        },
        "interpretation": (
            "v0.10.9 benchmarks an experimental compressed decode-attention path over the compressed page layout with optional BLOCK_M/page-size tuning and CUDA Graph replay diagnostics. "
            "It reads compressed pages without constructing full dense K/V. When a production Triton kernel is not "
            "available, the benchmark uses the verified PyTorch compressed-page fallback and reports that mode explicitly."
        ),
    }



def _candidate_page_sizes(config: FusedDecodeBenchConfig) -> List[int]:
    if config.tune_page_size:
        vals = [int(v) for v in config.tune_page_size_values]
    else:
        vals = [int(config.page_size)]
    out: List[int] = []
    for v in vals:
        if v > 0 and config.seq_len % v == 0 and v not in out:
            out.append(v)
    if not out:
        out = [int(config.page_size)]
    return out


def _add_competitiveness_summary(report: Dict[str, Any]) -> Dict[str, Any]:
    timing = report.get("timing", {})
    fused = float(timing.get("experimental_fused_seconds") or 0.0)
    graph = timing.get("cuda_graph") if isinstance(timing.get("cuda_graph"), dict) else {}
    graph_seconds = graph.get("seconds") if graph and graph.get("captured") else None
    effective_fused = float(graph_seconds) if graph_seconds is not None else fused
    effective_mode = "cuda-graph-replay" if graph_seconds is not None else "normal-fused-call"

    dense = float(timing.get("dense_attention_seconds") or 0.0)
    sdpa = timing.get("sdpa")
    sdpa_seconds = float(sdpa.get("seconds")) if isinstance(sdpa, dict) and "seconds" in sdpa else None
    ref = float(timing.get("compressed_page_reference_seconds") or 0.0)

    def ratio(a: Optional[float], b: Optional[float]) -> Optional[float]:
        if a is None or b is None or b <= 0:
            return None
        return float(a) / float(b)

    fused_over_dense = ratio(fused, dense)
    fused_over_sdpa = ratio(fused, sdpa_seconds)
    ref_over_fused = ratio(ref, fused)
    effective_over_dense = ratio(effective_fused, dense)
    effective_over_sdpa = ratio(effective_fused, sdpa_seconds)
    ref_over_effective = ratio(ref, effective_fused)

    competitive_dense = effective_over_dense is not None and effective_over_dense <= 1.0
    competitive_sdpa = effective_over_sdpa is not None and effective_over_sdpa <= 1.0

    summary = {
        "target": report.get("config", {}).get("competitiveness_target", "sdpa"),
        "effective_mode": effective_mode,
        "effective_fused_seconds": effective_fused,
        "fused_over_dense": fused_over_dense,
        "fused_over_sdpa": fused_over_sdpa,
        "reference_over_fused": ref_over_fused,
        "effective_over_dense": effective_over_dense,
        "effective_over_sdpa": effective_over_sdpa,
        "reference_over_effective": ref_over_effective,
        "cuda_graph_captured": bool(graph.get("captured", False)) if graph else False,
        "faster_than_dense_manual": competitive_dense,
        "faster_than_sdpa": competitive_sdpa,
        "faster_than_compressed_page_reference": ref_over_effective is not None and ref_over_effective > 1.0,
        "verdict": (
            "competitive-with-sdpa" if competitive_sdpa else
            "competitive-with-dense-manual" if competitive_dense else
            "faster-than-python-reference-only" if ref_over_effective is not None and ref_over_effective > 1.0 else
            "not-competitive-yet"
        ),
        "boundary": "This is a microbenchmark diagnostic, not production inference acceleration.",
    }
    report["competitiveness"] = summary
    report.setdefault("timing", {})["fused_over_dense_manual"] = fused_over_dense
    report.setdefault("timing", {})["fused_over_sdpa"] = fused_over_sdpa
    report.setdefault("timing", {})["effective_fused_seconds"] = effective_fused
    report.setdefault("timing", {})["effective_fused_mode"] = effective_mode
    report.setdefault("timing", {})["effective_over_dense_manual"] = effective_over_dense
    report.setdefault("timing", {})["effective_over_sdpa"] = effective_over_sdpa
    return report


def run_fused_decode_benchmark(config: FusedDecodeBenchConfig) -> Dict[str, Any]:
    """Benchmark dense, SDPA, compressed-page reference, and v0.9 fused path.

    v0.10.9 can optionally sweep page sizes in addition to BLOCK_M.  The returned
    report is always the fastest fused candidate, with all candidates recorded
    under ``page_size_tuning`` when page-size tuning is enabled.
    """
    page_sizes = _candidate_page_sizes(config)
    if len(page_sizes) <= 1:
        return _add_competitiveness_summary(_run_fused_decode_benchmark_core(config))

    reports: List[Dict[str, Any]] = []
    rows: List[Dict[str, Any]] = []
    for ps in page_sizes:
        cfg = FusedDecodeBenchConfig(**{**asdict(config), "page_size": int(ps), "tune_page_size": False})
        rep = _add_competitiveness_summary(_run_fused_decode_benchmark_core(cfg))
        reports.append(rep)
        q = rep.get("quality", {}).get("fused_vs_dense", {})
        rows.append({
            "page_size": int(ps),
            "selected_kernel_block_m": rep.get("timing", {}).get("selected_kernel_block_m"),
            "selected_kernel_num_warps": rep.get("timing", {}).get("selected_kernel_num_warps"),
            "experimental_fused_seconds": rep.get("timing", {}).get("experimental_fused_seconds"),
            "graph_fused_seconds": rep.get("timing", {}).get("graph_fused_seconds"),
            "effective_fused_seconds": rep.get("timing", {}).get("effective_fused_seconds"),
            "effective_fused_mode": rep.get("timing", {}).get("effective_fused_mode"),
            "dense_attention_seconds": rep.get("timing", {}).get("dense_attention_seconds"),
            "sdpa_seconds": (rep.get("timing", {}).get("sdpa") or {}).get("seconds") if isinstance(rep.get("timing", {}).get("sdpa"), dict) else None,
            "effective_compression_ratio": rep.get("memory", {}).get("effective_compression_ratio"),
            "effective_memory_saved_pct": rep.get("memory", {}).get("effective_memory_saved_pct"),
            "relative_error": q.get("relative_error"),
            "cosine_similarity": q.get("cosine_similarity"),
            "competitiveness_verdict": rep.get("competitiveness", {}).get("verdict"),
        })

    best = min(reports, key=lambda r: float(r.get("timing", {}).get("effective_fused_seconds") or r.get("timing", {}).get("experimental_fused_seconds") or 1e30))
    best["version"] = "0.10.9"
    best["page_size_tuning"] = rows
    best["execution"]["selected_page_size"] = int(best.get("config", {}).get("page_size", config.page_size))
    best["execution"]["tune_page_size"] = True
    best["timing"]["selected_page_size"] = int(best.get("config", {}).get("page_size", config.page_size))
    best["timing"]["page_size_tuning"] = rows
    best["interpretation"] = (
        "v0.10.9 benchmarks an experimental compressed decode-attention path over the compressed page layout with optional "
        "BLOCK_M, page-size tuning, and CUDA Graph replay diagnostics. It reads compressed pages without constructing full dense K/V. The competitiveness "
        "verdict is a microbenchmark diagnostic and is not a production acceleration claim."
    )
    return _add_competitiveness_summary(best)

def fused_decode_markdown_report(report: Dict[str, Any]) -> str:
    mem = report["memory"]
    timing = report["timing"]
    quality = report["quality"]
    execution = report.get("execution", {})
    lines = [
        "# tiny-turboquant v0.10.9 fused decode-attention benchmark",
        "",
        "## Execution",
        f"- Mode: {execution.get('mode')}",
        f"- Triton attempted: {execution.get('triton_attempted')}",
        f"- Uses compressed pages directly: {execution.get('uses_compressed_pages_directly')}",
        f"- Constructs full dense K/V: {execution.get('constructs_full_dense_kv')}",
        f"- Reason: {execution.get('reason')}",
        "",
        "## Memory",
        f"- FP16 K/V bytes: {mem['fp16_kv_bytes']}",
        f"- Actual compressed-layout bytes: {mem['actual_total_bytes']}",
        f"- Effective compression: {mem['effective_compression_ratio']:.4f}x",
        f"- Effective memory saved: {mem['effective_memory_saved_pct']:.2f}%",
        "",
        "## Timing",
        f"- Dense attention seconds: {timing['dense_attention_seconds']:.6f}",
        f"- Compressed page reference seconds: {timing['compressed_page_reference_seconds']:.6f}",
        f"- Experimental fused seconds: {timing['experimental_fused_seconds']:.6f}",
        f"- CUDA Graph replay: {timing.get('cuda_graph')}",
        f"- Selected BLOCK_M: {timing.get('selected_kernel_block_m')}",
        f"- Selected num_warps: {timing.get('selected_kernel_num_warps')}",
        f"- Selected page size: {timing.get('selected_page_size')}",
        f"- SDPA: {timing.get('sdpa')}",
        "",
        "## Competitiveness",
        f"- Summary: {report.get('competitiveness')}",
        "",
        "## Quality",
        f"- Fused vs dense: {quality['fused_vs_dense']}",
        f"- Reference vs dense: {quality['reference_vs_dense']}",
        f"- Fused vs reference: {quality['fused_vs_reference']}",
        f"- Warning: {quality['quality_warning']}",
        "",
        "## Boundary",
        "This is an experimental research benchmark. It does not claim production inference acceleration.",
    ]
    return "\n".join(lines) + "\n"


def save_fused_decode_json(report: Dict[str, Any], path: str | Path) -> None:
    Path(path).write_text(json.dumps(report, indent=2), encoding="utf-8")


def save_fused_decode_markdown(report: Dict[str, Any], path: str | Path) -> None:
    Path(path).write_text(fused_decode_markdown_report(report), encoding="utf-8")



@dataclass
class LongContextCompareConfig:
    """Compare compressed decode-attention layouts across longer contexts.

    v0.10.9 is a diagnostic layer over ``run_fused_decode_benchmark``.  It is
    meant to answer one question: does a more compressed residual layout become
    worthwhile as context length grows?  The benchmark is still synthetic and
    microbenchmark-oriented; it is not a production serving benchmark.
    """

    batch_size: int = 1
    heads: int = 8
    query_len: int = 1
    seq_lens: Tuple[int, ...] = (2048, 4096, 8192, 16384)
    head_dim: int = 64
    page_size: int = 256
    presets: Tuple[str, ...] = ("safe-layout", "residual-balanced", "residual-aggressive")
    device: str = "auto"
    dtype: str = "auto"
    warmup: int = 1
    repeats: int = 3
    seed: int = 123
    prefer_triton: bool = True
    kernel_block_m: int = 64
    kernel_num_warps: int = 4
    tune_kernel: bool = True
    tune_block_m_values: Tuple[int, ...] = (8, 16, 32, 64, 128)
    tune_num_warps: bool = False
    tune_num_warps_values: Tuple[int, ...] = (1, 2, 4, 8)
    tune_page_size: bool = False
    tune_page_size_values: Tuple[int, ...] = (64, 128, 256)
    cuda_graph: bool = True
    graph_replays: int = 100
    competitiveness_target: str = "sdpa"


def _row_from_fused_report(seq_len: int, preset: str, report: Dict[str, Any]) -> Dict[str, Any]:
    timing = report.get("timing", {})
    quality = report.get("quality", {}).get("fused_vs_dense", {})
    mem = report.get("memory", {})
    execution = report.get("execution", {})
    comp = report.get("competitiveness", {})
    sdpa = timing.get("sdpa") if isinstance(timing.get("sdpa"), dict) else {}
    return {
        "seq_len": int(seq_len),
        "preset": preset,
        "mode": execution.get("mode"),
        "quantization_mode": execution.get("quantization_mode", report.get("config", {}).get("quantization_mode")),
        "key_bits": report.get("config", {}).get("key_bits"),
        "value_bits": report.get("config", {}).get("value_bits"),
        "page_size": report.get("config", {}).get("page_size"),
        "selected_kernel_block_m": timing.get("selected_kernel_block_m"),
        "selected_kernel_num_warps": timing.get("selected_kernel_num_warps"),
        "uses_compressed_pages_directly": execution.get("uses_compressed_pages_directly"),
        "constructs_full_dense_kv": execution.get("constructs_full_dense_kv"),
        "fp16_kv_bytes": mem.get("fp16_kv_bytes"),
        "actual_total_bytes": mem.get("actual_total_bytes"),
        "effective_compression_ratio": mem.get("effective_compression_ratio"),
        "effective_memory_saved_pct": mem.get("effective_memory_saved_pct"),
        "dense_attention_seconds": timing.get("dense_attention_seconds"),
        "sdpa_seconds": sdpa.get("seconds") if isinstance(sdpa, dict) else None,
        "compressed_page_reference_seconds": timing.get("compressed_page_reference_seconds"),
        "normal_fused_seconds": timing.get("experimental_fused_seconds"),
        "graph_fused_seconds": timing.get("graph_fused_seconds"),
        "effective_fused_seconds": timing.get("effective_fused_seconds"),
        "effective_fused_mode": timing.get("effective_fused_mode"),
        "effective_over_sdpa": comp.get("effective_over_sdpa"),
        "effective_over_dense": comp.get("effective_over_dense"),
        "reference_over_effective": comp.get("reference_over_effective"),
        "faster_than_sdpa": comp.get("faster_than_sdpa"),
        "faster_than_dense_manual": comp.get("faster_than_dense_manual"),
        "faster_than_compressed_page_reference": comp.get("faster_than_compressed_page_reference"),
        "verdict": comp.get("verdict"),
        "relative_error": quality.get("relative_error"),
        "cosine_similarity": quality.get("cosine_similarity"),
        "quality_warning": report.get("quality", {}).get("quality_warning"),
    }


def _is_quality_acceptable(row: Dict[str, Any], *, max_relative_error: float = 0.08, min_cosine: float = 0.995) -> bool:
    rel = row.get("relative_error")
    cos = row.get("cosine_similarity")
    if rel is None or cos is None:
        return False
    return float(rel) <= max_relative_error and float(cos) >= min_cosine


def _summarize_long_context_rows(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    by_seq: Dict[int, List[Dict[str, Any]]] = {}
    for row in rows:
        by_seq.setdefault(int(row["seq_len"]), []).append(row)

    summary_rows: List[Dict[str, Any]] = []
    for seq_len in sorted(by_seq):
        group = by_seq[seq_len]
        valid_speed = [r for r in group if r.get("effective_fused_seconds") is not None]
        quality_ok = [r for r in valid_speed if _is_quality_acceptable(r)]
        fastest = min(valid_speed, key=lambda r: float(r["effective_fused_seconds"])) if valid_speed else None
        fastest_quality_ok = min(quality_ok, key=lambda r: float(r["effective_fused_seconds"])) if quality_ok else None
        best_memory = max(group, key=lambda r: float(r.get("effective_memory_saved_pct") or -1.0)) if group else None
        best_quality = max(group, key=lambda r: float(r.get("cosine_similarity") or -1.0)) if group else None
        recommended = fastest_quality_ok or best_quality or fastest
        summary_rows.append({
            "seq_len": seq_len,
            "fastest_preset": fastest.get("preset") if fastest else None,
            "fastest_effective_seconds": fastest.get("effective_fused_seconds") if fastest else None,
            "fastest_quality_ok_preset": fastest_quality_ok.get("preset") if fastest_quality_ok else None,
            "fastest_quality_ok_seconds": fastest_quality_ok.get("effective_fused_seconds") if fastest_quality_ok else None,
            "best_memory_preset": best_memory.get("preset") if best_memory else None,
            "best_memory_saved_pct": best_memory.get("effective_memory_saved_pct") if best_memory else None,
            "best_quality_preset": best_quality.get("preset") if best_quality else None,
            "best_quality_cosine": best_quality.get("cosine_similarity") if best_quality else None,
            "recommended_preset": recommended.get("preset") if recommended else None,
            "recommended_reason": (
                "fastest quality-acceptable layout" if fastest_quality_ok else
                "highest-quality fallback because no fast layout met the quality gate" if best_quality else
                "fastest available layout"
            ),
        })

    # Global verdict is deliberately conservative.
    any_sdpa = any(bool(r.get("faster_than_sdpa")) for r in rows)
    any_dense = any(bool(r.get("faster_than_dense_manual")) for r in rows)
    any_ref = any(bool(r.get("faster_than_compressed_page_reference")) for r in rows)
    return {
        "quality_gate": {
            "max_relative_error": 0.08,
            "min_cosine_similarity": 0.995,
            "note": "Used only to rank layouts for research; not a production quality guarantee.",
        },
        "by_seq_len": summary_rows,
        "global_verdict": (
            "competitive-with-sdpa-in-at-least-one-case" if any_sdpa else
            "competitive-with-dense-manual-in-at-least-one-case" if any_dense else
            "faster-than-python-reference-only" if any_ref else
            "not-competitive-yet"
        ),
        "boundary": "This is a synthetic long-context microbenchmark diagnostic, not production inference acceleration.",
    }


def run_long_context_comparison(config: LongContextCompareConfig) -> Dict[str, Any]:
    """Run safe vs residual compressed decode benchmarks across context lengths."""
    rows: List[Dict[str, Any]] = []
    reports: List[Dict[str, Any]] = []
    warnings: List[str] = []

    for seq_len in [int(x) for x in config.seq_lens]:
        for preset in [str(p) for p in config.presets]:
            try:
                cfg = FusedDecodeBenchConfig(
                    batch_size=config.batch_size,
                    heads=config.heads,
                    query_len=config.query_len,
                    seq_len=seq_len,
                    head_dim=config.head_dim,
                    page_size=config.page_size,
                    preset=preset,
                    device=config.device,
                    dtype=config.dtype,
                    warmup=config.warmup,
                    repeats=config.repeats,
                    seed=config.seed,
                    prefer_triton=config.prefer_triton,
                    kernel_block_m=config.kernel_block_m,
                    kernel_num_warps=config.kernel_num_warps,
                    tune_kernel=config.tune_kernel,
                    tune_block_m_values=tuple(int(x) for x in config.tune_block_m_values),
                    tune_num_warps=config.tune_num_warps,
                    tune_num_warps_values=tuple(int(x) for x in config.tune_num_warps_values),
                    tune_page_size=config.tune_page_size,
                    tune_page_size_values=tuple(int(x) for x in config.tune_page_size_values),
                    cuda_graph=config.cuda_graph,
                    graph_replays=config.graph_replays,
                    competitiveness_target=config.competitiveness_target,
                )
                rep = run_fused_decode_benchmark(cfg)
                reports.append(rep)
                rows.append(_row_from_fused_report(seq_len, preset, rep))
            except Exception as exc:
                msg = f"seq_len={seq_len}, preset={preset} failed: {exc!r}"
                warnings.append(msg)
                rows.append({
                    "seq_len": seq_len,
                    "preset": preset,
                    "error": repr(exc),
                    "verdict": "failed",
                })

    return {
        "version": "long-context-comparison-v0.10.9",
        "config": asdict(config),
        "warnings": warnings,
        "rows": rows,
        "summary": _summarize_long_context_rows([r for r in rows if "error" not in r]),
        "interpretation": (
            "v0.10.9 compares safe-layout and residual layouts across longer context lengths to find where "
            "extra residual correction overhead becomes worthwhile. It reuses the experimental fused decode benchmark, "
            "including CUDA Graph replay when enabled. This is not a production serving benchmark and does not claim production inference acceleration."
        ),
    }


def long_context_markdown_report(report: Dict[str, Any]) -> str:
    lines = [
        "# tiny-turboquant v0.10.9 long-context comparison",
        "",
        "## Boundary",
        "This is a synthetic microbenchmark diagnostic. It does not claim production inference acceleration.",
        "",
        "## Summary",
        f"- Global verdict: {report.get('summary', {}).get('global_verdict')}",
        f"- Quality gate: {report.get('summary', {}).get('quality_gate')}",
        "",
        "## Per-context recommendation",
    ]
    for row in report.get("summary", {}).get("by_seq_len", []):
        lines.append(
            f"- seq_len={row.get('seq_len')}: recommended={row.get('recommended_preset')} "
            f"({row.get('recommended_reason')}); fastest={row.get('fastest_preset')}; best_memory={row.get('best_memory_preset')}"
        )
    lines += ["", "## Rows", ""]
    for row in report.get("rows", []):
        if "error" in row:
            lines.append(f"- seq_len={row.get('seq_len')}, preset={row.get('preset')}: ERROR {row.get('error')}")
            continue
        lines.append(
            f"- seq_len={row.get('seq_len')}, preset={row.get('preset')}, "
            f"effective={row.get('effective_fused_seconds')}, sdpa_gap={row.get('effective_over_sdpa')}, "
            f"memory_saved={row.get('effective_memory_saved_pct')}, rel_err={row.get('relative_error')}, "
            f"cos={row.get('cosine_similarity')}, verdict={row.get('verdict')}"
        )
    return "\n".join(lines) + "\n"


def save_long_context_json(report: Dict[str, Any], path: str | Path) -> None:
    Path(path).write_text(json.dumps(report, indent=2), encoding="utf-8")


def save_long_context_markdown(report: Dict[str, Any], path: str | Path) -> None:
    Path(path).write_text(long_context_markdown_report(report), encoding="utf-8")



@dataclass
class SplitKCompareConfig:
    """Diagnostic split-K / sequence-parallel planning benchmark.

    v0.10.9 does not replace the single-pass Triton kernel with a production
    FlashDecoding implementation.  Instead it measures the current best fused
    safe-layout path and estimates how much sequence-parallel split-K would need
    to improve to beat SDPA.  This keeps the report honest while giving concrete
    targets for the next kernel rewrite.
    """

    batch_size: int = 1
    heads: int = 8
    query_len: int = 1
    seq_lens: Tuple[int, ...] = (8192, 16384, 32768)
    head_dim: int = 64
    page_size: int = 256
    preset: str = "safe-layout"
    device: str = "auto"
    dtype: str = "auto"
    warmup: int = 1
    repeats: int = 3
    seed: int = 123
    prefer_triton: bool = True
    kernel_block_m: int = 64
    kernel_num_warps: int = 4
    tune_kernel: bool = True
    tune_block_m_values: Tuple[int, ...] = (8, 16, 32, 64, 128)
    tune_num_warps: bool = True
    tune_num_warps_values: Tuple[int, ...] = (1, 2, 4, 8)
    cuda_graph: bool = True
    graph_replays: int = 100
    split_k_slabs: Tuple[int, ...] = (2, 4, 8, 16)
    reduce_overhead_fraction: float = 0.12
    measure_split_k: bool = True
    competitiveness_target: str = "sdpa"


def _split_k_projection_rows(base_row: Dict[str, Any], slabs: Tuple[int, ...], reduce_overhead_fraction: float) -> List[Dict[str, Any]]:
    """Return honest split-K projection rows from a measured single-pass row.

    This is not a production kernel measurement.  It estimates the target time
    if the page loop were parallelized into N slabs plus a small reduction pass.
    The purpose is to determine how much algorithmic parallelism is needed
    before implementing a true two-kernel/one-kernel split-K path.
    """
    eff = base_row.get("effective_fused_seconds")
    sdpa = base_row.get("sdpa_seconds")
    dense = base_row.get("dense_attention_seconds")
    if eff is None:
        return []
    eff = float(eff)
    sdpa_f = float(sdpa) if sdpa is not None else None
    dense_f = float(dense) if dense is not None else None
    rows: List[Dict[str, Any]] = []
    for n in slabs:
        n = max(1, int(n))
        reduction = eff * max(0.0, float(reduce_overhead_fraction))
        projected = eff / n + reduction
        rows.append({
            "split_k_slabs": n,
            "projected_seconds": projected,
            "projected_speedup_vs_single_pass": eff / projected if projected > 0 else None,
            "projected_over_sdpa": projected / sdpa_f if sdpa_f and sdpa_f > 0 else None,
            "projected_over_dense": projected / dense_f if dense_f and dense_f > 0 else None,
            "projected_faster_than_sdpa": bool(sdpa_f and projected <= sdpa_f),
            "projection_note": "projection only: assumes page/slab parallelism plus reduction overhead; not a measured split-K Triton kernel",
        })
    return rows



def _split_page_ranges(page_count: int, slabs: int) -> List[Tuple[int, int]]:
    slabs = max(1, min(int(slabs), int(page_count)))
    base = page_count // slabs
    rem = page_count % slabs
    ranges: List[Tuple[int, int]] = []
    start = 0
    for i in range(slabs):
        width = base + (1 if i < rem else 0)
        end = start + width
        if end > start:
            ranges.append((start, end))
        start = end
    return ranges


def split_k_attention_reference(query: torch.Tensor, page_table: CompressedKVPageTable, *, split_k_slabs: int = 4) -> torch.Tensor:
    """Measured two-stage split-K reference over compressed pages.

    Stage 1 computes per-slab online-softmax statistics from dequantized compressed
    pages: local max, local denominator, and local weighted-V accumulator.
    Stage 2 combines those partial statistics exactly with the standard
    log-sum-exp correction.  This is a measured correctness prototype, not the
    production Triton split-K kernel.
    """
    if query.ndim != 4 or query.shape[2] != 1:
        raise ValueError("split_k_attention_reference supports decode query_len=1 only")
    q = page_table.rotate_query(query).float()
    scale = float(page_table.head_dim ** -0.5)
    partials: List[Tuple[torch.Tensor, torch.Tensor, torch.Tensor]] = []
    for lo, hi in _split_page_ranges(page_table.page_count, int(split_k_slabs)):
        ks: List[torch.Tensor] = []
        vs: List[torch.Tensor] = []
        for page in page_table.pages[lo:hi]:
            ks.append(page_table.dequant_key_page(page, rotated=True).float())
            vs.append(page_table.dequant_value_page(page).float())
        k_slab = torch.cat(ks, dim=2)
        v_slab = torch.cat(vs, dim=2)
        scores = torch.matmul(q, k_slab.transpose(-1, -2)) * scale
        local_m = scores.max(dim=-1, keepdim=True).values
        probs = torch.exp(scores - local_m)
        local_l = probs.sum(dim=-1, keepdim=True).clamp_min(1e-20)
        local_acc = torch.matmul(probs, v_slab)
        partials.append((local_m, local_l, local_acc))
    global_m = torch.stack([p[0] for p in partials], dim=0).max(dim=0).values
    denom = None
    acc = None
    for local_m, local_l, local_acc in partials:
        weight = torch.exp(local_m - global_m)
        term_l = weight * local_l
        term_acc = weight * local_acc
        denom = term_l if denom is None else denom + term_l
        acc = term_acc if acc is None else acc + term_acc
    out = acc / denom.clamp_min(1e-20)
    return out.to(query.dtype)


def _measure_split_k_rows(
    config: FusedDecodeBenchConfig,
    dense_out: torch.Tensor,
    q: torch.Tensor,
    table: CompressedKVPageTable,
    base_row: Dict[str, Any],
    slabs: Tuple[int, ...],
) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    device = str(q.device).split(":")[0]
    sdpa = base_row.get("sdpa_seconds")
    dense = base_row.get("dense_attention_seconds")
    sdpa_f = float(sdpa) if sdpa is not None else None
    dense_f = float(dense) if dense is not None else None
    single = base_row.get("effective_fused_seconds")
    single_f = float(single) if single is not None else None
    for n in slabs:
        n = max(1, int(n))
        try:
            out, seconds = _time_call(
                lambda n=n: split_k_attention_reference(q, table, split_k_slabs=n),
                device=device,
                warmup=config.warmup,
                repeats=config.repeats,
            )
            quality = attention_similarity(dense_out, out)
            rows.append({
                "split_k_slabs": n,
                "measured_seconds": float(seconds),
                "measured_speedup_vs_single_pass": (single_f / float(seconds)) if single_f and seconds > 0 else None,
                "measured_over_sdpa": (float(seconds) / sdpa_f) if sdpa_f and sdpa_f > 0 else None,
                "measured_over_dense": (float(seconds) / dense_f) if dense_f and dense_f > 0 else None,
                "measured_faster_than_sdpa": bool(sdpa_f and float(seconds) <= sdpa_f),
                "relative_error": quality.get("relative_error"),
                "cosine_similarity": quality.get("cosine_similarity"),
                "mode": "torch-two-stage-split-k-reference",
                "measurement_note": "measured two-stage split-K reference using compressed pages; not a production Triton split-K kernel",
            })
        except Exception as exc:
            rows.append({
                "split_k_slabs": n,
                "error": repr(exc),
                "mode": "torch-two-stage-split-k-reference",
                "measurement_note": "measured split-K reference failed",
            })
    return rows



def _measure_triton_stage1_rows(
    config: FusedDecodeBenchConfig,
    dense_out: torch.Tensor,
    q: torch.Tensor,
    table: CompressedKVPageTable,
    base_row: Dict[str, Any],
    slabs: Tuple[int, ...],
) -> List[Dict[str, Any]]:
    """Measure the real Triton Stage-1 split-K partial kernel plus Torch reduction."""
    rows: List[Dict[str, Any]] = []
    device = str(q.device).split(":")[0]
    sdpa = base_row.get("sdpa_seconds")
    dense = base_row.get("dense_attention_seconds")
    sdpa_f = float(sdpa) if sdpa is not None else None
    dense_f = float(dense) if dense is not None else None
    single = base_row.get("effective_fused_seconds")
    single_f = float(single) if single is not None else None
    for n in slabs:
        n = max(1, int(n))
        try:
            partials, stage1_seconds = _time_call(
                lambda n=n: triton_split_k_stage1_partials(
                    q,
                    table,
                    split_k_slabs=n,
                    kernel_block_m=config.kernel_block_m,
                    kernel_num_warps=config.kernel_num_warps,
                )[:3],
                device=device,
                warmup=config.warmup,
                repeats=config.repeats,
            )
            partial_m, partial_l, partial_acc = partials
            reduced_out, reduce_seconds = _time_call(
                lambda: reduce_split_k_partials(partial_m, partial_l, partial_acc, output_dtype=q.dtype),
                device=device,
                warmup=config.warmup,
                repeats=config.repeats,
            )
            total_seconds = float(stage1_seconds) + float(reduce_seconds)
            quality = attention_similarity(dense_out, reduced_out)
            rows.append({
                "split_k_slabs": n,
                "stage1_seconds": float(stage1_seconds),
                "torch_reduce_seconds": float(reduce_seconds),
                "stage1_plus_torch_reduce_seconds": total_seconds,
                "stage1_speedup_vs_single_pass": (single_f / float(stage1_seconds)) if single_f and stage1_seconds > 0 else None,
                "stage1_over_sdpa": (float(stage1_seconds) / sdpa_f) if sdpa_f and sdpa_f > 0 else None,
                "stage1_plus_reduce_over_sdpa": (total_seconds / sdpa_f) if sdpa_f and sdpa_f > 0 else None,
                "stage1_over_dense": (float(stage1_seconds) / dense_f) if dense_f and dense_f > 0 else None,
                "stage1_faster_than_sdpa": bool(sdpa_f and float(stage1_seconds) <= sdpa_f),
                "stage1_plus_reduce_faster_than_sdpa": bool(sdpa_f and total_seconds <= sdpa_f),
                "relative_error": quality.get("relative_error"),
                "cosine_similarity": quality.get("cosine_similarity"),
                "mode": "triton-split-k-stage1-plus-torch-reduce-reference",
                "measurement_note": "Stage 1 is a real Triton partial-statistics kernel; Stage 2 reduction is still a Torch reference path.",
            })
        except Exception as exc:
            rows.append({
                "split_k_slabs": n,
                "error": repr(exc),
                "mode": "triton-split-k-stage1-partials",
                "measurement_note": "Triton Stage-1 split-K partial kernel failed or was unsupported",
            })
    return rows

def _measure_triton_full_split_k_rows(
    config: FusedDecodeBenchConfig,
    dense_out: torch.Tensor,
    q: torch.Tensor,
    table: CompressedKVPageTable,
    base_row: Dict[str, Any],
    slabs: Tuple[int, ...],
) -> List[Dict[str, Any]]:
    """Measure real Triton Stage-1 plus real Triton Stage-2 reduction.

    v0.10.9 optimizes the measured full split-K path by tuning the Stage-1
    launch shape separately from the single-pass fused kernel.  Earlier
    versions reused ``config.kernel_block_m`` and ``config.kernel_num_warps``
    for Stage 1, which was a poor proxy because split-K has a different work
    shape.  This function now searches ``BLOCK_M × num_warps`` when tuning is
    enabled, measures Stage 1 and Stage 2 together for each candidate, and
    selects the fastest quality-valid full split-K row.
    """
    rows: List[Dict[str, Any]] = []
    device = str(q.device).split(":")[0]
    sdpa = base_row.get("sdpa_seconds")
    dense = base_row.get("dense_attention_seconds")
    sdpa_f = float(sdpa) if sdpa is not None else None
    dense_f = float(dense) if dense is not None else None
    single = base_row.get("effective_fused_seconds")
    single_f = float(single) if single is not None else None
    block_candidates = _candidate_block_values(config)
    warp_candidates = _candidate_warp_values(config)

    for n in slabs:
        n = max(1, int(n))
        candidate_rows: List[Dict[str, Any]] = []
        best: Optional[Dict[str, Any]] = None
        try:
            # v0.10.9: prepare immutable split-K inputs once per row.
            # Earlier versions measured tensor concatenation, query rotation, and
            # allocation inside every Stage-1 candidate.  That distorted Stage-1
            # timing and hid the actual Triton kernel cost.
            ok, reason = _is_supported_triton_config(q, table)
            if not ok:
                raise RuntimeError(reason)
            q_rot_prepared = table.rotate_query(q).contiguous()
            payloads_prepared = _concat_page_payloads(table)
            _, heads, _, head_dim = table.dense_shape

            for block_m in block_candidates:
                for num_warps in warp_candidates:
                    try:
                        partial_m_buf = torch.empty((n, heads), device=q.device, dtype=torch.float32)
                        partial_l_buf = torch.empty((n, heads), device=q.device, dtype=torch.float32)
                        partial_acc_buf = torch.empty((n, heads, head_dim), device=q.device, dtype=torch.float32)
                        reduced_buf = torch.empty((1, heads, 1, head_dim), device=q.device, dtype=q.dtype)

                        partials, stage1_seconds = _time_call(
                            lambda n=n, block_m=block_m, num_warps=num_warps: _triton_split_k_stage1_partials_prepared(
                                q_rot_prepared,
                                payloads_prepared,
                                table,
                                partial_m_buf,
                                partial_l_buf,
                                partial_acc_buf,
                                split_k_slabs=n,
                                kernel_block_m=int(block_m),
                                kernel_num_warps=int(num_warps),
                            ),
                            device=device,
                            warmup=config.warmup,
                            repeats=config.repeats,
                        )
                        partial_m, partial_l, partial_acc = partials
                        reduced_out, stage2_seconds = _time_call(
                            lambda: _triton_split_k_stage2_reduce_prepared(
                                partial_m,
                                partial_l,
                                partial_acc,
                                reduced_buf,
                                kernel_num_warps=1,
                            ),
                            device=device,
                            warmup=config.warmup,
                            repeats=config.repeats,
                        )
                        total_seconds = float(stage1_seconds) + float(stage2_seconds)
                        quality = attention_similarity(dense_out, reduced_out)
                        candidate = {
                            "split_k_slabs": n,
                            "kernel_block_m": int(block_m),
                            "kernel_num_warps": int(num_warps),
                            "stage1_seconds": float(stage1_seconds),
                            "stage2_seconds": float(stage2_seconds),
                            "stage1_plus_stage2_seconds": total_seconds,
                            "relative_error": quality.get("relative_error"),
                            "cosine_similarity": quality.get("cosine_similarity"),
                            "candidate_quality_ok": bool(
                                quality.get("cosine_similarity") is not None
                                and float(quality.get("cosine_similarity")) > 0.99
                                and quality.get("relative_error") is not None
                                and float(quality.get("relative_error")) < 0.05
                            ),
                            "prepared_payloads_reused": True,
                            "allocation_excluded_from_kernel_timing": True,
                        }
                        candidate_rows.append(candidate)
                        if best is None or total_seconds < float(best["stage1_plus_stage2_seconds"]):
                            best = candidate
                    except Exception as exc:
                        candidate_rows.append({
                            "split_k_slabs": n,
                            "kernel_block_m": int(block_m),
                            "kernel_num_warps": int(num_warps),
                            "error": repr(exc),
                            "candidate_quality_ok": False,
                        })

            if best is None:
                raise RuntimeError("no full Triton split-K candidate completed")

            total_seconds = float(best["stage1_plus_stage2_seconds"])
            rows.append({
                "split_k_slabs": n,
                "selected_kernel_block_m": int(best["kernel_block_m"]),
                "selected_kernel_num_warps": int(best["kernel_num_warps"]),
                "stage1_seconds": float(best["stage1_seconds"]),
                "stage2_seconds": float(best["stage2_seconds"]),
                "stage1_plus_stage2_seconds": total_seconds,
                "full_speedup_vs_single_pass": (single_f / total_seconds) if single_f and total_seconds > 0 else None,
                "full_over_sdpa": (total_seconds / sdpa_f) if sdpa_f and sdpa_f > 0 else None,
                "full_over_dense": (total_seconds / dense_f) if dense_f and dense_f > 0 else None,
                "full_faster_than_sdpa": bool(sdpa_f and total_seconds <= sdpa_f),
                "relative_error": best.get("relative_error"),
                "cosine_similarity": best.get("cosine_similarity"),
                "stage1_kernel_tuning": candidate_rows,
                "stage1_kernel_tuning_count": len(candidate_rows),
                "prepared_payloads_reused": True,
                "allocation_excluded_from_kernel_timing": True,
                "mode": "triton-two-stage-split-k-stage1-memory-load-optimized",
                "measurement_note": (
                    "Stage 1 and Stage 2 are real Triton kernels. v0.10.9 tunes Stage-1 "
                    "BLOCK_M × num_warps per slab count and reuses prepared payload tensors, "
                    "rotated query, and output buffers so timing is focused on kernel work. "
                    "This remains a research microbenchmark, not production FlashDecoding."
                ),
            })
        except Exception as exc:
            rows.append({
                "split_k_slabs": n,
                "error": repr(exc),
                "mode": "triton-two-stage-split-k-optimized-stage1",
                "measurement_note": "Full Triton two-stage split-K failed or was unsupported",
            })
    return rows


def _split_k_base_benchmark(config: FusedDecodeBenchConfig) -> Tuple[Dict[str, Any], torch.Tensor, torch.Tensor, CompressedKVPageTable, torch.Tensor]:
    """Run the fused benchmark core and return internals for measured split-K.

    This intentionally duplicates the deterministic synthetic setup used by
    run_fused_decode_benchmark so the measured split-K reference is compared
    against the same dense baseline and compressed page table.
    """
    requested_device = config.device
    requested_dtype = config.dtype
    device = _resolve_device(requested_device)
    dtype = _resolve_dtype(requested_dtype, device)
    q, k, v = _build_random_qkv(config, device, dtype)
    table = CompressedKVPageTable.from_dense(
        k,
        v,
        key_bits=config.key_bits,
        value_bits=config.value_bits,
        page_size=config.page_size,
        seed=config.seed,
        dtype_bytes=torch.empty((), dtype=dtype).element_size(),
        quantization_mode=config.quantization_mode,
    )
    dense_out, _ = _time_call(lambda: dense_attention(q, k, v), device=device, warmup=config.warmup, repeats=config.repeats)
    rep = run_fused_decode_benchmark(config)
    return rep, dense_out, q, table, k

def run_split_k_comparison(config: SplitKCompareConfig) -> Dict[str, Any]:
    rows: List[Dict[str, Any]] = []
    warnings: List[str] = []
    for seq_len in [int(x) for x in config.seq_lens]:
        try:
            cfg = FusedDecodeBenchConfig(
                batch_size=config.batch_size,
                heads=config.heads,
                query_len=config.query_len,
                seq_len=seq_len,
                head_dim=config.head_dim,
                page_size=config.page_size,
                preset=config.preset,
                device=config.device,
                dtype=config.dtype,
                warmup=config.warmup,
                repeats=config.repeats,
                seed=config.seed,
                prefer_triton=config.prefer_triton,
                kernel_block_m=config.kernel_block_m,
                kernel_num_warps=config.kernel_num_warps,
                tune_kernel=config.tune_kernel,
                tune_block_m_values=tuple(int(x) for x in config.tune_block_m_values),
                tune_num_warps=config.tune_num_warps,
                tune_num_warps_values=tuple(int(x) for x in config.tune_num_warps_values),
                cuda_graph=config.cuda_graph,
                graph_replays=config.graph_replays,
                competitiveness_target=config.competitiveness_target,
            )
            if config.measure_split_k:
                rep, dense_out, q, table, _k = _split_k_base_benchmark(cfg)
            else:
                rep = run_fused_decode_benchmark(cfg)
                dense_out = q = table = None  # type: ignore[assignment]
            base = _row_from_fused_report(seq_len, config.preset, rep)
            base["split_k_projection"] = _split_k_projection_rows(base, tuple(int(x) for x in config.split_k_slabs), config.reduce_overhead_fraction)
            best_proj = min(base["split_k_projection"], key=lambda r: float(r["projected_seconds"])) if base["split_k_projection"] else None
            base["best_projected_split_k"] = best_proj
            if config.measure_split_k and dense_out is not None and q is not None and table is not None:
                measured_rows = _measure_split_k_rows(cfg, dense_out, q, table, base, tuple(int(x) for x in config.split_k_slabs))
                base["measured_split_k"] = measured_rows
                valid_measured = [r for r in measured_rows if "measured_seconds" in r]
                base["best_measured_split_k"] = min(valid_measured, key=lambda r: float(r["measured_seconds"])) if valid_measured else None

                stage1_rows = _measure_triton_stage1_rows(cfg, dense_out, q, table, base, tuple(int(x) for x in config.split_k_slabs))
                base["triton_stage1_split_k"] = stage1_rows
                valid_stage1 = [r for r in stage1_rows if "stage1_seconds" in r]
                base["best_triton_stage1_split_k"] = min(valid_stage1, key=lambda r: float(r["stage1_seconds"])) if valid_stage1 else None

                full_rows = _measure_triton_full_split_k_rows(cfg, dense_out, q, table, base, tuple(int(x) for x in config.split_k_slabs))
                base["triton_full_split_k"] = full_rows
                valid_full = [r for r in full_rows if "stage1_plus_stage2_seconds" in r]
                base["best_triton_full_split_k"] = min(valid_full, key=lambda r: float(r["stage1_plus_stage2_seconds"])) if valid_full else None
            else:
                base["measured_split_k"] = []
                base["best_measured_split_k"] = None
                base["triton_stage1_split_k"] = []
                base["best_triton_stage1_split_k"] = None
                base["triton_full_split_k"] = []
                base["best_triton_full_split_k"] = None
            base["measured_single_pass_verdict"] = rep.get("competitiveness", {}).get("verdict")
            rows.append(base)
        except Exception as exc:
            warnings.append(f"seq_len={seq_len} failed: {exc!r}")
            rows.append({"seq_len": seq_len, "preset": config.preset, "error": repr(exc)})

    any_projected_sdpa = any(
        bool(p.get("projected_faster_than_sdpa"))
        for r in rows if "error" not in r
        for p in r.get("split_k_projection", [])
    )
    any_measured_sdpa = any(
        bool(p.get("measured_faster_than_sdpa"))
        for r in rows if "error" not in r
        for p in r.get("measured_split_k", [])
    )
    measured_rows = [
        p for r in rows if "error" not in r
        for p in r.get("measured_split_k", [])
        if "measured_seconds" in p
    ]
    any_stage1_sdpa = any(
        bool(p.get("stage1_faster_than_sdpa"))
        for r in rows if "error" not in r
        for p in r.get("triton_stage1_split_k", [])
    )
    stage1_rows = [
        p for r in rows if "error" not in r
        for p in r.get("triton_stage1_split_k", [])
        if "stage1_seconds" in p
    ]
    any_full_sdpa = any(
        bool(p.get("full_faster_than_sdpa"))
        for r in rows if "error" not in r
        for p in r.get("triton_full_split_k", [])
    )
    full_rows = [
        p for r in rows if "error" not in r
        for p in r.get("triton_full_split_k", [])
        if "stage1_plus_stage2_seconds" in p
    ]
    return {
        "version": "split-k-comparison-v0.10.9",
        "config": asdict(config),
        "warnings": warnings,
        "rows": rows,
        "summary": {
            "global_projection_verdict": "split-k-projection-can-beat-sdpa" if any_projected_sdpa else "split-k-projection-still-needs-more-work",
            "global_measured_verdict": "measured-split-k-beats-sdpa" if any_measured_sdpa else "measured-split-k-not-competitive-yet" if measured_rows else "measured-split-k-not-run",
            "global_triton_stage1_verdict": "triton-stage1-beats-sdpa-in-at-least-one-case" if any_stage1_sdpa else "triton-stage1-measured",
            "global_triton_full_split_k_verdict": "triton-full-split-k-beats-sdpa-in-at-least-one-case" if any_full_sdpa else "triton-full-split-k-not-competitive-yet" if full_rows else "triton-full-split-k-unavailable",
            "measured_kernel_verdict": "v0.10.9 tunes the full Triton split-K Stage-1 launch shape and reports optimized Stage-1 + Stage-2 measured rows",
            "boundary": "This is a split-K measured research diagnostic, not production inference acceleration.",
        },
        "interpretation": (
            "v0.10.9 measures real Triton Stage-1 partial statistics plus a real Triton Stage-2 reducer over compressed pages. "
            "This completes the measured two-stage split-K research path, but it is still not a production FlashDecoding serving kernel."
        ),
    }


def split_k_markdown_report(report: Dict[str, Any]) -> str:
    lines = [
        "# tiny-turboquant v0.10.9 optimized split-K diagnostic",
        "",
        "This report includes measured full Triton split-K research rows with Stage-1 launch-shape tuning. It is still not a production FlashDecoding benchmark.",
        "",
        "## Summary",
        f"- {report.get('summary')}",
        "",
        "## Rows",
    ]
    for row in report.get("rows", []):
        lines.append(f"- seq_len={row.get('seq_len')}, preset={row.get('preset')}, measured_effective={row.get('effective_fused_seconds')}, sdpa={row.get('sdpa_seconds')}, verdict={row.get('measured_single_pass_verdict')}")
        for p in row.get("split_k_projection", []):
            lines.append(f"  - projected slabs={p.get('split_k_slabs')}: seconds={p.get('projected_seconds')}, over_sdpa={p.get('projected_over_sdpa')}, faster_than_sdpa={p.get('projected_faster_than_sdpa')}")
        for p in row.get("measured_split_k", []):
            if "error" in p:
                lines.append(f"  - torch measured slabs={p.get('split_k_slabs')}: ERROR {p.get('error')}")
            else:
                lines.append(f"  - torch measured slabs={p.get('split_k_slabs')}: seconds={p.get('measured_seconds')}, over_sdpa={p.get('measured_over_sdpa')}, faster_than_sdpa={p.get('measured_faster_than_sdpa')}, cos={p.get('cosine_similarity')}")
        for p in row.get("triton_stage1_split_k", []):
            if "error" in p:
                lines.append(f"  - Triton Stage-1 slabs={p.get('split_k_slabs')}: ERROR {p.get('error')}")
            else:
                lines.append(f"  - Triton Stage-1 slabs={p.get('split_k_slabs')}: stage1={p.get('stage1_seconds')}, stage1+torch_reduce={p.get('stage1_plus_torch_reduce_seconds')}, over_sdpa={p.get('stage1_plus_reduce_over_sdpa')}, cos={p.get('cosine_similarity')}")
        for p in row.get("triton_full_split_k", []):
            if "error" in p:
                lines.append(f"  - Triton full split-K slabs={p.get('split_k_slabs')}: ERROR {p.get('error')}")
            else:
                lines.append(f"  - Triton full split-K slabs={p.get('split_k_slabs')}: total={p.get('stage1_plus_stage2_seconds')}, over_sdpa={p.get('full_over_sdpa')}, faster_than_sdpa={p.get('full_faster_than_sdpa')}, cos={p.get('cosine_similarity')}")
    lines.extend([
        "",
        "## Boundary",
        "This is not a production acceleration claim.",
    ])
    return "\n".join(lines) + "\n"


def save_split_k_json(report: Dict[str, Any], path: str | Path) -> None:
    Path(path).write_text(json.dumps(report, indent=2), encoding="utf-8")


def save_split_k_markdown(report: Dict[str, Any], path: str | Path) -> None:
    Path(path).write_text(split_k_markdown_report(report), encoding="utf-8")


@dataclass
class EndToEndDecodeBenchConfig:
    """Configuration for fixed-cache end-to-end decode diagnostics.

    This is a synthetic decode-loop benchmark. It includes one-time compressed
    KV layout setup, prepared payload reuse, repeated decode-token execution,
    and amortized per-token timing. It is not a full model-serving benchmark.
    """

    batch_size: int = 1
    heads: int = 8
    query_len: int = 1
    prompt_lens: Tuple[int, ...] = (16384, 32768)
    decode_steps: int = 32
    amortization_steps: Tuple[int, ...] = (32, 128, 256, 512, 1024)
    head_dim: int = 64
    page_size: int = 256
    preset: Optional[str] = "safe-layout"
    device: str = "auto"
    dtype: str = "auto"
    warmup: int = 1
    repeats: int = 3
    seed: int = 123
    prefer_triton: bool = True
    kernel_block_m: int = 64
    kernel_num_warps: int = 4
    tune_kernel: bool = True
    tune_block_m_values: Tuple[int, ...] = (8, 16, 32, 64, 128)
    tune_num_warps: bool = True
    tune_num_warps_values: Tuple[int, ...] = (1, 2, 4, 8)
    split_k_slabs: Tuple[int, ...] = (2, 4, 8, 16)
    cuda_graph: bool = False
    graph_replays: int = 100
    include_single_pass_loop: bool = True
    competitiveness_target: str = "sdpa"

    def __post_init__(self) -> None:
        if self.query_len != 1:
            raise ValueError("EndToEndDecodeBenchConfig is decode-only: query_len must be 1")
        if self.preset:
            cfg = resolve_layout_preset(self.preset)
            # Store for report-time use through the generated fused config.
            self._resolved_key_bits = int(cfg.get("key_bits", 8))
            self._resolved_value_bits = int(cfg.get("value_bits", 6))
            self._resolved_quantization_mode = str(cfg.get("quantization_mode", "affine"))
        else:
            self._resolved_key_bits = 8
            self._resolved_value_bits = 6
            self._resolved_quantization_mode = "affine"


def _time_decode_loop(fn, *, device: str, warmup: int, repeats: int, decode_steps: int) -> Tuple[torch.Tensor, float, float]:
    """Time a decode loop and return last output, seconds per token, total loop seconds."""
    out = None
    steps = max(1, int(decode_steps))
    for _ in range(max(0, int(warmup))):
        out = fn()
    _sync(device)
    t0 = time.perf_counter()
    for _ in range(max(1, int(repeats))):
        out = fn()
    _sync(device)
    total = (time.perf_counter() - t0) / max(1, int(repeats))
    assert out is not None
    return out, float(total / steps), float(total)




def _positive_int_grid(values: Tuple[int, ...], fallback: int) -> Tuple[int, ...]:
    cleaned = sorted({max(1, int(v)) for v in values})
    return tuple(cleaned or (max(1, int(fallback)),))


def _ceil_ratio(numerator: Optional[float], denominator: Optional[float]) -> Optional[int]:
    if numerator is None or denominator is None:
        return None
    if denominator <= 0:
        return None
    return int((float(numerator) / float(denominator)) + 0.999999999)


def _setup_amortization_report(
    *,
    setup_seconds: float,
    table_build_seconds: float,
    payload_prepare_seconds: float,
    split_per_token: Optional[float],
    sdpa_per_token: Optional[float],
    steps: Tuple[int, ...],
) -> Dict[str, Any]:
    """Build setup amortization diagnostics from measured per-token timings.

    This is intentionally a model over measured loop timings, not a new kernel
    timing path. It answers how many decode steps are needed for setup cost to
    be amortized when the compressed layout can be reused.
    """
    if split_per_token is None or sdpa_per_token is None:
        return {
            "available": False,
            "reason": "split-K or SDPA per-token timing unavailable",
            "steps": [],
        }
    per_token_saving = float(sdpa_per_token) - float(split_per_token)
    payload_only_setup = float(payload_prepare_seconds)
    rows = []
    for n in _positive_int_grid(steps, 1):
        sdpa_total = float(sdpa_per_token) * n
        split_kernel_total = float(split_per_token) * n
        split_full_setup_total = float(setup_seconds) + split_kernel_total
        split_payload_only_setup_total = payload_only_setup + split_kernel_total
        split_cached_layout_total = split_kernel_total
        rows.append({
            "decode_steps": n,
            "sdpa_total_seconds": sdpa_total,
            "split_k_kernel_only_total_seconds": split_kernel_total,
            "split_k_with_full_setup_seconds": split_full_setup_total,
            "split_k_with_payload_prepare_only_seconds": split_payload_only_setup_total,
            "split_k_cached_layout_seconds": split_cached_layout_total,
            "kernel_only_beats_sdpa": bool(split_kernel_total <= sdpa_total),
            "full_setup_beats_sdpa": bool(split_full_setup_total <= sdpa_total),
            "payload_prepare_only_beats_sdpa": bool(split_payload_only_setup_total <= sdpa_total),
            "cached_layout_beats_sdpa": bool(split_cached_layout_total <= sdpa_total),
            "full_setup_over_sdpa": _safe_ratio(split_full_setup_total, sdpa_total),
            "payload_prepare_only_over_sdpa": _safe_ratio(split_payload_only_setup_total, sdpa_total),
            "cached_layout_over_sdpa": _safe_ratio(split_cached_layout_total, sdpa_total),
        })
    return {
        "available": True,
        "table_build_seconds": float(table_build_seconds),
        "payload_prepare_seconds": float(payload_prepare_seconds),
        "full_setup_seconds": float(setup_seconds),
        "split_k_seconds_per_token": float(split_per_token),
        "sdpa_seconds_per_token": float(sdpa_per_token),
        "per_token_saving_vs_sdpa_seconds": per_token_saving,
        "break_even_decode_steps_full_setup": _ceil_ratio(setup_seconds, per_token_saving),
        "break_even_decode_steps_payload_prepare_only": _ceil_ratio(payload_only_setup, per_token_saving),
        "kernel_only_speedup_vs_sdpa_per_token": _safe_ratio(sdpa_per_token, split_per_token),
        "steps": rows,
        "interpretation": (
            "Kernel-only rows exclude one-time setup. Full-setup rows include table build and payload preparation. "
            "Payload-only rows model cached table reuse. Cached-layout rows model prepared payload reuse across decode sessions."
        ),
    }

def _build_q_steps(config: EndToEndDecodeBenchConfig, prompt_len: int, device: str, dtype: torch.dtype) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    torch.manual_seed(int(config.seed) + int(prompt_len))
    q_steps = torch.randn(
        int(config.decode_steps),
        int(config.batch_size),
        int(config.heads),
        1,
        int(config.head_dim),
        device=device,
        dtype=dtype,
    )
    k = torch.randn(
        int(config.batch_size),
        int(config.heads),
        int(prompt_len),
        int(config.head_dim),
        device=device,
        dtype=dtype,
    )
    v = torch.randn_like(k)
    return q_steps, k, v


def _select_e2e_split_k_candidate(
    config: EndToEndDecodeBenchConfig,
    dense_ref: torch.Tensor,
    q0: torch.Tensor,
    table: CompressedKVPageTable,
    payloads: Dict[str, torch.Tensor],
) -> Dict[str, Any]:
    """Select the fastest quality-valid split-K candidate for the decode loop."""
    device = str(q0.device).split(":")[0]
    _, heads, _, head_dim = table.dense_shape
    block_candidates = [int(x) for x in (config.tune_block_m_values if config.tune_kernel else (config.kernel_block_m,))]
    warp_candidates = [int(x) for x in (config.tune_num_warps_values if config.tune_num_warps else (config.kernel_num_warps,))]
    block_candidates = [x for x in block_candidates if x in (8, 16, 32, 64, 128)] or [64]
    warp_candidates = [x for x in warp_candidates if x in (1, 2, 4, 8)] or [4]
    requested_slabs = [max(1, int(x)) for x in config.split_k_slabs] or [16]
    page_count = max(1, int(getattr(table, "page_count", 1)))
    slab_candidates = [x for x in requested_slabs if x <= page_count]
    if not slab_candidates:
        slab_candidates = [1]

    tuning_rows: List[Dict[str, Any]] = []
    best: Optional[Dict[str, Any]] = None
    q_rot = table.rotate_query(q0).contiguous()

    ok, reason = _is_supported_triton_config(q0, table)
    if not ok:
        raise RuntimeError(reason)

    for slabs in slab_candidates:
        for block_m in block_candidates:
            for num_warps in warp_candidates:
                partial_m = torch.empty((slabs, heads), device=q0.device, dtype=torch.float32)
                partial_l = torch.empty((slabs, heads), device=q0.device, dtype=torch.float32)
                partial_acc = torch.empty((slabs, heads, head_dim), device=q0.device, dtype=torch.float32)
                reduced = torch.empty((1, heads, 1, head_dim), device=q0.device, dtype=q0.dtype)
                try:
                    partials, stage1_seconds = _time_call(
                        lambda slabs=slabs, block_m=block_m, num_warps=num_warps: _triton_split_k_stage1_partials_prepared(
                            q_rot,
                            payloads,
                            table,
                            partial_m,
                            partial_l,
                            partial_acc,
                            split_k_slabs=slabs,
                            kernel_block_m=block_m,
                            kernel_num_warps=num_warps,
                        ),
                        device=device,
                        warmup=config.warmup,
                        repeats=config.repeats,
                    )
                    pm, pl, pa = partials
                    out, stage2_seconds = _time_call(
                        lambda: _triton_split_k_stage2_reduce_prepared(pm, pl, pa, reduced, kernel_num_warps=1),
                        device=device,
                        warmup=config.warmup,
                        repeats=config.repeats,
                    )
                    total = float(stage1_seconds) + float(stage2_seconds)
                    quality = attention_similarity(dense_ref, out)
                    row = {
                        "split_k_slabs": slabs,
                        "kernel_block_m": block_m,
                        "kernel_num_warps": num_warps,
                        "stage1_seconds": float(stage1_seconds),
                        "stage2_seconds": float(stage2_seconds),
                        "stage1_plus_stage2_seconds": total,
                        "relative_error": quality.get("relative_error"),
                        "cosine_similarity": quality.get("cosine_similarity"),
                        "candidate_quality_ok": bool(
                            quality.get("cosine_similarity") is not None
                            and float(quality.get("cosine_similarity")) > 0.99
                            and quality.get("relative_error") is not None
                            and float(quality.get("relative_error")) < 0.05
                        ),
                    }
                    tuning_rows.append(row)
                    if row["candidate_quality_ok"] and (best is None or total < float(best["stage1_plus_stage2_seconds"])):
                        best = row
                except Exception as exc:
                    tuning_rows.append({
                        "split_k_slabs": slabs,
                        "kernel_block_m": block_m,
                        "kernel_num_warps": num_warps,
                        "error": repr(exc),
                        "candidate_quality_ok": False,
                    })
    if best is None:
        completed = [row for row in tuning_rows if "stage1_plus_stage2_seconds" in row]
        fastest_invalid = min(completed, key=lambda row: float(row["stage1_plus_stage2_seconds"])) if completed else None
        fallback: Dict[str, Any] = {
            "candidate_quality_ok": False,
            "selection_error": "no quality-valid split-K candidate completed",
            "quality_gate": {
                "min_cosine_similarity": 0.99,
                "max_relative_error": 0.05,
            },
            "requested_split_k_slabs": requested_slabs,
            "effective_split_k_slabs_tested": slab_candidates,
            "page_count": page_count,
            "selection_tuning_count": len(tuning_rows),
            "selection_tuning_rows": tuning_rows,
            "selection_note": (
                "No candidate passed the strict split-K quality gate. The benchmark will still report "
                "dense, SDPA, single-pass compressed attention, memory, setup, and candidate diagnostics instead of failing the whole run."
            ),
        }
        if fastest_invalid is not None:
            fallback["best_invalid_candidate"] = fastest_invalid
        return fallback
    best = dict(best)
    best["candidate_quality_ok"] = True
    best["requested_split_k_slabs"] = requested_slabs
    best["effective_split_k_slabs_tested"] = slab_candidates
    best["page_count"] = page_count
    best["selection_tuning_count"] = len(tuning_rows)
    best["selection_tuning_rows"] = tuning_rows
    return best


def run_end_to_end_decode_benchmark(config: EndToEndDecodeBenchConfig) -> Dict[str, Any]:
    """Run a fixed-cache repeated decode benchmark with setup/amortization reporting."""
    requested_device = config.device
    requested_dtype = config.dtype
    device = _resolve_device(requested_device)
    dtype = _resolve_dtype(requested_dtype, device)
    warnings = _runtime_warnings(requested_device, device, requested_dtype, dtype)
    rows: List[Dict[str, Any]] = []

    for prompt_len in [int(x) for x in config.prompt_lens]:
        try:
            q_steps, k, v = _build_q_steps(config, prompt_len, device, dtype)
            dtype_bytes = torch.empty((), dtype=dtype).element_size()
            key_bits = int(getattr(config, "_resolved_key_bits", 8))
            value_bits = int(getattr(config, "_resolved_value_bits", 6))
            quant_mode = str(getattr(config, "_resolved_quantization_mode", "affine"))

            _sync(device)
            t0 = time.perf_counter()
            table = CompressedKVPageTable.from_dense(
                k,
                v,
                key_bits=key_bits,
                value_bits=value_bits,
                page_size=int(config.page_size),
                seed=int(config.seed),
                dtype_bytes=dtype_bytes,
                quantization_mode=quant_mode,
            )
            _sync(device)
            table_build_seconds = float(time.perf_counter() - t0)

            _sync(device)
            t0 = time.perf_counter()
            payloads = _concat_page_payloads(table)
            _sync(device)
            payload_prepare_seconds = float(time.perf_counter() - t0)

            first_q = q_steps[0]
            dense_first = dense_attention(first_q, k, v)
            memory = table.memory_report().to_dict()

            selected: Optional[Dict[str, Any]] = None
            if device == "cuda" and bool(config.prefer_triton):
                selected = _select_e2e_split_k_candidate(config, dense_first, first_q, table, payloads)

            def _dense_loop():
                out = None
                for i in range(int(config.decode_steps)):
                    out = dense_attention(q_steps[i], k, v)
                return out

            def _sdpa_loop():
                out = None
                for i in range(int(config.decode_steps)):
                    out = sdpa_attention(q_steps[i], k, v)
                return out

            dense_last, dense_per_token, dense_loop_total = _time_decode_loop(
                _dense_loop,
                device=device,
                warmup=config.warmup,
                repeats=config.repeats,
                decode_steps=config.decode_steps,
            )
            sdpa_last, sdpa_per_token, sdpa_loop_total = _time_decode_loop(
                _sdpa_loop,
                device=device,
                warmup=config.warmup,
                repeats=config.repeats,
                decode_steps=config.decode_steps,
            )

            single_last = None
            single_per_token = None
            single_loop_total = None
            if bool(config.include_single_pass_loop):
                def _single_loop():
                    out = None
                    for i in range(int(config.decode_steps)):
                        out, _ = experimental_fused_compressed_decode_attention(
                            q_steps[i],
                            table,
                            prefer_triton=config.prefer_triton,
                            kernel_block_m=int(config.kernel_block_m),
                            kernel_num_warps=int(config.kernel_num_warps),
                        )
                    return out

                single_last, single_per_token, single_loop_total = _time_decode_loop(
                    _single_loop,
                    device=device,
                    warmup=config.warmup,
                    repeats=config.repeats,
                    decode_steps=config.decode_steps,
                )

            split_last = None
            split_per_token = None
            split_loop_total = None
            graph_report: Dict[str, Any] = {
                "enabled": bool(config.cuda_graph),
                "attempted": False,
                "captured": False,
                "seconds_per_token": None,
                "reason": "CUDA Graph replay disabled",
            }

            if selected is not None:
                slabs = int(selected["split_k_slabs"])
                block_m = int(selected["kernel_block_m"])
                num_warps = int(selected["kernel_num_warps"])
                _, heads, _, head_dim = table.dense_shape
                partial_m = torch.empty((slabs, heads), device=q_steps.device, dtype=torch.float32)
                partial_l = torch.empty((slabs, heads), device=q_steps.device, dtype=torch.float32)
                partial_acc = torch.empty((slabs, heads, head_dim), device=q_steps.device, dtype=torch.float32)
                reduced = torch.empty((1, heads, 1, head_dim), device=q_steps.device, dtype=q_steps.dtype)

                def _split_loop():
                    out = None
                    for i in range(int(config.decode_steps)):
                        q_rot = table.rotate_query(q_steps[i]).contiguous()
                        _triton_split_k_stage1_partials_prepared(
                            q_rot,
                            payloads,
                            table,
                            partial_m,
                            partial_l,
                            partial_acc,
                            split_k_slabs=slabs,
                            kernel_block_m=block_m,
                            kernel_num_warps=num_warps,
                        )
                        out = _triton_split_k_stage2_reduce_prepared(
                            partial_m,
                            partial_l,
                            partial_acc,
                            reduced,
                            kernel_num_warps=1,
                        )
                    return out

                split_last, split_per_token, split_loop_total = _time_decode_loop(
                    _split_loop,
                    device=device,
                    warmup=config.warmup,
                    repeats=config.repeats,
                    decode_steps=config.decode_steps,
                )

                if bool(config.cuda_graph):
                    graph_out, graph_seconds, graph_meta = _time_cuda_graph_call(
                        _split_loop,
                        device=device,
                        warmup=config.warmup,
                        graph_replays=config.graph_replays,
                    )
                    graph_report.update(graph_meta)
                    if graph_seconds is not None:
                        graph_report["seconds_per_token"] = float(graph_seconds) / max(1, int(config.decode_steps))
                        graph_report["loop_seconds"] = float(graph_seconds)
                        if graph_out is not None:
                            graph_report["quality_vs_dense_last"] = _safe_attention_similarity(dense_last, graph_out)

            setup_seconds = table_build_seconds + payload_prepare_seconds
            split_total_with_setup = (setup_seconds + float(split_loop_total)) if split_loop_total is not None else None
            split_amortized = (split_total_with_setup / max(1, int(config.decode_steps))) if split_total_with_setup is not None else None
            split_first_token_with_setup = (setup_seconds + float(split_per_token)) if split_per_token is not None else None
            amortization = _setup_amortization_report(
                setup_seconds=setup_seconds,
                table_build_seconds=table_build_seconds,
                payload_prepare_seconds=payload_prepare_seconds,
                split_per_token=split_per_token,
                sdpa_per_token=sdpa_per_token,
                steps=tuple(getattr(config, "amortization_steps", (int(config.decode_steps),))),
            )

            row = {
                "prompt_len": int(prompt_len),
                "decode_steps": int(config.decode_steps),
                "preset": config.preset,
                "quantization_mode": table.quantization_mode,
                "key_bits": key_bits,
                "value_bits": value_bits,
                "page_size": int(config.page_size),
                "page_count": int(table.page_count),
                "memory": memory,
                "setup": {
                    "table_build_seconds": table_build_seconds,
                    "payload_prepare_seconds": payload_prepare_seconds,
                    "total_setup_seconds": setup_seconds,
                    "prepared_payloads_reused": True,
                    "output_buffers_reused": bool(selected is not None),
                },
                "dense_decode": {
                    "loop_seconds": dense_loop_total,
                    "seconds_per_token": dense_per_token,
                    "tokens_per_second": _safe_ratio(1.0, dense_per_token),
                },
                "sdpa_decode": {
                    "loop_seconds": sdpa_loop_total,
                    "seconds_per_token": sdpa_per_token,
                    "tokens_per_second": _safe_ratio(1.0, sdpa_per_token),
                    "quality_vs_dense_last": _safe_attention_similarity(dense_last, sdpa_last),
                },
                "single_pass_decode": None if single_per_token is None else {
                    "loop_seconds": single_loop_total,
                    "seconds_per_token": single_per_token,
                    "tokens_per_second": _safe_ratio(1.0, single_per_token),
                    "over_sdpa_per_token": _safe_ratio(single_per_token, sdpa_per_token),
                    "quality_vs_dense_last": _safe_attention_similarity(dense_last, single_last) if single_last is not None else None,
                },
                "split_k_decode": None if split_per_token is None else {
                    "selected": selected,
                    "loop_seconds": split_loop_total,
                    "seconds_per_token": split_per_token,
                    "tokens_per_second": _safe_ratio(1.0, split_per_token),
                    "over_sdpa_per_token": _safe_ratio(split_per_token, sdpa_per_token),
                    "speedup_vs_sdpa_per_token": _safe_ratio(sdpa_per_token, split_per_token),
                    "speedup_vs_single_pass_per_token": _safe_ratio(single_per_token, split_per_token) if single_per_token is not None else None,
                    "total_with_setup_seconds": split_total_with_setup,
                    "amortized_seconds_per_token_with_setup": split_amortized,
                    "first_token_seconds_with_setup": split_first_token_with_setup,
                    "amortized_over_sdpa_per_token": _safe_ratio(split_amortized, sdpa_per_token) if split_amortized is not None else None,
                    "first_token_over_sdpa_per_token": _safe_ratio(split_first_token_with_setup, sdpa_per_token) if split_first_token_with_setup is not None else None,
                    "quality_vs_dense_last": _safe_attention_similarity(dense_last, split_last) if split_last is not None else None,
                    "kernel_loop_beats_sdpa": bool(split_per_token is not None and split_per_token <= sdpa_per_token),
                    "amortized_with_setup_beats_sdpa": bool(split_amortized is not None and split_amortized <= sdpa_per_token),
                    "amortization": amortization,
                },
                "cuda_graph_decode": graph_report,
                "boundary": "Fixed-cache synthetic decode-loop benchmark; not a full model serving benchmark.",
            }
            rows.append(row)
        except Exception as exc:
            warnings.append(f"prompt_len={prompt_len} failed: {exc!r}")
            rows.append({"prompt_len": int(prompt_len), "error": repr(exc), "preset": config.preset})

    any_kernel_sdpa = any(
        bool(r.get("split_k_decode", {}) and r["split_k_decode"].get("kernel_loop_beats_sdpa"))
        for r in rows if "error" not in r
    )
    any_amortized_sdpa = any(
        bool(r.get("split_k_decode", {}) and r["split_k_decode"].get("amortized_with_setup_beats_sdpa"))
        for r in rows if "error" not in r
    )
    any_grid_full_setup_sdpa = any(
        bool(step.get("full_setup_beats_sdpa"))
        for r in rows if "error" not in r
        for step in (((r.get("split_k_decode") or {}).get("amortization") or {}).get("steps") or [])
    )
    any_grid_payload_only_sdpa = any(
        bool(step.get("payload_prepare_only_beats_sdpa"))
        for r in rows if "error" not in r
        for step in (((r.get("split_k_decode") or {}).get("amortization") or {}).get("steps") or [])
    )

    return {
        "version": "end-to-end-decode-v0.11.2",
        "config": asdict(config),
        "warnings": warnings,
        "rows": rows,
        "summary": {
            "kernel_loop_verdict": "split-k-decode-loop-beats-sdpa-in-at-least-one-case" if any_kernel_sdpa else "split-k-decode-loop-not-competitive-yet",
            "amortized_with_setup_verdict": "split-k-amortized-with-setup-beats-sdpa-in-at-least-one-case" if (any_amortized_sdpa or any_grid_full_setup_sdpa) else "split-k-setup-cost-still-needs-amortization",
            "payload_only_setup_verdict": "split-k-payload-only-setup-beats-sdpa-in-grid" if any_grid_payload_only_sdpa else "payload-only-setup-still-needs-amortization",
            "measured_kernel_verdict": "v0.11.2 measures repeated decode steps, setup-cost amortization, cached-layout reuse scenarios, and break-even decode lengths",
            "boundary": "This is a fixed-cache synthetic decode-loop diagnostic, not production LLM serving acceleration.",
        },
        "interpretation": (
            "v0.11.2 reports fixed-cache decode-loop timing plus setup amortization grids. It separates full setup, payload-only setup, and cached-layout reuse scenarios, but this is still not a full model-serving benchmark."
        ),
    }



@dataclass
class RealModelKVBenchConfig:
    """Configuration for real-model KV-cache compressed-attention diagnostics.

    This benchmark loads a Hugging Face causal LM, runs a prompt with
    ``use_cache=True``, extracts a real layer's ``past_key_values`` tensors, and
    benchmarks dense/SDPA/split-K compressed attention over those real KV
    tensors. The decode query is a model-shaped proxy by default (the last key
    vector), so this is a real-KV attention diagnostic, not full autoregressive
    model serving.
    """

    model: str = "sshleifer/tiny-gpt2"
    prompt: str = "Tiny TurboQuant studies compressed KV-cache attention for long-context inference."
    layer_index: int = 0
    max_prompt_tokens: Optional[int] = None
    decode_steps: int = 32
    amortization_steps: Tuple[int, ...] = (32, 128, 256, 512, 1024)
    page_size: int = 256
    preset: Optional[str] = "safe-layout"
    device: str = "auto"
    dtype: str = "auto"
    warmup: int = 1
    repeats: int = 3
    seed: int = 123
    prefer_triton: bool = True
    kernel_block_m: int = 64
    kernel_num_warps: int = 4
    tune_kernel: bool = True
    tune_block_m_values: Tuple[int, ...] = (8, 16, 32, 64, 128)
    tune_num_warps: bool = True
    tune_num_warps_values: Tuple[int, ...] = (1, 2, 4, 8)
    split_k_slabs: Tuple[int, ...] = (2, 4, 8, 16)
    cuda_graph: bool = False
    graph_replays: int = 100
    include_single_pass_loop: bool = True
    local_files_only: bool = False
    trust_remote_code: bool = False
    query_source: str = "random-normalized"  # last-key, random, or random-normalized
    kv_head_repeat: int = 1
    competitiveness_target: str = "sdpa"

    def __post_init__(self) -> None:
        if self.preset:
            cfg = resolve_layout_preset(self.preset)
            self._resolved_key_bits = int(cfg.get("key_bits", 8))
            self._resolved_value_bits = int(cfg.get("value_bits", 6))
            self._resolved_quantization_mode = str(cfg.get("quantization_mode", "affine"))
        else:
            self._resolved_key_bits = 8
            self._resolved_value_bits = 6
            self._resolved_quantization_mode = "affine"
        if self.query_source not in {"last-key", "random", "random-normalized"}:
            raise ValueError("query_source must be 'last-key', 'random', or 'random-normalized'")
        if int(self.kv_head_repeat) < 1:
            raise ValueError("kv_head_repeat must be >= 1")


def _import_transformers_for_real_kv():
    try:
        from transformers import AutoModelForCausalLM, AutoTokenizer  # type: ignore
    except Exception as exc:  # pragma: no cover - depends on optional dependency
        raise RuntimeError(
            "The real-model KV benchmark requires the optional 'transformers' package. "
            "Install it with `pip install transformers accelerate` or run this command in Kaggle/Colab."
        ) from exc
    return AutoModelForCausalLM, AutoTokenizer


def _extract_kv_pair_from_cache_layer(layer: Any) -> Optional[Tuple[torch.Tensor, torch.Tensor]]:
    """Return ``(key, value)`` from one Hugging Face cache layer if possible.

    Transformers cache internals have changed across releases. Older models return
    tuples like ``(k, v)``. Newer ``DynamicCache`` objects can hold per-layer
    objects whose tensors are exposed as ``.keys`` / ``.values``. Some model
    wrappers expose dictionary-style or alternate attribute names. This helper is
    intentionally permissive but only accepts real tensor pairs.
    """
    if isinstance(layer, (list, tuple)) and len(layer) >= 2:
        k, v = layer[0], layer[1]
        if torch.is_tensor(k) and torch.is_tensor(v):
            return k, v

    if isinstance(layer, dict):
        for key_name, value_name in (
            ("key", "value"),
            ("keys", "values"),
            ("k", "v"),
            ("key_states", "value_states"),
        ):
            k, v = layer.get(key_name), layer.get(value_name)
            if torch.is_tensor(k) and torch.is_tensor(v):
                return k, v

    for key_name, value_name in (
        ("keys", "values"),
        ("key", "value"),
        ("key_states", "value_states"),
        ("k", "v"),
    ):
        if hasattr(layer, key_name) and hasattr(layer, value_name):
            k, v = getattr(layer, key_name), getattr(layer, value_name)
            if torch.is_tensor(k) and torch.is_tensor(v):
                return k, v

    return None


def _normalise_past_key_values(past_key_values: Any) -> List[Tuple[torch.Tensor, torch.Tensor]]:
    """Convert common Hugging Face cache formats into ``[(k, v), ...]``.

    Supported formats include:

    * legacy tuple/list caches: ``((k, v), (k, v), ...)``
    * cache objects exposing ``to_legacy_cache()``
    * older ``DynamicCache`` objects exposing ``key_cache`` / ``value_cache``
    * newer ``DynamicCache`` objects exposing a ``layers`` list where each layer
      stores tensors as ``.keys`` and ``.values``
    * cache-like objects supporting ``len(cache)`` and ``cache[i]``
    """
    # Legacy tuple/list cache: ((k, v), (k, v), ...)
    if isinstance(past_key_values, (list, tuple)):
        out: List[Tuple[torch.Tensor, torch.Tensor]] = []
        for layer in past_key_values:
            pair = _extract_kv_pair_from_cache_layer(layer)
            if pair is not None:
                out.append(pair)
        if out:
            return out

    # New Cache object in several transformers versions. Guard this call because
    # some cache classes expose the method but raise when the cache is not in a
    # legacy-compatible layout.
    if hasattr(past_key_values, "to_legacy_cache"):
        try:
            legacy = past_key_values.to_legacy_cache()
        except Exception:
            legacy = None
        if legacy is not None and legacy is not past_key_values:
            out = _normalise_past_key_values(legacy)
            if out:
                return out

    # Older DynamicCache exposes key_cache/value_cache lists.
    if hasattr(past_key_values, "key_cache") and hasattr(past_key_values, "value_cache"):
        keys = getattr(past_key_values, "key_cache")
        values = getattr(past_key_values, "value_cache")
        out = []
        for k, v in zip(keys, values):
            if torch.is_tensor(k) and torch.is_tensor(v):
                out.append((k, v))
        if out:
            return out

    # Newer DynamicCache exposes per-layer cache objects through .layers. The
    # layer objects typically hold .keys and .values tensors. Hugging Face docs
    # describe DynamicCache as the default cache class and DynamicLayer stores
    # tensors with shape [batch, heads, seq, head_dim].
    if hasattr(past_key_values, "layers"):
        layers = getattr(past_key_values, "layers")
        out = []
        for layer in layers:
            pair = _extract_kv_pair_from_cache_layer(layer)
            if pair is not None:
                out.append(pair)
        if out:
            return out

    # Cache-like objects may support __len__ and __getitem__ without being lists.
    try:
        n_layers = len(past_key_values)  # type: ignore[arg-type]
    except Exception:
        n_layers = 0
    if n_layers:
        out = []
        for idx in range(int(n_layers)):
            try:
                pair = _extract_kv_pair_from_cache_layer(past_key_values[idx])
            except Exception:
                pair = None
            if pair is not None:
                out.append(pair)
        if out:
            return out

    attrs = ", ".join(
        name for name in ("to_legacy_cache", "key_cache", "value_cache", "layers", "cache", "keys", "values")
        if hasattr(past_key_values, name)
    ) or "no known cache attributes"
    raise RuntimeError(f"Unsupported past_key_values format: {type(past_key_values)!r}; visible cache attrs: {attrs}")


def _ensure_bhsd(x: torch.Tensor) -> torch.Tensor:
    """Return a KV tensor shaped (batch, heads, seq, head_dim)."""
    if x.ndim != 4:
        raise ValueError(f"KV tensor must be rank-4; got shape {tuple(x.shape)}")
    # Most causal LMs already use (batch, heads, seq, dim). If the second axis is
    # longer than the third axis, it is likely (batch, seq, heads, dim).
    if x.shape[1] > x.shape[2] and x.shape[2] <= 128:
        return x.permute(0, 2, 1, 3).contiguous()
    return x.contiguous()


def _largest_divisor_at_most(n: int, limit: int) -> int:
    """Return the largest positive divisor of ``n`` that is <= ``limit``.

    The current Triton compressed-page prototype requires every page to be
    full. Real prompts often produce sequence lengths that are not divisible by
    the requested page size. Instead of padding and accidentally changing
    attention semantics, the real-model benchmark picks a compatible page size
    for that specific KV tensor.
    """
    n = max(1, int(n))
    limit = max(1, min(int(limit), n))
    for d in range(limit, 0, -1):
        if n % d == 0:
            return d
    return 1


def _effective_full_page_size(seq_len: int, requested_page_size: int) -> Tuple[int, Dict[str, Any]]:
    """Choose a Triton-compatible page size without padding real KV tokens."""
    seq_len = max(1, int(seq_len))
    requested = max(1, int(requested_page_size))
    if seq_len % requested == 0:
        return requested, {
            "requested_page_size": requested,
            "effective_page_size": requested,
            "adjusted": False,
            "reason": "requested page size divides real KV sequence length",
        }
    effective = _largest_divisor_at_most(seq_len, requested)
    return effective, {
        "requested_page_size": requested,
        "effective_page_size": effective,
        "adjusted": True,
        "reason": "real KV sequence length is not divisible by requested page size; using largest divisor <= requested size to avoid padded-token attention artifacts",
    }


def _normalise_query_tensor(q: torch.Tensor) -> torch.Tensor:
    work = q.float()
    denom = work.norm(dim=-1, keepdim=True).clamp_min(1e-6)
    # Keep a stable O(1) vector norm. This avoids degenerate last-key/random
    # proxies that can make dense/SDPA reference quality metrics invalid.
    work = work / denom
    return work.to(dtype=q.dtype)


def _build_model_query_steps(config: RealModelKVBenchConfig, k: torch.Tensor) -> torch.Tensor:
    torch.manual_seed(int(config.seed))
    steps = max(1, int(config.decode_steps))
    if config.query_source == "last-key":
        q = k[:, :, -1:, :].detach().contiguous()
        q_steps = q.repeat(steps, 1, 1, 1, 1).contiguous()
    else:
        q_steps = torch.randn(
            steps,
            k.shape[0],
            k.shape[1],
            1,
            k.shape[3],
            device=k.device,
            dtype=k.dtype,
        )
        if config.query_source == "random-normalized":
            q_steps = _normalise_query_tensor(q_steps).contiguous()
    return q_steps


def _run_attention_decode_on_kv(
    *,
    config: Any,
    q_steps: torch.Tensor,
    k: torch.Tensor,
    v: torch.Tensor,
    key_bits: int,
    value_bits: int,
    quant_mode: str,
    dtype_bytes: int,
    device: str,
) -> Dict[str, Any]:
    """Shared decode-loop benchmark over supplied KV tensors."""
    _sync(device)
    t0 = time.perf_counter()
    table = CompressedKVPageTable.from_dense(
        k,
        v,
        key_bits=int(key_bits),
        value_bits=int(value_bits),
        page_size=int(config.page_size),
        seed=int(config.seed),
        dtype_bytes=int(dtype_bytes),
        quantization_mode=str(quant_mode),
    )
    _sync(device)
    table_build_seconds = float(time.perf_counter() - t0)

    _sync(device)
    t0 = time.perf_counter()
    payloads = _concat_page_payloads(table)
    _sync(device)
    payload_prepare_seconds = float(time.perf_counter() - t0)

    first_q = q_steps[0]
    dense_first = dense_attention(first_q, k, v)
    memory = table.memory_report().to_dict()

    selected: Optional[Dict[str, Any]] = None
    if device == "cuda" and bool(config.prefer_triton):
        selected = _select_e2e_split_k_candidate(config, dense_first, first_q, table, payloads)

    def _dense_loop():
        out = None
        for i in range(int(config.decode_steps)):
            out = dense_attention(q_steps[i], k, v)
        return out

    def _sdpa_loop():
        out = None
        for i in range(int(config.decode_steps)):
            out = sdpa_attention(q_steps[i], k, v)
        return out

    dense_last, dense_per_token, dense_loop_total = _time_decode_loop(
        _dense_loop,
        device=device,
        warmup=config.warmup,
        repeats=config.repeats,
        decode_steps=config.decode_steps,
    )
    sdpa_last, sdpa_per_token, sdpa_loop_total = _time_decode_loop(
        _sdpa_loop,
        device=device,
        warmup=config.warmup,
        repeats=config.repeats,
        decode_steps=config.decode_steps,
    )

    single_last = None
    single_per_token = None
    single_loop_total = None
    if bool(getattr(config, "include_single_pass_loop", True)):
        def _single_loop():
            out = None
            for i in range(int(config.decode_steps)):
                out, _ = experimental_fused_compressed_decode_attention(
                    q_steps[i],
                    table,
                    prefer_triton=config.prefer_triton,
                    kernel_block_m=int(config.kernel_block_m),
                    kernel_num_warps=int(config.kernel_num_warps),
                )
            return out

        single_last, single_per_token, single_loop_total = _time_decode_loop(
            _single_loop,
            device=device,
            warmup=config.warmup,
            repeats=config.repeats,
            decode_steps=config.decode_steps,
        )

    split_last = None
    split_per_token = None
    split_loop_total = None
    graph_report: Dict[str, Any] = {
        "enabled": bool(getattr(config, "cuda_graph", False)),
        "attempted": False,
        "captured": False,
        "seconds_per_token": None,
        "reason": "CUDA Graph replay disabled",
    }

    selected_quality_ok = bool(selected is not None and selected.get("candidate_quality_ok", False))
    if selected_quality_ok:
        slabs = int(selected["split_k_slabs"])
        block_m = int(selected["kernel_block_m"])
        num_warps = int(selected["kernel_num_warps"])
        _, heads, _, head_dim = table.dense_shape
        partial_m = torch.empty((slabs, heads), device=q_steps.device, dtype=torch.float32)
        partial_l = torch.empty((slabs, heads), device=q_steps.device, dtype=torch.float32)
        partial_acc = torch.empty((slabs, heads, head_dim), device=q_steps.device, dtype=torch.float32)
        reduced = torch.empty((1, heads, 1, head_dim), device=q_steps.device, dtype=q_steps.dtype)

        def _split_loop():
            out = None
            for i in range(int(config.decode_steps)):
                q_rot = table.rotate_query(q_steps[i]).contiguous()
                _triton_split_k_stage1_partials_prepared(
                    q_rot,
                    payloads,
                    table,
                    partial_m,
                    partial_l,
                    partial_acc,
                    split_k_slabs=slabs,
                    kernel_block_m=block_m,
                    kernel_num_warps=num_warps,
                )
                out = _triton_split_k_stage2_reduce_prepared(
                    partial_m,
                    partial_l,
                    partial_acc,
                    reduced,
                    kernel_num_warps=1,
                )
            return out

        split_last, split_per_token, split_loop_total = _time_decode_loop(
            _split_loop,
            device=device,
            warmup=config.warmup,
            repeats=config.repeats,
            decode_steps=config.decode_steps,
        )

        if bool(getattr(config, "cuda_graph", False)):
            graph_out, graph_seconds, graph_meta = _time_cuda_graph_call(
                _split_loop,
                device=device,
                warmup=config.warmup,
                graph_replays=config.graph_replays,
            )
            graph_report.update(graph_meta)
            if graph_seconds is not None:
                graph_report["seconds_per_token"] = float(graph_seconds) / max(1, int(config.decode_steps))
                graph_report["loop_seconds"] = float(graph_seconds)
                if graph_out is not None:
                    graph_report["quality_vs_dense_last"] = _safe_attention_similarity(dense_last, graph_out)
                graph_report["over_sdpa_per_token"] = _safe_ratio(graph_report.get("seconds_per_token"), sdpa_per_token)
                graph_report["speedup_vs_sdpa_per_token"] = _safe_ratio(sdpa_per_token, graph_report.get("seconds_per_token"))
                graph_report["kernel_loop_beats_sdpa"] = bool(
                    graph_report.get("seconds_per_token") is not None
                    and sdpa_per_token is not None
                    and graph_report["seconds_per_token"] <= sdpa_per_token
                )
                over = graph_report.get("over_sdpa_per_token")
                graph_report["near_sdpa_per_token"] = bool(over is not None and over <= 1.10)

    setup_seconds = table_build_seconds + payload_prepare_seconds
    split_total_with_setup = (setup_seconds + float(split_loop_total)) if split_loop_total is not None else None
    split_amortized = (split_total_with_setup / max(1, int(config.decode_steps))) if split_total_with_setup is not None else None
    split_first_token_with_setup = (setup_seconds + float(split_per_token)) if split_per_token is not None else None
    amortization = _setup_amortization_report(
        setup_seconds=setup_seconds,
        table_build_seconds=table_build_seconds,
        payload_prepare_seconds=payload_prepare_seconds,
        split_per_token=split_per_token,
        sdpa_per_token=sdpa_per_token,
        steps=tuple(getattr(config, "amortization_steps", (int(config.decode_steps),))),
    )

    return {
        "kv_shape": list(k.shape),
        "decode_steps": int(config.decode_steps),
        "preset": config.preset,
        "quantization_mode": table.quantization_mode,
        "key_bits": int(key_bits),
        "value_bits": int(value_bits),
        "page_size": int(config.page_size),
        "page_count": int(table.page_count),
        "memory": memory,
        "setup": {
            "table_build_seconds": table_build_seconds,
            "payload_prepare_seconds": payload_prepare_seconds,
            "total_setup_seconds": setup_seconds,
            "prepared_payloads_reused": True,
            "output_buffers_reused": bool(selected is not None),
        },
        "dense_decode": {
            "loop_seconds": dense_loop_total,
            "seconds_per_token": dense_per_token,
            "tokens_per_second": _safe_ratio(1.0, dense_per_token),
        },
        "sdpa_decode": {
            "loop_seconds": sdpa_loop_total,
            "seconds_per_token": sdpa_per_token,
            "tokens_per_second": _safe_ratio(1.0, sdpa_per_token),
            "quality_vs_dense_last": _safe_attention_similarity(dense_last, sdpa_last),
        },
        "single_pass_decode": None if single_per_token is None else {
            "loop_seconds": single_loop_total,
            "seconds_per_token": single_per_token,
            "tokens_per_second": _safe_ratio(1.0, single_per_token),
            "over_sdpa_per_token": _safe_ratio(single_per_token, sdpa_per_token),
            "quality_vs_dense_last": _safe_attention_similarity(dense_last, single_last) if single_last is not None else None,
        },
        "split_k_decode": (
            None if selected is None else (
                {
                    "selected": selected,
                    "status": "not_run",
                    "selection_error": selected.get("selection_error", "split-K candidate did not pass quality gate"),
                    "kernel_loop_beats_sdpa": False,
                    "amortized_with_setup_beats_sdpa": False,
                    "amortization": amortization,
                } if split_per_token is None else {
                    "selected": selected,
                    "status": "measured",
                    "loop_seconds": split_loop_total,
                    "seconds_per_token": split_per_token,
                    "tokens_per_second": _safe_ratio(1.0, split_per_token),
                    "over_sdpa_per_token": _safe_ratio(split_per_token, sdpa_per_token),
                    "speedup_vs_sdpa_per_token": _safe_ratio(sdpa_per_token, split_per_token),
                    "speedup_vs_single_pass_per_token": _safe_ratio(single_per_token, split_per_token) if single_per_token is not None else None,
                    "total_with_setup_seconds": split_total_with_setup,
                    "amortized_seconds_per_token_with_setup": split_amortized,
                    "first_token_seconds_with_setup": split_first_token_with_setup,
                    "amortized_over_sdpa_per_token": _safe_ratio(split_amortized, sdpa_per_token) if split_amortized is not None else None,
                    "first_token_over_sdpa_per_token": _safe_ratio(split_first_token_with_setup, sdpa_per_token) if split_first_token_with_setup is not None else None,
                    "quality_vs_dense_last": _safe_attention_similarity(dense_last, split_last) if split_last is not None else None,
                    "kernel_loop_beats_sdpa": bool(split_per_token is not None and split_per_token <= sdpa_per_token),
                    "amortized_with_setup_beats_sdpa": bool(split_amortized is not None and split_amortized <= sdpa_per_token),
                    "amortization": amortization,
                    "cuda_graph_seconds_per_token": graph_report.get("seconds_per_token"),
                    "cuda_graph_over_sdpa_per_token": graph_report.get("over_sdpa_per_token"),
                    "cuda_graph_speedup_vs_sdpa_per_token": graph_report.get("speedup_vs_sdpa_per_token"),
                    "cuda_graph_kernel_loop_beats_sdpa": graph_report.get("kernel_loop_beats_sdpa"),
                    "cuda_graph_near_sdpa_per_token": graph_report.get("near_sdpa_per_token"),
                }
            )
        ),
        "cuda_graph_decode": graph_report,
        "boundary": "Real model KV-cache attention benchmark with model-shaped query proxy; not full model serving.",
    }


def run_real_model_kv_benchmark(config: RealModelKVBenchConfig) -> Dict[str, Any]:
    """Run a real-model KV-cache compressed-attention diagnostic."""
    requested_device = config.device
    requested_dtype = config.dtype
    device = _resolve_device(requested_device)
    dtype = _resolve_dtype(requested_dtype, device)
    warnings = _runtime_warnings(requested_device, device, requested_dtype, dtype)

    row: Dict[str, Any]
    try:
        AutoModelForCausalLM, AutoTokenizer = _import_transformers_for_real_kv()
        load_kwargs = {
            "local_files_only": bool(config.local_files_only),
            "trust_remote_code": bool(config.trust_remote_code),
        }
        tok = AutoTokenizer.from_pretrained(config.model, **load_kwargs)
        model_kwargs = dict(load_kwargs)
        if device == "cuda":
            model_kwargs["torch_dtype"] = dtype
        model = AutoModelForCausalLM.from_pretrained(config.model, **model_kwargs)
        model.eval()
        model.to(device)

        encoded = tok(config.prompt, return_tensors="pt", truncation=bool(config.max_prompt_tokens), max_length=config.max_prompt_tokens)
        input_ids = encoded["input_ids"].to(device)
        attention_mask = encoded.get("attention_mask")
        if attention_mask is not None:
            attention_mask = attention_mask.to(device)

        _sync(device)
        t0 = time.perf_counter()
        with torch.no_grad():
            outputs = model(input_ids=input_ids, attention_mask=attention_mask, use_cache=True)
        _sync(device)
        model_forward_seconds = float(time.perf_counter() - t0)

        layers = _normalise_past_key_values(outputs.past_key_values)
        if not layers:
            raise RuntimeError("Model returned no past_key_values")
        layer_index = int(config.layer_index)
        if layer_index < 0:
            layer_index = len(layers) + layer_index
        if layer_index < 0 or layer_index >= len(layers):
            raise IndexError(f"layer_index {config.layer_index} out of range for {len(layers)} KV layers")

        k, v = layers[layer_index]
        k = _ensure_bhsd(k).detach().to(device=device, dtype=dtype).contiguous()
        v = _ensure_bhsd(v).detach().to(device=device, dtype=dtype).contiguous()
        if k.shape != v.shape:
            raise ValueError(f"K/V shapes must match; got {tuple(k.shape)} and {tuple(v.shape)}")

        kv_head_repeat = int(getattr(config, "kv_head_repeat", 1))
        kv_head_repeat_note = None
        original_kv_shape = list(k.shape)
        if kv_head_repeat > 1:
            k = k.repeat(1, kv_head_repeat, 1, 1).contiguous()
            v = v.repeat(1, kv_head_repeat, 1, 1).contiguous()
            kv_head_repeat_note = (
                f"real KV heads were repeated {kv_head_repeat}x for stress testing; "
                "this changes benchmark workload size and is not a literal model layer shape"
            )
            warnings.append(kv_head_repeat_note)

        effective_page_size, page_size_policy = _effective_full_page_size(
            seq_len=int(k.shape[2]),
            requested_page_size=int(config.page_size),
        )
        bench_config = config
        if effective_page_size != int(config.page_size):
            warnings.append(
                "real model KV sequence length is not divisible by requested page_size; "
                f"using effective_page_size={effective_page_size} for this benchmark"
            )
            bench_config = replace(config, page_size=int(effective_page_size))

        q_steps = _build_model_query_steps(config, k)
        dtype_bytes = torch.empty((), dtype=dtype).element_size()
        key_bits = int(getattr(config, "_resolved_key_bits", 8))
        value_bits = int(getattr(config, "_resolved_value_bits", 6))
        quant_mode = str(getattr(config, "_resolved_quantization_mode", "affine"))

        bench = _run_attention_decode_on_kv(
            config=bench_config,
            q_steps=q_steps,
            k=k,
            v=v,
            key_bits=key_bits,
            value_bits=value_bits,
            quant_mode=quant_mode,
            dtype_bytes=dtype_bytes,
            device=device,
        )
        bench.update({
            "model": config.model,
            "layer_index": int(config.layer_index),
            "actual_layer_index": int(layer_index),
            "num_kv_layers": int(len(layers)),
            "prompt_tokens": int(input_ids.shape[-1]),
            "query_source": config.query_source,
            "query_source_note": "random-normalized is the recommended stable diagnostic default; last-key can create degenerate quality checks on some models",
            "model_forward_seconds": model_forward_seconds,
            "original_kv_shape": original_kv_shape,
            "kv_head_repeat": int(kv_head_repeat),
            "kv_head_repeat_note": kv_head_repeat_note,
            "page_size_policy": page_size_policy,
            "note": "KV tensors come from a real Hugging Face model forward pass. Decode queries use the configured proxy source; this is not full autoregressive generation.",
        })
        row = bench
    except Exception as exc:
        warnings.append(f"real model KV benchmark failed: {exc!r}")
        row = {
            "model": config.model,
            "error": repr(exc),
            "boundary": "Real model KV benchmark could not run in this environment.",
        }

    split_row = (row.get("split_k_decode") or {}) if "error" not in row else {}
    graph_row = (row.get("cuda_graph_decode") or {}) if "error" not in row else {}
    sdpa_row = (row.get("sdpa_decode") or {}) if "error" not in row else {}
    any_kernel_sdpa = bool(split_row.get("kernel_loop_beats_sdpa")) if "error" not in row else False
    any_amortized_sdpa = bool(split_row.get("amortized_with_setup_beats_sdpa")) if "error" not in row else False
    any_graph_sdpa = bool(graph_row.get("kernel_loop_beats_sdpa")) if "error" not in row else False
    any_graph_near_sdpa = bool(graph_row.get("near_sdpa_per_token")) if "error" not in row else False
    graph_over_sdpa = graph_row.get("over_sdpa_per_token")
    any_grid_full_setup_sdpa = any(
        bool(step.get("full_setup_beats_sdpa"))
        for step in ((split_row.get("amortization") or {}).get("steps") or [])
    ) if "error" not in row else False
    any_grid_payload_only_sdpa = any(
        bool(step.get("payload_prepare_only_beats_sdpa"))
        for step in ((split_row.get("amortization") or {}).get("steps") or [])
    ) if "error" not in row else False
    workload_note = None
    if "error" not in row:
        kv_shape = row.get("kv_shape") or []
        if len(kv_shape) >= 4 and int(kv_shape[1]) <= 2 and int(kv_shape[2]) <= 2048:
            workload_note = "small real-KV workload: few KV heads and <=2048 tokens; SDPA can be hard to beat"

    if any_graph_sdpa:
        graph_verdict = "real-kv-cuda-graph-split-k-beats-sdpa"
    elif any_graph_near_sdpa:
        graph_verdict = "real-kv-cuda-graph-split-k-near-sdpa"
    elif graph_row.get("captured"):
        graph_verdict = "real-kv-cuda-graph-split-k-not-competitive"
    else:
        graph_verdict = "real-kv-cuda-graph-not-captured-or-not-run"

    return {
        "version": "real-model-kv-benchmark-v0.11.2.4",
        "config": asdict(config),
        "runtime": {
            "requested_device": requested_device,
            "device": device,
            "requested_dtype": requested_dtype,
            "dtype": str(dtype).replace("torch.", ""),
            "triton": triton_status(),
        },
        "warnings": warnings,
        "rows": [row],
        "summary": {
            "kernel_loop_verdict": "real-kv-split-k-loop-beats-sdpa" if any_kernel_sdpa else "real-kv-split-k-loop-not-competitive-or-not-run",
            "amortized_with_setup_verdict": "real-kv-split-k-amortized-with-setup-beats-sdpa" if (any_amortized_sdpa or any_grid_full_setup_sdpa) else "real-kv-setup-cost-still-needs-amortization-or-not-run",
            "payload_only_setup_verdict": "real-kv-payload-only-setup-beats-sdpa-in-grid" if any_grid_payload_only_sdpa else "real-kv-payload-only-setup-not-proven",
            "real_kv_cuda_graph_verdict": graph_verdict,
            "real_kv_cuda_graph_over_sdpa": graph_over_sdpa,
            "workload_note": workload_note,
            "measured_kernel_verdict": "v0.11.2.4 extracts real Hugging Face past_key_values, supports DynamicCache, auto-selects full-page-compatible page size, filters invalid split-K slab counts, reports candidate diagnostics, and includes CUDA Graph split-K verdicts",
            "boundary": "This is a real-KV attention diagnostic, not full autoregressive LLM serving acceleration.",
        },
        "interpretation": (
            "v0.11.2.4 moves beyond synthetic K/V by extracting real model KV-cache tensors, including newer DynamicCache layouts, while avoiding padded-token attention artifacts for non-divisible prompt lengths and reporting split-K candidate diagnostics and CUDA Graph verdicts instead of failing the whole benchmark. "
            "The decode query remains a model-shaped proxy unless the caller chooses random queries; this is not a full model generation benchmark."
        ),
    }


def real_model_kv_markdown_report(report: Dict[str, Any]) -> str:
    lines = [
        "# tiny-turboquant real-model KV benchmark",
        "",
        "This report uses real Hugging Face `past_key_values` tensors and benchmarks compressed attention over them. It is not full model serving.",
        "",
        "## Summary",
        f"- {report.get('summary')}",
        "",
        "## Rows",
    ]
    for row in report.get("rows", []):
        if "error" in row:
            lines.append(f"- model={row.get('model')}: ERROR {row.get('error')}")
            continue
        split = row.get("split_k_decode") or {}
        sdpa = row.get("sdpa_decode") or {}
        setup = row.get("setup") or {}
        mem = row.get("memory") or {}
        amort = split.get("amortization") or {}
        lines.append(
            f"- model={row.get('model')}, layer={row.get('actual_layer_index')}, prompt_tokens={row.get('prompt_tokens')}, "
            f"kv_shape={row.get('kv_shape')}, memory_saved={mem.get('effective_memory_saved_pct')}, "
            f"setup={setup.get('total_setup_seconds')}, sdpa/token={sdpa.get('seconds_per_token')}, "
            f"split_k/token={split.get('seconds_per_token')}, speedup_vs_sdpa={split.get('speedup_vs_sdpa_per_token')}, "
            f"break_even_full_setup={amort.get('break_even_decode_steps_full_setup')}, "
            f"break_even_payload_only={amort.get('break_even_decode_steps_payload_prepare_only')}, "
            f"cos={((split.get('quality_vs_dense_last') or {}).get('cosine_similarity'))}"
        )
    lines.extend(["", "## Boundary", "This is not a production acceleration claim."])
    return "\n".join(lines) + "\n"


def save_real_model_kv_json(report: Dict[str, Any], path: str | Path) -> None:
    Path(path).write_text(json.dumps(report, indent=2), encoding="utf-8")


def save_real_model_kv_markdown(report: Dict[str, Any], path: str | Path) -> None:
    Path(path).write_text(real_model_kv_markdown_report(report), encoding="utf-8")

def end_to_end_decode_markdown_report(report: Dict[str, Any]) -> str:
    lines = [
        "# tiny-turboquant end-to-end decode diagnostic",
        "",
        "This report measures fixed-cache repeated decode-loop behavior with setup accounting. It is not a full model-serving benchmark.",
        "",
        "## Summary",
        f"- {report.get('summary')}",
        "",
        "## Rows",
    ]
    for row in report.get("rows", []):
        if "error" in row:
            lines.append(f"- prompt_len={row.get('prompt_len')}: ERROR {row.get('error')}")
            continue
        split = row.get("split_k_decode") or {}
        sdpa = row.get("sdpa_decode") or {}
        setup = row.get("setup") or {}
        amort = split.get("amortization") or {}
        lines.append(
            f"- prompt_len={row.get('prompt_len')}, decode_steps={row.get('decode_steps')}, "
            f"setup={setup.get('total_setup_seconds')}, sdpa/token={sdpa.get('seconds_per_token')}, "
            f"split_k/token={split.get('seconds_per_token')}, split_k_over_sdpa={split.get('over_sdpa_per_token')}, "
            f"amortized_over_sdpa={split.get('amortized_over_sdpa_per_token')}, "
            f"break_even_full_setup={amort.get('break_even_decode_steps_full_setup')}, "
            f"break_even_payload_only={amort.get('break_even_decode_steps_payload_prepare_only')}, "
            f"cos={((split.get('quality_vs_dense_last') or {}).get('cosine_similarity'))}"
        )
    lines.extend(["", "## Boundary", "This is not a production acceleration claim."])
    return "\n".join(lines) + "\n"


def save_end_to_end_decode_json(report: Dict[str, Any], path: str | Path) -> None:
    Path(path).write_text(json.dumps(report, indent=2), encoding="utf-8")


def save_end_to_end_decode_markdown(report: Dict[str, Any], path: str | Path) -> None:
    Path(path).write_text(end_to_end_decode_markdown_report(report), encoding="utf-8")
