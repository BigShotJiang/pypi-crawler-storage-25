from __future__ import annotations

import subprocess
import sys
from pathlib import Path

import torch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tiny_turboquant.kv.compression import CompressedTensor, TinyTurboKVCache
from tiny_turboquant.kv.policy import available_kv_policies, resolve_kv_policy


def test_v012_policy_registry_contains_backend_defaults():
    names = available_kv_policies()
    assert "fp16" in names
    assert "q8k-q8v" in names
    assert "q8k-int4v" in names
    assert resolve_kv_policy("q8k-int4v").boundary_layer_count == 2


def test_v012_compressed_tensor_roundtrip_shape_and_storage():
    torch.manual_seed(120)
    x = torch.randn(1, 2, 8, 16, dtype=torch.float32)
    c = CompressedTensor.from_tensor(x, bits=4)
    y = c.dequantize(dtype=x.dtype)
    assert y.shape == x.shape
    assert c.storage_bytes() < c.dense_bytes(dtype_bytes=4)
    assert torch.isfinite(y).all()


def test_v012_tiny_turbo_kv_cache_roundtrip_tuple():
    torch.manual_seed(121)
    past = tuple((torch.randn(1, 2, 8, 16), torch.randn(1, 2, 8, 16)) for _ in range(6))
    cache = TinyTurboKVCache.from_past_key_values(past, "q8k-int4v")
    dense = cache.to_past_key_values(dtype=torch.float32)
    assert len(dense) == 6
    assert dense[0][0].shape == past[0][0].shape
    report = cache.to_dict()
    assert report["policy"] == "q8k-int4v"
    assert report["compressed_storage_bytes"] < report["dense_fp16_bytes"]
    assert report["layer_policies"][0].endswith("boundary-q8")
    assert report["layer_policies"][2] == "q8k-int4v"


def test_v012_cli_lists_policies_without_hf_download():
    result = subprocess.run(
        [sys.executable, "-m", "tiny_turboquant.cli", "bench", "--list-policies"],
        cwd=str(__import__("pathlib").Path(__file__).resolve().parents[1]),
        check=True,
        capture_output=True,
        text=True,
    )
    assert "q8k-q8v" in result.stdout
    assert "q8k-int4v" in result.stdout


def test_v0121_kv_cache_accepts_extended_layer_entries():
    torch.manual_seed(122)
    k = torch.randn(1, 2, 8, 16)
    v = torch.randn(1, 2, 8, 16)
    aux = torch.randn(1)
    past = ((k, v, aux, "ignored"),)
    cache = TinyTurboKVCache.from_past_key_values(past, "q8k-q8v")
    dense = cache.to_past_key_values(dtype=torch.float32)
    assert len(dense) == 1
    assert len(dense[0]) == 2
    assert dense[0][0].shape == k.shape
    assert dense[0][1].shape == v.shape


class _FakeHFCache:
    def __init__(self, past):
        self._past = past

    def to_legacy_cache(self):
        return self._past


def test_v0121_kv_cache_accepts_hf_cache_object_with_extended_entries():
    torch.manual_seed(123)
    k = torch.randn(1, 2, 8, 16)
    v = torch.randn(1, 2, 8, 16)
    past = _FakeHFCache(((k, v, None),))
    cache = TinyTurboKVCache.from_past_key_values(past, "fp16")
    dense = cache.to_past_key_values(dtype=torch.float32)
    assert dense[0][0].shape == k.shape
    assert dense[0][1].shape == v.shape


def test_cache_records_new_transformers_cache_format():
    import torch
    from tiny_turboquant.kv.compression import TinyTurboKVCache

    class FakeDynamicCache:
        def __init__(self, legacy):
            self._legacy = legacy
        def to_legacy_cache(self):
            return self._legacy
        def get_seq_length(self):
            return self._legacy[0][0].shape[-2]

    k = torch.randn(1, 2, 4, 8)
    v = torch.randn(1, 2, 4, 8)
    cache = TinyTurboKVCache.from_past_key_values(FakeDynamicCache(((k, v),)), "q8k-q8v")
    assert cache.source_requires_cache_object is True
    assert cache.source_cache_type == "FakeDynamicCache"
    assert cache.to_past_key_values()[0][0].shape == k.shape


def test_cache_accepts_legacy_extra_fields():
    import torch
    from tiny_turboquant.kv.compression import TinyTurboKVCache

    k = torch.randn(1, 2, 4, 8)
    v = torch.randn(1, 2, 4, 8)
    extra = torch.ones(1)
    cache = TinyTurboKVCache.from_past_key_values(((k, v, extra),), "q8k-q8v")
    dense = cache.to_past_key_values()
    assert len(dense[0]) == 2
    assert dense[0][0].shape == k.shape
    assert cache.source_requires_cache_object is False
