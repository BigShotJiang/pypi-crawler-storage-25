"""Inference backend abstraction — Ollama, llama-server, and OpenAI-compatible."""

from .base import InferenceBackend, StreamChunk
from .ollama import OllamaBackend
from .openai_compat import OpenAICompatBackend
from .registry import detect_backends, get_backend
from .params import calculate_params, build_server_args
from .server_manager import (
    start_server,
    stop_server,
    is_llama_server_installed,
    get_managed_port,
    is_server_running,
)

__all__ = [
    "InferenceBackend",
    "StreamChunk",
    "OllamaBackend",
    "OpenAICompatBackend",
    "detect_backends",
    "get_backend",
    "calculate_params",
    "build_server_args",
    "start_server",
    "stop_server",
    "is_llama_server_installed",
    "get_managed_port",
    "is_server_running",
]
