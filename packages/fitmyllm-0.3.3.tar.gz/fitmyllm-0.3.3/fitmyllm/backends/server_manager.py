"""Server lifecycle manager — start/stop llama-server as a child process."""

from __future__ import annotations

import atexit
import shutil
import signal
import subprocess
import time
from pathlib import Path

import httpx

from .params import build_server_args

# Module-level singleton: the managed server process
_managed_server: subprocess.Popen | None = None
_managed_port: int | None = None


def is_llama_server_installed() -> bool:
    """Check if llama-server binary is available."""
    return shutil.which("llama-server") is not None


def start_server(
    gguf_path: str | Path,
    params: dict,
    port: int = 8080,
) -> int:
    """Start llama-server with the given parameters.

    Tries ports 8080, 8081, 8082 if the preferred port is busy.

    Args:
        gguf_path: Path to the GGUF model file.
        params: Dict from calculate_params().
        port: Preferred port (will try +1, +2 on conflict).

    Returns:
        The port the server is running on.

    Raises:
        FileNotFoundError: If llama-server is not installed.
        RuntimeError: If the server fails to start on any port.
    """
    global _managed_server, _managed_port

    if not is_llama_server_installed():
        raise FileNotFoundError(
            "llama-server not found. Install llama.cpp: "
            "https://github.com/ggerganov/llama.cpp#build"
        )

    # Stop any existing managed server
    stop_server()

    # Try up to 3 ports
    last_error = None
    for offset in range(3):
        try_port = port + offset
        if _port_in_use(try_port):
            continue

        args = build_server_args(str(gguf_path), params, port=try_port)
        cmd = ["llama-server"] + args

        try:
            proc = subprocess.Popen(
                cmd,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.PIPE,
                text=True,
            )

            # Wait for the server to become ready
            if wait_for_ready(try_port, timeout=60.0):
                _managed_server = proc
                _managed_port = try_port
                atexit.register(stop_server)
                return try_port

            # Server started but didn't become ready
            proc.kill()
            proc.wait()
            last_error = "Server started but health check failed"

        except Exception as e:
            last_error = str(e)

    raise RuntimeError(
        f"Failed to start llama-server: {last_error}. "
        f"Tried ports {port}-{port + 2}"
    )


def stop_server() -> None:
    """Stop the managed llama-server if running."""
    global _managed_server, _managed_port

    if _managed_server is None:
        return

    try:
        _managed_server.send_signal(signal.SIGTERM)
        try:
            _managed_server.wait(timeout=5)
        except subprocess.TimeoutExpired:
            _managed_server.kill()
            _managed_server.wait(timeout=3)
    except Exception:
        pass

    _managed_server = None
    _managed_port = None


def wait_for_ready(port: int, timeout: float = 60.0) -> bool:
    """Poll the health endpoint until the server responds."""
    deadline = time.time() + timeout
    url = f"http://localhost:{port}/health"

    while time.time() < deadline:
        try:
            resp = httpx.get(url, timeout=2.0)
            if resp.status_code == 200:
                return True
        except (httpx.ConnectError, httpx.TimeoutException):
            pass
        time.sleep(0.5)

    return False


def get_managed_port() -> int | None:
    """Return the port of the currently managed server, or None."""
    if _managed_server is not None and _managed_server.poll() is None:
        return _managed_port
    return None


def is_server_running() -> bool:
    """Check if the managed server is still running."""
    return _managed_server is not None and _managed_server.poll() is None


def _port_in_use(port: int) -> bool:
    """Check if a port is already in use."""
    try:
        resp = httpx.get(f"http://localhost:{port}/health", timeout=1.0)
        return True
    except (httpx.ConnectError, httpx.TimeoutException):
        return False
