"""GGUF download from HuggingFace — no extra dependencies, just httpx."""

from __future__ import annotations

import re
from pathlib import Path
from typing import Callable

import httpx

from ..config import get_models_dir

HF_API = "https://huggingface.co/api/models"


def resolve_gguf_url(repo: str, quant_level: str) -> str | None:
    """Find the GGUF download URL for a specific quant level in a HF repo.

    Args:
        repo: HuggingFace repo ID, e.g. "bartowski/Llama-3.2-3B-Instruct-GGUF"
        quant_level: e.g. "Q4_K_M", "Q5_K_M", "Q8_0"

    Returns:
        Direct download URL or None if not found.
    """
    try:
        resp = httpx.get(f"{HF_API}/{repo}", timeout=10.0)
        resp.raise_for_status()
        data = resp.json()
    except (httpx.HTTPError, Exception):
        return None

    siblings = data.get("siblings", [])
    quant_lower = quant_level.lower()

    # Look for GGUF files matching the quant level
    candidates = []
    for s in siblings:
        fname = s.get("rfilename", "")
        if not fname.endswith(".gguf"):
            continue
        # Match quant level in filename (case-insensitive)
        if quant_lower in fname.lower():
            candidates.append(fname)

    if not candidates:
        return None

    # Prefer exact quant match, then shortest filename
    candidates.sort(key=len)
    best = candidates[0]

    return f"https://huggingface.co/{repo}/resolve/main/{best}"


def download_gguf(
    url: str,
    filename: str | None = None,
    progress_callback: Callable[[int, int], None] | None = None,
) -> Path:
    """Download a GGUF file to the models directory.

    Args:
        url: Direct download URL.
        filename: Override filename (default: extract from URL).
        progress_callback: Called with (bytes_downloaded, total_bytes).

    Returns:
        Path to the downloaded file.

    Raises:
        httpx.HTTPError: On download failure.
    """
    models_dir = get_models_dir()
    models_dir.mkdir(parents=True, exist_ok=True)

    if filename is None:
        # Extract from URL path
        filename = url.split("/")[-1].split("?")[0]

    dest = models_dir / filename
    part = dest.with_suffix(dest.suffix + ".part")

    with httpx.stream("GET", url, follow_redirects=True, timeout=600.0) as resp:
        resp.raise_for_status()

        total = int(resp.headers.get("content-length", 0))
        downloaded = 0

        with open(part, "wb") as f:
            for chunk in resp.iter_bytes(chunk_size=1024 * 1024):  # 1MB chunks
                f.write(chunk)
                downloaded += len(chunk)
                if progress_callback:
                    progress_callback(downloaded, total)

    # Atomic rename on completion
    part.rename(dest)
    return dest
