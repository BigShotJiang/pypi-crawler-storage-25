"""GGUF download screen — progress bar for HuggingFace GGUF downloads."""

from __future__ import annotations

import time
from datetime import datetime
from pathlib import Path

from rich.markup import escape

from textual.app import ComposeResult
from textual.screen import Screen
from textual.widgets import Header, Footer, Static
from textual.binding import Binding
from textual import work

from ..models.download import download_gguf
from ..models.store import add_to_inventory
from ..backends import (
    calculate_params,
    start_server,
    is_llama_server_installed,
    get_managed_port,
)
from ..backends.openai_compat import OpenAICompatBackend
from ..detect import detect_gpu


def _fmt_size(b: int) -> str:
    """Format bytes as human-readable."""
    if b >= 1_073_741_824:
        return f"{b / 1_073_741_824:.1f} GB"
    if b >= 1_048_576:
        return f"{b / 1_048_576:.1f} MB"
    return f"{b / 1024:.0f} KB"


def _fmt_speed(bps: float) -> str:
    """Format bytes/sec as human-readable."""
    if bps >= 1_048_576:
        return f"{bps / 1_048_576:.1f} MB/s"
    if bps >= 1024:
        return f"{bps / 1024:.0f} KB/s"
    return f"{bps:.0f} B/s"


class GGUFInstallScreen(Screen):
    """Download a GGUF file from HuggingFace with live progress."""

    DEFAULT_CSS = "GGUFInstallScreen { layout: vertical; }"

    BINDINGS = [
        Binding("c", "start_chat", "Chat", show=True),
        Binding("escape", "app.pop_screen", "Back"),
    ]

    def __init__(
        self,
        url: str,
        model_id: str = "",
        model_name: str = "",
        quant_level: str = "",
        repo: str = "",
    ) -> None:
        super().__init__()
        self.url = url
        self.model_id = model_id
        self.model_name = model_name or url.split("/")[-1]
        self.quant_level = quant_level
        self.repo = repo
        self._filename: str | None = None
        self._gguf_path: Path | None = None

    def compose(self) -> ComposeResult:
        yield Header(show_clock=False)
        yield Static(
            f"\n  [bold]Downloading:[/] [cyan]{escape(self.model_name)}[/]"
            f"  [dim]{self.quant_level}[/]\n",
            id="install-title",
        )
        yield Static("  [dim]Starting download...[/]", id="install-phase")
        yield Static("", id="install-bar")
        yield Static("", id="install-detail")
        yield Footer()

    def on_mount(self) -> None:
        self._run_download()

    def _set_phase(self, text: str) -> None:
        try:
            self.query_one("#install-phase", Static).update(text)
        except Exception:
            pass

    def _set_bar(self, text: str) -> None:
        try:
            self.query_one("#install-bar", Static).update(text)
        except Exception:
            pass

    def _set_detail(self, text: str) -> None:
        try:
            self.query_one("#install-detail", Static).update(text)
        except Exception:
            pass

    def _render_bar(self, pct: int) -> str:
        if pct < 0:
            return ""
        w = 40
        filled = round(pct / 100 * w)
        bar_str = "\u2588" * filled + "\u2591" * (w - filled)
        color = "green" if pct >= 80 else "cyan" if pct >= 40 else "blue"
        return f"  [{color}]{bar_str}[/] [bold]{pct}%[/]"

    def action_start_chat(self) -> None:
        if not self._filename or not self._gguf_path:
            self.notify("Download not complete", severity="warning")
            return
        self._launch_and_chat()

    @work(thread=True)
    def _launch_and_chat(self) -> None:
        """Start llama-server with the downloaded GGUF and open chat."""
        from .chat import ChatScreen

        model_id = self._filename.replace(".gguf", "")

        # Check if llama-server already running
        port = get_managed_port()
        if port:
            backend = OpenAICompatBackend(base_url=f"http://localhost:{port}", name="llama-server")
            self.app.call_from_thread(self.app.push_screen, ChatScreen(model_id, backend=backend))
            return

        if not is_llama_server_installed():
            self.app.call_from_thread(
                self.notify,
                "llama-server not found — install llama.cpp to chat directly",
                severity="warning",
                timeout=5,
            )
            return

        # Detect GPU and calculate optimal params
        self.app.call_from_thread(self._set_detail, "\n  [cyan]Starting llama-server...[/]")

        gpu = detect_gpu()
        vram_mb = gpu.get("vram_mb") if gpu else None
        file_size_gb = self._gguf_path.stat().st_size / (1024**3)
        params = calculate_params(vram_mb=vram_mb, model_size_gb=file_size_gb)

        try:
            port = start_server(str(self._gguf_path), params)
            backend = OpenAICompatBackend(base_url=f"http://localhost:{port}", name="llama-server")
            self.app.call_from_thread(self.app.push_screen, ChatScreen(model_id, backend=backend))
        except Exception as e:
            self.app.call_from_thread(
                self._set_detail,
                f"\n  [red]Failed to start llama-server:[/] {escape(str(e))}"
                f"\n  [dim]Start it manually:[/] [cyan]llama-server -m {escape(str(self._gguf_path))} -ngl 99[/]",
            )

    @work(thread=True)
    def _run_download(self) -> None:
        start_time = time.time()
        last_update = 0.0

        def on_progress(downloaded: int, total: int) -> None:
            nonlocal last_update
            now = time.time()
            # Throttle UI updates to max 4/sec
            if now - last_update < 0.25:
                return
            last_update = now

            elapsed = now - start_time
            speed = downloaded / elapsed if elapsed > 0 else 0
            eta = (total - downloaded) / speed if speed > 0 and total > 0 else 0

            if total > 0:
                pct = int(downloaded / total * 100)
                self.app.call_from_thread(self._set_bar, self._render_bar(pct))
                detail = (
                    f"  [dim]{_fmt_size(downloaded)} / {_fmt_size(total)}"
                    f"  {_fmt_speed(speed)}"
                    f"  {int(eta)}s remaining[/]"
                )
            else:
                detail = f"  [dim]{_fmt_size(downloaded)}  {_fmt_speed(speed)}[/]"
                self.app.call_from_thread(self._set_bar, "")

            self.app.call_from_thread(self._set_detail, detail)

        try:
            self.app.call_from_thread(
                self._set_phase, "  [cyan]Downloading from HuggingFace...[/]"
            )

            path = download_gguf(
                url=self.url,
                progress_callback=on_progress,
            )

            self._filename = path.name
            self._gguf_path = path
            size = path.stat().st_size

            # Add to inventory
            add_to_inventory({
                "id": self.model_id,
                "name": self.model_name,
                "filename": path.name,
                "size_bytes": size,
                "quant_level": self.quant_level,
                "repo": self.repo,
                "downloaded_at": datetime.now().isoformat(),
            })

            elapsed = time.time() - start_time
            self.app.call_from_thread(
                self._set_phase, "  [green]\u2713 Downloaded successfully![/]"
            )
            self.app.call_from_thread(self._set_bar, "")
            self.app.call_from_thread(
                self._set_detail,
                f"\n  [dim]File:[/] {escape(path.name)}"
                f"\n  [dim]Size:[/] {_fmt_size(size)}"
                f"\n  [dim]Time:[/] {elapsed:.0f}s"
                f"\n  [dim]Path:[/] {escape(str(path))}"
                f"\n\n  [dim]Press [bold]c[/bold] to start llama-server & chat · [bold]escape[/bold] to go back[/]",
            )

        except Exception as e:
            self.app.call_from_thread(
                self._set_phase, f"  [red]\u2717 Download failed[/]"
            )
            self.app.call_from_thread(self._set_bar, "")
            self.app.call_from_thread(
                self._set_detail,
                f"\n  [red]{escape(str(e))}[/]"
                f"\n\n  [dim]Try manually:[/] [cyan]{escape(self.url)}[/]",
            )
