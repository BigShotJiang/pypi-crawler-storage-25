# Expose the configuration method
from .context import set_websocket_sender

# Expose the tools
from .slots import SendSlots

__all__ = [
    "set_websocket_sender",
    "SendSlots"
]