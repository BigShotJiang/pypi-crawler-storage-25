# Changelog

## 0.2.3 — Relax withdraw gate on testnet

- `talyxion add <exchange> --testnet` no longer rejects keys with
  `canWithdraw=true`. Testnet exchanges (testnet.binance.vision et al)
  always grant withdraw because there's no real-fund flow to toggle
  off — refusing them blocked all testnet onboarding. CLI now warns,
  rewrites the permission payload to `canWithdraw=false` before
  registering, and prompts the user to re-validate without --testnet
  before going live. Mainnet keys with withdraw enabled remain a
  hard reject.

## 0.2.2 — Graceful keyring failures

- Catch macOS Keychain `-25308 errSecInteractionNotAllowed` (locked or
  no UI session) + Linux Secret-Service locked errors + Windows
  Credential Manager unavailability. The CLI now prints a clear
  remediation message instead of a raw Python traceback.
- New ``KeyringUnavailable`` exception type in
  ``talyxion.cli.keyring_store`` for callers that want to catch it.
- Server-side: ``BotAccessControlMiddleware.PUBLIC_NONBROWSER_PREFIXES``
  now allowlists ``/api/v1/talyxion/auth/device/`` and
  ``/api/v1/talyxion/trading/`` so the CLI's device-token Bearer doesn't
  get rejected by the ``ApiAccessKey``-only middleware. Per-endpoint
  auth still enforced via ``@device_token_required`` at the view layer.

## 0.2.1 — Cloudflare-friendly User-Agent

- Wrap HTTP requests in a ``Mozilla/5.0 (compatible; talyxion-cli/…)``
  User-Agent so the unauth device-flow endpoints don't trip Cloudflare
  bot-fight WAF (was returning 403 to ``python-httpx/x.y.z``). The CLI
  build identifier remains in the UA string + ``X-App-Version`` header
  for our own analytics.

## 0.2.0 — Trader CLI

- **NEW** `talyxion` command-line tool — thin-client trader that runs
  Talyxion alphas with the user's own exchange API keys and IP. Keys
  stay on the user's machine (OS keyring); the server only stores the
  SHA-256 fingerprint + permission flags.
- OAuth 2.0 Device Authorization Grant (RFC 8628) for pairing — no
  copy-paste of tokens.
- Native Binance REST adapter (Spot + USD-M Futures). No ccxt dep.
- Local risk gates: drawdown halt, position-size clamp, symbol
  blocklist, withdraw-permission refusal (belt + braces against
  server-side enforcement).
- Idempotent cycle reports + heartbeats; archived-on-server profiles
  auto-stop on the next loop iteration.
- ``[cli]`` optional dependency group — `pip install talyxion[cli]`.
- Commands: `auth login|logout|status`, `add`, `remove`,
  `list profiles|creds`, `run [--once|--profile|--dry-run]`,
  `status`, `logs`, `update`.

## 0.1.0 — initial release

- Sync `Talyxion` client with API key auth.
- Resources: `signals`, `screener`, `datafields`, `ticker`, `rates`, `simulations`, `status`.
- Streaming: `sim_progress`, `feed_events` via WebSocket.
- Pydantic v2 models with optional pandas conversion.
- Typed exceptions mapped from backend error codes.
- Built-in retry with exponential backoff for 5xx + connection errors.
