"""``talyxion list profiles`` — read-only listing of the user's trading desks."""
from __future__ import annotations

import click
from rich.console import Console
from rich.table import Table

from talyxion.cli.device_token_client import (
    DeviceTokenClient,
    NotAuthenticatedError,
    TokenRevokedError,
)

console = Console()


@click.group(name="list")
def list_group():
    """Browse server-side state (profiles, credentials)."""


@list_group.command("profiles")
def list_profiles():
    """List trading profiles owned by this account.

    Shows only LOCAL-execution profiles (the ones the CLI manages).
    """
    try:
        with DeviceTokenClient() as client:
            data = client.get("/trading/profiles/")["data"]
    except NotAuthenticatedError:
        console.print("[red]Not authenticated.[/red] Run `talyxion auth login`.")
        raise SystemExit(1)
    except TokenRevokedError as exc:
        console.print(f"[red]{exc}[/red]")
        raise SystemExit(1)
    except Exception as exc:
        console.print(f"[red]Failed to fetch profiles:[/red] {exc}")
        raise SystemExit(1)

    if not data:
        console.print("[yellow]No local-execution profiles yet.[/yellow]")
        console.print("Create one at https://talyxion.com/trading/profiles/new/.")
        return

    table = Table(title="Trading profiles", show_lines=False)
    table.add_column("#", style="dim", width=4, justify="right")
    table.add_column("Name", style="bold")
    table.add_column("Exchange", style="cyan")
    table.add_column("Mode")
    table.add_column("Status")
    table.add_column("Leverage", justify="right", style="white")
    table.add_column("Cycle (s)", justify="right", style="dim")
    table.add_column("Alpha", style="dim")
    for p in data:
        mode_color = "yellow" if p.get("mode") == "live" else "blue"
        status = p.get("status", "?")
        status_color = {
            "active": "green",
            "paused": "yellow",
            "error": "red",
            "archived": "dim",
        }.get(status, "white")
        table.add_row(
            str(p.get("id", "?")),
            p.get("name", "—"),
            f'{p.get("exchange","?")} · {p.get("market_type","")}',
            f'[{mode_color}]{p.get("mode","?")}[/]',
            f'[{status_color}]{status}[/]',
            f'{p.get("order_leverage","?")}×',
            str(p.get("cycle_interval_sec", "?")),
            p.get("alpha_id", "—"),
        )
    console.print(table)
