"""``talyxion run | status | logs`` — daemon control + introspection."""
from __future__ import annotations

import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

import click
from rich.console import Console
from rich.table import Table

from talyxion.cli.logger import log_path
from talyxion.cli.runner import run_loop
from talyxion.cli.state import load_state, state_path

console = Console()


@click.command(name="run")
@click.option("--once", is_flag=True, help="Run one cycle per profile, then exit (for debugging).")
@click.option("--profile", "only_profile", type=int, default=None,
              help="Limit run to this profile id (skip the others).")
@click.option("--dry-run", is_flag=True,
              help="Don't submit orders — log what would be submitted.")
@click.option("--background", "-d", is_flag=True,
              help="Detach into background via nohup. PID stored in state dir.")
def run_cmd(once: bool, only_profile: int | None, dry_run: bool, background: bool) -> None:
    """Start the trading daemon.

    Plays the cycle loop for every local-execution profile owned by the
    authenticated user. Token revoked / profile archived → daemon exits
    cleanly.
    """
    if background:
        argv = [sys.argv[0]] + [a for a in sys.argv[1:] if a != "--background" and a != "-d"]
        pid_file = state_path().parent / "run.pid"
        log_file = log_path()
        with open(log_file, "ab") as out:
            proc = subprocess.Popen(
                argv,
                stdout=out, stderr=out, stdin=subprocess.DEVNULL,
                start_new_session=True,
            )
        pid_file.write_text(str(proc.pid))
        console.print(f"[green]✓ Started in background (pid={proc.pid}).[/green]")
        console.print(f"  Log: [dim]{log_file}[/dim]")
        console.print(f"  Stop: [bold]kill {proc.pid}[/bold]")
        return

    try:
        run_loop(once=once, only_profile=only_profile, dry_run=dry_run)
    except KeyboardInterrupt:
        console.print("\n[yellow]Stopped.[/yellow]")


@click.command(name="status")
def status_cmd() -> None:
    """Show local state: which profiles are tracked, last outcome, next due."""
    state = load_state()
    profiles = state.get("profiles", {})
    auth_meta = state.get("auth") or {}

    console.print(
        f"[bold]Auth:[/bold] {auth_meta.get('email','?')} "
        f"([cyan]{auth_meta.get('tier','?')}[/cyan]) · "
        f"token [cyan]{auth_meta.get('prefix','?')}[/cyan]"
    )

    pid_file = state_path().parent / "run.pid"
    if pid_file.exists():
        try:
            pid = int(pid_file.read_text().strip())
            os.kill(pid, 0)
            console.print(f"[green]Daemon running[/green] (pid={pid})")
        except (OSError, ValueError):
            console.print(f"[yellow]Stale PID file[/yellow] — daemon not running.")
    else:
        console.print("[dim]Daemon not running[/dim] (run `talyxion run`).")

    if not profiles:
        console.print("[dim]No profile state yet.[/dim]")
        return

    table = Table(title="Local profile state", show_lines=False)
    table.add_column("Profile", style="cyan")
    table.add_column("Peak equity", justify="right")
    table.add_column("Last cycle", justify="right")
    table.add_column("Outcome")
    table.add_column("Errors", justify="right")
    table.add_column("Next due", justify="right")
    for pid, ps in profiles.items():
        outcome = ps.get("last_outcome", "—")
        outcome_color = {
            "ok": "green", "auth_fail": "red", "ip_blocked": "red",
            "data_error": "yellow", "exec_error": "yellow", "conflict": "yellow",
        }.get(outcome, "white")
        last_cycle = ps.get("last_cycle_at", "")
        if last_cycle:
            try:
                last_cycle = datetime.fromisoformat(last_cycle).strftime("%H:%M:%S")
            except ValueError:
                pass
        next_due = ps.get("next_due_at", "")
        if next_due:
            try:
                d = datetime.fromisoformat(next_due)
                delta = int((d - datetime.now(timezone.utc)).total_seconds())
                next_due = f"in {delta}s" if delta > 0 else f"{-delta}s ago"
            except ValueError:
                pass
        table.add_row(
            f"#{pid}",
            f"${ps.get('peak_equity_usd', 0):.2f}",
            last_cycle or "—",
            f"[{outcome_color}]{outcome}[/]",
            str(ps.get("consecutive_errors", 0)),
            next_due or "—",
        )
    console.print(table)
    console.print(f"\n[dim]State file: {state_path()}[/dim]")
    console.print(f"[dim]Log file:   {log_path()}[/dim]")


@click.command(name="logs")
@click.option("-n", "--lines", default=50, help="How many tail lines to show (default 50).")
@click.option("-f", "--follow", is_flag=True, help="Follow the log (tail -f).")
def logs_cmd(lines: int, follow: bool) -> None:
    """Show the rolling CLI log."""
    p = log_path()
    if not p.exists():
        console.print(f"[dim]No log yet at {p}.[/dim]")
        return
    if follow:
        try:
            subprocess.run(["tail", "-n", str(lines), "-f", str(p)])
        except KeyboardInterrupt:
            pass
        return
    # Print last N lines.
    try:
        with p.open("rb") as f:
            f.seek(0, 2)
            size = f.tell()
            # Read tail chunk — heuristic
            f.seek(max(0, size - 64 * 1024))
            tail = f.read().decode("utf-8", errors="replace")
        for line in tail.splitlines()[-lines:]:
            console.print(line, highlight=False)
    except Exception as exc:
        console.print(f"[red]Failed to read log:[/red] {exc}")
