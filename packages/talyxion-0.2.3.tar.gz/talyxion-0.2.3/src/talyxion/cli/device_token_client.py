"""Thin HTTP client that attaches the device token to every request.

Used by the CLI for every API call against ``/api/v1/talyxion/...``.
Reads the base URL from ``TALYXION_BASE_URL`` env var (default
``https://talyxion.com``), reads the token from the OS keyring on
construction.

Raises:
  ``NotAuthenticatedError`` — no token in keyring (user hasn't run
    ``talyxion auth login`` yet).
  ``TokenRevokedError`` — server returned 401 ``key_expired`` /
    ``invalid_device_token``. CLI clears keyring and prompts re-login.
"""
from __future__ import annotations

import os
from typing import Any

import httpx

from talyxion.cli._version import __cli_version__
from talyxion.cli.keyring_store import (
    delete_device_token,
    load_device_token,
)

DEFAULT_BASE = "https://talyxion.com"


class NotAuthenticatedError(RuntimeError):
    pass


class TokenRevokedError(RuntimeError):
    pass


def base_url() -> str:
    return os.environ.get("TALYXION_BASE_URL", DEFAULT_BASE).rstrip("/")


def _api_prefix() -> str:
    """Talyxion API endpoints live under ``/api/v1/talyxion/`` (see vnweb/urls.py)."""
    return f"{base_url()}/api/v1/talyxion"


class DeviceTokenClient:
    """HTTP client bound to the user's device token.

    Use as a context manager so the underlying ``httpx.Client`` is closed
    cleanly even if a daemon loop crashes::

        with DeviceTokenClient() as cli:
            who = cli.get("/trading/whoami/")
    """

    def __init__(self, *, base: str | None = None, timeout: float = 30.0):
        token = load_device_token()
        if not token:
            raise NotAuthenticatedError(
                "No device token in keyring. Run `talyxion auth login` first."
            )
        self._token = token
        self._base = (base or _api_prefix()).rstrip("/")
        self._http = httpx.Client(
            base_url=self._base,
            timeout=timeout,
            headers={
                "Authorization": f"Bearer {token}",
                "X-App-Version": __cli_version__,
                # Browser-like UA envelope to avoid Cloudflare bot-fight WAF;
                # the talyxion-cli build identifier still goes in for our
                # own analytics. Server reads X-App-Version separately.
                "User-Agent": (
                    f"Mozilla/5.0 (compatible; talyxion-cli/{__cli_version__}; "
                    "+https://talyxion.com/platform/trading/setup/)"
                ),
                "Accept": "application/json",
            },
        )

    # ── lifecycle ────────────────────────────────────────────────
    def __enter__(self) -> DeviceTokenClient:
        return self

    def __exit__(self, *exc: Any) -> None:
        self.close()

    def close(self) -> None:
        self._http.close()

    # ── HTTP helpers ─────────────────────────────────────────────
    def _check_revoked(self, resp: httpx.Response) -> None:
        if resp.status_code == 401:
            try:
                body = resp.json()
            except Exception:
                body = {}
            err = body.get("error", "")
            if err in {"invalid_device_token", "key_expired", "authentication_required"}:
                delete_device_token()
                raise TokenRevokedError(
                    body.get("message")
                    or "Device token revoked. Run `talyxion auth login` to re-pair."
                )

    def get(self, path: str, **kwargs: Any) -> dict[str, Any]:
        resp = self._http.get(path, **kwargs)
        self._check_revoked(resp)
        resp.raise_for_status()
        return resp.json()

    def post(self, path: str, json: Any = None, **kwargs: Any) -> dict[str, Any]:
        resp = self._http.post(path, json=json, **kwargs)
        self._check_revoked(resp)
        resp.raise_for_status()
        if resp.status_code == 204:
            return {}
        return resp.json()

    def delete(self, path: str, **kwargs: Any) -> dict[str, Any]:
        resp = self._http.delete(path, **kwargs)
        self._check_revoked(resp)
        resp.raise_for_status()
        if resp.status_code == 204:
            return {}
        return resp.json()
