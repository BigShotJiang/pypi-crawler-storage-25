"""``talyxion`` — top-level CLI router.

Entry point declared in ``pyproject.toml`` as ``talyxion = "talyxion.cli.main:cli"``.
Running ``talyxion`` opens this group; subcommands live in sibling modules.
"""
from __future__ import annotations

import click

from talyxion.cli._version import __cli_version__
from talyxion.cli.auth import auth as auth_cmd
from talyxion.cli.credentials import add_cmd, list_creds_cmd, remove_cmd
from talyxion.cli.profiles import list_group
from talyxion.cli.run_cmd import logs_cmd, run_cmd, status_cmd
from talyxion.cli.update_cmd import update_cmd


@click.group(
    name="talyxion",
    help=(
        "Talyxion thin trader — your keys, your IP, our alphas.\n\n"
        "Quickstart:\n"
        "  1. talyxion auth login              (pair via OAuth device flow)\n"
        "  2. talyxion add binance --testnet   (register key, stored in OS keyring)\n"
        "  3. talyxion run                     (daemon: poll segments + execute)\n"
        "\nInspect:\n"
        "  talyxion status        — local runner state\n"
        "  talyxion logs -f       — tail the runner log\n"
        "  talyxion list profiles — server-side profile list\n"
        "  talyxion list creds    — server-side credentials"
    ),
)
@click.version_option(__cli_version__, "-V", "--version", prog_name="talyxion")
def cli() -> None:
    """Root command group."""


cli.add_command(auth_cmd, name="auth")
cli.add_command(add_cmd, name="add")
cli.add_command(remove_cmd, name="remove")
cli.add_command(run_cmd, name="run")
cli.add_command(status_cmd, name="status")
cli.add_command(logs_cmd, name="logs")
cli.add_command(update_cmd, name="update")
cli.add_command(list_group, name="list")
# Also expose ``talyxion list creds`` alongside ``talyxion list profiles``.
list_group.add_command(list_creds_cmd, name="creds")


if __name__ == "__main__":  # pragma: no cover
    cli()
