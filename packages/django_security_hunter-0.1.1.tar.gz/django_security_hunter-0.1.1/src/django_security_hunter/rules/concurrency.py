﻿from __future__ import annotations

from typing import Iterable

from django_security_hunter.models import Finding


def run_concurrency_rules() -> Iterable[Finding]:
    """DJG-7 placeholder. Returns findings when implemented."""
    return []


