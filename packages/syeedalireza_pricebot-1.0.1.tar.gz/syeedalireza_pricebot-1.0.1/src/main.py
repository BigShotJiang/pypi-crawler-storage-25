from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List
from src.domain.pricing_strategy import calculate_new_price

app = FastAPI(
    title="PriceBot API",
    description="Algorithmic Repricing Engine",
    version="1.0.0"
)

class CompetitorData(BaseModel):
    competitor_id: str
    price: float
    in_stock: bool

class RepriceRequest(BaseModel):
    product_id: str
    base_cost: float
    min_margin_percent: float
    competitors: List[CompetitorData]

@app.get("/health", tags=["System"])
async def health_check():
    return {"status": "healthy"}

@app.post("/api/v1/reprice", tags=["Pricing"])
async def reprice_product(request: RepriceRequest):
    """
    Calculate the optimal price based on competitor prices while respecting minimum margins.
    """
    try:
        new_price, strategy_used = calculate_new_price(
            base_cost=request.base_cost,
            min_margin=request.min_margin_percent,
            competitors=[c.model_dump() for c in request.competitors]
        )
        
        return {
            "product_id": request.product_id,
            "new_price": new_price,
            "strategy_used": strategy_used
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))