def calculate_new_price(base_cost: float, min_margin: float, competitors: list) -> tuple[float, str]:
    """
    Determines the new price.
    Rules:
    1. Never go below base_cost + min_margin.
    2. Undercut the lowest in-stock competitor by 1%.
    3. If no competitors have stock, maximize profit (e.g., base_cost + 50%).
    """
    min_allowed_price = base_cost * (1 + (min_margin / 100))
    
    in_stock_competitors = [c for c in competitors if c['in_stock']]
    
    if not in_stock_competitors:
        # Monopoly pricing
        return round(base_cost * 1.50, 2), "monopoly_pricing"
        
    lowest_competitor_price = min(c['price'] for c in in_stock_competitors)
    
    # Try to undercut by 1%
    target_price = lowest_competitor_price * 0.99
    
    if target_price < min_allowed_price:
        return round(min_allowed_price, 2), "min_margin_floor"
        
    return round(target_price, 2), "competitive_undercut"