import pytest
from httpx import AsyncClient, ASGITransport
from src.main import app
import pytest_asyncio

@pytest_asyncio.fixture
async def async_client():
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        yield client

@pytest.mark.asyncio
async def test_reprice_undercut(async_client):
    payload = {
        "product_id": "PROD-1",
        "base_cost": 100.0,
        "min_margin_percent": 10.0, # Min allowed price = 110.0
        "competitors": [
            {"competitor_id": "C1", "price": 150.0, "in_stock": True},
            {"competitor_id": "C2", "price": 140.0, "in_stock": True}
        ]
    }
    response = await async_client.post("/api/v1/reprice", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["new_price"] == 138.6 # 140 * 0.99
    assert data["strategy_used"] == "competitive_undercut"

@pytest.mark.asyncio
async def test_reprice_floor(async_client):
    payload = {
        "product_id": "PROD-2",
        "base_cost": 100.0,
        "min_margin_percent": 10.0, # Min allowed price = 110.0
        "competitors": [
            {"competitor_id": "C1", "price": 105.0, "in_stock": True} # Too low to undercut
        ]
    }
    response = await async_client.post("/api/v1/reprice", json=payload)
    assert response.status_code == 200
    assert response.json()["new_price"] == 110.0
    assert response.json()["strategy_used"] == "min_margin_floor"