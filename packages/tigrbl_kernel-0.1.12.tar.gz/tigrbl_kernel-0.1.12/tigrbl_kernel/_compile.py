from __future__ import annotations

from dataclasses import replace
from typing import Any, Mapping

from tigrbl_atoms import StepFn
from tigrbl_core.config.constants import __JSONRPC_DEFAULT_ENDPOINT__

from . import events as _ev
from .models import KernelPlan, OpKey, OpMeta, OpView
from .opview_compiler import compile_opview_from_specs
from .types import DEFAULT_PHASE_ORDER as _DEFAULT_PHASE_ORDER
from .utils import (
    _canonicalize_app,
    _compile_path_pattern,
    _opspecs,
    _phase_info_map,
    _route_payload_template,
    _table_iter,
    deepmerge_phase_chains,
)


DEFAULT_PHASE_ORDER = tuple(getattr(_ev, "PHASES", ())) or _DEFAULT_PHASE_ORDER


def _compile_opview_from_specs(self: Any, specs: Mapping[str, Any], sp: Any) -> OpView:
    return compile_opview_from_specs(specs, sp)


def _compile_plan(self: Any, app: Any) -> KernelPlan:
    app = _canonicalize_app(app)

    from tigrbl_core._spec.binding_spec import (
        HttpJsonRpcBindingSpec,
        HttpRestBindingSpec,
        HttpStreamBindingSpec,
        SseBindingSpec,
        WebTransportBindingSpec,
        WsBindingSpec,
    )

    route_data: dict[str, Any] = _route_payload_template()
    opmeta: list[OpMeta] = []
    opkey_to_meta: dict[OpKey, int] = {}
    phase_chains: dict[int, Mapping[str, list[StepFn]]] = {}
    opviews: list[OpView | None] = []
    rest_exact_route_to_program: dict[tuple[str, str], int] = {}
    ingress_chain = self._build_ingress(app)
    egress_chain = self._build_egress(app)
    phases, mainline_phases, error_phases = _phase_info_map(DEFAULT_PHASE_ORDER)

    for model in _table_iter(app):
        for sp in _opspecs(model):
            meta_index = len(opmeta)
            target = (getattr(sp, "target", sp.alias) or sp.alias).lower()
            opmeta.append(OpMeta(model=model, alias=sp.alias, target=target))
            try:
                opviews.append(
                    self._compile_opview_from_specs(self.get_specs(model), sp)
                )
            except Exception:
                opviews.append(None)
            phase_chains[meta_index] = deepmerge_phase_chains(
                ingress_chain,
                self._build_op(model, sp.alias),
                egress_chain,
            )

            for binding in getattr(sp, "bindings", ()) or ():
                if isinstance(
                    binding,
                    (HttpRestBindingSpec, HttpStreamBindingSpec, SseBindingSpec),
                ):
                    bucket = route_data.setdefault(
                        binding.proto, {"exact": {}, "templated": []}
                    )
                    for method in binding.methods:
                        selector = f"{method.upper()} {binding.path}"
                        opkey_to_meta[OpKey(proto=binding.proto, selector=selector)] = (
                            meta_index
                        )
                        if "{" in binding.path and "}" in binding.path:
                            pattern, names = _compile_path_pattern(binding.path)
                            bucket["templated"].append(
                                {
                                    "method": method.upper(),
                                    "path": binding.path,
                                    "pattern": pattern,
                                    "names": names,
                                    "meta_index": meta_index,
                                    "selector": selector,
                                }
                            )
                        else:
                            bucket["exact"][selector] = meta_index
                            method, _, path = selector.partition(" ")
                            if path:
                                rest_exact_route_to_program[(method.upper(), path)] = (
                                    meta_index
                                )

                elif isinstance(binding, HttpJsonRpcBindingSpec):
                    endpoint = str(
                        getattr(binding, "endpoint", __JSONRPC_DEFAULT_ENDPOINT__)
                        or __JSONRPC_DEFAULT_ENDPOINT__
                    )
                    selector = f"{endpoint}:{binding.rpc_method}"
                    opkey_to_meta[OpKey(proto=binding.proto, selector=selector)] = (
                        meta_index
                    )
                    proto_bucket = route_data.setdefault(
                        binding.proto, {"endpoints": {}}
                    )
                    endpoint_bucket = proto_bucket.setdefault("endpoints", {}).setdefault(
                        endpoint, {}
                    )
                    proto_bucket[binding.rpc_method] = meta_index
                    endpoint_bucket[binding.rpc_method] = {
                        "meta_index": meta_index,
                        "selector": selector,
                        "rpc_method": binding.rpc_method,
                        "endpoint": endpoint,
                    }

                elif isinstance(binding, (WsBindingSpec, WebTransportBindingSpec)):
                    bucket = route_data.setdefault(
                        binding.proto, {"exact": {}, "templated": []}
                    )
                    selector = binding.path
                    opkey_to_meta[OpKey(proto=binding.proto, selector=selector)] = (
                        meta_index
                    )

                    if "{" in binding.path and "}" in binding.path:
                        pattern, names = _compile_path_pattern(binding.path)
                        bucket["templated"].append(
                            {
                                "path": binding.path,
                                "pattern": pattern,
                                "names": names,
                                "meta_index": meta_index,
                                "selector": selector,
                                "subprotocols": tuple(
                                    getattr(binding, "subprotocols", ()) or ()
                                ),
                            }
                        )
                    else:
                        bucket["exact"][selector] = meta_index

    semantic = KernelPlan(
        proto_indices=route_data,
        opmeta=tuple(opmeta),
        opkey_to_meta=opkey_to_meta,
        ingress_chain=ingress_chain,
        phase_chains=phase_chains,
        egress_chain=egress_chain,
        phases=phases,
        mainline_phases=mainline_phases,
        error_phases=error_phases,
    )
    try:
        packed = self._pack_kernel_plan(
            semantic,
            opviews=tuple(opviews),
            rest_exact_route_to_program=rest_exact_route_to_program,
        )
    except TypeError:
        packed = self._pack_kernel_plan(semantic)

    phase_trees = {}
    has_phase_tree_metadata = all(
        hasattr(packed, attr)
        for attr in (
            "program_phase_tree_offsets",
            "program_phase_tree_lengths",
            "phase_tree_nodes",
        )
    )
    if packed is not None and has_phase_tree_metadata:
        for program_id in range(len(opmeta)):
            offset = (
                packed.program_phase_tree_offsets[program_id]
                if program_id < len(packed.program_phase_tree_offsets)
                else 0
            )
            length = (
                packed.program_phase_tree_lengths[program_id]
                if program_id < len(packed.program_phase_tree_lengths)
                else 0
            )
            phase_trees[program_id] = tuple(
                packed.phase_tree_nodes[offset : offset + length]
            )
    return replace(semantic, packed=packed, phase_trees=phase_trees)
