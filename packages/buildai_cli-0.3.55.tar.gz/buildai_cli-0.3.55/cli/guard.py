"""Write-guard helpers for CLI commands."""

from __future__ import annotations

import typer

from cli.console import error


def require_write(
    ctx: typer.Context,
    action: str,
    *,
    allowed_profiles: frozenset[str] | None = None,
) -> None:
    """
    Enforce --write for mutating commands.

    Args:
        ctx: Typer context
        action: Short description of the mutation (for error messages)
        allowed_profiles: CLI profiles allowed to perform the mutation
    """
    ctx_obj = ctx.obj or {}
    allow_write = ctx_obj.get("allow_write", False)
    if not allow_write:
        error(f"{action} is a write operation. Re-run with --write.")
        raise typer.Exit(1)
    cli_profile = ctx_obj.get("cli_profile") or "internal_viewer"
    required_profiles = allowed_profiles or frozenset({"internal_admin"})
    if cli_profile not in required_profiles:
        profile_list = ", ".join(sorted(required_profiles))
        error(f"{action} requires one of these profiles: {profile_list}.")
        raise typer.Exit(1)
