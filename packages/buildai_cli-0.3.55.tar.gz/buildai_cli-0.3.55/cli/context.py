"""CLI context management for direct DB inspection and scoped DAL access.

This module exposes two intentionally different database access modes:

- ``get_inspection_connection()`` for direct operator/developer inspection.
  This uses the selected DB principal plus one explicit internal inspection
  session contract so RLS-backed tables stay visible without pretending to be
  a tenant request.
- ``get_cli_context()`` for DAL-driven commands that do want the CLI-owned
  scoped session contract.

Usage:
    # Direct DB inspection
    async with get_inspection_connection(settings) as conn:
        result = await conn.fetch("SELECT 1")

    # With canonical DAL context (for commands that use dal functions)
    async with get_cli_context(settings) as (db, ctx):
        datasets = await dal.external.datasets.list_datasets(ctx)
"""

import os
from contextlib import asynccontextmanager
from dataclasses import dataclass
from typing import TYPE_CHECKING, AsyncGenerator

import asyncpg
from dal import scopes as dal_scopes
from infra.settings import Settings, get_settings

from cli.auth_local import resolve_sanctioned_profile
from cli.db_broker import (
    BrokerConfig,
    BrokeredDatabase,
    broker_config_for_identity,
    connect_via_broker,
    open_brokered_database,
)
from infra import get_logger

if TYPE_CHECKING:
    from dal.context import Context

logger = get_logger(__name__)

# Environment variable to force local PostgreSQL (for test/CI)
USE_LOCAL_DB = os.getenv("USE_LOCAL_DB", "false").lower() == "true"
_ZERO_UUID = "00000000-0000-0000-0000-000000000000"
_EMPTY_SCOPE_IDS = "{}"
_SCOPE_GUCS = (
    "app.allowed_organization_ids",
    "app.allowed_site_ids",
    "app.allowed_source_ids",
    "app.allowed_dataset_ids",
)
_READ_SUFFIXES = (".read", ".search", ".query", ".introspection")
_READ_PROFILE_SCOPES = frozenset(
    scope
    for scope in dal_scopes.ALL_SCOPES
    if any(scope.endswith(suffix) for suffix in _READ_SUFFIXES)
)
_CLI_PROFILE_SCOPES: dict[str, frozenset[str]] = {
    "internal_admin": frozenset(dal_scopes.ALL_SCOPES),
    "internal_viewer": _READ_PROFILE_SCOPES,
    "engineers-dev": _READ_PROFILE_SCOPES,
    "developer": frozenset(dal_scopes.ALL_SCOPES),
    "operator": frozenset(dal_scopes.ALL_SCOPES),
    "ml_engineer": frozenset(dal_scopes.ALL_SCOPES),
    "mcp": _READ_PROFILE_SCOPES,
    "agent": frozenset(dal_scopes.ALL_SCOPES),
}
_UNRESTRICTED_CLI_PROFILES = frozenset(
    {
        "internal_admin",
        "internal_viewer",
        "developer",
        "operator",
        "ml_engineer",
        "mcp",
        "agent",
    }
)
DB_IDENTITY_PROFILE_ALIASES: dict[str, str] = {
    "internal_admin": "db-admin-local",
}
_ADMIN_DB_IDENTITY_PROFILES = frozenset({"internal_admin", "db-admin-local"})


def scopes_for_cli_profile(profile: str) -> frozenset[str]:
    """Resolve one sanctioned CLI profile to its DAL scope set."""
    resolved = _CLI_PROFILE_SCOPES.get(profile)
    if resolved is None:
        raise ValueError(f"Unknown CLI profile: {profile}")
    return resolved


def db_identity_profile_for_cli_profile(profile: str) -> str:
    """Return the DB identity profile backing one CLI-facing profile."""

    return DB_IDENTITY_PROFILE_ALIASES.get(profile, profile)


@dataclass(frozen=True)
class AdminConnectionConfig:
    """Describe the canonical admin connection the ops-plane CLI should prefer.

    This keeps DB-direct read paths deterministic when a deployment profile
    defines a dedicated admin principal instead of relying on the caller's
    personal IAM DB mapping.
    """

    user: str
    use_iam_auth: bool
    impersonate_sa: str | None = None
    password: str = ""


async def _stamp_base_cli_session_contract(
    conn: asyncpg.Connection,
    *,
    unrestricted: bool,
) -> None:
    """Stamp the common CLI session GUCs and clear all known resource scopes."""
    await conn.execute("SELECT set_config('app.principal_id', $1, false)", _ZERO_UUID)
    await conn.execute(
        "SELECT set_config('app.unrestricted', $1, false)",
        "true" if unrestricted else "false",
    )
    for setting_name in _SCOPE_GUCS:
        await conn.execute(
            f"SELECT set_config('{setting_name}', $1, false)",
            _EMPTY_SCOPE_IDS,
        )


async def _stamp_internal_inspection_session_contract(conn: asyncpg.Connection) -> None:
    """Stamp the explicit unrestricted contract for direct CLI inspection work.

    ``buildai db ...`` commands are internal inspection tools, not request-parity
    emulators. The DB principal still caps what the caller can mutate, while the
    unrestricted flag ensures RLS-backed tables answer truthfully for reads.
    """
    await _stamp_base_cli_session_contract(conn, unrestricted=True)


async def _stamp_scoped_cli_session_contract(
    conn: asyncpg.Connection,
    *,
    profile: str,
) -> None:
    """Stamp the CLI-owned scoped session contract for DAL-oriented commands."""
    await _stamp_base_cli_session_contract(
        conn,
        unrestricted=profile in _UNRESTRICTED_CLI_PROFILES,
    )


def resolve_admin_connection_config(
    settings: Settings,
) -> AdminConnectionConfig | None:
    """Resolve the canonical admin DB login for this environment, if one exists.

    Resolution order is explicit env overrides first, then the production
    password fallback already used by privileged database commands.
    """
    admin_iam_user = settings.effective_alloydb_admin_iam_user
    admin_impersonate_sa = settings.effective_alloydb_admin_impersonate_sa

    if admin_iam_user and admin_impersonate_sa:
        return AdminConnectionConfig(
            user=admin_iam_user,
            use_iam_auth=True,
            impersonate_sa=admin_impersonate_sa,
        )

    admin_password = os.getenv("ALLOYDB_PSW_PROD", "")
    if admin_password:
        return AdminConnectionConfig(
            user="postgres",
            use_iam_auth=False,
            password=admin_password,
        )

    return None


def _fixed_profile_connection_config(
    settings: Settings,
    *,
    profile: str,
) -> AdminConnectionConfig | None:
    """Resolve a sanctioned local auth profile into a DB login contract."""

    try:
        resolved = resolve_sanctioned_profile(
            profile,
            environment=settings.app_env.value,
        )
    except ValueError:
        return None

    if not resolved.db_access or not resolved.target_db_user or not resolved.target_service_account:
        return None

    return AdminConnectionConfig(
        user=resolved.target_db_user,
        use_iam_auth=True,
        impersonate_sa=resolved.target_service_account,
    )


def resolve_broker_config(
    settings: Settings,
    *,
    profile: str | None = None,
) -> BrokerConfig:
    """Resolve the CLI profile and settings into one local DB broker identity."""

    from cli.config import resolve_cli_profile

    resolved_profile = resolve_cli_profile(profile)
    db_identity_profile = db_identity_profile_for_cli_profile(resolved_profile)
    config = _fixed_profile_connection_config(settings, profile=db_identity_profile)

    if config is None and resolved_profile in _ADMIN_DB_IDENTITY_PROFILES:
        config = resolve_admin_connection_config(settings)

    if config is None:
        if resolved_profile in _ADMIN_DB_IDENTITY_PROFILES:
            raise RuntimeError(
                f"Profile '{resolved_profile}' requires admin DB credentials. "
                "Set ALLOYDB_ADMIN_IAM_USER_* / ALLOYDB_ADMIN_IMPERSONATE_SA_* "
                "or use the sanctioned db-admin-local profile."
            )
        config = AdminConnectionConfig(
            user=settings.effective_db_user,
            use_iam_auth=settings.effective_use_iam_auth,
            impersonate_sa=settings.effective_alloydb_runtime_impersonate_sa or None,
            password=settings.effective_alloydb_password,
        )

    return broker_config_for_identity(
        settings,
        profile=resolved_profile,
        db_user=config.user,
        use_iam_auth=config.use_iam_auth,
        target_service_account=config.impersonate_sa,
        password=config.password,
    )


async def open_admin_database(settings: Settings) -> BrokeredDatabase:
    """Open the canonical admin DB connection for privileged ops-plane access.

    Commands that need deterministic production introspection should use this
    instead of inheriting the caller's personal IAM DB login.
    """
    settings.validate_environment_access()

    if settings.is_test:
        raise RuntimeError("Admin AlloyDB connection is not available in test mode.")

    if not settings.alloydb_instance_uri:
        raise RuntimeError("AlloyDB instance URI is not configured for this environment.")

    config = resolve_admin_connection_config(settings) or _fixed_profile_connection_config(
        settings,
        profile="db-admin-local",
    )
    if config is None:
        raise RuntimeError(
            "Admin credentials not configured for this environment. "
            "Set ALLOYDB_ADMIN_IAM_USER_* / ALLOYDB_ADMIN_IMPERSONATE_SA_* "
            "or use the sanctioned db-admin-local profile."
        )

    broker_config = broker_config_for_identity(
        settings,
        profile="db-admin-local",
        db_user=config.user,
        use_iam_auth=config.use_iam_auth,
        target_service_account=config.impersonate_sa,
        password=config.password,
    )
    return await open_brokered_database(broker_config)


@asynccontextmanager
async def get_inspection_connection(
    settings: Settings | None = None,
) -> AsyncGenerator[asyncpg.Connection, None]:
    """
    Get a direct DB inspection connection for CLI commands.

    This path is for ``buildai db query/status/schema`` style inspection. It
    does not emulate request-scoped visibility. Instead it stamps the single
    explicit internal inspection contract so RLS-backed tables remain visible
    under the chosen DB principal.

    Args:
        settings: Optional Settings instance. Uses cached settings if not provided.

    Yields:
        asyncpg.Connection for executing queries

    Usage:
        async with get_inspection_connection(settings) as conn:
            result = await conn.fetch("SELECT 1")
    """
    if settings is None:
        settings = get_settings()

    if USE_LOCAL_DB or settings.is_test:
        # Test/CI: use local PostgreSQL
        async with _local_connection(settings) as conn:
            await _stamp_internal_inspection_session_contract(conn)
            yield conn
    else:
        config = resolve_broker_config(settings)
        conn = await connect_via_broker(config)
        try:
            await _stamp_internal_inspection_session_contract(conn)
            yield conn
        finally:
            await conn.close()


@asynccontextmanager
async def get_admin_connection(
    settings: Settings | None = None,
) -> AsyncGenerator[asyncpg.Connection, None]:
    """Get a connection using the canonical admin DB identity for this lane.

    This is intended for read-only ops-plane introspection where the checked-in
    deployment profile should decide the DB principal instead of the caller's
    personal IAM mapping.
    """
    if settings is None:
        settings = get_settings()

    db = await open_admin_database(settings)
    try:
        await _stamp_internal_inspection_session_contract(db.conn)
        yield db.conn
    finally:
        await db.close()


@asynccontextmanager
async def _local_connection(
    settings: Settings,
) -> AsyncGenerator[asyncpg.Connection, None]:
    """
    Connect to local PostgreSQL (for test/CI environments).

    Uses environment variables for connection parameters:
    - DB_HOST (default: localhost)
    - DB_PORT (default: 5432)
    - DB_USER (falls back to settings.db_user)
    - DB_PASSWORD (falls back to "postgres")
    - DB_NAME (falls back to settings.db_name)
    """
    conn = await asyncpg.connect(
        host=os.getenv("DB_HOST", "localhost"),
        port=int(os.getenv("DB_PORT", "5432")),
        user=os.getenv("DB_USER") or settings.effective_db_user,
        password=os.getenv("DB_PASSWORD") or settings.effective_alloydb_password or "postgres",
        database=os.getenv("DB_NAME", settings.db_name),  # Respect DB_NAME env var for CI
        statement_cache_size=0,
    )
    try:
        yield conn
    finally:
        await conn.close()


@asynccontextmanager
async def get_cli_context(
    settings: Settings | None = None,
    *,
    profile: str | None = None,
) -> AsyncGenerator[tuple[BrokeredDatabase | None, "Context"], None]:
    """
    Get a database connection and canonical DAL context for CLI commands.

    This is for commands that want to use canonical DAL functions instead of raw SQL.
    The context is scoped by CLI profile (default: internal_viewer).

    Args:
        settings: Optional Settings instance. Uses cached settings if not provided.

    Yields:
        Tuple of (Database instance or None, Context for DAL operations)
        - For test/CI: Database is None, Context wraps the raw connection
        - For dev/prod: Database is a brokered Database-like wrapper

    Usage:
        async with get_cli_context(settings) as (db, ctx):
            datasets = await dal.external.datasets.list_datasets(ctx)
    """
    from dal.context import Context

    from cli.config import resolve_cli_profile

    if settings is None:
        settings = get_settings()
    resolved_profile = resolve_cli_profile(profile)

    if USE_LOCAL_DB or settings.is_test:
        # Test/CI: wrap local connection in context
        async with _local_connection(settings) as conn:
            await _stamp_scoped_cli_session_contract(conn, profile=resolved_profile)
            ctx = Context.for_cli(conn, scopes=scopes_for_cli_profile(resolved_profile))
            yield None, ctx
    else:
        broker_config = resolve_broker_config(settings, profile=resolved_profile)
        db = await open_brokered_database(broker_config)
        try:
            await _stamp_scoped_cli_session_contract(db.conn, profile=resolved_profile)
            ctx = Context.for_cli(db, scopes=scopes_for_cli_profile(resolved_profile))
            yield db, ctx
        finally:
            await db.close()
