"""Profile-keyed local AlloyDB broker for CLI database operations."""

from __future__ import annotations

import fcntl
import hashlib
import json
import os
import re
import shlex
import shutil
import socket
import subprocess
import time
from contextlib import contextmanager
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Iterator

import asyncpg
from infra.settings import Settings

REPO_ROOT = Path(__file__).resolve().parents[3]
LEGACY_STATE_DIR = REPO_ROOT / ".buildai" / "db-brokers"
STATE_DIR = Path(os.getenv("BUILDAI_DB_BROKER_STATE_DIR", Path.home() / ".buildai" / "db-brokers"))
_PROFILE_PORT_OFFSETS = {
    "engineers-dev": 0,
    "internal_viewer": 1,
    "internal_admin": 21,
    "migrations-local": 10,
    "db-admin-local": 20,
}


@dataclass(frozen=True)
class BrokerConfig:
    """Complete identity and endpoint contract for one local DB broker."""

    environment: str
    profile: str
    instance_uri: str
    database: str
    db_user: str
    use_iam_auth: bool
    target_service_account: str | None
    host: str
    port: int
    use_private_ip: bool
    password: str = ""

    @property
    def identity(self) -> str:
        """Return the stable identity hash for state files and diagnostics."""

        payload = {
            "environment": self.environment,
            "profile": self.profile,
            "instance_uri": self.instance_uri,
            "database": self.database,
            "db_user": self.db_user,
            "use_iam_auth": self.use_iam_auth,
            "target_service_account": self.target_service_account,
            "host": self.host,
            "port": self.port,
            "use_private_ip": self.use_private_ip,
        }
        raw = json.dumps(payload, sort_keys=True, separators=(",", ":"))
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:16]

    @property
    def state_path(self) -> Path:
        """Return the broker state file path for this identity."""

        return STATE_DIR / f"{self.identity}.json"

    @property
    def log_path(self) -> Path:
        """Return the broker log path for this identity."""

        return STATE_DIR / f"{self.identity}.log"


@dataclass(frozen=True)
class BrokerState:
    """Persist the child process and identity that own one broker listener."""

    pid: int
    config: dict[str, Any]
    command: list[str]
    log_path: str


@dataclass(frozen=True)
class ListenerProcess:
    """Describe one local process already bound to a broker TCP endpoint."""

    pid: int
    command: list[str]


@dataclass
class BrokeredDatabase:
    """Expose the small Database-like surface migration commands require."""

    config: BrokerConfig
    conn: asyncpg.Connection

    async def fetch(self, query: str, *args: Any, timeout: float | None = None) -> list[Any]:
        """Run ``fetch`` through the brokered connection."""

        result = await self.conn.fetch(query, *args, timeout=timeout)
        return list(result)

    async def fetchrow(self, query: str, *args: Any, timeout: float | None = None) -> Any | None:
        """Run ``fetchrow`` through the brokered connection."""

        return await self.conn.fetchrow(query, *args, timeout=timeout)

    async def fetchval(self, query: str, *args: Any, timeout: float | None = None) -> Any:
        """Run ``fetchval`` through the brokered connection."""

        return await self.conn.fetchval(query, *args, timeout=timeout)

    async def execute(self, query: str, *args: Any, timeout: float | None = None) -> str:
        """Run ``execute`` through the brokered connection."""

        return str(await self.conn.execute(query, *args, timeout=timeout))

    async def executemany(
        self,
        query: str,
        args: list[tuple[Any, ...]],
        timeout: float | None = None,
    ) -> None:
        """Run ``executemany`` through the brokered connection."""

        await self.conn.executemany(query, args, timeout=timeout)

    def transaction(self) -> Any:
        """Return the asyncpg transaction context for this connection."""

        return self.conn.transaction()

    async def close(self) -> None:
        """Close the underlying local asyncpg connection."""

        await self.conn.close()


async def _init_broker_connection(conn: asyncpg.Connection) -> None:
    """Register codecs expected by DAL code using brokered CLI connections."""

    await conn.set_type_codec(
        "jsonb",
        encoder=json.dumps,
        decoder=json.loads,
        schema="pg_catalog",
    )
    await conn.set_type_codec(
        "json",
        encoder=json.dumps,
        decoder=json.loads,
        schema="pg_catalog",
    )


def default_proxy_binary() -> str | None:
    """Return the preferred AlloyDB Auth Proxy binary path if available."""

    on_path = shutil.which("alloydb-auth-proxy")
    if on_path:
        return on_path
    local_bin = Path.home() / ".local" / "bin" / "alloydb-auth-proxy"
    if local_bin.is_file():
        return str(local_bin)
    return None


def proxy_is_listening(*, host: str, port: int) -> bool:
    """Return True when a TCP listener is present at the local broker endpoint."""

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.settimeout(0.25)
        return sock.connect_ex((host, port)) == 0


def process_is_running(pid: int) -> bool:
    """Return whether the broker PID still exists."""

    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    return True


@contextmanager
def _broker_lock(config: BrokerConfig) -> Iterator[None]:
    """Serialize local broker startup for one profile identity on this machine."""

    STATE_DIR.mkdir(parents=True, exist_ok=True)
    lock_path = STATE_DIR / f"{config.identity}.lock"
    with lock_path.open("w", encoding="utf-8") as handle:
        fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
        try:
            yield
        finally:
            fcntl.flock(handle.fileno(), fcntl.LOCK_UN)


def _state_paths(config: BrokerConfig) -> tuple[Path, ...]:
    """Return current and legacy broker state paths for one identity."""

    paths = [config.state_path]
    legacy_path = LEGACY_STATE_DIR / f"{config.identity}.json"
    if legacy_path != config.state_path:
        paths.append(legacy_path)
    return tuple(paths)


def _read_broker_state_file(path: Path) -> BrokerState | None:
    """Read one broker state file without trusting malformed stale content."""

    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return BrokerState(
            pid=int(data["pid"]),
            config=dict(data["config"]),
            command=list(data["command"]),
            log_path=str(data["log_path"]),
        )
    except Exception:
        return None


def _unlink_state(config: BrokerConfig) -> None:
    """Remove current and legacy state files for a stale broker identity."""

    for path in _state_paths(config):
        try:
            path.unlink()
        except FileNotFoundError:
            pass


def _state_payload(config: BrokerConfig, *, pid: int, command: list[str]) -> BrokerState:
    """Build a serializable broker state object."""

    return BrokerState(
        pid=pid,
        config=asdict(config),
        command=command,
        log_path=str(config.log_path),
    )


def read_broker_state(config: BrokerConfig) -> BrokerState | None:
    """Read the state file for a broker identity when present and valid."""

    for path in _state_paths(config):
        state = _read_broker_state_file(path)
        if state is not None:
            return state
    return None


def _write_broker_state(config: BrokerConfig, state: BrokerState) -> None:
    """Atomically write the broker state file."""

    STATE_DIR.mkdir(parents=True, exist_ok=True)
    tmp_path = config.state_path.with_suffix(".tmp")
    tmp_path.write_text(
        json.dumps(asdict(state), indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    os.replace(tmp_path, config.state_path)


def _process_command(pid: int) -> list[str]:
    """Return argv-like command text for a local PID when the OS exposes it."""

    try:
        completed = subprocess.run(
            ["ps", "-p", str(pid), "-o", "command="],
            capture_output=True,
            text=True,
            timeout=2,
            check=False,
        )
    except Exception:
        return []
    if completed.returncode != 0:
        return []
    raw = completed.stdout.strip()
    if not raw:
        return []
    try:
        return shlex.split(raw)
    except ValueError:
        return raw.split()


def _listening_pids(*, host: str, port: int) -> list[int]:
    """Return local PIDs listening on a TCP port when OS tools expose them."""

    if shutil.which("lsof") is not None:
        try:
            completed = subprocess.run(
                ["lsof", "-nP", f"-iTCP:{port}", "-sTCP:LISTEN", "-t"],
                capture_output=True,
                text=True,
                timeout=2,
                check=False,
            )
        except Exception:
            completed = None
        if completed is not None and completed.returncode == 0:
            pids: list[int] = []
            for line in completed.stdout.splitlines():
                try:
                    pids.append(int(line.strip()))
                except ValueError:
                    continue
            if pids:
                return pids

    if shutil.which("ss") is not None:
        try:
            completed = subprocess.run(
                ["ss", "-H", "-ltnp", f"sport = :{port}"],
                capture_output=True,
                text=True,
                timeout=2,
                check=False,
            )
        except Exception:
            completed = None
        if completed is not None and completed.returncode == 0:
            candidates: list[int] = []
            for line in completed.stdout.splitlines():
                if f":{port}" not in line:
                    continue
                candidates.extend(int(pid) for pid in re.findall(r"pid=(\d+)", line))
            if candidates:
                return candidates

    del host
    return []


def _listener_processes(*, host: str, port: int) -> list[ListenerProcess]:
    """Return process metadata for listeners on the broker endpoint."""

    return [
        ListenerProcess(pid=pid, command=_process_command(pid))
        for pid in _listening_pids(host=host, port=port)
    ]


def _flag_value(command: list[str], flag: str) -> str | None:
    """Return the value passed to a command-line flag in split or equals form."""

    for index, value in enumerate(command):
        if value == flag and index + 1 < len(command):
            return command[index + 1]
        prefix = f"{flag}="
        if value.startswith(prefix):
            return value[len(prefix) :]
    return None


def _is_matching_proxy_process(process: ListenerProcess, config: BrokerConfig) -> bool:
    """Return True when a listener command is the broker this profile needs."""

    command = process.command
    if not command:
        return False
    if Path(command[0]).name != "alloydb-auth-proxy":
        return False
    if config.instance_uri not in command:
        return False
    if _flag_value(command, "--address") != config.host:
        return False
    if _flag_value(command, "--port") != str(config.port):
        return False
    if ("--auto-iam-authn" in command) != config.use_iam_auth:
        return False
    impersonate = _flag_value(command, "--impersonate-service-account")
    if impersonate != config.target_service_account:
        return False
    if not config.use_private_ip and "--public-ip" not in command:
        return False
    if config.use_private_ip and "--public-ip" in command:
        return False
    return True


def _adopt_matching_listener(config: BrokerConfig) -> BrokerState | None:
    """Persist state for an already-running broker from another worktree."""

    for process in _listener_processes(host=config.host, port=config.port):
        if _is_matching_proxy_process(process, config):
            state = _state_payload(config, pid=process.pid, command=process.command)
            _write_broker_state(config, state)
            return state
    return None


def _broker_command(config: BrokerConfig, *, proxy_binary: str) -> list[str]:
    """Build the AlloyDB Auth Proxy command for one broker config."""

    command = [
        proxy_binary,
        config.instance_uri,
        "--address",
        config.host,
        "--port",
        str(config.port),
        "--disable-built-in-telemetry",
        "--quiet",
    ]
    if config.use_iam_auth:
        command.append("--auto-iam-authn")
    if config.target_service_account:
        command.append(f"--impersonate-service-account={config.target_service_account}")
    if not config.use_private_ip:
        command.append("--public-ip")
    return command


def ensure_broker(config: BrokerConfig) -> BrokerState:
    """Start or reuse the profile-keyed local AlloyDB broker."""

    with _broker_lock(config):
        state = read_broker_state(config)
        if state:
            alive = process_is_running(state.pid)
            listening = proxy_is_listening(host=config.host, port=config.port)
            if alive and listening:
                _write_broker_state(config, state)
                return state
            if alive:
                raise RuntimeError(
                    f"Broker process {state.pid} for {config.profile} exists, but "
                    f"{config.host}:{config.port} is not accepting connections. "
                    f"Inspect {state.log_path} or run `buildai db broker stop`."
                )
            _unlink_state(config)

        adopted = _adopt_matching_listener(config)
        if adopted is not None:
            return adopted

        if proxy_is_listening(host=config.host, port=config.port):
            raise RuntimeError(
                f"{config.host}:{config.port} is already listening, but not for the expected "
                f"{config.profile} broker identity. Stop that process or choose another broker port."
            )

        proxy_binary = default_proxy_binary()
        if proxy_binary is None:
            raise RuntimeError(
                "alloydb-auth-proxy is not installed. Install it before using brokered DB access."
            )
        if not config.instance_uri:
            raise RuntimeError("AlloyDB instance URI is not configured for this environment.")

        command = _broker_command(config, proxy_binary=proxy_binary)
        with config.log_path.open("ab") as log_file:
            process = subprocess.Popen(
                command,
                stdout=log_file,
                stderr=log_file,
                start_new_session=True,
                env=os.environ.copy(),
            )

        deadline = time.monotonic() + 15.0
        while time.monotonic() < deadline:
            if process.poll() is not None:
                adopted = _adopt_matching_listener(config)
                if adopted is not None:
                    return adopted
                break
            if proxy_is_listening(host=config.host, port=config.port):
                state = _state_payload(config, pid=process.pid, command=command)
                _write_broker_state(config, state)
                return state
            time.sleep(0.25)

        if process.poll() is not None:
            raise RuntimeError(
                f"AlloyDB broker process exited with code {process.returncode}. "
                f"Broker log: {config.log_path}"
            )

        raise RuntimeError(
            f"Timed out waiting for AlloyDB broker on {config.host}:{config.port}. "
            f"Broker log: {config.log_path}"
        )


def stop_broker(config: BrokerConfig) -> bool:
    """Stop the machine-local broker for one identity."""

    with _broker_lock(config):
        state = read_broker_state(config) or _adopt_matching_listener(config)
        if state is None:
            return False

        def stopped() -> bool:
            return not process_is_running(state.pid) and not proxy_is_listening(
                host=config.host,
                port=config.port,
            )

        if process_is_running(state.pid):
            os.kill(state.pid, 15)
            deadline = time.monotonic() + 5.0
            while time.monotonic() < deadline:
                if stopped():
                    break
                time.sleep(0.1)

            if not stopped():
                try:
                    os.kill(state.pid, 9)
                except ProcessLookupError:
                    pass

                deadline = time.monotonic() + 2.0
                while time.monotonic() < deadline:
                    if stopped():
                        break
                    time.sleep(0.1)

        if not stopped():
            raise RuntimeError(
                f"Failed to stop AlloyDB broker process {state.pid} for {config.profile}. "
                f"State file left in place: {config.state_path}"
            )

        _unlink_state(config)
        return True


def broker_status(config: BrokerConfig) -> dict[str, Any]:
    """Return a human and JSON friendly status payload for one broker."""

    state = read_broker_state(config)
    if state is None and proxy_is_listening(host=config.host, port=config.port):
        with _broker_lock(config):
            state = read_broker_state(config) or _adopt_matching_listener(config)
    pid = state.pid if state else None
    alive = process_is_running(pid) if pid is not None else False
    listening = proxy_is_listening(host=config.host, port=config.port)
    return {
        "environment": config.environment,
        "profile": config.profile,
        "database": config.database,
        "db_user": config.db_user,
        "instance_uri": config.instance_uri,
        "host": config.host,
        "port": config.port,
        "state_path": str(config.state_path),
        "log_path": state.log_path if state else str(config.log_path),
        "pid": pid,
        "process_alive": alive,
        "listening": listening,
        "healthy": bool(state and alive and listening),
    }


def _profile_port(settings: Settings, profile: str, *, db_user: str) -> int:
    """Return a deterministic local port for an environment/profile/user tuple."""

    base = settings.effective_alloydb_auth_proxy_port
    if profile in _PROFILE_PORT_OFFSETS:
        return base + _PROFILE_PORT_OFFSETS[profile]
    digest = hashlib.sha256(f"{profile}:{db_user}".encode("utf-8")).digest()
    return base + 100 + int.from_bytes(digest[:2], "big") % 200


def broker_config_for_identity(
    settings: Settings,
    *,
    profile: str,
    db_user: str,
    use_iam_auth: bool,
    target_service_account: str | None,
    password: str = "",
) -> BrokerConfig:
    """Create a broker config for an explicit DB identity."""

    return BrokerConfig(
        environment=settings.app_env.value,
        profile=profile,
        instance_uri=settings.alloydb_instance_uri,
        database=settings.db_name,
        db_user=db_user,
        use_iam_auth=use_iam_auth,
        target_service_account=target_service_account,
        host=settings.alloydb_auth_proxy_host,
        port=_profile_port(settings, profile, db_user=db_user),
        use_private_ip=settings.use_private_ip,
        password=password,
    )


async def connect_via_broker(config: BrokerConfig) -> asyncpg.Connection:
    """Ensure the broker is running and return a local asyncpg connection."""

    ensure_broker(config)
    conn = await asyncpg.connect(
        host=config.host,
        port=config.port,
        user=config.db_user,
        password=config.password if config.password else None,
        database=config.database,
        ssl=False,
        statement_cache_size=0,
    )
    await _init_broker_connection(conn)
    return conn


async def open_brokered_database(config: BrokerConfig) -> BrokeredDatabase:
    """Open one brokered connection behind a Database-like wrapper."""

    return BrokeredDatabase(config=config, conn=await connect_via_broker(config))
