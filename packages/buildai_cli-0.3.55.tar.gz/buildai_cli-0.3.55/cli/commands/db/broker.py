"""Local AlloyDB broker commands for the DB CLI surface."""

from __future__ import annotations

import typer

from cli.context import resolve_broker_config
from cli.db_broker import BrokerConfig, broker_status, ensure_broker, stop_broker
from cli.output import Format, format_option, render

app = typer.Typer(
    name="broker",
    help="Inspect and manage the profile-keyed local AlloyDB broker.",
    no_args_is_help=True,
)


def _config_from_context(ctx: typer.Context) -> BrokerConfig:
    """Resolve the active DB command context into a broker config."""

    settings = ctx.obj["settings"]
    profile = ctx.obj.get("cli_profile")
    return resolve_broker_config(settings, profile=profile)


@app.command("status")
def status(
    ctx: typer.Context,
    format: Format = format_option(),
) -> None:
    """Show whether the active profile broker is alive and listening."""

    config = _config_from_context(ctx)
    render(broker_status(config), format=format)


@app.command("ensure")
def ensure(
    ctx: typer.Context,
    format: Format = format_option(),
) -> None:
    """Start or reuse the active profile broker, then print its status."""

    config = _config_from_context(ctx)
    ensure_broker(config)
    render(broker_status(config), format=format)


@app.command("stop")
def stop(
    ctx: typer.Context,
    format: Format = format_option(),
) -> None:
    """Stop the active profile broker if this workspace owns it."""

    config = _config_from_context(ctx)
    stopped = stop_broker(config)
    payload = broker_status(config)
    payload["stopped"] = stopped
    render(payload, format=format)
