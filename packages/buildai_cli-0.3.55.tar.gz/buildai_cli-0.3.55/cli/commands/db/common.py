"""Shared helpers for the simplified DB command surface."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

import asyncpg
from infra.settings import Settings

from cli.db_broker import (
    BrokeredDatabase,
    broker_config_for_identity,
    open_brokered_database,
)

MIGRATIONS_SA_EMAIL = "buildai-migrations-sa@data-470400.iam.gserviceaccount.com"
MIGRATIONS_SA_DB_USER = "buildai-migrations-sa@data-470400.iam"
REPO_ROOT = Path(__file__).resolve().parents[5]
MIGRATIONS_DIR = REPO_ROOT / "migrations"
MIGRATIONS_TABLE = "public._migrations"


@dataclass
class DatabaseStatus:
    """Capture the small DB health summary we still want in the public surface."""

    environment: str
    database_name: str
    connected: bool = False
    migrations_applied: int = 0
    repo_migrations_applied: int = 0
    migrations_total: int = 0
    migrations_raw_pending: int = 0
    migrations_safe_backfill_candidates: int = 0
    migrations_pending: int = 0
    migrations_db_only_allowed: int = 0
    migrations_db_only_unexpected: int = 0
    sources_count: int = 0
    clips_count: int = 0
    frames_count: int = 0
    embeddings_count: int = 0

    @property
    def health_status(self) -> str:
        """Return the coarse health summary for the current DB lane."""

        if not self.connected:
            return "DISCONNECTED"
        if self.migrations_pending > 0:
            return "MIGRATIONS PENDING"
        if self.migrations_db_only_unexpected > 0:
            return "TRACKING DRIFT"
        if self.sources_count == 0 or self.clips_count == 0:
            return "NO DATA"
        return "READY"


def migration_label(item: Any) -> str:
    """Return a stable human-readable migration label for logs and dry runs."""

    filename = getattr(item, "filename", None)
    if isinstance(filename, str) and filename:
        return filename
    if isinstance(item, Path):
        return item.name
    return str(item)


async def get_migrations_connection(settings: Settings) -> BrokeredDatabase:
    """Open the canonical migrations identity for reviewed DDL work."""

    settings.validate_environment_access()

    if not settings.alloydb_instance_uri:
        raise RuntimeError("AlloyDB instance URI is not configured for this environment.")

    config = broker_config_for_identity(
        settings,
        profile="migrations-local",
        db_user=MIGRATIONS_SA_DB_USER,
        use_iam_auth=True,
        target_service_account=MIGRATIONS_SA_EMAIL,
    )
    return await open_brokered_database(config)


async def get_table_row_count(
    conn: asyncpg.Connection,
    table: str,
    where_clause: str | None = None,
) -> int:
    """Return one exact table row count for the status summary."""

    query = f"SELECT COUNT(*) FROM {table}"
    if where_clause:
        query += f" WHERE {where_clause}"
    value = await conn.fetchval(query)
    return int(value or 0)


async def set_owner_role(conn: asyncpg.Connection) -> bool:
    """Try to `SET ROLE buildai_owner` for normal migration execution."""

    try:
        await conn.execute("SET ROLE buildai_owner")
        return True
    except Exception as exc:
        if "does not exist" in str(exc).lower() or "permission denied" in str(exc).lower():
            return False
        raise


async def ensure_migrations_table(conn: asyncpg.Connection) -> None:
    """Create the migration tracker table if the current lane lacks it."""

    await conn.execute(
        f"""
        CREATE TABLE IF NOT EXISTS {MIGRATIONS_TABLE} (
            id SERIAL PRIMARY KEY,
            filename TEXT UNIQUE NOT NULL,
            applied_at TIMESTAMPTZ DEFAULT NOW()
        )
        """
    )


async def get_migration_status(conn: asyncpg.Connection) -> tuple[set[str], list[Path]]:
    """Return applied migration names and the checked-in migration file list."""

    await ensure_migrations_table(conn)
    applied = await conn.fetch(f"SELECT filename FROM {MIGRATIONS_TABLE} ORDER BY filename")
    applied_set = {str(row["filename"]) for row in applied}
    migration_files = sorted(MIGRATIONS_DIR.glob("*.sql"))
    return applied_set, migration_files


def migration_requires_system_admin(path: Path) -> bool:
    """Detect migrations that must run with the DB admin connection."""

    return "requires-system-admin" in path.read_text(encoding="utf-8", errors="ignore")
