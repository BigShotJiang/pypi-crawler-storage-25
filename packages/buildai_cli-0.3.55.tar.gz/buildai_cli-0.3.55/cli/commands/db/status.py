"""Database status command for the simplified Build AI CLI."""

from __future__ import annotations

import asyncio

import asyncpg
import typer
from infra.migration_tracking import audit_migration_tracking, load_tracker_policy
from infra.settings import Settings
from rich.panel import Panel
from rich.table import Table

from cli.console import console, error, success, warning
from cli.context import get_inspection_connection

from .common import DatabaseStatus, get_table_row_count


def status(ctx: typer.Context) -> None:
    """Show the small DB health summary we still care about day to day."""

    settings: Settings = ctx.obj["settings"]

    async def run() -> None:
        status_obj = DatabaseStatus(
            environment=settings.app_env.value,
            database_name=settings.db_name,
        )

        try:
            async with get_inspection_connection(settings) as conn:
                status_obj.connected = True
                migration_audit = await audit_migration_tracking(
                    conn,
                    policy=load_tracker_policy(),
                )
                status_obj.migrations_applied = migration_audit.applied_migrations_total
                status_obj.repo_migrations_applied = (
                    migration_audit.repo_migrations_total - migration_audit.raw_pending_count
                )
                status_obj.migrations_total = migration_audit.repo_migrations_total
                status_obj.migrations_raw_pending = migration_audit.raw_pending_count
                status_obj.migrations_safe_backfill_candidates = (
                    migration_audit.verified_safe_backfills_count
                )
                status_obj.migrations_pending = migration_audit.effective_pending_count
                status_obj.migrations_db_only_allowed = migration_audit.allowed_db_only_count
                status_obj.migrations_db_only_unexpected = migration_audit.unexpected_db_only_count
                status_obj.sources_count = await get_table_row_count(conn, "core.sources")
                status_obj.clips_count = await get_table_row_count(
                    conn, "core.clips", "deleted_at IS NULL"
                )
                status_obj.frames_count = await get_table_row_count(conn, "core.frames")
                try:
                    status_obj.embeddings_count = await get_table_row_count(
                        conn, "observations.emb_siglip2_ego100k_frame_default"
                    )
                except asyncpg.UndefinedTableError:
                    status_obj.embeddings_count = 0
        except Exception as exc:
            error(f"Connection failed: {exc}")

        console.print()
        console.print(
            Panel(
                f"[bold]Environment:[/bold] {status_obj.environment} ({status_obj.database_name})",
                title="Database Status",
            )
        )
        console.print()

        migrations = Table(title="Migrations")
        migrations.add_column("Metric", style="cyan")
        migrations.add_column("Value", justify="right")
        migrations.add_row("Tracked rows", str(status_obj.migrations_applied))
        migrations.add_row("Repo applied", str(status_obj.repo_migrations_applied))
        migrations.add_row("Repo total", str(status_obj.migrations_total))
        migrations.add_row("Raw pending", str(status_obj.migrations_raw_pending))
        migrations.add_row("Safe backfills", str(status_obj.migrations_safe_backfill_candidates))
        migrations.add_row(
            "Effective pending",
            f"[red]{status_obj.migrations_pending}[/red]"
            if status_obj.migrations_pending > 0
            else "[green]0[/green]",
        )
        migrations.add_row("Allowed DB-only", str(status_obj.migrations_db_only_allowed))
        migrations.add_row(
            "Unexpected DB-only",
            f"[red]{status_obj.migrations_db_only_unexpected}[/red]"
            if status_obj.migrations_db_only_unexpected > 0
            else "[green]0[/green]",
        )
        console.print(migrations)
        console.print()

        data = Table(title="Data Volumes")
        data.add_column("Entity", style="cyan")
        data.add_column("Count", justify="right")
        data.add_row("Sources", f"{status_obj.sources_count:,}")
        data.add_row("Clips", f"{status_obj.clips_count:,}")
        data.add_row("Frames", f"{status_obj.frames_count:,}")
        data.add_row("Embeddings", f"{status_obj.embeddings_count:,}")
        console.print(data)
        console.print()

        if status_obj.health_status == "READY":
            success(f"Health: {status_obj.health_status}")
        else:
            warning(f"Health: {status_obj.health_status}")

    asyncio.run(run())
