﻿import json

from onefirewall_ai._onefirewall_compat import (
    extract_onefirewall_xml_tool_calls,
    strip_onefirewall_xml_for_display,
)


def test_extract_onefirewall_xml_tool_calls_removes_xml_from_content():
    text = (
        'I will inspect the workspace.\n'
        '<function_calls><invoke name="bash">'
        '<parameter name="command"><value>dir D:\\\\repo</value></parameter>'
        '</invoke></function_calls>'
        '\nThen I will report back.'
    )

    cleaned, tool_calls = extract_onefirewall_xml_tool_calls(text)

    assert cleaned == 'I will inspect the workspace.\n\nThen I will report back.'
    assert tool_calls[0]['function']['name'] == 'bash'
    assert json.loads(tool_calls[0]['function']['arguments']) == {'command': 'dir D:\\\\repo'}


def test_strip_onefirewall_xml_for_display_hides_incomplete_tool_block():
    text = 'Checking files...\n<function_calls><invoke name="bash">'

    assert strip_onefirewall_xml_for_display(text) == 'Checking files...'


def test_extract_onefirewall_xml_tool_calls_ignores_incomplete_invoke():
    text = 'Checking files...\n<function_calls><invoke name="read_file">'

    cleaned, tool_calls = extract_onefirewall_xml_tool_calls(text)

    assert cleaned == 'Checking files...'
    assert tool_calls == []
