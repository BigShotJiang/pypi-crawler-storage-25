from onefirewall_ai.agent import tools


def test_execute_tool_calls_before_execute_callback_before_tool(monkeypatch):
    events: list[str] = []

    def fake_read_file(path, start_line=None, end_line=None):
        events.append(f"read:{path}")
        return "ok"

    monkeypatch.setattr(tools, "read_file", fake_read_file)

    result = tools.execute_tool(
        "read_file",
        {"path": "app.py"},
        on_before_execute=lambda: events.append("before"),
    )

    assert result == "ok"
    assert events == ["before", "read:app.py"]


def test_execute_tool_does_not_call_before_execute_when_permission_denied(monkeypatch):
    called: list[bool] = []

    monkeypatch.setattr(tools, "_ask_permission", lambda _name, _display: False)

    result = tools.execute_tool(
        "write_file",
        {"path": "app.py", "content": "hello"},
        on_before_execute=lambda: called.append(True),
    )

    assert result.startswith("[DENIED]")
    assert called == []
