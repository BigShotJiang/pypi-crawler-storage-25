from onefirewall_ai import sessions


def test_delete_session_removes_session_file(tmp_path, monkeypatch):
    session_file = tmp_path / "agent_abc.md"
    session_file.write_text("# Session: agent_abc\n", encoding="utf-8")
    monkeypatch.setattr(sessions, "SESSIONS_DIR", tmp_path)

    sessions.delete_session("agent_abc")

    assert not session_file.exists()


def test_delete_session_rejects_path_like_id(tmp_path, monkeypatch):
    outside_file = tmp_path / "outside.md"
    outside_file.write_text("# Session: outside\n", encoding="utf-8")
    sessions_dir = tmp_path / "sessions"
    sessions_dir.mkdir()
    monkeypatch.setattr(sessions, "SESSIONS_DIR", sessions_dir)

    sessions.delete_session("../outside")

    assert outside_file.exists()
