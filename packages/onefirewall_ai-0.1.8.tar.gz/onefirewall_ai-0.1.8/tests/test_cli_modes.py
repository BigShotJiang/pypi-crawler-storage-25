import sys
from types import SimpleNamespace

import onefirewall_ai.cli as cli


def test_repl_defaults_to_agent_mode(monkeypatch):
    captured = {}

    def fake_run_repl(*, initial_prompt, session_id, agent_mode):
        captured["initial_prompt"] = initial_prompt
        captured["session_id"] = session_id
        captured["agent_mode"] = agent_mode

    monkeypatch.setattr(cli, "init_home", lambda: None)
    monkeypatch.setattr(cli.sys, "argv", ["onefirewall-ai"])
    monkeypatch.setattr(cli.sys, "stdin", SimpleNamespace(isatty=lambda: True))
    monkeypatch.setitem(sys.modules, "onefirewall_ai.repl", SimpleNamespace(run_repl=fake_run_repl))

    cli.main()

    assert captured["initial_prompt"] is None
    assert captured["session_id"] is None
    assert captured["agent_mode"] is True


def test_repl_honors_explicit_chat_mode(monkeypatch):
    captured = {}

    def fake_run_repl(*, initial_prompt, session_id, agent_mode):
        captured["agent_mode"] = agent_mode

    monkeypatch.setattr(cli, "init_home", lambda: None)
    monkeypatch.setattr(cli.sys, "argv", ["onefirewall-ai", "chat"])
    monkeypatch.setattr(cli.sys, "stdin", SimpleNamespace(isatty=lambda: True))
    monkeypatch.setitem(sys.modules, "onefirewall_ai.repl", SimpleNamespace(run_repl=fake_run_repl))

    cli.main()

    assert captured["agent_mode"] is False


def test_sessions_delete_dispatches_to_delete_session(monkeypatch):
    captured = {}

    def fake_delete_session(session_id):
        captured["session_id"] = session_id

    monkeypatch.setattr(cli, "init_home", lambda: None)
    monkeypatch.setattr(cli.sys, "argv", ["onefirewall-ai", "sessions", "delete", "agent_abc"])
    monkeypatch.setitem(
        sys.modules,
        "onefirewall_ai.sessions",
        SimpleNamespace(delete_session=fake_delete_session),
    )

    cli.main()

    assert captured["session_id"] == "agent_abc"
