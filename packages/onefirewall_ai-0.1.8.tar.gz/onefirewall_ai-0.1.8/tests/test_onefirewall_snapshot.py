﻿from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path

from onefirewall_ai._onefirewall_snapshot import (
    CURATED_STATIC_PROMPT_SECTIONS,
    DEFAULT_AGENT_PROMPT,
    UPSTREAM_SOURCES,
    XML_TAGS,
)

REPO_ROOT = Path(__file__).resolve().parents[1]
SCRIPT_PATH = REPO_ROOT / 'scripts' / 'sync_onefirewall_snapshot.py'
SPEC = spec_from_file_location('sync_onefirewall_snapshot', SCRIPT_PATH)
MODULE = module_from_spec(SPEC)
assert SPEC is not None and SPEC.loader is not None
SPEC.loader.exec_module(MODULE)
build_snapshot_module = MODULE.build_snapshot_module


def test_snapshot_matches_generator_output():
    generated = build_snapshot_module(REPO_ROOT)
    actual = (REPO_ROOT / 'onefirewall_ai' / '_onefirewall_snapshot.py').read_text(encoding='utf-8')
    assert actual == generated


def test_snapshot_tracks_upstream_sources():
    xml_source = (REPO_ROOT / 'openclaude' / 'src' / 'constants' / 'xml.ts').read_text(encoding='utf-8')
    prompts_source = (REPO_ROOT / 'openclaude' / 'src' / 'constants' / 'prompts.ts').read_text(encoding='utf-8')

    for tag_name in ('COMMAND_MESSAGE_TAG', 'BASH_STDOUT_TAG', 'TICK_TAG'):
        assert f"export const {tag_name} = '{XML_TAGS[tag_name]}'" in xml_source

    assert UPSTREAM_SOURCES['xml'] == 'openclaude/src/constants/xml.ts'
    assert UPSTREAM_SOURCES['prompts'] == 'openclaude/src/constants/prompts.ts'
    assert 'export const DEFAULT_AGENT_PROMPT' in prompts_source
    assert 'OneFirewall AI' in DEFAULT_AGENT_PROMPT
    assert 'OpenClaude' not in DEFAULT_AGENT_PROMPT
    assert 'All text you output outside of tool use is displayed to the user.' in CURATED_STATIC_PROMPT_SECTIONS['system']
    assert 'Do NOT use the bash tool to run commands when a relevant dedicated tool is provided.' in CURATED_STATIC_PROMPT_SECTIONS['using_your_tools']
