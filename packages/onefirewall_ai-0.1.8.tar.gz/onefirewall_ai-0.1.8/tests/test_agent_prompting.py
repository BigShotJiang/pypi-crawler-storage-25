from onefirewall_ai.agent.loop import (
    _build_system_prompt,
    _recover_empty_agent_reply,
    _wrap_agent_mode_prompt,
)
from onefirewall_ai._onefirewall_snapshot import (
    CURATED_STATIC_PROMPT_SECTIONS,
    DEFAULT_AGENT_PROMPT,
)


def test_system_prompt_requires_progress_updates():
    prompt = _build_system_prompt()

    assert "Before the first tool call for a task" in prompt
    assert "Before editing files or running a substantial command" in prompt
    assert "keep the user informed with short natural updates" in prompt
    assert "Do not create markdown reports, summary files, or extra artifacts unless the user asks for them." in prompt
    assert "Before destructive, hard-to-reverse, or externally visible actions, check with the user first." in prompt
    assert "Use todo_write proactively for multi-step work" in prompt


def test_agent_mode_wrapper_requests_short_update_before_tools():
    wrapped = _wrap_agent_mode_prompt("fix the auth bug")

    assert "If the user's message is conversational" in wrapped
    assert "first send one short sentence telling the user what you are about to do" in wrapped
    assert "Then use your tools to take action directly when tools are needed" in wrapped
    assert "todo_write first if the task is multi-step" in wrapped
    assert "Do NOT create extra report files or markdown summaries unless the user asks for them" in wrapped
    assert "run_in_background=true" in wrapped
    assert "launch it, report the URL or startup failure once" in wrapped


def test_empty_agent_reply_recovers_for_greeting():
    reply = _recover_empty_agent_reply("hey", "", [])

    assert reply == "Hey! What would you like to work on?"


def test_system_prompt_includes_onefirewall_snapshot_sections():
    prompt = _build_system_prompt()

    assert DEFAULT_AGENT_PROMPT in prompt
    assert "OneFirewall AI" in DEFAULT_AGENT_PROMPT
    assert "OpenClaude" not in DEFAULT_AGENT_PROMPT
    assert CURATED_STATIC_PROMPT_SECTIONS["system"] in prompt
    assert CURATED_STATIC_PROMPT_SECTIONS["doing_tasks"] in prompt
    assert "# OneFirewall agent baseline" in prompt
    assert "# Environment" in prompt
    assert "Working Directory:" in prompt
    assert "Shell:" in prompt
