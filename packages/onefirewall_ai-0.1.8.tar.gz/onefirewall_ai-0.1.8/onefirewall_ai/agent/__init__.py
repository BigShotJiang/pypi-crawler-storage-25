"""
agent/ - Autonomous agent for the OneFirewall AI CLI.

Provides a OneFirewall agentic loop:
  - Tool calling (Bash, File Read/Write/Edit, Glob, Grep, Web, Ask)
  - Permission system (ask user before dangerous ops)
  - Multi-turn loop until task is complete
"""
