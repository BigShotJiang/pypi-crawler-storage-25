﻿"""
onefirewall-ai â€” CLI for the OneFirewall AI Gateway
"""

__version__ = "0.1.8"
__app_name__ = "onefirewall-ai"
__description__ = "CLI for the OneFirewall AI Gateway â€” chat, stream, and build agents from your terminal"

