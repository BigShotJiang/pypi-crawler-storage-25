"""ecb-hr-ai-assistant."""
