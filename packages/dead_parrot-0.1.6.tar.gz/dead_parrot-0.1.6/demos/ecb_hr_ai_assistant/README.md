# ecb-hr-ai-assistant

This is a demo that showcases how to build an AI assistant with [dead-parrot](https://github.com/pygumby/dead-parrot/).
At the same time, it is a template that serves as a starting point for your own AI assistant.

The structure is simple:
- [documents/](documents/) contains the corpus for context retrieval.
- [examples/](examples/) contains the question-answer pairs for evaluation and retrieval.
- [constants.py](src/ecb_hr_ai_assistant/constants.py) defines names and other constants.
- [ai_assistant.py](src/ecb_hr_ai_assistant/ai_assistant.py) defines the AI assistant using dead-parrot.
- [temporal_workflow.py](src/ecb_hr_ai_assistant/temporal_workflow.py) defines a Temporal workflow that calls AI assistant.
- [temporal_worker.py](src/ecb_hr_ai_assistant/temporal_worker.py) defines and runs a Temporal worker for the Temporal workflow.
- [rest_api.py](src/ecb_hr_ai_assistant/rest_api.py)defines and runs a FastAPI REST API that calls the Temporal workflow.
----

### Usage

Run the following commands from the repository's root.

1. Initialize, query, evaluate and optimize the AI assistant (can be skipped):
    ```
    uv run --directory demos/ecb_hr_ai_assistant python -m ecb_hr_ai_assistant.ai_assistant
    ```
2. Start the Temporal Service (if not yet running):
    ```
    temporal server start-dev
    ```
3. Start the Temporal worker:
    ```
    uv run --directory demos/ecb_hr_ai_assistant python -m ecb_hr_ai_assistant.temporal_worker
    ```
4. Start the REST API:
    ```
    uv run --directory demos/ecb_hr_ai_assistant uvicorn ecb_hr_ai_assistant.rest_api:app --port 8001
    ```
5. Call the `/card` endpoint to get the AI assistant's card:
    ```
    curl --request GET \
    --url http://localhost:8001/card \
    --header 'content-type: application/json'
    ```
6. Call the `/ask` endpoint to ask a question to the AI assistant:
    ```
    curl --request POST \
    --url http://localhost:8001/ask \
    --header 'content-type: application/json' \
    --data '{
        "question": "What is a fixed-term contract?"
    }'
    ```

### Development

To create your own AI assistant, change the following files:
- [constants.py](src/ecb_hr_ai_assistant/constants.py): Update values such as the AI assistant's name
- [ai_assistant.py](src/ecb_hr_ai_assistant/ai_assistant.py): Customize the AI assistant's configuration
- [temporal_workflow.py](src/ecb_hr_ai_assistant/temporal_workflow.py): Change the Temporal worklow's name (Use VS Code's "Rename Symbol" to avoid stale references!)
