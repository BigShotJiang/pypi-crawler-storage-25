"""
This module contains custom template tags for the powercrud package.

It includes functions for generating action links, displaying object details,
and rendering object lists with customized formatting.

Key components:
- action_links: Generates HTML for action buttons (View, Edit, Delete, etc.)
- object_detail: Renders details of an object, including fields and properties
- object_list: Creates a list view of objects with customized field display
- get_proper_elided_page_range: Generates a properly elided page range for pagination

The module adapts to different CSS frameworks and supports HTMX and modal functionality.
"""

from datetime import date, datetime  # Import both date and datetime classes
from typing import Any, Dict, List, Optional

from django import template
from django.utils.html import conditional_escape
from django.utils.safestring import mark_safe
from django.utils.translation import gettext_lazy as _
from django.db import models

from powercrud.conf import get_powercrud_setting
from powercrud.logging import get_logger

log = get_logger(__name__)

register = template.Library()


def _should_center_field(model_field: models.Field) -> bool:
    """
    Return True when the column should default to centered alignment.
    Treat text-like, dropdown (FK), and M2M fields as left-aligned.
    """
    if not model_field:
        return False
    if getattr(model_field, "many_to_many", False):
        return False
    if model_field.is_relation:
        return False

    field_type = model_field.get_internal_type()
    text_types = {
        "CharField",
        "TextField",
        "SlugField",
        "EmailField",
        "URLField",
    }
    if field_type in text_types:
        return False
    # Default to centered for numerics, booleans, and other non-text columns.
    return True


def _get_model_field_or_none(view, field_name: str):
    """Return a model field for a rendered name, or None when absent."""
    try:
        return view.model._meta.get_field(field_name)
    except Exception:
        return None


def _get_effective_list_field(view, field_name: str, queryset=None):
    """
    Return model or annotation field metadata for a rendered list column.
    """
    model_field = _get_model_field_or_none(view, field_name)
    if model_field is not None:
        return model_field

    output_field_getter = getattr(view, "_get_queryset_annotation_output_field", None)
    if callable(output_field_getter):
        return output_field_getter(field_name, queryset=queryset)
    return None


def _get_display_name_for_field(field_name: str, field) -> str:
    """Return a human label for a model or annotation field."""
    if field is not None and hasattr(field, "remote_field"):
        remote_field = getattr(field, "remote_field", None)
        if remote_field and isinstance(remote_field, models.ManyToManyRel):
            return remote_field.model._meta.verbose_name_plural.title()

    verbose_name = getattr(field, "verbose_name", None)
    if verbose_name:
        return str(verbose_name).title()
    return field_name.replace("_", " ").title()


def _format_list_field_value(
    obj,
    field_name: str,
    field,
    tick_svg: str,
    cross_svg: str,
    *,
    is_model_field: bool,
):
    """
    Format a model-field or annotation value for list-cell display.
    """
    value = getattr(obj, field_name, None)

    if field is not None and getattr(field, "many_to_many", False):
        return ", ".join(str(item) for item in getattr(obj, field_name).all())

    internal_type = field.get_internal_type() if field is not None else ""
    if internal_type == "BooleanField" or isinstance(value, bool):
        if value is True:
            return mark_safe(tick_svg)
        if value is False:
            return mark_safe(cross_svg)
        return ""

    if isinstance(value, (date, datetime)) and value is not None:
        return value.strftime("%d/%m/%Y")

    if field is not None and getattr(field, "is_relation", False):
        return str(value)

    if field is not None and is_model_field:
        return field.value_to_string(obj)

    return "" if value is None else str(value)


def _resolve_cell_alignment(
    *,
    column_alignments: dict[str, str],
    name: str,
    default_align: str,
) -> str:
    """
    Return the configured alignment override for a rendered cell when present.
    """
    return column_alignments.get(name, default_align)


@register.filter
def get_form_field(form, field_name):
    """
    Safely fetch a bound form field by name.
    Returns None if the field does not exist.
    """
    if not form or not field_name:
        return None
    try:
        return form[field_name]
    except KeyError:
        return None


def _resolve_modal_action_url(
    url: str, query_string: str, show_modal: bool
) -> str:
    """
    Append the current query string to modal action URLs exactly once.
    """
    if not show_modal or not query_string:
        return url
    separator = "&" if "?" in url else "?"
    return f"{url}{separator}{query_string}"


def _resolve_named_view_method(view: Any, method_name: str | None) -> Any:
    """
    Resolve a named method on the view, returning None when unavailable.
    """
    if not method_name:
        return None
    resolver = getattr(view, method_name, None)
    if callable(resolver):
        return resolver
    return None


def _resolve_extra_action_disabled_state(
    *,
    view: Any,
    object: Any,
    action: Dict[str, Any],
    request: Any,
    lock_reason: str | None,
    lock_label: str | None,
) -> tuple[bool, str | None]:
    """
    Determine whether an extra action should render disabled and why.
    """
    disable = bool(lock_reason and action.get("lock_sensitive", False))
    disabled_reason = lock_label if disable else None

    disabled_if_name = action.get("disabled_if")
    if disabled_if_name:
        disabled_if = _resolve_named_view_method(view, disabled_if_name)
        if disabled_if is not None:
            try:
                custom_disabled = bool(disabled_if(object, request))
            except Exception:
                custom_disabled = False
            if custom_disabled:
                disable = True
                disabled_reason_name = action.get("disabled_reason")
                disabled_reason_resolver = _resolve_named_view_method(
                    view, disabled_reason_name
                )
                if disabled_reason_resolver is not None:
                    try:
                        disabled_reason = disabled_reason_resolver(object, request)
                    except Exception:
                        disabled_reason = None

    return disable, disabled_reason


def _resolve_standard_action_disabled_state(
    *,
    view: Any,
    object: Any,
    action_name: str,
    request: Any,
    lock_reason: str | None,
    lock_label: str | None,
) -> tuple[bool, str | None]:
    """
    Determine whether a built-in standard action should render disabled and why.
    """
    disable = bool(lock_reason and action_name in {"Edit", "Delete"})
    disabled_reason = lock_label if disable else None

    if disable:
        return disable, disabled_reason

    if action_name == "Edit":
        can_update = getattr(view, "can_update_object", None)
        if callable(can_update):
            try:
                allowed = bool(can_update(object, request))
            except Exception:
                allowed = True
            if not allowed:
                disable = True
                get_reason = getattr(view, "get_update_disabled_reason", None)
                if callable(get_reason):
                    try:
                        disabled_reason = get_reason(object, request)
                    except Exception:
                        disabled_reason = None
        return disable, disabled_reason

    if action_name != "Delete":
        return disable, disabled_reason

    can_delete = getattr(view, "can_delete_object", None)
    if callable(can_delete):
        try:
            allowed = bool(can_delete(object, request))
        except Exception:
            allowed = True
        if not allowed:
            disable = True
            get_reason = getattr(view, "get_delete_disabled_reason", None)
            if callable(get_reason):
                try:
                    disabled_reason = get_reason(object, request)
                except Exception:
                    disabled_reason = None

    return disable, disabled_reason


def _get_selection_button_state(
    view: Any,
    request: Any,
    button: Dict[str, Any],
) -> dict[str, Any]:
    """
    Return selection-aware state metadata for an extra header button.
    """
    uses_selection = bool(button.get("uses_selection", False))
    selected_ids: list[str] = []

    if uses_selection and request is not None:
        selection_getter = getattr(view, "get_selected_ids_for_extra_button", None)
        if callable(selection_getter):
            selected_ids = selection_getter(request, button) or []
        elif hasattr(view, "get_selected_ids_from_session"):
            selected_ids = view.get_selected_ids_from_session(request) or []
        selected_ids = [str(selected_id) for selected_id in selected_ids]

    selected_count = len(selected_ids)
    selection_min_count = int(button.get("selection_min_count", 0) or 0)
    selection_min_behavior = button.get("selection_min_behavior", "allow")
    is_below_minimum = selected_count < selection_min_count
    disable = bool(
        uses_selection
        and selection_min_behavior == "disable"
        and is_below_minimum
    )

    return {
        "uses_selection": uses_selection,
        "selected_count": selected_count,
        "selection_min_count": selection_min_count,
        "selection_min_behavior": selection_min_behavior,
        "disable": disable,
        "disabled_reason": button.get("selection_min_reason") if disable else None,
    }


def _render_action_anchor(
    *,
    url: str,
    anchor_text: str,
    class_name: str,
    target: str,
    hx_post: bool,
    show_modal: bool,
    modal_attrs: str,
    disable: bool,
    lock_label: str | None,
    use_htmx: bool,
    query_string: str,
    modal_box_classes: str | None = None,
) -> str:
    """
    Render a single row-action anchor with HTMX and disabled metadata.
    """
    resolved_url = _resolve_modal_action_url(url, query_string, show_modal)
    disabled_classes = (
        " btn-disabled opacity-50 pointer-events-none" if disable else ""
    )

    attrs = [
        f"href='{resolved_url}'",
        f"class='{class_name}{disabled_classes}'",
    ]

    if use_htmx:
        attrs.append(f"hx-{'post' if hx_post else 'get'}='{resolved_url}'")
        if target:
            attrs.append(f"hx-target='{target}'")
        if not show_modal:
            attrs.append("hx-replace-url='true'")
            attrs.append("hx-push-url='true'")

    if show_modal and modal_attrs:
        attrs.append(modal_attrs)
        if modal_box_classes:
            attrs.append(
                "data-powercrud-modal-box-classes="
                f"'{conditional_escape(str(modal_box_classes))}'"
            )

    if disable and lock_label:
        attrs.append("aria-disabled='true'")
        attrs.append(f"data-tippy-content='{lock_label}'")
        attrs.append("data-powercrud-tooltip='semantic'")

    attrs.append(f"data-inline-action='{anchor_text.lower()}'")
    return f"<a {' '.join(attrs)}>{anchor_text}</a>"


def _resolve_view_option(
    view: Any,
    *,
    method_name: str,
    attr_name: str | None = None,
    default: Any = None,
) -> Any:
    """
    Return a view option from a method when available, otherwise fall back to
    a plain attribute or the supplied default.

    Template tags are sometimes exercised with lightweight stubs in tests or by
    downstream callers that do not inherit the full PowerCRUD mixin stack.
    """
    resolver = getattr(view, method_name, None)
    if callable(resolver):
        return resolver()
    if attr_name:
        return getattr(view, attr_name, default)
    return default


def _resolve_list_cell_tooltip(
    *,
    view: Any,
    obj: Any,
    field_name: str,
    is_property: bool,
    request: Any,
) -> str | None:
    """
    Resolve a plain-text semantic tooltip for one rendered list cell.
    """
    resolver = getattr(view, "get_list_cell_tooltip", None)
    if not callable(resolver):
        return None
    try:
        tooltip_text = resolver(
            obj,
            field_name,
            is_property=is_property,
            request=request,
        )
    except Exception:
        return None
    if tooltip_text is None:
        return None
    tooltip_text = str(tooltip_text).strip()
    return tooltip_text or None


LIST_CELL_OPEN_IN_VALUES = {"current", "new", "modal"}


def _normalize_list_cell_open_in(value: Any, *, default: str = "new") -> str:
    """
    Normalize public list-cell link opening modes.
    """
    default_open_in = str(default or "new").strip()
    if default_open_in not in LIST_CELL_OPEN_IN_VALUES:
        default_open_in = "new"

    open_in = str(value or default_open_in).strip()
    if open_in in LIST_CELL_OPEN_IN_VALUES:
        return open_in
    return default_open_in


def _resolve_list_cell_default_open_in(view: Any) -> str:
    """
    Resolve the view-wide default opening mode for list-cell links.
    """
    return _normalize_list_cell_open_in(
        _resolve_view_option(
            view,
            method_name="get_list_cell_link_default_open_in",
            attr_name="list_cell_link_default_open_in",
            default="new",
        )
    )


def _resolve_list_cell_modal_metadata(
    *,
    view: Any,
    open_in: str,
    modal_box_classes: Any = None,
) -> dict[str, str]:
    """
    Resolve HTMX/modal metadata for a linked list cell when requested.
    """
    if open_in != "modal":
        return {}

    use_htmx = getattr(view, "get_use_htmx", None)
    use_modal_enabled = getattr(view, "get_use_modal", None)
    if not callable(use_htmx) or not callable(use_modal_enabled):
        return {}
    if not use_htmx() or not use_modal_enabled():
        return {}

    framework = get_powercrud_setting("POWERCRUD_CSS_FRAMEWORK")
    styles = view.get_framework_styles()[framework]
    target = _resolve_view_option(
        view,
        method_name="get_modal_target",
        attr_name="modal_target",
        default="#powercrudModalContent",
    )
    if target and not str(target).startswith("#"):
        target = f"#{target}"

    metadata = {
        "hx_method": "get",
        "hx_target": str(target or ""),
        "modal_attrs": str(styles.get("modal_attrs", "")).strip(),
    }
    if modal_box_classes is not None:
        modal_box_classes = str(modal_box_classes).strip()
        if modal_box_classes:
            metadata["modal_box_classes"] = modal_box_classes
    return metadata


def _normalize_list_cell_link_result(result: Any, *, view: Any) -> dict[str, Any] | None:
    """
    Normalize hook-returned list-cell link metadata.
    """
    if result is None or result is False:
        return None
    if not isinstance(result, dict):
        return None

    url = result.get("url")
    if url is None:
        return None

    url = str(url).strip()
    if not url:
        return None

    open_in = _normalize_list_cell_open_in(
        result.get("open_in"),
        default=_resolve_list_cell_default_open_in(view),
    )

    normalized: dict[str, Any] = {
        "url": url,
        "classes": str(result.get("classes") or "link link-primary").strip(),
        "open_in": open_in,
    }
    for key in ("title", "rel"):
        value = result.get(key)
        if value is None:
            continue
        value = str(value).strip()
        if value:
            normalized[key] = value
    if open_in == "new":
        normalized["target"] = "_blank"
        normalized.setdefault("rel", "noopener noreferrer")
    normalized.update(
        _resolve_list_cell_modal_metadata(
            view=view,
            open_in=open_in,
            modal_box_classes=result.get("modal_box_classes"),
        )
    )
    return normalized


def _resolve_declarative_list_cell_link(
    *,
    view: Any,
    obj: Any,
    field_name: str,
    is_property: bool,
) -> dict[str, Any] | None:
    """
    Resolve narrow declarative list-cell link config for one rendered cell.
    """
    configured_links = _resolve_view_option(
        view,
        method_name="get_link_fields",
        attr_name="link_fields",
        default={},
    )
    if not isinstance(configured_links, dict):
        return None

    config = configured_links.get(field_name)
    if not config:
        return None

    if isinstance(config, str):
        config = {"view_name": config}
    if not isinstance(config, dict):
        return None

    view_name = str(config.get("view_name") or "").strip()
    url = str(config.get("url") or "").strip()
    if not view_name and not url:
        return None

    if view_name:
        pk_attr = config.get("pk_attr")
        if pk_attr is None:
            if is_property:
                pk_attr = "pk"
            else:
                try:
                    model_field = obj._meta.get_field(field_name)
                except Exception:
                    model_field = None
                if model_field is not None and getattr(model_field, "is_relation", False):
                    pk_attr = f"{field_name}_id"
                else:
                    pk_attr = "pk"

        if not isinstance(pk_attr, str) or not pk_attr.strip():
            return None

        pk_value = getattr(obj, pk_attr.strip(), None)
        if pk_value in {None, ""}:
            return None

        url = view.safe_reverse(view_name, kwargs={"pk": pk_value})
    if not url:
        return None

    open_in = _normalize_list_cell_open_in(
        config.get("open_in"),
        default=_resolve_list_cell_default_open_in(view),
    )

    normalized: dict[str, Any] = {
        "url": url,
        "classes": "link link-primary",
        "open_in": open_in,
    }
    if open_in == "new":
        normalized["target"] = "_blank"
        normalized["rel"] = "noopener noreferrer"
    normalized.update(
        _resolve_list_cell_modal_metadata(
            view=view,
            open_in=open_in,
            modal_box_classes=config.get("modal_box_classes"),
        )
    )
    return normalized


def _resolve_list_cell_link(
    *,
    view: Any,
    obj: Any,
    field_name: str,
    value: Any,
    is_property: bool,
    is_inline_editable: bool,
    request: Any,
) -> dict[str, Any] | None:
    """
    Resolve final list-cell link metadata, preferring hook overrides.
    """
    if is_inline_editable:
        return None

    resolver = getattr(view, "get_list_cell_link", None)
    if callable(resolver):
        try:
            hook_result = resolver(
                obj,
                field_name,
                value,
                is_property=is_property,
                request=request,
            )
        except Exception:
            hook_result = None

        if hook_result is False:
            return None

        normalized = _normalize_list_cell_link_result(hook_result, view=view)
        if normalized is not None:
            return normalized

    return _resolve_declarative_list_cell_link(
        view=view,
        obj=obj,
        field_name=field_name,
        is_property=is_property,
    )


def action_links(view: Any, object: Any) -> str:
    """
    Generate HTML for action links (buttons) for a given object.

    Args:
        view: The view instance
        object: The object for which actions are being generated

    Returns:
        str: HTML string of action buttons
    """
    framework: str = get_powercrud_setting("POWERCRUD_CSS_FRAMEWORK")
    styles: Dict[str, Any] = view.get_framework_styles()[framework]
    action_button_classes = view.get_action_button_classes()

    prefix: str = view.get_prefix()
    use_htmx: bool = view.get_use_htmx()
    use_modal: bool = view.get_use_modal()
    extra_actions_mode: str = _resolve_view_option(
        view,
        method_name="get_extra_actions_mode",
        attr_name="extra_actions_mode",
        default="buttons",
    )
    query_string = ""
    if hasattr(view, "request") and hasattr(view.request, "GET") and view.request.GET:
        query_string = view.request.GET.urlencode()

    default_target: str = _resolve_view_option(
        view,
        method_name="get_htmx_target",
        attr_name="default_htmx_target",
        default="#content",
    )

    # Standard actions with framework-specific button classes
    lock_reason = getattr(object, "_blocked_reason", None)
    lock_label = getattr(object, "_blocked_label", None)

    standard_action_items: List[Dict[str, Any]] = []
    standard_actions = [
        ("View", view.safe_reverse(f"{prefix}-detail", kwargs={"pk": object.pk})),
        ("Edit", view.safe_reverse(f"{prefix}-update", kwargs={"pk": object.pk})),
        ("Delete", view.safe_reverse(f"{prefix}-delete", kwargs={"pk": object.pk})),
    ]
    for name, url in standard_actions:
        if url is None:
            continue
        disable, disabled_reason = _resolve_standard_action_disabled_state(
            view=view,
            object=object,
            action_name=name,
            request=getattr(view, "request", None),
            lock_reason=lock_reason,
            lock_label=lock_label,
        )
        standard_action_items.append(
            {
                "url": url,
                "text": name,
                "button_class": styles["actions"][name],
                "target": default_target,
                "hx_post": False,
                "show_modal": use_modal,
                "modal_attrs": styles["modal_attrs"],
                "modal_box_classes": "",
                "disable": disable,
                "disabled_reason": disabled_reason,
            }
        )

    # Add extra actions if defined
    extra_actions: List[Dict[str, Any]] = getattr(view, "extra_actions", [])
    extra_action_items: List[Dict[str, Any]] = []
    for action in extra_actions:
        url: Optional[str] = view.safe_reverse(
            action["url_name"],
            kwargs={"pk": object.pk} if action.get("needs_pk", True) else None,
        )

        if url is not None:
            htmx_target: str = action.get("htmx_target", default_target)
            if htmx_target and not htmx_target.startswith("#"):
                htmx_target = f"#{htmx_target}"
            button_class: str = action.get("button_class", styles["extra_default"])

            display_modal = action.get("display_modal", use_modal)
            show_modal: bool = display_modal if use_modal else False
            modal_attrs: str = styles["modal_attrs"] if show_modal else " "
            modal_box_classes: str = (
                str(action.get("modal_box_classes") or "") if show_modal else ""
            )

            disable_extra, disabled_reason = _resolve_extra_action_disabled_state(
                view=view,
                object=object,
                action=action,
                request=getattr(view, "request", None),
                lock_reason=lock_reason,
                lock_label=lock_label,
            )

            extra_action_items.append(
                {
                    "url": url,
                    "text": action["text"],
                    "button_class": button_class,
                    "target": htmx_target,
                    "hx_post": action.get("hx_post", False),
                    "show_modal": show_modal,
                    "modal_attrs": modal_attrs,
                    "modal_box_classes": modal_box_classes,
                    "disable": disable_extra,
                    "disabled_reason": disabled_reason,
                }
            )

    standard_links = [
        _render_action_anchor(
            url=action["url"],
            anchor_text=action["text"],
            class_name=(
                f"{styles['base']} join-item {action['button_class']} {action_button_classes}"
            ),
            target=action["target"],
            hx_post=action["hx_post"],
            show_modal=action["show_modal"],
            modal_attrs=action["modal_attrs"],
            disable=action["disable"],
            lock_label=action.get("disabled_reason"),
            use_htmx=use_htmx,
            query_string=query_string,
            modal_box_classes=action["modal_box_classes"],
        )
        for action in standard_action_items
    ]

    if extra_actions_mode == "dropdown" and extra_action_items:
        dropdown_items = [
            "<li>"
            + _render_action_anchor(
                url=action["url"],
                anchor_text=action["text"],
                class_name="justify-start whitespace-nowrap",
                target=action["target"],
                hx_post=action["hx_post"],
                show_modal=action["show_modal"],
                modal_attrs=action["modal_attrs"],
                disable=action["disable"],
                lock_label=action.get("disabled_reason") or lock_label,
                use_htmx=use_htmx,
                query_string=query_string,
                modal_box_classes=action["modal_box_classes"],
            )
            + "</li>"
            for action in extra_action_items
        ]
        extra_links = [
            "<div class='relative' data-powercrud-row-actions-dropdown='true'>"
            f"<button type='button' class='{styles['base']} join-item {styles['extra_default']} {action_button_classes} gap-1' aria-label='More actions' aria-expanded='false' data-inline-action='more' data-powercrud-row-actions-trigger='true'>More"
            "<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 20 20' fill='currentColor' class='h-3.5 w-3.5' aria-hidden='true'>"
            "<path fill-rule='evenodd' d='M5.23 7.21a.75.75 0 0 1 1.06.02L10 11.168l3.71-3.938a.75.75 0 1 1 1.08 1.04l-4.25 4.5a.75.75 0 0 1-1.08 0l-4.25-4.5a.75.75 0 0 1 .02-1.06Z' clip-rule='evenodd' />"
            "</svg></button>"
            "<div hidden data-powercrud-row-actions-template='true'>"
            "<ul tabindex='0' role='menu' class='menu bg-base-100 rounded-box z-[1200] min-w-40 p-2 shadow border border-base-300' data-powercrud-row-actions-panel='true'>"
            + "".join(dropdown_items)
            + "</ul></div></div>"
        ]
    else:
        extra_links = [
            _render_action_anchor(
                url=action["url"],
                anchor_text=action["text"],
                class_name=(
                    f"{styles['base']} join-item {action['button_class']} {action_button_classes}"
                ),
                target=action["target"],
                hx_post=action["hx_post"],
                show_modal=action["show_modal"],
                modal_attrs=action["modal_attrs"],
                disable=action["disable"],
                lock_label=action.get("disabled_reason") or lock_label,
                use_htmx=use_htmx,
                query_string=query_string,
                modal_box_classes=action["modal_box_classes"],
            )
            for action in extra_action_items
        ]

    links: List[str] = ["<div class='join'>" + " ".join(standard_links + extra_links) + "</div>"]

    return mark_safe(" ".join(links))


@register.inclusion_tag(
    f"powercrud/{get_powercrud_setting('POWERCRUD_CSS_FRAMEWORK')}/partial/detail.html"
)
def object_detail(object, view):
    """
    Display both fields and properties for an object detail view.

    Args:
        object: The object to display
        view: The view instance

    Returns:
        dict: Context for rendering the detail template
    """

    def iter():
        # Handle regular fields
        for f in view.detail_fields:
            field = object._meta.get_field(f)
            if field.is_relation:
                value = str(getattr(object, f))
            else:
                value = field.value_to_string(object)
            yield (field.verbose_name, value)

        # Handle properties
        for prop in view.detail_properties:
            value = str(getattr(object, prop))
            name = prop.replace("_", " ").title()
            yield (name, value)

    return {
        "object": iter(),
    }


@register.inclusion_tag(
    f"powercrud/{get_powercrud_setting('POWERCRUD_CSS_FRAMEWORK')}/partial/list.html",
    takes_context=True,
)
def object_list(context, objects, view):
    """
    Override default to set value = str()
    instead of value_to_string(). This allows related fields
    to be displayed correctly (not just the id)
    """
    fields = view.fields
    properties = getattr(view, "properties", []) or []
    queryset = context.get("filtered_queryset")
    if queryset is None and hasattr(objects, "query"):
        queryset = objects
    validate_list_fields = getattr(view, "validate_list_fields_against_queryset", None)
    if callable(validate_list_fields) and hasattr(queryset, "query"):
        validate_list_fields(fields, queryset)

    inline_config = context.get("inline_edit") or {}
    inline_enabled = bool(inline_config.get("enabled"))
    inline_fields = inline_config.get("fields") or []
    inline_fields = set(inline_fields)
    inline_row_endpoint = inline_config.get("row_endpoint_name")
    inline_dependencies = inline_config.get("dependencies") or {}

    # Check if bulk edit is enabled
    enable_bulk_edit = (
        hasattr(view, "get_bulk_edit_enabled") and view.get_bulk_edit_enabled()
    )

    # Get currently selected IDs from session if bulk edit is enabled
    request = context.get("request") or getattr(view, "request", None)
    selected_ids = []
    if request and enable_bulk_edit and hasattr(view, "get_selected_ids_from_session"):
        selected_ids = view.get_selected_ids_from_session(request)
        # Convert to strings for comparison
        selected_ids = [str(id) for id in selected_ids]

    # Get selection key suffix if available
    selection_key_suffix = ""
    if enable_bulk_edit and hasattr(view, "get_bulk_selection_key_suffix"):
        selection_key_suffix = view.get_bulk_selection_key_suffix()

    column_help_text = _resolve_view_option(
        view,
        method_name="get_column_help_text",
        attr_name="column_help_text",
        default={},
    )
    if not isinstance(column_help_text, dict):
        column_help_text = {}
    column_alignments = _resolve_view_option(
        view,
        method_name="get_column_alignments",
        attr_name="column_alignments",
        default={},
    )
    if not isinstance(column_alignments, dict):
        column_alignments = {}

    configured_cell_tooltip_fields = _resolve_view_option(
        view,
        method_name="get_list_cell_tooltip_fields",
        attr_name="list_cell_tooltip_fields",
        default=[],
    )
    if not isinstance(configured_cell_tooltip_fields, list):
        configured_cell_tooltip_fields = []
    rendered_column_names = set(fields) | set(properties)
    eligible_cell_tooltip_fields = {
        field_name
        for field_name in configured_cell_tooltip_fields
        if field_name in rendered_column_names
    }

    # Create header metadata for each field
    headers = []
    for f in fields:
        field = _get_effective_list_field(view, f, queryset=queryset)
        headers.append(
            {
                "label": _get_display_name_for_field(f, field),
                "field_name": f,
                "is_sortable": True,
                "help_text": column_help_text.get(f, ""),
            }
        )

    # Add properties with proper display names (not sortable)
    for prop in properties:
        # Try to get short_description from property
        prop_obj = getattr(view.model, prop, None)
        if (
            prop_obj
            and hasattr(prop_obj.fget, "short_description")
            and prop_obj.fget.short_description
        ):
            display_name = prop_obj.fget.short_description
        else:
            display_name = prop.replace("_", " ").title()
        headers.append(
            {
                "label": display_name,
                "field_name": prop,
                "is_sortable": False,
                "help_text": column_help_text.get(prop, ""),
            }
        )

    TICK_SVG = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="green" class="size-4 inline-block"><path fill-rule="evenodd" d="M8 15A7 7 0 1 0 8 1a7 7 0 0 0 0 14Zm3.844-8.791a.75.75 0 0 0-1.188-.918l-3.7 4.79-1.649-1.833a.75.75 0 1 0-1.114 1.004l2.25 2.5a.75.75 0 0 0 1.15-.043l4.25-5.5Z" clip-rule="evenodd" /></svg>'
    CROSS_SVG = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="crimson" class="size-4 inline-block"><path fill-rule="evenodd" d="M8 15A7 7 0 1 0 8 1a7 7 0 0 0 0 14Zm2.78-4.22a.75.75 0 0 1-1.06 0L8 9.06l-1.72 1.72a.75.75 0 1 1-1.06-1.06L6.94 8 5.22 6.28a.75.75 0 0 1 1.06-1.06L8 6.94l1.72-1.72a.75.75 0 1 1 1.06 1.06L9.06 8l1.72 1.72a.75.75 0 0 1 0 1.06Z" clip-rule="evenodd" /></svg>'

    objects = list(objects)
    bottom_row_count_for_upward_dropdown = _resolve_view_option(
        view,
        method_name="get_extra_actions_dropdown_open_upward_bottom_rows",
        attr_name="extra_actions_dropdown_open_upward_bottom_rows",
        default=3,
    )
    bottom_row_count_for_upward_dropdown = max(
        int(bottom_row_count_for_upward_dropdown or 0), 0
    )
    first_upward_dropdown_index = max(
        len(objects) - bottom_row_count_for_upward_dropdown,
        0,
    )

    object_list = []
    for row_index, obj in enumerate(objects):
        row_id = getattr(view, "get_inline_row_id", None)
        if callable(row_id):
            row_id = row_id(obj)
        else:
            row_id = None

        inline_row_url = None
        if inline_enabled and inline_row_endpoint:
            inline_row_url = view.safe_reverse(
                inline_row_endpoint, kwargs={"pk": obj.pk}
            )

        inline_blocked_reason = None
        inline_blocked_label = None
        inline_blocked_meta = {}
        inline_allowed = False
        action_blocked_reason = None
        action_blocked_label = None
        can_update = getattr(view, "can_update_object", None)
        update_allowed = True
        if callable(can_update):
            try:
                update_allowed = bool(can_update(obj, request))
            except Exception:
                update_allowed = True
        if not update_allowed:
            get_update_reason = getattr(view, "get_update_disabled_reason", None)
            if callable(get_update_reason):
                try:
                    action_blocked_label = get_update_reason(obj, request)
                except Exception:
                    action_blocked_label = None

        if inline_enabled and inline_row_url:
            lock_checker = getattr(view, "is_inline_row_locked", None)
            is_locked = False
            if callable(lock_checker):
                try:
                    is_locked = bool(lock_checker(obj))
                except Exception:
                    is_locked = False

            can_inline_callable = getattr(view, "can_inline_edit", None)
            can_inline = inline_enabled
            if callable(can_inline_callable) and request is not None:
                try:
                    can_inline = bool(can_inline_callable(obj, request))
                except Exception:
                    can_inline = False
            elif not callable(can_inline_callable):
                can_inline = inline_enabled
            else:
                can_inline = False

            if is_locked:
                lock_details = {}
                lock_detail_getter = getattr(view, "get_inline_lock_details", None)
                if callable(lock_detail_getter):
                    try:
                        lock_details = lock_detail_getter(obj) or {}
                    except Exception:
                        lock_details = {}
                inline_blocked_meta = lock_details
                inline_blocked_reason = "locked"
                inline_blocked_label = lock_details.get("label") or _(
                    "Inline editing blocked – record is locked."
                )
                action_blocked_reason = "locked"
                action_blocked_label = inline_blocked_label
            elif not update_allowed:
                inline_blocked_reason = "forbidden"
                inline_blocked_label = action_blocked_label or _(
                    "Editing not permitted for this row."
                )
            elif not can_inline:
                inline_blocked_reason = "forbidden"
                inline_blocked_label = _("Inline editing not permitted for this row.")
            else:
                inline_allowed = True

        row_dependency_endpoint_url = None
        dependency_endpoint_name = inline_config.get("dependency_endpoint_name")
        if inline_enabled and dependency_endpoint_name and getattr(obj, "pk", None):
            row_dependency_endpoint_url = view.safe_reverse(
                dependency_endpoint_name,
                kwargs={"pk": obj.pk},
            ) or view.safe_reverse(dependency_endpoint_name)

        def resolve_cell_dependency(field_name: str):
            dependency = inline_dependencies.get(field_name)
            if not dependency:
                return None
            resolved = dict(dependency)
            endpoint_name = resolved.get("endpoint_name")
            endpoint_url = resolved.get("endpoint_url")
            if endpoint_name and getattr(obj, "pk", None):
                endpoint_url = view.safe_reverse(
                    endpoint_name,
                    kwargs={"pk": obj.pk},
                ) or view.safe_reverse(endpoint_name)
            if not endpoint_url:
                endpoint_url = row_dependency_endpoint_url
            resolved["endpoint_url"] = endpoint_url
            return resolved

        # Attach inline metadata to the object for downstream helpers (e.g., action_links)
        setattr(obj, "_blocked_reason", action_blocked_reason)
        setattr(
            obj,
            "_blocked_label",
            action_blocked_label if action_blocked_reason else None,
        )
        setattr(
            obj,
            "_extra_actions_dropdown_open_upward",
            bottom_row_count_for_upward_dropdown > 0
            and row_index >= first_upward_dropdown_index,
        )

        actions_html = action_links(view, obj)
        has_actions = "data-inline-action=" in str(actions_html)

        record = {
            "object": obj,
            "id": str(obj.pk),  # Add ID for selection tracking
            "is_selected": str(obj.pk) in selected_ids
            if enable_bulk_edit
            else False,  # Check if this object is selected
            "row_id": row_id,
            "inline_url": inline_row_url,
            "inline_allowed": inline_allowed,
            "inline_blocked_reason": inline_blocked_reason,
            "inline_blocked_label": inline_blocked_label,
            "inline_blocked_meta": inline_blocked_meta,
            "cells": [],
            "fields": [],
            "actions": actions_html,
            "has_actions": has_actions,
        }

        for f in fields:
            model_field = _get_model_field_or_none(view, f)
            effective_field = model_field or _get_effective_list_field(
                view,
                f,
                queryset=queryset,
            )
            display_value = _format_list_field_value(
                obj,
                f,
                effective_field,
                TICK_SVG,
                CROSS_SVG,
                is_model_field=model_field is not None,
            )

            if effective_field is not None:
                default_align = (
                    "center" if _should_center_field(effective_field) else "left"
                )
            else:
                raw_value = getattr(obj, f, None)
                default_align = "center" if isinstance(raw_value, bool) else "left"
            cell_align = _resolve_cell_alignment(
                column_alignments=column_alignments,
                name=f,
                default_align=default_align,
            )

            record["cells"].append(
                {
                    "name": f,
                    "value": display_value,
                    "is_property": False,
                    "is_inline_editable": inline_enabled and f in inline_fields,
                    "dependency": resolve_cell_dependency(f),
                    "align": cell_align,
                    "tooltip_text": (
                        _resolve_list_cell_tooltip(
                            view=view,
                            obj=obj,
                            field_name=f,
                            is_property=False,
                            request=request,
                        )
                        if f in eligible_cell_tooltip_fields
                        else None
                    ),
                    "link": _resolve_list_cell_link(
                        view=view,
                        obj=obj,
                        field_name=f,
                        value=display_value,
                        is_property=False,
                        is_inline_editable=inline_enabled and f in inline_fields,
                        request=request,
                    ),
                }
            )
            record["fields"].append(display_value)

        for prop in properties:
            prop_value = getattr(obj, prop)
            default_align = "center" if isinstance(prop_value, bool) else "left"
            prop_align = _resolve_cell_alignment(
                column_alignments=column_alignments,
                name=prop,
                default_align=default_align,
            )
            if (
                isinstance(getattr(obj.__class__, prop), property)
                and prop_value is True
            ):
                display_value = mark_safe(TICK_SVG)
            elif (
                isinstance(getattr(obj.__class__, prop), property)
                and prop_value is False
            ):
                display_value = mark_safe(CROSS_SVG)
            elif isinstance(prop_value, (date, datetime)) and prop_value is not None:
                display_value = prop_value.strftime("%d/%m/%Y")
            else:
                display_value = str(prop_value)

            record["cells"].append(
                {
                    "name": prop,
                    "value": display_value,
                    "is_property": True,
                    "is_inline_editable": inline_enabled and prop in inline_fields,
                    "dependency": resolve_cell_dependency(prop),
                    "align": prop_align,
                    "tooltip_text": (
                        _resolve_list_cell_tooltip(
                            view=view,
                            obj=obj,
                            field_name=prop,
                            is_property=True,
                            request=request,
                        )
                        if prop in eligible_cell_tooltip_fields
                        else None
                    ),
                    "link": _resolve_list_cell_link(
                        view=view,
                        obj=obj,
                        field_name=prop,
                        value=display_value,
                        is_property=True,
                        is_inline_editable=inline_enabled and prop in inline_fields,
                        request=request,
                    ),
                }
            )
            record["fields"].append(display_value)

        object_list.append(record)

    request = context.get("request")
    current_sort = request.GET.get("sort", "") if request else ""

    # Get all current filter parameters
    filter_params = request.GET.copy() if request else {}
    if "sort" in filter_params:
        filter_params.pop("sort")
    if "page" in filter_params:
        filter_params.pop("page")

    # Only keep the last value for each key to avoid duplicate params in URLs
    clean_params = {}
    for k in filter_params:
        clean_params[k] = filter_params.getlist(k)[-1]
    filter_params = filter_params.__class__("", mutable=True)
    for k, v in clean_params.items():
        filter_params[k] = v

    use_htmx = context.get("use_htmx", view.get_use_htmx())
    original_target = context.get("original_target", view.get_original_target())
    htmx_target = context.get("htmx_target", view.get_htmx_target())
    has_row_actions = any(row.get("has_actions") for row in object_list)
    inline_edit_always_visible = False
    if hasattr(view, "get_inline_edit_always_visible"):
        inline_edit_always_visible = view.get_inline_edit_always_visible()

    inline_edit_highlight_palette = {}
    if hasattr(view, "get_inline_edit_highlight_palette"):
        inline_edit_highlight_palette = view.get_inline_edit_highlight_palette()

    return {
        "headers": headers,
        "object_list": object_list,
        "current_sort": current_sort,
        "filter_params": filter_params.urlencode(),  # Add filter parameters to context
        "use_htmx": use_htmx,
        "original_target": original_target,
        "table_pixel_height_other_page_elements": view.get_table_pixel_height_other_page_elements(),
        "table_max_height": view.get_table_max_height(),
        "table_classes": view.get_table_classes(),
        "htmx_target": htmx_target,
        "has_row_actions": has_row_actions,
        "request": request,
        # add bulk selection context
        "selected_ids": selected_ids,
        # Add bulk edit related context
        "enable_bulk_edit": enable_bulk_edit,
        "selected_count": len(selected_ids) if enable_bulk_edit else 0,
        "model_name": view.model.__name__.lower() if hasattr(view, "model") else "",
        "selection_key_suffix": selection_key_suffix,
        "inline_edit": inline_config,
        "inline_edit_always_visible": inline_edit_always_visible,
        "inline_edit_highlight_palette": inline_edit_highlight_palette,
    }


@register.simple_tag
def get_proper_elided_page_range(paginator, number, on_each_side=1, on_ends=1):
    """
    Return a list of page numbers with proper elision for pagination.

    Args:
        paginator: The Django Paginator instance
        number: The current page number
        on_each_side: Number of pages to show on each side of the current page
        on_ends: Number of pages to show at the beginning and end of the range

    Returns:
        list: A list of page numbers and ellipsis characters
    """
    page_range = paginator.get_elided_page_range(
        number=number, on_each_side=1, on_ends=1
    )
    return page_range


@register.simple_tag(takes_context=True)
def extra_buttons(context: Dict[str, Any], view: Any) -> str:
    """
    Generate HTML for extra buttons in the list view header.

    Args:
        context: The template context.
        view: The view instance

    Returns:
        str: HTML string of extra buttons
    """
    framework: str = get_powercrud_setting("POWERCRUD_CSS_FRAMEWORK")
    styles: Dict[str, Any] = view.get_framework_styles()[framework]

    use_htmx: bool = view.get_use_htmx()
    use_modal: bool = view.get_use_modal()
    request = context.get("request") or getattr(view, "request", None)

    extra_buttons: List[Dict[str, Any]] = getattr(view, "extra_buttons", [])
    extra_button_classes = _resolve_view_option(
        view,
        method_name="get_extra_button_classes",
        attr_name="extra_button_classes",
        default="",
    )

    buttons: List[str] = []
    for button in extra_buttons:
        selection_state = _get_selection_button_state(view, request, button)
        display_modal = button.get("display_modal", False) and use_modal
        modal_attrs = ""
        modal_box_attrs = ""
        extra_attrs = button.get("extra_attrs", "")
        extra_class_attrs = button.get("extra_class_attrs", "")

        url: Optional[str] = view.safe_reverse(
            button["url_name"], kwargs={} if not button.get("needs_pk", False) else None
        )
        if url is not None:
            htmx_attrs = []
            if use_htmx:
                if display_modal:
                    htmx_target = _resolve_view_option(
                        view,
                        method_name="get_modal_target",
                        attr_name="modal_target",
                        default="#powercrudModalContent",
                    )
                    if htmx_target and not htmx_target.startswith("#"):
                        htmx_target = f"#{htmx_target}"
                    modal_attrs = styles.get("modal_attrs", "")
                    if button.get("modal_box_classes"):
                        escaped_modal_box_classes = conditional_escape(
                            str(button["modal_box_classes"])
                        )
                        modal_box_attrs = (
                            'data-powercrud-modal-box-classes="'
                            f'{escaped_modal_box_classes}"'
                        )
                else:
                    htmx_target = button.get("htmx_target", "")
                    if htmx_target and not htmx_target.startswith("#"):
                        htmx_target = f"#{htmx_target}"

                htmx_attrs.append(f'hx-get="{url}"')
                if htmx_target:
                    htmx_attrs.append(f'hx-target="{htmx_target}"')
                if use_htmx and not display_modal:
                    htmx_attrs.append('hx-replace-url="true"')
                    htmx_attrs.append('hx-push-url="true"')

            htmx_attrs_str = " ".join(htmx_attrs)

            button_class = button.get("button_class", styles["extra_default"])
            disabled_classes = ""
            disabled_attrs: list[str] = []
            if selection_state["disable"]:
                disabled_classes = " btn-disabled opacity-50 pointer-events-none"
                disabled_attrs.append('aria-disabled="true"')
                if selection_state["disabled_reason"]:
                    disabled_attrs.append(
                        f'data-tippy-content="{selection_state["disabled_reason"]}"'
                    )
                    disabled_attrs.append('data-powercrud-tooltip="semantic"')

            if selection_state["uses_selection"]:
                disabled_attrs.append('data-powercrud-selection-aware="true"')
                disabled_attrs.append(
                    f'data-powercrud-selection-min-count="{selection_state["selection_min_count"]}"'
                )
                disabled_attrs.append(
                    f'data-powercrud-selection-min-behavior="{selection_state["selection_min_behavior"]}"'
                )
                if button.get("selection_min_reason"):
                    disabled_attrs.append(
                        f'data-powercrud-selection-min-reason="{button["selection_min_reason"]}"'
                    )

            new_button = (
                f'<a href="{url}" '
                f'class="{extra_class_attrs} {styles["base"]} {extra_button_classes} {button_class}{disabled_classes}" '
                f"{extra_attrs} {htmx_attrs_str} "
                f"{' '.join(disabled_attrs)} {modal_attrs} {modal_box_attrs}>"
                f"{button['text']}</a>"
            )

            buttons.append(new_button)

    if buttons:
        return mark_safe(" ".join(buttons))
    return ""


@register.simple_tag(takes_context=True)
def get_powercrud_session_data(context, key):
    """
    Get a value from the powercrud session data for the current model.

    Usage in template:
    {% get_powercrud_session_data 'original_template' as template_name %}
    """
    request = context.get("request")
    view = context.get("view")

    if not request or not view:
        return None

    powercrud_data = request.session.get("powercrud", {})
    model_key = view.get_model_session_key()
    model_data = powercrud_data.get(model_key, {})

    return model_data.get(key)
