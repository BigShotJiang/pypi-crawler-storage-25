import datetime as dt
import hashlib
import json
from types import SimpleNamespace

import httpx
import pytest

from fbnconfig import portfolio as pf
from fbnconfig import portfolio_group as pg
from fbnconfig import property as prop
from fbnconfig.properties import PropertyValue

TEST_BASE = "https://foo.lusid.com"


def response_hook(response: httpx.Response):
    response.read()
    response.raise_for_status()


@pytest.mark.respx(base_url=TEST_BASE)
class DescribePortfolioGroupResource:
    client = httpx.Client(base_url=TEST_BASE, event_hooks={"response": [response_hook]})

    def test_create_empty_portfolio_group(self, respx_mock):
        create_mock = respx_mock.post("/api/api/portfoliogroups/test-scope").mock(
            return_value=httpx.Response(200, json={})
        )
        # given a simple portfolio group
        sut = pg.PortfolioGroupResource(
            id="simple-group",
            scope="test-scope",
            code="simple-group",
            display_name="Simple Portfolio Group",
            description="A simple portfolio group for testing",
            created=dt.datetime(2024, 1, 1, 12, 0, 0, tzinfo=dt.timezone.utc),
        )
        # when we create it
        result = sut.create(self.client)
        # then the state is returned with content hash
        assert result == {
            "id": "simple-group",
            "code": "simple-group",
            "scope": "test-scope",
            "content_hash": "c40867e8f1dc5c38450392efe5636e64d8707c2b5dd3f519dc373d7142f45c23",
        }
        # and a create request was sent
        assert json.loads(create_mock.calls[0].request.content) == {
            "code": "simple-group",
            "displayName": "Simple Portfolio Group",
            "description": "A simple portfolio group for testing",
            "created": "2024-01-01T12:00:00+00:00",
            "subGroups": [],
            "values": [],
        }

    def test_create_with_portfolios(self, respx_mock):
        create_mock = respx_mock.post("/api/api/portfoliogroups/test-scope").mock(
            return_value=httpx.Response(200, json={})
        )
        # given a portfolio group with portfolio members
        portfolio = pf.PortfolioResource(
            id="member-portfolio",
            scope="test-scope",
            code="member-portfolio",
            display_name="Member Portfolio",
            description="Portfolio member of group",
            base_currency="USD",
            created=dt.datetime(2024, 1, 1, 12, 0, 0, tzinfo=dt.timezone.utc),
            instrument_scopes=["test-scope"],
        )
        sut = pg.PortfolioGroupResource(
            id="group-with-portfolios",
            scope="test-scope",
            code="group-with-portfolios",
            display_name="Group With Portfolios",
            description="Portfolio group with portfolio members",
            created=dt.datetime(2024, 1, 1, 12, 0, 0, tzinfo=dt.timezone.utc),
            portfolios=[portfolio],
        )
        # when we create it
        result = sut.create(self.client)
        # then the state is returned
        assert result == {
            "id": "group-with-portfolios",
            "code": "group-with-portfolios",
            "scope": "test-scope",
            "content_hash": "8bfb30edab88e8ba7d3971a892728bda90e9554dac6d018ee108bafd8676697f",
        }
        # and a create request was sent with portfolio references
        assert json.loads(create_mock.calls[0].request.content) == {
            "code": "group-with-portfolios",
            "displayName": "Group With Portfolios",
            "description": "Portfolio group with portfolio members",
            "created": "2024-01-01T12:00:00+00:00",
            "subGroups": [],
            "values": [{"scope": "test-scope", "code": "member-portfolio"}],
        }

    def test_read_portfolio_group(self, respx_mock):
        respx_mock.get("/api/api/portfoliogroups/test-scope/read-group").mock(
            return_value=httpx.Response(
                200,
                json={
                    "id": {"scope": "test-scope", "code": "read-group"},
                    "displayName": "Read Group",
                    "description": "Group for read testing",
                    "created": "2024-01-01T12:00:00+00:00",
                    "portfolios": [],
                    "subGroups": [],
                    "version": {"effectiveFrom": "2024-01-01T12:00:00+00:00"},
                    "links": [],
                },
            )
        )
        # given a portfolio group resource
        sut = pg.PortfolioGroupResource(
            id="read-group",
            scope="test-scope",
            code="read-group",
            display_name="Read Group",
            description="Group for read testing",
            created=dt.datetime(2024, 1, 1, 12, 0, 0, tzinfo=dt.timezone.utc),
        )
        old_state = SimpleNamespace(scope="test-scope", code="read-group")
        # when we read it
        result = sut.read(self.client, old_state)
        # then the group data is returned without version and links
        assert result == {
            "id": {"scope": "test-scope", "code": "read-group"},
            "displayName": "Read Group",
            "description": "Group for read testing",
            "created": "2024-01-01T12:00:00+00:00",
            "portfolios": [],
            "subGroups": [],
        }

    def test_update_portfolio_group_no_change(self):
        sut = pg.PortfolioGroupResource(
            id="no-change-group",
            scope="test-scope",
            code="no-change-group",
            display_name="No Change Group",
            description="Group with no changes",
            created=dt.datetime(2024, 1, 1, 12, 0, 0, tzinfo=dt.timezone.utc),
        )
        desired = sut.model_dump(
            mode="json", by_alias=True, exclude_none=True,
            exclude={"portfolios", "scope"},
        )
        sorted_desired = json.dumps(desired, sort_keys=True)
        content_hash = hashlib.sha256(sorted_desired.encode()).hexdigest()
        old_state = SimpleNamespace(
            scope="test-scope", code="no-change-group", content_hash=content_hash
        )
        result = sut.update(self.client, old_state)
        assert result is None

    def test_update_display_name(self, respx_mock):
        respx_mock.get("/api/api/portfoliogroups/test-scope/update-group").mock(
            return_value=httpx.Response(200, json={
                "id": {"scope": "test-scope", "code": "update-group"},
                "displayName": "Old Name",
                "description": "Same description",
                "created": "2024-01-01T12:00:00+00:00",
                "portfolios": [],
                "subGroups": [],
                "version": {}, "links": [],
            })
        )
        respx_mock.put("/api/api/portfoliogroups/test-scope/update-group").mock(
            return_value=httpx.Response(200, json={})
        )
        sut = pg.PortfolioGroupResource(
            id="update-group", scope="test-scope", code="update-group",
            display_name="New Name", description="Same description",
            created=dt.datetime(2024, 1, 1, 12, 0, 0, tzinfo=dt.timezone.utc),
        )
        old_state = SimpleNamespace(scope="test-scope", code="update-group", content_hash="old-hash")
        result = sut.update(self.client, old_state)
        assert result
        put_req = [c for c in respx_mock.calls if c.request.method == "PUT"]
        assert len(put_req) == 1
        assert json.loads(put_req[0].request.content) == {"displayName": "New Name"}

    def test_update_description(self, respx_mock):
        respx_mock.get("/api/api/portfoliogroups/test-scope/update-group").mock(
            return_value=httpx.Response(200, json={
                "id": {"scope": "test-scope", "code": "update-group"},
                "displayName": "Same Name",
                "description": "Old description",
                "created": "2024-01-01T12:00:00+00:00",
                "portfolios": [], "subGroups": [],
                "version": {}, "links": [],
            })
        )
        respx_mock.put("/api/api/portfoliogroups/test-scope/update-group").mock(
            return_value=httpx.Response(200, json={})
        )
        sut = pg.PortfolioGroupResource(
            id="update-group", scope="test-scope", code="update-group",
            display_name="Same Name", description="New description",
            created=dt.datetime(2024, 1, 1, 12, 0, 0, tzinfo=dt.timezone.utc),
        )
        old_state = SimpleNamespace(scope="test-scope", code="update-group", content_hash="old-hash")
        result = sut.update(self.client, old_state)
        assert result
        put_req = [c for c in respx_mock.calls if c.request.method == "PUT"]
        assert len(put_req) == 1
        assert json.loads(put_req[0].request.content) == {
            "displayName": "Same Name", "description": "New description",
        }

    def test_update_add_portfolio(self, respx_mock):
        respx_mock.get("/api/api/portfoliogroups/test-scope/update-group").mock(
            return_value=httpx.Response(200, json={
                "id": {"scope": "test-scope", "code": "update-group"},
                "displayName": "Group", "description": "Desc",
                "created": "2024-01-01T12:00:00+00:00",
                "portfolios": [],
                "subGroups": [],
                "version": {}, "links": [],
            })
        )
        respx_mock.post("/api/api/portfoliogroups/test-scope/update-group/portfolios").mock(
            return_value=httpx.Response(201, json={})
        )
        portfolio = pf.PortfolioRef(id="pf1", scope="pf-scope", code="pf-code")
        sut = pg.PortfolioGroupResource(
            id="update-group", scope="test-scope", code="update-group",
            display_name="Group", description="Desc",
            created=dt.datetime(2024, 1, 1, 12, 0, 0, tzinfo=dt.timezone.utc),
            portfolios=[portfolio],
        )
        old_state = SimpleNamespace(scope="test-scope", code="update-group", content_hash="old-hash")
        result = sut.update(self.client, old_state)
        assert result
        post_reqs = [c for c in respx_mock.calls if c.request.method == "POST"]
        assert len(post_reqs) == 1
        assert json.loads(post_reqs[0].request.content) == {"scope": "pf-scope", "code": "pf-code"}

    def test_update_remove_portfolio(self, respx_mock):
        respx_mock.get("/api/api/portfoliogroups/test-scope/update-group").mock(
            return_value=httpx.Response(200, json={
                "id": {"scope": "test-scope", "code": "update-group"},
                "displayName": "Group", "description": "Desc",
                "created": "2024-01-01T12:00:00+00:00",
                "portfolios": [{"scope": "pf-scope", "code": "pf-code"}],
                "subGroups": [],
                "version": {}, "links": [],
            })
        )
        respx_mock.delete(
            "/api/api/portfoliogroups/test-scope/update-group/portfolios/pf-scope/pf-code"
        ).mock(return_value=httpx.Response(200, json={}))
        sut = pg.PortfolioGroupResource(
            id="update-group", scope="test-scope", code="update-group",
            display_name="Group", description="Desc",
            created=dt.datetime(2024, 1, 1, 12, 0, 0, tzinfo=dt.timezone.utc),
            portfolios=[],
        )
        old_state = SimpleNamespace(scope="test-scope", code="update-group", content_hash="old-hash")
        result = sut.update(self.client, old_state)
        assert result
        del_reqs = [c for c in respx_mock.calls if c.request.method == "DELETE"]
        assert len(del_reqs) == 1
        expected = "/api/api/portfoliogroups/test-scope/update-group/portfolios/pf-scope/pf-code"
        assert del_reqs[0].request.url.path == expected

    def test_update_add_and_remove_portfolios(self, respx_mock):
        respx_mock.get("/api/api/portfoliogroups/test-scope/update-group").mock(
            return_value=httpx.Response(200, json={
                "id": {"scope": "test-scope", "code": "update-group"},
                "displayName": "Group", "description": "Desc",
                "created": "2024-01-01T12:00:00+00:00",
                "portfolios": [{"scope": "s", "code": "old-pf"}],
                "subGroups": [],
                "version": {}, "links": [],
            })
        )
        respx_mock.post("/api/api/portfoliogroups/test-scope/update-group/portfolios").mock(
            return_value=httpx.Response(201, json={})
        )
        respx_mock.delete(
            "/api/api/portfoliogroups/test-scope/update-group/portfolios/s/old-pf"
        ).mock(return_value=httpx.Response(200, json={}))
        new_pf = pf.PortfolioRef(id="pf2", scope="s", code="new-pf")
        sut = pg.PortfolioGroupResource(
            id="update-group", scope="test-scope", code="update-group",
            display_name="Group", description="Desc",
            created=dt.datetime(2024, 1, 1, 12, 0, 0, tzinfo=dt.timezone.utc),
            portfolios=[new_pf],
        )
        old_state = SimpleNamespace(scope="test-scope", code="update-group", content_hash="old-hash")
        result = sut.update(self.client, old_state)
        assert result
        post_reqs = [c for c in respx_mock.calls if c.request.method == "POST"]
        del_reqs = [c for c in respx_mock.calls if c.request.method == "DELETE"]
        assert len(post_reqs) == 1
        assert len(del_reqs) == 1

    def test_update_add_sub_group(self, respx_mock):
        respx_mock.get("/api/api/portfoliogroups/test-scope/update-group").mock(
            return_value=httpx.Response(200, json={
                "id": {"scope": "test-scope", "code": "update-group"},
                "displayName": "Group", "description": "Desc",
                "created": "2024-01-01T12:00:00+00:00",
                "portfolios": [], "subGroups": [],
                "version": {}, "links": [],
            })
        )
        respx_mock.post("/api/api/portfoliogroups/test-scope/update-group/subgroups").mock(
            return_value=httpx.Response(201, json={})
        )
        sub = pg.PortfolioGroupRef(id="sg1", scope="sg-scope", code="sg-code")
        sut = pg.PortfolioGroupResource(
            id="update-group", scope="test-scope", code="update-group",
            display_name="Group", description="Desc",
            created=dt.datetime(2024, 1, 1, 12, 0, 0, tzinfo=dt.timezone.utc),
            sub_groups=[sub],
        )
        old_state = SimpleNamespace(scope="test-scope", code="update-group", content_hash="old-hash")
        result = sut.update(self.client, old_state)
        assert result
        post_reqs = [c for c in respx_mock.calls if c.request.method == "POST"]
        assert len(post_reqs) == 1
        assert json.loads(post_reqs[0].request.content) == {"scope": "sg-scope", "code": "sg-code"}

    def test_update_remove_sub_group(self, respx_mock):
        respx_mock.get("/api/api/portfoliogroups/test-scope/update-group").mock(
            return_value=httpx.Response(200, json={
                "id": {"scope": "test-scope", "code": "update-group"},
                "displayName": "Group", "description": "Desc",
                "created": "2024-01-01T12:00:00+00:00",
                "portfolios": [],
                "subGroups": [{"scope": "sg-scope", "code": "sg-code"}],
                "version": {}, "links": [],
            })
        )
        respx_mock.delete(
            "/api/api/portfoliogroups/test-scope/update-group/subgroups/sg-scope/sg-code"
        ).mock(return_value=httpx.Response(200, json={}))
        sut = pg.PortfolioGroupResource(
            id="update-group", scope="test-scope", code="update-group",
            display_name="Group", description="Desc",
            created=dt.datetime(2024, 1, 1, 12, 0, 0, tzinfo=dt.timezone.utc),
            sub_groups=[],
        )
        old_state = SimpleNamespace(scope="test-scope", code="update-group", content_hash="old-hash")
        result = sut.update(self.client, old_state)
        assert result
        del_reqs = [c for c in respx_mock.calls if c.request.method == "DELETE"]
        assert len(del_reqs) == 1
        assert "/subgroups/sg-scope/sg-code" in del_reqs[0].request.url.path

    def test_update_scope_code_changed(self, respx_mock):
        delete_mock = respx_mock.delete("/api/api/portfoliogroups/old-scope/old-code").mock(
            return_value=httpx.Response(200, json={})
        )
        create_mock = respx_mock.post("/api/api/portfoliogroups/test-scope").mock(
            return_value=httpx.Response(200, json={})
        )
        sut = pg.PortfolioGroupResource(
            id="update-group", scope="test-scope", code="new-code",
            display_name="Group", description="Desc",
            created=dt.datetime(2024, 1, 1, 12, 0, 0, tzinfo=dt.timezone.utc),
        )
        old_state = SimpleNamespace(scope="old-scope", code="old-code", content_hash="old-hash")
        # when we update with a different scope/code
        result = sut.update(self.client, old_state)
        # then the old group is deleted
        assert len(delete_mock.calls) == 1
        assert delete_mock.calls[0].request.url.path == "/api/api/portfoliogroups/old-scope/old-code"
        # and the new group is created
        assert len(create_mock.calls) == 1
        assert json.loads(create_mock.calls[0].request.content) == {
            "code": "new-code",
            "displayName": "Group",
            "description": "Desc",
            "created": "2024-01-01T12:00:00+00:00",
            "values": [],
            "subGroups": [],
        }
        assert result == {
            "id": "update-group",
            "code": "new-code",
            "scope": "test-scope",
            "content_hash": "ec4fd925a0a5b89cddd53eb21cfce8349a1c1a27011e18fb968ed5c2695ed309",
        }

    def test_update_multiple_changes(self, respx_mock):
        respx_mock.get("/api/api/portfoliogroups/test-scope/update-group").mock(
            return_value=httpx.Response(200, json={
                "id": {"scope": "test-scope", "code": "update-group"},
                "displayName": "Old Name", "description": "Desc",
                "created": "2024-01-01T12:00:00+00:00",
                "portfolios": [], "subGroups": [],
                "version": {}, "links": [],
            })
        )
        respx_mock.put("/api/api/portfoliogroups/test-scope/update-group").mock(
            return_value=httpx.Response(200, json={})
        )
        respx_mock.post("/api/api/portfoliogroups/test-scope/update-group/portfolios").mock(
            return_value=httpx.Response(201, json={})
        )
        portfolio = pf.PortfolioRef(id="pf1", scope="pf-scope", code="pf-code")
        sut = pg.PortfolioGroupResource(
            id="update-group", scope="test-scope", code="update-group",
            display_name="New Name", description="Desc",
            created=dt.datetime(2024, 1, 1, 12, 0, 0, tzinfo=dt.timezone.utc),
            portfolios=[portfolio],
        )
        old_state = SimpleNamespace(scope="test-scope", code="update-group", content_hash="old-hash")
        result = sut.update(self.client, old_state)
        assert result
        put_reqs = [c for c in respx_mock.calls if c.request.method == "PUT"]
        post_reqs = [c for c in respx_mock.calls if c.request.method == "POST"]
        assert len(put_reqs) == 1
        assert len(post_reqs) == 1

    def test_delete_portfolio_group(self, respx_mock):
        delete_mock = respx_mock.delete("/api/api/portfoliogroups/test-scope/delete-group").mock(
            return_value=httpx.Response(200, json={})
        )
        old_state = SimpleNamespace(scope="test-scope", code="delete-group")
        # when we delete it
        pg.PortfolioGroupResource.delete(self.client, old_state)
        # then a DELETE request is sent to the correct path
        assert len(delete_mock.calls) == 1
        path = "/api/api/portfoliogroups/test-scope/delete-group"
        assert delete_mock.calls[0].request.url.path == path

    def test_portfolio_group_deps_with_portfolios(self):
        portfolio = pf.PortfolioResource(
            id="member-portfolio",
            scope="test-scope",
            code="member-portfolio",
            display_name="Member Portfolio",
            description="Portfolio member of group",
            base_currency="USD",
            created=dt.datetime(2024, 1, 1, 12, 0, 0, tzinfo=dt.timezone.utc),
            instrument_scopes=["test-scope"],
        )
        sub = pg.PortfolioGroupRef(id="sg1", scope="sg-scope", code="sg-code")
        sut = pg.PortfolioGroupResource(
            id="deps-group",
            scope="test-scope",
            code="deps-group",
            display_name="Dependencies Group",
            description="Group with dependencies",
            created=dt.datetime(2024, 1, 1, 12, 0, 0, tzinfo=dt.timezone.utc),
            portfolios=[portfolio],
            sub_groups=[sub],
        )
        deps = sut.deps()
        assert deps == [portfolio, sub]


def _make_group(scope="test-scope", code="g1"):
    return pg.PortfolioGroupResource(
        id="g1", scope=scope, code=code,
        display_name="G1", description="Test group",
        created=dt.datetime(2024, 1, 1, 12, 0, 0, tzinfo=dt.timezone.utc),
    )


def _make_prop_def(scope="test-scope", code="rating"):
    return prop.DefinitionRef(
        id=f"prop-{code}", domain=prop.Domain.PortfolioGroup, scope=scope, code=code,
    )


@pytest.mark.respx(base_url=TEST_BASE)
class DescribePortfolioGroupPropertiesResource:
    client = httpx.Client(base_url=TEST_BASE, event_hooks={"response": [response_hook]})

    def test_create_with_label_property(self, respx_mock):
        upsert_mock = respx_mock.post(
            "/api/api/portfoliogroups/test-scope/g1/properties/$upsert"
        ).mock(return_value=httpx.Response(200, json={}))
        # given a group properties resource with a label property
        group = _make_group()
        prop_def = _make_prop_def()
        sut = pg.PortfolioGroupPropertiesResource(
            id="g1-props", portfolio_group=group,
            properties=[PropertyValue(property_key=prop_def, label_value="AAA")],
        )
        # when we create it
        result = sut.create(self.client)
        # then the state is returned with scope, code, and content_hash
        assert result == {
            "scope": "test-scope",
            "code": "g1",
            "content_hash": "761e68da89c89b72a9010b231fdfe2d112d63755b988e7f259f921f77b3873d5",
        }
        # and an upsert request was sent with the property
        assert len(upsert_mock.calls) == 1
        assert json.loads(upsert_mock.calls[0].request.content) == {
            "PortfolioGroup/test-scope/rating": {
                "key": "PortfolioGroup/test-scope/rating",
                "value": {"labelValue": "AAA"},
            },
        }

    def test_create_empty_properties(self, respx_mock):
        # given a group properties resource with no properties
        group = _make_group()
        sut = pg.PortfolioGroupPropertiesResource(
            id="g1-props", portfolio_group=group, properties=[],
        )
        # when we create it
        result = sut.create(self.client)
        # then the state is returned but no API call is made
        assert result == {
            "scope": "test-scope",
            "code": "g1",
            "content_hash": "44136fa355b3678a1146ad16f7e8649e94fb4fc21fe77e8310c060f61caaff8a",
        }
        assert len(respx_mock.calls) == 0

    def test_update_no_change(self, respx_mock):
        # given a group properties resource with a matching content_hash
        group = _make_group()
        prop_def = _make_prop_def()
        sut = pg.PortfolioGroupPropertiesResource(
            id="g1-props", portfolio_group=group,
            properties=[PropertyValue(property_key=prop_def, label_value="AAA")],
        )
        desired = sut._serialize_properties()
        content_hash = hashlib.sha256(json.dumps(desired, sort_keys=True).encode()).hexdigest()
        old_state = SimpleNamespace(scope="test-scope", code="g1", content_hash=content_hash)
        # when we update it
        result = sut.update(self.client, old_state)
        # then no change is detected
        assert result is None

    def test_update_add_property(self, respx_mock):
        respx_mock.get("/api/api/portfoliogroups/test-scope/g1/properties").mock(
            return_value=httpx.Response(200, json={"properties": {}})
        )
        upsert_mock = respx_mock.post(
            "/api/api/portfoliogroups/test-scope/g1/properties/$upsert"
        ).mock(return_value=httpx.Response(200, json={}))
        # given a group with no remote properties
        group = _make_group()
        prop_def = _make_prop_def()
        sut = pg.PortfolioGroupPropertiesResource(
            id="g1-props", portfolio_group=group,
            properties=[PropertyValue(property_key=prop_def, label_value="AAA")],
        )
        old_state = SimpleNamespace(scope="test-scope", code="g1", content_hash="old")
        # when we update with a new property
        result = sut.update(self.client, old_state)
        # then the property is upserted
        assert result == {
            "scope": "test-scope",
            "code": "g1",
            "content_hash": "761e68da89c89b72a9010b231fdfe2d112d63755b988e7f259f921f77b3873d5",
        }
        assert len(upsert_mock.calls) == 1

    def test_update_remove_property(self, respx_mock):
        respx_mock.get("/api/api/portfoliogroups/test-scope/g1/properties").mock(
            return_value=httpx.Response(200, json={"properties": {
                "PortfolioGroup/test-scope/rating": {
                    "key": "PortfolioGroup/test-scope/rating",
                    "value": {"labelValue": "AAA"},
                },
            }})
        )
        delete_mock = respx_mock.post(
            "/api/api/portfoliogroups/test-scope/g1/properties/$delete"
        ).mock(return_value=httpx.Response(200, json={}))
        # given a group with a remote property but no desired properties
        group = _make_group()
        sut = pg.PortfolioGroupPropertiesResource(
            id="g1-props", portfolio_group=group, properties=[],
        )
        old_state = SimpleNamespace(scope="test-scope", code="g1", content_hash="old")
        # when we update it
        result = sut.update(self.client, old_state)
        # then the remote property is deleted
        assert result == {
            "scope": "test-scope",
            "code": "g1",
            "content_hash": "44136fa355b3678a1146ad16f7e8649e94fb4fc21fe77e8310c060f61caaff8a",
        }
        assert len(delete_mock.calls) == 1
        assert json.loads(delete_mock.calls[0].request.content) == [
            "PortfolioGroup/test-scope/rating",
        ]

    def test_update_change_value(self, respx_mock):
        respx_mock.get("/api/api/portfoliogroups/test-scope/g1/properties").mock(
            return_value=httpx.Response(200, json={"properties": {
                "PortfolioGroup/test-scope/rating": {
                    "key": "PortfolioGroup/test-scope/rating",
                    "value": {"labelValue": "AAA"},
                },
            }})
        )
        upsert_mock = respx_mock.post(
            "/api/api/portfoliogroups/test-scope/g1/properties/$upsert"
        ).mock(return_value=httpx.Response(200, json={}))
        # given a group with rating=AAA remotely
        group = _make_group()
        prop_def = _make_prop_def()
        sut = pg.PortfolioGroupPropertiesResource(
            id="g1-props", portfolio_group=group,
            properties=[PropertyValue(property_key=prop_def, label_value="BBB")],
        )
        old_state = SimpleNamespace(scope="test-scope", code="g1", content_hash="old")
        # when we update with rating=BBB
        result = sut.update(self.client, old_state)
        # then the changed value is upserted
        assert result == {
            "scope": "test-scope",
            "code": "g1",
            "content_hash": "c539378aacba3ba9266172640768d99d40d4e067c4cfad2788bec3b94f02457a",
        }
        assert len(upsert_mock.calls) == 1

    def test_update_scope_code_changed(self, respx_mock):
        get_mock = respx_mock.get("/api/api/portfoliogroups/old-scope/old-code/properties").mock(
            return_value=httpx.Response(200, json={"properties": {
                "PortfolioGroup/old-scope/rating": {
                    "key": "PortfolioGroup/old-scope/rating",
                    "value": {"labelValue": "AAA"},
                },
            }})
        )
        delete_mock = respx_mock.post(
            "/api/api/portfoliogroups/old-scope/old-code/properties/$delete"
        ).mock(return_value=httpx.Response(200, json={}))
        upsert_mock = respx_mock.post(
            "/api/api/portfoliogroups/test-scope/g1/properties/$upsert"
        ).mock(return_value=httpx.Response(200, json={}))
        # given properties on old-scope/old-code
        group = _make_group()
        prop_def = _make_prop_def()
        sut = pg.PortfolioGroupPropertiesResource(
            id="g1-props", portfolio_group=group,
            properties=[PropertyValue(property_key=prop_def, label_value="AAA")],
        )
        old_state = SimpleNamespace(scope="old-scope", code="old-code", content_hash="old")
        # when we update with a different scope/code
        result = sut.update(self.client, old_state)
        # then old properties are deleted from old-scope/old-code
        assert len(get_mock.calls) == 1
        assert len(delete_mock.calls) == 1
        assert json.loads(delete_mock.calls[0].request.content) == [
            "PortfolioGroup/old-scope/rating",
        ]
        # and new properties are created on test-scope/g1
        assert len(upsert_mock.calls) == 1
        assert json.loads(upsert_mock.calls[0].request.content) == {
            "PortfolioGroup/test-scope/rating": {
                "key": "PortfolioGroup/test-scope/rating",
                "value": {"labelValue": "AAA"},
            },
        }
        # and the result points to the new scope/code
        assert result == {
            "scope": "test-scope",
            "code": "g1",
            "content_hash": "761e68da89c89b72a9010b231fdfe2d112d63755b988e7f259f921f77b3873d5",
        }

    def test_delete(self, respx_mock):
        get_mock = respx_mock.get("/api/api/portfoliogroups/test-scope/g1/properties").mock(
            return_value=httpx.Response(200, json={"properties": {
                "PortfolioGroup/test-scope/rating": {
                    "key": "PortfolioGroup/test-scope/rating",
                    "value": {"labelValue": "AAA"},
                },
            }})
        )
        delete_mock = respx_mock.post(
            "/api/api/portfoliogroups/test-scope/g1/properties/$delete"
        ).mock(return_value=httpx.Response(200, json={}))
        # given a group with a remote property
        old_state = SimpleNamespace(scope="test-scope", code="g1")
        # when we delete it
        pg.PortfolioGroupPropertiesResource.delete(self.client, old_state)
        # then remote properties are read first
        assert len(get_mock.calls) == 1
        # and a delete request is sent with the property keys
        assert len(delete_mock.calls) == 1
        delete_body = json.loads(delete_mock.calls[0].request.content)
        assert delete_body == ["PortfolioGroup/test-scope/rating"]

    def test_delete_no_properties(self, respx_mock):
        respx_mock.get("/api/api/portfoliogroups/test-scope/g1/properties").mock(
            return_value=httpx.Response(200, json={"properties": {}})
        )
        # given a group with no remote properties
        old_state = SimpleNamespace(scope="test-scope", code="g1")
        # when we delete it
        pg.PortfolioGroupPropertiesResource.delete(self.client, old_state)
        # then no delete call is made
        assert len(respx_mock.calls) == 1  # only the GET

    def test_delete_group_not_found(self, respx_mock):
        respx_mock.get("/api/api/portfoliogroups/test-scope/g1/properties").mock(
            return_value=httpx.Response(404)
        )
        # given the group no longer exists
        old_state = SimpleNamespace(scope="test-scope", code="g1")
        # when we delete it, then a 404 error is raised
        with pytest.raises(httpx.HTTPStatusError) as exc_info:
            pg.PortfolioGroupPropertiesResource.delete(self.client, old_state)
        assert exc_info.value.response.status_code == 404

    def test_deps(self):
        # given a group properties resource with a property
        group = _make_group()
        prop_def = _make_prop_def()
        sut = pg.PortfolioGroupPropertiesResource(
            id="g1-props", portfolio_group=group,
            properties=[PropertyValue(property_key=prop_def, label_value="AAA")],
        )
        # when we get dependencies
        deps = sut.deps()
        # then the group and property definition are included
        assert group in deps
        assert prop_def in deps

    def test_update_with_group_ref(self, respx_mock):
        respx_mock.get("/api/api/portfoliogroups/test-scope/g1/properties").mock(
            return_value=httpx.Response(200, json={"properties": {}})
        )
        upsert_mock = respx_mock.post(
            "/api/api/portfoliogroups/test-scope/g1/properties/$upsert"
        ).mock(return_value=httpx.Response(200, json={}))
        # given a group ref (not a managed resource)
        ref = pg.PortfolioGroupRef(id="g1-ref", scope="test-scope", code="g1")
        prop_def = _make_prop_def()
        sut = pg.PortfolioGroupPropertiesResource(
            id="g1-props", portfolio_group=ref,
            properties=[PropertyValue(property_key=prop_def, label_value="AAA")],
        )
        old_state = SimpleNamespace(scope="test-scope", code="g1", content_hash="old")
        # when we update it
        result = sut.update(self.client, old_state)
        # then a normal update is performed (no recreate detection for refs)
        assert result is not None
        assert len(upsert_mock.calls) == 1

    def test_dump(self):
        # given a group properties resource with a label property
        group = _make_group()
        prop_def = _make_prop_def()
        sut = pg.PortfolioGroupPropertiesResource(
            id="g1-props", portfolio_group=group,
            properties=[PropertyValue(property_key=prop_def, label_value="AAA")],
        )
        # when we dump it
        dumped = sut.model_dump(
            by_alias=True, round_trip=True, exclude_none=True, context={"style": "dump"},
        )
        # then we get the full dump with $refs and no id
        assert dumped == {
            "portfolioGroup": {"$ref": "g1"},
            "properties": [{"propertyKey": {"$ref": "prop-rating"}, "labelValue": "AAA"}],
        }

    def test_undump(self):
        # given a dumped group properties state with $refs
        group = _make_group()
        prop_def = _make_prop_def()
        dumped = {
            "portfolioGroup": {"$ref": "g1"},
            "properties": [{"propertyKey": {"$ref": "prop-rating"}, "labelValue": "AAA"}],
        }
        # when we undump it with resolved refs
        refs = {"g1": group, "prop-rating": prop_def}
        sut = pg.PortfolioGroupPropertiesResource.model_validate(
            dumped, context={"style": "dump", "$refs": refs, "id": "g1-props"},
        )
        # then the refs are wired up to the original objects
        assert sut.id == "g1-props"
        assert sut.portfolio_group is group
        assert len(sut.properties) == 1
        assert sut.properties[0].label_value == "AAA"
        assert sut.properties[0].property_key is prop_def
