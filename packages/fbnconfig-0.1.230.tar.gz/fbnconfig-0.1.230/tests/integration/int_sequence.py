import os
from types import SimpleNamespace

import pytest
from pytest import fixture

import fbnconfig
from fbnconfig import sequence as seq
from tests.integration.generate_test_name import gen


@fixture(scope="module")
def lusid_env():
    if os.getenv("FBN_ACCESS_TOKEN") is None or os.getenv("LUSID_ENV") is None:
        raise (
            RuntimeError("FBN_ACCESS_TOKEN and LUSID_ENV variables need to be set to run these tests")
        )
    env = os.environ["LUSID_ENV"]
    token = os.environ["FBN_ACCESS_TOKEN"]
    return SimpleNamespace(env=env, token=token)


@fixture(scope="module")
def client(lusid_env):
    return fbnconfig.create_client(lusid_env.env, lusid_env.token)


@fixture
def base_resources(setup_deployment):
    name = setup_deployment.name
    return [
        seq.SequenceResource(id="seq1", scope=name, code="seq1"),
        seq.SequenceResource(id="seq2", scope=name, code="seq2", increment=2),
        seq.SequenceResource(id="seq3", scope=name, code="seq3", increment=5),
    ]


@fixture
def setup_deployment(lusid_env):
    deployment_name = gen("sequence")
    print(f"\nRunning for deployment {deployment_name}...")
    yield SimpleNamespace(name=deployment_name)
    # Clean up sequences after tests
    try:
        print("\nTearing down resources...")
        fbnconfig.deployex(fbnconfig.Deployment(deployment_name, []), lusid_env.env, lusid_env.token)
    except Exception:
        pass


def test_create(setup_deployment, base_resources, client, lusid_env):
    dep = fbnconfig.Deployment(setup_deployment.name, base_resources)
    fbnconfig.deployex(dep, lusid_env.env, lusid_env.token)
    resp = client.get(f"/api/api/sequences/{setup_deployment.name}/seq1").json()
    assert resp["id"]["scope"] == setup_deployment.name
    assert resp["id"]["code"] == "seq1"


def test_nochange(setup_deployment, base_resources, lusid_env):
    deployment = fbnconfig.Deployment(setup_deployment.name, base_resources)
    fbnconfig.deployex(deployment, lusid_env.env, lusid_env.token)
    update = fbnconfig.deployex(deployment, lusid_env.env, lusid_env.token)
    changes = [a.change for a in update if a.type == "SequenceResource"]
    assert changes == ["nochange", "nochange", "nochange"]


def test_teardown(setup_deployment, base_resources, lusid_env):
    deployment_name = setup_deployment.name
    # given we have deployed the base case
    dep = fbnconfig.Deployment(setup_deployment.name, base_resources)
    fbnconfig.deployex(dep, lusid_env.env, lusid_env.token)
    # when we remove all the resources
    empty = fbnconfig.Deployment(deployment_name, [])
    update = fbnconfig.deployex(empty, lusid_env.env, lusid_env.token)
    # then all the sequences get removed
    seq_changes = [a.change for a in update if a.type == "SequenceResource"]
    assert seq_changes == ["remove", "remove", "remove"]


def test_update_scope(setup_deployment, base_resources, client, lusid_env):
    deployment_name = setup_deployment.name
    new_scope = deployment_name + "-moved"
    # given we have deployed the base case
    dep = fbnconfig.Deployment(setup_deployment.name, base_resources)
    fbnconfig.deployex(dep, lusid_env.env, lusid_env.token)
    # when we move seq1 to a new scope
    updated_resources = [
        seq.SequenceResource(id="seq1", scope=new_scope, code="seq1"),
        seq.SequenceResource(id="seq2", scope=deployment_name, code="seq2", increment=2),
        seq.SequenceResource(id="seq3", scope=deployment_name, code="seq3", increment=5),
    ]
    dep = fbnconfig.Deployment(setup_deployment.name, updated_resources)
    update = fbnconfig.deployex(dep, lusid_env.env, lusid_env.token)
    # then we expect only the moved resource to change
    seq_changes = [a.change for a in update if a.type == "SequenceResource"]
    assert seq_changes == ["update", "nochange", "nochange"]
    # and the new sequence exists at the new scope
    new_resp = client.get(f"/api/api/sequences/{new_scope}/seq1").json()
    assert new_resp["id"]["scope"] == new_scope
    assert new_resp["id"]["code"] == "seq1"
    # clean up the moved sequence
    client.request("DELETE", f"/api/api/sequences/{new_scope}/seq1")


@pytest.mark.asyncio
async def test_sequence_list_with_filter(setup_deployment, base_resources, lusid_env):
    # GIVEN Sequence is deployed
    dep = fbnconfig.Deployment(setup_deployment.name, base_resources)
    fbnconfig.deployex(dep, lusid_env.env, lusid_env.token)
    scope = setup_deployment.name
    code = "seq1"
    async_client = fbnconfig.create_client(lusid_env.env, lusid_env.token, is_async=True)
    # WHEN calling list with filter for the deployment name
    result = await seq.SequenceResource.list(
        client=async_client,
        query_params={"filter": f"id.code eq '{code}' and id.scope eq '{scope}'"},
        path_params={}
    )
    # THEN the result has correct structure
    expected_result = {
        "values": [
            {
                "keys": {
                    "code": code,
                    "scope": scope
                },
                "value": {
                    "id": f"sequence_{scope}_{code}".lower(),
                    "code": code,
                    "scope": scope,
                    "cycle": False,
                    "increment": 1,
                    "start": 1,
                    "minValue": 1,
                    "maxValue": 9223372036854775807,
                }
            }
        ]
    }
    assert result == expected_result


@pytest.mark.asyncio
async def test_sequence_fetch(setup_deployment, base_resources, lusid_env):
    # GIVEN Sequence is deployed
    dep = fbnconfig.Deployment(setup_deployment.name, base_resources)
    fbnconfig.deployex(dep, lusid_env.env, lusid_env.token)
    scope = setup_deployment.name
    code = "seq1"
    async_client = fbnconfig.create_client(lusid_env.env, lusid_env.token, is_async=True)
    # WHEN the fetch method is called for that resource
    response = await seq.SequenceResource.fetch(
        client=async_client,
        keys={
            "code": code,
            "scope": scope
        }
    )
    # THEN the response is as expected
    expected_response = {
        "id": f"sequence_{scope}_{code}".lower(),
        "code": code,
        "scope": scope,
        "cycle": False,
        "increment": 1,
        "start": 1,
        "minValue": 1,
        "maxValue": 9223372036854775807,
    }
    assert response == expected_response
