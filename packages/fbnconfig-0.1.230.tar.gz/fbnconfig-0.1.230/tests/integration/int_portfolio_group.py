import datetime as dt
import os
from types import SimpleNamespace

from pytest import fixture

import fbnconfig
from fbnconfig import datatype, portfolio, portfolio_group, property
from fbnconfig.properties import PropertyValue
from tests.integration.generate_test_name import gen


@fixture(scope="module")
def lusid_env():
    if os.getenv("FBN_ACCESS_TOKEN") is None or os.getenv("LUSID_ENV") is None:
        raise (
            RuntimeError("Both FBN_ACCESS_TOKEN and LUSID_ENV variables need to be set")
        )
    lusid_env = os.environ["LUSID_ENV"]
    token = os.environ["FBN_ACCESS_TOKEN"]
    return SimpleNamespace(env=lusid_env, token=token)


@fixture(scope="module")
def client(lusid_env):
    return fbnconfig.create_client(lusid_env.env, lusid_env.token)


@fixture()
def deployment_name():
    return gen("pf_group")


@fixture()
def setup_deployment(deployment_name, lusid_env):
    print(f"\nRunning for deployment {deployment_name}...")
    yield SimpleNamespace(name=deployment_name)
    try:
        fbnconfig.deployex(fbnconfig.Deployment(deployment_name, []), lusid_env.env, lusid_env.token)
    except Exception as r:
        print("Exceptions during teardown of the test data", r)
        pass


@fixture()
def base_resources(setup_deployment):
    scope = setup_deployment.name
    start_date = dt.date(2024, 1, 5)
    string = datatype.DataTypeRef(id="datatype_string", scope="system", code="string")
    group_prop = property.DefinitionResource(
        id="group_prop", scope=scope, code="rating",
        domain=property.Domain.PortfolioGroup,
        display_name="Rating Property", data_type_id=string,
    )
    group_prop2 = property.DefinitionResource(
        id="group_prop2", scope=scope, code="sector",
        domain=property.Domain.PortfolioGroup,
        display_name="Sector Property", data_type_id=string,
    )
    pf1 = portfolio.PortfolioResource(
        id="pf1", scope=scope, code="pf1",
        display_name="Portfolio 1", description="Test portfolio 1",
        base_currency="USD", created=start_date, instrument_scopes=[scope],
    )
    pf2 = portfolio.PortfolioResource(
        id="pf2", scope=scope, code="pf2",
        display_name="Portfolio 2", description="Test portfolio 2",
        base_currency="USD", created=start_date, instrument_scopes=[scope],
    )
    sub_group = portfolio_group.PortfolioGroupResource(
        id="sub1", scope=scope, code="sub1",
        display_name="Sub Group", description="A sub group",
        created=start_date,
    )
    group = portfolio_group.PortfolioGroupResource(
        id="group1", scope=scope, code="group1",
        display_name="Test Group", description="Test group",
        created=start_date, portfolios=[pf1],
    )
    return {
        "group_prop": group_prop, "group_prop2": group_prop2,
        "pf1": pf1, "pf2": pf2, "sub1": sub_group, "group": group,
    }


def _deploy(name, resources, lusid_env):
    deployment = fbnconfig.Deployment(name, resources)
    return fbnconfig.deployex(deployment, lusid_env.env, lusid_env.token)


def _get_group_properties(client, scope, code, prop_keys=None):
    params = {}
    if prop_keys:
        params["propertyKeys"] = prop_keys
    return client.get(
        f"/api/api/portfoliogroups/{scope}/{code}/properties", params=params,
    ).json()


class DescribePortfolioGroupResource:
    def test_create(self, client, setup_deployment, base_resources, lusid_env):
        # given a group with one portfolio member
        # when we deploy
        _deploy(setup_deployment.name, base_resources.values(), lusid_env)
        # then the group exists with the correct display name and portfolio
        scope = setup_deployment.name
        remote = client.get(f"/api/api/portfoliogroups/{scope}/group1").json()
        assert remote["displayName"] == "Test Group"
        assert len(remote["portfolios"]) == 1
        assert remote["portfolios"][0]["code"] == "pf1"

    def test_create_body_has_no_scope(self, client, setup_deployment, base_resources, lusid_env):
        """scope must only be a path param, not in the request body"""
        # given a group resource
        # when we deploy
        _deploy(setup_deployment.name, base_resources.values(), lusid_env)
        # then the group is created with the correct scope and code
        scope = setup_deployment.name
        remote = client.get(f"/api/api/portfoliogroups/{scope}/group1").json()
        assert remote["id"]["scope"] == scope
        assert remote["id"]["code"] == "group1"
        assert remote["displayName"] == "Test Group"

    def test_update_display_name(self, client, setup_deployment, base_resources, lusid_env):
        # given an existing group
        _deploy(setup_deployment.name, base_resources.values(), lusid_env)
        # when we change the display name and redeploy
        base_resources["group"].display_name = "Updated Group Name"
        updates = _deploy(setup_deployment.name, base_resources.values(), lusid_env)
        # then the group is updated
        grp_changes = [u for u in updates if u.id == "group1"]
        assert grp_changes[0].change == "update"
        scope = setup_deployment.name
        remote = client.get(f"/api/api/portfoliogroups/{scope}/group1").json()
        assert remote["displayName"] == "Updated Group Name"

    def test_update_add_portfolio(self, client, setup_deployment, base_resources, lusid_env):
        # given an existing group with pf1
        _deploy(setup_deployment.name, base_resources.values(), lusid_env)
        # when we add pf2 and redeploy
        base_resources["group"].portfolios = [base_resources["pf1"], base_resources["pf2"]]
        updates = _deploy(setup_deployment.name, base_resources.values(), lusid_env)
        # then the group is updated with both portfolios
        grp_changes = [u for u in updates if u.id == "group1"]
        assert grp_changes[0].change == "update"
        scope = setup_deployment.name
        remote = client.get(f"/api/api/portfoliogroups/{scope}/group1").json()
        codes = {p["code"] for p in remote["portfolios"]}
        assert codes == {"pf1", "pf2"}

    def test_update_remove_portfolio(self, client, setup_deployment, base_resources, lusid_env):
        # given an existing group with pf1
        _deploy(setup_deployment.name, base_resources.values(), lusid_env)
        # when we remove all portfolios and redeploy
        base_resources["group"].portfolios = []
        updates = _deploy(setup_deployment.name, base_resources.values(), lusid_env)
        # then the group is updated with no portfolios
        grp_changes = [u for u in updates if u.id == "group1"]
        assert grp_changes[0].change == "update"
        scope = setup_deployment.name
        remote = client.get(f"/api/api/portfoliogroups/{scope}/group1").json()
        assert remote["portfolios"] == []

    def test_update_swap_portfolio(self, client, setup_deployment, base_resources, lusid_env):
        # given an existing group with pf1
        _deploy(setup_deployment.name, base_resources.values(), lusid_env)
        # when we swap pf1 for pf2 and redeploy
        base_resources["group"].portfolios = [base_resources["pf2"]]
        updates = _deploy(setup_deployment.name, base_resources.values(), lusid_env)
        # then the group is updated with only pf2
        grp_changes = [u for u in updates if u.id == "group1"]
        assert grp_changes[0].change == "update"
        scope = setup_deployment.name
        remote = client.get(f"/api/api/portfoliogroups/{scope}/group1").json()
        codes = {p["code"] for p in remote["portfolios"]}
        assert codes == {"pf2"}

    def test_update_add_and_remove_sub_group(self, client, setup_deployment, base_resources, lusid_env):
        # given an existing group with no sub groups
        _deploy(setup_deployment.name, base_resources.values(), lusid_env)
        scope = setup_deployment.name
        remote = client.get(f"/api/api/portfoliogroups/{scope}/group1").json()
        assert remote["subGroups"] == []
        # when we add a sub group and redeploy
        base_resources["group"].sub_groups = [base_resources["sub1"]]
        updates = _deploy(setup_deployment.name, base_resources.values(), lusid_env)
        # then the sub group is added
        group1_changes = [u for u in updates if u.id == "group1"]
        assert group1_changes[0].change == "update"
        remote = client.get(f"/api/api/portfoliogroups/{scope}/group1").json()
        assert len(remote["subGroups"]) == 1
        assert remote["subGroups"][0]["code"] == "sub1"
        # when we remove the sub group and redeploy
        base_resources["group"].sub_groups = []
        updates = _deploy(setup_deployment.name, base_resources.values(), lusid_env)
        # then the sub group is removed
        group1_changes = [u for u in updates if u.id == "group1"]
        assert group1_changes[0].change == "update"
        remote = client.get(f"/api/api/portfoliogroups/{scope}/group1").json()
        assert remote["subGroups"] == []

    def test_nochange(self, setup_deployment, base_resources, lusid_env):
        # given an existing group
        _deploy(setup_deployment.name, base_resources.values(), lusid_env)
        # when we redeploy with the same resources
        updates = _deploy(setup_deployment.name, base_resources.values(), lusid_env)
        # then no change is detected
        grp_changes = [u for u in updates if u.id == "group1"]
        assert grp_changes[0].change == "nochange"

    def test_teardown(self, setup_deployment, base_resources, lusid_env):
        # given an existing group
        _deploy(setup_deployment.name, base_resources.values(), lusid_env)
        # when we deploy with no resources
        updates = _deploy(setup_deployment.name, [], lusid_env)
        # then the group is removed
        grp_changes = [u for u in updates if u.id == "group1"]
        assert grp_changes[0].change == "remove"


class DescribePortfolioGroupPropertiesResource:
    def test_create_with_property(self, client, setup_deployment, base_resources, lusid_env):
        # given a group with a rating property
        scope = setup_deployment.name
        prop_ref = base_resources["group_prop"]
        prop_key = f"PortfolioGroup/{scope}/rating"
        grp_props = portfolio_group.PortfolioGroupPropertiesResource(
            id="grp_props", portfolio_group=base_resources["group"],
            properties=[PropertyValue(property_key=prop_ref, label_value="AAA")],
        )
        resources = list(base_resources.values()) + [grp_props]
        # when we deploy
        _deploy(setup_deployment.name, resources, lusid_env)
        # then the property exists on the group
        remote = _get_group_properties(client, scope, "group1", [prop_key])
        props = remote.get("properties", {})
        assert prop_key in props, f"Expected {prop_key} in {props}"
        assert props[prop_key]["value"]["labelValue"] == "AAA"

    def test_update_property_value(self, client, setup_deployment, base_resources, lusid_env):
        # given a group with rating=AAA
        scope = setup_deployment.name
        prop_ref = base_resources["group_prop"]
        prop_key = f"PortfolioGroup/{scope}/rating"
        grp_props = portfolio_group.PortfolioGroupPropertiesResource(
            id="grp_props", portfolio_group=base_resources["group"],
            properties=[PropertyValue(property_key=prop_ref, label_value="AAA")],
        )
        resources = list(base_resources.values()) + [grp_props]
        _deploy(setup_deployment.name, resources, lusid_env)
        # when we change the value to BBB and redeploy
        grp_props.properties = [PropertyValue(property_key=prop_ref, label_value="BBB")]
        resources = list(base_resources.values()) + [grp_props]
        updates = _deploy(setup_deployment.name, resources, lusid_env)
        # then the property is updated
        prop_changes = [u for u in updates if u.type == "PortfolioGroupPropertiesResource"]
        assert prop_changes[0].change == "update"
        remote = _get_group_properties(client, scope, "group1", [prop_key])
        assert remote["properties"][prop_key]["value"]["labelValue"] == "BBB"

    def test_remove_property(self, client, setup_deployment, base_resources, lusid_env):
        # given a group with rating and sector properties
        scope = setup_deployment.name
        rating_ref = base_resources["group_prop"]
        sector_ref = base_resources["group_prop2"]
        rating_key = f"PortfolioGroup/{scope}/rating"
        sector_key = f"PortfolioGroup/{scope}/sector"
        grp_props = portfolio_group.PortfolioGroupPropertiesResource(
            id="grp_props", portfolio_group=base_resources["group"],
            properties=[
                PropertyValue(property_key=rating_ref, label_value="AAA"),
                PropertyValue(property_key=sector_ref, label_value="Tech"),
            ],
        )
        resources = list(base_resources.values()) + [grp_props]
        _deploy(setup_deployment.name, resources, lusid_env)
        # when we keep sector but remove rating and redeploy
        grp_props.properties = [PropertyValue(property_key=sector_ref, label_value="Tech")]
        resources = list(base_resources.values()) + [grp_props]
        updates = _deploy(setup_deployment.name, resources, lusid_env)
        # then rating is removed and sector remains
        prop_changes = [u for u in updates if u.type == "PortfolioGroupPropertiesResource"]
        assert prop_changes[0].change == "update"
        remote = _get_group_properties(client, scope, "group1", [rating_key, sector_key])
        props = remote.get("properties", {})
        assert rating_key not in props, f"Expected {rating_key} removed, got {props}"
        assert sector_key in props
        assert props[sector_key]["value"]["labelValue"] == "Tech"

    def test_no_change(self, setup_deployment, base_resources, lusid_env):
        # given a group with a rating property
        prop_ref = base_resources["group_prop"]
        grp_props = portfolio_group.PortfolioGroupPropertiesResource(
            id="grp_props", portfolio_group=base_resources["group"],
            properties=[PropertyValue(property_key=prop_ref, label_value="AAA")],
        )
        resources = list(base_resources.values()) + [grp_props]
        _deploy(setup_deployment.name, resources, lusid_env)
        # when we redeploy with the same properties
        updates = _deploy(setup_deployment.name, resources, lusid_env)
        # then no change is detected
        prop_changes = [u for u in updates if u.type == "PortfolioGroupPropertiesResource"]
        assert prop_changes[0].change == "nochange"

    def test_teardown_removes_properties(self, client, setup_deployment, base_resources, lusid_env):
        # given a group with a rating property
        scope = setup_deployment.name
        prop_ref = base_resources["group_prop"]
        prop_key = f"PortfolioGroup/{scope}/rating"
        grp_props = portfolio_group.PortfolioGroupPropertiesResource(
            id="grp_props", portfolio_group=base_resources["group"],
            properties=[PropertyValue(property_key=prop_ref, label_value="AAA")],
        )
        resources = list(base_resources.values()) + [grp_props]
        _deploy(setup_deployment.name, resources, lusid_env)
        # when we redeploy without the properties resource
        _deploy(setup_deployment.name, list(base_resources.values()), lusid_env)
        # then the properties are removed
        remote = _get_group_properties(client, scope, "group1", [prop_key])
        assert remote.get("properties", {}) == {}
