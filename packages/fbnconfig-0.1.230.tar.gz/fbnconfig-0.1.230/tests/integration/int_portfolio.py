import datetime as dt
import os
from types import SimpleNamespace

from pytest import fixture

import fbnconfig
from fbnconfig import corporate_action, datatype, portfolio, property
from fbnconfig.properties import PropertyValue
from tests.integration.generate_test_name import gen


@fixture(scope="module")
def lusid_env():
    if os.getenv("FBN_ACCESS_TOKEN") is None or os.getenv("LUSID_ENV") is None:
        raise (
            RuntimeError("Both FBN_ACCESS_TOKEN and LUSID_ENV variables need to be set")
        )
    lusid_env = os.environ["LUSID_ENV"]
    token = os.environ["FBN_ACCESS_TOKEN"]
    return SimpleNamespace(env=lusid_env, token=token)


@fixture(scope="module")
def client(lusid_env):
    return fbnconfig.create_client(lusid_env.env, lusid_env.token)


@fixture()
def deployment_name():
    return gen("portfolio")


@fixture()
def setup_deployment(deployment_name, lusid_env):
    print(f"\nRunning for deployment {deployment_name}...")
    yield SimpleNamespace(name=deployment_name)
    try:
        fbnconfig.deployex(fbnconfig.Deployment(deployment_name, []), lusid_env.env, lusid_env.token)
    except Exception as r:
        print("Exceptions during teardown of the test data", r)
        pass


@fixture()
def base_resources(setup_deployment):
    deployment_name = setup_deployment.name
    start_date = dt.date(2024, 1, 5)
    scope = deployment_name
    string = datatype.DataTypeRef(
        id="datatype_string",
        scope="system",
        code="string",
    )
    test_property = property.DefinitionResource(
        id="test_property",
        scope=scope,
        code="portfolio_example",
        domain=property.Domain.Transaction,
        display_name="Portfolio Example Property",
        data_type_id=string,
    )
    portfolio_prop = property.DefinitionResource(
        id="portfolio_prop",
        scope=scope,
        code="rating",
        domain=property.Domain.Portfolio,
        display_name="Rating Property",
        data_type_id=string,
    )
    portfolio_prop2 = property.DefinitionResource(
        id="portfolio_prop2",
        scope=scope,
        code="sector",
        domain=property.Domain.Portfolio,
        display_name="Sector Property",
        data_type_id=string,
    )
    ca_source = corporate_action.CorporateActionSourceResource(
        id="ca_source",
        scope=scope,
        code="int_test_source",
        display_name="Integration Test CA Source",
        instrument_scopes=[scope],
    )
    portfolio1 = portfolio.PortfolioResource(
        id="portfolio",
        scope=scope,
        code="int_test",
        display_name="integration test portfolio 1",
        description="Test Portfolio",
        created=start_date,
        base_currency="USD",
        instrument_scopes=[scope],
        sub_holding_keys=[test_property],
        transaction_type_scope="default",
        corporate_action_source_id=ca_source,
    )
    return {
        "property": test_property, "portfolio_prop": portfolio_prop,
        "portfolio_prop2": portfolio_prop2, "ca_source": ca_source, "portfolio": portfolio1,
    }


def _get_portfolio(client, scope, code, prop_keys=None):
    params = {}
    if prop_keys:
        params["propertyKeys"] = prop_keys
    return client.get(f"/api/api/portfolios/{scope}/{code}", params=params).json()


def _deploy(name, resources, lusid_env):
    deployment = fbnconfig.Deployment(name, resources)
    return fbnconfig.deployex(deployment, lusid_env.env, lusid_env.token)


class DescribePortfolioResource:
    def test_update_display_name(self, client, setup_deployment, base_resources, lusid_env):
        deployment_name = setup_deployment.name
        scope = deployment_name
        _deploy(deployment_name, base_resources.values(), lusid_env)
        # when we change the display name
        base_resources["portfolio"].display_name = "Updated Display Name"
        updates = _deploy(deployment_name, base_resources.values(), lusid_env)
        # then the portfolio is updated (not recreated)
        pf_changes = [u for u in updates if u.type == "PortfolioResource"]
        assert pf_changes[0].change == "update"
        remote = client.get(f"/api/api/portfolios/{scope}/int_test").json()
        assert remote["displayName"] == "Updated Display Name"

    def test_update_base_currency(self, client, setup_deployment, base_resources, lusid_env):
        deployment_name = setup_deployment.name
        scope = deployment_name
        _deploy(deployment_name, base_resources.values(), lusid_env)
        # when we change the base currency (triggers delete+recreate)
        base_resources["portfolio"].base_currency = "GBP"
        updates = _deploy(deployment_name, base_resources.values(), lusid_env)
        # then the portfolio is recreated
        pf_changes = [u for u in updates if u.type == "PortfolioResource"]
        assert pf_changes[0].change == "update"
        remote = client.get(f"/api/api/portfolios/{scope}/int_test").json()
        assert remote["baseCurrency"] == "GBP"

    def test_update_created_date(self, client, setup_deployment, base_resources, lusid_env):
        deployment_name = setup_deployment.name
        scope = deployment_name
        _deploy(deployment_name, base_resources.values(), lusid_env)
        # when we change created to an earlier date (must precede existing)
        base_resources["portfolio"].created = dt.date(2023, 6, 1)
        updates = _deploy(deployment_name, base_resources.values(), lusid_env)
        # then the portfolio is updated in place
        pf_changes = [u for u in updates if u.type == "PortfolioResource"]
        assert pf_changes[0].change == "update"
        remote = client.get(f"/api/api/portfolios/{scope}/int_test").json()
        assert remote["created"].startswith("2023-06-01")

    def test_teardown(self, setup_deployment, base_resources, lusid_env):
        deployment_name = setup_deployment.name
        _deploy(deployment_name, base_resources.values(), lusid_env)
        # when we remove all the resources
        _deploy(deployment_name, [], lusid_env)


class DescribePortfolioPropertiesResource:
    def test_create_with_property(self, client, setup_deployment, base_resources, lusid_env):
        scope = setup_deployment.name
        prop_ref = base_resources["portfolio_prop"]
        prop_key = f"Portfolio/{scope}/rating"
        pf_props = portfolio.PortfolioPropertiesResource(
            id="pf_props", portfolio=base_resources["portfolio"],
            properties=[PropertyValue(property_key=prop_ref, label_value="AAA")],
        )
        resources = list(base_resources.values()) + [pf_props]
        _deploy(setup_deployment.name, resources, lusid_env)
        remote = _get_portfolio(client, scope, "int_test", [prop_key])
        props = remote.get("properties", {})
        assert prop_key in props, f"Expected {prop_key} in {props}"
        assert props[prop_key]["value"]["labelValue"] == "AAA"

    def test_update_property_value(self, client, setup_deployment, base_resources, lusid_env):
        scope = setup_deployment.name
        prop_ref = base_resources["portfolio_prop"]
        prop_key = f"Portfolio/{scope}/rating"
        pf_props = portfolio.PortfolioPropertiesResource(
            id="pf_props", portfolio=base_resources["portfolio"],
            properties=[PropertyValue(property_key=prop_ref, label_value="AAA")],
        )
        resources = list(base_resources.values()) + [pf_props]
        _deploy(setup_deployment.name, resources, lusid_env)
        # when we change the property value
        pf_props.properties = [PropertyValue(property_key=prop_ref, label_value="BBB")]
        resources = list(base_resources.values()) + [pf_props]
        updates = _deploy(setup_deployment.name, resources, lusid_env)
        pf_changes = [u for u in updates if u.type == "PortfolioPropertiesResource"]
        assert pf_changes[0].change == "update"
        remote = _get_portfolio(client, scope, "int_test", [prop_key])
        assert remote["properties"][prop_key]["value"]["labelValue"] == "BBB"

    def test_remove_property(self, client, setup_deployment, base_resources, lusid_env):
        scope = setup_deployment.name
        rating_ref = base_resources["portfolio_prop"]
        sector_ref = base_resources["portfolio_prop2"]
        rating_key = f"Portfolio/{scope}/rating"
        sector_key = f"Portfolio/{scope}/sector"
        # given two properties deployed
        pf_props = portfolio.PortfolioPropertiesResource(
            id="pf_props", portfolio=base_resources["portfolio"],
            properties=[
                PropertyValue(property_key=rating_ref, label_value="AAA"),
                PropertyValue(property_key=sector_ref, label_value="Tech"),
            ],
        )
        resources = list(base_resources.values()) + [pf_props]
        _deploy(setup_deployment.name, resources, lusid_env)
        # when we keep sector but remove rating
        pf_props.properties = [PropertyValue(property_key=sector_ref, label_value="Tech")]
        resources = list(base_resources.values()) + [pf_props]
        updates = _deploy(setup_deployment.name, resources, lusid_env)
        pf_changes = [u for u in updates if u.type == "PortfolioPropertiesResource"]
        assert pf_changes[0].change == "update"
        remote = _get_portfolio(client, scope, "int_test", [rating_key, sector_key])
        props = remote.get("properties", {})
        assert rating_key not in props, f"Expected {rating_key} removed, got {props}"
        assert sector_key in props
        assert props[sector_key]["value"]["labelValue"] == "Tech"

    def test_no_change(self, client, setup_deployment, base_resources, lusid_env):
        prop_ref = base_resources["portfolio_prop"]
        pf_props = portfolio.PortfolioPropertiesResource(
            id="pf_props", portfolio=base_resources["portfolio"],
            properties=[PropertyValue(property_key=prop_ref, label_value="AAA")],
        )
        resources = list(base_resources.values()) + [pf_props]
        _deploy(setup_deployment.name, resources, lusid_env)
        # when we deploy again with the same properties
        updates = _deploy(setup_deployment.name, resources, lusid_env)
        pf_changes = [u for u in updates if u.type == "PortfolioPropertiesResource"]
        assert pf_changes[0].change == "nochange"

    def test_teardown_removes_properties(self, client, setup_deployment, base_resources, lusid_env):
        scope = setup_deployment.name
        prop_ref = base_resources["portfolio_prop"]
        prop_key = f"Portfolio/{scope}/rating"
        pf_props = portfolio.PortfolioPropertiesResource(
            id="pf_props", portfolio=base_resources["portfolio"],
            properties=[PropertyValue(property_key=prop_ref, label_value="AAA")],
        )
        resources = list(base_resources.values()) + [pf_props]
        _deploy(setup_deployment.name, resources, lusid_env)
        # when we deploy without the properties resource
        _deploy(setup_deployment.name, list(base_resources.values()), lusid_env)
        # then properties are removed from the portfolio
        remote = _get_portfolio(client, scope, "int_test", [prop_key])
        assert remote.get("properties", {}) == {}
