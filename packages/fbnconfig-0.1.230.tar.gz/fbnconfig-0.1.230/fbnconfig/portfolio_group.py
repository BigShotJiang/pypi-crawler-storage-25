from __future__ import annotations

import hashlib
import json
from typing import Annotated, Any, Dict, List, Sequence

import httpx
from pydantic import BaseModel, BeforeValidator, Field, PlainSerializer, computed_field, model_validator

from fbnconfig.coretypes import IsoDateTime
from fbnconfig.portfolio import PortfolioKey
from fbnconfig.properties import PropertyValueDict
from fbnconfig.resource_abc import CamelAlias, Ref, Resource, register_resource


@register_resource(group="Portfolio Construction", keys=["scope", "code"])
class PortfolioGroupResource(BaseModel, Resource):
    id: str = Field(exclude=True)
    scope: str
    code: str
    display_name: str
    description: str
    created: IsoDateTime
    portfolios: Sequence[PortfolioKey] = []
    sub_groups: Sequence[PortfolioGroupKey] = []

    @model_validator(mode="before")
    @classmethod
    def des_model(cls, data: Any, info) -> Dict[str, Any]:
        if not isinstance(data, dict):
            return data
        # promote scope and code
        if isinstance(data.get("id", None), dict):
            data = data | data["id"]
            data.pop("id", None)
        if info.context and info.context.get("id"):
            data = data | {"id": info.context["id"]}
        return data

    @computed_field(alias="values")
    def values(self) -> Sequence[PortfolioKey]:
        return self.portfolios

    def read(self, client, old_state):
        scope, code = old_state.scope, old_state.code
        remote = client.request("get", f"/api/api/portfoliogroups/{scope}/{code}").json()
        remote.pop("version")
        remote.pop("links")
        return remote

    def create(self, client: httpx.Client):
        # create and list use "values" but group get gives portfolios. exclude the other
        desired = self.model_dump(
            mode="json", by_alias=True, exclude_none=True,
            exclude={"portfolios", "scope"},
        )
        client.request("POST", f"/api/api/portfoliogroups/{self.scope}", json=desired)
        sorted_desired = json.dumps(desired, sort_keys=True)
        content_hash = hashlib.sha256(sorted_desired.encode()).hexdigest()
        return {"id": self.id, "code": self.code, "scope": self.scope, "content_hash": content_hash}

    def update(self, client: httpx.Client, old_state):
        if [self.code, self.scope] != [old_state.code, old_state.scope]:
            self.delete(client, old_state)
            return self.create(client)
        desired = self.model_dump(
            mode="json", by_alias=True, exclude_none=True,
            exclude={"portfolios", "scope"},
        )
        sorted_desired = json.dumps(desired, sort_keys=True)
        content_hash = hashlib.sha256(sorted_desired.encode()).hexdigest()
        if content_hash == old_state.content_hash:
            return None
        remote = self.read(client, old_state)
        changed = any([
            self._update_put_fields(client, desired, remote),
            self._update_portfolios(client, desired, remote),
            self._update_sub_groups(client, desired, remote),
        ])
        if not changed:
            return None
        return {"id": self.id, "scope": self.scope, "code": self.code, "content_hash": content_hash}

    _PUT_FIELDS = ["displayName", "description"]

    def _update_put_fields(self, client, desired, remote):
        changes = {k: desired[k] for k in self._PUT_FIELDS
                   if k in desired and desired[k] != remote.get(k)}
        if not changes:
            return False
        # displayName is required in UpdatePortfolioGroupRequest
        body = {"displayName": desired["displayName"]}
        if "description" in changes:
            body["description"] = changes["description"]
        effective_at = remote.get("created", "0001-01-01")
        client.request(
            "PUT", f"/api/api/portfoliogroups/{self.scope}/{self.code}", json=body,
            params={"effectiveAt": effective_at},
        )
        return True

    @staticmethod
    def _to_tuples(items):
        return {(p["scope"], p["code"]) for p in (items or [])}

    def _update_portfolios(self, client, desired, remote):
        desired_set = self._to_tuples(desired.get("values"))
        remote_set = self._to_tuples(remote.get("portfolios"))
        if desired_set == remote_set:
            return False
        effective_at = remote.get("created", "0001-01-01")
        for scope, code in desired_set - remote_set:
            client.request(
                "POST", f"/api/api/portfoliogroups/{self.scope}/{self.code}/portfolios",
                json={"scope": scope, "code": code},
                params={"effectiveAt": effective_at},
            )
        for scope, code in remote_set - desired_set:
            client.request(
                "DELETE",
                f"/api/api/portfoliogroups/{self.scope}/{self.code}/portfolios/{scope}/{code}",
                params={"effectiveAt": effective_at},
            )
        return True

    def _update_sub_groups(self, client, desired, remote):
        desired_set = self._to_tuples(desired.get("subGroups"))
        remote_set = self._to_tuples(remote.get("subGroups"))
        if desired_set == remote_set:
            return False
        effective_at = remote.get("created", "0001-01-01")
        for scope, code in desired_set - remote_set:
            client.request(
                "POST", f"/api/api/portfoliogroups/{self.scope}/{self.code}/subgroups",
                json={"scope": scope, "code": code},
                params={"effectiveAt": effective_at},
            )
        for scope, code in remote_set - desired_set:
            client.request(
                "DELETE",
                f"/api/api/portfoliogroups/{self.scope}/{self.code}/subgroups/{scope}/{code}",
                params={"effectiveAt": effective_at},
            )
        return True

    @staticmethod
    def delete(client, old_state):
        scope = old_state.scope
        code = old_state.code
        client.request("DELETE", f"/api/api/portfoliogroups/{scope}/{code}")

    def deps(self):
        return list(self.portfolios) + list(self.sub_groups)


@register_resource(group="Portfolio Construction")
class PortfolioGroupRef(CamelAlias, BaseModel, Ref):
    id: str = Field(exclude=True)
    scope: str
    code: str

    def attach(self, client):
        try:
            response = client.get(f"/api/api/portfoliogroups/{self.scope}/{self.code}")
            return response.json()
        except httpx.HTTPStatusError as ex:
            if ex.response.status_code == 404:
                raise RuntimeError(f"PortfolioGroup {self.scope}/{self.code} not found")
            raise


def ser_group_key(value, info):
    style = info.context.get("style", "api") if info.context else "api"
    if style == "dump":
        return {"$ref": value.id}
    return {"scope": value.scope, "code": value.code}


def des_group_key(value, info):
    if not isinstance(value, dict):
        return value
    if "$ref" in value and info.context and info.context.get("$refs"):
        return info.context["$refs"][value["$ref"]]
    return value


PortfolioGroupKey = Annotated[
    PortfolioGroupResource | PortfolioGroupRef,
    BeforeValidator(des_group_key), PlainSerializer(ser_group_key)
]


@register_resource(group="Portfolio Construction", keys=["scope", "code"])
class PortfolioGroupPropertiesResource(BaseModel, Resource):
    id: str = Field(exclude=True)
    portfolio_group: PortfolioGroupKey
    properties: PropertyValueDict

    @model_validator(mode="before")
    @classmethod
    def des_model(cls, data: Any, info) -> Dict[str, Any]:
        if not isinstance(data, dict):
            return data
        if info.context and info.context.get("id"):
            return data | {"id": info.context.get("id")}
        return data

    def _serialize_properties(self):
        props = self.model_dump(mode="json", by_alias=True, exclude={"portfolio_group"})
        return props.get("properties", {})

    def _make_state(self, content_hash):
        return {
            "scope": self.portfolio_group.scope,
            "code": self.portfolio_group.code,
            "content_hash": content_hash,
        }

    def read(self, client, old_state):
        resp = client.request(
            "GET",
            f"/api/api/portfoliogroups/{old_state.scope}/{old_state.code}/properties",
        ).json()
        return resp.get("properties", {})

    def create(self, client):
        desired = self._serialize_properties()
        sorted_desired = json.dumps(desired, sort_keys=True)
        content_hash = hashlib.sha256(sorted_desired.encode()).hexdigest()
        if desired:
            client.request(
                "POST",
                f"/api/api/portfoliogroups/{self.portfolio_group.scope}/{self.portfolio_group.code}/properties/$upsert",
                json=desired,
            )
        return self._make_state(content_hash)

    def update(self, client: httpx.Client, old_state):
        old_id = [old_state.scope, old_state.code]
        new_id = [self.portfolio_group.scope, self.portfolio_group.code]
        if old_id != new_id:
            self.delete(client, old_state)
            return self.create(client)
        desired = self._serialize_properties()
        sorted_desired = json.dumps(desired, sort_keys=True)
        content_hash = hashlib.sha256(sorted_desired.encode()).hexdigest()
        if content_hash == old_state.content_hash:
            return None
        remote = self.read(client, old_state)
        to_upsert = {k: v for k, v in desired.items() if remote.get(k) != v}
        if to_upsert:
            client.request(
                "POST",
                f"/api/api/portfoliogroups/{self.portfolio_group.scope}/{self.portfolio_group.code}/properties/$upsert",
                json=to_upsert,
            )
        to_delete = [k for k in remote if k not in desired]
        if to_delete:
            client.request(
                "POST",
                f"/api/api/portfoliogroups/{self.portfolio_group.scope}/{self.portfolio_group.code}/properties/$delete",
                json=to_delete,
            )
        return self._make_state(content_hash)

    @staticmethod
    def delete(client, old_state):
        scope = old_state.scope
        code = old_state.code
        resp = client.request(
            "GET",
            f"/api/api/portfoliogroups/{scope}/{code}/properties",
        ).json()
        remote_keys = list(resp.get("properties", {}).keys())
        if not remote_keys:
            return
        client.request(
            "POST",
            f"/api/api/portfoliogroups/{scope}/{code}/properties/$delete",
            json=remote_keys,
        )

    def deps(self) -> List[Resource | Ref]:
        res: List[Resource | Ref] = [self.portfolio_group]
        for p in self.properties:
            res.append(p.property_key)
        return res
