# Changelog

All notable changes to QAMigrate are documented here.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.5.5] - 2026-04-19

**Theme: Fix the root cause of all remaining `mvn clean compile` failures.**

All 24 remaining compile errors in the v0.5.4 test report traced back to
the same architectural gap: generated files imported sibling classes via
the ORIGINAL package path, not the migrated `.playwright` path. Three
coordinated fixes close this.

### Fixed

- **Fix 1 — Post-generation sibling import rewrite (addresses ~22 of 24
  remaining errors).**
  After all files are generated (Phase 1), a new deterministic pass
  rewrites import statements that reference migrated sibling classes.
  Example: `import com.qastarter.browser.BrowserFactory;` becomes
  `import com.qastarter.browser.playwright.BrowserFactory;`. The rewrite
  uses a map of `{simple_class_name → original_package}` built from the
  generation results — no LLM call. Only `import` lines are touched;
  method bodies, comments, and third-party imports (Playwright API, JUnit,
  etc.) are left unchanged. Both the on-disk file and the in-memory
  `GenerationResult.generated_code` are updated so the compile check and
  hallucination detector see consistent state. This addresses the
  `cannot find symbol` errors in DriverManager, ScreenshotUtils, BasePage,
  WebActions, and BaseTest.

- **Fix 2 — Sanitize dict-valued `fields[]` list items (fixes WaitUtils
  Pydantic crash).**
  `gpt-4o` occasionally returns a structured object (e.g.
  `{'declaration': 'private Page page;', 'init': 'this.page = page;'}`)
  in the `fields[]` list, which the schema declares as `list[str]`.
  Pydantic v2 rejected this with a validation error, causing WaitUtils.java
  (and potentially other files) to be skipped entirely. `sanitize_fields()`
  in `llm/sanitize.py` now coerces dict-valued elements in `fields[]` and
  `imports[]` to strings by extracting the first string value from known
  keys (`declaration` > `type` > `name` > `value`). The `methods[]` list
  is intentionally excluded from coercion — its items are `MethodDefinition`
  dicts and must remain structured.

- **Fix 3 — Coder prompt: explicit `.playwright` import instruction.**
  Added numbered requirement 7 and a header note in the sibling-signatures
  block telling the LLM to append `.playwright` to the package path of any
  imported sibling class. Example provided inline. This prevents the import
  problem at generation time; Fix 1 remains as a safety net for cases where
  the LLM ignores the instruction.

### Tests

- +16 regression tests (`tests/test_v055_regressions.py`):
  - 7 for `_apply_import_rewrite()` (exact match, no false-positives,
    idempotent, non-import lines untouched)
  - 7 for `sanitize_fields()` dict coercion (priority order, methods
    unchanged, imports coerced, fallback str())
  - 2 for coder prompt content (system prompt + sibling block)
- Total: 240 → 256 passing.

## [0.5.4] - 2026-04-19

**Theme: Last two P0s from v0.5.3 test report — both blocking BUILD SUCCESS.**

### Fixed

- **P0 #1 — Passthrough files (enums) still emitted with wrong package.**
  `Environment.java` took the passthrough path (copy verbatim, no LLM),
  so the `.playwright` suffix enforcement added to `assemble_file()` in
  v0.5.3 never ran. The file was copied with `package com.qastarter.config;`
  and Maven saw a duplicate-class collision with the original.
  New `rewrite_package_for_passthrough()` in `intelligence/passthrough.py`
  rewrites the package declaration to append `.playwright` before writing
  the output file. Applied to both the single-file and batch pipeline paths.
  Idempotent: if the source somehow already ends with `.playwright`, it is
  not doubled.

- **P0 #2 — JUnit5 still injected with `<scope>test</scope>`.**
  v0.5.3 fixed Playwright's scope but left JUnit5 as test-scoped.
  `BaseTest.java` (and other lifecycle classes) are generated into
  `src/main/java` and import `org.junit.jupiter.api.*`. With test scope,
  Maven's compiler cannot resolve those imports for main-scope sources,
  producing 10+ errors in BaseTest.java alone.
  Fix: JUnit5 is now also injected without `<scope>` (= compile/default
  scope, visible to both `src/main` and `src/test`). This completes the
  scope fix started in v0.5.3.

### Tests

- +9 regression tests (`tests/test_v054_regressions.py`):
  - 6 for `rewrite_package_for_passthrough()` including end-to-end
    on the real `Environment.java` sample file
  - 3 for both deps having no scope after injection
- Updated `test_dependency_injector.py::test_line_count_grows_predictably`
  (10 new lines: both deps at 5 lines each, no scope line)
- Updated `test_v053_regressions.py` JUnit5 scope assertion
- Total: 231 → 240 passing.

## [0.5.3] - 2026-04-19

**Theme: Critical regression fixes from v0.5.1 real-project test report.**
All three bugs caused `mvn clean compile` to fail on any project migrated
with v0.5.1/v0.5.2, despite QAMigrate's internal check reporting 14/15
success at 93% confidence. This release fixes all three root causes.

### Fixed

- **Bug #1 — Wrong package declaration in all generated files.**
  Generated files declared `package com.example.pages;` — identical to
  their Selenium originals. When both source trees are compiled together
  by Maven, the Java compiler sees two classes with the same FQN
  (`com.example.pages.LoginPage`) and emits duplicate-symbol errors.
  Root cause: the Coder prompt said "Use exact same package name".
  Fix: two-layer defence —
  (1) Prompt now explicitly says to append `.playwright`
      (`com.example.pages` → `com.example.pages.playwright`);
  (2) The `package_name` tool-schema field description now also states
      the `.playwright` requirement;
  (3) `assemble_file()` enforces the suffix as a safety net regardless
      of what the LLM returns, so a mistaken response can never produce
      a duplicate-class collision.

- **Bug #2 — Playwright JAR injected with `<scope>test</scope>`.**
  `qamigrate init --yes` was injecting Playwright as a test-scoped
  dependency. Because QAMigrate generates page-object and base-class
  files into `src/main/java` that import `com.microsoft.playwright.*`,
  Maven cannot resolve those imports from a test-scoped JAR, producing
  "package com.microsoft.playwright does not exist" across every
  main-scope generated file.
  Fix: Playwright is now injected **without** a `<scope>` element
  (= default compile scope, visible to both `src/main` and `src/test`).
  JUnit 5 correctly keeps `<scope>test</scope>`.

- **Bug #3 — Internal compile check reported false success.**
  QAMigrate's batch `javac` check compiled only the `playwright/`
  output files in isolation. It never saw the original Selenium files,
  so duplicate-class collisions (Bug #1) and missing-package errors
  (Bug #2) were invisible to it. Fix: added `_warn_package_collisions()`
  that compares the package declared in each generated file against its
  original source. When they match, a structured warning is logged with
  a clear explanation and the fix, so users see the problem before
  invoking Maven rather than after.

### Tests

- +11 regression tests (`tests/test_v053_regressions.py`):
  - 4 for package-name enforcement in `assemble_file()`
  - 3 for dependency scope (Playwright no scope, JUnit test scope)
  - 3 for package-collision detection (`_warn_package_collisions`)
- Updated `test_dependency_injector.py::test_line_count_grows_predictably`
  to expect 11 new lines (Playwright: 5 lines, no scope; JUnit5: 6 lines
  with scope) instead of 12.
- Total: 220 → 231 passing.

## [0.5.2] - 2026-04-19

**Theme: Polish pass before next framework.** No new source/target
framework; instead, four precision fixes that harden what v0.5.1 shipped
with. All four came out of the v0.5.0/v0.5.1 real-project test report
and the review afterwards.

### Added

- **(a) Passthrough files now contribute sibling signatures.** In v0.5.1,
  files that went through the enum-passthrough path returned
  `signatures=[]`, which meant tests that imported them (e.g. a test
  using `Environment.DEV`) saw an empty sibling-context block and the
  Coder would occasionally hallucinate constants like `Environment.DEVELOPMENT`.
  Now passthrough files run through the scanner even though the LLM is
  skipped, and their extracted enum constants + methods flow into the
  Coder's prompt for every downstream file. New enum-aware branch in
  `core/parser.py` + new `build_signatures_from_class_info` helper in
  `intelligence/passthrough.py`.

- **(b) Selector hallucination detection now covers `getByTestId`.**
  v0.5.1 only checked `.locator("...")`. Tests that use
  `page.getByTestId("submit-btn")` were unvalidated even though the
  page object declares its test-ids explicitly. New
  `DeclaredSelectors` dataclass splits the per-class catalogue into
  `css` and `testids` so the two are never cross-compared (a CSS
  `#submit-btn` is NOT the same as a test-id `submit-btn`).
  Deliberately does NOT extend to `getByRole/Text/Label/Placeholder/AltText/Title`:
  those validate against ARIA/accessible-name semantics, not a
  declarative inventory, and string comparison there produces
  false-positives that erode trust in the detector. Backward
  compatible: old `dict[str, set[str]]` callers still work.

- **(c) `--confidence-threshold` CLI flag for quality gating.** Opt-in
  `qamigrate migrate --confidence-threshold 80 [--confidence-mode any|avg]`
  fails the run with exit code 2 (distinct from exit code 1 = migration
  broke) when the bar isn't met. Two modes:
  - `any` (default, strict): any single file below threshold fails.
  - `avg`: only the project-wide average must clear the bar.
  New `core/confidence_gate.py` module keeps the gate logic unit-testable
  without a Typer CliRunner harness. CI users: use
  `--confidence-threshold 80 --confidence-mode avg` to gate PRs on
  overall migration quality.

- **(d) `review.md` manual-review checklist.** When `--report <dir>` is
  passed, QAMigrate now also writes `review.md` alongside `report.html`,
  `report.json`, and `report.md`. Three prioritized buckets:
  - **Priority** (generation failed, or compile failed, or confidence &lt; 70): fix first.
  - **Verify** (hallucinations flagged, or needed 3+ fix attempts, or sub-90% confidence): glance at these.
  - **Solid** (&ge;90% confidence, zero hallucinations, compiled cleanly): likely ship-ready.

  Meant for a QA lead to work top-down. Complements `report.md`, which
  stays the per-file diff-detail document.

### Tests

- +3 enum-signature tests (`tests/test_passthrough.py`)
- +7 testid-detection tests (`tests/test_hallucination.py`)
- +8 confidence-gate tests (new `tests/test_confidence_gate.py`)
- +8 review-checklist tests (`tests/test_report.py`)
- Total: 194 -&gt; 220 passing.

## [0.5.1] - 2026-04-18

**Theme: Precision pass after v0.5.0 real-project test.** The v0.5.0
multi-provider run on a real Selenium project came back 14/15 on both
Anthropic and OpenAI. Four concrete failure modes were identified in
that report; this release fixes them.

### Fixed

- **Bug #1 -- Enum files mangled by both providers.** On v0.5.0,
  `Environment.java` (a plain enum with four constants) broke under
  Claude Sonnet (comma separators rewritten as semicolons) AND under
  GPT-4o (constants dropped entirely). Root cause: the
  `generate_playwright_code` tool schema forces
  `(package, imports, class_declaration, fields, constructor, methods)`
  which doesn't fit Java enum syntax. No amount of prompt-hardening
  fixes this -- the fix is to not call the LLM on such files.
  - New `qamigrate.intelligence.passthrough` module detects files that
    are enums / constants classes / DTOs with zero Selenium markers
    (`org.openqa.selenium`, `WebDriver`, `@FindBy`, `PageFactory`,
    `org.testng`, `org.junit`, etc.) and copies them verbatim into
    `playwright/` instead of running them through the Coder.
  - Wired into both the single-file `run_migration` and the batch
    `run_generation` code paths.

- **Bug #2 -- Hallucination detector missed invented CSS selectors.**
  The cross-file detector only checked method calls (e.g.
  `loginPage.getSuccessIndicator()`). Tests that instead invented raw
  selectors (`assertThat(page.locator("#success-indicator"))`) went
  unflagged even though `#success-indicator` didn't exist on any
  declared page-object locator.
  - Added `extract_declared_locators` + `detect_selector_hallucinations`
    in `qamigrate.core.hallucination`.
  - Batch pipeline now catalogues declared selectors per class during
    generation and flags invented ones during finalization, including
    a "did you mean" similarity hint (difflib) when close.
  - Conservative by design: skips bare tag names, `${...}`
    interpolations, and files that don't reference a known page object.

- **Bug #3 -- Coder prompt didn't prefer inherited helpers.**
  Tests extending a `BaseTest` that already exposes `getPage()` were
  being migrated as `DriverManager.getPage().locator(...)` instead of
  `getPage().locator(...)`. Bypassing the inherited helper breaks the
  per-test isolation the base class owns.
  - New prompt requirement #5 in `CoderAgent` spells out the rule.
  - `prompt_context._inherited_helpers_callout` enumerates the parent
    class's zero-arg infra accessors (`Page`, `WebDriver`, `Browser`,
    `BrowserContext`, etc.) when migrating a subclass and tells the
    Coder to call them by name instead of going through DriverManager.

### Verified (no code change)

- **Bug #4 -- pom.xml preservation under `qamigrate init`.**
  End-to-end check on the real `samples/selenium-java-project/pom.xml`
  (203-line pom with 17 comments): XML declaration kept, namespace
  attributes kept, all 17 comments kept, existing deps (selenium,
  testng, extentreports, log4j) intact, Playwright + JUnit 5 added
  cleanly, byte-for-byte idempotent on re-run.

### Tests

- +7 unit tests for passthrough (`tests/test_passthrough.py`)
- +10 unit tests for selector hallucination detection
  (`tests/test_hallucination.py`)
- +4 unit tests for inherited-helpers prompt block
  (`tests/test_prompt_context.py`)
- Total: 173 -> 194 passing.

## [0.5.0] - 2026-04-17

**Theme: Project Intelligence.** QAMigrate is now context-aware. Before
writing a single line of Playwright code, it parses the whole project,
classifies every class by role, detects the conventions the project
consistently follows, builds the cross-class dependency graph, and
captures infrastructure (Log4j2, ExtentReports, TestNG listeners, etc.).
Then when the Coder migrates a file, it sees all of this as prompt
context -- not just the one file in isolation.

### Added -- new intelligence layer

- **`qamigrate.intelligence` package** with:
  - `ProjectMap` data model: classes, roles, edges, conventions, infra
  - `role_inference`: classifies each class as BASE / UTILITY / PAGE /
    TEST / LISTENER / DRIVER_MANAGER / CONFIG / ENUM / OTHER
  - `convention_detector`: detects method chaining, "log every action",
    logger pattern, assertion style, driver access (ThreadLocal vs
    static), implicit-wait usage, explicit-wait helpers, password
    masking, retry analyzer, TestNG `@Listeners`, config override order
  - `dependency_graph`: builds EXTENDS / IMPLEMENTS / INSTANTIATES /
    STATIC_CALL / FIELD_TYPE / IMPORT edges between in-project classes
  - `infrastructure`: deep pom.xml / build.gradle parsing for
    Selenium / Playwright / TestNG / JUnit5 / Log4j2 / ExtentReports
    versions, plus env profiles, Java version, parallel execution
  - `ProjectAnalyzer`: orchestrator that ties all of the above into a
    single `ProjectMap` -- no LLM calls, runs in well under a second
  - `prompt_context.format_project_context()`: renders the map as a
    compact prompt block (~1K tokens for a medium project)

- **New CLI command: `qamigrate analyze`**
  - Produces `architecture.html`, `architecture.md`, and
    `project-map.json` under `./qamigrate-report/`
  - Zero LLM cost -- this is what QAMigrate KNOWS about your project
    before generating any code
  - Consultant-grade doc: classifies every class, lists conventions,
    shows the dependency graph, reports infrastructure

- **Deep Coder context (v0.5 prompt integration)**
  - `CoderAgent.generate_from_class_info(..., project_context=...)`
    now accepts a prompt block
  - `run_project_migration` builds the ProjectMap once in Phase 0 and
    threads it through every file's generation call
  - For the file being migrated, we zoom in on its direct dependencies
    and show the Coder the FULL method bodies of utility/base classes
    (Q3 "deep" design decision). This is what lets the Coder preserve
    `Log.action()` calls, ThreadLocal driver patterns, and the project's
    logging/reporting infrastructure -- instead of generating generic
    Playwright that silently drops those conventions.

### Parser enhancements

- Tree-sitter parser now extracts class / method / field modifiers
  (`public`, `private`, `protected`, `static`, `final`, `abstract`, ...).
  Needed by role inference to distinguish utility classes from page
  objects, and to detect ThreadLocal driver access.

### Validation on the real sample project

`qamigrate analyze samples/selenium-java-project`:
- Correctly classifies all 14 classes by role
- Detects 53 dependency edges
- Detects method_chaining=YES, logs_every_action=YES, driver_access=
  ThreadLocal, parallel_safe=YES, assertion_style=testng, retry_analyzer=
  YES, @Listeners=TestListener, config_override=System.getProperty ->
  properties_file
- Detects Maven / TestNG 7.8.0 / Selenium 4.16.0 / Log4j2 /
  ExtentReports / 3 env profiles / Java 17 / parallel execution enabled

### Tests (173/173, up from 106 in v0.4.2)

- `tests/test_role_inference.py` -- 21 tests
- `tests/test_convention_detector.py` -- 18 tests
- `tests/test_dependency_graph.py` -- 13 tests
- `tests/test_infrastructure_detector.py` -- 15 tests, 7 against the
  real sample project

### Known limitations

- Python Selenium / JavaScript / C# still not supported -- only Java
- Password-masking convention detection fires only for a narrow set of
  masking patterns (true in the current sample but may miss variants)
- The LLM quality comparison between v0.4.x and v0.5.0 hasn't been
  measured on a live run; if you test and see regressions, that's a
  bug report we want to hear

---

## [0.4.2] - 2026-04-16

**Install UX + README honesty pass.** No code changes beyond packaging
metadata and docs.

### Changed
- **One-command install.** `pip install qamigrate` now bundles both the
  Anthropic and OpenAI SDKs. Previously users had to pick between
  `qamigrate` and `qamigrate[openai]` without a clear way to know which
  they needed. The OpenAI SDK is ~2 MB -- small enough that the
  simplicity is worth the bundle.
- `[openai]` and `[all]` extras are kept as no-op aliases so existing
  `requirements.txt` files pinning them still resolve.

### Docs
- **Honest scope statement.** README now clearly says "Selenium (Java)
  -> Playwright (Java) only" as the supported path in v0.4.x. Python
  / JavaScript support is listed on the roadmap (v0.5.x+) instead of
  being implied by the tagline.
- Install section is now one command, not two.

---

## [0.4.1] - 2026-04-16

**Security + audit pass before first 0.4.x upload to PyPI.**

### Added
- **`escape_for_code_fence` helper** in `qamigrate.llm.sanitize`. Used by
  both CoderAgent and FixerAgent before embedding user Java source into
  markdown-fenced prompt blocks. Neutralizes stray triple-backticks so
  Java 15+ text blocks containing ` ``` ` can't break prompt structure
  and confuse the LLM.
- 4 new tests covering the escape helper: clean source unchanged, text
  blocks with markdown neutralized, single-backtick inline code left
  alone, triple-backtick sequences split safely.

### Audit findings (no action needed, documented for the record)
- `yaml.safe_load` used throughout (no `yaml.load` calls).
- No `subprocess.run(..., shell=True)` anywhere; all subprocess calls
  use argv-list form so paths with spaces / special chars are safe.
- No `eval`, `exec`, or `pickle.load` primitives in the source.
- No bare `except:` or `except Exception: pass` blocks.
- API keys never logged. Provider error messages use `str(e)` from the
  SDK, which does not include the key in either Anthropic or OpenAI.
- Generated file paths use `file_path.name` (original filename from
  `rglob`), not any LLM-controlled string -- no path traversal risk.

### Tests: 106/106 pass (was 102 in v0.4.0-unreleased, 79 in v0.3.1).

---

## [0.4.0] - 2026-04-16 (unreleased)

Originally tagged but not pushed to PyPI. v0.4.1 supersedes it with the
security fix above. All v0.4.0 release notes below apply to v0.4.1 as well.



**Theme: Multi-provider LLM support.** QAMigrate is no longer locked to
Anthropic. Run the Coder on Claude, the Fixer on GPT-4o, or switch both
to OpenAI when your Anthropic credits run out. The abstraction is clean
enough to add Ollama / Gemini / Bedrock in a later release with ~6 hours
of work each.

### Added
- **`qamigrate.llm` package** (`base.py`, `errors.py`, `registry.py`,
  `sanitize.py`, `from_config.py`) with the `LLMProvider` abstract
  interface. Every provider honors one contract: `generate_structured`
  takes a system prompt, user prompt, and tool schema -- returns a
  `StructuredResponse` whose `data` field is a dict matching the schema.
- **`AnthropicProvider`** (`qamigrate.llm.providers.anthropic`) -- the
  reference implementation, carrying forward the exact v0.3.x behavior
  so the refactor doesn't change a single byte for existing users.
- **`OpenAIProvider`** (`qamigrate.llm.providers.openai`) -- uses
  `chat.completions.create` with `tools` and forced `tool_choice`.
  Handles base_url override so Azure OpenAI / LM Studio / vLLM / any
  OpenAI-compatible endpoint "just works."
- **Per-agent provider selection.** Your qamigrate.yaml can now say
  `coder.provider: anthropic` and `fixer.provider: openai` so the
  expensive reasoning happens on one model and the cleanup happens on
  a cheaper one. See `qamigrate.yaml.example` for the full shape.
- **CLI overrides** on `qamigrate migrate`:
  `--provider` / `--model` for both agents,
  `--coder-provider` / `--coder-model`,
  `--fixer-provider` / `--fixer-model`. Per-agent flags win.
- **`openai` optional extra** -- `pip install qamigrate[openai]` to pick
  up the OpenAI SDK only when you want it.
- **`FakeProvider`** in `tests/helpers/fake_provider.py` lets us
  exercise the full pipeline without burning credits. Every new
  provider test uses it.

### Changed
- `CoderAgent` and `FixerAgent` accept an `llm_provider: LLMProvider`
  keyword argument. Default behavior is identical to v0.3.x (builds an
  `AnthropicProvider` internally). All previous code calling
  `CoderAgent(config)` keeps working.
- `run_migration`, `run_generation`, and `run_project_migration` now
  build providers from `config` via `build_provider_for_agent`. Public
  signatures unchanged.
- Shared LLM output sanitizers (`unescape_llm_string`, `sanitize_fields`,
  `strip_stray_markdown`) live in `qamigrate.llm.sanitize` so every
  provider benefits. `CoderAgent._sanitize_fields` etc. are preserved as
  back-compat shims.
- Anthropic SDK types no longer leak past the provider boundary. Agents
  never import `anthropic` directly.

### Config schema additions (back-compat)
```yaml
coder:
  provider: anthropic             # NEW; defaults to "anthropic"
  model: claude-sonnet-4-20250514

fixer:
  provider: anthropic             # NEW; defaults to "anthropic"
  model: claude-sonnet-4-20250514

llm:                              # NEW
  providers:
    anthropic:
      api_key_env: ANTHROPIC_API_KEY
    openai:
      api_key_env: OPENAI_API_KEY
      base_url: null              # override for Azure / LM Studio / proxy
    ollama:
      host: http://localhost:11434
      request_timeout_s: 120
```
Existing v0.3.x YAML files load without changes: the new fields default
to sensible values.

### Tests (102/102, up from 79)
- `tests/test_llm_sanitize.py` -- 13 tests for the shared sanitizers
  (move regression coverage).
- `tests/test_llm_integration.py` -- 3 tests proving agents actually
  respect injected providers and handle `LLMUnavailable` cleanly.
- `tests/test_llm_openai.py` -- 7 tests for the OpenAI provider
  (API key handling, tool-call parsing, JSON validation, base_url).

### Known limitations
- Ollama provider (local models) deferred to v0.4.1. The config scaffolding
  is in place; only the provider module itself is missing.
- Gemini, Bedrock, Azure OpenAI (as a distinct provider) deferred.

---

## [0.3.1] - 2026-04-16

**Theme: Polish from the v0.3.0 test report.** Three user-reported issues
plus the three untested surfaces the tester flagged. No new features --
every change makes the existing v0.3.0 flow safer or cheaper.

### Fixed
- **pom.xml preservation (major).** v0.3.0 used ElementTree to write back
  the pom after adding deps, which stripped every `<!-- comment -->` and
  the `<?xml version="1.0"?>` declaration. On a user's 202-line pom.xml
  we collapsed it to 173 lines of noise. v0.3.1 uses surgical text
  insertion: find the `</dependencies>` tag, insert the new
  `<dependency>` blocks right before it, leave everything else
  byte-for-byte identical. Also detects the existing indent of sibling
  `<dependency>` blocks so the new ones fit in seamlessly.
- **Per-file attempt starvation.** In v0.3.0 the project-wide Fixer loop
  tracked a single "no-progress counter" for the whole batch. If most
  files compiled quickly but one (e.g. `Environment.java` in the
  reporter's project) had a stubborn error, the counter hit its limit
  before the stubborn file got its fair share of attempts. v0.3.1 tracks
  progress per file: each file has its own attempt budget (up to
  `pipeline.max_retries`) and its own two-consecutive-no-progress bailout,
  independent of what's happening in sibling files. A "retired" file
  stops consuming attempts while others keep going.
- **Fixer prompt now explicitly covers enum syntax.** The v0.3.0 report
  showed `enum E { A("a"); B("b"); }` -- `;` instead of `,`. Added a
  dedicated bullet to the Fixer system prompt with the correct rule and
  an example.

### Added (polish)
- **Tighter Fixer system prompt to reduce wasted API calls.** v0.3.0
  regularly returned LLM output that started with prose ("Here's the
  fix:") or contained ` ``` ` fences, which our tree-sitter validator
  correctly rejected -- but that rejection burned a tool call. The
  prompt now explicitly says "return the ORIGINAL source unchanged if
  you're not confident the output will parse" and "no markdown fences,
  no prose outside Java comments." We also call out that the output is
  rejected silently when it fails to parse.

### Tests (now 79/79, was 69/69)
- `tests/test_dependency_injector.py::test_preserves_xml_declaration_and_comments`
  -- regression for the pom.xml stripping bug on a realistic pom with 4
  comments, multi-line `<project>` attributes, and the XML declaration.
- `tests/test_dependency_injector.py::test_no_dependencies_block_creates_one`
  -- edge case where the user's pom has no `<dependencies>` yet; we
  create one right before `</project>` without mangling the XML decl.
- `tests/test_dependency_injector.py::test_line_count_grows_predictably`
  -- two added deps add exactly 12 lines (6 lines each), not "the whole
  file reformatted."
- `tests/test_dependency_injector.py::test_idempotent_byte_for_byte` --
  a second `init --yes` leaves the file byte-for-byte identical so
  `git diff` is empty.
- `tests/test_hallucination.py::test_sensitivity_after_real_method_renamed`
  -- the exact scenario the tester asked about: rename a LoginPage
  method, verify the detector flags the test-class call site.
- `tests/test_pipeline_config.py` -- documents that `batch_compile`
  defaults to True, can be toggled via `--no-batch-compile`, and honors
  the `QAMIGRATE_PIPELINE__BATCH_COMPILE` env var.

### End-to-end validation on selenium-java-project
- pom.xml: 202 -> 214 lines (+12 for 2 deps, exactly as expected).
  All 17 `<!-- ... -->` comments preserved. XML declaration preserved.
  Re-running `init --yes` is a no-op; `git diff` is empty.

---

## [0.3.0] - 2026-04-15

**Theme: Whole-project compile.** Single-file compile was the bottleneck --
LoginPage can't compile without BasePage on the classpath, so every
page-object migration was marked FAIL even when the code was correct.
This release fixes that by compiling the whole project together and
resolving the real Maven classpath.

### Result on the reporter's selenium-java-project (15 files)
- v0.2.2: 7/15 at 70%+ confidence, all via skip-compile fallback
- v0.3.0: **14/15 at 100% compiled** (avg confidence 94%) -- twelve
  files compile cleanly on the first try, one file needs two fix
  iterations, one file still fails (isolated compile errors).

### Added
- **`qamigrate init --yes`** auto-injects Playwright 1.48.0 and
  JUnit Jupiter 5.11.3 into the project's `pom.xml` or `build.gradle`.
  Prompts the user without `--yes`. Idempotent -- re-running is a no-op.
  Gradle Groovy DSL supported; Gradle Kotlin DSL deferred to v0.3.1.
- **`qamigrate.agents.dependency_injector.DependencyInjector`** -- the
  module behind `init`. Preserves XML namespaces so pom.xml doesn't end
  up with `ns0:` prefixes.
- **`qamigrate.agents.classpath.ClasspathResolver`** -- shells out to
  `mvn -q dependency:build-classpath` (60s timeout) and caches the
  resolved JARs in `.qamigrate/classpath.txt`. Gradle classpath is
  deferred to v0.3.1.
- **`qamigrate.agents.pipeline.run_project_migration`** -- the new
  project-level pipeline. Three phases:
  1. Generate all files with scanner + coder (no compile-check yet).
  2. Resolve classpath and batch-compile everything with `javac
     -sourcepath ... -cp ...`.
  3. If there are errors, run the Fixer per file (only its own errors,
     never cross-contaminated), recompile, accept only when errors
     strictly reduce. Stop after `pipeline.max_retries` passes or two
     consecutive non-improvements.
- **`CompilerAgent.group_errors_by_file()`** -- helper that buckets a
  batch-compile result's errors by file path.
- **`FixerAgent.fix_file()`** -- wrapper around `fix()` that filters
  the error list to only those matching the file being fixed.
- **`qamigrate migrate --no-batch-compile`** -- escape hatch to fall
  back to the v0.2 per-file compile loop.
- `PipelineConfig.batch_compile` and `ClasspathConfig` sections in
  `qamigrate.yaml`.

### Fixed
- **`CompilerAgent.compile_batch()` tempdir bug** -- subprocess.run was
  outside the `TemporaryDirectory` context manager, meaning the tempdir
  had already been cleaned up before javac tried to use it. Moved the
  run inside the `with` block.
- **Classpath separator** -- was hard-coded to `;` (Windows). Now uses
  `os.pathsep` so batch compilation works on macOS / Linux.
- **Namespace mangling in pom.xml** -- when adding dependencies via
  ElementTree, the Maven namespace was being renamed to `ns0:` in the
  output. `ET.register_namespace("", maven_ns)` fixes it so the file
  looks normal.

### Developer experience
- Added 23 new tests (69/69 total pass):
  - `tests/test_dependency_injector.py` -- pom.xml (empty, existing
    deps, already-present, malformed) + gradle groovy (no block,
    existing block, idempotent) + Kotlin DSL unsupported.
  - `tests/test_classpath.py` -- mocks subprocess for success,
    not-installed, timeout, non-zero exit, cache hit / miss.
  - `tests/test_compiler_batch.py` -- `group_errors_by_file` and the
    empty-list case.
  - `tests/test_fixer.py::TestFixFilePerFileFiltering` -- ensures
    cross-file errors aren't shown to the per-file fixer.

### Known follow-ups
- One file (`Environment.java`) still fails on the reporter's project
  because its errors are unreachable by the Fixer after earlier files
  absorb attempts. The "rolling back" logic is protecting us but the
  file needs its own fix round.
- Gradle classpath resolution (init script or `./gradlew dependencies`
  parser) -- shipping Maven-only for v0.3.0.
- Gradle Kotlin DSL dep injection -- same.
- Incremental recompile for very large projects (currently always
  compiles everything).

---

## [0.2.2] - 2026-04-15

**Theme: Polish based on second user test report.** Three real issues
surfaced after a second round of testing on the user's project. All fixed
and validated end-to-end: 7/15 files at 70%+ confidence (vs 1/15 in
v0.2.1) with zero cross-file method hallucinations in the test class.

### Fixed
- **`\"` escape leak in generated code.** The LLM occasionally emitted
  literal `\"` sequences inside JSON `tool_use` string fields, which then
  landed in the generated Java as `page.locator(\\"#id\\")`. Added a
  sanitization pass at the tool-response parse boundary that unescapes
  `\\n`, `\\t`, `\\"`, and `\\'` from every string field before
  rendering. This was the single highest-ROI fix -- it flips several
  files from FAIL to PASS.
- **Cross-file method hallucinations.** Test classes no longer invent
  methods like `getSuccessIndicator()` or `getErrorElement()` on migrated
  page objects. Strengthened the Coder prompt to explicitly list allowed
  methods and forbid inventing new ones, with specific guidance on
  TestNG -> JUnit 5 annotation translation (`@Test(description="X")` ->
  `@Test` + `@DisplayName("X")` separately).
- **False compile failures when Playwright JAR is missing.** Previously
  the pipeline would burn API calls trying to "fix" `package
  com.microsoft.playwright does not exist` errors that the LLM can't
  resolve. Added classpath-issue detection on the first compile attempt:
  if more than half the errors look like classpath problems (missing
  Playwright package or cannot-find-symbol for Playwright types), the
  pipeline skips compilation validation, marks the file with 70%
  confidence (generated but not verified), and prints a helpful
  `Note:` at the end of the run with the pom.xml snippet to add.

### Added
- **Cross-file hallucination detector** (`qamigrate.core.hallucination`).
  Scans generated code for calls to methods on sibling classes that
  don't exist in those classes' public APIs. Suggests the closest real
  method name when one exists. Hallucinations appear in the console
  summary, the report (HTML/JSON/Markdown), and subtract 10 points each
  from confidence down to a floor of 20.
- **`MigrationRecord.hallucinations: list[Hallucination]`** field in the
  report data model.
- **CLI surfaces classpath issues** with an actionable pom.xml snippet
  when all files skip compilation due to missing Playwright.
- **10 new tests** (47 total) covering the unescape sanitizer, the
  hallucination detector, and confidence penalties.

### Changed
- `CoderAgent._sanitize_fields` is called on every `tool_use` response.
- `MigrationReport` HTML and Markdown outputs include a hallucinations
  section when any are present.
- Confidence scoring factored into two pieces: `_base_confidence()` and
  a hallucination penalty that applies on top.

### Results on the reporter's selenium-java-project (15 files)
- v0.2.1: 1/15 succeeded, 14 FAIL with uncompilable output.
- v0.2.2: 7/15 at 70%+ confidence, 2 fully compiled, remaining 6 failed
  because they reference app-internal classes (`DriverManager`, `Log`,
  `ExtentManager`) that can't be resolved when compiling single files --
  a separate problem to tackle in a later release.

---

## [0.2.1] - 2026-04-15

**Theme: Fix what v0.2.0 broke in real projects.** A user tested on a real
Selenium project and found the compile-fix loop was destructive and `--all`
missed most files. All six reported bugs are fixed.

### Fixed
- **Windows Unicode crash.** `qamigrate init` on Windows crashed with
  `UnicodeEncodeError: '\u2713'` because Rich emits box-drawing characters
  to a `cp1252` stdout. CLI now reconfigures stdout/stderr to UTF-8 on
  startup, and all Unicode glyphs in the CLI output have been replaced
  with ASCII-safe equivalents (`OK`, `FAIL`, `->`, etc.).
- **`--all` only finding `@Test` files.** The file-discovery loop stopped at
  the first directory under `src/` that had Java files, so it would pick
  `src/test/` and miss everything under `src/main/`. Fixed to walk the
  entire project (excluding `target`, `build`, `node_modules`, `playwright`,
  `.git`, `.venv`, `.idea`). Files are now also sorted so base classes and
  page objects are migrated before tests that depend on them.
- **Destructive compile-fix loop.** This was the headline defect: the
  fixer was splicing LLM prose like "Add this import at the top" into
  `.java` files, creating invalid output from valid first-draft code. Two
  changes:
  1. **Fixer rewrite.** The LLM fixer now uses Anthropic tool use
     (`emit_fixed_java` tool) to return the whole corrected file as a
     structured field. It cannot emit free-form text any more. The output
     is validated with tree-sitter before being accepted -- if it contains
     ERROR nodes, no top-level `class_declaration`, or is implausibly
     short, the fix is rejected.
  2. **Non-regressing pipeline.** The pipeline now tracks the best version
     seen so far (fewest errors). If a fix attempt produces more errors
     than the previous best, the pipeline rolls back to the best version.
     After two consecutive non-improvements, the loop stops early and
     keeps the best output. You no longer get degraded garbage after
     starting with working code.
- **Cross-file context.** When migrating a test class that imports a
  sibling page object, the Coder now receives the signatures of the
  already-migrated Playwright version of that sibling. The test class
  calls `new LoginPage(page)` (the real Playwright constructor) instead
  of inventing method names.
- **Confidence scoring.** The old scale gave 0 or 100 with almost no
  middle ground. Rewritten to 0-100 with honest tiers: 100 (first-try
  compile), 90 (1-2 fixes), 80 (many fixes), 70 (skipped compile),
  50 (didn't compile but output exists for review), 0 (no output).
- **Hours-saved metric.** Was counting every detected pattern, including
  from failed migrations. Now only counts patterns from files with
  confidence >= 70 -- if we didn't actually migrate the file, we don't
  claim credit for saving you time on it.
- **Escaped newlines in generated constructors.** LLM tool_use output
  occasionally contained literal `\n` (backslash-n, two chars) instead of
  real newlines, collapsing the constructor onto a single unreadable
  line. The reindenter now detects and unescapes this.

### Changed
- `FixerAgent` now returns the ORIGINAL code unchanged when no strategy
  worked, instead of returning half-applied partial fixes.
- Pipeline always fixes from the best version seen so far, not from
  whatever drifted version is currently on disk.
- CLI prints `[OK]`/`[FAIL]` tags instead of `OK`/`FAIL` for consistency.
- README has accurate output examples and honest confidence language.

### Removed
- `cli/main.py`: Unicode glyphs (check, cross, warning, rocket, chart,
  star, magnifying glass) replaced with ASCII.
- `reports.py` constants that referenced removed modules.

### Added
- `MigrationResult.class_name` and `MigrationResult.generated_signatures`
  so callers can thread context between files.
- `CoderAgent.extract_signatures()` helper.
- `CoderAgent.generate_from_class_info(..., sibling_signatures=...)`
  parameter.
- `run_migration(..., sibling_signatures=...)` parameter.
- `tests/test_fixer.py` with 8 new tests covering validation, markdown
  stripping, and escaped-newline handling.
- 8 more tests total (26 -> 34). All pass.

### Developer experience
- Removed stale dependency chain that referenced deleted modules.
- Fixed XML-element truthiness warning in scanner.
- `qamigrate --version` reports 0.2.1.

---

## [0.2.0] - 2026-04-15

**Theme: Trust & Evidence.** You no longer just get migrated code — you get proof of what changed, how confident we are, and how much time you saved.

### Added
- **Migration Report** in three formats: HTML, JSON, and Markdown
  - Per-file records with detected patterns, confidence score, compilation status, and before/after diff
  - Batch-level metrics: files succeeded/failed, patterns handled, average confidence, estimated hours saved
  - HTML report includes side-by-side diff viewer (stdlib `difflib`) with dark theme
- **`--dry-run` flag** on `qamigrate migrate`: scan all target files and preview patterns without calling the LLM or writing output
- **`--report <dir>` flag** on `qamigrate migrate`: writes `report.html`, `report.json`, `report.md` to the specified directory
- **`compiler.skip`** config option: skip compilation validation when Playwright JARs aren't available locally
- **Confidence scoring** per file (0-100) derived from success + compilation attempts
- **Time-saved estimate** based on ~15 min of manual effort per pattern

### Changed
- Simplified pipeline: `SupervisorConfig` renamed to `PipelineConfig`
- `QAMigrateConfig` now uses `pipeline.max_retries` instead of `supervisor.max_retries`
- `run_migration()` now returns a `MigrationResult` with an attached `MigrationRecord`
- CLI `migrate` command output: per-file status with confidence score, summary table with batch metrics

### Removed
- Dead modules: `supervisor.py`, `visual.py`, `utom.py`, `test_cleanup.py`, `languages.py`, `pdf_reports.py`, `dependencies.py`, `parallel.py`, `security.py`, `reports.py`, `database.py`, `integrations/jira_client.py`, `cli/interactive.py`
- Old web server (`server/`) and React dashboard (`dashboard/`) — will return in v0.3.0 once backed by the new report format
- CLI commands: `verify` (visual agent was mocked), `export` (superseded by `migrate --report`), `dashboard` (temporarily removed)
- Unused config sections: `visual`, `docker`, `server`, `quality_gates`
- Unused dependencies: `httpx`, `email-validator`, `fastapi`, `uvicorn`, `websockets`, `docker`, `opencv-python`, `pillow`, `imagehash`, `numpy`, `openai`

### Fixed
- `datetime.utcnow()` deprecation warnings on Python 3.12+ (now using `datetime.now(timezone.utc)`)
- Maven `pom.xml` element truthiness deprecation warnings in scanner
- CLI `--all` no longer requires the optional `DependencyAnalyzer` — walks `src/test` then `src/` directly

### Developer experience
- Added `tests/test_report.py` (13 new tests covering report rendering and confidence scoring)
- All 25 tests pass with no warnings

---

## [0.1.0] - 2026-04-14

### Added
- Initial release.
- Selenium Java -> Playwright Java migration pipeline:
  - **Scanner** (Tree-sitter, 70+ pattern queries)
  - **Coder** (Claude tool use for structured output)
  - **Compiler** (javac validation)
  - **Fixer** (rule-based + LLM error remediation with up to 3 retries)
- CLI commands: `init`, `scan`, `migrate`
- Validated end-to-end on real Selenium files covering `@FindBy`, `PageFactory`, `WebDriverWait`, `Actions`, `Select`, alerts, iframes, `JavascriptExecutor`, file uploads, TestNG inheritance, and `@DataProvider`.
