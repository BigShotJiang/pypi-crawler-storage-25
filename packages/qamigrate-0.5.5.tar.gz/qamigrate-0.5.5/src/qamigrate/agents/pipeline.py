"""
Migration Pipeline.

Plain Python pipeline that runs the migration workflow:
Scanner -> Coder -> Compiler -> Fixer (retry loop) -> Done.

Replaces the LangGraph-based graph.py with a simple, debuggable flow.
"""

import re
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import structlog

from qamigrate.agents.classpath import ClasspathResolver
from qamigrate.agents.coder import CoderAgent
from qamigrate.agents.compiler import CompilerAgent, CompilerError, ErrorType
from qamigrate.agents.fixer import FixerAgent
from qamigrate.agents.scanner import ScannerAgent
from qamigrate.agents.state import MigrationState, Phase, _utcnow_iso, create_initial_state
from qamigrate.core.config import QAMigrateConfig
from qamigrate.core.hallucination import (
    DeclaredSelectors,
    detect_hallucinations,
    detect_selector_hallucinations,
    extract_declared_selectors,
)
from qamigrate.core.report import Hallucination, MigrationRecord, PatternSummary

logger = structlog.get_logger(__name__)


@dataclass
class MigrationResult:
    """Result of a migration run."""

    success: bool
    file_path: str
    output_path: str | None
    error: str | None
    compilation_attempts: int
    final_state: MigrationState
    record: MigrationRecord | None = None
    # Signatures of public methods / constructor of the generated class.
    # Callers can pass these as `sibling_signatures` when migrating later
    # files so dependent classes call real methods instead of invented ones.
    class_name: str | None = None
    generated_signatures: list[str] = field(default_factory=list)


def run_migration(
    file_path: Path,
    project_path: Path,
    config: QAMigrateConfig | None = None,
    on_phase: Callable[[Phase, MigrationState], None] | None = None,
    sibling_signatures: dict[str, list[str]] | None = None,
) -> MigrationResult:
    """
    Run the migration pipeline for a single file.

    Pipeline: Scanner -> Coder -> Compiler -> (Fixer -> Compiler)* -> Done

    Args:
        file_path: Path to the Java file to migrate
        project_path: Root path of the project
        config: Optional configuration
        on_phase: Optional callback fired on each phase transition

    Returns:
        MigrationResult with outcome
    """
    config = config or QAMigrateConfig()
    max_retries = config.pipeline.max_retries
    started = time.time()

    # v0.5.1: passthrough path for files with no Selenium markers (enums,
    # pure-data classes). Copy them verbatim instead of pushing them
    # through the LLM where the tool schema mangles them.
    from qamigrate.intelligence.passthrough import (
        is_passthrough,
        rewrite_package_for_passthrough,
    )

    passthrough, reason = is_passthrough(file_path)
    if passthrough:
        try:
            original_code = file_path.read_text(encoding="utf-8")
            # v0.5.4: rewrite `package X;` → `package X.playwright;` so
            # the copied file doesn't collide with the original Selenium
            # class in Maven's joint compilation.
            output_code = rewrite_package_for_passthrough(original_code)
            output_path = file_path.parent / "playwright" / file_path.name
            output_path.parent.mkdir(parents=True, exist_ok=True)
            output_path.write_text(output_code, encoding="utf-8")
            logger.info(
                "Pipeline: passthrough",
                file=str(file_path),
                reason=reason,
            )
            state = create_initial_state(
                file_path=str(file_path),
                project_path=str(project_path),
            )
            state["phase"] = Phase.COMPLETE
            record = MigrationRecord(
                source_path=str(file_path),
                output_path=str(output_path),
                success=True,
                duration_seconds=round(time.time() - started, 2),
                patterns=[],
                compilation_attempts=0,
                compiled=None,
                original_lines=len(original_code.splitlines()),
                generated_lines=len(output_code.splitlines()),
                error=None,
                original_code=original_code,
                generated_code=output_code,
            )
            return MigrationResult(
                success=True,
                file_path=str(file_path),
                output_path=str(output_path),
                error=None,
                compilation_attempts=0,
                final_state=state,
                record=record,
            )
        except OSError as e:  # pragma: no cover
            logger.warning(
                "Pipeline: passthrough failed, falling through to LLM",
                file=str(file_path),
                error=str(e),
            )

    # Build LLM providers from config so each agent uses whatever provider
    # the user selected (Anthropic, OpenAI, Ollama, ...).
    from qamigrate.llm.from_config import build_provider_for_agent

    coder_provider = build_provider_for_agent(config, "coder")
    fixer_provider = build_provider_for_agent(config, "fixer")

    # Initialize agents
    scanner = ScannerAgent(config.scanner)
    coder = CoderAgent(config.coder, llm_provider=coder_provider)
    compiler = CompilerAgent(config.compiler)
    fixer = FixerAgent(config.fixer, llm_provider=fixer_provider)

    # Create initial state
    state = create_initial_state(
        file_path=str(file_path),
        project_path=str(project_path),
    )

    def _notify(phase: Phase) -> None:
        state["phase"] = phase
        state["updated_at"] = _utcnow_iso()
        if on_phase:
            on_phase(phase, state)

    def _build_record(
        success: bool,
        output_path_str: str | None,
        error: str | None,
        compiled: bool | None,
        attempts: int,
    ) -> MigrationRecord:
        """Build a MigrationRecord from current state."""
        pattern_counts: dict[str, tuple[int, str]] = {}
        for p in state.get("patterns", []):
            ptype = p.get("pattern_type", "unknown")
            strategy = p.get("migration_strategy", "")
            if ptype in pattern_counts:
                pattern_counts[ptype] = (pattern_counts[ptype][0] + 1, strategy)
            else:
                pattern_counts[ptype] = (1, strategy)

        patterns = [
            PatternSummary(pattern_type=ptype, count=count, migration_strategy=strat)
            for ptype, (count, strat) in pattern_counts.items()
        ]

        original_code = state.get("original_code", "") or ""
        generated_code = state.get("generated_code", "") or ""

        # Check for cross-file hallucinations (calls to methods that don't
        # exist on already-migrated sibling classes).
        hallucinations: list[Hallucination] = []
        if sibling_signatures and generated_code:
            hallucinations = detect_hallucinations(generated_code, sibling_signatures)
            if hallucinations:
                logger.warning(
                    "Pipeline: detected cross-file hallucinations",
                    count=len(hallucinations),
                    file=str(file_path),
                    details=[h.called_method for h in hallucinations],
                )

        return MigrationRecord(
            source_path=str(file_path),
            output_path=output_path_str,
            success=success,
            duration_seconds=round(time.time() - started, 2),
            patterns=patterns,
            compilation_attempts=attempts,
            compiled=compiled,
            original_lines=len(original_code.splitlines()),
            generated_lines=len(generated_code.splitlines()),
            error=error,
            original_code=original_code,
            generated_code=generated_code,
            hallucinations=hallucinations,
        )

    try:
        # --- SCAN ---
        logger.info("Pipeline: scanning", file=str(file_path))
        _notify(Phase.INIT)

        analysis = scanner.scan_file(file_path)
        state["ast_data"] = analysis.class_info
        state["patterns"] = [
            {
                "pattern_type": p.pattern_type,
                "line_number": p.line_number,
                "migration_strategy": p.migration_strategy,
            }
            for p in analysis.patterns
        ]
        state["complexity_score"] = analysis.complexity_score
        state["original_code"] = file_path.read_text(encoding="utf-8")
        _notify(Phase.SCANNED)

        # --- GENERATE ---
        logger.info("Pipeline: generating Playwright code", file=str(file_path))

        result = coder.generate_from_class_info(
            class_info=state["ast_data"] or {},
            original_code=state["original_code"],
            patterns=state["patterns"],
            sibling_signatures=sibling_signatures,
        )
        generated_code = coder.assemble_file(result)
        generated_class_name = result.class_declaration.strip().split()[-1].rstrip("{").strip()
        generated_signatures = CoderAgent.extract_signatures(result)

        output_path = file_path.parent / "playwright" / file_path.name
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(generated_code, encoding="utf-8")

        state["generated_code"] = generated_code
        state["generated_file_path"] = str(output_path)
        state["output_path"] = str(output_path)
        _notify(Phase.GENERATED)

        # --- SKIP COMPILATION IF CONFIGURED ---
        if config.compiler.skip:
            logger.info(
                "Pipeline: compilation skipped (compiler.skip=true)",
                file=str(file_path),
                output=str(output_path),
            )
            _notify(Phase.COMPILED)
            return MigrationResult(
                success=True,
                file_path=str(file_path),
                output_path=str(output_path),
                error=None,
                compilation_attempts=0,
                final_state=state,
                record=_build_record(
                    success=True,
                    output_path_str=str(output_path),
                    error=None,
                    compiled=None,
                    attempts=0,
                ),
                class_name=generated_class_name,
                generated_signatures=generated_signatures,
            )

        # --- COMPILE + FIX LOOP (non-regressing) ---
        # We keep the "best" version seen so far (fewest errors). A fix is
        # only accepted if it strictly reduces the error count. If the fixer
        # makes things worse, we roll back and try a different error the
        # next iteration. Bail out early if we can't make progress.
        best_code: str = state["generated_code"] or ""
        best_error_count: int | None = None
        no_progress_count = 0

        def _looks_like_classpath_issue(compile_result: Any) -> bool:
            """
            Detect 'package com.microsoft.playwright does not exist' and the
            downstream 'cannot find symbol' errors for Playwright types that
            follow. Trying to "fix" these with the LLM is hopeless -- the
            generated code is fine, we just have no Playwright JAR on the
            compile classpath.
            """
            if not compile_result.errors:
                return False

            # Known Playwright type names that show up in "cannot find symbol"
            # when the JAR is missing.
            playwright_types = {
                "Page", "Locator", "Browser", "BrowserContext", "BrowserType",
                "Playwright", "PlaywrightAssertions", "AriaRole", "SelectOption",
                "FileChooser", "Dialog", "Download", "Frame", "ElementHandle",
                "JSHandle", "Route", "Request", "Response", "TimeoutError",
            }

            classpath_errors = 0
            has_playwright_package_missing = False
            for e in compile_result.errors:
                # javac puts the real detail ("symbol: class Locator") in a
                # multi-line context block following the top-level "cannot
                # find symbol" message, so we need to check both fields.
                full_text = f"{e.message}\n{e.code_context or ''}"
                if "com.microsoft.playwright" in full_text and "does not exist" in full_text:
                    classpath_errors += 1
                    has_playwright_package_missing = True
                elif "cannot find symbol" in full_text.lower():
                    if any(f"class {t}" in full_text or f"symbol: {t}" in full_text
                           for t in playwright_types):
                        classpath_errors += 1
                    elif "class BasePage" in full_text or "class BaseTest" in full_text:
                        # Cross-file base classes under migration -- same root cause.
                        classpath_errors += 1

            # Require at least one explicit "package does not exist" and that
            # the classpath-looking errors are the majority -- otherwise we
            # might be masking real code bugs.
            if not has_playwright_package_missing:
                return False
            return classpath_errors * 2 >= len(compile_result.errors)

        for attempt in range(max_retries + 1):
            logger.info(
                "Pipeline: compiling",
                file=str(output_path),
                attempt=attempt + 1,
            )

            compile_result = compiler.compile_single_file(output_path)
            current_error_count = len(compile_result.errors)

            # Detect the "user hasn't added Playwright to their pom.xml yet"
            # case on the first attempt. Bailing here avoids burning API calls
            # on a classpath problem the LLM can't solve.
            if attempt == 0 and _looks_like_classpath_issue(compile_result):
                logger.warning(
                    "Pipeline: classpath issue detected "
                    "(Playwright JAR not on the compile classpath). "
                    "Generated code looks correct; skipping compilation check.",
                    file=str(file_path),
                )
                state["compilation_result"] = compile_result.to_dict()
                state["compilation_errors"] = []
                state["retry_count"] = 0
                _notify(Phase.COMPILED)
                return MigrationResult(
                    success=True,
                    file_path=str(file_path),
                    output_path=str(output_path),
                    error=None,
                    compilation_attempts=0,
                    final_state=state,
                    record=_build_record(
                        success=True,
                        output_path_str=str(output_path),
                        error=None,
                        compiled=None,  # None = skipped, not False = failed
                        attempts=0,
                    ),
                    class_name=generated_class_name,
                    generated_signatures=generated_signatures,
                )

            if compile_result.success:
                state["compilation_result"] = compile_result.to_dict()
                state["compilation_errors"] = []
                state["retry_count"] = attempt
                _notify(Phase.COMPILED)
                break

            # Compilation failed. Check if this version is better than the
            # best we've seen. If it's worse, roll back to best and log it.
            if best_error_count is None or current_error_count < best_error_count:
                best_code = output_path.read_text(encoding="utf-8")
                best_error_count = current_error_count
                no_progress_count = 0
            else:
                # This attempt was the same or worse than the last best.
                logger.warning(
                    "Pipeline: fix did not reduce errors; rolling back",
                    current_errors=current_error_count,
                    best_errors=best_error_count,
                )
                output_path.write_text(best_code, encoding="utf-8")
                state["generated_code"] = best_code
                no_progress_count += 1
                # Re-run compile on the rolled-back code so our error list
                # reflects the actual current state.
                compile_result = compiler.compile_single_file(output_path)
                current_error_count = len(compile_result.errors)

            state["compilation_result"] = compile_result.to_dict()
            state["compilation_errors"] = [e.to_dict() for e in compile_result.errors]
            state["retry_count"] = attempt + 1
            _notify(Phase.COMPILATION_FAILED)

            # Stop early if we've had two consecutive non-improvements.
            # Banging the LLM against the same code is expensive and
            # usually fruitless.
            if no_progress_count >= 2:
                logger.warning(
                    "Pipeline: no progress for 2 consecutive attempts; stopping early",
                    best_errors=best_error_count,
                )
                output_path.write_text(best_code, encoding="utf-8")
                state["generated_code"] = best_code
                _notify(Phase.FAILED)
                return MigrationResult(
                    success=False,
                    file_path=str(file_path),
                    output_path=str(output_path),
                    error=(
                        f"Compilation failed with {best_error_count} error(s); "
                        f"fixer could not make further progress after {attempt + 1} attempts"
                    ),
                    compilation_attempts=attempt + 1,
                    final_state=state,
                    record=_build_record(
                        success=False,
                        output_path_str=str(output_path),
                        error=(
                            f"Compilation failed with {best_error_count} error(s) "
                            "after the fixer stopped making progress"
                        ),
                        compiled=False,
                        attempts=attempt + 1,
                    ),
                    class_name=generated_class_name,
                    generated_signatures=generated_signatures,
                )

            if attempt >= max_retries:
                logger.warning(
                    "Pipeline: max retries reached",
                    file=str(file_path),
                    attempts=attempt + 1,
                    best_errors=best_error_count,
                )
                output_path.write_text(best_code, encoding="utf-8")
                state["generated_code"] = best_code
                _notify(Phase.FAILED)
                return MigrationResult(
                    success=False,
                    file_path=str(file_path),
                    output_path=str(output_path),
                    error=f"Compilation failed with {best_error_count} error(s) after {attempt + 1} attempts",
                    compilation_attempts=attempt + 1,
                    final_state=state,
                    record=_build_record(
                        success=False,
                        output_path_str=str(output_path),
                        error=f"Compilation failed with {best_error_count} error(s) after {attempt + 1} attempts",
                        compiled=False,
                        attempts=attempt + 1,
                    ),
                    class_name=generated_class_name,
                    generated_signatures=generated_signatures,
                )

            # --- FIX ---
            logger.info(
                "Pipeline: fixing errors",
                error_count=current_error_count,
                attempt=attempt + 1,
            )

            errors = []
            for e in state.get("compilation_errors", []):
                error_type_str = e.get("error_type", "unknown")
                try:
                    error_type = ErrorType(error_type_str)
                except ValueError:
                    error_type = ErrorType.UNKNOWN

                errors.append(CompilerError(
                    file_path=e["file_path"],
                    line_number=e["line_number"],
                    column=e["column"],
                    error_type=error_type,
                    message=e["message"],
                    code_context=e.get("code_context", ""),
                ))

            fixed_code, changes = fixer.fix(
                code=best_code,  # always fix from the best version, not drifted
                errors=errors,
                retry_count=attempt,
            )

            # If the fixer returned the same code, we're stuck -- count this
            # as no-progress so we bail out faster.
            if fixed_code == best_code:
                no_progress_count += 1

            output_path.write_text(fixed_code, encoding="utf-8")
            state["generated_code"] = fixed_code
            state["fix_changes"] = state.get("fix_changes", []) + changes
            _notify(Phase.FIXED)

        # If we got here via break (compilation succeeded)
        if state["phase"] == Phase.COMPILED:
            attempts = state.get("retry_count", 0)
            logger.info(
                "Pipeline: migration successful",
                file=str(file_path),
                output=str(output_path),
                attempts=attempts + 1,
            )
            return MigrationResult(
                success=True,
                file_path=str(file_path),
                output_path=str(output_path),
                error=None,
                compilation_attempts=attempts,
                final_state=state,
                record=_build_record(
                    success=True,
                    output_path_str=str(output_path),
                    error=None,
                    compiled=True,
                    attempts=attempts,
                ),
                class_name=generated_class_name,
                generated_signatures=generated_signatures,
            )

        # Should not reach here, but handle gracefully
        return MigrationResult(
            success=False,
            file_path=str(file_path),
            output_path=state.get("output_path"),
            error="Pipeline ended in unexpected state",
            compilation_attempts=state.get("retry_count", 0),
            final_state=state,
            record=_build_record(
                success=False,
                output_path_str=state.get("output_path"),
                error="Pipeline ended in unexpected state",
                compiled=None,
                attempts=state.get("retry_count", 0),
            ),
        )

    except Exception as e:
        logger.error("Pipeline: migration failed", error=str(e), file=str(file_path))
        state["phase"] = Phase.FAILED
        state["errors"].append({
            "phase": state.get("phase", Phase.INIT).value if isinstance(state.get("phase"), Phase) else "init",
            "error_type": type(e).__name__,
            "message": str(e),
            "timestamp": _utcnow_iso(),
        })
        return MigrationResult(
            success=False,
            file_path=str(file_path),
            output_path=state.get("output_path"),
            error=str(e),
            compilation_attempts=state.get("retry_count", 0),
            final_state=state,
            record=_build_record(
                success=False,
                output_path_str=state.get("output_path"),
                error=str(e),
                compiled=None,
                attempts=state.get("retry_count", 0),
            ),
        )


def run_batch_migration(
    files: list[Path],
    project_path: Path,
    config: QAMigrateConfig | None = None,
    on_progress: Callable[[int, int, MigrationResult], None] | None = None,
) -> list[MigrationResult]:
    """
    Run migration for multiple files.

    Args:
        files: List of Java files to migrate
        project_path: Root path of the project
        config: Optional configuration
        on_progress: Optional callback for progress updates

    Returns:
        List of MigrationResult for each file
    """
    results: list[MigrationResult] = []

    for i, file_path in enumerate(files):
        logger.info(f"Migrating file {i + 1}/{len(files)}", file=str(file_path))

        result = run_migration(file_path, project_path, config)
        results.append(result)

        if on_progress:
            on_progress(i + 1, len(files), result)

    success_count = sum(1 for r in results if r.success)
    logger.info(
        "Batch migration complete",
        total=len(files),
        success=success_count,
        failed=len(files) - success_count,
    )

    return results


# =====================================================================
# Project-level pipeline (v0.3+)
# =====================================================================


@dataclass
class GenerationResult:
    """Outcome of the generation-only phase for a single file."""

    source_path: Path
    output_path: Path | None
    success: bool
    error: str | None
    class_name: str | None
    signatures: list[str]
    analysis_patterns: list[dict[str, Any]]
    original_code: str
    generated_code: str
    duration_seconds: float


def run_generation(
    file_path: Path,
    project_path: Path,
    config: QAMigrateConfig,
    sibling_signatures: dict[str, list[str]] | None = None,
    project_map: "Any" = None,
) -> GenerationResult:
    """
    Scan + generate for a single file. Writes the output to disk but does
    NOT compile or fix. Used as the first phase of `run_project_migration`.

    When `project_map` is supplied (v0.5+), we build a per-file "project
    context" block and pass it to the Coder so generated code preserves
    the project's conventions (method chaining, logging, etc.).
    """
    from qamigrate.intelligence.passthrough import (
        build_signatures_from_class_info,
        is_passthrough,
        rewrite_package_for_passthrough,
    )
    from qamigrate.llm.from_config import build_provider_for_agent

    started = time.time()

    # v0.5.1: passthrough path for files that don't need migration
    # (enums, constants classes without Selenium markers). Skipping the
    # LLM call here eliminates a whole class of hallucinations where a
    # correct enum gets "migrated" into broken Java.
    #
    # v0.5.2(a): Parse the original source so sibling tests that IMPORT
    # this enum see its real constants/methods in their Coder prompt --
    # otherwise the LLM hallucinates `Environment.DEVELOPMENT` instead
    # of the real `Environment.DEV`.
    passthrough, reason = is_passthrough(file_path)
    if passthrough:
        try:
            original_code = file_path.read_text(encoding="utf-8")
            # v0.5.4: rewrite package declaration to .playwright suffix so
            # the copied file doesn't collide with the original in Maven.
            output_code = rewrite_package_for_passthrough(original_code)
            output_path = file_path.parent / "playwright" / file_path.name
            output_path.parent.mkdir(parents=True, exist_ok=True)
            output_path.write_text(output_code, encoding="utf-8")

            # Still run the scanner so we can contribute this file's API
            # to sibling_signatures. If scanning fails, degrade gracefully
            # to empty signatures -- passthrough correctness shouldn't
            # depend on parser robustness.
            class_name: str | None = file_path.stem
            signatures: list[str] = []
            try:
                scanner = ScannerAgent(config.scanner)
                analysis = scanner.scan_file(file_path)
                if analysis.class_info.get("class_name"):
                    class_name = analysis.class_info["class_name"]
                signatures = build_signatures_from_class_info(analysis.class_info)
            except Exception as e:  # pragma: no cover - defensive
                logger.debug(
                    "Pipeline: passthrough signature extraction failed",
                    file=str(file_path),
                    error=str(e),
                )

            logger.info(
                "Pipeline: passthrough",
                file=str(file_path),
                reason=reason,
                signatures=len(signatures),
            )
            return GenerationResult(
                source_path=file_path,
                output_path=output_path,
                success=True,
                error=None,
                class_name=class_name,
                signatures=signatures,
                analysis_patterns=[],
                original_code=original_code,
                generated_code=output_code,
                duration_seconds=round(time.time() - started, 2),
            )
        except OSError as e:  # pragma: no cover - defensive
            logger.warning(
                "Pipeline: passthrough failed, falling through to LLM",
                file=str(file_path),
                error=str(e),
            )

    scanner = ScannerAgent(config.scanner)
    coder = CoderAgent(
        config.coder,
        llm_provider=build_provider_for_agent(config, "coder"),
    )

    try:
        analysis = scanner.scan_file(file_path)
        original_code = file_path.read_text(encoding="utf-8")
        patterns_list = [
            {
                "pattern_type": p.pattern_type,
                "line_number": p.line_number,
                "migration_strategy": p.migration_strategy,
            }
            for p in analysis.patterns
        ]

        # v0.5+: build the project-context prompt block for this file
        project_context_text: str | None = None
        if project_map is not None:
            # Work out the fully-qualified name of the class being migrated
            # so we can zoom in on its direct dependencies.
            migrating_fqn = None
            class_name = analysis.class_info.get("class_name")
            pkg = analysis.class_info.get("package") or ""
            if class_name:
                migrating_fqn = f"{pkg}.{class_name}" if pkg else class_name
            from qamigrate.intelligence.prompt_context import format_project_context
            project_context_text = format_project_context(
                project_map, migrating_fqn=migrating_fqn,
            )

        result = coder.generate_from_class_info(
            class_info=analysis.class_info,
            original_code=original_code,
            patterns=patterns_list,
            sibling_signatures=sibling_signatures,
            project_context=project_context_text,
        )
        generated_code = coder.assemble_file(result)
        generated_class_name = result.class_declaration.strip().split()[-1].rstrip("{").strip()
        signatures = CoderAgent.extract_signatures(result)

        output_path = file_path.parent / "playwright" / file_path.name
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(generated_code, encoding="utf-8")

        return GenerationResult(
            source_path=file_path,
            output_path=output_path,
            success=True,
            error=None,
            class_name=generated_class_name,
            signatures=signatures,
            analysis_patterns=patterns_list,
            original_code=original_code,
            generated_code=generated_code,
            duration_seconds=round(time.time() - started, 2),
        )
    except Exception as e:
        logger.error("run_generation failed", file=str(file_path), error=str(e))
        return GenerationResult(
            source_path=file_path,
            output_path=None,
            success=False,
            error=str(e),
            class_name=None,
            signatures=[],
            analysis_patterns=[],
            original_code="",
            generated_code="",
            duration_seconds=round(time.time() - started, 2),
        )


def _build_record_from_generation(
    gen: GenerationResult,
    *,
    compiled: bool | None,
    attempts: int,
    error: str | None = None,
    hallucinations: list[Hallucination] | None = None,
) -> MigrationRecord:
    """Build a MigrationRecord from a GenerationResult + compile outcome."""
    pattern_counts: dict[str, tuple[int, str]] = {}
    for p in gen.analysis_patterns:
        ptype = p.get("pattern_type", "unknown")
        strategy = p.get("migration_strategy", "")
        count, _ = pattern_counts.get(ptype, (0, strategy))
        pattern_counts[ptype] = (count + 1, strategy)

    patterns = [
        PatternSummary(pattern_type=ptype, count=count, migration_strategy=strat)
        for ptype, (count, strat) in pattern_counts.items()
    ]

    return MigrationRecord(
        source_path=str(gen.source_path),
        output_path=str(gen.output_path) if gen.output_path else None,
        success=(gen.success and (compiled is True or compiled is None)),
        duration_seconds=gen.duration_seconds,
        patterns=patterns,
        compilation_attempts=attempts,
        compiled=compiled,
        original_lines=len(gen.original_code.splitlines()),
        generated_lines=len(gen.generated_code.splitlines()),
        error=error or gen.error,
        original_code=gen.original_code,
        generated_code=gen.generated_code,
        hallucinations=hallucinations or [],
    )


@dataclass
class ProjectMigrationResult:
    """Aggregate result of a project-level migration."""

    records: list[MigrationRecord]
    classpath_reason: str | None  # Populated when we fell back to skip-compile
    compiled_count: int
    failed_count: int


_PACKAGE_RE = re.compile(r"^\s*package\s+([\w.]+)\s*;", re.MULTILINE)

# Matches a single Java import line, capturing the full qualified name.
# Group 1 = everything before the semicolon (e.g. "com.example.pages.LoginPage").
_IMPORT_LINE_RE = re.compile(r"^(\s*import\s+)([\w.]+)(\s*;)", re.MULTILINE)


def _rewrite_sibling_imports(generations: "list[GenerationResult]") -> None:
    """v0.5.5 Fix #1: rewrite import statements that reference migrated sibling
    classes to use their new `.playwright` package path.

    After migration every class `Foo` in package `com.x.y` moves to
    `com.x.y.playwright.Foo`. Other generated files that import `Foo` still
    carry `import com.x.y.Foo;` from the original source. This makes the
    internal `javac -sourcepath` check AND `mvn compile` both fail with
    `cannot find symbol`.

    We build a map  {simple_class_name: original_package}  from the
    generation results, then scan each generated file's import lines. Any
    import whose trailing simple name matches a migrated class AND whose
    package prefix matches that class's original package is rewritten to
    `import <pkg>.playwright.<Name>;`.

    Only `import` lines are touched -- never method bodies, comments, or
    string literals. The fix is applied in-place on disk and in the
    `GenerationResult.generated_code` field so downstream steps (compile
    check, hallucination detection, report diff) see consistent state.
    """
    # Build the lookup: simple_name -> original_package.
    # We read the original_code (not the generated_code) for the package
    # because the generated code already has the `.playwright` suffix.
    name_to_orig_pkg: dict[str, str] = {}
    for gen in generations:
        if not gen.success or not gen.class_name:
            continue
        m = _PACKAGE_RE.search(gen.original_code)
        if m:
            name_to_orig_pkg[gen.class_name] = m.group(1)

    if not name_to_orig_pkg:
        return

    # For each generated file, rewrite matching import lines.
    for gen in generations:
        if not gen.success or not gen.output_path:
            continue
        try:
            src = gen.output_path.read_text(encoding="utf-8")
        except OSError:
            continue

        rewritten = _apply_import_rewrite(src, name_to_orig_pkg)
        if rewritten == src:
            continue  # Nothing changed.

        try:
            gen.output_path.write_text(rewritten, encoding="utf-8")
            # Keep in-memory view consistent for the compile/halluc steps.
            gen.generated_code = rewritten
            logger.info(
                "Pipeline: rewrote sibling imports",
                file=str(gen.output_path),
            )
        except OSError as e:
            logger.warning(
                "Pipeline: import rewrite write failed",
                file=str(gen.output_path),
                error=str(e),
            )


def _apply_import_rewrite(src: str, name_to_orig_pkg: dict[str, str]) -> str:
    """Apply the import rewrite to a single source string.

    Extracted so it can be unit-tested without touching the filesystem.
    """

    def _replace_import(m: re.Match) -> str:
        fq = m.group(2)  # fully-qualified name, e.g. "com.example.pages.LoginPage"
        # Split into (everything-before-last-dot, simple-name)
        dot = fq.rfind(".")
        if dot == -1:
            return m.group(0)  # default package -- leave alone
        pkg, simple = fq[:dot], fq[dot + 1:]
        if simple not in name_to_orig_pkg:
            return m.group(0)  # not a migrated sibling
        orig_pkg = name_to_orig_pkg[simple]
        if pkg != orig_pkg:
            return m.group(0)  # package doesn't match -- leave alone
        # Already has .playwright? Don't double it.
        if pkg.endswith(".playwright"):
            return m.group(0)
        new_fq = f"{pkg}.playwright.{simple}"
        return f"{m.group(1)}{new_fq}{m.group(3)}"

    return _IMPORT_LINE_RE.sub(_replace_import, src)


def _warn_package_collisions(generations: list["GenerationResult"]) -> None:
    """v0.5.3: warn when a generated file's package matches its original.

    This is the root cause of the "~150 mvn errors" failure mode: when the
    Coder emits `package com.example.pages;` instead of
    `package com.example.pages.playwright;`, Maven's joint compilation sees
    two classes with the same FQN and collapses with duplicate-symbol errors.

    We can't fix already-generated files here, but we log a structured
    warning so the user sees a clear diagnosis in the output rather than
    150 opaque javac errors from `mvn clean compile`.

    The assemble_file() safety net in coder.py (v0.5.3) prevents this on
    fresh runs; this check catches any rogue paths that bypass assemble_file.
    """

    for gen in generations:
        if not gen.success or not gen.generated_code or not gen.source_path:
            continue

        # Extract package from generated file.
        gen_match = _PACKAGE_RE.search(gen.generated_code)
        if not gen_match:
            continue
        gen_pkg = gen_match.group(1)

        # Extract package from original source file.
        try:
            orig_src = gen.source_path.read_text(encoding="utf-8")
        except OSError:
            continue
        orig_match = _PACKAGE_RE.search(orig_src)
        if not orig_match:
            continue
        orig_pkg = orig_match.group(1)

        if gen_pkg == orig_pkg:
            logger.warning(
                "Package collision: generated file has same package as original. "
                "Maven will see duplicate class errors on `mvn clean compile`. "
                "Expected generated package to end with '.playwright'.",
                file=str(gen.source_path),
                original_package=orig_pkg,
                generated_package=gen_pkg,
                fix="Regenerate with v0.5.3+; the coder now appends .playwright automatically.",
            )


def run_project_migration(
    files: list[Path],
    project_path: Path,
    config: QAMigrateConfig,
    on_generation: Callable[[int, int, GenerationResult], None] | None = None,
    on_compile: Callable[[int, int, int], None] | None = None,
) -> ProjectMigrationResult:
    """
    Migrate a whole project in three phases:

      1. Generate all files (scanner + coder, no compile).
      2. Resolve classpath + batch-compile everything together.
      3. If errors, loop through affected files, ask Fixer to fix each one
         with only its own errors, recompile, accept only if errors
         strictly reduced. Stop after config.pipeline.max_retries passes or
         two consecutive non-improvements.

    This is the recommended path for `qamigrate migrate --all` in v0.3+.
    """
    logger.info("Project pipeline: start", file_count=len(files))

    # ---- Phase 0 (v0.5+): build the ProjectMap once ----
    # This is the deep context the Coder uses on every file. Side effect:
    # zero LLM calls; costs a few hundred ms on a medium project.
    project_map = None
    try:
        from qamigrate.intelligence import ProjectAnalyzer
        project_map = ProjectAnalyzer().build(project_path)
        logger.info(
            "Project pipeline: intelligence ready",
            classes=project_map.file_count,
            edges=project_map.total_edges,
        )
    except Exception as e:  # pragma: no cover - defensive
        logger.warning(
            "Project pipeline: intelligence build failed; continuing without "
            "deep project context",
            error=str(e),
        )

    # ---- Phase 1: generate all files ----
    generations: list[GenerationResult] = []
    sibling_signatures: dict[str, list[str]] = {}
    # v0.5.1: catalogue of declared CSS/XPath selectors per class, so we
    # can detect tests that invent selectors not present on the page.
    # v0.5.2(b): now also tracks getByTestId strings (see DeclaredSelectors).
    sibling_locators: dict[str, DeclaredSelectors] = {}

    for i, file_path in enumerate(files, start=1):
        gen = run_generation(
            file_path=file_path,
            project_path=project_path,
            config=config,
            sibling_signatures=sibling_signatures or None,
            project_map=project_map,
        )
        generations.append(gen)
        if gen.success and gen.class_name:
            sibling_signatures[gen.class_name] = gen.signatures
            declared = extract_declared_selectors(gen.generated_code)
            if not declared.is_empty:
                sibling_locators[gen.class_name] = declared
        if on_generation:
            on_generation(i, len(files), gen)

    successful_gens = [g for g in generations if g.success and g.output_path is not None]

    # ---- Phase 1.5: rewrite sibling imports to .playwright package ----
    # v0.5.5 Fix #1: Generated files import siblings using the ORIGINAL
    # package path (e.g. `import com.qastarter.browser.BrowserFactory;`).
    # After migration, BrowserFactory lives at
    # `com.qastarter.browser.playwright.BrowserFactory`. javac resolves
    # cross-file references via -sourcepath, but only when the import
    # path matches the directory. This deterministic rewrite fixes all
    # `cannot find symbol` errors caused by stale sibling imports --
    # no LLM call required.
    _rewrite_sibling_imports(successful_gens)

    # ---- Phase 2: resolve classpath + batch compile ----
    classpath_reason: str | None = None
    compile_result = None
    classpath_entries: list[Path] = []

    if successful_gens:
        # Detect build tool by looking for pom.xml / build.gradle
        build_tool: str | None = None
        if (project_path / "pom.xml").exists():
            build_tool = "maven"
        elif (project_path / "build.gradle").exists() or (project_path / "build.gradle.kts").exists():
            build_tool = "gradle"

        if build_tool:
            resolver = ClasspathResolver(timeout_seconds=config.classpath.timeout_seconds)
            cp_result = resolver.resolve(
                project_path, build_tool,
                use_cache=config.classpath.use_cache,
            )
            if cp_result.ok:
                classpath_entries = cp_result.entries
                logger.info("Classpath resolved", entries=len(classpath_entries), cached=cp_result.cached)
            else:
                classpath_reason = cp_result.reason
                logger.warning("Classpath resolve failed; compile-check will be skipped",
                               reason=classpath_reason)
        else:
            classpath_reason = "No pom.xml or build.gradle found -- not a supported build tool"

    # ---- Phase 3: compile + fix loop ----
    from qamigrate.llm.from_config import build_provider_for_agent

    compiler = CompilerAgent(config.compiler)
    fixer = FixerAgent(
        config.fixer,
        llm_provider=build_provider_for_agent(config, "fixer"),
    )

    # If we couldn't resolve a classpath, skip compile entirely and mark
    # everything as "compiled=None" (generated, not verified).
    if classpath_reason is not None:
        records = _finalize_records_without_compile(generations, classpath_reason)
        return ProjectMigrationResult(
            records=records,
            classpath_reason=classpath_reason,
            compiled_count=0,
            failed_count=sum(1 for r in records if not r.success),
        )

    source_root = project_path / "src" / "main" / "java"
    test_source_root = project_path / "src" / "test" / "java"
    # Prefer main if present; otherwise use test. javac can handle mixed.
    effective_source_root = source_root if source_root.exists() else test_source_root

    # v0.5.3 Bug #3 fix: detect package-collision before compile.
    # When generated files declare the same package as their originals,
    # `mvn clean compile` sees duplicate class errors even though our
    # isolated javac check passes (it only sees the playwright/ files,
    # not the originals). We catch this deterministically here so the
    # user gets an actionable message instead of 150 javac errors.
    _warn_package_collisions(successful_gens)

    gen_paths = [g.output_path for g in successful_gens if g.output_path]

    max_iterations = config.pipeline.max_retries + 1
    # Per-file "best error count" so one stuck file doesn't block progress
    # on others (v0.3.1: fixes the Environment.java starvation reported
    # against v0.3.0). Each file gets its own attempt budget and its own
    # no-progress counter.
    per_file_best_errors: dict[str, int] = {}
    per_file_no_progress: dict[str, int] = {}
    attempts_per_file: dict[str, int] = {str(g.output_path): 0 for g in successful_gens}
    exhausted_files: set[str] = set()

    # Also keep a global no-progress tracker so we bail out when the whole
    # project has plateaued, not just when one file got stuck.
    global_best: int | None = None
    global_no_progress = 0

    for iteration in range(max_iterations):
        logger.info("Project compile attempt", iteration=iteration + 1)
        compile_result = compiler.compile_batch(
            files=gen_paths,
            classpath=classpath_entries if classpath_entries else None,
            source_root=effective_source_root,
        )
        if on_compile:
            on_compile(iteration + 1, len(compile_result.errors), len(gen_paths))

        if compile_result.success:
            logger.info("Project compile succeeded", iteration=iteration + 1)
            break

        current_errors = len(compile_result.errors)
        if global_best is None or current_errors < global_best:
            global_best = current_errors
            global_no_progress = 0
        else:
            global_no_progress += 1

        # Stop when the WHOLE project stops improving, or we hit the max.
        # A single file's budget is tracked separately below.
        if global_no_progress >= 2 or iteration == max_iterations - 1:
            logger.warning(
                "Project compile: stopping",
                reason="no global progress" if global_no_progress >= 2 else "max iterations",
                best_errors=global_best,
            )
            break

        # Group errors by file and fix each affected file individually.
        # Each file has its own budget (config.pipeline.max_retries per
        # file) and its own no-progress counter, so a stubborn file doesn't
        # starve its siblings and vice versa.
        groups = CompilerAgent.group_errors_by_file(compile_result)
        any_changed = False
        for file_str, errors in groups.items():
            if file_str in exhausted_files:
                continue
            try:
                file_path = Path(file_str)
                if not file_path.exists():
                    continue

                # Per-file progress check: if this file's error count has
                # gone up or stayed the same since we last fixed it, count
                # that against its no-progress budget.
                file_best = per_file_best_errors.get(file_str)
                if file_best is None or len(errors) < file_best:
                    per_file_best_errors[file_str] = len(errors)
                    per_file_no_progress[file_str] = 0
                else:
                    per_file_no_progress[file_str] = per_file_no_progress.get(file_str, 0) + 1

                if (
                    per_file_no_progress.get(file_str, 0) >= 2
                    or attempts_per_file.get(file_str, 0) >= config.pipeline.max_retries
                ):
                    logger.info(
                        "Fixer: retiring file (budget spent)",
                        file=file_str,
                        attempts=attempts_per_file.get(file_str, 0),
                    )
                    exhausted_files.add(file_str)
                    continue

                current_code = file_path.read_text(encoding="utf-8")
                fixed_code, changes = fixer.fix_file(
                    file_path=file_path,
                    code=current_code,
                    all_errors=errors,
                    retry_count=attempts_per_file.get(file_str, 0),
                )
                # Always count the attempt (even if the Fixer rejected its
                # own LLM output and returned the original). Without this,
                # stubborn files spin forever without consuming budget.
                attempts_per_file[file_str] = attempts_per_file.get(file_str, 0) + 1

                if fixed_code != current_code and changes:
                    file_path.write_text(fixed_code, encoding="utf-8")
                    any_changed = True
                    logger.info("Fixer applied changes", file=file_str,
                                change_count=len(changes))
                else:
                    logger.info("Fixer produced no usable fix for file",
                                file=file_str)
            except Exception as e:  # pragma: no cover
                logger.warning("Fixer error on file", file=file_str, error=str(e))

        # If nothing changed across any file in this iteration AND every
        # file has either been fixed cleanly or retired, we're done.
        if not any_changed and len(exhausted_files) >= len(groups):
            logger.info("Fixer produced no changes anywhere; stopping")
            break

    # ---- Finalize: build records from the final compile result ----
    final_errors_by_file = (
        CompilerAgent.group_errors_by_file(compile_result) if compile_result else {}
    )

    records: list[MigrationRecord] = []
    compiled_count = 0
    failed_count = 0

    for gen in generations:
        if not gen.success or gen.output_path is None:
            records.append(_build_record_from_generation(gen, compiled=None, attempts=0))
            failed_count += 1
            continue

        file_key = str(gen.output_path)
        # Match absolute+relative path variants (javac may emit either).
        file_errors = final_errors_by_file.get(file_key, [])
        if not file_errors:
            # Also try matching by basename
            for k, v in final_errors_by_file.items():
                if Path(k).name == gen.output_path.name:
                    file_errors = v
                    break

        attempts = attempts_per_file.get(file_key, 0)

        if compile_result and compile_result.success:
            compiled = True
            error = None
            compiled_count += 1
        elif file_errors:
            compiled = False
            error = f"{len(file_errors)} compile error(s) after {attempts} fix attempt(s)"
            failed_count += 1
        else:
            # Batch failed overall but this specific file had no errors.
            compiled = True
            error = None
            compiled_count += 1

        # Refresh generated_code from disk (may have been updated by fixer)
        try:
            gen.generated_code = gen.output_path.read_text(encoding="utf-8")
        except OSError:
            pass

        # Run hallucination detection now that the file is final
        hallucinations: list[Hallucination] = []
        if sibling_signatures and gen.generated_code:
            hallucinations = detect_hallucinations(gen.generated_code, sibling_signatures)
        if sibling_locators and gen.generated_code:
            hallucinations.extend(
                detect_selector_hallucinations(gen.generated_code, sibling_locators)
            )

        records.append(_build_record_from_generation(
            gen,
            compiled=compiled,
            attempts=attempts,
            error=error,
            hallucinations=hallucinations,
        ))

    return ProjectMigrationResult(
        records=records,
        classpath_reason=None,
        compiled_count=compiled_count,
        failed_count=failed_count,
    )


def _finalize_records_without_compile(
    generations: list[GenerationResult],
    reason: str,
) -> list[MigrationRecord]:
    """Build records for all files when compile-check was skipped entirely."""
    records: list[MigrationRecord] = []
    for gen in generations:
        if gen.success and gen.output_path is not None:
            records.append(_build_record_from_generation(
                gen, compiled=None, attempts=0,
            ))
        else:
            records.append(_build_record_from_generation(
                gen, compiled=None, attempts=0,
                error=gen.error or f"Generation failed; compile skipped: {reason}",
            ))
    return records
