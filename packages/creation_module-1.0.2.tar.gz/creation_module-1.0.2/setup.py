from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="Creation_module",
    version="1.0.2",
    author="shiroko",
    author_email="3207774253@qq.com",
    description="AI 驱动：将 .py 文件一键转为标准 Python 模块",
    long_description=long_description,
    long_description_content_type="text/markdown",
    packages=find_packages(),
    install_requires=[
        "shiroko_netai>=2.1.0",
        "text_discoloration>=3.0.1",
        "requests>=2.31.0",
    ],
    entry_points={
        "console_scripts": [
            "crme = Creation_module.core:main",
        ],
    },
    python_requires=">=3.6",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)