# crme

 **使用本工具即表示您已阅读、理解并同意以下条款：**

1. 本工具生成的代码由 AI 自动生成，可能存在错误、安全漏洞、恶意逻辑或版权问题。
2. **您必须自行审查、测试、修改并确认代码安全后方可使用。**
3. 作者不对任何直接或间接的损失（包括但不限于数据丢失、系统损坏、法律纠纷）承担责任。
4. 您输入的代码将经由 API 发送给第三方 AI 服务商（如 OpenAI），**请勿输入任何敏感信息**。
5. 本工具不存储、不收集、不上传您的本地文件内容，但无法控制 AI 服务商的数据处理行为。

**如不同意以上条款，请立即停止使用并卸载本工具。**

---

AI 驱动的 Python 文件转模块工具。  
把你的 `.py` 脚本拖进来，AI 自动生成完整的模块结构（`__init__.py`、`core.py`、`setup.py`、`README.md`）。

## 安装

```bash
pip install crme
```

## 使用

1. 配置 API（以 OpenAI 为例）

```bash
crme set api https://api.openai.com/v1/chat/completions
crme set key sk-xxx
crme set model gpt-3.5-turbo
crme set dir ~/my_modules
```

2. 转换模块

```bash
crme my_script.py mymodule
```

3. 查看配置

```bash
crme show
```

4. 重置配置

```bash
crme reset
```

安全审计流程

· 静态扫描（危险函数 / 密钥模式）
· AI 审计（只看结构，不看原始代码，防策反）
· 代码预览
· 用户最终确认（y / n / v）

依赖

· shiroko_netai
· text_discoloration

开源协议

MIT

作者

shiroko