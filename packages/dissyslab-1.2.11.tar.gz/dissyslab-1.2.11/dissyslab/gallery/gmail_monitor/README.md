# Gmail Monitor

Monitors your Gmail inbox for important emails and summarizes each one
that needs your attention. Newsletters, promotions, and automated
notifications go to the recycle bin.

**Tags:** gmail, single-agent, poll

## What it does

- Polls your inbox every minute for unread messages
- An analyst agent decides whether each message is important and, if so,
  writes a one-sentence summary with the suggested action
- Output streams to your terminal and to `gmail_monitor.jsonl`

## Files in this office

```
gmail_monitor/
    office.md          ← the org chart: source, agent, sink
    roles/
        analyst.md     ← what the agent does, in plain English
```

## Try it

```bash
dsl init gmail_monitor my_gmail
cd my_gmail
dsl run .
```

## Make it yours

- Change the polling interval or maximum emails in `office.md`:
  `Sources: gmail(poll_interval=60, max_emails=5, unread_only=True)`
- Rewrite the analyst in `roles/analyst.md` to fit your definition of
  "important" — work emails only, urgent threads, replies from specific
  people
- Add a second agent that drafts replies for emails that need one
- See [`docs/SOURCES_AND_SINKS.md`](https://github.com/kmchandy/DisSysLab/blob/main/docs/SOURCES_AND_SINKS.md)
  for the full list of sources and sinks you can swap in

**Recipe.** [How to monitor your inbox](https://github.com/kmchandy/DisSysLab/blob/main/docs/recipes/monitor-your-inbox.md)
walks through the Gmail app-password setup and shows how to swap
the analyst's criteria for "only meeting requests" or "only my
advisor".
