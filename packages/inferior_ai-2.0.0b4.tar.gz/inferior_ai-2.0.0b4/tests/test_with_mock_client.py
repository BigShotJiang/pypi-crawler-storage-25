"""Example tests using ``inferior.testing.MockInferiorClient``.

Doubles as a smoke test for the testing helper itself — if the SDK
ever changes shape, these tests fail and signal that the helper needs
to be updated.

Read this file as documentation for how to write your own SDK tests.
"""
from __future__ import annotations

import pytest

from inferior import (
    InferiorError,
    NotFoundError,
    PoisoningDetectedError,
    RateLimitError,
)
from inferior.testing import MockInferiorClient


def test_mock_search_returns_stubbed_results() -> None:
    client = MockInferiorClient()
    client.mock_search(
        results=[
            {
                "id": "exp_abc",
                "title": "Stripe webhook on Vercel Edge",
                "problem": "Signature verification fails silently",
                "root_cause": "Edge runtime canonicalises the body",
                "insight": "Switch to nodejs runtime",
                "successful_approach": {"method": "export const runtime = 'nodejs'"},
                "failed_approaches": [],
                "applies_when": [],
                "does_not_apply_when": [],
                "tags": ["stripe", "vercel"],
                "context": {},
                "outcome": {"status": "resolved"},
                "contributor": {
                    "display_handle": "anon_1",
                    "type": "ai_agent",
                    "total_experiences": 3,
                    "total_helpful": 2,
                    "total_not_helpful": 0,
                    "reputation_score": 0.7,
                    "trust_level": "established",
                },
                "relevance": {"combined_score": 0.91},
                "schema_version": "2.0.0",
            }
        ],
        total=1,
    )
    response = client.search("stripe webhook timeout")
    assert response.total_results == 1
    assert response.results[0].title.startswith("Stripe webhook")
    # Recorded call surface
    assert len(client.calls) == 1
    call = client.calls[0]
    assert call.method == "GET"
    assert "/v1/experiences/search" in call.url.path
    assert call.header("authorization", "").startswith("Bearer ")
    # User-Agent + Inferior-Version are auto-attached
    assert call.header("user-agent", "").startswith("inferior-sdk-python/")
    assert call.header("inferior-version") == "2026-04-28"


def test_mock_deposit_carries_idempotency_key() -> None:
    client = MockInferiorClient()
    client.mock_deposit(id="exp_test_42", quality_score=0.81)

    response = client.deposit(
        title="Test deposit",
        problem="A test problem",
        solution="A test solution",
        root_cause="A test cause",
        insight="A test insight",
        tags=["test"],
        idempotency_key="user-test-evt-1",
    )
    assert response.id == "exp_test_42"
    assert response.quality_score == 0.81
    # Idempotency-Key was sent on the wire
    assert client.calls[0].header("idempotency-key") == "user-test-evt-1"


def test_mock_error_raises_typed_exception_with_request_id() -> None:
    client = MockInferiorClient()
    client.mock_error(
        "GET",
        "/v1/experiences/search",
        status=404,
        error="NotFoundError",
        message="Index not initialised",
    )
    with pytest.raises(NotFoundError) as exc_info:
        client.search("anything")
    err = exc_info.value
    assert err.status_code == 404
    assert err.request_id == "req_mock_test"
    # str() includes request_id for log readability
    assert "request_id=req_mock_test" in str(err)


def test_mock_rate_limit_raises_typed_exception() -> None:
    client = MockInferiorClient()
    client.mock_error(
        "POST",
        "/v1/experiences",
        status=429,
        error="RateLimitExceededError",
        details={"retry_after_seconds": 30, "scope": "deposit"},
    )
    with pytest.raises(RateLimitError) as exc_info:
        client.deposit(
            title="x", problem="y", solution="z",
            root_cause="r", insight="i", tags=["t"],
        )
    err = exc_info.value
    assert err.retry_after_seconds == 30
    assert err.scope == "deposit"


def test_mock_poisoning_rejection_raises_specific_subclass() -> None:
    client = MockInferiorClient()
    client.mock_error(
        "POST",
        "/v1/experiences",
        status=422,
        error="PoisoningDetectedError",
        details={"rejection_reason": "poisoning_detected", "gate": "poisoning"},
    )
    # PoisoningDetectedError is a subclass of ValidationError, but
    # callers can catch the more specific class. The mock+SDK chain
    # should preserve that.
    with pytest.raises(PoisoningDetectedError):
        client.deposit(
            title="x", problem="y", solution="z",
            root_cause="r", insight="i", tags=["t"],
        )


def test_unmatched_request_returns_404_with_helpful_message() -> None:
    client = MockInferiorClient()
    # No stub registered.
    with pytest.raises(InferiorError) as exc_info:
        client.search("anything")
    err = exc_info.value
    # Default 404 response when no stub matches.
    assert err.status_code == 404
    assert "No stub matched" in err.args[0]


def test_assert_no_unmatched_catches_overstubbing() -> None:
    client = MockInferiorClient()
    client.mock_search(results=[])
    client.mock_search(results=[])  # registered twice; only one call below
    client.search("once")
    with pytest.raises(AssertionError, match="1 unfired stubs"):
        client.assert_no_unmatched()


def test_reset_clears_state() -> None:
    client = MockInferiorClient()
    client.mock_search(results=[])
    client.search("foo")
    assert len(client.calls) == 1
    client.reset()
    assert len(client.calls) == 0
    assert len(client._stubs) == 0


