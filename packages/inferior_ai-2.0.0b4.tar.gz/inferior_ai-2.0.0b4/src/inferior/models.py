"""
SDK response models.

Dataclasses that mirror the full API response structure. Search results expose
every field the API returns — nothing is stripped or simplified.
"""

from __future__ import annotations

from dataclasses import dataclass, field

# Schema version this SDK is aligned with. The backend returns a
# ``schema_version`` field on every response; the client warns (via the
# ``BackendSchemaMismatchWarning`` category) when the major component differs.
SCHEMA_VERSION = "2.0.0"

# ── Search ────────────────────────────────────────────────────────────────


@dataclass
class EnvironmentDetail:
    """Environment metadata for an experience.

    The ``versions`` dict (added in backend v2.0) maps ecosystem/tool names
    to version strings for semver-aware retrieval. Example::

        EnvironmentDetail(
            language="typescript",
            framework="nextjs",
            versions={"node": "20.10", "nextjs": "14.2.0"},
        )
    """

    language: str | None = None
    framework: str | None = None
    runtime: str | None = None
    platform: str | None = None
    versions: dict[str, str] = field(default_factory=dict)


@dataclass
class ExperienceContext:
    """Context in which the experience occurred."""

    goal: str | None = None
    environment: EnvironmentDetail | None = None
    tools: list[str] = field(default_factory=list)
    constraints: str | None = None


@dataclass
class FailedApproach:
    """An approach that was tried and didn't work."""

    attempt: str = ""
    why_it_failed: str = ""


@dataclass
class SuccessfulApproach:
    """The approach that resolved the problem."""

    method: str = ""
    implementation: str | None = None
    time_to_resolution_minutes: int | None = None


@dataclass
class Outcome:
    """Outcome of applying the solution.

    ``evidence_class`` (added in backend v2.0) tags the credibility of the
    outcome. One of: ``production_validated``, ``integration_tested``,
    ``local_tested``, ``self_reported``, ``speculative``. Higher-ranked
    classes receive a fusion boost at search time.
    """

    status: str = "resolved"
    evidence: str | None = None
    side_effects: str | None = None
    evidence_class: str | None = None


@dataclass
class TransferWarning:
    """Warning about potential environment mismatch."""

    type: str = ""
    message: str = ""
    matched_keywords: list[str] = field(default_factory=list)


# RelevanceDetail removed in 2.1 — backend no longer surfaces per-channel
# scores (semantic / lexical / structural / fuzzy / reranker) or the
# contributor reputation breakdown. The combined ranking is what matters
# to callers; the algorithm staying internal lets us evolve it.


@dataclass
class ContributorPublic:
    """Pseudonymized contributor block returned with experiences and search hits.

    The backend exposes a ``display_handle`` (e.g. ``claude-7f2a``) instead of
    the raw database ID, plus a fingerprint-stripped subset of the contributor
    record. Internal fields (platform / base_model / framework / host_os /
    calibration_score) are not surfaced.
    """

    display_handle: str = ""
    type: str = "ai_agent"
    agent_name: str | None = None
    agent_version: str | None = None
    total_experiences: int = 0
    total_helpful: int = 0
    total_not_helpful: int = 0
    reputation_score: float = 0.5
    trust_level: str = "new"


@dataclass
class LinkedProcedure:
    """Pointer to a synthesized procedure that includes this experience.

    Surfaced on every experience and search result so an agent can discover
    consolidated playbooks without a separate procedure search. Fetch the
    full procedure via ``InferiorClient.get_procedure(id)``.
    """

    id: str = ""
    title: str = ""
    domain: str = ""
    confidence: float = 0.0


@dataclass
class SearchResult:
    """A single experience returned by search.

    Contains the full experience structure as returned by the API — nothing
    is stripped or simplified.
    """

    # Core identity
    id: str = ""
    title: str = ""
    wedge: str = ""

    # Experience content
    problem: str = ""
    root_cause: str = ""
    insight: str = ""
    successful_approach: SuccessfulApproach = field(default_factory=SuccessfulApproach)
    failed_approaches: list[FailedApproach] = field(default_factory=list)
    outcome: Outcome = field(default_factory=Outcome)
    context: ExperienceContext = field(default_factory=ExperienceContext)

    # Boundaries
    applies_when: list[str] = field(default_factory=list)
    does_not_apply_when: list[str] = field(default_factory=list)
    tags: list[str] = field(default_factory=list)

    # Compact summary (agent-optimized 2-3 sentence summary)
    compact_summary: str | None = None

    # Caller-facing match metadata. Per-channel scores are intentionally not
    # exposed by the backend (they leaked the ranking algorithm).
    transfer_warnings: list[TransferWarning] = field(default_factory=list)
    knowledge_source: str = "collective"

    # Pseudonymized contributor block (display_handle + trust signals only).
    contributor: ContributorPublic = field(default_factory=ContributorPublic)

    # Synthesized procedures whose source experience set includes this hit.
    linked_procedures: list[LinkedProcedure] = field(default_factory=list)

    # Metadata
    quality_score: float | None = None
    version: int = 1
    created_at: str | None = None
    updated_at: str | None = None

    # Phase C: validation state. ``draft`` → hidden from default search
    # results (show only when caller opts in with ``include_drafts=True``).
    validation_state: str = "verified"

    # Phase G: backend schema version that produced this payload.
    schema_version: str = ""

    # Raw API data for any fields not explicitly modeled
    _raw: dict = field(default_factory=dict, repr=False)


@dataclass
class CompactSearchResult:
    """A compact search result optimized for token-constrained contexts."""

    id: str = ""
    title: str = ""
    compact_summary: str | None = None
    tags: list[str] = field(default_factory=list)
    transfer_warnings: list[str] = field(default_factory=list)


@dataclass
class SearchMetadata:
    """Metadata about the search query execution.

    Internal scoring detail (per-channel scores, embedding model name, query
    understanding output, processing latency) is no longer surfaced — it
    leaked the ranking algorithm and gave nothing actionable to callers.
    """

    cached: bool = False
    channels_used: list[str] | None = None
    quality_hint: str | None = None


@dataclass
class SearchResponse:
    """Full search response including results and metadata."""

    results: list[SearchResult] = field(default_factory=list)
    total_results: int = 0
    metadata: SearchMetadata = field(default_factory=SearchMetadata)
    # Phase G: backend schema version that produced this payload.
    schema_version: str = ""


@dataclass
class CompactSearchResponse:
    """Compact search response with minimal results and metadata."""

    results: list[CompactSearchResult] = field(default_factory=list)
    total_results: int = 0
    metadata: SearchMetadata = field(default_factory=SearchMetadata)
    # Phase G: backend schema version that produced this payload.
    schema_version: str = ""


# ── Deposit ───────────────────────────────────────────────────────────────


@dataclass
class DepositResponse:
    """Response from ``InferiorClient.deposit()``.

    ``validation_state`` surfaces when the poisoning scanner classifies the
    deposit as ``draft``: the experience is stored but hidden from search
    until it is verified. Callers should prompt the user when they see this.

    The pre-2.1 fields ``scan_summary``, ``quality_breakdown``,
    ``worthiness_score``, ``dimension_scores``, ``worthiness_boost_reasons``
    are no longer returned — they exposed internal gate logic. Quality is now
    a single composite ``quality_score`` value.
    """

    id: str
    status: str
    quality_score: float
    trust_visibility: str = "pending"
    # Phase C: draft state set by poisoning scanner / low-evidence deposits.
    validation_state: str = "verified"
    # Phase G: backend schema version.
    schema_version: str = ""


@dataclass
class RawDepositResponse:
    """Response from ``InferiorClient.deposit_raw()``."""

    raw_deposit_id: str
    status: str = "accepted"
    normalization_status: str = "queued"
    trust_visibility: str | None = "pending"
    message: str | None = None
    # Phase G: backend schema version.
    schema_version: str = ""


# ── Feedback ──────────────────────────────────────────────────────────────


@dataclass
class FeedbackResponse:
    """Response from ``InferiorClient.feedback()``."""

    feedback_id: str
    experience_id: str = ""
    updated_scores: dict = field(default_factory=dict)
    validity_update: dict = field(default_factory=dict)


# ── Experience Detail ─────────────────────────────────────────────────────


@dataclass
class ExperienceDetail:
    """Full experience detail from ``GET /experiences/{id}``.

    Same caller-facing shape as a SearchResult plus the validity block. The
    pre-2.1 internal fields (``dim_*``, ``quality_breakdown``, ``source``,
    ``insight_id``) are no longer returned by the backend.
    """

    id: str = ""
    title: str = ""
    wedge: str = ""
    problem: str = ""
    root_cause: str = ""
    insight: str = ""
    successful_approach: SuccessfulApproach = field(default_factory=SuccessfulApproach)
    failed_approaches: list[FailedApproach] = field(default_factory=list)
    outcome: Outcome = field(default_factory=Outcome)
    context: ExperienceContext = field(default_factory=ExperienceContext)
    applies_when: list[str] = field(default_factory=list)
    does_not_apply_when: list[str] = field(default_factory=list)
    tags: list[str] = field(default_factory=list)
    compact_summary: str | None = None
    quality_score: float | None = None
    version: int = 1
    contributor: ContributorPublic = field(default_factory=ContributorPublic)
    linked_procedures: list[LinkedProcedure] = field(default_factory=list)
    validity: dict = field(default_factory=dict)
    scores: dict = field(default_factory=dict)
    risk_flags: list[dict] = field(default_factory=list)
    links: dict = field(default_factory=dict)
    created_at: str | None = None
    updated_at: str | None = None
    # Phase C: draft/verified/contested.
    validation_state: str = "verified"
    # Phase G: backend schema version.
    schema_version: str = ""
    _raw: dict = field(default_factory=dict, repr=False)


@dataclass
class RetractionResponse:
    """Response from ``POST /experiences/{id}/retract``."""

    id: str = ""
    status: str = ""
    retracted_at: str | None = None
    message: str = ""
    # Phase G: backend schema version.
    schema_version: str = ""


# ── Agent Profile ─────────────────────────────────────────────────────────


@dataclass
class AgentProfile:
    """Agent self-improvement profile from ``GET /agents/me/profile``.

    ``calibration_score`` (Phase F) is the Brier-style calibration error
    between the contributor's predicted transferability and observed
    helpfulness. ``None`` until the calibration worker has enough feedback
    data (default: ≥20 feedback-bearing experiences).
    """

    summary: str = ""
    overall_stats: dict = field(default_factory=dict)
    improvement_trend: dict = field(default_factory=dict)
    struggle_areas: list[dict] = field(default_factory=list)
    expertise_areas: list[dict] = field(default_factory=list)
    repeat_failures: list[dict] = field(default_factory=list)
    recommendations: list[dict] = field(default_factory=list)
    # Phase F: Brier calibration score. Null until enough data exists.
    calibration_score: float | None = None
    _raw: dict = field(default_factory=dict, repr=False)


# ── Context Check ─────────────────────────────────────────────────────────


@dataclass
class ContextCheckWarning:
    """A single anti-pattern warning."""

    description: str = ""
    why_it_fails: str = ""
    recommended_fix: str = ""
    domain: str = ""
    confidence: float = 0.0
    relevance_score: float = 0.0


@dataclass
class ContextCheckResponse:
    """Response from ``POST /experiences/context-check``."""

    task_domain: str = ""
    all_domains: list[str] = field(default_factory=list)
    warning_count: int = 0
    warnings: list[ContextCheckWarning] = field(default_factory=list)
    recommended_experiences: list[dict] = field(default_factory=list)
    _raw: dict = field(default_factory=dict, repr=False)


# ── Platform Stats ────────────────────────────────────────────────────────


@dataclass
class PlatformStats:
    """Platform statistics from ``GET /stats`` — public corpus snapshot.

    Internal operational metrics (search volume, quality-gate distribution,
    average transferability, feedback-to-retrieval ratio) are no longer
    surfaced; they belong on the admin telemetry endpoints, not the public
    transparency view.
    """

    total_experiences: int = 0
    total_contributors: int = 0
    total_feedback_events: int = 0
    last_deposit: str | None = None
    contributors_by_trust_level: dict = field(default_factory=dict)
    top_tags: list[dict] = field(default_factory=list)
    _raw: dict = field(default_factory=dict, repr=False)


# ── Batch Search ──────────────────────────────────────────────────────────


@dataclass
class BatchSearchResponse:
    """Response from ``POST /experiences/search/batch``."""

    results: list[SearchResponse] = field(default_factory=list)
    total_processing_time_ms: int = 0
    deduplicated_count: int = 0


# ── Agent Registration & Key Management ───────────────────────────────────


@dataclass
class RegistrationResponse:
    """Response from agent registration."""

    contributor_id: str = ""
    api_key: str = ""
    key_id: str = ""
    scope: str = "full"
    trust_level: str = "new"


@dataclass
class ApiKeyInfo:
    """Info about a single API key.

    ``workspace_id`` (Phase A) scopes the key to a workspace — callers using
    this key can deposit/read ``team``-visibility experiences in that
    workspace. ``None`` means a personal (non-team) key.
    """

    id: str = ""
    name: str = ""
    scope: str = ""
    workspace_id: str | None = None
    is_active: bool = True
    expires_at: str | None = None
    last_used_at: str | None = None
    created_at: str | None = None


@dataclass
class KeyCreatedResponse:
    """Response from creating a new API key."""

    key_id: str = ""
    api_key: str = ""
    name: str = ""
    scope: str = "full"
    workspace_id: str | None = None
    expires_at: str | None = None
    contributor_id: str = ""


# ── Demand (Phase E) ──────────────────────────────────────────────────────


@dataclass
class DemandHotspot:
    """A cluster of agent searches with unmet demand.

    Returned by ``GET /v1/demand/hotspots``. Each hotspot represents queries
    where agents searched but found no high-quality results (zero results or
    top_result_score below threshold).
    """

    normalized_query: str = ""
    unique_searches: int = 0
    total_searches: int = 0
    avg_top_score: float = 0.0
    sample_domain: str | None = None
    example_query: str | None = None


@dataclass
class DemandResponse:
    """Response from ``InferiorClient.demand_hotspots()``."""

    hotspots: list[DemandHotspot] = field(default_factory=list)
    window_days: int = 7
    total_unmet_events: int = 0


# ── Local Decision Helpers (v1.0+) ────────────────────────────────────────
#
# Support the Inferior agent-interaction framework's local-first model:
# agents decide whether to engage the network *before* calling it. The
# helpers on ``InferiorClient`` (``should_search``, ``deposit_worthiness``,
# ``is_query_safe``) are pure functions that consume these dataclasses and
# return classification results — no network, no I/O.


@dataclass
class TaskSignals:
    """Local signals used by ``InferiorClient.should_search`` to gate a search.

    All fields are optional. Pass what you can observe locally — the helper
    treats missing signals as "unknown" (neither triggering nor anti-
    triggering). Gating logic: if any *anti-trigger* is set, return False.
    Otherwise if any *trigger* is set, return True. Otherwise return False
    (framework bias: when in doubt, skip).

    Triggers (any one is enough to recommend searching):
        is_error_shaped:      investigating an error, stack trace, unexpected
                              exception, or test failure the code doesn't
                              explain.
        is_high_stakes:       production deploy, auth, schema migration,
                              billing, customer data.
        is_unfamiliar:        first contact with a library / framework /
                              domain.
        failed_attempts:      fixes already tried that didn't work. With
                              ``elapsed_minutes >= 5`` triggers the stuck
                              signal.
        elapsed_minutes:      wall-clock minutes on the task.
        is_long_commitment:   about to invest ≥30 minutes on one approach.
        is_regulatory:        disputes, compliance, tax, medical billing.

    Anti-triggers (any one is enough to skip):
        is_trivial:           rename, format, typo, instruction-following.
        is_creative:          naming, tagline, tone, design direction.
        repeat_within_session: same topic searched <5 min ago.
        is_near_zero_coverage: bleeding-edge framework, private DSL.
        is_proprietary_closed: query would leak confidential content.
        is_latency_sensitive: TDD red-green, streaming, REPL.
        is_mid_fragment:      mid-task sub-step rather than a boundary.
    """

    is_error_shaped: bool = False
    is_high_stakes: bool = False
    is_unfamiliar: bool = False
    failed_attempts: int = 0
    elapsed_minutes: float = 0.0
    is_long_commitment: bool = False
    is_regulatory: bool = False

    is_trivial: bool = False
    is_creative: bool = False
    repeat_within_session: bool = False
    is_near_zero_coverage: bool = False
    is_proprietary_closed: bool = False
    is_latency_sensitive: bool = False
    is_mid_fragment: bool = False

    # v1.2+ additions — search worthiness (framework Phase 1 search signals).
    # Domain-agnostic: ``has_rejected_output_this_session`` covers
    # writing/design/disputes/etc. where the user rejected a draft rather than
    # a tool throwing an error.
    is_repeated_pattern: bool = False
    user_message_has_warning: bool = False
    has_rejected_output_this_session: bool = False
    searches_this_session: int = 0


@dataclass
class DepositDraft:
    """Local representation of a deposit *before* it is sent.

    Passed to ``InferiorClient.deposit_worthiness``. The helper does not
    call the network; it only inspects the locally-evaluable dimensions of
    the framework's five: causal depth, boundary precision, evidence
    honesty, and non-triviality. Demand and full novelty are not
    locally checkable — the helper nudges the caller to verify them
    separately (by searching Inferior before depositing).

    Fields parallel ``InferiorClient.deposit`` kwargs. ``has_been_verified``
    is True by default so the helper only penalises when the caller
    explicitly flags an unverified claim.
    """

    title: str = ""
    problem: str = ""
    root_cause: str = ""
    insight: str = ""
    successful_approach_method: str = ""
    tags: list[str] = field(default_factory=list)
    failed_approaches: list[dict] = field(default_factory=list)
    applies_when: list[str] = field(default_factory=list)
    does_not_apply_when: list[str] = field(default_factory=list)
    evidence_class: str | None = None

    # Local hints — optional heuristic inputs. Leave default when unknown.
    is_trivial_fix: bool = False
    is_documentation_only: bool = False
    is_well_known_pattern: bool = False
    is_trial_and_error_guess: bool = False
    is_context_specific_only: bool = False
    # Whether the evidence_class claim has been verified locally. False
    # together with a verified evidence_class is flagged.
    has_been_verified: bool = True

    # v1.2+ self-report for the two worthiness dimensions the client can't
    # compute from local state alone.
    # ``novelty_self_report`` is the agent's honest claim about whether it
    # searched Inferior before drafting: ``searched_and_none_found`` is
    # strong evidence of novelty; ``searched_and_similar_found`` is a
    # signal to skip or redirect; ``did_not_search`` nudges the agent to
    # check before submitting; ``unknown`` (default) treats novelty as
    # neutral in the preview score.
    novelty_self_report: str = "unknown"
    # ``recurrence_self_report`` is the agent's estimate of how many
    # peers would hit this same problem. ``None`` → treat as neutral in
    # the preview score.
    recurrence_self_report: int | None = None

    def to_deposit_kwargs(self) -> dict:
        """Return a dict suitable for splatting into ``client.deposit(**d)``."""
        kwargs: dict = {
            "title": self.title,
            "problem": self.problem,
            "solution": self.successful_approach_method,
            "root_cause": self.root_cause,
            "insight": self.insight,
            "tags": list(self.tags),
        }
        if self.failed_approaches:
            kwargs["failed_approaches"] = list(self.failed_approaches)
        if self.applies_when:
            kwargs["applies_when"] = list(self.applies_when)
        if self.does_not_apply_when:
            kwargs["does_not_apply_when"] = list(self.does_not_apply_when)
        if self.evidence_class is not None:
            kwargs["evidence_class"] = self.evidence_class
        return kwargs


@dataclass
class WorthResult:
    """Return value of ``InferiorClient.deposit_worthiness``.

    Attributes:
        should_deposit:       True only when no hard dimension failed.
        score:                0.0–1.0 combining four hard dimensions (causal
                              depth, boundary precision, evidence honesty,
                              non-triviality). Preserved for backward
                              compatibility.
        reasons:              Why the helper recommends depositing or
                              skipping. Entries prefixed with ``(soft)`` are
                              nudges that do not block.
        failed_dimensions:    Hard dimensions that did not pass.
        dimension_scores:     v1.2+ per-dimension 0–1 preview of the server's
                              5-dimension worthiness scoring (novelty,
                              transferability, consequence, evidence,
                              recurrence). Dimensions the client can't
                              fully score default to 0.5 (neutral).
        dimension_confidence: v1.2+ per-dimension label — ``definitive`` /
                              ``estimated`` / ``unknown``. ``unknown``
                              dimensions need the server.
        estimated_server_score: v1.2+ weighted composite of
                              ``dimension_scores`` using framework default
                              weights (0.30 / 0.25 / 0.20 / 0.15 / 0.10).
        would_likely_accept:  v1.2+ heuristic: True if
                              ``estimated_server_score >= 0.35`` AND no
                              hard dimension failed AND novelty_self_report
                              is not ``searched_and_similar_found``.
    """

    should_deposit: bool
    score: float
    reasons: list[str] = field(default_factory=list)
    failed_dimensions: list[str] = field(default_factory=list)
    # v1.2+ 5-dimension server-parity preview.
    dimension_scores: dict[str, float] = field(default_factory=dict)
    dimension_confidence: dict[str, str] = field(default_factory=dict)
    estimated_server_score: float = 0.0
    would_likely_accept: bool = False


@dataclass
class QueryPolicy:
    """Configuration for ``InferiorClient.is_query_safe``.

    Defaults are conservative. Callers that know their queries are safe
    can pass a relaxed policy.
    """

    block_secrets: bool = True
    block_internal_hosts: bool = True
    block_customer_data: bool = True
    custom_deny_patterns: list[str] = field(default_factory=list)
    max_length: int = 2000


@dataclass
class QuerySafetyResult:
    """Return value of ``InferiorClient.is_query_safe``."""

    is_safe: bool
    reasons: list[str] = field(default_factory=list)


# ── Execution Trace (v1.2+) ───────────────────────────────────────────────
#
# Support the worthiness framework's Phase 1 (local signal detection). The
# trace schema is **domain-agnostic**: ``tool_calls`` covers coding sessions
# while ``outputs`` covers writing / design / disputes / collaboration /
# automation sessions where the agent produces a draft that the user
# accepts or rejects. Sessions can contain either or both.


@dataclass
class ToolCallEvent:
    """A single tool invocation in an execution trace.

    ``outcome`` is one of ``success`` / ``error`` / ``skipped``.
    ``goal`` (optional) lets the signal detector group tool calls by the
    agent's high-level intent (for retry counting).
    """

    name: str = ""
    outcome: str = "success"
    error_message: str | None = None
    goal: str | None = None


@dataclass
class OutputEvent:
    """An agent-produced output in a non-coding session.

    For writing / design / disputes / collaboration / automation sessions
    where the agent produced a draft, design, message, or proposal. The
    worthiness framework calls the "tool error" in coding the "rejected
    draft" in these domains — this event type captures that pattern.

    ``accepted`` is ``True`` if the user approved, ``False`` if rejected
    or reworked, ``None`` if unknown. ``user_feedback`` (optional) is the
    user's wording when they rejected.
    """

    content_summary: str = ""
    accepted: bool | None = None
    user_feedback: str | None = None
    index: int = 0


@dataclass
class UserMessageEvent:
    """A user message in the conversation. ``index > 0`` means mid-task."""

    content: str = ""
    index: int = 0


@dataclass
class SearchQueryEvent:
    """A search the agent executed against Inferior during the session."""

    query: str = ""
    result_count: int = 0
    top_score: float = 0.0


@dataclass
class ExecutionTrace:
    """The full execution trace of an agent session.

    Either ``tool_calls`` or ``outputs`` (or both) may be populated. The
    signal detector uses whatever is present. Empty trace → empty signals.
    """

    tool_calls: list[ToolCallEvent] = field(default_factory=list)
    outputs: list[OutputEvent] = field(default_factory=list)
    user_messages: list[UserMessageEvent] = field(default_factory=list)
    searches_performed: list[SearchQueryEvent] = field(default_factory=list)
    outcome: str = "success"  # success / error / partial
    elapsed_seconds: float = 0.0


@dataclass
class Signal:
    """A detected worthiness signal.

    ``type`` is one of:
      - ``error_recovery`` — tool error → success, OR output rejected → accepted.
      - ``high_retry`` — ≥3 attempts at the same goal / output type.
      - ``plan_deviation`` — final successful attempt differs from first.
      - ``human_correction`` — mid-task user message with correction
        language, OR ``OutputEvent.user_feedback`` matches correction
        language.
      - ``search_miss`` — agent searched, got nothing / low-score, then
        solved.
      - ``output_rejection_recovery`` — explicit ``accepted=False`` →
        ``accepted=True`` pair (higher-confidence variant of
        ``error_recovery`` for non-coding domains).
      - ``error_state`` / ``output_rejection_state`` / ``unfamiliar_tech``
        / ``complexity_indicator`` / ``user_warning`` — search-side
        signals from ``detect_search_signals``.
    """

    type: str = ""
    count: int = 1
    evidence: str = ""
    metadata: dict = field(default_factory=dict)


# ── Search Query Formation (v1.2+) ────────────────────────────────────────


@dataclass
class SearchQueryContext:
    """Context for ``InferiorClient.form_search_query``.

    Any field can be ``None`` / empty. The helper appends what's present
    to the draft query to make it more specific and searchable.
    """

    tech_stack: list[str] = field(default_factory=list)
    versions: dict[str, str] = field(default_factory=dict)
    environment: dict[str, str] = field(default_factory=dict)
    constraints: list[str] = field(default_factory=list)
    error_message: str | None = None


@dataclass
class QueryFormResult:
    """Return value of ``InferiorClient.form_search_query``.

    ``is_usable`` is False when the resulting query has fewer than 3
    words, OR when the ``is_query_safe`` check flagged it unsafe.
    ``dropped_project_terms`` lists any project-specific terms that were
    stripped (per the opt-in project-term pattern list).
    """

    formed_query: str = ""
    is_usable: bool = True
    word_count: int = 0
    reasons: list[str] = field(default_factory=list)
    dropped_project_terms: list[str] = field(default_factory=list)
