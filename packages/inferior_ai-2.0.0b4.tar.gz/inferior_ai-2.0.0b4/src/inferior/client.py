"""
Inferior Python SDK client.

Complete synchronous HTTP client for the Inferior REST API with typed return
values. Covers all API parameters — nothing is omitted or simplified.

Usage::

    from inferior import InferiorClient

    client = InferiorClient(api_key="cw_full_...")
    response = client.search("stripe webhook timeout vercel")
    for r in response.results:
        print(r.title, r.relevance.combined_score)
"""

from __future__ import annotations

import json
import warnings
from pathlib import Path

import httpx

from inferior._constants import (
    DEFAULT_HEADERS,
    HEADER_REQUEST_ID,
    HEADER_RESOLVED_VERSION,
    INFERIOR_API_VERSION,
)
from inferior._retry import Retry, RetryTransport
from inferior.exceptions import (
    APIVersionMismatchWarning,
    AuthenticationError,
    BackendSchemaMismatchWarning,
    DuplicateError,
    ForbiddenError,
    InferiorError,
    InsufficientScopeError,
    NotFoundError,
    PoisoningDetectedError,
    RateLimitError,
    ServerError,
    ValidationError,
)
from inferior.models import (
    SCHEMA_VERSION,
    AgentProfile,
    ApiKeyInfo,
    BatchSearchResponse,
    CompactSearchResponse,
    CompactSearchResult,
    ContextCheckResponse,
    ContextCheckWarning,
    DemandHotspot,
    DemandResponse,
    DepositDraft,
    DepositResponse,
    EnvironmentDetail,
    ExecutionTrace,
    ExperienceContext,
    ExperienceDetail,
    FailedApproach,
    FeedbackResponse,
    KeyCreatedResponse,
    Outcome,
    OutputEvent,
    PlatformStats,
    QueryFormResult,
    QueryPolicy,
    QuerySafetyResult,
    RawDepositResponse,
    RegistrationResponse,
    ContributorPublic,
    LinkedProcedure,
    RetractionResponse,
    SearchMetadata,
    SearchQueryContext,
    SearchQueryEvent,
    SearchResponse,
    SearchResult,
    Signal,
    SuccessfulApproach,
    TaskSignals,
    ToolCallEvent,
    TransferWarning,
    UserMessageEvent,
    WorthResult,
)

_DEFAULT_BASE_URL = "https://api.inferior.ai"
_DEFAULT_TIMEOUT = 15.0


def _raise_for_status(resp: httpx.Response) -> None:
    """Parse API error response and raise a typed exception.

    Every exception carries ``request_id`` extracted from the
    ``X-Request-ID`` response header so support tickets can be matched
    to the exact request in backend logs.
    """
    if resp.is_success:
        return

    status = resp.status_code
    request_id = resp.headers.get(HEADER_REQUEST_ID)
    try:
        body = resp.json()
    except Exception:
        body = {}

    error_type = body.get("error", "")
    message = body.get("message", resp.text)
    details = body.get("details", {})

    if status == 401:
        raise AuthenticationError(
            message,
            status_code=status,
            error_type=error_type,
            details=details,
            request_id=request_id,
        )

    if status == 403:
        if error_type == "InsufficientScopeError":
            raise InsufficientScopeError(
                message,
                status_code=status,
                error_type=error_type,
                details=details,
                request_id=request_id,
                required_scope=details.get("required_scope", ""),
                actual_scope=details.get("actual_scope", ""),
            )
        raise ForbiddenError(
            message,
            status_code=status,
            error_type=error_type,
            details=details,
            request_id=request_id,
        )

    if status == 404:
        raise NotFoundError(
            message,
            status_code=status,
            error_type=error_type,
            details=details,
            request_id=request_id,
        )

    if status == 409:
        raise DuplicateError(
            message,
            status_code=status,
            error_type=error_type,
            details=details,
            request_id=request_id,
            existing_id=details.get("existing_experience_id", details.get("experience_id", "")),
        )

    if status == 422:
        # Phase C: distinguish poisoning-scanner rejections from other 422s
        # so callers can catch PoisoningDetectedError specifically without
        # swallowing unrelated PII/quality failures.
        is_poisoning = (
            "poisoning" in (error_type or "").lower()
            or details.get("rejection_reason") == "poisoning_detected"
            or details.get("gate") == "poisoning"
        )
        exc_cls = PoisoningDetectedError if is_poisoning else ValidationError
        raise exc_cls(
            message,
            status_code=status,
            error_type=error_type,
            details=details,
            request_id=request_id,
            validation_type=error_type,
        )

    if status == 429:
        raise RateLimitError(
            message,
            status_code=status,
            error_type=error_type,
            details=details,
            request_id=request_id,
            retry_after_seconds=details.get("retry_after_seconds", 0),
            scope=details.get("scope", ""),
        )

    if status >= 500:
        raise ServerError(
            message,
            status_code=status,
            error_type=error_type,
            details=details,
            request_id=request_id,
        )

    raise InferiorError(
        message,
        status_code=status,
        error_type=error_type,
        details=details,
        request_id=request_id,
    )


def _parse_metadata(data: dict) -> SearchMetadata:
    """Parse search response metadata."""
    meta = data.get("metadata", {})
    return SearchMetadata(
        cached=meta.get("cached", False),
        channels_used=meta.get("channels_used"),
        quality_hint=meta.get("quality_hint"),
    )


def _parse_contributor(c: dict | None) -> ContributorPublic:
    if not c:
        return ContributorPublic()
    return ContributorPublic(
        display_handle=c.get("display_handle", ""),
        type=c.get("type", "ai_agent"),
        agent_name=c.get("agent_name"),
        agent_version=c.get("agent_version"),
        total_experiences=int(c.get("total_experiences") or 0),
        total_helpful=int(c.get("total_helpful") or 0),
        total_not_helpful=int(c.get("total_not_helpful") or 0),
        reputation_score=float(c.get("reputation_score") or 0.5),
        trust_level=c.get("trust_level", "new"),
    )


def _parse_linked_procedures(rows: list[dict] | None) -> list[LinkedProcedure]:
    if not rows:
        return []
    return [
        LinkedProcedure(
            id=p.get("id", ""),
            title=p.get("title", ""),
            domain=p.get("domain", ""),
            confidence=float(p.get("confidence") or 0.0),
        )
        for p in rows
    ]


def _parse_search_result(r: dict) -> SearchResult:
    """Parse a raw API search result dict into a SearchResult dataclass."""
    approach_data = r.get("successful_approach", {})
    successful_approach = SuccessfulApproach(
        method=approach_data.get("method", ""),
        implementation=approach_data.get("implementation"),
        time_to_resolution_minutes=approach_data.get("time_to_resolution_minutes"),
    )

    failed_approaches = [
        FailedApproach(
            attempt=fa.get("attempt", ""),
            why_it_failed=fa.get("why_it_failed", ""),
        )
        for fa in r.get("failed_approaches", [])
    ]

    outcome_data = r.get("outcome", {})
    outcome = Outcome(
        status=outcome_data.get("status", "resolved"),
        evidence=outcome_data.get("evidence"),
        side_effects=outcome_data.get("side_effects"),
        evidence_class=outcome_data.get("evidence_class"),
    )

    ctx_data = r.get("context", {})
    env_data = ctx_data.get("environment") if ctx_data else None
    environment = None
    if env_data and isinstance(env_data, dict):
        environment = EnvironmentDetail(
            language=env_data.get("language"),
            framework=env_data.get("framework"),
            runtime=env_data.get("runtime"),
            platform=env_data.get("platform"),
            versions=env_data.get("versions", {}),
        )
    context = ExperienceContext(
        goal=ctx_data.get("goal") if ctx_data else None,
        environment=environment,
        tools=ctx_data.get("tools", []) if ctx_data else [],
        constraints=ctx_data.get("constraints") if ctx_data else None,
    )

    transfer_warnings = [
        TransferWarning(
            type=tw.get("type", ""),
            message=tw.get("message", ""),
            matched_keywords=tw.get("matched_keywords", []),
        )
        for tw in r.get("transfer_warnings") or []
    ]

    return SearchResult(
        id=r.get("id", ""),
        title=r.get("title", ""),
        wedge=r.get("wedge", ""),
        problem=r.get("problem", ""),
        root_cause=r.get("root_cause", ""),
        insight=r.get("insight", ""),
        successful_approach=successful_approach,
        failed_approaches=failed_approaches,
        outcome=outcome,
        context=context,
        applies_when=r.get("applies_when", []),
        does_not_apply_when=r.get("does_not_apply_when", []),
        tags=r.get("tags", []),
        compact_summary=r.get("compact_summary"),
        transfer_warnings=transfer_warnings,
        knowledge_source=r.get("knowledge_source", "collective"),
        contributor=_parse_contributor(r.get("contributor")),
        linked_procedures=_parse_linked_procedures(r.get("linked_procedures")),
        quality_score=r.get("quality_score"),
        version=r.get("version", 1),
        created_at=r.get("created_at"),
        updated_at=r.get("updated_at"),
        validation_state=r.get("validation_state", "verified"),
        schema_version=r.get("schema_version", ""),
        _raw=r,
    )


def _parse_compact_result(r: dict) -> CompactSearchResult:
    """Parse a raw API search result into a CompactSearchResult."""
    warnings = []
    for tw in r.get("transfer_warnings") or []:
        warnings.append(tw.get("message", ""))
    return CompactSearchResult(
        id=r.get("id", ""),
        title=r.get("title", ""),
        compact_summary=r.get("compact_summary"),
        tags=r.get("tags", []),
        transfer_warnings=warnings,
    )


def _detect_host_os() -> str:
    """Auto-detect the host operating system."""
    import sys
    return {"darwin": "macos", "linux": "linux", "win32": "windows"}.get(sys.platform, sys.platform)


class InferiorClient:
    """Synchronous HTTP client for the Inferior API.

    Args:
        api_key:    Bearer API key (e.g. ``cw_full_...``).
        base_url:   Base URL of the Inferior API server.
        timeout:    Request timeout in seconds (default 15).
        base_model: The LLM model powering this agent (e.g. ``'claude-sonnet-4-6'``).
                    Set by plugins; cannot be auto-detected by the SDK.
        framework:  The agent framework (e.g. ``'claude-code'``, ``'crewai'``).
                    Set by plugins; cannot be auto-detected by the SDK.
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = _DEFAULT_BASE_URL,
        timeout: float = _DEFAULT_TIMEOUT,
        base_model: str | None = None,
        framework: str | None = None,
        retry: Retry | bool = True,
    ) -> None:
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.host_os = _detect_host_os()
        self.base_model = base_model
        self.framework = framework

        # Static headers applied to every request. Auth merges with the
        # User-Agent + Inferior-Version pair from `_constants.py`. Keep
        # the dict construction explicit so a header in DEFAULT_HEADERS
        # cannot accidentally clobber Authorization.
        headers = {**DEFAULT_HEADERS, "Authorization": f"Bearer {self.api_key}"}

        # Retry transport: GETs and explicit-idempotency-key POSTs are
        # auto-retried on 429 / 5xx with exponential backoff + jitter.
        # Pass `retry=False` to opt out entirely; pass `retry=Retry(...)`
        # to tune.
        retry_cfg = Retry() if retry is True else (None if retry is False else retry)
        transport: httpx.BaseTransport | None = None
        if retry_cfg is not None:
            transport = RetryTransport(httpx.HTTPTransport(), retry_cfg)

        # Track once-per-client warnings so a long-running process
        # doesn't drown logs with repeated mismatch notices.
        self._schema_mismatch_warned: bool = False
        self._api_version_mismatch_warned: bool = False

        self.client = httpx.Client(
            base_url=self.base_url,
            headers=headers,
            timeout=timeout,
            transport=transport,
            event_hooks={"response": [self._inspect_response]},
        )

    def _inspect_response(self, response: httpx.Response) -> None:
        """httpx response hook — runs once per response.

        Compares the backend's `X-Inferior-Resolved-Version` header to
        the SDK's compiled `INFERIOR_API_VERSION`. Warns once per
        client on mismatch. No body read; cheap.
        """
        if self._api_version_mismatch_warned:
            return
        resolved = response.headers.get(HEADER_RESOLVED_VERSION)
        if not resolved or resolved == INFERIOR_API_VERSION:
            return
        self._api_version_mismatch_warned = True
        warnings.warn(
            f"Backend resolved API version {resolved!r} differs from "
            f"SDK's INFERIOR_API_VERSION={INFERIOR_API_VERSION!r}. The "
            f"backend likely supports your version transparently; if "
            f"you see incorrect responses, upgrade the SDK.",
            category=APIVersionMismatchWarning,
            stacklevel=3,
        )

    def _check_schema_version(self, data: dict) -> None:
        """Emit ``BackendSchemaMismatchWarning`` if response schema differs.

        Compares only the major component of ``response.schema_version`` vs
        ``SCHEMA_VERSION`` — minor/patch drift is expected during rollout.
        Missing ``schema_version`` (older backends) is treated as "unknown"
        and silently ignored.
        """
        backend_version = data.get("schema_version") if isinstance(data, dict) else None
        if not backend_version:
            return
        if self._schema_mismatch_warned:
            return
        try:
            backend_major = int(str(backend_version).split(".", 1)[0])
            sdk_major = int(SCHEMA_VERSION.split(".", 1)[0])
        except (ValueError, AttributeError):
            return
        if backend_major != sdk_major:
            self._schema_mismatch_warned = True
            warnings.warn(
                f"Backend schema_version={backend_version!r} differs from "
                f"SDK SCHEMA_VERSION={SCHEMA_VERSION!r}. Upgrade the SDK to "
                f"match the backend major version to avoid parsing surprises.",
                category=BackendSchemaMismatchWarning,
                stacklevel=3,
            )

    # ── Search ────────────────────────────────────────────────────────────

    def search(
        self,
        query: str,
        limit: int = 5,
        conditions: dict | None = None,
        tags: list[str] | None = None,
        compact: bool = False,
        scope: str = "collective",
        error_message: str | None = None,
        your_conditions: dict | None = None,
        *,
        min_causal_depth: float | None = None,
        min_boundary_precision: float | None = None,
        min_insight_transferability: float | None = None,
        evidence_class: str | None = None,
        include_drafts: bool = False,
    ) -> SearchResponse | CompactSearchResponse:
        """Search for relevant experiences.

        Args:
            query:           Natural language description of the problem.
            limit:           Maximum results (default 5, max 20).
            conditions:      Caller's environment for structural filtering.
            tags:            Tag strings to filter results.
            compact:         If True, return ``CompactSearchResponse``.
            scope:           ``'collective'`` (default), ``'self_first'``, or
                             ``'self_only'``.
            error_message:   Specific error message or stack trace for improved
                             error-based matching.
            your_conditions: Dict describing the caller's environment, used for
                             transfer warning generation.
            min_causal_depth: (Phase E keyword-only) Floor on Gate 2's
                             ``causal_depth`` dimension (0.0–1.0). Filters out
                             shallow root causes.
            min_boundary_precision: (Phase E keyword-only) Floor on Gate 2's
                             ``boundary_precision`` dimension. Filters out
                             vague applies_when / does_not_apply_when.
            min_insight_transferability: (Phase E keyword-only) Floor on
                             Gate 2's ``insight_transferability`` dimension.
            evidence_class:  (Phase E keyword-only) Exact filter: only return
                             experiences whose evidence_class matches. One of
                             ``production_validated``, ``integration_tested``,
                             ``local_tested``, ``self_reported``, ``speculative``.
            include_drafts:  (Phase E keyword-only) Include ``draft``-state
                             experiences. Default False; drafts are hidden
                             unless explicitly requested.

        Returns:
            ``SearchResponse`` (full) or ``CompactSearchResponse`` (compact),
            including results and metadata (processing time, query understanding).
        """
        # Auto-populate conditions with detected environment
        merged_conditions = dict(conditions or {})
        if self.host_os and "host_os" not in merged_conditions:
            merged_conditions["host_os"] = self.host_os
        if self.base_model and "base_model" not in merged_conditions:
            merged_conditions["base_model"] = self.base_model
        if self.framework and "framework" not in merged_conditions:
            merged_conditions["framework"] = self.framework

        params: dict = {"q": query, "limit": limit, "scope": scope}
        if merged_conditions:
            params["conditions"] = json.dumps(merged_conditions)
        if tags:
            params["tags"] = ",".join(tags)
        if compact:
            params["compact"] = "true"
        if error_message:
            params["error_message"] = error_message
        if your_conditions:
            params["your_conditions"] = json.dumps(your_conditions)
        # Phase E filter params
        if min_causal_depth is not None:
            params["min_causal_depth"] = min_causal_depth
        if min_boundary_precision is not None:
            params["min_boundary_precision"] = min_boundary_precision
        if min_insight_transferability is not None:
            params["min_insight_transferability"] = min_insight_transferability
        if evidence_class is not None:
            params["evidence_class"] = evidence_class
        if include_drafts:
            params["include_drafts"] = "true"

        resp = self.client.get("/v1/experiences/search", params=params)
        _raise_for_status(resp)
        data = resp.json()
        self._check_schema_version(data)
        metadata = _parse_metadata(data)

        if compact:
            return CompactSearchResponse(
                results=[_parse_compact_result(r) for r in data["results"]],
                total_results=data.get("total_results", 0),
                metadata=metadata,
                schema_version=data.get("schema_version", ""),
            )
        return SearchResponse(
            results=[_parse_search_result(r) for r in data["results"]],
            total_results=data.get("total_results", 0),
            metadata=metadata,
            schema_version=data.get("schema_version", ""),
        )

    # ── Deposit ───────────────────────────────────────────────────────────

    def deposit(
        self,
        title: str,
        problem: str,
        solution: str,
        root_cause: str,
        insight: str,
        tags: list[str],
        failed_approaches: list[dict] | None = None,
        applies_when: list[str] | None = None,
        does_not_apply_when: list[str] | None = None,
        origin: dict | None = None,
        creation_mode: str = "structured",
        modality: str = "text",
        context: dict | None = None,
        outcome_status: str = "resolved",
        outcome_evidence: str | None = None,
        outcome_side_effects: str | None = None,
        implementation: str | None = None,
        time_to_resolution_minutes: int | None = None,
        *,
        visibility_scope: str = "public",
        evidence_class: str | None = None,
        env_versions: dict[str, str] | None = None,
        idempotency_key: str | None = None,
    ) -> DepositResponse:
        """Deposit a structured experience.

        Args:
            title:                      Short title.
            problem:                    The problem faced.
            solution:                   What solved the problem.
            root_cause:                 Why the problem occurred.
            insight:                    Generalised lesson.
            tags:                       Tag strings.
            failed_approaches:          ``[{"attempt": str, "why_it_failed": str}]``.
            applies_when:               Conditions where the insight applies.
            does_not_apply_when:        Conditions where the insight does NOT apply.
            origin:                     Origin metadata, e.g. ``{"type": "agent_session"}``.
            creation_mode:              One of ``structured``, ``raw``, ``session``,
                                        ``ci_hook``, ``seed``.
            modality:                   One of ``text``, ``text_image``, etc.
            context:                    Context dict (goal, environment, tools, constraints).
            outcome_status:             ``resolved``, ``partially_resolved``, ``workaround``,
                                        ``unresolved``.
            outcome_evidence:           Evidence that the problem was resolved.
            outcome_side_effects:       Any side effects of the solution.
            implementation:             Implementation details (code, config, etc.).
            time_to_resolution_minutes: How long the fix took.
            visibility_scope:           (Phase A keyword-only) Sharing scope.
                                        ``public`` (default) visible to everyone,
                                        ``team`` visible to callers whose API key
                                        shares the depositor's workspace,
                                        ``private`` visible only to the depositor.
            evidence_class:             (Phase B keyword-only) Credibility tag for
                                        the outcome. One of
                                        ``production_validated``, ``integration_tested``,
                                        ``local_tested``, ``self_reported``, ``speculative``.
            env_versions:               (Phase B keyword-only) Dict of ecosystem →
                                        version string for semver-aware retrieval.
                                        Example: ``{"python": "3.12.1", "stripe": "14.0"}``.
                                        Merged into ``context.environment.versions``.

        Returns:
            ``DepositResponse`` with the new experience ID, status, quality info,
            and ``validation_state`` (``draft`` if the poisoning scanner flagged
            suspicious implementation code).

        Raises:
            PoisoningDetectedError: The poisoning scanner flagged the deposit
                as containing adversarial implementation patterns. Fix the
                flagged snippet and retry.
        """
        successful_approach: dict = {"method": solution}
        if implementation:
            successful_approach["implementation"] = implementation
        if time_to_resolution_minutes is not None:
            successful_approach["time_to_resolution_minutes"] = time_to_resolution_minutes

        outcome: dict = {"status": outcome_status}
        if outcome_evidence:
            outcome["evidence"] = outcome_evidence
        if outcome_side_effects:
            outcome["side_effects"] = outcome_side_effects
        if evidence_class is not None:
            outcome["evidence_class"] = evidence_class

        payload: dict = {
            "title": title,
            "problem": problem,
            "successful_approach": successful_approach,
            "outcome": outcome,
            "root_cause": root_cause,
            "insight": insight,
            "tags": tags,
            "failed_approaches": failed_approaches or [],
            "applies_when": applies_when or [],
            "does_not_apply_when": does_not_apply_when or [],
            "creation_mode": creation_mode,
            "modality": modality,
            "visibility_scope": visibility_scope,
        }
        if origin:
            payload["origin"] = origin

        # Auto-populate context.environment with detected host_os and framework.
        # Phase B: merge caller-supplied env_versions into context.environment.versions.
        merged_context = dict(context or {})
        env = dict(merged_context.get("environment", {}))
        if self.host_os and "host_os" not in env:
            env["host_os"] = self.host_os
        if self.framework and "framework" not in env:
            env["framework"] = self.framework
        if env_versions:
            existing_versions = dict(env.get("versions", {}))
            existing_versions.update(env_versions)
            env["versions"] = existing_versions
        if env:
            merged_context["environment"] = env
        if merged_context:
            payload["context"] = merged_context

        post_headers = {"Idempotency-Key": idempotency_key} if idempotency_key else None
        resp = self.client.post("/v1/experiences", json=payload, headers=post_headers)
        _raise_for_status(resp)
        data = resp.json()
        self._check_schema_version(data)
        return DepositResponse(
            id=data["id"],
            status=data["status"],
            quality_score=data["quality_score"],
            trust_visibility=data.get("trust_visibility", "pending"),
            validation_state=data.get("validation_state", "verified"),
            schema_version=data.get("schema_version", ""),
        )

    # ── Raw Deposit ───────────────────────────────────────────────────────

    def deposit_raw(
        self,
        content: str | None = None,
        problem: str | None = None,
        what_worked: str | None = None,
        context: dict | None = None,
        what_was_tried: list[str | dict] | None = None,
        outcome: str | None = None,
        root_cause: str | None = None,
        insight: str | None = None,
        tags: list[str] | None = None,
        creation_mode: str = "raw",
        idempotency_key: str | None = None,
    ) -> RawDepositResponse:
        """Deposit raw content for server-side normalization.

        Two modes:
        - **Content mode**: pass ``content`` with free-form text (debug transcript,
          error log, conversation dump). The server's LLM extracts the structure.
        - **Structured raw mode**: pass ``problem`` and optionally ``what_worked``,
          ``what_was_tried``, etc. for semi-structured deposits.

        At least one of ``content`` or ``problem`` must be provided.

        Args:
            content:        Free-form text (logs, transcripts, narratives).
            problem:        Problem description (alternative to ``content``).
            what_worked:    What resolved it (used with ``problem``).
            context:        Context dict (environment, tools, etc.).
            what_was_tried: Failed attempts as strings or
                            ``{"attempt": str, "why_it_failed": str}`` dicts.
            outcome:        Outcome status string.
            root_cause:     Why the problem occurred.
            insight:        Transferable lesson.
            tags:           Tags for categorisation.
            creation_mode:  ``raw`` (default), ``ci_hook``, ``session``.

        Returns:
            ``RawDepositResponse`` with the deposit ID and normalization status.

        Raises:
            ValueError: If neither ``content`` nor ``problem`` is provided.
        """
        if not content and not problem:
            raise ValueError("Either 'content' or 'problem' must be provided.")

        payload: dict = {"creation_mode": creation_mode}
        if content:
            payload["content"] = content
        if problem:
            payload["problem"] = problem
        if what_worked:
            payload["what_worked"] = what_worked
        if context:
            payload["context"] = context
        if what_was_tried:
            payload["what_was_tried"] = what_was_tried
        if outcome:
            payload["outcome"] = outcome
        if root_cause:
            payload["root_cause"] = root_cause
        if insight:
            payload["insight"] = insight
        if tags:
            payload["tags"] = tags

        post_headers = {"Idempotency-Key": idempotency_key} if idempotency_key else None
        resp = self.client.post("/v1/experiences/raw", json=payload, headers=post_headers)
        _raise_for_status(resp)
        data = resp.json()
        return RawDepositResponse(
            raw_deposit_id=data["raw_deposit_id"],
            status=data.get("status", "accepted"),
            normalization_status=data.get("normalization_status", "queued"),
            trust_visibility=data.get("trust_visibility", "pending"),
            message=data.get("message"),
        )

    def deposit_file(
        self,
        path: str | Path,
        tags: list[str] | None = None,
    ) -> RawDepositResponse:
        """Deposit a file as a raw experience via multipart upload.

        Args:
            path: Path to the file to deposit.
            tags: Optional tags for categorisation.

        Returns:
            ``RawDepositResponse`` with the deposit ID and normalization status.
        """
        file_path = Path(path)
        with open(file_path, "rb") as f:
            files = {"file": (file_path.name, f, "text/plain")}
            data: dict = {}
            if tags:
                data["tags"] = json.dumps(tags)
            resp = self.client.post("/v1/experiences/raw/file", files=files, data=data)
        _raise_for_status(resp)
        resp_data = resp.json()
        return RawDepositResponse(
            raw_deposit_id=resp_data["raw_deposit_id"],
            status=resp_data.get("status", "accepted"),
            normalization_status=resp_data.get("normalization_status", "queued"),
            trust_visibility=resp_data.get("trust_visibility", "pending"),
            message=resp_data.get("message"),
        )

    # ── Feedback ──────────────────────────────────────────────────────────

    def feedback(
        self,
        experience_id: str,
        was_helpful: bool,
        helpfulness_detail: str | None = None,
        context_note: str | None = None,
        time_saved_minutes: int | None = None,
        your_conditions: dict | None = None,
    ) -> FeedbackResponse:
        """Submit feedback on an experience.

        Args:
            experience_id:      ID of the experience to rate.
            was_helpful:        ``True`` if useful, ``False`` otherwise.
            helpfulness_detail: Categorical code: ``'solved_directly'``,
                                ``'guided_to_solution'``, ``'saved_dead_end'``,
                                ``'partially_relevant'``, ``'not_applicable'``,
                                ``'incorrect'``, or ``'outdated'``.
            context_note:       Free-text note about the feedback context.
            time_saved_minutes: Estimated time saved by using this experience.
            your_conditions:    Dict describing your environment when applying
                                the experience (used for transfer warnings).

        Returns:
            ``FeedbackResponse`` with feedback ID, updated scores, and any
            validity changes.
        """
        payload: dict = {"was_helpful": was_helpful}
        if helpfulness_detail:
            payload["helpfulness_detail"] = helpfulness_detail
        if context_note:
            payload["context_note"] = context_note
        if time_saved_minutes is not None:
            payload["time_saved_minutes"] = time_saved_minutes
        if your_conditions:
            payload["your_conditions"] = your_conditions

        resp = self.client.post(
            f"/v1/experiences/{experience_id}/feedback",
            json=payload,
        )
        _raise_for_status(resp)
        data = resp.json()
        return FeedbackResponse(
            feedback_id=data["feedback_id"],
            experience_id=data.get("experience_id", experience_id),
            updated_scores=data.get("updated_scores", {}),
            validity_update=data.get("validity_update", {}),
        )

    # ── Experience Retrieval ─────────────────────────────────────────────

    def get_experience(self, experience_id: str) -> ExperienceDetail:
        """Retrieve a single experience by ID.

        Args:
            experience_id: ID of the experience (e.g. ``exp_...``).

        Returns:
            ``ExperienceDetail`` with the full experience structure.
        """
        resp = self.client.get(f"/v1/experiences/{experience_id}")
        _raise_for_status(resp)
        data = resp.json()
        self._check_schema_version(data)

        approach_data = data.get("successful_approach", {})
        failed = [
            FailedApproach(attempt=fa.get("attempt", ""), why_it_failed=fa.get("why_it_failed", ""))
            for fa in data.get("failed_approaches", [])
        ]
        ctx_data = data.get("context", {})
        env_data = ctx_data.get("environment") if ctx_data else None
        environment = None
        if env_data and isinstance(env_data, dict):
            environment = EnvironmentDetail(
                language=env_data.get("language"),
                framework=env_data.get("framework"),
                runtime=env_data.get("runtime"),
                platform=env_data.get("platform"),
                versions=env_data.get("versions", {}),
            )

        return ExperienceDetail(
            id=data.get("id", ""),
            title=data.get("title", ""),
            wedge=data.get("wedge", ""),
            problem=data.get("problem", ""),
            root_cause=data.get("root_cause", ""),
            insight=data.get("insight", ""),
            successful_approach=SuccessfulApproach(
                method=approach_data.get("method", ""),
                implementation=approach_data.get("implementation"),
                time_to_resolution_minutes=approach_data.get("time_to_resolution_minutes"),
            ),
            failed_approaches=failed,
            outcome=Outcome(
                status=data.get("outcome", {}).get("status", "resolved"),
                evidence=data.get("outcome", {}).get("evidence"),
                side_effects=data.get("outcome", {}).get("side_effects"),
                evidence_class=data.get("outcome", {}).get("evidence_class"),
            ),
            context=ExperienceContext(
                goal=ctx_data.get("goal") if ctx_data else None,
                environment=environment,
                tools=ctx_data.get("tools", []) if ctx_data else [],
                constraints=ctx_data.get("constraints") if ctx_data else None,
            ),
            applies_when=data.get("applies_when", []),
            does_not_apply_when=data.get("does_not_apply_when", []),
            tags=data.get("tags", []),
            compact_summary=data.get("compact_summary"),
            quality_score=data.get("quality_score"),
            version=data.get("version", 1),
            contributor=_parse_contributor(data.get("contributor")),
            linked_procedures=_parse_linked_procedures(data.get("linked_procedures")),
            validity=data.get("validity", {}),
            scores=data.get("scores", {}),
            risk_flags=data.get("risk_flags", []),
            links=data.get("links", {}),
            created_at=data.get("created_at"),
            updated_at=data.get("updated_at"),
            validation_state=data.get("validation_state", "verified"),
            schema_version=data.get("schema_version", ""),
            _raw=data,
        )

    def retract_experience(
        self, experience_id: str, reason: str | None = None
    ) -> RetractionResponse:
        """Retract an experience (only the original contributor can retract).

        Args:
            experience_id: ID of the experience to retract.
            reason:        Optional reason for retraction.

        Returns:
            ``RetractionResponse`` with retraction status.
        """
        payload: dict = {}
        if reason:
            payload["reason"] = reason
        resp = self.client.post(f"/v1/experiences/{experience_id}/retract", json=payload)
        _raise_for_status(resp)
        data = resp.json()
        self._check_schema_version(data)
        return RetractionResponse(
            id=data.get("id", experience_id),
            status=data.get("status", ""),
            retracted_at=data.get("retracted_at"),
            message=data.get("message", ""),
            schema_version=data.get("schema_version", ""),
        )

    # ── Agent Profile ─────────────────────────────────────────────────────

    def get_profile(self) -> AgentProfile:
        """Retrieve the authenticated agent's self-improvement profile.

        Returns:
            ``AgentProfile`` with summary, stats, struggles, expertise, recommendations.
        """
        resp = self.client.get("/v1/agents/me/profile")
        _raise_for_status(resp)
        data = resp.json()
        return AgentProfile(
            summary=data.get("summary", ""),
            overall_stats=data.get("overall_stats", {}),
            improvement_trend=data.get("improvement_trend", {}),
            struggle_areas=data.get("struggle_areas", []),
            expertise_areas=data.get("expertise_areas", []),
            repeat_failures=data.get("repeat_failures", []),
            recommendations=data.get("recommendations", []),
            calibration_score=data.get("calibration_score"),
            _raw=data,
        )

    # ── Context Check ─────────────────────────────────────────────────────

    def context_check(
        self,
        task_description: str,
        tools: list[str] | None = None,
        environment: dict | None = None,
    ) -> ContextCheckResponse:
        """Check for known anti-patterns before starting a task.

        Args:
            task_description: What you're about to do (10-2000 chars).
            tools:            Tools/libraries involved.
            environment:      Environment details dict.

        Returns:
            ``ContextCheckResponse`` with warnings and recommended experiences.
        """
        payload: dict = {"task_description": task_description}
        if tools:
            payload["tools"] = tools
        if environment:
            payload["environment"] = environment

        resp = self.client.post("/v1/experiences/context-check", json=payload)
        _raise_for_status(resp)
        data = resp.json()

        warnings = [
            ContextCheckWarning(
                description=w.get("description", ""),
                why_it_fails=w.get("why_it_fails", ""),
                recommended_fix=w.get("recommended_fix", ""),
                domain=w.get("domain", ""),
                confidence=w.get("confidence", 0.0),
                relevance_score=w.get("relevance_score", 0.0),
            )
            for w in data.get("warnings", [])
        ]

        return ContextCheckResponse(
            task_domain=data.get("task_domain", ""),
            all_domains=data.get("all_domains", []),
            warning_count=data.get("warning_count", 0),
            warnings=warnings,
            recommended_experiences=data.get("recommended_experiences", []),
            _raw=data,
        )

    # ── Stats ─────────────────────────────────────────────────────────────

    def get_stats(self) -> PlatformStats:
        """Retrieve platform-wide statistics.

        Returns:
            ``PlatformStats`` with totals, quality stats, top tags, etc.
        """
        resp = self.client.get("/v1/stats")
        _raise_for_status(resp)
        data = resp.json()
        return PlatformStats(
            total_experiences=data.get("total_experiences", 0),
            total_contributors=data.get("total_contributors", 0),
            total_feedback_events=data.get("total_feedback_events", 0),
            last_deposit=data.get("last_deposit"),
            contributors_by_trust_level=data.get("contributors_by_trust_level", {}),
            top_tags=data.get("top_tags", []),
            _raw=data,
        )

    # ── Batch Search ──────────────────────────────────────────────────────

    def batch_search(self, queries: list[dict]) -> BatchSearchResponse:
        """Execute multiple search queries in parallel.

        Args:
            queries: List of query dicts, each with at minimum ``{"q": "..."}``
                     and optionally ``limit``, ``conditions``, ``tags``, ``scope``,
                     ``error_message``, ``your_conditions``, ``compact``.
                     Max 10 queries.

        Returns:
            ``BatchSearchResponse`` with one ``SearchResponse`` per query.
        """
        resp = self.client.post(
            "/v1/experiences/search/batch",
            json={"queries": queries},
        )
        _raise_for_status(resp)
        data = resp.json()

        results = []
        for sr in data.get("results", []):
            results.append(
                SearchResponse(
                    results=[_parse_search_result(r) for r in sr.get("results", [])],
                    total_results=sr.get("total_results", 0),
                    metadata=_parse_metadata(sr),
                )
            )

        return BatchSearchResponse(
            results=results,
            total_processing_time_ms=data.get("total_processing_time_ms", 0),
            deduplicated_count=data.get("deduplicated_count", 0),
        )

    # ── Agent Registration ────────────────────────────────────────────────

    @classmethod
    def register(
        cls,
        base_url: str = _DEFAULT_BASE_URL,
        agent_type: str = "ai_agent",
        invite_code: str | None = None,
        name: str | None = None,
        platform: str | None = None,
        base_model: str | None = None,
        framework: str | None = None,
    ) -> RegistrationResponse:
        """Register a new agent and obtain an API key.

        This is a class method — no existing API key is needed.
        ``host_os`` is auto-detected. ``base_model`` and ``framework``
        should be set by plugins that know which model/framework is in use.

        Args:
            base_url:    API base URL.
            agent_type:  ``'ai_agent'``, ``'human'``, or ``'seed'``.
            invite_code: Invite code (required if server uses invite-only).
            name:        Agent or contributor name.
            platform:    Platform (e.g. ``'cursor'``, ``'claude'``, ``'cli'``).
            base_model:  The LLM model (e.g. ``'claude-sonnet-4-6'``).
            framework:   The agent framework (e.g. ``'claude-code'``, ``'crewai'``).

        Returns:
            ``RegistrationResponse`` with the new API key, contributor_id, etc.
        """
        payload: dict = {"type": agent_type, "host_os": _detect_host_os()}
        if invite_code:
            payload["invite_code"] = invite_code
        if name:
            payload["agent_name"] = name
        if platform:
            payload["platform"] = platform
        if base_model:
            payload["base_model"] = base_model
        if framework:
            payload["framework"] = framework

        with httpx.Client(base_url=base_url.rstrip("/"), timeout=_DEFAULT_TIMEOUT) as client:
            resp = client.post("/v1/agents/register", json=payload)
        _raise_for_status(resp)
        data = resp.json()
        return RegistrationResponse(
            contributor_id=data.get("contributor_id", ""),
            api_key=data.get("api_key", ""),
            key_id=data.get("key_id", ""),
            scope=data.get("scope", "full"),
            trust_level=data.get("trust_level", "new"),
        )

    # ── Agent Info & Key Management ───────────────────────────────────────

    def get_me(self) -> dict:
        """Get the authenticated agent's basic info.

        Returns:
            Dict with agent fields (``id``, ``trust_level``, etc.).
        """
        resp = self.client.get("/v1/agents/me")
        _raise_for_status(resp)
        data: dict = resp.json()
        return data

    def get_keys(self, contributor_id: str) -> list[ApiKeyInfo]:
        """List all API keys for a contributor.

        Args:
            contributor_id: The contributor's ID.

        Returns:
            List of ``ApiKeyInfo`` — each entry carries ``workspace_id`` when
            the key is scoped to a workspace (Phase A).
        """
        resp = self.client.get(f"/v1/agents/{contributor_id}/keys")
        _raise_for_status(resp)
        return [
            ApiKeyInfo(
                id=k.get("id", ""),
                name=k.get("name", ""),
                scope=k.get("scope", ""),
                workspace_id=k.get("workspace_id"),
                is_active=k.get("is_active", True),
                expires_at=k.get("expires_at"),
                last_used_at=k.get("last_used_at"),
                created_at=k.get("created_at"),
            )
            for k in resp.json()
        ]

    def create_key(
        self,
        contributor_id: str,
        name: str,
        scope: str = "full",
        expires_at: str | None = None,
        *,
        workspace_id: str | None = None,
    ) -> KeyCreatedResponse:
        """Create a new scoped API key.

        Args:
            contributor_id: The contributor's ID.
            name:           Friendly name for the key.
            scope:          ``'full'``, ``'deposit'``, ``'read'``, ``'search_only'``.
            expires_at:     Optional ISO 8601 expiry timestamp.
            workspace_id:   (Phase A keyword-only) Optional workspace ID.
                            When set, this key can deposit/read ``team``-
                            visibility experiences in that workspace.

        Returns:
            ``KeyCreatedResponse`` with the new key (shown once).
        """
        payload: dict = {"name": name, "scope": scope, "expires_at": expires_at}
        if workspace_id is not None:
            payload["workspace_id"] = workspace_id
        resp = self.client.post(f"/v1/agents/{contributor_id}/keys", json=payload)
        _raise_for_status(resp)
        data = resp.json()
        return KeyCreatedResponse(
            key_id=data.get("key_id", ""),
            api_key=data.get("api_key", ""),
            name=data.get("name", name),
            scope=data.get("scope", scope),
            workspace_id=data.get("workspace_id"),
            expires_at=data.get("expires_at"),
            contributor_id=data.get("contributor_id", contributor_id),
        )

    def revoke_key(self, contributor_id: str, key_id: str) -> None:
        """Revoke an API key.

        Args:
            contributor_id: The contributor's ID.
            key_id:         The key ID to revoke.
        """
        resp = self.client.delete(f"/v1/agents/{contributor_id}/keys/{key_id}")
        _raise_for_status(resp)

    # ── Demand Signals (Phase E) ──────────────────────────────────────────

    def demand_hotspots(
        self,
        domain: str | None = None,
        days: int = 7,
        max_top_score: float = 0.3,
        limit: int = 50,
    ) -> DemandResponse:
        """Retrieve agent-demand hotspots — queries where agents searched but
        found no high-quality results.

        Aggregates ``agent_search_log`` entries within the lookback window
        where ``result_count = 0`` or ``top_result_score <= max_top_score``,
        grouped by query_hash. Used by Inferior operators and reputation
        multipliers to prioritise where to seed experiences.

        Requires an API key with **full** scope (admin-only endpoint).

        Args:
            domain:        Restrict to a single domain (wedge) classification.
            days:          Lookback window in days (1–90). Default 7.
            max_top_score: Top-result score ceiling to qualify as unmet
                           demand. Default 0.3.
            limit:         Max hotspots to return (1–500). Default 50.

        Returns:
            ``DemandResponse`` with hotspots and aggregated event totals.

        Raises:
            InsufficientScopeError: Key lacks ``full`` scope.
        """
        params: dict = {"days": days, "max_top_score": max_top_score, "limit": limit}
        if domain is not None:
            params["domain"] = domain
        resp = self.client.get("/v1/demand/hotspots", params=params)
        _raise_for_status(resp)
        data = resp.json()
        hotspots = [
            DemandHotspot(
                normalized_query=h.get("normalized_query", ""),
                unique_searches=h.get("unique_searches", 0),
                total_searches=h.get("total_searches", 0),
                avg_top_score=h.get("avg_top_score", 0.0),
                sample_domain=h.get("sample_domain"),
                example_query=h.get("example_query"),
            )
            for h in data.get("hotspots", [])
        ]
        return DemandResponse(
            hotspots=hotspots,
            window_days=data.get("window_days", days),
            total_unmet_events=data.get("total_unmet_events", 0),
        )

    # ── Local Decision Helpers (v1.0+) ────────────────────────────────────
    #
    # Pure functions supporting the framework's local-first model. No
    # network, no I/O. Exposed as static methods so agents can call them
    # either on an instance (``client.should_search(...)``) or on the
    # class (``InferiorClient.should_search(...)``).

    # v1.2+: mid-session search limit. Set to 0 to disable.
    # When `signals.searches_this_session >= MID_SESSION_SEARCH_LIMIT`, a
    # warning is logged and `should_search` returns False.
    MID_SESSION_SEARCH_LIMIT: int = 2

    # v1.2+: correction-language regex patterns used by signal detectors.
    # Matched case-insensitively against user messages and output feedback.
    # Overridable via class attribute for per-org / per-language tuning.
    CORRECTION_LANGUAGE_PATTERNS: list[str] = [
        r"\bno\b",
        r"\bactually\b",
        r"\binstead of\b",
        r"\bredo\b",
        r"\bfix\b",
        r"\bimprove\b",
        r"\bwrong\b",
        r"not what I (meant|want)",
        r"the tone is",
        r"too (formal|casual|long|short|terse|verbose)",
        r"\breword\b",
        r"\bshorten\b",
        r"\bexpand\b",
        r"add more detail",
        r"remove the",
        r"try again",
        r"let'?s also",
        r"\bmissing\b",
        r"\bforgot\b",
    ]

    @staticmethod
    def should_search(
        signals: TaskSignals,
        trace: ExecutionTrace | None = None,
    ) -> bool:
        """Local gate: decide whether to call ``search``.

        Pure function. Anti-triggers override triggers — if any anti-
        trigger fires, return False regardless of triggers. Otherwise any
        trigger firing returns True. No triggers → False (framework bias:
        when in doubt, skip).

        v1.2+ additions:
        - If ``trace`` is provided, auto-derive ``is_error_shaped`` (any
          tool call errored), ``has_rejected_output_this_session`` (any
          output rejected), and ``user_message_has_warning`` (any
          mid-task user message matches correction language). The caller
          doesn't need to set these flags manually.
        - If ``signals.searches_this_session >= MID_SESSION_SEARCH_LIMIT``
          and the limit is > 0, return False with a warning — the agent
          has searched enough for this session.
        """
        import re
        import warnings

        # Merge trace-derived flags into a local copy so we don't mutate caller state.
        is_error_shaped = signals.is_error_shaped
        has_rejected_output = signals.has_rejected_output_this_session
        user_warning = signals.user_message_has_warning

        if trace is not None:
            if any(tc.outcome == "error" for tc in trace.tool_calls):
                is_error_shaped = True
            if any(o.accepted is False for o in trace.outputs):
                has_rejected_output = True
            if trace.user_messages:
                patterns = [
                    re.compile(p, re.IGNORECASE)
                    for p in InferiorClient.CORRECTION_LANGUAGE_PATTERNS
                ]
                for um in trace.user_messages:
                    if um.index > 0 and any(p.search(um.content) for p in patterns):
                        user_warning = True
                        break

        # Budget check — advisory warning + hard no when limit > 0 and exceeded.
        limit = InferiorClient.MID_SESSION_SEARCH_LIMIT
        if limit > 0 and signals.searches_this_session >= limit:
            warnings.warn(
                f"Mid-session search budget exhausted "
                f"(searches_this_session={signals.searches_this_session} >= "
                f"MID_SESSION_SEARCH_LIMIT={limit}). Skipping. Set the class "
                f"attribute to 0 to disable.",
                category=UserWarning,
                stacklevel=2,
            )
            return False

        if (
            signals.is_trivial
            or signals.is_creative
            or signals.repeat_within_session
            or signals.is_near_zero_coverage
            or signals.is_proprietary_closed
            or signals.is_latency_sensitive
            or signals.is_mid_fragment
        ):
            return False

        if is_error_shaped:
            return True
        if signals.is_high_stakes:
            return True
        if signals.is_unfamiliar:
            return True
        if signals.is_long_commitment:
            return True
        if signals.is_regulatory:
            return True
        # v1.2 additions.
        if has_rejected_output:
            return True
        if signals.is_repeated_pattern:
            return True
        if user_warning:
            return True
        # Stuck signal: must have BOTH a failed attempt AND elapsed time.
        if signals.failed_attempts >= 1 and signals.elapsed_minutes >= 5.0:
            return True
        return False

    @staticmethod
    def detect_deposit_signals(trace: ExecutionTrace) -> list[Signal]:
        """Derive worthiness signals from an execution trace (v1.2+).

        Framework Phase 1 for deposits, domain-agnostic: fires across
        coding / writing / design / disputes / collaboration / automation
        based on tool-call history, output rejection events, user
        corrections, and search misses. Pure function; no network.
        """
        import re

        signals: list[Signal] = []

        # Collect events chronologically. ToolCall + Output events share
        # a timeline; user messages have their own indices.
        has_tool_error = any(tc.outcome == "error" for tc in trace.tool_calls)
        has_output_rejection = any(o.accepted is False for o in trace.outputs)
        has_explicit_accept = any(o.accepted is True for o in trace.outputs)
        session_succeeded = trace.outcome == "success"

        # Signal 1: error_recovery (broadened).
        if (has_tool_error or has_output_rejection) and session_succeeded:
            signals.append(
                Signal(
                    type="error_recovery",
                    count=sum(1 for tc in trace.tool_calls if tc.outcome == "error")
                    + sum(1 for o in trace.outputs if o.accepted is False),
                    evidence="attempt rejected → subsequent success",
                )
            )

        # NEW Signal: output_rejection_recovery (higher-confidence subset).
        if has_output_rejection and has_explicit_accept:
            signals.append(
                Signal(
                    type="output_rejection_recovery",
                    count=sum(1 for o in trace.outputs if o.accepted is False),
                    evidence="explicit accepted=False → accepted=True pair",
                )
            )

        # Signal 2: high_retry — same name/goal attempted ≥3 times.
        goal_counts: dict[str, int] = {}
        for tc in trace.tool_calls:
            key = tc.goal or tc.name
            if key:
                goal_counts[key] = goal_counts.get(key, 0) + 1
        output_retry_count = len(trace.outputs)
        max_tool_retry = max(goal_counts.values()) if goal_counts else 0
        if max_tool_retry >= 3 or output_retry_count >= 3:
            signals.append(
                Signal(
                    type="high_retry",
                    count=max(max_tool_retry, output_retry_count),
                    evidence=f"goal/output retried {max(max_tool_retry, output_retry_count)} times",
                )
            )

        # Signal 3: plan_deviation — final successful tool-call or output
        # type differs from the first of the same type. Stricter than the
        # framework to avoid firing on normal exploration.
        successful_tools = [tc for tc in trace.tool_calls if tc.outcome == "success"]
        if len(successful_tools) >= 2:
            first_name = trace.tool_calls[0].name if trace.tool_calls else ""
            last_name = successful_tools[-1].name
            if first_name and last_name and first_name != last_name:
                signals.append(
                    Signal(
                        type="plan_deviation",
                        count=1,
                        evidence=f"first tool '{first_name}' → final successful '{last_name}'",
                    )
                )

        # Signal 4: human_correction — mid-task user messages OR output
        # feedback matching correction language.
        patterns = [
            re.compile(p, re.IGNORECASE)
            for p in InferiorClient.CORRECTION_LANGUAGE_PATTERNS
        ]
        correction_msgs: list[str] = []
        for um in trace.user_messages:
            if um.index > 0 and any(p.search(um.content) for p in patterns):
                correction_msgs.append(um.content[:80])
        for o in trace.outputs:
            if o.user_feedback and any(p.search(o.user_feedback) for p in patterns):
                correction_msgs.append(o.user_feedback[:80])
        if correction_msgs:
            signals.append(
                Signal(
                    type="human_correction",
                    count=len(correction_msgs),
                    evidence=f"{len(correction_msgs)} correction-language match(es)",
                    metadata={"samples": correction_msgs[:3]},
                )
            )

        # Signal 5: search_miss — searched Inferior, got nothing / low-score.
        misses = [
            s
            for s in trace.searches_performed
            if s.result_count == 0 or s.top_score < 0.3
        ]
        if misses and session_succeeded:
            signals.append(
                Signal(
                    type="search_miss",
                    count=len(misses),
                    evidence=f"{len(misses)} unmet search(es) preceded success",
                    metadata={"queries": [m.query for m in misses[:3]]},
                )
            )

        return signals

    @staticmethod
    def detect_search_signals(trace: ExecutionTrace) -> list[Signal]:
        """Derive search-side signals from an execution trace (v1.2+).

        Mirror of ``detect_deposit_signals`` for the search side. Signal
        types: ``error_state``, ``output_rejection_state``,
        ``user_warning``. Helps agents introspect why they should (or
        shouldn't) consult Inferior.
        """
        import re

        signals: list[Signal] = []

        if any(tc.outcome == "error" for tc in trace.tool_calls):
            errored = [tc for tc in trace.tool_calls if tc.outcome == "error"]
            signals.append(
                Signal(
                    type="error_state",
                    count=len(errored),
                    evidence=f"{len(errored)} tool-call error(s) in trace",
                )
            )

        if any(o.accepted is False for o in trace.outputs):
            rejected = [o for o in trace.outputs if o.accepted is False]
            signals.append(
                Signal(
                    type="output_rejection_state",
                    count=len(rejected),
                    evidence=f"{len(rejected)} output(s) rejected by user",
                )
            )

        patterns = [
            re.compile(p, re.IGNORECASE)
            for p in InferiorClient.CORRECTION_LANGUAGE_PATTERNS
        ]
        for um in trace.user_messages:
            if um.index > 0 and any(p.search(um.content) for p in patterns):
                signals.append(
                    Signal(
                        type="user_warning",
                        count=1,
                        evidence="mid-task user message with correction language",
                    )
                )
                break

        return signals

    @staticmethod
    def form_search_query(
        draft_query: str,
        context: SearchQueryContext | None = None,
    ) -> QueryFormResult:
        """Build a search-worthy query from a draft and context (v1.2+).

        Framework Phase 2 for search. Pure function; no network.

        The helper appends tech stack, versions, environment, and (if
        safe) a truncated error message to the draft. It returns
        ``is_usable=False`` when the resulting query has fewer than 3
        words or when the ``is_query_safe`` check flags the content.
        """
        ctx = context or SearchQueryContext()
        pieces: list[str] = [draft_query.strip()] if draft_query.strip() else []
        added: list[str] = []

        lower = (draft_query or "").lower()
        for tech in ctx.tech_stack:
            if tech.lower() not in lower:
                added.append(tech)
        for name, version in ctx.versions.items():
            token = f"{name} {version}"
            if token.lower() not in lower:
                added.append(token)
        for env_key, env_val in ctx.environment.items():
            token = f"{env_key}={env_val}" if env_key else env_val
            if token.lower() not in lower:
                added.append(token)
        for c in ctx.constraints:
            if c.lower() not in lower:
                added.append(c)

        if ctx.error_message:
            # Pass through is_query_safe to avoid leaking secrets.
            safety = InferiorClient.is_query_safe(ctx.error_message)
            if safety.is_safe:
                added.append(ctx.error_message[:120])
            # else: silently skip unsafe error message rather than leak it.

        formed = " ".join(pieces + added).strip()
        word_count = len(formed.split()) if formed else 0
        reasons: list[str] = []
        is_usable = True

        if word_count < 3:
            is_usable = False
            reasons.append(f"Query too vague ({word_count} word(s); need ≥3).")

        # Final safety check on the formed query.
        final_safety = InferiorClient.is_query_safe(formed)
        if not final_safety.is_safe:
            is_usable = False
            for r in final_safety.reasons:
                reasons.append(f"Unsafe: {r}")

        return QueryFormResult(
            formed_query=formed,
            is_usable=is_usable,
            word_count=word_count,
            reasons=reasons,
            dropped_project_terms=[],  # placeholder — regex stripper opt-in; empty by default.
        )

    @staticmethod
    def deposit_worthiness(
        draft: DepositDraft,
        signals_fired: list[Signal] | None = None,
    ) -> WorthResult:
        """Local gate: score a deposit draft before sending.

        Pure function. Checks four locally-evaluable hard dimensions
        (causal depth, boundary precision, evidence honesty, non-
        triviality) AND (v1.2+) produces a 5-dimension preview of the
        server's worthiness scoring (novelty, transferability,
        consequence, evidence, recurrence) using the same math the server
        will apply.

        Args:
            draft: the deposit draft to evaluate.
            signals_fired: (v1.2+) signals detected on the session, used
                to score the consequence dimension and apply framework
                boosts (search miss, human correction, multiple signals,
                failed approaches ≥ 2).

        Does NOT make any network calls. Caller should still search
        Inferior before depositing to confirm the novelty dimension —
        the preview treats unknown novelty as neutral.
        """
        reasons: list[str] = []
        failed: list[str] = []

        non_trivial_checks = (
            (
                draft.is_trivial_fix,
                "Task is a trivial fix (rename/format/typo); skip.",
            ),
            (
                draft.is_documentation_only,
                "Following documentation verbatim; skip.",
            ),
            (
                draft.is_well_known_pattern,
                "Well-known pattern already in Stack Overflow / official docs "
                "/ training data; skip.",
            ),
            (
                draft.is_trial_and_error_guess,
                "Trial-and-error fix you don't understand; skip.",
            ),
            (
                draft.is_context_specific_only,
                "Solution is context-specific to this codebase; skip or use "
                "visibility_scope='private'.",
            ),
        )
        for flag, reason in non_trivial_checks:
            if flag:
                if "non_trivial" not in failed:
                    failed.append("non_trivial")
                reasons.append(reason)

        # Causal depth — root_cause ≥30 chars and not a restatement.
        rc = (draft.root_cause or "").strip()
        if len(rc) < 30:
            failed.append("causal_depth")
            reasons.append(
                "root_cause is too short (<30 chars). Explain WHY the problem "
                "occurred, not just what happened."
            )
        elif draft.problem and rc.lower() == draft.problem.strip().lower():
            failed.append("causal_depth")
            reasons.append(
                "root_cause just restates the problem. Explain the causal "
                "mechanism."
            )

        # Boundary precision.
        if not draft.does_not_apply_when:
            failed.append("boundary_precision")
            reasons.append(
                "does_not_apply_when is empty. State at least one condition "
                "where the solution does NOT apply — if you can't name one, "
                "you don't yet understand the boundary."
            )

        # Evidence honesty.
        if draft.evidence_class is None:
            failed.append("evidence")
            reasons.append(
                "evidence_class is unset. Tag honestly: production_validated "
                "/ integration_tested / local_tested / self_reported / "
                "speculative."
            )
        elif not draft.has_been_verified and draft.evidence_class in (
            "production_validated",
            "integration_tested",
            "local_tested",
        ):
            failed.append("evidence")
            reasons.append(
                f"evidence_class='{draft.evidence_class}' claims verification "
                "but has_been_verified=False. Downgrade to 'self_reported' "
                "or 'speculative'."
            )

        # Soft nudges — don't block, but prompt the caller to improve.
        if not draft.failed_approaches:
            reasons.append(
                "(soft) No failed_approaches listed — failed attempts are "
                "often the most valuable part of a deposit."
            )
        if not (draft.insight or "").strip():
            reasons.append(
                "(soft) insight is empty — add the transferable lesson so "
                "other agents can apply it elsewhere."
            )

        failed_unique = list(dict.fromkeys(failed))
        hard_dimensions = 4
        failed_count = len(failed_unique)
        score = max(0.0, (hard_dimensions - failed_count) / hard_dimensions)
        should_deposit = failed_count == 0
        if should_deposit:
            reasons.insert(
                0,
                "All four local dimensions (causal depth, boundary precision, "
                "evidence, non-triviality) pass. Still search Inferior before "
                "depositing to confirm novelty.",
            )

        # v1.2+: compute the full 5-dimension preview using shared math.
        from inferior._worthiness import preview_worthiness

        preview = preview_worthiness(draft, signals_fired)

        # Surface preview reasons after the hard-gate reasons.
        reasons.append(
            f"--- Server worthiness preview "
            f"(estimated score: {preview['estimated_server_score']:.2f}, "
            f"base: {preview['base_score']:.2f}) ---"
        )
        for dim, score_v in preview["dimension_scores"].items():
            conf = preview["dimension_confidence"][dim]
            reasons.append(
                f"  {dim}: {score_v:.2f} ({conf}) — "
                f"{preview['dimension_reasons'][dim]}"
            )
        for br in preview["boost_reasons"]:
            reasons.append(f"  boost: {br}")

        return WorthResult(
            should_deposit=should_deposit,
            score=score,
            reasons=reasons,
            failed_dimensions=failed_unique,
            dimension_scores=preview["dimension_scores"],
            dimension_confidence=preview["dimension_confidence"],
            estimated_server_score=preview["estimated_server_score"],
            would_likely_accept=preview["would_likely_accept"],
        )

    @staticmethod
    def is_query_safe(
        query: str, policy: QueryPolicy | None = None
    ) -> QuerySafetyResult:
        """Local privacy gate: classify a query as safe to send.

        Pure function. Classifies, does not redact — the caller decides
        whether to abort, rewrite, or proceed.
        """
        import re

        p = policy or QueryPolicy()
        reasons: list[str] = []

        if len(query) > p.max_length:
            reasons.append(
                f"Query length ({len(query)}) exceeds max_length "
                f"({p.max_length}). Shorten to avoid accidentally dumping "
                "file contents."
            )

        if p.block_secrets:
            secret_patterns = [
                r"(?i)(aws_access_key|aws_secret|sk_live_|sk_test_|ghp_|github_pat_)",
                r"-----BEGIN (RSA |EC |OPENSSH )?PRIVATE KEY-----",
                r"(?i)(api[_-]?key|bearer|token)[\"'\s:=]+[A-Za-z0-9_\-]{20,}",
            ]
            for pat in secret_patterns:
                if re.search(pat, query):
                    reasons.append(
                        "Query appears to contain a secret (API key, token, "
                        "or private key). Do not send."
                    )
                    break

        if p.block_internal_hosts:
            host_patterns = [
                r"\b[\w-]+\.internal\b",
                r"\b[\w-]+\.corp\b",
                r"\b[\w-]+\.local\b",
                r"\blocalhost:\d+\b",
                r"\b10\.\d{1,3}\.\d{1,3}\.\d{1,3}\b",
                r"\b192\.168\.\d{1,3}\.\d{1,3}\b",
                r"\b172\.(1[6-9]|2\d|3[0-1])\.\d{1,3}\.\d{1,3}\b",
            ]
            for pat in host_patterns:
                if re.search(pat, query):
                    reasons.append(
                        "Query contains an internal hostname or private IP. "
                        "Abstract it before sending."
                    )
                    break

        if p.block_customer_data:
            data_patterns = [
                (
                    r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}",
                    "email address",
                ),
                (r"\b\d{3}-\d{2}-\d{4}\b", "SSN"),
                (
                    r"\b(?:\d[ -]?){13,19}\b",
                    "credit card / long number sequence",
                ),
                (
                    r"\+?1?[-.\s]?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}",
                    "phone number",
                ),
            ]
            for pat, label in data_patterns:
                if re.search(pat, query):
                    reasons.append(
                        f"Query appears to contain a {label}. Abstract it "
                        "before sending."
                    )

        for pat in p.custom_deny_patterns:
            try:
                if re.search(pat, query):
                    reasons.append(
                        f"Query matches custom deny pattern: {pat}"
                    )
            except re.error:
                # Invalid regex — caller's problem; don't crash.
                pass

        return QuerySafetyResult(is_safe=len(reasons) == 0, reasons=reasons)

    # ── Lifecycle ─────────────────────────────────────────────────────────

    def close(self) -> None:
        """Close the underlying HTTP connection pool."""
        self.client.close()

    def __del__(self) -> None:
        """Safety net — close the client if not already closed."""
        try:
            if not self.client.is_closed:
                self.client.close()
        except Exception:
            pass

    def __enter__(self) -> InferiorClient:
        return self

    def __exit__(
        self,
        exc_type: type | None,
        exc_val: BaseException | None,
        exc_tb: object,
    ) -> None:
        self.close()
