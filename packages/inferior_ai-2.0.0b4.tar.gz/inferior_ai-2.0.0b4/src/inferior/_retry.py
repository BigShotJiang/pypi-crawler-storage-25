"""Retry-with-backoff transport for httpx.

The default retry policy retries idempotent requests on transient
errors (429, 502, 503, 504) with exponential backoff and jitter. On
429 responses the ``Retry-After`` header is honoured when present
(seconds form only — RFC HTTP-date form is not yet supported).

Design note: we do this at the transport layer rather than per-call
so the existing client code (`self.client.get(...)`, `self.client.post(...)`)
doesn't need to change. Disabling retries entirely is a one-liner via
the client constructor (`InferiorClient(retry=False)`); fine-tuning is
via `Retry(...)` config.
"""

from __future__ import annotations

import random
import time
from dataclasses import dataclass

import httpx


# Status codes that trigger a retry. We deliberately do NOT retry on
# 4xx other than 429 — those represent caller errors (bad payload,
# auth, validation) where a retry won't help.
_RETRY_STATUSES = frozenset({429, 502, 503, 504})

# Methods that are safe to retry without an idempotency key. POST
# retries are gated on the caller providing an Idempotency-Key header
# (see `InferiorClient.deposit(idempotency_key=...)`); without one we
# only retry GET / HEAD / OPTIONS.
_IDEMPOTENT_METHODS = frozenset({"GET", "HEAD", "OPTIONS"})


@dataclass(frozen=True)
class Retry:
    """Retry policy.

    Attributes:
        max_attempts:    Total attempts including the first request. Default 3.
        base_delay:      Initial backoff in seconds. Default 0.5.
        jitter:          Random fraction added to each backoff (0..1). Default 0.2.
        max_delay:       Cap on per-attempt sleep. Default 30.0 seconds.
        retry_writes:    If True, retry POST/PUT/DELETE even without an
                         Idempotency-Key header. Default False — turning
                         this on can silently double-create resources on
                         a backend that does not dedupe.
    """

    max_attempts: int = 3
    base_delay: float = 0.5
    jitter: float = 0.2
    max_delay: float = 30.0
    retry_writes: bool = False


def _backoff(attempt: int, base: float, jitter: float, cap: float) -> float:
    """Exponential backoff with multiplicative jitter."""
    delay = min(base * (2 ** (attempt - 1)), cap)
    if jitter > 0:
        delay *= 1.0 + random.uniform(0.0, jitter)
    return delay


def _retry_after(resp: httpx.Response) -> float | None:
    """Parse Retry-After header. Returns seconds or None."""
    raw = resp.headers.get("retry-after")
    if not raw:
        return None
    try:
        return float(raw)
    except ValueError:
        # HTTP-date form not yet supported.
        return None


class RetryTransport(httpx.BaseTransport):
    """Sync transport that retries transient errors.

    Wraps another transport (typically the default ``httpx.HTTPTransport``)
    and re-issues the request on retryable status codes or connection
    errors.
    """

    def __init__(self, inner: httpx.BaseTransport, retry: Retry) -> None:
        self.inner = inner
        self.retry = retry

    def handle_request(self, request: httpx.Request) -> httpx.Response:
        method = request.method.upper()
        is_idempotent = (
            method in _IDEMPOTENT_METHODS
            or self.retry.retry_writes
            or "idempotency-key" in {k.lower() for k in request.headers}
        )

        last_exc: Exception | None = None
        for attempt in range(1, self.retry.max_attempts + 1):
            try:
                resp = self.inner.handle_request(request)
            except (httpx.ConnectError, httpx.ReadError, httpx.WriteError, httpx.RemoteProtocolError) as e:
                last_exc = e
                if attempt >= self.retry.max_attempts or not is_idempotent:
                    raise
                time.sleep(_backoff(attempt, self.retry.base_delay, self.retry.jitter, self.retry.max_delay))
                continue

            if resp.status_code not in _RETRY_STATUSES:
                return resp
            if attempt >= self.retry.max_attempts or not is_idempotent:
                return resp

            # Honour Retry-After when present (seconds form only).
            retry_after = _retry_after(resp)
            sleep_for = retry_after if retry_after is not None else _backoff(
                attempt, self.retry.base_delay, self.retry.jitter, self.retry.max_delay
            )
            # Read+close the response body so the connection can be reused.
            resp.read()
            resp.close()
            time.sleep(sleep_for)

        # Exhausted retries on a transient error path.
        if last_exc is not None:
            raise last_exc
        return resp  # type: ignore[unreachable]


class AsyncRetryTransport(httpx.AsyncBaseTransport):
    """Async transport that retries transient errors. Mirrors
    ``RetryTransport`` for ``httpx.AsyncClient``."""

    def __init__(self, inner: httpx.AsyncBaseTransport, retry: Retry) -> None:
        self.inner = inner
        self.retry = retry

    async def handle_async_request(self, request: httpx.Request) -> httpx.Response:  # noqa: D401
        import asyncio

        method = request.method.upper()
        is_idempotent = (
            method in _IDEMPOTENT_METHODS
            or self.retry.retry_writes
            or "idempotency-key" in {k.lower() for k in request.headers}
        )

        last_exc: Exception | None = None
        for attempt in range(1, self.retry.max_attempts + 1):
            try:
                resp = await self.inner.handle_async_request(request)
            except (httpx.ConnectError, httpx.ReadError, httpx.WriteError, httpx.RemoteProtocolError) as e:
                last_exc = e
                if attempt >= self.retry.max_attempts or not is_idempotent:
                    raise
                await asyncio.sleep(
                    _backoff(attempt, self.retry.base_delay, self.retry.jitter, self.retry.max_delay)
                )
                continue

            if resp.status_code not in _RETRY_STATUSES:
                return resp
            if attempt >= self.retry.max_attempts or not is_idempotent:
                return resp

            retry_after = _retry_after(resp)
            sleep_for = retry_after if retry_after is not None else _backoff(
                attempt, self.retry.base_delay, self.retry.jitter, self.retry.max_delay
            )
            await resp.aread()
            await resp.aclose()
            await asyncio.sleep(sleep_for)

        if last_exc is not None:
            raise last_exc
        return resp  # type: ignore[unreachable]
