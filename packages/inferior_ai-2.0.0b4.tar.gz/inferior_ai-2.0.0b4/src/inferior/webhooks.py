"""Webhook signature verification helper.

Backend signs every webhook delivery with HMAC-SHA256 over the raw
body and sends the signature as ``X-Inferior-Signature: sha256=<hex>``.
This module exposes ``verify()`` for subscribers.

Usage::

    from inferior import webhooks

    @app.post("/inferior-webhook")
    async def receive(req):
        body = await req.body()  # raw bytes — not the parsed JSON
        sig = req.headers["X-Inferior-Signature"]
        try:
            event = webhooks.verify(body, sig, secret="whsec_...")
        except webhooks.InvalidSignatureError:
            return Response(status_code=400)
        # event is the parsed JSON event payload.
        ...

The helper checks both signature equality (via constant-time compare)
and event freshness (default 5-minute tolerance) — the latter
prevents replay attacks if a delivery is captured and re-sent.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import time
from typing import Any


__all__ = ["verify", "InvalidSignatureError"]


class InvalidSignatureError(Exception):
    """Raised when a webhook signature fails validation.

    Distinct from ``InferiorError`` because it's verified locally and
    doesn't carry HTTP status / request_id; subscribers usually want to
    return 400 to the backend on this error.
    """


def verify(
    body: str | bytes,
    signature_header: str,
    secret: str,
    tolerance: int = 300,
    *,
    delivery_timestamp: int | None = None,
) -> dict[str, Any]:
    """Verify a webhook signature and return the parsed event.

    Args:
        body:               Raw request body (bytes preferred; str is
                            UTF-8 encoded).
        signature_header:   Value of the ``X-Inferior-Signature`` header,
                            in the form ``sha256=<hex>``.
        secret:             Webhook signing secret (from the admin UI).
        tolerance:          Max age in seconds. If the parsed event has a
                            ``ts`` (or ``timestamp``) field older than
                            ``tolerance`` seconds, raises
                            ``InvalidSignatureError``. Default 300 (5min).
                            Pass 0 to disable freshness check.
        delivery_timestamp: Override "now" for testing (unix seconds).

    Returns:
        The parsed JSON event payload.

    Raises:
        InvalidSignatureError: Signature mismatch, malformed header, or
                               event older than ``tolerance`` seconds.
    """
    if not signature_header:
        raise InvalidSignatureError("missing signature header")

    if "=" not in signature_header:
        raise InvalidSignatureError("malformed signature header (expected 'sha256=<hex>')")

    scheme, _, sig_hex = signature_header.partition("=")
    if scheme != "sha256":
        raise InvalidSignatureError(f"unsupported signature scheme: {scheme!r}")

    raw_body = body.encode("utf-8") if isinstance(body, str) else body
    expected = hmac.new(secret.encode("utf-8"), raw_body, hashlib.sha256).hexdigest()
    if not hmac.compare_digest(expected, sig_hex):
        raise InvalidSignatureError("signature mismatch")

    try:
        event: dict[str, Any] = json.loads(raw_body.decode("utf-8"))
    except (json.JSONDecodeError, UnicodeDecodeError) as e:
        raise InvalidSignatureError(f"event body is not valid JSON: {e}") from e

    if tolerance > 0:
        # Backend webhook payload schema is { "id": ..., "type": ..., "ts": <unix>, "data": {...} }
        ts = event.get("ts") or event.get("timestamp")
        if ts is not None:
            try:
                event_time = int(ts)
            except (TypeError, ValueError) as e:
                raise InvalidSignatureError(f"event timestamp not parseable: {ts!r}") from e
            now = delivery_timestamp if delivery_timestamp is not None else int(time.time())
            if abs(now - event_time) > tolerance:
                raise InvalidSignatureError(
                    f"event timestamp outside tolerance ({abs(now - event_time)}s > {tolerance}s)"
                )

    return event
