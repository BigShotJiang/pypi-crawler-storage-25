"""Internal constants shared across the SDK.

Public surface re-exports the meaningful ones from `inferior` package root:
``INFERIOR_API_VERSION``, ``USER_AGENT``.
"""

from __future__ import annotations

import platform
import sys

# ── Package version ─────────────────────────────────────────────────
# Single source of truth — keep aligned with pyproject.toml [project] version.
__version__ = "2.0.0b4"

# ── API version pinning ─────────────────────────────────────────────
# Sent on every request as the `Inferior-Version` header. The backend
# echoes the resolved version as `X-Inferior-Resolved-Version` so the
# SDK can warn on mismatch (Phase C2 — depends on backend B2).
INFERIOR_API_VERSION = "2026-04-28"

# ── User-Agent ──────────────────────────────────────────────────────
# Surfaced in backend logs so we can see which SDK versions and Python
# runtimes our users run. Format mirrors common practice (Stripe SDK,
# Anthropic SDK).
USER_AGENT = (
    f"inferior-sdk-python/{__version__}"
    f" python/{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
    f" {platform.system().lower()}"
)

# ── Default request headers ─────────────────────────────────────────
# Applied to every httpx.Client / httpx.AsyncClient created by the SDK.
DEFAULT_HEADERS: dict[str, str] = {
    "User-Agent": USER_AGENT,
    "Inferior-Version": INFERIOR_API_VERSION,
}

# ── Response headers we read ────────────────────────────────────────
# Backend emits `X-Request-ID` per request (api/main.py:224-232). We
# surface it on every raised exception so support tickets are traceable.
HEADER_REQUEST_ID = "x-request-id"

# Backend echoes the resolved API version as
# `X-Inferior-Resolved-Version` (B2 of launch plan, shipped 2026-04-28).
# The SDK warns once per process on mismatch — see `client.py`.
HEADER_RESOLVED_VERSION = "x-inferior-resolved-version"
