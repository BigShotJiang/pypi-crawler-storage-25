"""
Typed exceptions for Inferior API errors.

All exceptions inherit from ``InferiorError`` and are raised instead of raw
``httpx.HTTPStatusError``. Each exception exposes the parsed error body so
callers don't need to parse JSON manually.
"""

from __future__ import annotations


class InferiorError(Exception):
    """Base exception for all Inferior API errors.

    Every API error carries a ``request_id`` (when the backend supplied
    one) so support tickets can be matched to the exact request in our
    logs. The id is also included in ``str(exc)`` for ergonomic logging.
    """

    def __init__(
        self,
        message: str,
        status_code: int = 0,
        error_type: str = "",
        details: dict | None = None,
        request_id: str | None = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.error_type = error_type
        self.details = details or {}
        self.request_id = request_id

    def __str__(self) -> str:
        base = super().__str__()
        if self.request_id:
            return f"{base} (request_id={self.request_id})"
        return base


class AuthenticationError(InferiorError):
    """401 — Invalid, missing, or revoked API key."""


class InsufficientScopeError(InferiorError):
    """403 — API key lacks required scope for the endpoint.

    Attributes:
        required_scope: The scope the endpoint requires.
        actual_scope:   The scope your key has.
    """

    def __init__(
        self, message: str, required_scope: str = "", actual_scope: str = "", **kwargs: object
    ) -> None:
        super().__init__(message, **kwargs)  # type: ignore[arg-type]
        self.required_scope = required_scope
        self.actual_scope = actual_scope


class ForbiddenError(InferiorError):
    """403 — Permission denied (trust level, self-rating, etc.)."""


class NotFoundError(InferiorError):
    """404 — Resource not found."""


class DuplicateError(InferiorError):
    """409 — Exact duplicate or duplicate feedback.

    Attributes:
        existing_id: ID of the existing resource that conflicts.
    """

    def __init__(self, message: str, existing_id: str = "", **kwargs: object) -> None:
        super().__init__(message, **kwargs)  # type: ignore[arg-type]
        self.existing_id = existing_id


class ValidationError(InferiorError):
    """422 — PII detected, quality below threshold, or invalid input.

    Attributes:
        validation_type: Specific error (PIIDetectedError, QualityBelowThresholdError,
                         PoisoningDetectedError, etc.).
    """

    def __init__(self, message: str, validation_type: str = "", **kwargs: object) -> None:
        super().__init__(message, **kwargs)  # type: ignore[arg-type]
        self.validation_type = validation_type


class PoisoningDetectedError(ValidationError):
    """422 — Experience poisoning scanner flagged the deposit as adversarial.

    Raised when the backend's poisoning scanner (Phase C) detects patterns
    like ``curl|sh``, ``/dev/tcp`` redirects, ``pip install`` from
    non-registry URLs, or other adversarial implementation code. The deposit
    is rejected outright; fix the flagged snippet and re-deposit.

    Callers distinguish this from a generic ``ValidationError`` via the
    ``validation_type`` attribute (``"poisoning"``) or by catching this class.
    """


class RateLimitError(InferiorError):
    """429 — Too many requests.

    Attributes:
        retry_after_seconds: Seconds to wait before retrying.
        scope:               Which rate limit scope was exceeded.
    """

    def __init__(
        self, message: str, retry_after_seconds: int = 0, scope: str = "", **kwargs: object
    ) -> None:
        super().__init__(message, **kwargs)  # type: ignore[arg-type]
        self.retry_after_seconds = retry_after_seconds
        self.scope = scope


class ServerError(InferiorError):
    """5xx — Server-side error (embedding service, internal error, etc.)."""


class BackendSchemaMismatchWarning(UserWarning):
    """Warning emitted when a response carries a schema_version whose major
    component differs from the SDK's ``SCHEMA_VERSION``.

    The SDK continues to parse the response on a best-effort basis — new
    fields are preserved in ``_raw`` dicts — but callers should plan to
    upgrade the SDK to match the backend.
    """


class APIVersionMismatchWarning(UserWarning):
    """Warning emitted when the backend's resolved API version differs
    from the SDK's compiled-in ``INFERIOR_API_VERSION``.

    Distinct from ``BackendSchemaMismatchWarning`` — that one tracks
    response-shape compatibility (``schema_version`` field on
    responses); this one tracks the request-side API contract version
    (``Inferior-Version`` request header / ``X-Inferior-Resolved-Version``
    response header).

    Emitted at most once per ``InferiorClient`` instance.
    """
