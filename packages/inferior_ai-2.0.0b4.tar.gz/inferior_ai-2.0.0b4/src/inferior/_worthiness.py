"""
Shared worthiness scoring math (v1.2+).

Pure functions implementing the 5-dimension scoring model from the
worthiness framework. Used by ``InferiorClient.deposit_worthiness`` to
produce a local preview of what the server's worthiness gate will score.

The backend has a parallel implementation that must stay in parity with
this module (enforced by ``tests/test_worthiness.py::TestSDKParity`` in
the backend repo).

Weights are exposed as ``DEFAULT_WEIGHTS`` so the backend can override
via env-var configuration. The client uses the defaults as a preview
estimate — the actual score is authoritative only on the server.
"""

from __future__ import annotations

from inferior.models import DepositDraft, Signal

# Framework-proposed weights. Both client preview and server gate must
# use the SAME weights for the preview-estimate to match reality.
DEFAULT_WEIGHTS: dict[str, float] = {
    "novelty": 0.30,
    "transferability": 0.25,
    "consequence": 0.20,
    "evidence": 0.15,
    "recurrence": 0.10,
}

# Mapping of ``evidence_class`` → base evidence dimension score.
_EVIDENCE_RANK: dict[str, float] = {
    "production_validated": 1.0,
    "integration_tested": 0.8,
    "local_tested": 0.6,
    "self_reported": 0.4,
    "speculative": 0.2,
}

# Severity mapping for the consequence dimension — higher-severity signals
# indicate the resolution was more consequential to capture.
_SIGNAL_SEVERITY: dict[str, float] = {
    "error_recovery": 0.9,
    "output_rejection_recovery": 0.9,
    "high_retry": 0.8,
    "plan_deviation": 0.7,
    "human_correction": 0.6,
    "search_miss": 0.5,
}


def score_novelty(draft: DepositDraft) -> tuple[float, str, str]:
    """Novelty dimension. Client-side this relies on the agent's self-report.

    Returns ``(score, confidence, reason)``. ``confidence`` is one of
    ``definitive`` / ``estimated`` / ``unknown``.
    """
    report = draft.novelty_self_report or "unknown"
    if report == "searched_and_none_found":
        return 0.8, "estimated", "Client novelty estimate: searched and found nothing."
    if report == "searched_and_similar_found":
        return 0.2, "estimated", (
            "Client novelty estimate: searched and found similar — reconsider "
            "whether a new deposit is worthwhile."
        )
    if report == "did_not_search":
        return 0.5, "estimated", (
            "You have not searched Inferior — do that before depositing so "
            "the server can verify novelty."
        )
    # "unknown" or anything else: neutral estimate; server will decide.
    return 0.5, "unknown", "Novelty unknown without a search — server will verify."


def score_transferability(draft: DepositDraft) -> tuple[float, str, str]:
    """Transferability dimension. Structural heuristic.

    Scored from ``applies_when`` + ``does_not_apply_when`` specificity:
    count of entries + average length. A draft with no
    ``does_not_apply_when`` scores poorly — the framework strongly
    weights boundary precision.
    """
    aw = draft.applies_when or []
    dw = draft.does_not_apply_when or []
    total = len(aw) + len(dw)
    if total == 0:
        return 0.1, "definitive", (
            "No applies_when or does_not_apply_when — this deposit looks "
            "context-free, which the server will heavily penalise."
        )
    if len(dw) == 0:
        return 0.3, "definitive", (
            "does_not_apply_when is empty — without a stated boundary the "
            "experience doesn't transfer well."
        )
    avg_len = sum(len(s) for s in aw + dw) / max(1, total)
    # Heuristic: 1 entry × 30 chars ≈ 0.45, 2 × 50 ≈ 0.85.
    score = min(1.0, total * 0.2 + avg_len / 100.0 * 0.4)
    reason = (
        f"Transferability looks reasonable "
        f"(applies_when={len(aw)}, does_not_apply_when={len(dw)}, "
        f"avg length={avg_len:.0f})."
    )
    return score, "definitive", reason


def score_consequence(
    signals_fired: list[Signal] | None,
) -> tuple[float, str, str]:
    """Consequence dimension. Derived from signals passed by the caller.

    If no signals provided, treated as neutral (0.5, unknown) — the
    server may infer signals from session data we don't have locally.
    """
    if not signals_fired:
        return 0.5, "unknown", (
            "No signals provided — server may infer consequence from "
            "session metadata."
        )
    # Max severity of fired signals, nudged by count.
    max_severity = max(
        _SIGNAL_SEVERITY.get(s.type, 0.4) for s in signals_fired
    )
    count_bonus = min(0.15, 0.05 * len(signals_fired))
    score = min(1.0, max_severity + count_bonus - 0.1)
    signal_names = ", ".join(s.type for s in signals_fired)
    return score, "estimated", (
        f"Consequence derived from {len(signals_fired)} signal(s): "
        f"{signal_names}."
    )


def score_evidence(draft: DepositDraft) -> tuple[float, str, str]:
    """Evidence dimension. Combines evidence_class with verification honesty."""
    ec = draft.evidence_class
    if ec is None:
        return 0.2, "definitive", "evidence_class is unset — tag honestly."
    base = _EVIDENCE_RANK.get(ec, 0.3)
    if not draft.has_been_verified and ec in (
        "production_validated",
        "integration_tested",
        "local_tested",
    ):
        return 0.3, "definitive", (
            f"evidence_class='{ec}' claims verification but "
            "has_been_verified=False — server will penalise inflation. "
            "Downgrade to 'self_reported' or 'speculative'."
        )
    return base, "definitive", f"evidence_class='{ec}' → {base:.2f}."


def score_recurrence(draft: DepositDraft) -> tuple[float, str, str]:
    """Recurrence dimension. Needs the corpus to score fully; relies on self-report."""
    estimate = draft.recurrence_self_report
    if estimate is None:
        return 0.5, "unknown", (
            "Recurrence unknown without a corpus lookup — server will "
            "compute from agent_search_log."
        )
    # 0 → 0.2, 10 → 0.8, capped.
    score = min(1.0, 0.2 + estimate * 0.06)
    return score, "estimated", (
        f"Recurrence estimate: ~{estimate} peers would hit this → {score:.2f}."
    )


def apply_signal_boosts(
    base_score: float,
    signals_fired: list[Signal] | None,
    draft: DepositDraft,
) -> tuple[float, list[str]]:
    """Apply framework boosts additively, capped at 1.0. Returns (score, reasons)."""
    reasons: list[str] = []
    score = base_score
    signals = signals_fired or []
    signal_types = {s.type for s in signals}

    if "search_miss" in signal_types:
        score += 0.15
        reasons.append("+0.15 (search miss — filling a known gap)")
    if "human_correction" in signal_types:
        score += 0.10
        reasons.append("+0.10 (human correction — captured user knowledge)")
    if len(signals) >= 3:
        score += 0.10
        reasons.append(f"+0.10 (≥3 signals fired: {len(signals)})")
    if len(draft.failed_approaches or []) >= 2:
        score += 0.05
        reasons.append("+0.05 (≥2 failed approaches documented)")

    return min(1.0, score), reasons


def compose_worthiness(
    dimension_scores: dict[str, float],
    weights: dict[str, float] | None = None,
) -> float:
    """Weighted composite of dimension scores. Missing dimensions default to 0.5."""
    w = weights or DEFAULT_WEIGHTS
    return round(
        sum(dimension_scores.get(d, 0.5) * w.get(d, 0.0) for d in w),
        4,
    )


def preview_worthiness(
    draft: DepositDraft,
    signals_fired: list[Signal] | None = None,
    weights: dict[str, float] | None = None,
) -> dict:
    """Full 5-dimension worthiness preview.

    Returns a dict with keys:
      - ``dimension_scores``: per-dimension 0–1.
      - ``dimension_confidence``: per-dimension string label.
      - ``dimension_reasons``: per-dimension human-readable reason.
      - ``base_score``: composite before signal boosts.
      - ``estimated_server_score``: composite after boosts, capped at 1.0.
      - ``boost_reasons``: list of strings describing applied boosts.
      - ``would_likely_accept``: heuristic flag.
    """
    novelty = score_novelty(draft)
    transferability = score_transferability(draft)
    consequence = score_consequence(signals_fired)
    evidence = score_evidence(draft)
    recurrence = score_recurrence(draft)

    dimension_scores = {
        "novelty": novelty[0],
        "transferability": transferability[0],
        "consequence": consequence[0],
        "evidence": evidence[0],
        "recurrence": recurrence[0],
    }
    dimension_confidence = {
        "novelty": novelty[1],
        "transferability": transferability[1],
        "consequence": consequence[1],
        "evidence": evidence[1],
        "recurrence": recurrence[1],
    }
    dimension_reasons = {
        "novelty": novelty[2],
        "transferability": transferability[2],
        "consequence": consequence[2],
        "evidence": evidence[2],
        "recurrence": recurrence[2],
    }

    base = compose_worthiness(dimension_scores, weights)
    boosted, boost_reasons = apply_signal_boosts(base, signals_fired, draft)

    would_likely_accept = (
        boosted >= 0.35
        and draft.novelty_self_report != "searched_and_similar_found"
    )

    return {
        "dimension_scores": dimension_scores,
        "dimension_confidence": dimension_confidence,
        "dimension_reasons": dimension_reasons,
        "base_score": base,
        "estimated_server_score": boosted,
        "boost_reasons": boost_reasons,
        "would_likely_accept": would_likely_accept,
    }
