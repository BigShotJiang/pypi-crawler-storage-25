"""Optional pytest plugin — auto-registers an ``inferior_mock`` fixture.

Activate by adding to your ``conftest.py``::

    pytest_plugins = ["inferior.testing.pytest_plugin"]

Then use the fixture in any test::

    def test_my_thing(inferior_mock):
        inferior_mock.mock_search(results=[])
        # call the code under test that takes a client
        my_function(inferior_mock)
        assert len(inferior_mock.calls) == 1

The plugin is a soft dependency on pytest — importing
``inferior.testing`` does NOT import pytest. Only this module does, and
only when pytest itself is loading plugins.
"""
from __future__ import annotations

from typing import Iterator

import pytest

from inferior.testing._client import MockInferiorClient


@pytest.fixture
def inferior_mock() -> Iterator[MockInferiorClient]:
    """A ``MockInferiorClient`` scoped to one test.

    Yielding instead of returning so we can call ``client.close()``
    on teardown — keeps the underlying httpx.Client connection pool
    tidy even though there's no real network.
    """
    client = MockInferiorClient()
    try:
        yield client
    finally:
        client.close()
