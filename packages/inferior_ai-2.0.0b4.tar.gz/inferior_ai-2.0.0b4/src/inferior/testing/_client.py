"""``MockInferiorClient`` — InferiorClient subclass backed by an
``httpx.MockTransport`` for tests.

Design notes:
- Subclasses the real ``InferiorClient`` so type-checking customers
  who annotate against ``InferiorClient`` keep working.
- Uses ``httpx.MockTransport`` so we don't reimplement the HTTP layer;
  the real ``_raise_for_status`` and request/response lifecycle still
  fires.
- Stubs are FIFO: each registered response is consumed by the next
  matching call. Re-register if you need the same endpoint to fire
  multiple times.
- ``calls`` records every request made, so tests can assert on the
  shape of what their code under test actually sent.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Callable

import httpx

from inferior._constants import DEFAULT_HEADERS, INFERIOR_API_VERSION
from inferior.client import InferiorClient


@dataclass
class RecordedCall:
    """A single intercepted request — what the code under test sent."""

    method: str
    url: httpx.URL
    headers: dict[str, str]
    body: bytes
    body_json: Any = None

    def header(self, name: str, default: str | None = None) -> str | None:
        """Convenience: case-insensitive header lookup with optional default."""
        return self.headers.get(name.lower(), default)


@dataclass
class _Stub:
    """One queued mock response."""

    matcher: Callable[[httpx.Request], bool]
    response: httpx.Response
    description: str = ""


class MockInferiorClient(InferiorClient):
    """An ``InferiorClient`` that intercepts every HTTP request.

    Construct with no arguments for a default test client; pass
    ``api_key=`` and ``base_url=`` if your code under test reads them.

    Stubs are FIFO. Default response when no stub matches is a 404
    with a descriptive body — surfaces unexpected calls fast.
    """

    def __init__(
        self,
        api_key: str = "cw_full_test_mock_key",
        base_url: str = "https://api.inferior.ai",
    ) -> None:
        # Initialize parent so all helper methods (parse_*, etc.) work,
        # but we'll immediately replace the underlying httpx.Client.
        super().__init__(api_key=api_key, base_url=base_url, retry=False)

        self._stubs: list[_Stub] = []
        self.calls: list[RecordedCall] = []

        # Replace the live httpx.Client with one whose transport is a
        # MockTransport. Headers + base_url + auth all carry over.
        headers = {**DEFAULT_HEADERS, "Authorization": f"Bearer {api_key}"}
        self.client = httpx.Client(
            base_url=base_url.rstrip("/"),
            headers=headers,
            timeout=15.0,
            transport=httpx.MockTransport(self._dispatch),
            event_hooks={"response": [self._inspect_response]},
        )

    # ── Recording ────────────────────────────────────────────────────

    def _dispatch(self, request: httpx.Request) -> httpx.Response:
        """MockTransport handler — record the call, find a matching stub."""
        body = request.read()
        try:
            body_json = json.loads(body) if body else None
        except (ValueError, TypeError):
            body_json = None
        self.calls.append(
            RecordedCall(
                method=request.method.upper(),
                url=request.url,
                headers={k.lower(): v for k, v in request.headers.items()},
                body=body,
                body_json=body_json,
            )
        )

        for i, stub in enumerate(self._stubs):
            if stub.matcher(request):
                self._stubs.pop(i)
                return stub.response

        return self._unmatched_response(request)

    def _unmatched_response(self, request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            status_code=404,
            headers={"X-Request-ID": "req_mock_unmatched"},
            content=json.dumps(
                {
                    "error": "MockInferiorClientUnmatchedRequest",
                    "message": (
                        f"No stub matched {request.method} {request.url.path}. "
                        f"Use add_response() / mock_search() / mock_deposit() / "
                        f"mock_feedback() to register a response."
                    ),
                    "details": {
                        "method": request.method,
                        "path": request.url.path,
                    },
                }
            ).encode("utf-8"),
        )

    # ── Stub registration — generic ──────────────────────────────────

    def add_response(
        self,
        method: str,
        path_substring: str,
        *,
        status: int = 200,
        json_body: Any = None,
        text_body: str | None = None,
        headers: dict[str, str] | None = None,
        description: str = "",
    ) -> "MockInferiorClient":
        """Queue a single response for the next matching request.

        Returns ``self`` for chaining.

        Args:
            method:           HTTP method (case-insensitive).
            path_substring:   Match against ``request.url.path``. Substring
                              match keeps tests robust to query strings.
            status:           HTTP status to return.
            json_body:        JSON-serialisable response body.
            text_body:        Plaintext body (mutually exclusive with json_body).
            headers:          Additional response headers. ``X-Request-ID`` is
                              auto-injected if absent — tests almost always
                              want it for error-surface assertions.
            description:      Optional label, surfaced in __repr__ / debug.
        """
        method = method.upper()
        path = path_substring

        def matcher(req: httpx.Request) -> bool:
            return req.method.upper() == method and path in req.url.path

        resp_headers = {"X-Request-ID": "req_mock_test"}
        if headers:
            resp_headers.update(headers)

        if json_body is not None:
            response = httpx.Response(
                status_code=status,
                headers=resp_headers,
                content=json.dumps(json_body).encode("utf-8"),
            )
            response.headers.setdefault("content-type", "application/json")
        elif text_body is not None:
            response = httpx.Response(
                status_code=status,
                headers=resp_headers,
                content=text_body.encode("utf-8"),
            )
        else:
            response = httpx.Response(status_code=status, headers=resp_headers)

        self._stubs.append(_Stub(matcher=matcher, response=response, description=description))
        return self

    # ── Stub registration — convenience helpers ──────────────────────

    def mock_search(
        self,
        *,
        results: list[dict] | None = None,
        total: int | None = None,
        cached: bool = False,
    ) -> "MockInferiorClient":
        """Stub the next ``search()`` call with the given results."""
        results = results or []
        return self.add_response(
            "GET",
            "/v1/experiences/search",
            json_body={
                "results": results,
                "total_results": total if total is not None else len(results),
                "metadata": {"cached": cached, "channels_used": ["semantic"]},
                "schema_version": "2.0.0",
            },
            description=f"search({len(results)} results)",
        )

    def mock_deposit(
        self,
        *,
        id: str = "exp_test_mock",
        status: str = "accepted",
        quality_score: float = 0.75,
        validation_state: str = "verified",
    ) -> "MockInferiorClient":
        """Stub the next ``deposit()`` call."""
        return self.add_response(
            "POST",
            "/v1/experiences",
            status=201,
            json_body={
                "id": id,
                "status": status,
                "quality_score": quality_score,
                "trust_visibility": "searchable",
                "validation_state": validation_state,
                "schema_version": "2.0.0",
            },
            description=f"deposit({id})",
        )

    def mock_deposit_raw(self, *, raw_deposit_id: str = "raw_test_mock") -> "MockInferiorClient":
        """Stub the next ``deposit_raw()`` call."""
        return self.add_response(
            "POST",
            "/v1/experiences/raw",
            status=202,
            json_body={
                "raw_deposit_id": raw_deposit_id,
                "status": "accepted",
                "normalization_status": "queued",
            },
            description=f"deposit_raw({raw_deposit_id})",
        )

    def mock_feedback(
        self,
        *,
        feedback_id: str = "fbk_test_mock",
        experience_id: str = "exp_test_mock",
    ) -> "MockInferiorClient":
        """Stub the next ``feedback()`` call."""
        return self.add_response(
            "POST",
            "/feedback",
            status=201,
            json_body={
                "feedback_id": feedback_id,
                "experience_id": experience_id,
                "updated_scores": {"lower": 0.5, "center": 0.7, "upper": 0.9, "n": 1},
                "validity_update": {},
            },
            description=f"feedback({feedback_id})",
        )

    def mock_error(
        self,
        method: str,
        path_substring: str,
        *,
        status: int,
        error: str = "ServerError",
        message: str = "Mocked error",
        details: dict | None = None,
    ) -> "MockInferiorClient":
        """Stub the next matching call with an error response.

        The SDK's ``_raise_for_status`` will raise the corresponding
        typed exception (``ServerError``, ``RateLimitError``, etc.)
        with ``request_id`` populated from the mock's ``X-Request-ID``.
        """
        return self.add_response(
            method,
            path_substring,
            status=status,
            json_body={"error": error, "message": message, "details": details or {}},
            description=f"error({status} {error})",
        )

    # ── Inspection ───────────────────────────────────────────────────

    def reset(self) -> "MockInferiorClient":
        """Clear all queued stubs and recorded calls."""
        self._stubs.clear()
        self.calls.clear()
        return self

    def assert_no_unmatched(self) -> None:
        """Raise if any registered stub never fired. Useful at test
        teardown to catch over-stubbing."""
        if self._stubs:
            unfired = ", ".join(s.description or repr(s) for s in self._stubs)
            raise AssertionError(f"{len(self._stubs)} unfired stubs: {unfired}")
