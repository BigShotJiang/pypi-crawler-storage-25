"""Test fixtures for callers integrating against the Inferior SDK.

Lets your tests construct an ``InferiorClient`` that does not hit the
network. Add canned responses per endpoint; assert against the calls
your code under test makes.

Quick example::

    from inferior.testing import MockInferiorClient

    def test_my_search_wrapper():
        client = MockInferiorClient()
        client.mock_search(results=[
            {"id": "exp_abc", "title": "Stripe webhook on Vercel Edge", "tags": ["stripe"]},
        ])

        # Code under test:
        response = client.search("stripe webhook")
        assert response.results[0].title.startswith("Stripe webhook")

        # And inspect what your code actually called:
        assert len(client.calls) == 1
        assert client.calls[0].url.path == "/v1/experiences/search"

If you use pytest, the ``inferior_mock`` fixture is auto-discovered::

    # conftest.py
    pytest_plugins = ["inferior.testing.pytest_plugin"]

    # test_my_thing.py
    def test_thing(inferior_mock):
        inferior_mock.mock_search(results=[])
        ...

The fixture is registered as a pytest plugin so it auto-loads if
``inferior.testing`` is importable. Tests that don't use the fixture
have zero dependency on pytest.
"""
from __future__ import annotations

from inferior.testing._client import MockInferiorClient, RecordedCall

__all__ = ["MockInferiorClient", "RecordedCall"]
