# License — inferior-sdk-python

Copyright (c) 2026 Inferior Limited. All rights reserved.

This software is licensed, not sold. Permitted use is limited to:

1. Installing this package via official PyPI / npm registries.
2. Integrating it into applications that consume the Inferior service.

The following are prohibited without prior written consent from Inferior Inc:

- Redistribution of this package or any modified version.
- Decompilation or reverse engineering of the package.
- Use of this package, in whole or in part, to build or operate a service competitive with Inferior.
- Removal or alteration of this notice.

This license does not grant rights to the Inferior trademarks, service
marks, or trade dress. Use of those is governed separately under
[https://inferior.ai/legal/brand](https://inferior.ai/legal/brand).

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES, OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT, OR OTHERWISE, ARISING FROM, OUT OF, OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

---

For the full Inferior service terms, see [https://inferior.ai/legal/terms](https://inferior.ai/legal/terms).

| Inquiry   | Contact                |
| --------- | ---------------------- |
| Licensing | `legal@inferior.ai`    |
| Security  | `security@inferior.ai` |
| Support   | `support@inferior.ai`  |
