"""
This module contains all the classes and functions that are exposed to the user.
"""

from .color import Color
from .point import Point
from .vector import Vector
from .plane import Plane
from .line import Line
from .polyline import Polyline
from .xform import Xform
from .quaternion import Quaternion
from .tree import Tree, TreeNode
from .graph import Graph, Vertex, Edge
from .objects import Objects
from .session import Session
from .mesh import Mesh, NormalWeighting
from .aabb import AABB
from .spatial_aabbtree import SpatialAABBTree
from .obb import OBB
from .pointcloud import PointCloud
from .spatial_bvh import SpatialBVH, SpatialBVHNode
from .spatial_rtree import SpatialRTree
from .tolerance import Tolerance, TOLERANCE
from .session_config import SessionConfig, SESSION_CONFIG
from . import file_encoders
from .file_obj import load_file_obj, save_file_obj
from . import intersection
from .nurbscurve import NurbsCurve
from .nurbssurface import NurbsSurface
from .primitives import Primitives
from .nurbssurface_trimmed import NurbsSurfaceTrimmed
from .brep import BRep
from .element import Element
from .element_column import ElementColumn
from .element_beam import ElementBeam
from .element_plate import ElementPlate
from .closest import Closest
from .remesh_cdt import RemeshCDT
from .remesh_nurbssurface_grid import remesh_nurbssurface_grid, RemeshNurbsSurfaceGrid
from .remesh_nurbssurface_adaptive import RemeshNurbsSurfaceAdaptive
from .matrix import Matrix
from .convex_hull import ConvexHull
from .spatial_kdtree import SpatialKDTree
from .mesh_offset import MeshOffset

__all__ = [
    "Color",
    "Point",
    "Vector",
    "Plane",
    "Line",
    "Polyline",
    "Xform",
    "Quaternion",
    "Tree",
    "TreeNode",
    "Graph",
    "Vertex",
    "Edge",
    "Objects",
    "Session",
    "Mesh",
    "NormalWeighting",
    "OBB",
    "PointCloud",
    "SpatialAABBTree",
    "SpatialBVH",
    "SpatialBVHNode",
    "SpatialRTree",
    "Tolerance",
    "TOLERANCE",
    "SessionConfig",
    "SESSION_CONFIG",
    "file_encoders",
    "load_file_obj",
    "save_file_obj",
    "intersection",
    "NurbsCurve",
    "NurbsSurface",
    "Primitives",
    "NurbsSurfaceTrimmed",
    "BRep",
    "Element",
    "ElementColumn",
    "ElementBeam",
    "ElementPlate",
    "Closest",
    "remesh_nurbssurface_grid",
    "RemeshCDT",
    "RemeshNurbsSurfaceGrid",
    "RemeshNurbsSurfaceAdaptive",
    "Matrix",
    "ConvexHull",
    "SpatialKDTree",
    "MeshOffset",
]
