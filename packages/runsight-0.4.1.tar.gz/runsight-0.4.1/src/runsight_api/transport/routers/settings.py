from typing import Optional

from fastapi import APIRouter, Depends
from runsight_core.identity import EntityKind, EntityRef

from ...data.filesystem.settings_repo import FileSystemSettingsRepo
from ...domain.errors import ProviderNotFound
from ...logic.services.provider_service import ProviderService
from ...logic.services.settings_service import SettingsService
from ..deps import get_provider_service, get_settings_repo, get_settings_service
from ..schemas.settings import (
    AppSettingsOut,
    AppSettingsUpdate,
    FallbackUpdate,
    ProviderCreate,
    ProviderTestIn,
    ProviderTestOut,
    ProviderUpdate,
    SettingsFallbackResponse,
    SettingsFallbackListResponse,
    SettingsProviderListResponse,
    SettingsProviderResponse,
)

router = APIRouter(prefix="/settings", tags=["Settings"])


def _provider_ref(provider_id: str) -> str:
    return str(EntityRef(EntityKind.PROVIDER, provider_id))


def _preview_api_key(secret: Optional[str]) -> Optional[str]:
    if not secret:
        return None
    if len(secret) <= 8:
        return "•" * len(secret)
    return f"{secret[:6]}...{secret[-4:]}"


def _provider_to_out(p, service: ProviderService) -> SettingsProviderResponse:
    models = p.models if p.models else []
    provider_type = getattr(p, "type", None)
    api_key_preview = None
    if p.api_key:
        secrets = getattr(service, "secrets", None)
        resolved_secret = secrets.resolve(p.api_key) if secrets else None
        api_key_preview = _preview_api_key(
            resolved_secret if isinstance(resolved_secret, str) else None
        )
    return SettingsProviderResponse(
        id=p.id,
        kind=p.kind,
        name=p.name,
        type=provider_type if isinstance(provider_type, str) else None,
        status=p.status or "unknown",
        is_active=bool(getattr(p, "is_active", True)),
        api_key_env=p.api_key,
        api_key_preview=api_key_preview,
        base_url=p.base_url,
        models=models,
        model_count=len(models),
        created_at=str(p.created_at) if hasattr(p, "created_at") and p.created_at else None,
        updated_at=str(p.updated_at) if hasattr(p, "updated_at") and p.updated_at else None,
    )


@router.get("/providers", response_model=SettingsProviderListResponse)
async def list_providers(
    service: ProviderService = Depends(get_provider_service),
):
    providers = service.list_providers()
    items = [_provider_to_out(p, service) for p in providers]
    return {"items": items, "total": len(items)}


@router.get("/providers/{provider_id}", response_model=SettingsProviderResponse)
async def get_provider(
    provider_id: str,
    service: ProviderService = Depends(get_provider_service),
):
    provider = service.get_provider(provider_id)
    if not provider:
        raise ProviderNotFound(f"Provider {_provider_ref(provider_id)} not found")
    return _provider_to_out(provider, service)


@router.post("/providers", response_model=SettingsProviderResponse)
async def create_provider(
    data: ProviderCreate,
    service: ProviderService = Depends(get_provider_service),
):
    provider = service.create_provider(
        id=data.id,
        kind=data.kind,
        name=data.name,
        api_key=data.api_key_env,
        base_url=data.base_url,
    )
    return _provider_to_out(provider, service)


@router.put("/providers/{provider_id}", response_model=SettingsProviderResponse)
async def update_provider(
    provider_id: str,
    data: ProviderUpdate,
    service: ProviderService = Depends(get_provider_service),
):
    provider = service.update_provider(
        provider_id=provider_id,
        id=data.id,
        kind=data.kind,
        name=data.name,
        api_key=data.api_key_env,
        base_url=data.base_url,
        is_active=data.is_active,
    )
    if not provider:
        raise ProviderNotFound(f"Provider {_provider_ref(provider_id)} not found")
    return _provider_to_out(provider, service)


@router.delete("/providers/{provider_id}")
async def delete_provider(
    provider_id: str,
    service: ProviderService = Depends(get_provider_service),
):
    deleted = service.delete_provider(provider_id)
    if not deleted:
        raise ProviderNotFound(f"Provider {_provider_ref(provider_id)} not found")
    return {"id": provider_id, "deleted": True}


@router.post("/providers/{provider_id}/test", response_model=ProviderTestOut)
async def test_provider(
    provider_id: str,
    service: ProviderService = Depends(get_provider_service),
):
    return await service.test_connection(provider_id)


@router.post("/providers/test", response_model=ProviderTestOut)
async def test_provider_credentials(
    data: ProviderTestIn,
    service: ProviderService = Depends(get_provider_service),
):
    return await service.test_credentials(
        provider_id=data.provider_id,
        provider_type=data.provider_type,
        name=data.name,
        api_key=data.api_key_env,
        base_url=data.base_url,
    )


@router.get("/fallbacks", response_model=SettingsFallbackListResponse)
async def list_fallback_targets(
    service: SettingsService = Depends(get_settings_service),
):
    items = service.get_fallback_targets()
    return {"items": items, "total": len(items)}


@router.put("/fallbacks/{provider_id}", response_model=SettingsFallbackResponse)
async def update_fallback_target(
    provider_id: str,
    data: FallbackUpdate,
    service: SettingsService = Depends(get_settings_service),
):
    return service.update_fallback_target(
        provider_id=provider_id,
        fallback_provider_id=data.fallback_provider_id,
        fallback_model_id=data.fallback_model_id,
    )


@router.get("/app", response_model=AppSettingsOut)
async def get_app_settings(
    repo: FileSystemSettingsRepo = Depends(get_settings_repo),
):
    settings_config = repo.get_settings()
    return settings_config.model_dump(exclude_none=True)


@router.put("/app", response_model=AppSettingsOut)
async def update_app_settings(
    data: AppSettingsUpdate,
    repo: FileSystemSettingsRepo = Depends(get_settings_repo),
):
    settings_config = repo.update_settings(data.model_dump(exclude_none=True))
    return settings_config.model_dump(exclude_none=True)
