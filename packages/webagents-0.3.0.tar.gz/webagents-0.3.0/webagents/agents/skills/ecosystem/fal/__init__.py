"""Fal.ai ecosystem skills"""

