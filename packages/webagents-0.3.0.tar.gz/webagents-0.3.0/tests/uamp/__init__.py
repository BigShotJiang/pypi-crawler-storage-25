"""UAMP protocol tests."""
