"""Plugin system tests"""
