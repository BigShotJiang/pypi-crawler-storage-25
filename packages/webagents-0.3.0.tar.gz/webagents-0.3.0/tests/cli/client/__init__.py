"""Client tests"""
