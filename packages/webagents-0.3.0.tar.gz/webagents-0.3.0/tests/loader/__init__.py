"""Loader tests."""
