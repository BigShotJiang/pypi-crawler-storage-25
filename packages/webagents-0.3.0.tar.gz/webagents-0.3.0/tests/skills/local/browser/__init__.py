"""Browser skills tests."""
