"""Local skills tests"""
