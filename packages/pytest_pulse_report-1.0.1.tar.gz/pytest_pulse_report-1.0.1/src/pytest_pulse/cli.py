"""CLI entry points — mirrors the npm bin scripts in the JS version.

Commands (registered in pyproject.toml):
  generate-pulse-report   → self-contained static HTML (all assets embedded)
  generate-report         → dynamic HTML (references attachment files)
  merge-pulse-report      → merge sharded / sequential reports
  send-email              → send report via email
  generate-email-report   → generate lightweight email HTML summary
  generate-trend          → archive current run for trend history
"""
from __future__ import annotations

import argparse
import os
import sys


from .env_utils import get_reporter_config
from .shared_ui import console, error_console
from .console_logo import animate

# ── Shared helpers ──────────────────────────────────────────────────────────────

def _find_report_json(output_dir: str, output_file: str) -> str:
    path = os.path.join(output_dir, output_file)
    if not os.path.isfile(path):
        sys.exit(
            f"✗ Report JSON not found at: {path}\n"
            f"  Run your tests first with the pulse-report plugin enabled."
        )
    return path


def _resolve_dirs(args) -> tuple[str, str]:
    """Return (output_dir, output_file)."""
    config = get_reporter_config(getattr(args, "output_dir", None))
    return os.path.abspath(config["outputDir"]), config["outputFile"]


# ── generate-pulse-report ───────────────────────────────────────────────────────

def generate_static_report(argv=None) -> None:
    """generate-pulse-report — static, fully self-contained HTML report."""
    p = argparse.ArgumentParser(
        prog="generate-pulse-report",
        description="Generate a self-contained static HTML pulse report",
    )
    p.add_argument("--outputDir", "-o", dest="output_dir", default=None,
                   help="Report output directory (default: pulse-report)")
    args = p.parse_args(argv)
    animate()
    output_dir, output_file = _resolve_dirs(args)

    from .merge_reports import merge_sequential_reports, merge_shard_files, archive_trend
    merge_shard_files(output_dir) # handle xdist shards
    merge_sequential_reports(output_dir)  # no-op if nothing to merge
    archive_trend(output_dir)

    json_path = _find_report_json(output_dir, output_file)
    html_path = os.path.join(output_dir, "playwright-pulse-static-report.html")

    console.print(f"\n[bold magenta]⚡ Pulse Report — Generating Static HTML[/bold magenta]\n")
    console.print(f"  Source : {json_path}")
    console.print(f"  Output : {html_path}\n")

    from .static_generator import generate_static_html
    generate_static_html(json_path, html_path)

    console.print(f"[bold green]✓ Static report generated[/bold green] → [cyan]{html_path}[/cyan]")
    _print_stats(json_path)
    console.print("\n💡 [bold cyan]Tip:[/bold cyan] [dim]Use 'generate-report' for a dynamic dashboard that supports attachments (screenshots/videos).[/dim]")


# ── generate-report ─────────────────────────────────────────────────────────────

def generate_report(argv=None) -> None:
    """generate-report — dynamic HTML that references attachment files."""
    p = argparse.ArgumentParser(
        prog="generate-report",
        description="Generate a dynamic HTML pulse report (references attachments)",
    )
    p.add_argument("--outputDir", "-o", dest="output_dir", default=None)
    args = p.parse_args(argv)
    animate()
    output_dir, output_file = _resolve_dirs(args)

    from .merge_reports import merge_sequential_reports, merge_shard_files, archive_trend
    merge_shard_files(output_dir)
    merge_sequential_reports(output_dir)
    archive_trend(output_dir)

    json_path = _find_report_json(output_dir, output_file)
    html_path = os.path.join(output_dir, "playwright-pulse-report.html")

    console.print(f"\n[bold magenta]⚡ Pulse Report — Generating Dynamic HTML[/bold magenta]\n")
    from .dynamic_generator import generate_dynamic_html
    generate_dynamic_html(json_path, html_path)

    console.print(f"[bold green]✓ Dynamic report generated[/bold green] → [cyan]{html_path}[/cyan]")
    _print_stats(json_path)
    console.print("\n💡 [bold cyan]Tip:[/bold cyan] [dim]Use 'generate-pulse-report' for a self-contained static HTML report (best for sharing via email/Slack).[/dim]")


# ── merge-pulse-report ──────────────────────────────────────────────────────────

def merge_reports_cli(argv=None) -> None:
    """merge-pulse-report — merge sharded or sequential reports."""
    p = argparse.ArgumentParser(
        prog="merge-pulse-report",
        description="Merge pulse reports (sharded or sequential runs)",
    )
    p.add_argument("--outputDir", "-o", dest="output_dir", default=None)
    p.add_argument("--no-cleanup", dest="cleanup", action="store_false", default=True,
                   help="Keep shard directories after merging")
    args = p.parse_args(argv)
    animate()
    output_dir, output_file = _resolve_dirs(args)

    console.print(f"\n[bold magenta]⚡ Pulse Report — Merge Reports[/bold magenta]\n")
    console.print(f"  Directory : {output_dir}")

    from .merge_reports import merge_shard_directories, merge_shard_files, merge_sequential_reports

    # First try directory merge (CI-style sharding)
    result = merge_shard_directories(
        output_dir, output_file, cleanup=args.cleanup
    )
    if result is None:
        # Try shard file merge (xdist-style sharding)
        result = merge_shard_files(
            output_dir, output_file, cleanup=args.cleanup
        )
    if result is None:
        # Fall back to sequential merge
        result = merge_sequential_reports(output_dir)
    if result is None:
        console.print("✗ Nothing to merge.")
        return

    console.print(f"\n✓ Merged report → {result}")
    _print_stats(result)



# ── generate-email-report ───────────────────────────────────────────────────────

def generate_email_report_cli(argv=None) -> None:
    """generate-email-report — lightweight email-friendly HTML summary."""
    p = argparse.ArgumentParser(
        prog="generate-email-report",
        description="Generate a lightweight email summary HTML",
    )
    p.add_argument("--outputDir", "-o", dest="output_dir", default=None)
    args = p.parse_args(argv)
    animate()
    output_dir, output_file = _resolve_dirs(args)

    json_path = _find_report_json(output_dir, output_file)
    email_path = os.path.join(output_dir, "pulse-email-summary.html")

    from .email_generator import generate_email_html
    html = generate_email_html(json_path)
    with open(email_path, "w", encoding="utf-8") as fh:
        fh.write(html)
    console.print(f"[bold green]✓ Email summary generated[/bold green] → [cyan]{email_path}[/cyan]")


# ── send-email ──────────────────────────────────────────────────────────────────

def send_email_cli(argv=None) -> None:
    """send-email — send the report via SMTP."""
    p = argparse.ArgumentParser(
        prog="send-email",
        description="Send the pulse report via email (reads credentials from env)",
    )
    p.add_argument("--outputDir", "-o", dest="output_dir", default=None)
    p.add_argument("--attach-html", dest="attach_html", action="store_true", default=False,
                   help="Attach the static HTML report file")
    args = p.parse_args(argv)
    animate()
    output_dir, output_file = _resolve_dirs(args)

    json_path = _find_report_json(output_dir, output_file)
    attachment = None
    if args.attach_html:
        html_path = os.path.join(output_dir, "playwright-pulse-static-report.html")
        if not os.path.isfile(html_path):
            console.print("  Static HTML not found, generating it first …")
            from .static_generator import generate_static_html
            generate_static_html(json_path, html_path)
        attachment = html_path

    from .email_sender import send_report
    try:
        send_report(json_path, attachment_path=attachment)
    except Exception as exc:
        console.print(f"✗ Email sending failed: {exc}")
        sys.exit(1)


# ── generate-trend ──────────────────────────────────────────────────────────────

def generate_trend_cli(argv=None) -> None:
    """generate-trend — archive current run JSON for historical trend analysis."""
    p = argparse.ArgumentParser(
        prog="generate-trend",
        description="Archive the current run JSON for trend history",
    )
    p.add_argument("--outputDir", "-o", dest="output_dir", default=None)
    p.add_argument("--max-history", dest="max_history", type=int, default=15)
    args = p.parse_args(argv)
    animate()
    output_dir, output_file = _resolve_dirs(args)

    from .merge_reports import archive_trend
    archive_trend(output_dir, output_file, max_history=args.max_history)


# ── Shared stat printer ─────────────────────────────────────────────────────────

def _print_stats(json_path: str) -> None:
    try:
        import json
        with open(json_path, "r", encoding="utf-8") as fh:
            data = json.load(fh)
        run = data.get("run") or {}
        console.print(f"\n  Total: {run.get('totalTests',0)}  "
              f"✓ Passed: {run.get('passed',0)}  "
              f"✗ Failed: {run.get('failed',0)}  "
              f"⊘ Skipped: {run.get('skipped',0)}  "
              f"⚡ Flaky: {run.get('flaky',0)}")
    except Exception:
        pass
