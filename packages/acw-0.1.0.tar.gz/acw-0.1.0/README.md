# ACW (Auto Commit Wizard)

AI를 활용해 Git 커밋 메시지를 생성하는 CLI 도구입니다.

`litellm` 기반으로 OpenAI, Anthropic, Google Gemini, Ollama, LM Studio 등 다양한 provider를 사용할 수 있습니다.

## 주요 기능

- 설정 마법사(`acw config`)로 provider/model/API 키 환경변수/기본 옵션 설정
- `staged diff`(기본), `stash`, `ref` 기준 커밋 메시지 생성
- 프롬프트 템플릿 관리(`acw prompt`) 및 포맷별 기본 프롬프트 제공
- 로컬 LLM 서버 연결 진단(`acw doctor`)
- 후보 여러 개 생성 후 선택, JSON 출력, 파일 저장, 클립보드 복사 지원

## 요구 사항

- Python 3.11+
- Git
- [uv](https://github.com/astral-sh/uv) 권장

## 설치

PyPI 배포 버전을 `uv`로 설치:

```bash
uv tool install acw
```

개발용(소스에서 실행):

```bash
git clone https://github.com/auto-commit-wizard/acw.git
cd acw
uv sync
```

## 빠른 시작

처음에는 설정 마법사를 실행하세요.

```bash
acw config
```

가장 기본적인 실행은 다음과 같습니다.

```bash
acw generate
```

참고:

- `acw`에 서브커맨드를 생략하면 내부적으로 `generate`로 동작합니다.
- 기본 생성 대상은 `staged` 변경사항입니다. (`git add`가 먼저 필요)

## 명령어

### `acw generate`

Git diff를 수집해 커밋 메시지를 생성합니다.

- `-p, --provider`: provider 지정
- `-m, --model`: 모델명 지정
- `-P, --profile`: profile 지정
- `-t, --prompt`: 프롬프트 이름 지정
- `-F, --prompt-file`: 프롬프트 파일 경로 지정
- `--print-prompt`: 최종 프롬프트 출력
- `-l, --language {ko,en}`: 출력 언어
- `-f, --format {plain,conventional,gitmoji}`: 메시지 포맷
- `-g, --generate`: 후보 개수
- `--from-stash`: stash 기준 diff 사용
- `--from-ref`: ref 기준 diff 사용
- `-x, --exclude`: 제외 패턴(반복 가능)
- `-s, --max-diff-size`: diff 최대 바이트
- `-y, --yes`: 확인 프롬프트 생략
- `-d, --dry-run`: 실제 커밋 없이 메시지 생성
- `-j, --json`: JSON 출력
- `-o, --output`: 메시지를 파일로 저장
- `-c, --clipboard`: 메시지를 클립보드로 복사
- `-n, --no-verify`: `git commit --no-verify` 사용
- `-a, --all`: 커밋 시 `git commit -a` 사용

예시:

```bash
# 메시지만 생성
uv run acw generate --dry-run

# 후보 3개 생성
uv run acw generate --generate 3

# 특정 브랜치 기준 diff
uv run acw generate --from-ref origin/main --dry-run

# stash 기준 diff
uv run acw generate --from-stash stash@{0} --dry-run

# JSON 출력
uv run acw generate --json --dry-run
```

### `acw config`

설정 마법사 실행 또는 설정 삭제

```bash
uv run acw config
uv run acw config --delete
```

### `acw prompt`

프롬프트 템플릿 조회/관리

```bash
uv run acw prompt --list
uv run acw prompt --name conventional --show
uv run acw prompt --name team --set "팀 규칙을 반영해 작성"
uv run acw prompt --name team --file ./prompt.md
uv run acw prompt --sync
```

### `acw doctor`

로컬 provider(`ollama`, `lmstudio`) 연결 및 모델 가용성 점검

```bash
uv run acw doctor --provider ollama
uv run acw doctor --provider lmstudio --timeout 60
```

## 설정 위치

기본 설정 디렉터리:

- `~/.config/acw`

환경변수로 변경 가능:

- `ACW_CONFIG_DIR`

생성되는 주요 파일/디렉터리:

- `config.toml`
- `prompts/*.md`
- `profiles/*.toml`

## 환경 변수

기본 API 키 환경 변수 매핑:

- `OPENAI_API_KEY`
- `ANTHROPIC_API_KEY`
- `GEMINI_API_KEY`
- `OPENROUTER_API_KEY`
- `XAI_API_KEY`
- `GROQ_API_KEY`
- `DEEPSEEK_API_KEY`
- `COHERE_API_KEY`

## 프로젝트 구조

```text
acw/
├── src/acw/
│   ├── __init__.py
│   ├── cli/
│   │   ├── __init__.py      # CLI 진입점(main) 및 의존성 조립
│   │   ├── parser.py        # argparse 파서/옵션 정의
│   │   ├── dispatch.py      # 명령 디스패치
│   │   ├── commands.py      # config/prompt/doctor 핸들러
│   │   ├── generate.py      # generate 명령 오케스트레이션
│   │   └── helpers.py       # git/clipboard/progress/interactive 보조 함수
│   ├── config/
│   │   ├── __init__.py
│   │   ├── shared.py        # 공통 상수/타입/에러
│   │   ├── layout.py        # 설정 파일 로드/저장, 디렉터리 관리
│   │   ├── resolver.py      # 실행 시 최종 설정 해석
│   │   └── prompts.py       # 프롬프트 파일 해석/병합
│   ├── diff_collector.py    # diff 수집 및 exclude 필터링
│   ├── generate_input.py    # 생성 입력 정규화
│   ├── generator.py         # litellm 호출 및 후보 생성
│   ├── onboarding.py        # 대화형 설정 마법사
│   ├── doctor.py            # 로컬 provider 진단
│   ├── prompt_catalog.py    # 내장 프롬프트 템플릿/카탈로그
│   └── models.py            # provider별 추천 모델 enum
├── tests/
│   ├── test_cli.py
│   ├── test_config.py
│   ├── test_diff_collector.py
│   ├── test_doctor.py
│   ├── test_generate_input.py
│   ├── test_generator.py
│   └── test_onboarding.py
├── pyproject.toml
└── README.md
```

## 개발

테스트:

```bash
uv run pytest
```

타입 체크:

```bash
uv run pyright
```

## 라이선스

- MIT ([LICENSE](./LICENSE))
