from __future__ import annotations

import os
from collections.abc import Mapping

from acw.config.layout import (
    _as_dict,
    _get_float,
    _get_str,
    _load_toml,
    load_config_settings,
    load_profile_settings,
)
from acw.config.shared import (
    DEFAULT_FORMAT,
    DEFAULT_LANGUAGE,
    DEFAULT_MODEL,
    DEFAULT_PROVIDER,
    DEFAULT_PROVIDER_ENV,
    DEFAULT_PROVIDER_TIMEOUT,
    ConfigLayout,
    MissingAPIKeyError,
    ProfileSettings,
    ResolvedGenerateSettings,
    first_non_empty,
    normalize_provider_name,
    provider_default_base_url,
    provider_requires_api_key,
)


def resolve_provider_env_var(layout: ConfigLayout, provider: str) -> str | None:
    normalized_provider = normalize_provider_name(provider)
    data = _load_toml(layout.config_file)
    return _resolve_provider_env_var_from_data(data, normalized_provider)


def resolve_provider_base_url(layout: ConfigLayout, provider: str) -> str | None:
    normalized_provider = normalize_provider_name(provider)
    data = _load_toml(layout.config_file)
    return _resolve_provider_base_url_from_data(data, normalized_provider)


def resolve_provider_timeout(layout: ConfigLayout, provider: str) -> float:
    normalized_provider = normalize_provider_name(provider)
    data = _load_toml(layout.config_file)
    return _resolve_provider_timeout_from_data(data, normalized_provider)


def resolve_generate_settings(
    *,
    layout: ConfigLayout,
    cli_provider: str | None,
    cli_model: str | None,
    cli_profile: str | None,
    cli_language: str | None,
    cli_format: str | None,
    environ: dict[str, str] | None = None,
) -> ResolvedGenerateSettings:
    env: Mapping[str, str]
    if environ is None:
        env = os.environ
    else:
        env = environ
    config = load_config_settings(layout)

    selected_profile = cli_profile or config.profile
    profile = (
        load_profile_settings(layout, selected_profile)
        if selected_profile is not None
        else ProfileSettings()
    )

    provider = normalize_provider_name(
        first_non_empty(cli_provider, profile.provider, config.provider)
        or DEFAULT_PROVIDER
    )
    model = first_non_empty(cli_model, profile.model, config.model) or DEFAULT_MODEL
    language = (
        first_non_empty(cli_language, profile.language, config.language)
        or DEFAULT_LANGUAGE
    )
    format_name = (
        first_non_empty(cli_format, profile.format, config.format) or DEFAULT_FORMAT
    )
    data = _load_toml(layout.config_file)
    base_url = _resolve_provider_base_url_from_data(data, provider)
    timeout_seconds = _resolve_provider_timeout_from_data(data, provider)
    key_env_var = _resolve_provider_env_var_from_data(data, provider)
    api_key = env.get(key_env_var, "").strip() if key_env_var is not None else None

    requires_api_key = provider_requires_api_key(provider)
    if requires_api_key and not api_key:
        assert key_env_var is not None
        raise MissingAPIKeyError(provider=provider, key_env_var=key_env_var)

    return ResolvedGenerateSettings(
        provider=provider,
        model=model,
        profile=selected_profile,
        language=language,
        format=format_name,
        base_url=base_url,
        key_env_var=key_env_var,
        api_key=api_key,
        timeout_seconds=timeout_seconds,
    )


def _resolve_provider_env_var_from_data(
    data: dict[str, object],
    provider: str,
) -> str | None:
    provider_env = _as_dict(data.get("provider_env"))

    configured = _get_str(provider_env.get(provider))
    if configured is not None:
        return configured

    fallback = DEFAULT_PROVIDER_ENV.get(provider)
    if fallback is None:
        if not provider_requires_api_key(provider):
            return None
        upper_name = provider.upper().replace("-", "_")
        return f"{upper_name}_API_KEY"
    return fallback


def _resolve_provider_base_url_from_data(
    data: dict[str, object],
    provider: str,
) -> str | None:
    provider_base_url = _as_dict(data.get("provider_base_url"))

    configured = _get_str(provider_base_url.get(provider))
    if configured is not None:
        return configured
    return provider_default_base_url(provider)


def _resolve_provider_timeout_from_data(
    data: dict[str, object],
    provider: str,
) -> float:
    provider_timeout = _as_dict(data.get("provider_timeout"))

    configured = _get_float(provider_timeout.get(provider))
    if configured is not None:
        return configured
    return DEFAULT_PROVIDER_TIMEOUT.get(provider, 30.0)
