from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path

DEFAULT_PROVIDER = "openai"
DEFAULT_MODEL = "gpt-4.1-mini"
DEFAULT_LANGUAGE = "ko"
DEFAULT_FORMAT = "plain"
DEFAULT_PROMPT = "default"
DEFAULT_REQUEST_TIMEOUT_SECONDS = 30.0

DEFAULT_PROVIDER_ENV: dict[str, str] = {
    "openai": "OPENAI_API_KEY",
    "anthropic": "ANTHROPIC_API_KEY",
    "google": "GEMINI_API_KEY",
    "openrouter": "OPENROUTER_API_KEY",
    "xai": "XAI_API_KEY",
    "groq": "GROQ_API_KEY",
    "deepseek": "DEEPSEEK_API_KEY",
    "cohere": "COHERE_API_KEY",
}


@dataclass(frozen=True, slots=True)
class ProviderPolicy:
    requires_api_key: bool = True
    default_base_url: str | None = None


PROVIDER_POLICIES: dict[str, ProviderPolicy] = {
    "ollama": ProviderPolicy(
        requires_api_key=False,
        default_base_url="http://localhost:11434",
    ),
    "lmstudio": ProviderPolicy(
        requires_api_key=False,
        default_base_url="http://localhost:1234/v1",
    ),
}
DEFAULT_PROVIDER_BASE_URL: dict[str, str] = {
    provider: policy.default_base_url
    for provider, policy in PROVIDER_POLICIES.items()
    if policy.default_base_url is not None
}
DEFAULT_PROVIDER_TIMEOUT: dict[str, float] = {
    "ollama": DEFAULT_REQUEST_TIMEOUT_SECONDS,
    "lmstudio": DEFAULT_REQUEST_TIMEOUT_SECONDS,
}


class ConfigError(ValueError):
    pass


PROMPT_NAME_PATTERN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]*$")
PROMPT_OVERRIDE_MARKER = "!override"
PROMPT_EXTEND_MARKER = "!extend"


class MissingAPIKeyError(ConfigError):
    provider: str
    key_env_var: str

    def __init__(self, provider: str, key_env_var: str) -> None:
        self.provider = provider
        self.key_env_var = key_env_var
        super().__init__(
            f"API 키를 찾지 못했습니다. provider='{provider}' 에 필요한 환경변수 '{key_env_var}' 를 설정하세요."
        )


@dataclass(slots=True)
class ProfileSettings:
    provider: str | None = None
    model: str | None = None
    language: str | None = None
    format: str | None = None


@dataclass(slots=True)
class ConfigSettings:
    provider: str | None = None
    model: str | None = None
    profile: str | None = None
    language: str | None = None
    format: str | None = None
    prompt: str | None = None


@dataclass(slots=True)
class ResolvedGenerateSettings:
    provider: str
    model: str
    profile: str | None
    language: str
    format: str
    base_url: str | None
    key_env_var: str | None
    api_key: str | None
    timeout_seconds: float


@dataclass(slots=True)
class ConfigLayout:
    root: Path
    config_file: Path
    prompts_dir: Path
    profiles_dir: Path


def first_non_empty(*values: str | None) -> str | None:
    for value in values:
        if value is not None and value.strip():
            return value.strip()
    return None


def normalize_provider_name(provider: str) -> str:
    return provider.strip().lower()


def provider_policy(provider: str) -> ProviderPolicy:
    normalized_provider = normalize_provider_name(provider)
    return PROVIDER_POLICIES.get(normalized_provider, ProviderPolicy())


def provider_requires_api_key(provider: str) -> bool:
    return provider_policy(provider).requires_api_key


def provider_default_base_url(provider: str) -> str | None:
    return provider_policy(provider).default_base_url


def escape_toml_string(value: str) -> str:
    return value.replace("\\", "\\\\").replace('"', '\\"')
