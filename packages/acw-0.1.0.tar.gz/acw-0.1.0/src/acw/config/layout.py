from __future__ import annotations

import os
import tomllib
from collections.abc import Mapping
from pathlib import Path
from typing import TypeGuard, cast

from acw.config.shared import (
    DEFAULT_LANGUAGE,
    DEFAULT_PROMPT,
    DEFAULT_PROVIDER_BASE_URL,
    DEFAULT_PROVIDER_ENV,
    DEFAULT_PROVIDER_TIMEOUT,
    ConfigError,
    ConfigLayout,
    ConfigSettings,
    ProfileSettings,
    escape_toml_string,
)
from acw.prompt_catalog import (
    BUILTIN_PROMPT_NAMES,
    build_builtin_prompt_templates,
    make_prompt_stem,
)


def get_config_layout(base_dir: Path | None = None) -> ConfigLayout:
    env_dir = os.environ.get("ACW_CONFIG_DIR")
    if base_dir is not None:
        root = base_dir.expanduser()
    elif env_dir:
        root = Path(env_dir).expanduser()
    else:
        root = Path.home() / ".config" / "acw"
    return ConfigLayout(
        root=root,
        config_file=root / "config.toml",
        prompts_dir=root / "prompts",
        profiles_dir=root / "profiles",
    )


def ensure_config_layout(base_dir: Path | None = None) -> ConfigLayout:
    layout = get_config_layout(base_dir=base_dir)
    layout.prompts_dir.mkdir(parents=True, exist_ok=True)
    layout.profiles_dir.mkdir(parents=True, exist_ok=True)

    if not layout.config_file.exists():
        _ = layout.config_file.write_text(_default_config_template(), encoding="utf-8")
    sync_builtin_prompt_templates(layout, overwrite=False)
    return layout


def sync_builtin_prompt_templates(layout: ConfigLayout, *, overwrite: bool) -> None:
    templates = _default_prompt_templates()
    for prompt_name, template in templates.items():
        default_prompt_path = layout.prompts_dir / f"{prompt_name}.md"
        if overwrite or not default_prompt_path.exists():
            _ = default_prompt_path.write_text(template, encoding="utf-8")

    # Backward compatibility: keep legacy non-language prompt files in sync too.
    for prompt_name in BUILTIN_PROMPT_NAMES:
        legacy_prompt_path = layout.prompts_dir / f"{prompt_name}.md"
        language_stem = make_prompt_stem(prompt_name, language=DEFAULT_LANGUAGE)
        template = templates.get(language_stem)
        if template is None:
            continue
        if overwrite or not legacy_prompt_path.exists():
            _ = legacy_prompt_path.write_text(template, encoding="utf-8")


def _default_config_template() -> str:
    return """[defaults]
provider = "openai"
model = "gpt-4.1-mini"
profile = ""
language = "ko"
format = "plain"
prompt = "default"

[provider_env]
# Provider -> API key environment variable mapping
openai = "OPENAI_API_KEY"
anthropic = "ANTHROPIC_API_KEY"
google = "GEMINI_API_KEY"
openrouter = "OPENROUTER_API_KEY"
xai = "XAI_API_KEY"
groq = "GROQ_API_KEY"
deepseek = "DEEPSEEK_API_KEY"
cohere = "COHERE_API_KEY"

[provider_base_url]
# Provider -> Base URL mapping (for local/compatible endpoints)
ollama = "http://localhost:11434"
lmstudio = "http://localhost:1234/v1"

[provider_timeout]
# Provider -> Request timeout seconds mapping
ollama = 30.0
lmstudio = 30.0
"""


def _default_prompt_templates() -> dict[str, str]:
    return build_builtin_prompt_templates()


def load_config_settings(layout: ConfigLayout) -> ConfigSettings:
    data = _load_toml(layout.config_file)
    defaults = _as_dict(data.get("defaults"))

    return ConfigSettings(
        provider=_get_str(defaults.get("provider")),
        model=_get_str(defaults.get("model")),
        profile=_get_str(defaults.get("profile")),
        language=_get_str(defaults.get("language")),
        format=_get_str(defaults.get("format")),
        prompt=_get_str(defaults.get("prompt")),
    )


def load_profile_settings(layout: ConfigLayout, name: str) -> ProfileSettings:
    profile_path = layout.profiles_dir / f"{name}.toml"
    if not profile_path.exists():
        raise ConfigError(f"프로필을 찾을 수 없습니다: {name} ({profile_path})")

    data = _load_toml(profile_path)
    section = _as_dict(data.get("profile"))

    return ProfileSettings(
        provider=_get_str(section.get("provider")),
        model=_get_str(section.get("model")),
        language=_get_str(section.get("language")),
        format=_get_str(section.get("format")),
    )


def load_provider_env_map(layout: ConfigLayout) -> dict[str, str]:
    data = _load_toml(layout.config_file)
    provider_env = _as_dict(data.get("provider_env"))
    merged = dict(DEFAULT_PROVIDER_ENV)

    for provider, env_name in provider_env.items():
        provider_name = _get_str(provider)
        env_var = _get_str(env_name)
        if provider_name is None or env_var is None:
            continue
        merged[provider_name] = env_var
    return merged


def load_provider_base_url_map(layout: ConfigLayout) -> dict[str, str]:
    data = _load_toml(layout.config_file)
    provider_base_url = _as_dict(data.get("provider_base_url"))
    merged = dict(DEFAULT_PROVIDER_BASE_URL)

    for provider, base_url in provider_base_url.items():
        provider_name = _get_str(provider)
        normalized_base_url = _get_str(base_url)
        if provider_name is None or normalized_base_url is None:
            continue
        merged[provider_name] = normalized_base_url
    return merged


def load_provider_timeout_map(layout: ConfigLayout) -> dict[str, float]:
    data = _load_toml(layout.config_file)
    provider_timeout = _as_dict(data.get("provider_timeout"))
    merged = dict(DEFAULT_PROVIDER_TIMEOUT)

    for provider, timeout in provider_timeout.items():
        provider_name = _get_str(provider)
        timeout_seconds = _get_float(timeout)
        if provider_name is None or timeout_seconds is None:
            continue
        merged[provider_name] = timeout_seconds
    return merged


def save_config_settings(
    layout: ConfigLayout,
    *,
    provider: str,
    model: str,
    profile: str | None,
    language: str,
    format_name: str,
    prompt: str | None = None,
    provider_env_map: dict[str, str],
    provider_base_url_map: dict[str, str] | None = None,
    provider_timeout_map: dict[str, float] | None = None,
) -> None:
    profile_name = profile.strip() if profile is not None else ""
    prompt_name = prompt.strip() if prompt is not None else DEFAULT_PROMPT
    lines = [
        "[defaults]",
        f'provider = "{escape_toml_string(provider.strip())}"',
        f'model = "{escape_toml_string(model.strip())}"',
        f'profile = "{escape_toml_string(profile_name)}"',
        f'language = "{escape_toml_string(language.strip())}"',
        f'format = "{escape_toml_string(format_name.strip())}"',
        f'prompt = "{escape_toml_string(prompt_name)}"',
        "",
        "[provider_env]",
        "# Provider -> API key environment variable mapping",
    ]

    for provider_name, env_var in provider_env_map.items():
        lines.append(f'{provider_name} = "{escape_toml_string(env_var.strip())}"')
    lines.extend(
        [
            "",
            "[provider_base_url]",
            "# Provider -> Base URL mapping (for local/compatible endpoints)",
        ]
    )

    merged_base_url_map = dict(DEFAULT_PROVIDER_BASE_URL)
    if provider_base_url_map is not None:
        for provider_name, base_url in provider_base_url_map.items():
            normalized_provider = provider_name.strip()
            normalized_base_url = base_url.strip()
            if normalized_provider and normalized_base_url:
                merged_base_url_map[normalized_provider] = normalized_base_url
    for provider_name, base_url in merged_base_url_map.items():
        lines.append(f'{provider_name} = "{escape_toml_string(base_url)}"')
    lines.extend(
        [
            "",
            "[provider_timeout]",
            "# Provider -> Request timeout seconds mapping",
        ]
    )
    merged_timeout_map = load_provider_timeout_map(layout)
    if provider_timeout_map is not None:
        for provider_name, timeout in provider_timeout_map.items():
            normalized_provider = provider_name.strip()
            if not normalized_provider or timeout <= 0:
                continue
            merged_timeout_map[normalized_provider] = timeout
    for provider_name, timeout in merged_timeout_map.items():
        lines.append(f"{provider_name} = {timeout:.1f}")
    lines.append("")

    _ = layout.config_file.write_text("\n".join(lines), encoding="utf-8")


def _load_toml(path: Path) -> dict[str, object]:
    if not path.exists():
        empty: dict[str, object] = {}
        return empty
    try:
        with path.open("rb") as fp:
            data = tomllib.load(fp)
    except tomllib.TOMLDecodeError as error:
        raise ConfigError(f"잘못된 TOML 형식입니다: {path} ({error})") from error
    return data


def _as_dict(value: object) -> dict[str, object]:
    if _is_str_object_dict(value):
        return value
    empty: dict[str, object] = {}
    return empty


def _get_str(value: object) -> str | None:
    if not isinstance(value, str):
        return None
    stripped = value.strip()
    return stripped if stripped else None


def _get_float(value: object) -> float | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, int | float):
        timeout_seconds = float(value)
        if timeout_seconds > 0:
            return timeout_seconds
    return None


def _is_str_object_dict(value: object) -> TypeGuard[dict[str, object]]:
    if not isinstance(value, dict):
        return False
    mapping = cast(Mapping[object, object], value)
    return all(isinstance(key, str) for key in mapping.keys())
