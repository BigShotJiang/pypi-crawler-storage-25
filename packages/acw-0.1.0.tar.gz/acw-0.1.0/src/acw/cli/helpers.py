from __future__ import annotations

import os
import subprocess
import sys
import time
from collections.abc import Callable
from concurrent.futures import Future, ThreadPoolExecutor
from dataclasses import dataclass
from typing import TypeVar

from rich.console import Console
from rich.panel import Panel
from rich.progress import BarColumn, Progress, SpinnerColumn, TextColumn, TimeElapsedColumn
from rich.text import Text

from acw.diff_collector import CollectedDiff

ProgressResultT = TypeVar("ProgressResultT")


@dataclass(frozen=True, slots=True)
class GenerationProgressDeps:
    console: Console
    is_interactive_terminal: bool
    refresh_sec: float
    is_pytest: bool


@dataclass(frozen=True, slots=True)
class ConsoleConfirmDeps:
    console: Console
    ask_confirm: Callable[[str, bool], bool | None]
    is_interactive_terminal: bool = True


@dataclass(frozen=True, slots=True)
class SelectionDeps:
    ask_select: Callable[[list[str]], str | None]
    ask_confirm: Callable[[str, bool], bool | None]


def truncate_utf8_text(text: str, max_bytes: int) -> str:
    return text.encode("utf-8")[:max_bytes].decode("utf-8", errors="ignore")


def normalize_optional_str(value: str | None) -> str | None:
    if value is None:
        return None
    stripped = value.strip()
    if not stripped:
        return None
    return stripped


def run_with_generation_progress(
    label: str,
    fn: Callable[[], ProgressResultT],
    *,
    timeout_seconds: float,
    enabled: bool,
    deps: GenerationProgressDeps,
) -> ProgressResultT:
    if not enabled:
        return fn()

    if not deps.is_interactive_terminal:
        deps.console.print(label)
        return fn()

    if deps.is_pytest:
        deps.console.print(f"{label} (timeout={timeout_seconds:.0f}s)")
        return fn()

    with ThreadPoolExecutor(max_workers=1) as executor:
        future: Future[ProgressResultT] = executor.submit(fn)
        start_time = time.monotonic()
        with Progress(
            SpinnerColumn(style="cyan"),
            TextColumn("[bold cyan]{task.description}"),
            BarColumn(bar_width=24),
            TextColumn("{task.percentage:>3.0f}%"),
            TimeElapsedColumn(),
            console=deps.console,
            transient=False,
        ) as progress:
            task_id = progress.add_task(label, total=timeout_seconds)
            while not future.done():
                elapsed = time.monotonic() - start_time
                progress.update(
                    task_id,
                    completed=min(elapsed, timeout_seconds),
                )
                time.sleep(deps.refresh_sec)
            progress.update(task_id, completed=timeout_seconds)

        return future.result()


def render_generated_messages(messages: list[str], *, console: Console) -> None:
    if not messages:
        return

    if len(messages) == 1:
        body = Text(messages[0], no_wrap=False, overflow="fold")
        title = "Generated Commit Message"
    else:
        body = Text(
            "\n".join(f"[{index}] {msg}" for index, msg in enumerate(messages, start=1)),
            no_wrap=False,
            overflow="fold",
        )
        title = "Generated Commit Message Candidates"

    console.print()
    console.print(
        Panel(
            body,
            title=title,
            border_style="cyan",
            expand=True,
        )
    )
    console.print()


def create_git_commit(*, message: str, stage_all: bool, no_verify: bool) -> str | None:
    command = ["git", "commit", "-m", message]
    if stage_all:
        command.insert(2, "-a")
    if no_verify:
        command.append("--no-verify")

    completed = subprocess.run(
        command,
        capture_output=True,
        check=False,
    )
    if completed.returncode == 0:
        return None

    stderr = completed.stderr.decode("utf-8", errors="replace").strip()
    stdout = completed.stdout.decode("utf-8", errors="replace").strip()
    detail = stderr or stdout or "git commit 실행 실패"
    return detail


def collect_staged_files() -> tuple[list[str], str | None]:
    completed = subprocess.run(
        ["git", "diff", "--cached", "--name-only"],
        capture_output=True,
        check=False,
    )
    if completed.returncode != 0:
        stderr = completed.stderr.decode("utf-8", errors="replace").strip()
        stdout = completed.stdout.decode("utf-8", errors="replace").strip()
        detail = stderr or stdout or "staged 파일 목록 수집 실패"
        return [], detail

    staged_files = [
        line.strip()
        for line in completed.stdout.decode("utf-8", errors="replace").splitlines()
        if line.strip()
    ]
    return staged_files, None


def confirm_generation_for_staged_files(
    *,
    staged_files: list[str],
    assume_yes: bool,
    emit_output: bool,
    prompt_enabled: bool,
    deps: ConsoleConfirmDeps,
) -> bool:
    if emit_output:
        staged_body = "\n".join(f"- {path}" for path in staged_files)
        deps.console.print(
            Panel(
                Text(staged_body),
                title="현재 staged 파일",
                border_style="cyan",
                expand=True,
            )
        )

    if assume_yes or not prompt_enabled:
        return True

    confirmed = deps.ask_confirm(
        "위 staged 파일 기준으로 AI 커밋 메시지를 생성할까요?",
        True,
    )
    return confirmed is True


def copy_to_clipboard(message: str) -> str | None:
    if sys.platform == "darwin":
        commands: list[list[str]] = [["pbcopy"]]
    elif sys.platform.startswith("win"):
        commands = [["clip"]]
    else:
        commands = [
            ["wl-copy"],
            ["xclip", "-selection", "clipboard"],
            ["xsel", "--clipboard", "--input"],
        ]

    for command in commands:
        executable = os.fsdecode(command[0])
        resolved_command = [executable, *command[1:]]
        try:
            completed = subprocess.run(
                resolved_command,
                input=message,
                text=True,
                capture_output=True,
                check=False,
            )
        except FileNotFoundError:
            continue

        if completed.returncode == 0:
            return None

        stderr = completed.stderr.strip()
        stdout = completed.stdout.strip()
        detail = stderr or stdout or "클립보드 명령 실행 실패"
        return f"{executable} 실행 실패: {detail}"

    return "사용 가능한 클립보드 명령을 찾을 수 없습니다."


def truncate_diff_with_confirmation(
    *,
    collected: CollectedDiff,
    max_diff_size: int,
    assume_yes: bool,
    deps: ConsoleConfirmDeps,
) -> CollectedDiff | None:
    diff_size = len(collected.diff_text.encode("utf-8"))
    if diff_size <= max_diff_size:
        return collected

    if assume_yes:
        should_truncate = True
    elif deps.is_interactive_terminal:
        should_truncate = (
            deps.ask_confirm(
                f"수집된 diff가 제한({max_diff_size} bytes)을 초과했습니다. 잘라서 계속할까요? (current={diff_size} bytes)",
                False,
            )
            is True
        )
    else:
        should_truncate = False

    if not should_truncate:
        print(
            f"입력 수집 오류: 수집된 diff 크기가 제한을 초과했습니다. (size={diff_size} bytes, limit={max_diff_size} bytes)"
        )
        return None

    truncated = truncate_utf8_text(collected.diff_text, max_diff_size)
    truncated_size = len(truncated.encode("utf-8"))
    print(
        f"수집된 diff를 제한 크기까지 잘라서 진행합니다. (original={diff_size} bytes, truncated={truncated_size} bytes)"
    )
    return CollectedDiff(source=collected.source, diff_text=truncated)


def select_commit_message_interactive(
    commit_messages: list[str],
    *,
    assume_yes: bool,
    deps: SelectionDeps,
) -> str | None:
    if not commit_messages:
        return None

    if assume_yes:
        selected_message = commit_messages[0]
    else:
        selected_message = deps.ask_select(commit_messages)
    if selected_message is None:
        return None

    if assume_yes:
        return selected_message

    confirmed = deps.ask_confirm("선택한 메시지로 진행할까요?", True)
    return selected_message if confirmed is True else None
