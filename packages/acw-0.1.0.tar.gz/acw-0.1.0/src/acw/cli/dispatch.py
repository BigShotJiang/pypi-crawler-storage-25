from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from typing import Protocol

from acw.cli.parser import BaseArgs, GenerateArgs


class _ParserLike(Protocol):
    def parse_args(self, args: list[str], namespace: BaseArgs) -> BaseArgs: ...

    def print_help(self) -> None: ...


@dataclass(frozen=True, slots=True)
class MainDispatchHandlers:
    handle_generate: Callable[[BaseArgs], int]
    handle_config: Callable[[BaseArgs], int]
    handle_prompt: Callable[[BaseArgs], int]
    handle_doctor: Callable[[BaseArgs], int]


@dataclass(frozen=True, slots=True)
class MainDispatchDeps:
    build_parser: Callable[[], _ParserLike]
    argv: list[str]
    base_args_factory: Callable[[], BaseArgs]
    generate_args_factory: Callable[[], GenerateArgs]
    handlers: MainDispatchHandlers


def run_main(deps: MainDispatchDeps) -> int:
    parser = deps.build_parser()
    known_commands = {"generate", "config", "prompt", "doctor"}
    argv = deps.argv
    parse_target = argv if argv[:1] and argv[0] in known_commands else ["generate", *argv]
    namespace: BaseArgs = (
        deps.generate_args_factory()
        if parse_target[:1] == ["generate"]
        else deps.base_args_factory()
    )
    args = parser.parse_args(parse_target, namespace=namespace)

    if args.handler is not None:
        return args.handler(args)
    if args.command == "generate":
        return deps.handlers.handle_generate(args)
    if args.command == "config":
        return deps.handlers.handle_config(args)
    if args.command == "prompt":
        return deps.handlers.handle_prompt(args)
    if args.command == "doctor":
        return deps.handlers.handle_doctor(args)

    parser.print_help()
    return 2
