from __future__ import annotations

import shutil
from collections.abc import Callable, Iterable
from dataclasses import dataclass
from pathlib import Path
from typing import Protocol

from acw.cli.parser import ConfigArgs, DoctorArgs, PromptArgs
from acw.config import ConfigError, ConfigLayout
from acw.doctor import DoctorResult


class _ConfigSettingsLike(Protocol):
    provider: str | None
    model: str | None
    language: str | None
    format: str | None
    prompt: str | None
    profile: str | None


class _ResolvedGenerateSettingsLike(Protocol):
    provider: str
    model: str
    base_url: str | None
    key_env_var: str | None
    api_key: str | None


@dataclass(frozen=True, slots=True)
class ConfigCommandDeps:
    get_config_layout: Callable[[], ConfigLayout]
    ensure_config_layout: Callable[[], ConfigLayout]
    is_interactive_terminal: Callable[[], bool]
    has_existing_user_config_fn: Callable[[ConfigLayout], bool]
    confirm: Callable[[str, bool], bool | None]
    run_onboarding_wizard: Callable[[ConfigLayout], bool]
    sync_builtin_prompt_templates: Callable[[ConfigLayout], object]
    delete_config_fn: Callable[[ConfigLayout, bool], bool]


@dataclass(frozen=True, slots=True)
class PromptCommandDeps:
    ensure_config_layout: Callable[[], ConfigLayout]
    load_config_settings: Callable[[ConfigLayout], _ConfigSettingsLike]
    default_language: str
    sync_builtin_prompt_templates: Callable[[ConfigLayout], object]
    list_prompt_names: Callable[[ConfigLayout, str], list[str]]
    load_prompt: Callable[[ConfigLayout, str, str], str]
    save_prompt: Callable[[ConfigLayout, str, str, str], Path]


@dataclass(frozen=True, slots=True)
class DoctorCommandDeps:
    ensure_config_layout: Callable[[], ConfigLayout]
    resolve_generate_settings: Callable[..., _ResolvedGenerateSettingsLike]
    resolve_provider_timeout: Callable[[ConfigLayout, str], float]
    diagnose_local_provider: Callable[..., DoctorResult]
    local_providers: Iterable[str]


def handle_config_command(
    args: ConfigArgs,
    deps: ConfigCommandDeps,
) -> int:
    layout = deps.get_config_layout()
    if args.delete:
        delete_result = deps.delete_config_fn(layout, args.yes)
        if not delete_result:
            return 2
        return 0

    layout = deps.ensure_config_layout()

    if not deps.is_interactive_terminal():
        print(f"ACW config initialized at: {layout.root}")
        print("비대화형 환경에서는 설정 마법사를 건너뜁니다.")
        return 0

    should_overwrite = False
    if deps.has_existing_user_config_fn(layout):
        overwrite = deps.confirm("기존 설정이 있습니다. 덮어쓸까요?", False)
        if not overwrite:
            print("설정 마법사를 취소했습니다.")
            return 2
        should_overwrite = True

    print("ACW 설정 마법사를 시작합니다.")
    completed = deps.run_onboarding_wizard(layout)
    if not completed:
        print("설정 마법사를 취소했습니다.")
        return 2
    if should_overwrite:
        _ = deps.sync_builtin_prompt_templates(layout)
    return 0


def handle_prompt_command(
    args: PromptArgs,
    deps: PromptCommandDeps,
) -> int:
    layout = deps.ensure_config_layout()
    settings = deps.load_config_settings(layout)
    settings_language = settings.language
    target_language = args.language or settings_language or deps.default_language

    if args.sync:
        _ = deps.sync_builtin_prompt_templates(layout)
        print(f"기본 프롬프트를 최신 템플릿으로 갱신했습니다: {layout.prompts_dir}")
        return 0

    if args.list:
        prompt_names = deps.list_prompt_names(layout, target_language)
        if not prompt_names:
            print("저장된 프롬프트가 없습니다.")
            return 0
        for name in prompt_names:
            print(name)
        return 0

    if args.show:
        if not args.name:
            print("입력 오류: `--show` 사용 시 `--name` 이 필요합니다.")
            return 2
        try:
            print(deps.load_prompt(layout, args.name, target_language))
        except ConfigError as error:
            print(f"설정 오류: {error}")
            return 2
        return 0

    content: str | None = None
    if args.set_text is not None:
        content = args.set_text
    elif args.file is not None:
        try:
            content = Path(args.file).expanduser().read_text(encoding="utf-8")
        except OSError as error:
            print(f"입력 오류: 프롬프트 파일을 읽을 수 없습니다. ({error})")
            return 2

    if content is not None:
        if not args.name:
            print("입력 오류: 프롬프트 저장 시 `--name` 이 필요합니다.")
            return 2
        try:
            prompt_path = deps.save_prompt(layout, args.name, content, target_language)
        except ConfigError as error:
            print(f"설정 오류: {error}")
            return 2
        print(f"프롬프트를 저장했습니다: {prompt_path}")
        return 0

    print("입력 오류: `--list`, `--show`, `--set`, `--file`, `--sync` 중 하나를 지정하세요.")
    return 2


def handle_doctor_command(
    args: DoctorArgs,
    deps: DoctorCommandDeps,
) -> int:
    if args.timeout is not None and args.timeout <= 0:
        print("입력 오류: `--timeout` 은 0보다 커야 합니다.")
        return 2

    layout = deps.ensure_config_layout()
    try:
        resolved = deps.resolve_generate_settings(
            layout=layout,
            cli_provider=args.provider,
            cli_model=args.model,
            cli_profile=args.profile,
            cli_language=None,
            cli_format=None,
        )
    except ConfigError as error:
        print(f"설정 오류: {error}")
        return 2

    print(f"provider: {resolved.provider}")
    print(f"model: {resolved.model}")
    print(f"base_url: {resolved.base_url or '(none)'}")
    if resolved.key_env_var is not None:
        api_key_status = "set" if resolved.api_key else "missing"
        print(f"api_key_env: {resolved.key_env_var} ({api_key_status})")

    if resolved.provider not in deps.local_providers:
        print("현재 doctor는 로컬 provider(ollama/lmstudio) 연결 진단을 지원합니다.")
        return 0
    if resolved.base_url is None:
        print(
            "진단 오류: 로컬 provider의 base_url이 비어 있습니다. "
            "`acw config`에서 provider_base_url을 설정하세요."
        )
        return 2

    timeout_seconds = (
        args.timeout
        if args.timeout is not None
        else deps.resolve_provider_timeout(layout, resolved.provider)
    )

    result = deps.diagnose_local_provider(
        provider=resolved.provider,
        base_url=resolved.base_url,
        configured_model=resolved.model,
        timeout_seconds=timeout_seconds,
    )
    print(f"endpoint: {result.endpoint}")
    if not result.reachable:
        print(f"server: fail ({result.error_message or 'unknown error'})")
        return 2
    print("server: ok")

    if result.models:
        print(f"models: {len(result.models)} found")
        for model_name in result.models:
            print(f"  - {model_name}")
    else:
        print("models: 0 found")

    if result.model_exists:
        print(f"configured model: ok ({result.configured_model})")
        return 0

    print(f"configured model: missing ({result.configured_model})")
    if result.provider == "ollama":
        print(
            "안내: 모델 이름을 확인하고, 필요하면 `ollama pull <model>`로 먼저 다운로드하세요."
        )
    elif result.provider == "lmstudio":
        print(
            "안내: LM Studio에서 해당 모델을 먼저 load한 뒤, 표시되는 모델 ID로 다시 시도하세요."
        )
    else:
        print(
            "안내: 모델 이름을 확인하거나, 모델을 먼저 pull/download 한 뒤 다시 시도하세요."
        )
    return 2


def delete_config(
    layout: ConfigLayout,
    *,
    assume_yes: bool,
    confirm: Callable[[str, bool], bool | None],
) -> bool:
    if not layout.root.exists():
        print(f"삭제할 설정 디렉터리가 없습니다: {layout.root}")
        return True

    if not assume_yes:
        confirmed = confirm(f"정말로 ACW 설정을 모두 삭제할까요? ({layout.root})", False)
        if not confirmed:
            print("설정 삭제를 취소했습니다.")
            return False

    shutil.rmtree(layout.root)
    print(f"ACW 설정을 삭제했습니다: {layout.root}")
    return True


def has_existing_user_config(
    layout: ConfigLayout,
    *,
    load_config_settings: Callable[[ConfigLayout], _ConfigSettingsLike],
    load_provider_env_map: Callable[[ConfigLayout], object],
    default_provider: str,
    default_model: str,
    default_language: str,
    default_format: str,
    default_prompt: str,
    default_provider_env: object,
    is_builtin_prompt_file: Callable[[str], bool],
) -> bool:
    if not layout.config_file.exists():
        return False

    settings = load_config_settings(layout)
    provider_env_map = load_provider_env_map(layout)

    has_custom_defaults = any(
        (
            settings.provider != default_provider,
            settings.model != default_model,
            settings.language != default_language,
            settings.format != default_format,
            settings.prompt != default_prompt,
            settings.profile is not None,
        )
    )
    has_custom_provider_env = provider_env_map != default_provider_env
    has_profiles = any(layout.profiles_dir.glob("*.toml"))
    has_prompts = any(
        prompt_file.is_file() and not is_builtin_prompt_file(prompt_file.stem)
        for prompt_file in layout.prompts_dir.iterdir()
    )

    return has_custom_defaults or has_custom_provider_env or has_profiles or has_prompts
