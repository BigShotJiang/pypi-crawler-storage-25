from __future__ import annotations

from dataclasses import dataclass
from typing import Any
from urllib.parse import urlparse

import httpx

from acw.config import DEFAULT_REQUEST_TIMEOUT_SECONDS

LOCAL_PROVIDERS = {"ollama", "lmstudio"}


@dataclass(frozen=True, slots=True)
class DoctorResult:
    provider: str
    base_url: str
    endpoint: str
    reachable: bool
    error_message: str | None
    models: list[str]
    configured_model: str
    model_exists: bool

    @property
    def ok(self) -> bool:
        return self.reachable and self.model_exists


def diagnose_local_provider(
    *,
    provider: str,
    base_url: str,
    configured_model: str,
    timeout_seconds: float = DEFAULT_REQUEST_TIMEOUT_SECONDS,
) -> DoctorResult:
    normalized_provider = provider.strip().lower()
    endpoint = _resolve_endpoint(normalized_provider, base_url)

    if endpoint is None:
        return DoctorResult(
            provider=normalized_provider,
            base_url=base_url,
            endpoint="",
            reachable=False,
            error_message=f"지원하지 않는 로컬 provider입니다: {provider}",
            models=[],
            configured_model=configured_model,
            model_exists=False,
        )

    try:
        response = httpx.get(endpoint, timeout=timeout_seconds)
        response.raise_for_status()
    except httpx.RequestError as error:
        return DoctorResult(
            provider=normalized_provider,
            base_url=base_url,
            endpoint=endpoint,
            reachable=False,
            error_message=_format_request_error(error),
            models=[],
            configured_model=configured_model,
            model_exists=False,
        )
    except httpx.HTTPStatusError as error:
        return DoctorResult(
            provider=normalized_provider,
            base_url=base_url,
            endpoint=endpoint,
            reachable=False,
            error_message=(
                f"HTTP {error.response.status_code} "
                f"({error.request.method} {error.request.url})"
            ),
            models=[],
            configured_model=configured_model,
            model_exists=False,
        )

    models = _extract_models(normalized_provider, response.json())
    normalized_configured_model = configured_model.strip()
    model_exists = normalized_configured_model in models
    return DoctorResult(
        provider=normalized_provider,
        base_url=base_url,
        endpoint=endpoint,
        reachable=True,
        error_message=None,
        models=models,
        configured_model=normalized_configured_model,
        model_exists=model_exists,
    )


def _resolve_endpoint(provider: str, base_url: str) -> str | None:
    normalized_base = base_url.strip()
    if not normalized_base:
        return None

    if provider == "ollama":
        return _join_url(normalized_base, "api/tags")
    if provider == "lmstudio":
        return _join_url(normalized_base, "models")
    return None


def _join_url(base_url: str, path: str) -> str:
    normalized_path = path.lstrip("/")
    if not normalized_path:
        return base_url.rstrip("/")
    if base_url.endswith("/"):
        return f"{base_url}{normalized_path}"
    return f"{base_url}/{normalized_path}"


def _extract_models(provider: str, payload: Any) -> list[str]:
    if not isinstance(payload, dict):
        return []

    if provider == "ollama":
        raw_models = payload.get("models")
        if not isinstance(raw_models, list):
            return []
        names = [
            model_name
            for item in raw_models
            for model_name in [_read_str_key(item, "name")]
            if model_name is not None
        ]
        return _unique(names)

    if provider == "lmstudio":
        raw_models = payload.get("data")
        if not isinstance(raw_models, list):
            return []
        ids = [
            model_id
            for item in raw_models
            for model_id in [_read_str_key(item, "id")]
            if model_id is not None
        ]
        return _unique(ids)

    return []


def _read_str_key(item: object, key: str) -> str | None:
    if not isinstance(item, dict):
        return None
    value = item.get(key)
    if not isinstance(value, str):
        return None
    normalized = value.strip()
    if not normalized:
        return None
    return normalized


def _unique(values: list[str]) -> list[str]:
    deduped = dict.fromkeys(values)
    return list(deduped.keys())


def _format_request_error(error: httpx.RequestError) -> str:
    request = error.request
    method = request.method
    url = str(request.url)
    parsed = urlparse(url)
    host = parsed.hostname
    port = parsed.port
    root = f"{method} {url} 요청 실패"
    hint = _request_error_hint(error)
    if host is None:
        return f"{root}: {error}{hint}"
    port_text = f":{port}" if port is not None else ""
    return f"{root} (host={host}{port_text}): {error}{hint}"


def _request_error_hint(error: httpx.RequestError) -> str:
    if isinstance(error, httpx.TimeoutException):
        return (
            " | 가이드: 타임아웃이 발생했습니다. 서버 응답이 지연되었습니다. "
            "서버 상태를 확인하고 `acw doctor --timeout` 값을 늘려 재시도하세요."
        )
    if isinstance(error, httpx.ConnectError):
        return (
            " | 가이드: 서버가 실행 중인지 확인하세요. "
            "로컬 서버가 꺼져 있거나, 다른 프로세스와 포트가 충돌했을 수 있습니다."
        )
    if isinstance(error, httpx.NetworkError):
        return (
            " | 가이드: host/port 설정을 확인하세요. "
            "특히 provider_base_url 오타 또는 잘못된 포트 여부를 점검하세요."
        )
    return ""
