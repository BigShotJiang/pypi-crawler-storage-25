from __future__ import annotations

import fnmatch
import re
import subprocess
from dataclasses import dataclass
from pathlib import Path


class DiffCollectionError(RuntimeError):
    pass


@dataclass(slots=True)
class CollectedDiff:
    source: str
    diff_text: str


def collect_diff(
    *,
    from_stash: str | None,
    from_ref: str | None,
    exclude: list[str] | None = None,
    max_diff_size: int | None = 200_000,
    cwd: Path | None = None,
) -> CollectedDiff:
    stash_ref = (from_stash or "").strip()
    ref = (from_ref or "").strip()
    excluded_patterns = [
        pattern.strip() for pattern in (exclude or []) if pattern.strip()
    ]

    if max_diff_size is not None and max_diff_size <= 0:
        raise DiffCollectionError("`--max-diff-size`는 1 이상의 정수여야 합니다.")

    if stash_ref and ref:
        raise DiffCollectionError(
            "`--from-stash`와 `--from-ref`는 동시에 사용할 수 없습니다."
        )

    if stash_ref:
        command = ["git", "stash", "show", "--patch", "--no-color", stash_ref]
        source = f"stash:{stash_ref}"
    elif ref:
        command = ["git", "diff", "--no-color", ref]
        source = f"ref:{ref}"
    else:
        command = ["git", "diff", "--cached", "--no-color"]
        source = "staged"

    completed = subprocess.run(
        command,
        capture_output=True,
        cwd=cwd,
        check=False,
    )

    if completed.returncode != 0:
        stderr = completed.stderr.decode("utf-8", errors="replace").strip()
        detail = stderr or "git 명령 실행 실패"
        raise DiffCollectionError(f"diff 수집에 실패했습니다. ({detail})")

    diff_text = completed.stdout.decode("utf-8", errors="replace")
    filtered_diff = _apply_excludes(diff_text, excluded_patterns)
    diff_size = len(filtered_diff.encode("utf-8"))
    if max_diff_size is not None and diff_size > max_diff_size:
        raise DiffCollectionError(
            f"수집된 diff 크기가 제한을 초과했습니다. (size={diff_size} bytes, limit={max_diff_size} bytes)"
        )

    return CollectedDiff(
        source=source,
        diff_text=filtered_diff,
    )


_DIFF_HEADER_RE = re.compile(r"^diff --git a/(.+) b/(.+)$")


def _apply_excludes(diff_text: str, patterns: list[str]) -> str:
    if not patterns:
        return diff_text

    blocks = _split_diff_blocks(diff_text)
    if not blocks:
        return diff_text

    kept_blocks: list[str] = []
    for block in blocks:
        path = _path_from_block(block)
        if path is None or not any(
            fnmatch.fnmatch(path, pattern) for pattern in patterns
        ):
            kept_blocks.append(block)
    return "".join(kept_blocks)


def _split_diff_blocks(diff_text: str) -> list[str]:
    lines = diff_text.splitlines(keepends=True)
    blocks: list[str] = []
    current: list[str] = []
    saw_header = False

    for line in lines:
        if line.startswith("diff --git "):
            saw_header = True
            if current:
                blocks.append("".join(current))
                current = []
        current.append(line)

    if current:
        blocks.append("".join(current))

    if not saw_header:
        return []
    return blocks


def _path_from_block(block: str) -> str | None:
    first_line = block.splitlines()[0] if block else ""
    match = _DIFF_HEADER_RE.match(first_line)
    if match is None:
        return None

    old_path, new_path = match.group(1), match.group(2)
    if new_path == "/dev/null":
        return old_path
    return new_path
