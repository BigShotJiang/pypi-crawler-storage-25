from __future__ import annotations

from dataclasses import dataclass

from acw.config import ResolvedGenerateSettings
from acw.diff_collector import CollectedDiff


class GenerateInputError(ValueError):
    pass


@dataclass(slots=True)
class GenerateInput:
    provider: str
    model: str
    profile: str | None
    language: str
    format: str
    base_url: str | None
    timeout_seconds: float
    key_env_var: str | None
    api_key: str | None
    prompt_name: str | None
    prompt_file: str | None
    prompt_text: str
    print_prompt: bool
    candidate_count: int
    exclude_patterns: tuple[str, ...]
    max_diff_size: int
    diff_source: str
    diff_text: str


def build_generate_input(
    *,
    resolved: ResolvedGenerateSettings,
    collected: CollectedDiff,
    prompt_name: str | None,
    prompt_file: str | None,
    prompt_text: str,
    print_prompt: bool,
    candidate_count: int,
    exclude_patterns: list[str] | None,
    max_diff_size: int,
) -> GenerateInput:
    if candidate_count <= 0:
        raise GenerateInputError("`--generate`는 1 이상의 정수여야 합니다.")
    if max_diff_size <= 0:
        raise GenerateInputError("`--max-diff-size`는 1 이상의 정수여야 합니다.")

    profile = resolved.profile.strip() if resolved.profile is not None else None
    normalized_profile = profile if profile else None
    normalized_prompt_name = _normalize_optional(prompt_name)
    normalized_prompt_file = _normalize_optional(prompt_file)
    normalized_prompt_text = prompt_text.strip()
    if not normalized_prompt_text:
        raise GenerateInputError("최종 프롬프트가 비어 있습니다.")
    normalized_excludes = tuple(
        pattern.strip() for pattern in (exclude_patterns or []) if pattern.strip()
    )

    return GenerateInput(
        provider=resolved.provider,
        model=resolved.model,
        profile=normalized_profile,
        language=resolved.language,
        format=resolved.format,
        base_url=resolved.base_url,
        timeout_seconds=resolved.timeout_seconds,
        key_env_var=resolved.key_env_var,
        api_key=resolved.api_key,
        prompt_name=normalized_prompt_name,
        prompt_file=normalized_prompt_file,
        prompt_text=normalized_prompt_text,
        print_prompt=print_prompt,
        candidate_count=candidate_count,
        exclude_patterns=normalized_excludes,
        max_diff_size=max_diff_size,
        diff_source=collected.source,
        diff_text=collected.diff_text,
    )


def _normalize_optional(value: str | None) -> str | None:
    if value is None:
        return None
    stripped = value.strip()
    return stripped if stripped else None
