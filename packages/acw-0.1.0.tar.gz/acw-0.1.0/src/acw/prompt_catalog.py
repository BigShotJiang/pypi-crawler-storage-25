from __future__ import annotations

from typing import Literal

PromptLanguage = Literal["ko", "en"]
SUPPORTED_PROMPT_LANGUAGES: tuple[PromptLanguage, ...] = ("ko", "en")
BUILTIN_PROMPT_NAMES = ("default", "plain", "conventional", "gitmoji")
FORMAT_PROMPT_NAMES = ("plain", "conventional", "gitmoji")

PROMPT_INTRO: dict[PromptLanguage, str] = {
    "en": (
        "You are an expert engineer writing git commit messages.\n"
        "Given the diff, produce a single high-quality commit message.\n"
    ),
    "ko": (
        "당신은 git commit 메시지를 작성하는 숙련된 엔지니어입니다.\n"
        "주어진 diff를 바탕으로, 품질 높은 단일 커밋 메시지를 생성하세요.\n"
    ),
}

PROMPT_OUTRO: dict[PromptLanguage, str] = {
    "en": "Keep it specific, concise, and grounded in changed behavior.\n",
    "ko": "변경된 동작에 근거해 구체적이고 간결하게 작성하세요.\n",
}

DEFAULT_PROMPT_TEMPLATES: dict[PromptLanguage, str] = {
    "en": f"{PROMPT_INTRO['en']}{PROMPT_OUTRO['en']}",
    "ko": f"{PROMPT_INTRO['ko']}{PROMPT_OUTRO['ko']}",
}

CONVENTIONAL_BASE_TEMPLATE = (
    "- Avoid overly verbose descriptions or unnecessary details.\n"
    "- Keep the message as short as possible.\n"
    "- Use the Conventional Commit format.\n"
    "- Use bullet points for multiple changes.\n"
)

CONVENTIONAL_ANSWER_LANGUAGE: dict[PromptLanguage, str] = {
    "en": "English",
    "ko": "Korean",
}

CONVENTIONAL_TEMPLATES: dict[PromptLanguage, str] = {
    language: (
        f"{CONVENTIONAL_BASE_TEMPLATE}"
        f"- Answer in {CONVENTIONAL_ANSWER_LANGUAGE[language]}.\n"
    )
    for language in SUPPORTED_PROMPT_LANGUAGES
}

FORMAT_INSTRUCTIONS: dict[PromptLanguage, dict[str, str]] = {
    "en": {
        "plain": "Output format: plain one-line commit subject (no prefix).",
        "gitmoji": "Output format: gitmoji + short subject (e.g. :sparkles: add ...).",
    },
    "ko": {
        "plain": "출력 형식: prefix 없는 한 줄 커밋 제목",
        "gitmoji": "출력 형식: gitmoji + 짧은 제목 (예: :sparkles: ...)",
    },
}


def make_prompt_stem(prompt_name: str, *, language: str | None) -> str:
    if language is None:
        return prompt_name
    return f"{prompt_name}.{language}"


def split_prompt_stem(stem: str) -> tuple[str, PromptLanguage | None]:
    for language in SUPPORTED_PROMPT_LANGUAGES:
        suffix = f".{language}"
        if stem.endswith(suffix):
            return stem[: -len(suffix)], language
    return stem, None


def is_builtin_prompt_stem(stem: str) -> bool:
    base_name, _ = split_prompt_stem(stem)
    return base_name in BUILTIN_PROMPT_NAMES


def build_builtin_prompt_templates() -> dict[str, str]:
    templates: dict[str, str] = {}
    for language in SUPPORTED_PROMPT_LANGUAGES:
        templates[make_prompt_stem("default", language=language)] = (
            _default_prompt_template_by_language(language)
        )
        for format_name in FORMAT_PROMPT_NAMES:
            templates[make_prompt_stem(format_name, language=language)] = (
                _format_prompt_template(format_name, language)
            )
    return templates


def _default_prompt_template_by_language(language: PromptLanguage) -> str:
    return DEFAULT_PROMPT_TEMPLATES[language]


def _format_prompt_template(format_name: str, language: PromptLanguage) -> str:
    if format_name == "conventional":
        return CONVENTIONAL_TEMPLATES[language]

    format_instruction = FORMAT_INSTRUCTIONS[language][format_name]
    return f"{PROMPT_INTRO[language]}{format_instruction}\n{PROMPT_OUTRO[language]}"
