from __future__ import annotations

import os
from collections.abc import MutableMapping
from typing import cast

import questionary
from questionary import Choice

from acw.config import (
    ConfigLayout,
    load_config_settings,
    load_provider_env_map,
    resolve_provider_timeout,
    resolve_provider_base_url,
    save_config_settings,
)
from acw.doctor import LOCAL_PROVIDERS, diagnose_local_provider
from acw.models import get_provider_model_choices

SUPPORTED_PROVIDERS = ["openai", "anthropic", "google", "ollama", "lmstudio"]
PROVIDER_DESCRIPTIONS: dict[str, str] = {
    "openai": "OpenAI API",
    "anthropic": "Anthropic Claude API",
    "google": "Google Gemini API",
    "ollama": "로컬 Ollama 서버 (기본: http://localhost:11434)",
    "lmstudio": "로컬 LM Studio 서버 (기본: http://localhost:1234/v1)",
}


def run_onboarding_wizard(
    layout: ConfigLayout,
    *,
    environ: MutableMapping[str, str] | None = None,
) -> bool:
    env: MutableMapping[str, str]
    if environ is None:
        env = os.environ
    else:
        env = environ
    config = load_config_settings(layout)
    provider_env_map = load_provider_env_map(layout)

    selected_provider = _ask_provider(configured_provider=config.provider)
    if selected_provider is None:
        return False

    model = _ask_model(layout=layout, configured_provider=selected_provider)
    if model is None:
        return False

    key_env_default = provider_env_map.get(
        selected_provider, f"{selected_provider.upper()}_API_KEY"
    )
    key_env_var = key_env_default.strip()
    api_key: str | None = None
    used_existing_env = False
    should_save_provider_env = True
    default_env_rejected = False

    default_env_value = env.get(key_env_var, "").strip()
    if default_env_value:
        use_default_env: bool | None = cast(
            bool | None,
            questionary.confirm(
                f"현재 환경변수 {key_env_var} 값이 감지되었습니다. 이 값을 사용할까요?",
                default=True,
                auto_enter=False,
            ).ask(),
        )
        if use_default_env is None:
            return False
        if use_default_env:
            api_key = default_env_value
            used_existing_env = True
            should_save_provider_env = False
        else:
            default_env_rejected = True

    if api_key is None:
        asked_key_env_var: str | None = cast(
            str | None,
            questionary.text(
                f"API key 환경변수 이름을 입력하세요. (예: {key_env_default})",
            ).ask(),
        )
        if asked_key_env_var is None:
            return False
        key_env_var = asked_key_env_var.strip()
        api_key, used_existing_env = _ask_api_key_value(
            env=env,
            key_env_var=key_env_var,
            confirm_existing=not (
                default_env_rejected and key_env_var == key_env_default.strip()
            ),
        )
        if api_key is None:
            return False

    language: str | None = cast(
        str | None,
        questionary.select(
            "출력 언어 기본값을 선택하세요.",
            choices=["ko", "en"],
        ).ask(),
    )
    if language is None:
        return False

    format_name: str | None = cast(
        str | None,
        questionary.select(
            "커밋 메시지 포맷 기본값을 선택하세요.",
            choices=["plain", "conventional", "gitmoji"],
        ).ask(),
    )
    if format_name is None:
        return False

    timeout_seconds = _ask_timeout_seconds(
        layout=layout,
        provider=selected_provider,
    )
    if timeout_seconds is None:
        return False

    provider_env_to_save: dict[str, str] = dict(provider_env_map)
    if should_save_provider_env:
        provider_env_to_save[selected_provider] = key_env_var
    save_config_settings(
        layout,
        provider=selected_provider,
        model=model.strip(),
        profile=config.profile,
        language=language,
        format_name=format_name,
        provider_env_map=provider_env_to_save,
        provider_timeout_map={selected_provider: timeout_seconds},
    )

    if api_key.strip():
        env[key_env_var] = api_key.strip()
        if used_existing_env:
            print(f"현재 환경변수 {key_env_var} 값을 사용합니다.")
        else:
            print(f"현재 실행 세션에만 {key_env_var} 값을 적용했습니다.")
            print("영구 저장이 필요하면 셸 설정 파일에 export를 추가하세요.")

    print(f"초기 설정을 저장했습니다: {layout.config_file}")
    return True


def _ask_model(*, layout: ConfigLayout, configured_provider: str) -> str | None:
    discovered_models: list[str] = []
    normalized_provider = configured_provider.strip().lower()
    if normalized_provider in LOCAL_PROVIDERS:
        discovered_models = _discover_local_models(
            layout=layout,
            provider=normalized_provider,
        )

    if discovered_models:
        selected_discovered: str | None = cast(
            str | None,
            questionary.select(
                "서버에서 발견한 model을 선택하세요.",
                choices=[*discovered_models, "직접 입력"],
            ).ask(),
        )
        if selected_discovered is None:
            return None
        if selected_discovered != "직접 입력":
            return selected_discovered

    model_choices = get_provider_model_choices(configured_provider)
    if model_choices:
        selected: str | None = cast(
            str | None,
            questionary.select(
                "기본 model을 선택하세요.",
                choices=[*model_choices, "직접 입력"],
            ).ask(),
        )
        if selected is None:
            return None
        if selected != "직접 입력":
            return selected

    model: str | None = cast(
        str | None,
        questionary.text(
            "기본 model을 입력하세요.",
        ).ask(),
    )
    if model is None:
        return None
    return model


def _discover_local_models(*, layout: ConfigLayout, provider: str) -> list[str]:
    base_url = resolve_provider_base_url(layout, provider)
    if base_url is None:
        return []

    should_discover: bool | None = cast(
        bool | None,
        questionary.confirm(
            (
                "로컬 서버에서 모델 목록을 자동 탐색할까요? "
                f"(provider={provider}, base_url={base_url})"
            ),
            default=True,
            auto_enter=False,
        ).ask(),
    )
    if should_discover is None:
        return []
    if not should_discover:
        return []

    result = diagnose_local_provider(
        provider=provider,
        base_url=base_url,
        configured_model="",
        timeout_seconds=resolve_provider_timeout(layout, provider),
    )
    if not result.reachable:
        print(
            "모델 자동 탐색에 실패했습니다. "
            f"({result.error_message or 'unknown error'}) 수동 입력으로 진행합니다."
        )
        return []
    if not result.models:
        print(
            "서버에 등록된 모델을 찾지 못했습니다. "
            "수동 입력으로 진행합니다."
        )
        return []
    return result.models


def _ask_timeout_seconds(*, layout: ConfigLayout, provider: str) -> float | None:
    default_timeout = resolve_provider_timeout(layout, provider)
    while True:
        answered: str | None = cast(
            str | None,
            questionary.text(
                "요청 타임아웃(초)을 입력하세요.",
                default=f"{default_timeout:g}",
            ).ask(),
        )
        if answered is None:
            return None
        normalized = answered.strip()
        if not normalized:
            return default_timeout
        try:
            timeout_seconds = float(normalized)
        except ValueError:
            print("입력 오류: 타임아웃은 숫자로 입력하세요. (예: 30)")
            continue
        if timeout_seconds <= 0:
            print("입력 오류: 타임아웃은 0보다 커야 합니다.")
            continue
        return timeout_seconds


def _ask_provider(*, configured_provider: str | None) -> str | None:
    provider_choices = list(SUPPORTED_PROVIDERS)
    if configured_provider and configured_provider not in provider_choices:
        provider_choices.insert(0, configured_provider)
    choice_items: list[Choice | str] = [
        Choice(
            title=(
                f"{provider} ({PROVIDER_DESCRIPTIONS[provider]})"
                if provider in PROVIDER_DESCRIPTIONS
                else provider
            ),
            value=provider,
        )
        for provider in provider_choices
    ]
    choice_items.append("직접 입력")

    selected: str | None = cast(
        str | None,
        questionary.select(
            "AI provider를 선택하세요.",
            choices=choice_items,
        ).ask(),
    )
    if selected is None:
        return None
    if selected != "직접 입력":
        return selected

    provider: str | None = cast(
        str | None,
        questionary.text(
            "AI provider를 입력하세요. (예: openrouter, xai, groq)",
        ).ask(),
    )
    if provider is None:
        return None
    return provider.strip()


def _ask_api_key_value(
    *, env: MutableMapping[str, str], key_env_var: str, confirm_existing: bool = True
) -> tuple[str | None, bool]:
    existing_env_value = env.get(key_env_var, "").strip() if confirm_existing else ""
    if existing_env_value:
        use_existing: bool | None = cast(
            bool | None,
            questionary.confirm(
                f"현재 환경변수 {key_env_var} 값이 감지되었습니다. 이 값을 사용할까요?",
                default=True,
                auto_enter=False,
            ).ask(),
        )
        if use_existing is None:
            return None, False
        if use_existing:
            return existing_env_value, True

    api_key: str | None = cast(
        str | None,
        questionary.password(
            f"{key_env_var} 값을 입력하세요. (비워두면 건너뜀)",
        ).ask(),
    )
    if api_key is None:
        return None, False
    return api_key, False
