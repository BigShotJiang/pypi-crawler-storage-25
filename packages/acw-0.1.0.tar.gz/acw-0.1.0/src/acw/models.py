from __future__ import annotations

from enum import StrEnum


class OpenAIModel(StrEnum):
    GPT_4_1_MINI = "gpt-4.1-mini"
    GPT_4_1 = "gpt-4.1"
    GPT_4O_MINI = "gpt-4o-mini"
    GPT_4O = "gpt-4o"
    GPT_5_MINI = "gpt-5-mini"
    GPT_5 = "gpt-5"


class AnthropicModel(StrEnum):
    CLAUDE_OPUS_4_6 = "claude-opus-4-6-20260205"
    CLAUDE_SONNET_4_6 = "claude-sonnet-4-6"
    CLAUDE_OPUS_4_5 = "claude-opus-4-5-20251101"
    CLAUDE_SONNET_4_5 = "claude-sonnet-4-5-20250929"


class GeminiModel(StrEnum):
    GEMINI_2_0_FLASH_LITE_PREVIEW_02_05 = "gemini/gemini-2.0-flash-lite-preview-02-05"
    GEMINI_2_5_FLASH_PREVIEW_09_2025 = "gemini/gemini-2.5-flash-preview-09-2025"
    GEMINI_2_5_FLASH_LITE_PREVIEW_09_2025 = (
        "gemini/gemini-2.5-flash-lite-preview-09-2025"
    )
    GEMINI_3_1_FLASH_LITE_PREVIEW = "gemini/gemini-3.1-flash-lite-preview"
    GEMINI_FLASH_LATEST = "gemini/gemini-flash-latest"
    GEMINI_FLASH_LITE_LATEST = "gemini/gemini-flash-lite-latest"


PROVIDER_MODEL_ENUMS: dict[str, type[StrEnum]] = {
    "openai": OpenAIModel,
    "anthropic": AnthropicModel,
    "google": GeminiModel,
}


def get_provider_model_choices(provider: str) -> list[str]:
    enum_values = _enum_model_values(provider)
    return enum_values


def _enum_model_values(provider: str) -> list[str]:
    model_enum = PROVIDER_MODEL_ENUMS.get(provider)
    if model_enum is None:
        return []
    return [item.value for item in model_enum]
