from __future__ import annotations

__all__ = ['get_stream_info', 'get_segments']

from .streams import get_stream_info
from .streams import get_segments
