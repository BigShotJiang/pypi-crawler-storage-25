from __future__ import annotations

__all__ = [
    'login', 'logout', 'server_connection', 'list_datasets', 'datasets', 'samplers',
]

import logging
from importlib.metadata import version

from . import datasets
from . import samplers
from tempora.utils.server import login
from tempora.utils.server import logout
from tempora.utils.server import list_datasets
from tempora.utils.server import server_connection


__version__ = version('tempora-ai')
logging.getLogger('tempora').addHandler(logging.NullHandler())
