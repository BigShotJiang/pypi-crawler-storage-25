"""InfluxDB connection helpers."""
from __future__ import annotations

import dataclasses as dc
import os
from typing import Any
from typing import ClassVar

import pydantic.dataclasses as pydc
from pydantic import validate_call

from .base import DatasetBase
from .filter import FilterMixin
from tempora.utils.dataclass import pydc_config
from tempora.utils.db import close_db_connection
from tempora.utils.db import ConnectionParams
from tempora.utils.db import open_db_connection
from tempora.utils.db import resolve_connection_params
from tempora.utils.exceptions import TemporaClientError


def _resolve_influxdb_timeout(timeout: int | None) -> int | None:
    if timeout is not None:
        return timeout

    env_value = os.getenv('INFLUXDB_TIMEOUT')
    if env_value is None:
        return None

    env_value = env_value.strip()
    if not env_value:
        return None

    try:
        return int(env_value)
    except ValueError as e:
        raise TemporaClientError(
            'Environment variable INFLUXDB_TIMEOUT must be an integer.',
        ) from e


@dc.dataclass(frozen=True)
class _InfluxDBDatasetArgs:
    database: str
    table: str


@pydc.dataclass(frozen=True, eq=False, config=pydc_config)
class InfluxDBDataset(DatasetBase, _InfluxDBDatasetArgs):
    """Class representing an InfluxDB-backed dataset.

    Args:
        database: InfluxDB database name.
        table: Table name within the database.
    """
    filtered_dataset_cls: ClassVar[type[FilteredInfluxDBDataset]]

    def __post_init__(self, _op_dict: dict[str, Any] | None) -> None:
        self._validate_supported_features()
        super().__post_init__(_op_dict=_op_dict)

    def _validate_supported_features(self) -> None:
        if self.pivot is not None:
            raise TemporaClientError(
                'InfluxDB datasets do not currently support pivots.',
            )
        if self.materialize:
            raise TemporaClientError(
                'InfluxDB datasets do not currently support materialize=True.',
            )
        if self._join_data:
            raise TemporaClientError(
                'InfluxDB datasets do not currently support joins.',
            )


@pydc.dataclass(frozen=True, eq=False, config=pydc_config)
class FilteredInfluxDBDataset(FilterMixin, InfluxDBDataset):
    """Class representing a filtered InfluxDB-based dataset."""

    def __post_init__(self, _op_dict: dict[str, Any] | None) -> None:
        super().__post_init__(_op_dict=_op_dict)


InfluxDBDataset.filtered_dataset_cls = FilteredInfluxDBDataset


@validate_call
def connect_influxdb(
    host: str | None = None,
    token: str | None = None,
    database: str | None = None,
    timeout: int | None = None,
) -> None:
    """Open a connection to InfluxDB.

    Args:
        host: InfluxDB server host. If omitted, this must be specified using the
            INFLUXDB_HOST env var.
        token: InfluxDB authentication token. If omitted, this must be specified using
            the INFLUXDB_TOKEN env var.
        database: InfluxDB database name. If omitted, this must be specified using the
            INFLUXDB_DATABASE env var.
        timeout: Optional request timeout. If omitted, uses INFLUXDB_TIMEOUT when set.

    Returns:
        None
    """
    params = _get_influxdb_connection_params(
        host=host, token=token, database=database, timeout=timeout,
    )
    open_db_connection(dbms_name='InfluxDB', params=params)
    return None


def _get_influxdb_connection_params(
    host: str | None = None,
    token: str | None = None,
    database: str | None = None,
    timeout: int | None = None,
) -> ConnectionParams:
    params = resolve_connection_params(
        args={'host': host, 'token': token, 'database': database},
        env_vars={
            'host': 'INFLUXDB_HOST',
            'token': 'INFLUXDB_TOKEN',
            'database': 'INFLUXDB_DATABASE',
        },
        required_args={'host', 'token', 'database'},
    )
    resolved_timeout = _resolve_influxdb_timeout(timeout)
    if resolved_timeout is not None:
        params['timeout'] = resolved_timeout
    return params


def disconnect_influxdb() -> None:
    """Close the currently open InfluxDB connection."""
    return close_db_connection(dbms_name='InfluxDB')
