"""MSSQL connection helpers."""
from __future__ import annotations

import dataclasses as dc
from typing import Any
from typing import ClassVar

import pydantic.dataclasses as pydc
from pydantic import validate_call

from .base import DatasetBase
from .filter import FilterMixin
from tempora.utils.dataclass import pydc_config
from tempora.utils.db import _SQLDatasetArgs
from tempora.utils.db import close_db_connection
from tempora.utils.db import ConnectionParams
from tempora.utils.db import open_db_connection
from tempora.utils.db import resolve_connection_params


@dc.dataclass(frozen=True)
class _MSSQLDatasetArgs(_SQLDatasetArgs):
    ...


@pydc.dataclass(frozen=True, eq=False, config=pydc_config)
class MSSQLDataset(DatasetBase, _MSSQLDatasetArgs):
    """Class representing an MSSQL-backed dataset.

    Args:
        database: MSSQL database name.
        table: Table name within the database.
        schema: Optional schema name.
    """
    filtered_dataset_cls: ClassVar[type[FilteredMSSQLDataset]]

    def __post_init__(self, _op_dict: dict[str, Any] | None) -> None:
        super().__post_init__(_op_dict=_op_dict)


@pydc.dataclass(frozen=True, eq=False, config=pydc_config)
class FilteredMSSQLDataset(FilterMixin, MSSQLDataset):
    """Class representing a filtered MSSQL-based dataset."""

    def __post_init__(self, _op_dict: dict[str, Any] | None) -> None:
        super().__post_init__(_op_dict=_op_dict)


MSSQLDataset.filtered_dataset_cls = FilteredMSSQLDataset


@validate_call
def connect_mssql(
    host: str | None = None,
    user: str | None = None,
    password: str | None = None,
    port: str | None = None,
    instance: str | None = None,
) -> None:
    """Open a connection to MSSQL.

    Args:
        host: MSSQL server host. If omitted, this must be specified using the
            MSSQL_HOST env var.
        user: Username for MSSQL authentication. If omitted, this must be specified
            using the MSSQL_USER env var.
        password: Password for MSSQL authentication. If omitted, this must be
            specified using the MSSQL_PASSWORD env var.
        port: Server port. If omitted, uses MSSQL_PORT if set; otherwise defaults to
            '1433'.
        instance: Optional SQL Server instance name. If omitted, uses
            MSSQL_INSTANCE.

    Returns:
        None
    """
    params = _get_mssql_connection_params(
        host=host,
        user=user,
        password=password,
        port=port,
        instance=instance,
    )
    open_db_connection(dbms_name='MSSQL', params=params)
    return None


def _get_mssql_connection_params(
    host: str | None = None,
    user: str | None = None,
    password: str | None = None,
    port: str | None = None,
    instance: str | None = None,
) -> ConnectionParams:
    params = resolve_connection_params(
        args={
            'host': host,
            'user': user,
            'password': password,
            'port': port,
            'instance': instance,
        },
        env_vars={
            'host': 'MSSQL_HOST',
            'user': 'MSSQL_USER',
            'password': 'MSSQL_PASSWORD',
            'port': 'MSSQL_PORT',
            'instance': 'MSSQL_INSTANCE',
        },
        required_args={'host', 'user', 'password'},
    )
    if not params.get('port'):
        params['port'] = '1433'
    return params


def disconnect_mssql() -> None:
    """Close the currently open MSSQL connection."""
    return close_db_connection(dbms_name='MSSQL')
