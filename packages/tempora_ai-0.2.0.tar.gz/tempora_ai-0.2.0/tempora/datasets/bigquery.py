"""BigQuery connection helpers."""
from __future__ import annotations

import dataclasses as dc
from typing import Any
from typing import ClassVar

import pydantic.dataclasses as pydc
from pydantic import validate_call

from .base import DatasetBase
from .filter import FilterMixin
from tempora.utils.dataclass import pydc_config
from tempora.utils.db import close_db_connection
from tempora.utils.db import ConnectionParams
from tempora.utils.db import open_db_connection
from tempora.utils.db import resolve_connection_params


@dc.dataclass(frozen=True)
class _BigQueryDatasetArgs:
    dataset: str
    table: str
    project: str | None = None


@pydc.dataclass(frozen=True, eq=False, config=pydc_config)
class BigQueryDataset(DatasetBase, _BigQueryDatasetArgs):
    """Class representing a BigQuery-backed dataset.

    Args:
        dataset: BigQuery dataset name.
        table: Table name within the dataset.
        project: Optional GCP project override. If omitted, the active BigQuery
            connection project is used.
    """
    filtered_dataset_cls: ClassVar[type[FilteredBigQueryDataset]]

    def __post_init__(self, _op_dict: dict[str, Any] | None) -> None:
        super().__post_init__(_op_dict=_op_dict)


@pydc.dataclass(frozen=True, eq=False, config=pydc_config)
class FilteredBigQueryDataset(FilterMixin, BigQueryDataset):
    """Class representing a filtered BigQuery-based dataset."""

    def __post_init__(self, _op_dict: dict[str, Any] | None) -> None:
        super().__post_init__(_op_dict=_op_dict)


BigQueryDataset.filtered_dataset_cls = FilteredBigQueryDataset


@validate_call
def connect_bigquery(
    project_id: str | None = None,
    dataset_id: str | None = None,
    host: str | None = None,
    port: str | None = None,
    service_account_json: str | None = None,
) -> None:
    """Open a connection to BigQuery.

    Args:
        project_id: Default GCP project for the connection. If omitted, this must be
            specified using the BIGQUERY_PROJECT_ID env var.
        dataset_id: Optional default BigQuery dataset for the connection. If omitted,
            uses BIGQUERY_DATASET_ID.
        host: Optional BigQuery API endpoint host. If omitted, uses BIGQUERY_HOST.
        port: Optional BigQuery API endpoint port. If omitted, uses BIGQUERY_PORT or
            defaults to '443'.
        service_account_json: Optional service account JSON string. If omitted, uses
            BIGQUERY_SERVICE_ACCOUNT_JSON or falls back to the server's Application
            Default Credentials.

    Returns:
        None
    """
    params = _get_bigquery_connection_params(
        project_id=project_id,
        dataset_id=dataset_id,
        host=host,
        port=port,
        service_account_json=service_account_json,
    )
    open_db_connection(dbms_name='BigQuery', params=params)
    return None


def _get_bigquery_connection_params(
    project_id: str | None = None,
    dataset_id: str | None = None,
    host: str | None = None,
    port: str | None = None,
    service_account_json: str | None = None,
) -> ConnectionParams:
    params = resolve_connection_params(
        args={
            'project_id': project_id,
            'dataset_id': dataset_id,
            'host': host,
            'port': port,
            'service_account_json': service_account_json,
        },
        env_vars={
            'project_id': 'BIGQUERY_PROJECT_ID',
            'dataset_id': 'BIGQUERY_DATASET_ID',
            'host': 'BIGQUERY_HOST',
            'port': 'BIGQUERY_PORT',
            'service_account_json': 'BIGQUERY_SERVICE_ACCOUNT_JSON',
        },
        required_args={'project_id'},
    )
    if not params.get('port'):
        params['port'] = '443'
    return params


def disconnect_bigquery() -> None:
    """Close the currently open BigQuery connection."""
    return close_db_connection(dbms_name='BigQuery')
