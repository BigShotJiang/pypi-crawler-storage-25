"""Teradata connection helpers."""
from __future__ import annotations

import dataclasses as dc
from typing import Any
from typing import ClassVar

import pydantic.dataclasses as pydc
from pydantic import validate_call

from .base import DatasetBase
from .filter import FilterMixin
from tempora.utils.dataclass import pydc_config
from tempora.utils.db import close_db_connection
from tempora.utils.db import ConnectionParams
from tempora.utils.db import open_db_connection
from tempora.utils.db import resolve_connection_params


@dc.dataclass(frozen=True)
class _TeradataDatasetArgs:
    database: str
    table: str


@pydc.dataclass(frozen=True, eq=False, config=pydc_config)
class TeradataDataset(DatasetBase, _TeradataDatasetArgs):
    """Class representing a Teradata-backed dataset.

    Args:
        database: Teradata database name.
        table: Table name within the database.
    """
    filtered_dataset_cls: ClassVar[type[FilteredTeradataDataset]]

    def __post_init__(self, _op_dict: dict[str, Any] | None) -> None:
        super().__post_init__(_op_dict=_op_dict)


@pydc.dataclass(frozen=True, eq=False, config=pydc_config)
class FilteredTeradataDataset(FilterMixin, TeradataDataset):
    """Class representing a filtered Teradata-based dataset."""

    def __post_init__(self, _op_dict: dict[str, Any] | None) -> None:
        super().__post_init__(_op_dict=_op_dict)


TeradataDataset.filtered_dataset_cls = FilteredTeradataDataset


@validate_call
def connect_teradata(
    host: str | None = None,
    user: str | None = None,
    password: str | None = None,
    port: str | None = None,
) -> None:
    """Open a connection to Teradata.

    Args:
        host: Teradata server host. If omitted, this must be specified using the
            TERADATA_HOST env var.
        user: Teradata username. If omitted, this must be specified using the
            TERADATA_USER env var.
        password: Teradata password. If omitted, this must be specified using the
            TERADATA_PASSWORD env var.
        port: Server port. If omitted, uses TERADATA_PORT if set; otherwise defaults
            to '1025'.

    Returns:
        None
    """
    params = _get_teradata_connection_params(
        host=host, user=user, password=password, port=port,
    )
    open_db_connection(dbms_name='Teradata', params=params)
    return None


def _get_teradata_connection_params(
    host: str | None = None,
    user: str | None = None,
    password: str | None = None,
    port: str | None = None,
) -> ConnectionParams:
    params = resolve_connection_params(
        args={'host': host, 'user': user, 'password': password, 'port': port},
        env_vars={
            'host': 'TERADATA_HOST',
            'user': 'TERADATA_USER',
            'password': 'TERADATA_PASSWORD',
            'port': 'TERADATA_PORT',
        },
        required_args={'host', 'user', 'password'},
    )
    if not params.get('port'):
        params['port'] = '1025'
    return params


def disconnect_teradata() -> None:
    """Close the currently open Teradata connection."""
    return close_db_connection(dbms_name='Teradata')
