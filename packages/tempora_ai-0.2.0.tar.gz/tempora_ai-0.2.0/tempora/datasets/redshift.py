"""Redshift connection helpers."""
from __future__ import annotations

import dataclasses as dc
from typing import Any
from typing import ClassVar
from typing import Literal
from typing import Union

import pydantic.dataclasses as pydc
from pydantic import validate_call

from .base import DatasetBase
from .filter import FilterMixin
from tempora.utils.dataclass import pydc_config
from tempora.utils.db import close_db_connection
from tempora.utils.db import ConnectionParams
from tempora.utils.db import load_aws_profile
from tempora.utils.db import open_db_connection
from tempora.utils.db import resolve_connection_params
from tempora.utils.exceptions import TemporaClientError

RedshiftClusterType = Literal['redshift', 'redshift-iam', 'redshift-serverless']
RedshiftConfigValue = Union[bool, int, str]


@dc.dataclass(frozen=True)
class _RedshiftDatasetArgs:
    table: str
    schema: str | None = None


@pydc.dataclass(frozen=True, eq=False, config=pydc_config)
class RedshiftDataset(DatasetBase, _RedshiftDatasetArgs):
    """Class representing a Redshift-backed dataset.

    Args:
        table: Redshift table name.
        schema: Optional schema name.
    """
    filtered_dataset_cls: ClassVar[type[FilteredRedshiftDataset]]

    def __post_init__(self, _op_dict: dict[str, Any] | None) -> None:
        super().__post_init__(_op_dict=_op_dict)


@pydc.dataclass(frozen=True, eq=False, config=pydc_config)
class FilteredRedshiftDataset(FilterMixin, RedshiftDataset):
    """Class representing a filtered Redshift-based dataset."""

    def __post_init__(self, _op_dict: dict[str, Any] | None) -> None:
        super().__post_init__(_op_dict=_op_dict)


RedshiftDataset.filtered_dataset_cls = FilteredRedshiftDataset


@validate_call
def connect_redshift(
    cluster_type: RedshiftClusterType = 'redshift',
    host: str | None = None,
    user: str | None = None,
    password: str | None = None,
    database: str | None = None,
    port: str | None = None,
    cluster_identifier: str | None = None,
    workgroup_name: str | None = None,
    profile: str | None = None,
    aws_region: str | None = None,
    aws_access_key_id: str | None = None,
    aws_secret_access_key: str | None = None,
    aws_session_token: str | None = None,
    sslmode: str | None = None,
    config_props: dict[str, RedshiftConfigValue] | None = None,
) -> None:
    """Open a connection to Redshift.

    Args:
        cluster_type: Redshift connection mode. Use `'redshift'` for provisioned
            clusters with direct credentials, `'redshift-iam'` for provisioned
            clusters with IAM auth, or `'redshift-serverless'` for Redshift
            Serverless. If omitted, uses REDSHIFT_CLUSTER_TYPE or defaults to
            `'redshift'`.
        host: Redshift cluster host. If omitted, this must be specified using the
            REDSHIFT_HOST env var when required by the selected cluster_type.
        user: Username for Redshift authentication. If omitted, this must be
            specified using the REDSHIFT_USER env var when required by the selected
            cluster_type.
        password: Password for Redshift authentication. If omitted, this must be
            specified using the REDSHIFT_PASSWORD env var when required by the
            selected cluster_type.
        database: Redshift database name. If omitted, this must be specified using
            the REDSHIFT_DATABASE env var.
        port: Cluster port. If omitted, uses REDSHIFT_PORT if set; otherwise defaults
            to '5439'.
        cluster_identifier: Redshift provisioned cluster identifier. Required for IAM
            auth. If omitted, uses REDSHIFT_CLUSTER_IDENTIFIER.
        workgroup_name: Redshift Serverless workgroup name. Required for serverless
            connections. If omitted, uses REDSHIFT_WORKGROUP_NAME.
        profile: AWS shared config / credentials profile name. If omitted, no local
            AWS profile is loaded.
        aws_region: Optional AWS region. If omitted, uses AWS_REGION or
            AWS_DEFAULT_REGION.
        aws_access_key_id: Optional AWS access key ID. If omitted, uses
            AWS_ACCESS_KEY_ID.
        aws_secret_access_key: Optional AWS secret access key. If omitted, uses
            AWS_SECRET_ACCESS_KEY.
        aws_session_token: Optional AWS session token. If omitted, uses
            AWS_SESSION_TOKEN.
        sslmode: Optional Redshift / PostgreSQL SSL mode. If omitted, uses
            REDSHIFT_SSLMODE.
        config_props: Optional additional Redshift JDBC-style configuration
            properties. Keys must be strings and values must be bool, int, or str.

    Returns:
        None
    """
    params = _get_redshift_connection_params(
        cluster_type=cluster_type,
        host=host,
        user=user,
        password=password,
        database=database,
        port=port,
        cluster_identifier=cluster_identifier,
        workgroup_name=workgroup_name,
        profile=profile,
        aws_region=aws_region,
        aws_access_key_id=aws_access_key_id,
        aws_secret_access_key=aws_secret_access_key,
        aws_session_token=aws_session_token,
        sslmode=sslmode,
        config_props=config_props,
    )
    open_db_connection(dbms_name='Redshift', params=params)
    return None


def _get_redshift_connection_params(
    cluster_type: RedshiftClusterType = 'redshift',
    host: str | None = None,
    user: str | None = None,
    password: str | None = None,
    database: str | None = None,
    port: str | None = None,
    cluster_identifier: str | None = None,
    workgroup_name: str | None = None,
    profile: str | None = None,
    aws_region: str | None = None,
    aws_access_key_id: str | None = None,
    aws_secret_access_key: str | None = None,
    aws_session_token: str | None = None,
    sslmode: str | None = None,
    config_props: dict[str, RedshiftConfigValue] | None = None,
) -> ConnectionParams:
    required_args = {'database'}
    if cluster_type == 'redshift':
        required_args.update({'host', 'user', 'password'})
    elif cluster_type == 'redshift-iam':
        required_args.update({'user', 'cluster_identifier'})
    elif cluster_type == 'redshift-serverless':
        required_args.add('workgroup_name')

    profile_params = load_aws_profile(profile_name=profile)
    params = resolve_connection_params(
        args={
            'cluster_type': cluster_type,
            'host': host,
            'user': user,
            'password': password,
            'database': database,
            'port': port,
            'cluster_identifier': cluster_identifier,
            'workgroup_name': workgroup_name,
            'aws_region': aws_region,
            'aws_access_key_id': aws_access_key_id,
            'aws_secret_access_key': aws_secret_access_key,
            'aws_session_token': aws_session_token,
            'sslmode': sslmode,
        },
        env_vars={
            'cluster_type': 'REDSHIFT_CLUSTER_TYPE',
            'host': 'REDSHIFT_HOST',
            'user': 'REDSHIFT_USER',
            'password': 'REDSHIFT_PASSWORD',
            'database': 'REDSHIFT_DATABASE',
            'port': 'REDSHIFT_PORT',
            'cluster_identifier': 'REDSHIFT_CLUSTER_IDENTIFIER',
            'workgroup_name': 'REDSHIFT_WORKGROUP_NAME',
            'aws_region': 'AWS_REGION',
            'aws_access_key_id': 'AWS_ACCESS_KEY_ID',
            'aws_secret_access_key': 'AWS_SECRET_ACCESS_KEY',
            'aws_session_token': 'AWS_SESSION_TOKEN',
            'sslmode': 'REDSHIFT_SSLMODE',
        },
        required_args=required_args,
        profile_params=profile_params,
    )
    params['config_props'] = config_props
    if params['cluster_type'] == 'redshift' and params.get('workgroup_name'):
        raise TemporaClientError(
            '"workgroup_name" is only valid for cluster_type="redshift-serverless".',
        )
    if params['cluster_type'] == 'redshift-serverless' and params.get('cluster_identifier'):  # noqa: E501
        raise TemporaClientError(
            '"cluster_identifier" is only valid for cluster_type="redshift-iam" or '
            '"redshift".',
        )
    if params['cluster_type'] == 'redshift-iam' and params.get('password'):
        raise TemporaClientError(
            '"password" is not used with cluster_type="redshift-iam".',
        )
    if params['cluster_type'] == 'redshift-serverless' and params.get('password'):
        raise TemporaClientError(
            '"password" is not used with cluster_type="redshift-serverless".',
        )
    if params['cluster_type'] == 'redshift-serverless' and params.get('host'):
        raise TemporaClientError(
            '"host" is not used with cluster_type="redshift-serverless".',
        )
    if not params.get('port'):
        params['port'] = '5439'
    return params


def disconnect_redshift() -> None:
    """Close the currently open Redshift connection."""
    return close_db_connection(dbms_name='Redshift')
