"""MySQL connection helpers."""
from __future__ import annotations

import dataclasses as dc
from typing import Any
from typing import ClassVar

import pydantic.dataclasses as pydc
from pydantic import validate_call

from .base import DatasetBase
from .filter import FilterMixin
from tempora.utils.dataclass import pydc_config
from tempora.utils.db import _SQLDatasetArgs
from tempora.utils.db import close_db_connection
from tempora.utils.db import ConnectionParams
from tempora.utils.db import open_db_connection
from tempora.utils.db import resolve_connection_params


@dc.dataclass(frozen=True)
class _MySQLDatasetArgs(_SQLDatasetArgs):
    ...


@pydc.dataclass(frozen=True, eq=False, config=pydc_config)
class MySQLDataset(DatasetBase, _MySQLDatasetArgs):
    """Class representing a MySQL-backed dataset.

    Args:
        database: MySQL database name.
        table: Table name within the database.
        schema: Optional schema name.
    """
    filtered_dataset_cls: ClassVar[type[FilteredMySQLDataset]]

    def __post_init__(self, _op_dict: dict[str, Any] | None) -> None:
        super().__post_init__(_op_dict=_op_dict)


@pydc.dataclass(frozen=True, eq=False, config=pydc_config)
class FilteredMySQLDataset(FilterMixin, MySQLDataset):
    """Class representing a filtered MySQL-based dataset."""

    def __post_init__(self, _op_dict: dict[str, Any] | None) -> None:
        super().__post_init__(_op_dict=_op_dict)


MySQLDataset.filtered_dataset_cls = FilteredMySQLDataset


@validate_call
def connect_mysql(
    host: str | None = None,
    user: str | None = None,
    password: str | None = None,
    port: str | None = None,
) -> None:
    """Open a connection to MySQL.

    Args:
        host: MySQL server host. If omitted, this must be specified using the
            MYSQL_HOST env var.
        user: Username for MySQL authentication. If omitted, this must be specified
            using the MYSQL_USER env var.
        password: Password for MySQL authentication. If omitted, this must be
            specified using the MYSQL_PASSWORD env var.
        port: Server port. If omitted, uses MYSQL_PORT if set; otherwise defaults to
            '3306'.

    Returns:
        None
    """
    params = _get_mysql_connection_params(
        host=host,
        user=user,
        password=password,
        port=port,
    )
    open_db_connection(dbms_name='MySQL', params=params)
    return None


def _get_mysql_connection_params(
    host: str | None = None,
    user: str | None = None,
    password: str | None = None,
    port: str | None = None,
) -> ConnectionParams:
    params = resolve_connection_params(
        args={
            'host': host,
            'user': user,
            'password': password,
            'port': port,
        },
        env_vars={
            'host': 'MYSQL_HOST',
            'user': 'MYSQL_USER',
            'password': 'MYSQL_PASSWORD',
            'port': 'MYSQL_PORT',
        },
        required_args={'host', 'user', 'password'},
    )
    if not params.get('port'):
        params['port'] = '3306'
    return params


def disconnect_mysql() -> None:
    """Close the currently open MySQL connection."""
    return close_db_connection(dbms_name='MySQL')
