"""ClickHouse connection helpers."""
from __future__ import annotations

import dataclasses as dc
from typing import Any
from typing import ClassVar

import pydantic.dataclasses as pydc
from pydantic import validate_call

from .base import DatasetBase
from .filter import FilterMixin
from tempora.utils.dataclass import pydc_config
from tempora.utils.db import close_db_connection
from tempora.utils.db import ConnectionParams
from tempora.utils.db import open_db_connection
from tempora.utils.db import resolve_connection_params


@dc.dataclass(frozen=True)
class _ClickhouseDatasetArgs:
    database: str
    table: str


@pydc.dataclass(frozen=True, eq=False, config=pydc_config)
class ClickhouseDataset(DatasetBase, _ClickhouseDatasetArgs):
    """Class representing a ClickHouse-backed dataset.

    Args:
        database: ClickHouse database name.
        table: Table name within the database.
    """
    filtered_dataset_cls: ClassVar[type[FilteredClickhouseDataset]]

    def __post_init__(self, _op_dict: dict[str, Any] | None) -> None:
        super().__post_init__(_op_dict=_op_dict)


@pydc.dataclass(frozen=True, eq=False, config=pydc_config)
class FilteredClickhouseDataset(FilterMixin, ClickhouseDataset):
    """Class representing a filtered ClickHouse-based dataset."""

    def __post_init__(self, _op_dict: dict[str, Any] | None) -> None:
        super().__post_init__(_op_dict=_op_dict)


ClickhouseDataset.filtered_dataset_cls = FilteredClickhouseDataset


@validate_call
def connect_clickhouse(
    host: str | None = None,
    user: str | None = None,
    password: str | None = None,
    port: str | None = None,
) -> None:
    """Open a connection to ClickHouse.

    Args:
        host: ClickHouse server host. If omitted, this must be specified using the
            CLICKHOUSE_HOST env var.
        user: Optional ClickHouse username. If omitted, uses CLICKHOUSE_USER.
        password: Optional ClickHouse password. If omitted, uses
            CLICKHOUSE_PASSWORD.
        port: Server port. If omitted, uses CLICKHOUSE_PORT if set; otherwise
            defaults to '8123'.

    Returns:
        None
    """
    params = _get_clickhouse_connection_params(
        host=host, user=user, password=password, port=port,
    )
    open_db_connection(dbms_name='ClickHouse', params=params)
    return None


def _get_clickhouse_connection_params(
    host: str | None = None,
    user: str | None = None,
    password: str | None = None,
    port: str | None = None,
) -> ConnectionParams:
    params = resolve_connection_params(
        args={'host': host, 'user': user, 'password': password, 'port': port},
        env_vars={
            'host': 'CLICKHOUSE_HOST',
            'user': 'CLICKHOUSE_USER',
            'password': 'CLICKHOUSE_PASSWORD',
            'port': 'CLICKHOUSE_PORT',
        },
        required_args={'host'},
    )
    if not params.get('port'):
        params['port'] = '8123'
    return params


def disconnect_clickhouse() -> None:
    """Close the currently open ClickHouse connection."""
    return close_db_connection(dbms_name='ClickHouse')
