"""Oracle connection helpers."""
from __future__ import annotations

import dataclasses as dc
from typing import Any
from typing import ClassVar

import pydantic.dataclasses as pydc
from pydantic import validate_call

from .base import DatasetBase
from .filter import FilterMixin
from tempora.utils.dataclass import pydc_config
from tempora.utils.db import _SQLDatasetArgs
from tempora.utils.db import close_db_connection
from tempora.utils.db import ConnectionParams
from tempora.utils.db import open_db_connection
from tempora.utils.db import resolve_connection_params


@dc.dataclass(frozen=True)
class _OracleDatasetArgs(_SQLDatasetArgs):
    ...


@pydc.dataclass(frozen=True, eq=False, config=pydc_config)
class OracleDataset(DatasetBase, _OracleDatasetArgs):
    """Class representing an Oracle-backed dataset.

    Args:
        database: Oracle database name.
        table: Table name within the database.
        schema: Optional schema name.
    """
    filtered_dataset_cls: ClassVar[type[FilteredOracleDataset]]

    def __post_init__(self, _op_dict: dict[str, Any] | None) -> None:
        super().__post_init__(_op_dict=_op_dict)


@pydc.dataclass(frozen=True, eq=False, config=pydc_config)
class FilteredOracleDataset(FilterMixin, OracleDataset):
    """Class representing a filtered Oracle-based dataset."""

    def __post_init__(self, _op_dict: dict[str, Any] | None) -> None:
        super().__post_init__(_op_dict=_op_dict)


OracleDataset.filtered_dataset_cls = FilteredOracleDataset


@validate_call
def connect_oracle(
    host: str | None = None,
    user: str | None = None,
    password: str | None = None,
    service_name: str | None = None,
    port: str | None = None,
) -> None:
    """Open a connection to Oracle.

    Args:
        host: Oracle server host. If omitted, this must be specified using the
            ORACLE_HOST env var.
        user: Oracle username. If omitted, this must be specified using the
            ORACLE_USER env var.
        password: Oracle password. If omitted, this must be specified using the
            ORACLE_PASSWORD env var.
        service_name: Oracle service name. If omitted, this must be specified using
            the ORACLE_SERVICE_NAME env var.
        port: Server port. If omitted, uses ORACLE_PORT if set; otherwise defaults to
            '1521'.

    Returns:
        None
    """
    params = _get_oracle_connection_params(
        host=host, user=user, password=password, service_name=service_name, port=port,
    )
    open_db_connection(dbms_name='Oracle', params=params)
    return None


def _get_oracle_connection_params(
    host: str | None = None,
    user: str | None = None,
    password: str | None = None,
    service_name: str | None = None,
    port: str | None = None,
) -> ConnectionParams:
    params = resolve_connection_params(
        args={
            'host': host,
            'user': user,
            'password': password,
            'service_name': service_name,
            'port': port,
        },
        env_vars={
            'host': 'ORACLE_HOST',
            'user': 'ORACLE_USER',
            'password': 'ORACLE_PASSWORD',
            'service_name': 'ORACLE_SERVICE_NAME',
            'port': 'ORACLE_PORT',
        },
        required_args={'host', 'user', 'password', 'service_name'},
    )
    if not params.get('port'):
        params['port'] = '1521'
    return params


def disconnect_oracle() -> None:
    """Close the currently open Oracle connection."""
    return close_db_connection(dbms_name='Oracle')
