from __future__ import annotations

from typing import Union

import numpy as np
from pandas.core.arrays.integer import Int64Dtype
from pandas.core.dtypes.dtypes import CategoricalDtype
from pandas.core.dtypes.dtypes import DatetimeTZDtype


PandasDtype = Union[CategoricalDtype, DatetimeTZDtype, Int64Dtype]
Dtype = Union[np.dtype, PandasDtype]
