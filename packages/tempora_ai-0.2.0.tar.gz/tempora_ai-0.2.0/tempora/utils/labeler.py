from __future__ import annotations

import dataclasses as dc
from typing import Literal


@dc.dataclass(frozen=True)
class Labeler:
    tag: str | None = None
    location: Literal['start', 'end'] = 'end'
    sep: str = '_'

    def label(self, idx: int, columns: list[str], n: int | None = None) -> str:
        k = n if n is not None else ''
        if self.tag:
            if self.location == 'start':
                return f'{self.tag}{k}{self.sep}{columns[idx]}'
            else:
                # Default to appending the tag
                return f'{columns[idx]}{self.sep}{self.tag}{k}'
        else:
            return f'{columns[idx]}[{k}]'
