from __future__ import annotations


class TemporaClientError(Exception):
    def __init__(self, message: str, code: str | None = None) -> None:
        super().__init__(message)
        self.code = code


class TemporaServerError(Exception):
    def __init__(self, message: str, code: str | None = None) -> None:
        super().__init__(message)
        self.code = code


def parse_arrow_exception(e: Exception) -> str:
    msg = e.args[0]
    # Remove the outer enclosing single quotes added by Pyarrow
    if msg.startswith("\'") and msg.endswith("\'"):
        msg = msg[1:-1]
    # Remove the Pyarrow flight details in the exception msg
    msg = msg.split('. Detail')[0]
    return msg
