from __future__ import annotations

import numpy as np

# Substitute jaxtyping type hints for when pytorch / tensorflow / jax are not installed
Tensor = np.ndarray
Array = np.ndarray
