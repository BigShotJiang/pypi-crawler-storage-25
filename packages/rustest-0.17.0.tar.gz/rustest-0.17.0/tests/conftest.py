"""Pytest compatibility for tests using rustest decorators.

This allows tests written with 'from rustest import parametrize, fixture'
to run under pytest by redirecting to pytest's native decorators.
"""

import sys

# Only activate when pytest is actually running (not just installed)
# Detection: check if _pytest is already loaded (pytest loads it early during startup)
# This is more reliable than PYTEST_CURRENT_TEST which is only set during test execution
# Also skip if we're running inside rustest's code block execution
if "_pytest" in sys.modules and "rustest" not in sys.modules:
    try:
        import pytest
    except ImportError:
        pass
    else:
        # Create a simple module-like object with fixture/parametrize/skip functions
        import types

        compat_module = types.ModuleType("rustest")
        compat_module.__file__ = __file__
        compat_module.__package__ = "rustest"

        # Find real rustest and copy its __path__ to make this a proper package
        # This allows submodule imports like `import rustest._runtime_config`
        import importlib.util
        spec = importlib.util.find_spec("rustest")
        if spec and spec.origin and "tests/conftest.py" not in str(spec.origin):
            # Get the real rustest package path
            real_rustest_loader = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(real_rustest_loader)
            if hasattr(real_rustest_loader, "__path__"):
                compat_module.__path__ = real_rustest_loader.__path__

        def _fixture(func=None, *, scope="function", autouse=False, name=None, params=None, ids=None):
            """Redirect to pytest.fixture with full parametrization support.

            Also sets rustest-specific attributes so rustest's discovery can find these fixtures.
            """
            def decorate(f):
                # Apply pytest fixture decorator
                decorated = pytest.fixture(f, scope=scope, autouse=autouse, name=name, params=params, ids=ids)
                # Set rustest-specific attributes for discovery
                setattr(decorated, "__rustest_fixture__", True)
                setattr(decorated, "__rustest_fixture_scope__", scope)
                setattr(decorated, "__rustest_fixture_autouse__", autouse)
                if name is not None:
                    setattr(decorated, "__rustest_fixture_name__", name)
                if params is not None:
                    setattr(decorated, "__rustest_fixture_params__", params)
                    if ids is not None:
                        setattr(decorated, "__rustest_fixture_ids__", ids)
                return decorated

            if func is None:
                # Called with arguments: @fixture(scope="module", autouse=True, params=[...])
                return decorate
            # Called without arguments: @fixture
            return decorate(func)

        def _parametrize(argnames, argvalues=None, *, argvalues_kw=None, ids=None, indirect=False):
            """Redirect to pytest.mark.parametrize."""
            vals = argvalues if argvalues is not None else argvalues_kw
            return pytest.mark.parametrize(argnames, vals, ids=ids, indirect=indirect)

        def _skip(reason=None):
            """Redirect to pytest.mark.skip."""
            return pytest.mark.skip(reason=reason or "skipped via rustest.skip")

        # Import approx and raises from rustest.approx and rustest.decorators
        # These need to come from the real rustest package
        try:
            # Try to import from installed rustest package
            import importlib.util

            # Find the real rustest module (not this shim)
            spec = importlib.util.find_spec("rustest")
            if spec and spec.origin and "tests/conftest.py" not in str(spec.origin):
                # Load the real module temporarily to get approx and raises
                real_rustest = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(real_rustest)
                compat_module.approx = real_rustest.approx
                compat_module.raises = real_rustest.raises
            else:
                # No real rustest found, use fallback
                raise ImportError("Real rustest module not found")
        except Exception:
            # Fallback: define minimal versions
            from math import isclose

            class _Approx:
                def __init__(self, expected, *, rel_tol=1e-6, abs_tol=1e-12):
                    self.expected = expected
                    self.rel_tol = rel_tol
                    self.abs_tol = abs_tol

                def __eq__(self, actual):
                    return isclose(
                        actual, self.expected, rel_tol=self.rel_tol, abs_tol=self.abs_tol
                    )

            compat_module.approx = _Approx
            compat_module.raises = pytest.raises

        compat_module.fixture = _fixture
        compat_module.parametrize = _parametrize
        compat_module.skip = _skip
        compat_module.skip_decorator = _skip  # Alias for compatibility
        compat_module.mark = pytest.mark

        # Add __getattr__ to delegate unknown attributes to real rustest
        # This allows accessing things like _runtime_config from the shim
        def __getattr__(name):
            """Delegate unknown attributes to real rustest module."""
            try:
                import importlib.util
                spec = importlib.util.find_spec("rustest")
                if spec and spec.origin and "tests/conftest.py" not in str(spec.origin):
                    # Load the real rustest module
                    import importlib
                    # Use import_module to get the actual installed rustest package
                    # Remove the shim temporarily to allow real import
                    saved_shim = sys.modules.pop("rustest", None)
                    try:
                        real_rustest = importlib.import_module("rustest")
                        return getattr(real_rustest, name)
                    finally:
                        if saved_shim:
                            sys.modules["rustest"] = saved_shim
            except Exception:
                pass
            raise AttributeError(f"module 'rustest' has no attribute '{name}'")

        # Attach __getattr__ to the module
        compat_module.__getattr__ = __getattr__

        # Inject rustest compatibility shim immediately at import time
        # This MUST happen before subdirectory conftest files are loaded
        # (pytest loads conftest files before calling pytest_configure)
        sys.modules["rustest"] = compat_module
