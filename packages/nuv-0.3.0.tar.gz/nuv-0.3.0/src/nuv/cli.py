import argparse
from collections.abc import Sequence

from nuv._logging import configure
from nuv.commands.new import validate_python_version


def _parse_python_version(value: str) -> str:
    try:
        return validate_python_version(value)
    except ValueError as exc:
        raise argparse.ArgumentTypeError(str(exc)) from exc


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="nuv",
        description="Scaffold opinionated uv Python projects.",
    )
    parser.add_argument(
        "--log-level",
        default="WARNING",
        choices=("DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"),
        help="Logging level (default: WARNING).",
    )
    subparsers = parser.add_subparsers(dest="command", metavar="<command>")

    new_parser = subparsers.add_parser("new", help="Create a new project.")
    new_parser.add_argument("name", help="Project name.")
    new_parser.add_argument("--at", metavar="PATH", help="Target directory (default: ./<name>).")
    new_parser.add_argument(
        "--archetype",
        default="script",
        choices=["script", "spark", "fastapi"],
        metavar="TYPE",
        help="Project archetype (script, spark, or fastapi).",
    )
    new_parser.add_argument(
        "--python-version",
        default=None,
        metavar="VERSION",
        type=_parse_python_version,
        help="Python version (default depends on archetype — script=3.14, spark=3.13, fastapi=3.14). Must be MAJOR.MINOR format.",
    )
    new_parser.add_argument(
        "--install",
        default="command-only",
        choices=["editable", "none", "command-only"],
        metavar="MODE",
        help=(
            "Install behavior for the generated project (default: command-only). "
            "editable: run `uv tool install --editable`; "
            "none: skip tool installation; "
            "command-only: log the install command without running it."
        ),
    )
    new_parser.add_argument(
        "--keep-on-failure",
        action="store_true",
        help="Keep partially generated files if setup steps fail.",
    )

    return parser


def main(argv: Sequence[str] | None = None) -> int:
    from nuv.commands.new import run_new

    parser = build_parser()
    args = parser.parse_args(argv)
    configure(args.log_level)

    if args.command == "new":
        try:
            return run_new(
                args.name,
                at=args.at,
                archetype=args.archetype,
                python_version=args.python_version,
                install_mode=args.install,
                keep_on_failure=args.keep_on_failure,
            )
        except Exception:  # pragma: no cover
            parser.exit(status=1, message="ERROR unexpected failure\n")

    parser.print_help()
    return 1
