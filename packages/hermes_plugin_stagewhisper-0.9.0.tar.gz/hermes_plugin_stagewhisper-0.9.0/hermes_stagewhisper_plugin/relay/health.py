"""Health tracker for StageWhisper relay.

Equivalent to the OpenClaw plugin's src/health.ts.
"""

from __future__ import annotations

import time
from typing import Any


class HealthTracker:
    def __init__(self, display_model: str | None = None) -> None:
        self._status = "disconnected"
        self._display_model = display_model
        self._consecutive_failures = 0
        self._last_success: float | None = None

    def get(self) -> dict[str, Any]:
        return {
            "status": self._status,
            "displayModel": self._display_model,
        }

    def set_connected(self) -> None:
        self._status = "healthy" if self._consecutive_failures == 0 else self._status

    def set_disconnected(self) -> None:
        self._status = "disconnected"

    def set_model(self, model: str) -> None:
        self._display_model = model

    def record_success(self) -> None:
        self._status = "healthy"
        self._consecutive_failures = 0
        self._last_success = time.time()

    def record_failure(self, error: str) -> None:
        self._consecutive_failures += 1
        normalized = error.lower()
        if "401" in normalized or "unauthorized" in normalized:
            self._status = "auth_required"
            return
        if self._consecutive_failures >= 3:
            self._status = "degraded"

    def to_heartbeat_payload(self) -> dict[str, Any]:
        return {
            "status": self._status,
            "display_model": self._display_model,
        }
