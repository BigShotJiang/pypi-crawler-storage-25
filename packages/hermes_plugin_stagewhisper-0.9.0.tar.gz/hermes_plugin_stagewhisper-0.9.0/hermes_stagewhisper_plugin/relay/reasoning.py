"""Reasoning job execution via Hermes's LLM provider.

Uses OpenAI-compatible chat completions API (Hermes's native LLM interface)
instead of OpenResponses.
"""

from __future__ import annotations

import json
import logging
import os
import time
from datetime import datetime, timezone
from typing import Any

import httpx

logger = logging.getLogger(__name__)

_REASONING_MODEL = os.getenv("STAGEWHISPER_REASONING_MODEL", "")
_OPENAI_BASE_URL = os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1")
_OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")


def _build_chat_prompt(
    payload: dict[str, Any],
    response_schema: dict[str, Any],
    purpose: str,
) -> list[dict[str, Any]]:
    system_instruction = payload.get("system_instruction", "")
    user_input = json.dumps(payload, separators=(",", ":"))

    system_parts = [
        f'You are a structured reasoning engine for the "{purpose}" task.',
        "You MUST respond with a JSON object conforming to this schema.",
        "Output ONLY valid JSON. No markdown fences, no explanation, no extra text.",
        "",
        "JSON Schema:",
        json.dumps(response_schema, indent=2),
    ]
    if system_instruction:
        system_parts = [system_instruction, ""] + system_parts

    system_msg = "\n".join(system_parts)

    return [
        {"role": "system", "content": system_msg},
        {"role": "user", "content": user_input},
    ]


def _parse_json_output(text: str) -> dict[str, Any] | None:
    cleaned = text.strip()
    if cleaned.startswith("```"):
        lines = cleaned.split("\n")
        end = next((i for i in range(len(lines) - 1, -1, -1) if lines[i].strip() == "```"), len(lines))
        cleaned = "\n".join(lines[1:end]).strip()
    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        return None


async def execute_reasoning_job(
    job: dict[str, Any],
    display_model: str | None,
) -> dict[str, Any]:
    job_id = job["job_id"]
    purpose = job.get("purpose", "live_analysis")
    response_schema = job.get("response_schema", {})
    payload = job.get("payload", {})
    correlation_id = job.get("correlation_id")

    deadline_at = job.get("deadline_at")
    deadline_ms = -1
    if deadline_at:
        try:
            iso = deadline_at.replace("Z", "+00:00") if deadline_at.endswith("Z") else deadline_at
            deadline_dt = datetime.fromisoformat(iso)
            if deadline_dt.tzinfo is None:
                deadline_dt = deadline_dt.replace(tzinfo=timezone.utc)
            deadline_ms = int((deadline_dt.timestamp() - time.time()) * 1000)
        except (ValueError, OverflowError):
            pass

    if deadline_ms <= 0:
        return {
            "job_id": job_id,
            "status": "timed_out",
            "provider_run_id": None,
            "model_ref": display_model,
            "usage": None,
            "output": None,
            "error_code": "deadline_expired_before_start",
            "error_message": "Job deadline had already passed when execution began",
        }

    model = job.get("model") or display_model or _REASONING_MODEL or "gpt-4o"
    messages = _build_chat_prompt(payload, response_schema, purpose)

    timeout = min(deadline_ms / 1000, 120) if deadline_ms > 0 else 120

    headers = {
        "Content-Type": "application/json",
    }
    if _OPENAI_API_KEY:
        headers["Authorization"] = f"Bearer {_OPENAI_API_KEY}"

    body = {
        "model": model,
        "messages": messages,
        "max_tokens": 4096,
        "temperature": 0.1,
    }

    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            resp = await client.post(
                f"{_OPENAI_BASE_URL}/chat/completions",
                headers=headers,
                json=body,
            )

            if not resp.is_success:
                return {
                    "job_id": job_id,
                    "status": "failed",
                    "provider_run_id": None,
                    "model_ref": model,
                    "usage": None,
                    "output": None,
                    "error_code": "llm_error",
                    "error_message": f"LLM API error ({resp.status_code}): {resp.text[:500]}",
                }

            data = resp.json()
            choice = data["choices"][0]
            text = choice["message"]["content"]
            usage = data.get("usage", {})
            provider_run_id = data.get("id")

            parsed = _parse_json_output(text)
            if parsed is None:
                return {
                    "job_id": job_id,
                    "status": "failed",
                    "provider_run_id": provider_run_id,
                    "model_ref": model,
                    "usage": {
                        "input_tokens": usage.get("prompt_tokens", 0),
                        "output_tokens": usage.get("completion_tokens", 0),
                    },
                    "output": None,
                    "error_code": "response_parse_error",
                    "error_message": "Response text is not valid JSON",
                }

            return {
                "job_id": job_id,
                "status": "completed",
                "provider_run_id": provider_run_id,
                "model_ref": model,
                "usage": {
                    "input_tokens": usage.get("prompt_tokens", 0),
                    "output_tokens": usage.get("completion_tokens", 0),
                },
                "output": parsed,
                "error_code": None,
                "error_message": None,
            }

    except httpx.TimeoutException:
        return {
            "job_id": job_id,
            "status": "timed_out",
            "provider_run_id": None,
            "model_ref": model,
            "usage": None,
            "output": None,
            "error_code": "deadline_exceeded",
            "error_message": f"Reasoning execution exceeded deadline",
        }
    except Exception as exc:
        logger.error("Reasoning job %s failed: %s", job_id, exc)
        return {
            "job_id": job_id,
            "status": "failed",
            "provider_run_id": None,
            "model_ref": model,
            "usage": None,
            "output": None,
            "error_code": "execution_error",
            "error_message": str(exc),
        }


async def probe_llm() -> dict[str, Any]:
    """Lightweight health check to verify the LLM is reachable."""
    headers = {"Content-Type": "application/json"}
    if _OPENAI_API_KEY:
        headers["Authorization"] = f"Bearer {_OPENAI_API_KEY}"

    body = {
        "model": _REASONING_MODEL or "gpt-4o",
        "messages": [{"role": "user", "content": "Reply with exactly: OK"}],
        "max_tokens": 8,
    }

    try:
        async with httpx.AsyncClient(timeout=15) as client:
            resp = await client.post(
                f"{_OPENAI_BASE_URL}/chat/completions",
                headers=headers,
                json=body,
            )
            if resp.is_success:
                data = resp.json()
                model = data.get("model")
                return {"ok": True, "model": model, "error": None}
            return {"ok": False, "model": None, "error": f"HTTP {resp.status_code}"}
    except Exception as exc:
        return {"ok": False, "model": None, "error": str(exc)}
