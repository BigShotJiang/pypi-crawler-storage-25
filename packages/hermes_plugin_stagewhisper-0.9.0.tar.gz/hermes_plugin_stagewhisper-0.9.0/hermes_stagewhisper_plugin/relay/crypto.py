"""X25519 key exchange + XChaCha20-Poly1305 envelope crypto.

Wire-compatible with the TypeScript OpenClaw plugin
(integrations/openclaw-stagewhisper-channel/src/crypto.ts).
"""

from __future__ import annotations

import json
import os
import struct
import uuid as _uuid
from typing import Literal

from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import x25519
from cryptography.hazmat.primitives.ciphers.aead import ChaCha20Poly1305
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

ENVELOPE_VERSION = "static_v1"
_ENVELOPE_HKDF_INFO = b"stagewhisper-byo-envelope-v1"
_REPLAY_GUARD_MAX_IDS = 10_000

SenderRole = Literal["desktop", "plugin"]
ContentType = Literal[
    "reasoning_input",
    "reasoning_output",
    "tool_intent",
    "tool_result",
    "task_content",
    "task_reply",
]


# ---------------------------------------------------------------------------
# ChaCha20 quarter-round + HChaCha20 (used only for XChaCha20 subkey)
# ---------------------------------------------------------------------------

def _rotl32(v: int, c: int) -> int:
    return ((v << c) | (v >> (32 - c))) & 0xFFFFFFFF


def _quarter_round(state: list[int], a: int, b: int, c: int, d: int) -> None:
    state[a] = (state[a] + state[b]) & 0xFFFFFFFF
    state[d] ^= state[a]
    state[d] = _rotl32(state[d], 16)
    state[c] = (state[c] + state[d]) & 0xFFFFFFFF
    state[b] ^= state[c]
    state[b] = _rotl32(state[b], 12)
    state[a] = (state[a] + state[b]) & 0xFFFFFFFF
    state[d] ^= state[a]
    state[d] = _rotl32(state[d], 8)
    state[c] = (state[c] + state[d]) & 0xFFFFFFFF
    state[b] ^= state[c]
    state[b] = _rotl32(state[b], 7)


def _hchacha20(key: bytes, nonce: bytes) -> bytes:
    """HChaCha20(key[32], nonce[16]) -> subkey[32]."""
    constants = [0x61707865, 0x3320646E, 0x79622D32, 0x6B206574]
    key_words = list(struct.unpack("<8I", key))
    nonce_words = list(struct.unpack("<4I", nonce))
    state = constants + key_words + nonce_words
    w = state[:]
    for _ in range(10):
        _quarter_round(w, 0, 4, 8, 12)
        _quarter_round(w, 1, 5, 9, 13)
        _quarter_round(w, 2, 6, 10, 14)
        _quarter_round(w, 3, 7, 11, 15)
        _quarter_round(w, 0, 5, 10, 15)
        _quarter_round(w, 1, 6, 11, 12)
        _quarter_round(w, 2, 7, 8, 13)
        _quarter_round(w, 3, 4, 9, 14)
    return struct.pack("<8I", w[0], w[1], w[2], w[3], w[12], w[13], w[14], w[15])


def _xchacha20_poly1305_encrypt(
    key: bytes, nonce: bytes, aad: bytes, plaintext: bytes
) -> bytes:
    subkey = _hchacha20(key, nonce[:16])
    chacha = ChaCha20Poly1305(subkey)
    return chacha.encrypt(b"\x00\x00\x00\x00" + nonce[16:24], plaintext, aad)


def _xchacha20_poly1305_decrypt(
    key: bytes, nonce: bytes, aad: bytes, ciphertext: bytes
) -> bytes:
    subkey = _hchacha20(key, nonce[:16])
    chacha = ChaCha20Poly1305(subkey)
    return chacha.decrypt(b"\x00\x00\x00\x00" + nonce[16:24], ciphertext, aad)


# ---------------------------------------------------------------------------
# Identity keypair (X25519)
# ---------------------------------------------------------------------------


class IdentityKeypair:
    def __init__(self, secret_key: bytes) -> None:
        if len(secret_key) != 32:
            raise ValueError(f"Secret key must be 32 bytes, got {len(secret_key)}")
        self._secret = secret_key
        self._public = x25519.X25519PrivateKey.from_private_bytes(secret_key).public_key()

    @classmethod
    def generate(cls) -> IdentityKeypair:
        return cls(os.urandom(32))

    @classmethod
    def from_secret_bytes(cls, data: bytes) -> IdentityKeypair:
        return cls(data)

    def secret_bytes(self) -> bytes:
        return self._secret

    def public_key_bytes(self) -> bytes:
        return self._public.public_bytes_raw()

    def public_key_base64(self) -> str:
        return _to_base64(self.public_key_bytes())

    @staticmethod
    def public_key_from_base64(b64: str) -> bytes:
        data = _from_base64(b64)
        if len(data) != 32:
            raise ValueError(f"Public key must be 32 bytes, got {len(data)}")
        return data

    def diffie_hellman(self, peer_public: bytes) -> bytes:
        priv = x25519.X25519PrivateKey.from_private_bytes(self._secret)
        peer_pub = x25519.X25519PublicKey.from_public_bytes(peer_public)
        return priv.exchange(peer_pub)

    def derive_envelope_key(self, peer_public: bytes) -> bytes:
        shared = self.diffie_hellman(peer_public)
        hkdf = HKDF(algorithm=hashes.SHA256(), length=32, salt=None, info=_ENVELOPE_HKDF_INFO)
        return hkdf.derive(shared)


# ---------------------------------------------------------------------------
# Envelope encryption / decryption
# ---------------------------------------------------------------------------


def _build_aad(meta: dict) -> bytes:
    aad_obj = {
        "content_type": meta["content_type"],
        "correlation_id": meta["correlation_id"],
        "message_id": meta["message_id"],
        "sender_role": meta["sender_role"],
        "session_id": meta["session_id"],
        "version": meta["version"],
    }
    return json.dumps(aad_obj, separators=(",", ":")).encode()


def seal(
    key: bytes,
    sender_role: SenderRole,
    session_id: str,
    correlation_id: str,
    content_type: ContentType,
    plaintext: bytes,
) -> dict:
    message_id = str(_uuid.uuid4())
    nonce = os.urandom(24)

    meta = {
        "version": ENVELOPE_VERSION,
        "sender_role": sender_role,
        "message_id": message_id,
        "session_id": session_id,
        "correlation_id": correlation_id,
        "content_type": content_type,
    }

    aad = _build_aad(meta)
    ciphertext = _xchacha20_poly1305_encrypt(key, nonce, aad, plaintext)

    return {
        **meta,
        "nonce": _to_base64(nonce),
        "ciphertext": _to_base64(ciphertext),
    }


def open_envelope(key: bytes, envelope: dict) -> bytes:
    if envelope.get("version") != ENVELOPE_VERSION:
        raise ValueError(f"Unsupported envelope version: {envelope.get('version')}")

    nonce = _from_base64(envelope["nonce"])
    if len(nonce) != 24:
        raise ValueError(f"Nonce must be 24 bytes, got {len(nonce)}")

    ciphertext = _from_base64(envelope["ciphertext"])
    aad = _build_aad(envelope)
    return _xchacha20_poly1305_decrypt(key, nonce, aad, ciphertext)


def seal_json(
    key: bytes,
    sender_role: SenderRole,
    session_id: str,
    correlation_id: str,
    content_type: ContentType,
    value,
) -> dict:
    plaintext = json.dumps(value, separators=(",", ":")).encode()
    return seal(key, sender_role, session_id, correlation_id, content_type, plaintext)


def open_json(key: bytes, envelope: dict):
    plaintext = open_envelope(key, envelope)
    return json.loads(plaintext)


# ---------------------------------------------------------------------------
# Replay guard
# ---------------------------------------------------------------------------


class ReplayGuard:
    def __init__(self) -> None:
        self._seen: set[str] = set()
        self._order: list[str] = []

    def check(self, message_id: str) -> None:
        if message_id in self._seen:
            raise ValueError(f"Replay detected: duplicate message_id {message_id}")
        while len(self._seen) >= _REPLAY_GUARD_MAX_IDS:
            oldest = self._order.pop(0)
            self._seen.discard(oldest)
        self._seen.add(message_id)
        self._order.append(message_id)


def open_checked(key: bytes, envelope: dict, replay_guard: ReplayGuard) -> bytes:
    replay_guard.check(envelope["message_id"])
    return open_envelope(key, envelope)


def open_json_checked(key: bytes, envelope: dict, replay_guard: ReplayGuard):
    replay_guard.check(envelope["message_id"])
    return open_json(key, envelope)


# ---------------------------------------------------------------------------
# Base64 (standard, NOT URL-safe)
# ---------------------------------------------------------------------------


def _to_base64(data: bytes) -> str:
    import base64

    return base64.b64encode(data).decode()


def _from_base64(b64: str) -> bytes:
    import base64

    return base64.b64decode(b64)
