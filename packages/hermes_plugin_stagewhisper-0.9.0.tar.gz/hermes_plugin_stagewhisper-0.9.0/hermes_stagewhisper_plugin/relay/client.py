"""HTTP client for StageWhisper relay API.

Wire-compatible with the TypeScript OpenClaw plugin's StageWhisperClient.
"""

from __future__ import annotations

import logging
from typing import Any

import httpx

logger = logging.getLogger(__name__)
_RELAY_API_PREFIX = "/api/v1/assistant-relay"


class StageWhisperClient:
    def __init__(self, base_url: str, integration_id: str, relay_token: str) -> None:
        self.base_url = base_url.rstrip("/")
        self.integration_id = integration_id
        self.relay_token = relay_token
        self._plugin_keypair = None
        self._desktop_public_key: bytes | None = None

    @property
    def plugin_keypair(self):
        return self._plugin_keypair

    @property
    def desktop_public_key(self) -> bytes | None:
        return self._desktop_public_key

    def set_plugin_keypair(self, kp) -> None:
        self._plugin_keypair = kp

    def set_desktop_public_key(self, key: bytes) -> None:
        self._desktop_public_key = key

    def _headers(self) -> dict[str, str]:
        return {
            "Authorization": f"Bearer {self.relay_token}",
            "Content-Type": "application/json",
        }

    async def complete_pairing(
        self,
        pairing_code: str,
        host_label: str,
        plugin_public_key: str | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "pairing_code": pairing_code,
            "host_label": host_label,
        }
        if plugin_public_key:
            body["plugin_public_key"] = plugin_public_key

        async with httpx.AsyncClient() as client:
            resp = await client.post(
                f"{self.base_url}{_RELAY_API_PREFIX}/pair/complete",
                json=body,
                timeout=30,
            )
            if not resp.is_success:
                raise RuntimeError(f"Pairing failed ({resp.status_code}): {resp.text}")
            return resp.json()

    async def update_task_status(
        self, task_id: str, status: str, remote_task_id: str | None = None
    ) -> None:
        body: dict[str, Any] = {"status": status}
        if remote_task_id:
            body["remote_task_id"] = remote_task_id

        async with httpx.AsyncClient() as client:
            resp = await client.post(
                f"{self.base_url}{_RELAY_API_PREFIX}/tasks/{task_id}/status",
                headers=self._headers(),
                json=body,
                timeout=15,
            )
            if not resp.is_success:
                raise RuntimeError(
                    f"Status update failed ({resp.status_code}): {resp.text}"
                )

    async def post_reply(
        self,
        task_id: str,
        content: str,
        remote_message_id: str | None = None,
        encrypted_summary: str | None = None,
    ) -> None:
        body: dict[str, Any] = {"content": content}
        if remote_message_id:
            body["remote_message_id"] = remote_message_id
        if encrypted_summary:
            body["encrypted_summary"] = encrypted_summary

        async with httpx.AsyncClient() as client:
            resp = await client.post(
                f"{self.base_url}{_RELAY_API_PREFIX}/tasks/{task_id}/reply",
                headers=self._headers(),
                json=body,
                timeout=15,
            )
            if not resp.is_success:
                raise RuntimeError(f"Reply failed ({resp.status_code}): {resp.text}")

    async def heartbeat(
        self, capabilities: dict[str, Any] | None = None
    ) -> dict[str, Any]:
        async with httpx.AsyncClient() as client:
            resp = await client.post(
                f"{self.base_url}{_RELAY_API_PREFIX}/integrations/{self.integration_id}/heartbeat",
                headers=self._headers(),
                json=capabilities,
                timeout=15,
            )
            if not resp.is_success:
                raise RuntimeError(
                    f"Heartbeat failed ({resp.status_code}): {resp.text}"
                )
            return resp.json()

    async def post_reasoning_result(
        self,
        job_id: str,
        result: dict[str, Any],
        correlation_id: str | None = None,
    ) -> None:
        headers = self._headers()
        if correlation_id:
            headers["X-Correlation-ID"] = correlation_id

        async with httpx.AsyncClient() as client:
            resp = await client.post(
                f"{self.base_url}{_RELAY_API_PREFIX}/reasoning-jobs/{job_id}/complete",
                headers=headers,
                json=result,
                timeout=30,
            )
            if not resp.is_success:
                raise RuntimeError(
                    f"Reasoning result post failed ({resp.status_code}): {resp.text}"
                )

    async def get_reasoning_job(self, job_id: str) -> dict[str, Any]:
        async with httpx.AsyncClient() as client:
            resp = await client.get(
                f"{self.base_url}{_RELAY_API_PREFIX}/reasoning-jobs/{job_id}",
                headers=self._headers(),
                timeout=15,
            )
            if not resp.is_success:
                raise RuntimeError(
                    f"Reasoning job fetch failed ({resp.status_code}): {resp.text}"
                )
            return resp.json()

    def stream_url(self) -> str:
        return (
            f"{self.base_url}{_RELAY_API_PREFIX}/integrations/"
            f"{self.integration_id}/stream"
        )

    def stream_headers(self) -> dict[str, str]:
        return {"Authorization": f"Bearer {self.relay_token}"}

    async def test_reply(self, test_id: str, content: str) -> None:
        async with httpx.AsyncClient() as client:
            resp = await client.post(
                f"{self.base_url}{_RELAY_API_PREFIX}/integrations/{self.integration_id}/test-reply",
                headers=self._headers(),
                json={"test_id": test_id, "content": content},
                timeout=15,
            )
            if not resp.is_success:
                raise RuntimeError(
                    f"Test reply failed ({resp.status_code}): {resp.text}"
                )
