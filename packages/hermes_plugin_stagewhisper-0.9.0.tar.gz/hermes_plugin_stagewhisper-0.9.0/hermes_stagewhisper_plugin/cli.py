"""CLI registration for the StageWhisper Hermes plugin."""

from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="stagewhisper-hermes",
        description="Manage the StageWhisper Hermes plugin.",
    )
    _setup_argparse(parser)
    args = parser.parse_args(argv)
    _handle_command(args)
    return 0


def _setup_argparse(subparser: argparse.ArgumentParser) -> None:
    subs = subparser.add_subparsers(dest="stagewhisper_command")

    pair_parser = subs.add_parser("pair", help="Pair with StageWhisper desktop")
    pair_parser.add_argument(
        "--code", "-c", required=True, help="Pairing code from StageWhisper desktop"
    )
    pair_parser.add_argument(
        "--label", "-l", default="StageWhisper", help="Label for this pairing"
    )
    pair_parser.add_argument("--api-url", help="StageWhisper backend URL override")
    pair_parser.add_argument(
        "--no-restart",
        action="store_true",
        help="Do not restart Hermes gateway after pairing.",
    )

    subs.add_parser("unpair", help="Unpair from StageWhisper")
    subs.add_parser("status", help="Show relay connection status")
    subs.add_parser("start", help="Start the relay service")
    subs.add_parser("stop", help="Stop the relay service")
    subs.add_parser("restart", help="Restart the relay service")

    subparser.set_defaults(func=_handle_command)


def _handle_command(args: argparse.Namespace) -> None:
    cmd = getattr(args, "stagewhisper_command", None)

    if cmd == "pair":
        _cmd_pair(
            args.code,
            args.label,
            args.api_url,
            restart_gateway=not args.no_restart,
        )
    elif cmd == "unpair":
        _cmd_unpair()
    elif cmd == "status":
        _cmd_status()
    elif cmd == "start":
        _cmd_start()
    elif cmd == "stop":
        _cmd_stop()
    elif cmd == "restart":
        _cmd_restart()
    else:
        print("Usage: stagewhisper-hermes <pair|unpair|status|start|stop|restart>")


def _cmd_pair(
    code: str, label: str, api_url: str | None, *, restart_gateway: bool = True
) -> None:
    from .tools import stagewhisper_pair

    result = stagewhisper_pair(code, label, api_url)
    data = json.loads(result)
    if data.get("ok"):
        print(f"✓ Paired — integration: {data['integration_id']}")
        if data.get("has_byo_keys"):
            print("  End-to-end encryption enabled")
        if restart_gateway:
            _restart_gateway()
        else:
            print(
                "  Restart Hermes gateway if it is already running: "
                "hermes gateway restart"
            )
    else:
        print(f"✗ Pairing failed: {data.get('error', 'unknown error')}")


def _restart_gateway() -> None:
    hermes = shutil.which("hermes")
    if not hermes:
        print("  Hermes command not found. Restart Hermes gateway manually.")
        return

    print("  Restarting Hermes gateway...")
    result = subprocess.run(
        [hermes, "gateway", "restart"],
        text=True,
        capture_output=True,
    )
    detail = (result.stdout or result.stderr or "").strip()
    if result.returncode == 0:
        if detail:
            _print_indented(detail)
        else:
            print("  Hermes gateway restarted")
        return

    print("  Hermes gateway restart failed.")
    if detail:
        _print_indented(detail)
    print("  Run manually: hermes gateway restart")


def _print_indented(text: str) -> None:
    for line in text.splitlines():
        print(f"  {line}")


def _cmd_unpair() -> None:
    from .tools import stagewhisper_unpair

    result = stagewhisper_unpair()
    data = json.loads(result)
    if data.get("ok"):
        print("✓ Unpaired — config cleared")
    else:
        print(f"✗ Unpair failed: {data.get('error', 'unknown error')}")


def _cmd_status() -> None:
    from .tools import stagewhisper_relay

    result = stagewhisper_relay("status")
    data = json.loads(result)
    if data.get("ok"):
        integration_id = data.get("integration_id")
        print(f"Pairing: {'configured' if integration_id else 'not configured'}")
        if integration_id:
            print(f"Integration: {integration_id}")
        if data.get("api_url"):
            print(f"Backend: {data['api_url']}")
        if data.get("running"):
            connected = "connected" if data.get("connected") else "disconnected"
            print(f"Relay: running in this process, stream: {connected}")
            print(f"Health: {data.get('health', 'unknown')}")
            if data.get("model"):
                print(f"Model: {data['model']}")
        else:
            print("Relay: managed by Hermes gateway")
    else:
        print(f"✗ Status check failed: {data.get('error', 'unknown error')}")


def _cmd_start() -> None:
    from .tools import stagewhisper_relay

    result = stagewhisper_relay("start")
    data = json.loads(result)
    if data.get("ok"):
        print("✓ Relay started")
    else:
        print(f"✗ Start failed: {data.get('error', 'unknown error')}")


def _cmd_stop() -> None:
    from .tools import stagewhisper_relay

    result = stagewhisper_relay("stop")
    data = json.loads(result)
    if data.get("ok"):
        print("✓ Relay stopped")
    else:
        print(f"✗ Stop failed: {data.get('error', 'unknown error')}")


def _cmd_restart() -> None:
    from .tools import stagewhisper_relay

    result = stagewhisper_relay("restart")
    data = json.loads(result)
    if data.get("ok"):
        print("✓ Relay restarted")
    else:
        print(f"✗ Restart failed: {data.get('error', 'unknown error')}")


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
