"""Tool handlers for the StageWhisper Hermes plugin."""

from __future__ import annotations

import asyncio
import base64
import json
import logging
import os

from .config import is_paired
from .relay.client import StageWhisperClient
from .relay.crypto import IdentityKeypair
from .relay.service import relay_service

logger = logging.getLogger(__name__)


def stagewhisper_pair(
    code: str, label: str = "StageWhisper", api_url: str | None = None
) -> str:
    if not code or len(code.strip()) < 4:
        return json.dumps({"error": "Invalid pairing code"})

    try:
        return asyncio.run(
            _pair_async(code.strip(), label.strip() or "StageWhisper", api_url)
        )
    except Exception as exc:
        logger.error("Pairing failed: %s", exc)
        return json.dumps({"error": str(exc)})


async def _pair_async(code: str, label: str, api_url: str | None) -> str:
    resolved_api_url = (
        api_url.strip()
        if api_url and api_url.strip()
        else os.environ.get("STAGEWHISPER_API_URL", "http://127.0.0.1:8000")
    )
    os.environ["STAGEWHISPER_API_URL"] = resolved_api_url

    kp = IdentityKeypair.generate()
    plugin_public_key = kp.public_key_base64()

    client = StageWhisperClient(resolved_api_url, "", "")
    result = await client.complete_pairing(code, label, plugin_public_key)

    os.environ["STAGEWHISPER_INTEGRATION_ID"] = result["integration_id"]
    os.environ["STAGEWHISPER_RELAY_TOKEN"] = result["relay_token"]
    os.environ["STAGEWHISPER_PLUGIN_SECRET_KEY"] = base64.b64encode(
        kp.secret_bytes()
    ).decode()

    desktop_pub_b64 = result.get("byo_public_key")
    if desktop_pub_b64:
        os.environ["STAGEWHISPER_DESKTOP_PUBLIC_KEY"] = desktop_pub_b64
        logger.info("E2EE BYO keys exchanged — relay will use encryption")

    _save_env()

    logger.info(
        "Paired successfully — integration: %s, label: %s",
        result["integration_id"],
        label,
    )

    return json.dumps(
        {
            "ok": True,
            "integration_id": result["integration_id"],
            "label": label,
            "has_byo_keys": bool(desktop_pub_b64),
        }
    )


def stagewhisper_relay(action: str = "status") -> str:
    try:
        return asyncio.run(_relay_async(action))
    except Exception as exc:
        logger.error("Relay action '%s' failed: %s", action, exc)
        return json.dumps({"error": str(exc)})


async def _relay_async(action: str) -> str:
    if action == "start":
        if not is_paired():
            return json.dumps(
                {"error": "Not paired. Run stagewhisper_pair first."}
            )
        await relay_service.stop()
        await relay_service.start()
        return json.dumps({"ok": True, "action": "started"})

    if action == "stop":
        await relay_service.stop()
        return json.dumps({"ok": True, "action": "stopped"})

    if action == "restart":
        await relay_service.stop()
        if is_paired():
            await relay_service.start()
        return json.dumps({"ok": True, "action": "restarted"})

    connected = relay_service._connected
    running = relay_service.running
    health = relay_service.health.get()

    return json.dumps(
        {
            "ok": True,
            "action": "status",
            "running": running,
            "connected": connected,
            "health": health.get("status", "unknown"),
            "model": health.get("displayModel"),
            "integration_id": os.environ.get(
                "STAGEWHISPER_INTEGRATION_ID", ""
            ),
            "api_url": os.environ.get("STAGEWHISPER_API_URL", ""),
        }
    )


def stagewhisper_unpair() -> str:
    try:
        asyncio.run(relay_service.stop())
    except Exception as exc:
        logger.warning("Error stopping relay during unpair: %s", exc)

    for var in [
        "STAGEWHISPER_INTEGRATION_ID",
        "STAGEWHISPER_RELAY_TOKEN",
        "STAGEWHISPER_PLUGIN_SECRET_KEY",
        "STAGEWHISPER_DESKTOP_PUBLIC_KEY",
    ]:
        os.environ.pop(var, None)

    _save_env()

    return json.dumps({"ok": True, "message": "Unpaired — config cleared"})


def _save_env() -> None:
    try:
        from pathlib import Path

        env_path = Path.home() / ".hermes" / ".env"
        if not env_path.parent.exists():
            return

        current_lines: list[str] = []
        if env_path.exists():
            current_lines = env_path.read_text().splitlines()

        sw_keys = {
            "STAGEWHISPER_API_URL",
            "STAGEWHISPER_INTEGRATION_ID",
            "STAGEWHISPER_RELAY_TOKEN",
            "STAGEWHISPER_PLUGIN_SECRET_KEY",
            "STAGEWHISPER_DESKTOP_PUBLIC_KEY",
            "STAGEWHISPER_REASONING_MODEL",
        }

        new_lines = [line for line in current_lines if not _line_has_key(line, sw_keys)]

        for key in sorted(sw_keys):
            value = os.environ.get(key, "")
            if value:
                new_lines.append(f'{key}="{_quote_env_value(value)}"')

        if env_path.exists():
            env_path.chmod(0o600)
        fd = os.open(env_path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write("\n".join(new_lines) + "\n")
        env_path.chmod(0o600)
    except Exception:
        pass


def _quote_env_value(value: str) -> str:
    return (
        value.replace("\\", "\\\\")
        .replace("\n", "\\n")
        .replace("\r", "\\r")
        .replace('"', '\\"')
    )


def _line_has_key(line: str, keys: set[str]) -> bool:
    for key in keys:
        if line.startswith(key + "=") or line.startswith(key + '="'):
            return True
    return False
