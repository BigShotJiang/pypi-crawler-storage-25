"""StageWhisper plugin for Hermes Agent.

Provides:
- Tools: stagewhisper_pair, stagewhisper_relay, stagewhisper_unpair
- CLI:  stagewhisper-hermes pair|unpair|status|start|stop|restart
- Auto-start relay on plugin load when configured

Install: pipx run --spec hermes-plugin-stagewhisper stagewhisper-hermes-install
(A plugin directory at ~/.hermes/plugins/stagewhisper/)
"""

from __future__ import annotations

import logging
from inspect import signature

logger = logging.getLogger(__name__)


def register(ctx) -> None:
    from . import schemas
    from .cli import _handle_command, _setup_argparse

    _register_tool(ctx, "stagewhisper_pair", schemas.STAGEWHISPER_PAIR, _handle_pair)
    _register_tool(ctx, "stagewhisper_relay", schemas.STAGEWHISPER_RELAY, _handle_relay)
    _register_tool(ctx, "stagewhisper_unpair", schemas.STAGEWHISPER_UNPAIR, _handle_unpair)

    if hasattr(ctx, "register_cli_command"):
        ctx.register_cli_command(
            "stagewhisper",
            "Manage StageWhisper BYO AI relay",
            _setup_argparse,
            _handle_command,
        )

    _start_relay_when_paired()


def _register_tool(ctx, name: str, schema: dict, handler) -> None:
    try:
        params = signature(ctx.register_tool).parameters
    except (TypeError, ValueError):
        params = {}

    if "toolset" in params:
        ctx.register_tool(name, "stagewhisper", schema, handler)
        return

    try:
        ctx.register_tool(name, schema, handler)
    except TypeError as exc:
        try:
            ctx.register_tool(
                name=name,
                toolset="stagewhisper",
                schema=schema,
                handler=handler,
            )
        except TypeError:
            raise exc


def _handle_pair(args: dict, **kwargs) -> str:
    from .tools import stagewhisper_pair

    return stagewhisper_pair(
        code=args.get("code", ""),
        label=args.get("label", "StageWhisper"),
        api_url=args.get("api_url"),
    )


def _handle_relay(args: dict, **kwargs) -> str:
    from .tools import stagewhisper_relay

    return stagewhisper_relay(action=args.get("action", "status"))


def _handle_unpair(args: dict, **kwargs) -> str:
    from .tools import stagewhisper_unpair

    return stagewhisper_unpair()


def _start_relay_when_paired() -> None:
    try:
        from .config import is_paired

        if not is_paired():
            return

        import asyncio

        from .relay.service import relay_service

        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            try:
                loop = asyncio.get_event_loop()
            except RuntimeError:
                return
        if not loop.is_closed():
            logger.info("StageWhisper is paired — auto-starting relay")
            loop.create_task(relay_service.start())
    except Exception as exc:
        logger.warning("StageWhisper relay auto-start skipped: %s", exc)
