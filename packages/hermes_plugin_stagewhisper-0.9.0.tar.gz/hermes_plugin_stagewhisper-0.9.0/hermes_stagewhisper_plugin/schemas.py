"""Tool schemas for the StageWhisper Hermes plugin.

These are what the LLM reads to decide when to call StageWhisper tools.
"""

STAGEWHISPER_PAIR = {
    "name": "stagewhisper_pair",
    "description": (
        "Pair this Hermes agent with a StageWhisper desktop app. "
        "Takes a pairing code from the StageWhisper settings screen "
        "and exchanges encryption keys for the BYO relay."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "code": {
                "type": "string",
                "description": "Pairing code from StageWhisper desktop (8 characters)",
            },
            "label": {
                "type": "string",
                "description": "Label for this pairing (e.g., 'My Hermes agent')",
            },
            "api_url": {
                "type": "string",
                "description": "StageWhisper backend URL override",
            },
        },
        "required": ["code"],
    },
}

STAGEWHISPER_RELAY = {
    "name": "stagewhisper_relay",
    "description": (
        "Control the StageWhisper relay service. Actions: "
        "'start' — begin the encrypted reasoning relay (auto-starts after pairing), "
        "'stop' — stop the relay, "
        "'status' — show relay connection status, "
        "'restart' — stop then start the relay."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "action": {
                "type": "string",
                "enum": ["start", "stop", "status", "restart"],
                "description": "Which relay action to perform",
            },
        },
        "required": ["action"],
    },
}

STAGEWHISPER_UNPAIR = {
    "name": "stagewhisper_unpair",
    "description": (
        "Unpair this Hermes agent from StageWhisper. "
        "Stops the relay and clears pairing configuration. "
        "The desktop can re-pair with a fresh code."
    ),
    "parameters": {
        "type": "object",
        "properties": {},
    },
}
