import soundfile as sf
import numpy as np


def load_audio(file_path):
    """加载音频文件，返回 data(float32), sample_rate, num_channels, duration"""
    data, sample_rate = sf.read(file_path, dtype='float32')
    num_channels = 1 if data.ndim == 1 else data.shape[1]
    duration = len(data) / sample_rate
    return data, sample_rate, num_channels, duration


def save_audio(file_path, data, sample_rate, force_clip=False):
    """保存音频为 16-bit WAV"""
    if force_clip:
        data = np.clip(data, -1.0, 1.0)
    sf.write(file_path, data, sample_rate, subtype='PCM_16')
