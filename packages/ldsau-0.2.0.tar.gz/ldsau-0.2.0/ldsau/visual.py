import numpy as np
import matplotlib.pyplot as plt
from pydub import AudioSegment


def get_waveform_data(file_path, max_points=50000):
    """提取音频波形数据用于绘图(Pydub)"""
    audio = AudioSegment.from_file(file_path)
    samples = np.array(audio.get_array_of_samples())
    if audio.channels == 2:
        samples = samples.reshape((-1, 2)).mean(axis=1)

    step = 1
    if len(samples) > max_points:
        step = len(samples) // max_points
        samples = samples[::step]

    time_axis = np.linspace(0, len(samples) / (audio.frame_rate / step), num=len(samples))
    return time_axis, samples


def get_envelope(channel_data, duration, num_bins=6000):
    """获取波形包络线(Numpy)"""
    data_len = len(channel_data)
    if data_len <= num_bins * 2:
        return np.linspace(0, duration, data_len), channel_data

    chunk_size = data_len // num_bins
    truncated_len = chunk_size * num_bins
    reshaped_data = channel_data[:truncated_len].reshape(num_bins, chunk_size)

    mins = reshaped_data.min(axis=1)
    maxs = reshaped_data.max(axis=1)

    time_base = np.linspace(0, duration, num_bins)
    x_plot = np.empty(num_bins * 2)
    x_plot[0::2], x_plot[1::2] = time_base, time_base
    y_plot = np.empty(num_bins * 2)
    y_plot[0::2], y_plot[1::2] = mins, maxs

    return x_plot, y_plot


def export_waveform_image(data, duration, num_channels, output_path):
    """导出波形图为图片"""
    plt.style.use('dark_background')
    fig, axes = plt.subplots(num_channels, 1, figsize=(12, 4 * num_channels), sharex=True)
    if num_channels == 1:
        axes = [axes]

    for ch in range(num_channels):
        ch_data = data if num_channels == 1 else data[:, ch]
        x, y = get_envelope(ch_data, duration, num_bins=8000)
        color = '#00FF99' if ch == 0 else '#00BFFF'
        axes[ch].plot(x, y, color=color, linewidth=0.5)
        axes[ch].axhline(0, color='#666666', linestyle='--', linewidth=1)
        axes[ch].axhline(1.0, color='#FF3333', linestyle=':', linewidth=1)
        axes[ch].axhline(-1.0, color='#FF3333', linestyle=':', linewidth=1)
        axes[ch].set_ylim(-1.2, 1.2)
        axes[ch].set_ylabel(f'Channel {ch + 1}')
        axes[ch].grid(True, alpha=0.3)

    axes[-1].set_xlabel('Time (seconds)')
    fig.suptitle('Audio Waveform', fontsize=16)
    plt.tight_layout()
    plt.savefig(output_path, dpi=150)
    plt.close()
    print(f"波形图片已保存至: {output_path}")
