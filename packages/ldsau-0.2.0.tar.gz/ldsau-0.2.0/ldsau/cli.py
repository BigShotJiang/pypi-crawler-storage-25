import argparse
import os
import numpy as np

from .io_utils import load_audio, save_audio
from .effects import apply_gain, calculate_auto_normalize, bypass_copyright_ultimate
from .mixer import mix_audios, extract_accompaniment
from .visual import export_waveform_image


def handle_bypass(args):
    """处理：去版权/修改音高"""
    if not os.path.exists(args.input):
        print(f"❌ 错误: 找不到文件 {args.input}")
        return

    bypass_copyright_ultimate(
        file_path=args.input,
        semitones=args.semi,
        tempo_rate=args.tempo,
        add_reverb=not args.no_reverb,
        add_noise=not args.no_noise,
        crop_60s=args.crop
    )


def handle_mix(args):
    """处理：多轨混合与伴奏提取"""
    try:
        if args.dir:
            extract_accompaniment(args.dir, args.output, to_mono=args.mono)
            print(f"✅ 伴奏提取成功！保存在: {args.output}")
        elif args.inputs:
            mix_audios(args.inputs, args.output, to_mono=args.mono)
            print(f"✅ 手动混合成功！保存在: {args.output}")
        else:
            print("❌ 错误: 必须提供 -i (文件列表) 或 -d (文件夹路径)")
    except Exception as e:
        print(f"❌ 处理失败: {e}")


def handle_process(args):
    """处理：声音处理/增益/标准化/波形图"""
    print(f"正在加载音频: {args.input} ...")
    data, sample_rate, num_channels, duration = load_audio(args.input)

    # 1. 处理自动标准化
    if args.auto_norm:
        factor, needed_db, target_db, over_ratio = calculate_auto_normalize(data, args.auto_norm)
        print(f"应用自动标准化模式 {args.auto_norm}...")
        print(f"计算得增益: {needed_db:+.2f} dB, 预计微小削波比例: {over_ratio:.3f}%")
        data = apply_gain(data, factor)

    # 2. 处理固定增益
    if args.gain is not None:
        factor = 10 ** (args.gain / 20.0)
        print(f"应用固定增益: {args.gain:+.2f} dB (倍数: {factor:.3f}x)")
        data = apply_gain(data, factor)

    # 3. 导出波形图片
    if args.export_img:
        print("正在生成波形图片...")
        export_waveform_image(data, duration, num_channels, args.export_img)

    # 4. 导出音频
    if args.output:
        max_val = np.max(np.abs(data))
        force_clip = False
        if max_val > 1.0:
            print(f"⚠️ 警告: 输出峰值为 {20 * np.log10(max_val):.2f} dB (> 0dB)。")
            print("正在强制切平以防止 16-bit WAV 平头失真...")
            force_clip = True

        save_audio(args.output, data, sample_rate, force_clip=force_clip)
        print(f"✅ 处理完成，已保存至: {args.output}")


def main():
    parser = argparse.ArgumentParser(description="音频处理工具箱 (Lds Audio Toolkit CLI)")
    subparsers = parser.add_subparsers(dest="command", help="可用的子命令", required=True)

    # ==================== 子命令 bypass (去版权/音高) ====================
    parser_bypass = subparsers.add_parser("bypass", help="修改音频音高、速度、加噪以规避版权检测")
    parser_bypass.add_argument("input", help="要处理的音频文件路径")
    parser_bypass.add_argument("--semi", type=float, default=0.6, help="音高移调半音数 (默认: 0.6)")
    parser_bypass.add_argument("--tempo", type=float, default=1.03, help="播放速度倍率 (默认: 1.03)")
    parser_bypass.add_argument("--no-reverb", action="store_true", help="禁用微混响")
    parser_bypass.add_argument("--no-noise", action="store_true", help="禁用磁带底噪")
    parser_bypass.add_argument("--crop", action="store_true", help="启用截取中间60秒")
    parser_bypass.set_defaults(func=handle_bypass)

    # ==================== 子命令 mix (音频合并/伴奏提取) ====================
    parser_mix = subparsers.add_parser("mix", help="多轨音频混合与伴奏提取工具")
    parser_mix.add_argument("-i", "--inputs", nargs="+", help="手动指定要混合的多个文件")
    parser_mix.add_argument("-d", "--dir", help="【一键伴奏模式】指定包含多轨音频的文件夹路径")
    parser_mix.add_argument("-o", "--output", required=True, help="输出的音频文件路径 (.wav)")
    parser_mix.add_argument("-m", "--mono", action="store_true", help="强制输出单声道")
    parser_mix.set_defaults(func=handle_mix)

    # ==================== 子命令 process (声音处理工具) ====================
    parser_process = subparsers.add_parser("process", help="音频增益、自动标准化与波形导出")
    parser_process.add_argument("input", help="输入音频文件路径")
    parser_process.add_argument("-o", "--output", help="输出音频文件路径 (可选)")
    parser_process.add_argument("--gain", type=float, help="增加或减少的增益 (dB)")
    parser_process.add_argument("--auto_norm", type=int, choices=[1, 2], help="自动标准化: 1=商业拉满级, 2=标准均衡级")
    parser_process.add_argument("--export_img", type=str, help="导出波形图片的保存路径 (例如: waveform.png)")
    parser_process.set_defaults(func=handle_process)

    # 解析并执行对应子命令的函数
    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
