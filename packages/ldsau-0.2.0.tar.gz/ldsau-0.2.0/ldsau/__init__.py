import warnings

# 忽略 pydub 在 Python 3.12+ 下由于正则转义引发的 SyntaxWarning
warnings.filterwarnings("ignore", category=SyntaxWarning, module="pydub")

from .io_utils import load_audio, save_audio
from .effects import apply_gain, calculate_auto_normalize, bypass_copyright_ultimate
from .mixer import mix_audios, extract_accompaniment
from .visual import get_waveform_data, get_envelope, export_waveform_image

__all__ = [
    "load_audio", "save_audio",
    "apply_gain", "calculate_auto_normalize", "bypass_copyright_ultimate",
    "mix_audios", "extract_accompaniment",
    "get_waveform_data", "get_envelope", "export_waveform_image"
]
