import os
import numpy as np
import scipy.signal as signal
import librosa
import soundfile as sf


def apply_gain(data, factor):
    """应用增益倍数 (无损32位浮点)"""
    return data * factor


def calculate_auto_normalize(data, mode_choice):
    """计算一键最佳音量的参数"""
    abs_data = np.abs(data)
    if mode_choice == 1:
        effective_peak = np.percentile(abs_data, 99.95)
        target_db = -0.1
    else:
        effective_peak = np.percentile(abs_data, 99.98)
        target_db = -0.5

    if effective_peak <= 1e-6:
        return 1.0, 0.0, target_db, 0.0

    target_val = 10 ** (target_db / 20.0)
    factor = target_val / effective_peak
    needed_db = 20 * np.log10(factor)
    over_0db_ratio = np.mean((abs_data * factor) > 1.0) * 100

    return factor, needed_db, target_db, over_0db_ratio


def bypass_copyright_ultimate(file_path, semitones=0.5, tempo_rate=1.03,
                              add_reverb=True, add_noise=True, crop_60s=True, logger=None):
    """终极去版权核心逻辑"""
    if logger is None:
        logger = print

    output_path = os.path.splitext(file_path)[0] + "_处理.wav"
    logger(f"🎵 加载音频: {os.path.basename(file_path)}")

    y, sr = librosa.load(file_path, sr=None, mono=True)

    if crop_60s:
        duration = librosa.get_duration(y=y, sr=sr)
        if duration > 70:
            logger("✂️ 截取中间60秒 (规避全曲匹配)...")
            start_sample = int(10 * sr)
            end_sample = start_sample + int(60 * sr)
            y = y[start_sample:end_sample]

    if tempo_rate != 1.0:
        logger(f"⏩ 微变速处理 (x{tempo_rate})...")
        y = librosa.effects.time_stretch(y, rate=tempo_rate)

    if semitones != 0:
        logger(f"🔧 移调处理 ({semitones} 半音)...")
        y = librosa.effects.pitch_shift(y, sr=sr, n_steps=semitones)

    logger("🌊 应用电子管饱和(修改波形峰值特征)...")
    y = np.tanh(y * 1.5) / np.tanh(1.5)

    nyq = 0.5 * sr
    low = 80 / nyq
    high = 12000 / nyq
    if high < 1.0:
        b, a = signal.butter(4, [low, high], btype='band')
        y = signal.filtfilt(b, a, y)

    if add_reverb:
        logger("🪞 添加特征模糊延迟...")
        delay_samples = int(sr * 0.04)
        y_echo = np.zeros_like(y)
        y_echo[delay_samples:] = y[:-delay_samples] * 0.25
        y = y + y_echo

    if add_noise:
        logger("📻 添加磁带底噪...")
        noise_amp = 0.008 * np.max(np.abs(y))
        raw_noise = np.random.normal(0, noise_amp, y.shape)
        b_noise, a_noise = signal.butter(2, 2000 / nyq, btype='low')
        filtered_noise = signal.filtfilt(b_noise, a_noise, raw_noise)
        y = y + filtered_noise

    y = librosa.util.normalize(y)
    logger(f"💾 保存文件: {output_path}")
    sf.write(output_path, y, sr)
    logger("✅ 净化与重塑完成！文件已实现物理与文本双重隐身。\n")
    return output_path
