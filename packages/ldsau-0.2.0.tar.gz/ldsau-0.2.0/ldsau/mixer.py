import os

from pydub import AudioSegment


def mix_audios(input_files, output_file, to_mono=False):
    """将多个音频文件混合叠加为一个音频文件"""
    if not input_files:
        raise ValueError("输入文件列表不能为空")

    audios = []
    for file_path in input_files:
        if os.path.exists(file_path):
            audio = AudioSegment.from_file(file_path)
            audio = audio.set_channels(1) if to_mono else audio.set_channels(2)
            audios.append(audio)
        else:
            print(f"警告: 文件不存在跳过 - {file_path}")

    if not audios:
        raise ValueError("没有有效的音频文件可供混合")

    max_duration = max(len(audio) for audio in audios)
    mixed_audio = AudioSegment.silent(duration=max_duration)

    for audio in audios:
        mixed_audio = mixed_audio.overlay(audio)

    mixed_audio.export(output_file, format="wav")
    return output_file


def extract_accompaniment(folder_path=None, output_file=None, to_mono=False, input_files=None):
    """
    提取伴奏：扫描文件夹或指定文件列表，排除人声轨道后合并剩余轨道
    例子：
    - 文件夹：extract_accompaniment('C:/folder', 'out.wav')
    - 文件列表：extract_accompaniment(output_file='out.wav', input_files=['a.wav', 'b.wav'])
    """
    # 参数校验
    if output_file is None:
        raise ValueError("必须提供 output_file (保存路径)")
    if not folder_path and not input_files:
        raise ValueError("必须提供 folder_path 或 input_files 其中之一")

    valid_exts = ('.wav', '.mp3', '.m4a', '.flac', '.ogg')
    all_candidate_files = []

    # 处理文件夹
    if folder_path:
        if not os.path.isdir(folder_path):
            raise ValueError(f"指定的路径不是文件夹: {folder_path}")
        for f in os.listdir(folder_path):
            if f.lower().endswith(valid_exts):
                # 保存文件的绝对路径
                all_candidate_files.append(os.path.join(folder_path, f))

    # 处理文件列表
    if input_files:
        for f in input_files:
            if f.lower().endswith(valid_exts):
                all_candidate_files.append(f)

    # 去重处理（防止同一个文件被又传文件夹、又传列表添加两次）
    all_candidate_files = list(set(all_candidate_files))

    # 过滤人声轨道
    accompaniment_files = []
    excluded_files = []

    for file_path in all_candidate_files:
        # 获取纯文件名，用于判断是否包含人声字样
        filename = os.path.basename(file_path)
        filename_lower = filename.lower()

        if 'lead vocals' in filename_lower or 'backing vocals' in filename_lower:
            excluded_files.append(filename)
        else:
            accompaniment_files.append(file_path)

    if not accompaniment_files:
        raise ValueError("没有找到可用于伴奏的轨道 (可能全部是人声轨道，或者未包含有效音频文件)")

    print(f"已排除人声轨道: {excluded_files}")
    print(f"正在混合 {len(accompaniment_files)} 个伴奏轨道...")

    return mix_audios(accompaniment_files, output_file, to_mono)
