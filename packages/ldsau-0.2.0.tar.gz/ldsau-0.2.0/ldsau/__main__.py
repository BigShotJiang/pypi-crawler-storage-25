import sys

from ldsau.cli import main

if __name__ == "__main__":
    # 退出时返回正确的状态码
    sys.exit(main())
