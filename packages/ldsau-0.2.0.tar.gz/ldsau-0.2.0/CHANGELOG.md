# 更改日志

此项目的所有显着更改都将记录在此文件中。

此项目遵循[语义化版本](https://semver.org/lang/zh-CN/)。

## TODO
- 无


## [0.2.0]

### Changed

- 合并伴奏的时候支持文件夹和文件列表

## [0.1.1]

### Changed

- 降低需要的最低版本到 Python3.10

## [0.1.0]

初始化仓库

### Added
- 

### Changed
- 

### Fixed
- 

