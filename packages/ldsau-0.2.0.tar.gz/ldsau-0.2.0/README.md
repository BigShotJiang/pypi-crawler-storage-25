# 说明

## 如何本地运行

**创建虚拟环境并同步所有依赖：**
在项目根目录运行：

```sh
uv sync
```

**直接运行命令行工具：**
因为我们在 [project.scripts] 里配置了 ldsau，可以直接使用：

```sh
# 使用 uv 运行 CLI 工具
uv run ldsau bypass "测试.wav" --semi 1.0
uv run ldsau mix -d "./tracks" -o "伴奏.wav"
uv run ldsau process "录音.wav" --auto_norm 1
```

  ### 如何使用 uv 打包并发布到 PyPI？

**打包项目（构建 wheel 和 sdist）：**

```
uv build
```

**发布到 PyPI：**

```
uv publish
```

*需要输入 PyPI 的 API Token。输入后，几秒钟之内，你的工具就会上线 PyPI！*