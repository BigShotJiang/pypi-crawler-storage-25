# Kimi K2.5 Optimizer

Run **Kimi K2.5 (1.1T parameters)** on a single **RTX 3090** at **15+ TPS** with optimized RAM usage for MoE models.

## Features

- **Multi-Framework Support**: llama.cpp, SGLang, vLLM
- **Aggressive RAM Optimization**: LRU expert caching, memory-mapped loading
- **Speculative Decoding**: EAGLE-3 for 2-3x speedup
- **Full Test Suite**: Benchmarks, memory tracking, quality tests, stress tests
- **Optimized for Vast.ai**: Ready-to-use Jupyter notebooks

## Quick Start

```bash
# Install uv (if not already installed)
curl -LsSf https://astral.sh/uv/install.sh | sh

# Clone and setup
cd kimi-k2-optimizer
uv sync

# Activate environment
source .venv/bin/activate

# Install Jupyter kernel
uv run ipython kernel install --user --name=kimi-k2
```

## Usage

### 1. Environment Setup (Notebook 00)
```bash
jupyter notebook notebooks/00_setup.ipynb
```

### 2. Download Model (Notebook 01)
Downloads and quantizes Kimi K2.5:
- GGUF format with imatrix calibration
- IQ4_XS or Q4_K_M quantization

### 3. Run Benchmarks (Notebooks 02-04)
```bash
# llama.cpp
jupyter notebook notebooks/02_llamacpp.ipynb

# SGLang with EAGLE-3
jupyter notebook notebooks/03_sglang.ipynb

# vLLM
jupyter notebook notebooks/04_vllm.ipynb
```

### 4. Compare Results (Notebook 05)
Side-by-side comparison of all frameworks.

### 5. Stress Testing (Notebook 06)
Long conversation and expert cache thrashing tests.

## Project Structure

```
kimi-k2-optimizer/
├── pyproject.toml           # uv dependencies
├── notebooks/               # Jupyter notebooks for vast.ai
│   ├── 00_setup.ipynb
│   ├── 01_download_model.ipynb
│   ├── 02_llamacpp.ipynb
│   ├── 03_sglang.ipynb
│   ├── 04_vllm.ipynb
│   ├── 05_comparison.ipynb
│   └── 06_stress_test.ipynb
├── src/                     # Source code
│   ├── frameworks/          # llama.cpp, SGLang, vLLM wrappers
│   ├── optimization/        # RAM manager, quantizer, mmap loader
│   ├── testing/            # Benchmark, memory, quality, stress tests
│   └── utils/              # Config, downloader, reporting
└── tests/                   # Test suite
```

## RAM Optimization Strategy

For **Kimi K2.5 (1.1T parameters, 384 experts)**:

| RAM Available | Cache Size | Strategy |
|--------------|------------|----------|
| 64GB | 20 experts | Conservative caching |
| 128GB | 100 experts | Balanced caching |
| 256GB+ | 200+ experts | Aggressive caching |

## Expected Performance (RTX 3090)

| Framework | Quantization | TPS | VRAM | Quality |
|-----------|--------------|-----|------|---------|
| llama.cpp | IQ4_XS | 8-12 | 16GB | 95% |
| llama.cpp+SD | Q4_K_M | 12-18 | 20GB | 97% |
| SGLang | FP8 | 10-15 | 20GB | 98% |
| **SGLang+EAGLE3** | FP8 | **20-30** | 20GB | 98% |
| vLLM | AWQ | 8-12 | 22GB | 96% |

## Configuration

Edit `config.json` or use environment variables:

```json
{
  "model_name": "moonshotai/Kimi-K2.5",
  "quantization": "Q4_K_M",
  "vram_gb": 24,
  "ram_gb": 128,
  "llamacpp_layers": 25,
  "sglang_spec_steps": 5,
  "sglang_draft_model": "lightseekorg/kimi-k2.5-eagle3"
}
```

## Testing

```bash
# Run all tests
uv run pytest

# Run specific test category
uv run pytest -m "not slow"
uv run pytest -m "gpu"
uv run pytest tests/test_optimization.py
```

## Vast.ai Deployment

1. **Create Instance**: RTX 3090 or equivalent
2. **Template**: PyTorch with CUDA 12.1
3. **Disk**: 100GB minimum
4. **RAM**: 128GB recommended

### Run on Vast.ai

```bash
# SSH into instance
ssh root@<instance-ip>

# Clone repository
git clone <repo-url>
cd kimi-k2-optimizer

# Setup environment
uv sync

# Launch Jupyter
uv run jupyter notebook --ip=0.0.0.0 --port=8888 --no-browser
```

## Development

```bash
# Install dev dependencies
uv sync --extra dev

# Format code
uv run black src/
uv run isort src/

# Type checking
uv run mypy src/

# Lint
uv run ruff check src/
```

## License

MIT License - See LICENSE file

## Acknowledgments

- [llama.cpp](https://github.com/ggerganov/llama.cpp) by Georgi Gerganov
- [SGLang](https://github.com/sgl-project/sglang) by LMSYS
- [vLLM](https://github.com/vllm-project/vllm) by vLLM Team
- [Kimi K2.5](https://huggingface.co/moonshotai/Kimi-K2.5) by Moonshot AI
