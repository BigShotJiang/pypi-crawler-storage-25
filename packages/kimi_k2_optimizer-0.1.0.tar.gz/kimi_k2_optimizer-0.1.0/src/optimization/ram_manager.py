"""RAM optimization for MoE models using LRU expert caching and memory mapping."""

import logging
import mmap
import os
import pickle
from collections import OrderedDict
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

import numpy as np
import psutil

logger = logging.getLogger(__name__)


class ExpertCache:
    """LRU Cache for MoE experts in CPU RAM."""

    def __init__(
        self,
        max_experts: int = 100,
        expert_size_mb: float = 50.0,
        cache_dir: Optional[str] = None,
    ):
        """Initialize expert cache.
        
        Args:
            max_experts: Maximum number of experts to cache in RAM
            expert_size_mb: Average size of one expert in MB
            cache_dir: Directory for disk fallback (None = no disk cache)
        """
        self.max_experts = max_experts
        self.expert_size_mb = expert_size_mb
        self.cache_dir = Path(cache_dir) if cache_dir else None
        
        # LRU cache: OrderedDict with most recent at end
        self._cache: OrderedDict[int, np.ndarray] = OrderedDict()
        self._access_count: Dict[int, int] = {}
        self._hit_count = 0
        self._miss_count = 0
        
        if self.cache_dir:
            self.cache_dir.mkdir(parents=True, exist_ok=True)

    def get(self, expert_id: int) -> Optional[np.ndarray]:
        """Get expert weights from cache."""
        if expert_id in self._cache:
            # Move to end (most recent)
            self._cache.move_to_end(expert_id)
            self._access_count[expert_id] += 1
            self._hit_count += 1
            return self._cache[expert_id]
        
        self._miss_count += 1
        
        # Try loading from disk cache
        if self.cache_dir:
            disk_path = self.cache_dir / f"expert_{expert_id}.npy"
            if disk_path.exists():
                weights = np.load(disk_path)
                self._add_to_cache(expert_id, weights)
                return weights
        
        return None

    def put(self, expert_id: int, weights: np.ndarray) -> None:
        """Add expert to cache."""
        self._add_to_cache(expert_id, weights)
        
        # Also save to disk for persistence
        if self.cache_dir:
            disk_path = self.cache_dir / f"expert_{expert_id}.npy"
            np.save(disk_path, weights)

    def _add_to_cache(self, expert_id: int, weights: np.ndarray) -> None:
        """Add to LRU cache, evicting if necessary."""
        if expert_id in self._cache:
            self._cache.move_to_end(expert_id)
            return
        
        # Evict oldest if at capacity
        while len(self._cache) >= self.max_experts:
            oldest_id, _ = self._cache.popitem(last=False)
            logger.debug(f"Evicted expert {oldest_id} from cache")
        
        self._cache[expert_id] = weights
        self._access_count[expert_id] = 0

    def get_stats(self) -> Dict[str, Any]:
        """Get cache statistics."""
        total_requests = self._hit_count + self._miss_count
        hit_rate = self._hit_count / total_requests if total_requests > 0 else 0
        
        return {
            "hit_count": self._hit_count,
            "miss_count": self._miss_count,
            "hit_rate": hit_rate,
            "cached_experts": len(self._cache),
            "max_experts": self.max_experts,
            "access_counts": self._access_count.copy(),
        }

    def clear(self) -> None:
        """Clear the cache."""
        self._cache.clear()
        self._access_count.clear()
        self._hit_count = 0
        self._miss_count = 0


class RAMManager:
    """Manage system RAM for MoE model inference."""

    def __init__(
        self,
        total_ram_gb: Optional[int] = None,
        target_utilization: float = 0.85,
        cache_dir: str = "/workspace/kimi_expert_cache",
    ):
        """Initialize RAM manager.
        
        Args:
            total_ram_gb: Total system RAM in GB (auto-detected if None)
            target_utilization: Target RAM utilization (0-1)
            cache_dir: Directory for expert disk cache
        """
        self.total_ram_gb = total_ram_gb or psutil.virtual_memory().total // (1024**3)
        self.target_utilization = target_utilization
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        
        # Calculate adaptive cache size based on available RAM
        self.available_ram_gb = self._calculate_available_ram()
        self.max_cache_experts = self._calculate_max_experts()
        
        # For 32GB systems, use minimal cache
        if self.total_ram_gb <= 32:
            self.max_cache_experts = min(self.max_cache_experts, 10)
        
        self.expert_cache = ExpertCache(
            max_experts=self.max_cache_experts,
            cache_dir=str(self.cache_dir),
        )
        
        logger.info(f"RAM Manager initialized:")
        logger.info(f"  Total RAM: {self.total_ram_gb} GB")
        logger.info(f"  Available for experts: {self.available_ram_gb:.1f} GB")
        logger.info(f"  Max cached experts: {self.max_cache_experts}")
        
        if self.total_ram_gb <= 32:
            logger.warning("LOW RAM MODE: Using aggressive disk offloading")

    def _calculate_available_ram(self) -> float:
        """Calculate RAM available for expert caching."""
        # Reserve RAM for OS, GPU transfer buffers, and other processes
        # For 32GB, reserve 12GB minimum (OS + GPU buffers)
        # For 64GB+, reserve 15%
        if self.total_ram_gb <= 32:
            reserve_gb = 12  # Aggressive reserve for 32GB
        else:
            reserve_gb = max(8, self.total_ram_gb * 0.15)
        
        available = (self.total_ram_gb * self.target_utilization) - reserve_gb
        return max(available, 2)  # At least 2GB for experts

    def _calculate_max_experts(self) -> int:
        """Calculate maximum number of experts to cache."""
        # Kimi K2.5 has 384 experts, each ~50-100MB depending on quantization
        expert_size_mb = 75  # Average with Q4 quantization
        max_experts = int((self.available_ram_gb * 1024) / expert_size_mb)
        
        # For 32GB, be very conservative
        if self.total_ram_gb <= 32:
            return min(max_experts, 10)  # Only 10 experts in RAM
        elif self.total_ram_gb <= 64:
            return min(max_experts, 20)
        
        return min(max_experts, 384)  # Cap at total number of experts

    def get_expert(self, expert_id: int) -> Optional[np.ndarray]:
        """Get expert from cache or load from source."""
        return self.expert_cache.get(expert_id)

    def cache_expert(self, expert_id: int, weights: np.ndarray) -> None:
        """Cache an expert in RAM."""
        self.expert_cache.put(expert_id, weights)

    def get_memory_stats(self) -> Dict[str, Any]:
        """Get current memory statistics."""
        mem = psutil.virtual_memory()
        return {
            "total_gb": mem.total // (1024**3),
            "available_gb": mem.available // (1024**3),
            "used_gb": mem.used // (1024**3),
            "percent": mem.percent,
            "cache_stats": self.expert_cache.get_stats(),
        }

    def optimize_memory(self) -> None:
        """Trigger garbage collection and memory optimization."""
        import gc
        gc.collect()
        
        # If memory pressure is high, reduce cache size
        mem = psutil.virtual_memory()
        if mem.percent > 85:  # Lower threshold for 32GB
            logger.warning(f"High memory usage ({mem.percent}%), clearing expert cache")
            self.expert_cache.clear()
            gc.collect()

    def preload_experts(self, expert_ids: List[int], weights_dict: Dict[int, np.ndarray]) -> None:
        """Preload specific experts into cache."""
        for expert_id in expert_ids:
            if expert_id in weights_dict:
                self.cache_expert(expert_id, weights_dict[expert_id])


class MMapLoader:
    """Memory-mapped file loader for large models."""

    def __init__(self, file_path: Union[str, Path]):
        """Initialize mmap loader.
        
        Args:
            file_path: Path to file to memory-map
        """
        self.file_path = Path(file_path)
        self._mmap: Optional[mmap.mmap] = None
        self._file: Optional[Any] = None

    def open(self) -> None:
        """Open file with memory mapping."""
        self._file = open(self.file_path, 'rb')
        self._mmap = mmap.mmap(self._file.fileno(), 0, access=mmap.ACCESS_READ)
        logger.info(f"Memory-mapped {self.file_path} ({self._mmap.size() // (1024**3):.1f} GB)")

    def close(self) -> None:
        """Close memory-mapped file."""
        if self._mmap:
            self._mmap.close()
            self._mmap = None
        if self._file:
            self._file.close()
            self._file = None

    def read(self, offset: int, size: int) -> bytes:
        """Read bytes from memory-mapped file."""
        if self._mmap is None:
            raise RuntimeError("MMap not opened")
        return self._mmap[offset:offset + size]

    def __enter__(self):
        self.open()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
        return False
