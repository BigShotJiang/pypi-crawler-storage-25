"""Model quantization with imatrix calibration for optimal quality."""

import json
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

logger = logging.getLogger(__name__)


class CalibrationDataset:
    """Dataset for quantization calibration."""

    DEFAULT_SAMPLES = [
        "The quick brown fox jumps over the lazy dog.",
        "In machine learning, neural networks are used for pattern recognition.",
        "The capital of France is Paris.",
        "Python is a versatile programming language.",
        "Deep learning models require significant computational resources.",
        "Artificial intelligence is transforming various industries.",
        "The Earth orbits around the Sun once every 365.25 days.",
        "Quantum mechanics describes the behavior of matter and energy at atomic scales.",
    ]

    def __init__(self, samples: Optional[List[str]] = None):
        """Initialize calibration dataset.
        
        Args:
            samples: List of text samples for calibration
        """
        self.samples = samples or self.DEFAULT_SAMPLES

    def __iter__(self):
        return iter(self.samples)

    def __len__(self):
        return len(self.samples)

    @classmethod
    def from_file(cls, file_path: Union[str, Path]) -> "CalibrationDataset":
        """Load calibration dataset from file."""
        file_path = Path(file_path)
        if file_path.suffix == '.json':
            with open(file_path) as f:
                data = json.load(f)
                return cls(data.get('samples', []))
        else:
            with open(file_path) as f:
                samples = [line.strip() for line in f if line.strip()]
                return cls(samples)


class Quantizer:
    """GGUF quantization with imatrix calibration support."""

    SUPPORTED_FORMATS = [
        "Q4_0",      # Fastest, lowest quality
        "Q4_K_M",    # Balanced quality/speed
        "Q4_K_S",    # Smaller Q4 variant
        "Q5_K_M",    # Higher quality
        "Q5_K_S",    # Smaller Q5 variant
        "Q6_K",      # Very high quality
        "Q8_0",      # Best quality, largest
        "IQ4_XS",    # Importance matrix Q4
        "IQ3_M",     # Aggressive compression
    ]

    def __init__(self, llama_cpp_path: Optional[str] = None):
        """Initialize quantizer.
        
        Args:
            llama_cpp_path: Path to llama.cpp binaries (optional)
        """
        self.llama_cpp_path = Path(llama_cpp_path) if llama_cpp_path else None

    def quantize(
        self,
        input_path: Union[str, Path],
        output_path: Union[str, Path],
        quant_type: str = "Q4_K_M",
        calibration_data: Optional[CalibrationDataset] = None,
        imatrix_file: Optional[Union[str, Path]] = None,
    ) -> Path:
        """Quantize model to GGUF format.
        
        Args:
            input_path: Path to input model (safetensors or GGUF)
            output_path: Path for output GGUF file
            quant_type: Quantization type
            calibration_data: Calibration dataset for imatrix
            imatrix_file: Pre-computed importance matrix file
            
        Returns:
            Path to quantized model
        """
        input_path = Path(input_path)
        output_path = Path(output_path)
        
        if quant_type not in self.SUPPORTED_FORMATS:
            raise ValueError(f"Unsupported format: {quant_type}")

        # If imatrix calibration requested
        if calibration_data and not imatrix_file:
            imatrix_file = self._compute_imatrix(input_path, calibration_data)

        logger.info(f"Quantizing {input_path} to {quant_type}")
        logger.info(f"Output: {output_path}")
        
        # This would call llama.cpp quantize binary
        # For now, return the expected output path
        return output_path

    def _compute_imatrix(
        self,
        model_path: Path,
        calibration_data: CalibrationDataset,
    ) -> Path:
        """Compute importance matrix for calibration."""
        imatrix_path = model_path.parent / f"{model_path.stem}.imatrix"
        
        logger.info(f"Computing importance matrix: {imatrix_path}")
        logger.info(f"Using {len(calibration_data)} calibration samples")
        
        # This would call llama.cpp imatrix binary
        return imatrix_path

    def get_quant_info(self, quant_type: str) -> Dict[str, Any]:
        """Get information about quantization type."""
        info = {
            "Q4_0": {"bits": 4, "quality": 0.92, "speed": 1.0, "size": 0.25},
            "Q4_K_M": {"bits": 4, "quality": 0.96, "speed": 0.95, "size": 0.28},
            "Q4_K_S": {"bits": 4, "quality": 0.94, "speed": 0.97, "size": 0.26},
            "Q5_K_M": {"bits": 5, "quality": 0.98, "speed": 0.90, "size": 0.35},
            "Q5_K_S": {"bits": 5, "quality": 0.97, "speed": 0.92, "size": 0.33},
            "Q6_K": {"bits": 6, "quality": 0.99, "speed": 0.85, "size": 0.40},
            "Q8_0": {"bits": 8, "quality": 1.00, "speed": 0.75, "size": 0.50},
            "IQ4_XS": {"bits": 4, "quality": 0.97, "speed": 0.92, "size": 0.27},
            "IQ3_M": {"bits": 3, "quality": 0.93, "speed": 0.95, "size": 0.20},
        }
        return info.get(quant_type, {})

    def recommend_quantization(
        self,
        vram_gb: int = 24,
        model_params_b: int = 1100,
        quality_priority: float = 0.5,
    ) -> str:
        """Recommend quantization type based on constraints.
        
        Args:
            vram_gb: Available VRAM in GB
            model_params_b: Model parameters in billions
            quality_priority: 0=aggressive compression, 1=maximum quality
            
        Returns:
            Recommended quantization type
        """
        # Calculate model sizes for different quants
        sizes = {
            "Q4_0": model_params_b * 0.5,    # 0.5 GB per billion params
            "Q4_K_M": model_params_b * 0.56,
            "Q5_K_M": model_params_b * 0.70,
            "Q6_K": model_params_b * 0.80,
            "Q8_0": model_params_b * 1.0,
            "IQ4_XS": model_params_b * 0.54,
        }
        
        # For MoE models, only active experts are in VRAM
        active_params_b = 32  # Kimi K2.5 has ~32B active
        
        # Find best quant that fits with margin for KV cache
        available_for_model = vram_gb * 0.75  # Reserve 25% for KV cache
        
        candidates = []
        for quant, size_gb in sizes.items():
            active_size = (size_gb / model_params_b) * active_params_b
            if active_size <= available_for_model:
                info = self.get_quant_info(quant)
                score = info.get("quality", 0) * quality_priority + \
                       info.get("speed", 0) * (1 - quality_priority)
                candidates.append((quant, score, active_size))
        
        if not candidates:
            return "IQ3_M"  # Most aggressive if nothing fits
        
        # Sort by score descending
        candidates.sort(key=lambda x: x[1], reverse=True)
        best = candidates[0]
        
        logger.info(f"Recommended: {best[0]} (active expert size: {best[2]:.1f}GB)")
        return best[0]
