"""Memory-mapped file loader for large models."""

import logging
import mmap
from pathlib import Path
from typing import Any, BinaryIO, Optional, Union

logger = logging.getLogger(__name__)


class MMapLoader:
    """Memory-mapped file loader for efficient large model loading."""

    def __init__(self, file_path: Union[str, Path]):
        """Initialize mmap loader.
        
        Args:
            file_path: Path to file to memory-map
        """
        self.file_path = Path(file_path)
        self._mmap: Optional[mmap.mmap] = None
        self._file: Optional[BinaryIO] = None
        self._size: int = 0

    def open(self) -> None:
        """Open file with memory mapping."""
        if not self.file_path.exists():
            raise FileNotFoundError(f"File not found: {self.file_path}")

        self._file = open(self.file_path, "rb")
        self._size = self.file_path.stat().st_size
        
        # Use mmap for files > 1GB
        if self._size > 1024**3:
            self._mmap = mmap.mmap(self._file.fileno(), 0, access=mmap.ACCESS_READ)
            logger.info(f"Memory-mapped {self.file_path.name} ({self._size // (1024**3):.1f} GB)")
        else:
            logger.info(f"Loaded {self.file_path.name} ({self._size // (1024**2):.1f} MB)")

    def close(self) -> None:
        """Close memory-mapped file."""
        if self._mmap:
            self._mmap.close()
            self._mmap = None
        if self._file:
            self._file.close()
            self._file = None

    def read(self, offset: int, size: int) -> bytes:
        """Read bytes from file."""
        if self._mmap:
            return self._mmap[offset:offset + size]
        elif self._file:
            self._file.seek(offset)
            return self._file.read(size)
        else:
            raise RuntimeError("File not opened")

    def get_size(self) -> int:
        """Get file size in bytes."""
        return self._size

    def __enter__(self):
        self.open()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
        return False
