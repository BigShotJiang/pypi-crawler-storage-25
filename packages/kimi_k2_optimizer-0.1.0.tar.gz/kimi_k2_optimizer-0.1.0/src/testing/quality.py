"""Quality testing with perplexity and benchmark evaluations."""

import logging
import math
from typing import Any, Dict, List, Optional

import numpy as np
import torch
from transformers import AutoTokenizer

logger = logging.getLogger(__name__)


class PerplexityTester:
    """Test model perplexity on evaluation datasets."""

    def __init__(
        self,
        dataset_name: str = "wikitext",
        dataset_config: str = "wikitext-2-raw-v1",
        split: str = "test",
        max_length: int = 512,
        stride: int = 512,
    ):
        """Initialize perplexity tester.
        
        Args:
            dataset_name: HuggingFace dataset name
            dataset_config: Dataset configuration
            split: Dataset split
            max_length: Maximum sequence length
            stride: Stride for sliding window
        """
        self.dataset_name = dataset_name
        self.dataset_config = dataset_config
        self.split = split
        self.max_length = max_length
        self.stride = stride

    def evaluate(
        self,
        model: Any,
        tokenizer: AutoTokenizer,
        num_samples: Optional[int] = None,
    ) -> Dict[str, float]:
        """Evaluate perplexity.
        
        Args:
            model: Language model
            tokenizer: Tokenizer
            num_samples: Number of samples to evaluate (None = all)
            
        Returns:
            Perplexity metrics
        """
        from datasets import load_dataset
        
        logger.info(f"Loading dataset: {self.dataset_name}")
        dataset = load_dataset(self.dataset_name, self.dataset_config, split=self.split)
        
        if num_samples:
            dataset = dataset.select(range(min(num_samples, len(dataset))))
        
        encodings = tokenizer(
            "\n\n".join(dataset["text"]),
            return_tensors="pt",
        )
        
        seq_len = encodings.input_ids.size(1)
        nlls = []
        
        logger.info(f"Evaluating {seq_len} tokens with stride {self.stride}")
        
        prev_end_loc = 0
        for begin_loc in range(0, seq_len, self.stride):
            end_loc = min(begin_loc + self.max_length, seq_len)
            trg_len = end_loc - prev_end_loc
            
            input_ids = encodings.input_ids[:, begin_loc:end_loc].to(model.device)
            target_ids = input_ids.clone()
            target_ids[:, :-trg_len] = -100
            
            with torch.no_grad():
                outputs = model(input_ids, labels=target_ids)
                neg_log_likelihood = outputs.loss * trg_len
            
            nlls.append(neg_log_likelihood)
            
            prev_end_loc = end_loc
            if end_loc == seq_len:
                break
        
        ppl = torch.exp(torch.stack(nlls).sum() / end_loc)
        
        return {
            "perplexity": ppl.item(),
            "tokens_evaluated": end_loc,
        }


class MMLUTester:
    """Test on MMLU benchmark subset."""

    MMLU_SUBJECTS = [
        "abstract_algebra",
        "anatomy",
        "astronomy",
        "business_ethics",
        "clinical_knowledge",
        "college_biology",
        "college_chemistry",
        "college_computer_science",
        "college_mathematics",
        "college_medicine",
        "college_physics",
        "computer_security",
        "conceptual_physics",
        "econometrics",
        "electrical_engineering",
        "elementary_mathematics",
        "formal_logic",
        "global_facts",
        "high_school_biology",
        "high_school_chemistry",
        "high_school_computer_science",
        "high_school_european_history",
        "high_school_geography",
        "high_school_government_and_politics",
        "high_school_macroeconomics",
        "high_school_mathematics",
        "high_school_microeconomics",
        "high_school_physics",
        "high_school_psychology",
        "high_school_statistics",
        "high_school_us_history",
        "high_school_world_history",
        "human_aging",
        "human_sexuality",
        "international_law",
        "jurisprudence",
        "logical_fallacies",
        "machine_learning",
        "management",
        "marketing",
        "medical_genetics",
        "miscellaneous",
        "moral_disputes",
        "moral_scenarios",
        "nutrition",
        "philosophy",
        "prehistory",
        "professional_accounting",
        "professional_law",
        "professional_medicine",
        "professional_psychology",
        "public_relations",
        "security_studies",
        "sociology",
        "us_foreign_policy",
        "virology",
        "world_religions",
    ]

    def __init__(
        self,
        num_questions: int = 100,
        subjects: Optional[List[str]] = None,
    ):
        """Initialize MMLU tester.
        
        Args:
            num_questions: Number of questions to test
            subjects: Specific subjects to test (None = random selection)
        """
        self.num_questions = num_questions
        self.subjects = subjects or self._select_random_subjects()

    def _select_random_subjects(self) -> List[str]:
        """Select random subjects for testing."""
        import random
        return random.sample(self.MMLU_SUBJECTS, min(10, len(self.MMLU_SUBJECTS)))

    def evaluate(
        self,
        generate_fn: Any,
        tokenizer: Optional[Any] = None,
    ) -> Dict[str, Any]:
        """Evaluate on MMLU subset.
        
        Args:
            generate_fn: Function(prompt) -> response
            tokenizer: Optional tokenizer
            
        Returns:
            Evaluation results
        """
        from datasets import load_dataset
        
        correct = 0
        total = 0
        results_by_subject = {}
        
        for subject in self.subjects:
            try:
                dataset = load_dataset("cais/mmlu", subject, split="test")
                
                subject_correct = 0
                subject_total = min(len(dataset), self.num_questions // len(self.subjects))
                
                for i in range(subject_total):
                    item = dataset[i]
                    question = item["question"]
                    choices = item["choices"]
                    answer = item["answer"]
                    
                    prompt = self._format_prompt(question, choices)
                    response = generate_fn(prompt)
                    
                    predicted = self._extract_answer(response)
                    if predicted == answer:
                        correct += 1
                        subject_correct += 1
                    total += 1
                
                results_by_subject[subject] = {
                    "correct": subject_correct,
                    "total": subject_total,
                    "accuracy": subject_correct / subject_total if subject_total > 0 else 0,
                }
                
            except Exception as e:
                logger.warning(f"Error evaluating subject {subject}: {e}")
        
        return {
            "overall_accuracy": correct / total if total > 0 else 0,
            "correct": correct,
            "total": total,
            "by_subject": results_by_subject,
        }

    def _format_prompt(self, question: str, choices: List[str]) -> str:
        """Format MMLU question as prompt."""
        prompt = f"Question: {question}\n\nChoices:\n"
        for i, choice in enumerate(choices):
            prompt += f"{chr(65+i)}. {choice}\n"
        prompt += "\nAnswer:"
        return prompt

    def _extract_answer(self, response: str) -> int:
        """Extract answer choice from response."""
        response = response.strip().upper()
        if response.startswith("A"):
            return 0
        elif response.startswith("B"):
            return 1
        elif response.startswith("C"):
            return 2
        elif response.startswith("D"):
            return 3
        return -1


class QualityTester:
    """Combined quality testing suite."""

    def __init__(
        self,
        model: Any,
        tokenizer: Any,
        perplexity_samples: int = 100,
        mmlu_questions: int = 100,
    ):
        """Initialize quality tester.
        
        Args:
            model: Language model
            tokenizer: Tokenizer
            perplexity_samples: Samples for perplexity test
            mmlu_questions: Questions for MMLU test
        """
        self.model = model
        self.tokenizer = tokenizer
        self.perplexity_tester = PerplexityTester()
        self.mmlu_tester = MMLUTester(num_questions=mmlu_questions)

    def run_all(self, generate_fn: Any) -> Dict[str, Any]:
        """Run all quality tests."""
        logger.info("Running quality tests")
        
        # Perplexity
        try:
            ppl_results = self.perplexity_tester.evaluate(
                self.model,
                self.tokenizer,
                num_samples=100,
            )
        except Exception as e:
            logger.error(f"Perplexity test failed: {e}")
            ppl_results = {"error": str(e)}
        
        # MMLU
        try:
            mmlu_results = self.mmlu_tester.evaluate(generate_fn, self.tokenizer)
        except Exception as e:
            logger.error(f"MMLU test failed: {e}")
            mmlu_results = {"error": str(e)}
        
        return {
            "perplexity": ppl_results,
            "mmlu": mmlu_results,
        }
