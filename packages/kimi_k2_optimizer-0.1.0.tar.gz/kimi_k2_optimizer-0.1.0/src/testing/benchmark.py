"""Benchmarking suite for TPS and TTFT measurements."""

import logging
import time
from typing import Any, Callable, Dict, List, Optional, Tuple

import numpy as np

logger = logging.getLogger(__name__)


class TPSBenchmark:
    """Tokens per second benchmark."""

    def __init__(
        self,
        prompt_lengths: List[int] = None,
        max_tokens: int = 256,
        warmup_runs: int = 2,
        benchmark_runs: int = 5,
    ):
        """Initialize TPS benchmark.
        
        Args:
            prompt_lengths: List of prompt lengths to test
            max_tokens: Tokens to generate
            warmup_runs: Number of warmup iterations
            benchmark_runs: Number of benchmark iterations
        """
        self.prompt_lengths = prompt_lengths or [512, 2048, 4096]
        self.max_tokens = max_tokens
        self.warmup_runs = warmup_runs
        self.benchmark_runs = benchmark_runs

    def run(
        self,
        generate_fn: Callable[[str, int], Tuple[str, Dict]],
        prompt_template: str = "Explain the concept of {topic} in detail.",
        topics: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """Run TPS benchmark.
        
        Args:
            generate_fn: Function(prompt, max_tokens) -> (text, metadata)
            prompt_template: Template for generating prompts
            topics: List of topics for prompts
            
        Returns:
            Benchmark results
        """
        topics = topics or [
            "machine learning",
            "quantum physics",
            "climate change",
            "artificial intelligence",
            "neuroscience",
        ]

        results = {}
        
        for length in self.prompt_lengths:
            logger.info(f"Benchmarking prompt length: {length}")
            
            # Generate prompt of desired length
            prompt = self._generate_prompt(prompt_template, topics, length)
            
            # Warmup
            logger.info(f"  Warmup runs: {self.warmup_runs}")
            for _ in range(self.warmup_runs):
                generate_fn(prompt, self.max_tokens)
            
            # Benchmark runs
            times = []
            tokens_generated = []
            
            logger.info(f"  Benchmark runs: {self.benchmark_runs}")
            for run in range(self.benchmark_runs):
                start = time.perf_counter()
                text, metadata = generate_fn(prompt, self.max_tokens)
                elapsed = time.perf_counter() - start
                
                # Count actual tokens if available, else estimate
                actual_tokens = metadata.get("tokens_generated", len(text.split()))
                tokens_generated.append(actual_tokens)
                times.append(elapsed)
            
            # Calculate statistics
            tps_values = [tokens / t for tokens, t in zip(tokens_generated, times)]
            
            results[f"prompt_{length}"] = {
                "mean_tps": np.mean(tps_values),
                "std_tps": np.std(tps_values),
                "min_tps": np.min(tps_values),
                "max_tps": np.max(tps_values),
                "mean_time": np.mean(times),
                "tokens_per_run": tokens_generated,
            }
        
        return results

    def _generate_prompt(self, template: str, topics: List[str], target_length: int) -> str:
        """Generate a prompt of approximately target length."""
        prompt_parts = []
        current_length = 0
        topic_idx = 0
        
        while current_length < target_length:
            topic = topics[topic_idx % len(topics)]
            part = template.format(topic=topic)
            prompt_parts.append(part)
            current_length += len(part.split())
            topic_idx += 1
        
        # Trim to exact length
        full_prompt = " ".join(prompt_parts)
        words = full_prompt.split()
        return " ".join(words[:target_length])


class TTFTBenchmark:
    """Time to first token benchmark."""

    def __init__(
        self,
        prompt_lengths: List[int] = None,
        warmup_runs: int = 2,
        benchmark_runs: int = 10,
    ):
        """Initialize TTFT benchmark.
        
        Args:
            prompt_lengths: List of prompt lengths to test
            warmup_runs: Number of warmup iterations
            benchmark_runs: Number of benchmark iterations
        """
        self.prompt_lengths = prompt_lengths or [512, 2048, 4096]
        self.warmup_runs = warmup_runs
        self.benchmark_runs = benchmark_runs

    def run(
        self,
        generate_fn: Callable[[str, int], Tuple[str, Dict]],
        prompt_template: str = "Explain {topic}.",
        topics: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """Run TTFT benchmark.
        
        Args:
            generate_fn: Function that supports streaming or returns first token time
            prompt_template: Template for prompts
            topics: List of topics
            
        Returns:
            Benchmark results
        """
        topics = topics or ["physics", "biology", "chemistry", "math", "history"]
        
        results = {}
        
        for length in self.prompt_lengths:
            logger.info(f"Benchmarking TTFT for prompt length: {length}")
            
            # Generate prompt
            words = []
            while len(words) < length:
                for topic in topics:
                    words.extend(prompt_template.format(topic=topic).split())
                    if len(words) >= length:
                        break
            prompt = " ".join(words[:length])
            
            # Warmup
            for _ in range(self.warmup_runs):
                generate_fn(prompt, 1)
            
            # Benchmark
            ttft_times = []
            
            for _ in range(self.benchmark_runs):
                start = time.perf_counter()
                generate_fn(prompt, 1)  # Generate just 1 token
                elapsed = time.perf_counter() - start
                ttft_times.append(elapsed)
            
            results[f"prompt_{length}"] = {
                "mean_ttft_ms": np.mean(ttft_times) * 1000,
                "std_ttft_ms": np.std(ttft_times) * 1000,
                "min_ttft_ms": np.min(ttft_times) * 1000,
                "max_ttft_ms": np.max(ttft_times) * 1000,
            }
        
        return results


class Benchmark:
    """Combined benchmark suite."""

    def __init__(
        self,
        engine: Any,
        prompt_lengths: List[int] = None,
        max_tokens: int = 256,
    ):
        """Initialize benchmark suite.
        
        Args:
            engine: Inference engine with generate() method
            prompt_lengths: Prompt lengths to test
            max_tokens: Max tokens to generate
        """
        self.engine = engine
        self.tps_benchmark = TPSBenchmark(
            prompt_lengths=prompt_lengths,
            max_tokens=max_tokens,
        )
        self.ttft_benchmark = TTFTBenchmark(
            prompt_lengths=prompt_lengths,
        )

    def run_all(self) -> Dict[str, Any]:
        """Run all benchmarks."""
        logger.info("Starting benchmark suite")
        
        def generate_fn(prompt: str, max_tokens: int) -> Tuple[str, Dict]:
            result = self.engine.generate(prompt, max_tokens)
            text = result.get("choices", [{}])[0].get("text", "")
            metadata = {
                "tokens_generated": result.get("usage", {}).get("completion_tokens", 0),
            }
            return text, metadata
        
        tps_results = self.tps_benchmark.run(generate_fn)
        ttft_results = self.ttft_benchmark.run(generate_fn)
        
        return {
            "tps": tps_results,
            "ttft": ttft_results,
            "engine": type(self.engine).__name__,
        }
