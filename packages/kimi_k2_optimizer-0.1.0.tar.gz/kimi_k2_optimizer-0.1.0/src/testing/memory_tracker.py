"""Memory tracking for RAM and VRAM monitoring."""

import logging
import time
from collections import deque
from dataclasses import dataclass
from typing import Any, Deque, Dict, List, Optional

import psutil

logger = logging.getLogger(__name__)


@dataclass
class MemorySnapshot:
    """Memory snapshot at a point in time."""
    timestamp: float
    ram_used_gb: float
    ram_available_gb: float
    ram_percent: float
    vram_used_gb: Optional[float] = None
    vram_total_gb: Optional[float] = None
    vram_percent: Optional[float] = None


class RAMMonitor:
    """Monitor system RAM usage."""

    def __init__(self, history_size: int = 1000):
        """Initialize RAM monitor.
        
        Args:
            history_size: Number of snapshots to keep in history
        """
        self.history_size = history_size
        self.history: Deque[MemorySnapshot] = deque(maxlen=history_size)

    def snapshot(self) -> MemorySnapshot:
        """Take a memory snapshot."""
        mem = psutil.virtual_memory()
        
        snapshot = MemorySnapshot(
            timestamp=time.time(),
            ram_used_gb=mem.used / (1024**3),
            ram_available_gb=mem.available / (1024**3),
            ram_percent=mem.percent,
        )
        
        self.history.append(snapshot)
        return snapshot

    def get_current(self) -> Dict[str, float]:
        """Get current RAM usage."""
        mem = psutil.virtual_memory()
        return {
            "total_gb": mem.total / (1024**3),
            "used_gb": mem.used / (1024**3),
            "available_gb": mem.available / (1024**3),
            "percent": mem.percent,
        }

    def get_history(self) -> List[MemorySnapshot]:
        """Get history of snapshots."""
        return list(self.history)

    def get_peak_usage(self) -> float:
        """Get peak RAM usage in GB."""
        if not self.history:
            return 0.0
        return max(s.ram_used_gb for s in self.history)


class VRAMMonitor:
    """Monitor GPU VRAM usage."""

    def __init__(self, device_id: int = 0, history_size: int = 1000):
        """Initialize VRAM monitor.
        
        Args:
            device_id: GPU device ID
            history_size: Number of snapshots to keep
        """
        self.device_id = device_id
        self.history_size = history_size
        self.history: Deque[MemorySnapshot] = deque(maxlen=history_size)
        self._pynvml_available = False
        
        try:
            import pynvml
            pynvml.nvmlInit()
            self.handle = pynvml.nvmlDeviceGetHandleByIndex(device_id)
            self._pynvml_available = True
        except Exception as e:
            logger.warning(f"pynvml not available: {e}")

    def snapshot(self) -> MemorySnapshot:
        """Take a VRAM snapshot."""
        if not self._pynvml_available:
            return MemorySnapshot(
                timestamp=time.time(),
                ram_used_gb=0,
                ram_available_gb=0,
                ram_percent=0,
            )

        import pynvml
        
        info = pynvml.nvmlDeviceGetMemoryInfo(self.handle)
        
        total_gb = info.total / (1024**3)
        used_gb = info.used / (1024**3)
        percent = (used_gb / total_gb) * 100
        
        snapshot = MemorySnapshot(
            timestamp=time.time(),
            ram_used_gb=0,  # Not tracked here
            ram_available_gb=0,
            ram_percent=0,
            vram_used_gb=used_gb,
            vram_total_gb=total_gb,
            vram_percent=percent,
        )
        
        self.history.append(snapshot)
        return snapshot

    def get_current(self) -> Dict[str, Optional[float]]:
        """Get current VRAM usage."""
        if not self._pynvml_available:
            return {
                "total_gb": None,
                "used_gb": None,
                "free_gb": None,
                "percent": None,
            }

        import pynvml
        info = pynvml.nvmlDeviceGetMemoryInfo(self.handle)
        
        total = info.total / (1024**3)
        used = info.used / (1024**3)
        free = info.free / (1024**3)
        
        return {
            "total_gb": total,
            "used_gb": used,
            "free_gb": free,
            "percent": (used / total) * 100 if total > 0 else 0,
        }

    def get_peak_usage(self) -> float:
        """Get peak VRAM usage in GB."""
        if not self.history:
            return 0.0
        vram_usages = [s.vram_used_gb for s in self.history if s.vram_used_gb is not None]
        return max(vram_usages) if vram_usages else 0.0


class MemoryTracker:
    """Combined RAM and VRAM tracker."""

    def __init__(self, device_id: int = 0):
        """Initialize memory tracker.
        
        Args:
            device_id: GPU device ID for VRAM tracking
        """
        self.ram_monitor = RAMMonitor()
        self.vram_monitor = VRAMMonitor(device_id)
        self._tracking = False

    def start_tracking(self, interval: float = 1.0) -> None:
        """Start continuous tracking in background.
        
        Args:
            interval: Sampling interval in seconds
        """
        import threading
        
        self._tracking = True
        
        def track():
            while self._tracking:
                self.ram_monitor.snapshot()
                self.vram_monitor.snapshot()
                time.sleep(interval)
        
        self._thread = threading.Thread(target=track, daemon=True)
        self._thread.start()

    def stop_tracking(self) -> None:
        """Stop continuous tracking."""
        self._tracking = False
        if hasattr(self, '_thread'):
            self._thread.join(timeout=2)

    def get_summary(self) -> Dict[str, Any]:
        """Get memory usage summary."""
        return {
            "ram": self.ram_monitor.get_current(),
            "vram": self.vram_monitor.get_current(),
            "ram_peak_gb": self.ram_monitor.get_peak_usage(),
            "vram_peak_gb": self.vram_monitor.get_peak_usage(),
        }

    def __enter__(self):
        self.start_tracking()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.stop_tracking()
        return False
