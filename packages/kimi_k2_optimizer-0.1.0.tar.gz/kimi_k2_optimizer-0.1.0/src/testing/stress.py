"""Stress testing for long conversations and expert cache thrashing."""

import logging
import random
import time
from typing import Any, Callable, Dict, List, Optional

import numpy as np

logger = logging.getLogger(__name__)


class LongConversationTest:
    """Test long multi-turn conversations."""

    def __init__(
        self,
        num_turns: int = 50,
        tokens_per_turn: int = 100,
        context_growth: bool = True,
    ):
        """Initialize long conversation test.
        
        Args:
            num_turns: Number of conversation turns
            tokens_per_turn: Tokens to generate per turn
            context_growth: Whether context accumulates across turns
        """
        self.num_turns = num_turns
        self.tokens_per_turn = tokens_per_turn
        self.context_growth = context_growth

    def run(
        self,
        generate_fn: Callable[[str, int], Dict[str, Any]],
        prompts: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """Run long conversation test.
        
        Args:
            generate_fn: Function(prompt, max_tokens) -> result
            prompts: List of prompts for each turn
            
        Returns:
            Test results with stability metrics
        """
        prompts = prompts or self._generate_default_prompts()
        
        conversation_history = []
        turn_times = []
        token_counts = []
        
        logger.info(f"Starting {self.num_turns} turn conversation test")
        
        for turn in range(self.num_turns):
            prompt = prompts[turn % len(prompts)]
            
            if self.context_growth and conversation_history:
                full_prompt = "\n\n".join(conversation_history + [f"User: {prompt}"])
            else:
                full_prompt = prompt
            
            start = time.perf_counter()
            result = generate_fn(full_prompt, self.tokens_per_turn)
            elapsed = time.perf_counter() - start
            
            turn_times.append(elapsed)
            
            # Extract response
            response = result.get("choices", [{}])[0].get("text", "")
            token_count = result.get("usage", {}).get("completion_tokens", 0)
            token_counts.append(token_count)
            
            if self.context_growth:
                conversation_history.append(f"User: {prompt}")
                conversation_history.append(f"Assistant: {response}")
            
            logger.info(f"Turn {turn + 1}: {elapsed:.2f}s, {token_count} tokens")
        
        return {
            "num_turns": self.num_turns,
            "total_time": sum(turn_times),
            "mean_turn_time": np.mean(turn_times),
            "std_turn_time": np.std(turn_times),
            "mean_tokens": np.mean(token_counts),
            "total_tokens": sum(token_counts),
            "stable": max(turn_times) < np.mean(turn_times) * 3,  # No huge spikes
        }

    def _generate_default_prompts(self) -> List[str]:
        """Generate default conversation prompts."""
        return [
            "Explain quantum mechanics briefly.",
            "What are the implications for computing?",
            "How does this relate to cryptography?",
            "Can you give a practical example?",
            "What are the current limitations?",
            "How might this change in the future?",
            "What should I study to understand this better?",
            "Summarize our discussion so far.",
        ]


class ExpertCacheTest:
    """Test expert cache behavior under rapid switching."""

    def __init__(
        self,
        prompts_per_expert: int = 10,
        total_prompts: int = 100,
    ):
        """Initialize expert cache test.
        
        Args:
            prompts_per_expert: Number of prompts targeting each expert
            total_prompts: Total prompts to generate
        """
        self.prompts_per_expert = prompts_per_expert
        self.total_prompts = total_prompts

    def run(
        self,
        generate_fn: Callable[[str, int], Dict[str, Any]],
        get_cache_stats_fn: Callable[[], Dict[str, Any]],
        expert_prompts: Optional[Dict[int, List[str]]] = None,
    ) -> Dict[str, Any]:
        """Run expert cache thrashing test.
        
        Args:
            generate_fn: Generation function
            get_cache_stats_fn: Function returning cache stats
            expert_prompts: Dict mapping expert IDs to prompts
            
        Returns:
            Cache performance metrics
        """
        if expert_prompts is None:
            expert_prompts = self._generate_expert_prompts()
        
        # Interleave prompts from different experts
        all_prompts = []
        for expert_id, prompts in expert_prompts.items():
            for prompt in prompts:
                all_prompts.append((expert_id, prompt))
        
        random.shuffle(all_prompts)
        
        # Run generation
        for expert_id, prompt in all_prompts[:self.total_prompts]:
            generate_fn(prompt, 50)
        
        # Get final cache stats
        stats = get_cache_stats_fn()
        
        return {
            "total_requests": self.total_prompts,
            "cache_hit_rate": stats.get("hit_rate", 0),
            "cached_experts": stats.get("cached_experts", 0),
            "hit_count": stats.get("hit_count", 0),
            "miss_count": stats.get("miss_count", 0),
            "target_hit_rate": 0.6,
            "passed": stats.get("hit_rate", 0) >= 0.6,
        }

    def _generate_expert_prompts(self) -> Dict[int, List[str]]:
        """Generate prompts targeting different knowledge domains."""
        domains = {
            0: ["Explain calculus derivatives.", "What is integration by parts?"],
            1: ["Describe DNA replication.", "How do enzymes work?"],
            2: ["What is machine learning?", "Explain neural networks."],
            3: ["Describe the French Revolution.", "Who was Napoleon?"],
            4: ["What is dark matter?", "Explain black holes."],
            5: ["How do markets work?", "What is inflation?"],
        }
        return {k: v * (self.prompts_per_expert // len(v) + 1) 
                for k, v in domains.items()}


class StressTester:
    """Combined stress testing suite."""

    def __init__(self):
        """Initialize stress tester."""
        self.conversation_test = LongConversationTest()
        self.cache_test = ExpertCacheTest()

    def run_all(
        self,
        generate_fn: Callable,
        get_cache_stats_fn: Callable,
    ) -> Dict[str, Any]:
        """Run all stress tests."""
        logger.info("Starting stress tests")
        
        conv_results = self.conversation_test.run(generate_fn)
        cache_results = self.cache_test.run(generate_fn, get_cache_stats_fn)
        
        return {
            "conversation": conv_results,
            "expert_cache": cache_results,
            "overall_stable": conv_results.get("stable", False) and cache_results.get("passed", False),
        }
