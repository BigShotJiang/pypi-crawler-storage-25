"""Configuration management."""

import json
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


@dataclass
class Config:
    """Configuration for Kimi K2.5 optimizer."""
    
    # Model settings
    model_name: str = "moonshotai/Kimi-K2.5"
    model_path: str = "/workspace/models/Kimi-K2.5"
    
    # Quantization settings
    quantization: str = "IQ4_XS"  # Changed for 32GB - more aggressive compression
    use_imatrix: bool = True
    calibration_file: str = "calibration_data.txt"
    
    # Hardware settings
    gpu_id: int = 0
    vram_gb: int = 24
    ram_gb: int = 32  # Updated default for 32GB systems
    
    # llama.cpp settings - optimized for 32GB RAM
    llamacpp_layers: int = 20  # Reduced from 25 to save RAM
    llamacpp_ctx: int = 2048   # Reduced from 4096 for 32GB
    llamacpp_batch: int = 512  # Reduced batch size
    llamacpp_ubatch: int = 256
    llamacpp_threads: int = 8   # Reduced threads
    llamacpp_cpu_moe: bool = True
    llamacpp_mmap: bool = True  # Enable mmap for low RAM
    llamacpp_mlock: bool = False  # Disable mlock for 32GB
    
    # SGLang settings
    sglang_quant: str = "fp8"
    sglang_draft_model: Optional[str] = "lightseekorg/kimi-k2.5-eagle3"
    sglang_spec_steps: int = 5
    sglang_eagle_topk: int = 4
    sglang_mem_fraction: float = 0.80  # Reduced for 32GB stability
    
    # vLLM settings
    vllm_quant: str = "awq"
    vllm_gpu_util: float = 0.85  # Reduced for 32GB
    vllm_max_model_len: int = 2048  # Reduced context
    
    # Benchmark settings
    prompt_lengths: List[int] = field(default_factory=lambda: [512, 1024])  # Reduced for 32GB
    max_tokens: int = 128  # Reduced for memory constraints
    warmup_runs: int = 1
    benchmark_runs: int = 3
    
    # Test settings
    stress_turns: int = 20   # Reduced for 32GB
    stress_tokens: int = 50
    
    # Cache settings - aggressive for 32GB
    expert_cache_size: int = 10  # Only 10 experts in RAM
    cache_dir: str = "/workspace/kimi_cache"
    use_disk_offload: bool = True  # Always use disk for 32GB
    
    # 32GB-specific optimizations
    aggressive_memory_cleanup: bool = True
    swap_to_disk_threshold: float = 0.80  # Start swapping at 80% RAM
    
    @classmethod
    def from_file(cls, path: str) -> "Config":
        """Load config from JSON file."""
        with open(path) as f:
            data = json.load(f)
        return cls(**data)
    
    def to_file(self, path: str) -> None:
        """Save config to JSON file."""
        with open(path, "w") as f:
            json.dump(self.__dict__, f, indent=2)
    
    def get_llamacpp_config(self) -> Dict[str, Any]:
        """Get llama.cpp specific config."""
        return {
            "model_path": f"{self.model_path}-{self.quantization}.gguf",
            "n_gpu_layers": self.llamacpp_layers,
            "n_ctx": self.llamacpp_ctx,
            "batch_size": self.llamacpp_batch,
            "ubatch_size": self.llamacpp_ubatch,
            "threads": self.llamacpp_threads,
            "cpu_moe": self.llamacpp_cpu_moe,
        }
    
    def get_sglang_config(self) -> Dict[str, Any]:
        """Get SGLang specific config."""
        return {
            "model_path": self.model_name,
            "quantization": self.sglang_quant,
            "speculative_draft": self.sglang_draft_model,
            "speculative_num_steps": self.sglang_spec_steps,
            "speculative_eagle_topk": self.sglang_eagle_topk,
        }
    
    def get_vllm_config(self) -> Dict[str, Any]:
        """Get vLLM specific config."""
        return {
            "model_path": self.model_name,
            "quantization": self.vllm_quant,
            "gpu_memory_utilization": self.vllm_gpu_util,
        }


def load_config(path: Optional[str] = None) -> Config:
    """Load config from file or return default."""
    if path and Path(path).exists():
        return Config.from_file(path)
    return Config()
