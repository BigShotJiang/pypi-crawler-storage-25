"""Reporting and results export."""

import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

import matplotlib.pyplot as plt
import pandas as pd

logger = logging.getLogger(__name__)


class BenchmarkReporter:
    """Generate benchmark reports."""

    def __init__(self, output_dir: str = "/workspace/results"):
        """Initialize reporter.
        
        Args:
            output_dir: Directory for report files
        """
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)

    def create_report(
        self,
        results: Dict[str, Any],
        framework: str,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> str:
        """Create markdown report from results.
        
        Args:
            results: Benchmark results dictionary
            framework: Framework name
            metadata: Additional metadata
            
        Returns:
            Path to generated report
        """
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        report_path = self.output_dir / f"{framework}_report_{timestamp}.md"
        
        lines = [
            f"# {framework} Benchmark Report",
            "",
            f"**Date:** {datetime.now().isoformat()}",
            "",
        ]
        
        if metadata:
            lines.extend(["## Metadata", ""])
            for key, value in metadata.items():
                lines.append(f"- **{key}:** {value}")
            lines.append("")
        
        # TPS Results
        if "tps" in results:
            lines.extend(["## Tokens Per Second", ""])
            for prompt_key, data in results["tps"].items():
                lines.extend([
                    f"### {prompt_key}",
                    f"- Mean TPS: {data.get('mean_tps', 0):.2f}",
                    f"- Std TPS: {data.get('std_tps', 0):.2f}",
                    f"- Min/Max: {data.get('min_tps', 0):.2f} / {data.get('max_tps', 0):.2f}",
                    "",
                ])
        
        # TTFT Results
        if "ttft" in results:
            lines.extend(["## Time to First Token", ""])
            for prompt_key, data in results["ttft"].items():
                lines.extend([
                    f"### {prompt_key}",
                    f"- Mean: {data.get('mean_ttft_ms', 0):.2f} ms",
                    f"- Std: {data.get('std_ttft_ms', 0):.2f} ms",
                    "",
                ])
        
        # Memory Results
        if "memory" in results:
            lines.extend(["## Memory Usage", ""])
            mem = results["memory"]
            lines.extend([
                f"- Peak RAM: {mem.get('ram_peak_gb', 0):.2f} GB",
                f"- Peak VRAM: {mem.get('vram_peak_gb', 0):.2f} GB",
                "",
            ])
        
        with open(report_path, "w") as f:
            f.write("\n".join(lines))
        
        logger.info(f"Report saved to {report_path}")
        return str(report_path)

    def create_comparison_chart(
        self,
        results_dict: Dict[str, Dict[str, Any]],
        metric: str = "mean_tps",
    ) -> str:
        """Create comparison chart across frameworks.
        
        Args:
            results_dict: Dict mapping framework names to results
            metric: Metric to compare
            
        Returns:
            Path to saved chart
        """
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        chart_path = self.output_dir / f"comparison_{metric}_{timestamp}.png"
        
        # Prepare data
        frameworks = list(results_dict.keys())
        data = []
        
        for framework, results in results_dict.items():
            if "tps" in results:
                for prompt_key, prompt_data in results["tps"].items():
                    data.append({
                        "Framework": framework,
                        "Prompt": prompt_key,
                        "Value": prompt_data.get(metric, 0),
                    })
        
        if not data:
            logger.warning("No data for comparison chart")
            return ""
        
        df = pd.DataFrame(data)
        
        # Create chart
        fig, ax = plt.subplots(figsize=(12, 6))
        
        for framework in frameworks:
            framework_data = df[df["Framework"] == framework]
            ax.plot(
                framework_data["Prompt"],
                framework_data["Value"],
                marker="o",
                label=framework,
            )
        
        ax.set_xlabel("Prompt Configuration")
        ax.set_ylabel(metric.replace("_", " ").title())
        ax.set_title(f"Framework Comparison: {metric.replace('_', ' ').title()}")
        ax.legend()
        ax.grid(True, alpha=0.3)
        
        plt.tight_layout()
        plt.savefig(chart_path, dpi=150)
        plt.close()
        
        logger.info(f"Chart saved to {chart_path}")
        return str(chart_path)


class ResultsExporter:
    """Export results to various formats."""

    def __init__(self, output_dir: str = "/workspace/results"):
        """Initialize exporter.
        
        Args:
            output_dir: Directory for exported files
        """
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)

    def to_json(self, results: Dict[str, Any], filename: str) -> str:
        """Export results to JSON."""
        path = self.output_dir / filename
        with open(path, "w") as f:
            json.dump(results, f, indent=2)
        return str(path)

    def to_csv(self, results: Dict[str, Any], filename: str) -> str:
        """Export results to CSV."""
        path = self.output_dir / filename
        
        # Flatten results for CSV
        rows = []
        for framework, data in results.items():
            if isinstance(data, dict):
                for key, value in data.items():
                    if isinstance(value, dict):
                        row = {"framework": framework, "test": key}
                        row.update(value)
                        rows.append(row)
        
        if rows:
            df = pd.DataFrame(rows)
            df.to_csv(path, index=False)
        
        return str(path)
