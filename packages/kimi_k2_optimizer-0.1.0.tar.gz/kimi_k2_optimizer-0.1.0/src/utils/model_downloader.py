"""Model downloader from HuggingFace."""

import logging
from pathlib import Path
from typing import Optional

from huggingface_hub import hf_hub_download, snapshot_download

logger = logging.getLogger(__name__)


class ModelDownloader:
    """Download models from HuggingFace Hub."""

    def __init__(self, cache_dir: str = "/workspace/models"):
        """Initialize downloader.
        
        Args:
            cache_dir: Local directory for downloaded models
        """
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)

    def download_model(
        self,
        repo_id: str,
        local_dir: Optional[str] = None,
        allow_patterns: Optional[list] = None,
        ignore_patterns: Optional[list] = None,
    ) -> str:
        """Download model from HuggingFace.
        
        Args:
            repo_id: HuggingFace repo ID (e.g., "moonshotai/Kimi-K2.5")
            local_dir: Local directory name (default: repo_id.split('/')[-1])
            allow_patterns: Patterns to include
            ignore_patterns: Patterns to exclude
            
        Returns:
            Path to downloaded model
        """
        if local_dir is None:
            local_dir = repo_id.split("/")[-1]
        
        destination = self.cache_dir / local_dir
        
        logger.info(f"Downloading {repo_id} to {destination}")
        
        snapshot_download(
            repo_id=repo_id,
            local_dir=str(destination),
            allow_patterns=allow_patterns,
            ignore_patterns=ignore_patterns,
            local_dir_use_symlinks=False,
        )
        
        logger.info(f"Downloaded to {destination}")
        return str(destination)

    def download_file(
        self,
        repo_id: str,
        filename: str,
        local_dir: Optional[str] = None,
    ) -> str:
        """Download single file from HuggingFace.
        
        Args:
            repo_id: HuggingFace repo ID
            filename: File to download
            local_dir: Local directory
            
        Returns:
            Path to downloaded file
        """
        if local_dir:
            local_dir = Path(local_dir)
            local_dir.mkdir(parents=True, exist_ok=True)
        
        logger.info(f"Downloading {filename} from {repo_id}")
        
        path = hf_hub_download(
            repo_id=repo_id,
            filename=filename,
            local_dir=str(local_dir) if local_dir else None,
            local_dir_use_symlinks=False,
        )
        
        logger.info(f"Downloaded to {path}")
        return path

    def get_gguf_url(self, repo_id: str, filename: str) -> str:
        """Get direct download URL for GGUF file."""
        from huggingface_hub import hf_hub_url
        return hf_hub_url(repo_id=repo_id, filename=filename)
