"""Kimi K2.5 Optimizer - Run 1.1T parameter models on RTX 3090."""

__version__ = "0.1.0"
__author__ = "Kimi K2 Optimizer Team"

from src.frameworks import LLamaCppEngine, SGLangEngine, VLLMEngine
from src.optimization import RAMManager, Quantizer, MMapLoader
from src.testing import Benchmark, MemoryTracker, QualityTester

__all__ = [
    "LLamaCppEngine",
    "SGLangEngine", 
    "VLLMEngine",
    "RAMManager",
    "Quantizer",
    "MMapLoader",
    "Benchmark",
    "MemoryTracker",
    "QualityTester",
]
