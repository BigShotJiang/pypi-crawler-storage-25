"""vLLM engine wrapper with quantization support."""

import logging
import subprocess
import time
from typing import Any, Dict, List, Optional

import requests

logger = logging.getLogger(__name__)


class VLLMEngine:
    """vLLM inference engine with AWQ/GPTQ quantization support."""

    def __init__(
        self,
        model_path: str,
        quantization: Optional[str] = None,
        tensor_parallel_size: int = 1,
        gpu_memory_utilization: float = 0.90,
        max_model_len: int = 4096,
        max_num_seqs: int = 256,
        port: int = 8000,
        dtype: str = "auto",
    ):
        """Initialize vLLM engine.
        
        Args:
            model_path: Path to model or HuggingFace repo
            quantization: Quantization type (awq, gptq, None)
            tensor_parallel_size: Tensor parallelism (1 for single GPU)
            gpu_memory_utilization: GPU memory fraction to use
            max_model_len: Maximum sequence length
            max_num_seqs: Maximum concurrent sequences
            port: Server port
            dtype: Data type (auto, float16, bfloat16)
        """
        self.model_path = model_path
        self.quantization = quantization
        self.tensor_parallel_size = tensor_parallel_size
        self.gpu_memory_utilization = gpu_memory_utilization
        self.max_model_len = max_model_len
        self.max_num_seqs = max_num_seqs
        self.port = port
        self.dtype = dtype
        
        self.process: Optional[subprocess.Popen] = None
        self.base_url = f"http://localhost:{port}"
        
    def start_server(self) -> None:
        """Start vLLM server."""
        cmd = [
            "python", "-m", "vllm.entrypoints.openai.api_server",
            "--model", self.model_path,
            "--tensor-parallel-size", str(self.tensor_parallel_size),
            "--gpu-memory-utilization", str(self.gpu_memory_utilization),
            "--max-model-len", str(self.max_model_len),
            "--max-num-seqs", str(self.max_num_seqs),
            "--port", str(self.port),
            "--dtype", self.dtype,
        ]
        
        if self.quantization:
            cmd.extend(["--quantization", self.quantization])
            
        logger.info(f"Starting vLLM server: {' '.join(cmd)}")
        
        self.process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        
        self._wait_for_server()
        
    def _wait_for_server(self, timeout: int = 180) -> None:
        """Wait for server to be ready."""
        start = time.time()
        while time.time() - start < timeout:
            try:
                response = requests.get(f"{self.base_url}/health", timeout=1)
                if response.status_code == 200:
                    logger.info("vLLM server ready")
                    return
            except requests.exceptions.ConnectionError:
                time.sleep(0.5)
                
        raise TimeoutError("Server failed to start within timeout")
        
    def stop_server(self) -> None:
        """Stop vLLM server."""
        if self.process:
            self.process.terminate()
            try:
                self.process.wait(timeout=15)
            except subprocess.TimeoutExpired:
                self.process.kill()
            self.process = None
            logger.info("vLLM server stopped")
            
    def generate(
        self,
        prompt: str,
        max_tokens: int = 256,
        temperature: float = 0.7,
        top_p: float = 0.9,
        stop: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """Generate text from prompt."""
        payload = {
            "model": self.model_path,
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": max_tokens,
            "temperature": temperature,
            "top_p": top_p,
            "stop": stop or [],
        }
        
        response = requests.post(
            f"{self.base_url}/v1/chat/completions",
            json=payload,
            timeout=300,
        )
        response.raise_for_status()
        
        return response.json()
        
    def generate_batch(
        self,
        prompts: List[str],
        max_tokens: int = 256,
    ) -> List[Dict[str, Any]]:
        """Generate for multiple prompts."""
        payload = {
            "model": self.model_path,
            "messages": [[{"role": "user", "content": p}] for p in prompts],
            "max_tokens": max_tokens,
        }
        
        response = requests.post(
            f"{self.base_url}/v1/chat/completions",
            json=payload,
            timeout=300,
        )
        response.raise_for_status()
        
        return response.json()
        
    def get_metrics(self) -> Dict[str, Any]:
        """Get server metrics."""
        try:
            response = requests.get(f"{self.base_url}/metrics", timeout=5)
            return response.json()
        except:
            return {}
            
    def __enter__(self):
        self.start_server()
        return self
        
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.stop_server()
        return False
