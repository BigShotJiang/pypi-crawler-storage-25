"""SGLang engine wrapper with EAGLE-3 speculative decoding support."""

import logging
import subprocess
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

import requests

logger = logging.getLogger(__name__)


class SGLangEngine:
    """SGLang inference engine with native MoE and EAGLE-3 support."""

    def __init__(
        self,
        model_path: str,
        quantization: Optional[str] = "fp8",
        tp_size: int = 1,
        mem_fraction: float = 0.85,
        max_model_len: int = 4096,
        port: int = 30000,
        speculative_draft: Optional[str] = None,
        speculative_num_steps: int = 5,
        speculative_eagle_topk: int = 4,
    ):
        """Initialize SGLang engine.
        
        Args:
            model_path: Path to model or HuggingFace repo
            quantization: Quantization type (fp8, awq, gptq, None)
            tp_size: Tensor parallelism size
            mem_fraction: GPU memory fraction to use
            max_model_len: Maximum sequence length
            port: Server port
            speculative_draft: Path to EAGLE-3 draft model
            speculative_num_steps: Number of speculative steps
            speculative_eagle_topk: Top-k for EAGLE verification
        """
        self.model_path = model_path
        self.quantization = quantization
        self.tp_size = tp_size
        self.mem_fraction = mem_fraction
        self.max_model_len = max_model_len
        self.port = port
        self.speculative_draft = speculative_draft
        self.speculative_num_steps = speculative_num_steps
        self.speculative_eagle_topk = speculative_eagle_topk
        
        self.process: Optional[subprocess.Popen] = None
        self.base_url = f"http://localhost:{port}"
        
    def start_server(self) -> None:
        """Start SGLang server."""
        cmd = [
            "python", "-m", "sglang.launch_server",
            "--model-path", self.model_path,
            "--tp-size", str(self.tp_size),
            "--mem-fraction-static", str(self.mem_fraction),
            "--max-model-len", str(self.max_model_len),
            "--port", str(self.port),
        ]
        
        if self.quantization:
            cmd.extend(["--quantization", self.quantization])
            
        if self.speculative_draft:
            cmd.extend([
                "--speculative-draft", self.speculative_draft,
                "--speculative-num-steps", str(self.speculative_num_steps),
                "--speculative-eagle-topk", str(self.speculative_eagle_topk),
            ])
            
        logger.info(f"Starting SGLang server: {' '.join(cmd)}")
        
        self.process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        
        self._wait_for_server()
        
    def _wait_for_server(self, timeout: int = 180) -> None:
        """Wait for server to be ready."""
        start = time.time()
        while time.time() - start < timeout:
            try:
                response = requests.get(f"{self.base_url}/health", timeout=1)
                if response.status_code == 200:
                    logger.info("SGLang server ready")
                    return
            except requests.exceptions.ConnectionError:
                time.sleep(0.5)
                
        raise TimeoutError("Server failed to start within timeout")
        
    def stop_server(self) -> None:
        """Stop SGLang server."""
        if self.process:
            self.process.terminate()
            try:
                self.process.wait(timeout=15)
            except subprocess.TimeoutExpired:
                self.process.kill()
            self.process = None
            logger.info("SGLang server stopped")
            
    def generate(
        self,
        prompt: str,
        max_tokens: int = 256,
        temperature: float = 0.7,
        top_p: float = 0.9,
        stop: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """Generate text from prompt."""
        payload = {
            "model": self.model_path,
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": max_tokens,
            "temperature": temperature,
            "top_p": top_p,
            "stop": stop or [],
        }
        
        response = requests.post(
            f"{self.base_url}/v1/chat/completions",
            json=payload,
            timeout=300,
        )
        response.raise_for_status()
        
        return response.json()
        
    def generate_batch(
        self,
        prompts: List[str],
        max_tokens: int = 256,
    ) -> List[Dict[str, Any]]:
        """Generate for multiple prompts."""
        results = []
        for prompt in prompts:
            result = self.generate(prompt, max_tokens)
            results.append(result)
        return results
        
    def get_metrics(self) -> Dict[str, Any]:
        """Get server metrics."""
        try:
            response = requests.get(f"{self.base_url}/metrics", timeout=5)
            return response.json()
        except:
            return {}
            
    def __enter__(self):
        self.start_server()
        return self
        
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.stop_server()
        return False

import logging
import subprocess
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

import requests

logger = logging.getLogger(__name__)


class SGLangEngine:
    """SGLang inference engine with native MoE and EAGLE-3 support."""

    def __init__(
        self,
        model_path: str,
        quantization: Optional[str] = "fp8",
        tp_size: int = 1,
        mem_fraction: float = 0.85,
        max_model_len: int = 4096,
        port: int = 30000,
        speculative_draft: Optional[str] = None,
        speculative_num_steps: int = 5,
        speculative_eagle_topk: int = 4,
    ):
        """Initialize SGLang engine.
        
        Args:
            model_path: Path to model or HuggingFace repo
            quantization: Quantization type (fp8, awq, gptq, None)
            tp_size: Tensor parallelism size
            mem_fraction: GPU memory fraction to use
            max_model_len: Maximum sequence length
            port: Server port
            speculative_draft: Path to EAGLE-3 draft model
            speculative_num_steps: Number of speculative steps
            speculative_eagle_topk: Top-k for EAGLE verification
        """
        self.model_path = model_path
        self.quantization = quantization
        self.tp_size = tp_size
        self.mem_fraction = mem_fraction
        self.max_model_len = max_model_len
        self.port = port
        self.speculative_draft = speculative_draft
        self.speculative_num_steps = speculative_num_steps
        self.speculative_eagle_topk = speculative_eagle_topk
        
        self.process: Optional[subprocess.Popen] = None
        self.base_url = f"http://localhost:{port}"
        
    def start_server(self) -> None:
        """Start SGLang server."""
        cmd = [
            "python", "-m", "sglang.launch_server",
            "--model-path", self.model_path,
            "--tp-size", str(self.tp_size),
            "--mem-fraction-static", str(self.mem_fraction),
            "--max-model-len", str(self.max_model_len),
            "--port", str(self.port),
        ]
        
        if self.quantization:
            cmd.extend(["--quantization", self.quantization])
            
        if self.speculative_draft:
            cmd.extend([
                "--speculative-draft", self.speculative_draft,
                "--speculative-num-steps", str(self.speculative_num_steps),
                "--speculative-eagle-topk", str(self.speculative_eagle_topk),
            ])
            
        logger.info(f"Starting SGLang server: {' '.join(cmd)}")
        
        self.process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        
        self._wait_for_server()
        
    def _wait_for_server(self, timeout: int = 180) -> None:
        """Wait for server to be ready."""
        start = time.time()
        while time.time() - start < timeout:
            try:
                response = requests.get(f"{self.base_url}/health", timeout=1)
                if response.status_code == 200:
                    logger.info("SGLang server ready")
                    return
            except requests.exceptions.ConnectionError:
                time.sleep(0.5)
                
        raise TimeoutError("Server failed to start within timeout")
        
    def stop_server(self) -> None:
        """Stop SGLang server."""
        if self.process:
            self.process.terminate()
            try:
                self.process.wait(timeout=15)
            except subprocess.TimeoutExpired:
                self.process.kill()
            self.process = None
            logger.info("SGLang server stopped")
            
    def generate(
        self,
        prompt: str,
        max_tokens: int = 256,
        temperature: float = 0.7,
        top_p: float = 0.9,
        stop: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """Generate text from prompt."""
        payload = {
            "model": self.model_path,
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": max_tokens,
            "temperature": temperature,
            "top_p": top_p,
            "stop": stop or [],
        }
        
        response = requests.post(
            f"{self.base_url}/v1/chat/completions",
            json=payload,
            timeout=300,
        )
        response.raise_for_status()
        
        return response.json()
        
    def generate_batch(
        self,
        prompts: List[str],
        max_tokens: int = 256,
    ) -> List[Dict[str, Any]]:
        """Generate for multiple prompts."""
        results = []
        for prompt in prompts:
            result = self.generate(prompt, max_tokens)
            results.append(result)
        return results
        
    def get_metrics(self) -> Dict[str, Any]:
        """Get server metrics."""
        try:
            response = requests.get(f"{self.base_url}/metrics", timeout=5)
            return response.json()
        except:
            return {}
            
    def __enter__(self):
        self.start_server()
        return self
        
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.stop_server()
        return False
