"""llama.cpp wrapper with aggressive RAM optimization for MoE models."""

import logging
import subprocess
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

import requests

logger = logging.getLogger(__name__)


class LLamaCppEngine:
    """llama.cpp inference engine optimized for Kimi K2.5 MoE."""

    def __init__(
        self,
        model_path: str,
        n_gpu_layers: int = 25,
        n_ctx: int = 4096,
        batch_size: int = 1024,
        ubatch_size: int = 512,
        threads: int = 16,
        cpu_moe: bool = True,
        use_mmap: bool = True,
        use_mlock: bool = False,
        port: int = 8080,
        quant_type: str = "Q4_K_M",
    ):
        """Initialize llama.cpp engine.
        
        Args:
            model_path: Path to GGUF model file
            n_gpu_layers: Number of layers to offload to GPU
            n_ctx: Context window size
            batch_size: Batch size for prompt processing
            ubatch_size: Micro-batch size
            threads: Number of CPU threads
            cpu_moe: Enable CPU offloading for MoE experts
            use_mmap: Use memory-mapped file loading
            use_mlock: Lock pages in RAM (disable swap)
            port: Server port
            quant_type: Quantization type used
        """
        self.model_path = Path(model_path)
        self.n_gpu_layers = n_gpu_layers
        self.n_ctx = n_ctx
        self.batch_size = batch_size
        self.ubatch_size = ubatch_size
        self.threads = threads
        self.cpu_moe = cpu_moe
        self.use_mmap = use_mmap
        self.use_mlock = use_mlock
        self.port = port
        self.quant_type = quant_type
        
        self.process: Optional[subprocess.Popen] = None
        self.base_url = f"http://localhost:{port}"
        
    def start_server(self) -> None:
        """Start llama.cpp server process."""
        if not self.model_path.exists():
            raise FileNotFoundError(f"Model not found: {self.model_path}")
        
        cmd = [
            "llama-server",
            "-m", str(self.model_path),
            "--port", str(self.port),
            "-ngl", str(self.n_gpu_layers),
            "-c", str(self.n_ctx),
            "-b", str(self.batch_size),
            "--ubatch-size", str(self.ubatch_size),
            "--threads", str(self.threads),
            "--threads-batch", str(self.threads),
        ]
        
        if self.cpu_moe:
            cmd.append("--cpu-moe")
        if self.use_mmap:
            cmd.append("--mmap")
        if self.use_mlock:
            cmd.append("--mlock")
            
        logger.info(f"Starting llama.cpp server: {' '.join(cmd)}")
        
        self.process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        
        # Wait for server to be ready
        self._wait_for_server()
        
    def _wait_for_server(self, timeout: int = 120) -> None:
        """Wait for server to be ready."""
        start = time.time()
        while time.time() - start < timeout:
            try:
                response = requests.get(f"{self.base_url}/health", timeout=1)
                if response.status_code == 200:
                    logger.info("llama.cpp server ready")
                    return
            except requests.exceptions.ConnectionError:
                time.sleep(0.5)
                
        raise TimeoutError("Server failed to start within timeout")
        
    def stop_server(self) -> None:
        """Stop llama.cpp server."""
        if self.process:
            self.process.terminate()
            try:
                self.process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                self.process.kill()
            self.process = None
            logger.info("llama.cpp server stopped")
            
    def generate(
        self,
        prompt: str,
        max_tokens: int = 256,
        temperature: float = 0.7,
        top_p: float = 0.9,
        stop: Optional[List[str]] = None,
        stream: bool = False,
    ) -> Dict[str, Any]:
        """Generate text from prompt.
        
        Args:
            prompt: Input prompt
            max_tokens: Maximum tokens to generate
            temperature: Sampling temperature
            top_p: Nucleus sampling parameter
            stop: Stop sequences
            stream: Whether to stream output
            
        Returns:
            Generation result with text and metadata
        """
        payload = {
            "prompt": prompt,
            "n_predict": max_tokens,
            "temperature": temperature,
            "top_p": top_p,
            "stop": stop or [],
            "stream": stream,
        }
        
        response = requests.post(
            f"{self.base_url}/completion",
            json=payload,
            timeout=300,
        )
        response.raise_for_status()
        
        return response.json()
        
    def generate_batch(
        self,
        prompts: List[str],
        max_tokens: int = 256,
        temperature: float = 0.7,
    ) -> List[Dict[str, Any]]:
        """Generate for multiple prompts."""
        results = []
        for prompt in prompts:
            result = self.generate(prompt, max_tokens, temperature)
            results.append(result)
        return results
        
    def get_metrics(self) -> Dict[str, Any]:
        """Get server metrics."""
        try:
            response = requests.get(f"{self.base_url}/metrics", timeout=5)
            return response.json()
        except:
            return {}
            
    def __enter__(self):
        self.start_server()
        return self
        
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.stop_server()
        return False
