"""Tests for framework wrappers."""

import pytest
from unittest.mock import Mock, patch

from src.frameworks import LLamaCppEngine, SGLangEngine, VLLMEngine


class TestLLamaCppEngine:
    """Test llama.cpp engine."""

    @pytest.mark.skip(reason="Requires actual model file")
    def test_init(self):
        engine = LLamaCppEngine(
            model_path="/tmp/test.gguf",
            n_gpu_layers=25,
            port=8080,
        )
        assert engine.n_gpu_layers == 25
        assert engine.port == 8080

    def test_generate_payload(self):
        with patch("src.frameworks.llamacpp.requests.post") as mock_post:
            mock_response = Mock()
            mock_response.json.return_value = {"choices": [{"text": "test"}]}
            mock_response.raise_for_status = Mock()
            mock_post.return_value = mock_response

            engine = LLamaCppEngine("/tmp/test.gguf", port=8080)
            engine.base_url = "http://localhost:8080"
            
            result = engine.generate("test prompt", max_tokens=50)
            
            mock_post.assert_called_once()
            call_args = mock_post.call_args
            assert call_args[1]["json"]["prompt"] == "test prompt"
            assert call_args[1]["json"]["n_predict"] == 50


class TestSGLangEngine:
    """Test SGLang engine."""

    @pytest.mark.skip(reason="Requires SGLang installation")
    def test_init_with_speculative(self):
        engine = SGLangEngine(
            model_path="moonshotai/Kimi-K2.5",
            speculative_draft="lightseekorg/kimi-k2.5-eagle3",
            speculative_num_steps=5,
        )
        assert engine.speculative_draft is not None
        assert engine.speculative_num_steps == 5


class TestVLLMEngine:
    """Test vLLM engine."""

    @pytest.mark.skip(reason="Requires vLLM installation")
    def test_init_with_quantization(self):
        engine = VLLMEngine(
            model_path="moonshotai/Kimi-K2.5",
            quantization="awq",
            gpu_memory_utilization=0.90,
        )
        assert engine.quantization == "awq"
        assert engine.gpu_memory_utilization == 0.90
