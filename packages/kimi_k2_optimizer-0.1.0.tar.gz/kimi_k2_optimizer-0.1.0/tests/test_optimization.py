"""Tests for optimization modules."""

import numpy as np
import pytest

from src.optimization import ExpertCache, MMapLoader, Quantizer, RAMManager


class TestExpertCache:
    """Test expert cache."""

    def test_cache_hit(self):
        cache = ExpertCache(max_experts=5)
        
        # Add expert
        weights = np.random.randn(100, 100).astype(np.float32)
        cache.put(0, weights)
        
        # Get should hit
        result = cache.get(0)
        assert result is not None
        assert np.array_equal(result, weights)
        
        stats = cache.get_stats()
        assert stats["hit_count"] == 1
        assert stats["miss_count"] == 0

    def test_cache_miss(self):
        cache = ExpertCache(max_experts=5)
        
        # Get non-existent expert
        result = cache.get(999)
        assert result is None
        
        stats = cache.get_stats()
        assert stats["hit_count"] == 0
        assert stats["miss_count"] == 1

    def test_lru_eviction(self):
        cache = ExpertCache(max_experts=2)
        
        # Add 3 experts (only 2 fit)
        for i in range(3):
            cache.put(i, np.random.randn(10, 10).astype(np.float32))
        
        # First one should be evicted
        assert cache.get(0) is None
        assert cache.get(1) is not None
        assert cache.get(2) is not None


class TestRAMManager:
    """Test RAM manager."""

    def test_init_calculates_cache_size(self):
        # Use small RAM for testing
        manager = RAMManager(total_ram_gb=64, cache_dir="/tmp/test_cache")
        
        assert manager.total_ram_gb == 64
        assert manager.max_cache_experts > 0
        assert manager.max_cache_experts <= 384  # Total experts

    def test_memory_stats(self):
        manager = RAMManager(total_ram_gb=64, cache_dir="/tmp/test_cache")
        stats = manager.get_memory_stats()
        
        assert "total_gb" in stats
        assert "used_gb" in stats
        assert "percent" in stats


class TestQuantizer:
    """Test quantizer."""

    def test_supported_formats(self):
        quantizer = Quantizer()
        
        assert "Q4_K_M" in quantizer.SUPPORTED_FORMATS
        assert "Q8_0" in quantizer.SUPPORTED_FORMATS
        assert "IQ4_XS" in quantizer.SUPPORTED_FORMATS

    def test_recommend_quantization(self):
        quantizer = Quantizer()
        
        # 3090 with 24GB VRAM
        result = quantizer.recommend_quantization(
            vram_gb=24,
            model_params_b=1100,
            quality_priority=0.5,
        )
        
        assert result in quantizer.SUPPORTED_FORMATS

    def test_get_quant_info(self):
        quantizer = Quantizer()
        info = quantizer.get_quant_info("Q4_K_M")
        
        assert "bits" in info
        assert "quality" in info
        assert "speed" in info
        assert "size" in info
