"""Integration tests."""

import pytest


@pytest.mark.integration
@pytest.mark.skip(reason="Requires full environment setup")
class TestIntegration:
    """Integration tests requiring full setup."""

    def test_end_to_end_llamacpp(self):
        """Test full llama.cpp workflow."""
        pass

    def test_end_to_end_sglang(self):
        """Test full SGLang workflow."""
        pass

    def test_end_to_end_vllm(self):
        """Test full vLLM workflow."""
        pass
