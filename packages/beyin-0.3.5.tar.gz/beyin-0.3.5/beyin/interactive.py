"""TTY-only interactive helpers for beyin."""

from __future__ import annotations

import importlib
import platform
import re
import shutil
import sys
from collections.abc import Callable
from functools import lru_cache
from pathlib import Path
from typing import Any

import typer

from beyin import __version__
from beyin.authoring import (
    add_source_to_pack,
    build_new_pack_config,
    update_pack_metadata,
    validate_authored_sources,
)
from beyin.config import load_config, write_config, write_public_config
from beyin.settings import (
    BeyinSettings,
    available_setup_choices,
    describe_settings_summary,
    load_settings,
    save_settings,
)
from beyin.runtime_summary import readiness_summary_lines
from beyin.readiness import _check_nltk_punkt_tab_available, _ytdlp_version_ok
from beyin.ui import render_header, render_meta, render_review, render_status


class InteractiveAbort(RuntimeError):
    """Normalized interactive cancellation for later prompt-driven flows."""


def is_interactive_session(stdin: Any = None, stdout: Any = None) -> bool:
    """Return True when both input and output streams are TTY-backed."""
    input_stream = sys.stdin if stdin is None else stdin
    output_stream = sys.stdout if stdout is None else stdout
    return bool(
        getattr(input_stream, "isatty", lambda: False)()
        and getattr(output_stream, "isatty", lambda: False)()
    )


def require_interactive_session() -> None:
    """Raise a reusable abort when interactive prompts are unavailable."""
    if not is_interactive_session():
        raise InteractiveAbort("Interactive prompts require a TTY session.")


def load_prompt_backend():
    """Load InquirerPy lazily so normal CLI imports stay dependency-light."""
    return importlib.import_module("InquirerPy.inquirer")


def normalize_prompt_abort(action: Callable[..., Any], *args: Any, **kwargs: Any) -> Any:
    """Collapse prompt cancellations into one reusable exception type."""
    try:
        return action(*args, **kwargs)
    except (EOFError, KeyboardInterrupt) as exc:
        raise InteractiveAbort("Interactive flow cancelled.") from exc


def _choice(
    value: str,
    name: str | None = None,
    *,
    help_text: str | None = None,
) -> dict[str, str]:
    label = name or value
    if help_text:
        short = help_text if len(help_text) <= 52 else help_text[:51] + "…"
        return {"value": value, "name": f"{label:<16}  |  {short}"}
    return {"value": value, "name": label}


def _echo_lines(lines: list[str]) -> None:
    for line in lines:
        typer.echo(line)


def _print_screen(
    title: str,
    intro_lines: list[str],
    *,
    show_brand: bool = False,
    footer_lines: list[str] | None = None,
) -> None:
    if show_brand:
        sys.stdout.write("\033[2J\033[H")
        sys.stdout.flush()
        _echo_lines(render_header(version=__version__, step=title))
    else:
        typer.echo("")
        _echo_lines([f"  {typer.style(title, bold=True)}"])
    typer.echo("")
    _echo_lines(render_meta(intro_lines))
    if footer_lines:
        typer.echo("")
        _echo_lines(render_meta(footer_lines))
    typer.echo("")


def _print_review(title: str, lines: list[str]) -> None:
    typer.echo("")
    rows: list[tuple[str, str]] = []
    for line in lines:
        if ":" in line:
            key, value = line.split(":", 1)
            rows.append((key.strip(), value.strip()))
        else:
            rows.append(("", line))
    _echo_lines(render_review(title, rows))
    typer.echo("")


def _print_progress_note(title: str, detail: str) -> None:
    _echo_lines(render_status(title, [detail], tone="info"))
    typer.echo("")


@lru_cache(maxsize=1)
def _cached_nltk_punkt_tab_available() -> bool:
    return _check_nltk_punkt_tab_available()


@lru_cache(maxsize=1)
def _cached_ytdlp_version_ok() -> tuple:
    return _ytdlp_version_ok()


@lru_cache(maxsize=8)
def _cached_command_exists(command: str) -> bool:
    return shutil.which(command) is not None


@lru_cache(maxsize=16)
def _cached_optional_module_available(module: str) -> bool:
    try:
        importlib.import_module(module)
        return True
    except ImportError:
        return False


def _import_available(module: str) -> Any:
    if not _cached_optional_module_available(module):
        raise ImportError(module)
    return importlib.import_module(module)


def _print_prompt_hint(text: str | None) -> None:
    if not text:
        return
    lines = [line for line in text.splitlines() if line.strip()]
    if not lines:
        return
    _echo_lines(render_meta(lines))
    typer.echo("")


def _machine_label() -> str:
    system = platform.system()
    machine = platform.machine()
    human = {
        "Darwin": "Mac",
        "Linux": "Linux",
        "Windows": "Windows",
    }.get(system, system)
    return f"{human} ({system.lower()} {machine.lower()})"


def _backend_description(value: str) -> str:
    descriptions = {
        "mlx-whisper": "Apple Silicon. Metal-accelerated transcription.",
        "faster-whisper": "Linux, Windows, or non-Apple-Silicon fallback.",
    }
    return descriptions.get(value, value)


def _model_description(value: str) -> str:
    descriptions = {
        "tiny": "(~75 MB) Fastest. Clean English audio only.",
        "tiny.en": "(~75 MB) English-only. Fastest option when all audio is English.",
        "base": "(~145 MB) Fast. Simple content and English podcasts.",
        "base.en": "(~145 MB) English-only. Better fit for English podcasts and interviews.",
        "small": "(~483 MB) Moderate. Strong default for most use cases and multilingual content.",
        "small.en": "(~483 MB) English-only. Strong default when all speech is English.",
        "medium": "(~1.5 GB) Higher accuracy. Better for harder English, multilingual, accented, or noisy audio.",
        "medium.en": "(~1.5 GB) English-only. Higher English accuracy for harder audio.",
        "large": "(~3 GB) Best quality. Needs 16 GB+ RAM and is the slowest option.",
    }
    return descriptions.get(value, value)


def _print_setup_intro(*, first_run: bool, current: BeyinSettings | None = None) -> None:
    title = "Start your first setup now" if first_run else "Update beyin settings"
    intro_lines = [
        "Turn your favorite content into local queryable packs.",
        f"Detected machine: {_machine_label()}",
    ]
    if not first_run and current is not None:
        intro_lines.extend(
            [
                "",
                "Current settings:",
                *describe_settings_summary(current).splitlines(),
            ]
        )
    footer_lines = [
        "Recommended selections are already preselected for this machine.",
        "You can change these defaults later with `beyin settings`.",
        "Press Ctrl+C at any time to cancel without writing changes.",
    ]
    _print_screen(title, intro_lines, footer_lines=footer_lines, show_brand=True)


def _print_authoring_intro(packs_dir: Path, pack_summaries: list | None = None) -> None:
    if pack_summaries is not None:
        total = len(pack_summaries)
        ready = sum(1 for s in pack_summaries if s.get("status") == "ready")
        if total == 0:
            summary_line = "No packs installed yet."
        elif ready == total:
            summary_line = f"{total} pack{'s' if total != 1 else ''} installed, all ready."
        elif ready > 0:
            summary_line = f"{total} pack{'s' if total != 1 else ''} installed, {ready} ready."
        else:
            needs = total - ready
            summary_line = f"{total} pack{'s' if total != 1 else ''} installed, {needs} need building."
    else:
        pack_count = 0
        if packs_dir.exists():
            pack_count = len(
                [
                    path
                    for path in packs_dir.iterdir()
                    if path.is_dir() and (path / "pack.yaml").exists()
                ]
            )
        summary_line = f"Installed packs detected: {pack_count}"
    _print_screen(
        "What would you like to do?",
        [summary_line, "Choice details appear under the menu."],
        show_brand=True,
    )


def _print_create_intro() -> None:
    _print_screen(
        "Create a new pack",
        [
            "Start with one source or paste several URLs on separate lines.",
        ],
        footer_lines=[
            "After creation, run `beyin build <name>` to index the source into local retrieval memory.",
        ],
        show_brand=True,
    )


def _print_import_intro() -> None:
    _print_screen(
        "Import an existing pack",
        [
            "This keeps `beyin add` semantics intact and only imports an already-authored pack.",
        ],
        show_brand=True,
    )


def _print_manage_intro(pack_count: int) -> None:
    _print_screen(
        "Manage an existing pack",
        [
            f"Available packs: {pack_count}",
            "Update metadata or append another content source without hand-editing YAML.",
        ],
        show_brand=True,
    )


def _prompt(prompt_backend: Any, prompt_type: str, **kwargs: Any) -> Any:
    hint = kwargs.pop("hint", None)
    _print_prompt_hint(hint)
    kwargs.setdefault("instruction", "")
    prompt = getattr(prompt_backend, prompt_type)(
        raise_keyboard_interrupt=True,
        **kwargs,
    )
    return normalize_prompt_abort(prompt.execute)


def _select(
    prompt_backend: Any,
    message: str,
    *,
    choices: list[dict[str, str]],
    default: str | None = None,
) -> str:
    return _prompt(
        prompt_backend,
        "select",
        message=message,
        choices=choices,
        default=default,
    )


def _text(
    prompt_backend: Any,
    message: str,
    *,
    default: str | None = None,
    instruction: str | None = None,
) -> str:
    return str(
        _prompt(
            prompt_backend,
            "text",
            message=message,
            default=default or "",
            instruction="",
            hint=instruction,
        )
    ).strip()


def _required_text(
    prompt_backend: Any,
    message: str,
    *,
    default: str | None = None,
    instruction: str | None = None,
    empty_error: str,
    validator: Callable[[str], str | None] | None = None,
) -> str:
    while True:
        value = _text(
            prompt_backend,
            message,
            default=default,
            instruction=instruction,
        )
        if not value:
            typer.echo(f"Error: {empty_error}", err=True)
            continue
        if validator is not None:
            error = validator(value)
            if error:
                typer.echo(f"Error: {error}", err=True)
                continue
        return value


def _confirm(
    prompt_backend: Any,
    message: str,
    *,
    default: bool = True,
    instruction: str | None = None,
) -> bool:
    return bool(
        _prompt(
            prompt_backend,
            "confirm",
            message=message,
            default=default,
            instruction="",
            hint=instruction,
        )
    )


def _checkbox(
    prompt_backend: Any,
    message: str,
    *,
    choices: list[dict[str, Any]],
    default: list[str] | None = None,
    instruction: str | None = None,
) -> list[str]:
    selected = _prompt(
        prompt_backend,
        "checkbox",
        message=message,
        choices=choices,
        default=default or [],
        transformer=lambda _: "",
        instruction="",
        hint=instruction,
    )
    return [str(value) for value in selected]


def _capability_description(value: str) -> str:
    descriptions = {
        "web": "Articles, blog posts, and readable web pages.",
        "youtube": "Videos and playlists (e.g. YouTube).",
        "podcasts": "Podcasts and RSS or feed-based sources.",
        "local_files": "Text files, PDF, DOCX, PPTX, EPUB, and XLSX.",
        "local_query": "Ask questions locally through Ollama.",
    }
    return descriptions.get(value, value)


def _local_file_type_description(value: str) -> str:
    descriptions = {
        "pdf": "Enable PDF ingestion support.",
        "docx": "Enable Microsoft Word document support.",
        "pptx": "Enable PowerPoint presentation support.",
        "xlsx": "Enable Excel spreadsheet support.",
        "epub": "Enable EPUB ebook support.",
    }
    return descriptions.get(value, value)


def _transcription_needed(capabilities: list[str]) -> bool:
    return any(value in capabilities for value in ("youtube", "podcasts"))


def _setup_followup_lines(settings: BeyinSettings) -> list[str]:
    lines: list[str] = []
    capabilities = set(settings.enabled_capabilities)
    if _transcription_needed(settings.enabled_capabilities):
        lines.append(
            f"Audio/video transcription will use {settings.preferred_transcription_backend} with the {settings.preferred_whisper_model} model."
        )
    if settings.enabled_local_file_types:
        file_types = ", ".join(file_type.upper() for file_type in settings.enabled_local_file_types)
        lines.append(f"Optional local file support selected: {file_types}.")
    if "local_query" in capabilities:
        lines.append(
            f"Local answers are configured for Ollama model `{settings.preferred_llm_model}`."
        )
        lines.append("Ollama stays user-managed. Install it separately if it is not available yet.")
    else:
        lines.append("Local answers are not enabled yet. You can add them later in `beyin settings`.")
    lines.append("Additional file support can be enabled later in `beyin settings`.")
    lines.append("")
    lines.extend(
        readiness_summary_lines(
            settings,
            command_exists=_cached_command_exists,
            import_module=_import_available,
            nltk_punkt_tab_available=_cached_nltk_punkt_tab_available,
            ytdlp_version_ok=_cached_ytdlp_version_ok,
        )
    )
    return lines


def _stage_settings(
    current: BeyinSettings,
    *,
    prompt_backend: Any,
    first_run: bool,
) -> BeyinSettings:
    choices = available_setup_choices()
    _print_setup_intro(first_run=first_run, current=current)
    recommended = choices["recommended"]

    enabled_capabilities = _checkbox(
        prompt_backend,
        "Choose what you want to work with",
        choices=[
            _choice(value, {
                "web": "Web pages",
                "youtube": "Videos",
                "podcasts": "Podcasts",
                "local_files": "Local files",
                "local_query": "Local answers",
            }[value], help_text=_capability_description(value))
            for value in choices["capabilities"]
        ],
        default=current.enabled_capabilities or recommended["enabled_capabilities"],
        instruction="[SPACE] Select or unselect items.\n[ENTER] Continue.",
    )
    if not enabled_capabilities:
        enabled_capabilities = list(recommended["enabled_capabilities"])

    enabled_local_file_types = list(current.enabled_local_file_types)
    if "local_files" in enabled_capabilities:
        enabled_local_file_types = _checkbox(
            prompt_backend,
            "Choose local file types to enable",
            choices=[
                _choice(value, value.upper(), help_text=_local_file_type_description(value))
                for value in choices["local_file_types"]
            ],
            default=current.enabled_local_file_types,
            instruction="Plain text and markdown are included automatically.\n[SPACE] Select or unselect items.\n[ENTER] Continue.",
        )
    else:
        enabled_local_file_types = []

    transcription_backend = current.preferred_transcription_backend
    whisper_model = current.preferred_whisper_model
    if _transcription_needed(enabled_capabilities):
        transcription_backend = _select(
            prompt_backend,
            "Select a transcription backend",
            choices=[
                _choice(value, value, help_text=_backend_description(value))
                for value in choices["transcription_backends"]
            ],
            default=current.preferred_transcription_backend,
        )
        whisper_model = _select(
            prompt_backend,
            "Select the default Whisper model",
            choices=[
                _choice(value, value, help_text=_model_description(value))
                for value in choices["whisper_models"]
            ],
            default=current.preferred_whisper_model,
        )

    llm_model = current.preferred_llm_model
    if "local_query" in enabled_capabilities:
        llm_model = _text(
            prompt_backend,
            "Local model",
            default=current.preferred_llm_model,
            instruction="Used for local answers through Ollama. Ollama itself is managed separately.",
        )

    staged = BeyinSettings(
        version=current.version,
        setup_completed=True,
        enabled_capabilities=enabled_capabilities,
        enabled_local_file_types=enabled_local_file_types,
        preferred_transcription_backend=transcription_backend,
        preferred_whisper_model=whisper_model,
        preferred_llm_model=llm_model or current.preferred_llm_model,
    )
    _print_progress_note(
        "Checking selected dependencies",
        "Reviewing the tools and Python modules needed for the workflows you selected.",
    )
    _print_review(
        "Review setup",
        [
            *describe_settings_summary(staged).splitlines(),
            "",
            *_setup_followup_lines(staged),
        ],
    )
    return staged


def _print_applied_summary(settings: BeyinSettings) -> None:
    next_lines = [
        "These changes apply to future commands.",
        "If you want existing packs to use new transcription or file support settings, run `beyin build <pack>` again.",
        "",
        "Connect beyin over MCP:",
        "  1. beyin mcp-server --help",
        "     See agent-specific MCP setup examples and connection help.",
        "  2. Codex:  codex mcp add beyin -- beyin mcp-server",
        "  3. Claude: claude mcp add beyin -- beyin mcp-server",
        "",
        "Then create and build your first pack:",
        "  4. beyin create",
        "  5. beyin build <pack>",
    ]
    _echo_lines(
        render_status(
            "Setup complete",
            [
                *describe_settings_summary(settings).splitlines(),
                "",
                *_setup_followup_lines(settings),
                "",
                *next_lines,
            ],
            tone="success",
        )
    )


def _run_settings_flow(
    *,
    current: BeyinSettings,
    prompt_backend: Any,
    cancel_message: str,
    first_run: bool,
) -> bool:
    active = current
    while True:
        try:
            staged = _stage_settings(
                active,
                prompt_backend=prompt_backend,
                first_run=first_run,
            )
            confirmed = _confirm(
                prompt_backend,
                "Apply these settings",
                default=True,
                instruction="Choose No to revise your selections. Press Ctrl+C to exit without saving.",
            )
        except InteractiveAbort:
            typer.echo(cancel_message)
            return False

        if confirmed:
            save_settings(staged)
            _print_applied_summary(staged)
            return True

        typer.echo("")
        _echo_lines(
            render_status(
                "Nothing saved yet",
                ["Returning to setup so you can revise the selections."],
                tone="info",
            )
        )
        typer.echo("")
        active = staged


def run_settings_landing(*, prompt_backend: Any | None = None) -> bool:
    """Show current settings first, then route to interactive editing on demand."""
    backend = prompt_backend
    if backend is None:
        require_interactive_session()
        backend = load_prompt_backend()

    current = load_settings()
    _print_screen(
        "beyin Settings",
        [
            *describe_settings_summary(current).splitlines(),
        ],
        show_brand=True,
        footer_lines=[
            "Select Edit settings to reopen the guided setup flow.",
            "Run `beyin check-deps` if you want a full dependency report.",
        ],
    )

    try:
        selection = _select(
            backend,
            "Choose an action",
            choices=[
                _choice("edit", "Edit settings", help_text="Reopen the guided setup flow with current values."),
                _choice("back", "Back", help_text="Leave settings without making changes."),
            ],
            default="edit",
        )
    except InteractiveAbort:
        typer.echo("Settings view cancelled.")
        return False

    if selection != "edit":
        return False

    return _run_settings_flow(
        current=current,
        prompt_backend=backend,
        cancel_message="Settings update cancelled. Settings unchanged.",
        first_run=False,
    )


def run_authoring_menu(
    *,
    packs_dir: Path,
    prompt_backend: Any | None = None,
    import_handler: Callable[[str], Any] | None = None,
    pack_summaries: list | None = None,
) -> bool:
    """Show the interactive create/import/manage chooser for human sessions."""
    backend = prompt_backend
    if backend is None:
        require_interactive_session()
        backend = load_prompt_backend()

    _print_authoring_intro(packs_dir, pack_summaries)
    try:
        selection = _select(
            backend,
            "Choose an action",
            choices=[
                _choice(
                    "create",
                    "Create new pack",
                    help_text="New pack from a URL, YouTube link, or local path.",
                ),
                _choice(
                    "import",
                    "Import existing pack",
                    help_text="Import a pack.yaml from a path or URL.",
                ),
                _choice(
                    "manage",
                    "Manage existing pack",
                    help_text="Edit metadata or add another source.",
                ),
            ],
            default="create",
        )
    except InteractiveAbort:
        typer.echo("Authoring menu cancelled.")
        return False

    if selection == "create":
        return bool(run_create_flow(packs_dir=packs_dir, prompt_backend=backend))
    if selection == "import":
        return bool(
            run_import_flow(
                packs_dir=packs_dir,
                prompt_backend=backend,
                import_handler=import_handler,
            )
        )
    return bool(run_manage_pack_flow(packs_dir=packs_dir, prompt_backend=backend))


def run_create_flow(
    *,
    packs_dir: Path,
    prompt_backend: Any | None = None,
) -> bool:
    """Run the guided new-pack authoring flow."""
    backend = prompt_backend
    if backend is None:
        require_interactive_session()
        backend = load_prompt_backend()

    _print_create_intro()
    try:
        name = _required_text(
            backend,
            "Pack name",
            empty_error="Pack name is required.",
            validator=lambda value: None
            if re.match(r"^[\w.-]+$", value)
            else (
                f"Pack name '{value}' contains invalid characters. "
                "Only alphanumerics, hyphens, underscores, and dots are allowed."
            ),
        )
        description = _text(
            backend,
            "Short description (optional)",
            instruction="Leave blank if you do not want to add a description now.",
        )
        source_input = _text(
            backend,
            "Source URL(s) or local path(s) (optional)",
            instruction="Optional. Leave blank to create an empty pack now, or paste multiple sources on separate lines.",
        )
        if source_input:
            validate_authored_sources(source_input)
        config = build_new_pack_config(
            name=name,
            description=description,
            source_input=source_input,
        )
        review_lines = [
            f"Name: {config.name}",
            f"Description: {config.description or '-'}",
            f"Source count: {len(config.sources)}",
        ]
        if config.sources:
            review_lines.append(f"First source: {config.sources[0].url}")
        else:
            review_lines.append("First source: none yet")
        _print_review("Review pack", review_lines)
        confirmed = _confirm(backend, "Create this pack", default=True)
    except InteractiveAbort:
        typer.echo("Pack creation cancelled. No files were written.")
        return False
    except ValueError as exc:
        typer.echo(f"Error: {exc}", err=True)
        return False

    pack_dir = packs_dir / config.id
    if pack_dir.exists():
        typer.echo(
            f"Error: Pack '{config.id}' already exists.\n"
            f"Choose a new name or run `beyin update {config.id}`.",
            err=True,
        )
        return False

    if not confirmed:
        typer.echo("Pack creation cancelled. No files were written.")
        return False

    write_public_config(config, pack_dir / "pack.yaml")
    _echo_lines(
        render_status(
            f"Created pack '{config.id}'",
            [
                f"Sources saved: {len(config.sources)}",
                "",
                (
                    f"Next step: beyin build {config.id}"
                    if config.sources
                    else f"Next step: beyin add-source {config.id} <path-or-url>"
                ),
                (
                    "Build indexes the source into local expert memory."
                    if config.sources
                    else "Add one or more sources before building this pack."
                ),
            ],
            tone="success",
        )
    )
    return True


def run_import_flow(
    *,
    packs_dir: Path,
    prompt_backend: Any | None = None,
    import_handler: Callable[[str], Any] | None = None,
) -> bool:
    """Prompt for a pack source and delegate to the explicit import command path."""
    del packs_dir  # Reserved for future pack-aware import UX; direct add owns import semantics today.

    backend = prompt_backend
    if backend is None:
        require_interactive_session()
        backend = load_prompt_backend()
    if import_handler is None:
        raise RuntimeError("run_import_flow requires an import handler.")

    _print_import_intro()
    try:
        source = _text(
            backend,
            "Path, URL, or marketplace id for pack.yaml",
            instruction="This uses the same import path as `beyin add`.",
        )
    except InteractiveAbort:
        typer.echo("Pack import cancelled.")
        return False

    import_handler(source)
    return True


def run_manage_pack_flow(
    *,
    packs_dir: Path,
    prompt_backend: Any | None = None,
) -> bool:
    """Run the guided manage flow for basic metadata and source edits."""
    backend = prompt_backend
    if backend is None:
        require_interactive_session()
        backend = load_prompt_backend()

    pack_choices = [
        _choice(path.name)
        for path in sorted(packs_dir.iterdir(), key=lambda item: item.name)
        if path.is_dir() and (path / "pack.yaml").exists()
    ] if packs_dir.exists() else []

    if not pack_choices:
        _echo_lines(
            render_status(
                "No packs installed yet",
                ["Create one with `beyin create` first."],
                tone="warn",
            )
        )
        return False

    _print_manage_intro(len(pack_choices))
    try:
        pack_name = _select(
            backend,
            "Choose a pack to manage",
            choices=pack_choices,
            default=pack_choices[0]["value"],
        )
        pack_dir = packs_dir / pack_name
        current = load_config(pack_dir)
        description = _text(
            backend,
            "Pack description",
            default=current.description,
        )
        add_source = _confirm(backend, "Add another source", default=False)

        staged = update_pack_metadata(current, description=description)
        if add_source:
            source_input = _text(
                backend,
                "New source URL(s) or local path(s)",
                instruction="Local text-like paths stay authored as content sources. Paste multiple entries on separate lines.",
            )
            staged = add_source_to_pack(staged, source_input)

        review_lines = [
            f"Pack: {pack_name}",
            f"Description: {staged.description}",
            f"Source count: {len(staged.sources)}",
        ]
        if add_source:
            review_lines.append(f"Latest source: {staged.sources[-1].url}")
        _print_review("Review pack changes", review_lines)
        confirmed = _confirm(backend, "Apply pack changes", default=True)
    except InteractiveAbort:
        typer.echo("Pack changes cancelled. pack.yaml unchanged.")
        return False
    except ValueError as exc:
        typer.echo(f"Error: {exc}", err=True)
        return False

    if not confirmed:
        typer.echo("Pack changes cancelled. pack.yaml unchanged.")
        return False

    write_config(staged, pack_dir / "pack.yaml")
    _echo_lines(
        render_status(
            f"Updated pack '{pack_name}'",
            [
                f"Next step: beyin build {pack_name}",
                "Rebuild after authoring changes so retrieval uses the latest sources.",
            ],
            tone="success",
        )
    )
    return True


def run_initial_setup_flow(*, prompt_backend: Any | None = None) -> bool:
    """Run the one-time initial setup flow and persist confirmed settings."""
    backend = prompt_backend
    if backend is None:
        require_interactive_session()
        backend = load_prompt_backend()
    return _run_settings_flow(
        current=load_settings(),
        prompt_backend=backend,
        cancel_message="Setup cancelled. Settings unchanged.",
        first_run=True,
    )


def run_settings_flow(*, prompt_backend: Any | None = None) -> bool:
    """Run the explicit editable settings flow and persist confirmed settings."""
    backend = prompt_backend
    if backend is None:
        require_interactive_session()
        backend = load_prompt_backend()
    return _run_settings_flow(
        current=load_settings(),
        prompt_backend=backend,
        cancel_message="Settings update cancelled. Settings unchanged.",
        first_run=False,
    )
