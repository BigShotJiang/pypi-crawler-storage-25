"""
Protocol defining the cache backend contract for permission caching.

Any class implementing these methods can be used as a cache backend
for RBACService — no inheritance required (structural subtyping).
"""

from typing import Optional, Protocol, runtime_checkable

from .cache import PermissionCacheEntry


@runtime_checkable
class CacheStore(Protocol):
    """Structural protocol for permission cache backends."""

    @property
    def ttl(self) -> float: ...

    def get_user(self, user_uuid: str) -> Optional[PermissionCacheEntry]: ...

    def set_user(self, user_uuid: str, entry: PermissionCacheEntry) -> None: ...

    def invalidate_user(self, user_uuid: str) -> None: ...

    def invalidate_users(self, user_uuids: list) -> None: ...

    def invalidate_all(self) -> None: ...

    def close(self) -> None: ...
