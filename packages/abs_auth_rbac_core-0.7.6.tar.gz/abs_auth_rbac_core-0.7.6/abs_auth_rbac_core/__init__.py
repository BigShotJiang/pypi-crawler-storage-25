"""
abs-auth-rbac-core - Authentication and RBAC for FastAPI applications.

v0.6.4 - Added ping_cache() and close() to RBACService.
         RedisCache.ping() safely returns False on connection errors.
         RedisCache.close() no longer raises on disconnected connections.

v0.6.3 - Added pluggable cache backend support (Redis or custom).
         Eager cache refresh on local permission/role changes.

Changes in 0.6.3:
  - Added CacheStore protocol for custom cache implementations
  - Added RedisCache and RedisCacheConfig for Redis-backed caching
  - RBACService now accepts cache_store or redis_config parameters
  - In-memory LRU cache remains the default (no breaking changes)
  - Redis is an optional dependency: pip install abs-auth-rbac-core[redis]
  - Added ttl read-only property to PermissionCache
  - Local permission changes eagerly reload affected users' cache entries
    instead of deleting them, eliminating the DB query on the next request
  - With shared cache (Redis), Service Bus publish and receive are both
    skipped — the eager reload is already visible to all servers via Redis

v0.6.0 - Replaced Casbin policy engine with in-memory per-user permission cache
          and targeted Azure Service Bus cache invalidation.

Changes in 0.6.0:
  - Removed Casbin, casbin-sqlalchemy-adapter, and casbin-redis-watcher dependencies
  - Added PermissionCache: thread-safe per-user LRU cache with TTL expiration
  - Added CacheInvalidationNotifier: targeted invalidation via Azure Service Bus
    (user-level, role-level, or full invalidation instead of full policy reload)
  - Permission checks are now cache-first with SQL fallback (sub-ms cache hits)
  - Cross-server sync invalidates only affected users (~200-500ms vs 3-4s full reload)
  - Constructor accepts **kwargs for backward compatibility with previous configs
  - Removed: gov_casbin_rule table (no longer read/written), policy.conf, watcher.py
  - Unchanged: decorators, auth middleware, JWT functions, all relational models
"""

__version__ = "0.6.4"
