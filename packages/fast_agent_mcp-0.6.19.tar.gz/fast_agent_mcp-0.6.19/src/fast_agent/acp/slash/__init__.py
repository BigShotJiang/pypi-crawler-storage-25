"""ACP slash command package."""
