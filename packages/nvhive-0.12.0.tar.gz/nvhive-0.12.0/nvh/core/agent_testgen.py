"""Test Generation Agent — reads source, identifies gaps, writes pytest tests.

Automates: read target -> identify untested code -> generate tests -> run
pytest -> retry once on failure.
"""

from __future__ import annotations

import json
import logging
import re
import subprocess
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from nvh.core.agent_loop import run_agent_loop  # noqa: F401 (public re-export)
from nvh.core.agentic import AgentConfig
from nvh.core.tools import ToolRegistry

logger = logging.getLogger(__name__)

_TEST_GEN_SYSTEM = """\
You are a test generation expert. Write comprehensive pytest tests:
- Use pytest (never unittest).
- Mock external dependencies (network, filesystem, databases) with unittest.mock.
- Test both happy path and error/edge cases.
- Use descriptive names: test_<function>_<scenario>.
- One logical assertion per test when practical.
- Add a one-line docstring to each test explaining what it verifies.
- Keep tests self-contained. Output ONLY valid Python, no commentary.\
"""


@dataclass
class CoverageGap:
    """A source file with low test coverage."""

    file: str
    current_coverage: float
    missing_lines: list[int] = field(default_factory=list)


@dataclass
class TestGenReport:
    """Result of a test generation run."""

    target_file: str
    test_file: str
    tests_generated: int
    tests_passing: int
    tests_failing: int
    coverage_before: float | None
    coverage_after: float | None
    duration_ms: int
    model_used: str


def find_coverage_gaps(working_dir: str | Path) -> list[CoverageGap]:
    """Run pytest-cov and return files with <50% coverage.

    Returns an empty list if pytest-cov is not installed or the run fails.
    """
    wd = Path(working_dir)
    try:
        subprocess.run(
            ["python", "-m", "pytest", "--cov=nvh", "--cov-report=json", "-q"],
            cwd=wd, capture_output=True, text=True, timeout=120,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return []
    cov_path = wd / "coverage.json"
    if not cov_path.exists():
        return []
    try:
        data = json.loads(cov_path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return []
    gaps: list[CoverageGap] = []
    for fname, info in data.get("files", {}).items():
        pct = info.get("summary", {}).get("percent_covered", 100.0)
        if pct < 50:
            gaps.append(CoverageGap(
                file=fname, current_coverage=pct,
                missing_lines=info.get("missing_lines", []),
            ))
    return sorted(gaps, key=lambda g: g.current_coverage)


async def generate_tests(
    engine: Any,
    config: AgentConfig,
    working_dir: str | Path,
    target: str,
    on_step: Any = None,
) -> TestGenReport:
    """Generate pytest tests for *target* and iterate until they pass.

    *target* can be a file path (``"nvh/core/council.py"``),
    ``"--coverage-gaps"``, or ``"--for-pr"``.
    """
    t0 = time.monotonic()
    wd = Path(working_dir)
    tools = ToolRegistry(workspace=str(wd))
    model_used = config.worker_model or "default"

    def _emit(phase: str, detail: str) -> None:
        if on_step is not None:
            on_step(phase, detail)

    # Phase 0: resolve target
    if target == "--coverage-gaps":
        gaps = find_coverage_gaps(wd)
        if not gaps:
            return _empty_report("(no gaps)", model_used, t0)
        target = gaps[0].file
    elif target == "--for-pr":
        proc = subprocess.run(
            ["git", "diff", "--name-only", "HEAD~1", "--", "*.py"],
            cwd=wd, capture_output=True, text=True, timeout=15,
        )
        changed = [f for f in proc.stdout.strip().splitlines()
                    if f and not f.startswith("test")]
        if not changed:
            return _empty_report("(no changed files)", model_used, t0)
        target = changed[0]

    test_file = _test_file_for(target)
    _emit("read", target)

    # Phase 1: read target source via tool registry
    read_result = await tools.execute("read_file", {"path": target})
    if not read_result.success:
        return _empty_report(target, model_used, t0)
    source_code = read_result.output

    # Phase 2: identify untested code via orchestrator
    _emit("analyze", "identifying untested functions")
    analysis = await engine.query(
        prompt=(
            f"Analyze this Python module and list all functions/methods that "
            f"need tests. Note key scenarios.\n\n```python\n{source_code}\n```"
        ),
        model=config.orchestrator_model,
        provider=config.orchestrator_provider,
        system_prompt="List untested functions and key test scenarios.",
    )

    # Phase 3: generate test code via worker
    _emit("generate", "writing pytest tests")
    mod = _module_path(target)
    gen_resp = await engine.query(
        prompt=(
            f"Write pytest tests for this module.\n\n"
            f"# What to test:\n{analysis.content}\n\n"
            f"# Source:\n```python\n{source_code}\n```\n\n"
            f"Import as: from {mod} import *"
        ),
        model=config.worker_model, provider=config.worker_provider,
        system_prompt=_TEST_GEN_SYSTEM,
    )
    test_code = _extract_code(gen_resp.content)
    model_used = gen_resp.model

    # Phase 4: write test file via tool registry
    _emit("write", test_file)
    await tools.execute("write_file", {"path": test_file, "content": test_code})

    # Phase 5: run pytest to verify
    _emit("verify", "running pytest")
    total, passed, failed, output = _run_pytest(wd, test_file)

    # Phase 6: retry once on failure
    if failed > 0:
        _emit("retry", "fixing failing tests")
        fix_resp = await engine.query(
            prompt=(
                f"Fix these failing tests.\n\n"
                f"```python\n{test_code}\n```\n\n"
                f"Errors:\n```\n{output[-2000:]}\n```\n\n"
                f"Output ONLY the corrected full test file."
            ),
            model=config.worker_model, provider=config.worker_provider,
            system_prompt=_TEST_GEN_SYSTEM,
        )
        test_code = _extract_code(fix_resp.content)
        await tools.execute("write_file", {"path": test_file, "content": test_code})
        total, passed, failed, output = _run_pytest(wd, test_file)

    elapsed = int((time.monotonic() - t0) * 1000)
    return TestGenReport(
        target_file=target, test_file=test_file,
        tests_generated=total, tests_passing=passed, tests_failing=failed,
        coverage_before=None, coverage_after=None,
        duration_ms=elapsed, model_used=model_used,
    )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _run_pytest(wd: Path, test_file: str) -> tuple[int, int, int, str]:
    """Run pytest on a single file, return (total, passed, failed, output)."""
    try:
        proc = subprocess.run(
            ["python", "-m", "pytest", test_file, "-v"],
            cwd=wd, capture_output=True, text=True, timeout=60,
        )
        combined = proc.stdout + proc.stderr
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return 0, 0, 0, "pytest execution failed"
    passed = int(m.group(1)) if (m := re.search(r"(\d+) passed", combined)) else 0
    failed = int(m.group(1)) if (m := re.search(r"(\d+) failed", combined)) else 0
    return passed + failed, passed, failed, combined


def _test_file_for(target: str) -> str:
    """Derive test file path: 'nvh/core/foo.py' -> 'nvh/core/test_foo.py'."""
    p = Path(target)
    return str(p.parent / f"test_{p.stem}.py")


def _extract_code(content: str) -> str:
    """Extract Python code from LLM response, stripping markdown fences."""
    m = re.search(r"```(?:python)?\s*\n(.*?)```", content, re.DOTALL)
    return m.group(1).strip() if m else content.strip()


def _module_path(file_path: str) -> str:
    """Convert 'nvh/core/council.py' to 'nvh.core.council'."""
    return file_path.replace("/", ".").replace("\\", ".").removesuffix(".py")


def _empty_report(target: str, model: str, t0: float) -> TestGenReport:
    """Return a zero-result report."""
    return TestGenReport(
        target_file=target, test_file="", tests_generated=0,
        tests_passing=0, tests_failing=0,
        coverage_before=None, coverage_after=None,
        duration_ms=int((time.monotonic() - t0) * 1000), model_used=model,
    )
