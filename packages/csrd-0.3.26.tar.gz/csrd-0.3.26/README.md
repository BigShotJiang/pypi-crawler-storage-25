# csrd

Meta package for the csrd API framework ecosystem.

## What it installs today

- `csrd-versioning`

This package is intentionally minimal for now. Additional `csrd-*` dependencies can be added as the curated bundle strategy is finalized.
