from __future__ import annotations

from pathlib import Path

import yaml


def _write_source_stage_config(root: Path) -> None:
    source = root / "vllm_omni" / "model_executor" / "stage_configs"
    source.mkdir(parents=True, exist_ok=True)
    config = {
        "stage_args": [
            {
                "engine_args": {
                    "model_stage": "audio_generation",
                    "gpu_memory_utilization": 0.8,
                    "max_num_seqs": 32,
                    "max_model_len": 4096,
                }
            },
            {
                "engine_args": {
                    "model_stage": "audio_tokenizer",
                    "gpu_memory_utilization": 0.1,
                    "max_num_seqs": 32,
                    "max_num_batched_tokens": 65536,
                    "max_model_len": 65536,
                }
            },
        ]
    }
    (source / "voxtral_tts.yaml").write_text(yaml.safe_dump(config, sort_keys=False), encoding="utf-8")


def test_write_stage_config_uses_stage_specific_spark_defaults(tmp_path: Path, monkeypatch):
    from vox_voxtral import runtime as runtime_module

    purelib = tmp_path / "purelib"
    _write_source_stage_config(purelib)

    monkeypatch.setenv("VOX_HOME", str(tmp_path / "vox-home"))
    monkeypatch.setattr(runtime_module, "_purelib", lambda python_bin: purelib)

    output = runtime_module._write_stage_config(Path("/tmp/fake-python"))
    config = yaml.safe_load(output.read_text(encoding="utf-8"))

    generation_args = config["stage_args"][0]["engine_args"]
    tokenizer_args = config["stage_args"][1]["engine_args"]

    assert generation_args["gpu_memory_utilization"] == 0.4
    assert generation_args["max_num_seqs"] == 1
    assert generation_args["enforce_eager"] is True
    assert generation_args["max_model_len"] == 2048

    assert tokenizer_args["gpu_memory_utilization"] == 0.1
    assert tokenizer_args["max_num_seqs"] == 1
    assert tokenizer_args["max_num_batched_tokens"] == 8192
    assert tokenizer_args["max_model_len"] == 8192


def test_write_stage_config_honors_stage_specific_env_overrides(tmp_path: Path, monkeypatch):
    from vox_voxtral import runtime as runtime_module

    purelib = tmp_path / "purelib"
    _write_source_stage_config(purelib)

    monkeypatch.setenv("VOX_HOME", str(tmp_path / "vox-home"))
    monkeypatch.setenv("VOX_VOXTRAL_GENERATION_GPU_MEMORY_UTILIZATION", "0.35")
    monkeypatch.setenv("VOX_VOXTRAL_TOKENIZER_GPU_MEMORY_UTILIZATION", "0.2")
    monkeypatch.setattr(runtime_module, "_purelib", lambda python_bin: purelib)

    output = runtime_module._write_stage_config(Path("/tmp/fake-python"))
    config = yaml.safe_load(output.read_text(encoding="utf-8"))

    generation_args = config["stage_args"][0]["engine_args"]
    tokenizer_args = config["stage_args"][1]["engine_args"]

    assert generation_args["gpu_memory_utilization"] == 0.35
    assert tokenizer_args["gpu_memory_utilization"] == 0.2


def test_build_env_prepends_runtime_and_app_torch_lib_dirs(tmp_path: Path, monkeypatch):
    from vox_voxtral import runtime as runtime_module

    runtime_purelib = tmp_path / "runtime-purelib"
    app_purelib = tmp_path / "app-purelib"
    runtime_torch_lib = runtime_purelib / "torch" / "lib"
    app_torch_lib = app_purelib / "torch" / "lib"
    runtime_torch_lib.mkdir(parents=True)
    app_torch_lib.mkdir(parents=True)

    monkeypatch.setattr(runtime_module, "_purelib", lambda python_bin: runtime_purelib)
    monkeypatch.setattr(runtime_module, "_app_purelib", lambda: app_purelib)
    monkeypatch.setenv("PYTHONPATH", "/existing/pythonpath")
    monkeypatch.setenv("LD_LIBRARY_PATH", "/existing/ld")

    env = runtime_module._build_env(
        Path("/tmp/fake-python"),
        extra_pythonpaths=["/extra/pythonpath"],
    )

    assert env["PYTHONPATH"] == "/extra/pythonpath:/existing/pythonpath"
    assert env["LD_LIBRARY_PATH"] == f"{runtime_torch_lib}:{app_torch_lib}:/existing/ld"


def test_build_env_includes_system_cuda_paths_when_present(tmp_path: Path, monkeypatch):
    from vox_voxtral import runtime as runtime_module

    runtime_purelib = tmp_path / "runtime-purelib"
    app_purelib = tmp_path / "app-purelib"
    runtime_torch_lib = runtime_purelib / "torch" / "lib"
    app_torch_lib = app_purelib / "torch" / "lib"
    runtime_torch_lib.mkdir(parents=True)
    app_torch_lib.mkdir(parents=True)

    real_isdir = runtime_module.os.path.isdir

    def fake_isdir(path: str) -> bool:
        if path in {"/usr/local/cuda/lib64", "/usr/local/cuda/targets/aarch64-linux/lib"}:
            return True
        return real_isdir(path)

    monkeypatch.setattr(runtime_module, "_purelib", lambda python_bin: runtime_purelib)
    monkeypatch.setattr(runtime_module, "_app_purelib", lambda: app_purelib)
    monkeypatch.setattr(runtime_module.os.path, "isdir", fake_isdir)

    env = runtime_module._build_env(Path("/tmp/fake-python"))

    assert env["LD_LIBRARY_PATH"] == (
        f"{runtime_torch_lib}:{app_torch_lib}:/usr/local/cuda/lib64:/usr/local/cuda/targets/aarch64-linux/lib"
    )


def test_default_torchvision_version_handles_2_8():
    from vox_voxtral import runtime as runtime_module

    assert runtime_module._default_torchvision_version("2.8.0") == "0.23.0"


def test_gpu_torch_index_url_prefers_official_cu129(monkeypatch):
    from vox_voxtral import runtime as runtime_module

    class TorchVersion:
        cuda = "12.9"

    class Torch:
        version = TorchVersion()

    monkeypatch.delenv("VOX_VOXTRAL_TORCH_INDEX_URL", raising=False)
    monkeypatch.setattr(runtime_module.platform, "machine", lambda: "aarch64")
    monkeypatch.setitem(__import__("sys").modules, "torch", Torch())

    assert runtime_module._gpu_torch_index_url() == "https://download.pytorch.org/whl/cu129"


def test_has_gpu_torch_rejects_wheel_without_active_device_arch(monkeypatch, tmp_path: Path):
    from vox_voxtral import runtime as runtime_module

    payload = {
        "version": "2.8.0",
        "cuda": "12.9",
        "available": True,
        "arch_list": ["sm_87"],
        "capability": "sm_121",
    }

    monkeypatch.setattr(
        runtime_module,
        "_run",
        lambda *args, **kwargs: type("Result", (), {"returncode": 0, "stdout": yaml.safe_dump(payload)})(),
    )

    assert runtime_module._has_gpu_torch(tmp_path / "python") is False
