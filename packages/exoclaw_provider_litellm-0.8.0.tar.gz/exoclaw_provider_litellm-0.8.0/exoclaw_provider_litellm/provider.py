"""LiteLLM provider implementation for exoclaw."""

import asyncio
import contextlib
import hashlib
import os
import secrets
import string
import time
from typing import Any

import json_repair
import litellm
import structlog
from exoclaw.providers.types import (
    ContextWindowExceededError,
    LLMResponse,
    ResponseFormat,
    ToolCallRequest,
)
from litellm import acompletion

logger = structlog.get_logger()

# Standard chat-completion message keys.
_ALLOWED_MSG_KEYS = frozenset(
    {"role", "content", "tool_calls", "tool_call_id", "name", "reasoning_content"}
)
_ANTHROPIC_EXTRA_KEYS = frozenset({"thinking_blocks"})
_ALNUM = string.ascii_letters + string.digits


def _short_tool_id() -> str:
    """Generate a 9-char alphanumeric ID compatible with all providers (incl. Mistral)."""
    return "".join(secrets.choice(_ALNUM) for _ in range(9))


def _sanitize_empty_content(messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Replace empty text content that causes provider 400 errors."""
    result: list[dict[str, Any]] = []
    for msg in messages:
        content = msg.get("content")

        if isinstance(content, str) and not content:
            clean = dict(msg)
            clean["content"] = (
                None if (msg.get("role") == "assistant" and msg.get("tool_calls")) else "(empty)"
            )
            result.append(clean)
            continue

        if isinstance(content, list):
            filtered = [
                item
                for item in content
                if not (
                    isinstance(item, dict)
                    and item.get("type") in ("text", "input_text", "output_text")
                    and not item.get("text")
                )
            ]
            if len(filtered) != len(content):
                clean = dict(msg)
                if filtered:
                    clean["content"] = filtered
                elif msg.get("role") == "assistant" and msg.get("tool_calls"):
                    clean["content"] = None
                else:
                    clean["content"] = "(empty)"
                result.append(clean)
                continue

        if isinstance(content, dict):
            clean = dict(msg)
            clean["content"] = [content]
            result.append(clean)
            continue

        result.append(msg)
    return result


def _sanitize_request_messages(
    messages: list[dict[str, Any]],
    allowed_keys: frozenset[str],
) -> list[dict[str, Any]]:
    """Keep only provider-safe message keys and normalize assistant content."""
    sanitized = []
    for msg in messages:
        clean = {k: v for k, v in msg.items() if k in allowed_keys}
        if clean.get("role") == "assistant" and "content" not in clean:
            clean["content"] = None
        sanitized.append(clean)
    return sanitized


def _normalize_tool_call_id(tool_call_id: Any) -> Any:
    """Normalize tool_call_id to a provider-safe 9-char alphanumeric form."""
    if not isinstance(tool_call_id, str):
        return tool_call_id
    if len(tool_call_id) == 9 and tool_call_id.isalnum():
        return tool_call_id
    return hashlib.sha1(tool_call_id.encode()).hexdigest()[:9]


def _is_anthropic(model: str) -> bool:
    """Return True when the model is an Anthropic/Claude model."""
    lower = model.lower()
    return "claude" in lower or lower.startswith("anthropic/")


def _apply_anthropic_cache_control_to_system(
    messages: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Stamp cache_control on the system message content for Anthropic prompt caching.

    Anthropic requires explicit cache_control markers — caching is never automatic.
    Converts string system content to a list block and stamps the last block with
    cache_control: {type: ephemeral} so the stable system prompt is cached.
    """
    result = []
    for msg in messages:
        if msg.get("role") == "system":
            content = msg.get("content")
            new_msg = dict(msg)
            if isinstance(content, str):
                new_msg["content"] = [
                    {"type": "text", "text": content, "cache_control": {"type": "ephemeral"}}
                ]
            elif isinstance(content, list) and content:
                new_content: list[Any] = list(content)
                last: dict[str, Any] = {**new_content[-1]}
                last["cache_control"] = {"type": "ephemeral"}
                new_content[-1] = last
                new_msg["content"] = new_content
            result.append(new_msg)
        else:
            result.append(msg)
    return result


def _apply_anthropic_cache_control_to_tools(
    tools: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Stamp cache_control on the last tool definition for Anthropic prompt caching.

    Tool definitions are stable across turns so marking the last one causes
    Anthropic to cache the entire tool block.
    """
    if not tools:
        return tools
    result = list(tools)
    last = dict(result[-1])
    last["cache_control"] = {"type": "ephemeral"}
    result[-1] = last
    return result


class LiteLLMProvider:
    """
    LLM provider using LiteLLM for multi-provider support.

    Implements the exoclaw LLMProvider protocol without inheriting from any
    exoclaw class.

    Supports OpenRouter, Anthropic, OpenAI, Gemini, and many other providers
    through a unified interface.

    When a ``router`` is supplied, chat requests are dispatched through
    ``litellm.Router`` — model names are resolved against the router's
    ``model_list`` as group aliases and the router handles provider
    selection, fallbacks, retries, and cooldowns. Without a router the
    provider falls back to calling ``litellm.acompletion`` directly, which
    is the single-deployment path.
    """

    def __init__(
        self,
        api_key: str | None = None,
        api_base: str | None = None,
        default_model: str = "anthropic/claude-opus-4-5",
        extra_headers: dict[str, str] | None = None,
        stream: bool = False,
        stream_ttft_timeout: float = 15.0,
        model_max_concurrent: dict[str, int] | None = None,
        model_extra_body: dict[str, dict[str, Any]] | None = None,
        router: "litellm.Router | None" = None,
    ):
        self.api_key = api_key
        self.api_base = api_base
        self.default_model = default_model
        self.extra_headers = extra_headers or {}
        self._stream = stream
        self._stream_ttft_timeout = stream_ttft_timeout
        self._router = router
        self._model_semaphores: dict[str, asyncio.Semaphore] = {
            model: asyncio.Semaphore(n)
            for model, n in (model_max_concurrent or {}).items()
            if n > 0
        }
        # Per-model extra_body merged into each request. The typical use
        # case is OpenRouter provider routing
        # (``{"provider": {"order": [...], "allow_fallbacks": True}}``),
        # but litellm passes the whole dict through so any provider-
        # specific extension fits here.
        self._model_extra_body: dict[str, dict[str, Any]] = dict(model_extra_body or {})

        if api_key and api_base:
            # Custom / gateway endpoint — set as OpenAI-compatible
            os.environ.setdefault("OPENAI_API_KEY", api_key)
        elif api_key:
            # Best-effort: set common env vars so LiteLLM can pick up the key
            os.environ.setdefault("OPENAI_API_KEY", api_key)
            os.environ.setdefault("ANTHROPIC_API_KEY", api_key)
            os.environ.setdefault("OPENROUTER_API_KEY", api_key)

        litellm.suppress_debug_info = True  # type: ignore[assignment]
        litellm.drop_params = True

        if callbacks_env := os.environ.get("LITELLM_CALLBACKS"):
            litellm.callbacks = [c.strip() for c in callbacks_env.split(",") if c.strip()]  # type: ignore[misc]

        self._llm_logging = os.environ.get("LLM_LOGGING", "").lower() == "true"
        self._llm_log_truncate = int(os.environ.get("LLM_LOG_TRUNCATE", "500"))

    def _sanitize_messages(
        self,
        messages: list[dict[str, Any]],
        extra_keys: frozenset[str] = frozenset(),
    ) -> list[dict[str, Any]]:
        """Strip non-standard keys and normalize tool call IDs."""
        allowed = _ALLOWED_MSG_KEYS | extra_keys
        sanitized = _sanitize_request_messages(messages, allowed)
        id_map: dict[str, str] = {}

        def map_id(value: Any) -> Any:
            if not isinstance(value, str):
                return value
            return id_map.setdefault(value, _normalize_tool_call_id(value))

        for clean in sanitized:
            if isinstance(clean.get("tool_calls"), list):
                normalized_tool_calls = []
                for tc in clean["tool_calls"]:
                    if not isinstance(tc, dict):
                        normalized_tool_calls.append(tc)
                        continue
                    tc_clean = dict(tc)
                    tc_clean["id"] = map_id(tc_clean.get("id"))
                    normalized_tool_calls.append(tc_clean)
                clean["tool_calls"] = normalized_tool_calls

            if "tool_call_id" in clean and clean["tool_call_id"]:
                clean["tool_call_id"] = map_id(clean["tool_call_id"])
        return sanitized

    async def chat(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        model: str | None = None,
        max_tokens: int = 4096,
        temperature: float = 0.7,
        reasoning_effort: str | None = None,
        response_format: ResponseFormat | None = None,
    ) -> LLMResponse:
        """Send a chat completion request via LiteLLM."""
        resolved_model = model or self.default_model
        is_anthropic = _is_anthropic(resolved_model)
        extra_keys = _ANTHROPIC_EXTRA_KEYS if is_anthropic else frozenset()

        max_tokens = max(1, max_tokens)

        kwargs: dict[str, Any] = {
            "model": resolved_model,
            "messages": self._sanitize_messages(
                _sanitize_empty_content(messages), extra_keys=extra_keys
            ),
            "max_tokens": max_tokens,
            "temperature": temperature,
        }

        if self.api_key:
            kwargs["api_key"] = self.api_key

        if self.api_base:
            kwargs["api_base"] = self.api_base

        if self.extra_headers:
            kwargs["extra_headers"] = self.extra_headers

        if reasoning_effort:
            kwargs["reasoning_effort"] = reasoning_effort
            kwargs["drop_params"] = True

        if response_format:
            kwargs["response_format"] = response_format

        if tools:
            kwargs["tools"] = tools
            kwargs["tool_choice"] = "auto"

        if model_eb := self._model_extra_body.get(resolved_model):
            # Deep-merge NOT implemented on purpose: the config owns the
            # whole ``extra_body`` for a given model, so taking the dict
            # verbatim keeps behavior predictable. If a caller has passed
            # ``extra_body`` in kwargs (not currently a chat() param but
            # a future option), we let the caller's dict win per
            # least-surprise.
            kwargs.setdefault("extra_body", model_eb)

        # OpenRouter treats the ``user`` field as a conversation-affinity
        # hint for sticky provider routing — requests with the same user
        # preferentially route to the provider that served prior calls
        # so prompt caches stay warm. ``session.key`` is already bound
        # on structlog contextvars by ``AgentLoop._process_message``
        # for every turn, and contextvars propagate through asyncio
        # tasks, so grabbing it here avoids threading a dedicated
        # parameter down through chat/process_turn/_run_agent_loop.
        #
        # Explicit caller override always wins: if chat() gets a future
        # ``user`` kwarg we would defer to that. For now there is no
        # such kwarg and we read solely from contextvars.
        if "user" not in kwargs:
            ctx = structlog.contextvars.get_contextvars()
            session_key = ctx.get("session.key")
            if session_key:
                kwargs["user"] = str(session_key)

        if is_anthropic:
            kwargs["messages"] = _apply_anthropic_cache_control_to_system(kwargs["messages"])
            if "tools" in kwargs:
                kwargs["tools"] = _apply_anthropic_cache_control_to_tools(kwargs["tools"])

        if self._llm_logging:
            logger.info(
                "llm_request",
                **{
                    "llm.model": resolved_model,
                    "llm.message.count": len(kwargs["messages"]),
                    "llm.tool.count": len(tools) if tools else 0,
                },
            )
            for msg in kwargs["messages"]:
                role = msg.get("role", "?")
                content = msg.get("content") or ""
                if isinstance(content, list):
                    content = " ".join(b.get("text", "") for b in content if isinstance(b, dict))
                text = str(content).replace("\n", "\\n")
                if self._llm_log_truncate >= 0:
                    text = text[: self._llm_log_truncate]
                logger.info("llm_request_msg", **{"message.role": role, "message.text": text})

        try:
            sem = self._model_semaphores.get(resolved_model)
            t0 = time.monotonic()

            async with sem if sem else contextlib.nullcontext():
                if self._stream:
                    response = await self._stream_to_completion(kwargs)
                elif self._router is not None:
                    # Router owns api_key / api_base / extra_headers per
                    # deployment in ``model_list`` — stripping them here
                    # prevents our single-provider defaults from overriding
                    # the deployment's own params.
                    router_kwargs = {
                        k: v
                        for k, v in kwargs.items()
                        if k not in ("api_key", "api_base", "extra_headers")
                    }
                    response = await self._router.acompletion(**router_kwargs)
                else:
                    response = await acompletion(**kwargs)

            elapsed = time.monotonic() - t0

            if self._llm_logging:
                usage = response.usage
                choice = response.choices[0]
                content = getattr(choice.message, "content", None) or ""
                tool_calls = getattr(choice.message, "tool_calls", None) or []
                cached_tokens = 0
                if usage:
                    details = getattr(usage, "prompt_tokens_details", None)
                    cached_tokens = getattr(details, "cached_tokens", 0) or 0
                    if not cached_tokens:
                        cached_tokens = getattr(usage, "cache_read_input_tokens", 0) or 0
                cache_created = getattr(usage, "cache_creation_input_tokens", 0) if usage else 0
                logger.info(
                    "llm_response",
                    **{
                        "llm.model": resolved_model,
                        "llm.token.prompt": usage.prompt_tokens if usage else "?",
                        "llm.token.completion": usage.completion_tokens if usage else "?",
                        "llm.token.total": usage.total_tokens if usage else "?",
                        "llm.token.cached": cached_tokens,
                        "llm.token.cache_created": cache_created,
                        "llm.duration_s": round(elapsed, 2),
                        "llm.finish_reason": choice.finish_reason,
                        "llm.tools": [tc.function.name for tc in tool_calls],
                        "llm.stream": self._stream,
                    },
                )

            return self._parse_response(response)
        except litellm.ContextWindowExceededError:
            raise ContextWindowExceededError("Prompt exceeds model context window")

    async def _stream_to_completion(self, kwargs: dict[str, Any]) -> Any:
        """Stream the response and reassemble into a non-streaming response object.

        Applies a TTFT (time-to-first-token) timeout: if the streaming connection
        isn't established within ``stream_ttft_timeout`` seconds, raises
        ``TimeoutError`` so Temporal can retry on a fresh connection.

        Routes through ``self._router.acompletion`` when a router is configured
        so streaming inherits the same fallback / cooldown behavior as the
        non-streaming path.
        """
        kwargs["stream"] = True
        if self._router is not None:
            router_kwargs = {
                k: v for k, v in kwargs.items() if k not in ("api_key", "api_base", "extra_headers")
            }
            _call = self._router.acompletion(**router_kwargs)
        else:
            _call = acompletion(**kwargs)
        try:
            stream = await asyncio.wait_for(_call, timeout=self._stream_ttft_timeout)
        except asyncio.TimeoutError:
            raise TimeoutError(
                f"LLM stream: connection not established within {self._stream_ttft_timeout}s (TTFT timeout)"
            )

        chunks: list[Any] = []
        async for chunk in stream:
            chunks.append(chunk)

        if not chunks:
            raise TimeoutError("LLM stream returned no chunks")

        return litellm.stream_chunk_builder(chunks)

    def _parse_response(self, response: Any) -> LLMResponse:
        """Parse LiteLLM response into our standard format."""
        choice = response.choices[0]
        message = choice.message
        content = message.content
        finish_reason = choice.finish_reason

        # Some providers split content and tool_calls across multiple choices.
        raw_tool_calls = []
        for ch in response.choices:
            msg = ch.message
            if hasattr(msg, "tool_calls") and msg.tool_calls:
                raw_tool_calls.extend(msg.tool_calls)
                if ch.finish_reason in ("tool_calls", "stop"):
                    finish_reason = ch.finish_reason
            if not content and msg.content:
                content = msg.content

        tool_calls = []
        for tc in raw_tool_calls:
            args = tc.function.arguments
            if isinstance(args, str):
                args = json_repair.loads(args)

            tool_calls.append(
                ToolCallRequest(
                    id=_short_tool_id(),
                    name=tc.function.name,
                    arguments=args,  # type: ignore[arg-type]
                )
            )

        usage = {}
        if hasattr(response, "usage") and response.usage:
            usage = {
                "prompt_tokens": response.usage.prompt_tokens,
                "completion_tokens": response.usage.completion_tokens,
                "total_tokens": response.usage.total_tokens,
            }

        reasoning_content = getattr(message, "reasoning_content", None) or None
        thinking_blocks = getattr(message, "thinking_blocks", None) or None

        return LLMResponse(
            content=content,
            tool_calls=tool_calls,
            finish_reason=finish_reason or "stop",
            usage=usage,
            reasoning_content=reasoning_content,
            thinking_blocks=thinking_blocks,
        )

    def get_default_model(self) -> str:
        """Get the default model."""
        return self.default_model
