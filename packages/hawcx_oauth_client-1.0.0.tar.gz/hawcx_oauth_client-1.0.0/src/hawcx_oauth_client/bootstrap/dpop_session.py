"""DPoP-aware HTTP session that auto-attaches proof headers per request."""

from __future__ import annotations

from urllib.parse import urlparse, urlunparse

import requests
from cryptography.hazmat.primitives.asymmetric.ec import EllipticCurvePrivateKey

from hawcx_oauth_client._crypto import create_dpop_proof


class DPoPSession:
    """A requests.Session wrapper that automatically generates and attaches DPoP proofs.

    Usage:
        token = bootstrap_client.authenticate_with_dpop()
        session = DPoPSession(token.access_token, token.dpop_private_key)
        resp = session.get("https://api.example.com/resource")
        resp = session.post("https://api.example.com/action", json={"key": "value"})
    """

    def __init__(self, access_token: str, dpop_private_key: EllipticCurvePrivateKey):
        self._token = access_token
        self._key = dpop_private_key
        self._session = requests.Session()

    def request(self, method: str, url: str, **kwargs) -> requests.Response:
        parsed = urlparse(url)
        normalized_url = urlunparse((parsed.scheme, parsed.netloc, parsed.path, "", "", ""))
        proof = create_dpop_proof(
            method=method.upper(),
            url=normalized_url,
            private_key=self._key,
            access_token=self._token,
        )
        headers = kwargs.pop("headers", {}) or {}
        headers["Authorization"] = f"DPoP {self._token}"
        headers["DPoP"] = proof
        kwargs["headers"] = headers
        return self._session.request(method, url, **kwargs)

    def get(self, url: str, **kwargs) -> requests.Response:
        return self.request("GET", url, **kwargs)

    def post(self, url: str, **kwargs) -> requests.Response:
        return self.request("POST", url, **kwargs)

    def put(self, url: str, **kwargs) -> requests.Response:
        return self.request("PUT", url, **kwargs)

    def delete(self, url: str, **kwargs) -> requests.Response:
        return self.request("DELETE", url, **kwargs)

    def patch(self, url: str, **kwargs) -> requests.Response:
        return self.request("PATCH", url, **kwargs)

    def close(self):
        self._session.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
