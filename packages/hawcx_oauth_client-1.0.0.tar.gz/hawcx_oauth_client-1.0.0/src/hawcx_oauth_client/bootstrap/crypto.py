"""Cryptographic utilities for the bootstrap authentication flow.

Provides:
- ES256 client assertion signing (private_key_jwt / RFC 7523)
- Re-exports of shared crypto primitives (JWK thumbprint, DPoP proof, etc.)
"""

from __future__ import annotations

import time
import uuid
from typing import Optional

import jwt

from hawcx_oauth_client._crypto import (
    b64url_encode,
    b64url_decode,
    compute_jwk_thumbprint,
    create_dpop_proof,
    ec_public_jwk,
    generate_dpop_keypair,
    load_ec_private_key,
)
from .exceptions import BootstrapSigningError

# Re-export for backward compatibility
__all__ = [
    "b64url_encode",
    "b64url_decode",
    "compute_jwk_thumbprint",
    "create_client_assertion",
    "create_dpop_proof",
    "ec_private_key_to_jwk",
    "ec_public_jwk",
    "generate_dpop_keypair",
    "load_ec_private_key",
]


def ec_private_key_to_jwk(key, kid: str) -> dict:
    """Export EC public key as JWK with kid, use, and alg fields.

    This is a bootstrap-specific wrapper around ec_public_jwk that adds
    kid, use, and alg metadata.
    """
    jwk = ec_public_jwk(key)
    jwk["kid"] = kid
    jwk["use"] = "sig"
    jwk["alg"] = "ES256"
    return jwk


def create_client_assertion(
    client_id: str,
    audience: str,
    nonce: str,
    scope: str,
    private_key_pem: str,
    kid: str,
    origin: Optional[str] = None,
    ttl: int = 120,
    dpop_jwk: Optional[dict] = None,
) -> str:
    """Create an ES256-signed private_key_jwt client assertion (RFC 7523).

    Args:
        client_id: The client identifier (used as iss and sub).
        audience: The audience for the assertion (exchange endpoint URL).
        nonce: The challenge nonce from /bootstrap/challenge.
        scope: Space-delimited scope string.
        private_key_pem: ES256 private key in PEM format.
        kid: Key ID matching the registered public key.
        origin: Optional web origin for binding.
        ttl: Assertion lifetime in seconds (max 120).
        dpop_jwk: Optional DPoP public JWK dict. If provided, the assertion
            will include a ``cnf.jkt`` claim binding the DPoP key to this
            assertion, preventing key-swap attacks.

    Returns:
        Signed JWT string (compact serialization).
    """
    try:
        key = load_ec_private_key(private_key_pem)
    except Exception as e:
        raise BootstrapSigningError(f"Failed to load signing key: {e}")

    now = int(time.time())
    payload = {
        "iss": client_id,
        "sub": client_id,
        "aud": audience,
        "iat": now,
        "exp": now + min(ttl, 120),
        "jti": str(uuid.uuid4()),
        "nonce": nonce,
        "scope": scope,
    }
    if origin:
        payload["origin"] = origin
    if dpop_jwk:
        payload["cnf"] = {"jkt": compute_jwk_thumbprint(dpop_jwk)}

    try:
        return jwt.encode(
            payload,
            key,
            algorithm="ES256",
            headers={"kid": kid},
        )
    except Exception as e:
        raise BootstrapSigningError(f"Failed to sign assertion: {e}")
