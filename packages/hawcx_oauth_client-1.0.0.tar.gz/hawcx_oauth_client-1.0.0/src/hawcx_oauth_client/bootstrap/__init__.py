"""Bootstrap authentication flow for Hawcx.

Provides the HawcxBootstrapClient SDK for customer backends to authenticate
with Hawcx using private_key_jwt (RFC 7523) challenge-response flow.

Example:
    >>> from hawcx_oauth_client.bootstrap import HawcxBootstrapClient
    >>> client = HawcxBootstrapClient(
    ...     hawcx_base_url="https://dev-api.hawcx.com",
    ...     client_id="cl_demo",
    ...     private_key_pem=open("private.pem").read(),
    ...     kid="key_2026_01",
    ... )
    >>> token = client.authenticate()
    >>> print(token.authorization_header)
    'Bearer eyJ...'
"""

from .client import HawcxBootstrapClient, BootstrapToken
from .crypto import (
    create_client_assertion,
    create_dpop_proof,
    compute_jwk_thumbprint,
)
from .dpop_session import DPoPSession
from .exceptions import (
    BootstrapError,
    BootstrapChallengeError,
    BootstrapExchangeError,
    BootstrapSigningError,
)

__all__ = [
    "HawcxBootstrapClient",
    "BootstrapToken",
    "DPoPSession",
    "create_client_assertion",
    "create_dpop_proof",
    "compute_jwk_thumbprint",
    "BootstrapError",
    "BootstrapChallengeError",
    "BootstrapExchangeError",
    "BootstrapSigningError",
]
