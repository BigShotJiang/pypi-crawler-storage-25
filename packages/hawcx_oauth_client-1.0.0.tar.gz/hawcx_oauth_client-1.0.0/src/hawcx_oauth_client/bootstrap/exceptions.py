"""Exceptions for the bootstrap authentication flow."""

from typing import Optional

from ..exceptions import HawcxOAuthError


class BootstrapError(HawcxOAuthError):
    """Base exception for bootstrap flow errors."""


class BootstrapChallengeError(BootstrapError):
    """Raised when the challenge request fails."""

    def __init__(
        self,
        message: str,
        status_code: Optional[int] = None,
        response_body: Optional[dict] = None,
    ):
        self.status_code = status_code
        self.response_body = response_body
        super().__init__(message)

    def __str__(self) -> str:
        base = super().__str__()
        if self.status_code:
            base = f"{base} (HTTP {self.status_code})"
        return base


class BootstrapExchangeError(BootstrapError):
    """Raised when the exchange request fails (assertion rejected, challenge expired, etc.)."""

    def __init__(
        self,
        message: str,
        status_code: Optional[int] = None,
        error_code: Optional[str] = None,
        response_body: Optional[dict] = None,
    ):
        self.status_code = status_code
        self.error_code = error_code
        self.response_body = response_body
        super().__init__(message)

    def __str__(self) -> str:
        base = super().__str__()
        if self.error_code:
            base = f"{base} [{self.error_code}]"
        if self.status_code:
            base = f"{base} (HTTP {self.status_code})"
        return base


class BootstrapSigningError(BootstrapError):
    """Raised when signing the client assertion fails."""
