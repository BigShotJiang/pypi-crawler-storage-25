"""Bootstrap authentication client for Hawcx.

Implements the challenge-response bootstrap flow using private_key_jwt (RFC 7523)
for customer backend authentication. Returns a short-lived frontend_access_token
that Kong can validate via OIDC.

Usage:
    >>> from hawcx_oauth_client.bootstrap import HawcxBootstrapClient
    >>> client = HawcxBootstrapClient.from_env()
    >>> token = client.authenticate()
    >>> print(token.authorization_header)
    'Bearer eyJ...'
"""

from __future__ import annotations

import os
import time
from dataclasses import dataclass, field
from typing import Any, Dict, Optional

import requests

from hawcx_oauth_client._crypto import generate_dpop_keypair
from .crypto import create_client_assertion
from .exceptions import (
    BootstrapChallengeError,
    BootstrapExchangeError,
    BootstrapSigningError,
)


@dataclass
class BootstrapToken:
    """A frontend access token obtained from the bootstrap flow.

    Attributes:
        access_token: The JWT access token string.
        token_type: "Bearer" or "DPoP".
        expires_in: Token lifetime in seconds.
        scope: Space-delimited scope string.
        expires_at: Absolute expiration time (unix timestamp).
    """

    access_token: str
    token_type: str
    expires_in: int
    scope: str
    expires_at: float = field(default=0.0)
    dpop_private_key: Optional[Any] = field(default=None, repr=False)

    def __post_init__(self):
        if self.expires_at == 0.0:
            self.expires_at = time.time() + self.expires_in

    @property
    def is_expired(self) -> bool:
        return time.time() >= self.expires_at

    @property
    def authorization_header(self) -> str:
        """Returns the Authorization header value (e.g., 'Bearer eyJ...')."""
        return f"{self.token_type} {self.access_token}"


class HawcxBootstrapClient:
    """SDK for customer backends to authenticate with Hawcx via bootstrap flow.

    Implements the full challenge → sign → exchange flow using private_key_jwt.

    Args:
        hawcx_base_url: Base URL of the Hawcx API (e.g., "https://dev-api.hawcx.com").
        client_id: Registered client identifier (e.g., "cl_demo").
        private_key_pem: ES256 private key in PEM format.
        kid: Key ID matching the public key registered with Hawcx.
        api_key: API key for Kong authentication (X-Consumer-Id or apikey header).
        origin: Optional web origin for binding.
        timeout: HTTP request timeout in seconds.
    """

    def __init__(
        self,
        hawcx_base_url: str,
        client_id: str,
        private_key_pem: str,
        kid: str,
        api_key: Optional[str] = None,
        origin: Optional[str] = None,
        timeout: int = 15,
    ):
        self.hawcx_base_url = hawcx_base_url.rstrip("/")
        self.client_id = client_id
        self.private_key_pem = private_key_pem
        self.kid = kid
        self.api_key = api_key
        self.origin = origin
        self.timeout = timeout

    @classmethod
    def from_env(cls) -> HawcxBootstrapClient:
        """Create a client from environment variables.

        Required env vars:
            HAWCX_BASE_URL: Base URL of the Hawcx API.
            HAWCX_CLIENT_ID: Client identifier.
            HAWCX_PRIVATE_KEY_PEM: ES256 private key (PEM format, can include newlines).
            HAWCX_KEY_ID: Key ID for the registered public key.

        Optional env vars:
            HAWCX_API_KEY: API key for Kong.
            HAWCX_ORIGIN: Web origin for binding.
            HAWCX_TIMEOUT: Request timeout in seconds (default: 15).
        """

        def _require(name: str) -> str:
            v = os.environ.get(name)
            if not v:
                raise BootstrapSigningError(f"Missing required env var: {name}")
            return v

        return cls(
            hawcx_base_url=_require("HAWCX_BASE_URL"),
            client_id=_require("HAWCX_CLIENT_ID"),
            private_key_pem=_require("HAWCX_PRIVATE_KEY_PEM"),
            kid=_require("HAWCX_KEY_ID"),
            api_key=os.environ.get("HAWCX_API_KEY"),
            origin=os.environ.get("HAWCX_ORIGIN"),
            timeout=int(os.environ.get("HAWCX_TIMEOUT", "15")),
        )

    def _headers(self) -> Dict[str, str]:
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["apikey"] = self.api_key
        return headers

    def _request_challenge(self) -> Dict[str, Any]:
        """Step 1: Request a challenge nonce from Hawcx."""
        url = f"{self.hawcx_base_url}/bootstrap/challenge"
        body: Dict[str, Any] = {"client_id": self.client_id}
        if self.origin:
            body["origin"] = self.origin

        try:
            resp = requests.post(url, json=body, headers=self._headers(), timeout=self.timeout)
        except requests.RequestException as e:
            raise BootstrapChallengeError(f"Challenge request failed: {e}")

        if resp.status_code != 200:
            raise BootstrapChallengeError(
                f"Challenge request rejected",
                status_code=resp.status_code,
                response_body=resp.json() if resp.headers.get("content-type", "").startswith("application/json") else None,
            )

        return resp.json()

    def sign_challenge(
        self,
        challenge: Dict[str, Any],
        dpop_jwk: Optional[Dict[str, Any]] = None,
    ) -> str:
        """Step 2: Sign a challenge payload with the client's ES256 private key.

        Args:
            challenge: The challenge response from /bootstrap/challenge.
            dpop_jwk: Optional DPoP public JWK to bind via cnf.jkt in the assertion.

        Returns:
            Signed client_assertion JWT string.
        """
        return create_client_assertion(
            client_id=self.client_id,
            audience=challenge["aud"],
            nonce=challenge["nonce"],
            scope=challenge.get("scope", ""),
            private_key_pem=self.private_key_pem,
            kid=self.kid,
            origin=self.origin,
            dpop_jwk=dpop_jwk,
        )

    def _exchange_assertion(
        self,
        client_assertion: str,
        dpop_jwk: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Step 3: Exchange the signed assertion for a frontend_access_token."""
        url = f"{self.hawcx_base_url}/bootstrap/exchange"
        body: Dict[str, Any] = {
            "client_id": self.client_id,
            "client_assertion": client_assertion,
        }
        if self.origin:
            body["origin"] = self.origin
        if dpop_jwk:
            body["dpop_jwk"] = dpop_jwk

        try:
            resp = requests.post(url, json=body, headers=self._headers(), timeout=self.timeout)
        except requests.RequestException as e:
            raise BootstrapExchangeError(f"Exchange request failed: {e}")

        if resp.status_code != 200:
            resp_body = None
            error_code = None
            if resp.headers.get("content-type", "").startswith("application/json"):
                resp_body = resp.json()
                error_code = resp_body.get("error")
            raise BootstrapExchangeError(
                f"Exchange request rejected",
                status_code=resp.status_code,
                error_code=error_code,
                response_body=resp_body,
            )

        return resp.json()

    def authenticate(self) -> BootstrapToken:
        """Run the full bootstrap flow: challenge → sign → exchange.

        If the server indicates dpop_required=True in the challenge response,
        automatically upgrades to DPoP-bound token (generates ephemeral keypair).

        Returns:
            BootstrapToken with the frontend_access_token.

        Raises:
            BootstrapChallengeError: If the challenge request fails.
            BootstrapSigningError: If signing the assertion fails.
            BootstrapExchangeError: If the exchange request fails.
        """
        challenge = self._request_challenge()

        # Auto-upgrade to DPoP if server requires it
        if challenge.get("dpop_required", False):
            return self._authenticate_with_dpop_from_challenge(challenge)

        assertion = self.sign_challenge(challenge)
        token_resp = self._exchange_assertion(assertion)

        return BootstrapToken(
            access_token=token_resp["frontend_access_token"],
            token_type=token_resp.get("token_type", "Bearer"),
            expires_in=token_resp.get("expires_in", 120),
            scope=token_resp.get("scope", ""),
        )

    def _authenticate_with_dpop_from_challenge(
        self, challenge: Dict[str, Any]
    ) -> BootstrapToken:
        """Complete a DPoP-bound exchange using an already-fetched challenge."""
        dpop_key, dpop_pub_jwk = generate_dpop_keypair()

        assertion = self.sign_challenge(challenge, dpop_jwk=dpop_pub_jwk)
        token_resp = self._exchange_assertion(assertion, dpop_jwk=dpop_pub_jwk)

        token = BootstrapToken(
            access_token=token_resp["frontend_access_token"],
            token_type=token_resp.get("token_type", "DPoP"),
            expires_in=token_resp.get("expires_in", 120),
            scope=token_resp.get("scope", ""),
        )
        token.dpop_private_key = dpop_key
        return token

    def revoke_token(self, token: str, token_type_hint: str = "access_token") -> None:
        """Revoke a token via the IdP revocation endpoint (RFC 7009)."""
        url = f"{self.hawcx_base_url}/oauth/revoke"
        payload: Dict[str, Any] = {"token": token}
        if token_type_hint:
            payload["token_type_hint"] = token_type_hint
        resp = requests.post(
            url, json=payload, headers=self._headers(), timeout=self.timeout
        )
        # RFC 7009: server always returns 200, even if token was invalid
        resp.raise_for_status()

    def authenticate_direct(
        self,
        scope: Optional[str] = None,
        dpop_jwk: Optional[Dict[str, Any]] = None,
    ) -> BootstrapToken:
        """One-step authentication via /bootstrap/token (no challenge round-trip).

        Sends a signed client_assertion directly. The assertion proves key possession
        without needing a server-issued nonce.
        """
        audience = f"{self.hawcx_base_url}/bootstrap/token"
        assertion = create_client_assertion(
            client_id=self.client_id,
            audience=audience,
            nonce="",
            scope=scope or "",
            private_key_pem=self.private_key_pem,
            kid=self.kid,
            dpop_jwk=dpop_jwk,
        )
        payload: Dict[str, Any] = {
            "grant_type": "client_credentials",
            "client_assertion_type": "urn:ietf:params:oauth:client-assertion-type:jwt-bearer",
            "client_assertion": assertion,
        }
        if scope:
            payload["scope"] = scope
        if dpop_jwk:
            payload["dpop_jwk"] = dpop_jwk

        resp = requests.post(
            f"{self.hawcx_base_url}/bootstrap/token",
            json=payload,
            headers=self._headers(),
            timeout=self.timeout,
        )
        if resp.status_code != 200:
            raise BootstrapExchangeError(
                f"Direct auth failed: {resp.status_code} {resp.text}"
            )

        data = resp.json()
        return BootstrapToken(
            access_token=data["access_token"],
            token_type=data.get("token_type", "Bearer"),
            expires_in=data.get("expires_in", 120),
            scope=data.get("scope", ""),
        )

    def authenticate_with_dpop(self) -> BootstrapToken:
        """Run the bootstrap flow with DPoP token binding.

        Generates an ephemeral ES256 keypair, binds the token to the public key,
        and returns a DPoP-bound token. Use create_dpop_proof() for subsequent
        API calls.

        Returns:
            BootstrapToken with token_type="DPoP".
        """
        # Generate ephemeral DPoP keypair
        dpop_key, dpop_pub_jwk = generate_dpop_keypair()

        challenge = self._request_challenge()
        assertion = self.sign_challenge(challenge, dpop_jwk=dpop_pub_jwk)
        token_resp = self._exchange_assertion(assertion, dpop_jwk=dpop_pub_jwk)

        token = BootstrapToken(
            access_token=token_resp["frontend_access_token"],
            token_type=token_resp.get("token_type", "DPoP"),
            expires_in=token_resp.get("expires_in", 120),
            scope=token_resp.get("scope", ""),
        )

        # Attach the DPoP private key so callers can create proofs
        token.dpop_private_key = dpop_key
        return token
