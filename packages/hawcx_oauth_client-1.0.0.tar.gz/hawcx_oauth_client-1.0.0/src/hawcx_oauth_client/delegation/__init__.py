"""
Hawcx OAuth Client SDK - Delegation Module

Exposes the client and utilities for making secure, backend-to-backend
delegated requests to an IDP.

For Hawcx-specific operations, use HawcxDelegationClient for simplified high-level API.
For generic delegation operations, use IdpDelegationClient for lower-level control.
"""

from .client import IdpDelegationClient
from .hawcx import HawcxDelegationClient, MfaMethod
from .crypto import (
    Ed25519Signer,
    RsaPssSigner,
    Verifier,
    EciesX25519Encryptor,
    EciesX25519Decryptor,
)
from .exceptions import (
    DelegationError,
    DelegationCryptoError,
    DelegationRequestError,
    DelegationResponseError,
)

__all__ = [
    # High-level Hawcx client (recommended for most use cases)
    "HawcxDelegationClient",
    "MfaMethod",
    # Generic delegation client (for advanced use cases)
    "IdpDelegationClient",
    # Crypto primitives
    "Ed25519Signer",
    "RsaPssSigner",
    "Verifier",
    "EciesX25519Encryptor",
    "EciesX25519Decryptor",
    # Exceptions
    "DelegationError",
    "DelegationCryptoError",
    "DelegationRequestError",
    "DelegationResponseError",
]
