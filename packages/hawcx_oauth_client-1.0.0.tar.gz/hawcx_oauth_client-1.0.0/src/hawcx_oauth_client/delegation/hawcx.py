"""
Hawcx-specific delegation client with high-level convenience methods.

This module provides a streamlined API for common Hawcx operations like
MFA configuration, user management, and device operations. All cryptographic
operations (encryption, signing, verification) are handled automatically.
"""

import os
import logging
from enum import Enum
from typing import Dict, Any, Optional

from .client import IdpDelegationClient
from .crypto import Ed25519Signer, RsaPssSigner, Verifier, EciesX25519Encryptor, EciesX25519Decryptor
from .exceptions import DelegationRequestError, DelegationResponseError

logger = logging.getLogger(__name__)


class MfaMethod(str, Enum):
    """
    Supported MFA methods for Hawcx authentication.
    
    This enum ensures type safety and prevents typos when specifying MFA methods.
    
    Example:
        >>> from hawcx_oauth_client.delegation import MfaMethod
        >>> 
        >>> # Use enum for type safety
        >>> client.initiate_mfa_change(
        ...     userid="user@example.com",
        ...     mfa_method=MfaMethod.SMS,  # Type-safe!
        ...     phone_number="+15551234567"
        ... )
        >>> 
        >>> # String values still work for backwards compatibility
        >>> client.initiate_mfa_change(
        ...     userid="user@example.com",
        ...     mfa_method="sms",  # Also works
        ...     phone_number="+15551234567"
        ... )
    """
    EMAIL = "email"
    SMS = "sms"
    TOTP = "totp"
    
    def __str__(self) -> str:
        """Return the string value for easy serialization."""
        return self.value


class HawcxDelegationClient:
    """
    High-level client for Hawcx delegation operations.
    
    This client provides simplified methods for common Hawcx operations:
    - MFA configuration (email, SMS, TOTP)
    - User credential management
    - Device operations
    
    All requests are automatically encrypted (ECIES) and signed (Ed25519/RSA-PSS).
    All responses are automatically verified and decrypted.
    
    Example:
        >>> # Initialize from environment variables
        >>> client = HawcxDelegationClient.from_env()
        >>> 
        >>> # Initiate SMS MFA setup
        >>> result = client.initiate_mfa_change(
        ...     userid="user@example.com",
        ...     mfa_method="sms",
        ...     phone_number="+15551234567"
        ... )
        >>> print(result['session_id'])
        >>> 
        >>> # Verify OTP
        >>> client.verify_mfa_change(
        ...     userid="user@example.com",
        ...     session_id=result['session_id'],
        ...     otp="123456"
        ... )
    """
    
    def __init__(
        self,
        base_url: str,
        signer,  # Ed25519Signer or RsaPssSigner
        verifier: Verifier,
        encryptor: EciesX25519Encryptor,
        decryptor: EciesX25519Decryptor,
        sp_id: str,
        api_key: Optional[str] = None,
        timeout: int = 15,
    ):
        """
        Initialize Hawcx delegation client.
        
        Args:
            base_url: Hawcx API base URL (e.g., "https://api.hawcx.com")
            signer: Ed25519Signer or RsaPssSigner instance
            verifier: Verifier instance with IDP public keys
            encryptor: EciesX25519Encryptor configured with IDP's public key
            decryptor: EciesX25519Decryptor configured with SP's private key
            sp_id: Service Provider identifier (usually OAuth client_id)
            api_key: Optional Hawcx API key (can be added to requests)
            timeout: Request timeout in seconds (default: 15)
        """
        self._client = IdpDelegationClient(
            base_url=base_url,
            signer=signer,
            verifier=verifier,
            encryptor=encryptor,
            decryptor=decryptor,
            sp_id=sp_id,
            timeout=timeout,
        )
        self.api_key = api_key
        self.base_url = base_url
        self.sp_id = sp_id
    
    @classmethod
    def from_keys(
        cls,
        sp_signing_key: str,
        sp_encryption_key: str,
        idp_verify_key: str,
        idp_encryption_key: str,
        base_url: str,
        sp_id: str,
        api_key: Optional[str] = None,
        timeout: int = 15,
        kid: str = "hawcx",  # Hawcx IDP expects "hawcx" as Key ID
        idp_kid: str = "hawcx",  # Hawcx IDP signs with "hawcx"
    ) -> "HawcxDelegationClient":
        """
        Create client from explicit key values (recommended).
        
        This method allows the application to load keys from any source
        (env vars, config files, secrets manager, etc.) and pass them
        as values to the SDK.
        
        Args:
            sp_signing_key: Service Provider's Ed25519 private key (PEM format)
            sp_encryption_key: Service Provider's X25519 private key (PEM format)
            idp_verify_key: IDP's Ed25519 public key (PEM format)
            idp_encryption_key: IDP's X25519 public key (PEM format)
            base_url: Hawcx API base URL (e.g., "https://api.hawcx.com")
            sp_id: Service Provider identifier (usually OAuth client_id)
            api_key: Optional Hawcx API key
            timeout: Request timeout in seconds (default: 15)
            kid: Internal - Key ID for SP signatures (default: "hawcx", do not change)
            idp_kid: Internal - Key ID for IDP verification (default: "hawcx", do not change)
        
        Returns:
            Configured HawcxDelegationClient instance
            
        Raises:
            DelegationRequestError: If key initialization fails
            
        Example:
            >>> import os
            >>> # App controls how to load keys
            >>> client = HawcxDelegationClient.from_keys(
            ...     sp_signing_key=os.getenv('MY_SIGNING_KEY'),
            ...     sp_encryption_key=os.getenv('MY_ENCRYPTION_KEY'),
            ...     idp_verify_key=os.getenv('IDP_VERIFY_KEY'),
            ...     idp_encryption_key=os.getenv('IDP_ENCRYPT_KEY'),
            ...     base_url=os.getenv('HAWCX_URL'),
            ...     sp_id=os.getenv('MY_CLIENT_ID')
            ... )
        """
        # Initialize crypto helpers
        try:
            signer = Ed25519Signer(sp_signing_key, kid=kid)
            verifier = Verifier({idp_kid: idp_verify_key})
            encryptor = EciesX25519Encryptor(idp_encryption_key)
            decryptor = EciesX25519Decryptor(sp_encryption_key)
        except Exception as e:
            raise DelegationRequestError(f"Failed to initialize crypto helpers: {e}") from e
        
        logger.info(f"Initialized HawcxDelegationClient with base_url={base_url}, sp_id={sp_id}")
        
        return cls(
            base_url=base_url,
            signer=signer,
            verifier=verifier,
            encryptor=encryptor,
            decryptor=decryptor,
            sp_id=sp_id,
            api_key=api_key,
            timeout=timeout,
        )

    def initiate_mfa_change(
        self,
        userid: str,
        mfa_method: "str | MfaMethod",
        phone_number: Optional[str] = None,
        mfa_change_to: Optional["str | MfaMethod"] = None,
    ) -> Dict[str, Any]:
        """
        Initiate MFA setup or change for a user.
        
        This method starts the MFA enrollment/update process by sending an OTP
        to the user via their chosen method (email, SMS, or generating a TOTP secret).
        
        Args:
            userid: User identifier (typically email address)
            mfa_method: MFA method to configure (MfaMethod enum or 'email', 'sms', 'totp' string)
            phone_number: Phone number with country code (required for SMS, e.g., "+15551234567")
            mfa_change_to: Target MFA method after verification (optional)
        
        Returns:
            Dictionary containing:
            - session_id (str): Session identifier for OTP verification
            - totp_secret (str, optional): TOTP secret (only for TOTP method)
            - otpauth_uri (str, optional): TOTP URI for QR code (only for TOTP method)
            - otp (str, optional): OTP code (only in test mode)
            
        Raises:
            DelegationRequestError: If request fails or parameters are invalid
            ValueError: If SMS method specified without phone_number
            
        Example:
            >>> from hawcx_oauth_client.delegation import MfaMethod
            >>> 
            >>> # Email MFA (with enum - recommended!)
            >>> result = client.initiate_mfa_change(
            ...     userid="user@example.com",
            ...     mfa_method=MfaMethod.EMAIL
            ... )
            >>> 
            >>> # SMS MFA (string also works)
            >>> result = client.initiate_mfa_change(
            ...     userid="user@example.com",
            ...     mfa_method="sms",
            ...     phone_number="+15551234567"
            ... )
            >>> 
            >>> # TOTP MFA
            >>> result = client.initiate_mfa_change(
            ...     userid="user@example.com",
            ...     mfa_method=MfaMethod.TOTP
            ... )
            >>> print(f"Scan QR code: {result['otpauth_uri']}")
        """
        # Convert enum to string if needed
        mfa_method_str = str(mfa_method) if isinstance(mfa_method, MfaMethod) else mfa_method
        mfa_change_to_str = str(mfa_change_to) if isinstance(mfa_change_to, MfaMethod) else mfa_change_to
        
        # Validate method (allow any of the enum values)
        valid_methods = [m.value for m in MfaMethod]
        if mfa_method_str not in valid_methods:
            raise ValueError(
                f"Invalid mfa_method '{mfa_method_str}'. "
                f"Must be one of: {', '.join(valid_methods)} "
                f"or use MfaMethod enum: {', '.join(f'MfaMethod.{m.name}' for m in MfaMethod)}"
            )
        
        # Validate SMS requires phone number
        if mfa_method_str == MfaMethod.SMS.value and not phone_number:
            raise ValueError("phone_number is required for SMS MFA")
        
        # Build Hawcx UpdateTable API payload
        payload = {
            'userid': userid,
            'mfa_method': mfa_method_str,
        }
        
        # Add SMS phone number
        if mfa_method_str == MfaMethod.SMS.value and phone_number:
            payload['contact'] = phone_number
        
        # Add target method if changing
        if mfa_change_to_str:
            payload['mfa_change_to'] = mfa_change_to_str
        
        logger.info(f"[MFA Initiate] Method={mfa_method_str} for user={userid}")
        
        try:
            # Build Hawcx API authentication headers
            extra_headers = {}
            if self.api_key:
                extra_headers['apikey'] = self.api_key

            
            # Send encrypted and signed request with API authentication
            response = self._client.send_secure_request(
                endpoint='/hc_auth/v5/update/initiate',
                payload=payload,
                extra_headers=extra_headers
            )
            
            logger.info(f"[MFA Initiate] Success for user={userid}, session_id={response.get('session_id')}")
            return response
            
        except Exception as e:
            logger.error(f"[MFA Initiate] Failed for user={userid}: {e}")
            raise
    
    def verify_mfa_change(
        self,
        userid: str,
        session_id: str,
        otp: str,
    ) -> Dict[str, Any]:
        """
        Verify OTP and complete MFA configuration change.
        
        This method verifies the OTP sent to the user and completes the MFA
        enrollment/update process.
        
        Args:
            userid: User identifier (must match initiate request)
            session_id: Session ID from initiate_mfa_change response
            otp: One-time password entered by user (6 digits)
        
        Returns:
            Dictionary containing:
            - detail (str): Success message
            - mfa_changed_to (str, optional): New MFA method if changed
            
        Raises:
            DelegationRequestError: If verification fails
            DelegationResponseError: If OTP is invalid
            
        Example:
            >>> # Get OTP from user
            >>> otp = input("Enter OTP: ")
            >>> 
            >>> # Verify and complete MFA setup
            >>> result = client.verify_mfa_change(
            ...     userid="user@example.com",
            ...     session_id=session_id,
            ...     otp=otp
            ... )
            >>> print(f"MFA updated: {result['detail']}")
        """
        # Validate OTP format
        if not otp or len(otp) != 6 or not otp.isdigit():
            raise ValueError("OTP must be a 6-digit code")
        
        # Build Hawcx UpdateTable API payload
        payload = {
            'userid': userid,
            'session_id': session_id,
            'otp': otp,
        }
        
        logger.info(f"[MFA Verify] Verifying OTP for user={userid}, session={session_id}")
        
        try:
            # Build Hawcx API authentication headers
            extra_headers = {}
            if self.api_key:
                extra_headers['apikey'] = self.api_key
            
            # Send encrypted and signed request with API authentication
            response = self._client.send_secure_request(
                endpoint='/hc_auth/v5/update/verify',
                payload=payload,
                extra_headers=extra_headers
            )
            
            logger.info(f"[MFA Verify] Success for user={userid}")
            return response
            
        except Exception as e:
            logger.error(f"[MFA Verify] Failed for user={userid}: {e}")
            raise
    
    def get_user_credentials(
        self,
        userid: str,
    ) -> Dict[str, Any]:
        """
        Get user's stored credentials and MFA status.
        
        This method retrieves the user's credentials from Hawcx, including
        their current MFA configuration.
        
        Args:
            userid: User identifier
        
        Returns:
            Dictionary containing user credentials and MFA status
            
        Example:
            >>> creds = client.get_user_credentials("user@example.com")
            >>> print(f"MFA method: {creds.get('mfa_method')}")
            >>> print(f"Phone: {creds.get('contact')}")
        """
        payload = {
            'userid': userid,
        }
        
        logger.info(f"[Get Creds] Fetching credentials for user={userid}")
        
        try:
            # Build Hawcx API authentication headers
            extra_headers = {}
            if self.api_key:
                extra_headers['apikey'] = self.api_key
            
            # Send encrypted and signed request with API authentication
            response = self._client.send_secure_request(
                endpoint='/hc_auth/v5/update/get-creds',
                payload=payload,
                extra_headers=extra_headers
            )
            
            logger.info(f"[Get Creds] Success for user={userid}")
            return response
            
        except Exception as e:
            logger.error(f"[Get Creds] Failed for user={userid}: {e}")
            raise
    
    def list_user_devices(
        self,
        userid: str,
    ) -> Dict[str, Any]:
        """
        List all devices for a user with full device metadata.
        
        This method retrieves all devices associated with a user, including
        revocation status, device metadata, and last attempted login.
        
        Args:
            userid: User identifier (typically email address)
        
        Returns:
            Dictionary containing:
            - userid (str): User identifier
            - devices (list): List of device dictionaries with:
                - h2index (str): Device identifier
                - revoked (bool): Whether device is revoked
                - device_metadata (dict): Device information (type, model, etc.)
                - last_attempted_login (str, optional): ISO timestamp of last login
                - created_at (str, optional): ISO timestamp of device creation
            - total_devices (int): Total number of devices
            - detail (str): Status message
            
        Raises:
            DelegationRequestError: If request fails
            DelegationResponseError: If response verification fails
            
        Example:
            >>> result = client.list_user_devices(
            ...     userid="user@example.com",
            ... )
            >>> for device in result['devices']:
            ...     print(f"Device: {device['h2index']}, Revoked: {device['revoked']}")
        """
        payload = {
            'userid': userid,
        }
        
        logger.info(f"[List Devices] Fetching devices for user={userid}")
        
        try:
            # Build Hawcx API authentication headers
            extra_headers = {}
            if self.api_key:
                extra_headers['apikey'] = self.api_key
            
            # Send encrypted and signed request with API authentication
            response = self._client.send_secure_request(
                endpoint='/hc_auth/v5/manage/devices',
                payload=payload,
                extra_headers=extra_headers
            )
            
            logger.info(f"[List Devices] Success for user={userid}, found {response.get('total_devices', 0)} devices")
            return response
            
        except Exception as e:
            logger.error(f"[List Devices] Failed for user={userid}: {e}")
            raise
    
    def revoke_device(
        self,
        userid: str,
        h2index: str,
    ) -> Dict[str, Any]:
        """
        Revoke a user's device, marking it as inactive.
        
        This method revokes a device, preventing it from being used for
        authentication. The device can be restored using unrevoke_device.
        
        Args:
            userid: User identifier (typically email address)
            h2index: Device identifier (h2index)
        
        Returns:
            Dictionary containing:
            - detail (str): Status message ("Device successfully revoked." or "Device is already revoked.")
            
        Raises:
            DelegationRequestError: If request fails or device not found
            DelegationResponseError: If response verification fails
            
        Example:
            >>> result = client.revoke_device(
            ...     userid="user@example.com",
            ...     h2index="abc123..."
            ... )
            >>> print(result['detail'])
        """
        payload = {
            'userid': userid,       
            'h2index': h2index,
        }
        
        logger.info(f"[Revoke Device] Revoking device h2index={h2index} for user={userid}")
        
        try:
            # Build Hawcx API authentication headers
            extra_headers = {}
            if self.api_key:
                extra_headers['apikey'] = self.api_key
            
            # Send encrypted and signed request with API authentication
            response = self._client.send_secure_request(
                endpoint='/hc_auth/v5/manage/revoke',
                payload=payload,
                extra_headers=extra_headers
            )
            
            logger.info(f"[Revoke Device] Success for user={userid}, h2index={h2index}")
            return response
            
        except Exception as e:
            logger.error(f"[Revoke Device] Failed for user={userid}, h2index={h2index}: {e}")
            raise
    
    def unrevoke_device(
        self,
        userid: str,
        h2index: str,
    ) -> Dict[str, Any]:
        """
        Un-revoke a user's device, marking it as active.
        
        This method restores a previously revoked device, allowing it to be
        used for authentication again. Only works if the device is currently revoked.
        
        Args:
            userid: User identifier (typically email address)
            h2index: Device identifier (h2index)
        
        Returns:
            Dictionary containing:
            - detail (str): Status message
            
        Raises:
            DelegationRequestError: If request fails or device not found
            DelegationResponseError: If response verification fails
            
        Example:
            >>> result = client.unrevoke_device(
            ...     userid="user@example.com",      
            ...     h2index="abc123..."
            ... )
            >>> print(result['detail'])
        """
        payload = {
            'userid': userid,
            'h2index': h2index,
        }
        
        logger.info(f"[Unrevoke Device] Un-revoking device h2index={h2index} for user={userid}")
        
        try:
            # Build Hawcx API authentication headers
            extra_headers = {}
            if self.api_key:
                extra_headers['apikey'] = self.api_key
            
            # Send encrypted and signed request with API authentication
            response = self._client.send_secure_request(
                endpoint='/hc_auth/v5/manage/unrevoke',
                payload=payload,
                extra_headers=extra_headers
            )
            
            logger.info(f"[Unrevoke Device] Success for user={userid}, h2index={h2index}")
            return response
            
        except Exception as e:
            logger.error(f"[Unrevoke Device] Failed for user={userid}, h2index={h2index}: {e}")
            raise
    
    def delete_device(
        self,
        userid: str,
        h2index: str,
    ) -> Dict[str, Any]:
        """
        Delete a specific user device.
        
        This method permanently deletes a device from the user's account.
        Unlike revoke, this operation cannot be undone.
        
        Args:
            userid: User identifier (typically email address)
            h2index: Device identifier (h2index)
        
        Returns:
            Dictionary containing:
            - detail (str): Status message ("Device successfully deleted.")
            
        Raises:
            DelegationRequestError: If request fails or device not found
            DelegationResponseError: If response verification fails
            
        Example:
            >>> result = client.delete_device(
            ...     userid="user@example.com",
            ...     h2index="abc123..."
            ... )
            >>> print(result['detail'])
        """
        payload = {
            'userid': userid,
            'h2index': h2index,
        }
        
        logger.info(f"[Delete Device] Deleting device h2index={h2index} for user={userid}")
        
        try:
            # Build Hawcx API authentication headers
            extra_headers = {}
            if self.api_key:
                extra_headers['apikey'] = self.api_key
            
            # Send encrypted and signed request with API authentication
            response = self._client.send_secure_request(
                endpoint='/hc_auth/v5/manage/delete',
                payload=payload,
                extra_headers=extra_headers
            )
            
            logger.info(f"[Delete Device] Success for user={userid}, h2index={h2index}")
            return response
            
        except Exception as e:
            logger.error(f"[Delete Device] Failed for user={userid}, h2index={h2index}: {e}")
            raise
    
    def set_suggested_mfa(
        self,
        userid: str,
        suggested_mfa: str,
    ) -> Dict[str, Any]:
        """
        Set the suggested_mfa preference for a user.
        
        This method sets the user's MFA preference which is used when the tenant's
        MFA enforcement policy is set to "Suggested".
        
        Args:
            userid: User identifier (typically email address)
            suggested_mfa: MFA preference: "none", "always", or "risk_only"
        
        Returns:
            Dictionary containing:
            - success (bool): Whether the operation succeeded
            - detail (str): Status message
            
        Raises:
            ValueError: If suggested_mfa is not one of the valid values
            DelegationRequestError: If request fails
            DelegationResponseError: If response verification fails
            
        Example:
            >>> # Set suggested_mfa to "none"
            >>> result = client.set_suggested_mfa(
            ...     userid="user@example.com",
            ...     suggested_mfa="none"
            ... )
            >>> print(result['detail'])
            
            >>> # Set suggested_mfa to "always"
            >>> result = client.set_suggested_mfa(
            ...     userid="user@example.com",
            ...     suggested_mfa="always"
            ... )
        """
        # Validate suggested_mfa value
        valid_values = ["none", "always", "risk_only"]
        if suggested_mfa not in valid_values:
            raise ValueError(
                f"Invalid suggested_mfa value: '{suggested_mfa}'. "
                f"Must be one of: {', '.join(valid_values)}"
            )
        
        payload = {
            'userid': userid,
            'suggested_mfa': suggested_mfa,
        }
        
        logger.info(f"[Set Suggested MFA] Setting suggested_mfa={suggested_mfa} for user={userid}")
        
        try:
            # Build Hawcx API authentication headers
            extra_headers = {}
            if self.api_key:
                extra_headers['apikey'] = self.api_key
            
            # Send encrypted and signed request with API authentication
            response = self._client.send_secure_request(
                endpoint='/hc_auth/v5/update/set-suggest-mfa',
                payload=payload,
                extra_headers=extra_headers
            )
            
            logger.info(f"[Set Suggested MFA] Success for user={userid}, suggested_mfa={suggested_mfa}")
            return response
            
        except Exception as e:
            logger.error(f"[Set Suggested MFA] Failed for user={userid}: {e}")
            raise
    
    def get_suggested_mfa(
        self,
        userid: str,
    ) -> Dict[str, Any]:
        """
        Get the suggested_mfa preference value for a user.
        
        This method retrieves the user's MFA preference. Returns null if the user
        doesn't exist or if suggested_mfa is not set.
        
        All requests are automatically encrypted (ECIES) and signed (Ed25519/RSA-PSS).
        All responses are automatically verified and decrypted.
        
        Args:
            userid: User identifier (typically email address)
        
        Returns:
            Dictionary containing:
            - suggested_mfa (str | None): The suggested_mfa value ("none", "always", "risk_only", or null)
            
        Raises:
            DelegationRequestError: If request fails
            DelegationResponseError: If response verification or decryption fails
            
        Example:
            >>> # Get suggested_mfa value
            >>> result = client.get_suggested_mfa("user@example.com")
            >>> print(f"Suggested MFA: {result.get('suggested_mfa')}")
            
            >>> # Check if not set (returns null)
            >>> result = client.get_suggested_mfa("newuser@example.com")
            >>> if result.get('suggested_mfa') is None:
            ...     print("No preference set")
        """
        payload = {
            'userid': userid,
        }
        
        logger.info(f"[Get Suggested MFA] Fetching suggested_mfa for user={userid}")
        
        try:
            # Build Hawcx API authentication headers
            extra_headers = {}
            if self.api_key:
                extra_headers['apikey'] = self.api_key
            
            # Send encrypted and signed request with API authentication
            response = self._client.send_secure_request(
                endpoint='/hc_auth/v5/update/get-suggested-mfa',
                payload=payload,
                extra_headers=extra_headers
            )
            
            logger.info(
                f"[Get Suggested MFA] Success for user={userid}, "
                f"suggested_mfa={response.get('suggested_mfa')}"
            )
            return response
            
        except Exception as e:
            logger.error(f"[Get Suggested MFA] Failed for user={userid}: {e}")
            raise

