import json
import uuid
import requests
from typing import Optional, Dict, Any

from .crypto import (
    now_s,
    Verifier,
    EciesX25519Encryptor,
    EciesX25519Decryptor,
)
from .exceptions import DelegationRequestError, DelegationResponseError

class IdpDelegationClient:
    """
    Client for sending secure, ECIES-encrypted and signed delegation requests to an IDP.
    """
    def __init__(
        self,
        base_url: str,
        signer,  # Ed25519Signer or RsaPssSigner
        verifier: Verifier,
        encryptor: EciesX25519Encryptor,
        decryptor: EciesX25519Decryptor,
        sp_id: str,
        timeout: int = 15,
    ):
        """
        Initializes the delegation client.

        Args:
            base_url: The base URL of the IDP (e.g., https://idp.example.com).
            signer: An instance of Ed25519Signer or RsaPssSigner for signing requests.
            verifier: An instance of Verifier for verifying IDP responses.
            encryptor: An instance of EciesX25519Encryptor configured with the IDP's public ECIES key.
            decryptor: An instance of EciesX25519Decryptor configured with the SP's private ECIES key.
            sp_id: The identifier for this Service Provider.
            timeout: Request timeout in seconds.
        """
        self.base_url = base_url.rstrip("/")
        self.signer = signer
        self.verifier = verifier
        self.encryptor = encryptor
        self.decryptor = decryptor
        self.sp_id = sp_id
        self.timeout = timeout

    def send_secure_request(
        self, 
        endpoint: str, 
        payload: Dict[str, Any],
        include_base_url: bool = True,
        extra_headers: Optional[Dict[str, str]] = None
    ) -> Dict[str, Any]:
        """
        Send an encrypted and signed delegation request to the IDP.
        
        This method automatically handles all cryptographic operations:
        - ECIES (X25519 + AES-GCM) encryption of the request payload
        - Ed25519/RSA-PSS detached signature generation
        - HTTP header construction with delegation metadata
        - Response signature verification
        - ECIES decryption of the response
        
        Args:
            endpoint: API endpoint path (e.g., "/mfa/update" or "/device/revoke")
            payload: Request payload dictionary to be encrypted and sent
            include_base_url: If True, prepends self.base_url to endpoint (default: True)
                             If False, treats endpoint as a full URL
            extra_headers: Optional additional HTTP headers to include (e.g., API keys)
        
        Returns:
            Decrypted and verified response dictionary from the IDP
            
        Raises:
            DelegationRequestError: If request preparation or sending fails
            DelegationResponseError: If response verification or decryption fails
            
        Example:
            >>> # Initialize client
            >>> client = IdpDelegationClient(
            ...     base_url="https://idp.example.com",
            ...     signer=signer, verifier=verifier,
            ...     encryptor=encryptor, decryptor=decryptor,
            ...     sp_id="my-sp"
            ... )
            >>>
            >>> # Send secure request with automatic crypto
            >>> response = client.send_secure_request(
            ...     endpoint="/mfa/update",
            ...     payload={
            ...         "userid": "user@example.com",
            ...         "mfa_method": "sms",
            ...         "contact": "+15551234567"
            ...     }
            ... )
            >>> print(response)  # {'success': True, 'session_id': '...'}
        
        Security Notes:
            - All requests are encrypted with ECIES (X25519 + AES-GCM)
            - All requests include a detached signature (Ed25519 or RSA-PSS)
            - All responses are verified and decrypted automatically
            - Timestamps are included to prevent replay attacks
        """
        try:
            # Step 1: Serialize and encrypt the payload
            body = json.dumps(payload, separators=(",", ":")).encode('utf-8')
            encrypted_env = self.encryptor.encrypt(body)
            
            # Step 2: Generate timestamp and signature
            ts = now_s()
            sig = self.signer.sign_detached(encrypted_env, ts)
            
            # Step 3: Build delegation headers
            headers = {
                "Content-Type": "application/json",
                "X-Enc-Alg": "x25519-aesgcm",
                "X-SP-Id": self.sp_id,
                "X-Timestamp": str(ts),
                "X-Signature-Alg": sig.alg,
                "X-Signature": sig.signature_b64,
            }
            if sig.kid:
                headers["X-Key-Id"] = sig.kid
            
            # Merge extra headers (e.g., API authentication headers)
            if extra_headers:
                headers.update(extra_headers)
        except Exception as e:
            raise DelegationRequestError(f"Failed to prepare secure request: {e}") from e

        try:
            # Step 4: Send encrypted request to IDP
            url = (self.base_url + endpoint) if include_base_url else endpoint
            response = requests.post(
                url, 
                headers=headers, 
                data=encrypted_env, 
                timeout=self.timeout
            )
        except requests.exceptions.RequestException as e:
            raise DelegationRequestError(f"Request to IDP failed: {e}") from e

        # Step 5: Verify and decrypt response (even for error statuses)
        try:
            resp_ts = int(response.headers.get("X-Timestamp", str(now_s())))
            resp_sig = response.headers["X-Signature"]
            resp_alg = response.headers["X-Signature-Alg"]
            resp_kid = response.headers.get("X-Key-Id")

            self.verifier.verify(response.content, resp_ts, resp_sig, resp_alg, resp_kid)
            
            # Step 6: Verify encryption and decrypt response
            if response.headers.get("X-Enc-Alg") != "x25519-aesgcm":
                raise DelegationResponseError("IDP response must be ECIES encrypted")

            plaintext = self.decryptor.decrypt(response.content)
            decrypted_data = json.loads(plaintext)
            
            # Now check HTTP status and include decrypted error message if available
            if not response.ok:
                error_detail = decrypted_data.get('detail', decrypted_data)
                raise DelegationRequestError(f"IDP returned {response.status_code}: {error_detail}")
            
            return decrypted_data
        except DelegationRequestError:
            # Re-raise our delegation errors
            raise
        except (KeyError, ValueError) as e:
            # If we can't decrypt, fall back to raw response
            if not response.ok:
                raise DelegationRequestError(f"IDP returned {response.status_code}: {response.text[:500]}")
            raise DelegationResponseError(f"Invalid or incomplete secure response from IDP: {e}") from e
        except Exception as e:
            raise DelegationResponseError(f"Failed to process secure response: {e}") from e
    
    # Backwards compatibility alias
    _send = send_secure_request

    # --- Public API Methods ---

    def mfa_update(
        self,
        user_id: str,
        method: str,
        enabled: bool,
        reason: str,
        requested_by: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Request an MFA method update for a user.

        Args:
            user_id: The ID of the user to modify.
            method: The MFA method to update (e.g., "sms", "totp").
            enabled: Whether to enable or disable the method.
            reason: An audit reason for the change.
            requested_by: The identifier of the entity requesting the change (e.g., admin ID or user ID).

        Returns:
            The decrypted acknowledgment response from the IDP.
        """
        payload = {
            "v": "1",
            "type": "delegation.request",
            "action": "mfa.update",
            "sp": {"id": self.sp_id, "kid": getattr(self.signer, "kid", None)},
            "subject": {"user_id": user_id},
            "params": {"method": method, "enabled": bool(enabled)},
            "audit": {"reason": reason, "requested_by": requested_by or user_id},
            "jti": uuid.uuid4().hex,
            "iat": now_s()
        }
        return self._send("/mfa/update", payload)

    def mfa_get_status(self, user_id: str) -> Dict[str, Any]:
        """
        Request the current MFA status for a user.

        Args:
            user_id: The ID of the user to query.

        Returns:
            The decrypted acknowledgment response from the IDP containing the MFA status.
        """
        payload = {
            "v": "1",
            "type": "delegation.request",
            "action": "mfa.get_status",
            "sp": {"id": self.sp_id, "kid": getattr(self.signer, "kid", None)},
            "subject": {"user_id": user_id},
            "params": {},
            "audit": {"reason": "User status query", "requested_by": user_id},
            "jti": uuid.uuid4().hex,
            "iat": now_s()
        }
        return self._send("/mfa/get", payload)

    def device_revoke(
        self,
        user_id: str,
        device_id: str,
        reason: str,
        requested_by: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Request to revoke a user's device.

        Args:
            user_id: The ID of the user who owns the device.
            device_id: The ID of the device to revoke.
            reason: An audit reason for the revocation.
            requested_by: The identifier of the entity requesting the change.

        Returns:
            The decrypted acknowledgment response from the IDP.
        """
        payload = {
            "v": "1",
            "type": "delegation.request",
            "action": "device.revoke",
            "sp": {"id": self.sp_id, "kid": getattr(self.signer, "kid", None)},
            "subject": {"user_id": user_id, "device_id": device_id},
            "params": {},
            "audit": {"reason": reason, "requested_by": requested_by or user_id},
            "jti": uuid.uuid4().hex,
            "iat": now_s()
        }
        return self._send("/device/revoke", payload) # Example of another endpoint
