"""Custom exceptions for the Delegation module."""

from ..exceptions import HawcxOAuthError

class DelegationError(HawcxOAuthError):
    """Base exception for delegation errors."""

class DelegationCryptoError(DelegationError):
    """Raised for cryptographic errors (signing, encryption, etc.)."""

class DelegationRequestError(DelegationError):
    """Raised for errors sending requests to the IDP."""
    def __init__(self, message: str, status_code: int | None = None, response_body: str | None = None):
        self.status_code = status_code
        self.response_body = response_body
        super().__init__(message)

    def __str__(self) -> str:
        base = super().__str__()
        if self.status_code:
            base = f"{base} (HTTP {self.status_code})"
        return base

class DelegationResponseError(DelegationError):
    """Raised for errors in the IDP's response."""
