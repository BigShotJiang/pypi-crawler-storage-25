from __future__ import annotations
import base64, json, os, time
from typing import Dict, Optional
from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.primitives.asymmetric import ed25519, padding, x25519, rsa
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from .exceptions import DelegationCryptoError

# -------- helpers --------

def now_s() -> int:
    return int(time.time())

def b64e(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).rstrip(b'=').decode('ascii')

def b64d(s: str) -> bytes:
    # Add padding if necessary
    padding_needed = len(s) % 4
    if padding_needed:
        s += '=' * (4 - padding_needed)
    return base64.urlsafe_b64decode(s)

# -------- signing --------
class SignResult:
    def __init__(self, alg: str, signature_b64: str, kid: Optional[str]):
        self.alg = alg
        self.signature_b64 = signature_b64
        self.kid = kid

class Ed25519Signer:
    def __init__(self, private_pem: str, kid: Optional[str] = None):
        self.kid = kid
        try:
            self.sk = serialization.load_pem_private_key(private_pem.encode(), password=None)
            if not isinstance(self.sk, ed25519.Ed25519PrivateKey):
                raise DelegationCryptoError("Provided PEM is not an Ed25519 private key")
        except Exception as e:
            raise DelegationCryptoError(f"Failed to load Ed25519 private key: {e}") from e
        self.alg = "ed25519"

    def sign_detached(self, body: bytes, ts: int) -> SignResult:
        try:
            sig = self.sk.sign(body + b"." + str(ts).encode())
            return SignResult(self.alg, b64e(sig), self.kid)
        except Exception as e:
            raise DelegationCryptoError(f"Ed25519 signing failed: {e}") from e

class RsaPssSigner:
    def __init__(self, private_pem: str, kid: Optional[str] = None):
        self.kid = kid
        try:
            self.sk = serialization.load_pem_private_key(private_pem.encode(), password=None)
            if not isinstance(self.sk, rsa.RSAPrivateKey):
                raise DelegationCryptoError("Provided PEM is not an RSA private key")
        except Exception as e:
            raise DelegationCryptoError(f"Failed to load RSA private key: {e}") from e
        self.alg = "rsa-pss-sha256"

    def sign_detached(self, body: bytes, ts: int) -> SignResult:
        try:
            sig = self.sk.sign(
                body + b"." + str(ts).encode(),
                padding.PSS(mgf=padding.MGF1(hashes.SHA256()), salt_length=padding.PSS.MAX_LENGTH),
                hashes.SHA256(),
            )
            return SignResult(self.alg, b64e(sig), self.kid)
        except Exception as e:
            raise DelegationCryptoError(f"RSA-PSS signing failed: {e}") from e

class Verifier:
    def __init__(self, pubkeys: Dict[str, str]):  # {kid: PEM}
        if not pubkeys:
            raise DelegationCryptoError("At least one public key is required for verification.")
        try:
            self.pub = {k: serialization.load_pem_public_key(v.encode()) for k, v in pubkeys.items()}
        except Exception as e:
            raise DelegationCryptoError(f"Failed to load one or more public keys: {e}") from e

    def verify(self, body: bytes, ts: int, sig_b64: str, alg: str, kid: Optional[str]) -> None:
        try:
            sig = b64d(sig_b64)
            if kid and kid in self.pub:
                pub = self.pub[kid]
            elif len(self.pub) == 1 and kid is None:
                pub = list(self.pub.values())[0]
            else:
                raise DelegationCryptoError("Unknown or ambiguous key ID for verification")

            data_to_verify = body + b"." + str(ts).encode()

            if alg == "ed25519" and isinstance(pub, ed25519.Ed25519PublicKey):
                pub.verify(sig, data_to_verify)
            elif alg == "rsa-pss-sha256" and isinstance(pub, rsa.RSAPublicKey):
                pub.verify(
                    sig,
                    data_to_verify,
                    padding.PSS(mgf=padding.MGF1(hashes.SHA256()), salt_length=padding.PSS.MAX_LENGTH),
                    hashes.SHA256(),
                )
            else:
                raise DelegationCryptoError(f"Unsupported algorithm '{alg}' or mismatched key type.")
        except Exception as e:
            raise DelegationCryptoError(f"Signature verification failed: {e}") from e

# -------- ECIES (X25519 + AES-GCM) --------
class EciesX25519Encryptor:
    def __init__(self, peer_pub_pem: str):
        try:
            pk = serialization.load_pem_public_key(peer_pub_pem.encode())
            if not isinstance(pk, x25519.X25519PublicKey):
                raise DelegationCryptoError("peer_pub_pem must be an X25519 public key")
            self.peer = pk
        except Exception as e:
            raise DelegationCryptoError(f"Failed to load ECIES peer public key: {e}") from e

    def encrypt(self, plaintext: bytes) -> bytes:
        try:
            eph = x25519.X25519PrivateKey.generate()
            shared = eph.exchange(self.peer)
            key = HKDF(algorithm=hashes.SHA256(), length=32, salt=None, info=b"idp-sp-ecies-v1").derive(shared)
            nonce = os.urandom(12)
            ct = AESGCM(key).encrypt(nonce, plaintext, None)
            env = {
                "enc": "x25519-aesgcm",
                "epk": b64e(eph.public_key().public_bytes(
                    encoding=serialization.Encoding.Raw, format=serialization.PublicFormat.Raw
                )),
                "iv": b64e(nonce),
                "ct": b64e(ct),
            }
            return json.dumps(env, separators=(",", ":")).encode()
        except Exception as e:
            raise DelegationCryptoError(f"ECIES encryption failed: {e}") from e

class EciesX25519Decryptor:
    def __init__(self, priv_pem: str):
        try:
            sk = serialization.load_pem_private_key(priv_pem.encode(), password=None)
            if not isinstance(sk, x25519.X25519PrivateKey):
                raise DelegationCryptoError("priv_pem must be an X25519 private key")
            self.sk = sk
        except Exception as e:
            raise DelegationCryptoError(f"Failed to load ECIES private key: {e}") from e

    def decrypt(self, envelope_json: bytes) -> bytes:
        try:
            env = json.loads(envelope_json)
            if env.get("enc") != "x25519-aesgcm":
                raise DelegationCryptoError("Unsupported envelope encryption algorithm")
            
            epk_bytes = b64d(env["epk"])
            epk = x25519.X25519PublicKey.from_public_bytes(epk_bytes)
            
            nonce, ct = b64d(env["iv"]), b64d(env["ct"])
            shared = self.sk.exchange(epk)
            key = HKDF(algorithm=hashes.SHA256(), length=32, salt=None, info=b"idp-sp-ecies-v1").derive(shared)
            return AESGCM(key).decrypt(nonce, ct, None)
        except Exception as e:
            raise DelegationCryptoError(f"ECIES decryption failed: {e}") from e
