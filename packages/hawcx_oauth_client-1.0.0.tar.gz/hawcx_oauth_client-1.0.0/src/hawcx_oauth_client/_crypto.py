"""Shared cryptographic utilities for bootstrap, stepup, and delegation modules."""

from __future__ import annotations

import base64
import hashlib
import json
import time
import uuid
from typing import Optional

import jwt
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ec


def b64url_encode(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode()


def b64url_decode(s: str) -> bytes:
    padding = 4 - len(s) % 4
    if padding != 4:
        s += "=" * padding
    return base64.urlsafe_b64decode(s)


def load_ec_private_key(pem: str) -> ec.EllipticCurvePrivateKey:
    """Load an EC private key from PEM string."""
    key = serialization.load_pem_private_key(pem.encode(), password=None)
    if not isinstance(key, ec.EllipticCurvePrivateKey):
        raise ValueError("Key must be an EC private key")
    return key


def ec_public_jwk(key: ec.EllipticCurvePrivateKey) -> dict:
    """Export EC public key as minimal JWK (kty, crv, x, y only)."""
    pub = key.public_key().public_numbers()
    coord_size = (key.key_size + 7) // 8
    return {
        "kty": "EC",
        "crv": "P-256",
        "x": b64url_encode(pub.x.to_bytes(coord_size, "big")),
        "y": b64url_encode(pub.y.to_bytes(coord_size, "big")),
    }


def compute_jwk_thumbprint(jwk: dict) -> str:
    """RFC 7638 JWK thumbprint (SHA-256)."""
    kty = jwk.get("kty")
    if kty == "EC":
        required = ["crv", "kty", "x", "y"]
    elif kty == "OKP":
        required = ["crv", "kty", "x"]
    else:
        raise ValueError(f"Unsupported kty for JWK thumbprint: {kty}")
    for k in required:
        if k not in jwk:
            raise ValueError(f"Missing required JWK member for thumbprint: {k}")
    members = {k: jwk[k] for k in sorted(required)}
    canonical = json.dumps(members, separators=(",", ":"), sort_keys=True).encode()
    return b64url_encode(hashlib.sha256(canonical).digest())


def generate_dpop_keypair() -> tuple:
    """Generate ephemeral EC P-256 key pair for DPoP. Returns (private_key, public_jwk)."""
    key = ec.generate_private_key(ec.SECP256R1())
    jwk = ec_public_jwk(key)
    return key, jwk


def create_dpop_proof(
    method: str,
    url: str,
    private_key: ec.EllipticCurvePrivateKey,
    access_token: Optional[str] = None,
) -> str:
    """Create a DPoP proof JWT per RFC 9449."""
    jwk = ec_public_jwk(private_key)
    payload = {
        "htm": method,
        "htu": url,
        "iat": int(time.time()),
        "jti": str(uuid.uuid4()),
    }
    if access_token:
        payload["ath"] = b64url_encode(hashlib.sha256(access_token.encode()).digest())
    return jwt.encode(
        payload,
        private_key,
        algorithm="ES256",
        headers={"typ": "dpop+jwt", "jwk": jwk},
    )
