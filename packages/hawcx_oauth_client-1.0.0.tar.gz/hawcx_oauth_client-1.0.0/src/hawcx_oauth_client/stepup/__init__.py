"""
Hawcx OAuth Client SDK - Step-Up Module

Provides a client for management step-up endpoints that require
proof-of-possession via ES256 client assertions bound to ephemeral DPoP keys.

Usage:
    >>> from hawcx_oauth_client.stepup import StepUpClient
    >>> client = StepUpClient(
    ...     client_id="my-service",
    ...     signing_key_pem=open("private.pem").read(),
    ...     base_url="https://dev-api.hawcx.com",
    ...     tenant_id="tenant-abc",
    ... )
"""

from .client import StepUpClient
from .exceptions import (
    StepUpError,
    StepUpSigningError,
    StepUpRequestError,
)

__all__ = [
    "StepUpClient",
    "StepUpError",
    "StepUpSigningError",
    "StepUpRequestError",
]
