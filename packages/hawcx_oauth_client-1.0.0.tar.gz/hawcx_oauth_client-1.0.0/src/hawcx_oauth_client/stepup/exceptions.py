"""Custom exceptions for the Step-Up module."""

from ..exceptions import HawcxOAuthError


class StepUpError(HawcxOAuthError):
    """Base exception for step-up errors."""


class StepUpSigningError(StepUpError):
    """Raised for cryptographic errors (key loading, JWT signing)."""


class StepUpRequestError(StepUpError):
    """Raised for errors sending requests to the step-up endpoint."""

    def __init__(self, message: str, status_code: int | None = None, response_body: str | None = None):
        self.status_code = status_code
        self.response_body = response_body
        super().__init__(message)

    def __str__(self) -> str:
        base = super().__str__()
        if self.status_code:
            base = f"{base} (HTTP {self.status_code})"
        return base
