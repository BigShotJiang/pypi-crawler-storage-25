"""Step-up authentication client using signed assertion + DPoP.

Provides a lightweight client for management step-up endpoints that require
proof-of-possession via ES256 client assertions bound to ephemeral DPoP keys.

Usage:
    >>> from hawcx_oauth_client.stepup import StepUpClient
    >>> client = StepUpClient(
    ...     client_id="my-service",
    ...     signing_key_pem=open("private.pem").read(),
    ...     base_url="https://dev-api.hawcx.com",
    ...     tenant_id="tenant-abc",
    ... )
    >>> result = client.start_token(user_id="user@example.com", purpose="mfa_change")
    >>> if result.get("receipt"):
    ...     final = client.consume_receipt(user_id="user@example.com", receipt=result["receipt"])
"""

from __future__ import annotations

import time
import uuid
from typing import Any, Dict

import jwt
import requests

from hawcx_oauth_client._crypto import (
    compute_jwk_thumbprint,
    create_dpop_proof,
    ec_public_jwk,
    generate_dpop_keypair,
    load_ec_private_key,
)
from .exceptions import StepUpRequestError, StepUpSigningError


class StepUpClient:
    """Client for management step-up endpoints using signed assertion + DPoP.

    At init, generates an ephemeral EC P-256 key pair used for DPoP proofs.
    Each request includes:
      - An ES256 client assertion JWT (X-Client-Assertion header)
      - A DPoP proof JWT bound to the endpoint (DPoP header)
    """

    def __init__(
        self,
        *,
        client_id: str,
        signing_key_pem: str,
        base_url: str,
        tenant_id: str,
        api_prefix: str = "/v1",
        timeout: int = 15,
    ):
        """
        Args:
            client_id: The client identifier (used as ``iss`` in assertions).
            signing_key_pem: ES256 private key in PEM format for signing assertions.
            base_url: API base URL (e.g., ``https://dev-api.hawcx.com``).
            tenant_id: Tenant identifier sent via ``X-Hcx-Tenant`` header.
            api_prefix: URL prefix for step-up endpoints (default ``/v1``).
            timeout: HTTP request timeout in seconds.
        """
        self.client_id = client_id
        self.base_url = base_url.rstrip("/")
        self.tenant_id = tenant_id
        self.api_prefix = api_prefix
        self.timeout = timeout

        # Load the long-lived signing key for client assertions
        try:
            self._signing_key = load_ec_private_key(signing_key_pem)
        except StepUpSigningError:
            raise
        except Exception as e:
            raise StepUpSigningError(f"Failed to load signing key: {e}") from e

        # Generate an ephemeral EC P-256 key pair for DPoP proofs
        self._dpop_key, self._dpop_jwk = generate_dpop_keypair()
        self._dpop_thumbprint = compute_jwk_thumbprint(self._dpop_jwk)

        self._session = requests.Session()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def start_token(
        self,
        *,
        user_id: str,
        purpose: str,
        new_mfa_method: str | None = None,
        new_phone_number: str | None = None,
    ) -> dict:
        """Issue a start token (or direct receipt if skip policy applies).

        Args:
            user_id: Subject user identifier.
            purpose: Step-up purpose (e.g., ``mfa_change``, ``device_revoke``).
            new_mfa_method: Optional new MFA method being requested.
            new_phone_number: Optional new phone number for SMS MFA.

        Returns:
            JSON response dict from the server. May contain a ``receipt`` for
            direct completion, or flow state for further interaction.
        """
        endpoint = f"{self.api_prefix}/management/stepup/start-token"
        extra_claims: Dict[str, Any] = {"purpose": purpose}
        if new_mfa_method is not None:
            extra_claims["new_mfa_method"] = new_mfa_method
        if new_phone_number is not None:
            extra_claims["new_phone_number"] = new_phone_number
        return self._send(endpoint, user_id=user_id, extra_claims=extra_claims)

    def consume_receipt(self, *, user_id: str, receipt: str) -> dict:
        """Consume a step-up receipt.

        Args:
            user_id: Subject user identifier.
            receipt: The receipt token obtained from a completed step-up flow.

        Returns:
            JSON response dict from the server.
        """
        endpoint = f"{self.api_prefix}/management/stepup/consume"
        extra_claims: Dict[str, Any] = {"receipt": receipt}
        return self._send(endpoint, user_id=user_id, extra_claims=extra_claims)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _send(
        self,
        endpoint: str,
        *,
        user_id: str,
        extra_claims: Dict[str, Any],
    ) -> dict:
        """Build assertion + DPoP proof, send POST, return JSON response."""
        url = f"{self.base_url}{endpoint}"

        # Build the client assertion JWT
        assertion = self._build_assertion(user_id=user_id, audience=url, extra_claims=extra_claims)

        # Build the DPoP proof JWT
        dpop_proof = self._build_dpop_proof(method="POST", url=url)

        headers = {
            "Content-Type": "application/json",
            "X-Client-Assertion": assertion,
            "DPoP": dpop_proof,
            "X-Config-Id": self.tenant_id,
            "apikey": self.tenant_id,
        }

        try:
            resp = self._session.post(url, headers=headers, json={}, timeout=self.timeout)
        except requests.exceptions.RequestException as e:
            raise StepUpRequestError(f"Request failed: {e}") from e

        if not resp.ok:
            raise StepUpRequestError(
                f"Step-up endpoint returned {resp.status_code}: {resp.text[:500]}",
                status_code=resp.status_code,
                response_body=resp.text[:500],
            )

        return resp.json()

    def _build_assertion(
        self,
        *,
        user_id: str,
        audience: str,
        extra_claims: Dict[str, Any],
        ttl: int = 120,
    ) -> str:
        """Build an ES256-signed client assertion JWT.

        The assertion binds the request to the DPoP key via the ``cnf.jkt`` claim.
        """
        now = int(time.time())
        payload: Dict[str, Any] = {
            "iss": self.client_id,
            "sub": user_id,
            "aud": audience,
            "iat": now,
            "exp": now + min(ttl, 120),
            "jti": str(uuid.uuid4()),
            "cnf": {"jkt": self._dpop_thumbprint},
            **extra_claims,
        }

        try:
            return jwt.encode(payload, self._signing_key, algorithm="ES256")
        except Exception as e:
            raise StepUpSigningError(f"Failed to sign assertion: {e}") from e

    def _build_dpop_proof(self, *, method: str, url: str) -> str:
        """Build a DPoP proof JWT per RFC 9449."""
        try:
            return create_dpop_proof(
                method=method,
                url=url,
                private_key=self._dpop_key,
            )
        except Exception as e:
            raise StepUpSigningError(f"Failed to sign DPoP proof: {e}") from e

    def close(self):
        """Close the underlying HTTP session."""
        self._session.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
