"""Custom exceptions for the Hawcx OAuth Client SDK."""

from typing import Optional


class HawcxOAuthError(Exception):
    """Base exception for all hawcx_oauth_client errors."""


class OAuthExchangeError(HawcxOAuthError):
    """
    Raised when the OAuth code exchange fails.
    
    This can happen due to:
    - Invalid or expired authorization code
    - Network connectivity issues
    - OAuth server errors
    - Malformed responses
    
    Attributes:
        status_code: HTTP status code from the OAuth server (if available)
        response_body: Parsed response body from the OAuth server (if available)
    """
    
    def __init__(
        self,
        message: str,
        status_code: Optional[int] = None,
        response_body: Optional[dict] = None
    ):
        self.status_code = status_code
        self.response_body = response_body
        super().__init__(message)
    
    def __str__(self) -> str:
        base = super().__str__()
        if self.status_code:
            base = f"{base} (HTTP {self.status_code})"
        return base


class JWTVerificationError(HawcxOAuthError):
    """
    Raised when JWT signature or claims verification fails.
    
    This can happen due to:
    - Invalid JWT signature (tampering detected)
    - Expired token
    - Wrong audience or issuer
    - Token not yet valid (nbf claim)
    - Malformed JWT structure
    
    Attributes:
        original_error: The underlying exception from PyJWT (if available)
    """
    
    def __init__(self, message: str, original_error: Optional[Exception] = None):
        self.original_error = original_error
        super().__init__(message)


class InvalidPublicKeyError(HawcxOAuthError):
    """
    Raised when the provided public key is invalid or unreadable.
    
    This can happen due to:
    - File not found
    - Invalid PEM format
    - Wrong key algorithm (not RS256)
    - Permission denied
    - Empty key
    """

