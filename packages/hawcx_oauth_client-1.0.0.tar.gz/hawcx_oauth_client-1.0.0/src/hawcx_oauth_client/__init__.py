"""
Hawcx OAuth Client SDK

A lightweight Python library for exchanging OAuth authorization codes
for verified JWT claims. Handles code exchange, JWT signature verification,
and claims extraction.

Example:
    >>> from hawcx_oauth_client import exchange_code_for_claims
    >>> claims = exchange_code_for_claims(
    ...     code='abc123',
    ...     oauth_token_url='https://oauth.example.com/token',
    ...     client_id='my-app',
    ...     public_key='path/to/public.pem'
    ... )
    >>> print(claims['sub'])
    'user@example.com'
"""

import sys
import os

from .client import (
    exchange_code_for_claims,
    require_oauth_claims,
    verify_jwt,
    exchange_code_for_token_and_claims,
)
from ._utils import (
    fetch_jwks,
    get_key_from_jwks,
)
from .exceptions import (
    HawcxOAuthError,
    InvalidPublicKeyError,
    OAuthExchangeError,
    JWTVerificationError,
)
from .bootstrap import (
    HawcxBootstrapClient,
    BootstrapToken,
    DPoPSession,
    BootstrapError,
    BootstrapChallengeError,
    BootstrapExchangeError,
    BootstrapSigningError,
)
from .assertion import build_assertion_and_dpop, AssertionResult

__version__ = "1.0.0"
__all__ = [
    # OAuth code exchange
    "exchange_code_for_claims",
    "exchange_code_for_token_and_claims",
    "require_oauth_claims",
    "verify_jwt",
    "fetch_jwks",
    "get_key_from_jwks",
    # Bootstrap flow
    "HawcxBootstrapClient",
    "BootstrapToken",
    "DPoPSession",
    # Assertion + DPoP (FAPI 2.0)
    "build_assertion_and_dpop",
    "AssertionResult",
    # Exceptions
    "HawcxOAuthError",
    "InvalidPublicKeyError",
    "OAuthExchangeError",
    "JWTVerificationError",
    "BootstrapError",
    "BootstrapChallengeError",
    "BootstrapExchangeError",
    "BootstrapSigningError",
]

# Additional submodules (imported from their own namespace):
#   from hawcx_oauth_client.delegation import HawcxDelegationClient, IdpDelegationClient
#   from hawcx_oauth_client.stepup import StepUpClient

