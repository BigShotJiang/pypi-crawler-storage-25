"""
Server-side assertion+DPoP builder for token exchange (FAPI 2.0).

Builds client_assertion JWT (RFC 7523 private_key_jwt) + DPoP proof (RFC 9449)
for authenticating to /oauth2/token. Mirrors @hawcx/oauth-client Pattern 1.

Usage:
    from hawcx_oauth_client.assertion import build_assertion_and_dpop

    result = build_assertion_and_dpop(
        token_url="https://api.hawcx.com/oauth2/token",
        client_id="cl_my_app",
        signing_key_pem=os.environ["ASSERTION_SIGNING_KEY"],
    )

    # result.client_assertion — signed JWT for form body
    # result.dpop_proof — signed DPoP JWT for DPoP header
    # result.client_assertion_type — "urn:ietf:params:oauth:client-assertion-type:jwt-bearer"
"""

from __future__ import annotations

import time
import uuid
from dataclasses import dataclass
from typing import Optional

import jwt

from ._crypto import (
    compute_jwk_thumbprint,
    generate_dpop_keypair,
    load_ec_private_key,
)


@dataclass(frozen=True)
class AssertionResult:
    """Result of building assertion + DPoP for token exchange."""
    client_assertion: str
    client_assertion_type: str
    dpop_proof: str


def build_assertion_and_dpop(
    token_url: str,
    client_id: str,
    signing_key_pem: str,
    algorithm: str = "ES256",
    ttl: int = 120,
) -> AssertionResult:
    """
    Build client_assertion JWT + DPoP proof for /oauth2/token exchange.

    Args:
        token_url: The full token endpoint URL (e.g., "https://api.hawcx.com/oauth2/token").
                   Used as audience for assertion and htu for DPoP.
        client_id: OAuth client_id registered with the auth server.
        signing_key_pem: PEM-encoded PKCS#8 private key for signing the assertion.
        algorithm: Signing algorithm (default: ES256).
        ttl: Assertion JWT lifetime in seconds (default: 120).

    Returns:
        AssertionResult with client_assertion, client_assertion_type, and dpop_proof.
    """
    now = int(time.time())

    # Load long-lived assertion signing key
    signing_key = load_ec_private_key(signing_key_pem)

    # Generate ephemeral DPoP key pair (fresh per request)
    dpop_private_key, dpop_public_jwk = generate_dpop_keypair()

    # Compute JWK Thumbprint (RFC 7638) — binds DPoP to assertion
    thumbprint = compute_jwk_thumbprint(dpop_public_jwk)

    # Build client_assertion JWT (RFC 7523 private_key_jwt)
    assertion_payload = {
        "iss": client_id,
        "sub": client_id,
        "aud": token_url,
        "iat": now,
        "exp": now + ttl,
        "jti": str(uuid.uuid4()),
        "cnf": {"jkt": thumbprint},
    }
    client_assertion = jwt.encode(
        assertion_payload,
        signing_key,
        algorithm=algorithm,
    )

    # Build DPoP proof JWT (RFC 9449)
    dpop_payload = {
        "htm": "POST",
        "htu": token_url,
        "iat": now,
        "jti": str(uuid.uuid4()),
    }
    dpop_proof = jwt.encode(
        dpop_payload,
        dpop_private_key,
        algorithm=algorithm,
        headers={"typ": "dpop+jwt", "jwk": dpop_public_jwk},
    )

    return AssertionResult(
        client_assertion=client_assertion,
        client_assertion_type="urn:ietf:params:oauth:client-assertion-type:jwt-bearer",
        dpop_proof=dpop_proof,
    )
