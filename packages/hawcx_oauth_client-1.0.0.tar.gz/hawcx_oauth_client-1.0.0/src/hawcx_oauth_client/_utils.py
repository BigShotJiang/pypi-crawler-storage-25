"""Internal utilities for the Hawcx OAuth Client SDK."""

import base64
import logging
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional, Union

import requests
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa, ec
from cryptography.hazmat.backends import default_backend

from .exceptions import InvalidPublicKeyError

logger = logging.getLogger(__name__)

# JWKS cache: {url: {'jwks': {...}, 'timestamp': float}}
_jwks_cache: Dict[str, Dict[str, Any]] = {}
JWKS_CACHE_TTL = 3600  # 1 hour default TTL


def load_public_key(key_input: Union[str, Path]) -> str:
    """
    Load public key from string or file.
    
    Args:
        key_input: Either a PEM-formatted public key string or a path to a key file
        
    Returns:
        PEM-formatted public key string
        
    Raises:
        InvalidPublicKeyError: If the key cannot be loaded or is invalid
        
    Example:
        >>> # From file
        >>> key = load_public_key(Path('keys/public.pem'))
        >>> 
        >>> # From string
        >>> key = load_public_key(os.getenv('PUBLIC_KEY'))
    """
    # Check for empty input first
    if not key_input or (isinstance(key_input, str) and not key_input.strip()):
        raise InvalidPublicKeyError("Public key is empty")

    # If it's a Path object, try to read it
    if isinstance(key_input, Path):
        try:
            if not key_input.exists():
                raise InvalidPublicKeyError(f"Public key file not found: {key_input}")
            if not key_input.is_file():
                raise InvalidPublicKeyError(f"Public key path is not a file: {key_input}")
            key_content = key_input.read_text(encoding='utf-8')
            logger.debug(f"Loaded public key from file: {key_input}")
            return _validate_pem_format(key_content)
        except Exception as e:
            raise InvalidPublicKeyError(f"Error reading public key file {key_input}: {e}") from e

    # Otherwise, treat as PEM string directly
    if not isinstance(key_input, str):
        raise InvalidPublicKeyError(f"Public key must be a string or Path, got {type(key_input)}")
    
    return _validate_pem_format(key_input)


def _validate_pem_format(key_content: str) -> str:
    """
    Validate that the key content looks like a valid PEM public key.
    
    Args:
        key_content: The key content to validate
        
    Returns:
        The validated key content
        
    Raises:
        InvalidPublicKeyError: If the key format is invalid
    """
    if not key_content or not key_content.strip():
        raise InvalidPublicKeyError("Public key is empty")
    
    key_stripped = key_content.strip()
    
    # Check for PEM markers
    if not ('-----BEGIN' in key_stripped and '-----END' in key_stripped):
        raise InvalidPublicKeyError(
            "Public key does not appear to be in PEM format "
            "(missing BEGIN/END markers)"
        )
    
    # Check for common public key markers
    valid_markers = [
        'BEGIN PUBLIC KEY',
        'BEGIN RSA PUBLIC KEY',
        'BEGIN CERTIFICATE',
    ]
    
    if not any(marker in key_stripped for marker in valid_markers):
        raise InvalidPublicKeyError(
            "Public key does not contain recognized PEM markers. "
            f"Expected one of: {', '.join(valid_markers)}"
        )
    
    return key_stripped


def fetch_jwks(jwks_url: str, timeout: int = 10, ttl: int = JWKS_CACHE_TTL) -> Dict[str, Any]:
    """
    Fetch JWKS (JSON Web Key Set) from a URL with caching.
    
    Args:
        jwks_url: URL to fetch JWKS from (e.g., https://example.com/.well-known/jwks.json)
        timeout: Request timeout in seconds (default: 10)
        ttl: Cache TTL in seconds (default: 3600)
        
    Returns:
        JWKS dictionary containing 'keys' array
        
    Raises:
        InvalidPublicKeyError: If JWKS cannot be fetched or is invalid
        
    Example:
        >>> jwks = fetch_jwks('https://example.com/.well-known/jwks.json')
        >>> print(jwks['keys'][0]['kid'])
        'key-id-123'
    """
    global _jwks_cache
    
    if not jwks_url or not isinstance(jwks_url, str):
        raise InvalidPublicKeyError("JWKS URL must be a non-empty string")
    
    # Check cache
    now = time.time()
    if jwks_url in _jwks_cache:
        cached = _jwks_cache[jwks_url]
        if now - cached['timestamp'] < ttl:
            logger.debug(f"Using cached JWKS for {jwks_url}")
            return cached['jwks']
    
    # Fetch from URL
    try:
        logger.info(f"Fetching JWKS from {jwks_url}")
        response = requests.get(jwks_url, timeout=timeout)
        response.raise_for_status()
        jwks = response.json()
        
        # Validate JWKS format
        if not isinstance(jwks, dict) or 'keys' not in jwks:
            raise InvalidPublicKeyError(
                f"Invalid JWKS format: missing 'keys' field in response from {jwks_url}"
            )
        
        if not isinstance(jwks['keys'], list) or len(jwks['keys']) == 0:
            raise InvalidPublicKeyError(
                f"Invalid JWKS format: 'keys' must be a non-empty array in response from {jwks_url}"
            )
        
        # Cache the result
        _jwks_cache[jwks_url] = {
            'jwks': jwks,
            'timestamp': now
        }
        
        logger.debug(f"Cached JWKS from {jwks_url} with {len(jwks['keys'])} keys")
        return jwks
        
    except requests.exceptions.RequestException as e:
        raise InvalidPublicKeyError(f"Failed to fetch JWKS from {jwks_url}: {e}") from e
    except ValueError as e:
        raise InvalidPublicKeyError(f"Invalid JSON in JWKS response from {jwks_url}: {e}") from e


def get_key_from_jwks(jwks: Dict[str, Any], kid: Optional[str] = None) -> str:
    """
    Extract a public key from JWKS and convert to PEM format.
    
    Args:
        jwks: JWKS dictionary (must contain 'keys' array)
        kid: Key ID to search for (optional). If not provided, uses first key.
        
    Returns:
        PEM-formatted public key string
        
    Raises:
        InvalidPublicKeyError: If key cannot be found or converted
        
    Example:
        >>> jwks = fetch_jwks('https://example.com/.well-known/jwks.json')
        >>> pem_key = get_key_from_jwks(jwks, kid='key-123')
    """
    if not isinstance(jwks, dict) or 'keys' not in jwks:
        raise InvalidPublicKeyError("Invalid JWKS: missing 'keys' field")
    
    keys = jwks['keys']
    if not isinstance(keys, list) or len(keys) == 0:
        raise InvalidPublicKeyError("Invalid JWKS: 'keys' must be a non-empty array")
    
    # Find the key
    if kid:
        # Search for specific key ID
        matching_keys = [k for k in keys if k.get('kid') == kid]
        if not matching_keys:
            raise InvalidPublicKeyError(f"Key with kid='{kid}' not found in JWKS")
        jwk = matching_keys[0]
    else:
        # Use first key
        jwk = keys[0]
        logger.debug(f"No kid specified, using first key: {jwk.get('kid', 'no-kid')}")
    
    # Convert JWK to PEM
    return jwk_to_pem(jwk)


def jwk_to_pem(jwk: Dict[str, Any]) -> str:
    """
    Convert a JWK (JSON Web Key) to PEM format.
    
    Supports RSA and EC (Elliptic Curve) keys.
    
    Args:
        jwk: JWK dictionary
        
    Returns:
        PEM-formatted public key string
        
    Raises:
        InvalidPublicKeyError: If JWK cannot be converted
        
    Example:
        >>> jwk = {'kty': 'RSA', 'n': '...', 'e': 'AQAB'}
        >>> pem = jwk_to_pem(jwk)
    """
    try:
        kty = jwk.get('kty')
        
        if kty == 'RSA':
            return _rsa_jwk_to_pem(jwk)
        elif kty == 'EC':
            return _ec_jwk_to_pem(jwk)
        else:
            raise InvalidPublicKeyError(f"Unsupported key type: {kty}")
            
    except Exception as e:
        raise InvalidPublicKeyError(f"Failed to convert JWK to PEM: {e}") from e


def _rsa_jwk_to_pem(jwk: Dict[str, Any]) -> str:
    """Convert RSA JWK to PEM format."""
    try:
        # Extract modulus (n) and exponent (e) from JWK
        n = jwk.get('n')
        e = jwk.get('e')
        
        if not n or not e:
            raise InvalidPublicKeyError("RSA JWK missing required fields 'n' or 'e'")
        
        # Decode base64url-encoded values
        n_int = int.from_bytes(_base64url_decode(n), byteorder='big')
        e_int = int.from_bytes(_base64url_decode(e), byteorder='big')
        
        # Create RSA public key
        public_numbers = rsa.RSAPublicNumbers(e_int, n_int)
        public_key = public_numbers.public_key(default_backend())
        
        # Convert to PEM
        pem = public_key.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo
        )
        
        return pem.decode('utf-8')
        
    except Exception as e:
        raise InvalidPublicKeyError(f"Failed to convert RSA JWK to PEM: {e}") from e


def _ec_jwk_to_pem(jwk: Dict[str, Any]) -> str:
    """Convert EC JWK to PEM format."""
    try:
        # Extract curve and coordinates
        crv = jwk.get('crv')
        x = jwk.get('x')
        y = jwk.get('y')
        
        if not crv or not x or not y:
            raise InvalidPublicKeyError("EC JWK missing required fields 'crv', 'x', or 'y'")
        
        # Map curve name to cryptography curve
        curve_map = {
            'P-256': ec.SECP256R1(),
            'P-384': ec.SECP384R1(),
            'P-521': ec.SECP521R1(),
        }
        
        if crv not in curve_map:
            raise InvalidPublicKeyError(f"Unsupported EC curve: {crv}")
        
        # Decode coordinates
        x_int = int.from_bytes(_base64url_decode(x), byteorder='big')
        y_int = int.from_bytes(_base64url_decode(y), byteorder='big')
        
        # Create EC public key
        public_numbers = ec.EllipticCurvePublicNumbers(x_int, y_int, curve_map[crv])
        public_key = public_numbers.public_key(default_backend())
        
        # Convert to PEM
        pem = public_key.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo
        )
        
        return pem.decode('utf-8')
        
    except Exception as e:
        raise InvalidPublicKeyError(f"Failed to convert EC JWK to PEM: {e}") from e


def _base64url_decode(data: str) -> bytes:
    """Decode base64url-encoded data (RFC 4648)."""
    # Add padding if needed
    padding = 4 - (len(data) % 4)
    if padding != 4:
        data += '=' * padding
    
    # Replace URL-safe characters
    data = data.replace('-', '+').replace('_', '/')
    
    return base64.b64decode(data)
