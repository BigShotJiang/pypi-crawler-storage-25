"""Core OAuth client implementation."""

import logging
from functools import wraps
from pathlib import Path
from typing import Any, Callable, Dict, Optional, Union

import jwt
import requests

from ._utils import load_public_key, fetch_jwks, get_key_from_jwks
from .exceptions import (
    InvalidPublicKeyError,
    JWTVerificationError,
    OAuthExchangeError,
)

logger = logging.getLogger(__name__)


def _exchange_for_token(
    code: str,
    oauth_token_url: str,
    client_id: str,
    api_key: Optional[str] = None,
    timeout: int = 20,
    code_verifier: Optional[str] = None,
    redirect_uri: Optional[str] = None,
    client_assertion: Optional[str] = None,
    client_assertion_type: Optional[str] = None,
    bearer_token: Optional[str] = None,
) -> Dict[str, Any]:
    """Internal helper to perform the code-for-token exchange.

    Both PKCE and RP authentication are mandatory:
    - PKCE (code_verifier): Binds the authorization code to the original caller.
    - RP auth: Bearer token or private_key_jwt assertion proves RP identity.
    """
    try:
        # Build token request payload
        payload = {
            "grant_type": "authorization_code",
            "code": code,
            "client_id": client_id,
        }

        headers: Dict[str, str] = {
            "Content-Type": "application/x-www-form-urlencoded",
            "Accept": "application/json",
        }

        # PKCE is mandatory — always send code_verifier when available
        if code_verifier:
            payload["code_verifier"] = code_verifier

        # RP authentication (Bearer or assertion, mutually exclusive)
        if bearer_token:
            headers["Authorization"] = f"Bearer {bearer_token}"
        elif client_assertion:
            payload["client_assertion"] = client_assertion
            payload["client_assertion_type"] = (
                client_assertion_type
                or "urn:ietf:params:oauth:client-assertion-type:jwt-bearer"
            )

        if api_key:
            headers["apikey"] = api_key

        # Add redirect_uri if provided (OAuth 2.0 standard)
        if redirect_uri:
            payload["redirect_uri"] = redirect_uri

        response = requests.post(
            oauth_token_url,
            data=payload,
            timeout=timeout,
            headers=headers
        )
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        # We'll extract more specific details in the main function
        raise OAuthExchangeError(f"Network error while exchanging code: {e}") from e


def exchange_code_for_claims(
    code: str,
    oauth_token_url: str,
    client_id: str,
    public_key: Optional[Union[str, Path]] = None,
    api_key: Optional[str] = None,
    jwks_url: Optional[str] = None,
    code_verifier: Optional[str] = None,
    redirect_uri: Optional[str] = None,
    timeout: int = 20,
    audience: Optional[str] = None,
    issuer: Optional[str] = None,
    verify_exp: bool = True,
    leeway: int = 0,
    algorithms: Optional[list] = None,
    client_assertion: Optional[str] = None,
    client_assertion_type: Optional[str] = None,
    bearer_token: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Exchange OAuth authorization code for verified JWT claims.
    
    Supports PKCE (Proof Key for Code Exchange) per RFC 7636 for enhanced security.
    
    Args:
        code: Authorization code from OAuth flow
        oauth_token_url: Token endpoint URL
        client_id: OAuth client identifier
        public_key: RS256 public key (PEM string or file path) - optional if jwks_url provided
        jwks_url: JWKS URL to fetch public keys from (alternative to public_key)
        api_key: API key for OAuth provider (required for Hawcx)
        code_verifier: PKCE code verifier (optional, recommended for security)
        redirect_uri: OAuth redirect URI (optional, required by some providers)
        timeout: Request timeout in seconds (default: 20)
        audience: Expected 'aud' claim (optional but recommended)
        issuer: Expected 'iss' claim (optional but recommended)
        verify_exp: Verify token expiration (default: True)
        leeway: Clock skew tolerance in seconds (default: 0)
        algorithms: List of allowed signing algorithms (default: RS256, ES256/384/512, EdDSA)
    
    Returns:
        Dictionary containing the verified JWT claims.
        
    Raises:
        OAuthExchangeError: Code exchange failed
        JWTVerificationError: JWT verification failed
        InvalidPublicKeyError: Public key invalid
        
    Example:
        >>> # Basic usage
        >>> claims = exchange_code_for_claims(
        ...     code=request.form['code'],
        ...     oauth_token_url='https://oauth.example.com/token',
        ...     client_id='my-app',
        ...     public_key='/path/to/public.pem',
        ...     api_key=os.getenv('HAWCX_API_KEY')
        ... )
        
        >>> # With PKCE (recommended)
        >>> claims = exchange_code_for_claims(
        ...     code=request.form['code'],
        ...     oauth_token_url='https://oauth.example.com/token',
        ...     client_id='my-app',
        ...     public_key=os.getenv('OAUTH_PUBLIC_KEY'),
        ...     api_key=os.getenv('HAWCX_API_KEY'),
        ...     code_verifier=session.get('pkce_verifier'),  # From PKCE flow
        ...     redirect_uri='https://myapp.com/callback',
        ...     audience='my-app',
        ...     issuer='https://oauth.example.com'
        ... )
    """
    # Input validation
    if not code or not isinstance(code, str):
        raise OAuthExchangeError("Authorization code must be a non-empty string")
    
    if not oauth_token_url or not isinstance(oauth_token_url, str):
        raise OAuthExchangeError("OAuth token URL must be a non-empty string")
    
    if not client_id or not isinstance(client_id, str):
        raise OAuthExchangeError("Client ID must be a non-empty string")
    
    # Step 2: Exchange code for id_token (with PKCE support)
    try:
        response_body = _exchange_for_token(
            code,
            oauth_token_url,
            client_id,
            api_key,
            timeout,
            code_verifier=code_verifier,
            redirect_uri=redirect_uri,
            client_assertion=client_assertion,
            client_assertion_type=client_assertion_type,
            bearer_token=bearer_token,
        )
    except OAuthExchangeError as e:
        # Catch and re-raise to add more context if possible from response
        if e.__cause__ and isinstance(e.__cause__, requests.exceptions.HTTPError):
            try:
                body = e.__cause__.response.json()
                error_msg = body.get("error_description") or body.get("error") or "Unknown server error"
                raise OAuthExchangeError(
                    f"Code exchange failed: {error_msg}",
                    status_code=e.__cause__.response.status_code,
                    response_body=body
                ) from e.__cause__
            except ValueError:
                raise OAuthExchangeError(
                    "Code exchange failed with non-JSON error response",
                    status_code=e.__cause__.response.status_code
                ) from e.__cause__
        raise

    id_token = response_body.get("id_token")
    if not id_token:
        raise OAuthExchangeError(
            "OAuth server response missing 'id_token' field",
            response_body=response_body
        )
    
    claims = verify_jwt(
        token=id_token,
        public_key=public_key,
        jwks_url=jwks_url,
        audience=audience,
        issuer=issuer,
        verify_exp=verify_exp,
        leeway=leeway,
        algorithms=algorithms,
    )
    return claims


def exchange_code_for_token_and_claims(
    code: str,
    oauth_token_url: str,
    client_id: str,
    public_key: Optional[Union[str, Path]] = None,
    api_key: Optional[str] = None,
    jwks_url: Optional[str] = None,
    code_verifier: Optional[str] = None,
    redirect_uri: Optional[str] = None,
    timeout: int = 20,
    audience: Optional[str] = None,
    issuer: Optional[str] = None,
    verify_exp: bool = True,
    leeway: int = 0,
    algorithms: Optional[list] = None,
    client_assertion: Optional[str] = None,
    client_assertion_type: Optional[str] = None,
    bearer_token: Optional[str] = None,
) -> tuple[Dict[str, Any], str]:
    """
    Exchange OAuth authorization code for verified JWT claims and the raw id_token.

    Supports PKCE (Proof Key for Code Exchange) per RFC 7636 for enhanced security.

    Returns:
        A tuple containing (claims_dict, id_token_str).
    """
    response_body = _exchange_for_token(
        code,
        oauth_token_url,
        client_id,
        api_key,
        timeout,
        code_verifier=code_verifier,
        redirect_uri=redirect_uri,
        client_assertion=client_assertion,
        client_assertion_type=client_assertion_type,
        bearer_token=bearer_token,
    )
    id_token = response_body.get("id_token")
    if not id_token:
        raise OAuthExchangeError(
            "OAuth server response missing 'id_token' field",
            response_body=response_body
        )

    claims = verify_jwt(
        token=id_token,
        public_key=public_key,
        jwks_url=jwks_url,
        audience=audience,
        issuer=issuer,
        verify_exp=verify_exp,
        leeway=leeway,
        algorithms=algorithms,
    )
    return claims, id_token


def verify_jwt(
    token: str,
    public_key: Optional[Union[str, Path]] = None,
    jwks_url: Optional[str] = None,
    audience: Optional[str] = None,
    issuer: Optional[str] = None,
    verify_exp: bool = True,
    leeway: int = 0,
    algorithms: Optional[list] = None,
) -> Dict[str, Any]:
    """
    Verify a JWT and return its claims.
    
    This function verifies the JWT signature using either a JWKS URL or a provided public key
    and validates claims (audience, issuer, expiration).
    
    Args:
        token: JWT token to verify
        public_key: Public key for JWT verification (PEM string or file path). Supports RS256, ES256/384/512, EdDSA
        jwks_url: URL to fetch JWKS from (alternative to public_key). The JWT's 'kid' header will be used to select the key.
        audience: Expected 'aud' claim for validation (optional but recommended)
        issuer: Expected 'iss' claim for validation (optional but recommended)
        verify_exp: Whether to verify token expiration (default: True)
        leeway: Clock skew tolerance in seconds for time-based claims (default: 0)
        algorithms: List of allowed signing algorithms (default: ["RS256", "ES256", "ES384", "ES512", "EdDSA"])
    
    Returns:
        Dictionary containing the verified JWT claims. Common claims include:
        - sub: Subject identifier (usually user ID)
        - email: User's email address
        - iss: Issuer
        - aud: Audience
        - exp: Expiration time
        - iat: Issued at time
        
    Raises:
        JWTVerificationError: When JWT verification fails due to:
            - Invalid signature (token has been tampered with)
            - Expired token (when verify_exp=True)
            - Wrong audience or issuer
            - Token not yet valid (nbf claim)
            - Malformed JWT structure
        
        InvalidPublicKeyError: When the public key is invalid:
            - File not found
            - Invalid PEM format
            - Wrong algorithm
            - Empty key
            - JWKS fetch failed
    
    Example:
        >>> # With JWKS URL (recommended)
        >>> claims = verify_jwt(
        ...     token='eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9...',
        ...     jwks_url='https://example.com/.well-known/jwks.json',
        ...     audience='my-app',
        ...     issuer='https://oauth.example.com'
        ... )
        
        >>> # With static public key
        >>> claims = verify_jwt(
        ...     token='eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9...',
        ...     public_key=Path('keys/public.pem'),
        ...     audience='my-app'
        ... )
    
    Security Notes:
        - Always validate audience and issuer in production
        - Never log the token or claims containing sensitive data
        - Store public keys securely (env vars, secrets manager, etc.)
        - JWKS URLs are recommended for key rotation support
    """
    # Input validation
    if not token or not isinstance(token, str):
        raise JWTVerificationError("Token must be a non-empty string")
    
    # Must provide either public_key or jwks_url
    if not public_key and not jwks_url:
        raise JWTVerificationError("Must provide either 'public_key' or 'jwks_url'")
    
    # Load public key from JWKS or directly
    try:
        if jwks_url:
            # Decode JWT header to get 'kid' (key ID)
            try:
                header = jwt.get_unverified_header(token)
                kid = header.get('kid')
                logger.debug(f"JWT kid: {kid}")
            except Exception as e:
                raise JWTVerificationError(f"Failed to decode JWT header: {e}") from e
            
            # Fetch JWKS and extract key
            jwks = fetch_jwks(jwks_url)
            pem_key = get_key_from_jwks(jwks, kid=kid)
            logger.debug(f"Using key from JWKS URL: {jwks_url}")
        else:
            # Load public key directly
            pem_key = load_public_key(public_key)
    except InvalidPublicKeyError:
        raise
    except Exception as e:
        raise InvalidPublicKeyError(f"Unexpected error loading public key: {e}") from e
    
    # Build verification options
    verify_options = {
        "verify_signature": True,
        "verify_exp": verify_exp,
        "verify_aud": audience is not None,
        "verify_iss": issuer is not None,
    }
    
    # Default to common OAuth algorithms if not specified
    if algorithms is None:
        algorithms = ["RS256", "ES256", "ES384", "ES512", "EdDSA"]
    
    # Decode and verify
    try:
        claims = jwt.decode(
            token,
            pem_key,
            algorithms=algorithms,
            audience=audience,
            issuer=issuer,
            leeway=leeway,
            options=verify_options
        )
        
        logger.debug(f"Successfully verified JWT for subject: {claims.get('sub')}")
        return claims
        
    except jwt.ExpiredSignatureError as e:
        raise JWTVerificationError(
            "Token has expired. Please re-authenticate.",
            original_error=e
        ) from e
    
    except jwt.InvalidAudienceError as e:
        raise JWTVerificationError(
            f"Token audience validation failed. Expected: {audience}",
            original_error=e
        ) from e
    
    except jwt.InvalidIssuerError as e:
        raise JWTVerificationError(
            f"Token issuer validation failed. Expected: {issuer}",
            original_error=e
        ) from e
    
    except jwt.ImmatureSignatureError as e:
        raise JWTVerificationError(
            "Token not yet valid (nbf claim). Check server clock synchronization.",
            original_error=e
        ) from e
    
    except jwt.InvalidSignatureError as e:
        raise JWTVerificationError(
            "Token signature verification failed. Token may have been tampered with.",
            original_error=e
        ) from e
    
    except jwt.DecodeError as e:
        raise JWTVerificationError(
            "Token has invalid structure or encoding",
            original_error=e
        ) from e
    
    except jwt.InvalidTokenError as e:
        raise JWTVerificationError(
            f"Token validation failed: {e}",
            original_error=e
        ) from e
    
    except Exception as e:
        logger.error(f"--- JWT VERIFICATION FAILED ---")
        logger.error(f"The token that could not be verified is:\n---\n{token}\n---")
        raise JWTVerificationError(
            f"Unexpected error during JWT verification: {e}",
            original_error=e
        ) from e


def require_oauth_claims(
    oauth_token_url: str,
    client_id: str,
    public_key: Union[str, Path],
    code_field: str = "code",
    algorithms: Optional[list] = None,
    **verify_kwargs
) -> Callable:
    """
    Flask decorator to extract and verify OAuth claims from authorization code.
    
    This decorator:
    1. Extracts the authorization code from the request (form data by default)
    2. Exchanges it for verified claims using exchange_code_for_claims()
    3. Attaches the claims to Flask's g.oauth_claims
    4. Returns a 400 error if the code is missing
    5. Returns a 401 error if verification fails
    
    Args:
        oauth_token_url: Token endpoint URL
        client_id: OAuth client identifier  
        public_key: Public key (PEM string or file path). Supports RS256, ES256/384/512, EdDSA
        code_field: Name of the form field containing the code (default: "code")
        algorithms: List of allowed signing algorithms (optional)
        **verify_kwargs: Additional arguments passed to exchange_code_for_claims()
            (timeout, audience, issuer, verify_exp, leeway)
    
    Returns:
        Decorator function
    
    Example:
        >>> from flask import Flask, g, redirect
        >>> from hawcx_oauth_client import require_oauth_claims
        >>> 
        >>> app = Flask(__name__)
        >>> 
        >>> @app.post('/callback')
        >>> @require_oauth_claims(
        ...     oauth_token_url=os.getenv('OAUTH_TOKEN_ENDPOINT'),
        ...     client_id=os.getenv('CLIENT_ID'),
        ...     public_key=os.getenv('PUBLIC_KEY'),
        ...     audience='my-app'
        ... )
        >>> def callback():
        ...     claims = g.oauth_claims
        ...     user_id = claims['sub']
        ...     # Mint your own access token here
        ...     return redirect('/dashboard')
    """
    def decorator(f: Callable) -> Callable:
        @wraps(f)
        def wrapped(*args, **kwargs):
            from flask import g, request

            # Extract code from request
            code = request.form.get(code_field)
            if not code:
                logger.warning(f"Missing '{code_field}' in request")
                return (f"Missing {code_field}", 400)
            
            # Exchange and verify
            try:
                claims = exchange_code_for_claims(
                    code=code,
                    oauth_token_url=oauth_token_url,
                    client_id=client_id,
                    public_key=public_key,
                    algorithms=algorithms,
                    **verify_kwargs
                )
                g.oauth_claims = claims
                logger.info(f"Successfully authenticated user: {claims.get('sub')}")
                
            except (OAuthExchangeError, JWTVerificationError, InvalidPublicKeyError) as e:
                logger.error(f"OAuth verification failed: {e}")
                return (str(e), 401)
            
            return f(*args, **kwargs)
        
        return wrapped
    return decorator

