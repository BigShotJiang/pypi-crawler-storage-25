"""Tests for the bootstrap authentication flow."""

import json
import time
import uuid

import jwt
import pytest
import requests
import responses
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives import serialization

from hawcx_oauth_client.bootstrap import (
    HawcxBootstrapClient,
    BootstrapToken,
    BootstrapChallengeError,
    BootstrapExchangeError,
    BootstrapSigningError,
)
from hawcx_oauth_client.bootstrap.crypto import (
    create_client_assertion,
    create_dpop_proof,
    compute_jwk_thumbprint,
    load_ec_private_key,
    ec_private_key_to_jwk,
)


# ---------- Fixtures ----------

@pytest.fixture(scope="session")
def ec_keypair():
    """Generate a test ES256 keypair."""
    key = ec.generate_private_key(ec.SECP256R1())
    private_pem = key.private_bytes(
        serialization.Encoding.PEM,
        serialization.PrivateFormat.PKCS8,
        serialization.NoEncryption(),
    ).decode()
    public_pem = key.public_key().public_bytes(
        serialization.Encoding.PEM,
        serialization.PublicFormat.SubjectPublicKeyInfo,
    ).decode()
    return private_pem, public_pem, key


@pytest.fixture
def client(ec_keypair):
    """Create a HawcxBootstrapClient with test keys."""
    private_pem, _, _ = ec_keypair
    return HawcxBootstrapClient(
        hawcx_base_url="https://api.hawcx.test",
        client_id="cl_test",
        private_key_pem=private_pem,
        kid="test-key-1",
        api_key="test-api-key",
        origin="https://app.test.com",
    )


@pytest.fixture
def challenge_response():
    """Standard challenge response from the server."""
    return {
        "client_id": "cl_test",
        "aud": "https://api.hawcx.test/bootstrap/exchange",
        "nonce": "n_test-nonce-12345",
        "exp": int(time.time()) + 60,
        "scope": "hawcx:tx.start hawcx:tx.submit",
        "origin": "https://app.test.com",
        "dpop_required": False,
        "token_type_hint": "Bearer",
    }


@pytest.fixture
def token_response():
    """Standard exchange token response."""
    return {
        "frontend_access_token": "eyJhbGciOiJFUzI1NiJ9.test.signature",
        "token_type": "Bearer",
        "expires_in": 120,
        "scope": "hawcx:tx.start hawcx:tx.submit",
    }


# ---------- Crypto tests ----------

class TestCrypto:
    def test_load_ec_private_key(self, ec_keypair):
        private_pem, _, _ = ec_keypair
        key = load_ec_private_key(private_pem)
        assert isinstance(key, ec.EllipticCurvePrivateKey)

    def test_load_ec_private_key_invalid(self):
        with pytest.raises(Exception):
            load_ec_private_key("not a key")

    def test_ec_private_key_to_jwk(self, ec_keypair):
        _, _, key = ec_keypair
        jwk = ec_private_key_to_jwk(key, kid="test-1")
        assert jwk["kty"] == "EC"
        assert jwk["crv"] == "P-256"
        assert jwk["kid"] == "test-1"
        assert "x" in jwk
        assert "y" in jwk

    def test_compute_jwk_thumbprint(self, ec_keypair):
        _, _, key = ec_keypair
        jwk = ec_private_key_to_jwk(key, kid="test-1")
        thumbprint = compute_jwk_thumbprint(jwk)
        assert isinstance(thumbprint, str)
        assert len(thumbprint) > 0
        # Deterministic
        assert compute_jwk_thumbprint(jwk) == thumbprint

    def test_create_client_assertion(self, ec_keypair):
        private_pem, public_pem, key = ec_keypair
        assertion = create_client_assertion(
            client_id="cl_test",
            audience="https://api.hawcx.test/bootstrap/exchange",
            nonce="n_test-nonce",
            scope="hawcx:tx.start",
            private_key_pem=private_pem,
            kid="test-key-1",
            origin="https://app.test.com",
        )

        # Decode and verify structure
        claims = jwt.decode(assertion, key.public_key(), algorithms=["ES256"], audience="https://api.hawcx.test/bootstrap/exchange")
        assert claims["iss"] == "cl_test"
        assert claims["sub"] == "cl_test"
        assert claims["aud"] == "https://api.hawcx.test/bootstrap/exchange"
        assert claims["nonce"] == "n_test-nonce"
        assert claims["scope"] == "hawcx:tx.start"
        assert claims["origin"] == "https://app.test.com"
        assert "jti" in claims
        assert "iat" in claims
        assert "exp" in claims
        # TTL should be <= 120s
        assert claims["exp"] - claims["iat"] <= 120

        # Verify header has kid
        header = jwt.get_unverified_header(assertion)
        assert header["kid"] == "test-key-1"
        assert header["alg"] == "ES256"

    def test_create_client_assertion_no_origin(self, ec_keypair):
        private_pem, _, _ = ec_keypair
        assertion = create_client_assertion(
            client_id="cl_test",
            audience="https://api.hawcx.test/bootstrap/exchange",
            nonce="n_test",
            scope="hawcx:tx.start",
            private_key_pem=private_pem,
            kid="k1",
        )
        claims = jwt.decode(assertion, options={"verify_signature": False})
        assert "origin" not in claims

    def test_create_dpop_proof(self, ec_keypair):
        _, _, key = ec_keypair
        proof = create_dpop_proof(
            method="POST",
            url="https://api.hawcx.test/tx/start",
            private_key=key,
            access_token="test-access-token",
        )

        # Verify structure
        header = jwt.get_unverified_header(proof)
        assert header["typ"] == "dpop+jwt"
        assert header["alg"] == "ES256"
        assert "jwk" in header
        assert header["jwk"]["kty"] == "EC"

        claims = jwt.decode(proof, options={"verify_signature": False})
        assert claims["htm"] == "POST"
        assert claims["htu"] == "https://api.hawcx.test/tx/start"
        assert "jti" in claims
        assert "iat" in claims
        assert "ath" in claims  # access token hash

    def test_create_dpop_proof_no_access_token(self, ec_keypair):
        _, _, key = ec_keypair
        proof = create_dpop_proof(
            method="GET",
            url="https://api.hawcx.test/tx/status",
            private_key=key,
        )
        claims = jwt.decode(proof, options={"verify_signature": False})
        assert "ath" not in claims


# ---------- BootstrapToken tests ----------

class TestBootstrapToken:
    def test_token_not_expired(self):
        token = BootstrapToken(
            access_token="test",
            token_type="Bearer",
            expires_in=120,
            scope="hawcx:tx.start",
        )
        assert not token.is_expired
        assert token.authorization_header == "Bearer test"

    def test_token_expired(self):
        token = BootstrapToken(
            access_token="test",
            token_type="Bearer",
            expires_in=0,
            scope="hawcx:tx.start",
            expires_at=time.time() - 10,
        )
        assert token.is_expired

    def test_token_dpop_type(self):
        token = BootstrapToken(
            access_token="test",
            token_type="DPoP",
            expires_in=120,
            scope="hawcx:tx.start",
        )
        assert token.authorization_header == "DPoP test"


# ---------- Client tests ----------

class TestHawcxBootstrapClient:
    def test_from_env(self, ec_keypair, monkeypatch):
        private_pem, _, _ = ec_keypair
        monkeypatch.setenv("HAWCX_BASE_URL", "https://api.hawcx.test")
        monkeypatch.setenv("HAWCX_CLIENT_ID", "cl_test")
        monkeypatch.setenv("HAWCX_PRIVATE_KEY_PEM", private_pem)
        monkeypatch.setenv("HAWCX_KEY_ID", "test-key-1")
        monkeypatch.setenv("HAWCX_API_KEY", "test-key")

        client = HawcxBootstrapClient.from_env()
        assert client.client_id == "cl_test"
        assert client.hawcx_base_url == "https://api.hawcx.test"
        assert client.api_key == "test-key"

    def test_from_env_missing_required(self, monkeypatch):
        monkeypatch.delenv("HAWCX_BASE_URL", raising=False)
        monkeypatch.delenv("HAWCX_CLIENT_ID", raising=False)
        with pytest.raises(BootstrapSigningError, match="Missing required env var"):
            HawcxBootstrapClient.from_env()

    def test_sign_challenge(self, client, challenge_response, ec_keypair):
        assertion = client.sign_challenge(challenge_response)
        assert isinstance(assertion, str)
        # Should be a valid JWT
        parts = assertion.split(".")
        assert len(parts) == 3

    @responses.activate
    def test_authenticate_full_flow(self, client, challenge_response, token_response):
        # Mock challenge endpoint
        responses.add(
            responses.POST,
            "https://api.hawcx.test/bootstrap/challenge",
            json=challenge_response,
            status=200,
        )
        # Mock exchange endpoint
        responses.add(
            responses.POST,
            "https://api.hawcx.test/bootstrap/exchange",
            json=token_response,
            status=200,
        )

        token = client.authenticate()
        assert isinstance(token, BootstrapToken)
        assert token.access_token == token_response["frontend_access_token"]
        assert token.token_type == "Bearer"
        assert token.expires_in == 120
        assert not token.is_expired

        # Verify challenge request had correct body
        challenge_req = json.loads(responses.calls[0].request.body)
        assert challenge_req["client_id"] == "cl_test"
        assert challenge_req["origin"] == "https://app.test.com"

        # Verify exchange request had correct body
        exchange_req = json.loads(responses.calls[1].request.body)
        assert exchange_req["client_id"] == "cl_test"
        assert "client_assertion" in exchange_req

    @responses.activate
    def test_authenticate_challenge_rejected(self, client):
        responses.add(
            responses.POST,
            "https://api.hawcx.test/bootstrap/challenge",
            json={"error": "invalid_client", "error_description": "Unknown client"},
            status=403,
        )

        with pytest.raises(BootstrapChallengeError) as exc_info:
            client.authenticate()
        assert exc_info.value.status_code == 403

    @responses.activate
    def test_authenticate_exchange_rejected(self, client, challenge_response):
        responses.add(
            responses.POST,
            "https://api.hawcx.test/bootstrap/challenge",
            json=challenge_response,
            status=200,
        )
        responses.add(
            responses.POST,
            "https://api.hawcx.test/bootstrap/exchange",
            json={"error": "invalid_client", "error_description": "Invalid assertion"},
            status=401,
        )

        with pytest.raises(BootstrapExchangeError) as exc_info:
            client.authenticate()
        assert exc_info.value.status_code == 401
        assert exc_info.value.error_code == "invalid_client"

    @responses.activate
    def test_authenticate_network_error(self, client):
        responses.add(
            responses.POST,
            "https://api.hawcx.test/bootstrap/challenge",
            body=requests.ConnectionError("Connection refused"),
        )

        with pytest.raises(BootstrapChallengeError, match="request failed"):
            client.authenticate()

    @responses.activate
    def test_headers_include_api_key(self, client, challenge_response):
        responses.add(
            responses.POST,
            "https://api.hawcx.test/bootstrap/challenge",
            json=challenge_response,
            status=200,
        )
        responses.add(
            responses.POST,
            "https://api.hawcx.test/bootstrap/exchange",
            json={
                "frontend_access_token": "tok",
                "token_type": "Bearer",
                "expires_in": 120,
                "scope": "hawcx:tx.start",
            },
            status=200,
        )

        client.authenticate()
        assert responses.calls[0].request.headers["apikey"] == "test-api-key"
