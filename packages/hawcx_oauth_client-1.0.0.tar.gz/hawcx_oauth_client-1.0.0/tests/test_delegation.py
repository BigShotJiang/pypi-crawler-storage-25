import pytest
import time
import json
from pathlib import Path
import responses
import requests

from cryptography.hazmat.primitives.asymmetric import ed25519, rsa, x25519
from cryptography.hazmat.primitives import serialization

from hawcx_oauth_client.delegation.crypto import (
    now_s,
    Ed25519Signer,
    RsaPssSigner,
    Verifier,
    EciesX25519Encryptor,
    EciesX25519Decryptor,
)
from hawcx_oauth_client.delegation.exceptions import (
    DelegationCryptoError,
    DelegationRequestError,
    DelegationResponseError,
)
from hawcx_oauth_client.delegation.client import IdpDelegationClient

# --- Fixtures for generating and providing test keys ---

@pytest.fixture(scope="session")
def key_pairs():
    """Generate and provide Ed25519, RSA, and X25519 key pairs for testing."""
    # Ed25519
    ed_priv = ed25519.Ed25519PrivateKey.generate()
    ed_pub = ed_priv.public_key()

    # RSA
    rsa_priv = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    rsa_pub = rsa_priv.public_key()

    # X25519
    x_priv = x25519.X25519PrivateKey.generate()
    x_pub = x_priv.public_key()

    return {
        "ed25519": {
            "private": ed_priv.private_bytes(
                serialization.Encoding.PEM,
                serialization.PrivateFormat.PKCS8,
                serialization.NoEncryption(),
            ).decode(),
            "public": ed_pub.public_bytes(
                serialization.Encoding.PEM,
                serialization.PublicFormat.SubjectPublicKeyInfo,
            ).decode(),
        },
        "rsa": {
            "private": rsa_priv.private_bytes(
                serialization.Encoding.PEM,
                serialization.PrivateFormat.PKCS8,
                serialization.NoEncryption(),
            ).decode(),
            "public": rsa_pub.public_bytes(
                serialization.Encoding.PEM,
                serialization.PublicFormat.SubjectPublicKeyInfo,
            ).decode(),
        },
        "x25519": {
            "private": x_priv.private_bytes(
                serialization.Encoding.PEM,
                serialization.PrivateFormat.PKCS8,
                serialization.NoEncryption(),
            ).decode(),
            "public": x_pub.public_bytes(
                serialization.Encoding.PEM,
                serialization.PublicFormat.SubjectPublicKeyInfo,
            ).decode(),
        },
    }


class TestCrypto:
    """Tests for the cryptographic utilities in crypto.py."""

    def test_ed25519_sign_verify_roundtrip(self, key_pairs):
        signer = Ed25519Signer(key_pairs["ed25519"]["private"], kid="ed25519-k1")
        verifier = Verifier({"ed25519-k1": key_pairs["ed25519"]["public"]})
        body = b"test message"
        ts = now_s()
        
        sig = signer.sign_detached(body, ts)
        assert sig.alg == "ed25519"
        assert sig.kid == "ed25519-k1"
        
        # Should not raise
        verifier.verify(body, ts, sig.signature_b64, sig.alg, sig.kid)

    def test_rsa_pss_sign_verify_roundtrip(self, key_pairs):
        signer = RsaPssSigner(key_pairs["rsa"]["private"], kid="rsa-k1")
        verifier = Verifier({"rsa-k1": key_pairs["rsa"]["public"]})
        body = b"test message"
        ts = now_s()

        sig = signer.sign_detached(body, ts)
        assert sig.alg == "rsa-pss-sha256"
        assert sig.kid == "rsa-k1"

        # Should not raise
        verifier.verify(body, ts, sig.signature_b64, sig.alg, sig.kid)

    def test_ecies_encrypt_decrypt_roundtrip(self, key_pairs):
        encryptor = EciesX25519Encryptor(key_pairs["x25519"]["public"])
        decryptor = EciesX25519Decryptor(key_pairs["x25519"]["private"])
        plaintext = b'{"hello": "world"}'

        encrypted = encryptor.encrypt(plaintext)
        decrypted = decryptor.decrypt(encrypted)

        assert decrypted == plaintext
    
    def test_verification_fails_tampered_body(self, key_pairs):
        signer = Ed25519Signer(key_pairs["ed25519"]["private"], kid="k1")
        verifier = Verifier({"k1": key_pairs["ed25519"]["public"]})
        body = b"original message"
        ts = now_s()
        sig = signer.sign_detached(body, ts)

        with pytest.raises(DelegationCryptoError, match="Signature verification failed"):
            verifier.verify(b"tampered message", ts, sig.signature_b64, sig.alg, sig.kid)

    def test_verification_fails_wrong_key(self, key_pairs):
        signer = Ed25519Signer(key_pairs["ed25519"]["private"], kid="k1")
        # Generate a different key for verification
        wrong_pub_key = ed25519.Ed25519PrivateKey.generate().public_key().public_bytes(
            serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo
        ).decode()
        verifier = Verifier({"k1": wrong_pub_key})
        body = b"message"
        ts = now_s()
        sig = signer.sign_detached(body, ts)

        with pytest.raises(DelegationCryptoError, match="Signature verification failed"):
            verifier.verify(body, ts, sig.signature_b64, sig.alg, sig.kid)

    def test_decryption_fails_wrong_key(self, key_pairs):
        encryptor = EciesX25519Encryptor(key_pairs["x25519"]["public"])
        # Generate a different private key for decryption
        wrong_priv_key = x25519.X25519PrivateKey.generate().private_bytes(
            serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption()
        ).decode()
        decryptor = EciesX25519Decryptor(wrong_priv_key)
        
        encrypted = encryptor.encrypt(b"plaintext")
        with pytest.raises(DelegationCryptoError, match="ECIES decryption failed"):
            decryptor.decrypt(encrypted)

    def test_key_loading_errors(self, key_pairs):
        # Malformed PEM
        with pytest.raises(DelegationCryptoError, match="Failed to load"):
            Ed25519Signer("-----BEGIN GARBAGE-----")
        
        # Wrong key type for signer
        with pytest.raises(DelegationCryptoError, match="not an Ed25519"):
            Ed25519Signer(key_pairs["rsa"]["private"])

        # Wrong key type for encryptor
        with pytest.raises(DelegationCryptoError, match="Failed to load ECIES peer public key"):
            EciesX25519Encryptor(key_pairs["ed25519"]["public"])
    
    def test_verifier_ambiguous_kid(self, key_pairs):
        verifier = Verifier({
            "k1": key_pairs["ed25519"]["public"],
            "k2": key_pairs["rsa"]["public"],
        })
        with pytest.raises(DelegationCryptoError, match="ambiguous key ID"):
            verifier.verify(b"body", now_s(), "sig", "ed25519", kid=None)


@pytest.fixture
def mock_client(key_pairs):
    """Fixture to create a mocked IdpDelegationClient for testing."""
    signer = Ed25519Signer(key_pairs["ed25519"]["private"], kid="sp-k1")
    verifier = Verifier({"idp-k1": key_pairs["ed25519"]["public"]})
    encryptor = EciesX25519Encryptor(key_pairs["x25519"]["public"])
    decryptor = EciesX25519Decryptor(key_pairs["x25519"]["private"])

    return IdpDelegationClient(
        base_url="https://idp.test.com",
        signer=signer,
        verifier=verifier,
        encryptor=encryptor,
        decryptor=decryptor,
        sp_id="test-sp",
    )

class TestIdpDelegationClient:
    """Tests for the IdpDelegationClient."""

    @responses.activate
    def test_mfa_update_success(self, mock_client, key_pairs):
        # --- Mock the IDP's response ---
        # 1. IDP creates an ACK payload
        ack_payload = {
            "v": "1", "type": "delegation.ack", "status": "accepted",
            "result": {"status": "success", "method": "sms", "enabled": True},
        }
        # 2. IDP encrypts it for the SP
        idp_encryptor = EciesX25519Encryptor(key_pairs["x25519"]["public"])
        encrypted_ack = idp_encryptor.encrypt(json.dumps(ack_payload).encode())
        # 3. IDP signs the encrypted envelope
        idp_signer = Ed25519Signer(key_pairs["ed25519"]["private"], kid="idp-k1")
        ts = now_s()
        sig = idp_signer.sign_detached(encrypted_ack, ts)
        
        # 4. Mock the HTTP response
        responses.add(
            responses.POST,
            "https://idp.test.com/mfa/update",
            body=encrypted_ack,
            status=200,
            headers={
                "Content-Type": "application/json",
                "X-Enc-Alg": "x25519-aesgcm",
                "X-Timestamp": str(ts),
                "X-Signature-Alg": sig.alg,
                "X-Signature": sig.signature_b64,
                "X-Key-Id": sig.kid,
            }
        )

        # --- Call the client method ---
        response = mock_client.mfa_update(
            user_id="u-123", method="sms", enabled=True, reason="test"
        )

        # --- Assertions ---
        assert response["status"] == "accepted"
        assert response["result"]["method"] == "sms"
        
        # Verify the request sent by the client was correct
        sent_request = responses.calls[0].request
        assert sent_request.headers["X-SP-Id"] == "test-sp"
        assert sent_request.headers["X-Signature-Alg"] == "ed25519"
        
        # Decrypt the body sent by the client to verify its contents
        decryptor = EciesX25519Decryptor(key_pairs["x25519"]["private"])
        decrypted_payload = decryptor.decrypt(sent_request.body)
        payload = json.loads(decrypted_payload)
        
        assert payload["action"] == "mfa.update"
        assert payload["subject"]["user_id"] == "u-123"

    @responses.activate
    def test_network_error(self, mock_client):
        responses.add(
            responses.POST, "https://idp.test.com/mfa/update", 
            body=requests.exceptions.ConnectionError("Failed to connect")
        )
        with pytest.raises(DelegationRequestError, match="Request to IDP failed"):
            mock_client.mfa_update("u-123", "sms", True, "test")

    @responses.activate
    def test_server_error_500(self, mock_client):
        responses.add(responses.POST, "https://idp.test.com/mfa/update", status=500)
        with pytest.raises(DelegationRequestError, match="IDP returned 500"):
            mock_client.mfa_update("u-123", "sms", True, "test")
            
    @responses.activate
    def test_response_verification_failure(self, mock_client):
        # Mock a response with a bad signature
        responses.add(
            responses.POST, "https://idp.test.com/mfa/update",
            body=b"encrypted_body", status=200,
            headers={
                "X-Enc-Alg": "x25519-aesgcm", "X-Timestamp": str(now_s()),
                "X-Signature-Alg": "ed25519", "X-Signature": "bad-signature", "X-Key-Id": "idp-k1",
            }
        )
        with pytest.raises(DelegationResponseError, match="Failed to process secure response"):
            mock_client.mfa_update("u-123", "sms", True, "test")
            
    @responses.activate
    def test_response_decryption_failure(self, mock_client, key_pairs):
        # Encrypt with a key the client can't decrypt
        wrong_x25519_pub_key = x25519.X25519PrivateKey.generate().public_key().public_bytes(
            serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo
        ).decode()
        wrong_encryptor = EciesX25519Encryptor(wrong_x25519_pub_key)
        encrypted_body = wrong_encryptor.encrypt(b'{"k":"v"}')
        
        # Correctly sign it
        idp_signer = Ed25519Signer(key_pairs["ed25519"]["private"], kid="idp-k1")
        ts = now_s()
        sig = idp_signer.sign_detached(encrypted_body, ts)
        
        responses.add(
            responses.POST, "https://idp.test.com/mfa/update",
            body=encrypted_body, status=200,
            headers={
                "X-Enc-Alg": "x25519-aesgcm", "X-Timestamp": str(ts),
                "X-Signature-Alg": sig.alg, "X-Signature": sig.signature_b64, "X-Key-Id": sig.kid,
            }
        )
        with pytest.raises(DelegationResponseError, match="Failed to process secure response"):
            mock_client.mfa_update("u-123", "sms", True, "test")
