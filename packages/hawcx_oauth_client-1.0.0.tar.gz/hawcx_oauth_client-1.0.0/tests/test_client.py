"""Comprehensive tests for the core client functionality."""

import json
import time
from pathlib import Path
from unittest.mock import Mock, patch

import jwt
import pytest
import responses
from requests.exceptions import ConnectionError, Timeout

from hawcx_oauth_client import (
    InvalidPublicKeyError,
    JWTVerificationError,
    OAuthExchangeError,
    exchange_code_for_claims,
)

# Load test keys
FIXTURES_DIR = Path(__file__).parent / "fixtures"
PRIVATE_KEY = (FIXTURES_DIR / "private_key.pem").read_text()
PUBLIC_KEY = (FIXTURES_DIR / "public_key.pem").read_text()


def create_test_token(claims: dict, private_key: str = PRIVATE_KEY) -> str:
    """Helper to create a test JWT token."""
    return jwt.encode(claims, private_key, algorithm="RS256")


class TestExchangeCodeForClaims:
    """Test the main exchange_code_for_claims function."""
    
    @responses.activate
    def test_successful_exchange_and_verification(self):
        """Test successful code exchange and JWT verification."""
        # Arrange
        test_claims = {
            "sub": "user@example.com",
            "email": "user@example.com",
            "iss": "https://oauth.example.com",
            "aud": "my-app",
            "exp": int(time.time()) + 3600,
            "iat": int(time.time()),
        }
        id_token = create_test_token(test_claims)
        
        responses.add(
            responses.POST,
            "https://oauth.example.com/token",
            json={"id_token": id_token, "expires_in": 3600},
            status=200
        )
        
        # Act
        claims = exchange_code_for_claims(
            code="test_code",
            oauth_token_url="https://oauth.example.com/token",
            client_id="my-app",
            public_key=PUBLIC_KEY,
            audience="my-app",
            issuer="https://oauth.example.com"
        )
        
        # Assert
        assert claims["sub"] == "user@example.com"
        assert claims["email"] == "user@example.com"
        assert len(responses.calls) == 1
        # Body might be str or bytes depending on Python/requests version
        body = responses.calls[0].request.body
        expected = "grant_type=authorization_code&code=test_code&client_id=my-app"
        assert body == expected or body == expected.encode()
    
    @responses.activate
    def test_public_key_from_file(self):
        """Test loading public key from file path."""
        test_claims = {
            "sub": "user@example.com",
            "exp": int(time.time()) + 3600,
        }
        id_token = create_test_token(test_claims)
        
        responses.add(
            responses.POST,
            "https://oauth.example.com/token",
            json={"id_token": id_token},
            status=200
        )
        
        # Use Path object
        claims = exchange_code_for_claims(
            code="test_code",
            oauth_token_url="https://oauth.example.com/token",
            client_id="my-app",
            public_key=FIXTURES_DIR / "public_key.pem"
        )
        
        assert claims["sub"] == "user@example.com"
    
    @responses.activate
    def test_empty_code_raises_error(self):
        """Test that empty code raises OAuthExchangeError."""
        responses.add(responses.POST, "https://oauth.example.com/token", status=500)
        with pytest.raises(OAuthExchangeError, match="code must be a non-empty string"):
            exchange_code_for_claims(
                code="",
                oauth_token_url="https://oauth.example.com/token",
                client_id="my-app",
                public_key=PUBLIC_KEY
            )
    
    @responses.activate
    def test_none_code_raises_error(self):
        """Test that None code raises OAuthExchangeError."""
        responses.add(responses.POST, "https://oauth.example.com/token", status=500)
        with pytest.raises(OAuthExchangeError, match="code must be a non-empty string"):
            exchange_code_for_claims(
                code=None,  # type: ignore
                oauth_token_url="https://oauth.example.com/token",
                client_id="my-app",
                public_key=PUBLIC_KEY
            )
    
    @responses.activate
    def test_empty_oauth_url_raises_error(self):
        """Test that empty OAuth URL raises error."""
        responses.add(responses.POST, "https://oauth.example.com/token", status=500)
        with pytest.raises(OAuthExchangeError, match="OAuth token URL must be a non-empty string"):
            exchange_code_for_claims(
                code="test",
                oauth_token_url="",
                client_id="my-app",
                public_key=PUBLIC_KEY
            )
    
    @responses.activate
    def test_empty_client_id_raises_error(self):
        """Test that empty client ID raises error."""
        responses.add(responses.POST, "https://oauth.example.com/token", status=500)
        with pytest.raises(OAuthExchangeError, match="Client ID must be a non-empty string"):
            exchange_code_for_claims(
                code="test",
                oauth_token_url="https://oauth.example.com/token",
                client_id="",
                public_key=PUBLIC_KEY
            )
    
    @responses.activate
    def test_invalid_code_400_error(self):
        """Test handling of invalid authorization code (400 error)."""
        responses.add(
            responses.POST,
            "https://oauth.example.com/token",
            json={
                "error": "invalid_grant",
                "error_description": "Authorization code is invalid or expired"
            },
            status=400
        )
        
        with pytest.raises(OAuthExchangeError) as exc_info:
            exchange_code_for_claims(
                code="invalid_code",
                oauth_token_url="https://oauth.example.com/token",
                client_id="my-app",
                public_key=PUBLIC_KEY
            )
        
        assert "invalid or expired" in str(exc_info.value).lower()
        assert exc_info.value.status_code == 400
    
    @responses.activate
    def test_server_error_500(self):
        """Test handling of server errors (500)."""
        responses.add(
            responses.POST,
            "https://oauth.example.com/token",
            json={"error": "internal_server_error"},
            status=500
        )
        
        with pytest.raises(OAuthExchangeError) as exc_info:
            exchange_code_for_claims(
                code="test_code",
                oauth_token_url="https://oauth.example.com/token",
                client_id="my-app",
                public_key=PUBLIC_KEY
            )
        
        assert exc_info.value.status_code == 500
    
    @responses.activate
    def test_timeout_error(self):
        """Test handling of request timeout."""
        responses.add(
            responses.POST,
            "https://oauth.example.com/token",
            body=Timeout("Request timeout")
        )
        
        with pytest.raises(OAuthExchangeError, match="timeout"):
            exchange_code_for_claims(
                code="test_code",
                oauth_token_url="https://oauth.example.com/token",
                client_id="my-app",
                public_key=PUBLIC_KEY,
                timeout=5
            )
    
    @responses.activate
    def test_connection_error(self):
        """Test handling of connection errors."""
        responses.add(
            responses.POST,
            "https://oauth.example.com/token",
            body=ConnectionError("Failed to connect")
        )
        
        with pytest.raises(OAuthExchangeError, match="Network error while exchanging code: Failed to connect"):
            exchange_code_for_claims(
                code="test_code",
                oauth_token_url="https://oauth.example.com/token",
                client_id="my-app",
                public_key=PUBLIC_KEY
            )
    
    @responses.activate
    def test_malformed_json_response(self):
        """Test handling of malformed JSON response."""
        responses.add(
            responses.POST,
            "https://oauth.example.com/token",
            body="not valid json",
            status=200
        )
        
        with pytest.raises(OAuthExchangeError, match="Network error while exchanging code: Expecting value"):
            exchange_code_for_claims(
                code="test_code",
                oauth_token_url="https://oauth.example.com/token",
                client_id="my-app",
                public_key=PUBLIC_KEY
            )
    
    @responses.activate
    def test_missing_id_token_in_response(self):
        """Test handling of missing id_token field."""
        responses.add(
            responses.POST,
            "https://oauth.example.com/token",
            json={"access_token": "some_token", "expires_in": 3600},
            status=200
        )
        
        with pytest.raises(OAuthExchangeError, match="missing 'id_token'"):
            exchange_code_for_claims(
                code="test_code",
                oauth_token_url="https://oauth.example.com/token",
                client_id="my-app",
                public_key=PUBLIC_KEY
            )
    
    @responses.activate
    def test_expired_token(self):
        """Test handling of expired JWT."""
        test_claims = {
            "sub": "user@example.com",
            "exp": int(time.time()) - 3600,  # Expired 1 hour ago
            "iat": int(time.time()) - 7200,
        }
        id_token = create_test_token(test_claims)
        
        responses.add(
            responses.POST,
            "https://oauth.example.com/token",
            json={"id_token": id_token},
            status=200
        )
        
        with pytest.raises(JWTVerificationError, match="expired"):
            exchange_code_for_claims(
                code="test_code",
                oauth_token_url="https://oauth.example.com/token",
                client_id="my-app",
                public_key=PUBLIC_KEY,
                verify_exp=True
            )
    
    @responses.activate
    def test_expired_token_with_leeway(self):
        """Test that leeway allows recently expired tokens."""
        test_claims = {
            "sub": "user@example.com",
            "exp": int(time.time()) - 5,  # Expired 5 seconds ago
            "iat": int(time.time()) - 3605,
        }
        id_token = create_test_token(test_claims)
        
        responses.add(
            responses.POST,
            "https://oauth.example.com/token",
            json={"id_token": id_token},
            status=200
        )
        
        # Should succeed with 10 second leeway
        claims = exchange_code_for_claims(
            code="test_code",
            oauth_token_url="https://oauth.example.com/token",
            client_id="my-app",
            public_key=PUBLIC_KEY,
            leeway=10
        )
        
        assert claims["sub"] == "user@example.com"
    
    @responses.activate
    def test_wrong_audience(self):
        """Test validation of wrong audience claim."""
        test_claims = {
            "sub": "user@example.com",
            "aud": "different-app",
            "exp": int(time.time()) + 3600,
        }
        id_token = create_test_token(test_claims)
        
        responses.add(
            responses.POST,
            "https://oauth.example.com/token",
            json={"id_token": id_token},
            status=200
        )
        
        with pytest.raises(JWTVerificationError, match="Token validation failed: Audience doesn't match"):
            exchange_code_for_claims(
                code="test_code",
                oauth_token_url="https://oauth.example.com/token",
                client_id="my-app",
                public_key=PUBLIC_KEY,
                audience="my-app"
            )
    
    @responses.activate
    def test_wrong_issuer(self):
        """Test validation of wrong issuer claim."""
        test_claims = {
            "sub": "user@example.com",
            "iss": "https://wrong-issuer.com",
            "exp": int(time.time()) + 3600,
        }
        id_token = create_test_token(test_claims)
        
        responses.add(
            responses.POST,
            "https://oauth.example.com/token",
            json={"id_token": id_token},
            status=200
        )
        
        with pytest.raises(JWTVerificationError, match="issuer"):
            exchange_code_for_claims(
                code="test_code",
                oauth_token_url="https://oauth.example.com/token",
                client_id="my-app",
                public_key=PUBLIC_KEY,
                issuer="https://oauth.example.com"
            )
    
    @responses.activate
    def test_invalid_signature(self):
        """Test detection of invalid JWT signature (tampering)."""
        # Create token with correct key
        test_claims = {
            "sub": "user@example.com",
            "exp": int(time.time()) + 3600,
        }
        id_token = create_test_token(test_claims)
        
        # Tamper with the token
        parts = id_token.split('.')
        parts[2] = parts[2][:-5] + "XXXXX"  # Change signature
        tampered_token = '.'.join(parts)
        
        responses.add(
            responses.POST,
            "https://oauth.example.com/token",
            json={"id_token": tampered_token},
            status=200
        )
        
        with pytest.raises(JWTVerificationError, match="Token validation failed: Signature verification failed"):
            exchange_code_for_claims(
                code="test_code",
                oauth_token_url="https://oauth.example.com/token",
                client_id="my-app",
                public_key=PUBLIC_KEY
            )
    
    @responses.activate
    def test_malformed_jwt(self):
        """Test handling of malformed JWT structure."""
        responses.add(
            responses.POST,
            "https://oauth.example.com/token",
            json={"id_token": "not.a.valid.jwt.structure"},
            status=200
        )
        
        with pytest.raises(JWTVerificationError):
            exchange_code_for_claims(
                code="test_code",
                oauth_token_url="https://oauth.example.com/token",
                client_id="my-app",
                public_key=PUBLIC_KEY
            )
    
    @responses.activate
    def test_public_key_file_not_found(self):
        """Test error when public key file doesn't exist."""
        responses.add(responses.POST, "https://oauth.example.com/token", status=500)
        with pytest.raises(InvalidPublicKeyError, match="not found"):
            exchange_code_for_claims(
                code="test_code",
                oauth_token_url="https://oauth.example.com/token",
                client_id="my-app",
                public_key="/nonexistent/path/to/key.pem"
            )
    
    @responses.activate
    def test_invalid_public_key_format(self):
        """Test error with invalid PEM format."""
        responses.add(responses.POST, "https://oauth.example.com/token", status=500)
        # Use a string with newlines to avoid file path detection
        with pytest.raises(InvalidPublicKeyError, match="PEM format"):
            exchange_code_for_claims(
                code="test_code",
                oauth_token_url="https://oauth.example.com/token",
                client_id="my-app",
                public_key="this is not\na valid pem key\nat all"
            )
    
    @responses.activate
    def test_empty_public_key(self):
        """Test error with empty public key."""
        responses.add(responses.POST, "https://oauth.example.com/token", status=500)
        with pytest.raises(InvalidPublicKeyError, match="empty"):
            exchange_code_for_claims(
                code="test_code",
                oauth_token_url="https://oauth.example.com/token",
                client_id="my-app",
                public_key=""
            )
    
    @responses.activate
    def test_token_not_yet_valid(self):
        """Test handling of token with nbf (not before) in the future."""
        test_claims = {
            "sub": "user@example.com",
            "exp": int(time.time()) + 3600,
            "nbf": int(time.time()) + 300,  # Not valid for 5 minutes
            "iat": int(time.time()),
        }
        id_token = create_test_token(test_claims)
        
        responses.add(
            responses.POST,
            "https://oauth.example.com/token",
            json={"id_token": id_token},
            status=200
        )
        
        with pytest.raises(JWTVerificationError, match="not yet valid"):
            exchange_code_for_claims(
                code="test_code",
                oauth_token_url="https://oauth.example.com/token",
                client_id="my-app",
                public_key=PUBLIC_KEY
            )
    
    @responses.activate
    def test_skip_expiration_verification(self):
        """Test that expired tokens are accepted when verify_exp=False."""
        test_claims = {
            "sub": "user@example.com",
            "exp": int(time.time()) - 3600,  # Expired
        }
        id_token = create_test_token(test_claims)
        
        responses.add(
            responses.POST,
            "https://oauth.example.com/token",
            json={"id_token": id_token},
            status=200
        )
        
        # Should succeed when expiration verification is disabled
        claims = exchange_code_for_claims(
            code="test_code",
            oauth_token_url="https://oauth.example.com/token",
            client_id="my-app",
            public_key=PUBLIC_KEY,
            verify_exp=False
        )
        
        assert claims["sub"] == "user@example.com"

