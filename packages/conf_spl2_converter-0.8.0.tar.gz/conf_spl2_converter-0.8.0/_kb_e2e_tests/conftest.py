import json
import os
import pathlib
from unittest.mock import patch

import pytest

from _kb_e2e_tests.utils import create_index
from conf_spl2_converter.converter.input_config import InputConfig
from conf_spl2_converter.knowledge_builder.common_utils.spl2_utils import get_combined_knowledge_base_provider_spl2_file
from conf_spl2_converter.knowledge_builder.knowledge_base.nr_knowledge_base_creator import create_knowledge_base
from conf_spl2_converter.knowledge_builder.spl2_content_creator.spl2_content_creator import create_spl2_content

# Repo root: _kb_e2e_tests -> repo
os.chdir(pathlib.Path(__file__).resolve().parents[1])

# Test TA used when scenario does not specify paths (flat layout: props.conf at root)
_E2E_TA_DIR = (
    pathlib.Path(__file__).resolve().parents[1]
    / "tests"
    / "knowledge_builder"
    / "resources"
    / "splunk-add-on-for-cisco-asa-5.2.0"
)


class MockedInput(InputConfig):
    """Test double: uses scenario input_config dict and optional ta_path/pt_conf_files for e2e."""

    def __init__(self, config, ta_path=None, pt_conf_files=None):
        self.input_to_process = config
        self.ta_path = ta_path or str(_E2E_TA_DIR)
        self.original_ta_path = self.ta_path
        self._pt_conf_files = pt_conf_files

    def get_pt_conf_files(self):
        if self._pt_conf_files is not None:
            return [str(p) for p in self._pt_conf_files]
        # Fallback: flat TA layout (props.conf, transforms.conf at ta_path root)
        return [
            str(pathlib.Path(self.ta_path) / "props.conf"),
            str(pathlib.Path(self.ta_path) / "transforms.conf"),
        ]


@pytest.fixture
def input_config(request):
    """Per parametrized scenario so each test gets the correct config and template path."""
    param = request.param
    if isinstance(param, dict):
        param = param.copy()
        ta_path = param.pop("_ta_path", None)
        pt_conf_files = param.pop("_pt_conf_files", None)
        config = param
    else:
        config = param
        ta_path = pt_conf_files = None
    ic = MockedInput(config, ta_path=ta_path, pt_conf_files=pt_conf_files)
    return ic


@pytest.fixture
def knowledge_base_object(input_config):
    """
    Build knowledge base and generate a single SPL2 template for all sourcetypes.
    Use TA-only knowledge source so e2e does not require security_content/detections.
    :return: Knowledge base dict (kb or kb_pairs).
    """
    with patch("conf_spl2_converter.knowledge_builder.knowledge_base.nr_knowledge_base_creator.KNOWLEDGE_SOURCE", "ta"):
        kb, kb_pairs = create_knowledge_base(input_config)
    create_spl2_content(input_config, kb_pairs)
    return kb_pairs if kb_pairs else kb


@pytest.fixture
def generated_template_path(input_config, knowledge_base_object):
    """Path to the generated SPL2 template (single file with all sourcetypes)."""
    is_kb_pairs = (
        isinstance(knowledge_base_object, dict)
        and len(knowledge_base_object) > 0
        and isinstance(next(iter(knowledge_base_object.keys())), tuple)
    )
    sourcetypes = sorted({k[0] for k in knowledge_base_object}) if is_kb_pairs else input_config.get_input_sourcetypes()
    path = get_combined_knowledge_base_provider_spl2_file(sourcetypes)
    return os.path.abspath(path)


@pytest.fixture(scope="session", autouse=True)
def general_config():
    with open(pathlib.Path(__file__).resolve().parent / "config.json") as config_file:
        config = json.load(config_file)

    config["hec_raw_url"] = f"https://{config['ip']}:{config['port']}/services/collector/raw"
    config["index_url"] = f"https://{config['ip']}:{config['api_port']}/services/data/indexes"
    return config


@pytest.fixture(scope="session", autouse=True)
def setup_environment(general_config):
    create_index(general_config)
