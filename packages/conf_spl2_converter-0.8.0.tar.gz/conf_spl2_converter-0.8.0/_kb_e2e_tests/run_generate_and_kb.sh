#!/usr/bin/env bash
# Generate and knowledge-build for each sourcetype config. One block per sourcetype.
# Run from repo root: ./_kb_e2e_tests/run_generate_and_kb.sh
# Config: BASE/scenarios/config/splitted. TA storage: REPO/x/ta_storage. Output: BASE/scenarios/templates.

set -e
BASE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO="$(dirname "$BASE")"
CONFIG="$BASE/scenarios/config/splitted"
TA_STORAGE="$REPO/ta_storage"
OUT="$BASE/scenarios/templates"
cd "$REPO"

# --- aws:cloudtrail ---
uv run conf-spl2-converter generate "$TA_STORAGE/splunk-add-on-for-amazon-web-services" -c "$CONFIG/aws_cloudtrail.json" -o "$OUT/gen/aws_cloudtrail"
uv run conf-spl2-converter knowledge-build "$TA_STORAGE/splunk-add-on-for-amazon-web-services" -c "$CONFIG/aws_cloudtrail.json" -o "$OUT/kb/aws_cloudtrail" -k ta

# --- aws:cloudwatchlogs:vpcflow ---
uv run conf-spl2-converter generate "$TA_STORAGE/splunk-add-on-for-amazon-web-services" -c "$CONFIG/aws_cloudwatchlogs_vpcflow.json" -o "$OUT/gen/aws_cloudwatchlogs_vpcflow"
uv run conf-spl2-converter knowledge-build "$TA_STORAGE/splunk-add-on-for-amazon-web-services" -c "$CONFIG/aws_cloudwatchlogs_vpcflow.json" -o "$OUT/kb/aws_cloudwatchlogs_vpcflow" -k ta

# --- pan:firewall ---
uv run conf-spl2-converter generate "$TA_STORAGE/splunk-add-on-for-palo-alto-networks" -c "$CONFIG/pan_firewall.json" -o "$OUT/gen/pan_firewall"
uv run conf-spl2-converter knowledge-build "$TA_STORAGE/splunk-add-on-for-palo-alto-networks" -c "$CONFIG/pan_firewall.json" -o "$OUT/kb/pan_firewall" -k ta

# --- pan:firewall:cloud ---
uv run conf-spl2-converter generate "$TA_STORAGE/splunk-add-on-for-palo-alto-networks" -c "$CONFIG/pan_firewall_cloud.json" -o "$OUT/gen/pan_firewall_cloud"
uv run conf-spl2-converter knowledge-build "$TA_STORAGE/splunk-add-on-for-palo-alto-networks" -c "$CONFIG/pan_firewall_cloud.json" -o "$OUT/kb/pan_firewall_cloud" -k ta

# --- crowdstrike:events:sensor ---
uv run conf-spl2-converter generate "$TA_STORAGE/splunk-add-on-for-crowdstrike-fdr" -c "$CONFIG/crowdstrike_events_sensor.json" -o "$OUT/gen/crowdstrike_events_sensor"
uv run conf-spl2-converter knowledge-build "$TA_STORAGE/splunk-add-on-for-crowdstrike-fdr" -c "$CONFIG/crowdstrike_events_sensor.json" -o "$OUT/kb/crowdstrike_events_sensor" -k ta

# --- WinEventLog ---
uv run conf-spl2-converter generate "$TA_STORAGE/splunk-add-on-for-microsoft-windows" -c "$CONFIG/wineventlog.json" -o "$OUT/gen/wineventlog"
uv run conf-spl2-converter knowledge-build "$TA_STORAGE/splunk-add-on-for-microsoft-windows" -c "$CONFIG/wineventlog.json" -o "$OUT/kb/wineventlog" -k ta

# --- XmlWinEventLog ---
uv run conf-spl2-converter generate "$TA_STORAGE/splunk-add-on-for-microsoft-windows" -c "$CONFIG/xmlwineventlog.json" -o "$OUT/gen/xmlwineventlog"
uv run conf-spl2-converter knowledge-build "$TA_STORAGE/splunk-add-on-for-microsoft-windows" -c "$CONFIG/xmlwineventlog.json" -o "$OUT/kb/xmlwineventlog" -k ta

# --- mscs:azure:eventhub ---
uv run conf-spl2-converter generate "$TA_STORAGE/splunk-add-on-for-microsoft-cloud-services" -c "$CONFIG/mscs_azure_eventhub.json" -o "$OUT/gen/mscs_azure_eventhub"
uv run conf-spl2-converter knowledge-build "$TA_STORAGE/splunk-add-on-for-microsoft-cloud-services" -c "$CONFIG/mscs_azure_eventhub.json" -o "$OUT/kb/mscs_azure_eventhub" -k ta

# --- cisco:asa ---
uv run conf-spl2-converter generate "$TA_STORAGE/splunk-add-on-for-cisco-asa" -c "$CONFIG/cisco_asa.json" -o "$OUT/gen/cisco_asa"
uv run conf-spl2-converter knowledge-build "$TA_STORAGE/splunk-add-on-for-cisco-asa" -c "$CONFIG/cisco_asa.json" -o "$OUT/kb/cisco_asa" -k ta

# --- google:gcp:pubsub:message ---
uv run conf-spl2-converter generate "$TA_STORAGE/splunk-add-on-for-google-cloud-platform" -c "$CONFIG/google_gcp_pubsub_message.json" -o "$OUT/gen/google_gcp_pubsub_message"
uv run conf-spl2-converter knowledge-build "$TA_STORAGE/splunk-add-on-for-google-cloud-platform" -c "$CONFIG/google_gcp_pubsub_message.json" -o "$OUT/kb/google_gcp_pubsub_message" -k ta

echo "Done."
