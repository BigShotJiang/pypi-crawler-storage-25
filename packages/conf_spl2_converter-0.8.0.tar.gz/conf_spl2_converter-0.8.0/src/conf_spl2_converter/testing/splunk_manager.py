# Conf To Spl2 Converter
# Copyright (C) 2026 Splunk Inc. All Rights Reserved.
#
# Installation and use subject to the Splunk General Terms,
# see https://www.splunk.com/en_us/legal/splunk-general-terms.html


"""Splunk HEC and SDK utilities for sending events and retrieving extracted fields."""

from __future__ import annotations

import logging
import time

import requests
import splunklib.binding
import splunklib.client as client
import splunklib.results as results
import urllib3

from conf_spl2_converter.testing.constants import (
    DELETE_EVENTS_SPL,
    GET_EVENTS_SPL,
    HEC_HEADERS,
    HEC_RAW_URL,
    SEARCH_RETRY_DELAY,
    SEARCH_RETRY_LIMIT,
    SPLUNK_API_PORT,
    SPLUNK_HEC_TIMEOUT,
    SPLUNK_HOST,
    SPLUNK_INDEX,
    SPLUNK_PASSWORD,
    SPLUNK_USERNAME,
)

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

logger = logging.getLogger("conf-spl2-converter")


def send_event_to_splunk(
    index: str,
    raw_event: str,
    sourcetype: str,
    host: str,
    source: str | None,
    max_retries: int = 3,
    backoff_factor: int = 5,
) -> bool:
    """Send a single raw event to Splunk via HEC with exponential backoff retries."""
    data_encode = raw_event.encode("utf-8")
    params: dict[str, str] = {
        "sourcetype": sourcetype,
        "index": index,
        "host": host,
    }
    if source:
        params["source"] = source

    attempt = 0
    while attempt <= max_retries:
        try:
            response = requests.post(
                url=HEC_RAW_URL,
                data=data_encode,
                params=params,
                headers=HEC_HEADERS,
                verify=False,
                timeout=SPLUNK_HEC_TIMEOUT,
            )
            if response.status_code == 200:
                logger.debug(f"Successfully sent event to Splunk (sourcetype={sourcetype}, host={host})")
                return True
            else:
                logger.warning(f"Failed to send event: status={response.status_code}, response={response.text}")
        except requests.Timeout:
            logger.warning("HEC request timed out, retrying...")
        except requests.ConnectionError as e:
            logger.warning(f"HEC connection error, retrying... {e}")
        except Exception as e:
            logger.warning(f"Unexpected HEC error: {e}")

        attempt += 1
        if attempt <= max_retries:
            wait_time = backoff_factor**attempt
            logger.info(f"Retry {attempt}/{max_retries} after {wait_time}s...")
            time.sleep(wait_time)
        else:
            logger.error("Max HEC retries reached. Event not sent.")
            return False

    return False


class SplunkManager:
    """Manages Splunk SDK connections for retrieving and deleting events."""

    def __init__(
        self,
        host: str = SPLUNK_HOST,
        port: int = SPLUNK_API_PORT,
        username: str = SPLUNK_USERNAME,
        password: str = SPLUNK_PASSWORD,
        index: str = SPLUNK_INDEX,
    ):
        self.host = host
        self.port = port
        self.username = username
        self.index = index

        self.service = client.connect(
            host=self.host,
            port=self.port,
            username=self.username,
            password=password,
            app="search",
        )

        try:
            self.index_service = self.service.indexes[self.index]
            logger.info(f"Connected to existing index '{self.index}'")
        except (KeyError, splunklib.binding.HTTPError):
            logger.info(f"Index '{self.index}' not found, creating...")
            self.index_service = self.service.indexes.create(self.index)
            logger.info(f"Created index '{self.index}'")

        self._ensure_indexed_kv_limit()

    def _ensure_indexed_kv_limit(self, required_limit: int = 1024) -> None:
        """Ensure indexed_kv_limit is high enough for JSON-heavy sourcetypes."""
        try:
            response = self.service.get("/services/configs/conf-limits/kv")
            body = response.body.read().decode("utf-8")
            current_limit = int(body.split("indexed_kv_limit")[1].split("<s:key")[0].split(">")[1].split("<")[0])
        except Exception:
            current_limit = 200

        if current_limit < required_limit:
            logger.info(f"Increasing indexed_kv_limit from {current_limit} to {required_limit}")
            try:
                self.service.post("/services/configs/conf-limits/kv", indexed_kv_limit=required_limit)
                logger.info(f"indexed_kv_limit set to {required_limit}")
            except Exception as e:
                logger.warning(
                    f"Could not update indexed_kv_limit: {e}. "
                    f"Manually set indexed_kv_limit={required_limit} in limits.conf [kv]."
                )
        else:
            logger.debug(f"indexed_kv_limit already {current_limit} (>= {required_limit})")

    def get_events_by_sourcetype(self, sourcetype: str) -> list[dict]:
        """Fetch all events with extracted fields for a given sourcetype."""
        spl_query = GET_EVENTS_SPL.format(index=self.index, sourcetype=sourcetype)
        logger.info(f"Splunk search: {spl_query}")

        results_all: list[dict] = []
        retry = 0
        while not results_all and retry < SEARCH_RETRY_LIMIT:
            if retry > 0:
                logger.info(f"Retrying Splunk search (attempt {retry})")
            kwargs = {"adhoc_search_level": "verbose", "status_buckets": 300}
            job = self.service.jobs.create(spl_query, **kwargs)

            while not job.is_done():
                time.sleep(SEARCH_RETRY_DELAY)

            results_splunk = job.results(output_mode="json", count=0, field_list="*")
            results_iterator = results.JSONResultsReader(results_splunk)
            for result in results_iterator:
                if isinstance(result, dict):
                    results_all.append(result)
            retry += 1

        logger.info(f"Retrieved {len(results_all)} events from Splunk")
        return results_all

    def delete_all_events(self, sourcetype: str) -> None:
        """Delete all events for a given sourcetype from the index."""
        spl_query = DELETE_EVENTS_SPL.format(index=self.index, sourcetype=sourcetype)
        logger.info(f"Deleting events: {spl_query}")
        job = self.service.jobs.create(spl_query, exec_mode="blocking")
        job.cancel()
        logger.info(f"Deleted events for sourcetype '{sourcetype}' from index '{self.index}'")
