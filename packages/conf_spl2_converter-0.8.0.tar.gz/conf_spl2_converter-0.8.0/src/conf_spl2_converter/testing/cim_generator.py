# Conf To Spl2 Converter
# Copyright (C) 2026 Splunk Inc. All Rights Reserved.
#
# Installation and use subject to the Splunk General Terms,
# see https://www.splunk.com/en_us/legal/splunk-general-terms.html


"""Generate module.test.json files from CIM fields embedded in XML sample files (no Splunk required).

When an existing module.test.json is present (e.g. generated via Splunk with ``generate-expected``),
CIM data is merged into matching test entries as ``expected_cim_fields``.  When no prior test exists
for a given sample, a new entry is created with an empty ``expected_destination_result`` and the
``expected_cim_fields`` section populated from the sample's CIM annotations.
"""

from __future__ import annotations

import json
import logging
import os
import time

from conf_spl2_converter.converter.input_config import InputConfig
from conf_spl2_converter.testing.expected_generator import (
    _prepare_module_test,
    _read_existing_module_test,
)
from conf_spl2_converter.testing.sample_collector import (
    collect_samples_for_sourcetypes,
    discover_sample_files,
)

logger = logging.getLogger("conf-spl2-converter")


def _build_cim_section(sample: dict) -> dict | None:
    """Build an ``expected_cim_fields`` dict from a sample's CIM data.

    Returns a dict with ``models`` and ``cim_fields`` keys,
    or None if the sample has no CIM fields.
    """
    cim = sample.get("cim")
    if not cim or not cim.get("cim_fields"):
        return None

    section: dict = {}
    if cim.get("models"):
        section["models"] = cim["models"]
    section["cim_fields"] = dict(cim["cim_fields"])
    return section


def _find_existing_test_index_by_raw(existing_tests: list[dict], raw_value: str) -> int | None:
    """Return the index of an existing test entry whose _raw matches *raw_value*."""
    for idx, test in enumerate(existing_tests):
        try:
            expected = test.get("test", {}).get("expected_destination_result", [])
            if expected and expected[0].get("_raw") == raw_value:
                return idx
        except (KeyError, IndexError):
            continue
    return None


def generate_cim_expected_for_sourcetype(
    samples_file: str,
    sourcetype_slug: str,
    output_dir: str,
) -> int:
    """Generate / augment module.test.json for a sourcetype with CIM fields from the .samples file.

    If an existing module.test.json is present, matching entries (by ``_raw``) get an
    ``expected_cim_fields`` section added.  Samples without a matching existing test
    produce a new entry with an empty ``expected_destination_result``.

    Returns the number of test entries that received CIM data.
    """
    module_test_json_path = os.path.join(output_dir, sourcetype_slug, "module.test.json")

    with open(samples_file) as f:
        samples = [json.loads(line) for line in f]

    if not samples:
        logger.info(f"No samples in '{samples_file}', skipping")
        return 0

    existing_tests = _read_existing_module_test(module_test_json_path)

    seen_raws: set[str] = set()
    skipped_no_cim = 0
    cim_count = 0
    new_entries: list[dict] = []

    for sample in samples:
        cim_section = _build_cim_section(sample)
        if cim_section is None:
            skipped_no_cim += 1
            continue

        raw_value = sample.get("raw", "")
        if raw_value in seen_raws:
            logger.debug(f"Skipping duplicate _raw: {raw_value[:60]}...")
            continue
        seen_raws.add(raw_value)

        existing_idx = _find_existing_test_index_by_raw(existing_tests, raw_value)
        if existing_idx is not None:
            existing_tests[existing_idx]["test"]["expected_cim_fields"] = cim_section
            cim_count += 1
        else:
            transport = sample.get("transport", {})
            stub_fields: dict = {
                "_raw": raw_value,
                "source": transport.get("source", ""),
                "sourcetype": transport.get("sourcetype", ""),
                "host": transport.get("host", ""),
            }
            entry = _prepare_module_test(
                sourcetype_slug,
                stub_fields,
                source_host=transport.get("host", ""),
            )
            entry["test"]["expected_destination_result"] = []
            entry["test"]["expected_cim_fields"] = cim_section
            new_entries.append(entry)
            cim_count += 1

    if skipped_no_cim:
        logger.info(f"Skipped {skipped_no_cim} sample(s) without CIM fields")

    if cim_count == 0:
        logger.warning(f"No samples with CIM fields found in '{samples_file}'")
        return 0

    module_test_json = existing_tests + new_entries

    output_path = os.path.join(output_dir, sourcetype_slug)
    os.makedirs(output_path, exist_ok=True)
    with open(module_test_json_path, "w") as f:
        json.dump(module_test_json, f, indent=2)
        f.write("\n")

    merged = cim_count - len(new_entries)
    logger.info(
        f"Generated module.test.json at '{module_test_json_path}' with {cim_count} CIM test(s) "
        f"({merged} merged into existing, {len(new_entries)} new)"
    )
    return cim_count


def run_cim_pipeline(
    ta_path: str,
    config_file: str | None = None,
    output_dir: str | None = None,
) -> None:
    """Run the CIM-based test generation pipeline (no Splunk / Docker required).

    Steps:
        1. Read configuration to determine sourcetypes.
        2. Discover and collect XML sample files.
        3. For each sourcetype, generate module.test.json from embedded CIM fields.
    """
    process_start = time.time()
    logger.info("=" * 20 + " CIM TEST PIPELINE - STARTING " + "=" * 20)

    input_config = InputConfig(ta_path, config_file)

    if not output_dir:
        output_dir = os.path.join(input_config.ta_path, "default", "data", "spl2")
    os.makedirs(output_dir, exist_ok=True)

    ta_repo_root = input_config.original_ta_path
    sample_files = discover_sample_files(ta_repo_root)
    if not sample_files:
        sample_files = discover_sample_files(input_config.ta_path)

    if not sample_files:
        logger.warning("No sample files found. Nothing to generate.")
        return

    input_sourcetypes = input_config.get_input_sourcetypes()
    total_tests = 0

    for input_sourcetype in input_sourcetypes:
        start_time = time.time()
        logger.info(f"======= Processing sourcetype: '{input_sourcetype}' =======")

        sourcetype_slug = input_config.get_slug_for_sourcetype(input_sourcetype)
        if not sourcetype_slug:
            logger.warning(f"No slug for '{input_sourcetype}', skipping")
            continue

        sourcetypes_to_process = [input_sourcetype]
        sub_sourcetypes = input_config.get_sub_sourcetypes(input_sourcetype)
        if sub_sourcetypes:
            logger.info(f"Found {len(sub_sourcetypes)} sub_sourcetypes: {sub_sourcetypes}")
            sourcetypes_to_process.extend(sub_sourcetypes)

        samples_output_file = os.path.join(output_dir, sourcetype_slug, f"{sourcetype_slug}.samples")

        collected = collect_samples_for_sourcetypes(
            sample_files=sample_files,
            sourcetypes_to_collect=sourcetypes_to_process,
            output_file=samples_output_file,
        )
        if collected == 0:
            logger.warning(f"No samples collected for '{input_sourcetype}', skipping")
            continue

        count = generate_cim_expected_for_sourcetype(
            samples_file=samples_output_file,
            sourcetype_slug=sourcetype_slug,
            output_dir=output_dir,
        )
        total_tests += count

        elapsed = time.time() - start_time
        logger.info(f"======= Completed '{input_sourcetype}' in {elapsed:.2f}s =======")

    total_elapsed = time.time() - process_start
    logger.info("=" * 20 + f" CIM TEST PIPELINE - COMPLETE ({total_tests} tests, {total_elapsed:.2f}s) " + "=" * 20)
