# Conf To Spl2 Converter
# Copyright (C) 2026 Splunk Inc. All Rights Reserved.
#
# Installation and use subject to the Splunk General Terms,
# see https://www.splunk.com/en_us/legal/splunk-general-terms.html


"""End-to-end pipeline: collect samples, run through Splunk, generate expected test outputs."""

from __future__ import annotations

import logging
import os
import time

from conf_spl2_converter.converter.input_config import InputConfig
from conf_spl2_converter.testing.docker_manager import is_splunk_running, start_splunk, stop_splunk
from conf_spl2_converter.testing.expected_generator import generate_expected_for_sourcetype
from conf_spl2_converter.testing.sample_collector import collect_samples_for_sourcetypes, discover_sample_files

logger = logging.getLogger("conf-spl2-converter")


def run_test_pipeline(
    ta_path: str,
    config_file: str | None = None,
    output_dir: str | None = None,
    skip_docker: bool = False,
    keep_running: bool = False,
) -> None:
    """Run the full test generation pipeline.

    Steps:
        1. Start Splunk Docker container with the TA mounted (unless --skip-docker).
        2. Collect test samples from the TA's tests/knowledge/samples/.
        3. For each sourcetype, send samples through Splunk and capture extracted fields.
        4. Generate module.test.json files with expected outputs.
        5. Stop Docker container (unless --keep-running).

    Args:
        ta_path: Path to the TA package directory.
        config_file: Optional path to field_extraction_config.json.
        output_dir: Output directory for generated files.
        skip_docker: If True, assume Splunk is already running.
        keep_running: If True, leave the Splunk container running after completion.
    """
    process_start = time.time()
    logger.info("=" * 20 + " TEST PIPELINE - STARTING " + "=" * 20)

    input_config = InputConfig(ta_path, config_file)

    if not output_dir:
        output_dir = os.path.join(input_config.ta_path, "default", "data", "spl2")
    os.makedirs(output_dir, exist_ok=True)

    ta_label = _resolve_ta_label(input_config)
    ta_package_path = input_config.ta_path

    if not skip_docker:
        if is_splunk_running():
            logger.info("Splunk container already running, reusing it")
        else:
            start_splunk(ta_package_path, ta_label)
    else:
        logger.info("Skipping Docker management (--skip-docker)")

    # Resolve sample files directory: check the original TA path first
    # (the repo root, not the resolved package/ subdirectory)
    ta_repo_root = input_config.original_ta_path
    sample_files = discover_sample_files(ta_repo_root)
    if not sample_files:
        sample_files = discover_sample_files(ta_package_path)

    if not sample_files:
        logger.warning("No sample files found. Skipping sample collection.")

    try:
        input_sourcetypes = input_config.get_input_sourcetypes()

        for input_sourcetype in input_sourcetypes:
            start_time = time.time()
            logger.info(f"======= Processing sourcetype: '{input_sourcetype}' =======")

            sourcetype_slug = input_config.get_slug_for_sourcetype(input_sourcetype)
            if not sourcetype_slug:
                logger.warning(f"No slug for '{input_sourcetype}', skipping")
                continue

            sourcetypes_to_process = [input_sourcetype]
            sub_sourcetypes = input_config.get_sub_sourcetypes(input_sourcetype)
            if sub_sourcetypes:
                logger.info(f"Found {len(sub_sourcetypes)} sub_sourcetypes: {sub_sourcetypes}")
                sourcetypes_to_process.extend(sub_sourcetypes)

            samples_output_file = os.path.join(output_dir, sourcetype_slug, f"{sourcetype_slug}.samples")

            if sample_files:
                collected = collect_samples_for_sourcetypes(
                    sample_files=sample_files,
                    sourcetypes_to_collect=sourcetypes_to_process,
                    output_file=samples_output_file,
                )
                if collected == 0:
                    logger.warning(f"No samples collected for '{input_sourcetype}', skipping expected generation")
                    continue
            elif not os.path.exists(samples_output_file):
                logger.warning(f"No samples file at '{samples_output_file}', skipping")
                continue

            string_to_array_fields = input_config.get_convert_string_to_array(input_sourcetype)

            generate_expected_for_sourcetype(
                samples_file=samples_output_file,
                sourcetype_slug=sourcetype_slug,
                sourcetypes_to_process=sourcetypes_to_process,
                output_dir=output_dir,
                string_to_array_fields=string_to_array_fields,
            )

            elapsed = time.time() - start_time
            logger.info(f"======= Completed '{input_sourcetype}' in {elapsed / 60:.2f} min =======")

    finally:
        if not skip_docker and not keep_running:
            stop_splunk()
        elif keep_running:
            logger.info("Leaving Splunk container running (--keep-running)")

    total_elapsed = time.time() - process_start
    logger.info("=" * 20 + f" TEST PIPELINE - COMPLETE ({total_elapsed / 60:.2f} min) " + "=" * 20)


def _resolve_ta_label(input_config: InputConfig) -> str:
    """Determine the TA label for the Splunk apps directory from config or directory name."""
    sourcetypes = input_config.get_input_sourcetypes()
    if sourcetypes:
        addon_name = input_config.get_addon_name_for_sourcetype(sourcetypes[0])
        if addon_name:
            return addon_name

    ta_dir = os.path.basename(os.path.normpath(input_config.ta_path))
    return ta_dir
