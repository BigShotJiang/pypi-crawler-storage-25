# Conf To Spl2 Converter
# Copyright (C) 2026 Splunk Inc. All Rights Reserved.
#
# Installation and use subject to the Splunk General Terms,
# see https://www.splunk.com/en_us/legal/splunk-general-terms.html


"""Constants for Splunk testing infrastructure."""

import os

SPLUNK_HOST = os.environ.get("SPL2_TF_SPLUNK_INSTANCE_IP", "127.0.0.1")
SPLUNK_HEC_PORT = int(os.environ.get("SPL2_TF_SPLUNK_INSTANCE_PORT", "8088"))
SPLUNK_API_PORT = int(os.environ.get("SPL2_TF_SPLUNK_INSTANCE_API_PORT", "8089"))
SPLUNK_USERNAME = os.environ.get("SPL2_TF_SPLUNK_INSTANCE_USERNAME", "admin")
SPLUNK_PASSWORD = os.environ.get("SPL2_TF_SPLUNK_INSTANCE_PASSWORD", "newPassword")
SPLUNK_INDEX = os.environ.get("SPL2_TF_SPLUNK_INSTANCE_INDEX", "cov_test")
SPLUNK_HEC_TOKEN = os.environ.get("SPL2_TF_SPLUNK_INSTANCE_HEC_TOKEN", "cc7f4d5e-62fc-4e13-9022-7a2de70863ca")
SPLUNK_HEC_TIMEOUT = 10

HEC_RAW_URL = f"https://{SPLUNK_HOST}:{SPLUNK_HEC_PORT}/services/collector/raw"
HEC_HEADERS = {"Authorization": f"Splunk {SPLUNK_HEC_TOKEN}"}

GET_EVENTS_SPL = "| search index={index} sourcetype={sourcetype} host=* | fields *"
DELETE_EVENTS_SPL = "| search index={index} sourcetype={sourcetype} earliest=0 | delete"

SEARCH_RETRY_LIMIT = 3
SEARCH_RETRY_DELAY = 0.2
MAX_WORKERS = 15

DOCKER_COMPOSE_DIR = os.path.join(
    os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__)))), "docker"
)
DOCKER_CONTAINER_NAME = "splunk-field-extraction"

IGNORE_KEYS_FOR_COMPARISON = {
    "punct",
    "linecount",
    "timeendpos",
    "timestartpos",
    "index",
    "date_hour",
    "date_mday",
    "date_minute",
    "date_month",
    "date_second",
    "date_wday",
    "date_year",
    "date_zone",
    "tag",
    "tag::eventtype",
    "eventtype",
    "splunk_server",
}

MODULE_TEST_TEMPLATE = {
    "filename": "pipeline_{sourcetype_slug}.spl2",
    "test": {
        "source": '[{{_raw: "{raw}", source: "{source}", sourcetype: "{sourcetype}", host: "{host}"}}]',
        "expected_destination_result": [],
    },
}
