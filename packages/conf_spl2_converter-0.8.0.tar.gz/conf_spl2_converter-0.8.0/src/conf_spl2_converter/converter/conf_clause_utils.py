# Conf To Spl2 Converter
# Copyright (C) 2026 Splunk Inc. All Rights Reserved.
#
# Installation and use subject to the Splunk General Terms,
# see https://www.splunk.com/en_us/legal/splunk-general-terms.html


"""Utilities for detecting and parsing props.conf / transforms.conf clauses."""

from __future__ import annotations

import logging
import re

from conf_spl2_converter.converter.conf_constants import (
    PropsConfClause,
    SplunkEventFields,
    TransformsConfClause,
)

logger = logging.getLogger("conf-spl2-converter")


# ---------------------------------------------------------------------------
# Stanza / KV helpers
# ---------------------------------------------------------------------------


def get_all_stanzas(config):
    return config.sections()


def get_kv_pairs_for_stanza(config, stanza_name):
    return config.items(stanza_name)


# ---------------------------------------------------------------------------
# Clause type detection
# ---------------------------------------------------------------------------


def is_transforms_clause(clause: str) -> bool:
    return clause.upper().startswith(PropsConfClause.TRANSFORMS)


def is_extract_clause(clause: str) -> bool:
    return clause.upper().startswith(PropsConfClause.EXTRACT)


def is_report_clause(clause: str) -> bool:
    return clause.upper().startswith(PropsConfClause.REPORT)


def is_field_alias_attribute(clause: str) -> bool:
    return clause.upper().startswith(PropsConfClause.FIELDALIAS)


def is_eval_clause(clause: str) -> bool:
    return clause.upper().startswith(PropsConfClause.EVAL)


def is_lookup_attribute(clause: str) -> bool:
    return clause.upper().startswith(PropsConfClause.LOOKUP)


def is_kvmode_clause(clause: str) -> bool:
    return clause.upper().startswith(PropsConfClause.KV_MODE)


def is_indexed_extraction_clause(clause: str) -> bool:
    return clause.upper().startswith(PropsConfClause.INDEXED_EXTRACTIONS)


def is_autokvmode_clause(clause: str) -> bool:
    return clause.upper().startswith(PropsConfClause.AUTO_KV_JSON)


SUPPORTED_TIME_CLAUSES = [
    PropsConfClause.TIME_PREFIX,
    PropsConfClause.MAX_TIMESTAMP_LOOKAHEAD,
    PropsConfClause.TIME_FORMAT,
    PropsConfClause.TZ,
    PropsConfClause.DATETIME_CONFIG,
]

SUPPORTED_LINEBREAKING_CLAUSES = [
    PropsConfClause.TRUNCATE,
    PropsConfClause.LINE_BREAKER,
    PropsConfClause.LINE_BREAKER_LOOKBEHIND,
    PropsConfClause.SHOULD_LINEMERGE,
    PropsConfClause.BREAK_ONLY_BEFORE_DATE,
    PropsConfClause.BREAK_ONLY_BEFORE,
    PropsConfClause.MUST_BREAK_AFTER,
    PropsConfClause.MUST_NOT_BREAK_AFTER,
    PropsConfClause.MUST_NOT_BREAK_BEFORE,
    PropsConfClause.MAX_EVENTS,
    PropsConfClause.ROUTE_EVENTS_OLDER_THAN,
    PropsConfClause.EVENT_BREAKER_ENABLE,
    PropsConfClause.EVENT_BREAKER,
    PropsConfClause.LB_CHUNK_BREAKER,
    PropsConfClause.LB_CHUNK_BREAKER_TRUNCATE,
]


def is_time_clause(clause: str) -> bool:
    return clause.upper().strip() in SUPPORTED_TIME_CLAUSES


def is_linebreaking_clause(clause: str) -> bool:
    return clause.upper().strip() in SUPPORTED_LINEBREAKING_CLAUSES


def is_time_prefix_clause(clause: str) -> bool:
    return clause.upper() == PropsConfClause.TIME_PREFIX


def is_max_timestamp_lookahead_clause(clause: str) -> bool:
    return clause.upper() == PropsConfClause.MAX_TIMESTAMP_LOOKAHEAD


# ---------------------------------------------------------------------------
# Clause parsing
# ---------------------------------------------------------------------------


def clean_eval_code(eval_clause_value: str) -> str:
    """Clean multi-line eval expressions."""
    lines = eval_clause_value.splitlines()
    if len(lines) <= 1:
        return eval_clause_value

    cleaned_lines = []
    for i, line in enumerate(lines):
        line = re.sub(r"\\\s*$", "", line)
        if i == 0:
            cleaned_lines.append(line)
        else:
            cleaned_lines.append("\n" + " " * 20 + line)
    return "".join(cleaned_lines)


def parse_eval_clause(eval_clause_key: str, eval_clause_value: str) -> dict:
    """Parse an EVAL-<field> clause into {field, expression}."""
    field_expression = {"field": None, "expression": None}
    eval_clause_value = eval_clause_value.strip()
    eval_clause_key = eval_clause_key.strip()
    for prefix in ["EVAL", "eval", "Eval"]:
        if prefix in eval_clause_key:
            field_expression["field"] = eval_clause_key.removeprefix(prefix + "-")
            field_expression["expression"] = clean_eval_code(eval_clause_value)
            break
    return field_expression


def parse_extract_clause(extract_clause_key: str, extract_clause_values: str) -> list[dict]:
    """Parse EXTRACT clauses into a list of extraction dicts."""
    extract_clause_values = extract_clause_values.strip()
    all_extract_clause_values = [v.strip() for v in extract_clause_values.split(",")]
    regex_extractions = []
    in_clauses = [" in ", " IN ", " In ", " iN "]

    for extract_clause in all_extract_clause_values:
        no_in_clause = True
        for in_clause in in_clauses:
            if in_clause in extract_clause:
                no_in_clause = False
                segments = extract_clause.split(in_clause)
                regex_extractions.append(
                    {
                        "regex": segments[0].strip(),
                        "source_field": segments[1].strip(),
                        "format": None,
                        "dest_field": None,
                    }
                )
        if no_in_clause:
            regex_extractions.append(
                {
                    "regex": extract_clause,
                    "source_field": SplunkEventFields.RAW,
                    "format": None,
                    "dest_field": None,
                }
            )
    return regex_extractions


def parse_report_clause(report_clause_key: str, report_clause_values: str, ta_config_object) -> list[dict]:
    """Parse REPORT clauses."""
    return _process_clause(report_clause_key, report_clause_values, ta_config_object)


def parse_transforms_clause(transforms_clause_key: str, transforms_clause_values: str, ta_config_object):
    """Parse TRANSFORMS clauses."""
    return _process_clause(transforms_clause_key, transforms_clause_values, ta_config_object)


def _process_clause(clause_key: str, clause_values: str, ta_config_object) -> list[dict] | dict:
    """Process REPORT or TRANSFORMS clause values against transforms.conf stanzas."""
    clause_values = clause_values.strip()
    all_clause_values = [v.strip() for v in clause_values.split(",")]
    extractions = []

    for clause in all_clause_values:
        clauses: list = get_kv_pairs_for_stanza(ta_config_object, clause)
        logger.debug(f"Extractions for stanza '{clause}' found: {clauses}")
        has_delims = any(k.upper() == TransformsConfClause.DELIMS for k, _v in clauses)
        has_filename = any(k == TransformsConfClause.FILENAME for k, _v in clauses)
        has_external_type = any(k == TransformsConfClause.EXTERNAL_TYPE for k, _v in clauses)

        if has_filename or has_external_type:
            return dict(clauses)
        elif has_delims:
            delims_extraction = {
                "delims": None,
                "source_field": SplunkEventFields.RAW,
                "fields": None,
                "dest_field": None,
            }
            for k, v in clauses:
                if k.upper() == TransformsConfClause.DELIMS:
                    delims_extraction["delims"] = v.strip()
                elif k.upper() == TransformsConfClause.FIELDS:
                    delims_extraction["fields"] = v.strip()
                elif k == TransformsConfClause.SOURCE_KEY:
                    delims_extraction["source_field"] = v.strip()
            extractions.append(delims_extraction)
        else:
            regex_extraction = {
                "regex": None,
                "source_field": SplunkEventFields.RAW,
                "format": None,
                "dest_field": None,
            }
            for current_clause_key, current_clause_value in clauses:
                if current_clause_key == TransformsConfClause.REGEX:
                    regex_extraction["regex"] = current_clause_value.strip()
                elif current_clause_key == TransformsConfClause.SOURCE_KEY:
                    regex_extraction["source_field"] = current_clause_value.strip()
                elif current_clause_key == TransformsConfClause.FORMAT:
                    regex_extraction["format"] = current_clause_value.strip()
                elif current_clause_key == TransformsConfClause.DEST_KEY:
                    regex_extraction["dest_field"] = current_clause_value.strip()
            extractions.append(regex_extraction)
    return extractions
