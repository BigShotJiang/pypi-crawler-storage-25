# Conf To Spl2 Converter
# Copyright (C) 2026 Splunk Inc. All Rights Reserved.
#
# Installation and use subject to the Splunk General Terms,
# see https://www.splunk.com/en_us/legal/splunk-general-terms.html


"""Parser for SPL lookup commands using ANTLR grammar."""

from __future__ import annotations

from dataclasses import dataclass, field

from antlr4 import CommonTokenStream, InputStream

from conf_spl2_converter.converter.input.grammar.lookup.lookup_splLexer import lookup_splLexer
from conf_spl2_converter.converter.input.grammar.lookup.lookup_splParser import lookup_splParser
from conf_spl2_converter.converter.input.grammar.lookup.lookup_splVisitor import lookup_splVisitor


@dataclass
class LookupCommandData:
    lookup_name: str | None = None
    output_mode: str | None = None
    input_fields: list[tuple[str, str]] = field(default_factory=list)
    output_fields: list[tuple[str, str]] = field(default_factory=list)


class LookupSPLCommandParser(lookup_splVisitor):
    def __init__(self):
        self.command_data = LookupCommandData()

    def visitSpl_cmd_start(self, ctx):
        cmd_ctx = ctx.lookup_spl_command()
        self.command_data.lookup_name = cmd_ctx.lookup_name().getText()
        self.visit(cmd_ctx.input_clause())
        if cmd_ctx.output_clause():
            self.visit(cmd_ctx.output_clause())
        return self

    def visitInput_clause(self, ctx):
        for input_field_mapping in ctx.input_field_mapping():
            lookup_field = input_field_mapping.lookup_field.text
            event_field = input_field_mapping.event_field.text if input_field_mapping.event_field else lookup_field
            self.command_data.input_fields.append((lookup_field, event_field))

    def visitOutput_clause(self, ctx):
        self.command_data.output_mode = ctx.getChild(0).getText().upper()
        for output_field_mapping in ctx.output_field_mapping():
            lookup_destfield = output_field_mapping.lookup_destfield.text
            event_destfield = (
                output_field_mapping.event_destfield.text if output_field_mapping.event_destfield else lookup_destfield
            )
            self.command_data.output_fields.append((lookup_destfield, event_destfield))

    def parse(self, command_str) -> LookupCommandData:
        input_stream = InputStream(command_str)
        lexer = lookup_splLexer(input_stream)
        stream = CommonTokenStream(lexer)
        parser = lookup_splParser(stream)
        tree = parser.spl_cmd_start()
        self.visit(tree)
        return self.command_data
