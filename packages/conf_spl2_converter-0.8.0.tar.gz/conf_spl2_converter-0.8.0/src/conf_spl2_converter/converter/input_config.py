# Conf To Spl2 Converter
# Copyright (C) 2026 Splunk Inc. All Rights Reserved.
#
# Installation and use subject to the Splunk General Terms,
# see https://www.splunk.com/en_us/legal/splunk-general-terms.html


"""Field extraction configuration reader."""

from __future__ import annotations

import json
import logging
import os

from conf_spl2_converter.utils.utils import sluggify_string

logger = logging.getLogger("conf-spl2-converter")

# JSON key constants
ADDON_NAME_KEY = "addon_name"
VERSION = "version"
LABEL = "label"
SAMPLE_FILES = "sample_files"
LB_RULE = "lb_rule"
SOURCE = "source"
SUB_SOURCETYPES = "sub_sourcetypes"
DEFAULT_EXTRACTIONS = "system_default_extractions"
LOOKUPS = "lookups_with_empty_values"
FIELDS_TO_TRIM = "fields_to_trim"
KV_MODE = "kv_mode"
DUPLICATE_FIELDS_TO_REMOVE = "remove_duplicate_fields_case_insensitive"
FIELDS_TO_TRIM_NEWLINES = "fields_to_trim_newlines"
FIELDS_TO_TRIM_QUOTES = "fields_to_trim_quotes"
CONVERT_STRING_TO_ARRAY = "convert_string_to_array"
SLUG = "slug"
HUMAN_READABLE_NAME = "human_readable_name"
SPLUNK_BASE_URL = "splunk_base_url"
TEMPLATE_VERSION = "template_version"
TEMPLATE_NAME = "template_name"
TEMPLATE_DESCRIPTION = "template_description"
TEMPLATE_RUNTIME = "template_runtime"
TEMPLATE_EVENTS = "template_events"
TEMPLATE_SOURCETYPE = "template_sourcetype"


DEFAULT_CONFIG_FILENAME = "field_extraction_config.json"


class InputConfig:
    """Reads a field_extraction_config.json and provides accessor methods for sourcetype configuration.

    Resolution order when no explicit config file is given:
      1. Look for ``field_extraction_config.json`` inside the TA directory.
      2. Fall back to auto-discovering all sourcetypes from ``props.conf``.
    """

    def __init__(self, ta_path: str, config_file: str | None = None):
        self.original_ta_path = ta_path
        self.ta_path = self._resolve_ta_path(ta_path)

        resolved_config = config_file or self._find_default_config()
        self.used_auto_discovery = resolved_config is None
        if resolved_config:
            logger.info(f"Using config file: {resolved_config}")
            with open(resolved_config) as f:
                self.input_to_process: dict = json.load(f)
        else:
            logger.info(f"No {DEFAULT_CONFIG_FILENAME} found; auto-discovering sourcetypes from props.conf")
            self.input_to_process = self._discover_sourcetypes()

    def _sourcetype_config(self, sourcetype: str) -> dict:
        """Return the config dict for a sourcetype (empty dict if missing)."""
        return self.input_to_process.get(sourcetype, {})

    def _find_default_config(self) -> str | None:
        """Look for field_extraction_config.json in the TA directory.

        Checks the resolved ta_path first, then the original (unresolved) path
        to handle layouts like ``<ta>/package/default/`` where the config sits
        at the ``<ta>/`` root.
        """
        for base in (self.ta_path, self.original_ta_path):
            candidate = os.path.join(base, DEFAULT_CONFIG_FILENAME)
            if os.path.isfile(candidate):
                return candidate
        return None

    @staticmethod
    def _resolve_ta_path(ta_path: str) -> str:
        """Resolve the TA package path.

        Accepts either the directory containing ``default/props.conf`` directly,
        or its parent (when the layout is ``<ta>/package/default/...``).
        """
        if os.path.isdir(os.path.join(ta_path, "default")):
            return ta_path
        candidate = os.path.join(ta_path, "package")
        if os.path.isdir(os.path.join(candidate, "default")):
            return candidate
        raise FileNotFoundError(f"Cannot find default/ directory under {ta_path} or {ta_path}/package/")

    def _discover_sourcetypes(self) -> dict:
        """Auto-discover sourcetypes from the TA's props.conf."""
        from addonfactory_splunk_conf_parser_lib import TABConfigParser

        props_path = os.path.join(self.ta_path, "default", "props.conf")
        if not os.path.isfile(props_path):
            raise FileNotFoundError(f"props.conf not found at {props_path}")

        config = TABConfigParser()
        config.read([props_path])

        result = {}
        for stanza in config.sections():
            # Skip source:: stanzas and default
            if stanza.startswith("source::") or stanza == "default":
                continue
            result[stanza] = {SLUG: sluggify_string(stanza)}

        logger.info(f"Auto-discovered {len(result)} sourcetypes from {props_path}")
        return result

    def get_input_sourcetypes(self) -> list[str]:
        return list(self.input_to_process.keys())

    def get_ta_location_for_sourcetype(self, sourcetype: str) -> str:
        return self.ta_path

    def get_slug_for_sourcetype(self, sourcetype: str) -> str | None:
        cfg = self._sourcetype_config(sourcetype)
        return cfg.get(SLUG) or sluggify_string(sourcetype)

    def get_addon_name_for_sourcetype(self, sourcetype: str) -> str:
        return self._sourcetype_config(sourcetype).get(ADDON_NAME_KEY, "")

    def get_source(self, sourcetype: str) -> list[str] | None:
        return self._sourcetype_config(sourcetype).get(SOURCE)

    def get_sub_sourcetypes(self, sourcetype: str) -> list[str] | None:
        return self._sourcetype_config(sourcetype).get(SUB_SOURCETYPES)

    def get_default_stanza(self, sourcetype: str) -> list[str] | None:
        return self._sourcetype_config(sourcetype).get(DEFAULT_EXTRACTIONS)

    def get_lookup_list(self, sourcetype: str) -> list[str]:
        return self._sourcetype_config(sourcetype).get(LOOKUPS, [])

    def get_fields_to_trim(self, sourcetype: str) -> list[str]:
        return self._sourcetype_config(sourcetype).get(FIELDS_TO_TRIM, [])

    def get_duplicate_fields_to_remove(self, sourcetype: str) -> list[str]:
        return self._sourcetype_config(sourcetype).get(DUPLICATE_FIELDS_TO_REMOVE, [])

    def get_fields_to_trim_newlines(self, sourcetype: str) -> list[str]:
        return self._sourcetype_config(sourcetype).get(FIELDS_TO_TRIM_NEWLINES, [])

    def get_fields_to_trim_quotes(self, sourcetype: str) -> list[str]:
        return self._sourcetype_config(sourcetype).get(FIELDS_TO_TRIM_QUOTES, [])

    def get_convert_string_to_array(self, sourcetype: str) -> list[str]:
        return self._sourcetype_config(sourcetype).get(CONVERT_STRING_TO_ARRAY, [])

    def get_kv_mode(self, sourcetype: str) -> str:
        return self._sourcetype_config(sourcetype).get(KV_MODE, "auto")

    def get_pt_conf_files(self) -> list[str]:
        """Return props.conf and transforms.conf paths from the TA."""
        conf_files = [
            os.path.join(self.ta_path, "default", "props.conf"),
            os.path.join(self.ta_path, "default", "transforms.conf"),
        ]
        return [f for f in conf_files if os.path.isfile(f)]

    def get_samples_files_for_sourcetype(self, sourcetype: str) -> list:
        """Knowledge Builder compatibility: sample files for the sourcetype (default empty)."""
        return self._sourcetype_config(sourcetype).get(SAMPLE_FILES, [])

    def get_line_breaking_rule(self, sourcetype: str) -> str | None:
        """Knowledge Builder compatibility: line-breaking rule (default None)."""
        return self._sourcetype_config(sourcetype).get(LB_RULE)

    def get_template_name(self, sourcetype: str) -> str | None:
        return self._sourcetype_config(sourcetype).get(TEMPLATE_NAME)

    def get_template_description(self, sourcetype: str) -> str | None:
        return self._sourcetype_config(sourcetype).get(TEMPLATE_DESCRIPTION)

    def get_template_runtime(self, sourcetype: str) -> list[str] | None:
        return self._sourcetype_config(sourcetype).get(TEMPLATE_RUNTIME)

    def get_template_events(self, sourcetype: str) -> list[dict] | None:
        return self._sourcetype_config(sourcetype).get(TEMPLATE_EVENTS)

    def get_template_sourcetype(self, sourcetype: str) -> dict | None:
        """Return the ``template_sourcetype`` override for the annotation.

        Expected format::

            {"operator": "MATCH", "values": ["/pan[:|_]/i"]}

        or the full form::

            {"field": "sourcetype", "operator": "MATCH", "values": [...]}

        When absent the converter auto-derives an ``EQUAL`` filter.
        """
        return self._sourcetype_config(sourcetype).get(TEMPLATE_SOURCETYPE)

    def get_attribute_value_for_sourcetype(self, sourcetype: str, attribute: str) -> str:
        return self._sourcetype_config(sourcetype).get(attribute, "")
