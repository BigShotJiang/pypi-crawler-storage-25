# Conf To Spl2 Converter
# Copyright (C) 2026 Splunk Inc. All Rights Reserved.
#
# Installation and use subject to the Splunk General Terms,
# see https://www.splunk.com/en_us/legal/splunk-general-terms.html


"""Wrapper around TABConfigParser for reading Splunk .conf files."""

from __future__ import annotations

import logging
from importlib.resources import as_file
from importlib.resources import files as resource_files

from addonfactory_splunk_conf_parser_lib import TABConfigParser

logger = logging.getLogger("conf-spl2-converter")

_DEFAULT_CONF_PACKAGE = resource_files("conf_spl2_converter") / "default_conf"
_DEFAULT_CONF_NAMES = ("props.conf", "transforms.conf")


def get_ta_config_object() -> TABConfigParser:
    """Create a new TABConfigParser instance."""
    return TABConfigParser()


def load_conf_files(config: TABConfigParser, conf_files: list[str]) -> None:
    """Load a list of .conf files into the parser."""
    config.read(conf_files)


def load_default_conf_files(config: TABConfigParser) -> None:
    """Load the bundled system-default props.conf and transforms.conf into *config*.

    These contain Splunk's built-in stanzas (e.g. ``WinEventLog:Default``) that
    TAs may reference via the ``system_default_extractions`` config key but do not
    ship themselves.  The files are located via ``importlib.resources`` so the
    lookup works for both editable installs and proper wheel installs.
    """
    for name in _DEFAULT_CONF_NAMES:
        ref = _DEFAULT_CONF_PACKAGE / name
        with as_file(ref) as path:
            if path.exists():
                config.read([str(path)])
            else:
                logger.warning("Bundled default conf file not found: %s (packaging issue?)", name)
