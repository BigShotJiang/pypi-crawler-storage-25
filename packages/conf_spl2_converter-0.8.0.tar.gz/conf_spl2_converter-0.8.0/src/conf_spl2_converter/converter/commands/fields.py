# Conf To Spl2 Converter
# Copyright (C) 2026 Splunk Inc. All Rights Reserved.
#
# Installation and use subject to the Splunk General Terms,
# see https://www.splunk.com/en_us/legal/splunk-general-terms.html


"""Fields command."""

from conf_spl2_converter.converter.commands.base import SPL2Command


class FieldsCommand(SPL2Command):
    """Generate SPL2 fields command."""

    def __init__(self):
        super().__init__("fields")

    def generate(self, fields, operation):
        return self.template.format(fields=fields, operation=operation).strip()
