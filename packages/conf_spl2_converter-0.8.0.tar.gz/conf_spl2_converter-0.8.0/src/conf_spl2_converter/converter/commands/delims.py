# Conf To Spl2 Converter
# Copyright (C) 2026 Splunk Inc. All Rights Reserved.
#
# Installation and use subject to the Splunk General Terms,
# see https://www.splunk.com/en_us/legal/splunk-general-terms.html


"""Delims-based extraction command."""

from conf_spl2_converter.converter.commands.base import SPL2Command


class DelimsCommand(SPL2Command):
    """Generate SPL2 from delims-based extractions (split + zip_with_keys)."""

    def __init__(self):
        super().__init__("delims")

    def generate(self, delims, source_field, fields):
        return self.template.format(source_field=source_field, delims=delims, fields=fields)
