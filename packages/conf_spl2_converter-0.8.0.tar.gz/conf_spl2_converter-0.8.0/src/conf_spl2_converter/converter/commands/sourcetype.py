# Conf To Spl2 Converter
# Copyright (C) 2026 Splunk Inc. All Rights Reserved.
#
# Installation and use subject to the Splunk General Terms,
# see https://www.splunk.com/en_us/legal/splunk-general-terms.html


"""Sourcetype function command."""

from conf_spl2_converter.converter.commands.base import SPL2Command


class SourcetypeFunctionCommand(SPL2Command):
    """Generate SPL2 sourcetype function."""

    def __init__(self):
        super().__init__("sourcetype_function")

    def generate(self, function, auto_kv_mode, regex_based_extractions, aliases, code_based_extractions):
        return self.template.format(
            function_name=function,
            auto_kv_mode=auto_kv_mode,
            regex_based_extractions=regex_based_extractions,
            aliases=aliases,
            code_based_extractions=code_based_extractions,
        ).strip()
