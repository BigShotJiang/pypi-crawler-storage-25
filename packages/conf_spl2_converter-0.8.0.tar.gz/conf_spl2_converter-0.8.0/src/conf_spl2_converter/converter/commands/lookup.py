# Conf To Spl2 Converter
# Copyright (C) 2026 Splunk Inc. All Rights Reserved.
#
# Installation and use subject to the Splunk General Terms,
# see https://www.splunk.com/en_us/legal/splunk-general-terms.html


"""Lookup commands."""

from conf_spl2_converter.converter.commands.base import SPL2Command
from conf_spl2_converter.converter.parsers.lookup_parser import LookupCommandData, LookupSPLCommandParser


class LookupCommand(SPL2Command):
    """Generate SPL2 lookup command."""

    def __init__(self):
        super().__init__("lookup")

    def parse(self, spl_command_str) -> LookupCommandData:
        extractor = LookupSPLCommandParser()
        return extractor.parse(spl_command_str)

    def convert_spl_to_spl2(self, spl_command_data: LookupCommandData) -> str:
        lookup_name = spl_command_data.lookup_name

        # Workaround for lookup names with hyphens
        if "-" in spl_command_data.lookup_name:
            lookup_name = "'" + spl_command_data.lookup_name + "'"

        spl2_command_args = lookup_name

        input_clause = []
        for lookup_field, event_field in spl_command_data.input_fields:
            if "." in lookup_field:
                lookup_field = f"'{lookup_field}'"
            if "." in event_field:
                event_field = f"'{event_field}'"
            input_clause.append(f"{lookup_field} AS {event_field}" if lookup_field != event_field else lookup_field)
        input_clause_str = ", ".join(input_clause) if input_clause else ""

        spl2_command_args += f" {input_clause_str}"

        output_mode = spl_command_data.output_mode
        if output_mode:
            output_clause = []
            for lookup_destfield, event_destfield in spl_command_data.output_fields:
                if ":" in event_destfield:
                    event_destfield = f"'{event_destfield}'"
                output_clause.append(
                    f"{lookup_destfield} AS {event_destfield}"
                    if lookup_destfield != event_destfield
                    else lookup_destfield
                )
            output_clause_str = ", ".join(output_clause) if output_clause else ""
            spl2_command_args += f" {output_mode} {output_clause_str}"

        return spl2_command_args

    def generate(self, lookup_action):
        spl_command_data = self.parse("lookup " + lookup_action)
        spl2_command_args = self.convert_spl_to_spl2(spl_command_data)
        return self.template.format(lookup_action=spl2_command_args).strip()


class LookupFunctionCommand(SPL2Command):
    """Generate SPL2 lookup function wrapper."""

    def __init__(self):
        super().__init__("lookup_function")

    def generate(self, function, lookups, default_lookup_extractions, scripted_lookups):
        return self.template.format(
            function_name=function,
            lookups=lookups,
            default_lookup_extractions=default_lookup_extractions,
            scripted_lookups=scripted_lookups,
        ).strip()
