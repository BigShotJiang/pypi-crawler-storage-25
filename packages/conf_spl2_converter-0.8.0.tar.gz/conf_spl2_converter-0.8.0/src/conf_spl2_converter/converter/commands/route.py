# Conf To Spl2 Converter
# Copyright (C) 2026 Splunk Inc. All Rights Reserved.
#
# Installation and use subject to the Splunk General Terms,
# see https://www.splunk.com/en_us/legal/splunk-general-terms.html


"""Route commands for SPL2 pipeline generation."""

from conf_spl2_converter.converter.commands.base import SPL2Command


class RouteCommand(SPL2Command):
    """Generate SPL2 route condition."""

    def __init__(self):
        super().__init__("route")

    def generate(self, condition, route_function_name):
        return self.template.format(
            condition=condition,
            branch_function_name=route_function_name,
        ).strip()


class RouteFunctionCommand(SPL2Command):
    """Generate SPL2 route function."""

    def __init__(self):
        super().__init__("route_function")

    def generate(
        self,
        route_function_name,
        source_function,
        source_lookups,
        sourcetype_lookups,
        trim_newline,
        trim_whitespace,
        convert_string_to_array,
        remove_duplicate_fields,
    ):
        return self.template.format(
            branch_function_name=route_function_name,
            source_function=source_function,
            source_lookups=source_lookups,
            sourcetype_lookups=sourcetype_lookups,
            trim_newline=trim_newline,
            trim_whitespace=trim_whitespace,
            convert_string_to_array=convert_string_to_array,
            remove_duplicate_fields=remove_duplicate_fields,
        ).strip()
