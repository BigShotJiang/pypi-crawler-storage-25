grammar rename_spl;

spl_cmd_start: rename_spl_command;
rename_spl_command: 'rename' input_clause;

input_clause: input_field_mapping (separator input_field_mapping)*;

input_field_mapping: source_field=SPLUNK_IDENTIFIER ( as_keyword target_field=SPLUNK_IDENTIFIER)?;
separator: (',' )?;  // allow comma OR nothing (i.e., just space)

as_keyword: AS | ASNEW;

AS: [aA][sS];
ASNEW: [aA][sS][nN][eE][wW];

SPLUNK_IDENTIFIER: [a-zA-Z_][a-zA-Z0-9_{}.:-]*;
WS: [ \t\r\n]+ -> skip;
