# Generated from src/conf_spl2_converter/converter/input/grammar/lookup/lookup_spl.g4 by ANTLR 4.13.2
import sys

from antlr4 import *

if sys.version_info[1] > 5:
    from typing import TextIO
else:
    from typing.io import TextIO


def serializedATN():
    return [
        4,
        1,
        8,
        65,
        2,
        0,
        7,
        0,
        2,
        1,
        7,
        1,
        2,
        2,
        7,
        2,
        2,
        3,
        7,
        3,
        2,
        4,
        7,
        4,
        2,
        5,
        7,
        5,
        2,
        6,
        7,
        6,
        2,
        7,
        7,
        7,
        2,
        8,
        7,
        8,
        1,
        0,
        1,
        0,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        3,
        1,
        25,
        8,
        1,
        1,
        2,
        1,
        2,
        1,
        3,
        1,
        3,
        1,
        3,
        1,
        3,
        5,
        3,
        33,
        8,
        3,
        10,
        3,
        12,
        3,
        36,
        9,
        3,
        1,
        4,
        1,
        4,
        1,
        4,
        1,
        4,
        1,
        4,
        5,
        4,
        43,
        8,
        4,
        10,
        4,
        12,
        4,
        46,
        9,
        4,
        1,
        5,
        1,
        5,
        1,
        5,
        1,
        5,
        3,
        5,
        52,
        8,
        5,
        1,
        6,
        1,
        6,
        1,
        6,
        1,
        6,
        3,
        6,
        58,
        8,
        6,
        1,
        7,
        3,
        7,
        61,
        8,
        7,
        1,
        8,
        1,
        8,
        1,
        8,
        0,
        0,
        9,
        0,
        2,
        4,
        6,
        8,
        10,
        12,
        14,
        16,
        0,
        2,
        1,
        0,
        5,
        6,
        1,
        0,
        3,
        4,
        61,
        0,
        18,
        1,
        0,
        0,
        0,
        2,
        20,
        1,
        0,
        0,
        0,
        4,
        26,
        1,
        0,
        0,
        0,
        6,
        28,
        1,
        0,
        0,
        0,
        8,
        37,
        1,
        0,
        0,
        0,
        10,
        47,
        1,
        0,
        0,
        0,
        12,
        53,
        1,
        0,
        0,
        0,
        14,
        60,
        1,
        0,
        0,
        0,
        16,
        62,
        1,
        0,
        0,
        0,
        18,
        19,
        3,
        2,
        1,
        0,
        19,
        1,
        1,
        0,
        0,
        0,
        20,
        21,
        5,
        1,
        0,
        0,
        21,
        22,
        3,
        4,
        2,
        0,
        22,
        24,
        3,
        6,
        3,
        0,
        23,
        25,
        3,
        8,
        4,
        0,
        24,
        23,
        1,
        0,
        0,
        0,
        24,
        25,
        1,
        0,
        0,
        0,
        25,
        3,
        1,
        0,
        0,
        0,
        26,
        27,
        5,
        7,
        0,
        0,
        27,
        5,
        1,
        0,
        0,
        0,
        28,
        34,
        3,
        10,
        5,
        0,
        29,
        30,
        3,
        14,
        7,
        0,
        30,
        31,
        3,
        10,
        5,
        0,
        31,
        33,
        1,
        0,
        0,
        0,
        32,
        29,
        1,
        0,
        0,
        0,
        33,
        36,
        1,
        0,
        0,
        0,
        34,
        32,
        1,
        0,
        0,
        0,
        34,
        35,
        1,
        0,
        0,
        0,
        35,
        7,
        1,
        0,
        0,
        0,
        36,
        34,
        1,
        0,
        0,
        0,
        37,
        38,
        7,
        0,
        0,
        0,
        38,
        44,
        3,
        12,
        6,
        0,
        39,
        40,
        3,
        14,
        7,
        0,
        40,
        41,
        3,
        12,
        6,
        0,
        41,
        43,
        1,
        0,
        0,
        0,
        42,
        39,
        1,
        0,
        0,
        0,
        43,
        46,
        1,
        0,
        0,
        0,
        44,
        42,
        1,
        0,
        0,
        0,
        44,
        45,
        1,
        0,
        0,
        0,
        45,
        9,
        1,
        0,
        0,
        0,
        46,
        44,
        1,
        0,
        0,
        0,
        47,
        51,
        5,
        7,
        0,
        0,
        48,
        49,
        3,
        16,
        8,
        0,
        49,
        50,
        5,
        7,
        0,
        0,
        50,
        52,
        1,
        0,
        0,
        0,
        51,
        48,
        1,
        0,
        0,
        0,
        51,
        52,
        1,
        0,
        0,
        0,
        52,
        11,
        1,
        0,
        0,
        0,
        53,
        57,
        5,
        7,
        0,
        0,
        54,
        55,
        3,
        16,
        8,
        0,
        55,
        56,
        5,
        7,
        0,
        0,
        56,
        58,
        1,
        0,
        0,
        0,
        57,
        54,
        1,
        0,
        0,
        0,
        57,
        58,
        1,
        0,
        0,
        0,
        58,
        13,
        1,
        0,
        0,
        0,
        59,
        61,
        5,
        2,
        0,
        0,
        60,
        59,
        1,
        0,
        0,
        0,
        60,
        61,
        1,
        0,
        0,
        0,
        61,
        15,
        1,
        0,
        0,
        0,
        62,
        63,
        7,
        1,
        0,
        0,
        63,
        17,
        1,
        0,
        0,
        0,
        6,
        24,
        34,
        44,
        51,
        57,
        60,
    ]


class lookup_splParser(Parser):
    grammarFileName = "lookup_spl.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [DFA(ds, i) for i, ds in enumerate(atn.decisionToState)]

    sharedContextCache = PredictionContextCache()

    literalNames = ["<INVALID>", "'lookup'", "','"]

    symbolicNames = [
        "<INVALID>",
        "<INVALID>",
        "<INVALID>",
        "AS",
        "ASNEW",
        "OUTPUT",
        "OUTPUTNEW",
        "SPLUNK_IDENTIFIER",
        "WS",
    ]

    RULE_spl_cmd_start = 0
    RULE_lookup_spl_command = 1
    RULE_lookup_name = 2
    RULE_input_clause = 3
    RULE_output_clause = 4
    RULE_input_field_mapping = 5
    RULE_output_field_mapping = 6
    RULE_separator = 7
    RULE_as_keyword = 8

    ruleNames = [
        "spl_cmd_start",
        "lookup_spl_command",
        "lookup_name",
        "input_clause",
        "output_clause",
        "input_field_mapping",
        "output_field_mapping",
        "separator",
        "as_keyword",
    ]

    EOF = Token.EOF
    T__0 = 1
    T__1 = 2
    AS = 3
    ASNEW = 4
    OUTPUT = 5
    OUTPUTNEW = 6
    SPLUNK_IDENTIFIER = 7
    WS = 8

    def __init__(self, input: TokenStream, output: TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.2")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None

    class Spl_cmd_startContext(ParserRuleContext):
        __slots__ = "parser"

        def __init__(self, parser, parent: ParserRuleContext = None, invokingState: int = -1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def lookup_spl_command(self):
            return self.getTypedRuleContext(lookup_splParser.Lookup_spl_commandContext, 0)

        def getRuleIndex(self):
            return lookup_splParser.RULE_spl_cmd_start

        def enterRule(self, listener: ParseTreeListener):
            if hasattr(listener, "enterSpl_cmd_start"):
                listener.enterSpl_cmd_start(self)

        def exitRule(self, listener: ParseTreeListener):
            if hasattr(listener, "exitSpl_cmd_start"):
                listener.exitSpl_cmd_start(self)

        def accept(self, visitor: ParseTreeVisitor):
            if hasattr(visitor, "visitSpl_cmd_start"):
                return visitor.visitSpl_cmd_start(self)
            else:
                return visitor.visitChildren(self)

    def spl_cmd_start(self):

        localctx = lookup_splParser.Spl_cmd_startContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_spl_cmd_start)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 18
            self.lookup_spl_command()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Lookup_spl_commandContext(ParserRuleContext):
        __slots__ = "parser"

        def __init__(self, parser, parent: ParserRuleContext = None, invokingState: int = -1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def lookup_name(self):
            return self.getTypedRuleContext(lookup_splParser.Lookup_nameContext, 0)

        def input_clause(self):
            return self.getTypedRuleContext(lookup_splParser.Input_clauseContext, 0)

        def output_clause(self):
            return self.getTypedRuleContext(lookup_splParser.Output_clauseContext, 0)

        def getRuleIndex(self):
            return lookup_splParser.RULE_lookup_spl_command

        def enterRule(self, listener: ParseTreeListener):
            if hasattr(listener, "enterLookup_spl_command"):
                listener.enterLookup_spl_command(self)

        def exitRule(self, listener: ParseTreeListener):
            if hasattr(listener, "exitLookup_spl_command"):
                listener.exitLookup_spl_command(self)

        def accept(self, visitor: ParseTreeVisitor):
            if hasattr(visitor, "visitLookup_spl_command"):
                return visitor.visitLookup_spl_command(self)
            else:
                return visitor.visitChildren(self)

    def lookup_spl_command(self):

        localctx = lookup_splParser.Lookup_spl_commandContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_lookup_spl_command)
        self._la = 0  # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 20
            self.match(lookup_splParser.T__0)
            self.state = 21
            self.lookup_name()
            self.state = 22
            self.input_clause()
            self.state = 24
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la == 5 or _la == 6:
                self.state = 23
                self.output_clause()

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Lookup_nameContext(ParserRuleContext):
        __slots__ = "parser"

        def __init__(self, parser, parent: ParserRuleContext = None, invokingState: int = -1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def SPLUNK_IDENTIFIER(self):
            return self.getToken(lookup_splParser.SPLUNK_IDENTIFIER, 0)

        def getRuleIndex(self):
            return lookup_splParser.RULE_lookup_name

        def enterRule(self, listener: ParseTreeListener):
            if hasattr(listener, "enterLookup_name"):
                listener.enterLookup_name(self)

        def exitRule(self, listener: ParseTreeListener):
            if hasattr(listener, "exitLookup_name"):
                listener.exitLookup_name(self)

        def accept(self, visitor: ParseTreeVisitor):
            if hasattr(visitor, "visitLookup_name"):
                return visitor.visitLookup_name(self)
            else:
                return visitor.visitChildren(self)

    def lookup_name(self):

        localctx = lookup_splParser.Lookup_nameContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_lookup_name)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 26
            self.match(lookup_splParser.SPLUNK_IDENTIFIER)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Input_clauseContext(ParserRuleContext):
        __slots__ = "parser"

        def __init__(self, parser, parent: ParserRuleContext = None, invokingState: int = -1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def input_field_mapping(self, i: int = None):
            if i is None:
                return self.getTypedRuleContexts(lookup_splParser.Input_field_mappingContext)
            else:
                return self.getTypedRuleContext(lookup_splParser.Input_field_mappingContext, i)

        def separator(self, i: int = None):
            if i is None:
                return self.getTypedRuleContexts(lookup_splParser.SeparatorContext)
            else:
                return self.getTypedRuleContext(lookup_splParser.SeparatorContext, i)

        def getRuleIndex(self):
            return lookup_splParser.RULE_input_clause

        def enterRule(self, listener: ParseTreeListener):
            if hasattr(listener, "enterInput_clause"):
                listener.enterInput_clause(self)

        def exitRule(self, listener: ParseTreeListener):
            if hasattr(listener, "exitInput_clause"):
                listener.exitInput_clause(self)

        def accept(self, visitor: ParseTreeVisitor):
            if hasattr(visitor, "visitInput_clause"):
                return visitor.visitInput_clause(self)
            else:
                return visitor.visitChildren(self)

    def input_clause(self):

        localctx = lookup_splParser.Input_clauseContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_input_clause)
        self._la = 0  # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 28
            self.input_field_mapping()
            self.state = 34
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la == 2 or _la == 7:
                self.state = 29
                self.separator()
                self.state = 30
                self.input_field_mapping()
                self.state = 36
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Output_clauseContext(ParserRuleContext):
        __slots__ = "parser"

        def __init__(self, parser, parent: ParserRuleContext = None, invokingState: int = -1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def output_field_mapping(self, i: int = None):
            if i is None:
                return self.getTypedRuleContexts(lookup_splParser.Output_field_mappingContext)
            else:
                return self.getTypedRuleContext(lookup_splParser.Output_field_mappingContext, i)

        def OUTPUT(self):
            return self.getToken(lookup_splParser.OUTPUT, 0)

        def OUTPUTNEW(self):
            return self.getToken(lookup_splParser.OUTPUTNEW, 0)

        def separator(self, i: int = None):
            if i is None:
                return self.getTypedRuleContexts(lookup_splParser.SeparatorContext)
            else:
                return self.getTypedRuleContext(lookup_splParser.SeparatorContext, i)

        def getRuleIndex(self):
            return lookup_splParser.RULE_output_clause

        def enterRule(self, listener: ParseTreeListener):
            if hasattr(listener, "enterOutput_clause"):
                listener.enterOutput_clause(self)

        def exitRule(self, listener: ParseTreeListener):
            if hasattr(listener, "exitOutput_clause"):
                listener.exitOutput_clause(self)

        def accept(self, visitor: ParseTreeVisitor):
            if hasattr(visitor, "visitOutput_clause"):
                return visitor.visitOutput_clause(self)
            else:
                return visitor.visitChildren(self)

    def output_clause(self):

        localctx = lookup_splParser.Output_clauseContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_output_clause)
        self._la = 0  # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 37
            _la = self._input.LA(1)
            if not (_la == 5 or _la == 6):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 38
            self.output_field_mapping()
            self.state = 44
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la == 2 or _la == 7:
                self.state = 39
                self.separator()
                self.state = 40
                self.output_field_mapping()
                self.state = 46
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Input_field_mappingContext(ParserRuleContext):
        __slots__ = "parser"

        def __init__(self, parser, parent: ParserRuleContext = None, invokingState: int = -1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.lookup_field = None  # Token
            self.event_field = None  # Token

        def SPLUNK_IDENTIFIER(self, i: int = None):
            if i is None:
                return self.getTokens(lookup_splParser.SPLUNK_IDENTIFIER)
            else:
                return self.getToken(lookup_splParser.SPLUNK_IDENTIFIER, i)

        def as_keyword(self):
            return self.getTypedRuleContext(lookup_splParser.As_keywordContext, 0)

        def getRuleIndex(self):
            return lookup_splParser.RULE_input_field_mapping

        def enterRule(self, listener: ParseTreeListener):
            if hasattr(listener, "enterInput_field_mapping"):
                listener.enterInput_field_mapping(self)

        def exitRule(self, listener: ParseTreeListener):
            if hasattr(listener, "exitInput_field_mapping"):
                listener.exitInput_field_mapping(self)

        def accept(self, visitor: ParseTreeVisitor):
            if hasattr(visitor, "visitInput_field_mapping"):
                return visitor.visitInput_field_mapping(self)
            else:
                return visitor.visitChildren(self)

    def input_field_mapping(self):

        localctx = lookup_splParser.Input_field_mappingContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_input_field_mapping)
        self._la = 0  # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 47
            localctx.lookup_field = self.match(lookup_splParser.SPLUNK_IDENTIFIER)
            self.state = 51
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la == 3 or _la == 4:
                self.state = 48
                self.as_keyword()
                self.state = 49
                localctx.event_field = self.match(lookup_splParser.SPLUNK_IDENTIFIER)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Output_field_mappingContext(ParserRuleContext):
        __slots__ = "parser"

        def __init__(self, parser, parent: ParserRuleContext = None, invokingState: int = -1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.lookup_destfield = None  # Token
            self.event_destfield = None  # Token

        def SPLUNK_IDENTIFIER(self, i: int = None):
            if i is None:
                return self.getTokens(lookup_splParser.SPLUNK_IDENTIFIER)
            else:
                return self.getToken(lookup_splParser.SPLUNK_IDENTIFIER, i)

        def as_keyword(self):
            return self.getTypedRuleContext(lookup_splParser.As_keywordContext, 0)

        def getRuleIndex(self):
            return lookup_splParser.RULE_output_field_mapping

        def enterRule(self, listener: ParseTreeListener):
            if hasattr(listener, "enterOutput_field_mapping"):
                listener.enterOutput_field_mapping(self)

        def exitRule(self, listener: ParseTreeListener):
            if hasattr(listener, "exitOutput_field_mapping"):
                listener.exitOutput_field_mapping(self)

        def accept(self, visitor: ParseTreeVisitor):
            if hasattr(visitor, "visitOutput_field_mapping"):
                return visitor.visitOutput_field_mapping(self)
            else:
                return visitor.visitChildren(self)

    def output_field_mapping(self):

        localctx = lookup_splParser.Output_field_mappingContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_output_field_mapping)
        self._la = 0  # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 53
            localctx.lookup_destfield = self.match(lookup_splParser.SPLUNK_IDENTIFIER)
            self.state = 57
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la == 3 or _la == 4:
                self.state = 54
                self.as_keyword()
                self.state = 55
                localctx.event_destfield = self.match(lookup_splParser.SPLUNK_IDENTIFIER)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class SeparatorContext(ParserRuleContext):
        __slots__ = "parser"

        def __init__(self, parser, parent: ParserRuleContext = None, invokingState: int = -1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def getRuleIndex(self):
            return lookup_splParser.RULE_separator

        def enterRule(self, listener: ParseTreeListener):
            if hasattr(listener, "enterSeparator"):
                listener.enterSeparator(self)

        def exitRule(self, listener: ParseTreeListener):
            if hasattr(listener, "exitSeparator"):
                listener.exitSeparator(self)

        def accept(self, visitor: ParseTreeVisitor):
            if hasattr(visitor, "visitSeparator"):
                return visitor.visitSeparator(self)
            else:
                return visitor.visitChildren(self)

    def separator(self):

        localctx = lookup_splParser.SeparatorContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_separator)
        self._la = 0  # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 60
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la == 2:
                self.state = 59
                self.match(lookup_splParser.T__1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class As_keywordContext(ParserRuleContext):
        __slots__ = "parser"

        def __init__(self, parser, parent: ParserRuleContext = None, invokingState: int = -1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def AS(self):
            return self.getToken(lookup_splParser.AS, 0)

        def ASNEW(self):
            return self.getToken(lookup_splParser.ASNEW, 0)

        def getRuleIndex(self):
            return lookup_splParser.RULE_as_keyword

        def enterRule(self, listener: ParseTreeListener):
            if hasattr(listener, "enterAs_keyword"):
                listener.enterAs_keyword(self)

        def exitRule(self, listener: ParseTreeListener):
            if hasattr(listener, "exitAs_keyword"):
                listener.exitAs_keyword(self)

        def accept(self, visitor: ParseTreeVisitor):
            if hasattr(visitor, "visitAs_keyword"):
                return visitor.visitAs_keyword(self)
            else:
                return visitor.visitChildren(self)

    def as_keyword(self):

        localctx = lookup_splParser.As_keywordContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_as_keyword)
        self._la = 0  # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 62
            _la = self._input.LA(1)
            if not (_la == 3 or _la == 4):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx
