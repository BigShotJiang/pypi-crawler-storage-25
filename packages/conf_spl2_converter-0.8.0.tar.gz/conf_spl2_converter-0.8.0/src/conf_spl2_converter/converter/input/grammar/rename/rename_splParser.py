# Generated from src/conf_spl2_converter/converter/input/grammar/rename/rename_spl.g4 by ANTLR 4.13.2
import sys

from antlr4 import *

if sys.version_info[1] > 5:
    from typing import TextIO
else:
    from typing.io import TextIO


def serializedATN():
    return [
        4,
        1,
        6,
        38,
        2,
        0,
        7,
        0,
        2,
        1,
        7,
        1,
        2,
        2,
        7,
        2,
        2,
        3,
        7,
        3,
        2,
        4,
        7,
        4,
        2,
        5,
        7,
        5,
        1,
        0,
        1,
        0,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        2,
        1,
        2,
        1,
        2,
        1,
        2,
        5,
        2,
        22,
        8,
        2,
        10,
        2,
        12,
        2,
        25,
        9,
        2,
        1,
        3,
        1,
        3,
        1,
        3,
        1,
        3,
        3,
        3,
        31,
        8,
        3,
        1,
        4,
        3,
        4,
        34,
        8,
        4,
        1,
        5,
        1,
        5,
        1,
        5,
        0,
        0,
        6,
        0,
        2,
        4,
        6,
        8,
        10,
        0,
        1,
        1,
        0,
        3,
        4,
        34,
        0,
        12,
        1,
        0,
        0,
        0,
        2,
        14,
        1,
        0,
        0,
        0,
        4,
        17,
        1,
        0,
        0,
        0,
        6,
        26,
        1,
        0,
        0,
        0,
        8,
        33,
        1,
        0,
        0,
        0,
        10,
        35,
        1,
        0,
        0,
        0,
        12,
        13,
        3,
        2,
        1,
        0,
        13,
        1,
        1,
        0,
        0,
        0,
        14,
        15,
        5,
        1,
        0,
        0,
        15,
        16,
        3,
        4,
        2,
        0,
        16,
        3,
        1,
        0,
        0,
        0,
        17,
        23,
        3,
        6,
        3,
        0,
        18,
        19,
        3,
        8,
        4,
        0,
        19,
        20,
        3,
        6,
        3,
        0,
        20,
        22,
        1,
        0,
        0,
        0,
        21,
        18,
        1,
        0,
        0,
        0,
        22,
        25,
        1,
        0,
        0,
        0,
        23,
        21,
        1,
        0,
        0,
        0,
        23,
        24,
        1,
        0,
        0,
        0,
        24,
        5,
        1,
        0,
        0,
        0,
        25,
        23,
        1,
        0,
        0,
        0,
        26,
        30,
        5,
        5,
        0,
        0,
        27,
        28,
        3,
        10,
        5,
        0,
        28,
        29,
        5,
        5,
        0,
        0,
        29,
        31,
        1,
        0,
        0,
        0,
        30,
        27,
        1,
        0,
        0,
        0,
        30,
        31,
        1,
        0,
        0,
        0,
        31,
        7,
        1,
        0,
        0,
        0,
        32,
        34,
        5,
        2,
        0,
        0,
        33,
        32,
        1,
        0,
        0,
        0,
        33,
        34,
        1,
        0,
        0,
        0,
        34,
        9,
        1,
        0,
        0,
        0,
        35,
        36,
        7,
        0,
        0,
        0,
        36,
        11,
        1,
        0,
        0,
        0,
        3,
        23,
        30,
        33,
    ]


class rename_splParser(Parser):
    grammarFileName = "rename_spl.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [DFA(ds, i) for i, ds in enumerate(atn.decisionToState)]

    sharedContextCache = PredictionContextCache()

    literalNames = ["<INVALID>", "'rename'", "','"]

    symbolicNames = ["<INVALID>", "<INVALID>", "<INVALID>", "AS", "ASNEW", "SPLUNK_IDENTIFIER", "WS"]

    RULE_spl_cmd_start = 0
    RULE_rename_spl_command = 1
    RULE_input_clause = 2
    RULE_input_field_mapping = 3
    RULE_separator = 4
    RULE_as_keyword = 5

    ruleNames = [
        "spl_cmd_start",
        "rename_spl_command",
        "input_clause",
        "input_field_mapping",
        "separator",
        "as_keyword",
    ]

    EOF = Token.EOF
    T__0 = 1
    T__1 = 2
    AS = 3
    ASNEW = 4
    SPLUNK_IDENTIFIER = 5
    WS = 6

    def __init__(self, input: TokenStream, output: TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.2")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None

    class Spl_cmd_startContext(ParserRuleContext):
        __slots__ = "parser"

        def __init__(self, parser, parent: ParserRuleContext = None, invokingState: int = -1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def rename_spl_command(self):
            return self.getTypedRuleContext(rename_splParser.Rename_spl_commandContext, 0)

        def getRuleIndex(self):
            return rename_splParser.RULE_spl_cmd_start

        def enterRule(self, listener: ParseTreeListener):
            if hasattr(listener, "enterSpl_cmd_start"):
                listener.enterSpl_cmd_start(self)

        def exitRule(self, listener: ParseTreeListener):
            if hasattr(listener, "exitSpl_cmd_start"):
                listener.exitSpl_cmd_start(self)

        def accept(self, visitor: ParseTreeVisitor):
            if hasattr(visitor, "visitSpl_cmd_start"):
                return visitor.visitSpl_cmd_start(self)
            else:
                return visitor.visitChildren(self)

    def spl_cmd_start(self):

        localctx = rename_splParser.Spl_cmd_startContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_spl_cmd_start)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 12
            self.rename_spl_command()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Rename_spl_commandContext(ParserRuleContext):
        __slots__ = "parser"

        def __init__(self, parser, parent: ParserRuleContext = None, invokingState: int = -1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def input_clause(self):
            return self.getTypedRuleContext(rename_splParser.Input_clauseContext, 0)

        def getRuleIndex(self):
            return rename_splParser.RULE_rename_spl_command

        def enterRule(self, listener: ParseTreeListener):
            if hasattr(listener, "enterRename_spl_command"):
                listener.enterRename_spl_command(self)

        def exitRule(self, listener: ParseTreeListener):
            if hasattr(listener, "exitRename_spl_command"):
                listener.exitRename_spl_command(self)

        def accept(self, visitor: ParseTreeVisitor):
            if hasattr(visitor, "visitRename_spl_command"):
                return visitor.visitRename_spl_command(self)
            else:
                return visitor.visitChildren(self)

    def rename_spl_command(self):

        localctx = rename_splParser.Rename_spl_commandContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_rename_spl_command)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 14
            self.match(rename_splParser.T__0)
            self.state = 15
            self.input_clause()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Input_clauseContext(ParserRuleContext):
        __slots__ = "parser"

        def __init__(self, parser, parent: ParserRuleContext = None, invokingState: int = -1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def input_field_mapping(self, i: int = None):
            if i is None:
                return self.getTypedRuleContexts(rename_splParser.Input_field_mappingContext)
            else:
                return self.getTypedRuleContext(rename_splParser.Input_field_mappingContext, i)

        def separator(self, i: int = None):
            if i is None:
                return self.getTypedRuleContexts(rename_splParser.SeparatorContext)
            else:
                return self.getTypedRuleContext(rename_splParser.SeparatorContext, i)

        def getRuleIndex(self):
            return rename_splParser.RULE_input_clause

        def enterRule(self, listener: ParseTreeListener):
            if hasattr(listener, "enterInput_clause"):
                listener.enterInput_clause(self)

        def exitRule(self, listener: ParseTreeListener):
            if hasattr(listener, "exitInput_clause"):
                listener.exitInput_clause(self)

        def accept(self, visitor: ParseTreeVisitor):
            if hasattr(visitor, "visitInput_clause"):
                return visitor.visitInput_clause(self)
            else:
                return visitor.visitChildren(self)

    def input_clause(self):

        localctx = rename_splParser.Input_clauseContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_input_clause)
        self._la = 0  # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 17
            self.input_field_mapping()
            self.state = 23
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la == 2 or _la == 5:
                self.state = 18
                self.separator()
                self.state = 19
                self.input_field_mapping()
                self.state = 25
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Input_field_mappingContext(ParserRuleContext):
        __slots__ = "parser"

        def __init__(self, parser, parent: ParserRuleContext = None, invokingState: int = -1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.source_field = None  # Token
            self.target_field = None  # Token

        def SPLUNK_IDENTIFIER(self, i: int = None):
            if i is None:
                return self.getTokens(rename_splParser.SPLUNK_IDENTIFIER)
            else:
                return self.getToken(rename_splParser.SPLUNK_IDENTIFIER, i)

        def as_keyword(self):
            return self.getTypedRuleContext(rename_splParser.As_keywordContext, 0)

        def getRuleIndex(self):
            return rename_splParser.RULE_input_field_mapping

        def enterRule(self, listener: ParseTreeListener):
            if hasattr(listener, "enterInput_field_mapping"):
                listener.enterInput_field_mapping(self)

        def exitRule(self, listener: ParseTreeListener):
            if hasattr(listener, "exitInput_field_mapping"):
                listener.exitInput_field_mapping(self)

        def accept(self, visitor: ParseTreeVisitor):
            if hasattr(visitor, "visitInput_field_mapping"):
                return visitor.visitInput_field_mapping(self)
            else:
                return visitor.visitChildren(self)

    def input_field_mapping(self):

        localctx = rename_splParser.Input_field_mappingContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_input_field_mapping)
        self._la = 0  # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 26
            localctx.source_field = self.match(rename_splParser.SPLUNK_IDENTIFIER)
            self.state = 30
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la == 3 or _la == 4:
                self.state = 27
                self.as_keyword()
                self.state = 28
                localctx.target_field = self.match(rename_splParser.SPLUNK_IDENTIFIER)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class SeparatorContext(ParserRuleContext):
        __slots__ = "parser"

        def __init__(self, parser, parent: ParserRuleContext = None, invokingState: int = -1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def getRuleIndex(self):
            return rename_splParser.RULE_separator

        def enterRule(self, listener: ParseTreeListener):
            if hasattr(listener, "enterSeparator"):
                listener.enterSeparator(self)

        def exitRule(self, listener: ParseTreeListener):
            if hasattr(listener, "exitSeparator"):
                listener.exitSeparator(self)

        def accept(self, visitor: ParseTreeVisitor):
            if hasattr(visitor, "visitSeparator"):
                return visitor.visitSeparator(self)
            else:
                return visitor.visitChildren(self)

    def separator(self):

        localctx = rename_splParser.SeparatorContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_separator)
        self._la = 0  # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 33
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la == 2:
                self.state = 32
                self.match(rename_splParser.T__1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class As_keywordContext(ParserRuleContext):
        __slots__ = "parser"

        def __init__(self, parser, parent: ParserRuleContext = None, invokingState: int = -1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def AS(self):
            return self.getToken(rename_splParser.AS, 0)

        def ASNEW(self):
            return self.getToken(rename_splParser.ASNEW, 0)

        def getRuleIndex(self):
            return rename_splParser.RULE_as_keyword

        def enterRule(self, listener: ParseTreeListener):
            if hasattr(listener, "enterAs_keyword"):
                listener.enterAs_keyword(self)

        def exitRule(self, listener: ParseTreeListener):
            if hasattr(listener, "exitAs_keyword"):
                listener.exitAs_keyword(self)

        def accept(self, visitor: ParseTreeVisitor):
            if hasattr(visitor, "visitAs_keyword"):
                return visitor.visitAs_keyword(self)
            else:
                return visitor.visitChildren(self)

    def as_keyword(self):

        localctx = rename_splParser.As_keywordContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_as_keyword)
        self._la = 0  # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 35
            _la = self._input.LA(1)
            if not (_la == 3 or _la == 4):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx
