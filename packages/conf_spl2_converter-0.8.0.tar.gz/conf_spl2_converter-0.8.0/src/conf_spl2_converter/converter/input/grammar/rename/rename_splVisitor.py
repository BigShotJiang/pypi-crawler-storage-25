# Generated from src/conf_spl2_converter/converter/input/grammar/rename/rename_spl.g4 by ANTLR 4.13.2
from antlr4 import *

if "." in __name__:
    from .rename_splParser import rename_splParser
else:
    from rename_splParser import rename_splParser

# This class defines a complete generic visitor for a parse tree produced by rename_splParser.


class rename_splVisitor(ParseTreeVisitor):
    # Visit a parse tree produced by rename_splParser#spl_cmd_start.
    def visitSpl_cmd_start(self, ctx: rename_splParser.Spl_cmd_startContext):
        return self.visitChildren(ctx)

    # Visit a parse tree produced by rename_splParser#rename_spl_command.
    def visitRename_spl_command(self, ctx: rename_splParser.Rename_spl_commandContext):
        return self.visitChildren(ctx)

    # Visit a parse tree produced by rename_splParser#input_clause.
    def visitInput_clause(self, ctx: rename_splParser.Input_clauseContext):
        return self.visitChildren(ctx)

    # Visit a parse tree produced by rename_splParser#input_field_mapping.
    def visitInput_field_mapping(self, ctx: rename_splParser.Input_field_mappingContext):
        return self.visitChildren(ctx)

    # Visit a parse tree produced by rename_splParser#separator.
    def visitSeparator(self, ctx: rename_splParser.SeparatorContext):
        return self.visitChildren(ctx)

    # Visit a parse tree produced by rename_splParser#as_keyword.
    def visitAs_keyword(self, ctx: rename_splParser.As_keywordContext):
        return self.visitChildren(ctx)


del rename_splParser
