# Conf To Spl2 Converter
# Copyright (C) 2026 Splunk Inc. All Rights Reserved.
#
# Installation and use subject to the Splunk General Terms,
# see https://www.splunk.com/en_us/legal/splunk-general-terms.html


"""Generate @template annotations for SPL2 pipeline files."""

from __future__ import annotations

import json


def _escape_spl2_string(s: str) -> str:
    """Escape a string for use inside an SPL2 double-quoted string literal."""
    return s.replace("\\", "\\\\").replace('"', '\\"')


def _format_events(events: list[dict], base_indent: int = 4) -> str:
    """Format a list of event dicts as an SPL2 array literal."""
    inner_indent = " " * base_indent
    content_indent = " " * (base_indent + 4)

    lines = ["["]
    for i, event in enumerate(events):
        lines.append(f"{inner_indent}{{")
        items = list(event.items())
        for j, (key, value) in enumerate(items):
            value_str = json.dumps(value, ensure_ascii=False)
            comma = "," if j < len(items) - 1 else ""
            lines.append(f'{content_indent}"{key}": {value_str}{comma}')
        comma = "," if i < len(events) - 1 else ""
        lines.append(f"{inner_indent}}}{comma}")
    lines.append("]")
    return "\n".join(lines)


def _format_sourcetype(field: str, operator: str, values: list[str]) -> str:
    """Format the sourcetype object literal."""
    values_str = ", ".join(f'"{_escape_spl2_string(v)}"' for v in values)
    return f'{{field: "{field}", operator: "{operator}", values: [{values_str}]}}'


def generate_template_annotation(
    name: str,
    description: str,
    runtime: list[str],
    sourcetype_values: list[str],
    sourcetype_operator: str = "EQUAL",
    sourcetype_field: str = "sourcetype",
    events: list[dict] | None = None,
) -> str:
    """Build the ``@template(...)`` annotation for an SPL2 pipeline.

    Args:
        name: Human-readable template name.
        description: Template description text.
        runtime: List of runtime profiles (e.g. ``["ingestProcessor", "edgeProcessor"]``).
        sourcetype_values: Values for the sourcetype filter. For ``EQUAL`` these are
            literal sourcetype names; for ``MATCH`` they are regex patterns like
            ``/pan[:|_]/i``.
        sourcetype_operator: Filter operator — ``"EQUAL"`` or ``"MATCH"``.
        sourcetype_field: The field to filter on (almost always ``"sourcetype"``).
        events: Optional sample events to embed in the annotation.

    Returns:
        A string containing the complete ``@template(...);`` annotation.
    """
    sourcetype_str = _format_sourcetype(sourcetype_field, sourcetype_operator, sourcetype_values)

    parts = [f'@template("{_escape_spl2_string(name)}"']

    if description:
        parts.append(f'description: "{_escape_spl2_string(description)}"')

    if runtime:
        runtime_str = ", ".join(f'"{_escape_spl2_string(r)}"' for r in runtime)
        parts.append(f"runtime: [{runtime_str}]")

    parts.append(f"sourcetype: {sourcetype_str}")

    has_events = events is not None and len(events) > 0
    if has_events:
        events_str = _format_events(events)
        parts.append(f"events: {events_str}")

    return ", ".join(parts) + ");"
