# Conf To Spl2 Converter
# Copyright (C) 2026 Splunk Inc. All Rights Reserved.
#
# Installation and use subject to the Splunk General Terms,
# see https://www.splunk.com/en_us/legal/splunk-general-terms.html


"""CLI interface for conf-spl2-converter using Typer."""

import enum
import logging
from pathlib import Path
from typing import Annotated, Optional

import typer

from conf_spl2_converter import __version__
from conf_spl2_converter.converter.content import create_spl2_templates

app = typer.Typer(
    name="conf-spl2-converter",
    help="A CLI tool for converting Splunk .conf configurations to SPL2.",
    add_completion=True,
)

logger = logging.getLogger("conf-spl2-converter")


class OutputFormat(str, enum.Enum):
    """Supported output formats."""

    spl2 = "spl2"
    json = "json"


def _configure_logging(verbose: bool) -> None:
    """Set up logging based on verbosity."""
    level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    )


def version_callback(value: bool):
    """Show version information."""
    if value:
        typer.echo(f"conf-spl2-converter version {__version__}")
        raise typer.Exit()


@app.callback()
def main(
    version: Annotated[
        Optional[bool], typer.Option("--version", callback=version_callback, help="Show version information")
    ] = None,
):
    """conf-spl2-converter - Convert Splunk .conf configurations to SPL2."""


@app.command()
def generate(
    ta_path: Annotated[
        Path,
        typer.Argument(
            exists=True,
            file_okay=False,
            dir_okay=True,
            readable=True,
            help="Path to the TA package directory (contains default/props.conf).",
        ),
    ],
    config: Annotated[
        Optional[Path],
        typer.Option(
            "--config",
            "-c",
            exists=True,
            file_okay=True,
            dir_okay=False,
            readable=True,
            help="Path to field_extraction_config.json. When omitted, looks for it in the TA directory; falls back to auto-discovery from props.conf.",
        ),
    ] = None,
    output: Annotated[
        Optional[Path],
        typer.Option(
            "--output",
            "-o",
            file_okay=False,
            dir_okay=True,
            help="Output directory for generated files. Defaults to <ta_path>/default/data/spl2/.",
        ),
    ] = None,
    fmt: Annotated[
        OutputFormat,
        typer.Option(
            "--format",
            "-f",
            help="Output format: 'spl2' (default) generates .spl2 pipeline files, 'json' generates a JSON representation of the parsed template data.",
        ),
    ] = OutputFormat.spl2,
    no_annotation: Annotated[
        bool,
        typer.Option("--no-annotation", help="Disable @template annotation generation in SPL2 output."),
    ] = False,
    verbose: Annotated[bool, typer.Option("-v", "--verbose", help="Enable verbose/debug output")] = False,
):
    """Generate SPL2 templates from TA configuration.

    Reads the TA .conf files and generates SPL2 pipeline templates.
    When --config is provided, only the listed sourcetypes are processed.
    Without --config, all sourcetypes found in props.conf are processed.

    Examples:

        conf-spl2-converter generate /path/to/ta

        conf-spl2-converter generate /path/to/ta -c config.json -o ./out -f spl2

        conf-spl2-converter generate /path/to/ta --no-annotation
    """
    _configure_logging(verbose)

    output_dir = str(output) if output else None

    try:
        create_spl2_templates(
            ta_path=str(ta_path),
            config_file=str(config) if config else None,
            output_dir=output_dir,
            output_format=fmt.value,
            enable_annotation=not no_annotation,
        )
        typer.secho("SPL2 templates generated successfully.", fg=typer.colors.GREEN)
    except FileNotFoundError as e:
        typer.secho(f"Error: {e}", fg=typer.colors.RED, err=True)
        raise typer.Exit(1) from e
    except Exception as e:
        logger.exception("Template generation failed")
        typer.secho(f"Error: {e}", fg=typer.colors.RED, err=True)
        raise typer.Exit(1) from e


@app.command("generate-expected")
def generate_expected(
    ta_path: Annotated[
        Path,
        typer.Argument(
            exists=True,
            file_okay=False,
            dir_okay=True,
            readable=True,
            help="Path to the TA directory (repo root or package directory).",
        ),
    ],
    config: Annotated[
        Optional[Path],
        typer.Option(
            "--config",
            "-c",
            exists=True,
            file_okay=True,
            dir_okay=False,
            readable=True,
            help="Path to field_extraction_config.json. When omitted, looks for it in the TA directory; falls back to auto-discovery from props.conf.",
        ),
    ] = None,
    output: Annotated[
        Optional[Path],
        typer.Option(
            "--output",
            "-o",
            file_okay=False,
            dir_okay=True,
            help="Output directory for generated files. Defaults to <ta_path>/default/data/spl2/.",
        ),
    ] = None,
    skip_docker: Annotated[
        bool,
        typer.Option("--skip-docker", help="Skip Docker container management; assume Splunk is already running."),
    ] = False,
    keep_running: Annotated[
        bool,
        typer.Option("--keep-running", help="Leave the Splunk container running after completion."),
    ] = False,
    verbose: Annotated[bool, typer.Option("-v", "--verbose", help="Enable verbose/debug output")] = False,
):
    """Generate expected test outputs by running samples through Splunk.

    Full pipeline in a single command:
      1. Start Splunk Docker container with the TA installed.
      2. Collect test samples from the TA's tests/knowledge/samples/ directory.
      3. Send each sample event to Splunk via HEC.
      4. Retrieve Splunk's extracted fields via the SDK.
      5. Generate module.test.json files with expected outputs.
      6. Stop the Splunk container.

    Requires Docker and the 'testing' extra: pip install conf-spl2-converter[testing]

    Examples:

        conf-spl2-converter generate-expected /path/to/ta

        conf-spl2-converter generate-expected /path/to/ta -c config.json -o ./out

        conf-spl2-converter generate-expected /path/to/ta --skip-docker --keep-running
    """
    _configure_logging(verbose)

    try:
        from conf_spl2_converter.testing.pipeline import run_test_pipeline
    except ImportError as e:
        typer.secho(
            f"Missing testing dependencies: {e}\nInstall with: pip install conf-spl2-converter[testing]",
            fg=typer.colors.RED,
            err=True,
        )
        raise typer.Exit(1) from e

    output_dir = str(output) if output else None

    try:
        run_test_pipeline(
            ta_path=str(ta_path),
            config_file=str(config) if config else None,
            output_dir=output_dir,
            skip_docker=skip_docker,
            keep_running=keep_running,
        )
        typer.secho("Expected test outputs generated successfully.", fg=typer.colors.GREEN)
    except TimeoutError as e:
        typer.secho(f"Timeout: {e}", fg=typer.colors.RED, err=True)
        raise typer.Exit(1) from e
    except FileNotFoundError as e:
        typer.secho(f"Error: {e}", fg=typer.colors.RED, err=True)
        raise typer.Exit(1) from e
    except Exception as e:
        logger.exception("Test pipeline failed")
        typer.secho(f"Error: {e}", fg=typer.colors.RED, err=True)
        raise typer.Exit(1) from e


@app.command("generate-expected-all")
def generate_expected_all(
    ta_path: Annotated[
        Path,
        typer.Argument(
            exists=True,
            file_okay=False,
            dir_okay=True,
            readable=True,
            help="Path to the TA directory (repo root or package directory).",
        ),
    ],
    config: Annotated[
        Optional[Path],
        typer.Option(
            "--config",
            "-c",
            exists=True,
            file_okay=True,
            dir_okay=False,
            readable=True,
            help="Path to field_extraction_config.json. When omitted, looks for it in the TA directory; falls back to auto-discovery from props.conf.",
        ),
    ] = None,
    output: Annotated[
        Optional[Path],
        typer.Option(
            "--output",
            "-o",
            file_okay=False,
            dir_okay=True,
            help="Output directory for generated files. Defaults to <ta_path>/default/data/spl2/.",
        ),
    ] = None,
    skip_docker: Annotated[
        bool,
        typer.Option("--skip-docker", help="Skip Docker container management; assume Splunk is already running."),
    ] = False,
    keep_running: Annotated[
        bool,
        typer.Option("--keep-running", help="Leave the Splunk container running after completion."),
    ] = False,
    verbose: Annotated[bool, typer.Option("-v", "--verbose", help="Enable verbose/debug output")] = False,
):
    """Generate expected test outputs from Splunk AND CIM fields in a single run.

    Combines both pipelines:
      1. Run `generate-expected` (Splunk-based) to populate expected_destination_result.
      2. Run `generate-expected-cim` to add expected_cim_fields from XML annotations.

    The result is a module.test.json with both full Splunk extraction results
    and CIM field expectations side by side.

    Requires Docker and the 'testing' extra: pip install conf-spl2-converter[testing]

    Examples:

        conf-spl2-converter generate-expected-all /path/to/ta

        conf-spl2-converter generate-expected-all /path/to/ta --skip-docker -v
    """
    _configure_logging(verbose)

    try:
        from conf_spl2_converter.testing.cim_generator import run_cim_pipeline
        from conf_spl2_converter.testing.pipeline import run_test_pipeline
    except ImportError as e:
        typer.secho(
            f"Missing testing dependencies: {e}\nInstall with: pip install conf-spl2-converter[testing]",
            fg=typer.colors.RED,
            err=True,
        )
        raise typer.Exit(1) from e

    output_dir = str(output) if output else None
    config_str = str(config) if config else None

    try:
        typer.secho("Step 1/2: Running Splunk-based pipeline...", fg=typer.colors.CYAN)
        run_test_pipeline(
            ta_path=str(ta_path),
            config_file=config_str,
            output_dir=output_dir,
            skip_docker=skip_docker,
            keep_running=keep_running,
        )
        typer.secho("Step 1/2 complete: Splunk extraction done.", fg=typer.colors.GREEN)

        typer.secho("Step 2/2: Adding CIM fields from XML annotations...", fg=typer.colors.CYAN)
        run_cim_pipeline(
            ta_path=str(ta_path),
            config_file=config_str,
            output_dir=output_dir,
        )
        typer.secho("Step 2/2 complete: CIM fields added.", fg=typer.colors.GREEN)

        typer.secho("All expected test outputs generated successfully.", fg=typer.colors.GREEN)
    except TimeoutError as e:
        typer.secho(f"Timeout: {e}", fg=typer.colors.RED, err=True)
        raise typer.Exit(1) from e
    except FileNotFoundError as e:
        typer.secho(f"Error: {e}", fg=typer.colors.RED, err=True)
        raise typer.Exit(1) from e
    except Exception as e:
        logger.exception("Combined pipeline failed")
        typer.secho(f"Error: {e}", fg=typer.colors.RED, err=True)
        raise typer.Exit(1) from e


@app.command("generate-expected-cim")
def generate_expected_cim(
    ta_path: Annotated[
        Path,
        typer.Argument(
            exists=True,
            file_okay=False,
            dir_okay=True,
            readable=True,
            help="Path to the TA directory (repo root or package directory).",
        ),
    ],
    config: Annotated[
        Optional[Path],
        typer.Option(
            "--config",
            "-c",
            exists=True,
            file_okay=True,
            dir_okay=False,
            readable=True,
            help="Path to field_extraction_config.json. When omitted, looks for it in the TA directory; falls back to auto-discovery from props.conf.",
        ),
    ] = None,
    output: Annotated[
        Optional[Path],
        typer.Option(
            "--output",
            "-o",
            file_okay=False,
            dir_okay=True,
            help="Output directory for generated files. Defaults to <ta_path>/default/data/spl2/.",
        ),
    ] = None,
    verbose: Annotated[bool, typer.Option("-v", "--verbose", help="Enable verbose/debug output")] = False,
):
    """Generate expected test outputs from CIM fields in XML samples (no Splunk/Docker needed).

    Offline alternative to `generate-expected`. Instead of running events through
    a Splunk instance, this command reads CIM field annotations already present
    in the TA's XML sample files and uses them as expected values.

    Pipeline:
      1. Collect test samples from the TA's tests/knowledge/samples/ directory.
      2. Parse CIM models, fields, and missing recommended fields from the XML.
      3. Generate module.test.json files with CIM fields as expected outputs.

    Examples:

        conf-spl2-converter generate-expected-cim /path/to/ta

        conf-spl2-converter generate-expected-cim /path/to/ta -c config.json -o ./out
    """
    _configure_logging(verbose)

    try:
        from conf_spl2_converter.testing.cim_generator import run_cim_pipeline
    except ImportError as e:
        typer.secho(
            f"Missing testing dependencies: {e}\nInstall with: pip install conf-spl2-converter[testing]",
            fg=typer.colors.RED,
            err=True,
        )
        raise typer.Exit(1) from e

    output_dir = str(output) if output else None

    try:
        run_cim_pipeline(
            ta_path=str(ta_path),
            config_file=str(config) if config else None,
            output_dir=output_dir,
        )
        typer.secho("CIM-based expected test outputs generated successfully.", fg=typer.colors.GREEN)
    except FileNotFoundError as e:
        typer.secho(f"Error: {e}", fg=typer.colors.RED, err=True)
        raise typer.Exit(1) from e
    except Exception as e:
        logger.exception("CIM test pipeline failed")
        typer.secho(f"Error: {e}", fg=typer.colors.RED, err=True)
        raise typer.Exit(1) from e


@app.command()
def knowledge_build(
    ta_path: Annotated[
        Path,
        typer.Argument(
            exists=True,
            file_okay=False,
            dir_okay=True,
            readable=True,
            help="Path to the TA package directory (contains default/props.conf).",
        ),
    ],
    config: Annotated[
        Optional[Path],
        typer.Option(
            "--config",
            "-c",
            exists=True,
            file_okay=True,
            dir_okay=False,
            readable=True,
            help="Path to field_extraction_config.json. When omitted, looks for it in the TA directory; falls back to auto-discovery from props.conf.",
        ),
    ] = None,
    output: Annotated[
        Optional[Path],
        typer.Option(
            "--output",
            "-o",
            file_okay=False,
            dir_okay=True,
            help="Output directory for SPL2 and knowledge base files. Defaults to paths from knowledge_builder input/config.json.",
        ),
    ] = None,
    knowledge_source: Annotated[
        Optional[str],
        typer.Option(
            "--knowledge-source",
            "-k",
            help="Knowledge source: 'ta' (TA only) or 'security_content'. Use 'ta' when security_content is not available.",
        ),
    ] = None,
    verbose: Annotated[bool, typer.Option("-v", "--verbose", help="Enable verbose/debug output")] = False,
):
    """Run Knowledge Builder: create knowledge bases and SPL2 content.

    Uses the same input config behaviour as generate: TA path plus optional config file.
    When --config is omitted, looks for field_extraction_config.json in the TA directory,
    then falls back to auto-discovering sourcetypes from props.conf.

    Examples:

        conf-spl2-converter knowledge-build /path/to/ta

        conf-spl2-converter knowledge-build /path/to/ta -c config.json -o ./out
    """
    _configure_logging(verbose)
    from conf_spl2_converter.knowledge_builder.create_content import create_content

    try:
        create_content(
            ta_path=str(ta_path),
            config_file=str(config) if config else None,
            output_dir=str(output) if output else None,
            knowledge_source=knowledge_source,
        )
        typer.secho("Knowledge Builder finished successfully.", fg=typer.colors.GREEN)
    except FileNotFoundError as e:
        typer.secho(f"Error: {e}", fg=typer.colors.RED, err=True)
        raise typer.Exit(1) from e
    except Exception as e:
        logger.exception("Knowledge Build failed")
        typer.secho(f"Error: {e}", fg=typer.colors.RED, err=True)
        raise typer.Exit(1) from e


if __name__ == "__main__":
    app()
