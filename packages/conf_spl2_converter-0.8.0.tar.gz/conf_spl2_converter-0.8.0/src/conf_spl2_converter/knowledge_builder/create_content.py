from __future__ import annotations

import os

from conf_spl2_converter.converter.input_config import InputConfig
from conf_spl2_converter.knowledge_builder.knowledge_base.nr_knowledge_base_creator import create_knowledge_base
from conf_spl2_converter.knowledge_builder.spl2_content_creator.spl2_content_creator import create_spl2_content


def create_content(
    ta_path: str,
    config_file: str | None = None,
    output_dir: str | None = None,
    knowledge_source: str | None = None,
):
    """Run Knowledge Builder with the same input config behaviour as the converter.

    Resolution order when config_file is not provided:
      1. Look for field_extraction_config.json in the TA directory.
      2. Else auto-discover sourcetypes from props.conf.

    When output_dir is provided, SPL2 and knowledge base output are written there
    (and under output_dir/knowledge_bases for KB JSON).

    knowledge_source: optional override for KNOWLEDGE_SOURCE ('ta' or 'security_content').
      Use 'ta' to build only from the TA (no security_content/detections). Default from config.
    """
    input_config = InputConfig(ta_path, config_file)

    if knowledge_source is not None:
        from conf_spl2_converter.knowledge_builder.input import configuration_constants as kb_constants
        from conf_spl2_converter.knowledge_builder.knowledge_base import nr_knowledge_base_creator

        attr = "KNOWLEDGE_SOURCE"
        for mod in (kb_constants, nr_knowledge_base_creator):
            setattr(mod, attr, knowledge_source)

    if output_dir:
        os.makedirs(output_dir, exist_ok=True)
        out_kb = os.path.join(output_dir, "knowledge_bases")
        os.makedirs(out_kb, exist_ok=True)
        out_combined = os.path.join(output_dir, "props_transforms.conf")

        from conf_spl2_converter.knowledge_builder import spl2_content_creator
        from conf_spl2_converter.knowledge_builder.common_utils import spl2_utils
        from conf_spl2_converter.knowledge_builder.common_utils import utils as kb_utils
        from conf_spl2_converter.knowledge_builder.input import configuration_constants as kb_constants
        from conf_spl2_converter.knowledge_builder.knowledge_base import cim_integration, nr_knowledge_base_creator

        modules_for_paths = (kb_constants, nr_knowledge_base_creator, cim_integration, kb_utils)
        path_attrs = ("SPL2_CONTENT_FOLDER", "TA_KNOWLEDGE_BASE_FOLDER", "SPLUNK_CONF_FILE_COMBINED")
        path_vals = (output_dir, out_kb, out_combined)
        for mod in modules_for_paths:
            for attr_name, attr_val in zip(path_attrs, path_vals):
                setattr(mod, attr_name, attr_val)

        modules_for_spl2_folder = (spl2_utils, spl2_content_creator.spl2_content_creator)
        spl2_attr = "SPL2_CONTENT_FOLDER"
        for mod in modules_for_spl2_folder:
            setattr(mod, spl2_attr, output_dir)

    _kb, kb_pairs = create_knowledge_base(input_config)
    create_spl2_content(input_config, kb_pairs)


if __name__ == "__main__":
    import sys

    if len(sys.argv) < 2:
        print("Usage: python -m ... <ta_path> [config_file] [output_dir]", file=sys.stderr)
        sys.exit(1)
    create_content(
        ta_path=sys.argv[1],
        config_file=sys.argv[2] if len(sys.argv) > 2 else None,
        output_dir=sys.argv[3] if len(sys.argv) > 3 else None,
    )
