from __future__ import annotations

import json
import os
from collections import defaultdict
from itertools import product

from conf_spl2_converter.converter.input_config import InputConfig
from conf_spl2_converter.knowledge_builder.common_utils.log_utils import MAIN_STAGE_FORMAT, logger
from conf_spl2_converter.knowledge_builder.common_utils.security_content_parser import SecurityContent
from conf_spl2_converter.knowledge_builder.common_utils.spl2_utils import get_spl2_safe_sourcetype_name
from conf_spl2_converter.knowledge_builder.common_utils.splunk_utils import timestamping
from conf_spl2_converter.knowledge_builder.common_utils.splunk_utils.spl_utils.spl_utils import (
    find_dependent_fields_from_spl_code_using_static_analysis,
)
from conf_spl2_converter.knowledge_builder.common_utils.splunk_utils.ta_utils.splunk_pt_constructs import KV_MODES
from conf_spl2_converter.knowledge_builder.common_utils.splunk_utils.ta_utils.ta_config_obj_utils import (
    get_ta_config_object,
    load_conf_files,
    write_object_to_file,
)
from conf_spl2_converter.knowledge_builder.common_utils.splunk_utils.ta_utils.ta_pt_conf_utils import (
    cleanup_regex,
    extract_field_regex_mapping,
    find_dependent_fields_from_eval_code_using_static_analysis,
    get_autokvjson_for_stanza,
    get_field_from_extract_clause,
    get_field_from_report_stanza,
    get_field_names,
    get_input_fields_from_lookup_clause,
    get_kv_pairs_for_stanza,
    get_kvmode_for_stanza,
    get_regex_from_extract_clause,
    get_regex_on_raw_for_stanza,
    get_report_stanza_names,
    get_stanza_name_for_source,
    get_transform_stanza_names,
    is_eval_attribute,
    is_extract_attribute,
    is_field_alias_attribute,
    is_kvmode_attribute,
    is_lookup_attribute,
    is_report_attribute,
    is_transforms_attribute,
)
from conf_spl2_converter.knowledge_builder.common_utils.utils import write_stringdata_to_file
from conf_spl2_converter.knowledge_builder.input.configuration_constants import (
    KNOWLEDGE_SOURCE,
    SPLUNK_CONF_FILE_COMBINED,
    TA_KNOWLEDGE_BASE_FOLDER,
)
from conf_spl2_converter.knowledge_builder.knowledge_base.cim_integration import ensure_cim_fields_in_knowledge_base
from conf_spl2_converter.knowledge_builder.knowledge_base.knowledge_base_constructs import KnowledgeBaseAttribute

NO_RESPONSE = "SPNO"


def add_miscellaneous_regexes(sourcetype, knowledge_base):
    regexes = []
    timestamp_regex = timestamping.get_timestamping_regex(sourcetype)
    if timestamp_regex:
        regexes.append(timestamp_regex)

    kv_mode = knowledge_base[sourcetype][KnowledgeBaseAttribute.KV_MODE]
    is_auto_kv = kv_mode.lower() == KV_MODES.AUTO.lower()
    if is_auto_kv:
        is_win_event_log = sourcetype == "WinEventLog"
        if is_win_event_log:
            # This regex is used to extract key-value pairs in the format 'key=value' e.g. 'LogName=Security dddd	a'
            pattern = r"([^\n]+?)(:\s.?)?(\w+)\s?=\s?([^\n]+?)(?:$|\n)"
            regexes.append(pattern)
            # This regex is used to extract key-value pairs in the format 'key:value' e.g. 'Account Name: IP-0AC000F2'
            pattern = r"\w([-\w\s]+)\s*:\s*([-\w\d\s.\\]+)"
            regexes.append(pattern)

            pattern = r"(?sm)^(?<_pre_msg>.+)\nMessage=(?<Message>.+)$"
            regexes.append(pattern)

            pattern = r"\n([^:\n\r]+):[ \t]++([^\n]*)"
            regexes.append(pattern)
        else:
            # This regex is used to extract key-value pairs in the format key="value" , key='value' , key1=value1 key2="value2" key3='value3' , key=value with spaces
            pattern = r"([^=\s]+)=(['\"]?([^'\"\s]+)['\"]?)"
            regexes.append(pattern)

    for regex in regexes:
        add_to_knowledge_base(
            sourcetype=sourcetype,
            attribute_type=KnowledgeBaseAttribute.REGEXES,
            value=regex,
            knowledge_base=knowledge_base,
        )


def add_to_knowledge_base(sourcetype, attribute_type, value, knowledge_base):
    if attribute_type == KnowledgeBaseAttribute.REGEXES:
        if sourcetype in knowledge_base:
            if KnowledgeBaseAttribute.REGEXES in knowledge_base[sourcetype]:
                knowledge_base[sourcetype][KnowledgeBaseAttribute.REGEXES].append(value)
            else:
                knowledge_base[sourcetype][KnowledgeBaseAttribute.REGEXES] = []
                knowledge_base[sourcetype][KnowledgeBaseAttribute.REGEXES].append(value)
        else:
            knowledge_base[sourcetype] = {}
            knowledge_base[sourcetype][KnowledgeBaseAttribute.REGEXES] = []
            knowledge_base[sourcetype][KnowledgeBaseAttribute.REGEXES].append(value)
    elif attribute_type == KnowledgeBaseAttribute.DEPENDENT_FIELDS:
        if not value or (isinstance(value, str) and not value.strip()):
            return
        if sourcetype in knowledge_base:
            if KnowledgeBaseAttribute.DEPENDENT_FIELDS in knowledge_base[sourcetype]:
                knowledge_base[sourcetype][KnowledgeBaseAttribute.DEPENDENT_FIELDS].append(value)
            else:
                knowledge_base[sourcetype][KnowledgeBaseAttribute.DEPENDENT_FIELDS] = []
                knowledge_base[sourcetype][KnowledgeBaseAttribute.DEPENDENT_FIELDS].append(value)
        else:
            knowledge_base[sourcetype] = {}
            knowledge_base[sourcetype][KnowledgeBaseAttribute.DEPENDENT_FIELDS] = []
            knowledge_base[sourcetype][KnowledgeBaseAttribute.DEPENDENT_FIELDS].append(value)
    elif attribute_type == KnowledgeBaseAttribute.KV_MODE:
        if sourcetype in knowledge_base:
            if KnowledgeBaseAttribute.KV_MODE in knowledge_base[sourcetype]:
                knowledge_base[sourcetype][KnowledgeBaseAttribute.KV_MODE] = value
            else:
                knowledge_base[sourcetype][KnowledgeBaseAttribute.KV_MODE] = value
        else:
            knowledge_base[sourcetype] = {}
            knowledge_base[sourcetype][KnowledgeBaseAttribute.KV_MODE] = value
    elif attribute_type == KnowledgeBaseAttribute.AUTO_KV_JSON:
        if sourcetype in knowledge_base:
            if KnowledgeBaseAttribute.AUTO_KV_JSON in knowledge_base[sourcetype]:
                knowledge_base[sourcetype][KnowledgeBaseAttribute.AUTO_KV_JSON] = value
            else:
                knowledge_base[sourcetype][KnowledgeBaseAttribute.AUTO_KV_JSON] = value
        else:
            knowledge_base[sourcetype] = {}
            knowledge_base[sourcetype][KnowledgeBaseAttribute.AUTO_KV_JSON] = value


def dedeuplicate_knowledge_base(sourcetype, knowledge_base):
    fields = knowledge_base[sourcetype][KnowledgeBaseAttribute.DEPENDENT_FIELDS]
    knowledge_base[sourcetype][KnowledgeBaseAttribute.DEPENDENT_FIELDS] = list(set(fields))


def _process_attributes_into_kb(attributes, target_key, ta_config_object, knowledge_base, detailed_mapping=None):
    """Process stanza (key, value) attributes into knowledge_base[target_key]. Optionally update detailed_mapping."""
    for props_attr_key, props_attr_value in attributes:
        if is_report_attribute(props_attr_key):
            transform_stanza_names = get_report_stanza_names(props_attr_value)
            for transform_stanza_name in transform_stanza_names:
                regex = get_regex_on_raw_for_stanza(ta_config_object, transform_stanza_name)
                if regex:
                    # TODO: Get fields the regex depends on
                    cleaned_up_regex = cleanup_regex(regex)
                    add_to_knowledge_base(
                        sourcetype=target_key,
                        attribute_type=KnowledgeBaseAttribute.REGEXES,
                        value=cleaned_up_regex,
                        knowledge_base=knowledge_base,
                    )

                field_name = get_field_from_report_stanza(ta_config_object, transform_stanza_name)
                add_to_knowledge_base(
                    sourcetype=target_key,
                    attribute_type=KnowledgeBaseAttribute.DEPENDENT_FIELDS,
                    value=field_name,
                    knowledge_base=knowledge_base,
                )

                # Add field-regex mapping in dependency chain logic
                if detailed_mapping is not None:
                    returned_mapping = extract_field_regex_mapping(ta_config_object, transform_stanza_name)
                    for key, value in returned_mapping.items():
                        for entry in value:
                            if entry not in detailed_mapping[key]:
                                detailed_mapping[key].append(entry)

        elif is_transforms_attribute(props_attr_key):
            transform_stanza_names = get_transform_stanza_names(props_attr_value)
            for transform_stanza_name in transform_stanza_names:
                regex = get_regex_on_raw_for_stanza(ta_config_object, transform_stanza_name)
                if regex:
                    # TODO: Get fields the regex depends on
                    cleaned_up_regex = cleanup_regex(regex)
                    add_to_knowledge_base(
                        sourcetype=target_key,
                        attribute_type=KnowledgeBaseAttribute.REGEXES,
                        value=cleaned_up_regex,
                        knowledge_base=knowledge_base,
                    )

                field_name = get_field_from_report_stanza(ta_config_object, transform_stanza_name)
                add_to_knowledge_base(
                    sourcetype=target_key,
                    attribute_type=KnowledgeBaseAttribute.DEPENDENT_FIELDS,
                    value=field_name,
                    knowledge_base=knowledge_base,
                )
        elif is_extract_attribute(props_attr_key):
            value = props_attr_value
            regexes = get_regex_from_extract_clause(value)
            for regex in regexes:
                cleaned_up_regex = cleanup_regex(regex)
                add_to_knowledge_base(
                    sourcetype=target_key,
                    attribute_type=KnowledgeBaseAttribute.REGEXES,
                    value=cleaned_up_regex,
                    knowledge_base=knowledge_base,
                )

            fields = get_field_from_extract_clause(value)
            for field_value in fields:
                add_to_knowledge_base(
                    sourcetype=target_key,
                    attribute_type=KnowledgeBaseAttribute.DEPENDENT_FIELDS,
                    value=field_value,
                    knowledge_base=knowledge_base,
                )
        elif is_kvmode_attribute(props_attr_key):
            value = props_attr_value
            add_to_knowledge_base(
                sourcetype=target_key,
                attribute_type=KnowledgeBaseAttribute.KV_MODE,
                value=value,
                knowledge_base=knowledge_base,
            )
        elif is_field_alias_attribute(props_attr_key):
            field_names = get_field_names(props_attr_value)
            for field_name in field_names:
                add_to_knowledge_base(
                    sourcetype=target_key,
                    attribute_type=KnowledgeBaseAttribute.DEPENDENT_FIELDS,
                    value=field_name,
                    knowledge_base=knowledge_base,
                )
        elif is_eval_attribute(props_attr_key):
            code = props_attr_value.strip()
            fields = find_dependent_fields_from_eval_code_using_static_analysis(code)
            if fields != NO_RESPONSE:
                fields = fields.strip().split(",")
                fields = [field.strip() for field in fields]
                for field in fields:
                    add_to_knowledge_base(
                        sourcetype=target_key,
                        attribute_type=KnowledgeBaseAttribute.DEPENDENT_FIELDS,
                        value=field,
                        knowledge_base=knowledge_base,
                    )
        elif is_lookup_attribute(props_attr_key):
            fields = get_input_fields_from_lookup_clause(props_attr_value)
            for field_value in fields:
                add_to_knowledge_base(
                    sourcetype=target_key,
                    attribute_type=KnowledgeBaseAttribute.DEPENDENT_FIELDS,
                    value=field_value,
                    knowledge_base=knowledge_base,
                )


def get_knowledge_from_tas(input_config, knowledge_base):
    logger.info("Extracting Knowledge from TA")

    ta_config_object = get_ta_config_object()
    conf_files = input_config.get_pt_conf_files()
    input_sourcetypes = input_config.get_input_sourcetypes()
    detailed_mapping = defaultdict(list)

    load_conf_files(ta_config_object, conf_files)
    parent_dir = os.path.dirname(SPLUNK_CONF_FILE_COMBINED)
    if parent_dir:
        os.makedirs(parent_dir, exist_ok=True)
    write_object_to_file(config=ta_config_object, file_location=SPLUNK_CONF_FILE_COMBINED)

    for input_sourcetype in input_sourcetypes:
        input_source = input_config.get_source(input_sourcetype)
        sub_sourcetypes = input_config.get_sub_sourcetypes(input_sourcetype)
        sourcetype_attributes = get_kv_pairs_for_stanza(ta_config_object, input_sourcetype)

        if input_source:
            # Build sourcetype-only KB (base for merge) and per-source KBs so each (sourcetype, source) pair gets a distinct merged KB.
            sources = input_source if isinstance(input_source, list) else [input_source]
            _process_attributes_into_kb(
                sourcetype_attributes, input_sourcetype, ta_config_object, knowledge_base, detailed_mapping
            )
            for src in sources:
                stanza_name = get_stanza_name_for_source(source_value=src)
                source_attributes = get_kv_pairs_for_stanza(ta_config_object, stanza_name)
                source_key = f"source::{src}"
                # Ensure per-source KB has full structure so dedeuplicate_knowledge_base and merge_kbs work
                knowledge_base[source_key] = {
                    KnowledgeBaseAttribute.REGEXES: [],
                    KnowledgeBaseAttribute.DEPENDENT_FIELDS: [],
                    KnowledgeBaseAttribute.KV_MODE: "",
                    KnowledgeBaseAttribute.AUTO_KV_JSON: "",
                }
                _process_attributes_into_kb(source_attributes, source_key, ta_config_object, knowledge_base, None)
                add_to_knowledge_base(
                    sourcetype=source_key,
                    attribute_type=KnowledgeBaseAttribute.KV_MODE,
                    value=get_kvmode_for_stanza(ta_config_object, stanza_name),
                    knowledge_base=knowledge_base,
                )
                add_to_knowledge_base(
                    sourcetype=source_key,
                    attribute_type=KnowledgeBaseAttribute.AUTO_KV_JSON,
                    value=get_autokvjson_for_stanza(ta_config_object, stanza_name),
                    knowledge_base=knowledge_base,
                )
                # Per-stanza misc regexes (same as pre-integration: source keys use else-branch, e.g. key=value with quotes)
                add_miscellaneous_regexes(sourcetype=source_key, knowledge_base=knowledge_base)
        else:
            _process_attributes_into_kb(
                sourcetype_attributes, input_sourcetype, ta_config_object, knowledge_base, detailed_mapping
            )

        # Sourcetype KB: set kv_mode / auto_kv_json if not set by stanza, add misc regexes, dedupe
        add_to_knowledge_base(
            sourcetype=input_sourcetype,
            attribute_type=KnowledgeBaseAttribute.KV_MODE,
            value=get_kvmode_for_stanza(ta_config_object, input_sourcetype),
            knowledge_base=knowledge_base,
        )
        add_to_knowledge_base(
            sourcetype=input_sourcetype,
            attribute_type=KnowledgeBaseAttribute.AUTO_KV_JSON,
            value=get_autokvjson_for_stanza(ta_config_object, input_sourcetype),
            knowledge_base=knowledge_base,
        )
        add_miscellaneous_regexes(sourcetype=input_sourcetype, knowledge_base=knowledge_base)
        dedeuplicate_knowledge_base(sourcetype=input_sourcetype, knowledge_base=knowledge_base)
        if input_source:
            sources = input_source if isinstance(input_source, list) else [input_source]
            for src in sources:
                dedeuplicate_knowledge_base(f"source::{src}", knowledge_base)

        if sub_sourcetypes:
            for sub_st in sub_sourcetypes:
                knowledge_base[sub_st] = {
                    KnowledgeBaseAttribute.REGEXES: [],
                    KnowledgeBaseAttribute.DEPENDENT_FIELDS: [],
                    KnowledgeBaseAttribute.KV_MODE: "",
                    KnowledgeBaseAttribute.AUTO_KV_JSON: "",
                }
                sub_attributes = get_kv_pairs_for_stanza(ta_config_object, sub_st)
                _process_attributes_into_kb(sub_attributes, sub_st, ta_config_object, knowledge_base, None)
                add_to_knowledge_base(
                    sourcetype=sub_st,
                    attribute_type=KnowledgeBaseAttribute.KV_MODE,
                    value=get_kvmode_for_stanza(ta_config_object, sub_st),
                    knowledge_base=knowledge_base,
                )
                add_to_knowledge_base(
                    sourcetype=sub_st,
                    attribute_type=KnowledgeBaseAttribute.AUTO_KV_JSON,
                    value=get_autokvjson_for_stanza(ta_config_object, sub_st),
                    knowledge_base=knowledge_base,
                )
                add_miscellaneous_regexes(sourcetype=sub_st, knowledge_base=knowledge_base)
                dedeuplicate_knowledge_base(sourcetype=sub_st, knowledge_base=knowledge_base)
                # Merge parent KB into sub so sub has parent's regexes (e.g. from TRANSFORMS) and dependent_fields
                knowledge_base[sub_st] = merge_parent_kb_into_sub(
                    knowledge_base[input_sourcetype], knowledge_base[sub_st]
                )

        output_data = {
            "detailed_mapping": detailed_mapping,
            "metadata": {
                "total_fields": len(detailed_mapping),
                # 'total_patterns': sum(len(patterns) for patterns in simple_mapping.values()),
                "source_file": conf_files,
            },
        }
        os.makedirs(TA_KNOWLEDGE_BASE_FOLDER, exist_ok=True)
        output_file_location = os.path.join(
            TA_KNOWLEDGE_BASE_FOLDER, get_spl2_safe_sourcetype_name(input_sourcetype) + "_field_regex_mapping" + ".json"
        )
        with open(output_file_location, "w", encoding="utf-8") as f:
            json.dump(output_data, f, indent=2, ensure_ascii=False)

        logger.info(f"Detailed field-regex mapping saved to: {output_file_location}")
        # Reset detailed_mapping for next sourcetype
        detailed_mapping = defaultdict(list)

    return knowledge_base


def get_knowledge_from_security_content(input_config, knowledge_base):
    logger.info("Extracting Knowledge from security content")
    input_sourcetypes = input_config.get_input_sourcetypes()
    security_content = SecurityContent()
    sec_fields = []
    for input_sourcetype in input_sourcetypes:
        detection_searches = security_content.get_detection_searches_for_sourcetype(input_sourcetype)
        for detection_search in detection_searches:
            logger.info("detection found ")

            # TODO: field names should be separated from the datamodel name
            fields = find_dependent_fields_from_spl_code_using_static_analysis(spl_code=detection_search)
            # logger.info(fields)
            if fields != NO_RESPONSE:
                fields = fields.strip().split(",")
                fields = [field.strip() for field in fields]
                sec_fields.extend(fields)
                for field in fields:  # TODO: make it easy using list extend instead of for loop
                    add_to_knowledge_base(
                        sourcetype=input_sourcetype,
                        attribute_type=KnowledgeBaseAttribute.DEPENDENT_FIELDS,
                        value=field,
                        knowledge_base=knowledge_base,
                    )

    logger.info(f"sec_fields: {sec_fields}")
    return knowledge_base


def store_knowledge_base(knowledge_base):
    for sourcetype, knowledge_base_for_sourcetype in knowledge_base.items():
        safe_name = get_spl2_safe_sourcetype_name(str(sourcetype))
        os.makedirs(TA_KNOWLEDGE_BASE_FOLDER, exist_ok=True)
        sourcetype_kb_file_location = os.path.join(TA_KNOWLEDGE_BASE_FOLDER, safe_name + ".json")
        write_stringdata_to_file(json.dumps(knowledge_base_for_sourcetype, indent=2), sourcetype_kb_file_location)
        logger.info("FILEINFO: Knowledge Base Stored at %s", sourcetype_kb_file_location)


def get_base_knowledge_base_structure(input_config: InputConfig):
    knowledge_base = {}
    input_sourcetypes = input_config.get_input_sourcetypes()
    for input_sourcetype in input_sourcetypes:
        knowledge_base[input_sourcetype] = {
            KnowledgeBaseAttribute.REGEXES: [],
            KnowledgeBaseAttribute.KV_MODE: "",
            KnowledgeBaseAttribute.AUTO_KV_JSON: "",
            KnowledgeBaseAttribute.DEPENDENT_FIELDS: [],
        }
    return knowledge_base


def create_knowledge_base(input_config: InputConfig):
    logger.info(MAIN_STAGE_FORMAT.format(msg="CREATING KNOWLEDGEBASE"))
    knowledge_base = get_base_knowledge_base_structure(input_config)

    # Determine which knowledge source to use
    knowledge_source = KNOWLEDGE_SOURCE.lower()

    # Validate knowledge source
    if knowledge_source not in ("ta", "security_content"):
        logger.warning(
            f"Invalid KNOWLEDGE_SOURCE value: '{knowledge_source}'. Valid options are 'ta' or 'security_content'. Using 'ta' as default."
        )
        knowledge_source = "ta"

    logger.info(f"Knowledge source: {knowledge_source.upper()}")

    knowledge_base = get_knowledge_from_tas(input_config=input_config, knowledge_base=knowledge_base)

    if knowledge_source == "security_content":
        # reinitialise 'knowledge_base'
        knowledge_base = get_base_knowledge_base_structure(input_config)
        knowledge_base = get_knowledge_from_security_content(input_config=input_config, knowledge_base=knowledge_base)

        knowledge_base = ensure_cim_fields_in_knowledge_base(
            input_config=input_config, knowledge_base=knowledge_base, field_regex_mappings=None
        )

        for st in knowledge_base:
            dedeuplicate_knowledge_base(sourcetype=st, knowledge_base=knowledge_base)

    kb_pairs = _build_kb_source_sourcetype_pairs(knowledge_base=knowledge_base, input_config=input_config)
    # TODO -> uncomment if using it in future milestones
    logger.info(MAIN_STAGE_FORMAT.format(msg="STORING KNOWLEDGEBASE"))
    store_knowledge_base(knowledge_base)

    return knowledge_base, kb_pairs


def _build_kb_source_sourcetype_pairs(knowledge_base, input_config: InputConfig | None = None):
    """
    Build pairs of source and sourcetype knowledge bases and merge them.

    This function separates the entries in the knowledge base into sources and sourcetypes,
    creates all possible pairs between them, and merges each pair using the `merge_kbs` function.
    The result is a dictionary mapping each (sourcetype, source) tuple to its merged knowledge base.

    When the config has a source list, get_knowledge_from_tas populates knowledge_base with
    source:: keys (per-source KBs); this function then builds one merged KB per (sourcetype, source) pair.

    Args:
        knowledge_base (dict): Dictionary containing knowledge bases for sources and sourcetypes.
        input_config (InputConfig | None): Unused; kept for API compatibility.

    Returns:
        dict: Dictionary mapping (sourcetype, source) tuples to merged knowledge base dictionaries.
    """
    sources = {}
    sourcetypes = {}
    kb_pairs = {}
    for single_kb in knowledge_base:
        if single_kb.startswith("source::"):
            sources[single_kb] = knowledge_base[single_kb]
        else:
            sourcetypes[single_kb] = knowledge_base[single_kb]
    pairs = list(product(sourcetypes, sources))

    for pair in pairs:
        sourcetype = pair[0]
        source = pair[1]
        merged_kb = merge_kbs(source_kb=sources[source], sourcetype_kb=sourcetypes[sourcetype])
        kb_pairs[pair] = merged_kb

    return kb_pairs


def _non_empty_dependent_fields(fields: list) -> list:
    """Return sorted list of non-empty, stripped field names (strings only)."""
    seen = set()
    for f in fields:
        if isinstance(f, str) and f.strip():
            seen.add(f.strip())
    return sorted(seen)


def merge_parent_kb_into_sub(parent_kb: dict, sub_kb: dict) -> dict:
    """
    Merge parent sourcetype KB into a sub_sourcetype KB so the sub has both parent and
    sub-specific regexes and dependent_fields (e.g. parent's TRANSFORMS regexes and
    miscellaneous regexes plus sub's REPORT/EVAL-derived content).

    Sub's kv_mode and auto_kv_json are kept. Regexes and dependent_fields are combined
    and deduplicated. Empty strings are filtered out from dependent_fields.
    """
    merged = sub_kb.copy()
    merged.setdefault("regexes", [])
    merged.setdefault("dependent_fields", [])
    merged["regexes"] = list(set(list(merged["regexes"]) + list(parent_kb.get("regexes", []))))
    merged["dependent_fields"] = _non_empty_dependent_fields(
        list(merged["dependent_fields"]) + list(parent_kb.get("dependent_fields", []))
    )
    merged["regexes"].sort()
    return merged


def merge_kbs(source_kb, sourcetype_kb):
    """
    Merge two knowledge base dictionaries: one for a source and one for a sourcetype.

    This function combines the REGEXES and DEPENDENDENT_FIELDS lists from both dictionaries,
    deduplicates and sorts them, and ensures KV_MODE and AUTO_KV_JSON are present in the merged result.

    Args:
        source_kb (dict): Knowledge base dictionary for the source.
        sourcetype_kb (dict): Knowledge base dictionary for the sourcetype.

    Returns:
        dict: Merged knowledge base dictionary.
    """
    merged_kb = source_kb.copy()
    merged_kb.setdefault("dependent_fields", [])
    merged_kb["regexes"].extend(sourcetype_kb.get("regexes", []))
    merged_kb["dependent_fields"].extend(sourcetype_kb.get("dependent_fields", []))

    merged_kb["regexes"].sort()
    merged_kb["dependent_fields"].sort()

    merged_kb["regexes"] = list(set(merged_kb["regexes"]))
    merged_kb["dependent_fields"] = list(set(merged_kb["dependent_fields"]))

    if "kv_mode" not in merged_kb:
        merged_kb["kv_mode"] = sourcetype_kb["kv_mode"]

    if "auto_kv_json" not in merged_kb:
        merged_kb["auto_kv_json"] = sourcetype_kb["auto_kv_json"]

    return merged_kb


if __name__ == "__main__":
    import sys

    if len(sys.argv) < 2:
        print("Usage: python -m ... <ta_path> [config_file]", file=sys.stderr)
        sys.exit(1)
    ta_path = sys.argv[1]
    config_file = sys.argv[2] if len(sys.argv) > 2 else None
    input_config = InputConfig(ta_path, config_file)
    create_knowledge_base(input_config)
