import os

from conf_spl2_converter.knowledge_builder.input.configuration_constants import (
    NOISE_REDUCED_SAMPLE_FILE_LOCATION,
    ORIGINAL_SAMPLE_FILE_LOCATION,
)


def get_sample_file_path(sample_file_name):
    return os.path.join(ORIGINAL_SAMPLE_FILE_LOCATION, sample_file_name)


def get_noise_reduced_sample_file_path(sample_file_name):
    return os.path.join(NOISE_REDUCED_SAMPLE_FILE_LOCATION, sample_file_name)
