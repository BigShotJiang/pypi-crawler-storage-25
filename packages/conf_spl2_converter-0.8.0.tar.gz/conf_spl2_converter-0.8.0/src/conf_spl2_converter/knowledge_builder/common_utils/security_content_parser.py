import json
import os.path
import re
from collections import defaultdict

import yaml

from conf_spl2_converter.knowledge_builder.common_utils.log_utils import logger
from conf_spl2_converter.knowledge_builder.input.configuration_constants import (
    CIM_SOURCETYPE_MAPPING_FILE,
    SEARCH_BY_DATAMODEL_IN_ESCU,
    SECURITY_CONTENT_LOCATION,
)

DETECTIONS = "detections"
EXCLUSION_STATUS = {"deprecated", "experimental"}

SEARCHES_ATTRIBUTE = "searches"
DETECTION_FILES_ATTRIBUTE = "detection_files"

_DATAMODEL_PATTERN = re.compile(
    r"(?:from\s+)?datamodel\s*(?:=\s*|\s+)([\w.]+)",
    re.IGNORECASE,
)


def extract_datamodel_names_from_search(search_str: str) -> list[str]:
    """Extract unique datamodel names referenced in a Splunk SPL search string.

    Matches patterns like ``from datamodel Web``, ``datamodel=Network_Traffic``,
    ``from datamodel Risk.All_Risk``.  Returns names in order of first occurrence,
    deduplicated.
    """
    if not search_str or not isinstance(search_str, str):
        return []
    names = _DATAMODEL_PATTERN.findall(search_str)
    return list(dict.fromkeys(names))


def _load_cim_sourcetype_mapping(mapping_file_path: str | None = None) -> dict[str, list[str]]:
    """Load sourcetype -> CIM datamodel names from the configured mapping JSON.

    Values may be a single string or a list of strings; they are normalised to
    ``list[str]`` per sourcetype.  Returns an empty dict on missing/invalid file.
    """
    path = mapping_file_path if mapping_file_path is not None else CIM_SOURCETYPE_MAPPING_FILE
    if not os.path.exists(path):
        return {}
    try:
        with open(path, encoding="utf-8") as f:
            raw = json.load(f)
    except (json.JSONDecodeError, OSError):
        return {}
    result: dict[str, list[str]] = {}
    for sourcetype, value in raw.items():
        if isinstance(value, list):
            result[sourcetype] = list(value)
        elif isinstance(value, str):
            result[sourcetype] = [value]
    return result


class SecurityContent:
    """Loads detection YAMLs from security content and indexes them by sourcetype.

    Also indexes searches by CIM datamodel (from search text) for sourcetype-based
    lookup via CIM mapping (``cim_sourcetype_mapping.json``).
    """

    def __init__(self):
        self.content_summary: dict[str, dict] = {}
        self._sourcetype_to_datamodels: dict[str, list[str]] = _load_cim_sourcetype_mapping()
        self.datamodel_to_searches: dict[str, list[str]] = defaultdict(list)

        valid_detection_count = 0
        for directory in os.listdir(os.path.join(SECURITY_CONTENT_LOCATION, DETECTIONS)):
            for detection_file in os.listdir(os.path.join(SECURITY_CONTENT_LOCATION, DETECTIONS, directory)):
                if detection_file.endswith(".yml"):
                    detection_file_path = os.path.join(SECURITY_CONTENT_LOCATION, DETECTIONS, directory, detection_file)
                    with open(detection_file_path) as detection_file_content:
                        detection_file_content_obj = yaml.safe_load(detection_file_content)
                        if detection_file_content_obj["status"] not in EXCLUSION_STATUS:
                            search = detection_file_content_obj.get("search")
                            if search:
                                for dm in extract_datamodel_names_from_search(search):
                                    self.datamodel_to_searches[dm].append(search)

                            try:
                                sourcetype = detection_file_content_obj["tests"][0]["attack_data"][0]["sourcetype"]
                            except KeyError:
                                continue

                            valid_detection_count = valid_detection_count + 1
                            if sourcetype in self.content_summary:
                                self.content_summary[sourcetype][SEARCHES_ATTRIBUTE].append(search)
                                self.content_summary[sourcetype][DETECTION_FILES_ATTRIBUTE].append(
                                    os.path.join(directory, detection_file)
                                )
                            else:
                                item = {SEARCHES_ATTRIBUTE: [], DETECTION_FILES_ATTRIBUTE: []}
                                self.content_summary[sourcetype] = item
                                self.content_summary[sourcetype][SEARCHES_ATTRIBUTE].append(search)
                                self.content_summary[sourcetype][DETECTION_FILES_ATTRIBUTE].append(
                                    os.path.join(directory, detection_file)
                                )

        logger.info(valid_detection_count)

    def get_detection_searches_for_sourcetype(self, sourcetype: str) -> list[str]:
        """Return detection searches for a sourcetype.

        Merges searches indexed directly by sourcetype with those from any CIM
        datamodels mapped to this sourcetype (when ``SEARCH_BY_DATAMODEL_IN_ESCU``
        is enabled).  Results are deduplicated while preserving order.
        """
        searches: list[str] = []
        if sourcetype in self.content_summary:
            searches = list(self.content_summary[sourcetype][SEARCHES_ATTRIBUTE])

        if SEARCH_BY_DATAMODEL_IN_ESCU:
            for dm in self._sourcetype_to_datamodels.get(sourcetype, []):
                searches.extend(self.datamodel_to_searches.get(dm, []))

        return list(dict.fromkeys(searches))

    def get_detection_files_for_sourcetype(self, sourcetype):
        if sourcetype in self.content_summary:
            return self.content_summary[sourcetype][DETECTION_FILES_ATTRIBUTE]
        else:
            return []
