import os
import re

from conf_spl2_converter.knowledge_builder.common_utils.log_utils import logger
from conf_spl2_converter.knowledge_builder.input.configuration_constants import (
    SPL2_CONTENT_FOLDER,
)


def sanitize_for_spl2_identifier(name: str, max_len: int = 128) -> str:
    """
    Produce an SPL2-safe identifier:
    - replace any char not in [A-Za-z0-9_] with underscore
    - collapse runs of underscores and trim leading/trailing underscores
    - ensure it starts with an ASCII letter (prefix with 'id_' if needed)
    - fallback to 'kb' if empty, and truncate to max_len
    """

    s = (name or "").strip()
    s = re.sub(r"[^A-Za-z0-9_]+", "_", s)
    s = re.sub(r"_+", "_", s)
    s = s.strip("_")
    if not s:
        s = "kb"
    if not re.match(r"^[A-Za-z]", s):
        s = f"id_{s}"
    result = s[:max_len]
    logger.debug("sanitize_for_spl2_identifier: original=%r sanitized=%r", name, result)
    return result


def get_spl2_safe_sourcetype_name(sourcetype: str):
    return sanitize_for_spl2_identifier(sourcetype)


def get_knowledge_base_provider_function_name(sourcetype: str):
    safe = get_spl2_safe_sourcetype_name(sourcetype)
    return f"noise_reduction_knowledgebase_{safe}"


def get_knowledge_base_provider_function_name_source_sourcetype(sourcetype: str, source: str):
    """
    Generate a SPL2-safe knowledge-base function name for a combination of source and sourcetype.
    """
    safe_sourcetype = get_spl2_safe_sourcetype_name(sourcetype)
    safe_source = get_spl2_safe_sourcetype_name(source)
    return f"noise_reduction_knowledgebase__{safe_sourcetype}_{safe_source}"


def get_knowledge_base_provider_module_name(sourcetype: str):
    return f"{get_spl2_safe_sourcetype_name(sourcetype)}_noise_reduction"


def get_knowledge_base_provider_spl2_file_name(sourcetype: str):
    return get_knowledge_base_provider_module_name(sourcetype) + ".spl2"


def get_pipeline_spl2_file_name(sourcetype: str):
    return f"{get_spl2_safe_sourcetype_name(sourcetype)}_noise_reduction.spl2"


def get_knowledge_base_provider_spl2_file(sourcetype: str):
    sourcetype = sourcetype.replace("/", "_")
    return os.path.join(SPL2_CONTENT_FOLDER, get_knowledge_base_provider_spl2_file_name(sourcetype))


def get_pipeline_spl2_file(sourcetype: str):
    return os.path.join(SPL2_CONTENT_FOLDER, get_pipeline_spl2_file_name(sourcetype))


def get_combined_knowledge_base_provider_spl2_file_name(sourcetypes: list) -> str:
    """
    Filename for the single combined SPL2 file: all sourcetypes in the name.
    Format: {safe_st1}_{safe_st2}_..._noise_reduction.spl2 (sorted for determinism).
    """
    if not sourcetypes:
        return "noise_reduction_combined.spl2"
    safe = [get_spl2_safe_sourcetype_name(st) for st in sorted(sourcetypes)]
    return "_".join(safe) + "_noise_reduction.spl2"


def get_combined_knowledge_base_provider_spl2_file(sourcetypes) -> str:
    """
    Path for the single combined SPL2 file when multiple sourcetypes are in one template.
    """
    if isinstance(sourcetypes, str):
        sourcetypes = [sourcetypes]
    name = get_combined_knowledge_base_provider_spl2_file_name(sourcetypes)
    return os.path.join(SPL2_CONTENT_FOLDER, name)
