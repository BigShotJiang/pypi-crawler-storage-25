from __future__ import annotations

import os
import re
from collections import defaultdict
from configparser import ConfigParser
from typing import Any

from conf_spl2_converter.knowledge_builder.common_utils.log_utils import logger
from conf_spl2_converter.knowledge_builder.common_utils.splunk_utils.splunk_event_constructs import SplunkEventFields
from conf_spl2_converter.knowledge_builder.common_utils.splunk_utils.ta_utils.eval_variable_extractor import (
    extract_variables_from_eval_code,
)
from conf_spl2_converter.knowledge_builder.common_utils.splunk_utils.ta_utils.splunk_pt_constructs import (
    KV_MODES,
    Booleans,
    PropsConfAttribute,
    TimeAttribute,
    TransformsConfAttribute,
)
from conf_spl2_converter.knowledge_builder.knowledge_base.knowledge_base_constructs import KnowledgeBaseAttribute

"""
Removes ways to name groups and get the output of the captured group stored appropiriately in a variable with that name.
Removing as certain ways like ?<> are not compatible in python but works in other languages(like .net) and viceversa.
Patterns examples
?<interface_id>
?P<BucketName>
"""


def cleanup_regex(regex_unclean: str) -> str:
    cleanup_patterns = [r"\?P<.*?>", r"\?<.*?>"]
    regex_clean = regex_unclean
    for cleanup_pattern in cleanup_patterns:
        regex_clean = re.sub(cleanup_pattern, "", regex_clean)
    return regex_clean


def get_report_stanza_names(report_stanzas_combined: str) -> set[str]:
    report_stanza_names: set[str] = set()
    report_stanza_names_unclean = report_stanzas_combined.split(",")
    for report_stanza_name_unclean in report_stanza_names_unclean:
        report_stanza_names.add(report_stanza_name_unclean.strip())
    return report_stanza_names


def get_transform_stanza_names(transport_stanzas_combined: str) -> set[str]:
    transforms_stanza_names: set[str] = set()
    transforms_stanza_names_unclean = transport_stanzas_combined.split(",")
    for transforms_stanza_name_unclean in transforms_stanza_names_unclean:
        transforms_stanza_names.add(transforms_stanza_name_unclean.strip())
    return transforms_stanza_names


def get_field_names(field_alias_value: str) -> list[str]:
    all_field_aliases = field_alias_value.split(
        ","
    )  # TODO: Bug when the AS clauses are not separated by a comma but separated by just a space
    all_field_aliases = [field_alias.strip() for field_alias in all_field_aliases]
    # Handling casesensitivity case for as, AS, As,aS
    fields = set()
    as_clauses = [" AS ", " as ", " As ", " aS "]
    for field_alias in all_field_aliases:
        for as_clause in as_clauses:
            if as_clause in field_alias:
                fields_unclean = field_alias.split(as_clause)
                for field_unclean in fields_unclean:
                    fields.add(field_unclean.strip())
    return list(fields)


def get_stanza_name_for_source(source_value: str) -> str:
    return "source::" + source_value


def get_all_stanzas(config: Any) -> list[str]:
    return config.sections()


def get_kv_pairs_for_stanza(config: Any, stanza_name: str) -> list[tuple[str, str]]:
    """
    Try config.items(stanza_name). On any exception, fallback to parsing
    `input/transforms.conf` manually and return list of (key, value) tuples.
    """
    try:
        return config.items(stanza_name)
    except Exception as exc:
        logger.info("config.items failed for stanza %s: %s. Falling back to `input/transforms.conf`", stanza_name, exc)

        default_transforms_path = os.path.join(os.getcwd(), "input", "transforms.conf")
        if not os.path.isfile(default_transforms_path):
            logger.debug("Fallback file not found: %s", default_transforms_path)
            return []

        stanza_dict = read_stanza_from_default_file(default_transforms_path, stanza_name)
        if stanza_dict:
            return list(stanza_dict.items())
        return []  # Explicitly return empty list when stanza_dict is empty


def read_stanza_from_default_file(path: str, stanza_name: str) -> dict[str, str]:
    """
    Read stanza from file using ConfigParser.
    Always returns a dict (empty if stanza not found).
    """
    if not os.path.isfile(path):
        logger.debug("File not found: %s", path)
        return {}

    parser = ConfigParser(interpolation=None)
    parser.optionxform = str  # preserve key case

    try:
        with open(path, encoding="utf-8", errors="ignore") as fh:
            parser.read_file(fh)
    except Exception as exc:
        logger.error("Error parsing %s: %s", path, exc)
        return {}

    # Return the requested stanza as a dict
    if stanza_name in parser:
        logger.info("Stanza %s found in file %s", stanza_name, path)
        return dict(parser.items(stanza_name))
    else:
        logger.error("Stanza %s not found in file %s", stanza_name, path)
        return {}


def get_all_eval_clauses(config: Any) -> list[str]:
    eval_clauses: list[str] = []
    for stanza in get_all_stanzas(config):
        stanza_eval_clauses = get_eval_clauses_for_stanza(config, stanza)
        eval_clauses.extend(stanza_eval_clauses)
    return eval_clauses


def get_regex_on_raw_for_stanza(config: Any, stanza_name: str) -> str | None:
    for transforms_attr_key, transforms_attr_value in get_kv_pairs_for_stanza(config, stanza_name):
        if (
            transforms_attr_key.upper() == TransformsConfAttribute.SOURCE_KEY
            and transforms_attr_value != SplunkEventFields._raw
        ):
            return None
    for transforms_attr_key, transforms_attr_value in get_kv_pairs_for_stanza(config, stanza_name):
        if transforms_attr_key.upper() == TransformsConfAttribute.REGEX:
            return transforms_attr_value
    return None


def get_eval_clauses_for_stanza(config: Any, stanza_name: str) -> list[str]:
    attribute_kv_pairs = get_kv_pairs_for_stanza(config, stanza_name)
    clauses: list[str] = []
    for attribute_key, attribute_value in attribute_kv_pairs:
        if is_eval_attribute(attribute_key):
            clauses.append(attribute_value)
    return clauses


def get_field_from_report_stanza(config: Any, stanza_name: str) -> str:
    field = SplunkEventFields._raw  # DEFAULT SOURCE_KEY
    for transforms_attr_key, transforms_attr_value in get_kv_pairs_for_stanza(config, stanza_name):
        if transforms_attr_key.upper() == TransformsConfAttribute.SOURCE_KEY:
            field = transforms_attr_value.strip()
            break
    return field


# Extracts field -> regex mapping from stanza of Splunk transforms.conf
def extract_field_regex_mapping(config: Any, transform_stanza_name: str) -> defaultdict[str, list[dict[str, Any]]]:
    local_mapping: defaultdict[str, list[dict[str, Any]]] = defaultdict(list)
    content = get_kv_pairs_for_stanza(config, transform_stanza_name)
    regex_matches: list[str] = []
    format_matches: list[str] = []

    # Iterate over the content tuple to extract REGEX and FORMAT
    for key, value in content:
        if key.upper() == "REGEX":
            regex_matches.append(value.strip())
        elif key.upper() == "FORMAT":
            format_matches.append(value.strip())

    # Track added mappings to avoid duplicates
    added_mappings: set[tuple[str, str] | str] = set()

    # Process each regex pattern found in the stanza
    for regex_pattern in regex_matches:
        regex_pattern = regex_pattern.strip()

        # Extract named groups from the regex (e.g., (?<field_name>...))
        named_groups = re.findall(r"\(\?<(?P<field_name>\w+)>", regex_pattern)
        logger.debug("Processing regex pattern: %s with named groups: %s", regex_pattern, named_groups)

        # Add each field to the mapping
        for field in named_groups:
            mapping: dict[str, Any] = {
                "stanza": transform_stanza_name,
                "regex": regex_pattern,
                "type": "named_group",
            }
            if (field, str(mapping)) not in added_mappings:
                local_mapping[field].append(mapping)
                logger.debug("Added REGEX mapping for field: %s with details: %s", field, mapping)
                added_mappings.add((field, str(mapping)))

        # If there's a FORMAT statement, extract field mappings
        if format_matches:
            format_pattern = format_matches[0].strip()
            # Extract field mappings from FORMAT (e.g., action::$1 transport::$2)
            field_mappings = re.findall(r"(?P<field_name>\w+)::?\$(?P<group_num>\d+)", format_pattern)

            for field_name, group_num in field_mappings:
                mapping = {
                    "stanza": transform_stanza_name,
                    "regex": regex_pattern,
                    "format": format_pattern,
                    "group_number": int(group_num),
                    "type": "format_group",
                }
                if str(mapping) not in added_mappings:
                    local_mapping[field_name].append(mapping)
                    logger.debug("Added FORMAT mapping for field: %s with details: %s", field_name, mapping)
                    added_mappings.add(str(mapping))

    return local_mapping


def get_regex_from_extract_clause(extract_clause_values: str) -> list[str]:
    all_extract_clauses = [c.strip() for c in extract_clause_values.split(",")]
    in_clauses = [" in ", " IN ", " In ", " iN "]

    regexes: list[str] = []
    for extract_clause in all_extract_clauses:
        no_in_clause = True
        for in_clause in in_clauses:
            if in_clause in extract_clause:
                no_in_clause = False
                segments = extract_clause.split(in_clause)
                regex = segments[0].strip()
                field = segments[1].strip()
                if field == SplunkEventFields._raw:
                    regexes.append(regex)
        if no_in_clause:
            regexes.append(extract_clause)
    return regexes


def get_field_from_extract_clause(extract_clause_values: str) -> list[str]:
    all_extract_clauses = [c.strip() for c in extract_clause_values.split(",")]
    in_clauses = [" in ", " IN ", " In ", " iN "]

    fields: list[str] = []
    for extract_clause in all_extract_clauses:
        no_in_clause = True
        for in_clause in in_clauses:
            if in_clause in extract_clause:
                no_in_clause = False
                segments = extract_clause.split(in_clause)
                field = segments[1].strip()
                fields.append(field)
        if no_in_clause:
            fields.extend(re.findall(r"\(\?<(?P<name>.*?)>", extract_clause))
    return fields


def get_kvmode_for_stanza(config: Any, stanza_name: str) -> str:
    kv_mode = KV_MODES.AUTO  # Default
    for transforms_attr_key, transforms_attr_value in get_kv_pairs_for_stanza(config, stanza_name):
        if transforms_attr_key.upper() == KnowledgeBaseAttribute.KV_MODE:
            kv_mode = transforms_attr_value
            break
    return kv_mode


def get_autokvjson_for_stanza(config: Any, stanza_name: str) -> bool:
    auto_kv_json = Booleans.TRUE  # Default
    for transforms_attr_key, transforms_attr_value in get_kv_pairs_for_stanza(config, stanza_name):
        if transforms_attr_key.upper() == KnowledgeBaseAttribute.AUTO_KV_JSON:
            auto_kv_json = transforms_attr_value.lower()
            break
    return auto_kv_json == Booleans.TRUE


def is_stanza_having_regex_clauses(config: Any, stanza_name: str) -> bool:
    regex_clauses = {PropsConfAttribute.REPORT, PropsConfAttribute.EXTRACT}
    for transforms_attr_key, _transforms_attr_value in get_kv_pairs_for_stanza(config, stanza_name):
        transforms_attr_key = transforms_attr_key.upper()
        clause = transforms_attr_key.split("-")[0]
        if clause in regex_clauses:
            return True
    return False


def is_stanza_having_report_clause(config: Any, stanza_name: str) -> bool:
    for transforms_attr_key, _transforms_attr_value in get_kv_pairs_for_stanza(config, stanza_name):
        if transforms_attr_key.upper().startswith(PropsConfAttribute.REPORT):
            return True
    return False


def is_stanza_having_extract_clause(config: Any, stanza_name: str) -> bool:
    for transforms_attr_key, _transforms_attr_value in get_kv_pairs_for_stanza(config, stanza_name):
        if transforms_attr_key.upper().startswith(PropsConfAttribute.EXTRACT):
            return True
    return False


def is_report_attribute(attribute: str) -> bool:
    return attribute.upper().startswith(PropsConfAttribute.REPORT)


def is_transforms_attribute(attribute: str) -> bool:
    return attribute.upper().startswith(PropsConfAttribute.TRANSFORMS)


def is_extract_attribute(attribute: str) -> bool:
    return attribute.upper().startswith(PropsConfAttribute.EXTRACT)


def is_kvmode_attribute(attribute: str) -> bool:
    return attribute.upper().startswith(PropsConfAttribute.KV_MODE)


def is_field_alias_attribute(attribute: str) -> bool:
    return attribute.upper().startswith(PropsConfAttribute.FIELDALIAS)


def is_time_attribute(attribute: str) -> bool:
    return attribute.upper() in (
        TimeAttribute.TIME_PREFIX,
        TimeAttribute.TIME_FORMAT,
        TimeAttribute.TIME_ZONE,
        TimeAttribute.MAX_TIMESTAMP_LOOKAHEAD,
    )


def is_eval_attribute(attribute: str) -> bool:
    return attribute.upper().startswith(PropsConfAttribute.EVAL)


def is_lookup_attribute(attribute: str) -> bool:
    return attribute.upper().startswith(PropsConfAttribute.LOOKUP)


def get_input_fields_from_lookup_clause(lookup_value: str) -> list[str]:
    """
    Parse a props.conf LOOKUP clause value and return event (input) field names.

    Syntax: <lookup_name> <input_fields> OUTPUT[NEW] <output_field>
    - input_fields: comma-separated, each part is "field" or "field AS lookup_column"

    Examples:
      "windows_signature_lookup signature_id OUTPUTNEW CategoryString,action"
        -> ["signature_id"]
      "xmlsecurity_eventcode_errorcode_action_lookup EventCode, Error_Code OUTPUTNEW action"
        -> ["EventCode", "Error_Code"]
      "windows_start_mode_lookup StartType AS start_type2 OUTPUTNEW start_mode"
        -> ["StartType"]
    """
    if not lookup_value or not lookup_value.strip():
        return []
    value = lookup_value.strip()

    match = re.match(
        r"^\s*\S+\s+(?P<input_fields>.+?)\s+OUTPUT(?:NEW)?\s+",
        value,
        flags=re.IGNORECASE | re.DOTALL,
    )
    if not match:
        return []
    input_fields = match.group("input_fields").strip()
    if not input_fields:
        return []
    # Capture each input field name:
    # at start or after comma, take first word (optionally before " AS ...")
    return re.findall(
        r"(?:^|,\s*)(?P<field>\w+)(?=\s*(?:AS\s+\S+)?(?:,|$))",
        input_fields,
        flags=re.IGNORECASE,
    )


def find_dependent_fields_from_eval_code_using_static_analysis(code: str) -> str:
    variables = extract_variables_from_eval_code(code)
    return ",".join(variables)
