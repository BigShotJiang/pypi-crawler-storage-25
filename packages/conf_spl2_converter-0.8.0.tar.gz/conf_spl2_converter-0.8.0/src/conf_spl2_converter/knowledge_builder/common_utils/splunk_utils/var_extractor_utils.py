import re

SINGLE_QUOTE = "'"
DOUBLE_QUOTE = '"'


def is_int(s):
    try:
        int(s)
        return True
    except ValueError:
        return False


def extract_single_quote_variables(code) -> list:
    pattern = r"'(.*?)'"

    # Find all matches
    matches = re.findall(pattern, code)
    return list(set(matches))


def remove_space(code):
    code = code.replace(" ", "")
    return code


def remove_newline(code):
    code = code.replace("\n", "")
    return code


def remove_booleans(code):
    true_val = "True"
    false_val = "False"
    code = code.replace(true_val, "")
    code = code.replace(true_val.lower(), "")
    code = code.replace(true_val.upper(), "")

    code = code.replace(false_val, "")
    code = code.replace(false_val.upper(), "")
    code = code.replace(false_val.lower(), "")
    return code


def clean_double_quote_strings(code):
    double_quote_regex = r'"[^"]*"'
    code = re.sub(double_quote_regex, "", code)
    return code


def clean_single_quote_strings(code):
    double_quote_regex = r"'[^']*'"
    code = re.sub(double_quote_regex, "", code)
    return code


def clean_single_tick_strings(code):
    double_quote_regex = r"`[^`]*`"
    code = re.sub(double_quote_regex, "", code)
    return code


def remove_unwanted_variables(variables):
    cleaned_variables = set()
    splunk_commands = [
        "cluster",
        "addinfo",
        "xyseries",
        "metasearch",
        "join",
        "erex",
        "sendalert",
        "xmlkv",
        "gentimes",
        "tags",
        "scrub",
        "analyzefields",
        "diff",
        "fieldformat",
        "convert",
        "bucketdir",
        "iconify",
        "mstats",
        "from",
        "associate",
        "geom",
        "redistribute",
        "contingency",
        "addcoltotals",
        "overlap",
        "autoregress",
        "iplocation",
        "top",
        "xmlunescape",
        "return",
        "mcollect",
        "findtypes",
        "rename",
        "typeahead",
        "appendcols",
        "anomalydetection",
        "union",
        "sichart",
        "reverse",
        "nomv",
        "tstats",
        "untable",
        "correlate",
        "geomfilter",
        "tojson",
        "lookup",
        "typer",
        "tail",
        "eventcount",
        "eventstats",
        "streamstats",
        "sitimechart",
        "stats",
        "addtotals",
        "rex",
        "appendpipe",
        "delta",
        "dedup",
        "collect",
        "chart",
        "makeresults",
        "reltime",
        "localize",
        "localop",
        "searchtxn",
        "inputlookup",
        "strcat",
        "xpath",
        "anomalies",
        "mpreview",
        "search",
        "rare",
        "anomalousvalue",
        "msearch",
        "folderize",
        "loadjob",
        "transpose",
        "meventcollect",
        "uniq",
        "dbinspect",
        "sitop",
        "arules",
        "highlight",
        "require",
        "makemv",
        "extract",
        "sort",
        "spath",
        "span",
        "predict",
        "where",
        "tscollect",
        "foreach",
        "trendline",
        "selfjoin",
        "filldown",
        "datamodel",
        "kmeans",
        "outputtext",
        "rest",
        "kvform",
        "regex",
        "multisearch",
        "transaction",
        "mvexpand",
        "table",
        "pivot",
        "metadata",
        "cofilter",
        "multikv",
        "replace",
        "timewrap",
        "format",
        "timechart",
        "mvcombine",
        "outputcsv",
        "abstract",
        "walklex",
        "x11",
        "sirare",
        "set",
        "history",
        "outlier",
        "gauge",
        "fields",
        "sendemail",
        "savedsearch",
        "outputlookup",
        "inputcsv",
        "typelearner",
        "rangemap",
        "setfields",
        "append",
        "rtorder",
        "bin",
        "geostats",
        "map",
        "sistats",
        "eval",
        "head",
        "concurrency",
        "delete",
        "makecontinuous",
        "accum",
        "fillnull",
        "script",
        "fieldsummary",
    ]
    misc_commands = ["span", "min", "max", "by", "datamodel", "OUTPUT", "maxspan", "minspan", "bucket"]
    for variable in variables:
        if (
            variable == "\\\n"
            or variable.strip() == ""
            or variable == ""
            or variable == "-"
            or variable == "\\"
            or variable in splunk_commands
            or variable in misc_commands
        ):
            continue
        else:
            var1 = variable.strip("")
            var1 = var1.lstrip("\\")
            cleaned_variables.add(var1)

    return list(set(cleaned_variables))


def get_cleaned_variable_name(variable_name):
    if SINGLE_QUOTE in variable_name:
        variable_name = variable_name.replace(SINGLE_QUOTE, "")
    if DOUBLE_QUOTE in variable_name:
        variable_name = variable_name.replace(DOUBLE_QUOTE, "")
    variable_name = variable_name.strip()
    return variable_name
