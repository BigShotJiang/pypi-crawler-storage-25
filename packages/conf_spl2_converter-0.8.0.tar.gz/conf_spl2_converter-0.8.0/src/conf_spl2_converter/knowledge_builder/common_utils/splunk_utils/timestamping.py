# TODO: eliminate this hardcoded approach
timestamping_regexes_map = {
    "sysmon:linux": r'<Data Name="UtcTime">.*?</Data>',
    "WinEventLog": r"\b(0[1-9]|1[0-2]|[1-9])\/(0[1-9]|[12][0-9]|3[01])\/(19|20)\d\d\s(0[1-9]|1[0-2]|[1-9]):([0-5][0-9]):([0-5][0-9])\s(AM|PM)\b\n?",
}


def get_timestamping_regex(sourcetype):
    if sourcetype in timestamping_regexes_map:
        return timestamping_regexes_map[sourcetype]
    else:
        return None


def add_timestamping_regex_from_props(props_conf_content, sourcetype):
    """
    Parses the props.conf content to find timestamp-related regex patterns for a specific sourcetype.
    If found, adds them to the timestamping_regexes_map.

    :param props_conf_content: The content of the props.conf file as a string.
    :param sourcetype: The specific sourcetype to process.
    """
    import re

    # Define a regex pattern to identify timestamp-related attributes in props.conf
    timestamp_regex_pattern = re.compile(r"(?i)TIME_FORMAT|TIME_PREFIX|MAX_TIMESTAMP_LOOKAHEAD|TIME_ZONE")

    # Split the props.conf content into stanzas
    stanzas = props_conf_content.split("\n\n")

    for stanza in stanzas:
        lines = stanza.splitlines()
        current_sourcetype = None
        regex_found = None

        for line in lines:
            # Check for the sourcetype in the stanza header
            if line.startswith("[") and line.endswith("]"):
                current_sourcetype = line.strip("[]")

            # Skip processing if the current stanza is not the target sourcetype
            if current_sourcetype != sourcetype:
                continue

            # Check for timestamp-related regex attributes
            if timestamp_regex_pattern.search(line):
                regex_found = line.split("=", 1)[-1].strip()

        # Add the regex to the map if the target sourcetype and regex are found
        if current_sourcetype == sourcetype and regex_found:
            timestamping_regexes_map[sourcetype] = regex_found
            print(f"Added timestamping regex for sourcetype: {sourcetype}")
