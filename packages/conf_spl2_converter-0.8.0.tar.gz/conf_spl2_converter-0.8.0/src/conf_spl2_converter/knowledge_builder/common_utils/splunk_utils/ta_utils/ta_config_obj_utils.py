from addonfactory_splunk_conf_parser_lib import TABConfigParser

from conf_spl2_converter.knowledge_builder.common_utils.log_utils import logger


def get_ta_config_object():
    config = TABConfigParser()
    return config


def load_conf_files(config, files):
    config.read(files)


def write_object_to_file(config, file_location):
    with open(file_location, "w") as file:
        config.write(file)


def iterate_all(config):
    # logger.info(config.get(section="sysmon:linux", option="FIELDALIAS-dvc"))
    for section in config.sections():
        if section == "sysmon:linux":
            for k, v in config.items(section):
                logger.info("key ######")
                logger.info(k)
                logger.info("value #####")
                logger.info(v)
