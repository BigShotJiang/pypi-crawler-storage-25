"""Input config for Knowledge Builder: same behaviour as converter.

Re-exports the converter's InputConfig so KB uses the same resolution:
- When config_file is provided, use it.
- Else look for field_extraction_config.json in the TA directory.
- Else auto-discover sourcetypes from props.conf.
"""

from conf_spl2_converter.converter.input_config import InputConfig

__all__ = ["InputConfig"]
