def filter_json(input_json, interested_fields):
    if not interested_fields:
        return input_json
    main_ptr = {}

    for field in interested_fields:
        valid_parts_detected = False
        parts = field.split(".")

        growing_json = main_ptr
        value_in_input_json = input_json

        final_key_reference = growing_json
        final_key = None

        for part in parts:
            if not part.endswith("{}"):
                if isinstance(value_in_input_json, dict) and part in value_in_input_json:
                    valid_parts_detected = True
                    value_in_input_json = value_in_input_json[part]

                    if part not in growing_json:
                        growing_json[part] = dict()
                    final_key_reference = growing_json
                    final_key = part
                    growing_json = growing_json[part]
                else:
                    break
            else:
                part = part.removesuffix("{}")
                if isinstance(value_in_input_json, dict) and part in value_in_input_json:
                    valid_parts_detected = True
                    value_in_input_json = value_in_input_json[part]

                    if part not in growing_json:
                        growing_json[part] = list()
                    final_key_reference = growing_json
                    final_key = part
                    growing_json = growing_json[part]
                else:
                    break
                break  # Don't recurse into arrays — compromise on reduction depth.
        if valid_parts_detected:
            final_key_reference[final_key] = value_in_input_json

    return main_ptr
