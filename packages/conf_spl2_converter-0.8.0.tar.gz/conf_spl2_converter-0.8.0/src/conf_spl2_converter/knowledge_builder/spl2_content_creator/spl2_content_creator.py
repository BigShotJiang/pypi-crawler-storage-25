from __future__ import annotations

import contextlib
import json
import os
import re

from conf_spl2_converter.converter.input_config import (
    HUMAN_READABLE_NAME,
    SPLUNK_BASE_URL,
    TEMPLATE_VERSION,
    VERSION,
    InputConfig,
)
from conf_spl2_converter.converter.template_annotation import generate_template_annotation
from conf_spl2_converter.knowledge_builder.common_utils.log_utils import logger
from conf_spl2_converter.knowledge_builder.common_utils.spl2_utils import (
    get_combined_knowledge_base_provider_spl2_file,
    get_knowledge_base_provider_function_name,
    get_knowledge_base_provider_function_name_source_sourcetype,
    get_spl2_safe_sourcetype_name,
)
from conf_spl2_converter.knowledge_builder.common_utils.utils import (
    get_knowledge_base_for_sourcetype,
    sort_knowledge_base,
)
from conf_spl2_converter.knowledge_builder.input.configuration_constants import (
    IMPORT_NOISEREDUCE_TEMPLATE,
    KNOWLEDGE_BASE_PROVIDER_SPL2_TEMPLATE,
    PIPELINE_SPL2_TEMPLATE,
    SPL2_CONTENT_FOLDER,
)


def format_knowledge_base_json(knowledge_base_for_sourcetype_json_str):
    formatted_json = []
    for line_number, line in enumerate(knowledge_base_for_sourcetype_json_str.splitlines(), start=1):
        if line_number == 1:
            formatted_json.append(line)
        else:
            formatted_json.append(" " * 18 + line)

    return "\n".join(formatted_json)


def get_knowledge_base_provider_spl2_template():
    with open(KNOWLEDGE_BASE_PROVIDER_SPL2_TEMPLATE) as f:
        return f.read()


def get_import_noisereduce_spl2_template():
    with open(IMPORT_NOISEREDUCE_TEMPLATE) as f:
        return f.read()


def get_pipeline_spl2_template():
    with open(PIPELINE_SPL2_TEMPLATE) as f:
        return f.read()


def _get_sourcetypes_from_kb_pairs(kb_pairs):
    """Return distinct sourcetypes from kb_pairs keys (sourcetype, source), sorted."""
    return sorted({pair[0] for pair in kb_pairs})


ROUTE_IMPORT = "import route from /splunk.ingest.commands"


def _get_expanded_sourcetypes(input_config: InputConfig) -> tuple[list, list]:
    """
    Return (route_sourcetypes, catchall_sourcetypes).
    - route_sourcetypes: sourcetypes that get a route and KB function (sub_sourcetypes only when present; else parent).
    - catchall_sourcetypes: all sourcetypes for reference (parent + sub_sourcetypes when present).
    So when sub_sourcetypes exist we do not route on the main sourcetype and do not emit a function for it.
    """
    route_list = []
    catchall_list = []
    for st in input_config.get_input_sourcetypes():
        sub_sourcetypes = input_config.get_sub_sourcetypes(st)
        if sub_sourcetypes:
            route_list.extend(sub_sourcetypes)
            catchall_list.append(st)
            catchall_list.extend(sub_sourcetypes)
        else:
            route_list.append(st)
            catchall_list.append(st)
    return route_list, catchall_list


def _get_pairs_for_sourcetype(kb_pairs, sourcetype):
    """Return the subset of kb_pairs for the given sourcetype."""
    return {pair: kb for pair, kb in kb_pairs.items() if pair[0] == sourcetype}


def _kb_function_block(kb_template: str, fn_name: str, kb: dict) -> str:
    """One KB function block: sort kb, format with template, return string."""
    sort_knowledge_base(kb)
    return kb_template.format(
        knowledge_base_provider_function_name=fn_name,
        knowledgebase_json=format_knowledge_base_json(json.dumps(kb, indent=2)),
    )


def _route_line(match_field: str, regex: str, fn_name: str) -> str:
    """One pipeline route: divert matching events, noisereduce with fn_name, into $destination."""
    return (
        f"| route match({match_field}, /{regex}/), [ | eval _raw=noisereduce({fn_name}(), _raw) | into $destination ]"
    )


def _route_line_compound(sourcetype_regex: str, source_regex: str, fn_name: str) -> str:
    """Pipeline route matching on both sourcetype AND source."""
    return (
        f"| route match(sourcetype, /{sourcetype_regex}/) and match(source, /{source_regex}/), "
        f"[ | eval _raw=noisereduce({fn_name}(), _raw) | into $destination ]"
    )


def create_spl2_content(input_config: InputConfig, kb_pairs=None):
    """
    Single entry point: generate one SPL2 file for all sourcetypes/sources.
    Uses SPL2 ``route`` command to divert matching events per sourcetype/source.
    - When kb_pairs is None or empty: route on sourcetype (one KB per sourcetype, unmatched pass through).
    - When kb_pairs is non-empty: route on source (per-pair, per-sourcetype, unmatched pass through).
    Output path is get_combined_knowledge_base_provider_spl2_file(sourcetypes).
    """
    if kb_pairs is None:
        kb_pairs = {}
    if kb_pairs:
        sourcetypes = _get_sourcetypes_from_kb_pairs(kb_pairs)
        catchall_sourcetypes = None
        filename_sourcetypes = input_config.get_input_sourcetypes() if input_config else sourcetypes
    else:
        route_sourcetypes, catchall_sourcetypes = _get_expanded_sourcetypes(input_config) if input_config else ([], [])
        sourcetypes = route_sourcetypes
        catchall_sourcetypes = catchall_sourcetypes if route_sourcetypes != catchall_sourcetypes else None
        if input_config and catchall_sourcetypes is not None and len(catchall_sourcetypes) > len(sourcetypes):
            filename_sourcetypes = input_config.get_input_sourcetypes()
        else:
            filename_sourcetypes = catchall_sourcetypes if catchall_sourcetypes is not None else sourcetypes
    if not sourcetypes:
        return

    # Build sourcetype → source patterns mapping so compound routes can be generated
    source_patterns: dict[str, list[str]] = {}
    if input_config:
        for parent_st in input_config.get_input_sourcetypes():
            sources = input_config.get_source(parent_st)
            if isinstance(sources, list) and sources:
                sub_sts = input_config.get_sub_sourcetypes(parent_st) or []
                for st in [parent_st, *sub_sts]:
                    source_patterns[st] = sources

    _write_spl2_content(
        input_config, kb_pairs, sourcetypes, catchall_sourcetypes, filename_sourcetypes, source_patterns
    )


def _to_spl2_regex(s: str) -> str:
    r"""
    Convert a glob-like or regex-like pattern into a string safe for use inside an SPL2
    regex literal (the text that would appear between the `/` delimiters).

    - Normalize `...` -> `.*`.
    - If the pattern contains explicit regex tokens, treat it as a regex:
      - do not disturb existing `.*`
      - convert standalone `*` (not part of `.*`) -> `.*` (heuristic)
      - double backslashes and escape `/`
    - Otherwise treat as glob-like:
      - escape with `re.escape`, convert escaped `\*` -> `.*`, and escape `/`.
    """
    if not s:
        return ""

    # normalize the explicit shorthand
    s = s.replace("...", ".*")

    regex_tokens = ("(", ")", "|", "[", "]", "{", "}", "?", "+", "^", "$")
    is_regex_like = any(tok in s for tok in regex_tokens)

    if is_regex_like:
        # Heuristic: convert '*' that are NOT already part of '.*' into '.*' to support mixed inputs,
        # but avoid converting existing '.*' into '..*'
        s = re.sub(r"(?<!\.)\*", ".*", s)
        # double backslashes so the SPL2 regex literal sees '\\' for each '\' in the pattern
        s = s.replace("\\", r"\\")
        # escape the SPL2 regex delimiter '/'
        s = s.replace("/", r"\/")
        return s
    else:
        # Treat as glob-like: escape regex metacharacters, convert glob '*' -> '.*'
        escaped = re.escape(s)
        # convert escaped glob stars back into '.*'
        escaped = escaped.replace(r"\*", ".*")
        # ensure slash is escaped for /.../ delimiter
        escaped = escaped.replace("/", r"\/")
        return escaped


# Knowledge Builder template naming: output_dir/<slug>/{slug}_noisereduce.spl2
NOISEREDUCE_FILE_NAME = "{slug}_noisereduce.spl2"
COMBINED_SLUG = "all_sourcetypes"

DEFAULT_TEMPLATE_VERSION = "0.1.0"
HEADER_PLACEHOLDER_ADDON = "[ADDON_DISPLAY_NAME]"
HEADER_PLACEHOLDER_VERSION = "[COMPATIBLE_VERSION]"
HEADER_PLACEHOLDER_URL = "[SPLUNKBASE_URL]"
HEADER_PLACEHOLDER_TEMPLATE_VERSION = "[TEMPLATE_VERSION]"

DISCLAIMER_TEXT = """
 Disclaimer :
 BY USING SPL2 TEMPLATES FOR DATA PROCESSING (THE "TEMPLATES"), YOU UNDERSTAND AND AGREE THAT TEMPLATES ARE PROVIDED "AS IS". SPLUNK DISCLAIMS ANY AND ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND WARRANTIES ARISING OUT OF COURSE OF DEALING OR USAGE OF TRADE OR BY STATUTE OR IN LAW. SPLUNK SPECIFICALLY DOES NOT WARRANT THAT TEMPLATES WILL MEET YOUR REQUIREMENTS, THE OPERATION OR OUTPUT OF TEMPLATES WILL BE ERROR-FREE, ACCURATE, RELIABLE, COMPLETE OR UNINTERRUPTED.
"""


def _addon_display_name_from_addon_name(addon_name: str) -> str:
    """Derive short display name from addon_name (e.g. splunk-add-on-for-cisco-asa -> Cisco ASA)."""
    if not addon_name or not addon_name.strip():
        return HEADER_PLACEHOLDER_ADDON
    s = addon_name.strip().lower()
    for prefix in ("splunk-add-on-for-", "splunk_ta_", "splunk-ta-"):
        if s.startswith(prefix):
            s = s[len(prefix) :]
            break
    return s.replace("-", " ").replace("_", " ").title()


def _build_noisereduce_header(
    input_config: InputConfig | None,
    sourcetypes: list,
    include_disclaimer: bool = True,
    overview_note: str | None = None,
    all_sourcetypes: list | None = None,
) -> str:
    """
    Build the comment header for a noise reduction SPL2 template.
    Uses metadata from the first sourcetype when input_config is provided; otherwise placeholders.
    When all_sourcetypes is provided, it is used for the Sourcetype display row (includes sub_sourcetypes).
    """
    display_list = all_sourcetypes if all_sourcetypes else sourcetypes
    if not sourcetypes:
        first_st = None
        sourcetype_display = "[SOURCETYPE]"
    else:
        first_st = sourcetypes[0]
        sourcetype_display = ", ".join(display_list)

    if input_config and first_st:
        human = input_config.get_attribute_value_for_sourcetype(first_st, HUMAN_READABLE_NAME)
        addon_name = input_config.get_addon_name_for_sourcetype(first_st)
        version = input_config.get_attribute_value_for_sourcetype(first_st, VERSION)
        url = input_config.get_attribute_value_for_sourcetype(first_st, SPLUNK_BASE_URL)
        template_version = input_config.get_attribute_value_for_sourcetype(first_st, TEMPLATE_VERSION)
        addon_display = (
            human or _addon_display_name_from_addon_name(addon_name or "") or HEADER_PLACEHOLDER_ADDON
        ).strip()
    else:
        addon_display = HEADER_PLACEHOLDER_ADDON
        version = HEADER_PLACEHOLDER_VERSION
        url = HEADER_PLACEHOLDER_URL
        template_version = HEADER_PLACEHOLDER_TEMPLATE_VERSION

    if not addon_display:
        addon_display = HEADER_PLACEHOLDER_ADDON
    if not version:
        version = HEADER_PLACEHOLDER_VERSION
    if not url:
        url = HEADER_PLACEHOLDER_URL
    if not template_version:
        template_version = DEFAULT_TEMPLATE_VERSION

    title = f"SPL2 template for {addon_display} noise reduction"
    sep = "=" * len(title)
    table_row = "|---------------------|------------------------------------------------------------|"
    lines = [
        title,
        sep,
        "",
        "Metadata:",
        table_row,
        f"| Template version    | {template_version}",
        f"| Add-on Name         | {addon_display}",
        f"| Compatible version  | {version}",
        f"| Splunkbase URL      | {url}",
        f"| Sourcetype          | {sourcetype_display}",
        table_row,
        "",
    ]
    if include_disclaimer:
        lines.append(DISCLAIMER_TEXT.strip())
        lines.append("")
    lines.extend(
        [
            "Overview:",
            "This SPL2 template is auto-generated using regular expressions from Splunk add-on configuration files (`props.conf`, `transforms.conf`).",
            "It enables the `noisereduce` function to filter out noise from log events, enhancing data quality for analysis.",
            "",
        ]
    )
    if overview_note:
        lines.append(overview_note)
        lines.append("")
    lines.extend(
        [
            "Purpose:",
            "Automates noise reduction for logs by leveraging Splunk Knowledge Objects, improving downstream analytics and alerting.",
            "",
            "Generated by:",
            "Automated SPL2 knowledge builder for Splunk Knowledge Object-based noise reduction.",
        ]
    )
    return "\n".join(lines)


def _prepend_header(content: str, header: str, annotation: str = "") -> str:
    """Prepend block comment header and insert @template annotation just before $pipeline."""
    result = "/*\n" + header + "\n*/\n\n" + content
    if annotation:
        result = result.replace("$pipeline =", annotation + "\n$pipeline =", 1)
    return result


def _build_spl2_content(
    kb_pairs: dict,
    sourcetypes: list,
    catchall_sourcetypes: list | None = None,
    source_patterns: dict[str, list[str]] | None = None,
) -> str:
    """
    Build SPL2 content string for the given sourcetypes (and kb_pairs when non-empty).
    Uses chained ``route`` commands to divert matching events per sourcetype/source.
    When source_patterns is provided, compound routes (sourcetype AND source) are generated.
    Unmatched events fall through to ``| into $destination`` at the end.
    """
    if source_patterns is None:
        source_patterns = {}
    kb_template = get_knowledge_base_provider_spl2_template()
    has_pairs = bool(kb_pairs)
    if has_pairs:
        kb_pairs = dict(sorted(kb_pairs.items(), key=lambda item: item[0]))

    blocks = [get_import_noisereduce_spl2_template()]
    route_by_key: dict[str, str] = {} if has_pairs else None
    route_lines: list[str] = [] if not has_pairs else None

    # Detect single-dimension cases: skip the redundant dimension in routing but keep it in function names.
    unique_sources = {pair[1] for pair in kb_pairs} if has_pairs else set()
    unique_sourcetypes = {pair[0] for pair in kb_pairs} if has_pairs else set()
    single_source = has_pairs and len(unique_sources) == 1
    single_sourcetype = has_pairs and len(unique_sourcetypes) == 1
    emitted_sourcetypes: set[str] = set()
    emitted_sources: set[str] = set()

    if has_pairs:
        for pair, kb in kb_pairs.items():
            sourcetype_name = pair[0]
            src = pair[1].removeprefix("source::")
            fn_name = get_knowledge_base_provider_function_name_source_sourcetype(
                sourcetype=sourcetype_name, source=pair[1]
            )

            if single_source:
                if sourcetype_name not in emitted_sourcetypes:
                    blocks.append(_kb_function_block(kb_template, fn_name, kb))
                    route_by_key[get_spl2_safe_sourcetype_name(sourcetype_name)] = _route_line(
                        "sourcetype", _to_spl2_regex(sourcetype_name), fn_name
                    )
                    emitted_sourcetypes.add(sourcetype_name)
            elif single_sourcetype:
                if src not in emitted_sources:
                    blocks.append(_kb_function_block(kb_template, fn_name, kb))
                    route_by_key[get_spl2_safe_sourcetype_name(src)] = _route_line(
                        "source", _to_spl2_regex(src), fn_name
                    )
                    emitted_sources.add(src)
            else:
                blocks.append(_kb_function_block(kb_template, fn_name, kb))
                pair_key = f"{get_spl2_safe_sourcetype_name(sourcetype_name)}__{get_spl2_safe_sourcetype_name(src)}"
                route_by_key[pair_key] = _route_line_compound(
                    _to_spl2_regex(sourcetype_name), _to_spl2_regex(src), fn_name
                )

    for sourcetype in sourcetypes:
        if has_pairs and sourcetype in emitted_sourcetypes:
            continue

        kb = get_knowledge_base_for_sourcetype(sourcetype=sourcetype)
        fn_name = get_knowledge_base_provider_function_name(sourcetype=sourcetype)
        blocks.append(_kb_function_block(kb_template, fn_name, kb))
        regex = _to_spl2_regex(sourcetype)

        if has_pairs:
            if single_sourcetype:
                # Single sourcetype with multiple sources: add fallback route for base source
                pairs_for_st = _get_pairs_for_sourcetype(kb_pairs, sourcetype)
                if pairs_for_st:
                    sources = [v[1].replace("source::", "") for v in pairs_for_st]
                    has_sub_sources = any(":" in s for s in sources)
                    if has_sub_sources:
                        base_source, last_line = calculate_last_route_case_for_multiple_sources(
                            pairs_for_st, sourcetype
                        )
                        route_by_key[base_source] = last_line
            else:
                key = get_spl2_safe_sourcetype_name(sourcetype)
                pairs_for_st = _get_pairs_for_sourcetype(kb_pairs, sourcetype)
                if pairs_for_st:
                    sources = [v[1].replace("source::", "") for v in pairs_for_st]
                    has_sub_sources = any(":" in s for s in sources)
                    if has_sub_sources:
                        base_source, last_line = calculate_last_route_case_for_multiple_sources(
                            pairs_for_st, sourcetype
                        )
                        route_by_key[base_source] = last_line
                else:
                    route_by_key[key] = _route_line("sourcetype", regex, fn_name)
        else:
            sources_for_st = source_patterns.get(sourcetype)
            if sources_for_st and len(sources_for_st) > 1:
                for src in sources_for_st:
                    route_lines.append(_route_line_compound(regex, _to_spl2_regex(src), fn_name))
            else:
                route_lines.append(_route_line("sourcetype", regex, fn_name))

    single_sourcetype_no_pairs = not has_pairs and len(sourcetypes) == 1
    needs_route = not single_sourcetype_no_pairs

    if has_pairs:
        pipeline_body = "\n".join(route_by_key.values())
        pipeline = pipeline_body + "\n| into $destination;\n"
    elif single_sourcetype_no_pairs:
        fn_name = get_knowledge_base_provider_function_name(sourcetype=sourcetypes[0])
        pipeline = f"| eval _raw=noisereduce({fn_name}(), _raw)  | into $destination;\n"
    else:
        pipeline_body = "\n".join(route_lines)
        pipeline = pipeline_body + "\n| into $destination;\n"

    pipeline_intro = "| from $source\n " if single_sourcetype_no_pairs else "| from $source\n"

    content_blocks = "\n\n".join(blocks)
    if needs_route:
        content_blocks = ROUTE_IMPORT + "\n\n" + content_blocks
    return content_blocks + "\n\n$pipeline = " + pipeline_intro + pipeline


def _build_noisereduce_annotation(
    input_config: InputConfig | None,
    sourcetypes: list[str],
    all_sourcetypes: list[str] | None = None,
) -> str:
    """Build a ``@template(...)`` annotation for a noise reduction SPL2 file."""
    st_values = list(all_sourcetypes) if all_sourcetypes else list(sourcetypes)

    st_operator = "EQUAL"
    st_field = "sourcetype"

    if input_config and sourcetypes:
        first_st = sourcetypes[0]
        human = input_config.get_attribute_value_for_sourcetype(first_st, HUMAN_READABLE_NAME)
        addon_name = input_config.get_addon_name_for_sourcetype(first_st)
        display = (human or _addon_display_name_from_addon_name(addon_name or "")).strip()
        name_override = input_config.get_template_name(first_st)
        desc_override = input_config.get_template_description(first_st)
        runtime_override = input_config.get_template_runtime(first_st)
        events_override = input_config.get_template_events(first_st)
        st_override = input_config.get_template_sourcetype(first_st)
        if st_override:
            st_values = st_override["values"]
            st_operator = st_override.get("operator", "EQUAL")
            st_field = st_override.get("field", "sourcetype")
    else:
        display = HEADER_PLACEHOLDER_ADDON
        name_override = desc_override = runtime_override = events_override = None

    name = name_override or f"{display}: noise reduction"
    description = desc_override or (
        "Noise reduction template that filters out noisy log events, enhancing data quality for analysis."
    )
    runtime = runtime_override or ["ingestProcessor", "edgeProcessor"]

    return generate_template_annotation(
        name=name,
        description=description,
        runtime=runtime,
        sourcetype_values=st_values,
        sourcetype_operator=st_operator,
        sourcetype_field=st_field,
        events=events_override,
    )


def _write_spl2_content(
    input_config: InputConfig,
    kb_pairs: dict,
    sourcetypes: list,
    catchall_sourcetypes: list | None = None,
    filename_sourcetypes: list | None = None,
    source_patterns: dict[str, list[str]] | None = None,
):
    """
    Build and write SPL2 file(s). When no config was provided (used_auto_discovery),
    writes one combined template (all sourcetypes) and one per sourcetype:
    <output_dir>/<slug>/{slug}_noisereduce.spl2.
    Otherwise writes a single combined file to the legacy path.
    catchall_sourcetypes: all sourcetypes for reference (main + subs) when sub_sourcetypes are present.
    filename_sourcetypes: sourcetypes used for the output filename (e.g. parent only when sub_sourcetypes exist).
    source_patterns: mapping of sourcetype -> source patterns for compound route conditions.
    """
    if source_patterns is None:
        source_patterns = {}
    display_sourcetypes = catchall_sourcetypes if catchall_sourcetypes is not None else sourcetypes
    name_sourcetypes = filename_sourcetypes if filename_sourcetypes is not None else display_sourcetypes
    used_auto = getattr(input_config, "used_auto_discovery", False)
    if used_auto and sourcetypes:
        # One combined + one per sourcetype, converter-style layout
        content_combined = _build_spl2_content(kb_pairs, sourcetypes, catchall_sourcetypes, source_patterns)
        header_combined = _build_noisereduce_header(input_config, display_sourcetypes, include_disclaimer=True)
        annotation_combined = _build_noisereduce_annotation(input_config, sourcetypes, display_sourcetypes)
        content_combined = _prepend_header(content_combined, header_combined, annotation_combined)
        combined_dir = os.path.join(SPL2_CONTENT_FOLDER, COMBINED_SLUG)
        os.makedirs(combined_dir, exist_ok=True)
        combined_path = os.path.join(combined_dir, NOISEREDUCE_FILE_NAME.format(slug=COMBINED_SLUG))
        with open(combined_path, "w") as f:
            f.write(content_combined)
        logger.info("FILEINFO: SPL2 combined template: %s", combined_path)

        for st in sourcetypes:
            slug = input_config.get_slug_for_sourcetype(st)
            st_pairs = _get_pairs_for_sourcetype(kb_pairs, st) if kb_pairs else {}
            st_source_patterns = {st: source_patterns[st]} if st in source_patterns else {}
            content_single = _build_spl2_content(st_pairs, [st], None, st_source_patterns)
            header_single = _build_noisereduce_header(input_config, [st], include_disclaimer=True)
            annotation_single = _build_noisereduce_annotation(input_config, [st])
            content_single = _prepend_header(content_single, header_single, annotation_single)
            st_dir = os.path.join(SPL2_CONTENT_FOLDER, slug)
            os.makedirs(st_dir, exist_ok=True)
            st_path = os.path.join(st_dir, NOISEREDUCE_FILE_NAME.format(slug=slug))
            with open(st_path, "w") as f:
                f.write(content_single)
            logger.info("FILEINFO: SPL2 template for %s: %s", st, st_path)
    else:
        content = _build_spl2_content(kb_pairs, sourcetypes, catchall_sourcetypes, source_patterns)
        header_sourcetypes = (input_config.get_input_sourcetypes() if input_config else None) or display_sourcetypes
        header = _build_noisereduce_header(
            input_config, header_sourcetypes, include_disclaimer=True, all_sourcetypes=display_sourcetypes
        )
        annotation = _build_noisereduce_annotation(input_config, header_sourcetypes, display_sourcetypes)
        content = _prepend_header(content, header, annotation)
        out_path = get_combined_knowledge_base_provider_spl2_file(name_sourcetypes)
        out_dir = os.path.dirname(out_path)
        if out_dir:
            with contextlib.suppress(PermissionError, OSError):
                os.makedirs(out_dir, exist_ok=True)
        with open(out_path, "w") as f:
            f.write(content)
        logger.info("FILEINFO: SPL2 file for sourcetypes %s : %s", display_sourcetypes, out_path)


def calculate_last_route_case_for_multiple_sources(kb_pairs, sourcetype=None):
    """
    Compute the route line for events whose source matches the base source
    but not any specific sub-source (e.g. source=WinEventLog but not WinEventLog:Security).

    Returns:
        tuple[str, str]: (base_source, route_line).
    """
    sources = [v[1].replace("source::", "") for v in kb_pairs]
    if not sources:
        raise ValueError("Can't calculate base source from empty kb_pairs")
    try:
        base_source = sources[0].split(":")[0]
    except Exception as e:
        raise ValueError(f"Can't calculate base source from {sources!r}") from e
    if not base_source:
        raise ValueError(f"Empty base_source from {sources!r}")
    fn_name = (
        get_knowledge_base_provider_function_name(sourcetype=sourcetype)
        if sourcetype is not None
        else f"noise_reduction_knowledgebase_{get_spl2_safe_sourcetype_name(base_source)}"
    )
    base_regex = _to_spl2_regex(base_source)
    base_regex_with_colon = _to_spl2_regex(base_source + ":")
    route_line = (
        f"| route match(source, /{base_regex}/) and not match(source, /{base_regex_with_colon}/), "
        f"[ | eval _raw=noisereduce({fn_name}(), _raw) | into $destination ]"
    )
    return base_source, route_line


def create_spl2_content_for_source_sourcetype_pairs(kb_pairs):
    """Backward compatibility: generate combined SPL2 for source+sourcetype pairs."""
    create_spl2_content(None, kb_pairs)


if __name__ == "__main__":
    import sys

    from conf_spl2_converter.knowledge_builder.knowledge_base.nr_knowledge_base_creator import create_knowledge_base

    if len(sys.argv) < 2:
        print("Usage: python -m ... <ta_path> [config_file]", file=sys.stderr)
        sys.exit(1)
    ta_path = sys.argv[1]
    config_file = sys.argv[2] if len(sys.argv) > 2 else None
    input_config = InputConfig(ta_path, config_file)
    _, kb_pairs = create_knowledge_base(input_config)
    create_spl2_content(input_config, kb_pairs)
