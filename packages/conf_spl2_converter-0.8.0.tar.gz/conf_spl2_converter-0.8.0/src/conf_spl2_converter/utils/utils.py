# Conf To Spl2 Converter
# Copyright (C) 2026 Splunk Inc. All Rights Reserved.
#
# Installation and use subject to the Splunk General Terms,
# see https://www.splunk.com/en_us/legal/splunk-general-terms.html


"""Utility functions for the converter."""

import re
from pathlib import Path

# Path to language templates
_LANGUAGE_TEMPLATES_DIR = Path(__file__).parent.parent / "converter" / "input" / "language_templates"

# Cache template file contents to avoid repeated disk I/O
_template_cache: dict[str, str] = {}


def _load_template(name: str) -> str:
    """Load a language template file by name (cached)."""
    if name not in _template_cache:
        _template_cache[name] = (_LANGUAGE_TEMPLATES_DIR / name).read_text()
    return _template_cache[name]


def load_kv_extraction_template() -> str:
    """Load the KV extraction template."""
    return _load_template("kv_extraction")


def load_trim_fields_template() -> str:
    """Load the trim fields template."""
    return _load_template("trim_fields")


def load_convert_string_to_array_template() -> str:
    """Load the convert-string-to-array template."""
    return _load_template("convert_string_to_array")


def load_remove_duplicate_fields_template() -> str:
    """Load the remove-duplicate-fields template."""
    return _load_template("remove_duplicate_fields")


def sluggify_string(value: str) -> str:
    """Convert a string to a slug (lowercase, underscores for non-alphanumeric)."""
    return re.sub(r"[^a-zA-Z0-9]", "_", value).lower()
