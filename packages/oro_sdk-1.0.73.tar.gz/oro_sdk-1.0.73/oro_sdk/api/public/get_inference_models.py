from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.inference_models_response import InferenceModelsResponse
from ...models.ranked_inference_models_response import RankedInferenceModelsResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    provider: str | Unset = "chutes",
    ranked: bool | Unset = False,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["provider"] = provider

    params["ranked"] = ranked

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/public/inference/models",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | InferenceModelsResponse | RankedInferenceModelsResponse | None:
    if response.status_code == 200:

        def _parse_response_200(data: object) -> InferenceModelsResponse | RankedInferenceModelsResponse:
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                response_200_type_0 = InferenceModelsResponse.from_dict(data)

                return response_200_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            if not isinstance(data, dict):
                raise TypeError()
            response_200_type_1 = RankedInferenceModelsResponse.from_dict(data)

            return response_200_type_1

        response_200 = _parse_response_200(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | InferenceModelsResponse | RankedInferenceModelsResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: str | Unset = "chutes",
    ranked: bool | Unset = False,
) -> Response[HTTPValidationError | InferenceModelsResponse | RankedInferenceModelsResponse]:
    """List allowed inference models

     Returns the models available to ORO agents via the inference proxy. Defaults to a flat array of
    model IDs (provider's static allowlist). Set ``?ranked=true`` to receive models in load-/health-
    sorted order with per-model stats from the most recent provider poll.

    Args:
        provider (str | Unset):  Default: 'chutes'.
        ranked (bool | Unset):  Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | InferenceModelsResponse | RankedInferenceModelsResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        ranked=ranked,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    provider: str | Unset = "chutes",
    ranked: bool | Unset = False,
) -> HTTPValidationError | InferenceModelsResponse | RankedInferenceModelsResponse | None:
    """List allowed inference models

     Returns the models available to ORO agents via the inference proxy. Defaults to a flat array of
    model IDs (provider's static allowlist). Set ``?ranked=true`` to receive models in load-/health-
    sorted order with per-model stats from the most recent provider poll.

    Args:
        provider (str | Unset):  Default: 'chutes'.
        ranked (bool | Unset):  Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | InferenceModelsResponse | RankedInferenceModelsResponse
    """

    return sync_detailed(
        client=client,
        provider=provider,
        ranked=ranked,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: str | Unset = "chutes",
    ranked: bool | Unset = False,
) -> Response[HTTPValidationError | InferenceModelsResponse | RankedInferenceModelsResponse]:
    """List allowed inference models

     Returns the models available to ORO agents via the inference proxy. Defaults to a flat array of
    model IDs (provider's static allowlist). Set ``?ranked=true`` to receive models in load-/health-
    sorted order with per-model stats from the most recent provider poll.

    Args:
        provider (str | Unset):  Default: 'chutes'.
        ranked (bool | Unset):  Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | InferenceModelsResponse | RankedInferenceModelsResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        ranked=ranked,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    provider: str | Unset = "chutes",
    ranked: bool | Unset = False,
) -> HTTPValidationError | InferenceModelsResponse | RankedInferenceModelsResponse | None:
    """List allowed inference models

     Returns the models available to ORO agents via the inference proxy. Defaults to a flat array of
    model IDs (provider's static allowlist). Set ``?ranked=true`` to receive models in load-/health-
    sorted order with per-model stats from the most recent provider poll.

    Args:
        provider (str | Unset):  Default: 'chutes'.
        ranked (bool | Unset):  Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | InferenceModelsResponse | RankedInferenceModelsResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            provider=provider,
            ranked=ranked,
        )
    ).parsed
