from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.store_inference_credential_request import StoreInferenceCredentialRequest
from ...models.store_inference_credential_response_store_inference_credential import (
    StoreInferenceCredentialResponseStoreInferenceCredential,
)
from ...types import Response


def _get_kwargs(
    provider: str,
    *,
    body: StoreInferenceCredentialRequest,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/miner/inference-auth/{provider}".format(
            provider=quote(str(provider), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | StoreInferenceCredentialResponseStoreInferenceCredential | None:
    if response.status_code == 200:
        response_200 = StoreInferenceCredentialResponseStoreInferenceCredential.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | StoreInferenceCredentialResponseStoreInferenceCredential]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    provider: str,
    *,
    client: AuthenticatedClient | Client,
    body: StoreInferenceCredentialRequest,
) -> Response[HTTPValidationError | StoreInferenceCredentialResponseStoreInferenceCredential]:
    """Store an inference-provider credential

     Store (or overwrite) the miner's credential for the given provider.

    Validates the credential before persisting so bad input fails here rather
    than at first claim_work. The first stored provider becomes the miner's
    default; switching default afterward goes through the dedicated PATCH
    endpoint.

    Args:
        provider (str):
        body (StoreInferenceCredentialRequest): Request body for ``POST /v1/miner/inference-
            auth/{provider}``.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | StoreInferenceCredentialResponseStoreInferenceCredential]
    """

    kwargs = _get_kwargs(
        provider=provider,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    provider: str,
    *,
    client: AuthenticatedClient | Client,
    body: StoreInferenceCredentialRequest,
) -> HTTPValidationError | StoreInferenceCredentialResponseStoreInferenceCredential | None:
    """Store an inference-provider credential

     Store (or overwrite) the miner's credential for the given provider.

    Validates the credential before persisting so bad input fails here rather
    than at first claim_work. The first stored provider becomes the miner's
    default; switching default afterward goes through the dedicated PATCH
    endpoint.

    Args:
        provider (str):
        body (StoreInferenceCredentialRequest): Request body for ``POST /v1/miner/inference-
            auth/{provider}``.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | StoreInferenceCredentialResponseStoreInferenceCredential
    """

    return sync_detailed(
        provider=provider,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    provider: str,
    *,
    client: AuthenticatedClient | Client,
    body: StoreInferenceCredentialRequest,
) -> Response[HTTPValidationError | StoreInferenceCredentialResponseStoreInferenceCredential]:
    """Store an inference-provider credential

     Store (or overwrite) the miner's credential for the given provider.

    Validates the credential before persisting so bad input fails here rather
    than at first claim_work. The first stored provider becomes the miner's
    default; switching default afterward goes through the dedicated PATCH
    endpoint.

    Args:
        provider (str):
        body (StoreInferenceCredentialRequest): Request body for ``POST /v1/miner/inference-
            auth/{provider}``.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | StoreInferenceCredentialResponseStoreInferenceCredential]
    """

    kwargs = _get_kwargs(
        provider=provider,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    provider: str,
    *,
    client: AuthenticatedClient | Client,
    body: StoreInferenceCredentialRequest,
) -> HTTPValidationError | StoreInferenceCredentialResponseStoreInferenceCredential | None:
    """Store an inference-provider credential

     Store (or overwrite) the miner's credential for the given provider.

    Validates the credential before persisting so bad input fails here rather
    than at first claim_work. The first stored provider becomes the miner's
    default; switching default afterward goes through the dedicated PATCH
    endpoint.

    Args:
        provider (str):
        body (StoreInferenceCredentialRequest): Request body for ``POST /v1/miner/inference-
            auth/{provider}``.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | StoreInferenceCredentialResponseStoreInferenceCredential
    """

    return (
        await asyncio_detailed(
            provider=provider,
            client=client,
            body=body,
        )
    ).parsed
