from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.delete_inference_credential_response_delete_inference_credential import (
    DeleteInferenceCredentialResponseDeleteInferenceCredential,
)
from ...models.http_validation_error import HTTPValidationError
from ...types import Response


def _get_kwargs(
    provider: str,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "delete",
        "url": "/v1/miner/inference-auth/{provider}".format(
            provider=quote(str(provider), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> DeleteInferenceCredentialResponseDeleteInferenceCredential | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = DeleteInferenceCredentialResponseDeleteInferenceCredential.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[DeleteInferenceCredentialResponseDeleteInferenceCredential | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    provider: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[DeleteInferenceCredentialResponseDeleteInferenceCredential | HTTPValidationError]:
    """Disconnect an inference-provider credential

     Delete the miner's stored credential for the given provider.

    If the deleted provider was the miner's default, the default falls back
    to whichever other provider is still connected, or clears to NULL when
    none remain. Returns the new default so the client can update without a
    follow-up GET.

    Args:
        provider (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeleteInferenceCredentialResponseDeleteInferenceCredential | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        provider=provider,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    provider: str,
    *,
    client: AuthenticatedClient | Client,
) -> DeleteInferenceCredentialResponseDeleteInferenceCredential | HTTPValidationError | None:
    """Disconnect an inference-provider credential

     Delete the miner's stored credential for the given provider.

    If the deleted provider was the miner's default, the default falls back
    to whichever other provider is still connected, or clears to NULL when
    none remain. Returns the new default so the client can update without a
    follow-up GET.

    Args:
        provider (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeleteInferenceCredentialResponseDeleteInferenceCredential | HTTPValidationError
    """

    return sync_detailed(
        provider=provider,
        client=client,
    ).parsed


async def asyncio_detailed(
    provider: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[DeleteInferenceCredentialResponseDeleteInferenceCredential | HTTPValidationError]:
    """Disconnect an inference-provider credential

     Delete the miner's stored credential for the given provider.

    If the deleted provider was the miner's default, the default falls back
    to whichever other provider is still connected, or clears to NULL when
    none remain. Returns the new default so the client can update without a
    follow-up GET.

    Args:
        provider (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeleteInferenceCredentialResponseDeleteInferenceCredential | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        provider=provider,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    provider: str,
    *,
    client: AuthenticatedClient | Client,
) -> DeleteInferenceCredentialResponseDeleteInferenceCredential | HTTPValidationError | None:
    """Disconnect an inference-provider credential

     Delete the miner's stored credential for the given provider.

    If the deleted provider was the miner's default, the default falls back
    to whichever other provider is still connected, or clears to NULL when
    none remain. Returns the new default so the client can update without a
    follow-up GET.

    Args:
        provider (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeleteInferenceCredentialResponseDeleteInferenceCredential | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            provider=provider,
            client=client,
        )
    ).parsed
