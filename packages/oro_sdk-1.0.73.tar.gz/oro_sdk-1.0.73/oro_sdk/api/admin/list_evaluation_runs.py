import datetime
from http import HTTPStatus
from typing import Any
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.admin_evaluation_runs_response import AdminEvaluationRunsResponse
from ...models.evaluation_phase import EvaluationPhase
from ...models.evaluation_run_status import EvaluationRunStatus
from ...models.http_validation_error import HTTPValidationError
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    status: EvaluationRunStatus | None | Unset = UNSET,
    agent_version_id: None | Unset | UUID = UNSET,
    validator_hotkey: None | str | Unset = UNSET,
    phase: EvaluationPhase | None | Unset = UNSET,
    race_id: None | Unset | UUID = UNSET,
    eval_work_item_id: None | Unset | UUID = UNSET,
    inference_provider: None | str | Unset = UNSET,
    since: datetime.datetime | None | Unset = UNSET,
    until: datetime.datetime | None | Unset = UNSET,
    limit: int | Unset = 50,
    offset: int | Unset = 0,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_status: None | str | Unset
    if isinstance(status, Unset):
        json_status = UNSET
    elif isinstance(status, EvaluationRunStatus):
        json_status = status.value
    else:
        json_status = status
    params["status"] = json_status

    json_agent_version_id: None | str | Unset
    if isinstance(agent_version_id, Unset):
        json_agent_version_id = UNSET
    elif isinstance(agent_version_id, UUID):
        json_agent_version_id = str(agent_version_id)
    else:
        json_agent_version_id = agent_version_id
    params["agent_version_id"] = json_agent_version_id

    json_validator_hotkey: None | str | Unset
    if isinstance(validator_hotkey, Unset):
        json_validator_hotkey = UNSET
    else:
        json_validator_hotkey = validator_hotkey
    params["validator_hotkey"] = json_validator_hotkey

    json_phase: None | str | Unset
    if isinstance(phase, Unset):
        json_phase = UNSET
    elif isinstance(phase, EvaluationPhase):
        json_phase = phase.value
    else:
        json_phase = phase
    params["phase"] = json_phase

    json_race_id: None | str | Unset
    if isinstance(race_id, Unset):
        json_race_id = UNSET
    elif isinstance(race_id, UUID):
        json_race_id = str(race_id)
    else:
        json_race_id = race_id
    params["race_id"] = json_race_id

    json_eval_work_item_id: None | str | Unset
    if isinstance(eval_work_item_id, Unset):
        json_eval_work_item_id = UNSET
    elif isinstance(eval_work_item_id, UUID):
        json_eval_work_item_id = str(eval_work_item_id)
    else:
        json_eval_work_item_id = eval_work_item_id
    params["eval_work_item_id"] = json_eval_work_item_id

    json_inference_provider: None | str | Unset
    if isinstance(inference_provider, Unset):
        json_inference_provider = UNSET
    else:
        json_inference_provider = inference_provider
    params["inference_provider"] = json_inference_provider

    json_since: None | str | Unset
    if isinstance(since, Unset):
        json_since = UNSET
    elif isinstance(since, datetime.datetime):
        json_since = since.isoformat()
    else:
        json_since = since
    params["since"] = json_since

    json_until: None | str | Unset
    if isinstance(until, Unset):
        json_until = UNSET
    elif isinstance(until, datetime.datetime):
        json_until = until.isoformat()
    else:
        json_until = until
    params["until"] = json_until

    params["limit"] = limit

    params["offset"] = offset

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/admin/evaluation-runs",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> AdminEvaluationRunsResponse | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = AdminEvaluationRunsResponse.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[AdminEvaluationRunsResponse | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    status: EvaluationRunStatus | None | Unset = UNSET,
    agent_version_id: None | Unset | UUID = UNSET,
    validator_hotkey: None | str | Unset = UNSET,
    phase: EvaluationPhase | None | Unset = UNSET,
    race_id: None | Unset | UUID = UNSET,
    eval_work_item_id: None | Unset | UUID = UNSET,
    inference_provider: None | str | Unset = UNSET,
    since: datetime.datetime | None | Unset = UNSET,
    until: datetime.datetime | None | Unset = UNSET,
    limit: int | Unset = 50,
    offset: int | Unset = 0,
) -> Response[AdminEvaluationRunsResponse | HTTPValidationError]:
    """List evaluation runs with full details

     List evaluation runs with optional filtering and pagination.

    Args:
        status (EvaluationRunStatus | None | Unset): Filter by run status (e.g., RUNNING, SUCCESS)
        agent_version_id (None | Unset | UUID): Filter by agent version ID
        validator_hotkey (None | str | Unset): Filter by validator hotkey
        phase (EvaluationPhase | None | Unset): Filter by evaluation phase (QUALIFYING or RACE)
        race_id (None | Unset | UUID): Filter by race ID (RACE-phase runs only)
        eval_work_item_id (None | Unset | UUID): Filter to runs for a specific work item
        inference_provider (None | str | Unset): Filter by inference provider (e.g. chutes,
            openrouter). Pass 'none' to filter to runs with no provider recorded.
        since (datetime.datetime | None | Unset): Filter: created at or after (ISO 8601)
        until (datetime.datetime | None | Unset): Filter: created at or before (ISO 8601)
        limit (int | Unset): Number of runs to return Default: 50.
        offset (int | Unset): Offset for pagination Default: 0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AdminEvaluationRunsResponse | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        status=status,
        agent_version_id=agent_version_id,
        validator_hotkey=validator_hotkey,
        phase=phase,
        race_id=race_id,
        eval_work_item_id=eval_work_item_id,
        inference_provider=inference_provider,
        since=since,
        until=until,
        limit=limit,
        offset=offset,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    status: EvaluationRunStatus | None | Unset = UNSET,
    agent_version_id: None | Unset | UUID = UNSET,
    validator_hotkey: None | str | Unset = UNSET,
    phase: EvaluationPhase | None | Unset = UNSET,
    race_id: None | Unset | UUID = UNSET,
    eval_work_item_id: None | Unset | UUID = UNSET,
    inference_provider: None | str | Unset = UNSET,
    since: datetime.datetime | None | Unset = UNSET,
    until: datetime.datetime | None | Unset = UNSET,
    limit: int | Unset = 50,
    offset: int | Unset = 0,
) -> AdminEvaluationRunsResponse | HTTPValidationError | None:
    """List evaluation runs with full details

     List evaluation runs with optional filtering and pagination.

    Args:
        status (EvaluationRunStatus | None | Unset): Filter by run status (e.g., RUNNING, SUCCESS)
        agent_version_id (None | Unset | UUID): Filter by agent version ID
        validator_hotkey (None | str | Unset): Filter by validator hotkey
        phase (EvaluationPhase | None | Unset): Filter by evaluation phase (QUALIFYING or RACE)
        race_id (None | Unset | UUID): Filter by race ID (RACE-phase runs only)
        eval_work_item_id (None | Unset | UUID): Filter to runs for a specific work item
        inference_provider (None | str | Unset): Filter by inference provider (e.g. chutes,
            openrouter). Pass 'none' to filter to runs with no provider recorded.
        since (datetime.datetime | None | Unset): Filter: created at or after (ISO 8601)
        until (datetime.datetime | None | Unset): Filter: created at or before (ISO 8601)
        limit (int | Unset): Number of runs to return Default: 50.
        offset (int | Unset): Offset for pagination Default: 0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AdminEvaluationRunsResponse | HTTPValidationError
    """

    return sync_detailed(
        client=client,
        status=status,
        agent_version_id=agent_version_id,
        validator_hotkey=validator_hotkey,
        phase=phase,
        race_id=race_id,
        eval_work_item_id=eval_work_item_id,
        inference_provider=inference_provider,
        since=since,
        until=until,
        limit=limit,
        offset=offset,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    status: EvaluationRunStatus | None | Unset = UNSET,
    agent_version_id: None | Unset | UUID = UNSET,
    validator_hotkey: None | str | Unset = UNSET,
    phase: EvaluationPhase | None | Unset = UNSET,
    race_id: None | Unset | UUID = UNSET,
    eval_work_item_id: None | Unset | UUID = UNSET,
    inference_provider: None | str | Unset = UNSET,
    since: datetime.datetime | None | Unset = UNSET,
    until: datetime.datetime | None | Unset = UNSET,
    limit: int | Unset = 50,
    offset: int | Unset = 0,
) -> Response[AdminEvaluationRunsResponse | HTTPValidationError]:
    """List evaluation runs with full details

     List evaluation runs with optional filtering and pagination.

    Args:
        status (EvaluationRunStatus | None | Unset): Filter by run status (e.g., RUNNING, SUCCESS)
        agent_version_id (None | Unset | UUID): Filter by agent version ID
        validator_hotkey (None | str | Unset): Filter by validator hotkey
        phase (EvaluationPhase | None | Unset): Filter by evaluation phase (QUALIFYING or RACE)
        race_id (None | Unset | UUID): Filter by race ID (RACE-phase runs only)
        eval_work_item_id (None | Unset | UUID): Filter to runs for a specific work item
        inference_provider (None | str | Unset): Filter by inference provider (e.g. chutes,
            openrouter). Pass 'none' to filter to runs with no provider recorded.
        since (datetime.datetime | None | Unset): Filter: created at or after (ISO 8601)
        until (datetime.datetime | None | Unset): Filter: created at or before (ISO 8601)
        limit (int | Unset): Number of runs to return Default: 50.
        offset (int | Unset): Offset for pagination Default: 0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AdminEvaluationRunsResponse | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        status=status,
        agent_version_id=agent_version_id,
        validator_hotkey=validator_hotkey,
        phase=phase,
        race_id=race_id,
        eval_work_item_id=eval_work_item_id,
        inference_provider=inference_provider,
        since=since,
        until=until,
        limit=limit,
        offset=offset,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    status: EvaluationRunStatus | None | Unset = UNSET,
    agent_version_id: None | Unset | UUID = UNSET,
    validator_hotkey: None | str | Unset = UNSET,
    phase: EvaluationPhase | None | Unset = UNSET,
    race_id: None | Unset | UUID = UNSET,
    eval_work_item_id: None | Unset | UUID = UNSET,
    inference_provider: None | str | Unset = UNSET,
    since: datetime.datetime | None | Unset = UNSET,
    until: datetime.datetime | None | Unset = UNSET,
    limit: int | Unset = 50,
    offset: int | Unset = 0,
) -> AdminEvaluationRunsResponse | HTTPValidationError | None:
    """List evaluation runs with full details

     List evaluation runs with optional filtering and pagination.

    Args:
        status (EvaluationRunStatus | None | Unset): Filter by run status (e.g., RUNNING, SUCCESS)
        agent_version_id (None | Unset | UUID): Filter by agent version ID
        validator_hotkey (None | str | Unset): Filter by validator hotkey
        phase (EvaluationPhase | None | Unset): Filter by evaluation phase (QUALIFYING or RACE)
        race_id (None | Unset | UUID): Filter by race ID (RACE-phase runs only)
        eval_work_item_id (None | Unset | UUID): Filter to runs for a specific work item
        inference_provider (None | str | Unset): Filter by inference provider (e.g. chutes,
            openrouter). Pass 'none' to filter to runs with no provider recorded.
        since (datetime.datetime | None | Unset): Filter: created at or after (ISO 8601)
        until (datetime.datetime | None | Unset): Filter: created at or before (ISO 8601)
        limit (int | Unset): Number of runs to return Default: 50.
        offset (int | Unset): Offset for pagination Default: 0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AdminEvaluationRunsResponse | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            client=client,
            status=status,
            agent_version_id=agent_version_id,
            validator_hotkey=validator_hotkey,
            phase=phase,
            race_id=race_id,
            eval_work_item_id=eval_work_item_id,
            inference_provider=inference_provider,
            since=since,
            until=until,
            limit=limit,
            offset=offset,
        )
    ).parsed
