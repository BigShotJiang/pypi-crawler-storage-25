from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.validator_pause_request import ValidatorPauseRequest
from ...models.validator_pause_status import ValidatorPauseStatus
from ...types import Response


def _get_kwargs(
    *,
    body: ValidatorPauseRequest,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/admin/validator-pause",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | ValidatorPauseStatus | None:
    if response.status_code == 200:
        response_200 = ValidatorPauseStatus.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | ValidatorPauseStatus]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: ValidatorPauseRequest,
) -> Response[HTTPValidationError | ValidatorPauseStatus]:
    """Pause validator claims (pull the andon cord)

     Block all validators from claiming new evaluations. In-flight runs continue and report normally.
    Idempotent — calling twice overwrites the prior pause metadata.

    Args:
        body (ValidatorPauseRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | ValidatorPauseStatus]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: ValidatorPauseRequest,
) -> HTTPValidationError | ValidatorPauseStatus | None:
    """Pause validator claims (pull the andon cord)

     Block all validators from claiming new evaluations. In-flight runs continue and report normally.
    Idempotent — calling twice overwrites the prior pause metadata.

    Args:
        body (ValidatorPauseRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | ValidatorPauseStatus
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: ValidatorPauseRequest,
) -> Response[HTTPValidationError | ValidatorPauseStatus]:
    """Pause validator claims (pull the andon cord)

     Block all validators from claiming new evaluations. In-flight runs continue and report normally.
    Idempotent — calling twice overwrites the prior pause metadata.

    Args:
        body (ValidatorPauseRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | ValidatorPauseStatus]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: ValidatorPauseRequest,
) -> HTTPValidationError | ValidatorPauseStatus | None:
    """Pause validator claims (pull the andon cord)

     Block all validators from claiming new evaluations. In-flight runs continue and report normally.
    Idempotent — calling twice overwrites the prior pause metadata.

    Args:
        body (ValidatorPauseRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | ValidatorPauseStatus
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
