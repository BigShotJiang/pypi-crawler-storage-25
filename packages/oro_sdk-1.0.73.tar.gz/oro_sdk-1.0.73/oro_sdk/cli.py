"""CLI for ORO SDK — submit agents, manage inference auth, and pick race versions.

Usage:
    oro submit --agent-name "my-agent" --agent-file agent.py
    oro inference connect openrouter --api-key sk-or-v1-...
    oro inference connect chutes                 # interactive OAuth
    oro inference status                          # list connected providers + default
    oro inference set-default openrouter|chutes
    oro inference disconnect openrouter|chutes
    oro pin --agent-version-id <uuid>     # lock a specific version into the next race
    oro unpin                              # clear the lock; auto-pick takes over
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path
from uuid import UUID

DEFAULT_BASE_URL = "https://api.oroagents.com"


def _add_wallet_args(parser: argparse.ArgumentParser) -> None:
    """Common wallet + base-url args shared across subcommands."""
    parser.add_argument(
        "--wallet-name",
        default="default",
        help="Bittensor wallet name (default: 'default')",
    )
    parser.add_argument(
        "--wallet-hotkey",
        default="default",
        help="Bittensor hotkey name (default: 'default')",
    )
    parser.add_argument(
        "--base-url",
        default=os.environ.get("ORO_API_URL", DEFAULT_BASE_URL),
        help=f"Backend API URL (default: $ORO_API_URL or {DEFAULT_BASE_URL})",
    )


def _load_wallet_and_client(args: argparse.Namespace):
    """Load the Bittensor wallet and an authenticated client.

    Returns (wallet, hotkey_address, BittensorAuthClient). Exits on failure.
    """
    try:
        from bittensor_wallet import Wallet
    except ImportError:
        print(
            "Error: bittensor-wallet is required.\nInstall it with: pip install oro-sdk[bittensor]",
            file=sys.stderr,
        )
        sys.exit(1)

    from .bittensor_auth import BittensorAuthClient

    try:
        wallet = Wallet(name=args.wallet_name, hotkey=args.wallet_hotkey)
        hotkey_address = wallet.hotkey.ss58_address
    except Exception as e:
        print(f"Error loading wallet '{args.wallet_name}': {e}", file=sys.stderr)
        print(
            "\nMake sure you have a Bittensor wallet set up:\n"
            "  btcli wallet new_coldkey --wallet.name default\n"
            "  btcli wallet new_hotkey --wallet.name default --wallet.hotkey default",
            file=sys.stderr,
        )
        sys.exit(1)

    client = BittensorAuthClient(base_url=args.base_url, wallet=wallet)
    return wallet, hotkey_address, client


def _exit_with_response_error(response) -> None:
    """Print a backend error response and exit 1."""
    try:
        body = json.loads(response.content)
        detail = body.get("detail") or body.get("reason") or body.get("message") or response.content.decode()
    except (ValueError, UnicodeDecodeError):
        detail = response.content.decode(errors="replace")
    print(f"Error (HTTP {response.status_code}): {detail}", file=sys.stderr)
    sys.exit(1)


def _submit(args: argparse.Namespace) -> None:
    """Handle the 'submit' subcommand."""
    from .api.miner import list_inference_auth, submit_agent
    from .models.body_submit_agent import BodySubmitAgent
    from .models.submit_agent_response import SubmitAgentResponse
    from .types import UNSET, File

    agent_file: Path = args.agent_file
    if not agent_file.exists():
        print(f"Error: Agent file not found: {agent_file}", file=sys.stderr)
        sys.exit(1)

    wallet, hotkey_address, client = _load_wallet_and_client(args)

    print(f"Wallet:  {wallet.name} ({hotkey_address})")
    print(f"Agent:   {args.agent_name}")
    print(f"File:    {agent_file} ({agent_file.stat().st_size:,} bytes)")
    print(f"Backend: {args.base_url}")
    print()

    # Confirm at least one inference provider is connected before submitting.
    # Validators mint per-run tokens against the miner's default provider at
    # claim time; submitting without any provider yields runs that fail mint
    # and waste a cooldown window.
    listing_resp = list_inference_auth.sync_detailed(client=client)
    listing = listing_resp.parsed
    if listing is None:
        _exit_with_response_error(listing_resp)
    providers = [p for p in (listing.providers or []) if p.connected]
    default_provider = (
        listing.default_provider
        if not isinstance(listing.default_provider, type(UNSET))
        else None
    )
    if not providers:
        print(
            "Error: No inference provider connected. "
            "Run `oro inference connect chutes` (interactive) or "
            "`oro inference connect openrouter --api-key sk-or-v1-...` "
            "before submitting.",
            file=sys.stderr,
        )
        sys.exit(1)

    connected_names = ", ".join(sorted(p.provider for p in providers))
    if default_provider:
        print(f"Inference: connected={connected_names}, default={default_provider}")
    else:
        print(f"Inference: connected={connected_names}")

    print()

    body = BodySubmitAgent(
        agent_name=args.agent_name,
        file=File(
            payload=agent_file.read_bytes(),
            file_name=agent_file.name,
            mime_type="text/x-python",
        ),
    )

    response = submit_agent.sync_detailed(client=client, body=body)
    result = response.parsed

    if isinstance(result, SubmitAgentResponse):
        print(f"Status:  {result.admission_status.value}")
        if not isinstance(result.agent_version_id, type(UNSET)) and result.agent_version_id:
            print(f"Version: {result.agent_version_id}")
        if not isinstance(result.message, type(UNSET)) and result.message:
            print(f"Message: {result.message}")
        if not isinstance(result.admission_reason, type(UNSET)) and result.admission_reason:
            print(f"Reason:  {result.admission_reason.value}")
        if not isinstance(result.next_allowed_at, type(UNSET)) and result.next_allowed_at:
            print(f"Next allowed at: {result.next_allowed_at}")
    elif result is not None:
        # Parsed error model from the SDK (400, 413, 422, 429, 503)
        detail = getattr(result, "detail", None) or getattr(result, "message", None) or str(result)
        print(f"Error: {detail}", file=sys.stderr)

        # Surface static analysis violations with line numbers
        violations = getattr(result, "violations", None)
        if violations and not isinstance(violations, type(UNSET)):
            print(file=sys.stderr)
            for v in violations:
                props = v.additional_properties if hasattr(v, "additional_properties") else v
                line = props.get("line")
                message = props.get("message", "unknown")
                rule = props.get("rule", "unknown")
                prefix = f"  Line {line}" if line else "  "
                print(f"{prefix}: {message} ({rule})", file=sys.stderr)

        sys.exit(1)
    else:
        _exit_with_response_error(response)


def _pin(args: argparse.Namespace) -> None:
    """Handle the 'pin' subcommand — lock a specific agent version into the next race.

    Without pinning, the miner's highest-scoring eligible version is auto-picked
    when the next race starts. Pinning overrides that choice for this miner.
    """
    from .api.miner import set_race_selection
    from .models.miner_race_selection_request import MinerRaceSelectionRequest

    try:
        agent_version_id = UUID(args.agent_version_id)
    except (ValueError, TypeError):
        print(
            f"Error: --agent-version-id must be a valid UUID, got: {args.agent_version_id!r}",
            file=sys.stderr,
        )
        sys.exit(1)

    wallet, hotkey_address, client = _load_wallet_and_client(args)

    print(f"Wallet:  {wallet.name} ({hotkey_address})")
    print(f"Version: {agent_version_id}")
    print(f"Backend: {args.base_url}")
    print()

    response = set_race_selection.sync_detailed(
        client=client,
        body=MinerRaceSelectionRequest(agent_version_id=agent_version_id),
    )
    if response.status_code.value == 204:
        print(f"Locked {agent_version_id} into the next race. Auto-pick is now disabled.")
        return
    _exit_with_response_error(response)


def _unpin(args: argparse.Namespace) -> None:
    """Handle the 'unpin' subcommand — release the lock so auto-pick takes over.

    After unpinning, the miner's highest-scoring eligible version is auto-picked
    when the next race starts.
    """
    from .api.miner import clear_race_selection

    wallet, hotkey_address, client = _load_wallet_and_client(args)

    print(f"Wallet:  {wallet.name} ({hotkey_address})")
    print(f"Backend: {args.base_url}")
    print()

    response = clear_race_selection.sync_detailed(client=client)
    if response.status_code.value == 204:
        print("Lock cleared. The next race will use your highest-scoring eligible version.")
        return
    _exit_with_response_error(response)


_INFERENCE_PROVIDERS = ("chutes", "openrouter")


def _print_inference_header(
    wallet_name: str, hotkey_address: str, base_url: str, provider: str | None = None
) -> None:
    print(f"Wallet:   {wallet_name} ({hotkey_address})")
    if provider:
        print(f"Provider: {provider}")
    print(f"Backend:  {base_url}")
    print()


def _exit_unless_ok(response, success_msg: str, *, ok_codes: tuple[int, ...] = (200, 204)) -> None:
    if response.status_code.value in ok_codes:
        print(success_msg)
        return
    _exit_with_response_error(response)


def _inference_connect(args: argparse.Namespace) -> None:
    """Connect a provider's credential to the miner's inference-auth.

    OpenRouter requires an explicit ``--api-key`` (a Management API key
    minted on OR's dashboard). Chutes always runs the interactive OAuth
    flow — there's no Chutes-side API key to paste.
    """
    from .api.miner import store_inference_credential
    from .chutes_auth import ChutesAuthError, start_auth_flow
    from .models.store_inference_credential_request import StoreInferenceCredentialRequest

    provider: str = args.provider
    credential: str | None = args.api_key

    if provider == "chutes" and credential:
        print(
            "Error: --api-key is not supported for chutes; the connect flow "
            "uses interactive OAuth.",
            file=sys.stderr,
        )
        sys.exit(1)
    if provider != "chutes" and not credential:
        print(
            f"Error: --api-key is required for {provider}.\n"
            "  For OpenRouter, mint a Management API key at "
            "https://openrouter.ai/settings/keys",
            file=sys.stderr,
        )
        sys.exit(1)

    # Load the wallet first so a misconfigured wallet doesn't waste a
    # completed OAuth flow.
    wallet, hotkey_address, client = _load_wallet_and_client(args)

    if provider == "chutes":
        try:
            tokens = start_auth_flow()
        except ChutesAuthError as e:
            print(f"Error: {e}", file=sys.stderr)
            sys.exit(1)
        credential = tokens.get("refresh_token")
        if not credential:
            print("Error: Chutes OAuth did not return a refresh token.", file=sys.stderr)
            sys.exit(1)

    _print_inference_header(wallet.name, hotkey_address, args.base_url, provider=provider)

    response = store_inference_credential.sync_detailed(
        client=client,
        provider=provider,
        body=StoreInferenceCredentialRequest(credential=credential),
    )
    _exit_unless_ok(response, f"Connected {provider}.", ok_codes=(200,))


def _inference_status(args: argparse.Namespace) -> None:
    """List connected providers and which is the default."""
    from .api.miner import list_inference_auth
    from .types import UNSET

    wallet, hotkey_address, client = _load_wallet_and_client(args)
    _print_inference_header(wallet.name, hotkey_address, args.base_url)

    response = list_inference_auth.sync_detailed(client=client)
    listing = response.parsed
    if listing is None:
        _exit_with_response_error(response)

    providers = listing.providers or []
    default_provider = (
        listing.default_provider
        if not isinstance(listing.default_provider, type(UNSET))
        else None
    )

    if not providers:
        print("No providers connected. Run `oro inference connect <provider>` first.")
        return

    print(f"{'Provider':<14} {'Connected':<10} {'Default':<8} {'Updated'}")
    print("─" * 60)
    for p in providers:
        is_default = "yes" if p.provider == default_provider else ""
        updated = (
            p.updated_at.isoformat()
            if p.updated_at and not isinstance(p.updated_at, type(UNSET))
            else ""
        )
        print(
            f"{p.provider:<14} {('yes' if p.connected else 'no'):<10} "
            f"{is_default:<8} {updated}"
        )


def _inference_set_default(args: argparse.Namespace) -> None:
    """Set the miner's default inference provider for new evaluations."""
    from .api.miner import set_default_inference_provider
    from .models.set_default_provider_request import SetDefaultProviderRequest

    wallet, hotkey_address, client = _load_wallet_and_client(args)
    _print_inference_header(wallet.name, hotkey_address, args.base_url, provider=args.provider)

    response = set_default_inference_provider.sync_detailed(
        client=client,
        body=SetDefaultProviderRequest(provider=args.provider),
    )
    _exit_unless_ok(
        response,
        f"Default provider set to {args.provider}. Applies to next claimed eval.",
    )


def _inference_disconnect(args: argparse.Namespace) -> None:
    """Remove a stored inference credential."""
    from .api.miner import delete_inference_credential

    wallet, hotkey_address, client = _load_wallet_and_client(args)
    _print_inference_header(wallet.name, hotkey_address, args.base_url, provider=args.provider)

    response = delete_inference_credential.sync_detailed(
        client=client, provider=args.provider
    )
    _exit_unless_ok(response, f"Disconnected {args.provider}.")


def _get_version() -> str:
    """Get the installed package version from metadata."""
    try:
        from importlib.metadata import version

        return version("oro-sdk")
    except Exception:
        return "unknown"


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="oro",
        description="ORO SDK CLI — tools for the ORO Bittensor Subnet",
    )
    parser.add_argument(
        "-v",
        "--version",
        action="version",
        version=f"oro-sdk {_get_version()}",
    )
    subparsers = parser.add_subparsers()

    # oro submit
    submit_parser = subparsers.add_parser(
        "submit",
        help="Submit an agent for evaluation",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""\
Examples:
    oro submit --agent-name "my-agent" --agent-file agent.py
    oro submit --wallet-name my-miner --agent-name "v2" --agent-file agent.py
    oro submit --base-url http://localhost:8000 --agent-name "test" --agent-file agent.py
""",
    )
    submit_parser.add_argument(
        "--agent-name",
        required=True,
        help="Name for the agent (unique per miner)",
    )
    submit_parser.add_argument(
        "--agent-file",
        required=True,
        type=Path,
        help="Path to the agent Python file",
    )
    _add_wallet_args(submit_parser)
    submit_parser.set_defaults(func=_submit)

    # oro inference {connect, status, set-default, disconnect}
    inference_parser = subparsers.add_parser(
        "inference",
        help="Manage inference-provider credentials (Chutes, OpenRouter)",
        description=(
            "Connect, list, and disconnect inference credentials, and choose which "
            "provider funds your evaluations. The default provider applies from your "
            "next claimed eval onward."
        ),
    )
    inf_subs = inference_parser.add_subparsers(required=True)

    connect_parser = inf_subs.add_parser(
        "connect",
        help="Connect a provider credential",
        description=(
            "Store a provider credential against your hotkey. OpenRouter requires "
            "--api-key (mint a Management API key at https://openrouter.ai/settings/keys). "
            "Chutes runs an interactive OAuth flow — no API key to paste."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""\
Examples:
    oro inference connect openrouter --api-key sk-or-v1-...
    oro inference connect chutes
""",
    )
    connect_parser.add_argument(
        "provider",
        choices=_INFERENCE_PROVIDERS,
        help="Provider to connect",
    )
    connect_parser.add_argument(
        "--api-key",
        help="Credential to store (openrouter only; chutes uses interactive OAuth)",
    )
    _add_wallet_args(connect_parser)
    connect_parser.set_defaults(func=_inference_connect)

    status_parser = inf_subs.add_parser(
        "status",
        help="List connected providers and the current default",
    )
    _add_wallet_args(status_parser)
    status_parser.set_defaults(func=_inference_status)

    setdefault_parser = inf_subs.add_parser(
        "set-default",
        help="Set the default inference provider for new evaluations",
    )
    setdefault_parser.add_argument(
        "provider",
        choices=_INFERENCE_PROVIDERS,
        help="Provider to set as default",
    )
    _add_wallet_args(setdefault_parser)
    setdefault_parser.set_defaults(func=_inference_set_default)

    disconnect_parser = inf_subs.add_parser(
        "disconnect",
        help="Remove a stored inference credential",
    )
    disconnect_parser.add_argument(
        "provider",
        choices=_INFERENCE_PROVIDERS,
        help="Provider to disconnect",
    )
    _add_wallet_args(disconnect_parser)
    disconnect_parser.set_defaults(func=_inference_disconnect)

    # oro pin
    pin_parser = subparsers.add_parser(
        "pin",
        help="Lock a specific agent version into the next race (overrides auto-pick)",
        description=(
            "Lock a specific agent version into the next race. "
            "By default, when a race starts, your highest-scoring eligible version is "
            "auto-picked. Pinning overrides that and forces the chosen version to race."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""\
Examples:
    oro pin --agent-version-id 12345678-1234-1234-1234-123456789012
    oro pin --agent-version-id <uuid> --wallet-name my-miner
""",
    )
    pin_parser.add_argument(
        "--agent-version-id",
        required=True,
        help="UUID of the agent version to lock into the next race",
    )
    _add_wallet_args(pin_parser)
    pin_parser.set_defaults(func=_pin)

    # oro unpin
    unpin_parser = subparsers.add_parser(
        "unpin",
        help="Release the race lock so auto-pick chooses your version",
        description=(
            "Release the race lock set by `oro pin`. After unpinning, the next race "
            "uses your highest-scoring eligible version (auto-pick)."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""\
Examples:
    oro unpin
    oro unpin --wallet-name my-miner
""",
    )
    _add_wallet_args(unpin_parser)
    unpin_parser.set_defaults(func=_unpin)

    args = parser.parse_args()

    if not getattr(args, "func", None):
        parser.print_help()
        sys.exit(1)

    args.func(args)


if __name__ == "__main__":
    main()
