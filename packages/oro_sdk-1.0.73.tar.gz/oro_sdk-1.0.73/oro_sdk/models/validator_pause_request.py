from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="ValidatorPauseRequest")


@_attrs_define
class ValidatorPauseRequest:
    """
    Attributes:
        reason (str): Reason for pulling the andon cord
        auto_release_at (datetime.datetime | None | Unset): UTC timestamp at which the pause auto-clears. Safety net so
            a pause can't be left on by accident.
    """

    reason: str
    auto_release_at: datetime.datetime | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        reason = self.reason

        auto_release_at: None | str | Unset
        if isinstance(self.auto_release_at, Unset):
            auto_release_at = UNSET
        elif isinstance(self.auto_release_at, datetime.datetime):
            auto_release_at = self.auto_release_at.isoformat()
        else:
            auto_release_at = self.auto_release_at

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "reason": reason,
            }
        )
        if auto_release_at is not UNSET:
            field_dict["auto_release_at"] = auto_release_at

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        reason = d.pop("reason")

        def _parse_auto_release_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                auto_release_at_type_0 = isoparse(data)

                return auto_release_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        auto_release_at = _parse_auto_release_at(d.pop("auto_release_at", UNSET))

        validator_pause_request = cls(
            reason=reason,
            auto_release_at=auto_release_at,
        )

        validator_pause_request.additional_properties = d
        return validator_pause_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
