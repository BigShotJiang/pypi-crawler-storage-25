from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="ValidatorPauseStatus")


@_attrs_define
class ValidatorPauseStatus:
    """
    Attributes:
        active (bool): True when validator claims are paused
        reason (None | str | Unset): Reason from the most recent pause
        paused_by (None | str | Unset): Admin hotkey that pulled the cord
        paused_at (datetime.datetime | None | Unset): When the cord was pulled
        auto_release_at (datetime.datetime | None | Unset): When the pause will auto-clear, if scheduled
    """

    active: bool
    reason: None | str | Unset = UNSET
    paused_by: None | str | Unset = UNSET
    paused_at: datetime.datetime | None | Unset = UNSET
    auto_release_at: datetime.datetime | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        active = self.active

        reason: None | str | Unset
        if isinstance(self.reason, Unset):
            reason = UNSET
        else:
            reason = self.reason

        paused_by: None | str | Unset
        if isinstance(self.paused_by, Unset):
            paused_by = UNSET
        else:
            paused_by = self.paused_by

        paused_at: None | str | Unset
        if isinstance(self.paused_at, Unset):
            paused_at = UNSET
        elif isinstance(self.paused_at, datetime.datetime):
            paused_at = self.paused_at.isoformat()
        else:
            paused_at = self.paused_at

        auto_release_at: None | str | Unset
        if isinstance(self.auto_release_at, Unset):
            auto_release_at = UNSET
        elif isinstance(self.auto_release_at, datetime.datetime):
            auto_release_at = self.auto_release_at.isoformat()
        else:
            auto_release_at = self.auto_release_at

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "active": active,
            }
        )
        if reason is not UNSET:
            field_dict["reason"] = reason
        if paused_by is not UNSET:
            field_dict["paused_by"] = paused_by
        if paused_at is not UNSET:
            field_dict["paused_at"] = paused_at
        if auto_release_at is not UNSET:
            field_dict["auto_release_at"] = auto_release_at

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        active = d.pop("active")

        def _parse_reason(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        reason = _parse_reason(d.pop("reason", UNSET))

        def _parse_paused_by(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        paused_by = _parse_paused_by(d.pop("paused_by", UNSET))

        def _parse_paused_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                paused_at_type_0 = isoparse(data)

                return paused_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        paused_at = _parse_paused_at(d.pop("paused_at", UNSET))

        def _parse_auto_release_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                auto_release_at_type_0 = isoparse(data)

                return auto_release_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        auto_release_at = _parse_auto_release_at(d.pop("auto_release_at", UNSET))

        validator_pause_status = cls(
            active=active,
            reason=reason,
            paused_by=paused_by,
            paused_at=paused_at,
            auto_release_at=auto_release_at,
        )

        validator_pause_status.additional_properties = d
        return validator_pause_status

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
