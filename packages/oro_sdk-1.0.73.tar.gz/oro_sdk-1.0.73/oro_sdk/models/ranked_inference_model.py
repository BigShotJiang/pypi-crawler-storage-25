from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.ranked_inference_model_rank_metric import RankedInferenceModelRankMetric


T = TypeVar("T", bound="RankedInferenceModel")


@_attrs_define
class RankedInferenceModel:
    """One row in a ranked inference-models response.

    ``rank_metric`` is provider-specific: Chutes returns rate-limit ratio +
    utilization + instance counts; OpenRouter returns uptime + latency +
    status.

        Attributes:
            id (str):
            rank_metric (RankedInferenceModelRankMetric | Unset):
            healthy (bool | Unset):  Default: True.
    """

    id: str
    rank_metric: RankedInferenceModelRankMetric | Unset = UNSET
    healthy: bool | Unset = True
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        rank_metric: dict[str, Any] | Unset = UNSET
        if not isinstance(self.rank_metric, Unset):
            rank_metric = self.rank_metric.to_dict()

        healthy = self.healthy

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
            }
        )
        if rank_metric is not UNSET:
            field_dict["rank_metric"] = rank_metric
        if healthy is not UNSET:
            field_dict["healthy"] = healthy

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.ranked_inference_model_rank_metric import RankedInferenceModelRankMetric

        d = dict(src_dict)
        id = d.pop("id")

        _rank_metric = d.pop("rank_metric", UNSET)
        rank_metric: RankedInferenceModelRankMetric | Unset
        if isinstance(_rank_metric, Unset):
            rank_metric = UNSET
        else:
            rank_metric = RankedInferenceModelRankMetric.from_dict(_rank_metric)

        healthy = d.pop("healthy", UNSET)

        ranked_inference_model = cls(
            id=id,
            rank_metric=rank_metric,
            healthy=healthy,
        )

        ranked_inference_model.additional_properties = d
        return ranked_inference_model

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
