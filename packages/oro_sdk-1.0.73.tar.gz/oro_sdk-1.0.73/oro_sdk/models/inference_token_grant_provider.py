from enum import Enum


class InferenceTokenGrantProvider(str, Enum):
    CHUTES = "chutes"
    OPENROUTER = "openrouter"

    def __str__(self) -> str:
        return str(self.value)
