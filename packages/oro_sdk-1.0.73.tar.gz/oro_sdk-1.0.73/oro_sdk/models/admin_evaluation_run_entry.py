from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="AdminEvaluationRunEntry")


@_attrs_define
class AdminEvaluationRunEntry:
    """
    Attributes:
        run_id (UUID): Evaluation run ID
        agent_version_id (UUID): Agent version being evaluated
        validator_hotkey (str): Validator performing the evaluation
        suite_id (int): Problem suite ID
        status (str): Current run status
        is_included (bool): Whether this run is included in scoring
        created_at (datetime.datetime): When the run was created
        claimed_at (datetime.datetime | None | Unset): When the run was claimed
        completed_at (datetime.datetime | None | Unset): When the run completed
        last_heartbeat_at (datetime.datetime | None | Unset): Last heartbeat from the validator
        lease_expires_at (datetime.datetime | None | Unset): When the lease expires
        score (float | None | Unset): Run score
        invalidated_at (datetime.datetime | None | Unset): When the run was invalidated
        invalidation_reason (None | str | Unset): Reason the run was invalidated
        failure_reason (None | str | Unset): Reason the run failed
        eval_work_item_id (None | Unset | UUID): Work item this run was created for
        phase (None | str | Unset): Evaluation phase (QUALIFYING or RACE) from the work item
        race_id (None | Unset | UUID): Race ID for RACE-phase runs
        race_number (int | None | Unset): Race number for RACE-phase runs
        inference_provider (None | str | Unset): Inference provider used for this run (e.g. chutes, openrouter)
    """

    run_id: UUID
    agent_version_id: UUID
    validator_hotkey: str
    suite_id: int
    status: str
    is_included: bool
    created_at: datetime.datetime
    claimed_at: datetime.datetime | None | Unset = UNSET
    completed_at: datetime.datetime | None | Unset = UNSET
    last_heartbeat_at: datetime.datetime | None | Unset = UNSET
    lease_expires_at: datetime.datetime | None | Unset = UNSET
    score: float | None | Unset = UNSET
    invalidated_at: datetime.datetime | None | Unset = UNSET
    invalidation_reason: None | str | Unset = UNSET
    failure_reason: None | str | Unset = UNSET
    eval_work_item_id: None | Unset | UUID = UNSET
    phase: None | str | Unset = UNSET
    race_id: None | Unset | UUID = UNSET
    race_number: int | None | Unset = UNSET
    inference_provider: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        run_id = str(self.run_id)

        agent_version_id = str(self.agent_version_id)

        validator_hotkey = self.validator_hotkey

        suite_id = self.suite_id

        status = self.status

        is_included = self.is_included

        created_at = self.created_at.isoformat()

        claimed_at: None | str | Unset
        if isinstance(self.claimed_at, Unset):
            claimed_at = UNSET
        elif isinstance(self.claimed_at, datetime.datetime):
            claimed_at = self.claimed_at.isoformat()
        else:
            claimed_at = self.claimed_at

        completed_at: None | str | Unset
        if isinstance(self.completed_at, Unset):
            completed_at = UNSET
        elif isinstance(self.completed_at, datetime.datetime):
            completed_at = self.completed_at.isoformat()
        else:
            completed_at = self.completed_at

        last_heartbeat_at: None | str | Unset
        if isinstance(self.last_heartbeat_at, Unset):
            last_heartbeat_at = UNSET
        elif isinstance(self.last_heartbeat_at, datetime.datetime):
            last_heartbeat_at = self.last_heartbeat_at.isoformat()
        else:
            last_heartbeat_at = self.last_heartbeat_at

        lease_expires_at: None | str | Unset
        if isinstance(self.lease_expires_at, Unset):
            lease_expires_at = UNSET
        elif isinstance(self.lease_expires_at, datetime.datetime):
            lease_expires_at = self.lease_expires_at.isoformat()
        else:
            lease_expires_at = self.lease_expires_at

        score: float | None | Unset
        if isinstance(self.score, Unset):
            score = UNSET
        else:
            score = self.score

        invalidated_at: None | str | Unset
        if isinstance(self.invalidated_at, Unset):
            invalidated_at = UNSET
        elif isinstance(self.invalidated_at, datetime.datetime):
            invalidated_at = self.invalidated_at.isoformat()
        else:
            invalidated_at = self.invalidated_at

        invalidation_reason: None | str | Unset
        if isinstance(self.invalidation_reason, Unset):
            invalidation_reason = UNSET
        else:
            invalidation_reason = self.invalidation_reason

        failure_reason: None | str | Unset
        if isinstance(self.failure_reason, Unset):
            failure_reason = UNSET
        else:
            failure_reason = self.failure_reason

        eval_work_item_id: None | str | Unset
        if isinstance(self.eval_work_item_id, Unset):
            eval_work_item_id = UNSET
        elif isinstance(self.eval_work_item_id, UUID):
            eval_work_item_id = str(self.eval_work_item_id)
        else:
            eval_work_item_id = self.eval_work_item_id

        phase: None | str | Unset
        if isinstance(self.phase, Unset):
            phase = UNSET
        else:
            phase = self.phase

        race_id: None | str | Unset
        if isinstance(self.race_id, Unset):
            race_id = UNSET
        elif isinstance(self.race_id, UUID):
            race_id = str(self.race_id)
        else:
            race_id = self.race_id

        race_number: int | None | Unset
        if isinstance(self.race_number, Unset):
            race_number = UNSET
        else:
            race_number = self.race_number

        inference_provider: None | str | Unset
        if isinstance(self.inference_provider, Unset):
            inference_provider = UNSET
        else:
            inference_provider = self.inference_provider

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "run_id": run_id,
                "agent_version_id": agent_version_id,
                "validator_hotkey": validator_hotkey,
                "suite_id": suite_id,
                "status": status,
                "is_included": is_included,
                "created_at": created_at,
            }
        )
        if claimed_at is not UNSET:
            field_dict["claimed_at"] = claimed_at
        if completed_at is not UNSET:
            field_dict["completed_at"] = completed_at
        if last_heartbeat_at is not UNSET:
            field_dict["last_heartbeat_at"] = last_heartbeat_at
        if lease_expires_at is not UNSET:
            field_dict["lease_expires_at"] = lease_expires_at
        if score is not UNSET:
            field_dict["score"] = score
        if invalidated_at is not UNSET:
            field_dict["invalidated_at"] = invalidated_at
        if invalidation_reason is not UNSET:
            field_dict["invalidation_reason"] = invalidation_reason
        if failure_reason is not UNSET:
            field_dict["failure_reason"] = failure_reason
        if eval_work_item_id is not UNSET:
            field_dict["eval_work_item_id"] = eval_work_item_id
        if phase is not UNSET:
            field_dict["phase"] = phase
        if race_id is not UNSET:
            field_dict["race_id"] = race_id
        if race_number is not UNSET:
            field_dict["race_number"] = race_number
        if inference_provider is not UNSET:
            field_dict["inference_provider"] = inference_provider

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        run_id = UUID(d.pop("run_id"))

        agent_version_id = UUID(d.pop("agent_version_id"))

        validator_hotkey = d.pop("validator_hotkey")

        suite_id = d.pop("suite_id")

        status = d.pop("status")

        is_included = d.pop("is_included")

        created_at = isoparse(d.pop("created_at"))

        def _parse_claimed_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                claimed_at_type_0 = isoparse(data)

                return claimed_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        claimed_at = _parse_claimed_at(d.pop("claimed_at", UNSET))

        def _parse_completed_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                completed_at_type_0 = isoparse(data)

                return completed_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        completed_at = _parse_completed_at(d.pop("completed_at", UNSET))

        def _parse_last_heartbeat_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                last_heartbeat_at_type_0 = isoparse(data)

                return last_heartbeat_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        last_heartbeat_at = _parse_last_heartbeat_at(d.pop("last_heartbeat_at", UNSET))

        def _parse_lease_expires_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                lease_expires_at_type_0 = isoparse(data)

                return lease_expires_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        lease_expires_at = _parse_lease_expires_at(d.pop("lease_expires_at", UNSET))

        def _parse_score(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        score = _parse_score(d.pop("score", UNSET))

        def _parse_invalidated_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                invalidated_at_type_0 = isoparse(data)

                return invalidated_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        invalidated_at = _parse_invalidated_at(d.pop("invalidated_at", UNSET))

        def _parse_invalidation_reason(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        invalidation_reason = _parse_invalidation_reason(d.pop("invalidation_reason", UNSET))

        def _parse_failure_reason(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        failure_reason = _parse_failure_reason(d.pop("failure_reason", UNSET))

        def _parse_eval_work_item_id(data: object) -> None | Unset | UUID:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                eval_work_item_id_type_0 = UUID(data)

                return eval_work_item_id_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UUID, data)

        eval_work_item_id = _parse_eval_work_item_id(d.pop("eval_work_item_id", UNSET))

        def _parse_phase(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        phase = _parse_phase(d.pop("phase", UNSET))

        def _parse_race_id(data: object) -> None | Unset | UUID:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                race_id_type_0 = UUID(data)

                return race_id_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UUID, data)

        race_id = _parse_race_id(d.pop("race_id", UNSET))

        def _parse_race_number(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        race_number = _parse_race_number(d.pop("race_number", UNSET))

        def _parse_inference_provider(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        inference_provider = _parse_inference_provider(d.pop("inference_provider", UNSET))

        admin_evaluation_run_entry = cls(
            run_id=run_id,
            agent_version_id=agent_version_id,
            validator_hotkey=validator_hotkey,
            suite_id=suite_id,
            status=status,
            is_included=is_included,
            created_at=created_at,
            claimed_at=claimed_at,
            completed_at=completed_at,
            last_heartbeat_at=last_heartbeat_at,
            lease_expires_at=lease_expires_at,
            score=score,
            invalidated_at=invalidated_at,
            invalidation_reason=invalidation_reason,
            failure_reason=failure_reason,
            eval_work_item_id=eval_work_item_id,
            phase=phase,
            race_id=race_id,
            race_number=race_number,
            inference_provider=inference_provider,
        )

        admin_evaluation_run_entry.additional_properties = d
        return admin_evaluation_run_entry

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
