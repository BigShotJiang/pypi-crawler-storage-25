from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.inference_token_grant_provider import InferenceTokenGrantProvider

T = TypeVar("T", bound="InferenceTokenGrant")


@_attrs_define
class InferenceTokenGrant:
    """Per-run scoped inference credential issued at claim_work.

    Attributes:
        provider (InferenceTokenGrantProvider): Provider that minted the token.
        access_token (str): Bearer credential the validator presents at base_url.
        base_url (str): Inference API base URL (OpenAI-compatible chat/completions).
        expires_at (datetime.datetime): UTC timestamp when this token stops being usable.
    """

    provider: InferenceTokenGrantProvider
    access_token: str
    base_url: str
    expires_at: datetime.datetime
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        provider = self.provider.value

        access_token = self.access_token

        base_url = self.base_url

        expires_at = self.expires_at.isoformat()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "provider": provider,
                "access_token": access_token,
                "base_url": base_url,
                "expires_at": expires_at,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        provider = InferenceTokenGrantProvider(d.pop("provider"))

        access_token = d.pop("access_token")

        base_url = d.pop("base_url")

        expires_at = isoparse(d.pop("expires_at"))

        inference_token_grant = cls(
            provider=provider,
            access_token=access_token,
            base_url=base_url,
            expires_at=expires_at,
        )

        inference_token_grant.additional_properties = d
        return inference_token_grant

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
