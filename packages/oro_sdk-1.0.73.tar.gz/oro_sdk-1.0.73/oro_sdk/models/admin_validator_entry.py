from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.validator_status import ValidatorStatus
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.admin_validator_entry_service_versions_type_0 import AdminValidatorEntryServiceVersionsType0
    from ..models.validator_current_agent import ValidatorCurrentAgent


T = TypeVar("T", bound="AdminValidatorEntry")


@_attrs_define
class AdminValidatorEntry:
    """
    Attributes:
        hotkey (str): Validator's SS58 address
        status (ValidatorStatus):
        registered_at (datetime.datetime): When validator was registered
        is_banned (bool): Whether the validator is banned
        max_concurrent_runs (int): Maximum concurrent evaluation runs for this hotkey
        name (None | str | Unset): On-chain identity name, if set
        last_claim_at (datetime.datetime | None | Unset): Last work claim time
        last_seen_at (datetime.datetime | None | Unset): Last time validator was seen
        current_agent (None | Unset | ValidatorCurrentAgent): Agent currently being evaluated, if any
        service_versions (AdminValidatorEntryServiceVersionsType0 | None | Unset): Docker image digests for validator
            stack services
        identity_url (None | str | Unset): On-chain identity URL
        identity_image (None | str | Unset): On-chain identity image URL
        identity_description (None | str | Unset): On-chain identity description
        cpu_pct (float | None | Unset): Latest reported host CPU utilisation percentage (0-100)
        ram_pct (float | None | Unset): Latest reported host RAM utilisation percentage (0-100)
        disk_pct (float | None | Unset): Latest reported host disk utilisation percentage on the sandbox volume (0-100)
        docker_container_count (int | None | Unset): Latest reported running Docker container count on the host
        metrics_reported_at (datetime.datetime | None | Unset): UTC timestamp of the last resource-metrics report
        ban_reason (None | str | Unset): Reason for the ban
        banned_at (datetime.datetime | None | Unset): When the validator was banned
    """

    hotkey: str
    status: ValidatorStatus
    registered_at: datetime.datetime
    is_banned: bool
    max_concurrent_runs: int
    name: None | str | Unset = UNSET
    last_claim_at: datetime.datetime | None | Unset = UNSET
    last_seen_at: datetime.datetime | None | Unset = UNSET
    current_agent: None | Unset | ValidatorCurrentAgent = UNSET
    service_versions: AdminValidatorEntryServiceVersionsType0 | None | Unset = UNSET
    identity_url: None | str | Unset = UNSET
    identity_image: None | str | Unset = UNSET
    identity_description: None | str | Unset = UNSET
    cpu_pct: float | None | Unset = UNSET
    ram_pct: float | None | Unset = UNSET
    disk_pct: float | None | Unset = UNSET
    docker_container_count: int | None | Unset = UNSET
    metrics_reported_at: datetime.datetime | None | Unset = UNSET
    ban_reason: None | str | Unset = UNSET
    banned_at: datetime.datetime | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.admin_validator_entry_service_versions_type_0 import AdminValidatorEntryServiceVersionsType0
        from ..models.validator_current_agent import ValidatorCurrentAgent

        hotkey = self.hotkey

        status = self.status.value

        registered_at = self.registered_at.isoformat()

        is_banned = self.is_banned

        max_concurrent_runs = self.max_concurrent_runs

        name: None | str | Unset
        if isinstance(self.name, Unset):
            name = UNSET
        else:
            name = self.name

        last_claim_at: None | str | Unset
        if isinstance(self.last_claim_at, Unset):
            last_claim_at = UNSET
        elif isinstance(self.last_claim_at, datetime.datetime):
            last_claim_at = self.last_claim_at.isoformat()
        else:
            last_claim_at = self.last_claim_at

        last_seen_at: None | str | Unset
        if isinstance(self.last_seen_at, Unset):
            last_seen_at = UNSET
        elif isinstance(self.last_seen_at, datetime.datetime):
            last_seen_at = self.last_seen_at.isoformat()
        else:
            last_seen_at = self.last_seen_at

        current_agent: dict[str, Any] | None | Unset
        if isinstance(self.current_agent, Unset):
            current_agent = UNSET
        elif isinstance(self.current_agent, ValidatorCurrentAgent):
            current_agent = self.current_agent.to_dict()
        else:
            current_agent = self.current_agent

        service_versions: dict[str, Any] | None | Unset
        if isinstance(self.service_versions, Unset):
            service_versions = UNSET
        elif isinstance(self.service_versions, AdminValidatorEntryServiceVersionsType0):
            service_versions = self.service_versions.to_dict()
        else:
            service_versions = self.service_versions

        identity_url: None | str | Unset
        if isinstance(self.identity_url, Unset):
            identity_url = UNSET
        else:
            identity_url = self.identity_url

        identity_image: None | str | Unset
        if isinstance(self.identity_image, Unset):
            identity_image = UNSET
        else:
            identity_image = self.identity_image

        identity_description: None | str | Unset
        if isinstance(self.identity_description, Unset):
            identity_description = UNSET
        else:
            identity_description = self.identity_description

        cpu_pct: float | None | Unset
        if isinstance(self.cpu_pct, Unset):
            cpu_pct = UNSET
        else:
            cpu_pct = self.cpu_pct

        ram_pct: float | None | Unset
        if isinstance(self.ram_pct, Unset):
            ram_pct = UNSET
        else:
            ram_pct = self.ram_pct

        disk_pct: float | None | Unset
        if isinstance(self.disk_pct, Unset):
            disk_pct = UNSET
        else:
            disk_pct = self.disk_pct

        docker_container_count: int | None | Unset
        if isinstance(self.docker_container_count, Unset):
            docker_container_count = UNSET
        else:
            docker_container_count = self.docker_container_count

        metrics_reported_at: None | str | Unset
        if isinstance(self.metrics_reported_at, Unset):
            metrics_reported_at = UNSET
        elif isinstance(self.metrics_reported_at, datetime.datetime):
            metrics_reported_at = self.metrics_reported_at.isoformat()
        else:
            metrics_reported_at = self.metrics_reported_at

        ban_reason: None | str | Unset
        if isinstance(self.ban_reason, Unset):
            ban_reason = UNSET
        else:
            ban_reason = self.ban_reason

        banned_at: None | str | Unset
        if isinstance(self.banned_at, Unset):
            banned_at = UNSET
        elif isinstance(self.banned_at, datetime.datetime):
            banned_at = self.banned_at.isoformat()
        else:
            banned_at = self.banned_at

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "hotkey": hotkey,
                "status": status,
                "registered_at": registered_at,
                "is_banned": is_banned,
                "max_concurrent_runs": max_concurrent_runs,
            }
        )
        if name is not UNSET:
            field_dict["name"] = name
        if last_claim_at is not UNSET:
            field_dict["last_claim_at"] = last_claim_at
        if last_seen_at is not UNSET:
            field_dict["last_seen_at"] = last_seen_at
        if current_agent is not UNSET:
            field_dict["current_agent"] = current_agent
        if service_versions is not UNSET:
            field_dict["service_versions"] = service_versions
        if identity_url is not UNSET:
            field_dict["identity_url"] = identity_url
        if identity_image is not UNSET:
            field_dict["identity_image"] = identity_image
        if identity_description is not UNSET:
            field_dict["identity_description"] = identity_description
        if cpu_pct is not UNSET:
            field_dict["cpu_pct"] = cpu_pct
        if ram_pct is not UNSET:
            field_dict["ram_pct"] = ram_pct
        if disk_pct is not UNSET:
            field_dict["disk_pct"] = disk_pct
        if docker_container_count is not UNSET:
            field_dict["docker_container_count"] = docker_container_count
        if metrics_reported_at is not UNSET:
            field_dict["metrics_reported_at"] = metrics_reported_at
        if ban_reason is not UNSET:
            field_dict["ban_reason"] = ban_reason
        if banned_at is not UNSET:
            field_dict["banned_at"] = banned_at

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.admin_validator_entry_service_versions_type_0 import AdminValidatorEntryServiceVersionsType0
        from ..models.validator_current_agent import ValidatorCurrentAgent

        d = dict(src_dict)
        hotkey = d.pop("hotkey")

        status = ValidatorStatus(d.pop("status"))

        registered_at = isoparse(d.pop("registered_at"))

        is_banned = d.pop("is_banned")

        max_concurrent_runs = d.pop("max_concurrent_runs")

        def _parse_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        name = _parse_name(d.pop("name", UNSET))

        def _parse_last_claim_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                last_claim_at_type_0 = isoparse(data)

                return last_claim_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        last_claim_at = _parse_last_claim_at(d.pop("last_claim_at", UNSET))

        def _parse_last_seen_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                last_seen_at_type_0 = isoparse(data)

                return last_seen_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        last_seen_at = _parse_last_seen_at(d.pop("last_seen_at", UNSET))

        def _parse_current_agent(data: object) -> None | Unset | ValidatorCurrentAgent:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                current_agent_type_0 = ValidatorCurrentAgent.from_dict(data)

                return current_agent_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | ValidatorCurrentAgent, data)

        current_agent = _parse_current_agent(d.pop("current_agent", UNSET))

        def _parse_service_versions(data: object) -> AdminValidatorEntryServiceVersionsType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                service_versions_type_0 = AdminValidatorEntryServiceVersionsType0.from_dict(data)

                return service_versions_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(AdminValidatorEntryServiceVersionsType0 | None | Unset, data)

        service_versions = _parse_service_versions(d.pop("service_versions", UNSET))

        def _parse_identity_url(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        identity_url = _parse_identity_url(d.pop("identity_url", UNSET))

        def _parse_identity_image(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        identity_image = _parse_identity_image(d.pop("identity_image", UNSET))

        def _parse_identity_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        identity_description = _parse_identity_description(d.pop("identity_description", UNSET))

        def _parse_cpu_pct(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        cpu_pct = _parse_cpu_pct(d.pop("cpu_pct", UNSET))

        def _parse_ram_pct(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        ram_pct = _parse_ram_pct(d.pop("ram_pct", UNSET))

        def _parse_disk_pct(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        disk_pct = _parse_disk_pct(d.pop("disk_pct", UNSET))

        def _parse_docker_container_count(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        docker_container_count = _parse_docker_container_count(d.pop("docker_container_count", UNSET))

        def _parse_metrics_reported_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                metrics_reported_at_type_0 = isoparse(data)

                return metrics_reported_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        metrics_reported_at = _parse_metrics_reported_at(d.pop("metrics_reported_at", UNSET))

        def _parse_ban_reason(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        ban_reason = _parse_ban_reason(d.pop("ban_reason", UNSET))

        def _parse_banned_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                banned_at_type_0 = isoparse(data)

                return banned_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        banned_at = _parse_banned_at(d.pop("banned_at", UNSET))

        admin_validator_entry = cls(
            hotkey=hotkey,
            status=status,
            registered_at=registered_at,
            is_banned=is_banned,
            max_concurrent_runs=max_concurrent_runs,
            name=name,
            last_claim_at=last_claim_at,
            last_seen_at=last_seen_at,
            current_agent=current_agent,
            service_versions=service_versions,
            identity_url=identity_url,
            identity_image=identity_image,
            identity_description=identity_description,
            cpu_pct=cpu_pct,
            ram_pct=ram_pct,
            disk_pct=disk_pct,
            docker_container_count=docker_container_count,
            metrics_reported_at=metrics_reported_at,
            ban_reason=ban_reason,
            banned_at=banned_at,
        )

        admin_validator_entry.additional_properties = d
        return admin_validator_entry

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
