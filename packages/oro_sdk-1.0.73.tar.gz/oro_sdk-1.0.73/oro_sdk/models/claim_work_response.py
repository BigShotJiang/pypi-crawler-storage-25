from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.inference_token_grant import InferenceTokenGrant


T = TypeVar("T", bound="ClaimWorkResponse")


@_attrs_define
class ClaimWorkResponse:
    """
    Attributes:
        eval_run_id (UUID): Evaluation run ID assigned to this claim
        agent_version_id (UUID): Agent version to evaluate
        suite_id (int): Problem suite ID for this evaluation
        lease_expires_at (datetime.datetime): When the lease expires if not renewed
        code_download_url (str): Presigned URL to download agent code
        chutes_access_token (None | str | Unset): Mirrors ``inference_token.access_token`` when the minted provider is
            Chutes; null otherwise. Present for compatibility with older validators that haven't migrated to
            ``inference_token``.
        inference_token (InferenceTokenGrant | None | Unset): Per-run scoped inference credential. Null when the miner
            has no inference auth connected or minting failed.
    """

    eval_run_id: UUID
    agent_version_id: UUID
    suite_id: int
    lease_expires_at: datetime.datetime
    code_download_url: str
    chutes_access_token: None | str | Unset = UNSET
    inference_token: InferenceTokenGrant | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.inference_token_grant import InferenceTokenGrant

        eval_run_id = str(self.eval_run_id)

        agent_version_id = str(self.agent_version_id)

        suite_id = self.suite_id

        lease_expires_at = self.lease_expires_at.isoformat()

        code_download_url = self.code_download_url

        chutes_access_token: None | str | Unset
        if isinstance(self.chutes_access_token, Unset):
            chutes_access_token = UNSET
        else:
            chutes_access_token = self.chutes_access_token

        inference_token: dict[str, Any] | None | Unset
        if isinstance(self.inference_token, Unset):
            inference_token = UNSET
        elif isinstance(self.inference_token, InferenceTokenGrant):
            inference_token = self.inference_token.to_dict()
        else:
            inference_token = self.inference_token

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "eval_run_id": eval_run_id,
                "agent_version_id": agent_version_id,
                "suite_id": suite_id,
                "lease_expires_at": lease_expires_at,
                "code_download_url": code_download_url,
            }
        )
        if chutes_access_token is not UNSET:
            field_dict["chutes_access_token"] = chutes_access_token
        if inference_token is not UNSET:
            field_dict["inference_token"] = inference_token

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.inference_token_grant import InferenceTokenGrant

        d = dict(src_dict)
        eval_run_id = UUID(d.pop("eval_run_id"))

        agent_version_id = UUID(d.pop("agent_version_id"))

        suite_id = d.pop("suite_id")

        lease_expires_at = isoparse(d.pop("lease_expires_at"))

        code_download_url = d.pop("code_download_url")

        def _parse_chutes_access_token(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        chutes_access_token = _parse_chutes_access_token(d.pop("chutes_access_token", UNSET))

        def _parse_inference_token(data: object) -> InferenceTokenGrant | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                inference_token_type_0 = InferenceTokenGrant.from_dict(data)

                return inference_token_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(InferenceTokenGrant | None | Unset, data)

        inference_token = _parse_inference_token(d.pop("inference_token", UNSET))

        claim_work_response = cls(
            eval_run_id=eval_run_id,
            agent_version_id=agent_version_id,
            suite_id=suite_id,
            lease_expires_at=lease_expires_at,
            code_download_url=code_download_url,
            chutes_access_token=chutes_access_token,
            inference_token=inference_token,
        )

        claim_work_response.additional_properties = d
        return claim_work_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
