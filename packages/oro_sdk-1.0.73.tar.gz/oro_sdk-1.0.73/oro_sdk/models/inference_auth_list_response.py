from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.inference_auth_status_response import InferenceAuthStatusResponse


T = TypeVar("T", bound="InferenceAuthListResponse")


@_attrs_define
class InferenceAuthListResponse:
    """Response body for ``GET /v1/miner/inference-auth``.

    Attributes:
        providers (list[InferenceAuthStatusResponse]):
        default_provider (None | str | Unset): Which provider claim_work mints a token from. Null = single-provider
            auto-pick.
    """

    providers: list[InferenceAuthStatusResponse]
    default_provider: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        providers = []
        for providers_item_data in self.providers:
            providers_item = providers_item_data.to_dict()
            providers.append(providers_item)

        default_provider: None | str | Unset
        if isinstance(self.default_provider, Unset):
            default_provider = UNSET
        else:
            default_provider = self.default_provider

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "providers": providers,
            }
        )
        if default_provider is not UNSET:
            field_dict["default_provider"] = default_provider

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.inference_auth_status_response import InferenceAuthStatusResponse

        d = dict(src_dict)
        providers = []
        _providers = d.pop("providers")
        for providers_item_data in _providers:
            providers_item = InferenceAuthStatusResponse.from_dict(providers_item_data)

            providers.append(providers_item)

        def _parse_default_provider(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        default_provider = _parse_default_provider(d.pop("default_provider", UNSET))

        inference_auth_list_response = cls(
            providers=providers,
            default_provider=default_provider,
        )

        inference_auth_list_response.additional_properties = d
        return inference_auth_list_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
