from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.ranked_inference_model import RankedInferenceModel


T = TypeVar("T", bound="RankedInferenceModelsResponse")


@_attrs_define
class RankedInferenceModelsResponse:
    """Models in ranked order — earlier entries are preferred.

    Attributes:
        models (list[RankedInferenceModel]):
        ranked_by (None | str | Unset): Sort applied; null on cold start (static fallback order).
        as_of (datetime.datetime | None | Unset):
    """

    models: list[RankedInferenceModel]
    ranked_by: None | str | Unset = UNSET
    as_of: datetime.datetime | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        models = []
        for models_item_data in self.models:
            models_item = models_item_data.to_dict()
            models.append(models_item)

        ranked_by: None | str | Unset
        if isinstance(self.ranked_by, Unset):
            ranked_by = UNSET
        else:
            ranked_by = self.ranked_by

        as_of: None | str | Unset
        if isinstance(self.as_of, Unset):
            as_of = UNSET
        elif isinstance(self.as_of, datetime.datetime):
            as_of = self.as_of.isoformat()
        else:
            as_of = self.as_of

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "models": models,
            }
        )
        if ranked_by is not UNSET:
            field_dict["ranked_by"] = ranked_by
        if as_of is not UNSET:
            field_dict["as_of"] = as_of

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.ranked_inference_model import RankedInferenceModel

        d = dict(src_dict)
        models = []
        _models = d.pop("models")
        for models_item_data in _models:
            models_item = RankedInferenceModel.from_dict(models_item_data)

            models.append(models_item)

        def _parse_ranked_by(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        ranked_by = _parse_ranked_by(d.pop("ranked_by", UNSET))

        def _parse_as_of(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                as_of_type_0 = isoparse(data)

                return as_of_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        as_of = _parse_as_of(d.pop("as_of", UNSET))

        ranked_inference_models_response = cls(
            models=models,
            ranked_by=ranked_by,
            as_of=as_of,
        )

        ranked_inference_models_response.additional_properties = d
        return ranked_inference_models_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
