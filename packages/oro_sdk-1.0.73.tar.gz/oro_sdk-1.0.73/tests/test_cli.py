"""Tests for the CLI submit, inference-auth, pin, and unpin flows."""

from __future__ import annotations

import argparse
import json
import sys
import types
from http import HTTPStatus
from types import SimpleNamespace
from unittest.mock import MagicMock, patch
from uuid import UUID

import pytest

from oro_sdk.models.admission_status import AdmissionStatus
from oro_sdk.models.chutes_auth_status_response import ChutesAuthStatusResponse
from oro_sdk.models.inference_auth_list_response import InferenceAuthListResponse
from oro_sdk.models.inference_auth_status_response import InferenceAuthStatusResponse
from oro_sdk.models.no_selection_error import NoSelectionError
from oro_sdk.models.race_locked_error import RaceLockedError
from oro_sdk.models.submit_agent_response import SubmitAgentResponse
from oro_sdk.types import UNSET, Response


def _list_response(providers: list[InferenceAuthStatusResponse], default: str | None = None):
    """Build a Response wrapping an InferenceAuthListResponse for `list_inference_auth.sync_detailed`."""
    return Response(
        status_code=HTTPStatus.OK,
        content=b"{}",
        headers={},
        parsed=InferenceAuthListResponse(
            providers=providers,
            default_provider=default if default is not None else UNSET,
        ),
    )


def _provider(name: str) -> InferenceAuthStatusResponse:
    return InferenceAuthStatusResponse(provider=name, connected=True)

# Stub bittensor_wallet so patch() works without the optional dependency.
if "bittensor_wallet" not in sys.modules:
    _bw = types.ModuleType("bittensor_wallet")
    _bw.Wallet = MagicMock  # type: ignore[attr-defined]
    sys.modules["bittensor_wallet"] = _bw

_OK_SUBMIT = Response(
    status_code=HTTPStatus.OK,
    content=b"{}",
    headers={},
    parsed=SubmitAgentResponse(
        admission_status=AdmissionStatus.ACCEPTED,
        hotkey="5Fake",
        message="OK",
    ),
)
_OK_STORE = Response(status_code=HTTPStatus.OK, content=b"{}", headers={}, parsed=None)
_ERR_STORE = Response(
    status_code=HTTPStatus.INTERNAL_SERVER_ERROR,
    headers={},
    parsed=None,
    content=json.dumps({"detail": "storage failed"}).encode(),
)


@pytest.fixture()
def cli(tmp_path):
    """Patch all _submit dependencies with happy-path defaults. Returns (run, mocks).

    Call run() to invoke _submit. Override mocks.X.return_value before calling
    to test unhappy paths — only configure what the test cares about.
    """
    agent_file = tmp_path / "agent.py"
    agent_file.write_text("print('hello')")
    args = argparse.Namespace(
        agent_name="test-agent",
        agent_file=agent_file,
        wallet_name="default",
        wallet_hotkey="default",
        base_url="http://localhost:8000",
    )

    with (
        patch("bittensor_wallet.Wallet") as mock_wallet,
        patch("oro_sdk.bittensor_auth.BittensorAuthClient"),
        patch("oro_sdk.api.miner.list_inference_auth.sync_detailed") as listing,
        patch("oro_sdk.api.miner.submit_agent.sync_detailed") as submit,
    ):
        w = MagicMock()
        w.name = "default"
        w.hotkey.ss58_address = "5Fake"
        mock_wallet.return_value = w

        # Happy-path defaults: chutes connected as default, submission succeeds.
        listing.return_value = _list_response([_provider("chutes")], default="chutes")
        submit.return_value = _OK_SUBMIT

        from oro_sdk.cli import _submit

        m = SimpleNamespace(listing=listing, submit=submit, args=args)
        yield lambda **kw: _submit(argparse.Namespace(**{**vars(args), **kw})), m


class TestSubmitInferenceProviderGate:
    def test_proceeds_when_chutes_only_connected(self, cli, capsys):
        run, m = cli
        # default chutes-only fixture
        run()

        m.submit.assert_called_once()
        out = capsys.readouterr().out
        assert "connected=chutes" in out
        assert "default=chutes" in out

    def test_proceeds_when_openrouter_only_connected(self, cli, capsys):
        run, m = cli
        m.listing.return_value = _list_response(
            [_provider("openrouter")], default="openrouter"
        )

        run()

        m.submit.assert_called_once()
        out = capsys.readouterr().out
        assert "connected=openrouter" in out
        assert "default=openrouter" in out

    def test_proceeds_when_both_connected(self, cli, capsys):
        run, m = cli
        m.listing.return_value = _list_response(
            [_provider("chutes"), _provider("openrouter")],
            default="openrouter",
        )

        run()

        m.submit.assert_called_once()
        out = capsys.readouterr().out
        assert "connected=chutes, openrouter" in out
        assert "default=openrouter" in out

    def test_exits_with_hint_when_no_provider_connected(self, cli, capsys):
        run, m = cli
        m.listing.return_value = _list_response([], default=None)

        with pytest.raises(SystemExit, match="1"):
            run()

        m.submit.assert_not_called()
        err = capsys.readouterr().err
        assert "No inference provider connected" in err
        assert "oro inference connect" in err

    def test_no_inline_token_in_submit_body(self, cli):
        run, m = cli
        run()

        body = m.submit.call_args.kwargs["body"]
        assert "chutes_refresh_token" not in body.additional_properties


_VERSION_ID = "12345678-1234-1234-1234-123456789012"
_NO_CONTENT = Response(status_code=HTTPStatus.NO_CONTENT, content=b"", headers={}, parsed=None)
_RACE_LOCKED = Response(
    status_code=HTTPStatus.CONFLICT,
    content=json.dumps({"detail": "Race is in progress"}).encode(),
    headers={},
    parsed=RaceLockedError(detail="Race is in progress"),
)
_NO_SELECTION = Response(
    status_code=HTTPStatus.NOT_FOUND,
    content=json.dumps({"detail": "No selection exists"}).encode(),
    headers={},
    parsed=NoSelectionError(detail="No selection exists"),
)
_NOT_OWNER = Response(
    status_code=HTTPStatus.FORBIDDEN,
    content=json.dumps({"detail": "Not the version owner"}).encode(),
    headers={},
    parsed=None,
)
_PRECONDITION_FAILED = Response(
    status_code=HTTPStatus.BAD_REQUEST,
    content=json.dumps(
        {"error_code": "SELECTION_PRECONDITION_FAILED", "detail": "Cannot pin: below_threshold"}
    ).encode(),
    headers={},
    parsed=None,
)


@pytest.fixture()
def pin_cli():
    """Patch _pin dependencies. Returns (run, mocks)."""
    args = argparse.Namespace(
        agent_version_id=_VERSION_ID,
        wallet_name="default",
        wallet_hotkey="default",
        base_url="http://localhost:8000",
    )
    with (
        patch("bittensor_wallet.Wallet") as mock_wallet,
        patch("oro_sdk.bittensor_auth.BittensorAuthClient"),
        patch("oro_sdk.api.miner.set_race_selection.sync_detailed") as call,
    ):
        w = MagicMock()
        w.name = "default"
        w.hotkey.ss58_address = "5Fake"
        mock_wallet.return_value = w

        call.return_value = _NO_CONTENT

        from oro_sdk.cli import _pin

        m = SimpleNamespace(call=call, args=args)
        yield lambda **kw: _pin(argparse.Namespace(**{**vars(args), **kw})), m


@pytest.fixture()
def unpin_cli():
    """Patch _unpin dependencies. Returns (run, mocks)."""
    args = argparse.Namespace(
        wallet_name="default",
        wallet_hotkey="default",
        base_url="http://localhost:8000",
    )
    with (
        patch("bittensor_wallet.Wallet") as mock_wallet,
        patch("oro_sdk.bittensor_auth.BittensorAuthClient"),
        patch("oro_sdk.api.miner.clear_race_selection.sync_detailed") as call,
    ):
        w = MagicMock()
        w.name = "default"
        w.hotkey.ss58_address = "5Fake"
        mock_wallet.return_value = w

        call.return_value = _NO_CONTENT

        from oro_sdk.cli import _unpin

        m = SimpleNamespace(call=call, args=args)
        yield lambda **kw: _unpin(argparse.Namespace(**{**vars(args), **kw})), m


class TestPin:
    def test_success_sends_uuid_and_prints(self, pin_cli, capsys):
        run, m = pin_cli
        run()

        body = m.call.call_args.kwargs["body"]
        assert body.agent_version_id == UUID(_VERSION_ID)
        out = capsys.readouterr().out
        assert "Locked" in out
        assert _VERSION_ID in out

    def test_invalid_uuid_exits_before_request(self, pin_cli, capsys):
        run, m = pin_cli
        with pytest.raises(SystemExit, match="1"):
            run(agent_version_id="not-a-uuid")
        m.call.assert_not_called()
        assert "must be a valid UUID" in capsys.readouterr().err

    def test_400_precondition_exits_with_detail(self, pin_cli, capsys):
        run, m = pin_cli
        m.call.return_value = _PRECONDITION_FAILED

        with pytest.raises(SystemExit, match="1"):
            run()
        assert "below_threshold" in capsys.readouterr().err

    def test_403_not_owner_exits_with_detail(self, pin_cli, capsys):
        run, m = pin_cli
        m.call.return_value = _NOT_OWNER

        with pytest.raises(SystemExit, match="1"):
            run()
        assert "Not the version owner" in capsys.readouterr().err

    def test_409_race_locked_exits_with_detail(self, pin_cli, capsys):
        run, m = pin_cli
        m.call.return_value = _RACE_LOCKED

        with pytest.raises(SystemExit, match="1"):
            run()
        assert "Race is in progress" in capsys.readouterr().err


class TestUnpin:
    def test_success_calls_clear_and_prints(self, unpin_cli, capsys):
        run, m = unpin_cli
        run()

        m.call.assert_called_once()
        assert "Lock cleared" in capsys.readouterr().out

    def test_404_no_selection_exits_with_detail(self, unpin_cli, capsys):
        run, m = unpin_cli
        m.call.return_value = _NO_SELECTION

        with pytest.raises(SystemExit, match="1"):
            run()
        assert "No selection exists" in capsys.readouterr().err

    def test_409_race_locked_exits_with_detail(self, unpin_cli, capsys):
        run, m = unpin_cli
        m.call.return_value = _RACE_LOCKED

        with pytest.raises(SystemExit, match="1"):
            run()
        assert "Race is in progress" in capsys.readouterr().err


# ---------------------------------------------------------------------------
# `oro inference {connect, status, set-default, disconnect}` tests
# ---------------------------------------------------------------------------


def _inference_args(**overrides):
    base = {
        "wallet_name": "default",
        "wallet_hotkey": "default",
        "base_url": "http://localhost:8000",
    }
    base.update(overrides)
    return argparse.Namespace(**base)


def _inference_mock_wallet():
    w = MagicMock()
    w.name = "default"
    w.hotkey.ss58_address = "5Fake"
    return w


class TestInferenceConnect:
    def test_openrouter_requires_api_key(self, capsys):
        from oro_sdk.cli import _inference_connect

        with pytest.raises(SystemExit, match="1"):
            _inference_connect(_inference_args(provider="openrouter", api_key=None))
        assert "--api-key is required" in capsys.readouterr().err

    def test_openrouter_with_key_calls_store(self):
        from oro_sdk.cli import _inference_connect

        with (
            patch("bittensor_wallet.Wallet") as mock_wallet,
            patch("oro_sdk.bittensor_auth.BittensorAuthClient"),
            patch("oro_sdk.api.miner.store_inference_credential.sync_detailed") as store,
        ):
            mock_wallet.return_value = _inference_mock_wallet()
            store.return_value = _OK_STORE
            _inference_connect(_inference_args(provider="openrouter", api_key="sk-or-v1-test"))

        assert store.call_args.kwargs["provider"] == "openrouter"
        assert store.call_args.kwargs["body"].credential == "sk-or-v1-test"

    def test_chutes_without_key_runs_oauth_flow(self):
        from oro_sdk.cli import _inference_connect

        with (
            patch("bittensor_wallet.Wallet") as mock_wallet,
            patch("oro_sdk.bittensor_auth.BittensorAuthClient"),
            patch("oro_sdk.chutes_auth.start_auth_flow") as auth_flow,
            patch("oro_sdk.api.miner.store_inference_credential.sync_detailed") as store,
        ):
            mock_wallet.return_value = _inference_mock_wallet()
            auth_flow.return_value = {"refresh_token": "rt-test"}
            store.return_value = _OK_STORE
            _inference_connect(_inference_args(provider="chutes", api_key=None))

        auth_flow.assert_called_once()
        assert store.call_args.kwargs["provider"] == "chutes"
        assert store.call_args.kwargs["body"].credential == "rt-test"

    def test_chutes_rejects_api_key(self, capsys):
        from oro_sdk.cli import _inference_connect

        with pytest.raises(SystemExit, match="1"):
            _inference_connect(_inference_args(provider="chutes", api_key="cpk_test"))
        assert "not supported for chutes" in capsys.readouterr().err


class TestInferenceStatus:
    def test_prints_providers_table(self, capsys):
        from oro_sdk.cli import _inference_status

        listing = InferenceAuthListResponse(
            providers=[
                InferenceAuthStatusResponse(connected=True, provider="chutes"),
                InferenceAuthStatusResponse(connected=True, provider="openrouter"),
            ],
            default_provider="openrouter",
        )
        response = Response(status_code=HTTPStatus.OK, content=b"{}", headers={}, parsed=listing)

        with (
            patch("bittensor_wallet.Wallet") as mock_wallet,
            patch("oro_sdk.bittensor_auth.BittensorAuthClient"),
            patch("oro_sdk.api.miner.list_inference_auth.sync_detailed") as list_call,
        ):
            mock_wallet.return_value = _inference_mock_wallet()
            list_call.return_value = response
            _inference_status(_inference_args())

        out = capsys.readouterr().out
        # Find each provider's row and verify the default column is set only
        # for openrouter — asserting "yes" globally would also match the
        # "Connected" column.
        rows = {line.split()[0]: line for line in out.splitlines() if line.split() and line.split()[0] in ("chutes", "openrouter")}
        assert set(rows) == {"chutes", "openrouter"}
        assert "yes" not in rows["chutes"].split()[2:3]  # Default col blank
        assert rows["openrouter"].split()[2] == "yes"  # Default col set

    def test_no_providers_prints_hint(self, capsys):
        from oro_sdk.cli import _inference_status

        listing = InferenceAuthListResponse(providers=[])
        response = Response(status_code=HTTPStatus.OK, content=b"{}", headers={}, parsed=listing)

        with (
            patch("bittensor_wallet.Wallet") as mock_wallet,
            patch("oro_sdk.bittensor_auth.BittensorAuthClient"),
            patch("oro_sdk.api.miner.list_inference_auth.sync_detailed") as list_call,
        ):
            mock_wallet.return_value = _inference_mock_wallet()
            list_call.return_value = response
            _inference_status(_inference_args())

        assert "No providers connected" in capsys.readouterr().out


class TestInferenceSetDefault:
    def test_calls_set_default_with_provider(self):
        from oro_sdk.cli import _inference_set_default

        with (
            patch("bittensor_wallet.Wallet") as mock_wallet,
            patch("oro_sdk.bittensor_auth.BittensorAuthClient"),
            patch("oro_sdk.api.miner.set_default_inference_provider.sync_detailed") as call,
        ):
            mock_wallet.return_value = _inference_mock_wallet()
            call.return_value = _NO_CONTENT
            _inference_set_default(_inference_args(provider="openrouter"))

        assert call.call_args.kwargs["body"].provider == "openrouter"


class TestInferenceDisconnect:
    def test_calls_delete_on_provider_path(self):
        from oro_sdk.cli import _inference_disconnect

        with (
            patch("bittensor_wallet.Wallet") as mock_wallet,
            patch("oro_sdk.bittensor_auth.BittensorAuthClient"),
            patch("oro_sdk.api.miner.delete_inference_credential.sync_detailed") as call,
        ):
            mock_wallet.return_value = _inference_mock_wallet()
            call.return_value = _NO_CONTENT
            _inference_disconnect(_inference_args(provider="openrouter"))

        assert call.call_args.kwargs["provider"] == "openrouter"

    def test_non_2xx_exits_with_error(self, capsys):
        from oro_sdk.cli import _inference_disconnect

        not_found = Response(
            status_code=HTTPStatus.NOT_FOUND,
            content=json.dumps({"detail": "not found"}).encode(),
            headers={},
            parsed=None,
        )

        with (
            patch("bittensor_wallet.Wallet") as mock_wallet,
            patch("oro_sdk.bittensor_auth.BittensorAuthClient"),
            patch("oro_sdk.api.miner.delete_inference_credential.sync_detailed") as call,
        ):
            mock_wallet.return_value = _inference_mock_wallet()
            call.return_value = not_found
            with pytest.raises(SystemExit, match="1"):
                _inference_disconnect(_inference_args(provider="chutes"))

        assert "not found" in capsys.readouterr().err
