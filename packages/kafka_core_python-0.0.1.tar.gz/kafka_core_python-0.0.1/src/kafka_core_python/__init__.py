raise ImportError(
    "kafka-core-python is an internal Homeward Health package. "
    "Do not install from public PyPI."
)
