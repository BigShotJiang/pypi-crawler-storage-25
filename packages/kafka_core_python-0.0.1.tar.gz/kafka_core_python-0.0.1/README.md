# kafka-core-python

This is a placeholder package reserved by [Homeward Health](https://homewardhealth.com).

**Do not use this package.** It is an internal package and is not intended for public use.
