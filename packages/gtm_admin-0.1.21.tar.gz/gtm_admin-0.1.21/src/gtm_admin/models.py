from __future__ import annotations

from datetime import datetime, timezone
from enum import Enum
from typing import Any
from uuid import UUID, uuid4

from sqlalchemy import JSON, Column, DateTime
from sqlmodel import Field, SQLModel


class WorkflowStatus(str, Enum):
    pending = "pending"
    running = "running"
    success = "success"
    failed = "failed"


class WorkflowRun(SQLModel, table=True):
    __tablename__ = "workflow_runs"

    id: UUID = Field(default_factory=uuid4, primary_key=True)
    name: str
    status: str = WorkflowStatus.pending
    triggered_by: str = "manual"
    started_at: datetime | None = Field(default=None, sa_column=Column(DateTime(timezone=True), nullable=True))
    finished_at: datetime | None = Field(default=None, sa_column=Column(DateTime(timezone=True), nullable=True))
    created_at: datetime = Field(
        default_factory=lambda: datetime.now(timezone.utc),
        sa_column=Column(DateTime(timezone=True), nullable=False),
    )
    parent_id: UUID | None = Field(default=None, foreign_key="workflow_runs.id", index=True)
    nodes: list[dict[str, Any]] = Field(default=[], sa_column=Column(JSON))


class User(SQLModel, table=True):
    __tablename__ = "users"

    username: str = Field(primary_key=True)
    hashed_password: str
    created_at: datetime = Field(
        default_factory=lambda: datetime.now(timezone.utc),
        sa_column=Column(DateTime(timezone=True), nullable=False),
    )


class ConfigRecord(SQLModel, table=True):
    __tablename__ = "config_records"

    id: UUID = Field(default_factory=uuid4, primary_key=True)
    key: str = Field(index=True, unique=True)
    value: str
    type: str  # string | number | date | datetime | time | select | json
    select_options: list[str] | None = Field(default=None, sa_column=Column(JSON))
    description: str | None = None
    folder: str | None = None
    created_at: datetime = Field(
        default_factory=lambda: datetime.now(timezone.utc),
        sa_column=Column(DateTime(timezone=True), nullable=False),
    )
    updated_at: datetime = Field(
        default_factory=lambda: datetime.now(timezone.utc),
        sa_column=Column(DateTime(timezone=True), nullable=False),
    )


class DbTable(SQLModel, table=True):
    __tablename__ = "db_tables"

    id: UUID = Field(default_factory=uuid4, primary_key=True)
    name: str
    description: str | None = None
    columns: list[dict[str, Any]] = Field(default=[], sa_column=Column(JSON))
    rows: list[dict[str, Any]] = Field(default=[], sa_column=Column(JSON))
    created_at: datetime = Field(
        default_factory=lambda: datetime.now(timezone.utc),
        sa_column=Column(DateTime(timezone=True), nullable=False),
    )
    updated_at: datetime = Field(
        default_factory=lambda: datetime.now(timezone.utc),
        sa_column=Column(DateTime(timezone=True), nullable=False),
    )
