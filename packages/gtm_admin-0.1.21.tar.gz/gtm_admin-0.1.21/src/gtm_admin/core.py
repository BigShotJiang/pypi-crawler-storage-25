from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from fastapi import FastAPI

STATIC_DIR = Path(__file__).parent / "static"


class GTMAdmin:
    def __init__(
        self,
        app: "FastAPI",
        db_url: str,
        secret: str,
        dev: bool = False,
        auto_seed: bool = False,
    ) -> None:
        from .auth import configure
        from .database import setup_engine

        configure(secret)
        setup_engine(db_url)

        self._workflows: dict = {}

        @app.on_event("startup")
        async def _startup() -> None:
            from .database import run_migrations

            await run_migrations()

            if auto_seed:
                from .seed import seed_demo_data

                await seed_demo_data()

        self._register_router(app, secret)
        self._mount_dashboard(app, dev)

    def _register_router(self, app: "FastAPI", secret: str) -> None:
        from .router import create_router

        router = create_router(secret, self._workflows)
        app.include_router(router, prefix="/api")

    def _mount_dashboard(self, app: "FastAPI", dev: bool) -> None:
        if dev:
            self._mount_dev_proxy(app)
        elif STATIC_DIR.exists():
            from fastapi.responses import FileResponse

            @app.get("/admin/{path:path}", include_in_schema=False)
            async def _serve_dashboard(path: str) -> FileResponse:
                # Serve exact static asset if it exists, otherwise SPA fallback.
                candidate = STATIC_DIR / path
                if candidate.is_file():
                    return FileResponse(candidate)
                return FileResponse(STATIC_DIR / "index.html")

    def _mount_dev_proxy(self, app: "FastAPI") -> None:
        import httpx
        from fastapi import Request
        from fastapi.responses import StreamingResponse

        @app.api_route("/admin/{path:path}", methods=["GET"])
        async def _proxy(path: str, request: Request) -> StreamingResponse:
            async with httpx.AsyncClient() as client:
                url = f"http://localhost:5173/admin/{path}"
                resp = await client.get(url, headers=dict(request.headers))
                return StreamingResponse(
                    content=iter([resp.content]),
                    status_code=resp.status_code,
                    media_type=resp.headers.get("content-type"),
                )

    def workflow(self, fn):
        from .decorator import make_workflow_wrapper

        wrapper = make_workflow_wrapper(fn)
        self._workflows[fn.__name__] = fn
        return wrapper
