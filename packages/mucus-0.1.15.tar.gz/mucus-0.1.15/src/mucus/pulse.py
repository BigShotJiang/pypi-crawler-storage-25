import ctypes as ct
import ctypes.util as ctu


class Pulse:
    class Error(Exception):
        pass

    def __init__(self, client_name=None, stream_name='playback', format=7, rate=44100, channels=2):
        if client_name is None:
            from sys import argv
            from os.path import split
            client_name = split(argv[0])[1]
        self.client_name = client_name
        self.stream_name = stream_name
        self.format = format
        self.rate = rate
        self.channels = channels

    def __enter__(self):
        class pa_sample_spec(ct.Structure):
            _fields_ = [('format', ct.c_int),
                        ('rate', ct.c_uint32),
                        ('channels', ct.c_uint8)]
        ss = pa_sample_spec(self.format, self.rate, self.channels)
        e = ct.c_int()
        s = self.c.pa_simple_new(None,
                                 self.client_name.encode(),
                                 1,
                                 None,
                                 self.stream_name.encode(),
                                 ct.byref(ss),
                                 None,
                                 None,
                                 ct.byref(e))
        if not s:
            raise Pulse.Error('pa_simple_new', self.c.pa_strerror(e))
        self.s = s
        return self

    def __exit__(self, *args):
        self.c.pa_simple_free(self.s)
        del self.s

    def __call__(self, data: bytes):
        e = ct.c_int()
        if self.c.pa_simple_write(self.s, ct.create_string_buffer(data), len(data), ct.byref(e)) < 0:
            raise Pulse.Error('pa_simple_write', self.c.pa_strerror(e))

    @property
    def c(self):
        try:
            return self._cdll
        except AttributeError:
            pass
        path = ctu.find_library('pulse-simple')
        if path is None:
            raise Pulse.Error('libpulse-simple not found')
        cdll = self._cdll = ct.CDLL(path)
        cp, i, sz, vp = ct.c_char_p, ct.c_int, ct.c_size_t, ct.c_void_p
        cdll.pa_simple_new.argtypes = [cp, cp, i, cp, cp, vp, vp, vp]
        cdll.pa_simple_new.restype = vp
        cdll.pa_simple_free.argtypes = [vp]
        cdll.pa_simple_free.restype = None
        cdll.pa_simple_write.argtypes = [vp, vp, sz, vp]
        cdll.pa_simple_write.restype = i
        cdll.pa_simple_drain.argtypes = [vp, vp]
        cdll.pa_simple_drain.restype = i
        cdll.pa_simple_read.argtypes = [vp, vp, sz, vp]
        cdll.pa_simple_read.restype = i
        cdll.pa_simple_get_latency.argtypes = [vp, vp]
        cdll.pa_simple_get_latency.restype = ct.c_uint64
        cdll.pa_simple_flush.argtypes = [vp, vp]
        cdll.pa_simple_flush.restype = i
        cdll.pa_strerror.argtypes = [i]
        cdll.pa_strerror.restype = cp
        return cdll
    
    def drain(self):
        e = ct.c_int()
        if self.c.pa_simple_drain(self.s, ct.byref(e)) < 0:
            raise Pulse.Error('pa_simple_drain', self.c.pa_strerror(e))

    def flush(self):
        e = ct.c_int()
        if self.c.pa_simple_flush(self.s, ct.byref(e)) < 0:
            raise Pulse.Error('pa_simple_flush', self.c.pa_strerror(e))
