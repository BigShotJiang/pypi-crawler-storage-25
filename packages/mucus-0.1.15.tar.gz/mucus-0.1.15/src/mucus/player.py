import queue
import selectors
import subprocess
import threading

import mucus.deezer.stream
import mucus.exception
from mucus.notify import notify
from mucus.probe import probe
from mucus.pulse import Pulse
from mucus.sox import Sox


class Player:
    class Events:
        types = ('play', 'pause', 'resume', 'stop')

        def __init__(self):
            for name in self.types:
                setattr(self, name, threading.Event())

        def clear(self):
            for name in self.types:
                getattr(self, name).clear()

    def __init__(self, client):
        self.client = client
        self.events = self.Events()
        self.queue = queue.Queue()

    def loop(self):
        self.events.clear()

        while not self.events.stop.is_set():
            song = self.queue.get()
            try:
                if song is None:
                    break
                else:
                    self.song = song
                    self.events.play.set()
                    self.play(song)
                    self.events.play.clear()
                    self.song = None
            finally:
                self.queue.task_done()

    def play(self, song):
        stream = mucus.deezer.stream.stream(song, self.client.data.license_token)
        try:
            chunk0 = next(stream)
        except mucus.exception.DeezerStreamError as e:
            notify(str(e.code), e.message)
            return
        else:
            notify(song['ART_NAME'], song['SNG_TITLE'])

        q = queue.Queue(maxsize=100)
        q.put(chunk0)

        def fillq():
            while self.events.play.is_set():
                try:
                    q.put(next(stream))
                except StopIteration:
                    q.put(None)
                    break

        t = threading.Thread(target=fillq, daemon=True)
        t.start()

        name = ' - '.join((song['ART_NAME'], song['SNG_TITLE']))
        info = probe(chunk0)

        with self.sox(['-t', info['type'], '-', '-t', 's32', '-']) as sox:
            with Pulse(stream_name=name, rate=info['rate'], channels=info['channels']) as pulse:

                sel = selectors.DefaultSelector()

                def write():
                    data = q.get()
                    if data is None:
                        sel.unregister(sox.stdin)
                        sox.stdin.close()
                    else:
                        sox.stdin.write(data)

                def read():
                    data = sox.stdout.read(self.sox.bufsize)
                    if data == b'':
                        sel.unregister(sox.stdout)
                        sox.stdout.close()
                        return True
                    else:
                        if self.events.pause.is_set():
                            self.events.resume.wait()
                        pulse(data)

                def error():
                    data = sox.stderr.read()
                    if data == b'':
                        sel.unregister(sox.stderr)
                        sox.stderr.close()
                    else:
                        raise mucus.exception.SoxError(data.decode())

                sel.register(sox.stdin, selectors.EVENT_WRITE, write)
                sel.register(sox.stdout, selectors.EVENT_READ, read)
                sel.register(sox.stderr, selectors.EVENT_READ, error)

                while self.events.play.is_set():
                    events = sel.select()
                    for key, mask in events:
                        if key.data() is True:
                            self.events.play.clear()
                            break

                if self.events.stop.is_set():
                    pulse.flush()

    def start(self):
        self.sox = Sox(bufsize=2048)
        try:
            self.sox.version
        except FileNotFoundError:
            raise mucus.exception.SoxNotInstalled
        self.thread = threading.Thread(target=self.loop, daemon=True)
        self.thread.start()
