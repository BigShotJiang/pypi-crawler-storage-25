import random

import httpx

import mucus.data
import mucus.exception


class Auth(httpx.Auth):
    def __init__(self, arl=None, sid=None):
        if arl is None or sid is None:
            data = mucus.data.get('auth')
            if data is not None:
                arl = data.get('arl')
                sid = data.get('sid')
        self.arl = arl
        self.sid = sid


    def auth_flow(self, request):
        if request.url.host == 'www.deezer.com':
            cookies = {}
            if self.arl is not None:
                cookies['arl'] = self.arl
            if self.sid is not None:
                cookies['sid'] = self.sid
            if cookies:
                request.headers['Cookie'] = '; '.join(f'{k}={v}' for k, v in cookies.items())
            response = yield request
            try:
                response.cookies['arl']
                response.cookies['sid']
            except KeyError:
                pass
            else:
                mucus.data.set('auth', {'arl': response.cookies['arl'],
                                        'sid': response.cookies['sid']})
        else:
            yield request


class Client(httpx.Client):
    def __init__(self, auth=None):
        if auth is None:
            auth = Auth()

        super().__init__(auth=auth)

        self.data = UserData(self)

    def get_api_token(self, method=None, refresh=False):
        if method == 'deezer.getUserData':
            return ''

        if refresh:
            self.data = UserData(self)

        return self.data.api_token,

    def request(self, method, url, *, params=None, **kwargs):
        if '/' not in url:
            if params is None:
                params = {
                    'method': url,
                    'input': 3,
                    'api_version': '1.0',
                    'api_token': self.get_api_token(method=url),
                    'cid': random.randrange(0, 1000000000)
                }

            url = httpx.URL('https://www.deezer.com/ajax/gw-light.php')

            for _ in range(2):
                r = super().request(method, url, params=params, **kwargs).json()
                e = r.get('error')
                if e and e.get('VALID_TOKEN_REQUIRED'):
                    params['api_token'] = self.get_api_token(params['method'], refresh=True)
                else:
                    break

            if e:
                raise mucus.exception.DeezerError(e)

            return r['results']

        return super().request(method, url, **kwargs)


class UserData:
    def __init__(self, client):
        self._data = client.post('deezer.getUserData')

    @property
    def api_token(self):
        return self._data['checkForm']

    @property
    def license_token(self):
        return self._data['USER']['OPTIONS']['license_token']

    @property
    def user_id(self):
        return self._data['USER']['USER_ID']
