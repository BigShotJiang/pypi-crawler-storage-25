import mucus.command


class Command(mucus.command.Command):
    def __call__(self, console, **kwargs):
        console.clear()
