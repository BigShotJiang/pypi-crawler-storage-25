import argparse
import pathlib
import shlex

import rich.status

import mucus.command
import mucus.config
import mucus.deezer.page
import mucus.deezer.stream
import mucus.probe



class Command(mucus.command.Command):
    def __call__(self, client, command, config, console, player, **kwargs):
        parser = argparse.ArgumentParser(exit_on_error=False)
        parser.add_argument('-a', '--album', action='store_true')
        parser.add_argument('-d', '--directory')
        args = parser.parse_args(shlex.split(command['args']))

        if args.directory is not None:
            try:
                config['download']
            except KeyError:
                config['download'] = {}
            config['download']['directory'] = args.directory
            mucus.config.dump(config)

        if player.song is None:
            return

        def download(song, album=None):
            stream = mucus.deezer.stream.stream(song, client.data.license_token)
            chunk0 = next(stream)
            info = mucus.probe.probe(chunk0)

            root = pathlib.Path(config['download']['directory'])

            def _(s):
                return s.replace('/', '|')

            if album is None:
                path = root / _(song['ART_NAME']) / _(song['ALB_TITLE'])
            else:
                path = root / _(album['ART_NAME']) / _(album['ALB_TITLE'])

            path.mkdir(parents=True, exist_ok=True)
            path /= f'{int(song['TRACK_NUMBER']):02} - {_(song['SNG_TITLE'])}.{info['type']}'

            with path.open('wb') as f:
                f.write(chunk0)
                for chunk in stream:
                    f.write(chunk)

        spinner = rich.status.Status('', console=console)
        spinner.start()

        if args.album:
            page = mucus.deezer.page.Album(client=client, alb_id=player.song['ALB_ID'])
            for song in page.data['SONGS']['data']:
                spinner.update(f'{int(song['TRACK_NUMBER']):02} - {song['SNG_TITLE']}')
                try:
                    download(song, album=page.data['DATA'])
                except mucus.exception.MucusError:
                    continue
        else:
            try:
                download(player.song)
            except mucus.exception.MucusError:
                pass

        spinner.stop()
