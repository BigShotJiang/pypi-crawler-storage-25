import os

import mucus.command
import mucus.commands


class Command(mucus.command.Command):
    def __call__(self, console, **kwargs):
        for f in os.listdir(mucus.commands.__path__[0]):
            if f.startswith('_'):
                continue
            if f.endswith('.py'):
                console.print(f[:-3])
