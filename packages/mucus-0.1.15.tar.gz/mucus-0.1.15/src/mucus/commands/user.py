import argparse
import shlex

import mucus.command


class Command(mucus.command.Command):
    def __call__(self, client, command, console, **kwargs):
        parser = argparse.ArgumentParser(add_help=False, exit_on_error=False)
        parser.add_argument('-j', '--json', action='store_true')
        try:
            args = parser.parse_args(shlex.split(command['args']))
        except argparse.ArgumentError as e:
            raise mucus.exception.CommandException(e)

        if args.json:
            console.print_json(data=client.data._data)
        else:
            console.print(client.data._data['USER']['EMAIL'])
