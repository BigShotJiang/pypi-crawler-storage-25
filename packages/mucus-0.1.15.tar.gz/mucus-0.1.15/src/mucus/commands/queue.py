import random
import queue

import mucus.command


class Command(mucus.command.Command):
    def __call__(self, command, console, player, **kwargs):
        items = []
        while True:
            try:
                items.append(player.queue.get(block=False))
            except queue.Empty:
                break
        if '!' in command['line']:
            return
        if '*' in command['line']:
            random.shuffle(items)
        for i, item in enumerate(items):
            console.print(f'{i:02}', end=' ', style='red')
            console.print(item['ART_NAME'], end=' ', style='green')
            console.print(item['SNG_TITLE'], style='blue')
            player.queue.put(item)
