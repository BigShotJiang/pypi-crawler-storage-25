import argparse
import json
import shlex

import mucus.command


class Command(mucus.command.Command):
    def __call__(self, command, console, player, **kwargs):
        if player.song is None:
            return

        parser = argparse.ArgumentParser(add_help=False, exit_on_error=False)
        parser.add_argument('-j', '--json', action='store_true')
        parser.add_argument('-v', '--verbose', action='store_true')
        try:
            args = parser.parse_args(shlex.split(command['args']))
        except argparse.ArgumentError as e:
            raise mucus.exception.CommandException(e)

        if args.json:
            console.print_json(data=player.song)
            return

        console.print(player.song['SNG_TITLE'], end=' ', style='blue')
        console.print(player.song['ART_NAME'], style='green')

        if args.verbose:
            console.print(player.song['ALB_TITLE'], style='cyan')
            def hms(s):
                r = [int(s)//60, int(s)%60]
                if r[0] > 59:
                    r.insert(0, r[0]//60)
                    r[1] %= 60
                return ':'.join((f'{i:02}' for i in r))
            console.print(hms(player.song['DURATION']))
