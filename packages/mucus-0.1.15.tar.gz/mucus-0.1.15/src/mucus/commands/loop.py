import mucus.command


class Command(mucus.command.Command):
    def __call__(self, console, player, **kwargs):
        if player.events.loop.is_set():
            player.events.loop.clear()
        else:
            player.events.loop.set()
        console.print(player.events.loop.is_set() and 'loop' or 'noop')
