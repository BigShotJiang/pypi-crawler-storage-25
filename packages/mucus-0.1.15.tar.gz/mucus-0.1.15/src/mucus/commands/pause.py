import mucus.command


class Command(mucus.command.Command):
    def __call__(self, player, **kwargs):
        if player.events.pause.is_set():
            player.events.pause.clear()
            player.events.resume.set()
        else:
            player.events.resume.clear()
            player.events.pause.set()
