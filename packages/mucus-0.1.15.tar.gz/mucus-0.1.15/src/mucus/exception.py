class MucusException(Exception):
    pass


class Exit(MucusException):
    pass


class CommandException(MucusException):
    pass


class MucusError(MucusException):
    pass


class NoSuchCommand(MucusError):
    pass


class SoxError(MucusError):
    pass


class SoxNotInstalled(SoxError):
    pass


class DeezerError(MucusError):
    pass


class DeezerAuthError(DeezerError):
    pass


class DeezerStreamError(DeezerError):
    def __init__(self, errors):
        super().__init__(*[f'{e['code']}: {e['message']}' for e in errors])
        self.errors = errors
        self.code = errors[0]['code']
        self.message = errors[0]['message']


class NoMedia(DeezerError):
    pass


class NoSource(DeezerError):
    pass
