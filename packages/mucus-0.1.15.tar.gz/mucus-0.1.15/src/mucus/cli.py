#!/usr/bin/env python3

import argparse
import pathlib

import rich.console
import rich.traceback

import mucus.command
import mucus.config
import mucus.deezer
import mucus.exception
import mucus.history
import mucus.player


def main():
    console = rich.console.Console()

    parser = argparse.ArgumentParser()
    parser.add_argument('--config', '-c', type=pathlib.Path, default=mucus.config.default_path())
    parser.add_argument('--version', '-v', action='store_true')
    args = parser.parse_args()

    if args.version:
        console.print(mucus.__version__)
        return

    config = mucus.config.load(args.config)
    client = mucus.deezer.client.Client()

    if client.data.user_id == 0:
        console.print('not logged in', style='red')

    player = mucus.player.Player(client)
    try:
        player.start()
    except mucus.exception.MucusException as e:
        console.print_exception()
        return

    def inputs():
        while True:
            prompt = config.get('prompt', '\u1e43 ')
            try:
                yield input(prompt)
            except EOFError:
                break

    history = mucus.history.History()
    aliases = config.get('aliases', {})

    with history:
        for line in inputs():
            try:
                loader = mucus.command.Loader(line=line, aliases=aliases)
            except mucus.exception.NoSuchCommand:
                name = config.get('default_command', 'search')
                try:
                    loader = mucus.command.Loader(name=name, args=line)
                except mucus.exception.NoSuchCommand as e:
                    console.print_exception()

            context = {'client': client,
                       'command': {'line': line,
                                   'name': loader.name,
                                   'args': loader.args},
                       'config': config,
                       'console': console,
                       'history': history,
                       'player': player}

            runner = mucus.command.Runner(loader, context)

            try:
                runner()
            except mucus.exception.CommandException as e:
                console.print_exception()
            except mucus.exception.Exit:
                break
