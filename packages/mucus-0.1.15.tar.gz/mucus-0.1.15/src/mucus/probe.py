def probe(data: bytes):
    for probe_func in (probe_flac, probe_mp3):
        try:
            return probe_func(data)
        except ValueError:
            pass

    raise ValueError


def probe_flac(data: bytes):
    if data[0:4] != b'fLaC':
        raise ValueError(data[0:4])

    u = bitstream(data[8:42])

    i = {'min_blocksize': u(16),
         'max_blocksize': u(16),
         'min_framesize': u(24),
         'max_framesize': u(24),
         'sample_rate': u(20),
         'channels': u(3) + 1,
         'bits_per_sample': u(5) + 1,
         'total_samples': u(36),
         'md5sum': u(128)}

    return {'type': 'flac',
            'rate': i['sample_rate'],
            'channels': i['channels']}


def probe_mp3(data: bytes):
    for i in range(0, len(data)-4):
        u = bitstream(data[i:i+4])

        if u(11) == 0x7ff:
            h = {'version': u(2),
                 'layer': 4 - u(2),
                 'error_protection': u(1),
                 'bitrate_index': u(4),
                 'samplerate_index': u(2),
                 'padding': u(1),
                 'extension': u(1),
                 'mode': u(2),
                 'mode_extension': u(2),
                 'copyright': u(1),
                 'original': u(1),
                 'emphasis': u(2)}
            try:
                return {'type': 'mp3',
                        'rate': {3: [44100, 48000, 32000],
                                 2: [22050, 24000, 16000],
                                 0: [11025, 12000, 8000]}[h['version']][h['samplerate_index']],
                        'channels': h['mode'] == 3 and 1 or 2}
            except (KeyError, IndexError):
                continue

    raise ValueError


def bitstream(data: bytes):
    def bits(data: bytes):
        for b in data:
            for i in range(8):
                yield (b >> (7 - i)) & 1

    def u(n):
        r = 0
        for _ in range(n):
            r = (r << 1) | next(u.it)
        return r

    u.it = bits(data)

    return u
