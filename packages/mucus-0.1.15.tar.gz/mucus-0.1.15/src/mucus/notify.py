import subprocess


def notify(summary, body=None, *, urgency=None, expire_time=None,
           app_name=None, icon=None, category=None, transient=False, hint=None,
           print_id=False, replace_id=None, wait=False, action=None):

    args = [summary]

    if body is not None:
        args.append(body)
    if wait is True:
        args.insert(0, '-w')
    if replace_id is not None:
        args.insert(0, '-r')
        args.insert(1, replace_id)
    if print_id is True:
        args.insert(0, '-p')
    if hint is not None:
        args.insert(0, '-h')
        args.insert(1, hint)
    if transient is True:
        args.insert(0, '-e')
    if category is not None:
        args.insert(0, '-c')
        args.insert(1, category)
    if icon is not None:
        args.insert(0, '-i')
        args.insert(1, icon)
    if app_name is not None:
        args.insert(0, '-a')
        args.insert(1, app_name)
    if expire_time is not None:
        args.insert(0, '-t')
        args.insert(1, expire_time)
    if urgency is not None:
        args.append(0, '-u')
        args.append(1, urgency)

    try:
        subprocess.run(['notify-send', *args], stdout=subprocess.PIPE)
    except FileNotFoundError:
        pass
