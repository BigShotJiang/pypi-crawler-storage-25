import subprocess
import functools
import shutil


class Sox:
    def __init__(self, bufsize=8192):
        self.bufsize = bufsize

    def __call__(self, args):
        return subprocess.Popen([self.executable, *args],
                                bufsize=self.bufsize,
                                executable=self.executable,
                                stdin=subprocess.PIPE,
                                stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE,
                                env=self.env,
                                pipesize=self.bufsize)

    @property
    def env(self):
        return {'SOX_OPTS': f'--buffer {self.bufsize}'}

    @property
    @functools.cache
    def executable(self):
        for cmd in ('sox_ng', 'sox'):
            path = shutil.which(cmd)
            if path is not None:
                return path
        raise FileNotFoundError(cmd)

    @property
    @functools.cache
    def version(self):
        return tuple(subprocess.run([self.executable, '--version'],
                                    stdout=subprocess.PIPE,
                                    encoding='utf-8').stdout.strip().split(' ')[-2:])
