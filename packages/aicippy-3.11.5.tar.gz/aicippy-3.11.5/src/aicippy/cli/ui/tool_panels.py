"""Tool-call rendering for the AiCippy TUI.

Provides Rich renderables that replicate the Claude Code "⏺ running a tool"
experience: a *before* line shown when a tool starts and a *result* block
shown after execution, with success / error styling and output truncation.

Public API
----------
- ``ToolStatus``            - enum: RUNNING | SUCCESS | ERROR
- ``render_tool_call``      - produce a renderable for the *before* line
- ``render_tool_result``    - produce a renderable for the *after* block
- ``ToolCallView``          - dataclass bundling call + result renderables

All helpers are intentionally self-contained (stdlib + rich only) and will
never raise on pathological input (None, empty strings, huge blobs, etc.).
"""

from __future__ import annotations

import shutil
import unicodedata
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any

from rich.console import Console, RenderableType
from rich.padding import Padding
from rich.panel import Panel
from rich.style import Style
from rich.text import Text

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

#: Maximum characters shown for a *single* parameter value in the call line.
_PARAM_MAX_CHARS: int = 60

#: Maximum *total* characters for all serialised params on the call line.
_PARAMS_LINE_MAX: int = 120

#: Default maximum number of output lines to show before truncation.
DEFAULT_OUTPUT_LINE_CAP: int = 20

#: Accent colour for the tool-call "before" line (matches Claude Code cyan).
_ACCENT: str = "bold cyan"

#: Colour used for successful result headers.
_SUCCESS_COLOR: str = "bold green"

#: Colour used for error result headers.
_ERROR_COLOR: str = "bold red"

#: Colour used for the "running" spinner line.
_RUNNING_COLOR: str = "bold yellow"

#: Dim style for output body text.
_OUTPUT_STYLE: str = "dim"

#: Style for truncation indicator lines.
_TRUNC_STYLE: str = "italic dim"


# ---------------------------------------------------------------------------
# Unicode-aware icon helpers
# ---------------------------------------------------------------------------


def _unicode_supported() -> bool:
    """Return True if the current terminal is likely to support Unicode."""
    try:
        # shutil.get_terminal_size is a stdlib call; just checking the codec
        # on stdout would require importing sys which we already avoid; we use
        # a lightweight heuristic instead.
        _ = shutil.get_terminal_size()
    except Exception:
        return False
    try:
        # Test a common BMP character used in our icons.
        "●".encode()
        return True
    except (UnicodeEncodeError, LookupError):
        return False


#: Module-level flag; evaluated once at import time.
_UNICODE_OK: bool = _unicode_supported()


class ToolStatus(StrEnum):
    """Status of a tool invocation."""

    RUNNING = "running"
    SUCCESS = "success"
    ERROR = "error"


def _icon(status: ToolStatus) -> str:
    """Return the icon for *status*, with an ASCII fallback."""
    if _UNICODE_OK:
        return {
            ToolStatus.RUNNING: "●",   # ● (filled circle)
            ToolStatus.SUCCESS: "●",   # ● green
            ToolStatus.ERROR:   "●",   # ● red
        }[status]
    return {
        ToolStatus.RUNNING: "*",
        ToolStatus.SUCCESS: "+",
        ToolStatus.ERROR:   "!",
    }[status]


def _icon_style(status: ToolStatus) -> str:
    """Return the Rich style string for *status*."""
    return {
        ToolStatus.RUNNING: _RUNNING_COLOR,
        ToolStatus.SUCCESS: _SUCCESS_COLOR,
        ToolStatus.ERROR:   _ERROR_COLOR,
    }[status]


# ---------------------------------------------------------------------------
# Parameter serialisation helpers
# ---------------------------------------------------------------------------


def _truncate(value: str, max_chars: int) -> str:
    """Truncate *value* to *max_chars*, appending '…' if cut."""
    if len(value) <= max_chars:
        return value
    return value[:max_chars] + "…"  # …


def _is_printable(ch: str) -> bool:
    """Return True for printable (non-control) characters."""
    return unicodedata.category(ch) not in {"Cc", "Cs"}


def _clean(value: str) -> str:
    """Strip non-printable characters from *value*."""
    return "".join(ch if _is_printable(ch) else "?" for ch in value)


def _format_param_value(value: Any) -> str:
    """Render a single parameter value as a safe, readable string."""
    if value is None:
        return "None"
    if isinstance(value, bool):
        return str(value)
    if isinstance(value, (int, float)):
        return str(value)
    if isinstance(value, (list, tuple)):
        inner = ", ".join(_format_param_value(v) for v in value[:5])
        suffix = f", +{len(value) - 5} more" if len(value) > 5 else ""
        return f"[{inner}{suffix}]"
    if isinstance(value, dict):
        pairs = [f"{k}={_format_param_value(v)}" for k, v in list(value.items())[:3]]
        suffix = f", +{len(value) - 3} more" if len(value) > 3 else ""
        return "{" + ", ".join(pairs) + suffix + "}"
    raw = _clean(str(value))
    return _truncate(raw, _PARAM_MAX_CHARS)


def _format_params(params: dict[str, Any] | None) -> str:
    """Serialise *params* to a compact ``key=value, …`` string."""
    if not params:
        return ""
    parts: list[str] = []
    running_len = 0
    for key, val in params.items():
        part = f'{_clean(str(key))}="{_format_param_value(val)}"'
        if running_len + len(part) > _PARAMS_LINE_MAX and parts:
            parts.append("…")
            break
        parts.append(part)
        running_len += len(part) + 2  # account for ", "
    return ", ".join(parts)


# ---------------------------------------------------------------------------
# Core rendering functions
# ---------------------------------------------------------------------------


def render_tool_call(
    name: str | None,
    params: dict[str, Any] | None = None,
    *,
    status: ToolStatus = ToolStatus.RUNNING,
) -> RenderableType:
    """Return a Rich renderable for the tool *call* ("before") line.

    Parameters
    ----------
    name:
        Tool name (e.g. ``"shell_exec"``).  ``None`` or empty string are
        handled gracefully.
    params:
        Mapping of parameter names to values.  May be ``None``.
    status:
        Initial status icon style.  Defaults to :attr:`ToolStatus.RUNNING`.

    Returns
    -------
    :class:`rich.text.Text`
        A single-line renderable suitable for ``console.print()``.

    """
    safe_name: str = _clean(str(name)) if name else "<unknown>"
    params_str: str = _format_params(params)

    icon_char = _icon(status)
    icon_style = _icon_style(status)

    line = Text()
    line.append(icon_char + " ", style=icon_style)
    line.append(safe_name, style=_ACCENT)
    line.append("(", style="dim")
    if params_str:
        line.append(params_str, style="white")
    line.append(")", style="dim")
    return line


def render_tool_result(
    name: str | None,
    *,
    success: bool,
    output: str | None,
    exit_code: int | None = None,
    line_cap: int = DEFAULT_OUTPUT_LINE_CAP,
) -> RenderableType:
    """Return a Rich renderable for the tool *result* ("after") block.

    Parameters
    ----------
    name:
        Tool name, used in the panel title.
    success:
        Whether the tool invocation succeeded.
    output:
        Raw output text from the tool.  May be ``None`` or empty.
    exit_code:
        Optional integer exit code (shown in the header when provided).
    line_cap:
        Maximum number of output lines to display before truncating.

    Returns
    -------
    :class:`rich.panel.Panel`
        A bordered panel renderable suitable for ``console.print()``.

    """
    safe_name = _clean(str(name)) if name else "<unknown>"
    status = ToolStatus.SUCCESS if success else ToolStatus.ERROR
    icon_char = _icon(status)
    icon_style = _icon_style(status)
    header_color = _SUCCESS_COLOR if success else _ERROR_COLOR

    # --- Build panel title ---------------------------------------------------
    title = Text()
    title.append(icon_char + " ", style=icon_style)
    title.append(safe_name, style=header_color)
    if exit_code is not None:
        title.append(f"  exit={exit_code}", style="dim")

    # --- Build panel body ----------------------------------------------------
    body = Text()

    # Split on real newlines *first* so that \n is not treated as a control
    # character by _clean(), then sanitise each line individually.
    raw_output = str(output) if output else ""
    lines = [_clean(ln) for ln in raw_output.splitlines()] if raw_output else []

    if not lines:
        body.append("(no output)", style="italic dim")
    else:
        visible = lines[:line_cap]
        hidden_count = len(lines) - len(visible)
        for i, line_text in enumerate(visible):
            if i:
                body.append("\n")
            body.append(line_text, style=_OUTPUT_STYLE)
        if hidden_count > 0:
            body.append(f"\n… +{hidden_count} lines", style=_TRUNC_STYLE)

    border_style: Style = Style(color="green" if success else "red")
    return Panel(
        Padding(body, pad=(0, 1)),
        title=title,
        title_align="left",
        border_style=border_style,
        expand=False,
    )


# ---------------------------------------------------------------------------
# ToolCallView — convenience bundle
# ---------------------------------------------------------------------------


@dataclass
class ToolCallView:
    """Bundle of renderables for a single tool invocation lifecycle.

    Holds the *call* renderable (shown before execution) and, optionally,
    the *result* renderable (shown after execution).  Use
    :meth:`set_result` to attach the result once available.

    Attributes
    ----------
    name:
        Tool name.
    params:
        Parameter mapping passed to :func:`render_tool_call`.
    call_renderable:
        Pre-computed call-line renderable.
    result_renderable:
        Result panel renderable, or ``None`` if not yet set.

    """

    name: str
    params: dict[str, Any] = field(default_factory=dict)
    call_renderable: RenderableType = field(init=False)
    result_renderable: RenderableType | None = field(default=None, init=False)

    def __post_init__(self) -> None:
        """Pre-compute the call-line renderable."""
        self.call_renderable = render_tool_call(
            self.name,
            self.params,
            status=ToolStatus.RUNNING,
        )

    def set_result(
        self,
        *,
        success: bool,
        output: str | None,
        exit_code: int | None = None,
        line_cap: int = DEFAULT_OUTPUT_LINE_CAP,
    ) -> None:
        """Compute and store the result renderable.

        Call this from the agent loop after the tool finishes.

        Parameters
        ----------
        success:
            Whether the tool invocation succeeded.
        output:
            Raw output string from the tool.
        exit_code:
            Optional integer exit code.
        line_cap:
            Maximum output lines to display.

        """
        self.result_renderable = render_tool_result(
            self.name,
            success=success,
            output=output,
            exit_code=exit_code,
            line_cap=line_cap,
        )

    def print_to(self, console: Console) -> None:
        """Print call + result (if available) to *console*.

        Parameters
        ----------
        console:
            A :class:`rich.console.Console` instance.

        """
        console.print(self.call_renderable)
        if self.result_renderable is not None:
            console.print(self.result_renderable)
