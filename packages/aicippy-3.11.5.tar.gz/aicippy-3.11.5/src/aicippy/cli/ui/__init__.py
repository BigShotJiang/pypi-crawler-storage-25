"""Claude-Code-style TUI rendering components for AiCippy.

Each module in this package is a self-contained, headless-testable
rendering unit (streaming, tool-call panels, status indicators, diff
rendering, input/slash-command UX). Components render via Rich and are
verified with ``rich.console.Console(record=True)``.
"""
