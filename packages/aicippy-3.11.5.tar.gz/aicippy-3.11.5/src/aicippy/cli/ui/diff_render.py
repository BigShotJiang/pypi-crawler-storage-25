"""Diff rendering for the AiCippy TUI — Claude-Code-style unified diff display.

Public API
----------
render_unified_diff(diff_text, *, max_lines=150) -> RenderableType
    Render a pre-computed unified-diff string with Rich syntax highlighting,
    a line-cap footer, and graceful empty/error handling.

render_file_change(path, old_text, new_text, *, max_lines=150) -> RenderableType
    Compute a unified diff from old/new text and render it with a file header
    that shows the path, addition count, and deletion count.

Both functions are self-contained (stdlib + rich only), never raise, and
degrade gracefully to plain ASCII on non-colour terminals.
"""

from __future__ import annotations

import difflib
import os
from typing import TYPE_CHECKING

from rich.columns import Columns
from rich.console import Console, RenderableType
from rich.panel import Panel
from rich.syntax import Syntax
from rich.text import Text

if TYPE_CHECKING:
    pass

# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

_NO_COLOR: bool = os.environ.get("NO_COLOR", "") != "" or os.environ.get("TERM", "") == "dumb"


def _count_changes(diff_lines: list[str]) -> tuple[int, int]:
    """Count additions and deletions from unified-diff body lines.

    Parameters
    ----------
    diff_lines:
        Raw lines of a unified diff (including leading +/-/@@ markers).

    Returns
    -------
    tuple[int, int]
        ``(additions, deletions)``

    """
    adds = sum(1 for ln in diff_lines if ln.startswith("+") and not ln.startswith("+++"))
    dels = sum(1 for ln in diff_lines if ln.startswith("-") and not ln.startswith("---"))
    return adds, dels


def _is_likely_binary(text: str) -> bool:
    """Return True if *text* appears to be binary/non-UTF-8 content."""
    try:
        text.encode("utf-8")
    except (UnicodeEncodeError, AttributeError):
        return True
    # Heuristic: if >30% of chars are non-printable (excluding common whitespace), treat as binary
    if not text:
        return False
    non_printable = sum(1 for ch in text if ord(ch) < 32 and ch not in "\t\n\r")
    return (non_printable / max(len(text), 1)) > 0.30


def _safe_str(value: object) -> str:
    """Coerce *value* to str, silently handling errors."""
    try:
        result = str(value) if not isinstance(value, str) else value
    except Exception:
        result = repr(value)
    return result


def _cap_lines(diff_text: str, max_lines: int) -> tuple[str, int]:
    """Truncate *diff_text* to *max_lines* lines.

    Returns
    -------
    tuple[str, int]
        The (possibly truncated) text and the number of remaining lines clipped.

    """
    lines = diff_text.splitlines(keepends=True)
    if len(lines) <= max_lines:
        return diff_text, 0
    visible = lines[:max_lines]
    remaining = len(lines) - max_lines
    return "".join(visible), remaining


def _footer_text(remaining: int) -> Text:
    """Build a styled '… +N more lines' footer."""
    t = Text()
    t.append("  … ", style="dim")
    t.append(f"+{remaining:,} more lines", style="bold dim")
    t.append(" (output truncated)", style="dim italic")
    return t


def _no_changes_renderable() -> RenderableType:
    """Return a renderable indicating an empty / no-change diff."""
    msg = Text("  no changes", style="dim italic")
    return Panel(msg, border_style="dim", padding=(0, 1))


def _header_text(path: str, adds: int, dels: int) -> Text:
    """Build a file-path header with add/del counts."""
    t = Text()
    t.append(" ", style="")
    t.append(path, style="bold cyan")
    t.append("  ")
    if adds:
        t.append(f"+{adds}", style="bold green")
    if adds and dels:
        t.append("  ")
    if dels:
        t.append(f"-{dels}", style="bold red")
    return t


def _build_syntax(diff_text: str) -> RenderableType:
    """Create a ``Syntax`` renderable for diff text.

    Falls back to a plain ``Text`` object when NO_COLOR is set or the
    diff text is suspiciously binary.
    """
    if _NO_COLOR or _is_likely_binary(diff_text):
        return Text(diff_text)
    return Syntax(
        diff_text,
        "diff",
        theme="ansi_dark",
        word_wrap=False,
        background_color="default",
    )


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def render_unified_diff(
    diff_text: object,
    *,
    max_lines: int = 150,
) -> RenderableType:
    """Render a unified-diff string with Rich syntax highlighting.

    Parameters
    ----------
    diff_text:
        A unified diff string (e.g. from ``difflib.unified_diff``).  Any
        non-string value is coerced; errors are caught and displayed as a
        warning panel.
    max_lines:
        Maximum number of diff lines to display.  If the diff is longer a
        '… +N more lines' footer is appended.  Defaults to 150.

    Returns
    -------
    RenderableType
        A Rich renderable that can be passed directly to
        ``Console.print()``.

    """
    if diff_text is None:
        return _no_changes_renderable()

    try:
        text = _safe_str(diff_text).rstrip()
    except Exception:
        text = ""

    if not text:
        return _no_changes_renderable()

    lines = text.splitlines()
    if not any(ln for ln in lines if ln.strip()):
        return _no_changes_renderable()

    visible_text, remaining = _cap_lines(text, max(1, max_lines))
    syntax = _build_syntax(visible_text)

    if remaining:
        from rich.console import Group  # local to avoid circular risk

        return Group(syntax, _footer_text(remaining))

    return syntax


def render_file_change(
    path: object,
    old_text: object,
    new_text: object,
    *,
    max_lines: int = 150,
) -> RenderableType:
    """Compute and render a unified diff between *old_text* and *new_text*.

    Parameters
    ----------
    path:
        File path shown in the header panel.  Coerced to str.
    old_text:
        Original file content.  Pass an empty string or ``None`` for new files.
    new_text:
        Updated file content.  Pass an empty string or ``None`` for deletions.
    max_lines:
        Maximum number of diff body lines to display before truncating.

    Returns
    -------
    RenderableType
        A Rich renderable with a header panel showing the path and change
        counts, followed by the diff body.

    """
    from rich.console import Group  # local import to avoid top-level side effects

    path_str = _safe_str(path) if path is not None else "<unknown>"
    old_str = _safe_str(old_text) if old_text is not None else ""
    new_str = _safe_str(new_text) if new_text is not None else ""

    # Detect binary content and bail out gracefully
    if _is_likely_binary(old_str) or _is_likely_binary(new_str):
        warning = Text()
        warning.append("  binary or non-text file: ", style="dim")
        warning.append(path_str, style="bold cyan")
        warning.append("  (diff not shown)", style="dim italic")
        return Panel(warning, border_style="yellow", padding=(0, 1))

    # Determine labels based on new/deleted file status
    is_new_file = old_str == "" and new_str != ""
    is_deleted_file = old_str != "" and new_str == ""

    old_label = "/dev/null" if is_new_file else f"a/{path_str}"
    new_label = "/dev/null" if is_deleted_file else f"b/{path_str}"

    # Compute diff
    old_lines = old_str.splitlines(keepends=True)
    new_lines = new_str.splitlines(keepends=True)

    # Ensure lines end with newline for uniform diff output
    if old_lines and not old_lines[-1].endswith("\n"):
        old_lines[-1] += "\n"
    if new_lines and not new_lines[-1].endswith("\n"):
        new_lines[-1] += "\n"

    diff_iter = difflib.unified_diff(
        old_lines,
        new_lines,
        fromfile=old_label,
        tofile=new_label,
        lineterm="",
    )

    try:
        diff_lines = list(diff_iter)
    except Exception:
        diff_lines = []

    if not diff_lines:
        adds, dels = 0, 0
        header = _header_text(path_str, adds, dels)
        body = _no_changes_renderable()
        return Group(Panel(header, border_style="dim", padding=(0, 0)), body)

    diff_text = "\n".join(diff_lines)
    adds, dels = _count_changes(diff_lines)
    header = _header_text(path_str, adds, dels)

    # Optionally annotate new/deleted file
    badge_parts: list[RenderableType] = []
    if is_new_file:
        badge = Text(" new file ", style="bold green on dark_green")
        badge_parts.append(badge)
    elif is_deleted_file:
        badge = Text(" deleted ", style="bold red on dark_red")
        badge_parts.append(badge)

    header_renderables: list[RenderableType] = [header]
    if badge_parts:
        header_renderables.append(Columns(badge_parts))

    header_group = Group(*header_renderables)
    header_panel = Panel(header_group, border_style="blue", padding=(0, 1))

    # Build body (with line cap)
    visible_text, remaining = _cap_lines(diff_text, max(1, max_lines))
    body: RenderableType = _build_syntax(visible_text)

    if remaining:
        return Group(header_panel, body, _footer_text(remaining))

    return Group(header_panel, body)


# ---------------------------------------------------------------------------
# Module-level console for optional standalone preview
# ---------------------------------------------------------------------------

def _preview(path: str = "example.py") -> None:
    """Print a demo diff to stdout — used only for manual inspection."""
    console = Console()
    old = "def hello():\n    print('hello')\n    return 0\n"
    new = (
        "def hello(name: str = 'world') -> int:\n"
        "    print(f'hello {name}')\n"
        "    return 0\n\n"
        "def goodbye() -> None:\n    pass\n"
    )
    console.print(render_file_change(path, old, new))
    console.print(render_unified_diff(""))
    console.print(render_file_change("new_file.py", "", new))
    console.print(render_file_change("deleted.py", old, ""))


if __name__ == "__main__":
    _preview()
