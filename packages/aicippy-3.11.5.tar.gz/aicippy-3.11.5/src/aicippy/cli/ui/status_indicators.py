"""Status and thinking indicators for the AiCippy TUI.

Provides:
- ``ThinkingIndicator`` — animated spinner + elapsed timer (Claude-Code-style).
  Exposes a deterministic ``render(elapsed)`` method for headless/test use,
  plus ``start()`` / ``stop()`` for real-time live rendering.
- ``AgentStatus`` / ``StatusLine`` — coloured-dot connection/agent status line
  with unicode and ASCII fallbacks.
- ``MultiAgentStatusRow`` — compact "N agents: M ✓, K running" summary.

All public callables are self-contained (stdlib + rich only).  Bad inputs are
handled gracefully; nothing raises on invalid state.
"""

from __future__ import annotations

import enum
import threading
import time
from typing import TYPE_CHECKING

from rich.console import Console
from rich.style import Style
from rich.text import Text

if TYPE_CHECKING:
    pass

# ---------------------------------------------------------------------------
# Spinner frame table
# Each entry is a list of frame strings cycled by elapsed time.
# ---------------------------------------------------------------------------
_SPINNER_FRAMES: list[str] = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]
_SPINNER_FRAMES_ASCII: list[str] = ["-", "\\", "|", "/"]
_SPINNER_FPS: float = 12.5  # frames per second


def _spinner_frame(elapsed: float, *, ascii_fallback: bool = False) -> str:
    """Return the spinner character for a given elapsed time (seconds)."""
    frames = _SPINNER_FRAMES_ASCII if ascii_fallback else _SPINNER_FRAMES
    index = int(elapsed * _SPINNER_FPS) % len(frames)
    return frames[index]


def _format_elapsed(elapsed: float) -> str:
    """Format an elapsed duration into a human-readable string.

    Examples::

        0.9  -> "0.9s"
        3.14 -> "3.1s"
        61.0 -> "1m 1s"
        3661 -> "1h 1m 1s"
    """
    elapsed = max(0.0, elapsed)
    if elapsed < 60.0:
        return f"{elapsed:.1f}s"
    total_s = int(elapsed)
    hours, remainder = divmod(total_s, 3600)
    minutes, seconds = divmod(remainder, 60)
    if hours:
        return f"{hours}h {minutes}m {seconds}s"
    return f"{minutes}m {seconds}s"


# ---------------------------------------------------------------------------
# ThinkingIndicator
# ---------------------------------------------------------------------------


class ThinkingIndicator:
    """Animated spinner with elapsed timer, Claude-Code-style.

    Usage — real-time (blocks the current thread in a background thread)::

        indicator = ThinkingIndicator(label="OdiN thinking")
        indicator.start()
        ...heavy work...
        indicator.stop()

    Usage — deterministic / headless (for tests or custom render loops)::

        indicator = ThinkingIndicator(label="OdiN thinking")
        renderable = indicator.render(elapsed=2.3)
        console.print(renderable)

    The ``render`` method never mutates state and never reads the wall clock, so
    tests can call it with arbitrary elapsed values.
    """

    def __init__(
        self,
        label: str = "thinking",
        *,
        style: str = "bold cyan",
        elapsed_style: str = "dim",
        ascii_fallback: bool = False,
        refresh_rate: float = _SPINNER_FPS,
        console: Console | None = None,
    ) -> None:
        r"""Initialise a ThinkingIndicator.

        Args:
            label: Text shown after the spinner, e.g. ``"OdiN thinking"``.
            style: Rich style applied to the spinner character.
            elapsed_style: Rich style applied to the elapsed-time suffix.
            ascii_fallback: Use ASCII ``-\|/`` frames instead of braille.
            refresh_rate: Frames per second for the real-time live loop.
            console: Optional ``Console`` to use for the live display;
                defaults to a new stderr console.

        """
        self._label = str(label) if label else "thinking"
        self._style = style
        self._elapsed_style = elapsed_style
        self._ascii_fallback = bool(ascii_fallback)
        self._refresh_rate = max(1.0, float(refresh_rate))
        self._console = console

        self._thread: threading.Thread | None = None
        self._stop_event = threading.Event()
        self._start_time: float | None = None

    # ------------------------------------------------------------------
    # Public deterministic API (no side effects, no real-time clock)
    # ------------------------------------------------------------------

    def render(self, elapsed: float) -> Text:
        """Return a Rich ``Text`` renderable for the given *elapsed* seconds.

        This is the headless/test-friendly API.  It never reads the clock.

        Args:
            elapsed: Seconds elapsed since the operation began.  Values < 0
                are clamped to 0.

        Returns:
            A ``rich.text.Text`` with spinner, label, and elapsed time.

        """
        elapsed = max(0.0, float(elapsed))
        frame = _spinner_frame(elapsed, ascii_fallback=self._ascii_fallback)
        elapsed_str = _format_elapsed(elapsed)

        text = Text()
        text.append(frame, style=Style.parse(self._style))
        text.append(" ")
        text.append(self._label, style=Style.parse(self._style))
        text.append("… ", style=Style.parse(self._style))
        text.append(elapsed_str, style=Style.parse(self._elapsed_style))
        return text

    # Alias kept for API symmetry with frame-generator style helpers
    frame = render

    @property
    def label(self) -> str:
        """The current label string."""
        return self._label

    @label.setter
    def label(self, value: str) -> None:
        """Update the label; silently ignores non-string or empty values."""
        if value and isinstance(value, str):
            self._label = value

    # ------------------------------------------------------------------
    # Real-time live loop
    # ------------------------------------------------------------------

    def start(self) -> None:
        """Start the spinner in a background daemon thread.

        If already running, this is a no-op.
        """
        if self._thread is not None and self._thread.is_alive():
            return
        self._stop_event.clear()
        self._start_time = time.monotonic()
        self._thread = threading.Thread(target=self._run, daemon=True, name="aicippy-thinking")
        self._thread.start()

    def stop(self) -> None:
        """Stop the spinner and clear the live line.

        Safe to call even if the indicator was never started.
        """
        self._stop_event.set()
        if self._thread is not None:
            self._thread.join(timeout=2.0)
            self._thread = None
        self._start_time = None

    @property
    def is_running(self) -> bool:
        """True if the background thread is currently active."""
        return self._thread is not None and self._thread.is_alive()

    def _run(self) -> None:
        """Background thread: print spinner frames using rich Live."""
        from rich.live import Live

        console = self._console or Console(stderr=True)
        start = self._start_time or time.monotonic()

        interval = 1.0 / self._refresh_rate
        with Live(console=console, refresh_per_second=self._refresh_rate, transient=True) as live:
            while not self._stop_event.is_set():
                elapsed = time.monotonic() - start
                live.update(self.render(elapsed))
                time.sleep(interval)


# ---------------------------------------------------------------------------
# AgentStatus — connection / agent status line
# ---------------------------------------------------------------------------


class AgentState(enum.Enum):
    """Possible states for a connection or agent."""

    CONNECTED = "connected"
    CONNECTING = "connecting"
    DISCONNECTED = "disconnected"
    ERROR = "error"
    IDLE = "idle"
    RUNNING = "running"


# Map each state to (unicode dot, ascii fallback, rich colour)
_STATE_META: dict[AgentState, tuple[str, str, str]] = {
    AgentState.CONNECTED: ("●", "[OK]", "green"),
    AgentState.CONNECTING: ("◌", "[..]", "yellow"),
    AgentState.DISCONNECTED: ("○", "[--]", "dim white"),
    AgentState.ERROR: ("✖", "[ER]", "bold red"),
    AgentState.IDLE: ("◎", "[  ]", "blue"),
    AgentState.RUNNING: ("◉", "[>>]", "cyan"),
}


class StatusLine:
    """A single coloured-dot status line for an agent or connection.

    Example output::

        ● CONNECTED  (green dot, plain text)
        OdiN ● CONNECTED

    Args:
        name: Optional name prefix, e.g. ``"OdiN"``.
        state: Initial ``AgentState``; defaults to ``DISCONNECTED``.
        ascii_fallback: Use ASCII bracket codes instead of unicode dots.

    """

    def __init__(
        self,
        name: str = "",
        state: AgentState = AgentState.DISCONNECTED,
        *,
        ascii_fallback: bool = False,
    ) -> None:
        self._name = str(name)
        self._state: AgentState = state if isinstance(state, AgentState) else AgentState.DISCONNECTED
        self._ascii_fallback = bool(ascii_fallback)

    @property
    def state(self) -> AgentState:
        """Current agent state."""
        return self._state

    @state.setter
    def state(self, value: AgentState) -> None:
        """Set the state; silently ignores invalid values."""
        if isinstance(value, AgentState):
            self._state = value

    def render(self) -> Text:
        """Return a Rich ``Text`` renderable for the current state.

        Returns:
            Coloured dot + optional name + state label as ``rich.text.Text``.

        """
        dot_unicode, dot_ascii, colour = _STATE_META.get(
            self._state,
            ("?", "[?]", "white"),
        )
        dot = dot_ascii if self._ascii_fallback else dot_unicode
        label = self._state.value.upper()

        text = Text()
        if self._name:
            text.append(self._name, style="bold")
            text.append(" ")
        text.append(dot, style=Style.parse(colour))
        text.append(" ")
        text.append(label, style=Style.parse(colour))
        return text


# ---------------------------------------------------------------------------
# MultiAgentStatusRow
# ---------------------------------------------------------------------------


class MultiAgentStatusRow:
    """Compact summary row for multiple agents.

    Example output::

        3 agents: 2 ✓, 1 running
        3 agents: 2 OK, 1 running   (ASCII fallback)

    Args:
        total: Total number of agents.
        done: Agents that have completed successfully.
        running: Agents currently active.
        ascii_fallback: Use ``OK`` instead of ``✓``.

    """

    _CHECK_UNICODE = "✓"
    _CHECK_ASCII = "OK"

    def __init__(
        self,
        total: int = 0,
        done: int = 0,
        running: int = 0,
        *,
        ascii_fallback: bool = False,
    ) -> None:
        self._total = max(0, int(total))
        self._done = max(0, int(done))
        self._running = max(0, int(running))
        self._ascii_fallback = bool(ascii_fallback)

    def update(self, *, total: int | None = None, done: int | None = None, running: int | None = None) -> None:
        """Update counts; ignores negative or non-integer values."""
        if total is not None and isinstance(total, int) and total >= 0:
            self._total = total
        if done is not None and isinstance(done, int) and done >= 0:
            self._done = done
        if running is not None and isinstance(running, int) and running >= 0:
            self._running = running

    def render(self) -> Text:
        """Return a ``rich.text.Text`` with the compact agent summary.

        Returns:
            Text like ``"3 agents: 2 ✓, 1 running"``.

        """
        check = self._CHECK_ASCII if self._ascii_fallback else self._CHECK_UNICODE
        agent_word = "agent" if self._total == 1 else "agents"

        text = Text()
        text.append(f"{self._total} {agent_word}: ", style="bold")
        text.append(f"{self._done} {check}", style="green")
        text.append(", ", style="dim")
        text.append(f"{self._running} running", style="cyan")
        return text

    # Convenience read-only properties
    @property
    def total(self) -> int:
        """Total number of agents."""
        return self._total

    @property
    def done(self) -> int:
        """Number of completed agents."""
        return self._done

    @property
    def running(self) -> int:
        """Number of running agents."""
        return self._running


# ---------------------------------------------------------------------------
# Module-level convenience factory
# ---------------------------------------------------------------------------


def make_thinking_indicator(
    agent_name: str = "OdiN",
    *,
    ascii_fallback: bool = False,
    console: Console | None = None,
) -> ThinkingIndicator:
    """Create a ``ThinkingIndicator`` with a standard ``"<name> thinking"`` label.

    Args:
        agent_name: The agent name shown in the label (e.g. ``"OdiN"``).
        ascii_fallback: Use ASCII spinner frames.
        console: Optional Rich console; used for the live display.

    Returns:
        A configured ``ThinkingIndicator`` ready to ``start()`` or ``render()``.

    """
    label = f"{agent_name} thinking"
    return ThinkingIndicator(label=label, ascii_fallback=ascii_fallback, console=console)


__all__ = [
    "AgentState",
    "MultiAgentStatusRow",
    "StatusLine",
    "ThinkingIndicator",
    "make_thinking_indicator",
]
