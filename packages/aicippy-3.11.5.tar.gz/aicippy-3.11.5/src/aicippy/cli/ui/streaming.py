"""Live token-streaming renderer for the AiCippy CLI.

Renders assistant output token-by-token using ``rich.live.Live`` with an
animated cursor, agent-label prefix, optional footer (elapsed time + token
count), and a clean finalize that leaves the full text in the scrollback.

Usage (context-manager style)::

    from rich.console import Console
    from aicippy.cli.ui.streaming import StreamRenderer

    console = Console()
    with StreamRenderer(console, label="OdiN") as renderer:
        for token in token_source:
            renderer.feed(token)
    # Full text remains in scrollback; cursor gone.

``finalize()`` is safe to call multiple times (idempotent).
"""

from __future__ import annotations

import time
from contextlib import suppress
from types import TracebackType

from rich.console import Console
from rich.live import Live
from rich.markup import escape
from rich.text import Text

# Cursor frames cycled while streaming is in progress.
_CURSOR_FRAMES: tuple[str, ...] = ("▋", "▌", "▍", "▎", "▏", "▎", "▍", "▌")

# Label style — matches Claude-Code's dim-bold prefix aesthetic.
_LABEL_STYLE = "bold cyan"
_CURSOR_STYLE = "blink bold white"
_FOOTER_STYLE = "dim"
_TEXT_STYLE = ""


class StreamRenderer:
    """Render streaming assistant tokens in-place via ``rich.live.Live``.

    Parameters
    ----------
    console:
        The ``rich.console.Console`` instance to render into.
    label:
        Agent label displayed as a prefix on every frame (e.g. ``"OdiN"``).
    show_footer:
        When *True* (default) a footer line shows elapsed time and token count
        while streaming; it disappears after ``finalize()``.
    refresh_per_second:
        Passed to ``rich.live.Live`` — controls how often the display is
        redrawn.  Default is 15 fps which feels fluid without burning CPU.

    """

    def __init__(
        self,
        console: Console,
        *,
        label: str = "Assistant",
        show_footer: bool = True,
        refresh_per_second: int = 15,
    ) -> None:
        self._console = console
        self._label = label
        self._show_footer = show_footer
        self._refresh_per_second = refresh_per_second

        self._buffer: list[str] = []
        self._token_count: int = 0
        self._cursor_frame: int = 0
        self._started_at: float = 0.0
        self._live: Live | None = None
        self._finalised: bool = False

    # ------------------------------------------------------------------
    # Internal rendering helpers
    # ------------------------------------------------------------------

    def _label_prefix(self) -> Text:
        """Return the styled agent-label prefix segment."""
        prefix = Text()
        prefix.append(f"{self._label}", style=_LABEL_STYLE)
        prefix.append(" › ", style="dim")
        return prefix

    def _build_renderable(self, *, with_cursor: bool) -> Text:
        """Build the full ``Text`` renderable for the current frame.

        Parameters
        ----------
        with_cursor:
            When *True* append the animated blinking cursor after the content.

        """
        renderable = self._label_prefix()
        content = "".join(self._buffer)
        renderable.append(escape(content), style=_TEXT_STYLE)
        if with_cursor:
            frame = _CURSOR_FRAMES[self._cursor_frame % len(_CURSOR_FRAMES)]
            renderable.append(frame, style=_CURSOR_STYLE)
        return renderable

    def _build_group(self, *, with_cursor: bool) -> Text | list[Text]:
        """Return the renderable(s) for the current Live frame."""
        lines: list[Text] = [self._build_renderable(with_cursor=with_cursor)]
        if self._show_footer and with_cursor:
            elapsed = time.monotonic() - self._started_at
            footer = Text(
                f"  {self._token_count} tokens · {elapsed:.1f}s",
                style=_FOOTER_STYLE,
            )
            lines.append(footer)
        if len(lines) == 1:
            return lines[0]
        return lines  # type: ignore[return-value]

    def _refresh(self) -> None:
        """Push the current frame to the Live display."""
        if self._live is not None:
            self._cursor_frame += 1
            self._live.update(self._build_group(with_cursor=True))

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def start(self) -> None:
        """Start the Live display.  Called automatically by ``__enter__``."""
        if self._live is not None:
            return
        self._started_at = time.monotonic()
        # Start with an empty renderable so Live allocates its region
        # before the first token arrives.
        self._live = Live(
            self._build_group(with_cursor=True),
            console=self._console,
            refresh_per_second=self._refresh_per_second,
            # transient=False keeps the last frame in scrollback on stop.
            transient=False,
        )
        self._live.start(refresh=True)

    def feed(self, token: str) -> None:
        """Append *token* to the buffer and refresh the display.

        Parameters
        ----------
        token:
            A single token (word-piece, character, or arbitrary string chunk).
            Empty strings are accepted and ignored gracefully.

        """
        if not token:
            return
        self._buffer.append(token)
        self._token_count += 1
        self._refresh()

    def finalize(self) -> None:
        """Stop the Live display and print the final text to the scrollback.

        Safe to call multiple times; subsequent calls are no-ops.
        """
        if self._finalised:
            return
        self._finalised = True

        if self._live is not None:
            # Update to the cursor-free final renderable before stopping.
            final = self._build_renderable(with_cursor=False)
            self._live.update(final)
            with suppress(Exception):
                self._live.stop()
            self._live = None

        elif not self._buffer:
            # Never started a Live session AND no content — nothing to print.
            return
        else:
            # start() was never called; just print synchronously.
            self._console.print(self._build_renderable(with_cursor=False))

    def get_text(self) -> str:
        """Return the accumulated text seen so far (without label or cursor)."""
        return "".join(self._buffer)

    @property
    def token_count(self) -> int:
        """Number of non-empty tokens fed since ``start()``."""
        return self._token_count

    # ------------------------------------------------------------------
    # Context-manager protocol
    # ------------------------------------------------------------------

    def __enter__(self) -> StreamRenderer:
        """Start the Live display and return *self*."""
        self.start()
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        """Finalize on exit — even when an exception is raised."""
        self.finalize()
