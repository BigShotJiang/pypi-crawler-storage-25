"""Slash-command UX engine for the aicippy CLI.

Provides a pure-logic, headlessly-testable slash-command registry with
Rich-based rendering for the interactive terminal input loop.  No live I/O,
no prompt_toolkit dependency - only the standard library + rich.

Public API
----------
SlashCommand        - immutable definition of one slash command.
CommandRegistry     - register, look-up, and iterate commands.
match()             - ranked partial-match lookup.
parse()             - split a dispatched line into (name, args).
render_palette()    - Rich renderable for the autocomplete dropdown.
render_help()       - Rich renderable for the full /help table.
"""

from __future__ import annotations

import re
import shlex
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from rich.console import Group
from rich.padding import Padding
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

if TYPE_CHECKING:
    from collections.abc import Sequence

    from rich.console import RenderableType

# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------

_TRIGGER_RE = re.compile(r"^[/\\]")


@dataclass(frozen=True)
class SlashCommand:
    """An immutable slash-command definition.

    Attributes
    ----------
    name:
        Canonical name without the leading slash, e.g. ``"help"``.
    summary:
        One-line description shown in the palette and help table.
    args:
        Optional human-readable argument hint, e.g. ``"<query>"``.
    aliases:
        Alternative names that resolve to this command.
    group:
        Logical group for the help table (e.g. ``"Navigation"``).

    """

    name: str
    summary: str
    args: str = ""
    aliases: tuple[str, ...] = field(default_factory=tuple)
    group: str = "General"

    def all_names(self) -> tuple[str, ...]:
        """Return the canonical name plus all aliases."""
        return (self.name, *self.aliases)


# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------


class CommandRegistry:
    """Thread-safe (GIL-sufficient) registry of SlashCommand objects.

    Example:
    -------
    >>> reg = CommandRegistry()
    >>> reg.register(SlashCommand("help", "Show this help"))
    >>> reg.get("help").name
    'help'

    """

    def __init__(self) -> None:
        """Initialise an empty registry."""
        self._commands: dict[str, SlashCommand] = {}   # canonical name → cmd
        self._alias_map: dict[str, str] = {}           # alias → canonical name

    def register(self, cmd: SlashCommand) -> None:
        """Add *cmd* to the registry.

        Parameters
        ----------
        cmd:
            The command to register.  Raises ``ValueError`` if a command
            with the same canonical name is already registered.

        """
        name_lower = cmd.name.lower()
        if name_lower in self._commands:
            msg = f"Command already registered: {cmd.name!r}"
            raise ValueError(msg)
        self._commands[name_lower] = cmd
        for alias in cmd.aliases:
            alias_lower = alias.lower()
            if alias_lower not in self._alias_map:
                self._alias_map[alias_lower] = name_lower

    def get(self, name: str) -> SlashCommand | None:
        """Look up a command by canonical name or alias (case-insensitive)."""
        key = name.lower().lstrip("/\\")
        if key in self._commands:
            return self._commands[key]
        canonical = self._alias_map.get(key)
        if canonical:
            return self._commands.get(canonical)
        return None

    def all_commands(self) -> list[SlashCommand]:
        """Return all registered commands sorted by name."""
        return sorted(self._commands.values(), key=lambda c: c.name)

    def groups(self) -> dict[str, list[SlashCommand]]:
        """Return commands grouped by their *group* attribute (sorted)."""
        result: dict[str, list[SlashCommand]] = {}
        for cmd in self.all_commands():
            result.setdefault(cmd.group, []).append(cmd)
        return dict(sorted(result.items()))


# ---------------------------------------------------------------------------
# Match / lookup
# ---------------------------------------------------------------------------

_SCORE_PREFIX = 0
_SCORE_SUBSTRING = 1
_SCORE_NO_MATCH = 99


def _strip_trigger(text: str) -> str:
    r"""Remove a leading ``/`` or ``\`` from *text*."""
    return text.lstrip("/\\")


def _score_command(cmd: SlashCommand, query: str) -> int:
    """Return a sort key for *cmd* against *query* (lower = better match)."""
    query_lower = query.lower()
    for name in cmd.all_names():
        n = name.lower()
        if n.startswith(query_lower):
            return _SCORE_PREFIX
        if query_lower in n:
            return _SCORE_SUBSTRING
    return _SCORE_NO_MATCH


def match(registry: CommandRegistry, prefix: str) -> list[SlashCommand]:
    r"""Return commands that match *prefix*, ranked best-first.

    Matching rules
    --------------
    * Leading ``/`` or ``\`` is ignored (both are valid trigger characters).
    * Empty *prefix* (or just a trigger character) returns all commands.
    * Prefix matches (name **starts with** query) rank above substring matches.
    * Within the same rank, commands are sorted alphabetically.
    * Case-insensitive throughout.
    * Unrecognised input returns an empty list.

    Parameters
    ----------
    registry:
        The populated :class:`CommandRegistry` to search.
    prefix:
        Raw user input, e.g. ``"/mo"`` or ``"mo"``.

    Returns
    -------
    list[SlashCommand]
        Ranked list of matching commands; empty if none match.

    """
    if not isinstance(prefix, str):
        return []

    query = _strip_trigger(prefix).strip()

    # Empty query → return everything
    if not query:
        return registry.all_commands()

    scored: list[tuple[int, str, SlashCommand]] = []
    for cmd in registry.all_commands():
        score = _score_command(cmd, query)
        if score < _SCORE_NO_MATCH:
            scored.append((score, cmd.name, cmd))

    scored.sort(key=lambda t: (t[0], t[1]))
    return [cmd for _, _, cmd in scored]


# ---------------------------------------------------------------------------
# Parse
# ---------------------------------------------------------------------------


def parse(line: str) -> tuple[str, list[str]]:
    r"""Split *line* into ``(command_name, args_list)``.

    The command name is returned **without** the leading trigger character and
    in lower-case.  Argument splitting uses :func:`shlex.split` so quoted
    strings are handled correctly.  Never raises on weird input.

    Parameters
    ----------
    line:
        A raw command line, e.g. ``"/search 'foo bar' baz"`` or
        ``"\clear"``.

    Returns
    -------
    tuple[str, list[str]]
        ``(name, args)`` where *name* may be empty and *args* may be empty.

    Examples
    --------
    >>> parse("/help")
    ('help', [])
    >>> parse("/search 'foo bar' baz")
    ('search', ['foo bar', 'baz'])
    >>> parse("  /  ")
    ('', [])

    """
    if not isinstance(line, str):
        return ("", [])

    stripped = line.strip()
    if not stripped:
        return ("", [])

    # Split on whitespace (honour quotes) - never raise
    try:
        parts = shlex.split(stripped)
    except ValueError:
        # Unmatched quotes etc. - fall back to naive split
        parts = stripped.split()

    if not parts:
        return ("", [])

    raw_cmd = parts[0]
    name = _strip_trigger(raw_cmd).lower()
    args = parts[1:] if len(parts) > 1 else []
    return (name, args)


# ---------------------------------------------------------------------------
# Rendering
# ---------------------------------------------------------------------------

_PALETTE_MAX_ROWS = 8   # mirror typical IDE autocomplete height
_CMD_STYLE = "bold cyan"
_ALIAS_STYLE = "dim cyan"
_ARG_STYLE = "dim white"
_SUMMARY_STYLE = "white"
_BORDER_STYLE = "bright_black"
_GROUP_STYLE = "bold yellow"


def render_palette(matches: Sequence[SlashCommand]) -> RenderableType:
    """Render a compact autocomplete dropdown panel for *matches*.

    Parameters
    ----------
    matches:
        An ordered sequence of :class:`SlashCommand` objects to display,
        typically the output of :func:`match`.

    Returns
    -------
    RenderableType
        A :class:`rich.panel.Panel` wrapping a table; ready to pass to
        ``Console.print()``.  Returns an empty panel when *matches* is empty.

    """
    visible = list(matches)[:_PALETTE_MAX_ROWS]

    tbl = Table.grid(padding=(0, 1))
    tbl.add_column("cmd", no_wrap=True, min_width=16)
    tbl.add_column("args", no_wrap=True, min_width=12)
    tbl.add_column("summary")

    if not visible:
        tbl.add_row(
            Text("(no matches)", style="dim italic"),
            Text(""),
            Text(""),
        )
    else:
        for cmd in visible:
            # Build command cell: canonical name + aliases abbreviated
            cmd_text = Text(f"/{cmd.name}", style=_CMD_STYLE)
            if cmd.aliases:
                alias_str = ", ".join(f"/{a}" for a in cmd.aliases)
                cmd_text.append(f"  {alias_str}", style=_ALIAS_STYLE)

            args_text = Text(cmd.args or "", style=_ARG_STYLE)
            summary_text = Text(cmd.summary, style=_SUMMARY_STYLE)

            tbl.add_row(cmd_text, args_text, summary_text)

    overflow_count = len(matches) - len(visible)
    if overflow_count > 0:
        more_text = Text(f"  … and {overflow_count} more", style="dim italic")
        content: RenderableType = Group(tbl, Padding(more_text, (0, 0, 0, 1)))
    else:
        content = tbl

    return Panel(
        content,
        title=Text("Slash Commands", style="bold"),
        border_style=_BORDER_STYLE,
        padding=(0, 1),
    )


def render_help(registry: CommandRegistry) -> RenderableType:
    """Render a full ``/help``-style reference panel.

    Commands are grouped by their *group* attribute.  Each group gets its own
    sub-heading row inside a single bordered table.

    Parameters
    ----------
    registry:
        The :class:`CommandRegistry` to render.

    Returns
    -------
    RenderableType
        A :class:`rich.panel.Panel` containing a :class:`rich.table.Table`.

    """
    tbl = Table(
        show_header=True,
        header_style="bold magenta",
        border_style=_BORDER_STYLE,
        show_lines=False,
        expand=True,
    )
    tbl.add_column("Command", style=_CMD_STYLE, no_wrap=True, min_width=18)
    tbl.add_column("Arguments", style=_ARG_STYLE, no_wrap=True, min_width=14)
    tbl.add_column("Description", style=_SUMMARY_STYLE)
    tbl.add_column("Aliases", style=_ALIAS_STYLE, no_wrap=True)

    groups = registry.groups()
    group_names = list(groups.keys())

    for idx, group_name in enumerate(group_names):
        cmds = groups[group_name]

        # Group separator row
        if idx > 0:
            tbl.add_row("", "", "", "")

        tbl.add_row(
            Text(f"── {group_name} ──", style=_GROUP_STYLE),
            Text(""),
            Text(""),
            Text(""),
        )

        for cmd in cmds:
            aliases_str = ", ".join(f"/{a}" for a in cmd.aliases) if cmd.aliases else ""
            tbl.add_row(
                Text(f"/{cmd.name}"),
                Text(cmd.args),
                Text(cmd.summary),
                Text(aliases_str),
            )

    return Panel(
        tbl,
        title=Text(" aicippy  Commands", style="bold cyan"),
        subtitle=Text("Type /command [args] to run", style="dim"),
        border_style="cyan",
        padding=(0, 1),
    )


# ---------------------------------------------------------------------------
# Built-in default registry
# ---------------------------------------------------------------------------


def default_registry() -> CommandRegistry:
    """Return a pre-populated registry with aicippy's built-in commands.

    This is the single source of truth for all slash commands.  The
    interactive loop's completer, ``/help`` handler, and dispatcher all
    call this function (or accept a registry built on top of it) so that
    adding a command here automatically propagates everywhere.
    """
    reg = CommandRegistry()

    # -- General -------------------------------------------------------------
    _cmds_general = [
        SlashCommand("help", "Show this help panel", args="[command]", group="General"),
        SlashCommand("clear", "Clear the terminal screen", group="General", aliases=("cls",)),
        SlashCommand("exit", "Exit aicippy", group="General", aliases=("quit", "q")),
        SlashCommand("version", "Print version information", group="General", aliases=("ver",)),
    ]

    # -- Navigation ----------------------------------------------------------
    _cmds_nav = [
        SlashCommand("model", "Switch active AI model", args="<name>", group="Navigation", aliases=("m",)),
        SlashCommand("mode", "Set interaction mode (chat/agent/plan)", args="<mode>", group="Navigation"),
        SlashCommand("context", "Show current context window stats", group="Navigation", aliases=("ctx",)),
        SlashCommand("history", "Browse conversation history", args="[n]", group="Navigation", aliases=("hist",)),
    ]

    # -- Agent / Tasks -------------------------------------------------------
    _cmds_agent = [
        SlashCommand("run", "Run an agent task inline", args="<task>", group="Agent"),
        SlashCommand("plan", "Generate a task plan", args="<goal>", group="Agent"),
        SlashCommand("review", "Review last agent output", group="Agent"),
        SlashCommand("stop", "Interrupt a running agent", group="Agent"),
        SlashCommand("retry", "Retry the last failed command", group="Agent"),
    ]

    # -- Files & Project -----------------------------------------------------
    _cmds_files = [
        SlashCommand("open", "Open a file in the editor pane", args="<path>", group="Files"),
        SlashCommand("diff", "Show git diff for current changes", group="Files"),
        SlashCommand("commit", "Stage and commit with AI message", args="[message]", group="Files"),
        SlashCommand("upload", "Upload a file to the session context", args="<path>", group="Files"),
    ]

    # -- Settings ------------------------------------------------------------
    _cmds_settings = [
        SlashCommand("config", "Open settings editor", group="Settings", aliases=("cfg",)),
        SlashCommand("theme", "Switch terminal colour theme", args="<name>", group="Settings"),
        SlashCommand("verbose", "Toggle verbose/debug logging", group="Settings"),
        SlashCommand("billing", "Show plan and usage summary", group="Settings"),
    ]

    for cmd in [*_cmds_general, *_cmds_nav, *_cmds_agent, *_cmds_files, *_cmds_settings]:
        reg.register(cmd)

    return reg
