"""Pure, testable logic for the interactive login prompt.

Kept free of any I/O, Rich, or network dependencies so the login
state machine (email normalization/validation, login-method parsing,
OTP-code validation) can be unit-tested deterministically. The actual
rendering and stdin reads live in ``cli.main``; this module only
decides *what* a given input means.
"""

from __future__ import annotations

import re
from enum import StrEnum
from typing import Final

# RFC-5321 max length; same regex the CLI has always used for emails.
EMAIL_MAX_LENGTH: Final[int] = 254
_EMAIL_REGEX: Final[re.Pattern[str]] = re.compile(r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$")
_OTP_REGEX: Final[re.Pattern[str]] = re.compile(r"^\d{6}$")

# Strip stray control characters (notably the Windows CR) that can ride
# along with a pasted/typed line and corrupt validation.
_CONTROL_CHARS: Final[str] = "".join(chr(c) for c in range(0, 32)) + "\x7f"


class LoginMethod(StrEnum):
    """Canonical login methods."""

    PASSWORD = "password"
    OTP = "otp"


# Lenient alias table: accept the digit, the canonical name, a single
# letter, or the menu label itself.
_METHOD_ALIASES: Final[dict[str, LoginMethod]] = {
    "1": LoginMethod.PASSWORD,
    "p": LoginMethod.PASSWORD,
    "password": LoginMethod.PASSWORD,
    "email+password": LoginMethod.PASSWORD,
    "email + password": LoginMethod.PASSWORD,
    "email password": LoginMethod.PASSWORD,
    "2": LoginMethod.OTP,
    "o": LoginMethod.OTP,
    "otp": LoginMethod.OTP,
    "code": LoginMethod.OTP,
    "email otp": LoginMethod.OTP,
    "email otp (verification code)": LoginMethod.OTP,
}


def clean_line(raw: str | None) -> str:
    """Normalize a raw input line: drop control chars, surrounding quotes, whitespace."""
    if not raw:
        return ""
    cleaned = raw.translate({ord(c): None for c in _CONTROL_CHARS})
    cleaned = cleaned.strip().strip("\"'").strip()
    return cleaned


def normalize_email(raw: str | None) -> str:
    """Clean and lowercase an email line for validation/use."""
    return clean_line(raw).lower()


def is_valid_email(email: str) -> bool:
    """Return True if *email* is a well-formed address within length limits."""
    return 0 < len(email) <= EMAIL_MAX_LENGTH and _EMAIL_REGEX.match(email) is not None


def parse_login_choice(raw: str | None, default: LoginMethod = LoginMethod.PASSWORD) -> LoginMethod | None:
    """Map a raw menu input to a LoginMethod.

    Empty input returns *default*. Unrecognized input returns None so
    the caller can re-prompt inline (without redrawing the whole menu).
    """
    cleaned = clean_line(raw).lower()
    if not cleaned:
        return default
    return _METHOD_ALIASES.get(cleaned)


def is_valid_otp(raw: str | None) -> bool:
    """Return True if *raw* is exactly six digits (after cleaning)."""
    return _OTP_REGEX.match(clean_line(raw)) is not None
