"""AiCippY Textual TUI — A7THAVA-powered agent with streaming, auto-execution, workspace awareness."""

from __future__ import annotations

import base64
import json
import platform
import re
import subprocess
import threading
import time
from pathlib import Path
from typing import Any

from textual import on, work
from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical, VerticalScroll
from textual.css.query import NoMatches
from textual.reactive import reactive
from textual.widgets import Button, Static, TextArea

from aicippy.cli.tui_tools import execute_tool, get_llama4_tool_definitions, parse_tool_calls

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

DISPLAY_NAMES: dict[str, str] = {"odin": "OdiN", "arjuna": "ArjunA"}
MEMORY_FILE = Path.home() / ".aicippy" / "session_memory.json"
MAX_AUTO_EXEC_TURNS = 50
CMD_TIMEOUT_SECONDS = 120
SHELL_RE = re.compile(r"```(?:powershell|bash|sh|shell|cmd)\n(.*?)```", re.DOTALL)
FILE_RE = re.compile(r"```(?:typescript|python|tsx|ts|py|json|css|html|yaml|toml)\n(.*?)```", re.DOTALL)

# System prompt for ArjunA (code-block fallback mode)
_AGENT_SYSTEM_PROMPT_CODEBLOCK = """You are {agent_name}, an elite full-stack developer agent.
Output shell commands in ```powershell (Windows) or ```bash (Unix) code blocks.
The TUI auto-executes every code block. Never ask for confirmation. Say DONE when finished.
PLATFORM: {platform}  CWD: {cwd}
"""

# System prompt for OdiN — Llama 4 native tool calling with streaming.
# Tool definitions are embedded in the system prompt (Llama 4 native format).
# The model outputs JSON tool calls which the TUI parses and executes.
_AGENT_SYSTEM_PROMPT_TOOLS = """You are {agent_name}, an elite full-stack developer \
agent running inside the AiCippY CLI.
You are an expert in function composition. You MUST invoke functions to complete tasks. Follow these strict guidelines:

1. FUNCTION CALLS:
- ONLY use functions that are listed in the function list below
- If ALL required parameters are present: output ONLY the function call(s) as JSON array
- Use exact format:
[
  {{"name": "tool_name", "parameters": {{"param1": "value1", "param2": "value2"}}}}
]

2. EXECUTION RULES:
- NEVER ask the user for permission or confirmation. Execute directly.
- Work step by step: call one function, wait for the tool response, then proceed.
- If a function fails, analyze the error and retry with corrected parameters.
- Call the "done" function with a summary when ALL tasks are complete.
- For multi-file changes, call file_write for each file separately.
- You are fully autonomous. The user expects action, not explanation.
- NEVER combine text and function calls in the same response.
- NEVER add explanatory text before or after function calls.

3. TOOL RESPONSE HANDLING:
- When receiving tool responses: analyze the result, then call the next function.
- If the result shows an error, fix it and retry.

PLATFORM: {platform}
CWD: {cwd}

Here is a list of functions in JSON format that you can invoke:
{tools_json}
"""

# Gemini API endpoint for ArjunA (GCP Vertex AI-compatible)
_GEMINI_SECRET_ID = "vibekaro/gemini-api-key"
_GEMINI_ENDPOINT = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent"


def _dn(key: str) -> str:
    """Return display name for agent key."""
    return DISPLAY_NAMES.get(key.lower(), key) if key else "OdiN"


# ---------------------------------------------------------------------------
# Safety: blocklist of commands that should never be auto-executed
# ---------------------------------------------------------------------------

_BLOCKED_CMDS: set[str] = {
    "rm -rf /",
    "format c:",
    "del /f /s /q",
    ":(){ :|:& };:",
    "mkfs",
    "> /dev/sda",
}


def _is_blocked_cmd(cmd: str) -> bool:
    """Return True if *cmd* matches any entry in the dangerous-command blocklist."""
    lower = cmd.lower().strip()
    return any(blocked in lower for blocked in _BLOCKED_CMDS)


# ---------------------------------------------------------------------------
# Session Memory
# ---------------------------------------------------------------------------


class SessionMemory:
    """Persistent memory across restarts."""

    def __init__(self) -> None:
        self._data: dict[str, Any] = {}
        self._load()

    def _load(self) -> None:
        try:
            if MEMORY_FILE.exists():
                self._data = json.loads(MEMORY_FILE.read_text("utf-8"))
        except Exception:
            self._data = {}

    def save(self) -> None:
        try:
            MEMORY_FILE.parent.mkdir(parents=True, exist_ok=True)
            MEMORY_FILE.write_text(json.dumps(self._data, indent=2), "utf-8")
        except Exception:
            pass

    def get(self, key: str, default: Any = None) -> Any:
        return self._data.get(key, default)

    def set(self, key: str, value: Any) -> None:
        self._data[key] = value
        self.save()

    def context_str(self) -> str:
        """Return env context for agent prompts."""
        return "\n".join(f"  {k}: {v}" for k, v in self._data.items() if not k.startswith("_"))


def _detect_env(mem: SessionMemory) -> None:
    """Auto-detect machine environment."""
    mem.set("os", f"{platform.system()} {platform.release()} ({platform.machine()})")
    mem.set("python", platform.python_version())
    mem.set("computer", platform.node())
    mem.set("user", str(Path.home().name))
    mem.set("cwd", str(Path.cwd()))
    mem.set("project", Path.cwd().name)

    # Scan workspace tree (top 2 levels)
    try:
        tree: list[str] = []
        cwd = Path.cwd()
        for p in sorted(cwd.iterdir()):
            if p.name.startswith(".") or p.name in {"node_modules", "__pycache__", "dist", "build", ".git", "venv"}:
                continue
            tree.append(p.name + ("/" if p.is_dir() else ""))
            if p.is_dir():
                try:
                    for sub in sorted(p.iterdir())[:10]:
                        if not sub.name.startswith("."):
                            tree.append(f"  {sub.name}")
                except PermissionError:
                    pass
        mem.set("workspace_tree", "\n".join(tree[:60]))
    except Exception:
        pass

    # AWS check
    try:
        r = subprocess.run(["aws", "sts", "get-caller-identity", "--query", "Account", "--output", "text"],
                           capture_output=True, text=True, timeout=10, check=False)
        if r.returncode == 0 and r.stdout.strip():
            mem.set("aws_account", r.stdout.strip())
            mem.set("aws_configured", True)
    except Exception:
        mem.set("aws_configured", False)

    # Docker check
    try:
        r = subprocess.run(["docker", "info", "--format", "{{.ServerVersion}}"],
                           capture_output=True, text=True, timeout=5, check=False)
        if r.returncode == 0 and r.stdout.strip():
            mem.set("docker", r.stdout.strip())
    except Exception:
        pass

    # Git check
    try:
        r = subprocess.run(["git", "branch", "--show-current"],
                           capture_output=True, text=True, timeout=5, check=False)
        if r.returncode == 0 and r.stdout.strip():
            mem.set("git_branch", r.stdout.strip())
    except Exception:
        pass

    mem.save()


def _fetch_gemini_api_key() -> str:
    """Fetch Gemini API key from AWS Secrets Manager at runtime. Never hardcoded.

    Returns empty string on any failure so callers can handle unavailability
    gracefully without crashing the TUI.
    """
    try:
        import boto3  # type: ignore[import-untyped]
        client = boto3.client("secretsmanager")
        resp = client.get_secret_value(SecretId=_GEMINI_SECRET_ID)
        secret = resp.get("SecretString", "")
        # Secret may be a JSON object {"api_key": "..."} or a raw string
        try:
            parsed = json.loads(secret)
            return str(parsed.get("api_key") or parsed.get("GEMINI_API_KEY") or secret)
        except (json.JSONDecodeError, AttributeError):
            return secret.strip()
    except Exception:
        return ""


def _call_gemini(prompt: str, api_key: str) -> str:
    """Call Gemini REST API synchronously, return full text response.

    Any network/HTTP/timeout errors are caught and empty string is returned
    so that callers can handle gracefully. The API key is never included in
    error messages to prevent secret leakage in stack traces.
    """
    import urllib.error
    import urllib.request

    payload = json.dumps({
        "contents": [{"parts": [{"text": prompt}]}],
        "generationConfig": {"temperature": 0.7, "maxOutputTokens": 8192},
    }).encode()

    url = f"{_GEMINI_ENDPOINT}?key={api_key}"
    req = urllib.request.Request(  # noqa: S310
        url,
        data=payload,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:  # noqa: S310
            body = json.loads(resp.read().decode())
    except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError, OSError):
        return ""  # Caller handles empty response gracefully

    if not isinstance(body, dict):
        return ""
    candidates = body.get("candidates", [])
    if not candidates or not isinstance(candidates, list):
        return ""
    parts = candidates[0].get("content", {}).get("parts", [])
    return "".join(p.get("text", "") for p in parts)


# ---------------------------------------------------------------------------
# CSS
# ---------------------------------------------------------------------------

# AiCippY mascot — expressive oval mascot with blinking eyes and movement
# Each frame is a 3-line oval body with eyes that blink/pulse
_Z_OPEN = "◉"  # eyes open
_Z_HALF = "◎"  # eyes half (blink transition)
_Z_SHUT = "─"  # eyes shut (blink)
_Z_LOOK_L = "◉ ◉"  # looking left
_Z_LOOK_R = "◉ ◉"  # looking right

MASCOT_FRAMES: dict[str, list[list[str]]] = {
    "idle": [
        [" ╭───╮ ", f"( {_Z_OPEN}‿{_Z_OPEN} )", " ╰───╯✨"],
        [" ╭───╮ ", f"( {_Z_HALF}‿{_Z_HALF} )", " ╰───╯  "],
        [" ╭───╮ ", f"( {_Z_SHUT}‿{_Z_SHUT} )", " ╰───╯  "],
        [" ╭───╮ ", f"( {_Z_HALF}‿{_Z_HALF} )", " ╰───╯  "],
        [" ╭───╮ ", f"( {_Z_OPEN}‿{_Z_OPEN} )", " ╰───╯💭"],
        [" ╭───╮ ", f"( {_Z_OPEN}ᴗ{_Z_OPEN} )", " ╰───╯  "],
    ],
    "thinking": [
        [" ╭───╮ ", f"( {_Z_OPEN}_{_Z_OPEN} )", " ╰───╯💭"],
        [" ╭───╮ ", f"( {_Z_OPEN}•{_Z_OPEN} )", " ╰───╯🔍"],
        [" ╭───╮ ", f"( {_Z_HALF}_{_Z_HALF} )", " ╰───╯💭"],
        [" ╭───╮ ", f"( {_Z_OPEN}•{_Z_OPEN} )", " ╰───╯🤔"],
    ],
    "working": [
        [" ╭───╮ ", f"( {_Z_OPEN}▿{_Z_OPEN} )", " ╰───╯⚡"],
        [" ╭───╮ ", f"( {_Z_OPEN}△{_Z_OPEN} )", " ╰───╯🔧"],
        [" ╭───╮ ", f"( {_Z_HALF}▿{_Z_HALF} )", " ╰───╯⚡"],
        [" ╭───╮ ", f"( {_Z_OPEN}△{_Z_OPEN} )", " ╰───╯💪"],
    ],
    "success": [
        [" ╭───╮ ", f"( {_Z_OPEN}‿{_Z_OPEN} )", " ╰───╯✅"],
        [" ╭───╮ ", f"( {_Z_OPEN}‿{_Z_OPEN} )", " ╰───╯🎉"],
        [" ╭───╮ ", f"( {_Z_OPEN}ᴗ{_Z_OPEN} )", " ╰───╯✨"],
        [" ╭───╮ ", f"( {_Z_OPEN}‿{_Z_OPEN} )", " ╰───╯💚"],
    ],
    "error": [
        [" ╭───╮ ", f"( {_Z_OPEN}╭{_Z_OPEN} )", " ╰───╯❌"],
        [" ╭───╮ ", f"( {_Z_HALF}_{_Z_HALF} )", " ╰───╯😰"],
        [" ╭───╮ ", f"( {_Z_OPEN}╭{_Z_OPEN} )", " ╰───╯🔴"],
        [" ╭───╮ ", f"( {_Z_SHUT}_{_Z_SHUT} )", " ╰───╯💔"],
    ],
    "hello": [
        [" ╭───╮ ", f"( {_Z_OPEN}‿{_Z_OPEN} )", " ╰───╯👋"],
        [" ╭───╮ ", f"( {_Z_HALF}ᴗ{_Z_HALF} )", " ╰───╯🤗"],
        [" ╭───╮ ", f"( {_Z_OPEN}‿{_Z_OPEN} )", " ╰───╯💫"],
        [" ╭───╮ ", f"( {_Z_OPEN}ᴗ{_Z_OPEN} )", " ╰───╯🌟"],
    ],
}
AICIPPY_GREETINGS = [
    "Hey! I see you! 👋",
    "Hi there! Ready to build something? ✨",
    "AiCippY at your service! 🚀",
    "AiCippY here! What shall we create? 💡",
    "Click me again, I love it! 😄",
    "OdiN and I are all warmed up! ⚡",
    "Namaste! Let's make magic! 🙏",
    "I'm watching... and learning! 🧠",
]

APP_CSS = """
Screen { background: #0d1117; }

/* Header */
#header-bar {
    dock: top; height: 5; background: #161b22;
    border-bottom: solid #30363d; padding: 0 1;
}
#header-left {
    width: 1fr; height: 5;
    content-align: left middle; padding: 0 1;
}
#header-right {
    width: auto; height: 5;
    content-align: right middle; padding: 0 1;
}
#zoozoo {
    width: 12; height: 5;
    content-align: center middle; padding: 0 0;
    color: #22d3ee;
}
#zoozoo:hover { color: #00ff88; }

/* Info */
#info-bar {
    dock: top; height: 1;
    background: #0d1117; color: #6b7280; padding: 0 2;
}

/* Chat */
#chat-scroll {
    background: #0d1117; padding: 0 1; scrollbar-size: 1 1;
}
.msg-user {
    margin: 1 0 0 4; padding: 1 2;
    background: #1a3a5c; color: #e5e7eb; border: round #264d73;
}
.msg-agent {
    margin: 1 4 0 0; padding: 1 2;
    background: #1c1c2e; color: #d1d5db; border: round #30363d;
}
.msg-system { margin: 0 0; padding: 0 2; color: #a855f7; }
.msg-success { color: #00ff88; padding: 0 2; }
.msg-exec {
    margin: 0 1; padding: 0 2; color: #22d3ee;
    background: #0f1923; border: round #1e3a50;
}
.msg-stream { margin: 0 4 0 0; padding: 0 2; color: #9ca3af; }
.msg-zoozoo {
    margin: 0 2; padding: 0 2; color: #fbbf24;
    text-style: italic;
}
.msg-arjuna {
    margin: 1 4 0 0; padding: 1 2;
    background: #1a2e1a; color: #d1d5db; border: round #22543d;
}
.msg-tool {
    margin: 0 1; padding: 0 2; color: #22d3ee;
    background: #0f1923; border: round #1e3a50;
}
.msg-diff {
    margin: 0 1; padding: 1 2;
    background: #0a0f14; color: #e5e7eb; border: round #1e3a50;
}

/* Input */
#input-area {
    dock: bottom; height: auto; max-height: 12;
    background: #161b22; border-top: solid #30363d;
    padding: 1 1;
}
#input-row {
    height: auto; min-height: 3; max-height: 8;
    padding: 0 1;
}
#prompt-input {
    width: 1fr; min-height: 3; max-height: 6;
    border: round #30363d; background: #0d1117;
    color: #e5e7eb;
}
#prompt-input:focus { border: round #6366f1; }
#send-btn {
    width: 10; min-width: 10; height: 3;
    margin: 0 0 0 1; background: #6366f1;
    color: #fff; text-style: bold;
    border: round #818cf8;
}
#send-btn:hover { background: #4f46e5; border: round #a5b4fc; }
#chips-row { height: 1; padding: 0 2; }
.chip {
    width: auto; margin: 0 1 0 0; padding: 0 1;
    background: #1e293b; color: #9ca3af;
    border: round #30363d;
}
.chip:hover { background: #334155; color: #22d3ee; }
.chip-model-active {
    background: #14532d; color: #4ade80;
    border: round #22543d;
}
#status-bar {
    dock: bottom; height: 1;
    background: #080b10; color: #6b7280; padding: 0 2;
}
"""


# ---------------------------------------------------------------------------
# Widgets
# ---------------------------------------------------------------------------


class MascotWidget(Static):
    """Animated AiCippY mascot with click interaction."""

    mood: reactive[str] = reactive("idle")
    _frame: reactive[int] = reactive(0)
    _click_count: int = 0

    def __init__(self) -> None:
        super().__init__(id="zoozoo")
        self._timer_handle: Any = None

    def on_mount(self) -> None:
        """Start animation timer."""
        self._timer_handle = self.set_interval(0.8, self._next_frame)

    def _next_frame(self) -> None:
        frames = MASCOT_FRAMES.get(self.mood, MASCOT_FRAMES["idle"])
        self._frame = (self._frame + 1) % len(frames)
        frame = frames[self._frame]
        # Multi-line oval body rendering
        if isinstance(frame, list):
            rendered = "\n".join(f"[bold #22d3ee]{ln}[/]" for ln in frame)
        else:
            rendered = f"[bold #22d3ee]{frame}[/]"
        self.update(rendered)

    def on_click(self) -> None:
        """AiCippY mascot speaks when clicked."""
        import random
        self._click_count += 1
        greeting = random.choice(AICIPPY_GREETINGS)  # noqa: S311
        self.mood = "hello"
        # Post greeting to chat
        try:
            app = self.app
            if hasattr(app, "_add_mascot_msg"):
                app._add_mascot_msg(greeting)
        except Exception:
            pass

    def set_mood(self, mood: str) -> None:
        """Change mascot mood."""
        if mood in MASCOT_FRAMES:
            self.mood = mood


class HeaderBar(Horizontal):
    """Title bar."""

    def __init__(self, model: str, user: str) -> None:
        super().__init__(id="header-bar")
        self._model = model
        self._user = user

    def compose(self) -> ComposeResult:
        try:
            from aicippy import __version__
        except Exception:
            __version__ = "?"
        brand = "[bold #00ff88]Ai[/][bold #22d3ee]Cipp[/][bold #00ff88]Y[/]"
        left_text = (
            f"{brand} [#6b7280]v{__version__}[/]"
            f"  Agent: [bold #f59e0b]{self._model}[/]"
        )
        right_text = ""
        if self._user:
            right_text += f"[#22d3ee]{self._user}[/]  "
        right_text += "[bold #00ff88]● LIVE[/]"
        yield Static(left_text, id="header-left")
        yield Static(right_text, id="header-right")
        yield MascotWidget()


class InfoBar(Static):
    """Info line."""

    def __init__(self, mem: SessionMemory) -> None:
        proj = mem.get("project", "?")
        cwd = mem.get("cwd", str(Path.cwd()))
        home = str(Path.home())
        short = cwd.replace(home, "~", 1) if cwd.startswith(home) else cwd
        aws = f"  [bold #f59e0b]AWS:{mem.get('aws_account', '')}[/]" if mem.get("aws_configured") else ""
        branch = f"  [bold #a78bfa]⎇ {mem.get('git_branch', '')}[/]" if mem.get("git_branch") else ""
        super().__init__(
            f"[#6b7280]project:[/] [bold #22d3ee]{proj}[/]  [#6b7280]CWD:[/] [bold #ffd93d]{short}[/]{branch}{aws}",
            id="info-bar",
        )


class ChatMessage(Static):
    """Chat bubble."""

    pass


class StreamingMessage(Static):
    """Live streaming text that updates in-place."""

    pass


class CommandChip(Button):
    """Chip."""

    def __init__(self, cmd: str) -> None:
        super().__init__(cmd, classes="chip")


class StatusBar(Static):
    """Status bar."""

    tokens: reactive[int] = reactive(0)
    latency: reactive[int] = reactive(0)
    session_start: reactive[float] = reactive(0.0)
    turns: reactive[int] = reactive(0)
    status: reactive[str] = reactive("Ready")

    def __init__(self) -> None:
        super().__init__(id="status-bar")
        self.session_start = time.time()

    def render(self) -> str:
        dur = int(time.time() - self.session_start)
        m, s = divmod(dur, 60)
        h, m = divmod(m, 60)
        ds = f"{h}h{m}m" if h else f"{m}m{s}s"
        lat = f"{self.latency}ms" if self.latency > 0 else "--"
        return (
            f"  {self.status}"
            f"    ⚡ {self.tokens:,} tokens"
            f"  │  {lat}"
            f"  │  {self.turns} turns"
            f"  │  {ds}"
        )


# ---------------------------------------------------------------------------
# App
# ---------------------------------------------------------------------------


class AiCippyApp(App):
    """TUI App."""

    TITLE = "AiCippY"
    CSS = APP_CSS
    BINDINGS: list[Binding] = [  # noqa: RUF012
        Binding("ctrl+c", "quit", "Quit", show=False),
        Binding("ctrl+l", "clear_chat", "Clear"),
        Binding("escape", "focus_input", "Focus", show=False),
    ]

    def __init__(self, model: str = "odin", user_email: str = "", initial_prompt: str = "") -> None:
        super().__init__()
        # Normalise model key: store canonical lowercase key, display name separately
        model_key = model.lower()
        self._model_key: str = model_key if model_key in DISPLAY_NAMES else "odin"
        self._model: str = _dn(self._model_key)
        self._user_email = user_email
        self._initial_prompt = initial_prompt
        self._agent_client: Any = None
        self._tokens = 0
        self._turns = 0
        self._conversation: list[dict[str, str]] = []
        self._memory = SessionMemory()
        self._streaming_widget: StreamingMessage | None = None
        self._stream_text: str = ""
        self._stream_lock = threading.Lock()

    def compose(self) -> ComposeResult:
        yield HeaderBar(model=self._model, user=self._user_email)
        yield InfoBar(self._memory)

        with VerticalScroll(id="chat-scroll"):
            ts = time.strftime("%H:%M:%S")
            _os = self._memory.get("os", platform.system())
            _py = platform.python_version()
            yield ChatMessage(
                f"[#4b5563]{ts}[/]  [bold #a855f7]●[/] [#a855f7]{self._model} Agent initialized  \\[A7THAVA][/]",
                classes="msg-system",
            )
            yield ChatMessage(
                f"[#4b5563]{ts}[/]  [#6b7280]{_os} | Py {_py}[/]",
                classes="msg-system",
            )
            if self._memory.get("aws_configured"):
                _aid = self._memory.get("aws_account", "?")
                yield ChatMessage(f"[#4b5563]{ts}[/]  [bold #00ff88]✓ AWS: {_aid}[/]", classes="msg-success")
            if self._memory.get("git_branch"):
                _br = self._memory.get("git_branch", "?")
                yield ChatMessage(f"[#4b5563]{ts}[/]  [bold #a78bfa]⎇ {_br}[/]", classes="msg-system")

        with Vertical(id="input-area"):
            with Horizontal(id="input-row"):
                yield TextArea(id="prompt-input", language=None, theme="monokai", show_line_numbers=False)
                yield Button(" SEND ➤", id="send-btn", variant="primary")
            with Horizontal(id="chips-row"):
                for cmd in ["/build", "/deploy", "/test", "/status", "/model", "/screenshot", "/attach", "/clear"]:
                    yield CommandChip(cmd)

        yield StatusBar()

    def on_mount(self) -> None:
        self.query_one("#prompt-input", TextArea).focus()
        self._detect_env_bg()
        if self._initial_prompt:
            self.call_after_refresh(self._send_initial)

    @work(thread=True)
    def _detect_env_bg(self) -> None:
        _detect_env(self._memory)

    def _send_initial(self) -> None:
        ta = self.query_one("#prompt-input", TextArea)
        ta.load_text(self._initial_prompt)
        self._handle_send()

    def _handle_send(self) -> None:
        ta = self.query_one("#prompt-input", TextArea)
        text = ta.text.strip()
        if not text:
            return
        ta.clear()
        if text.lower() in {"quit", "exit", "q", "/quit", "/exit"}:
            self.exit()
            return
        # Handle /screenshot command inline
        if text.lower() in {"/screenshot", "/ss"}:
            self._capture_screenshot()
            return
        # Handle /attach <filepath> command
        if text.lower().startswith("/attach "):
            filepath = text[8:].strip()
            if filepath:
                self._handle_attach(filepath)
            else:
                self._add_sys("Usage: /attach <image-path>")
            return
        self._add_user_msg(text)
        self._conversation.append({"role": "user", "content": text})
        self._set_status("Processing...")
        self._set_mascot_mood("thinking")
        self._invoke_agent(text)

    def on_key(self, event: Any) -> None:
        # Enter → send, Alt+Enter → newline
        if event.key == "enter":
            # Only intercept when prompt-input is focused
            try:
                focused = self.focused
                if focused and focused.id == "prompt-input":
                    self._handle_send()
                    event.prevent_default()
                    event.stop()
            except Exception:
                pass
        elif event.key in {"alt+enter", "ctrl+j"}:
            # Insert newline into the text area
            try:
                ta = self.query_one("#prompt-input", TextArea)
                ta.insert("\n")
                event.prevent_default()
                event.stop()
            except NoMatches:
                pass

    @on(Button.Pressed, "#send-btn")
    def _on_send_click(self) -> None:
        self._handle_send()

    @on(Button.Pressed, ".chip")
    def _on_chip_click(self, event: Button.Pressed) -> None:
        cmd = str(event.button.label)
        if cmd == "/clear":
            self.action_clear_chat()
        elif cmd == "/status":
            self._add_sys(f"Environment:\n{self._esc(self._memory.context_str())}")
        elif cmd == "/model":
            self._toggle_model()
        elif cmd == "/screenshot":
            self._capture_screenshot()
        elif cmd == "/attach":
            ta = self.query_one("#prompt-input", TextArea)
            ta.load_text("/attach ")
            ta.focus()
        else:
            ta = self.query_one("#prompt-input", TextArea)
            ta.load_text(cmd + " ")
            ta.focus()

    def _toggle_model(self) -> None:
        """Toggle active agent between OdiN and ArjunA."""
        if self._model_key == "odin":
            self._model_key = "arjuna"
        else:
            self._model_key = "odin"
        self._model = _dn(self._model_key)
        # Reset Bedrock client so it re-initialises for whichever model is active next
        self._agent_client = None
        self._add_sys(f"Switched to [bold]{self._model}[/]. Next message will use {self._model}.")
        # Update /model chip style to reflect active agent
        try:
            for chip in self.query(".chip"):
                if str(chip.label) == "/model":  # type: ignore[union-attr]
                    if self._model_key == "arjuna":
                        chip.add_class("chip-model-active")
                    else:
                        chip.remove_class("chip-model-active")
        except Exception:
            pass

    # -- Screenshot & Image Attachment --

    def _capture_screenshot(self) -> None:
        """Capture a screenshot of the current screen for visual analysis."""
        self._capture_screenshot_bg()

    @work(thread=True)
    def _capture_screenshot_bg(self) -> None:
        """Background worker: capture screenshot and send to agent for analysis."""
        try:
            screenshot_dir = Path.home() / ".aicippy" / "screenshots"
            screenshot_dir.mkdir(parents=True, exist_ok=True)
            ts = time.strftime("%Y%m%d_%H%M%S")
            filepath = screenshot_dir / f"screen_{ts}.png"

            # Use platform-native screenshot tool
            if platform.system() == "Windows":
                # PowerShell screenshot capture using .NET
                ps_cmd = (
                    "Add-Type -AssemblyName System.Windows.Forms;"
                    "[System.Windows.Forms.Screen]::PrimaryScreen | ForEach-Object {"
                    "$bmp = New-Object System.Drawing.Bitmap($_.Bounds.Width, $_.Bounds.Height);"
                    "$g = [System.Drawing.Graphics]::FromImage($bmp);"
                    "$g.CopyFromScreen($_.Bounds.Location, [System.Drawing.Point]::Empty, $_.Bounds.Size);"
                    f"$bmp.Save('{filepath}');"
                    "$g.Dispose(); $bmp.Dispose()}"
                )
                r = subprocess.run(
                    ["powershell", "-ExecutionPolicy", "Bypass", "-NoProfile", "-Command", ps_cmd],
                    capture_output=True, text=True, timeout=15, check=False,
                )
            elif platform.system() == "Darwin":
                r = subprocess.run(
                    ["screencapture", "-x", str(filepath)],
                    capture_output=True, text=True, timeout=10, check=False,
                )
            else:
                # Linux — try gnome-screenshot, scrot, or import
                for tool in [
                    ["gnome-screenshot", "-f", str(filepath)],
                    ["scrot", str(filepath)],
                    ["import", "-window", "root", str(filepath)],
                ]:
                    r = subprocess.run(tool, capture_output=True, text=True, timeout=10, check=False)
                    if r.returncode == 0:
                        break

            if filepath.exists():
                size_kb = filepath.stat().st_size // 1024
                self.call_from_thread(
                    self._add_sys,
                    f"[bold #22d3ee]Screenshot captured:[/] {filepath.name} ({size_kb}KB)",
                )
                # Auto-send to agent for visual analysis
                self._send_image_to_agent(
                    str(filepath),
                    "Analyze this screenshot. Describe what you see and identify any issues, "
                    "errors, or notable UI elements.",
                )
            else:
                self.call_from_thread(self._add_sys, "[bold #ef4444]Screenshot capture failed[/]")
        except Exception as exc:
            self.call_from_thread(self._add_sys, f"[bold #ef4444]Screenshot error:[/] {self._esc(str(exc))}")

    def _handle_attach(self, filepath: str) -> None:
        """Handle /attach <filepath> command — attach image for visual analysis."""
        p = Path(filepath.strip().strip('"').strip("'"))
        if not p.exists():
            self._add_sys(f"[bold #ef4444]File not found:[/] {self._esc(str(p))}")
            return
        if p.suffix.lower() not in {".png", ".jpg", ".jpeg", ".gif", ".bmp", ".webp"}:
            self._add_sys(f"[bold #ef4444]Unsupported image format:[/] {p.suffix}")
            return
        size_kb = p.stat().st_size // 1024
        if size_kb > 5120:
            self._add_sys("[bold #ef4444]Image too large (max 5MB)[/]")
            return
        self._add_sys(f"[bold #22d3ee]Attached:[/] {p.name} ({size_kb}KB)")
        self._send_image_to_agent_bg(str(p), "Analyze this image. Describe what you see in detail.")

    @work(thread=True)
    def _send_image_to_agent_bg(self, filepath: str, prompt: str) -> None:
        """Background worker wrapper for sending image to agent."""
        self._send_image_to_agent(filepath, prompt)

    def _send_image_to_agent(self, filepath: str, prompt: str) -> None:
        """Read image, encode to base64, and send to the active agent for visual analysis."""
        try:
            p = Path(filepath)
            img_bytes = p.read_bytes()
            img_b64 = base64.b64encode(img_bytes).decode("ascii")
            ext = p.suffix.lower().lstrip(".")
            mime = {
                "png": "image/png",
                "jpg": "image/jpeg",
                "jpeg": "image/jpeg",
                "gif": "image/gif",
                "bmp": "image/bmp",
                "webp": "image/webp",
            }.get(ext, "image/png")

            # Build a prompt with image context
            # For Gemini (ArjunA), we can include the image in the API call
            # For Bedrock (OdiN), we describe the image path for the agent to use
            is_arjuna = self._model_key == "arjuna"

            if is_arjuna:
                # Gemini supports multimodal — send image directly
                result = self._call_arjuna_with_image(prompt, img_b64, mime)
            else:
                # OdiN/Bedrock — send image context via streaming Converse API
                img_context = f"[Image attached: {p.name}, {len(img_bytes)//1024}KB, {mime}]\n\n{prompt}"
                self.call_from_thread(self._start_stream)
                self.call_from_thread(self._set_status, "Analyzing image...")

                messages = [{"role": "user", "content": [{"text": img_context}]}]
                streamed: list[str] = []

                def on_token(t: str) -> None:
                    streamed.append(t)
                    self.call_from_thread(self._update_stream, "".join(streamed))

                result, _tools = self._stream_turn(messages, on_token)
                if result and not streamed:
                    self._simulate_stream(result)
                self.call_from_thread(self._end_stream)

            if not result:
                self.call_from_thread(self._add_sys, "[#ef4444]No analysis returned.[/]")
                return

            if is_arjuna:
                self.call_from_thread(self._start_stream)
                self._simulate_stream(result)
                self.call_from_thread(self._end_stream)

            self._conversation.append({"role": "user", "content": f"[Image: {p.name}] {prompt}"})
            self._conversation.append({"role": "assistant", "content": result})
            if len(self._conversation) > 20:
                self._conversation = self._conversation[-20:]

            self.call_from_thread(self._set_status, "Ready")
            self.call_from_thread(self._set_mascot_mood, "success")

        except Exception as exc:
            self.call_from_thread(self._end_stream)
            self.call_from_thread(self._add_sys, f"[bold #ef4444]Image analysis error:[/] {self._esc(str(exc)[:200])}")
            self.call_from_thread(self._set_mascot_mood, "error")

    def _call_arjuna_with_image(self, prompt: str, img_b64: str, mime: str) -> str:
        """Call Gemini with multimodal (text + image) input."""
        import urllib.error
        import urllib.request

        api_key = _fetch_gemini_api_key()
        if not api_key:
            return "[ArjunA unavailable — Gemini API key not configured]"

        payload = json.dumps({
            "contents": [{
                "parts": [
                    {"text": prompt},
                    {"inline_data": {"mime_type": mime, "data": img_b64}},
                ],
            }],
            "generationConfig": {"temperature": 0.4, "maxOutputTokens": 4096},
        }).encode()

        url = f"{_GEMINI_ENDPOINT}?key={api_key}"
        req = urllib.request.Request(url, data=payload, headers={"Content-Type": "application/json"}, method="POST")  # noqa: S310
        try:
            with urllib.request.urlopen(req, timeout=120) as resp:  # noqa: S310
                body = json.loads(resp.read().decode())
        except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError, OSError):
            return ""

        if not isinstance(body, dict):
            return ""
        candidates = body.get("candidates", [])
        if not candidates or not isinstance(candidates, list):
            return ""
        parts = candidates[0].get("content", {}).get("parts", [])
        return "".join(p.get("text", "") for p in parts)

    # -- Helpers --

    @staticmethod
    def _esc(text: str) -> str:
        """Escape Rich markup."""
        if not text:
            return ""
        return str(text).replace("[", "\\[")

    def _set_status(self, text: str) -> None:
        try:
            self.query_one(StatusBar).status = text
        except NoMatches:
            pass

    def _set_mascot_mood(self, mood: str) -> None:
        try:
            self.query_one(MascotWidget).set_mood(mood)
        except NoMatches:
            pass

    def _add_mascot_msg(self, text: str) -> None:
        ts = time.strftime("%H:%M:%S")
        sc = self.query_one("#chat-scroll", VerticalScroll)
        m = ChatMessage(
            f"[#4b5563]{ts}[/]  [bold #fbbf24]🤖 AiCippY:[/]"
            f" [italic #fbbf24]{self._esc(text)}[/]",
            classes="msg-zoozoo",
        )
        sc.mount(m)
        m.scroll_visible()

    def _scroll_bottom(self) -> None:
        try:
            sc = self.query_one("#chat-scroll", VerticalScroll)
            sc.scroll_end(animate=False)
        except NoMatches:
            pass

    # -- Messages --

    def _add_user_msg(self, text: str) -> None:
        ts = time.strftime("%H:%M:%S")
        sc = self.query_one("#chat-scroll", VerticalScroll)
        m = ChatMessage(f"[bold #86efac]You ❯[/]  {self._esc(text)}\n[#4b5563 italic]{ts}[/]", classes="msg-user")
        sc.mount(m)
        m.scroll_visible()

    def _add_agent_msg(self, text: str) -> None:
        ts = time.strftime("%H:%M:%S")
        sc = self.query_one("#chat-scroll", VerticalScroll)
        css_class = "msg-arjuna" if self._model_key == "arjuna" else "msg-agent"
        m = ChatMessage(
            f"[bold #22d3ee]{self._model} ❯[/]  {self._esc(text)}\n[#4b5563 italic]{ts}[/]",
            classes=css_class,
        )
        sc.mount(m)
        m.scroll_visible()

    def _add_sys(self, text: str) -> None:
        ts = time.strftime("%H:%M:%S")
        sc = self.query_one("#chat-scroll", VerticalScroll)
        m = ChatMessage(f"[#4b5563]{ts}[/]  [bold #a855f7]●[/] [#a855f7]{text}[/]", classes="msg-system")
        sc.mount(m)
        m.scroll_visible()

    def _add_exec(self, cmd: str, output: str, ok: bool) -> None:
        ts = time.strftime("%H:%M:%S")
        sc = self.query_one("#chat-scroll", VerticalScroll)
        icon = "[bold #00ff88]✓[/]" if ok else "[bold #ef4444]✗[/]"
        m = ChatMessage(
            f"[#4b5563]{ts}[/]  {icon} [bold #22d3ee]$ {self._esc(cmd[:80])}[/]\n"
            f"[#9ca3af]{self._esc(output[:400]) if output else '(ok)'}[/]",
            classes="msg-exec",
        )
        sc.mount(m)
        m.scroll_visible()

    def _add_tool_result(self, tool_name: str, result: dict[str, Any], params: dict[str, Any]) -> None:
        """Display a tool call result in the chat."""
        ts = time.strftime("%H:%M:%S")
        sc = self.query_one("#chat-scroll", VerticalScroll)
        ok = result.get("success", False)
        icon = "[bold #00ff88]✓[/]" if ok else "[bold #ef4444]✗[/]"
        output_text = result.get("output", "")[:300]

        # Brief param summary
        param_str = ""
        if "path" in params:
            param_str = f" {params['path']}"
        elif "command" in params:
            param_str = f" {params['command'][:50]}"
        elif "app_name" in params:
            param_str = f" {params['app_name']}"

        m = ChatMessage(
            f"[#4b5563]{ts}[/]  {icon} [bold #22d3ee]🔧 {tool_name}{self._esc(param_str)}[/]\n"
            f"[#9ca3af]{self._esc(output_text) if output_text else '(ok)'}[/]",
            classes="msg-tool",
        )
        sc.mount(m)
        m.scroll_visible()

        # Show diff if present (file_write)
        diff_text = result.get("diff", "")
        if diff_text:
            self._show_diff(diff_text)

    def _show_diff(self, diff_text: str) -> None:
        """Display a colored unified diff in the chat."""
        sc = self.query_one("#chat-scroll", VerticalScroll)
        colored_lines: list[str] = []
        for line in diff_text.split("\n")[:60]:
            escaped = self._esc(line)
            if line.startswith("+++") or line.startswith("---") or line.startswith("@@"):
                colored_lines.append(f"[bold #a78bfa]{escaped}[/]")
            elif line.startswith("+"):
                colored_lines.append(f"[bold #00ff88]{escaped}[/]")
            elif line.startswith("-"):
                colored_lines.append(f"[bold #ef4444]{escaped}[/]")
            else:
                colored_lines.append(f"[#6b7280]{escaped}[/]")
        if colored_lines:
            m = ChatMessage("\n".join(colored_lines), classes="msg-diff")
            sc.mount(m)
            m.scroll_visible()

    def _start_stream(self) -> None:
        """Create a streaming message widget for live token display."""
        sc = self.query_one("#chat-scroll", VerticalScroll)
        widget = StreamingMessage(
            f"[bold #22d3ee]{self._model} ❯[/]  [#6b7280]...[/]",
            classes="msg-stream",
        )
        with self._stream_lock:
            self._streaming_widget = widget
            self._stream_text = ""
        sc.mount(widget)
        widget.scroll_visible()

    def _update_stream(self, text: str) -> None:
        """Update streaming message with new text."""
        with self._stream_lock:
            self._stream_text = text
            widget = self._streaming_widget
        if widget:
            widget.update(
                f"[bold #22d3ee]{self._model} ❯[/]  {self._esc(text)}"
            )
            widget.scroll_visible()

    def _end_stream(self) -> None:
        """Finalize streaming message."""
        with self._stream_lock:
            widget = self._streaming_widget
            current_text = self._stream_text
            self._streaming_widget = None
            self._stream_text = ""
        if widget:
            css_class = "msg-arjuna" if self._model_key == "arjuna" else "msg-agent"
            widget.remove_class("msg-stream")
            widget.add_class(css_class)
            ts = time.strftime("%H:%M:%S")
            if current_text:
                widget.update(
                    f"[bold #22d3ee]{self._model} ❯[/]  {self._esc(current_text)}\n[#4b5563 italic]{ts}[/]"
                )
            else:
                widget.update(
                    f"[bold #22d3ee]{self._model} ❯[/]  [#6b7280](no response)[/]\n[#4b5563 italic]{ts}[/]"
                )

    # -- Simulated word-by-word streaming --

    def _simulate_stream(self, text: str) -> None:
        """Emit text word-by-word into the streaming widget (called from thread)."""
        words = text.split()
        # Cap simulation at 200 words to avoid long blocking; append ellipsis if truncated
        truncated = len(words) > 200
        words = words[:200]
        displayed: list[str] = []
        for word in words:
            displayed.append(word)
            self.call_from_thread(self._update_stream, " ".join(displayed))
            time.sleep(0.015)  # 15 ms per word for smooth UX
        if truncated:
            displayed.append("...")
            self.call_from_thread(self._update_stream, " ".join(displayed))

    # -- Auto-commit after file operations --

    def _auto_commit(self, description: str) -> None:
        """Stage all changes and create an automatic git commit."""
        try:
            r = subprocess.run(
                ["git", "add", "-u"],  # Only tracked files, not untracked
                capture_output=True, text=True, timeout=15, check=False,
            )
            if r.returncode != 0:
                return  # Not a git repo or add failed — silently skip
            # Only commit if there are staged changes
            diff_r = subprocess.run(
                ["git", "diff", "--cached", "--quiet"],
                capture_output=True, timeout=5, check=False,
            )
            if diff_r.returncode == 0:
                return  # Nothing staged
            msg = f"chore(auto): {description[:72]}"
            commit_r = subprocess.run(
                ["git", "commit", "-m", msg],
                capture_output=True, text=True, timeout=30, check=False,
            )
            if commit_r.returncode == 0:
                sha_line = commit_r.stdout.strip().splitlines()[0] if commit_r.stdout else ""
                self.call_from_thread(
                    self._add_sys,
                    f"[bold #00ff88]Auto-commit:[/] {self._esc(sha_line or msg)}",
                )
        except Exception:
            pass  # Auto-commit is best-effort; never crash the loop

    # -- ArjunA (Gemini) invocation --

    def _call_arjuna(self, prompt: str, on_token: Any) -> str:
        """Invoke ArjunA (Gemini) via REST API.

        Fetches the API key from AWS Secrets Manager at runtime.
        Simulates streaming by calling on_token once with the full result;
        word-by-word display is handled by _simulate_stream in the outer loop.
        """
        api_key = _fetch_gemini_api_key()
        if not api_key:
            return "[ArjunA unavailable — Gemini API key not configured in Secrets Manager]"
        result = _call_gemini(prompt, api_key)
        if result and on_token:
            on_token(result)
        return result

    # -- OdiN (Bedrock Converse with native tool calling) --

    _ODIN_MODEL_ID = "us.meta.llama4-maverick-17b-instruct-v1:0"

    def _ensure_bedrock_client(self) -> Any:
        """Lazy-init bedrock-runtime client."""
        import boto3  # type: ignore[import-untyped]
        from botocore.config import Config as BotoConfig
        if self._agent_client is None:
            self._agent_client = boto3.client(
                "bedrock-runtime",
                region_name="us-east-1",
                config=BotoConfig(
                    read_timeout=900,
                    connect_timeout=30,
                    retries={"max_attempts": 2, "mode": "adaptive"},
                ),
            )
        return self._agent_client

    @staticmethod
    def _fix_message_order(messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Ensure strict user/assistant alternation (Bedrock requirement)."""
        if not messages:
            return messages
        fixed: list[dict[str, Any]] = [messages[0]]
        for msg in messages[1:]:
            if fixed[-1]["role"] == msg["role"]:
                fixed[-1]["content"].extend(msg["content"])
            else:
                fixed.append(msg)
        if fixed[0]["role"] != "user":
            fixed.insert(0, {"role": "user", "content": [{"text": "Continue."}]})
        return fixed

    def _stream_turn(
        self, messages: list[dict[str, Any]], on_token: Any,
    ) -> tuple[str, list[dict[str, Any]]]:
        """Stream one model turn via converse_stream with Llama 4 native tool calling.

        Tool definitions are in the system prompt (Llama 4 native JSON format).
        The model outputs tool calls as JSON arrays in the text, which we parse.
        This gives us REAL streaming + tool calling simultaneously.

        Returns (full_text, tool_calls_list).
        Each tool call is {name, parameters}.
        """
        br = self._ensure_bedrock_client()
        tools_json = json.dumps(get_llama4_tool_definitions(), indent=2)
        sys_text = _AGENT_SYSTEM_PROMPT_TOOLS.format(
            agent_name="OdiN",
            platform=platform.system(),
            cwd=self._memory.get("cwd", str(Path.cwd())),
            tools_json=tools_json,
        )

        try:
            resp = br.converse_stream(
                modelId=self._ODIN_MODEL_ID,
                messages=messages,
                system=[{"text": sys_text}],
                inferenceConfig={"maxTokens": 8192, "temperature": 0.3, "topP": 0.9},
            )
        except Exception as exc:
            return f"[OdiN error: {str(exc)[:200]}]", []

        full_text = ""
        for event in resp.get("stream", []):
            if "contentBlockDelta" in event:
                delta = event["contentBlockDelta"].get("delta", {})
                text = delta.get("text", "")
                if text:
                    full_text += text
                    if on_token:
                        on_token(text)

        # Parse Llama 4 native JSON tool calls from the response text
        tool_calls = parse_tool_calls(full_text)
        return full_text, tool_calls

    # -- Agent invocation with streaming + auto-execution --

    @work(thread=True)
    def _invoke_agent(self, text: str) -> None:
        """Call the active agent. OdiN uses native tool calling; ArjunA uses code-block fallback."""
        try:
            is_arjuna = self._model_key == "arjuna"
            agent_label = "ArjunA" if is_arjuna else "OdiN"

            if is_arjuna:
                self._invoke_arjuna_codeblock(text, agent_label)
            else:
                self._invoke_odin_tools(text, agent_label)

        except Exception as exc:
            self.call_from_thread(self._end_stream)
            self.call_from_thread(self._add_sys, f"Error: {self._esc(str(exc))}")
            self.call_from_thread(self._set_status, "Error")
            self.call_from_thread(self._set_mascot_mood, "error")

        self.call_from_thread(self._focus_input)

    # ── OdiN: native Converse API tool-calling loop ──

    def _invoke_odin_tools(self, text: str, agent_label: str) -> None:
        """Run OdiN with Llama 4 native streaming + tool calling.

        Tool definitions are in the system prompt. The model outputs JSON
        tool calls in the text stream, which we parse and execute.
        Tool results are sent back as 'ipython' role messages (Llama 4 format).
        """
        env = self._memory.context_str()
        tree = self._memory.get("workspace_tree", "")
        context = f"[Environment]\n{env}\n[Workspace]\n{tree}\n\n"

        # Build Converse API messages (text-only, no toolUse blocks)
        messages: list[dict[str, Any]] = [
            {"role": "user", "content": [{"text": context + text}]},
        ]

        for turn in range(1, MAX_AUTO_EXEC_TURNS + 1):
            self._turns += 1
            start_t = time.time()

            # Stream turn (real streaming via converse_stream)
            self.call_from_thread(self._start_stream)
            self.call_from_thread(self._set_status, f"{agent_label} streaming (turn {turn})...")

            streamed_text: list[str] = []

            def on_token(t: str) -> None:
                streamed_text.append(t)
                self.call_from_thread(self._update_stream, "".join(streamed_text))

            full_text, tool_calls = self._stream_turn(messages, on_token)

            elapsed = int((time.time() - start_t) * 1000)
            self._tokens += len(full_text.split()) if full_text else 0
            self.call_from_thread(self._update_status_bar, self._tokens, elapsed, self._turns)

            # Finalize streaming display
            if full_text and not streamed_text:
                self._simulate_stream(full_text)
            self.call_from_thread(self._end_stream)

            # Append assistant message
            messages.append({"role": "assistant", "content": [{"text": full_text}]})

            # No tool calls — model finished with text response
            if not tool_calls:
                self.call_from_thread(self._set_status, "Ready")
                self.call_from_thread(self._set_mascot_mood, "success")
                break

            # Check for done tool
            done_call = next((c for c in tool_calls if c["name"] == "done"), None)
            if done_call:
                summary = done_call.get("parameters", {}).get("summary", "Tasks complete.")
                self.call_from_thread(self._add_sys, f"[bold #00ff88]{agent_label}: {self._esc(summary)}[/]")
                self.call_from_thread(self._set_status, "Ready")
                self.call_from_thread(self._set_mascot_mood, "success")
                break

            # Execute all tool calls and collect results
            tool_results: list[dict[str, Any]] = []
            for call in tool_calls:
                tool_name = call["name"]
                tool_params = call.get("parameters", {})

                self.call_from_thread(self._set_status, f"Executing: {tool_name}...")
                self.call_from_thread(self._set_mascot_mood, "working")
                result = execute_tool(tool_name, tool_params)

                # Display tool result in chat
                self.call_from_thread(self._add_tool_result, tool_name, result, tool_params)

                # Auto-commit after file writes
                if tool_name == "file_write" and result.get("success"):
                    self._auto_commit(f"{agent_label}: {tool_params.get('path', 'file')[:60]}")

                tool_results.append({"response": result.get("output", "")[:4000]})

            # Send tool results back as user message (Llama 4 ipython/tool role)
            # In Converse API, tool results go as a user message with the JSON response
            tool_response_text = json.dumps(tool_results, indent=2)
            messages.append({"role": "user", "content": [{"text": tool_response_text}]})

            # Trim messages to avoid token overflow
            if len(messages) > 20:
                messages = messages[-20:]
                messages = self._fix_message_order(messages)

        self.call_from_thread(self._set_status, "Ready")

    # ── ArjunA: code-block fallback loop (Gemini) ──

    def _invoke_arjuna_codeblock(self, text: str, agent_label: str) -> None:
        """Run ArjunA with code-block parsing (no native tool support)."""
        env = self._memory.context_str()
        tree = self._memory.get("workspace_tree", "")
        cwd = self._memory.get("cwd", str(Path.cwd()))
        sys_prompt = _AGENT_SYSTEM_PROMPT_CODEBLOCK.format(
            agent_name=agent_label, platform=platform.system(), cwd=cwd,
        )
        current = f"{sys_prompt}\n[Environment]\n{env}\n[Workspace]\n{tree}\n\n{text}"

        for turn in range(1, MAX_AUTO_EXEC_TURNS + 1):
            self._turns += 1
            start_t = time.time()

            self.call_from_thread(self._start_stream)
            self.call_from_thread(self._set_status, f"{agent_label} thinking (turn {turn})...")

            result = self._call_arjuna(current, None)

            elapsed = int((time.time() - start_t) * 1000)
            self._tokens += len(result.split()) if result else 0
            self.call_from_thread(self._update_status_bar, self._tokens, elapsed, self._turns)

            if result:
                self._simulate_stream(result)
            self.call_from_thread(self._end_stream)

            if not result:
                self.call_from_thread(self._add_sys, "No response.")
                break

            self._conversation.append({"role": "assistant", "content": result})
            if len(self._conversation) > 20:
                self._conversation = self._conversation[-20:]

            # Parse code blocks
            blocks = SHELL_RE.findall(result)
            if not blocks:
                self.call_from_thread(self._set_status, "Ready")
                self.call_from_thread(self._set_mascot_mood, "success")
                break

            # Execute blocks
            outputs: list[str] = []
            for block in blocks:
                script = block.strip()
                if not script or _is_blocked_cmd(script):
                    continue
                cmd_preview = script.split("\n")[0][:60]
                self.call_from_thread(self._set_status, f"Running: {cmd_preview}...")
                self.call_from_thread(self._set_mascot_mood, "working")
                try:
                    if platform.system() == "Windows":
                        r = subprocess.run(
                            ["powershell", "-ExecutionPolicy", "Bypass", "-NoProfile", "-Command", script],
                            capture_output=True, text=True, timeout=CMD_TIMEOUT_SECONDS, check=False,
                        )
                    else:
                        r = subprocess.run(
                            ["bash", "-c", script],
                            capture_output=True, text=True, timeout=CMD_TIMEOUT_SECONDS, check=False,
                        )
                    out = (r.stdout or "").strip()
                    err = (r.stderr or "").strip()
                    output = out if out else err
                    self.call_from_thread(self._add_exec, cmd_preview, output, r.returncode == 0)
                    outputs.append(f"$ {cmd_preview}\nExit: {r.returncode}\n{output[:500]}")
                except Exception as exc:
                    outputs.append(f"$ {cmd_preview}\nERROR: {exc}")

            feedback = "\n\n".join(outputs)
            current = f"[Results]\n{feedback}\n\nContinue or say DONE."
            self._conversation.append({"role": "user", "content": current})

            if any("DONE" in line.upper() for line in result.strip().split("\n")[-5:]):
                break

        self.call_from_thread(self._set_status, "Ready")

    def _focus_input(self) -> None:
        try:
            self.query_one("#prompt-input", TextArea).focus()
        except NoMatches:
            pass

    def _update_status_bar(self, tokens: int, latency: int, turns: int) -> None:
        """Update StatusBar reactives from the main thread."""
        try:
            sb = self.query_one(StatusBar)
            sb.tokens = tokens
            sb.latency = latency
            sb.turns = turns
        except NoMatches:
            pass

    def action_clear_chat(self) -> None:
        sc = self.query_one("#chat-scroll", VerticalScroll)
        sc.remove_children()
        self._conversation.clear()
        self._add_sys("Cleared. Memory preserved.")

    def action_focus_input(self) -> None:
        self._focus_input()

    def action_quit(self) -> None:
        self._memory.save()
        self.exit()


# ---------------------------------------------------------------------------
# Entry
# ---------------------------------------------------------------------------


async def start_tui_session(
    model: str = "odin", user_email: str = "",
    initial_prompt: str = "", **_kw: object,
) -> None:
    """Launch TUI."""
    app = AiCippyApp(model=model, user_email=user_email, initial_prompt=initial_prompt)
    await app.run_async()
