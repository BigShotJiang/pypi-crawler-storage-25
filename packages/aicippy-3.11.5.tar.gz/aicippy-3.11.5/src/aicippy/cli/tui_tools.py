"""AiCippY TUI tool definitions and executor for Bedrock Converse API native tool calling.

18 tools across 6 categories: file ops, shell, browser, app control, documents, agent control.
Each tool uses the Bedrock Converse `toolSpec` format.
"""

from __future__ import annotations

import difflib
import json
import platform
import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import Any

# ---------------------------------------------------------------------------
# Safety
# ---------------------------------------------------------------------------

_BLOCKED_CMDS: set[str] = {
    "rm -rf /", "format c:", "del /f /s /q", ":(){ :|:& };:", "mkfs", "> /dev/sda",
}

_CMD_TIMEOUT = 120


def _is_blocked(cmd: str) -> bool:
    lower = cmd.lower().strip()
    return any(b in lower for b in _BLOCKED_CMDS)


# ---------------------------------------------------------------------------
# App registry (multi-OS)
# ---------------------------------------------------------------------------

APP_REGISTRY: dict[str, dict[str, str | None]] = {
    "chrome":       {"Windows": "chrome",          "Darwin": "Google Chrome",          "Linux": "google-chrome"},
    "firefox":      {"Windows": "firefox",         "Darwin": "Firefox",                "Linux": "firefox"},
    "edge":         {"Windows": "msedge",          "Darwin": "Microsoft Edge",         "Linux": "microsoft-edge"},
    "safari":       {"Windows": None,              "Darwin": "Safari",                 "Linux": None},
    "outlook":      {"Windows": "outlook",         "Darwin": "Microsoft Outlook",      "Linux": None},
    "mail":         {"Windows": None,              "Darwin": "Mail",                   "Linux": "thunderbird"},
    "gmail":        {"Windows": "https://mail.google.com", "Darwin": "https://mail.google.com", "Linux": "https://mail.google.com"},
    "vscode":       {"Windows": "code",            "Darwin": "Visual Studio Code",     "Linux": "code"},
    "terminal":     {"Windows": "wt",              "Darwin": "Terminal",               "Linux": "gnome-terminal"},
    "finder":       {"Windows": "explorer",        "Darwin": "Finder",                 "Linux": "nautilus"},
    "notepad":      {"Windows": "notepad",         "Darwin": "TextEdit",               "Linux": "gedit"},
}

# ---------------------------------------------------------------------------
# Tool Spec Definitions (Bedrock Converse format)
# ---------------------------------------------------------------------------


def _spec(name: str, desc: str, props: dict, required: list[str] | None = None) -> dict:
    """Build a Bedrock Converse toolSpec entry."""
    schema: dict[str, Any] = {"type": "object", "properties": props}
    if required:
        schema["required"] = required
    return {"toolSpec": {"name": name, "description": desc, "inputSchema": {"json": schema}}}


ALL_TOOLS: list[dict[str, Any]] = [
    # ── File Operations ──
    _spec("file_read", "Read a file and return its contents.", {
        "path": {"type": "string", "description": "Absolute or relative file path"},
        "max_lines": {"type": "integer", "description": "Max lines to return (default all)"},
        "offset": {"type": "integer", "description": "Start from this line number (0-based)"},
    }, ["path"]),

    _spec("file_write", "Write content to a file. Creates parent dirs. Returns diff of changes.", {
        "path": {"type": "string", "description": "File path to write"},
        "content": {"type": "string", "description": "Full file content to write"},
    }, ["path", "content"]),

    _spec("file_list", "List files and directories in a path.", {
        "path": {"type": "string", "description": "Directory path to list"},
        "recursive": {"type": "boolean", "description": "Recurse into subdirectories"},
        "max_depth": {"type": "integer", "description": "Max recursion depth (default 2)"},
    }, ["path"]),

    _spec("file_diff", "Show unified diff between old and new content of a file.", {
        "path": {"type": "string", "description": "File path to diff"},
        "new_content": {"type": "string", "description": "New content to compare against current file"},
    }, ["path"]),

    # ── Shell Execution ──
    _spec("shell_exec", "Execute a shell command and return stdout/stderr.", {
        "command": {"type": "string", "description": "Shell command to execute"},
        "cwd": {"type": "string", "description": "Working directory (optional)"},
        "timeout": {"type": "integer", "description": "Timeout in seconds (default 120)"},
    }, ["command"]),

    _spec("shell_script", "Execute a multi-line script.", {
        "script": {"type": "string", "description": "Full script content"},
        "language": {"type": "string", "description": "Script language: powershell, bash, or python"},
        "cwd": {"type": "string", "description": "Working directory (optional)"},
    }, ["script"]),

    # ── Browser Automation ──
    _spec("browser_screenshot", "Capture a screenshot of the active browser tab.", {}),
    _spec("browser_navigate", "Navigate the browser to a URL.", {
        "url": {"type": "string", "description": "URL to navigate to"},
    }, ["url"]),
    _spec("browser_click", "Click an element in the browser by CSS selector.", {
        "selector": {"type": "string", "description": "CSS selector of the element to click"},
    }, ["selector"]),
    _spec("browser_fill", "Fill a form field in the browser.", {
        "selector": {"type": "string", "description": "CSS selector of the input"},
        "value": {"type": "string", "description": "Value to fill"},
    }, ["selector", "value"]),
    _spec("browser_get_content", "Get the HTML content of the active browser tab.", {}),

    # ── App Control ──
    _spec("app_open", "Open an application by name (cross-platform).", {
        "app_name": {
            "type": "string",
            "description": "App name: chrome, firefox, edge, safari, "
            "outlook, mail, gmail, vscode, terminal, finder, notepad",
        },
        "url": {"type": "string", "description": "Optional URL to open in browser apps"},
    }, ["app_name"]),
    _spec("app_close", "Close an application by name.", {
        "app_name": {"type": "string", "description": "App name to close"},
    }, ["app_name"]),

    # ── Document Tools ──
    _spec("pdf_read", "Extract text from a PDF file.", {
        "path": {"type": "string", "description": "Path to PDF file"},
        "pages": {"type": "string", "description": "Page range e.g. '1-5' or '3' (optional, default all)"},
    }, ["path"]),
    _spec("pdf_create", "Create a PDF file from text content.", {
        "path": {"type": "string", "description": "Output PDF path"},
        "content": {"type": "string", "description": "Text content for the PDF"},
        "title": {"type": "string", "description": "PDF title (optional)"},
    }, ["path", "content"]),
    _spec("excel_read", "Read data from an Excel file.", {
        "path": {"type": "string", "description": "Path to .xlsx file"},
        "sheet": {"type": "string", "description": "Sheet name (optional, default first sheet)"},
    }, ["path"]),
    _spec("pptx_read", "Read text from a PowerPoint file.", {
        "path": {"type": "string", "description": "Path to .pptx file"},
    }, ["path"]),

    # ── Image & Video Generation ──
    _spec("image_generate", "Generate an image using AI (Bedrock Titan Image Generator). Saves to specified path.", {
        "prompt": {"type": "string", "description": "Detailed text description of the image to generate"},
        "path": {"type": "string", "description": "Output file path (e.g. public/hero.png)"},
        "width": {"type": "integer", "description": "Image width in pixels (default 1024)"},
        "height": {"type": "integer", "description": "Image height in pixels (default 1024)"},
        "style": {
            "type": "string",
            "description": "Style: photorealistic, digital-art, cinematic, anime, "
            "3d-render (default photorealistic)",
        },
    }, ["prompt", "path"]),

    _spec("image_analyze", "Analyze an image using AI vision. Returns detailed description.", {
        "path": {"type": "string", "description": "Path to image file to analyze"},
        "question": {"type": "string", "description": "Question about the image (default: describe it)"},
    }, ["path"]),

    _spec("video_create", "Create a video from images or text (uses ffmpeg). "
          "Generates animated slideshows, GIFs, or MP4.", {
        "output_path": {"type": "string", "description": "Output video file path (.mp4 or .gif)"},
        "image_paths": {"type": "string", "description": "Comma-separated paths to images for slideshow"},
        "duration": {"type": "integer", "description": "Duration per image in seconds (default 3)"},
        "fps": {"type": "integer", "description": "Frames per second (default 24)"},
        "text_overlay": {"type": "string", "description": "Text to overlay on the video (optional)"},
    }, ["output_path"]),

    _spec("image_edit", "Edit/transform an image: resize, crop, add text, convert format.", {
        "path": {"type": "string", "description": "Input image path"},
        "output_path": {"type": "string", "description": "Output image path"},
        "resize": {"type": "string", "description": "New size as WIDTHxHEIGHT (e.g. 800x600)"},
        "text": {"type": "string", "description": "Text to add to the image"},
        "format": {"type": "string", "description": "Output format: png, jpg, webp, gif"},
    }, ["path", "output_path"]),

    # ── Agent Control ──
    _spec("done", "Signal that all tasks are complete.", {
        "summary": {"type": "string", "description": "Brief summary of what was accomplished"},
    }, ["summary"]),
]

# ---------------------------------------------------------------------------
# Tool Executor
# ---------------------------------------------------------------------------


def get_llama4_tool_definitions() -> list[dict[str, Any]]:
    """Convert ALL_TOOLS to Llama 4 native JSON function list format."""
    result = []
    for tool in ALL_TOOLS:
        spec = tool["toolSpec"]
        schema = spec["inputSchema"]["json"]
        result.append({
            "name": spec["name"],
            "description": spec["description"],
            "parameters": {
                "type": "dict",
                "required": schema.get("required", []),
                "properties": schema.get("properties", {}),
            },
        })
    return result


def parse_tool_calls(text: str) -> list[dict[str, Any]]:
    """Parse Llama 4 native tool calls from model text output.

    Llama 4 may output tool calls in either:
    - JSON format: [{"name": "tool", "parameters": {...}}]
    - Python format: [{'name': 'tool', 'parameters': {...}}]
    - Python call format: [tool_name(param1="value1", param2="value2")]

    Returns list of {name, parameters} dicts. Returns [] if no valid calls found.
    """
    text = text.strip()
    # Find outermost [...] array in the text
    start = text.find("[")
    if start == -1:
        return []
    # Find matching close bracket
    depth = 0
    end = -1
    for i in range(start, len(text)):
        if text[i] == "[":
            depth += 1
        elif text[i] == "]":
            depth -= 1
            if depth == 0:
                end = i + 1
                break
    if end == -1:
        return []

    raw = text[start:end]

    # Try JSON first
    try:
        calls = json.loads(raw)
        if isinstance(calls, list):
            return _validate_calls(calls)
    except (json.JSONDecodeError, ValueError):
        pass

    # Try Python-style single quotes → convert to JSON double quotes
    try:
        # Replace single quotes with double quotes carefully
        fixed = raw.replace("'", '"')
        calls = json.loads(fixed)
        if isinstance(calls, list):
            return _validate_calls(calls)
    except (json.JSONDecodeError, ValueError):
        pass

    # Try ast.literal_eval (handles Python dicts/lists)
    try:
        import ast
        calls = ast.literal_eval(raw)
        if isinstance(calls, list):
            return _validate_calls(calls)
    except (ValueError, SyntaxError):
        pass

    # Try Python function-call format: [func_name(param=val, ...)]
    import re
    func_pattern = re.compile(r'(\w+)\(([^)]*)\)')
    matches = func_pattern.findall(raw)
    if matches:
        results = []
        for name, args_str in matches:
            params: dict[str, Any] = {}
            if args_str.strip():
                # Parse key=value pairs
                for pair in re.findall(r'(\w+)\s*=\s*"([^"]*)"', args_str):
                    params[pair[0]] = pair[1]
                for pair in re.findall(r"(\w+)\s*=\s*'([^']*)'", args_str):
                    params[pair[0]] = pair[1]
            results.append({"name": name, "parameters": params})
        return results

    return []


def _validate_calls(calls: list) -> list[dict[str, Any]]:
    """Validate and normalize a list of parsed tool calls."""
    valid = []
    for call in calls:
        if isinstance(call, dict) and "name" in call:
            valid.append({
                "name": call["name"],
                "parameters": call.get("parameters", {}),
            })
    return valid


def execute_tool(name: str, params: dict[str, Any]) -> dict[str, Any]:
    """Execute a tool by name with given parameters. Returns {success, output, diff?}."""
    handler = _HANDLERS.get(name)
    if not handler:
        return {"success": False, "output": f"Unknown tool: {name}"}
    try:
        return handler(params)
    except Exception as exc:
        return {"success": False, "output": f"Tool error: {str(exc)[:500]}"}


# ---------------------------------------------------------------------------
# File Operation Handlers
# ---------------------------------------------------------------------------


def _file_read(p: dict[str, Any]) -> dict[str, Any]:
    path = Path(p["path"])
    if not path.exists():
        return {"success": False, "output": f"File not found: {path}"}
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except Exception as e:
        return {"success": False, "output": f"Read error: {e}"}
    lines = text.splitlines(keepends=True)
    offset = int(p.get("offset", 0) or 0)
    max_lines = int(p.get("max_lines", 0) or 0)
    if offset > 0:
        lines = lines[offset:]
    if max_lines > 0:
        lines = lines[:max_lines]
    content = "".join(lines)
    if len(content) > 8000:
        content = content[:8000] + "\n... (truncated)"
    return {"success": True, "output": content}


def _file_write(p: dict[str, Any]) -> dict[str, Any]:
    path = Path(p["path"])
    content = p["content"]
    # Capture old content for diff
    old = ""
    if path.exists():
        try:
            old = path.read_text(encoding="utf-8", errors="replace")
        except Exception:
            pass
    # Create parent dirs
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
    # Compute diff
    diff_lines = list(difflib.unified_diff(
        old.splitlines(keepends=True),
        content.splitlines(keepends=True),
        fromfile=f"a/{path.name}",
        tofile=f"b/{path.name}",
        lineterm="",
    ))
    diff_text = "\n".join(diff_lines[:100])  # Cap at 100 lines
    return {
        "success": True,
        "output": f"Written {len(content)} bytes to {path}",
        "diff": diff_text,
        "path": str(path),
    }


def _file_list(p: dict[str, Any]) -> dict[str, Any]:
    path = Path(p["path"])
    if not path.exists():
        return {"success": False, "output": f"Path not found: {path}"}
    recursive = bool(p.get("recursive", False))
    max_depth = int(p.get("max_depth", 2) or 2)
    entries: list[str] = []

    def _walk(d: Path, depth: int) -> None:
        if depth > max_depth or len(entries) > 200:
            return
        try:
            for item in sorted(d.iterdir()):
                if item.name.startswith(".") or item.name in {"node_modules", "__pycache__", "dist", ".git", "venv"}:
                    continue
                prefix = "  " * depth
                if item.is_dir():
                    entries.append(f"{prefix}{item.name}/")
                    if recursive:
                        _walk(item, depth + 1)
                else:
                    sz = item.stat().st_size
                    entries.append(f"{prefix}{item.name} ({sz}B)")
        except PermissionError:
            pass

    _walk(path, 0)
    return {"success": True, "output": "\n".join(entries) or "(empty)"}


def _file_diff(p: dict[str, Any]) -> dict[str, Any]:
    path = Path(p["path"])
    new_content = p.get("new_content", "")
    if not path.exists():
        return {"success": False, "output": f"File not found: {path}"}
    old = path.read_text(encoding="utf-8", errors="replace")
    diff_lines = list(difflib.unified_diff(
        old.splitlines(keepends=True),
        new_content.splitlines(keepends=True),
        fromfile=f"a/{path.name}",
        tofile=f"b/{path.name}",
    ))
    return {"success": True, "output": "\n".join(diff_lines[:150]) or "(no differences)"}


# ---------------------------------------------------------------------------
# Shell Handlers
# ---------------------------------------------------------------------------


def _shell_exec(p: dict[str, Any]) -> dict[str, Any]:
    cmd = p["command"]
    if _is_blocked(cmd):
        return {"success": False, "output": "BLOCKED: dangerous command"}
    cwd = p.get("cwd") or None
    timeout = int(p.get("timeout", _CMD_TIMEOUT) or _CMD_TIMEOUT)
    try:
        if platform.system() == "Windows":
            r = subprocess.run(
                ["powershell", "-ExecutionPolicy", "Bypass", "-NoProfile", "-Command", cmd],
                capture_output=True, text=True, timeout=timeout, check=False, cwd=cwd,
            )
        else:
            r = subprocess.run(
                ["bash", "-c", cmd],
                capture_output=True, text=True, timeout=timeout, check=False, cwd=cwd,
            )
        out = (r.stdout or "").strip()
        err = (r.stderr or "").strip()
        output = out if out else err
        return {"success": r.returncode == 0, "output": output[:4000], "exit_code": r.returncode}
    except subprocess.TimeoutExpired:
        return {"success": False, "output": "TIMEOUT"}
    except Exception as exc:
        return {"success": False, "output": str(exc)[:500]}


def _shell_script(p: dict[str, Any]) -> dict[str, Any]:
    script = p["script"]
    lang = p.get("language", "powershell" if platform.system() == "Windows" else "bash")
    cwd = p.get("cwd") or None
    suffix = {"powershell": ".ps1", "bash": ".sh", "python": ".py"}.get(lang, ".sh")
    interpreter: list[str] = {
        "powershell": ["powershell", "-ExecutionPolicy", "Bypass", "-NoProfile", "-File"],
        "bash": ["bash"],
        "python": ["python"],
    }.get(lang, ["bash"])

    with tempfile.NamedTemporaryFile(mode="w", suffix=suffix, delete=False, encoding="utf-8") as f:
        f.write(script)
        tmp_path = f.name
    try:
        r = subprocess.run(
            [*interpreter, tmp_path],
            capture_output=True, text=True, timeout=_CMD_TIMEOUT, check=False, cwd=cwd,
        )
        out = (r.stdout or "").strip()
        err = (r.stderr or "").strip()
        return {"success": r.returncode == 0, "output": (out or err)[:4000], "exit_code": r.returncode}
    except subprocess.TimeoutExpired:
        return {"success": False, "output": "TIMEOUT"}
    except Exception as exc:
        return {"success": False, "output": str(exc)[:500]}
    finally:
        Path(tmp_path).unlink(missing_ok=True)


# ---------------------------------------------------------------------------
# Browser Handlers (stub — delegates to BrowserManager if available)
# ---------------------------------------------------------------------------

_browser_manager: Any = None


def set_browser_manager(mgr: Any) -> None:
    """Inject the BrowserManager instance from the TUI app."""
    global _browser_manager
    _browser_manager = mgr


def _browser_screenshot(_p: dict[str, Any]) -> dict[str, Any]:
    if not _browser_manager:
        return {"success": False, "output": "Browser not connected. Launch AiCippy browser extension first."}
    try:
        import asyncio
        result = asyncio.run(_browser_manager.capture_screenshot())
        return {"success": True, "output": f"Screenshot captured: {result}"}
    except Exception as e:
        return {"success": False, "output": str(e)[:300]}


def _browser_navigate(p: dict[str, Any]) -> dict[str, Any]:
    url = p.get("url", "")
    # Fallback: open in default browser via shell
    try:
        if platform.system() == "Windows":
            subprocess.run(
                ["powershell", "-Command", f"Start-Process '{url}'"],
                timeout=10,
                check=False,
                capture_output=True,
            )
        elif platform.system() == "Darwin":
            subprocess.run(["open", url], timeout=10, check=False, capture_output=True)
        else:
            subprocess.run(["xdg-open", url], timeout=10, check=False, capture_output=True)
        return {"success": True, "output": f"Opened {url}"}
    except Exception as e:
        return {"success": False, "output": str(e)[:300]}


def _browser_click(p: dict[str, Any]) -> dict[str, Any]:
    if not _browser_manager:
        return {"success": False, "output": "Browser not connected."}
    try:
        import asyncio
        asyncio.run(_browser_manager.click_element(p["selector"]))
        return {"success": True, "output": f"Clicked {p['selector']}"}
    except Exception as e:
        return {"success": False, "output": str(e)[:300]}


def _browser_fill(p: dict[str, Any]) -> dict[str, Any]:
    if not _browser_manager:
        return {"success": False, "output": "Browser not connected."}
    try:
        import asyncio
        asyncio.run(_browser_manager.fill_form({p["selector"]: p["value"]}))
        return {"success": True, "output": f"Filled {p['selector']}"}
    except Exception as e:
        return {"success": False, "output": str(e)[:300]}


def _browser_get_content(_p: dict[str, Any]) -> dict[str, Any]:
    if not _browser_manager:
        return {"success": False, "output": "Browser not connected."}
    try:
        import asyncio
        html = asyncio.run(_browser_manager.get_page_content())
        return {"success": True, "output": str(html)[:8000]}
    except Exception as e:
        return {"success": False, "output": str(e)[:300]}


# ---------------------------------------------------------------------------
# App Control Handlers
# ---------------------------------------------------------------------------


def _app_open(p: dict[str, Any]) -> dict[str, Any]:
    app_name = p["app_name"].lower().strip()
    url = p.get("url", "")
    os_name = platform.system()

    # Check if it's a URL (gmail, etc.)
    target = APP_REGISTRY.get(app_name, {}).get(os_name)
    if target is None:
        return {"success": False, "output": f"{app_name} not available on {os_name}"}

    # URL-based apps
    if target.startswith("http"):
        target = url or target

    try:
        if os_name == "Windows":
            subprocess.Popen(
                ["powershell", "-Command", f"Start-Process '{target}'"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        elif os_name == "Darwin":
            if target.startswith("http"):
                subprocess.Popen(["open", target], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            else:
                subprocess.Popen(["open", "-a", target], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        elif target.startswith("http"):
            subprocess.Popen(["xdg-open", target], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        elif shutil.which(target):
            subprocess.Popen([target], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        else:
            return {"success": False, "output": f"{target} not found on PATH"}
        return {"success": True, "output": f"Opened {app_name}"}
    except Exception as e:
        return {"success": False, "output": str(e)[:300]}


def _app_close(p: dict[str, Any]) -> dict[str, Any]:
    app_name = p["app_name"].lower().strip()
    os_name = platform.system()
    target = APP_REGISTRY.get(app_name, {}).get(os_name)
    if not target or target.startswith("http"):
        return {"success": False, "output": f"Cannot close {app_name} on {os_name}"}
    try:
        if os_name == "Windows":
            exe = target + ".exe" if not target.endswith(".exe") else target
            subprocess.run(["taskkill", "/IM", exe, "/F"], capture_output=True, timeout=10, check=False)
        elif os_name == "Darwin":
            subprocess.run(["osascript", "-e", f'quit app "{target}"'], capture_output=True, timeout=10, check=False)
        else:
            subprocess.run(["pkill", "-f", target], capture_output=True, timeout=10, check=False)
        return {"success": True, "output": f"Closed {app_name}"}
    except Exception as e:
        return {"success": False, "output": str(e)[:300]}


# ---------------------------------------------------------------------------
# Document Handlers (graceful import fallback)
# ---------------------------------------------------------------------------


def _pdf_read(p: dict[str, Any]) -> dict[str, Any]:
    path = Path(p["path"])
    if not path.exists():
        return {"success": False, "output": f"File not found: {path}"}
    # Try PyPDF2
    try:
        import PyPDF2  # type: ignore[import-untyped]
        reader = PyPDF2.PdfReader(str(path))
        pages_range = p.get("pages", "")
        texts: list[str] = []
        if pages_range:
            parts = pages_range.split("-")
            start = int(parts[0]) - 1
            end = int(parts[-1]) if len(parts) > 1 else start + 1
            for i in range(start, min(end, len(reader.pages))):
                texts.append(reader.pages[i].extract_text() or "")
        else:
            for page in reader.pages[:50]:
                texts.append(page.extract_text() or "")
        return {"success": True, "output": "\n\n".join(texts)[:8000]}
    except ImportError:
        pass
    # Fallback: pdftotext CLI
    try:
        r = subprocess.run(["pdftotext", str(path), "-"], capture_output=True, text=True, timeout=30, check=False)
        if r.returncode == 0:
            return {"success": True, "output": r.stdout[:8000]}
    except FileNotFoundError:
        pass
    return {"success": False, "output": "Install PyPDF2: pip install PyPDF2"}


def _pdf_create(p: dict[str, Any]) -> dict[str, Any]:
    path = Path(p["path"])
    content = p["content"]
    title = p.get("title", "")
    path.parent.mkdir(parents=True, exist_ok=True)
    # Try fpdf2
    try:
        from fpdf import FPDF  # type: ignore[import-untyped]
        pdf = FPDF()
        pdf.add_page()
        pdf.set_auto_page_break(auto=True, margin=15)
        pdf.set_font("Helvetica", size=11)
        if title:
            pdf.set_font("Helvetica", "B", size=16)
            pdf.cell(0, 12, title, ln=True, align="C")
            pdf.ln(6)
            pdf.set_font("Helvetica", size=11)
        for line in content.split("\n"):
            pdf.multi_cell(0, 6, line)
        pdf.output(str(path))
        return {"success": True, "output": f"PDF created: {path} ({path.stat().st_size}B)"}
    except ImportError:
        pass
    # Fallback: write as text + pandoc
    txt_path = path.with_suffix(".txt")
    txt_path.write_text(content, encoding="utf-8")
    try:
        r = subprocess.run(["pandoc", str(txt_path), "-o", str(path)], capture_output=True, timeout=30, check=False)
        txt_path.unlink(missing_ok=True)
        if r.returncode == 0:
            return {"success": True, "output": f"PDF created via pandoc: {path}"}
    except FileNotFoundError:
        pass
    return {"success": False, "output": "Install fpdf2: pip install fpdf2"}


def _excel_read(p: dict[str, Any]) -> dict[str, Any]:
    path = Path(p["path"])
    if not path.exists():
        return {"success": False, "output": f"File not found: {path}"}
    # Try openpyxl
    try:
        import openpyxl  # type: ignore[import-untyped]
        wb = openpyxl.load_workbook(str(path), read_only=True, data_only=True)
        sheet_name = p.get("sheet") or wb.sheetnames[0]
        ws = wb[sheet_name]
        rows: list[str] = []
        for row in ws.iter_rows(max_row=200, values_only=True):
            rows.append("\t".join(str(c) if c is not None else "" for c in row))
        wb.close()
        return {"success": True, "output": f"Sheet: {sheet_name}\n" + "\n".join(rows)[:8000]}
    except ImportError:
        pass
    # Fallback: if CSV
    if path.suffix.lower() == ".csv":
        return {"success": True, "output": path.read_text(encoding="utf-8", errors="replace")[:8000]}
    return {"success": False, "output": "Install openpyxl: pip install openpyxl"}


def _pptx_read(p: dict[str, Any]) -> dict[str, Any]:
    path = Path(p["path"])
    if not path.exists():
        return {"success": False, "output": f"File not found: {path}"}
    try:
        from pptx import Presentation  # type: ignore[import-untyped]
        prs = Presentation(str(path))
        slides: list[str] = []
        for i, slide in enumerate(prs.slides, 1):
            texts: list[str] = []
            for shape in slide.shapes:
                if shape.has_text_frame:
                    texts.append(shape.text_frame.text)
            slides.append(f"--- Slide {i} ---\n" + "\n".join(texts))
        return {"success": True, "output": "\n\n".join(slides)[:8000]}
    except ImportError:
        return {"success": False, "output": "Install python-pptx: pip install python-pptx"}


# ---------------------------------------------------------------------------
# Done handler
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Image & Video Handlers
# ---------------------------------------------------------------------------

_bedrock_image_client: Any = None


def _image_generate(p: dict[str, Any]) -> dict[str, Any]:
    """Generate image using AWS Bedrock Titan Image Generator G1 v2."""
    global _bedrock_image_client
    prompt_text = p["prompt"]
    path = Path(p["path"])
    width = int(p.get("width", 1024) or 1024)
    height = int(p.get("height", 1024) or 1024)

    path.parent.mkdir(parents=True, exist_ok=True)

    try:
        import base64 as b64

        import boto3  # type: ignore[import-untyped]
        if _bedrock_image_client is None:
            _bedrock_image_client = boto3.client("bedrock-runtime", region_name="us-east-1")

        body = json.dumps({
            "taskType": "TEXT_IMAGE",
            "textToImageParams": {"text": prompt_text},
            "imageGenerationConfig": {
                "numberOfImages": 1,
                "height": height,
                "width": width,
                "cfgScale": 8.0,
            },
        })

        resp = _bedrock_image_client.invoke_model(
            modelId="amazon.titan-image-generator-v2:0",
            body=body,
            contentType="application/json",
            accept="application/json",
        )
        result = json.loads(resp["body"].read())
        images = result.get("images", [])
        if not images:
            return {"success": False, "output": "No image generated"}

        img_bytes = b64.b64decode(images[0])
        path.write_bytes(img_bytes)
        return {"success": True, "output": f"Image generated: {path} ({len(img_bytes) // 1024}KB, {width}x{height})"}

    except Exception as exc:
        # Fallback: try using Stability AI via Bedrock
        try:
            body = json.dumps({
                "text_prompts": [{"text": prompt_text, "weight": 1.0}],
                "cfg_scale": 7, "steps": 30,
                "width": min(width, 1024), "height": min(height, 1024),
            })
            resp = _bedrock_image_client.invoke_model(
                modelId="stability.stable-diffusion-xl-v1",
                body=body, contentType="application/json", accept="application/json",
            )
            result = json.loads(resp["body"].read())
            artifacts = result.get("artifacts", [])
            if artifacts:
                import base64 as b64
                img_bytes = b64.b64decode(artifacts[0]["base64"])
                path.write_bytes(img_bytes)
                return {"success": True, "output": f"Image generated (SDXL): {path} ({len(img_bytes) // 1024}KB)"}
        except Exception:
            pass
        return {"success": False, "output": f"Image generation failed: {str(exc)[:200]}"}


def _image_analyze(p: dict[str, Any]) -> dict[str, Any]:
    """Analyze image using Bedrock (Llama 4 Maverick has vision)."""
    global _bedrock_image_client
    path = Path(p["path"])
    question = p.get("question", "Describe this image in detail.")
    if not path.exists():
        return {"success": False, "output": f"File not found: {path}"}

    try:
        import boto3  # type: ignore[import-untyped]

        img_bytes = path.read_bytes()
        ext = path.suffix.lower().lstrip(".")

        if _bedrock_image_client is None:
            _bedrock_image_client = boto3.client("bedrock-runtime", region_name="us-east-1")
        resp = _bedrock_image_client.converse(
            modelId="us.meta.llama4-maverick-17b-instruct-v1:0",
            messages=[{
                "role": "user",
                "content": [
                    {"image": {"format": ext if ext in ("png", "jpeg", "gif", "webp") else "png",
                               "source": {"bytes": img_bytes}}},
                    {"text": question},
                ],
            }],
            inferenceConfig={"maxTokens": 2048, "temperature": 0.3},
        )
        output = resp.get("output", {}).get("message", {}).get("content", [])
        text = "".join(b.get("text", "") for b in output)
        return {"success": True, "output": text[:4000]}
    except Exception as exc:
        return {"success": False, "output": f"Image analysis failed: {str(exc)[:200]}"}


def _video_create(p: dict[str, Any]) -> dict[str, Any]:
    """Create video from images using ffmpeg."""
    output_path = Path(p["output_path"])
    output_path.parent.mkdir(parents=True, exist_ok=True)
    image_paths = [i.strip() for i in p.get("image_paths", "").split(",") if i.strip()]
    duration = int(p.get("duration", 3) or 3)
    fps = int(p.get("fps", 24) or 24)
    text_overlay = p.get("text_overlay", "")

    if not image_paths:
        return {"success": False, "output": "No image paths provided"}

    # Check ffmpeg
    if not shutil.which("ffmpeg"):
        return {"success": False, "output": "ffmpeg not found. Install ffmpeg to create videos."}

    try:
        # Create concat file for ffmpeg
        concat_file = output_path.parent / "_concat.txt"
        with concat_file.open("w") as f:
            for img in image_paths:
                if Path(img).exists():
                    f.write(f"file '{Path(img).resolve()}'\n")
                    f.write(f"duration {duration}\n")
            # Repeat last image
            if image_paths and Path(image_paths[-1]).exists():
                f.write(f"file '{Path(image_paths[-1]).resolve()}'\n")

        cmd = ["ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", str(concat_file),
               "-vf",
               f"fps={fps},scale=1920:1080:force_original_aspect_ratio=decrease,"
               "pad=1920:1080:(ow-iw)/2:(oh-ih)/2",
               "-c:v", "libx264", "-pix_fmt", "yuv420p", str(output_path)]

        if text_overlay:
            # Add text overlay
            cmd = ["ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", str(concat_file),
                   "-vf",
                   f"fps={fps},scale=1920:1080:force_original_aspect_ratio=decrease,"
                   "pad=1920:1080:(ow-iw)/2:(oh-ih)/2,"
                   f"drawtext=text='{text_overlay}':fontsize=48:fontcolor=white:"
                   "x=(w-text_w)/2:y=h-80",
                   "-c:v", "libx264", "-pix_fmt", "yuv420p", str(output_path)]

        r = subprocess.run(cmd, capture_output=True, text=True, timeout=120, check=False)
        concat_file.unlink(missing_ok=True)

        if r.returncode == 0 and output_path.exists():
            return {"success": True, "output": f"Video created: {output_path} ({output_path.stat().st_size // 1024}KB)"}
        return {"success": False, "output": f"ffmpeg error: {(r.stderr or '')[:300]}"}
    except Exception as exc:
        return {"success": False, "output": f"Video creation failed: {str(exc)[:200]}"}


def _image_edit(p: dict[str, Any]) -> dict[str, Any]:
    """Edit image: resize, add text, convert format."""
    path = Path(p["path"])
    output_path = Path(p["output_path"])
    if not path.exists():
        return {"success": False, "output": f"File not found: {path}"}

    output_path.parent.mkdir(parents=True, exist_ok=True)

    # Try Pillow
    try:
        from PIL import Image, ImageDraw, ImageFont  # type: ignore[import-untyped]
        img = Image.open(str(path))

        # Resize
        resize = p.get("resize", "")
        if resize and "x" in resize.lower():
            w, h = resize.lower().split("x")[:2]
            img = img.resize((int(w), int(h)), Image.LANCZOS)

        # Add text
        text = p.get("text", "")
        if text:
            draw = ImageDraw.Draw(img)
            try:
                font = ImageFont.truetype("arial.ttf", 36)
            except OSError:
                font = ImageFont.load_default()
            draw.text((20, img.height - 60), text, fill="white", font=font)

        # Output format
        fmt = p.get("format", output_path.suffix.lstrip(".") or "png")
        img.save(str(output_path), fmt.upper() if fmt.upper() in ("PNG", "JPEG", "WEBP", "GIF", "BMP") else "PNG")
        return {"success": True, "output": f"Image saved: {output_path} ({output_path.stat().st_size // 1024}KB)"}

    except ImportError:
        pass

    # Fallback: ffmpeg for basic conversion/resize
    resize = p.get("resize", "")
    try:
        cmd = ["ffmpeg", "-y", "-i", str(path)]
        if resize and "x" in resize.lower():
            cmd += ["-vf", f"scale={resize.replace('x', ':')}"]
        cmd.append(str(output_path))
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=30, check=False)
        if r.returncode == 0:
            return {"success": True, "output": f"Image converted: {output_path}"}
        return {"success": False, "output": f"ffmpeg error: {(r.stderr or '')[:200]}"}
    except FileNotFoundError:
        return {"success": False, "output": "Install Pillow (pip install Pillow) or ffmpeg for image editing"}


# ---------------------------------------------------------------------------
# Done handler
# ---------------------------------------------------------------------------


def _done(p: dict[str, Any]) -> dict[str, Any]:
    return {"success": True, "output": p.get("summary", "Tasks complete."), "done": True}


# ---------------------------------------------------------------------------
# Handler dispatch
# ---------------------------------------------------------------------------

_HANDLERS: dict[str, Any] = {
    "file_read": _file_read,
    "file_write": _file_write,
    "file_list": _file_list,
    "file_diff": _file_diff,
    "shell_exec": _shell_exec,
    "shell_script": _shell_script,
    "browser_screenshot": _browser_screenshot,
    "browser_navigate": _browser_navigate,
    "browser_click": _browser_click,
    "browser_fill": _browser_fill,
    "browser_get_content": _browser_get_content,
    "app_open": _app_open,
    "app_close": _app_close,
    "pdf_read": _pdf_read,
    "pdf_create": _pdf_create,
    "excel_read": _excel_read,
    "pptx_read": _pptx_read,
    "image_generate": _image_generate,
    "image_analyze": _image_analyze,
    "video_create": _video_create,
    "image_edit": _image_edit,
    "done": _done,
}
