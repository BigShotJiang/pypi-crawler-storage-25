"""Proxmox API client wrapper."""

from __future__ import annotations

import ipaddress
import time
from typing import Any
from urllib.parse import quote

from hiveframe.config.settings import HiveframeSettings, NodeSettings
from hiveframe.models.firewall import FirewallRule
from hiveframe.models.vlan import VlanConfig
from hiveframe.models.vm import CloudInitConfig


class HiveframeAPIError(Exception):
    """Raised when a Proxmox API call fails."""

    def __init__(self, message: str, *, cause: BaseException | None = None) -> None:
        super().__init__(message)
        self.cause = cause


def _wrap(fn: Any, *args: Any, **kwargs: Any) -> Any:
    """Call a proxmoxer chain and re-raise as HiveframeAPIError on failure."""
    try:
        return fn(*args, **kwargs)
    except Exception as exc:
        raise HiveframeAPIError(str(exc), cause=exc) from exc


class ProxmoxClient:
    """Clean interface over proxmoxer.ProxmoxAPI.

    All callers must go through this class — never proxmoxer directly.
    Every method re-raises proxmoxer exceptions as HiveframeAPIError.
    """

    def __init__(self, settings: NodeSettings) -> None:
        self._settings = settings
        self._px = self._connect()

    def _connect(self) -> Any:
        try:
            from proxmoxer import ProxmoxAPI
        except ImportError as exc:
            raise RuntimeError("proxmoxer is not installed") from exc

        try:
            return ProxmoxAPI(
                self._settings.host,
                user=self._settings.user,
                token_name=self._settings.token_id,
                token_value=self._settings.token_secret.get_secret_value(),
                verify_ssl=self._settings.verify_ssl,
            )
        except Exception as exc:
            raise HiveframeAPIError(
                f"Failed to connect to Proxmox at {self._settings.host}: {exc}",
                cause=exc,
            ) from exc

    # ------------------------------------------------------------------
    # Node / cluster info
    # ------------------------------------------------------------------

    def get_nodes(self) -> list[dict]:
        return _wrap(self._px.nodes.get)

    def get_node_info(self, node: str) -> dict:
        return _wrap(self._px.nodes(node).status.get)

    # ------------------------------------------------------------------
    # Network
    # ------------------------------------------------------------------

    def get_network_config(self, node: str) -> list[dict]:
        return _wrap(self._px.nodes(node).network.get)

    def bridge_exists(self, node: str, bridge_name: str) -> bool:
        ifaces = self.get_network_config(node)
        return any(i.get("iface") == bridge_name for i in ifaces)

    def create_linux_bridge(self, node: str, vlan: VlanConfig) -> None:
        """Create a Linux bridge for the given VLAN (pending, not yet applied)."""
        net = ipaddress.ip_network(vlan.cidr, strict=False)
        netmask = str(net.netmask)

        params: dict[str, Any] = {
            "iface": vlan.bridge,
            "type": "bridge",
            "bridge_ports": "",
            "comments": vlan.description or f"HiveFrame VLAN {vlan.vlan_id}",
        }
        if vlan.gateway:
            params["address"] = vlan.gateway
            params["netmask"] = netmask

        _wrap(self._px.nodes(node).network.post, **params)

    def delete_network_iface(self, node: str, iface_name: str) -> None:
        _wrap(self._px.nodes(node).network(iface_name).delete)

    def apply_network_config(self, node: str) -> None:
        _wrap(self._px.nodes(node).network.put)

    # ------------------------------------------------------------------
    # VMs
    # ------------------------------------------------------------------

    def get_vms(self, node: str) -> list[dict]:
        """Return list of VMs on the node (each dict has vmid, name, status)."""
        return _wrap(self._px.nodes(node).qemu.get)

    def get_vm_status(self, node: str, vmid: int) -> str:
        """Return power state string ('running', 'stopped', 'paused').
        Raises HiveframeAPIError if the VM does not exist."""
        result = _wrap(self._px.nodes(node).qemu(vmid).status.current.get)
        return str(result.get("status", "unknown"))

    def get_next_vmid(self, node: str) -> int:
        """Return the next available VMID from the cluster."""
        result = _wrap(self._px.cluster.nextid.get)
        return int(result)

    def clone_vm(
        self, node: str, template_id: int, new_vmid: int, name: str
    ) -> str:
        """Clone a template VM. Returns the task UPID string."""
        result = _wrap(
            self._px.nodes(node).qemu(template_id).clone.post,
            newid=new_vmid,
            name=name,
            full=1,
        )
        return str(result)

    def resize_disk(self, node: str, vmid: int, disk: str, add_gb: int) -> None:
        """Expand a disk by add_gb gigabytes (uses '+' prefix)."""
        _wrap(
            self._px.nodes(node).qemu(vmid).resize.put,
            disk=disk,
            size=f"+{add_gb}G",
        )

    def set_cloud_init(
        self, node: str, vmid: int, cloud_init: CloudInitConfig, storage: str = "local-lvm"
    ) -> None:
        """Apply cloud-init settings to a VM. Adds ide2 cloudinit drive if absent."""
        config = _wrap(self._px.nodes(node).qemu(vmid).config.get)

        params: dict[str, Any] = {}

        if "ide2" not in config:
            params["ide2"] = f"{storage}:cloudinit"

        params["ciuser"] = cloud_init.user

        if cloud_init.password:
            params["cipassword"] = cloud_init.password

        if cloud_init.ssh_keys:
            params["sshkeys"] = quote("\n".join(cloud_init.ssh_keys), safe="")

        ipconfig = cloud_init.proxmox_ipconfig0
        if ipconfig:
            params["ipconfig0"] = ipconfig

        if cloud_init.nameservers:
            params["nameserver"] = " ".join(cloud_init.nameservers)

        if cloud_init.search_domain:
            params["searchdomain"] = cloud_init.search_domain

        _wrap(self._px.nodes(node).qemu(vmid).config.post, **params)

    def set_network(self, node: str, vmid: int, bridge: str, vlan_id: int) -> None:
        """Set net0 on a VM to the given bridge with VLAN tag."""
        _wrap(
            self._px.nodes(node).qemu(vmid).config.post,
            net0=f"virtio,bridge={bridge},tag={vlan_id}",
        )

    def start_vm(self, node: str, vmid: int) -> str:
        """Start a VM. Returns the task UPID."""
        result = _wrap(self._px.nodes(node).qemu(vmid).status.start.post)
        return str(result)

    def stop_vm(self, node: str, vmid: int) -> str:
        """Stop a VM. Returns the task UPID."""
        result = _wrap(self._px.nodes(node).qemu(vmid).status.stop.post)
        return str(result)

    def delete_vm(self, node: str, vmid: int) -> None:
        """Delete a VM permanently."""
        _wrap(self._px.nodes(node).qemu(vmid).delete)

    # ------------------------------------------------------------------
    # Firewall
    # ------------------------------------------------------------------

    def get_vm_firewall_rules(self, node: str, vmid: int) -> list[dict]:
        """Return the list of firewall rules currently set on a VM."""
        return _wrap(self._px.nodes(node).qemu(vmid).firewall.rules.get)

    def add_vm_firewall_rule(self, node: str, vmid: int, rule: FirewallRule) -> None:
        """Append a single firewall rule to a VM."""
        _wrap(self._px.nodes(node).qemu(vmid).firewall.rules.post, **rule.to_proxmox_params())

    def clear_vm_firewall_rules(self, node: str, vmid: int) -> None:
        """Delete all firewall rules from a VM (idempotent)."""
        rules = self.get_vm_firewall_rules(node, vmid)
        for pos in range(len(rules) - 1, -1, -1):
            _wrap(self._px.nodes(node).qemu(vmid).firewall.rules(pos).delete)

    def enable_vm_firewall(self, node: str, vmid: int) -> None:
        """Enable the firewall on a VM."""
        _wrap(self._px.nodes(node).qemu(vmid).firewall.options.put, enable=1)

    # ------------------------------------------------------------------
    # Snapshots
    # ------------------------------------------------------------------

    def list_vm_snapshots(self, node: str, vmid: int) -> list[dict]:
        """Return all snapshots for a VM."""
        return _wrap(self._px.nodes(node).qemu(vmid).snapshot.get)

    def create_vm_snapshot(
        self, node: str, vmid: int, name: str, description: str = ""
    ) -> str:
        """Create a snapshot. Returns the task UPID."""
        result = _wrap(
            self._px.nodes(node).qemu(vmid).snapshot.post,
            snapname=name,
            description=description,
        )
        return str(result)

    def restore_vm_snapshot(self, node: str, vmid: int, name: str) -> str:
        """Rollback a VM to a snapshot. Returns the task UPID."""
        result = _wrap(self._px.nodes(node).qemu(vmid).snapshot(name).rollback.post)
        return str(result)

    def delete_vm_snapshot(self, node: str, vmid: int, name: str) -> str:
        """Delete a snapshot. Returns the task UPID."""
        result = _wrap(self._px.nodes(node).qemu(vmid).snapshot(name).delete)
        return str(result)

    def wait_for_task(self, node: str, task_id: str, timeout: int = 300) -> None:
        """Poll task status every 2s until stopped or timeout. Raises on failure."""
        elapsed = 0
        while elapsed < timeout:
            status = _wrap(self._px.nodes(node).tasks(task_id).status.get)
            if status.get("status") == "stopped":
                exit_status = status.get("exitstatus", "")
                if exit_status != "OK":
                    raise HiveframeAPIError(
                        f"Task {task_id} failed with exitstatus '{exit_status}'"
                    )
                return
            time.sleep(2)
            elapsed += 2
        raise HiveframeAPIError(f"Task {task_id} timed out after {timeout}s")


# ---------------------------------------------------------------------------
# Node registry — lazy multi-node connection manager
# ---------------------------------------------------------------------------

class NodeRegistry:
    """Manages per-node ProxmoxClient instances.

    Clients are created lazily — no connection is opened until get_client()
    is called for that node for the first time.
    """

    def __init__(self, settings: HiveframeSettings) -> None:
        self._settings = settings
        self._clients: dict[str, ProxmoxClient] = {}

    def get_client(self, name: str) -> ProxmoxClient:
        """Return (and lazily create) the client for the named node."""
        node_cfg = next(
            (n for n in self._settings.nodes if n.name == name), None
        )
        if node_cfg is None:
            available = ", ".join(n.name for n in self._settings.nodes)
            raise HiveframeAPIError(
                f"Node '{name}' not found in config. Available: {available}"
            )
        if name not in self._clients:
            self._clients[name] = ProxmoxClient(node_cfg)
        return self._clients[name]

    def get_node_settings(self, name: str) -> NodeSettings:
        """Return the NodeSettings for the named node without connecting."""
        node_cfg = next(
            (n for n in self._settings.nodes if n.name == name), None
        )
        if node_cfg is None:
            available = ", ".join(n.name for n in self._settings.nodes)
            raise HiveframeAPIError(
                f"Node '{name}' not found in config. Available: {available}"
            )
        return node_cfg

    def list_nodes(self) -> list[str]:
        """Return configured node names in order."""
        return [n.name for n in self._settings.nodes]

    def all_clients(self) -> dict[str, ProxmoxClient]:
        """Connect to all configured nodes and return the client map."""
        for node in self._settings.nodes:
            self.get_client(node.name)
        return dict(self._clients)
