"""Webhook alert sender for drift/recovery events."""

from __future__ import annotations

import time
from datetime import datetime, timezone
from typing import TYPE_CHECKING

import httpx
from rich.console import Console

from hiveframe.config.settings import WebhookSettings

if TYPE_CHECKING:
    from hiveframe.provision.drift import DriftReport

console = Console(legacy_windows=False)


# ---------------------------------------------------------------------------
# Payload builders (pure functions, one per provider × event)
# ---------------------------------------------------------------------------

def _iso(dt: datetime) -> str:
    return dt.strftime("%Y-%m-%dT%H:%M:%SZ")


def _missing_vlans(report: DriftReport) -> list[str]:
    return [i.name for i in report.vlans if i.status == "MISSING"]


def _missing_vms(report: DriftReport) -> list[str]:
    return [i.name for i in report.vms if i.status == "MISSING"]


def _stopped_vms(report: DriftReport) -> list[str]:
    return [i.name for i in report.vms if i.status == "STOPPED"]


def _slack_drift(report: DriftReport, stack_name: str) -> dict:
    parts = _missing_vlans(report) + _missing_vms(report) + _stopped_vms(report)
    missing_str = ", ".join(parts) if parts else "see report"
    checked = report.checked_at.strftime("%Y-%m-%d %H:%M UTC")
    body = f"*DRIFT DETECTED* — {stack_name}\nMissing: {missing_str}\nChecked: {checked}"
    return {
        "text": f"*DRIFT DETECTED* — {stack_name}",
        "blocks": [{"type": "section", "text": {"type": "mrkdwn", "text": body}}],
    }


def _slack_recovery(stack_name: str) -> dict:
    return {"text": f"✓ {stack_name} — all resources healthy"}


def _discord_drift(report: DriftReport, stack_name: str) -> dict:
    fields = []
    mv = _missing_vlans(report)
    if mv:
        fields.append({"name": "Missing VLANs", "value": ", ".join(mv), "inline": True})
    mm = _missing_vms(report)
    if mm:
        fields.append({"name": "Missing VMs", "value": ", ".join(mm), "inline": True})
    sv = _stopped_vms(report)
    if sv:
        fields.append({"name": "Stopped VMs", "value": ", ".join(sv), "inline": True})
    embed: dict = {
        "title": f"DRIFT DETECTED — {stack_name}",
        "color": 15158332,
        "timestamp": _iso(report.checked_at),
    }
    if fields:
        embed["fields"] = fields
    return {"embeds": [embed]}


def _discord_recovery(stack_name: str) -> dict:
    return {"embeds": [{"title": f"{stack_name} — all resources healthy", "color": 3066993}]}


def _generic_drift(report: DriftReport, stack_name: str) -> dict:
    return {
        "event": "drift",
        "stack": stack_name,
        "timestamp": _iso(report.checked_at),
        "missing_vlans": _missing_vlans(report),
        "missing_vms": _missing_vms(report),
        "stopped_vms": _stopped_vms(report),
    }


def _generic_recovery(stack_name: str) -> dict:
    return {
        "event": "recovery",
        "stack": stack_name,
        "timestamp": _iso(datetime.now(timezone.utc)),
        "missing_vlans": [],
        "missing_vms": [],
        "stopped_vms": [],
    }


_DRIFT_BUILDERS = {
    "slack": _slack_drift,
    "discord": _discord_drift,
    "generic": _generic_drift,
}

_RECOVERY_BUILDERS = {
    "slack": _slack_recovery,
    "discord": _discord_recovery,
    "generic": _generic_recovery,
}


# ---------------------------------------------------------------------------
# WebhookAlert — stateless sender
# ---------------------------------------------------------------------------

class WebhookAlert:
    """Sends drift/recovery payloads to configured webhook endpoints."""

    def __init__(self, settings: list[WebhookSettings]) -> None:
        self._settings = settings

    def send_drift(self, report: DriftReport, stack_name: str) -> None:
        for ws in self._settings:
            if "drift" in ws.on:
                self._send(ws, _DRIFT_BUILDERS[ws.provider](report, stack_name))

    def send_recovery(self, stack_name: str) -> None:
        for ws in self._settings:
            if "recovery" in ws.on:
                self._send(ws, _RECOVERY_BUILDERS[ws.provider](stack_name))

    def _send(self, ws: WebhookSettings, payload: dict) -> None:
        last_exc: Exception | None = None
        for attempt in range(2):
            if attempt > 0:
                time.sleep(5)
            try:
                r = httpx.post(ws.url, json=payload, timeout=10.0)
                r.raise_for_status()
                console.print(f"Webhook sent: {ws.name}")
                return
            except Exception as exc:
                last_exc = exc

        if last_exc is not None:
            if hasattr(last_exc, "response") and last_exc.response is not None:
                detail: object = last_exc.response.status_code
            else:
                detail = str(last_exc)
            console.print(f"[yellow]Webhook failed: {ws.name} ({detail})[/yellow]")


# ---------------------------------------------------------------------------
# DriftAlertState — tracks transitions between watch-loop polls
# ---------------------------------------------------------------------------

class DriftAlertState:
    """Fires drift/recovery alerts only on state transitions, not every poll."""

    def __init__(self, alert: WebhookAlert, stack_name: str) -> None:
        self._alert = alert
        self._stack_name = stack_name
        self._was_drifted: bool | None = None  # None = no previous observation

    def evaluate(self, report: DriftReport) -> None:
        now_drifted = report.has_drift
        if self._was_drifted is None:
            self._was_drifted = now_drifted
            return
        if not self._was_drifted and now_drifted:
            self._alert.send_drift(report, self._stack_name)
        elif self._was_drifted and not now_drifted:
            self._alert.send_recovery(self._stack_name)
        self._was_drifted = now_drifted
