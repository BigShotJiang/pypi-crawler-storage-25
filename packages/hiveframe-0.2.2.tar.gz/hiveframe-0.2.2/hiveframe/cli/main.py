"""HiveFrame CLI entry point."""

from __future__ import annotations

import os
import time
from pathlib import Path

import click
from rich.console import Console
from rich.table import Table

console = Console(legacy_windows=False)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _load_stack(file: str):
    from hiveframe.models import Stack
    try:
        return Stack.from_file(file)
    except Exception as exc:
        console.print(f"[red]FAIL[/red] Failed to load {file}: {exc}")
        raise SystemExit(1) from exc


def _load_settings(debug: bool = False):
    from hiveframe.config.settings import load_settings, resolve_config_path
    try:
        cfg_path = resolve_config_path()
        if debug:
            console.print(f"[dim]config: {cfg_path.resolve()}[/dim]")
        return load_settings(cfg_path)
    except FileNotFoundError as exc:
        console.print(f"[red]FAIL[/red] Config not found: {exc}")
        raise SystemExit(1) from exc
    except Exception as exc:
        console.print(f"[red]FAIL[/red] Cannot load config: {exc}")
        raise SystemExit(1) from exc


def _make_registry(debug: bool = False):
    from hiveframe.api.client import NodeRegistry
    return NodeRegistry(_load_settings(debug))


def _vlan_table(title: str, rows: list) -> Table:
    t = Table(title=title, show_lines=False)
    t.add_column("Action", style="bold")
    t.add_column("VLAN ID", justify="right")
    t.add_column("Bridge")
    t.add_column("Node")
    t.add_column("CIDR")
    t.add_column("Detail", style="dim")
    for action, vlan_id, bridge, node, cidr, detail, colour in rows:
        t.add_row(
            f"[{colour}]{action}[/{colour}]",
            str(vlan_id), bridge, node, cidr, detail,
        )
    return t


def _vm_table(title: str, rows: list) -> Table:
    t = Table(title=title, show_lines=False)
    t.add_column("Action", style="bold")
    t.add_column("VM Name")
    t.add_column("VMID", justify="right")
    t.add_column("VLAN")
    t.add_column("Node")
    t.add_column("Detail", style="dim")
    for action, name, vmid, vlan, node, detail, colour in rows:
        t.add_row(
            f"[{colour}]{action}[/{colour}]",
            name, str(vmid) if vmid is not None else "-", vlan, node, detail,
        )
    return t


def _fw_table(title: str, rows: list) -> Table:
    t = Table(title=title, show_lines=False)
    t.add_column("VM")
    t.add_column("Rules", justify="right")
    t.add_column("Action", style="bold")
    t.add_column("VMID", justify="right")
    t.add_column("Node")
    t.add_column("Detail", style="dim")
    for vm_name, rule_count, action, vmid, node, detail, colour in rows:
        t.add_row(
            vm_name,
            str(rule_count),
            f"[{colour}]{action}[/{colour}]",
            str(vmid) if vmid is not None else "-",
            node,
            detail,
        )
    return t


def _drift_vlan_table(title: str, rows: list) -> Table:
    t = Table(title=title, show_lines=False)
    t.add_column("Status", style="bold")
    t.add_column("Bridge")
    t.add_column("VLAN ID", justify="right")
    t.add_column("CIDR")
    t.add_column("Detail", style="dim")
    for status, bridge, vlan_id, cidr, detail, colour in rows:
        t.add_row(f"[{colour}]{status}[/{colour}]", bridge, vlan_id, cidr, detail)
    return t


def _drift_vm_table(title: str, rows: list) -> Table:
    t = Table(title=title, show_lines=False)
    t.add_column("Status", style="bold")
    t.add_column("VM Name")
    t.add_column("VLAN")
    t.add_column("Detail", style="dim")
    for status, name, vlan, detail, colour in rows:
        t.add_row(f"[{colour}]{status}[/{colour}]", name, vlan, detail)
    return t


# ---------------------------------------------------------------------------
# CLI group
# ---------------------------------------------------------------------------

@click.group()
@click.version_option(package_name="hiveframe")
@click.option("--debug", is_flag=True, default=False, help="Print config path and extra diagnostics")
@click.pass_context
def cli(ctx: click.Context, debug: bool) -> None:
    """HiveFrame -- Proxmox automation toolkit."""
    ctx.ensure_object(dict)
    ctx.obj["debug"] = debug


# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------

@cli.command()
@click.option("--name", "-n", default=None, help="Stack name")
@click.option("--node", default=None, help="Default Proxmox node name")
@click.option("--file", "-f", default="stack.yaml", show_default=True)
@click.option("--force", is_flag=True, help="Overwrite without prompting")
def init(name: str | None, node: str | None, file: str, force: bool) -> None:
    """Scaffold a new stack.yaml with commented fields explaining each option."""
    out = Path(file)

    if name is None:
        name = click.prompt("Stack name", default="my-stack")
    if node is None:
        node = click.prompt("Proxmox node name", default="pve")

    if out.exists() and not force:
        click.confirm(f"{file} already exists. Overwrite?", abort=True)

    content = (
        f"name: {name}  # stack identifier\n"
        f"node: {node}  # default node (must match a node in config.yaml)\n"
        "\n"
        "vlans:\n"
        "  - name: mgmt          # VLAN name — referenced by VMs\n"
        "    vlan_id: 10         # VLAN ID (1-4094)\n"
        "    cidr: 192.168.10.0/24\n"
        "    gateway: 192.168.10.1\n"
        "    description: Management VLAN\n"
        "\n"
        "vms:\n"
        "  - name: my-vm         # VM hostname\n"
        "    template_id: 9000   # Proxmox VM ID of the template to clone\n"
        "    vlan: mgmt          # must match a vlan name above\n"
        "    cores: 2\n"
        "    memory_mb: 2048\n"
        "    disk_gb: 20\n"
        "    start_on_create: false\n"
        "    cloud_init:\n"
        "      user: admin\n"
        "      password: changeme  # change this\n"
        "      ssh_keys: []\n"
        "      ip_config: dhcp     # or: ip=192.168.10.5/24,gw=192.168.10.1\n"
        "    firewall: []          # optional — add rules here\n"
    )

    out.write_text(content, encoding="utf-8")
    console.print(f"[green]OK[/green] Created [bold]{file}[/bold] — edit it, then run: [bold]hiveframe validate[/bold]")


@cli.command()
@click.option("--file", "-f", default="stack.yaml", show_default=True, help="Path to stack file (.yaml or .toml)")
def validate(file: str) -> None:
    """Validate a stack.yaml against the schema."""
    stack = _load_stack(file)
    console.print(f"[green]OK[/green] {file} is valid -- stack [bold]{stack.name}[/bold]")
    console.print(f"  VLANs : {len(stack.vlans)}")
    console.print(f"  VMs   : {len(stack.vms)}")


@cli.command()
@click.option("--file", "-f", default="stack.yaml", show_default=True, help="Path to stack file (.yaml or .toml)")
@click.pass_context
def plan(ctx: click.Context, file: str) -> None:
    """Dry-run -- show what would be provisioned."""
    from hiveframe.provision.engine import ProvisionEngine

    stack = _load_stack(file)
    registry = _make_registry(debug=ctx.obj.get("debug", False))
    engine = ProvisionEngine(stack, registry)
    stack_path = Path(file)

    try:
        vlan_actions = engine.plan_vlans()
        vm_actions = engine.plan_vms()
        fw_actions = engine.plan_firewall(stack_path)
    except Exception as exc:
        console.print(f"[red]FAIL[/red] Plan failed: {exc}")
        raise SystemExit(1) from exc

    # VLAN table
    vlan_rows = []
    for a in vlan_actions:
        colour = "green" if a.action == "CREATE" else "yellow"
        vlan_rows.append((a.action, a.vlan.vlan_id, a.bridge_name, a.node, a.vlan.cidr, a.reason, colour))
    console.print(_vlan_table(f"Plan -- VLANs ({stack.name})", vlan_rows))

    # VM table
    vm_rows = []
    for a in vm_actions:
        colour = "green" if a.action == "CREATE" else "yellow"
        vm_rows.append((a.action, a.vm.name, None, a.vm.vlan, a.node, a.reason, colour))
    if vm_rows:
        console.print(_vm_table(f"Plan -- VMs ({stack.name})", vm_rows))

    # Firewall table
    if fw_actions:
        fw_rows = []
        for a in fw_actions:
            colour = {"CREATE": "green", "REPLACE": "cyan", "SKIP": "yellow"}[a.action]
            fw_rows.append((a.vm.name, a.rule_count, a.action, a.vmid, a.node, a.reason, colour))
        console.print(_fw_table(f"Plan -- Firewall ({stack.name})", fw_rows))

    vlan_creates = sum(1 for a in vlan_actions if a.action == "CREATE")
    vm_creates = sum(1 for a in vm_actions if a.action == "CREATE")
    fw_creates = sum(1 for a in fw_actions if a.action in ("CREATE", "REPLACE"))
    console.print(
        f"\n  VLANs:    [bold]{vlan_creates}[/bold] to create, "
        f"[bold]{len(vlan_actions) - vlan_creates}[/bold] to skip"
    )
    console.print(
        f"  VMs:      [bold]{vm_creates}[/bold] to create, "
        f"[bold]{len(vm_actions) - vm_creates}[/bold] to skip"
    )
    if fw_actions:
        console.print(
            f"  Firewall: [bold]{fw_creates}[/bold] to apply, "
            f"[bold]{len(fw_actions) - fw_creates}[/bold] to skip"
        )


@cli.command()
@click.option("--file", "-f", default="stack.yaml", show_default=True, help="Path to stack file (.yaml or .toml)")
@click.pass_context
def apply(ctx: click.Context, file: str) -> None:
    """Provision the stack against the live Proxmox host."""
    from hiveframe.provision.engine import ProvisionEngine

    stack = _load_stack(file)
    registry = _make_registry(debug=ctx.obj.get("debug", False))
    engine = ProvisionEngine(stack, registry)
    stack_yaml = Path(file)

    console.print(f"Applying stack [bold]{stack.name}[/bold]...")

    # --- VLANs ---
    try:
        vlan_results = engine.apply_vlans(stack_yaml)
    except Exception as exc:
        console.print(f"[red]FAIL[/red] VLAN apply failed: {exc}")
        raise SystemExit(1) from exc

    vlan_rows = []
    for r in vlan_results:
        colour = {"CREATED": "green", "SKIPPED": "yellow", "FAILED": "red"}[r.outcome]
        vlan_rows.append((r.outcome, r.vlan.vlan_id, r.bridge_name, r.node, r.vlan.cidr, r.reason, colour))
    console.print(_vlan_table(f"Apply -- VLANs ({stack.name})", vlan_rows))

    if any(r.outcome == "FAILED" for r in vlan_results):
        console.print("[red]FAIL[/red] VLAN provisioning had failures -- skipping VMs.")
        raise SystemExit(1)

    # --- VMs ---
    if stack.vms:
        try:
            vm_results = engine.apply_vms(stack_yaml)
        except Exception as exc:
            console.print(f"[red]FAIL[/red] VM apply failed: {exc}")
            raise SystemExit(1) from exc

        vm_rows = []
        for r in vm_results:
            colour = {"CREATED": "green", "SKIPPED": "yellow", "FAILED": "red"}[r.outcome]
            vm_rows.append((r.outcome, r.vm.name, r.vmid, r.vm.vlan, r.node, r.reason, colour))
        console.print(_vm_table(f"Apply -- VMs ({stack.name})", vm_rows))

        if any(r.outcome == "FAILED" for r in vm_results):
            console.print("[red]FAIL[/red] VM provisioning had failures.")
            raise SystemExit(1)

    # --- Firewall ---
    vms_with_fw = [vm for vm in stack.vms if vm.firewall]
    if vms_with_fw:
        try:
            fw_results = engine.apply_firewall(stack_yaml)
        except Exception as exc:
            console.print(f"[red]FAIL[/red] Firewall apply failed: {exc}")
            raise SystemExit(1) from exc

        fw_rows = []
        for r in fw_results:
            colour = {"APPLIED": "green", "SKIPPED": "yellow", "FAILED": "red"}[r.outcome]
            fw_rows.append((r.vm.name, r.rule_count, r.outcome, r.vmid, r.node, r.reason, colour))
        console.print(_fw_table(f"Apply -- Firewall ({stack.name})", fw_rows))

        if any(r.outcome == "FAILED" for r in fw_results):
            console.print("[red]FAIL[/red] Firewall provisioning had failures.")
            raise SystemExit(1)

    console.print("\n[green]OK[/green] State written to .hiveframe-state.json")


@cli.command()
@click.option("--file", "-f", default="stack.yaml", show_default=True, help="Path to stack file (.yaml or .toml)")
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation prompt")
@click.pass_context
def destroy(ctx: click.Context, file: str, yes: bool) -> None:
    """Tear down a previously applied stack (firewall, VMs, then VLANs)."""
    from hiveframe.provision.engine import ProvisionEngine

    stack = _load_stack(file)

    if not yes:
        click.confirm(f"Destroy all resources in stack '{stack.name}'?", abort=True)

    registry = _make_registry(debug=ctx.obj.get("debug", False))
    engine = ProvisionEngine(stack, registry)
    stack_yaml = Path(file)

    # --- Firewall first ---
    vms_with_fw = [vm for vm in stack.vms if vm.firewall]
    if vms_with_fw:
        try:
            fw_results = engine.destroy_firewall(stack_yaml)
        except Exception as exc:
            console.print(f"[red]FAIL[/red] Firewall destroy failed: {exc}")
            raise SystemExit(1) from exc

        if fw_results:
            fw_rows = []
            for r in fw_results:
                colour = {"APPLIED": "green", "SKIPPED": "yellow", "FAILED": "red"}[r.outcome]
                label = "CLEARED" if r.outcome == "APPLIED" else r.outcome
                fw_rows.append((r.vm.name, r.rule_count, label, r.vmid, r.node, r.reason, colour))
            console.print(_fw_table(f"Destroy -- Firewall ({stack.name})", fw_rows))

        if any(r.outcome == "FAILED" for r in fw_results):
            console.print("[red]FAIL[/red] Firewall destroy had failures.")
            raise SystemExit(1)

    # --- VMs second ---
    if stack.vms:
        try:
            vm_results = engine.destroy_vms(stack_yaml)
        except Exception as exc:
            console.print(f"[red]FAIL[/red] VM destroy failed: {exc}")
            raise SystemExit(1) from exc

        if vm_results:
            vm_rows = []
            for r in vm_results:
                colour = {"CREATED": "green", "SKIPPED": "yellow", "FAILED": "red"}[r.outcome]
                label = "DELETED" if r.outcome == "CREATED" else r.outcome
                vm_rows.append((label, r.vm.name, r.vmid, r.vm.vlan, r.node, r.reason, colour))
            console.print(_vm_table(f"Destroy -- VMs ({stack.name})", vm_rows))

        if any(r.outcome == "FAILED" for r in vm_results):
            console.print("[red]FAIL[/red] VM destroy had failures -- skipping VLAN teardown.")
            raise SystemExit(1)

    # --- VLANs last ---
    try:
        vlan_results = engine.destroy_vlans(stack_yaml)
    except Exception as exc:
        console.print(f"[red]FAIL[/red] VLAN destroy failed: {exc}")
        raise SystemExit(1) from exc

    vlan_rows = []
    for r in vlan_results:
        colour = {"CREATED": "green", "SKIPPED": "yellow", "FAILED": "red"}[r.outcome]
        label = "DELETED" if r.outcome == "CREATED" else r.outcome
        vlan_rows.append((label, r.vlan.vlan_id, r.bridge_name, r.node, r.vlan.cidr, r.reason, colour))
    console.print(_vlan_table(f"Destroy -- VLANs ({stack.name})", vlan_rows))

    if any(r.outcome == "FAILED" for r in vlan_results):
        console.print("[red]FAIL[/red] VLAN destroy had failures.")
        raise SystemExit(1)


@cli.command()
@click.option("--file", "-f", default="stack.yaml", show_default=True, help="Path to stack file (.yaml or .toml)")
@click.option("--watch", "-w", is_flag=True, default=False, help="Poll continuously for drift")
@click.option(
    "--interval", "-i",
    default=30, show_default=True, type=int,
    help="Polling interval in seconds (min 10, requires --watch)",
)
@click.pass_context
def status(ctx: click.Context, file: str, watch: bool, interval: int) -> None:
    """Show stack drift vs live Proxmox. Use --watch to poll continuously."""
    from hiveframe.alerts.webhooks import DriftAlertState, WebhookAlert
    from hiveframe.api.client import NodeRegistry
    from hiveframe.provision.drift import DriftDetector
    from hiveframe.provision.state import load_state

    if interval < 10:
        console.print("[red]FAIL[/red] --interval must be at least 10 seconds")
        raise SystemExit(1)

    stack = _load_stack(file)
    stack_yaml = Path(file)
    settings = _load_settings(debug=ctx.obj.get("debug", False))
    registry = NodeRegistry(settings)
    alerter = WebhookAlert(settings.webhooks)
    detector = DriftDetector(stack, registry)

    _colours = {"OK": "green", "MISSING": "red", "STOPPED": "yellow", "UNEXPECTED": "dim"}

    def _print_report(report) -> None:
        bridge_to_vlan = {v.bridge: v for v in stack.vlans}
        vlan_rows = []
        for item in report.vlans:
            if item.status == "UNEXPECTED":
                continue
            cfg = bridge_to_vlan.get(item.name)
            vlan_rows.append((
                item.status, item.name,
                str(cfg.vlan_id) if cfg else "-",
                cfg.cidr if cfg else "-",
                item.detail or "",
                _colours[item.status],
            ))
        console.print(_drift_vlan_table(f"Status -- VLANs ({stack.name})", vlan_rows))

        name_to_vm = {vm.name: vm for vm in stack.vms}
        vm_rows = []
        for item in report.vms:
            if item.status == "UNEXPECTED":
                continue
            cfg = name_to_vm.get(item.name)
            vm_rows.append((
                item.status, item.name,
                cfg.vlan if cfg else "-",
                item.detail or "",
                _colours[item.status],
            ))
        if vm_rows:
            console.print(_drift_vm_table(f"Status -- VMs ({stack.name})", vm_rows))

        if report.has_drift:
            console.print("\n[red bold]! DRIFT DETECTED[/red bold]")
        else:
            console.print("\n[green]All resources healthy[/green]")

        unmanaged = sum(1 for i in report.vlans + report.vms if i.status == "UNEXPECTED")
        if unmanaged:
            console.print(
                f"  [dim]{unmanaged} unmanaged resource{'s' if unmanaged != 1 else ''} "
                "on node (not tracked by Hiveframe)[/dim]"
            )

    if not watch:
        try:
            report = detector.check()
        except Exception as exc:
            console.print(f"[red]FAIL[/red] Status check failed: {exc}")
            raise SystemExit(1) from exc
        _print_report(report)
        state = load_state(stack_yaml)
        if state:
            console.print(f"\n  Applied at: [dim]{state.applied_at}[/dim]")
        return

    # Watch loop
    state_tracker = DriftAlertState(alerter, stack.name)
    try:
        while True:
            os.system("cls" if os.name == "nt" else "clear")
            console.print(
                f"Watching [bold]{stack.name}[/bold] — every {interval}s — Ctrl+C to stop"
            )
            for node_name in registry.list_nodes():
                ns = registry.get_node_settings(node_name)
                try:
                    registry.get_client(node_name)
                    console.print(f"  [green]{node_name} ({ns.host}) — connected[/green]")
                except Exception:
                    console.print(f"  [red]{node_name} ({ns.host}) — unreachable[/red]")
            try:
                report = detector.check()
                console.print(
                    f"  Last checked: [dim]"
                    f"{report.checked_at.strftime('%Y-%m-%d %H:%M:%S')} UTC[/dim]"
                )
                _print_report(report)
                state_tracker.evaluate(report)
            except Exception as exc:
                console.print(
                    f"[yellow]Connection error — retrying in {interval}s: {exc}[/yellow]"
                )
            time.sleep(interval)
    except KeyboardInterrupt:
        console.print("\nStopped.")
        raise SystemExit(0)


from hiveframe.cli.template_cmd import template as _template_group
from hiveframe.cli.snapshot_cmd import snapshot as _snapshot_group
from hiveframe.cli.license_cmd import license_group as _license_group
from hiveframe.cli.stack_cmd import stack as _stack_group

cli.add_command(_template_group, name="template")
cli.add_command(_snapshot_group, name="snapshot")
cli.add_command(_license_group, name="license")
cli.add_command(_stack_group, name="stack")


@cli.group()
def config() -> None:
    """Manage HiveFrame configuration."""


@config.command("init")
@click.option("--force", is_flag=True, help="Overwrite without prompting")
def config_init(force: bool) -> None:
    """Interactive setup wizard for ~/.hiveframe/config.yaml."""
    import yaml
    from hiveframe.config.settings import _HOME_CONFIG

    cfg_path = _HOME_CONFIG

    if cfg_path.exists() and not force:
        click.confirm(f"Config already exists at {cfg_path}. Overwrite?", abort=True)

    console.print("Setting up Proxmox connection. Press Enter to accept defaults.\n")

    node_name = click.prompt("Node name", default="pve")
    host = click.prompt("Host IP or hostname")
    user = click.prompt("User", default="root@pam")
    token_id = click.prompt("API token ID")
    token_secret = click.prompt("API token secret", hide_input=True)
    verify_ssl = click.confirm("Verify SSL?", default=False)

    data = {
        "nodes": [{
            "name": node_name,
            "host": host,
            "user": user,
            "token_id": token_id,
            "token_secret": token_secret,
            "verify_ssl": verify_ssl,
        }]
    }

    cfg_path.parent.mkdir(parents=True, exist_ok=True)
    with cfg_path.open("w", encoding="utf-8") as fh:
        yaml.safe_dump(data, fh, sort_keys=False)

    console.print(f"\n[green]OK[/green] Config written to [bold]{cfg_path}[/bold]")
    console.print("  Next: [bold]hiveframe init[/bold] to scaffold a stack file")


@cli.group()
def webhook() -> None:
    """Manage webhook alerts."""


@webhook.command("test")
@click.option("--name", "-n", required=True, help="Webhook name from config")
@click.pass_context
def webhook_test(ctx: click.Context, name: str) -> None:
    """Send a test drift payload to verify a webhook URL."""
    import datetime
    from hiveframe.alerts.webhooks import WebhookAlert
    from hiveframe.provision.drift import DriftItem, DriftReport

    settings = _load_settings(debug=ctx.obj.get("debug", False))
    ws = next((w for w in settings.webhooks if w.name == name), None)
    if ws is None:
        available = ", ".join(w.name for w in settings.webhooks) or "none configured"
        console.print(f"[red]FAIL[/red] Webhook '{name}' not found. Available: {available}")
        raise SystemExit(1)

    report = DriftReport(
        checked_at=datetime.datetime.now(datetime.timezone.utc),
        vlans=[DriftItem("vmbr99", "vlan", "MISSING")],
        vms=[DriftItem("test-vm", "vm", "MISSING")],
    )
    console.print(f"Sending test drift payload to [bold]{ws.name}[/bold] ({ws.provider})...")
    WebhookAlert([ws]).send_drift(report, "test-stack")


@cli.command()
@click.option("--host", default="127.0.0.1", show_default=True, help="Bind address")
@click.option("--port", default=8080, show_default=True, type=int, help="Port")
def web(host: str, port: int) -> None:
    """Start the HiveFrame web dashboard."""
    import uvicorn
    from hiveframe.web.app import app as fastapi_app
    console.print(f"[green]OK[/green] Dashboard at [bold]http://{host}:{port}[/bold]")
    console.print("  Press Ctrl+C to stop.")
    uvicorn.run(fastapi_app, host=host, port=port, log_level="warning")
