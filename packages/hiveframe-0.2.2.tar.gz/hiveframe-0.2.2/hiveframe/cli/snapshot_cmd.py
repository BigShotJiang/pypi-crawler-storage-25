"""Snapshot subgroup — stack-aware VM snapshot management."""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path

import click
from rich.console import Console
from rich.table import Table

console = Console(legacy_windows=False)

_ACTION_COLOURS = {
    "CREATED": "green",
    "RESTORED": "cyan",
    "DELETED": "red",
    "SKIPPED": "yellow",
    "FAILED": "bold red",
}


def _load_stack(stack_yaml: Path):
    from hiveframe.models import Stack
    try:
        return Stack.from_file(str(stack_yaml))
    except Exception as exc:
        console.print(f"[red]FAIL[/red] Failed to load {stack_yaml}: {exc}")
        raise SystemExit(1) from exc


def _make_registry(debug: bool = False):
    from hiveframe.api.client import NodeRegistry
    from hiveframe.config.settings import load_settings, resolve_config_path
    try:
        cfg_path = resolve_config_path()
        if debug:
            console.print(f"[dim]config: {cfg_path.resolve()}[/dim]")
        return NodeRegistry(load_settings(cfg_path))
    except FileNotFoundError as exc:
        console.print(f"[red]FAIL[/red] Config not found: {exc}")
        raise SystemExit(1) from exc
    except Exception as exc:
        console.print(f"[red]FAIL[/red] Cannot load config: {exc}")
        raise SystemExit(1) from exc


def _result_table(title: str, results) -> Table:
    t = Table(title=title, show_lines=False)
    t.add_column("VM")
    t.add_column("VMID", justify="right")
    t.add_column("Snapshot")
    t.add_column("Action", style="bold")
    t.add_column("Detail", style="dim")
    for r in results:
        colour = _ACTION_COLOURS.get(r.action, "white")
        t.add_row(
            r.vm_name,
            str(r.vmid) if r.vmid else "-",
            r.snapshot_name,
            f"[{colour}]{r.action}[/{colour}]",
            r.detail or "",
        )
    return t


@click.group()
def snapshot() -> None:
    """Stack-aware VM snapshot management."""


@snapshot.command("create")
@click.argument("name")
@click.option("--description", "-d", default="", show_default=False, help="Snapshot description")
@click.option("--file", "-f", default="stack.yaml", show_default=True)
@click.pass_context
def snapshot_create(ctx: click.Context, name: str, description: str, file: str) -> None:
    """Create a snapshot of every VM in the stack."""
    from hiveframe.provision.snapshot import SnapshotEngine

    stack_yaml = Path(file)
    stack = _load_stack(stack_yaml)
    registry = _make_registry(ctx.obj.get("debug", False))
    engine = SnapshotEngine(stack, registry, stack_yaml)

    try:
        results = engine.create(name, description)
    except ValueError as exc:
        console.print(f"[red]FAIL[/red] {exc}")
        raise SystemExit(1) from exc
    except Exception as exc:
        console.print(f"[red]FAIL[/red] Snapshot create failed: {exc}")
        raise SystemExit(1) from exc

    console.print(_result_table(f"Snapshot Create — {stack.name}", results))
    if any(r.action == "FAILED" for r in results):
        raise SystemExit(1)


@snapshot.command("list")
@click.option("--file", "-f", default="stack.yaml", show_default=True)
@click.pass_context
def snapshot_list(ctx: click.Context, file: str) -> None:
    """List all snapshots across VMs in the stack."""
    from hiveframe.provision.snapshot import SnapshotEngine

    stack_yaml = Path(file)
    stack = _load_stack(stack_yaml)
    registry = _make_registry(ctx.obj.get("debug", False))
    engine = SnapshotEngine(stack, registry, stack_yaml)

    try:
        snap_map = engine.list_snapshots()
    except Exception as exc:
        console.print(f"[red]FAIL[/red] Snapshot list failed: {exc}")
        raise SystemExit(1) from exc

    vmid_map = {}
    from hiveframe.provision.state import load_state
    state = load_state(stack_yaml)
    if state:
        vmid_map = {vs.name: vs.vmid for vs in state.vms}

    t = Table(title=f"Snapshots — {stack.name}", show_lines=False)
    t.add_column("VM")
    t.add_column("VMID", justify="right")
    t.add_column("Snapshot")
    t.add_column("Created")

    total = 0
    for vm_name, snaps in snap_map.items():
        vmid = vmid_map.get(vm_name, 0)
        for snap in snaps:
            snap_time = snap.get("snaptime")
            if snap_time:
                created = datetime.fromtimestamp(snap_time, tz=timezone.utc).strftime(
                    "%Y-%m-%d %H:%M UTC"
                )
            else:
                created = "-"
            t.add_row(vm_name, str(vmid) if vmid else "-", snap.get("name", ""), created)
            total += 1

    if total == 0:
        console.print("[yellow]No snapshots found for this stack.[/yellow]")
        return

    console.print(t)


@snapshot.command("restore")
@click.argument("name")
@click.option("--file", "-f", default="stack.yaml", show_default=True)
@click.pass_context
def snapshot_restore(ctx: click.Context, name: str, file: str) -> None:
    """Restore every VM in the stack to a snapshot."""
    from hiveframe.provision.snapshot import SnapshotEngine

    stack_yaml = Path(file)
    stack = _load_stack(stack_yaml)
    registry = _make_registry(ctx.obj.get("debug", False))
    engine = SnapshotEngine(stack, registry, stack_yaml)

    try:
        results = engine.restore(name)
    except ValueError as exc:
        console.print(f"[red]FAIL[/red] {exc}")
        raise SystemExit(1) from exc
    except Exception as exc:
        console.print(f"[red]FAIL[/red] Snapshot restore failed: {exc}")
        raise SystemExit(1) from exc

    console.print(_result_table(f"Snapshot Restore — {stack.name}", results))
    if any(r.action == "FAILED" for r in results):
        raise SystemExit(1)


@snapshot.command("delete")
@click.argument("name")
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation prompt")
@click.option("--file", "-f", default="stack.yaml", show_default=True)
@click.pass_context
def snapshot_delete(ctx: click.Context, name: str, yes: bool, file: str) -> None:
    """Delete a snapshot from every VM in the stack."""
    from hiveframe.provision.snapshot import SnapshotEngine

    stack_yaml = Path(file)
    stack = _load_stack(stack_yaml)

    if not yes:
        click.confirm(
            f"Delete snapshot '{name}' from all VMs in stack '{stack.name}'?", abort=True
        )

    registry = _make_registry(ctx.obj.get("debug", False))
    engine = SnapshotEngine(stack, registry, stack_yaml)

    try:
        results = engine.delete(name)
    except ValueError as exc:
        console.print(f"[red]FAIL[/red] {exc}")
        raise SystemExit(1) from exc
    except Exception as exc:
        console.print(f"[red]FAIL[/red] Snapshot delete failed: {exc}")
        raise SystemExit(1) from exc

    console.print(_result_table(f"Snapshot Delete — {stack.name}", results))
    if any(r.action == "FAILED" for r in results):
        raise SystemExit(1)
