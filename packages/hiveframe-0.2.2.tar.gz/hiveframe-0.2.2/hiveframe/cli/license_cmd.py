"""License management subgroup."""

from __future__ import annotations

import click
from rich.console import Console

console = Console(legacy_windows=False)


@click.group(name="license")
def license_group() -> None:
    """Manage Hiveframe license."""


@license_group.command("status")
def license_status() -> None:
    """Show current license tier and masked key."""
    from hiveframe.license import License, load_license_key

    key = load_license_key()
    lic = License(key)
    result = lic.validate()

    if result.tier == "pro":
        masked = key[:7] + "*" * (len(key) - 7) if key else ""
        console.print(f"[green]Pro tier[/green] — all features unlocked")
        console.print(f"  Key: {masked}")
    else:
        if key and not result.valid:
            console.print(f"[yellow]Warning:[/yellow] {result.message}")
        console.print("[dim]Free tier[/dim] — core features only")
        console.print(
            "  Run [bold]hiveframe license activate <key>[/bold] to unlock Pro."
        )


@license_group.command("activate")
@click.argument("key")
def license_activate(key: str) -> None:
    """Validate a license key and save it to ~/.hiveframe/config.yaml."""
    from hiveframe.license import License, write_license_key

    result = License(key).validate()
    if not result.valid or result.tier != "pro":
        console.print(f"[red]FAIL[/red] {result.message}")
        raise SystemExit(1)

    write_license_key(key)
    console.print("[green]OK[/green] License activated — Pro tier unlocked")
