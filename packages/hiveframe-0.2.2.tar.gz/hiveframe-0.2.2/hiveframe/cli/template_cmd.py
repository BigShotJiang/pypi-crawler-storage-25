"""Template subgroup — browse and scaffold pre-built stack templates."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

import click
from rich.console import Console
from rich.table import Table

console = Console(legacy_windows=False)

_TEMPLATES_DIR = Path(__file__).resolve().parent.parent / "templates"


def _all_templates() -> list[dict]:
    """Return metadata for every bundled template, sorted by name."""
    result = []
    if not _TEMPLATES_DIR.is_dir():
        return result
    for entry in sorted(_TEMPLATES_DIR.iterdir()):
        meta_file = entry / "meta.json"
        if entry.is_dir() and meta_file.exists():
            result.append(json.loads(meta_file.read_text(encoding="utf-8")))
    return result


def _get_template(name: str) -> Path:
    """Return the template directory for *name*, or exit with an error."""
    path = _TEMPLATES_DIR / name
    if not path.is_dir() or not (path / "meta.json").exists():
        available = ", ".join(t["name"] for t in _all_templates()) or "none"
        console.print(
            f"[red]FAIL[/red] Template '[bold]{name}[/bold]' not found. "
            f"Available: {available}"
        )
        raise SystemExit(1)
    return path


@click.group()
def template() -> None:
    """Browse and scaffold pre-built stack templates."""


@template.command("list")
def template_list() -> None:
    """List all available stack templates."""
    templates = _all_templates()
    if not templates:
        console.print("[yellow]No templates found.[/yellow]")
        return

    t = Table(show_lines=False)
    t.add_column("Name", style="bold")
    t.add_column("Description")
    t.add_column("VLANs", justify="right")
    t.add_column("VMs", justify="right")
    t.add_column("Tags", style="dim")

    for meta in templates:
        t.add_row(
            meta["name"],
            meta["description"],
            str(meta.get("vlans", "-")),
            str(meta.get("vms", "-")),
            ", ".join(meta.get("tags", [])),
        )

    console.print(t)
    console.print(
        f"\n  [dim]{len(templates)} template{'s' if len(templates) != 1 else ''} available. "
        "Run [bold]hiveframe template use <name>[/bold] to scaffold.[/dim]"
    )


@template.command("show")
@click.argument("name")
def template_show(name: str) -> None:
    """Show details and README for a template."""
    tmpl_dir = _get_template(name)
    meta = json.loads((tmpl_dir / "meta.json").read_text(encoding="utf-8"))

    console.print(f"\n[bold]{meta['display_name']}[/bold]  v{meta['version']}")
    console.print(f"  {meta['description']}\n")
    console.print(f"  Author  : {meta['author']}")
    console.print(f"  VLANs   : {meta.get('vlans', '-')}")
    console.print(f"  VMs     : {meta.get('vms', '-')}")
    console.print(f"  Tags    : {', '.join(meta.get('tags', []))}")
    console.print(f"  Proxmox : {meta.get('proxmox_version', 'any')}\n")

    readme = tmpl_dir / "README.md"
    if readme.exists():
        console.print("[dim]─── README ────────────────────────────────────────[/dim]")
        console.print(readme.read_text(encoding="utf-8"))


@template.command("use")
@click.argument("name")
@click.option(
    "--output", "-o",
    default="stack.yaml",
    show_default=True,
    help="Destination file path",
)
def template_use(name: str, output: str) -> None:
    """Copy a template to stack.yaml (or --output path)."""
    tmpl_dir = _get_template(name)
    src = tmpl_dir / "template.yaml"
    dest = Path(output)

    if dest.exists():
        click.confirm(f"{output} already exists. Overwrite?", abort=True)

    shutil.copy2(src, dest)
    console.print(f"[green]OK[/green] Template [bold]{name}[/bold] written to [bold]{output}[/bold]")
    console.print(
        "  Next: edit [bold]template_id[/bold] fields, "
        "then run [bold]hiveframe validate[/bold]"
    )
