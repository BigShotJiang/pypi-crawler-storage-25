"""Stack management subgroup (Pro features)."""

from __future__ import annotations

from pathlib import Path

import click
from rich.console import Console
from rich.table import Table

console = Console(legacy_windows=False)


def _load_stack(path: Path):
    from hiveframe.models import Stack
    try:
        return Stack.from_file(path)
    except Exception as exc:
        console.print(f"[red]FAIL[/red] Failed to load {path}: {exc}")
        raise SystemExit(1) from exc


def _make_registry(debug: bool = False):
    from hiveframe.api.client import NodeRegistry
    from hiveframe.config.settings import load_settings, resolve_config_path
    try:
        cfg_path = resolve_config_path()
        if debug:
            console.print(f"[dim]config: {cfg_path.resolve()}[/dim]")
        return NodeRegistry(load_settings(cfg_path))
    except FileNotFoundError as exc:
        console.print(f"[red]FAIL[/red] Config not found: {exc}")
        raise SystemExit(1) from exc
    except Exception as exc:
        console.print(f"[red]FAIL[/red] Cannot load config: {exc}")
        raise SystemExit(1) from exc


@click.group()
def stack() -> None:
    """Stack management operations."""


@stack.command("clone")
@click.option("--from", "source", required=True,
              help="Path to source stack.yaml or .toml")
@click.option("--name", required=True,
              help="New stack name (used as prefix for all resources)")
@click.option("--output", default=None,
              help="Output path (default: <name>.yaml in current directory)")
@click.option("--vlan-offset", default=None, type=int,
              help="Manually set VLAN ID offset instead of auto-detecting")
@click.pass_context
def stack_clone(
    ctx: click.Context,
    source: str,
    name: str,
    output: str | None,
    vlan_offset: int | None,
) -> None:
    """Clone a stack definition with renamed resources (Pro)."""
    from hiveframe.license import require_pro
    from hiveframe.provision.clone import StackCloner

    require_pro("Stack cloning")

    source_path = Path(source)
    output_path = Path(output) if output else Path.cwd() / f"{name}.yaml"

    src_stack = _load_stack(source_path)
    registry = _make_registry(ctx.obj.get("debug", False))
    cloner = StackCloner(src_stack, registry)

    try:
        rows = cloner.clone(name, output_path, vlan_offset=vlan_offset)
    except ValueError as exc:
        console.print(f"[red]FAIL[/red] {exc}")
        raise SystemExit(1) from exc
    except Exception as exc:
        console.print(f"[red]FAIL[/red] Clone failed: {exc}")
        raise SystemExit(1) from exc

    t = Table(show_lines=False)
    t.add_column("Original")
    t.add_column("Cloned")
    for row in rows:
        t.add_row(f"{row.kind}: {row.original}", f"{row.kind}: {row.cloned}")
    console.print(t)

    console.print(f"\n[green]OK[/green] Written to [bold]{output_path}[/bold]")
