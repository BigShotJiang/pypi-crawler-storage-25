"""Stack state sidecar — written next to stack.yaml as .hiveframe-state.json."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Literal

from pydantic import BaseModel, Field


class VlanState(BaseModel):
    vlan_id: int
    bridge: str
    status: Literal["applied", "failed"]
    node: str = Field(default="")


class VmState(BaseModel):
    name: str
    vmid: int
    vlan: str
    status: Literal["applied", "failed"]
    firewall_rules_count: int = Field(default=0)
    node: str = Field(default="")
    snapshots: list[str] = Field(default_factory=list)


class StackState(BaseModel):
    stack_name: str
    applied_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    vlans: list[VlanState] = Field(default_factory=list)
    vms: list[VmState] = Field(default_factory=list)


def state_path_for(stack_yaml: Path) -> Path:
    return stack_yaml.parent / ".hiveframe-state.json"


def load_state(stack_yaml: Path) -> StackState | None:
    path = state_path_for(stack_yaml)
    if not path.exists():
        return None
    data = json.loads(path.read_text())
    return StackState.model_validate(data)


def save_state(stack_yaml: Path, state: StackState) -> None:
    path = state_path_for(stack_yaml)
    path.write_text(json.dumps(state.model_dump(mode="json"), indent=2))


def merge_vlan_states(
    existing: StackState | None,
    stack_name: str,
    new_vlans: list[VlanState],
) -> StackState:
    base_vlans: dict[int, VlanState] = {}
    base_vms: list[VmState] = []
    if existing and existing.stack_name == stack_name:
        base_vlans = {v.vlan_id: v for v in existing.vlans}
        base_vms = existing.vms
    for vs in new_vlans:
        base_vlans[vs.vlan_id] = vs
    return StackState(
        stack_name=stack_name,
        vlans=list(base_vlans.values()),
        vms=base_vms,
    )


def merge_vm_states(
    existing: StackState | None,
    stack_name: str,
    new_vms: list[VmState],
) -> StackState:
    base_vlans: list[VlanState] = []
    base_vms: dict[str, VmState] = {}
    if existing and existing.stack_name == stack_name:
        base_vlans = existing.vlans
        base_vms = {v.name: v for v in existing.vms}
    for vm in new_vms:
        base_vms[vm.name] = vm
    return StackState(
        stack_name=stack_name,
        vlans=base_vlans,
        vms=list(base_vms.values()),
    )


def remove_vlan_states(existing: StackState, vlan_ids: set[int]) -> StackState:
    return StackState(
        stack_name=existing.stack_name,
        applied_at=existing.applied_at,
        vlans=[v for v in existing.vlans if v.vlan_id not in vlan_ids],
        vms=existing.vms,
    )


def remove_vm_states(existing: StackState, vm_names: set[str]) -> StackState:
    return StackState(
        stack_name=existing.stack_name,
        applied_at=existing.applied_at,
        vlans=existing.vlans,
        vms=[v for v in existing.vms if v.name not in vm_names],
    )
