"""Stack cloning — rename all resources and find a free VLAN ID block."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from hiveframe.api.client import HiveframeAPIError, NodeRegistry
from hiveframe.models import Stack
from hiveframe.models.vlan import VlanConfig
from hiveframe.models.vm import VmConfig


@dataclass
class RenameRow:
    kind: str
    original: str
    cloned: str


class StackCloner:
    def __init__(self, source: Stack, registry: NodeRegistry) -> None:
        self.source = source
        self.registry = registry

    def _used_vlan_ids(self, node: str) -> set[int]:
        """Return VLAN IDs already in use as Linux bridges on the node."""
        try:
            client = self.registry.get_client(node)
            ifaces = client.get_network_config(node)
        except HiveframeAPIError:
            return set()
        result: set[int] = set()
        for iface in ifaces:
            name = iface.get("iface", "")
            if name.startswith("vmbr"):
                try:
                    result.add(int(name[4:]))
                except ValueError:
                    pass
        return result

    def _find_offset(self, node: str) -> int:
        """Find the smallest positive offset that places all source VLANs at free IDs."""
        source_ids = [v.vlan_id for v in self.source.vlans]
        if not source_ids:
            return 0
        used = self._used_vlan_ids(node)
        min_step = min(source_ids)
        offset = min_step
        while offset <= 4094:
            new_ids = {sid + offset for sid in source_ids}
            if all(1 <= nid <= 4094 and nid not in used for nid in new_ids):
                return offset
            offset += min_step
        raise ValueError(
            f"No free VLAN ID block found in range 1–4094 for source VLANs {source_ids}."
        )

    def clone(
        self,
        new_name: str,
        output: Path,
        vlan_offset: int | None = None,
    ) -> list[RenameRow]:
        """Clone the source stack with a new name, writing the result to *output*.

        Returns a list of RenameRow entries suitable for table display.
        """
        node = self.source.node
        offset = vlan_offset if vlan_offset is not None else self._find_offset(node)

        rows: list[RenameRow] = [RenameRow("Stack", self.source.name, new_name)]

        # Rename VLANs
        vlan_name_map: dict[str, str] = {}
        new_vlans: list[VlanConfig] = []
        for v in self.source.vlans:
            new_vlan_name = f"{new_name}-{v.name}"
            new_vlan_id = v.vlan_id + offset
            vlan_name_map[v.name] = new_vlan_name
            new_vlans.append(v.model_copy(update={"name": new_vlan_name, "vlan_id": new_vlan_id}))
            rows.append(RenameRow(
                "VLAN",
                f"{v.name} ({v.vlan_id})",
                f"{new_vlan_name} ({new_vlan_id})",
            ))

        # Rename VMs
        new_vms: list[VmConfig] = []
        for vm in self.source.vms:
            new_vm_name = f"{new_name}-{vm.name}"
            new_vlan_ref = vlan_name_map[vm.vlan]
            new_vms.append(vm.model_copy(update={"name": new_vm_name, "vlan": new_vlan_ref}))
            rows.append(RenameRow("VM", vm.name, new_vm_name))

        new_stack = Stack(
            name=new_name,
            description=self.source.description,
            node=node,
            vlans=new_vlans,
            vms=new_vms,
        )
        new_stack.to_yaml(output)

        return rows
