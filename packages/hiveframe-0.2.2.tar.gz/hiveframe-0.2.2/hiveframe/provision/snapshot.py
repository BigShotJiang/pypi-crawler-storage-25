"""Snapshot management — stack-aware create, list, restore, delete."""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Literal

from hiveframe.api.client import HiveframeAPIError, NodeRegistry
from hiveframe.models import Stack
from hiveframe.provision.state import StackState, VmState, load_state, save_state

_SNAP_NAME_RE = re.compile(r"^[a-zA-Z0-9\-]{1,40}$")


def _validate_snapshot_name(name: str) -> None:
    if not _SNAP_NAME_RE.match(name):
        raise ValueError(
            f"Invalid snapshot name '{name}'. "
            "Must be alphanumeric + hyphens only, max 40 characters."
        )


@dataclass
class SnapshotResult:
    vm_name: str
    vmid: int
    snapshot_name: str
    action: Literal["CREATED", "RESTORED", "DELETED", "SKIPPED", "FAILED"]
    detail: str | None = None


class SnapshotEngine:
    def __init__(self, stack: Stack, registry: NodeRegistry, stack_yaml: Path) -> None:
        self.stack = stack
        self.registry = registry
        self.stack_yaml = stack_yaml

    def _node(self, vm_state: VmState) -> str:
        return vm_state.node or self.stack.node

    def _state_vms(self) -> dict[str, VmState]:
        state = load_state(self.stack_yaml)
        if not state:
            return {}
        return {vs.name: vs for vs in state.vms if vs.vmid != 0}

    def create(self, snapshot_name: str, description: str = "") -> list[SnapshotResult]:
        _validate_snapshot_name(snapshot_name)
        state_vms = self._state_vms()
        results: list[SnapshotResult] = []

        for vm_cfg in self.stack.vms:
            vs = state_vms.get(vm_cfg.name)
            if vs is None:
                results.append(SnapshotResult(
                    vm_cfg.name, 0, snapshot_name, "SKIPPED",
                    "VM not in state — run hiveframe apply first",
                ))
                continue
            if vs.vmid == vm_cfg.template_id:
                results.append(SnapshotResult(
                    vm_cfg.name, vs.vmid, snapshot_name, "SKIPPED",
                    "VMID matches template — skipping",
                ))
                continue

            node = self._node(vs)
            client = self.registry.get_client(node)
            try:
                task = client.create_vm_snapshot(node, vs.vmid, snapshot_name, description)
                client.wait_for_task(node, task)
                results.append(SnapshotResult(vm_cfg.name, vs.vmid, snapshot_name, "CREATED"))
            except HiveframeAPIError as exc:
                results.append(SnapshotResult(
                    vm_cfg.name, vs.vmid, snapshot_name, "FAILED", str(exc)
                ))

        created_vms = {r.vm_name for r in results if r.action == "CREATED"}
        if created_vms:
            self._append_snapshot(created_vms, snapshot_name)

        return results

    def list_snapshots(self) -> dict[str, list[dict]]:
        state_vms = self._state_vms()
        result: dict[str, list[dict]] = {}
        for vm_cfg in self.stack.vms:
            vs = state_vms.get(vm_cfg.name)
            if vs is None:
                continue
            node = self._node(vs)
            client = self.registry.get_client(node)
            try:
                snaps = client.list_vm_snapshots(node, vs.vmid)
                result[vm_cfg.name] = [s for s in snaps if s.get("name") != "current"]
            except HiveframeAPIError:
                result[vm_cfg.name] = []
        return result

    def restore(self, snapshot_name: str) -> list[SnapshotResult]:
        _validate_snapshot_name(snapshot_name)
        state_vms = self._state_vms()
        results: list[SnapshotResult] = []

        for vm_cfg in self.stack.vms:
            vs = state_vms.get(vm_cfg.name)
            if vs is None:
                results.append(SnapshotResult(
                    vm_cfg.name, 0, snapshot_name, "SKIPPED",
                    "VM not in state — run hiveframe apply first",
                ))
                continue

            node = self._node(vs)
            client = self.registry.get_client(node)
            try:
                was_running = client.get_vm_status(node, vs.vmid) == "running"
                if was_running:
                    stop_task = client.stop_vm(node, vs.vmid)
                    client.wait_for_task(node, stop_task)

                task = client.restore_vm_snapshot(node, vs.vmid, snapshot_name)
                client.wait_for_task(node, task)

                if was_running:
                    start_task = client.start_vm(node, vs.vmid)
                    client.wait_for_task(node, start_task)

                results.append(SnapshotResult(vm_cfg.name, vs.vmid, snapshot_name, "RESTORED"))
            except HiveframeAPIError as exc:
                results.append(SnapshotResult(
                    vm_cfg.name, vs.vmid, snapshot_name, "FAILED", str(exc)
                ))

        return results

    def delete(self, snapshot_name: str) -> list[SnapshotResult]:
        _validate_snapshot_name(snapshot_name)
        state_vms = self._state_vms()
        results: list[SnapshotResult] = []

        for vm_cfg in self.stack.vms:
            vs = state_vms.get(vm_cfg.name)
            if vs is None:
                results.append(SnapshotResult(
                    vm_cfg.name, 0, snapshot_name, "SKIPPED",
                    "VM not in state — run hiveframe apply first",
                ))
                continue

            node = self._node(vs)
            client = self.registry.get_client(node)
            try:
                snaps = client.list_vm_snapshots(node, vs.vmid)
                existing_names = {s.get("name") for s in snaps}
                if snapshot_name not in existing_names:
                    results.append(SnapshotResult(
                        vm_cfg.name, vs.vmid, snapshot_name, "SKIPPED",
                        "snapshot does not exist on this VM",
                    ))
                    continue

                task = client.delete_vm_snapshot(node, vs.vmid, snapshot_name)
                client.wait_for_task(node, task)
                results.append(SnapshotResult(vm_cfg.name, vs.vmid, snapshot_name, "DELETED"))
            except HiveframeAPIError as exc:
                results.append(SnapshotResult(
                    vm_cfg.name, vs.vmid, snapshot_name, "FAILED", str(exc)
                ))

        deleted_vms = {r.vm_name for r in results if r.action == "DELETED"}
        if deleted_vms:
            self._remove_snapshot(deleted_vms, snapshot_name)

        return results

    # ------------------------------------------------------------------
    # State helpers
    # ------------------------------------------------------------------

    def _append_snapshot(self, vm_names: set[str], snapshot_name: str) -> None:
        state = load_state(self.stack_yaml)
        if not state:
            return
        updated = [
            VmState(
                name=vs.name,
                vmid=vs.vmid,
                vlan=vs.vlan,
                status=vs.status,
                firewall_rules_count=vs.firewall_rules_count,
                node=vs.node,
                snapshots=(
                    vs.snapshots + [snapshot_name]
                    if snapshot_name not in vs.snapshots
                    else vs.snapshots
                ) if vs.name in vm_names else vs.snapshots,
            )
            for vs in state.vms
        ]
        save_state(self.stack_yaml, StackState(
            stack_name=state.stack_name,
            applied_at=state.applied_at,
            vlans=state.vlans,
            vms=updated,
        ))

    def _remove_snapshot(self, vm_names: set[str], snapshot_name: str) -> None:
        state = load_state(self.stack_yaml)
        if not state:
            return
        updated = [
            VmState(
                name=vs.name,
                vmid=vs.vmid,
                vlan=vs.vlan,
                status=vs.status,
                firewall_rules_count=vs.firewall_rules_count,
                node=vs.node,
                snapshots=(
                    [s for s in vs.snapshots if s != snapshot_name]
                    if vs.name in vm_names else vs.snapshots
                ),
            )
            for vs in state.vms
        ]
        save_state(self.stack_yaml, StackState(
            stack_name=state.stack_name,
            applied_at=state.applied_at,
            vlans=state.vlans,
            vms=updated,
        ))
