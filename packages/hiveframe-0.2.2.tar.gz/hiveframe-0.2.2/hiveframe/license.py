"""License key validation and Pro feature gating."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Literal

import yaml

_HOME_CONFIG = Path.home() / ".hiveframe" / "config.yaml"
_PRO_PREFIX = "HF-PRO-"
_PRO_KEY_LEN = 32


@dataclass
class LicenseResult:
    valid: bool
    tier: Literal["free", "pro"]
    message: str


class License:
    def __init__(self, key: str | None) -> None:
        self._key = key

    def is_pro(self) -> bool:
        return self.validate().tier == "pro"

    def validate(self) -> LicenseResult:
        if not self._key:
            return LicenseResult(valid=True, tier="free", message="No license key — free tier")
        if self._key.startswith(_PRO_PREFIX) and len(self._key) == _PRO_KEY_LEN:
            return LicenseResult(valid=True, tier="pro", message="Pro license active")
        return LicenseResult(
            valid=False,
            tier="free",
            message=(
                f"Invalid license key format — must start with '{_PRO_PREFIX}' "
                f"and be {_PRO_KEY_LEN} characters total"
            ),
        )


def load_license_key() -> str | None:
    """Read license_key from ~/.hiveframe/config.yaml without loading full settings."""
    if not _HOME_CONFIG.exists():
        return None
    data: dict = yaml.safe_load(_HOME_CONFIG.read_text(encoding="utf-8")) or {}
    return data.get("license_key") or None


def write_license_key(key: str) -> None:
    """Write license_key to ~/.hiveframe/config.yaml, preserving all other settings."""
    _HOME_CONFIG.parent.mkdir(parents=True, exist_ok=True)
    data: dict = {}
    if _HOME_CONFIG.exists():
        data = yaml.safe_load(_HOME_CONFIG.read_text(encoding="utf-8")) or {}
    data["license_key"] = key
    _HOME_CONFIG.write_text(yaml.safe_dump(data, sort_keys=False), encoding="utf-8")


_PRO_UPSELL = (
    "\nThis feature requires Hiveframe Pro.\n\n"
    "Hiveframe Pro unlocks:\n"
    "  - Stack cloning\n"
    "  - [future pro features]\n\n"
    "Get a license at: https://codeberg.org/itzdrixxyy/hiveframe\n\n"
    "Already have a key? Add it to ~/.hiveframe/config.yaml:\n"
    "  license_key: HF-PRO-your-key-here"
)


def require_pro(feature_name: str) -> None:
    """Exit with code 1 if the current license is not Pro."""
    lic = License(load_license_key())
    result = lic.validate()
    if result.tier != "pro":
        from rich.console import Console
        console = Console(legacy_windows=False)
        if not result.valid:
            console.print(f"[yellow]Warning:[/yellow] {result.message}")
        console.print(_PRO_UPSELL)
        raise SystemExit(1)
