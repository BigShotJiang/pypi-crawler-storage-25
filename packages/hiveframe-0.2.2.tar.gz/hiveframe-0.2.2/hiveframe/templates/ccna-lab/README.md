# CCNA Lab

Two-VLAN network with routed segments for CCNA routing/switching practice.

## What this sets up

- **mgmt** (VLAN 10, `192.168.10.0/24`) — management network with a router VM
- **lab** (VLAN 20, `192.168.20.0/24`) — lab segment with a workstation VM

Both VMs clone from template ID 9000. Update `template_id` to match your actual cloud-init template before running `hiveframe apply`.

## Usage

```bash
hiveframe template use ccna-lab
# edit template_id in stack.yaml
hiveframe validate
hiveframe apply
```

## Practice scenarios

- Configure inter-VLAN routing on the router VM
- Practice static and dynamic routing (OSPF, EIGRP) between segments
- Simulate access/distribution/core layer switching

## Notes

- Both VMs start with `start_on_create: false` — start them manually once configured
- Default credentials: `labuser` / `changeme` — change before exposing to any network
- `template_id: 9000` is a placeholder; replace with your actual Proxmox template VMID
