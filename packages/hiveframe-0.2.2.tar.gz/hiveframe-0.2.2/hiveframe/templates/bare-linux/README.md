# Bare Linux

Minimal single VM on a flat VLAN for general-purpose use.

## What this sets up

- **default** (VLAN 10, `192.168.10.0/24`) — single flat network
- One `linux-01` VM with 2 cores and 2 GB RAM

## Usage

```bash
hiveframe template use bare-linux
# edit template_id in stack.yaml
hiveframe validate
hiveframe apply
```

## Use cases

- Quick throwaway VM for testing commands or scripts
- Starting point to build a custom stack from scratch
- Minimal footprint when you only need one machine

## Notes

- The VM starts with `start_on_create: false` — start it manually once configured
- Default credentials: `labuser` / `changeme` — change before use
- `template_id: 9000` is a placeholder; replace with your actual Proxmox template VMID
