# Security Lab

Basic attack/defense lab with isolated network segments.

## What this sets up

- **external** (VLAN 10, `10.0.10.0/24`) — attacker network
- **internal** (VLAN 20, `10.0.20.0/24`) — target network

The `target` VM has a firewall pre-configured to allow SSH inbound and drop everything else.

## Usage

```bash
hiveframe template use security-lab
# edit template_id in stack.yaml
hiveframe validate
hiveframe apply
```

## Practice scenarios

- Network enumeration and service discovery from the attacker VM
- Exploit practice against the target VM
- Firewall rule analysis and bypass techniques
- Packet capture and traffic analysis between segments

## Notes

- Both VMs start with `start_on_create: false` — start them manually once configured
- Default credentials: `labuser` / `changeme` — change before use
- `template_id: 9000` is a placeholder; replace with your actual Proxmox template VMID
- The attacker VM has 4 GB RAM by default; reduce if your host is constrained
