# Web Stack

Two-tier web application lab with dedicated frontend and backend network segments.

## What this sets up

- **frontend** (VLAN 10, `172.16.10.0/24`) — web server network
- **backend** (VLAN 20, `172.16.20.0/24`) — database network

## Usage

```bash
hiveframe template use web-stack
# edit template_id in stack.yaml
hiveframe validate
hiveframe apply
```

## Practice scenarios

- Deploy a web application (nginx/Apache) on the webserver VM
- Set up a database (PostgreSQL/MySQL) on the database VM
- Practice network segmentation and firewall rules between tiers
- Test application connectivity across VLAN boundaries

## Notes

- Both VMs start with `start_on_create: false` — start them manually once configured
- Default credentials: `labuser` / `changeme` — change before use
- `template_id: 9000` is a placeholder; replace with your actual Proxmox template VMID
- The database VM has 4 GB RAM by default; adjust to your workload
