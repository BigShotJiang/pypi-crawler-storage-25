"""Tests for WebhookAlert payload formatting, filtering, error handling, and transition tracking."""

from __future__ import annotations

import datetime
from unittest.mock import MagicMock, patch

import httpx
import pytest
from pydantic import ValidationError

from hiveframe.alerts.webhooks import DriftAlertState, WebhookAlert
from hiveframe.config.settings import WebhookSettings
from hiveframe.provision.drift import DriftItem, DriftReport


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_CHECKED_AT = datetime.datetime(2026, 4, 23, 0, 35, 0, tzinfo=datetime.timezone.utc)


def _ws(name: str = "test", provider: str = "generic", on: list | None = None) -> WebhookSettings:
    return WebhookSettings(
        name=name,
        url="https://example.com/hook",
        provider=provider,  # type: ignore[arg-type]
        on=on or ["drift", "recovery"],
    )


def _report(*, missing_vlan: bool = False, missing_vm: bool = False, stopped_vm: bool = False) -> DriftReport:
    vlans = [DriftItem("vmbr99", "vlan", "MISSING")] if missing_vlan else [DriftItem("vmbr10", "vlan", "OK")]
    if missing_vm:
        vms = [DriftItem("vm-01", "vm", "MISSING")]
    elif stopped_vm:
        vms = [DriftItem("vm-01", "vm", "STOPPED")]
    else:
        vms = [DriftItem("vm-01", "vm", "OK")]
    return DriftReport(checked_at=_CHECKED_AT, vlans=vlans, vms=vms)


def _ok_response() -> MagicMock:
    resp = MagicMock(status_code=200)
    resp.raise_for_status.return_value = None
    return resp


# ---------------------------------------------------------------------------
# WebhookSettings validation
# ---------------------------------------------------------------------------

class TestWebhookSettings:
    def test_url_must_start_with_http(self):
        with pytest.raises(ValidationError, match="http"):
            WebhookSettings(name="bad", url="ftp://example.com", provider="generic")

    def test_non_url_raises(self):
        with pytest.raises(ValidationError):
            WebhookSettings(name="bad", url="not-a-url", provider="generic")

    def test_valid_https_url_passes(self):
        ws = WebhookSettings(name="ok", url="https://hooks.slack.com/xxx", provider="slack")
        assert ws.url.startswith("https://")

    def test_on_defaults_to_drift_only(self):
        ws = WebhookSettings(name="ok", url="https://example.com", provider="generic")
        assert ws.on == ["drift"]


# ---------------------------------------------------------------------------
# Slack payload
# ---------------------------------------------------------------------------

class TestSlackPayload:
    def test_drift_text_field(self):
        alerter = WebhookAlert([_ws(provider="slack")])
        with patch("httpx.post", return_value=_ok_response()) as mock_post:
            alerter.send_drift(_report(missing_vlan=True, missing_vm=True), "my-stack")
        payload = mock_post.call_args[1]["json"]
        assert payload["text"] == "*DRIFT DETECTED* — my-stack"

    def test_drift_blocks_contain_missing_resources(self):
        alerter = WebhookAlert([_ws(provider="slack")])
        with patch("httpx.post", return_value=_ok_response()) as mock_post:
            alerter.send_drift(_report(missing_vlan=True, missing_vm=True), "my-stack")
        block_text = mock_post.call_args[1]["json"]["blocks"][0]["text"]["text"]
        assert "vmbr99" in block_text
        assert "vm-01" in block_text
        assert "2026-04-23 00:35 UTC" in block_text

    def test_drift_blocks_mrkdwn_type(self):
        alerter = WebhookAlert([_ws(provider="slack")])
        with patch("httpx.post", return_value=_ok_response()) as mock_post:
            alerter.send_drift(_report(missing_vm=True), "stack")
        block = mock_post.call_args[1]["json"]["blocks"][0]
        assert block["type"] == "section"
        assert block["text"]["type"] == "mrkdwn"

    def test_recovery_text_contains_healthy(self):
        alerter = WebhookAlert([_ws(provider="slack")])
        with patch("httpx.post", return_value=_ok_response()) as mock_post:
            alerter.send_recovery("my-stack")
        payload = mock_post.call_args[1]["json"]
        assert "healthy" in payload["text"]
        assert "my-stack" in payload["text"]

    def test_recovery_has_no_blocks(self):
        alerter = WebhookAlert([_ws(provider="slack")])
        with patch("httpx.post", return_value=_ok_response()) as mock_post:
            alerter.send_recovery("stack")
        payload = mock_post.call_args[1]["json"]
        assert "blocks" not in payload


# ---------------------------------------------------------------------------
# Discord payload
# ---------------------------------------------------------------------------

class TestDiscordPayload:
    def test_drift_embed_title_and_color(self):
        alerter = WebhookAlert([_ws(provider="discord")])
        with patch("httpx.post", return_value=_ok_response()) as mock_post:
            alerter.send_drift(_report(missing_vm=True), "my-stack")
        embed = mock_post.call_args[1]["json"]["embeds"][0]
        assert "DRIFT DETECTED" in embed["title"]
        assert "my-stack" in embed["title"]
        assert embed["color"] == 15158332

    def test_drift_embed_has_timestamp(self):
        alerter = WebhookAlert([_ws(provider="discord")])
        with patch("httpx.post", return_value=_ok_response()) as mock_post:
            alerter.send_drift(_report(missing_vm=True), "stack")
        embed = mock_post.call_args[1]["json"]["embeds"][0]
        assert "timestamp" in embed
        assert embed["timestamp"] == "2026-04-23T00:35:00Z"

    def test_drift_missing_vlan_field(self):
        alerter = WebhookAlert([_ws(provider="discord")])
        with patch("httpx.post", return_value=_ok_response()) as mock_post:
            alerter.send_drift(_report(missing_vlan=True), "stack")
        fields = mock_post.call_args[1]["json"]["embeds"][0]["fields"]
        names = [f["name"] for f in fields]
        assert "Missing VLANs" in names

    def test_drift_missing_vm_field(self):
        alerter = WebhookAlert([_ws(provider="discord")])
        with patch("httpx.post", return_value=_ok_response()) as mock_post:
            alerter.send_drift(_report(missing_vm=True), "stack")
        fields = mock_post.call_args[1]["json"]["embeds"][0]["fields"]
        names = [f["name"] for f in fields]
        assert "Missing VMs" in names

    def test_drift_stopped_vm_field(self):
        alerter = WebhookAlert([_ws(provider="discord")])
        with patch("httpx.post", return_value=_ok_response()) as mock_post:
            alerter.send_drift(_report(stopped_vm=True), "stack")
        fields = mock_post.call_args[1]["json"]["embeds"][0]["fields"]
        names = [f["name"] for f in fields]
        assert "Stopped VMs" in names

    def test_drift_empty_categories_not_included(self):
        alerter = WebhookAlert([_ws(provider="discord")])
        with patch("httpx.post", return_value=_ok_response()) as mock_post:
            alerter.send_drift(_report(missing_vm=True), "stack")  # no missing VLAN
        fields = mock_post.call_args[1]["json"]["embeds"][0].get("fields", [])
        names = [f["name"] for f in fields]
        assert "Missing VLANs" not in names

    def test_recovery_green_color(self):
        alerter = WebhookAlert([_ws(provider="discord")])
        with patch("httpx.post", return_value=_ok_response()) as mock_post:
            alerter.send_recovery("my-stack")
        embed = mock_post.call_args[1]["json"]["embeds"][0]
        assert embed["color"] == 3066993
        assert "healthy" in embed["title"]
        assert "my-stack" in embed["title"]


# ---------------------------------------------------------------------------
# Generic payload
# ---------------------------------------------------------------------------

class TestGenericPayload:
    def test_drift_event_field(self):
        alerter = WebhookAlert([_ws(provider="generic")])
        with patch("httpx.post", return_value=_ok_response()) as mock_post:
            alerter.send_drift(_report(missing_vlan=True, missing_vm=True), "my-stack")
        payload = mock_post.call_args[1]["json"]
        assert payload["event"] == "drift"
        assert payload["stack"] == "my-stack"
        assert "timestamp" in payload
        assert "vmbr99" in payload["missing_vlans"]
        assert "vm-01" in payload["missing_vms"]
        assert payload["stopped_vms"] == []

    def test_drift_stopped_vms_populated(self):
        alerter = WebhookAlert([_ws(provider="generic")])
        with patch("httpx.post", return_value=_ok_response()) as mock_post:
            alerter.send_drift(_report(stopped_vm=True), "stack")
        payload = mock_post.call_args[1]["json"]
        assert "vm-01" in payload["stopped_vms"]
        assert payload["missing_vms"] == []

    def test_recovery_event_field(self):
        alerter = WebhookAlert([_ws(provider="generic")])
        with patch("httpx.post", return_value=_ok_response()) as mock_post:
            alerter.send_recovery("my-stack")
        payload = mock_post.call_args[1]["json"]
        assert payload["event"] == "recovery"
        assert payload["stack"] == "my-stack"
        assert payload["missing_vlans"] == []
        assert payload["missing_vms"] == []
        assert payload["stopped_vms"] == []


# ---------------------------------------------------------------------------
# Filtering by `on` list
# ---------------------------------------------------------------------------

class TestWebhookFiltering:
    def test_send_drift_skipped_when_on_excludes_drift(self):
        alerter = WebhookAlert([_ws(on=["recovery"])])
        with patch("httpx.post") as mock_post:
            alerter.send_drift(_report(missing_vm=True), "stack")
        mock_post.assert_not_called()

    def test_send_recovery_skipped_when_on_excludes_recovery(self):
        alerter = WebhookAlert([_ws(on=["drift"])])
        with patch("httpx.post") as mock_post:
            alerter.send_recovery("stack")
        mock_post.assert_not_called()

    def test_empty_webhooks_list_sends_nothing(self):
        alerter = WebhookAlert([])
        with patch("httpx.post") as mock_post:
            alerter.send_drift(_report(missing_vm=True), "stack")
            alerter.send_recovery("stack")
        mock_post.assert_not_called()

    def test_only_matching_webhooks_fire(self):
        drift_ws = _ws(name="drift-only", on=["drift"])
        recovery_ws = _ws(name="recovery-only", on=["recovery"])
        alerter = WebhookAlert([drift_ws, recovery_ws])
        with patch("httpx.post", return_value=_ok_response()) as mock_post:
            alerter.send_drift(_report(missing_vm=True), "stack")
        assert mock_post.call_count == 1


# ---------------------------------------------------------------------------
# Error handling
# ---------------------------------------------------------------------------

class TestWebhookErrorHandling:
    def test_http_error_does_not_crash(self):
        alerter = WebhookAlert([_ws()])
        mock_resp = MagicMock(status_code=403)
        mock_resp.raise_for_status.side_effect = httpx.HTTPStatusError(
            "403", request=MagicMock(), response=mock_resp
        )
        with patch("httpx.post", return_value=mock_resp), patch("time.sleep"):
            alerter.send_drift(_report(missing_vm=True), "stack")  # must not raise

    def test_network_error_does_not_crash(self):
        alerter = WebhookAlert([_ws()])
        with patch("httpx.post", side_effect=httpx.ConnectError("refused")), patch("time.sleep"):
            alerter.send_drift(_report(missing_vm=True), "stack")  # must not raise

    def test_retries_once_after_5_seconds(self):
        alerter = WebhookAlert([_ws()])
        with patch("httpx.post", side_effect=Exception("timeout")) as mock_post, \
             patch("time.sleep") as mock_sleep:
            alerter.send_drift(_report(missing_vm=True), "stack")
        assert mock_post.call_count == 2
        mock_sleep.assert_called_once_with(5)

    def test_success_on_second_attempt_does_not_log_warning(self, capsys):
        alerter = WebhookAlert([_ws()])
        call_count = 0

        def post_side_effect(*args, **kwargs):
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                raise httpx.ConnectError("first attempt fails")
            return _ok_response()

        with patch("httpx.post", side_effect=post_side_effect), patch("time.sleep"):
            alerter.send_drift(_report(missing_vm=True), "stack")

        assert call_count == 2  # retried and succeeded


# ---------------------------------------------------------------------------
# DriftAlertState — transition tracking
# ---------------------------------------------------------------------------

class TestDriftAlertState:
    def _mock_alert(self) -> MagicMock:
        return MagicMock(spec=WebhookAlert)

    def _healthy(self) -> DriftReport:
        return _report()

    def _drifted(self) -> DriftReport:
        return _report(missing_vm=True)

    def test_no_alert_on_first_poll_when_healthy(self):
        alert = self._mock_alert()
        tracker = DriftAlertState(alert, "stack")
        tracker.evaluate(self._healthy())
        alert.send_drift.assert_not_called()
        alert.send_recovery.assert_not_called()

    def test_no_alert_on_first_poll_when_drifted(self):
        alert = self._mock_alert()
        tracker = DriftAlertState(alert, "stack")
        tracker.evaluate(self._drifted())
        alert.send_drift.assert_not_called()
        alert.send_recovery.assert_not_called()

    def test_drift_alert_fires_on_healthy_to_drifted(self):
        alert = self._mock_alert()
        tracker = DriftAlertState(alert, "stack")
        tracker.evaluate(self._healthy())   # first poll — sets state
        tracker.evaluate(self._drifted())   # transition → alert
        alert.send_drift.assert_called_once()
        alert.send_recovery.assert_not_called()

    def test_drift_alert_does_not_fire_on_sustained_drift(self):
        alert = self._mock_alert()
        tracker = DriftAlertState(alert, "stack")
        tracker.evaluate(self._healthy())
        tracker.evaluate(self._drifted())
        tracker.evaluate(self._drifted())
        tracker.evaluate(self._drifted())
        assert alert.send_drift.call_count == 1

    def test_recovery_alert_fires_on_drifted_to_healthy(self):
        alert = self._mock_alert()
        tracker = DriftAlertState(alert, "stack")
        tracker.evaluate(self._drifted())   # first poll — sets state as drifted
        tracker.evaluate(self._healthy())   # transition → recovery
        alert.send_recovery.assert_called_once()
        alert.send_drift.assert_not_called()

    def test_recovery_does_not_fire_on_sustained_healthy(self):
        alert = self._mock_alert()
        tracker = DriftAlertState(alert, "stack")
        tracker.evaluate(self._drifted())
        tracker.evaluate(self._healthy())
        tracker.evaluate(self._healthy())
        tracker.evaluate(self._healthy())
        assert alert.send_recovery.call_count == 1

    def test_multiple_transitions_fire_correct_counts(self):
        alert = self._mock_alert()
        tracker = DriftAlertState(alert, "stack")
        tracker.evaluate(self._healthy())   # sets healthy
        tracker.evaluate(self._drifted())   # drift #1
        tracker.evaluate(self._drifted())   # no change
        tracker.evaluate(self._healthy())   # recovery #1
        tracker.evaluate(self._drifted())   # drift #2
        assert alert.send_drift.call_count == 2
        assert alert.send_recovery.call_count == 1

    def test_send_drift_called_with_report_and_stack_name(self):
        alert = self._mock_alert()
        tracker = DriftAlertState(alert, "my-stack")
        report = self._drifted()
        tracker.evaluate(self._healthy())
        tracker.evaluate(report)
        alert.send_drift.assert_called_once_with(report, "my-stack")
