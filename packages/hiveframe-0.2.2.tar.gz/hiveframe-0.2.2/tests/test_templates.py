"""Tests for the template library (hiveframe template list/show/use)."""

from __future__ import annotations

import json
from pathlib import Path

import pytest
import yaml
from click.testing import CliRunner

from hiveframe.cli.main import cli
from hiveframe.cli.template_cmd import _TEMPLATES_DIR, _all_templates
from hiveframe.models import Stack

# ---------------------------------------------------------------------------
# Template discovery helpers
# ---------------------------------------------------------------------------

EXPECTED_NAMES = {"ccna-lab", "security-lab", "web-stack", "bare-linux"}

META_REQUIRED_KEYS = {
    "name", "display_name", "description", "tags",
    "author", "version", "proxmox_version", "vms", "vlans",
}


class TestTemplateDiscovery:
    def test_templates_dir_exists(self):
        assert _TEMPLATES_DIR.is_dir()

    def test_all_four_templates_present(self):
        names = {t["name"] for t in _all_templates()}
        assert names == EXPECTED_NAMES

    def test_returns_exactly_four(self):
        assert len(_all_templates()) == 4

    def test_templates_sorted_alphabetically(self):
        names = [t["name"] for t in _all_templates()]
        assert names == sorted(names)

    def test_each_template_dir_has_required_files(self):
        for name in EXPECTED_NAMES:
            tmpl_dir = _TEMPLATES_DIR / name
            assert (tmpl_dir / "meta.json").exists(), f"{name}/meta.json missing"
            assert (tmpl_dir / "template.yaml").exists(), f"{name}/template.yaml missing"
            assert (tmpl_dir / "README.md").exists(), f"{name}/README.md missing"


# ---------------------------------------------------------------------------
# meta.json schema validation
# ---------------------------------------------------------------------------

class TestMetaSchema:
    @pytest.mark.parametrize("name", sorted(EXPECTED_NAMES))
    def test_all_required_keys_present(self, name):
        meta_path = _TEMPLATES_DIR / name / "meta.json"
        meta = json.loads(meta_path.read_text(encoding="utf-8"))
        missing = META_REQUIRED_KEYS - set(meta.keys())
        assert not missing, f"{name}/meta.json missing keys: {missing}"

    @pytest.mark.parametrize("name", sorted(EXPECTED_NAMES))
    def test_name_matches_directory(self, name):
        meta = json.loads((_TEMPLATES_DIR / name / "meta.json").read_text(encoding="utf-8"))
        assert meta["name"] == name

    @pytest.mark.parametrize("name", sorted(EXPECTED_NAMES))
    def test_tags_is_list(self, name):
        meta = json.loads((_TEMPLATES_DIR / name / "meta.json").read_text(encoding="utf-8"))
        assert isinstance(meta["tags"], list)
        assert len(meta["tags"]) > 0

    @pytest.mark.parametrize("name", sorted(EXPECTED_NAMES))
    def test_vms_and_vlans_are_positive_ints(self, name):
        meta = json.loads((_TEMPLATES_DIR / name / "meta.json").read_text(encoding="utf-8"))
        assert isinstance(meta["vms"], int) and meta["vms"] >= 1
        assert isinstance(meta["vlans"], int) and meta["vlans"] >= 1

    def test_ccna_lab_meta_values(self):
        meta = json.loads((_TEMPLATES_DIR / "ccna-lab" / "meta.json").read_text(encoding="utf-8"))
        assert meta["display_name"] == "CCNA Lab"
        assert meta["vms"] == 2
        assert meta["vlans"] == 2
        assert "ccna" in meta["tags"]

    def test_bare_linux_meta_values(self):
        meta = json.loads((_TEMPLATES_DIR / "bare-linux" / "meta.json").read_text(encoding="utf-8"))
        assert meta["vms"] == 1
        assert meta["vlans"] == 1


# ---------------------------------------------------------------------------
# template.yaml validation — all templates must pass hiveframe validate
# ---------------------------------------------------------------------------

class TestTemplateYaml:
    @pytest.mark.parametrize("name", sorted(EXPECTED_NAMES))
    def test_template_yaml_passes_validation(self, name):
        template_path = _TEMPLATES_DIR / name / "template.yaml"
        stack = Stack.from_file(str(template_path))
        assert stack.name == name

    @pytest.mark.parametrize("name", sorted(EXPECTED_NAMES))
    def test_template_id_is_9000(self, name):
        template_path = _TEMPLATES_DIR / name / "template.yaml"
        stack = Stack.from_file(str(template_path))
        for vm in stack.vms:
            assert vm.template_id == 9000

    @pytest.mark.parametrize("name", sorted(EXPECTED_NAMES))
    def test_start_on_create_false(self, name):
        template_path = _TEMPLATES_DIR / name / "template.yaml"
        stack = Stack.from_file(str(template_path))
        for vm in stack.vms:
            assert vm.start_on_create is False

    @pytest.mark.parametrize("name", sorted(EXPECTED_NAMES))
    def test_cloud_init_user_is_labuser(self, name):
        template_path = _TEMPLATES_DIR / name / "template.yaml"
        stack = Stack.from_file(str(template_path))
        for vm in stack.vms:
            assert vm.cloud_init.user == "labuser"

    @pytest.mark.parametrize("name", sorted(EXPECTED_NAMES))
    def test_cloud_init_password_is_changeme(self, name):
        template_path = _TEMPLATES_DIR / name / "template.yaml"
        stack = Stack.from_file(str(template_path))
        for vm in stack.vms:
            assert vm.cloud_init.password == "changeme"

    @pytest.mark.parametrize("name", sorted(EXPECTED_NAMES))
    def test_vm_count_matches_meta(self, name):
        meta = json.loads((_TEMPLATES_DIR / name / "meta.json").read_text(encoding="utf-8"))
        stack = Stack.from_file(str(_TEMPLATES_DIR / name / "template.yaml"))
        assert len(stack.vms) == meta["vms"]

    @pytest.mark.parametrize("name", sorted(EXPECTED_NAMES))
    def test_vlan_count_matches_meta(self, name):
        meta = json.loads((_TEMPLATES_DIR / name / "meta.json").read_text(encoding="utf-8"))
        stack = Stack.from_file(str(_TEMPLATES_DIR / name / "template.yaml"))
        assert len(stack.vlans) == meta["vlans"]

    def test_security_lab_has_firewall_rules_on_target(self):
        stack = Stack.from_file(str(_TEMPLATES_DIR / "security-lab" / "template.yaml"))
        target = next(vm for vm in stack.vms if vm.name == "target")
        assert len(target.firewall) >= 2
        ssh_rule = target.firewall[0]
        assert ssh_rule.action == "ACCEPT"
        assert ssh_rule.dport == "22"
        drop_rule = target.firewall[-1]
        assert drop_rule.action == "DROP"

    def test_security_lab_attacker_has_no_firewall(self):
        stack = Stack.from_file(str(_TEMPLATES_DIR / "security-lab" / "template.yaml"))
        attacker = next(vm for vm in stack.vms if vm.name == "attacker")
        assert attacker.firewall == []


# ---------------------------------------------------------------------------
# hiveframe template list
# ---------------------------------------------------------------------------

class TestTemplateList:
    def test_exit_code_zero(self):
        runner = CliRunner()
        result = runner.invoke(cli, ["template", "list"])
        assert result.exit_code == 0, result.output

    def test_all_template_names_shown(self):
        runner = CliRunner()
        result = runner.invoke(cli, ["template", "list"])
        for name in EXPECTED_NAMES:
            assert name in result.output

    def test_output_has_four_entries(self):
        runner = CliRunner()
        result = runner.invoke(cli, ["template", "list"])
        assert "4 templates" in result.output

    def test_shows_descriptions(self):
        runner = CliRunner()
        result = runner.invoke(cli, ["template", "list"])
        assert "CCNA" in result.output
        assert "attack" in result.output.lower() or "security" in result.output.lower()


# ---------------------------------------------------------------------------
# hiveframe template show
# ---------------------------------------------------------------------------

class TestTemplateShow:
    def test_exit_code_zero(self):
        runner = CliRunner()
        result = runner.invoke(cli, ["template", "show", "ccna-lab"])
        assert result.exit_code == 0, result.output

    def test_shows_display_name(self):
        runner = CliRunner()
        result = runner.invoke(cli, ["template", "show", "ccna-lab"])
        assert "CCNA Lab" in result.output

    def test_shows_description(self):
        runner = CliRunner()
        result = runner.invoke(cli, ["template", "show", "bare-linux"])
        assert "Minimal" in result.output or "single VM" in result.output

    def test_shows_readme_content(self):
        runner = CliRunner()
        result = runner.invoke(cli, ["template", "show", "ccna-lab"])
        assert "README" in result.output or "CCNA" in result.output

    def test_unknown_template_exits_nonzero(self):
        runner = CliRunner()
        result = runner.invoke(cli, ["template", "show", "does-not-exist"])
        assert result.exit_code != 0

    def test_unknown_template_lists_available(self):
        runner = CliRunner()
        result = runner.invoke(cli, ["template", "show", "does-not-exist"])
        assert "ccna-lab" in result.output

    @pytest.mark.parametrize("name", sorted(EXPECTED_NAMES))
    def test_show_all_templates(self, name):
        runner = CliRunner()
        result = runner.invoke(cli, ["template", "show", name])
        assert result.exit_code == 0, result.output


# ---------------------------------------------------------------------------
# hiveframe template use
# ---------------------------------------------------------------------------

class TestTemplateUse:
    def test_writes_stack_yaml(self, tmp_path):
        runner = CliRunner()
        with runner.isolated_filesystem(temp_dir=tmp_path) as td:
            result = runner.invoke(cli, ["template", "use", "ccna-lab"])
            assert result.exit_code == 0, result.output
            assert Path(td, "stack.yaml").exists()

    def test_output_confirms_template_name(self, tmp_path):
        runner = CliRunner()
        with runner.isolated_filesystem(temp_dir=tmp_path):
            result = runner.invoke(cli, ["template", "use", "ccna-lab"])
            assert "ccna-lab" in result.output

    def test_output_mentions_template_id(self, tmp_path):
        runner = CliRunner()
        with runner.isolated_filesystem(temp_dir=tmp_path):
            result = runner.invoke(cli, ["template", "use", "ccna-lab"])
            assert "template_id" in result.output

    def test_output_mentions_validate(self, tmp_path):
        runner = CliRunner()
        with runner.isolated_filesystem(temp_dir=tmp_path):
            result = runner.invoke(cli, ["template", "use", "ccna-lab"])
            assert "validate" in result.output

    def test_written_file_passes_stack_validation(self, tmp_path):
        runner = CliRunner()
        with runner.isolated_filesystem(temp_dir=tmp_path) as td:
            runner.invoke(cli, ["template", "use", "ccna-lab"])
            stack = Stack.from_file(str(Path(td, "stack.yaml")))
            assert stack.name == "ccna-lab"

    def test_custom_output_path(self, tmp_path):
        runner = CliRunner()
        with runner.isolated_filesystem(temp_dir=tmp_path) as td:
            result = runner.invoke(cli, ["template", "use", "bare-linux", "--output", "infra.yaml"])
            assert result.exit_code == 0, result.output
            assert Path(td, "infra.yaml").exists()
            assert not Path(td, "stack.yaml").exists()

    def test_custom_output_short_flag(self, tmp_path):
        runner = CliRunner()
        with runner.isolated_filesystem(temp_dir=tmp_path) as td:
            result = runner.invoke(cli, ["template", "use", "bare-linux", "-o", "custom.yaml"])
            assert result.exit_code == 0, result.output
            assert Path(td, "custom.yaml").exists()

    def test_prompts_before_overwrite(self, tmp_path):
        runner = CliRunner()
        with runner.isolated_filesystem(temp_dir=tmp_path) as td:
            Path(td, "stack.yaml").write_text("name: original\n")
            result = runner.invoke(cli, ["template", "use", "ccna-lab"], input="n\n")
            assert result.exit_code != 0
            assert "original" in Path(td, "stack.yaml").read_text()

    def test_overwrite_on_confirm_yes(self, tmp_path):
        runner = CliRunner()
        with runner.isolated_filesystem(temp_dir=tmp_path) as td:
            Path(td, "stack.yaml").write_text("name: original\n")
            result = runner.invoke(cli, ["template", "use", "ccna-lab"], input="y\n")
            assert result.exit_code == 0, result.output
            stack = Stack.from_file(str(Path(td, "stack.yaml")))
            assert stack.name == "ccna-lab"

    def test_unknown_template_exits_nonzero(self, tmp_path):
        runner = CliRunner()
        with runner.isolated_filesystem(temp_dir=tmp_path):
            result = runner.invoke(cli, ["template", "use", "does-not-exist"])
            assert result.exit_code != 0

    def test_unknown_template_lists_available(self, tmp_path):
        runner = CliRunner()
        with runner.isolated_filesystem(temp_dir=tmp_path):
            result = runner.invoke(cli, ["template", "use", "nope"])
            assert "ccna-lab" in result.output

    @pytest.mark.parametrize("name", sorted(EXPECTED_NAMES))
    def test_all_templates_can_be_used(self, name, tmp_path):
        runner = CliRunner()
        with runner.isolated_filesystem(temp_dir=tmp_path) as td:
            result = runner.invoke(cli, ["template", "use", name])
            assert result.exit_code == 0, result.output
            stack = Stack.from_file(str(Path(td, "stack.yaml")))
            assert stack.name == name
