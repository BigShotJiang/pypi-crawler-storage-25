"""Tests for 'hiveframe init' and 'hiveframe config init'."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import patch

import pytest
import yaml
from click.testing import CliRunner

from hiveframe.cli.main import cli
from hiveframe.models import Stack


# ---------------------------------------------------------------------------
# hiveframe init
# ---------------------------------------------------------------------------

class TestInit:
    def test_creates_stack_yaml_with_flags(self, tmp_path):
        runner = CliRunner()
        with runner.isolated_filesystem(temp_dir=tmp_path) as td:
            result = runner.invoke(cli, ["init", "--name", "my-stack", "--node", "pve"])
            assert result.exit_code == 0, result.output
            assert Path(td, "stack.yaml").exists()

    def test_output_message_mentions_validate(self, tmp_path):
        runner = CliRunner()
        with runner.isolated_filesystem(temp_dir=tmp_path):
            result = runner.invoke(cli, ["init", "--name", "test", "--node", "pve"])
            assert "validate" in result.output

    def test_name_and_node_written_to_file(self, tmp_path):
        runner = CliRunner()
        with runner.isolated_filesystem(temp_dir=tmp_path) as td:
            runner.invoke(cli, ["init", "--name", "prod-stack", "--node", "pve2"])
            stack = Stack.from_yaml(Path(td, "stack.yaml"))
            assert stack.name == "prod-stack"
            assert stack.node == "pve2"

    def test_created_file_is_valid_stack(self, tmp_path):
        runner = CliRunner()
        with runner.isolated_filesystem(temp_dir=tmp_path) as td:
            runner.invoke(cli, ["init", "--name", "test", "--node", "pve"])
            stack = Stack.from_yaml(Path(td, "stack.yaml"))
            assert len(stack.vlans) == 1
            assert len(stack.vms) == 1
            assert stack.vlans[0].name == "mgmt"
            assert stack.vms[0].vlan == "mgmt"

    def test_file_contains_comments(self, tmp_path):
        runner = CliRunner()
        with runner.isolated_filesystem(temp_dir=tmp_path) as td:
            runner.invoke(cli, ["init", "--name", "test", "--node", "pve"])
            content = Path(td, "stack.yaml").read_text()
            assert "# stack identifier" in content
            assert "# VLAN name" in content
            assert "# VM hostname" in content
            assert "# Proxmox VM ID" in content

    def test_prompts_for_name_when_not_provided(self, tmp_path):
        runner = CliRunner()
        with runner.isolated_filesystem(temp_dir=tmp_path) as td:
            result = runner.invoke(cli, ["init"], input="prompted-stack\npve\n")
            assert result.exit_code == 0, result.output
            stack = Stack.from_yaml(Path(td, "stack.yaml"))
            assert stack.name == "prompted-stack"

    def test_prompts_for_node_when_not_provided(self, tmp_path):
        runner = CliRunner()
        with runner.isolated_filesystem(temp_dir=tmp_path) as td:
            runner.invoke(cli, ["init", "--name", "test"], input="pve3\n")
            stack = Stack.from_yaml(Path(td, "stack.yaml"))
            assert stack.node == "pve3"

    def test_prompt_defaults(self, tmp_path):
        runner = CliRunner()
        with runner.isolated_filesystem(temp_dir=tmp_path) as td:
            # Accept both defaults by pressing Enter twice
            runner.invoke(cli, ["init"], input="\n\n")
            stack = Stack.from_yaml(Path(td, "stack.yaml"))
            assert stack.name == "my-stack"
            assert stack.node == "pve"

    def test_existing_file_prompts_before_overwrite(self, tmp_path):
        runner = CliRunner()
        with runner.isolated_filesystem(temp_dir=tmp_path) as td:
            runner.invoke(cli, ["init", "--name", "original", "--node", "pve"])
            result = runner.invoke(
                cli, ["init", "--name", "replacement", "--node", "pve"], input="n\n"
            )
            assert result.exit_code != 0
            # Original file must be unchanged
            stack = Stack.from_yaml(Path(td, "stack.yaml"))
            assert stack.name == "original"

    def test_existing_file_overwritten_on_confirm_yes(self, tmp_path):
        runner = CliRunner()
        with runner.isolated_filesystem(temp_dir=tmp_path) as td:
            runner.invoke(cli, ["init", "--name", "original", "--node", "pve"])
            result = runner.invoke(
                cli, ["init", "--name", "replacement", "--node", "pve"], input="y\n"
            )
            assert result.exit_code == 0, result.output
            stack = Stack.from_yaml(Path(td, "stack.yaml"))
            assert stack.name == "replacement"

    def test_force_overwrites_without_prompt(self, tmp_path):
        runner = CliRunner()
        with runner.isolated_filesystem(temp_dir=tmp_path) as td:
            runner.invoke(cli, ["init", "--name", "original", "--node", "pve"])
            result = runner.invoke(
                cli, ["init", "--name", "replacement", "--node", "pve", "--force"]
            )
            assert result.exit_code == 0, result.output
            stack = Stack.from_yaml(Path(td, "stack.yaml"))
            assert stack.name == "replacement"

    def test_custom_file_path(self, tmp_path):
        runner = CliRunner()
        with runner.isolated_filesystem(temp_dir=tmp_path) as td:
            result = runner.invoke(
                cli, ["init", "--name", "test", "--node", "pve", "--file", "infra.yaml"]
            )
            assert result.exit_code == 0, result.output
            assert Path(td, "infra.yaml").exists()
            assert not Path(td, "stack.yaml").exists()


# ---------------------------------------------------------------------------
# hiveframe config init
# ---------------------------------------------------------------------------

# Simulated input sequence: node, host, user, token_id, token_secret, verify_ssl (n)
_FULL_INPUT = "pve\n10.0.0.1\nroot@pam\nmytoken\nmysecret\nn\n"


class TestConfigInit:
    def _invoke(self, runner: CliRunner, tmp_path: Path, extra_args: list = (), input: str = _FULL_INPUT):
        cfg_path = tmp_path / "config.yaml"
        with patch("hiveframe.config.settings._HOME_CONFIG", cfg_path):
            result = runner.invoke(cli, ["config", "init", *extra_args], input=input)
        return result, cfg_path

    def test_creates_config_file(self, tmp_path):
        runner = CliRunner()
        result, cfg_path = self._invoke(runner, tmp_path)
        assert result.exit_code == 0, result.output
        assert cfg_path.exists()

    def test_output_confirms_path(self, tmp_path):
        runner = CliRunner()
        result, _ = self._invoke(runner, tmp_path)
        assert "Config written" in result.output

    def test_written_config_is_valid_settings(self, tmp_path):
        runner = CliRunner()
        _, cfg_path = self._invoke(runner, tmp_path)
        from hiveframe.config.settings import load_settings
        settings = load_settings(cfg_path)
        assert len(settings.nodes) == 1
        assert settings.nodes[0].name == "pve"
        assert settings.nodes[0].host == "10.0.0.1"

    def test_node_name_written_correctly(self, tmp_path):
        runner = CliRunner()
        input_ = "proxmox-1\n10.0.0.5\nroot@pam\ntok\nsec\nn\n"
        _, cfg_path = self._invoke(runner, tmp_path, input=input_)
        data = yaml.safe_load(cfg_path.read_text())
        assert data["nodes"][0]["name"] == "proxmox-1"

    def test_host_written_correctly(self, tmp_path):
        runner = CliRunner()
        _, cfg_path = self._invoke(runner, tmp_path)
        data = yaml.safe_load(cfg_path.read_text())
        assert data["nodes"][0]["host"] == "10.0.0.1"

    def test_token_id_written_correctly(self, tmp_path):
        runner = CliRunner()
        _, cfg_path = self._invoke(runner, tmp_path)
        data = yaml.safe_load(cfg_path.read_text())
        assert data["nodes"][0]["token_id"] == "mytoken"

    def test_verify_ssl_false_by_default(self, tmp_path):
        runner = CliRunner()
        _, cfg_path = self._invoke(runner, tmp_path)
        data = yaml.safe_load(cfg_path.read_text())
        assert data["nodes"][0]["verify_ssl"] is False

    def test_verify_ssl_true_when_confirmed(self, tmp_path):
        runner = CliRunner()
        input_ = "pve\n10.0.0.1\nroot@pam\ntok\nsec\ny\n"
        _, cfg_path = self._invoke(runner, tmp_path, input=input_)
        data = yaml.safe_load(cfg_path.read_text())
        assert data["nodes"][0]["verify_ssl"] is True

    def test_existing_config_prompts_before_overwrite(self, tmp_path):
        runner = CliRunner()
        cfg_path = tmp_path / "config.yaml"
        cfg_path.write_text("sentinel: original\n")
        with patch("hiveframe.config.settings._HOME_CONFIG", cfg_path):
            result = runner.invoke(cli, ["config", "init"], input="n\n")
        assert result.exit_code != 0
        assert "sentinel" in cfg_path.read_text()

    def test_existing_config_overwritten_on_yes(self, tmp_path):
        runner = CliRunner()
        cfg_path = tmp_path / "config.yaml"
        cfg_path.write_text("sentinel: original\n")
        with patch("hiveframe.config.settings._HOME_CONFIG", cfg_path):
            result = runner.invoke(
                cli, ["config", "init"],
                input=f"y\n{_FULL_INPUT}"
            )
        assert result.exit_code == 0, result.output
        data = yaml.safe_load(cfg_path.read_text())
        assert "nodes" in data

    def test_force_skips_overwrite_prompt(self, tmp_path):
        runner = CliRunner()
        cfg_path = tmp_path / "config.yaml"
        cfg_path.write_text("sentinel: original\n")
        with patch("hiveframe.config.settings._HOME_CONFIG", cfg_path):
            result = runner.invoke(
                cli, ["config", "init", "--force"],
                input=_FULL_INPUT
            )
        assert result.exit_code == 0, result.output
        data = yaml.safe_load(cfg_path.read_text())
        assert "nodes" in data

    def test_output_suggests_next_command(self, tmp_path):
        runner = CliRunner()
        result, _ = self._invoke(runner, tmp_path)
        assert "hiveframe init" in result.output
