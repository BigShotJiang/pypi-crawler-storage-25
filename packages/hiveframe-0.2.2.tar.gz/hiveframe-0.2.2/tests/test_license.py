"""Tests for the license key system."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import patch

import pytest
import yaml

from hiveframe.license import (
    License,
    LicenseResult,
    load_license_key,
    require_pro,
    write_license_key,
)

_VALID_PRO_KEY = "HF-PRO-" + "x" * 25   # 7 + 25 = 32 chars


# ---------------------------------------------------------------------------
# License.validate()
# ---------------------------------------------------------------------------

class TestLicenseValidate:
    def test_valid_pro_key_recognized(self):
        result = License(_VALID_PRO_KEY).validate()
        assert result.valid is True
        assert result.tier == "pro"

    def test_no_key_is_free_and_valid(self):
        result = License(None).validate()
        assert result.tier == "free"
        assert result.valid is True

    def test_empty_string_is_free(self):
        result = License("").validate()
        assert result.tier == "free"

    def test_wrong_prefix_is_free_and_invalid(self):
        result = License("HF-STD-" + "x" * 25).validate()
        assert result.tier == "free"
        assert result.valid is False

    def test_correct_prefix_wrong_length_is_invalid(self):
        result = License("HF-PRO-tooshort").validate()
        assert result.tier == "free"
        assert result.valid is False

    def test_key_one_char_too_long_is_invalid(self):
        result = License("HF-PRO-" + "x" * 26).validate()  # 33 chars total
        assert result.tier == "free"
        assert result.valid is False

    def test_key_one_char_too_short_is_invalid(self):
        result = License("HF-PRO-" + "x" * 24).validate()  # 31 chars total
        assert result.tier == "free"
        assert result.valid is False


# ---------------------------------------------------------------------------
# License.is_pro()
# ---------------------------------------------------------------------------

class TestLicenseIsPro:
    def test_is_pro_true_for_valid_key(self):
        assert License(_VALID_PRO_KEY).is_pro() is True

    def test_is_pro_false_for_no_key(self):
        assert License(None).is_pro() is False

    def test_is_pro_false_for_invalid_key(self):
        assert License("bad-key").is_pro() is False


# ---------------------------------------------------------------------------
# load_license_key()
# ---------------------------------------------------------------------------

class TestLoadLicenseKey:
    def test_returns_none_when_no_config(self, tmp_path: Path, monkeypatch):
        monkeypatch.setattr("hiveframe.license._HOME_CONFIG", tmp_path / "config.yaml")
        assert load_license_key() is None

    def test_returns_none_when_key_absent_from_config(self, tmp_path: Path, monkeypatch):
        cfg = tmp_path / "config.yaml"
        cfg.write_text(yaml.safe_dump({"nodes": []}), encoding="utf-8")
        monkeypatch.setattr("hiveframe.license._HOME_CONFIG", cfg)
        assert load_license_key() is None

    def test_returns_key_when_present(self, tmp_path: Path, monkeypatch):
        cfg = tmp_path / "config.yaml"
        cfg.write_text(yaml.safe_dump({"license_key": _VALID_PRO_KEY}), encoding="utf-8")
        monkeypatch.setattr("hiveframe.license._HOME_CONFIG", cfg)
        assert load_license_key() == _VALID_PRO_KEY


# ---------------------------------------------------------------------------
# write_license_key()
# ---------------------------------------------------------------------------

class TestWriteLicenseKey:
    def test_creates_config_when_absent(self, tmp_path: Path, monkeypatch):
        cfg = tmp_path / "config.yaml"
        monkeypatch.setattr("hiveframe.license._HOME_CONFIG", cfg)
        write_license_key(_VALID_PRO_KEY)
        data = yaml.safe_load(cfg.read_text())
        assert data["license_key"] == _VALID_PRO_KEY

    def test_preserves_existing_settings(self, tmp_path: Path, monkeypatch):
        cfg = tmp_path / "config.yaml"
        cfg.write_text(
            yaml.safe_dump({"nodes": [{"name": "pve"}]}), encoding="utf-8"
        )
        monkeypatch.setattr("hiveframe.license._HOME_CONFIG", cfg)
        write_license_key(_VALID_PRO_KEY)
        data = yaml.safe_load(cfg.read_text())
        assert data["license_key"] == _VALID_PRO_KEY
        assert "nodes" in data

    def test_overwrites_existing_key(self, tmp_path: Path, monkeypatch):
        cfg = tmp_path / "config.yaml"
        cfg.write_text(yaml.safe_dump({"license_key": "old-key"}), encoding="utf-8")
        monkeypatch.setattr("hiveframe.license._HOME_CONFIG", cfg)
        write_license_key(_VALID_PRO_KEY)
        data = yaml.safe_load(cfg.read_text())
        assert data["license_key"] == _VALID_PRO_KEY

    def test_creates_parent_dirs(self, tmp_path: Path, monkeypatch):
        cfg = tmp_path / "nested" / "dir" / "config.yaml"
        monkeypatch.setattr("hiveframe.license._HOME_CONFIG", cfg)
        write_license_key(_VALID_PRO_KEY)
        assert cfg.exists()


# ---------------------------------------------------------------------------
# require_pro()
# ---------------------------------------------------------------------------

class TestRequirePro:
    def test_exits_1_on_free_tier(self, monkeypatch):
        monkeypatch.setattr("hiveframe.license.load_license_key", lambda: None)
        with pytest.raises(SystemExit) as exc:
            require_pro("Stack cloning")
        assert exc.value.code == 1

    def test_exits_1_on_invalid_key(self, monkeypatch):
        monkeypatch.setattr("hiveframe.license.load_license_key", lambda: "bad-key")
        with pytest.raises(SystemExit) as exc:
            require_pro("Stack cloning")
        assert exc.value.code == 1

    def test_does_not_exit_on_pro_key(self, monkeypatch):
        monkeypatch.setattr("hiveframe.license.load_license_key", lambda: _VALID_PRO_KEY)
        require_pro("Stack cloning")  # must not raise

    def test_upsell_message_printed_on_free_tier(self, monkeypatch, capsys):
        monkeypatch.setattr("hiveframe.license.load_license_key", lambda: None)
        with pytest.raises(SystemExit):
            require_pro("Stack cloning")
        # Rich prints to stdout; check captured output contains key text
        # (capsys captures plain text stripped of Rich markup)
        from io import StringIO
        from rich.console import Console
        buf = StringIO()
        c = Console(file=buf, legacy_windows=False, highlight=False)
        from hiveframe.license import _PRO_UPSELL
        c.print(_PRO_UPSELL)
        assert "Hiveframe Pro" in buf.getvalue()
