"""Tests for StackCloner — all Proxmox API calls mocked."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock

import pytest
import yaml

from hiveframe.models import Stack
from hiveframe.provision.clone import RenameRow, StackCloner


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

STACK_DATA = {
    "name": "ccna-lab",
    "node": "pve",
    "vlans": [
        {"name": "mgmt", "vlan_id": 10, "cidr": "192.168.10.0/24", "gateway": "192.168.10.1"},
        {"name": "lab",  "vlan_id": 20, "cidr": "192.168.20.0/24", "gateway": "192.168.20.1"},
    ],
    "vms": [
        {
            "name": "router",
            "template_id": 9000,
            "vlan": "mgmt",
            "cores": 2,
            "memory_mb": 2048,
            "disk_gb": 20,
            "start_on_create": False,
            "cloud_init": {"user": "ubuntu", "ip_config": "dhcp"},
        },
        {
            "name": "workstation",
            "template_id": 9000,
            "vlan": "lab",
            "cores": 2,
            "memory_mb": 2048,
            "disk_gb": 20,
            "start_on_create": False,
            "cloud_init": {"user": "ubuntu", "ip_config": "dhcp"},
        },
    ],
}


@pytest.fixture()
def source() -> Stack:
    return Stack.model_validate(STACK_DATA)


def _make_registry(existing_ifaces: list[dict] | None = None) -> MagicMock:
    """Build a mock registry where get_network_config returns *existing_ifaces*."""
    client = MagicMock()
    client.get_network_config.return_value = existing_ifaces or []
    registry = MagicMock()
    registry.get_client.return_value = client
    return registry


# ---------------------------------------------------------------------------
# Renaming
# ---------------------------------------------------------------------------

class TestStackCloneRenaming:
    def test_renames_stack_name(self, source: Stack, tmp_path: Path):
        registry = _make_registry()
        cloner = StackCloner(source, registry)
        cloner.clone("student-01", tmp_path / "out.yaml")
        new = Stack.from_file(tmp_path / "out.yaml")
        assert new.name == "student-01"

    def test_renames_vlans_with_prefix(self, source: Stack, tmp_path: Path):
        registry = _make_registry()
        cloner = StackCloner(source, registry)
        cloner.clone("student-01", tmp_path / "out.yaml")
        new = Stack.from_file(tmp_path / "out.yaml")
        vlan_names = {v.name for v in new.vlans}
        assert "student-01-mgmt" in vlan_names
        assert "student-01-lab" in vlan_names

    def test_renames_vms_with_prefix(self, source: Stack, tmp_path: Path):
        registry = _make_registry()
        cloner = StackCloner(source, registry)
        cloner.clone("student-01", tmp_path / "out.yaml")
        new = Stack.from_file(tmp_path / "out.yaml")
        vm_names = {vm.name for vm in new.vms}
        assert "student-01-router" in vm_names
        assert "student-01-workstation" in vm_names

    def test_vm_vlan_refs_updated(self, source: Stack, tmp_path: Path):
        registry = _make_registry()
        cloner = StackCloner(source, registry)
        cloner.clone("student-01", tmp_path / "out.yaml")
        new = Stack.from_file(tmp_path / "out.yaml")
        router = next(vm for vm in new.vms if vm.name == "student-01-router")
        workstation = next(vm for vm in new.vms if vm.name == "student-01-workstation")
        assert router.vlan == "student-01-mgmt"
        assert workstation.vlan == "student-01-lab"

    def test_node_preserved(self, source: Stack, tmp_path: Path):
        registry = _make_registry()
        cloner = StackCloner(source, registry)
        cloner.clone("student-01", tmp_path / "out.yaml")
        new = Stack.from_file(tmp_path / "out.yaml")
        assert new.node == "pve"

    def test_vm_template_id_preserved(self, source: Stack, tmp_path: Path):
        registry = _make_registry()
        cloner = StackCloner(source, registry)
        cloner.clone("student-01", tmp_path / "out.yaml")
        new = Stack.from_file(tmp_path / "out.yaml")
        for vm in new.vms:
            assert vm.template_id == 9000


# ---------------------------------------------------------------------------
# VLAN ID offset / auto-detection
# ---------------------------------------------------------------------------

class TestVlanIdOffset:
    def test_increments_vlan_ids_with_auto_offset(self, source: Stack, tmp_path: Path):
        # No existing bridges → first free block is source+10 (= 20,30)
        # But vmbr20 might conflict with source vlan 20... let me check algorithm:
        # source_ids = [10, 20], min_step = 10
        # offset=10: new_ids={20,30} — 20 not in used={} → success
        registry = _make_registry([])
        cloner = StackCloner(source, registry)
        cloner.clone("student-01", tmp_path / "out.yaml")
        new = Stack.from_file(tmp_path / "out.yaml")
        new_ids = {v.vlan_id for v in new.vlans}
        assert new_ids == {20, 30}

    def test_skips_conflicts_with_existing_bridges(self, source: Stack, tmp_path: Path):
        # Existing bridges include vmbr20 and vmbr30 (conflicts with offset=10 and offset=20)
        # offset=10: new_ids={20,30}, 20 in used → fail
        # offset=20: new_ids={30,40}, 30 in used → fail
        # offset=30: new_ids={40,50} → success
        existing = [
            {"iface": "vmbr10"},
            {"iface": "vmbr20"},
            {"iface": "vmbr30"},
        ]
        registry = _make_registry(existing)
        cloner = StackCloner(source, registry)
        cloner.clone("student-01", tmp_path / "out.yaml")
        new = Stack.from_file(tmp_path / "out.yaml")
        new_ids = {v.vlan_id for v in new.vlans}
        assert new_ids == {40, 50}

    def test_manual_vlan_offset_used_directly(self, source: Stack, tmp_path: Path):
        registry = _make_registry()
        cloner = StackCloner(source, registry)
        cloner.clone("student-01", tmp_path / "out.yaml", vlan_offset=100)
        new = Stack.from_file(tmp_path / "out.yaml")
        new_ids = {v.vlan_id for v in new.vlans}
        assert new_ids == {110, 120}

    def test_manual_offset_skips_live_check(self, source: Stack, tmp_path: Path):
        registry = _make_registry()
        cloner = StackCloner(source, registry)
        cloner.clone("student-01", tmp_path / "out.yaml", vlan_offset=50)
        # get_network_config should not have been called
        registry.get_client.return_value.get_network_config.assert_not_called()

    def test_no_vlans_uses_zero_offset(self, tmp_path: Path):
        stack = Stack.model_validate({
            "name": "empty",
            "node": "pve",
            "vlans": [],
            "vms": [],
        })
        registry = _make_registry()
        cloner = StackCloner(stack, registry)
        cloner.clone("empty-clone", tmp_path / "out.yaml")
        new = Stack.from_file(tmp_path / "out.yaml")
        assert new.vlans == []


# ---------------------------------------------------------------------------
# Output file
# ---------------------------------------------------------------------------

class TestOutputFile:
    def test_output_written_to_specified_path(self, source: Stack, tmp_path: Path):
        out = tmp_path / "student-01.yaml"
        registry = _make_registry()
        StackCloner(source, registry).clone("student-01", out)
        assert out.exists()

    def test_output_is_valid_stack(self, source: Stack, tmp_path: Path):
        out = tmp_path / "student-01.yaml"
        registry = _make_registry()
        StackCloner(source, registry).clone("student-01", out)
        # Stack.from_file runs all validators — if it passes, the file is valid
        new = Stack.from_file(out)
        assert new.name == "student-01"

    def test_output_passes_vlan_ref_validation(self, source: Stack, tmp_path: Path):
        out = tmp_path / "student-01.yaml"
        registry = _make_registry()
        StackCloner(source, registry).clone("student-01", out)
        new = Stack.from_file(out)
        # All VM vlan refs must exist in the vlans list
        vlan_names = {v.name for v in new.vlans}
        for vm in new.vms:
            assert vm.vlan in vlan_names


# ---------------------------------------------------------------------------
# RenameRow output
# ---------------------------------------------------------------------------

class TestRenameRows:
    def test_first_row_is_stack(self, source: Stack, tmp_path: Path):
        registry = _make_registry()
        rows = StackCloner(source, registry).clone("student-01", tmp_path / "out.yaml")
        assert rows[0].kind == "Stack"
        assert rows[0].original == "ccna-lab"
        assert rows[0].cloned == "student-01"

    def test_vlan_rows_present(self, source: Stack, tmp_path: Path):
        registry = _make_registry()
        rows = StackCloner(source, registry).clone("student-01", tmp_path / "out.yaml")
        vlan_rows = [r for r in rows if r.kind == "VLAN"]
        assert len(vlan_rows) == 2

    def test_vm_rows_present(self, source: Stack, tmp_path: Path):
        registry = _make_registry()
        rows = StackCloner(source, registry).clone("student-01", tmp_path / "out.yaml")
        vm_rows = [r for r in rows if r.kind == "VM"]
        assert len(vm_rows) == 2

    def test_vlan_row_includes_ids(self, source: Stack, tmp_path: Path):
        registry = _make_registry()
        rows = StackCloner(source, registry).clone("student-01", tmp_path / "out.yaml")
        vlan_rows = [r for r in rows if r.kind == "VLAN"]
        originals = {r.original for r in vlan_rows}
        assert "mgmt (10)" in originals
        assert "lab (20)" in originals


# ---------------------------------------------------------------------------
# Pro gate (CLI level)
# ---------------------------------------------------------------------------

class TestProGate:
    def test_stack_clone_blocked_for_free_tier(self, tmp_path: Path, monkeypatch):
        from click.testing import CliRunner
        from hiveframe.cli.main import cli

        monkeypatch.setattr("hiveframe.license.load_license_key", lambda: None)

        # Write a minimal source stack so the command can parse --from
        src = tmp_path / "source.yaml"
        src.write_text(
            "name: ccna-lab\nnode: pve\nvlans: []\nvms: []\n", encoding="utf-8"
        )

        runner = CliRunner()
        result = runner.invoke(
            cli,
            ["stack", "clone", "--from", str(src), "--name", "student-01",
             "--output", str(tmp_path / "out.yaml")],
        )
        assert result.exit_code == 1
        assert "Hiveframe Pro" in result.output
