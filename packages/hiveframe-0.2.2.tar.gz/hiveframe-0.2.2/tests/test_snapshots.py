"""Tests for SnapshotEngine — all API calls mocked."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock, call

import pytest

from hiveframe.models import Stack
from hiveframe.provision.snapshot import SnapshotEngine, SnapshotResult
from hiveframe.provision.state import StackState, VmState, save_state


# ---------------------------------------------------------------------------
# Shared fixtures
# ---------------------------------------------------------------------------

STACK_DATA = {
    "name": "test-stack",
    "node": "pve",
    "vlans": [
        {"name": "mgmt", "vlan_id": 10, "cidr": "192.168.10.0/24", "gateway": "192.168.10.1"},
    ],
    "vms": [
        {
            "name": "vm-01",
            "template_id": 9000,
            "vlan": "mgmt",
            "cores": 2,
            "memory_mb": 2048,
            "disk_gb": 20,
            "start_on_create": False,
            "cloud_init": {"user": "ubuntu", "ip_config": "dhcp"},
        },
        {
            "name": "vm-02",
            "template_id": 9000,
            "vlan": "mgmt",
            "cores": 2,
            "memory_mb": 2048,
            "disk_gb": 20,
            "start_on_create": False,
            "cloud_init": {"user": "ubuntu", "ip_config": "dhcp"},
        },
    ],
}


@pytest.fixture()
def stack() -> Stack:
    return Stack.model_validate(STACK_DATA)


@pytest.fixture()
def mock_client() -> MagicMock:
    client = MagicMock()
    client.create_vm_snapshot.return_value = "UPID:pve:000:snap-task"
    client.restore_vm_snapshot.return_value = "UPID:pve:000:rollback-task"
    client.delete_vm_snapshot.return_value = "UPID:pve:000:del-task"
    client.stop_vm.return_value = "UPID:pve:000:stop-task"
    client.start_vm.return_value = "UPID:pve:000:start-task"
    client.wait_for_task.return_value = None
    client.get_vm_status.return_value = "stopped"
    client.list_vm_snapshots.return_value = [
        {"name": "current", "snaptime": 0},
        {"name": "clean-state", "snaptime": 1745366100},
    ]
    return client


@pytest.fixture()
def mock_registry(mock_client: MagicMock) -> MagicMock:
    registry = MagicMock()
    registry.get_client.return_value = mock_client
    return registry


def _seed_state(stack_yaml: Path, vm_states: list[dict] | None = None) -> None:
    """Write a minimal state file with the given VMs (or the default two)."""
    if vm_states is None:
        vm_states = [
            {"name": "vm-01", "vmid": 101, "vlan": "mgmt", "status": "applied", "node": "pve"},
            {"name": "vm-02", "vmid": 102, "vlan": "mgmt", "status": "applied", "node": "pve"},
        ]
    state = StackState(
        stack_name="test-stack",
        vms=[VmState(**v) for v in vm_states],
    )
    save_state(stack_yaml, state)


def _make_engine(stack: Stack, registry: MagicMock, stack_yaml: Path) -> SnapshotEngine:
    return SnapshotEngine(stack, registry, stack_yaml)


# ---------------------------------------------------------------------------
# create()
# ---------------------------------------------------------------------------

class TestSnapshotCreate:
    def test_calls_create_for_each_vm_in_state(
        self, stack: Stack, mock_client: MagicMock, mock_registry: MagicMock, tmp_path: Path
    ):
        stack_yaml = tmp_path / "stack.yaml"
        _seed_state(stack_yaml)
        engine = _make_engine(stack, mock_registry, stack_yaml)

        results = engine.create("clean-state")

        assert mock_client.create_vm_snapshot.call_count == 2
        mock_client.create_vm_snapshot.assert_any_call("pve", 101, "clean-state", "")
        mock_client.create_vm_snapshot.assert_any_call("pve", 102, "clean-state", "")
        assert all(r.action == "CREATED" for r in results)

    def test_passes_description(
        self, stack: Stack, mock_client: MagicMock, mock_registry: MagicMock, tmp_path: Path
    ):
        stack_yaml = tmp_path / "stack.yaml"
        _seed_state(stack_yaml)
        engine = _make_engine(stack, mock_registry, stack_yaml)

        engine.create("snap-v1", description="before patch")

        mock_client.create_vm_snapshot.assert_any_call("pve", 101, "snap-v1", "before patch")

    def test_skips_vm_not_in_state(
        self, stack: Stack, mock_client: MagicMock, mock_registry: MagicMock, tmp_path: Path
    ):
        stack_yaml = tmp_path / "stack.yaml"
        # Only vm-01 in state; vm-02 is absent
        _seed_state(stack_yaml, [
            {"name": "vm-01", "vmid": 101, "vlan": "mgmt", "status": "applied", "node": "pve"},
        ])
        engine = _make_engine(stack, mock_registry, stack_yaml)

        results = engine.create("snap-x")

        assert mock_client.create_vm_snapshot.call_count == 1
        skipped = [r for r in results if r.action == "SKIPPED"]
        assert len(skipped) == 1
        assert skipped[0].vm_name == "vm-02"

    def test_skips_vm_not_in_state_when_no_state_file(
        self, stack: Stack, mock_client: MagicMock, mock_registry: MagicMock, tmp_path: Path
    ):
        stack_yaml = tmp_path / "stack.yaml"
        engine = _make_engine(stack, mock_registry, stack_yaml)

        results = engine.create("snap-x")

        mock_client.create_vm_snapshot.assert_not_called()
        assert all(r.action == "SKIPPED" for r in results)

    def test_skips_template_vmid(
        self, stack: Stack, mock_client: MagicMock, mock_registry: MagicMock, tmp_path: Path
    ):
        stack_yaml = tmp_path / "stack.yaml"
        # vm-01 has vmid == template_id (9000) — should be skipped
        _seed_state(stack_yaml, [
            {"name": "vm-01", "vmid": 9000, "vlan": "mgmt", "status": "applied", "node": "pve"},
            {"name": "vm-02", "vmid": 102, "vlan": "mgmt", "status": "applied", "node": "pve"},
        ])
        engine = _make_engine(stack, mock_registry, stack_yaml)

        results = engine.create("snap-t")

        skipped = [r for r in results if r.vm_name == "vm-01"]
        assert skipped[0].action == "SKIPPED"
        created = [r for r in results if r.vm_name == "vm-02"]
        assert created[0].action == "CREATED"

    def test_waits_for_task_per_vm(
        self, stack: Stack, mock_client: MagicMock, mock_registry: MagicMock, tmp_path: Path
    ):
        stack_yaml = tmp_path / "stack.yaml"
        _seed_state(stack_yaml)
        engine = _make_engine(stack, mock_registry, stack_yaml)

        engine.create("snap-wait")

        assert mock_client.wait_for_task.call_count == 2

    def test_failed_result_on_api_error(
        self, stack: Stack, mock_client: MagicMock, mock_registry: MagicMock, tmp_path: Path
    ):
        from hiveframe.api.client import HiveframeAPIError
        mock_client.create_vm_snapshot.side_effect = HiveframeAPIError("disk full")
        stack_yaml = tmp_path / "stack.yaml"
        _seed_state(stack_yaml)
        engine = _make_engine(stack, mock_registry, stack_yaml)

        results = engine.create("snap-err")

        assert all(r.action == "FAILED" for r in results)
        assert "disk full" in results[0].detail

    def test_invalid_name_raises(
        self, stack: Stack, mock_registry: MagicMock, tmp_path: Path
    ):
        stack_yaml = tmp_path / "stack.yaml"
        engine = _make_engine(stack, mock_registry, stack_yaml)
        with pytest.raises(ValueError, match="Invalid snapshot name"):
            engine.create("bad name!")

    def test_name_too_long_raises(
        self, stack: Stack, mock_registry: MagicMock, tmp_path: Path
    ):
        stack_yaml = tmp_path / "stack.yaml"
        engine = _make_engine(stack, mock_registry, stack_yaml)
        with pytest.raises(ValueError, match="Invalid snapshot name"):
            engine.create("a" * 41)

    def test_snapshot_name_appended_to_state(
        self, stack: Stack, mock_client: MagicMock, mock_registry: MagicMock, tmp_path: Path
    ):
        from hiveframe.provision.state import load_state
        stack_yaml = tmp_path / "stack.yaml"
        _seed_state(stack_yaml)
        engine = _make_engine(stack, mock_registry, stack_yaml)

        engine.create("clean-state")

        state = load_state(stack_yaml)
        for vs in state.vms:
            assert "clean-state" in vs.snapshots

    def test_snapshot_not_duplicated_in_state(
        self, stack: Stack, mock_client: MagicMock, mock_registry: MagicMock, tmp_path: Path
    ):
        from hiveframe.provision.state import load_state
        stack_yaml = tmp_path / "stack.yaml"
        _seed_state(stack_yaml)
        engine = _make_engine(stack, mock_registry, stack_yaml)

        engine.create("clean-state")
        engine.create("clean-state")

        state = load_state(stack_yaml)
        for vs in state.vms:
            assert vs.snapshots.count("clean-state") == 1


# ---------------------------------------------------------------------------
# list_snapshots()
# ---------------------------------------------------------------------------

class TestListSnapshots:
    def test_excludes_current_snapshot(
        self, stack: Stack, mock_client: MagicMock, mock_registry: MagicMock, tmp_path: Path
    ):
        stack_yaml = tmp_path / "stack.yaml"
        _seed_state(stack_yaml)
        engine = _make_engine(stack, mock_registry, stack_yaml)

        snap_map = engine.list_snapshots()

        for vm_name, snaps in snap_map.items():
            names = [s["name"] for s in snaps]
            assert "current" not in names

    def test_returns_real_snapshots(
        self, stack: Stack, mock_client: MagicMock, mock_registry: MagicMock, tmp_path: Path
    ):
        stack_yaml = tmp_path / "stack.yaml"
        _seed_state(stack_yaml)
        engine = _make_engine(stack, mock_registry, stack_yaml)

        snap_map = engine.list_snapshots()

        for vm_name, snaps in snap_map.items():
            assert any(s["name"] == "clean-state" for s in snaps)

    def test_skips_vms_not_in_state(
        self, stack: Stack, mock_client: MagicMock, mock_registry: MagicMock, tmp_path: Path
    ):
        stack_yaml = tmp_path / "stack.yaml"
        # Only vm-01 in state
        _seed_state(stack_yaml, [
            {"name": "vm-01", "vmid": 101, "vlan": "mgmt", "status": "applied", "node": "pve"},
        ])
        engine = _make_engine(stack, mock_registry, stack_yaml)

        snap_map = engine.list_snapshots()

        assert "vm-02" not in snap_map
        assert "vm-01" in snap_map

    def test_returns_empty_when_no_state(
        self, stack: Stack, mock_client: MagicMock, mock_registry: MagicMock, tmp_path: Path
    ):
        stack_yaml = tmp_path / "stack.yaml"
        engine = _make_engine(stack, mock_registry, stack_yaml)

        snap_map = engine.list_snapshots()

        assert snap_map == {}


# ---------------------------------------------------------------------------
# restore()
# ---------------------------------------------------------------------------

class TestSnapshotRestore:
    def test_calls_restore_for_each_vm(
        self, stack: Stack, mock_client: MagicMock, mock_registry: MagicMock, tmp_path: Path
    ):
        stack_yaml = tmp_path / "stack.yaml"
        _seed_state(stack_yaml)
        engine = _make_engine(stack, mock_registry, stack_yaml)

        results = engine.restore("clean-state")

        assert mock_client.restore_vm_snapshot.call_count == 2
        mock_client.restore_vm_snapshot.assert_any_call("pve", 101, "clean-state")
        mock_client.restore_vm_snapshot.assert_any_call("pve", 102, "clean-state")
        assert all(r.action == "RESTORED" for r in results)

    def test_skips_vm_not_in_state(
        self, stack: Stack, mock_client: MagicMock, mock_registry: MagicMock, tmp_path: Path
    ):
        stack_yaml = tmp_path / "stack.yaml"
        engine = _make_engine(stack, mock_registry, stack_yaml)

        results = engine.restore("clean-state")

        mock_client.restore_vm_snapshot.assert_not_called()
        assert all(r.action == "SKIPPED" for r in results)

    def test_stops_running_vm_before_restore(
        self, stack: Stack, mock_client: MagicMock, mock_registry: MagicMock, tmp_path: Path
    ):
        mock_client.get_vm_status.return_value = "running"
        stack_yaml = tmp_path / "stack.yaml"
        _seed_state(stack_yaml)
        engine = _make_engine(stack, mock_registry, stack_yaml)

        engine.restore("clean-state")

        assert mock_client.stop_vm.call_count == 2

    def test_restarts_vm_after_restore_if_was_running(
        self, stack: Stack, mock_client: MagicMock, mock_registry: MagicMock, tmp_path: Path
    ):
        mock_client.get_vm_status.return_value = "running"
        stack_yaml = tmp_path / "stack.yaml"
        _seed_state(stack_yaml)
        engine = _make_engine(stack, mock_registry, stack_yaml)

        engine.restore("clean-state")

        assert mock_client.start_vm.call_count == 2

    def test_does_not_stop_or_start_if_already_stopped(
        self, stack: Stack, mock_client: MagicMock, mock_registry: MagicMock, tmp_path: Path
    ):
        mock_client.get_vm_status.return_value = "stopped"
        stack_yaml = tmp_path / "stack.yaml"
        _seed_state(stack_yaml)
        engine = _make_engine(stack, mock_registry, stack_yaml)

        engine.restore("clean-state")

        mock_client.stop_vm.assert_not_called()
        mock_client.start_vm.assert_not_called()

    def test_failed_result_on_api_error(
        self, stack: Stack, mock_client: MagicMock, mock_registry: MagicMock, tmp_path: Path
    ):
        from hiveframe.api.client import HiveframeAPIError
        mock_client.restore_vm_snapshot.side_effect = HiveframeAPIError("snap not found")
        stack_yaml = tmp_path / "stack.yaml"
        _seed_state(stack_yaml)
        engine = _make_engine(stack, mock_registry, stack_yaml)

        results = engine.restore("clean-state")

        assert all(r.action == "FAILED" for r in results)

    def test_waits_for_task_after_restore(
        self, stack: Stack, mock_client: MagicMock, mock_registry: MagicMock, tmp_path: Path
    ):
        stack_yaml = tmp_path / "stack.yaml"
        _seed_state(stack_yaml)
        engine = _make_engine(stack, mock_registry, stack_yaml)

        engine.restore("clean-state")

        # wait_for_task called once per VM for restore task
        restore_upid = "UPID:pve:000:rollback-task"
        calls = mock_client.wait_for_task.call_args_list
        restore_calls = [c for c in calls if c.args[1] == restore_upid]
        assert len(restore_calls) == 2


# ---------------------------------------------------------------------------
# delete()
# ---------------------------------------------------------------------------

class TestSnapshotDelete:
    def test_calls_delete_when_snapshot_exists(
        self, stack: Stack, mock_client: MagicMock, mock_registry: MagicMock, tmp_path: Path
    ):
        stack_yaml = tmp_path / "stack.yaml"
        _seed_state(stack_yaml)
        engine = _make_engine(stack, mock_registry, stack_yaml)

        results = engine.delete("clean-state")

        assert mock_client.delete_vm_snapshot.call_count == 2
        assert all(r.action == "DELETED" for r in results)

    def test_skips_if_snapshot_not_on_vm(
        self, stack: Stack, mock_client: MagicMock, mock_registry: MagicMock, tmp_path: Path
    ):
        mock_client.list_vm_snapshots.return_value = [{"name": "current", "snaptime": 0}]
        stack_yaml = tmp_path / "stack.yaml"
        _seed_state(stack_yaml)
        engine = _make_engine(stack, mock_registry, stack_yaml)

        results = engine.delete("clean-state")

        mock_client.delete_vm_snapshot.assert_not_called()
        assert all(r.action == "SKIPPED" for r in results)

    def test_skips_vm_not_in_state(
        self, stack: Stack, mock_client: MagicMock, mock_registry: MagicMock, tmp_path: Path
    ):
        stack_yaml = tmp_path / "stack.yaml"
        engine = _make_engine(stack, mock_registry, stack_yaml)

        results = engine.delete("clean-state")

        mock_client.delete_vm_snapshot.assert_not_called()
        assert all(r.action == "SKIPPED" for r in results)

    def test_waits_for_task_after_delete(
        self, stack: Stack, mock_client: MagicMock, mock_registry: MagicMock, tmp_path: Path
    ):
        stack_yaml = tmp_path / "stack.yaml"
        _seed_state(stack_yaml)
        engine = _make_engine(stack, mock_registry, stack_yaml)

        engine.delete("clean-state")

        assert mock_client.wait_for_task.call_count == 2

    def test_snapshot_removed_from_state_after_delete(
        self, stack: Stack, mock_client: MagicMock, mock_registry: MagicMock, tmp_path: Path
    ):
        from hiveframe.provision.state import load_state
        stack_yaml = tmp_path / "stack.yaml"
        # Seed state with snapshot already tracked
        state = StackState(
            stack_name="test-stack",
            vms=[
                VmState(name="vm-01", vmid=101, vlan="mgmt", status="applied",
                        node="pve", snapshots=["clean-state"]),
                VmState(name="vm-02", vmid=102, vlan="mgmt", status="applied",
                        node="pve", snapshots=["clean-state"]),
            ],
        )
        save_state(stack_yaml, state)
        engine = _make_engine(stack, mock_registry, stack_yaml)

        engine.delete("clean-state")

        updated = load_state(stack_yaml)
        for vs in updated.vms:
            assert "clean-state" not in vs.snapshots

    def test_other_snapshots_preserved_after_delete(
        self, stack: Stack, mock_client: MagicMock, mock_registry: MagicMock, tmp_path: Path
    ):
        from hiveframe.provision.state import load_state
        mock_client.list_vm_snapshots.return_value = [
            {"name": "current", "snaptime": 0},
            {"name": "clean-state", "snaptime": 1745366100},
            {"name": "another-snap", "snaptime": 1745366200},
        ]
        stack_yaml = tmp_path / "stack.yaml"
        state = StackState(
            stack_name="test-stack",
            vms=[
                VmState(name="vm-01", vmid=101, vlan="mgmt", status="applied",
                        node="pve", snapshots=["clean-state", "another-snap"]),
                VmState(name="vm-02", vmid=102, vlan="mgmt", status="applied",
                        node="pve", snapshots=["clean-state", "another-snap"]),
            ],
        )
        save_state(stack_yaml, state)
        engine = _make_engine(stack, mock_registry, stack_yaml)

        engine.delete("clean-state")

        updated = load_state(stack_yaml)
        for vs in updated.vms:
            assert "clean-state" not in vs.snapshots
            assert "another-snap" in vs.snapshots


# ---------------------------------------------------------------------------
# SnapshotResult fields
# ---------------------------------------------------------------------------

class TestSnapshotResultFields:
    def test_created_result_fields(
        self, stack: Stack, mock_client: MagicMock, mock_registry: MagicMock, tmp_path: Path
    ):
        stack_yaml = tmp_path / "stack.yaml"
        _seed_state(stack_yaml, [
            {"name": "vm-01", "vmid": 101, "vlan": "mgmt", "status": "applied", "node": "pve"},
        ])
        engine = _make_engine(stack, mock_registry, stack_yaml)

        results = engine.create("snap-a")
        created = next(r for r in results if r.action == "CREATED")

        assert created.vm_name == "vm-01"
        assert created.vmid == 101
        assert created.snapshot_name == "snap-a"
        assert created.detail is None

    def test_skipped_result_fields(
        self, stack: Stack, mock_client: MagicMock, mock_registry: MagicMock, tmp_path: Path
    ):
        stack_yaml = tmp_path / "stack.yaml"
        engine = _make_engine(stack, mock_registry, stack_yaml)

        results = engine.create("snap-b")
        skipped = results[0]

        assert skipped.action == "SKIPPED"
        assert skipped.vmid == 0
        assert skipped.detail is not None

    def test_restored_result_fields(
        self, stack: Stack, mock_client: MagicMock, mock_registry: MagicMock, tmp_path: Path
    ):
        stack_yaml = tmp_path / "stack.yaml"
        _seed_state(stack_yaml, [
            {"name": "vm-01", "vmid": 101, "vlan": "mgmt", "status": "applied", "node": "pve"},
        ])
        engine = _make_engine(stack, mock_registry, stack_yaml)

        results = engine.restore("clean-state")
        restored = next(r for r in results if r.action == "RESTORED")

        assert restored.vm_name == "vm-01"
        assert restored.vmid == 101
        assert restored.snapshot_name == "clean-state"

    def test_deleted_result_fields(
        self, stack: Stack, mock_client: MagicMock, mock_registry: MagicMock, tmp_path: Path
    ):
        stack_yaml = tmp_path / "stack.yaml"
        _seed_state(stack_yaml, [
            {"name": "vm-01", "vmid": 101, "vlan": "mgmt", "status": "applied", "node": "pve"},
        ])
        engine = _make_engine(stack, mock_registry, stack_yaml)

        results = engine.delete("clean-state")
        deleted = next(r for r in results if r.action == "DELETED")

        assert deleted.vm_name == "vm-01"
        assert deleted.vmid == 101
        assert deleted.snapshot_name == "clean-state"
