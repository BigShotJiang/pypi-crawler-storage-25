# ersan — your office. your rules. your AI. ...and you, amplified.
# Copyright 2026 Ersan Bilik
# SPDX-License-Identifier: Apache-2.0
"""Skill loader for ersan.core (US-002).

This module is the spine of the skills/plugins architecture D-005
declared. It is **stdlib-only by design** — the privacy invariant
(D-008, Constitution §I) forbids any outbound network surface from the
loader, and a dedicated guard test
(`tests/unit/test_skill_loader_no_network_imports.py`) enforces this
in CI by asserting that no HTTP-client OR LLM-client import substring
appears in this file's source. See that test for the exact forbidden
list. LLM calls and external service calls belong in **skills**, not
in the loader.

Architecture, in one paragraph: a **skill** is a Python module under
`ersan/skills/<plugin>/<skill_name>.py` exposing a top-level `MANIFEST`
dict and a top-level `handler` callable; a **plugin** is the parent
directory bundling related skills under a shared namespace. The loader
walks the plugins root, validates each module via
`importlib.util.spec_from_file_location` (no `sys.path` mutation), and
returns a mapping `{"<plugin>.<skill_name>" -> Skill}` of frozen
dataclasses. Every invocation through `invoke()` runs `policy_check`
BEFORE the handler (Constitution §III, NON-NEGOTIABLE) and
`shield_redact` AFTER on string output. When callers do not supply
overrides, the defaults are lazy first-party adapters around
`ersan.policy.PolicyEngine.evaluate()` and `ersan.shield.ContentShield.scan()`.
The lazy-import pattern is intentional: it keeps discovery/import time
stdlib-only while still enforcing the real gates at invocation time.

Validation order (Decision R-002 in plan.md). First failure short-
circuits and raises:

    1. plugin-dir name char class -> SkillPluginMismatchError
    2. module load (importlib exec) -> SkillManifestError (chained)
    3. MANIFEST symbol present     -> SkillManifestError
    4. MANIFEST is dict            -> SkillManifestError
    5. required keys present       -> SkillManifestError
    6. per-key value validation    -> SkillManifestError
    7. plugin-field matches dir    -> SkillPluginMismatchError
    8. handler present + callable  -> SkillHandlerError
    9. duplicate name within plugin -> SkillManifestError

See `.specify/specs/002-skill-loader/{spec,plan}.md` for the canonical
specification and design notes, and `docs/skills.md` for the
contributor guide.
"""

from __future__ import annotations

import importlib.util
import re
import sys
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Literal, cast

# ---------------------------------------------------------------------------
# Module-level constants.
# ---------------------------------------------------------------------------

_VALID_NAME = re.compile(r"^[a-zA-Z_][a-zA-Z0-9_]*$")
"""Python-identifier-like character class for plugin and skill names.

Restricting to this class keeps the dotted-lookup key
(``<plugin>.<skill_name>``) unambiguous: a name with a dot in it would
collide with the plugin/skill separator, and a name starting with a
digit would conflict with the loader's `_LOADER_PREFIX` namespace.
"""

_TRUST_TIERS: frozenset[str] = frozenset({"ask_first", "do_and_tell", "do_it"})
"""The three trust tiers from Constitution §III.

``ask_first`` (highest gate, e.g. send-email), ``do_and_tell`` (informs
after, e.g. read-and-summarize), ``do_it`` (silent execution, e.g.
read-list).
"""

_DESCRIPTION_MAX_LEN: int = 200
"""Per-skill ``MANIFEST['description']`` cap (FR-A2)."""

_MANIFEST_REQUIRED_KEYS: tuple[str, ...] = ("name", "description", "trust_tier", "plugin")
"""Keys every ``MANIFEST`` dict MUST carry."""

_LOADER_PREFIX: str = "ersan._loader_skills."
"""Underscore-prefixed sys.modules namespace for loader-loaded modules.

Decision R-010: prevents collisions with the production
``ersan.skills.<plugin>.<skill_name>`` namespace when the loader runs
against `tmp_path` fake plugins while the production package is also
importable.
"""

TrustTier = Literal["ask_first", "do_and_tell", "do_it"]
"""Type alias re-stating the trust-tier enum at the type-system layer."""


# ---------------------------------------------------------------------------
# Public dataclass.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class Skill:
    """One discovered skill — frozen, hashable, equality-comparable.

    Attributes:
        name: The skill's name within its plugin namespace; matches
            ``[a-zA-Z_][a-zA-Z0-9_]*``.
        description: One-line description (≤200 characters per FR-A2).
        trust_tier: One of ``ask_first`` / ``do_and_tell`` / ``do_it``.
        plugin: The parent plugin's name; equals the plugin directory
            name and matches ``[a-zA-Z_][a-zA-Z0-9_]*``.
        handler: The callable the loader invokes through
            :func:`invoke` after the policy gate clears.
        module_path: Filesystem path to the skill module (resolved via
            ``pathlib.Path``; useful for diagnostics).
    """

    name: str
    description: str
    trust_tier: TrustTier
    plugin: str
    handler: Callable[..., Any]
    module_path: Path

    @property
    def fully_qualified_name(self) -> str:
        """Return ``"<plugin>.<name>"`` — the canonical user-facing id."""
        return f"{self.plugin}.{self.name}"


# ---------------------------------------------------------------------------
# Typed exceptions (Decision R-003).
# ---------------------------------------------------------------------------


class SkillLoaderError(Exception):
    """Base class for every loader-raised exception.

    Catch this to handle any loader failure family-uniformly; catch the
    subclasses to distinguish specific validation steps.
    """


class SkillManifestError(SkillLoaderError):
    """The skill module's ``MANIFEST`` is missing, malformed, or invalid.

    Also raised on module-load failure during discovery (with the
    underlying ``ImportError`` chained via ``raise ... from ...``) and
    on duplicate-skill-name within a plugin.
    """


class SkillHandlerError(SkillLoaderError):
    """The skill module's ``handler`` symbol is missing or not callable."""


class SkillPluginMismatchError(SkillLoaderError):
    """``MANIFEST['plugin']`` mismatches the parent dir, OR the dir name fails char class."""


class SkillPolicyDeniedError(SkillLoaderError):
    """:func:`invoke`'s ``policy_check`` returned ``False`` — handler NOT invoked."""


# ---------------------------------------------------------------------------
# Default gate/filter adapters.
#
# The first-party policy/shield imports are intentionally lazy inside these
# helper functions. `tests/unit/test_skill_loader_no_network_imports.py`
# guards against HTTP/LLM client imports in this module; keeping the real
# gates behind function-local imports preserves the loader's stdlib-only
# module-import surface while still enforcing policy/shield at invoke time.
# ---------------------------------------------------------------------------


_DEFAULT_ENGINE: Any | None = None
_DEFAULT_SHIELD: Any | None = None


def _get_default_engine() -> Any:
    """Return the lazy singleton `PolicyEngine` for default policy checks."""
    global _DEFAULT_ENGINE
    if _DEFAULT_ENGINE is None:
        from ersan.policy import JSONLinesAuditLogger, PolicyEngine, load_default_policy

        _DEFAULT_ENGINE = PolicyEngine(
            load_default_policy(),
            audit_logger=JSONLinesAuditLogger(Path.home() / ".ersan" / "audit.log"),
        )
    return _DEFAULT_ENGINE


def _get_default_shield() -> Any:
    """Return the lazy singleton `ContentShield` for default redaction."""
    global _DEFAULT_SHIELD
    if _DEFAULT_SHIELD is None:
        from ersan.shield import ContentShield

        _DEFAULT_SHIELD = ContentShield()
    return _DEFAULT_SHIELD


def _default_policy_check(skill: Skill) -> bool:
    """Wrap `PolicyEngine.evaluate()` into the loader's `Skill -> bool` hook.

    ALLOW and ALLOW_NOTIFY map to `True`. CONFIRM, LOG_ONLY, and DENY map
    to `False`, which keeps the loader's public `Callable[[Skill], bool]`
    override surface intact while defaulting retail `ask_first` skills to
    conservative denial until the user opts in via `~/.ersan/policy.yaml`.
    """
    from ersan.policy import Action

    engine = _get_default_engine()
    decision = engine.evaluate(tool=skill.fully_qualified_name)
    return decision.action in (Action.ALLOW, Action.ALLOW_NOTIFY)


def _default_shield_redact(value: str) -> str:
    """Wrap `ContentShield.scan()` into the loader's `str -> str` hook.

    Returns the redacted value when the shield produced one, otherwise
    returns the original string unchanged. BLOCK findings raise
    `ShieldBlocked` per the source shield semantics.
    """
    from ersan.shield import ScanAction, ShieldBlocked

    shield = _get_default_shield()
    result = shield.scan(value)
    if any(finding.action is ScanAction.BLOCK for finding in result.findings):
        raise ShieldBlocked(result)
    redacted = cast(str | None, result.redacted)
    if redacted is not None:
        return redacted
    return value


# ---------------------------------------------------------------------------
# Validators.
# ---------------------------------------------------------------------------


def _validate_name(value: object, *, kind: str, file: Path) -> str:
    """Assert ``value`` is a non-empty str matching ``_VALID_NAME``.

    Args:
        value: The value to validate.
        kind: Diagnostic noun (e.g. ``"name"``, ``"plugin"``, ``"plugin directory"``).
        file: Source location to name in the error message.

    Returns:
        The validated string (so callers can use it as a typed value).

    Raises:
        SkillManifestError: If ``value`` is not a str matching the class.
    """
    if not isinstance(value, str) or not _VALID_NAME.match(value):
        raise SkillManifestError(f"{file}: {kind} {value!r} must match {_VALID_NAME.pattern}")
    return value


def _validate_manifest(
    manifest: object,
    *,
    file: Path,
    parent_dir_name: str,
) -> tuple[str, str, TrustTier, str]:
    """Run validation steps 3 through 7 from the module docstring.

    Returns the four validated manifest fields as a tuple
    ``(name, description, trust_tier, plugin)`` ready for ``Skill``
    construction.

    Raises:
        SkillManifestError: Steps 3, 4, 5, 6.
        SkillPluginMismatchError: Step 7.
    """
    if not isinstance(manifest, dict):
        raise SkillManifestError(f"{file}: MANIFEST must be a dict, got {type(manifest).__name__}")
    for key in _MANIFEST_REQUIRED_KEYS:
        if key not in manifest:
            raise SkillManifestError(f"{file}: MANIFEST missing required key {key!r}")
    name = _validate_name(manifest["name"], kind="MANIFEST['name']", file=file)
    description = manifest["description"]
    if not isinstance(description, str):
        raise SkillManifestError(
            f"{file}: MANIFEST['description'] must be str, got {type(description).__name__}"
        )
    if len(description) > _DESCRIPTION_MAX_LEN:
        raise SkillManifestError(
            f"{file}: MANIFEST['description'] is {len(description)} chars, "
            f"max is {_DESCRIPTION_MAX_LEN}"
        )
    trust_tier = manifest["trust_tier"]
    # Codex review 2026-04-18 (P2): a non-string trust_tier (e.g. list/dict)
    # is unhashable and would raise raw TypeError from the membership test
    # below, leaking an internal traceback in exactly the plugin-author-
    # debugging scenario this story is supposed to improve. Type-check first.
    if not isinstance(trust_tier, str):
        raise SkillManifestError(
            f"{file}: MANIFEST['trust_tier'] must be str, got {type(trust_tier).__name__}"
        )
    if trust_tier not in _TRUST_TIERS:
        raise SkillManifestError(
            f"{file}: MANIFEST['trust_tier']={trust_tier!r} must be one of {sorted(_TRUST_TIERS)}"
        )
    plugin = _validate_name(manifest["plugin"], kind="MANIFEST['plugin']", file=file)
    if plugin != parent_dir_name:
        raise SkillPluginMismatchError(
            f"{file}: MANIFEST['plugin']={plugin!r} does not match parent "
            f"directory name {parent_dir_name!r}"
        )
    # The membership check above narrows trust_tier at runtime to one of
    # the three Literal values; cast tells mypy the same thing.
    return name, description, cast(TrustTier, trust_tier), plugin


def _ensure_parent_packages(qualified_name: str, plugin_dir: Path) -> None:
    """Register parent package modules in ``sys.modules`` for relative imports.

    Codex review 2026-04-18 (P1): a skill that uses ``from ._helpers import X``
    triggers Python's relative-import machinery, which walks up
    ``__package__`` and looks the parent package up in ``sys.modules``. If
    only the leaf module is registered, the parent (e.g.
    ``ersan._loader_skills.<plugin>``) is missing and the import fails with
    ``No module named ...``. Pre-register every ancestor as a synthetic
    package module with ``__path__`` pointing at the right directory so
    relative imports inside skill modules resolve.

    Idempotent: re-registers the same package module if already present
    (the module object is reused so reimports do not duplicate state).

    Args:
        qualified_name: e.g. ``"ersan._loader_skills.inbox.list_unread"``.
        plugin_dir: Filesystem directory of the plugin (parent of all
            its skill modules and the ``_*.py`` helpers they may import).
    """
    import types

    parts = qualified_name.split(".")
    # Walk every ancestor except the leaf (which exec_module handles).
    for i in range(1, len(parts)):
        ancestor = ".".join(parts[:i])
        if ancestor in sys.modules:
            continue
        pkg = types.ModuleType(ancestor)
        # Only the immediate parent (length == len(parts) - 1) maps to a
        # real on-disk directory holding the skill files. Higher ancestors
        # are synthetic namespaces with empty __path__ — their only job is
        # to satisfy Python's parent-package resolution.
        if i == len(parts) - 1:
            pkg.__path__ = [str(plugin_dir)]
        else:
            pkg.__path__ = []
        sys.modules[ancestor] = pkg


def _load_module(qualified_name: str, path: Path) -> Any:
    """Load a skill module by filesystem path via ``importlib.util``.

    Registers the module in ``sys.modules`` under ``qualified_name``
    BEFORE executing it, so intra-skill ``from .helpers import ...``
    style imports resolve correctly (the leaf module is registered here;
    parent packages are registered by ``_ensure_parent_packages``,
    which the caller invokes first per Codex review 2026-04-18 P1 fix).

    **Idempotency** (Decision R-001 / FR-C4 / Codex review P2 fix): if
    the module is already in ``sys.modules`` AND its source path matches,
    the already-loaded module is returned **without** re-executing it.
    This preserves callable identity for the ``handler`` symbol across
    repeated discovery calls so ``Skill`` instances compare equal between
    scans (the spec's idempotency contract). A path mismatch — e.g. the
    plugin moved on disk — falls through to a fresh load.

    Args:
        qualified_name: ``_LOADER_PREFIX + plugin + "." + skill_name``.
        path: Path to the ``.py`` file to load.

    Returns:
        The loaded module object.

    Raises:
        SkillManifestError: If spec construction fails or the module
            raises during ``exec_module``. The original exception is
            chained.
    """
    cached = sys.modules.get(qualified_name)
    if cached is not None:
        cached_file = getattr(cached, "__file__", None)
        if cached_file is not None and Path(cached_file).resolve() == path.resolve():
            return cached
    spec = importlib.util.spec_from_file_location(qualified_name, path)
    if spec is None or spec.loader is None:
        raise SkillManifestError(f"{path}: importlib could not build a spec for the module")
    module = importlib.util.module_from_spec(spec)
    sys.modules[qualified_name] = module
    try:
        spec.loader.exec_module(module)
    except Exception as exc:
        sys.modules.pop(qualified_name, None)
        raise SkillManifestError(f"{path}: failed to load skill module: {exc}") from exc
    return module


# ---------------------------------------------------------------------------
# Discovery.
# ---------------------------------------------------------------------------


def discover_skills(plugins_dir: Path) -> dict[str, Skill]:
    """Walk ``plugins_dir`` and return ``{fully_qualified_name -> Skill}``.

    Args:
        plugins_dir: Directory containing one subdirectory per plugin.

    Returns:
        Mapping keyed by ``"<plugin>.<skill_name>"``. Empty dict if the
        directory exists but contains no plugin subdirectories or no
        skill modules. Insertion order is determined by sorted
        directory traversal (deterministic across runs / platforms).

    Raises:
        FileNotFoundError: If ``plugins_dir`` does not exist.
        SkillManifestError, SkillHandlerError, SkillPluginMismatchError:
            Per the validation order documented in the module docstring.
    """
    if not plugins_dir.exists() or not plugins_dir.is_dir():
        raise FileNotFoundError(f"plugins dir does not exist: {plugins_dir}")
    skills: dict[str, Skill] = {}
    for plugin_dir in sorted(p for p in plugins_dir.iterdir() if p.is_dir()):
        plugin_name = _validate_plugin_dir_name(plugin_dir)
        names_seen: dict[str, Path] = {}
        for module_path in sorted(plugin_dir.glob("*.py")):
            if module_path.name == "__init__.py" or module_path.name.startswith("_"):
                continue
            skill_stem = module_path.stem
            qualified_name = f"{_LOADER_PREFIX}{plugin_name}.{skill_stem}"
            _ensure_parent_packages(qualified_name, plugin_dir)
            module = _load_module(qualified_name, module_path)
            if not hasattr(module, "MANIFEST"):
                raise SkillManifestError(f"{module_path}: module is missing top-level `MANIFEST`")
            name, description, trust_tier, plugin = _validate_manifest(
                module.MANIFEST,
                file=module_path,
                parent_dir_name=plugin_name,
            )
            if not hasattr(module, "handler"):
                raise SkillHandlerError(f"{module_path}: module is missing top-level `handler`")
            handler = module.handler
            if not callable(handler):
                raise SkillHandlerError(
                    f"{module_path}: `handler` must be callable, got {type(handler).__name__}"
                )
            if name in names_seen:
                raise SkillManifestError(
                    f"duplicate skill name {name!r} in plugin {plugin!r}: "
                    f"{names_seen[name]} and {module_path}"
                )
            names_seen[name] = module_path
            skill = Skill(
                name=name,
                description=description,
                trust_tier=trust_tier,
                plugin=plugin,
                handler=handler,
                module_path=module_path,
            )
            skills[skill.fully_qualified_name] = skill
    return skills


def _validate_plugin_dir_name(plugin_dir: Path) -> str:
    """Step 1 of the validation order: plugin directory name char class."""
    plugin_name = plugin_dir.name
    if not _VALID_NAME.match(plugin_name):
        raise SkillPluginMismatchError(
            f"plugin directory name {plugin_name!r} (at {plugin_dir}) must match "
            f"{_VALID_NAME.pattern}"
        )
    return plugin_name


# ---------------------------------------------------------------------------
# Invocation.
# ---------------------------------------------------------------------------


def invoke(
    skill: Skill,
    *args: Any,
    policy_check: Callable[[Skill], bool] | None = None,
    shield_redact: Callable[[str], str] | None = None,
    **kwargs: Any,
) -> Any:
    """Run ``skill.handler`` wrapped in the policy gate and the shield filter.

    Order is fixed and NON-NEGOTIABLE (Constitution §III, FR-E2):

        1. ``policy_check(skill)`` runs FIRST.
        2. If it returns falsy, ``SkillPolicyDeniedError`` is raised
           and the handler is NEVER called.
        3. Otherwise ``skill.handler(*args, **kwargs)`` runs.
        4. If the handler returned a ``str``, ``shield_redact(value)``
           runs on the output and its return value is returned to the
           caller. Non-string outputs bypass the shield (it is a text
           filter, not a general output transform).

    Defaults (Decision R-004 / FR-E3, FR-E4):

        - ``policy_check=None`` -> internal ``_default_policy_check``
          (lazy `PolicyEngine.evaluate()` adapter).
        - ``shield_redact=None`` -> internal ``_default_shield_redact``
          (lazy `ContentShield.scan()` adapter).

    Handler exceptions and policy-check exceptions propagate verbatim
    (FR-E6) — the loader does not wrap them. A buggy skill is the
    skill author's bug to fix; a buggy policy is the policy author's
    bug to fix; neither should be silently re-typed.

    Args:
        skill: The skill to invoke.
        *args: Positional arguments forwarded to the handler verbatim.
        policy_check: Callable receiving the skill and returning
            ``True`` to allow or ``False`` to deny. Keyword-only.
        shield_redact: Callable that receives the handler's string
            output and returns the redacted string. Keyword-only.
        **kwargs: Keyword arguments forwarded to the handler verbatim.

    Returns:
        The handler's return value (passed through ``shield_redact``
        if it was a string).

    Raises:
        SkillPolicyDeniedError: ``policy_check`` returned falsy.
    """
    policy = policy_check if policy_check is not None else _default_policy_check
    shield = shield_redact if shield_redact is not None else _default_shield_redact
    if not policy(skill):
        raise SkillPolicyDeniedError(
            f"policy denied invocation of skill {skill.fully_qualified_name!r}"
        )
    result = skill.handler(*args, **kwargs)
    if isinstance(result, str):
        return shield(result)
    return result
