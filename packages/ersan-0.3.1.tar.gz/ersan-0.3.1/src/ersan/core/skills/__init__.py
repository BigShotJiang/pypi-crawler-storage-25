# ersan — your office. your rules. your AI. ...and you, amplified.
# Copyright 2026 Ersan Bilik
# SPDX-License-Identifier: Apache-2.0
"""Public skills/plugins loader API for ersan.core (US-002).

Re-exports the loader's public surface so callers can write::

    from ersan.core.skills import discover_skills, invoke, Skill

without reaching into the submodule.
"""

from __future__ import annotations

from ersan.core.skills.loader import (
    Skill,
    SkillHandlerError,
    SkillLoaderError,
    SkillManifestError,
    SkillPluginMismatchError,
    SkillPolicyDeniedError,
    discover_skills,
    invoke,
)

__all__ = [
    "Skill",
    "SkillHandlerError",
    "SkillLoaderError",
    "SkillManifestError",
    "SkillPluginMismatchError",
    "SkillPolicyDeniedError",
    "discover_skills",
    "invoke",
]
