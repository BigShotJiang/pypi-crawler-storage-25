# ersan — your office. your rules. your AI. ...and you, amplified.
# Copyright 2026 Ersan Bilik
# SPDX-License-Identifier: Apache-2.0
"""ersan core: cross-cutting infrastructure (loader, runtime).

The `core` namespace holds infrastructure shared across plugins —
things like the skill loader (`ersan.core.skills.loader`) that every
plugin relies on. Plugins themselves live under `ersan.skills.<plugin>`
(sibling of `core`), not inside `core`. See
`.specify/specs/002-skill-loader/plan.md` Decision R-001 for the
rationale.
"""

from __future__ import annotations
