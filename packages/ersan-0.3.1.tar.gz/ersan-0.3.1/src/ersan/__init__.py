# ersan — your office. your rules. your AI. ...and you, amplified.
# Copyright 2026 Ersan Bilik
# SPDX-License-Identifier: Apache-2.0
"""ersan - open-source AI agent for Microsoft 365.

ersan is the gate (owns the user relationship), not infrastructure.
Capabilities load as skills, packaged into plugins. Every skill call
passes through policy (trust tiers) and shield (PII / credential
redaction) before output reaches the user.

Read the constitution: see CONSTITUTION.md at the repository root.
Read the agent brief: see AGENTS.md at the repository root.
"""

__version__ = "0.3.1"

BANNER = """
 ███████╗██████╗ ███████╗ █████╗ ███╗   ██╗
 ██╔════╝██╔══██╗██╔════╝██╔══██╗████╗  ██║
 █████╗  ██████╔╝███████╗███████║██╔██╗ ██║
 ██╔══╝  ██╔══██╗╚════██║██╔══██║██║╚██╗██║
 ███████╗██║  ██║███████║██║  ██║██║ ╚████║
 ╚══════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═╝  ╚═══╝

   Your office. Your rules. Your AI.
          ...and you, amplified.
""".strip("\n")

MOTTO = "Your office. Your rules. Your AI. ...and you, amplified."

__all__ = ["BANNER", "MOTTO", "__version__"]
