# ersan — your office. your rules. your AI. ...and you, amplified.
# Copyright 2026 Ersan Bilik
# SPDX-License-Identifier: Apache-2.0
"""Content shield ported from ersan_ai_shield/shield.py."""

from __future__ import annotations

import time
from collections.abc import Callable
from typing import Any

from ersan.shield.layers.ner import NERScanner
from ersan.shield.layers.regex import RegexScanner
from ersan.shield.layers.semantic import SemanticScanner
from ersan.shield.types import Finding, ScanAction, ScanResult

CONTENT_FIELDS = {
    "body",
    "text",
    "subject",
    "content",
    "message",
    "description",
    "notes",
    "comment",
}
"""Argument fields treated as user-authored content."""

_REDACT_CHAR = "\u2588"
_REDACT_LENGTH = 4


class ContentShield:
    """Unified content firewall that chains the available shield layers."""

    def __init__(
        self,
        enable_pii: bool = True,
        enable_semantic: bool = True,
        custom_patterns: list[dict[str, Any]] | None = None,
        audit_logger: Any | None = None,
        legal_threshold: float = 0.65,
        legal_examples: dict[str, list[str]] | None = None,
    ) -> None:
        self._regex = RegexScanner(extra_patterns=custom_patterns)
        self._layers: list[tuple[str, Any]] = [("regex", self._regex)]

        if enable_pii and NERScanner.is_available():
            self._ner = NERScanner()
            self._layers.append(("ner", self._ner))

        if enable_semantic and SemanticScanner.is_available():
            self._semantic = SemanticScanner(
                threshold=legal_threshold,
                examples=legal_examples,
            )
            self._layers.append(("semantic", self._semantic))

        self._audit = audit_logger

    def scan(self, text: str) -> ScanResult:
        """Scan one text string through all active layers."""
        start = time.perf_counter()
        findings: list[Finding] = []
        layers_used: list[str] = []

        for name, layer in self._layers:
            layer_findings = layer.scan(text)
            if layer_findings:
                findings.extend(layer_findings)
            layers_used.append(name)

        return ScanResult(
            passed=not any(finding.action is ScanAction.BLOCK for finding in findings),
            findings=findings,
            redacted=self._apply_redactions(text, findings),
            scan_time_ms=(time.perf_counter() - start) * 1000,
            layers_used=layers_used,
        )

    def scan_tool_args(self, tool: str, args: dict[str, Any]) -> ScanResult:
        """Scan content-bearing tool arguments."""
        start = time.perf_counter()
        all_findings: list[Finding] = []
        layers_used_set: set[str] = set()
        redacted_args: dict[str, Any] = {}
        has_redactions = False

        for key, value in args.items():
            if key not in CONTENT_FIELDS or not isinstance(value, str):
                continue

            for name, layer in self._layers:
                layer_findings = layer.scan(value, field=key)
                for finding in layer_findings:
                    finding.field = key
                all_findings.extend(layer_findings)
                layers_used_set.add(name)

            redacted_text = self._apply_redactions(value, all_findings)
            if redacted_text is not None:
                redacted_args[key] = redacted_text
                has_redactions = True

        result = ScanResult(
            passed=not any(finding.action is ScanAction.BLOCK for finding in all_findings),
            findings=all_findings,
            redacted_args=redacted_args if has_redactions else None,
            scan_time_ms=(time.perf_counter() - start) * 1000,
            layers_used=(
                sorted(layers_used_set) if layers_used_set else [name for name, _ in self._layers]
            ),
        )

        if self._audit is not None:
            self._audit.log(tool, result)

        return result

    def guard(self, tool: str, on_block: str = "raise") -> Callable[..., Any]:
        """Preserve the source API surface until `make_guard` ships."""
        raise NotImplementedError(
            "ContentShield.guard() ships in v0.4+ alongside make_guard() "
            "— see adapters/decorator.py"
        )

    @staticmethod
    def _apply_redactions(text: str, findings: list[Finding]) -> str | None:
        """Replace REDACT findings with block characters."""
        redact_findings = [
            finding
            for finding in findings
            if (
                finding.action is ScanAction.REDACT
                and finding.start >= 0
                and finding.end > finding.start
            )
        ]
        if not redact_findings:
            return None

        redact_findings.sort(key=lambda finding: finding.start, reverse=True)
        result = text
        for finding in redact_findings:
            replacement = _REDACT_CHAR * _REDACT_LENGTH
            result = result[: finding.start] + replacement + result[finding.end :]
        return result
