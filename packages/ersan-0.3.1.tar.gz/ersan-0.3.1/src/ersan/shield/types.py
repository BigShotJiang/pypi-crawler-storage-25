# ersan — your office. your rules. your AI. ...and you, amplified.
# Copyright 2026 Ersan Bilik
# SPDX-License-Identifier: Apache-2.0
"""Shield types ported from ersan_ai_shield/types.py."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class ScanAction(str, Enum):
    """Possible outcomes from a shield detector."""

    PASS = "pass"  # noqa: S105
    WARN = "warn"
    BLOCK = "block"
    REDACT = "redact"


@dataclass
class Finding:
    """One detector finding."""

    type: str
    subtype: str
    text: str
    action: ScanAction
    confidence: float = 1.0
    field: str = ""
    message: str = ""
    start: int = -1
    end: int = -1


@dataclass
class ScanResult:
    """Aggregate result from one shield scan."""

    passed: bool
    findings: list[Finding] = field(default_factory=list)
    redacted: str | None = None
    redacted_args: dict[str, Any] | None = None
    scan_time_ms: float = 0.0
    layers_used: list[str] = field(default_factory=list)

    @property
    def blocks(self) -> list[Finding]:
        """Return only BLOCK findings."""
        return [finding for finding in self.findings if finding.action is ScanAction.BLOCK]

    @property
    def warnings(self) -> list[Finding]:
        """Return only WARN findings."""
        return [finding for finding in self.findings if finding.action is ScanAction.WARN]

    @property
    def redactions(self) -> list[Finding]:
        """Return only REDACT findings."""
        return [finding for finding in self.findings if finding.action is ScanAction.REDACT]
