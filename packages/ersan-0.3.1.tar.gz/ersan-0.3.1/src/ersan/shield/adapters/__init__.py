# ersan — your office. your rules. your AI. ...and you, amplified.
# Copyright 2026 Ersan Bilik
# SPDX-License-Identifier: Apache-2.0
"""Shield adapter package."""

from __future__ import annotations

from ersan.shield.adapters.decorator import ShieldBlocked

__all__ = ["ShieldBlocked"]
