# ersan — your office. your rules. your AI. ...and you, amplified.
# Copyright 2026 Ersan Bilik
# SPDX-License-Identifier: Apache-2.0
"""Shield adapter exceptions ported from ersan_ai_shield/adapters/decorator.py.

`make_guard` is intentionally deferred to v0.4+, but `ShieldBlocked`
stays at the source-faithful path so future ports do not need a move.
"""

from __future__ import annotations

from ersan.shield.types import ScanResult


class ShieldBlocked(Exception):  # noqa: N818
    """Raised when `ContentShield` blocks outbound content."""

    def __init__(self, result: ScanResult) -> None:
        self.result = result
        blocked = result.blocks
        messages = [finding.message or finding.subtype for finding in blocked]
        super().__init__(f"ContentShield blocked: {'; '.join(messages)}")
