# ersan — your office. your rules. your AI. ...and you, amplified.
# Copyright 2026 Ersan Bilik
# SPDX-License-Identifier: Apache-2.0
"""Semantic shield layer stub ported from ersan_ai_shield/layers/semantic.py.

This preserves the source class surface for the future optional semantic
scanner while v0.3 ships the no-dependency stub.
"""

from __future__ import annotations

from ersan.shield.types import Finding


class SemanticScanner:
    """Semantic layer stub for v0.3."""

    def __init__(
        self,
        *,
        threshold: float = 0.65,
        examples: dict[str, list[str]] | None = None,
        model_name: str = "sentence-transformers/all-MiniLM-L6-v2",
    ) -> None:
        self._threshold = threshold
        self._examples = examples or {}
        self._model_name = model_name

    @staticmethod
    def is_available() -> bool:
        """The optional semantic runtime does not ship in v0.3."""
        return False

    def scan(self, text: str, field: str = "") -> list[Finding]:
        """Return no findings while the optional runtime is absent."""
        return []
