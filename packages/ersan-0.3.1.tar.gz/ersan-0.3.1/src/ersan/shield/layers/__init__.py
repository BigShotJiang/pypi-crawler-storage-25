# ersan — your office. your rules. your AI. ...and you, amplified.
# Copyright 2026 Ersan Bilik
# SPDX-License-Identifier: Apache-2.0
"""Shield layer Protocol.

No source precedent — D-017 §genuinely-new-concerns founder-approved
2026-04-19 via issue #36 body, because source duck-types the scanner layer
interface and v0.3 makes that common `scan()` shape explicit.
"""

from __future__ import annotations

from typing import Protocol, runtime_checkable

from ersan.shield.types import Finding


@runtime_checkable
class Layer(Protocol):
    """Common interface every shield layer satisfies.

    `is_available()` intentionally stays off the Protocol body per OQ-9.
    The optional-dependency scanners expose it on their concrete classes,
    and `ContentShield` calls those class methods directly by name.
    """

    def scan(self, text: str, field: str = "") -> list[Finding]:
        """Scan text and return zero or more findings."""
        ...
