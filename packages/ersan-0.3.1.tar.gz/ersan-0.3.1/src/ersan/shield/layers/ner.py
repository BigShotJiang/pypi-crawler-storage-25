# ersan — your office. your rules. your AI. ...and you, amplified.
# Copyright 2026 Ersan Bilik
# SPDX-License-Identifier: Apache-2.0
"""NER shield layer stub ported from ersan_ai_shield/layers/ner.py.

This preserves the source class surface for future optional-dependency
activation while v0.3 ships the no-dependency stub.
"""

from __future__ import annotations

from ersan.shield.types import Finding


class NERScanner:
    """PII layer stub for v0.3."""

    def __init__(
        self,
        *,
        min_confidence: float = 0.6,
        languages: list[str] | None = None,
    ) -> None:
        self._min_confidence = min_confidence
        self._languages = languages or ["en"]

    @staticmethod
    def is_available() -> bool:
        """The optional NER runtime does not ship in v0.3."""
        return False

    def scan(self, text: str, field: str = "") -> list[Finding]:
        """Return no findings while the optional runtime is absent."""
        return []
