# ersan — your office. your rules. your AI. ...and you, amplified.
# Copyright 2026 Ersan Bilik
# SPDX-License-Identifier: Apache-2.0
"""Regex shield layer ported from ersan_ai_shield/layers/regex.py."""

from __future__ import annotations

import re
from typing import Any

from ersan.shield.types import Finding, ScanAction

CREDENTIAL_PATTERNS: list[tuple[str, str, ScanAction, str]] = [
    (r"(?:api[_-]?key|apikey)\s*[:=]\s*\S{10,}", "api_key", ScanAction.BLOCK, "API key detected"),
    (r"\bsk-ant-[a-zA-Z0-9]{20,}", "anthropic_key", ScanAction.BLOCK, "Anthropic API key"),
    (r"\bsk-proj-[a-zA-Z0-9]{20,}", "openai_key", ScanAction.BLOCK, "OpenAI API key"),
    (r"\bAKIA[0-9A-Z]{16}\b", "aws_key", ScanAction.BLOCK, "AWS access key"),
    (r"\bghp_[a-zA-Z0-9]{36,}\b", "github_token", ScanAction.BLOCK, "GitHub personal access token"),
    (r"\bgho_[a-zA-Z0-9]{36,}\b", "github_oauth", ScanAction.BLOCK, "GitHub OAuth token"),
    (
        r"(?:password|passwd|pwd)\s*[:=]\s*\S{8,}",
        "password",
        ScanAction.BLOCK,
        "Password detected",
    ),
    (
        r"(?:secret|secret[_-]?key)\s*[:=]\s*\S{8,}",
        "secret",
        ScanAction.BLOCK,
        "Secret key detected",
    ),
    (
        r"\bBearer\s+eyJ[a-zA-Z0-9_-]{20,}",
        "bearer_token",
        ScanAction.BLOCK,
        "Bearer token detected",
    ),
    (
        r"\beyJ[a-zA-Z0-9_-]{20,}\.eyJ[a-zA-Z0-9_-]{20,}\.[a-zA-Z0-9_-]{20,}",
        "jwt",
        ScanAction.BLOCK,
        "JWT detected",
    ),
    (
        r"(?:mongodb|postgres|mysql|redis)://\S{10,}",
        "connection_string",
        ScanAction.BLOCK,
        "Connection string detected",
    ),
    (
        r"(?:[A-Za-z0-9+/]{200,}={0,2})",
        "base64_blob",
        ScanAction.WARN,
        "Large base64 blob - possible encoded secret",
    ),
]
"""Built-in detector patterns shipped in the v0.3 regex layer."""

_ACTION_MAP = {
    "pass": ScanAction.PASS,
    "warn": ScanAction.WARN,
    "block": ScanAction.BLOCK,
    "redact": ScanAction.REDACT,
}


class RegexScanner:
    """Pattern-based credential and secret scanner."""

    def __init__(self, extra_patterns: list[dict[str, Any]] | None = None) -> None:
        self._compiled: list[tuple[re.Pattern[str], str, ScanAction, str]] = []
        for raw_pattern, subtype, action, message in CREDENTIAL_PATTERNS:
            self._compiled.append(
                (re.compile(raw_pattern, re.IGNORECASE), subtype, action, message)
            )

        if extra_patterns is not None:
            for custom_pattern in extra_patterns:
                action = _ACTION_MAP.get(custom_pattern.get("action", "warn"), ScanAction.WARN)
                self._compiled.append(
                    (
                        re.compile(custom_pattern["pattern"]),
                        custom_pattern["name"],
                        action,
                        custom_pattern.get("message", ""),
                    )
                )

    def scan(self, text: str, field: str = "") -> list[Finding]:
        """Scan text for regex-defined credential patterns."""
        findings: list[Finding] = []
        for compiled, subtype, action, message in self._compiled:
            for match in compiled.finditer(text):
                findings.append(
                    Finding(
                        type="credential" if action is ScanAction.BLOCK else "pattern",
                        subtype=subtype,
                        text=match.group()[:100],
                        action=action,
                        confidence=1.0,
                        field=field,
                        message=message,
                        start=match.start(),
                        end=match.end(),
                    )
                )
        return findings
