# ersan — your office. your rules. your AI. ...and you, amplified.
# Copyright 2026 Ersan Bilik
# SPDX-License-Identifier: Apache-2.0
"""Policy loading and tier resolution ported from ersan_ai_policy/core/policy.py.

This slim port keeps the retail-needed data model, YAML loader, tier lookup,
and blocked-pattern helpers while cutting enterprise cascading-policy types.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

from ersan.policy.types import TIER_RANK, ConditionalRule, ToolPolicy

log = logging.getLogger("ersan.policy.policy")

TIERS = ("do_it", "do_and_tell", "ask_first", "log_only", "never")
"""Valid policy tier names in permissive-to-restrictive order."""


@dataclass
class Policy:
    """Parsed policy data."""

    default_tier: str = "ask_first"
    tool_tiers: dict[str, str] = field(default_factory=dict)
    tool_policies: dict[str, ToolPolicy] = field(default_factory=dict)
    blocked_patterns: list[re.Pattern[str]] = field(default_factory=list)


def load_policy(path: str | Path, *, is_layer: bool = False) -> Policy:
    """Load a YAML policy file.

    Missing or unparsable files fall back to source-shaped defaults.
    """
    fallback_default = "" if is_layer else "ask_first"
    policy = Policy(default_tier=fallback_default)
    policy_path = Path(path)
    if not policy_path.is_file():
        return policy

    try:
        data = yaml.safe_load(policy_path.read_text(encoding="utf-8")) or {}
    except Exception as exc:
        log.error(
            "Failed to parse policy file '%s': %s - using defaults.",
            policy_path,
            exc,
        )
        return policy

    defaults_section = data.get("defaults", {})
    explicit_tier = defaults_section.get("tier") if isinstance(defaults_section, dict) else None
    if explicit_tier:
        policy.default_tier = explicit_tier if explicit_tier in TIERS else "ask_first"
    elif not is_layer:
        policy.default_tier = "ask_first"

    tools = data.get("tools", {})
    if isinstance(tools, dict):
        for name, config in tools.items():
            if isinstance(config, str):
                if config in TIERS:
                    policy.tool_tiers[name] = config
                else:
                    log.warning(
                        "Policy: tool '%s' has invalid tier '%s' (valid: %s) - using default '%s'",
                        name,
                        config,
                        ", ".join(TIERS),
                        policy.default_tier,
                    )
            elif isinstance(config, dict):
                if "rules" in config:
                    tool_policy = _parse_tool_policy(name, config, policy.default_tier)
                    if tool_policy is not None:
                        policy.tool_policies[name] = tool_policy
                else:
                    tier = config.get("tier", policy.default_tier)
                    if tier in TIERS:
                        policy.tool_tiers[name] = tier
                    else:
                        log.warning(
                            (
                                "Policy: tool '%s' has invalid tier '%s' "
                                "(valid: %s) - using default '%s'"
                            ),
                            name,
                            tier,
                            ", ".join(TIERS),
                            policy.default_tier,
                        )

    blocked_patterns = data.get("blocked_patterns", [])
    if isinstance(blocked_patterns, list):
        for pattern in blocked_patterns:
            try:
                policy.blocked_patterns.append(re.compile(pattern, re.IGNORECASE))
            except re.error:
                continue

    return policy


def _parse_tool_policy(
    name: str,
    config: dict[str, Any],
    default_tier: str,
) -> ToolPolicy | None:
    """Parse one tool's conditional-rule configuration."""
    from ersan.policy.conditions import ConditionParseError, parse_condition

    rules_raw = config.get("rules", [])
    if not isinstance(rules_raw, list):
        log.warning("Policy: tool '%s' has non-list 'rules' - skipping", name)
        return None

    rules: list[ConditionalRule] = []
    for rule_data in rules_raw:
        if not isinstance(rule_data, dict) or "when" not in rule_data:
            log.warning("Policy: tool '%s' has rule without 'when' - skipping rule", name)
            continue
        tier = rule_data.get("tier", default_tier)
        if tier not in TIERS:
            log.warning("Policy: tool '%s' rule has invalid tier '%s' - skipping rule", name, tier)
            continue
        rule = ConditionalRule(
            when=rule_data["when"],
            tier=tier,
            message=rule_data.get("message", ""),
        )
        try:
            rule.parsed = parse_condition(rule.when)
        except ConditionParseError as exc:
            log.warning("Policy: tool '%s' rule condition error: %s - skipping rule", name, exc)
            continue
        rules.append(rule)

    if not rules:
        log.warning("Policy: tool '%s' has no valid rules - using default tier", name)
        return None

    default = config.get("default", default_tier)
    if default not in TIERS:
        default = default_tier
    return ToolPolicy(rules=rules, default=default)


def has_conditional_rules(policy: Policy, tool_name: str) -> bool:
    """Return whether a tool has conditional rules configured."""
    return tool_name in policy.tool_policies


def get_tier(policy: Policy, tool_name: str) -> str:
    """Return the configured or default tier for a tool."""
    if tool_name in policy.tool_tiers:
        return policy.tool_tiers[tool_name]
    if tool_name in policy.tool_policies:
        return policy.tool_policies[tool_name].default
    return policy.default_tier


_TIER_RANK = TIER_RANK


def check_blocked(policy: Policy, text: str) -> str | None:
    """Return the matching blocked-pattern string, if any."""
    for pattern in policy.blocked_patterns:
        if pattern.search(text):
            return pattern.pattern
    return None


def check_blocked_recursive(
    policy: Policy,
    value: Any,
    *,
    max_depth: int = 20,
    _depth: int = 0,
) -> str | None:
    """Walk nested args and return the first blocked-pattern match."""
    if _depth >= max_depth:
        return None
    if isinstance(value, str):
        return check_blocked(policy, value)
    if isinstance(value, dict):
        for nested in value.values():
            hit = check_blocked_recursive(policy, nested, max_depth=max_depth, _depth=_depth + 1)
            if hit:
                return hit
    elif isinstance(value, list | tuple):
        for nested in value:
            hit = check_blocked_recursive(policy, nested, max_depth=max_depth, _depth=_depth + 1)
            if hit:
                return hit
    return None


def build_args_summary(args: dict[str, Any]) -> str:
    """Format args as truncated key=value pairs for audit logging."""
    parts: list[str] = []
    for key, value in args.items():
        rendered = str(value)
        if len(rendered) > 40:
            rendered = rendered[:40] + "\u2026"
        parts.append(f"{key}='{rendered}'")
    result = ", ".join(parts)
    if len(result) > 200:
        result = result[:200]
    return result
