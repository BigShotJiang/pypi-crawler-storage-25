# ersan — your office. your rules. your AI. ...and you, amplified.
# Copyright 2026 Ersan Bilik
# SPDX-License-Identifier: Apache-2.0
"""Audit logging ported from ersan_ai_policy/core/audit.py.

The slim port keeps the runtime-checkable logger contract and the JSON-lines
file logger that US-005 wires into the loader defaults.
"""

from __future__ import annotations

import json
import logging
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Protocol, runtime_checkable

from ersan.policy.types import AuditEntry

log = logging.getLogger("ersan.policy.audit")


@runtime_checkable
class AuditLoggerProtocol(Protocol):
    """Protocol that every audit logger must satisfy."""

    def log(
        self,
        tool_name: str,
        args_summary: str,
        decision: str,
        user: str = "",
        reason: str = "",
    ) -> None: ...


class JSONLinesAuditLogger:
    """Append-only JSON-lines audit log writer."""

    def __init__(self, path: str | Path, *, max_size_bytes: int = 5 * 1024 * 1024) -> None:
        self._path = Path(path).expanduser()
        self._max_size = max_size_bytes

    def log(
        self,
        tool_name: str,
        args_summary: str,
        decision: str,
        user: str = "",
        reason: str = "",
    ) -> None:
        """Append one JSON-lines entry, rotating if the file exceeds the limit."""
        if len(args_summary) > 200:
            args_summary = args_summary[:200]

        entry: dict[str, str] = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "tool": tool_name,
            "args_summary": args_summary,
            "decision": decision,
            "user": user,
        }
        if reason:
            entry["reason"] = reason

        try:
            self._path.parent.mkdir(parents=True, exist_ok=True)
            if self._path.is_file():
                try:
                    if self._path.stat().st_size > self._max_size:
                        os.replace(self._path, Path(str(self._path) + ".1"))
                except OSError:
                    pass
            with self._path.open("a", encoding="utf-8", newline="") as handle:
                handle.write(json.dumps(entry, default=str) + "\n")
        except OSError:
            log.warning("Failed to write audit log entry for %s", tool_name)

    def to_audit_entry(
        self,
        tool_name: str,
        args_summary: str,
        decision: str,
        user: str = "",
        reason: str = "",
    ) -> AuditEntry:
        """Build an `AuditEntry` without writing it."""
        return AuditEntry(
            timestamp=datetime.now(timezone.utc).isoformat(),
            tool=tool_name,
            args_summary=args_summary,
            action=decision,
            user=user,
            reason=reason,
        )
