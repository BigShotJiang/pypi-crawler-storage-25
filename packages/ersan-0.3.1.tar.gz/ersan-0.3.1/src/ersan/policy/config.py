# ersan — your office. your rules. your AI. ...and you, amplified.
# Copyright 2026 Ersan Bilik
# SPDX-License-Identifier: Apache-2.0
"""Retail policy config helpers.

No source precedent — D-017 §genuinely-new-concerns founder-approved
2026-04-19 via issue #36 body, because retail needs a thin convenience
cascade from `~/.ersan/policy.yaml` to the packaged default policy.
"""

from __future__ import annotations

from importlib import resources
from pathlib import Path

from ersan.policy.policy import Policy, load_policy


def load_default_policy() -> Policy:
    """Load the user override policy or the packaged retail default."""
    user_policy = Path.home() / ".ersan" / "policy.yaml"
    if user_policy.is_file():
        return load_policy(user_policy)

    packaged_policy = resources.files("ersan.policy").joinpath("_default_policy.yaml")
    with resources.as_file(packaged_policy) as packaged_path:
        return load_policy(packaged_path)
