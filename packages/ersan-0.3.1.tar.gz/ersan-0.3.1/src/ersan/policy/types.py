# ersan — your office. your rules. your AI. ...and you, amplified.
# Copyright 2026 Ersan Bilik
# SPDX-License-Identifier: Apache-2.0
"""Policy types ported from ersan_ai_policy/core/types.py.

Verbatim slim port per US-005 source provenance. The full type hierarchy
ships even where retail v0.3 does not yet populate every field, preserving
enterprise-pluggability shape for future extensions.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class Tier(str, Enum):
    """Policy tiers from most permissive to most restrictive."""

    DO_IT = "do_it"
    DO_AND_TELL = "do_and_tell"
    ASK_FIRST = "ask_first"
    LOG_ONLY = "log_only"
    NEVER = "never"


class Action(str, Enum):
    """Enforcement actions derived from tier evaluation."""

    ALLOW = "allow"
    ALLOW_NOTIFY = "allow_notify"
    CONFIRM = "confirm"
    LOG_ONLY = "log_only"
    DENY = "deny"


TIER_TO_ACTION: dict[Tier, Action] = {
    Tier.DO_IT: Action.ALLOW,
    Tier.DO_AND_TELL: Action.ALLOW_NOTIFY,
    Tier.ASK_FIRST: Action.CONFIRM,
    Tier.LOG_ONLY: Action.LOG_ONLY,
    Tier.NEVER: Action.DENY,
}
"""Mapping from policy tier to concrete enforcement action."""


TIER_RANK: dict[str, int] = {
    Tier.DO_IT.value: 0,
    Tier.DO_AND_TELL.value: 1,
    Tier.ASK_FIRST.value: 2,
    Tier.LOG_ONLY.value: 3,
    Tier.NEVER.value: 4,
}
"""Tier restrictiveness ranking where higher means more restrictive."""


DEFAULT_TIER: str = Tier.ASK_FIRST.value
"""Retail-safe default policy tier."""


@dataclass
class CallerContext:
    """Information about who or what is invoking the tool."""

    identity: str = ""
    channel: str = ""


@dataclass
class AuditEntry:
    """Single audit log record."""

    timestamp: str
    tool: str
    args_summary: str
    action: str
    user: str = ""
    reason: str = ""
    policy_version: str = ""


@dataclass
class SessionContext:
    """Runtime session state for contextual policy evaluation."""

    dlp_level: int = 0
    session_tool_count: int = 0
    tool_call_counts: dict[str, int] = field(default_factory=dict)
    custom: dict[str, Any] = field(default_factory=dict)


@dataclass
class ConditionalRule:
    """A condition-based runtime policy rule."""

    when: str
    tier: str
    message: str = ""
    parsed: Any = None


@dataclass
class ToolPolicy:
    """Per-tool policy config supporting conditional rules."""

    rules: list[ConditionalRule] = field(default_factory=list)
    default: str = ""


@dataclass(frozen=True)
class Decision:
    """Result of a policy evaluation."""

    action: Action
    tier: Tier
    tool: str
    reason: str
    audit_entry: AuditEntry
    blocked_pattern: str | None = None
    matched_rule: str | None = None
