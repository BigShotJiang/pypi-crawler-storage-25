# ersan — your office. your rules. your AI. ...and you, amplified.
# Copyright 2026 Ersan Bilik
# SPDX-License-Identifier: Apache-2.0
"""Policy engine ported from ersan_ai_policy/core/engine.py.

This keeps the source evaluation flow and decorator surface while limiting the
retail port to the core policy module set shipped in US-005.
"""

from __future__ import annotations

import asyncio
import functools
from collections.abc import Callable
from datetime import datetime, timezone
from typing import Any

from ersan.policy.audit import AuditLoggerProtocol
from ersan.policy.conditions import evaluate_condition
from ersan.policy.policy import (
    Policy,
    build_args_summary,
    check_blocked_recursive,
    get_tier,
    has_conditional_rules,
)
from ersan.policy.types import (
    TIER_TO_ACTION,
    Action,
    AuditEntry,
    CallerContext,
    Decision,
    SessionContext,
    Tier,
)


class PolicyEngine:
    """Evaluate tool calls against a policy and return decisions."""

    def __init__(
        self,
        policy: Policy,
        *,
        audit_logger: AuditLoggerProtocol | None = None,
    ) -> None:
        self.policy = policy
        self.audit_logger = audit_logger

    def evaluate(
        self,
        tool: str,
        args: dict[str, Any] | None = None,
        caller: CallerContext | None = None,
        session: SessionContext | None = None,
    ) -> Decision:
        """Evaluate one tool call against the configured policy."""
        effective_args = args or {}
        effective_caller = caller or CallerContext()
        summary = build_args_summary(effective_args)

        blocked = check_blocked_recursive(self.policy, effective_args)
        if blocked:
            reason = f"matched pattern: {blocked}"
            entry = self._make_audit_entry(
                tool,
                summary,
                "blocked",
                effective_caller.identity,
                reason,
            )
            if self.audit_logger is not None:
                self.audit_logger.log(
                    tool,
                    summary,
                    "blocked",
                    user=effective_caller.identity,
                    reason=reason,
                )
            return Decision(
                action=Action.DENY,
                tier=Tier.NEVER,
                tool=tool,
                reason=f"Arguments match blocked pattern: {blocked}",
                audit_entry=entry,
                blocked_pattern=blocked,
            )

        matched_rule: str | None = None
        if has_conditional_rules(self.policy, tool):
            tool_policy = self.policy.tool_policies[tool]
            tier_str = None
            for rule in tool_policy.rules:
                if rule.parsed and evaluate_condition(
                    rule.parsed,
                    effective_args,
                    effective_caller,
                    session,
                ):
                    tier_str = rule.tier
                    matched_rule = rule.when
                    break
            if tier_str is None:
                tier_str = tool_policy.default
        else:
            tier_str = get_tier(self.policy, tool)

        tier = Tier(tier_str)
        action = TIER_TO_ACTION[tier]
        action_label = self._action_to_audit_label(action)
        reason = f"tier={tier_str}, action={action.value}"
        if matched_rule is not None:
            reason = f"rule matched: {matched_rule} -> tier={tier_str}"
        entry = self._make_audit_entry(
            tool,
            summary,
            action_label,
            effective_caller.identity,
            reason,
        )

        if self.audit_logger is not None:
            self.audit_logger.log(
                tool,
                summary,
                action_label,
                user=effective_caller.identity,
                reason=reason,
            )

        return Decision(
            action=action,
            tier=tier,
            tool=tool,
            reason=reason,
            audit_entry=entry,
            matched_rule=matched_rule,
        )

    def enforce(self, tool_name: str) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        """Wrap a sync or async function with policy enforcement."""

        def decorator(function: Callable[..., Any]) -> Callable[..., Any]:
            if asyncio.iscoroutinefunction(function):

                @functools.wraps(function)
                async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
                    decision = self.evaluate(tool_name, kwargs)
                    _raise_on_deny(decision)
                    return await function(*args, **kwargs)

                return async_wrapper

            @functools.wraps(function)
            def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
                decision = self.evaluate(tool_name, kwargs)
                _raise_on_deny(decision)
                return function(*args, **kwargs)

            return sync_wrapper

        return decorator

    @staticmethod
    def _action_to_audit_label(action: Action) -> str:
        return {
            Action.ALLOW: "silent",
            Action.ALLOW_NOTIFY: "auto_approved",
            Action.CONFIRM: "needs_confirmation",
            Action.LOG_ONLY: "log_only",
            Action.DENY: "blocked",
        }.get(action, action.value)

    @staticmethod
    def _make_audit_entry(
        tool: str,
        summary: str,
        action_label: str,
        user: str = "",
        reason: str = "",
    ) -> AuditEntry:
        return AuditEntry(
            timestamp=datetime.now(timezone.utc).isoformat(),
            tool=tool,
            args_summary=summary,
            action=action_label,
            user=user,
            reason=reason,
        )


class PolicyDenied(Exception):  # noqa: N818
    """Raised when policy denies a tool call."""

    def __init__(self, decision: Decision) -> None:
        self.decision = decision
        super().__init__(f"Policy denied '{decision.tool}': {decision.reason}")


class PolicyConfirmRequired(Exception):  # noqa: N818
    """Raised when policy requires explicit confirmation."""

    def __init__(self, decision: Decision) -> None:
        self.decision = decision
        super().__init__(f"Policy requires confirmation for '{decision.tool}': {decision.reason}")


def _raise_on_deny(decision: Decision) -> None:
    """Raise the source-shaped exception for blocking actions."""
    if decision.action is Action.DENY:
        raise PolicyDenied(decision)
    if decision.action is Action.LOG_ONLY:
        raise PolicyDenied(decision)
    if decision.action is Action.CONFIRM:
        raise PolicyConfirmRequired(decision)
