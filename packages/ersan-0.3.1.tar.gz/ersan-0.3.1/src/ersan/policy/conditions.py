# ersan — your office. your rules. your AI. ...and you, amplified.
# Copyright 2026 Ersan Bilik
# SPDX-License-Identifier: Apache-2.0
"""Policy conditions ported from ersan_ai_policy/core/conditions.py.

This is the source parser and evaluator shape for contextual tool-policy
rules. The slim port keeps the deterministic expression language intact.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from typing import Any

log = logging.getLogger("ersan.policy.conditions")

_OPERATORS = frozenset(
    {
        "==",
        "!=",
        ">",
        "<",
        ">=",
        "<=",
        "CONTAINS",
        "NOT_CONTAINS",
        "MATCHES",
        "IN",
        "NOT_IN",
    }
)
_COMBINATORS = frozenset({"AND", "OR"})
_TOKEN_RE = re.compile(
    r'"[^"]*"'
    r"|'[^']*'"
    r"|>=|<=|!=|==|>|<"
    r"|\bNOT_CONTAINS\b"
    r"|\bNOT_IN\b"
    r"|\bCONTAINS\b"
    r"|\bMATCHES\b"
    r"|\bIN\b"
    r"|\bAND\b"
    r"|\bOR\b"
    r"|[^\s]+"
)


@dataclass
class Condition:
    """A single field-operator-value comparison."""

    field: str
    operator: str
    value: str


@dataclass
class ConditionGroup:
    """A flat list of conditions joined by AND/OR combinators."""

    conditions: list[Condition] = field(default_factory=list)
    combinators: list[str] = field(default_factory=list)


class ConditionParseError(ValueError):
    """Raised when a condition expression cannot be parsed."""


def parse_condition(expr: str) -> ConditionGroup:
    """Parse a condition expression into a flat condition group."""
    tokens = _TOKEN_RE.findall(expr.strip())
    if not tokens:
        raise ConditionParseError(f"Empty condition: {expr!r}")

    group = ConditionGroup()
    index = 0

    while index < len(tokens):
        if index + 2 >= len(tokens):
            raise ConditionParseError(f"Incomplete condition at position {index} in: {expr!r}")

        field_name = tokens[index]
        operator = tokens[index + 1].upper()
        value = tokens[index + 2]
        if operator not in _OPERATORS:
            raise ConditionParseError(f"Unknown operator {tokens[index + 1]!r} in: {expr!r}")

        if len(value) >= 2 and value[0] in {'"', "'"} and value[-1] == value[0]:
            value = value[1:-1]

        group.conditions.append(Condition(field=field_name, operator=operator, value=value))
        index += 3

        if index < len(tokens):
            combinator = tokens[index].upper()
            if combinator not in _COMBINATORS:
                raise ConditionParseError(
                    f"Expected AND/OR but got {tokens[index]!r} at position {index} in: {expr!r}"
                )
            group.combinators.append(combinator)
            index += 1

    return group


def _resolve_field(
    field_name: str,
    args: dict[str, Any],
    caller: Any | None,
    session: Any | None,
) -> Any:
    """Resolve a condition field from args, session, or caller context."""
    if field_name in args:
        return args[field_name]

    if session is not None:
        if hasattr(session, field_name):
            return getattr(session, field_name)
        custom = getattr(session, "custom", None)
        if isinstance(custom, dict) and field_name in custom:
            return custom[field_name]

    if caller is not None:
        if field_name.startswith("caller_"):
            attr = field_name[7:]
            if hasattr(caller, attr):
                return getattr(caller, attr)
        if hasattr(caller, field_name):
            return getattr(caller, field_name)

    return None


def _coerce_numeric(value: str) -> float | str:
    """Return a float when possible, otherwise the original string."""
    try:
        return float(value)
    except (TypeError, ValueError):
        return value


def _evaluate_single(
    condition: Condition,
    args: dict[str, Any],
    caller: Any | None,
    session: Any | None,
) -> bool:
    """Evaluate one condition against the runtime context."""
    actual = _resolve_field(condition.field, args, caller, session)
    if actual is None:
        return False

    actual_str = str(actual)
    expected = condition.value
    operator = condition.operator

    if operator == "==":
        return actual_str == expected
    if operator == "!=":
        return actual_str != expected
    if operator == "CONTAINS":
        return expected.lower() in actual_str.lower()
    if operator == "NOT_CONTAINS":
        return expected.lower() not in actual_str.lower()
    if operator == "MATCHES":
        try:
            return bool(re.search(expected, actual_str))
        except re.error:
            log.warning("Invalid regex in condition MATCHES: %s", expected)
            return False
    if operator == "IN":
        return actual_str in [item.strip() for item in expected.split(",")]
    if operator == "NOT_IN":
        return actual_str not in [item.strip() for item in expected.split(",")]
    if operator in {">", "<", ">=", "<="}:
        actual_num = _coerce_numeric(actual_str)
        expected_num = _coerce_numeric(expected)
        if isinstance(actual_num, str) or isinstance(expected_num, str):
            if operator == ">":
                return actual_str > expected
            if operator == "<":
                return actual_str < expected
            if operator == ">=":
                return actual_str >= expected
            return actual_str <= expected
        if operator == ">":
            return actual_num > expected_num
        if operator == "<":
            return actual_num < expected_num
        if operator == ">=":
            return actual_num >= expected_num
        return actual_num <= expected_num

    return False


def evaluate_condition(
    group: ConditionGroup,
    args: dict[str, Any] | None = None,
    caller: Any | None = None,
    session: Any | None = None,
) -> bool:
    """Evaluate a parsed condition group left-to-right."""
    effective_args = args or {}
    if not group.conditions:
        return False

    result = _evaluate_single(group.conditions[0], effective_args, caller, session)
    for index, combinator in enumerate(group.combinators):
        next_result = _evaluate_single(group.conditions[index + 1], effective_args, caller, session)
        result = result and next_result if combinator == "AND" else result or next_result
    return result
