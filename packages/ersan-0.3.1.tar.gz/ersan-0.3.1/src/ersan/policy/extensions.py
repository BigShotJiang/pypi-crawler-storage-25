# ersan — your office. your rules. your AI. ...and you, amplified.
# Copyright 2026 Ersan Bilik
# SPDX-License-Identifier: Apache-2.0
"""Extension Protocols for future policy integrations.

No source precedent — D-017 §genuinely-new-concerns founder-approved
2026-04-19 via issue #36 body, because v0.3 documents the future extension
contracts explicitly instead of leaving them as `Any`-typed fields.
"""

from __future__ import annotations

from typing import Any, Protocol, runtime_checkable

from ersan.policy.audit import AuditLoggerProtocol  # noqa: F401
from ersan.policy.policy import Policy
from ersan.policy.types import CallerContext, SessionContext


@runtime_checkable
class PolicyResolverProtocol(Protocol):
    """Resolve a `Policy` from a per-caller context.

    Mirrors the shape of `ersan_ai_policy/core/policy.py:PolicyResolver`.
    """

    def resolve(self, ctx: Any) -> Policy:
        """Return the effective policy for this caller context."""
        ...


@runtime_checkable
class TrustMatrixProtocol(Protocol):
    """Evaluate `(caller, tool, base_tier) -> behavior level`.

    Mirrors the shape of `ersan_ai_policy/core/trust.py:TrustMatrix.evaluate`.
    """

    def evaluate(
        self,
        caller: Any,
        tool_name: str,
        base_tier: str,
    ) -> Any:
        """Return the effective behavior level for this caller and tool."""
        ...


@runtime_checkable
class DLPProtocol(Protocol):
    """Provider-specific sensitivity-label resolution.

    Mirrors `ersan_ai_policy/core/dlp.py:DLPProvider`.
    """

    async def list_labels(self) -> list[Any]:
        """Fetch all available sensitivity labels from the provider."""
        ...

    async def get_content_label(
        self,
        content_type: str,
        content_id: str,
    ) -> Any | None:
        """Fetch the sensitivity label for a specific content item."""
        ...


@runtime_checkable
class SandboxProtocol(Protocol):
    """Data-flow sandbox elevation hook.

    Mirrors the field-shape of `office_agent/capabilities/policy.py`
    `PolicyCapability.sandbox`.
    """

    def elevate(
        self,
        tool: str,
        args: dict[str, Any],
        caller: CallerContext | None,
        session: SessionContext | None,
    ) -> str | None:
        """Return an elevated tier string, or `None` to leave it unchanged."""
        ...


@runtime_checkable
class HooksPipelineProtocol(Protocol):
    """Pre-tool and post-tool hook chain.

    Mirrors the field-shape of `office_agent/capabilities/policy.py`
    `PolicyCapability.hooks_pipeline`.
    """

    async def run_pre(
        self,
        tool: str,
        args: dict[str, Any],
        caller: CallerContext | None,
        session: SessionContext | None,
    ) -> None:
        """Run all pre-tool hooks, raising to abort the tool call."""
        ...

    async def run_post(
        self,
        tool: str,
        args: dict[str, Any],
        result: Any,
        caller: CallerContext | None,
        session: SessionContext | None,
    ) -> None:
        """Run all post-tool hooks after the tool call finishes."""
        ...
