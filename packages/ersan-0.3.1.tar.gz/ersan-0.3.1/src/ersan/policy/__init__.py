# ersan — your office. your rules. your AI. ...and you, amplified.
# Copyright 2026 Ersan Bilik
# SPDX-License-Identifier: Apache-2.0
"""Public policy API for ersan.

Slim re-export surface patterned after `ersan_ai_policy/__init__.py`, cut to
the retail modules shipped in US-005. The extensions Protocols remain an
explicit-import surface under `ersan.policy.extensions`.
"""

from __future__ import annotations

from ersan.policy.audit import AuditLoggerProtocol, JSONLinesAuditLogger
from ersan.policy.conditions import (
    Condition,
    ConditionGroup,
    ConditionParseError,
    evaluate_condition,
    parse_condition,
)
from ersan.policy.config import load_default_policy
from ersan.policy.engine import PolicyConfirmRequired, PolicyDenied, PolicyEngine
from ersan.policy.policy import (
    TIERS,
    Policy,
    build_args_summary,
    check_blocked,
    check_blocked_recursive,
    get_tier,
    has_conditional_rules,
    load_policy,
)
from ersan.policy.types import (
    DEFAULT_TIER,
    TIER_RANK,
    TIER_TO_ACTION,
    Action,
    AuditEntry,
    CallerContext,
    ConditionalRule,
    Decision,
    SessionContext,
    Tier,
    ToolPolicy,
)

__all__ = [
    "DEFAULT_TIER",
    "TIERS",
    "TIER_RANK",
    "TIER_TO_ACTION",
    "Action",
    "AuditEntry",
    "AuditLoggerProtocol",
    "CallerContext",
    "Condition",
    "ConditionGroup",
    "ConditionParseError",
    "ConditionalRule",
    "Decision",
    "JSONLinesAuditLogger",
    "Policy",
    "PolicyConfirmRequired",
    "PolicyDenied",
    "PolicyEngine",
    "SessionContext",
    "Tier",
    "ToolPolicy",
    "build_args_summary",
    "check_blocked",
    "check_blocked_recursive",
    "evaluate_condition",
    "get_tier",
    "has_conditional_rules",
    "load_default_policy",
    "load_policy",
    "parse_condition",
]
