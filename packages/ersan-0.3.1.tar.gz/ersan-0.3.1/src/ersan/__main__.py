# ersan — your office. your rules. your AI. ...and you, amplified.
# Copyright 2026 Ersan Bilik
# SPDX-License-Identifier: Apache-2.0
"""Module entrypoint for `python -m ersan`."""

from __future__ import annotations

import sys

from ersan import BANNER, __version__


def main() -> None:
    """Print the startup banner and current package version."""
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    print(BANNER)
    print(__version__)


if __name__ == "__main__":
    main()
