# ersan — your office. your rules. your AI. ...and you, amplified.
# Copyright 2026 Ersan Bilik
# SPDX-License-Identifier: Apache-2.0
"""ersan plugins root — actual plugin packages drop their modules under here.

Each plugin is a subdirectory containing one `.py` file per skill plus a
package `__init__.py`. The skill loader (`ersan.core.skills.loader`)
walks this tree at startup, validates each module's `MANIFEST` and
`handler`, and exposes the discovered skills via `discover_skills(...)`.

US-002 ships the loader; real plugins land with US-007 onwards.
"""

from __future__ import annotations
