# ersan — your office. your rules. your AI. ...and you, amplified.
# Copyright 2026 Ersan Bilik
# SPDX-License-Identifier: Apache-2.0
"""Provider metadata schema for ersan model providers.

Ported from `office_agent/providers/spec.py` (v0.2.0 slim).
See `.specify/specs/US-003/spec.md` §SP-1 for the field-cut justification.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

Backend = Literal["openai_compat", "anthropic"]
"""The v0.2.0 backend set ported from the source provider registry."""


@dataclass(frozen=True)
class ProviderSpec:
    """Declarative metadata for one model provider.

    Fields:
        name: Canonical config field name, such as ``"ollama"``.
        display_name: Human-readable provider label.
        backend: Dispatch key selecting the backend factory.
        default_api_base: Default base URL for OpenAI-compatible backends.
        env_key: Primary environment variable holding the API key.
        is_local: Whether the provider is local-first metadata.
        supports_prompt_caching: Whether the provider supports prompt caching.
    """

    name: str
    display_name: str = ""
    backend: Backend = "openai_compat"
    default_api_base: str = ""
    env_key: str = ""
    is_local: bool = False
    supports_prompt_caching: bool = False

    @property
    def label(self) -> str:
        """Return the display name, falling back to a title-cased name."""
        return self.display_name or self.name.replace("_", " ").title()
