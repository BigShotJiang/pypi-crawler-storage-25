# ersan — your office. your rules. your AI. ...and you, amplified.
# Copyright 2026 Ersan Bilik
# SPDX-License-Identifier: Apache-2.0
"""Model-provider public API for ersan.

Ported from `office_agent/providers/__init__.py` (v0.2.0 slim).
This re-exports the source-shaped provider surface from the local package.
"""

from __future__ import annotations

from ersan.providers.backends import BACKEND_DISPATCH, dispatch
from ersan.providers.config import LLMConfig, load_llm_config
from ersan.providers.registry import PROVIDERS, find_by_name, spec_names
from ersan.providers.spec import Backend, ProviderSpec

__all__ = [
    "BACKEND_DISPATCH",
    "PROVIDERS",
    "Backend",
    "LLMConfig",
    "ProviderSpec",
    "dispatch",
    "find_by_name",
    "load_llm_config",
    "spec_names",
]
