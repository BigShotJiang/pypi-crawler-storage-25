# ersan — your office. your rules. your AI. ...and you, amplified.
# Copyright 2026 Ersan Bilik
# SPDX-License-Identifier: Apache-2.0
"""Provider configuration loader for ersan.

Ported from `office_agent/config.py` (LLMConfig only, v0.2.0 slim).
This keeps the source dataclass shape while limiting env interpolation to the
`api_key` field per `.specify/specs/US-003/spec.md` §SP-6 and OQ-4.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

import yaml

_ENV_PATTERN = "${"


@dataclass
class LLMConfig:
    """Typed config for the `llm:` block in `~/.ersan/config.yaml`."""

    model: str = ""
    base_url: str = ""
    provider: str = ""
    api_key: str = ""


def _interpolate_env(value: str) -> str:
    """Resolve a `${VAR}` API-key reference, or pass literals through."""
    if not (value.startswith("${") and value.endswith("}")):
        return value
    env_name = value[2:-1]
    resolved = os.environ.get(env_name)
    if resolved is None:
        raise ValueError(f"api_key references missing env var: {env_name}")
    return resolved


def load_llm_config(path: Path | None = None) -> LLMConfig:
    """Load the `llm:` block from `~/.ersan/config.yaml` into `LLMConfig`."""
    config_path = path if path is not None else Path.home() / ".ersan" / "config.yaml"
    if not config_path.is_file():
        return LLMConfig()

    raw = yaml.safe_load(config_path.read_text(encoding="utf-8")) or {}
    if not isinstance(raw, dict):
        return LLMConfig()

    llm_block = raw.get("llm", {})
    if not isinstance(llm_block, dict):
        return LLMConfig()

    fields = {field_name: llm_block.get(field_name, "") for field_name in LLMConfig.__annotations__}
    typed_fields: dict[str, str] = {}
    for key, value in fields.items():
        typed_fields[key] = value if isinstance(value, str) else ""

    api_key = typed_fields["api_key"]
    if _ENV_PATTERN in api_key:
        typed_fields["api_key"] = _interpolate_env(api_key)

    return LLMConfig(**typed_fields)
