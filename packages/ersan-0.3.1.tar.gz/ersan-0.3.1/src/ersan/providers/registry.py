# ersan — your office. your rules. your AI. ...and you, amplified.
# Copyright 2026 Ersan Bilik
# SPDX-License-Identifier: Apache-2.0
"""Provider registry for ersan model providers.

Ported from `office_agent/providers/registry.py` (v0.2.0 slim).
This keeps the source tuple-and-resolver shape while limiting the shipped set
to Ollama and Anthropic.
"""

from __future__ import annotations

from ersan.providers.spec import ProviderSpec

PROVIDERS: tuple[ProviderSpec, ...] = (
    ProviderSpec(
        name="anthropic",
        display_name="Anthropic",
        backend="anthropic",
        env_key="ANTHROPIC_API_KEY",
        supports_prompt_caching=True,
    ),
    ProviderSpec(
        name="ollama",
        display_name="Ollama",
        backend="openai_compat",
        default_api_base="http://localhost:11434/v1",
        is_local=True,
    ),
)
"""The v0.2.0 provider registry, ported as a module-level tuple."""

_ALIASES: dict[str, str] = {}
"""Source-shaped alias map, intentionally empty at v0.2.0."""


def find_by_name(name: str | None) -> ProviderSpec | None:
    """Return the provider spec matching ``name``, or ``None`` on miss."""
    if not name:
        return None
    canonical = _ALIASES.get(name, name)
    canonical = canonical.replace("-", "_").lower()
    canonical = _ALIASES.get(canonical, canonical)
    for spec in PROVIDERS:
        if spec.name == canonical:
            return spec
    return None


def spec_names() -> list[str]:
    """Return the canonical provider names for diagnostics."""
    return [spec.name for spec in PROVIDERS]
