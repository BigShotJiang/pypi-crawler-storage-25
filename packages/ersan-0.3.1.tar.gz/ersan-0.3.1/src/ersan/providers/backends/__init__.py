# ersan — your office. your rules. your AI. ...and you, amplified.
# Copyright 2026 Ersan Bilik
# SPDX-License-Identifier: Apache-2.0
"""Backend dispatch for ersan model providers.

Ported from `office_agent/providers/backends/__init__.py` (v0.2.0 slim).
Only the OpenAI-compatible and Anthropic backends ship in this cut.
"""

from __future__ import annotations

from typing import Any

from ersan.providers.backends import anthropic, openai_compat
from ersan.providers.spec import ProviderSpec

BACKEND_DISPATCH: dict[str, Any] = {
    "openai_compat": openai_compat.create_model,
    "anthropic": anthropic.create_model,
}
"""Dispatch table keyed by `ProviderSpec.backend`."""


def dispatch(
    spec: ProviderSpec,
    model_name: str,
    model_cfg: dict[str, Any],
    login_manager: Any | None,
) -> Any:
    """Resolve ``spec.backend`` to a factory and return the model object."""
    factory = BACKEND_DISPATCH.get(spec.backend)
    if factory is None:
        raise ValueError(
            f"Unknown backend {spec.backend!r} for provider {spec.name!r}. "
            f"Registered backends: {sorted(BACKEND_DISPATCH)}"
        )
    return factory(spec, model_name, model_cfg, login_manager)


__all__ = ["BACKEND_DISPATCH", "dispatch"]
