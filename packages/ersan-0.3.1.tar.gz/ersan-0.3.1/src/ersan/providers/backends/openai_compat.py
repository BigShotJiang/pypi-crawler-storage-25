# ersan — your office. your rules. your AI. ...and you, amplified.
# Copyright 2026 Ersan Bilik
# SPDX-License-Identifier: Apache-2.0
"""OpenAI-compatible backend for ersan model providers.

Ported from `office_agent/providers/backends/openai_compat.py` (v0.2.0 slim).
This preserves the source factory signature and base-url resolution order.
"""

from __future__ import annotations

from typing import Any

from pydantic_ai.models.openai import OpenAIChatModel
from pydantic_ai.providers.openai import OpenAIProvider

from ersan.providers.spec import ProviderSpec


def create_model(
    spec: ProviderSpec,
    model_name: str,
    model_cfg: dict[str, Any],
    login_manager: Any | None,
) -> Any:
    """Create an `OpenAIChatModel` for an OpenAI-compatible provider."""
    del login_manager

    base_url = model_cfg.get("base_url") or spec.default_api_base or None
    api_key = model_cfg.get("api_key")
    if not base_url and not api_key:
        return OpenAIChatModel(model_name)

    kwargs: dict[str, Any] = {}
    if base_url:
        kwargs["base_url"] = base_url
    if api_key:
        kwargs["api_key"] = api_key
    return OpenAIChatModel(model_name, provider=OpenAIProvider(**kwargs))
