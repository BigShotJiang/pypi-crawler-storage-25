# ersan — your office. your rules. your AI. ...and you, amplified.
# Copyright 2026 Ersan Bilik
# SPDX-License-Identifier: Apache-2.0
"""Anthropic backend for ersan model providers.

Ported from `office_agent/providers/backends/anthropic.py` (v0.2.0 slim).
The LoginManager and Claude-credentials branches are intentionally deferred.
"""

from __future__ import annotations

from typing import Any

from pydantic_ai.models.anthropic import AnthropicModel
from pydantic_ai.providers.anthropic import AnthropicProvider

from ersan.providers.spec import ProviderSpec

_BETA_HEADERS = "redact-thinking-2026-02-12,prompt-caching-scope-2026-01-05"
"""Anthropic beta headers preserved from the source backend."""


def _resolve_key(api_key: str | None, login_manager: Any | None) -> str | None:
    """Resolve the Anthropic API key for the v0.2.0 cut."""
    del login_manager
    if api_key:
        return api_key
    return None


def create_model(
    spec: ProviderSpec,
    model_name: str,
    model_cfg: dict[str, Any],
    login_manager: Any | None,
) -> Any:
    """Create an `AnthropicModel` with the source beta-header behavior."""
    del spec

    key = _resolve_key(model_cfg.get("api_key"), login_manager)
    if not key:
        return AnthropicModel(model_name)

    from anthropic import AsyncAnthropic

    client = AsyncAnthropic(
        api_key=key,
        max_retries=5,
        default_headers={"anthropic-beta": _BETA_HEADERS},
    )
    return AnthropicModel(model_name, provider=AnthropicProvider(anthropic_client=client))
