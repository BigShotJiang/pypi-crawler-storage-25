# Contributing to ersan

ersan is built issue-by-issue. The public repo is the working surface; the contributor workflow is self-contained here even when longer-form founder notes also exist elsewhere.

## Prerequisites

- Python 3.10 or newer
- `uv`
- `git`

## Local setup

```bash
uv sync
uv tool install pre-commit
pre-commit install --hook-type pre-commit --hook-type commit-msg
```

Run the local quality loop from the repo root (the `uv run` prefix matches
how CI executes; bare `pytest` will fail at collection because the test
suite is imported via the editable install that `uv sync` produced):

```bash
uv run ruff format --check .
uv run ruff check .
uv run mypy --strict src/
uv run pytest
uv build
```

## Development cycle

ersan uses a single-issue baton with one active `phase:*` label at a time.

| Phase | Meaning | Default owner |
|---|---|---|
| `phase:backlog` | Story drafted, not ready | founder |
| `phase:ready` | Acceptance criteria locked | founder |
| `phase:specify` | Spec being written | Claude |
| `phase:plan` | Implementation plan being written | Claude |
| `phase:tasks` | Task list being decomposed | Codex |
| `phase:implement` | Code and tests being written | Codex |
| `phase:review` | Cross-CLI review | Claude |
| `phase:merge` | Waiting for founder merge | founder |
| `phase:doc-sweep` | Merged + version cut; awaiting docs-sweep per D-013 | founder |
| `phase:done` | Merged + version cut + doc-sweep complete (per D-013); issue auto-closes | none |

Cycle rules:

- Exactly one `phase:*` label is valid on an issue at any time.
- The current assignee is the person or agent acting now.
- One feature maps to one branch and one worktree.
- Cross-CLI review is mandatory before merge.
- Founder merge authority is final.
- After merge, the issue moves to `phase:doc-sweep` until the founder verifies that README, roadmap, and other version-aware docs reflect what shipped (per the **Document Integrity Invariants** in `CONSTITUTION.md`); only then does the label move to `phase:done`.

## Cross-CLI review

Claude writes `spec.md` and `plan.md`, Codex writes `tasks.md` and the implementation, and Claude performs the review. Reviewers must re-read the acceptance criteria and apply the red-team prompt captured in `AGENTS.md` and `CLAUDE.md`; reading only the diff is not enough.

## Conventional commits

Every commit in a PR must follow Conventional Commits. Common examples:

- `feat: add package scaffolding`
- `fix: correct release workflow permissions`
- `docs: inline the contribution flow`
- `test: cover python -m ersan startup`
- `chore: refresh tooling metadata`

Commits are checked locally through `pre-commit` and again in CI.

## DCO sign-off

All commits must carry a `Signed-off-by:` trailer. Use:

```bash
git commit -s -m "feat: describe the change"
```

If the sign-off is missing, the commit-msg hook and CI checks will block the change.

## Working agreements

- Keep the wordmark as `ersan`, lowercase.
- Do not add telemetry, MCP server code, or an `ee/` split.
- Keep changes inside the scope of the active issue.
- Use `pathlib.Path`, typed public APIs, Google-style docstrings, and `structlog` for logging when those concerns appear in a story.

## Eval harness

ersan's CI gates every PR with a behavioural eval harness. Skill PRs cannot silently regress agent quality — if the aggregate pass rate drops below the configured threshold (default `0.95`), CI fails and the merge is blocked.

To add a new fixture you write three small JSON files under `evals/fixtures/`. No Python edit required. See [`docs/eval-harness.md`](docs/eval-harness.md) for the full reference (how to add a fixture, supported scorers, exit codes, the privacy invariant, how CI runs the harness).

## Writing a skill

ersan's capabilities load as **skills** organised into **plugins** (Constitution §II). To add a new capability, drop a Python module under `src/ersan/skills/<plugin>/<skill_name>.py` exposing a top-level `MANIFEST` dict and a top-level `handler` callable. The skill loader (`ersan.core.skills.loader`) discovers it at startup and routes invocations through `ersan.policy` (trust tiers) and `ersan.shield` (PII/credential redaction) before output reaches the user. As of v0.3.0 those are real default gates, not stub callables: a new skill is denied by the packaged `ask_first` policy until a caller passes an explicit override or `~/.ersan/policy.yaml` allows it.

See [`docs/skills.md`](docs/skills.md) for the full reference (manifest format, handler signature, trust-tier guidance, validation order, the privacy invariant, and a working "write your first skill" example).

## Security

Report security issues through the process documented in `SECURITY.md`. Do not open public issues for undisclosed vulnerabilities.

## License

ersan is Apache 2.0 licensed. Contributions are accepted under Apache 2.0 with DCO sign-off; there is no CLA in v0.1.0.

## Canonical source note

This file is the canonical, self-contained guide for contributors to the
ersan public repository. Treat it as authoritative for cycle, conventions,
and contributor obligations.
