# Governance

## Model

ersan uses a BDFL model.

- Ersan Bilik (`@bilersan`) is the founder and sole merge authority.
- Branch protection, constitution amendments, and architectural decision records are founder-controlled.
- AI agents participate in delivery, but they do not override founder decisions.

## Current operating shape

Today the project is run by one founder coordinating agent contributors through the issue-based workflow documented in `AGENTS.md` and `CONTRIBUTING.md`.

## Successor mechanism

If the founder can no longer serve as BDFL, the top three lifetime contributors elect the next BDFL.

## Review and merge authority

- All changes land through pull requests.
- Cross-CLI review is required before a PR moves to merge readiness.
- Only the founder performs the final merge to `main`.
