# Conventions

## Python conventions

- Sort imports with Ruff's `I` rules.
- Add Google-style docstrings to public modules, functions, and classes.
- Keep all public APIs fully typed.
- Route logging through `structlog`; do not use `print` or stdlib `logging` for application logging.
- Build filesystem paths with `pathlib.Path`, never string concatenation.
- Keep shared constants in `ersan/constants.py` and typed exceptions in `ersan/errors.py` when those modules are introduced by later stories.

## Package and naming conventions

- The wordmark is `ersan`, lowercase.
- The Python package is `ersan`.
- CLI command names should remain `ersan`.
- Environment variables use the `ERSAN_` prefix.

## Slim SPDX header

Every Python source file must start with this header:

```python
# ersan — your office. your rules. your AI. ...and you, amplified.
# Copyright 2026 Ersan Bilik
# SPDX-License-Identifier: Apache-2.0
```

Do not replace this with a larger license banner.

## Testing conventions

- Register and use the `unit`, `integration`, `platform`, and `functional` pytest markers.
- Prefer behavior-oriented tests over coverage chasing.
- Use `tests/unit/`, `tests/integration/`, `tests/platform/`, and `tests/functional/` as the natural directory layout when those suites are added.

## Commit conventions

- Use Conventional Commits for every commit.
- Add DCO sign-off to every commit with `git commit -s`.
- Keep each PR scoped to one GitHub issue and its acceptance criteria.
