# ersan — your office. your rules. your AI. ...and you, amplified.
# Copyright 2026 Ersan Bilik
# SPDX-License-Identifier: Apache-2.0
"""Unit tests for `ersan.policy.audit`."""

from __future__ import annotations

import json
import os
import time
from pathlib import Path

import pytest

from ersan.policy.audit import AuditLoggerProtocol, JSONLinesAuditLogger

_SCRATCH_DIR = Path(__file__).resolve().parents[2] / ".tmp-policy-audit-tests"
_SCRATCH_DIR.mkdir(exist_ok=True)


def _fresh_log_path(prefix: str) -> Path:
    """Return a unique log path without relying on delete-on-cleanup."""
    return _SCRATCH_DIR / f"{prefix}-{time.monotonic_ns()}.log"


class _MemoryAuditLogger:
    def log(
        self,
        tool_name: str,
        args_summary: str,
        decision: str,
        user: str = "",
        reason: str = "",
    ) -> None:
        self.last = (tool_name, args_summary, decision, user, reason)


@pytest.mark.unit
def test_audit_logger_protocol_is_runtime_checkable() -> None:
    """The logger contract can be checked with `isinstance`."""
    assert isinstance(_MemoryAuditLogger(), AuditLoggerProtocol)


@pytest.mark.unit
def test_json_lines_audit_logger_appends_utf8_json_lines() -> None:
    """One log call appends one JSON object line with the expected fields."""
    path = _fresh_log_path("append")
    logger = JSONLinesAuditLogger(path)
    logger.log("inbox.list_unread", "limit='5'", "silent", user="ersan", reason="tier=do_it")

    payload = path.read_text(encoding="utf-8").strip().splitlines()
    assert len(payload) == 1
    entry = json.loads(payload[0])
    assert entry["tool"] == "inbox.list_unread"
    assert entry["args_summary"] == "limit='5'"
    assert entry["decision"] == "silent"
    assert entry["user"] == "ersan"
    assert entry["reason"] == "tier=do_it"
    assert "timestamp" in entry


@pytest.mark.unit
def test_json_lines_audit_logger_rotates_when_max_size_exceeded(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Rotation calls `os.replace` with the source-shaped `.1` target."""
    path = _fresh_log_path("rotate")
    logger = JSONLinesAuditLogger(path, max_size_bytes=1)
    logger.log("first.tool", "summary", "silent")

    calls: list[tuple[Path, Path]] = []

    def _fake_replace(src: os.PathLike[str], dst: os.PathLike[str]) -> None:
        calls.append((Path(src), Path(dst)))

    monkeypatch.setattr(os, "replace", _fake_replace)
    logger.log("second.tool", "summary", "blocked")

    assert calls == [(path, Path(str(path) + ".1"))]
