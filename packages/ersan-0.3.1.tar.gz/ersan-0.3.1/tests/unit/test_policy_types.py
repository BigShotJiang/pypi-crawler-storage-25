# ersan — your office. your rules. your AI. ...and you, amplified.
# Copyright 2026 Ersan Bilik
# SPDX-License-Identifier: Apache-2.0
"""Unit tests for `ersan.policy.types`."""

from __future__ import annotations

from dataclasses import FrozenInstanceError, fields

import pytest

from ersan.policy.types import (
    DEFAULT_TIER,
    TIER_RANK,
    TIER_TO_ACTION,
    Action,
    AuditEntry,
    CallerContext,
    ConditionalRule,
    Decision,
    SessionContext,
    Tier,
    ToolPolicy,
)


@pytest.mark.unit
def test_tier_and_action_round_trip_from_values() -> None:
    """The port preserves value-level enum construction."""
    assert Tier("do_it") is Tier.DO_IT
    assert Tier("ask_first") is Tier.ASK_FIRST
    assert Action("allow") is Action.ALLOW
    assert Action("deny") is Action.DENY


@pytest.mark.unit
def test_tier_to_action_and_rank_constants_match_source_shape() -> None:
    """Tier constants keep the source mappings and ordering."""
    assert TIER_TO_ACTION[Tier.DO_IT] is Action.ALLOW
    assert TIER_TO_ACTION[Tier.DO_AND_TELL] is Action.ALLOW_NOTIFY
    assert TIER_TO_ACTION[Tier.ASK_FIRST] is Action.CONFIRM
    assert TIER_TO_ACTION[Tier.LOG_ONLY] is Action.LOG_ONLY
    assert TIER_TO_ACTION[Tier.NEVER] is Action.DENY

    assert TIER_RANK["do_it"] < TIER_RANK["do_and_tell"] < TIER_RANK["ask_first"]
    assert TIER_RANK["ask_first"] < TIER_RANK["log_only"] < TIER_RANK["never"]
    assert DEFAULT_TIER == "ask_first"


@pytest.mark.unit
def test_decision_is_frozen() -> None:
    """The decision object is immutable once created."""
    decision = Decision(
        action=Action.ALLOW,
        tier=Tier.DO_IT,
        tool="inbox.list_unread",
        reason="allowed",
        audit_entry=AuditEntry(
            timestamp="2026-04-19T00:00:00+00:00",
            tool="inbox.list_unread",
            args_summary="",
            action="silent",
        ),
    )

    with pytest.raises(FrozenInstanceError):
        decision.reason = "changed"  # type: ignore[misc]


@pytest.mark.unit
def test_full_type_hierarchy_field_set_matches_contract() -> None:
    """The public dataclass field sets stay stable for future ports."""
    assert [field.name for field in fields(CallerContext)] == ["identity", "channel"]
    assert [field.name for field in fields(AuditEntry)] == [
        "timestamp",
        "tool",
        "args_summary",
        "action",
        "user",
        "reason",
        "policy_version",
    ]
    assert [field.name for field in fields(SessionContext)] == [
        "dlp_level",
        "session_tool_count",
        "tool_call_counts",
        "custom",
    ]
    assert [field.name for field in fields(ConditionalRule)] == [
        "when",
        "tier",
        "message",
        "parsed",
    ]
    assert [field.name for field in fields(ToolPolicy)] == ["rules", "default"]
    assert [field.name for field in fields(Decision)] == [
        "action",
        "tier",
        "tool",
        "reason",
        "audit_entry",
        "blocked_pattern",
        "matched_rule",
    ]
