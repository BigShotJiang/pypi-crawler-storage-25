# ersan — your office. your rules. your AI. ...and you, amplified.
# Copyright 2026 Ersan Bilik
# SPDX-License-Identifier: Apache-2.0
"""Unit tests for `ersan.shield.layers.regex`."""

from __future__ import annotations

import pytest

from ersan.shield.layers.regex import CREDENTIAL_PATTERNS, RegexScanner
from ersan.shield.types import ScanAction

_AWS_KEY = "AKIA" + "1234567890ABCDEF"  # pragma: allowlist secret
_GITHUB_PAT = "ghp_" + ("a" * 36)  # pragma: allowlist secret
_GITHUB_OAUTH = "gho_" + ("b" * 36)  # pragma: allowlist secret
_ANTHROPIC_KEY = "sk-ant-" + ("c" * 20)  # pragma: allowlist secret
_OPENAI_KEY = "sk-proj-" + ("d" * 20)  # pragma: allowlist secret
_BEARER = "Bearer eyJ" + ("e" * 20)  # pragma: allowlist secret
_JWT = "eyJ" + ("f" * 20) + ".eyJ" + ("g" * 20) + "." + ("h" * 20)  # pragma: allowlist secret
_BASE64_BLOB = "A" * 200  # pragma: allowlist secret
_DSN = "postgres://user:pass@example.com/dbname"  # pragma: allowlist secret


@pytest.mark.unit
@pytest.mark.parametrize(
    ("text", "subtype", "action"),
    [
        ("api_key=ABCDEFGHIJKL12345", "api_key", ScanAction.BLOCK),  # pragma: allowlist secret
        (_ANTHROPIC_KEY, "anthropic_key", ScanAction.BLOCK),
        (_OPENAI_KEY, "openai_key", ScanAction.BLOCK),
        (_AWS_KEY, "aws_key", ScanAction.BLOCK),
        (_GITHUB_PAT, "github_token", ScanAction.BLOCK),
        (_GITHUB_OAUTH, "github_oauth", ScanAction.BLOCK),
        ("password=supersecret", "password", ScanAction.BLOCK),
        ("secret_key=supersecret", "secret", ScanAction.BLOCK),
        (_BEARER, "bearer_token", ScanAction.BLOCK),
        (_JWT, "jwt", ScanAction.BLOCK),
        (_DSN, "connection_string", ScanAction.BLOCK),
        (_BASE64_BLOB, "base64_blob", ScanAction.WARN),
    ],
)
def test_regex_scanner_matches_built_in_patterns(
    text: str,
    subtype: str,
    action: ScanAction,
) -> None:
    """Each built-in pattern produces the expected subtype and action."""
    findings = RegexScanner().scan(text)
    assert any(finding.subtype == subtype and finding.action is action for finding in findings)


@pytest.mark.unit
def test_regex_scanner_ignores_harmless_text() -> None:
    """Non-secret text should not produce findings."""
    assert RegexScanner().scan("normal summary text with no credentials") == []


@pytest.mark.unit
def test_regex_scanner_supports_custom_patterns() -> None:
    """Custom patterns use the documented action mapping."""
    scanner = RegexScanner(
        extra_patterns=[
            {
                "pattern": r"alice@example.com",
                "name": "email_address",
                "action": "redact",
                "message": "Email detected",
            }
        ]
    )
    findings = scanner.scan("Contact alice@example.com", field="body")
    assert len(findings) == 1
    assert findings[0].subtype == "email_address"
    assert findings[0].action is ScanAction.REDACT
    assert findings[0].field == "body"
    assert len(CREDENTIAL_PATTERNS) == 12
