# ersan — your office. your rules. your AI. ...and you, amplified.
# Copyright 2026 Ersan Bilik
# SPDX-License-Identifier: Apache-2.0
"""Unit tests for `ersan.policy.engine`."""

from __future__ import annotations

import asyncio
from dataclasses import dataclass, field

import pytest

from ersan.policy.conditions import parse_condition
from ersan.policy.engine import (
    PolicyConfirmRequired,
    PolicyDenied,
    PolicyEngine,
    _raise_on_deny,
)
from ersan.policy.policy import Policy
from ersan.policy.types import (
    Action,
    CallerContext,
    ConditionalRule,
    SessionContext,
    ToolPolicy,
)


@dataclass
class _SpyAuditLogger:
    calls: list[tuple[str, str, str, str, str]] = field(default_factory=list)

    def log(
        self,
        tool_name: str,
        args_summary: str,
        decision: str,
        user: str = "",
        reason: str = "",
    ) -> None:
        self.calls.append((tool_name, args_summary, decision, user, reason))


@pytest.mark.unit
def test_policy_engine_evaluate_maps_simple_tier_to_action() -> None:
    """Simple tool tiers map to the expected decision action."""
    policy = Policy(tool_tiers={"inbox.list_unread": "do_it"})
    decision = PolicyEngine(policy).evaluate("inbox.list_unread", {"limit": 5})
    assert decision.action is Action.ALLOW
    assert decision.tier.value == "do_it"
    assert decision.tool == "inbox.list_unread"


@pytest.mark.unit
def test_policy_engine_evaluate_uses_conditional_rule_when_matched() -> None:
    """Conditional rules override the tool default when they match."""
    policy = Policy(
        tool_policies={
            "inbox.reply": ToolPolicy(
                default="ask_first",
                rules=[
                    ConditionalRule(
                        when="caller_channel == repl",
                        tier="do_it",
                        parsed=parse_condition("caller_channel == repl"),
                    )
                ],
            )
        }
    )
    decision = PolicyEngine(policy).evaluate(
        "inbox.reply",
        args={},
        caller=CallerContext(channel="repl"),
        session=SessionContext(),
    )
    assert decision.action is Action.ALLOW
    assert decision.matched_rule == "caller_channel == repl"
    assert "rule matched" in decision.reason


@pytest.mark.unit
def test_policy_engine_evaluate_blocks_matching_argument_pattern() -> None:
    """Blocked patterns short-circuit tier resolution."""
    import re

    policy = Policy(tool_tiers={"inbox.reply": "do_it"})
    policy.blocked_patterns.append(re.compile("secret", re.IGNORECASE))
    decision = PolicyEngine(policy).evaluate("inbox.reply", {"body": "contains secret"})
    assert decision.action is Action.DENY
    assert decision.blocked_pattern == "secret"
    assert decision.tier.value == "never"


@pytest.mark.unit
def test_policy_engine_logs_decisions_when_audit_logger_is_present() -> None:
    """The engine emits one audit call per evaluation."""
    logger = _SpyAuditLogger()
    policy = Policy(tool_tiers={"inbox.list_unread": "do_and_tell"})
    PolicyEngine(policy, audit_logger=logger).evaluate(
        "inbox.list_unread",
        {"limit": 5},
        caller=CallerContext(identity="ersan"),
    )
    assert logger.calls == [
        (
            "inbox.list_unread",
            "limit='5'",
            "auto_approved",
            "ersan",
            "tier=do_and_tell, action=allow_notify",
        )
    ]


@pytest.mark.unit
def test_raise_on_deny_raises_specific_exceptions() -> None:
    """DENY and CONFIRM actions surface the dedicated exception types."""
    deny_decision = PolicyEngine(Policy(tool_tiers={"tool": "never"})).evaluate("tool", {})
    confirm_decision = PolicyEngine(Policy(tool_tiers={"tool": "ask_first"})).evaluate("tool", {})
    log_only_decision = PolicyEngine(Policy(tool_tiers={"tool": "log_only"})).evaluate("tool", {})

    with pytest.raises(PolicyDenied):
        _raise_on_deny(deny_decision)
    with pytest.raises(PolicyConfirmRequired):
        _raise_on_deny(confirm_decision)
    with pytest.raises(PolicyDenied):
        _raise_on_deny(log_only_decision)


@pytest.mark.unit
def test_enforce_decorator_wraps_async_function() -> None:
    """Async handlers stay async and honor the policy gate."""
    engine = PolicyEngine(Policy(tool_tiers={"inbox.reply": "do_it"}))

    @engine.enforce("inbox.reply")
    async def _send_reply(*, body: str) -> str:
        return body.upper()

    assert asyncio.run(_send_reply(body="ok")) == "OK"


@pytest.mark.unit
def test_enforce_decorator_wraps_sync_function() -> None:
    """Sync handlers are wrapped with the same enforcement path."""
    engine = PolicyEngine(Policy(tool_tiers={"inbox.reply": "do_it"}))

    @engine.enforce("inbox.reply")
    def _send_reply(*, body: str) -> str:
        return body.upper()

    assert _send_reply(body="ok") == "OK"
