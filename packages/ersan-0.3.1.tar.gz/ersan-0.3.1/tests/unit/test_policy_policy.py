# ersan — your office. your rules. your AI. ...and you, amplified.
# Copyright 2026 Ersan Bilik
# SPDX-License-Identifier: Apache-2.0
"""Unit tests for `ersan.policy.policy`."""

from __future__ import annotations

from pathlib import Path
from textwrap import dedent

import pytest

from ersan.policy.policy import (
    Policy,
    build_args_summary,
    check_blocked,
    check_blocked_recursive,
    get_tier,
    has_conditional_rules,
    load_policy,
)
from ersan.policy.types import DEFAULT_TIER

_SCRATCH_DIR = Path(__file__).resolve().parents[2] / ".tmp-policy-tests"
_SCRATCH_DIR.mkdir(exist_ok=True)


def _write_policy_file(name: str, contents: str) -> Path:
    """Write policy YAML to a repo-local scratch file.

    The default `tmp_path` fixture hits ACL issues on this Windows worktree,
    so these tests use stable overwrite-only files under a writable repo
    directory instead.
    """
    path = _SCRATCH_DIR / f"{name}.yaml"
    path.write_text(contents, encoding="utf-8")
    return path


@pytest.mark.unit
def test_load_policy_parses_source_shaped_yaml() -> None:
    """The loader keeps the source defaults/tools YAML layout."""
    policy_path = _write_policy_file(
        "source-shaped",
        dedent(
            """
            defaults:
              tier: do_and_tell
            blocked_patterns:
              - secret
            tools:
              inbox.list_unread: do_it
              inbox.send:
                tier: ask_first
              inbox.reply:
                default: ask_first
                rules:
                  - when: "caller_channel == repl"
                    tier: do_it
                    message: "local repl"
            """
        ).strip()
        + "\n",
    )
    policy = load_policy(policy_path)
    assert policy.default_tier == "do_and_tell"
    assert policy.tool_tiers == {
        "inbox.list_unread": "do_it",
        "inbox.send": "ask_first",
    }
    assert has_conditional_rules(policy, "inbox.reply")
    assert policy.tool_policies["inbox.reply"].default == "ask_first"
    assert policy.tool_policies["inbox.reply"].rules[0].parsed is not None
    assert [pattern.pattern for pattern in policy.blocked_patterns] == ["secret"]


@pytest.mark.unit
def test_load_policy_missing_file_returns_defaults() -> None:
    """Absent policy files fail soft to retail defaults."""
    policy = load_policy("does-not-exist.yaml")
    assert policy == Policy(default_tier=DEFAULT_TIER)


@pytest.mark.unit
def test_get_tier_falls_back_to_tool_policy_default_and_global_default() -> None:
    """Tier lookup matches the source simple-tier and conditional-tier rules."""
    policy_path = _write_policy_file(
        "tier-fallback",
        dedent(
            """
            defaults:
              tier: ask_first
            tools:
              inbox.reply:
                default: do_and_tell
                rules:
                  - when: "caller_channel == repl"
                    tier: do_it
            """
        ).strip()
        + "\n",
    )
    policy = load_policy(policy_path)
    assert get_tier(policy, "inbox.reply") == "do_and_tell"
    assert get_tier(policy, "missing.tool") == "ask_first"


@pytest.mark.unit
def test_check_blocked_helpers_walk_nested_values() -> None:
    """Blocked-pattern helpers recurse through dicts and lists."""
    policy = Policy(blocked_patterns=[])
    policy.blocked_patterns.append(__import__("re").compile("secret", __import__("re").IGNORECASE))
    assert check_blocked(policy, "contains SECRET value") == "secret"
    assert (
        check_blocked_recursive(
            policy,
            {"outer": [{"inner": "safe"}, {"nested": "my secret token"}]},
        )
        == "secret"
    )


@pytest.mark.unit
def test_build_args_summary_truncates_long_values_and_total_length() -> None:
    """Audit summaries keep the source truncation behavior."""
    summary = build_args_summary(
        {
            "subject": "x" * 50,
            "body": "y" * 300,
        }
    )
    assert "subject='xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx" in summary
    assert "\u2026" in summary
    assert len(summary) <= 200
