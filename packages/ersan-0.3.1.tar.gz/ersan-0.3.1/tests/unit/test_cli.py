# ersan — your office. your rules. your AI. ...and you, amplified.
# Copyright 2026 Ersan Bilik
# SPDX-License-Identifier: Apache-2.0
"""Smoke tests for the package metadata and CLI entrypoint."""

from __future__ import annotations

import runpy
import sys
from contextlib import redirect_stdout
from io import StringIO

from ersan import BANNER, MOTTO, __version__


def test_python_module_entrypoint_prints_banner_and_version() -> None:
    """`python -m ersan` should print the banner and version and exit cleanly."""
    stdout = StringIO()
    original_argv = sys.argv[:]

    try:
        sys.argv = ["python", "-m", "ersan"]
        with redirect_stdout(stdout):
            runpy.run_module("ersan", run_name="__main__", alter_sys=True)
    finally:
        sys.argv = original_argv

    output = stdout.getvalue()
    assert BANNER in output
    assert __version__ in output


def test_banner_contains_motto() -> None:
    """The public banner constant should embed the canonical motto lines."""
    assert MOTTO.split(" ...and")[0] in BANNER
