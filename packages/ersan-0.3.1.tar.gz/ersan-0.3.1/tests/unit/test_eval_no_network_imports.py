# ersan — your office. your rules. your AI. ...and you, amplified.
# Copyright 2026 Ersan Bilik
# SPDX-License-Identifier: Apache-2.0
"""Privacy-invariant guard test for `evals/scorer.py` (US-001 / FR-F3).

The constitution's §I "Privacy by Default" is NON-NEGOTIABLE — the eval
scorer makes ZERO outbound network calls. Rather than rely on contributor
discipline, this test mechanically reads `evals/scorer.py` as text and
asserts that no HTTP-client substring appears anywhere in the file.

A future contributor (or a malicious fork) cannot accidentally introduce
a phone-home call without this test catching it on the next CI run.
"""

from __future__ import annotations

from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[2]
SCORER_PATH = REPO_ROOT / "evals" / "scorer.py"

FORBIDDEN_SUBSTRINGS: tuple[str, ...] = (
    "import requests",
    "import urllib",
    "import httpx",
    "import aiohttp",
    "from requests",
    "from urllib",
    "from httpx",
    "from aiohttp",
)


@pytest.mark.unit
def test_eval_scorer_has_no_outbound_network_imports() -> None:
    """FR-I1 / FR-F3: `evals/scorer.py` MUST NOT import HTTP clients.

    Any of `requests`, `urllib`, `httpx`, `aiohttp` (top-level OR `from`
    imports) is forbidden. The scorer is stdlib-only by design — if a
    real need ever arises, it goes through an ADR first, not a silent
    diff.
    """
    assert SCORER_PATH.is_file(), f"expected eval scorer at {SCORER_PATH}"
    source = SCORER_PATH.read_text(encoding="utf-8")
    offenders = [substr for substr in FORBIDDEN_SUBSTRINGS if substr in source]
    assert not offenders, (
        f"{SCORER_PATH.relative_to(REPO_ROOT)} contains forbidden network "
        f"import substring(s): {offenders}. The eval scorer MUST be "
        "stdlib-only (D-008, Constitution §I)."
    )
