# ersan — your office. your rules. your AI. ...and you, amplified.
# Copyright 2026 Ersan Bilik
# SPDX-License-Identifier: Apache-2.0
"""Unit tests for `ersan.providers.registry`."""

from __future__ import annotations

import pytest

from ersan.providers.registry import PROVIDERS, find_by_name, spec_names


@pytest.mark.unit
def test_providers_contains_ollama_with_local_defaults() -> None:
    """The registry includes the local-first Ollama entry from the spec."""
    ollama = find_by_name("ollama")
    assert ollama is not None
    assert ollama in PROVIDERS
    assert ollama.backend == "openai_compat"
    assert ollama.default_api_base == "http://localhost:11434/v1"
    assert ollama.is_local is True


@pytest.mark.unit
def test_providers_contains_anthropic() -> None:
    """The registry includes the Anthropic provider entry."""
    anthropic = find_by_name("anthropic")
    assert anthropic is not None
    assert anthropic in PROVIDERS
    assert anthropic.backend == "anthropic"
    assert anthropic.env_key == "ANTHROPIC_API_KEY"
    assert anthropic.supports_prompt_caching is True


@pytest.mark.unit
def test_find_by_name_resolves_known() -> None:
    """Known providers resolve by canonical name."""
    assert find_by_name("ollama") == PROVIDERS[1]
    assert find_by_name("anthropic") == PROVIDERS[0]


@pytest.mark.unit
def test_find_by_name_returns_none_for_unknown() -> None:
    """Unknown and empty names return `None`."""
    assert find_by_name("missing") is None
    assert find_by_name("") is None
    assert find_by_name(None) is None


@pytest.mark.unit
def test_find_by_name_normalises_case_and_hyphens() -> None:
    """Lookup lowercases and normalises hyphens to underscores."""
    assert find_by_name("OLLAMA") == find_by_name("ollama")
    assert find_by_name("anthropic") == find_by_name("AnThRoPiC")


@pytest.mark.unit
def test_spec_names_returns_canonical_names() -> None:
    """`spec_names()` returns the canonical provider names in registry order."""
    assert spec_names() == ["anthropic", "ollama"]
