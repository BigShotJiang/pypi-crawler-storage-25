# ersan — your office. your rules. your AI. ...and you, amplified.
# Copyright 2026 Ersan Bilik
# SPDX-License-Identifier: Apache-2.0
"""Regression tests for Codex cross-CLI review findings on US-001.

Codex (`codex exec`, GPT-5.x) reviewed PR #4 and surfaced four defects
where malformed fixture configurations could pass silently. Each test
below pins one of those behaviors so a future regression is loud:

- P1: unknown scorer names MUST raise (not be folded into pass-rate)
- P1: malformed `<id>.input.json` MUST fail the run (not be ignored)
- P2: orphan `.golden.json` / `.scorers.json` (no matching input) MUST raise
- P2: `bool` MUST NOT satisfy `"type": "number"` schemas (Python subclass quirk)

If any of these tests start failing, the scorer's config-validation
contract has regressed.
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest
from evals.scorer import (
    _discover_fixtures,
    run_all,
    run_fixture,
    valid_json_schema,
)

# ---------------------------------------------------------------------------
# Codex P1: unknown scorer names raise as config errors
# ---------------------------------------------------------------------------


@pytest.mark.unit
def test_run_fixture_raises_on_unknown_scorer_name(tmp_path: Path) -> None:
    """A fixture referencing an unknown scorer MUST raise ValueError."""
    fixture_id = "test-unknown-scorer"
    golden_path = tmp_path / f"{fixture_id}.golden.json"
    scorers_path = tmp_path / f"{fixture_id}.scorers.json"
    golden_path.write_text(json.dumps({"k": "v"}), encoding="utf-8")
    scorers_path.write_text(
        json.dumps([{"name": "totally_made_up_scorer", "params": {}}]),
        encoding="utf-8",
    )
    with pytest.raises(ValueError, match="unknown scorer"):
        run_fixture(fixture_id, golden_path, scorers_path)


# ---------------------------------------------------------------------------
# Codex P1: run_all parses every <id>.input.json and fails on malformed JSON
# ---------------------------------------------------------------------------


@pytest.mark.unit
def test_run_all_fails_on_malformed_input_json(tmp_path: Path) -> None:
    """Malformed `<id>.input.json` MUST surface as a ValueError from run_all."""
    fixture_id = "test-malformed-input"
    (tmp_path / f"{fixture_id}.input.json").write_text("not valid json{{{", encoding="utf-8")
    (tmp_path / f"{fixture_id}.golden.json").write_text(json.dumps({}), encoding="utf-8")
    (tmp_path / f"{fixture_id}.scorers.json").write_text(json.dumps([]), encoding="utf-8")
    with pytest.raises(ValueError, match="malformed JSON"):
        run_all(tmp_path, threshold=0.95)


# ---------------------------------------------------------------------------
# Codex P2: orphan companion files (golden / scorers without input) raise
# ---------------------------------------------------------------------------


@pytest.mark.unit
def test_discover_fixtures_rejects_orphan_golden(tmp_path: Path) -> None:
    """A `.golden.json` with no matching `.input.json` MUST raise."""
    (tmp_path / "valid-001.input.json").write_text(json.dumps({}), encoding="utf-8")
    (tmp_path / "valid-001.golden.json").write_text(json.dumps({}), encoding="utf-8")
    (tmp_path / "valid-001.scorers.json").write_text(json.dumps([]), encoding="utf-8")
    (tmp_path / "orphan-002.golden.json").write_text(json.dumps({}), encoding="utf-8")
    with pytest.raises(ValueError, match="orphan fixture"):
        _discover_fixtures(tmp_path)


@pytest.mark.unit
def test_discover_fixtures_rejects_orphan_scorers(tmp_path: Path) -> None:
    """A `.scorers.json` with no matching `.input.json` MUST raise."""
    (tmp_path / "valid-001.input.json").write_text(json.dumps({}), encoding="utf-8")
    (tmp_path / "valid-001.golden.json").write_text(json.dumps({}), encoding="utf-8")
    (tmp_path / "valid-001.scorers.json").write_text(json.dumps([]), encoding="utf-8")
    (tmp_path / "orphan-003.scorers.json").write_text(json.dumps([]), encoding="utf-8")
    with pytest.raises(ValueError, match="orphan fixture"):
        _discover_fixtures(tmp_path)


# ---------------------------------------------------------------------------
# Codex P2: valid_json_schema rejects bool for both "integer" AND "number"
# ---------------------------------------------------------------------------


@pytest.mark.unit
def test_valid_json_schema_number_type_does_not_accept_bool() -> None:
    """`bool` MUST NOT satisfy `"type": "number"` (Python subclass quirk)."""
    assert (
        valid_json_schema(True, schema={"type": "number"})  # type: ignore[arg-type]
        is False
    )
    assert (
        valid_json_schema(False, schema={"type": "number"})  # type: ignore[arg-type]
        is False
    )


@pytest.mark.unit
def test_valid_json_schema_number_type_accepts_int_and_float() -> None:
    """Real numbers (int and float) still satisfy `"type": "number"`."""
    assert (
        valid_json_schema(1, schema={"type": "number"})  # type: ignore[arg-type]
        is True
    )
    assert (
        valid_json_schema(1.5, schema={"type": "number"})  # type: ignore[arg-type]
        is True
    )
