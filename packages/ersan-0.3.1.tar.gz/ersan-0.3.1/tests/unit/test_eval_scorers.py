# ersan — your office. your rules. your AI. ...and you, amplified.
# Copyright 2026 Ersan Bilik
# SPDX-License-Identifier: Apache-2.0
"""Unit tests for the eval-harness scorer primitives (US-001 / FR-F1).

Each scorer has at least one positive case and one negative case. The
helper `_resolve_field` is also tested for its happy + missing paths
since `field_present` and `golden_field` lookup both depend on it.
"""

from __future__ import annotations

import pytest
from evals.scorer import (
    _resolve_field,
    contains_substring,
    field_present,
    list_min_length,
    valid_json_schema,
)

# ---------------------------------------------------------------------------
# contains_substring
# ---------------------------------------------------------------------------


@pytest.mark.unit
def test_contains_substring_positive() -> None:
    """`target` present anywhere in `actual` returns True."""
    assert contains_substring("hello world", target="world") is True


@pytest.mark.unit
def test_contains_substring_negative() -> None:
    """`target` absent from `actual` returns False (not raised)."""
    assert contains_substring("hello world", target="goodbye") is False


@pytest.mark.unit
def test_contains_substring_type_error_on_non_str_actual() -> None:
    """Non-str `actual` raises TypeError so config bugs surface loudly."""
    with pytest.raises(TypeError, match="contains_substring expected str"):
        contains_substring(123, target="x")  # type: ignore[arg-type]


# ---------------------------------------------------------------------------
# list_min_length
# ---------------------------------------------------------------------------


@pytest.mark.unit
def test_list_min_length_positive() -> None:
    """A list at or above the threshold returns True."""
    assert list_min_length([1, 2, 3], n=2) is True
    assert list_min_length(["a", "b"], n=2) is True


@pytest.mark.unit
def test_list_min_length_negative() -> None:
    """A list below the threshold returns False."""
    assert list_min_length([1], n=3) is False
    assert list_min_length([], n=1) is False


@pytest.mark.unit
def test_list_min_length_zero_threshold_always_true() -> None:
    """`n=0` is the trivial-pass case — even an empty list returns True."""
    assert list_min_length([], n=0) is True


@pytest.mark.unit
def test_list_min_length_negative_n_raises() -> None:
    """A negative threshold is a config bug, not a soft fail."""
    with pytest.raises(ValueError, match="must be >= 0"):
        list_min_length([1], n=-1)


# ---------------------------------------------------------------------------
# valid_json_schema
# ---------------------------------------------------------------------------


@pytest.mark.unit
def test_valid_json_schema_positive_object_with_required_keys() -> None:
    """All required keys present + correct type returns True."""
    assert (
        valid_json_schema(
            {"tool": "x", "result": {"count": 1}},
            schema={"type": "object", "required": ["tool", "result"]},
        )
        is True
    )


@pytest.mark.unit
def test_valid_json_schema_negative_missing_required_key() -> None:
    """Missing required key returns False."""
    assert (
        valid_json_schema(
            {"tool": "x"},
            schema={"type": "object", "required": ["tool", "result"]},
        )
        is False
    )


@pytest.mark.unit
def test_valid_json_schema_negative_wrong_type() -> None:
    """Wrong top-level type returns False."""
    assert (
        valid_json_schema(
            ["a", "b"],  # type: ignore[arg-type]
            schema={"type": "object", "required": []},
        )
        is False
    )


@pytest.mark.unit
def test_valid_json_schema_array_type() -> None:
    """Array type check works for lists."""
    assert valid_json_schema([], schema={"type": "array"}) is True  # type: ignore[arg-type]


@pytest.mark.unit
def test_valid_json_schema_integer_type_does_not_accept_bool() -> None:
    """`bool` MUST NOT satisfy `"type": "integer"` (Python subclass quirk)."""
    assert valid_json_schema(True, schema={"type": "integer"}) is False  # type: ignore[arg-type]
    assert valid_json_schema(1, schema={"type": "integer"}) is True  # type: ignore[arg-type]


@pytest.mark.unit
def test_valid_json_schema_unsupported_type_raises() -> None:
    """An unsupported `"type"` value is a config bug, not a soft fail."""
    with pytest.raises(ValueError, match="unsupported type"):
        valid_json_schema({}, schema={"type": "blob"})


# ---------------------------------------------------------------------------
# field_present
# ---------------------------------------------------------------------------


@pytest.mark.unit
def test_field_present_positive_top_level() -> None:
    """A top-level key resolves successfully."""
    assert field_present({"k": 1}, path="k") is True


@pytest.mark.unit
def test_field_present_positive_dotted() -> None:
    """A nested dotted path resolves successfully."""
    assert field_present({"a": {"b": {"c": 7}}}, path="a.b.c") is True


@pytest.mark.unit
def test_field_present_negative_missing() -> None:
    """A missing segment returns False rather than raising."""
    assert field_present({"a": {"b": {}}}, path="a.b.c") is False


@pytest.mark.unit
def test_field_present_negative_non_dict_intermediate() -> None:
    """A non-dict intermediate is treated as 'not present'."""
    assert field_present({"a": "scalar"}, path="a.b") is False


@pytest.mark.unit
def test_field_present_empty_path_raises() -> None:
    """An empty path is a config bug, not a soft fail."""
    with pytest.raises(ValueError, match="non-empty"):
        field_present({"a": 1}, path="")


# ---------------------------------------------------------------------------
# _resolve_field helper
# ---------------------------------------------------------------------------


@pytest.mark.unit
def test_resolve_field_positive() -> None:
    """The dotted-path walker returns the leaf value."""
    assert _resolve_field({"a": {"b": "leaf"}}, "a.b") == "leaf"


@pytest.mark.unit
def test_resolve_field_negative_raises_keyerror() -> None:
    """A missing segment raises KeyError naming the segment and full path."""
    with pytest.raises(KeyError, match="missing segment"):
        _resolve_field({"a": {}}, "a.b.c")
