# ersan — your office. your rules. your AI. ...and you, amplified.
# Copyright 2026 Ersan Bilik
# SPDX-License-Identifier: Apache-2.0
"""Regression tests for Codex cross-CLI review findings on US-002.

Codex (`codex exec`, GPT-5.x) reviewed PR #8 and surfaced three defects
in the loader. Each test below pins the fix so a future regression is
loud:

- P1: relative helper imports (`from ._helpers import X`) MUST resolve;
  the loader pre-registers parent packages so Python's import machinery
  can find them.
- P2: repeated `discover_skills()` calls MUST return Skills with
  identity-equal handlers (idempotency contract).
- P2: a non-string `trust_tier` (e.g. list/dict) MUST raise a typed
  `SkillManifestError`, not a raw `TypeError` from the membership test.
"""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

from ersan.core.skills.loader import (
    SkillManifestError,
    discover_skills,
)

# ---------------------------------------------------------------------------
# Codex P1: relative helper imports inside skills MUST resolve
# ---------------------------------------------------------------------------


@pytest.mark.unit
def test_skill_with_relative_helper_import_loads(tmp_path: Path) -> None:
    """A skill using `from ._helpers import VALUE` MUST discover successfully."""
    plugin_dir = tmp_path / "demo"
    plugin_dir.mkdir()
    (plugin_dir / "_helpers.py").write_text(
        "# ersan — your office. your rules. your AI. ...and you, amplified.\n"
        "# Copyright 2026 Ersan Bilik\n"
        "# SPDX-License-Identifier: Apache-2.0\n"
        'GREETING = "hello from helper"\n',
        encoding="utf-8",
    )
    (plugin_dir / "say_hi.py").write_text(
        "# ersan — your office. your rules. your AI. ...and you, amplified.\n"
        "# Copyright 2026 Ersan Bilik\n"
        "# SPDX-License-Identifier: Apache-2.0\n"
        "from ._helpers import GREETING\n"
        "\n"
        'MANIFEST = {"name": "say_hi", "description": "test", '
        '"trust_tier": "do_it", "plugin": "demo"}\n'
        "\n"
        "def handler() -> str:\n"
        "    return GREETING\n",
        encoding="utf-8",
    )
    skills = discover_skills(tmp_path)
    assert "demo.say_hi" in skills, (
        "skill with relative helper import was rejected; "
        "_ensure_parent_packages may not be registering the parent."
    )
    skill = skills["demo.say_hi"]
    assert skill.handler() == "hello from helper"


# ---------------------------------------------------------------------------
# Codex P2: repeated discovery preserves handler identity (idempotency)
# ---------------------------------------------------------------------------


@pytest.mark.unit
def test_repeated_discovery_preserves_handler_identity(tmp_path: Path) -> None:
    """Calling `discover_skills()` twice MUST return identity-equal handlers."""
    plugin_dir = tmp_path / "demo"
    plugin_dir.mkdir()
    (plugin_dir / "noop.py").write_text(
        "# ersan — your office. your rules. your AI. ...and you, amplified.\n"
        "# Copyright 2026 Ersan Bilik\n"
        "# SPDX-License-Identifier: Apache-2.0\n"
        'MANIFEST = {"name": "noop", "description": "n", '
        '"trust_tier": "do_it", "plugin": "demo"}\n'
        "\n"
        "def handler() -> int:\n"
        "    return 42\n",
        encoding="utf-8",
    )
    first = discover_skills(tmp_path)
    second = discover_skills(tmp_path)
    assert "demo.noop" in first and "demo.noop" in second
    # Identity, not just equality — the loader must reuse the cached module
    # so a downstream registry diffing handlers does not see a false change.
    assert first["demo.noop"].handler is second["demo.noop"].handler, (
        "discover_skills() returned a fresh handler on the second call; "
        "the idempotency contract requires identity-equal handlers."
    )
    assert first["demo.noop"] == second["demo.noop"], (
        "Skill instances drifted across repeated discovery."
    )


# ---------------------------------------------------------------------------
# Codex P2: non-string trust_tier raises typed SkillManifestError
# ---------------------------------------------------------------------------


@pytest.mark.unit
def test_non_string_trust_tier_raises_manifest_error_not_typeerror(
    tmp_path: Path,
) -> None:
    """`MANIFEST['trust_tier']=[...]` MUST raise SkillManifestError, not TypeError."""
    plugin_dir = tmp_path / "demo"
    plugin_dir.mkdir()
    (plugin_dir / "bad.py").write_text(
        "# ersan — your office. your rules. your AI. ...and you, amplified.\n"
        "# Copyright 2026 Ersan Bilik\n"
        "# SPDX-License-Identifier: Apache-2.0\n"
        'MANIFEST = {"name": "bad", "description": "bad", '
        '"trust_tier": ["not", "a", "string"], "plugin": "demo"}\n'
        "\n"
        "def handler() -> None:\n"
        "    return None\n",
        encoding="utf-8",
    )
    with pytest.raises(SkillManifestError, match=r"trust_tier.*must be str"):
        discover_skills(tmp_path)


@pytest.mark.unit
def test_non_string_trust_tier_dict_raises_manifest_error(tmp_path: Path) -> None:
    """`MANIFEST['trust_tier']={...}` MUST raise SkillManifestError, not TypeError."""
    plugin_dir = tmp_path / "demo"
    plugin_dir.mkdir()
    (plugin_dir / "bad2.py").write_text(
        "# ersan — your office. your rules. your AI. ...and you, amplified.\n"
        "# Copyright 2026 Ersan Bilik\n"
        "# SPDX-License-Identifier: Apache-2.0\n"
        'MANIFEST = {"name": "bad2", "description": "bad", '
        '"trust_tier": {"k": "v"}, "plugin": "demo"}\n'
        "\n"
        "def handler() -> None:\n"
        "    return None\n",
        encoding="utf-8",
    )
    with pytest.raises(SkillManifestError, match=r"trust_tier.*must be str"):
        discover_skills(tmp_path)


# ---------------------------------------------------------------------------
# Cleanup helper: prevent sys.modules pollution between test runs
# ---------------------------------------------------------------------------


@pytest.fixture(autouse=True)
def _reset_loader_namespace() -> None:
    """Strip any `ersan._loader_skills.*` entries before each test runs."""
    keys = [key for key in list(sys.modules) if key.startswith("ersan._loader_skills")]
    for key in keys:
        del sys.modules[key]
