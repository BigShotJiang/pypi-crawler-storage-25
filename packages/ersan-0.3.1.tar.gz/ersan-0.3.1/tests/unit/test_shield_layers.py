# ersan — your office. your rules. your AI. ...and you, amplified.
# Copyright 2026 Ersan Bilik
# SPDX-License-Identifier: Apache-2.0
"""Unit tests for the shield layer surface."""

from __future__ import annotations

import pytest

from ersan.shield.layers import Layer
from ersan.shield.layers.ner import NERScanner
from ersan.shield.layers.regex import RegexScanner
from ersan.shield.layers.semantic import SemanticScanner


@pytest.mark.unit
def test_layer_protocol_is_satisfied_by_all_shipped_layers() -> None:
    """The regex layer and both stubs satisfy the public Protocol."""
    assert isinstance(RegexScanner(), Layer)
    assert isinstance(NERScanner(), Layer)
    assert isinstance(SemanticScanner(), Layer)


@pytest.mark.unit
def test_optional_layers_are_stubbed_but_future_compatible() -> None:
    """The v0.3 stubs expose the expected optional-dependency hooks."""
    assert not NERScanner.is_available()
    assert not SemanticScanner.is_available()
    assert NERScanner().scan("anything") == []
    assert SemanticScanner().scan("anything") == []
