# ersan — your office. your rules. your AI. ...and you, amplified.
# Copyright 2026 Ersan Bilik
# SPDX-License-Identifier: Apache-2.0
"""Project-manifest invariants for the current dependency set."""

from __future__ import annotations

from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[2]
PYPROJECT = REPO_ROOT / "pyproject.toml"


@pytest.mark.unit
def test_runtime_deps_are_current_set() -> None:
    """The runtime dep set matches what's actually shipped.

    v0.2.0 added `anthropic`, `pydantic-ai`, `pyyaml` for the model-provider
    abstraction (US-003). v0.2.1 (cross-platform infra, US-004) adds NO new
    runtime deps — secret-storage was deferred to v0.4.0 per D-017 re-scope.
    """
    source = PYPROJECT.read_text(encoding="utf-8")
    assert '"anthropic>=0.40"' in source
    assert '"pydantic-ai>=1.73"' in source
    assert '"pyyaml>=6.0"' in source

    forbidden = ['"argon2-cffi', '"keyring', '"pynacl', '"pytest-httpx']
    for marker in forbidden:
        assert marker not in source, (
            f"{marker} appears in pyproject.toml but was deferred to v0.4.0 "
            f"per D-017 re-scope (see .specify/specs/US-004/spec.md)"
        )
