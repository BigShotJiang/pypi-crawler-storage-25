# ersan — your office. your rules. your AI. ...and you, amplified.
# Copyright 2026 Ersan Bilik
# SPDX-License-Identifier: Apache-2.0
"""Regression guard for forward-slash paths inside `.secrets.baseline`."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[2]
BASELINE_PATH = REPO_ROOT / ".secrets.baseline"


@pytest.mark.unit
def test_secrets_baseline_uses_posix_path_separators() -> None:
    """The detect-secrets baseline serializes paths with `/` on every OS."""
    baseline = json.loads(BASELINE_PATH.read_text(encoding="utf-8"))
    offending_paths: list[str] = []

    for result_key, findings in baseline.get("results", {}).items():
        if "\\" in result_key:
            offending_paths.append(result_key)
        if not isinstance(findings, list):
            continue
        for finding in findings:
            if isinstance(finding, dict):
                filename = finding.get("filename")
                if isinstance(filename, str) and "\\" in filename:
                    offending_paths.append(filename)

    assert not offending_paths, (
        "`.secrets.baseline` contains a Windows-style path separator `\\`; "
        "re-run `detect-secrets scan --update .secrets.baseline` on Linux/macOS, "
        "or run `python scripts/normalize_secrets_baseline.py`. "
        f"Offending paths: {offending_paths}"
    )
