# ersan — your office. your rules. your AI. ...and you, amplified.
# Copyright 2026 Ersan Bilik
# SPDX-License-Identifier: Apache-2.0
"""Unit tests for `ersan.policy.conditions`."""

from __future__ import annotations

import pytest

from ersan.policy.conditions import (
    ConditionParseError,
    evaluate_condition,
    parse_condition,
)
from ersan.policy.types import CallerContext, SessionContext


@pytest.mark.unit
def test_parse_condition_builds_flat_group() -> None:
    """Quoted values and combinators parse into the source-shaped group."""
    group = parse_condition('subject CONTAINS "Quarterly report" OR dlp_level >= 3')
    assert [condition.field for condition in group.conditions] == ["subject", "dlp_level"]
    assert [condition.operator for condition in group.conditions] == ["CONTAINS", ">="]
    assert [condition.value for condition in group.conditions] == ["Quarterly report", "3"]
    assert group.combinators == ["OR"]


@pytest.mark.unit
def test_parse_condition_rejects_unknown_operator() -> None:
    """Unexpected operators raise the dedicated parse error."""
    with pytest.raises(ConditionParseError, match="Unknown operator"):
        parse_condition("size ~~ 1000")


@pytest.mark.unit
def test_evaluate_condition_reads_args_caller_and_session() -> None:
    """Runtime lookups follow args, session, then caller context."""
    group = parse_condition(
        "subject CONTAINS report AND dlp_level >= 3 AND caller_identity == owner@example.com"
    )
    session = SessionContext(dlp_level=4)
    caller = CallerContext(identity="owner@example.com", channel="repl")
    assert evaluate_condition(
        group,
        args={"subject": "Quarterly report"},
        caller=caller,
        session=session,
    )


@pytest.mark.unit
def test_evaluate_condition_uses_session_custom_fields() -> None:
    """Session.custom participates in field resolution."""
    group = parse_condition("risk_score >= 7")
    session = SessionContext(custom={"risk_score": 8})
    assert evaluate_condition(group, session=session)


@pytest.mark.unit
def test_evaluate_condition_is_left_to_right() -> None:
    """Combinators preserve the source left-to-right evaluation semantics."""
    group = parse_condition("flag == yes OR count > 10 AND other == no")
    result = evaluate_condition(
        group,
        args={"flag": "yes", "count": 0, "other": "yes"},
    )
    assert not result
