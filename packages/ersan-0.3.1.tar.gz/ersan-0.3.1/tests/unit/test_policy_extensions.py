# ersan — your office. your rules. your AI. ...and you, amplified.
# Copyright 2026 Ersan Bilik
# SPDX-License-Identifier: Apache-2.0
"""Unit tests for `ersan.policy.extensions`."""

from __future__ import annotations

from typing import Any

import pytest

from ersan.policy.extensions import (
    DLPProtocol,
    HooksPipelineProtocol,
    PolicyResolverProtocol,
    SandboxProtocol,
    TrustMatrixProtocol,
)
from ersan.policy.policy import Policy


class _Resolver:
    def resolve(self, ctx: Any) -> Policy:
        return Policy()


class _TrustMatrix:
    def evaluate(self, caller: Any, tool_name: str, base_tier: str) -> str:
        return base_tier


class _DLP:
    async def list_labels(self) -> list[Any]:
        return []

    async def get_content_label(self, content_type: str, content_id: str) -> Any | None:
        return None


class _Sandbox:
    def elevate(
        self,
        tool: str,
        args: dict[str, Any],
        caller: Any,
        session: Any,
    ) -> str | None:
        return None


class _Hooks:
    async def run_pre(self, tool: str, args: dict[str, Any], caller: Any, session: Any) -> None:
        return None

    async def run_post(
        self,
        tool: str,
        args: dict[str, Any],
        result: Any,
        caller: Any,
        session: Any,
    ) -> None:
        return None


class _Unrelated:
    pass


@pytest.mark.unit
def test_extensions_protocols_are_runtime_checkable() -> None:
    """Minimal implementations satisfy the public extension contracts."""
    assert isinstance(_Resolver(), PolicyResolverProtocol)
    assert isinstance(_TrustMatrix(), TrustMatrixProtocol)
    assert isinstance(_DLP(), DLPProtocol)
    assert isinstance(_Sandbox(), SandboxProtocol)
    assert isinstance(_Hooks(), HooksPipelineProtocol)


@pytest.mark.unit
def test_unrelated_class_does_not_satisfy_extensions_protocols() -> None:
    """The Protocol checks reject unrelated objects."""
    unrelated = _Unrelated()
    assert not isinstance(unrelated, PolicyResolverProtocol)
    assert not isinstance(unrelated, TrustMatrixProtocol)
    assert not isinstance(unrelated, DLPProtocol)
    assert not isinstance(unrelated, SandboxProtocol)
    assert not isinstance(unrelated, HooksPipelineProtocol)
