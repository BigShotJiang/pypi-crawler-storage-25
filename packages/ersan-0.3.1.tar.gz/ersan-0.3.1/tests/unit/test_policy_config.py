# ersan — your office. your rules. your AI. ...and you, amplified.
# Copyright 2026 Ersan Bilik
# SPDX-License-Identifier: Apache-2.0
"""Unit tests for `ersan.policy.config`."""

from __future__ import annotations

from pathlib import Path
from textwrap import dedent

import pytest

from ersan.policy import config as policy_config

_SCRATCH_DIR = Path(__file__).resolve().parents[2] / ".tmp-policy-config-tests"
_SCRATCH_DIR.mkdir(exist_ok=True)


@pytest.mark.unit
def test_load_default_policy_falls_back_to_packaged_default(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Without a user override, the packaged retail default is loaded."""
    fake_home = _SCRATCH_DIR / "fallback-home"
    fake_home.mkdir(parents=True, exist_ok=True)
    monkeypatch.setattr(policy_config.Path, "home", lambda: fake_home)

    policy = policy_config.load_default_policy()
    assert policy.default_tier == "ask_first"
    assert policy.tool_tiers == {}
    assert policy.blocked_patterns == []


@pytest.mark.unit
def test_load_default_policy_prefers_user_override(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """The `~/.ersan/policy.yaml` override wins over the packaged default."""
    fake_home = _SCRATCH_DIR / "override-home"
    user_policy_dir = fake_home / ".ersan"
    user_policy_dir.mkdir(parents=True, exist_ok=True)
    (user_policy_dir / "policy.yaml").write_text(
        dedent(
            """
            defaults:
              tier: do_it
            tools:
              inbox.list_unread: do_and_tell
            """
        ).strip()
        + "\n",
        encoding="utf-8",
    )
    monkeypatch.setattr(policy_config.Path, "home", lambda: fake_home)

    policy = policy_config.load_default_policy()
    assert policy.default_tier == "do_it"
    assert policy.tool_tiers["inbox.list_unread"] == "do_and_tell"
