# ersan — your office. your rules. your AI. ...and you, amplified.
# Copyright 2026 Ersan Bilik
# SPDX-License-Identifier: Apache-2.0
"""Unit tests for `ersan.shield.types`."""

from __future__ import annotations

import pytest

from ersan.shield.types import Finding, ScanAction, ScanResult


@pytest.mark.unit
def test_scan_action_round_trip_values() -> None:
    """The shield enum preserves the source action values."""
    assert ScanAction("pass") is ScanAction.PASS
    assert ScanAction("warn") is ScanAction.WARN
    assert ScanAction("block") is ScanAction.BLOCK
    assert ScanAction("redact") is ScanAction.REDACT


@pytest.mark.unit
def test_scan_result_helper_properties_filter_findings() -> None:
    """The helper properties partition findings by action."""
    findings = [
        Finding(type="credential", subtype="aws_key", text="x", action=ScanAction.BLOCK),
        Finding(type="pii", subtype="email", text="x", action=ScanAction.WARN),
        Finding(type="pattern", subtype="custom", text="x", action=ScanAction.REDACT),
    ]
    result = ScanResult(passed=False, findings=findings)
    assert [finding.subtype for finding in result.blocks] == ["aws_key"]
    assert [finding.subtype for finding in result.warnings] == ["email"]
    assert [finding.subtype for finding in result.redactions] == ["custom"]
