# ersan — your office. your rules. your AI. ...and you, amplified.
# Copyright 2026 Ersan Bilik
# SPDX-License-Identifier: Apache-2.0
"""Unit tests for the portable DCO sign-off pre-commit hook.

Defends `scripts/check_dco.py` (issue #11). Tests both positive and
negative cases, and the error paths (missing arg, unreadable file). The
script is exercised both directly via its public ``main()`` AND via a
subprocess invocation that mirrors how pre-commit calls it, so OS-level
regressions in argv parsing or stdio are also caught.
"""

from __future__ import annotations

import importlib.util
import subprocess
import sys
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[2]
SCRIPT = REPO_ROOT / "scripts" / "check_dco.py"

# Load `scripts/check_dco.py` as a module via importlib because `scripts/`
# is not a package under `src/ersan`; this keeps the production namespace
# clean and lets us exercise `_has_dco_trailer` and `main()` directly.
_spec = importlib.util.spec_from_file_location("check_dco", SCRIPT)
assert _spec is not None and _spec.loader is not None
check_dco = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(check_dco)


# ---------------------------------------------------------------------------
# In-process tests of `_has_dco_trailer` and `main()`
# ---------------------------------------------------------------------------


@pytest.mark.unit
def test_has_dco_trailer_accepts_canonical_signoff() -> None:
    """A line matching `Signed-off-by: Name <email@host>` returns True."""
    msg = "feat: x\n\nSigned-off-by: Ersan Bilik <ersanbilik@gmail.com>\n"
    assert check_dco._has_dco_trailer(msg) is True


@pytest.mark.unit
def test_has_dco_trailer_rejects_missing_trailer() -> None:
    """A message without any sign-off returns False."""
    assert check_dco._has_dco_trailer("feat: x\n\nNo trailer here\n") is False


@pytest.mark.unit
def test_has_dco_trailer_rejects_lowercase_keyword() -> None:
    """`signed-off-by:` (wrong case) does NOT count — the canonical form is required."""
    assert (
        check_dco._has_dco_trailer("feat: x\n\nsigned-off-by: Ersan <ersanbilik@gmail.com>\n")
        is False
    )


@pytest.mark.unit
def test_has_dco_trailer_rejects_missing_email_brackets() -> None:
    """`Signed-off-by: Name email@host` (no `<...>`) does NOT count."""
    assert (
        check_dco._has_dco_trailer("feat: x\n\nSigned-off-by: Ersan ersanbilik@gmail.com\n")
        is False
    )


@pytest.mark.unit
def test_has_dco_trailer_rejects_email_without_at(tmp_path: Path) -> None:
    """`Signed-off-by: Name <not-an-email>` does NOT count."""
    assert check_dco._has_dco_trailer("feat: x\n\nSigned-off-by: Ersan <not-an-email>\n") is False


@pytest.mark.unit
def test_main_returns_0_on_signed_message(tmp_path: Path) -> None:
    """`main([msg_file])` returns 0 when the trailer is present."""
    msg_file = tmp_path / "msg.txt"
    msg_file.write_text(
        "feat: x\n\nSigned-off-by: Ersan Bilik <ersanbilik@gmail.com>\n",
        encoding="utf-8",
    )
    assert check_dco.main([str(msg_file)]) == 0


@pytest.mark.unit
def test_main_returns_1_on_unsigned_message(
    tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    """`main([msg_file])` returns 1 and prints diagnostic when trailer missing."""
    msg_file = tmp_path / "msg.txt"
    msg_file.write_text("feat: x\n\nNo trailer\n", encoding="utf-8")
    rc = check_dco.main([str(msg_file)])
    assert rc == 1
    err = capsys.readouterr().err
    assert "Signed-off-by" in err
    assert "git commit -s" in err


@pytest.mark.unit
def test_main_returns_1_on_missing_argv(
    capsys: pytest.CaptureFixture[str],
) -> None:
    """`main([])` returns 1 with a usage message."""
    rc = check_dco.main([])
    assert rc == 1
    assert "usage" in capsys.readouterr().err.lower()


@pytest.mark.unit
def test_main_returns_1_on_unreadable_file(
    tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    """`main([nonexistent_path])` returns 1 with a read-error diagnostic."""
    rc = check_dco.main([str(tmp_path / "nope.txt")])
    assert rc == 1
    assert "cannot read" in capsys.readouterr().err.lower()


@pytest.mark.unit
def test_main_handles_non_utf8_commit_message(tmp_path: Path) -> None:
    """A non-UTF-8 commit message MUST still allow the ASCII trailer to be detected.

    Codex review 2026-04-18 (P2): contributors with `git config
    i18n.commitEncoding` set to e.g. Latin-1 or Shift-JIS would write
    commit-msg files containing non-UTF-8 bytes; a strict UTF-8 decode
    would raise UnicodeDecodeError and abort the hook with a traceback,
    blocking valid signed commits. Verify the new bytes-then-decode-with-
    errors-replace path keeps the ASCII Signed-off-by trailer detectable.
    """
    msg_file = tmp_path / "msg.txt"
    # Latin-1 bytes for "ï" (0xEF) and "é" (0xE9) — invalid as UTF-8 here
    # because they're standalone high bytes rather than UTF-8 multibyte
    # sequences. The Signed-off-by trailer is pure ASCII so MUST survive.
    body = b"feat: \xef test \xe9\n\nSigned-off-by: Ersan Bilik <ersanbilik@gmail.com>\n"
    msg_file.write_bytes(body)
    assert check_dco.main([str(msg_file)]) == 0


@pytest.mark.unit
def test_main_handles_non_utf8_commit_message_without_trailer(
    tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    """Non-UTF-8 message WITHOUT trailer still rejects (no traceback)."""
    msg_file = tmp_path / "msg.txt"
    body = b"feat: \xef test \xe9\n\nNo trailer here at all\n"
    msg_file.write_bytes(body)
    rc = check_dco.main([str(msg_file)])
    assert rc == 1
    assert "Signed-off-by" in capsys.readouterr().err


# ---------------------------------------------------------------------------
# Subprocess tests — exercise the actual CLI surface pre-commit will hit
# ---------------------------------------------------------------------------


def _run_script(msg_file: Path) -> subprocess.CompletedProcess[str]:
    # Args are fully controlled (sys.executable + repo-internal script + tmp
    # path from pytest's tmp_path fixture); no user input. S603 is a false
    # positive here — the test harness is intentionally invoking our own
    # script the way pre-commit will invoke it in production.
    return subprocess.run(  # noqa: S603
        [sys.executable, str(SCRIPT), str(msg_file)],
        capture_output=True,
        text=True,
        check=False,
    )


@pytest.mark.unit
def test_subprocess_exit_0_on_signed_message(tmp_path: Path) -> None:
    """End-to-end via subprocess: signed message exits 0."""
    msg_file = tmp_path / "msg.txt"
    msg_file.write_text(
        "feat: x\n\nSigned-off-by: Ersan Bilik <ersanbilik@gmail.com>\n",
        encoding="utf-8",
    )
    result = _run_script(msg_file)
    assert result.returncode == 0, f"stderr={result.stderr}"


@pytest.mark.unit
def test_subprocess_exit_1_on_unsigned_message(tmp_path: Path) -> None:
    """End-to-end via subprocess: unsigned message exits 1 with diagnostic."""
    msg_file = tmp_path / "msg.txt"
    msg_file.write_text("feat: x\n\nNo trailer here\n", encoding="utf-8")
    result = _run_script(msg_file)
    assert result.returncode == 1
    assert "Signed-off-by" in result.stderr
