# ersan — your office. your rules. your AI. ...and you, amplified.
# Copyright 2026 Ersan Bilik
# SPDX-License-Identifier: Apache-2.0
"""Unit tests for `ersan.providers.backends`."""

from __future__ import annotations

import inspect
from typing import Any, cast

import pytest

from ersan.providers.backends import BACKEND_DISPATCH, dispatch
from ersan.providers.registry import find_by_name
from ersan.providers.spec import Backend, ProviderSpec


@pytest.mark.unit
def test_backend_dispatch_keys_match_v020_backends() -> None:
    """Only the two v0.2.0 backends are registered."""
    assert set(BACKEND_DISPATCH) == {"openai_compat", "anthropic"}


@pytest.mark.unit
def test_backend_dispatch_values_are_callable() -> None:
    """Every dispatch entry points at a callable factory."""
    assert all(callable(factory) for factory in BACKEND_DISPATCH.values())


@pytest.mark.unit
def test_create_model_signatures_match_source() -> None:
    """Both factories keep the source factory signature shape."""
    expected = ["spec", "model_name", "model_cfg", "login_manager"]
    for factory in BACKEND_DISPATCH.values():
        assert list(inspect.signature(factory).parameters) == expected


@pytest.mark.unit
def test_dispatch_raises_value_error_for_unknown_backend() -> None:
    """Unknown backends raise the source-shaped diagnostic."""
    spec = ProviderSpec(name="demo", backend=cast(Backend, "unknown"))
    with pytest.raises(ValueError, match=r"Unknown backend 'unknown' for provider 'demo'"):
        dispatch(spec, "gpt-4o", {}, None)


@pytest.mark.unit
def test_dispatch_is_data_driven_for_new_backend(monkeypatch: pytest.MonkeyPatch) -> None:
    """Adding a backend is one dispatch-table entry, not new control flow."""
    calls: list[tuple[ProviderSpec, str, dict[str, Any], Any | None]] = []

    def fake_factory(
        spec: ProviderSpec,
        model_name: str,
        model_cfg: dict[str, Any],
        login_manager: Any | None,
    ) -> str:
        calls.append((spec, model_name, model_cfg, login_manager))
        return "ok"

    monkeypatch.setitem(BACKEND_DISPATCH, "dummy_backend", fake_factory)
    spec = ProviderSpec(name="dummy", backend=cast(Backend, "dummy_backend"))
    assert dispatch(spec, "demo-model", {"base_url": "http://localhost"}, None) == "ok"
    assert calls == [(spec, "demo-model", {"base_url": "http://localhost"}, None)]


@pytest.mark.unit
def test_dispatch_uses_registry_specs() -> None:
    """The registry and dispatch table compose through the shared backend key."""
    ollama = find_by_name("ollama")
    anthropic = find_by_name("anthropic")
    assert ollama is not None
    assert anthropic is not None
    assert ollama.backend in BACKEND_DISPATCH
    assert anthropic.backend in BACKEND_DISPATCH
