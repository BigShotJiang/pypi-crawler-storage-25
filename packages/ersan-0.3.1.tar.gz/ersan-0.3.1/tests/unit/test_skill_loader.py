# ersan — your office. your rules. your AI. ...and you, amplified.
# Copyright 2026 Ersan Bilik
# SPDX-License-Identifier: Apache-2.0
"""Unit tests for `ersan.core.skills.loader.discover_skills` (US-002 / FR-G1).

Each test constructs a fake plugin (or several) inside `tmp_path` and
exercises one branch of the documented validation order (loader.py
module docstring; plan.md Decision R-002). Tests cover the happy path,
idempotency, edge cases (empty dir, missing dir, dunder/underscore
modules), and one-failure-per-validation-step for every typed error in
the loader's exception hierarchy.

The fake plugins are file-system-only — no module under
`src/ersan/skills/` is required. This keeps the loader tests
hermetic and independent of the (still-unborn) production skills
delivered by US-007 onwards.
"""

from __future__ import annotations

from pathlib import Path
from textwrap import dedent

import pytest

from ersan.core.skills import (
    Skill,
    SkillHandlerError,
    SkillManifestError,
    SkillPluginMismatchError,
    discover_skills,
)

SPDX_HEADER: str = (
    "# ersan — your office. your rules. your AI. ...and you, amplified.\n"
    "# Copyright 2026 Ersan Bilik\n"
    "# SPDX-License-Identifier: Apache-2.0\n"
)


def _write_init(plugin_dir: Path) -> None:
    """Write a minimal `__init__.py` so the directory is a proper package."""
    plugin_dir.mkdir(parents=True, exist_ok=True)
    init = plugin_dir / "__init__.py"
    init.write_text(SPDX_HEADER + '"""Fake plugin (test fixture)."""\n', encoding="utf-8")


def _write_skill(
    plugin_dir: Path,
    skill_name: str,
    *,
    manifest_repr: str | None = None,
    handler_repr: str | None = None,
    extra_body: str = "",
) -> Path:
    """Write a fake skill module to `plugin_dir/<skill_name>.py`.

    Args:
        plugin_dir: The plugin directory (must already contain an
            `__init__.py`).
        skill_name: The skill module's stem (without `.py`).
        manifest_repr: Python source for the right-hand side of
            `MANIFEST = ...`. If None, a minimal valid manifest is
            synthesized using `skill_name` and the plugin dir name.
        handler_repr: Python source for the right-hand side of
            `handler = ...`. If None, a no-op `def handler(*a, **k):
            return None` is written.
        extra_body: Additional Python source appended after the
            manifest and handler (for advanced scenarios).

    Returns:
        The path to the written `.py` file.
    """
    plugin_name = plugin_dir.name
    if manifest_repr is None:
        manifest_repr = (
            "{"
            f'"name": "{skill_name}", '
            f'"description": "Test skill {skill_name}.", '
            f'"trust_tier": "do_it", '
            f'"plugin": "{plugin_name}"'
            "}"
        )
    if handler_repr is None:
        handler_repr = dedent(
            """
            def handler(*args, **kwargs):
                return None
            """
        ).strip()
    body = (
        SPDX_HEADER
        + f'"""Fake skill {skill_name} for plugin {plugin_name}."""\n'
        + "from __future__ import annotations\n\n"
        + f"MANIFEST = {manifest_repr}\n\n"
        + f"{handler_repr}\n"
        + (("\n" + extra_body + "\n") if extra_body else "")
    )
    skill_path = plugin_dir / f"{skill_name}.py"
    skill_path.write_text(body, encoding="utf-8")
    return skill_path


def _write_raw_skill(plugin_dir: Path, skill_name: str, body: str) -> Path:
    """Write a skill module with arbitrary body (no auto-MANIFEST/handler).

    Used for tests that need exact control over the module's contents
    (e.g. malformed manifests, missing symbols, import errors).
    """
    skill_path = plugin_dir / f"{skill_name}.py"
    skill_path.write_text(SPDX_HEADER + body, encoding="utf-8")
    return skill_path


# ---------------------------------------------------------------------------
# Happy-path discovery.
# ---------------------------------------------------------------------------


@pytest.mark.unit
def test_discover_returns_three_skills_for_three_module_plugin(tmp_path: Path) -> None:
    """FR-C1: discovery returns one Skill per module, keyed correctly."""
    plugin_dir = tmp_path / "inbox"
    _write_init(plugin_dir)
    _write_skill(plugin_dir, "list_unread")
    _write_skill(plugin_dir, "summarize")
    _write_skill(plugin_dir, "draft_reply")
    skills = discover_skills(tmp_path)
    assert set(skills) == {
        "inbox.list_unread",
        "inbox.summarize",
        "inbox.draft_reply",
    }
    for fqn, skill in skills.items():
        assert isinstance(skill, Skill)
        assert skill.fully_qualified_name == fqn


@pytest.mark.unit
def test_discover_returns_skills_across_two_plugins(tmp_path: Path) -> None:
    """FR-C1: discovery handles multiple plugin directories."""
    inbox = tmp_path / "inbox"
    calendar = tmp_path / "calendar"
    _write_init(inbox)
    _write_init(calendar)
    _write_skill(inbox, "list_unread")
    _write_skill(calendar, "list_events")
    skills = discover_skills(tmp_path)
    assert set(skills) == {"inbox.list_unread", "calendar.list_events"}


@pytest.mark.unit
def test_discover_returns_empty_dict_for_empty_plugins_dir(tmp_path: Path) -> None:
    """Edge case: empty dir is a valid zero-skill state, not an error."""
    skills = discover_skills(tmp_path)
    assert skills == {}


@pytest.mark.unit
def test_discover_raises_file_not_found_error_for_missing_plugins_dir(tmp_path: Path) -> None:
    """Edge case: missing dir is a config bug, distinguished from empty."""
    missing = tmp_path / "nope"
    with pytest.raises(FileNotFoundError, match="plugins dir does not exist"):
        discover_skills(missing)


@pytest.mark.unit
def test_discover_skips_dunder_init_modules(tmp_path: Path) -> None:
    """FR-A5: `__init__.py` is a package marker, not a skill module."""
    plugin_dir = tmp_path / "inbox"
    _write_init(plugin_dir)
    # The init alone — no skill modules. Discovery must not complain that
    # __init__.py is missing a MANIFEST.
    skills = discover_skills(tmp_path)
    assert skills == {}


@pytest.mark.unit
def test_discover_skips_underscore_prefixed_modules(tmp_path: Path) -> None:
    """FR-A5: `_helpers.py` style modules are private, not skills."""
    plugin_dir = tmp_path / "inbox"
    _write_init(plugin_dir)
    _write_skill(plugin_dir, "list_unread")
    # Drop a malformed _helpers.py — if the loader were inspecting it,
    # it would raise SkillManifestError. Discovery must skip it cleanly.
    _write_raw_skill(plugin_dir, "_helpers", "# nothing useful here\n")
    skills = discover_skills(tmp_path)
    assert set(skills) == {"inbox.list_unread"}


@pytest.mark.unit
def test_discover_is_idempotent(tmp_path: Path) -> None:
    """FR-C4: two consecutive calls return equivalent mappings."""
    plugin_dir = tmp_path / "inbox"
    _write_init(plugin_dir)
    _write_skill(plugin_dir, "list_unread")
    _write_skill(plugin_dir, "summarize")
    first = discover_skills(tmp_path)
    second = discover_skills(tmp_path)
    assert set(first) == set(second)
    for fqn in first:
        a, b = first[fqn], second[fqn]
        assert a.name == b.name
        assert a.description == b.description
        assert a.trust_tier == b.trust_tier
        assert a.plugin == b.plugin
        assert a.module_path == b.module_path
        # Idempotent re-loading: handler in `second` is the freshly-loaded
        # callable. We assert callable identity in functional tests where
        # the e2e shape exercises behavior; here, verify it is callable.
        assert callable(a.handler)
        assert callable(b.handler)


@pytest.mark.unit
def test_skill_dataclass_fields_are_populated_correctly(tmp_path: Path) -> None:
    """FR-B1: Skill carries name/description/trust_tier/plugin/handler/module_path."""
    plugin_dir = tmp_path / "inbox"
    _write_init(plugin_dir)
    skill_path = _write_skill(
        plugin_dir,
        "list_unread",
        manifest_repr=(
            '{"name": "list_unread", "description": "List unread mail.", '
            '"trust_tier": "do_it", "plugin": "inbox"}'
        ),
    )
    skills = discover_skills(tmp_path)
    skill = skills["inbox.list_unread"]
    assert skill.name == "list_unread"
    assert skill.description == "List unread mail."
    assert skill.trust_tier == "do_it"
    assert skill.plugin == "inbox"
    assert callable(skill.handler)
    assert skill.module_path == skill_path


@pytest.mark.unit
def test_skill_fully_qualified_name(tmp_path: Path) -> None:
    """FR-B3: fully_qualified_name returns "<plugin>.<name>"."""
    plugin_dir = tmp_path / "inbox"
    _write_init(plugin_dir)
    _write_skill(plugin_dir, "list_unread")
    skill = discover_skills(tmp_path)["inbox.list_unread"]
    assert skill.fully_qualified_name == "inbox.list_unread"


@pytest.mark.unit
def test_skill_dataclass_is_frozen_and_hashable(tmp_path: Path) -> None:
    """FR-B2: Skill is hashable (frozen dataclass)."""
    plugin_dir = tmp_path / "inbox"
    _write_init(plugin_dir)
    _write_skill(plugin_dir, "list_unread")
    skill = discover_skills(tmp_path)["inbox.list_unread"]
    # Hashable -> usable in a set.
    assert {skill}
    # Frozen -> attribute assignment is rejected.
    with pytest.raises(Exception):  # noqa: B017 — FrozenInstanceError or AttributeError
        skill.name = "mutated"  # type: ignore[misc]


# ---------------------------------------------------------------------------
# Typed-error coverage (per FR-D, validation order in module docstring).
# ---------------------------------------------------------------------------


@pytest.mark.unit
def test_missing_manifest_raises_skill_manifest_error(tmp_path: Path) -> None:
    """Step 3: module without a top-level MANIFEST."""
    plugin_dir = tmp_path / "inbox"
    _write_init(plugin_dir)
    _write_raw_skill(
        plugin_dir,
        "list_unread",
        '"""no manifest here"""\n\ndef handler(*a, **k): return None\n',
    )
    with pytest.raises(SkillManifestError, match="missing top-level `MANIFEST`"):
        discover_skills(tmp_path)


@pytest.mark.unit
def test_manifest_not_dict_raises_skill_manifest_error(tmp_path: Path) -> None:
    """Step 4: MANIFEST is a list, not a dict."""
    plugin_dir = tmp_path / "inbox"
    _write_init(plugin_dir)
    _write_raw_skill(
        plugin_dir,
        "list_unread",
        '"""bad manifest"""\nMANIFEST = ["not", "a", "dict"]\ndef handler(*a, **k): return None\n',
    )
    with pytest.raises(SkillManifestError, match="MANIFEST must be a dict"):
        discover_skills(tmp_path)


@pytest.mark.unit
def test_manifest_missing_required_key_raises_skill_manifest_error(tmp_path: Path) -> None:
    """Step 5: MANIFEST without the `name` key."""
    plugin_dir = tmp_path / "inbox"
    _write_init(plugin_dir)
    _write_skill(
        plugin_dir,
        "list_unread",
        manifest_repr=(
            '{"description": "no name field", "trust_tier": "do_it", "plugin": "inbox"}'
        ),
    )
    with pytest.raises(SkillManifestError, match="missing required key 'name'"):
        discover_skills(tmp_path)


@pytest.mark.unit
def test_manifest_wrong_key_type_raises_skill_manifest_error(tmp_path: Path) -> None:
    """Step 6: description is an int, not a str."""
    plugin_dir = tmp_path / "inbox"
    _write_init(plugin_dir)
    _write_skill(
        plugin_dir,
        "list_unread",
        manifest_repr=(
            '{"name": "list_unread", "description": 42, "trust_tier": "do_it", "plugin": "inbox"}'
        ),
    )
    with pytest.raises(SkillManifestError, match=r"description.*must be str"):
        discover_skills(tmp_path)


@pytest.mark.unit
def test_manifest_invalid_trust_tier_raises_skill_manifest_error(tmp_path: Path) -> None:
    """Step 6: trust_tier is not in the allowed set."""
    plugin_dir = tmp_path / "inbox"
    _write_init(plugin_dir)
    _write_skill(
        plugin_dir,
        "list_unread",
        manifest_repr=(
            '{"name": "list_unread", "description": "x", "trust_tier": "bogus", "plugin": "inbox"}'
        ),
    )
    with pytest.raises(SkillManifestError, match=r"trust_tier.*'bogus'.*must be one of"):
        discover_skills(tmp_path)


@pytest.mark.unit
def test_manifest_description_too_long_raises_skill_manifest_error(tmp_path: Path) -> None:
    """Step 6: description exceeds 200-char cap."""
    plugin_dir = tmp_path / "inbox"
    _write_init(plugin_dir)
    long_desc = "x" * 201
    _write_skill(
        plugin_dir,
        "list_unread",
        manifest_repr=(
            f'{{"name": "list_unread", "description": "{long_desc}", '
            f'"trust_tier": "do_it", "plugin": "inbox"}}'
        ),
    )
    with pytest.raises(SkillManifestError, match=r"description.*201 chars"):
        discover_skills(tmp_path)


@pytest.mark.unit
def test_manifest_invalid_name_chars_raises_skill_manifest_error(tmp_path: Path) -> None:
    """Step 6: name contains a dot."""
    plugin_dir = tmp_path / "inbox"
    _write_init(plugin_dir)
    _write_skill(
        plugin_dir,
        "list_unread",
        manifest_repr=(
            '{"name": "bad.name", "description": "x", "trust_tier": "do_it", "plugin": "inbox"}'
        ),
    )
    with pytest.raises(SkillManifestError, match=r"MANIFEST\['name'\].*'bad.name'"):
        discover_skills(tmp_path)


@pytest.mark.unit
def test_manifest_plugin_mismatch_raises_skill_plugin_mismatch_error(tmp_path: Path) -> None:
    """Step 7: MANIFEST['plugin'] != parent dir name."""
    plugin_dir = tmp_path / "inbox"
    _write_init(plugin_dir)
    _write_skill(
        plugin_dir,
        "list_unread",
        manifest_repr=(
            '{"name": "list_unread", "description": "x", "trust_tier": "do_it", "plugin": "outbox"}'
        ),
    )
    with pytest.raises(SkillPluginMismatchError, match="does not match parent directory"):
        discover_skills(tmp_path)


@pytest.mark.unit
def test_plugin_dir_name_invalid_chars_raises_skill_plugin_mismatch_error(tmp_path: Path) -> None:
    """Step 1: plugin directory name with a dot fails the char class."""
    plugin_dir = tmp_path / "evil.plugin"
    _write_init(plugin_dir)
    _write_skill(plugin_dir, "list_unread")
    with pytest.raises(SkillPluginMismatchError, match=r"plugin directory name 'evil.plugin'"):
        discover_skills(tmp_path)


@pytest.mark.unit
def test_missing_handler_raises_skill_handler_error(tmp_path: Path) -> None:
    """Step 8: module has MANIFEST but no `handler` symbol."""
    plugin_dir = tmp_path / "inbox"
    _write_init(plugin_dir)
    _write_raw_skill(
        plugin_dir,
        "list_unread",
        (
            '"""no handler here"""\n'
            'MANIFEST = {"name": "list_unread", "description": "x", '
            '"trust_tier": "do_it", "plugin": "inbox"}\n'
        ),
    )
    with pytest.raises(SkillHandlerError, match="missing top-level `handler`"):
        discover_skills(tmp_path)


@pytest.mark.unit
def test_handler_not_callable_raises_skill_handler_error(tmp_path: Path) -> None:
    """Step 8: handler symbol exists but is not callable."""
    plugin_dir = tmp_path / "inbox"
    _write_init(plugin_dir)
    _write_skill(
        plugin_dir,
        "list_unread",
        handler_repr="handler = 42",
    )
    with pytest.raises(SkillHandlerError, match=r"handler.*must be callable.*int"):
        discover_skills(tmp_path)


@pytest.mark.unit
def test_duplicate_skill_name_within_plugin_raises_skill_manifest_error(tmp_path: Path) -> None:
    """Step 9: two modules in one plugin both declare MANIFEST['name']='list_unread'."""
    plugin_dir = tmp_path / "inbox"
    _write_init(plugin_dir)
    _write_skill(
        plugin_dir,
        "module_a",
        manifest_repr=(
            '{"name": "list_unread", "description": "first", '
            '"trust_tier": "do_it", "plugin": "inbox"}'
        ),
    )
    _write_skill(
        plugin_dir,
        "module_b",
        manifest_repr=(
            '{"name": "list_unread", "description": "second", '
            '"trust_tier": "do_it", "plugin": "inbox"}'
        ),
    )
    with pytest.raises(SkillManifestError, match="duplicate skill name 'list_unread'"):
        discover_skills(tmp_path)


@pytest.mark.unit
def test_module_load_import_error_chains_into_skill_manifest_error(tmp_path: Path) -> None:
    """Step 2: skill module raises during exec_module -> SkillManifestError chained."""
    plugin_dir = tmp_path / "inbox"
    _write_init(plugin_dir)
    _write_raw_skill(
        plugin_dir,
        "list_unread",
        '"""raises on import"""\nimport this_module_does_not_exist\n',
    )
    with pytest.raises(SkillManifestError, match="failed to load skill module") as exc_info:
        discover_skills(tmp_path)
    # Verify exception chaining is preserved.
    assert exc_info.value.__cause__ is not None
    assert isinstance(exc_info.value.__cause__, ImportError)
