# ersan — your office. your rules. your AI. ...and you, amplified.
# Copyright 2026 Ersan Bilik
# SPDX-License-Identifier: Apache-2.0
"""Repository invariant tests for the cross-platform `.gitattributes` file."""

from __future__ import annotations

from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[2]
GITATTRIBUTES = REPO_ROOT / ".gitattributes"


@pytest.mark.unit
def test_gitattributes_exists_with_required_content() -> None:
    """The repo-root `.gitattributes` file carries the D-016 rules verbatim."""
    source = GITATTRIBUTES.read_text(encoding="utf-8")
    required_lines = [
        "* text=auto eol=lf",
        "*.bat   text eol=crlf",
        "*.cmd   text eol=crlf",
        "*.ps1   text eol=crlf",
        "*.png   binary",
        "*.whl   binary",
        "*.exe   binary",
        "uv.lock          text eol=lf linguist-generated=true",
        "*.lock           text eol=lf linguist-generated=true",
        "CHANGELOG.md     text eol=lf linguist-generated=true",
        ".secrets.baseline text eol=lf linguist-generated=true",
    ]
    for line in required_lines:
        assert line in source, f"Missing required .gitattributes line: {line}"
