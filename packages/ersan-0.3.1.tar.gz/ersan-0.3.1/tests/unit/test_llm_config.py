# ersan — your office. your rules. your AI. ...and you, amplified.
# Copyright 2026 Ersan Bilik
# SPDX-License-Identifier: Apache-2.0
"""Unit tests for `ersan.providers.config`."""

from __future__ import annotations

from dataclasses import fields
from pathlib import Path

import pytest

from ersan.providers.config import LLMConfig, load_llm_config


@pytest.mark.unit
def test_llm_config_field_set() -> None:
    """The v0.2.0 config schema contains exactly four fields."""
    assert [field.name for field in fields(LLMConfig)] == [
        "model",
        "base_url",
        "provider",
        "api_key",
    ]


@pytest.mark.unit
def test_load_llm_config_reads_yaml_block(tmp_path: Path) -> None:
    """The loader reads the `llm:` block and ignores unknown keys."""
    config_path = tmp_path / "config.yaml"
    config_path.write_text(
        "llm:\n"
        "  provider: ollama\n"
        "  model: llama3\n"
        "  base_url: http://localhost:11434/v1\n"
        "  api_key: ''\n"
        "  ignored: value\n",
        encoding="utf-8",
    )
    assert load_llm_config(config_path) == LLMConfig(
        provider="ollama",
        model="llama3",
        base_url="http://localhost:11434/v1",
        api_key="",
    )


@pytest.mark.unit
def test_load_llm_config_missing_file_returns_defaults(tmp_path: Path) -> None:
    """A missing config file returns the default empty config."""
    assert load_llm_config(tmp_path / "missing.yaml") == LLMConfig()


@pytest.mark.unit
def test_api_key_interpolation_resolves_env_var(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """`${VAR}` resolves on the `api_key` field."""
    config_path = tmp_path / "config.yaml"
    config_path.write_text(
        "llm:\n"
        "  provider: anthropic\n"
        "  model: claude-3-5-sonnet-latest\n"
        "  api_key: ${ANTHROPIC_API_KEY}\n",
        encoding="utf-8",
    )
    monkeypatch.setenv("ANTHROPIC_API_KEY", "secret-token")
    assert load_llm_config(config_path).api_key == "secret-token"


@pytest.mark.unit
def test_api_key_interpolation_missing_env_raises_clear_error(
    tmp_path: Path,
) -> None:
    """`${MISSING}` raises a clear error naming the missing env var."""
    config_path = tmp_path / "config.yaml"
    config_path.write_text("llm:\n  api_key: ${MISSING}\n", encoding="utf-8")
    with pytest.raises(ValueError, match="api_key references missing env var: MISSING"):
        load_llm_config(config_path)


@pytest.mark.unit
def test_literal_api_key_passes_through_unchanged(tmp_path: Path) -> None:
    """Literal API-key strings pass through unchanged."""
    config_path = tmp_path / "config.yaml"
    config_path.write_text("llm:\n  api_key: literal-value\n", encoding="utf-8")
    assert load_llm_config(config_path).api_key == "literal-value"


@pytest.mark.unit
def test_interpolation_runs_only_on_api_key(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """The OQ-4 carve-out is bounded to the `api_key` field only."""
    monkeypatch.setenv("MODEL_NAME", "should-not-resolve")
    monkeypatch.setenv("BASE_URL", "http://example.com")
    monkeypatch.setenv("PROVIDER_NAME", "anthropic")
    monkeypatch.setenv("ANTHROPIC_API_KEY", "resolved-key")

    config_path = tmp_path / "config.yaml"
    config_path.write_text(
        "llm:\n"
        "  model: ${MODEL_NAME}\n"
        "  base_url: ${BASE_URL}\n"
        "  provider: ${PROVIDER_NAME}\n"
        "  api_key: ${ANTHROPIC_API_KEY}\n",
        encoding="utf-8",
    )

    config = load_llm_config(config_path)
    assert config.model == "${MODEL_NAME}"
    assert config.base_url == "${BASE_URL}"
    assert config.provider == "${PROVIDER_NAME}"
    assert config.api_key == "resolved-key"  # pragma: allowlist secret
