# ersan — your office. your rules. your AI. ...and you, amplified.
# Copyright 2026 Ersan Bilik
# SPDX-License-Identifier: Apache-2.0
"""Privacy-invariant guard test for `src/ersan/core/skills/loader.py` (US-002 / FR-G4).

The constitution's §I "Privacy by Default" is NON-NEGOTIABLE — the
skill loader makes ZERO outbound network calls. Network access (LLM
calls, M365 reads) belongs in skills, not in the loader. Rather than
rely on contributor discipline, this test mechanically reads
`src/ersan/core/skills/loader.py` as text and asserts that no
HTTP-client OR LLM-client substring appears anywhere in the file.

Mirrors `tests/unit/test_eval_no_network_imports.py` (US-001) by
design — the pattern works and the guard test deserves to be the same
shape across every load-bearing module in the project. The forbidden
list extends US-001's eight HTTP-client substrings with four LLM-client
substrings (`anthropic`, `openai` x {`import`, `from`}) per spec
FR-J3: a future contributor might think "the loader will need
Anthropic to summarize the manifest" and silently introduce a
phone-home — the guard test catches it.

US-005 note: first-party lazy imports inside the loader's adapter
functions are intentional and allowed. The guard exists to stop outbound
network and LLM client surfaces from creeping into the loader, not to
ban `ersan.policy` / `ersan.shield` from being imported on demand.
"""

from __future__ import annotations

from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[2]
LOADER_PATH = REPO_ROOT / "src" / "ersan" / "core" / "skills" / "loader.py"

FORBIDDEN_SUBSTRINGS: tuple[str, ...] = (
    "import requests",
    "import urllib",
    "import httpx",
    "import aiohttp",
    "from requests",
    "from urllib",
    "from httpx",
    "from aiohttp",
    "import anthropic",
    "from anthropic",
    "import openai",
    "from openai",
)


@pytest.mark.unit
def test_skill_loader_has_no_outbound_network_or_llm_imports() -> None:
    """FR-J1 / FR-G4: `src/ersan/core/skills/loader.py` MUST NOT import HTTP or LLM clients.

    Any of `requests`, `urllib`, `httpx`, `aiohttp` (HTTP) or
    `anthropic`, `openai` (LLM) — top-level OR `from`-imports — is
    forbidden. The loader is core, not a skill — if a real need ever
    arises, it goes through an ADR first, not a silent diff. Lazy
    first-party imports used by the default policy/shield adapters are
    explicitly in-bounds and are not what this guard is policing.
    """
    assert LOADER_PATH.is_file(), f"expected skill loader at {LOADER_PATH}"
    source = LOADER_PATH.read_text(encoding="utf-8")
    offenders = [substr for substr in FORBIDDEN_SUBSTRINGS if substr in source]
    assert not offenders, (
        f"{LOADER_PATH.relative_to(REPO_ROOT)} contains forbidden network or "
        f"LLM-client import substring(s): {offenders}. The skill loader MUST "
        "be stdlib-only (D-008, Constitution §I; LLM calls belong in skills, "
        "not in the loader)."
    )
