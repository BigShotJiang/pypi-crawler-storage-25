# ersan — your office. your rules. your AI. ...and you, amplified.
# Copyright 2026 Ersan Bilik
# SPDX-License-Identifier: Apache-2.0
"""Unit tests for `ersan.core.skills.loader.invoke` (US-002 / FR-G2).

The invocation surface is the load-bearing mechanism for Constitution
§III ("Policy Gates Every Action"). These tests assert the policy
runs BEFORE the handler, the shield runs AFTER on string output (and
ONLY on string output), the real default adapters stay wired, and
args/kwargs forward verbatim.

Tests construct `Skill` instances directly (no discovery) — invoke's
contract only depends on the `Skill` shape, and bypassing discovery
keeps these unit tests fast and focused on invoke's behavior.
"""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock

import pytest

from ersan.core.skills import (
    Skill,
    SkillPolicyDeniedError,
    invoke,
)
from ersan.core.skills import loader as skill_loader
from ersan.policy import Policy, PolicyEngine
from ersan.shield import ContentShield


def _make_skill(handler: object) -> Skill:
    """Construct a minimal valid Skill with the given handler."""
    return Skill(
        name="test_skill",
        description="A test skill.",
        trust_tier="do_it",
        plugin="test_plugin",
        handler=handler,  # type: ignore[arg-type]
        module_path=Path("/fake/path/test_skill.py"),
    )


# ---------------------------------------------------------------------------
# Policy gate.
# ---------------------------------------------------------------------------


@pytest.mark.unit
def test_invoke_calls_policy_check_with_skill() -> None:
    """FR-E2 step 1: policy_check receives the Skill argument."""
    handler = MagicMock(return_value=None)
    policy = MagicMock(return_value=True)
    skill = _make_skill(handler)
    invoke(skill, policy_check=policy)
    policy.assert_called_once_with(skill)


@pytest.mark.unit
def test_invoke_calls_handler_when_policy_allows() -> None:
    """FR-E2 step 3: allow-policy -> handler runs."""
    handler = MagicMock(return_value="ok")
    skill = _make_skill(handler)
    invoke(skill, policy_check=lambda _s: True)
    handler.assert_called_once_with()


@pytest.mark.unit
def test_invoke_raises_skill_policy_denied_error_when_policy_denies() -> None:
    """FR-E2 step 2: deny-policy -> SkillPolicyDeniedError."""
    handler = MagicMock(return_value=None)
    skill = _make_skill(handler)
    with pytest.raises(SkillPolicyDeniedError, match="policy denied invocation"):
        invoke(skill, policy_check=lambda _s: False)


@pytest.mark.unit
def test_invoke_handler_not_called_when_policy_denies() -> None:
    """FR-E2 step 2: deny-policy -> handler call count remains zero."""
    handler = MagicMock(return_value=None)
    skill = _make_skill(handler)
    with pytest.raises(SkillPolicyDeniedError):
        invoke(skill, policy_check=lambda _s: False)
    assert handler.call_count == 0


# ---------------------------------------------------------------------------
# Shield filter.
# ---------------------------------------------------------------------------


@pytest.mark.unit
def test_invoke_calls_shield_on_string_handler_output() -> None:
    """FR-E2 step 4: handler returns str -> shield_redact runs and its return is invoke's."""
    handler = MagicMock(return_value="raw output")
    shield = MagicMock(return_value="redacted output")
    skill = _make_skill(handler)
    result = invoke(skill, policy_check=lambda _s: True, shield_redact=shield)
    shield.assert_called_once_with("raw output")
    assert result == "redacted output"


@pytest.mark.unit
def test_invoke_does_not_call_shield_on_dict_output() -> None:
    """FR-E2 step 4: non-string output bypasses the shield."""
    handler = MagicMock(return_value={"k": "v"})
    shield = MagicMock(return_value="should not be called")
    skill = _make_skill(handler)
    result = invoke(skill, policy_check=lambda _s: True, shield_redact=shield)
    shield.assert_not_called()
    assert result == {"k": "v"}


@pytest.mark.unit
def test_invoke_does_not_call_shield_on_list_output() -> None:
    """FR-E2 step 4: list output bypasses the shield."""
    handler = MagicMock(return_value=[1, 2, 3])
    shield = MagicMock(return_value="should not be called")
    skill = _make_skill(handler)
    result = invoke(skill, policy_check=lambda _s: True, shield_redact=shield)
    shield.assert_not_called()
    assert result == [1, 2, 3]


@pytest.mark.unit
def test_invoke_does_not_call_shield_on_int_output() -> None:
    """FR-E2 step 4: int output bypasses the shield."""
    handler = MagicMock(return_value=42)
    shield = MagicMock(return_value="should not be called")
    skill = _make_skill(handler)
    result = invoke(skill, policy_check=lambda _s: True, shield_redact=shield)
    shield.assert_not_called()
    assert result == 42


@pytest.mark.unit
def test_invoke_does_not_call_shield_on_none_output() -> None:
    """FR-E2 step 4: None output bypasses the shield."""
    handler = MagicMock(return_value=None)
    shield = MagicMock(return_value="should not be called")
    skill = _make_skill(handler)
    result = invoke(skill, policy_check=lambda _s: True, shield_redact=shield)
    shield.assert_not_called()
    assert result is None


# ---------------------------------------------------------------------------
# Argument forwarding.
# ---------------------------------------------------------------------------


@pytest.mark.unit
def test_invoke_forwards_args_and_kwargs_to_handler() -> None:
    """FR-E5: positional and keyword args reach the handler verbatim."""
    handler = MagicMock(return_value=None)
    skill = _make_skill(handler)
    invoke(
        skill,
        "positional_arg",
        42,
        policy_check=lambda _s: True,
        keyword_arg="kw_value",
        another_kw=7,
    )
    handler.assert_called_once_with("positional_arg", 42, keyword_arg="kw_value", another_kw=7)


# ---------------------------------------------------------------------------
# Default behavior (FR-E3, FR-E4).
# ---------------------------------------------------------------------------


@pytest.mark.unit
def test_invoke_default_policy_is_fail_closed(monkeypatch: pytest.MonkeyPatch) -> None:
    """The default policy adapter denies retail `ask_first` skills."""
    handler = MagicMock(return_value="should not run")
    skill = _make_skill(handler)
    monkeypatch.setattr(skill_loader, "_DEFAULT_ENGINE", PolicyEngine(Policy()))
    with pytest.raises(SkillPolicyDeniedError):
        invoke(skill)
    assert handler.call_count == 0


@pytest.mark.unit
def test_invoke_default_shield_uses_real_content_shield(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """The default shield adapter routes through `ContentShield.scan()`."""
    handler = MagicMock(return_value="contact alice@example.com")
    skill = _make_skill(handler)
    monkeypatch.setattr(
        skill_loader,
        "_DEFAULT_ENGINE",
        PolicyEngine(Policy(tool_tiers={skill.fully_qualified_name: "do_it"})),
    )
    monkeypatch.setattr(
        skill_loader,
        "_DEFAULT_SHIELD",
        ContentShield(
            custom_patterns=[
                {
                    "pattern": r"alice@example.com",
                    "name": "email",
                    "action": "redact",
                    "message": "Email detected",
                }
            ]
        ),
    )
    result = invoke(skill)
    assert result == "contact ████"


# ---------------------------------------------------------------------------
# Exception propagation (FR-E6).
# ---------------------------------------------------------------------------


@pytest.mark.unit
def test_invoke_propagates_handler_exception() -> None:
    """FR-E6: handler raises -> exception bubbles verbatim, not wrapped."""

    class _BoomError(RuntimeError):
        pass

    def _raising_handler() -> None:
        raise _BoomError("handler exploded")

    skill = _make_skill(_raising_handler)
    with pytest.raises(_BoomError, match="handler exploded"):
        invoke(skill, policy_check=lambda _s: True)


@pytest.mark.unit
def test_invoke_propagates_policy_check_exception() -> None:
    """FR-E6: policy_check raises -> exception bubbles, NOT converted to PolicyDeniedError."""

    class _PolicyBugError(RuntimeError):
        pass

    def _bad_policy(_s: Skill) -> bool:
        raise _PolicyBugError("policy is broken")

    handler = MagicMock(return_value=None)
    skill = _make_skill(handler)
    with pytest.raises(_PolicyBugError, match="policy is broken"):
        invoke(skill, policy_check=_bad_policy)
    # Handler must not have been called when the policy itself failed.
    assert handler.call_count == 0


@pytest.mark.unit
def test_invoke_policy_check_runs_strictly_before_handler() -> None:
    """FR-E2: ordering invariant — policy is consulted before handler runs.

    Uses a shared call-order list so the assertion catches any future
    refactor that accidentally inverts policy/handler ordering (a
    Constitution §III violation).
    """
    call_order: list[str] = []

    def _policy(_s: Skill) -> bool:
        call_order.append("policy")
        return True

    def _handler() -> None:
        call_order.append("handler")

    skill = _make_skill(_handler)
    invoke(skill, policy_check=_policy)
    assert call_order == ["policy", "handler"]
