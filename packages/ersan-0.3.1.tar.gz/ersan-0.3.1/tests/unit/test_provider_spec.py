# ersan — your office. your rules. your AI. ...and you, amplified.
# Copyright 2026 Ersan Bilik
# SPDX-License-Identifier: Apache-2.0
"""Unit tests for `ersan.providers.spec`."""

from __future__ import annotations

from dataclasses import FrozenInstanceError, fields, is_dataclass

import pytest

from ersan.providers.spec import ProviderSpec


@pytest.mark.unit
def test_provider_spec_is_frozen_dataclass() -> None:
    """`ProviderSpec` is a frozen dataclass, preserving the source shape."""
    assert is_dataclass(ProviderSpec)
    spec = ProviderSpec(name="ollama")
    with pytest.raises(FrozenInstanceError):
        spec.name = "changed"  # type: ignore[misc]


@pytest.mark.unit
def test_provider_spec_field_set_matches_v020_slim() -> None:
    """The v0.2.0 port keeps only the approved slim field set."""
    assert [field.name for field in fields(ProviderSpec)] == [
        "name",
        "display_name",
        "backend",
        "default_api_base",
        "env_key",
        "is_local",
        "supports_prompt_caching",
    ]


@pytest.mark.unit
def test_provider_spec_label_prefers_display_name() -> None:
    """`label` falls back to a title-cased name when display_name is empty."""
    assert ProviderSpec(name="openai_compat").label == "Openai Compat"
    assert ProviderSpec(name="ollama", display_name="Ollama").label == "Ollama"
