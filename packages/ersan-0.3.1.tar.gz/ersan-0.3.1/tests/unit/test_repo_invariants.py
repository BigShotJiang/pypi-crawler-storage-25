# ersan — your office. your rules. your AI. ...and you, amplified.
# Copyright 2026 Ersan Bilik
# SPDX-License-Identifier: Apache-2.0
"""Repo invariants: SPDX headers and brand banner canonical shape.

Defends:
  * FR-G1 — `BANNER` is the canonical Block ASCII (not a placeholder).
  * FR-G5 — every `.py` source file MUST carry the slim SPDX header.

These tests run in the `unit` marker so they are part of the default
local + CI loop.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from ersan import BANNER

REPO_ROOT = Path(__file__).resolve().parents[2]
SRC_DIR = REPO_ROOT / "src"
TESTS_DIR = REPO_ROOT / "tests"

EXPECTED_HEADER_LINES = (
    "# ersan — your office. your rules. your AI. ...and you, amplified.",
    "# Copyright 2026 Ersan Bilik",
    "# SPDX-License-Identifier: Apache-2.0",
)


def _python_source_files() -> list[Path]:
    """Every `.py` file in `src/` and `tests/` that must carry the SPDX header."""
    files: list[Path] = []
    for root in (SRC_DIR, TESTS_DIR):
        files.extend(p for p in root.rglob("*.py") if p.is_file())
    return sorted(files)


@pytest.mark.unit
def test_every_python_file_has_spdx_header() -> None:
    """FR-G5: every `.py` source file MUST start with the slim SPDX header."""
    missing: list[str] = []
    for path in _python_source_files():
        with path.open("r", encoding="utf-8") as handle:
            first_three = tuple(handle.readline().rstrip("\n") for _ in range(3))
        if first_three != EXPECTED_HEADER_LINES:
            missing.append(str(path.relative_to(REPO_ROOT)))
    assert not missing, f"Files missing the slim SPDX header (per CONVENTIONS.md): {missing}"


@pytest.mark.unit
def test_banner_is_canonical_block_ascii() -> None:
    """FR-G1: `BANNER` MUST be the canonical Block ASCII, not a placeholder."""
    assert "█" in BANNER, (
        "BANNER is missing U+2588 FULL BLOCK — looks like a placeholder. "
        "Replace with the canonical Block ASCII shape (see CONVENTIONS.md)."
    )
    assert "╔" in BANNER and "╗" in BANNER and "╚" in BANNER and "╝" in BANNER, (
        "BANNER is missing the U+2554/2557/255A/255D box-drawing corners "
        "that mark the Block ASCII style."
    )
    lines = [line for line in BANNER.split("\n") if line.strip()]
    block_lines = [line for line in lines if "█" in line]
    assert len(block_lines) >= 5, (
        "BANNER must have at least 5 lines containing FULL BLOCK characters; "
        f"found {len(block_lines)}."
    )
