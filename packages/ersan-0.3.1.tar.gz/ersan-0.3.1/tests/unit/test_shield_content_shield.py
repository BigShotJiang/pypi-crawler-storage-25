# ersan — your office. your rules. your AI. ...and you, amplified.
# Copyright 2026 Ersan Bilik
# SPDX-License-Identifier: Apache-2.0
"""Unit tests for `ersan.shield.shield`."""

from __future__ import annotations

import pytest

from ersan.shield.shield import CONTENT_FIELDS, ContentShield
from ersan.shield.types import ScanAction


@pytest.mark.unit
def test_content_shield_defaults_to_regex_only_layers() -> None:
    """The v0.3 shield activates only the regex layer by default."""
    result = ContentShield().scan("harmless text")
    assert result.passed
    assert result.findings == []
    assert result.layers_used == ["regex"]


@pytest.mark.unit
def test_content_shield_redacts_custom_redact_findings() -> None:
    """REDACT findings replace the matched range with block characters."""
    shield = ContentShield(
        custom_patterns=[
            {
                "pattern": r"alice@example.com",
                "name": "email",
                "action": "redact",
                "message": "Email detected",
            }
        ]
    )
    result = shield.scan("Contact alice@example.com for details.")
    assert result.redacted == "Contact ████ for details."
    assert result.redactions[0].action is ScanAction.REDACT


@pytest.mark.unit
def test_content_shield_blocks_built_in_secret_patterns() -> None:
    """BLOCK findings make the scan fail closed."""
    aws_key = "AKIA" + "1234567890ABCDEF"  # pragma: allowlist secret
    result = ContentShield().scan(f"key={aws_key}")
    assert not result.passed
    assert any(finding.action is ScanAction.BLOCK for finding in result.findings)


@pytest.mark.unit
def test_content_shield_scan_tool_args_only_scans_content_fields() -> None:
    """Only the documented content fields are scanned and redacted."""
    shield = ContentShield(
        custom_patterns=[
            {
                "pattern": r"alice@example.com",
                "name": "email",
                "action": "redact",
                "message": "Email detected",
            }
        ]
    )
    result = shield.scan_tool_args(
        "inbox.reply",
        {
            "subject": "Reach alice@example.com",
            "path": "alice@example.com",
        },
    )
    assert result.redacted_args == {"subject": "Reach ████"}
    assert result.layers_used == ["regex"]
    assert all(finding.field == "subject" for finding in result.findings)
    assert "path" not in CONTENT_FIELDS


@pytest.mark.unit
def test_content_shield_guard_is_reserved_for_v0_4() -> None:
    """The source API surface remains present but intentionally unimplemented."""
    with pytest.raises(
        NotImplementedError,
        match=r"ContentShield\.guard\(\) ships in v0\.4\+ alongside make_guard\(\)",
    ):
        ContentShield().guard("inbox.reply")
