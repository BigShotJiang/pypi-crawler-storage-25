# ersan — your office. your rules. your AI. ...and you, amplified.
# Copyright 2026 Ersan Bilik
# SPDX-License-Identifier: Apache-2.0
"""Unit tests for the provider backend factories."""

from __future__ import annotations

from typing import Any

import pytest
from pydantic_ai.models.anthropic import AnthropicModel
from pydantic_ai.models.openai import OpenAIChatModel

from ersan.providers.backends.anthropic import _BETA_HEADERS
from ersan.providers.backends.anthropic import create_model as create_anthropic
from ersan.providers.backends.openai_compat import create_model as create_openai_compat
from ersan.providers.registry import find_by_name


@pytest.mark.unit
def test_openai_compat_returns_object() -> None:
    """The OpenAI-compatible factory returns an `OpenAIChatModel`."""
    spec = find_by_name("ollama")
    assert spec is not None
    model = create_openai_compat(spec, "llama3", {}, None)
    assert isinstance(model, OpenAIChatModel)
    assert str(model.client.base_url) == "http://localhost:11434/v1/"


@pytest.mark.unit
def test_anthropic_returns_object() -> None:
    """The Anthropic factory returns an `AnthropicModel` with source settings."""
    spec = find_by_name("anthropic")
    assert spec is not None
    cfg = {"api_key": "test-key"}  # pragma: allowlist secret
    model = create_anthropic(spec, "claude-3-5-sonnet-latest", cfg, None)
    assert isinstance(model, AnthropicModel)
    assert model.client.max_retries == 5
    assert model.client.default_headers["anthropic-beta"] == _BETA_HEADERS


@pytest.mark.unit
def test_anthropic_missing_key_uses_library_default_path(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Missing config key falls through to the library's env-var path."""
    spec = find_by_name("anthropic")
    assert spec is not None
    monkeypatch.setenv("ANTHROPIC_API_KEY", "env-key")
    model = create_anthropic(spec, "claude-3-5-sonnet-latest", {}, None)
    assert isinstance(model, AnthropicModel)


@pytest.mark.unit
def test_no_messages_create_called_at_construction(monkeypatch: pytest.MonkeyPatch) -> None:
    """Factory construction is lazy and does not invoke model requests."""
    openai_calls: list[tuple[tuple[Any, ...], dict[str, Any]]] = []
    anthropic_calls: list[tuple[tuple[Any, ...], dict[str, Any]]] = []

    def fail_openai(*args: Any, **kwargs: Any) -> None:
        openai_calls.append((args, kwargs))
        raise AssertionError("OpenAIChatModel.request should not run during construction")

    def fail_anthropic(*args: Any, **kwargs: Any) -> None:
        anthropic_calls.append((args, kwargs))
        raise AssertionError("AnthropicModel.request should not run during construction")

    monkeypatch.setattr(OpenAIChatModel, "request", fail_openai)
    monkeypatch.setattr(AnthropicModel, "request", fail_anthropic)

    ollama = find_by_name("ollama")
    anthropic = find_by_name("anthropic")
    assert ollama is not None
    assert anthropic is not None

    openai_model = create_openai_compat(ollama, "llama3", {}, None)
    cfg = {"api_key": "x"}  # pragma: allowlist secret
    anthropic_model = create_anthropic(anthropic, "claude-3-5-sonnet-latest", cfg, None)

    assert isinstance(openai_model, OpenAIChatModel)
    assert isinstance(anthropic_model, AnthropicModel)
    assert openai_calls == []
    assert anthropic_calls == []
