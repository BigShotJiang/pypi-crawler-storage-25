# ersan — your office. your rules. your AI. ...and you, amplified.
# Copyright 2026 Ersan Bilik
# SPDX-License-Identifier: Apache-2.0
"""Privacy-invariant integration tests for provider construction."""

from __future__ import annotations

from typing import Any

import httpx
import pytest

from ersan.providers import dispatch, find_by_name


@pytest.mark.integration
@pytest.mark.parametrize(
    ("provider_name", "model_name", "model_cfg"),
    [
        ("ollama", "llama3", {"base_url": "http://localhost:11434/v1"}),
        ("anthropic", "claude-3-5-sonnet-latest", {"api_key": "test-key"}),
    ],
)
def test_local_provider_construction_makes_no_external_calls(
    monkeypatch: pytest.MonkeyPatch,
    provider_name: str,
    model_name: str,
    model_cfg: dict[str, Any],
) -> None:
    """Constructing model clients is lazy and performs zero outbound sends."""
    requests: list[str] = []

    def fail_async_send(
        self: httpx.AsyncClient, request: httpx.Request, *args: Any, **kwargs: Any
    ) -> Any:
        requests.append(str(request.url))
        raise AssertionError(f"unexpected outbound request during construction: {request.url}")

    def fail_sync_send(
        self: httpx.Client, request: httpx.Request, *args: Any, **kwargs: Any
    ) -> Any:
        requests.append(str(request.url))
        raise AssertionError(f"unexpected outbound request during construction: {request.url}")

    monkeypatch.setattr(httpx.AsyncClient, "send", fail_async_send)
    monkeypatch.setattr(httpx.Client, "send", fail_sync_send)

    spec = find_by_name(provider_name)
    assert spec is not None
    client = dispatch(spec, model_name, model_cfg, None)
    assert client is not None
    assert requests == []
