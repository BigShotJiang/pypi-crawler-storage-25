# ersan — your office. your rules. your AI. ...and you, amplified.
# Copyright 2026 Ersan Bilik
# SPDX-License-Identifier: Apache-2.0
"""Integration tests for the loader's real default policy and shield gates."""

from __future__ import annotations

import json
from pathlib import Path
from textwrap import dedent
from time import monotonic_ns

import pytest

from ersan.core.skills import loader as skill_loader
from ersan.core.skills.loader import Skill, SkillPolicyDeniedError
from ersan.policy import config as policy_config
from ersan.policy import engine as policy_engine
from ersan.shield import ShieldBlocked
from ersan.shield import shield as shield_module

_SCRATCH_DIR = Path(__file__).resolve().parents[2] / ".tmp-loader-integration"
_SCRATCH_DIR.mkdir(exist_ok=True)


def _make_skill(name: str, handler: object) -> Skill:
    """Construct a minimal valid skill for loader integration tests."""
    return Skill(
        name=name,
        description="Integration fixture skill.",
        trust_tier="do_it",
        plugin="test_plugin",
        handler=handler,  # type: ignore[arg-type]
        module_path=Path("/fixture/test_plugin.py"),
    )


def _fake_home(prefix: str) -> Path:
    """Return a unique fake home directory under the repo scratch area."""
    home = _SCRATCH_DIR / f"{prefix}-{monotonic_ns()}"
    home.mkdir(parents=True, exist_ok=True)
    return home


def _patch_fake_home(monkeypatch: pytest.MonkeyPatch, fake_home: Path) -> None:
    """Route both policy loading and audit logging through the fake home."""
    monkeypatch.setattr(skill_loader.Path, "home", lambda: fake_home)
    monkeypatch.setattr(policy_config.Path, "home", lambda: fake_home)


def _reset_loader_singletons(monkeypatch: pytest.MonkeyPatch) -> None:
    """Reset lazy loader singletons between integration tests."""
    monkeypatch.setattr(skill_loader, "_DEFAULT_ENGINE", None)
    monkeypatch.setattr(skill_loader, "_DEFAULT_SHIELD", None)


def _write_user_policy(fake_home: Path, tool_name: str, tier: str = "do_it") -> None:
    """Write a user override policy for the given tool."""
    policy_dir = fake_home / ".ersan"
    policy_dir.mkdir(parents=True, exist_ok=True)
    (policy_dir / "policy.yaml").write_text(
        dedent(
            f"""
            defaults:
              tier: ask_first
            tools:
              {tool_name}: {tier}
            """
        ).strip()
        + "\n",
        encoding="utf-8",
    )


@pytest.mark.integration
def test_default_policy_check_invokes_engine_and_denies_by_default(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Default invoke path calls the real policy engine and denies ask_first."""
    fake_home = _fake_home("deny-home")
    _patch_fake_home(monkeypatch, fake_home)
    _reset_loader_singletons(monkeypatch)

    calls: list[str] = []
    original_evaluate = policy_engine.PolicyEngine.evaluate

    def _spy_evaluate(self: policy_engine.PolicyEngine, *args: object, **kwargs: object) -> object:
        tool_name = kwargs.get("tool", args[0] if args else "")
        calls.append(str(tool_name))
        return original_evaluate(self, *args, **kwargs)

    monkeypatch.setattr(policy_engine.PolicyEngine, "evaluate", _spy_evaluate)

    skill = _make_skill("default_deny", lambda: "hello")
    with pytest.raises(SkillPolicyDeniedError):
        skill_loader.invoke(skill)

    assert calls == [skill.fully_qualified_name]
    audit_log = fake_home / ".ersan" / "audit.log"
    assert audit_log.is_file()
    entry = json.loads(audit_log.read_text(encoding="utf-8").strip().splitlines()[-1])
    assert entry["tool"] == skill.fully_qualified_name
    assert entry["decision"] == "needs_confirmation"


@pytest.mark.integration
def test_default_shield_invokes_real_content_shield_for_allowed_skill(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Default invoke path calls the real shield when policy allows the skill."""
    fake_home = _fake_home("allow-home")
    _patch_fake_home(monkeypatch, fake_home)

    skill = _make_skill("allow_message", lambda: "Hello, ersan!")
    _write_user_policy(fake_home, skill.fully_qualified_name, tier="do_it")
    _reset_loader_singletons(monkeypatch)

    calls: list[str] = []
    original_scan = shield_module.ContentShield.scan

    def _spy_scan(self: shield_module.ContentShield, text: str) -> object:
        calls.append(text)
        return original_scan(self, text)

    monkeypatch.setattr(shield_module.ContentShield, "scan", _spy_scan)

    assert skill_loader.invoke(skill) == "Hello, ersan!"
    assert calls == ["Hello, ersan!"]


@pytest.mark.integration
def test_default_shield_block_action_raises_shield_blocked(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """BLOCK findings from the real shield raise `ShieldBlocked`."""
    fake_home = _fake_home("block-home")
    _patch_fake_home(monkeypatch, fake_home)

    skill = _make_skill("echo_secret", lambda: "key=" + "AKIA" + "1234567890ABCDEF")
    _write_user_policy(fake_home, skill.fully_qualified_name, tier="do_it")
    _reset_loader_singletons(monkeypatch)

    with pytest.raises(ShieldBlocked) as exc_info:
        skill_loader.invoke(skill)

    assert exc_info.value.result.blocks
    assert exc_info.value.result.blocks[0].subtype == "aws_key"
