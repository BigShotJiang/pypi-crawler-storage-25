# ersan — your office. your rules. your AI. ...and you, amplified.
# Copyright 2026 Ersan Bilik
# SPDX-License-Identifier: Apache-2.0
"""Shared pytest fixtures for the ersan test suite.

Intentionally empty at this stage. Fixture additions land with the user
stories that need them. The `ersan` package is importable through the
editable install produced by `uv sync`; no `sys.path` manipulation is
required (and adding it would mask packaging regressions, weakening the
signal for FR-A2 / FR-A3 in spec.md).
"""

from __future__ import annotations
