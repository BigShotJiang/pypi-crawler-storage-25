# ersan — your office. your rules. your AI. ...and you, amplified.
# Copyright 2026 Ersan Bilik
# SPDX-License-Identifier: Apache-2.0
"""Functional round-trip test for the local Ollama YAML example."""

from __future__ import annotations

from pathlib import Path

import pytest

from ersan.providers.config import LLMConfig, load_llm_config


@pytest.mark.functional
def test_config_local_yaml_roundtrip(tmp_path: Path) -> None:
    """The README's local Ollama example loads into `LLMConfig` unchanged."""
    config_path = tmp_path / "config.yaml"
    config_path.write_text(
        "llm:\n  provider: ollama\n  model: llama3\n  base_url: http://localhost:11434/v1\n",
        encoding="utf-8",
    )
    assert load_llm_config(config_path) == LLMConfig(
        provider="ollama",
        model="llama3",
        base_url="http://localhost:11434/v1",
        api_key="",
    )
