# ersan — your office. your rules. your AI. ...and you, amplified.
# Copyright 2026 Ersan Bilik
# SPDX-License-Identifier: Apache-2.0
"""End-to-end smoke test for the eval harness (US-001 / FR-F2).

Runs the full harness against every checked-in placeholder fixture under
`evals/fixtures/` and asserts the aggregate pass rate clears the 0.95
threshold from Constitution §IV. Also verifies the three placeholder
fixture ids (FR-H1) are all represented in the result.
"""

from __future__ import annotations

from pathlib import Path

import pytest
from evals.scorer import run_all

REPO_ROOT = Path(__file__).resolve().parents[2]
FIXTURES_DIR = REPO_ROOT / "evals" / "fixtures"

REQUIRED_FIXTURE_IDS: frozenset[str] = frozenset(
    {
        "inbox-summary-001",
        "tool-call-002",
        "shield-redaction-003",
    }
)


@pytest.mark.functional
def test_eval_harness_passes_against_placeholder_fixtures() -> None:
    """FR-F2: harness over the placeholder set passes the 0.95 threshold."""
    assert FIXTURES_DIR.is_dir(), f"fixtures dir missing: {FIXTURES_DIR}"
    result = run_all(FIXTURES_DIR, threshold=0.95)
    assert result.total >= 3, f"expected at least 3 fixtures (FR-H1), got {result.total}"
    assert result.pass_rate >= 0.95, (
        f"placeholder fixtures regressed: pass_rate={result.pass_rate:.2%} "
        f"(threshold=0.95). per-fixture: "
        f"{[(fx.fixture_id, fx.passed) for fx in result.fixtures]}"
    )
    discovered_ids = {fixture.fixture_id for fixture in result.fixtures}
    missing = REQUIRED_FIXTURE_IDS - discovered_ids
    assert not missing, f"required placeholder fixtures missing from discovery: {sorted(missing)}"


@pytest.mark.functional
def test_eval_harness_scorecard_schema_is_stable() -> None:
    """SC-007: scorecard top-level keys match the documented stable schema."""
    result = run_all(FIXTURES_DIR, threshold=0.95)
    scorecard = result.to_scorecard()
    expected_top_level = {"total", "passed", "failed", "pass_rate", "threshold", "fixtures"}
    assert set(scorecard.keys()) == expected_top_level, (
        f"scorecard top-level keys drifted: got {sorted(scorecard.keys())}, "
        f"expected {sorted(expected_top_level)}"
    )
    assert isinstance(scorecard["fixtures"], list)
    if scorecard["fixtures"]:
        per_fixture = scorecard["fixtures"][0]
        expected_fixture_keys = {"id", "passed", "scorer_results"}
        assert set(per_fixture.keys()) == expected_fixture_keys, (
            f"per-fixture keys drifted: got {sorted(per_fixture.keys())}, "
            f"expected {sorted(expected_fixture_keys)}"
        )
