# ersan — your office. your rules. your AI. ...and you, amplified.
# Copyright 2026 Ersan Bilik
# SPDX-License-Identifier: Apache-2.0
"""End-to-end tests for the skill loader (US-002 / FR-G3).

Exercises the full discover -> invoke chain against a real fake plugin
written to disk in `tmp_path`. The unit tests in
`tests/unit/test_skill_loader.py` and `tests/unit/test_skill_invoke.py`
cover the surface in isolation; this file covers the seam between
discovery and invocation, plus idempotency at the e2e layer.

Stub `policy_check` and `shield_redact` are simple lambdas; the real
ports land in US-003 and US-004 respectively.
"""

from __future__ import annotations

from pathlib import Path
from textwrap import dedent

import pytest

from ersan.core.skills import (
    Skill,
    SkillPolicyDeniedError,
    discover_skills,
    invoke,
)

SPDX_HEADER: str = (
    "# ersan — your office. your rules. your AI. ...and you, amplified.\n"
    "# Copyright 2026 Ersan Bilik\n"
    "# SPDX-License-Identifier: Apache-2.0\n"
)


def _write_plugin_with_one_skill(plugins_dir: Path) -> Path:
    """Write a fake `inbox` plugin with a single `list_unread` skill.

    The handler accepts (counter, message) and returns a
    pre-redaction string we can verify the shield filters.
    """
    plugin_dir = plugins_dir / "inbox"
    plugin_dir.mkdir(parents=True)
    (plugin_dir / "__init__.py").write_text(
        SPDX_HEADER + '"""Fake inbox plugin (e2e fixture)."""\n', encoding="utf-8"
    )
    skill_path = plugin_dir / "list_unread.py"
    skill_path.write_text(
        SPDX_HEADER
        + dedent(
            '''
            """Fake list_unread skill (e2e fixture)."""

            from __future__ import annotations

            MANIFEST = {
                "name": "list_unread",
                "description": "List unread mail (test fixture).",
                "trust_tier": "do_it",
                "plugin": "inbox",
            }


            def handler(counter, message):
                """Increment the counter and return the message verbatim."""
                counter["calls"] = counter.get("calls", 0) + 1
                return message
            '''
        ).lstrip(),
        encoding="utf-8",
    )
    return skill_path


@pytest.mark.functional
def test_e2e_discover_then_invoke_with_allow_policy_and_redacting_shield(
    tmp_path: Path,
) -> None:
    """FR-G3: full discover -> invoke chain with allow-policy + redacting shield."""
    _write_plugin_with_one_skill(tmp_path)
    skills = discover_skills(tmp_path)
    assert "inbox.list_unread" in skills
    skill = skills["inbox.list_unread"]
    assert isinstance(skill, Skill)

    counter: dict[str, int] = {}
    redacted = invoke(
        skill,
        counter,
        "Contact alice.example@example.invalid",
        policy_check=lambda _s: True,
        shield_redact=lambda s: s.replace("alice.example@example.invalid", "[REDACTED]"),
    )
    assert counter["calls"] == 1
    assert redacted == "Contact [REDACTED]"


@pytest.mark.functional
def test_e2e_discover_then_invoke_with_deny_policy_raises(tmp_path: Path) -> None:
    """FR-G3: deny-policy at the e2e layer raises and handler is not called."""
    _write_plugin_with_one_skill(tmp_path)
    skill = discover_skills(tmp_path)["inbox.list_unread"]
    counter: dict[str, int] = {}
    with pytest.raises(SkillPolicyDeniedError):
        invoke(
            skill,
            counter,
            "any message",
            policy_check=lambda _s: False,
        )
    assert counter.get("calls", 0) == 0


@pytest.mark.functional
def test_e2e_discover_idempotent_across_two_calls(tmp_path: Path) -> None:
    """FR-C4 at the e2e layer: two consecutive discover calls return equivalent mappings."""
    _write_plugin_with_one_skill(tmp_path)
    first = discover_skills(tmp_path)
    second = discover_skills(tmp_path)
    assert set(first) == set(second)
    for fqn in first:
        a, b = first[fqn], second[fqn]
        assert a.name == b.name
        assert a.description == b.description
        assert a.trust_tier == b.trust_tier
        assert a.plugin == b.plugin
        assert a.module_path == b.module_path
