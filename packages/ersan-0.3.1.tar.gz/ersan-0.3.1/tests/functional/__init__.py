# ersan — your office. your rules. your AI. ...and you, amplified.
# Copyright 2026 Ersan Bilik
# SPDX-License-Identifier: Apache-2.0
"""Functional / end-to-end tests for the ersan suite.

Mirrors `tests/unit/` as a sibling package so pytest collection is
consistent. Tests under this directory carry the `@pytest.mark.functional`
marker (registered in `pytest.ini`).
"""

from __future__ import annotations
