# ersan — your office. your rules. your AI. ...and you, amplified.
# Copyright 2026 Ersan Bilik
# SPDX-License-Identifier: Apache-2.0
"""Functional round-trip test for the Anthropic YAML example."""

from __future__ import annotations

from pathlib import Path

import pytest

from ersan.providers.config import LLMConfig, load_llm_config


@pytest.mark.functional
def test_config_anthropic_yaml_roundtrip(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """The README's Anthropic example resolves `${ANTHROPIC_API_KEY}`."""
    monkeypatch.setenv("ANTHROPIC_API_KEY", "secret-token")
    config_path = tmp_path / "config.yaml"
    config_path.write_text(
        "llm:\n"
        "  provider: anthropic\n"
        "  model: claude-3-5-sonnet-latest\n"
        "  api_key: ${ANTHROPIC_API_KEY}\n",
        encoding="utf-8",
    )
    assert load_llm_config(config_path) == LLMConfig(
        provider="anthropic",
        model="claude-3-5-sonnet-latest",
        base_url="",
        api_key="secret-token",
    )
