"""MCP tools — firmware flashing."""

from __future__ import annotations

from typing import TYPE_CHECKING, Literal

from mcp.server.fastmcp import FastMCP

if TYPE_CHECKING:
    from wisentwire import WisentWireClient

Flasher = Literal["msp430", "openocd", "st-link", "j-link"]


def register(mcp: FastMCP, client: WisentWireClient) -> None:
    """Register flash tools on the MCP server."""

    @mcp.tool()
    def flash_firmware(
        ww_id: int,
        firmware_id: int,
        flasher: Flasher,
        erase: bool = True,
        verify: bool = True,
        reset: bool = True,
        start_address: str = "0x08000000",
        timeout: int = 60,
    ) -> str:
        """Flash firmware to a WisentWire device and wait for completion.
        Use when the user wants to update device firmware.
        `flasher` is required — must be one of: 'msp430', 'openocd',
        'st-link', 'j-link'. Ask the user if unspecified."""
        job_id = client.flash(
            ww_id,
            firmware_id,
            flasher=flasher,
            erase=erase,
            verify=verify,
            reset=reset,
            start_address=start_address,
            timeout=timeout,
        )
        status = client.wait_flash_complete(ww_id, job_id)
        return f"Flash complete. Job: {job_id}, Status: {status.status}"

    @mcp.tool()
    def get_flash_status(ww_id: int, job_id: str) -> str:
        """Check the current status of a flash job."""
        status = client.get_flash_status(ww_id, job_id)
        return f"Job {status.job_id}: {status.status}"

    @mcp.tool()
    def get_flasher_logs(ww_id: int) -> str:
        """Get flasher log entries for a WisentWire device.
        Use when the user wants to debug a flash operation."""
        logs = client.get_flasher_logs(ww_id)
        if not logs:
            return "No flasher logs."
        return "\n".join(
            f"[{entry.source}] {entry.data}" for entry in logs
        )

    @mcp.tool()
    def list_firmware() -> str:
        """List all uploaded firmware binaries in the organization.
        Use when the user wants to see available firmware."""
        firmwares = client.list_firmware()
        if not firmwares:
            return "No firmware binaries found."
        return "\n".join(
            f"- {fw.filename} (id={fw.id}, target={fw.target}, status={fw.status})"
            for fw in firmwares
        )

    @mcp.tool()
    def upload_firmware(file_path: str, target: str) -> str:
        """Upload a firmware binary from a local file path.
        Target is the MCU target (e.g. 'stm32', 'nrf52')."""
        import os
        filename = os.path.basename(file_path)
        with open(file_path, "rb") as f:
            data = f.read()
        fw = client.upload_firmware(filename, data, target)
        return f"Uploaded {fw.filename} (id={fw.id}, status={fw.status.value})"

    @mcp.tool()
    def delete_firmware(firmware_id: int) -> str:
        """Delete a firmware binary by ID."""
        client.delete_firmware(firmware_id)
        return f"Firmware {firmware_id} deleted."
