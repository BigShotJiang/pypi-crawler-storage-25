"""Entry point: python -m wisent_wire_mcp"""

from wisent_wire_mcp.server import main

if __name__ == "__main__":
    main()
