# wisent-wire-mcp

MCP (Model Context Protocol) server for the [Wisent Wire](https://wisent-wire.com) hardware testing platform. Lets AI assistants interact with WisentWire devices — power control, firmware flashing, and UART communication.

## Installation

Requires Python **3.10+**. Install with [`pipx`](https://pipx.pypa.io) —
it puts the MCP server in an isolated environment and adds the
`wisent-wire-mcp` binary to your `PATH`.

### 1. Install `pipx` (one-time)

```bash
# macOS
brew install pipx
pipx ensurepath

# Linux / WSL
python3 -m pip install --user pipx
python3 -m pipx ensurepath
```

Open a new terminal so the updated `PATH` is picked up.

### 2. Install the MCP server

```bash
pipx install wisent-wire-mcp
```

Verify:

```bash
which wisent-wire-mcp         # ~/.local/bin/wisent-wire-mcp (or similar)
```

### 3. Upgrade / uninstall

```bash
pipx upgrade   wisent-wire-mcp
pipx uninstall wisent-wire-mcp
```

## Configuration

### `.mcp.json` location

Claude Code reads MCP servers from `.mcp.json`. Two scopes:

| Scope | Path | When to use |
|-------|------|-------------|
| **Project** | `<repo-root>/.mcp.json` | Shared with the project (checked into VCS or per-repo) |
| **User** | `~/.claude.json` under the `mcpServers` key | Available in every Claude Code session for this user |

Claude Desktop uses a separate file:

| Platform | Path |
|----------|------|
| macOS | `~/Library/Application Support/Claude/claude_desktop_config.json` |
| Windows | `%APPDATA%\Claude\claude_desktop_config.json` |
| Linux | `~/.config/Claude/claude_desktop_config.json` |

### Example `.mcp.json`

```json
{
  "mcpServers": {
    "wisent-wire": {
      "command": "wisent-wire-mcp",
      "env": {
        "WISENT_WIRE_URL": "https://int.wisent-wire.com",
        "WISENT_WIRE_EMAIL": "user@company.com",
        "WISENT_WIRE_PASSWORD": "..."
      }
    }
  }
}
```

After editing `.mcp.json`, restart Claude Code (or reload the window)
for the server to be picked up.

### Environment variables

| Variable | Required | Description |
|----------|----------|-------------|
| `WISENT_WIRE_URL` | No | API base URL (default: `https://int.wisent-wire.com`) |
| `WISENT_WIRE_EMAIL` | Yes* | Account email |
| `WISENT_WIRE_PASSWORD` | Yes* | Account password |
| `WISENT_WIRE_TOKEN` | Yes* | API token (alternative to email/password) |
| `WISENT_WIRE_LOCAL` | No | Set to `1` for local development mode |

\* Provide either `TOKEN` or `EMAIL` + `PASSWORD`.

### Available tools

#### Device

| Tool | Description |
|------|-------------|
| `list_wisentwires` | List all WisentWire devices |
| `get_ww_status` | Get current device status |
| `check_ww_available` | Check if a device is available |
| `power_on` / `power_off` | Control power supply |
| `get_telemetry` | Recent voltage/current readings |

#### Work Setup

| Tool | Description |
|------|-------------|
| `get_work_setup` | Get a device's work setup |
| `create_work_setup` | Create a work setup |
| `update_work_setup` | Update a work setup |
| `delete_work_setup` | Delete a work setup |

#### Firmware & Flashing

| Tool | Description |
|------|-------------|
| `list_firmware` | List firmware binaries |
| `upload_firmware` | Upload a firmware binary |
| `delete_firmware` | Delete a firmware binary |
| `flash_firmware` | Flash firmware to a device (msp430/openocd/st-link/j-link) |
| `get_flash_status` | Check flash job status |
| `get_flasher_logs` | Get flasher debug logs |

#### UART

| Tool | Description |
|------|-------------|
| `send_uart_command` | Send a text command over UART |
| `send_uart_hex` | Send raw hex bytes over UART |
| `get_uart_log` | Get TX/RX message history |

#### Frame Definitions

| Tool | Description |
|------|-------------|
| `list_frame_definitions` | List all frame definitions |
| `get_frame_definition` | Get a frame definition with fields |
| `create_frame_definition` | Create a new frame definition |
| `update_frame_definition` | Update a frame definition |
| `delete_frame_definition` | Delete a frame definition |

#### Commands

| Tool | Description |
|------|-------------|
| `list_commands` | List commands for a frame definition |
| `create_command` | Create a command |
| `update_command` | Update a command |
| `delete_command` | Delete a command |

#### Reservations

| Tool | Description |
|------|-------------|
| `list_reservations` | List reservations |
| `get_reservation` | Get a single reservation |
| `create_reservation` | Create a reservation |
| `delete_reservation` | Delete a reservation |


## Development

```bash
pip install -e ".[dev]"
pytest tests/ -v
ruff check src/ tests/
```

## License

MIT
