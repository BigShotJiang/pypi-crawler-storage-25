"""Tests for WisentWire listing and status tools."""

from __future__ import annotations

from tests.helpers import ToolCapture, make_shadow, make_ww
from wisent_wire_mcp.tools_ww import register


def _register(client, capture: ToolCapture) -> dict:
    register(capture, client)
    return capture.tools


def test_list_wisentwires(mock_client, capture):
    mock_client.list_wisentwires.return_value = [
        make_ww(id=1, name="alpha"),
        make_ww(id=2, name="beta", status="OFFLINE", virtual=True),
    ]
    tools = _register(mock_client, capture)
    result = tools["list_wisentwires"]()

    assert "alpha" in result
    assert "id=1" in result
    assert "beta" in result
    assert "OFFLINE" in result
    assert "virtual=True" in result


def test_list_wisentwires_empty(mock_client, capture):
    mock_client.list_wisentwires.return_value = []
    tools = _register(mock_client, capture)

    assert tools["list_wisentwires"]() == "No WisentWire devices found."


def test_check_ww_available_true(mock_client, capture):
    mock_client.is_wisentwire_available.return_value = True
    tools = _register(mock_client, capture)
    assert "available" in tools["check_ww_available"](ww_id=1)
    assert "not" not in tools["check_ww_available"](ww_id=1)


def test_check_ww_available_false(mock_client, capture):
    mock_client.is_wisentwire_available.return_value = False
    tools = _register(mock_client, capture)
    assert "not available" in tools["check_ww_available"](ww_id=1)


def test_get_ww_status_virtual(mock_client, capture):
    mock_client.get_wisentwire.return_value = make_ww(virtual=True)
    tools = _register(mock_client, capture)

    result = tools["get_ww_status"](ww_id=1)
    assert "Virtual: True" in result
    mock_client.get_shadow.assert_not_called()


def test_get_ww_status_physical(mock_client, capture):
    mock_client.get_wisentwire.return_value = make_ww()
    mock_client.get_shadow.return_value = make_shadow(voltage=5.0)
    tools = _register(mock_client, capture)

    result = tools["get_ww_status"](ww_id=1)
    assert "Power: ON" in result
    assert "5.0V" in result
