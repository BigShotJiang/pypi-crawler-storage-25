"""Tests for UART communication tools."""

from __future__ import annotations

from tests.helpers import ToolCapture, make_uart_msg
from wisent_wire_mcp.tools_uart import register


def _register(client, capture: ToolCapture) -> dict:
    register(capture, client)
    return capture.tools


def test_send_uart_command(mock_client, capture):
    mock_client.wait_for_uart_rx.return_value = make_uart_msg(hex_bytes="4f4b0a")
    tools = _register(mock_client, capture)

    result = tools["send_uart_command"](ww_id=1, command="AT")
    assert "4f4b0a" in result
    assert "OK" in result
    mock_client.send_uart_ascii.assert_called_once_with(1, "AT\n")


def test_send_uart_command_preserves_newline(mock_client, capture):
    mock_client.wait_for_uart_rx.return_value = make_uart_msg()
    tools = _register(mock_client, capture)

    tools["send_uart_command"](ww_id=1, command="AT\n")
    mock_client.send_uart_ascii.assert_called_once_with(1, "AT\n")


def test_send_uart_hex(mock_client, capture):
    mock_client.wait_for_uart_rx.return_value = make_uart_msg(hex_bytes="ff01")
    tools = _register(mock_client, capture)

    result = tools["send_uart_hex"](ww_id=1, hex_data="aa55")
    assert "ff01" in result
    mock_client.send_uart.assert_called_once_with(1, "aa55")


def test_get_uart_log(mock_client, capture):
    mock_client.get_uart_messages.return_value = [
        make_uart_msg(direction="TX", hex_bytes="4154"),
        make_uart_msg(direction="RX", hex_bytes="4f4b"),
    ]
    tools = _register(mock_client, capture)

    result = tools["get_uart_log"](ww_id=1)
    assert "[TX]" in result
    assert "[RX]" in result
    assert "4f4b" in result


def test_get_uart_log_empty(mock_client, capture):
    mock_client.get_uart_messages.return_value = []
    tools = _register(mock_client, capture)

    assert tools["get_uart_log"](ww_id=1) == "No UART messages."
