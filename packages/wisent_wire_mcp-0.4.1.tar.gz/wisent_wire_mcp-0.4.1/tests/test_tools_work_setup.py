"""Tests for work setup tools."""

from __future__ import annotations

from types import SimpleNamespace

from tests.helpers import ToolCapture
from wisent_wire_mcp.tools_work_setup import register


def _register(client, capture: ToolCapture) -> dict:
    register(capture, client)
    return capture.tools


def _make_work_setup(
    *, id: int = 1, ww_id: int = 1, name: str = "default",
    target_mcu: str = "STM32F407", description: str | None = None,
    power_supply_address: str | None = None, frame_definition_id: int | None = None,
) -> SimpleNamespace:
    return SimpleNamespace(
        id=id, wisent_wire_id=ww_id, name=name, target_mcu=target_mcu,
        description=description, power_supply_address=power_supply_address,
        frame_definition_id=frame_definition_id,
    )


def test_get_work_setup(mock_client, capture):
    mock_client.get_work_setup.return_value = _make_work_setup(
        description="dev config", power_supply_address="GPIB::1",
    )
    tools = _register(mock_client, capture)

    result = tools["get_work_setup"](ww_id=1)
    assert "STM32F407" in result
    assert "dev config" in result
    assert "GPIB::1" in result


def test_create_work_setup(mock_client, capture):
    mock_client.create_work_setup.return_value = _make_work_setup(id=3)
    tools = _register(mock_client, capture)

    result = tools["create_work_setup"](ww_id=1, name="test", target_mcu="NRF52")
    assert "id=3" in result
    mock_client.create_work_setup.assert_called_once_with(1, "test", "NRF52")


def test_create_work_setup_with_optionals(mock_client, capture):
    mock_client.create_work_setup.return_value = _make_work_setup(id=4, description="full")
    tools = _register(mock_client, capture)

    tools["create_work_setup"](
        ww_id=1, name="full", target_mcu="STM32", description="full",
        power_supply_address="GPIB::2", frame_definition_id=5,
    )
    mock_client.create_work_setup.assert_called_once_with(
        1, "full", "STM32",
        description="full", power_supply_address="GPIB::2", frame_definition_id=5,
    )


def test_update_work_setup(mock_client, capture):
    mock_client.update_work_setup.return_value = _make_work_setup(name="updated")
    tools = _register(mock_client, capture)

    result = tools["update_work_setup"](ww_id=1, name="updated", target_mcu="STM32F407")
    assert "updated" in result


def test_delete_work_setup(mock_client, capture):
    tools = _register(mock_client, capture)
    result = tools["delete_work_setup"](ww_id=3)
    assert "3" in result
    mock_client.delete_work_setup.assert_called_once_with(3)
