"""Tests for frame definition command tools."""

from __future__ import annotations

from types import SimpleNamespace

from tests.helpers import ToolCapture
from wisent_wire_mcp.tools_commands import register


def _register(client, capture: ToolCapture) -> dict:
    register(capture, client)
    return capture.tools


def _make_command(*, id: int = 1, name: str = "ping", fields: int = 1) -> SimpleNamespace:
    return SimpleNamespace(
        id=id, name=name,
        field_values=[
            SimpleNamespace(field_name=f"f{i}", hex_value="AA")
            for i in range(fields)
        ],
    )


def test_list_commands(mock_client, capture):
    mock_client.list_commands.return_value = [
        _make_command(id=1, name="ping"),
        _make_command(id=2, name="reset", fields=3),
    ]
    tools = _register(mock_client, capture)

    result = tools["list_commands"](frame_def_id=1)
    assert "ping" in result
    assert "reset" in result
    assert "fields=3" in result


def test_list_commands_empty(mock_client, capture):
    mock_client.list_commands.return_value = []
    tools = _register(mock_client, capture)
    assert tools["list_commands"](frame_def_id=1) == "No commands defined."


def test_create_command(mock_client, capture):
    mock_client.create_command.return_value = _make_command(id=5, name="new_cmd")
    tools = _register(mock_client, capture)

    result = tools["create_command"](frame_def_id=1, name="new_cmd")
    assert "id=5" in result
    mock_client.create_command.assert_called_once_with(1, "new_cmd", None)


def test_create_command_with_fields(mock_client, capture):
    mock_client.create_command.return_value = _make_command(id=6, name="cmd2")
    tools = _register(mock_client, capture)

    fv = '[{"fieldName": "header", "hexValue": "FF"}]'
    tools["create_command"](frame_def_id=1, name="cmd2", field_values_json=fv)
    mock_client.create_command.assert_called_once_with(
        1, "cmd2", [{"fieldName": "header", "hexValue": "FF"}],
    )


def test_update_command(mock_client, capture):
    mock_client.update_command.return_value = _make_command(name="renamed")
    tools = _register(mock_client, capture)

    result = tools["update_command"](frame_def_id=1, command_id=2, name="renamed")
    assert "renamed" in result


def test_delete_command(mock_client, capture):
    tools = _register(mock_client, capture)
    result = tools["delete_command"](frame_def_id=1, command_id=3)
    assert "3" in result
    mock_client.delete_command.assert_called_once_with(1, 3)
