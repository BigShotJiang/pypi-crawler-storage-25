"""Tests for frame definition tools."""

from __future__ import annotations

from types import SimpleNamespace

from tests.helpers import ToolCapture
from wisent_wire_mcp.tools_frame_defs import register


def _register(client, capture: ToolCapture) -> dict:
    register(capture, client)
    return capture.tools


def _make_frame_def(
    *, id: int = 1, name: str = "proto-v1", data_type: str = "HEX", fields: int = 3,
) -> SimpleNamespace:
    return SimpleNamespace(
        id=id, name=name,
        data_type=SimpleNamespace(value=data_type),
        fields=[
            SimpleNamespace(
                name=f"field_{i}", field_order=i,
                category=SimpleNamespace(value="CONSTANT"), size=2,
            )
            for i in range(fields)
        ],
    )


def test_list_frame_definitions(mock_client, capture):
    mock_client.list_frame_definitions.return_value = [
        _make_frame_def(id=1, name="proto-v1"),
        _make_frame_def(id=2, name="proto-v2", data_type="ASCII"),
    ]
    tools = _register(mock_client, capture)

    result = tools["list_frame_definitions"]()
    assert "proto-v1" in result
    assert "proto-v2" in result
    assert "ASCII" in result


def test_list_frame_definitions_empty(mock_client, capture):
    mock_client.list_frame_definitions.return_value = []
    tools = _register(mock_client, capture)
    assert tools["list_frame_definitions"]() == "No frame definitions found."


def test_get_frame_definition(mock_client, capture):
    mock_client.get_frame_definition.return_value = _make_frame_def(fields=2)
    tools = _register(mock_client, capture)

    result = tools["get_frame_definition"](frame_def_id=1)
    assert "proto-v1" in result
    assert "field_0" in result
    assert "field_1" in result


def test_create_frame_definition(mock_client, capture):
    mock_client.create_frame_definition.return_value = _make_frame_def(id=5, name="new")
    tools = _register(mock_client, capture)

    fields_json = '[{"name": "header", "fieldOrder": 0, "category": "CONSTANT", "size": 1}]'
    result = tools["create_frame_definition"](name="new", fields_json=fields_json)
    assert "id=5" in result


def test_update_frame_definition(mock_client, capture):
    mock_client.update_frame_definition.return_value = _make_frame_def(name="updated")
    tools = _register(mock_client, capture)

    result = tools["update_frame_definition"](frame_def_id=1, name="updated", fields_json="[]")
    assert "updated" in result


def test_delete_frame_definition(mock_client, capture):
    tools = _register(mock_client, capture)
    result = tools["delete_frame_definition"](frame_def_id=3)
    assert "3" in result
    mock_client.delete_frame_definition.assert_called_once_with(3)
