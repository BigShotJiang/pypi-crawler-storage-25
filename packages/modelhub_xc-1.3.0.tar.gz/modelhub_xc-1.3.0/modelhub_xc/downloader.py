"""
Model Downloader
Handles model downloading from ModelHub
"""

import os
from typing import Optional, List
from .api_client import ModelHubAPIClient
from .gitea_client import GiteaClient
from .git_cloner import GitCloner
from .config import HF_TOKEN


class ModelDownloader:
    """模型下载器"""

    def __init__(self, api_base_url: str = "https://modelhub.org.cn/api"):
        self.api_client = ModelHubAPIClient(api_base_url)

    def download_model(
            self,
            model_id: str,
            local_dir: Optional[str] = None,
            files: Optional[List[str]] = None
    ) -> str:
        """
        下载模型

        Args:
            model_id: 模型ID，例如 'mlx-community/Qwen3-8B-bf16' 或 'Tencent-Hunyuan/HY-Embodied-0.5'
            local_dir: 本地保存目录，如果为None则使用默认目录
            files: 要下载的文件列表，如果为None则下载所有文件（仅在使用modelhub源时有效）

        Returns:
            下载后的本地目录路径
        """
        print(f"正在查询模型信息: {model_id}")

        # 从API获取模型信息
        model_info = self.api_client.get_model_info(model_id)
        source = model_info.get('source')

        print(f"模型源: {source if source else 'ModelHub'}")

        # 确定本地保存目录
        if local_dir is None:
            # 默认保存到 ~/.cache/modelhub-xc/models/{model_id}
            cache_dir = os.path.expanduser("~/.cache/modelhub-xc/models")
            local_dir = os.path.join(cache_dir, model_id)

        # 规范化source字段（统一大写，去除下划线和空格）
        normalized_source = None
        if source:
            normalized_source = source.upper().replace('_', '').replace('-', '').replace(' ', '')

        # 根据source选择不同的下载方式
        if normalized_source == "MODELSCOPE":
            # 使用git clone从ModelScope下载
            if files:
                print(f"警告: 使用git clone方式无法下载指定文件，将下载完整仓库")

            return GitCloner.clone_from_modelscope(
                model_id=model_id,
                local_dir=local_dir,
                branch="main"
            )
        elif normalized_source == "HUGGINGFACE":
            # 使用git clone从HuggingFace下载
            if files:
                print(f"警告: 使用git clone方式无法下载指定文件，将下载完整仓库")

            return GitCloner.clone_from_huggingface(
                model_id=model_id,
                local_dir=local_dir,
                branch="main",
                hf_token=HF_TOKEN
            )
        else:
            # 使用原有的Gitea API方式下载（从modelhub）
            return self._download_from_modelhub(model_id, local_dir, files, model_info)

    def _download_from_modelhub(
            self,
            model_id: str,
            local_dir: str,
            files: Optional[List[str]] = None,
            model_info: Optional[dict] = None
    ) -> str:
        """
        从ModelHub下载模型（原有逻辑）

        Args:
            model_id: 模型ID
            local_dir: 本地保存目录
            files: 要下载的文件列表
            model_info: 模型信息（如果已经获取过则传入，避免重复请求）

        Returns:
            下载后的本地目录路径
        """
        # 如果没有传入model_info，则获取
        if model_info is None:
            model_info = self.api_client.get_model_info(model_id)

        gitea_url = model_info.get('giteaUrl')

        if not gitea_url:
            raise Exception(f"模型 {model_id} 没有可用的Gitea地址")

        print(f"找到模型仓库: {gitea_url}")

        # 初始化Gitea客户端
        gitea_client = GiteaClient(gitea_url)

        # 获取默认分支
        try:
            branch = gitea_client.get_default_branch()
            print(f"使用仓库分支: {branch}")
        except Exception as e:
            branch = "main"
            print(f"获取默认分支失败，使用: {branch}")

        os.makedirs(local_dir, exist_ok=True)
        print(f"保存目录: {local_dir}")

        # 下载文件
        if files:
            # 下载指定文件
            print(f"下载指定文件: {files}")
            for file_path in files:
                local_file_path = os.path.join(local_dir, os.path.basename(file_path))
                print(f"\n下载文件: {file_path}")
                gitea_client.download_file(file_path, local_file_path, branch=branch)
                print(f"已保存到: {local_file_path}")
        else:
            # 下载所有文件
            print("下载完整模型库...")
            all_files = gitea_client.list_all_files(branch=branch)
            print(f"共找到 {len(all_files)} 个文件")

            for idx, file_info in enumerate(all_files, 1):
                file_path = file_info['path']
                local_file_path = os.path.join(local_dir, file_path)

                print(f"\n[{idx}/{len(all_files)}] 下载文件: {file_path}")
                print(f"文件大小: {file_info['size']} bytes")

                gitea_client.download_file(file_path, local_file_path, branch=branch)
                print(f"已保存到: {local_file_path}")

        print(f"\n下载完成! 模型保存在: {local_dir}")
        return local_dir
