"""
Git Cloner
Handles model cloning from different sources using git
"""

import os
import subprocess
from typing import Optional


class GitCloner:
    """Git克隆器，支持ModelScope和HuggingFace，包含Git LFS支持"""

    @staticmethod
    def _ensure_git_xet() -> bool:
        """
        确保git-xet已安装并初始化（用于hf-mirror.com）

        Returns:
            True if git-xet is available and initialized, False otherwise
        """
        try:
            # 检查git xet是否安装
            result = subprocess.run(
                ["git", "xet", "--version"],
                capture_output=True,
                text=True,
                timeout=5
            )

            if result.returncode != 0:
                return False

            # 执行 git xet install 初始化
            print("初始化 Git XET...")
            subprocess.run(
                ["git", "xet", "install"],
                check=True,
                capture_output=True,
                text=True
            )
            return True

        except (subprocess.SubprocessError, FileNotFoundError):
            return False

    @staticmethod
    def _ensure_git_lfs() -> bool:
        """
        确保Git LFS已安装并初始化

        Returns:
            True if git-lfs is available and initialized, False otherwise
        """
        try:
            # 检查git lfs是否安装
            result = subprocess.run(
                ["git", "lfs", "version"],
                capture_output=True,
                text=True,
                timeout=5
            )

            if result.returncode != 0:
                return False

            # 执行 git lfs install 初始化
            print("初始化 Git LFS...")
            subprocess.run(
                ["git", "lfs", "install"],
                check=True,
                capture_output=True,
                text=True
            )
            return True

        except (subprocess.SubprocessError, FileNotFoundError):
            return False

    @staticmethod
    def clone_from_modelscope(
            model_id: str,
            local_dir: str,
            branch: str = "main"
    ) -> str:
        """
        从ModelScope克隆模型

        Args:
            model_id: 模型ID，例如 'Tencent-Hunyuan/HY-Embodied-0.5'
            local_dir: 本地保存目录
            branch: 分支名，默认为 'main'

        Returns:
            克隆后的本地目录路径
        """
        # 确保Git LFS已安装和初始化
        has_lfs = GitCloner._ensure_git_lfs()
        if not has_lfs:
            print("警告: 未检测到 Git LFS，大文件可能无法正确下载")
            print("请安装 Git LFS: https://git-lfs.github.com/")
            print("安装后运行: git lfs install")

        # 构建ModelScope的git URL
        git_url = f"https://www.modelscope.cn/{model_id}.git"

        print(f"从 ModelScope 克隆模型: {model_id}")
        print(f"仓库地址: {git_url}")
        print(f"目标目录: {local_dir}")

        # 确保父目录存在
        parent_dir = os.path.dirname(local_dir)
        if parent_dir:
            os.makedirs(parent_dir, exist_ok=True)

        # 构建git clone命令
        cmd = ["git", "clone"]

        # 添加分支参数
        if branch and branch != "main":
            cmd.extend(["-b", branch])

        cmd.extend([git_url, local_dir])

        # 执行git clone (Git LFS会自动处理大文件)
        try:
            print("正在克隆仓库（包含大文件）...")
            result = subprocess.run(
                cmd,
                check=True,
                capture_output=True,
                text=True
            )
            print(result.stdout)
            print(f"克隆完成: {local_dir}")
            return local_dir
        except subprocess.CalledProcessError as e:
            error_msg = f"克隆失败: {e.stderr}"
            raise Exception(error_msg)

    @staticmethod
    def clone_from_huggingface(
            model_id: str,
            local_dir: str,
            branch: str = "main",
            hf_token: Optional[str] = None
    ) -> str:
        """
        从HuggingFace克隆模型

        Args:
            model_id: 模型ID，例如 'tiiuae/falcon-7b'
            local_dir: 本地保存目录
            branch: 分支名，默认为 'main'
            hf_token: HuggingFace token（可选）

        Returns:
            克隆后的本地目录路径
        """
        # 确保git-xet已安装和初始化（hf-mirror.com使用xet而不是lfs）
        has_xet = GitCloner._ensure_git_xet()
        if not has_xet:
            print("="*60)
            print("❌ 错误: 未检测到 git-xet")
            print("="*60)
            print("\nhf-mirror.com 使用 git-xet 处理大文件，而不是 git-lfs")
            print("\n请安装 git-xet：")
            print("  # macOS")
            print("  brew install git-xet")
            print("  git xet install")
            print("\n  # 其他系统")
            print("  参考: https://about.xethub.com/")
            print("="*60)
            raise Exception("git-xet 未安装，无法从 hf-mirror.com 下载大文件")

        # 构建HuggingFace的git URL（使用镜像）
        git_url = f"https://hf-mirror.com/{model_id}"

        print(f"从 HuggingFace 克隆模型: {model_id}")
        print(f"仓库地址: {git_url}")
        print(f"目标目录: {local_dir}")

        # 确保父目录存在
        parent_dir = os.path.dirname(local_dir)
        if parent_dir:
            os.makedirs(parent_dir, exist_ok=True)

        # 设置环境变量（如果提供了token）
        env = os.environ.copy()
        if hf_token:
            env["HF_TOKEN"] = hf_token
            print(f"使用 HF_TOKEN 进行认证")

        # 构建git clone命令
        cmd = ["git", "clone"]

        # 添加分支参数
        if branch and branch != "main":
            cmd.extend(["-b", branch])

        cmd.extend([git_url, local_dir])

        # 执行git clone (git-xet会自动处理大文件)
        try:
            print("正在克隆仓库（包含大文件，使用git-xet）...")
            result = subprocess.run(
                cmd,
                env=env,
                check=True,
                capture_output=True,
                text=True
            )
            print(result.stdout)
            print(f"克隆完成: {local_dir}")
            return local_dir
        except subprocess.CalledProcessError as e:
            error_msg = f"克隆失败: {e.stderr}"
            raise Exception(error_msg)

    @staticmethod
    def clone_model(
            model_id: str,
            source: str,
            local_dir: str,
            branch: str = "main",
            hf_token: Optional[str] = None
    ) -> str:
        """
        根据source参数克隆模型

        Args:
            model_id: 模型ID
            source: 模型源，可选值: 'ModelScope', 'HuggingFace'
            local_dir: 本地保存目录
            branch: 分支名，默认为 'main'
            hf_token: HuggingFace token（仅在source为HuggingFace时使用）

        Returns:
            克隆后的本地目录路径
        """
        if source == "ModelScope":
            return GitCloner.clone_from_modelscope(model_id, local_dir, branch)
        elif source == "HuggingFace":
            return GitCloner.clone_from_huggingface(model_id, local_dir, branch, hf_token)
        else:
            raise ValueError(f"不支持的模型源: {source}，支持的源: ModelScope, HuggingFace")
