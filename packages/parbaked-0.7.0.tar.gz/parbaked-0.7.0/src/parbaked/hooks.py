"""Lifecycle hooks.

Pass callbacks to :class:`Parbaked` to react to signup events (analytics,
Slack notifications, etc.). Callbacks are invoked synchronously after the
database has been updated; exceptions are logged and swallowed so user code
can't break the auth flow.

Example::

    def notify_slack(user):
        requests.post(SLACK_URL, json={"text": f"{user.email} signed up"})

    parbaked = Parbaked(app, on_signup=notify_slack)
"""

from __future__ import annotations

import logging
from collections.abc import Callable
from dataclasses import dataclass

from parbaked.auth.models import User

logger = logging.getLogger("parbaked.hooks")


UserCallback = Callable[[User], None]


@dataclass
class Hooks:
    """Bundle of optional lifecycle callbacks.

    All hooks receive the :class:`User` after the relevant DB mutation has been
    committed, so any state you read off ``user`` reflects the new reality.
    """

    on_signup: UserCallback | None = None
    """Fires when a new signup is created (status=pending, unverified)."""

    on_verify: UserCallback | None = None
    """Fires when a user clicks their verify link (email_verified_at set)."""

    on_approve: UserCallback | None = None
    """Fires when admin approves (status=active). Triggered by both the magic
    link AND the admin-dashboard button."""

    on_reject: UserCallback | None = None
    """Fires when admin rejects (status=rejected). Same triggers as on_approve."""

    def fire(self, event: str, user: User) -> None:
        """Invoke the named hook if present. Swallows + logs exceptions.

        ``event`` is one of "signup", "verify", "approve", "reject".
        """
        hook = getattr(self, f"on_{event}", None)
        if hook is None:
            return
        try:
            hook(user)
        except Exception:  # noqa: BLE001 — user code must not break the auth flow
            logger.exception(
                "Lifecycle hook on_%s raised; swallowed so parbaked can continue.",
                event,
            )
