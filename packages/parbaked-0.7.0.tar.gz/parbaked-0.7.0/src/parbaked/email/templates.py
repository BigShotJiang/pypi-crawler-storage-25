"""Plain-text + HTML email templates for the approval flow.

Each renderer returns an :class:`EmailMessage` with both ``body`` (text) and
``html`` set. The HTML version uses inline styles and a single ``<a>`` button
so it renders in every major email client without external CSS.

To override copy or styling, build a custom :class:`Templates` and pass it to
:func:`build_auth_router` / :class:`Parbaked`.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field
from html import escape as _esc

from parbaked.auth.models import User
from parbaked.config import ParbakedConfig
from parbaked.email.base import EmailMessage

# ---------------------------------------------------------------------------
# Shared HTML chrome — one place to tweak the look
# ---------------------------------------------------------------------------

_HTML_SHELL = """\
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{title}</title>
</head>
<body style="margin:0;padding:0;background:#f6f7f9;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;color:#1a1a1a;">
  <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" style="background:#f6f7f9;">
    <tr><td align="center" style="padding:32px 16px;">
      <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="480" style="max-width:480px;background:#ffffff;border-radius:8px;border:1px solid #e5e7eb;">
        <tr><td style="padding:32px;">
          <h1 style="margin:0 0 12px 0;font-size:18px;font-weight:600;color:#111;">{heading}</h1>
          {content}
        </td></tr>
      </table>
      <p style="margin:16px 0 0 0;font-size:12px;color:#9ca3af;">Sent by {app_name}</p>
    </td></tr>
  </table>
</body>
</html>
"""

_BUTTON = """\
<table role="presentation" cellpadding="0" cellspacing="0" border="0" style="margin:24px 0;">
  <tr><td>
    <a href="{url}" style="display:inline-block;padding:10px 20px;background:#111;color:#ffffff;text-decoration:none;border-radius:6px;font-weight:500;font-size:14px;">{label}</a>
  </td></tr>
</table>"""


def _shell(title: str, heading: str, app_name: str, content: str) -> str:
    return _HTML_SHELL.format(
        title=title, heading=heading, app_name=app_name, content=content
    )


# ---------------------------------------------------------------------------
# 1. Verify email — sent to user on signup
# ---------------------------------------------------------------------------


def render_user_verify_email(
    user: User, verify_url: str, config: ParbakedConfig
) -> EmailMessage:
    subject = f"[{config.app_name}] Confirm your email"
    body = (
        f"Hi {user.name},\n\n"
        f"Welcome to {config.app_name}! Please confirm your email address by "
        "clicking the link below:\n\n"
        f"  {verify_url}\n\n"
        f"The link expires in {config.approval_token_expiry_hours} hours.\n\n"
        "If you didn't sign up, you can ignore this email.\n"
    )
    # HTML escape every interpolated value — user.name/email are user-controlled
    # (attacker can set them at signup) and app_name is config but could contain
    # & or <. URLs are constructed from config + base64url tokens (safe alphabet)
    # but we escape them too as defence-in-depth.
    html = _shell(
        title=f"Confirm your email — {_esc(config.app_name)}",
        heading=f"Welcome to {_esc(config.app_name)}",
        app_name=_esc(config.app_name),
        content=(
            f'<p style="margin:0 0 12px 0;line-height:1.5;color:#374151;">Hi {_esc(user.name)}, please confirm your email address to finish signing up.</p>'
            + _BUTTON.format(url=_esc(verify_url, quote=True), label="Confirm email")
            + f'<p style="margin:24px 0 0 0;line-height:1.5;color:#6b7280;font-size:13px;">'
            f"The link expires in {config.approval_token_expiry_hours} hours. "
            "If you didn't sign up, you can ignore this email."
            "</p>"
        ),
    )
    return EmailMessage(to=user.email, subject=subject, body=body, html=html)


# ---------------------------------------------------------------------------
# 2. Admin approval request — sent to admin after user verifies
# ---------------------------------------------------------------------------


def render_admin_approval_request(
    user: User, approve_url: str, reject_url: str, config: ParbakedConfig
) -> EmailMessage:
    if config.admin_email is None:
        raise RuntimeError(
            "Cannot render admin approval email: PARBAKED_ADMIN_EMAIL is unset. "
            "Either set it, or stop calling this template directly — the router "
            "only invokes it when admin_email is set."
        )
    subject = f"[{config.app_name}] New signup: {user.name} ({user.email})"
    body = (
        f"A new user just signed up for {config.app_name}.\n\n"
        f"  Name:  {user.name}\n"
        f"  Email: {user.email}\n\n"
        "Approve:\n"
        f"  {approve_url}\n\n"
        "Reject:\n"
        f"  {reject_url}\n\n"
        f"Links expire in {config.approval_token_expiry_hours} hours.\n"
    )

    # Two-button HTML — approve is the primary, reject is a secondary text link
    # so the admin doesn't fat-finger the wrong one on mobile.
    # All user-controlled values are HTML-escaped — an attacker can set their
    # signup `name` / `email` arbitrarily, so embedding either un-escaped would
    # let them phish the admin (e.g. inject a fake "Approve" link to evil.com).
    html = _shell(
        title=f"New signup — {_esc(config.app_name)}",
        heading=f"New signup: {_esc(user.name)}",
        app_name=_esc(config.app_name),
        content=(
            f'<p style="margin:0 0 4px 0;color:#6b7280;font-size:13px;">Name</p>'
            f'<p style="margin:0 0 16px 0;line-height:1.5;color:#111;">{_esc(user.name)}</p>'
            f'<p style="margin:0 0 4px 0;color:#6b7280;font-size:13px;">Email</p>'
            f'<p style="margin:0 0 16px 0;line-height:1.5;color:#111;">{_esc(user.email)}</p>'
            + _BUTTON.format(url=_esc(approve_url, quote=True), label="Approve")
            + f'<p style="margin:8px 0 0 0;font-size:13px;color:#6b7280;">'
            f'Not them? <a href="{_esc(reject_url, quote=True)}" style="color:#b91c1c;text-decoration:underline;">Reject this signup</a>.'
            "</p>"
            f'<p style="margin:24px 0 0 0;line-height:1.5;color:#9ca3af;font-size:12px;">'
            f"Links expire in {config.approval_token_expiry_hours} hours."
            "</p>"
        ),
    )
    return EmailMessage(to=str(config.admin_email), subject=subject, body=body, html=html)


# ---------------------------------------------------------------------------
# 3. User approved — sent to user when admin approves
# ---------------------------------------------------------------------------


def render_user_approved(user: User, login_url: str, config: ParbakedConfig) -> EmailMessage:
    subject = f"[{config.app_name}] You're in"
    body = (
        f"Hi {user.name},\n\n"
        f"Your {config.app_name} account has been approved. "
        f"You can sign in at:\n\n  {login_url}\n\n"
        "— The team\n"
    )
    first_name = user.name.split()[0] if user.name.split() else user.name
    html = _shell(
        title=f"You're in — {_esc(config.app_name)}",
        heading=f"You're in, {_esc(first_name)}",
        app_name=_esc(config.app_name),
        content=(
            f'<p style="margin:0 0 12px 0;line-height:1.5;color:#374151;">'
            f"Your {_esc(config.app_name)} account is active. Sign in below to get started."
            "</p>"
            + _BUTTON.format(url=_esc(login_url, quote=True), label="Sign in")
        ),
    )
    return EmailMessage(to=user.email, subject=subject, body=body, html=html)


# ---------------------------------------------------------------------------
# 5. Password reset — sent in response to /auth/forgot-password
# ---------------------------------------------------------------------------


def render_password_reset_email(
    user: User, reset_url: str, config: ParbakedConfig
) -> EmailMessage:
    subject = f"[{config.app_name}] Reset your password"
    body = (
        f"Hi {user.name},\n\n"
        f"Someone requested a password reset for your {config.app_name} account. "
        "If that was you, click the link below to choose a new password:\n\n"
        f"  {reset_url}\n\n"
        f"This link expires in {config.password_reset_expiry_hours} hour(s) and "
        "can only be used once.\n\n"
        "If you didn't request this, you can safely ignore this email — your "
        "password won't change.\n"
    )
    html = _shell(
        title=f"Reset your password — {_esc(config.app_name)}",
        heading="Reset your password",
        app_name=_esc(config.app_name),
        content=(
            f'<p style="margin:0 0 12px 0;line-height:1.5;color:#374151;">'
            f"Hi {_esc(user.name)}, someone requested a password reset for your "
            f"{_esc(config.app_name)} account. Click the button below to choose a new password."
            "</p>"
            + _BUTTON.format(url=_esc(reset_url, quote=True), label="Reset password")
            + f'<p style="margin:24px 0 0 0;line-height:1.5;color:#6b7280;font-size:13px;">'
            f"This link expires in {config.password_reset_expiry_hours} hour(s) "
            "and can only be used once. If you didn't request this, you can "
            "safely ignore this email — your password won't change."
            "</p>"
        ),
    )
    return EmailMessage(to=user.email, subject=subject, body=body, html=html)


# ---------------------------------------------------------------------------
# 4. User rejected — sent to user when admin rejects
# ---------------------------------------------------------------------------


def render_user_rejected(user: User, config: ParbakedConfig) -> EmailMessage:
    subject = f"[{config.app_name}] About your signup"
    body = (
        f"Hi {user.name},\n\n"
        f"Thanks for your interest in {config.app_name}. "
        "Unfortunately we weren't able to approve your account at this time.\n\n"
        "— The team\n"
    )
    html = _shell(
        title=f"About your signup — {_esc(config.app_name)}",
        heading="About your signup",
        app_name=_esc(config.app_name),
        content=(
            f'<p style="margin:0 0 12px 0;line-height:1.5;color:#374151;">'
            f"Hi {_esc(user.name)}, thanks for your interest in {_esc(config.app_name)}. "
            "Unfortunately we weren't able to approve your account at this time."
            "</p>"
        ),
    )
    return EmailMessage(to=user.email, subject=subject, body=body, html=html)


# ---------------------------------------------------------------------------
# Templates bundle — override individual renderers if you want custom copy
# ---------------------------------------------------------------------------


@dataclass
class Templates:
    """Bundle of renderers. Pass a customised instance to override copy."""

    user_verify_email: Callable[[User, str, ParbakedConfig], EmailMessage] = field(
        default=render_user_verify_email
    )
    admin_approval_request: Callable[[User, str, str, ParbakedConfig], EmailMessage] = field(
        default=render_admin_approval_request
    )
    user_approved: Callable[[User, str, ParbakedConfig], EmailMessage] = field(
        default=render_user_approved
    )
    user_rejected: Callable[[User, ParbakedConfig], EmailMessage] = field(
        default=render_user_rejected
    )
    password_reset: Callable[[User, str, ParbakedConfig], EmailMessage] = field(
        default=render_password_reset_email
    )
