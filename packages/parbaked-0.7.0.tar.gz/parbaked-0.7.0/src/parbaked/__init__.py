"""parbaked — a par-baked starter for PoC apps.

Public API re-exports the most commonly used pieces so consumers can do:

    from parbaked import ParbakedConfig, auth_router, get_current_user
"""

__version__ = "0.7.0"

from parbaked.app import Parbaked
from parbaked.auth.deps import make_current_user
from parbaked.auth.router import build_auth_router
from parbaked.config import ParbakedConfig

__all__ = [
    "Parbaked",
    "ParbakedConfig",
    "build_auth_router",
    "make_current_user",
]
