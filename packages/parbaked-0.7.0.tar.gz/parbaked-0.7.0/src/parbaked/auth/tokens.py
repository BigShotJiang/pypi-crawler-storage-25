"""HMAC-signed magic links.

Four audiences:

- ``parbaked-approval`` — admin clicks approve/reject from the signup email
- ``parbaked-verify`` — user clicks the link confirming they own the address
- ``parbaked-admin-session`` — cookie issued by the admin login form
- ``parbaked-password-reset`` — user clicks the reset link from forgot-password

Audience-scoping means a session JWT can never be replayed as a magic link, an
approval link can never verify an email, and so on.
"""

from __future__ import annotations

from datetime import UTC, datetime, timedelta
from typing import Literal
from uuid import UUID

import jwt

from parbaked.config import ParbakedConfig

ApprovalAction = Literal["approve", "reject"]
_AUDIENCE = "parbaked-approval"
_VERIFY_AUDIENCE = "parbaked-verify"
_ADMIN_SESSION_AUDIENCE = "parbaked-admin-session"
_PASSWORD_RESET_AUDIENCE = "parbaked-password-reset"


class InvalidApprovalToken(Exception):
    """Raised when an approval magic link is forged, malformed, or expired."""


class InvalidVerifyToken(Exception):
    """Raised when an email-verification link is forged, malformed, or expired."""


class InvalidAdminSession(Exception):
    """Raised when the admin session cookie is forged, malformed, or expired."""


class InvalidPasswordResetToken(Exception):
    """Raised when a password-reset link is forged, expired, or already-used.

    "Already-used" applies because each token is bound to the user's current
    ``password_hash`` — once the password changes, every outstanding reset
    link for that account fails validation. (Same defence Django uses.)
    """


def create_approval_token(user_id: UUID, action: ApprovalAction, config: ParbakedConfig) -> str:
    secret = config.effective_approval_secret()
    if not secret:
        raise RuntimeError(
            "Cannot sign approval token: set PARBAKED_APPROVAL_TOKEN_SECRET "
            "(or PARBAKED_JWT_SECRET as a fallback)."
        )
    payload = {
        "sub": str(user_id),
        "action": action,
        "aud": _AUDIENCE,
        "iat": datetime.now(UTC),
        "exp": datetime.now(UTC)
        + timedelta(hours=config.approval_token_expiry_hours),
    }
    return jwt.encode(payload, secret, algorithm="HS256")


def verify_approval_token(token: str, config: ParbakedConfig) -> tuple[UUID, ApprovalAction]:
    secret = config.effective_approval_secret()
    try:
        payload = jwt.decode(
            token, secret, algorithms=["HS256"], audience=_AUDIENCE
        )
    except (jwt.ExpiredSignatureError, jwt.InvalidTokenError) as exc:
        raise InvalidApprovalToken(str(exc)) from exc

    action = payload.get("action")
    if action not in ("approve", "reject"):
        raise InvalidApprovalToken(f"Unknown approval action: {action!r}")

    try:
        user_id = UUID(payload["sub"])
    except (KeyError, ValueError) as exc:
        raise InvalidApprovalToken("Missing or malformed subject") from exc

    return user_id, action  # type: ignore[return-value]


def create_verify_token(user_id: UUID, config: ParbakedConfig) -> str:
    """Mint a magic link the user clicks to prove they own the email."""
    secret = config.effective_approval_secret()
    if not secret:
        raise RuntimeError(
            "Cannot sign verify token: set PARBAKED_APPROVAL_TOKEN_SECRET "
            "(or PARBAKED_JWT_SECRET as a fallback)."
        )
    payload = {
        "sub": str(user_id),
        "aud": _VERIFY_AUDIENCE,
        "iat": datetime.now(UTC),
        "exp": datetime.now(UTC)
        + timedelta(hours=config.approval_token_expiry_hours),
    }
    return jwt.encode(payload, secret, algorithm="HS256")


def verify_verify_token(token: str, config: ParbakedConfig) -> UUID:
    """Validate a verification link, returning the user_id it's for."""
    secret = config.effective_approval_secret()
    try:
        payload = jwt.decode(
            token, secret, algorithms=["HS256"], audience=_VERIFY_AUDIENCE
        )
    except (jwt.ExpiredSignatureError, jwt.InvalidTokenError) as exc:
        raise InvalidVerifyToken(str(exc)) from exc
    try:
        return UUID(payload["sub"])
    except (KeyError, ValueError) as exc:
        raise InvalidVerifyToken("Missing or malformed subject") from exc


def create_admin_session_token(config: ParbakedConfig, ttl_hours: int = 12) -> str:
    """Mint a signed cookie value for an authenticated admin session.

    Audience-scoped so it can never be replayed as a verify or approval link.
    Default 12-hour lifetime — bumps each fresh login.
    """
    secret = config.effective_approval_secret()
    if not secret:
        raise RuntimeError(
            "Cannot sign admin session: set PARBAKED_APPROVAL_TOKEN_SECRET "
            "(or PARBAKED_JWT_SECRET as a fallback)."
        )
    payload = {
        "sub": "admin",
        "aud": _ADMIN_SESSION_AUDIENCE,
        "iat": datetime.now(UTC),
        "exp": datetime.now(UTC) + timedelta(hours=ttl_hours),
    }
    return jwt.encode(payload, secret, algorithm="HS256")


def verify_admin_session_token(token: str, config: ParbakedConfig) -> None:
    """Validate a cookie value. Raises InvalidAdminSession if not OK."""
    secret = config.effective_approval_secret()
    try:
        jwt.decode(token, secret, algorithms=["HS256"], audience=_ADMIN_SESSION_AUDIENCE)
    except (jwt.ExpiredSignatureError, jwt.InvalidTokenError) as exc:
        raise InvalidAdminSession(str(exc)) from exc


def _hash_fingerprint(password_hash: str) -> str:
    """Stable, opaque marker for the user's current credential.

    Embedded in reset tokens so any successful reset invalidates every other
    outstanding reset link. The first 16 chars of a bcrypt hash include the
    salt — different per user, regenerated on each change — so this is
    enough entropy without leaking the full hash into the token claims.
    """
    return password_hash[:16]


def create_password_reset_token(
    user_id: UUID, password_hash: str, config: ParbakedConfig
) -> str:
    """Mint a one-shot reset link for the user.

    Binding the token to ``_hash_fingerprint(password_hash)`` means the link
    can only be used while the password hasn't changed — a successful reset
    rotates the hash and invalidates every outstanding reset email.
    """
    secret = config.effective_approval_secret()
    if not secret:
        raise RuntimeError(
            "Cannot sign password-reset token: set PARBAKED_APPROVAL_TOKEN_SECRET "
            "(or PARBAKED_JWT_SECRET as a fallback)."
        )
    payload = {
        "sub": str(user_id),
        "aud": _PASSWORD_RESET_AUDIENCE,
        "fp": _hash_fingerprint(password_hash),
        "iat": datetime.now(UTC),
        "exp": datetime.now(UTC)
        + timedelta(hours=config.password_reset_expiry_hours),
    }
    return jwt.encode(payload, secret, algorithm="HS256")


def verify_password_reset_token(
    token: str, password_hash: str, config: ParbakedConfig
) -> UUID:
    """Validate a reset link against the user's *current* password_hash.

    Raises :class:`InvalidPasswordResetToken` if the signature is bad, the
    token is expired, or the user's password has rotated since it was minted.
    """
    secret = config.effective_approval_secret()
    try:
        payload = jwt.decode(
            token, secret, algorithms=["HS256"], audience=_PASSWORD_RESET_AUDIENCE
        )
    except (jwt.ExpiredSignatureError, jwt.InvalidTokenError) as exc:
        raise InvalidPasswordResetToken(str(exc)) from exc
    if payload.get("fp") != _hash_fingerprint(password_hash):
        raise InvalidPasswordResetToken("Token already used or password changed.")
    try:
        return UUID(payload["sub"])
    except (KeyError, ValueError) as exc:
        raise InvalidPasswordResetToken("Missing or malformed subject") from exc
