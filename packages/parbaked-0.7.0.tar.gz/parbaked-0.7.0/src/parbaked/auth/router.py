"""FastAPI router builder: signup, verify, login, approve, reject, me."""

from __future__ import annotations

import logging
from collections.abc import Callable
from datetime import UTC, datetime
from html import escape as _esc
from uuid import UUID

import jwt
from fastapi import APIRouter, Depends, Form, HTTPException, Request, Response, status
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, EmailStr, Field
from slowapi import Limiter
from sqlmodel import Session, select

from parbaked._clientip import client_ip
from parbaked.auth.deps import make_current_user
from parbaked.auth.jwt import create_jwt
from parbaked.auth.models import User, UserStatus
from parbaked.auth.passwords import hash_password, verify_password
from parbaked.auth.tokens import (
    InvalidApprovalToken,
    InvalidPasswordResetToken,
    InvalidVerifyToken,
    create_approval_token,
    create_password_reset_token,
    create_verify_token,
    verify_approval_token,
    verify_password_reset_token,
    verify_verify_token,
)
from parbaked.config import ParbakedConfig
from parbaked.email.base import EmailMessage, EmailTransport
from parbaked.email.templates import Templates
from parbaked.hooks import Hooks
from parbaked.logging import log_event

logger = logging.getLogger("parbaked.auth")


def _safe_send(email: EmailTransport, message: EmailMessage) -> None:
    """Send an email best-effort. Log failures rather than propagate them so
    DB state changes (and hook firings) downstream of the send still happen."""
    try:
        email.send(message)
    except Exception:  # noqa: BLE001 — best-effort by design
        logger.exception("Email send failed; continuing with auth flow.")

# ---------------------------------------------------------------------------
# Request / response schemas
# ---------------------------------------------------------------------------


class SignupRequest(BaseModel):
    email: EmailStr
    name: str = Field(min_length=1, max_length=255)
    password: str = Field(min_length=8, max_length=128)


class SignupResponse(BaseModel):
    user_id: str
    status: UserStatus


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class UserPublic(BaseModel):
    id: str
    email: EmailStr
    name: str
    status: UserStatus


class LoginResponse(BaseModel):
    token: str
    user: UserPublic


class ForgotPasswordRequest(BaseModel):
    email: EmailStr


class ForgotPasswordResponse(BaseModel):
    status: str = "ok"


_RESET_FORM_HTML = """\
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Reset your password</title>
<style>
  body {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
          background: #f6f7f9; color: #111; margin: 0; padding: 0;
          min-height: 100vh; display: flex; align-items: center;
          justify-content: center; }}
  .card {{ background: white; padding: 32px; border-radius: 8px;
           border: 1px solid #e5e7eb; max-width: 360px; width: 100%; }}
  h1 {{ margin: 0 0 6px 0; font-size: 18px; }}
  .sub {{ margin: 0 0 24px 0; font-size: 13px; color: #6b7280; }}
  label {{ display: block; font-size: 13px; margin-bottom: 4px;
           margin-top: 12px; color: #374151; }}
  input {{ width: 100%; padding: 10px 12px; border: 1px solid #d1d5db;
           border-radius: 6px; font-size: 14px; box-sizing: border-box; }}
  button {{ width: 100%; padding: 10px; background: #111; color: white;
            border: 0; border-radius: 6px; font-weight: 500;
            font-size: 14px; cursor: pointer; margin-top: 16px; }}
  .err {{ color: #b91c1c; font-size: 13px; margin: 8px 0 0 0; }}
</style>
</head>
<body>
  <form method="post" action="{action}" class="card">
    <h1>Choose a new password</h1>
    <p class="sub">For {email}</p>
    {error_html}
    <label for="password">New password</label>
    <input id="password" name="password" type="password" autofocus required minlength="8">
    <label for="confirm">Confirm password</label>
    <input id="confirm" name="confirm" type="password" required minlength="8">
    <button type="submit">Set new password</button>
  </form>
</body>
</html>
"""


def _render_reset_form(action_url: str, email: str, error: str | None = None) -> str:
    error_html = f'<p class="err">{_esc(error)}</p>' if error else ""
    return _RESET_FORM_HTML.format(
        action=_esc(action_url, quote=True),
        email=_esc(email),
        error_html=error_html,
    )


# ---------------------------------------------------------------------------
# Confirmation pages (admin click-through)
# ---------------------------------------------------------------------------

_PAGE_SHELL = """\
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>{title}</title>
<style>
  body {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
          max-width: 32rem; margin: 4rem auto; padding: 0 1.5rem; color: #1a1a1a; }}
  h1 {{ font-size: 1.5rem; margin-bottom: 0.5rem; }}
  p  {{ line-height: 1.5; color: #444; }}
  .ok    {{ color: #15803d; }}
  .nope  {{ color: #b91c1c; }}
</style>
</head>
<body>
  <h1 class="{cls}">{heading}</h1>
  <p>{body}</p>
</body>
</html>
"""


def _ok_page(heading: str, body: str) -> HTMLResponse:
    """Render the success confirmation page.

    Both ``heading`` and ``body`` are HTML-escaped here so callers can pass
    raw user data (user.email, user.name) without thinking about injection.
    Anyone wanting actual markup must build their own response.
    """
    return HTMLResponse(
        _PAGE_SHELL.format(
            title=_esc(heading),
            heading=_esc(heading),
            body=_esc(body),
            cls="ok",
        )
    )


def _err_page(heading: str, body: str, status_code: int = 400) -> HTMLResponse:
    """Render the error page. Same escaping contract as :func:`_ok_page`."""
    return HTMLResponse(
        _PAGE_SHELL.format(
            title=_esc(heading),
            heading=_esc(heading),
            body=_esc(body),
            cls="nope",
        ),
        status_code=status_code,
    )


def _user_for_reset_token(token: str, session: Session) -> User | None:
    """Resolve the User a reset token claims to be for, *without* verifying.

    Validation happens in a second step against the user's live password_hash
    (see :func:`verify_password_reset_token`). We peek at the subject claim
    first to find the user, then verify; if the signature is bad both halves
    fail.
    """
    try:
        # Peek-only: disable every check. Real verification (signature, exp,
        # audience, and the per-user fingerprint) runs in the second pass via
        # verify_password_reset_token.
        payload = jwt.decode(
            token,
            options={
                "verify_signature": False,
                "verify_exp": False,
                "verify_aud": False,
                "verify_iat": False,
            },
        )
    except jwt.InvalidTokenError:
        return None
    subject = payload.get("sub")
    if not subject:
        return None
    try:
        user_uuid = UUID(subject)
    except (TypeError, ValueError):
        return None
    return session.get(User, user_uuid)


# ---------------------------------------------------------------------------
# Router builder
# ---------------------------------------------------------------------------


def build_auth_router(
    config: ParbakedConfig,
    get_session: Callable[..., Session],
    email: EmailTransport,
    *,
    limiter: Limiter | None = None,
    templates: Templates | None = None,
    hooks: Hooks | None = None,
    prefix: str = "/auth",
    tags: list[str] | None = None,
) -> APIRouter:
    """Construct the signup/login/approval router.

    Args:
        config: parbaked settings (secrets, branding, rate limits).
        get_session: FastAPI dependency yielding a SQLModel ``Session``. parbaked
            calls this via ``Depends`` — supply the same one you use elsewhere.
        email: any object implementing :class:`EmailTransport`. Use
            :class:`ConsoleEmail` for dev and tests.
        limiter: optional slowapi ``Limiter``. If omitted, rate limiting is OFF
            on these routes — fine for tests but DO NOT ship to production
            without it. Pair with :func:`install_rate_limiting`.
        templates: override the email body renderers if you want custom copy.
        prefix: URL prefix. Default ``/auth``.
        tags: OpenAPI tags. Default ``["auth"]``.
    """
    templates = templates or Templates()
    hooks = hooks or Hooks()
    current_user = make_current_user(config, get_session)
    router = APIRouter(prefix=prefix, tags=tags or ["auth"])

    # slowapi requires the decorator at definition time, so we resolve to a
    # no-op when no limiter is provided.
    def _limit(rule: str) -> Callable[[Callable], Callable]:
        if limiter is None:
            return lambda f: f
        return limiter.limit(rule)

    # ----- signup ----------------------------------------------------
    @router.post("/signup", response_model=SignupResponse, status_code=status.HTTP_201_CREATED)
    @_limit(config.ratelimit_signup)
    async def signup(
        request: Request,
        response: Response,  # noqa: ARG001 — slowapi injects rate-limit headers
        body: SignupRequest,
        session: Session = Depends(get_session),
    ) -> SignupResponse:
        # Reject duplicate emails up-front. Generic message to avoid enumeration.
        existing = session.exec(select(User).where(User.email == body.email)).first()
        if existing is not None:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="An account with that email is already registered or pending.",
            )

        user = User(
            email=body.email,
            name=body.name,
            password_hash=hash_password(body.password),
            status=UserStatus.pending,
        )
        session.add(user)
        session.commit()
        session.refresh(user)

        # Email the user a verification magic link. The admin doesn't get
        # notified until the user actually clicks through — that's how we
        # filter out junk signups before they reach the admin queue.
        verify_token = create_verify_token(user.id, config)
        verify_url = f"{config.app_url.rstrip('/')}{prefix}/verify/{verify_token}"
        _safe_send(email, templates.user_verify_email(user, verify_url, config))

        log_event("signup", user_id=str(user.id), email=user.email, ip=client_ip(request, config))
        hooks.fire("signup", user)
        return SignupResponse(user_id=str(user.id), status=user.status)

    # ----- verify email ---------------------------------------------
    @router.get("/verify/{token}", response_class=HTMLResponse)
    async def verify(
        request: Request,
        token: str,
        session: Session = Depends(get_session),
    ) -> HTMLResponse:
        try:
            user_id = verify_verify_token(token, config)
        except InvalidVerifyToken as exc:
            return _err_page("Link invalid or expired", str(exc), status_code=400)

        user = session.get(User, user_id)
        if user is None:
            return _err_page("User no longer exists", "The signup may have been deleted.", 404)
        if user.email_verified_at is not None:
            return _ok_page(
                "Already verified", f"{user.email} is already verified — awaiting approval."
            )

        user.email_verified_at = datetime.now(UTC)
        session.add(user)
        session.commit()
        session.refresh(user)

        # Now that we've proven the email is real, notify the admin.
        if config.admin_email:
            approve = create_approval_token(user.id, "approve", config)
            reject = create_approval_token(user.id, "reject", config)
            approve_url = f"{config.app_url.rstrip('/')}{prefix}/approve/{approve}"
            reject_url = f"{config.app_url.rstrip('/')}{prefix}/reject/{reject}"
            _safe_send(
                email,
                templates.admin_approval_request(user, approve_url, reject_url, config),
            )

        log_event("verify", user_id=str(user.id), email=user.email, ip=client_ip(request, config))
        hooks.fire("verify", user)
        return _ok_page(
            "Email verified",
            f"Thanks, {user.name}. {user.email} is confirmed — an admin will "
            "approve your account shortly.",
        )

    # ----- login -----------------------------------------------------
    @router.post("/login", response_model=LoginResponse)
    @_limit(config.ratelimit_login)
    async def login(
        request: Request,
        response: Response,  # noqa: ARG001
        body: LoginRequest,
        session: Session = Depends(get_session),
    ) -> LoginResponse:
        ip = client_ip(request, config)
        user = session.exec(select(User).where(User.email == body.email)).first()
        # Same response for "no user" and "wrong password" to avoid enumeration.
        if user is None or not verify_password(body.password, user.password_hash):
            log_event(
                "login.fail",
                email=body.email,
                ip=ip,
                success=False,
                extra={"reason": "invalid_credentials"},
            )
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid credentials"
            )
        if user.email_verified_at is None:
            log_event(
                "login.fail",
                user_id=str(user.id),
                email=user.email,
                ip=ip,
                success=False,
                extra={"reason": "unverified"},
            )
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Email not yet verified — check your inbox for the verification link.",
            )
        if user.status == UserStatus.pending:
            log_event(
                "login.fail",
                user_id=str(user.id),
                email=user.email,
                ip=ip,
                success=False,
                extra={"reason": "pending_approval"},
            )
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN, detail="Account awaiting approval"
            )
        if user.status == UserStatus.rejected:
            log_event(
                "login.fail",
                user_id=str(user.id),
                email=user.email,
                ip=ip,
                success=False,
                extra={"reason": "rejected"},
            )
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN, detail="Account not approved"
            )

        token = create_jwt(user.id, user.email, user.name, config)
        log_event("login.success", user_id=str(user.id), email=user.email, ip=ip)
        return LoginResponse(
            token=token,
            user=UserPublic(
                id=str(user.id), email=user.email, name=user.name, status=user.status
            ),
        )

    # ----- approve ---------------------------------------------------
    @router.get("/approve/{token}", response_class=HTMLResponse)
    async def approve(
        request: Request,
        token: str,
        session: Session = Depends(get_session),
    ) -> HTMLResponse:
        try:
            user_id, action = verify_approval_token(token, config)
        except InvalidApprovalToken as exc:
            return _err_page("Link invalid or expired", str(exc), status_code=400)
        if action != "approve":
            return _err_page("Wrong link", "This link doesn't approve.", status_code=400)

        user = session.get(User, user_id)
        if user is None:
            return _err_page("User no longer exists", "The signup may have been deleted.", 404)
        if user.status == UserStatus.active:
            return _ok_page("Already approved", f"{user.email} is already active.")

        now = datetime.now(UTC)
        user.status = UserStatus.active
        user.approved_at = now
        # Safety net: an admin clicking approve implicitly attests to the email.
        if user.email_verified_at is None:
            user.email_verified_at = now
        session.add(user)
        session.commit()
        session.refresh(user)

        login_url = f"{config.app_url.rstrip('/')}{config.login_path}"
        _safe_send(email, templates.user_approved(user, login_url, config))

        log_event(
            "approve",
            user_id=str(user.id),
            email=user.email,
            ip=client_ip(request, config),
            extra={"via": "magic_link"},
        )
        hooks.fire("approve", user)
        return _ok_page("Approved", f"{user.email} can now sign in.")

    # ----- reject ----------------------------------------------------
    @router.get("/reject/{token}", response_class=HTMLResponse)
    async def reject(
        request: Request,
        token: str,
        session: Session = Depends(get_session),
    ) -> HTMLResponse:
        try:
            user_id, action = verify_approval_token(token, config)
        except InvalidApprovalToken as exc:
            return _err_page("Link invalid or expired", str(exc), status_code=400)
        if action != "reject":
            return _err_page("Wrong link", "This link doesn't reject.", status_code=400)

        user = session.get(User, user_id)
        if user is None:
            return _err_page("User no longer exists", "The signup may have been deleted.", 404)
        if user.status == UserStatus.rejected:
            return _ok_page("Already rejected", f"{user.email} was already rejected.")

        user.status = UserStatus.rejected
        session.add(user)
        session.commit()
        session.refresh(user)

        _safe_send(email, templates.user_rejected(user, config))

        log_event(
            "reject",
            user_id=str(user.id),
            email=user.email,
            ip=client_ip(request, config),
            extra={"via": "magic_link"},
        )
        hooks.fire("reject", user)
        return _ok_page("Rejected", f"{user.email} has been rejected and notified.")

    # ----- forgot password ------------------------------------------
    @router.post(
        "/forgot-password",
        response_model=ForgotPasswordResponse,
        status_code=status.HTTP_202_ACCEPTED,
    )
    @_limit(config.ratelimit_password_reset)
    async def forgot_password(
        request: Request,
        response: Response,  # noqa: ARG001 — slowapi injects rate-limit headers
        body: ForgotPasswordRequest,
        session: Session = Depends(get_session),
    ) -> ForgotPasswordResponse:
        # Always return 202 regardless of whether the email exists, so the
        # endpoint can't be used to discover which addresses are registered.
        ip = client_ip(request, config)
        user = session.exec(select(User).where(User.email == body.email)).first()
        if user is None:
            log_event(
                "password_reset.request",
                email=body.email,
                ip=ip,
                success=False,
                extra={"reason": "unknown_email"},
            )
            return ForgotPasswordResponse()

        reset_token = create_password_reset_token(user.id, user.password_hash, config)
        reset_url = f"{config.app_url.rstrip('/')}{prefix}/reset/{reset_token}"
        _safe_send(email, templates.password_reset(user, reset_url, config))
        log_event(
            "password_reset.request",
            user_id=str(user.id),
            email=user.email,
            ip=ip,
        )
        return ForgotPasswordResponse()

    # ----- reset form (GET) -----------------------------------------
    @router.get("/reset/{token}", response_class=HTMLResponse)
    async def reset_form(
        request: Request,  # noqa: ARG001 — kept for symmetry with POST
        token: str,
        session: Session = Depends(get_session),
    ) -> HTMLResponse:
        # We need the user to validate the token (the fingerprint check needs
        # their current password_hash). Decode without verification first to
        # extract the subject, then verify against the live hash.
        user = _user_for_reset_token(token, session)
        if user is None:
            return _err_page(
                "Link invalid or expired",
                "Request a new password-reset email and try again.",
                status_code=400,
            )
        try:
            verify_password_reset_token(token, user.password_hash, config)
        except InvalidPasswordResetToken as exc:
            return _err_page("Link invalid or expired", str(exc), status_code=400)
        return HTMLResponse(_render_reset_form(f"{prefix}/reset/{token}", user.email))

    # ----- reset submit (POST) --------------------------------------
    @router.post("/reset/{token}", response_class=HTMLResponse)
    async def reset_submit(
        request: Request,
        token: str,
        password: str = Form(..., min_length=8, max_length=128),
        confirm: str = Form(..., min_length=8, max_length=128),
        session: Session = Depends(get_session),
    ) -> HTMLResponse:
        ip = client_ip(request, config)
        user = _user_for_reset_token(token, session)
        if user is None:
            log_event(
                "password_reset.fail",
                ip=ip,
                success=False,
                extra={"reason": "unknown_user"},
            )
            return _err_page("Link invalid or expired", "Request a new email.", 400)

        try:
            verify_password_reset_token(token, user.password_hash, config)
        except InvalidPasswordResetToken as exc:
            log_event(
                "password_reset.fail",
                user_id=str(user.id),
                email=user.email,
                ip=ip,
                success=False,
                extra={"reason": "invalid_token"},
            )
            return _err_page("Link invalid or expired", str(exc), 400)

        if password != confirm:
            return HTMLResponse(
                _render_reset_form(
                    f"{prefix}/reset/{token}",
                    user.email,
                    error="Passwords didn't match.",
                ),
                status_code=400,
            )

        user.password_hash = hash_password(password)
        session.add(user)
        session.commit()
        # Rotating the hash invalidates this token and any other outstanding
        # reset links for the same user. No state to clean up.

        log_event(
            "password_reset.success",
            user_id=str(user.id),
            email=user.email,
            ip=ip,
        )
        return _ok_page(
            "Password updated",
            f"{user.email} can now sign in with the new password.",
        )

    # ----- me --------------------------------------------------------
    @router.get("/me", response_model=UserPublic)
    async def me(user: User = Depends(current_user)) -> UserPublic:
        return UserPublic(id=str(user.id), email=user.email, name=user.name, status=user.status)

    return router
