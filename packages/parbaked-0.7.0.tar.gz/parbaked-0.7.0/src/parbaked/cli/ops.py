"""parbaked dev / tunnel / deploy / logs / secrets.

One cross-platform path for every dev / deploy operation. ``make`` doesn't
ship on Windows by default, so we don't use it anywhere — the same
``parbaked <command>`` works on every supported OS.
"""

from __future__ import annotations

import shutil
import subprocess
from pathlib import Path

import typer


def _require(binary: str, install_hint: str) -> None:
    """Exit with a friendly error if ``binary`` is not on PATH."""
    if shutil.which(binary) is None:
        typer.echo(f"✗ {binary} not found on PATH.", err=True)
        typer.echo(install_hint, err=True)
        raise typer.Exit(1)


def _run(cmd: list[str], *, env: dict[str, str] | None = None) -> int:
    """Run a subprocess inheriting stdio. Returns the exit code.

    Uses ``shell=False`` everywhere — argument values come from the user's
    own typer args, so we want them treated as a single token, not parsed
    by a shell.
    """
    try:
        return subprocess.run(cmd, env=env, check=False).returncode
    except KeyboardInterrupt:
        # Ctrl-C while the subprocess was running. Treat it as a clean exit
        # — the user told the process to stop, no traceback needed.
        return 0


def dev(
    port: int = typer.Option(8000, "--port", "-p", help="Port to bind"),
    host: str = typer.Option(
        "127.0.0.1",
        "--host",
        help="Host interface (default 127.0.0.1; use 0.0.0.0 for LAN access)",
    ),
    app: str = typer.Option(
        "main:app",
        "--app",
        help="ASGI app spec — ``module:variable`` (defaults to ``main:app``)",
    ),
    reload: bool = typer.Option(
        True, "--reload/--no-reload", help="Auto-reload on source changes (default on)"
    ),
) -> None:
    """Run the app locally with uvicorn auto-reload."""
    cmd = ["uvicorn", app, "--port", str(port), "--host", host]
    if reload:
        cmd.append("--reload")
    if shutil.which("uvicorn") is None:
        # Almost certainly running under uv — fall back to `uv run uvicorn`.
        if shutil.which("uv") is None:
            _require("uvicorn", "Install with: pip install uvicorn (or use uv)")
        cmd = ["uv", "run", *cmd]
    raise typer.Exit(_run(cmd))


def tunnel(
    port: int = typer.Option(8000, "--port", "-p", help="Local port to expose"),
) -> None:
    """Expose http://localhost:<port> via a cloudflared quick tunnel.

    Prints a *.trycloudflare.com URL — set ``PARBAKED_APP_URL`` to it before
    signing up so magic links resolve correctly. The URL is ephemeral and
    dies when you Ctrl-C this command.
    """
    install_hint = (
        "Install cloudflared:\n"
        "  macOS:    brew install cloudflared\n"
        "  Windows:  winget install --id Cloudflare.cloudflared\n"
        "  Linux:    https://github.com/cloudflare/cloudflared/releases"
    )
    _require("cloudflared", install_hint)
    typer.echo(
        "Tunnel starting — copy the trycloudflare.com URL and set "
        "PARBAKED_APP_URL to it."
    )
    raise typer.Exit(
        _run(["cloudflared", "tunnel", "--url", f"http://localhost:{port}"])
    )


def deploy() -> None:
    """Run ``fly deploy`` for the current directory."""
    _require(
        "fly",
        "Install flyctl: https://fly.io/docs/flyctl/install/ "
        "(or `brew install flyctl` on macOS).",
    )
    raise typer.Exit(_run(["fly", "deploy"]))


def logs() -> None:
    """Tail fly.io application logs."""
    _require("fly", "Install flyctl: https://fly.io/docs/flyctl/install/")
    raise typer.Exit(_run(["fly", "logs"]))


def secrets(
    env_file: Path = typer.Option(
        Path(".env"), "--env-file", "-e", help="Path to env file (default ./.env)"
    ),
) -> None:
    """Push every line of ``.env`` to fly secrets in one shot.

    Wraps ``fly secrets import`` which reads ``KEY=VALUE`` lines from stdin.
    """
    _require("fly", "Install flyctl: https://fly.io/docs/flyctl/install/")
    if not env_file.exists():
        typer.echo(
            f"✗ {env_file} not found — copy .env.example to .env and fill in your secrets.",
            err=True,
        )
        raise typer.Exit(1)

    typer.echo(f"Pushing {env_file} → fly secrets…")
    # `fly secrets import` reads from stdin
    try:
        with env_file.open("rb") as fh:
            rc = subprocess.run(
                ["fly", "secrets", "import"], stdin=fh, check=False
            ).returncode
    except KeyboardInterrupt:
        rc = 130
    raise typer.Exit(rc)
