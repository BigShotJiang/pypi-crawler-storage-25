# {{APP_NAME}}

A PoC built with [parbaked](https://github.com/saml7n/parbaked). Signup with admin approval, login, protected dashboard, and a deploy posture that won't run up your fly.io bill.

## Quickstart

```bash
parbaked dev
```

Then:

1. Open <http://localhost:8000> — sign up
2. Open <http://localhost:8000/auth/admin> — sign in as `admin` with the password printed in the terminal banner, approve yourself
3. Go back and log in

## What's running

- **`/`** — landing page
- **`/signup`** — signup form
- **`/login`** — login form
- **`/dashboard`** — protected page, requires a logged-in account
- **`/auth/admin`** — admin dashboard (cookie-gated)

## Sharing it locally

```bash
parbaked tunnel
```

Spins up a `cloudflared` quick tunnel — gives you a public `*.trycloudflare.com` URL with no Cloudflare account needed. Set `PARBAKED_APP_URL` to that URL before signing up so magic links resolve correctly.

## Shipping to fly.io

First time:

```bash
fly launch --copy-config --no-deploy   # claims the app name from fly.toml
parbaked secrets                       # pushes your .env to fly secrets
parbaked deploy
```

After that, just `parbaked deploy`. Tail logs with `parbaked logs`.

The included `fly.toml` is tuned for cost-safety:

- `auto_stop_machines = "stop"` + `min_machines_running = 0` → idle traffic costs nothing
- Hard concurrency cap of 200 requests/machine → a single machine can't get blown up
- `shared-cpu-1x` / 256MB — fly's cheapest tier

Before going public:

1. Set the secrets in `.env` (or pass them straight to `fly secrets set`):
   - `PARBAKED_JWT_SECRET`
   - `PARBAKED_APPROVAL_TOKEN_SECRET`
   - `PARBAKED_ADMIN_PASSWORD`
   - `PARBAKED_ADMIN_EMAIL`
   - `PARBAKED_APP_URL` (your fly URL, e.g. `https://{{APP_NAME}}.fly.dev`)
2. Set up real email — `parbaked email setup` walks you through Resend signup. Free for 3,000 emails/month, no card.
3. `parbaked secrets && parbaked deploy`
