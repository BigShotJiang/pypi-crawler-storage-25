"""Admin dashboard router.

A login form at ``/auth/admin/login`` issues a signed cookie. The cookie
gates ``/auth/admin`` (the pending / active / rejected dashboard) and the
``approve`` / ``reject`` action endpoints. The session lives in an HttpOnly,
SameSite=Lax cookie; lifetime is 12 hours.

Works even with no email configured — that's the whole point of having a web
UI alongside the magic-link flow.
"""

from __future__ import annotations

import contextlib
import secrets as _secrets
from collections.abc import Callable
from datetime import UTC, datetime
from html import escape as _esc
from uuid import UUID

from fastapi import APIRouter, Cookie, Depends, Form, HTTPException, Request, status
from fastapi.responses import HTMLResponse, RedirectResponse, Response
from sqlmodel import Session, select

from parbaked._clientip import client_ip
from parbaked.auth.models import User, UserStatus
from parbaked.auth.tokens import (
    InvalidAdminSession,
    create_admin_session_token,
    verify_admin_session_token,
)
from parbaked.config import ParbakedConfig
from parbaked.email.base import EmailTransport
from parbaked.email.templates import Templates
from parbaked.hooks import Hooks
from parbaked.logging import log_event

_COOKIE_NAME = "parbaked_admin_session"
_COOKIE_TTL_HOURS = 12


_DASHBOARD_HTML = """\
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>parbaked admin · {app_name}</title>
<style>
  :root {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; }}
  body {{ max-width: 64rem; margin: 2rem auto; padding: 0 1.5rem; color: #111; }}
  h1 {{ font-size: 1.4rem; margin-bottom: 0.25rem; }}
  .sub {{ color: #666; font-size: 0.875rem; margin-bottom: 2rem; }}
  h2 {{ font-size: 1.05rem; margin-top: 2rem; color: #333; }}
  table {{ width: 100%; border-collapse: collapse; font-size: 0.9rem; }}
  th, td {{ text-align: left; padding: 0.5rem 0.75rem; border-bottom: 1px solid #eee; }}
  th {{ font-weight: 600; color: #555; background: #fafafa; }}
  td.actions {{ text-align: right; }}
  button {{ font: inherit; padding: 0.35rem 0.75rem; border-radius: 4px; border: 1px solid #ccc;
           background: white; cursor: pointer; margin-left: 0.5rem; }}
  button.approve {{ background: #15803d; color: white; border-color: #15803d; }}
  button.reject {{ background: #b91c1c; color: white; border-color: #b91c1c; }}
  .empty {{ color: #888; font-style: italic; padding: 0.5rem 0.75rem; }}
  .badge {{ font-size: 0.7rem; padding: 0.1rem 0.5rem; border-radius: 999px;
           background: #eee; color: #666; text-transform: uppercase; letter-spacing: 0.04em; }}
  .badge.pending {{ background: #fef3c7; color: #92400e; }}
  .badge.active  {{ background: #dcfce7; color: #166534; }}
  .badge.rejected {{ background: #fee2e2; color: #991b1b; }}
</style>
</head>
<body>
  <h1>parbaked admin</h1>
  <p class="sub">{app_name} · {pending_summary}</p>

  <h2>Pending</h2>
  {pending_table}

  <h2>Active</h2>
  {active_table}

  <h2>Rejected</h2>
  {rejected_table}
</body>
</html>
"""


_LOGIN_FORM_HTML = """\
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>parbaked admin · sign in</title>
<style>
  body {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
          background: #f6f7f9; color: #111; margin: 0; padding: 0;
          min-height: 100vh; display: flex; align-items: center;
          justify-content: center; }}
  .card {{ background: white; padding: 32px; border-radius: 8px;
           border: 1px solid #e5e7eb; max-width: 360px; width: 100%; }}
  h1 {{ margin: 0 0 6px 0; font-size: 18px; }}
  .sub {{ margin: 0 0 24px 0; font-size: 13px; color: #6b7280; }}
  label {{ display: block; font-size: 13px; margin-bottom: 4px; color: #374151; }}
  input {{ width: 100%; padding: 10px 12px; border: 1px solid #d1d5db;
           border-radius: 6px; font-size: 14px; box-sizing: border-box; }}
  button {{ width: 100%; padding: 10px; background: #111; color: white;
            border: 0; border-radius: 6px; font-weight: 500;
            font-size: 14px; cursor: pointer; margin-top: 16px; }}
  .err {{ color: #b91c1c; font-size: 13px; margin: 8px 0 0 0; }}
</style>
</head>
<body>
  <form method="post" action="{action}" class="card">
    <h1>parbaked admin</h1>
    <p class="sub">Sign in to manage signups.</p>
    {error_html}
    <label for="password">Admin password</label>
    <input id="password" name="password" type="password" autofocus required>
    <button type="submit">Sign in</button>
  </form>
</body>
</html>
"""


def _render_login_form(action_url: str, error: str | None = None) -> str:
    error_html = (
        f'<p class="err">{_esc(error)}</p>' if error else ""
    )
    return _LOGIN_FORM_HTML.format(action=_esc(action_url, quote=True), error_html=error_html)


def _render_pending_row(user: User, prefix: str) -> str:
    # user.name and user.email are user-controlled at signup — must escape.
    # prefix and user.id are parbaked-controlled (UUID has a safe alphabet) but
    # we escape defensively.
    safe_prefix = _esc(prefix, quote=True)
    return f"""\
      <tr>
        <td>{_esc(user.name)}</td>
        <td>{_esc(user.email)}</td>
        <td>{user.created_at.strftime("%Y-%m-%d %H:%M")}</td>
        <td class="actions">
          <form method="post" action="{safe_prefix}/{user.id}/approve" style="display: inline">
            <button class="approve" type="submit">Approve</button>
          </form>
          <form method="post" action="{safe_prefix}/{user.id}/reject" style="display: inline">
            <button class="reject" type="submit">Reject</button>
          </form>
        </td>
      </tr>"""


def _render_simple_row(user: User) -> str:
    when = (user.approved_at or user.created_at).strftime("%Y-%m-%d %H:%M")
    return f"""\
      <tr>
        <td>{_esc(user.name)}</td>
        <td>{_esc(user.email)}</td>
        <td>{when}</td>
        <td><span class="badge {user.status.value}">{user.status.value}</span></td>
      </tr>"""


def _table(rows: list[str], headers: list[str]) -> str:
    if not rows:
        return '<p class="empty">None</p>'
    header_row = "".join(f"<th>{h}</th>" for h in headers)
    body = "\n".join(rows)
    return f"<table><thead><tr>{header_row}</tr></thead><tbody>\n{body}\n</tbody></table>"


def build_admin_router(
    config: ParbakedConfig,
    get_session: Callable[..., Session],
    admin_password: str,
    email: EmailTransport,
    templates: Templates,
    *,
    hooks: Hooks | None = None,
    prefix: str = "/auth/admin",
) -> APIRouter:
    hooks = hooks or Hooks()
    router = APIRouter(prefix=prefix, tags=["admin"], include_in_schema=False)
    actions_prefix = prefix  # forms POST to /auth/admin/<id>/<action>
    login_url = f"{prefix}/login"

    # Cookies are only marked Secure when the public URL is HTTPS — otherwise
    # browsers reject the Set-Cookie on plain http://localhost dev.
    cookie_secure = config.app_url.startswith("https://")

    def _require_admin(
        request: Request,
        session_cookie: str | None = Cookie(default=None, alias=_COOKIE_NAME),
    ) -> None:
        """Check the admin session cookie. Redirect to login if missing/invalid."""
        if session_cookie:
            try:
                verify_admin_session_token(session_cookie, config)
                return
            except InvalidAdminSession:
                pass

        # No valid cookie. For browser navigation (GET), redirect to login.
        # For mutating actions (POST), tell the client they need to sign in.
        if request.method == "GET":
            raise HTTPException(
                status_code=status.HTTP_303_SEE_OTHER,
                headers={"Location": login_url},
            )
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Admin session expired — sign in again.",
        )

    # ----- login form ------------------------------------------------

    @router.get("/login", response_class=HTMLResponse)
    async def login_form() -> HTMLResponse:
        return HTMLResponse(_render_login_form(login_url))

    @router.post("/login")
    async def login_submit(
        request: Request,
        password: str = Form(...),
    ) -> Response:
        ip = client_ip(request, config)
        if not _secrets.compare_digest(password, admin_password):
            log_event(
                "admin.login.fail",
                ip=ip,
                success=False,
                extra={"reason": "bad_password"},
            )
            return HTMLResponse(
                _render_login_form(login_url, error="Incorrect password."),
                status_code=status.HTTP_401_UNAUTHORIZED,
            )
        token = create_admin_session_token(config, ttl_hours=_COOKIE_TTL_HOURS)
        response = RedirectResponse(url=prefix, status_code=status.HTTP_303_SEE_OTHER)
        response.set_cookie(
            key=_COOKIE_NAME,
            value=token,
            max_age=_COOKIE_TTL_HOURS * 3600,
            httponly=True,
            secure=cookie_secure,
            samesite="lax",
            path=prefix,  # cookie scoped to the admin tree only
        )
        log_event("admin.login.success", ip=ip, success=True)
        return response

    @router.post("/logout")
    async def logout(request: Request) -> Response:
        response = RedirectResponse(url=login_url, status_code=status.HTTP_303_SEE_OTHER)
        response.delete_cookie(key=_COOKIE_NAME, path=prefix)
        log_event("admin.logout", ip=client_ip(request, config), success=True)
        return response

    @router.get("", response_class=HTMLResponse, dependencies=[Depends(_require_admin)])
    async def dashboard(session: Session = Depends(get_session)) -> HTMLResponse:
        all_users = list(session.exec(select(User).order_by(User.created_at.desc())).all())
        # Unverified signups are deliberately hidden — they haven't proven they
        # own the email yet, so they're filed under "noise" until then.
        verified_pending = [
            u for u in all_users
            if u.status == UserStatus.pending and u.email_verified_at is not None
        ]
        unverified_count = sum(
            1 for u in all_users
            if u.status == UserStatus.pending and u.email_verified_at is None
        )
        active = [u for u in all_users if u.status == UserStatus.active]
        rejected = [u for u in all_users if u.status == UserStatus.rejected]

        pending_table = _table(
            [_render_pending_row(u, actions_prefix) for u in verified_pending],
            ["Name", "Email", "Signed up", ""],
        )
        active_table = _table(
            [_render_simple_row(u) for u in active], ["Name", "Email", "Approved", "Status"]
        )
        rejected_table = _table(
            [_render_simple_row(u) for u in rejected], ["Name", "Email", "Rejected", "Status"]
        )

        unverified_note = (
            f" · {unverified_count} unverified (hidden)" if unverified_count else ""
        )
        return HTMLResponse(
            _DASHBOARD_HTML.format(
                app_name=_esc(config.app_name),
                pending_summary=f"{len(verified_pending)} pending{unverified_note}",
                pending_table=pending_table,  # rows already escaped per-cell
                active_table=active_table,
                rejected_table=rejected_table,
            )
        )

    @router.post("/{user_id}/approve", dependencies=[Depends(_require_admin)])
    async def approve(
        request: Request,
        user_id: UUID,
        session: Session = Depends(get_session),
    ) -> RedirectResponse:
        user = session.get(User, user_id)
        if user is None:
            raise HTTPException(status_code=404, detail="User not found")
        if user.status != UserStatus.active:
            now = datetime.now(UTC)
            user.status = UserStatus.active
            user.approved_at = now
            if user.email_verified_at is None:
                user.email_verified_at = now
            session.add(user)
            session.commit()
            session.refresh(user)
            login_url = f"{config.app_url.rstrip('/')}{config.login_path}"
            # Email failures shouldn't block an approval — the user is active.
            with contextlib.suppress(Exception):
                email.send(templates.user_approved(user, login_url, config))
            log_event(
                "approve",
                user_id=str(user.id),
                email=user.email,
                ip=client_ip(request, config),
                extra={"via": "dashboard"},
            )
            hooks.fire("approve", user)
        return RedirectResponse(url=prefix, status_code=status.HTTP_303_SEE_OTHER)

    @router.post("/{user_id}/reject", dependencies=[Depends(_require_admin)])
    async def reject(
        request: Request,
        user_id: UUID,
        session: Session = Depends(get_session),
    ) -> RedirectResponse:
        user = session.get(User, user_id)
        if user is None:
            raise HTTPException(status_code=404, detail="User not found")
        if user.status != UserStatus.rejected:
            user.status = UserStatus.rejected
            session.add(user)
            session.commit()
            session.refresh(user)
            with contextlib.suppress(Exception):
                email.send(templates.user_rejected(user, config))
            log_event(
                "reject",
                user_id=str(user.id),
                email=user.email,
                ip=client_ip(request, config),
                extra={"via": "dashboard"},
            )
            hooks.fire("reject", user)
        return RedirectResponse(url=prefix, status_code=status.HTTP_303_SEE_OTHER)

    return router
