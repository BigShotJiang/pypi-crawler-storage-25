# parbaked examples

Runnable, version-pinned examples. Each file is a complete FastAPI app — copy, paste, run.

Run any of them with:

```bash
uv run uvicorn examples.<filename>:app --reload
```

| File | What it shows |
|---|---|
| [`minimal.py`](minimal.py) | The 4-line setup. Zero config. |
| [`with_resend.py`](with_resend.py) | Real email via Resend — the recommended prod path. Set `PARBAKED_RESEND_KEY` (or run `parbaked email setup`) and you're done. |
| [`with_hooks.py`](with_hooks.py) | React to signup events — fire Slack notifications / analytics / onboarding emails via the `on_signup` / `on_verify` / `on_approve` / `on_reject` callbacks. |
| [`protected_routes.py`](protected_routes.py) | Using `parbaked.current_user` to gate your own routes. |
| [`per_user_data.py`](per_user_data.py) | Adding a per-user table that joins on `users.id` — the right way to extend the schema. |
| [`custom_emails.py`](custom_emails.py) | Overriding the email body copy without forking parbaked. |
