---
agent: speckit.git.initialize
---
