---
agent: speckit.git.commit
---
