---
agent: speckit.git.feature
---
