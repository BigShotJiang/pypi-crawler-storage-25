import enum
import logging
import uuid
from collections.abc import Callable
from typing import (
    Any,
    ClassVar,
    Self,
    TypeVar,
    cast,
)

import sqlalchemy as sa
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.engine.interfaces import Dialect
from sqlalchemy.orm import registry
from sqlalchemy.types import CHAR, VARCHAR, TypeDecorator

from ai.backend.account_manager.utils import hash_password
from ai.backend.logging import BraceStyleAdapter

log = BraceStyleAdapter(logging.getLogger(__spec__.name))

# The common shared metadata instance
convention = {
    "ix": "ix_%(column_0_label)s",
    "uq": "uq_%(table_name)s_%(column_0_name)s",
    "ck": "ck_%(table_name)s_%(constraint_name)s",
    "fk": "fk_%(table_name)s_%(column_0_name)s_%(referred_table_name)s",
    "pk": "pk_%(table_name)s",
}
metadata = sa.MetaData(naming_convention=convention)
mapper_registry = registry(metadata=metadata)
Base: Any = mapper_registry.generate_base()

pgsql_connect_opts = {
    "server_settings": {
        "jit": "off",
        # 'deadlock_timeout': '10000',  # FIXME: AWS RDS forbids settings this via connection arguments
        "lock_timeout": "60000",  # 60 secs
        "idle_in_transaction_session_timeout": "60000",  # 60 secs
    },
}

UUID_SubType = TypeVar("UUID_SubType", bound=uuid.UUID)


class GUID[UUID_SubType: uuid.UUID](TypeDecorator[uuid.UUID]):
    """
    Platform-independent GUID type.
    Uses PostgreSQL's UUID type, otherwise uses CHAR(16) storing as raw bytes.
    """

    impl = CHAR
    uuid_subtype_func: ClassVar[Callable[[Any], Any]] = lambda v: v
    cache_ok = True

    def load_dialect_impl(self, dialect: Dialect) -> TypeDecorator[Any]:
        if dialect.name == "postgresql":
            return cast(TypeDecorator[Any], dialect.type_descriptor(UUID()))
        return cast(TypeDecorator[Any], dialect.type_descriptor(CHAR(16)))

    def process_bind_param(
        self, value: UUID_SubType | uuid.UUID | None, dialect: Dialect
    ) -> str | bytes | None:
        # NOTE: EndpointId, SessionId, KernelId are *not* actual types defined as classes,
        #       but a "virtual" type that is an identity function at runtime.
        #       The type checker treats them as distinct derivatives of uuid.UUID.
        #       Therefore, we just do isinstance on uuid.UUID only below.
        if value is None:
            return value
        if dialect.name == "postgresql":
            return str(value)
        return value.bytes

    def process_result_value(self, value: Any, dialect: Dialect) -> UUID_SubType | None:
        if value is None:
            return value
        cls = type(self)
        match value:
            case bytes():
                return cast(UUID_SubType, cls.uuid_subtype_func(uuid.UUID(bytes=value)))
            case _:
                return cast(UUID_SubType, cls.uuid_subtype_func(uuid.UUID(value)))


T_StrEnum = TypeVar("T_StrEnum", bound=enum.Enum, covariant=True)


class StrEnumType[T_StrEnum: enum.Enum](TypeDecorator[str]):
    """
    Maps Postgres VARCHAR(64) column with a Python enum.StrEnum type.
    """

    impl = sa.VARCHAR
    cache_ok = True

    def __init__(self, enum_cls: type[T_StrEnum], **opts: Any) -> None:
        self._opts = opts
        super().__init__(length=64, **opts)
        self._enum_cls = enum_cls

    def process_bind_param(  # type: ignore[override]
        self,
        value: T_StrEnum | None,
        dialect: Dialect,
    ) -> str | None:
        return value.value if value is not None else None

    def process_result_value(  # type: ignore[override]
        self,
        value: Any | None,
        dialect: Dialect,
    ) -> T_StrEnum | None:
        return self._enum_cls(value) if value is not None else None

    def copy(self, **kw: Any) -> Self:
        return StrEnumType(self._enum_cls, **self._opts)  # type: ignore[return-value]

    @property
    def python_type(self) -> type[T_StrEnum]:
        return self._enum_cls


class PasswordColumn(TypeDecorator[str]):
    impl = VARCHAR

    def process_bind_param(self, value: Any, dialect: Dialect) -> str:
        return hash_password(value)


def IDColumn(name: str = "id") -> sa.Column[Any]:
    return sa.Column(name, GUID, primary_key=True, server_default=sa.text("uuid_generate_v4()"))
