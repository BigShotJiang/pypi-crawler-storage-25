import asyncio
import aiohttp
import json
from typing import Dict, List, Any
from ErisPulse import sdk
from ErisPulse.Core import router
from .Converter import TelegramConverter
from ErisPulse.Core.Event import register_event_mixin, unregister_platform_event_methods


class TelegramEventMixin:

    def is_bot_message(self) -> bool:
        from_user = self.get("telegram_raw", {}).get("message", {}).get("from", {})
        if not from_user:
            from_user = (
                self.get("telegram_raw", {}).get("edited_message", {}).get("from", {})
            )
        return from_user.get("is_bot", False)

    def get_update_id(self) -> int:
        return self.get("telegram_raw", {}).get("update_id", 0)


register_event_mixin("telegram", TelegramEventMixin)


class TelegramAdapter(sdk.BaseAdapter):
    class Send(sdk.BaseAdapter.Send):
        """消息发送DSL实现"""

        def __init__(self, adapter, target_type=None, target_id=None, account_id=None):
            super().__init__(adapter, target_type, target_id, account_id)
            self._at_user_ids = []
            self._reply_message_id = None
            self._at_all = False

        # ============ 消息发送方法 ============

        def Text(self, text: str):
            return self.Raw_ob12([{"type": "text", "data": {"text": text}}])

        def Image(self, file: bytes | str, caption: str = "", content_type: str = None):
            return self.Raw_ob12(
                [
                    {
                        "type": "image",
                        "data": {
                            "file": file,
                            "caption": caption,
                            "content_type": content_type,
                        },
                    }
                ]
            )

        def Voice(self, file: bytes | str, caption: str = ""):
            return self.Raw_ob12(
                [{"type": "voice", "data": {"file": file, "caption": caption}}]
            )

        def Video(self, file: bytes | str, caption: str = "", content_type: str = None):
            return self.Raw_ob12(
                [
                    {
                        "type": "video",
                        "data": {
                            "file": file,
                            "caption": caption,
                            "content_type": content_type,
                        },
                    }
                ]
            )

        def File(self, file: bytes | str, caption: str = ""):
            return self.Raw_ob12(
                [{"type": "file", "data": {"file": file, "caption": caption}}]
            )

        def Document(
            self, file: bytes | str, caption: str = "", content_type: str = None
        ):
            return self.Raw_ob12(
                [
                    {
                        "type": "file",
                        "data": {
                            "file": file,
                            "caption": caption,
                            "content_type": content_type,
                        },
                    }
                ]
            )

        def Audio(self, file: bytes | str, caption: str = "", content_type: str = None):
            return self.Raw_ob12(
                [
                    {
                        "type": "audio",
                        "data": {
                            "file": file,
                            "caption": caption,
                            "content_type": content_type,
                        },
                    }
                ]
            )

        def Face(self, emoji: str):
            return self.Raw_ob12([{"type": "text", "data": {"text": emoji}}])

        def Markdown(self, text: str, content_type: str = "MarkdownV2"):
            return self.Raw_ob12(
                [
                    {
                        "type": "markdown",
                        "data": {"markdown": text, "content_type": content_type},
                    }
                ]
            )

        def HTML(self, text: str):
            return self.Raw_ob12(
                [{"type": "html", "data": {"html": text, "content_type": "HTML"}}]
            )

        def Edit(self, message_id: int, text: str, content_type: str = None):
            return asyncio.create_task(
                self._adapter.call_api(
                    endpoint="editMessageText",
                    chat_id=self._target_id,
                    message_id=message_id,
                    text=text,
                    parse_mode=content_type,
                )
            )

        def Recall(self, message_id: int):
            return asyncio.create_task(
                self._adapter.call_api(
                    endpoint="deleteMessage",
                    chat_id=self._target_id,
                    message_id=message_id,
                )
            )

        # ============ 原始消息发送方法 ============

        def Raw_ob12(self, message: List[Dict], **kwargs):
            import asyncio

            async def _send_raw_ob12():
                converted = await self._convert_ob12_to_telegram(message, **kwargs)

                if isinstance(converted, dict):
                    return await self._do_send(converted)
                elif isinstance(converted, list):
                    results = []
                    for call in converted:
                        result = await self._do_send(call)
                        results.append(result)
                    self._reset_modifiers()
                    return results[-1] if results else None

            return asyncio.create_task(_send_raw_ob12())

        def Raw_json(self, json_str: str):
            import asyncio

            data = json.loads(json_str)

            async def _send_raw_json():
                endpoint = data.pop("endpoint", "sendMessage")
                return await self._adapter.call_api(endpoint=endpoint, **data)

            return asyncio.create_task(_send_raw_json())

        # ============ 链式修饰方法 ============

        def At(self, user_id: str) -> "Send":
            self._at_user_ids.append(user_id)
            return self

        def AtAll(self) -> "Send":
            self._at_all = True
            return self

        def Reply(self, message_id: str) -> "Send":
            self._reply_message_id = message_id
            return self

        # ============ 辅助方法 ============

        def _reset_modifiers(self):
            self._at_user_ids = []
            self._reply_message_id = None
            self._at_all = False

        async def _do_send(self, call: Dict) -> Dict:
            endpoint = call["endpoint"]
            params = call["params"]

            media_file_data = params.pop("_media_file_data", None)
            if media_file_data is not None:
                return await self._upload_file_and_call_api(
                    endpoint, params.pop("_field_name"), media_file_data, **params
                )

            self._reset_modifiers()
            return await self._adapter.call_api(endpoint=endpoint, **params)

        def _add_mention_entity(
            self, entities: list, text_parts: list, user_id, name: str
        ):
            start_pos = len("".join(text_parts))
            text_parts.append(name)
            if str(user_id).isdigit():
                entities.append(
                    {
                        "type": "text_mention",
                        "offset": start_pos,
                        "length": len(name),
                        "user": {"id": int(user_id)},
                    }
                )
            else:
                entities.append(
                    {"type": "mention", "offset": start_pos, "length": len(name)}
                )

        async def _convert_ob12_to_telegram(
            self, message_segments: List[Dict], **kwargs
        ) -> Dict:
            text_parts = []
            entities = []
            media_segment = None
            reply_message_id = None
            at_all = False
            parse_mode = None

            for segment in message_segments:
                seg_type = segment.get("type")
                data = segment.get("data", {})

                if seg_type == "text":
                    text_parts.append(data.get("text", ""))

                elif seg_type in ["image", "video", "voice", "file", "audio"]:
                    if not media_segment:
                        media_segment = {"type": seg_type, "data": data}

                elif seg_type in ("at", "mention"):
                    user_id = data.get("user_id", "")
                    name = data.get("name", f"@{user_id}")
                    self._add_mention_entity(entities, text_parts, user_id, name)

                elif seg_type == "reply":
                    msg_id = data.get("message_id")
                    if msg_id:
                        try:
                            reply_message_id = int(msg_id)
                        except (ValueError, TypeError):
                            pass

                elif seg_type == "markdown":
                    text_parts.append(data.get("markdown", ""))
                    parse_mode = data.get("content_type", "MarkdownV2")

                elif seg_type == "html":
                    text_parts.append(data.get("html", ""))
                    parse_mode = data.get("content_type", "HTML")

            for user_id in self._at_user_ids:
                self._add_mention_entity(entities, text_parts, user_id, f"@{user_id}")

            final_reply_id = reply_message_id or self._reply_message_id
            final_at_all = at_all or self._at_all

            full_text = "".join(text_parts)
            if final_at_all:
                full_text = "@All " + full_text

            params = {"chat_id": self._target_id}
            if final_reply_id:
                try:
                    params["reply_to_message_id"] = int(final_reply_id)
                except (ValueError, TypeError):
                    pass

            if media_segment:
                seg_type = media_segment["type"]
                data = media_segment["data"]

                endpoint_map = {
                    "image": ("sendPhoto", "photo"),
                    "video": ("sendVideo", "video"),
                    "voice": ("sendVoice", "voice"),
                    "audio": ("sendAudio", "audio"),
                    "file": ("sendDocument", "document"),
                }
                endpoint, field_name = endpoint_map.get(
                    seg_type, ("sendDocument", "document")
                )

                media_file = (
                    data.get("file_id") or data.get("url") or data.get("file", "")
                )
                caption = full_text or data.get("caption", "")

                if isinstance(media_file, bytes):
                    params["caption"] = caption
                    ct = data.get("content_type")
                    if ct is not None:
                        params["parse_mode"] = ct
                    return {
                        "endpoint": endpoint,
                        "params": {
                            **params,
                            "_field_name": field_name,
                            "_media_file_data": media_file,
                        },
                    }

                params[field_name] = media_file
                params["caption"] = caption
                ct = data.get("content_type")
                if ct is not None:
                    params["parse_mode"] = ct
                if parse_mode and not ct:
                    params["parse_mode"] = parse_mode
                return {"endpoint": endpoint, "params": params}
            else:
                params["text"] = full_text or " "
                if entities:
                    params["entities"] = entities
                if parse_mode:
                    params["parse_mode"] = parse_mode
                return {"endpoint": "sendMessage", "params": params}

        async def _upload_file_and_call_api(self, endpoint, field_name, file, **kwargs):
            if "content_type" in kwargs:
                content_type = kwargs.pop("content_type")
                if content_type is not None:
                    kwargs["parse_mode"] = content_type

            if self._reply_message_id:
                try:
                    kwargs["reply_to_message_id"] = int(self._reply_message_id)
                except (ValueError, TypeError):
                    pass

            url = f"{self._adapter.base_url}/{endpoint}"
            data = aiohttp.FormData()
            data.add_field(
                field_name,
                file,
                filename=f"file.{field_name}",
                content_type="application/octet-stream",
            )

            for key, value in kwargs.items():
                if isinstance(value, (dict, list)):
                    data.add_field(key, json.dumps(value))
                else:
                    data.add_field(key, str(value))

            async with self._adapter.session.post(url, data=data) as response:
                raw_response = await response.json()
                self._reset_modifiers()
                return {
                    "status": "ok" if raw_response.get("ok") else "failed",
                    "retcode": 0 if raw_response.get("ok") else 34000,
                    "data": raw_response.get("result"),
                    "message_id": str(
                        raw_response.get("result", {}).get("message_id", "")
                    )
                    if isinstance(raw_response.get("result"), dict)
                    else "",
                    "message": ""
                    if raw_response.get("ok")
                    else raw_response.get("description", "Unknown error"),
                    "telegram_raw": raw_response,
                }

    def __init__(self, sdk):
        super().__init__()
        self.sdk = sdk
        self.logger = sdk.logger
        self.config = self._load_config()
        self.token = self.config.get("token", "")
        self.session = None
        self.poll_task = None
        self.base_url = f"https://api.telegram.org/bot{self.token}"
        self.last_update_id = 0
        self._proxy_enabled = self.config.get("proxy_enabled", False)
        self._proxy_config = (
            self.config.get("proxy", {}) if self._proxy_enabled else None
        )
        converter = TelegramConverter(self.token)
        self.convert = converter.convert
        self.bot_id = converter.bot_id

    def _load_config(self):
        config = self.sdk.config.getConfig("Telegram_Adapter")
        if not config:
            # 新配置（无 mode 和 webhook）
            default_config = {
                "token": "YOUR_BOT_TOKEN",
                "proxy_enabled": False,
                "proxy": {"host": "127.0.0.1", "port": 1080, "type": "socks5"},
            }
            try:
                sdk.logger.warning("Telegram适配器配置不存在，已自动创建默认配置")
                self.sdk.config.setConfig("Telegram_Adapter", default_config)
                return default_config
            except Exception as e:
                self.logger.error(f"保存默认配置失败: {str(e)}")
                return default_config

        # 兼容旧版配置：检查是否有 mode 和 webhook 配置
        has_mode = "mode" in config
        has_webhook = "webhook" in config

        if has_mode or has_webhook:
            mode = config.get("mode", "polling")

            # 如果旧版配置是 webhook 模式，发出 Error 日志
            if mode == "webhook":
                self.logger.error(
                    "Telegram 适配器不再支持 Webhook 模式！请切换到 Polling 模式。将自动使用 Polling 模式启动。"
                )
            elif has_webhook:
                self.logger.warning(
                    "检测到旧版 Webhook 配置，已自动忽略。Telegram 适配器将使用 Polling 模式。"
                )
            else:
                self.logger.info("检测到旧版配置，已自动兼容。当前使用 Polling 模式。")

        return config

    async def _poll_updates(self):
        """轮询获取 Telegram 更新"""
        offset = 0
        while True:
            try:
                response = await self.call_api("getUpdates", offset=offset, timeout=60)

                # 检查API调用是否成功
                if response.get("status") != "ok":
                    self.logger.error(f"获取更新失败: {response.get('message')}")
                    await asyncio.sleep(5)
                    continue

                updates = response.get("data")

                if updates:
                    for update in updates:
                        update_id = update["update_id"]
                        if update_id >= offset:
                            offset = update_id + 1

                        if hasattr(self.sdk, "adapter"):
                            onebot_event = self.convert(update)
                            self.logger.debug(
                                f"OneBot12事件数据: {json.dumps(onebot_event, ensure_ascii=False)}"
                            )
                            if onebot_event:
                                await self.sdk.adapter.emit(onebot_event)
                await asyncio.sleep(1)
            except Exception as e:
                self.logger.error(f"轮询更新失败: {e}")
                await asyncio.sleep(5)

    async def call_api(self, endpoint: str, **params):
        """调用 Telegram Bot API"""
        url = f"{self.base_url}/{endpoint}"
        try:
            async with self.session.post(url, json=params) as response:
                raw_response = await response.json()

                self.logger.debug(f"Telegram API请求: {url}")
                self.logger.debug(f"Telegram API响应: {raw_response}")

                # 检查响应是否为预期的字典格式
                if not isinstance(raw_response, dict):
                    self.logger.error(
                        f"Telegram API 返回了意外的响应格式: {type(raw_response)}, 内容: {raw_response}"
                    )
                    return {
                        "status": "failed",
                        "retcode": 34000,
                        "data": None,
                        "message_id": "",
                        "message": f"API 返回了意外格式: {type(raw_response)}",
                        "telegram_raw": raw_response,
                        "echo": params.get("echo", ""),
                    }

                # 构建标准化响应
                response_data = {
                    "status": "ok" if raw_response.get("ok") else "failed",
                    "retcode": 0 if raw_response.get("ok") else 34000,  # 34xxx 平台错误
                    "data": raw_response.get("result"),
                    "message_id": str(
                        raw_response.get("result", {}).get("message_id", "")
                    )
                    if isinstance(raw_response.get("result"), dict)
                    else "",
                    "message": ""
                    if raw_response.get("ok")
                    else raw_response.get("description", "Unknown Telegram API error"),
                    "telegram_raw": raw_response,
                }

                # 处理echo字段
                if "echo" in params:
                    response_data["echo"] = params["echo"]

                return response_data

        except Exception as e:
            self.logger.error(f"调用Telegram API失败: {str(e)}")
            return {
                "status": "failed",
                "retcode": 33001,  # 网络错误
                "data": None,
                "message_id": "",
                "message": f"API调用失败: {str(e)}",
                "telegram_raw": None,
                "echo": params.get("echo", ""),
            }

    async def start(self):
        """启动适配器（仅支持 polling 模式）"""
        import ssl
        import certifi
        from aiohttp_socks import ProxyType, ProxyConnector

        # 初始化会话
        if self._proxy_enabled and self._proxy_config:
            proxy_type = self._proxy_config.get("type")
            if proxy_type in ["socks5", "socks4"]:
                proxy_type_enum = (
                    ProxyType.SOCKS5 if proxy_type == "socks5" else ProxyType.SOCKS4
                )
                ssl_context = ssl.create_default_context(cafile=certifi.where())
                connector = ProxyConnector(
                    proxy_type=proxy_type_enum,
                    host=self._proxy_config["host"],
                    port=self._proxy_config["port"],
                    ssl=ssl_context,
                )
                self.session = aiohttp.ClientSession(connector=connector)
                self.logger.info(
                    f"已启用{proxy_type.upper()}代理: {self._proxy_config['host']}:{self._proxy_config['port']}"
                )
            else:
                self.logger.warning(f"不支持的代理类型: {proxy_type}, 将不使用代理")
                self.session = aiohttp.ClientSession()
        else:
            self.session = aiohttp.ClientSession()
            if self._proxy_enabled:
                self.logger.warning("代理已启用但未配置，将不使用代理")

        # 启动轮询模式
        self.poll_task = asyncio.create_task(self._poll_updates())
        self.logger.info("Telegram适配器已启动（polling 模式）")

        await self.sdk.adapter.emit(
            {
                "type": "meta",
                "detail_type": "connect",
                "platform": "telegram",
                "self": {"platform": "telegram", "user_id": self.bot_id},
            }
        )

    async def shutdown(self):
        """关闭适配器"""
        await self.sdk.adapter.emit(
            {
                "type": "meta",
                "detail_type": "disconnect",
                "platform": "telegram",
                "self": {"platform": "telegram", "user_id": self.bot_id},
            }
        )

        if self.poll_task:
            self.poll_task.cancel()
            try:
                await self.poll_task
            except asyncio.CancelledError:
                pass
            self.poll_task = None

        if self.session:
            await self.session.close()
            self.session = None

        unregister_platform_event_methods("telegram")
        self.logger.info("Telegram适配器已关闭")
