import numpy as np
from ..libs._nptsne import HSne as HSne
from ..libs._nptsne._hsne_analysis import Analysis as Analysis, EmbedderType as EmbedderType
from _typeshed import Incomplete

class AnalysisContainer:
    """A dict of dicts to store analyses

    Parameters
    ----------
    top_analysis: :class:`Analysis`
        The Analysis at the highest scale level containing all landmarks

    Notes
    -----
    The outer dict represents the scales and
    the inner dicts at scale level are indexed by the unique
    self-generated Analysis ids.
    """
    def __init__(self, top_analysis: Analysis) -> None: ...
    def __eq__(self, other):
        """To used for comparing an older copy with the current analysis container"""
    def add_analysis(self, analysis: Analysis) -> None:
        """Add a new analysis to the container

        Parameters
        ----------
        analysis : Analysis
            The new analysis
        """
    def get_analysis(self, analysis_id: int) -> Analysis:
        """Get the analysis corresponding to the id

        Parameters
        ----------
        analysis_id : int
            [description]

        Returns
        -------
        Analysis
            [description]

        Raises
        ------
        ValueError
            If the id does not correspond to an analysis
        """
    def remove_analysis(self, analysis_id: int) -> list[int]:
        """Removes analysis and, recursively, child analyses

        Returns
        -------
        list[int]
            A list of analysis ids removed including this one
        """

class AnalysisModel:
    """Create an analysis model tree with the a top level Analysis containing all landmarks at the highest scale
    The AnalysisModel initially contains only the top analysis, i.e. the HSNE scale with the least number of points.
    As selections are made starting from the top analysis new sub analyses are added to the tree
    in AnalsisModel. The helper class AnalysisContainer is responsible for maintaining this tree of analyses.

    Parameters
    ----------
    hsne : HSne
        The python HSne wrapper class
    embedder_type : :class:`hsne_analysis.EmbedderType`
        The embedder to be used when creating a new analysis CPU or GPU

    Examples
    --------
    Initialize a model using loaded :class:`HSne` data.

    >>> import nptsne
    >>> model = nptsne.hsne_analysis.AnalysisModel(sample_hsne, nptsne.hsne_analysis.EmbedderType.CPU)
    >>> model.top_scale_id
    2

    Attributes
    ----------
    top_analysis
    analysis_container
    bottom_scale_id
    top_scale_id

    See Also
    --------
    hsne_analysis.Analysis
    hsne_analysis.EmbedderType.CPU

    Notes
    -----
    The hsne_analysis.AnalysisModel contains the user driven selections
    when exploring an HSNE hierarchy. The AnalysisModel is created
    with a top level default hsne_analysis.Analysis containing all top level landmarks.
    """
    hsne: Incomplete
    embedder_type: Incomplete
    top_scale_id: Incomplete
    bottom_scale_id: int
    top_analysis_id: int
    def __init__(self, hsne: HSne, embedder_type: EmbedderType) -> None: ...
    @property
    def top_analysis(self) -> Analysis:
        """hsne_analysis.Analysis: The top level analysis

        Examples
        --------
        Retrieve the top level analysis containing all points at the top level.

        >>> import nptsne
        >>> model = nptsne.hsne_analysis.AnalysisModel(sample_hsne, nptsne.hsne_analysis.EmbedderType.CPU)
        >>> analysis = model.top_analysis
        >>> analysis.scale_id
        2

        Raises
        ------
        ValueError
            If there is not top analysis
        """
    def add_new_analysis(self, parent: Analysis, parent_selection: np.ndarray) -> Analysis:
        """Add a new analysis based on a selection in a parent analysis

        Parameters
        ----------
        parent: Analysis
           The parent analysis

        parent_selection: ndarray<np.uint32>
           The selection indices in the parent analysis

        Examples
        --------
        Make a child analysis by selecting half of the points in the top analysis.
        The analysis is created at the next scale down is a child of the top level
        and contains an embedding of the right shape.

        >>> import nptsne
        >>> model = nptsne.hsne_analysis.AnalysisModel(sample_hsne, nptsne.hsne_analysis.EmbedderType.CPU)
        >>> sel = np.arange(int(model.top_analysis.number_of_points / 2))
        >>> analysis = model.add_new_analysis(model.top_analysis, sel)
        >>> analysis.scale_id
        1
        >>> analysis.parent_id == model.top_analysis.id
        True
        >>> analysis.embedding.shape == (analysis.number_of_points, 2)
        True
        """
    def get_analysis(self, id: int) -> Analysis:
        """Get the `Analysis` for the given id

        Parameters
        ----------
        id: int
           An Analysis id

        Examples
        --------
        >>> import nptsne
        >>> model = nptsne.hsne_analysis.AnalysisModel(sample_hsne, nptsne.hsne_analysis.EmbedderType.CPU)
        >>> id = model.top_analysis.id
        >>> str(model.top_analysis) == str(model.get_analysis(id))
        True

        Returns
        -------
            The Analysis corresponding to the id

        Raises
        ------
        ValueError
            If the id does not correspond to an analysis
        """
    @property
    def analysis_container(self) -> AnalysisContainer:
        """The container for all analyses.

        This is an internal property exposed for debug purposes only"""
    def remove_analysis(self, id: int) -> list[int]:
        """Remove the analysis and all children

        Returns
        -------
        list[int]
            list of deleted ids

        Examples
        --------
        >>> import nptsne
        >>> model = nptsne.hsne_analysis.AnalysisModel(sample_hsne, nptsne.hsne_analysis.EmbedderType.CPU)
        >>> sel = np.arange(int(model.top_analysis.number_of_points / 2))
        >>> analysis = model.add_new_analysis(model.top_analysis, sel)
        >>> id = analysis.id
        >>> a_list = model.remove_analysis(analysis.id)
        >>> a_list == [id]
        """
