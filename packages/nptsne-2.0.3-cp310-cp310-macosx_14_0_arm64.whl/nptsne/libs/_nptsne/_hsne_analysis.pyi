"""
Submodule containing classes for navigation of HSNE analyses
"""
from __future__ import annotations
import nptsne.libs._nptsne
import numpy
import typing
__all__: tuple = ('Analysis', 'SparseTsne', 'EmbedderType')
class Analysis:
    """
    
                Create a new analysis as a child of an (optional) parent analysis.
    
                Parameters
                ----------
                hsne : :class:`HSne`
                    The hierarchical SNE being explored
                embedder_type : :class:`EmbedderType`
                    The tSNE to use CPU or GPU based
                parent : :class:`Analysis`, optional
                    The parent Analysis (where the selection was performed) if any
                parent_selection : list, optional
                    List of selection indexes in the parent analysis.
    
                Attributes
                ----------
                number_of_points
                parent_id
                transition_matrix
                landmark_weights
                landmark_indexes
                landmark_orig_indexes
                embedding
    
                Examples
                --------
                The Analysis constructor is meant for use by the :class: `nptsne.hsne_analysis.AnalysisModel`.
                The example here illustrates how a top level analysis would be created from a sample hsne.
    
                >>> import nptsne
                >>> top_analysis = nptsne.hsne_analysis.Analysis(sample_hsne, nptsne.hsne_analysis.EmbedderType.CPU)
                >>> top_analysis.scale_id
                2
                >>> sample_hsne.get_scale(top_analysis.scale_id).num_points == top_analysis.number_of_points
                True
    
                Notes
                -----
                Together with `AnalysisModel` provides support for visual analytics of an hSNE.
                The Analysis class holds both the chosen landmarks at a particular
                scale but also permits referencing back to the original data.
                Additionally a t-SNE embedder is included (a choice is
                provided between GPU and CPU implementations) which can be used to create
                an embedding of the selected landmarks.
    
            
    """
    def __init__(self, hnse: nptsne.libs._nptsne.HSne, embedder_type: EmbedderType, parent: Analysis = None, parent_selection: list[int] = []) -> None:
        ...
    def __str__(self) -> str:
        """
                        str: A string summary of the analysis.
        
                        Examples
                        --------
                        >>> expected_str = 'Analysis[id={}, num points={}, scale={}]'.format(
                        ... sample_analysis.id, 
                        ... sample_analysis.number_of_points, 
                        ... sample_analysis.scale_id)
                        >>> str(sample_analysis) == expected_str
                        True
        """
    def do_iteration(self) -> None:
        """
        Perform one iteration of the chosen embedder
        """
    def get_area_of_influence(self, select_list: list[int], threshold: float = 0.3) -> numpy.ndarray[numpy.float32]:
        """
                        Get the area of influence of the selection in the original data.
                        For more information on the `threshold` refer to the HSNE paper
                        section *4.2 Filtering and drilling down*.
        
                        A fast but less accurate approach to obtaining area of influence 
                        is `get_mapped_area_of_influence`.
        
                        See Also
                        --------
                        get_fast_area_of_influence
        
                        Parameters
                        ----------
                        select_list : list
                            A list of selection indexes for landmarks in this analysis
                        threshold: float, optional
                            The minimum value required for the underlying
                            datapoint to be considered in the landmark's region of influence.
                            Default is 0.3. The parameter must be in the range 0 to 1.0,
                            values outside the range it will be ignored.
        
                        Returns
                        -------
                        :class:`ndarray`
                            The mask of the original points represented by the selected landmarks.
                            If the point is in the AOI the value is 1.
        """
    def get_fast_area_of_influence(self, select_list: list[int]) -> numpy.ndarray[numpy.float32]:
        """
                        Fast method to get the area of influence of the selection in the original data
                        based on non overlapping :math:`{1}\\rightarrow{n}` mapping of scale landmarks
                        to original data points.
        
                        This mapping is derived by working bottom up from the data points and finding
                        the landmarks at each scale with the maximum influence. The mapping is calculated
                        once on the first call to this function so subsequent calls are fast.
        
                        Due to thresholding it is possible that a datapoint may have no representative
                        landmark at a specific scale.
        
                        See Also
                        --------
                        get_area_of_influence
        
                        Parameters
                        ----------
                        select_list : list
                            A list of selection indexes for landmarks in this analysis
        
                        Examples
                        --------
        
                        Demonstrate the non-overlap of the area of influence for each landmark.
        
                        >>> import math
                        >>> import numpy as np
                        >>> all_top_landmarks=list(range(0,sample_analysis.number_of_points))
                        >>> all_influenced=sample_analysis.get_fast_area_of_influence(all_top_landmarks)
                        >>> all_influenced.shape[0] == 10000
                        True
        
                        Accumulate the individual landmark AOIs and check the total
        
                        >>> infl_accum = np.zeros((10000,), dtype=np.float32)
                        >>> total = 0
                        >>> for i in all_top_landmarks:
                        ...     influenced = sample_analysis.get_fast_area_of_influence([i])
                        ...     total = total + influenced.sum()
                        ...     infl_accum = np.add(infl_accum, influenced)
                        >>> (total == 10000).item()
                        True
        
                        Verify that all AOIs are non-overlapping, each datapoint
                        occurs once and only once.
        
                        >>> (np.all(infl_accum == 1)).item()
                        True
        
                        Returns
                        -------
                        :class:`ndarray`
                            The mask of the original points represented by the selected landmarks.
                            If the point is in the AOI the value is 1.
        """
    @property
    def embedding(self) -> numpy.ndarray[numpy.float32]:
        """
                    :class:`ndarray` : the tSNE embedding generated for this `Analysis`
        
                    Examples
                    --------
                    An embedding is a 2d float array. One entry per point.
        
                    >>> import numpy as np
                    >>> sample_analysis.embedding.shape == (sample_analysis.number_of_points, 2)
                    True
                    >>> sample_analysis.embedding.dtype == np.float32
                    True
        """
    @property
    def id(self) -> int:
        """
                        int: Internally generated unique id for the analysis.
        
                        Examples
                        --------
        
                        >>> sample_analysis.id
                        0
        """
    @id.setter
    def id(self, arg0: int) -> None:
        ...
    @property
    def landmark_indexes(self) -> numpy.ndarray[numpy.uint32]:
        """
                    :class:`ndarray` : the indexes for the landmarks in this `Analysis`
        
                    Examples
                    --------
                    In a complete top level analysis all points are present
                    in this case all the points at scale2.
        
                    >>> import numpy as np
                    >>> np.array_equal(
                    ... np.arange(sample_scale2.num_points, dtype=np.uint32), 
                    ... sample_analysis.landmark_indexes)
                    True
        """
    @property
    def landmark_orig_indexes(self) -> numpy.ndarray[numpy.uint32]:
        """
                    :class:`ndarray` : the original data indexes for the landmarks in this `Analysis`
        
                    Examples
                    --------
                    The indexes are in the range of the original point indexes.
        
                    >>> import numpy as np
                    >>> result = np.logical_and(
                    ... sample_analysis.landmark_orig_indexes >= 0,
                    ... sample_analysis.landmark_orig_indexes < 10000).any()
                    >>> print(f"{result}")
                    True
        """
    @property
    def landmark_weights(self) -> numpy.ndarray[numpy.float32]:
        """
                    :class:`ndarray` : the weights for the landmarks in this `Analysis`
        
                    Examples
                    --------
                    There will be a weight for every point.
        
                    >>> weights = sample_analysis.landmark_weights
                    >>> weights.shape == (sample_analysis.number_of_points,)
                    True
        """
    @property
    def number_of_points(self) -> int:
        """
                        int : number of landmarks in this `Analysis`
        
                        Examples
                        --------
                        The sample analysis is all the top scale points
        
                        >>> sample_analysis.number_of_points == sample_scale2.num_points
                        True
        """
    @property
    def parent_id(self) -> int:
        """
        int : Unique id of the parent analysis
        """
    @property
    def scale_id(self) -> int:
        """
                        int: The number of this HSNE scale where this analysis is created.
        
                        Examples
                        --------
                        >>> sample_analysis.scale_id
                        2
        """
    @scale_id.setter
    def scale_id(self, arg0: int) -> None:
        ...
    @property
    def transition_matrix(self) -> list[list[tuple[int, float]]]:
        """
        list(dict) : The transition (probability) matrix in this `Analysis`
        """
class EmbedderType:
    """
    
                Enumeration used to select the embedder used. Two possibilities are
                supported:
    
                `EmbedderType.CPU`: CPU tSNE
                `EmbedderType.CPU`: GPU tSNE
    
            
    
    Members:
    
      CPU
    
      GPU
    """
    CPU: typing.ClassVar[EmbedderType]  # value = <EmbedderType.CPU: 0>
    GPU: typing.ClassVar[EmbedderType]  # value = <EmbedderType.GPU: 1>
    __members__: typing.ClassVar[dict[str, EmbedderType]]  # value = {'CPU': <EmbedderType.CPU: 0>, 'GPU': <EmbedderType.GPU: 1>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __ge__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __gt__(self, other: typing.Any) -> bool:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: int) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __le__(self, other: typing.Any) -> bool:
        ...
    def __lt__(self, other: typing.Any) -> bool:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: int) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class SparseTsne:
    """
    
                SparseTsne a wrapper for an approximating tSNE CPU implementation as described in [1]_.
    
                Forms an alternative to `TextureTsne` when GPU acceleration for creation of the embedding
                is not available for internal use in the `Analysis` class
    
                Attributes
                ----------
                embedding : :class:`ndarray`
    
                See Also
                --------
                Analysis
                EmbedderType
    
                References
                ----------
                .. [1] Pezzotti, N., Lelieveldt, B.P.F., Maaten, L. van der, Höllt, T., Eisemann, E., Vilanova, A., 2017.
                    `Approximated and User Steerable tSNE for Progressive Visual Analytics. <https://doi.org/10.1109/TVCG.2016.2570755>`_
                    IEEE Transactions on Visualization and Computer Graphics 23, 1739–1752.
            
    """
    def do_iteration(self) -> None:
        """
                    Perform a single tSNE iteration on the sparse data.
                    Once complete the embedding coordinates can be read via the embedding property
        """
    @property
    def embedding(self) -> numpy.ndarray[numpy.float32]:
        """
        Embedding plot - shape embed dimensions x num points
        """
