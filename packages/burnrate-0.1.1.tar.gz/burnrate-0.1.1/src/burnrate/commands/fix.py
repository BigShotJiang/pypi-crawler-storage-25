from __future__ import annotations

from pathlib import Path
from typing import Annotated, Optional

import typer
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.prompt import Prompt
from rich.text import Text

from burnrate.commands.audit import PYTHON_SUFFIX, SKIP_DIRS, TS_SUFFIXES, _collect_files
from burnrate.fixers import apply_fix, get_fixer_for
from burnrate.scanner.python_ast import scan_python_file
from burnrate.scanner.regex_scan import scan_ts_file
from burnrate.scanner.report import Finding

console = Console()

_NOT_FIXABLE_HINTS = {
    "cache_control": (
        "Add cache_control: {{type: 'ephemeral'}} to your system prompt array — "
        "see Anthropic prompt caching docs."
    ),
}


def fix(
    path: Annotated[
        Optional[Path],
        typer.Argument(help="Path to scan (default: current directory)"),
    ] = None,
    dry_run: Annotated[
        bool,
        typer.Option("--dry-run", help="Show diffs but do not write any files."),
    ] = False,
) -> None:
    """Apply targeted code-level fixes found by the scanner. Shows diffs before writing."""
    root = (path or Path(".")).resolve()

    if not root.exists():
        console.print(f"[red]Path does not exist:[/red] {root}")
        raise typer.Exit(1)

    files = _collect_files(root)

    findings: list[Finding] = []
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
        transient=True,
    ) as progress:
        task = progress.add_task(f"Scanning {len(files)} files...", total=len(files))
        for f in files:
            if f.suffix == PYTHON_SUFFIX:
                findings.extend(scan_python_file(f))
            elif f.suffix in TS_SUFFIXES:
                findings.extend(scan_ts_file(f))
            progress.advance(task)

    fixable = [f for f in findings if get_fixer_for(f) is not None]
    not_fixable = [f for f in findings if get_fixer_for(f) is None]

    if not fixable and not not_fixable:
        console.print("[green]No issues found — nothing to fix.[/green]")
        return

    if not fixable:
        console.print("[green]No auto-fixable issues found.[/green]")
        _print_manual_hints(not_fixable)
        return

    console.print()
    if dry_run:
        console.print(f"[dim]Dry run — showing {len(fixable)} fixable finding(s). No files will be written.[/dim]")
    else:
        console.print(f"Applying fixes for [bold]{len(fixable)}[/bold] finding(s)...")
    console.print()

    applied = 0
    total_savings = 0.0

    # Track "apply all" per fix kind (identified by the fixer class name)
    apply_all_kinds: set[str] = set()

    for i, finding in enumerate(fixable, start=1):
        fixer = get_fixer_for(finding)
        kind = type(fixer).__name__

        console.print(f"[bold]Fix {i}/{len(fixable)}:[/bold] {finding.file}:{finding.line}")
        console.print(f"  {finding.message}")
        console.print()

        result = apply_fix(finding, dry_run=True)
        if result is None or not result.changed:
            console.print("  [dim](no change produced — skipping)[/dim]")
            console.print()
            continue

        _render_diff(result.diff)
        console.print()

        if dry_run:
            applied += 1
            total_savings += finding.savings_stub
            continue

        if kind in apply_all_kinds:
            _write_fix(finding)
            applied += 1
            total_savings += finding.savings_stub
            console.print(f"  [green]✓ Applied (all)[/green]")
            console.print()
            continue

        answer = Prompt.ask(
            "  Apply?",
            choices=["y", "n", "skip", "all"],
            default="n",
            console=console,
        )

        if answer == "y":
            _write_fix(finding)
            applied += 1
            total_savings += finding.savings_stub
            console.print(f"  [green]✓ Applied[/green]")
        elif answer == "all":
            apply_all_kinds.add(kind)
            _write_fix(finding)
            applied += 1
            total_savings += finding.savings_stub
            console.print(f"  [green]✓ Applied (applying all remaining of this kind)[/green]")
        else:
            console.print(f"  [dim]Skipped[/dim]")
        console.print()

    _print_summary(applied, total_savings, dry_run)
    _print_manual_hints(not_fixable)


def _write_fix(finding: Finding) -> None:
    apply_fix(finding, dry_run=False)


def _render_diff(diff_text: str) -> None:
    for line in diff_text.splitlines():
        if line.startswith("+") and not line.startswith("+++"):
            console.print(Text(line, style="green"))
        elif line.startswith("-") and not line.startswith("---"):
            console.print(Text(line, style="red"))
        elif line.startswith("@@"):
            console.print(Text(line, style="cyan"))
        else:
            console.print(Text(line, style="dim"))


def _print_summary(applied: int, savings: float, dry_run: bool) -> None:
    console.print()
    if dry_run:
        console.print(f"[dim]Dry run complete — {applied} fix(es) previewed, 0 written.[/dim]")
    else:
        label = "fix" if applied == 1 else "fixes"
        console.print(f"[bold green]Done.[/bold green] {applied} {label} applied.")
    if savings > 0:
        console.print(f"[green]Est. monthly savings: ~${savings:.0f}/mo[/green]")
    console.print()


def _print_manual_hints(not_fixable: list[Finding]) -> None:
    cache_findings = [f for f in not_fixable if "cache_control" in f.message.lower()]
    if cache_findings:
        console.print("[yellow]Manual action required:[/yellow]")
        for f in cache_findings:
            console.print(f"  [dim]{f.file}:{f.line}[/dim] — {_NOT_FIXABLE_HINTS['cache_control']}")
        console.print()
