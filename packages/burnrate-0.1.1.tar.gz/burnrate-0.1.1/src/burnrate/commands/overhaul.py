from __future__ import annotations

import typer
from rich.console import Console
from rich.prompt import Prompt

from burnrate.config import config_path, load_config
from burnrate.installers import StepStatus, execute_plan, preview_plan
from burnrate.installers.steps import build_steps
from burnrate.overhaul import recommend
from burnrate.overhaul.render import render_plan


def overhaul(
    dry_run: bool = typer.Option(
        False,
        "--dry-run",
        help="Show what would be installed without running any commands.",
    ),
) -> None:
    """Show a personalized stack-overhaul plan and (optionally) execute the installs."""
    con = Console()

    if not config_path().exists():
        con.print()
        con.print(
            "[red]No config found.[/red] Run [bold]burnrate auth[/bold] first to set up keys and detect your system."
        )
        con.print()
        raise typer.Exit(code=1)

    config = load_config()
    subs = config.baseline.subscriptions if config.baseline else []

    if not subs:
        con.print()
        con.print(
            "[yellow]No subscriptions recorded.[/yellow] Re-run [bold]burnrate auth[/bold] "
            "and answer the subscription prompts, or edit [dim]"
            f"{config_path()}[/dim] manually."
        )
        con.print()
        raise typer.Exit(code=1)

    plan = recommend(config)
    render_plan(plan, config, con)

    steps = build_steps(plan.recommendations)
    if not steps:
        con.print("[dim]No installable steps in this plan — recommendations are advisory only.[/dim]")
        con.print()
        return

    preview_plan(steps, con)

    answer = Prompt.ask(
        "[bold]Proceed with overhaul?[/bold]",
        choices=["y", "n"],
        default="n",
        show_choices=True,
    )

    con.print()
    if answer != "y":
        con.print("[dim]Cancelled — no changes made.[/dim]")
        con.print()
        return

    results = execute_plan(steps, con, dry_run=dry_run)

    con.print()
    successes = sum(1 for r in results if r.status == StepStatus.SUCCESS)
    skipped = sum(1 for r in results if r.status == StepStatus.SKIPPED_ALREADY_DONE)
    failed = sum(1 for r in results if r.status == StepStatus.FAILED)

    if dry_run:
        con.print(f"[dim]Dry run complete. {len(results)} step(s) previewed.[/dim]")
        con.print()
        return

    con.print(
        f"[bold green]{successes} step(s) succeeded[/bold green], "
        f"[dim]{skipped} already-installed[/dim], "
        f"[red]{failed} failed[/red]."
    )

    followups = [s.step.followup_hint for s in results if s.step.followup_hint and s.status == StepStatus.SUCCESS]
    if followups:
        con.print()
        con.print("[bold]Manual follow-ups:[/bold]")
        for hint in followups:
            con.print(f"  [dim]•[/dim] {hint}")

    con.print()
    con.print(
        "[dim]Next: run [bold]burnrate fix .[/bold] to patch your codebase API calls, "
        "then [bold]burnrate doctor[/bold] to verify everything.[/dim]"
    )
    con.print()

    if failed > 0:
        raise typer.Exit(code=1)
