from __future__ import annotations

import datetime

import typer
from rich.console import Console
from rich.rule import Rule

from burnrate.config import config_path, load_config
from burnrate.spend import ProviderSpend, gather_spend


PROVIDER_LABELS = {
    "anthropic": "Anthropic API",
    "openai": "OpenAI API",
}


def status() -> None:
    """Show current-month API spend vs pre-overhaul subscription baseline."""
    con = Console()

    if not config_path().exists():
        con.print()
        con.print(
            "[red]No config found.[/red] Run [bold]burnrate auth[/bold] first."
        )
        con.print()
        raise typer.Exit(code=1)

    config = load_config()
    today = datetime.date.today()
    month_label = today.strftime("%B %Y")

    con.print()
    con.print(Rule(style="red dim"))
    con.print(f"  [bold]SPEND THIS MONTH ({month_label})[/bold]")
    con.print(Rule(style="red dim"))
    con.print()

    spends = gather_spend(config)

    known_total = 0.0
    have_any_live_data = False
    for s in spends:
        _print_provider(s, con)
        if s.amount_usd is not None:
            known_total += s.amount_usd
            have_any_live_data = True

    con.print(f"  [dim]Ollama:[/dim]            [bold]$0.00[/bold] [dim](local)[/dim]")
    con.print()

    baseline_monthly = (
        config.baseline.monthly_cost if config.baseline and config.baseline.monthly_cost else 0.0
    )

    con.print(Rule(style="dim"))
    if have_any_live_data:
        con.print(f"  [dim]Total API spend (tracked):[/dim]   [bold]${known_total:.2f}/mo[/bold]")
    if baseline_monthly > 0:
        con.print(
            f"  [dim]Pre-overhaul subscriptions:[/dim]   [bold]${baseline_monthly:.0f}/mo[/bold]"
        )
        baseline_savings_annual = baseline_monthly * 12
        if have_any_live_data:
            net_monthly = baseline_monthly - known_total
            net_annual = net_monthly * 12
            color = "green" if net_annual > 0 else "red"
            con.print(
                f"  [bold {color}]Estimated annual savings:[/bold {color}]   ${net_annual:.0f}/yr"
            )
        else:
            con.print(
                f"  [bold green]Subscription savings:[/bold green]       ${baseline_savings_annual:.0f}/yr "
                "[dim](API spend not yet tracked)[/dim]"
            )
    con.print(Rule(style="dim"))
    con.print()


def _print_provider(s: ProviderSpend, con: Console) -> None:
    label = PROVIDER_LABELS.get(s.provider, s.provider.title())
    if s.amount_usd is None:
        con.print(
            f"  [dim]{label}:[/dim]      [yellow]unknown[/yellow] [dim]— {s.detail}[/dim]"
        )
    else:
        con.print(
            f"  [dim]{label}:[/dim]      [bold]${s.amount_usd:.2f}[/bold] [dim]({s.detail})[/dim]"
        )
