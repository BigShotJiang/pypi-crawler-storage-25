from pathlib import Path
from typing import Annotated, Optional

import typer
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn

from burnrate.scanner.python_ast import scan_python_file
from burnrate.scanner.regex_scan import scan_ts_file
from burnrate.scanner.report import Report, render_report

console = Console()

SKIP_DIRS = {
    "node_modules", ".next", ".git", "dist", "build",
    "__pycache__", ".venv", ".mypy_cache", ".pytest_cache",
}

PYTHON_SUFFIX = ".py"
TS_SUFFIXES = {".ts", ".tsx", ".js", ".jsx"}


def audit(
    path: Annotated[
        Optional[Path],
        typer.Argument(help="Path to scan (default: current directory)"),
    ] = None,
) -> None:
    """Scan a codebase for wasteful AI API usage. Read-only — no files are changed."""
    root = (path or Path(".")).resolve()

    if not root.exists():
        console.print(f"[red]Path does not exist:[/red] {root}")
        raise typer.Exit(1)

    files = _collect_files(root)

    report = Report(scanned_files=len(files))

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
        transient=True,
    ) as progress:
        task = progress.add_task(f"Scanning {len(files)} files...", total=len(files))
        for f in files:
            if f.suffix == PYTHON_SUFFIX:
                report.findings.extend(scan_python_file(f))
            elif f.suffix in TS_SUFFIXES:
                report.findings.extend(scan_ts_file(f))
            progress.advance(task)

    console.print(f"[dim]Scanned {len(files)} files[/dim]")
    render_report(report, console)


def _collect_files(root: Path) -> list[Path]:
    if root.is_file():
        return [root]

    result = []
    for item in root.rglob("*"):
        if _should_skip(item):
            continue
        if item.is_file() and (item.suffix == PYTHON_SUFFIX or item.suffix in TS_SUFFIXES):
            result.append(item)
    return sorted(result)


def _should_skip(path: Path) -> bool:
    return any(part in SKIP_DIRS for part in path.parts)
