from rich.console import Console
from rich.prompt import Confirm, Prompt
from rich.rule import Rule

from burnrate import __version__
from burnrate.banner import print_banner
from burnrate.config import (
    BaselineConfig,
    BurnrateConfig,
    ProviderConfig,
    SystemConfig,
    save_config,
)
from burnrate.overhaul.catalog import CATALOG
from burnrate.system import detect_system

console = Console()

PROVIDERS = [
    ("anthropic", "Anthropic"),
    ("openai", "OpenAI"),
    ("google", "Google Gemini"),
    ("groq", "Groq"),
    ("mistral", "Mistral"),
]


def _select_providers() -> list[tuple[str, str]]:
    console.print("[bold]Which providers do you have API keys for?[/bold]")
    console.print("[dim]Press Enter to toggle, empty input when done.[/dim]\n")

    selected = set()
    for key, label in PROVIDERS:
        answer = Confirm.ask(f"  {label}", default=False)
        if answer:
            selected.add(key)

    return [(k, label) for k, label in PROVIDERS if k in selected]


def _collect_keys(selected: list[tuple[str, str]]) -> dict[str, str]:
    keys: dict[str, str] = {}
    if not selected:
        return keys
    console.print()
    for key, label in selected:
        value = Prompt.ask(f"  [bold]{label}[/bold] API key", password=True)
        if value.strip():
            keys[key] = value.strip()
    return keys


def _select_subscriptions() -> tuple[list[str], float]:
    console.print()
    console.print("[bold]Which paid AI tools are you currently subscribed to?[/bold]")
    console.print("[dim]These power the personalized overhaul recommendation.[/dim]\n")

    selected: list[str] = []
    total = 0.0
    for sub_id, entry in CATALOG.items():
        answer = Confirm.ask(
            f"  {entry.label} [dim](${entry.cost:.0f}/mo)[/dim]", default=False
        )
        if answer:
            selected.append(sub_id)
            total += entry.cost
    return selected, total


def _print_system_info(info: dict) -> None:
    console.print()
    console.print("[bold]Detecting your system...[/bold]")

    os_label = info["os"]
    arch = info["arch"]
    ram = info["ram_gb"]

    arch_label = "Apple Silicon" if arch == "arm64" else arch
    ram_label = f", {ram}GB RAM" if ram else ""
    console.print(f"  [dim]OS:[/dim]     {os_label} ({arch_label}{ram_label})")

    shell = info["shell"] or "unknown"
    console.print(f"  [dim]Shell:[/dim]  {shell}")

    editor = info["editor"]
    if editor:
        console.print(f"  [dim]Editor:[/dim] {editor} (detected via running processes)")
    else:
        console.print("  [dim]Editor:[/dim] not detected")


def auth() -> None:
    """First-time setup: store API keys and detect system profile."""
    print_banner(__version__)

    selected = _select_providers()
    keys = _collect_keys(selected)

    system_info = detect_system()
    _print_system_info(system_info)

    sub_ids, monthly_cost = _select_subscriptions()

    providers = {k: ProviderConfig(key=v) for k, v in keys.items()}
    sys_cfg = SystemConfig(
        os=system_info["os"],
        arch=system_info["arch"],
        ram_gb=system_info["ram_gb"],
        shell=system_info["shell"],
        editor=system_info["editor"],
    )
    baseline_cfg = (
        BaselineConfig(subscriptions=sub_ids, monthly_cost=monthly_cost)
        if sub_ids
        else None
    )
    cfg = BurnrateConfig(providers=providers, system=sys_cfg, baseline=baseline_cfg)
    save_config(cfg)

    console.print()
    console.print(Rule(style="red dim"))
    console.print(
        "  [bold green]Config saved to[/bold green] [dim]~/.burnrate/config.json[/dim]"
    )
    console.print(Rule(style="red dim"))
    console.print()
