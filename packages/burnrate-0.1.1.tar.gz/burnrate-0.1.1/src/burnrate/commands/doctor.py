from __future__ import annotations

import typer
from rich.console import Console

from burnrate.checks import CheckResult, CheckStatus, run_all_checks
from burnrate.config import config_path, load_config


def doctor() -> None:
    """Verify the Burnrate setup — config, Python version, API keys, optional tools."""
    con = Console()
    con.print()
    con.print("Checking setup...")
    con.print()

    config_present = config_path().exists()
    cfg = load_config() if config_present else None
    from burnrate.config import BurnrateConfig

    results = run_all_checks(cfg or BurnrateConfig(), config_present)

    for r in results:
        _print(r, con)

    con.print()
    fails = sum(1 for r in results if r.status == CheckStatus.FAIL)
    if fails == 0:
        con.print("[green]All checks passed.[/green]")
    else:
        con.print(f"[red]{fails} check(s) failed.[/red]")
    con.print()

    raise typer.Exit(code=1 if fails else 0)


def _print(r: CheckResult, con: Console) -> None:
    if r.status == CheckStatus.PASS:
        line = f"  [green]✓[/green] {r.name}"
        if r.detail:
            line += f" [dim]({r.detail})[/dim]"
    elif r.status == CheckStatus.FAIL:
        line = f"  [red]✗[/red] {r.name}"
        if r.detail:
            line += f" [red]({r.detail})[/red]"
    elif r.status == CheckStatus.SKIP:
        line = f"  [dim]○[/dim] [dim]{r.name}[/dim]"
        if r.detail:
            line += f" [dim]({r.detail})[/dim]"
    else:
        line = f"  [dim]—[/dim] [dim]{r.name}[/dim]"
        if r.detail:
            line += f" [dim]({r.detail})[/dim]"
    con.print(line)
