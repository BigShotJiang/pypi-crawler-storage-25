from __future__ import annotations

from burnrate.mcp_server import run_stdio


def mcp() -> None:
    """Run the Burnrate MCP server over stdio (for Claude Code, Cursor, Zed, etc.)."""
    run_stdio()
