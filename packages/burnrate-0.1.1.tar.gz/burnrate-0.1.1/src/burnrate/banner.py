from rich.console import Console
from rich.rule import Rule

console = Console()

PIXEL_FONT = {
    'B': ["███ ", "█  █", "███ ", "█  █", "███ "],
    'U': ["█  █", "█  █", "█  █", "█  █", "████"],
    'R': ["███ ", "█  █", "███ ", "█ █ ", "█  █"],
    'N': ["█  █", "██ █", "█▐ █", "█ ██", "█  █"],
    'A': [" ██ ", "█  █", "████", "█  █", "█  █"],
    'T': ["████", " █  ", " █  ", " █  ", " █  "],
    'E': ["████", "█   ", "███ ", "█   ", "████"],
}

WORD = "BURNRATE"
SPLIT = 4  # "BURN" red, "RATE" light gray


def render_logo(con: Console | None = None) -> None:
    con = con or console
    rows = 5
    lines = [""] * rows
    for i, char in enumerate(WORD):
        pixels = PIXEL_FONT.get(char, ["    "] * rows)
        color = "bold red" if i < SPLIT else "bold white"
        for row in range(rows):
            lines[row] += f"[{color}]{pixels[row]}[/{color}] "
    for line in lines:
        con.print(line)


def print_banner(version: str = "0.1.0", con: Console | None = None) -> None:
    con = con or console
    con.print()
    render_logo(con)
    con.print()
    con.print(Rule(style="red dim"))
    con.print(f"  [dim]v{version}[/dim]  [dim]Stop overpaying for AI.[/dim]")
    con.print(Rule(style="red dim"))
    con.print()
