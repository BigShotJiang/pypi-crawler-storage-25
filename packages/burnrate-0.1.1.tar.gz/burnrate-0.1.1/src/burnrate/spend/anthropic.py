from __future__ import annotations

import datetime

import httpx

from burnrate.spend.prices import estimate_cost
from burnrate.spend.types import ProviderSpend

ENDPOINT = "https://api.anthropic.com/v1/organizations/usage_report/messages"
TIMEOUT = 10.0


def query_anthropic_spend(
    key: str, today: datetime.date | None = None
) -> ProviderSpend:
    today = today or datetime.date.today()
    start = today.replace(day=1).isoformat() + "T00:00:00Z"
    end = today.isoformat() + "T23:59:59Z"

    try:
        with httpx.Client(timeout=TIMEOUT) as client:
            r = client.get(
                ENDPOINT,
                headers={"x-api-key": key, "anthropic-version": "2023-06-01"},
                params={"starting_at": start, "ending_at": end, "bucket_width": "1d"},
            )
    except httpx.HTTPError as e:
        return ProviderSpend("anthropic", None, f"network error: {e}")

    if r.status_code in (401, 403):
        return ProviderSpend("anthropic", None, "requires admin API key (sk-ant-admin-...)")
    if r.status_code == 404:
        return ProviderSpend("anthropic", None, "usage endpoint not available for this account")
    if r.status_code != 200:
        return ProviderSpend("anthropic", None, f"unexpected status {r.status_code}")

    try:
        data = r.json()
    except ValueError:
        return ProviderSpend("anthropic", None, "response was not valid JSON")

    total = _sum_anthropic_usage(data)
    if total is None:
        return ProviderSpend("anthropic", None, "could not parse usage response")
    return ProviderSpend("anthropic", total, "via Admin API")


def _sum_anthropic_usage(data: dict) -> float | None:
    buckets = data.get("data")
    if not isinstance(buckets, list):
        return None

    total = 0.0
    saw_any = False
    for bucket in buckets:
        results = bucket.get("results", []) if isinstance(bucket, dict) else []
        for entry in results:
            if not isinstance(entry, dict):
                continue
            model = entry.get("model")
            input_tokens = _get_int(entry, ("input_tokens", "uncached_input_tokens"))
            output_tokens = _get_int(entry, ("output_tokens",))
            if model is None or input_tokens is None or output_tokens is None:
                continue
            cost = estimate_cost(model, input_tokens, output_tokens)
            if cost is None:
                continue
            total += cost
            saw_any = True

    return total if saw_any else None


def _get_int(entry: dict, keys: tuple[str, ...]) -> int | None:
    for k in keys:
        v = entry.get(k)
        if isinstance(v, int):
            return v
    return None
