from __future__ import annotations

# Rough list prices per million tokens (input, output) in USD.
# These are approximate v0 constants — published rates as of 2026Q1.
# When provider usage APIs return both tokens and a precomputed cost field,
# prefer the precomputed cost; fall back to this table for token-only data.
MODEL_PRICES_USD_PER_MTOK: dict[str, tuple[float, float]] = {
    "claude-haiku-4-5": (1.0, 5.0),
    "claude-sonnet-4-6": (3.0, 15.0),
    "claude-opus-4": (15.0, 75.0),
    "claude-opus-4-1": (15.0, 75.0),
    "gpt-4o": (5.0, 20.0),
    "gpt-4o-mini": (0.30, 1.20),
    "o1": (15.0, 60.0),
    "o3-mini": (3.0, 12.0),
}


def estimate_cost(model: str, input_tokens: int, output_tokens: int) -> float | None:
    prices = MODEL_PRICES_USD_PER_MTOK.get(model)
    if prices is None:
        return None
    in_price, out_price = prices
    return (input_tokens / 1_000_000) * in_price + (output_tokens / 1_000_000) * out_price
