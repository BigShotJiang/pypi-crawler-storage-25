from __future__ import annotations

from dataclasses import dataclass


@dataclass
class ProviderSpend:
    provider: str
    amount_usd: float | None
    detail: str
