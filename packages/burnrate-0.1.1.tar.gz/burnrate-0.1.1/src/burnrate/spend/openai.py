from __future__ import annotations

import datetime

import httpx

from burnrate.spend.types import ProviderSpend

ENDPOINT = "https://api.openai.com/v1/organization/costs"
TIMEOUT = 10.0


def query_openai_spend(
    key: str, today: datetime.date | None = None
) -> ProviderSpend:
    today = today or datetime.date.today()
    start = int(
        datetime.datetime(today.year, today.month, 1, tzinfo=datetime.timezone.utc).timestamp()
    )
    end = int(
        datetime.datetime(today.year, today.month, today.day, 23, 59, 59, tzinfo=datetime.timezone.utc).timestamp()
    )

    try:
        with httpx.Client(timeout=TIMEOUT) as client:
            r = client.get(
                ENDPOINT,
                headers={"Authorization": f"Bearer {key}"},
                params={"start_time": start, "end_time": end},
            )
    except httpx.HTTPError as e:
        return ProviderSpend("openai", None, f"network error: {e}")

    if r.status_code in (401, 403):
        return ProviderSpend("openai", None, "requires admin API key (org-level)")
    if r.status_code == 404:
        return ProviderSpend("openai", None, "costs endpoint not available for this account")
    if r.status_code != 200:
        return ProviderSpend("openai", None, f"unexpected status {r.status_code}")

    try:
        data = r.json()
    except ValueError:
        return ProviderSpend("openai", None, "response was not valid JSON")

    total = _sum_openai_costs(data)
    if total is None:
        return ProviderSpend("openai", None, "could not parse usage response")
    return ProviderSpend("openai", total, "via Admin API")


def _sum_openai_costs(data: dict) -> float | None:
    buckets = data.get("data")
    if not isinstance(buckets, list):
        return None

    total = 0.0
    saw_any = False
    for bucket in buckets:
        results = bucket.get("results", []) if isinstance(bucket, dict) else []
        for entry in results:
            if not isinstance(entry, dict):
                continue
            amount = entry.get("amount")
            if isinstance(amount, dict):
                value = amount.get("value")
                if isinstance(value, (int, float)):
                    total += float(value)
                    saw_any = True
            elif isinstance(amount, (int, float)):
                total += float(amount)
                saw_any = True

    return total if saw_any else None
