from __future__ import annotations

from burnrate.config import BurnrateConfig
from burnrate.spend.anthropic import query_anthropic_spend
from burnrate.spend.openai import query_openai_spend
from burnrate.spend.types import ProviderSpend


def gather_spend(config: BurnrateConfig) -> list[ProviderSpend]:
    results: list[ProviderSpend] = []

    if "anthropic" in config.providers:
        results.append(query_anthropic_spend(config.providers["anthropic"].key))
    if "openai" in config.providers:
        results.append(query_openai_spend(config.providers["openai"].key))

    return results
