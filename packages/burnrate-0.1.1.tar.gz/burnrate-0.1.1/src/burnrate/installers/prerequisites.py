from __future__ import annotations

import platform
import shutil


def is_darwin() -> bool:
    return platform.system() == "Darwin"


def has_brew() -> bool:
    return shutil.which("brew") is not None


def has_pipx() -> bool:
    return shutil.which("pipx") is not None


def has_command(cmd: str) -> bool:
    return shutil.which(cmd) is not None
