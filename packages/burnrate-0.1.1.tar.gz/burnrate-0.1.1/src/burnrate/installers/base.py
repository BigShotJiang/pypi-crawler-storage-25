from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Callable


class StepStatus(str, Enum):
    PENDING = "PENDING"
    SKIPPED_ALREADY_DONE = "SKIPPED_ALREADY_DONE"
    SKIPPED_PREREQ_MISSING = "SKIPPED_PREREQ_MISSING"
    SUCCESS = "SUCCESS"
    FAILED = "FAILED"


@dataclass
class InstallStep:
    description: str
    commands: list[list[str]] = field(default_factory=list)
    already_done: Callable[[], bool] = lambda: False
    requires: list[str] = field(default_factory=list)
    followup_hint: str = ""
    write_files: dict[str, str] = field(default_factory=dict)


@dataclass
class StepResult:
    step: InstallStep
    status: StepStatus
    detail: str = ""
