from __future__ import annotations

import subprocess

from rich.console import Console

from burnrate.installers import prerequisites
from burnrate.installers.base import InstallStep, StepResult, StepStatus

PREREQ_CHECKS = {
    "brew": (lambda: prerequisites.has_brew(), "Install Homebrew from https://brew.sh"),
    "pipx": (lambda: prerequisites.has_pipx(), "Install pipx: `brew install pipx && pipx ensurepath`"),
    "ollama": (lambda: prerequisites.has_command("ollama"), "Ollama install step must run first"),
}


def preview_plan(steps: list[InstallStep], con: Console) -> None:
    con.print()
    con.print("[bold]Burnrate will:[/bold]")
    for step in steps:
        if step.already_done():
            con.print(f"  [dim]○ {step.description} (already installed — will skip)[/dim]")
            continue
        con.print(f"  [green]✓[/green] {step.description}")
        if step.commands:
            cmd_preview = " ".join(step.commands[0])
            con.print(f"    [dim]$ {cmd_preview}[/dim]")
        for path in step.write_files:
            con.print(f"    [dim]write {path}[/dim]")
    con.print()


def execute_plan(
    steps: list[InstallStep], con: Console, dry_run: bool = False
) -> list[StepResult]:
    results: list[StepResult] = []
    total = len(steps)

    for idx, step in enumerate(steps, start=1):
        prefix = f"[{idx}/{total}]"

        if step.already_done():
            con.print(f"{prefix} {step.description}... [dim]already installed, skipping[/dim]")
            results.append(StepResult(step=step, status=StepStatus.SKIPPED_ALREADY_DONE))
            continue

        if not dry_run:
            missing_prereq = _missing_prereq(step)
            if missing_prereq:
                con.print(
                    f"{prefix} {step.description}... [red]skipped — {missing_prereq}[/red]"
                )
                results.append(
                    StepResult(
                        step=step,
                        status=StepStatus.SKIPPED_PREREQ_MISSING,
                        detail=missing_prereq,
                    )
                )
                continue

        if dry_run:
            preview = (
                " ".join(step.commands[0]) if step.commands
                else f"write {next(iter(step.write_files))}" if step.write_files
                else ""
            )
            con.print(f"{prefix} {step.description}... [dim](dry-run) {preview}[/dim]")
            results.append(
                StepResult(step=step, status=StepStatus.SUCCESS, detail="dry-run")
            )
            continue

        con.print(f"{prefix} {step.description}...", end=" ")
        ok, msg = _run_commands(step.commands)
        if not ok:
            con.print(f"[red]✗ {msg}[/red]")
            results.append(StepResult(step=step, status=StepStatus.FAILED, detail=msg))
            break
        ok, msg = _write_files(step.write_files)
        if not ok:
            con.print(f"[red]✗ {msg}[/red]")
            results.append(StepResult(step=step, status=StepStatus.FAILED, detail=msg))
            break
        con.print("[green]✓[/green]")
        results.append(StepResult(step=step, status=StepStatus.SUCCESS))

    return results


def _missing_prereq(step: InstallStep) -> str:
    for prereq in step.requires:
        check_pair = PREREQ_CHECKS.get(prereq)
        if check_pair is None:
            continue
        check, hint = check_pair
        if not check():
            return f"{prereq} not found — {hint}"
    return ""


def _run_commands(commands: list[list[str]]) -> tuple[bool, str]:
    for cmd in commands:
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, check=False)
        except OSError as e:
            return False, f"{cmd[0]}: {e}"
        if result.returncode != 0:
            stderr_snippet = (result.stderr or result.stdout or "").strip().splitlines()
            tail = stderr_snippet[-1] if stderr_snippet else f"exit {result.returncode}"
            return False, tail[:200]
    return True, ""


def _write_files(files: dict[str, str]) -> tuple[bool, str]:
    from pathlib import Path

    for path_str, content in files.items():
        try:
            path = Path(path_str).expanduser()
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(content)
        except OSError as e:
            return False, f"writing {path_str}: {e}"
    return True, ""
