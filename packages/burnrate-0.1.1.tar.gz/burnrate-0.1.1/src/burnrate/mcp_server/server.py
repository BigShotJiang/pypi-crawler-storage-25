from __future__ import annotations

from mcp.server.fastmcp import FastMCP

from burnrate.mcp_server import tools


def build_server() -> FastMCP:
    server = FastMCP(name="burnrate")

    @server.tool(
        name="burnrate_check_file",
        description=(
            "Scan a single source file for wasteful AI API usage — expensive "
            "model choices, missing max_tokens, missing prompt caching. "
            "Returns a list of findings with file:line citations."
        ),
    )
    def burnrate_check_file(path: str) -> dict:
        return tools.check_file(path)

    @server.tool(
        name="burnrate_suggest_fix",
        description=(
            "Given a code snippet and a finding type "
            "('expensive_model' or 'missing_max_tokens'), return the patched "
            "code and a one-line explanation."
        ),
    )
    def burnrate_suggest_fix(code: str, finding_type: str) -> dict:
        return tools.suggest_fix(code, finding_type)

    @server.tool(
        name="burnrate_get_spend",
        description=(
            "Return the current month's API spend across configured providers. "
            "v0 returns a stub — live spend ships with `burnrate status`."
        ),
    )
    def burnrate_get_spend() -> dict:
        return tools.get_spend()

    @server.tool(
        name="burnrate_recommend_model",
        description=(
            "Given a task description, return the most cost-effective model "
            "for the task plus its cost class and rationale."
        ),
    )
    def burnrate_recommend_model(task_description: str) -> dict:
        return tools.recommend_model(task_description)

    return server
