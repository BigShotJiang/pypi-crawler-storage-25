from __future__ import annotations

import datetime
import tempfile
from pathlib import Path
from typing import Any

from burnrate.fixers import get_fixer_for
from burnrate.scanner.python_ast import scan_python_file
from burnrate.scanner.regex_scan import scan_ts_file
from burnrate.scanner.report import Finding

PYTHON_EXTS = {".py"}
TS_EXTS = {".ts", ".tsx", ".js", ".jsx"}


def _finding_to_dict(f: Finding) -> dict[str, Any]:
    return {
        "file": f.file,
        "line": f.line,
        "severity": f.severity.value,
        "message": f.message,
        "detail": f.detail,
        "savings_per_month_usd": f.savings_stub,
    }


def check_file(path: str) -> dict[str, Any]:
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"no such file: {path}")

    ext = p.suffix.lower()
    if ext in PYTHON_EXTS:
        findings = scan_python_file(p)
    elif ext in TS_EXTS:
        findings = scan_ts_file(p)
    else:
        return {"findings": [], "note": f"unsupported extension: {ext}"}

    return {"findings": [_finding_to_dict(f) for f in findings]}


def suggest_fix(code: str, finding_type: str) -> dict[str, Any]:
    if finding_type not in ("expensive_model", "missing_max_tokens"):
        return {
            "patched_code": code,
            "explanation": "no auto-fixer for this finding type",
            "savings_per_month_usd": 0.0,
        }

    ext = ".py" if _looks_like_python(code) else ".ts"
    with tempfile.NamedTemporaryFile(
        mode="w", suffix=ext, delete=False, encoding="utf-8"
    ) as tmp:
        tmp.write(code)
        tmp_path = Path(tmp.name)

    try:
        if ext == ".py":
            findings = scan_python_file(tmp_path)
        else:
            findings = scan_ts_file(tmp_path)

        if finding_type == "expensive_model":
            relevant = [f for f in findings if "Expensive model" in f.message]
        else:
            relevant = [f for f in findings if "max_tokens" in f.message]

        if not relevant:
            return {
                "patched_code": code,
                "explanation": "no matching findings in snippet",
                "savings_per_month_usd": 0.0,
            }

        # v0: fix the first matching finding only — applying multiple textual
        # patches in sequence would shift line numbers and corrupt later splices.
        # MCP clients can re-call with the patched output to chain fixes.
        finding = relevant[0]
        fixer = get_fixer_for(finding)
        if fixer is None:
            return {
                "patched_code": code,
                "explanation": "no fixer registered for this finding",
                "savings_per_month_usd": 0.0,
            }

        patched = fixer.apply(finding, code)
        explanation = finding.message
        if finding.detail:
            explanation += f" — {finding.detail}"
        return {
            "patched_code": patched,
            "explanation": explanation,
            "savings_per_month_usd": finding.savings_stub,
        }
    finally:
        tmp_path.unlink(missing_ok=True)


def _looks_like_python(code: str) -> bool:
    py_signals = ("import ", "from ", "def ", "class ", "client.messages.create(")
    ts_signals = ("const ", "let ", "import {", 'from "', "function ", " : ")
    py_score = sum(1 for s in py_signals if s in code)
    ts_score = sum(1 for s in ts_signals if s in code)
    return py_score >= ts_score


def get_spend() -> dict[str, Any]:
    return {
        "currency": "usd",
        "month": datetime.date.today().strftime("%Y-%m"),
        "providers": {},
        "note": "Live spend tracking ships in `burnrate status` — not yet implemented",
    }


_MODEL_RULES: list[tuple[tuple[str, ...], str, str, str]] = [
    (
        ("classify", "classifier", "categorize", "intent"),
        "claude-haiku-4-5",
        "cheap",
        "Simple classification — Haiku-class handles this at ~2% of Opus cost",
    ),
    (
        ("extract", "summarize", "summary", "parse"),
        "claude-haiku-4-5",
        "cheap",
        "Extractive tasks rarely need Opus-level reasoning",
    ),
    (
        ("embed", "embedding"),
        "local:nomic-embed-text",
        "free",
        "Embeddings should run locally via Ollama; no API cost",
    ),
    (
        ("autocomplete", "completion", "next token"),
        "local:qwen3:30b-a3b",
        "free",
        "Autocomplete is a local-model task — zero latency, zero cost",
    ),
    (
        ("reason", "plan", "agent", "multi-step", "complex"),
        "claude-sonnet-4-6",
        "medium",
        "Multi-step reasoning benefits from Sonnet; reserve Opus for the hardest tasks",
    ),
]


def recommend_model(task_description: str) -> dict[str, Any]:
    desc = task_description.lower()
    for keywords, model, cost_class, reason in _MODEL_RULES:
        if any(k in desc for k in keywords):
            return {"model": model, "cost_class": cost_class, "reason": reason}
    return {
        "model": "claude-haiku-4-5",
        "cost_class": "cheap",
        "reason": "Default to cheap for unknown tasks; escalate if quality suffers",
    }
