from __future__ import annotations

from burnrate.mcp_server.server import build_server


def run_stdio() -> None:
    server = build_server()
    server.run(transport="stdio")


__all__ = ["build_server", "run_stdio"]
