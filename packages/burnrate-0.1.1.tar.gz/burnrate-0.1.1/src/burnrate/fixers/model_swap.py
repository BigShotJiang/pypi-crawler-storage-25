from __future__ import annotations

import re

from burnrate.fixers.base import Fixer
from burnrate.scanner.patterns import EXPENSIVE_MODEL_NAMES, model_info
from burnrate.scanner.report import Finding

# Matches: model="..." or model: "..." (Python kwarg or TS property)
_MODEL_PATTERN = re.compile(
    r"""(model\s*[:=]\s*['"])([^'"]+)(['"])"""
)


class ModelSwapFixer:
    """Replace an expensive model string literal with its recommended cheaper alternative."""

    def can_fix(self, finding: Finding) -> bool:
        return (
            "Expensive model:" in finding.message
            and bool(finding.alternative)
        )

    def apply(self, finding: Finding, source: str) -> str:
        expensive_name = finding.message.replace("Expensive model:", "").strip()
        info = model_info(expensive_name)
        if info is None:
            return source

        target_line_idx = finding.line - 1
        lines = source.splitlines(keepends=True)
        if target_line_idx >= len(lines):
            return source

        # The AST scanner reports the Call node line (may be the opening line),
        # while the model= keyword could be on the same or a subsequent line.
        # Search up to 10 lines forward from the flagged line.
        search_end = min(target_line_idx + 10, len(lines))
        for i in range(target_line_idx, search_end):
            line = lines[i]
            new_line, count = _MODEL_PATTERN.subn(
                _make_replacement(expensive_name, info.recommended_alternative),
                line,
            )
            if count > 0:
                lines[i] = new_line
                return "".join(lines)

        return source


def _make_replacement(old: str, new: str):
    def _sub(m: re.Match) -> str:
        if m.group(2) == old:
            return m.group(1) + new + m.group(3)
        return m.group(0)
    return _sub
