from __future__ import annotations

import difflib
import os
from dataclasses import dataclass
from typing import Protocol

from burnrate.scanner.report import Finding


@dataclass
class FixResult:
    file: str
    original: str
    patched: str

    @property
    def diff(self) -> str:
        original_lines = self.original.splitlines(keepends=True)
        patched_lines = self.patched.splitlines(keepends=True)
        rel = os.path.relpath(self.file)
        return "".join(
            difflib.unified_diff(
                original_lines,
                patched_lines,
                fromfile=f"a/{rel}",
                tofile=f"b/{rel}",
                n=3,
            )
        )

    @property
    def changed(self) -> bool:
        return self.original != self.patched


class Fixer(Protocol):
    def can_fix(self, finding: Finding) -> bool: ...

    def apply(self, finding: Finding, source: str) -> str: ...
