from __future__ import annotations

from pathlib import Path

from burnrate.fixers.add_max_tokens import AddMaxTokensFixer
from burnrate.fixers.base import FixResult, Fixer
from burnrate.fixers.cache_control import CacheControlFixer
from burnrate.fixers.model_swap import ModelSwapFixer
from burnrate.scanner.report import Finding

_FIXERS: list[Fixer] = [
    ModelSwapFixer(),
    AddMaxTokensFixer(),
    CacheControlFixer(),
]


def get_fixer_for(finding: Finding) -> Fixer | None:
    for fixer in _FIXERS:
        if fixer.can_fix(finding):
            return fixer
    return None


def apply_fix(finding: Finding, dry_run: bool = False) -> FixResult | None:
    fixer = get_fixer_for(finding)
    if fixer is None:
        return None

    path = Path(finding.file)
    try:
        original = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return None

    patched = fixer.apply(finding, original)
    result = FixResult(file=finding.file, original=original, patched=patched)

    if result.changed and not dry_run:
        path.write_text(patched, encoding="utf-8")

    return result
