from __future__ import annotations

import re

from burnrate.fixers.base import Fixer
from burnrate.scanner.report import Finding


# 1024 is a conservative safe default for v0: large enough for most API responses
# (summaries, classifications, short completions) but small enough to bound spend
# meaningfully. Users can tune upward once they know their actual output sizes.
_DEFAULT_MAX_TOKENS = 1024

_PY_SUFFIX = ".py"
_TS_SUFFIXES = {".ts", ".tsx", ".js", ".jsx"}

_MAX_TOKENS_CHECK = re.compile(r"\bmax_tokens\b")


class AddMaxTokensFixer:
    """Insert max_tokens into messages.create() calls that are missing it."""

    def can_fix(self, finding: Finding) -> bool:
        return "max_tokens" in finding.message and "missing" in finding.message

    def apply(self, finding: Finding, source: str) -> str:
        file_lower = finding.file.lower()
        if file_lower.endswith(_PY_SUFFIX):
            return _apply_python(finding, source)
        if any(file_lower.endswith(s) for s in _TS_SUFFIXES):
            return _apply_ts(finding, source)
        return source


def _apply_python(finding: Finding, source: str) -> str:
    lines = source.splitlines(keepends=True)
    target_line_idx = finding.line - 1
    if target_line_idx >= len(lines):
        return source

    # Locate the '(' that opens the messages.create call on or near the flagged line.
    # The AST lineno points to the Call node's first line; scan forward from there.
    flat = "".join(lines[target_line_idx:])
    create_match = re.search(r"\.messages\.create\s*\(", flat)
    if not create_match:
        return source

    call_open = create_match.end() - 1  # index of '(' in `flat`
    prefix_len = sum(len(l) for l in lines[:target_line_idx])
    abs_open = prefix_len + call_open

    close_idx = _matching_close(source, abs_open, "(", ")")
    if close_idx is None:
        return source

    call_body = source[abs_open + 1:close_idx]
    if _MAX_TOKENS_CHECK.search(call_body):
        return source

    # Determine indentation from the kwargs already in the call body.
    # Find the first non-empty, non-opening-paren line inside the call.
    indent_str = _infer_indent_from_body(call_body)

    insertion = f"{indent_str}max_tokens={_DEFAULT_MAX_TOKENS},\n"
    return source[:close_idx] + insertion + source[close_idx:]


def _apply_ts(finding: Finding, source: str) -> str:
    lines = source.splitlines(keepends=True)
    target_line_idx = finding.line - 1
    if target_line_idx >= len(lines):
        return source

    flat = "".join(lines[target_line_idx:])
    create_match = re.search(r"\.messages\.create\s*\(\s*\{", flat)
    if not create_match:
        return source

    # abs position of the '{' opening the object literal
    prefix_len = sum(len(l) for l in lines[:target_line_idx])
    brace_open_rel = flat.index("{", create_match.start())
    abs_open = prefix_len + brace_open_rel

    close_idx = _matching_close(source, abs_open, "{", "}")
    if close_idx is None:
        return source

    call_body = source[abs_open + 1:close_idx]
    if _MAX_TOKENS_CHECK.search(call_body):
        return source

    # Determine indentation from existing properties in the object body
    indent_str = _infer_indent_from_body(call_body)

    # Insert max_tokens as the FIRST property so that the TS regex scanner
    # (which uses [^}]* before handling nested braces) can always find it.
    # The scanner stops at the first '}' in the body, so a property inserted
    # after messages: [{...}] would be invisible to the idempotency check.
    open_ch = source[abs_open]  # '{'
    after_open = abs_open + 1

    # Find where the first property starts (skip leading whitespace/newline)
    body_start = after_open
    while body_start < close_idx and source[body_start] in (" ", "\t", "\n", "\r"):
        body_start += 1

    if body_start >= close_idx:
        # Empty body — just fill it
        return source[:after_open] + f" max_tokens: {_DEFAULT_MAX_TOKENS} " + source[after_open:]

    # Determine whether the object is multi-line or single-line
    first_newline = source.find("\n", abs_open, close_idx)
    is_multiline = first_newline != -1

    if is_multiline:
        insertion = f"\n{indent_str}max_tokens: {_DEFAULT_MAX_TOKENS},"
        return source[:after_open] + insertion + source[after_open:]
    else:
        insertion = f" max_tokens: {_DEFAULT_MAX_TOKENS},"
        return source[:after_open] + insertion + source[after_open:]


def _infer_indent_from_body(body: str) -> str:
    """Return the indentation string inferred from the first indented line in `body`."""
    for line in body.splitlines():
        stripped = line.lstrip()
        if stripped and not stripped.startswith("#"):
            indent = len(line) - len(stripped)
            if indent > 0:
                return line[:indent]
    return "    "


def _matching_close(source: str, open_idx: int, open_ch: str, close_ch: str) -> int | None:
    """Return the index of the bracket in `source` that closes the one at `open_idx`."""
    depth = 0
    in_string: str | None = None
    i = open_idx
    while i < len(source):
        ch = source[i]
        if in_string:
            if ch == "\\" and in_string != "`":
                i += 2
                continue
            if ch == in_string:
                in_string = None
        elif ch in ('"', "'", "`"):
            in_string = ch
        elif ch == open_ch:
            depth += 1
        elif ch == close_ch:
            depth -= 1
            if depth == 0:
                return i
        i += 1
    return None
