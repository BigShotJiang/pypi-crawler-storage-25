from __future__ import annotations

import re

from burnrate.fixers.base import Fixer
from burnrate.scanner.report import Finding

_PY_TRIPLE = re.compile(
    r'(\bsystem\s*=\s*)("""(?:.|\n)*?"""|\'\'\'(?:.|\n)*?\'\'\')'
)
_PY_SINGLE = re.compile(
    r"""(\bsystem\s*=\s*)(["'])((?:\\.|(?!\2).)*?)\2"""
)
_TS_TEMPLATE = re.compile(r'(\bsystem\s*:\s*)(`(?:[^`\\]|\\.)*`)')
_TS_QUOTED = re.compile(
    r"""(\bsystem\s*:\s*)(["'])((?:\\.|(?!\2).)*?)\2"""
)


class CacheControlFixer:
    """Wrap a long system-prompt string literal into the Anthropic cache_control array form."""

    def can_fix(self, finding: Finding) -> bool:
        return "cache_control" in finding.message.lower()

    def apply(self, finding: Finding, source: str) -> str:
        is_python = finding.file.endswith(".py")
        is_ts = finding.file.endswith((".ts", ".tsx", ".js", ".jsx"))
        if not (is_python or is_ts):
            return source

        lines = source.splitlines(keepends=True)
        # The Call node's line points to the opening line of messages.create(...).
        # system="..." can be on that line or a few lines later. Search a window.
        target_line_idx = max(finding.line - 1, 0)
        search_end = min(target_line_idx + 15, len(lines))
        offset = sum(len(line) for line in lines[:target_line_idx])
        haystack = "".join(lines[target_line_idx:search_end])

        if is_python:
            new_chunk = _try_python(haystack)
        else:
            new_chunk = _try_ts(haystack)

        if new_chunk is None:
            return source

        return source[:offset] + new_chunk + source[offset + len(haystack):]


def _try_python(text: str) -> str | None:
    m = _PY_TRIPLE.search(text)
    if m is not None:
        prefix, quoted = m.group(1), m.group(2)
        replacement = (
            f'{prefix}[{{"type": "text", "text": {quoted}, '
            f'"cache_control": {{"type": "ephemeral"}}}}]'
        )
        return text[:m.start()] + replacement + text[m.end():]

    m = _PY_SINGLE.search(text)
    if m is not None:
        prefix, quote, content = m.group(1), m.group(2), m.group(3)
        replacement = (
            f'{prefix}[{{"type": "text", "text": {quote}{content}{quote}, '
            f'"cache_control": {{"type": "ephemeral"}}}}]'
        )
        return text[:m.start()] + replacement + text[m.end():]
    return None


def _try_ts(text: str) -> str | None:
    m = _TS_TEMPLATE.search(text)
    if m is not None:
        prefix, template = m.group(1), m.group(2)
        replacement = (
            f'{prefix}[{{type: "text", text: {template}, '
            f'cache_control: {{type: "ephemeral"}}}}]'
        )
        return text[:m.start()] + replacement + text[m.end():]

    m = _TS_QUOTED.search(text)
    if m is not None:
        prefix, quote, content = m.group(1), m.group(2), m.group(3)
        replacement = (
            f'{prefix}[{{type: "text", text: {quote}{content}{quote}, '
            f'cache_control: {{type: "ephemeral"}}}}]'
        )
        return text[:m.start()] + replacement + text[m.end():]
    return None
