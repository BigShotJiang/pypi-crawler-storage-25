import json
from pathlib import Path
from typing import Optional

from pydantic import BaseModel


class ProviderConfig(BaseModel):
    key: str


class SystemConfig(BaseModel):
    os: str
    arch: str
    ram_gb: Optional[int] = None
    shell: Optional[str] = None
    editor: Optional[str] = None


class BaselineConfig(BaseModel):
    subscriptions: list[str] = []
    monthly_cost: Optional[float] = None
    overhaul_date: Optional[str] = None


class BurnrateConfig(BaseModel):
    providers: dict[str, ProviderConfig] = {}
    system: Optional[SystemConfig] = None
    baseline: Optional[BaselineConfig] = None


def config_path() -> Path:
    return Path.home() / ".burnrate" / "config.json"


def load_config() -> BurnrateConfig:
    path = config_path()
    if not path.exists():
        return BurnrateConfig()
    raw = json.loads(path.read_text())
    return BurnrateConfig.model_validate(raw)


def save_config(cfg: BurnrateConfig) -> None:
    path = config_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(cfg.model_dump_json(indent=2, exclude_none=True))
