import os
import platform
import subprocess


def detect_os() -> str:
    system = platform.system().lower()
    if system == "darwin":
        return "darwin"
    if system == "linux":
        return "linux"
    return system


def detect_arch() -> str:
    machine = platform.machine().lower()
    if machine in ("arm64", "aarch64"):
        return "arm64"
    if machine in ("x86_64", "amd64"):
        return "x86_64"
    return machine


def detect_ram_gb() -> int | None:
    try:
        import psutil  # type: ignore[import]
        return round(psutil.virtual_memory().total / (1024**3))
    except ImportError:
        pass

    try:
        pages = os.sysconf("SC_PHYS_PAGES")
        page_size = os.sysconf("SC_PAGE_SIZE")
        return round(pages * page_size / (1024**3))
    except (AttributeError, ValueError):
        pass

    return None


def detect_shell() -> str | None:
    shell = os.environ.get("SHELL")
    if shell:
        return os.path.basename(shell)
    return None


def detect_editor() -> str | None:
    candidates = {
        "cursor": "Cursor",
        "code": "Code",
        "zed": "Zed",
        "windsurf": "Windsurf",
    }
    try:
        result = subprocess.run(
            ["ps", "aux"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        output_lower = result.stdout.lower()
        for key, label in candidates.items():
            if key in output_lower:
                return label
    except Exception:
        pass
    return None


def detect_system() -> dict:
    return {
        "os": detect_os(),
        "arch": detect_arch(),
        "ram_gb": detect_ram_gb(),
        "shell": detect_shell(),
        "editor": detect_editor(),
    }
