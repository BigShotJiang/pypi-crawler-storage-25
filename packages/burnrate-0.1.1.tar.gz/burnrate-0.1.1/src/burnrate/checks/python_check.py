from __future__ import annotations

import sys

from burnrate.checks.base import CheckResult, CheckStatus

MIN_PYTHON = (3, 11)


def check_python() -> CheckResult:
    v = sys.version_info
    version_str = f"{v.major}.{v.minor}.{v.micro}"
    if (v.major, v.minor) >= MIN_PYTHON:
        return CheckResult(
            name="Python version",
            status=CheckStatus.PASS,
            detail=f"v{version_str}",
        )
    return CheckResult(
        name="Python version",
        status=CheckStatus.FAIL,
        detail=f"v{version_str} — Burnrate requires Python ≥ {MIN_PYTHON[0]}.{MIN_PYTHON[1]}",
    )
