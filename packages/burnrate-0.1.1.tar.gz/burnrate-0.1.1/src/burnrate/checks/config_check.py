from __future__ import annotations

from burnrate.checks.base import CheckResult, CheckStatus
from burnrate.config import config_path


def check_config(config_present: bool) -> CheckResult:
    if config_present:
        return CheckResult(
            name="Config file",
            status=CheckStatus.PASS,
            detail=str(config_path()),
        )
    return CheckResult(
        name="Config file",
        status=CheckStatus.FAIL,
        detail=f"not found at {config_path()} — run `burnrate auth`",
    )
