from __future__ import annotations

import platform
import shutil
import subprocess
from pathlib import Path

from burnrate.checks.base import CheckResult, CheckStatus

SUBPROCESS_TIMEOUT = 2.0


def _run(args: list[str]) -> tuple[bool, str]:
    try:
        result = subprocess.run(
            args,
            capture_output=True,
            text=True,
            timeout=SUBPROCESS_TIMEOUT,
            check=False,
        )
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        return False, ""
    if result.returncode != 0:
        return False, ""
    return True, result.stdout


def check_ollama() -> CheckResult:
    name = "ollama"
    if shutil.which("ollama") is None:
        return CheckResult(name=name, status=CheckStatus.INFO, detail="not installed")

    ok, out = _run(["ollama", "list"])
    if not ok:
        return CheckResult(
            name=name,
            status=CheckStatus.INFO,
            detail="installed but not responding",
        )
    lines = [ln for ln in out.splitlines()[1:] if ln.strip()]
    return CheckResult(
        name=name,
        status=CheckStatus.PASS,
        detail=f"{len(lines)} model(s) available",
    )


def check_aider() -> CheckResult:
    name = "aider"
    if shutil.which("aider") is None:
        return CheckResult(name=name, status=CheckStatus.INFO, detail="not installed")
    return CheckResult(name=name, status=CheckStatus.PASS, detail="on PATH")


def check_zed() -> CheckResult:
    name = "zed"
    if shutil.which("zed") is not None:
        return CheckResult(name=name, status=CheckStatus.PASS, detail="on PATH")
    if platform.system() == "Darwin" and Path("/Applications/Zed.app").exists():
        return CheckResult(name=name, status=CheckStatus.PASS, detail="/Applications/Zed.app")
    return CheckResult(name=name, status=CheckStatus.INFO, detail="not installed")
