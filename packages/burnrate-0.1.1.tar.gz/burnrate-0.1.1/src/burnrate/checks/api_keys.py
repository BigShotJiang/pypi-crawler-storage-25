from __future__ import annotations

import httpx

from burnrate.checks.base import CheckResult, CheckStatus

TIMEOUT_SECONDS = 5.0


def check_anthropic(key: str) -> CheckResult:
    name = "Anthropic API key"
    try:
        with httpx.Client(timeout=TIMEOUT_SECONDS) as client:
            r = client.get(
                "https://api.anthropic.com/v1/models",
                headers={"x-api-key": key, "anthropic-version": "2023-06-01"},
            )
    except httpx.HTTPError as e:
        return CheckResult(name=name, status=CheckStatus.FAIL, detail=f"network error: {e}")

    if r.status_code == 200:
        return CheckResult(name=name, status=CheckStatus.PASS, detail="valid")
    if r.status_code in (401, 403):
        return CheckResult(name=name, status=CheckStatus.FAIL, detail="invalid key")
    return CheckResult(
        name=name,
        status=CheckStatus.FAIL,
        detail=f"unexpected status {r.status_code}",
    )


def check_openai(key: str) -> CheckResult:
    name = "OpenAI API key"
    try:
        with httpx.Client(timeout=TIMEOUT_SECONDS) as client:
            r = client.get(
                "https://api.openai.com/v1/models",
                headers={"Authorization": f"Bearer {key}"},
            )
    except httpx.HTTPError as e:
        return CheckResult(name=name, status=CheckStatus.FAIL, detail=f"network error: {e}")

    if r.status_code == 200:
        return CheckResult(name=name, status=CheckStatus.PASS, detail="valid")
    if r.status_code == 401:
        return CheckResult(name=name, status=CheckStatus.FAIL, detail="invalid key")
    return CheckResult(
        name=name,
        status=CheckStatus.FAIL,
        detail=f"unexpected status {r.status_code}",
    )


# TODO(v0.2): Google Gemini, Groq, Mistral validation endpoints.
# Each provider exposes a different shape for "list models" / health probes;
# the spec only requires Anthropic + OpenAI for v0.
