from __future__ import annotations

from burnrate.checks.api_keys import check_anthropic, check_openai
from burnrate.checks.base import CheckResult, CheckStatus
from burnrate.checks.config_check import check_config
from burnrate.checks.python_check import check_python
from burnrate.checks.tools import check_aider, check_ollama, check_zed
from burnrate.config import BurnrateConfig


def run_all_checks(config: BurnrateConfig, config_present: bool) -> list[CheckResult]:
    results: list[CheckResult] = []

    results.append(check_config(config_present))
    results.append(check_python())

    if not config_present:
        for name in ("Anthropic API key", "OpenAI API key"):
            results.append(
                CheckResult(name=name, status=CheckStatus.SKIP, detail="no config")
            )
    else:
        if "anthropic" in config.providers:
            results.append(check_anthropic(config.providers["anthropic"].key))
        if "openai" in config.providers:
            results.append(check_openai(config.providers["openai"].key))

    results.append(check_ollama())
    results.append(check_aider())
    results.append(check_zed())

    return results


__all__ = ["CheckResult", "CheckStatus", "run_all_checks"]
