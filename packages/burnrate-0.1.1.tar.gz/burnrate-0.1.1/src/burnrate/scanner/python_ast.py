import ast
from pathlib import Path

from burnrate.scanner.patterns import (
    EXPENSIVE_MODEL_NAMES,
    LONG_SYSTEM_PROMPT_CHARS,
    MISSING_CACHE_COST_STUB,
    MISSING_MAX_TOKENS_COST_STUB,
    model_info,
)
from burnrate.scanner.report import Finding, Severity


def scan_python_file(path: Path) -> list[Finding]:
    try:
        source = path.read_text(encoding="utf-8", errors="replace")
        tree = ast.parse(source, filename=str(path))
    except SyntaxError:
        return []

    findings: list[Finding] = []
    rel = str(path)

    findings.extend(_check_calls(tree, rel))

    return findings


def _check_calls(tree: ast.AST, rel: str) -> list[Finding]:
    findings = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue

        kwargs = {kw.arg: kw.value for kw in node.keywords if kw.arg}

        findings.extend(_check_model_name(node, kwargs, rel))
        findings.extend(_check_missing_max_tokens(node, kwargs, rel))
        findings.extend(_check_missing_cache(node, kwargs, rel))

    return findings


def _check_model_name(node: ast.Call, kwargs: dict, rel: str) -> list[Finding]:
    findings = []
    model_val = kwargs.get("model")
    if model_val is None:
        return findings

    model_str = _extract_string(model_val)
    if model_str and model_str in EXPENSIVE_MODEL_NAMES:
        info = model_info(model_str)
        savings = info.monthly_cost_stub - info.alternative_cost_stub if info else 0
        findings.append(Finding(
            severity=Severity.HIGH,
            file=rel,
            line=node.lineno,
            message=f"Expensive model: {model_str}",
            detail=f"Consider swapping to {info.recommended_alternative if info else 'a cheaper alternative'}",
            savings_stub=savings,
            current_cost_stub=info.monthly_cost_stub if info else 0,
            alternative=info.recommended_alternative if info else "",
            alternative_cost_stub=info.alternative_cost_stub if info else 0,
        ))
    return findings


def _check_missing_max_tokens(node: ast.Call, kwargs: dict, rel: str) -> list[Finding]:
    if not _is_messages_create(node):
        return []
    if "max_tokens" not in kwargs:
        return [Finding(
            severity=Severity.QUICK_WIN,
            file=rel,
            line=node.lineno,
            message="messages.create() call missing max_tokens — unbounded response spend",
            savings_stub=MISSING_MAX_TOKENS_COST_STUB,
        )]
    return []


def _check_missing_cache(node: ast.Call, kwargs: dict, rel: str) -> list[Finding]:
    system_val = kwargs.get("system")
    if system_val is None:
        return []

    system_str = _extract_string(system_val)
    if system_str is None or len(system_str) < LONG_SYSTEM_PROMPT_CHARS:
        return []

    has_cache = _has_cache_control(system_val)
    if not has_cache:
        return [Finding(
            severity=Severity.HIGH,
            file=rel,
            line=node.lineno,
            message="Long system prompt (>1000 chars) without cache_control",
            detail="Add cache_control: {type: ephemeral} to avoid re-tokenizing on every call",
            savings_stub=MISSING_CACHE_COST_STUB,
            current_cost_stub=94.0,
            alternative="with caching",
            alternative_cost_stub=9.0,
        )]
    return []


def _is_messages_create(node: ast.Call) -> bool:
    func = node.func
    if not isinstance(func, ast.Attribute):
        return False
    if func.attr != "create":
        return False
    if not isinstance(func.value, ast.Attribute):
        return False
    return func.value.attr == "messages"


def _extract_string(node: ast.expr) -> str | None:
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        return node.value
    return None


def _has_cache_control(node: ast.expr) -> bool:
    source = ast.unparse(node)
    return "cache_control" in source
