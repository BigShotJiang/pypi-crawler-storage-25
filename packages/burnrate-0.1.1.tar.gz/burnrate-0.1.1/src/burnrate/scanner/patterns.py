from dataclasses import dataclass


@dataclass
class ModelInfo:
    name: str
    provider: str
    monthly_cost_stub: float
    recommended_alternative: str
    alternative_cost_stub: float


EXPENSIVE_MODELS: list[ModelInfo] = [
    ModelInfo(
        name="claude-opus-4",
        provider="anthropic",
        monthly_cost_stub=180.0,
        recommended_alternative="claude-haiku-4-5",
        alternative_cost_stub=4.0,
    ),
    ModelInfo(
        name="claude-opus-4-1",
        provider="anthropic",
        monthly_cost_stub=180.0,
        recommended_alternative="claude-haiku-4-5",
        alternative_cost_stub=4.0,
    ),
    ModelInfo(
        name="claude-3-opus",
        provider="anthropic",
        monthly_cost_stub=150.0,
        recommended_alternative="claude-haiku-4-5",
        alternative_cost_stub=4.0,
    ),
    ModelInfo(
        name="claude-3-5-opus",
        provider="anthropic",
        monthly_cost_stub=160.0,
        recommended_alternative="claude-haiku-4-5",
        alternative_cost_stub=4.0,
    ),
    ModelInfo(
        name="gpt-4o",
        provider="openai",
        monthly_cost_stub=60.0,
        recommended_alternative="gpt-4o-mini",
        alternative_cost_stub=6.0,
    ),
    ModelInfo(
        name="gpt-4",
        provider="openai",
        monthly_cost_stub=80.0,
        recommended_alternative="gpt-4o-mini",
        alternative_cost_stub=6.0,
    ),
    ModelInfo(
        name="o1",
        provider="openai",
        monthly_cost_stub=120.0,
        recommended_alternative="gpt-4o-mini",
        alternative_cost_stub=6.0,
    ),
    ModelInfo(
        name="o1-preview",
        provider="openai",
        monthly_cost_stub=110.0,
        recommended_alternative="gpt-4o-mini",
        alternative_cost_stub=6.0,
    ),
    ModelInfo(
        name="o3",
        provider="openai",
        monthly_cost_stub=200.0,
        recommended_alternative="gpt-4o-mini",
        alternative_cost_stub=6.0,
    ),
]

EXPENSIVE_MODEL_NAMES: set[str] = {m.name for m in EXPENSIVE_MODELS}

PYTHON_PROVIDER_IMPORTS = {
    "anthropic",
    "openai",
    "google.generativeai",
    "groq",
    "mistralai",
}

TS_PROVIDER_IMPORTS = {
    "anthropic",
    "openai",
    "@google/generative-ai",
    "groq",
    "@mistralai/mistralai",
}

MISSING_MAX_TOKENS_COST_STUB = 20.0
MISSING_CACHE_COST_STUB = 85.0

LONG_SYSTEM_PROMPT_CHARS = 1000


def model_info(name: str) -> ModelInfo | None:
    for m in EXPENSIVE_MODELS:
        if m.name == name:
            return m
    return None
