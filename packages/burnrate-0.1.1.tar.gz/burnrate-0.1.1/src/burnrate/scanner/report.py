from dataclasses import dataclass, field
from enum import Enum

from rich.console import Console
from rich.rule import Rule
from rich.text import Text


class Severity(str, Enum):
    HIGH = "HIGH"
    QUICK_WIN = "QUICK_WIN"


@dataclass
class Finding:
    severity: Severity
    file: str
    line: int
    message: str
    detail: str = ""
    savings_stub: float = 0.0
    current_cost_stub: float = 0.0
    alternative: str = ""
    alternative_cost_stub: float = 0.0


@dataclass
class Report:
    scanned_files: int = 0
    findings: list[Finding] = field(default_factory=list)

    def high_impact(self) -> list[Finding]:
        return [f for f in self.findings if f.severity == Severity.HIGH]

    def quick_wins(self) -> list[Finding]:
        return [f for f in self.findings if f.severity == Severity.QUICK_WIN]

    def total_savings(self) -> float:
        return sum(f.savings_stub for f in self.findings)


def render_report(report: Report, con: Console | None = None) -> None:
    con = con or Console()

    con.print()
    con.print(Rule(style="dim"))
    con.print("  [bold]BURNRATE AUDIT REPORT[/bold]")
    con.print(Rule(style="dim"))
    con.print()

    high = report.high_impact()
    quick = report.quick_wins()

    if not high and not quick:
        con.print("[green]  No issues found.[/green]")
        con.print()
    else:
        if high:
            con.print("[bold red]HIGH IMPACT[/bold red]")
            for f in high:
                _render_finding(f, con)
            con.print()

        if quick:
            con.print("[bold yellow]QUICK WINS[/bold yellow] [dim](low effort, immediate impact)[/dim]")
            for f in quick:
                _render_quick_win(f, con)
            con.print()

    con.print(Rule(style="dim"))
    current = sum(f.current_cost_stub for f in report.findings)
    after_swaps = sum(f.alternative_cost_stub for f in report.findings)
    swap_savings = current - after_swaps
    other_savings = sum(
        f.savings_stub for f in report.findings if f.current_cost_stub == 0
    )
    total = swap_savings + other_savings
    if current > 0:
        con.print(f"  [dim]Current monthly AI spend:[/dim]  ~${current:.0f}/mo")
        con.print(f"  [dim]After model swaps:[/dim]         ~${after_swaps:.0f}/mo")
    if other_savings > 0:
        con.print(
            f"  [dim]Quick-win savings (caching, max_tokens):[/dim] ~${other_savings:.0f}/mo"
        )
    con.print(
        f"  [bold green]Total estimated savings: ${total:.0f}/mo[/bold green] [dim](estimated)[/dim]"
    )
    con.print(Rule(style="dim"))
    con.print()

    if high or quick:
        con.print("[dim]Run [bold]burnrate fix[/bold] to apply quick wins[/dim]")
        con.print("[dim]Run [bold]burnrate overhaul[/bold] for full stack migration[/dim]")
        con.print()


def _render_finding(f: Finding, con: Console) -> None:
    con.print(f"  [red]✗[/red] [bold]{f.file}:{f.line}[/bold]")
    con.print(f"    {f.message}")
    if f.detail:
        con.print(f"    [dim]{f.detail}[/dim]")
    if f.current_cost_stub and f.alternative:
        con.print(
            f"    Est. cost: ~${f.current_cost_stub:.0f}/mo"
            f" → {f.alternative}: ~${f.alternative_cost_stub:.0f}/mo"
        )
        con.print(f"    [green]Savings: ${f.savings_stub:.0f}/mo[/green]")
    con.print()


def _render_quick_win(f: Finding, con: Console) -> None:
    con.print(f"  [yellow]✗[/yellow] {f.message}")
