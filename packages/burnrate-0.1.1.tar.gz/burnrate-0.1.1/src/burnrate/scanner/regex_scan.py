import re
from pathlib import Path

from burnrate.scanner.patterns import (
    EXPENSIVE_MODEL_NAMES,
    LONG_SYSTEM_PROMPT_CHARS,
    MISSING_CACHE_COST_STUB,
    MISSING_MAX_TOKENS_COST_STUB,
    model_info,
)
from burnrate.scanner.report import Finding, Severity

_MODEL_RE = re.compile(
    r"""model\s*[:=]\s*['"]([^'"]+)['"]""",
    re.MULTILINE,
)

_MESSAGES_CREATE_RE = re.compile(
    r"""\.messages\.create\s*\(\s*\{([^}]*(?:\{[^}]*\}[^}]*)*)\}""",
    re.DOTALL,
)

_MAX_TOKENS_RE = re.compile(r"\bmax_tokens\b")
_CACHE_CONTROL_RE = re.compile(r"\bcache_control\b")

_SYSTEM_PROMPT_RE = re.compile(
    r"""system\s*:\s*(?:'([^']{1000,})'|"([^"]{1000,})")""",
    re.DOTALL,
)


def scan_ts_file(path: Path) -> list[Finding]:
    try:
        source = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return []

    findings: list[Finding] = []
    rel = str(path)
    lines = source.splitlines()

    findings.extend(_check_ts_models(source, lines, rel))
    findings.extend(_check_ts_missing_max_tokens(source, lines, rel))
    findings.extend(_check_ts_missing_cache(source, lines, rel))

    return findings


def _line_of(source: str, pos: int) -> int:
    return source[:pos].count("\n") + 1


def _check_ts_models(source: str, lines: list[str], rel: str) -> list[Finding]:
    findings = []
    for m in _MODEL_RE.finditer(source):
        name = m.group(1)
        if name in EXPENSIVE_MODEL_NAMES:
            info = model_info(name)
            savings = info.monthly_cost_stub - info.alternative_cost_stub if info else 0
            findings.append(Finding(
                severity=Severity.HIGH,
                file=rel,
                line=_line_of(source, m.start()),
                message=f"Expensive model: {name}",
                detail=f"Consider swapping to {info.recommended_alternative if info else 'a cheaper alternative'}",
                savings_stub=savings,
                current_cost_stub=info.monthly_cost_stub if info else 0,
                alternative=info.recommended_alternative if info else "",
                alternative_cost_stub=info.alternative_cost_stub if info else 0,
            ))
    return findings


def _check_ts_missing_max_tokens(source: str, lines: list[str], rel: str) -> list[Finding]:
    findings = []
    for m in _MESSAGES_CREATE_RE.finditer(source):
        body = m.group(1)
        if not _MAX_TOKENS_RE.search(body):
            findings.append(Finding(
                severity=Severity.QUICK_WIN,
                file=rel,
                line=_line_of(source, m.start()),
                message="messages.create() call missing max_tokens — unbounded response spend",
                savings_stub=MISSING_MAX_TOKENS_COST_STUB,
            ))
    return findings


def _check_ts_missing_cache(source: str, lines: list[str], rel: str) -> list[Finding]:
    findings = []
    for m in _SYSTEM_PROMPT_RE.finditer(source):
        system_text = m.group(1) or m.group(2)
        if system_text and len(system_text) >= LONG_SYSTEM_PROMPT_CHARS:
            if not _CACHE_CONTROL_RE.search(source[m.start():m.end() + 200]):
                findings.append(Finding(
                    severity=Severity.HIGH,
                    file=rel,
                    line=_line_of(source, m.start()),
                    message="Long system prompt (>1000 chars) without cache_control",
                    detail="Add cache_control: { type: 'ephemeral' } to avoid re-tokenizing",
                    savings_stub=MISSING_CACHE_COST_STUB,
                    current_cost_stub=94.0,
                    alternative="with caching",
                    alternative_cost_stub=9.0,
                ))
    return findings
