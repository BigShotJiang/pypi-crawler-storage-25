from __future__ import annotations

from burnrate.config import BurnrateConfig
from burnrate.overhaul.catalog import CATALOG, CatalogEntry, Variant
from burnrate.overhaul.models import OverhaulPlan, Recommendation


def _system_satisfies(req: str, config: BurnrateConfig) -> bool:
    sys = config.system
    if sys is None:
        return False
    if req.startswith("ram>="):
        threshold = int(req.split(">=", 1)[1])
        return (sys.ram_gb or 0) >= threshold
    if req == "darwin":
        return sys.os == "darwin"
    if req == "darwin-arm64":
        return sys.os == "darwin" and sys.arch == "arm64"
    if req == "linux":
        return sys.os == "linux"
    return True


def _variant_satisfies(variant: Variant, config: BurnrateConfig) -> bool:
    return all(_system_satisfies(r, config) for r in variant.requires)


def _all_viable_variants(entry: CatalogEntry, config: BurnrateConfig) -> list[Variant]:
    """All variants that satisfy the system profile, sorted by cost ascending (best savings first)."""
    viable = [v for v in entry.variants if _variant_satisfies(v, config)]
    if not viable:
        return [entry.variants[-1]]
    return sorted(viable, key=lambda v: v.with_cost)


def _pick_cheapest(entry: CatalogEntry, config: BurnrateConfig) -> Variant:
    """Cheapest viable variant — used for totals and the bash script."""
    return _all_viable_variants(entry, config)[0]


def recommend(config: BurnrateConfig) -> OverhaulPlan:
    subs = config.baseline.subscriptions if config.baseline else []
    recs: list[Recommendation] = []

    for sub_id in subs:
        entry = CATALOG.get(sub_id)
        if entry is None:
            recs.append(
                Recommendation(
                    replace=sub_id,
                    replace_cost=0,
                    with_tool="(no replacement in v0 catalog)",
                    with_cost=0,
                    reason="unknown — leaving as-is",
                )
            )
            continue
        cheapest = _pick_cheapest(entry, config)
        all_variants = _all_viable_variants(entry, config)
        recs.append(
            Recommendation(
                replace=entry.label,
                replace_cost=entry.cost,
                category=entry.category,
                with_tool=cheapest.with_tool,
                with_cost=cheapest.with_cost,
                reason=cheapest.reason,
                strategy=cheapest.strategy,
                alt=cheapest.alt,
                requires=list(cheapest.requires),
                all_variants=all_variants,
            )
        )

    current = sum(r.replace_cost for r in recs)
    new = sum(r.with_cost for r in recs)
    return OverhaulPlan(recommendations=recs, current_monthly=current, new_monthly=new)
