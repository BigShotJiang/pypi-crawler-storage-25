from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class CatalogEntry:
    label: str
    cost: float
    category: str  # 'ai-coding' | 'llm-chat' | 'search' | 'image' | 'video' | 'audio' | 'terminal'
    api_equivalent_cost: float
    variants: list["Variant"]


@dataclass
class Variant:
    with_tool: str
    with_cost: float
    reason: str
    strategy: str  # 'swap' | 'downgrade' | 'annual' | 'open-source' | 'api-direct' | 'consolidate' | 'educational' | 'aggregator'
    alt: str = ""
    requires: list[str] = None  # type: ignore[assignment]

    def __post_init__(self) -> None:
        if self.requires is None:
            self.requires = []


# fmt: off
CATALOG: dict[str, CatalogEntry] = {

    # ── AI CODING ──────────────────────────────────────────────────────────────

    "cursor-pro": CatalogEntry(
        label="Cursor Pro",
        cost=20,
        category="ai-coding",
        api_equivalent_cost=0,
        variants=[
            Variant(
                with_tool="Zed",
                with_cost=0,
                reason="Native Apple Silicon, built-in AI, faster than Cursor",
                alt="VS Code + Continue extension",
                requires=["darwin-arm64"],
                strategy="swap",
            ),
            Variant(
                with_tool="VS Code + Continue + Ollama",
                with_cost=0,
                reason="Open-source Copilot stack — free, runs locally",
                requires=["ram>=16"],
                strategy="open-source",
            ),
            Variant(
                with_tool="Cursor Pro (annual)",
                with_cost=16,
                reason="Same Cursor, billed yearly — saves ~$48/yr with no friction",
                strategy="annual",
            ),
            Variant(
                with_tool="Zed",
                with_cost=0,
                reason="Free AI editor, native AI integration",
                alt="VS Code + Continue extension",
                strategy="swap",
            ),
        ],
    ),

    "cursor-pro-plus": CatalogEntry(
        label="Cursor Pro+",
        cost=60,
        category="ai-coding",
        api_equivalent_cost=0,
        variants=[
            Variant(
                with_tool="Cursor Pro",
                with_cost=20,
                reason="Drop to Pro — same AI, 3x fewer credits, costs $40/mo less",
                strategy="downgrade",
            ),
            Variant(
                with_tool="Zed",
                with_cost=0,
                reason="Native Apple Silicon, built-in AI, faster than Cursor",
                alt="VS Code + Continue extension",
                requires=["darwin-arm64"],
                strategy="swap",
            ),
            Variant(
                with_tool="VS Code + Continue + Ollama",
                with_cost=0,
                reason="Open-source Copilot stack — free, runs locally",
                requires=["ram>=16"],
                strategy="open-source",
            ),
            Variant(
                with_tool="Zed",
                with_cost=0,
                reason="Free AI editor, native AI integration",
                strategy="swap",
            ),
        ],
    ),

    "cursor-ultra": CatalogEntry(
        label="Cursor Ultra",
        cost=200,
        category="ai-coding",
        api_equivalent_cost=0,
        variants=[
            Variant(
                with_tool="Cursor Pro+",
                with_cost=60,
                reason="Step down to Pro+ — same models, 7x fewer credits, saves $140",
                strategy="downgrade",
            ),
            Variant(
                with_tool="Anthropic API + Aider",
                with_cost=25,
                reason="Pay per token via API — same Claude, no rate limits at that pace",
                strategy="api-direct",
            ),
            Variant(
                with_tool="VS Code + Continue + Ollama",
                with_cost=0,
                reason="Open-source Copilot stack — free, runs locally on 16GB+ RAM",
                requires=["ram>=16"],
                strategy="open-source",
            ),
            Variant(
                with_tool="Zed",
                with_cost=0,
                reason="Native Apple Silicon, built-in AI, faster than Cursor",
                requires=["darwin-arm64"],
                strategy="swap",
            ),
            Variant(
                with_tool="Zed",
                with_cost=0,
                reason="Free AI editor, native AI integration",
                strategy="swap",
            ),
        ],
    ),

    "github-copilot-pro": CatalogEntry(
        label="GitHub Copilot Pro",
        cost=10,
        category="ai-coding",
        api_equivalent_cost=0,
        variants=[
            Variant(
                with_tool="Ollama + Qwen3:30b-a3b",
                with_cost=0,
                reason="Local autocomplete, zero latency, zero cost, runs on 16GB",
                alt="Continue extension",
                requires=["ram>=16"],
                strategy="open-source",
            ),
            Variant(
                with_tool="GitHub Copilot Pro (educational)",
                with_cost=0,
                reason="Free for verified students and teachers via GitHub Education",
                strategy="educational",
            ),
            Variant(
                with_tool="Cursor Pro",
                with_cost=20,
                reason="Cursor covers autocomplete + chat + agent — one bill replaces two",
                strategy="swap",
            ),
            Variant(
                with_tool="Ollama + Qwen3:7b",
                with_cost=0,
                reason="Smaller local model — fits in <16GB RAM, still free",
                alt="Continue extension",
                strategy="open-source",
            ),
        ],
    ),

    "github-copilot": CatalogEntry(
        label="GitHub Copilot",
        cost=19,
        category="ai-coding",
        api_equivalent_cost=0,
        variants=[
            Variant(
                with_tool="GitHub Copilot Pro",
                with_cost=10,
                reason="Newer individual plan — same core feature set, half the price",
                strategy="downgrade",
            ),
            Variant(
                with_tool="Ollama + Qwen3:30b-a3b",
                with_cost=0,
                reason="Local autocomplete, zero latency, zero cost",
                alt="Continue extension",
                requires=["ram>=16"],
                strategy="open-source",
            ),
            Variant(
                with_tool="Ollama + Qwen3:7b",
                with_cost=0,
                reason="Smaller local model — fits in <16GB RAM, still free",
                alt="Continue extension",
                strategy="open-source",
            ),
        ],
    ),

    "windsurf": CatalogEntry(
        label="Windsurf",
        cost=20,
        category="ai-coding",
        api_equivalent_cost=0,
        variants=[
            Variant(
                with_tool="Zed",
                with_cost=0,
                reason="Native AI editor, free — strong alternative post-Cognition deal",
                alt="Aider",
                strategy="swap",
            ),
            Variant(
                with_tool="VS Code + Continue + Ollama",
                with_cost=0,
                reason="Open-source Copilot stack — free, runs locally",
                requires=["ram>=16"],
                strategy="open-source",
            ),
            Variant(
                with_tool="Cursor Pro",
                with_cost=20,
                reason="Same monthly cost, more mature ecosystem and model selection",
                strategy="swap",
            ),
        ],
    ),

    "replit-core": CatalogEntry(
        label="Replit Core",
        cost=20,
        category="ai-coding",
        api_equivalent_cost=0,
        variants=[
            Variant(
                with_tool="Replit Core (annual)",
                with_cost=17,
                reason="Annual billing saves ~$36/yr — same plan, no migration needed",
                strategy="annual",
            ),
            Variant(
                with_tool="Cursor Pro + Vercel",
                with_cost=20,
                reason="Local dev + Vercel free tier replaces Replit for most projects",
                strategy="swap",
            ),
        ],
    ),

    "jetbrains-ai-pro": CatalogEntry(
        label="JetBrains AI Pro",
        cost=10,
        category="ai-coding",
        api_equivalent_cost=0,
        variants=[
            Variant(
                with_tool="JetBrains AI Pro (annual)",
                with_cost=8,
                reason="Annual billing saves ~$24/yr — same plan, no disruption",
                strategy="annual",
            ),
            Variant(
                with_tool="Continue + Ollama (JetBrains plugin)",
                with_cost=0,
                reason="Free Continue plugin for JetBrains IDEs + local Ollama model",
                requires=["ram>=16"],
                strategy="open-source",
            ),
            Variant(
                with_tool="GitHub Copilot Pro",
                with_cost=10,
                reason="Same cost, broader model access and better agent mode support",
                strategy="swap",
            ),
        ],
    ),

    # ── LLM CHAT ───────────────────────────────────────────────────────────────

    "claude-pro": CatalogEntry(
        label="Claude Pro",
        cost=20,
        category="llm-chat",
        api_equivalent_cost=8,
        variants=[
            Variant(
                with_tool="Anthropic API direct",
                with_cost=8,
                reason="Light chat usage costs ~$5-10/mo via API — no subscription tax",
                strategy="api-direct",
            ),
            Variant(
                with_tool="T3 Chat",
                with_cost=8,
                reason="Multi-model aggregator ($8/mo) includes Claude + GPT + Gemini",
                strategy="aggregator",
            ),
        ],
    ),

    "claude-max-5x": CatalogEntry(
        label="Claude Max 5x",
        cost=100,
        category="llm-chat",
        api_equivalent_cost=25,
        variants=[
            Variant(
                with_tool="Anthropic API + Aider",
                with_cost=25,
                reason="Same Claude, no rate limits, pay only for what you use",
                alt="Claude Code direct",
                strategy="api-direct",
            ),
            Variant(
                with_tool="Claude Pro",
                with_cost=20,
                reason="Downgrade to Pro — 5x fewer turns but costs $80/mo less",
                strategy="downgrade",
            ),
            Variant(
                with_tool="T3 Chat",
                with_cost=8,
                reason="Multi-model aggregator — Claude + GPT + Gemini for $8/mo",
                strategy="aggregator",
            ),
        ],
    ),

    "claude-max-20x": CatalogEntry(
        label="Claude Max 20x",
        cost=200,
        category="llm-chat",
        api_equivalent_cost=35,
        variants=[
            Variant(
                with_tool="Anthropic API + Aider",
                with_cost=25,
                reason="Same Claude, no rate limits, pay only for what you use",
                alt="Claude Code direct",
                strategy="api-direct",
            ),
            Variant(
                with_tool="Claude Max 5x",
                with_cost=100,
                reason="Step down to 5x tier — saves $100/mo with 4x fewer turns",
                strategy="downgrade",
            ),
            Variant(
                with_tool="ChatGPT Pro",
                with_cost=200,
                reason="If you also have ChatGPT Pro, cancel one — pick your preferred model",
                strategy="consolidate",
            ),
        ],
    ),

    "chatgpt-plus": CatalogEntry(
        label="ChatGPT Plus",
        cost=20,
        category="llm-chat",
        api_equivalent_cost=6,
        variants=[
            Variant(
                with_tool="OpenAI API direct",
                with_cost=6,
                reason="Light use costs ~$5-8/mo via API — no subscription overhead",
                strategy="api-direct",
            ),
            Variant(
                with_tool="Claude Pro",
                with_cost=20,
                reason="If you mainly use chat, Claude Pro covers the same workload",
                strategy="consolidate",
            ),
            Variant(
                with_tool="T3 Chat",
                with_cost=8,
                reason="Multi-model aggregator — GPT-4o + Claude + Gemini for $8/mo",
                strategy="aggregator",
            ),
        ],
    ),

    "chatgpt-pro": CatalogEntry(
        label="ChatGPT Pro",
        cost=200,
        category="llm-chat",
        api_equivalent_cost=40,
        variants=[
            Variant(
                with_tool="OpenAI API direct",
                with_cost=40,
                reason="Pay per token — heavy users still save $150+/mo at typical use",
                strategy="api-direct",
            ),
            Variant(
                with_tool="ChatGPT Plus",
                with_cost=20,
                reason="Downgrade to Plus — o3/o4 access at $20 covers most use cases",
                strategy="downgrade",
            ),
            Variant(
                with_tool="Claude Max 20x",
                with_cost=200,
                reason="If you also have Claude Max, cancel one — same monthly cost",
                strategy="consolidate",
            ),
        ],
    ),

    "gemini-ai-pro": CatalogEntry(
        label="Google AI Pro",
        cost=20,
        category="llm-chat",
        api_equivalent_cost=6,
        variants=[
            Variant(
                with_tool="Gemini API direct",
                with_cost=6,
                reason="Gemini 2.5 Pro via API — flash model is nearly free at low volume",
                strategy="api-direct",
            ),
            Variant(
                with_tool="T3 Chat",
                with_cost=8,
                reason="Multi-model aggregator includes Gemini + Claude + GPT for $8/mo",
                strategy="aggregator",
            ),
        ],
    ),

    "perplexity-pro": CatalogEntry(
        label="Perplexity Pro",
        cost=20,
        category="search",
        api_equivalent_cost=0,
        variants=[
            Variant(
                with_tool="Perplexity Pro (annual)",
                with_cost=17,
                reason="Annual billing saves ~$36/yr — same plan, no disruption",
                strategy="annual",
            ),
            Variant(
                with_tool="Perplexity Pro (educational)",
                with_cost=10,
                reason="Verified students get 50% off — $10/mo with .edu email",
                strategy="educational",
            ),
            Variant(
                with_tool="Kagi Search",
                with_cost=10,
                reason="Privacy-first search with AI summaries — covers most Perplexity needs",
                strategy="swap",
            ),
        ],
    ),

    "supergrok": CatalogEntry(
        label="SuperGrok",
        cost=30,
        category="llm-chat",
        api_equivalent_cost=10,
        variants=[
            Variant(
                with_tool="xAI API direct",
                with_cost=10,
                reason="Grok via API — pay per token, cheaper for intermittent use",
                strategy="api-direct",
            ),
            Variant(
                with_tool="T3 Chat",
                with_cost=8,
                reason="Multi-model aggregator includes Grok + Claude + GPT for $8/mo",
                strategy="aggregator",
            ),
        ],
    ),

    "mistral-pro": CatalogEntry(
        label="Mistral Le Chat Pro",
        cost=15,
        category="llm-chat",
        api_equivalent_cost=4,
        variants=[
            Variant(
                with_tool="Mistral API direct",
                with_cost=4,
                reason="Mistral Large via API — very low cost per token, no subscription",
                strategy="api-direct",
            ),
            Variant(
                with_tool="T3 Chat",
                with_cost=8,
                reason="Multi-model aggregator — covers Mistral use case for $8/mo",
                strategy="aggregator",
            ),
        ],
    ),

    "t3-chat": CatalogEntry(
        label="T3 Chat",
        cost=8,
        category="llm-chat",
        api_equivalent_cost=8,
        variants=[
            Variant(
                with_tool="OpenAI API direct",
                with_cost=6,
                reason="If you only use GPT-4o, direct API is cheaper at light usage",
                strategy="api-direct",
            ),
        ],
    ),

    # ── IMAGE ──────────────────────────────────────────────────────────────────

    "midjourney-basic": CatalogEntry(
        label="Midjourney Basic",
        cost=10,
        category="image",
        api_equivalent_cost=0,
        variants=[
            Variant(
                with_tool="Stable Diffusion (local)",
                with_cost=0,
                reason="Run locally on Apple Silicon — unlimited generations, no queue",
                requires=["darwin-arm64"],
                strategy="open-source",
            ),
            Variant(
                with_tool="Adobe Firefly",
                with_cost=0,
                reason="Included in Creative Cloud — check if you already subscribe",
                strategy="consolidate",
            ),
        ],
    ),

    "midjourney-standard": CatalogEntry(
        label="Midjourney Standard",
        cost=30,
        category="image",
        api_equivalent_cost=0,
        variants=[
            Variant(
                with_tool="Midjourney Basic",
                with_cost=10,
                reason="Downgrade to Basic — 3.3 fast GPU hours covers casual use",
                strategy="downgrade",
            ),
            Variant(
                with_tool="Stable Diffusion (local)",
                with_cost=0,
                reason="Run locally — unlimited generations, no monthly GPU queue",
                requires=["darwin-arm64"],
                strategy="open-source",
            ),
            Variant(
                with_tool="Adobe Firefly",
                with_cost=0,
                reason="Included in existing Creative Cloud subscription if you have one",
                strategy="consolidate",
            ),
        ],
    ),

    "midjourney-pro": CatalogEntry(
        label="Midjourney Pro",
        cost=60,
        category="image",
        api_equivalent_cost=0,
        variants=[
            Variant(
                with_tool="Midjourney Standard",
                with_cost=30,
                reason="Downgrade to Standard — saves $30/mo; relax mode still unlimited",
                strategy="downgrade",
            ),
            Variant(
                with_tool="Stable Diffusion (local)",
                with_cost=0,
                reason="Run locally on 16GB+ RAM — unlimited, stealth by default",
                requires=["ram>=16"],
                strategy="open-source",
            ),
        ],
    ),

    # ── VIDEO ──────────────────────────────────────────────────────────────────

    "runway-standard": CatalogEntry(
        label="Runway Standard",
        cost=12,
        category="video",
        api_equivalent_cost=12,
        variants=[
            Variant(
                with_tool="Runway (annual)",
                with_cost=10,
                reason="Annual billing saves ~$24/yr — same credits, no migration",
                strategy="annual",
            ),
            Variant(
                with_tool="Pika Pro",
                with_cost=8,
                reason="Pika covers basic video gen at $8/mo — evaluate feature overlap",
                strategy="swap",
            ),
        ],
    ),

    "runway-pro": CatalogEntry(
        label="Runway Pro",
        cost=28,
        category="video",
        api_equivalent_cost=28,
        variants=[
            Variant(
                with_tool="Runway Standard",
                with_cost=12,
                reason="Downgrade to Standard — saves $16/mo if you use <625 credits",
                strategy="downgrade",
            ),
            Variant(
                with_tool="Runway Pro (annual)",
                with_cost=24,
                reason="Annual billing saves ~$48/yr — same plan, no change in workflow",
                strategy="annual",
            ),
        ],
    ),

    # ── AUDIO ──────────────────────────────────────────────────────────────────

    "elevenlabs-starter": CatalogEntry(
        label="ElevenLabs Starter",
        cost=6,
        category="audio",
        api_equivalent_cost=6,
        variants=[
            Variant(
                with_tool="Kokoro TTS (local)",
                with_cost=0,
                reason="Open-source TTS model — runs locally, no API costs",
                requires=["ram>=8"],
                strategy="open-source",
            ),
            Variant(
                with_tool="ElevenLabs API",
                with_cost=5,
                reason="Pay per character via API — cheaper at low volume than Starter",
                strategy="api-direct",
            ),
        ],
    ),

    "elevenlabs-creator": CatalogEntry(
        label="ElevenLabs Creator",
        cost=11,
        category="audio",
        api_equivalent_cost=11,
        variants=[
            Variant(
                with_tool="ElevenLabs Starter",
                with_cost=6,
                reason="Downgrade to Starter — saves $5/mo if you use <30k chars/mo",
                strategy="downgrade",
            ),
            Variant(
                with_tool="Kokoro TTS (local)",
                with_cost=0,
                reason="Open-source TTS model — runs locally, no per-character billing",
                requires=["ram>=8"],
                strategy="open-source",
            ),
        ],
    ),

    "suno-pro": CatalogEntry(
        label="Suno Pro",
        cost=10,
        category="audio",
        api_equivalent_cost=0,
        variants=[
            Variant(
                with_tool="Suno Pro (annual)",
                with_cost=8,
                reason="Annual billing saves ~$24/yr — same 2,500 credits/mo",
                strategy="annual",
            ),
        ],
    ),

    # ── TERMINAL ───────────────────────────────────────────────────────────────

    "raycast-pro": CatalogEntry(
        label="Raycast Pro",
        cost=10,
        category="terminal",
        api_equivalent_cost=0,
        variants=[
            Variant(
                with_tool="Raycast Pro (annual)",
                with_cost=8,
                reason="Annual billing saves ~$24/yr — same AI features, no disruption",
                strategy="annual",
            ),
            Variant(
                with_tool="Alfred 5 (one-time)",
                with_cost=0,
                reason="Alfred Powerpack is a one-time $34 — no AI but zero monthly cost",
                strategy="swap",
            ),
        ],
    ),

    "notion-ai": CatalogEntry(
        label="Notion AI (Plus)",
        cost=10,
        category="terminal",
        api_equivalent_cost=0,
        variants=[
            Variant(
                with_tool="Notion Free + Claude API",
                with_cost=3,
                reason="Notion Free + occasional Claude API calls for drafting cost ~$3/mo",
                strategy="api-direct",
            ),
            Variant(
                with_tool="Obsidian + Copilot plugin",
                with_cost=0,
                reason="Local Markdown notes with free Copilot plugin — no subscription",
                strategy="swap",
            ),
        ],
    ),
}
# fmt: on
