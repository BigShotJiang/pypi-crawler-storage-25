import typer

from burnrate.commands import auth, audit, doctor, overhaul, status
from burnrate.commands import fix as fix_cmd
from burnrate.commands import mcp as mcp_cmd

app = typer.Typer(
    name="burnrate",
    help="Stop overpaying for AI. Audit, optimize, and overhaul your entire dev stack.",
    add_completion=False,
)

app.command(name="auth")(auth.auth)
app.command(name="audit")(audit.audit)
app.command(name="fix")(fix_cmd.fix)
app.command(name="doctor")(doctor.doctor)
app.command(name="overhaul")(overhaul.overhaul)
app.command(name="mcp")(mcp_cmd.mcp)
app.command(name="status")(status.status)
