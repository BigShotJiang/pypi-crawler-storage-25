# burnrate

Stop overpaying for AI. `burnrate` audits your codebase for wasteful AI API usage, suggests targeted fixes, and can execute a full stack migration off expensive subscriptions.

The core insight: most devs pay $100–400/month for Cursor, Claude Max, and Copilot. The same output costs $20–40 via direct API + open-source tooling. Burnrate finds the gap and closes it.

## Install

```bash
pipx install burnrate
```

Or with pip:

```bash
pip install --user burnrate
```

## Quick start

```bash
burnrate auth                  # one-time setup: keys + system profiling
burnrate audit .               # scan your codebase (read-only)
burnrate fix .                 # patch the easy wins, with diff approvals
burnrate overhaul              # replace expensive subscriptions with API + open-source
burnrate status                # current-month spend vs subscription baseline
burnrate doctor                # verify the setup is healthy
```

## Commands

### `burnrate auth`
First-time setup. Prompts for API keys (Anthropic, OpenAI, Google, Groq, Mistral), detects your system (OS, RAM, shell, editor), and asks which paid AI tools you're subscribed to. Writes everything to `~/.burnrate/config.json`. **Keys never leave your machine.**

### `burnrate audit [path]`
Read-only scan. Finds:
- Expensive model choices (e.g. `claude-opus-4` for a simple classifier)
- Missing `max_tokens` (unbounded response spend)
- Long system prompts (>1k chars) without `cache_control`
- Cross-language: Python (AST-based) and TypeScript/JavaScript (regex-based)

### `burnrate fix [path]`
Applies code-level fixes. Shows a unified diff per finding and prompts `y / n / skip / all` (per-fix-kind batching). Add `--dry-run` to preview without writing. Fix types: model swap, add `max_tokens`, wrap system prompts with `cache_control`.

### `burnrate overhaul`
Personalized stack-replacement plan. Reads your detected system + subscriptions; recommends replacements (Zed for Cursor, Anthropic API + Aider for Claude Max, Ollama + Qwen for Copilot). On approval, runs the installs (`brew`, `pipx`, `ollama pull`) with a single confirmation gate. Add `--dry-run` to see the plan without executing.

### `burnrate status`
This month's API spend per provider, with subscription-baseline comparison. Queries the Anthropic and OpenAI Admin APIs (`/v1/organizations/usage_report/messages` and `/v1/organization/costs`). Requires admin-tier API keys — regular keys show "requires admin API key" gracefully. Subscription savings are shown regardless.

### `burnrate doctor`
Verifies config, Python version, API key validity (via cheap `GET /v1/models` probes), and optional tools on PATH (Ollama, Aider, Zed). Exit 0 if all checks pass, 1 if any fail.

### `burnrate mcp`
Starts an MCP (Model Context Protocol) server on stdio. Exposes four tools to MCP-compatible editors (Claude Code, Cursor, Zed):
- `burnrate_check_file(path)` — scan a single file
- `burnrate_suggest_fix(code, finding_type)` — return patched code
- `burnrate_get_spend()` — current-month spend
- `burnrate_recommend_model(task_description)` — most cost-effective model for the task

Register in your editor's MCP config:
```json
{
  "mcpServers": {
    "burnrate": {
      "command": "burnrate",
      "args": ["mcp"]
    }
  }
}
```

## Safety

- `burnrate fix` shows every diff before writing. There's no `--yes` shortcut for v0 — confirm each kind or pipe `all` to batch.
- `burnrate overhaul` shows every install command before running. Single confirmation gate; no per-step prompts during execution. `--dry-run` is always safe.
- `burnrate audit` is fully read-only.
- API keys live at `~/.burnrate/config.json`. The CLI never transmits them to any third party.

If you want extra safety on `fix`, run it on a committed working tree so `git diff` is your undo.

## Web companion

If you'd rather use a hosted UI, get personalized setup scripts, or track spend over time, [burnrate.money](https://burnrate.money) has a paid tier ($12/mo or $49 lifetime) that complements the CLI.

## Development

```bash
git clone https://github.com/saintbate/burnrate
cd burnrate/cli
python3 -m venv .venv && source .venv/bin/activate
pip install -e ".[dev]"
pytest -q
```

## License

MIT.
