from __future__ import annotations

import subprocess
from unittest.mock import MagicMock, patch

import httpx

from burnrate.checks.api_keys import check_anthropic, check_openai
from burnrate.checks.base import CheckStatus
from burnrate.checks.config_check import check_config
from burnrate.checks.python_check import check_python
from burnrate.checks.tools import check_ollama


def test_config_check_present():
    r = check_config(config_present=True)
    assert r.status == CheckStatus.PASS


def test_config_check_missing():
    r = check_config(config_present=False)
    assert r.status == CheckStatus.FAIL
    assert "burnrate auth" in r.detail


def test_python_check_current_interpreter():
    r = check_python()
    assert r.status == CheckStatus.PASS
    assert r.detail.startswith("v")


def _mock_response(status_code: int):
    return MagicMock(status_code=status_code)


def test_anthropic_check_pass():
    with patch("burnrate.checks.api_keys.httpx.Client") as mock_cls:
        mock_cls.return_value.__enter__.return_value.get.return_value = _mock_response(200)
        r = check_anthropic("sk-ant-test")
    assert r.status == CheckStatus.PASS


def test_anthropic_check_invalid_key():
    with patch("burnrate.checks.api_keys.httpx.Client") as mock_cls:
        mock_cls.return_value.__enter__.return_value.get.return_value = _mock_response(401)
        r = check_anthropic("sk-ant-bad")
    assert r.status == CheckStatus.FAIL
    assert "invalid key" in r.detail


def test_anthropic_check_network_error():
    with patch("burnrate.checks.api_keys.httpx.Client") as mock_cls:
        mock_cls.return_value.__enter__.return_value.get.side_effect = httpx.HTTPError("no route")
        r = check_anthropic("sk-ant-test")
    assert r.status == CheckStatus.FAIL
    assert "network error" in r.detail


def test_openai_check_pass():
    with patch("burnrate.checks.api_keys.httpx.Client") as mock_cls:
        mock_cls.return_value.__enter__.return_value.get.return_value = _mock_response(200)
        r = check_openai("sk-test")
    assert r.status == CheckStatus.PASS


def test_openai_check_invalid_key():
    with patch("burnrate.checks.api_keys.httpx.Client") as mock_cls:
        mock_cls.return_value.__enter__.return_value.get.return_value = _mock_response(401)
        r = check_openai("sk-bad")
    assert r.status == CheckStatus.FAIL
    assert "invalid key" in r.detail


def test_tool_check_ollama_missing(monkeypatch):
    monkeypatch.setattr("burnrate.checks.tools.shutil.which", lambda _: None)
    r = check_ollama()
    assert r.status == CheckStatus.INFO
    assert "not installed" in r.detail


def test_tool_check_ollama_present_but_dead(monkeypatch):
    monkeypatch.setattr(
        "burnrate.checks.tools.shutil.which", lambda _: "/usr/local/bin/ollama"
    )

    def fake_run(*args, **kwargs):
        raise subprocess.TimeoutExpired(cmd=args[0], timeout=2.0)

    monkeypatch.setattr("burnrate.checks.tools.subprocess.run", fake_run)
    r = check_ollama()
    assert r.status == CheckStatus.INFO
    assert "not responding" in r.detail


def test_tool_check_ollama_present_and_responding(monkeypatch):
    monkeypatch.setattr(
        "burnrate.checks.tools.shutil.which", lambda _: "/usr/local/bin/ollama"
    )

    def fake_run(*args, **kwargs):
        return subprocess.CompletedProcess(
            args=args[0],
            returncode=0,
            stdout="NAME\tID\nllama3:latest\tabc\nqwen:latest\tdef\n",
            stderr="",
        )

    monkeypatch.setattr("burnrate.checks.tools.subprocess.run", fake_run)
    r = check_ollama()
    assert r.status == CheckStatus.PASS
    assert "2 model" in r.detail
