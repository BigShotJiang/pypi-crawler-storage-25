import anthropic

client = anthropic.Anthropic()

SYSTEM_PROMPT = "You are a helpful assistant."

response = client.messages.create(
    model="claude-haiku-4-5",
    system=SYSTEM_PROMPT,
    max_tokens=1024,
    messages=[{"role": "user", "content": "classify this intent"}],
)
