import anthropic

client = anthropic.Anthropic()

response = client.messages.create(
    model="claude-opus-4",
    system="You are a helpful classifier.",
    messages=[{"role": "user", "content": "classify this intent"}],
)

summary = client.messages.create(
    model="claude-opus-4",
    messages=[{"role": "user", "content": "summarize this"}],
)
