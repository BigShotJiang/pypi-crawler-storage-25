import Anthropic from "anthropic";

const client = new Anthropic();

const response = await client.messages.create({
  model: "claude-opus-4",
  messages: [{ role: "user", content: "classify this" }],
});
