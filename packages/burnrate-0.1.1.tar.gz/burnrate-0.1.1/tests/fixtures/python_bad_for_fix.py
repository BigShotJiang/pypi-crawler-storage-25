import anthropic

client = anthropic.Anthropic()

response = client.messages.create(
    model="claude-opus-4",
    messages=[{"role": "user", "content": "classify this intent"}],
)
