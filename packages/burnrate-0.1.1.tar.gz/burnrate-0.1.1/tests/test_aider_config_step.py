from __future__ import annotations

from unittest.mock import patch

from rich.console import Console

from burnrate.installers import StepStatus, execute_plan
from burnrate.installers.steps import (
    aider_config_step,
    steps_for_recommendation,
)
from burnrate.overhaul.models import Recommendation


def _rec(with_tool: str) -> Recommendation:
    return Recommendation(
        replace="Claude Max 5x",
        replace_cost=100,
        with_tool=with_tool,
        with_cost=25,
        reason="test",
    )


def test_steps_for_aider_includes_config_writer():
    steps = steps_for_recommendation(_rec("Anthropic API + Aider"))
    descriptions = [s.description for s in steps]
    assert any("Install Aider" in d for d in descriptions)
    assert any(".aider.conf.yml" in d for d in descriptions)


def test_aider_config_step_writes_file(tmp_path, monkeypatch):
    monkeypatch.setenv("HOME", str(tmp_path))
    step = aider_config_step()
    con = Console(record=True)
    results = execute_plan([step], con)
    assert results[0].status == StepStatus.SUCCESS
    written = tmp_path / ".aider.conf.yml"
    assert written.exists()
    content = written.read_text()
    assert "claude-sonnet-4-6" in content


def test_aider_config_step_skips_if_file_exists(tmp_path, monkeypatch):
    monkeypatch.setenv("HOME", str(tmp_path))
    existing = tmp_path / ".aider.conf.yml"
    existing.write_text("# user's own aider config\nmodel: gpt-4o\n")
    step = aider_config_step()
    con = Console(record=True)
    results = execute_plan([step], con)
    assert results[0].status == StepStatus.SKIPPED_ALREADY_DONE
    # User's content untouched
    assert "gpt-4o" in existing.read_text()


def test_dry_run_does_not_write_file(tmp_path, monkeypatch):
    monkeypatch.setenv("HOME", str(tmp_path))
    step = aider_config_step()
    con = Console(record=True)
    results = execute_plan([step], con, dry_run=True)
    assert results[0].status == StepStatus.SUCCESS
    assert results[0].detail == "dry-run"
    assert not (tmp_path / ".aider.conf.yml").exists()
