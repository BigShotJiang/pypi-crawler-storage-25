from __future__ import annotations

from burnrate.fixers.cache_control import CacheControlFixer
from burnrate.scanner.report import Finding, Severity


def _finding(file: str, line: int = 1) -> Finding:
    return Finding(
        severity=Severity.HIGH,
        file=file,
        line=line,
        message="Long system prompt (>1000 chars) without cache_control",
    )


def test_can_fix_cache_control_finding():
    fixer = CacheControlFixer()
    assert fixer.can_fix(_finding("x.py")) is True


def test_can_fix_returns_false_for_unrelated_finding():
    fixer = CacheControlFixer()
    other = Finding(severity=Severity.HIGH, file="x.py", line=1, message="Expensive model: claude-opus-4")
    assert fixer.can_fix(other) is False


def test_python_single_quoted_system_wrapped():
    source = (
        "client.messages.create(\n"
        '    model="claude-haiku-4-5",\n'
        '    system="You are a helpful assistant for a complex task.",\n'
        "    messages=[],\n"
        ")\n"
    )
    fixer = CacheControlFixer()
    out = fixer.apply(_finding("x.py", line=1), source)
    assert "cache_control" in out
    assert '"type": "ephemeral"' in out
    assert 'system=[' in out
    # Original content is preserved verbatim inside the array form.
    assert "You are a helpful assistant for a complex task." in out


def test_python_triple_quoted_system_wrapped():
    source = (
        "x = client.messages.create(\n"
        '    model="claude-haiku-4-5",\n'
        '    system="""You are a helpful assistant.\n'
        'With multiple lines of context.""",\n'
        "    messages=[],\n"
        ")\n"
    )
    out = CacheControlFixer().apply(_finding("x.py", line=1), source)
    assert "cache_control" in out
    assert "With multiple lines of context." in out
    # Triple quotes preserved
    assert '"""' in out


def test_typescript_double_quoted_system_wrapped():
    source = (
        "client.messages.create({\n"
        '  model: "claude-haiku-4-5",\n'
        '  system: "You are a helpful assistant.",\n'
        "  messages: [],\n"
        "})\n"
    )
    out = CacheControlFixer().apply(_finding("x.ts", line=1), source)
    assert "cache_control" in out
    assert "system: [" in out
    assert "You are a helpful assistant." in out


def test_typescript_template_literal_system_wrapped():
    source = (
        "client.messages.create({\n"
        '  model: "claude-haiku-4-5",\n'
        "  system: `You are a helpful assistant.`,\n"
        "  messages: [],\n"
        "})\n"
    )
    out = CacheControlFixer().apply(_finding("x.ts", line=1), source)
    assert "cache_control" in out
    assert "system: [" in out
    assert "`You are a helpful assistant.`" in out


def test_variable_reference_returns_unchanged():
    source = (
        "SYSTEM_PROMPT = build_prompt()\n"
        "client.messages.create(\n"
        '    model="claude-haiku-4-5",\n'
        "    system=SYSTEM_PROMPT,\n"
        "    messages=[],\n"
        ")\n"
    )
    out = CacheControlFixer().apply(_finding("x.py", line=2), source)
    assert out == source


def test_idempotent_no_double_wrap():
    source = (
        "client.messages.create(\n"
        '    model="claude-haiku-4-5",\n'
        '    system="You are helpful.",\n'
        "    messages=[],\n"
        ")\n"
    )
    fixer = CacheControlFixer()
    once = fixer.apply(_finding("x.py", line=1), source)
    # After the first apply, the regex shouldn't match `system="..."` anymore —
    # it now matches `system=[{...}]`. Re-applying should be a no-op.
    twice = fixer.apply(_finding("x.py", line=1), once)
    assert once == twice
    # Confirm no double-wrap signature
    assert once.count("cache_control") == 1
