from pathlib import Path

import pytest

from burnrate.scanner.python_ast import scan_python_file
from burnrate.scanner.report import Severity

FIXTURES = Path(__file__).parent / "fixtures"


def test_bad_file_has_findings():
    findings = scan_python_file(FIXTURES / "python_bad.py")
    assert len(findings) >= 3


def test_bad_file_has_expensive_model_finding():
    findings = scan_python_file(FIXTURES / "python_bad.py")
    high = [f for f in findings if f.severity == Severity.HIGH]
    assert any("claude-opus-4" in f.message for f in high)


def test_bad_file_has_missing_max_tokens():
    findings = scan_python_file(FIXTURES / "python_bad.py")
    quick = [f for f in findings if f.severity == Severity.QUICK_WIN]
    assert any("max_tokens" in f.message for f in quick)


def test_good_file_has_no_findings():
    findings = scan_python_file(FIXTURES / "python_good.py")
    assert findings == []


def test_syntax_error_file_returns_empty(tmp_path):
    bad = tmp_path / "broken.py"
    bad.write_text("def oops(:\n    pass\n")
    assert scan_python_file(bad) == []
