import json
from pathlib import Path
from unittest.mock import patch

from burnrate.config import BurnrateConfig, ProviderConfig, SystemConfig, load_config, save_config


def test_round_trip(tmp_path):
    fake_home = tmp_path / "home"
    fake_home.mkdir()

    with patch("burnrate.config.Path.home", return_value=fake_home):
        cfg = BurnrateConfig(
            providers={"anthropic": ProviderConfig(key="sk-ant-test")},
            system=SystemConfig(os="darwin", arch="arm64", ram_gb=16, shell="zsh", editor="Cursor"),
        )
        save_config(cfg)

        loaded = load_config()

    assert loaded.providers["anthropic"].key == "sk-ant-test"
    assert loaded.system.os == "darwin"
    assert loaded.system.arch == "arm64"
    assert loaded.system.ram_gb == 16
    assert loaded.system.shell == "zsh"
    assert loaded.system.editor == "Cursor"


def test_config_file_is_valid_json(tmp_path):
    fake_home = tmp_path / "home"
    fake_home.mkdir()

    with patch("burnrate.config.Path.home", return_value=fake_home):
        cfg = BurnrateConfig(providers={"openai": ProviderConfig(key="sk-test")})
        save_config(cfg)
        config_file = fake_home / ".burnrate" / "config.json"
        raw = json.loads(config_file.read_text())

    assert raw["providers"]["openai"]["key"] == "sk-test"


def test_load_missing_config_returns_empty(tmp_path):
    fake_home = tmp_path / "home"
    fake_home.mkdir()

    with patch("burnrate.config.Path.home", return_value=fake_home):
        cfg = load_config()

    assert cfg.providers == {}
    assert cfg.system is None
