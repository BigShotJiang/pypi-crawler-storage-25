from __future__ import annotations

import datetime
from unittest.mock import MagicMock, patch

import httpx
import pytest
from typer.testing import CliRunner

from burnrate.cli import app
from burnrate.spend.anthropic import _sum_anthropic_usage, query_anthropic_spend
from burnrate.spend.openai import _sum_openai_costs, query_openai_spend
from burnrate.spend.prices import estimate_cost

runner = CliRunner()


def _resp(status_code: int, json_data=None):
    r = MagicMock()
    r.status_code = status_code
    r.json.return_value = json_data
    return r


def test_estimate_cost_known_model():
    cost = estimate_cost("claude-haiku-4-5", 1_000_000, 1_000_000)
    assert cost == pytest.approx(1.0 + 5.0)


def test_estimate_cost_unknown_model_returns_none():
    assert estimate_cost("imaginary-model-99", 1_000_000, 1_000_000) is None


def test_sum_anthropic_usage_happy_path():
    data = {
        "data": [
            {
                "starting_at": "2026-05-01",
                "results": [
                    {
                        "model": "claude-haiku-4-5",
                        "input_tokens": 1_000_000,
                        "output_tokens": 500_000,
                    }
                ],
            }
        ]
    }
    total = _sum_anthropic_usage(data)
    # 1M @ $1/MTok input + 0.5M @ $5/MTok output = 1 + 2.5
    assert total == pytest.approx(3.5)


def test_sum_anthropic_usage_unknown_model_skipped():
    data = {
        "data": [
            {
                "results": [
                    {
                        "model": "imaginary-model",
                        "input_tokens": 1_000_000,
                        "output_tokens": 1_000_000,
                    }
                ]
            }
        ]
    }
    assert _sum_anthropic_usage(data) is None


def test_sum_anthropic_usage_empty_returns_none():
    assert _sum_anthropic_usage({"data": []}) is None
    assert _sum_anthropic_usage({"data": "not a list"}) is None
    assert _sum_anthropic_usage({}) is None


def test_anthropic_spend_pass():
    payload = {
        "data": [
            {
                "results": [
                    {
                        "model": "claude-haiku-4-5",
                        "input_tokens": 2_000_000,
                        "output_tokens": 1_000_000,
                    }
                ]
            }
        ]
    }
    with patch("burnrate.spend.anthropic.httpx.Client") as mc:
        mc.return_value.__enter__.return_value.get.return_value = _resp(200, payload)
        result = query_anthropic_spend("sk-ant-admin-xxx", today=datetime.date(2026, 5, 14))
    assert result.amount_usd == pytest.approx(2.0 + 5.0)
    assert "Admin API" in result.detail


def test_anthropic_spend_needs_admin_key():
    with patch("burnrate.spend.anthropic.httpx.Client") as mc:
        mc.return_value.__enter__.return_value.get.return_value = _resp(401, {})
        result = query_anthropic_spend("sk-ant-test")
    assert result.amount_usd is None
    assert "admin" in result.detail.lower()


def test_anthropic_spend_network_error():
    with patch("burnrate.spend.anthropic.httpx.Client") as mc:
        mc.return_value.__enter__.return_value.get.side_effect = httpx.HTTPError("no route")
        result = query_anthropic_spend("sk-ant-test")
    assert result.amount_usd is None
    assert "network error" in result.detail


def test_sum_openai_costs_happy_path():
    data = {
        "data": [
            {
                "results": [
                    {"amount": {"value": 1.23, "currency": "usd"}},
                    {"amount": {"value": 0.45, "currency": "usd"}},
                ]
            }
        ]
    }
    total = _sum_openai_costs(data)
    assert total == pytest.approx(1.68)


def test_sum_openai_costs_handles_scalar_amount():
    data = {"data": [{"results": [{"amount": 2.5}]}]}
    assert _sum_openai_costs(data) == pytest.approx(2.5)


def test_sum_openai_costs_returns_none_on_empty():
    assert _sum_openai_costs({"data": []}) is None
    assert _sum_openai_costs({}) is None


def test_openai_spend_needs_admin_key():
    with patch("burnrate.spend.openai.httpx.Client") as mc:
        mc.return_value.__enter__.return_value.get.return_value = _resp(401, {})
        result = query_openai_spend("sk-test")
    assert result.amount_usd is None
    assert "admin" in result.detail.lower()


def test_status_command_no_config(tmp_path, monkeypatch):
    monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)
    result = runner.invoke(app, ["status"])
    assert result.exit_code == 1
    assert "burnrate auth" in result.stdout


def test_status_command_shows_baseline_when_apis_unavailable(tmp_path, monkeypatch):
    monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)
    cfg_dir = tmp_path / ".burnrate"
    cfg_dir.mkdir()
    (cfg_dir / "config.json").write_text(
        '{"providers": {"anthropic": {"key": "sk-ant-test"}},'
        '"baseline": {"subscriptions": ["claude-max-5x"], "monthly_cost": 100}}'
    )
    with patch("burnrate.spend.orchestrator.query_anthropic_spend") as mock_q:
        from burnrate.spend.types import ProviderSpend

        mock_q.return_value = ProviderSpend("anthropic", None, "requires admin API key")
        result = runner.invoke(app, ["status"])
    assert result.exit_code == 0
    assert "SPEND THIS MONTH" in result.stdout
    assert "1200" in result.stdout  # baseline_monthly * 12 = $1200


def test_status_command_shows_live_spend(tmp_path, monkeypatch):
    monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)
    cfg_dir = tmp_path / ".burnrate"
    cfg_dir.mkdir()
    (cfg_dir / "config.json").write_text(
        '{"providers": {"anthropic": {"key": "sk-ant-test"}},'
        '"baseline": {"subscriptions": ["claude-max-5x"], "monthly_cost": 100}}'
    )
    with patch("burnrate.spend.orchestrator.query_anthropic_spend") as mock_q:
        from burnrate.spend.types import ProviderSpend

        mock_q.return_value = ProviderSpend("anthropic", 18.42, "via Admin API")
        result = runner.invoke(app, ["status"])
    assert result.exit_code == 0
    assert "$18.42" in result.stdout
    assert "tracked" in result.stdout.lower() or "Total API spend" in result.stdout
