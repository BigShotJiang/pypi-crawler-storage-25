import shutil
from pathlib import Path

import pytest
from typer.testing import CliRunner

from burnrate.cli import app

FIXTURES = Path(__file__).parent / "fixtures"
runner = CliRunner()


class TestFixCommandDryRun:
    def test_files_untouched(self, tmp_path):
        src = shutil.copy(FIXTURES / "python_bad_for_fix.py", tmp_path / "python_bad_for_fix.py")
        original = Path(src).read_text()

        result = runner.invoke(app, ["fix", "--dry-run", str(tmp_path)])

        assert result.exit_code == 0, result.output
        assert Path(src).read_text() == original

    def test_dry_run_shows_diff(self, tmp_path):
        shutil.copy(FIXTURES / "python_bad_for_fix.py", tmp_path / "python_bad_for_fix.py")

        result = runner.invoke(app, ["fix", "--dry-run", str(tmp_path)])

        assert result.exit_code == 0
        # The diff should contain the old and new model names
        assert "claude-opus-4" in result.output
        assert "claude-haiku-4-5" in result.output

    def test_dry_run_ts_files_untouched(self, tmp_path):
        src = shutil.copy(FIXTURES / "typescript_bad_for_fix.ts", tmp_path / "typescript_bad_for_fix.ts")
        original = Path(src).read_text()

        result = runner.invoke(app, ["fix", "--dry-run", str(tmp_path)])

        assert result.exit_code == 0, result.output
        assert Path(src).read_text() == original


class TestFixCommandApplyAll:
    def test_apply_all_patches_multiple_files(self, tmp_path):
        py_src = shutil.copy(FIXTURES / "python_bad_for_fix.py", tmp_path / "a.py")
        ts_src = shutil.copy(FIXTURES / "typescript_bad_for_fix.ts", tmp_path / "b.ts")

        # Feed "all" then "all" for each kind of fix that appears
        result = runner.invoke(app, ["fix", str(tmp_path)], input="all\nall\nall\nall\nall\n")

        assert result.exit_code == 0, result.output

        py_text = Path(py_src).read_text()
        ts_text = Path(ts_src).read_text()

        assert "claude-haiku-4-5" in py_text or "claude-haiku-4-5" in ts_text
        assert "claude-opus-4" not in py_text
        assert "claude-opus-4" not in ts_text

    def test_apply_all_inserts_max_tokens(self, tmp_path):
        py_src = shutil.copy(FIXTURES / "python_bad_for_fix.py", tmp_path / "a.py")

        result = runner.invoke(app, ["fix", str(tmp_path)], input="all\nall\nall\nall\n")

        assert result.exit_code == 0, result.output
        py_text = Path(py_src).read_text()
        assert "max_tokens=1024" in py_text

    def test_y_per_fix_applies_each(self, tmp_path):
        py_src = shutil.copy(FIXTURES / "python_bad_for_fix.py", tmp_path / "a.py")

        result = runner.invoke(app, ["fix", str(tmp_path)], input="y\ny\ny\ny\n")

        assert result.exit_code == 0, result.output
        py_text = Path(py_src).read_text()
        assert "claude-haiku-4-5" in py_text

    def test_skip_leaves_file_unchanged(self, tmp_path):
        py_src = shutil.copy(FIXTURES / "python_bad_for_fix.py", tmp_path / "a.py")
        original = Path(py_src).read_text()

        result = runner.invoke(app, ["fix", str(tmp_path)], input="n\nn\nn\nn\n")

        assert result.exit_code == 0, result.output
        assert Path(py_src).read_text() == original

    def test_nonexistent_path_exits_nonzero(self):
        result = runner.invoke(app, ["fix", "/nonexistent/path/does/not/exist"])
        assert result.exit_code != 0

    def test_no_issues_clean_directory(self, tmp_path):
        shutil.copy(FIXTURES / "python_good.py", tmp_path / "good.py")

        result = runner.invoke(app, ["fix", str(tmp_path)])

        assert result.exit_code == 0
        assert "nothing to fix" in result.output.lower() or "no issues" in result.output.lower()
