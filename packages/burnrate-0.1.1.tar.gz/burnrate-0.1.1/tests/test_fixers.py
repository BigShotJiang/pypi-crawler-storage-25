from pathlib import Path

import pytest

from burnrate.fixers.model_swap import ModelSwapFixer
from burnrate.fixers.add_max_tokens import AddMaxTokensFixer
from burnrate.fixers import apply_fix, get_fixer_for
from burnrate.scanner.python_ast import scan_python_file
from burnrate.scanner.regex_scan import scan_ts_file
from burnrate.scanner.report import Finding, Severity

FIXTURES = Path(__file__).parent / "fixtures"


def _make_model_finding(file: str, line: int, model: str, alt: str) -> Finding:
    return Finding(
        severity=Severity.HIGH,
        file=file,
        line=line,
        message=f"Expensive model: {model}",
        alternative=alt,
    )


def _make_max_tokens_finding(file: str, line: int) -> Finding:
    return Finding(
        severity=Severity.QUICK_WIN,
        file=file,
        line=line,
        message="messages.create() call missing max_tokens — unbounded response spend",
    )


class TestModelSwapPython:
    def test_swaps_model_string(self, tmp_path):
        src = 'response = client.messages.create(\n    model="claude-opus-4",\n    messages=[],\n)\n'
        f = tmp_path / "test.py"
        f.write_text(src)
        finding = _make_model_finding(str(f), 2, "claude-opus-4", "claude-haiku-4-5")
        fixer = ModelSwapFixer()
        result = fixer.apply(finding, src)
        assert "claude-haiku-4-5" in result
        assert "claude-opus-4" not in result

    def test_bytes_outside_literal_unchanged(self, tmp_path):
        src = 'x = 1\nresponse = client.messages.create(\n    model="claude-opus-4",\n    messages=[],\n)\ny = 2\n'
        f = tmp_path / "test.py"
        f.write_text(src)
        finding = _make_model_finding(str(f), 3, "claude-opus-4", "claude-haiku-4-5")
        fixer = ModelSwapFixer()
        result = fixer.apply(finding, src)
        assert result.startswith("x = 1\n")
        assert result.endswith("y = 2\n")
        assert "claude-haiku-4-5" in result

    def test_other_lines_unchanged(self, tmp_path):
        src = 'import anthropic\nclient = anthropic.Anthropic()\nresponse = client.messages.create(\n    model="claude-opus-4",\n    messages=[],\n)\n'
        f = tmp_path / "test.py"
        f.write_text(src)
        finding = _make_model_finding(str(f), 4, "claude-opus-4", "claude-haiku-4-5")
        fixer = ModelSwapFixer()
        result = fixer.apply(finding, src)
        assert "import anthropic" in result
        assert "claude-haiku-4-5" in result


class TestModelSwapTypeScript:
    def test_swaps_model_string_ts(self, tmp_path):
        src = 'const response = await client.messages.create({\n  model: "claude-opus-4",\n  messages: [],\n});\n'
        f = tmp_path / "test.ts"
        f.write_text(src)
        finding = _make_model_finding(str(f), 2, "claude-opus-4", "claude-haiku-4-5")
        fixer = ModelSwapFixer()
        result = fixer.apply(finding, src)
        assert "claude-haiku-4-5" in result
        assert "claude-opus-4" not in result

    def test_ts_bytes_outside_literal_unchanged(self, tmp_path):
        src = 'const x = 1;\nconst response = await client.messages.create({\n  model: "claude-opus-4",\n  messages: [],\n});\nconst y = 2;\n'
        f = tmp_path / "test.ts"
        f.write_text(src)
        finding = _make_model_finding(str(f), 3, "claude-opus-4", "claude-haiku-4-5")
        fixer = ModelSwapFixer()
        result = fixer.apply(finding, src)
        assert result.startswith("const x = 1;\n")
        assert result.endswith("const y = 2;\n")
        assert "claude-haiku-4-5" in result

    def test_gpt4o_swap(self, tmp_path):
        src = 'const r = await client.messages.create({\n  model: "gpt-4o",\n  messages: [],\n});\n'
        f = tmp_path / "test.ts"
        f.write_text(src)
        finding = _make_model_finding(str(f), 2, "gpt-4o", "gpt-4o-mini")
        fixer = ModelSwapFixer()
        result = fixer.apply(finding, src)
        assert "gpt-4o-mini" in result
        assert '"gpt-4o"' not in result


class TestAddMaxTokensPython:
    def test_inserts_max_tokens(self, tmp_path):
        src = 'response = client.messages.create(\n    model="claude-haiku-4-5",\n    messages=[{"role": "user", "content": "hi"}],\n)\n'
        f = tmp_path / "test.py"
        f.write_text(src)
        finding = _make_max_tokens_finding(str(f), 1)
        fixer = AddMaxTokensFixer()
        result = fixer.apply(finding, src)
        assert "max_tokens=1024" in result

    def test_does_not_break_indentation(self, tmp_path):
        src = 'response = client.messages.create(\n    model="claude-haiku-4-5",\n    messages=[],\n)\n'
        f = tmp_path / "test.py"
        f.write_text(src)
        finding = _make_max_tokens_finding(str(f), 1)
        fixer = AddMaxTokensFixer()
        result = fixer.apply(finding, src)
        lines = result.splitlines()
        max_tokens_line = next(l for l in lines if "max_tokens" in l)
        assert max_tokens_line.startswith("    "), "should be indented to match surrounding kwargs"

    def test_idempotent_python(self, tmp_path):
        src = 'response = client.messages.create(\n    model="claude-haiku-4-5",\n    messages=[],\n    max_tokens=1024,\n)\n'
        f = tmp_path / "test.py"
        f.write_text(src)
        finding = _make_max_tokens_finding(str(f), 1)
        fixer = AddMaxTokensFixer()
        result = fixer.apply(finding, src)
        assert result == src


class TestAddMaxTokensTypeScript:
    def test_inserts_max_tokens_ts(self, tmp_path):
        src = 'const r = await client.messages.create({\n  model: "claude-haiku-4-5",\n  messages: [{ role: "user", content: "hi" }],\n});\n'
        f = tmp_path / "test.ts"
        f.write_text(src)
        finding = _make_max_tokens_finding(str(f), 1)
        fixer = AddMaxTokensFixer()
        result = fixer.apply(finding, src)
        assert "max_tokens: 1024" in result

    def test_ts_idempotent(self, tmp_path):
        src = 'const r = await client.messages.create({\n  model: "claude-haiku-4-5",\n  messages: [],\n  max_tokens: 1024,\n});\n'
        f = tmp_path / "test.ts"
        f.write_text(src)
        finding = _make_max_tokens_finding(str(f), 1)
        fixer = AddMaxTokensFixer()
        result = fixer.apply(finding, src)
        assert result == src


class TestIdempotent:
    def test_python_no_findings_after_fix(self, tmp_path):
        src = (FIXTURES / "python_bad_for_fix.py").read_text()
        f = tmp_path / "python_bad_for_fix.py"
        f.write_text(src)

        findings = scan_python_file(f)
        fixable = [fi for fi in findings if get_fixer_for(fi) is not None]
        assert fixable, "need at least one fixable finding to test idempotency"

        for fi in fixable:
            apply_fix(fi, dry_run=False)

        after_findings = scan_python_file(f)
        after_fixable = [fi for fi in after_findings if get_fixer_for(fi) is not None]
        assert after_fixable == [], f"expected no fixable findings after fix, got: {after_fixable}"

    def test_ts_no_findings_after_fix(self, tmp_path):
        src = (FIXTURES / "typescript_bad_for_fix.ts").read_text()
        f = tmp_path / "typescript_bad_for_fix.ts"
        f.write_text(src)

        findings = scan_ts_file(f)
        fixable = [fi for fi in findings if get_fixer_for(fi) is not None]
        assert fixable, "need at least one fixable finding to test idempotency"

        for fi in fixable:
            apply_fix(fi, dry_run=False)

        after_findings = scan_ts_file(f)
        after_fixable = [fi for fi in after_findings if get_fixer_for(fi) is not None]
        assert after_fixable == [], f"expected no fixable findings after fix, got: {after_fixable}"
