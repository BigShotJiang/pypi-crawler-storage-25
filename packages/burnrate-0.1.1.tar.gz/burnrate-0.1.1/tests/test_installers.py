from __future__ import annotations

import subprocess
from unittest.mock import patch

from rich.console import Console
from typer.testing import CliRunner

from burnrate.cli import app
from burnrate.installers import StepStatus, execute_plan
from burnrate.installers.base import InstallStep
from burnrate.installers.steps import (
    aider_step,
    build_steps,
    ollama_install_step,
    ollama_pull_step,
    steps_for_recommendation,
    zed_step,
)
from burnrate.overhaul.models import Recommendation

runner = CliRunner()


def _rec(with_tool: str) -> Recommendation:
    return Recommendation(
        replace="X",
        replace_cost=10,
        with_tool=with_tool,
        with_cost=0,
        reason="test",
    )


def test_steps_for_zed():
    steps = steps_for_recommendation(_rec("Zed"))
    assert len(steps) == 1
    assert "Zed" in steps[0].description
    assert steps[0].commands[0][0] == "brew"


def test_steps_for_aider():
    steps = steps_for_recommendation(_rec("Anthropic API + Aider"))
    assert len(steps) == 2
    assert "Install Aider" in steps[0].description
    assert steps[0].commands[0][0] == "pipx"
    assert ".aider.conf.yml" in steps[1].description


def test_steps_for_ollama_with_model():
    steps = steps_for_recommendation(_rec("Ollama + Qwen3:30b-a3b"))
    assert len(steps) == 2
    assert "Ollama" in steps[0].description
    assert "Qwen3:30b-a3b" in steps[1].description
    assert steps[1].commands[0] == ["ollama", "pull", "Qwen3:30b-a3b"]


def test_steps_for_unknown_tool_returns_empty():
    steps = steps_for_recommendation(_rec("(no replacement in v0 catalog)"))
    assert steps == []


def test_build_steps_dedupes_shared_installs():
    recs = [
        _rec("Ollama + Qwen3:30b-a3b"),
        _rec("Ollama + Qwen3:7b"),
    ]
    plan = build_steps(recs)
    install_descriptions = [s.description for s in plan]
    assert install_descriptions.count("Install Ollama (local model runner)") == 1
    pull_descriptions = [d for d in install_descriptions if "Pull Ollama" in d]
    assert len(pull_descriptions) == 2


def test_execute_skips_already_done(monkeypatch):
    con = Console(record=True)
    step = InstallStep(
        description="test",
        commands=[["echo", "hi"]],
        already_done=lambda: True,
    )
    results = execute_plan([step], con)
    assert results[0].status == StepStatus.SKIPPED_ALREADY_DONE


def test_execute_skips_when_prereq_missing(monkeypatch):
    monkeypatch.setattr("burnrate.installers.prerequisites.has_brew", lambda: False)
    con = Console(record=True)
    step = InstallStep(
        description="test",
        commands=[["brew", "install", "x"]],
        already_done=lambda: False,
        requires=["brew"],
    )
    results = execute_plan([step], con)
    assert results[0].status == StepStatus.SKIPPED_PREREQ_MISSING
    assert "brew" in results[0].detail


def test_execute_runs_command_and_records_success(monkeypatch):
    captured = []

    def fake_run(cmd, **kwargs):
        captured.append(cmd)
        return subprocess.CompletedProcess(args=cmd, returncode=0, stdout="ok", stderr="")

    monkeypatch.setattr("burnrate.installers.executor.subprocess.run", fake_run)
    step = InstallStep(
        description="test",
        commands=[["true"]],
        already_done=lambda: False,
    )
    con = Console(record=True)
    results = execute_plan([step], con)
    assert results[0].status == StepStatus.SUCCESS
    assert captured == [["true"]]


def test_execute_records_failure_and_stops(monkeypatch):
    def fake_run(cmd, **kwargs):
        return subprocess.CompletedProcess(
            args=cmd, returncode=1, stdout="", stderr="boom: nope"
        )

    monkeypatch.setattr("burnrate.installers.executor.subprocess.run", fake_run)
    step1 = InstallStep(
        description="first", commands=[["false"]], already_done=lambda: False
    )
    step2 = InstallStep(
        description="second", commands=[["true"]], already_done=lambda: False
    )
    con = Console(record=True)
    results = execute_plan([step1, step2], con)
    assert len(results) == 1
    assert results[0].status == StepStatus.FAILED


def test_dry_run_does_not_invoke_subprocess(monkeypatch):
    monkeypatch.setattr(
        "burnrate.installers.executor.subprocess.run",
        lambda *a, **k: pytest.fail("subprocess.run should not be called in dry-run"),
    )
    import pytest

    step = InstallStep(
        description="test",
        commands=[["echo", "hi"]],
        already_done=lambda: False,
    )
    con = Console(record=True)
    results = execute_plan([step], con, dry_run=True)
    assert results[0].status == StepStatus.SUCCESS
    assert results[0].detail == "dry-run"


def _write_config(tmp_path):
    cfg_dir = tmp_path / ".burnrate"
    cfg_dir.mkdir()
    (cfg_dir / "config.json").write_text(
        '{"providers": {}, "system": {"os": "darwin", "arch": "arm64", "ram_gb": 16},'
        '"baseline": {"subscriptions": ["cursor-pro"]}}'
    )


def test_overhaul_command_cancelled_runs_nothing(tmp_path, monkeypatch):
    monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)
    _write_config(tmp_path)
    with patch("burnrate.commands.overhaul.execute_plan") as mock_exec:
        result = runner.invoke(app, ["overhaul"], input="n\n")
        mock_exec.assert_not_called()
    assert result.exit_code == 0
    assert "Cancelled" in result.stdout


def test_overhaul_command_dry_run_executes_in_preview_mode(tmp_path, monkeypatch):
    monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)
    _write_config(tmp_path)
    result = runner.invoke(app, ["overhaul", "--dry-run"], input="y\n")
    assert result.exit_code == 0
    assert "dry-run" in result.stdout.lower() or "Dry run complete" in result.stdout
