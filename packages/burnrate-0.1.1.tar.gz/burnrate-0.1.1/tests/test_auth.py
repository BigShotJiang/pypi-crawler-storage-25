from __future__ import annotations

from burnrate.commands.auth import _select_subscriptions
from burnrate.overhaul.catalog import CATALOG

# Total number of catalog entries — tests must stay in sync
CATALOG_SIZE = len(CATALOG)
CATALOG_SLUGS = list(CATALOG.keys())


def _set_confirm_answers(monkeypatch, answers: list[bool]) -> None:
    it = iter(answers)
    monkeypatch.setattr(
        "burnrate.commands.auth.Confirm.ask", lambda *a, **k: next(it)
    )


def test_select_subscriptions_none_selected(monkeypatch):
    _set_confirm_answers(monkeypatch, [False] * CATALOG_SIZE)
    subs, total = _select_subscriptions()
    assert subs == []
    assert total == 0


def test_select_subscriptions_cursor_pro_and_copilot(monkeypatch):
    # Build answers: True for cursor-pro, True for github-copilot, False for everything else
    answers = []
    for slug in CATALOG_SLUGS:
        answers.append(slug in ("cursor-pro", "github-copilot"))
    _set_confirm_answers(monkeypatch, answers)
    subs, total = _select_subscriptions()
    assert "cursor-pro" in subs
    assert "github-copilot" in subs
    assert total == CATALOG["cursor-pro"].cost + CATALOG["github-copilot"].cost


def test_select_subscriptions_all_selected(monkeypatch):
    _set_confirm_answers(monkeypatch, [True] * CATALOG_SIZE)
    subs, total = _select_subscriptions()
    assert len(subs) == CATALOG_SIZE
    assert total > 0
