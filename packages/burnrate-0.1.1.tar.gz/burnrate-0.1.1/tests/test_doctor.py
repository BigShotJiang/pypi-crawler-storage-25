from __future__ import annotations

from unittest.mock import patch

from typer.testing import CliRunner

from burnrate.checks.base import CheckResult, CheckStatus
from burnrate.cli import app

runner = CliRunner()


def _make_results(*statuses: CheckStatus) -> list[CheckResult]:
    return [
        CheckResult(name=f"check-{i}", status=s, detail="") for i, s in enumerate(statuses)
    ]


def test_doctor_command_exits_zero_on_all_pass():
    with patch("burnrate.commands.doctor.run_all_checks") as mock_run:
        mock_run.return_value = _make_results(
            CheckStatus.PASS, CheckStatus.PASS, CheckStatus.INFO
        )
        result = runner.invoke(app, ["doctor"])
    assert result.exit_code == 0
    assert "All checks passed" in result.stdout


def test_doctor_command_exits_nonzero_on_fail():
    with patch("burnrate.commands.doctor.run_all_checks") as mock_run:
        mock_run.return_value = _make_results(
            CheckStatus.PASS, CheckStatus.FAIL, CheckStatus.INFO
        )
        result = runner.invoke(app, ["doctor"])
    assert result.exit_code == 1
    assert "1 check(s) failed" in result.stdout


def test_doctor_command_shows_check_names():
    with patch("burnrate.commands.doctor.run_all_checks") as mock_run:
        mock_run.return_value = [
            CheckResult(name="my-test-check", status=CheckStatus.PASS, detail="ok"),
        ]
        result = runner.invoke(app, ["doctor"])
    assert "my-test-check" in result.stdout
    assert result.exit_code == 0


def test_doctor_command_runs_with_no_config(tmp_path, monkeypatch):
    monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)
    result = runner.invoke(app, ["doctor"])
    assert "burnrate auth" in result.stdout
    assert result.exit_code != 0
