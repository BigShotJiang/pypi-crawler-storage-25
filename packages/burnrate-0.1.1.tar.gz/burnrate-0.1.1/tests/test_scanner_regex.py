from pathlib import Path

import pytest

from burnrate.scanner.regex_scan import scan_ts_file
from burnrate.scanner.report import Severity

FIXTURES = Path(__file__).parent / "fixtures"


def test_ts_bad_file_has_findings():
    findings = scan_ts_file(FIXTURES / "typescript_bad.ts")
    assert len(findings) >= 1


def test_ts_bad_file_has_expensive_model():
    findings = scan_ts_file(FIXTURES / "typescript_bad.ts")
    high = [f for f in findings if f.severity == Severity.HIGH]
    assert len(high) >= 1
    assert any("claude-opus-4" in f.message or "gpt-4o" in f.message for f in high)


def test_ts_bad_file_missing_max_tokens():
    findings = scan_ts_file(FIXTURES / "typescript_bad.ts")
    quick = [f for f in findings if f.severity == Severity.QUICK_WIN]
    assert any("max_tokens" in f.message for f in quick)
