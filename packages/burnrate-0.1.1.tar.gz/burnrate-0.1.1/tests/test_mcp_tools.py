from __future__ import annotations

from pathlib import Path

import pytest

from burnrate.mcp_server import tools

FIXTURES = Path(__file__).parent / "fixtures"


def test_check_file_python_bad():
    result = tools.check_file(str(FIXTURES / "python_bad.py"))
    assert "findings" in result
    assert len(result["findings"]) > 0
    f = result["findings"][0]
    assert {"file", "line", "severity", "message"} <= set(f.keys())


def test_check_file_python_good():
    result = tools.check_file(str(FIXTURES / "python_good.py"))
    assert result["findings"] == []


def test_check_file_typescript_bad():
    result = tools.check_file(str(FIXTURES / "typescript_bad.ts"))
    assert len(result["findings"]) > 0


def test_check_file_unsupported_extension(tmp_path):
    p = tmp_path / "readme.txt"
    p.write_text("hello")
    result = tools.check_file(str(p))
    assert result["findings"] == []
    assert "unsupported" in result["note"]


def test_check_file_nonexistent():
    with pytest.raises(FileNotFoundError):
        tools.check_file("/no/such/file.py")


def test_suggest_fix_expensive_model_python():
    code = (
        "import anthropic\n"
        "client = anthropic.Anthropic()\n"
        "client.messages.create(\n"
        '    model="claude-opus-4",\n'
        '    messages=[],\n'
        "    max_tokens=100,\n"
        ")\n"
    )
    result = tools.suggest_fix(code, "expensive_model")
    assert "claude-haiku-4-5" in result["patched_code"]
    assert "claude-opus-4" not in result["patched_code"]
    assert result["savings_per_month_usd"] > 0


def test_suggest_fix_missing_max_tokens_python():
    code = (
        "import anthropic\n"
        "client = anthropic.Anthropic()\n"
        "client.messages.create(\n"
        '    model="claude-haiku-4-5",\n'
        '    messages=[],\n'
        ")\n"
    )
    result = tools.suggest_fix(code, "missing_max_tokens")
    assert "max_tokens" in result["patched_code"]


def test_suggest_fix_unknown_type_returns_unchanged():
    code = "print('hello')\n"
    result = tools.suggest_fix(code, "foo_bar")
    assert result["patched_code"] == code
    assert "no auto-fixer" in result["explanation"]


def test_suggest_fix_no_matching_findings():
    code = "print('hello')\n"
    result = tools.suggest_fix(code, "expensive_model")
    assert result["patched_code"] == code
    assert "no matching findings" in result["explanation"]


def test_get_spend_returns_stub_shape():
    result = tools.get_spend()
    assert result["currency"] == "usd"
    assert len(result["month"]) == 7  # YYYY-MM
    assert "providers" in result
    assert "burnrate status" in result["note"]


def test_recommend_model_classification():
    r = tools.recommend_model("Build a simple intent classifier")
    assert "haiku" in r["model"]
    assert r["cost_class"] == "cheap"


def test_recommend_model_embedding():
    r = tools.recommend_model("Embed user queries for semantic search")
    assert r["cost_class"] == "free"
    assert "local" in r["model"]


def test_recommend_model_autocomplete():
    r = tools.recommend_model("Autocomplete the next line of code")
    assert r["cost_class"] == "free"


def test_recommend_model_complex_reasoning():
    r = tools.recommend_model("Multi-step agent that plans a refactor")
    assert "sonnet" in r["model"]
    assert r["cost_class"] == "medium"


def test_recommend_model_default():
    r = tools.recommend_model("Do something totally unspecified")
    assert "haiku" in r["model"]


def test_build_server_registers_four_tools():
    from burnrate.mcp_server import build_server

    server = build_server()
    # FastMCP exposes its tool manager; we just confirm the four tools exist.
    import asyncio

    listed = asyncio.run(server.list_tools())
    names = {t.name for t in listed}
    assert names == {
        "burnrate_check_file",
        "burnrate_suggest_fix",
        "burnrate_get_spend",
        "burnrate_recommend_model",
    }
