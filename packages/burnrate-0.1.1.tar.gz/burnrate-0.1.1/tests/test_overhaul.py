from __future__ import annotations

from typer.testing import CliRunner

from burnrate.cli import app
from burnrate.config import BaselineConfig, BurnrateConfig, SystemConfig
from burnrate.overhaul import recommend

runner = CliRunner()


def _config(
    *,
    subscriptions: list[str],
    ram_gb: int = 16,
    arch: str = "arm64",
    os_name: str = "darwin",
    editor: str = "cursor",
) -> BurnrateConfig:
    return BurnrateConfig(
        system=SystemConfig(os=os_name, arch=arch, ram_gb=ram_gb, editor=editor),
        baseline=BaselineConfig(subscriptions=subscriptions),
    )


def test_recommend_cursor_pro_swaps_to_zed():
    plan = recommend(_config(subscriptions=["cursor-pro"]))
    assert len(plan.recommendations) == 1
    r = plan.recommendations[0]
    assert r.replace == "Cursor Pro"
    # On darwin-arm64 with 16GB RAM, cheapest is free Zed or free VS Code+Continue
    assert r.with_cost == 0
    assert r.with_tool in ("Zed", "VS Code + Continue + Ollama")


def test_recommend_cursor_pro_has_multiple_variants():
    plan = recommend(_config(subscriptions=["cursor-pro"]))
    r = plan.recommendations[0]
    assert len(r.all_variants) >= 2, "cursor-pro should have multiple variants"


def test_recommend_cursor_pro_has_category():
    plan = recommend(_config(subscriptions=["cursor-pro"]))
    r = plan.recommendations[0]
    assert r.category == "ai-coding"


def test_recommend_catalog_entries_have_new_fields():
    """Verify category and api_equivalent_cost are present on entries."""
    from burnrate.overhaul.catalog import CATALOG
    for slug, entry in CATALOG.items():
        assert hasattr(entry, "category"), f"{slug} missing category"
        assert hasattr(entry, "api_equivalent_cost"), f"{slug} missing api_equivalent_cost"
        assert entry.category in {
            "ai-coding", "llm-chat", "search", "image", "video", "audio", "terminal"
        }, f"{slug} has unexpected category {entry.category!r}"
        for v in entry.variants:
            assert hasattr(v, "strategy"), f"{slug} variant missing strategy"


def test_recommend_copilot_swaps_to_qwen30b_on_16gb():
    plan = recommend(_config(subscriptions=["github-copilot"], ram_gb=16))
    r = plan.recommendations[0]
    # cheapest viable on 16GB darwin-arm64 — Ollama local or educational free
    assert r.with_cost == 0


def test_recommend_copilot_falls_back_to_smaller_model_on_low_ram():
    plan = recommend(_config(subscriptions=["github-copilot"], ram_gb=8))
    r = plan.recommendations[0]
    # on low RAM, downgrade to Copilot Pro ($10) or Qwen3:7b (free)
    assert r.with_cost <= 10


def test_recommend_claude_max_swaps_to_api():
    plan = recommend(_config(subscriptions=["claude-max-5x"]))
    r = plan.recommendations[0]
    # Cheapest viable: api-direct at $25 or aggregator at $8
    assert r.with_cost <= 25


def test_recommend_claude_max_has_api_direct_variant():
    plan = recommend(_config(subscriptions=["claude-max-5x"]))
    r = plan.recommendations[0]
    strategies = [v.strategy for v in r.all_variants]
    assert "api-direct" in strategies


def test_recommend_unknown_subscription_passthrough():
    plan = recommend(_config(subscriptions=["random-tool-99"]))
    r = plan.recommendations[0]
    assert r.with_tool == "(no replacement in v0 catalog)"
    assert r.replace_cost == r.with_cost == 0


def test_plan_totals():
    plan = recommend(
        _config(subscriptions=["cursor-pro", "claude-max-5x", "github-copilot"])
    )
    # cursor-pro: $20 → $0 (free Zed/OSS)
    # claude-max-5x: $100 → cheapest viable (api-direct $25 or aggregator $8)
    # github-copilot: $19 → $0 (free OSS or downgrade to copilot-pro=$10 but local is $0)
    assert plan.current_monthly == 139
    # new_monthly uses cheapest viable per entry
    assert plan.new_monthly <= 25
    assert plan.annual_savings == (plan.current_monthly - plan.new_monthly) * 12


def test_overhaul_command_no_config(tmp_path, monkeypatch):
    monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)
    result = runner.invoke(app, ["overhaul"])
    assert result.exit_code == 1
    assert "burnrate auth" in result.stdout


def test_overhaul_command_no_subscriptions(tmp_path, monkeypatch):
    monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)
    cfg_dir = tmp_path / ".burnrate"
    cfg_dir.mkdir()
    (cfg_dir / "config.json").write_text(
        '{"providers": {}, "system": {"os": "darwin", "arch": "arm64", "ram_gb": 16}}'
    )
    result = runner.invoke(app, ["overhaul"])
    assert result.exit_code == 1
    assert "No subscriptions recorded" in result.stdout


def test_overhaul_command_prints_savings(tmp_path, monkeypatch):
    monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)
    cfg_dir = tmp_path / ".burnrate"
    cfg_dir.mkdir()
    (cfg_dir / "config.json").write_text(
        '{"providers": {}, "system": {"os": "darwin", "arch": "arm64", "ram_gb": 16},'
        '"baseline": {"subscriptions": ["cursor-pro", "claude-max-5x", "github-copilot"], "monthly_cost": 139}}'
    )
    result = runner.invoke(app, ["overhaul"], input="n\n")
    assert result.exit_code == 0
    assert "Annual savings" in result.stdout
    assert "Cursor Pro" in result.stdout


def test_overhaul_command_shows_multiple_strategies(tmp_path, monkeypatch):
    monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)
    cfg_dir = tmp_path / ".burnrate"
    cfg_dir.mkdir()
    (cfg_dir / "config.json").write_text(
        '{"providers": {}, "system": {"os": "darwin", "arch": "arm64", "ram_gb": 16},'
        '"baseline": {"subscriptions": ["cursor-pro", "claude-max-5x", "github-copilot",'
        '"chatgpt-plus", "midjourney-standard"]}}'
    )
    result = runner.invoke(app, ["overhaul"], input="n\n")
    assert result.exit_code == 0
    # Strategy badges should appear in output
    assert any(badge in result.stdout for badge in ["SWAP", "API-DIRECT", "OPEN-SOURCE", "DOWNGRADE"])


def test_overhaul_command_invokes_executor_on_yes(tmp_path, monkeypatch):
    from unittest.mock import patch

    monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)
    cfg_dir = tmp_path / ".burnrate"
    cfg_dir.mkdir()
    (cfg_dir / "config.json").write_text(
        '{"providers": {}, "system": {"os": "darwin", "arch": "arm64", "ram_gb": 16},'
        '"baseline": {"subscriptions": ["cursor-pro"]}}'
    )
    with patch("burnrate.commands.overhaul.execute_plan", return_value=[]) as mock_exec:
        result = runner.invoke(app, ["overhaul"], input="y\n")
    assert mock_exec.called
    assert result.exit_code == 0
