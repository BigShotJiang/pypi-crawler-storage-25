# CHANGELOG

All notable changes to this project will be documented in this file.
This project adheres to [Semantic Versioning](http://semver.org/) and [Keep a Changelog](http://keepachangelog.com/).



## Unreleased
---

### New

### Changes

### Fixes

### Breaks


## 2.3.5 - (2026-05-11)
---

## 2.3.4 - (2026-05-10)
---

## 2.3.3 - (2026-05-10)
---

## 2.3.2 - (2026-05-07)
---

## 2.3.1 - (2026-05-06)
---

## 2.3.0 - (2026-05-06)
---

### New
* Added support for case insensitive memory units `Gi`, `GiB`, `Mi`, `MiB` instead of defaulting to `Mi`

### Fixes
* Passing `--memory 0`, `0Gi`, `0Mi`, `0Gib`, `0Mib` now correctly falls back to the default `4Gi` / `2 CPU` in the build flow, instead of being silently passed to the server as an unset value
* Memory unit parsing now supports all valid units (`Gi`, `GiB`, `Mi`, `MiB`) consistently across all commands, instead of only `Gi`/`Mib`
* Invalid memory units (e.g. `4GB`, `4MB`) now raise a `ValueError` instead of silently defaulting to `Mi`


## 2.2.24 - (2026-05-05)
---

## 2.2.23 - (2026-05-05)
---

## 2.2.22 - (2026-05-05)
---

## 2.2.21 - (2026-05-04)
---

## 2.2.20 - (2026-05-04)
---

## 2.2.19 - (2026-05-03)
---

## 2.2.18 - (2026-04-29)
---

## 2.2.17 - (2026-04-29)
---

## 2.2.16 - (2026-04-23)
---

## 2.2.15 - (2026-04-23)
---

## 2.2.14 - (2026-04-20)
---

## 2.2.13 - (2026-04-19)
---

## 2.2.12 - (2026-04-19)
---

## 2.2.11 - (2026-04-16)
---

## 2.2.10 - (2026-04-14)
---

## 2.2.9 - (2026-04-14)
---

## 2.2.8 - (2026-04-14)
---

## 2.2.7 - (2026-04-14)
---

## 2.2.6 - (2026-04-13)
---

## 2.2.5 - (2026-04-13)
---

## 2.2.4 - (2026-03-30)
---

## 2.2.3 - (2026-03-30)
---

## 2.2.2 - (2026-03-30)
---

## 2.2.1 - (2026-03-29)
---

## 2.2.0 - (2026-03-25)
---

### New

* Added cron expression validation for Batch Featureset scheduling policy


## 2.1.21 - (2026-03-22)
---

## 2.1.20 - (2026-03-22)
---

## 0.1.245 - (2026-03-22)
---

## 0.1.244 - (2026-03-12)
---

## 0.1.243 - (2026-03-08)
---

## 0.1.242 - (2026-03-08)
---

## 0.1.241 - (2026-02-26)
---

## 0.1.240 - (2026-02-24)
---

### New

* Added online-time-to-live field to Batch Feature Set decorator


## 0.1.239 - (2026-02-24)
---

## 0.1.238 - (2026-02-24)
---

## 0.1.237 - (2026-02-23)
---

## 0.1.236 - (2026-02-23)
---

### Fixes
* log_model with register_in_jml=False no longer instantiates JML gRPC clients (EcosystemClient, ModelVersionManagerClient), avoiding connection attempts to grpc.qwak.ai in air-gapped environments


## 0.1.235 - (2026-02-22)
---

## 0.1.234 - (2026-02-22)
---

## 0.1.233 - (2026-02-19)
---

## 0.1.232 - (2026-02-18)
---

## 0.1.231 - (2026-02-18)
---

## 0.1.230 - (2026-02-17)
---

## 0.1.229 - (2026-02-17)
---

### New
* introduce keepalive option for grpc channels


## 0.1.228 - (2026-02-16)
---

## 0.1.227 - (2026-02-15)
---

## 0.1.226 - (2026-02-15)
---

## 0.1.225 - (2026-02-15)
---

## 0.1.224 - (2026-02-12)
---

## 0.1.223 - (2026-02-12)
---

## 0.1.222 - (2026-02-11)
---

## 0.1.221 - (2026-02-11)
---

## 0.1.220 - (2026-02-11)
---

## 0.1.219 - (2026-02-10)
---

## 0.1.218 - (2026-02-09)
---

## 0.1.217 - (2026-02-09)
---

## 0.1.216 - (2026-02-05)
---

## 0.1.215 - (2026-02-05)
---

## 0.1.214 - (2026-02-04)
---

## 0.1.213 - (2026-02-04)
---

## 0.1.212 - (2026-02-03)
---

## 0.1.211 - (2026-02-02)
---

## 0.1.210 - (2026-02-02)
---

## 0.1.209 - (2026-02-02)
---

## 0.1.208 - (2026-02-02)
---

## 0.1.207 - (2026-02-01)
---

## 0.1.206 - (2026-01-29)
---

## 0.1.205 - (2026-01-29)
---

### New
* Added `ClusterV2Client` for Cluster V2 API interactions
* Added `EnvironmentV1Client` for Environment V1 API interactions
* Added `update_environment_configuration` method to `EnvironmentClient` for updating environment configurations


## 0.1.204 - (2026-01-28)
---

## 0.1.203 - (2026-01-28)
---

## 0.1.202 - (2026-01-27)
---

## 0.1.201 - (2026-01-26)
---

## 0.1.200 - (2026-01-25)
---

## 0.1.199 - (2026-01-25)
---

## 0.1.198 - (2026-01-22)
---

## 0.1.197 - (2026-01-21)
---

## 0.1.196 - (2026-01-20)
---

## 0.1.195 - (2026-01-15)
---

## 0.1.194 - (2026-01-14)
---

## 0.1.193 - (2026-01-14)
---

## 0.1.192 - (2026-01-14)
---

## 0.1.191 - (2026-01-13)
---

## 0.1.190 - (2026-01-12)
---

## 0.1.189 - (2026-01-12)
---

## 0.1.188 - (2026-01-12)
---

## 0.1.187 - (2026-01-11)
---

## 0.1.186 - (2026-01-11)
---

## 0.1.185 - (2026-01-08)
---

## 0.1.184 - (2026-01-07)
---

### New
* streaming aggregation featureset can trigger backfill ad-hoc
* @streaming.backfill() decorator for defining backfill specifications for streaming aggregation feature sets
* BackfillDataSource class for specifying batch data sources with optional time ranges for backfill
* StreamingAggregationBackfill executor class with .trigger() method for submitting backfill jobs to execution manager

### Changes
* @streaming.backfill() decorator now creates a standalone StreamingBackfill specification instead of being attached to feature set definition
* @streaming.backfill() decorator now returns a StreamingBackfill object instead of decorating the feature set function
* @streaming.feature_set() now accepts backfill_max_timestamp parameter (datetime) instead of backfill specification object
* Backfill transformation is now defined as the decorated function's return value instead of via backfill_transformation parameter
* Renamed: BackfillBatchDataSourceSpec → BackfillDataSource

### Breaks
* streaming aggregation definition does no longer contain backfill definition
* @streaming.backfill() now requires feature_set_name parameter
* backfill_transformation parameter removed from @streaming.backfill() decorator
* backfill_max_timestamp is now mandatory for streaming aggregation feature sets
* backfill parameter removed from StreamingFeatureSet - replaced with backfill_max_timestamp (datetime)
* @streaming.backfill() decorator can no longer be stacked on @streaming.feature_set() - will raise FrogmlException


## 0.1.183 - (2026-01-06)
---

## 0.1.182 - (2026-01-05)
---

## 0.1.181 - (2026-01-04)
---

## 0.1.180 - (2025-12-31)
---

## 0.1.179 - (2025-12-30)
---

## 0.1.178 - (2025-12-30)
---

## 0.1.177 - (2025-12-29)
---

## 0.1.176 - (2025-12-29)
---

## 0.1.175 - (2025-12-24)
---

## 0.1.174 - (2025-12-24)
---

## 0.1.173 - (2025-12-23)
---

## 0.1.172 - (2025-12-22)
---

## 0.1.171 - (2025-12-16)
---

## 0.1.170 - (2025-12-16)
---

## 0.1.169 - (2025-12-15)
---

## 0.1.168 - (2025-12-10)
---

## 0.1.167 - (2025-12-10)
---

## 0.1.166 - (2025-12-09)
---

## 0.1.165 - (2025-12-08)
---

## 0.1.164 - (2025-12-08)
---

## 0.1.163 - (2025-12-07)
---

### New
* Supporting array-like strings for properties, parameters and metrics params in log_model funcs

### Changes
* Raising error when entity version upload fails on validation


## 0.1.162 - (2025-12-07)
---

## 0.1.161 - (2025-12-07)
---

### New
* Added support for Python 3.12 and 3.13


## 0.1.160 - (2025-12-03)
---

## 0.1.159 - (2025-12-01)
---

## 0.1.158 - (2025-12-01)
---

## 0.1.157 - (2025-11-30)
---

## 0.1.156 - (2025-11-27)
---

## 0.1.155 - (2025-11-27)
---

## 0.1.154 - (2025-11-25)
---

## 0.1.153 - (2025-11-25)
---

## 0.1.152 - (2025-11-24)
---

## 0.1.151 - (2025-11-24)
---

## 0.1.150 - (2025-11-19)
---

## 0.1.149 - (2025-11-19)
---

## 0.1.148 - (2025-11-19)
---

### Fixes
* Fix error message in authentication utility to reference correct configuration command


## 0.1.147 - (2025-11-17)
---

## 0.1.146 - (2025-11-16)
---

### Changes
* Refining imports for builds


## 0.1.145 - (2025-11-16)
---

## 0.1.144 - (2025-11-16)
---

## 0.1.143 - (2025-11-16)
---

## 0.1.142 - (2025-11-16)
---

## 0.1.141 - (2025-11-11)
---

## 0.1.140 - (2025-11-10)
---

## 0.1.139 - (2025-11-10)
---

## 0.1.138 - (2025-11-04)
---

## 0.1.137 - (2025-11-03)
---

## 0.1.136 - (2025-11-03)
---

## 0.1.135 - (2025-11-03)
---

## 0.1.134 - (2025-11-02)
---

## 0.1.133 - (2025-10-29)
---

## 0.1.132 - (2025-10-29)
---

## 0.1.131 - (2025-10-28)
---

## 0.1.130 - (2025-10-28)
---

## 0.1.129 - (2025-10-28)
---

## 0.1.128 - (2025-10-28)
---

## 0.1.127 - (2025-10-28)
---

## 0.1.126 - (2025-10-28)
---

## 0.1.125 - (2025-10-27)
---

## 0.1.124 - (2025-10-27)
---

## 0.1.123 - (2025-10-26)
---

## 0.1.122 - (2025-10-26)
---

## 0.1.121 - (2025-10-22)
---

## 0.1.120 - (2025-10-21)
---

### Changes
* Defining cachetools dep to be >= 5.2 and < 7


## 0.1.119 - (2025-10-21)
---

## 0.1.118 - (2025-10-20)
---

## 0.1.117 - (2025-10-15)
---

## 0.1.116 - (2025-10-09)
---

## 0.1.115 - (2025-10-08)
---

## 0.1.114 - (2025-10-08)
---

## 0.1.113 - (2025-10-08)
---

## 0.1.112 - (2025-10-08)
---

### New
* Adding containerEngine usage in builds proto
* Adding duration report to pytest


## 0.1.111 - (2025-09-30)
---

### Fixes
* debug wheels location when executing a build


## 0.1.110 - (2025-09-29)
---

### New
* SDK support uploading files to Azure Blob Storage


## 0.1.109 - (2025-09-29)
---

## 0.1.108 - (2025-09-29)
---

## 0.1.107 - (2025-09-29)
---

## 0.1.106 - (2025-09-29)
---

## 0.1.105 - (2025-09-28)
---

## 0.1.104 - (2025-09-28)
---

## 0.1.103 - (2025-09-25)
---

## 0.1.102 - (2025-09-25)
---

## 0.1.101 - (2025-09-21)
---

## 0.1.100 - (2025-09-21)
---

## 0.1.99 - (2025-09-18)
---

## 0.1.98 - (2025-09-16)
---

## 0.1.97 - (2025-09-15)
---

### New
* model group management client can now fetch a specific model group


## 0.1.96 - (2025-09-15)
---

## 0.1.95 - (2025-09-15)
---

## 0.1.94 - (2025-09-15)
---

## 0.1.93 - (2025-09-14)
---

## 0.1.92 - (2025-09-14)
---

## 0.1.91 - (2025-09-14)
---

## 0.1.90 - (2025-09-11)
---

## 0.1.89 - (2025-09-11)
---

## 0.1.88 - (2025-09-11)
---

## 0.1.87 - (2025-09-04)
---

## 0.1.86 - (2025-09-04)
---

## 0.1.85 - (2025-09-03)
---

## 0.1.84 - (2025-09-03)
---

## 0.1.83 - (2025-09-02)
---

## 0.1.82 - (2025-09-02)
---

## 0.1.81 - (2025-09-02)
---

## 0.1.80 - (2025-09-02)
---

## 0.1.79 - (2025-09-01)
---

## 0.1.78 - (2025-08-31)
---

## 0.1.77 - (2025-08-31)
---

## 0.1.76 - (2025-08-31)
---

### New
* Support authentication for JFrog Self Hosted accounts


## 0.1.75 - (2025-08-28)
---

## 0.1.74 - (2025-08-28)
---

## 0.1.73 - (2025-08-28)
---

## 0.1.72 - (2025-08-28)
---

## 0.1.71 - (2025-08-26)
---

## 0.1.70 - (2025-08-25)
---

### New
* silence unsupported self-hosted backend exception
* support uploading source code to artifactory


## 0.1.69 - (2025-08-25)
---

## 0.1.68 - (2025-08-24)
---

## 0.1.67 - (2025-08-24)
---

## 0.1.66 - (2025-08-24)
---

## 0.1.65 - (2025-08-21)
---

## 0.1.64 - (2025-08-20)
---

## 0.1.63 - (2025-08-20)
---

## 0.1.62 - (2025-08-19)
---

## 0.1.61 - (2025-08-19)
---

### Fixes
* [`FrogMLClient.list_builds`](./frogml/sdk/frogml_client/client.py) - Making `tags` and `filters` optional parameters


## 0.1.60 - (2025-08-19)
---

## 0.1.59 - (2025-08-18)
---

## 0.1.58 - (2025-08-18)
---

## 0.1.57 - (2025-08-18)
---

## 0.1.56 - (2025-08-18)
---

## 0.1.55 - (2025-08-17)
---

## 0.1.54 - (2025-08-14)
---

### Fixes
* Replacing BaseModel by the correct Model object for the 'from_proto' method


## 0.1.53 - (2025-08-14)
---

## 0.1.52 - (2025-08-14)
---

## 0.1.51 - (2025-08-13)
---

### Changes


---
### Changes
added support for the platform url
## 0.1.50 - (2025-08-13)
---

## 1.1.49 - (2025-08-12)
---

## 1.1.48 - (2025-08-10)
---

## 1.1.47 - (2025-08-07)
---

## 1.1.46 - (2025-08-07)
---

## 1.1.45 - (2025-08-06)
---

## 1.1.44 - (2025-08-06)
---

## 1.1.43 - (2025-08-05)
---

## 1.1.42 - (2025-08-05)
---

## 1.1.41 - (2025-08-05)
---

## 1.1.40 - (2025-08-05)
---

## 1.1.39 - (2025-08-05)
---

## 1.1.38 - (2025-08-05)
---

## 1.1.37 - (2025-08-04)
---

## 1.1.36 - (2025-08-04)
---

## 1.1.35 - (2025-08-04)
---

## 1.1.34 - (2025-07-30)
---

## 1.1.33 - (2025-07-30)
---

## 1.1.32 - (2025-07-28)
---

## 1.1.31 - (2025-07-27)
---

## 1.1.30 - (2025-07-27)
---

## 1.1.29 - (2025-07-24)
---

## 1.1.28 - (2025-07-22)
---

## 1.1.27 - (2025-07-22)
---

## 1.1.26 - (2025-07-22)
---

### Changes
* Added a detailed deprecation message for users using deprecated Snowflake basic authentication


## 1.1.25 - (2025-07-21)
---

## 1.1.24 - (2025-07-20)
---

## 1.1.23 - (2025-07-20)
---

## 1.1.22 - (2025-07-19)
---

## 1.1.21 - (2025-07-17)
---

## 1.1.20 - (2025-07-16)
---

## 1.1.19 - (2025-07-16)
---

## 1.1.18 - (2025-07-15)
---

## 1.1.17 - (2025-07-13)
---

## 1.1.16 - (2025-07-13)
---

## 1.1.15 - (2025-07-13)
---

## 1.1.14 - (2025-07-13)
---

## 1.1.13 - (2025-07-10)
---

## 1.1.12 - (2025-07-10)
---

## 1.1.11 - (2025-07-08)
---

## 1.1.10 - (2025-07-08)
---

### Breaks
* Removing the BuildsManagementService


## 1.1.9 - (2025-07-08)
---

### New
* Add model group client
* Add server id to config


## 1.1.8 - (2025-07-08)
---

### New
* Frogml Core now supports Snowflake key_pair authentication
