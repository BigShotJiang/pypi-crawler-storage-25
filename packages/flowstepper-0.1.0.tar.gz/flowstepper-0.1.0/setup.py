"""Minimal ``setup.py`` whose sole purpose is to build the bundled frontend.

All package metadata lives in ``pyproject.toml``. This file stays because
setuptools still needs a custom ``cmdclass`` to run the ``npm run build`` step
ahead of ``build_py`` / ``sdist`` / ``develop`` / ``editable_wheel``.
"""

from __future__ import annotations

import os
import shutil
import subprocess
from pathlib import Path

from setuptools import setup
from setuptools.command.build_py import build_py as _build_py
from setuptools.command.sdist import sdist as _sdist

try:
    from setuptools.command.develop import develop as _develop
except ImportError:  # pragma: no cover
    _develop = None

try:
    from setuptools.command.editable_wheel import editable_wheel as _editable_wheel
except ImportError:  # pragma: no cover
    _editable_wheel = None


_FRONTEND_BUILT = False
_REPO_ROOT = Path(__file__).parent.resolve()


def _build_frontend() -> None:
    global _FRONTEND_BUILT
    if _FRONTEND_BUILT:
        return

    if os.environ.get("FLOWSTEPPER_SKIP_FRONTEND_BUILD") == "1":
        print("Skipping frontend build because FLOWSTEPPER_SKIP_FRONTEND_BUILD=1")
        _FRONTEND_BUILT = True
        return

    frontend_dir = _REPO_ROOT / "flowstepper" / "frontend"
    script_path = _REPO_ROOT / "flowstepper" / "scripts" / "build_frontend.sh"
    bundle_entrypoint = _REPO_ROOT / "flowstepper" / "server" / "static" / "index.html"

    if not frontend_dir.exists():
        _FRONTEND_BUILT = True
        return

    if shutil.which("npm") is None:
        raise RuntimeError(
            "npm is required to build the Flowstepper frontend when installing from source"
        )

    subprocess.run(["bash", str(script_path)], cwd=_REPO_ROOT, check=True)

    if not bundle_entrypoint.exists():
        raise RuntimeError(f"Frontend build did not produce {bundle_entrypoint}")

    _FRONTEND_BUILT = True


class build_py(_build_py):
    def run(self) -> None:
        _build_frontend()
        super().run()


class sdist(_sdist):
    def run(self) -> None:
        _build_frontend()
        super().run()


cmdclass: dict[str, type] = {"build_py": build_py, "sdist": sdist}

if _develop is not None:
    class develop(_develop):
        def run(self) -> None:
            _build_frontend()
            super().run()

    cmdclass["develop"] = develop

if _editable_wheel is not None:
    class editable_wheel(_editable_wheel):
        def run(self) -> None:
            _build_frontend()
            super().run()

    cmdclass["editable_wheel"] = editable_wheel


setup(cmdclass=cmdclass)
