# Changelog

All notable changes to flowstepper will be documented here.

## [0.1.0] - 2026-03-31

### Added
- Python SDK for instrumenting pipelines (`flowstepper.sdk`)
  - `Pipeline` context manager with once-per-entry sampling decision
  - `node_scope()` for per-node timing and metadata capture
  - Async bounded queue with configurable drop policies (`DROP_NEWEST`, `DROP_OLDEST`, `BLOCK`)
  - `LoggingConfig` for sampling rate, queue depth, and error callbacks
  - `SamplingStrategy.NEVER` produces zero-cost no-ops on the hot path
- `.flowlog` wire format: newline-delimited JSON, eight event types
- FastAPI server that reads `.flowlog` files and exposes a REST API (`/api/v1/pipelines/`)
- React SPA for interactive pipeline visualization
  - DAG layout via dagre with D3 SVG rendering
  - Per-node timing and metadata panels
  - Timeline view with time-scale ruler (Chrome DevTools style)
  - Run search by ID and parameters
  - SSE-based live tailing (`--reload` mode)
- `flowstepper` CLI entry point (`--logdir`, `--port`, `--reload`)
