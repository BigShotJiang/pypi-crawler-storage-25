"""
REST API — pipeline and run endpoints.

Base path (mounted in app.py): /api/v1

Endpoints
---------
GET  /pipelines
    List all pipeline names found in log_dir.
GET  /pipelines/{pipeline_name}/runs
    List run summaries for a pipeline, sorted newest-first.
GET  /pipelines/{pipeline_name}/runs/{run_id}
    Full run detail: DAG nodes + edges + runtime stats.
GET  /pipelines/{pipeline_name}/runs/{run_id}/stream
    Raw event stream (Server-Sent Events) for live tailing.
"""

from __future__ import annotations

import warnings
from collections.abc import AsyncGenerator
from pathlib import Path
from typing import Any

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from watchfiles import Change, awatch

from flowstepper.reader import parser as reader_parser
from flowstepper.reader.parser import PipelineRun


def _resolve_within(base: Path, *parts: str) -> Path:
    """Resolve a path constructed from *parts* and assert it stays within *base*."""
    resolved_base = base.resolve()
    resolved_path = (base / Path(*parts)).resolve()
    if not resolved_path.is_relative_to(resolved_base):
        raise HTTPException(status_code=400, detail="Invalid path component")
    return resolved_path


# In-memory cache: path -> (mtime_ns, PipelineRun). Keeps revalidating polls
# cheap — only re-parse when the file on disk has changed.
_run_cache: dict[Path, tuple[int, PipelineRun]] = {}


def _parse_cached(log_path: Path) -> PipelineRun:
    """Parse a log file, reusing the previously parsed result when fresh."""
    mtime_ns = log_path.stat().st_mtime_ns
    cached = _run_cache.get(log_path)
    if cached is not None and cached[0] == mtime_ns:
        return cached[1]
    run = reader_parser.parse(log_path)
    _run_cache[log_path] = (mtime_ns, run)
    return run


router = APIRouter()


# ---------------------------------------------------------------------------
# Response schemas
# ---------------------------------------------------------------------------


class RunSummary(BaseModel):
    run_id: str
    pipeline_name: str
    started_at: float
    ended_at: float | None
    had_error: bool
    node_count: int
    edge_count: int
    metadata: dict[str, Any] = {}


class NodeDetail(BaseModel):
    node_id: str
    name: str
    kind: str
    tags: dict[str, Any]
    runs: list[dict[str, Any]]


class EdgeDetail(BaseModel):
    source_id: str
    target_id: str
    kind: str
    label: str | None


class PipelineRunDetail(BaseModel):
    run_id: str
    pipeline_name: str
    started_at: float
    ended_at: float | None
    had_error: bool
    nodes: list[NodeDetail]
    edges: list[EdgeDetail]
    metadata: dict[str, Any]
    node_kind_colors: dict[str, str] = {}


# ---------------------------------------------------------------------------
# Route handlers
# ---------------------------------------------------------------------------


@router.get("/pipelines")
async def list_pipelines(
    request: Request,
    q: str | None = None,
) -> dict[str, list[str]]:
    log_dir: Path = request.app.state.log_dir
    if not log_dir.exists():
        return {"pipelines": []}

    dirs_with_logs: set[str] = set()
    for log_file in log_dir.rglob("*.flowlog"):
        rel_dir = log_file.parent.relative_to(log_dir)
        dirs_with_logs.add(rel_dir.as_posix())

    pipelines = sorted(dirs_with_logs)
    if q is not None:
        q_lower = q.lower()
        pipelines = [p for p in pipelines if q_lower in p.lower()]
    return {"pipelines": pipelines}


@router.get("/pipelines/{pipeline_name:path}/runs")
async def list_runs(
    pipeline_name: str,
    request: Request,
    q: str | None = None,
) -> dict[str, list[RunSummary]]:
    log_dir: Path = request.app.state.log_dir
    pipeline_dir = _resolve_within(log_dir, pipeline_name)
    if not pipeline_dir.exists():
        raise HTTPException(status_code=404, detail=f"Pipeline {pipeline_name!r} not found")

    log_files = sorted(pipeline_dir.rglob("*.flowlog"))

    if q is not None:
        q_lower = q.lower()
        candidate_files: list[Path] = []
        for log_path in log_files:
            result = reader_parser.quick_scan(log_path)
            if result is None:
                continue
            run_id, metadata = result
            if _run_matches(run_id, metadata, q_lower):
                candidate_files.append(log_path)
    else:
        candidate_files = log_files

    runs = []
    for log_path in candidate_files:
        try:
            runs.append(_parse_cached(log_path))
        except (FileNotFoundError, ValueError) as exc:
            warnings.warn(f"Skipping {log_path}: {exc}")
    runs.sort(key=lambda r: r.started_at, reverse=True)

    summaries = [
        RunSummary(
            run_id=r.run_id,
            pipeline_name=r.pipeline_name,
            started_at=r.started_at,
            ended_at=r.ended_at,
            had_error=r.had_error,
            node_count=len(r.nodes),
            edge_count=len(r.edges),
            metadata=r.metadata,
        )
        for r in runs
    ]
    return {"runs": summaries}


def _run_matches(run_id: str, metadata: dict[str, Any], q_lower: str) -> bool:
    if q_lower in run_id.lower():
        return True
    for k, v in metadata.items():
        if q_lower in k.lower() or q_lower in str(v).lower():
            return True
    return False


@router.get("/pipelines/{pipeline_name:path}/runs/{run_id}")
async def get_run(pipeline_name: str, run_id: str, request: Request) -> PipelineRunDetail:
    log_dir: Path = request.app.state.log_dir
    log_path = _resolve_within(log_dir, pipeline_name, f"{run_id}.flowlog")
    if not log_path.exists():
        raise HTTPException(status_code=404, detail=f"Run {run_id!r} not found")

    run = _parse_cached(log_path)
    return PipelineRunDetail(
        run_id=run.run_id,
        pipeline_name=run.pipeline_name,
        started_at=run.started_at,
        ended_at=run.ended_at,
        had_error=run.had_error,
        nodes=[
            NodeDetail(
                node_id=n.node_id,
                name=n.name,
                kind=n.kind,
                tags=n.tags,
                runs=n.runs,
            )
            for n in run.nodes
        ],
        edges=[
            EdgeDetail(
                source_id=e.source_id,
                target_id=e.target_id,
                kind=e.kind,
                label=e.label,
            )
            for e in run.edges
        ],
        metadata=run.metadata,
        node_kind_colors=run.node_kind_colors,
    )


@router.get("/pipelines/{pipeline_name:path}/runs/{run_id}/stream")
async def stream_events(pipeline_name: str, run_id: str, request: Request) -> StreamingResponse:
    """Server-Sent Events stream for live log tailing.

    Uses ``watchfiles`` to react to file modifications instead of busy-polling.
    """
    log_dir: Path = request.app.state.log_dir
    log_path = _resolve_within(log_dir, pipeline_name, f"{run_id}.flowlog")
    if not log_path.exists():
        raise HTTPException(status_code=404, detail=f"Run {run_id!r} not found")

    async def event_generator() -> AsyncGenerator[str, None]:
        with open(log_path) as f:
            for line in f:
                line = line.strip()
                if line:
                    yield f"data: {line}\n\n"

            async for changes in awatch(log_path, stop_event=None):
                if await request.is_disconnected():
                    break
                if not any(change != Change.deleted for change, _ in changes):
                    continue
                while True:
                    line = f.readline()
                    if not line:
                        break
                    line = line.strip()
                    if line:
                        yield f"data: {line}\n\n"

    return StreamingResponse(event_generator(), media_type="text/event-stream")
