"""
Web server package — FastAPI application + static frontend.
"""
