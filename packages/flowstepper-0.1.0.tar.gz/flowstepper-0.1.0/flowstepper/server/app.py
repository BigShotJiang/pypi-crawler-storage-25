"""
FastAPI application factory.

The CLI calls `create_app()` and hands the result to uvicorn:

    import uvicorn
    app = create_app(log_dir=Path(logdir))
    uvicorn.run(app, host=host, port=port)

Static frontend assets are served from `flowstepper/server/static/` which is
populated by the `scripts/build_frontend.sh` script before packaging.
"""

from __future__ import annotations

from pathlib import Path

from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles

from flowstepper.server.api.v1.pipelines import router as pipelines_router

# Path to the bundled frontend — populated at build time.
STATIC_DIR = Path(__file__).parent / "static"


def create_app(log_dir: Path) -> FastAPI:
    """
    Build and return the FastAPI application.

    Parameters
    ----------
    log_dir:
        Root directory that the server will scan for `.flowlog` files.
        Stored in app.state so API routers can access it without globals.
    """
    app = FastAPI(title="Flowstepper", version="0.1.0")
    app.state.log_dir = log_dir
    app.include_router(pipelines_router, prefix="/api/v1")

    if (STATIC_DIR / "index.html").exists():
        app.mount("/", StaticFiles(directory=STATIC_DIR, html=True), name="frontend")

    return app
