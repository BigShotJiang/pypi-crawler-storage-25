"""
Pipeline context manager — the primary SDK entry point.

Production design
-----------------
The Pipeline is designed so that **all logging is a no-op when disabled or
not sampled**, adding zero overhead beyond a single boolean check on the
hot path.

Sampling decision
~~~~~~~~~~~~~~~~~
Sampling is decided once in __enter__. If the run is not sampled, every
subsequent SDK call (add_node, connect, node_scope, record) is a no-op.
This means the caller code never changes between dev and prod — just swap
the config.

Thread safety
~~~~~~~~~~~~~
A single Pipeline instance should not be shared across threads. For
concurrent pipelines (e.g. one per request), create one Pipeline per
request. The underlying Logger is shared only through its queue, which is
thread-safe.

Usage
-----
    # Development — log everything
    with Pipeline("rec_pipeline", log_dir="./logs") as p:
        ...

    # Production — 1% sample rate, non-blocking, metrics on drops
    cfg = LoggingConfig.for_production(
        sample_rate=0.01,
        on_drop=lambda n: statsd.increment("flowstepper.drops", n),
    )
    with Pipeline("my_pipeline", log_dir="/var/log/logs", config=cfg) as p:
        fetch = p.add_node(BaseNode("fetch", kind="retrieval"))
        score = p.add_node(BaseNode("score", kind="ranker"))
        p.connect(fetch, score)

        with p.node_scope(src):
            items = fetch()
            p.record(src, item_count=len(items))

    # Disabled entirely (load-test baseline, zero overhead)
    with Pipeline("rec_pipeline", config=LoggingConfig.disabled()) as p:
        ...  # all calls are no-ops
"""

from __future__ import annotations

import random
import time
import uuid
from pathlib import Path
from types import TracebackType
from typing import Any

from flowstepper.sdk.config import LoggingConfig
from flowstepper.sdk.logger import Logger
from flowstepper.sdk.node import BaseNode
from flowstepper.sdk.types import EdgeKind, EventType


class Pipeline:
    """
    Represents one pipeline run.

    When sampled, a .flowlog file is created in log_dir:
        <log_dir>/<pipeline_name>/<run_id>.flowlog

    When not sampled (sample_rate=0 or random draw fails), no file is created
    and all method calls are O(1) no-ops.
    """

    def __init__(
        self,
        name: str,
        log_dir: str | Path = "./logs",
        run_id: str | None = None,
        metadata: dict[str, Any] | None = None,
        config: LoggingConfig | None = None,
        node_kind_colors: dict[str, str] | None = None,
    ) -> None:
        self._name = name
        self._log_dir = Path(log_dir)
        self._run_id_override = run_id
        self._metadata = metadata or {}
        self._config = config if config is not None else LoggingConfig.for_development()
        self._node_kind_colors = node_kind_colors or {}

        self._sampled = False
        self._run_id: str = ""
        self._logger: Logger | None = None
        self._node_counter: int = 0

    # ------------------------------------------------------------------
    # Context manager protocol
    # ------------------------------------------------------------------

    def __enter__(self) -> Pipeline:
        """
        Decide sampling, create the Logger (if sampled), emit pipeline_start.

        Sampling decision:
          sample_rate == 0.0  → never log (zero overhead)
          sample_rate == 1.0  → always log
          0 < sample_rate < 1 → log that fraction at random
        """
        self._sampled = random.random() < self._config.sample_rate

        if not self._sampled:
            return self

        self._run_id = self._run_id_override or str(uuid.uuid4())
        log_path = Logger.build_log_path(self._log_dir, self._name, self._run_id)
        self._logger = Logger(
            log_path=log_path,
            config=self._config,
            run_id=self._run_id,
        )

        self._logger.write(
            EventType.PIPELINE_START,
            {
                "pipeline_name": self._name,
                "metadata": self._metadata,
                "node_kind_colors": self._node_kind_colors,
            },
        )
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        """
        Emit pipeline_end (with had_error flag), then close the Logger.

        Contract: this method MUST NOT raise — logging failures are silently
        swallowed so the caller's exception (if any) is not masked.
        """
        if self._sampled and self._logger is not None:
            try:
                self._logger.write(
                    EventType.PIPELINE_END,
                    {"had_error": exc_type is not None},
                )
                self._logger.close()
            except Exception:
                pass

    # ------------------------------------------------------------------
    # DAG construction
    # ------------------------------------------------------------------

    def add_node(self, node: BaseNode) -> BaseNode:
        """
        Register a node. No-op when not sampled.

        Emits node_declared event and assigns an internal _node_id.
        Returns the node (mutated in place) for inline use.
        """
        if not self._sampled or self._logger is None:
            return node

        node._node_id = f"node-{self._node_counter}"
        self._node_counter += 1
        self._logger.write(EventType.NODE_DECLARED, node.as_dict())
        return node

    def connect(
        self,
        source: BaseNode,
        target: BaseNode,
        kind: EdgeKind = EdgeKind.STREAM,
        label: str | None = None,
    ) -> None:
        """
        Declare a directed edge source → target. No-op when not sampled.

        Emits edge_declared event.
        """
        if not self._sampled or self._logger is None:
            return

        self._logger.write(
            EventType.EDGE_DECLARED,
            {
                "source_id": source._node_id,
                "target_id": target._node_id,
                "edge_kind": kind.value,
                "label": label,
            },
        )

    # ------------------------------------------------------------------
    # Runtime instrumentation
    # ------------------------------------------------------------------

    def node_scope(self, node: BaseNode) -> NodeScope:
        """
        Context manager wrapping a node's execution window.

        When sampled: emits node_start on enter, node_end (or node_error) on exit.
        When not sampled: returns a no-op context manager (zero overhead).
        """
        if not self._sampled or self._logger is None:
            return _NoOpNodeScope()
        return _ActiveNodeScope(node=node, logger=self._logger)

    def record(self, node: BaseNode, **kwargs: Any) -> None:
        """
        Attach runtime metrics to the current node_scope. No-op when not sampled.

        Common keys: item_count, latency_ms, score_avg, cache_hit, model_version.
        Emits a metadata event.
        """
        if not self._sampled or self._logger is None:
            return

        self._logger.write(
            EventType.METADATA,
            {
                "node_id": node._node_id,
                "payload": kwargs,
            },
        )

    # ------------------------------------------------------------------
    # Introspection
    # ------------------------------------------------------------------

    @property
    def is_sampled(self) -> bool:
        """True if this run is being logged."""
        return self._sampled

    @property
    def run_id(self) -> str:
        """The run identifier (generated or user-supplied)."""
        return self._run_id

    @property
    def dropped_events(self) -> int:
        """Number of events dropped by the async queue for this run."""
        if not self._sampled or self._logger is None:
            return 0
        return self._logger.dropped_count


class NodeScope:
    """Returned by Pipeline.node_scope(). Base for _ActiveNodeScope / _NoOpNodeScope."""

    is_error: bool = False


class _NoOpNodeScope(NodeScope):
    """Zero-overhead context manager returned when the run is not sampled."""

    is_error: bool = False

    def __enter__(self) -> _NoOpNodeScope:
        return self

    def __exit__(self, *_: Any) -> None:
        pass


class _ActiveNodeScope(NodeScope):
    """Emits node_start on enter and node_end/node_error on exit.

    Set ``scope.is_error = True`` inside a ``with`` block to mark the
    execution as a soft error without raising an exception::

        with pipeline.node_scope(node) as scope:
            result = fetch()
            if not result:
                scope.is_error = True
    """

    def __init__(self, node: BaseNode, logger: Logger) -> None:
        self._node = node
        self._logger = logger
        self._start: float = 0.0
        self.is_error: bool = False

    def __enter__(self) -> _ActiveNodeScope:
        self._start = time.perf_counter()
        self._logger.write(
            EventType.NODE_START,
            {"node_id": self._node._node_id},
        )
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        duration_ms = (time.perf_counter() - self._start) * 1000.0
        if exc_type is not None:
            self._logger.write(
                EventType.NODE_ERROR,
                {
                    "node_id": self._node._node_id,
                    "error_type": exc_type.__name__,
                    "error_message": str(exc_val),
                },
            )
        else:
            self._logger.write(
                EventType.NODE_END,
                {
                    "node_id": self._node._node_id,
                    "duration_ms": duration_ms,
                    "is_error": self.is_error,
                },
            )
