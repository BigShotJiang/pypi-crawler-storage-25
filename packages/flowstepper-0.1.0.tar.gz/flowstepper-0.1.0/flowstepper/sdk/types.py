"""
Shared type definitions for the SDK and the log format.

Log format
----------
Every pipeline run produces a single `.flowlog` file (newline-delimited JSON).
Each line is one *event* — a JSON object with at minimum:

    {"event": "<event_type>", "ts": <unix_float>, "run_id": "<id>", ...payload}

Event types
-----------
pipeline_start   – emitted once when Pipeline.__enter__ is called
pipeline_end     – emitted once when Pipeline.__exit__ is called
node_declared    – emitted for every add_node() call
edge_declared    – emitted for every connect() call
node_start       – emitted when a node begins processing
node_end         – emitted when a node finishes (includes duration_ms)
node_error       – emitted on exception inside a node
metadata         – arbitrary key/value payload attached to any scope
"""

from __future__ import annotations

from enum import Enum
from typing import Any


class EdgeKind(str, Enum):
    """How items flow along an edge."""

    STREAM = "stream"   # continuous item stream
    BATCH = "batch"     # single batched transfer
    SIGNAL = "signal"   # control / trigger (no items)


class EventType(str, Enum):
    PIPELINE_START = "pipeline_start"
    PIPELINE_END = "pipeline_end"
    NODE_DECLARED = "node_declared"
    EDGE_DECLARED = "edge_declared"
    NODE_START = "node_start"
    NODE_END = "node_end"
    NODE_ERROR = "node_error"
    METADATA = "metadata"


# Type alias for raw log event dicts read back from .flowlog files
LogEvent = dict[str, Any]
