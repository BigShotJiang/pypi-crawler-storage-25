"""
Async, production-grade log writer.

Design goals
------------
1. **Zero hot-path blocking** — the caller's thread only enqueues an event
   into an in-memory queue; all disk I/O happens on a background writer thread.
2. **Bounded memory** — the queue has a hard size limit; overflow is handled
   by the configured DropPolicy (default: drop newest, never block).
3. **Batched writes** — the background thread drains the queue in batches and
   writes serialised JSON lines in a single write() call per batch,
   minimising syscall overhead.
4. **Crash-safe shutdown** — close() signals the background thread to drain
   the remaining queue before exiting, with a configurable timeout.
5. **Error isolation** — I/O errors on the background thread never propagate
   to the caller; they are reported via LoggingConfig.on_error.
6. **Dropped-event accounting** — dropped events increment an atomic counter;
   the counter is flushed to LoggingConfig.on_drop after each batch.

Internal architecture
---------------------

    Caller threads
        │
        │  Logger.write()  (non-blocking)
        ▼
    ┌─────────────────────────┐
    │  _queue: queue.Queue    │  bounded, maxsize = config.queue_maxsize
    │  (LogEvent dicts)       │
    └────────────┬────────────┘
                 │  _writer_thread drains in batches
                 ▼
    ┌─────────────────────────┐
    │  _WriterThread          │
    │  - wakes every          │
    │    flush_interval_ms    │
    │  - pops up to           │
    │    flush_batch_size     │
    │  - serialises to NDJSON │
    │  - writes to file       │
    │  - optionally fsyncs    │
    └─────────────────────────┘
"""

from __future__ import annotations

import os
import queue
import threading
import time
from collections.abc import Callable
from pathlib import Path
from typing import Any

import orjson

from flowstepper.sdk.config import DropPolicy, LoggingConfig
from flowstepper.sdk.types import EventType, LogEvent

# Sentinel placed on the queue to signal the writer thread to shut down.
_STOP_SENTINEL = object()


class Logger:
    """
    Thread-safe, non-blocking event writer.

    One Logger instance is created per Pipeline run. It must be explicitly
    closed (or used via Pipeline's context manager) to ensure remaining
    queued events are flushed before the process exits.
    """

    def __init__(self, log_path: Path, config: LoggingConfig, run_id: str) -> None:
        self._log_path = log_path
        self._config = config
        self._run_id = run_id

        self._queue: queue.Queue[LogEvent | object] = queue.Queue(
            maxsize=config.queue_maxsize
        )

        self._drop_lock = threading.Lock()
        self._total_dropped: int = 0
        self._unreported_drops: int = 0

        self._writer = _WriterThread(
            q=self._queue,
            log_path=log_path,
            config=config,
            report_drops=self._report_drops,
        )
        self._writer.start()

    # ------------------------------------------------------------------
    # Public API (called from hot path)
    # ------------------------------------------------------------------

    def write(self, event_type: EventType, payload: dict[str, Any]) -> None:
        """
        Enqueue one event for async writing. Never blocks the caller.

        If the queue is full, the event is handled according to
        config.drop_policy:
        - DROP_NEWEST: event is silently dropped (default)
        - DROP_OLDEST: oldest queued event is discarded to make room
        - BLOCK: caller blocks until space is available (use with care)
        """
        event = self._make_event(event_type, payload)
        self._try_enqueue(event)

    def close(self, drain_timeout_s: float = 5.0) -> None:
        """
        Signal the writer thread to stop and wait for it to drain the queue.

        Parameters
        ----------
        drain_timeout_s:
            How long to wait for the background thread to finish flushing.
            Remaining events are dropped after the timeout.
        """
        self._queue.put(_STOP_SENTINEL)
        self._writer.join(timeout=drain_timeout_s)
        if self._writer.is_alive():
            remaining = self._queue.qsize()
            if remaining > 0:
                with self._drop_lock:
                    self._total_dropped += remaining
                    self._unreported_drops += remaining
                self._report_drops()

    @property
    def dropped_count(self) -> int:
        """Total events dropped since this Logger was created."""
        with self._drop_lock:
            return self._total_dropped

    # ------------------------------------------------------------------
    # Class-level helpers
    # ------------------------------------------------------------------

    @staticmethod
    def build_log_path(log_dir: Path, pipeline_name: str, run_id: str) -> Path:
        """
        Compute the canonical .flowlog path and create parent directories.

        Convention: <log_dir>/<pipeline_name>/<run_id>.flowlog
        """
        log_path = log_dir / pipeline_name / f"{run_id}.flowlog"
        log_path.parent.mkdir(parents=True, exist_ok=True)
        return log_path

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _make_event(self, event_type: EventType, payload: dict[str, Any]) -> LogEvent:
        """Attach event, ts, and run_id fields to payload."""
        event: LogEvent = {
            "event": event_type.value,
            "ts": time.time(),
            "run_id": self._run_id,
        }
        event.update(payload)
        return event

    def _try_enqueue(self, event: LogEvent) -> None:
        """
        Attempt to put event on the queue according to the drop policy.

        Increments the internal drop counter on overflow.
        """
        if self._config.drop_policy == DropPolicy.BLOCK:
            self._queue.put(event)
            return

        if self._config.drop_policy == DropPolicy.DROP_NEWEST:
            try:
                self._queue.put_nowait(event)
            except queue.Full:
                with self._drop_lock:
                    self._total_dropped += 1
                    self._unreported_drops += 1
            return

        # DROP_OLDEST: evict the oldest item to make room, then enqueue
        while True:
            try:
                self._queue.put_nowait(event)
                return
            except queue.Full:
                try:
                    self._queue.get_nowait()
                    with self._drop_lock:
                        self._total_dropped += 1
                        self._unreported_drops += 1
                except queue.Empty:
                    pass  # race: another thread drained it; retry

    def _report_drops(self) -> None:
        """Drain the unreported drop counter and invoke config.on_drop if set."""
        with self._drop_lock:
            count = self._unreported_drops
            self._unreported_drops = 0

        if count > 0 and self._config.on_drop is not None:
            try:
                self._config.on_drop(count)
            except Exception:
                pass


class _WriterThread(threading.Thread):
    """
    Background daemon thread that drains the queue and writes to disk.

    Lifecycle:
      1. Starts when Logger is constructed.
      2. Wakes every flush_interval_ms ms OR when flush/stop sentinels arrive.
      3. Writes batches of up to flush_batch_size events as NDJSON.
      4. Exits cleanly when it dequeues _STOP_SENTINEL.
    """

    def __init__(
        self,
        q: queue.Queue[LogEvent | object],
        log_path: Path,
        config: LoggingConfig,
        report_drops: Callable[[], None],
    ) -> None:
        super().__init__(daemon=True)
        self._q = q
        self._log_path = log_path
        self._config = config
        self._report_drops = report_drops

    def run(self) -> None:
        """Main loop: batch-drain the queue and write to file."""
        flush_interval = self._config.flush_interval_ms / 1000.0

        try:
            f = self._log_path.open("ab")
        except Exception as e:
            self._invoke_error_cb(e)
            return

        with f:
            while True:
                # Block until we get at least one item (or timeout)
                try:
                    first = self._q.get(timeout=flush_interval)
                except queue.Empty:
                    # Nothing arrived — loop again
                    continue

                if first is _STOP_SENTINEL:
                    break

                batch: list[LogEvent] = [first]  # type: ignore[list-item]
                stop = False

                while len(batch) < self._config.flush_batch_size:
                    try:
                        item = self._q.get_nowait()
                        if item is _STOP_SENTINEL:
                            stop = True
                            break
                        batch.append(item)  # type: ignore[arg-type]
                    except queue.Empty:
                        break

                self._write_batch(f, batch)
                self._report_drops()

                if stop:
                    break

    def _write_batch(self, f: Any, events: list[LogEvent]) -> None:
        """
        Serialise events to NDJSON and write in one call.

        Optionally calls fsync if config.sync_on_flush is True.
        Invokes config.on_error on any I/O exception (never re-raises).
        """
        try:
            lines = b"\n".join(orjson.dumps(e) for e in events) + b"\n"
            f.write(lines)
            if self._config.sync_on_flush:
                f.flush()
                os.fsync(f.fileno())
            else:
                f.flush()
        except Exception as e:
            self._invoke_error_cb(e)

    def _invoke_error_cb(self, exc: Exception) -> None:
        if self._config.on_error is not None:
            try:
                self._config.on_error(exc)
            except Exception:
                pass
