"""
Logging configuration for the Flowstepper SDK.

Designed for high-load production use:
- all writes happen on a background thread (never blocks the caller)
- a bounded in-memory queue decouples the hot path from disk I/O
- sampling is controlled by a single sample_rate float (0–1)
- logging failures are silently swallowed (optionally reported via callback)

Typical production setup
------------------------
    from flowstepper.sdk.config import LoggingConfig, DropPolicy

    cfg = LoggingConfig(
        sample_rate=0.01,            # log 1 % of requests
        queue_maxsize=10_000,
        drop_policy=DropPolicy.DROP_OLDEST,
        flush_interval_ms=200,
        flush_batch_size=256,
        sync_on_flush=False,
        on_drop=lambda count: metrics.increment("flowstepper.dropped_events", count),
    )
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from enum import Enum


class DropPolicy(str, Enum):
    """What to do when the internal queue is full."""

    DROP_NEWEST = "drop_newest"
    """Discard the incoming event (default). Zero latency impact."""

    DROP_OLDEST = "drop_oldest"
    """Pop the oldest queued event to make room. Preserves recent data."""

    BLOCK = "block"
    """Block the caller until space is available.
    WARNING: use only in non-latency-sensitive contexts (e.g. batch jobs)."""


@dataclass
class LoggingConfig:
    """
    Full configuration for the async logger.

    Sampling is controlled by ``sample_rate`` alone:
      - ``1.0`` → log every run (default, suitable for dev / staging)
      - ``0.0`` → disable logging entirely; all SDK calls become no-ops
      - any value in between → log that fraction of runs at random

    All other defaults are conservative so development usage works
    out-of-the-box.
    """

    # ------------------------------------------------------------------
    # Sampling
    # ------------------------------------------------------------------
    sample_rate: float = 1.0
    """Fraction of runs to log. 1.0 = always, 0.0 = never, 0.01 = 1 %."""

    # ------------------------------------------------------------------
    # Queue / backpressure
    # ------------------------------------------------------------------
    queue_maxsize: int = 10_000
    """Maximum number of events buffered in memory."""

    drop_policy: DropPolicy = DropPolicy.DROP_NEWEST

    # ------------------------------------------------------------------
    # Background writer
    # ------------------------------------------------------------------
    flush_interval_ms: int = 500
    """How often the background thread flushes the queue to disk (ms)."""

    flush_batch_size: int = 128
    """Maximum events written in a single flush iteration."""

    # ------------------------------------------------------------------
    # Durability
    # ------------------------------------------------------------------
    sync_on_flush: bool = False
    """Call fsync after each flush batch."""

    # ------------------------------------------------------------------
    # Error handling
    # ------------------------------------------------------------------
    on_drop: Callable[[int], None] | None = None
    """Optional callback invoked with the number of dropped events."""

    on_error: Callable[[Exception], None] | None = None
    """Optional callback invoked when a background write fails."""

    # ------------------------------------------------------------------
    # Convenience constructors
    # ------------------------------------------------------------------

    @classmethod
    def for_development(cls) -> LoggingConfig:
        """Log everything synchronously-ish; suitable for local runs."""
        return cls(
            sample_rate=1.0,
            flush_interval_ms=100,
            sync_on_flush=True,
        )

    @classmethod
    def for_production(
        cls,
        sample_rate: float = 0.01,
        queue_maxsize: int = 10_000,
        on_drop: Callable[[int], None] | None = None,
        on_error: Callable[[Exception], None] | None = None,
    ) -> LoggingConfig:
        """
        Opinionated production preset.

        Samples 1% of traffic, drops newest events on overflow, never blocks.
        """
        return cls(
            sample_rate=sample_rate,
            queue_maxsize=queue_maxsize,
            drop_policy=DropPolicy.DROP_NEWEST,
            flush_interval_ms=200,
            flush_batch_size=256,
            sync_on_flush=False,
            on_drop=on_drop,
            on_error=on_error,
        )

    @classmethod
    def disabled(cls) -> LoggingConfig:
        """Zero overhead — all SDK calls are no-ops."""
        return cls(sample_rate=0.0)

    def __post_init__(self) -> None:
        if not 0.0 <= self.sample_rate <= 1.0:
            raise ValueError(f"sample_rate must be in [0, 1], got {self.sample_rate}")
        if self.queue_maxsize < 1:
            raise ValueError("queue_maxsize must be >= 1")
        if self.flush_batch_size < 1:
            raise ValueError("flush_batch_size must be >= 1")
