"""
Node descriptor class.

A *node* is a logical processing stage in the pipeline. Nodes are value
objects — they carry metadata but contain no execution logic themselves.
Actual computation happens in user code; the SDK only records timing/counts.

Usage
-----
    node = BaseNode("fetch", kind="retrieval", tags={"team": "search"})
    pipeline.add_node(node)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class BaseNode:
    """A named stage in the pipeline DAG.

    ``kind`` is a free-form string that callers define to categorise nodes.
    The frontend renders it as a label and can colour-code it via
    ``Pipeline(node_kind_colors={"retrieval": "#3b82f6", ...})``.
    """

    name: str
    kind: str = "custom"
    tags: dict[str, Any] = field(default_factory=dict)

    # Assigned by Pipeline.add_node(); opaque within the SDK.
    _node_id: str | None = field(default=None, init=False, repr=False)

    def as_dict(self) -> dict[str, Any]:
        """Serialize to a JSON-safe dict for the log event payload."""
        return {
            "node_id": self._node_id,
            "name": self.name,
            "kind": self.kind,
            "tags": self.tags,
        }
