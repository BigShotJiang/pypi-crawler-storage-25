#!/usr/bin/env bash
# Build the React frontend and place the output where the Python package
# expects it: flowstepper/server/static/
#
# Called by CI and by developers before building the wheel.
# Usage: ./scripts/build_frontend.sh

set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
FRONTEND_DIR="$REPO_ROOT/frontend"
STATIC_DIR="$REPO_ROOT/server/static"

echo "→ Installing frontend dependencies..."
cd "$FRONTEND_DIR"
if [[ -f package-lock.json ]]; then
  npm ci
else
  npm install
fi

echo "→ Building frontend (output: $STATIC_DIR)..."
npm run build
# vite.config.ts already sets outDir to ../server/static

echo "✓ Frontend built successfully."
echo "  Static assets are in: $STATIC_DIR"
