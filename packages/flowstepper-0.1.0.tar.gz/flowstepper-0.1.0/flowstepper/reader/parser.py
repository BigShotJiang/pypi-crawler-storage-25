"""
Parses `.flowlog` files and reconstructs the pipeline DAG + run metadata.

The parser is a pure function: pass a log file path, get back a PipelineRun
dataclass. The server layer is responsible for caching and watching for new /
updated files.
"""

from __future__ import annotations

import json
import warnings
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class NodeRecord:
    """In-memory representation of a declared node."""

    node_id: str
    name: str
    kind: str
    tags: dict[str, Any] = field(default_factory=dict)
    # Runtime stats collected from node_start/node_end events
    runs: list[dict[str, Any]] = field(default_factory=list)


@dataclass
class EdgeRecord:
    """In-memory representation of a declared edge."""

    source_id: str
    target_id: str
    kind: str
    label: str | None = None


@dataclass
class PipelineRun:
    """
    Fully parsed representation of one pipeline run.

    Consumed by the API layer and serialised to JSON for the frontend.
    """

    run_id: str
    pipeline_name: str
    started_at: float          # unix timestamp
    ended_at: float | None
    nodes: list[NodeRecord] = field(default_factory=list)
    edges: list[EdgeRecord] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)
    had_error: bool = False
    # Custom kind → hex color mapping set at pipeline init
    node_kind_colors: dict[str, str] = field(default_factory=dict)


def parse(log_path: Path) -> PipelineRun:
    """
    Parse all events in *log_path* and return a PipelineRun.

    Raises FileNotFoundError if the path doesn't exist.
    Skips malformed lines with a warning rather than hard-failing.
    """
    run: PipelineRun | None = None
    node_index: dict[str, NodeRecord] = {}

    with open(log_path) as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                event = json.loads(line)
            except json.JSONDecodeError as exc:
                warnings.warn(f"Skipping malformed line in {log_path}: {exc}")
                continue

            if run is None:
                if event.get("event") != "pipeline_start":
                    warnings.warn(
                        f"Expected pipeline_start as first event in {log_path}, "
                        f"got {event.get('event')!r}"
                    )
                    continue
                run = PipelineRun(
                    run_id=event["run_id"],
                    pipeline_name=event.get("pipeline_name", ""),
                    started_at=event["ts"],
                    ended_at=None,
                    metadata=event.get("metadata", {}),
                    node_kind_colors=event.get("node_kind_colors", {}),
                )
                continue

            _process_event(run, node_index, event)

    if run is None:
        raise ValueError(f"No pipeline_start event found in {log_path}")

    return run


def quick_scan(log_path: Path) -> tuple[str, dict[str, Any]] | None:
    """Read only the first ``pipeline_start`` event to extract run_id and metadata.

    Much faster than a full parse — used for search filtering.
    Returns ``None`` if the file is empty or malformed.
    """
    try:
        with open(log_path) as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    event = json.loads(line)
                except json.JSONDecodeError:
                    return None
                if event.get("event") == "pipeline_start":
                    return event["run_id"], event.get("metadata", {})
    except OSError:
        return None
    return None


def parse_directory(log_dir: Path) -> list[PipelineRun]:
    """
    Walk *log_dir* recursively and parse every `.flowlog` file found.

    Returns runs sorted by started_at descending (most recent first).
    """
    runs: list[PipelineRun] = []
    for log_path in sorted(log_dir.rglob("*.flowlog")):
        try:
            runs.append(parse(log_path))
        except (FileNotFoundError, ValueError) as exc:
            warnings.warn(f"Skipping {log_path}: {exc}")
            continue
    runs.sort(key=lambda r: r.started_at, reverse=True)
    return runs


def _process_event(
    run: PipelineRun,
    node_index: dict[str, NodeRecord],
    event: dict[str, Any],
) -> None:
    """Dispatch a single log event to the appropriate handler."""
    event_type = event.get("event")

    if event_type == "pipeline_start":
        run.metadata = event.get("metadata", {})
        run.node_kind_colors = event.get("node_kind_colors", {})

    elif event_type == "pipeline_end":
        run.ended_at = event["ts"]
        run.had_error = event.get("had_error", False)

    elif event_type == "node_declared":
        record = NodeRecord(
            node_id=event["node_id"],
            name=event["name"],
            kind=event.get("kind", "custom"),
            tags=event.get("tags", {}),
        )
        run.nodes.append(record)
        node_index[record.node_id] = record

    elif event_type == "edge_declared":
        run.edges.append(
            EdgeRecord(
                source_id=event["source_id"],
                target_id=event["target_id"],
                kind=event.get("edge_kind", "stream"),
                label=event.get("label"),
            )
        )

    elif event_type == "node_start":
        node = node_index.get(event["node_id"])
        if node:
            node.runs.append({"start_ts": event["ts"]})

    elif event_type == "node_end":
        node = node_index.get(event["node_id"])
        if node and node.runs:
            last = node.runs[-1]
            last["end_ts"] = event["ts"]
            last["duration_ms"] = event.get("duration_ms")
            last["is_error"] = event.get("is_error", False)

    elif event_type == "node_error":
        node = node_index.get(event["node_id"])
        if node and node.runs:
            last = node.runs[-1]
            last["end_ts"] = event["ts"]
            last["is_error"] = True
            last["error_type"] = event.get("error_type")
            last["error_message"] = event.get("error_message")
        elif node:
            node.runs.append({
                "start_ts": event["ts"],
                "end_ts": event["ts"],
                "is_error": True,
                "error_type": event.get("error_type"),
                "error_message": event.get("error_message"),
            })

    elif event_type == "metadata":
        node = node_index.get(event["node_id"])
        if node and node.runs:
            last = node.runs[-1]
            last.update(event.get("payload", {}))
        elif node:
            node.runs.append(event.get("payload", {}))


class LogParser:
    """Backwards-compatible façade over the module-level ``parse`` helpers.

    New code should import ``parse`` / ``quick_scan`` / ``parse_directory``
    directly from :mod:`flowstepper.reader.parser`.
    """

    parse = staticmethod(parse)
    quick_scan = staticmethod(quick_scan)
    parse_directory = staticmethod(parse_directory)
