/**
 * Root application shell.
 *
 * Layout:
 *   ┌──────────────────────────────────────────────────┐
 *   │  Header (brand + pipeline/run selectors)         │
 *   ├───────────────┬──────────────────────────────────┤
 *   │  Sidebar      │  DAGGraph (main canvas)          │
 *   │  ─ Pipeline   │                                  │
 *   │    navigator  │                                  │
 *   │  ─ Run/node   │                                  │
 *   │    detail     │                                  │
 *   ├───────────────┴──────────────────────────────────┤
 *   │  Timeline (execution trace, bottom panel)        │
 *   └──────────────────────────────────────────────────┘
 */

import { useState, useEffect, type FC, type CSSProperties } from "react";
import { usePipelineNames, useRunList, useRunDetail } from "@/hooks/usePipeline";
import { useResize } from "@/hooks/useResize";
import DAGGraph from "@/components/DAGGraph";
import Sidebar from "@/components/Sidebar";
import Timeline from "@/components/Timeline";

const SIDEBAR_MIN = 160;
const SIDEBAR_MAX = 520;
const TIMELINE_MIN = 60;
const TIMELINE_MAX = 480;

const App: FC = () => {
  const [selectedPipeline, setSelectedPipeline] = useState<string | null>(null);
  const [selectedRunId, setSelectedRunId] = useState<string | null>(null);
  const [selectedNodeId, setSelectedNodeId] = useState<string | null>(null);
  const [runSearch, setRunSearch] = useState("");
  const [sidebarWidth, setSidebarWidth] = useState(260);
  const [timelineHeight, setTimelineHeight] = useState(130);

  const startSidebarResize = useResize({
    axis: "x",
    min: SIDEBAR_MIN,
    max: SIDEBAR_MAX,
    value: sidebarWidth,
    onChange: setSidebarWidth,
  });

  const startTimelineResize = useResize({
    axis: "y",
    min: TIMELINE_MIN,
    max: TIMELINE_MAX,
    value: timelineHeight,
    onChange: setTimelineHeight,
  });

  const { names } = usePipelineNames();
  const { runs } = useRunList(selectedPipeline ?? "", runSearch || undefined);
  const { run } = useRunDetail(selectedPipeline ?? "", selectedRunId ?? "");

  // Auto-select first pipeline when list loads
  useEffect(() => {
    if (names && names.length > 0 && !selectedPipeline) {
      setSelectedPipeline(names[0]);
    }
  }, [names, selectedPipeline]);

  // Auto-select first run when runs load
  useEffect(() => {
    if (runs && runs.length > 0 && !selectedRunId) {
      setSelectedRunId(runs[0].runId);
    }
  }, [runs, selectedRunId]);

  // Reset run/node selection and run search when pipeline changes
  useEffect(() => {
    setSelectedRunId(null);
    setSelectedNodeId(null);
    setRunSearch("");
  }, [selectedPipeline]);

  // Reset node selection when run changes
  useEffect(() => {
    setSelectedNodeId(null);
  }, [selectedRunId]);

  const selectedNode = run?.nodes.find((n) => n.nodeId === selectedNodeId) ?? null;

  const shellStyle = {
    "--sidebar-w": `${sidebarWidth}px`,
    "--timeline-h": `${timelineHeight}px`,
  } as CSSProperties;

  return (
    <div id="app-shell" style={shellStyle}>
      <header className="app-header">
        <h1>Flowstepper</h1>
      </header>

      <div className="app-main">
        <Sidebar
          pipelines={names ?? []}
          runs={runs}
          selectedPipeline={selectedPipeline}
          selectedRunId={selectedRunId}
          onSelectPipeline={setSelectedPipeline}
          onSelectRun={setSelectedRunId}
          runSearch={runSearch}
          onRunSearchChange={setRunSearch}
          run={run}
          selectedNode={selectedNode}
        />
        <div className="resize-handle resize-handle--h" onMouseDown={startSidebarResize} />

        {run ? (
          <div className="app-canvas">
            <DAGGraph
              nodes={run.nodes}
              edges={run.edges}
              selectedNodeId={selectedNodeId}
              onNodeSelect={setSelectedNodeId}
              kindColors={run.nodeKindColors}
            />
            <div className="resize-handle resize-handle--v" onMouseDown={startTimelineResize} />
            <Timeline
              run={run}
              selectedNodeId={selectedNodeId}
              onNodeSelect={setSelectedNodeId}
            />
          </div>
        ) : (
          <div className="app-empty">
            {selectedPipeline
              ? "Select a run from the sidebar"
              : "Select a pipeline from the sidebar"}
          </div>
        )}
      </div>
    </div>
  );
};

export default App;
