/**
 * Typed API client for the Flowstepper REST API.
 *
 * Used as the fetcher for SWR hooks — all network calls go through here.
 */

import type {
  PipelinesListResponse,
  PipelineRunDetail,
  RunsListResponse,
  PipelineEdge,
  PipelineNode,
  RunSummary,
  NodeRunStats,
} from "@/types/pipeline";

const BASE = "/api/v1";

async function get<T>(path: string): Promise<T> {
  const res = await fetch(path);
  if (!res.ok) throw new Error(`HTTP ${res.status}: ${path}`);
  return res.json() as Promise<T>;
}

type RawNodeRunStats = {
  start_ts?: number;
  end_ts?: number;
  duration_ms?: number;
  item_count?: number;
  is_error?: boolean;
  [key: string]: unknown;
};

type RawPipelineNode = {
  node_id: string;
  name: string;
  kind: PipelineNode["kind"];
  tags: PipelineNode["tags"];
  runs: RawNodeRunStats[];
};

type RawPipelineEdge = {
  source_id: string;
  target_id: string;
  kind: PipelineEdge["kind"];
  label: string | null;
};

type RawRunSummary = {
  run_id: string;
  pipeline_name: string;
  started_at: number;
  ended_at: number | null;
  had_error: boolean;
  node_count: number;
  edge_count: number;
  metadata: Record<string, unknown>;
};

type RawPipelineRunDetail = RawRunSummary & {
  nodes: RawPipelineNode[];
  edges: RawPipelineEdge[];
  metadata: Record<string, unknown>;
  node_kind_colors?: Record<string, string>;
};

function normalizeRunStats(raw: RawNodeRunStats): NodeRunStats {
  const {
    start_ts,
    end_ts,
    duration_ms,
    item_count,
    is_error,
    ...metadata
  } = raw;

  return {
    startedAt: start_ts ?? null,
    endedAt: end_ts ?? null,
    durationMs: duration_ms ?? null,
    itemCount: item_count ?? null,
    isError: is_error ?? false,
    metadata,
  };
}

function normalizeRunSummary(raw: RawRunSummary): RunSummary {
  return {
    runId: raw.run_id,
    pipelineName: raw.pipeline_name,
    startedAt: raw.started_at,
    endedAt: raw.ended_at,
    hadError: raw.had_error,
    nodeCount: raw.node_count,
    edgeCount: raw.edge_count,
    metadata: raw.metadata ?? {},
  };
}

function normalizeNode(raw: RawPipelineNode): PipelineNode {
  return {
    nodeId: raw.node_id,
    name: raw.name,
    kind: raw.kind,
    tags: raw.tags,
    runs: raw.runs.map(normalizeRunStats),
  };
}

function normalizeEdge(raw: RawPipelineEdge): PipelineEdge {
  return {
    sourceId: raw.source_id,
    targetId: raw.target_id,
    kind: raw.kind,
    label: raw.label,
  };
}

function normalizeRunDetail(raw: RawPipelineRunDetail): PipelineRunDetail {
  return {
    ...normalizeRunSummary(raw),
    nodes: raw.nodes.map(normalizeNode),
    edges: raw.edges.map(normalizeEdge),
    metadata: raw.metadata,
    nodeKindColors: raw.node_kind_colors ?? {},
  };
}

export const api = {
  listPipelines(): Promise<PipelinesListResponse> {
    return get<PipelinesListResponse>(`${BASE}/pipelines`);
  },

  async listRuns(pipelineName: string, q?: string): Promise<RunsListResponse> {
    const path = q
      ? `${BASE}/pipelines/${pipelineName}/runs?q=${encodeURIComponent(q)}`
      : `${BASE}/pipelines/${pipelineName}/runs`;
    const data = await get<{ runs: RawRunSummary[] }>(path);
    return { runs: data.runs.map(normalizeRunSummary) };
  },

  async getRun(pipelineName: string, runId: string): Promise<PipelineRunDetail> {
    const data = await get<RawPipelineRunDetail>(
      `${BASE}/pipelines/${pipelineName}/runs/${runId}`
    );
    return normalizeRunDetail(data);
  },

  /**
   * Returns the EventSource URL for live-tailing a run.
   * The caller is responsible for constructing and closing the EventSource.
   */
  runEventsUrl(pipelineName: string, runId: string): string {
    return `${BASE}/pipelines/${pipelineName}/runs/${runId}/stream`;
  },
};
