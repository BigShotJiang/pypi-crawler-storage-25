/**
 * SWR data-fetching hooks for pipeline data.
 */

import useSWR from "swr";
import { api } from "@/api/client";
import type { PipelineRunDetail, RunSummary } from "@/types/pipeline";

/** List all known pipeline names. Refreshes every 5 s (new runs may appear). */
export function usePipelineNames(): {
  names: string[] | undefined;
  isLoading: boolean;
  error: unknown;
} {
  const { data, isLoading, error } = useSWR(
    "pipelines",
    () => api.listPipelines(),
    { refreshInterval: 5000 }
  );
  return { names: data?.pipelines, isLoading, error };
}

/** List run summaries for a pipeline, optionally filtered by run ID or metadata. */
export function useRunList(pipelineName: string, q?: string): {
  runs: RunSummary[] | undefined;
  isLoading: boolean;
  error: unknown;
} {
  const { data, isLoading, error } = useSWR(
    pipelineName ? ["runs", pipelineName, q ?? ""] : null,
    () => api.listRuns(pipelineName, q || undefined)
  );
  return { runs: data?.runs, isLoading, error };
}

/** Full run detail (nodes + edges + stats). */
export function useRunDetail(
  pipelineName: string,
  runId: string
): {
  run: PipelineRunDetail | undefined;
  isLoading: boolean;
  error: unknown;
} {
  const { data, isLoading, error } = useSWR(
    pipelineName && runId ? ["run", pipelineName, runId] : null,
    () => api.getRun(pipelineName, runId)
  );
  return { run: data, isLoading, error };
}
