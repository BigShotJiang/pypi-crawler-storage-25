/**
 * Mouse-drag resize handler for sidebar/timeline panels.
 */

import { useCallback } from "react";

export type ResizeAxis = "x" | "y";

interface UseResizeOptions {
  axis: ResizeAxis;
  min: number;
  max: number;
  value: number;
  onChange: (next: number) => void;
}

export function useResize({ axis, min, max, value, onChange }: UseResizeOptions) {
  return useCallback(
    (e: React.MouseEvent) => {
      e.preventDefault();
      const start = axis === "x" ? e.clientX : e.clientY;
      const startValue = value;
      const cursor = axis === "x" ? "col-resize" : "row-resize";
      document.body.style.userSelect = "none";
      document.body.style.cursor = cursor;

      const onMove = (ev: MouseEvent) => {
        const current = axis === "x" ? ev.clientX : ev.clientY;
        const delta = axis === "x" ? current - start : start - current;
        onChange(Math.max(min, Math.min(max, startValue + delta)));
      };
      const onUp = () => {
        document.body.style.userSelect = "";
        document.body.style.cursor = "";
        document.removeEventListener("mousemove", onMove);
        document.removeEventListener("mouseup", onUp);
      };
      document.addEventListener("mousemove", onMove);
      document.addEventListener("mouseup", onUp);
    },
    [axis, min, max, value, onChange],
  );
}
