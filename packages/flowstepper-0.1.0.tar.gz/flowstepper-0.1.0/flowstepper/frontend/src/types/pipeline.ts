/**
 * TypeScript mirror of the Python SDK type system.
 * These types are the contract between the REST API and the frontend.
 */

/** Free-form node kind label; callers supply the value and the color via
 * `Pipeline(node_kind_colors={...})`. */
export type NodeKind = string;

export type EdgeKind = "stream" | "batch" | "signal";

// -------------------------------------------------------------------------
// Node
// -------------------------------------------------------------------------

export interface NodeRunStats {
  startedAt: number | null; // unix float
  endedAt: number | null;
  durationMs: number | null;
  itemCount: number | null;
  /** True if the node scope raised an exception or the caller flagged
   *  `scope.is_error = True`. */
  isError: boolean;
  metadata: Record<string, unknown>;
}

export interface PipelineNode {
  nodeId: string;
  name: string;
  kind: NodeKind;
  tags: Record<string, unknown>;
  /** Runtime stats — one entry per node_scope execution within this run. */
  runs: NodeRunStats[];
}

// -------------------------------------------------------------------------
// Edge
// -------------------------------------------------------------------------

export interface PipelineEdge {
  sourceId: string;
  targetId: string;
  kind: EdgeKind;
  label: string | null;
}

// -------------------------------------------------------------------------
// Run
// -------------------------------------------------------------------------

export interface RunSummary {
  runId: string;
  pipelineName: string;
  startedAt: number;
  endedAt: number | null;
  hadError: boolean;
  nodeCount: number;
  edgeCount: number;
  metadata: Record<string, unknown>;
}

export interface PipelineRunDetail extends RunSummary {
  nodes: PipelineNode[];
  edges: PipelineEdge[];
  metadata: Record<string, unknown>;
  /** Custom node kind → hex color, set at Pipeline init. */
  nodeKindColors: Record<string, string>;
}

// -------------------------------------------------------------------------
// API response envelopes
// -------------------------------------------------------------------------

export interface PipelinesListResponse {
  pipelines: string[];
}

export interface RunsListResponse {
  runs: RunSummary[];
}
