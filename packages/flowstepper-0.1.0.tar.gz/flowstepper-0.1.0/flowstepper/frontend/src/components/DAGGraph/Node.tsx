/**
 * Individual node shape inside the DAG canvas.
 */

import type { FC } from "react";
import type { PipelineNode } from "@/types/pipeline";

export interface NodeProps {
  node: PipelineNode;
  x: number;
  y: number;
  isSelected: boolean;
  isHighlighted: boolean;
  isDimmed: boolean;
  onClick: (nodeId: string) => void;
  /** Custom kind → color map from the pipeline run (merged with built-in defaults). */
  kindColors?: Record<string, string>;
}

/** Width/height constants shared with the dagre layout step. */
export const NODE_WIDTH = 220;
export const NODE_HEIGHT = 80;

function getKindColor(kind: string, kindColors?: Record<string, string>): string {
  return kindColors?.[kind] ?? "#64748b";
}

function getKindLabel(kind: string): string {
  return kind.toUpperCase().replace(/_/g, "-");
}

function fmtDuration(ms: number | null): string | null {
  if (ms == null) return null;
  if (ms < 1) return `<1ms`;
  if (ms < 1000) return `${Math.round(ms)}ms`;
  return `${(ms / 1000).toFixed(2)}s`;
}

function truncate(s: string, max: number): string {
  return s.length > max ? s.slice(0, max - 1) + "…" : s;
}

const Node: FC<NodeProps> = ({ node, x, y, isSelected, isHighlighted, isDimmed, onClick, kindColors }) => {
  const hadError = node.runs.some((r) => r.isError);
  const lastRun = node.runs[node.runs.length - 1];
  const kindColor = getKindColor(node.kind, kindColors);
  const clipId = `nclip-${node.nodeId.replace(/[^a-zA-Z0-9]/g, "-")}`;

  const duration = lastRun ? fmtDuration(lastRun.durationMs) : null;
  const itemCount = lastRun?.itemCount ?? null;
  const statParts: string[] = [];
  if (duration) statParts.push(duration);
  if (itemCount != null) statParts.push(`${itemCount.toLocaleString()} items`);
  const statsText = statParts.join("  ·  ");

  const dropShadow = isHighlighted
    ? "drop-shadow(0 0 10px rgba(250,204,21,0.5)) drop-shadow(0 2px 8px rgba(0,0,0,0.8))"
    : isSelected
    ? "drop-shadow(0 0 10px rgba(88,166,255,0.5)) drop-shadow(0 2px 8px rgba(0,0,0,0.8))"
    : hadError
    ? "drop-shadow(0 0 8px rgba(248,81,73,0.35)) drop-shadow(0 2px 6px rgba(0,0,0,0.7))"
    : "drop-shadow(0 2px 8px rgba(0,0,0,0.6))";

  const strokeColor = isHighlighted
    ? "rgba(250,204,21,0.9)"
    : isSelected
    ? "rgba(88,166,255,0.9)"
    : hadError
    ? "rgba(248,81,73,0.6)"
    : `${kindColor}30`;

  const strokeWidth = isHighlighted || isSelected || hadError ? 2 : 1;

  return (
    <g
      transform={`translate(${x - NODE_WIDTH / 2},${y - NODE_HEIGHT / 2})`}
      onClick={() => onClick(node.nodeId)}
      style={{ cursor: "pointer", filter: dropShadow, opacity: isDimmed ? 0.25 : 1 }}
    >
      {/* Pulse ring — matches node rect shape */}
      {(hadError || isSelected || isHighlighted) && (
        <rect
          x={-6}
          y={-6}
          width={NODE_WIDTH + 12}
          height={NODE_HEIGHT + 12}
          rx={12}
          fill="none"
          stroke={
            isHighlighted
              ? "rgba(250,204,21,0.7)"
              : isSelected
              ? "rgba(88,166,255,0.7)"
              : "#f85149"
          }
          strokeWidth={1.5}
        >
          <animate attributeName="x" values="-4;-8;-4" dur="1.5s" repeatCount="indefinite" />
          <animate attributeName="y" values="-4;-8;-4" dur="1.5s" repeatCount="indefinite" />
          <animate
            attributeName="width"
            values={`${NODE_WIDTH + 8};${NODE_WIDTH + 16};${NODE_WIDTH + 8}`}
            dur="1.5s"
            repeatCount="indefinite"
          />
          <animate
            attributeName="height"
            values={`${NODE_HEIGHT + 8};${NODE_HEIGHT + 16};${NODE_HEIGHT + 8}`}
            dur="1.5s"
            repeatCount="indefinite"
          />
          <animate attributeName="stroke-opacity" values="0.7;0;0.7" dur="1.5s" repeatCount="indefinite" />
        </rect>
      )}

      <defs>
        <clipPath id={clipId}>
          <rect width={NODE_WIDTH} height={NODE_HEIGHT} rx={8} />
        </clipPath>
      </defs>

      {/* Card background */}
      <rect
        width={NODE_WIDTH}
        height={NODE_HEIGHT}
        rx={8}
        fill="#1c2128"
        stroke={strokeColor}
        strokeWidth={strokeWidth}
      />

      {/* Left accent bar */}
      <rect width={4} height={NODE_HEIGHT} fill={kindColor} clipPath={`url(#${clipId})`} />

      {/* Kind label */}
      <text x={16} y={23} fill={kindColor} fontSize={9} fontWeight="700" letterSpacing="0.6">
        {getKindLabel(node.kind)}
      </text>

      {/* Error badge */}
      {hadError && (
        <>
          <rect
            x={NODE_WIDTH - 54}
            y={11}
            width={44}
            height={16}
            rx={4}
            fill="rgba(248,81,73,0.12)"
            stroke="rgba(248,81,73,0.45)"
            strokeWidth={1}
          />
          <text
            x={NODE_WIDTH - 32}
            y={22.5}
            textAnchor="middle"
            dominantBaseline="middle"
            fill="#f85149"
            fontSize={9}
            fontWeight="600"
          >
            ⚠ error
          </text>
        </>
      )}

      {/* Node name */}
      <text
        x={16}
        y={46}
        fill="rgba(255,255,255,0.92)"
        fontSize={13}
        fontWeight="600"
      >
        {truncate(node.name, 24)}
      </text>

      {/* Stats row */}
      {statsText ? (
        <text x={16} y={65} fill="rgba(255,255,255,0.38)" fontSize={11}>
          {statsText}
        </text>
      ) : (
        <text x={16} y={65} fill="rgba(255,255,255,0.2)" fontSize={11} fontStyle="italic">
          no runs yet
        </text>
      )}
    </g>
  );
};

export default Node;
