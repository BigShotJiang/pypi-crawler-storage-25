/**
 * Directed edge (arrow) between two nodes.
 */

import type { FC } from "react";
import type { PipelineEdge } from "@/types/pipeline";

export interface EdgeProps {
  edge: PipelineEdge;
  /** Waypoints computed by dagre (array of {x, y} objects). */
  points: Array<{ x: number; y: number }>;
}

const Edge: FC<EdgeProps> = ({ edge, points }) => {
  const d =
    points.length < 2
      ? ""
      : (() => {
          const [start, ...rest] = points;
          const end = rest[rest.length - 1];
          const mid = rest.slice(0, -1);
          if (mid.length === 0)
            return `M${start.x},${start.y} L${end.x},${end.y}`;
          const c1 = mid[0];
          const c2 = mid[mid.length - 1];
          return `M${start.x},${start.y} C${c1.x},${c1.y} ${c2.x},${c2.y} ${end.x},${end.y}`;
        })();

  const midPoint = points[Math.floor(points.length / 2)];
  const isDashed = edge.kind === "signal";

  return (
    <g>
      <path
        d={d}
        fill="none"
        stroke="#484f58"
        strokeWidth={1.5}
        strokeOpacity={0.8}
        strokeDasharray={isDashed ? "5,4" : undefined}
        markerEnd="url(#dag-arrow)"
      />
      {edge.label && midPoint && (
        <text
          x={midPoint.x}
          y={midPoint.y - 6}
          textAnchor="middle"
          fill="#6e7681"
          fontSize={10}
        >
          {edge.label}
        </text>
      )}
    </g>
  );
};

export default Edge;
