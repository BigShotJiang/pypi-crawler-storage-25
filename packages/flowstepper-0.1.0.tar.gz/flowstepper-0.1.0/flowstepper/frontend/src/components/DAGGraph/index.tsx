/**
 * DAGGraph — the main pipeline canvas.
 *
 * Renders nodes and edges using D3 + dagre layout.
 */

import { useEffect, useMemo, useRef, useState, type FC } from "react";
import type { PipelineNode, PipelineEdge } from "@/types/pipeline";
import * as dagre from "@dagrejs/dagre";
import * as d3 from "d3";
import Node, { NODE_WIDTH, NODE_HEIGHT } from "./Node";
import Edge from "./Edge";

export interface DAGGraphProps {
  nodes: PipelineNode[];
  edges: PipelineEdge[];
  selectedNodeId?: string | null;
  /** Non-null when a search is active; contains IDs of matching nodes. */
  highlightedNodeIds?: Set<string> | null;
  onNodeSelect?: (nodeId: string) => void;
  /** Custom kind → hex color mapping from the pipeline run. */
  kindColors?: Record<string, string>;
}

const PADDING = 48;

const DAGGraph: FC<DAGGraphProps> = ({
  nodes,
  edges,
  selectedNodeId,
  highlightedNodeIds,
  onNodeSelect,
  kindColors,
}) => {
  const svgRef = useRef<SVGSVGElement>(null);
  const zoomRef = useRef<d3.ZoomBehavior<SVGSVGElement, unknown> | null>(null);
  const [transform, setTransform] = useState("translate(0,0) scale(1)");

  // Build dagre graph — recomputed only when nodes/edges change
  const g = useMemo(() => {
    const graph = new dagre.graphlib.Graph();
    graph.setGraph({ rankdir: "LR", ranksep: 60, nodesep: 24 });
    graph.setDefaultEdgeLabel(() => ({}));
    nodes.forEach((n) =>
      graph.setNode(n.nodeId, { width: NODE_WIDTH, height: NODE_HEIGHT })
    );
    edges.forEach((e) => graph.setEdge(e.sourceId, e.targetId));
    dagre.layout(graph);
    return graph;
  }, [nodes, edges]);

  // Setup zoom once
  useEffect(() => {
    if (!svgRef.current) return;
    const zoom = d3
      .zoom<SVGSVGElement, unknown>()
      .on("zoom", (event) => setTransform(event.transform.toString()));
    zoomRef.current = zoom;
    d3.select(svgRef.current).call(zoom);
  }, []);

  // Center graph whenever the layout changes
  useEffect(() => {
    if (!svgRef.current || !zoomRef.current || nodes.length === 0) return;
    const svgEl = svgRef.current;
    const { width: svgW, height: svgH } = svgEl.getBoundingClientRect();
    const { width: graphW = 0, height: graphH = 0 } = g.graph();
    if (!graphW || !graphH) return;

    const scale = Math.min(
      1,
      (svgW - PADDING * 2) / graphW,
      (svgH - PADDING * 2) / graphH
    );
    const tx = (svgW - graphW * scale) / 2;
    const ty = (svgH - graphH * scale) / 2;

    d3.select(svgEl).call(
      zoomRef.current.transform,
      d3.zoomIdentity.translate(tx, ty).scale(scale)
    );
  }, [g, nodes.length]);

  return (
    <svg ref={svgRef} className="dag-canvas">
      <defs>
        <marker
          id="dag-arrow"
          markerWidth={10}
          markerHeight={7}
          refX={10}
          refY={3.5}
          orient="auto"
        >
          <polygon points="0 0,10 3.5,0 7" fill="#484f58" />
        </marker>
      </defs>
      <g transform={transform}>
        {edges.map((e) => {
          const edgeData = g.edge(e.sourceId, e.targetId);
          return (
            <Edge
              key={`${e.sourceId}-${e.targetId}`}
              edge={e}
              points={edgeData?.points ?? []}
            />
          );
        })}
        {nodes.map((n) => {
          const pos = g.node(n.nodeId);
          const isHighlighted = highlightedNodeIds?.has(n.nodeId) ?? false;
          const isDimmed =
            highlightedNodeIds !== null &&
            highlightedNodeIds !== undefined &&
            !isHighlighted;
          return (
            <Node
              key={n.nodeId}
              node={n}
              x={pos.x}
              y={pos.y}
              isSelected={n.nodeId === selectedNodeId}
              isHighlighted={isHighlighted}
              isDimmed={isDimmed}
              onClick={onNodeSelect ?? (() => {})}
              kindColors={kindColors}
            />
          );
        })}
      </g>
    </svg>
  );
};

export default DAGGraph;
