/**
 * PipelineList — left-sidebar navigator.
 *
 * Renders pipelines as a collapsible tree (like an IDE file explorer).
 * Pipeline names containing "/" become nested folders automatically:
 *   ["sessions/retrieval", "sessions/ranking", "flat_pipe"]
 *   → folder "sessions" > leaves "retrieval", "ranking"
 *   → leaf "flat_pipe"
 */

import { useState, useMemo, useEffect, type FC } from "react";
import type { RunSummary } from "@/types/pipeline";

export interface PipelineListProps {
  pipelines: string[];
  runs: RunSummary[] | undefined;
  selectedPipeline: string | null;
  selectedRunId: string | null;
  onSelectPipeline: (name: string) => void;
  onSelectRun: (runId: string) => void;
  runSearch: string;
  onRunSearchChange: (value: string) => void;
}

// ---------------------------------------------------------------------------
// Tree types & helpers
// ---------------------------------------------------------------------------

type TreeLeaf = { type: "leaf"; path: string };
type TreeFolder = { type: "folder"; children: Record<string, TreeNode> };
type TreeNode = TreeLeaf | TreeFolder;

function buildTree(paths: string[]): Record<string, TreeNode> {
  const root: Record<string, TreeNode> = {};
  for (const path of paths) {
    const parts = path.split("/");
    let current = root;
    for (let i = 0; i < parts.length; i++) {
      const part = parts[i];
      if (i === parts.length - 1) {
        current[part] = { type: "leaf", path };
      } else {
        if (!current[part]) {
          current[part] = { type: "folder", children: {} };
        }
        current = (current[part] as TreeFolder).children;
      }
    }
  }
  return root;
}

function collectFolderPaths(
  tree: Record<string, TreeNode>,
  prefix = ""
): string[] {
  const result: string[] = [];
  for (const [key, node] of Object.entries(tree)) {
    if (node.type === "folder") {
      const fullPath = prefix ? `${prefix}/${key}` : key;
      result.push(fullPath);
      result.push(...collectFolderPaths(node.children, fullPath));
    }
  }
  return result;
}

// ---------------------------------------------------------------------------
// Runs section (shown below selected leaf)
// ---------------------------------------------------------------------------

interface RunsSectionProps {
  runs: RunSummary[] | undefined;
  selectedRunId: string | null;
  onSelectRun: (id: string) => void;
  runSearch: string;
  onRunSearchChange: (v: string) => void;
  marginLeft: number;
}

const RunsSection: FC<RunsSectionProps> = ({
  runs,
  selectedRunId,
  onSelectRun,
  runSearch,
  onRunSearchChange,
  marginLeft,
}) => (
  <div className="pipeline-list__runs-section" style={{ marginLeft }}>
    <div className="pipeline-list__search-wrap">
      <svg
        className="pipeline-list__search-icon"
        viewBox="0 0 16 16"
        fill="none"
        aria-hidden="true"
      >
        <circle cx="6.5" cy="6.5" r="4" stroke="currentColor" strokeWidth="1.5" />
        <path
          d="M10 10l3 3"
          stroke="currentColor"
          strokeWidth="1.5"
          strokeLinecap="round"
        />
      </svg>
      <input
        type="search"
        className="pipeline-list__search"
        placeholder="Filter by ID or param…"
        value={runSearch}
        onChange={(e) => onRunSearchChange(e.target.value)}
      />
      {runSearch && (
        <button
          className="pipeline-list__search-clear"
          onClick={() => onRunSearchChange("")}
          aria-label="Clear search"
        >
          ×
        </button>
      )}
    </div>
    <ul className="pipeline-list__runs">
      {runs?.length ? (
        runs.map((r) => (
          <li key={r.runId}>
            <button
              className={`pipeline-list__run${r.runId === selectedRunId ? " pipeline-list__run--active" : ""}`}
              onClick={() => onSelectRun(r.runId)}
              title={r.runId}
            >
              <span
                className={`pipeline-list__run-dot${r.hadError ? " pipeline-list__run-dot--error" : ""}`}
              />
              <span className="pipeline-list__run-id">{r.runId}</span>
              {r.hadError && (
                <span className="pipeline-list__run-error-badge">err</span>
              )}
            </button>
          </li>
        ))
      ) : (
        <li>
          <span className="pipeline-list__empty">
            {runSearch ? `No runs matching "${runSearch}"` : "No runs"}
          </span>
        </li>
      )}
    </ul>
  </div>
);

// ---------------------------------------------------------------------------
// Recursive tree renderer
// ---------------------------------------------------------------------------

const INDENT = 12; // px per depth level
const BASE_PADDING = 6; // base left padding for depth-0 items

interface TreeLevelProps {
  tree: Record<string, TreeNode>;
  depth: number;
  folderPrefix: string;
  expandedFolders: Set<string>;
  toggleFolder: (path: string) => void;
  runs: RunSummary[] | undefined;
  selectedPipeline: string | null;
  selectedRunId: string | null;
  onSelectPipeline: (name: string) => void;
  onSelectRun: (runId: string) => void;
  runSearch: string;
  onRunSearchChange: (v: string) => void;
}

const TreeLevel: FC<TreeLevelProps> = ({
  tree,
  depth,
  folderPrefix,
  expandedFolders,
  toggleFolder,
  runs,
  selectedPipeline,
  selectedRunId,
  onSelectPipeline,
  onSelectRun,
  runSearch,
  onRunSearchChange,
}) => {
  const paddingLeft = BASE_PADDING + depth * INDENT;

  return (
    <>
      {Object.entries(tree).map(([key, node]) => {
        if (node.type === "leaf") {
          const isSelected = node.path === selectedPipeline;
          return (
            <div key={node.path} className="pipeline-list__group">
              <button
                className={`pipeline-list__pipeline${isSelected ? " pipeline-list__pipeline--active" : ""}`}
                style={{ paddingLeft }}
                onClick={() => onSelectPipeline(node.path)}
              >
                <span
                  className={`pipeline-list__chevron${isSelected ? " pipeline-list__chevron--open" : ""}`}
                >
                  ▶
                </span>
                <span className="pipeline-list__pipeline-name">{key}</span>
              </button>
              {isSelected && (
                <RunsSection
                  runs={runs}
                  selectedRunId={selectedRunId}
                  onSelectRun={onSelectRun}
                  runSearch={runSearch}
                  onRunSearchChange={onRunSearchChange}
                  marginLeft={paddingLeft + 16}
                />
              )}
            </div>
          );
        }

        // folder node
        const fullPath = folderPrefix ? `${folderPrefix}/${key}` : key;
        const isOpen = expandedFolders.has(fullPath);

        return (
          <div key={fullPath} className="pipeline-list__group">
            <button
              className="pipeline-list__folder"
              style={{ paddingLeft }}
              onClick={() => toggleFolder(fullPath)}
            >
              <span
                className={`pipeline-list__chevron${isOpen ? " pipeline-list__chevron--open" : ""}`}
              >
                ▶
              </span>
              <svg
                className="pipeline-list__folder-icon"
                viewBox="0 0 16 16"
                fill="none"
                aria-hidden="true"
              >
                {isOpen ? (
                  <path
                    d="M1.5 6.5h13v6a1 1 0 01-1 1h-11a1 1 0 01-1-1v-6zM1.5 6.5V5.5a1 1 0 011-1h3l1.5 2h-5.5z"
                    stroke="currentColor"
                    strokeWidth="1.2"
                    strokeLinejoin="round"
                  />
                ) : (
                  <path
                    d="M1.5 5.5h13v7a1 1 0 01-1 1h-11a1 1 0 01-1-1v-7zM1.5 5.5V4.5a1 1 0 011-1h3l1.5 2h-5.5z"
                    stroke="currentColor"
                    strokeWidth="1.2"
                    strokeLinejoin="round"
                  />
                )}
              </svg>
              <span className="pipeline-list__folder-name">{key}</span>
            </button>
            {isOpen && (
              <div
                className="pipeline-list__tree-children"
                style={{ marginLeft: paddingLeft + 9 }}
              >
                <TreeLevel
                  tree={(node as TreeFolder).children}
                  depth={depth + 1}
                  folderPrefix={fullPath}
                  expandedFolders={expandedFolders}
                  toggleFolder={toggleFolder}
                  runs={runs}
                  selectedPipeline={selectedPipeline}
                  selectedRunId={selectedRunId}
                  onSelectPipeline={onSelectPipeline}
                  onSelectRun={onSelectRun}
                  runSearch={runSearch}
                  onRunSearchChange={onRunSearchChange}
                />
              </div>
            )}
          </div>
        );
      })}
    </>
  );
};

// ---------------------------------------------------------------------------
// Main component
// ---------------------------------------------------------------------------

const PipelineList: FC<PipelineListProps> = ({
  pipelines,
  runs,
  selectedPipeline,
  selectedRunId,
  onSelectPipeline,
  onSelectRun,
  runSearch,
  onRunSearchChange,
}) => {
  const tree = useMemo(() => buildTree(pipelines), [pipelines]);

  const [expandedFolders, setExpandedFolders] = useState<Set<string>>(() =>
    new Set(collectFolderPaths(buildTree(pipelines)))
  );

  // Auto-expand any folders that appear after the initial render
  useEffect(() => {
    const allFolderPaths = collectFolderPaths(tree);
    setExpandedFolders((prev) => {
      let changed = false;
      const next = new Set(prev);
      for (const p of allFolderPaths) {
        if (!next.has(p)) {
          next.add(p);
          changed = true;
        }
      }
      return changed ? next : prev;
    });
  }, [tree]);

  const toggleFolder = (path: string) => {
    setExpandedFolders((prev) => {
      const next = new Set(prev);
      if (next.has(path)) {
        next.delete(path);
      } else {
        next.add(path);
      }
      return next;
    });
  };

  if (!pipelines.length) {
    return (
      <div className="pipeline-list">
        <p className="pipeline-list__heading">Pipelines</p>
        <p className="pipeline-list__empty">No pipelines found</p>
      </div>
    );
  }

  return (
    <div className="pipeline-list">
      <p className="pipeline-list__heading">Pipelines</p>
      <TreeLevel
        tree={tree}
        depth={0}
        folderPrefix=""
        expandedFolders={expandedFolders}
        toggleFolder={toggleFolder}
        runs={runs}
        selectedPipeline={selectedPipeline}
        selectedRunId={selectedRunId}
        onSelectPipeline={onSelectPipeline}
        onSelectRun={onSelectRun}
        runSearch={runSearch}
        onRunSearchChange={onRunSearchChange}
      />
    </div>
  );
};

export default PipelineList;
