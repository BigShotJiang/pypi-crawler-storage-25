/**
 * Timeline — horizontal Gantt-style execution trace.
 */

import { useRef, useEffect, useState, type FC } from "react";
import type { PipelineRunDetail, NodeRunStats } from "@/types/pipeline";

export interface TimelineProps {
  run: PipelineRunDetail;
  selectedNodeId: string | null;
  onNodeSelect: (nodeId: string) => void;
}

const LABEL_WIDTH = 130;
const ROW_HEIGHT = 26;
const HEADER_HEIGHT = 22;

/** Return a "nice" tick interval (ms) that gives ~5–8 ticks across totalMs. */
function niceInterval(totalMs: number): number {
  const target = totalMs / 6;
  const magnitude = Math.pow(10, Math.floor(Math.log10(target)));
  const residual = target / magnitude;
  let nice: number;
  if (residual < 1.5) nice = 1;
  else if (residual < 3.5) nice = 2;
  else if (residual < 7.5) nice = 5;
  else nice = 10;
  return nice * magnitude;
}

function formatMs(ms: number): string {
  if (ms === 0) return "0";
  if (ms < 1000) return `${Math.round(ms)}ms`;
  return `${(ms / 1000).toFixed(ms % 1000 === 0 ? 0 : 1)}s`;
}

const Timeline: FC<TimelineProps> = ({ run, selectedNodeId, onNodeSelect }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [containerWidth, setContainerWidth] = useState(0);

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const observer = new ResizeObserver((entries) => {
      for (const entry of entries) {
        setContainerWidth(entry.contentRect.width);
      }
    });
    observer.observe(el);
    setContainerWidth(el.clientWidth);
    return () => observer.disconnect();
  }, []);

  const timedRuns = run.nodes.flatMap((n) =>
    n.runs
      .filter(
        (r): r is NodeRunStats & { startedAt: number; endedAt: number } =>
          r.startedAt != null && r.endedAt != null
      )
      .map((r) => ({ node: n, run: r }))
  );

  if (timedRuns.length === 0) return null;

  const minStart = Math.min(...timedRuns.map((t) => t.run.startedAt));
  const maxEnd = Math.max(...timedRuns.map((t) => t.run.endedAt));
  const totalMs = Math.max((maxEnd - minStart) * 1000, 1);

  const canvasWidth = Math.max(containerWidth - LABEL_WIDTH - 1, 200);
  const svgWidth = containerWidth > 0 ? containerWidth - 1 : LABEL_WIDTH + 200;
  const svgHeight = HEADER_HEIGHT + run.nodes.length * ROW_HEIGHT;

  // Compute tick positions
  const interval = niceInterval(totalMs);
  const ticks: number[] = [];
  for (let t = 0; t <= totalMs; t += interval) {
    ticks.push(t);
  }

  return (
    <div className="timeline" ref={containerRef}>
      {containerWidth > 0 && (
        <svg className="timeline__canvas" width={svgWidth} height={svgHeight}>
          {/* ── Ruler header ── */}
          <rect x={0} y={0} width={svgWidth} height={HEADER_HEIGHT} fill="#161b22" />
          <line
            x1={0}
            y1={HEADER_HEIGHT}
            x2={svgWidth}
            y2={HEADER_HEIGHT}
            stroke="#30363d"
            strokeWidth={1}
          />

          {ticks.map((ms) => {
            const x = LABEL_WIDTH + (ms / totalMs) * canvasWidth;
            return (
              <g key={ms}>
                {/* Tick mark in ruler */}
                <line
                  x1={x}
                  y1={HEADER_HEIGHT - 6}
                  x2={x}
                  y2={HEADER_HEIGHT}
                  stroke="#484f58"
                  strokeWidth={1}
                />
                {/* Vertical grid line through bars */}
                <line
                  x1={x}
                  y1={HEADER_HEIGHT}
                  x2={x}
                  y2={svgHeight}
                  stroke="#21262d"
                  strokeWidth={1}
                  strokeDasharray="3 3"
                />
                {/* Time label — skip the "0" label to avoid clipping on the divider */}
                {ms > 0 && (
                  <text
                    x={x + 3}
                    y={HEADER_HEIGHT - 8}
                    fontSize={10}
                    fill="#6e7681"
                    dominantBaseline="auto"
                  >
                    {formatMs(ms)}
                  </text>
                )}
              </g>
            );
          })}

          {/* Divider between labels and bars */}
          <line
            x1={LABEL_WIDTH}
            y1={0}
            x2={LABEL_WIDTH}
            y2={svgHeight}
            stroke="#30363d"
            strokeWidth={1}
          />

          {/* ── Node rows ── */}
          {run.nodes.map((node, i) => {
            const nodeRun = timedRuns.find((t) => t.node.nodeId === node.nodeId);
            const isSelected = node.nodeId === selectedNodeId;
            const rowY = HEADER_HEIGHT + i * ROW_HEIGHT;
            const barX = nodeRun
              ? LABEL_WIDTH + ((nodeRun.run.startedAt - minStart) * 1000 / totalMs) * canvasWidth
              : LABEL_WIDTH;
            const barW = nodeRun
              ? ((nodeRun.run.endedAt - nodeRun.run.startedAt) * 1000 / totalMs) * canvasWidth
              : 0;

            return (
              <g
                key={node.nodeId}
                transform={`translate(0,${rowY})`}
                onClick={() => onNodeSelect(node.nodeId)}
                style={{ cursor: "pointer" }}
              >
                {isSelected && (
                  <rect
                    x={0}
                    y={0}
                    width={svgWidth}
                    height={ROW_HEIGHT}
                    fill="rgba(88,166,255,0.06)"
                  />
                )}
                <text
                  x={LABEL_WIDTH - 10}
                  y={ROW_HEIGHT / 2 + 4}
                  textAnchor="end"
                  fontSize={11}
                  fill={isSelected ? "#58a6ff" : "#8b949e"}
                >
                  {node.name}
                </text>
                {/* Track line */}
                <line
                  x1={LABEL_WIDTH}
                  y1={ROW_HEIGHT / 2}
                  x2={svgWidth}
                  y2={ROW_HEIGHT / 2}
                  stroke="#21262d"
                  strokeWidth={1}
                />
                {nodeRun && (
                  <rect
                    x={barX}
                    y={ROW_HEIGHT / 2 - 8}
                    width={Math.max(barW, 3)}
                    height={16}
                    rx={3}
                    fill={
                      isSelected
                        ? "#58a6ff"
                        : nodeRun.run.isError
                        ? "#f85149"
                        : "#3fb950"
                    }
                    opacity={isSelected ? 1 : 0.85}
                  />
                )}
              </g>
            );
          })}
        </svg>
      )}
    </div>
  );
};

export default Timeline;
