/**
 * Sidebar — left panel containing:
 *  1. PipelineList  – collapsible navigator (pipeline → runs)
 *  2. Detail panel  – run summary or selected-node detail
 */

import type { FC } from "react";
import type { PipelineNode, PipelineRunDetail, RunSummary } from "@/types/pipeline";
import PipelineList from "@/components/PipelineList";

export interface SidebarProps {
  // Pipeline navigation
  pipelines: string[];
  runs: RunSummary[] | undefined;
  selectedPipeline: string | null;
  selectedRunId: string | null;
  onSelectPipeline: (name: string) => void;
  onSelectRun: (runId: string) => void;
  // Run search
  runSearch: string;
  onRunSearchChange: (value: string) => void;
  // Detail panel (only present when a run is loaded)
  run?: PipelineRunDetail;
  selectedNode: PipelineNode | null;
}

function NodeDetailView({ node }: { node: PipelineNode }) {
  return (
    <div className="sidebar__node-detail">
      <h3>{node.name}</h3>
      <p className="sidebar__kind">Kind: {node.kind}</p>
      {Object.keys(node.tags).length > 0 && (
        <table className="sidebar__tags">
          <thead>
            <tr>
              <th>Tag</th>
              <th>Value</th>
            </tr>
          </thead>
          <tbody>
            {Object.entries(node.tags).map(([k, v]) => (
              <tr key={k}>
                <td>{k}</td>
                <td>{String(v)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
      {node.runs.length > 0 && (
        <table className="sidebar__runs">
          <thead>
            <tr>
              <th>Duration</th>
              <th>Items</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {node.runs.map((r, i) => (
              <tr key={i}>
                <td>{r.durationMs != null ? `${r.durationMs.toFixed(1)}ms` : "—"}</td>
                <td>{r.itemCount ?? "—"}</td>
                <td>{r.isError ? "error" : "ok"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

function RunSummaryView({ run }: { run: PipelineRunDetail }) {
  const totalDuration =
    run.endedAt != null
      ? `${((run.endedAt - run.startedAt) * 1000).toFixed(0)}ms`
      : "running...";
  const errorCount = run.nodes.filter((n) =>
    n.runs.some((r) => r.isError)
  ).length;

  return (
    <div className="sidebar__run-summary">
      <h3>Run Summary</h3>
      <dl>
        <dt>Run ID</dt>
        <dd>{run.runId}</dd>
        <dt>Duration</dt>
        <dd>{totalDuration}</dd>
        <dt>Nodes</dt>
        <dd>{run.nodes.length}</dd>
        <dt>Edges</dt>
        <dd>{run.edges.length}</dd>
        <dt>Errors</dt>
        <dd>{errorCount}</dd>
      </dl>
    </div>
  );
}

const Sidebar: FC<SidebarProps> = ({
  pipelines,
  runs,
  selectedPipeline,
  selectedRunId,
  onSelectPipeline,
  onSelectRun,
  runSearch,
  onRunSearchChange,
  run,
  selectedNode,
}) => {
  return (
    <aside className="sidebar">
      <PipelineList
        pipelines={pipelines}
        runs={runs}
        selectedPipeline={selectedPipeline}
        selectedRunId={selectedRunId}
        onSelectPipeline={onSelectPipeline}
        onSelectRun={onSelectRun}
        runSearch={runSearch}
        onRunSearchChange={onRunSearchChange}
      />

      {run && (
        <div className="sidebar__detail">
          {selectedNode ? (
            <NodeDetailView node={selectedNode} />
          ) : (
            <RunSummaryView run={run} />
          )}
        </div>
      )}
    </aside>
  );
};

export default Sidebar;
