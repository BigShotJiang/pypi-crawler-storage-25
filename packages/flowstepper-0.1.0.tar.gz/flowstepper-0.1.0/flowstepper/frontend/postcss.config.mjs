export default { plugins: [] };
