import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import path from "path";

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: { "@": path.resolve(__dirname, "./src") },
  },
  server: {
    // During development, proxy API calls to the Python server.
    proxy: {
      "/api": {
        target: "http://127.0.0.1:6006",
        changeOrigin: true,
      },
    },
  },
  build: {
    // Output goes into flowstepper/server/static/ via scripts/build_frontend.sh
    outDir: "../server/static",
    emptyOutDir: true,
  },
});
