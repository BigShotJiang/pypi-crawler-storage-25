"""
CLI entry point.

    $ flowstepper --logdir ./logs --port 6006 [--reload]

Mirrors the TensorBoard UX: point at a log directory, get a local server.
"""

import click


@click.command()
@click.option(
    "--logdir",
    required=True,
    type=click.Path(exists=True, file_okay=False),
    help="Directory containing .flowlog files produced by the SDK.",
)
@click.option("--host", default="127.0.0.1", show_default=True, help="Bind host.")
@click.option("--port", default=6006, show_default=True, help="Bind port.")
@click.option("--reload", is_flag=True, default=False, help="Hot-reload on log changes.")
def main(logdir: str, host: str, port: int, reload: bool) -> None:
    """Start the Flowstepper visualization server."""
    from pathlib import Path

    import uvicorn

    from flowstepper.server.app import create_app

    app = create_app(log_dir=Path(logdir))
    uvicorn.run(app, host=host, port=port, reload=reload)
