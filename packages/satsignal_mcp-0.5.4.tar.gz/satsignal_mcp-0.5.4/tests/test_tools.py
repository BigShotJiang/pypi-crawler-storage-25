"""Tool-handler tests.

httpx is mocked out — these are unit tests of the MCP layer's behavior
(dry-run paths, error mapping, sha computation, response shape), not of
the live Satsignal API.
"""

import asyncio
import hashlib
import json
import tempfile
import unittest
import unittest.mock as mock
import zipfile
from pathlib import Path

import os

from satsignal_mcp.api import DEFAULT_API_BASE, AnchorResult, ApiError
from satsignal_mcp.server import (
    FolderAliasConflict,
    _env_default_folder,
    _env_default_matter,
    _handle_anchor_file,
    _handle_anchor_json,
    _handle_anchor_text,
    _handle_chain_confirm_bundle,
    _handle_lookup_hash,
    _handle_verify_bundle_blocked,
    _handle_verify_file_against_bundle,
    _resolve_folder,
    _tool_definitions,
)


def _run(coro):
    return asyncio.run(coro)


def _parse(response) -> dict:
    """Helper: pull the JSON payload out of a tool response.

    v0.5.0 changed handler return type from `list[TextContent]` to
    `CallToolResult` (closes the missing-isError finding). Accept both
    shapes so per-handler assertions remain spelled the same way; an
    explicit `CallToolResultShapeTest` pins the new wrapper itself.
    """
    content = response.content if hasattr(response, "content") else response
    assert len(content) == 1
    return json.loads(content[0].text)


def _stub_anchor_result(*, sha: str, matter: str = "inbox",
                        duplicate: bool = False) -> AnchorResult:
    return AnchorResult(
        bundle_id="bundle_test_001",
        txid="t" * 64,
        mode="standard",
        matter_slug=matter,
        receipt_url=f"https://example.com/w/ws/m/{matter}/r/bundle_test_001",
        bundle_url="https://example.com/bundle/bundle_test_001.mbnt",
        duplicate=duplicate,
        raw={},
    )


class AnchorFileDryRunTest(unittest.TestCase):

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = Path(self.tmp.name) / "doc.txt"
        self.path.write_bytes(b"hello world")
        self.expected_sha = hashlib.sha256(b"hello world").hexdigest()

    def tearDown(self):
        self.tmp.cleanup()

    def test_dry_run_computes_sha_without_calling_api(self):
        api = mock.AsyncMock()
        result = _run(_handle_anchor_file(
            {"path": str(self.path), "dry_run": True}, api,
        ))
        payload = _parse(result)
        self.assertFalse(payload["anchored"])
        self.assertTrue(payload["dry_run"])
        self.assertEqual(payload["sha256_hex"], self.expected_sha)
        self.assertEqual(payload["file_size"], 11)
        self.assertEqual(payload["filename"], "doc.txt")
        api.anchor_standard.assert_not_called()

    def test_real_anchor_passes_correct_payload(self):
        api = mock.AsyncMock()
        api.anchor_standard.return_value = _stub_anchor_result(
            sha=self.expected_sha,
        )
        result = _run(_handle_anchor_file(
            {"path": str(self.path), "matter": "case42",
             "label": "evidence A"}, api,
        ))
        payload = _parse(result)
        self.assertTrue(payload["anchored"])
        self.assertEqual(payload["sha256_hex"], self.expected_sha)
        self.assertEqual(payload["bundle_id"], "bundle_test_001")
        api.anchor_standard.assert_called_once_with(
            matter_slug="case42",
            sha256_hex=self.expected_sha,
            file_size=11,
            label="evidence A",
            filename="doc.txt",
            force_new=False,
        )

    def test_missing_path_returns_error(self):
        api = mock.AsyncMock()
        result = _run(_handle_anchor_file({}, api))
        payload = _parse(result)
        self.assertEqual(payload["error"], "missing_path")
        api.anchor_standard.assert_not_called()

    def test_nonexistent_path_returns_error(self):
        api = mock.AsyncMock()
        result = _run(_handle_anchor_file(
            {"path": "/no/such/file.txt"}, api,
        ))
        payload = _parse(result)
        self.assertEqual(payload["error"], "not_a_file")
        api.anchor_standard.assert_not_called()

    def test_api_error_surfaces_code_and_status(self):
        api = mock.AsyncMock()
        api.anchor_standard.side_effect = ApiError(
            401, "missing_api_key", "set SATSIGNAL_API_KEY",
        )
        result = _run(_handle_anchor_file({"path": str(self.path)}, api))
        payload = _parse(result)
        self.assertEqual(payload["error"], "missing_api_key")
        self.assertEqual(payload["status"], 401)


class AnchorTextTest(unittest.TestCase):

    def test_dry_run_sha_matches_utf8_bytes(self):
        api = mock.AsyncMock()
        result = _run(_handle_anchor_text(
            {"text": "café", "dry_run": True}, api,
        ))
        payload = _parse(result)
        self.assertEqual(
            payload["sha256_hex"],
            hashlib.sha256("café".encode("utf-8")).hexdigest(),
        )
        self.assertEqual(payload["byte_length"], len("café".encode("utf-8")))
        api.anchor_standard.assert_not_called()

    def test_real_anchor_sends_correct_size(self):
        api = mock.AsyncMock()
        api.anchor_standard.return_value = _stub_anchor_result(sha="a" * 64)
        _run(_handle_anchor_text({"text": "hello"}, api))
        kwargs = api.anchor_standard.call_args.kwargs
        self.assertEqual(kwargs["file_size"], 5)
        self.assertEqual(
            kwargs["sha256_hex"],
            hashlib.sha256(b"hello").hexdigest(),
        )
        self.assertNotIn("filename", kwargs)


class AnchorJsonTest(unittest.TestCase):

    def test_dry_run_returns_canonical_bytes(self):
        api = mock.AsyncMock()
        result = _run(_handle_anchor_json(
            {"data": {"b": 1, "a": 2}, "dry_run": True}, api,
        ))
        payload = _parse(result)
        # Sorted keys: a before b.
        self.assertEqual(payload["canonical_bytes"], '{"a":2,"b":1}')
        self.assertEqual(payload["byte_length"], 13)
        api.anchor_standard.assert_not_called()

    def test_real_anchor_includes_canonical_bytes_in_response(self):
        api = mock.AsyncMock()
        api.anchor_standard.return_value = _stub_anchor_result(sha="a" * 64)
        result = _run(_handle_anchor_json(
            {"data": {"hello": "world"}}, api,
        ))
        payload = _parse(result)
        self.assertEqual(payload["canonical_bytes"], '{"hello":"world"}')
        self.assertTrue(payload["anchored"])

    def test_non_finite_float_rejected(self):
        api = mock.AsyncMock()
        result = _run(_handle_anchor_json(
            {"data": {"x": float("nan")}}, api,
        ))
        payload = _parse(result)
        self.assertEqual(payload["error"], "canonicalization_failed")
        api.anchor_standard.assert_not_called()

    def test_missing_data_returns_error(self):
        api = mock.AsyncMock()
        result = _run(_handle_anchor_json({}, api))
        payload = _parse(result)
        self.assertEqual(payload["error"], "missing_data")


class LookupHashTest(unittest.TestCase):

    def test_hit_maps_to_hit_true(self):
        api = mock.AsyncMock()
        api.lookup_hash.return_value = {
            "bundle_id": "b1", "txid": "t" * 64,
            "created_utc": "2026-05-14T00:00:00Z",
        }
        result = _run(_handle_lookup_hash(
            {"sha256_hex": "a" * 64}, api,
        ))
        payload = _parse(result)
        self.assertTrue(payload["hit"])
        self.assertEqual(payload["bundle_id"], "b1")
        self.assertEqual(payload["txid"], "t" * 64)

    def test_miss_maps_to_hit_false(self):
        api = mock.AsyncMock()
        api.lookup_hash.return_value = {
            "miss": True, "reason": "sha_not_indexed_as_file_hash",
        }
        result = _run(_handle_lookup_hash(
            {"sha256_hex": "a" * 64}, api,
        ))
        payload = _parse(result)
        self.assertFalse(payload["hit"])
        self.assertEqual(payload["reason"], "sha_not_indexed_as_file_hash")


class ChainConfirmBundleTest(unittest.TestCase):
    """Tests for chain_confirm_bundle's core semantics.

    Historically this class was named VerifyBundleTest (pre-v0.3) and
    covered the verify_bundle handler; v0.3 renamed the handler and v0.4
    fail-closes the verify_bundle alias entirely. The body still tests
    the chain-confirm semantics it always did, just under a name that
    matches the canonical handler.
    """

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.bundle = Path(self.tmp.name) / "test.mbnt"

    def tearDown(self):
        self.tmp.cleanup()

    def _write_bundle(self, manifest: dict, canonical: dict | None = None
                       ) -> None:
        if canonical is None:
            # Default canonical has the document_sha256 the handler
            # actually reads (manifest only carries the 40-hex
            # doc_hash_expected; the 64-hex file sha lives in canonical).
            canonical = {"subject": {"document_sha256": "a" * 64}}
        with zipfile.ZipFile(self.bundle, "w") as zf:
            zf.writestr("manifest.json", json.dumps(manifest))
            zf.writestr("canonical.json", json.dumps(canonical))

    def test_verified_true_when_txid_matches(self):
        self._write_bundle({"txid": "t" * 64})
        api = mock.AsyncMock()
        api.lookup_hash.return_value = {
            "bundle_id": "b1", "txid": "t" * 64, "created_utc": "x",
        }
        result = _run(_handle_chain_confirm_bundle(
            {"path": str(self.bundle)}, api,
        ))
        payload = _parse(result)
        self.assertTrue(payload["verified"])

    def test_verified_false_on_txid_mismatch(self):
        """Locally-fabricated bundle: real sha in canonical but bogus
        claimed txid in manifest. Must report verified=false with
        txid_mismatch."""
        self._write_bundle({"txid": "f" * 64})  # forged
        api = mock.AsyncMock()
        api.lookup_hash.return_value = {
            "bundle_id": "b1", "txid": "t" * 64,  # real
            "created_utc": "x",
        }
        result = _run(_handle_chain_confirm_bundle(
            {"path": str(self.bundle)}, api,
        ))
        payload = _parse(result)
        self.assertFalse(payload["verified"])
        self.assertEqual(payload["reason"], "txid_mismatch")

    def test_verified_false_on_lookup_miss(self):
        self._write_bundle({"txid": "t" * 64})
        api = mock.AsyncMock()
        api.lookup_hash.return_value = {"miss": True, "reason": "x"}
        result = _run(_handle_chain_confirm_bundle(
            {"path": str(self.bundle)}, api,
        ))
        payload = _parse(result)
        self.assertFalse(payload["verified"])
        self.assertEqual(payload["reason"], "sha_not_indexed")

    def test_sealed_bundle_no_document_sha_returns_error(self):
        """Sealed/manifest bundles don't put document_sha256 in
        canonical.subject; verify should explain rather than silently
        fail (or worse, lookup the wrong field and false-miss)."""
        self._write_bundle(
            {"mode": "sealed", "txid": "t" * 64},
            canonical={"subject": {"byte_exact_commitment": "c" * 64}},
        )
        api = mock.AsyncMock()
        result = _run(_handle_chain_confirm_bundle(
            {"path": str(self.bundle)}, api,
        ))
        payload = _parse(result)
        self.assertEqual(payload["error"], "no_file_sha")
        self.assertEqual(payload["manifest_mode"], "sealed")
        api.lookup_hash.assert_not_called()

    def test_lookup_called_with_canonical_sha_not_manifest_hash(self):
        """Regression: pre-fix the handler read manifest.doc_hash_expected
        (40-hex truncated). The real file sha (64-hex) is in
        canonical.subject.document_sha256, and that's what lookup_hash
        indexes. Confirm we pass the canonical one."""
        self._write_bundle(
            {
                "txid": "t" * 64,
                "doc_hash_expected": "ab" * 20,  # 40-hex; must NOT be sent
            },
            canonical={"subject": {"document_sha256": "9" * 64}},
        )
        api = mock.AsyncMock()
        api.lookup_hash.return_value = {
            "bundle_id": "b1", "txid": "t" * 64, "created_utc": "x",
        }
        _run(_handle_chain_confirm_bundle(
            {"path": str(self.bundle)}, api,
        ))
        api.lookup_hash.assert_called_once_with("9" * 64)


class VerifyBundleBlockedTest(unittest.TestCase):
    """v0.4 fail-close: verify_bundle returns structured error on every call.

    Closes the v0.2 false-PASS class — a tampered original used to pass
    verified=true via the chain-only handler under a name implying full
    verify. The alias is still listed (callers pinned by name don't get
    unknown_tool), but the handler returns deprecated_tool_blocked.
    """

    def test_returns_deprecated_tool_blocked_error(self):
        api = mock.AsyncMock()
        result = _run(_handle_verify_bundle_blocked(
            {"path": "/tmp/anything"}, api,
        ))
        payload = _parse(result)
        self.assertEqual(payload["error"], "deprecated_tool_blocked")
        self.assertEqual(payload["deprecated_tool"], "verify_bundle")
        self.assertEqual(payload["full_verify_tool"],
                         "verify_file_against_bundle")
        self.assertEqual(payload["chain_only_tool"],
                         "chain_confirm_bundle")
        self.assertEqual(payload["removal_version"], "0.5")
        api.lookup_hash.assert_not_called()

    def test_does_not_open_bundle_file(self):
        # Even with a nonexistent path, no I/O happens — the redirect
        # is structural, not contingent on bundle contents.
        api = mock.AsyncMock()
        result = _run(_handle_verify_bundle_blocked(
            {"path": "/nonexistent/path"}, api,
        ))
        payload = _parse(result)
        self.assertEqual(payload["error"], "deprecated_tool_blocked")

    def test_handlers_dict_routes_verify_bundle_to_blocked(self):
        from satsignal_mcp.server import _HANDLERS
        self.assertIs(_HANDLERS["verify_bundle"],
                      _handle_verify_bundle_blocked)

    def test_tool_still_listed_with_fail_closed_description(self):
        from satsignal_mcp.server import _tool_definitions
        tools = {t.name: t for t in _tool_definitions()}
        self.assertIn("verify_bundle", tools)
        desc = tools["verify_bundle"].description
        self.assertIn("DEPRECATED", desc)
        self.assertIn("FAIL-CLOSED", desc)
        self.assertIn("deprecated_tool_blocked", desc)


class ToolDefinitionTest(unittest.TestCase):

    def test_seven_tools_declared(self):
        # v0.3 split: chain_confirm_bundle is the new canonical name,
        # verify_file_against_bundle is the new full-verify tool, and
        # verify_bundle remains as a deprecated alias.
        tools = _tool_definitions()
        self.assertEqual(
            [t.name for t in tools],
            ["anchor_file", "anchor_text", "anchor_json",
             "lookup_hash",
             "chain_confirm_bundle",
             "verify_file_against_bundle",
             "verify_bundle"],
        )

    def test_anchor_tools_have_dry_run_with_default_false(self):
        for tool in _tool_definitions():
            if not tool.name.startswith("anchor_"):
                continue
            props = tool.inputSchema["properties"]
            self.assertIn("dry_run", props)
            self.assertFalse(props["dry_run"]["default"])

    def test_anchor_tools_expose_folder_and_legacy_matter(self):
        """Additive alias: every anchor tool must declare BOTH the new
        `folder` property and the frozen legacy `matter` property, with
        `matter` typed identically (string) so existing callers keep
        validating."""
        for tool in _tool_definitions():
            if not tool.name.startswith("anchor_"):
                continue
            props = tool.inputSchema["properties"]
            self.assertIn("folder", props, tool.name)
            self.assertIn("matter", props, tool.name)
            self.assertEqual(props["folder"]["type"], "string")
            self.assertEqual(props["matter"]["type"], "string")
            # Neither is required: folder/matter stay optional (env
            # default), exactly as `matter` was pre-alias.
            self.assertNotIn("folder", tool.inputSchema.get("required", []))
            self.assertNotIn("matter", tool.inputSchema.get("required", []))


class DefaultApiBaseTest(unittest.TestCase):
    """v0.1.0 shipped with DEFAULT_API_BASE=https://proof.satsignal.cloud,
    which silently 404'd every anchor_* call (customer routes only
    dispatch on app.* per is_app_host). Pin the correct host so a
    future drift fails this test, not the user's first anchor."""

    def test_default_points_at_app_host(self):
        self.assertEqual(DEFAULT_API_BASE, "https://app.satsignal.cloud")


class ResolveFolderTest(unittest.TestCase):
    """Unit tests for the folder/matter alias resolver + conflict rule.

    Run with no SATSIGNAL_* env so the default path is deterministic.
    """

    def setUp(self):
        self._saved = {
            k: os.environ.pop(k, None)
            for k in ("SATSIGNAL_FOLDER", "SATSIGNAL_MATTER")
        }

    def tearDown(self):
        for k, v in self._saved.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v

    # ---- legacy `matter` property: byte-identical behavior -----------

    def test_legacy_matter_only_used_as_before(self):
        self.assertEqual(_resolve_folder({"matter": "case-legacy"}),
                          "case-legacy")

    def test_no_args_falls_back_to_inbox_default(self):
        # Pre-alias behavior: `args.get("matter") or default` -> 'inbox'.
        self.assertEqual(_resolve_folder({}), "inbox")

    def test_whitespace_matter_treated_as_absent(self):
        # Pre-alias: ("   ".strip() or "inbox") -> "inbox".
        self.assertEqual(_resolve_folder({"matter": "   "}), "inbox")

    def test_matter_is_stripped(self):
        self.assertEqual(_resolve_folder({"matter": "  c1  "}), "c1")

    # ---- new `folder` property ---------------------------------------

    def test_folder_only(self):
        self.assertEqual(_resolve_folder({"folder": "proj-x"}), "proj-x")

    def test_folder_is_stripped(self):
        self.assertEqual(_resolve_folder({"folder": "  proj-x "}), "proj-x")

    # ---- precedence: folder preferred over matter --------------------

    def test_equal_folder_and_matter_accepted(self):
        self.assertEqual(
            _resolve_folder({"folder": "same", "matter": "same"}), "same",
        )

    def test_folder_preferred_when_matter_empty(self):
        self.assertEqual(
            _resolve_folder({"folder": "f", "matter": ""}), "f",
        )

    def test_matter_used_when_folder_empty(self):
        self.assertEqual(
            _resolve_folder({"folder": "  ", "matter": "m"}), "m",
        )

    # ---- conflict rule ----------------------------------------------

    def test_conflicting_values_raise(self):
        with self.assertRaises(FolderAliasConflict) as ctx:
            _resolve_folder({"folder": "a", "matter": "b"})
        msg = str(ctx.exception)
        self.assertIn("aliases", msg)
        self.assertIn("send only folder", msg)


class FolderEnvDefaultTest(unittest.TestCase):
    """SATSIGNAL_FOLDER is the public env var; SATSIGNAL_MATTER is the
    frozen legacy alias. Legacy SATSIGNAL_MATTER-only setups MUST stay
    byte-identical to pre-alias behavior."""

    def setUp(self):
        self._saved = {
            k: os.environ.pop(k, None)
            for k in ("SATSIGNAL_FOLDER", "SATSIGNAL_MATTER")
        }

    def tearDown(self):
        for k, v in self._saved.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v

    def test_default_inbox_when_unset(self):
        self.assertEqual(_env_default_folder(), "inbox")

    def test_legacy_satsignal_matter_still_honored(self):
        os.environ["SATSIGNAL_MATTER"] = "legacy-env"
        self.assertEqual(_env_default_folder(), "legacy-env")
        # The frozen public name is still importable and identical.
        self.assertIs(_env_default_matter, _env_default_folder)
        self.assertEqual(_env_default_matter(), "legacy-env")

    def test_satsignal_folder_used(self):
        os.environ["SATSIGNAL_FOLDER"] = "new-env"
        self.assertEqual(_env_default_folder(), "new-env")

    def test_satsignal_folder_wins_over_legacy_matter(self):
        os.environ["SATSIGNAL_FOLDER"] = "new-env"
        os.environ["SATSIGNAL_MATTER"] = "legacy-env"
        self.assertEqual(_env_default_folder(), "new-env")

    def test_blank_satsignal_folder_falls_back_to_legacy(self):
        os.environ["SATSIGNAL_FOLDER"] = "   "
        os.environ["SATSIGNAL_MATTER"] = "legacy-env"
        self.assertEqual(_env_default_folder(), "legacy-env")


class AnchorHandlerAliasWireTest(unittest.TestCase):
    """End-to-end through the anchor handlers: confirm the resolved
    folder is sent to the API as the FROZEN `matter_slug` wire kwarg
    (never `folder_slug`), legacy `matter` still works, and conflicts
    short-circuit before any network call."""

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = Path(self.tmp.name) / "doc.txt"
        self.path.write_bytes(b"hello world")
        self.sha = hashlib.sha256(b"hello world").hexdigest()
        self._saved = {
            k: os.environ.pop(k, None)
            for k in ("SATSIGNAL_FOLDER", "SATSIGNAL_MATTER")
        }

    def tearDown(self):
        for k, v in self._saved.items():
            if v is not None:
                os.environ[k] = v
        self.tmp.cleanup()

    def _api(self):
        api = mock.AsyncMock()
        api.anchor_standard.return_value = _stub_anchor_result(sha=self.sha)
        return api

    def test_legacy_matter_arg_sends_matter_slug_unchanged(self):
        api = self._api()
        _run(_handle_anchor_file(
            {"path": str(self.path), "matter": "case-legacy"}, api,
        ))
        kwargs = api.anchor_standard.call_args.kwargs
        self.assertEqual(kwargs["matter_slug"], "case-legacy")
        self.assertNotIn("folder_slug", kwargs)
        self.assertNotIn("folder", kwargs)

    def test_new_folder_arg_folds_into_matter_slug_wire_field(self):
        api = self._api()
        _run(_handle_anchor_text(
            {"text": "hi", "folder": "proj-x"}, api,
        ))
        kwargs = api.anchor_standard.call_args.kwargs
        self.assertEqual(kwargs["matter_slug"], "proj-x")
        self.assertNotIn("folder_slug", kwargs)

    def test_folder_preferred_over_matter_on_wire(self):
        api = self._api()
        _run(_handle_anchor_json(
            {"data": {"k": 1}, "folder": "f", "matter": ""}, api,
        ))
        kwargs = api.anchor_standard.call_args.kwargs
        self.assertEqual(kwargs["matter_slug"], "f")

    def test_conflict_returns_error_and_no_api_call(self):
        api = self._api()
        result = _run(_handle_anchor_file(
            {"path": str(self.path), "folder": "a", "matter": "b"}, api,
        ))
        payload = _parse(result)
        self.assertEqual(payload["error"], "conflicting_alias")
        self.assertIn("send only folder", payload["message"])
        api.anchor_standard.assert_not_called()

    def test_conflict_on_text_and_json_too(self):
        for handler, extra in (
            (_handle_anchor_text, {"text": "x"}),
            (_handle_anchor_json, {"data": {"a": 1}}),
        ):
            api = self._api()
            result = _run(handler(
                {**extra, "folder": "a", "matter": "b"}, api,
            ))
            payload = _parse(result)
            self.assertEqual(payload["error"], "conflicting_alias")
            api.anchor_standard.assert_not_called()

    def test_legacy_matter_dry_run_payload_unchanged(self):
        """Regression guard: dry-run still reports `matter_slug` and the
        legacy `matter` arg drives it byte-identically."""
        api = mock.AsyncMock()
        result = _run(_handle_anchor_file(
            {"path": str(self.path), "matter": "case42", "dry_run": True},
            api,
        ))
        payload = _parse(result)
        self.assertEqual(payload["matter_slug"], "case42")
        api.anchor_standard.assert_not_called()

    def test_folder_drives_dry_run_matter_slug(self):
        api = mock.AsyncMock()
        result = _run(_handle_anchor_file(
            {"path": str(self.path), "folder": "case42", "dry_run": True},
            api,
        ))
        payload = _parse(result)
        self.assertEqual(payload["matter_slug"], "case42")
        api.anchor_standard.assert_not_called()


class ChainConfirmBundleAliasTest(unittest.TestCase):
    """v0.3: chain_confirm_bundle is the canonical name and accepts both
    the new `bundle_path` arg and the legacy `path` alias, refusing on
    differing non-empty values. (v0.4 separately fail-closed the
    verify_bundle name so it no longer routes here — see
    VerifyBundleBlockedTest.)"""

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.bundle = Path(self.tmp.name) / "test.mbnt"
        with zipfile.ZipFile(self.bundle, "w") as zf:
            zf.writestr("manifest.json", json.dumps({"txid": "t" * 64}))
            zf.writestr(
                "canonical.json",
                json.dumps({"subject": {"document_sha256": "a" * 64}}),
            )

    def tearDown(self):
        self.tmp.cleanup()

    def _api(self):
        api = mock.AsyncMock()
        api.lookup_hash.return_value = {
            "bundle_id": "b1", "txid": "t" * 64, "created_utc": "x",
        }
        return api

    def test_bundle_path_arg_works(self):
        result = _run(_handle_chain_confirm_bundle(
            {"bundle_path": str(self.bundle)}, self._api(),
        ))
        self.assertTrue(_parse(result)["verified"])

    def test_legacy_path_arg_still_works(self):
        result = _run(_handle_chain_confirm_bundle(
            {"path": str(self.bundle)}, self._api(),
        ))
        self.assertTrue(_parse(result)["verified"])

    def test_both_args_same_value_accepted(self):
        result = _run(_handle_chain_confirm_bundle(
            {"bundle_path": str(self.bundle), "path": str(self.bundle)},
            self._api(),
        ))
        self.assertTrue(_parse(result)["verified"])

    def test_conflicting_alias_rejected(self):
        api = self._api()
        result = _run(_handle_chain_confirm_bundle(
            {"bundle_path": str(self.bundle), "path": "/some/other.mbnt"},
            api,
        ))
        payload = _parse(result)
        self.assertEqual(payload["error"], "conflicting_alias")
        api.lookup_hash.assert_not_called()

    def test_neither_arg_rejected(self):
        api = self._api()
        result = _run(_handle_chain_confirm_bundle({}, api))
        payload = _parse(result)
        self.assertEqual(payload["error"], "missing_bundle_path")
        api.lookup_hash.assert_not_called()

    def test_verify_bundle_no_longer_dispatches_to_chain_confirm(self):
        """v0.4 fail-close: the deprecated verify_bundle name must NOT
        route to chain_confirm_bundle anymore — that's the v0.2
        false-PASS class. It now routes to the blocked handler that
        returns deprecated_tool_blocked. See VerifyBundleBlockedTest
        for the full contract."""
        from satsignal_mcp.server import _HANDLERS
        self.assertIsNot(_HANDLERS["verify_bundle"],
                         _HANDLERS["chain_confirm_bundle"])
        self.assertIs(_HANDLERS["verify_bundle"],
                      _handle_verify_bundle_blocked)


class VerifyFileAgainstBundleTest(unittest.TestCase):
    """v0.3 new tool: re-hashes the original file, runs crypto + chain
    via satsignal-cli's verify_file. Tests mock that function so we
    don't hit the network."""

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.file = Path(self.tmp.name) / "doc.txt"
        self.file.write_text("hello")
        self.bundle = Path(self.tmp.name) / "doc.mbnt"
        with zipfile.ZipFile(self.bundle, "w") as zf:
            zf.writestr("manifest.json", json.dumps({"txid": "t" * 64}))
            zf.writestr(
                "canonical.json",
                json.dumps({"subject": {"document_sha256": "a" * 64}}),
            )

    def tearDown(self):
        self.tmp.cleanup()

    def _mock_result(self, cls, **kw):
        from satsignal.verify import VerifyClass
        r = mock.Mock()
        r.cls = cls if isinstance(cls, VerifyClass) else VerifyClass(cls)
        r.sha256_hex = kw.get("sha256_hex")
        r.txid = kw.get("txid")
        r.confirmations = kw.get("confirmations")
        r.message = kw.get("message")
        return r

    def test_verified_true_on_verified_class(self):
        from satsignal.verify import VerifyClass
        with mock.patch("satsignal_mcp.server.verify_file") as vf:
            vf.return_value = self._mock_result(
                VerifyClass.VERIFIED,
                sha256_hex="a" * 64, txid="t" * 64, confirmations=3,
            )
            result = _run(_handle_verify_file_against_bundle(
                {"file_path": str(self.file),
                 "bundle_path": str(self.bundle)},
                mock.AsyncMock(),
            ))
        payload = _parse(result)
        self.assertTrue(payload["verified"])
        self.assertEqual(payload["verify_class"], "verified")
        self.assertEqual(payload["confirmations"], 3)

    def test_verified_true_on_pending_class(self):
        """Crypto + chain both passed, just 0 confirmations — still
        verified=true; confirmations field surfaces maturity."""
        from satsignal.verify import VerifyClass
        with mock.patch("satsignal_mcp.server.verify_file") as vf:
            vf.return_value = self._mock_result(
                VerifyClass.PENDING,
                sha256_hex="a" * 64, txid="t" * 64, confirmations=0,
            )
            result = _run(_handle_verify_file_against_bundle(
                {"file_path": str(self.file),
                 "bundle_path": str(self.bundle)},
                mock.AsyncMock(),
            ))
        payload = _parse(result)
        self.assertTrue(payload["verified"])
        self.assertEqual(payload["confirmations"], 0)

    def test_verified_false_on_crypto_mismatch(self):
        """Tampered file: this is the whole reason this tool exists."""
        from satsignal.verify import VerifyClass
        with mock.patch("satsignal_mcp.server.verify_file") as vf:
            vf.return_value = self._mock_result(
                VerifyClass.CRYPTO,
                message="sha256 mismatch: bundle expects "
                        "a..., got b...",
            )
            result = _run(_handle_verify_file_against_bundle(
                {"file_path": str(self.file),
                 "bundle_path": str(self.bundle)},
                mock.AsyncMock(),
            ))
        payload = _parse(result)
        self.assertFalse(payload["verified"])
        self.assertEqual(payload["verify_class"], "crypto")
        self.assertIn("mismatch", payload["reason"])

    def test_verified_false_on_chain_mismatch(self):
        from satsignal.verify import VerifyClass
        with mock.patch("satsignal_mcp.server.verify_file") as vf:
            vf.return_value = self._mock_result(
                VerifyClass.CHAIN,
                message="on-chain doc_hash X does not match bundle's Y",
            )
            result = _run(_handle_verify_file_against_bundle(
                {"file_path": str(self.file),
                 "bundle_path": str(self.bundle)},
                mock.AsyncMock(),
            ))
        payload = _parse(result)
        self.assertFalse(payload["verified"])
        self.assertEqual(payload["verify_class"], "chain")

    def test_missing_file_path_rejected(self):
        result = _run(_handle_verify_file_against_bundle(
            {"bundle_path": str(self.bundle)}, mock.AsyncMock(),
        ))
        self.assertEqual(_parse(result)["error"], "missing_file_path")

    def test_missing_bundle_path_rejected(self):
        result = _run(_handle_verify_file_against_bundle(
            {"file_path": str(self.file)}, mock.AsyncMock(),
        ))
        self.assertEqual(_parse(result)["error"], "missing_bundle_path")

    def test_nonexistent_file_rejected_with_which_field(self):
        result = _run(_handle_verify_file_against_bundle(
            {"file_path": "/no/such/file",
             "bundle_path": str(self.bundle)},
            mock.AsyncMock(),
        ))
        payload = _parse(result)
        self.assertEqual(payload["error"], "not_a_file")
        self.assertEqual(payload["which"], "file_path")

    def test_nonexistent_bundle_rejected_with_which_field(self):
        result = _run(_handle_verify_file_against_bundle(
            {"file_path": str(self.file),
             "bundle_path": "/no/such/bundle.mbnt"},
            mock.AsyncMock(),
        ))
        payload = _parse(result)
        self.assertEqual(payload["error"], "not_a_file")
        self.assertEqual(payload["which"], "bundle_path")

    def test_min_confirmations_passed_through(self):
        from satsignal.verify import VerifyClass
        with mock.patch("satsignal_mcp.server.verify_file") as vf:
            vf.return_value = self._mock_result(
                VerifyClass.VERIFIED,
                sha256_hex="a" * 64, txid="t" * 64, confirmations=7,
            )
            _run(_handle_verify_file_against_bundle(
                {"file_path": str(self.file),
                 "bundle_path": str(self.bundle),
                 "min_confirmations": 6},
                mock.AsyncMock(),
            ))
            _, kwargs = vf.call_args
            self.assertEqual(kwargs["min_confirmations"], 6)

    def test_offline_never_passed_through(self):
        """[[feedback_chain_confirm_in_helpers]]: chain-confirm MUST be
        on by default in helpers. We never let the caller skip the
        chain check, so verify_file is always called with offline=False."""
        from satsignal.verify import VerifyClass
        with mock.patch("satsignal_mcp.server.verify_file") as vf:
            vf.return_value = self._mock_result(
                VerifyClass.VERIFIED,
                sha256_hex="a" * 64, txid="t" * 64, confirmations=1,
            )
            _run(_handle_verify_file_against_bundle(
                {"file_path": str(self.file),
                 "bundle_path": str(self.bundle),
                 # User-supplied offline=True is silently ignored — the
                 # tool's schema doesn't list it, so an LLM agent can't
                 # request a less-safe verify.
                 "offline": True},
                mock.AsyncMock(),
            ))
            _, kwargs = vf.call_args
            self.assertFalse(kwargs["offline"])


class CallToolResultShapeTest(unittest.TestCase):
    """v0.5.0: tool handlers return `CallToolResult` with `isError`
    set, not bare `list[TextContent]`. Programmatic MCP clients branch
    on `result.isError` to distinguish error from success — the
    pre-0.5 bare list had no flag, so errors looked like success.

    These tests pin the wrapper itself. The text body shape inside the
    wrapper is unchanged (`{"error": <code>, "message": <human>, ...}`
    on errors, the tool-specific payload on success) — naive clients
    reading `content[0].text` see no regression; clients respecting
    `isError` per the MCP protocol now classify errors correctly.
    """

    def test_success_path_sets_isError_false(self):
        """A successful tool call returns a CallToolResult with
        isError=False. Use lookup_hash with a stub'd hit — the
        cheapest success path that doesn't touch the filesystem."""
        import mcp.types as mtypes
        api = mock.AsyncMock()
        api.lookup_hash.return_value = {
            "bundle_id": "b1", "txid": "t" * 64,
            "created_utc": "2026-05-22T00:00:00Z",
        }
        result = _run(_handle_lookup_hash(
            {"sha256_hex": "a" * 64}, api,
        ))
        self.assertIsInstance(result, mtypes.CallToolResult)
        self.assertFalse(result.isError)
        # Naive-client back-compat: text body still parses + has the
        # success shape, no "error" key.
        payload = _parse(result)
        self.assertTrue(payload["hit"])
        self.assertNotIn("error", payload)

    def test_error_path_sets_isError_true(self):
        """The error path (any tool, any error code) returns a
        CallToolResult with isError=True. Use lookup_hash with a
        non-string sha — cheapest error path."""
        import mcp.types as mtypes
        api = mock.AsyncMock()
        result = _run(_handle_lookup_hash({}, api))
        self.assertIsInstance(result, mtypes.CallToolResult)
        self.assertTrue(result.isError)
        api.lookup_hash.assert_not_called()

    def test_error_text_body_shape_preserved(self):
        """Back-compat: the JSON body inside the error CallToolResult
        still has the pre-0.5 shape (`error` code key + `message`
        key), so existing clients that ignore isError and just parse
        the body still work byte-identically."""
        api = mock.AsyncMock()
        result = _run(_handle_lookup_hash({}, api))
        payload = _parse(result)
        self.assertEqual(payload["error"], "missing_sha")
        self.assertIn("message", payload)
        self.assertIsInstance(payload["message"], str)

    def test_call_tool_handler_returns_CallToolResult(self):
        """The @server.call_tool() handler itself returns a
        CallToolResult (covers the dispatcher's own error path —
        unknown_tool — not just per-handler errors)."""
        import mcp.types as mtypes
        from satsignal_mcp.server import build_server

        # build_server registers handlers via decorators on a local
        # Server; we can't easily call the dispatcher through that.
        # The handlers themselves are tested above; the dispatcher
        # wraps them, so the return-type annotation is the contract.
        # Pin the annotation directly.
        import inspect
        # Read the source of build_server and confirm call_tool is
        # annotated to return CallToolResult.
        src = inspect.getsource(build_server)
        self.assertIn("CallToolResult", src)
        # And confirm the dispatcher's error helper itself returns
        # CallToolResult on the unknown_tool branch (which is what the
        # dispatcher reaches when name doesn't match any registered
        # tool).
        from satsignal_mcp.server import _error_response
        result = _error_response("test", code="unknown_tool")
        self.assertIsInstance(result, mtypes.CallToolResult)
        self.assertTrue(result.isError)


if __name__ == "__main__":
    unittest.main()
