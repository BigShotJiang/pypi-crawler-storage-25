# MiniCausal

![logo](images/cropped_logo.jpeg)
