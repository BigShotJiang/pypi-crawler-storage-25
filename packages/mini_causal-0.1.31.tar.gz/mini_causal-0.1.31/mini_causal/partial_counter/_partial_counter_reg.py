from mini_causal.partial_counter._partial_counter import PartialCounterfactual

class PartialCounterfactualRegression(PartialCounterfactual):
    """
    PartialCounterfactualRegression is class that uses partial modeling or methods to 
    measure the impact of features on the built-in regression models.

    It inherits all the methods and properties from the CausalFeatureImportance.

   Args:
        model:
            the trained model

        X (pd.DataFrame):
            The features stored in a dataframe format dataframe are used to simplify accessing the features for partial modeling 
            and calculating causal metrics

        y {pd.DataFrame ,np.array}:
            The target values  must have the same length as the X arg


    Attributes
        partial_fit :
            fits the partial estimator i.e the model without the feature

        individual_causal_effects (np.ndarray):
            returns an array of the individual causal effects

        average_causal_effects (np.ndarray):
            returns the average causal effect float value

    References
    ----------
        .. [1] GUIDO W. IMBENS and DONALD B. RUBIN, Causal Inference For Statistics,Social and Biomedical Sciences An Introduction
        .. [2] Victor Chernozhukov et al. ,Applied Causal Inference Powered by
    ML and AI https://causalml-book.org/


    """
    def __init__(self,model,X,y):
        super().__init__(model,X,y)
        
