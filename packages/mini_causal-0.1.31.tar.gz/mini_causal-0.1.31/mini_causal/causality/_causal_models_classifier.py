import numpy as np
from mini_causal.causality._causal_models import CausalModels

class CausalModelsClassifier(CausalModels):
    """
    CausalModelClassifier class implementation.
    The class inherits the CausalModels class

    The class is mainly deisgned to implement and include Classification of all kinds.
    The aim is to measure the imapact that one model has on the predictions compared to the second
    one . 
    
    In other words,A/B Testing using causality to measure impact.

    Args:
        first_model:
            the first trained model

        second_model:
            the second trained model

    Attributes:
        
        individual_causal_effects (np.ndarray):
            an array of the individual causal effects for the predictions
        
        individual_causal_effects_resid (np.ndarray):
            an array of the individual causal effects for the residuals

        individual_causal_effects_probs (np.ndarray):
            an array of the individual causal effects for the probabilities
        
        average_causal_effect (float):
            the average causal effect of the first model 

        average_causal_effect_resid (float):
            the average causal effect of the first model  on the residuals

        
        average_causal_effect_probs (float):
            the average causal effect of the first model on the predicted probabilities

    """
    def __init__(self,first_model,second_model):
        super().__init__(first_model,second_model)

    def individual_causal_effects_probs(self,X):
        """
        
        The individual causal effects of the predicted probabilities
        
        Args:
            X (np.array,pd.DataFrame):
                the input values that will be used for prediction

        Return:
            np.ndarray:
                an array of individual causal effects for the predicted probabilities
        """
        first_preds=self.first_model.predict_proba(X)[:,1]
        sec_preds=self.second_model.predict_proba(X)[:,1]

        return first_preds-sec_preds
    
  
    def average_causal_effect_probs(self,X):
        """
        
        The average difference in the predicted probabilities for the two models

        Args:
            X (np.array,pd.DataFrame):
                the input values that will be used for prediction

        Return:
            np.ndarray:
                the average causal effect for the predicted probabilities
        """
        return float(np.mean(self.individual_causal_effects_probs(X=X)))
    

