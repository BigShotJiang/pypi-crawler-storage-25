from mini_causal.causality._causal_models import CausalModels

class CausalModelsRegression(CausalModels):
    """
    CausalModelsRegression class implementation.

    The class is mainly deisgned to cover Regression models for tabular data.
    The aim is to measure the imapact that one model has on the predictions compared to the second
    one . 
    
    In other words,A/B Testing using causality to measure impact
    
    Args:
        first_model:
            the first trained model

        second_model:
            the second trained model

    Attributes:
        
        individual_causal_effects (np.ndarray):
            an array of the individual causal effects for the predictions
        
        individual_causal_effects_resid (np.ndarray):
            an array of the individual causal effects for the residuals

        individual_causal_effects_probs (np.ndarray):
            an array of the individual causal effects for the probabilities
        
        average_causal_effect (float):
            the average causal effect of the first model 

        average_causal_effect_resid (float):
            the average causal effect of the first model  on the residuals

        
        average_causal_effect_probs (float):
            the average causal effect of the first model on the predicted probabilities

    """
    def __init__(self,first_model,second_model):
        super().__init__(first_model,second_model)
