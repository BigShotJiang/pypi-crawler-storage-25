import numpy as np

class CausalModels:
    """
    CausalModels class implementation.

    The class is mainly deisgned to implement and include Classification and Regression models of all kinds.
    The aim is to measure the imapact that one model has on the predictions compared to the second
    one . 
    
    In other words,A/B Testing using causality to measure impact.

    Args:
        first_model:
            the first trained model

        second_model:
            the second trained model

    Attributes:
        
        individual_causal_effects (np.ndarray):
            an array of the individual causal effects for the predictions.
        
        individual_causal_effects_resid (np.ndarray):
            an array of the individual causal effects for the residuals.
        
        average_causal_effect (float):
            the effect of the feature on the predictions or outcomes.

        average_causal_effect_resid (float):
            the average causal effect of the feature on the residuals.

    """
    def __init__(self,first_model,second_model):
        self.first_model=first_model
        self.second_model=second_model

    def individual_causal_effects(self,X):
        """
        The individual causal effects of the predicted outcomes.

        Args:
            X (np.array,pd.DataFrame):
                the input values that will be used for prediction.

        Return:
            np.ndarray:
                an array of individual causal effects for the predicted values.
        """
        first_preds=self.first_model.predict(X)
        sec_preds=self.second_model.predict(X)

        return first_preds-sec_preds
    
    def individual_causal_effects_resid(self,X):
        """
        The individual causal effects of the residuals.
        Args:
            X (np.array,pd.DataFrame):
                the input values that will be used for prediction.

        Return:
            np.ndarray:
                an array of individual causal effects for the predicted probabilites.
        """
        first_preds=self.first_model.predict(X)
        sec_preds=self.second_model.predict(X)


        return sec_preds-first_preds
    
    def average_causal_effect(self,X):

        """
        The average difference in the predictions for the two models.

        Args:
            X (np.array,pd.DataFrame):
                the input values that will be used for prediction.

        Return:
            float:
                the average causal effect.
        """
        return float(np.mean(self.individual_causal_effects(X=X)))

    
    def average_causal_effect_resid(self,X):
        """
        The average difference in the effects of the residuals.

        Args:
            X (np.array,pd.DataFrame):
                the input values that will be used for prediction.

        Return:
            float:
                the average causal effect for the residuals.
        """
        return float(np.mean(self.individual_causal_effects_resid(X=X)))
    
