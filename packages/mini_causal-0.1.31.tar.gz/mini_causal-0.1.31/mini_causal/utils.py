import numpy as np
import pandas as pd
from sklearn import clone

def clone_model(model):
    return clone(model)


def treatment_control_selection(df, control_size=0.2, random_seed=None):
    """
    Randomly split dataframe into treatment and control groups.

    Args:
        df (pd.DataFrame):
            the input dataframe

        control_size (float):
            Fraction assigned to control group

        random_seed(int or None):
            for reproducibilit

    Returns:
        treatment,control
    """

    if random_seed is not None:
        np.random.seed(random_seed)

    n_samples = len(df)

    # Shuffle row indices
    indices = np.random.permutation(n_samples)

    # Split point
    split_idx = int(n_samples * (1 - control_size))

    # Indices
    treat_idx = indices[:split_idx]
    control_idx = indices[split_idx:]


    treatment = df.iloc[treat_idx]
    control = df.iloc[control_idx]

    return treatment,control



def make_treatment_control_df(treatment,control)->pd.DataFrame:
    df=pd.concat([treatment,control])

    return df.sort_index()


def summary_stats(treatment:np.ndarray,control:np.ndarray)->pd.DataFrame:
    n_treatment=len(treatment)
    n_control=len(control)

    mean_control_preds=float(np.mean(control))
    mean_treatment_preds=float(np.mean(treatment))

    variance_treatment=float(np.var(treatment,ddof=1))
    variance_control=float(np.var(control,ddof=1))

    return pd.DataFrame(
        {
            "type":["treatment","control"],
            "n":[n_treatment,n_control],
            "mean":[mean_treatment_preds,mean_control_preds],
            "sample_variance":[variance_treatment,variance_control]
        })
    


def causal_effects_stratum(X:pd.DataFrame,causal_effects:np.ndarray,strata_feature:str):
    """
    Args:
        X (pd.DataFrame):
            X values stored in a dataframe that will be used for the prediction.

        causal_effects(np.ndarray):
            the causal effects values
        
        strata_feature(str):
           the name of the feature that will be used for strata

    Returns:
        pd.DataFrame:
           - a dataframe with the following columns: strata_feature,mean,size and weight of the strata
           -  the mean is based on the type arg i.e if preds ,then it will be the mean for the 
           predictions, else if probs then it will be the mean for the predicted probabilities
    """
    N=len(X)
    X["causal_effects"]=causal_effects
        
    results=X.groupby(strata_feature)["causal_effects"].agg(["mean","size"]).reset_index()
    results["weight_rss"]= results["size"] * N

    return results
 
def stratum_weight_rss(X:pd.DataFrame,
                       treatment_model,
                       control_model,
                       feature:str,
                       strata_feature:str,
                       type:str="preds")->pd.DataFrame:
    """
    The causal effect based on the stratum to validate the effect per stratum of the treatment.

    Args:
        X (pd.DataFrame):
            X values stored in a dataframe that will be used for the prediction.

        strata_feature (str):
            the name of the feature that will be used for strata

        treatment_model:
            the trained treatment estimator

        control_model:
            the trained control estimator

        type (str): {preds,probs}
            return the stratum values based on the predicted probabilites or predicted values of the target


    Returns:
        pd.DataFrame:
           - a dataframe with the following columns: strata_feature,mean,size and weight of the strata
           -  the mean is based on the type arg i.e if preds ,then it will be the mean for the 
           predictions, else if probs then it will be the mean for the predicted probabilities

    """
    X_control=X.drop([feature,strata_feature],axis=1)
    X_treatment=X.drop(strata_feature,axis=1)

    treatment_probs=treatment_model.predict_proba(X_treatment)[:,1]
    control_probs=control_model.predict_proba(X_control)[:,1]

    treatment_preds=treatment_model.predict(X_treatment)
    control_preds=control_model.predict(X_control)
    
    causal_effects_probs=treatment_probs-control_probs
    causal_effects=treatment_preds-control_preds

    if type=="preds":
        return causal_effects_stratum(X=X,causal_effects=causal_effects_probs,
                                      strata_feature=strata_feature)
    
    elif type=="probs":
        return causal_effects_stratum(X=X,causal_effects=causal_effects,
                                      strata_feature=strata_feature)
    
    else:
        raise ValueError("Type invalid")
    
