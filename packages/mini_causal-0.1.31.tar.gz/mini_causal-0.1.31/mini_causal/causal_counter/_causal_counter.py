import pandas as pd
import numpy as np
import scipy.stats as stats
from typing import Dict,Union
from mini_causal.utils import make_treatment_control_df,clone_model
from mini_causal.utils import summary_stats,stratum_weight_rss


class CausalCounterfactual:
    """
    CausalCounterfactual class implementation.
    This class is mainly based on the potential outcome framework sometimes referred to
    as Counterfactual framework in Causal Framework.

    The Counterfactual framework assumes two possible outcomes and is based on the what if question.
    The workflow used in the class is the t-learner method which takes in two different sets and 
    train two different models. 

    However the aim in the CausalCounterfactual class is to measure the impact of features on the model.
    With that being said, the treatment set will be the dataset without the feature whereas the control will
    have the feature we want to measure the impact it has overall.

    Hence both the treatment and control models use the same args or parameters for the model.
    If the model used is a DecisionTreeClassifier for instance then we would have a decision classifier
    for treatment and as well as for control group.

    Args:
        model (str):
            the model that will be used for the counterfactual workflow.

        treatment(pd.DataFrame):
            the treatment set.

        control (pd.DataFrame):
            the control set.

        feature (str):
            the feature that we want to measure the impact for.

        label (str):
           the name of the target column in the treatment and control.
           it must be the same and consistent for both sets.

    Attributes:
        hypotheses (Dict[str,str]):
            return a dictionary with the null and alternative hypotheses.

        treatment_model (sklearn.base):
            the model trained on the treatment set.

        control_model:
            the model trained on the control set.

        individual_causal_effects (np.ndarray):
            an array of the individual causal effects for the predictions.
        
        individual_causal_effects_resid (np.ndarray):
            an array of the individual causal effects for the residuals.

        average_causal_effect (float):
            the effect of the feature on the predictions or outcomes.

        average_causal_effect_resid (float):
            the effect of the feature on the residuals.

        correlation (float):
            the correlation between treatment and control predictions.

        correlation_confidence_interval (Dict[float,float]):
            the confidence intervals for the correlation between treatment and control predictions.

        t_statistic (float):
            the studentized t-statistic for individual causal effects.
        
        p_value (float):
            the pvalue for the outcome individual causal effects.

        causal_effect_stratified (pd.DataFrame):
            the causal effect per stratum using rss method in a dataframe format
       
        """
    def __init__(self,model,treatment:pd.DataFrame,control:pd.DataFrame,feature:str,label:str):
        self.model=model
        self.treatment=treatment
        self.control=control
        self.feature=feature
        self.label=label
        self.df=make_treatment_control_df(treatment=treatment,control=control)

    def hypotheses(self)->Dict[str,str]:
        """
        Returns: 
            Dict[str,str]
                - the dictionary containing the hypotheses i.e Ho and Ha
                - sometimes referred to Strong hypotheses.
        """
        return {
            "Ho":f"{self.feature} has no effect on the predictions.",
            "Ha":f"{self.feature} has no effect on the predictions."

        }
    
    def _full_model(self):
        return clone_model(self.model)

    def treatment_model(self):
        """
        Returns :
            a treatment model i.e a model trained on the treatment sample or units.
        """
        X_treat=self.treatment.drop(self.label,axis=1)
        y_treat=self.treatment[self.label]

        return self._full_model.fit(X_treat,y_treat)

    def control_model(self):
        """
        Returns :
            a control model i.e a model trained on the treatment sample or units.
        """
        X_control=self.control.drop([self.label,self.feature],axis=1)
        y_control=self.control[self.label]

        return self._full_model.fit(X_control,y_control)
    
    def individual_causal_effects(self,X:pd.DataFrame)->np.ndarray:
        """
        Calculates the individual causal effects.
        That is the difference between Yt and Yc for predicted values.

        Args:
            X (pd.Dataframe):
                X values stored in a dataframe that will be used for the predictions.

        Returns:
            np.ndarray:
                an array of individual causal effects.

        """
        control=X.drop(self.feature,axis=1)

        control_preds=self.control_model().predict(control)
        treatment_preds=self.treatment_model().predict(X)

        return treatment_preds-control_preds
    
    def individual_causal_effects_resid(self,X:pd.DataFrame)->np.ndarray:
        """
        The individual causal effects for the residuals.


        Args:
            X (pd.DataFrame):
                X values stored in a dataframe that will be used for the predictions.

        Returns:
            np.ndarray:
                individual causal effect for the probabilities.

        """

        control=X.drop(self.feature,axis=1)

        control_preds=self.control_model().predict(control)
        treatment_preds=self.treatment_model().predict(X)

        return control_preds-treatment_preds
    
    def average_causal_effect(self,X:pd.DataFrame):
        """
        The average causal effect for the probabilities.

        Args:
            X (pd.DataFrame):
                X values stored in a dataframe that will be used for the prediction.

        Returns:
            float:
                average causal effect for the probabilities.

        """
        return float(np.mean(self.individual_causal_effects(X)))
    
    def average_causal_effect_resid(self,X:pd.DataFrame):
        """
        The average causal effect for the probabilities.

        Args:
            X (pd.DataFrame):
                X values stored in a dataframe that will be used for the prediction.
            
        Returns:
            float:
                average causal effect for the probabilities.

        """
    
          
        return float(np.mean(self.individual_causal_effects_resid(X)))
    
    @property
    def _preds_exp(self):
        """
        Returns:
            np.ndarray:
                the treatment and control predictions.
        """
        X_control=self.df.drop([self.feature,self.label],axis=1)
        X_treatment=self.df.drop([self.label],axis=1)

        control_preds=self.control_model.predict(X_control) 
        treatment_preds=self.treatment_model.predict(X_treatment)

        return treatment_preds,control_preds

    
    @property
    def summary(self)->pd.DataFrame:
        """
        The summary dataframe for the treatment and control predictions.

        Returns:
            pd.DataFrame:
                summary
        """
        treatment_preds,control_preds=self._preds_exp
        return summary_stats(treatment=treatment_preds,control=control_preds)
        
    
    @property
    def correlation(self):
        """
        The correlation between the treatment and control predictions.
        """
        population_size=len(self.df)

        treatment_preds,control_preds=self._preds_exp

        diff=np.mean(treatment_preds-control_preds)

        summation=np.sum(treatment_preds-control_preds-diff) ** 2

        return 1/(population_size-1) * summation
    
    def correlation_confidence_interval(self,alpha=0.05):
        """
        The correlation confidence interval for the correlation between treatment and control
        outcomes.

        Args:
           alpha (float)
                the level of significance.

        Returns:
            Dict[float,float]:
                the dictionary with the lower and upper bounds.
        """
        summary_df=self.summary

        nt,nc=summary_df["n"].values
        sample_var_treatment,sample_var_control=summary_df["sample_variance"].values

        first_term=sample_var_treatment/nt
        sec_term=sample_var_control/nc

        third_term=(sample_var_treatment-sample_var_control)**2/ (nt+nc)

        var_corr=(first_term + sec_term) - third_term

        std_error=float(np.sqrt(var_corr))
        z_critical = stats.norm.ppf(1 - alpha/2)

        return {
            "lower_bound":self.correlation - (z_critical*std_error),
            "upper_bound":self.correlation + (z_critical*std_error)
        }
    

    @property
    def t_statistic(self):
        """
        The average causal effect for the probabilities for the stratum.
        The average between Yc and Yt of predicted probabilities is the causal effect.

        Args:
            X (pd.DataFrame):
                X values stored in a dataframe that will be used for the prediction.

            strata_feature (str):
                the name of the feature that will be used for strata

        Returns:
            pd.DataFrame:
                the dataframe of the stratum with the following columns:stratum_feature,causal_effect,size and 
                stratum weight.
        """
        summary_df=self.summary

        nt,nc=summary_df["n"]
        sample_var_treatment,sample_var_control=summary_df["sample_variance"].values
        mean_treatment,mean_control=summary_df["mean"].values

        first_term=sample_var_treatment/nt
        sec_term=sample_var_control/nc

        v_diff=first_term + sec_term

        t_stat=(mean_treatment-mean_control)/np.sqrt(v_diff)

        return float(t_stat)
    
    @property
    def p_value(self):
        """
        Args:
            alpha (float):
                the level of significance.
        
        Returns:
            float:
                pvalue for testing if the feature has an impact on the outcomes or not.

        """

        df=len(self.df)-1
        pvalue = 2 * stats.t.sf(abs(self.t_statistic), df) # Two-tailed

        return pvalue
       
   
    def causal_effect_stratified(self,X:pd.DataFrame,strata_feature:str,type:str="preds")->pd.DataFrame:
        """
        The average causal effect for the predicted per stratum.
        The average between Yc and Yt of predicted is the causal effect.

        Args:
            X (pd.DataFrame):
                X values stored in a dataframe that will be used for the prediction.

            strata_feature (str):
                the name of the feature that will be used to get causal effects per stratum.

            type (str): {preds,probs}
                type will determine if the returned causal effects are for the predictions
                or the predicted probabilities.

        Returns:
            pd.DataFrame:
                the dataframe with the following columns:strata_feature,causal_effect,size and 
                stratum weight.
        """
        return stratum_weight_rss(
            X=X,
            treatment_model=self.treatment_model(),
            control_model=self.control_model(),
            feature=self.feature,
            strata_feature=strata_feature,
            type=type)
    
    
