import pandas as pd
from mini_causal.causal_counter import CausalCounterfactual

class CausalCounterfactualRegression(CausalCounterfactual):
    """
    CausalCounterfactualRegression class implementation.
    This class is mainly based on the potential outcome framework sometimes referred to
    as Counterfactual framework in Causal Framework.

    The class is mainly deisgned to implement and include Regression models of all kinds. 
    It should be noted that the class inherits all the properties and methods 
    from the CausalCounterfactul class

    The Counterfactual framework assumes two possible outcomes and is based on the what if question.
    The workflow used in the class is the t-learner method which takes in two different sets and 
    train two different models. 

    However the aim in the CausalCounterfactual class is to measure the impact of features on the model.
    With that being said, the treatment set will be the dataset without the feature whereas the control will
    have the feature we want to measure the impact it has overall.

    Hence both the treatment and control models use the same args or parameters for the model.
    If the model used is a DecisionTreeRegression for instance then we would have a decision regressor
    for treatment and as well as for control group.

    Args:
        model (str):
            the model that will be used for the counterfactual workflow.

        treatment(pd.DataFrame):
            the treatment set.

        control (pd.DataFrame):
            the control set.

        feature (str):
            the feature that we want to measure the impact for

        label (str):
           the name of the target column in the treatment and control.
           it must be the same and consistent for both sets

    Attributes:
        hypotheses (Dict[str,str]):
            return a dictionary with the null and alternative hypotheses

        treatment_model (sklearn.base):
            the model trained on the treatment set

        control_model:
            the model trained on the control set

        individual_causal_effects (np.ndarray):
            an array of the individual causal effects for the predictions
        
        individual_causal_effects_resid (np.ndarray):
            an array of the individual causal effects for the residuals

        average_causal_effect (float):
            the effect of the feature on the predictions or outcomes

        average_causal_effect_resid (float):
            the effect of the feature on the residuals

        correlation (float):
            the correlation between treatment and control predictions

        correlation_confidence_interval (Dict[float,float]):
            the confidence intervals for the correlation between treatment and control predictions

        t_statistic (float):
            the studentized t-statistic for individual causal effects
        
        pvalue (float):
            the pvalue for the outcome individual causal effects

        causal_effect_stratified (pd.DataFrame):
            the causal effect per stratum using rss method in a dataframe format

        """
    def __init__(self,model,treatment:pd.DataFrame,control:pd.DataFrame,feature:str,label:str):
        super().__init__(model,treatment,control,feature,label)
        
