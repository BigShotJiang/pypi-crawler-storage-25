import numpy as np
import pandas as pd
import scipy.stats as stats
from mini_causal.causal_counter import CausalCounterfactual
from mini_causal.utils import stratum_weight_rss

class CausalCounterfactualClassifier(CausalCounterfactual):
    """
    CausalCounterfactualClassifier class implementation.
    This class is mainly based on the potential outcome framework sometimes referred to
    as Counterfactual framework in Causal Framework.

    The class is mainly deisgned to implement and include Classification models of all kinds. 
    It should be noted that the class inherits all the properties and methods 
    from the CausalCounterfactul class.

    The Counterfactual framework assumes two possible outcomes and is based on the what if question.

    The class is to measure the impact of features on the model for classification models.
    With that being said, the treatment set will be the dataset without the feature whereas the control will
    have the feature we want to measure the impact it has overall.

    Hence both the treatment and control models use the same args or parameters for the model.
    If the model used is a DecisionTreeClassifier for instance then we would have a decision classifier
    for treatment and as well as for control group.

    Args:
        model (str):
            the model that will be used for the counterfactual workflow.

        treatment(pd.DataFrame):
            the treatment set.

        control (pd.DataFrame):
            the control set.

        feature (str):
            the feature that we want to measure the impact for

        label (str):
           the name of the target column in the treatment and control.
           it must be the same and consistent for both sets

    Attributes:
        hypotheses (Dict[str,str]):
            return a dictionary with the null and alternative hypotheses

        treatment_model (sklearn.base):
            the model trained on the treatment set

        control_model:
            the model trained on the control set

        individual_causal_effects (np.ndarray):
            an array of the individual causal effects for the predictions
        
        individual_causal_effects_resid (np.ndarray):
            an array of the individual causal effects for the residuals
        
        individual_causal_effects_probs (np.ndarray):
            an array of the individual causal effects for the predicted probabilities

        average_causal_effect (float):
            the effect of the feature on the predictions or outcomes

        average_causal_effect_resid (float):
            the average causal effect of the feature on the residuals

        average_causal_effect_probs (float):
            the average causal effect of the feature on the predicted probabilities

        correlation(float):
            the correlation between treatment and control predictions

        correlation_confidence_interval (Dict[float,float]):
            the confidence intervals for the correlation between treatment and control predictions

        t_statistic (float):
            the studentized t-statistic for causal effects
        
        pvalue (float):
            the pvalue for the causal effects

        causal_effect_stratified (pd.DataFrame):
            the causal effect for strata using rss method for the outcomes or predictions

            
        """
    def __init__(self,model,treatment,control,feature,label):
        super().__init__(model,treatment,control,feature,label)

    def individual_causal_effects_probs(self,X:pd.DataFrame)->np.ndarray:
        """
       The individual causal effects of the predicted probabilities by calculating the difference 
       between Yc and Yt of predicted probabilities .

        Args:
            X (pd.DataFrame):
                X values stored in a dataframe that will be used for the prediction.

        Returns:
            np.ndarray:
                an array of individual causal effects for the probabilities

        """
        control=X.drop(self.feature,axis=1)

        control_preds=self.control_model().predict(control)
        treatment_preds=self.treatment_model().predict(X)

        return treatment_preds-control_preds
    
    def average_causal_effect_probs(self,X:pd.DataFrame)->float:
        """
        The average causal effect for the probabilities

        Args:
            X (pd.DataFrame):
                X values stored in a dataframe that will be used for the prediction.

        Returns:
            float:
                average causal effect for the probabilities
        """

        return float(np.mean(self.individual_causal_effects(X)))
    
   
