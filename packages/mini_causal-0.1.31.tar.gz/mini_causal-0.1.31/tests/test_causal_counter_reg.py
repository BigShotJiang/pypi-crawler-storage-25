import pytest
import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from mini_causal.causal_counter import CausalCounterfactualRegression


@pytest.fixture
def sample_data():
    df=pd.DataFrame({
        "X1":[11,19,20,23,24,25,11,19,20],
        "X2":[23,15,17,8,12,15,17,16,17],
        "location":["North","North","South","South","South","North","South","South","North"],
        "y_reg":np.array([19,11,17,30,31,32,77,80,19])
    })


    return df

@pytest.fixture
def linear_model():
    """
    Returns:
        Linear Regression class
    """
    
    return LinearRegression()

@pytest.fixture
def linear_causal_counter(sample_data,log_model):
    treatment=sample_data
    control=sample_data
    model=log_model

    linear_counter=CausalCounterfactualRegression(
        model=model,
        treatment=treatment,
        control=control,
        feature="X1",
        label="y_reg")
    
    return linear_counter

def test_hypotheses_keys(linear_causal_counter):
    linear_counter=linear_causal_counter
   
    assert "Ho" in linear_counter.hypotheses()
    assert "Ha" in linear_counter.hypotheses()

def test_control_model(linear_causal_counter,log_model,sample_data):
    linear_counter=linear_causal_counter
    control=sample_data
    model=log_model
   
    X_control=control.drop(["X1","location","y_class"],axis=1)
    y_control=control["y_class"]

    model.fit(X_control,y_control)

    assert model == linear_counter.control_model()


def test_treatment_model(linear_causal_counter,linear_model,sample_data):
    linear_counter=linear_causal_counter
    treatment=sample_data
    model=linear_model
   
    X=treatment.drop(["location","y_reg"],axis=1)
    y=treatment["y_reg"]

    model.fit(X,y)

    assert model == linear_counter.treatment_model()

def test_average_causality(linear_causal_counter,sample_data):
    linear_counter=linear_causal_counter
    df=sample_data

    X=df.drop(["location","y_reg"],axis=1)

    assert type(linear_counter.average_causal_effect(X=X))==float


def test_inferential_stats(linear_causal_counter):
    linear_counter=linear_causal_counter

    correlation=linear_counter.correlation()
    pvalue=linear_counter.p_value

    t_stats=linear_counter.t_statistic

    assert type(correlation)==float
    assert type(pvalue)==float
    assert type(t_stats)==float


def test_correlation_ci(linear_causal_counter):
    linear_counter=linear_causal_counter

    assert "upper_bound" in linear_counter.correlation_confidence_interval()
    assert "lower_bound" in linear_counter.correlation_confidence_interval()


def test_strat_exp(linear_causal_counter,sample_data):
    linear_counter=linear_causal_counter
    X=sample_data
    
    strat_df=linear_counter.causal_effect_stratified(
        X=X,
        strata_feature="location",
        type="preds"
    )

    columns=strat_df.columns

    assert "mean" in columns
    assert "size" in columns
    assert "weight_rss" in columns

def test_individual_causal_effects(linear_causal_counter,sample_data):
    linear_counter=linear_causal_counter
    df=sample_data

    X=df.drop(["y_reg","location"],axis=1)
    y=df["y_reg"]
    

    causal_effects=linear_counter.individual_causal_effects(X=X)
    causal_resids=linear_counter.individual_causal_effects_resid(X=X,y_true=y)

    assert type(causal_effects)==np.ndarray
    assert type(causal_resids)==np.ndarray




