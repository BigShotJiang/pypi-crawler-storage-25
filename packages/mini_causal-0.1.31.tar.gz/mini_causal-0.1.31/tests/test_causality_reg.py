import pytest
import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.tree import DecisionTreeRegressor
from mini_causal.causality import CausalModelsRegression

@pytest.fixture
def sample_data():

    X=np.array([[1,2,3,4,5,6,7,8,9,10]]).reshape(-1,1)
    y=np.array([13,16,19,11,55,16,18,30,19,10])

    return X,y

@pytest.fixture
def linear_model(sample_data):
   X,y=sample_data

   model=LinearRegression()

   return model.fit(X,y)

@pytest.fixture
def dt_model(sample_data):
   X,y=sample_data

   model=DecisionTreeRegressor()

   return model.fit(X,y)


@pytest.fixture
def causal_regressor(linear_model,dt_model):
   
   first_model=linear_model
   sec_model=dt_model

   return CausalModelsRegression(
      first_model=first_model,
      second_model=sec_model
   )
   

def test_individual_causal_effect(causal_regressor):
   causal_reg=causal_regressor

   causal_effects_arr=causal_reg.individual_causal_effects()
   causal_effects_resid=causal_reg.individual_causal_effects_resid()
   

   assert type(causal_effects_arr)==np.array
   assert type(causal_effects_resid)==np.array
   

def test_causal_effects(causal_regressor):
   causal_reg=causal_regressor

   causal_effect_preds=causal_reg._average_causal_effect()
   causal_effect_resid=causal_reg.average_causal_effect_resid()
  
   
   assert type(causal_effect_preds)==float
   assert type(causal_effect_resid)==float


   

