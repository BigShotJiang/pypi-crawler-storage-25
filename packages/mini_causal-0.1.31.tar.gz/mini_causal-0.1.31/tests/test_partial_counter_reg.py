import pytest
import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from mini_causal.partial_counter import PartialCounterfactualRegression


@pytest.fixture
def sample_data():
    X=pd.DataFrame({"X1":[11,19,20,23,24,25],
                    "X2":[23,15,17,8,12,15]})
    y=[12,19,13,4,3,11]

    return X,y

@pytest.fixture
def model(sample_data):
    X,y=sample_data
    lr=LinearRegression()

    return lr.fit(X,y)

def test_initialization(model, sample_data):
    X, y = sample_data

    partial_reg= PartialCounterfactualRegression(model, X, y)

    assert partial_reg.model == model
    assert len(partial_reg.X)== len(partial_reg.X)
    assert len(partial_reg.y) == len(y)

def test_individual_causal_effect(model,sample_data):
    X, y = sample_data

    partial_reg= PartialCounterfactualRegression(model, X, y)
    individual_effects=partial_reg.individual_causal_effects("X1")

    assert isinstance(individual_effects,np.ndarray)


def test_average_causal_effect(model,sample_data):
    X, y = sample_data

    partial_reg= PartialCounterfactualRegression(model, X, y)
    average_effect=partial_reg.average_causal_effect("X1")

    assert isinstance(average_effect,float)
