import pytest
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from mini_causal.causal_counter import CausalCounterfactualClassifier


@pytest.fixture
def sample_data():
    df=pd.DataFrame({
        "X1":[11,19,20,23,24,25,11,19,20],
        "X2":[23,15,17,8,12,15,17,16,17],
        "y_class":np.array([19,11,17,30,31,32,77,80,19])
    })


    return df

@pytest.fixture
def log_model():
    """
    Returns:
        LogisticRegression fitted on sample set
    """
    
    return LogisticRegression(solver="liblinear")

@pytest.fixture
def log_causal_counter(sample_data,log_model):
    treatment=sample_data
    control=sample_data
    model=log_model

    log_counter=CausalCounterfactualClassifier(model=model,
                                     treatment=treatment,
                                     control=control,
                                     feature="X1",
                                     label="y_class")
    
    return log_counter



def test_individual_causal_effects(log_causal_counter,sample_data):
    log_counter=log_causal_counter
    df=sample_data

    X=df.drop("y_class",axis=1)
    y=df["y_class"]

    causal_effects=log_counter.individual_causal_effects(X=X)
    causal_resids=log_counter.individual_causal_effects_resid(X=X,y_true=y)
    causal_probs=log_counter.individual_causal_effects_probs(X=X)

    assert type(causal_effects)==np.ndarray
    assert type(causal_resids)==np.ndarray
    assert type(causal_probs)==np.ndarray

def test_causal_effect(log_causal_counter,sample_data):
    log_counter=log_causal_counter
    df=sample_data

    X=df.drop("y_class",axis=1)
    y=df["y_class"]

    causal_effect_preds=log_counter.average_causal_effect(X=X)
    causal_effect_resid=log_counter.average_causal_effect_resid(X=X,y_true=y)
    causal_effect_probs=log_counter.average_causal_effect_probs(X=X)

    assert type(causal_effect_preds)==float
    assert type(causal_effect_resid)==float
    assert type(causal_effect_probs)==float


