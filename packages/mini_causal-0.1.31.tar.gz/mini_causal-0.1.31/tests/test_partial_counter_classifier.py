import pytest
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from mini_causal.partial_counter import PartialCounterfactualClassifier



@pytest.fixture
def sample_data():
    X=pd.DataFrame({"X1":[11,19,20,23,24,25],
                    "X2":[23,15,17,8,12,15]})
    y=[1,1,0,0,1,1]

    return X,y


@pytest.fixture
def model(sample_data):
    X,y=sample_data
    log_model= LogisticRegression(solver="liblinear")
    
    return log_model.fit(X,y)

def test_initialization(model, sample_data):
    X, y = sample_data

    partial_counter= PartialCounterfactualClassifier(model, X, y)

    assert partial_counter.model == model
    assert len(partial_counter.y) == len(y)


def test_causal_effects():
    X, y = sample_data

    partial_counter= PartialCounterfactualClassifier(model, X, y)

    individual_causals=partial_counter._individual_causal_effects(feature="X1")
    individual_causals_probs=partial_counter._individual_causal_effects_probs(feature="X2")

    assert isinstance(individual_causals, np.ndarray)
    assert isinstance(individual_causals_probs,np.ndarray)


def test_average_causal_effects():
    X, y = sample_data

    partial_counter= PartialCounterfactualClassifier(model, X, y)
    ate=partial_counter.average_treatment_effect(feature="X1")
    ate_probs=partial_counter.average_treatment_effect_probs(feature="X2")

    assert isinstance(ate,float)
    assert isinstance(ate_probs,float)



