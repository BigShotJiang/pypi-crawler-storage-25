import pytest
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from mini_causal.causal_counter import CausalCounterfactual


@pytest.fixture
def sample_data():
    df=pd.DataFrame({
        "X1":[11,19,20,23,24,25,11,19,20],
        "X2":[23,15,17,8,12,15,17,16,17],
        "location":["North","North","South","South","South","North","South","South","North"],
        "y_class":np.array([19,11,17,30,31,32,77,80,19])
    })


    return df

@pytest.fixture
def log_model():
    """
    Returns:
        LogisticRegression fitted on sample set
    """
    
    return LogisticRegression(solver="liblinear")

@pytest.fixture
def log_causal_counter(sample_data,log_model):
    treatment=sample_data
    control=sample_data
    model=log_model

    log_counter=CausalCounterfactual(model=model,
                                     treatment=treatment,
                                     control=control,
                                     feature="X1",
                                     label="y_class")
    
    return log_counter

def test_hypotheses_keys(log_causal_counter):
    log_counter=log_causal_counter
   
    assert "Ho" in log_counter.hypotheses()
    assert "Ha" in log_counter.hypotheses()

def test_control_model(log_causal_counter,log_model,sample_data):
    log_counter=log_causal_counter
    control=sample_data
    model=log_model
   
    X_control=control.drop(["X1","y_class"],axis=1)
    y_control=control["y_class"]

    model.fit(X_control,y_control)

    assert model == log_counter.control_model()


def test_treatment_model(log_causal_counter,log_model,sample_data):
    log_counter=log_causal_counter
    treatment=sample_data
    model=log_model
   
    X=treatment.drop("y_class",axis=1)
    y=treatment["y_class"]

    model.fit(X,y)

    assert model == log_counter.treatment_model()

def test_average_causality(log_causal_counter):
    log_counter=log_causal_counter

    assert type(log_counter.average_causal_effect()) == float


def test_inferential_stats(log_causal_counter):
    log_counter=log_causal_counter

    correlation=log_counter.correlation()
    pvalue=log_counter.p_value

    t_stats=log_counter.t_statistic

    assert type(correlation)==float
    assert type(pvalue)==float
    assert type(t_stats)==float


def test_correlation_ci(log_causal_counter):
    log_counter=log_causal_counter

    assert "upper_bound" in log_counter.correlation_confidence_interval()
    assert "lower_bound" in log_counter.correlation_confidence_interval()


def test_strat_exp(log_causal_counter,sample_data):
    log_counter=log_causal_counter
    X=sample_data.drop("y_class",axis=1)
    
    strat_df=log_counter.causal_effect_stratified(
        X=X,
        strata_feature="location",
        type="preds"
    )

    columns=strat_df.columns

    assert "mean" in columns
    assert "size" in columns
    assert "weight_rss" in columns

def test_individual_causal_effects(log_causal_counter,sample_data):
    log_counter=log_causal_counter
    df=sample_data

    X=df.drop(["y_class","location"],axis=1)
    y=df["y_class"]

    causal_effects=log_counter.individual_causal_effects(X=X)
    causal_resids=log_counter.individual_causal_effects_resid(X=X,y_true=y)

    assert type(causal_effects)==np.ndarray
    assert type(causal_resids)==np.ndarray







