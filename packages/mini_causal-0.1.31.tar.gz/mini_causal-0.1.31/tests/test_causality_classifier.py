import pytest
import pandas as pd
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from mini_causal.causality import CausalModelsClassifier

@pytest.fixture
def sample_data():
    
    X=np.array([[1,2,3,4,5,6,7,8,9,10]]).reshape(-1,1)
    y=np.array([1,1,1,0,0,0,1,1,0,0,1,0])

    return X,y

@pytest.fixture
def log_model(sample_data):
   X,y=sample_data

   model=LogisticRegression(solver="liblinear")

   return model.fit(X,y)

@pytest.fixture
def dt_model(sample_data):
   X,y=sample_data

   model=DecisionTreeClassifier()

   return model.fit(X,y)


@pytest.fixture
def causal_classifier(log_model,dt_model):
   
   first_model=log_model
   sec_model=dt_model

   return CausalModelsClassifier(
      first_model=first_model,
      second_model=sec_model
   )
   

def test_individual_causal_effect(causal_classifier):
   causal_class=causal_classifier

   causal_effects_arr=causal_class.individual_causal_effects()
   causal_effects_resid=causal_class.individual_causal_effects_resid()
   causal_effects_probs=causal_class.individual_causal_effects_probs()

   assert type(causal_effects_arr)==np.array
   assert type(causal_effects_resid)==np.array
   assert type(causal_effects_probs)==np.array


def test_causal_effects(causal_classifier):
   causal_class=causal_classifier

   causal_effect_preds=causal_class._average_causal_effect()
   causal_effect_resid=causal_class.average_causal_effect_resid()
   causal_effect_probs=causal_class.average_causal_effect_probs()
   
   assert type(causal_effect_preds)==float
   assert type(causal_effect_resid)==float
   assert type(causal_effect_probs)==float

   

