import pytest
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression,LinearRegression
from mini_causal.partial_counter import PartialCounterfactual


@pytest.fixture
def sample_data():
    X=pd.DataFrame({"X1":[11,19,20,23,24,25],
                    "X2":[23,15,17,8,12,15]})
    y_class=np.array([1,1,0,0,1,1])
    y_reg=np.array([19,37,65,67,45])


    return X,y_class,y_reg


@pytest.fixture
def log_model(sample_data):
    """
    Returns:
        LogisticRegression fitted on sample set
    """
    X,y=sample_data
    log_model=LogisticRegression(solver="liblinear")
    return log_model.fit(X,y)

@pytest.fixture
def linear_model(sample_data):
    """
    Returns:
        LinearRegression fitted on sample set
    """
    X,_,y=sample_data
    lr=LinearRegression()

    return lr.fit(X,y)


def test_initialization_reg(linear_model,sample_data):
    """
    """
    X,_,y_reg = sample_data

    causal_feat_reg= PartialCounterfactual(linear_model, X, y_reg)

    assert causal_feat_reg.model== linear_model
    assert len(causal_feat_reg.y) == len(y_reg)

def test_initialization_class(log_model,sample_data):
    """
    """
    X, y_class,_ = sample_data

    causal_feat_classifier= PartialCounterfactual(log_model, X, y_class)
   
    assert causal_feat_classifier.model ==log_model
    assert len(causal_feat_classifier.y) == len(y_class)

def test_causal_effects(linear_model,log_model):
    """
    Testing If individual causal effects are returned as numpy array

    Parameters:
        linear_model : LinearRegression
        log_model : LogisticRegression

    """
    X, y_class,y_reg= sample_data

    causal_feat_reg = PartialCounterfactual(linear_model,X, y_reg)
    causal_feat_classifier = PartialCounterfactual(log_model,X, y_class)


    individual_causals_reg=causal_feat_reg._individual_causal_effects(feature="X1")
    individual_causals_classifier=causal_feat_classifier._individual_causal_effects(feature="X2")

    assert isinstance(individual_causals_reg, np.ndarray)
    assert isinstance(individual_causals_classifier,np.ndarray)


def test_average_causal_effects(linear_model,log_model):
    """
     Testing If average causal effects are returned as float values rather

    Parameters:
        linear_model : LinearRegression
        log_model : LogisticRegression

    """
    X, y_class,y_reg= sample_data

    causal_feat_reg = PartialCounterfactual(linear_model,X, y_reg)
    causal_feat_classifier = PartialCounterfactual(log_model,X, y_class)


    ace_reg=causal_feat_reg._average_causal_effects(feature="X1")
    ace_classifier=causal_feat_classifier.average_effects(feature="X2")

    assert isinstance(ace_reg,float)
    assert isinstance(ace_classifier,float)



