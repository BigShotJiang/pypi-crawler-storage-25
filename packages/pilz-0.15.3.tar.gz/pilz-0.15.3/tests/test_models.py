from sympy import And, Eq, Ge, Gt, Le, Lt, Ne, Not, Or, Symbol

from pilz.model.datacard import DataCard, Feature, FeatureType, Target
from pilz.model.dataframes import CatCats, ContCats
from pilz.model.filter import Filter, SympyContainer, SympyToSqlHelper
from pilz.model.pilz import Pilz, Pilze, Spore
from pilz.model.settings import EvalSettings, TrainSettings


class TestFeatureType:
    def test_values(self):
        assert FeatureType.CATEGORIAL == "categorial"
        assert FeatureType.NUMERICAL == "numerical"


class TestFeature:
    def test_minimal(self):
        f = Feature(name="age", statistical=FeatureType.NUMERICAL, type="int")
        assert f.name == "age"
        assert f.statistical == FeatureType.NUMERICAL
        assert f.type == "int"
        assert f.missing_value is None

    def test_with_missing_value(self):
        f = Feature(
            name="age",
            statistical=FeatureType.NUMERICAL,
            type="int",
            missing_value=-1,
        )
        assert f.missing_value == -1


class TestTarget:
    def test_create(self):
        t = Target(feature_name="label", values=["yes", "no"])
        assert t.feature_name == "label"
        assert t.values == ["yes", "no"]

    def test_int_values(self):
        t = Target(feature_name="target", values=[0, 1])
        assert t.values == [0, 1]


class TestDataCard:
    def test_feature_names(self):
        card = DataCard(
            features=[
                Feature(name="age", statistical=FeatureType.NUMERICAL, type="int"),
                Feature(name="income", statistical=FeatureType.NUMERICAL, type="float"),
                Feature(name="label", statistical=FeatureType.CATEGORIAL, type="string"),
            ],
            infos={"name": "test"},
            target=Target(feature_name="label", values=["yes", "no"]),
            test_files=["test.csv"],
            train_files=["train.csv"],
        )
        assert card.feature_names == ["age", "income", "label"]

    def test_feature_names_sql_save(self):
        card = DataCard(
            features=[
                Feature(name="age", statistical=FeatureType.NUMERICAL, type="int"),
                Feature(name="income", statistical=FeatureType.NUMERICAL, type="float"),
            ],
            infos={},
            target=Target(feature_name="label", values=[0, 1]),
            test_files=[],
            train_files=[],
        )
        assert card.feature_names_sql_save == ['"age"', '"income"']

    def test_train_features_excludes_target(self):
        card = DataCard(
            features=[
                Feature(name="age", statistical=FeatureType.NUMERICAL, type="int"),
                Feature(name="label", statistical=FeatureType.CATEGORIAL, type="string"),
            ],
            infos={},
            target=Target(feature_name="label", values=["yes", "no"]),
            test_files=[],
            train_files=[],
        )
        names = [f.name for f in card.train_features]
        assert names == ["age"]


class TestTrainSettings:
    def test_defaults(self):
        s = TrainSettings(out_folder=".")
        assert s.n == 1
        assert s.max_depth == 10
        assert s.n_cat == 3
        assert s.n_dims == 3
        assert s.neutral_faktor == 0.0
        assert s.use_neutral_state is False

    def test_custom_values(self):
        s = TrainSettings(n=5, out_folder="results", max_depth=6, n_cat=4)
        assert s.n == 5
        assert s.max_depth == 6
        assert s.n_cat == 4

    def test_neutral_faktor_bounds_valid(self):
        s = TrainSettings(out_folder=".", neutral_faktor=0.5)
        assert s.neutral_faktor == 0.5

    def test_neutral_faktor_below_zero_raises(self):
        import pydantic
        import pytest
        with pytest.raises(pydantic.ValidationError):
            TrainSettings(out_folder=".", neutral_faktor=-0.1)

    def test_neutral_faktor_above_one_raises(self):
        import pydantic
        import pytest
        with pytest.raises(pydantic.ValidationError):
            TrainSettings(out_folder=".", neutral_faktor=1.5)


class TestEvalSettings:
    def test_minimal(self):
        s = EvalSettings(in_folders=["."], out_folder="results")
        assert s.max_parallel_where == 100
        assert s.keep_cols == []

    def test_custom(self):
        s = EvalSettings(
            in_folders=["models/run1"],
            out_folder="eval/run1",
            max_parallel_where=50,
            keep_cols=["id"],
        )
        assert s.max_parallel_where == 50
        assert s.keep_cols == ["id"]


class TestSpore:
    def test_create(self):
        spore = Spore(cut=["age > 30", "income < 50000"], score=0.75, depth="lr")
        assert spore.cut == ["age > 30", "income < 50000"]
        assert spore.score == 0.75
        assert spore.depth == "lr"

    def test_empty_cut(self):
        spore = Spore(cut=[], score=0.0, depth="")
        assert spore.cut == []


class TestPilz:
    def test_get_where_sql(self):
        pilz = Pilz(
            spore=[
                Spore(cut=["age > 30"], score=0.8, depth="l"),
                Spore(cut=["income < 50000"], score=-0.3, depth="r"),
            ],
            target="yes",
        )
        sql = pilz.get_where_sql()
        assert len(sql) == 2
        assert "WHEN" in sql[0]
        assert "age > 30" in sql[0]
        assert "0.8" in sql[0]
        assert "income < 50000" in sql[1]
        assert "-0.3" in sql[1]

    def test_get_sql(self):
        pilz = Pilz(
            spore=[Spore(cut=["x > 1"], score=0.5, depth="l")],
            target="yes",
        )
        sql = pilz.get_sql("res_0")
        assert "CASE" in sql
        assert "END AS res_0" in sql
        assert "x > 1" in sql

    def test_get_split_sql(self):
        pilz = Pilz(
            spore=[
                Spore(cut=["a=1"], score=0.5, depth="l"),
                Spore(cut=["b=2"], score=-0.3, depth="r"),
            ],
            target="yes",
        )
        result = pilz.get_split_sql(max_parallel_where=1)
        assert len(result) == 2
        for r in result:
            assert "CASE" in r
            assert "ELSE CAST(0 AS DOUBLE)" in r
            assert "END AS res_" in r

    def test_get_split_sql_single_batch(self):
        pilz = Pilz(
            spore=[
                Spore(cut=["a=1"], score=0.5, depth="l"),
                Spore(cut=["b=2"], score=-0.3, depth="r"),
            ],
            target="yes",
        )
        result = pilz.get_split_sql(max_parallel_where=10)
        assert len(result) == 1


class TestPilze:
    def test_get_sql(self):
        pilz_a = Pilz(
            spore=[Spore(cut=["x > 1"], score=0.5, depth="l")],
            target="yes",
        )
        pilze = Pilze(pilze={"tree_0": pilz_a}, target="yes")
        sql_dict = pilze.get_sql()
        assert "res_tree_0" in sql_dict
        assert "CASE" in sql_dict["res_tree_0"]

    def test_multiple_trees(self):
        p1 = Pilz(spore=[Spore(cut=["a=1"], score=1.0, depth="l")], target="yes")
        p2 = Pilz(spore=[Spore(cut=["b=2"], score=0.5, depth="r")], target="yes")
        pilze = Pilze(pilze={"t1": p1, "t2": p2}, target="yes")
        sql = pilze.get_sql()
        assert "res_t1" in sql
        assert "res_t2" in sql


class TestSympyToSqlHelper:
    def setup_method(self):
        SympyToSqlHelper.columns = ["age", "income"]

    def test_eq(self):
        expr = Eq(Symbol("age"), Symbol("30"))
        result = SympyToSqlHelper.to_sql_where(expr)
        assert '"age"=' in result

    def test_and(self):
        expr = And(
            Eq(Symbol("age"), Symbol("30")), Gt(Symbol("income"), Symbol("50000"))
        )
        result = SympyToSqlHelper.to_sql_where(expr)
        assert "AND" in result

    def test_or(self):
        expr = Or(Eq(Symbol("age"), Symbol("30")), Eq(Symbol("age"), Symbol("40")))
        result = SympyToSqlHelper.to_sql_where(expr)
        assert "OR" in result

    def test_not(self):
        expr = Not(And(Eq(Symbol("age"), Symbol("30")), Eq(Symbol("income"), Symbol("50"))))
        result = SympyToSqlHelper.to_sql_where(expr)
        assert "NOT" in result

    def test_lt(self):
        expr = Lt(Symbol("age"), Symbol("50"))
        result = SympyToSqlHelper.to_sql_where(expr)
        assert '"age"<' in result

    def test_gt(self):
        expr = Gt(Symbol("income"), Symbol("100"))
        result = SympyToSqlHelper.to_sql_where(expr)
        assert '"income">' in result

    def test_le(self):
        expr = Le(Symbol("age"), Symbol("30"))
        result = SympyToSqlHelper.to_sql_where(expr)
        assert '"age"<=' in result

    def test_ge(self):
        expr = Ge(Symbol("income"), Symbol("50000"))
        result = SympyToSqlHelper.to_sql_where(expr)
        assert '"income">=' in result

    def test_ne(self):
        expr = Ne(Symbol("age"), Symbol("30"))
        result = SympyToSqlHelper.to_sql_where(expr)
        assert '"age"<>' in result

    def test_column_name_quoted(self):
        SympyToSqlHelper.columns = ["age"]
        expr = Eq(Symbol("age"), Symbol("30"))
        result = SympyToSqlHelper.to_sql_where(expr)
        assert '"age"' in result

    def test_value_not_column_quoted_as_string(self):
        SympyToSqlHelper.columns = []
        expr = Eq(Symbol("x"), Symbol("1"))
        result = SympyToSqlHelper.to_sql_where(expr)
        assert "'x'" in result or "x" in result

    def test_number_rendered(self):
        SympyToSqlHelper.columns = ["age"]
        expr = Eq(Symbol("age"), 30)
        result = SympyToSqlHelper.to_sql_where(expr)
        assert "30" in result


class TestSympyContainer:
    def test_eq_operator(self):
        c = SympyContainer(feat_name="age", operator="=", value=30, assumptions={})
        expr = c.get_sympy()
        assert isinstance(expr, Eq)

    def test_ne_operator(self):
        c = SympyContainer(feat_name="age", operator="!=", value=30, assumptions={})
        expr = c.get_sympy()
        assert isinstance(expr, Ne)

    def test_lt_operator(self):
        c = SympyContainer(feat_name="age", operator="<", value=30, assumptions={})
        expr = c.get_sympy()
        assert isinstance(expr, Lt)

    def test_le_operator(self):
        c = SympyContainer(feat_name="age", operator="<=", value=30, assumptions={})
        expr = c.get_sympy()
        assert isinstance(expr, Le)

    def test_gt_operator(self):
        c = SympyContainer(feat_name="age", operator=">", value=30, assumptions={})
        expr = c.get_sympy()
        assert isinstance(expr, Gt)

    def test_ge_operator(self):
        c = SympyContainer(feat_name="age", operator=">=", value=30, assumptions={})
        expr = c.get_sympy()
        assert isinstance(expr, Ge)

    def test_in_operator(self):
        c = SympyContainer(
            feat_name="color", operator="in", value=["red", "blue"], assumptions={}
        )
        expr = c.get_sympy()
        assert isinstance(expr, Or)

    def test_not_in_operator(self):
        c = SympyContainer(
            feat_name="color", operator="not in", value=["red", "blue"], assumptions={}
        )
        expr = c.get_sympy()
        assert isinstance(expr, Not)

    def test_between_operator(self):
        c = SympyContainer(
            feat_name="age", operator="between", value=[20, 30], assumptions={}
        )
        expr = c.get_sympy()
        assert isinstance(expr, And)


class TestFilter:
    def test_sql(self):
        SympyToSqlHelper.columns = ["age"]
        f = Filter(combine=Eq(Symbol("age"), Symbol("30")))
        sql = f.sql()
        assert "=" in sql

    def test_sql_inverted(self):
        SympyToSqlHelper.columns = ["age", "income"]
        f = Filter(combine=And(Eq(Symbol("age"), Symbol("30")), Eq(Symbol("income"), Symbol("50"))))
        sql = f.sql(do_invert=True)
        assert "NOT" in sql

    def test_sql_and(self):
        SympyToSqlHelper.columns = ["age"]
        f = Filter(combine=And(Eq(Symbol("age"), Symbol("30")), Eq(Symbol("age"), Symbol("40"))))
        sql = f.sql()
        assert "AND" in sql


class TestCatCats:
    def test_labels(self):
        cc = CatCats(mapping={"a": "0", "b": "0", "c": "1"}, default="0", feat_name="color")
        assert set(cc.labels) == {"0", "1"}

    def test_inverted_mapping(self):
        cc = CatCats(mapping={"a": "0", "b": "0", "c": "1"}, default="0", feat_name="color")
        inv = cc.inverted_mapping
        assert set(inv["0"]) == {"a", "b"}
        assert inv["1"] == ["c"]

    def test_get_single_filter_eq(self):
        cc = CatCats(mapping={"a": "0", "b": "0", "c": "1"}, default="0", feat_name="color")
        f = cc.get_single_filter(1)
        assert f.operator == "="
        assert f.value == "c"

    def test_get_single_filter_not_in_for_default(self):
        cc = CatCats(
            mapping={"a": "0", "b": "1", "c": "1"}, default="0", feat_name="color"
        )
        f = cc.get_single_filter(0)
        assert f.operator == "not in"
        assert set(f.value) == {"b", "c"}

    def test_get_single_filter_in_for_multival(self):
        cc = CatCats(
            mapping={"a": "0", "b": "1", "c": "1"}, default="0", feat_name="color"
        )
        f = cc.get_single_filter(1)
        assert f.operator == "in"
        assert set(f.value) == {"b", "c"}


class TestContCats:
    def test_get_single_filter_first(self):
        cc = ContCats(cuts=[10.0, 20.0, 30.0], labels=["low", "mid", "high"], feat_name="age")
        f = cc.get_single_filter(0)
        assert f.operator == "<="
        assert f.value == 10.0

    def test_get_single_filter_last(self):
        cc = ContCats(cuts=[10.0, 20.0, 30.0], labels=["low", "mid", "high"], feat_name="age")
        f = cc.get_single_filter(2)
        assert f.operator == ">"
        assert f.value == 20.0

    def test_get_single_filter_mid(self):
        cc = ContCats(cuts=[10.0, 20.0, 30.0], labels=["low", "mid", "high"], feat_name="age")
        f = cc.get_single_filter(1)
        assert f.operator == "between"
        assert f.value == [10.0, 20.0]

    def test_get_single_filter_mid_two_cuts(self):
        cc = ContCats(cuts=[5.0, 15.0], labels=["low", "mid", "high"], feat_name="age")
        f = cc.get_single_filter(1)
        assert f.operator == "between"
        assert f.value == [5.0, 15.0]

    def test_single_cut_three_labels_first(self):
        cc = ContCats(cuts=[10.0], labels=["low", "mid", "high"], feat_name="age")
        f = cc.get_single_filter(0)
        assert f.operator == "<="
        assert f.value == 10.0

    def test_single_cut_last(self):
        cc = ContCats(cuts=[10.0], labels=["low", "high"], feat_name="age")
        f = cc.get_single_filter(1)
        assert f.operator == ">"
        assert f.value == 10.0
