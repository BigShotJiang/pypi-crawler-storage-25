import html


def fence_mermaid(source, language, class_name, options, md, **kwargs):
    return f'<div class="mermaid">{html.unescape(source)}</div>'
