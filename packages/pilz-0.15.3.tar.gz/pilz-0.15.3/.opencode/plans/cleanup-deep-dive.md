# Plan: Clean up Deep Dive Pages

## 1. `docs/training-internals.md`

### Remove
- All pseudo-code (lines 98-130, 136-234, 240-270, 276-343) — replace with actual source code references
- Stale placeholder mermaid (Start→Process→End at lines 373-379)
- Duplicate mermaid diagrams (data caching at lines 382-410, parallel trees at lines 507-524)
- Dead SVG references (6x `images/training_internals_*.svg`)
- Broken text fragments (line 98 `ee_index):`, line 428-429 truncated score calc)

### Replace With
- A concise architecture overview using the existing clean mermaid
- The `run()` main loop with actual code ref from `train.py` (the per-target/per-tree loop)
- The recursive `train_pilz()` function with actual code ref from `train.py:100-151` (similar to three-way-splits.md)
- `cater()` with actual code ref from `train.py:192-202`
- `counter()` with actual code ref from `train.py:153-190`
- `make_spore()` with actual code ref from `train.py:85-98`
- `is_final_size()` with actual code ref from `dataframes.py:435-439`
- Data caching with actual code ref from `darkwing.py` (get_cached_train_df)
- Score calculation with actual code ref from `dataframes.py:428-433`
- Keep the clean sequence diagram and architecture overview mermaids
- Fix the summary table with actual file paths
- Fix Next Steps with proper links (no `../` prefix)

## 2. `docs/sql-rules.md`

### Remove
- Stale placeholder mermaid (Start→Process→End at lines 180-186)
- Duplicate mermaid (small-vs-large model at lines 189-213 — already at lines 9-22)
- Dead SVG references (3x `images/sql_rules_*.svg`)
- Broken text (line 215: `rge rule sets:`)
- Truncated diagram + SQL fragment at lines 239-292 (duplicate batching content)

### Keep
- The SQL generation code examples (Pilz.get_sql, Pilz.get_split_sql)
- Deployment patterns (View, Materialized Table, Stored Procedure)
- Security considerations
- The batching explanation (one copy)
- Multiple trees / ensemble averaging
- Practical example with generated SQL

### Replace With
- Add source code references to `pilz.py` (get_sql, get_split_sql, Spore)
- Add source code references to `darkwing.py` (get_eval_sr, max_parallel_where)
- Keep the clean mermaids (architecture flow, batching)
- Fix the summary table

## After edits
1. Run `mkdocs build` to verify
2. Restart dev server
