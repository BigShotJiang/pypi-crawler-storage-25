# Plan: Align Getting Started with Core Concepts

## Changes to `docs/introduction.md`

### What's wrong
- Broken/truncated text throughout (lines 78, 95-108, 115, 131-134, 151, 170-173, 199, 220, 235-241, 251)
- Stale placeholder mermaid diagrams (Start→Process→End)
- Duplicate mermaid diagrams (multi-dimensional cut shown twice)
- Dead SVG image references (`images/introduction_*.svg`)
- Detailed Step 1-5 algorithm walkthrough duplicates what Core Concept pages now cover
- Mixed broken mermaids inside comparison table and core parameters section

### Rewrite plan
1. **Keep** "What is Pilz?" (lines 1-26) — mushroom analogy, SQL-native, multi-dimensional cuts. Keep the nature/ML mermaid.
2. **Replace** "The Core Idea: Multi-Dimensional Feature Cuts" with "How It Works" — a concise bullet-list overview of the 6 Core Concepts with links to each detail page. No inline algorithm walkthrough.
3. **Add** "Traditional vs Pilz" — one clean mermaid comparing traditional tree (needs 2 splits) vs Pilz (1 cut). This is the existing good diagram from the old section.
4. **Rewrite** "Comparison with Other Approaches" — clean table without broken mermaids mixed in.
5. **Rewrite** "Core Parameters" — clean table (was truncated with half a mermaid embedded).
6. **Add** "When to Use Pilz" — cleaned up from the broken text fragments.
7. **Keep** "Next Steps" — already aligned.

### Full replacement content

```markdown
# Introduction to Pilz

## What is Pilz?

Pilz (German for "mushroom" / "fungus") is a machine learning library for classification tasks. The name reflects its nature: like mushrooms are neither plants nor animals, Pilz is neither a traditional decision tree nor a neural network — it's something in between that captures the best of both worlds.

[Diagram: nature/ML analogy mermaid]

Unlike traditional ML tools that create "black box" models, Pilz generates **readable SQL rules** that you can directly deploy to your database.

The core innovation of Pilz is its ability to handle **feature correlations naturally** through multi-dimensional cuts.

## How It Works

Pilz evaluates feature combinations by their ability to separate target from non-target, with all data processing running through SQL. The algorithm is composed of several key concepts:

- **[Feature Categorization](feature-categorization.md)** — Every feature is binned into `n_cat` categories. Numerical features use quantile binning; categorical features are grouped by target rate similarity.
- **[Multi-Dimensional Splits](multi-dimensional-splits.md)** — Pilz splits on feature combinations directly, not one at a time. This captures correlations between features in a single split.
- **[SQL-Native Architecture](sql-native.md)** — All data processing runs through DuckDB SQL. Filters are SymPy boolean expressions translated to SQL WHERE clauses. Trained models generate CASE WHEN SQL.
- **[Three-Way Splits](three-way-splits.md)** — Each node splits into three branches: Left (non-target), Neutral (continue splitting), and Right (target).
- **[Downsampling](downsampling.md)** — At every node, Pilz independently samples target and non-target rows via ORDER BY RANDOM() LIMIT.
- **[Imbalanced Data](imbalanced-data.md)** — Because target and non-target are sampled independently with equal total weight, Pilz handles skewed distributions without SMOTE or class weights.

## Traditional vs Pilz

[Diagram: Traditional Tree (needs 2 splits for correlation) vs Pilz (1 multi-dimensional cut)]

## Comparison with Other Approaches

| Aspect | Neural Networks | Traditional Trees | Pilz |
|--------|----------------|-------------------|------|
| Feature correlations | Learned implicitly | Multiple splits | Single cut |
| Interpretability | Low | Medium | High (SQL) |
| Output format | Opaque weights | Tree structure | SQL rules |
| Data preprocessing | Often required | Minimal | Minimal |
| Imbalanced data | Needs tuning | Needs tuning | Native support |

## Core Parameters

| Parameter | What it controls |
|-----------|-----------------|
| n_dims | How many features to combine in a single split |
| n_cat | Number of bins per feature |
| max_depth | Maximum tree depth |
| neutral_faktor | Width of the neutral zone in three-way splits |
| max_eval_fit | Rows sampled per node |
| calcs_per_dim | Max combinations evaluated per dimension |

## When to Use Pilz

### Ideal For
- Tabular data
- Interpretability matters
- Feature correlations exist
- SQL-native deployment

### Not Ideal For
- Image/audio/video
- Very large datasets (may need tuning)
- No correlations (simpler models suffice)

## Next Steps
- [Installation](installation.md)
- [Feature Categorization](feature-categorization.md)
- [Multi-Dimensional Splits](multi-dimensional-splits.md)
```

---

## Changes to `docs/installation.md`

### What's wrong
- "What Just Happened?" mermaid (line 263) has a dead SVG image reference below it

### Fix plan
1. Remove the `![Diagram](images/installation_1.svg)` line
2. Add a brief note at the bottom of "What Just Happened?" connecting the Iris example to Core Concepts: "The trained model uses Feature Categorization to bin features, Multi-Dimensional Splits to find correlations, and SQL-native rules for scoring — all explained in the Core Concepts section."
3. No other changes needed — Next Steps are already aligned

---

## After edits
1. Run `mkdocs build` to verify
2. Run the `mkdocs-restart` skill to reload the dev server
