---
name: mkdocs-restart
description: Kill any running mkdocs server and restart it on port 8000
---

# MkDocs Restart

Kill any existing `mkdocs serve` process and start a fresh dev server.

## Steps

1. Kill any running mkdocs process:
   ```bash
   pkill -f "mkdocs serve" 2>/dev/null || true
   ```

2. Wait for the port to free up:
   ```bash
   sleep 1
   ```

3. Restart the server in the background:
   ```bash
   nohup .venv/bin/mkdocs serve -a 0.0.0.0:8000 > /tmp/mkdocs.log 2>&1 &
   ```

4. Wait for it to be ready and verify:
   ```bash
   sleep 4
   curl -s -o /dev/null -w "%{http_code}" http://0.0.0.0:8000/
   ```

5. Report the URL to the user: `http://0.0.0.0:8000/`
