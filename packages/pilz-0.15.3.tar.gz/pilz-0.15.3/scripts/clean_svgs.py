#!/usr/bin/env python3
"""Clean up markdown - remove duplicates and extra blank lines."""

import re
from pathlib import Path

DOCS_DIR = Path("docs")

def clean_file(md_path: Path) -> int:
    """Clean one markdown file."""
    content = md_path.read_text(encoding='utf-8')
    original = content
    
    # Remove all existing SVG image references
    content = re.sub(r'\n*!\[Diagram\]\(images/[^\)]+\.svg\)\n*', '\n\n', content)
    
    # Collapse multiple blank lines into at most 2
    content = re.sub(r'\n{4,}', '\n\n\n', content)
    
    # Find all mermaid blocks
    pattern = r'(```mermaid\s*\n)(.*?)(```)'
    matches = list(re.finditer(pattern, content, flags=re.DOTALL))
    
    if not matches:
        # No mermaid blocks, just clean and return
        content = content.strip() + '\n'
        if content != original:
            md_path.write_text(content, encoding='utf-8')
            return 1
        return 0
    
    # Reconstruct with one image per mermaid block
    parts = []
    last_end = 0
    
    for i, match in enumerate(matches):
        # Add content before this mermaid block
        before = content[last_end:match.start()]
        # Clean up blank lines before mermaid
        before = re.sub(r'\n+\n*', '\n\n', before).rstrip('\n')
        if before:
            parts.append(before)
            parts.append('\n\n')
        
        # Add the mermaid block
        parts.append(match.group(0))
        
        # Add single image
        safe_name = re.sub(r'[^a-zA-Z0-9]', '_', md_path.stem)[:30]
        filename = f"{safe_name}_{i+1}.svg"
        parts.append(f'\n\n![Diagram](images/{filename})\n\n')
        
        last_end = match.end()
    
    # Add remaining content
    after = content[last_end:].strip('\n')
    if after:
        parts.append('\n\n')
        parts.append(after)
    
    new_content = ''.join(parts).strip() + '\n'
    
    # Clean up any remaining issues
    new_content = re.sub(r'\n{4,}', '\n\n\n', new_content)
    
    if new_content != original:
        md_path.write_text(new_content, encoding='utf-8')
        return 1
    return 0

def main():
    print("Cleaning markdown files...")
    
    md_files = list(DOCS_DIR.glob("*.md"))
    
    cleaned = 0
    for md_file in md_files:
        updated = clean_file(md_file)
        if updated:
            print(f"Cleaned: {md_file.name}")
            cleaned += 1
    
    print(f"\nTotal files cleaned: {cleaned}")

if __name__ == "__main__":
    main()