#!/usr/bin/env python3
"""Render and embed SVG images after mermaid blocks (one per block)."""

import base64
import re
import subprocess
import sys
import time
from pathlib import Path

DOCS_DIR = Path("docs")
OUTPUT_DIR = DOCS_DIR / "images"
OUTPUT_DIR.mkdir(exist_ok=True)

def render_svg(code: str) -> str | None:
    """Render mermaid to SVG using curl with retries."""
    code = code.strip()
    b64 = base64.b64encode(code.encode()).decode().replace('+', '-').replace('/', '_').replace('=', '')
    url = f'https://mermaid.ink/svg/{b64}'
    
    for attempt in range(3):
        try:
            result = subprocess.run(
                ['curl', '-s', '-L', '-k', url],
                capture_output=True,
                text=True,
                timeout=30
            )
            if result.returncode == 0 and '<svg' in result.stdout:
                return result.stdout
            elif attempt < 2:
                time.sleep(2)
            else:
                print(f"API error", file=sys.stderr)
                return None
        except Exception as e:
            print(f"Error: {e}", file=sys.stderr)
            return None

def process_file(md_path: Path) -> int:
    """Process one markdown file."""
    content = md_path.read_text(encoding='utf-8')
    original = content
    
    # Remove existing duplicate image references first
    content = re.sub(r'\n\n!\[Diagram\]\(images/[^\)]+\.svg\)\n*', '\n\n', content)
    
    # Find all mermaid blocks and replace them
    pattern = r'(```mermaid\s*\n)(.*?)(```)'
    
    def replace_block(m):
        code = m.group(2).strip()
        
        # Generate filename
        safe_name = re.sub(r'[^a-zA-Z0-9]', '_', md_path.stem)[:30]
        
        # Find diagram number for this file
        counter[safe_name] = counter.get(safe_name, 0) + 1
        num = counter[safe_name]
        filename = f"{safe_name}_{num}.svg"
        
        svg_path = OUTPUT_DIR / filename
        
        if not svg_path.exists():
            svg = render_svg(code)
            if svg:
                svg_path.write_text(svg, encoding='utf-8')
                print(f"  Created: {filename}")
            else:
                print(f"  Failed: {filename}", file=sys.stderr)
        
        # Add SINGLE SVG embed after block
        return f'{m.group(1)}{code}{m.group(3)}\n\n![Diagram](images/{filename})'
    
    counter = {}
    new_content = re.sub(pattern, replace_block, content, flags=re.DOTALL)
    
    if new_content != original:
        md_path.write_text(new_content, encoding='utf-8')
        return 1
    return 0

def main():
    print("Processing markdown files...")
    
    md_files = list(DOCS_DIR.rglob("*.md"))
    md_files = [f for f in md_files if 'examples/' not in str(f)]
    
    updated = 0
    for md_file in md_files:
        print(f"\n{md_file.relative_to(DOCS_DIR)}:")
        updated += process_file(md_file)
    
    print(f"\nDone. Updated {updated} files.")

if __name__ == "__main__":
    main()