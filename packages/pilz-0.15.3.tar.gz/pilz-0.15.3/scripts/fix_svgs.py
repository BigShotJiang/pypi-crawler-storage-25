#!/usr/bin/env python3
"""Fix duplicate SVGs in markdown - set to exactly 1 per mermaid block."""

import re
from pathlib import Path

DOCS_DIR = Path("docs")

def fix_file(md_path: Path) -> int:
    """Fix one markdown file."""
    content = md_path.read_text(encoding='utf-8')
    original = content
    
    # Find all mermaid blocks
    pattern = r'(```mermaid\s*\n)(.*?)(```)'
    matches = list(re.finditer(pattern, content, flags=re.DOTALL))
    
    if not matches:
        return 0
    
    # Count mermaid blocks
    num_blocks = len(matches)
    
    # Remove all existing ![Diagram](images/...) lines
    content = re.sub(r'\n*!\[Diagram\]\(images/[^\)]+\.svg\)\n*', '\n\n', content)
    
    # Now add exactly one image after each mermaid block
    # Split content by mermaid blocks and insert images
    parts = []
    last_end = 0
    
    for i, match in enumerate(matches):
        # Get content before this mermaid block
        parts.append(content[last_end:match.start()])
        # Add the mermaid block itself
        parts.append(match.group(0))
        # Add single image
        safe_name = re.sub(r'[^a-zA-Z0-9]', '_', md_path.stem)[:30]
        filename = f"{safe_name}_{i+1}.svg"
        parts.append(f'\n\n![Diagram](images/{filename})\n\n')
        last_end = match.end()
    
    # Add remaining content
    parts.append(content[last_end:])
    
    new_content = ''.join(parts)
    
    if new_content != original:
        md_path.write_text(new_content, encoding='utf-8')
        return 1
    return 0

def main():
    print("Fixing markdown files...")
    
    md_files = list(DOCS_DIR.glob("*.md"))
    
    fixed = 0
    for md_file in md_files:
        updated = fix_file(md_file)
        if updated:
            print(f"Fixed: {md_file.name}")
            fixed += 1
    
    print(f"\nTotal files fixed: {fixed}")

if __name__ == "__main__":
    main()