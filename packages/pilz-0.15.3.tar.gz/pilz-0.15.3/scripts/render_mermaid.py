#!/usr/bin/env python3
"""Extract Mermaid diagrams from markdown files and render to SVG."""

import re
import base64
import time
from pathlib import Path

DOCS_DIR = Path("/Users/swayand/PycharmProjects/pilz/docs")
OUTPUT_DIR = DOCS_DIR / "images"
OUTPUT_DIR.mkdir(exist_ok=True)

MAX_RETRIES = 5
RETRY_DELAY = 2

def extract_mermaid_blocks(content: str) -> list[tuple[str, str]]:
    """Extract all mermaid code blocks with context for naming."""
    pattern = r'```mermaid\s*\n(.*?)```'
    matches = re.findall(pattern, content, re.DOTALL)
    
    results = []
    for i, code in enumerate(matches):
        # Try to find context for naming
        label = f"diagram_{i+1}"
        
        # Look for a heading before this block
        lines = content.split('\n')
        for j, line in enumerate(lines):
            if '```mermaid' in line:
                # Look backwards for a heading
                for k in range(j-1, max(0, j-10), -1):
                    if lines[k].startswith('#'):
                        # Extract text from heading
                        heading = lines[k].lstrip('#').strip()
                        # Make it filename-safe
                        safe = re.sub(r'[^a-zA-Z0-9]', '_', heading)[:30]
                        label = f"{safe}_{i+1}"
                        break
                break
        
        results.append((label, code.strip()))
    return results

def render_mermaid_svg(mermaid_code: str, retries: int = MAX_RETRIES) -> str | None:
    """Render Mermaid code to SVG using mermaid.ink API with base64 and retry."""
    import urllib.request
    
    # Remove any leading/trailing whitespace issues
    code = mermaid_code.strip()
    
    b64 = base64.b64encode(code.encode()).decode()
    b64_urlsafe = b64.replace('+', '-').replace('/', '_').replace('=', '')
    url = 'https://mermaid.ink/svg/' + b64_urlsafe
    
    for attempt in range(retries):
        try:
            req = urllib.request.Request(
                url, 
                headers={'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)'}
            )
            with urllib.request.urlopen(req, timeout=60) as response:
                return response.read().decode('utf-8')
        except Exception as e:
            if attempt < retries - 1:
                print(f"  Retry {attempt + 1}/{retries} after error: {e}")
                time.sleep(RETRY_DELAY)
            else:
                print(f"  Error after {retries} attempts: {e}")
                return None

def sanitize_filename(label: str) -> str:
    # Make descriptive names safe for filenames
    label = re.sub(r'[^a-zA-Z0-9_]', '_', label)
    label = re.sub(r'_+', '_', label)
    label = label.strip('_')
    return label[:50]

def main():
    md_files = sorted(DOCS_DIR.rglob("*.md"))
    # Skip example files for now
    md_files = [f for f in md_files if 'examples/' not in str(f)]
    print(f"Found {len(md_files)} markdown files")
    
    for md_file in md_files:
        content = md_file.read_text(encoding='utf-8')
        diagrams = extract_mermaid_blocks(content)
        
        if not diagrams:
            continue
            
        print(f"\n{md_file.relative_to(DOCS_DIR)}: {len(diagrams)} diagram(s)")
        
        for i, (label, code) in enumerate(diagrams):
            filename = sanitize_filename(label)
            if len(diagrams) > 1:
                filename = f"{md_file.stem}_{filename}"
            else:
                filename = f"{md_file.stem}_{filename}"
            
            svg_path = OUTPUT_DIR / f"{filename}.svg"
            
            # Always regenerate
            print(f"  Rendering: {filename}.svg")
            svg = render_mermaid_svg(code)
            if svg:
                svg_path.write_text(svg, encoding='utf-8')
                print(f"    ✓ Created")
            else:
                print(f"    ✗ Failed")

if __name__ == "__main__":
    main()