#!/usr/bin/env python3
"""Update markdown files to include SVG images alongside Mermaid blocks."""

import re
from pathlib import Path

DOCS_DIR = Path("/Users/swayand/PycharmProjects/pilz/docs")

def get_svg_embed(svg_path: Path, alt: str = "Diagram") -> str:
    """Generate markdown for embedding SVG."""
    return f'<img src="{svg_path}" alt="{alt}" />'

def process_file(md_file: Path):
    content = md_file.read_text(encoding='utf-8')
    original = content
    
    # Find all mermaid blocks and add SVG reference after each
    pattern = r'(```mermaid\s*\n.*?```)'
    
    def replace_match(match):
        block = match.group(1)
        
        # Try to find a heading before this block for context
        # Count which diagram this is
        return block + "\n\n<!-- SVG version: -->\n"
    
    # For now, let's add SVG image tags after each mermaid block
    # We'll add a comment showing the SVG location
    
    # Actually, let's just add the SVG as an optional addition
    # First, let's identify each mermaid block and its index
    
    diagrams = list(re.finditer(r'```mermaid\s*\n(.*?)```', content, re.DOTALL))
    
    # Work backwards to not mess up positions
    for i, match in enumerate(reversed(diagrams)):
        idx = len(diagrams) - 1 - i
        block = match.group(0)
        
        # Determine which SVG file this corresponds to
        stem = md_file.stem
        if stem == "mnist":
            svg_name = f"mnist_diagram_{idx+1}.svg"
        else:
            svg_name = f"{stem}_diagram_{idx+1}_{idx+1}.svg"
        
        svg_path = f"images/{svg_name}"
        
        # Add SVG embed after the mermaid block
        svg_embed = f'\n<img src="{svg_path}" alt="Diagram" />\n'
        
        # Insert after the mermaid block
        end_pos = match.end()
        content = content[:end_pos] + svg_embed + content[end_pos:]
    
    if content != original:
        md_file.write_text(content, encoding='utf-8')
        print(f"Updated: {md_file.relative_to(DOCS_DIR)}")

def main():
    md_files = list(DOCS_DIR.rglob("*.md"))
    for md_file in md_files:
        if 'images' in md_file.parts:
            continue
        if 'about.md' in str(md_file):
            continue
        process_file(md_file)

if __name__ == "__main__":
    main()