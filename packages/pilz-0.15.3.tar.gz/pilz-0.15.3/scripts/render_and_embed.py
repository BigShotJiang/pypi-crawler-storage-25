#!/usr/bin/env python3
"""Render all Mermaid diagrams to SVG and embed in markdown files."""

import base64
import re
import time
from pathlib import Path

DOCS_DIR = Path("/Users/swayand/PycharmProjects/pilz/docs")
OUTPUT_DIR = DOCS_DIR / "images"
OUTPUT_DIR.mkdir(exist_ok=True)

MAX_RETRIES = 3
RETRY_DELAY = 1

def extract_mermaid_blocks(content: str) -> list[tuple[int, str, str]]:
    """Extract mermaid blocks with line numbers and surrounding context."""
    pattern = r'(```mermaid\s*\n(.*?)```)'
    matches = re.finditer(pattern, content, re.DOTALL)
    
    results = []
    for match in matches:
        start_pos = match.start()
        code = match.group(2).strip()
        
        # Get context - look backwards for heading
        lines_before = content[:start_pos].split('\n')
        heading = ""
        for line in reversed(lines_before[-10:]):
            if line.strip().startswith('#'):
                heading = line.strip().lstrip('#').strip()[:40]
                break
        
        # Create label from heading + counter
        label = re.sub(r'[^a-zA-Z0-9]', '_', heading) if heading else "diagram"
        
        results.append((match.start(), label, code))
    
    return results

def render_mermaid_svg(mermaid_code: str, retries: int = MAX_RETRIES) -> str | None:
    """Render Mermaid code to SVG using mermaid.ink API."""
    import urllib.request
    
    code = mermaid_code.strip()
    b64 = base64.b64encode(code.encode()).decode()
    b64_urlsafe = b64.replace('+', '-').replace('/', '_').replace('=', '')
    url = 'https://mermaid.ink/svg/' + b64_urlsafe
    
    for attempt in range(retries):
        try:
            req = urllib.request.Request(
                url, 
                headers={'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)'}
            )
            with urllib.request.urlopen(req, timeout=30) as response:
                return response.read().decode('utf-8')
        except Exception as e:
            if attempt < retries - 1:
                time.sleep(RETRY_DELAY)
            else:
                print(f"  Error: {e}")
                return None

def process_file(md_file: Path) -> int:
    """Process a single markdown file."""
    content = md_file.read_text(encoding='utf-8')
    original = content
    
    diagrams = extract_mermaid_blocks(content)
    if not diagrams:
        return 0
    
    print(f"\n{md_file.name}: {len(diagrams)} diagram(s)")
    
    inserted = 0
    offset = 0
    
    for i, (pos, label, code) in enumerate(diagrams):
        # Generate unique filename
        safe_label = re.sub(r'[^a-zA-Z0-9]', '_', label)
        if safe_label.endswith('_'):
            safe_label = safe_label[:-1]
        if not safe_label:
            safe_label = f"diagram_{i+1}"
        
        filename = f"{md_file.stem}_{safe_label}_{i+1}.svg"
        svg_path = OUTPUT_DIR / filename
        
        # Check if already exists
        if not svg_path.exists():
            print(f"  Rendering: {filename}...")
            svg = render_mermaid_svg(code)
            if svg:
                svg_path.write_text(svg, encoding='utf-8')
                print(f"    ✓ Created")
                inserted += 1
            else:
                print(f"    ✗ Failed")
        else:
            print(f"  {filename} (exists)")
        
        # Add SVG embed after mermaid block
        svg_embed = f'\n\n<img src="images/{filename}" alt="{label}" />\n'
        
        # Find the end of this mermaid block
        end_pattern = r'```mermaid\s*\n' + re.escape(code) + r'```'
        match = re.search(end_pattern, content)
        if match:
            end_pos = match.end()
            content = content[:end_pos] + svg_embed + content[end_pos:]
    
    if content != original:
        md_file.write_text(content, encoding='utf-utf-8')
        return inserted
    
    return inserted

def main():
    print("=" * 60)
    print("Rendering Mermaid diagrams to SVG")
    print("=" * 60)
    
    md_files = sorted(DOCS_DIR.rglob("*.md"))
    # Skip example files
    md_files = [f for f in md_files if 'examples/' not in str(f) and 'images' not in str(f)]
    
    total = 0
    for md_file in md_files:
        count = process_file(md_file)
        total += count
    
    print(f"\n{'=' * 60}")
    print(f"Total: {total} new SVG files created")
    print(f"{'=' * 60}")

if __name__ == "__main__":
    main()