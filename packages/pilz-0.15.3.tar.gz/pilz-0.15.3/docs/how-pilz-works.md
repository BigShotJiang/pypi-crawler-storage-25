# How Pilz Works

Pilz is an experimental classification library that takes a different approach to machine learning. Instead of optimizing a loss function through gradient descent, it directly evaluates feature combinations by their ability to separate target from non-target, with all data processing running through SQL.

## Core Concepts

- [Feature Categorization](feature-categorization.md)
- [Multi-Dimensional Splits](multi-dimensional-splits.md)
- [SQL-Native Architecture](sql-native.md)
- [Three-Way Splits](three-way-splits.md)
- [Downsampling](downsampling.md)
- [Imbalanced Data](imbalanced-data.md)
