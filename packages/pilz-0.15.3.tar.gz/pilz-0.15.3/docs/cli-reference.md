# CLI Reference

Complete reference for all Pilz command-line commands.

## Commands Overview

```mermaid
flowchart TD
    A[pilz] --> B[train]
    A --> C[eval]
    A --> D[infer]
    A --> E[create-dc]
    
    B --> B1[Train models]
    C --> C1[Evaluate + metrics]
    D --> D1[Predictions only]
    E --> E1[Generate DataCard]
    
    style A fill:#e0f0ff
    style B fill:#ccffcc
    style C fill:#ffff99
    style D fill:#ffff99
    style E fill:#ccffcc
```
![Diagram](images/cli_reference_1.svg)

## train

Train Pilz models.

```bash
pilz train --datacard <file.yaml> --trainsettings <file.yaml>
```

### Options

| Option | Description |
|--------|-------------|
| `--datacard` | Path to DataCard YAML file |
| `--trainsettings` | Path to TrainSettings YAML file |

### Example

```bash
pilz train --datacard iris_dc.yaml --trainsettings train.yaml
```

## eval

Evaluate trained models and generate ROC curves.

```bash
pilz eval --datacard <file.yaml> --evalsettings <file.yaml>
```

### Options

| Option | Description |
|--------|-------------|
| `--datacard` | Path to DataCard YAML file |
| `--evalsettings` | Path to EvalSettings YAML file |

### Example

```bash
pilz eval --datacard iris_dc.yaml --evalsettings eval.yaml
```

### Output Files

- `{target}_roc.html` - ROC curve per class
- `all_roc.html` - Combined ROC curves
- `multi_class_result.html` - Per-class accuracy
- `{out_file}` - Prediction scores (CSV/Parquet)

## infer

Run inference only (no metrics).

```bash
pilz infer --datacard <file.yaml> --evalsettings <file.yaml>
```

### Options

| Option | Description |
|--------|-------------|
| `--datacard` | Path to DataCard YAML file |
| `--evalsettings` | Path to EvalSettings YAML file |

### Example

```bash
pilz infer --datacard iris_dc.yaml --evalsettings eval.yaml
```

### Use Cases

- Fast prediction on new data
- Batch scoring in production
- When you only need scores, not metrics

## create-dc

Generate a DataCard from a dataset.

```bash
pilz create-dc --src <path> --out <file.yaml>
```

### Options

| Option | Description |
|--------|-------------|
| `--src` | Path to CSV or Parquet file |
| `--out` | Output DataCard YAML file (optional, will prompt) |

### Example

```bash
pilz create-dc --src data.csv --out datacard.yaml
```

### Interactive Prompts

1. Select target column
2. For each feature, choose type (categorial/numerical)
3. Confirm missing value handling

## Quick Reference

| Command | Purpose |
|---------|---------|
| `pilz train --datacard X --trainsettings Y` | Train models |
| `pilz eval --datacard X --evalsettings Y` | Evaluate with metrics |
| `pilz infer --datacard X --evalsettings Y` | Fast predictions |
| `pilz create-dc --src X --out Y` | Generate DataCard |
