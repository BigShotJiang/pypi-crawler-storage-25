"""Tests for X3DH-style prekey records and the local prekey store."""

import base64
import time

import pytest

from dmp.core.crypto import DMPCrypto
from dmp.core.prekeys import (
    Prekey,
    PrekeyStore,
    RECORD_PREFIX,
    prekey_rrset_name,
)


class TestPrekeyRecord:
    def test_sign_parse_roundtrip(self):
        identity = DMPCrypto()
        sk = DMPCrypto()
        pk = Prekey(
            prekey_id=42,
            public_key=sk.get_public_key_bytes(),
            exp=int(time.time()) + 86400,
        )
        wire = pk.sign(identity)
        assert wire.startswith(RECORD_PREFIX)
        assert len(wire.encode("utf-8")) <= 255

        parsed = Prekey.parse_and_verify(wire, identity.get_signing_public_key_bytes())
        assert parsed is not None
        assert parsed.prekey_id == 42
        assert parsed.public_key == sk.get_public_key_bytes()

    def test_wrong_signer_rejected(self):
        real = DMPCrypto()
        impostor = DMPCrypto()
        sk = DMPCrypto()
        pk = Prekey(
            prekey_id=1,
            public_key=sk.get_public_key_bytes(),
            exp=int(time.time()) + 86400,
        )
        wire = pk.sign(real)
        # Verify against the wrong Ed25519 key → None.
        assert (
            Prekey.parse_and_verify(wire, impostor.get_signing_public_key_bytes())
            is None
        )

    def test_tampered_wire_rejected(self):
        identity = DMPCrypto()
        sk = DMPCrypto()
        pk = Prekey(
            prekey_id=1,
            public_key=sk.get_public_key_bytes(),
            exp=int(time.time()) + 86400,
        )
        wire = pk.sign(identity)
        # Flip a byte inside the signed body.
        mangled = bytearray(base64.b64decode(wire[len(RECORD_PREFIX) :]))
        mangled[0] ^= 0xFF
        tampered = RECORD_PREFIX + base64.b64encode(bytes(mangled)).decode("ascii")
        assert (
            Prekey.parse_and_verify(tampered, identity.get_signing_public_key_bytes())
            is None
        )

    def test_malformed_wire_returns_none(self):
        identity = DMPCrypto()
        assert (
            Prekey.parse_and_verify("garbage", identity.get_signing_public_key_bytes())
            is None
        )
        assert (
            Prekey.parse_and_verify(
                RECORD_PREFIX + "not-base64!!",
                identity.get_signing_public_key_bytes(),
            )
            is None
        )
        short = base64.b64encode(b"too short").decode("ascii")
        assert (
            Prekey.parse_and_verify(
                RECORD_PREFIX + short, identity.get_signing_public_key_bytes()
            )
            is None
        )

    def test_expiry_flag(self):
        now = int(time.time())
        past = Prekey(prekey_id=0, public_key=b"\x00" * 32, exp=now - 1)
        future = Prekey(prekey_id=0, public_key=b"\x00" * 32, exp=now + 60)
        assert past.is_expired()
        assert not future.is_expired()

    def test_far_future_exp_rejected(self):
        """Reject prekeys whose expiry is years out. A real pool
        refreshes daily; year-3000 expiries would let a sender pin
        a prekey in every recipient's local store forever, blocking
        identity rotation and consuming disk."""
        identity = DMPCrypto()
        now = int(time.time())
        pk = Prekey(
            prekey_id=42,
            public_key=identity.get_public_key_bytes(),
            exp=now + 365 * 86400,  # 1 year — past the 30-day cap
        )
        wire = pk.sign(identity)
        assert (
            Prekey.parse_and_verify(wire, identity.get_signing_public_key_bytes())
            is None
        )

    def test_exp_within_30_days_accepted(self):
        identity = DMPCrypto()
        now = int(time.time())
        pk = Prekey(
            prekey_id=43,
            public_key=identity.get_public_key_bytes(),
            exp=now + 29 * 86400,
        )
        wire = pk.sign(identity)
        result = Prekey.parse_and_verify(wire, identity.get_signing_public_key_bytes())
        assert result is not None
        assert result.prekey_id == 43


class TestPrekeyStore:
    def test_generate_and_lookup(self, tmp_path):
        store = PrekeyStore(str(tmp_path / "prekeys.db"))
        try:
            pool = store.generate_pool(count=5, ttl_seconds=3600)
            assert len(pool) == 5
            assert store.count_live() == 5

            # Lookup each sk.
            for prekey, sk in pool:
                fetched = store.get_private_key(prekey.prekey_id)
                assert fetched is not None
                # Can't compare X25519PrivateKey instances directly; compare
                # via their derived pubkeys.
                from cryptography.hazmat.primitives import serialization

                fetched_pub = fetched.public_key().public_bytes(
                    encoding=serialization.Encoding.Raw,
                    format=serialization.PublicFormat.Raw,
                )
                assert fetched_pub == prekey.public_key
        finally:
            store.close()

    def test_consume_deletes_private_key(self, tmp_path):
        store = PrekeyStore(str(tmp_path / "p.db"))
        try:
            pool = store.generate_pool(count=1, ttl_seconds=3600)
            pid = pool[0][0].prekey_id
            assert store.get_private_key(pid) is not None
            assert store.consume(pid)
            assert store.get_private_key(pid) is None
            assert not store.consume(pid)  # idempotent second delete
        finally:
            store.close()

    def test_expired_row_filtered_from_lookup(self, tmp_path):
        store = PrekeyStore(str(tmp_path / "p.db"))
        try:
            pool = store.generate_pool(count=1, ttl_seconds=0)
            # ttl=0 → exp == now; the query uses strict ">".
            assert store.get_private_key(pool[0][0].prekey_id) is None
        finally:
            store.close()

    def test_cleanup_expired(self, tmp_path):
        store = PrekeyStore(str(tmp_path / "p.db"))
        try:
            store.generate_pool(count=3, ttl_seconds=0)  # expired
            store.generate_pool(count=2, ttl_seconds=3600)  # live
            deleted = store.cleanup_expired()
            assert deleted == 3
            assert store.count_live() == 2
        finally:
            store.close()

    def test_persistence_across_reopen(self, tmp_path):
        db = str(tmp_path / "p.db")
        s1 = PrekeyStore(db)
        pool = s1.generate_pool(count=2, ttl_seconds=3600)
        pid = pool[0][0].prekey_id
        s1.close()

        s2 = PrekeyStore(db)
        try:
            assert s2.get_private_key(pid) is not None
        finally:
            s2.close()


class TestPrekeyStoreFilePerms:
    # The DB holds X25519 prekey private halves — local disclosure
    # equals forward-secrecy compromise for in-flight messages
    # against this client. A permissive umask on the parent dir
    # used to leave the DB and its WAL/SHM siblings world-readable
    # because chmod was applied only to the main DB file (codex P2
    # on the post-#52 fresh audit).

    def test_db_and_wal_shm_are_0600_after_init(self, tmp_path):
        import os
        import stat

        path = str(tmp_path / "secrets" / "prekeys.db")
        from dmp.core.prekeys import PrekeyStore

        store = PrekeyStore(path)
        try:
            # Force the WAL/SHM siblings to actually exist by
            # writing a row.
            store.generate_pool(count=1, ttl_seconds=3600)
            for suffix in ("", "-wal", "-shm"):
                p = path + suffix
                if not os.path.exists(p):
                    continue
                mode = stat.S_IMODE(os.stat(p).st_mode)
                assert mode & 0o077 == 0, f"{p!r} too permissive: 0o{mode:o}"
        finally:
            store.close()

    def test_parent_dir_is_0700_after_init(self, tmp_path):
        import os
        import stat

        parent = tmp_path / "secrets"
        path = str(parent / "prekeys.db")
        from dmp.core.prekeys import PrekeyStore

        PrekeyStore(path).close()
        mode = stat.S_IMODE(os.stat(parent).st_mode)
        assert mode & 0o077 == 0, f"parent dir too permissive: 0o{mode:o}"

    def test_existing_loose_parent_is_healed_on_reopen(self, tmp_path):
        # An operator upgrading from a pre-#53 build has an existing
        # parent dir created with the old, looser perms. The chmod
        # MUST run on every ``__init__``, not just first-time
        # creation, so the bad perms heal on the next start.
        import os
        import stat

        parent = tmp_path / "existing"
        parent.mkdir(mode=0o755)
        # Confirm the loose mode before init.
        before = stat.S_IMODE(os.stat(parent).st_mode)
        assert before & 0o077 != 0
        path = str(parent / "prekeys.db")
        from dmp.core.prekeys import PrekeyStore

        PrekeyStore(path).close()
        after = stat.S_IMODE(os.stat(parent).st_mode)
        assert after & 0o077 == 0, f"loose parent dir not healed: 0o{after:o}"


class TestPrekeyStoreSchemaVersioning:
    """``PRAGMA user_version`` migration ladder for the prekey store.

    Pre-versioning binaries left ``user_version=0`` and ran an inline
    column-presence check to add ``wire_record`` for v1→v2. The new
    versioning makes that step explicit and stamps the version so future
    bumps don't have to re-derive the schema state from PRAGMA
    table_info every open.
    """

    def test_fresh_db_is_stamped_at_current_version(self, tmp_path):
        from dmp.core.prekeys import _SCHEMA_VERSION

        db = str(tmp_path / "fresh.db")
        store = PrekeyStore(db)
        try:
            stored = store._conn.execute("PRAGMA user_version").fetchone()[0]
            assert stored == _SCHEMA_VERSION
        finally:
            store.close()

    def test_legacy_pre_wire_record_db_migrates_to_v2(self, tmp_path):
        """A db created by the very first prekey-store binary (no
        wire_record column, user_version unstamped) opens cleanly: the
        v1→v2 step adds the column and stamps the version. Existing
        rows are preserved."""
        import sqlite3

        db = str(tmp_path / "legacy.db")
        # Mimic the original v1 schema: no wire_record column.
        legacy = sqlite3.connect(db, isolation_level=None)
        legacy.executescript("""
            CREATE TABLE prekeys (
                prekey_id INTEGER PRIMARY KEY,
                private_key BLOB NOT NULL,
                public_key BLOB NOT NULL,
                exp INTEGER NOT NULL,
                created_at INTEGER NOT NULL
            );
            """)
        legacy.execute(
            "INSERT INTO prekeys(prekey_id, private_key, public_key, "
            "exp, created_at) VALUES(?, ?, ?, ?, ?)",
            (42, b"\x01" * 32, b"\x02" * 32, 9_999_999_999, 100),
        )
        legacy.close()

        store = PrekeyStore(db)
        try:
            stored = store._conn.execute("PRAGMA user_version").fetchone()[0]
            assert stored == 2
            cols = {
                row[1]
                for row in store._conn.execute("PRAGMA table_info(prekeys)").fetchall()
            }
            assert "wire_record" in cols
            # Old row still findable. get_private_key returns the
            # constructed X25519PrivateKey, not raw bytes; existence is
            # what the migration test cares about.
            assert store.get_private_key(42) is not None
        finally:
            store.close()

    def test_legacy_v1_5_with_wire_record_but_unstamped(self, tmp_path):
        """Some pre-versioning binaries DID add wire_record via the old
        inline migration but never stamped user_version. The v1→v2 step
        must skip the duplicate ALTER (sqlite would raise) and just
        stamp the version."""
        import sqlite3

        db = str(tmp_path / "legacy_with_wr.db")
        legacy = sqlite3.connect(db, isolation_level=None)
        legacy.executescript("""
            CREATE TABLE prekeys (
                prekey_id INTEGER PRIMARY KEY,
                private_key BLOB NOT NULL,
                public_key BLOB NOT NULL,
                exp INTEGER NOT NULL,
                created_at INTEGER NOT NULL,
                wire_record TEXT DEFAULT ''
            );
            """)
        legacy.close()

        store = PrekeyStore(db)
        try:
            stored = store._conn.execute("PRAGMA user_version").fetchone()[0]
            assert stored == 2
        finally:
            store.close()

    def test_future_version_db_refuses_to_open(self, tmp_path):
        import sqlite3

        from dmp.core.prekeys import _SCHEMA_VERSION

        db = str(tmp_path / "future.db")
        future = sqlite3.connect(db, isolation_level=None)
        future.executescript("""
            CREATE TABLE prekeys (
                prekey_id INTEGER PRIMARY KEY,
                private_key BLOB NOT NULL,
                public_key BLOB NOT NULL,
                exp INTEGER NOT NULL,
                created_at INTEGER NOT NULL,
                wire_record TEXT DEFAULT ''
            );
            """)
        future.execute(f"PRAGMA user_version = {_SCHEMA_VERSION + 5}")
        future.close()

        with pytest.raises(RuntimeError, match="schema version"):
            PrekeyStore(db)

    def test_migrate_uses_begin_immediate(self):
        """Structural assertion: ``_migrate`` wraps the read-then-write
        in ``BEGIN IMMEDIATE`` so two ``PrekeyStore`` instances opening
        the same legacy db can't both read ``user_version=0`` and race
        the ALTER (sqlite would raise ``duplicate column name`` on the
        second).

        We assert the source contains ``BEGIN IMMEDIATE`` rather than
        running a thread race, because the dynamic test is timing-
        fragile under full-suite load (sqlite WAL setup + 8 threads
        contending on the same file mid-suite produces sporadic
        ``database is locked`` even with timeout=30s). The structural
        property is what we actually rely on; the dynamic version was
        overkill and unstable.
        """
        import inspect

        src = inspect.getsource(PrekeyStore._migrate)
        assert "BEGIN IMMEDIATE" in src, (
            "PrekeyStore._migrate must take a reserved write lock to "
            "serialize concurrent migrations across PrekeyStore instances"
        )
        assert "ROLLBACK" in src, "_migrate must release the lock on failure"

    # NOTE: dynamic concurrent-open test deliberately removed.
    #
    # An earlier version spawned N threads each opening PrekeyStore
    # against the same legacy db and asserted no errors. Even at N=3
    # under busy CI it raised ``database is locked`` — not because of
    # the migration's BEGIN IMMEDIATE (which is the property the test
    # was meant to defend) but because sqlite's WAL-mode setup itself
    # (``PRAGMA journal_mode=WAL`` on a brand-new file) takes a brief
    # write lock, and 3 threads contending on that lock during py3.12
    # CI's tighter scheduling routinely lost the dice within sqlite's
    # busy-timeout. The fix would require either serializing opens via
    # a process-wide lock (heavy, unrelated to the schema-versioning
    # property), or sequencing the WAL setup before any thread reaches
    # ``_migrate`` (also unrelated).
    #
    # The structural test ``test_migrate_uses_begin_immediate`` above
    # is sufficient: it asserts the source contains BEGIN IMMEDIATE
    # and ROLLBACK, which is the cross-connection-safety property
    # that actually matters. The dynamic test was theatre.


class TestClaimSk:
    """``PrekeyStore.claim_sk`` atomically returns the sk and deletes
    the row. Replaces the previous get + decrypt + consume sequence on
    the receive path so the sk is gone from disk before decrypt
    starts. Closes the crash-window the old sequence had where a
    crash between successful decrypt and `consume()` left the sk
    on disk for a later disk-compromise attacker."""

    def test_returns_sk_and_wire_then_deletes_row(self, tmp_path):
        store = PrekeyStore(str(tmp_path / "p.db"))
        try:
            pool = store.generate_pool(count=1, ttl_seconds=3600)
            prekey, sk = pool[0]
            store.record_wire(prekey.prekey_id, "v=dmp1;t=prekey;d=...")

            claim = store.claim_sk(prekey.prekey_id)
            assert claim is not None
            claimed_sk, wire = claim
            # The returned sk derives the same pubkey as the original.
            from cryptography.hazmat.primitives import serialization

            claimed_pub = claimed_sk.public_key().public_bytes(
                encoding=serialization.Encoding.Raw,
                format=serialization.PublicFormat.Raw,
            )
            assert claimed_pub == prekey.public_key
            assert wire == "v=dmp1;t=prekey;d=..."
            # And the row is gone — second claim returns None.
            assert store.claim_sk(prekey.prekey_id) is None
            # ``get_private_key`` also reflects the deletion.
            assert store.get_private_key(prekey.prekey_id) is None
        finally:
            store.close()

    def test_missing_prekey_id_returns_none(self, tmp_path):
        store = PrekeyStore(str(tmp_path / "p.db"))
        try:
            assert store.claim_sk(99999) is None
        finally:
            store.close()

    def test_expired_prekey_returns_none(self, tmp_path):
        store = PrekeyStore(str(tmp_path / "p.db"))
        try:
            pool = store.generate_pool(count=1, ttl_seconds=0)
            prekey, _ = pool[0]
            # ttl=0 → exp == now; query uses strict ">" so already expired.
            assert store.claim_sk(prekey.prekey_id) is None
        finally:
            store.close()

    def test_zero_prekey_id_returns_none(self, tmp_path):
        """The NO_PREKEY sentinel is never claimable, even via this
        path — same reservation as get_private_key / consume."""
        store = PrekeyStore(str(tmp_path / "p.db"))
        try:
            assert store.claim_sk(0) is None
        finally:
            store.close()

    def test_concurrent_claims_only_one_wins_within_one_store(self, tmp_path):
        """Single-instance race: 8 threads sharing one PrekeyStore.
        The per-instance RLock alone is enough to serialize this
        case; the harder cross-process case is tested below via
        multiple PrekeyStore instances on the same db file.
        """
        import threading

        store = PrekeyStore(str(tmp_path / "p.db"))
        try:
            pool = store.generate_pool(count=1, ttl_seconds=3600)
            prekey, _ = pool[0]
            results: list = []
            lock = threading.Lock()
            start = threading.Event()

            def worker():
                start.wait()
                got = store.claim_sk(prekey.prekey_id)
                with lock:
                    results.append(got)

            threads = [threading.Thread(target=worker) for _ in range(8)]
            for t in threads:
                t.start()
            start.set()
            for t in threads:
                t.join(timeout=10)

            wins = [r for r in results if r is not None]
            assert len(wins) == 1, f"expected 1 winner, got {len(wins)}"
        finally:
            store.close()

    def test_concurrent_claims_across_separate_store_instances(self, tmp_path):
        """The harder case: each thread holds its OWN PrekeyStore on
        the same db file. The per-instance RLock no longer helps
        because each thread has a different instance. Atomicity has
        to come from sqlite itself — `DELETE ... RETURNING` is one
        statement, so exactly one issuer's RETURNING resolves to the
        row.

        This is the cross-process race shape: a node and an admin
        tool could plausibly both open the same db simultaneously.
        Two threads here is enough to expose the failure if the
        fix regressed to SELECT-then-DELETE under autocommit.
        """
        import threading

        seed = PrekeyStore(str(tmp_path / "p.db"))
        try:
            pool = seed.generate_pool(count=1, ttl_seconds=3600)
            prekey, _ = pool[0]
        finally:
            seed.close()

        results: list = []
        lock = threading.Lock()
        start = threading.Event()

        def worker():
            local = PrekeyStore(str(tmp_path / "p.db"))
            try:
                start.wait()
                got = local.claim_sk(prekey.prekey_id)
                with lock:
                    results.append(got)
            finally:
                local.close()

        # 16 threads × distinct PrekeyStore instances on the same db.
        # If claim_sk regressed to SELECT-then-DELETE in autocommit
        # mode, multiple of these could all read the row before any
        # delete committed, and all return non-None.
        threads = [threading.Thread(target=worker) for _ in range(16)]
        for t in threads:
            t.start()
        start.set()
        for t in threads:
            t.join(timeout=15)

        wins = [r for r in results if r is not None]
        assert len(wins) == 1, (
            f"DELETE ... RETURNING must be atomic across separate "
            f"connections; got {len(wins)} winners (expected 1)"
        )

    def test_returns_none_when_wire_record_was_never_set(self, tmp_path):
        """Pool generation creates the row with wire_record=''. If
        the caller never recorded the published wire (e.g. publish
        failed), claim_sk should still return the sk paired with
        None for the wire — the caller decides whether to bother
        with a DNS DELETE."""
        store = PrekeyStore(str(tmp_path / "p.db"))
        try:
            pool = store.generate_pool(count=1, ttl_seconds=3600)
            prekey, _ = pool[0]
            # Note: NOT calling record_wire — wire_record stays ''.
            claim = store.claim_sk(prekey.prekey_id)
            assert claim is not None
            sk, wire = claim
            assert sk is not None
            assert wire is None
        finally:
            store.close()


class TestPrekeyIdReservation:
    """``prekey_id = 0`` is reserved as the ``NO_PREKEY`` sentinel
    (see dmp/core/manifest.py). The pool generator must never return
    it — otherwise a sender that picked the prekey would silently
    fall back to the recipient's long-term X25519 key (no forward
    secrecy) without the manifest's ``prekey_id`` carrying any
    distinguishing signal.
    """

    def test_zero_prekey_id_is_skipped(self, tmp_path, monkeypatch):
        """Force ``secrets.randbits`` to return 0 on the first draw,
        then a usable value on the second. The generator must skip 0
        and produce a non-zero prekey_id on the second attempt.
        """
        from dmp.core import prekeys as mod

        store = mod.PrekeyStore(str(tmp_path / "p.db"))
        try:
            # Stateful patch: first call returns 0, every subsequent
            # call returns 12345.
            calls = {"n": 0}

            def fake_randbits(n_bits):
                calls["n"] += 1
                if calls["n"] == 1:
                    return 0
                return 12345

            monkeypatch.setattr(mod.secrets, "randbits", fake_randbits)
            pool = store.generate_pool(count=1, ttl_seconds=3600)
            assert len(pool) == 1
            prekey, _ = pool[0]
            # Reserved 0 was rejected; the second draw landed.
            assert prekey.prekey_id == 12345
            # And we made at least 2 draws.
            assert calls["n"] >= 2
        finally:
            store.close()

    def test_no_zero_id_in_a_large_pool(self, tmp_path):
        """Statistical sanity: generate many prekeys and verify none
        end up with ``prekey_id == 0``. Without the reservation, the
        2^-32 chance per draw means this rarely catches the bug —
        but combined with the targeted test above it confirms the
        guard fires in production usage too.
        """
        from dmp.core.manifest import NO_PREKEY
        from dmp.core.prekeys import PrekeyStore

        store = PrekeyStore(str(tmp_path / "pool.db"))
        try:
            pool = store.generate_pool(count=200, ttl_seconds=3600)
            ids = [pk.prekey_id for pk, _ in pool]
            assert NO_PREKEY == 0  # if the sentinel ever changes
            assert NO_PREKEY not in ids
        finally:
            store.close()

    def test_collision_retry_budget_still_works_with_zero_skip(
        self, tmp_path, monkeypatch
    ):
        """If every draw returns 0 (an extreme stuck-RNG scenario),
        the retry budget runs out and the generator raises rather
        than looping forever. Belt-and-suspenders: the generator's
        outer 10-retry bound covers both the collision case AND a
        pathological all-zero RNG.
        """
        from dmp.core import prekeys as mod

        store = mod.PrekeyStore(str(tmp_path / "stuck.db"))
        try:
            monkeypatch.setattr(mod.secrets, "randbits", lambda n: 0)
            with pytest.raises(RuntimeError, match="could not allocate"):
                store.generate_pool(count=1, ttl_seconds=3600)
        finally:
            store.close()

    def test_to_body_bytes_rejects_zero(self):
        """Codex P1: defense-in-depth at the wire layer. Even if a
        legacy / buggy / malicious caller constructs a Prekey with
        ``prekey_id=0``, ``to_body_bytes`` (and therefore ``sign``)
        must refuse — preventing publication of an ambiguous record.
        """
        pk = Prekey(prekey_id=0, public_key=b"\x01" * 32, exp=9_999_999_999)
        with pytest.raises(ValueError, match="reserved as NO_PREKEY"):
            pk.to_body_bytes()

    def test_from_body_bytes_rejects_zero(self):
        """Same wire-layer defense on the parse side: a signed prekey
        record carrying ``prekey_id=0`` must be rejected at parse
        time so a sender cannot pick it from DNS."""
        body = (
            (0).to_bytes(4, "big")  # prekey_id = 0
            + b"\x01" * 32  # public_key
            + (9_999_999_999).to_bytes(8, "big")  # exp
        )
        with pytest.raises(ValueError, match="reserved as NO_PREKEY"):
            Prekey.from_body_bytes(body)

    def test_parse_and_verify_returns_none_for_zero_id_record(self):
        """End-to-end: even a correctly-signed prekey record with
        ``prekey_id=0`` must NOT round-trip through
        ``parse_and_verify``. ``from_body_bytes`` raises ValueError
        on the zero id, which parse_and_verify converts to None.
        """
        from dmp.core.crypto import DMPCrypto

        identity = DMPCrypto()
        # Construct a body manually (since to_body_bytes refuses zero)
        # and sign it. This simulates a non-conforming peer publishing
        # the ambiguous record.
        body = (
            (0).to_bytes(4, "big")
            + b"\x01" * 32
            + (int(time.time()) + 86400).to_bytes(8, "big")
        )
        sig = identity.sign_data(body)
        wire = RECORD_PREFIX + base64.b64encode(body + sig).decode("ascii")
        # Even though the signature is valid, parse_and_verify must
        # reject the zero prekey_id — the wire-layer guard fires
        # before signature check matters for delivery.
        result = Prekey.parse_and_verify(wire, identity.get_signing_public_key_bytes())
        assert result is None

    def test_get_private_key_refuses_zero_even_if_row_exists(self, tmp_path):
        """Codex P2: a legacy/imported db could already have a row at
        ``prekey_id=0``. ``get_private_key`` must refuse the lookup
        regardless of what the table contains, so the receiver's
        decrypt path can't accidentally use it."""
        import sqlite3

        from dmp.core.prekeys import PrekeyStore

        path = str(tmp_path / "legacy_zero.db")
        # Create a v2 schema directly and inject a row at prekey_id=0,
        # mimicking a legacy/imported db that managed to slip 0 in.
        legacy = sqlite3.connect(path, isolation_level=None)
        legacy.executescript("""
            CREATE TABLE prekeys (
                prekey_id INTEGER PRIMARY KEY,
                private_key BLOB NOT NULL,
                public_key BLOB NOT NULL,
                exp INTEGER NOT NULL,
                created_at INTEGER NOT NULL,
                wire_record TEXT DEFAULT ''
            );
            """)
        legacy.execute(
            "INSERT INTO prekeys(prekey_id, private_key, public_key, "
            "exp, created_at) VALUES(?, ?, ?, ?, ?)",
            (0, b"\x05" * 32, b"\x06" * 32, 9_999_999_999, 100),
        )
        legacy.execute("PRAGMA user_version = 2")
        legacy.close()

        store = PrekeyStore(path)
        try:
            # The row exists — but the lookup must refuse the
            # reserved id.
            assert store.get_private_key(0) is None
            # Direct sql confirms the row IS still there (we don't
            # auto-delete legacy rows).
            row = store._conn.execute(
                "SELECT prekey_id FROM prekeys WHERE prekey_id = 0"
            ).fetchone()
            assert row is not None and row[0] == 0
        finally:
            store.close()

    def test_consume_refuses_zero(self, tmp_path):
        """``consume(0)`` must return False even if a legacy id=0
        row is present in the table. Same NO_PREKEY guarantee as
        ``get_private_key``."""
        import sqlite3

        from dmp.core.prekeys import PrekeyStore

        path = str(tmp_path / "legacy_zero_consume.db")
        legacy = sqlite3.connect(path, isolation_level=None)
        legacy.executescript("""
            CREATE TABLE prekeys (
                prekey_id INTEGER PRIMARY KEY,
                private_key BLOB NOT NULL,
                public_key BLOB NOT NULL,
                exp INTEGER NOT NULL,
                created_at INTEGER NOT NULL,
                wire_record TEXT DEFAULT ''
            );
            """)
        legacy.execute(
            "INSERT INTO prekeys(prekey_id, private_key, public_key, "
            "exp, created_at) VALUES(?, ?, ?, ?, ?)",
            (0, b"\x05" * 32, b"\x06" * 32, 9_999_999_999, 100),
        )
        legacy.execute("PRAGMA user_version = 2")
        legacy.close()

        store = PrekeyStore(path)
        try:
            # Refusal returns False without touching the row.
            assert store.consume(0) is False
            row = store._conn.execute(
                "SELECT prekey_id FROM prekeys WHERE prekey_id = 0"
            ).fetchone()
            assert row is not None
        finally:
            store.close()


class TestRrsetNaming:
    def test_hashed_label(self):
        name = prekey_rrset_name("alice", "mesh.example.com")
        assert name.startswith("prekeys.id-")
        assert name.endswith(".mesh.example.com")
        # Hash is stable.
        assert name == prekey_rrset_name("alice", "mesh.example.com")
        assert name != prekey_rrset_name("bob", "mesh.example.com")
