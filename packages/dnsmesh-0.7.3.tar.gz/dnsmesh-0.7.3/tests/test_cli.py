"""Tests for the `dmp` CLI.

Each test gets an isolated DMP_CONFIG_HOME so real user config isn't touched.
Network-dependent commands (send/recv) route through the in-memory store
exposed via a monkeypatched `_make_client`.
"""

from __future__ import annotations

import os
from pathlib import Path

import pytest
import yaml

from dmp import cli
from dmp.client.client import DMPClient
from dmp.network.memory import InMemoryDNSStore


@pytest.fixture
def config_home(tmp_path, monkeypatch):
    home = tmp_path / "dmp-home"
    monkeypatch.setenv("DMP_CONFIG_HOME", str(home))
    return home


@pytest.fixture
def shared_store(monkeypatch):
    """Force _make_client to use a shared in-memory store across test clients.

    Preserves the real CLI's persistent-replay-cache path so tests exercise
    that wiring too (one replay cache per config home / identity). Also
    monkeypatches `_DnsReader` so the identity-fetch path (which bypasses
    _make_client) sees the same shared store.
    """
    store = InMemoryDNSStore()

    def fake_make_client(config, passphrase, *, requires_network=True):
        # `requires_network` is accepted but ignored — the shared in-memory
        # store stands in for both cluster and legacy network paths, so
        # local-only commands and networked commands exercise the same
        # fake. The real _make_client uses the flag to decide whether to
        # call fetch_cluster_manifest; that branch is covered separately
        # in TestLocalOnlyClusterBootstrap.
        del requires_network
        from dmp.cli import _config_path

        replay_path = str(_config_path().parent / "replay_cache.json")
        client = DMPClient(
            config.username,
            passphrase,
            domain=config.domain,
            store=store,
            replay_cache_path=replay_path,
            allow_tofu=config.allow_tofu,
            intro_queue_path=":memory:",
            prekey_store_path=":memory:",
        )
        for name, entry in config.contacts.items():
            # Mirror the real _make_client: use the persisted
            # `domain` (cross-zone contacts added via
            # `identity fetch user@host --add`) or fall back to the
            # local config.domain. Back-compat for legacy
            # `{pub, spk}` entries missing the field.
            contact_domain = entry.get("domain", "") or config.domain
            client.add_contact(
                name,
                entry.get("pub", ""),
                domain=contact_domain,
                signing_key_hex=entry.get("spk", ""),
            )
        return client

    class _SharedStoreReader:
        def query_txt_record(self, name):
            return store.query_txt_record(name)

    def fake_dns_reader(host, port=5353, *, dnssec_required=False):
        # Accept the P0-4 kwarg even though the in-memory shim doesn't
        # exercise DNSSEC — keeps the test fixture in lockstep with
        # _make_reader's call shape so signature changes surface here
        # rather than as a TypeError swallowed mid-flow.
        del dnssec_required
        return _SharedStoreReader()

    monkeypatch.setattr(cli, "_make_client", fake_make_client)
    monkeypatch.setattr(cli, "_DnsReader", fake_dns_reader)
    return store


class TestInitAndIdentity:
    def test_init_writes_config(self, config_home, capsys):
        rc = cli.main(
            ["init", "alice", "--domain", "mesh.test", "--endpoint", "http://node:8053"]
        )
        assert rc == 0
        cfg = yaml.safe_load((config_home / "config.yaml").read_text())
        assert cfg["username"] == "alice"
        assert cfg["domain"] == "mesh.test"
        assert cfg["endpoint"] == "http://node:8053"
        # Per-identity random salt: 32 bytes = 64 hex chars.
        assert len(cfg["kdf_salt"]) == 64

    def test_init_generates_unique_salts_per_identity(
        self, config_home, tmp_path, monkeypatch
    ):
        """Two independent `dnsmesh init` runs must produce distinct salts."""
        cli.main(["init", "--no-default-resolvers", "alice", "--endpoint", "http://x"])
        first = yaml.safe_load((config_home / "config.yaml").read_text())["kdf_salt"]

        other_home = tmp_path / "dmp-other"
        monkeypatch.setenv("DMP_CONFIG_HOME", str(other_home))
        cli.main(["init", "--no-default-resolvers", "alice", "--endpoint", "http://x"])
        second = yaml.safe_load((other_home / "config.yaml").read_text())["kdf_salt"]

        assert first != second

    def test_init_refuses_overwrite_without_force(self, config_home):
        cli.main(["init", "--no-default-resolvers", "alice", "--endpoint", "http://a"])
        with pytest.raises(SystemExit) as exc:
            cli.main(
                ["init", "--no-default-resolvers", "bob", "--endpoint", "http://b"]
            )
        assert exc.value.code == 1

    def test_init_force_overwrites(self, config_home):
        cli.main(["init", "--no-default-resolvers", "alice", "--endpoint", "http://a"])
        rc = cli.main(
            [
                "init",
                "--no-default-resolvers",
                "bob",
                "--endpoint",
                "http://b",
                "--force",
            ]
        )
        assert rc == 0
        cfg = yaml.safe_load((config_home / "config.yaml").read_text())
        assert cfg["username"] == "bob"

    def test_identity_show_prints_keys(
        self, config_home, shared_store, monkeypatch, capsys
    ):
        cli.main(["init", "--no-default-resolvers", "alice", "--endpoint", "http://x"])
        monkeypatch.setenv("DMP_PASSPHRASE", "pw")
        rc = cli.main(["identity", "show"])
        assert rc == 0
        out = capsys.readouterr().out
        assert "username: alice" in out
        assert "public_key:" in out
        assert "signing_public_key:" in out

    def test_identity_show_json(self, config_home, shared_store, monkeypatch, capsys):
        cli.main(["init", "--no-default-resolvers", "alice", "--endpoint", "http://x"])
        capsys.readouterr()  # flush init output
        monkeypatch.setenv("DMP_PASSPHRASE", "pw")
        cli.main(["identity", "show", "--json"])
        out = capsys.readouterr().out
        import json

        parsed = json.loads(out)
        assert parsed["username"] == "alice"
        assert len(parsed["public_key"]) == 64  # 32 bytes hex


class TestIdentityPublishFetch:
    """`dmp identity publish` + `dmp identity fetch` + `--add`."""

    def test_publish_then_fetch_roundtrip(
        self, config_home, shared_store, monkeypatch, capsys
    ):
        """alice publishes, a second invocation as bob can fetch and add her."""
        # Alice sets up + publishes.
        cli.main(["init", "--no-default-resolvers", "alice", "--endpoint", "http://x"])
        capsys.readouterr()
        monkeypatch.setenv("DMP_PASSPHRASE", "alice-pass")
        cli.main(["identity", "publish"])
        assert "published identity" in capsys.readouterr().out

        # Bob's CLI (different config home; same shared in-memory store)
        # fetches alice's record and verifies it.
        bob_home = config_home.parent / "bob-home"
        monkeypatch.setenv("DMP_CONFIG_HOME", str(bob_home))
        cli.main(["init", "--no-default-resolvers", "bob", "--endpoint", "http://x"])
        capsys.readouterr()
        monkeypatch.setenv("DMP_PASSPHRASE", "bob-pass")
        cli.main(["identity", "fetch", "alice", "--json"])
        import json

        parsed = json.loads(capsys.readouterr().out)
        assert parsed["username"] == "alice"
        assert len(parsed["public_key"]) == 64  # hex

    def test_fetch_add_stores_contact(
        self, config_home, shared_store, monkeypatch, capsys
    ):
        cli.main(["init", "--no-default-resolvers", "alice", "--endpoint", "http://x"])
        monkeypatch.setenv("DMP_PASSPHRASE", "alice-pass")
        cli.main(["identity", "publish"])
        capsys.readouterr()

        bob_home = config_home.parent / "bob-home-2"
        monkeypatch.setenv("DMP_CONFIG_HOME", str(bob_home))
        cli.main(["init", "--no-default-resolvers", "bob", "--endpoint", "http://x"])
        monkeypatch.setenv("DMP_PASSPHRASE", "bob-pass")
        capsys.readouterr()

        cli.main(["identity", "fetch", "alice", "--add"])
        out = capsys.readouterr().out
        assert "added contact alice" in out

        cli.main(["contacts", "list"])
        assert "alice" in capsys.readouterr().out

    def test_fetch_missing_identity_errors(
        self, config_home, shared_store, monkeypatch
    ):
        cli.main(["init", "--no-default-resolvers", "alice", "--endpoint", "http://x"])
        monkeypatch.setenv("DMP_PASSPHRASE", "alice-pass")
        with pytest.raises(SystemExit) as exc:
            cli.main(["identity", "fetch", "nobody"])
        assert exc.value.code == 2

    def test_zone_anchored_publish_and_fetch(
        self, config_home, shared_store, monkeypatch, capsys
    ):
        """Identity published under a user-controlled zone resolves via
        `user@host` addresses instead of the hash-based shared-mesh name."""
        # alice initializes with her own zone; publish goes to dmp.alice.example.com
        cli.main(
            [
                "init",
                "alice",
                "--endpoint",
                "http://x",
                "--identity-domain",
                "alice.example.com",
            ]
        )
        capsys.readouterr()
        monkeypatch.setenv("DMP_PASSPHRASE", "alice-pass")
        cli.main(["identity", "publish"])
        out = capsys.readouterr().out
        assert "published identity to dmp.alice.example.com" in out
        assert "alice@alice.example.com" in out

        # Bob fetches via the zone-anchored address.
        bob_home = config_home.parent / "bob-zone"
        monkeypatch.setenv("DMP_CONFIG_HOME", str(bob_home))
        cli.main(["init", "--no-default-resolvers", "bob", "--endpoint", "http://x"])
        monkeypatch.setenv("DMP_PASSPHRASE", "bob-pass")
        capsys.readouterr()

        cli.main(["identity", "fetch", "alice@alice.example.com", "--add"])
        out = capsys.readouterr().out
        assert "added contact alice" in out

        cli.main(["contacts", "list"])
        assert "alice" in capsys.readouterr().out

    def test_zone_anchored_fetch_add_persists_remote_domain(
        self, config_home, shared_store, monkeypatch, capsys
    ):
        """`identity fetch user@host --add` stores `domain=host` on the contact.

        Regression for the rotation-chain cross-domain walk: without
        the remote host persisted, `_make_client` reconstructs the
        contact with the local effective domain and the walker queries
        the wrong zone's rotate RRset.
        """
        import yaml as _yaml

        # Alice publishes under her own zone.
        cli.main(
            [
                "init",
                "alice",
                "--endpoint",
                "http://x",
                "--identity-domain",
                "alice.example.com",
            ]
        )
        monkeypatch.setenv("DMP_PASSPHRASE", "alice-pass")
        cli.main(["identity", "publish"])
        capsys.readouterr()

        # Bob (different local domain) fetches + adds.
        bob_home = config_home.parent / "bob-cross-zone"
        monkeypatch.setenv("DMP_CONFIG_HOME", str(bob_home))
        cli.main(
            [
                "init",
                "--no-default-resolvers",
                "bob",
                "--endpoint",
                "http://x",
                "--domain",
                "bob.local",
            ]
        )
        monkeypatch.setenv("DMP_PASSPHRASE", "bob-pass")
        capsys.readouterr()

        cli.main(["identity", "fetch", "alice@alice.example.com", "--add"])

        cfg_data = _yaml.safe_load((bob_home / "config.yaml").read_text())
        # Codex round-23: contacts pinned via the `user@host` form are
        # keyed by the FULL canonical address (was: bare username).
        # Two contacts with the same left-half on different zones MUST
        # be distinguishable; the bare-name keying is reserved for
        # shared-mesh fetches without `@host`.
        entry = cfg_data["contacts"]["alice@alice.example.com"]
        # The persisted entry must carry the REMOTE host, not bob's
        # local domain. Rotation fallback reads this field.
        assert entry["domain"] == "alice.example.com"
        assert entry["pub"]
        assert entry["spk"]

    def test_zone_anchored_fetch_rejects_username_mismatch(
        self, config_home, shared_store, monkeypatch, capsys
    ):
        """An attacker who controls `alice.example.com` can't publish an
        identity record carrying username="bob" and have it stored as bob
        in a fetcher's contact list. The address's user part must match
        the record's username field."""
        from dmp.core.crypto import DMPCrypto
        from dmp.core.identity import (
            make_record,
            zone_anchored_identity_name,
        )

        # Skip normal publish — craft a record with mismatched username
        # directly and drop it in the shared store.
        attacker_crypto = DMPCrypto()
        record = make_record(attacker_crypto, "bob")  # record says "bob"
        wire = record.sign(attacker_crypto)
        shared_store.publish_txt_record(
            zone_anchored_identity_name("alice.example.com"),  # but at alice's zone
            wire,
        )

        # carol tries `dmp identity fetch alice@alice.example.com --add`.
        cli.main(["init", "--no-default-resolvers", "carol", "--endpoint", "http://x"])
        monkeypatch.setenv("DMP_PASSPHRASE", "carol-pass")
        capsys.readouterr()

        with pytest.raises(SystemExit) as exc:
            cli.main(["identity", "fetch", "alice@alice.example.com", "--add"])
        assert exc.value.code == 2

    def test_fetch_refuses_ambiguous_without_fingerprint(
        self, config_home, shared_store, monkeypatch, capsys
    ):
        """Two valid identity records at the same name force manual choice.

        An attacker who squats `id-{hash(alice)}.{domain}` before the real
        alice publishes creates an RRset with two valid self-signed
        records. Auto-picking the first one hands the attacker a win;
        instead, fetch dumps fingerprints and requires --accept-fingerprint.
        """
        from dmp.core.crypto import DMPCrypto
        from dmp.core.identity import identity_domain, make_record

        # Real alice publishes her identity.
        cli.main(["init", "--no-default-resolvers", "alice", "--endpoint", "http://x"])
        capsys.readouterr()
        monkeypatch.setenv("DMP_PASSPHRASE", "alice-pass")
        cli.main(["identity", "publish"])
        capsys.readouterr()

        # An attacker with a different keypair publishes another valid
        # identity record for username "alice" at the same DNS name.
        attacker = DMPCrypto()
        squat = make_record(attacker, "alice").sign(attacker)
        name = identity_domain("alice", "mesh.local")
        shared_store.publish_txt_record(name, squat)

        # Bob tries to fetch alice. Two records; auto-pick refused.
        bob_home = config_home.parent / "bob-squat-home"
        monkeypatch.setenv("DMP_CONFIG_HOME", str(bob_home))
        cli.main(["init", "--no-default-resolvers", "bob", "--endpoint", "http://x"])
        monkeypatch.setenv("DMP_PASSPHRASE", "bob-pass")
        capsys.readouterr()

        with pytest.raises(SystemExit) as exc:
            cli.main(["identity", "fetch", "alice", "--add"])
        assert exc.value.code == 2
        err = capsys.readouterr().err
        assert "ambiguous" in err
        assert "fingerprint=" in err
        assert "--accept-fingerprint" in err


class TestIdentityRotateExperimental:
    """`dmp identity rotate` — EXPERIMENTAL (M5.4).

    The CLI surface ships flagged experimental; the underlying wire
    format is subject to revision after the external crypto audit.
    """

    def test_rotate_without_flag_errors(
        self, config_home, shared_store, monkeypatch, capsys
    ):
        cli.main(["init", "--no-default-resolvers", "alice", "--endpoint", "http://x"])
        monkeypatch.setenv("DMP_PASSPHRASE", "alice-pass")
        monkeypatch.setenv("DMP_NEW_PASSPHRASE", "alice-new-pass")
        with pytest.raises(SystemExit) as exc:
            cli.main(["identity", "rotate", "--yes"])
        assert exc.value.code == 1
        err = capsys.readouterr().err
        assert "EXPERIMENTAL" in err
        assert "--experimental" in err

    def test_rotate_routine_publishes_rotation_only_no_revocation(
        self, config_home, shared_store, monkeypatch, capsys
    ):
        """Routine rotations (the default --reason) must NOT publish a
        RevocationRecord — doing so would abort the rotation-chain
        walker on every rotation-chain-enabled peer and break the
        auto-follow workflow. Routine = rotation only; contacts pick
        up the new key via chain walk.
        """
        cli.main(["init", "--no-default-resolvers", "alice", "--endpoint", "http://x"])
        capsys.readouterr()
        monkeypatch.setenv("DMP_PASSPHRASE", "alice-pass")
        monkeypatch.setenv("DMP_NEW_PASSPHRASE", "alice-new-pass")

        rc = cli.main(["identity", "rotate", "--yes", "--experimental"])
        assert rc == 0
        out = capsys.readouterr().out
        assert "published RotationRecord" in out
        # Routine path skips revocation; success output calls that out.
        assert "skipping RevocationRecord" in out
        assert "published new IdentityRecord" in out

        from dmp.core.rotation import (
            RECORD_PREFIX_REVOCATION,
            RECORD_PREFIX_ROTATION,
            rotation_rrset_name_user_identity,
        )

        rrset = rotation_rrset_name_user_identity("alice", "mesh.local")
        records = shared_store.query_txt_record(rrset)
        assert records is not None and len(records) == 1
        assert records[0].startswith(RECORD_PREFIX_ROTATION)
        assert not any(r.startswith(RECORD_PREFIX_REVOCATION) for r in records)

    def test_rotate_compromise_publishes_rotation_and_revocation(
        self, config_home, shared_store, monkeypatch, capsys
    ):
        """`--reason compromise` publishes BOTH a RotationRecord and a
        RevocationRecord of the old key. The revocation forces
        rotation-chain walkers to abort trust (correct — the old key
        is compromised, auto-follow would be unsafe) and makes
        non-rotation-aware fetchers filter the old IdentityRecord.
        """
        cli.main(["init", "--no-default-resolvers", "alice", "--endpoint", "http://x"])
        capsys.readouterr()
        monkeypatch.setenv("DMP_PASSPHRASE", "alice-pass")
        monkeypatch.setenv("DMP_NEW_PASSPHRASE", "alice-new-pass")

        rc = cli.main(
            ["identity", "rotate", "--yes", "--experimental", "--reason", "compromise"]
        )
        assert rc == 0
        out = capsys.readouterr().out
        assert "published RotationRecord" in out
        assert "published RevocationRecord" in out
        assert "reason=compromise" in out
        assert "published new IdentityRecord" in out

        from dmp.core.rotation import (
            RECORD_PREFIX_REVOCATION,
            RECORD_PREFIX_ROTATION,
            rotation_rrset_name_user_identity,
        )

        rrset = rotation_rrset_name_user_identity("alice", "mesh.local")
        records = shared_store.query_txt_record(rrset)
        assert records is not None and len(records) == 2
        kinds = sorted(r.split(";")[1] for r in records)
        assert kinds == ["t=revocation", "t=rotation"]

    def test_rotate_twice_fast_produces_distinct_seq(
        self, config_home, shared_store, monkeypatch, tmp_path, capsys
    ):
        """Two rotations fired within the same second must produce
        distinct `seq` values. The chain walker REJECTS same-seq hops
        (seq must strictly increase), so a second-resolution seq would
        leave the second rotation invisible. Fix: seq is
        int(time.time() * 1000), which gives >1000 distinct values
        per second — plenty for rapid-fire recovery scenarios.
        """
        from dmp.core.crypto import DMPCrypto
        from dmp.core.rotation import (
            RECORD_PREFIX_ROTATION,
            RotationRecord,
            rotation_rrset_name_user_identity,
        )

        cli.main(["init", "--no-default-resolvers", "alice", "--endpoint", "http://x"])
        capsys.readouterr()

        pp1 = tmp_path / "pp1.pp"
        pp1.write_text("alice-pass")
        pp2 = tmp_path / "pp2.pp"
        pp2.write_text("alice-pass-2")
        pp3 = tmp_path / "pp3.pp"
        pp3.write_text("alice-pass-3")

        # Point config at pp1; each --yes --new-passphrase-file rotate
        # atomically repoints the config so the next rotate loads the
        # new passphrase as its "current".
        cfg_path = config_home / "config.yaml"
        import yaml as _y

        doc = _y.safe_load(cfg_path.read_text())
        doc["passphrase_file"] = str(pp1)
        cfg_path.write_text(_y.safe_dump(doc, sort_keys=True))
        salt = bytes.fromhex(doc["kdf_salt"])
        monkeypatch.delenv("DMP_PASSPHRASE", raising=False)
        monkeypatch.delenv("DMP_NEW_PASSPHRASE", raising=False)

        # Rotate #1: pp1 → pp2.
        rc1 = cli.main(
            [
                "identity",
                "rotate",
                "--yes",
                "--experimental",
                "--new-passphrase-file",
                str(pp2),
            ]
        )
        assert rc1 == 0
        capsys.readouterr()

        # Rotate #2 IMMEDIATELY (no sleep). Config now points at pp2;
        # the new target is pp3. Same wall-clock second as rotate #1.
        rc2 = cli.main(
            [
                "identity",
                "rotate",
                "--yes",
                "--experimental",
                "--new-passphrase-file",
                str(pp3),
            ]
        )
        assert rc2 == 0
        capsys.readouterr()

        rrset = rotation_rrset_name_user_identity("alice", "mesh.local")
        records = shared_store.query_txt_record(rrset) or []
        rotations = [
            RotationRecord.parse_and_verify(r)
            for r in records
            if r.startswith(RECORD_PREFIX_ROTATION)
        ]
        rotations = [r for r in rotations if r is not None]

        pp2_spk = DMPCrypto.from_passphrase(
            "alice-pass-2", salt=salt
        ).get_signing_public_key_bytes()
        pp3_spk = DMPCrypto.from_passphrase(
            "alice-pass-3", salt=salt
        ).get_signing_public_key_bytes()

        seqs = {
            bytes(r.new_spk): r.seq
            for r in rotations
            if bytes(r.new_spk) in (pp2_spk, pp3_spk)
        }
        assert pp2_spk in seqs, "rotation #1 not present"
        assert pp3_spk in seqs, "rotation #2 not present"
        assert seqs[pp2_spk] != seqs[pp3_spk], (
            "two rotations in the same second produced the same seq — "
            "regression of the ms-resolution fix"
        )
        assert seqs[pp3_spk] > seqs[pp2_spk], "seq must strictly increase"

    def test_rotate_rejects_same_passphrase(
        self, config_home, shared_store, monkeypatch, capsys
    ):
        cli.main(["init", "--no-default-resolvers", "alice", "--endpoint", "http://x"])
        monkeypatch.setenv("DMP_PASSPHRASE", "alice-pass")
        monkeypatch.setenv("DMP_NEW_PASSPHRASE", "alice-pass")
        with pytest.raises(SystemExit) as exc:
            cli.main(["identity", "rotate", "--yes", "--experimental"])
        assert exc.value.code == 1

    def test_rotate_warning_banner_emitted(
        self, config_home, shared_store, monkeypatch, capsys
    ):
        cli.main(["init", "--no-default-resolvers", "alice", "--endpoint", "http://x"])
        capsys.readouterr()
        monkeypatch.setenv("DMP_PASSPHRASE", "alice-pass")
        monkeypatch.setenv("DMP_NEW_PASSPHRASE", "alice-new-pass")
        cli.main(["identity", "rotate", "--yes", "--experimental"])
        captured = capsys.readouterr()
        # Banner goes to stderr so it doesn't contaminate piped-to-json.
        assert "EXPERIMENTAL" in captured.err
        assert "draft" in captured.err or "change in v0.3.0" in captured.err

    def test_rotate_yes_swaps_local_identity_atomically(
        self, config_home, shared_store, monkeypatch, tmp_path, capsys
    ):
        """--yes + --new-passphrase-file atomically rewires the local
        config so that reloading + deriving with the new passphrase
        yields a keypair whose Ed25519 pubkey matches new_spk in the
        published RotationRecord. The kdf_salt MUST stay the same — the
        same salt + new passphrase is what derives the rotated keypair.
        """
        from dmp.core.crypto import DMPCrypto
        from dmp.core.rotation import (
            RECORD_PREFIX_ROTATION,
            RotationRecord,
            rotation_rrset_name_user_identity,
        )

        cli.main(["init", "--no-default-resolvers", "alice", "--endpoint", "http://x"])
        capsys.readouterr()

        # Seed the old passphrase via file (so we drive the full
        # "config points at a passphrase file" path, which is what
        # operators typically use).
        old_pp_file = tmp_path / "old.pp"
        old_pp_file.write_text("alice-pass")
        new_pp_file = tmp_path / "new.pp"
        new_pp_file.write_text("alice-new-pass")

        # Point config.passphrase_file at the old file.
        cfg_path = config_home / "config.yaml"
        cfg_text = cfg_path.read_text()
        # yaml rewrite: inject passphrase_file.
        import yaml as _y

        doc = _y.safe_load(cfg_text)
        doc["passphrase_file"] = str(old_pp_file)
        cfg_path.write_text(_y.safe_dump(doc, sort_keys=True))
        salt_before = doc["kdf_salt"]

        # DMP_PASSPHRASE must NOT be set or _load_passphrase prefers
        # the env var over the file path; clear it to exercise the
        # passphrase-file path.
        monkeypatch.delenv("DMP_PASSPHRASE", raising=False)
        monkeypatch.delenv("DMP_NEW_PASSPHRASE", raising=False)

        rc = cli.main(
            [
                "identity",
                "rotate",
                "--yes",
                "--experimental",
                "--new-passphrase-file",
                str(new_pp_file),
            ]
        )
        assert rc == 0
        out = capsys.readouterr().out
        assert "local identity swapped atomically" in out

        # Read back the config. Salt preserved, passphrase_file now
        # points at the NEW file.
        doc2 = _y.safe_load(cfg_path.read_text())
        assert doc2["kdf_salt"] == salt_before, "kdf_salt MUST be preserved"
        assert doc2["passphrase_file"] == str(new_pp_file)

        # Derive the identity with the NEW passphrase + preserved salt
        # — it must match the new_spk published in the RotationRecord.
        rrset = rotation_rrset_name_user_identity("alice", "mesh.local")
        records = shared_store.query_txt_record(rrset)
        assert records is not None
        rotations = [r for r in records if r.startswith(RECORD_PREFIX_ROTATION)]
        assert len(rotations) == 1
        rec = RotationRecord.parse_and_verify(rotations[0])
        assert rec is not None

        derived = DMPCrypto.from_passphrase(
            "alice-new-pass", salt=bytes.fromhex(salt_before)
        )
        assert derived.get_signing_public_key_bytes() == bytes(rec.new_spk)

    def test_rotate_warns_when_env_passphrase_mismatches(
        self, config_home, shared_store, monkeypatch, tmp_path, capsys
    ):
        """--yes --new-passphrase-file while DMP_PASSPHRASE is ALSO
        exported (and mismatches the file) must warn the operator and
        exit non-zero.

        `_load_passphrase` prefers the env var over the file. Without
        this detection, the command claims "atomic swap" but every
        subsequent invocation in the same shell keeps deriving the OLD
        identity. The warning text names the culprit env var so the
        fix is obvious.
        """
        cli.main(["init", "--no-default-resolvers", "alice", "--endpoint", "http://x"])
        capsys.readouterr()

        old_pp_file = tmp_path / "old.pp"
        old_pp_file.write_text("alice-pass")
        new_pp_file = tmp_path / "new.pp"
        new_pp_file.write_text("alice-new-pass")

        # Point config at the old file so rotate can load the old
        # identity; then ALSO export DMP_PASSPHRASE with a *different*
        # value from what will end up in the new-passphrase file.
        cfg_path = config_home / "config.yaml"
        import yaml as _y

        doc = _y.safe_load(cfg_path.read_text())
        doc["passphrase_file"] = str(old_pp_file)
        cfg_path.write_text(_y.safe_dump(doc, sort_keys=True))

        # DMP_PASSPHRASE == alice-pass (the OLD one). When rotate
        # completes, the config points at new_pp_file (content
        # "alice-new-pass"). Mismatch — must warn + exit non-zero.
        monkeypatch.setenv("DMP_PASSPHRASE", "alice-pass")
        monkeypatch.delenv("DMP_NEW_PASSPHRASE", raising=False)

        rc = cli.main(
            [
                "identity",
                "rotate",
                "--yes",
                "--experimental",
                "--new-passphrase-file",
                str(new_pp_file),
            ]
        )
        # Non-zero exit: the rotation did publish, but the env var is
        # going to undermine the swap until the operator fixes it.
        assert rc == 3
        captured = capsys.readouterr()
        stderr = captured.err
        assert "DMP_PASSPHRASE is set" in stderr
        assert "unset DMP_PASSPHRASE" in stderr or "export DMP_PASSPHRASE" in stderr

    def test_rotate_no_env_passphrase_no_warning(
        self, config_home, shared_store, monkeypatch, tmp_path, capsys
    ):
        """DMP_PASSPHRASE unset: --yes --new-passphrase-file exits 0
        with no env-mismatch warning (the only other path to
        `_load_passphrase` is the file, which we've already rewritten)."""
        cli.main(["init", "--no-default-resolvers", "alice", "--endpoint", "http://x"])
        capsys.readouterr()

        old_pp_file = tmp_path / "old.pp"
        old_pp_file.write_text("alice-pass")
        new_pp_file = tmp_path / "new.pp"
        new_pp_file.write_text("alice-new-pass")

        cfg_path = config_home / "config.yaml"
        import yaml as _y

        doc = _y.safe_load(cfg_path.read_text())
        doc["passphrase_file"] = str(old_pp_file)
        cfg_path.write_text(_y.safe_dump(doc, sort_keys=True))

        monkeypatch.delenv("DMP_PASSPHRASE", raising=False)
        monkeypatch.delenv("DMP_NEW_PASSPHRASE", raising=False)

        rc = cli.main(
            [
                "identity",
                "rotate",
                "--yes",
                "--experimental",
                "--new-passphrase-file",
                str(new_pp_file),
            ]
        )
        assert rc == 0
        captured = capsys.readouterr()
        assert "WARNING: DMP_PASSPHRASE" not in captured.err

    def test_rotate_compromise_reason_tags_revocation(
        self, config_home, shared_store, monkeypatch, capsys
    ):
        """--reason compromise propagates to reason_code on the revocation."""
        from dmp.core.rotation import (
            RECORD_PREFIX_REVOCATION,
            REASON_COMPROMISE,
            RevocationRecord,
            rotation_rrset_name_user_identity,
        )

        cli.main(["init", "--no-default-resolvers", "alice", "--endpoint", "http://x"])
        capsys.readouterr()
        monkeypatch.setenv("DMP_PASSPHRASE", "alice-pass")
        monkeypatch.setenv("DMP_NEW_PASSPHRASE", "alice-new-pass")

        rc = cli.main(
            [
                "identity",
                "rotate",
                "--yes",
                "--experimental",
                "--reason",
                "compromise",
            ]
        )
        assert rc == 0
        capsys.readouterr()

        rrset = rotation_rrset_name_user_identity("alice", "mesh.local")
        records = shared_store.query_txt_record(rrset)
        revocations = [r for r in records if r.startswith(RECORD_PREFIX_REVOCATION)]
        assert len(revocations) == 1
        rev = RevocationRecord.parse_and_verify(revocations[0])
        assert rev is not None
        assert rev.reason_code == REASON_COMPROMISE

    def test_identity_fetch_filters_revoked_records(
        self, config_home, shared_store, monkeypatch, capsys
    ):
        """Publish an old IdentityRecord keyed off the SAME salt the
        rotate command uses, rotate (which publishes new IdentityRecord
        + RevocationRecord of old), then `dmp identity fetch` returns
        the new identity and does NOT raise the ambiguous-error.
        """
        import json as _json
        import yaml as _y
        from dmp.core.crypto import DMPCrypto
        from dmp.core.identity import identity_domain, make_record

        cli.main(["init", "--no-default-resolvers", "alice", "--endpoint", "http://x"])
        capsys.readouterr()

        # Derive the OLD identity with the salt that `cmd_identity_rotate`
        # reads from config. Publishing this directly sidesteps the
        # test-fixture's DMPClient-without-kdf_salt quirk (which would
        # otherwise leave identity-publish and identity-rotate keyed off
        # two different salts, so no revocation would match).
        alice_doc = _y.safe_load((config_home / "config.yaml").read_text())
        alice_salt = bytes.fromhex(alice_doc["kdf_salt"])
        old_crypto = DMPCrypto.from_passphrase("alice-pass", salt=alice_salt)
        old_record = make_record(old_crypto, "alice")
        shared_store.publish_txt_record(
            identity_domain("alice", "mesh.local"),
            old_record.sign(old_crypto),
        )

        # Rotate with --reason compromise: publishes a RotationRecord +
        # Revocation of old + new IdentityRecord (all under the same
        # shared store). Routine rotations wouldn't publish a revocation,
        # so the fetch path can't use the revocation-filter to
        # disambiguate the two identity records.
        monkeypatch.setenv("DMP_PASSPHRASE", "alice-pass")
        monkeypatch.setenv("DMP_NEW_PASSPHRASE", "alice-new-pass")
        rc = cli.main(
            [
                "identity",
                "rotate",
                "--yes",
                "--experimental",
                "--reason",
                "compromise",
            ]
        )
        assert rc == 0
        capsys.readouterr()

        # At this point the identity RRset holds BOTH the old and new
        # IdentityRecords. A naive fetch would exit 2 with ambiguous.
        # With the revocation filter the OLD one is dropped.
        bob_home = config_home.parent / "bob-revoke-filter"
        monkeypatch.setenv("DMP_CONFIG_HOME", str(bob_home))
        cli.main(["init", "--no-default-resolvers", "bob", "--endpoint", "http://x"])
        capsys.readouterr()
        monkeypatch.setenv("DMP_PASSPHRASE", "bob-pass")

        rc = cli.main(["identity", "fetch", "alice", "--json"])
        assert rc == 0
        out = capsys.readouterr().out
        parsed = _json.loads(out)

        # The surviving identity must be the NEW one: its ed25519_spk
        # is the salt-derived key under the new passphrase.
        new_crypto = DMPCrypto.from_passphrase("alice-new-pass", salt=alice_salt)
        assert (
            parsed["signing_public_key"]
            == new_crypto.get_signing_public_key_bytes().hex()
        )

    def test_identity_fetch_routine_rotation_disambiguates_via_chain_head(
        self, config_home, shared_store, monkeypatch, capsys
    ):
        """Routine rotations publish a RotationRecord but NO Revocation.
        A non-rotation-aware `dmp identity fetch` must still return the
        new identity unambiguously by dropping any IdentityRecord whose
        ed25519_spk appears as an old_spk in the rotation RRset.

        This is the Codex round-5 P1 path: without chain-head filtering,
        the default `dmp identity rotate` (reason=routine) would leave
        the identity RRset ambiguous forever.
        """
        import json as _json
        import yaml as _y
        from dmp.core.crypto import DMPCrypto
        from dmp.core.identity import identity_domain, make_record

        cli.main(["init", "--no-default-resolvers", "alice", "--endpoint", "http://x"])
        capsys.readouterr()

        # Publish the OLD IdentityRecord under the SAME salt rotate uses
        # (see test_identity_fetch_filters_revoked_records for why this
        # is needed to keep keys aligned).
        alice_doc = _y.safe_load((config_home / "config.yaml").read_text())
        alice_salt = bytes.fromhex(alice_doc["kdf_salt"])
        old_crypto = DMPCrypto.from_passphrase("alice-pass", salt=alice_salt)
        old_record = make_record(old_crypto, "alice")
        shared_store.publish_txt_record(
            identity_domain("alice", "mesh.local"),
            old_record.sign(old_crypto),
        )

        # Routine rotation: publishes new IdentityRecord + RotationRecord
        # (co-signed by old + new keys) — NO RevocationRecord.
        monkeypatch.setenv("DMP_PASSPHRASE", "alice-pass")
        monkeypatch.setenv("DMP_NEW_PASSPHRASE", "alice-new-pass")
        rc = cli.main(["identity", "rotate", "--yes", "--experimental"])
        assert rc == 0
        capsys.readouterr()

        # Now both IdentityRecords live at the mailbox name and there is
        # no revocation — the only disambiguator is the RotationRecord's
        # old_spk. A correct fetch picks the new key.
        bob_home = config_home.parent / "bob-routine-chain"
        monkeypatch.setenv("DMP_CONFIG_HOME", str(bob_home))
        cli.main(["init", "--no-default-resolvers", "bob", "--endpoint", "http://x"])
        capsys.readouterr()
        monkeypatch.setenv("DMP_PASSPHRASE", "bob-pass")

        rc = cli.main(["identity", "fetch", "alice", "--json"])
        assert rc == 0
        out = capsys.readouterr().out
        parsed = _json.loads(out)

        new_crypto = DMPCrypto.from_passphrase("alice-new-pass", salt=alice_salt)
        assert (
            parsed["signing_public_key"]
            == new_crypto.get_signing_public_key_bytes().hex()
        )

    def test_identity_fetch_still_ambiguous_on_concurrent_rotations(
        self, config_home, shared_store, monkeypatch, capsys
    ):
        """Two non-revoked IdentityRecords at the same name → still
        exits with the ambiguous-error. Regression guard: the revocation
        filter must not silently merge legitimate concurrent rotations.
        """
        from dmp.core.crypto import DMPCrypto
        from dmp.core.identity import identity_domain, make_record

        # Real alice publishes.
        cli.main(["init", "--no-default-resolvers", "alice", "--endpoint", "http://x"])
        capsys.readouterr()
        monkeypatch.setenv("DMP_PASSPHRASE", "alice-pass")
        cli.main(["identity", "publish"])
        capsys.readouterr()

        # A second, unrevoked identity also lands at the same name
        # (squatter or pathological concurrent rotation).
        squatter = DMPCrypto()
        wire = make_record(squatter, "alice").sign(squatter)
        shared_store.publish_txt_record(identity_domain("alice", "mesh.local"), wire)

        bob_home = config_home.parent / "bob-concurrent"
        monkeypatch.setenv("DMP_CONFIG_HOME", str(bob_home))
        cli.main(["init", "--no-default-resolvers", "bob", "--endpoint", "http://x"])
        monkeypatch.setenv("DMP_PASSPHRASE", "bob-pass")
        capsys.readouterr()

        with pytest.raises(SystemExit) as exc:
            cli.main(["identity", "fetch", "alice"])
        assert exc.value.code == 2
        err = capsys.readouterr().err
        assert "ambiguous" in err


class TestContacts:
    def test_add_and_list(self, config_home, capsys):
        cli.main(["init", "--no-default-resolvers", "alice", "--endpoint", "http://x"])
        pubkey = "a" * 64
        rc = cli.main(["contacts", "add", "bob", pubkey])
        assert rc == 0
        cli.main(["contacts", "list"])
        assert "bob" in capsys.readouterr().out

    def test_add_rejects_short_key(self, config_home):
        cli.main(["init", "--no-default-resolvers", "alice", "--endpoint", "http://x"])
        with pytest.raises(SystemExit) as exc:
            cli.main(["contacts", "add", "bob", "aabb"])
        assert exc.value.code == 1

    def test_list_empty(self, config_home, capsys):
        cli.main(["init", "--no-default-resolvers", "alice", "--endpoint", "http://x"])
        cli.main(["contacts", "list"])
        assert "no contacts" in capsys.readouterr().out


class TestContactKeyByFullAddress:
    """Codex round-23 P1: ``dnsmesh identity fetch user@host --add``
    must store the contact under the FULL canonical address
    (``user@host``), not the bare username. Two users with the same
    left-half on different zones (``alice@a.example`` vs
    ``alice@b.example``) MUST be distinguishable, and a subsequent
    ``dnsmesh send user@host`` MUST find the contact it just pinned.
    """

    def test_fetch_with_at_address_stores_full_key(
        self, config_home, shared_store, monkeypatch, capsys
    ):
        # Set up alice's config + store.
        cli.main(
            [
                "init",
                "--no-default-resolvers",
                "alice",
                "--domain",
                "alice.example",
                "--endpoint",
                "http://x",
            ]
        )
        # Bob publishes his identity in a separate config home.
        bob_home = config_home.parent / "dmp-home-bob"
        monkeypatch.setenv("DMP_CONFIG_HOME", str(bob_home))
        cli.main(
            [
                "init",
                "--no-default-resolvers",
                "bob",
                "--domain",
                "bob.example",
                "--endpoint",
                "http://x",
            ]
        )
        monkeypatch.setenv("DMP_PASSPHRASE", "bob-pp")
        cli.main(["identity", "publish"])

        # Alice fetches bob via the user@host form and pins.
        monkeypatch.setenv("DMP_CONFIG_HOME", str(config_home))
        monkeypatch.setenv("DMP_PASSPHRASE", "alice-pp")
        cli.main(["identity", "fetch", "bob@bob.example", "--add"])

        # The contact MUST be stored under the FULL address.
        cfg = cli.CLIConfig.load(cli._config_path())
        assert "bob@bob.example" in cfg.contacts, (
            f"contact should be keyed by full address; got keys: "
            f"{list(cfg.contacts.keys())}"
        )

    def test_fetch_bare_username_keeps_bare_key(
        self, config_home, shared_store, monkeypatch
    ):
        """Shared-mesh / TOFU fetches (no @host) keep the bare-name
        keying for back-compat with pre-M9 configs."""
        cli.main(
            [
                "init",
                "--no-default-resolvers",
                "alice",
                "--domain",
                "shared.mesh",
                "--endpoint",
                "http://x",
            ]
        )
        bob_home = config_home.parent / "dmp-home-bob"
        monkeypatch.setenv("DMP_CONFIG_HOME", str(bob_home))
        cli.main(
            [
                "init",
                "--no-default-resolvers",
                "bob",
                "--domain",
                "shared.mesh",  # same shared mesh
                "--endpoint",
                "http://x",
            ]
        )
        monkeypatch.setenv("DMP_PASSPHRASE", "bob-pp")
        cli.main(["identity", "publish"])

        monkeypatch.setenv("DMP_CONFIG_HOME", str(config_home))
        monkeypatch.setenv("DMP_PASSPHRASE", "alice-pp")
        cli.main(["identity", "fetch", "bob", "--add"])

        cfg = cli.CLIConfig.load(cli._config_path())
        assert "bob" in cfg.contacts
        assert "bob@shared.mesh" not in cfg.contacts

    def test_send_full_address_finds_full_keyed_contact(
        self, config_home, shared_store, monkeypatch, capsys
    ):
        """End-to-end: fetch by full address → store under full key →
        send by full address → finds it. This is the bug the user hit."""
        cli.main(
            [
                "init",
                "--no-default-resolvers",
                "alice",
                "--domain",
                "alice.example",
                "--endpoint",
                "http://x",
            ]
        )
        # Bob publishes from a different home + zone (cross-zone case).
        bob_home = config_home.parent / "dmp-home-bob"
        monkeypatch.setenv("DMP_CONFIG_HOME", str(bob_home))
        cli.main(
            [
                "init",
                "--no-default-resolvers",
                "bob",
                "--domain",
                "bob.example",
                "--endpoint",
                "http://x",
            ]
        )
        monkeypatch.setenv("DMP_PASSPHRASE", "bob-pp")
        cli.main(["identity", "publish"])

        # Alice pins bob via the full address.
        monkeypatch.setenv("DMP_CONFIG_HOME", str(config_home))
        monkeypatch.setenv("DMP_PASSPHRASE", "alice-pp")
        cli.main(["identity", "fetch", "bob@bob.example", "--add"])

        # Sending to the same full address MUST succeed (used to fail
        # with "unknown contact `bob@bob.example`" because the contact
        # was indexed under bare `bob`).
        rc = cli.main(["send", "bob@bob.example", "hello bob"])
        assert rc == 0, capsys.readouterr().err

    def test_send_falls_back_to_bare_name_for_legacy_contacts(
        self, config_home, shared_store, monkeypatch, capsys
    ):
        """Pre-M9 configs have contacts under bare names. ``dnsmesh send
        bob@bob.example`` must still find `bob` in those configs so an
        upgrade doesn't break existing flows."""
        cli.main(
            [
                "init",
                "--no-default-resolvers",
                "alice",
                "--domain",
                "shared.mesh",
                "--endpoint",
                "http://x",
            ]
        )
        bob_home = config_home.parent / "dmp-home-bob"
        monkeypatch.setenv("DMP_CONFIG_HOME", str(bob_home))
        cli.main(
            [
                "init",
                "--no-default-resolvers",
                "bob",
                "--domain",
                "shared.mesh",
                "--endpoint",
                "http://x",
            ]
        )
        monkeypatch.setenv("DMP_PASSPHRASE", "bob-pp")
        cli.main(["identity", "publish"])

        monkeypatch.setenv("DMP_CONFIG_HOME", str(config_home))
        monkeypatch.setenv("DMP_PASSPHRASE", "alice-pp")
        cli.main(["identity", "fetch", "bob", "--add"])  # no @host → bare key

        # Send by FULL address — must fall back to bare lookup.
        rc = cli.main(["send", "bob@shared.mesh", "hello"])
        assert rc == 0, capsys.readouterr().err


class TestConfigHomeFlag:
    """Codex round-23 P1: top-level ``--config-home`` flag for
    explicit config isolation. The pre-fix only knob was the
    ``DMP_CONFIG_HOME`` env var, which proved leaky — a stale
    config in ``~/.dmp/`` could shadow the env-var path during an
    upgrade and silently produce the wrong subject on
    ``dnsmesh tsig register``. The flag wins over the env var."""

    def test_flag_overrides_env_var(self, tmp_path, monkeypatch):
        # Env var points at one path, --config-home points at another.
        env_path = tmp_path / "env-home"
        flag_path = tmp_path / "flag-home"
        monkeypatch.setenv("DMP_CONFIG_HOME", str(env_path))
        rc = cli.main(
            [
                "--config-home",
                str(flag_path),
                "init",
                "--no-default-resolvers",
                "alice",
                "--endpoint",
                "http://x",
            ]
        )
        assert rc == 0
        # Init MUST have written to the flag path, not the env path.
        assert (
            flag_path / "config.yaml"
        ).exists(), "--config-home flag should win over DMP_CONFIG_HOME env var"
        assert not (env_path / "config.yaml").exists()

    def test_flag_propagates_to_subsequent_subcommands(self, tmp_path, monkeypatch):
        flag_path = tmp_path / "flag-home"
        # First invocation: init under the flag.
        cli.main(
            [
                "--config-home",
                str(flag_path),
                "init",
                "--no-default-resolvers",
                "alice",
                "--domain",
                "alice.example",
                "--endpoint",
                "http://x",
            ]
        )
        # Second invocation with the same flag: must read the same config.
        monkeypatch.setenv("DMP_PASSPHRASE", "alice-pp")
        rc = cli.main(["--config-home", str(flag_path), "identity", "show"])
        assert rc == 0

    def test_flag_defaults_tokens_home_to_sibling(self, tmp_path, monkeypatch):
        """A single --config-home flag should also isolate tokens, so
        the operator workflow (per-tenant directories) is one-knob."""
        # Clean any DMP_TOKENS_HOME leaked by a sibling test (the CLI's
        # main() writes os.environ directly, bypassing monkeypatch's
        # cleanup hooks; explicit delenv gets us a known starting state).
        monkeypatch.delenv("DMP_TOKENS_HOME", raising=False)
        flag_path = tmp_path / "flag-home"
        cli.main(
            [
                "--config-home",
                str(flag_path),
                "init",
                "--no-default-resolvers",
                "alice",
                "--endpoint",
                "http://x",
            ]
        )
        # After init, DMP_TOKENS_HOME should point at <config-home>/tokens.
        assert os.environ.get("DMP_TOKENS_HOME") == str(flag_path / "tokens")


class TestSendRecv:
    def test_send_and_recv_roundtrip(
        self, config_home, shared_store, monkeypatch, capsys
    ):
        # Set up alice's config.
        cli.main(["init", "--no-default-resolvers", "alice", "--endpoint", "http://x"])
        monkeypatch.setenv("DMP_PASSPHRASE", "alice-pass")

        # Discover bob's pubkey by spinning up a client in the same store.
        bob = DMPClient(
            "bob",
            "bob-pass",
            domain="mesh.local",
            store=shared_store,
            intro_queue_path=":memory:",
            prekey_store_path=":memory:",
        )
        cli.main(["contacts", "add", "bob", bob.get_public_key_hex()])

        rc = cli.main(["send", "bob", "hello from cli"])
        assert rc == 0
        assert "sent" in capsys.readouterr().out

        # Switch "identity" to bob and read. Bob has no pinned signing
        # keys yet (fresh init), so opt into TOFU explicitly to receive
        # alice's first-contact manifest. Real onboarding flows would
        # use ``dnsmesh contacts add alice <pub> --signing-key <spk>``
        # instead.
        cli.main(
            [
                "init",
                "--no-default-resolvers",
                "bob",
                "--endpoint",
                "http://x",
                "--force",
                "--allow-tofu",
            ]
        )
        monkeypatch.setenv("DMP_PASSPHRASE", "bob-pass")
        cli.main(["recv"])
        out = capsys.readouterr().out
        assert "hello from cli" in out

    def test_send_unknown_recipient_errors(
        self, config_home, shared_store, monkeypatch
    ):
        cli.main(["init", "--no-default-resolvers", "alice", "--endpoint", "http://x"])
        monkeypatch.setenv("DMP_PASSPHRASE", "pw")
        with pytest.raises(SystemExit) as exc:
            cli.main(["send", "ghost", "hi"])
        assert exc.value.code == 1

    def test_recv_empty_inbox(self, config_home, shared_store, monkeypatch, capsys):
        cli.main(["init", "--no-default-resolvers", "alice", "--endpoint", "http://x"])
        monkeypatch.setenv("DMP_PASSPHRASE", "pw")
        cli.main(["recv"])
        assert "no new messages" in capsys.readouterr().out

    def test_recv_twice_is_idempotent(
        self, config_home, shared_store, monkeypatch, capsys
    ):
        """Persistent replay cache: second `dmp recv` in a fresh process
        doesn't re-deliver what was already delivered."""
        cli.main(["init", "--no-default-resolvers", "alice", "--endpoint", "http://x"])
        capsys.readouterr()
        monkeypatch.setenv("DMP_PASSPHRASE", "alice-pass")

        bob = DMPClient(
            "bob",
            "bob-pass",
            domain="mesh.local",
            store=shared_store,
            intro_queue_path=":memory:",
            prekey_store_path=":memory:",
        )
        cli.main(["contacts", "add", "bob", bob.get_public_key_hex()])
        capsys.readouterr()

        # alice sends
        cli.main(["send", "bob", "only-once"])
        capsys.readouterr()

        # bob's CLI reads once. --allow-tofu is required because bob's
        # fresh init has no pinned contacts; without it the slot walk
        # drops alice's manifest as a default-deny first-contact.
        cli.main(
            [
                "init",
                "--no-default-resolvers",
                "bob",
                "--endpoint",
                "http://x",
                "--force",
                "--allow-tofu",
            ]
        )
        monkeypatch.setenv("DMP_PASSPHRASE", "bob-pass")
        capsys.readouterr()
        cli.main(["recv"])
        out1 = capsys.readouterr().out
        assert "only-once" in out1

        # bob's CLI reads again — replay cache persists across the simulated
        # second invocation, so no duplicate.
        cli.main(["recv"])
        out2 = capsys.readouterr().out
        assert "only-once" not in out2
        assert "no new messages" in out2


class TestLoadWithoutConfig:
    def test_identity_show_without_config_errors(self, config_home):
        # Don't init; config doesn't exist.
        with pytest.raises(FileNotFoundError):
            cli.main(["identity", "show"])

    def test_resolvers_list_without_config_exits_cleanly(self, config_home, capsys):
        """`dmp resolvers list` on a fresh install (no config.yaml) must
        not dump a FileNotFoundError traceback — it's a diagnostic
        command, and a missing config is the expected "not yet set up"
        state. Surface a friendly exit-1 via `_die` instead, matching
        the pattern used by `dmp resolvers discover --save`.
        """
        # Don't init; config doesn't exist.
        with pytest.raises(SystemExit) as exc:
            cli.main(["resolvers", "list"])
        assert exc.value.code == 1
        err = capsys.readouterr().err
        # The hint should mention `dnsmesh init` so users know what to do.
        assert "dnsmesh init" in err


class TestDnsResolvers:
    """`--dns-resolvers` multi-resolver pool wiring (M1.2)."""

    def test_init_persists_resolver_list(self, config_home):
        """Happy path: two bare IPs land in config as dns_resolvers."""
        rc = cli.main(
            [
                "init",
                "alice",
                "--endpoint",
                "http://x",
                "--dns-resolvers",
                "8.8.8.8,1.1.1.1",
            ]
        )
        assert rc == 0
        data = yaml.safe_load((config_home / "config.yaml").read_text())
        assert data["dns_resolvers"] == ["8.8.8.8", "1.1.1.1"]

    def test_init_persists_entries_with_ports(self, config_home):
        """Port syntax round-trips through config in canonical form."""
        rc = cli.main(
            [
                "init",
                "alice",
                "--endpoint",
                "http://x",
                "--dns-resolvers",
                "8.8.8.8:53,1.1.1.1:5353",
            ]
        )
        assert rc == 0
        data = yaml.safe_load((config_home / "config.yaml").read_text())
        assert data["dns_resolvers"] == ["8.8.8.8:53", "1.1.1.1:5353"]

    def test_init_accepts_ipv6_bracket_port(self, config_home):
        rc = cli.main(
            [
                "init",
                "alice",
                "--endpoint",
                "http://x",
                "--dns-resolvers",
                "[2001:4860:4860::8888]:53,1.1.1.1",
            ]
        )
        assert rc == 0
        data = yaml.safe_load((config_home / "config.yaml").read_text())
        assert data["dns_resolvers"] == ["[2001:4860:4860::8888]:53", "1.1.1.1"]

    def test_init_rejects_hostname(self, config_home, capsys):
        """ResolverPool forbids hostnames — so does our parser."""
        with pytest.raises(SystemExit) as exc:
            cli.main(
                [
                    "init",
                    "alice",
                    "--endpoint",
                    "http://x",
                    "--dns-resolvers",
                    "dns.google",
                ]
            )
        assert exc.value.code == 1
        err = capsys.readouterr().err
        assert "invalid --dns-resolvers" in err
        # No config file was written on parse failure.
        assert not (config_home / "config.yaml").exists()

    def test_init_rejects_port_out_of_range(self, config_home):
        with pytest.raises(SystemExit) as exc:
            cli.main(
                [
                    "init",
                    "alice",
                    "--endpoint",
                    "http://x",
                    "--dns-resolvers",
                    "8.8.8.8:99999",
                ]
            )
        assert exc.value.code == 1

    def test_init_rejects_malformed_port(self, config_home):
        with pytest.raises(SystemExit) as exc:
            cli.main(
                [
                    "init",
                    "alice",
                    "--endpoint",
                    "http://x",
                    "--dns-resolvers",
                    "8.8.8.8:notaport",
                ]
            )
        assert exc.value.code == 1

    def test_load_tolerates_scalar_dns_resolvers_in_config(self, config_home):
        """A hand-edited config with `dns_resolvers: "1.2.3.4"` (scalar
        instead of list) must not explode into single characters.

        The naive `[str(r) for r in raw]` comprehension iterates a
        string char-by-char, yielding `["1", ".", "2", ...]`, which
        then fails validation deep inside ResolverPool. Wrap the scalar
        up front so the loader treats it as a one-element list.
        """
        # Init a valid config first so the file exists.
        cli.main(["init", "--no-default-resolvers", "alice", "--endpoint", "http://x"])
        cfg_path = config_home / "config.yaml"
        data = yaml.safe_load(cfg_path.read_text())
        # Simulate the hand-edit: YAML scalar, not a list.
        data["dns_resolvers"] = "1.2.3.4"
        cfg_path.write_text(yaml.safe_dump(data, sort_keys=True))

        cfg = cli.CLIConfig.load(cfg_path)
        assert cfg.dns_resolvers == ["1.2.3.4"]

    def test_make_client_uses_resolver_pool_when_list_set(
        self, config_home, monkeypatch
    ):
        """With dns_resolvers populated, _make_reader builds a ResolverPool."""
        cli.main(
            [
                "init",
                "alice",
                "--endpoint",
                "http://x",
                "--dns-resolvers",
                "8.8.8.8,1.1.1.1",
            ]
        )
        cfg = cli.CLIConfig.load(config_home / "config.yaml")
        reader = cli._make_reader(cfg)
        from dmp.network.resolver_pool import ResolverPool

        assert isinstance(reader, ResolverPool)
        # Both hosts are in the preferred tier right after construction.
        assert set(reader.healthy_hosts()) == {"8.8.8.8", "1.1.1.1"}

    def test_make_reader_per_host_ports_applied(self, config_home):
        """Each entry's explicit port reaches the underlying resolver.

        M1.5 dropped the old "first explicit port wins" workaround:
        `ResolverPool` now accepts `(ip, port)` tuples, so the CLI
        hands each upstream's port through unchanged.
        """
        cli.main(
            [
                "init",
                "alice",
                "--endpoint",
                "http://x",
                "--dns-resolvers",
                "8.8.8.8:53,1.1.1.1:5353",
            ]
        )
        cfg = cli.CLIConfig.load(config_home / "config.yaml")
        reader = cli._make_reader(cfg)
        from dmp.network.resolver_pool import ResolverPool

        assert isinstance(reader, ResolverPool)
        # Each host uses its own port, not a single shared one.
        by_host = {s.host: s.resolver.port for s in reader._states}
        assert by_host == {"8.8.8.8": 53, "1.1.1.1": 5353}

    def test_make_reader_portless_entries_default_to_53(self, config_home):
        """Entries without an explicit port fall through to the ResolverPool default."""
        cli.main(
            [
                "init",
                "alice",
                "--endpoint",
                "http://x",
                "--dns-resolvers",
                "8.8.8.8,1.1.1.1",
            ]
        )
        cfg = cli.CLIConfig.load(config_home / "config.yaml")
        reader = cli._make_reader(cfg)
        from dmp.network.resolver_pool import ResolverPool

        assert isinstance(reader, ResolverPool)
        # Both inherited the ResolverPool default of 53.
        by_host = {s.host: s.resolver.port for s in reader._states}
        assert by_host == {"8.8.8.8": 53, "1.1.1.1": 53}

    def test_make_reader_mixed_port_entries_preserved(self, config_home):
        """A mix of ported and portless entries round-trips cleanly.

        The portless one defaults to 53; the ported one keeps its
        explicit value. Confirms the CLI's new per-host wiring doesn't
        leak the old "first port wins" coupling.
        """
        cli.main(
            [
                "init",
                "alice",
                "--endpoint",
                "http://x",
                "--dns-resolvers",
                "8.8.8.8,1.1.1.1:5353",
            ]
        )
        cfg = cli.CLIConfig.load(config_home / "config.yaml")
        reader = cli._make_reader(cfg)
        from dmp.network.resolver_pool import ResolverPool

        assert isinstance(reader, ResolverPool)
        by_host = {s.host: s.resolver.port for s in reader._states}
        assert by_host == {"8.8.8.8": 53, "1.1.1.1": 5353}

    def test_make_reader_falls_back_to_dns_reader_when_list_empty(self, config_home):
        """Back-compat: legacy --dns-host path still produces a _DnsReader."""
        cli.main(
            [
                "init",
                "--no-default-resolvers",
                "alice",
                "--endpoint",
                "http://x",
                "--dns-host",
                "127.0.0.1",
                "--dns-port",
                "5353",
            ]
        )
        cfg = cli.CLIConfig.load(config_home / "config.yaml")
        assert cfg.dns_resolvers == []
        reader = cli._make_reader(cfg)
        assert isinstance(reader, cli._DnsReader)

    def test_legacy_single_host_send_recv_still_works(
        self, config_home, shared_store, monkeypatch, capsys
    ):
        """The existing --dns-host flow still delivers messages end-to-end.

        The `shared_store` fixture monkeypatches `_make_client` and
        `_DnsReader`, so we're really checking that the legacy config
        shape (no dns_resolvers) round-trips through load/save and
        reaches the same send/recv path that existed before M1.2.
        """
        cli.main(
            [
                "init",
                "alice",
                "--endpoint",
                "http://x",
                "--dns-host",
                "127.0.0.1",
            ]
        )
        monkeypatch.setenv("DMP_PASSPHRASE", "alice-pass")
        capsys.readouterr()

        bob = DMPClient(
            "bob",
            "bob-pass",
            domain="mesh.local",
            store=shared_store,
            intro_queue_path=":memory:",
            prekey_store_path=":memory:",
        )
        cli.main(["contacts", "add", "bob", bob.get_public_key_hex()])
        cli.main(["send", "bob", "legacy hi"])
        assert "sent" in capsys.readouterr().out

        cli.main(
            [
                "init",
                "--no-default-resolvers",
                "bob",
                "--endpoint",
                "http://x",
                "--force",
                "--allow-tofu",
            ]
        )
        monkeypatch.setenv("DMP_PASSPHRASE", "bob-pass")
        cli.main(["recv"])
        assert "legacy hi" in capsys.readouterr().out

    def test_parse_resolver_entry_accepts_forms(self):
        """Unit-level coverage of the parser's accepted forms."""
        from dmp.cli import _parse_resolver_entry

        assert _parse_resolver_entry("8.8.8.8") == ("8.8.8.8", None)
        assert _parse_resolver_entry("8.8.8.8:53") == ("8.8.8.8", 53)
        assert _parse_resolver_entry("2001:4860:4860::8888") == (
            "2001:4860:4860::8888",
            None,
        )
        assert _parse_resolver_entry("[2001:4860:4860::8888]:53") == (
            "2001:4860:4860::8888",
            53,
        )

    def test_parse_resolver_entry_rejects_bracket_with_bad_port(self):
        """Bracketed IPv6 with a non-numeric port is rejected."""
        from dmp.cli import _parse_resolver_entry

        with pytest.raises(ValueError):
            _parse_resolver_entry("[::1]:notaport")

    def test_parse_resolver_entry_rejects_unmatched_bracket(self):
        """Lone opening bracket without a closing one is rejected."""
        from dmp.cli import _parse_resolver_entry

        with pytest.raises(ValueError):
            _parse_resolver_entry("[2001:4860:4860::8888")


class TestResolversCommand:
    """`dmp resolvers discover` + `dmp resolvers list`.

    Network probes are mocked out via a stub ResolverPool that returns
    a fixed host list, so the tests run offline and deterministically.
    """

    def _stub_discover(self, monkeypatch, hosts):
        """Replace ResolverPool.discover with one that returns a stub pool."""
        from dmp.network.resolver_pool import ResolverPool

        class _StubPool:
            def snapshot(self):
                return [{"host": h} for h in hosts]

        def fake_discover(candidates, timeout=2.0):
            if not hosts:
                raise ValueError(
                    "ResolverPool.discover: no candidates answered "
                    f"within {timeout}s"
                )
            return _StubPool()

        # Patch the symbol the CLI imported, not just ResolverPool itself.
        monkeypatch.setattr(cli.ResolverPool, "discover", staticmethod(fake_discover))

    def test_discover_prints_working_list(self, config_home, monkeypatch, capsys):
        cli.main(["init", "--no-default-resolvers", "alice", "--endpoint", "http://x"])
        capsys.readouterr()
        self._stub_discover(monkeypatch, ["1.1.1.1", "9.9.9.9"])

        rc = cli.main(["resolvers", "discover"])
        assert rc == 0
        out = capsys.readouterr().out
        assert "discovered 2 working resolver(s)" in out
        assert "1.1.1.1" in out
        assert "9.9.9.9" in out

    def test_discover_without_save_does_not_touch_config(
        self, config_home, monkeypatch, capsys
    ):
        cli.main(["init", "--no-default-resolvers", "alice", "--endpoint", "http://x"])
        capsys.readouterr()
        cfg_path = config_home / "config.yaml"
        before = yaml.safe_load(cfg_path.read_text())
        assert before.get("dns_resolvers", []) == []

        self._stub_discover(monkeypatch, ["1.1.1.1", "9.9.9.9"])
        cli.main(["resolvers", "discover"])

        after = yaml.safe_load(cfg_path.read_text())
        assert after.get("dns_resolvers", []) == []

    def test_discover_with_save_writes_config(self, config_home, monkeypatch, capsys):
        cli.main(["init", "--no-default-resolvers", "alice", "--endpoint", "http://x"])
        capsys.readouterr()
        self._stub_discover(monkeypatch, ["1.1.1.1", "9.9.9.9", "8.8.8.8"])

        rc = cli.main(["resolvers", "discover", "--save"])
        assert rc == 0
        out = capsys.readouterr().out
        assert "saved 3 resolvers" in out

        cfg = yaml.safe_load((config_home / "config.yaml").read_text())
        assert cfg["dns_resolvers"] == ["1.1.1.1", "9.9.9.9", "8.8.8.8"]

    def test_discover_save_then_list_shows_them(self, config_home, monkeypatch, capsys):
        cli.main(["init", "--no-default-resolvers", "alice", "--endpoint", "http://x"])
        capsys.readouterr()
        self._stub_discover(monkeypatch, ["1.1.1.1", "9.9.9.9"])
        cli.main(["resolvers", "discover", "--save"])
        capsys.readouterr()

        cli.main(["resolvers", "list"])
        out = capsys.readouterr().out
        assert "1.1.1.1" in out
        assert "9.9.9.9" in out

    def test_list_without_saved_resolvers_prints_hint(self, config_home, capsys):
        cli.main(["init", "--no-default-resolvers", "alice", "--endpoint", "http://x"])
        capsys.readouterr()
        cli.main(["resolvers", "list"])
        out = capsys.readouterr().out
        assert "no dns_resolvers configured" in out

    def test_discover_save_without_config_errors(
        self, config_home, monkeypatch, capsys
    ):
        """`--save` on a fresh machine (no `dmp init` yet) fails cleanly."""
        self._stub_discover(monkeypatch, ["1.1.1.1"])
        with pytest.raises(SystemExit) as exc:
            cli.main(["resolvers", "discover", "--save"])
        assert exc.value.code == 1

    def test_discover_all_failures_exits_with_network_error(
        self, config_home, monkeypatch
    ):
        """Every probe failed -> ResolverPool.discover raises ValueError,
        CLI surfaces it as exit code 2 (network/backend error)."""
        cli.main(["init", "--no-default-resolvers", "alice", "--endpoint", "http://x"])
        self._stub_discover(monkeypatch, [])
        with pytest.raises(SystemExit) as exc:
            cli.main(["resolvers", "discover"])
        assert exc.value.code == 2


class TestClusterCommand:
    """`dmp cluster pin` / `dmp cluster fetch` / `dmp cluster status`.

    Network reads are redirected at the shared in-memory store via a
    monkeypatched `_make_reader`; that's the same anchor the real CLI
    uses to build both the legacy single-host reader and the cluster
    bootstrap reader.
    """

    def _patch_reader(self, monkeypatch, store):
        """Force `_make_reader` to return a reader backed by `store`."""

        class _StoreReader:
            def query_txt_record(self, name):
                return store.query_txt_record(name)

        monkeypatch.setattr(cli, "_make_reader", lambda cfg: _StoreReader())

    def _build_signed_manifest(
        self, *, cluster_name="mesh.example.com", seq=1, n_nodes=2
    ):
        """Return `(operator, wire_string, manifest)` for test use."""
        import time as _time

        from dmp.core.cluster import ClusterManifest, ClusterNode
        from dmp.core.crypto import DMPCrypto

        op = DMPCrypto()
        nodes = [
            ClusterNode(
                node_id=f"n{i:02d}",
                http_endpoint=f"https://n{i}.example.com:8053",
                dns_endpoint=f"203.0.113.{i}:53",
            )
            for i in range(1, n_nodes + 1)
        ]
        manifest = ClusterManifest(
            cluster_name=cluster_name,
            operator_spk=op.get_signing_public_key_bytes(),
            nodes=nodes,
            seq=seq,
            exp=int(_time.time()) + 3600,
        )
        return op, manifest.sign(op), manifest

    def test_cluster_pin_writes_config(self, config_home):
        cli.main(["init", "--no-default-resolvers", "alice", "--endpoint", "http://x"])
        op, wire, manifest = self._build_signed_manifest()
        hex_spk = op.get_signing_public_key_bytes().hex()
        rc = cli.main(["cluster", "pin", hex_spk, "mesh.example.com"])
        assert rc == 0
        cfg = yaml.safe_load((config_home / "config.yaml").read_text())
        assert cfg["cluster_operator_spk"] == hex_spk
        assert cfg["cluster_base_domain"] == "mesh.example.com"

    def test_cluster_pin_rejects_bad_hex(self, config_home):
        cli.main(["init", "--no-default-resolvers", "alice", "--endpoint", "http://x"])
        with pytest.raises(SystemExit) as exc:
            cli.main(["cluster", "pin", "not-hex", "mesh.example.com"])
        assert exc.value.code == 1

    def test_cluster_pin_rejects_wrong_length(self, config_home):
        cli.main(["init", "--no-default-resolvers", "alice", "--endpoint", "http://x"])
        # 16-byte hex (too short for Ed25519)
        with pytest.raises(SystemExit) as exc:
            cli.main(["cluster", "pin", "aa" * 16, "mesh.example.com"])
        assert exc.value.code == 1

    def test_cluster_fetch_prints_summary(self, config_home, monkeypatch, capsys):
        from dmp.core.cluster import cluster_rrset_name
        from dmp.network.memory import InMemoryDNSStore

        cli.main(["init", "--no-default-resolvers", "alice", "--endpoint", "http://x"])
        capsys.readouterr()

        op, wire, manifest = self._build_signed_manifest(n_nodes=2)
        hex_spk = op.get_signing_public_key_bytes().hex()
        cli.main(["cluster", "pin", hex_spk, "mesh.example.com"])
        capsys.readouterr()

        store = InMemoryDNSStore()
        store.publish_txt_record(cluster_rrset_name("mesh.example.com"), wire)
        self._patch_reader(monkeypatch, store)

        rc = cli.main(["cluster", "fetch"])
        assert rc == 0
        out = capsys.readouterr().out
        assert "cluster: mesh.example.com" in out
        assert "seq:   1" in out
        assert "nodes: 2" in out
        assert "n01" in out
        assert "n02" in out

    def test_cluster_fetch_without_pin_errors(self, config_home):
        cli.main(["init", "--no-default-resolvers", "alice", "--endpoint", "http://x"])
        with pytest.raises(SystemExit) as exc:
            cli.main(["cluster", "fetch"])
        assert exc.value.code == 1

    def test_cluster_fetch_nothing_published_exits_2(self, config_home, monkeypatch):
        from dmp.network.memory import InMemoryDNSStore

        cli.main(["init", "--no-default-resolvers", "alice", "--endpoint", "http://x"])
        op, wire, manifest = self._build_signed_manifest()
        hex_spk = op.get_signing_public_key_bytes().hex()
        cli.main(["cluster", "pin", hex_spk, "mesh.example.com"])

        store = InMemoryDNSStore()  # nothing published
        self._patch_reader(monkeypatch, store)

        with pytest.raises(SystemExit) as exc:
            cli.main(["cluster", "fetch"])
        assert exc.value.code == 2

    def test_cluster_fetch_save_writes_wire_cache(
        self, config_home, monkeypatch, capsys
    ):
        from dmp.core.cluster import cluster_rrset_name
        from dmp.network.memory import InMemoryDNSStore

        cli.main(["init", "--no-default-resolvers", "alice", "--endpoint", "http://x"])
        op, wire, manifest = self._build_signed_manifest()
        hex_spk = op.get_signing_public_key_bytes().hex()
        cli.main(["cluster", "pin", hex_spk, "mesh.example.com"])

        store = InMemoryDNSStore()
        store.publish_txt_record(cluster_rrset_name("mesh.example.com"), wire)
        self._patch_reader(monkeypatch, store)

        cli.main(["cluster", "fetch", "--save"])
        wire_path = config_home / "cluster_manifest.wire"
        assert wire_path.exists()
        assert wire_path.read_text() == wire

    def test_cluster_status_prints_snapshots(self, config_home, monkeypatch, capsys):
        from dmp.core.cluster import cluster_rrset_name
        from dmp.network.memory import InMemoryDNSStore

        cli.main(["init", "--no-default-resolvers", "alice", "--endpoint", "http://x"])
        capsys.readouterr()
        op, wire, manifest = self._build_signed_manifest(n_nodes=3)
        hex_spk = op.get_signing_public_key_bytes().hex()
        cli.main(["cluster", "pin", hex_spk, "mesh.example.com"])
        capsys.readouterr()

        store = InMemoryDNSStore()
        store.publish_txt_record(cluster_rrset_name("mesh.example.com"), wire)
        self._patch_reader(monkeypatch, store)

        rc = cli.main(["cluster", "status"])
        assert rc == 0
        out = capsys.readouterr().out
        assert "cluster: mesh.example.com" in out
        assert "fan-out writer snapshot" in out
        assert "union reader snapshot" in out
        # All three nodes appear in the snapshot.
        for i in range(1, 4):
            assert f"n{i:02d}" in out


class TestClusterEnableDisable:
    """Pin-vs-enable decoupling (M2.wire-polish).

    `dmp cluster pin` now only writes anchors; cluster mode is
    activated separately via `dmp cluster enable` (which runs a live
    manifest fetch sanity check) and deactivated via `dmp cluster
    disable`. Before this split, pinning immediately flipped cluster
    mode on, which broke every networked command when the manifest
    wasn't yet published under the pinned anchors.
    """

    def _patch_reader(self, monkeypatch, store):
        class _StoreReader:
            def query_txt_record(self, name):
                return store.query_txt_record(name)

        monkeypatch.setattr(cli, "_make_reader", lambda cfg: _StoreReader())

    def _build_signed_manifest(
        self, *, cluster_name="mesh.example.com", seq=1, n_nodes=2
    ):
        import time as _time

        from dmp.core.cluster import ClusterManifest, ClusterNode
        from dmp.core.crypto import DMPCrypto

        op = DMPCrypto()
        nodes = [
            ClusterNode(
                node_id=f"n{i:02d}",
                http_endpoint=f"https://n{i}.example.com:8053",
                dns_endpoint=f"203.0.113.{i}:53",
            )
            for i in range(1, n_nodes + 1)
        ]
        manifest = ClusterManifest(
            cluster_name=cluster_name,
            operator_spk=op.get_signing_public_key_bytes(),
            nodes=nodes,
            seq=seq,
            exp=int(_time.time()) + 3600,
        )
        return op, manifest.sign(op), manifest

    def test_pin_does_not_enable_cluster_mode(self, config_home, monkeypatch):
        """Bare `cluster pin` leaves cluster_enabled=False even with both
        anchors set; `_cluster_mode_enabled` returns False; a subsequent
        `_make_client` uses the legacy single-endpoint path."""
        cli.main(
            [
                "init",
                "--no-default-resolvers",
                "alice",
                "--endpoint",
                "http://legacy.example",
            ]
        )
        op, wire, manifest = self._build_signed_manifest()
        hex_spk = op.get_signing_public_key_bytes().hex()
        cli.main(["cluster", "pin", hex_spk, "mesh.example.com"])

        cfg = cli.CLIConfig.load(config_home / "config.yaml")
        assert cfg.cluster_base_domain == "mesh.example.com"
        assert cfg.cluster_operator_spk == hex_spk
        assert cfg.cluster_enabled is False
        # Key invariant: both anchors set, but cluster mode is NOT on.
        assert cli._cluster_mode_enabled(cfg) is False
        assert cli._cluster_anchors_pinned(cfg) is True

        # And `_make_client` must wire the legacy endpoint, not the
        # cluster bootstrap. We monkeypatch fetch_cluster_manifest to
        # detect any accidental cluster-path invocation.
        import dmp.cli as cli_mod

        def boom_fetch(*args, **kwargs):  # pragma: no cover
            raise AssertionError(
                "fetch_cluster_manifest must NOT be called when "
                "cluster_enabled is False"
            )

        monkeypatch.setattr(cli_mod, "fetch_cluster_manifest", boom_fetch)
        client = cli._make_client(cfg, "pw")
        try:
            assert client._cluster_client is None
            # Legacy writer → plain _HttpWriter, not FanoutWriter.
            from dmp.network.fanout_writer import FanoutWriter

            assert not isinstance(client.writer, FanoutWriter)
        finally:
            cli._close_client(client)

    def test_enable_requires_both_anchors(self, config_home, capsys):
        """`cluster enable` with no anchors pinned exits 1 with a clear
        error and does NOT flip cluster_enabled."""
        cli.main(
            [
                "init",
                "--no-default-resolvers",
                "alice",
                "--endpoint",
                "http://legacy.example",
            ]
        )
        with pytest.raises(SystemExit) as exc:
            cli.main(["cluster", "enable"])
        assert exc.value.code == 1
        err = capsys.readouterr().err
        assert "anchors not pinned" in err
        cfg = cli.CLIConfig.load(config_home / "config.yaml")
        assert cfg.cluster_enabled is False

    def test_enable_rejects_unreachable_manifest(
        self, config_home, monkeypatch, capsys
    ):
        """Anchors pinned but manifest unpublished: `cluster enable`
        exits 2, leaves cluster_enabled=False, and the error message
        tells the operator how to diagnose."""
        from dmp.network.memory import InMemoryDNSStore

        cli.main(
            [
                "init",
                "--no-default-resolvers",
                "alice",
                "--endpoint",
                "http://legacy.example",
            ]
        )
        op, wire, manifest = self._build_signed_manifest()
        hex_spk = op.get_signing_public_key_bytes().hex()
        cli.main(["cluster", "pin", hex_spk, "mesh.example.com"])

        # Empty store: no manifest published.
        store = InMemoryDNSStore()
        self._patch_reader(monkeypatch, store)

        with pytest.raises(SystemExit) as exc:
            cli.main(["cluster", "enable"])
        assert exc.value.code == 2
        err = capsys.readouterr().err
        assert "cluster manifest fetch failed" in err
        assert "NOT enabled" in err

        cfg = cli.CLIConfig.load(config_home / "config.yaml")
        assert cfg.cluster_enabled is False

    def test_enable_happy_path(self, config_home, monkeypatch, capsys):
        """With a signed manifest published, `cluster enable` flips
        the flag and subsequent `_make_client` calls go through the
        cluster path."""
        from dmp.core.cluster import cluster_rrset_name
        from dmp.network.memory import InMemoryDNSStore

        cli.main(
            [
                "init",
                "--no-default-resolvers",
                "alice",
                "--endpoint",
                "http://legacy.example",
            ]
        )
        op, wire, manifest = self._build_signed_manifest(n_nodes=2)
        hex_spk = op.get_signing_public_key_bytes().hex()
        cli.main(["cluster", "pin", hex_spk, "mesh.example.com"])

        store = InMemoryDNSStore()
        store.publish_txt_record(cluster_rrset_name("mesh.example.com"), wire)
        self._patch_reader(monkeypatch, store)
        capsys.readouterr()

        rc = cli.main(["cluster", "enable"])
        assert rc == 0
        out = capsys.readouterr().out
        assert "cluster mode enabled." in out
        # Manifest summary is part of the output so operators see what
        # they just activated against.
        assert "cluster: mesh.example.com" in out
        assert "seq:   1" in out
        assert "nodes: 2" in out

        cfg = cli.CLIConfig.load(config_home / "config.yaml")
        assert cfg.cluster_enabled is True
        assert cli._cluster_mode_enabled(cfg) is True

        # Build a client and confirm we're actually on the cluster path.
        client = cli._make_client(cfg, "pw")
        try:
            from dmp.network.composite_reader import CompositeReader
            from dmp.network.fanout_writer import FanoutWriter
            from dmp.network.union_reader import UnionReader

            assert client._cluster_client is not None
            assert isinstance(client.writer, FanoutWriter)
            # Reader is wrapped in a CompositeReader so cross-domain
            # lookups route through the bootstrap resolver — the
            # cluster-local side is a UnionReader.
            assert isinstance(client.reader, CompositeReader)
            assert isinstance(client.reader._cluster_reader, UnionReader)
        finally:
            cli._close_client(client)

    def test_disable_reverts_to_legacy(self, config_home, monkeypatch, capsys):
        """After enable, `disable` flips cluster_enabled back to False
        without clearing the anchors. Subsequent `_make_client` uses
        the legacy endpoint path."""
        from dmp.core.cluster import cluster_rrset_name
        from dmp.network.memory import InMemoryDNSStore

        cli.main(
            [
                "init",
                "--no-default-resolvers",
                "alice",
                "--endpoint",
                "http://legacy.example",
            ]
        )
        op, wire, manifest = self._build_signed_manifest()
        hex_spk = op.get_signing_public_key_bytes().hex()
        cli.main(["cluster", "pin", hex_spk, "mesh.example.com"])
        store = InMemoryDNSStore()
        store.publish_txt_record(cluster_rrset_name("mesh.example.com"), wire)
        self._patch_reader(monkeypatch, store)
        cli.main(["cluster", "enable"])
        capsys.readouterr()

        rc = cli.main(["cluster", "disable"])
        assert rc == 0
        out = capsys.readouterr().out
        assert "cluster mode disabled" in out
        assert "legacy endpoint" in out

        cfg = cli.CLIConfig.load(config_home / "config.yaml")
        assert cfg.cluster_enabled is False
        # Anchors still pinned — operator can re-enable without re-pin.
        assert cfg.cluster_base_domain == "mesh.example.com"
        assert cfg.cluster_operator_spk == hex_spk
        assert cli._cluster_mode_enabled(cfg) is False
        assert cli._cluster_anchors_pinned(cfg) is True

        # Legacy path is active — no cluster client, no FanoutWriter.
        import dmp.cli as cli_mod

        def boom_fetch(*args, **kwargs):  # pragma: no cover
            raise AssertionError(
                "fetch_cluster_manifest must NOT be called after disable"
            )

        monkeypatch.setattr(cli_mod, "fetch_cluster_manifest", boom_fetch)
        client = cli._make_client(cfg, "pw")
        try:
            assert client._cluster_client is None
        finally:
            cli._close_client(client)

    def test_disable_idempotent_when_already_disabled(self, config_home, capsys):
        """Running `cluster disable` on a never-enabled config is a
        no-op that exits 0 and reports current state."""
        cli.main(
            [
                "init",
                "--no-default-resolvers",
                "alice",
                "--endpoint",
                "http://legacy.example",
            ]
        )
        capsys.readouterr()
        rc = cli.main(["cluster", "disable"])
        assert rc == 0
        out = capsys.readouterr().out
        assert "already disabled" in out
        cfg = cli.CLIConfig.load(config_home / "config.yaml")
        assert cfg.cluster_enabled is False

    def test_enable_idempotent(self, config_home, monkeypatch, capsys):
        """Running `cluster enable` twice re-runs the fetch sanity
        check and reports the current state (second run returns 0)."""
        from dmp.core.cluster import cluster_rrset_name
        from dmp.network.memory import InMemoryDNSStore

        cli.main(
            [
                "init",
                "--no-default-resolvers",
                "alice",
                "--endpoint",
                "http://legacy.example",
            ]
        )
        op, wire, manifest = self._build_signed_manifest()
        hex_spk = op.get_signing_public_key_bytes().hex()
        cli.main(["cluster", "pin", hex_spk, "mesh.example.com"])
        store = InMemoryDNSStore()
        store.publish_txt_record(cluster_rrset_name("mesh.example.com"), wire)
        self._patch_reader(monkeypatch, store)

        # First run: cluster_enabled False -> True, prints "enabled".
        cli.main(["cluster", "enable"])
        capsys.readouterr()

        # Second run: cluster_enabled already True, must still call
        # fetch (verified by the reader returning the same manifest),
        # and exits 0 with an "already enabled" message.
        rc = cli.main(["cluster", "enable"])
        assert rc == 0
        out = capsys.readouterr().out
        assert "already enabled" in out
        # Manifest summary printed again as a sanity-check confirmation.
        assert "cluster: mesh.example.com" in out

        cfg = cli.CLIConfig.load(config_home / "config.yaml")
        assert cfg.cluster_enabled is True

    def test_enable_idempotent_fails_if_manifest_disappears(
        self, config_home, monkeypatch, capsys
    ):
        """A previously-enabled config whose manifest goes unpublished
        must exit 2 on the next `cluster enable` run (re-verification
        fails). Does NOT touch the on-disk enabled flag — the operator
        may want to keep it on and diagnose separately."""
        from dmp.core.cluster import cluster_rrset_name
        from dmp.network.memory import InMemoryDNSStore

        cli.main(
            [
                "init",
                "--no-default-resolvers",
                "alice",
                "--endpoint",
                "http://legacy.example",
            ]
        )
        op, wire, manifest = self._build_signed_manifest()
        hex_spk = op.get_signing_public_key_bytes().hex()
        cli.main(["cluster", "pin", hex_spk, "mesh.example.com"])
        store = InMemoryDNSStore()
        store.publish_txt_record(cluster_rrset_name("mesh.example.com"), wire)
        self._patch_reader(monkeypatch, store)
        cli.main(["cluster", "enable"])
        capsys.readouterr()

        # Now simulate the manifest disappearing — empty store.
        empty_store = InMemoryDNSStore()
        self._patch_reader(monkeypatch, empty_store)
        with pytest.raises(SystemExit) as exc:
            cli.main(["cluster", "enable"])
        assert exc.value.code == 2

    def test_status_shows_enabled_flag(self, config_home, monkeypatch, capsys):
        """`cluster status` surfaces `cluster_enabled: False` after pin
        and `cluster_enabled: True` after enable."""
        from dmp.core.cluster import cluster_rrset_name
        from dmp.network.memory import InMemoryDNSStore

        cli.main(
            [
                "init",
                "--no-default-resolvers",
                "alice",
                "--endpoint",
                "http://legacy.example",
            ]
        )
        op, wire, manifest = self._build_signed_manifest()
        hex_spk = op.get_signing_public_key_bytes().hex()
        cli.main(["cluster", "pin", hex_spk, "mesh.example.com"])
        store = InMemoryDNSStore()
        store.publish_txt_record(cluster_rrset_name("mesh.example.com"), wire)
        self._patch_reader(monkeypatch, store)
        capsys.readouterr()

        # After pin (not enabled).
        rc = cli.main(["cluster", "status"])
        assert rc == 0
        out_before = capsys.readouterr().out
        assert "cluster_enabled: False" in out_before

        # After enable.
        cli.main(["cluster", "enable"])
        capsys.readouterr()
        rc = cli.main(["cluster", "status"])
        assert rc == 0
        out_after = capsys.readouterr().out
        assert "cluster_enabled: True" in out_after

    def test_fetch_works_without_cluster_enabled(
        self, config_home, monkeypatch, capsys
    ):
        """`cluster fetch` is a read-only diagnostic; it must work on a
        pinned-but-not-enabled config (that's its primary pre-enable
        use case)."""
        from dmp.core.cluster import cluster_rrset_name
        from dmp.network.memory import InMemoryDNSStore

        cli.main(
            [
                "init",
                "--no-default-resolvers",
                "alice",
                "--endpoint",
                "http://legacy.example",
            ]
        )
        op, wire, manifest = self._build_signed_manifest()
        hex_spk = op.get_signing_public_key_bytes().hex()
        cli.main(["cluster", "pin", hex_spk, "mesh.example.com"])
        store = InMemoryDNSStore()
        store.publish_txt_record(cluster_rrset_name("mesh.example.com"), wire)
        self._patch_reader(monkeypatch, store)
        capsys.readouterr()

        # cluster_enabled is False here by design.
        cfg = cli.CLIConfig.load(config_home / "config.yaml")
        assert cfg.cluster_enabled is False

        rc = cli.main(["cluster", "fetch"])
        assert rc == 0
        out = capsys.readouterr().out
        assert "cluster: mesh.example.com" in out


class TestClusterConfigPersistence:
    """CLIConfig round-trips the new cluster_* fields."""

    def test_defaults_present_on_fresh_init(self, config_home):
        cli.main(["init", "--no-default-resolvers", "alice", "--endpoint", "http://x"])
        cfg = yaml.safe_load((config_home / "config.yaml").read_text())
        # Empty / default values should be present in the serialized
        # config so post-upgrade loads don't KeyError.
        assert cfg.get("cluster_base_domain", "") == ""
        assert cfg.get("cluster_operator_spk", "") == ""
        assert cfg.get("cluster_refresh_interval", 3600) == 3600
        # M2.wire-polish: cluster_enabled defaults False on fresh init
        # so a bare config is never accidentally in cluster mode.
        assert cfg.get("cluster_enabled", False) is False

    def test_load_tolerates_absent_cluster_fields(self, config_home):
        """An older config (pre-M2.wire) without cluster_* keys loads cleanly."""
        # Write a minimal config omitting the new fields entirely.
        cfg_path = config_home / "config.yaml"
        config_home.mkdir(parents=True, exist_ok=True)
        cfg_path.write_text(
            yaml.safe_dump(
                {
                    "username": "alice",
                    "domain": "mesh.local",
                    "endpoint": "http://x",
                    "kdf_salt": "aa" * 32,
                }
            )
        )
        # Load via the public classmethod and verify defaults.
        loaded = cli.CLIConfig.load(cfg_path)
        assert loaded.cluster_base_domain == ""
        assert loaded.cluster_operator_spk == ""
        assert loaded.cluster_refresh_interval == 3600
        assert loaded.cluster_enabled is False

    def test_load_back_compat_pinned_anchors_default_disabled(self, config_home):
        """A pre-polish config with anchors pinned but no cluster_enabled
        key MUST load as cluster_enabled=False.

        This is the back-compat contract: upgrading the CLI over an
        existing cluster-pinned config must NOT silently flip cluster
        mode on. Operators must explicitly run `dmp cluster enable`
        once to opt in.
        """
        cfg_path = config_home / "config.yaml"
        config_home.mkdir(parents=True, exist_ok=True)
        cfg_path.write_text(
            yaml.safe_dump(
                {
                    "username": "alice",
                    "domain": "mesh.local",
                    "endpoint": "http://x",
                    "kdf_salt": "aa" * 32,
                    "cluster_base_domain": "mesh.example.com",
                    "cluster_operator_spk": "aa" * 32,
                    # No cluster_enabled key at all — mimics a pre-polish
                    # config on disk.
                }
            )
        )
        loaded = cli.CLIConfig.load(cfg_path)
        assert loaded.cluster_base_domain == "mesh.example.com"
        assert loaded.cluster_operator_spk == "aa" * 32
        assert loaded.cluster_enabled is False
        # And therefore cluster mode is NOT active even with both
        # anchors set — operator has to enable explicitly.
        assert cli._cluster_mode_enabled(loaded) is False
        assert cli._cluster_anchors_pinned(loaded) is True


class TestClusterModeInMakeClient:
    """`_make_client` wires the cluster path when both anchors are pinned."""

    def test_make_client_uses_cluster_when_both_anchors_set(
        self, config_home, monkeypatch
    ):
        import time as _time

        from dmp.core.cluster import (
            ClusterManifest,
            ClusterNode,
            cluster_rrset_name,
        )
        from dmp.core.crypto import DMPCrypto
        from dmp.network.memory import InMemoryDNSStore

        op = DMPCrypto()
        manifest = ClusterManifest(
            cluster_name="mesh.example.com",
            operator_spk=op.get_signing_public_key_bytes(),
            nodes=[
                ClusterNode(
                    node_id="n01",
                    http_endpoint="https://n1.example.com:8053",
                    dns_endpoint="127.0.0.1:9999",
                ),
            ],
            seq=1,
            exp=int(_time.time()) + 3600,
        )
        wire = manifest.sign(op)
        store = InMemoryDNSStore()
        store.publish_txt_record(cluster_rrset_name("mesh.example.com"), wire)

        class _StoreReader:
            def query_txt_record(self, name):
                return store.query_txt_record(name)

        monkeypatch.setattr(cli, "_make_reader", lambda cfg: _StoreReader())

        cli.main(["init", "--no-default-resolvers", "alice", "--endpoint", "http://x"])
        cli.main(
            [
                "cluster",
                "pin",
                op.get_signing_public_key_bytes().hex(),
                "mesh.example.com",
            ]
        )
        # Pin no longer activates cluster mode (M2.wire-polish). The
        # operator must `cluster enable` — with the manifest published
        # above, this one-shot fetch sanity check should succeed.
        cli.main(["cluster", "enable"])

        cfg = cli.CLIConfig.load(config_home / "config.yaml")
        client = cli._make_client(cfg, "pw")
        try:
            # Cluster handle must be attached when cluster mode kicks in.
            assert client._cluster_client is not None
            # Writer is a FanoutWriter. Reader is a CompositeReader that
            # wraps the cluster's UnionReader (cluster-local zone) + the
            # bootstrap resolver (external zones) — a raw UnionReader
            # would NXDOMAIN cross-domain identity fetches.
            from dmp.network.composite_reader import CompositeReader
            from dmp.network.fanout_writer import FanoutWriter
            from dmp.network.union_reader import UnionReader

            assert isinstance(client.writer, FanoutWriter)
            assert isinstance(client.reader, CompositeReader)
            # The composite's cluster_reader side is the UnionReader
            # from the cluster client.
            assert isinstance(
                client.reader._cluster_reader,  # type: ignore[attr-defined]
                UnionReader,
            )
            assert (
                client.reader._cluster_base_domain  # type: ignore[attr-defined]
                == "mesh.example.com"
            )
            # Mailbox RRsets must live under the cluster's base domain,
            # not the legacy config.domain (default "mesh.local"). Using
            # the wrong domain here would silently target the wrong zone.
            assert client.domain == "mesh.example.com"
        finally:
            cli._close_client(client)

    def test_make_client_legacy_path_unchanged(self, config_home, monkeypatch):
        """A config WITHOUT cluster_base_domain still uses single-endpoint mode."""
        cli.main(["init", "--no-default-resolvers", "alice", "--endpoint", "http://x"])
        cfg = cli.CLIConfig.load(config_home / "config.yaml")
        assert cfg.cluster_base_domain == ""
        # Build a client — should not attempt cluster fetch.
        client = cli._make_client(cfg, "pw")
        try:
            # No cluster handle in legacy mode.
            assert client._cluster_client is None
        finally:
            cli._close_client(client)


class TestNodeDnsReaderTruncation:
    """`_NodeDnsReader` retries over TCP when the UDP response is truncated.

    DMP RRsets that carry prekey pools or multi-chunk slot manifests can
    easily exceed the 512-byte UDP DNS limit. Nodes return the TC
    (truncated) flag with an empty answer; a client that trusts UDP
    alone silently drops these rrsets and the union reader sees no data.
    The reader must detect TC and retry over TCP.
    """

    def _build_truncated_udp_response(self, request):
        """Return a response with TC set and an empty answer section."""
        import dns.flags
        import dns.message

        response = dns.message.make_response(request)
        response.flags |= dns.flags.TC
        return response

    def _build_tcp_answer_response(self, request, name, values):
        """Return a full (non-truncated) TXT response carrying `values`."""
        import dns.message
        import dns.rdataclass
        import dns.rdatatype
        import dns.rrset

        response = dns.message.make_response(request)
        rrset = dns.rrset.from_text_list(
            name,
            300,
            dns.rdataclass.IN,
            dns.rdatatype.TXT,
            [f'"{v}"' for v in values],
        )
        response.answer.append(rrset)
        return response

    def test_udp_truncation_triggers_tcp_retry(self, monkeypatch):
        """UDP returns TC with empty answer → TCP retry is issued, its
        answer is returned."""
        import dns.query

        from dmp.cli import _NodeDnsReader

        reader = _NodeDnsReader("127.0.0.1:9999", timeout=1.0)
        captured = {"udp_calls": 0, "tcp_calls": 0, "tcp_request": None}

        def fake_udp(request, host, port, timeout):
            captured["udp_calls"] += 1
            return self._build_truncated_udp_response(request)

        def fake_tcp(request, host, port, timeout):
            captured["tcp_calls"] += 1
            captured["tcp_request"] = request
            return self._build_tcp_answer_response(
                request, "example.com.", ["hello-big-rrset"]
            )

        monkeypatch.setattr(dns.query, "udp", fake_udp)
        monkeypatch.setattr(dns.query, "tcp", fake_tcp)

        result = reader.query_txt_record("example.com.")
        assert captured["udp_calls"] == 1
        assert captured["tcp_calls"] == 1
        assert result == ["hello-big-rrset"]

    def test_no_tcp_retry_when_udp_not_truncated(self, monkeypatch):
        """Non-truncated UDP response → TCP must NOT be called."""
        import dns.query

        from dmp.cli import _NodeDnsReader

        reader = _NodeDnsReader("127.0.0.1:9999", timeout=1.0)
        captured = {"udp_calls": 0, "tcp_calls": 0}

        def fake_udp(request, host, port, timeout):
            captured["udp_calls"] += 1
            return self._build_tcp_answer_response(
                request, "example.com.", ["small-rrset"]
            )

        def fake_tcp(request, host, port, timeout):  # pragma: no cover
            captured["tcp_calls"] += 1
            raise AssertionError("TCP should not be called for a non-truncated reply")

        monkeypatch.setattr(dns.query, "udp", fake_udp)
        monkeypatch.setattr(dns.query, "tcp", fake_tcp)

        result = reader.query_txt_record("example.com.")
        assert captured["udp_calls"] == 1
        assert captured["tcp_calls"] == 0
        assert result == ["small-rrset"]

    def test_tcp_retry_failure_raises(self, monkeypatch):
        """UDP truncated + TCP blows up → raises.

        UnionReader distinguishes "healthy missing" (None return) from
        "transport failure" (raised exception) — a TCP connect refused
        is the latter, so the per-node failure counter must fire
        instead of silently succeeding with an empty answer.
        """
        import dns.query
        import pytest

        from dmp.cli import _NodeDnsReader

        reader = _NodeDnsReader("127.0.0.1:9999", timeout=1.0)

        def fake_udp(request, host, port, timeout):
            return self._build_truncated_udp_response(request)

        def fake_tcp(request, host, port, timeout):
            raise OSError("tcp connect refused")

        monkeypatch.setattr(dns.query, "udp", fake_udp)
        monkeypatch.setattr(dns.query, "tcp", fake_tcp)

        with pytest.raises(OSError, match="tcp connect refused"):
            reader.query_txt_record("example.com.")


class TestNodeDnsReaderDnssecGate:
    """``_NodeDnsReader(dnssec_required=True)`` requires the AD flag on
    the recursor's reply. Same policy as ResolverPool / DNSOperations;
    closes the gap codex flagged on PR #39 where cluster-mode reads
    bypassed the AD gate even when the operator opted in."""

    def _build_response(self, request, name, values, *, ad_set: bool):
        import dns.flags
        import dns.message
        import dns.rdataclass
        import dns.rdatatype
        import dns.rrset

        response = dns.message.make_response(request)
        if ad_set:
            response.flags |= dns.flags.AD
        rrset = dns.rrset.from_text_list(
            name,
            300,
            dns.rdataclass.IN,
            dns.rdatatype.TXT,
            [f'"{v}"' for v in values],
        )
        response.answer.append(rrset)
        return response

    def test_default_off_does_not_require_ad(self, monkeypatch):
        """Existing operators get the legacy behavior: AD-less replies
        round-trip cleanly."""
        import dns.query

        from dmp.cli import _NodeDnsReader

        reader = _NodeDnsReader("127.0.0.1:9999")

        def fake_udp(request, host, port, timeout):
            return self._build_response(
                request, "x.example.com.", ["v=dmp1;t=chunk;d=aGk="], ad_set=False
            )

        monkeypatch.setattr(dns.query, "udp", fake_udp)
        assert reader.query_txt_record("x.example.com.") == ["v=dmp1;t=chunk;d=aGk="]

    def test_required_passes_when_ad_set(self, monkeypatch):
        import dns.query

        from dmp.cli import _NodeDnsReader

        reader = _NodeDnsReader("127.0.0.1:9999", dnssec_required=True)

        def fake_udp(request, host, port, timeout):
            return self._build_response(
                request, "x.example.com.", ["validated"], ad_set=True
            )

        monkeypatch.setattr(dns.query, "udp", fake_udp)
        assert reader.query_txt_record("x.example.com.") == ["validated"]

    def test_required_raises_when_ad_unset(self, monkeypatch):
        """A reply without AD is treated as a per-node transport
        failure (raised), not as a healthy "no records" outcome.
        UnionReader counts it against the node so a non-validating
        upstream gets demoted instead of silently passing through.
        The raised type is ``DnssecValidationError`` so callers (and
        future metrics/dashboards) can distinguish DNSSEC rejection
        from generic transport failures; it subclasses ``RuntimeError``
        so legacy ``except RuntimeError:`` keeps working."""
        import dns.query

        from dmp.cli import _NodeDnsReader
        from dmp.core.dns import DnssecValidationError

        reader = _NodeDnsReader("127.0.0.1:9999", dnssec_required=True)

        def fake_udp(request, host, port, timeout):
            return self._build_response(
                request, "x.example.com.", ["unvalidated"], ad_set=False
            )

        monkeypatch.setattr(dns.query, "udp", fake_udp)
        with pytest.raises(DnssecValidationError, match="AD flag missing"):
            reader.query_txt_record("x.example.com.")
        # Subclass relationship: legacy ``except RuntimeError:``
        # handlers must still catch this.
        assert issubclass(DnssecValidationError, RuntimeError)

    def test_required_sets_do_bit_on_outgoing_query(self, monkeypatch):
        """Without the DO bit on the outgoing query, many recursors
        strip RRSIGs and never set AD on the response. Verify the
        wire query carries DO so a validating recursor will actually
        do the validation we're going to check for."""
        import dns.flags
        import dns.query

        from dmp.cli import _NodeDnsReader

        reader = _NodeDnsReader("127.0.0.1:9999", dnssec_required=True)
        captured = {}

        def fake_udp(request, host, port, timeout):
            captured["request"] = request
            return self._build_response(request, "x.example.com.", ["v"], ad_set=True)

        monkeypatch.setattr(dns.query, "udp", fake_udp)
        reader.query_txt_record("x.example.com.")
        # dnspython's Message.ednsflags reflects the DO bit on the
        # outgoing question.
        assert captured["request"].ednsflags & dns.flags.DO

    def test_required_raises_on_ad_less_nxdomain(self, monkeypatch):
        """DNSSEC supports validated denial of existence — a real
        validating recursor sets AD on NXDOMAIN for signed zones. An
        AD-less NXDOMAIN is indistinguishable from a spoofed one and
        must not be accepted as a healthy 'no record' answer when the
        operator opted in to `dnssec_required`."""
        import dns.message
        import dns.query
        import dns.rcode

        from dmp.cli import _NodeDnsReader

        reader = _NodeDnsReader("127.0.0.1:9999", dnssec_required=True)

        def fake_udp(request, host, port, timeout):
            response = dns.message.make_response(request)
            response.set_rcode(dns.rcode.NXDOMAIN)
            return response

        monkeypatch.setattr(dns.query, "udp", fake_udp)
        with pytest.raises(RuntimeError, match="AD flag missing"):
            reader.query_txt_record("missing.example.com.")

    def test_required_accepts_validated_nxdomain(self, monkeypatch):
        """AD-set NXDOMAIN is a validated denial — accept as a healthy
        'no record' (return None). UnionReader treats None as
        healthy-not-found, distinct from a transport error."""
        import dns.flags
        import dns.message
        import dns.query
        import dns.rcode

        from dmp.cli import _NodeDnsReader

        reader = _NodeDnsReader("127.0.0.1:9999", dnssec_required=True)

        def fake_udp(request, host, port, timeout):
            response = dns.message.make_response(request)
            response.set_rcode(dns.rcode.NXDOMAIN)
            response.flags |= dns.flags.AD
            return response

        monkeypatch.setattr(dns.query, "udp", fake_udp)
        assert reader.query_txt_record("missing.example.com.") is None

    def test_required_checks_ad_after_tcp_retry(self, monkeypatch):
        """When UDP returns truncated and the reader retries over TCP,
        the AD check must apply to the TCP response — not the UDP one.
        Without this, an attacker who can spoof TC=1 forces a TCP
        retry whose unvalidated answer would slip through."""
        import dns.flags
        import dns.message
        import dns.query

        from dmp.cli import _NodeDnsReader

        reader = _NodeDnsReader("127.0.0.1:9999", dnssec_required=True)

        def fake_udp(request, host, port, timeout):
            response = dns.message.make_response(request)
            response.flags |= dns.flags.TC  # truncated → forces TCP retry
            response.flags |= dns.flags.AD  # AD on UDP must not satisfy the gate
            return response

        def fake_tcp(request, host, port, timeout):
            response = dns.message.make_response(request)
            # TCP response WITHOUT AD — this is the one the gate must see.
            return response

        monkeypatch.setattr(dns.query, "udp", fake_udp)
        monkeypatch.setattr(dns.query, "tcp", fake_tcp)
        with pytest.raises(RuntimeError, match="AD flag missing"):
            reader.query_txt_record("x.example.com.")


class TestDnsReaderDnssecLogs:
    # `_DnsReader` (the single-host reader the CLI builds when the
    # operator passes only --dns-host) returns None when the AD bit
    # is missing on a `dnssec_required=True` reply. Without a log
    # the operator sees empty results with no signal that DNSSEC
    # enforcement is the cause — same blind spot the heartbeat
    # reader had before #49.

    def test_logs_when_dropping_ad_less_answer(self, monkeypatch, caplog):
        import logging

        import dns.flags
        import dns.resolver

        class _FakeRdata:
            def __init__(self, s):
                self.strings = [s.encode("utf-8")]

        class _FakeResponse:
            def __init__(self, ad):
                self.flags = dns.flags.AD if ad else 0

        class _FakeAnswer(list):
            def __init__(self, vals, ad):
                super().__init__(_FakeRdata(v) for v in vals)
                self.response = _FakeResponse(ad)

        def fake_resolve(self, name, rdtype):
            return _FakeAnswer(["nope"], ad=False)

        monkeypatch.setattr(dns.resolver.Resolver, "resolve", fake_resolve)
        reader = cli._DnsReader("127.0.0.1", 53, dnssec_required=True)
        with caplog.at_level(logging.WARNING, logger="dmp.cli"):
            assert reader.query_txt_record("missing-token") is None
        msgs = [r.getMessage() for r in caplog.records if r.levelno == logging.WARNING]
        assert any(
            "AD-less TXT" in m
            and "missing-token" in m
            and "127.0.0.1:53" in m
            and "dnssec_required=True" in m
            for m in msgs
        ), msgs

    def test_logs_when_dropping_ad_less_nxdomain(self, monkeypatch, caplog):
        # Negative-response AD gate: the same threat model that
        # forced the positive-answer gate applies to NXDOMAIN.
        import logging

        import dns.flags
        import dns.message
        import dns.name
        import dns.resolver

        def side_effect(self, name, rdtype):
            qname = dns.name.from_text(name) if isinstance(name, str) else name
            response = dns.message.Message()
            response.flags = dns.flags.QR | dns.flags.RA  # AD intentionally unset
            raise dns.resolver.NXDOMAIN(qnames=[qname], responses={qname: response})

        monkeypatch.setattr(dns.resolver.Resolver, "resolve", side_effect)
        reader = cli._DnsReader("127.0.0.1", 53, dnssec_required=True)
        with caplog.at_level(logging.WARNING, logger="dmp.cli"):
            assert reader.query_txt_record("forged-host") is None
        msgs = [r.getMessage() for r in caplog.records if r.levelno == logging.WARNING]
        assert any(
            "AD-less negative TXT" in m
            and "forged-host" in m
            and "127.0.0.1:53" in m
            and "dnssec_required=True" in m
            for m in msgs
        ), msgs


class TestLocalOnlyClusterBootstrap:
    """Local-only CLI commands must not crash on cluster bootstrap failure.

    `dmp identity show` prints only local-config state + keys derived
    from the passphrase. In cluster mode, _make_client used to call
    fetch_cluster_manifest unconditionally and die with exit 2 when DNS
    was unreachable — breaking offline use. The fix routes local-only
    commands through _make_client(..., requires_network=False) so they
    skip the manifest fetch entirely.
    """

    def _pin_cluster_unreachable(self, monkeypatch):
        """Make `fetch_cluster_manifest` behave as if DNS is offline."""
        import dmp.cli as cli_mod

        def failing_fetch(*args, **kwargs):
            return None  # simulates "nothing verifying / DNS unreachable"

        monkeypatch.setattr(cli_mod, "fetch_cluster_manifest", failing_fetch)

    def _force_cluster_enabled(self, config_home):
        """Flip cluster_enabled=True on disk directly.

        Post-M2.wire-polish, cluster mode requires explicit activation
        via `dmp cluster enable` — but enable runs a live fetch check
        that these tests are specifically trying to simulate failing.
        Writing the flag straight into config.yaml bypasses the live
        check so we can exercise the cluster-mode bootstrap-failure
        paths (identity show stays local, send fails loudly).
        """
        cfg_path = config_home / "config.yaml"
        data = yaml.safe_load(cfg_path.read_text())
        data["cluster_enabled"] = True
        cfg_path.write_text(yaml.safe_dump(data, sort_keys=True))

    def test_identity_show_works_when_cluster_fetch_fails(
        self, config_home, monkeypatch, capsys
    ):
        """`dmp identity show` must print local identity even when the
        pinned cluster manifest is unreachable."""
        from dmp.core.crypto import DMPCrypto

        # Pin a cluster (both anchors set -> cluster mode on after enable).
        cli.main(["init", "--no-default-resolvers", "alice", "--endpoint", "http://x"])
        op = DMPCrypto()
        cli.main(
            [
                "cluster",
                "pin",
                op.get_signing_public_key_bytes().hex(),
                "mesh.unreachable.example",
            ]
        )
        # Force cluster_enabled=True on disk (bypasses the live fetch
        # check in `cluster enable` since this test is specifically
        # about the fetch-failure path).
        self._force_cluster_enabled(config_home)
        capsys.readouterr()

        # Simulate DNS outage — manifest fetch returns None.
        self._pin_cluster_unreachable(monkeypatch)

        monkeypatch.setenv("DMP_PASSPHRASE", "pw")
        rc = cli.main(["identity", "show"])
        assert rc == 0
        out = capsys.readouterr().out
        assert "username: alice" in out
        assert "public_key:" in out

    def test_identity_show_json_works_when_cluster_fetch_fails(
        self, config_home, monkeypatch, capsys
    ):
        """JSON variant of the same: offline identity show still succeeds."""
        import json as _json

        from dmp.core.crypto import DMPCrypto

        cli.main(["init", "--no-default-resolvers", "alice", "--endpoint", "http://x"])
        op = DMPCrypto()
        cli.main(
            [
                "cluster",
                "pin",
                op.get_signing_public_key_bytes().hex(),
                "mesh.unreachable.example",
            ]
        )
        self._force_cluster_enabled(config_home)
        capsys.readouterr()

        self._pin_cluster_unreachable(monkeypatch)

        monkeypatch.setenv("DMP_PASSPHRASE", "pw")
        rc = cli.main(["identity", "show", "--json"])
        assert rc == 0
        parsed = _json.loads(capsys.readouterr().out)
        assert parsed["username"] == "alice"
        assert len(parsed["public_key"]) == 64

    def test_send_still_fails_loudly_when_cluster_fetch_fails(
        self, config_home, monkeypatch, capsys
    ):
        """A networked command (`dmp send`) MUST still fail loudly with a
        clear error + non-zero exit when bootstrap fails. Silencing that
        would hide real breakage."""
        from dmp.core.crypto import DMPCrypto

        cli.main(["init", "--no-default-resolvers", "alice", "--endpoint", "http://x"])
        op = DMPCrypto()
        cli.main(
            [
                "cluster",
                "pin",
                op.get_signing_public_key_bytes().hex(),
                "mesh.unreachable.example",
            ]
        )
        self._force_cluster_enabled(config_home)
        # Stash a contact so send gets past the unknown-contact check.
        cli.main(["contacts", "add", "bob", "aa" * 32])
        capsys.readouterr()

        self._pin_cluster_unreachable(monkeypatch)

        monkeypatch.setenv("DMP_PASSPHRASE", "pw")
        with pytest.raises(SystemExit) as exc:
            cli.main(["send", "bob", "hi"])
        # Exit 2 is the network/backend error code per cli.py docstring.
        assert exc.value.code == 2
        err = capsys.readouterr().err
        assert "cluster manifest fetch failed" in err

    def test_offline_writer_raises_on_publish(self):
        """The offline placeholder writer must raise loudly on use, not
        silently return success — otherwise a buggy command could think
        it had published a record when in reality nothing went out."""
        from dmp.cli import _OfflineWriter

        w = _OfflineWriter()
        with pytest.raises(RuntimeError, match="network unavailable"):
            w.publish_txt_record("example.com.", "value")
        with pytest.raises(RuntimeError, match="network unavailable"):
            w.delete_txt_record("example.com.")

    def test_offline_reader_raises_on_query(self):
        """Same for the placeholder reader: raise, don't return None."""
        from dmp.cli import _OfflineReader

        r = _OfflineReader()
        with pytest.raises(RuntimeError, match="network unavailable"):
            r.query_txt_record("example.com.")

    def test_make_client_skips_fetch_when_requires_network_false(
        self, config_home, monkeypatch
    ):
        """Direct unit-level check: `requires_network=False` must not
        invoke fetch_cluster_manifest at all, even when cluster mode is
        pinned."""
        import dmp.cli as cli_mod
        from dmp.core.crypto import DMPCrypto

        cli.main(["init", "--no-default-resolvers", "alice", "--endpoint", "http://x"])
        op = DMPCrypto()
        cli.main(
            [
                "cluster",
                "pin",
                op.get_signing_public_key_bytes().hex(),
                "mesh.never.fetched.example",
            ]
        )
        self._force_cluster_enabled(config_home)

        called = {"fetch_calls": 0}

        def boom_fetch(*args, **kwargs):
            called["fetch_calls"] += 1
            raise AssertionError(
                "fetch_cluster_manifest must NOT be called in local-only mode"
            )

        monkeypatch.setattr(cli_mod, "fetch_cluster_manifest", boom_fetch)

        cfg = cli.CLIConfig.load(config_home / "config.yaml")
        client = cli._make_client(cfg, "pw", requires_network=False)
        try:
            assert called["fetch_calls"] == 0
            # Cluster handle is NOT created in local-only mode (we skipped
            # the manifest → no ClusterClient to attach).
            assert client._cluster_client is None
            # Writer/reader are the offline placeholders — local ops like
            # get_user_info() still work, but any accidental network call
            # raises loudly.
            assert isinstance(client.writer, cli_mod._OfflineWriter)
            assert isinstance(client.reader, cli_mod._OfflineReader)
        finally:
            cli._close_client(client)


class TestBootstrapCommand:
    """`dmp bootstrap pin` / `dmp bootstrap fetch` / `dmp bootstrap discover`.

    M3.2-wire: bootstrap discovery translates `user@host` addresses
    into concrete cluster anchors without prior `cluster pin` config.
    Tests cover pin validation, fetch summary printing, unreachable
    DNS, end-to-end discover → auto-pin with two-hop verification,
    and `identity fetch --via-bootstrap`.
    """

    # ----------------------------------------------------------- helpers

    def _patch_reader(self, monkeypatch, store):
        """Force `_make_reader` to return a reader backed by `store`."""

        class _StoreReader:
            def query_txt_record(self, name):
                return store.query_txt_record(name)

        monkeypatch.setattr(cli, "_make_reader", lambda cfg: _StoreReader())

    def _publish_bootstrap(self, store, *, user_domain, signer, entries, seq=1):
        """Publish a signed BootstrapRecord into the given store."""
        import time as _time

        from dmp.core.bootstrap import BootstrapRecord, bootstrap_rrset_name

        record = BootstrapRecord(
            user_domain=user_domain,
            signer_spk=signer.get_signing_public_key_bytes(),
            entries=list(entries),
            seq=seq,
            exp=int(_time.time()) + 3600,
        )
        store.publish_txt_record(bootstrap_rrset_name(user_domain), record.sign(signer))
        return record

    def _publish_cluster_manifest(
        self, store, *, cluster_name, operator, n_nodes=2, seq=1
    ):
        """Publish a signed ClusterManifest at cluster.<cluster_name>."""
        import time as _time

        from dmp.core.cluster import ClusterManifest, ClusterNode, cluster_rrset_name

        nodes = [
            ClusterNode(
                node_id=f"n{i:02d}",
                http_endpoint=f"https://n{i}.{cluster_name}:8053",
                dns_endpoint=f"203.0.113.{i}:53",
            )
            for i in range(1, n_nodes + 1)
        ]
        manifest = ClusterManifest(
            cluster_name=cluster_name,
            operator_spk=operator.get_signing_public_key_bytes(),
            nodes=nodes,
            seq=seq,
            exp=int(_time.time()) + 3600,
        )
        store.publish_txt_record(
            cluster_rrset_name(cluster_name), manifest.sign(operator)
        )
        return manifest

    # ----------------------------------------------------------- bootstrap pin

    def test_bootstrap_pin_writes_config(self, config_home):
        from dmp.core.crypto import DMPCrypto

        cli.main(["init", "--no-default-resolvers", "alice", "--endpoint", "http://x"])
        signer = DMPCrypto()
        hex_spk = signer.get_signing_public_key_bytes().hex()
        rc = cli.main(["bootstrap", "pin", "example.com", hex_spk])
        assert rc == 0
        cfg = yaml.safe_load((config_home / "config.yaml").read_text())
        assert cfg["bootstrap_user_domain"] == "example.com"
        assert cfg["bootstrap_signer_spk"] == hex_spk

    def test_bootstrap_pin_does_not_fetch(self, config_home, monkeypatch):
        """`bootstrap pin` must not call fetch_bootstrap_record — pinning
        an operator whose record is not yet published should be safe."""
        import dmp.cli as cli_mod
        from dmp.core.crypto import DMPCrypto

        cli.main(["init", "--no-default-resolvers", "alice", "--endpoint", "http://x"])
        signer = DMPCrypto()

        def boom_fetch(*args, **kwargs):  # pragma: no cover
            raise AssertionError("fetch_bootstrap_record must NOT be called by pin")

        monkeypatch.setattr(cli_mod, "fetch_bootstrap_record", boom_fetch)
        rc = cli.main(
            [
                "bootstrap",
                "pin",
                "example.com",
                signer.get_signing_public_key_bytes().hex(),
            ]
        )
        assert rc == 0

    def test_bootstrap_pin_rejects_malformed_user_domain(self, config_home):
        from dmp.core.crypto import DMPCrypto

        cli.main(["init", "--no-default-resolvers", "alice", "--endpoint", "http://x"])
        signer = DMPCrypto()
        hex_spk = signer.get_signing_public_key_bytes().hex()
        # Leading dot — _validate_dns_name rejects.
        with pytest.raises(SystemExit) as exc:
            cli.main(["bootstrap", "pin", ".example.com", hex_spk])
        assert exc.value.code == 1

    def test_bootstrap_pin_rejects_bad_hex(self, config_home):
        cli.main(["init", "--no-default-resolvers", "alice", "--endpoint", "http://x"])
        with pytest.raises(SystemExit) as exc:
            cli.main(["bootstrap", "pin", "example.com", "not-hex"])
        assert exc.value.code == 1

    def test_bootstrap_pin_rejects_wrong_length(self, config_home):
        cli.main(["init", "--no-default-resolvers", "alice", "--endpoint", "http://x"])
        # 16-byte hex (too short for Ed25519).
        with pytest.raises(SystemExit) as exc:
            cli.main(["bootstrap", "pin", "example.com", "aa" * 16])
        assert exc.value.code == 1

    # ----------------------------------------------------------- bootstrap fetch

    def test_bootstrap_fetch_prints_summary(self, config_home, monkeypatch, capsys):
        from dmp.core.bootstrap import BootstrapEntry
        from dmp.core.crypto import DMPCrypto
        from dmp.network.memory import InMemoryDNSStore

        cli.main(["init", "--no-default-resolvers", "alice", "--endpoint", "http://x"])
        signer = DMPCrypto()
        hex_spk = signer.get_signing_public_key_bytes().hex()
        cli.main(["bootstrap", "pin", "example.com", hex_spk])
        capsys.readouterr()

        store = InMemoryDNSStore()
        cluster_op = DMPCrypto()
        self._publish_bootstrap(
            store,
            user_domain="example.com",
            signer=signer,
            entries=[
                BootstrapEntry(
                    priority=10,
                    cluster_base_domain="mesh.example.com",
                    operator_spk=cluster_op.get_signing_public_key_bytes(),
                ),
                BootstrapEntry(
                    priority=20,
                    cluster_base_domain="backup.example.com",
                    operator_spk=cluster_op.get_signing_public_key_bytes(),
                ),
            ],
            seq=3,
        )
        self._patch_reader(monkeypatch, store)

        rc = cli.main(["bootstrap", "fetch"])
        assert rc == 0
        out = capsys.readouterr().out
        assert "user_domain: example.com" in out
        assert "seq:         3" in out
        assert "priority=10" in out
        assert "mesh.example.com" in out
        assert "priority=20" in out
        assert "backup.example.com" in out

    def test_bootstrap_fetch_without_pin_errors(self, config_home):
        cli.main(["init", "--no-default-resolvers", "alice", "--endpoint", "http://x"])
        with pytest.raises(SystemExit) as exc:
            cli.main(["bootstrap", "fetch"])
        assert exc.value.code == 1

    def test_bootstrap_fetch_nothing_published_exits_2(self, config_home, monkeypatch):
        from dmp.core.crypto import DMPCrypto
        from dmp.network.memory import InMemoryDNSStore

        cli.main(["init", "--no-default-resolvers", "alice", "--endpoint", "http://x"])
        signer = DMPCrypto()
        cli.main(
            [
                "bootstrap",
                "pin",
                "example.com",
                signer.get_signing_public_key_bytes().hex(),
            ]
        )

        store = InMemoryDNSStore()  # nothing published
        self._patch_reader(monkeypatch, store)

        with pytest.raises(SystemExit) as exc:
            cli.main(["bootstrap", "fetch"])
        assert exc.value.code == 2

    def test_bootstrap_fetch_unreachable_dns_exits_2(self, config_home, monkeypatch):
        """Reader that raises on query → treated as unreachable → exit 2."""
        from dmp.core.crypto import DMPCrypto

        cli.main(["init", "--no-default-resolvers", "alice", "--endpoint", "http://x"])
        signer = DMPCrypto()
        cli.main(
            [
                "bootstrap",
                "pin",
                "example.com",
                signer.get_signing_public_key_bytes().hex(),
            ]
        )

        class _FailingReader:
            def query_txt_record(self, name):
                raise RuntimeError("dns unreachable")

        monkeypatch.setattr(cli, "_make_reader", lambda cfg: _FailingReader())

        with pytest.raises(SystemExit) as exc:
            cli.main(["bootstrap", "fetch"])
        assert exc.value.code == 2

    def test_bootstrap_fetch_with_cli_override(self, config_home, monkeypatch, capsys):
        """CLI args override any pinned anchors — useful for pre-pin
        verification. No pin in config here at all."""
        from dmp.core.bootstrap import BootstrapEntry
        from dmp.core.crypto import DMPCrypto
        from dmp.network.memory import InMemoryDNSStore

        cli.main(["init", "--no-default-resolvers", "alice", "--endpoint", "http://x"])
        signer = DMPCrypto()
        hex_spk = signer.get_signing_public_key_bytes().hex()
        store = InMemoryDNSStore()
        cluster_op = DMPCrypto()
        self._publish_bootstrap(
            store,
            user_domain="example.com",
            signer=signer,
            entries=[
                BootstrapEntry(
                    priority=10,
                    cluster_base_domain="mesh.example.com",
                    operator_spk=cluster_op.get_signing_public_key_bytes(),
                )
            ],
        )
        self._patch_reader(monkeypatch, store)

        rc = cli.main(
            [
                "bootstrap",
                "fetch",
                "--user-domain",
                "example.com",
                "--signer-spk",
                hex_spk,
            ]
        )
        assert rc == 0
        out = capsys.readouterr().out
        assert "user_domain: example.com" in out

    # ----------------------------------------------------------- bootstrap discover

    def test_bootstrap_discover_prints_guidance(self, config_home, monkeypatch, capsys):
        """Without --auto-pin, discover is a pure diagnostic that prints
        what a manual `dmp cluster pin` would do; no config is written."""
        from dmp.core.bootstrap import BootstrapEntry
        from dmp.core.crypto import DMPCrypto
        from dmp.network.memory import InMemoryDNSStore

        cli.main(["init", "--no-default-resolvers", "alice", "--endpoint", "http://x"])
        signer = DMPCrypto()
        hex_spk = signer.get_signing_public_key_bytes().hex()
        cli.main(["bootstrap", "pin", "example.com", hex_spk])
        capsys.readouterr()

        store = InMemoryDNSStore()
        cluster_op = DMPCrypto()
        self._publish_bootstrap(
            store,
            user_domain="example.com",
            signer=signer,
            entries=[
                BootstrapEntry(
                    priority=10,
                    cluster_base_domain="mesh.example.com",
                    operator_spk=cluster_op.get_signing_public_key_bytes(),
                )
            ],
        )
        self._patch_reader(monkeypatch, store)

        rc = cli.main(["bootstrap", "discover", "alice@example.com"])
        assert rc == 0
        out = capsys.readouterr().out
        assert "alice@example.com" in out
        assert "mesh.example.com" in out
        assert "dnsmesh cluster pin" in out
        assert "dnsmesh cluster enable" in out
        assert "--auto-pin" in out

        # No config mutation: cluster_* fields remain empty.
        cfg = cli.CLIConfig.load(config_home / "config.yaml")
        assert cfg.cluster_base_domain == ""
        assert cfg.cluster_operator_spk == ""
        assert cfg.cluster_enabled is False

    def test_bootstrap_discover_requires_pinned_host_or_signer(
        self, config_home, capsys
    ):
        """discover without a pin for the host AND without --signer-spk
        must exit 1 with a clear error."""
        cli.main(["init", "--no-default-resolvers", "alice", "--endpoint", "http://x"])
        with pytest.raises(SystemExit) as exc:
            cli.main(["bootstrap", "discover", "alice@example.com"])
        assert exc.value.code == 1

    def test_bootstrap_discover_auto_pin_writes_both_configs(
        self, config_home, monkeypatch, capsys
    ):
        """--auto-pin verifies bootstrap AND cluster manifest, then writes
        bootstrap + cluster anchors and sets cluster_enabled=True."""
        from dmp.core.bootstrap import BootstrapEntry
        from dmp.core.crypto import DMPCrypto
        from dmp.network.memory import InMemoryDNSStore

        cli.main(["init", "--no-default-resolvers", "alice", "--endpoint", "http://x"])
        signer = DMPCrypto()
        hex_spk = signer.get_signing_public_key_bytes().hex()
        cli.main(["bootstrap", "pin", "example.com", hex_spk])
        capsys.readouterr()

        store = InMemoryDNSStore()
        cluster_op = DMPCrypto()
        cluster_op_hex = cluster_op.get_signing_public_key_bytes().hex()
        self._publish_bootstrap(
            store,
            user_domain="example.com",
            signer=signer,
            entries=[
                BootstrapEntry(
                    priority=10,
                    cluster_base_domain="mesh.example.com",
                    operator_spk=cluster_op.get_signing_public_key_bytes(),
                )
            ],
        )
        # The cluster manifest MUST also verify — auto-pin's two-hop
        # trust chain rejects if either step fails.
        self._publish_cluster_manifest(
            store, cluster_name="mesh.example.com", operator=cluster_op, n_nodes=2
        )
        self._patch_reader(monkeypatch, store)

        rc = cli.main(["bootstrap", "discover", "alice@example.com", "--auto-pin"])
        assert rc == 0
        out = capsys.readouterr().out
        assert "cluster:" in out
        assert "mesh.example.com" in out
        assert "cluster_enabled       = True" in out

        cfg = cli.CLIConfig.load(config_home / "config.yaml")
        assert cfg.bootstrap_user_domain == "example.com"
        assert cfg.bootstrap_signer_spk == hex_spk
        assert cfg.cluster_base_domain == "mesh.example.com"
        assert cfg.cluster_operator_spk == cluster_op_hex
        assert cfg.cluster_enabled is True

    def test_bootstrap_discover_auto_pin_aborts_on_manifest_failure(
        self, config_home, monkeypatch, capsys
    ):
        """If the bootstrap record verifies but the cluster manifest does
        NOT (not published, wrong key, etc.), --auto-pin must leave
        config untouched. Half-written state is worse than none."""
        from dmp.core.bootstrap import BootstrapEntry
        from dmp.core.crypto import DMPCrypto
        from dmp.network.memory import InMemoryDNSStore

        cli.main(["init", "--no-default-resolvers", "alice", "--endpoint", "http://x"])
        signer = DMPCrypto()
        hex_spk = signer.get_signing_public_key_bytes().hex()
        cli.main(["bootstrap", "pin", "example.com", hex_spk])
        capsys.readouterr()

        store = InMemoryDNSStore()
        cluster_op = DMPCrypto()
        self._publish_bootstrap(
            store,
            user_domain="example.com",
            signer=signer,
            entries=[
                BootstrapEntry(
                    priority=10,
                    cluster_base_domain="mesh.example.com",
                    operator_spk=cluster_op.get_signing_public_key_bytes(),
                )
            ],
        )
        # Deliberately DO NOT publish the cluster manifest — auto-pin
        # must abort at the second verification hop.
        self._patch_reader(monkeypatch, store)

        with pytest.raises(SystemExit) as exc:
            cli.main(["bootstrap", "discover", "alice@example.com", "--auto-pin"])
        assert exc.value.code == 2
        err = capsys.readouterr().err
        assert "no usable cluster manifest" in err

        # Config must not have been mutated. Before discover ran, only
        # bootstrap_* was set via pin; cluster_* remained empty.
        cfg = cli.CLIConfig.load(config_home / "config.yaml")
        assert cfg.cluster_base_domain == ""
        assert cfg.cluster_operator_spk == ""
        assert cfg.cluster_enabled is False
        # bootstrap anchor was pinned up-front; it's untouched too.
        assert cfg.bootstrap_user_domain == "example.com"
        assert cfg.bootstrap_signer_spk == hex_spk

    def test_bootstrap_discover_rejects_bad_address(self, config_home):
        cli.main(["init", "--no-default-resolvers", "alice", "--endpoint", "http://x"])
        with pytest.raises(SystemExit) as exc:
            cli.main(["bootstrap", "discover", "no-at-sign"])
        assert exc.value.code == 1

    # ----------------------------------------------------------- config persistence

    def test_config_defaults_include_bootstrap_fields(self, config_home):
        cli.main(["init", "--no-default-resolvers", "alice", "--endpoint", "http://x"])
        cfg = yaml.safe_load((config_home / "config.yaml").read_text())
        assert cfg.get("bootstrap_user_domain", "") == ""
        assert cfg.get("bootstrap_signer_spk", "") == ""

    def test_load_tolerates_absent_bootstrap_fields(self, config_home):
        """An older config without bootstrap_* keys loads cleanly as empty."""
        cfg_path = config_home / "config.yaml"
        config_home.mkdir(parents=True, exist_ok=True)
        cfg_path.write_text(
            yaml.safe_dump(
                {
                    "username": "alice",
                    "domain": "mesh.local",
                    "endpoint": "http://x",
                    "kdf_salt": "aa" * 32,
                }
            )
        )
        loaded = cli.CLIConfig.load(cfg_path)
        assert loaded.bootstrap_user_domain == ""
        assert loaded.bootstrap_signer_spk == ""

    # ----------------------------------------------------------- identity fetch --via-bootstrap

    def test_identity_fetch_via_bootstrap_routes_through_discovered_cluster(
        self, config_home, monkeypatch, capsys
    ):
        """`identity fetch alice@example.com --via-bootstrap` discovers
        the cluster for `example.com` on the fly (no pinned cluster),
        then queries the identity record via the discovered cluster.
        Does NOT persist any cluster config — pure lookup convenience."""
        import hashlib
        import time as _time

        from dmp.core.bootstrap import BootstrapEntry
        from dmp.core.crypto import DMPCrypto
        from dmp.core.identity import (
            IdentityRecord,
            zone_anchored_identity_name,
        )
        from dmp.network.memory import InMemoryDNSStore

        cli.main(["init", "--no-default-resolvers", "bob", "--endpoint", "http://x"])
        signer = DMPCrypto()  # zone operator for example.com
        cluster_op = DMPCrypto()  # cluster operator
        cli.main(
            [
                "bootstrap",
                "pin",
                "example.com",
                signer.get_signing_public_key_bytes().hex(),
            ]
        )
        capsys.readouterr()

        store = InMemoryDNSStore()
        # 1. Bootstrap record pointing at mesh.example.com cluster.
        self._publish_bootstrap(
            store,
            user_domain="example.com",
            signer=signer,
            entries=[
                BootstrapEntry(
                    priority=10,
                    cluster_base_domain="mesh.example.com",
                    operator_spk=cluster_op.get_signing_public_key_bytes(),
                )
            ],
        )
        # 2. Cluster manifest at cluster.mesh.example.com. Use
        #    dns_endpoint=None on every node so _make_cluster_reader_factory
        #    falls back to the shared bootstrap_reader (the patched store)
        #    — that simulates a real deployment where the cluster nodes
        #    are authoritative for the user's zone and the union reader
        #    queries them for dmp.example.com directly.
        import time as _time2
        from dmp.core.cluster import (
            ClusterManifest as _CM,
            ClusterNode as _CN,
            cluster_rrset_name as _crn,
        )

        nodes = [
            _CN(
                node_id=f"n{i:02d}",
                http_endpoint=f"https://n{i}.mesh.example.com:8053",
                dns_endpoint=None,  # falls back to bootstrap_reader in the factory
            )
            for i in range(1, 3)
        ]
        cluster_manifest = _CM(
            cluster_name="mesh.example.com",
            operator_spk=cluster_op.get_signing_public_key_bytes(),
            nodes=nodes,
            seq=1,
            exp=int(_time2.time()) + 3600,
        )
        store.publish_txt_record(
            _crn("mesh.example.com"), cluster_manifest.sign(cluster_op)
        )
        # 3. Alice's identity record published under the cluster zone
        #    (zone-anchored: dmp.example.com TXT). The bootstrap-
        #    discovered flow queries dmp.<host> where host = example.com.
        alice_crypto = DMPCrypto()
        identity = IdentityRecord(
            username="alice",
            x25519_pk=alice_crypto.get_public_key_bytes(),
            ed25519_spk=alice_crypto.get_signing_public_key_bytes(),
            ts=int(_time.time()),
        )
        identity_wire = identity.sign(alice_crypto)
        store.publish_txt_record(
            zone_anchored_identity_name("example.com"), identity_wire
        )

        self._patch_reader(monkeypatch, store)

        rc = cli.main(
            ["identity", "fetch", "alice@example.com", "--via-bootstrap", "--json"]
        )
        assert rc == 0

        import json as _json

        out = capsys.readouterr().out
        parsed = _json.loads(out)
        assert parsed["username"] == "alice"
        assert parsed["public_key"] == alice_crypto.get_public_key_bytes().hex()

        # Via-bootstrap is a pure lookup — must NOT have written
        # cluster anchors to config.
        cfg = cli.CLIConfig.load(config_home / "config.yaml")
        assert cfg.cluster_base_domain == ""
        assert cfg.cluster_operator_spk == ""
        assert cfg.cluster_enabled is False


class TestDoctor:
    """Tests for the `dnsmesh doctor` config-drift detector."""

    def test_clean_config_passes(self, config_home, monkeypatch, capsys):
        """A config with reachable endpoint, pinned local DNS, and a
        TSIG block produces all PASS / no FAIL."""
        # Stub HTTP /health → 200.
        import requests

        class _OkResponse:
            status_code = 200

        monkeypatch.setattr(requests, "get", lambda *_a, **_kw: _OkResponse())

        # Stub the local-DNS probe → responds.
        from dmp import cli as _cli

        monkeypatch.setattr(_cli, "_local_dns_target_responds", lambda *_a, **_kw: True)

        cli.main(
            [
                "init",
                "--no-default-resolvers",
                "--no-probe-local-dns",
                "alice",
                "--endpoint",
                "http://node.example:8053",
            ]
        )
        # Hand-edit config to populate the M10 + TSIG fields the
        # auto-probe would normally fill.
        cfg = cli.CLIConfig.load(config_home / "config.yaml")
        cfg.local_node_dns_server = "node.example"
        cfg.local_node_dns_port = 5353
        cfg.tsig_key_name = "alice."
        cfg.tsig_secret_hex = "aa" * 32
        cfg.tsig_zone = "node.example"
        cfg.save(config_home / "config.yaml")

        rc = cli.main(["doctor"])
        out = capsys.readouterr().out
        assert rc == 0
        assert "DOCTOR: clean" in out
        assert "FAIL" not in out

    def test_unreachable_endpoint_fails(self, config_home, monkeypatch, capsys):
        """Endpoint that does not respond to /health surfaces as FAIL."""
        import requests

        def _raise(*_a, **_kw):
            raise requests.RequestException("connection refused")

        monkeypatch.setattr(requests, "get", _raise)

        cli.main(
            [
                "init",
                "--no-default-resolvers",
                "--no-probe-local-dns",
                "alice",
                "--endpoint",
                "http://dead.example:8053",
            ]
        )
        rc = cli.main(["doctor"])
        out = capsys.readouterr().out
        assert rc == 1
        assert "FAIL" in out
        assert "endpoint unreachable" in out

    def test_dns_host_pointing_at_public_resolver_warns(
        self, config_home, monkeypatch, capsys
    ):
        """`dns_host=1.1.1.1` without `local_node_dns_*` set MUST warn —
        sending un-TSIG’d UPDATE to a recursive resolver gets
        REFUSED, silently breaking M10 phase-1 same-zone delivery."""
        import requests

        class _OkResponse:
            status_code = 200

        monkeypatch.setattr(requests, "get", lambda *_a, **_kw: _OkResponse())
        from dmp import cli as _cli

        # Auto-probe also fails (so the local-DNS check stays in WARN
        # state, which combines with the dns_host warning).
        monkeypatch.setattr(_cli, "_probe_local_node_dns", lambda *_a, **_kw: None)

        cli.main(
            [
                "init",
                "--no-default-resolvers",
                "--no-probe-local-dns",
                "alice",
                "--endpoint",
                "http://node.example:8053",
                "--dns-host",
                "1.1.1.1",
            ]
        )
        rc = cli.main(["doctor"])
        out = capsys.readouterr().out
        # WARN-only → exit 0.
        assert rc == 0
        assert "WARN" in out
        assert "public recursive" in out

    def test_tsig_unset_warns(self, config_home, monkeypatch, capsys):
        """HTTP-mode without TSIG registered surfaces as WARN, not FAIL —
        local-only flows still work."""
        import requests

        class _OkResponse:
            status_code = 200

        monkeypatch.setattr(requests, "get", lambda *_a, **_kw: _OkResponse())
        from dmp import cli as _cli

        monkeypatch.setattr(_cli, "_probe_local_node_dns", lambda *_a, **_kw: None)

        cli.main(
            [
                "init",
                "--no-default-resolvers",
                "--no-probe-local-dns",
                "alice",
                "--endpoint",
                "http://node.example:8053",
            ]
        )
        rc = cli.main(["doctor"])
        out = capsys.readouterr().out
        assert rc == 0
        assert "TSIG not registered" in out


class TestDoctorRound14:
    """Codex round-14 P1 regression coverage."""

    def test_repair_pins_local_node_dns_without_clobbering_identity(
        self, config_home, monkeypatch, capsys
    ):
        """`dnsmesh doctor --repair` MUST be non-destructive: it
        only updates local_node_dns_*, leaving identity (kdf_salt),
        TSIG block, contacts intact. The previous remediation
        suggested `init --force` which rebuilds CLIConfig from
        scratch and would rotate the user onto new keys."""
        from dmp import cli as _cli

        cli.main(
            [
                "init",
                "--no-default-resolvers",
                "--no-probe-local-dns",
                "alice",
                "--endpoint",
                "http://node.example:8053",
            ]
        )
        cfg = cli.CLIConfig.load(config_home / "config.yaml")
        original_kdf = cfg.kdf_salt
        # Hand-pin TSIG + contacts as if the user had registered
        # and added contacts before the local DNS endpoint moved.
        cfg.tsig_key_name = "alice."
        cfg.tsig_secret_hex = "ee" * 32
        cfg.tsig_zone = "node.example"
        cfg.contacts = {
            "bob": {"pub": "11" * 32, "spk": "22" * 32, "domain": "bob.example"}
        }
        cfg.save(config_home / "config.yaml")

        monkeypatch.setattr(
            _cli,
            "_probe_local_node_dns",
            lambda *_a, **_kw: ("repaired.example", 5353),
        )

        rc = cli.main(["doctor", "--repair"])
        assert rc == 0

        cfg2 = cli.CLIConfig.load(config_home / "config.yaml")
        assert (
            cfg2.kdf_salt == original_kdf
        ), "kdf_salt was rotated — identity destroyed"
        assert cfg2.tsig_key_name == "alice."
        assert cfg2.tsig_secret_hex == "ee" * 32
        assert "bob" in cfg2.contacts
        # Local DNS got pinned.
        assert cfg2.local_node_dns_server == "repaired.example"
        assert cfg2.local_node_dns_port == 5353

    def test_probe_rejects_non_dmp_dns_listener(self, monkeypatch):
        """Codex round-14 P1 + round-15 P1: the probe must reject
        servers that don't return a DMP-specific UPDATE-REFUSED
        signature. NOTIMP (most non-DMP DNS servers' UPDATE response)
        does NOT pass; only REFUSED (5) or NOTAUTH (9) do."""
        import dns.rcode
        from dmp import cli as _cli

        class _StubResp:
            def __init__(self, rcode_value):
                self._rcode = rcode_value

            def rcode(self):
                return self._rcode

        # NOTIMP — typical non-auth DNS server response to UPDATE.
        # Must NOT bless.
        monkeypatch.setattr(
            "dns.query.udp",
            lambda *_a, **_kw: _StubResp(dns.rcode.NOTIMP),
        )
        assert _cli._probe_local_node_dns("http://stranger.example") is None

        # NOERROR — would indicate the server accepted the probe
        # write. A real DMP node REFUSES un-TSIG'd non-claim writes,
        # so NOERROR back is wrong-shape too.
        monkeypatch.setattr(
            "dns.query.udp",
            lambda *_a, **_kw: _StubResp(dns.rcode.NOERROR),
        )
        assert _cli._probe_local_node_dns("http://stranger.example") is None

    def test_probe_accepts_dmp_node_without_heartbeat(self, monkeypatch):
        """Codex round-15 P1 (positive): a default DMP node with
        ``DMP_HEARTBEAT_ENABLED=0`` MUST still be detected. The
        UPDATE-REFUSED signal fires regardless of heartbeat config —
        REFUSED is a load-bearing protocol contract on the un-TSIG'd
        accept path, independent of any operator opt-in."""
        import dns.rcode
        from dmp import cli as _cli

        class _StubResp:
            def __init__(self, rcode_value):
                self._rcode = rcode_value

            def rcode(self):
                return self._rcode

        monkeypatch.setattr(
            "dns.query.udp",
            lambda *_a, **_kw: _StubResp(dns.rcode.REFUSED),
        )
        result = _cli._probe_local_node_dns("http://node.example:8053")
        assert result == ("node.example", 5353)

    def test_probe_accepts_notauth_as_dmp_signature(self, monkeypatch):
        """A DMP server with mismatched ``allowed_zones`` returns
        NOTAUTH (9) — still a DMP-distinctive UPDATE answer
        (recursive resolvers return NOTIMP). MUST be accepted."""
        import dns.rcode
        from dmp import cli as _cli

        class _StubResp:
            def __init__(self, rcode_value):
                self._rcode = rcode_value

            def rcode(self):
                return self._rcode

        monkeypatch.setattr(
            "dns.query.udp",
            lambda *_a, **_kw: _StubResp(dns.rcode.NOTAUTH),
        )
        result = _cli._probe_local_node_dns("http://node.example:8053")
        assert result == ("node.example", 5353)
