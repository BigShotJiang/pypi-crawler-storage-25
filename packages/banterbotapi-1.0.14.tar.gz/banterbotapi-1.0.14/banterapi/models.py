"""Data models for gateway events and REST responses.

Each model is a thin :mod:`dataclasses` wrapper with:

* A :meth:`from_dict` classmethod that parses a raw JSON dict coming
  off the wire. Missing fields default to safe zero values (``""``,
  ``0``, ``False``, ``[]``) — the server contract is that every field
  in a model's annotation MAY be absent from a given payload.
* Optional bound helpers (``Message.reply``, ``Channel.send``) that
  route back through the owning :class:`~banterapi.Bot` for HTTP
  calls. These only work on models the SDK created with a ``client``
  argument set; calling them on a model the user hand-constructed
  raises :class:`RuntimeError`.

Models are intentionally lightweight: no caching, no lazy-loading, no
background refetches. If you need an up-to-date view of a user/guild,
call :meth:`Bot.get_user` / :meth:`Bot.get_guild` again — the returned
model is a fresh snapshot.
"""

import functools
from dataclasses import dataclass, field
from typing import List, Optional


def _requires_client(fn):
    """Decorator that guards instance-method calls against detached models.

    Models built via :meth:`from_dict` without a ``client=`` argument
    have ``self._client is None`` and can't call back into the SDK.
    This shim produces a clear :class:`RuntimeError` instead of the
    ``AttributeError: 'NoneType' object has no attribute …`` that
    would otherwise fire deep in the call chain.
    """
    @functools.wraps(fn)
    async def wrapper(self, *args, **kwargs):
        if self._client is None:
            raise RuntimeError(f"{type(self).__name__} detached from client")
        return await fn(self, *args, **kwargs)
    return wrapper


@dataclass
class User:
    """A user or bot account.

    Attributes:
        id: Opaque user ID (hex snowflake).
        username: The user's unique handle (no spaces).
        display_name: Optional display name shown in the UI; falls
            back to ``username`` on the server side if empty.
        avatar_id: Avatar asset ID. Use with
            ``{base_url}/api/avatars/{avatar_id}`` to fetch the image.
            Empty string if the user has no avatar set.
        bot: ``True`` for bot accounts (those registered via
            ``/api/applications``); ``False`` for human users.
    """

    id: str
    username: str
    display_name: str = ""
    avatar_id: str = ""
    bot: bool = False

    @classmethod
    def from_dict(cls, d):
        """Parse a user payload from REST or gateway.

        Tolerant of both ``avatar``/``avatar_id`` and
        ``is_bot``/``bot`` key spellings so older server builds and
        gateway-shaped vs REST-shaped payloads both parse.
        """
        return cls(
            id=d.get("id", ""),
            username=d.get("username", ""),
            display_name=d.get("display_name", ""),
            avatar_id=d.get("avatar", "") or d.get("avatar_id", ""),
            bot=d.get("is_bot", False) or d.get("bot", False),
        )


@dataclass
class Role:
    """A role within a guild.

    Attributes:
        id: Opaque role ID.
        name: Display name.
        color: Hex colour string (e.g. ``"#5865f2"``), or ``""`` for
            no colour.
        position: Sort position in the role list; higher = higher in
            the hierarchy. Used to determine role-based perm
            overrides.
        permissions: Bitmask of permissions this role grants. See
            :class:`~banterapi.Permissions`.

    The :attr:`_client` field is set by SDK-facing constructors
    (:meth:`Bot.list_roles`, :meth:`Bot.create_role`) to enable
    :meth:`edit` / :meth:`delete`. Excluded from ``repr`` and equality.
    """

    id: str
    name: str
    color: str = ""
    position: int = 0
    permissions: int = 0

    _client: object = field(default=None, repr=False, compare=False)

    @classmethod
    def from_dict(cls, d, client=None):
        """Parse a role payload; ``permissions`` is coerced to ``int``."""
        return cls(
            id=d.get("id", ""),
            name=d.get("name", ""),
            color=d.get("color", ""),
            position=d.get("position", 0),
            permissions=int(d.get("permissions", 0)),
            _client=client,
        )

    @_requires_client
    async def edit(self, **patch):
        """Edit this role. Requires MANAGE_ROLES in the guild.

        Accepts any subset of: ``name``, ``color``, ``description``,
        ``permissions``, ``deny``, ``position``, ``mentionable``.
        Only fields explicitly passed are sent.
        """
        return await self._client._http.edit_role(self.id, **patch)

    @_requires_client
    async def delete(self):
        """Delete this role. Requires MANAGE_ROLES in the guild."""
        return await self._client._http.delete_role(self.id)


@dataclass
class Channel:
    """A channel (text or voice) inside a guild, or a DM thread.

    Attributes:
        id: Opaque channel ID.
        name: Channel name without a leading ``#``. Empty for DMs.
        guild_id: Parent guild ID, or ``""`` for DM channels.
        type: ``"text"`` or ``"voice"``. Defaults to ``"text"`` for
            safety when the server omits the key.
        description: Topic / description. May be empty.

    The ``_client`` field is set by :meth:`Bot.list_channels` and
    similar SDK-facing constructors; it enables :meth:`send` and
    :meth:`trigger_typing`. Excluded from ``repr`` and equality so
    instances printed or compared don't leak unrelated state.
    """

    id: str
    name: str
    guild_id: str = ""
    type: str = "text"
    description: str = ""
    category_id: str = ""
    permission_overrides: list = field(default_factory=list)

    _client: object = field(default=None, repr=False, compare=False)

    @classmethod
    def from_dict(cls, d, client=None):
        """Parse a channel payload, optionally attaching a client.

        ``permission_overrides`` is preserved as a plain list of dicts
        (``[{role_id, allow, deny}, ...]``) — same shape accepted by
        ``bot.create_channel(..., permission_overrides=...)`` so the
        two round-trip symmetrically (useful for clone/nuke flows).
        """
        return cls(
            id=d.get("id", ""),
            name=d.get("name", ""),
            guild_id=d.get("guild_id", ""),
            type=d.get("type", "text"),
            description=d.get("description", ""),
            category_id=d.get("category_id", ""),
            permission_overrides=list(d.get("permission_overrides") or []),
            _client=client,
        )

    @_requires_client
    async def send(self, content="", embed=None, file=None, files=None, components=None):
        """Send a new message in the channel this command was invoked in.

        Unlike :meth:`reply`, does not thread-link back to the invoking
        message. Prefer :meth:`reply` for direct command responses.

        ``file`` / ``files`` accept :class:`~banterapi.File` instances
        and are uploaded before the message is sent. Buttons attached
        to ``embed`` via ``embed.add_button()`` forward automatically
        as components — see :meth:`Bot.send_message`.
        """
        return await self.bot.send_message(self.channel_id, content=content, embed=embed, file=file, files=files, components=components)

    async def reply(self, content="", embed=None, file=None, files=None, components=None):
        """Send a message as a reply to the invoking message.

        Shorthand for ``ctx.message.reply(...)``. The reply-chain link
        is set server-side so clients render the "replying to" header.
        Buttons attached to ``embed`` via ``embed.add_button()`` forward
        automatically as components.
        """
        return await self.message.reply(content=content, embed=embed, file=file, files=files, components=components)
    @_requires_client
    async def trigger_typing(self):
        """Show the typing indicator in this channel for the bot."""
        await self._client._http.trigger_typing(self.id)

    @_requires_client
    async def edit(self, **patch):
        """Edit this channel. Requires MANAGE_CHANNELS in the guild.

        Accepts keyword-only: ``name``, ``description``, ``position``,
        ``category_id``. Only fields passed are sent. Returns the
        server's updated channel representation (a dict) — the local
        model is NOT mutated. Fetch the guild's channel list for a
        fresh :class:`Channel` if you need one.
        """
        return await self._client._http.edit_channel(self.id, **patch)

    @_requires_client
    async def delete(self):
        """Delete this channel. Requires MANAGE_CHANNELS in the guild.

        After a successful call, the local :class:`Channel` instance
        is stale. The channel is also gone from every user's channel
        list via the gateway ``channel_delete`` event.
        """
        return await self._client._http.delete_channel(self.id)

    @_requires_client
    async def purge(self, limit=100):
        """Bulk-delete the most recent ``limit`` messages in this channel.

        Requires MANAGE_MESSAGES. Server caps at 1000. Returns the
        number of messages actually deleted (may be less than
        ``limit`` if the channel is shorter).
        """
        resp = await self._client._http.purge_channel(self.id, limit=limit)
        return (resp or {}).get("deleted", 0)

    @_requires_client
    async def set_permissions(self, role_id, *, allow=0, deny=0):
        """Set a role's permission overrides on this channel.

        Requires MANAGE_CHANNELS. ``allow`` and ``deny`` are bitmasks
        built from :class:`~banterapi.Permissions`. Existing override
        for the same role is replaced.
        """
        return await self._client._http.set_channel_permissions(
            self.id, role_id, allow=allow, deny=deny,
        )

    @_requires_client
    async def members(self, search="", limit=50, offset=0):
        """List one page of users who can view this channel.

        One-shot fetch capped at ``limit`` (server hard cap ~500).
        Ideal for slash-command autocomplete where the server's
        ``search`` filter already narrows the result to the top N
        matches in a single call.

        For iterating ALL members of a large guild, use
        :meth:`iter_members` instead — it pages transparently and
        streams results as they arrive.

        Args:
            search: Case-insensitive substring match against
                username and display_name. Empty returns everyone.
            limit: Maximum rows to return this call.
            offset: Starting row for paging.

        Returns:
            ``list[Member]`` with ``.user`` and ``.roles`` populated.
            Empty list on network / permission failures — safe to
            call from a slash-command handler without try/except.
        """
        try:
            resp = await self._client._http.list_channel_members(
                self.id, limit=limit, offset=offset, search=search
            )
        except Exception:
            return []
        users = (resp or {}).get("users") or []
        return [Member.from_dict(u, guild_id=self.guild_id) for u in users]

    @_requires_client
    async def iter_members(self, search="", page_size=200):
        """Async generator yielding every member across paginated calls.

        Handles offset bookkeeping and stops automatically when the
        server reports no more rows. Safe for guilds of any size —
        uses ``page_size`` (default 200) rows per round-trip, so an
        8,000-member guild is ~40 requests. The bot can break out of
        the loop at any time to avoid fetching pages it doesn't need.

        Usage::

            async for m in channel.iter_members():
                if m.user.username == "alice":
                    ...
                    break

            # Or collect all:
            all_members = [m async for m in channel.iter_members()]

        Args:
            search: Case-insensitive substring match forwarded to the
                server on every page. Empty returns everyone.
            page_size: Rows per request. Clamped to [1, 500] by the
                server regardless of what's passed here.

        Yields:
            :class:`Member` instances one at a time. Swallows page
            errors silently and ends iteration — the partial result
            is whatever pages succeeded before the failure.
        """
        offset = 0
        seen_ids = set()
        while True:
            try:
                resp = await self._client._http.list_channel_members(
                    self.id, limit=page_size, offset=offset, search=search
                )
            except Exception:
                return
            users = (resp or {}).get("users") or []
            if not users:
                return
            for u in users:
                uid = u.get("id", "")
                if uid and uid not in seen_ids:
                    seen_ids.add(uid)
                    yield Member.from_dict(u, guild_id=self.guild_id)
            if len(users) < page_size:
                return
            offset += len(users)


@dataclass
class Member:
    """A :class:`User` plus their per-guild state.

    Attributes:
        user: The underlying :class:`User`.
        guild_id: Guild this membership is for.
        roles: List of role IDs the member holds in this guild. Use
            with :meth:`Bot.get_guild` → roles list to resolve names /
            permissions.
    """

    user: User
    guild_id: str
    roles: List[str] = field(default_factory=list)

    @classmethod
    def from_dict(cls, d, guild_id=""):
        """Parse a member payload.

        The payload is flat — user fields live at the top level
        alongside ``roles`` — so the user portion is parsed via
        :meth:`User.from_dict` on the same dict.
        """
        return cls(
            user=User.from_dict(d),
            guild_id=guild_id or d.get("guild_id", ""),
            roles=d.get("roles", []) or [],
        )


@dataclass
@dataclass
class Category:
    """A category (channel group) inside a guild.

    Attributes:
        id: Opaque category ID.
        name: Display name.
        guild_id: Parent guild ID.
        position: Sort order within the guild's category list. Lower
            values appear higher in the sidebar.
    """

    id: str
    name: str
    guild_id: str = ""
    position: int = 0

    _client: object = field(default=None, repr=False, compare=False)

    @classmethod
    def from_dict(cls, d, client=None):
        return cls(
            id=d.get("id", ""),
            name=d.get("name", ""),
            guild_id=d.get("guild_id", ""),
            position=d.get("position", 0),
            _client=client,
        )

    @_requires_client
    async def edit(self, **patch):
        """Edit this category. Accepts keyword-only ``name`` / ``position``.

        Only fields passed are sent. Requires MANAGE_CHANNELS.
        """
        return await self._client._http.edit_category(self.id, **patch)

    @_requires_client
    async def delete(self):
        """Delete this category. Requires MANAGE_CHANNELS.

        Child channels become uncategorized (not deleted).
        """
        return await self._client._http.delete_category(self.id)

    @_requires_client
    async def set_permissions(self, role_id, *, allow=0, deny=0):
        """Set a role's permission overrides on this category."""
        return await self._client._http.set_category_permissions(
            self.id, role_id, allow=allow, deny=deny,
        )


@dataclass
class Guild:
    """A guild (server) the bot is a member of.

    Attributes:
        id: Opaque guild ID.
        name: Display name.
        owner_id: User ID of the guild's owner.
        icon: Icon asset ID; empty when the guild has no icon.
        description: Server description shown in discovery / invite
            landing pages.
        member_count: Cached member count from the server. May drift
            from reality between full resyncs — treat as informational.
    """

    id: str
    name: str
    owner_id: str = ""
    icon: str = ""
    description: str = ""
    member_count: int = 0

    @classmethod
    def from_dict(cls, d):
        """Parse a guild payload. Missing fields default to zero values."""
        return cls(
            id=d.get("id", ""),
            name=d.get("name", ""),
            owner_id=d.get("owner_id", ""),
            icon=d.get("icon", ""),
            description=d.get("description", ""),
            member_count=d.get("member_count", 0),
        )


@dataclass
class Message:
    """A message event dispatched via ``on_message`` or returned by send.

    Attributes:
        id: Message ID.
        channel_id: ID of the channel it was sent in.
        user_id: Author's user ID. Same as ``author.id`` when
            :attr:`author` is populated.
        content: Message body as typed. Mentions are encoded as
            ``<@user_id>`` / ``<#channel_id>`` tokens server-side.
        author: Populated :class:`User` of the author, or ``None`` if
            the gateway payload omitted author fields (the SDK only
            fills it when ``username`` is present on the dict).
        guild_id: Guild the message was posted in, or ``""`` for DMs.
        type: ``"message"`` for normal messages; other values are
            reserved for system messages.
        reply_to: Message ID this one replies to, or ``""`` for
            non-reply messages.
        edited: ``True`` if the message has been edited since creation.
        created_at: ISO-8601 timestamp string. Not parsed into a
            :class:`~datetime.datetime` — do that yourself if needed.
        author_perms: Pre-resolved effective permission bitmask for the
            author in this channel. Used by command perm checks
            without a round-trip.

    The :attr:`channel` property returns a lightweight :class:`Channel`
    stub for sending replies. Its ``.name`` is NOT populated — fetch
    via ``bot.list_channels(guild_id)`` when you need the name.
    """

    id: str
    channel_id: str
    user_id: str
    content: str
    author: Optional[User] = None
    guild_id: str = ""
    type: str = "message"
    reply_to: str = ""
    edited: bool = False
    created_at: str = ""
    author_perms: int = 0

    _client: object = field(default=None, repr=False, compare=False)
    # Lazy Channel stub cached on first access; see :attr:`channel`.
    # init=False keeps this out of __init__'s signature.
    _channel_stub: object = field(default=None, init=False, repr=False, compare=False)

    @classmethod
    def from_dict(cls, d, client=None):
        """Parse a message payload, optionally binding a client.

        ``author`` is set iff the payload carries user fields at the
        top level (gateway ``channel_message`` frames do; some REST
        replies don't). Bind the client to enable :meth:`reply`,
        :meth:`edit`, :meth:`delete`, and :meth:`add_reaction`.
        """
        return cls(
            id=d.get("id", ""),
            channel_id=d.get("channel_id", ""),
            user_id=d.get("user_id", ""),
            content=d.get("content", ""),
            author=User.from_dict(d) if d.get("username") else None,
            guild_id=d.get("guild_id", ""),
            type=d.get("type", "message"),
            reply_to=d.get("reply_to", ""),
            edited=d.get("edited", False),
            created_at=d.get("created_at", ""),
            author_perms=int(d.get("author_perms", 0)),
            _client=client,
        )

    @property
    def channel(self):
        """A :class:`Channel` stub for sending in this message's channel.

        Cached on first access so repeated ``msg.channel`` calls return
        the same object (important for identity comparisons).

        The stub's ``.name`` is empty — the gateway message payload
        does not carry channel names, and making this property do a
        REST call would be a surprising hidden await. If you need the
        channel name, fetch the full channel list via
        ``await bot.list_channels(msg.guild_id)``.

        Raises:
            RuntimeError: The message was built without a client
                (i.e. from a raw dict by user code).
        """
        if self._client is None:
            raise RuntimeError("Message detached from client")
        if self._channel_stub is None:
            self._channel_stub = Channel(
                id=self.channel_id,
                name="",
                guild_id=self.guild_id,
                _client=self._client,
            )
        return self._channel_stub

    @_requires_client
    async def reply(self, content="", embed=None, file=None, files=None, components=None):
        """Send a message that threads as a reply to this one.

        Wraps :meth:`Bot.send_message` with ``reply_to=self.id`` set.
        Buttons attached to ``embed`` via ``embed.add_button()`` forward
        automatically (see :meth:`Bot.send_message`).
        """
        return await self._client.send_message(self.channel_id, content=content, embed=embed, reply_to=self.id, file=file, files=files, components=components)

    @_requires_client
    async def edit(self, content):
        """Edit this message's content. The bot must be the author."""
        return await self._client._http.edit_message(self.id, content)

    @_requires_client
    async def delete(self):
        """Delete this message.

        The bot must be the author OR hold
        :data:`Permissions.MANAGE_MESSAGES` in the channel.
        """
        return await self._client._http.delete_message(self.id)

    @_requires_client
    async def add_reaction(self, emoji):
        """Add an emoji reaction to this message from the bot.

        Args:
            emoji: Unicode emoji (``"👍"``) or server-resolvable token.
        """
        return await self._client._http.add_reaction(self.channel_id, self.id, emoji)