"""banterapi — Python SDK for BanterChat bots.

Quickstart:

    import banterapi

    bot = banterapi.Bot(
        intents=banterapi.Intents.default() | banterapi.Intents.MESSAGE_CONTENT,
        command_prefix="!",
    )

    @bot.event
    async def on_ready():
        print(f"logged in as {bot.user.username}")

    @bot.command(slash=True, description="Ping the bot")
    async def ping(ctx):
        await ctx.reply("pong")

    bot.run("YOUR_BOT_TOKEN")

The library mirrors discord.py conventions where possible. See the Bot,
Intents, Embed, and Permissions classes for the main entry points.
"""

__version__ = "1.0.14"

from .client import Bot
from .intents import Intents
from .embed import Embed
from .files import File
from .models import User, Guild, Channel, Category, Member, Role, Message
from .errors import BanterError, HTTPException, Forbidden, NotFound, RateLimited, GatewayError, LoginFailure, MissingPermissions
from .permissions import Permissions
from .commands import (
    has_permissions,
    SlashOption,
    Optional,
    OPTION_STRING, OPTION_INTEGER, OPTION_BOOLEAN,
    OPTION_USER, OPTION_CHANNEL, OPTION_ROLE,
)
from .interactions import Interaction

__all__ = [
    "__version__",
    "Bot",
    "Intents",
    "Embed",
    "File",
    "User",
    "Guild",
    "Channel",
    "Category",
    "Member",
    "Role",
    "Message",
    "Permissions",
    "has_permissions",
    # Slash command support
    "SlashOption",
    "Optional",
    "OPTION_STRING", "OPTION_INTEGER", "OPTION_BOOLEAN",
    "OPTION_USER", "OPTION_CHANNEL", "OPTION_ROLE",
    "Interaction",
    # Errors
    "BanterError",
    "HTTPException",
    "Forbidden",
    "NotFound",
    "RateLimited",
    "GatewayError",
    "LoginFailure",
    "MissingPermissions",
]