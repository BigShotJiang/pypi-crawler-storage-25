"""File attachments.

Mirrors discord.py's :class:`discord.File` — accepts a path, a
file-like object, or raw bytes, and carries the filename the server
should see. Uploaded via two-phase send: each ``File`` is POSTed to
``/api/v1/bot/attachments`` first, and the returned attachment IDs
are included in the message payload. Bot authors never see this; they
just pass ``file=`` or ``files=`` to any send method.
"""

import os


class File:
    """Represents a file to attach to a bot message.

    Args:
        fp: One of:

            * ``str``: filesystem path (opened for reading in binary mode)
            * ``bytes`` / ``bytearray``: raw bytes
            * file-like: anything with a ``.read()`` returning bytes

        filename: Name the server / clients should display. Required
            when ``fp`` is bytes or a file-like without a ``.name``
            attribute. When ``fp`` is a path the basename is used if
            ``filename`` is omitted.

    Example:
        >>> File("photo.png")
        >>> File(open("data.bin", "rb"))
        >>> File(b"hello", filename="hello.txt")
    """

    __slots__ = ("fp", "filename", "_owns_fp")

    def __init__(self, fp, filename=None):
        self._owns_fp = False
        if isinstance(fp, (bytes, bytearray)):
            self.fp = bytes(fp)
            if not filename:
                raise ValueError("File(bytes, ...) requires filename=")
            self.filename = filename
        elif isinstance(fp, str):
            if not filename:
                filename = os.path.basename(fp)
            with open(fp, "rb") as f:
                self.fp = f.read()
            self.filename = filename
        else:
            data = fp.read()
            if not isinstance(data, (bytes, bytearray)):
                raise TypeError("file-like must return bytes from .read()")
            self.fp = bytes(data)
            if not filename:
                filename = getattr(fp, "name", None)
                if filename:
                    filename = os.path.basename(filename)
            if not filename:
                raise ValueError("File(file-like, ...) requires filename= or fp.name")
            self.filename = filename

    def __repr__(self):
        return f"File({self.filename!r}, {len(self.fp)} bytes)"