"""WebSocket gateway client.

The Banter gateway is a JSON WebSocket that mirrors Discord's gateway
opcodes at the wire level (``op``/``d``/``s``/``t`` frame shape). This
module hides the protocol mechanics behind a simple contract:

1. :meth:`Gateway.connect` opens the socket and authenticates via the
   ``Authorization: Bot <token>`` header.
2. The server sends HELLO (op 10) with a heartbeat interval. The client
   starts a heartbeat coroutine that sends HEARTBEAT (op 1) on that
   cadence; the server replies HEARTBEAT_ACK (op 11).
3. DISPATCH (op 0) frames carry events (``t`` = event name, ``d`` =
   payload). They're forwarded verbatim to the supplied ``dispatcher``
   callable — the :class:`~banterapi.Bot` installs
   :meth:`Bot._dispatch` as that callable.
4. If a heartbeat ack is missed, the client closes the socket with
   code 4000 ("missed heartbeat ack"); :class:`~banterapi.Bot`
   reconnects when ``reconnect=True``.

This module does **not** own reconnect / resume logic — that lives on
:class:`~banterapi.Bot`. A :class:`Gateway` instance is single-use;
reconnect creates a new one.
"""

import asyncio
import json
import logging

import websockets

from .errors import GatewayError, LoginFailure


log = logging.getLogger("banterapi.gateway")


# Opcodes — MUST stay in sync with server/modules/websocket/gateway.go.
OP_DISPATCH = 0      # server → client: a named event (t = event name, d = payload)
OP_HEARTBEAT = 1     # client → server: liveness ping (unsolicited, on interval)
OP_HELLO = 10        # server → client: sent once on connect; carries heartbeat_interval_ms
OP_HEARTBEAT_ACK = 11  # server → client: reply to an OP_HEARTBEAT


def _headers_kwarg():
    """Return the correct kwarg name for custom headers on ``websockets.connect``.

    websockets >=13 renamed ``extra_headers`` → ``additional_headers``.
    We detect at import/call time which name the installed version
    accepts so the SDK works across both. Falls back to the newer name
    when signature inspection fails (which is the right choice on
    bleeding-edge versions where the check itself might error).
    """
    try:
        from inspect import signature
        params = signature(websockets.connect).parameters
    except Exception:
        return "additional_headers"
    if "additional_headers" in params:
        return "additional_headers"
    if "extra_headers" in params:
        return "extra_headers"
    return "additional_headers"


class Gateway:
    """Low-level WebSocket gateway client.

    One instance == one socket lifetime. Reconnect by constructing a
    new :class:`Gateway`. :class:`~banterapi.Bot` handles that loop.

    Args:
        token: Bot token. Sent in the ``Authorization: Bot <token>``
            header on connect.
        intents: Integer bitmask (see :class:`~banterapi.Intents`).
            Appended as the ``?intents=`` query param; the server
            filters events accordingly.
        ws_url: Full gateway URL including ``wss://`` scheme and path
            (e.g. ``wss://banterchat.org/api/v1/bot/gateway``).
        dispatcher: Async callable invoked as
            ``await dispatcher(event_type, payload_dict)`` for each
            DISPATCH frame, plus synthetic events for non-opcode
            (legacy-shape) frames.
    """

    def __init__(self, token, intents, ws_url, dispatcher):
        self.token = token
        self.intents = int(intents)
        self.ws_url = ws_url
        self.dispatcher = dispatcher
        self._ws = None
        self._closed = False
        self._heartbeat_task = None
        self._heartbeat_interval = None
        self._last_ack = True
        self.close_code = None
        self.close_reason = ""

    async def connect(self):
        url = f"{self.ws_url}?intents={self.intents}"
        kwargs = {
            _headers_kwarg(): {
                "Authorization": f"Bot {self.token}",
                "User-Agent": "BanterPy/0.1",
            },
            "ping_interval": 20,
            "ping_timeout": 20,
        }
        try:
            self._ws = await websockets.connect(url, **kwargs)
        except Exception as e:
            name = type(e).__name__
            if name in ("InvalidStatus", "InvalidStatusCode"):
                status = 0
                resp = getattr(e, "response", None)
                if resp is not None:
                    status = getattr(resp, "status_code", 0)
                if status == 0:
                    status = getattr(e, "status_code", 0)
                if status == 401:
                    raise LoginFailure("invalid bot token")
                raise GatewayError(f"connect failed: HTTP {status}")
            raise GatewayError(f"connect failed: {e}")

    async def _heartbeat_loop(self):
        """Send OP_HEARTBEAT every ``heartbeat_interval`` ms; bail on missed ack.

        A missed ack means the server-to-client channel is stalled — we
        close with code 4000 so the :class:`Bot` reconnect loop takes
        over. We swallow :class:`asyncio.CancelledError` because it's
        the normal shutdown signal (:meth:`close` cancels the task),
        and log any other exception so the operator sees why heartbeats
        stopped.
        """
        try:
            while not self._closed:
                await asyncio.sleep(self._heartbeat_interval / 1000)
                if not self._last_ack:
                    try:
                        await self._ws.close(code=4000, reason="missed heartbeat ack")
                    except Exception:  # already-closed/broken socket: nothing to do
                        log.debug("heartbeat: socket already gone on close-after-miss")
                    return
                self._last_ack = False
                try:
                    await self._ws.send(json.dumps({"op": OP_HEARTBEAT, "d": None}))
                except Exception as e:
                    # Send failed — socket is dead. Let the reconnect
                    # loop notice by way of ReadPump finishing.
                    log.warning("heartbeat send failed: %s", e)
                    return
        except asyncio.CancelledError:
            return

    async def run(self):
        if self._ws is None:
            raise GatewayError("not connected")
        try:
            async for raw in self._ws:
                if self._closed:
                    return
                try:
                    msg = json.loads(raw)
                except json.JSONDecodeError as e:
                    log.warning("gateway: dropping non-JSON frame: %s", e)
                    continue

                if isinstance(msg, dict) and "op" in msg:
                    op = msg.get("op")
                    if op == OP_HELLO:
                        d = msg.get("d") or {}
                        self._heartbeat_interval = int(d.get("heartbeat_interval", 41250))
                        self._last_ack = True
                        if self._heartbeat_task is None or self._heartbeat_task.done():
                            self._heartbeat_task = asyncio.create_task(self._heartbeat_loop())
                        continue
                    if op == OP_HEARTBEAT_ACK:
                        self._last_ack = True
                        continue
                    if op == OP_DISPATCH:
                        event_type = msg.get("t") or ""
                        payload = msg.get("d") or {}
                        await self.dispatcher(event_type, payload)
                        continue
                    log.debug("gateway: unknown opcode %r — ignored", op)
                    continue

                event_type = msg.get("type", "")
                payload = msg.get("payload", {})
                await self.dispatcher(event_type, payload)
        except websockets.exceptions.ConnectionClosed as e:
            self.close_code = getattr(e, "code", None)
            self.close_reason = getattr(e, "reason", "") or ""
            return
        except Exception as e:
            raise GatewayError(f"gateway read loop failed: {e}") from e

    async def close(self):
        """Close the socket and cancel the heartbeat task.

        Idempotent — safe to call multiple times or before
        :meth:`connect`. Never raises; teardown-during-teardown errors
        are logged at debug level and swallowed. The caller
        (typically :meth:`Bot._start`) uses this in a ``finally``.
        """
        self._closed = True
        if self._heartbeat_task is not None and not self._heartbeat_task.done():
            self._heartbeat_task.cancel()
        if self._ws is None:
            return
        # Older websockets expose .closed as a bool; newer versions use
        # a State enum and may not have the attribute at all. Treat
        # missing-attribute as "don't know, try closing anyway" — the
        # inner close() is already guarded.
        closed = False
        state = getattr(self._ws, "closed", None)
        if state is not None:
            closed = bool(state)
        if not closed:
            try:
                await self._ws.close()
            except Exception as e:
                log.debug("gateway close ignored teardown error: %s", e)