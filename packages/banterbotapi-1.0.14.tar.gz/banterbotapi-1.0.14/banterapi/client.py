"""High-level bot client — the main entry point of the SDK.

:class:`Bot` wires everything together:

* :class:`~banterapi.http.HTTPClient` for REST calls.
* :class:`~banterapi.gateway.Gateway` for the WebSocket connection.
* :class:`~banterapi.commands.CommandRegistry` for prefix/slash commands.
* An event-handler map (``on_ready``, ``on_message``, ...) populated
  via the :meth:`Bot.event` decorator.

Typical usage::

    bot = Bot(intents=Intents.default() | Intents.MESSAGE_CONTENT)

    @bot.event
    async def on_ready():
        print("logged in")

    @bot.command(slash=True, description="Say pong")
    async def ping(ctx):
        await ctx.reply("pong")

    bot.run(TOKEN)

:meth:`Bot.run` blocks until the bot disconnects (or ``KeyboardInterrupt``).
It manages the reconnect loop internally when ``reconnect=True``.
"""

import asyncio
import inspect
import logging

from .commands import Command, CommandRegistry, Context, CommandError, CommandNotFound
from .gateway import Gateway
from .http import HTTPClient
from .intents import Intents
from .models import User, Guild, Channel, Member, Message
from .errors import GatewayError, LoginFailure

log = logging.getLogger("banterapi.client")


# Default REST/gateway URL fragments. Kept as module constants so that
# the URL derivation in __init__ is easy to trace and future API
# version bumps only touch these lines.
_DEFAULT_BASE_URL = "https://banterchat.org"
_GATEWAY_PATH = "/api/v1/bot/gateway"


class Bot:
    """Main bot entry point.

    Args:
        intents: :class:`~banterapi.Intents` bitmask controlling which
            gateway events the server will send. Defaults to
            :meth:`Intents.default`. If you register a prefix command
            you almost certainly need
            ``Intents.default() | Intents.MESSAGE_CONTENT``.
        base_url: HTTP origin (scheme + host) of the Banter instance.
            Defaults to ``https://banterchat.org``. Trailing slash is
            stripped.
        ws_url: Override for the gateway URL. If ``None`` (default), the
            SDK derives it from ``base_url`` by switching the scheme
            (``http`` → ``ws``, ``https`` → ``wss``) and appending the
            gateway path. Set this only for local/testing setups where
            REST and gateway live on different hosts.
        reconnect: If ``True`` (default), :meth:`run` sleeps 5s and
            reconnects on any transient gateway error. Set ``False``
            to have :meth:`run` return on the first disconnect.
        command_prefix: Prefix for text commands (``!`` by default).
            Messages beginning with this prefix are parsed and routed
            to registered commands.
        application_id: Your bot application's ID, used for slash
            command registration. If empty, the SDK reads it off the
            READY frame the gateway sends on connect — you usually
            don't need to pass this explicitly.
        help_enabled: Register a default ``help`` command that lists
            registered commands in an embed. ``True`` by default.
            Disable only if you're providing a custom help command of
            your own; most users should leave this on.
        help_color: RGB int (``0xRRGGBB``) used as the embed accent for
            the default help command. Only applies when
            ``help_enabled=True``.
    """

    def __init__(
        self,
        intents=None,
        *,
        base_url=_DEFAULT_BASE_URL,
        ws_url=None,
        reconnect=True,
        command_prefix="!",
        application_id="",
        help_enabled=True,
        help_color=0x5865f2,
    ):
        self.intents = intents if intents is not None else Intents.default()
        self.base_url = base_url.rstrip("/")
        # Derive gateway URL from base_url unless explicitly overridden.
        # http: → ws:, https: → wss:. The path segment lives as a module
        # constant so /api/v1/bot/* migration is a single-line edit.
        self.ws_url = ws_url or (
            self.base_url
            .replace("http://", "ws://")
            .replace("https://", "wss://")
            + _GATEWAY_PATH
        )
        self.reconnect = reconnect
        self.command_prefix = command_prefix
        self.application_id = application_id
        self.help_enabled = help_enabled
        self.help_color = help_color
        self.user = None
        self.guilds = {}
        self._http = None
        self._gateway = None
        self._handlers = {}
        self._commands = CommandRegistry()
        # _slash_commands stores registration metadata sent to the server
        # at sync_commands() time: [{name, description, options}, ...].
        # _slash_handlers maps command-name → coroutine invoked when the
        # gateway delivers an interaction_create event for that command.
        # Separate from _commands because slash handlers take an
        # Interaction, not a (Context, *args) like prefix handlers.
        self._slash_commands = []
        self._slash_handlers = {}
        self._button_handlers_exact = {}
        self._button_handlers_prefix = []
        self._loop = None
        self.session_id = ""
        if self.help_enabled:
            self._register_default_help()

    def event(self, fn):
        """Register ``fn`` as an event handler.

        The handler's name must begin with ``on_`` and is looked up
        against event types the gateway dispatches (``on_ready``,
        ``on_message``, ``on_reaction_add``, ``on_member_join``, …). One
        handler per event name — re-decorating with the same name
        overwrites the previous handler.

        Handlers may be sync or async. Exceptions raised inside a
        handler are logged and swallowed so one bad handler can't take
        the bot down.

        Usage::

            @bot.event
            async def on_ready():
                print("ready")

        Raises:
            ValueError: Handler name does not start with ``on_``.
        """
        name = fn.__name__
        if not name.startswith("on_"):
            raise ValueError("event handlers must be named on_<event>")
        self._handlers[name] = fn
        return fn

    def command(self, name=None, aliases=None, help=None, category=None):
        """Register a prefix command.

        The handler runs when a user types ``<prefix><n> ...`` in a
        channel the bot can see. Function signature drives arg parsing:
        ``int`` / ``float`` / ``bool`` annotations convert tokens,
        ``*args`` collects the rest, ``*, text: str`` consumes the
        remainder verbatim.

        Args:
            name: Command name as typed (without prefix). Defaults to
                the function name.
            aliases: Iterable of alternate names.
            help: Short help text for the default help embed. Defaults
                to the first line of the function's docstring.
            category: Optional group label used by the default ``!help``
                embed. Commands with the same category render together.
                ``None`` bucketizes to "Other".

        For slash commands (typed options + UI autocomplete), use
        :meth:`slash_command` — prefix and slash are separate paths.
        """
        def decorator(fn):
            cmd = Command(fn, name=name, aliases=aliases, help=help, category=category)
            self._commands.add(cmd)
            return fn
        return decorator

    def slash_command(self, name=None, description="", options=None, category=None):
        """Register a standalone slash command (no prefix twin).

        The decorated function takes a single argument — an
        :class:`~banterapi.interactions.Interaction` — and responds
        via ``await interaction.respond(...)``. This differs from
        :meth:`command` (prefix commands) which takes a
        :class:`~banterapi.commands.Context` and parses args from
        message text.

        Use this when the command has structured typed args and makes
        no sense as a plain-text prefix command, or when you want the
        command only accessible through the UI autocomplete.

        Args:
            name: Slash command name. Defaults to the function name.
            description: Shown in the autocomplete dropdown.
            options: Iterable of :class:`~banterapi.SlashOption`.

        Usage::

            from banterapi import SlashOption, OPTION_STRING, OPTION_INTEGER

            @bot.slash_command(
                name="greet",
                description="Greet a user with a custom message",
                options=[
                    SlashOption("name", type=OPTION_STRING),
                    SlashOption("times", type=OPTION_INTEGER, required=False),
                ],
            )
            async def greet(interaction):
                n = interaction.options["name"]
                k = interaction.options.get("times", 1)
                await interaction.respond(f"Hello {n}! " * k)
        """
        def decorator(fn):
            cmd_name = name or fn.__name__
            entry = {
                "name": cmd_name,
                "description": description or cmd_name,
            }
            if options:
                from .commands import SlashOption as _SO
                entry["options"] = [
                    (o.to_dict() if isinstance(o, _SO) else dict(o))
                    for o in options
                ]
            if category is not None:
                entry["_category"] = category
            self._slash_commands.append(entry)
            self._slash_handlers[cmd_name] = fn
            return fn
        return decorator

    def on_button(self, custom_id):
        """Register a handler for button clicks.

        The ``custom_id`` argument can be either:

        * An exact string (``"page_next"``) — fires only when a button
          with that exact id is clicked.
        * A prefix ending in ``*`` (``"page_*"``) — fires for any
          custom_id starting with the prefix, with the remainder
          accessible via ``interaction.custom_id``.

        Handlers receive an :class:`~banterapi.Interaction` with
        ``type == "button"``. Call :meth:`Interaction.update` to edit
        the source message, :meth:`Interaction.respond` to post a new
        message, or :meth:`Interaction.defer` to ack without a reply.

        Usage::

            @bot.on_button("page_*")
            async def page(interaction):
                n = int(interaction.custom_id.removeprefix("page_"))
                await interaction.update(embed=build_page_embed(n))

        Raises:
            ValueError: If ``custom_id`` is empty.
        """
        if not custom_id:
            raise ValueError("custom_id must be a non-empty string")
        def decorator(fn):
            if custom_id.endswith("*"):
                self._button_handlers_prefix.append((custom_id[:-1], fn))
            else:
                self._button_handlers_exact[custom_id] = fn
            return fn
        return decorator

    def _pick_button_handler(self, custom_id):
        """Resolve the handler for a clicked button's custom_id.

        Exact matches take priority over prefix matches. If multiple
        prefix rules could match, the first one registered wins — same
        rule as mounting multiple routers on one path in a web framework.
        """
        if not custom_id:
            return None
        exact = self._button_handlers_exact.get(custom_id)
        if exact is not None:
            return exact
        for prefix, fn in self._button_handlers_prefix:
            if custom_id.startswith(prefix):
                return fn
        return None

    def _register_default_help(self):
        from . import helpcommand
        helpcommand.register(self)

    async def sync_commands(self):
        """Push the bot's slash-command definitions to the server.

        Called automatically on ``on_ready`` when any commands are
        registered with ``slash=True``. Safe to call manually too — it
        replaces the server's stored command list for this bot, so
        calling it a second time with a shorter list deletes any
        commands no longer present.

        The target application is resolved server-side from the bot
        token (``PUT /api/v1/bot/applications/@me/commands``) — the
        ``application_id`` attribute on :class:`Bot` is populated by
        the READY frame for reference but isn't used in this call.

        Returns:
            int: Number of commands the server acknowledged. Zero if
            no slash commands are registered locally.
        """
        if not self._slash_commands:
            return 0
        wire = [{k: v for k, v in entry.items() if not k.startswith("_")} for entry in self._slash_commands]
        result = await self._http.register_commands(wire)
        return result.get("registered", len(self._slash_commands)) if result else 0

    @property
    def commands(self):
        return self._commands.all()

    async def process_commands(self, message):
        if self.user is not None and message.user_id == self.user.id:
            return
        content = message.content or ""
        if not content.startswith(self.command_prefix):
            return
        stripped = content[len(self.command_prefix):]
        if not stripped:
            return
        parts = stripped.split(maxsplit=1)
        name = parts[0]
        args_raw = parts[1] if len(parts) > 1 else ""
        cmd = self._commands.get(name)
        if cmd is None:
            return
        ctx = Context(self, message, name, args_raw)
        try:
            await cmd.invoke(ctx)
        except CommandError as e:
            await self._fire("on_command_error", ctx, e)
        except Exception as e:
            await self._fire("on_command_error", ctx, e)

    async def _dispatch(self, event_type, payload):
        if event_type == "ready":
            user_data = payload.get("user", {})
            self.user = User.from_dict(user_data)
            for g in payload.get("guilds", []) or []:
                guild = Guild.from_dict(g)
                self.guilds[guild.id] = guild
            app_id_from_ready = payload.get("application_id", "")
            if app_id_from_ready and not self.application_id:
                self.application_id = app_id_from_ready
            self.session_id = payload.get("session_id", "")
            print(f"[banterapi] gateway connected | session_id={self.session_id} | user={self.user.username} ({self.user.id})")
            if self._slash_commands:
                try:
                    await self.sync_commands()
                except Exception as e:
                    log.warning("command sync failed: %s", e)
            await self._fire("on_ready")
            return

        if event_type in ("channel_message", "message_create"):
            msg = Message.from_dict(payload, client=self)
            await self._fire("on_message", msg)
            await self.process_commands(msg)
            return

        if event_type == "message_edit":
            await self._fire("on_message_edit", payload)
            return

        if event_type == "message_delete":
            await self._fire("on_message_delete", payload)
            return

        if event_type == "reaction_add":
            await self._fire("on_reaction_add", payload)
            return

        if event_type == "reaction_remove":
            await self._fire("on_reaction_remove", payload)
            return

        if event_type == "guild_member_add":
            await self._fire("on_member_join", payload)
            return

        if event_type == "guild_member_remove":
            await self._fire("on_member_remove", payload)
            return

        if event_type == "error":
            await self._fire("on_error", payload)
            return

        if event_type == "interaction_create":
            from .interactions import Interaction
            interaction = Interaction(payload, client=self)
            if interaction.is_button:
                handler = self._pick_button_handler(interaction.custom_id)
                if handler is not None:
                    try:
                        result = handler(interaction)
                        if inspect.isawaitable(result):
                            await result
                    except Exception:
                        log.exception("button handler for %r raised", interaction.custom_id)
                else:
                    log.warning("received button click for unhandled custom_id %r", interaction.custom_id)
            else:
                handler = self._slash_handlers.get(interaction.command_name)
                if handler is not None:
                    try:
                        result = handler(interaction)
                        if inspect.isawaitable(result):
                            await result
                    except Exception:
                        log.exception("slash handler %r raised", interaction.command_name)
                else:
                    log.warning(
                        "received interaction for unknown slash command %r",
                        interaction.command_name,
                    )
            await self._fire("on_interaction", interaction)
            return

        await self._fire("on_raw_event", event_type, payload)

    async def _fire(self, name, *args):
        handler = self._handlers.get(name)
        if handler is None:
            return
        try:
            result = handler(*args)
            if inspect.isawaitable(result):
                await result
        except Exception:
            log.exception("handler %s raised", name)

    async def send_message(self, channel_id, content="", embed=None, reply_to="", file=None, files=None, components=None):
        """Send a message.

        Buttons attached to ``embed`` via ``embed.add_button()`` are
        automatically forwarded as top-level components. If the caller
        ALSO passes ``components=[...]`` explicitly, the explicit
        argument wins — we don't merge both sources because that would
        silently exceed the 5-row cap in hard-to-debug ways.
        """
        attachment_ids = []
        if file is not None and files:
            raise ValueError("pass either file= or files=, not both")
        uploads = [file] if file is not None else (list(files) if files else [])
        for f in uploads:
            res = await self._http.upload_attachment(channel_id, f)
            if res and res.get("id"):
                attachment_ids.append(res["id"])
        wire_components = components
        if wire_components is None and embed is not None and hasattr(embed, "pending_components"):
            pending = embed.pending_components()
            if pending:
                wire_components = pending
        d = await self._http.send_message(
            channel_id,
            content=content,
            embed=embed,
            reply_to=reply_to,
            attachment_ids=attachment_ids or None,
            components=wire_components,
        )
        return Message.from_dict(d, client=self) if d else None

    async def get_user(self, user_id):
        d = await self._http.get_user(user_id)
        return User.from_dict(d) if d else None

    async def get_guild(self, guild_id):
        """Fetch a guild by ID. Returns a :class:`Guild` or ``None``."""
        d = await self._http.get_guild(guild_id)
        return Guild.from_dict(d) if d else None

    async def edit_guild(self, guild_id, *, name=None, description=None, welcome_channel_id=None):
        """Edit guild name, description (bio), or welcome channel.

        Requires MANAGE_GUILD in the guild. Server enforces this via
        the bot's actual roles — SDK-side perm claims are ignored.
        Bots can't create or delete guilds; only edits are permitted.
        """
        d = await self._http.edit_guild(
            guild_id,
            name=name,
            description=description,
            welcome_channel_id=welcome_channel_id,
        )
        return Guild.from_dict(d) if d else None

    async def get_member(self, guild_id, user_id):
        """Fetch a guild member by user ID. Returns :class:`Member` or ``None``."""
        d = await self._http.get_member(guild_id, user_id)
        return Member.from_dict(d, guild_id=guild_id) if d else None

    async def list_channels(self, guild_id):
        """List channels in a guild the bot can see. Returns [Channel, ...]."""
        d = await self._http.list_channels(guild_id)
        return [Channel.from_dict(c, client=self) for c in (d or [])]

    async def get_channel(self, channel_id):
        """Fetch a single channel by ID. Returns :class:`Channel` or ``None``.

        Use this when you have only a channel_id (e.g. from a message
        event) and want the full Channel record with its name and
        description, not just the stub from ``msg.channel``.
        """
        d = await self._http.get_channel(channel_id)
        return Channel.from_dict(d, client=self) if d else None

    async def list_roles(self, guild_id):
        """List roles in a guild. Returns [Role, ...]."""
        from .models import Role
        d = await self._http.list_roles(guild_id)
        return [Role.from_dict(r, client=self) for r in (d or [])]

    async def create_channel(self, guild_id, name, **kwargs):
        """Create a channel. Requires MANAGE_CHANNELS in the guild.

        Keyword args are forwarded to
        :meth:`HTTPClient.create_channel` (``description``,
        ``category_id``, ``type``). Returns the created
        :class:`Channel` or ``None``.
        """
        d = await self._http.create_channel(guild_id, name, **kwargs)
        return Channel.from_dict(d, client=self) if d else None

    async def edit_channel(self, channel_id, **patch):
        """Partial channel update. Accepts ``name``, ``description``,
        ``position``, ``category_id``. Returns the server's response
        (dict) — pass to :class:`Channel.from_dict` if you need a model.
        """
        return await self._http.edit_channel(channel_id, **patch)

    async def delete_channel(self, channel_id):
        """Delete a channel. Requires MANAGE_CHANNELS."""
        return await self._http.delete_channel(channel_id)

    async def reorder_channels(self, guild_id, items):
        """Reorder channels. ``items`` = list of
        ``{"id", "position", "category_id"}`` dicts.
        """
        return await self._http.reorder_channels(guild_id, items)

    async def purge_channel(self, channel_id, limit=100):
        """Bulk-delete up to ``limit`` recent messages in a channel.
        Returns the number actually deleted.
        """
        resp = await self._http.purge_channel(channel_id, limit=limit)
        return (resp or {}).get("deleted", 0)

    async def set_channel_permissions(self, channel_id, role_id, *, allow=0, deny=0):
        """Set a role's permission overrides on a channel."""
        return await self._http.set_channel_permissions(channel_id, role_id, allow=allow, deny=deny)

    async def list_categories(self, guild_id):
        """List categories in a guild. Returns [Category, ...]."""
        from .models import Category
        d = await self._http.list_categories(guild_id)
        return [Category.from_dict(c, client=self) for c in (d or [])]

    async def create_category(self, guild_id, name, *, permission_overrides=None):
        """Create a category. Requires MANAGE_CHANNELS.

        ``permission_overrides`` optional list of
        ``{"role_id", "allow", "deny"}`` applied at creation.
        Returns the created :class:`Category` or ``None``.
        """
        from .models import Category
        d = await self._http.create_category(guild_id, name, permission_overrides=permission_overrides)
        return Category.from_dict(d, client=self) if d else None

    async def edit_category(self, category_id, **patch):
        """Partial category update. Accepts ``name``, ``position``."""
        return await self._http.edit_category(category_id, **patch)

    async def delete_category(self, category_id):
        """Delete a category. Child channels become uncategorized."""
        return await self._http.delete_category(category_id)

    async def reorder_categories(self, guild_id, items):
        """Reorder categories. ``items`` = list of ``{"id", "position"}``."""
        return await self._http.reorder_categories(guild_id, items)

    async def set_category_permissions(self, category_id, role_id, *, allow=0, deny=0):
        """Set a role's permission overrides on a category."""
        return await self._http.set_category_permissions(category_id, role_id, allow=allow, deny=deny)

    async def create_role(self, guild_id, name, **kwargs):
        """Create a role. Requires MANAGE_ROLES in the guild.

        Keyword args are forwarded to :meth:`HTTPClient.create_role`
        (``color``, ``permissions``, ...). Returns the created
        :class:`Role` or ``None``.
        """
        from .models import Role
        d = await self._http.create_role(guild_id, name, **kwargs)
        return Role.from_dict(d, client=self) if d else None

    async def _start(self, token):
        self._loop = asyncio.get_running_loop()
        self._http = HTTPClient(token, base_url=self.base_url)
        self._gateway = Gateway(token, self.intents, self.ws_url, self._dispatch)
        try:
            while True:
                try:
                    await self._gateway.connect()
                    await self._gateway.run()
                except LoginFailure as e:
                    print(f"[banterapi] LOGIN FAILED: {e} — check your bot token")
                    break
                except GatewayError as e:
                    log.warning("gateway error: %s", e)
                code = self._gateway.close_code
                reason = self._gateway.close_reason
                if code in (4001, 4004):
                    label = "BANNED" if code == 4001 else "INVALID TOKEN"
                    print(f"[banterapi] DISCONNECTED ({code} {label}): {reason} — not reconnecting")
                    break
                if not self.reconnect:
                    break
                if code:
                    print(f"[banterapi] disconnected ({code} {reason}) — reconnecting in 5s")
                else:
                    log.info("reconnecting in 5s")
                self._gateway = Gateway(token, self.intents, self.ws_url, self._dispatch)
                await asyncio.sleep(5)
        finally:
            await self._gateway.close()
            await self._http.close()

    def create_task(self, coro):
        """Schedule a coroutine on the bot's event loop.

        Use this from inside event handlers (``on_ready``,
        ``on_message``, etc.) when you want to launch a long-running
        background task without blocking the handler's return.

        Args:
            coro: The coroutine object to run. Not a coroutine function
                — call it first: ``bot.create_task(my_loop())``, not
                ``bot.create_task(my_loop)``.

        Returns:
            asyncio.Task: The scheduled task. Usually ignored, but can
            be used to ``cancel()`` the background work on shutdown.

        Raises:
            RuntimeError: If called before the bot has started. The
            loop is only available once ``_start`` has begun — calling
            from module scope before ``bot.run()`` doesn't work.

        Example::

            @bot.event
            async def on_ready():
                bot.create_task(scheduler_loop(bot))
        """
        if self._loop is None:
            raise RuntimeError(
                "create_task() called before bot started. Use it from "
                "inside an event handler (on_ready, on_message, ...) — "
                "the loop doesn't exist until bot.run() is called."
            )
        return self._loop.create_task(coro)

    def run(self, token):
        """Blocking entry point. Start the bot and run until disconnected.

        This is the synchronous façade most scripts use:
        ``bot.run(TOKEN)`` at the bottom of a file. Internally it spins
        up an asyncio event loop and drives :meth:`_start`.

        Ctrl-C (``KeyboardInterrupt``) is caught and swallowed on
        purpose — it's the standard shutdown signal for a CLI-launched
        bot, and rethrowing would produce a noisy traceback the user
        can't act on. Non-``KeyboardInterrupt`` exceptions still
        propagate.
        """
        try:
            asyncio.run(self._start(token))
        except KeyboardInterrupt:
            pass