"""Slash-command interaction context.

When a user invokes a slash command, the server emits an
``interaction_create`` gateway event to the owning bot. The SDK wraps
the payload in an :class:`Interaction` and dispatches it to the
registered ``@bot.slash_command`` handler.

Unlike prefix commands (which deliver a :class:`~banterapi.Message`
via ``on_message``), slash commands deliver an :class:`Interaction`
with pre-parsed, typed options and a response-correlation token.

Handler usage::

    @bot.slash_command(
        name="roll",
        description="Roll an N-sided die",
        options=[SlashOption("sides", type=OPTION_INTEGER, required=False)],
    )
    async def roll(interaction):
        sides = interaction.options.get("sides", 6)
        await interaction.respond(f"🎲 {sides}-sided die")

Responding to an interaction:

* :meth:`Interaction.respond` — send the visible reply. The invocation
  stays on screen as a header; this message lands below.
* :meth:`Interaction.defer` — acknowledge that a response is coming
  "soon" (within the interaction timeout, typically 15 minutes). Use
  before long-running work so the UI can show a thinking state.
* :meth:`Interaction.followup` — send additional messages after the
  initial response. Can be called multiple times.

The ``ephemeral`` flag makes a response visible only to the invoker.
Follows Discord's semantics: ephemeral messages are dropped by
clients that aren't the invoker, even though they transit the same
gateway for everyone else.
"""


def _merge_components(embed, components):
    """Resolve the `components` payload for a respond/send call.

    If the caller passed components explicitly, that wins. Otherwise
    promote any buttons attached to the embed via add_button(). Returns
    None when there are no buttons to send so the body stays lean.
    """
    if components is not None:
        return components
    if embed is not None and hasattr(embed, "pending_components"):
        pending = embed.pending_components()
        if pending:
            return pending
    return None


class Interaction:
    """One interaction delivered to the bot.

    Two flavors arrive through the same class:

    * **Slash commands** — ``type == "slash"``. ``command_name`` is the
      registered slash command, ``options`` has the parsed arguments.
    * **Button clicks** — ``type == "button"``. ``custom_id`` is the
      clicked button's identifier, ``message_id`` is the source message.

    Constructed by :class:`~banterapi.Bot._dispatch` when an
    ``interaction_create`` event arrives. Do not instantiate manually.

    Attributes:
        id: Server-assigned interaction ID. Used to correlate the
            bot's response back to this invocation.
        token: Short-lived bearer token the server issued for this
            interaction. Included on every response call.
        type: ``"slash"`` or ``"button"`` — dispatch was routed to the
            matching ``@bot.slash_command`` or ``@bot.on_button``.
        command_name: For slash interactions, the command name. For
            button interactions, ``"__button__"`` (sentinel).
        custom_id: For button interactions, the clicked button's
            ``custom_id``. Empty string for slash interactions.
        message_id: For button interactions, the message the button
            sits on. Empty string for slash interactions.
        options: Dict of ``{option_name: parsed_value}`` for slash
            commands. Empty dict for button interactions.
        guild_id: Guild the interaction was invoked in, or ``""`` for
            a DM.
        channel_id: Channel ID it was invoked in.
        user_id: Invoking user's ID (whoever clicked the button or
            typed the slash).
    """

    __slots__ = (
        "id", "token", "app_id", "type", "command_name", "custom_id",
        "message_id", "options", "guild_id", "channel_id", "user_id",
        "_client", "_responded",
    )

    def __init__(self, payload, client=None):
        self.id = payload.get("id", "")
        self.token = payload.get("token", "")
        self.app_id = payload.get("app_id", "")
        # Default to "slash" when missing so older servers that don't
        # emit a type field still route correctly through slash_handlers.
        self.type = payload.get("type", "slash") or "slash"
        self.command_name = payload.get("command_name", "")
        self.custom_id = payload.get("custom_id", "")
        self.message_id = payload.get("message_id", "") or payload.get("source_message_id", "")
        self.options = payload.get("options", {}) or {}
        self.guild_id = payload.get("guild_id", "")
        self.channel_id = payload.get("channel_id", "")
        self.user_id = payload.get("user_id", "")
        self._client = client
        # Track whether we've sent the first response. Subsequent calls
        # must go through followup() since the server distinguishes
        # "initial response" from "follow-up" on the wire.
        self._responded = False

    @property
    def is_button(self):
        return self.type == "button"

    @property
    def is_slash(self):
        return self.type == "slash"

    async def respond(self, content="", *, embed=None, ephemeral=False, components=None):
        """Send the visible reply to the invocation.

        May only be called once per interaction. After this, additional
        messages must go through :meth:`followup` (or :meth:`update` for
        button interactions that want to edit the source message).

        Buttons attached to ``embed`` via ``embed.add_button()`` forward
        automatically as components. Pass ``components=[...]`` to
        override.

        Args:
            content: Message text.
            embed: Optional :class:`~banterapi.Embed`.
            ephemeral: If True, only the invoking user sees this
                message. Defaults to False (public).
            components: Optional explicit action-row array.

        Raises:
            RuntimeError: If called more than once on the same
                interaction — use :meth:`followup` for subsequent
                messages, or :meth:`update` for button interactions.
        """
        if self._responded:
            raise RuntimeError(
                "respond() was already called on this interaction. "
                "Use interaction.followup(...) for additional messages, "
                "or interaction.update(...) to edit the source message."
            )
        if self._client is None:
            raise RuntimeError("Interaction has no attached client.")
        body = {
            "kind": "reply",
            "content": content,
            "ephemeral": bool(ephemeral),
        }
        if embed is not None:
            body["embed"] = embed.to_dict() if hasattr(embed, "to_dict") else embed
        comps = _merge_components(embed, components)
        if comps is not None:
            body["components"] = comps
        await self._client._http.respond_interaction(self.id, self.token, body)
        self._responded = True

    async def defer(self, *, ephemeral=False):
        """Acknowledge the interaction without replying yet.

        Shows a thinking indicator in the client until :meth:`respond`
        or :meth:`followup` lands. Use for handlers that may exceed
        the client's immediate-response timeout (~3s). The ephemeral
        flag here determines whether the eventual response will be
        ephemeral too.
        """
        if self._responded:
            raise RuntimeError("interaction already responded to")
        if self._client is None:
            raise RuntimeError("Interaction has no attached client.")
        await self._client._http.respond_interaction(self.id, self.token, {
            "kind": "defer",
            "ephemeral": bool(ephemeral),
        })
        self._responded = True

    async def followup(self, content="", *, embed=None, ephemeral=False, components=None):
        """Send an additional message after the initial response.

        Callable repeatedly. Unlike :meth:`respond` there's no
        once-only limit — use for streaming progress updates, paginated
        results, or multi-part replies.
        """
        if self._client is None:
            raise RuntimeError("Interaction has no attached client.")
        body = {
            "kind": "followup",
            "content": content,
            "ephemeral": bool(ephemeral),
        }
        if embed is not None:
            body["embed"] = embed.to_dict() if hasattr(embed, "to_dict") else embed
        comps = _merge_components(embed, components)
        if comps is not None:
            body["components"] = comps
        await self._client._http.respond_interaction(self.id, self.token, body)

    async def update(self, content="", *, embed=None, components=None):
        """Edit the source message in place (button interactions only).

        Only valid for ``type == "button"`` interactions — slash
        interactions have no source message to edit. The edit replaces
        content/embed/components on the clicked message; all viewers
        see the update live.

        Semantics (match the server's ``update`` kind):

        * ``content=""`` keeps the existing content.
        * ``embed=None`` keeps the existing embed.
        * ``components=None`` AND no embed buttons → keep existing.
        * ``components=[]`` → clear all buttons (explicit empty array).

        Raises:
            RuntimeError: On a slash interaction, or if already responded.
        """
        if self.type != "button":
            raise RuntimeError(
                "update() is only valid for button interactions — use "
                "respond() or followup() for slash commands."
            )
        if self._responded:
            raise RuntimeError("interaction already responded to")
        if self._client is None:
            raise RuntimeError("Interaction has no attached client.")
        body = {"kind": "update", "content": content}
        if embed is not None:
            body["embed"] = embed.to_dict() if hasattr(embed, "to_dict") else embed
        comps = _merge_components(embed, components)
        if comps is not None:
            body["components"] = comps
        await self._client._http.respond_interaction(self.id, self.token, body)
        self._responded = True

    def __repr__(self):
        if self.is_button:
            return (
                f"Interaction(type=button, id={self.id!r}, custom_id={self.custom_id!r}, "
                f"message={self.message_id!r}, user={self.user_id!r}, channel={self.channel_id!r})"
            )
        return (
            f"Interaction(type=slash, id={self.id!r}, app={self.app_id!r}, command={self.command_name!r}, "
            f"user={self.user_id!r}, channel={self.channel_id!r})"
        )