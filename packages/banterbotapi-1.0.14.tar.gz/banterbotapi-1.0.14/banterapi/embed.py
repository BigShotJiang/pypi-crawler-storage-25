class Embed:
    """Rich embed card.

    Text, fields, images, thumbnails, footer, author are rendered INSIDE
    the embed's accent-colored card. Buttons added via ``add_button()``
    are NOT rendered inside the card — they render below the message as
    a row of interactive components (same system as ``@bot.on_button``
    handlers).

    Source-compatible with the pre-unification API: existing bots that
    call ``embed.add_button("Open", url="...")`` or
    ``embed.add_button("Next", id="page_next")`` continue to work. The
    SDK collects these calls separately from the embed body and the Bot
    methods (``send_message``, ``Interaction.respond``, ``Message.reply``)
    forward them as top-level ``components`` on the wire.

    Use :meth:`pending_components` (or pass the Embed to a send helper
    that already knows how) to get the components payload. The canonical
    JSON shape is ``[{type:"action_row", components:[{type:"button",...}]}]``
    — one row of up to 5 buttons, with at most 5 rows.
    """

    def __init__(self, title="", description="", color=None, url="", image="", thumbnail=""):
        self._data = {}
        if title:
            self._data["title"] = title
        if description:
            self._data["description"] = description
        if color is not None:
            self._data["color"] = color if isinstance(color, str) else f"#{color:06x}"
        if url:
            self._data["url"] = url
        if image:
            self._data["image"] = image
        if thumbnail:
            self._data["thumbnail"] = thumbnail
        self._data["fields"] = []
        # Pending buttons accumulated from add_button() calls. Rendered
        # as message components rather than embed-body elements.
        self._pending_buttons = []

    def add_field(self, name, value, inline=False):
        self._data["fields"].append({"name": name, "value": value, "inline": inline})
        return self

    def set_footer(self, text):
        self._data["footer"] = text
        return self

    def set_author(self, name):
        self._data["author"] = name
        return self

    def set_image(self, url):
        self._data["image"] = url
        return self

    def set_thumbnail(self, url):
        self._data["thumbnail"] = url
        return self

    def add_button(self, label, style="secondary", url="", emoji="", disabled=False, custom_id="", id=""):
        """Attach a button. Rendered below the message alongside the embed.

        Args:
            label: Button text (1–80 chars).
            style: One of ``primary``, ``secondary``, ``success``,
                ``danger``, ``link``. ``link`` requires ``url``. Any
                other style requires ``custom_id`` if you want the click
                to fire a handler.
            url: For link buttons. Opens in a new tab.
            emoji: Unicode character shown before the label.
            disabled: If True, the button renders grayed-out and does
                not fire.
            custom_id: Identifier delivered to ``on_button`` handlers.
                Required for non-link interactive buttons.
            id: Deprecated alias for ``custom_id`` — kept so that older
                bot code (``add_button(..., id="foo")``) still works.
        """
        btn = {"type": "button", "label": label, "style": style or "secondary"}
        if emoji:
            btn["emoji"] = emoji
        if disabled:
            btn["disabled"] = True
        if style == "link":
            if url:
                btn["url"] = url
        else:
            cid = custom_id or id
            if cid:
                btn["custom_id"] = cid
        self._pending_buttons.append(btn)
        return self

    def pending_components(self):
        """Return the components payload built from ``add_button()`` calls.

        Returns a list of action rows (up to 5 rows × 5 buttons each),
        or an empty list if no buttons were added. The wire shape matches
        the backend's ``components`` field exactly.
        """
        if not self._pending_buttons:
            return []
        rows = []
        for i in range(0, len(self._pending_buttons), 5):
            rows.append({
                "type": "action_row",
                "components": self._pending_buttons[i:i + 5],
            })
        return rows[:5]

    def to_dict(self):
        d = dict(self._data)
        if not d.get("fields"):
            d.pop("fields", None)
        # Never emit "buttons" on the embed payload anymore — the backend
        # drops it on decode, but keeping it out of the canonical shape
        # stops noise from appearing in bot traffic captures.
        d.pop("buttons", None)
        return d