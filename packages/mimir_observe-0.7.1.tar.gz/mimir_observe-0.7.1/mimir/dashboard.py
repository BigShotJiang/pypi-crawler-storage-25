"""
Mimir local dashboard — HTTP server + trajectory storage.

Receives telemetry from the SDK, persists runs grouped by fingerprint,
and serves a single-page dashboard for viewing and diffing agent runs.
"""

from __future__ import annotations

import hashlib
import json
import threading
import time
from datetime import datetime, timezone
from http.server import HTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from typing import Any
from urllib.parse import urlparse, parse_qs

# ---------------------------------------------------------------------------
# Storage paths — all under ~/.mimir/
# ---------------------------------------------------------------------------

MIMIR_DIR = Path.home() / ".mimir"
TASK_GROUPS_FILE = MIMIR_DIR / "task_groups.json"
TRAJECTORIES_DIR = MIMIR_DIR / "trajectories"
TELEMETRY_DIR = MIMIR_DIR / "telemetry"


def _ensure_dirs():
    MIMIR_DIR.mkdir(exist_ok=True)
    TRAJECTORIES_DIR.mkdir(exist_ok=True)
    TELEMETRY_DIR.mkdir(exist_ok=True)


# ---------------------------------------------------------------------------
# FrameworkRecorder — persistence layer
# ---------------------------------------------------------------------------


class FrameworkRecorder:
    """Thread-safe persistence for task groups, trajectories, and telemetry."""

    def __init__(self):
        _ensure_dirs()
        self._lock = threading.Lock()
        self._active_runs: dict[str, dict] = {}  # run_id -> run data

    # --- task groups ---

    def _load_task_groups(self) -> dict:
        if TASK_GROUPS_FILE.exists():
            try:
                return json.loads(TASK_GROUPS_FILE.read_text())
            except (json.JSONDecodeError, OSError):
                pass
        return {}

    def _save_task_groups(self, groups: dict) -> None:
        TASK_GROUPS_FILE.write_text(json.dumps(groups, indent=2))

    def register_task(self, data: dict) -> None:
        with self._lock:
            groups = self._load_task_groups()
            tid = data["task_type_id"]
            if tid not in groups:
                groups[tid] = {
                    "task_type_id": tid,
                    "name": data.get("name", ""),
                    "config": data.get("config", ""),
                    "config_hash": data.get("config_hash", ""),
                    "tools": data.get("tools", []),
                    "model": data.get("model", ""),
                    "run_count": 0,
                    "created_at": time.time(),
                }
            self._save_task_groups(groups)

    # --- runs ---

    def start_run(self, data: dict) -> None:
        run_id = data["run_id"]
        with self._lock:
            self._active_runs[run_id] = {
                "run_id": run_id,
                "task_type_id": data.get("task_type_id", ""),
                "task_name": data.get("task_name", ""),
                "input": data.get("input", {}),
                "started_at": data.get("started_at", time.time()),
                "steps": [],
            }

    def add_step(self, data: dict) -> None:
        run_id = data.get("run_id", "")
        with self._lock:
            run = self._active_runs.get(run_id)
            if run:
                step = {k: v for k, v in data.items() if k != "run_id"}
                run["steps"].append(step)

    def end_run(self, data: dict) -> None:
        run_id = data["run_id"]
        with self._lock:
            run = self._active_runs.pop(run_id, None)
            if run is None:
                # Reconstruct from end payload if we missed the start
                run = {
                    "run_id": run_id,
                    "task_type_id": data.get("task_type_id", ""),
                    "task_name": data.get("task_name", ""),
                    "input": {},
                    "started_at": data.get("ended_at", time.time()),
                    "steps": data.get("steps", []),
                }

            run.update({
                "status": data.get("status", "unknown"),
                "duration_s": data.get("duration_s", 0),
                "usage": data.get("usage", {}),
                "cost_usd": data.get("cost_usd"),
                "output": data.get("output"),
                "ended_at": data.get("ended_at", time.time()),
            })

            # If end payload has steps and run had none, use those
            if not run.get("steps") and data.get("steps"):
                run["steps"] = data["steps"]

            self._persist_run(run)

    def _persist_run(self, run: dict) -> None:
        """Save run to trajectory file (grouped by tool-call fingerprint) and telemetry."""
        # Compute fingerprint from tool step shapes
        fp = self._fingerprint(run.get("steps", []))
        traj_file = TRAJECTORIES_DIR / f"{fp}.json"

        # Load or create trajectory
        if traj_file.exists():
            try:
                traj = json.loads(traj_file.read_text())
            except (json.JSONDecodeError, OSError):
                traj = {"fingerprint": fp, "runs": []}
        else:
            traj = {"fingerprint": fp, "runs": []}

        traj["runs"].append(run)
        traj_file.write_text(json.dumps(traj, indent=2))

        # Update task group run count
        groups = self._load_task_groups()
        tid = run.get("task_type_id", "")
        if tid in groups:
            groups[tid]["run_count"] = groups[tid].get("run_count", 0) + 1
            groups[tid]["last_run_at"] = run.get("ended_at", time.time())
            self._save_task_groups(groups)

        # Write telemetry
        self._write_telemetry(run)

    def _fingerprint(self, steps: list[dict]) -> str:
        """SHA-256 of tool step shapes (type + tool name sequence)."""
        shapes = []
        for s in steps:
            if s.get("type") in ("tool", "tool_error"):
                shapes.append(f"{s.get('type')}:{s.get('tool', '')}")
        raw = "|".join(shapes) if shapes else "empty"
        return hashlib.sha256(raw.encode()).hexdigest()[:16]

    def _write_telemetry(self, run: dict) -> None:
        """Append tool call records to daily JSONL telemetry file."""
        today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        path = TELEMETRY_DIR / f"{today}.jsonl"
        lines = []
        for step in run.get("steps", []):
            if step.get("type") in ("tool", "tool_error"):
                record = {
                    "run_id": run["run_id"],
                    "task_type_id": run.get("task_type_id", ""),
                    "task_name": run.get("task_name", ""),
                    "tool": step.get("tool", ""),
                    "type": step.get("type", ""),
                    "duration_ms": step.get("duration_ms", 0),
                    "ts": step.get("ts", time.time()),
                }
                lines.append(json.dumps(record))
        if lines:
            with open(path, "a") as f:
                f.write("\n".join(lines) + "\n")

    # --- query methods ---

    def get_overview(self) -> dict:
        groups = self._load_task_groups()
        total_runs = sum(g.get("run_count", 0) for g in groups.values())
        traj_count = len(list(TRAJECTORIES_DIR.glob("*.json")))
        # Sum cost across all persisted runs
        total_cost = 0.0
        for traj_file in TRAJECTORIES_DIR.glob("*.json"):
            try:
                traj = json.loads(traj_file.read_text())
                for r in traj.get("runs", []):
                    total_cost += r.get("cost_usd") or 0
            except (json.JSONDecodeError, OSError):
                continue
        return {
            "task_groups": len(groups),
            "total_runs": total_runs,
            "trajectories": traj_count,
            "active_runs": len(self._active_runs),
            "total_cost_usd": round(total_cost, 6),
        }

    def get_task_groups(self) -> list[dict]:
        groups = self._load_task_groups()
        # Compute per-group cost + tokens from trajectories
        group_costs: dict[str, float] = {}
        group_tokens: dict[str, int] = {}
        for traj_file in TRAJECTORIES_DIR.glob("*.json"):
            try:
                traj = json.loads(traj_file.read_text())
                for r in traj.get("runs", []):
                    tid = r.get("task_type_id", "")
                    group_costs[tid] = group_costs.get(tid, 0) + (r.get("cost_usd") or 0)
                    u = r.get("usage", {})
                    group_tokens[tid] = group_tokens.get(tid, 0) + (u.get("input_tokens", 0) or 0) + (u.get("output_tokens", 0) or 0)
            except (json.JSONDecodeError, OSError):
                continue
        for g in groups.values():
            tid = g["task_type_id"]
            g["total_cost_usd"] = round(group_costs.get(tid, 0), 6)
            g["total_tokens"] = group_tokens.get(tid, 0)
        return sorted(groups.values(), key=lambda g: g.get("last_run_at", 0), reverse=True)

    def get_task_group(self, task_type_id: str) -> dict | None:
        groups = self._load_task_groups()
        group = groups.get(task_type_id)
        if not group:
            return None
        # Attach runs from all trajectory files that match this task
        runs = []
        for traj_file in TRAJECTORIES_DIR.glob("*.json"):
            try:
                traj = json.loads(traj_file.read_text())
                for r in traj.get("runs", []):
                    if r.get("task_type_id") == task_type_id:
                        runs.append(r)
            except (json.JSONDecodeError, OSError):
                continue
        group["runs"] = sorted(runs, key=lambda r: r.get("ended_at", 0), reverse=True)
        return group

    def get_divergence(self) -> list[dict]:
        """Cross-run divergence map — find fingerprint groups with multiple patterns."""
        divergences = []
        groups = self._load_task_groups()

        for tid, group in groups.items():
            fingerprints: dict[str, list] = {}
            for traj_file in TRAJECTORIES_DIR.glob("*.json"):
                try:
                    traj = json.loads(traj_file.read_text())
                    for r in traj.get("runs", []):
                        if r.get("task_type_id") == tid:
                            fp = traj["fingerprint"]
                            fingerprints.setdefault(fp, []).append(r["run_id"])
                except (json.JSONDecodeError, OSError):
                    continue

            if len(fingerprints) > 1:
                divergences.append({
                    "task_type_id": tid,
                    "task_name": group.get("name", ""),
                    "fingerprints": {fp: {"run_count": len(ids), "run_ids": ids} for fp, ids in fingerprints.items()},
                })

        return divergences

    def get_all_data(self) -> dict:
        """Full data export."""
        groups = self._load_task_groups()
        trajectories = {}
        for traj_file in TRAJECTORIES_DIR.glob("*.json"):
            try:
                traj = json.loads(traj_file.read_text())
                trajectories[traj_file.stem] = traj
            except (json.JSONDecodeError, OSError):
                continue
        return {"task_groups": groups, "trajectories": trajectories}


# ---------------------------------------------------------------------------
# HTTP handler
# ---------------------------------------------------------------------------

_recorder = FrameworkRecorder()


class DashboardHandler(BaseHTTPRequestHandler):

    def log_message(self, format, *args):
        # Suppress default logging
        pass

    def _send_json(self, data: Any, status: int = 200) -> None:
        body = json.dumps(data, indent=2).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _send_html(self, html: str, status: int = 200) -> None:
        body = html.encode()
        self.send_response(status)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _read_body(self) -> dict:
        length = int(self.headers.get("Content-Length", 0))
        if length == 0:
            return {}
        raw = self.rfile.read(length)
        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            return {}

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path.rstrip("/")
        params = parse_qs(parsed.query)

        if path == "" or path == "/":
            self._send_html(_dashboard_html())
        elif path == "/api/overview":
            self._send_json(_recorder.get_overview())
        elif path == "/api/task-groups":
            self._send_json(_recorder.get_task_groups())
        elif path.startswith("/api/task-group/"):
            tid = path.split("/api/task-group/")[1].split("/")[0]
            result = _recorder.get_task_group(tid)
            if result:
                self._send_json(result)
            else:
                self._send_json({"error": "not found"}, 404)
        elif path == "/api/divergence":
            self._send_json(_recorder.get_divergence())
        elif path == "/api/data":
            self._send_json(_recorder.get_all_data())
        else:
            self._send_json({"error": "not found"}, 404)

    def do_POST(self):
        path = urlparse(self.path).path.rstrip("/")
        data = self._read_body()

        if path == "/api/task/register":
            _recorder.register_task(data)
            self._send_json({"ok": True})
        elif path == "/api/run/start":
            _recorder.start_run(data)
            self._send_json({"ok": True})
        elif path == "/api/run/step":
            _recorder.add_step(data)
            self._send_json({"ok": True})
        elif path == "/api/run/end":
            _recorder.end_run(data)
            self._send_json({"ok": True})
        else:
            self._send_json({"error": "not found"}, 404)


# ---------------------------------------------------------------------------
# Dashboard HTML (single-page app)
# ---------------------------------------------------------------------------


def _dashboard_html() -> str:
    return """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Mimir</title>
<style>
  :root {
    --bg: #09090b; --surface: #18181b; --surface2: #1e1e22; --border: #27272a;
    --text: #fafafa; --text2: #d4d4d8; --muted: #71717a; --dim: #52525b;
    --accent: #6366f1; --accent2: #818cf8; --accent-bg: rgba(99,102,241,0.08);
    --green: #22c55e; --green-bg: rgba(34,197,94,0.08);
    --red: #ef4444; --red-bg: rgba(239,68,68,0.08);
    --amber: #f59e0b; --amber-bg: rgba(245,158,11,0.08);
    --cyan: #06b6d4; --cyan-bg: rgba(6,182,212,0.06);
    --radius: 8px;
  }
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { font-family: -apple-system, BlinkMacSystemFont, 'Inter', 'Segoe UI', sans-serif; background: var(--bg); color: var(--text); font-size: 13px; line-height: 1.6; }
  code, .mono { font-family: 'SF Mono', 'Cascadia Code', 'Fira Code', 'JetBrains Mono', monospace; font-size: 12px; }

  /* Layout */
  .shell { display: flex; height: 100vh; overflow: hidden; }
  .sidebar { width: 280px; min-width: 280px; border-right: 1px solid var(--border); display: flex; flex-direction: column; background: var(--surface); }
  .main { flex: 1; overflow-y: auto; }

  /* Sidebar */
  .sidebar-header { padding: 20px 16px 12px; border-bottom: 1px solid var(--border); }
  .sidebar-header h1 { font-size: 15px; font-weight: 700; letter-spacing: -0.02em; }
  .sidebar-header h1 span { color: var(--accent2); }
  .sidebar-header p { color: var(--muted); font-size: 11px; margin-top: 2px; }
  .sidebar-nav { padding: 8px; flex: 1; overflow-y: auto; }
  .nav-section { padding: 8px 8px 4px; font-size: 10px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.06em; color: var(--dim); }
  .nav-item { display: flex; align-items: center; gap: 8px; padding: 8px 12px; border-radius: 6px; cursor: pointer; color: var(--text2); transition: all 0.1s; }
  .nav-item:hover { background: var(--accent-bg); color: var(--text); }
  .nav-item.active { background: var(--accent-bg); color: var(--accent2); font-weight: 500; }
  .nav-item .count { margin-left: auto; font-size: 11px; color: var(--muted); background: var(--bg); padding: 0 6px; border-radius: 10px; }
  .nav-item .dot { width: 6px; height: 6px; border-radius: 50%; flex-shrink: 0; }
  .sidebar-stats { padding: 12px 16px; border-top: 1px solid var(--border); display: grid; grid-template-columns: 1fr 1fr; gap: 8px; }
  .sidebar-stat { text-align: center; }
  .sidebar-stat .val { font-size: 18px; font-weight: 700; }
  .sidebar-stat .lbl { font-size: 10px; color: var(--muted); text-transform: uppercase; letter-spacing: 0.04em; }

  /* Main content */
  .main-header { padding: 20px 32px 16px; border-bottom: 1px solid var(--border); display: flex; justify-content: space-between; align-items: center; position: sticky; top: 0; background: var(--bg); z-index: 10; }
  .main-header h2 { font-size: 16px; font-weight: 600; }
  .main-header .subtitle { color: var(--muted); font-size: 12px; margin-top: 2px; }
  .main-body { padding: 24px 32px; }

  /* Empty state */
  .empty { color: var(--muted); text-align: center; padding: 80px 40px; }
  .empty h3 { font-size: 15px; color: var(--text2); margin-bottom: 8px; }

  /* Badges */
  .badge { display: inline-flex; align-items: center; padding: 2px 8px; border-radius: 4px; font-size: 11px; font-weight: 500; }
  .badge-tool { background: var(--accent-bg); color: var(--accent2); }
  .badge-success { background: var(--green-bg); color: var(--green); }
  .badge-error { background: var(--red-bg); color: var(--red); }
  .badge-amber { background: var(--amber-bg); color: var(--amber); }
  .badge-outline { background: none; border: 1px solid var(--border); color: var(--muted); }

  /* Run cards */
  .run-list { display: flex; flex-direction: column; gap: 8px; }
  .run-card { background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius); overflow: hidden; transition: border-color 0.15s; }
  .run-card:hover { border-color: var(--dim); }
  .run-card-header { display: flex; align-items: center; gap: 12px; padding: 14px 16px; cursor: pointer; user-select: none; }
  .run-label { font-weight: 600; font-size: 14px; color: var(--accent2); min-width: 70px; }
  .run-prompt { flex: 1; color: var(--text2); font-size: 12px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  .run-meta { display: flex; gap: 12px; align-items: center; font-size: 11px; color: var(--muted); flex-shrink: 0; }
  .run-meta .sep { color: var(--border); }
  .run-chevron { color: var(--dim); transition: transform 0.2s; font-size: 12px; }
  .run-card.open .run-chevron { transform: rotate(90deg); }
  .run-body { display: none; border-top: 1px solid var(--border); }
  .run-card.open .run-body { display: block; }

  /* Run body sections */
  .run-section { padding: 16px; border-bottom: 1px solid var(--border); }
  .run-section:last-child { border-bottom: none; }
  .run-section-title { font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.04em; color: var(--dim); margin-bottom: 10px; }
  .run-io { font-size: 12px; color: var(--text2); line-height: 1.7; }
  .run-io .label { color: var(--muted); font-size: 11px; font-weight: 500; }
  .run-output { margin-top: 10px; padding: 12px; background: var(--bg); border-radius: 6px; white-space: pre-wrap; word-break: break-word; max-height: 400px; overflow-y: auto; font-size: 12px; }
  .run-footer { padding: 12px 16px; border-top: 1px solid var(--border); display: flex; gap: 16px; align-items: center; font-size: 11px; color: var(--muted); background: var(--surface2); }

  /* Timeline steps */
  .timeline { position: relative; padding-left: 20px; }
  .timeline::before { content: ''; position: absolute; left: 5px; top: 8px; bottom: 8px; width: 1px; background: var(--border); }
  .tl-step { position: relative; padding: 6px 0 6px 16px; }
  .tl-step::before { content: ''; position: absolute; left: -1px; top: 14px; width: 9px; height: 9px; border-radius: 50%; border: 2px solid var(--border); background: var(--bg); z-index: 1; }
  .tl-step.tl-tool::before { border-color: var(--accent); background: var(--accent-bg); }
  .tl-step.tl-tool-error::before { border-color: var(--red); background: var(--red-bg); }
  .tl-step.tl-reasoning::before { border-color: var(--green); background: var(--green-bg); }
  .tl-step.tl-llm::before { border-color: var(--amber); background: var(--amber-bg); }

  .tl-head { display: flex; align-items: center; gap: 8px; }
  .tl-name { font-weight: 600; font-size: 12px; }
  .tl-tool .tl-name { color: var(--accent2); }
  .tl-tool-error .tl-name { color: var(--red); }
  .tl-reasoning .tl-name { color: var(--green); }
  .tl-dur { font-size: 10px; color: var(--muted); font-family: 'SF Mono', monospace; }
  .tl-detail { margin-top: 4px; font-size: 12px; color: var(--muted); }
  .tl-args { padding: 6px 10px; margin-top: 4px; background: var(--bg); border-radius: 4px; font-size: 11px; white-space: pre-wrap; word-break: break-word; max-height: 120px; overflow-y: auto; }
  .tl-args.mono { font-family: 'SF Mono', 'Cascadia Code', monospace; }
  .tl-result { padding: 6px 10px; margin-top: 4px; background: var(--cyan-bg); border-radius: 4px; border-left: 2px solid var(--cyan); font-size: 11px; white-space: pre-wrap; word-break: break-word; max-height: 150px; overflow-y: auto; }
  .tl-reasoning-text { padding: 8px 12px; margin-top: 4px; background: var(--green-bg); border-radius: 4px; border-left: 2px solid var(--green); font-size: 12px; line-height: 1.6; white-space: pre-wrap; word-break: break-word; color: var(--text2); transition: max-height 0.2s ease; }
  .tl-toggle { font-size: 11px; color: var(--accent2); cursor: pointer; margin-left: 8px; }
  .tl-toggle:hover { text-decoration: underline; }

  /* Diff */
  .diff-bar { display: flex; gap: 8px; align-items: center; margin-bottom: 16px; flex-wrap: wrap; }
  .diff-bar select { background: var(--surface); color: var(--text); border: 1px solid var(--border); padding: 6px 10px; border-radius: 6px; font-family: inherit; font-size: 12px; }
  .diff-bar select:focus { border-color: var(--accent); outline: none; }
  .diff-btn { background: var(--accent); color: #fff; border: none; padding: 6px 14px; border-radius: 6px; cursor: pointer; font-family: inherit; font-size: 12px; font-weight: 500; }
  .diff-btn:hover { opacity: 0.9; }
  .diff-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
  .diff-col { background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius); padding: 16px; overflow-x: auto; }
  .diff-col-title { font-size: 12px; font-weight: 600; margin-bottom: 12px; display: flex; justify-content: space-between; }
  .diff-col-title .diff-stats { font-weight: 400; color: var(--muted); }
  .diff-row { padding: 6px 10px; margin: 3px 0; border-radius: 4px; font-size: 12px; display: flex; justify-content: space-between; }
  .diff-row-tool { background: var(--accent-bg); }
  .diff-match { background: var(--surface2); }
  .diff-add { background: var(--green-bg); }
  .diff-rm { background: var(--red-bg); }
  .diff-summary { margin-top: 16px; padding: 14px 16px; background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius); display: grid; grid-template-columns: repeat(auto-fit, minmax(140px,1fr)); gap: 12px; font-size: 12px; }
  .diff-summary .ds-label { color: var(--muted); font-size: 10px; text-transform: uppercase; }
  .diff-summary .ds-val { font-weight: 600; margin-top: 2px; }
  .diff-delta-pos { color: var(--red); }
  .diff-delta-neg { color: var(--green); }

  /* Tool duration waterfall */
  .waterfall { display: flex; flex-direction: column; gap: 4px; margin-bottom: 12px; position: relative; padding-bottom: 18px; }
  .wf-row { position: relative; width: 100%; height: 18px; background: var(--surface2); border-radius: 3px; overflow: visible; }
  .wf-bar { position: absolute; top: 0; height: 100%; background: var(--accent); display: flex; align-items: center; padding: 0 6px; color: #fff; font-size: 10px; font-weight: 500; white-space: nowrap; overflow: hidden; cursor: default; transition: opacity 0.15s; min-width: 2px; border-radius: 2px; }
  .wf-bar:hover { opacity: 0.75; }
  .wf-error { background: var(--red); }
  .wf-llm { background: var(--amber); }
  .wf-marker { position: absolute; top: 0; bottom: 18px; width: 1px; background: var(--dim); pointer-events: none; }
  .wf-marker-start { left: 0; }
  .wf-marker-end { right: 0; }
  .wf-axis { position: absolute; left: 0; right: 0; bottom: 0; display: flex; justify-content: space-between; font-size: 10px; color: var(--muted); font-family: ui-monospace, SFMono-Regular, Menlo, monospace; }
  /* Custom tooltip */
  .wf-tip { position: absolute; bottom: calc(100% + 6px); left: 50%; transform: translateX(-50%); background: var(--bg); border: 1px solid var(--border); border-radius: 6px; padding: 8px 10px; font-size: 11px; line-height: 1.5; color: var(--text); white-space: nowrap; box-shadow: 0 4px 12px rgba(0,0,0,0.4); pointer-events: none; opacity: 0; transition: opacity 0.12s; z-index: 50; min-width: 180px; }
  .wf-tip-title { font-weight: 600; font-size: 12px; margin-bottom: 4px; color: var(--text); }
  .wf-tip-row { display: flex; justify-content: space-between; gap: 16px; font-family: ui-monospace, SFMono-Regular, Menlo, monospace; }
  .wf-tip-lbl { color: var(--muted); }
  .wf-tip-val { color: var(--text); }
  .wf-tip-val.amber { color: var(--amber); font-weight: 600; }
  .wf-tip-sep { height: 1px; background: var(--border); margin: 5px 0; }
  .wf-bar:hover + .wf-tip, .wf-tip:hover { opacity: 1; }
  /* Sparkline */
  .wf-spark { position: relative; width: 100%; height: 32px; margin-bottom: 6px; }
  .wf-spark svg { width: 100%; height: 100%; display: block; overflow: visible; }
  .wf-spark-label { position: absolute; top: 0; left: 0; font-size: 9px; color: var(--muted); text-transform: uppercase; letter-spacing: 0.05em; pointer-events: none; }
  .wf-spark-end { position: absolute; top: 0; right: 0; font-size: 10px; color: var(--amber); font-weight: 600; font-family: ui-monospace, SFMono-Regular, Menlo, monospace; pointer-events: none; }

  /* Color key */
  .wf-key { display: flex; gap: 14px; font-size: 10px; color: var(--muted); margin-bottom: 6px; justify-content: flex-end; }
  .wf-key-dot { display: inline-block; width: 10px; height: 10px; border-radius: 2px; vertical-align: middle; margin-right: 3px; }

  /* Divergence */
  .div-card { background: var(--surface); border: 1px solid var(--amber); border-radius: var(--radius); padding: 16px; margin-bottom: 8px; }
  .div-card .name { font-weight: 600; font-size: 14px; }
  .div-card .patterns { margin-top: 8px; display: flex; gap: 6px; flex-wrap: wrap; }

  /* Buttons */
  .btn-ghost { background: none; border: 1px solid var(--border); color: var(--text2); padding: 5px 12px; border-radius: 6px; cursor: pointer; font-family: inherit; font-size: 12px; }
  .btn-ghost:hover { border-color: var(--accent); color: var(--text); }

  /* ===== Behavioral Comparison ===== */
  .cmp-banner { display: flex; align-items: flex-start; gap: 14px; padding: 14px 18px; margin-bottom: 16px; background: linear-gradient(135deg, rgba(245,158,11,0.07), rgba(239,68,68,0.04)); border: 1px solid var(--amber); border-radius: var(--radius); }
  .cmp-banner-icon { font-size: 20px; line-height: 1; flex-shrink: 0; margin-top: 1px; }
  .cmp-banner-body { flex: 1; }
  .cmp-banner-title { font-weight: 700; font-size: 13px; color: var(--amber); }
  .cmp-banner-desc { font-size: 12px; color: var(--text2); margin-top: 2px; line-height: 1.5; }
  .cmp-banner-jump { margin-left: auto; flex-shrink: 0; background: var(--amber); color: var(--bg); border: none; padding: 5px 12px; border-radius: 6px; cursor: pointer; font-size: 11px; font-weight: 600; align-self: center; }
  .cmp-banner-jump:hover { opacity: 0.9; }
  .cmp-banner-none { border-color: var(--green); background: linear-gradient(135deg, rgba(34,197,94,0.06), rgba(34,197,94,0.02)); }
  .cmp-banner-none .cmp-banner-title { color: var(--green); }

  .cmp-stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(100px, 1fr)); gap: 8px; margin-bottom: 14px; }
  .cmp-stat { background: var(--surface); border: 1px solid var(--border); border-radius: 6px; padding: 10px; text-align: center; }
  .cmp-stat-lbl { font-size: 9px; text-transform: uppercase; color: var(--muted); letter-spacing: 0.05em; }
  .cmp-stat-val { font-size: 16px; font-weight: 700; margin-top: 2px; }
  .cmp-c-a { color: var(--cyan); }
  .cmp-c-b { color: var(--accent2); }
  .cmp-c-match { color: var(--green); }
  .cmp-c-warn { color: var(--amber); }

  .cmp-filters { display: flex; gap: 14px; margin-bottom: 10px; font-size: 11px; color: var(--text2); }
  .cmp-filters label { display: flex; align-items: center; gap: 4px; cursor: pointer; }
  .cmp-filters input[type=checkbox] { accent-color: var(--accent); }

  .cmp-timeline { position: relative; }
  .cmp-row { display: flex; gap: 0; border-bottom: 1px solid var(--border); transition: background 0.1s; }
  .cmp-row:hover { background: rgba(255,255,255,0.015); }
  .cmp-row-marker { width: 4px; flex-shrink: 0; align-self: stretch; }
  .cmp-mk-match { background: var(--green); }
  .cmp-mk-a { background: var(--cyan); }
  .cmp-mk-b { background: var(--accent2); }
  .cmp-mk-reason { background: var(--green); opacity: 0.4; }
  .cmp-row-body { flex: 1; padding: 7px 12px; min-width: 0; }
  .cmp-row-head { display: flex; align-items: center; gap: 8px; font-size: 12px; flex-wrap: wrap; }
  .cmp-row-num { color: var(--dim); font-size: 10px; min-width: 20px; font-family: monospace; }
  .cmp-row-name { font-weight: 600; }
  .cmp-row-name.cmp-n-match { color: var(--text); }
  .cmp-row-name.cmp-n-a { color: var(--cyan); }
  .cmp-row-name.cmp-n-b { color: var(--accent2); }
  .cmp-row-name.cmp-n-reason { color: var(--green); font-weight: 500; }
  .cmp-badge { padding: 1px 6px; border-radius: 3px; font-size: 9px; font-weight: 600; letter-spacing: 0.02em; }
  .cmp-badge-match { background: var(--green-bg); color: var(--green); }
  .cmp-badge-a { background: var(--cyan-bg); color: var(--cyan); }
  .cmp-badge-b { background: var(--accent-bg); color: var(--accent2); }
  .cmp-badge-drift { background: var(--amber-bg); color: var(--amber); }
  .cmp-row-dur { margin-left: auto; font-size: 10px; color: var(--muted); font-family: monospace; white-space: nowrap; }
  .cmp-row-toggle { font-size: 10px; color: var(--accent2); cursor: pointer; margin-left: 4px; }
  .cmp-row-toggle:hover { text-decoration: underline; }
  .cmp-row-preview { font-size: 11px; color: var(--muted); margin-top: 3px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }

  .cmp-detail { margin-top: 8px; padding: 10px; background: var(--bg); border-radius: 6px; border: 1px solid var(--border); }
  .cmp-detail-lbl { font-size: 9px; font-weight: 600; color: var(--dim); text-transform: uppercase; margin-bottom: 4px; margin-top: 8px; }
  .cmp-detail-lbl:first-child { margin-top: 0; }
  .cmp-diff-line { padding: 1px 4px; font-family: monospace; font-size: 11px; line-height: 1.7; border-radius: 2px; }
  .cmp-dl-same { color: var(--muted); }
  .cmp-dl-changed { display: flex; gap: 12px; }
  .cmp-dl-val-a { color: var(--cyan); background: rgba(6,182,212,0.06); padding: 0 4px; border-radius: 2px; }
  .cmp-dl-val-b { color: var(--accent2); background: rgba(99,102,241,0.06); padding: 0 4px; border-radius: 2px; }
  .cmp-dl-added { color: var(--green); background: var(--green-bg); padding: 0 4px; border-radius: 2px; }
  .cmp-dl-removed { color: var(--red); background: var(--red-bg); padding: 0 4px; border-radius: 2px; }
  .cmp-reason-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
  .cmp-reason-col-lbl { font-size: 10px; font-weight: 600; margin-bottom: 4px; }
  .cmp-reason-col-lbl.cmp-c-a { color: var(--cyan); }
  .cmp-reason-col-lbl.cmp-c-b { color: var(--accent2); }
  .cmp-reason-text { padding: 8px 10px; border-radius: 4px; font-size: 11px; line-height: 1.6; white-space: pre-wrap; word-break: break-word; max-height: 250px; overflow-y: auto; background: var(--surface); }

  .cmp-div-marker { display: flex; align-items: center; gap: 8px; padding: 10px 0; margin: 2px 0; }
  .cmp-div-line { flex: 1; height: 2px; background: var(--amber); border-radius: 1px; }
  .cmp-div-label { font-size: 9px; font-weight: 700; letter-spacing: 0.1em; color: var(--amber); white-space: nowrap; padding: 2px 10px; background: var(--amber-bg); border-radius: 4px; }
  /* Search */
  .search-box { padding: 8px 8px 0; }
  .search-input { width: 100%; background: var(--bg); color: var(--text); border: 1px solid var(--border); padding: 8px 12px; border-radius: 6px; font-family: inherit; font-size: 12px; outline: none; transition: border-color 0.15s; }
  .search-input:focus { border-color: var(--accent); }
  .search-input::placeholder { color: var(--dim); }
  mark { background: rgba(245,158,11,0.3); color: var(--text); border-radius: 2px; padding: 0 1px; }
  .no-results { color: var(--muted); text-align: center; padding: 40px 20px; font-size: 12px; }
  .back-btn { cursor: pointer; opacity: 0.4; margin-right: 8px; transition: opacity 0.15s; }
  .back-btn:hover { opacity: 1; }

  /* ===== Sub-tabs (Runs / Deep Dive) ===== */
  .sub-tabs { display: flex; gap: 0; margin-bottom: 20px; border-bottom: 1px solid var(--border); }
  .sub-tab { padding: 8px 18px; cursor: pointer; color: var(--muted); border-bottom: 2px solid transparent; font-size: 13px; font-weight: 500; transition: all 0.1s; }
  .sub-tab.active { color: var(--text); border-bottom-color: var(--accent); }
  .sub-tab:hover { color: var(--text); }

  /* ===== Deep Dive ===== */
  .dd-section { margin-bottom: 24px; }
  .dd-section-title { font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.05em; color: var(--dim); margin-bottom: 10px; }

  .dd-cards { display: flex; gap: 10px; overflow-x: auto; padding-bottom: 4px; }
  .dd-card { background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius); padding: 14px 16px; min-width: 200px; flex-shrink: 0; }
  .dd-card-title { font-weight: 700; font-size: 13px; color: var(--accent2); margin-bottom: 8px; display: flex; align-items: center; gap: 8px; }
  .dd-card-row { display: flex; justify-content: space-between; font-size: 11px; color: var(--text2); padding: 2px 0; }
  .dd-card-row .label { color: var(--muted); }
  .dd-card-row .val { font-weight: 600; font-family: monospace; }
  .dd-card-row .val-cost { color: var(--amber); }
  .dd-card-prompt { font-size: 10px; color: var(--dim); margin-top: 6px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 220px; }

  .dd-grid-wrap { overflow-x: auto; }
  .dd-grid { width: 100%; border-collapse: collapse; font-size: 11px; }
  .dd-grid th { padding: 6px 10px; text-align: left; font-weight: 600; color: var(--accent2); background: var(--surface); border-bottom: 2px solid var(--border); position: sticky; top: 0; font-size: 12px; }
  .dd-grid td { padding: 5px 10px; border-bottom: 1px solid var(--border); font-family: monospace; font-size: 11px; white-space: nowrap; }
  .dd-grid .dd-step-num { color: var(--dim); font-size: 10px; min-width: 28px; text-align: center; }
  .dd-cell-match { color: var(--green); background: rgba(34,197,94,0.08); }
  .dd-cell-diverge { color: var(--red); background: rgba(239,68,68,0.08); }
  .dd-cell-empty { color: var(--border); background: rgba(239,68,68,0.04); }
  .dd-cell-ref { color: var(--text2); }
  .dd-cell-reason { color: var(--green); font-style: italic; font-family: inherit; }
  .dd-cell-tool { color: var(--accent2); }
  .dd-cell-llm { color: var(--amber); font-weight: 600; }

  .dd-reason-cards { display: flex; gap: 10px; overflow-x: auto; }
  .dd-reason-card { background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius); padding: 12px 16px; min-width: 180px; flex-shrink: 0; }

  .dd-tl-tabs { display: flex; gap: 0; border-bottom: 1px solid var(--border); margin-bottom: 12px; }
  .dd-tl-tab { padding: 6px 14px; cursor: pointer; color: var(--muted); border-bottom: 2px solid transparent; font-size: 12px; }
  .dd-tl-tab.active { color: var(--text); border-bottom-color: var(--accent); }
  .dd-tl-tab:hover { color: var(--text); }
  .dd-tl-content { display: none; }
  .dd-tl-content.active { display: block; }

  .dd-output { background: var(--bg); border: 1px solid var(--border); border-radius: var(--radius); padding: 14px; font-size: 12px; line-height: 1.6; white-space: pre-wrap; word-break: break-word; max-height: 300px; overflow-y: auto; color: var(--text2); }
</style>
</head>
<body>
<div class="shell">
  <aside class="sidebar">
    <div class="sidebar-header">
      <h1><span>mimir</span></h1>
      <p>agent observability</p>
    </div>
    <div class="search-box">
      <input class="search-input" type="text" placeholder="Search agents..." oninput="onSearchInput(event)" id="search-input">
    </div>
    <nav class="sidebar-nav">
      <div class="nav-section">Views</div>
      <div class="nav-item active" data-view="agents" onclick="switchView('agents')">Agents</div>
      <div class="nav-item" data-view="divergence" onclick="switchView('divergence')">Divergence</div>
      <div class="nav-section" id="agents-nav-label" style="margin-top:12px">Agents</div>
      <div id="agents-nav"></div>
    </nav>
    <div class="sidebar-stats" id="sidebar-stats"></div>
  </aside>
  <div class="main">
    <div class="main-header">
      <div>
        <h2 id="main-title">Agents</h2>
        <div class="subtitle" id="main-subtitle">Select an agent to view runs</div>
      </div>
      <button class="btn-ghost" onclick="loadAll()">Refresh</button>
    </div>
    <div class="main-body" id="main-body">
      <div class="empty"><h3>No agents tracked yet</h3>Instrument your agent with Mimir and run it.</div>
    </div>
  </div>
</div>

<script>
const API = '';
let _groups = [];
let _currentGroup = null;
let _currentRuns = [];
let _openRuns = new Set();       // indices of expanded run cards
let _openDetails = new Set();    // "runIdx-stepIdx" keys for expanded tool details
let _lastRunCount = 0;           // detect new runs arriving
let _searchQuery = '';
let _searchTimer = null;

function onSearchInput(e) {
  clearTimeout(_searchTimer);
  _searchTimer = setTimeout(() => {
    _searchQuery = e.target.value.trim().toLowerCase();
    if (_currentGroup) renderRunPanel();
    else renderAgentsHome();
    renderAgentsNav();
  }, 250);
}

function clearSearch() {
  _searchQuery = '';
  const el = document.getElementById('search-input');
  if (el) el.value = '';
}

function goBack() { switchView('agents'); }

function highlight(text, query) {
  const escaped = esc(String(text || ''));
  if (!query) return escaped;
  const eq = esc(query);
  if (!eq) return escaped;
  let result = '', lower = escaped.toLowerCase(), ql = eq.toLowerCase(), pos = 0, idx;
  while ((idx = lower.indexOf(ql, pos)) !== -1) {
    result += escaped.slice(pos, idx) + '<mark>' + escaped.slice(idx, idx + ql.length) + '</mark>';
    pos = idx + ql.length;
  }
  return result + escaped.slice(pos);
}

function runMatchesSearch(r, q) {
  if (!q) return true;
  const prompt = ((r.input && r.input.prompt) || '').toLowerCase();
  if (prompt.includes(q)) return true;
  if ((r.status || '').toLowerCase().includes(q)) return true;
  const out = (typeof r.output === 'string' ? r.output : JSON.stringify(r.output || '')).toLowerCase();
  if (out.includes(q)) return true;
  for (const s of (r.steps || [])) {
    if ((s.tool || '').toLowerCase().includes(q)) return true;
    const args = (typeof s.args === 'string' ? s.args : JSON.stringify(s.args || '')).toLowerCase();
    if (args.includes(q)) return true;
    const res = (typeof s.result === 'string' ? s.result : JSON.stringify(s.result || '')).toLowerCase();
    if (res.includes(q)) return true;
    if ((s.text || '').toLowerCase().includes(q)) return true;
    if ((s.error || '').toLowerCase().includes(q)) return true;
  }
  return false;
}

function groupMatchesSearch(g, q) {
  if (!q) return true;
  if ((g.name || '').toLowerCase().includes(q)) return true;
  if ((g.model || '').toLowerCase().includes(q)) return true;
  for (const t of (g.tools || [])) if (t.toLowerCase().includes(q)) return true;
  return false;
}

function switchView(name) {
  clearSearch();
  document.querySelectorAll('.nav-item[data-view]').forEach(n => n.classList.toggle('active', n.dataset.view === name));
  if (name === 'divergence') {
    document.getElementById('main-title').textContent = 'Divergence';
    document.getElementById('main-subtitle').textContent = 'Agents with inconsistent tool patterns across runs';
    loadDivergence();
  } else {
    _currentGroup = null;
    document.getElementById('main-title').textContent = 'Agents';
    document.getElementById('main-subtitle').textContent = _groups.length + ' tracked agents';
    document.getElementById('search-input').placeholder = 'Search agents...';
    renderAgentsNav();
    renderAgentsHome();
  }
}

async function loadAll() {
  try {
    const [overview, groups] = await Promise.all([
      fetch(API + '/api/overview').then(r => r.json()),
      fetch(API + '/api/task-groups').then(r => r.json()),
    ]);
    _groups = groups;
    renderSidebarStats(overview);
    renderAgentsNav();
    // Only render the agents home if no agent is selected yet
    if (!_currentGroup) renderAgentsHome();
  } catch(e) { console.error(e); }
}

function fmtCost(c) { return c >= 1 ? '$' + c.toFixed(2) : '$' + c.toFixed(4); }

function renderSidebarStats(o) {
  document.getElementById('sidebar-stats').innerHTML = `
    <div class="sidebar-stat"><div class="val">${o.total_runs}</div><div class="lbl">Runs</div></div>
    <div class="sidebar-stat"><div class="val">${o.task_groups}</div><div class="lbl">Agents</div></div>
    <div class="sidebar-stat"><div class="val">${o.trajectories}</div><div class="lbl">Traces</div></div>
    <div class="sidebar-stat"><div class="val">${o.total_cost_usd ? fmtCost(o.total_cost_usd) : '$0'}</div><div class="lbl">Total Cost</div></div>`;
}

function renderAgentsHome() {
  const body = document.getElementById('main-body');
  if (!_groups.length) {
    body.innerHTML = '<div class="empty"><h3>No agents tracked yet</h3>Instrument your agent with Mimir and run it.</div>';
    return;
  }
  const q = _searchQuery;
  const filtered = _groups.filter(g => groupMatchesSearch(g, q));
  if (!filtered.length) {
    body.innerHTML = '<div class="no-results">No agents match &ldquo;' + esc(q) + '&rdquo;</div>';
    return;
  }
  body.innerHTML = filtered.map(g => `
    <div class="run-card" style="cursor:pointer;margin-bottom:8px" onclick="loadTaskGroup('${g.task_type_id}')">
      <div class="run-card-header">
        <span class="run-label" style="min-width:auto">${highlight(g.name, q)}</span>
        <div class="run-meta">
          <span>${g.run_count} run${g.run_count!==1?'s':''}</span>
          <span class="sep">|</span>
          <span>${esc(g.model||'unknown')}</span>
          ${g.total_tokens ? `<span class="sep">|</span><span class="mono">${fmtTokens(g.total_tokens)} tokens</span>` : ''}
          ${g.total_cost_usd ? `<span class="sep">|</span><span style="color:var(--amber)">${fmtCost(g.total_cost_usd)}</span>` : ''}
          <span>${highlight(g.model||'unknown', q)}</span>
          <span class="sep">|</span>
          ${(g.tools||[]).map(t => `<span class="badge badge-tool">${highlight(t, q)}</span>`).join(' ')}
        </div>
        <span class="run-chevron">&#9654;</span>
      </div>
    </div>
  `).join('');
}

function renderAgentsNav() {
  const el = document.getElementById('agents-nav');
  if (!_groups.length) { el.innerHTML = ''; return; }
  const q = _currentGroup ? '' : _searchQuery;
  const filtered = _groups.filter(g => groupMatchesSearch(g, q));
  el.innerHTML = filtered.map(g => `
    <div class="nav-item ${_currentGroup && _currentGroup.task_type_id === g.task_type_id ? 'active' : ''}" onclick="loadTaskGroup('${g.task_type_id}')">
      <div class="dot" style="background:${g.run_count ? 'var(--accent)' : 'var(--dim)'}"></div>
      ${highlight(g.name, q)}
      <span class="count">${g.run_count}</span>
    </div>
  `).join('');
}

async function loadTaskGroup(tid) {
  clearSearch();
  document.getElementById('search-input').placeholder = 'Search runs...';
  const data = await fetch(API + '/api/task-group/' + tid).then(r => r.json());
  _currentGroup = data;
  _currentRuns = (data.runs || []);
  _currentRuns.sort((a, b) => (a.started_at || 0) - (b.started_at || 0));
  // Reset UI state when switching agents
  _openRuns.clear();
  _openDetails.clear();
  _lastRunCount = _currentRuns.length;
  renderAgentsNav();
  renderRunPanel();
}

function renderRunPanel() {
  const g = _currentGroup;
  const runs = _currentRuns;
  const q = _searchQuery;
  const matched = new Set();
  runs.forEach((r, i) => { if (runMatchesSearch(r, q)) matched.add(i); });
  document.getElementById('main-title').innerHTML = '<span class="back-btn" onclick="goBack()">&larr;</span>' + esc(g.name);
  const toolsHtml = (g.tools||[]).map(t => `<span class="badge badge-tool">${esc(t)}</span>`).join(' ');
  const countLabel = q ? matched.size + '/' + runs.length + ' runs' : runs.length + ' runs';
  document.getElementById('main-subtitle').innerHTML = `${countLabel} &middot; ${esc(g.model||'unknown')} &middot; ${toolsHtml}`;

  // Sub-tabs: Runs vs Deep Dive
  const activeSubTab = window._activeSubTab || 'runs';
  let html = `<div class="sub-tabs">
    <div class="sub-tab ${activeSubTab==='runs'?'active':''}" onclick="window._activeSubTab='runs';renderRunPanel()">Runs</div>
    ${runs.length >= 2 ? `<div class="sub-tab ${activeSubTab==='deepdive'?'active':''}" onclick="window._activeSubTab='deepdive';renderRunPanel()">Deep Dive</div>` : ''}
  </div>`;

  if (activeSubTab === 'deepdive' && runs.length >= 2) {
    html += renderDeepDive(runs, g);
    document.getElementById('main-body').innerHTML = html;
    return;
  }

  // Diff bar
  if (runs.length >= 2) {
    html += `<div class="diff-bar">
      <span style="color:var(--muted);font-size:12px">Compare</span>
      <select id="diff-a">${runs.map((r,i) => `<option value="${i}">Run #${i+1}</option>`).join('')}</select>
      <span style="color:var(--dim)">vs</span>
      <select id="diff-b">${runs.map((r,i) => `<option value="${i}" ${i===Math.min(1,runs.length-1)?'selected':''}>Run #${i+1}</option>`).join('')}</select>
      <button class="diff-btn" onclick="diffRuns()">Compare runs</button>
    </div>
    <div id="diff-result"></div>`;
  }

  // Run list
  html += '<div class="run-list">';
  runs.forEach((r, idx) => {
    if (!matched.has(idx)) return;
    const num = idx + 1;
    const prompt = (r.input && r.input.prompt) ? r.input.prompt : '';
    const toolSteps = (r.steps||[]).filter(s => s.type === 'tool' || s.type === 'tool_error');
    const reasonSteps = (r.steps||[]).filter(s => s.type === 'reasoning');
    const inTok = (r.usage||{}).input_tokens || 0;
    const outTok = (r.usage||{}).output_tokens || 0;

    html += `<div class="run-card ${_openRuns.has(idx)?'open':''}" id="run-card-${idx}">
      <div class="run-card-header" onclick="toggleRun(${idx})">
        <span class="run-label">Run #${num}</span>
        <span class="run-prompt">${highlight(prompt, q)}</span>
        <div class="run-meta">
          <span class="badge badge-${r.status === 'success' ? 'success' : 'error'}">${r.status}</span>
          <span class="sep">|</span>
          <span>${toolSteps.length} tools</span>
          <span class="sep">|</span>
          <span>${reasonSteps.length} reasoning</span>
          <span class="sep">|</span>
          <span class="mono">${fmtTokens(inTok)} in / ${fmtTokens(outTok)} out</span>
          <span class="sep">|</span>
          <span>${r.duration_s ? r.duration_s.toFixed(1) + 's' : '?'}</span>
          ${r.cost_usd ? `<span class="sep">|</span><span style="color:var(--amber)">${fmtCost(r.cost_usd)}</span>` : ''}
        </div>
        <span class="run-chevron">&#9654;</span>
      </div>
      <div class="run-body">
        <div class="run-section">
          <div class="run-section-title">Input</div>
          <div class="run-io">${prompt ? highlight(prompt, q) : '<span style="color:var(--dim)">No input recorded</span>'}</div>
        </div>
        <div class="run-section">
          <div class="run-section-title">Timeline &mdash; ${(r.steps||[]).filter(s => s.type !== 'reasoning').length} steps</div>
          ${renderToolWaterfall(r.steps || [])}
          <div class="timeline">${renderTimeline(idx, r.steps || [])}</div>
        </div>
        <div class="run-section">
          <div class="run-section-title">Output</div>
          <div class="run-output">${getRunOutput(r, q)}</div>
        </div>
        <div class="run-footer">
          <span class="badge badge-${r.status === 'success' ? 'success' : r.status === 'error' ? 'error' : 'outline'}">${r.status || 'unknown'}</span>
          <span>${r.duration_s ? 'Completed in ' + r.duration_s.toFixed(1) + 's' : ''}</span>
          <span class="mono">${fmtTokens(inTok)} in / ${fmtTokens(outTok)} out (${fmtTokens(inTok + outTok)} total)</span>
          ${r.cost_usd ? `<span style="color:var(--amber);font-weight:600">${fmtCost(r.cost_usd)}</span>` : '<span style="color:var(--dim)">cost: n/a</span>'}
        </div>
      </div>
    </div>`;
  });
  html += '</div>';
  if (q && !matched.size) html = '<div class="no-results">No runs match &ldquo;' + esc(q) + '&rdquo;</div>';

  document.getElementById('main-body').innerHTML = html;
}

// ============================================================
// Deep Dive — multi-run comparison view
// ============================================================

function renderDeepDive(runs, group) {
  let h = '';

  // --- Section 1: Run summary cards ---
  h += '<div class="dd-section"><div class="dd-section-title">Run Overview</div><div class="dd-cards">';
  runs.forEach((r, i) => {
    const toolSteps = (r.steps||[]).filter(s => s.type === 'tool' || s.type === 'tool_error');
    const reasonSteps = (r.steps||[]).filter(s => s.type === 'reasoning' && !isNoise(s));
    const llmSteps = (r.steps||[]).filter(s => s.type === 'llm_call');
    const inTok = (r.usage||{}).input_tokens || 0;
    const outTok = (r.usage||{}).output_tokens || 0;
    const prompt = (r.input && r.input.prompt) || '';
    h += `<div class="dd-card">
      <div class="dd-card-title">Run #${i+1} <span class="badge badge-${r.status==='success'?'success':'error'}" style="font-size:9px">${r.status}</span></div>
      <div class="dd-card-row"><span class="label">Tools</span><span class="val">${toolSteps.length}</span></div>
      <div class="dd-card-row"><span class="label">Reasoning</span><span class="val">${reasonSteps.length}</span></div>
      <div class="dd-card-row"><span class="label">LLM calls</span><span class="val">${llmSteps.length}</span></div>
      <div class="dd-card-row"><span class="label">Tokens</span><span class="val">${fmtTokens(inTok+outTok)}</span></div>
      <div class="dd-card-row"><span class="label">Duration</span><span class="val">${r.duration_s ? r.duration_s.toFixed(1)+'s' : '?'}</span></div>
      ${r.cost_usd ? `<div class="dd-card-row"><span class="label">Cost</span><span class="val val-cost">${fmtCost(r.cost_usd)}</span></div>` : ''}
      <div class="dd-card-prompt" title="${esc(prompt)}">${esc(prompt.slice(0,60))}</div>
    </div>`;
  });
  h += '</div></div>';

  // --- Section 2: Step comparison grid ---
  h += '<div class="dd-section"><div class="dd-section-title">Step Comparison Across Runs</div>';
  h += buildStepGrid(runs);
  h += '</div>';

  // --- Section 3: Reasoning overview ---
  h += '<div class="dd-section"><div class="dd-section-title">Reasoning Overview</div><div class="dd-reason-cards">';
  runs.forEach((r, i) => {
    const reasons = (r.steps||[]).filter(s => s.type === 'reasoning' && !isNoise(s));
    const llms = (r.steps||[]).filter(s => s.type === 'llm_call');
    const reasonTokens = llms.reduce((sum, s) => sum + (s.output_tokens||0), 0);
    h += `<div class="dd-reason-card">
      <div class="dd-card-title">Run #${i+1}</div>
      <div class="dd-card-row"><span class="label">Blocks</span><span class="val">${reasons.length}</span></div>
      <div class="dd-card-row"><span class="label">Output tokens</span><span class="val">${fmtTokens(reasonTokens)}</span></div>
      ${r.cost_usd ? `<div class="dd-card-row"><span class="label">Cost</span><span class="val val-cost">${fmtCost(r.cost_usd)}</span></div>` : ''}
    </div>`;
  });
  h += '</div></div>';

  // --- Section 4: Full trajectory timeline (tabbed) ---
  h += '<div class="dd-section"><div class="dd-section-title">Full Trajectory Timeline</div>';
  h += '<div class="dd-tl-tabs">';
  runs.forEach((r, i) => {
    h += `<div class="dd-tl-tab ${i===0?'active':''}" onclick="switchDDTab(${i})" data-ddt="${i}">Run #${i+1}</div>`;
  });
  h += '</div>';
  runs.forEach((r, i) => {
    h += `<div class="dd-tl-content ${i===0?'active':''}" id="dd-tl-${i}">
      <div class="timeline">${renderTimeline(1000+i, r.steps || [])}</div>
    </div>`;
  });
  h += '</div>';

  // --- Section 5: Output ---
  h += '<div class="dd-section"><div class="dd-section-title">Agent Output</div>';
  h += '<div class="dd-tl-tabs">';
  runs.forEach((r, i) => {
    h += `<div class="dd-tl-tab ${i===0?'active':''}" onclick="switchDDOutTab(${i})" data-ddo="${i}">Run #${i+1}</div>`;
  });
  h += '</div>';
  runs.forEach((r, i) => {
    h += `<div class="dd-tl-content ${i===0?'active':''}" id="dd-out-${i}">
      <div class="dd-output">${getRunOutput(r, '')}</div>
    </div>`;
  });
  h += '</div>';

  return h;
}

function buildStepGrid(runs) {
  // Extract tool steps per run (filter out noise reasoning and llm_call)
  const runTools = runs.map(r => (r.steps||[]).filter(s => s.type === 'tool' || s.type === 'tool_error'));

  // Use Run #1 as reference, align others via weighted LCS
  const ref = runTools[0] || [];
  const alignments = [ref.map((s, i) => i)]; // Run 1: identity mapping

  for (let r = 1; r < runTools.length; r++) {
    const other = runTools[r];
    // Build indexed versions for weightedLCS
    const refIndexed = ref.map((s, i) => ({step: s, idx: i}));
    const otherIndexed = other.map((s, i) => ({step: s, idx: i}));
    const matches = weightedLCS(refIndexed, otherIndexed);
    // Build mapping: refIdx -> otherIdx (or -1 for unmatched)
    const map = new Array(ref.length).fill(-1);
    const matchedOther = new Set();
    matches.forEach(m => { map[m.oA] = m.oB; matchedOther.add(m.oB); });
    // Collect unmatched steps from this run
    const unmatched = other.map((s, i) => i).filter(i => !matchedOther.has(i));
    alignments.push({map, unmatched, steps: other});
  }

  // Build grid rows
  const maxRows = Math.max(ref.length, ...runTools.map(t => t.length));
  let grid = '<div class="dd-grid-wrap"><table class="dd-grid"><thead><tr><th class="dd-step-num">#</th>';
  runs.forEach((_, i) => grid += `<th>Run #${i+1}</th>`);
  grid += '</tr></thead><tbody>';

  // Main rows aligned to reference
  for (let row = 0; row < ref.length; row++) {
    // Check consensus: do all runs have the same tool at this step?
    const refTool = ref[row].tool;
    let allMatch = true;
    for (let r = 1; r < runs.length; r++) {
      const otherIdx = alignments[r].map[row];
      if (otherIdx < 0 || alignments[r].steps[otherIdx].tool !== refTool) { allMatch = false; break; }
    }

    grid += `<tr><td class="dd-step-num">${row+1}</td>`;
    // Run 1 (reference) — green if consensus, neutral otherwise
    grid += `<td class="${allMatch ? 'dd-cell-match' : 'dd-cell-ref'}">${esc(refTool)}</td>`;
    // Other runs
    for (let r = 1; r < runs.length; r++) {
      const a = alignments[r];
      const otherIdx = a.map[row];
      if (otherIdx >= 0) {
        const otherTool = a.steps[otherIdx].tool;
        const same = otherTool === refTool;
        grid += `<td class="${same ? 'dd-cell-match' : 'dd-cell-diverge'}">${esc(otherTool)}</td>`;
      } else {
        grid += `<td class="dd-cell-empty">&mdash;</td>`;
      }
    }
    grid += '</tr>';
  }

  // Extra rows for unmatched steps in other runs (additions not in reference)
  for (let r = 1; r < runs.length; r++) {
    const a = alignments[r];
    if (a.unmatched && a.unmatched.length) {
      a.unmatched.forEach(idx => {
        grid += `<tr><td class="dd-step-num" style="color:var(--red)">+</td>`;
        for (let c = 0; c < runs.length; c++) {
          if (c === r) {
            grid += `<td class="dd-cell-diverge">${esc(a.steps[idx].tool)}</td>`;
          } else {
            grid += `<td class="dd-cell-empty">&mdash;</td>`;
          }
        }
        grid += '</tr>';
      });
    }
  }

  grid += '</tbody></table></div>';
  return grid;
}

function switchDDTab(idx) {
  document.querySelectorAll('.dd-tl-tab[data-ddt]').forEach(t => t.classList.toggle('active', parseInt(t.dataset.ddt) === idx));
  document.querySelectorAll('.dd-tl-content[id^="dd-tl-"]').forEach(c => c.classList.toggle('active', c.id === 'dd-tl-' + idx));
}

function switchDDOutTab(idx) {
  document.querySelectorAll('.dd-tl-tab[data-ddo]').forEach(t => t.classList.toggle('active', parseInt(t.dataset.ddo) === idx));
  document.querySelectorAll('.dd-tl-content[id^="dd-out-"]').forEach(c => c.classList.toggle('active', c.id === 'dd-out-' + idx));
}

function renderToolWaterfall(steps) {
  const allSteps = (steps || []);
  const items = allSteps.filter(s =>
    s.type === 'tool' || s.type === 'tool_error' || s.type === 'llm_call'
  );
  if (!items.length) return '';
  const total = items.reduce((sum, s) => sum + (s.duration_ms || 0), 0);
  if (!total) return '';

  // Count reasoning steps associated with each llm_call (appear after it in allSteps)
  const reasoningMap = new Map(); // index in items -> [reasoning steps]
  let lastLlmIdx = -1;
  const itemSet = new Set(items);
  for (const s of allSteps) {
    if (itemSet.has(s)) {
      lastLlmIdx = s.type === 'llm_call' ? items.indexOf(s) : -1;
    } else if (s.type === 'reasoning' && lastLlmIdx >= 0) {
      if (!reasoningMap.has(lastLlmIdx)) reasoningMap.set(lastLlmIdx, []);
      reasoningMap.get(lastLlmIdx).push(s);
    }
  }

  // Total step count including reasoning
  const reasoningCount = allSteps.filter(s => s.type === 'reasoning').length;
  const totalStepCount = items.length + reasoningCount;

  // Pre-compute cumulative cost & tokens for sparkline + tooltips
  const totalCost = items.reduce((s, x) => s + (x.cost_usd || 0), 0);
  let cumulCost = 0, cumulTok = 0;
  const enriched = items.map(s => {
    cumulCost += (s.cost_usd || 0);
    cumulTok  += (s.input_tokens || 0) + (s.output_tokens || 0);
    return { s, cumulCost, cumulTok };
  });

  let cumul = 0;
  const rows = enriched.map(({s, cumulCost: cc, cumulTok: ct}, i) => {
    const dur = s.duration_ms || 0;
    const left = (cumul / total) * 100;
    const width = (dur / total) * 100;
    cumul += dur;
    const isError = s.type === 'tool_error';
    const isLlm = s.type === 'llm_call';
    const label = isLlm ? ('LLM' + (s.model ? ' · ' + s.model : '')) : (s.tool || 'unknown');
    const status = isError ? 'error' : 'success';
    const pct = ((dur / total) * 100).toFixed(1);

    // For LLM bars: compute green reasoning portion based on output/total token ratio
    const rSteps = reasoningMap.get(i) || [];
    const rCount = rSteps.length;
    let barHtml = '';
    if (isLlm && rCount > 0 && (s.input_tokens || s.output_tokens)) {
      const outTok = s.output_tokens || 0;
      const inTok = s.input_tokens || 0;
      const reasonPct = (outTok / (inTok + outTok)) * 100;
      const llmPct = 100 - reasonPct;
      barHtml = `<div class="wf-bar wf-llm" style="left:${left}%;width:${width}%;padding:0;overflow:hidden">`
        + `<div style="width:${llmPct}%;height:100%;background:var(--amber);display:inline-block"></div>`
        + `<div style="width:${reasonPct}%;height:100%;background:var(--green);display:inline-block"></div>`
        + `</div>`;
    } else {
      let cls = 'wf-bar';
      if (isError) cls += ' wf-error';
      else if (isLlm) cls += ' wf-llm';
      barHtml = `<div class="${cls}" style="left:${left}%;width:${width}%"></div>`;
    }

    // Rich tooltip
    const tipParts = [`<div class="wf-tip-title">${esc(label)}</div>`];
    tipParts.push(`<div class="wf-tip-row"><span class="wf-tip-lbl">step</span><span class="wf-tip-val">${i+1} / ${items.length}</span></div>`);
    tipParts.push(`<div class="wf-tip-row"><span class="wf-tip-lbl">status</span><span class="wf-tip-val">${status}</span></div>`);
    tipParts.push(`<div class="wf-tip-row"><span class="wf-tip-lbl">duration</span><span class="wf-tip-val">${dur.toFixed(0)}ms (${pct}%)</span></div>`);
    if (isLlm) {
      tipParts.push(`<div class="wf-tip-sep"></div>`);
      if (s.input_tokens || s.output_tokens) {
        tipParts.push(`<div class="wf-tip-row"><span class="wf-tip-lbl">tokens in</span><span class="wf-tip-val">${fmtTokens(s.input_tokens||0)}</span></div>`);
        tipParts.push(`<div class="wf-tip-row"><span class="wf-tip-lbl">tokens out</span><span class="wf-tip-val">${fmtTokens(s.output_tokens||0)}</span></div>`);
      }
      if (s.cost_usd != null) {
        tipParts.push(`<div class="wf-tip-row"><span class="wf-tip-lbl">cost</span><span class="wf-tip-val amber">${fmtCost(s.cost_usd)}</span></div>`);
      }
      if (rCount > 0) {
        tipParts.push(`<div class="wf-tip-row"><span class="wf-tip-lbl">reasoning</span><span class="wf-tip-val" style="color:var(--green)">${rCount} step${rCount>1?'s':''}</span></div>`);
      }
    }
    tipParts.push(`<div class="wf-tip-sep"></div>`);
    tipParts.push(`<div class="wf-tip-row"><span class="wf-tip-lbl">cumul tokens</span><span class="wf-tip-val">${fmtTokens(ct)}</span></div>`);
    if (totalCost > 0) {
      tipParts.push(`<div class="wf-tip-row"><span class="wf-tip-lbl">cumul cost</span><span class="wf-tip-val amber">${fmtCost(cc)}</span></div>`);
    }

    const tipLeft = left + width / 2;
    return `<div class="wf-row">${barHtml}`
      + `<div class="wf-tip" style="left:${tipLeft}%">${tipParts.join('')}</div></div>`;
  }).join('');

  // Color key
  const key = `<div class="wf-key">`
    + `<span><span class="wf-key-dot" style="background:var(--amber)"></span>LLM</span>`
    + `<span><span class="wf-key-dot" style="background:var(--green)"></span>Reasoning</span>`
    + `<span><span class="wf-key-dot" style="background:var(--accent)"></span>Tool</span>`
    + `<span><span class="wf-key-dot" style="background:var(--red)"></span>Error</span>`
    + `</div>`;

  // Sparkline — cumulative cost (fallback to cumulative tokens) over step index
  const useCost = totalCost > 0;
  const seriesMax = useCost ? totalCost : (enriched[enriched.length-1].cumulTok || 1);
  const n = enriched.length;
  const pts = enriched.map(({cumulCost: cc, cumulTok: ct}, i) => {
    const x = n === 1 ? 100 : (i / (n - 1)) * 100;
    const v = useCost ? cc : ct;
    const y = 100 - (v / seriesMax) * 100;
    return `${x.toFixed(2)},${y.toFixed(2)}`;
  });
  const path = pts.join(' L');
  const area = `M0,100 L${path} L100,100 Z`;
  const line = `M${path}`;
  const endLabel = useCost ? fmtCost(totalCost) : fmtTokens(seriesMax) + ' tok';
  const sparkLabel = useCost ? 'cumulative cost' : 'cumulative tokens';
  const spark = `<div class="wf-spark">`
    + `<div class="wf-spark-label">${sparkLabel}</div>`
    + `<div class="wf-spark-end">${endLabel}</div>`
    + `<svg viewBox="0 0 100 100" preserveAspectRatio="none">`
    + `<path d="${area}" fill="var(--amber)" fill-opacity="0.12" stroke="none"/>`
    + `<path d="${line}" fill="none" stroke="var(--amber)" stroke-width="1.2" vector-effect="non-scaling-stroke"/>`
    + `</svg></div>`;

  // Duration axis — straight line with start, label, and end
  const durLine = `<div class="wf-axis"><span>0:00s</span><span style="color:var(--muted);font-size:9px;text-transform:uppercase;letter-spacing:0.05em">Duration</span><span>${fmtWfDur(total)}</span></div>`;

  return `<div class="waterfall" style="padding-bottom:18px;position:relative">${key}${spark}${rows}${durLine}</div>`;
}

function fmtWfDur(ms) {
  if (!ms) return '0:00s';
  const s = ms / 1000;
  const m = Math.floor(s / 60);
  const rs = s - m * 60;
  return `${m}:${rs.toFixed(2).padStart(5, '0')}s`;
}

function renderTimeline(runIdx, steps) {
  return steps.map((s, i) => {
    const key = runIdx + '-' + i;
    const isOpen = _openDetails.has(key);
    if (s.type === 'tool') {
      const argsStr = typeof s.args === 'string' ? s.args : JSON.stringify(s.args || '', null, 2);
      const resultStr = typeof s.result === 'string' ? s.result : JSON.stringify(s.result || '', null, 2);
      const q = _searchQuery;
      const detailMatch = q && (argsStr.toLowerCase().includes(q) || resultStr.toLowerCase().includes(q));
      const show = isOpen || detailMatch;
      return `<div class="tl-step tl-tool">
        <div class="tl-head">
          <span class="tl-name">${highlight(s.tool, _searchQuery)}</span>
          <span class="tl-dur">${s.duration_ms ? s.duration_ms.toFixed(0) + 'ms' : ''}</span>
          <span class="tl-toggle" onclick="toggleDetail(${runIdx},${i})">${show?'hide':'details'}</span>
        </div>
        <div class="tl-detail" id="tl-detail-${key}" style="display:${show?'block':'none'}">
          <div style="color:var(--dim);font-size:10px;margin-bottom:2px">ARGS</div>
          <div class="tl-args mono">${highlight(argsStr, _searchQuery)}</div>
          <div style="color:var(--dim);font-size:10px;margin-top:6px;margin-bottom:2px">RESULT</div>
          <div class="tl-result">${highlight(resultStr, _searchQuery)}</div>
        </div>
      </div>`;
    }
    if (s.type === 'tool_error') {
      return `<div class="tl-step tl-tool-error">
        <div class="tl-head">
          <span class="tl-name">${highlight(s.tool, _searchQuery)} &mdash; ERROR</span>
          <span class="tl-dur">${s.duration_ms ? s.duration_ms.toFixed(0) + 'ms' : ''}</span>
        </div>
        <div class="tl-detail"><div class="tl-args" style="border-left:2px solid var(--red)">${highlight(s.error || '', _searchQuery)}</div></div>
      </div>`;
    }
    if (s.type === 'reasoning') {
      const text = s.text || '';
      const isShort = text.length < 120;
      const isAgentEvent = text.startsWith('[agent ') || text.startsWith('[handoff') || text.startsWith('[subagent');
      if (isAgentEvent) {
        return `<div class="tl-step tl-reasoning">
          <div class="tl-head"><span class="tl-name">${esc(text)}</span></div>
        </div>`;
      }
      return `<div class="tl-step tl-reasoning">
        <div class="tl-head">
          <span class="tl-name">reasoning${s.tokens ? ' (' + s.tokens + ' tokens)' : ''}</span>
          ${!isShort ? `<span class="tl-toggle" onclick="toggleDetail(${runIdx},${i})">${isOpen?'collapse':'expand'}</span>` : ''}
        </div>
        ${isShort
          ? `<div class="tl-reasoning-text">${esc(text)}</div>`
          : `<div class="tl-reasoning-text" id="tl-detail-${key}" data-mode="maxheight" style="max-height:${isOpen?'none':'60px'};overflow-y:${isOpen?'auto':'hidden'};cursor:pointer" onclick="toggleDetail(${runIdx},${i})">${esc(text)}</div>`
        }
      </div>`;
    }
    if (s.type === 'llm_call') {
      const inTok = s.input_tokens || 0;
      const outTok = s.output_tokens || 0;
      const cost = s.cost_usd;
      const dur = s.duration_ms ? (s.duration_ms/1000).toFixed(1) + 's' : '';
      return `<div class="tl-step" style="border-left:2px solid var(--amber);padding:4px 0 4px 16px">
        <div class="tl-head" style="font-size:11px">
          <span style="color:var(--amber);font-weight:600">LLM call</span>
          <span class="mono" style="color:var(--muted);font-size:10px">${s.model||''}</span>
          <span class="mono" style="font-size:10px">${fmtTokens(inTok)} in / ${fmtTokens(outTok)} out</span>
          ${cost ? `<span style="color:var(--amber);font-size:10px;font-weight:600">${fmtCost(cost)}</span>` : ''}
          ${dur ? `<span class="tl-dur">${dur}</span>` : ''}
        </div>
      </div>`;
    }
    return '';
  }).join('');
}

function toggleDetail(runIdx, stepIdx) {
  const key = runIdx + '-' + stepIdx;
  const el = document.getElementById('tl-detail-' + key);
  if (!el) return;
  const wasOpen = _openDetails.has(key);
  if (wasOpen) {
    _openDetails.delete(key);
    // Handle both display-toggle (tool details) and max-height (reasoning)
    if (el.dataset.mode === 'maxheight') { el.style.maxHeight = '60px'; }
    else { el.style.display = 'none'; }
  } else {
    _openDetails.add(key);
    if (el.dataset.mode === 'maxheight') { el.style.maxHeight = 'none'; }
    else { el.style.display = 'block'; }
  }
  const toggle = el.parentElement.querySelector('.tl-toggle');
  if (toggle) toggle.textContent = wasOpen ? 'details' : 'hide';
}

function toggleRun(idx) {
  const card = document.getElementById('run-card-' + idx);
  if (!card) return;
  if (_openRuns.has(idx)) { _openRuns.delete(idx); card.classList.remove('open'); }
  else { _openRuns.add(idx); card.classList.add('open'); }
}

// ============================================================
// Behavioral comparison — utilities
// ============================================================
let _openCmpDetails = new Set();

function normArgs(a) {
  if (!a) return {};
  if (typeof a === 'object' && !Array.isArray(a)) return a;
  if (typeof a === 'string') { try { const p = JSON.parse(a); return typeof p === 'object' && p ? p : {_raw: a}; } catch(e) { return {_raw: a}; } }
  return {_raw: String(a)};
}

function jaccard(a, b) {
  const ka = Object.keys(a), kb = Object.keys(b);
  if (!ka.length && !kb.length) return 1;
  const setA = new Set(ka), setB = new Set(kb);
  let inter = 0; for (const k of setA) if (setB.has(k)) inter++;
  return inter / (setA.size + setB.size - inter);
}

function isNoise(s) {
  if (s.type !== 'reasoning') return false;
  const t = (s.text || '').trim();
  return !t || t.length < 5 || t.charAt(0)==='[' && (/stop_reason|^.agent (started|completed)|^.handoff|^.subagent/.test(t));
}

function trigramSim(a, b) {
  if (!a || !b) return 0;
  a = a.slice(0, 500).toLowerCase(); b = b.slice(0, 500).toLowerCase();
  const tg = s => { const t = new Set(); for (let i = 0; i < s.length - 2; i++) t.add(s.slice(i, i+3)); return t; };
  const ta = tg(a), tb = tg(b);
  if (!ta.size && !tb.size) return 1;
  let inter = 0; for (const x of ta) if (tb.has(x)) inter++;
  return inter / (ta.size + tb.size - inter);
}

function stepLabel(s) {
  if (!s) return '';
  if (s.type === 'tool' || s.type === 'tool_error') return s.tool || 'unknown';
  if (s.type === 'reasoning') return (s.text || '').slice(0, 60).replace(/\\n/g, ' ');
  return s.type;
}

// ============================================================
// Behavioral comparison — matching algorithm
// ============================================================

function toolSim(a, b, ia, ib, na, nb) {
  let sc = 0;
  if (a.tool === b.tool) sc += 40; // name match
  sc += 35 * jaccard(normArgs(a.args), normArgs(b.args)); // args overlap
  sc += 15 * (1 - Math.abs((ia/Math.max(na,1)) - (ib/Math.max(nb,1)))); // position
  if (a.type === b.type) sc += 10; // type match
  return sc / 100;
}

function weightedLCS(toolsA, toolsB) {
  const m = toolsA.length, n = toolsB.length;
  const dp = Array.from({length: m+1}, () => Array(n+1).fill(0));
  const sim = Array.from({length: m}, () => Array(n).fill(0));
  for (let i = 0; i < m; i++) for (let j = 0; j < n; j++) sim[i][j] = toolSim(toolsA[i].step, toolsB[j].step, i, j, m, n);
  for (let i = 1; i <= m; i++)
    for (let j = 1; j <= n; j++) {
      const s = sim[i-1][j-1];
      dp[i][j] = s >= 0.3 ? Math.max(dp[i-1][j-1] + s, dp[i-1][j], dp[i][j-1]) : Math.max(dp[i-1][j], dp[i][j-1]);
    }
  const matches = [];
  let i = m, j = n;
  while (i > 0 && j > 0) {
    const s = sim[i-1][j-1];
    if (s >= 0.3 && dp[i][j] === dp[i-1][j-1] + s) { matches.unshift({iA: toolsA[i-1].idx, iB: toolsB[j-1].idx, oA: i-1, oB: j-1, sim: s}); i--; j--; }
    else if (dp[i-1][j] >= dp[i][j-1]) i--;
    else j--;
  }
  return matches;
}

function buildAlignment(stepsA, stepsB) {
  // Extract tool steps with original indices
  const toolsA = [], toolsB = [];
  stepsA.forEach((s, i) => { if (s.type === 'tool' || s.type === 'tool_error') toolsA.push({step: s, idx: i}); });
  stepsB.forEach((s, i) => { if (s.type === 'tool' || s.type === 'tool_error') toolsB.push({step: s, idx: i}); });

  const toolMatches = weightedLCS(toolsA, toolsB);
  const matchedA = new Set(toolMatches.map(m => m.iA));
  const matchedB = new Set(toolMatches.map(m => m.iB));

  // Build anchor boundaries for reasoning pairing
  const anchors = [{endA: 0, endB: 0}]; // before first match
  toolMatches.forEach(m => anchors.push({endA: m.iA + 1, endB: m.iB + 1}));

  const alignment = [];
  let ptrA = 0, ptrB = 0;

  for (const match of toolMatches) {
    // Emit unmatched steps before this anchor
    const preA = [], preB = [];
    while (ptrA < match.iA) {
      if (!matchedA.has(ptrA)) preA.push(stepsA[ptrA]);
      ptrA++;
    }
    while (ptrB < match.iB) {
      if (!matchedB.has(ptrB)) preB.push(stepsB[ptrB]);
      ptrB++;
    }
    // Pair reasoning in this segment
    const rA = preA.filter(s => s.type === 'reasoning' && !isNoise(s));
    const rB = preB.filter(s => s.type === 'reasoning' && !isNoise(s));
    const tA = preA.filter(s => s.type !== 'reasoning');
    const tB = preB.filter(s => s.type !== 'reasoning');
    // Emit unmatched tools
    tA.forEach(s => alignment.push({type: 'onlyA', stepA: s, stepB: null, cat: 'tool', sim: 0}));
    tB.forEach(s => alignment.push({type: 'onlyB', stepA: null, stepB: s, cat: 'tool', sim: 0}));
    // Pair reasoning sequentially
    const rMax = Math.max(rA.length, rB.length);
    for (let k = 0; k < rMax; k++) {
      if (k < rA.length && k < rB.length) alignment.push({type: 'matched', stepA: rA[k], stepB: rB[k], cat: 'reasoning', sim: trigramSim(rA[k].text, rB[k].text)});
      else if (k < rA.length) alignment.push({type: 'onlyA', stepA: rA[k], stepB: null, cat: 'reasoning', sim: 0});
      else alignment.push({type: 'onlyB', stepA: null, stepB: rB[k], cat: 'reasoning', sim: 0});
    }
    // Emit the matched tool
    alignment.push({type: 'matched', stepA: stepsA[match.iA], stepB: stepsB[match.iB], cat: 'tool', sim: match.sim});
    ptrA = match.iA + 1;
    ptrB = match.iB + 1;
  }

  // Remaining steps after last match
  const tailA = [], tailB = [];
  while (ptrA < stepsA.length) { if (!matchedA.has(ptrA)) tailA.push(stepsA[ptrA]); ptrA++; }
  while (ptrB < stepsB.length) { if (!matchedB.has(ptrB)) tailB.push(stepsB[ptrB]); ptrB++; }
  const trA = tailA.filter(s => s.type === 'reasoning' && !isNoise(s));
  const trB = tailB.filter(s => s.type === 'reasoning' && !isNoise(s));
  tailA.filter(s => s.type !== 'reasoning').forEach(s => alignment.push({type: 'onlyA', stepA: s, stepB: null, cat: 'tool', sim: 0}));
  tailB.filter(s => s.type !== 'reasoning').forEach(s => alignment.push({type: 'onlyB', stepA: null, stepB: s, cat: 'tool', sim: 0}));
  const trMax = Math.max(trA.length, trB.length);
  for (let k = 0; k < trMax; k++) {
    if (k < trA.length && k < trB.length) alignment.push({type: 'matched', stepA: trA[k], stepB: trB[k], cat: 'reasoning', sim: trigramSim(trA[k].text, trB[k].text)});
    else if (k < trA.length) alignment.push({type: 'onlyA', stepA: trA[k], stepB: null, cat: 'reasoning', sim: 0});
    else alignment.push({type: 'onlyB', stepA: null, stepB: trB[k], cat: 'reasoning', sim: 0});
  }

  const stats = {
    matched: alignment.filter(e => e.type === 'matched').length,
    matchedTools: alignment.filter(e => e.type === 'matched' && e.cat === 'tool').length,
    matchedReasoning: alignment.filter(e => e.type === 'matched' && e.cat === 'reasoning').length,
    onlyA: alignment.filter(e => e.type === 'onlyA').length,
    onlyB: alignment.filter(e => e.type === 'onlyB').length,
  };
  return {alignment, stats};
}

// ============================================================
// Behavioral comparison — divergence detection
// ============================================================

function detectDivergence(alignment) {
  let matchStreak = 0;
  for (let i = 0; i < alignment.length; i++) {
    const e = alignment[i];
    if (e.type === 'matched' && e.cat === 'tool' && e.sim >= 0.6) { matchStreak++; continue; }
    if (e.cat !== 'tool') continue; // skip reasoning for divergence detection

    // Found a tool-level divergence
    const prev = alignment.slice(0, i).reverse().find(x => x.type === 'matched' && x.cat === 'tool');
    const afterName = prev ? (prev.stepA.tool || prev.stepB.tool) : 'start';

    if (e.type === 'matched' && e.sim < 0.6) {
      return {index: i, step: i + 1, type: 'args_drift',
        desc: `${e.stepA.tool} matched by name but args diverged significantly after ${afterName}`};
    }
    if (e.type === 'onlyA') {
      const bNext = alignment.slice(i).find(x => x.type === 'onlyB' && x.cat === 'tool');
      return {index: i, step: i + 1, type: 'tool_mismatch',
        desc: bNext ? `Run A used ${e.stepA.tool} while Run B used ${bNext.stepB.tool} after ${afterName}` : `Run A used ${e.stepA.tool} — not present in Run B — after ${afterName}`};
    }
    if (e.type === 'onlyB') {
      const aNext = alignment.slice(i).find(x => x.type === 'onlyA' && x.cat === 'tool');
      return {index: i, step: i + 1, type: 'tool_mismatch',
        desc: aNext ? `Run B used ${e.stepB.tool} while Run A used ${aNext.stepA.tool} after ${afterName}` : `Run B used ${e.stepB.tool} — not present in Run A — after ${afterName}`};
    }
  }
  return null;
}

// ============================================================
// Behavioral comparison — rendering
// ============================================================

function diffRuns() {
  const aIdx = parseInt(document.getElementById('diff-a').value);
  const bIdx = parseInt(document.getElementById('diff-b').value);
  const a = _currentRuns[aIdx], b = _currentRuns[bIdx];
  if (!a || !b) return;
  _openCmpDetails = new Set();

  const {alignment, stats} = buildAlignment(a.steps || [], b.steps || []);
  const div = detectDivergence(alignment);

  const aIn = (a.usage||{}).input_tokens||0, aOut = (a.usage||{}).output_tokens||0;
  const bIn = (b.usage||{}).input_tokens||0, bOut = (b.usage||{}).output_tokens||0;
  const dDur = (b.duration_s||0) - (a.duration_s||0);
  const dTok = (bIn + bOut) - (aIn + aOut);
  const aCost = a.cost_usd||0, bCost = b.cost_usd||0;
  const dCost = bCost - aCost;

  let html = '';

  // Divergence banner
  if (div) {
    html += `<div class="cmp-banner">
      <div class="cmp-banner-icon">&#9888;</div>
      <div class="cmp-banner-body">
        <div class="cmp-banner-title">Runs diverge at step ${div.step}</div>
        <div class="cmp-banner-desc">${esc(div.desc)}</div>
      </div>
      <button class="cmp-banner-jump" onclick="document.getElementById('cmp-div-point').scrollIntoView({behavior:'smooth',block:'center'})">Jump</button>
    </div>`;
  } else {
    html += `<div class="cmp-banner cmp-banner-none">
      <div class="cmp-banner-icon">&#10003;</div>
      <div class="cmp-banner-body">
        <div class="cmp-banner-title">No behavioral divergence</div>
        <div class="cmp-banner-desc">Both runs follow the same tool pattern. Reasoning may vary.</div>
      </div>
    </div>`;
  }

  // Stats
  html += `<div class="cmp-stats">
    <div class="cmp-stat"><div class="cmp-stat-lbl">Shared</div><div class="cmp-stat-val cmp-c-match">${stats.matched}</div></div>
    <div class="cmp-stat"><div class="cmp-stat-lbl">Only #${aIdx+1}</div><div class="cmp-stat-val cmp-c-a">${stats.onlyA}</div></div>
    <div class="cmp-stat"><div class="cmp-stat-lbl">Only #${bIdx+1}</div><div class="cmp-stat-val cmp-c-b">${stats.onlyB}</div></div>
    <div class="cmp-stat"><div class="cmp-stat-lbl">Duration</div><div class="cmp-stat-val ${dDur>0?'diff-delta-pos':'diff-delta-neg'}">${dDur>0?'+':''}${dDur.toFixed(1)}s</div></div>
    <div class="cmp-stat"><div class="cmp-stat-lbl">Tokens</div><div class="cmp-stat-val ${dTok>0?'diff-delta-pos':'diff-delta-neg'}">${dTok>0?'+':''}${fmtTokens(dTok)}</div></div>
    ${aCost||bCost ? `<div class="cmp-stat"><div class="cmp-stat-lbl">Cost</div><div class="cmp-stat-val ${dCost>0?'diff-delta-pos':'diff-delta-neg'}">${dCost>0?'+':''}${fmtCost(Math.abs(dCost))}</div></div>` : ''}
  </div>`;

  // Build side-by-side rows from alignment
  const rowsA = [], rowsB = [];
  alignment.forEach((e, i) => {
    const isDivPt = div && i === div.index;
    if (isDivPt) {
      rowsA.push({divider: true});
      rowsB.push({divider: true});
    }
    if (e.type === 'matched') {
      rowsA.push({step: e.stepA, match: true, sim: e.sim, cat: e.cat, idx: i});
      rowsB.push({step: e.stepB, match: true, sim: e.sim, cat: e.cat, idx: i});
    } else if (e.type === 'onlyA') {
      rowsA.push({step: e.stepA, match: false, cat: e.cat, idx: i});
      rowsB.push({empty: true, cat: e.cat, idx: i});
    } else {
      rowsA.push({empty: true, cat: e.cat, idx: i});
      rowsB.push({step: e.stepB, match: false, cat: e.cat, idx: i});
    }
  });

  html += `<div class="diff-grid">
    <div class="diff-col">
      <div class="diff-col-title">Run #${aIdx+1} <span class="diff-stats">${(a.steps||[]).length} steps &middot; ${(a.duration_s||0).toFixed(1)}s</span></div>
      ${rowsA.map(r => renderSbsRow(r, 'a')).join('')}
    </div>
    <div class="diff-col">
      <div class="diff-col-title">Run #${bIdx+1} <span class="diff-stats">${(b.steps||[]).length} steps &middot; ${(b.duration_s||0).toFixed(1)}s</span></div>
      ${rowsB.map(r => renderSbsRow(r, 'b')).join('')}
    </div>
  </div>`;

  document.getElementById('diff-result').innerHTML = html;
}

function renderSbsRow(r, side) {
  if (r.divider) return `<div class="cmp-div-marker" ${side==='a'?'id="cmp-div-point"':''}><div class="cmp-div-line"></div><span class="cmp-div-label">DIVERGENCE</span><div class="cmp-div-line"></div></div>`;
  if (r.empty) return `<div class="diff-row" style="opacity:0.15;min-height:30px">&mdash;</div>`;

  const s = r.step;
  const isTool = s.type === 'tool' || s.type === 'tool_error';
  const isReason = s.type === 'reasoning';

  // Color coding
  let cls = '', badge = '';
  if (r.match && isTool) {
    cls = r.sim >= 0.6 ? 'diff-match' : 'cmp-dl-changed';
    badge = `<span class="cmp-badge cmp-badge-match">${Math.round(r.sim*100)}%</span>`;
  } else if (r.match && isReason) {
    cls = 'diff-match';
  } else if (!r.match && isTool) {
    cls = side === 'a' ? 'diff-rm' : 'diff-add';
  } else if (!r.match && isReason) {
    cls = side === 'a' ? 'diff-rm' : 'diff-add';
  }

  if (isTool) {
    const dur = (s.duration_ms||0).toFixed(0);
    const argsPreview = esc(String(typeof s.args === 'string' ? s.args : JSON.stringify(s.args||'')).slice(0, 80));
    const toggle = r.match ? `<span class="cmp-row-toggle" onclick="toggleCmpDetail(${r.idx})">compare</span>` : '';
    let detail = '';
    if (r.match && _openCmpDetails.has(r.idx)) {
      // We need both steps — store in a data attribute won't work, so render inline
      detail = `<div class="cmp-detail" id="cmp-d-${side}-${r.idx}" style="margin-top:6px"></div>`;
    }
    return `<div class="diff-row ${cls}" style="flex-direction:column;align-items:stretch">
      <div style="display:flex;justify-content:space-between;align-items:center">
        <span><span class="cmp-row-name ${r.match?'cmp-n-match':side==='a'?'cmp-n-a':'cmp-n-b'}">${esc(s.tool)}</span> ${badge} ${toggle}</span>
        <span class="mono" style="color:var(--muted);font-size:10px">${dur}ms</span>
      </div>
      <div style="color:var(--dim);font-size:10px;margin-top:2px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${argsPreview}</div>
    </div>`;
  }

  if (isReason) {
    const txt = (s.text||'').slice(0, 120).replace(/\\n/g, ' ');
    if (isNoise(s)) return `<div class="diff-row ${cls}" style="opacity:0.3;font-size:10px;color:var(--dim)">${esc(txt)}</div>`;
    return `<div class="diff-row ${cls}" style="flex-direction:column;border-left:2px solid var(--green);font-size:11px;color:var(--text2);line-height:1.5">
      <div style="color:var(--green);font-size:10px;font-weight:600;margin-bottom:2px">reasoning</div>
      <div style="max-height:60px;overflow:hidden">${esc(txt)}</div>
    </div>`;
  }

  return `<div class="diff-row ${cls}">${esc(s.type)}</div>`;
}

function toggleCmpDetail(i) {
  // For side-by-side, we just toggle a class to highlight the row
  // Full detail expansion would require both steps which we handle via the alignment data
  const el = document.getElementById('cmp-d-' + i);
  if (el) { el.style.display = el.style.display === 'none' ? 'block' : 'none'; return; }
  // No detail panel — this is expected for side-by-side
}

async function loadDivergence() {
  const data = await fetch(API + '/api/divergence').then(r => r.json());
  const body = document.getElementById('main-body');
  if (!data.length) { body.innerHTML = '<div class="empty"><h3>No divergence detected</h3>All agents follow consistent tool patterns across runs.</div>'; return; }
  body.innerHTML = data.map(d => {
    const fps = Object.entries(d.fingerprints);
    return `<div class="div-card">
      <div class="name">${esc(d.task_name)}</div>
      <div style="color:var(--muted);font-size:12px;margin-top:4px">${fps.length} distinct tool patterns detected</div>
      <div class="patterns">${fps.map(([fp, info]) =>
        `<span class="badge badge-amber">${fp.substring(0,8)} &middot; ${info.run_count} run${info.run_count>1?'s':''}</span>`
      ).join('')}</div>
    </div>`;
  }).join('');
}

function getRunOutput(r, q) {
  if (r.output) {
    const out = typeof r.output === 'string' ? r.output : JSON.stringify(r.output, null, 2);
    return highlight(out, q);
  }
  const steps = r.steps || [];
  for (let i = steps.length - 1; i >= 0; i--) {
    const s = steps[i];
    if (s.type === 'reasoning' && s.text && !s.text.startsWith('[agent ') && !s.text.startsWith('[handoff') && !s.text.startsWith('[subagent')) {
      return highlight(s.text, q);
    }
  }
  return '<span style="color:var(--dim)">No output recorded</span>';
}

function fmtTokens(n) {
  if (Math.abs(n) >= 1000) return (n/1000).toFixed(1) + 'k';
  return String(n);
}

function esc(s) { const d = document.createElement('div'); d.textContent = String(s||''); return d.innerHTML; }

loadAll();
</script>
</body>
</html>"""


# ---------------------------------------------------------------------------
# Server
# ---------------------------------------------------------------------------


def run_dashboard(host: str = "0.0.0.0", port: int = 9847) -> None:
    """Start the Mimir dashboard HTTP server (blocking)."""
    _ensure_dirs()
    server = HTTPServer((host, port), DashboardHandler)
    print(f"  mimir dashboard running at http://localhost:{port}")
    print(f"  data stored in {MIMIR_DIR}")
    print(f"  press ctrl+c to stop")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n  mimir dashboard stopped.")
        server.server_close()
