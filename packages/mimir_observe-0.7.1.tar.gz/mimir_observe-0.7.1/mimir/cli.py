"""
Mimir CLI — dashboard, quickstart, and version.
"""

from __future__ import annotations

import argparse
import sys


QUICKSTART = """\
\033[1;36m╔══════════════════════════════════════════════════════════╗
║                  mimir — quick start                     ║
╚══════════════════════════════════════════════════════════╝\033[0m

\033[1m1. Instrument your code\033[0m (add 2 lines at the top of your entry point)

   \033[33mimport mimir\033[0m

   Pick one:
   \033[32mmimir.instrument_openai()\033[0m         \033[90m# raw OpenAI client\033[0m
   \033[32mmimir.instrument_anthropic()\033[0m      \033[90m# raw Anthropic client\033[0m
   \033[32mmimir.instrument_openai_agents()\033[0m  \033[90m# OpenAI Agents SDK\033[0m
   \033[32mmimir.instrument_claude()\033[0m         \033[90m# Claude Agent SDK\033[0m

\033[1m2. Multi-turn agents?\033[0m Wrap each agent's loop so all API calls
   become steps in one run (instead of separate runs):

   \033[33mwith mimir.trace("My Agent Name"):\033[0m
       \033[90m# ... your existing loop here, unchanged ...\033[0m

\033[1m3. Start the dashboard\033[0m (separate terminal)

   \033[32mpython -m mimir.cli dashboard\033[0m
   \033[90m# opens at http://localhost:9847\033[0m

\033[1;36m───────────────────────────────────────────────────────────\033[0m

\033[1mOnboard with Claude Code\033[0m — paste this prompt:

\033[90m  Install and set up Mimir agent observability in this project.

  Step 1: pip install mimir-observe (if not already installed).
  Import as `import mimir`.

  Step 2: Find the entry point(s) and determine which SDK is used:
    - `from openai import OpenAI` → add `mimir.instrument_openai()`
    - `from anthropic import Anthropic` → add `mimir.instrument_anthropic()`
    - `from agents import Runner` → add `mimir.instrument_openai_agents()`
    - `from claude_code_sdk import query` → add `mimir.instrument_claude()`

  Add the 2 lines (import + instrument call) at the top of each entry
  point, BEFORE any API calls. No other code changes needed.

  Step 3: If the code has multi-turn agentic loops (calling the API
  multiple times in a while/for loop), wrap each agent's loop with
  mimir.trace("Agent Name") so all turns become steps in one run:

      with mimir.trace("My Agent"):
          # ... existing loop unchanged ...

  Each distinct agent should get its own mimir.trace() with a unique
  name. Single API calls outside a loop do NOT need this wrapper.

  Step 4: Start the dashboard: python -m mimir.cli dashboard\033[0m

\033[1;36m───────────────────────────────────────────────────────────\033[0m
\033[90mDocs: https://pypi.org/project/mimir-observe/\033[0m
"""


def main():
    parser = argparse.ArgumentParser(
        prog="mimir",
        description="Mimir — auto-instrumentation and visibility for AI agents",
        epilog="Run 'mimir quickstart' for the full getting-started guide.",
    )
    sub = parser.add_subparsers(dest="command")

    sub.add_parser("quickstart", help="Getting-started guide with code snippets and Claude Code onboarding prompt")
    dash = sub.add_parser("dashboard", help="Start the local dashboard (default: http://localhost:9847)")
    dash.add_argument("--host", default="0.0.0.0", help="Bind address (default: 0.0.0.0)")
    dash.add_argument("--port", type=int, default=9847, help="Port (default: 9847)")
    sub.add_parser("version", help="Print version")

    args = parser.parse_args()

    if args.command == "quickstart":
        print(QUICKSTART)
    elif args.command == "dashboard":
        from .dashboard import run_dashboard
        run_dashboard(host=args.host, port=args.port)
    elif args.command == "version":
        from . import __version__
        print(f"mimir {__version__}")
    else:
        from . import __version__
        print(f"\033[1;36mmimir\033[0m {__version__}")
        print()
        print("  \033[1mmimir quickstart\033[0m    Getting-started guide + Claude Code onboarding prompt")
        print("  \033[1mmimir dashboard\033[0m     Start the local dashboard at http://localhost:9847")
        print("  \033[1mmimir version\033[0m       Print version")
        print()
        print("Run \033[33mmimir quickstart\033[0m to get started.")


if __name__ == "__main__":
    main()
