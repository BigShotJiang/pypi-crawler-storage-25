# iTE Documentation

**iTE** (Interactive Terminal Environment) is an AI coding agent for your terminal. Connect your model service and start coding.

iTE runs as a chat interface in your terminal. You prompt, it responds, and together you build software. It can read files, run commands, search code, and edit files—safely, with your approval.

## Quick Start

1. [Install iTE](installation.md)
2. [Configure your provider](configuration.md)
3. [Initialize your project](initialization.md)
4. [Start coding](usage.md)

## What iTE Does

- **Reads and writes files**: Code, config, documentation
- **Runs terminal commands**: Tests, builds, git operations
- **Searches code**: Find functions, patterns, references
- **Plans changes**: Discuss before implementing with `/plan`
- **Remembers context**: Sessions persist across restarts
- **Works with your tools**: MCP servers, skills, custom subagents

---

## Model Providers

iTE Cloud brings bundled models—no API keys required. A curated selection of high-quality models, managed directly within the platform. [Learn more →](configuration.md#ite-cloud-coming-soon)

Or bring your own: Ollama (local), OpenRouter, OpenAI, or any OpenAI-compatible provider.

---

## Documentation

- [Installation](installation.md) — Install via pipx
- [Configuration](configuration.md) — Set up your model provider
- [Initialization](initialization.md) — Project setup with AGENTS.md
- [Usage](usage.md) — Everyday workflows
- [Commands](commands.md) — Full command reference
- [Tools](tools.md) — Built-in tools reference
- [Subagents](subagents.md) — Specialist agents for parallel tasks
- [AGENTS.md](agents.md) — Project instructions for the AI
- [Skills](skills.md) — Bundles of expertise
- [MCP](mcp.md) — External tool servers
