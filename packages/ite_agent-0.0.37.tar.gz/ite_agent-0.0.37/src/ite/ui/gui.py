"""Compatibility forwarder for GUI package refactor."""

from ite.ui.gui import GUIApp, GUI, create_gui_app, run_gui

__all__ = ["GUIApp", "GUI", "create_gui_app", "run_gui"]
