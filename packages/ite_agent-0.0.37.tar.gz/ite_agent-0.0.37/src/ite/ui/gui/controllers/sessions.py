from __future__ import annotations
import asyncio
import json
from typing import Any
from pathlib import Path
import flet as ft
from ite.agent.session import Session
from ite.agent.session_manager import SessionManager, SessionSnapshot
from ..tokens import *


class SessionControllerMixin:
    GUI_SESSION_RENDER_LIMIT = 60

    def _cancel_session_hydration_task(self):
        task = getattr(self, "_session_hydration_task", None)
        if task and hasattr(task, "done") and hasattr(task, "cancel") and not task.done():
            task.cancel()
        self._session_hydration_task = None
        self._hydrating_session_id = None

    async def _start_new_thread(self):
        """Start a fresh agent session instead of clearing the current one."""
        self._set_loading(True)
        try:
            self._cancel_session_hydration_task()
            await self._cancel_active_turn_and_wait()
            await self._ensure_agent()
            if not self.agent or not self.agent.session:
                return

            # Persist current thread before switching if it has real turns.
            if self.agent.session.turn_count > 0:
                await self._auto_save()

            previous = self.agent.session
            fresh = Session(config=self.config)

            # Close resources bound to the old live session before replacing it.
            await previous.client.close()
            await previous.mcp_manager.shutdown()
            await fresh.initialize()
            fresh.approval_manager.confirmation_callback = self._gui_confirmation_callback
            self.agent.session = fresh
            if hasattr(self, "_sync_plan_toggle_ui"):
                self._sync_plan_toggle_ui()
            if hasattr(self, "_refresh_workboard_from_session"):
                self._refresh_workboard_from_session()

            self.gui_state.session_loaded(
                session_id=None,
                title=None,
                workspace=self.config.cwd,
                visible_transcript_messages=[],
                transcript_truncated=False,
                pending_transcript_load=False,
            )
            self._set_current_session_title(None)

            if self.messages_column and self.page:
                self._clear_chat_controls()
                self._safe_page_update()

            self._tool_call_row_indices.clear()
            self.streaming_markdown = None
            self.streaming_container = None
            self.streaming_text = ""
            if hasattr(self, "_clear_pending_attachments"):
                self._clear_pending_attachments()
            self._refresh_sidebar_threads()
            self._add_assistant_card(
                "New Thread",
                ft.Text("Started a fresh session.", color=TEXT_SECONDARY),
            )
        except Exception as e:
            self._add_message("system", f"Error starting new thread: {e}", is_error=True)
        finally:
            self._set_loading(False)

    async def _auto_save(self):
        if not self.agent or not self.agent.session:
            return
        if self.agent.session.turn_count == 0:
            return

        session = self.agent.session
        try:
            if session.name is None:
                session.set_auto_name(await self._generate_session_name(session))
            elif session.should_refresh_auto_name():
                refreshed = await self._generate_session_name(session)
                if refreshed and refreshed.strip() and refreshed.strip() != session.name:
                    session.set_auto_name(refreshed)

            snapshot = SessionSnapshot(
                **session.snapshot_kwargs(workspace_path=str(self.config.cwd.resolve()))
            )
            await asyncio.to_thread(SessionManager().save_session, snapshot)
            self._set_current_session_title(session.name)
            self._refresh_workspace_options()
            self._refresh_sidebar_threads()
        except Exception:
            # Keep GUI responsive; autosave failure should not break chat flow.
            return

    async def _generate_session_name(self, session: Session) -> str:
        first_user = ""
        try:
            context = session.name_generation_context()
            first_user = context.get("first_user", "")
            first_assistant = context.get("first_assistant", "")
            latest_user = context.get("latest_user", "")
            focus_hint = context.get("focus_hint", "")

            if not first_user:
                return "New thread"

            naming_messages = [
                {
                    "role": "user",
                    "content": (
                        "Generate a concise 3-6 word title for this conversation. "
                        "Prefer the current active work focus over the initial exploratory question if they differ. "
                        "Reply with ONLY the title text, nothing else. No quotes, no punctuation at the end.\n\n"
                        f"Initial user: {first_user}\n"
                        + (f"Initial assistant: {first_assistant}\n" if first_assistant else "")
                        + (f"Latest user: {latest_user}\n" if latest_user else "")
                        + (f"Active focus: {focus_hint}" if focus_hint else "")
                    ),
                }
            ]

            title = ""
            async for event in session.client.chat_completion(
                naming_messages, tools=None, stream=False
            ):
                if event.text_delta and event.text_delta.content:
                    title += event.text_delta.content

            title = title.strip()[:60]
            if title:
                return title
        except Exception:
            pass

        fallback = first_user.split(".")[0].split("?")[0].split("!")[0][:60]
        return fallback.strip() or "New thread"

    async def _open_session_from_sidebar(self, session_id: str):
        self._set_loading(True)
        try:
            self._cancel_session_hydration_task()
            await self._cancel_active_turn_and_wait()
            snapshot = await asyncio.to_thread(SessionManager().load_session, session_id)
            if snapshot is None:
                self._add_message("system", f"Session not found: {session_id}", is_error=True)
                return

            if snapshot.workspace_path:
                snapshot_workspace = Path(snapshot.workspace_path).resolve()
                if snapshot_workspace != self.config.cwd.resolve():
                    self.config.cwd = snapshot_workspace
                    self.gui_state.set_workspace(snapshot_workspace)
                    if self.header_workspace_text:
                        self.header_workspace_text.value = f"Workspace: {self.config.cwd}"
                    if self.agent is not None:
                        await self._shutdown_agent()
                    self._refresh_workspace_options()
                    self._refresh_sidebar_threads()
                    if self.page:
                        self.page.run_task(self._refresh_branch_options_async)

            await self._ensure_agent()
            if not self.agent:
                self._add_message("system", "Error: agent not initialized", is_error=True)
                return

            await self._resume_agent_session(snapshot)
            if hasattr(self, "_clear_pending_attachments"):
                self._clear_pending_attachments()
            self._set_current_session_title(snapshot.name)
            self._clear_chat_controls()
            resumed_messages = self.agent.session.context_manager.get_snapshot_messages()
            render_limit = self.GUI_SESSION_RENDER_LIMIT
            hidden_count = max(0, len(resumed_messages) - render_limit)
            rendered_messages = (
                resumed_messages[-render_limit:]
                if hidden_count > 0
                else resumed_messages
            )
            self.gui_state.session_loaded(
                session_id=snapshot.session_id,
                title=snapshot.name,
                workspace=self.config.cwd,
                visible_transcript_messages=rendered_messages,
                transcript_truncated=hidden_count > 0,
                pending_transcript_load=hidden_count > 0,
            )
            self.gui_state.clear_session_loading()
            self._reset_turn_ui_state()
            self._refresh_sidebar_threads()
            self._set_loading(False)
            self._auto_scroll_enabled = True
            self._scroll_request_id += 1
            self._start_session_hydration(
                snapshot.session_id,
                self.gui_state.state.session_view.visible_transcript_messages,
                hidden_count=hidden_count,
                render_limit=render_limit,
            )
        except Exception as e:
            self.gui_state.session_load_failed()
            self._add_message("system", f"Error loading session: {e}", is_error=True)
        finally:
            if self.loading_session_id == session_id:
                self.gui_state.clear_session_loading()
                self._reset_turn_ui_state()
                self._refresh_sidebar_threads()
                self._set_loading(False)

    async def _resume_agent_session(self, snapshot):
        if not self.agent:
            return

        resumed = self.agent.session
        if resumed is None:
            resumed = Session(config=self.config)
            await resumed.initialize()
            self.agent.session = resumed

        resumed.set_session_id(snapshot.session_id)
        resumed.name = snapshot.name
        resumed.created_at = snapshot.created_at
        resumed.updated_at = snapshot.updated_at
        resumed.turn_count = snapshot.turn_count
        resumed.pending_plan_text = snapshot.pending_plan_text
        resumed.active_plan_text = snapshot.active_plan_text
        resumed.active_skill_refs = list(snapshot.active_skills or [])
        resumed.show_planning_todos = snapshot.show_planning_todos

        if resumed.context_manager is None:
            await resumed.initialize()

        resumed.set_plan_mode(snapshot.plan_mode_enabled)
        resumed.plan_questions_asked = snapshot.plan_questions_asked
        resumed.plan_target_questions = snapshot.plan_target_questions
        resumed.set_plan_phase(snapshot.plan_phase)
        if snapshot.transcript_state:
            resumed.context_manager.restore_transcript_state(snapshot.transcript_state)
        else:
            resumed.context_manager.set_messages(snapshot.messages)
        resumed.context_manager.total_usage = snapshot.total_usage
        if hasattr(resumed, "restore_active_skills"):
            resumed.restore_active_skills(snapshot.active_skills)
        resumed.restore_todos_state(snapshot.todos_state)
        resumed.restore_change_history_state(snapshot.change_history_state)
        resumed.restore_subagent_runtime_state(snapshot.subagent_runtime_state)
        resumed.approval_manager.confirmation_callback = self._gui_confirmation_callback
        if hasattr(self, "_sync_plan_toggle_ui"):
            self._sync_plan_toggle_ui()
        if hasattr(self, "_refresh_workboard_from_session"):
            self._refresh_workboard_from_session()

    def _start_session_hydration(
        self,
        expected_session_id: str,
        messages: list[dict[str, Any]],
        *,
        hidden_count: int = 0,
        render_limit: int | None = None,
    ) -> None:
        if not self.page:
            return
        self._cancel_session_hydration_task()
        self._hydrating_session_id = expected_session_id
        self._session_hydration_task = self.page.run_task(
            self._hydrate_session_view_task,
            expected_session_id,
            messages,
            hidden_count,
            render_limit or self.GUI_SESSION_RENDER_LIMIT,
        )

    async def _hydrate_session_view_task(
        self,
        expected_session_id: str,
        messages: list[dict[str, Any]],
        hidden_count: int,
        render_limit: int,
    ) -> None:
        self.gui_state.set_hydrating_chat(True)
        try:
            await self._hydrate_chat_from_snapshot(
                messages,
                expected_session_id=expected_session_id,
            )
            if self.active_session_id != expected_session_id:
                return
            self._auto_scroll_enabled = True
            self._safe_control_update(self.messages_column)
            await asyncio.sleep(0)
            await self._scroll_chat_to_bottom_async(animate=False, force=True)
            await asyncio.sleep(0.06)
            await self._scroll_chat_to_bottom_async(animate=False, force=True)
            await asyncio.sleep(0.12)
            await self._scroll_chat_to_bottom_async(animate=False, force=True)
        except asyncio.CancelledError:
            return
        finally:
            if self._hydrating_session_id == expected_session_id:
                self._hydrating_session_id = None
                self._session_hydration_task = None
            self.gui_state.set_hydrating_chat(False)

    async def _load_full_transcript_for_active_session(self, expected_session_id: str):
        if (
            not self.agent
            or not self.agent.session
            or self.active_session_id != expected_session_id
        ):
            return
        try:
            messages = self.agent.session.context_manager.get_messages()
            self.gui_state.set_transcript_view(
                visible_transcript_messages=messages,
                transcript_truncated=False,
                pending_transcript_load=False,
            )
            await self._hydrate_chat_from_snapshot(
                self.gui_state.state.session_view.visible_transcript_messages,
                expected_session_id=expected_session_id,
            )
            if self.active_session_id != expected_session_id:
                return
            self._auto_scroll_enabled = True
            self._safe_control_update(self.messages_column)
            await asyncio.sleep(0)
            await self._scroll_chat_to_bottom_async(animate=False, force=True)
            await asyncio.sleep(0.06)
            await self._scroll_chat_to_bottom_async(animate=False, force=True)
            await asyncio.sleep(0.12)
            await self._scroll_chat_to_bottom_async(animate=False, force=True)
        except asyncio.CancelledError:
            return

    async def _hydrate_chat_from_snapshot(
        self,
        messages: list[dict[str, Any]],
        *,
        expected_session_id: str | None = None,
    ):
        if not self.messages_column or not self.page:
            return

        self._clear_chat_controls()
        self._tool_call_row_indices.clear()
        if hasattr(self, "_tool_args_by_call_id"):
            self._tool_args_by_call_id.clear()
        self.streaming_markdown = None
        self.streaming_container = None
        self.streaming_text = ""

        omitted_tool_steps = 0
        processed = 0
        batch_size = 24

        self._defer_ui_updates = True
        try:
            for message in messages:
                if expected_session_id and self.active_session_id != expected_session_id:
                    return
                processed += 1
                role = message.get("role")
                content = message.get("content", "")

                if role == "system":
                    # Internal system prompt; omit from UI transcript.
                    continue

                if role == "user":
                    self._append_chat_control(self.build_chat_message("user", content))
                    continue

                if role == "assistant":
                    if content:
                        self._append_chat_control(
                            self.build_chat_message("assistant", content)
                        )
                    tool_calls = message.get("tool_calls") or []
                    if tool_calls:
                        omitted_tool_steps += len(tool_calls)
                    continue

                if role == "tool":
                    omitted_tool_steps += 1
                    continue

                if processed % batch_size == 0:
                    self._defer_ui_updates = False
                    self._safe_control_update(self.messages_column)
                    await asyncio.sleep(0)
                    self._defer_ui_updates = True
        finally:
            self._defer_ui_updates = False

        self._safe_control_update(self.messages_column)
        await asyncio.sleep(0)
