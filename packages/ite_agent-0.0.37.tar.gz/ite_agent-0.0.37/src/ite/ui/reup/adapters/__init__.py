"""Adapters for reup Textual TUI."""
