"""Git helpers for branch/workspace workflows."""

