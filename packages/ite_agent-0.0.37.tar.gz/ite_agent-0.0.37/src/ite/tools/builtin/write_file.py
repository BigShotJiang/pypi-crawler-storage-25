from ite.tools.base import ToolConfirmation
from ite.tools.base import FileDiff
from ite.utils.paths import ensure_parent_dir
from ite.utils.paths import resolve_path
from pydantic import BaseModel, Field
from ite.tools.base import ToolInvocation, ToolResult, ToolKind, Tool


class WriteFileParams(BaseModel):
    path: str = Field(
        ...,
        description="Path to the file to write (relative to thw cwd or absolute).",
    )
    content: str = Field(
        ...,
        description="Content to write to the file.",
    )
    create_directories: bool = Field(
        True,
        description="Create parent directories if they don't exist.",
    )


class WriteFileTool(Tool):
    name = "write_file"
    description = (
        "Write content to a file. Creates the file if it doesn't exist, "
        "or overwrites it if it does. Parent directories are created automatically. "
        "Use this tool for creating new files or completely replaciing file contents. "
        "For partial modifications, use the edit tool instead."
    )

    kind = ToolKind.WRITE
    schema = WriteFileParams

    async def get_confirmation(
        self,
        invocation: ToolInvocation,
    ) -> ToolConfirmation | None:
        params = WriteFileParams(**invocation.params)
        path = resolve_path(invocation.cwd, params.path)

        is_new_file = not path.exists()

        action = "Create" if is_new_file else "Update"

        old_content = ""

        if not is_new_file:
            try:
                old_content = path.read_text(encoding="utf-8")
            except (OSError, UnicodeDecodeError):
                pass

        diff = FileDiff(
            path=path,
            old_content=old_content,
            new_content=params.content,
            is_new_file=is_new_file,
        )

        return ToolConfirmation(
            tool_name=self.name,
            description=f"{action} file: {path}",
            params=invocation.params,
            diff=diff,
            affected_paths=[path],
            is_dangerous=not is_new_file,
        )

    async def execute(self, invocation: ToolInvocation) -> ToolResult:
        params = WriteFileParams(**invocation.params)

        path = resolve_path(invocation.cwd, params.path)

        sandbox_error = self._sandbox_check(path, invocation.cwd)
        if sandbox_error:
            return sandbox_error

        is_new_file = not path.exists()

        old_content = ""

        if not is_new_file:
            try:
                old_content = path.read_text(encoding="utf-8")
            except (OSError, UnicodeDecodeError):
                pass

        try:
            if params.create_directories:
                ensure_parent_dir(path)
            elif not path.parent.exists():
                return ToolResult.error_result(
                    f"Parent directory does not exist: {path.parent}"
                )

            path.write_text(params.content, encoding="utf-8")

            action = "Created" if is_new_file else "Updated"
            line_count = len(params.content.splitlines())
            diff = FileDiff(
                path=path,
                old_content=old_content,
                new_content=params.content,
                is_new_file=is_new_file,
            )

            return ToolResult.success_result(
                f"{action} {path} {line_count} lines",
                diff=diff,
                file_diffs=[diff],
                metadata={
                    "path": str(path),
                    "is_new_file": is_new_file,
                    "lines_added": line_count,
                    "bytes": len(params.content.encode("utf-8")),
                },
            )
        except OSError as e:
            return ToolResult.error_result(f"Failed to write file: {e}")
