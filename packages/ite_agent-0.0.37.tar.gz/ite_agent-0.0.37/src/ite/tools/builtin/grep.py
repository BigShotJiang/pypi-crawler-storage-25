from ite.utils.paths import is_binary_file
from pathlib import Path
import os
import re
from ite.utils.paths import resolve_path
from ite.tools.base import ToolResult
from ite.tools.base import ToolInvocation
from ite.tools.base import ToolKind
from pydantic import AliasChoices, BaseModel, ConfigDict, Field
from ite.tools.base import Tool


class GrepParams(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="ignore")

    pattern: str = Field(
        description="Regex pattern to search for",
        validation_alias=AliasChoices("pattern", "query", "search", "regex", "match"),
    )
    path: str = Field(
        ".",
        description="File or directory to search in (default: current directory)",
        validation_alias=AliasChoices("path", "file", "target", "directory", "dir"),
    )
    case_insensitive: bool = Field(
        False,
        description="Case-insensitive search (default: false)",
    )


class GrepTool(Tool):
    name = "grep"
    description = "Search for a regex pattern in file content. Returns matching lines with file path and line number."
    kind = ToolKind.READ
    schema = GrepParams

    async def execute(self, invocation: ToolInvocation) -> ToolResult:
        params = GrepParams(**invocation.params)

        search_path = resolve_path(invocation.cwd, params.path)

        sandbox_error = self._sandbox_check(search_path, invocation.cwd)
        if sandbox_error:
            return sandbox_error

        if not search_path.exists():
            return ToolResult.error_result(f"Path does not exist: '{search_path}'")

        try:
            flags = re.IGNORECASE if params.case_insensitive else 0
            pattern = re.compile(params.pattern, flags)
        except re.error as e:
            return ToolResult.error_result(f"Invalid regex pattern: {e}")

        if search_path.is_dir():
            files = self._find_files(search_path)
        else:
            files = [search_path]

        output_lines = []
        matches = 0

        for file_path in files:
            try:
                content = file_path.read_text(encoding="utf-8")
            except Exception:
                continue

            lines = content.splitlines()
            file_matches = False

            # sample:
            # === path/to/file ===
            # line number: line content

            # e.g:
            # === main.py ===
            # 1: def main():
            # 2:     print("Hello, world!")

            # === main2.py ===
            # 1: def main():
            # 2:     print("Hello, world!")

            for i, line in enumerate(lines, start=1):
                if pattern.search(line):
                    matches += 1
                    if not file_matches:
                        try:
                            relative_path = file_path.relative_to(invocation.cwd)
                        except Exception:
                            relative_path = file_path
                        output_lines.append(f"=== {relative_path} ===")
                        file_matches = True

                    output_lines.append(f"{i}: {line}")

            if file_matches:
                output_lines.append("")

        if not output_lines:
            return ToolResult.success_result(
                f"No matches found for pattern: '{params.pattern}'",
                metadata={
                    "path": str(search_path),
                    "matches": 0,
                    "files_searched": len(files),
                },
            )

        if matches > 500:
            output_lines.append(
                f"... limited to 500 matches; ({matches - 500} more matches not shown)"
            )

        return ToolResult.success_result(
            "\n".join(output_lines),
            metadata={
                "path": str(search_path),
                "matches": matches,
                "files_searched": len(files),
            },
        )

    def _find_files(self, search_path: Path) -> list[Path]:
        files = []

        for root, dirs, filenames in os.walk(search_path):
            dirs[:] = [
                d
                for d in dirs
                if d
                not in {".git", ".venv", "__pycache__", "node_modules", ".git", "venv"}
            ]
            for filename in filenames:
                if filename.startswith("."):
                    continue

                file_path = Path(root) / filename

                if not is_binary_file(file_path):
                    files.append(file_path)
                    if len(files) >= 500:
                        return files

        return files
