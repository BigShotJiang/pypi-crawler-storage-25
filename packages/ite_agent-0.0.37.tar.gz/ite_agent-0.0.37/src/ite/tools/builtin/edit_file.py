from ite.tools.base import ToolConfirmation
from pathlib import Path
from ite.tools.base import FileDiff
from ite.utils.paths import ensure_parent_dir
from ite.utils.paths import resolve_path
from pydantic import AliasChoices, BaseModel, ConfigDict, Field
from ite.tools.base import Tool, ToolKind, ToolInvocation, ToolResult


class EditParams(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="ignore")

    path: str = Field(
        ...,
        description="Path to the file to edit (relative to working directory or absolute path)",
        validation_alias=AliasChoices("path", "file", "file_path", "filepath", "target"),
    )
    old_string: str = Field(
        "",
        description="The exact text to find and replace. Must match exactly including all whitespace and indentation. For new files, leave this empty.",
        validation_alias=AliasChoices(
            "old_string",
            "old",
            "old_text",
            "oldText",
            "search",
            "find",
            "target_text",
        ),
    )
    new_string: str = Field(
        ...,
        description="The text to replace old_string with. Can be empty to delete text",
        validation_alias=AliasChoices(
            "new_string",
            "new",
            "new_text",
            "newText",
            "replacement",
            "replace_with",
        ),
    )
    replace_all: bool = Field(
        False, description="Replace all occurrences of old_string (default: false)"
    )


class EditTool(Tool):
    name = "edit"
    description = (
        "Edit a file by replacing text. The old_string must match exactly "
        "(including whitespace and indentation) and must be unique in the file "
        "unless replace_all is true. Use this for precise, surgical edits. "
        "For creating new files or complete rewrites, use write_file instead."
    )
    kind = ToolKind.WRITE
    schema = EditParams

    async def get_confirmation(
        self,
        invocation: ToolInvocation,
    ) -> ToolConfirmation | None:
        params = EditParams(**invocation.params)
        path = resolve_path(invocation.cwd, params.path)

        is_new_file = not path.exists()

        if is_new_file:
            diff = FileDiff(
                path=path,
                old_content="",
                new_content=params.new_string,
                is_new_file=True,
            )

            return ToolConfirmation(
                tool_name=self.name,
                params=invocation.params,
                description=f"Create new file: {path}",
                diff=diff,
                affected_paths=[path],
            )

        old_content = path.read_text(encoding="utf-8")

        if params.replace_all:
            new_content = old_content.replace(params.old_string, params.new_string)
        else:
            new_content = old_content.replace(params.old_string, params.new_string, 1)

        diff = FileDiff(
            path=path,
            old_content=old_content,
            new_content=new_content,
        )

        return ToolConfirmation(
            tool_name=self.name,
            params=invocation.params,
            description=f"Edit file: {path}",
            diff=diff,
            affected_paths=[path],
        )

    async def execute(self, invocation: ToolInvocation) -> ToolResult:
        params = EditParams(**invocation.params)

        path = resolve_path(invocation.cwd, params.path)

        sandbox_error = self._sandbox_check(path, invocation.cwd)
        if sandbox_error:
            return sandbox_error

        if not path.exists():
            if params.old_string:
                return ToolResult.error_result(
                    f"File does not exist: '{path}'. To create a new file, use an empty old_string"
                )

            ensure_parent_dir(path)
            path.write_text(params.new_string, encoding="utf-8")

            line_count = len(params.new_string.splitlines())

            return ToolResult.success_result(
                f"Created: {path} {line_count} lines",
                diff=FileDiff(
                    path=path,
                    old_content="",
                    new_content=params.new_string,
                    is_new_file=True,
                ),
                file_diffs=[
                    FileDiff(
                        path=path,
                        old_content="",
                        new_content=params.new_string,
                        is_new_file=True,
                    )
                ],
                metadata={
                    "path": str(path),
                    "is_new_file": True,
                    "lines": line_count,
                },
            )

        old_content = path.read_text(encoding="utf-8")

        if not params.old_string:
            return ToolResult.error_result(
                "old_string is empty but file exists. Provide old_string to edit, or use write_file to overwrite"
            )

        occurrence_count = old_content.count(params.old_string)

        if occurrence_count == 0:
            return self._no_match_error(params.old_string, old_content, path)

        if occurrence_count > 1 and not params.replace_all:
            return ToolResult.error_result(
                f"old_string found {occurrence_count} times  in {path}. "
                f"Either: \n"
                f"1. Provide more context to make the match unique or\n"
                f"2. Set replace_all=true to replace all accurrences",
                metadata={
                    "occurrence_count": occurrence_count,
                    "recoverable": True,
                    "recovery_hint": "Provide more context or set replace_all=true.",
                },
            )

        if params.replace_all:
            new_content = old_content.replace(params.old_string, params.new_string)
            replace_count = occurrence_count
        else:
            new_content = old_content.replace(params.old_string, params.new_string, 1)
            replace_count = 1

        if new_content == old_content:
            return ToolResult.error_result(
                "No changes made - old_string equals new_strinc"
            )

        try:
            path.write_text(new_content, encoding="utf-8")
        except IOError as e:
            return ToolResult.error_result(f"Failed to write file: {e}")

        old_lines = len(old_content.splitlines())
        new_lines = len(new_content.splitlines())
        line_diff = new_lines - old_lines

        diff_msg = ""

        if line_diff > 0:
            diff_msg = f" (+{line_diff} line{'s' if line_diff != 1 else ''})"
        elif line_diff < 0:
            diff_msg = f" (-{abs(line_diff)} line{'s' if abs(line_diff) != 1 else ''})"

        return ToolResult.success_result(
            f"Edited {path}: {replace_count} occurrence{'s' if replace_count != 1 else ''} {diff_msg}",
            diff=FileDiff(
                path=path,
                old_content=old_content,
                new_content=new_content,
            ),
            file_diffs=[
                FileDiff(
                    path=path,
                    old_content=old_content,
                    new_content=new_content,
                )
            ],
            metadata={
                "path": str(path),
                "replace_count": replace_count,
                "line_diff": line_diff,
            },
        )

    def _no_match_error(self, old_string: str, content: str, path: Path) -> ToolResult:
        lines = content.splitlines()

        partial_matches = []
        search_terms = old_string.split()[:5]

        if search_terms:
            first_term = search_terms[0]
            for i, line in enumerate(lines, 1):
                if first_term in line:
                    partial_matches.append((i, line.strip()[:80]))
                    if len(partial_matches) >= 3:
                        break

        error_msg = f"old_string not found in {path}."

        if partial_matches:
            error_msg += "\n\nPossible similar lines:"
            for line_num, line_preview in partial_matches:
                error_msg += f"\n  Line {line_num}: {line_preview}"
            error_msg += "\n\nMake sure old_string matches exactly (including whitespace and indentation)."
        else:
            error_msg += (
                " Make sure the text matches exactly, including:\n"
                "- All whitespace and indentation\n"
                "- Line breaks\n"
                "- Any invisible characters\n"
                "- Try re-reading the file using read_file tool and then editing."
            )

        return ToolResult.error_result(error_msg)
