# DOCX recipes

Use the bundled scripts for these common jobs:

- Inspect a document: `extract_docx.py`
- Unpack for XML edits: `unpack_docx.py`
- Repack the edited package: `pack_docx.py`
- Validate a generated file: `validate_docx.py`
- Create a simple memo or report from a text draft: `write_docx.py`
- Apply direct wording swaps: `replace_text.py`

Prefer a workspace-local scratch directory under `./.ite/tmp/docx/` so shell commands remain inside the project sandbox.
