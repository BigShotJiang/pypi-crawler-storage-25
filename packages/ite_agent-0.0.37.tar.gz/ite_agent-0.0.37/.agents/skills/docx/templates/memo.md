Team Memo

Summary

Add the short executive summary here.

Details

Add the supporting details here.

Next steps

List the follow-up actions here.
