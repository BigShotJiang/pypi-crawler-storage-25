"""Helper scripts for the bundled ite docx skill."""
