"""Helper scripts for the bundled ite pdf skill."""
