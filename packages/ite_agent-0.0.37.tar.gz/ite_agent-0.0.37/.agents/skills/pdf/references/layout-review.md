# PDF layout review

Use `render_pdf.py` when page appearance matters.

Rendered review is the source of truth for:

- spacing
- clipped text
- broken tables
- unreadable charts
- missing page numbers

If Poppler is unavailable, say that visual review could not be completed in this environment.
