"""Centralized log path resolution.

All log file names include project code and user ID for traceability.
Environment variables:
  - HDSP_PRJ_ID: project code
  - JUPYTERHUB_USER / HDSP_BDP_ID: user identifier
  - HDSP_USER_TEAM: team name (for idle shutdown logs)
  - ANALYTICS_LOG_DIR: override for analytics log directory
"""

from __future__ import annotations

import datetime
import json
import logging
import os
from pathlib import Path

logger = logging.getLogger(__name__)

_PROJECT = os.environ.get("HDSP_PRJ_ID", "unknown")
_USER = os.environ.get("JUPYTERHUB_USER", "") or os.environ.get(
    "HDSP_BDP_ID", "unknown"
)
_TEAM = os.environ.get("HDSP_USER_TEAM", "")


def get_log_dir() -> Path:
    """Return the log directory, creating it if necessary.

    Resolution order:
      1. ANALYTICS_LOG_DIR env var
      2. /home/sagemaker-user/.action_logs (SageMaker — auto-created)
      3. <project_root>/logs  (extensions/jupyter/jupyter_ext -> parents[3])
    """
    env = os.environ.get("ANALYTICS_LOG_DIR")
    if env:
        d = Path(env)
    else:
        sagemaker = Path("/home/sagemaker-user")
        if sagemaker.is_dir():
            d = sagemaker / ".action_logs"
        else:
            d = Path(__file__).resolve().parents[3] / ".action_logs"
    try:
        d.mkdir(parents=True, exist_ok=True)
        return d
    except OSError:
        logger.warning("Failed to create log directory: %s", d)
    # Local fallback
    fallback = Path(__file__).resolve().parents[3] / ".action_logs"
    try:
        fallback.mkdir(parents=True, exist_ok=True)
        return fallback
    except OSError:
        logger.warning("Log directory unavailable: %s", fallback)
        return fallback


_LOG_DIR = get_log_dir()


def get_debug_log_path() -> str:
    """Return path for agent_debug_{project}_{user}.log."""
    return str(_LOG_DIR / f"agent_debug_{_PROJECT}_{_USER}.log")


def get_structured_log_path() -> Path:
    """Return path for agent_structured_{project}_{user}.jsonl."""
    return _LOG_DIR / f"agent_structured_{_PROJECT}_{_USER}.jsonl"


def get_analytics_log_path(event_type: str, date_str: str) -> Path:
    """Return path for analytics_{type}_{project}_{user}_{YYYYMMDD}.jsonl."""
    return _LOG_DIR / f"analytics_{event_type}_{_PROJECT}_{_USER}_{date_str}.jsonl"


def write_idle_shutdown_log(
    idle_seconds: float,
    timeout_setting: int,
    trigger_source: str,
) -> None:
    """Write idle shutdown event to a JSONL file.

    File: idle_shutdown_{project}_{user}_{YYYYMMDD_HHMMSS}.jsonl
    """
    now = datetime.datetime.now()
    ts_file = now.strftime("%Y%m%d_%H%M%S")
    filename = f"idle_shutdown_{_PROJECT}_{_USER}_{ts_file}.jsonl"
    path = _LOG_DIR / filename
    event = {
        "event": "idle_shutdown",
        "ts": now.isoformat(timespec="seconds"),
        "project": _PROJECT,
        "user_id": _USER,
        "team": _TEAM,
        "idle_seconds": round(idle_seconds, 1),
        "timeout_setting": timeout_setting,
        "trigger_source": trigger_source,
    }
    try:
        with open(path, "a", encoding="utf-8") as f:
            f.write(json.dumps(event, ensure_ascii=False) + "\n")
    except OSError:
        logger.warning("Failed to write idle shutdown log: %s", path)
