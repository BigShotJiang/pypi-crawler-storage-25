"""기본 도구 인터페이스."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Optional


@dataclass
class ToolResult:
    """도구 실행 결과."""

    success: bool
    data: Optional[Any] = None
    error: Optional[str] = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """딕셔너리로 변환."""
        result = {"success": self.success}
        if self.data is not None:
            result["data"] = self.data
        if self.error is not None:
            result["error"] = self.error
        if self.metadata:
            result["metadata"] = self.metadata
        return result


class BaseTool(ABC):
    """도구의 추상 기본 클래스."""

    @property
    @abstractmethod
    def name(self) -> str:
        """도구 이름."""
        pass

    @property
    @abstractmethod
    def description(self) -> str:
        """도구 설명."""
        pass

    @property
    @abstractmethod
    def parameters(self) -> dict[str, Any]:
        """도구 매개변수 스키마 (JSON Schema 형식)."""
        pass

    @property
    def risk_level(self) -> str:
        """
        도구의 위험 수준.

        Returns:
            다음 중 하나: "low", "medium", "high", "critical"
        """
        return "low"

    @property
    def definition(self) -> dict[str, Any]:
        """
        OpenAI 호환 도구 정의를 가져옵니다.

        Returns:
            도구 정의 딕셔너리
        """
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self.parameters,
            },
        }

    @abstractmethod
    async def execute(self, **kwargs: Any) -> ToolResult:
        """
        도구를 실행합니다.

        Args:
            **kwargs: 도구 인자

        Returns:
            실행 결과가 담긴 ToolResult
        """
        pass
