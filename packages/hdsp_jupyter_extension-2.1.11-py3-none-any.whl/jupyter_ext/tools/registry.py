"""도구 관리 및 실행을 위한 도구 레지스트리."""

from __future__ import annotations

from typing import Any, Optional

from hdsp_agent_core.core.exceptions import ToolError

from .base import BaseTool, ToolResult
from .jupyter_tools import JupyterCellTool, JupyterMarkdownTool
from .file_tools import FileReadTool, FileWriteTool, FileListTool
from .shell_tools import ShellExecuteTool
from .search_tools import SearchCodeTool, WebSearchTool


class ToolRegistry:
    """도구 관리를 위한 레지스트리."""

    # HITL 승인이 필요한 도구들
    HIGH_RISK_TOOLS = {"shell_execute", "file_write"}

    def __init__(
        self,
        kernel_manager: Any = None,
        contents_manager: Any = None,
        base_path: str = ".",
        tavily_api_key: Optional[str] = None,
    ):
        self._tools: dict[str, BaseTool] = {}
        self._base_path = base_path
        self._kernel_manager = kernel_manager
        self._contents_manager = contents_manager

        self._register_default_tools(tavily_api_key)

    def _register_default_tools(self, tavily_api_key: Optional[str] = None) -> None:
        """모든 기본 도구를 등록합니다."""
        # Jupyter 도구
        self._tools["jupyter_cell"] = JupyterCellTool(
            self._kernel_manager,
            self._contents_manager,
        )
        self._tools["jupyter_markdown"] = JupyterMarkdownTool(
            self._contents_manager,
        )

        # 파일 도구
        self._tools["file_read"] = FileReadTool(
            self._contents_manager,
            self._base_path,
        )
        self._tools["file_write"] = FileWriteTool(
            self._contents_manager,
            self._base_path,
        )
        self._tools["file_list"] = FileListTool(
            self._contents_manager,
            self._base_path,
        )

        # 셸 도구
        self._tools["shell_execute"] = ShellExecuteTool(
            working_dir=self._base_path,
        )

        # 검색 도구
        self._tools["search_code"] = SearchCodeTool(
            self._base_path,
        )
        web_search = WebSearchTool(api_key=tavily_api_key)
        self._tools["web_search"] = web_search

    def register(self, tool: BaseTool) -> None:
        """도구를 등록합니다."""
        self._tools[tool.name] = tool

    def unregister(self, name: str) -> None:
        """도구 등록을 해제합니다."""
        if name in self._tools:
            del self._tools[name]

    def get(self, name: str) -> Optional[BaseTool]:
        """이름으로 도구를 가져옵니다."""
        return self._tools.get(name)

    def get_definitions(self) -> list[dict[str, Any]]:
        """LLM용 모든 도구 정의를 가져옵니다."""
        return [tool.definition for tool in self._tools.values()]

    def requires_approval(self, name: str, args: dict[str, Any]) -> bool:
        """
        도구 실행에 HITL 승인이 필요한지 확인합니다.

        Args:
            name: 도구 이름
            args: 도구 인자

        Returns:
            승인이 필요하면 True
        """
        # 고위험 도구인지 확인
        if name in self.HIGH_RISK_TOOLS:
            return True

        # 도구의 위험 수준 확인
        tool = self._tools.get(name)
        if tool and tool.risk_level in ("high", "critical"):
            return True

        # 인자 기반 추가 검사
        if name == "jupyter_cell":
            # EXECUTE 작업에 승인 필요
            if args.get("operation", "").upper() == "EXECUTE":
                return True

        return False

    async def execute(self, name: str, args: dict[str, Any]) -> ToolResult:
        """
        도구를 실행합니다.

        Args:
            name: 도구 이름
            args: 도구 인자

        Returns:
            도구 실행 결과 ToolResult
        """
        tool = self._tools.get(name)
        if not tool:
            return ToolResult(success=False, error=f"알 수 없는 도구: {name}")

        try:
            return await tool.execute(**args)
        except ToolError:
            raise
        except Exception as e:
            raise ToolError(f"도구 실행 오류: {e}", tool_name=name, cause=e) from e

    def set_notebook_context(self, path: str, model: dict) -> None:
        """Jupyter 도구에 노트북 컨텍스트를 설정합니다."""
        jupyter_cell = self._tools.get("jupyter_cell")
        if isinstance(jupyter_cell, JupyterCellTool):
            jupyter_cell.set_notebook(path, model)

        jupyter_md = self._tools.get("jupyter_markdown")
        if isinstance(jupyter_md, JupyterMarkdownTool):
            jupyter_md.set_notebook(model)

    def set_tavily_api_key(self, api_key: str) -> None:
        """웹 검색을 위한 Tavily API 키를 설정합니다."""
        web_search = self._tools.get("web_search")
        if isinstance(web_search, WebSearchTool):
            web_search.set_api_key(api_key)

    @property
    def tool_names(self) -> list[str]:
        """등록된 도구 이름 목록을 가져옵니다."""
        return list(self._tools.keys())
