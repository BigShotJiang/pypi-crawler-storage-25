"""
User interaction tools for agent mode.

- ask_user_tool: Request user input via HITL interrupt
- final_summary_tool: Summarize completed work with next step suggestions
"""

import json
from typing import Any, Dict, List, Optional

from langchain_core.tools import tool
from pydantic import BaseModel, Field


class AskUserInput(BaseModel):
    """Input schema for ask_user tool"""

    question: str = Field(description="사용자에게 보여줄 질문 또는 요청")
    options: Optional[List[str]] = Field(
        default=None, description="선택지 목록 (없으면 자유 입력)"
    )
    input_type: str = Field(
        default="text",
        description="입력 타입: text (텍스트 입력), file (파일 업로드), selection (선택지 중 선택)",
    )
    user_response: Optional[str] = Field(
        default=None,
        description="사용자 응답 (HITL edit decision으로 프론트엔드에서 전달)",
    )


@tool(args_schema=AskUserInput)
def ask_user_tool(
    question: str,
    options: Optional[List[str]] = None,
    input_type: str = "text",
    user_response: Optional[str] = None,
) -> Dict[str, Any]:
    """
    사용자에게 질문하고 응답을 기다리는 도구.

    이 도구 호출 후 에이전트는 사용자 응답을 기다립니다.
    사용자가 응답하면 그 내용이 다음 메시지로 전달됩니다.

    사용 시점:
    - 선택 요청: ask_user_tool(question="어떤 모델을 사용할까요?", options=["Logistic", "RandomForest"])
    - 정보 요청: ask_user_tool(question="API 키를 입력해 주세요", input_type="text")

    주의: 정보 출력용으로는 jupyter_markdown을 사용하고, 사용자 응답이 필요하면 이 도구를 사용하세요.

    Args:
        question: 사용자에게 보여줄 질문
        options: 선택지 목록 (선택적, input_type="selection"일 때 사용)
        input_type: 입력 타입 - text(텍스트), file(파일 업로드), selection(선택)
        user_response: 사용자 응답 (HITL에서 프론트엔드가 전달)

    Returns:
        Dict containing the user response or waiting status
    """
    if user_response is not None:
        return {
            "tool": "ask_user",
            "parameters": {
                "question": question,
                "options": options,
                "input_type": input_type,
            },
            "status": "completed",
            "user_response": user_response,
            "message": f"사용자 응답: {user_response}",
        }

    return {
        "tool": "ask_user",
        "parameters": {
            "question": question,
            "options": options,
            "input_type": input_type,
        },
        "status": "waiting_for_user",
        "message": "사용자 응답을 기다리는 중입니다...",
    }


class FinalSummaryInput(BaseModel):
    """Input schema for final_summary tool"""

    summary: str = Field(description="완료된 작업에 대한 요약 (한국어)")
    next_items: List[dict] = Field(
        description="다음 단계 제안 목록 (각각 subject와 description 포함, 3개 이상)"
    )


@tool(args_schema=FinalSummaryInput)
def final_summary_tool(
    summary: str,
    next_items: List[dict],
) -> str:
    """
    모든 todo가 completed 상태가 된 후 호출하는 마무리 도구.
    별도의 "요약" todo를 만들지 말고, 실제 작업 todo가 모두 완료되면 바로 이 도구를 호출하세요.

    Args:
        summary: 완료된 작업에 대한 요약 (한국어로 작성)
        next_items: 후속 작업 제안 목록 (각각 subject와 description 포함, 3개 이상)

    Returns:
        JSON string containing the summary and next items for frontend display
    """
    serialized_items = []
    for item in next_items:
        if isinstance(item, dict):
            serialized_items.append(item)
        elif hasattr(item, "model_dump"):
            serialized_items.append(item.model_dump())
        else:
            serialized_items.append(
                {
                    "subject": str(getattr(item, "subject", "")),
                    "description": str(getattr(item, "description", "")),
                }
            )
    return json.dumps(
        {
            "tool": "final_summary",
            "summary": summary,
            "next_items": serialized_items,
            "status": "completed",
            "message": "작업 요약이 완료되었습니다.",
        },
        ensure_ascii=False,
    )
