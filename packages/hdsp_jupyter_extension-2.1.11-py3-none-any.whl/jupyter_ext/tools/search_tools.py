"""코드 및 웹 검색 도구."""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any, Optional

import httpx

from .base import BaseTool, ToolResult


class SearchCodeTool(BaseTool):
    """파일에서 코드 검색 도구."""

    def __init__(self, base_path: str = "."):
        self._base_path = Path(base_path)

    @property
    def name(self) -> str:
        return "search_code"

    @property
    def description(self) -> str:
        return """Search for patterns in code files.
Uses regex patterns to find matches across files.
Returns matching lines with file paths and line numbers."""

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "pattern": {
                    "type": "string",
                    "description": "Regex pattern to search for",
                },
                "path": {
                    "type": "string",
                    "description": "Directory to search in (relative to workspace)",
                    "default": ".",
                },
                "file_pattern": {
                    "type": "string",
                    "description": "Glob pattern for files to search (e.g., '*.py')",
                    "default": "*",
                },
                "max_results": {
                    "type": "integer",
                    "description": "Maximum number of results to return",
                    "default": 50,
                },
                "case_sensitive": {
                    "type": "boolean",
                    "description": "Case-sensitive search",
                    "default": True,
                },
            },
            "required": ["pattern"],
        }

    @property
    def risk_level(self) -> str:
        return "low"

    async def execute(self, **kwargs: Any) -> ToolResult:
        """코드 패턴을 검색합니다."""
        pattern = kwargs.get("pattern", "")
        path = kwargs.get("path", ".")
        file_pattern = kwargs.get("file_pattern", "*")
        max_results = kwargs.get("max_results", 50)
        case_sensitive = kwargs.get("case_sensitive", True)

        if not pattern:
            return ToolResult(success=False, error="패턴이 필요합니다")

        try:
            flags = 0 if case_sensitive else re.IGNORECASE
            regex = re.compile(pattern, flags)
        except re.error as e:
            return ToolResult(success=False, error=f"잘못된 정규식 패턴: {e}")

        search_path = self._base_path / path
        if not search_path.exists():
            return ToolResult(success=False, error=f"경로를 찾을 수 없음: {path}")

        results = []
        try:
            for file_path in search_path.rglob(file_pattern):
                if not file_path.is_file():
                    continue

                # 바이너리 파일과 숨김 디렉토리 건너뛰기
                if any(part.startswith(".") for part in file_path.parts):
                    continue

                try:
                    content = file_path.read_text(encoding="utf-8", errors="ignore")
                    for line_num, line in enumerate(content.splitlines(), 1):
                        if regex.search(line):
                            rel_path = file_path.relative_to(self._base_path)
                            results.append(
                                {
                                    "file": str(rel_path),
                                    "line": line_num,
                                    "content": line.strip(),
                                }
                            )

                            if len(results) >= max_results:
                                break
                except Exception:
                    # 읽을 수 없는 파일 건너뛰기
                    continue

                if len(results) >= max_results:
                    break

            return ToolResult(
                success=True,
                data={"matches": results, "pattern": pattern},
                metadata={
                    "count": len(results),
                    "truncated": len(results) >= max_results,
                },
            )

        except Exception as e:
            return ToolResult(success=False, error=f"검색 오류: {str(e)}")


class WebSearchTool(BaseTool):
    """Tavily API를 사용한 웹 검색 도구."""

    def __init__(self, api_key: Optional[str] = None):
        self._api_key = api_key
        self._client = httpx.AsyncClient(timeout=30.0)

    @property
    def name(self) -> str:
        return "web_search"

    @property
    def description(self) -> str:
        return """Search the web for information.
Returns relevant search results with titles, URLs, and snippets.
Useful for finding current information, documentation, or examples."""

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "The search query",
                },
                "max_results": {
                    "type": "integer",
                    "description": "Maximum number of results to return",
                    "default": 5,
                },
            },
            "required": ["query"],
        }

    @property
    def risk_level(self) -> str:
        return "low"

    def set_api_key(self, api_key: str) -> None:
        """Tavily API 키를 설정합니다."""
        self._api_key = api_key

    async def execute(self, **kwargs: Any) -> ToolResult:
        """웹 검색을 실행합니다."""
        query = kwargs.get("query", "")
        max_results = kwargs.get("max_results", 5)

        if not query:
            return ToolResult(success=False, error="쿼리가 필요합니다")

        if not self._api_key:
            return ToolResult(success=False, error="Tavily API 키가 설정되지 않음")

        try:
            response = await self._client.post(
                "https://api.tavily.com/search",
                json={
                    "api_key": self._api_key,
                    "query": query,
                    "max_results": max_results,
                    "include_answer": True,
                },
            )
            response.raise_for_status()

            data = response.json()
            results = []

            for result in data.get("results", []):
                results.append(
                    {
                        "title": result.get("title", ""),
                        "url": result.get("url", ""),
                        "snippet": result.get("content", ""),
                    }
                )

            return ToolResult(
                success=True,
                data={
                    "results": results,
                    "answer": data.get("answer"),
                    "query": query,
                },
                metadata={"count": len(results)},
            )

        except httpx.HTTPStatusError as e:
            return ToolResult(
                success=False, error=f"검색 API 오류: {e.response.status_code}"
            )
        except Exception as e:
            return ToolResult(success=False, error=f"검색 오류: {str(e)}")

    async def close(self):
        """HTTP 클라이언트를 닫습니다."""
        await self._client.aclose()
