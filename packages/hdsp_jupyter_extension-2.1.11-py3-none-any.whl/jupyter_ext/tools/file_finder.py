"""File finder with fzf-style subsequence matching.

Provides a cached file index with both prefix and fuzzy matching,
shared by the @file autocomplete handler and the file_find agent tool.
"""

from __future__ import annotations

import os
import time
from pathlib import Path


def _fzf_score(query: str, candidate: str) -> float | None:
    """fzf-style subsequence match. Returns None if no match."""
    q, c = query.lower(), candidate.lower()
    qi = ci = 0
    positions: list[int] = []
    while qi < len(q) and ci < len(c):
        if q[qi] == c[ci]:
            positions.append(ci)
            qi += 1
        ci += 1
    if qi < len(q):
        return None
    score = 100.0
    # Consecutive character bonus
    consecutive = sum(
        1 for i in range(1, len(positions)) if positions[i] == positions[i - 1] + 1
    )
    score += consecutive * 10
    # Start-of-string bonus
    if positions and positions[0] == 0:
        score += 15
    # Gap penalty
    total_gap = sum(
        positions[i] - positions[i - 1] - 1
        for i in range(1, len(positions))
        if positions[i] > positions[i - 1] + 1
    )
    score -= total_gap * 3
    # Length difference penalty
    score -= (len(candidate) - len(query)) * 1
    return score


# Directories to exclude from indexing
_EXCLUDE_DIRS = frozenset(
    {
        "__pycache__",
        "node_modules",
        ".git",
        ".venv",
        "venv",
        ".ipynb_checkpoints",
        ".tox",
        ".mypy_cache",
        ".pytest_cache",
        ".ruff_cache",
        "dist",
        "build",
        ".eggs",
        "labextension",
        "lib",
    }
)


class FileIndex:
    """Caches a directory tree in memory and provides fuzzy search."""

    def __init__(
        self,
        base_dir: str | Path,
        ttl: int = 30,
        max_files: int = 10_000,
    ):
        self._base_dir = Path(base_dir).resolve()
        self._ttl = ttl
        self._max_files = max_files
        self._entries: list[str] = []  # relative paths
        self._built_at: float = 0.0

    # ------------------------------------------------------------------
    # Index management
    # ------------------------------------------------------------------

    def _maybe_rebuild(self) -> None:
        if time.monotonic() - self._built_at < self._ttl and self._entries:
            return
        self._build_index()

    def _build_index(self) -> None:
        entries: list[str] = []
        base = str(self._base_dir)
        for dirpath, dirnames, filenames in os.walk(base):
            # Prune excluded directories in-place
            dirnames[:] = [
                d for d in dirnames if d not in _EXCLUDE_DIRS and not d.startswith(".")
            ]

            rel_dir = os.path.relpath(dirpath, base)
            if rel_dir == ".":
                rel_dir = ""

            # Add directory entry (with trailing /)
            if rel_dir:
                entries.append(rel_dir + "/")

            for fname in filenames:
                if fname.startswith("."):
                    continue
                if rel_dir:
                    entries.append(os.path.join(rel_dir, fname))
                else:
                    entries.append(fname)

                if len(entries) >= self._max_files:
                    break
            if len(entries) >= self._max_files:
                break

        self._entries = entries
        self._built_at = time.monotonic()

    # ------------------------------------------------------------------
    # Search methods
    # ------------------------------------------------------------------

    def fuzzy_search(
        self,
        query: str,
        max_results: int = 20,
        supported_exts: set[str] | None = None,
        include_dirs: bool = True,
    ) -> list[dict]:
        """Find files by fuzzy matching on the query string.

        If query contains '/', the part before the last '/' is used as a
        directory filter and only the basename portion is fuzzy-matched.

        Returns list of dicts: [{path, score, type}, ...]
        """
        self._maybe_rebuild()
        if not query:
            return []

        # Split directory filter from basename query
        dir_filter = ""
        basename_query = query
        if "/" in query:
            last_slash = query.rfind("/")
            dir_filter = query[:last_slash]
            basename_query = query[last_slash + 1 :]
            if not basename_query:
                # query like "src/" → fall back to prefix search
                return self.prefix_search(query, max_results, supported_exts)

        # Filter candidates
        candidates: list[str] = []
        for entry in self._entries:
            is_dir = entry.endswith("/")

            if not include_dirs and is_dir:
                continue

            if not is_dir and supported_exts is not None:
                ext = os.path.splitext(entry)[1]
                if ext not in supported_exts:
                    continue

            if dir_filter and not entry.startswith(dir_filter):
                continue

            candidates.append(entry)

        if not candidates:
            return []

        # fzf-style subsequence matching on basename
        scored: list[tuple[str, float]] = []
        for entry in candidates:
            basename = os.path.basename(entry.rstrip("/"))
            s = _fzf_score(basename_query, basename)
            if s is None:
                continue
            # Depth penalty: shallower files preferred
            depth = entry.count("/") - (1 if entry.endswith("/") else 0)
            s -= depth * 1.0
            scored.append((entry, s))

        # Sort by score descending
        scored.sort(key=lambda x: -x[1])

        results: list[dict] = []
        for entry, score in scored[:max_results]:
            is_dir = entry.endswith("/")
            results.append(
                {
                    "path": entry.rstrip("/") if is_dir else entry,
                    "score": round(score, 1),
                    "type": "directory" if is_dir else "file",
                }
            )
        return results

    def prefix_search(
        self,
        prefix: str,
        max_results: int = 20,
        supported_exts: set[str] | None = None,
    ) -> list[dict]:
        """Find files/dirs matching a path prefix (existing glob behavior)."""
        self._maybe_rebuild()

        # Normalize: ensure no trailing slash for matching (unless root)
        norm_prefix = prefix.rstrip("/") if prefix != "/" else ""
        results: list[dict] = []

        for entry in self._entries:
            is_dir = entry.endswith("/")
            entry_clean = entry.rstrip("/")

            # Match: entry starts with prefix
            if not entry_clean.startswith(norm_prefix):
                continue

            # Only direct children if prefix looks like a directory
            if prefix.endswith("/") or not prefix:
                remainder = entry_clean[len(norm_prefix) :].lstrip("/")
                if "/" in remainder:
                    continue

            if not is_dir and supported_exts is not None:
                ext = os.path.splitext(entry)[1]
                if ext not in supported_exts:
                    continue

            results.append(
                {
                    "path": entry_clean,
                    "score": 100.0,
                    "type": "directory" if is_dir else "file",
                }
            )
            if len(results) >= max_results:
                break

        # Sort: directories first, then alphabetical
        results.sort(key=lambda r: (r["type"] != "directory", r["path"].lower()))
        return results
