"""Jupyter 노트북 도구."""

from __future__ import annotations

from typing import Any, Optional

from .base import BaseTool, ToolResult


class JupyterCellTool(BaseTool):
    """Jupyter 셀 작업 도구."""

    def __init__(self, kernel_manager: Any, contents_manager: Any):
        self._kernel_manager = kernel_manager
        self._contents_manager = contents_manager
        self._notebook_path: Optional[str] = None
        self._notebook_model: Optional[dict] = None

    @property
    def name(self) -> str:
        return "jupyter_cell"

    @property
    def description(self) -> str:
        return """Create, read, update, delete, or execute Jupyter notebook cells.
Operations:
- CREATE: Create a new code cell with the given code
- READ: Read the content of a cell at the given index
- UPDATE: Update the code of an existing cell
- DELETE: Delete a cell at the given index
- EXECUTE: Execute a cell and return the output"""

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "operation": {
                    "type": "string",
                    "enum": ["CREATE", "READ", "UPDATE", "DELETE", "EXECUTE"],
                    "description": "The operation to perform",
                },
                "code": {
                    "type": "string",
                    "description": "The code content (for CREATE, UPDATE, EXECUTE)",
                },
                "cell_index": {
                    "type": "integer",
                    "description": "The cell index (for READ, UPDATE, DELETE, EXECUTE)",
                },
                "insert_after": {
                    "type": "integer",
                    "description": "Insert new cell after this index (for CREATE)",
                },
            },
            "required": ["operation"],
        }

    @property
    def risk_level(self) -> str:
        return "medium"

    def set_notebook(self, path: str, model: dict) -> None:
        """현재 노트북 컨텍스트를 설정합니다."""
        self._notebook_path = path
        self._notebook_model = model

    async def execute(self, **kwargs: Any) -> ToolResult:
        """Jupyter 셀 작업을 실행합니다."""
        operation = kwargs.get("operation", "").upper()

        if operation == "CREATE":
            return await self._create_cell(
                kwargs.get("code", ""), kwargs.get("insert_after")
            )
        elif operation == "READ":
            return await self._read_cell(kwargs.get("cell_index", 0))
        elif operation == "UPDATE":
            return await self._update_cell(
                kwargs.get("cell_index", 0), kwargs.get("code", "")
            )
        elif operation == "DELETE":
            return await self._delete_cell(kwargs.get("cell_index", 0))
        elif operation == "EXECUTE":
            return await self._execute_cell(
                kwargs.get("cell_index"), kwargs.get("code")
            )
        else:
            return ToolResult(success=False, error=f"알 수 없는 연산: {operation}")

    async def _create_cell(
        self, code: str, insert_after: Optional[int] = None
    ) -> ToolResult:
        """새 셀을 생성합니다."""
        if not self._notebook_model:
            return ToolResult(success=False, error="노트북 컨텍스트가 설정되지 않음")

        cells = self._notebook_model.get("content", {}).get("cells", [])
        new_cell = {
            "cell_type": "code",
            "source": code,
            "metadata": {},
            "outputs": [],
            "execution_count": None,
        }

        if insert_after is not None and 0 <= insert_after < len(cells):
            cells.insert(insert_after + 1, new_cell)
            cell_index = insert_after + 1
        else:
            cells.append(new_cell)
            cell_index = len(cells) - 1

        return ToolResult(
            success=True,
            data={"cell_index": cell_index, "operation": "created"},
            metadata={"cell_type": "code"},
        )

    async def _read_cell(self, cell_index: int) -> ToolResult:
        """셀 내용을 읽습니다."""
        if not self._notebook_model:
            return ToolResult(success=False, error="노트북 컨텍스트가 설정되지 않음")

        cells = self._notebook_model.get("content", {}).get("cells", [])
        if not 0 <= cell_index < len(cells):
            return ToolResult(success=False, error=f"잘못된 셀 인덱스: {cell_index}")

        cell = cells[cell_index]
        return ToolResult(
            success=True,
            data={
                "source": cell.get("source", ""),
                "cell_type": cell.get("cell_type", "code"),
                "outputs": cell.get("outputs", []),
            },
        )

    async def _update_cell(self, cell_index: int, code: str) -> ToolResult:
        """셀 내용을 업데이트합니다."""
        if not self._notebook_model:
            return ToolResult(success=False, error="노트북 컨텍스트가 설정되지 않음")

        cells = self._notebook_model.get("content", {}).get("cells", [])
        if not 0 <= cell_index < len(cells):
            return ToolResult(success=False, error=f"잘못된 셀 인덱스: {cell_index}")

        cells[cell_index]["source"] = code
        return ToolResult(
            success=True,
            data={"cell_index": cell_index, "operation": "updated"},
        )

    async def _delete_cell(self, cell_index: int) -> ToolResult:
        """셀을 삭제합니다."""
        if not self._notebook_model:
            return ToolResult(success=False, error="노트북 컨텍스트가 설정되지 않음")

        cells = self._notebook_model.get("content", {}).get("cells", [])
        if not 0 <= cell_index < len(cells):
            return ToolResult(success=False, error=f"잘못된 셀 인덱스: {cell_index}")

        del cells[cell_index]
        return ToolResult(
            success=True,
            data={"cell_index": cell_index, "operation": "deleted"},
        )

    async def _execute_cell(
        self, cell_index: Optional[int], code: Optional[str]
    ) -> ToolResult:
        """셀 또는 코드를 실행합니다."""
        # 코드가 직접 제공되면 실행
        if code:
            return await self._execute_code(code)

        # 그렇지 않으면 주어진 인덱스의 셀 실행
        if cell_index is not None and self._notebook_model:
            cells = self._notebook_model.get("content", {}).get("cells", [])
            if 0 <= cell_index < len(cells):
                cell_code = cells[cell_index].get("source", "")
                return await self._execute_code(cell_code)

        return ToolResult(
            success=False, error="코드 또는 유효한 셀 인덱스가 제공되지 않음"
        )

    async def _execute_code(self, code: str) -> ToolResult:
        """커널에서 코드를 실행합니다."""
        # 실제 커널과 통합됨
        # 현재는 플레이스홀더 반환
        return ToolResult(
            success=True,
            data={
                "output": "코드 실행 플레이스홀더",
                "execution_count": 1,
            },
            metadata={"executed": True},
        )


class JupyterMarkdownTool(BaseTool):
    """Jupyter 마크다운 셀 작업 도구."""

    def __init__(self, contents_manager: Any):
        self._contents_manager = contents_manager
        self._notebook_model: Optional[dict] = None

    @property
    def name(self) -> str:
        return "jupyter_markdown"

    @property
    def description(self) -> str:
        return """Create or update markdown cells in the Jupyter notebook.
Use this for adding documentation, explanations, or headers."""

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "operation": {
                    "type": "string",
                    "enum": ["CREATE", "UPDATE"],
                    "description": "The operation to perform",
                },
                "content": {
                    "type": "string",
                    "description": "The markdown content",
                },
                "cell_index": {
                    "type": "integer",
                    "description": "The cell index (for UPDATE)",
                },
                "insert_after": {
                    "type": "integer",
                    "description": "Insert new cell after this index (for CREATE)",
                },
            },
            "required": ["operation", "content"],
        }

    @property
    def risk_level(self) -> str:
        return "low"

    def set_notebook(self, model: dict) -> None:
        """현재 노트북 컨텍스트를 설정합니다."""
        self._notebook_model = model

    async def execute(self, **kwargs: Any) -> ToolResult:
        """마크다운 셀 작업을 실행합니다."""
        operation = kwargs.get("operation", "").upper()
        content = kwargs.get("content", "")

        if not self._notebook_model:
            return ToolResult(success=False, error="노트북 컨텍스트가 설정되지 않음")

        cells = self._notebook_model.get("content", {}).get("cells", [])

        if operation == "CREATE":
            new_cell = {
                "cell_type": "markdown",
                "source": content,
                "metadata": {},
            }

            insert_after = kwargs.get("insert_after")
            if insert_after is not None and 0 <= insert_after < len(cells):
                cells.insert(insert_after + 1, new_cell)
                cell_index = insert_after + 1
            else:
                cells.append(new_cell)
                cell_index = len(cells) - 1

            return ToolResult(
                success=True,
                data={"cell_index": cell_index, "operation": "created"},
            )

        elif operation == "UPDATE":
            cell_index = kwargs.get("cell_index", 0)
            if not 0 <= cell_index < len(cells):
                return ToolResult(
                    success=False, error=f"잘못된 셀 인덱스: {cell_index}"
                )

            cells[cell_index]["source"] = content
            cells[cell_index]["cell_type"] = "markdown"
            return ToolResult(
                success=True,
                data={"cell_index": cell_index, "operation": "updated"},
            )

        return ToolResult(success=False, error=f"알 수 없는 연산: {operation}")
