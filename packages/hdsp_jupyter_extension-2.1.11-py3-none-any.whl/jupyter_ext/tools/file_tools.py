"""파일 작업 도구."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from .base import BaseTool, ToolResult


class FileReadTool(BaseTool):
    """파일 내용 읽기 도구."""

    def __init__(self, contents_manager: Any, base_path: str = "."):
        self._contents_manager = contents_manager
        self._base_path = Path(base_path)

    @property
    def name(self) -> str:
        return "file_read"

    @property
    def description(self) -> str:
        return """Read the contents of a file.
Returns the file content as text. For binary files, returns an error."""

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "The file path to read (relative to workspace)",
                },
                "encoding": {
                    "type": "string",
                    "description": "File encoding (default: utf-8)",
                    "default": "utf-8",
                },
            },
            "required": ["path"],
        }

    @property
    def risk_level(self) -> str:
        return "low"

    async def execute(self, **kwargs: Any) -> ToolResult:
        """파일 내용을 읽습니다."""
        path = kwargs.get("path", "")
        encoding = kwargs.get("encoding", "utf-8")

        if not path:
            return ToolResult(success=False, error="경로가 필요합니다")

        try:
            file_path = self._base_path / path
            if not file_path.exists():
                return ToolResult(success=False, error=f"파일을 찾을 수 없음: {path}")

            if not file_path.is_file():
                return ToolResult(success=False, error=f"파일이 아님: {path}")

            content = file_path.read_text(encoding=encoding)
            return ToolResult(
                success=True,
                data={"content": content, "path": str(path)},
                metadata={"size": len(content), "encoding": encoding},
            )

        except UnicodeDecodeError:
            return ToolResult(
                success=False, error=f"텍스트로 읽을 수 없는 파일: {path}"
            )
        except Exception as e:
            return ToolResult(success=False, error=f"파일 읽기 오류: {str(e)}")


class FileWriteTool(BaseTool):
    """파일 내용 쓰기 도구."""

    def __init__(self, contents_manager: Any, base_path: str = "."):
        self._contents_manager = contents_manager
        self._base_path = Path(base_path)

    @property
    def name(self) -> str:
        return "file_write"

    @property
    def description(self) -> str:
        return """Write content to a file.
Creates the file if it doesn't exist. Creates parent directories if needed."""

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "The file path to write (relative to workspace)",
                },
                "content": {
                    "type": "string",
                    "description": "The content to write",
                },
                "encoding": {
                    "type": "string",
                    "description": "File encoding (default: utf-8)",
                    "default": "utf-8",
                },
                "append": {
                    "type": "boolean",
                    "description": "Append to file instead of overwriting",
                    "default": False,
                },
            },
            "required": ["path", "content"],
        }

    @property
    def risk_level(self) -> str:
        return "high"

    async def execute(self, **kwargs: Any) -> ToolResult:
        """파일 내용을 씁니다."""
        path = kwargs.get("path", "")
        content = kwargs.get("content", "")
        encoding = kwargs.get("encoding", "utf-8")
        append = kwargs.get("append", False)

        if not path:
            return ToolResult(success=False, error="경로가 필요합니다")

        try:
            file_path = self._base_path / path

            # 필요시 상위 디렉토리 생성
            file_path.parent.mkdir(parents=True, exist_ok=True)

            mode = "a" if append else "w"
            with open(file_path, mode, encoding=encoding) as f:
                f.write(content)

            return ToolResult(
                success=True,
                data={"path": str(path), "operation": "append" if append else "write"},
                metadata={"size": len(content)},
            )

        except Exception as e:
            return ToolResult(success=False, error=f"파일 쓰기 오류: {str(e)}")


class FileListTool(BaseTool):
    """디렉토리 내용 목록 도구."""

    def __init__(self, contents_manager: Any, base_path: str = "."):
        self._contents_manager = contents_manager
        self._base_path = Path(base_path)

    @property
    def name(self) -> str:
        return "file_list"

    @property
    def description(self) -> str:
        return """List files and directories in a path.
Returns a list of file/directory names with their types."""

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "The directory path to list (relative to workspace)",
                    "default": ".",
                },
                "recursive": {
                    "type": "boolean",
                    "description": "List recursively",
                    "default": False,
                },
                "pattern": {
                    "type": "string",
                    "description": "Glob pattern to filter files (e.g., '*.py')",
                },
            },
        }

    @property
    def risk_level(self) -> str:
        return "low"

    async def execute(self, **kwargs: Any) -> ToolResult:
        """디렉토리 내용을 나열합니다."""
        path = kwargs.get("path", ".")
        recursive = kwargs.get("recursive", False)
        pattern = kwargs.get("pattern")

        try:
            dir_path = self._base_path / path
            if not dir_path.exists():
                return ToolResult(success=False, error=f"경로를 찾을 수 없음: {path}")

            if not dir_path.is_dir():
                return ToolResult(success=False, error=f"디렉토리가 아님: {path}")

            entries = []

            if pattern:
                if recursive:
                    files = dir_path.rglob(pattern)
                else:
                    files = dir_path.glob(pattern)
            else:
                if recursive:
                    files = dir_path.rglob("*")
                else:
                    files = dir_path.iterdir()

            for entry in files:
                rel_path = entry.relative_to(self._base_path)
                entries.append(
                    {
                        "name": entry.name,
                        "path": str(rel_path),
                        "type": "directory" if entry.is_dir() else "file",
                        "size": entry.stat().st_size if entry.is_file() else None,
                    }
                )

            return ToolResult(
                success=True,
                data={"entries": entries, "path": str(path)},
                metadata={"count": len(entries)},
            )

        except Exception as e:
            return ToolResult(success=False, error=f"디렉토리 목록 조회 오류: {str(e)}")
