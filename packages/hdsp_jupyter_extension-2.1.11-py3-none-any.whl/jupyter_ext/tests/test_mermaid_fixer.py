"""Tests for mermaid_fixer — deterministic Mermaid syntax repair."""

from jupyter_ext.agent.mermaid_fixer import fix_mermaid_blocks, fix_mermaid_code


# ---------------------------------------------------------------------------
# Category 1: Comments
# ---------------------------------------------------------------------------


def test_fix_comments():
    code = "graph TD\n  A --> B %% this is a comment\n  B --> C"
    result = fix_mermaid_code(code)
    assert "%%" not in result
    assert "A --> B" in result


def test_fix_comments_standalone_line():
    code = "graph TD\n  %% full line comment\n  A --> B"
    result = fix_mermaid_code(code)
    assert "%%" not in result


# ---------------------------------------------------------------------------
# Category 2: Reserved keyword `end`
# ---------------------------------------------------------------------------


def test_fix_end_keyword_as_node():
    code = "graph TD\n  start --> end"
    result = fix_mermaid_code(code)
    assert "end_node" in result


def test_fix_end_preserves_subgraph_closer():
    code = "graph TD\n  subgraph sub1\n    A --> B\n  end"
    result = fix_mermaid_code(code)
    # The standalone `end` (subgraph closer) must remain
    assert result.strip().endswith("end")


def test_fix_end_preserves_directive():
    code = "graph TD\n  class end myClass"
    result = fix_mermaid_code(code)
    # `end` inside a class directive must remain
    assert "class end" in result


# ---------------------------------------------------------------------------
# Category 3: Escaped quotes
# ---------------------------------------------------------------------------


def test_fix_escaped_quotes():
    code = 'A["hello \\"world\\""]'
    result = fix_mermaid_code(code)
    assert '\\"' not in result
    assert "&quot;" in result


# ---------------------------------------------------------------------------
# Category 4: Arrow syntax
# ---------------------------------------------------------------------------


def test_fix_single_arrow():
    code = "graph TD\n  A -> B"
    result = fix_mermaid_code(code)
    assert " --> " in result


def test_fix_dotted_arrow():
    code = "graph TD\n  A -. B"
    result = fix_mermaid_code(code)
    assert "-.-> " in result


def test_double_arrow_unchanged():
    code = "graph TD\n  A --> B"
    result = fix_mermaid_code(code)
    assert " --> " in result


# ---------------------------------------------------------------------------
# Category 5: Nested brackets
# ---------------------------------------------------------------------------


def test_fix_nested_brackets():
    code = 'graph TD\n  H["dask[dataframe] 설치"]'
    result = fix_mermaid_code(code)
    assert "&#91;" in result
    assert "&#93;" in result


def test_fix_misquoted_labels():
    """Misquoted: opening " but no matching closing "."""
    code = "graph TD\n  E[\"rcParams['family'\"] 설정]"
    result = fix_mermaid_code(code)
    # Should handle gracefully without crashing
    assert "E[" in result


# ---------------------------------------------------------------------------
# Category 6: Node labels
# ---------------------------------------------------------------------------


def test_fix_unquoted_node_label():
    code = "graph TD\n  A[Hello World]"
    result = fix_mermaid_code(code)
    assert '["Hello World"]' in result


def test_fix_already_quoted_label():
    code = 'graph TD\n  A["Hello World"]'
    result = fix_mermaid_code(code)
    assert '["Hello World"]' in result


def test_fix_subroutine_label():
    code = "graph TD\n  A[[My Process]]"
    result = fix_mermaid_code(code)
    assert '[["My Process"]]' in result


# ---------------------------------------------------------------------------
# Category 7: Edge labels
# ---------------------------------------------------------------------------


def test_fix_edge_labels_with_brackets():
    code = "graph TD\n  A -->|[text]| B"
    result = fix_mermaid_code(code)
    assert "&#91;" in result
    assert "&#93;" in result


def test_edge_labels_no_brackets_unchanged():
    code = "graph TD\n  A -->|yes| B"
    result = fix_mermaid_code(code)
    assert "|yes|" in result


# ---------------------------------------------------------------------------
# Category 8: Subgraph titles
# ---------------------------------------------------------------------------


def test_fix_subgraph_unquoted_title():
    code = "subgraph My Section\n  A --> B\nend"
    result = fix_mermaid_code(code)
    assert '"My Section"' in result


def test_subgraph_quoted_title_unchanged():
    code = 'subgraph "My Section"\n  A --> B\nend'
    result = fix_mermaid_code(code)
    assert '"My Section"' in result


# ---------------------------------------------------------------------------
# Category 9: Empty labels
# ---------------------------------------------------------------------------


def test_fix_empty_labels():
    code = 'graph TD\n  A[""] --> B'
    result = fix_mermaid_code(code)
    assert '[""]' not in result
    assert "A --> B" in result


# ---------------------------------------------------------------------------
# Category 10: Direction
# ---------------------------------------------------------------------------


def test_fix_invalid_direction():
    code = "graph TD\n  direction XX\n  A --> B"
    result = fix_mermaid_code(code)
    assert "direction TD" in result


def test_valid_direction_unchanged():
    for d in ("TB", "BT", "LR", "RL", "TD"):
        code = f"graph TD\n  direction {d}\n  A --> B"
        result = fix_mermaid_code(code)
        assert f"direction {d}" in result


# ---------------------------------------------------------------------------
# Category 11: Trailing semicolons
# ---------------------------------------------------------------------------


def test_fix_trailing_semicolons():
    code = "graph TD\n  A --> B;\n  B --> C;"
    result = fix_mermaid_code(code)
    assert ";" not in result


def test_no_semicolons_unchanged():
    code = "graph TD\n  A --> B\n  B --> C"
    result = fix_mermaid_code(code)
    assert result.strip() == code.strip()


# ---------------------------------------------------------------------------
# Category 12: Duplicate edges
# ---------------------------------------------------------------------------


def test_fix_duplicate_edges():
    code = "graph TD\n  A --> B\n  A --> B\n  B --> C"
    result = fix_mermaid_code(code)
    assert result.count("A --> B") == 1
    assert "B --> C" in result


def test_different_edges_preserved():
    code = "graph TD\n  A --> B\n  B --> C"
    result = fix_mermaid_code(code)
    assert "A --> B" in result
    assert "B --> C" in result


# ---------------------------------------------------------------------------
# Integration: fix_mermaid_blocks
# ---------------------------------------------------------------------------


def test_no_mermaid_passthrough():
    text = "Hello world, no mermaid here."
    assert fix_mermaid_blocks(text) == text


def test_multiple_blocks():
    text = (
        "Some text\n"
        "```mermaid\n"
        "graph TD\n  A -> B\n"
        "```\n"
        "Middle text\n"
        "```mermaid\n"
        "graph LR\n  C -> D\n"
        "```\n"
        "End text"
    )
    result = fix_mermaid_blocks(text)
    assert result.count("-->") == 2
    assert "Some text" in result
    assert "Middle text" in result
    assert "End text" in result


def test_composition_multiple_issues():
    """Multiple issues coexist in a single block."""
    code = (
        "graph TD\n"
        "  %% comment\n"
        "  start --> end;\n"
        "  A[Hello World] -> B\n"
        "  direction XX\n"
    )
    result = fix_mermaid_code(code)
    assert "%%" not in result
    assert "end_node" in result
    assert ";" not in result
    assert " --> " in result  # single arrow fixed
    assert "direction TD" in result
    assert '["Hello World"]' in result
