"""Tests for resource tier classification and guidance generation."""

from __future__ import annotations

import pytest

from ..resource_usage import (
    _classify_cpu,
    _classify_memory,
    _classify_single_gpu,
    _classify_gpu,
    classify_resource_tiers,
    generate_tier_guidance,
)


# ---------------------------------------------------------------------------
# CPU tier classification
# ---------------------------------------------------------------------------


class TestClassifyCPU:
    @pytest.mark.parametrize(
        "cores,expected",
        [
            (1, "low"),
            (2, "low"),
            (3, "low"),
            (4, "medium"),
            (7, "medium"),
            (8, "high"),
            (16, "high"),
            (31, "high"),
            (32, "very_high"),
            (56, "very_high"),
            (128, "very_high"),
            (2.5, "low"),  # fractional (K8s pod)
            (None, "unknown"),
        ],
    )
    def test_cpu_tiers(self, cores, expected):
        assert _classify_cpu(cores) == expected


# ---------------------------------------------------------------------------
# Memory tier classification
# ---------------------------------------------------------------------------


class TestClassifyMemory:
    @pytest.mark.parametrize(
        "total_gb,expected",
        [
            (2, "constrained"),
            (3.9, "constrained"),
            (4, "limited"),
            (15, "limited"),
            (16, "comfortable"),
            (63, "comfortable"),
            (64, "large"),
            (128, "large"),
            (255, "large"),
            (256, "very_large"),
            (900, "very_large"),
            (None, "unknown"),
        ],
    )
    def test_memory_tiers(self, total_gb, expected):
        assert _classify_memory(total_gb) == expected


# ---------------------------------------------------------------------------
# GPU tier classification
# ---------------------------------------------------------------------------


class TestClassifyGPU:
    @pytest.mark.parametrize(
        "name,vram_mb,expected",
        [
            ("NVIDIA L4", 24576, "entry"),
            ("Tesla T4", 16384, "entry"),
            ("Tesla V100-SXM2-16GB", 16384, "mid"),
            ("Tesla V100-SXM2-32GB", 32768, "high"),
            ("NVIDIA A100-SXM4-40GB", 40960, "high"),
            ("NVIDIA A100-SXM4-80GB", 81920, "ultra"),
            ("NVIDIA H100 80GB HBM3", 81920, "ultra"),
            ("NVIDIA H200", 144000, "ultra"),
            ("NVIDIA RTX 3060", 12288, "entry"),
            ("NVIDIA RTX 4090", 24576, "high"),
            ("Unknown GPU", 8192, "entry"),
            ("Unknown GPU", 32768, "high"),
            ("Unknown GPU", 49152, "ultra"),
        ],
    )
    def test_single_gpu_tiers(self, name, vram_mb, expected):
        assert _classify_single_gpu(name, vram_mb) == expected

    def test_no_gpu(self):
        result = _classify_gpu([])
        assert result["tier"] == "none"
        assert result["count"] == 0

    def test_single_gpu(self):
        gpus = [{"name": "NVIDIA A100-SXM4-80GB", "memory_total_mb": 81920}]
        result = _classify_gpu(gpus)
        assert result["tier"] == "ultra"
        assert result["count"] == 1
        assert not result["multi_gpu"]

    def test_multi_gpu(self):
        gpus = [
            {"name": "NVIDIA H200", "memory_total_mb": 144000},
            {"name": "NVIDIA H200", "memory_total_mb": 144000},
            {"name": "NVIDIA H200", "memory_total_mb": 144000},
            {"name": "NVIDIA H200", "memory_total_mb": 144000},
        ]
        result = _classify_gpu(gpus)
        assert result["tier"] == "ultra"
        assert result["count"] == 4
        assert result["multi_gpu"]


# ---------------------------------------------------------------------------
# classify_resource_tiers integration
# ---------------------------------------------------------------------------


class TestClassifyResourceTiers:
    def _make_data(self, cores=8, total_gb=32, avail_gb=24, gpus=None):
        return {
            "cpu": {"cores": cores, "usage_percent": 30.0},
            "memory": {
                "total_gb": total_gb,
                "available_gb": avail_gb,
                "used_gb": total_gb - avail_gb,
            },
            "gpus": gpus or [],
            "gpu_status": "available" if gpus else "not_detected",
        }

    def test_mid_workstation(self):
        tiers = classify_resource_tiers(
            self._make_data(cores=7, total_gb=128, avail_gb=100)
        )
        assert tiers["cpu_tier"] == "medium"
        assert tiers["mem_tier"] == "large"
        assert tiers["gpu"]["tier"] == "none"

    def test_high_server(self):
        gpus = [
            {"name": "NVIDIA A100-SXM4-80GB", "memory_total_mb": 81920},
            {"name": "NVIDIA A100-SXM4-80GB", "memory_total_mb": 81920},
        ]
        tiers = classify_resource_tiers(
            self._make_data(cores=56, total_gb=900, avail_gb=850, gpus=gpus)
        )
        assert tiers["cpu_tier"] == "very_high"
        assert tiers["mem_tier"] == "very_large"
        assert tiers["gpu"]["tier"] == "ultra"
        assert tiers["gpu"]["multi_gpu"]

    def test_low_container(self):
        tiers = classify_resource_tiers(
            self._make_data(cores=2, total_gb=4, avail_gb=2)
        )
        assert tiers["cpu_tier"] == "low"
        assert tiers["mem_tier"] == "limited"


# ---------------------------------------------------------------------------
# Guidance generation — differentiation tests
# ---------------------------------------------------------------------------


class TestGenerateTierGuidance:
    def _make_data(self, cores=8, total_gb=32, avail_gb=24, gpus=None):
        return {
            "cpu": {"cores": cores, "usage_percent": 30.0},
            "memory": {
                "total_gb": total_gb,
                "available_gb": avail_gb,
                "used_gb": total_gb - avail_gb,
            },
            "gpus": gpus or [],
            "gpu_status": "available" if gpus else "not_detected",
        }

    def test_scenario_a_mid_workstation_with_l4(self):
        """7코어/128GB/L4 → Polars 권장, joblib, LoRA"""
        gpus = [{"name": "NVIDIA L4", "memory_total_mb": 24576}]
        tiers = classify_resource_tiers(
            self._make_data(cores=7, total_gb=128, avail_gb=100, gpus=gpus)
        )
        guidance = generate_tier_guidance(tiers)

        assert "joblib" in guidance
        assert "n_jobs=6" in guidance or "n_jobs" in guidance
        assert "Polars" in guidance
        assert "LoRA" in guidance or "entry" in guidance

    def test_scenario_b_high_server_with_a100(self):
        """56코어/900GB/A100x2 → Dask/Ray, cuDF, DDP"""
        gpus = [
            {"name": "NVIDIA A100-SXM4-80GB", "memory_total_mb": 81920},
            {"name": "NVIDIA A100-SXM4-80GB", "memory_total_mb": 81920},
        ]
        tiers = classify_resource_tiers(
            self._make_data(cores=56, total_gb=900, avail_gb=850, gpus=gpus)
        )
        guidance = generate_tier_guidance(tiers)

        assert "Dask" in guidance or "Ray" in guidance
        assert "cuDF" in guidance or "cudf" in guidance.lower()
        assert "DDP" in guidance or "FSDP" in guidance or "멀티GPU" in guidance
        assert "서버급" in guidance

    def test_scenario_c_high_server_no_gpu(self):
        """56코어/900GB/GPU없음 → Dask/Ray CPU, Polars 멀티스레드"""
        tiers = classify_resource_tiers(
            self._make_data(cores=56, total_gb=900, avail_gb=850)
        )
        guidance = generate_tier_guidance(tiers)

        assert "Dask" in guidance or "Ray" in guidance
        assert "Polars" in guidance
        assert "GPU 미감지" in guidance
        assert "device='cpu'" in guidance or "CPU" in guidance

    def test_scenario_d_low_container(self):
        """2코어/4GB/GPU없음 → chunked, 병렬처리 비권장"""
        tiers = classify_resource_tiers(
            self._make_data(cores=2, total_gb=4, avail_gb=2)
        )
        guidance = generate_tier_guidance(tiers)

        assert "저사양" in guidance
        assert "병렬처리" in guidance
        assert "dtypes" in guidance or "chunked" in guidance

    def test_scenarios_produce_different_guidance(self):
        """핵심: 서로 다른 환경은 확실히 다른 가이드를 생성해야 함."""
        gpus_l4 = [{"name": "NVIDIA L4", "memory_total_mb": 24576}]
        gpus_a100 = [
            {"name": "NVIDIA A100-SXM4-80GB", "memory_total_mb": 81920},
            {"name": "NVIDIA A100-SXM4-80GB", "memory_total_mb": 81920},
        ]

        tiers_a = classify_resource_tiers(
            self._make_data(cores=7, total_gb=128, avail_gb=100, gpus=gpus_l4)
        )
        tiers_b = classify_resource_tiers(
            self._make_data(cores=56, total_gb=900, avail_gb=850, gpus=gpus_a100)
        )

        guidance_a = generate_tier_guidance(tiers_a)
        guidance_b = generate_tier_guidance(tiers_b)

        # Must be substantially different
        assert guidance_a != guidance_b

        # Scenario A should NOT contain server-grade terms
        assert "서버급" not in guidance_a
        assert "Spark" not in guidance_a

        # Scenario B should NOT contain low-tier terms
        assert "저사양" not in guidance_b
        assert "LoRA" not in guidance_b

    def test_mode_codegen_differs_from_review(self):
        """codegen 모드는 다른 헤더를 사용."""
        tiers = classify_resource_tiers(self._make_data())
        review = generate_tier_guidance(tiers, mode="review")
        codegen = generate_tier_guidance(tiers, mode="codegen")

        assert "환경 맞춤 기술 스택 권장" in review
        assert "기술 스택 지침" in codegen

    def test_memory_pressure_warning(self):
        """가용 메모리가 전체의 30% 미만일 때 경고 출력."""
        tiers = classify_resource_tiers(
            self._make_data(cores=16, total_gb=128, avail_gb=10)
        )
        guidance = generate_tier_guidance(tiers)

        assert "메모리 압박" in guidance

    def test_h200_multi_gpu_guidance(self):
        """4x H200 → tensor parallelism, FSDP"""
        gpus = [{"name": "NVIDIA H200", "memory_total_mb": 144000}] * 4
        tiers = classify_resource_tiers(
            self._make_data(cores=56, total_gb=900, avail_gb=850, gpus=gpus)
        )
        guidance = generate_tier_guidance(tiers)

        assert "FSDP" in guidance or "DeepSpeed" in guidance
        assert "멀티GPU" in guidance
        assert "tensor" in guidance.lower() or "pipeline" in guidance.lower()
