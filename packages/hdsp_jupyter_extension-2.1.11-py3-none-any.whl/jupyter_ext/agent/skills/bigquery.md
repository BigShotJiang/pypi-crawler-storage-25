---
name: bigquery
description: BigQuery 전문가 기본 가이드. 세부 가이드는 bigquery_tuning, bigquery_oracle 참조.
---

# BigQuery Expert Guide

BQ agent의 3대 역할별 세부 가이드:

| 요청 유형 | 로드할 스킬 | 설명 |
|-----------|------------|------|
| 성능 튜닝 / 비용 최적화 / anti-pattern | `bigquery_tuning` | 900-slot 최적화, anti-pattern 10종, 비용 공식, INFORMATION_SCHEMA |
| Oracle → BQ 변환 | `bigquery_oracle` | 구문 매핑, 실행 모델 비교, Hint 대체, anti-pattern 체크 |
| 쿼리 오류 수정 | `bigquery_tuning` | anti-pattern 탐지 + 비용/성능 분석으로 오류 원인 진단 |

## 사용법
1. 요청 유형 판단
2. `load_skill('bigquery_tuning')` 또는 `load_skill('bigquery_oracle')` 호출
3. 두 가지 모두 필요하면 둘 다 호출

## ⚠️ 필수: Mermaid 시각화

**모든 BQ 응답에는 반드시 ```mermaid 다이어그램을 포함하세요.** 시각화 없는 응답은 불완전합니다.
