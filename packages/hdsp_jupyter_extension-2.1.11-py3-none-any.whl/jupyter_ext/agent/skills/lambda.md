---
name: lambda
description: Lambda 전문가 기본 가이드. 세부 가이드는 lambda_tuning, lambda_log 참조.
---

# Lambda Expert Guide

Lambda agent의 3대 역할별 세부 가이드:

| 요청 유형 | 로드할 스킬 | 설명 |
|-----------|------------|------|
| Cold Start 최적화 / 메모리·타임아웃 튜닝 / 비용 최적화 | `lambda_tuning` | Provisioned Concurrency, SnapStart, Power Tuning, ARM64 |
| CloudWatch 로그 / X-Ray 트레이스 / Duration·Memory 분석 | `lambda_log` | Logs Insights 쿼리, REPORT 라인 파싱, 에러 패턴 |
| 함수 코드 생성 / SAM 템플릿 | `lambda-function` | 기존 Lambda 개발 가이드 |

## 사용법
1. 요청 유형 판단
2. 해당 스킬 로드
3. 복합 요청(튜닝+로그)이면 둘 다 로드
