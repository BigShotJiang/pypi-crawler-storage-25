---
name: emr_log
description: EMR 로그 분석. Spark UI 메트릭, YARN 로그, CloudWatch EMR 메트릭, OOM/GC/Fetch Failure 패턴.
---

# EMR Spark Log Analysis Guide

EMR Spark 작업 로그, Spark UI 메트릭, YARN 로그, 에러 패턴 분석 레퍼런스입니다.

---

## 1. Spark UI 메트릭 분석

### Jobs 탭
| 메트릭 | 의미 | 경고 기준 |
|--------|------|----------|
| Duration | 잡 전체 실행 시간 | 예상 대비 2배 이상 |
| Stages | 잡 내 스테이지 수 | 과다 셔플 → 스테이지 많음 |
| Tasks (failed) | 실패한 태스크 수 | > 0 → 원인 분석 필요 |

### Stages 탭
| 메트릭 | 의미 | 최적화 포인트 |
|--------|------|-------------|
| Shuffle Read | 셔플 입력 크기 | 대량 → 파티션 수 조절 |
| Shuffle Write | 셔플 출력 크기 | 파티션 키 최적화 |
| GC Time | GC 총 시간 | Task Duration의 10% 이상 → 메모리 부족 |
| Peak Execution Memory | 최대 실행 메모리 | Executor 메모리의 70% 이상 → 위험 |
| Input Size | 입력 데이터 크기 | 컬럼 프루닝 확인 |

### Tasks 탭 (Stage 상세)
| 메트릭 | 의미 | Skew 의심 기준 |
|--------|------|---------------|
| Duration | 태스크 실행 시간 | Max/Median > 3배 → Skew |
| Shuffle Read Size | 태스크별 셔플 입력 | Max/Median > 5배 → Skew |
| Spill (Memory) | 메모리 스필 크기 | > 0 → 메모리 부족 |
| Spill (Disk) | 디스크 스필 크기 | > 0 → 파티션 감소 필요 |

### SQL 탭
```
Physical Plan 노드별 메트릭:
- number of output rows: 실제 처리 행 수
- number of files read: 파일 스캔 수
- size of files read: 스캔 바이트 수
- scan time total: 스캔 소요 시간
```

---

## 2. YARN 로그 분석

### 로그 위치

| 로그 유형 | S3 경로 | 설명 |
|----------|---------|------|
| Step 로그 | `s3://log-bucket/j-XXXXX/steps/s-XXXXX/` | Step 실행 로그 |
| Container 로그 | `s3://log-bucket/j-XXXXX/containers/` | Executor 로그 |
| Driver stdout | `steps/s-XXXXX/stdout.gz` | Driver 표준 출력 |
| Driver stderr | `steps/s-XXXXX/stderr.gz` | Driver 에러 출력 |
| Executor stderr | `containers/application_XXX/container_XXX/stderr.gz` | Executor 에러 |

### YARN 명령어 (EMR 마스터 노드)
```bash
# 애플리케이션 목록
yarn application -list -appStates ALL

# 애플리케이션 로그 수집
yarn logs -applicationId application_XXXX_XXXX -out /tmp/app_logs/

# 특정 컨테이너 로그
yarn logs -applicationId application_XXXX_XXXX \
  -containerId container_XXXX_XXXX

# YARN 리소스 상태
yarn node -list -showDetails
```

### 주요 로그 패턴 (grep 키워드)
```bash
# OOM 탐지
grep -i "OutOfMemoryError\|java.lang.OutOfMemoryError\|Container killed" stderr.gz

# GC 과다
grep -i "GC overhead limit exceeded" stderr.gz

# Fetch Failure
grep -i "FetchFailedException\|Failed to connect" stderr.gz

# Lost Executor
grep -i "Lost executor\|ExecutorLostFailure" stderr.gz

# Disk Space
grep -i "No space left\|DiskSpaceExhausted" stderr.gz

# S3 에러
grep -i "AmazonS3Exception\|SlowDown\|503" stderr.gz
```

---

## 3. CloudWatch EMR 메트릭

### 클러스터 레벨 메트릭

| 메트릭 | 설명 | 경고 기준 |
|--------|------|----------|
| `IsIdle` | 클러스터 유휴 여부 | 장시간 유휴 → 비용 낭비 |
| `AppsRunning` | 실행 중 앱 수 | 동시 실행 과다 → 리소스 부족 |
| `AppsPending` | 대기 중 앱 수 | > 0 지속 → 클러스터 확장 필요 |
| `ContainerAllocated` | 할당된 컨테이너 수 | 최대치 지속 → 확장 필요 |
| `ContainerPending` | 대기 컨테이너 수 | > 0 → 리소스 부족 |
| `MemoryAvailableMB` | 가용 메모리 | < 10% → 메모리 부족 |
| `HDFSUtilization` | HDFS 사용률 | > 80% → 디스크 부족 |

### 노드 레벨 메트릭

| 메트릭 | 설명 | 경고 기준 |
|--------|------|----------|
| `CPUUtilization` | CPU 사용률 | > 90% 지속 → CPU 병목 |
| `MemoryUsedPercent` | 메모리 사용률 | > 85% → OOM 위험 |
| `DiskSpaceUtilization` | 디스크 사용률 | > 80% → 스필 실패 가능 |
| `NetworkBytesIn/Out` | 네트워크 I/O | 셔플 병목 확인 |

### CloudWatch Logs Insights (EMR)
```
-- EMR Step 실행 시간 분석
fields @timestamp, @message
| filter @message like /Completed step/
| parse @message "Completed step * in * seconds" as stepName, duration
| sort duration desc
```

---

## 4. 에러 패턴 진단

### OOM (OutOfMemoryError)

**증상**: `java.lang.OutOfMemoryError: Java heap space`

**원인별 대응**:
| 원인 | 진단 | 해결 |
|------|------|------|
| Executor 메모리 부족 | Spark UI > GC Time 높음 | `spark.executor.memory` 증가 |
| Driver에서 collect() | Driver OOM | `take(n)` 사용, 집계 후 수집 |
| Broadcast 테이블 과대 | Driver OOM | broadcast threshold 감소 |
| 데이터 Skew | Task Duration 불균형 | AQE Skew Join, Salting |
| 메모리 오버헤드 부족 | Container killed by YARN | `spark.executor.memoryOverhead` 증가 |

### Fetch Failure

**증상**: `org.apache.spark.shuffle.FetchFailedException`

**원인별 대응**:
| 원인 | 진단 | 해결 |
|------|------|------|
| Executor 비정상 종료 | Lost executor 로그 | OOM 해결 우선 |
| 네트워크 타임아웃 | Connection refused | `spark.shuffle.io.maxRetries` 증가 |
| 디스크 공간 부족 | No space left | 인스턴스 EBS 크기 증가 |
| GC 지연 | GC Time 과다 | 메모리 증가 또는 G1GC |

### S3 Throttling

**증상**: `503 SlowDown`, `AmazonS3Exception`

**대응**:
```python
# S3 요청 분산
spark.conf.set("spark.hadoop.fs.s3a.retry.limit", "20")
spark.conf.set("spark.hadoop.fs.s3a.retry.interval", "500ms")

# S3 prefix 분산 (파티셔닝)
# 단일 prefix에 집중 방지
```

---

## 5. Ganglia 메트릭 (EMR 클러스터)

### 주요 차트

| 차트 | 해석 | 최적화 |
|------|------|--------|
| CPU Usage | 전체 CPU 사용률 | 100% 지속 → 노드/코어 추가 |
| Memory Usage | 메모리 사용 추이 | 급증 → Skew 또는 캐시 확인 |
| Network I/O | 네트워크 트래픽 | 셔플 단계에서 급증 정상 |
| Disk I/O | 디스크 읽기/쓰기 | 스필 시 급증 → 메모리 부족 |
| Load Average | 시스템 부하 | > 노드 코어 수 → 과부하 |

---

## 6. EMR Step 로그 분석

### Step 상태 확인
```bash
aws emr list-steps --cluster-id j-XXXXX \
  --step-states FAILED CANCELLED

aws emr describe-step --cluster-id j-XXXXX --step-id s-XXXXX
```

### Step 실패 유형

| 실패 메시지 | 원인 | 해결 |
|-------------|------|------|
| `Step failed with non-zero exit code 1` | 스크립트 오류 | stderr.gz 확인 |
| `Cancelled while Pending` | 선행 Step 실패 | `ActionOnFailure` 설정 확인 |
| `Container killed by YARN` | OOM | 메모리 설정 조정 |
| `Application was killed` | 타임아웃/수동 중단 | Step timeout 확인 |

---

## 7. 성능 분석 체크리스트

```
□ Spark UI > Stages: GC Time < Duration의 10%
□ Spark UI > Tasks: Duration 분포 균일 (Skew 없음)
□ Spark UI > Tasks: Spill (Disk) = 0 (메모리 충분)
□ Spark UI > SQL: Scan Files/Bytes 확인 (프루닝 효과)
□ YARN > ContainerPending = 0 (리소스 충분)
□ CloudWatch > CPU < 90% 지속
□ CloudWatch > Memory > 15% 여유
□ S3 > 503 SlowDown 없음
□ stderr > OOM/FetchFailed 없음
□ AQE 적용 여부 확인 (SQL 탭)
```
