---
name: lambda_tuning
description: Lambda 성능 튜닝. Cold Start 최적화, 메모리-CPU 상관관계, Provisioned Concurrency, SnapStart, Power Tuning, ARM64.
---

# Lambda Performance Tuning Guide

Lambda 함수 성능 최적화, Cold Start 제거, 비용 최적화 레퍼런스입니다.

---

## 1. Cold Start 최적화

### Cold Start 발생 조건
- 새로운 실행 환경 프로비저닝 시
- 스케일 아웃 (동시성 증가) 시
- 코드 업데이트 배포 직후
- 장시간 미사용 후 (실행 환경 회수)

### Cold Start 시간 구성
```
Cold Start = Runtime Init + Handler Init + 코드 다운로드
           = (런타임 부팅) + (전역 초기화) + (S3 → /var/task)
```

### 최적화 전략

| 전략 | 효과 | 구현 |
|------|------|------|
| SDK 클라이언트 외부 초기화 | 연결 재사용 | `boto3.client()` 핸들러 밖 |
| 필요한 모듈만 import | 초기화 시간 감소 | Lazy import 패턴 |
| 배포 패키지 최소화 | 다운로드 시간 감소 | .pyc 포함, 불필요 파일 제거 |
| Layer 활용 | 공통 라이브러리 캐싱 | 자주 바뀌지 않는 의존성 분리 |
| ARM64 (Graviton2) | 20% 비용 절감 | `Architectures: [arm64]` |

### 코드 패턴
```python
# ✅ 올바른 패턴: 핸들러 밖에서 초기화
import boto3
import os

# 전역 초기화 (Cold Start 시 1회만 실행)
TABLE_NAME = os.environ["TABLE_NAME"]
dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table(TABLE_NAME)

def handler(event, context):
    # Warm Start: 위 객체 재사용
    return table.get_item(Key={"id": event["id"]})
```

```python
# ❌ 잘못된 패턴: 매 호출마다 초기화
def handler(event, context):
    dynamodb = boto3.resource("dynamodb")  # 매번 새 연결
    table = dynamodb.Table(os.environ["TABLE_NAME"])
    return table.get_item(Key={"id": event["id"]})
```

---

## 2. 메모리-CPU 상관관계

### 메모리별 CPU/네트워크 할당

| 메모리 (MB) | vCPU | 네트워크 | 권장 용도 |
|-------------|------|----------|----------|
| 128 | 1/10 | 제한적 | 최소 작업 |
| 256 | 1/6 | 제한적 | 간단한 API |
| 512 | 1/3 | 보통 | 일반 API |
| 1024 | ~0.6 | 보통 | 데이터 처리 |
| 1769 | 1 vCPU | 풀 | **최적 성능/비용 비율** |
| 3538 | 2 vCPU | 풀 | 멀티스레드 |
| 5307 | 3 vCPU | 풀 | CPU 집약 |
| 10240 | 6 vCPU | 풀 | 대용량 처리 |

### 비용 공식
```
비용 = 요청 수 × $0.20/1M + GB-초 × $0.0000166667
GB-초 = (메모리 MB / 1024) × Duration(초)

예: 256MB, 200ms, 100만 호출/월
= $0.20 + (0.25 × 0.2 × 1,000,000 × $0.0000166667)
= $0.20 + $0.83 = $1.03/월
```

### Power Tuning
```bash
# AWS Lambda Power Tuning (Step Functions 기반)
# 1. SAR에서 배포
# 2. 다양한 메모리 설정으로 자동 테스트
# 3. 비용 vs 성능 최적점 시각화

# 입력 예시:
{
  "lambdaARN": "arn:aws:lambda:...:my-function",
  "powerValues": [128, 256, 512, 1024, 1769, 3008],
  "num": 50,
  "payload": {"key": "value"},
  "parallelInvocation": true
}
```

---

## 3. Provisioned Concurrency

### 설정 시나리오
```yaml
# SAM template
Resources:
  MyFunction:
    Type: AWS::Serverless::Function
    Properties:
      AutoPublishAlias: live
      ProvisionedConcurrencyConfig:
        ProvisionedConcurrentExecutions: 10

  # 스케줄 기반 자동 조절
  ScalingTarget:
    Type: AWS::ApplicationAutoScaling::ScalableTarget
    Properties:
      MaxCapacity: 50
      MinCapacity: 5
      ResourceId: !Sub function:${MyFunction}:live
      ScalableDimension: lambda:function:ProvisionedConcurrency

  ScalingPolicy:
    Type: AWS::ApplicationAutoScaling::ScalingPolicy
    Properties:
      TargetTrackingScalingPolicyConfiguration:
        TargetValue: 0.7  # 70% 사용률 유지
        PredefinedMetricSpecification:
          PredefinedMetricType: LambdaProvisionedConcurrencyUtilization
```

### 비용 영향
```
Provisioned Concurrency 비용:
= 프로비저닝 인스턴스 × GB-시간 × $0.0000041667
  + 실제 호출 × Duration × $0.0000097222/GB-초

vs On-Demand:
= 호출 × Duration × $0.0000166667/GB-초

손익분기점: ~60% 사용률 이상이면 Provisioned가 유리
```

---

## 4. SnapStart (Java 전용)

### 적용
```yaml
# SAM template
Resources:
  JavaFunction:
    Type: AWS::Serverless::Function
    Properties:
      Runtime: java21
      SnapStart:
        ApplyOn: PublishedVersions
      AutoPublishAlias: live
```

### 제한사항
- Java 11/17/21 런타임만 지원
- 512MB 이상 메모리 권장
- 고유성 관련 주의 (스냅샷 복원 → Random/UUID 재초기화 필요)
- `/tmp` 내용 미보존

---

## 5. ARM64 (Graviton2) 마이그레이션

### 전환 방법
```yaml
# SAM template
Resources:
  MyFunction:
    Type: AWS::Serverless::Function
    Properties:
      Architectures:
        - arm64  # x86_64 → arm64
```

### 호환성 체크리스트
```
□ 네이티브 확장 없는 순수 Python/Node.js → 즉시 전환 가능
□ C 확장 포함 (numpy, pandas 등) → arm64 빌드 필요
□ Layer → arm64 호환 Layer로 교체
□ Docker 기반 → multi-arch 빌드 설정
□ 성능 테스트 → 일부 워크로드에서 최대 34% 성능 향상
```

---

## 6. Anti-Pattern

| # | Anti-Pattern | 문제 | 올바른 방법 |
|---|-------------|------|------------|
| 1 | 핸들러 내부 SDK 초기화 | 매 호출 새 연결 | 전역 초기화 |
| 2 | 전체 SDK import | `import boto3` 후 전부 로드 | 필요한 서비스만 |
| 3 | 동기식 대기 (polling) | Duration 낭비 | Step Functions / SQS |
| 4 | VPC 내 Lambda + 미사용 | Cold Start 추가 ENI 생성 | VPC 필요 시만 사용 |
| 5 | 대용량 /tmp 사용 (>512MB) | 추가 비용 발생 | S3/EFS 활용 |
| 6 | 무한 재시도 | 비용 폭발 | Dead Letter Queue 설정 |
| 7 | 환경변수 미사용 하드코딩 | 배포 유연성 저하 | `os.environ` 활용 |
| 8 | 로그 과다 출력 | CloudWatch 비용 증가 | 로그 레벨 관리 |
