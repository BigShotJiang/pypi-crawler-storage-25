---
name: lambda_log
description: Lambda 로그 분석. CloudWatch Logs Insights 쿼리, X-Ray 트레이스, REPORT 라인 파싱, Duration/Memory 분석.
---

# Lambda Log Analysis Guide

Lambda 함수 CloudWatch 로그, X-Ray 트레이스, 성능 메트릭 분석 레퍼런스입니다.

---

## 1. REPORT 라인 파싱

### REPORT 라인 구조
```
REPORT RequestId: xxx
Duration: 215.42 ms
Billed Duration: 216 ms
Memory Size: 256 MB
Max Memory Used: 128 MB
Init Duration: 432.17 ms    ← Cold Start 시에만 출력
```

### 핵심 필드 해석

| 필드 | 의미 | 경고 기준 |
|------|------|----------|
| `Duration` | 실제 실행 시간 | Timeout의 80% 이상 |
| `Billed Duration` | 과금 시간 (1ms 단위 올림) | Duration 대비 큰 차이 |
| `Memory Size` | 할당 메모리 | - |
| `Max Memory Used` | 실제 사용 메모리 | Memory Size의 90% 이상 → OOM 위험 |
| `Init Duration` | Cold Start 시간 | > 1s → 최적화 필요 |
| `XRAY TraceId` | X-Ray 트레이스 ID | 분산 추적용 |

---

## 2. CloudWatch Logs Insights 쿼리

### 기본 분석
```
-- Cold Start 비율
filter @type = "REPORT"
| stats count(*) as total,
        sum(ispresent(@initDuration)) as coldStarts,
        avg(@initDuration) as avgColdStart,
        max(@initDuration) as maxColdStart
| display total, coldStarts,
          coldStarts * 100.0 / total as coldStartPct,
          avgColdStart, maxColdStart
```

### Duration 분석
```
-- Duration 퍼센타일
filter @type = "REPORT"
| stats avg(@duration) as avgDuration,
        pct(@duration, 50) as p50,
        pct(@duration, 90) as p90,
        pct(@duration, 95) as p95,
        pct(@duration, 99) as p99,
        max(@duration) as maxDuration
```

### Memory 분석
```
-- 메모리 사용률 분석
filter @type = "REPORT"
| stats avg(@maxMemoryUsed / @memorySize * 100) as avgMemPct,
        max(@maxMemoryUsed / @memorySize * 100) as maxMemPct,
        min(@maxMemoryUsed) as minMemUsed,
        max(@maxMemoryUsed) as maxMemUsed
```

### 에러 분석
```
-- 에러 유형별 집계
filter @message like /(?i)(error|exception|traceback|timeout)/
| parse @message /(?<errorType>\w+Error|\w+Exception)/
| stats count(*) as errorCount by errorType
| sort errorCount desc
```

### 타임아웃 탐지
```
-- 타임아웃 발생 탐지
filter @message like "Task timed out"
| parse @message "* Task timed out after * seconds" as requestId, timeoutSec
| sort @timestamp desc
| limit 20
```

### 시간대별 호출 패턴
```
-- 시간대별 호출량 + 평균 Duration
filter @type = "REPORT"
| stats count(*) as invocations,
        avg(@duration) as avgDuration,
        sum(@billedDuration) / 1000 as totalBilledSec
  by bin(1h) as timeSlot
| sort timeSlot
```

### Provisioned Concurrency 효과 분석
```
-- PC 적용 전후 비교
filter @type = "REPORT"
| fields ispresent(@initDuration) as isColdStart
| stats count(*) as total,
        sum(isColdStart) as coldStarts,
        avg(@duration) as avgDuration
  by bin(1d) as day
| sort day
```

---

## 3. X-Ray 트레이스 분석

### X-Ray 주요 세그먼트

| 세그먼트 | 설명 | 최적화 포인트 |
|----------|------|-------------|
| `Initialization` | Cold Start 초기화 | SDK 외부 초기화 |
| `Invocation` | 핸들러 실행 | 비즈니스 로직 최적화 |
| `Overhead` | Lambda 오버헤드 | 제어 불가 |
| `AWS::DynamoDB` | DynamoDB 호출 | 배치 연산, DAX 캐시 |
| `AWS::S3` | S3 호출 | 멀티파트, Transfer Acceleration |
| `AWS::SQS` | SQS 호출 | 배치 크기 조절 |

### X-Ray 서비스 맵 해석
```
Lambda → DynamoDB   (50ms avg)
      → S3          (200ms avg)  ← 병목!
      → SQS         (10ms avg)
```

### X-Ray SDK 계측
```python
from aws_xray_sdk.core import patch_all
patch_all()  # boto3 호출 자동 추적

# 커스텀 서브세그먼트
from aws_xray_sdk.core import xray_recorder

@xray_recorder.capture("process_data")
def process_data(data):
    # 이 함수의 실행 시간이 X-Ray에 기록됨
    ...
```

---

## 4. 에러 패턴 진단

### 주요 에러 유형

| 에러 | 원인 | 해결 |
|------|------|------|
| `Task timed out` | Timeout 초과 | Timeout 증가 또는 로직 최적화 |
| `Runtime.OutOfMemory` | 메모리 부족 | 메모리 증가, 대용량 처리 분할 |
| `Runtime.ImportModuleError` | 모듈 미설치 | Layer/패키지 확인 |
| `Runtime.HandlerNotFound` | 핸들러 경로 오류 | Handler 설정 확인 |
| `TooManyRequestsException` | 동시성 제한 초과 | Reserved Concurrency 증가 |
| `KMSAccessDeniedException` | KMS 키 접근 불가 | IAM 권한 확인 |
| `InvalidParameterValueException` | 잘못된 설정값 | 환경변수/설정 확인 |
| `ENOMEM (Container)` | 컨테이너 OOM | 메모리 할당 증가 |

### OOM 진단 쿼리
```
-- OOM 직전 메모리 사용 추적
filter @type = "REPORT"
| filter @maxMemoryUsed / @memorySize > 0.85
| fields @timestamp, @requestId,
         @maxMemoryUsed / 1048576 as usedMB,
         @memorySize / 1048576 as allocMB,
         @maxMemoryUsed / @memorySize * 100 as usagePct
| sort usagePct desc
| limit 20
```

### Throttle 진단 쿼리
```
-- CloudWatch 메트릭 기반 Throttle 확인
-- Lambda > Metrics > Throttles

-- Logs Insights로 재시도 탐지
filter @message like "Rate exceeded"
    or @message like "TooManyRequestsException"
| stats count(*) as throttleCount by bin(5m)
| sort throttleCount desc
```

---

## 5. Lambda Insights 메트릭

### 주요 메트릭 (Lambda Insights 확장)

| 메트릭 | 설명 | 경고 기준 |
|--------|------|----------|
| `cpu_total_time` | CPU 사용 시간 | Duration의 90% 이상 → CPU bound |
| `memory_utilization` | 메모리 사용률 (%) | > 85% → 메모리 증가 |
| `rx_bytes` / `tx_bytes` | 네트워크 I/O | 비정상 증가 → 외부 호출 검토 |
| `fd_use` / `fd_max` | 파일 디스크립터 | fd_use/fd_max > 0.8 → 리소스 누수 |
| `threads` | 스레드 수 | 지속 증가 → 스레드 누수 |
| `tmp_used` | /tmp 사용량 | > 400MB → 정리 필요 |

### Insights 활성화 (SAM)
```yaml
Resources:
  MyFunction:
    Type: AWS::Serverless::Function
    Properties:
      Layers:
        - !Sub arn:aws:lambda:${AWS::Region}:580247275435:layer:LambdaInsightsExtension:38
      Policies:
        - CloudWatchLambdaInsightsExecutionRolePolicy
```

---

## 6. 성능 분석 체크리스트

```
□ REPORT 라인에서 Init Duration 확인 (Cold Start 여부)
□ Memory 사용률 확인 (Max Memory Used / Memory Size)
□ Duration 퍼센타일 분석 (p50, p90, p99)
□ 에러율 추이 확인
□ Timeout 발생 빈도 확인
□ X-Ray 서비스 맵에서 병목 식별
□ Cold Start 비율 확인 (< 5% 목표)
□ Throttle 발생 여부 확인
□ Provisioned Concurrency 필요성 평가
□ Power Tuning으로 최적 메모리 설정 확인
```
