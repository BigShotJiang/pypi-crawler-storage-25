---
name: spring_tuning
description: Spring Boot 성능 튜닝. JVM GC(G1/ZGC), HikariCP, Cache, Async/Virtual Threads, N+1 쿼리, Hibernate 튜닝.
---

# Spring Boot Performance Tuning Guide

Spring Boot 애플리케이션 JVM, DB, Cache, Thread 성능 최적화 레퍼런스입니다.

---

## 1. JVM GC 튜닝

### GC 알고리즘 선택

| GC | 적합 용도 | 장점 | 단점 |
|----|----------|------|------|
| G1GC | **범용 서버** (기본) | 균형 잡힌 처리량/지연 | 힙 < 4GB에서는 과잉 |
| ZGC | **저지연 필수** (API 서버) | pause < 1ms | 처리량 약간 감소 |
| Shenandoah | 저지연 대안 | ZGC 유사 | OpenJDK만 |
| ParallelGC | **배치/처리량 우선** | 최대 처리량 | 긴 pause |

### G1GC 튜닝
```bash
java \
  -XX:+UseG1GC \
  -Xms2g -Xmx2g \                      # 힙 크기 고정 (Min=Max)
  -XX:MaxGCPauseMillis=200 \            # 목표 pause 시간
  -XX:G1HeapRegionSize=16m \            # Region 크기 (힙/2048)
  -XX:InitiatingHeapOccupancyPercent=45 \  # Mixed GC 시작 점유율
  -XX:G1MixedGCCountTarget=8 \         # Mixed GC 반복 횟수
  -jar app.jar
```

### ZGC 튜닝 (Java 17+)
```bash
java \
  -XX:+UseZGC \
  -Xms4g -Xmx4g \                      # ZGC는 넉넉한 힙 권장
  -XX:SoftMaxHeapSize=3g \              # 소프트 목표 힙
  -XX:ZCollectionInterval=0 \           # 자동 GC 주기
  -jar app.jar
```

### 힙 사이징 가이드
```
Live Data Set (LDS) = Old Gen 안정 상태 크기
권장 힙 크기: LDS × 3~4

예: LDS 500MB → 힙 1.5GB~2GB
```

---

## 2. HikariCP Connection Pool

### 기본 설정
```yaml
spring:
  datasource:
    hikari:
      maximum-pool-size: 10          # 기본 10, 공식 참조
      minimum-idle: 10               # = maximum-pool-size (고정 풀)
      idle-timeout: 600000           # 10분
      max-lifetime: 1800000          # 30분 (DB wait_timeout 미만)
      connection-timeout: 30000      # 30초
      validation-timeout: 5000      # 5초
      leak-detection-threshold: 60000 # 60초 (개발 환경)
```

### 풀 사이징 공식
```
최적 풀 크기 = (core_count × 2) + effective_spindle_count

예: 4 core, SSD(1 spindle) → (4 × 2) + 1 = 9
실제 권장: 10~20 (대부분 10으로 충분)

주의: 풀 크기 > 필요량 → 성능 오히려 저하 (컨텍스트 스위칭)
```

### 모니터링 메트릭
```
hikaricp_connections_active      # 활성 연결 수
hikaricp_connections_idle        # 유휴 연결 수
hikaricp_connections_pending     # 대기 스레드 수 (> 0 → 풀 부족)
hikaricp_connections_timeout     # 타임아웃 횟수
hikaricp_connections_creation    # 연결 생성 시간
```

---

## 3. Cache 설정

### Spring Cache + Caffeine
```java
@Configuration
@EnableCaching
public class CacheConfig {

    @Bean
    public CaffeineCacheManager cacheManager() {
        CaffeineCacheManager manager = new CaffeineCacheManager();
        manager.setCaffeine(Caffeine.newBuilder()
            .maximumSize(10_000)                // 최대 엔트리
            .expireAfterWrite(Duration.ofMinutes(10))  // TTL
            .recordStats());                     // 통계 활성화
        return manager;
    }
}

@Service
public class UserService {
    @Cacheable("users")
    public UserDto findById(Long id) { ... }

    @CacheEvict(value = "users", key = "#id")
    public void update(Long id, UserRequest req) { ... }

    @CacheEvict(value = "users", allEntries = true)
    public void clearAll() { ... }
}
```

### Spring Cache + Redis
```yaml
spring:
  cache:
    type: redis
    redis:
      time-to-live: 600000       # 10분
      cache-null-values: false
  redis:
    host: localhost
    port: 6379
    lettuce:
      pool:
        max-active: 8
        max-idle: 8
        min-idle: 2
```

### 캐시 히트율 모니터링
```
cache_gets{cache="users",result="hit"}
cache_gets{cache="users",result="miss"}
cache_evictions{cache="users"}
```

---

## 4. Async / Virtual Threads

### @Async 설정
```java
@Configuration
@EnableAsync
public class AsyncConfig {

    @Bean("taskExecutor")
    public Executor taskExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(10);
        executor.setMaxPoolSize(50);
        executor.setQueueCapacity(100);
        executor.setThreadNamePrefix("async-");
        executor.setRejectedExecutionHandler(new CallerRunsPolicy());
        executor.initialize();
        return executor;
    }
}

@Service
public class NotificationService {
    @Async("taskExecutor")
    public CompletableFuture<Boolean> sendEmail(String to) {
        // 비동기 실행
        return CompletableFuture.completedFuture(true);
    }
}
```

### Virtual Threads (Java 21+)
```yaml
# application.yml
spring:
  threads:
    virtual:
      enabled: true   # Tomcat 요청 처리를 Virtual Thread로
```

```java
// 직접 사용
try (var executor = Executors.newVirtualThreadPerTaskExecutor()) {
    var futures = urls.stream()
        .map(url -> executor.submit(() -> fetch(url)))
        .toList();
    var results = futures.stream()
        .map(Future::get)
        .toList();
}
```

### Virtual Threads 주의사항
| 주의 | 이유 | 대안 |
|------|------|------|
| synchronized 블록 | carrier thread 고정 (pinning) | ReentrantLock 사용 |
| ThreadLocal 남용 | VT 수백만 생성 → 메모리 폭발 | ScopedValue (Java 21) |
| CPU 집약 작업 | VT 장점 없음 (I/O 대기에 특화) | Platform Thread 유지 |

---

## 5. N+1 쿼리 탐지 및 해결

### 탐지 방법
```yaml
# application.yml
spring:
  jpa:
    properties:
      hibernate:
        generate_statistics: true  # 쿼리 통계
        session.events.log.LOG_QUERIES_SLOWER_THAN_MS: 25  # 느린 쿼리 로깅
logging:
  level:
    org.hibernate.SQL: DEBUG           # SQL 로깅
    org.hibernate.stat: DEBUG          # 통계 로깅
```

### 해결 패턴

**@EntityGraph**:
```java
@EntityGraph(attributePaths = {"orders", "orders.items"})
List<User> findAllWithOrders();
```

**JOIN FETCH (JPQL)**:
```java
@Query("SELECT u FROM User u LEFT JOIN FETCH u.orders WHERE u.id = :id")
Optional<User> findByIdWithOrders(@Param("id") Long id);
```

**@BatchSize**:
```java
@Entity
public class User {
    @BatchSize(size = 100)  // IN 절로 100개씩 배치 로딩
    @OneToMany(mappedBy = "user")
    private List<Order> orders;
}
```

**Default Batch Fetch Size**:
```yaml
spring:
  jpa:
    properties:
      hibernate:
        default_batch_fetch_size: 100  # 전역 배치 사이즈
```

---

## 6. Hibernate 튜닝

### 2차 캐시 설정
```yaml
spring:
  jpa:
    properties:
      hibernate:
        cache:
          use_second_level_cache: true
          use_query_cache: true
          region.factory_class: org.hibernate.cache.jcache.JCacheRegionFactory
        javax.cache.provider: com.github.benmanes.caffeine.jcache.spi.CaffeineCachingProvider
```

```java
@Entity
@Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
public class Category {
    // 자주 조회, 드물게 변경되는 엔티티
}
```

### 쿼리 힌트
```java
// 읽기 전용 쿼리 (스냅샷 비생성 → 메모리 절약)
@QueryHints(@QueryHint(name = "org.hibernate.readOnly", value = "true"))
List<User> findByStatus(String status);

// fetch size 조절
@QueryHints(@QueryHint(name = "org.hibernate.fetchSize", value = "100"))
List<Order> findByDateRange(LocalDate from, LocalDate to);
```

### OSIV (Open Session In View) 비활성화
```yaml
spring:
  jpa:
    open-in-view: false  # 성능 권장: false
    # true일 때: Controller까지 DB 세션 유지 → 커넥션 점유 시간 증가
    # false일 때: Service 계층에서 세션 종료 → LazyInitializationException 주의
```

---

## 7. Tomcat / Undertow 튜닝

### Tomcat 스레드 풀
```yaml
server:
  tomcat:
    threads:
      max: 200          # 최대 스레드 (기본 200)
      min-spare: 10     # 최소 유지 스레드
    max-connections: 8192  # 최대 연결 수
    accept-count: 100     # 연결 큐 크기
    connection-timeout: 20000  # 연결 타임아웃 (ms)
```

### Undertow (대안 서블릿 컨테이너)
```xml
<!-- pom.xml: Tomcat 제거 + Undertow 추가 -->
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-web</artifactId>
    <exclusions>
        <exclusion>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-tomcat</artifactId>
        </exclusion>
    </exclusions>
</dependency>
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-undertow</artifactId>
</dependency>
```

---

## 8. Anti-Pattern

| # | Anti-Pattern | 문제 | 올바른 방법 |
|---|-------------|------|------------|
| 1 | N+1 쿼리 방치 | DB 부하 N배 | `@EntityGraph`, `JOIN FETCH` |
| 2 | OSIV = true (기본) | 커넥션 장기 점유 | `open-in-view: false` |
| 3 | 커넥션 풀 과대 설정 | 컨텍스트 스위칭 증가 | HikariCP 공식 참조 |
| 4 | 캐시 없이 동일 쿼리 반복 | DB 불필요 부하 | Spring Cache 적용 |
| 5 | synchronized + Virtual Threads | Carrier thread pinning | ReentrantLock |
| 6 | 로그 레벨 DEBUG (운영) | I/O 병목 + 디스크 | INFO 이상만 |
| 7 | 힙 크기 Xms ≠ Xmx | GC 빈도 증가 | 동일 값 설정 |
| 8 | Eager Loading 남용 | 불필요 데이터 로딩 | Lazy + 필요 시 Fetch |
