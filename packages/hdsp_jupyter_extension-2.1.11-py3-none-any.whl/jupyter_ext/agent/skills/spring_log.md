---
name: spring_log
description: Spring Boot 로그 분석. Logback/Log4j2, Actuator 메트릭, Micrometer, GC 로그, Thread Dump 분석.
---

# Spring Boot Log Analysis Guide

Spring Boot 로그, Actuator 메트릭, GC 로그, Thread Dump 분석 레퍼런스입니다.

---

## 1. Logback / Log4j2 설정

### Logback 운영 설정
```xml
<!-- logback-spring.xml -->
<configuration>
  <!-- JSON 로그 (ELK 연동) -->
  <appender name="JSON" class="ch.qos.logback.core.ConsoleAppender">
    <encoder class="net.logstash.logback.encoder.LogstashEncoder">
      <fieldNames>
        <timestamp>@timestamp</timestamp>
        <message>message</message>
        <logger>logger</logger>
        <thread>thread</thread>
        <level>level</level>
      </fieldNames>
    </encoder>
  </appender>

  <!-- 파일 로그 (롤링) -->
  <appender name="FILE" class="ch.qos.logback.core.rolling.RollingFileAppender">
    <file>logs/app.log</file>
    <rollingPolicy class="ch.qos.logback.core.rolling.SizeAndTimeBasedRollingPolicy">
      <fileNamePattern>logs/app.%d{yyyy-MM-dd}.%i.log.gz</fileNamePattern>
      <maxFileSize>100MB</maxFileSize>
      <maxHistory>30</maxHistory>
      <totalSizeCap>3GB</totalSizeCap>
    </rollingPolicy>
    <encoder>
      <pattern>%d{yyyy-MM-dd HH:mm:ss.SSS} [%thread] %-5level %logger{36} - %msg%n</pattern>
    </encoder>
  </appender>

  <!-- 프로파일별 설정 -->
  <springProfile name="prod">
    <root level="INFO">
      <appender-ref ref="JSON"/>
      <appender-ref ref="FILE"/>
    </root>
  </springProfile>

  <springProfile name="dev">
    <root level="DEBUG">
      <appender-ref ref="CONSOLE"/>
    </root>
    <logger name="org.hibernate.SQL" level="DEBUG"/>
  </springProfile>
</configuration>
```

### MDC (Mapped Diagnostic Context)
```java
// 분산 추적용 필터
@Component
public class MDCFilter extends OncePerRequestFilter {
    @Override
    protected void doFilterInternal(HttpServletRequest request,
            HttpServletResponse response, FilterChain chain) {
        try {
            MDC.put("requestId", UUID.randomUUID().toString().substring(0, 8));
            MDC.put("userId", extractUserId(request));
            chain.doFilter(request, response);
        } finally {
            MDC.clear();
        }
    }
}

// logback 패턴에 MDC 포함
// %d [%thread] %-5level [%X{requestId}] [%X{userId}] %logger - %msg%n
```

### 주요 로깅 키워드 (grep 패턴)
```bash
# 에러 유형별 검색
grep -E "ERROR|Exception|StackTrace" app.log

# 느린 쿼리
grep "Slow query" app.log

# 커넥션 풀 문제
grep -i "HikariPool\|connection timeout\|leak" app.log

# OOM 전조
grep -i "OutOfMemory\|heap space\|GC overhead" app.log
```

---

## 2. Actuator 메트릭

### 주요 엔드포인트

| 엔드포인트 | 설명 | 용도 |
|-----------|------|------|
| `/actuator/health` | 헬스 상태 | 라이브니스/레디니스 |
| `/actuator/metrics` | 메트릭 목록 | 전체 메트릭 색인 |
| `/actuator/metrics/{name}` | 특정 메트릭 | 상세 값 조회 |
| `/actuator/threaddump` | 스레드 덤프 | 데드락/병목 진단 |
| `/actuator/heapdump` | 힙 덤프 | 메모리 분석 |
| `/actuator/env` | 환경 변수 | 설정 확인 |
| `/actuator/loggers` | 로거 레벨 | 런타임 로그 레벨 변경 |
| `/actuator/prometheus` | Prometheus 포맷 | 모니터링 연동 |

### 설정
```yaml
management:
  endpoints:
    web:
      exposure:
        include: health,metrics,prometheus,threaddump,loggers
  endpoint:
    health:
      show-details: always
      probes:
        enabled: true   # K8s liveness/readiness
  metrics:
    tags:
      application: my-app
```

### 런타임 로그 레벨 변경
```bash
# 현재 레벨 확인
curl localhost:8080/actuator/loggers/com.example

# 레벨 변경 (재시작 없이)
curl -X POST localhost:8080/actuator/loggers/com.example \
  -H "Content-Type: application/json" \
  -d '{"configuredLevel": "DEBUG"}'
```

---

## 3. Micrometer 메트릭

### JVM 메트릭

| 메트릭 | 설명 | 경고 기준 |
|--------|------|----------|
| `jvm_memory_used_bytes{area="heap"}` | 힙 사용량 | > 80% of max |
| `jvm_memory_used_bytes{area="nonheap"}` | 비힙 사용량 | 지속 증가 → 누수 |
| `jvm_gc_pause_seconds` | GC pause 시간 | p99 > 200ms |
| `jvm_gc_pause_seconds_count` | GC 발생 횟수 | 분당 50회 이상 |
| `jvm_threads_live_threads` | 활성 스레드 수 | > max pool 90% |
| `jvm_threads_states_threads{state="blocked"}` | 블로킹 스레드 | > 0 지속 → 데드락 |
| `jvm_classes_loaded_classes` | 로드된 클래스 수 | 지속 증가 → ClassLoader 누수 |

### HTTP 메트릭

| 메트릭 | 설명 | 경고 기준 |
|--------|------|----------|
| `http_server_requests_seconds` | 요청 처리 시간 | p99 > 3s |
| `http_server_requests_seconds_count` | 요청 수 | TPS 모니터링 |
| `http_server_requests_seconds{status="5xx"}` | 5xx 에러 | > 1% |

### DB Pool 메트릭

| 메트릭 | 설명 | 경고 기준 |
|--------|------|----------|
| `hikaricp_connections_active` | 활성 연결 | > 80% of max |
| `hikaricp_connections_pending` | 대기 요청 | > 0 지속 |
| `hikaricp_connections_timeout_total` | 타임아웃 수 | > 0 |
| `hikaricp_connections_creation_seconds` | 연결 생성 시간 | > 1s |

### Prometheus 쿼리 예시
```promql
# 요청 처리 시간 p99
histogram_quantile(0.99, rate(http_server_requests_seconds_bucket[5m]))

# 분당 에러율
sum(rate(http_server_requests_seconds_count{status=~"5.."}[5m]))
/ sum(rate(http_server_requests_seconds_count[5m]))

# GC pause 비율
sum(rate(jvm_gc_pause_seconds_sum[5m]))
/ sum(rate(jvm_gc_pause_seconds_count[5m]))

# DB 커넥션 풀 사용률
hikaricp_connections_active / hikaricp_connections_max
```

---

## 4. GC 로그 분석

### GC 로그 활성화
```bash
# Java 17+ (Unified Logging)
java -Xlog:gc*:file=gc.log:time,uptime,level,tags:filecount=5,filesize=100M \
     -jar app.jar

# 주요 태그
# gc         → GC 이벤트
# gc+heap    → 힙 상태
# gc+cpu     → CPU 시간
# gc+phases  → GC 단계별 시간
```

### GC 로그 핵심 패턴
```
[2024-01-15T10:30:00.123+0900][gc] GC(42) Pause Young (Normal) (G1 Evacuation Pause)
[2024-01-15T10:30:00.145+0900][gc] GC(42) Pause Young 1024M->512M(2048M) 22.456ms

해석:
- GC(42): 42번째 GC
- Pause Young: Young GC
- 1024M->512M: 힙 사용량 변화
- (2048M): 전체 힙 크기
- 22.456ms: pause 시간
```

### GC 로그 분석 명령
```bash
# GC pause 시간만 추출
grep "Pause" gc.log | awk '{print $NF}' | sort -n

# Full GC 발생 확인
grep "Pause Full" gc.log

# GC 빈도 (분당 횟수)
grep "Pause" gc.log | cut -d'[' -f2 | cut -d']' -f1 | \
  awk -F'T' '{print $2}' | cut -c1-5 | uniq -c

# GC Ergonomics (자동 크기 조절)
grep "gc+ergo" gc.log
```

### GC 분석 도구
```
- GCViewer: gc.log 시각화 (오픈소스)
- GCEasy (gceasy.io): 온라인 GC 로그 분석
- JVisualVM: 실시간 GC 모니터링
```

---

## 5. Thread Dump 분석

### Thread Dump 수집
```bash
# Actuator
curl localhost:8080/actuator/threaddump > thread_dump.json

# jstack (PID)
jstack <pid> > thread_dump.txt

# kill signal (SIGQUIT)
kill -3 <pid>  # stdout으로 출력
```

### 스레드 상태 해석

| 상태 | 의미 | 주의 |
|------|------|------|
| `RUNNABLE` | CPU 사용 중 | 다수 → CPU 병목 |
| `WAITING` | 대기 (Object.wait) | 정상 (idle 스레드) |
| `TIMED_WAITING` | 타임아웃 대기 | sleep/poll 대기 |
| `BLOCKED` | 모니터 락 대기 | 지속 → 락 경합 |

### 데드락 탐지
```
# jstack 출력에서 자동 탐지
"Found one Java-level deadlock:"

# 또는 Actuator JSON에서
GET /actuator/threaddump
→ "lockedMonitors", "lockedSynchronizers" 확인
```

### Thread Dump 분석 패턴
```bash
# 상태별 스레드 수
grep "java.lang.Thread.State" thread_dump.txt | sort | uniq -c

# BLOCKED 스레드 추출
grep -A 20 "BLOCKED" thread_dump.txt

# HikariCP 대기 스레드
grep -A 10 "HikariPool" thread_dump.txt

# 특정 패키지 호출 스택
grep -B 5 -A 15 "com.example" thread_dump.txt
```

### Thread Dump 분석 도구
```
- fastthread.io: 온라인 분석 (무료)
- TDA (Thread Dump Analyzer): 오프라인
- IntelliJ IDEA: Run > Analyze Thread Dump
```

---

## 6. 느린 쿼리 분석

### Hibernate 느린 쿼리 로깅
```yaml
spring:
  jpa:
    properties:
      hibernate:
        session.events.log.LOG_QUERIES_SLOWER_THAN_MS: 100  # 100ms 이상
logging:
  level:
    org.hibernate.SQL: DEBUG
    org.hibernate.type.descriptor.sql.BasicBinder: TRACE  # 바인드 파라미터
```

### P6Spy (쿼리 실행 시간 + 파라미터)
```yaml
# application.yml
spring:
  datasource:
    driver-class-name: com.p6spy.engine.spy.P6SpyDriver
    url: jdbc:p6spy:mysql://localhost:3306/mydb
```

```properties
# spy.properties
logMessageFormat=com.p6spy.engine.spy.appender.CustomLineFormat
customLogMessageFormat=%(executionTime)ms | %(sql)
excludecategories=info,debug,result,resultset
```

---

## 7. 성능 분석 체크리스트

```
□ GC 로그: Pause Full GC 없음
□ GC 로그: Young GC pause < 50ms (p99)
□ Actuator: jvm_memory_used < 80% of max
□ Actuator: jvm_threads_states{blocked} = 0
□ HikariCP: pending = 0
□ HikariCP: timeout_total = 0
□ HTTP: p99 응답 시간 < SLA
□ HTTP: 5xx 에러율 < 0.1%
□ Hibernate: generate_statistics 확인
□ N+1: 불필요한 쿼리 없음
□ OSIV: false 설정 확인
□ Thread Dump: 데드락 없음
```
