---
name: bigquery_tuning
description: BigQuery 900-slot 쿼리 튜닝, anti-pattern 탐지, 비용 최적화, INFORMATION_SCHEMA 참조.
---

# BigQuery Query Analysis & Optimization Guide

BigQuery 쿼리 분석, 튜닝, 비용 최적화 시 참고하는 레퍼런스 가이드입니다.

---

## 1. INFORMATION_SCHEMA.JOBS 핵심 컬럼

데이터는 `creation_time` 기준 파티셔닝, `project_id`와 `user_email`으로 클러스터링. 180일 보관.

### 핵심 식별/성능 컬럼

| Column | Type | Description |
|--------|------|-------------|
| `job_id` | STRING | Unique job identifier |
| `query` | STRING | SQL text |
| `total_slot_ms` | INT64 | Total slot-milliseconds consumed |
| `total_bytes_processed` | INT64 | Bytes processed |
| `total_bytes_billed` | INT64 | Bytes billed (min 10MB, rounded up to MB) |
| `cache_hit` | BOOL | Whether results from cache |
| `job_stages` | RECORD (REPEATED) | Execution stage array |
| `creation_time` | TIMESTAMP | Job creation time |
| `start_time` | TIMESTAMP | Execution start |
| `end_time` | TIMESTAMP | Execution end |
| `reservation_id` | STRING | Reservation name |
| `priority` | STRING | INTERACTIVE or BATCH |
| `referenced_tables` | RECORD (REPEATED) | Tables read |
| `destination_table` | RECORD | Target table |
| `statement_type` | STRING | SELECT, INSERT, MERGE, etc. |

---

## 2. job_stages RECORD 스키마

| Field | Type | Description |
|-------|------|-------------|
| `id` | INT64 | Stage identifier |
| `name` | STRING | Human-readable stage name |
| `slot_ms` | INT64 | Slot-ms used by stage |
| `records_read` | INT64 | Records read |
| `records_written` | INT64 | Records written |
| `shuffle_output_bytes` | INT64 | Bytes written to shuffle |
| `shuffle_output_bytes_spilled` | INT64 | Bytes spilled to disk |
| `compute_ms_avg` | INT64 | Avg compute ms per shard |
| `compute_ms_max` | INT64 | Max compute ms per shard |
| `wait_ms_avg` | INT64 | Avg wait ms |
| `wait_ms_max` | INT64 | Max wait ms |
| `input_stages` | INT64 (REPEATED) | IDs of input stages |
| `steps` | RECORD (REPEATED) | Operations (kind + substeps) |
| `parallel_inputs` | INT64 | Number of parallel input segments |

**steps sub-record**: `kind` (READ, COMPUTE, AGGREGATE, WRITE, HASH, SORT, JOIN, USER_DEFINED_FUNCTION) + `substeps` (STRING REPEATED)

---

## 3. Anti-Pattern 탐지 규칙

| # | Anti-Pattern | Detection | Severity | Fix |
|---|-------------|-----------|----------|-----|
| 1 | `SELECT *` | `SELECT\s+\*` regex | HIGH | 필요 컬럼만 명시 |
| 2 | Self-join | 같은 테이블이 FROM과 JOIN에 | HIGH | Window/Analytic 함수 또는 PIVOT |
| 3 | Missing partition filter | 파티션 컬럼 WHERE 조건 없음 | HIGH | 파티션 컬럼 필터 추가 |
| 4 | `ORDER BY` without `LIMIT` | ORDER BY 있고 LIMIT 없음 | MEDIUM | LIMIT 추가 |
| 5 | `COUNT(DISTINCT)` high-cardinality | 대규모 데이터에 COUNT(DISTINCT) | MEDIUM | `APPROX_COUNT_DISTINCT()` 사용 |
| 6 | `NOT IN` subquery | NOT IN + 서브쿼리 | MEDIUM | `NOT EXISTS` 또는 `LEFT JOIN ... IS NULL` |
| 7 | Cross-join | inequality JOIN 조건 | HIGH | equi-join으로 재구성 |
| 8 | Repeated CTE | 동일 CTE 2회+ 참조 | LOW | TEMP TABLE로 물리화 |
| 9 | Leading wildcard `LIKE '%x'` | LIKE 앞에 % | LOW | 가능하면 suffix 검색 회피 |
| 10 | `UNION` vs `UNION ALL` | 불필요한 중복 제거 | LOW | `UNION ALL` 사용 |

참고 도구: `GoogleCloudPlatform/bigquery-antipattern-recognition` (ZetaSQL 기반 AST 분석)

---

## 4. 비용 추정 공식

### On-Demand 가격
- **$6.25 / TiB** processed (US multi-region)
- 첫 1 TiB/월 무료
- 최소 10MB billing, MB 단위 올림

```
cost_usd = (total_bytes_billed / 1024^4) × 6.25
```

### 900-slot Enterprise Reservation
- **PAYG**: 900 × 730h × $0.06 = **~$39,420/월**
- **1-yr**: ~$35,478/월
- **3-yr**: ~$31,536/월

```
capacity_cost = (total_slot_ms / 3,600,000) × price_per_slot_hour
```

### 비용 절감액 계산 (튜닝 시 필수 출력)
```
on_demand_saving = (bytes_before - bytes_after) / 1024^4 × 6.25
monthly_saving = daily_executions × on_demand_saving × 30
annual_saving = monthly_saving × 12
```

---

## 5. Mermaid 다이어그램 템플릿

### Color Coding Convention

| Color | Hex | Meaning | When to Apply |
|-------|-----|---------|---------------|
| Blue | #4285F4 | READ stages | Input/scan |
| Red | #EA4335 | Bottleneck | slot_ms > 50% of total, or high skew |
| Orange | #FF6D01 | Data skew | compute_ms_max/avg > 3x |
| Yellow | #FBBC04 | Shuffle spill | spilled > 0 |
| Green | #34A853 | WRITE/output | Final output |
| Gray | #9AA0A6 | Idle/waiting | wait_ratio_avg > 0.5 |

### Stage Flowchart 템플릿

```
graph TD
    S0["Stage 0: READ<br/>table_name<br/>records: N<br/>slot_ms: N"]
    S1["Stage 1: HASH JOIN<br/>shuffle: N GB<br/>slot_ms: N"]
    S2["Stage 2: AGGREGATE<br/>GROUP BY col<br/>slot_ms: N"]
    S3["Stage 3: WRITE<br/>output<br/>records: N"]

    S0 -->|"N rows"| S1
    S1 -->|"N rows"| S2
    S2 -->|"N rows"| S3

    style S0 fill:#4285F4,color:#fff
    style S1 fill:#EA4335,color:#fff
    style S2 fill:#FBBC04,color:#000
    style S3 fill:#34A853,color:#fff
```

### As-Is vs To-Be 비교 레이아웃

```
graph LR
    subgraph "AS-IS (before tuning)"
        A0["READ: full scan<br/>bytes: 500GB"]
        A1["JOIN: shuffle 50GB"]
        A2["OUTPUT"]
        A0 --> A1 --> A2
    end

    subgraph "TO-BE (after tuning)"
        B0["READ: partition pruned<br/>bytes: 20GB"]
        B1["JOIN: broadcast<br/>shuffle: 0"]
        B2["OUTPUT"]
        B0 --> B1 --> B2
    end

    style A0 fill:#EA4335,color:#fff
    style A1 fill:#EA4335,color:#fff
    style B0 fill:#34A853,color:#fff
    style B1 fill:#34A853,color:#fff
```

---

## 6. 900-Slot 최적화 가이드

### 핵심 메트릭
```
avg_slots = total_slot_ms / wall_time_ms
slot_utilization = avg_slots / 900
contention = period_estimated_runnable_units > 0
```

### 최적화 전략
1. **Slot hog 식별**: `total_slot_ms > 300,000` (5분 이상 slot 소비)
2. **BATCH priority**: 비긴급 쿼리는 `@{priority: "BATCH"}` 사용
3. **Stagger batch jobs**: 대형 쿼리 동시 실행 회피
4. **Partition/Clustering**: 파티션 프루닝 + 클러스터링으로 scan 범위 축소
5. **Materialized View**: 반복 집계를 MV로 사전 계산
6. **JOIN 최적화**: broadcast join 유도 (작은 테이블 필터링), skew salting

### Slot Pressure 판단 기준
| Metric | 정상 | 주의 | 위험 |
|--------|------|------|------|
| P50 slots | < 450 | 450-720 | > 720 |
| P99 slots | < 720 | 720-900 | > 900 |
| Queued units | 0 | 간헐적 | 5분+ 지속 |
| Spill bytes | 0 | 간헐적 | 상시 |

---

## 7. 유용한 INFORMATION_SCHEMA 쿼리

### Top Expensive Queries (24시간)
```sql
SELECT job_id, user_email, query, total_bytes_processed, total_bytes_billed,
  total_slot_ms, TIMESTAMP_DIFF(end_time, start_time, SECOND) AS duration_sec, cache_hit
FROM `region-us`.INFORMATION_SCHEMA.JOBS
WHERE creation_time > TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 24 HOUR)
  AND job_type = 'QUERY' AND state = 'DONE' AND error_result IS NULL
ORDER BY total_bytes_processed DESC LIMIT 20;
```

### Slot Pressure (900-slot 초과 여부)
```sql
WITH slot_usage AS (
  SELECT TIMESTAMP_TRUNC(period_start, SECOND) AS sec,
    SUM(period_slot_ms) / 1000 AS slots_used,
    MAX(period_estimated_runnable_units) AS runnable_units
  FROM `region-us`.INFORMATION_SCHEMA.JOBS_TIMELINE
  WHERE period_start > TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 24 HOUR)
  GROUP BY sec
)
SELECT COUNTIF(slots_used > 900) AS seconds_over_900, COUNT(*) AS total_seconds,
  ROUND(COUNTIF(slots_used > 900) / COUNT(*) * 100, 2) AS pct_over_capacity,
  MAX(slots_used) AS peak_slots,
  APPROX_QUANTILES(slots_used, 100)[OFFSET(50)] AS p50,
  APPROX_QUANTILES(slots_used, 100)[OFFSET(90)] AS p90,
  APPROX_QUANTILES(slots_used, 100)[OFFSET(99)] AS p99
FROM slot_usage;
```

### Skew Detection
```sql
SELECT job_id, stage.name, stage.id, stage.slot_ms,
  stage.compute_ms_max, stage.compute_ms_avg,
  SAFE_DIVIDE(stage.compute_ms_max, NULLIF(stage.compute_ms_avg, 0)) AS skew_ratio,
  stage.shuffle_output_bytes_spilled
FROM `region-us`.INFORMATION_SCHEMA.JOBS, UNNEST(job_stages) AS stage
WHERE creation_time > TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 24 HOUR)
  AND job_type = 'QUERY' AND state = 'DONE' AND total_slot_ms > 60000
ORDER BY skew_ratio DESC LIMIT 50;
```

### Anomaly Detection (Z-score)
```sql
WITH query_patterns AS (
  SELECT REGEXP_REPLACE(REGEXP_REPLACE(query, r"'[^']*'", "'?'"), r'\b\d+\b', '?') AS template,
    total_slot_ms, TIMESTAMP_DIFF(end_time, start_time, SECOND) AS duration_sec, job_id
  FROM `region-us`.INFORMATION_SCHEMA.JOBS
  WHERE creation_time > TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 7 DAY)
    AND job_type = 'QUERY' AND state = 'DONE' AND error_result IS NULL
),
stats AS (
  SELECT template, AVG(total_slot_ms) AS avg_slot_ms, STDDEV(total_slot_ms) AS std_slot_ms,
    AVG(duration_sec) AS avg_dur, STDDEV(duration_sec) AS std_dur
  FROM query_patterns GROUP BY template HAVING COUNT(*) >= 5
)
SELECT p.job_id, p.duration_sec, s.avg_dur,
  ROUND((p.duration_sec - s.avg_dur) / NULLIF(s.std_dur, 0), 2) AS dur_z,
  ROUND((p.total_slot_ms - s.avg_slot_ms) / NULLIF(s.std_slot_ms, 0), 2) AS slot_z
FROM query_patterns p JOIN stats s ON p.template = s.template
WHERE ABS((p.total_slot_ms - s.avg_slot_ms) / NULLIF(s.std_slot_ms, 0)) > 3
ORDER BY slot_z DESC LIMIT 20;
```

---

## 8. 추가 기능 가이드

### Schema Analysis
```sql
-- 테이블 크기/행 수
SELECT table_name, total_rows,
  ROUND(total_logical_bytes / POW(1024, 3), 2) AS size_gb,
  ROUND(total_physical_bytes / NULLIF(total_logical_bytes, 0), 2) AS compression_ratio
FROM `project.dataset`.INFORMATION_SCHEMA.TABLE_STORAGE
ORDER BY total_logical_bytes DESC;

-- 컬럼 메타데이터 (파티션/클러스터 확인)
SELECT column_name, data_type, is_partitioning_column, clustering_ordinal_position
FROM `project.dataset`.INFORMATION_SCHEMA.COLUMNS
WHERE table_name = 'target_table' ORDER BY ordinal_position;
```

### Data Lineage (테이블 의존관계)
```sql
SELECT ref.project_id, ref.dataset_id, ref.table_id,
  COUNT(*) AS query_count, COUNT(DISTINCT user_email) AS users
FROM `region-us`.INFORMATION_SCHEMA.JOBS, UNNEST(referenced_tables) AS ref
WHERE creation_time > TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 7 DAY)
  AND job_type = 'QUERY' AND state = 'DONE'
GROUP BY 1, 2, 3 ORDER BY query_count DESC LIMIT 30;
```

### Dry-Run 비용 사전 추정 (Python)
```python
from google.cloud import bigquery
client = bigquery.Client()
job_config = bigquery.QueryJobConfig(dry_run=True, use_query_cache=False)
query_job = client.query("SELECT ...", job_config=job_config)
bytes_processed = query_job.total_bytes_processed
cost_estimate = (bytes_processed / (1024**4)) * 6.25
print(f"Estimated cost: ${cost_estimate:.4f}")
```

---

## ⚠️ 필수 출력 규칙

**모든 튜닝/오류수정 응답에는 반드시 ```mermaid 다이어그램을 포함하세요.**
- 튜닝: AS-IS vs TO-BE 실행 흐름 비교 (위 템플릿 참조)
- 오류 수정: 에러 발생 흐름 → 수정 후 정상 흐름
- 위 Color Coding Convention을 반드시 적용하세요.
- 다이어그램 없는 응답은 불완전한 응답입니다.
