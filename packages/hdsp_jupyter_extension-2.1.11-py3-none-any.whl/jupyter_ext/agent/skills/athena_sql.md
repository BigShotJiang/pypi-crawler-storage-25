# Athena SQL 가이드
BDP의 테이블은 Athena 쿼리로만 수행이 가능. 
Athena는 Trino(Presto) 기반 서버리스 SQL 엔진. S3 데이터를 직접 쿼리. 과금: 스캔 데이터 $5/TB.

## 엔진 특성

- DML: SELECT, INSERT INTO, UPDATE, DELETE, MERGE INTO (Iceberg 테이블만)
- DDL: CREATE TABLE, CREATE VIEW, ALTER TABLE, DROP TABLE, CTAS
- DDL은 HiveQL 기반 (백틱 `\`` 사용), DML은 Trino 기반 (큰따옴표 `"` 사용)

## 데이터 타입

| 타입 | 설명 | 예시 |
|------|------|------|
| `STRING` / `VARCHAR` | 문자열 | `'hello'` |
| `INT` / `BIGINT` | 정수 | `42` |
| `DOUBLE` | 실수 | `3.14` |
| `DECIMAL(p,s)` | 고정 소수점 | `DECIMAL(18,2)` |
| `DATE` | 날짜 | `DATE '2024-01-15'` |
| `TIMESTAMP` | 일시 | `TIMESTAMP '2024-01-15 10:30:00'` (공백 필수, T 사용 불가) |
| `BOOLEAN` | 불리언 | `TRUE` / `FALSE` |
| `ARRAY<T>` | 배열 | `ARRAY[1, 2, 3]` |
| `MAP<K,V>` | 맵 | `MAP(ARRAY['a'], ARRAY[1])` |
| `STRUCT` | 구조체 | `ROW(name VARCHAR, age INT)` |

### 타입 주의사항
- TIMESTAMP 형식: `YYYY-MM-DD HH:MM:SS.SSS` (T 구분자 사용 불가)
- 파티션 키는 `STRING` 권장 (DATE 타입은 성능 저하)
- Long → Timestamp 암묵적 변환 불가 → `from_unixtime()` 사용
- `CONCAT()`은 최소 2개 인자 필요

## SELECT 쿼리

```sql
-- 기본 조회
SELECT col1, col2 FROM db.table WHERE condition LIMIT 100;

-- 집계
SELECT category, COUNT(*) cnt, SUM(amount) total
FROM db.table
WHERE txn_date BETWEEN DATE '2024-01-01' AND DATE '2024-01-31'
GROUP BY category
HAVING COUNT(*) > 10
ORDER BY total DESC;

-- 서브쿼리 / CTE
WITH daily AS (
    SELECT txn_date, SUM(amount) total FROM db.txn GROUP BY txn_date
)
SELECT txn_date, total FROM daily WHERE total > 1000000;
```

## 날짜/시간 함수

| 함수 | 설명 | 예시 |
|------|------|------|
| `current_date` | 오늘 날짜 | `WHERE dt = current_date` |
| `current_timestamp` | 현재 시각 | |
| `date_add('day', n, date)` | 날짜 더하기 | `date_add('day', -7, current_date)` |
| `date_diff('day', d1, d2)` | 날짜 차이 | `date_diff('day', start_dt, end_dt)` |
| `date_trunc('month', dt)` | 절삭 | `date_trunc('month', txn_date)` |
| `format_datetime(ts, fmt)` | 포맷 | `format_datetime(ts, 'yyyy-MM-dd')` |
| `date_parse(str, fmt)` | 파싱 | `date_parse('2024-01-15', '%Y-%m-%d')` |
| `from_unixtime(epoch)` | 에포크→타임스탬프 | `from_unixtime(1705276800)` |
| `to_unixtime(ts)` | 타임스탬프→에포크 | `to_unixtime(current_timestamp)` |
| `year(dt)` / `month(dt)` / `day(dt)` | 추출 | `year(txn_date) = 2024` |

**주의**: `date_format()` 대신 `format_datetime()` 권장 (동작이 더 직관적).

## 문자열 함수

| 함수 | 설명 |
|------|------|
| `LOWER(s)` / `UPPER(s)` | 대소문자 |
| `TRIM(s)` / `LTRIM(s)` / `RTRIM(s)` | 공백 제거 |
| `LENGTH(s)` | 길이 |
| `SUBSTR(s, start, len)` | 부분 문자열 |
| `REPLACE(s, from, to)` | 치환 |
| `SPLIT(s, delim)` | 분할 → 배열 |
| `REGEXP_EXTRACT(s, pattern, group)` | 정규식 추출 |
| `REGEXP_LIKE(s, pattern)` | 정규식 매칭 |
| `CONCAT(s1, s2, ...)` | 연결 (최소 2개 인자) |
| `COALESCE(a, b, ...)` | NULL 대체 |
| `CAST(x AS type)` | 타입 변환 |

## 윈도우 함수

```sql
-- ROW_NUMBER: 순위
SELECT *, ROW_NUMBER() OVER (PARTITION BY user_id ORDER BY txn_date DESC) rn
FROM db.txn;

-- LAG / LEAD: 이전/다음 행
SELECT txn_date, amount,
       LAG(amount) OVER (ORDER BY txn_date) prev_amount,
       LEAD(amount) OVER (ORDER BY txn_date) next_amount
FROM db.txn;

-- 누적합
SELECT txn_date, amount,
       SUM(amount) OVER (ORDER BY txn_date ROWS UNBOUNDED PRECEDING) running_total
FROM db.txn;

-- FIRST_VALUE / LAST_VALUE
SELECT *, FIRST_VALUE(amount) OVER (PARTITION BY category ORDER BY txn_date) first_amt
FROM db.txn;
```

**주의**: `IGNORE NULLS`는 `first_value`, `last_value`, `nth_value`, `lag`, `lead`에서만 사용 가능.

## JOIN

```sql
-- INNER JOIN
SELECT a.*, b.name FROM db.txn a JOIN db.merchant b ON a.merchant_id = b.id;

-- LEFT JOIN
SELECT a.*, b.name FROM db.txn a LEFT JOIN db.merchant b ON a.merchant_id = b.id;

-- CROSS JOIN (주의: 카르테시안 곱)
SELECT * FROM db.dates CROSS JOIN db.categories;
```

**JOIN 최적화**: 작은 테이블을 오른쪽(또는 JOIN의 두 번째)에 배치.

## CTAS (Create Table As Select)

```sql
-- Parquet + Snappy 압축으로 결과 저장
CREATE TABLE db.result
WITH (format = 'PARQUET', write_compression = 'SNAPPY', external_location = 's3://bucket/result/')
AS SELECT * FROM db.source WHERE condition;

-- 파티셔닝 포함
CREATE TABLE db.result
WITH (format = 'PARQUET', partitioned_by = ARRAY['dt'])
AS SELECT col1, col2, dt FROM db.source;
```

## 성능 최적화

### 1. 파티션 프루닝 (가장 중요)
```sql
-- 좋음: 파티션 키(dt)로 필터
SELECT * FROM db.txn WHERE dt = DATE '2024-01-15';

-- 나쁨: 파티션 키 없이 전체 스캔
SELECT * FROM db.txn WHERE amount > 1000;
```

### 2. 컬럼 프루닝
```sql
-- 좋음: 필요한 컬럼만
SELECT id, name, amount FROM db.txn;

-- 나쁨: 전체 컬럼
SELECT * FROM db.txn;
```

### 3. 파일 최적화
- 최적 크기: **128MB ~ 512MB**
- 너무 작으면 (<64MB): 메타데이터 오버헤드
- 너무 크면 (>1GB): 병렬성 저하
- Parquet/ORC 포맷 사용 (CSV 대비 75% 스캔 절감)

### 4. LIMIT 활용
```sql
-- 탐색적 쿼리에 LIMIT 필수
SELECT * FROM db.large_table LIMIT 100;
```

### 5. APPROX 함수 (대용량)
```sql
-- 정확한 COUNT DISTINCT 대신
SELECT APPROX_DISTINCT(user_id) FROM db.txn;

-- 백분위수
SELECT APPROX_PERCENTILE(amount, 0.95) FROM db.txn;
```
