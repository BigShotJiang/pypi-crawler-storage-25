---
name: spring-java
description: Java & Spring Boot 개발 가이드. Java 17+ 기능, Maven 빌드 시스템, JDK/JVM 옵션, Spring Boot 프로젝트 구조, JUnit 5 테스트.
---

# Java & Spring Boot Development Guide

Spring Boot 애플리케이션 개발 가이드입니다.

## Maven 프로젝트 구조

```
project/
├── pom.xml
├── src/
│   ├── main/
│   │   ├── java/com/example/app/
│   │   │   ├── Application.java
│   │   │   ├── controller/
│   │   │   │   └── UserController.java
│   │   │   ├── service/
│   │   │   │   └── UserService.java
│   │   │   ├── repository/
│   │   │   │   └── UserRepository.java
│   │   │   ├── entity/
│   │   │   │   └── User.java
│   │   │   └── dto/
│   │   │       ├── UserRequest.java
│   │   │       └── UserResponse.java
│   │   └── resources/
│   │       └── application.yml
│   └── test/
│       └── java/com/example/app/
│           ├── controller/
│           │   └── UserControllerTest.java
│           └── service/
│               └── UserServiceTest.java
```

## Controller 패턴

```java
@RestController
@RequestMapping("/api/v1/users")
@RequiredArgsConstructor
public class UserController {

    private final UserService userService;

    @GetMapping
    public ResponseEntity<List<UserResponse>> getAll() {
        return ResponseEntity.ok(userService.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<UserResponse> getById(@PathVariable Long id) {
        return ResponseEntity.ok(userService.findById(id));
    }

    @PostMapping
    public ResponseEntity<UserResponse> create(@Valid @RequestBody UserRequest request) {
        UserResponse created = userService.create(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }

    @PutMapping("/{id}")
    public ResponseEntity<UserResponse> update(
            @PathVariable Long id, @Valid @RequestBody UserRequest request) {
        return ResponseEntity.ok(userService.update(id, request));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        userService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
```

## Service 패턴

```java
@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class UserService {

    private final UserRepository userRepository;

    public List<UserResponse> findAll() {
        return userRepository.findAll().stream()
                .map(UserResponse::from)
                .toList();
    }

    public UserResponse findById(Long id) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("User not found: " + id));
        return UserResponse.from(user);
    }

    @Transactional
    public UserResponse create(UserRequest request) {
        User user = User.builder()
                .name(request.getName())
                .email(request.getEmail())
                .build();
        return UserResponse.from(userRepository.save(user));
    }

    @Transactional
    public UserResponse update(Long id, UserRequest request) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("User not found: " + id));
        user.update(request.getName(), request.getEmail());
        return UserResponse.from(user);
    }

    @Transactional
    public void delete(Long id) {
        if (!userRepository.existsById(id)) {
            throw new EntityNotFoundException("User not found: " + id);
        }
        userRepository.deleteById(id);
    }
}
```

## Entity 패턴

```java
@Entity
@Table(name = "users")
@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@Builder
@AllArgsConstructor
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 100)
    private String name;

    @Column(nullable = false, unique = true)
    private String email;

    @CreatedDate
    private LocalDateTime createdAt;

    @LastModifiedDate
    private LocalDateTime updatedAt;

    public void update(String name, String email) {
        this.name = name;
        this.email = email;
    }
}
```

## Repository 패턴

```java
public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByEmail(String email);
    List<User> findByNameContaining(String keyword);
    boolean existsByEmail(String email);
}
```

## DTO 패턴

```java
// Request
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class UserRequest {
    @NotBlank(message = "Name is required")
    private String name;

    @Email(message = "Invalid email format")
    @NotBlank(message = "Email is required")
    private String email;
}

// Response
@Getter
@Builder
public class UserResponse {
    private Long id;
    private String name;
    private String email;
    private LocalDateTime createdAt;

    public static UserResponse from(User user) {
        return UserResponse.builder()
                .id(user.getId())
                .name(user.getName())
                .email(user.getEmail())
                .createdAt(user.getCreatedAt())
                .build();
    }
}
```

## application.yml

```yaml
spring:
  datasource:
    url: jdbc:h2:mem:testdb
    driver-class-name: org.h2.Driver
    username: sa
    password:
  jpa:
    hibernate:
      ddl-auto: create-drop
    show-sql: true
    properties:
      hibernate:
        format_sql: true
  h2:
    console:
      enabled: true

server:
  port: 8080
```

## pom.xml 공통 의존성

```xml
<dependencies>
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-web</artifactId>
    </dependency>
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-data-jpa</artifactId>
    </dependency>
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-validation</artifactId>
    </dependency>
    <dependency>
        <groupId>com.h2database</groupId>
        <artifactId>h2</artifactId>
        <scope>runtime</scope>
    </dependency>
    <dependency>
        <groupId>org.projectlombok</groupId>
        <artifactId>lombok</artifactId>
        <optional>true</optional>
    </dependency>
    <!-- Test -->
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-test</artifactId>
        <scope>test</scope>
    </dependency>
</dependencies>
```

## JUnit 5 + Mockito 테스트 패턴

### Controller 테스트 (MockMvc)

```java
@WebMvcTest(UserController.class)
class UserControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private UserService userService;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    void getAll_ShouldReturnUsers() throws Exception {
        List<UserResponse> users = List.of(
            UserResponse.builder().id(1L).name("Alice").build()
        );
        given(userService.findAll()).willReturn(users);

        mockMvc.perform(get("/api/v1/users"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].name").value("Alice"));
    }

    @Test
    void create_ShouldReturn201() throws Exception {
        UserRequest request = new UserRequest("Alice", "alice@example.com");
        UserResponse response = UserResponse.builder()
                .id(1L).name("Alice").email("alice@example.com").build();
        given(userService.create(any())).willReturn(response);

        mockMvc.perform(post("/api/v1/users")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").value(1));
    }
}
```

### Service 테스트 (Unit)

```java
@ExtendWith(MockitoExtension.class)
class UserServiceTest {

    @InjectMocks
    private UserService userService;

    @Mock
    private UserRepository userRepository;

    @Test
    void findById_ShouldReturnUser() {
        User user = User.builder().id(1L).name("Alice").email("a@b.com").build();
        given(userRepository.findById(1L)).willReturn(Optional.of(user));

        UserResponse result = userService.findById(1L);

        assertThat(result.getName()).isEqualTo("Alice");
    }

    @Test
    void findById_NotFound_ShouldThrow() {
        given(userRepository.findById(1L)).willReturn(Optional.empty());

        assertThatThrownBy(() -> userService.findById(1L))
                .isInstanceOf(EntityNotFoundException.class);
    }
}
```

## 빌드 명령

```bash
# 컴파일
mvn clean compile

# 테스트
mvn test

# 패키징
mvn clean package -DskipTests

# 실행
mvn spring-boot:run

# 특정 프로파일
mvn spring-boot:run -Dspring-boot.run.profiles=dev
```

## Java Core (17+)

### Records & Sealed Classes

```java
// Record: 불변 데이터 클래스 (getter, equals, hashCode, toString 자동 생성)
public record UserDto(Long id, String name, String email) {
    // compact constructor로 유효성 검증
    public UserDto {
        Objects.requireNonNull(name, "name must not be null");
    }
}

// Sealed Class: 허용된 하위 클래스만 상속 가능
public sealed interface Shape permits Circle, Rectangle, Triangle {
    double area();
}
public record Circle(double radius) implements Shape {
    public double area() { return Math.PI * radius * radius; }
}
```

### Pattern Matching & Text Blocks

```java
// Pattern Matching for switch (Java 21)
String describe(Shape shape) {
    return switch (shape) {
        case Circle c when c.radius() > 10 -> "Large circle (r=" + c.radius() + ")";
        case Circle c    -> "Circle (r=" + c.radius() + ")";
        case Rectangle r -> "Rectangle " + r.width() + "x" + r.height();
        case Triangle t  -> "Triangle (base=" + t.base() + ")";
    };
}

// Text Blocks
String json = """
        {
            "name": "%s",
            "email": "%s"
        }
        """.formatted(name, email);
```

### Collections & Streams

```java
// Stream API 패턴
List<UserDto> activeUsers = users.stream()
        .filter(u -> u.isActive())
        .sorted(Comparator.comparing(User::getName))
        .map(u -> new UserDto(u.getId(), u.getName(), u.getEmail()))
        .toList();  // Java 16+

// Collectors: groupingBy, partitioningBy
Map<String, List<User>> byDept = users.stream()
        .collect(Collectors.groupingBy(User::getDepartment));

// Optional 체이닝
String city = user.getAddress()
        .flatMap(Address::getCity)
        .orElse("Unknown");
```

### Concurrency

```java
// CompletableFuture
CompletableFuture<UserDto> future = CompletableFuture
        .supplyAsync(() -> userRepository.findById(id))
        .thenApply(UserDto::from)
        .exceptionally(ex -> { log.error("Failed", ex); return null; });

// Virtual Threads (Java 21)
try (var executor = Executors.newVirtualThreadPerTaskExecutor()) {
    List<Future<String>> futures = urls.stream()
            .map(url -> executor.submit(() -> fetchData(url)))
            .toList();
}
```

### Design Patterns (Spring 연동)

```java
// Strategy Pattern with Spring DI
public interface NotificationStrategy { void send(String to, String message); }

@Component("email") class EmailNotification implements NotificationStrategy { ... }
@Component("sms")   class SmsNotification implements NotificationStrategy { ... }

@Service
@RequiredArgsConstructor
public class NotificationService {
    private final Map<String, NotificationStrategy> strategies; // Spring이 자동 주입
    public void notify(String type, String to, String msg) {
        strategies.get(type).send(to, msg);
    }
}
```

## Maven 심화

### 라이프사이클 & 명령

```bash
# Maven 라이프사이클: clean → validate → compile → test → package → verify → install → deploy
mvn clean install              # 전체 빌드 + 로컬 저장소 설치
mvn clean package -DskipTests  # 테스트 스킵 패키징
mvn dependency:tree             # 의존성 트리 확인
mvn versions:display-dependency-updates  # 업데이트 가능한 의존성 확인

# Maven Wrapper (프로젝트 내 Maven 버전 고정)
mvn wrapper:wrapper -Dmaven=3.9.6
./mvnw clean package           # wrapper 사용
```

### Multi-module 프로젝트

```xml
<!-- parent/pom.xml -->
<groupId>com.example</groupId>
<artifactId>my-app-parent</artifactId>
<version>1.0.0</version>
<packaging>pom</packaging>

<modules>
    <module>common</module>
    <module>api</module>
    <module>batch</module>
</modules>

<dependencyManagement>
    <dependencies>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-dependencies</artifactId>
            <version>3.2.0</version>
            <type>pom</type>
            <scope>import</scope>
        </dependency>
    </dependencies>
</dependencyManagement>
```

### Profiles

```xml
<profiles>
    <profile>
        <id>dev</id>
        <activation><activeByDefault>true</activeByDefault></activation>
        <properties>
            <spring.profiles.active>dev</spring.profiles.active>
        </properties>
    </profile>
    <profile>
        <id>prod</id>
        <properties>
            <spring.profiles.active>prod</spring.profiles.active>
        </properties>
    </profile>
</profiles>
```

### Plugin 설정

```xml
<build>
    <plugins>
        <!-- 컴파일러 설정 -->
        <plugin>
            <groupId>org.apache.maven.plugins</groupId>
            <artifactId>maven-compiler-plugin</artifactId>
            <version>3.12.1</version>
            <configuration>
                <source>17</source>
                <target>17</target>
                <compilerArgs>--enable-preview</compilerArgs>
            </configuration>
        </plugin>
        <!-- 테스트 설정 -->
        <plugin>
            <groupId>org.apache.maven.plugins</groupId>
            <artifactId>maven-surefire-plugin</artifactId>
            <version>3.2.5</version>
        </plugin>
        <!-- Fat JAR 생성 -->
        <plugin>
            <groupId>org.apache.maven.plugins</groupId>
            <artifactId>maven-shade-plugin</artifactId>
            <version>3.5.2</version>
            <executions>
                <execution>
                    <phase>package</phase>
                    <goals><goal>shade</goal></goals>
                    <configuration>
                        <transformers>
                            <transformer implementation="org.apache.maven.plugins.shade.resource.ManifestResourceTransformer">
                                <mainClass>com.example.Main</mainClass>
                            </transformer>
                        </transformers>
                    </configuration>
                </execution>
            </executions>
        </plugin>
    </plugins>
</build>
```

### Dependency Scope & BOM

```xml
<!-- Scope 종류 -->
<dependency>
    <groupId>javax.servlet</groupId>
    <artifactId>javax.servlet-api</artifactId>
    <scope>provided</scope>  <!-- 컨테이너가 제공 (컴파일 O, 패키징 X) -->
</dependency>
<dependency>
    <groupId>mysql</groupId>
    <artifactId>mysql-connector-j</artifactId>
    <scope>runtime</scope>  <!-- 런타임에만 필요 (컴파일 X, 패키징 O) -->
</dependency>

<!-- Exclusion: 전이 의존성 제거 -->
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-web</artifactId>
    <exclusions>
        <exclusion>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-tomcat</artifactId>
        </exclusion>
    </exclusions>
</dependency>
```

## JDK/JVM 옵션

### JDK 버전 선택 가이드

| 버전 | LTS | 상태 | 주요 기능 |
|------|-----|------|-----------|
| 8 | LTS | 레거시 | Lambda, Stream API |
| 11 | LTS | 유지보수 | var, HttpClient, 모듈 시스템 |
| 17 | LTS | **현재 권장** | Records, Sealed Classes, Pattern Matching (instanceof) |
| 21 | LTS | 최신 안정 | Virtual Threads, Pattern Matching (switch), Sequenced Collections |

### JVM 메모리 옵션

```bash
# 힙 메모리
java -Xms512m -Xmx2g -jar app.jar          # 초기 512MB, 최대 2GB
java -XX:MetaspaceSize=128m -XX:MaxMetaspaceSize=256m -jar app.jar

# GC 선택
java -XX:+UseG1GC -jar app.jar              # G1 GC (기본, 범용)
java -XX:+UseZGC -jar app.jar               # ZGC (초저지연, 대용량 힙)
java -XX:+UseShenandoahGC -jar app.jar      # Shenandoah (저지연)

# GC 로그
java -Xlog:gc*:file=gc.log:time -jar app.jar
```

### 컴파일러 옵션

```bash
# javac 옵션
javac --source 17 --target 17 Main.java     # 소스/타겟 버전 지정
javac --release 17 Main.java                # --release 권장 (API 호환성 보장)
javac --enable-preview --release 21 Main.java  # 프리뷰 기능 활성화
```

### 디버깅 & 모니터링

```bash
# 원격 디버깅
java -agentlib:jdwp=transport=dt_socket,server=y,suspend=n,address=*:5005 -jar app.jar

# OOM 시 힙 덤프
java -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=/tmp/heapdump.hprof -jar app.jar

# JVM 상태 모니터링
jps                  # Java 프로세스 목록
jstack <pid>         # 스레드 덤프
jmap -histo <pid>    # 힙 히스토그램
jstat -gc <pid> 1000 # GC 통계 (1초 간격)
```

### 실행 방법 비교

```bash
# Spring Boot
mvn spring-boot:run                                   # Maven 플러그인
java -jar target/app-1.0.0.jar                        # JAR 직접 실행
java -jar app.jar --spring.profiles.active=prod       # 프로파일 지정

# Plain Java
java -cp "lib/*:." com.example.Main                   # classpath 지정
java --module-path mods -m com.example/com.example.Main  # 모듈 시스템
```
