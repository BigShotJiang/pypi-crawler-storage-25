---
name: unit-testing
description: pytest 유닛테스트 생성 가이드. 의존성 분석, 테스트 구조, fixture, mock, parametrize, 커버리지 패턴 제공.
---

# Unit Testing Guide (pytest)

## 테스트 파일 구조

```python
"""Tests for <module_name>."""
import pytest
from <module> import <target_function_or_class>


class TestTargetFunction:
    """<target_function> 테스트."""

    def test_basic_case(self):
        """정상 입력에 대한 기본 동작."""
        result = target_function(valid_input)
        assert result == expected

    def test_edge_case_empty(self):
        """빈 입력 처리."""
        result = target_function("")
        assert result == default_or_empty

    def test_error_case(self):
        """잘못된 입력 시 예외 발생."""
        with pytest.raises(ValueError):
            target_function(invalid_input)
```

## Import 의존성 처리 패턴

### 내부 모듈 (프로젝트 내)
직접 import하여 통합 테스트. 실제 동작을 검증:
```python
from myproject.utils import parse_config
from myproject.models import User

def test_parse_config_integration():
    result = parse_config({"name": "test"})
    assert isinstance(result, User)
```

### 외부 라이브러리 (third-party, 네트워크, DB)
mock/patch로 격리하여 단위 테스트:
```python
from unittest.mock import patch, MagicMock

def test_fetch_data():
    with patch("mymodule.requests.get") as mock_get:
        mock_get.return_value.json.return_value = {"data": [1, 2]}
        result = fetch_data("http://api.example.com")
        assert result == [1, 2]
```

### 의존성 판별 기준
| 구분 | 예시 | 처리 |
|------|------|------|
| 내부 모듈 | `from .utils import helper` | 직접 import |
| 표준 라이브러리 | `import os, json, pathlib` | 직접 사용 |
| 외부 라이브러리 | `import requests, boto3, sqlalchemy` | mock/patch |
| 파일 I/O | `open(), Path.read_text()` | tmp_path fixture |
| 네트워크 | `requests.get, httpx.AsyncClient` | mock/patch |
| DB | `session.query(), cursor.execute()` | mock/patch |

## 핵심 패턴

### Fixture (공유 설정)
```python
@pytest.fixture
def sample_data():
    return {"key": "value", "count": 42}

def test_with_fixture(sample_data):
    assert sample_data["count"] == 42
```

### Parametrize (다중 입력 테스트)
```python
@pytest.mark.parametrize("input_val,expected", [
    (1, 1),
    (2, 4),
    (3, 9),
    (-1, 1),
    (0, 0),
])
def test_square(input_val, expected):
    assert square(input_val) == expected
```

### Mock (외부 의존성 격리)
```python
from unittest.mock import patch, MagicMock

def test_api_call():
    with patch("module.requests.get") as mock_get:
        mock_get.return_value.json.return_value = {"status": "ok"}
        result = fetch_status()
        assert result == "ok"
        mock_get.assert_called_once()
```

### Async 테스트
```python
@pytest.mark.asyncio
async def test_async_function():
    result = await async_fetch("url")
    assert result is not None
```

## 커버리지 체크리스트

테스트 생성 시 반드시 확인:

- [ ] **Public 함수/메서드**: 모든 public API에 최소 1개 테스트
- [ ] **분기 (if/else)**: 각 분기 경로별 테스트
- [ ] **예외 경로**: `raise`, `try/except` 블록 검증
- [ ] **경계값**: 0, 빈 문자열, None, 빈 리스트, 매우 큰 값
- [ ] **타입 변환**: 입력 타입이 다를 때의 동작
- [ ] **기본값**: 선택적 파라미터의 기본값 동작

## conftest.py 패턴

공유 fixture는 `conftest.py`에 정의:
```python
# conftest.py
import pytest
from pathlib import Path

@pytest.fixture
def sample_dir(tmp_path):
    """테스트용 디렉토리 구조 생성."""
    (tmp_path / "data.csv").write_text("a,b\n1,2\n")
    return tmp_path

@pytest.fixture
def mock_env(monkeypatch):
    """환경변수 설정."""
    monkeypatch.setenv("API_KEY", "test-key")
    monkeypatch.setenv("DEBUG", "true")
```

## 테스트 대상별 가이드

### 순수 함수
- 입력/출력 쌍으로 parametrize
- 경계값: 0, 빈 문자열, None, 매우 큰 값
- 타입 에러 케이스

### 클래스
- `__init__` 파라미터 검증
- 메서드별 독립 테스트
- 상태 변경 추적 (before/after)

### 파일 I/O
- `tmp_path` fixture 사용
- 존재하지 않는 파일 처리
- 인코딩 에러 처리

### DataFrame 함수
```python
import pandas as pd

@pytest.fixture
def sample_df():
    return pd.DataFrame({"a": [1, 2, 3], "b": [4, 5, 6]})

def test_transform(sample_df):
    result = transform_df(sample_df)
    assert "new_col" in result.columns
    assert len(result) == 3
```

### .ipynb 노트북 코드
노트북에서 추출한 함수/클래스를 테스트:
1. 노트북의 함수 정의를 별도 .py 모듈로 추출하여 import
2. 또는 `%run notebook.ipynb`로 네임스페이스 로드 후 테스트
3. 전역 변수 의존성은 fixture로 대체

## 커버리지 실행 가이드

```bash
# 기본 커버리지 측정
pytest --cov=module_name --cov-report=term-missing

# HTML 리포트 생성
pytest --cov=module_name --cov-report=html

# 특정 파일만
pytest tests/test_utils.py --cov=utils --cov-report=term-missing

# 최소 커버리지 강제
pytest --cov=module_name --cov-fail-under=80
```

## 네이밍 규칙
- 파일: `test_<원본파일명>.py`
- 클래스: `Test<대상클래스또는함수>`
- 메서드: `test_<동작>_<조건>` (예: `test_parse_empty_input`)
