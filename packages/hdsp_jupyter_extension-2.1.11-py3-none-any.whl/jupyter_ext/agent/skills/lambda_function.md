---
name: lambda-function
description: AWS Lambda 함수 개발 가이드. handler, event/context, SAM, 테스트.
---

# Lambda Function Development Guide

AWS Lambda 함수 개발 가이드입니다.

## Handler 기본 템플릿

```python
"""Lambda function: <description>."""
import json
import logging
import os

logger = logging.getLogger()
logger.setLevel(os.environ.get("LOG_LEVEL", "INFO"))

def handler(event: dict, context) -> dict:
    """Lambda entry point.

    Args:
        event: Event payload (source-dependent).
        context: Lambda runtime context (request_id, memory_limit, etc.).
    """
    logger.info("Event: %s", json.dumps(event, default=str))

    try:
        result = process(event)
        return {
            "statusCode": 200,
            "body": json.dumps(result, default=str),
        }
    except ValueError as e:
        logger.warning("Validation error: %s", e)
        return {"statusCode": 400, "body": json.dumps({"error": str(e)})}
    except Exception as e:
        logger.exception("Unexpected error")
        return {"statusCode": 500, "body": json.dumps({"error": "Internal server error"})}

def process(event: dict) -> dict:
    """Core business logic (separated for testability)."""
    # Implement here
    return {"message": "success"}
```

## Event Source 패턴

### API Gateway (REST)
```python
def handler(event, context):
    http_method = event["httpMethod"]
    path = event["path"]
    body = json.loads(event.get("body") or "{}")
    query = event.get("queryStringParameters") or {}
```

### S3 Event
```python
def handler(event, context):
    for record in event["Records"]:
        bucket = record["s3"]["bucket"]["name"]
        key = record["s3"]["object"]["key"]
        # Process file
```

### SQS Event
```python
def handler(event, context):
    for record in event["Records"]:
        body = json.loads(record["body"])
        # Process message
    return {"batchItemFailures": []}
```

### EventBridge (Scheduled)
```python
def handler(event, context):
    detail_type = event.get("detail-type", "")
    detail = event.get("detail", {})
    # Process scheduled event
```

## SAM Template

```yaml
AWSTemplateFormatVersion: "2010-09-09"
Transform: AWS::Serverless-2016-10-31
Description: Lambda function

Globals:
  Function:
    Timeout: 30
    Runtime: python3.12
    MemorySize: 256
    Environment:
      Variables:
        LOG_LEVEL: INFO

Resources:
  MyFunction:
    Type: AWS::Serverless::Function
    Properties:
      Handler: handler.handler
      CodeUri: src/
      Description: "Function description"
      Policies:
        - S3ReadPolicy:
            BucketName: !Ref DataBucket
      Events:
        ApiEvent:
          Type: Api
          Properties:
            Path: /items
            Method: get
```

## 로컬 테스트

```bash
# SAM CLI 로컬 실행
sam build
sam local invoke MyFunction -e events/test_event.json

# 로컬 API 시작
sam local start-api --port 3000

# 직접 Python 테스트
python -c "from handler import handler; print(handler({'key': 'value'}, None))"
```

## pytest 테스트 패턴

```python
import json
import pytest
from unittest.mock import patch, MagicMock
from handler import handler, process

@pytest.fixture
def api_event():
    return {
        "httpMethod": "POST",
        "path": "/items",
        "body": json.dumps({"name": "test"}),
        "queryStringParameters": None,
    }

@pytest.fixture
def s3_event():
    return {
        "Records": [{
            "s3": {
                "bucket": {"name": "my-bucket"},
                "object": {"key": "data/file.json"},
            }
        }]
    }

@pytest.fixture
def context():
    ctx = MagicMock()
    ctx.function_name = "test-function"
    ctx.memory_limit_in_mb = 256
    ctx.invoked_function_arn = "arn:aws:lambda:us-east-1:123:function:test"
    return ctx

def test_handler_success(api_event, context):
    response = handler(api_event, context)
    assert response["statusCode"] == 200

def test_handler_validation_error(context):
    event = {"httpMethod": "POST", "body": "{}"}
    response = handler(event, context)
    assert response["statusCode"] in (200, 400)

def test_process_logic():
    result = process({"key": "value"})
    assert "message" in result

@patch("handler.boto3")
def test_s3_integration(mock_boto3, s3_event, context):
    handler(s3_event, context)
    # Assert S3 interactions
```

## Layer / 의존성 관리

```
project/
├── src/
│   ├── handler.py
│   └── requirements.txt
├── layers/
│   └── common/
│       └── python/
│           └── utils.py
├── events/
│   └── test_event.json
├── template.yaml
└── tests/
    └── test_handler.py
```

## Cold Start 최적화

| 기법 | 효과 | 구현 |
|------|------|------|
| Top-level import 최소화 | 초기화 시간 감소 | 필요한 것만 top-level |
| SDK 클라이언트 재사용 | 연결 재사용 | 핸들러 밖에서 생성 |
| Provisioned Concurrency | 웜 인스턴스 유지 | SAM에서 설정 |
| SnapStart (Java) | 스냅샷 복원 | Java 런타임 전용 |
| 패키지 크기 축소 | 로딩 시간 감소 | Layer 활용, 불필요 파일 제외 |

```python
# Cold start 최적화: 핸들러 밖에서 클라이언트 초기화
import boto3
s3_client = boto3.client("s3")  # 재사용됨

def handler(event, context):
    s3_client.get_object(...)  # 기존 연결 재사용
```

## 환경변수 패턴

```python
import os

TABLE_NAME = os.environ["TABLE_NAME"]          # 필수
STAGE = os.environ.get("STAGE", "dev")         # 선택 (기본값)
DEBUG = os.environ.get("DEBUG", "").lower() == "true"
```
