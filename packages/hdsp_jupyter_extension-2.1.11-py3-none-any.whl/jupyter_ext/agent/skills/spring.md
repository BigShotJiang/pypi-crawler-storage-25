---
name: spring
description: Spring 전문가 기본 가이드. 세부 가이드는 spring_tuning, spring_log 참조.
---

# Spring Expert Guide

Spring agent의 3대 역할별 세부 가이드:

| 요청 유형 | 로드할 스킬 | 설명 |
|-----------|------------|------|
| JVM GC / Connection Pool / Cache / Hibernate 튜닝 | `spring_tuning` | G1GC/ZGC, HikariCP, N+1 쿼리, Virtual Threads |
| Logback / Actuator / GC 로그 / Thread Dump 분석 | `spring_log` | Micrometer 메트릭, GC 로그 파싱, 데드락 탐지 |
| Spring Boot / Java 코드 생성 | `spring-java` | 기존 Spring 개발 가이드 |

## 사용법
1. 요청 유형 판단
2. 해당 스킬 로드
3. 복합 요청(튜닝+로그)이면 둘 다 로드
