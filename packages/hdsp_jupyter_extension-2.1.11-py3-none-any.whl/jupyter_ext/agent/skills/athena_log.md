---
name: athena_log
description: Athena 쿼리 로그 분석. CloudWatch 메트릭, 쿼리 실행 통계, 에러 패턴 진단.
---

# Athena Query Log Analysis Guide

Athena 쿼리 실행 로그, CloudWatch 메트릭, 에러 패턴 분석 레퍼런스입니다.

---

## 1. 쿼리 실행 통계 조회

### INFORMATION_SCHEMA 활용 (Athena v3)
```sql
-- 최근 쿼리 실행 통계
SELECT
  query_execution_id,
  query,
  state,
  total_execution_time_in_millis,
  data_scanned_in_bytes,
  data_scanned_in_bytes / POWER(1024, 3) AS scanned_gb,
  data_scanned_in_bytes / POWER(1024, 4) * 5.0 AS estimated_cost_usd
FROM information_schema.__query_log__
WHERE date = CURRENT_DATE
ORDER BY data_scanned_in_bytes DESC
LIMIT 20;
```

### AWS CLI로 쿼리 이력 조회
```bash
# 최근 실패 쿼리
aws athena list-query-executions --work-group primary --max-items 50

# 특정 쿼리 상세 정보
aws athena get-query-execution --query-execution-id <ID>

# 배치 조회
aws athena batch-get-query-execution \
  --query-execution-ids id1 id2 id3
```

### 응답 필드 해석

| 필드 | 설명 | 주의 |
|------|------|------|
| `Statistics.EngineExecutionTimeInMillis` | 엔진 실행 시간 | 큐 대기 미포함 |
| `Statistics.DataScannedInBytes` | 스캔 데이터량 | 비용 계산 기준 |
| `Statistics.DataManifestLocation` | 매니페스트 S3 경로 | 결과 파일 목록 |
| `Statistics.TotalExecutionTimeInMillis` | 전체 실행 시간 | 큐 대기 포함 |
| `Statistics.QueryQueueTimeInMillis` | 큐 대기 시간 | Workgroup 동시성 제한 |
| `Statistics.ServiceProcessingTimeInMillis` | 후처리 시간 | 결과 저장 시간 |

---

## 2. CloudWatch 메트릭

### Athena 주요 메트릭

| 메트릭 | 단위 | 설명 | 알람 기준 |
|--------|------|------|----------|
| `ProcessedBytes` | Bytes | 쿼리당 스캔 바이트 | > 1TB 경고 |
| `EngineExecutionTime` | ms | 엔진 실행 시간 | > 300s 경고 |
| `TotalExecutionTime` | ms | 큐 포함 전체 시간 | > 600s 경고 |
| `QueryQueueTime` | ms | 큐 대기 시간 | > 60s → Workgroup 동시성 증가 |
| `ServiceProcessingTime` | ms | 결과 후처리 시간 | > 30s → 결과 크기 검토 |

### CloudWatch Logs Insights 쿼리 패턴

```
-- Athena는 기본적으로 CloudWatch Logs에 직접 로깅하지 않음
-- 대신 S3 쿼리 결과 경로와 AWS API로 분석

-- CloudTrail에서 Athena API 호출 추적
fields @timestamp, eventName, requestParameters.queryString
| filter eventSource = "athena.amazonaws.com"
| filter eventName = "StartQueryExecution"
| sort @timestamp desc
| limit 50
```

---

## 3. S3 액세스 패턴 분석

### S3 서버 액세스 로그
```
-- S3 GET 요청 수 (파일 스캔 수)
-- 파일이 너무 많으면 GET 요청 병목

-- S3 요청 최적화 기준:
-- 파일 수 > 10,000 → 파일 병합 필요
-- 파일 크기 < 1MB → CTAS로 병합
-- S3 ListObjects 호출 > 100 → 파티션 구조 검토
```

### 최적 파일 레이아웃
```
s3://bucket/table/
├── dt=2024-01-01/
│   ├── part-00000.parquet   (128MB)
│   ├── part-00001.parquet   (128MB)
│   └── part-00002.parquet   (64MB)
├── dt=2024-01-02/
│   └── ...
```

---

## 4. 에러 패턴 진단

### 주요 에러 코드

| 에러 | 원인 | 해결 |
|------|------|------|
| `HIVE_CURSOR_ERROR` | 파일 손상/스키마 불일치 | 파일 무결성 확인, MSCK REPAIR |
| `HIVE_METASTORE_ERROR` | Glue Catalog 문제 | 테이블 메타데이터 확인 |
| `GENERIC_INTERNAL_ERROR` | 메모리 부족 (OOM) | 쿼리 분할 또는 CTAS 사용 |
| `HIVE_BAD_DATA` | 데이터 포맷 오류 | SerDe 설정 확인 |
| `EXCEEDED_MAX_QUERY_LENGTH` | 쿼리 문자열 > 262144 bytes | 쿼리 간소화 |
| `THROTTLING` | DML 동시 실행 제한 (Iceberg) | 요청 간격 확보, 재시도 |
| `INVALID_TABLE` | 테이블 미존재/권한 | SHOW TABLES로 확인 |
| `HIVE_PATH_ALREADY_EXISTS` | CTAS 대상 경로 이미 존재 | 경로 삭제 후 재실행 |

### OOM (GENERIC_INTERNAL_ERROR) 대응

```sql
-- 원인 1: ORDER BY 없는 LIMIT → 전체 정렬
-- 해결: 정렬 불필요하면 ORDER BY 제거

-- 원인 2: 대량 GROUP BY
-- 해결: 단계별 집계
CREATE TABLE temp_agg AS
SELECT region, COUNT(*) AS cnt
FROM huge_table
WHERE dt = '2024-01-01'
GROUP BY region;

-- 원인 3: 거대 조인
-- 해결: 작은 테이블 필터링 후 조인
WITH filtered_dim AS (
  SELECT * FROM dim_table WHERE active = true
)
SELECT f.*, d.name
FROM fact_table f
JOIN filtered_dim d ON f.dim_id = d.id;
```

---

## 5. Workgroup 분석

### Workgroup 설정 검토
```bash
aws athena get-work-group --work-group primary

# 주요 확인 사항:
# - BytesScannedCutoffPerQuery: 쿼리당 스캔 제한
# - RequesterPaysEnabled: 교차 계정 비용
# - EnforceWorkGroupConfiguration: 설정 강제 여부
# - EngineVersion: v2 (Presto) vs v3 (Trino)
```

### Workgroup 메트릭 집계
```sql
-- 일별 비용 추정 (CloudTrail + API)
SELECT
  DATE(completion_date_time) AS query_date,
  COUNT(*) AS query_count,
  SUM(data_scanned_in_bytes) / POWER(1024, 4) AS total_tb,
  SUM(data_scanned_in_bytes) / POWER(1024, 4) * 5.0 AS cost_usd
FROM query_history
GROUP BY 1
ORDER BY 1 DESC;
```

---

## 6. 성능 분석 체크리스트

```
□ EXPLAIN으로 실행계획 확인
□ 파티션 프루닝 동작 확인 (SOURCE fragment에서 파일 수)
□ 스캔 바이트 vs 테이블 크기 비교 (프루닝 효과)
□ 파일 포맷 확인 (Parquet/ORC 여부)
□ 파일 크기 분포 확인 (작은 파일 여부)
□ ORDER BY + LIMIT 조합 확인
□ JOIN 키 카디널리티 확인
□ Workgroup 동시성 제한 확인
□ Athena v3 (Trino) 전환 여부
□ 비용 추정 및 예산 설정
```
