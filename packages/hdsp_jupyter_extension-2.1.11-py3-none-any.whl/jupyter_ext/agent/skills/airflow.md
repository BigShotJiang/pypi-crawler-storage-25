---
name: airflow
description: Airflow 전문가 라우팅 가이드. 요청 유형에 따라 세부 스킬(airflow_tuning, airflow_troubleshoot, airflow-dag)을 로드합니다.
---

# Airflow Expert Routing Guide

요청 유형에 따라 적절한 세부 스킬을 로드하세요.

## 스킬 라우팅 테이블

| 요청 유형 | 로드할 스킬 | 설명 |
|-----------|------------|------|
| 성능 튜닝 / concurrency / parallelism / pool / 스케줄러 최적화 | `load_skill('airflow_tuning')` | MWAA/Composer 환경별 파라미터 최적화, anti-pattern |
| 에러 분석 / task failure / dependency error / 로그 해석 | `load_skill('airflow_troubleshoot')` | 에러 패턴 진단, 로그 구조, 플랫폼별 이슈 |
| DAG 코드 생성 / 리뷰 / 테스트 | `load_skill('airflow-dag')` | DAG 구조, Operator, TaskFlow API, 검증 |
| 복합 요청 (튜닝 + 에러 분석) | 필요한 스킬 모두 로드 | 예: tuning + troubleshoot |

## 요청 유형 판단 키워드

- **성능 튜닝**: parallelism, concurrency, worker, pool, slot, 스케줄러, 느림, 병목, 최적화, 튜닝
- **에러 분석**: error, fail, SIGKILL, OOM, timeout, upstream_failed, zombie, 에러, 실패
- **로그 해석**: log, 로그, CloudWatch, Cloud Logging, Stackdriver, 디버깅
- **DAG 생성**: DAG 만들어, DAG 생성, 코드 작성, operator, taskflow

## 플랫폼 판단

- **MWAA**: mwaa, aws, s3, cloudwatch, mw1.small/medium/large
- **Composer**: composer, gcp, gcs, gke, stackdriver, cloud logging
- **공통**: 명시 없으면 양쪽 모두 안내
