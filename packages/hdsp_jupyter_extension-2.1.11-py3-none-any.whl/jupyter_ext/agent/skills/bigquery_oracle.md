---
name: bigquery_oracle
description: Oracle(Exadata) → BigQuery SQL 변환. 구문 매핑, 실행 모델 비교, Hint 대체 전략.
---

# Oracle(Exadata) → BigQuery 변환 가이드

### 구문 매핑 테이블

| Oracle 구문 | BigQuery StandardSQL 대체 |
|-------------|--------------------------|
| `ROWNUM` | `ROW_NUMBER() OVER()` |
| `NVL(a, b)` | `IFNULL(a, b)` / `COALESCE(a, b)` |
| `NVL2(a, b, c)` | `IF(a IS NOT NULL, b, c)` |
| `DECODE(a, v1, r1, ...)` | `CASE WHEN a = v1 THEN r1 ... END` |
| `SYSDATE` | `CURRENT_TIMESTAMP()` |
| `TO_DATE(s, fmt)` | `PARSE_DATE(fmt, s)` (포맷 문법 다름) |
| `TO_CHAR(d, fmt)` | `FORMAT_DATE(fmt, d)` / `FORMAT_TIMESTAMP()` |
| `(+)` outer join | `LEFT JOIN` / `RIGHT JOIN` |
| `CONNECT BY / START WITH` | Recursive CTE (`WITH RECURSIVE`) |
| `MINUS` | `EXCEPT DISTINCT` |
| `FROM DUAL` | FROM 생략 가능 (BQ) |
| `MERGE INTO` | `MERGE` (BQ DML, 구문 유사) |
| `ROWID` | 없음 (partition/clustering으로 대체) |
| `SEQUENCE` | `GENERATE_UUID()` / `ROW_NUMBER()` |
| `DBMS_*` 패키지 | BQ scripting / UDF |
| PL/SQL 프로시저 | BQ scripting (`DECLARE`, `SET`, `LOOP`, `IF`) |
| Oracle hint (`/*+ PARALLEL */`) | 불필요 (BQ 자동 병렬화) |
| `VARCHAR2(N)` | `STRING` |
| `NUMBER(p,s)` | `NUMERIC` / `INT64` / `FLOAT64` |
| `DATE` (Oracle은 timestamp 포함) | `TIMESTAMP` |
| `CLOB` / `BLOB` | `STRING` / `BYTES` |

### 성능 주의사항
- **Exadata 물리 인덱스 의존 쿼리** → BQ partition/clustering 전략으로 재설계 필요
- **Nested Loop Join 패턴** (Oracle index scan 기반) → BQ에서는 Hash Join으로 자동 전환, 대형 테이블 시 pre-filter 필수
- **PL/SQL 커서 반복** → BQ SET 기반 처리 (벡터 연산)로 재작성
- **Oracle Materialized View** → BQ Materialized View (구문/제약 다름, GROUP BY + 집계 함수만)

### Oracle vs BigQuery 실행 모델 비교

| 항목 | Oracle (Exadata) | BigQuery |
|------|-----------------|----------|
| **스토리지 구조** | Row-store + Smart Scan (column projection) | 완전 Columnar (Capacitor 포맷) |
| **인덱스** | B-tree, Bitmap, Function-based 등 | 없음 — Partition Pruning + Clustering으로 대체 |
| **JOIN 전략** | Nested Loop (index), Hash Join, Sort-Merge | Hash Join (shuffle/broadcast) — optimizer 자동 선택 |
| **정렬** | Index-ordered scan으로 sort 회피 가능 | 항상 명시적 sort (shuffle 필요), LIMIT 없으면 전체 데이터 정렬 |
| **병렬화** | `/*+ PARALLEL(N) */` hint로 수동 제어 | 자동 (슬롯 기반 분산), hint 불필요 |
| **캐싱** | Buffer Cache (SGA), Result Cache | 24시간 결과 캐시 (동일 쿼리 + 테이블 미변경 시) |
| **파티셔닝** | Range, List, Hash, Composite | 시간/정수 Range, Ingestion-time 파티션 |
| **통계 수집** | `DBMS_STATS`, `/*+ GATHER_PLAN_STATISTICS */` | 자동 (INFORMATION_SCHEMA.JOBS에 job_stages 포함) |
| **실행 계획** | `EXPLAIN PLAN`, SQL Monitor (`/*+ MONITOR */`) | 쿼리 실행 후 `INFORMATION_SCHEMA.JOBS.job_stages` 또는 Web UI |

### Oracle Hint → BQ 대체 전략

| Oracle Hint | Oracle 목적 | BQ 대체 전략 |
|-------------|-----------|-------------|
| `/*+ PARALLEL(N) */` | 병렬 실행 DOP 지정 | 불필요 — BQ 자동 슬롯 분배 |
| `/*+ FULL(t) */` | Full Table Scan 강제 | 불필요 — BQ 기본이 Full Scan (파티션 프루닝으로 범위 제한) |
| `/*+ INDEX(t idx) */` | 특정 인덱스 사용 강제 | 파티션 필터 + 클러스터링으로 scan 범위 축소 |
| `/*+ USE_HASH(t) */` | Hash Join 강제 | BQ 기본 전략, 작은 테이블은 broadcast join 자동 적용 |
| `/*+ USE_NL(t) */` | Nested Loop Join 강제 | BQ 미지원 — Hash Join으로 자동 대체 |
| `/*+ LEADING(t1 t2) */` | JOIN 순서 지정 | 불필요 — BQ optimizer 자동 결정 |
| `/*+ MONITOR */` | SQL Monitor 실시간 추적 | `INFORMATION_SCHEMA.JOBS`가 모든 쿼리 자동 기록 |
| `/*+ GATHER_PLAN_STATISTICS */` | 실행 통계 수집 | `job_stages` 필드에 stage별 통계 자동 포함 |
| `/*+ RESULT_CACHE */` | 결과 캐시 활성화 | BQ 24시간 자동 캐시 (동일 쿼리 + 테이블 미변경) |
| `/*+ NO_RESULT_CACHE */` | 캐시 우회 | `SELECT` 뒤에 `@{cache=false}` 힌트 사용 |
| `/*+ APPEND */` | Direct-path insert | BQ `INSERT`/`LOAD` 기본 동작 (append) |
| `/*+ PUSH_PRED */` | 조건 predicate pushdown | BQ optimizer 자동 적용 |

### 변환 시 Anti-Pattern 체크

Oracle에서 문제없지만 BQ에서 anti-pattern이 되는 패턴:

| Oracle 패턴 | BQ에서의 문제 | 권고 |
|------------|-------------|------|
| `ORDER BY col DESC` (LIMIT 없음) | BQ에서 전체 데이터 shuffle sort → 대량 slot 소비 | 반드시 `LIMIT N` 추가, 없으면 anti-pattern 경고 |
| `SELECT *` | Oracle은 row-store라 영향 적음, BQ는 columnar → 불필요 컬럼도 전부 scan | 필요 컬럼만 명시 (bytes_processed 대폭 감소) |
| `VARCHAR2` 컬럼 JOIN key | Oracle은 인덱스로 고속 매칭, BQ는 STRING Hash → 느림 | 가능하면 INT64 surrogate key 사용, 불가 시 클러스터링 적용 |

### 변환 시 Mermaid 시각화 예시

```
graph LR
    subgraph "Oracle 구문"
        O1["ROWNUM <= 10"]
        O2["NVL(col, 0)"]
        O3["DECODE(status, 'A', 'Active')"]
        O4["table_a a, table_b b<br/>WHERE a.id = b.id(+)"]
    end

    subgraph "변환 규칙"
        R1["ROW_NUMBER() OVER()"]
        R2["IFNULL / COALESCE"]
        R3["CASE WHEN"]
        R4["LEFT JOIN"]
    end

    subgraph "BigQuery 구문"
        B1["ROW_NUMBER() OVER() <= 10"]
        B2["IFNULL(col, 0)"]
        B3["CASE WHEN status='A'<br/>THEN 'Active' END"]
        B4["table_a a LEFT JOIN<br/>table_b b ON a.id=b.id"]
    end

    O1 --> R1 --> B1
    O2 --> R2 --> B2
    O3 --> R3 --> B3
    O4 --> R4 --> B4

    style O1 fill:#EA4335,color:#fff
    style O2 fill:#EA4335,color:#fff
    style O3 fill:#EA4335,color:#fff
    style O4 fill:#EA4335,color:#fff
    style B1 fill:#34A853,color:#fff
    style B2 fill:#34A853,color:#fff
    style B3 fill:#34A853,color:#fff
    style B4 fill:#34A853,color:#fff
```

---

## ⚠️ 필수 출력 규칙

**모든 Oracle→BQ 변환 응답에는 반드시 ```mermaid 다이어그램을 포함하세요.**
- Oracle 실행 흐름 다이어그램 (graph TD)
- BigQuery 실행 흐름 다이어그램 (graph TD)
- 두 흐름의 비교가 시각적으로 드러나야 합니다.
- 다이어그램 없는 응답은 불완전한 응답입니다.
