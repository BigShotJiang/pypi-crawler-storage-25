---
name: athena_tuning
description: Athena 쿼리 성능 튜닝. EXPLAIN 분석, 파티션 프루닝, Predicate Pushdown, 비용 최적화, 파일 포맷.
---

# Athena Query Performance Tuning Guide

Athena 쿼리 분석, 튜닝, 비용 최적화 시 참고하는 레퍼런스 가이드입니다.

---

## 1. EXPLAIN 출력 분석

### EXPLAIN 실행
```sql
EXPLAIN (TYPE DISTRIBUTED)
SELECT ...
```

### 주요 노드 해석

| 노드 | 의미 | 최적화 포인트 |
|------|------|-------------|
| `TableScan` | 테이블 전체/파티션 스캔 | 파티션 필터 확인 |
| `FilterProject` | WHERE 조건 적용 | Predicate Pushdown 여부 |
| `HashAggregate` | GROUP BY 집계 | 메모리 사용량 주의 |
| `Exchange` | 셔플 (데이터 재분배) | 조인 키 선택 최적화 |
| `Join` | 조인 연산 | 작은 테이블 먼저 (build side) |
| `Output` | 최종 결과 출력 | 불필요 컬럼 제거 |

### Fragment 분석
```
Fragment 0 [SINGLE]     → 최종 결과 수집 (coordinator)
Fragment 1 [HASH]       → 해시 분배 (조인/집계)
Fragment 2 [SOURCE]     → 데이터 소스 스캔
```
- `SINGLE`: 단일 노드 처리 → 병목 가능성
- `HASH`: 데이터 재분배 → 네트워크 비용
- `SOURCE`: 병렬 스캔 → 파티션 수 = 병렬도

---

## 2. 파티션 프루닝

### Hive 파티션 테이블
```sql
-- ✅ 파티션 프루닝 작동
WHERE dt = '2024-01-01'
WHERE dt BETWEEN '2024-01-01' AND '2024-01-31'
WHERE year = 2024 AND month = 1

-- ❌ 파티션 프루닝 실패
WHERE CAST(dt AS DATE) > DATE '2024-01-01'   -- 함수 적용
WHERE dt LIKE '2024%'                          -- 패턴 매칭
WHERE dt IN (SELECT dt FROM other_table)       -- 서브쿼리
```

### Iceberg 파티션
```sql
-- Iceberg는 hidden partitioning → 자동 프루닝
WHERE event_time >= TIMESTAMP '2024-01-01'  -- day(event_time) 파티션 자동 적용
```

### 파티션 프루닝 확인
```sql
EXPLAIN SELECT ... WHERE dt = '2024-01-01'
-- "assignments" 부분에서 실제 스캔 파티션 수 확인
```

---

## 3. Predicate Pushdown

### 동작 조건
| 조건 | Parquet | ORC | CSV/JSON |
|------|---------|-----|----------|
| `=`, `<>`, `<`, `>`, `<=`, `>=` | ✅ | ✅ | ❌ |
| `BETWEEN` | ✅ | ✅ | ❌ |
| `IN (values)` | ✅ | ✅ | ❌ |
| `IS NULL` / `IS NOT NULL` | ✅ | ✅ | ❌ |
| `LIKE 'prefix%'` | ⚠️ 부분 | ⚠️ 부분 | ❌ |
| 함수 적용 (`UPPER()`, `CAST()`) | ❌ | ❌ | ❌ |

### 최적화 전략
```sql
-- ❌ Pushdown 실패 (함수 적용)
WHERE YEAR(event_date) = 2024

-- ✅ Pushdown 성공
WHERE event_date >= DATE '2024-01-01' AND event_date < DATE '2025-01-01'
```

---

## 4. 파일 포맷 최적화

### 포맷별 비교

| 항목 | Parquet | ORC | CSV | JSON |
|------|---------|-----|-----|------|
| 컬럼 프루닝 | ✅ | ✅ | ❌ | ❌ |
| Predicate Pushdown | ✅ | ✅ | ❌ | ❌ |
| 압축률 | 높음 | 높음 | 낮음 | 매우 낮음 |
| 스키마 진화 | ✅ | ✅ | ❌ | ⚠️ |
| 권장 사용 | **분석 표준** | Hive 호환 | 임시/소량 | 로그 |

### 파일 크기 최적화
```
권장 파일 크기: 128MB ~ 512MB
- 너무 작은 파일 (<1MB): S3 요청 오버헤드 → CTAS로 병합
- 너무 큰 파일 (>1GB): 병렬 처리 효율 저하
```

### CTAS로 포맷 변환/파일 병합
```sql
CREATE TABLE optimized_table
WITH (
  format = 'PARQUET',
  parquet_compression = 'SNAPPY',
  external_location = 's3://bucket/optimized/',
  partitioned_by = ARRAY['dt']
) AS
SELECT * FROM source_table
WHERE dt >= '2024-01-01';
```

---

## 5. 비용 최적화

### 비용 모델
```
비용 = 스캔 바이트 × $5.00 / TB
최소 청구 단위: 10 MB per 쿼리
반올림 단위: 1 MB
```

### 비용 절감 전략

| 전략 | 절감률 | 구현 |
|------|--------|------|
| 컬럼 기반 포맷 (Parquet) | 30-90% | CTAS 변환 |
| 파티셔닝 | 50-99% | dt/region 파티션 |
| 컬럼 프루닝 (SELECT 명시) | 20-80% | SELECT * 제거 |
| 압축 (Snappy/ZSTD) | 20-40% | CTAS 옵션 |
| LIMIT 사용 | 0% (주의!) | 전체 스캔 후 잘라냄 |
| Workgroup 예산 제한 | N/A | 바이트 쿼터 설정 |

### 비용 추정 쿼리
```sql
-- 쿼리 스캔량 확인 (실행 없이)
EXPLAIN SELECT ...;
-- "Physical input" 항목에서 예상 스캔량 확인

-- 또는 Workgroup 설정으로 예산 제한
-- Per-Query Data Usage Control: 1 TB
```

---

## 6. Anti-Pattern

| # | Anti-Pattern | 문제 | 올바른 방법 |
|---|-------------|------|------------|
| 1 | `SELECT *` | 불필요 컬럼 스캔 → 비용 증가 | 필요 컬럼만 명시 |
| 2 | CSV/JSON 대량 분석 | Pushdown 불가 → 전체 스캔 | Parquet/ORC 변환 |
| 3 | 파티션 필터 누락 | 전체 파티션 스캔 | WHERE dt = '...' 필수 |
| 4 | 함수로 파티션 컬럼 감싸기 | 프루닝 실패 | 리터럴 비교 사용 |
| 5 | 작은 파일 다수 | S3 요청 폭증 | CTAS로 병합 (128MB+) |
| 6 | `ORDER BY` without `LIMIT` | 전체 정렬 → 메모리 폭발 | `LIMIT` 필수 또는 제거 |
| 7 | `CROSS JOIN` | 카테시안 곱 → OOM | 조인 키 명시 |
| 8 | `NOT IN (subquery)` | 비효율 실행계획 | `LEFT JOIN ... IS NULL` |
| 9 | `UNION` 대신 `UNION ALL` | 불필요 중복 제거 비용 | 중복 없으면 `UNION ALL` |
| 10 | Athena v2에서 v3 미전환 | Iceberg/성능 개선 미활용 | Athena v3 (Trino) 전환 |

---

## 7. Athena v3 (Trino) 최적화

### v2 vs v3 차이

| 항목 | Athena v2 (Presto) | Athena v3 (Trino) |
|------|--------------------|--------------------|
| 엔진 | Presto 0.217 | Trino 기반 |
| Iceberg | 읽기만 | 읽기+쓰기+MERGE |
| EXPLAIN | 기본 | DISTRIBUTED 지원 |
| 동적 필터링 | ❌ | ✅ |
| Fault-tolerant | ❌ | ✅ (일부) |

### Trino 전용 최적화
```sql
-- 동적 필터링: 조인 시 build-side 필터를 probe-side에 자동 적용
-- (설정 불필요, v3에서 자동)

-- Iceberg MERGE
MERGE INTO target t
USING source s ON t.id = s.id
WHEN MATCHED THEN UPDATE SET t.value = s.value
WHEN NOT MATCHED THEN INSERT VALUES (s.id, s.value);
```
