---
name: athena
description: Athena 전문가 기본 가이드. 세부 가이드는 athena_tuning, athena_log 참조.
---

# Athena Expert Guide

Athena agent의 3대 역할별 세부 가이드:

| 요청 유형 | 로드할 스킬 | 설명 |
|-----------|------------|------|
| 성능 튜닝 / EXPLAIN 분석 / 비용 최적화 | `athena_tuning` | 파티션 프루닝, Predicate Pushdown, 파일 포맷, 비용 공식 |
| CloudWatch 로그 / 쿼리 실행 통계 분석 | `athena_log` | CloudWatch 메트릭, 쿼리 실행 통계, 에러 패턴 진단 |
| 쿼리 오류 수정 | `athena_tuning` | anti-pattern 탐지 + 비용/성능 분석으로 오류 원인 진단 |

## 사용법
1. 요청 유형 판단
2. `load_skill('athena_tuning')` 또는 `load_skill('athena_log')` 호출
3. 두 가지 모두 필요하면 둘 다 호출
