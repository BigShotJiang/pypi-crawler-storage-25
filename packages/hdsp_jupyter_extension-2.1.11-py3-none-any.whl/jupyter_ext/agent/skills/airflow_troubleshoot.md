---
name: airflow_troubleshoot
description: Airflow 에러 분석 및 로그 해석 가이드. MWAA/Composer task failure, dependency error, scheduler 문제 진단.
---

# Airflow Troubleshooting & Log Interpretation Guide

MWAA 및 Cloud Composer 환경의 에러 분석, 로그 해석 가이드입니다.

## 1. Task State Transitions

```mermaid
graph LR
    style none fill:#9E9E9E,color:white
    style scheduled fill:#2196F3,color:white
    style queued fill:#FF9800,color:white
    style running fill:#4CAF50,color:white
    style success fill:#4CAF50,color:white
    style failed fill:#F44336,color:white
    style up_failed fill:#F44336,color:white
    style skipped fill:#9E9E9E,color:white

    none["none"] --> scheduled["scheduled"]
    scheduled --> queued["queued"]
    queued --> running["running"]
    running --> success["success ✅"]
    running --> failed["failed ❌"]
    none --> up_failed["upstream_failed"]
    running --> skipped["skipped"]
```

### State 의미

| State | 설명 | 진단 포인트 |
|-------|------|------------|
| `none` | 아직 스케줄되지 않음 | DAG 파싱/스케줄 문제 확인 |
| `scheduled` | 실행 예약됨 | 스케줄러 정상, executor 큐 확인 |
| `queued` | Worker 대기 중 | Worker 가용성, Pool 슬롯 확인 |
| `running` | 실행 중 | 정상 진행, timeout 모니터링 |
| `success` | 성공 완료 | - |
| `failed` | 실행 실패 | **Task 로그 확인 필수** |
| `upstream_failed` | Upstream task 실패로 skip | upstream task 로그 확인 |
| `skipped` | 조건부 skip | trigger_rule, ShortCircuit 확인 |
| `up_for_retry` | 재시도 대기 | 재시도 횟수/간격 확인 |
| `up_for_reschedule` | Sensor reschedule 대기 | poke_interval, mode 확인 |

## 2. 에러 패턴별 진단

### Critical 에러

| 에러 패턴 | 원인 | MWAA 해결 | Composer 해결 |
|-----------|------|-----------|---------------|
| `Negsignal.SIGKILL` / `SIGTERM` | OOM — Worker 메모리 초과 | Environment class 업그레이드 (mw1.medium→large), `worker_concurrency` 낮춤 | Worker pod 메모리 증가, `worker_concurrency` 낮춤 |
| `AirflowTaskTimeout` | `execution_timeout` 초과 | timeout 값 증가 또는 Task 분리 | 동일 |
| `AirflowSensorTimeout` | Sensor timeout 도달 | `mode='reschedule'`, `poke_interval` 증가, `timeout` 증가 | 동일 |
| `DagFileProcessorTimeout` | DAG 파싱 시간 초과 (기본 50초) | top-level 코드 정리, `dagbag_import_timeout` 증가 | 동일 |
| `OperationalError: connection` | DB connection pool 고갈 | `sql_alchemy_pool_size` 증가 (기본 5), PgBouncer 권장 | 동일 |
| `Zombie task detected` | Worker 비정상 종료 후 Task 잔류 | `scheduler_zombie_task_threshold` 확인 (기본 300초) | GKE pod eviction 확인 |

### Warning 에러

| 에러 패턴 | 원인 | 해결 |
|-----------|------|------|
| `Task is not able to be run` | Pool 슬롯 부족 | Pool 슬롯 증가 또는 `pool_slots` 조정 |
| `Maximum number of running tasks` | `max_active_tasks_per_dag` 도달 | 값 증가 또는 DAG 분리 |
| `Executor reports task instance finished` | Worker crash 후 Task 실패 처리 | Worker 리소스 확인, 로그 분석 |
| `Could not read served logs` | 로그 파일 접근 실패 | S3/GCS 로그 설정 확인, 권한 확인 |

### Sensor 에러 상세

| Mode | 동작 | Worker 슬롯 | 적합한 상황 |
|------|------|-------------|------------|
| `poke` | Worker 안에서 sleep 후 재확인 | 전체 시간 점유 | 짧은 대기 (<5분) |
| `reschedule` | Worker 반환 후 재스케줄 | 확인 시에만 점유 | 긴 대기 (>5분) |
| `deferrable=True` | Triggerer에 위임 (Airflow 2.6+) | **점유 안 함** | 최적 (권장) |

```python
# ❌ 문제: mode='poke'는 Worker 슬롯을 점유하며 대기
sensor = S3KeySensor(
    task_id="wait_for_file",
    bucket_key="s3://bucket/data/*.csv",
    mode="poke",              # Worker 슬롯 점유
    poke_interval=60,
    timeout=3600,
)

# ✅ 해결 1: mode='reschedule'로 변경
sensor = S3KeySensor(
    task_id="wait_for_file",
    bucket_key="s3://bucket/data/*.csv",
    mode="reschedule",        # Worker 슬롯 반환
    poke_interval=300,         # 5분마다 확인
    timeout=7200,              # 2시간 timeout
    exponential_backoff=True,  # 지수 백오프
)

# ✅✅ 해결 2 (최적): deferrable operator (Airflow 2.6+)
sensor = S3KeySensor(
    task_id="wait_for_file",
    bucket_key="s3://bucket/data/*.csv",
    deferrable=True,           # Triggerer에 위임, Worker 슬롯 0
    poke_interval=300,
    timeout=7200,
)
```

**참고**: `timeout` 파라미터는 `reschedule`/`deferrable` 모드에서만 유효. `poke` 모드에서는 `execution_timeout` (task-level)이 적용됨.

**알려진 이슈**: OOM으로 kill된 Task는 `retries` 설정이 있어도 재시도 없이 바로 `failed` 상태가 될 수 있음 ([apache/airflow#55753](https://github.com/apache/airflow/issues/55753)).
Airflow 2.10+부터는 scheduler/executor 에러가 task 로그에 자동 포워딩됨.

## 3. MWAA 고유 이슈

### S3 DAG Sync
| 문제 | 원인 | 해결 |
|------|------|------|
| **새 DAG** 업로드 후 인식 안 됨 | S3→Fargate sync ~30초 + `dag_dir_list_interval` ~300초 | 최대 5분 대기, `dag_dir_list_interval` 낮춤 |
| **기존 DAG 수정** 후 반영 안 됨 | S3 sync ~30초 + `min_file_process_interval` | ~60초 대기 |
| DAG 삭제 후 계속 보임 | S3 eventual consistency | 수 분 대기, 환경 재시작 |
| Import error 발생 | S3 파일 부분 업로드 | 전체 파일 재업로드, `.airflowignore` 확인 |

**⚠️ DAGs 폴더에 비-DAG `.py` 파일 넣지 말 것** — MWAA가 모든 `.py`를 파싱 시도함

### plugins.zip 패키징
```bash
# 올바른 구조
plugins.zip
├── __init__.py            # 필수!
├── my_plugin.py           # plugins/ 폴더 없이 flat 구조
├── operators/
│   ├── __init__.py
│   └── custom_operator.py
└── hooks/
    ├── __init__.py
    └── custom_hook.py

# ⚠️ 흔한 실수: plugins/ 폴더를 포함하여 패키징
# ❌ plugins.zip/plugins/my_plugin.py  → 인식 안 됨 (이중 중첩)
# ✅ plugins.zip/my_plugin.py           → 정상

# ⚠️ plugins.zip 업로드 후 MWAA 콘솔에서 버전 번호 업데이트 필수
# 한번 추가한 plugins.zip은 제거 불가 → 빈 .zip으로 교체하여 무력화
```

### requirements.txt 관련
```bash
# 버전 충돌 방지
apache-airflow-providers-amazon==8.0.0  # 버전 명시 필수
pandas==2.0.3                             # 정확한 버전
# ❌ pandas  → 최신 버전이 호환 안 될 수 있음
# ❌ numpy>=1.24  → 범위 지정 시 예측 불가

# 설치 로그 확인 (CloudWatch)
# Log group: airflow-{env-name}-Requirementsinstall
```

### MWAA CLI 사용
```bash
# CLI 토큰 생성 (60초 유효)
aws mwaa create-cli-token --name YOUR_ENV_NAME

# CLI 실행 (curl)
CLI_TOKEN=$(aws mwaa create-cli-token --name YOUR_ENV --query CliToken --output text)
WEBSERVER=$(aws mwaa get-environment --name YOUR_ENV --query Environment.WebserverUrl --output text)

curl -X POST "https://${WEBSERVER}/aws_mwaa/cli" \
  -H "Authorization: Bearer ${CLI_TOKEN}" \
  -H "Content-Type: text/plain" \
  -d "dags list"

# ⚠️ 동시 CLI 호출 4개 이내 권장 (Webserver 보호)
```

### CloudWatch 로그 그룹
```
airflow-{env-name}-DAGProcessing    # DAG 파싱 로그
airflow-{env-name}-Scheduler        # 스케줄러 로그
airflow-{env-name}-Task             # Task 실행 로그
airflow-{env-name}-WebServer        # 웹서버 로그
airflow-{env-name}-Worker           # Worker 로그
```

## 4. Cloud Composer 고유 이슈

### GCS DAG Sync
| 문제 | 원인 | 해결 |
|------|------|------|
| DAG 업로드 후 지연 (~10-30초) | gcsfuse 마운트 + `dag_dir_list_interval` | 대기, interval 조정 |
| DAG 폴더 경로 오류 | Composer가 관리하는 GCS bucket 구조 | `gs://bucket/dags/` 하위에만 업로드 |
| 파싱 중 DAG 변경 시 에러 | gcsfuse가 실시간 반영 | 일시적, 다음 파싱 주기에 해결됨 |

**참고**: Composer는 gcsfuse로 GCS를 직접 마운트 (복사 아님). 로컬 파일시스템보다 지연이 있으므로 DAG 파싱 시 파일 I/O를 최소화할 것.

```bash
# Composer DAG 업로드
gcloud composer environments storage dags import \
  --environment ENV_NAME \
  --location LOCATION \
  --source my_dag.py

# DAG 목록 확인
gcloud composer environments run ENV_NAME \
  --location LOCATION \
  dags list
```

### PyPI 패키지 관리
```bash
# CLI로 패키지 설치
gcloud composer environments update ENV_NAME \
  --location LOCATION \
  --update-pypi-packages-from-file requirements.txt

# 단일 패키지
gcloud composer environments update ENV_NAME \
  --location LOCATION \
  --update-pypi-package pandas==2.0.3

# ⚠️ 패키지 설치 시 환경 업데이트 발생 (수 분 소요)
```

### GKE Pod Eviction
| 원인 | 증상 | 해결 |
|------|------|------|
| 메모리 초과 | Pod `OOMKilled` | Worker 리소스 증가 (Composer UI → WORKLOADS) |
| 디스크 부족 | Pod `Evicted` | 임시 파일 정리, PV 크기 증가 |
| Node 리소스 부족 | Pod `Pending` | Node pool 크기 증가 |

**메모리 집약 Task 격리 (KubernetesPodOperator)**:
```python
from airflow.providers.cncf.kubernetes.operators.kubernetes_pod import KubernetesPodOperator
from kubernetes.client import models as k8s

heavy_task = KubernetesPodOperator(
    task_id="heavy_processing",
    namespace="composer-user-workloads",  # Composer 2 전용 네임스페이스
    image="my-image:latest",
    container_resources=k8s.V1ResourceRequirements(
        requests={"memory": "8Gi", "cpu": "2"},
        limits={"memory": "16Gi", "cpu": "4"},
    ),
)
```

### Cloud Logging 검색
```
# Cloud Logging 필터
resource.type="cloud_composer_environment"
resource.labels.environment_name="ENV_NAME"

# Task 로그만
log_name="projects/PROJECT/logs/airflow-worker"
jsonPayload.message=~"ERROR"

# Scheduler 로그만
log_name="projects/PROJECT/logs/airflow-scheduler"
```

## 5. 로그 해석 가이드

### Task 로그 구조
```
# 로그 경로 패턴
{base_log_folder}/{dag_id}/{task_id}/{execution_date}/{try_number}.log

# Airflow 2.x 경로
{base_log_folder}/dag_id={dag_id}/run_id={run_id}/task_id={task_id}/attempt={try_number}.log
```

### Task 로그 핵심 패턴

| 로그 패턴 | 의미 | 조치 |
|-----------|------|------|
| `Starting attempt N of M` | N번째 시도 시작 | 이전 시도 로그 확인 |
| `Marking task as SUCCESS` | Task 성공 완료 | 정상 |
| `Marking task as FAILED` | Task 실패 | **바로 위 라인에 에러 원인** |
| `Task exited with return code Negsignal.SIGKILL` | OOM Kill | Worker 메모리 확인 |
| `Task timed out` | execution_timeout 초과 | timeout 증가 또는 Task 분리 |
| `Received SIGTERM. Terminating subprocesses` | 외부 종료 신호 | Worker 재시작, 스케일링 이벤트 확인 |
| `Dependencies not met` | upstream 미완료 | upstream task 상태 확인 |
| `Pool: X is full` | Pool 슬롯 부족 | Pool 크기 증가 |

### Scheduler 로그 핵심 패턴

| 로그 패턴 | 의미 | 조치 |
|-----------|------|------|
| `Heartbeat` | 스케줄러 정상 동작 | 정상 |
| `DAG {dag_id} is paused` | DAG 일시정지 상태 | Unpause 필요 시 확인 |
| `Processing file {path} took X seconds` | DAG 파싱 시간 | X가 높으면 DAG 최적화 필요 |
| `DagFileProcessorManager running {N} processors` | 파싱 프로세스 수 | N < `parsing_processes`면 파일 적음 |
| `Detected zombie job` | 좀비 Task 감지 | Worker 상태 확인 |
| `Timed out while waiting for the executor` | Executor 응답 없음 | Executor/Worker 상태 확인 |

### Worker 로그 핵심 패턴

| 로그 패턴 | 의미 | 조치 |
|-----------|------|------|
| `Received task: {task}` | Task 수신 | 정상 |
| `Task {task} succeeded` | Task 완료 | 정상 |
| `celeryd: Warm shutdown` | Worker 정상 종료 | Auto-scaling 축소일 수 있음 |
| `celeryd: Cold shutdown` | Worker 강제 종료 | OOM 또는 외부 종료 확인 |
| `Cannot allocate memory` | 메모리 할당 실패 | Worker 리소스 증가 필요 |

## 6. Dependency 에러 분석

### upstream_failed 진단
```mermaid
graph TD
    style taskA fill:#F44336,color:white
    style taskB fill:#F44336,color:white
    style taskC fill:#9E9E9E,color:white

    taskA["Task A<br/>❌ FAILED"] --> taskB["Task B<br/>upstream_failed"]
    taskA --> taskC["Task C<br/>upstream_failed"]
```

**해결 순서**: Task A 로그 확인 → Task A 원인 해결 → downstream 자동 해결

### ExternalTaskSensor 이슈
```python
# 문제: 다른 DAG의 Task 완료 대기
sensor = ExternalTaskSensor(
    task_id="wait_for_upstream_dag",
    external_dag_id="upstream_dag",
    external_task_id="final_task",
    execution_delta=timedelta(hours=1),  # ⚠️ 시간 차이 정확히 설정
    mode="reschedule",
    timeout=7200,
)

# 흔한 실수:
# 1. execution_delta / execution_date_fn 잘못 설정 → 영원히 대기
# 2. 외부 DAG의 schedule_interval 변경 → execution_date 불일치
# 3. 외부 Task 이름 변경 → 센서 실패
```

### Dataset-triggered DAG (Airflow 2.4+)
```python
# Producer DAG
from airflow.datasets import Dataset

my_dataset = Dataset("s3://bucket/data/output.csv")

@task(outlets=[my_dataset])
def produce_data():
    # 데이터 생성...
    pass

# Consumer DAG - Dataset 업데이트 시 자동 트리거
@dag(schedule=[my_dataset])
def consumer_dag():
    @task
    def consume_data():
        pass
```

## 7. 스케줄러 문제 진단

### DAG가 스케줄되지 않는 경우

```mermaid
graph TD
    style check1 fill:#2196F3,color:white
    style check2 fill:#2196F3,color:white
    style check3 fill:#2196F3,color:white
    style check4 fill:#2196F3,color:white
    style fix fill:#4CAF50,color:white

    check1["DAG paused?"] -->|Yes| fix1["Unpause DAG"]
    check1 -->|No| check2["Import error?"]
    check2 -->|Yes| fix2["DAG 코드 수정"]
    check2 -->|No| check3["start_date 미래?"]
    check3 -->|Yes| fix3["start_date 과거로 변경"]
    check3 -->|No| check4["max_active_runs 도달?"]
    check4 -->|Yes| fix4["이전 Run 정리 또는 값 증가"]
    check4 -->|No| fix5["Scheduler 로그 확인"]
```

### 스케줄러 Loop Time 진단
```
# 정상: 1-5초
# 주의: 5-15초 (DAG 수 또는 파싱 복잡도 높음)
# 위험: 15초+ (스케줄러 과부하)

# 확인 방법 (Airflow metrics)
# scheduler.scheduler_loop_duration_seconds
```

### Zombie Task 처리
```python
# airflow.cfg 설정
[scheduler]
scheduler_zombie_task_threshold = 300  # 300초 이상 heartbeat 없으면 zombie
zombie_detection_interval = 10.0       # zombie 체크 주기

# CLI로 zombie 강제 정리
# airflow tasks clear {dag_id} -t {task_id} -s {start_date} -e {end_date}
```

## 8. 빠른 진단 체크리스트

### Task 실패 시
1. ✅ Task 로그 확인 (Airflow UI → DAG → Task → Log)
2. ✅ 에러 메시지 패턴 매칭 (위 테이블 참조)
3. ✅ 이전 시도(attempt) 로그도 확인
4. ✅ Upstream task 상태 확인
5. ✅ Worker 리소스 (메모리, CPU) 확인
6. ✅ 외부 시스템 연결 상태 확인

### 성능 저하 시
1. ✅ `parallelism` vs 실제 동시 Task 수 비교
2. ✅ Pool 슬롯 가용량 확인
3. ✅ Scheduler 로그에서 파싱 시간 확인
4. ✅ Worker Auto-scaling 상태 확인
5. ✅ DB connection pool 사용량 확인
6. ✅ Anti-pattern 코드 검사 (top-level Variable.get 등)

### DAG 인식 안 될 때
1. ✅ DAG 파일 문법 오류 확인 (`python -c "import dag_file"`)
2. ✅ `.airflowignore` 패턴 확인
3. ✅ `dag_dir_list_interval` 대기
4. ✅ Scheduler DAG Processing 로그 확인
5. ✅ S3/GCS sync 상태 확인 (MWAA/Composer)
