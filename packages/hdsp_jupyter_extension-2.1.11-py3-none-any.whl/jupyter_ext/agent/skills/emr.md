---
name: emr
description: EMR 전문가 기본 가이드. 세부 가이드는 emr_tuning, emr_log 참조.
---

# EMR Expert Guide

EMR agent의 3대 역할별 세부 가이드:

| 요청 유형 | 로드할 스킬 | 설명 |
|-----------|------------|------|
| Spark 성능 튜닝 / Executor·Memory 설정 / 비용 최적화 | `emr_tuning` | AQE, Shuffle, Broadcast Join, Dynamic Allocation, 데이터 Skew |
| Spark UI / YARN 로그 / CloudWatch EMR 메트릭 분석 | `emr_log` | Stage 메트릭, GC/OOM 패턴, Fetch Failure 진단 |
| PySpark 스크립트 생성 | `emr-script` | 기존 EMR 스크립트 개발 가이드 |

## 사용법
1. 요청 유형 판단
2. 해당 스킬 로드
3. 복합 요청(튜닝+로그)이면 둘 다 로드
