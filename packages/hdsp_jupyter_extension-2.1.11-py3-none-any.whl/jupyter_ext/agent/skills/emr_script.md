---
name: emr-script
description: EMR PySpark 스크립트 개발 가이드. SparkSession, S3 I/O, EMR Step, 테스트.
---

# EMR PySpark Script Development Guide

EMR에서 실행할 PySpark 스크립트 개발 가이드입니다.

## PySpark 스크립트 기본 템플릿

```python
"""EMR PySpark job: <description>."""
import argparse
import sys
from pyspark.sql import SparkSession
from pyspark.sql import functions as F

def parse_args():
    parser = argparse.ArgumentParser(description="PySpark job")
    parser.add_argument("--input", required=True, help="Input S3 path")
    parser.add_argument("--output", required=True, help="Output S3 path")
    parser.add_argument("--date", required=False, help="Processing date (YYYY-MM-DD)")
    return parser.parse_args()

def create_spark_session(app_name: str) -> SparkSession:
    return (
        SparkSession.builder
        .appName(app_name)
        .config("spark.sql.adaptive.enabled", "true")
        .config("spark.sql.adaptive.coalescePartitions.enabled", "true")
        .getOrCreate()
    )

def main():
    args = parse_args()
    spark = create_spark_session("my-job")

    try:
        # Read
        df = spark.read.parquet(args.input)

        # Transform
        result = df.filter(F.col("status") == "active")

        # Write
        result.write.mode("overwrite").parquet(args.output)

        print(f"Job completed. Output: {args.output}")
    finally:
        spark.stop()

if __name__ == "__main__":
    main()
```

## S3 I/O 패턴

```python
# Parquet 읽기/쓰기
df = spark.read.parquet("s3://bucket/input/")
df.write.mode("overwrite").parquet("s3://bucket/output/")

# CSV 읽기/쓰기
df = spark.read.option("header", "true").csv("s3://bucket/data.csv")
df.write.option("header", "true").mode("overwrite").csv("s3://bucket/output/")

# 파티션 쓰기
df.write.partitionBy("year", "month").mode("append").parquet("s3://bucket/output/")

# 날짜 기반 경로
input_path = f"s3://bucket/data/dt={args.date}/"
```

## EMR Step JSON

```json
{
    "Name": "PySpark Job",
    "ActionOnFailure": "CONTINUE",
    "HadoopJarStep": {
        "Jar": "command-runner.jar",
        "Args": [
            "spark-submit",
            "--deploy-mode", "cluster",
            "--master", "yarn",
            "--conf", "spark.sql.adaptive.enabled=true",
            "--conf", "spark.executor.memory=4g",
            "--conf", "spark.executor.cores=4",
            "s3://bucket/scripts/my_job.py",
            "--input", "s3://bucket/input/",
            "--output", "s3://bucket/output/"
        ]
    }
}
```

## 로컬 테스트

```bash
# Local mode 테스트
spark-submit --master "local[*]" my_job.py \
    --input ./test_data/input/ \
    --output ./test_data/output/

# pytest + local Spark
pip install pyspark pytest
```

## pytest 테스트 패턴

```python
import pytest
from pyspark.sql import SparkSession
from pyspark.sql import Row

@pytest.fixture(scope="module")
def spark():
    session = (
        SparkSession.builder
        .master("local[*]")
        .appName("test")
        .config("spark.ui.enabled", "false")
        .getOrCreate()
    )
    yield session
    session.stop()

def test_transform(spark):
    data = [Row(id=1, status="active"), Row(id=2, status="inactive")]
    df = spark.createDataFrame(data)
    result = df.filter(df.status == "active")
    assert result.count() == 1
    assert result.first().id == 1

def test_aggregation(spark):
    data = [Row(category="A", amount=100), Row(category="A", amount=200)]
    df = spark.createDataFrame(data)
    result = df.groupBy("category").agg({"amount": "sum"})
    assert result.first()["sum(amount)"] == 300
```

## 성능 최적화 패턴

| 패턴 | 설명 | 사용 시점 |
|------|------|----------|
| `repartition(n)` | 파티션 수 조정 | 대량 쓰기 전 |
| `coalesce(n)` | 파티션 감소 (셔플 없음) | 소량 결과 저장 시 |
| `cache()` / `persist()` | 중간 결과 캐싱 | 반복 접근 데이터 |
| `broadcast()` | 작은 테이블 브로드캐스트 | 대-소 테이블 조인 |
| AQE (`spark.sql.adaptive.enabled`) | 런타임 최적화 | 항상 활성화 권장 |
| `mapPartitions()` | 파티션 단위 처리 | 외부 API 호출, 연결 재사용 |

## 안티패턴

| 안티패턴 | 문제 | 올바른 방법 |
|----------|------|------------|
| `collect()` 남용 | OOM 위험 | `take(n)` 또는 집계 후 수집 |
| UDF 과다 사용 | 성능 저하 | 내장 함수 (`F.col()`) 우선 사용 |
| 전체 데이터 `count()` | 불필요한 전체 스캔 | `limit(1).count()` 또는 추정 |
| 작은 파일 다수 생성 | 읽기 성능 저하 | `coalesce()` 또는 `repartition()` |
