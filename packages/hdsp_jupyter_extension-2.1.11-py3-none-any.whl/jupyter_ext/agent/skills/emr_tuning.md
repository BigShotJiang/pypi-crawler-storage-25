---
name: emr_tuning
description: EMR Spark 성능 튜닝. Executor/Memory 설정, Shuffle 최적화, AQE, Broadcast Join, Dynamic Allocation, 데이터 Skew.
---

# EMR Spark Performance Tuning Guide

EMR에서 Spark 작업 성능 최적화, Executor 사이징, Shuffle 튜닝 레퍼런스입니다.

---

## 1. Executor 사이징 공식

### 기본 공식
```
노드 사양: m5.4xlarge (16 vCPU, 64 GB)

1. OS/Hadoop 데몬 예약: 1 core, 1 GB
   사용 가능: 15 cores, 63 GB

2. Executor cores: 5 (최적, I/O 병렬성과 GC 밸런스)
   Executor 수/노드: floor(15/5) = 3

3. YARN AM 예약: 1 executor 차감
   작업 Executor 수/노드: 2 (첫 노드), 3 (나머지)

4. Memory per executor:
   총 메모리: 63 GB / 3 executors = 21 GB
   메모리 오버헤드: max(384MB, 21GB × 0.10) = 2.1 GB
   Executor 메모리: 21 - 2.1 = ~18 GB
```

### 인스턴스별 권장 설정

| 인스턴스 | vCPU | RAM | Executors/Node | Cores/Exec | Mem/Exec |
|----------|------|-----|----------------|------------|----------|
| m5.xlarge | 4 | 16GB | 1 | 3 | 10GB |
| m5.2xlarge | 8 | 32GB | 1 | 7 | 26GB |
| m5.4xlarge | 16 | 64GB | 3 | 5 | 18GB |
| m5.8xlarge | 32 | 128GB | 5 | 5 | 22GB |
| r5.4xlarge | 16 | 128GB | 3 | 5 | 38GB |

### Spark 설정
```python
spark = SparkSession.builder \
    .config("spark.executor.cores", "5") \
    .config("spark.executor.memory", "18g") \
    .config("spark.executor.memoryOverhead", "2g") \
    .config("spark.driver.memory", "8g") \
    .config("spark.driver.cores", "5") \
    .getOrCreate()
```

---

## 2. Shuffle 최적화

### spark.sql.shuffle.partitions
```python
# 기본값: 200 (대부분 과다 또는 부족)

# 권장 공식:
# 파티션 수 = 전체 셔플 데이터 크기 / 128MB
# 예: 셔플 데이터 50GB → 50GB / 128MB ≈ 400 파티션

spark.conf.set("spark.sql.shuffle.partitions", "400")
```

### Shuffle 관련 설정

| 설정 | 기본값 | 권장 | 설명 |
|------|--------|------|------|
| `spark.sql.shuffle.partitions` | 200 | 데이터 의존 | 셔플 파티션 수 |
| `spark.shuffle.compress` | true | true | 셔플 데이터 압축 |
| `spark.shuffle.spill.compress` | true | true | 스필 데이터 압축 |
| `spark.reducer.maxSizeInFlight` | 48m | 96m | 리듀서 버퍼 |
| `spark.shuffle.file.buffer` | 32k | 64k | 셔플 파일 버퍼 |
| `spark.shuffle.io.maxRetries` | 3 | 10 | 셔플 읽기 재시도 |
| `spark.shuffle.io.retryWait` | 5s | 10s | 재시도 대기 |

---

## 3. AQE (Adaptive Query Execution)

### 핵심 설정
```python
# AQE 활성화 (EMR 6.x 기본 활성화)
spark.conf.set("spark.sql.adaptive.enabled", "true")

# 자동 파티션 병합
spark.conf.set("spark.sql.adaptive.coalescePartitions.enabled", "true")
spark.conf.set("spark.sql.adaptive.coalescePartitions.minPartitionSize", "64MB")

# 자동 Broadcast Join 전환
spark.conf.set("spark.sql.adaptive.autoBroadcastJoinThreshold", "30MB")

# Skew Join 최적화
spark.conf.set("spark.sql.adaptive.skewJoin.enabled", "true")
spark.conf.set("spark.sql.adaptive.skewJoin.skewedPartitionFactor", "5")
spark.conf.set("spark.sql.adaptive.skewJoin.skewedPartitionThresholdInBytes", "256MB")
```

### AQE 효과 확인
```
Spark UI > SQL 탭 > 쿼리 클릭
→ "AQE" 마커가 있는 노드 확인
→ 자동 최적화 적용 여부 표시
```

---

## 4. Broadcast Join

### 자동 Broadcast
```python
# 기본값: 10MB (작은 테이블 자동 브로드캐스트)
spark.conf.set("spark.sql.autoBroadcastJoinThreshold", "30MB")  # 30MB로 증가

# 브로드캐스트 비활성화
spark.conf.set("spark.sql.autoBroadcastJoinThreshold", "-1")
```

### 수동 Broadcast 힌트
```python
from pyspark.sql.functions import broadcast

result = large_df.join(
    broadcast(small_df),  # 명시적 브로드캐스트
    on="join_key"
)
```

### Broadcast 사이즈 기준
```
Broadcast 가능: 테이블 크기 < executor 메모리의 30%
예: executor 18GB → 최대 ~5GB 테이블까지 broadcast 가능
   (단 드라이버 메모리도 충분해야 함)
```

---

## 5. Dynamic Allocation

### 설정
```python
spark.conf.set("spark.dynamicAllocation.enabled", "true")
spark.conf.set("spark.dynamicAllocation.minExecutors", "2")
spark.conf.set("spark.dynamicAllocation.maxExecutors", "50")
spark.conf.set("spark.dynamicAllocation.initialExecutors", "5")

# 스케일 업/다운 기준
spark.conf.set("spark.dynamicAllocation.schedulerBacklogTimeout", "1s")    # 큐 대기 → 스케일 업
spark.conf.set("spark.dynamicAllocation.executorIdleTimeout", "60s")       # 유휴 → 스케일 다운
spark.conf.set("spark.dynamicAllocation.cachedExecutorIdleTimeout", "300s") # 캐시 보유 executor
```

---

## 6. 데이터 Skew 처리

### Skew 탐지
```
Spark UI > Stages > Task Duration 분포
→ 일부 Task만 비정상적으로 오래 걸리면 Skew
→ Shuffle Read Size 분포도 확인
```

### 해결 전략

**Salting 기법**:
```python
import pyspark.sql.functions as F

# 1. Salt 컬럼 추가
salt_count = 10
skewed_df = skewed_df.withColumn(
    "salt", (F.rand() * salt_count).cast("int")
)
small_df = small_df.crossJoin(
    spark.range(salt_count).withColumnRenamed("id", "salt")
)

# 2. Salt 포함 조인
result = skewed_df.join(
    small_df,
    on=["join_key", "salt"]
)
```

**AQE Skew Join** (Spark 3.0+):
```python
# AQE가 자동으로 skew 파티션 분할
spark.conf.set("spark.sql.adaptive.skewJoin.enabled", "true")
```

**Repartition**:
```python
# 특정 키로 재분배
df = df.repartition(200, "balanced_key")
```

---

## 7. S3 최적화

### S3 Committer
```python
# EMRFS S3-optimized committer (EMR 기본)
spark.conf.set("spark.sql.sources.commitProtocolClass",
    "com.amazon.emr.committer.EmrOptimizedSparkSqlParquetOutputCommitter")

# 또는 S3A committer
spark.conf.set("spark.hadoop.fs.s3a.committer.name", "magic")
spark.conf.set("spark.hadoop.fs.s3a.committer.magic.enabled", "true")
```

### S3 I/O 설정
```python
spark.conf.set("spark.hadoop.fs.s3a.connection.maximum", "200")       # 최대 연결
spark.conf.set("spark.hadoop.fs.s3a.threads.max", "64")               # 최대 스레드
spark.conf.set("spark.hadoop.fs.s3a.multipart.size", "128MB")         # 멀티파트 크기
spark.conf.set("spark.hadoop.fs.s3a.fast.upload.buffer", "bytebuffer") # 업로드 버퍼
```

---

## 8. Anti-Pattern

| # | Anti-Pattern | 문제 | 올바른 방법 |
|---|-------------|------|------------|
| 1 | `collect()` 대량 데이터 | Driver OOM | `take(n)` 또는 집계 후 수집 |
| 2 | UDF 과다 사용 | Catalyst 최적화 불가 | 내장 함수 우선 |
| 3 | 작은 파일 다수 출력 | 읽기 성능 저하 | `coalesce()` / `repartition()` |
| 4 | `count()` 전체 데이터 | 불필요 전체 스캔 | `limit(1).count()` |
| 5 | 과다 셔플 | 네트워크/디스크 병목 | `broadcast()`, 파티셔닝 |
| 6 | Driver에서 대용량 처리 | Driver OOM | Executor에서 분산 처리 |
| 7 | 고정 파티션 수 200 | 데이터 크기 불일치 | AQE 또는 수동 조절 |
| 8 | 캐시 미반환 | 메모리 부족 | `unpersist()` 호출 |
