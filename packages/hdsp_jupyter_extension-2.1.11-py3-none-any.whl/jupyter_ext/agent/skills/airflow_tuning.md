---
name: airflow_tuning
description: Airflow 성능 튜닝 가이드. MWAA/Composer parallelism, concurrency, pool, scheduler 최적화, anti-pattern 진단.
---

# Airflow Performance Tuning Guide

MWAA 및 Cloud Composer 환경의 Airflow 성능 최적화 가이드입니다.

## 1. 핵심 성능 파라미터

### 파라미터 계층 구조

```mermaid
graph TD
    style P fill:#4CAF50,color:white
    style DC fill:#FF9800,color:white
    style WC fill:#2196F3,color:white
    style PS fill:#9C27B0,color:white
    P["parallelism<br/>전체 최대 동시 Task 수"] --> DC["max_active_tasks_per_dag<br/>(구 dag_concurrency)<br/>DAG당 최대 동시 Task"]
    P --> WC["worker_concurrency<br/>Worker당 최대 동시 Task"]
    P --> PS["pool slots<br/>Pool별 최대 동시 Task"]
    DC --> T["실제 실행 Task"]
    WC --> T
    PS --> T
```

### 파라미터 상세

| 파라미터 (airflow.cfg) | 섹션 | 기본값 | 설명 |
|------------------------|------|--------|------|
| `parallelism` | [core] | 32 | **전체** 동시 실행 Task 상한 |
| `max_active_tasks_per_dag` | [core] | 16 | **DAG당** 동시 실행 Task 상한 (Airflow 2.2+ 이름 변경, 구: `dag_concurrency`) |
| `max_active_runs_per_dag` | [core] | 16 | **DAG당** 동시 DAG Run 상한 |
| `worker_concurrency` | [celery] | 16 | **Worker당** 동시 Task (CeleryExecutor) |
| `default_pool_task_slot_count` | [core] | 128 | default pool 슬롯 수 |
| `min_file_process_interval` | [scheduler] | 30 | DAG 파일 재파싱 주기 (초) |
| `dag_dir_list_interval` | [scheduler] | 300 | DAGs 디렉토리 스캔 주기 (초) |
| `parsing_processes` | [scheduler] | 2 | DAG 파싱 프로세스 수 (vCPU × 2 권장) |
| `scheduler_heartbeat_sec` | [scheduler] | 5 | 스케줄러 heartbeat 주기 |

## 2. MWAA 환경클래스별 권장값

| 파라미터 | mw1.micro | mw1.small | mw1.medium | mw1.large | mw1.xlarge | mw1.2xlarge |
|----------|-----------|-----------|------------|-----------|------------|-------------|
| vCPU (Scheduler) | 0.5 | 1 | 2 | 4 | 8 | 16 |
| 메모리 (Scheduler) | 1 GB | 2 GB | 4 GB | 8 GB | 24 GB | 48 GB |
| `parallelism` | 16 | 32 | 64 | 128 | 256 | 512 |
| `max_active_tasks_per_dag` | 8 | 16 | 32 | 64 | 128 | 256 |
| `worker_concurrency` | 4 | 8 | 12 | 16 | 24 | 32 |
| `parsing_processes` | 1 | 2 | 4 | 8 | 16 | 32 |
| `min_file_process_interval` | 60 | 60 | 30 | 30 | 15 | 15 |
| Worker Auto Scaling | 1 | 1-5 | 1-10 | 1-25 | 1-25 | 1-25 |
| DAG 용량 (목안) | ~50 | ~250 | ~500 | ~1000 | ~2000 | ~4000 |

**환경클래스 선택 기준**:
- `mw1.micro`: 개발/테스트 (DAG 50개 미만)
- `mw1.small`: 소규모 운영 (동시 Task 5개 이내)
- `mw1.medium`: 중규모 운영 (동시 Task ~50개)
- `mw1.large`: 대규모 운영 (동시 Task ~100개)
- `mw1.xlarge/2xlarge`: 대용량 (1000+ DAG, 100+ 동시 Task)
- **업사이징 신호**: Scheduler CPU > 70% 지속, DB connection 고갈

**MWAA 설정 방법**: AWS Console → MWAA → Environment → Edit → Airflow configuration options
```
core.parallelism = 64
core.max_active_tasks_per_dag = 32
celery.worker_concurrency = 12
scheduler.min_file_process_interval = 30
```

## 3. Cloud Composer 환경별 권장값

### Composer 2 (권장)

| 프리셋 | Scheduler CPU/Mem | Worker CPU/Mem | 권장 parallelism | worker_concurrency |
|--------|-------------------|----------------|------------------|--------------------|
| Small | 0.5 / 1.875 GB | 0.5 / 1.875 GB | 32 | 6 |
| Medium | 2 / 7.5 GB | 1 / 4 GB | 64 | 12 |
| Large | 4 / 15 GB | 2 / 7.5 GB | 128 | 16 |
| Custom | 사용자 지정 | 사용자 지정 | vCPU × 16 | Worker Mem(GB) / 0.5 |

### Composer 1 vs 2 주요 차이

| 항목 | Composer 1 | Composer 2 |
|------|-----------|------------|
| Executor | CeleryExecutor | CeleryExecutor (기본) / KubernetesExecutor |
| Auto-scaling | GKE node 기반 | Worker pod 기반 (빠름) |
| 설정 변경 | 환경 재생성 필요할 수 있음 | 동적 변경 가능 |
| 비용 모델 | 고정 GKE 클러스터 | 사용량 기반 |

**Composer 설정 방법**:
```bash
# CLI
gcloud composer environments update ENV_NAME \
  --location LOCATION \
  --update-airflow-configs \
    core-parallelism=64,core-max_active_tasks_per_dag=32,celery-worker_concurrency=12

# Console: Composer → Environment → AIRFLOW OVERRIDES 탭
```

## 4. Pool 관리 전략

### Pool 설계 원칙
- **리소스 유형별 Pool 분리**: DB 연결, API 호출, 파일 I/O 등
- **외부 시스템 보호**: 동시 접속 제한이 있는 외부 API/DB에 Pool 적용
- **우선순위 활용**: `priority_weight`로 중요 Task 우선 실행

### Pool 설정 예시
```python
# DAG 내에서 Pool 지정
task = PythonOperator(
    task_id="api_call",
    python_callable=call_api,
    pool="external_api_pool",       # Pool 이름
    pool_slots=1,                    # 사용 슬롯 수 (기본: 1)
    priority_weight=10,              # 우선순위 (높을수록 먼저)
)
```

### Pool 모니터링
```python
# Airflow CLI로 Pool 상태 확인
# airflow pools list
# airflow pools set external_api_pool 5 "External API connection limit"
```

## 5. 스케줄러 튜닝

### 파싱 병목 진단

| 증상 | 원인 | 해결 |
|------|------|------|
| 새 DAG 인식 느림 | `dag_dir_list_interval` 높음 | 값 낮춤 (기본 300 → 60) |
| DAG 변경 반영 느림 | `min_file_process_interval` 높음 | 값 낮춤 (기본 30 → 15) |
| Scheduler CPU 100% | 파싱 부하 과다 | `parsing_processes` 조정, DAG 코드 최적화 |
| `DagFileProcessorTimeout` | DAG 파일 파싱 시간 초과 | top-level 코드 정리, import 최적화 |

### 스케줄러 Heartbeat
```
scheduler_heartbeat_sec = 5   # 기본값, 낮추면 반응성 ↑ / CPU ↑
num_runs = -1                  # 스케줄러 루프 횟수 (-1 = 무한)
```

### DAG Serialization (Airflow 2.0+)
- `store_serialized_dags = True` (기본)
- DAG을 DB에 직렬화 저장 → Webserver가 DAG 파일 직접 파싱 안 함
- `min_serialized_dag_update_interval = 30` (직렬화 갱신 주기)

## 6. Task-level 최적화

### 실행 제어 파라미터
```python
default_args = {
    "execution_timeout": timedelta(hours=2),  # Task 최대 실행 시간
    "retries": 3,                              # 재시도 횟수
    "retry_delay": timedelta(minutes=5),       # 재시도 간격
    "retry_exponential_backoff": True,          # 지수 백오프
    "max_retry_delay": timedelta(minutes=30),   # 최대 재시도 간격
}
```

### Trigger Rules
| Rule | 설명 | 사용 사례 |
|------|------|----------|
| `all_success` | 모든 upstream 성공 시 (기본) | 일반 파이프라인 |
| `all_done` | 모든 upstream 완료 시 (성공/실패 무관) | 클린업 Task |
| `one_success` | 하나라도 성공 시 | 브랜칭 후 합류 |
| `one_failed` | 하나라도 실패 시 | 알림/에러 핸들링 |
| `none_failed` | 실패 없음 (skip 허용) | 조건부 실행 후 합류 |

### ShortCircuitOperator
```python
from airflow.operators.python import ShortCircuitOperator

check = ShortCircuitOperator(
    task_id="check_condition",
    python_callable=lambda: should_run(),  # False 반환 시 downstream skip
)
check >> downstream_tasks
```

## 7. Mermaid DAG 시각화 템플릿

### 기본 Task Dependency 시각화
```mermaid
graph LR
    style extract fill:#4CAF50,color:white
    style transform fill:#2196F3,color:white
    style load fill:#4CAF50,color:white
    style notify fill:#9E9E9E,color:white

    extract["extract<br/>⏱ 5min"] --> transform["transform<br/>⏱ 15min"]
    transform --> load["load<br/>⏱ 3min"]
    load --> notify["notify<br/>⏱ 1min"]
```

### 병목 분석 시각화
```mermaid
graph TD
    style slow_task fill:#F44336,color:white
    style normal fill:#4CAF50,color:white
    style warning fill:#FF9800,color:white

    A["Task A<br/>✅ 2min"] --> B["Task B<br/>⚠️ 10min<br/>병목"]
    A --> C["Task C<br/>✅ 3min"]
    B --> D["Task D<br/>⏳ 대기중"]
    C --> D
```

**컬러 코딩 규칙**:
- `#4CAF50` (green): 정상 / 빠른 Task
- `#FF9800` (orange): 경고 / 느린 Task
- `#F44336` (red): 에러 / 병목 Task
- `#2196F3` (blue): 정보 / 진행중
- `#9E9E9E` (gray): 대기 / Skip

### 병렬 구조 시각화
```mermaid
graph LR
    start["start"] --> A["branch_a"]
    start --> B["branch_b"]
    start --> C["branch_c"]
    A --> join["join"]
    B --> join
    C --> join
    join --> end_task["end"]
```

## 8. Anti-Pattern 목록

| Anti-Pattern | 심각도 | 문제 | 해결 |
|--------------|--------|------|------|
| Top-level `Variable.get()` | 🔴 Critical | 매 파싱마다 메타DB 쿼리 | `template_fields` 또는 함수 내 호출 |
| Top-level DB 쿼리 | 🔴 Critical | 파싱 시간 ↑, DB 부하 ↑ | 함수 안으로 이동 |
| Heavy import at top | 🟡 Warning | 파싱 시간 ↑ | 지연 import (`importlib`) |
| 과도한 Task 수 (100+/DAG) | 🟡 Warning | 스케줄러 부하, UI 느려짐 | DAG 분리 또는 Dynamic Task Mapping |
| 과도한 XCom (>48KB) | 🟡 Warning | 메타DB 부하 | 외부 스토리지 (S3/GCS) 사용 |
| `catchup=True` + 긴 기간 | 🟡 Warning | 대량 DAG Run 생성 | `catchup=False` 또는 제한된 start_date |
| 모든 Task `default_pool` | 🟢 Info | 리소스 격리 안 됨 | 용도별 Pool 분리 |
| `execution_timeout` 미설정 | 🟢 Info | 무한 실행 가능 | 적절한 timeout 설정 |
| `depends_on_past=True` 남용 | 🟡 Warning | 연쇄 지연/실패 | 진짜 필요한 경우만 사용 |
| DAG 파일명에 공백/특수문자 | 🔴 Critical | 파싱 실패 가능 | snake_case 파일명 |

## 9. 성능 모니터링 쿼리

### MWAA CloudWatch Metrics
```
# 핵심 메트릭 (CloudWatch → MWAA namespace)
- scheduler_heartbeat: 스케줄러 정상 동작 확인
- dag_processing.total_parse_time: DAG 파싱 시간
- pool.open_slots.default_pool: 사용 가능 Pool 슬롯
- executor.queued_tasks: 대기 중 Task 수
- executor.running_tasks: 실행 중 Task 수
```

### Composer Monitoring
```
# Cloud Monitoring → Composer 메트릭
- composer.googleapis.com/environment/dagbag_size: DAG 수
- composer.googleapis.com/environment/dag_processing/total_parse_time: 파싱 시간
- composer.googleapis.com/workflow/task/run_count: Task 실행 수
- composer.googleapis.com/workflow/task/run_duration: Task 실행 시간
```

## 10. DB Connection Pool 튜닝

### 핵심 파라미터
```ini
[database]
sql_alchemy_pool_size = 5          # Pool 기본 크기 (기본값)
sql_alchemy_max_overflow = 10      # Pool 초과 허용 연결 수
sql_alchemy_pool_recycle = 1800    # 연결 재활용 주기 (초)
sql_alchemy_pool_pre_ping = True   # 사용 전 연결 유효성 검사
```

**총 DB 연결 수 = (pool_size + max_overflow) × 프로세스 수**
- 프로세스: Scheduler, Workers, Webserver 각각 독립 Pool 보유
- 프로덕션 권장: `pool_size=10, max_overflow=20`
- **PgBouncer 사용 권장**: PostgreSQL 앞단에 PgBouncer를 두면 DB 서버 부하 대폭 감소

## 11. 프로덕션 시작 설정 (참고용)

```ini
# airflow.cfg (또는 MWAA/Composer 환경 오버라이드)
[core]
parallelism = 64
max_active_tasks_per_dag = 32
max_active_runs_per_dag = 4
dagbag_import_timeout = 120
dag_file_processor_timeout = 180

[scheduler]
min_file_process_interval = 30
dag_dir_list_interval = 120
parsing_processes = 4
scheduler_zombie_task_threshold = 300

[celery]
worker_concurrency = 8

[database]
sql_alchemy_pool_size = 10
sql_alchemy_max_overflow = 20
sql_alchemy_pool_recycle = 1800
sql_alchemy_pool_pre_ping = True
```
**모든 값은 모니터링 데이터 기반으로 조정 필요. 위는 시작점일 뿐.**
