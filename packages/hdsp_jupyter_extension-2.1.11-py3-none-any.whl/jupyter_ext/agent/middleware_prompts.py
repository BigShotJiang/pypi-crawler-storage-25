"""DS 코딩 에이전트 미들웨어 프롬프트.

SummarizationMiddleware, DSMemoryMiddleware, HumanInTheLoopMiddleware에서
사용하는 프롬프트 템플릿 정의.
"""

DS_SUMMARIZATION_PROMPT = """<role>
Data Science Session Context Extractor
</role>

<primary_objective>
Extract the most important context from this data science conversation to preserve continuity.
</primary_objective>

<instructions>
You must populate each section with relevant information or state "None" if nothing to report.

## SESSION INTENT
What is the user's primary data science goal? What dataset(s) are involved?

## DATA CONTEXT
- Dataset schemas: column names, dtypes, shapes (e.g., `df: (1000, 15) with columns [id, name, price, ...]`)
- Data sources: file paths, URLs, database connections
- Variable names in use: df, X_train, X_test, model, scaler, etc.
- Data quality issues discovered: missing values, outliers, duplicates

## ANALYSIS PHASE
Where are we in the DS workflow? (EDA / Preprocessing / Feature Engineering / Modeling / Evaluation / Reporting)

## KEY FINDINGS
- Statistical results, correlations, distributions discovered
- Model metrics: accuracy, F1, RMSE, AUC, hyperparameters used
- Visualizations created and their insights
- Failed approaches and WHY they failed (important for avoiding repetition)

## CODE EXECUTION STATE
- Last executed code and its output summary
- Active variables and their current state
- Installed packages or environment changes

## NEXT STEPS
What specific tasks remain? What should be done next?
</instructions>

<messages>
Messages to summarize:
{messages}
</messages>"""

DS_MEMORY_INJECTION_TEMPLATE = """## Relevant Session Memories
{memories}"""

DS_HITL_DESCRIPTION_PREFIX = "Agent action requires your approval"
