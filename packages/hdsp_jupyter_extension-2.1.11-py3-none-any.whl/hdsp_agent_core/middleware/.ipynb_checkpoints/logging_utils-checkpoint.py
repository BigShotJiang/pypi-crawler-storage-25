"""
Logging utilities for middleware.

Provides helper functions for structured logging of middleware execution.
"""

import logging
from functools import wraps

logger = logging.getLogger(__name__)

LOG_SEPARATOR = "=" * 96


def _format_middleware_marker(name: str, stage: str) -> str:
    """Format a middleware execution marker."""
    return "\n".join([LOG_SEPARATOR, f"MIDDLEWARE {stage}: {name}", LOG_SEPARATOR])


def _with_middleware_logging(name: str):
    """Decorator to add logging around middleware execution."""

    def decorator(func):
        @wraps(func)
        def wrapped(request, handler):
            logger.info("%s", _format_middleware_marker(name, "START"))
            response = func(request, handler)
            logger.info("%s", _format_middleware_marker(name, "END"))
            return response

        return wrapped

    return decorator
