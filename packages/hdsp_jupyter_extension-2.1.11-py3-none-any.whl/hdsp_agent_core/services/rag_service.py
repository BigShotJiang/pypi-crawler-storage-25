"""
RAG 서비스 구현

IRAGService의 Embedded 구현.
"""

import logging
from typing import Any, Dict, List, Optional

from hdsp_agent_core.interfaces import IRAGService
from hdsp_agent_core.models.rag import SearchRequest, SearchResponse

logger = logging.getLogger(__name__)


class EmbeddedRAGService(IRAGService):
    """
    RAG 서비스 구현.

    인프로세스에서 직접 RAGManager를 사용합니다.
    """

    def __init__(self):
        """Embedded RAG 서비스 초기화"""
        self._rag_manager = None
        self._initialized = False
        logger.info("EmbeddedRAGService 생성됨 (아직 초기화되지 않음)")

    async def initialize(self) -> None:
        """RAG 관리자 초기화."""
        if self._initialized:
            return
        try:
            from hdsp_agent_core.services.rag_manager import get_rag_manager

            self._rag_manager = get_rag_manager()
            success = await self._rag_manager.initialize()
            self._initialized = success
            if success:
                logger.info("EmbeddedRAGService: RAG 초기화 완료")
            else:
                logger.info("EmbeddedRAGService: RAG 비활성화 (설정)")
        except Exception as e:
            logger.warning(f"EmbeddedRAGService: RAG 초기화 실패: {e}")
            self._initialized = False

    async def shutdown(self) -> None:
        """RAG 서비스 종료"""
        self._rag_manager = None
        self._initialized = False
        logger.info("EmbeddedRAGService 종료됨")

    def is_ready(self) -> bool:
        """RAG 서비스 준비 상태 확인"""
        if not self._initialized or not self._rag_manager:
            return False
        return self._rag_manager.is_ready

    async def search(self, request: SearchRequest) -> SearchResponse:
        """지식 베이스 검색"""
        logger.info(f"[Embedded] RAG 검색: {request.query[:100]}...")

        if not self.is_ready():
            return SearchResponse(
                results=[],
                total=0,
                query=request.query,
            )

        results = await self._rag_manager.search(
            query=request.query,
            collection=request.collection,
            limit=request.limit,
            score_threshold=request.scoreThreshold,
        )

        return SearchResponse(
            results=results.get("results", []),
            total=results.get("total", 0),
            query=request.query,
        )

    async def get_context_for_query(
        self,
        query: str,
        detected_libraries: Optional[List[str]] = None,
        max_results: int = 5,
    ) -> Optional[str]:
        """쿼리에 대한 포맷된 컨텍스트 가져오기"""
        logger.info(f"[Embedded] 쿼리 컨텍스트 조회: {query[:100]}...")

        if not self.is_ready():
            return None

        try:
            return await self._rag_manager.get_context_for_query(
                query=query,
                detected_libraries=detected_libraries,
                max_results=max_results,
            )
        except Exception as e:
            logger.error(f"RAG 컨텍스트 조회 실패: {e}")
            return None

    async def get_index_status(self) -> Dict[str, Any]:
        """현재 인덱스 상태 가져오기"""
        logger.info("[Embedded] 인덱스 상태 조회")

        if not self.is_ready():
            return {
                "ready": False,
                "documentCount": 0,
                "collections": [],
                "message": "RAG 서비스가 초기화되지 않음",
            }

        try:
            return await self._rag_manager.get_index_status()
        except Exception as e:
            logger.error(f"인덱스 상태 조회 실패: {e}")
            return {
                "ready": False,
                "documentCount": 0,
                "collections": [],
                "message": str(e),
            }

    async def trigger_reindex(self, force: bool = False) -> Dict[str, Any]:
        """재인덱싱 작업 트리거"""
        logger.info(f"[Embedded] 재인덱싱 트리거 (force={force})")

        if not self.is_ready():
            return {
                "success": False,
                "message": "RAG 서비스가 초기화되지 않음",
            }

        try:
            return await self._rag_manager.trigger_reindex(force=force)
        except Exception as e:
            logger.error(f"재인덱싱 트리거 실패: {e}")
            return {
                "success": False,
                "message": str(e),
            }
