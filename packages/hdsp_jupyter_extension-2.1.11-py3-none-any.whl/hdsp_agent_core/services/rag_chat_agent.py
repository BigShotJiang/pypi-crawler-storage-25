"""RAG Chat Agent — LangChain create_agent 기반 ReAct 에이전트.

chat mode에서 RAG 검색이 필요할 때 LLM이 자동으로 rag_search tool을 호출.
최대 2회 tool call, 스트리밍 지원.
"""

from __future__ import annotations

import json
import logging
import re
from datetime import datetime
from pathlib import Path
from typing import Any, AsyncGenerator, Dict, List, Optional

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Raw LLM 로깅 유틸리티
# ---------------------------------------------------------------------------

_LOG_DIR = Path("agent_logs")


def _get_raw_log_path() -> Path:
    """타임스탬프 기반 로그 파일 경로 반환."""
    _LOG_DIR.mkdir(parents=True, exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    return _LOG_DIR / f"raw_llm_{ts}.json"


def _is_raw_logging_enabled() -> bool:
    """config에서 rawLlmLogging 설정을 매번 확인 (핫리로드)."""
    try:
        from hdsp_agent_core.managers.config_manager import get_config_manager

        return bool(get_config_manager().get_config().get("rawLlmLogging", False))
    except Exception:
        return False


def _append_log(log_path: Path, entry: Dict[str, Any]) -> None:
    """JSON 배열에 엔트리 추가 (보기 좋은 포맷)."""
    try:
        entries: list = []
        if log_path.exists() and log_path.stat().st_size > 0:
            with open(log_path, "r", encoding="utf-8") as f:
                entries = json.load(f)
        entries.append(entry)
        with open(log_path, "w", encoding="utf-8") as f:
            json.dump(entries, f, ensure_ascii=False, default=str, indent=2)
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Harmony 토큰 필터 래퍼
# ---------------------------------------------------------------------------

# GPT-OSS harmony 특수 토큰 패턴
_HARMONY_TOKEN_RE = re.compile(
    r"<\|(?:start|end|message|channel|call|system|user|assistant|"
    r"analysis|commentary|final|functions?)\|>"
)
_HARMONY_BLOCK_RE = re.compile(r"<\|message\|>.*?<\|end\|>", re.DOTALL)


def _create_developer_role_middleware_class():
    """SystemMessage → developer role 변환 미들웨어.

    gpt-oss는 system role을 메타데이터로 취급하고,
    developer role을 최우선 지시사항으로 따른다.
    """
    from langchain.agents.middleware import AgentMiddleware

    class _DeveloperRole(AgentMiddleware):
        def before_model(self, state, runtime=None):  # noqa: ARG002
            from langchain_core.messages import ChatMessage

            messages = state.get("messages", [])
            if not messages:
                return None

            converted = []
            changed = False
            for msg in messages:
                if msg.type == "system":
                    converted.append(ChatMessage(role="developer", content=msg.content))
                    changed = True
                else:
                    converted.append(msg)

            return {"messages": converted} if changed else None

        async def abefore_model(self, state, runtime=None):  # noqa: ARG002
            return self.before_model(state, runtime)

    return _DeveloperRole


def _create_strip_content_on_toolcall_middleware_class():
    """tool_calls가 있는 AIMessage에서 content를 제거하는 미들웨어.

    LLM이 content + tool_calls를 동시에 보내면 content는 할루시네이션.
    UI에서만 폐기하면 context에 누적되어 토큰 초과 원인이 됨.
    after_model에서 AIMessage.content를 비워 context 절약.
    """
    from langchain.agents.middleware import AgentMiddleware

    class _StripContentOnToolCall(AgentMiddleware):
        def after_model(self, state, runtime=None):  # noqa: ARG002
            from langchain_core.messages import AIMessage

            messages = state.get("messages", [])
            if not messages:
                return None

            last = messages[-1]
            if (
                not isinstance(last, AIMessage)
                or not last.tool_calls
                or not last.content
            ):
                return None

            # tool_calls가 있으면 content 제거
            stripped = last.model_copy(update={"content": ""})
            new_messages = list(messages[:-1]) + [stripped]
            logger.info(
                "[RAG] Stripped %d chars content from AIMessage with tool_calls",
                len(last.content),
            )
            return {"messages": new_messages}

        async def aafter_model(self, state, runtime=None):  # noqa: ARG002
            return self.after_model(state, runtime)

    return _StripContentOnToolCall


# tiktoken 인코더 싱글톤 캐시
_tiktoken_enc = None
_tiktoken_available = None  # None=미확인, True/False


def _get_tiktoken_encoder():
    """tiktoken 인코더를 한 번만 초기화. 패키지 내장 캐시를 사용하여 오프라인 지원."""
    global _tiktoken_enc, _tiktoken_available  # noqa: PLW0603
    if _tiktoken_enc is not None:
        return _tiktoken_enc

    import os

    import tiktoken

    # 패키지 내장 캐시 디렉토리를 TIKTOKEN_CACHE_DIR로 설정
    if "TIKTOKEN_CACHE_DIR" not in os.environ:
        cache_dir = str(Path(__file__).parent.parent / "data" / "tiktoken_cache")
        if Path(cache_dir).is_dir():
            os.environ["TIKTOKEN_CACHE_DIR"] = cache_dir

    _tiktoken_enc = tiktoken.get_encoding("cl100k_base")
    _tiktoken_available = True
    return _tiktoken_enc


CHUNK_SIZE = 10000  # 분할 인코딩 단위 (큰 텍스트 O(n²) 방지)


def _count_tokens_text(enc, text: str) -> int:
    """큰 텍스트를 청크로 분할 후 batch 인코딩하여 토큰 수 반환."""
    if len(text) <= CHUNK_SIZE:
        return len(enc.encode(text))
    chunks = [text[i : i + CHUNK_SIZE] for i in range(0, len(text), CHUNK_SIZE)]
    results = enc.encode_ordinary_batch(chunks)
    return sum(len(r) for r in results)


def _estimate_tokens(messages) -> int:
    """tiktoken으로 메시지 토큰 수 추정. 실패 시 한국어 보수적 추정(2자/토큰) 폴백."""
    global _tiktoken_available  # noqa: PLW0603

    if _tiktoken_available is False:
        return _estimate_tokens_fallback(messages)

    try:
        enc = _get_tiktoken_encoder()
        total = 0
        for msg in messages:
            content = msg.content if hasattr(msg, "content") else str(msg)
            total += _count_tokens_text(enc, content) + 4
            if hasattr(msg, "tool_calls") and msg.tool_calls:
                tc_str = str(msg.tool_calls)
                total += _count_tokens_text(enc, tc_str)
        print(
            f"[RAG] tiktoken estimate: {total} tokens ({len(messages)} messages)",
            flush=True,
        )
        return total
    except Exception as e:
        _tiktoken_available = False
        print(f"[RAG] tiktoken unavailable, using fallback: {e}", flush=True)
        return _estimate_tokens_fallback(messages)


def _estimate_tokens_fallback(messages) -> int:
    """tiktoken 없을 때 폴백. 한국어 보수적 추정 (2자/토큰)."""
    total = 0
    for msg in messages:
        content = msg.content if hasattr(msg, "content") else str(msg)
        total += len(content) // 2 + 4
        if hasattr(msg, "tool_calls") and msg.tool_calls:
            total += len(str(msg.tool_calls)) // 2
    print(
        f"[RAG] token estimate (fallback): {total} tokens ({len(messages)} messages)",
        flush=True,
    )
    return total


def _create_context_compression_middleware_class(model_context_limit: int = 131072):
    """LLM 호출 전 토큰 사전 체크 + 점진적 ToolMessage 축소 미들웨어.

    1. score 낮은 검색 결과부터 점진적 삭제
    2. 마지막 1개 남으면 columns 제거 + content 2000자 컷
    3. 87.5% 초과 시 더 공격적 축약
    """
    from langchain.agents.middleware import AgentMiddleware

    # 시스템 프롬프트 + tools 스키마 오버헤드 감안 (메시지만 세므로 보수적)
    SOFT_LIMIT = int(model_context_limit * 0.5)
    HARD_LIMIT = int(model_context_limit * 0.65)

    class _ContextCompression(AgentMiddleware):
        def before_model(self, state, runtime=None):  # noqa: ARG002
            import json as _json

            from langchain_core.messages import ToolMessage

            messages = state.get("messages", [])
            if not messages:
                return None

            estimated = _estimate_tokens(messages)
            if estimated <= SOFT_LIMIT:
                return None

            # 메시지별 토큰 상세 로깅
            for i, msg in enumerate(messages):
                content = msg.content if hasattr(msg, "content") else ""
                msg_tokens = len(content) // 2
                logger.info(
                    "[RAG] Context msg[%d] type=%s tokens≈%d chars=%d",
                    i,
                    type(msg).__name__,
                    msg_tokens,
                    len(content),
                )

            logger.info(
                "[RAG] Context compression: estimated=%d tokens, soft=%d, hard=%d",
                estimated,
                SOFT_LIMIT,
                HARD_LIMIT,
            )

            # ToolMessage 인덱스 수집
            new_messages = list(messages)
            changed = False

            for msg_idx in range(len(new_messages) - 1, -1, -1):
                msg = new_messages[msg_idx]
                if not isinstance(msg, ToolMessage) or not msg.content:
                    continue

                # ToolMessage의 content를 JSON 파싱하여 결과 리스트 축소
                try:
                    parsed = _json.loads(msg.content)
                except (ValueError, TypeError):
                    continue

                if not isinstance(parsed, dict):
                    continue

                # 결과 리스트 키 찾기
                result_keys = [
                    k
                    for k in ("테이블 검색 결과", "가이드 검색 결과", "코드 검색 결과")
                    if k in parsed
                    and isinstance(parsed[k], list)
                    and len(parsed[k]) > 0
                ]

                if not result_keys:
                    continue

                # Step 1: (결과 삭제 비활성화 — 컬럼 축소로 충분)

                # Step 2: 모든 결과의 컬럼을 동시에 50%씩 삭감 + content 축약
                # 기존 방식: 결과 하나씩 컬럼 0까지 → 다음 결과 (비효율적)
                # 개선: 모든 결과 컬럼을 한 라운드에 50%씩 → estimate → 반복
                estimated = _estimate_tokens(new_messages)
                if estimated > SOFT_LIMIT:
                    # 모든 결과의 payload 수집
                    all_payloads = []
                    for key in result_keys:
                        for r in parsed.get(key, []):
                            p = r.get("payload", r)
                            if isinstance(p, dict):
                                all_payloads.append(p)

                    # 라운드별: 모든 payload의 컬럼을 동시에 50% 삭감
                    max_rounds = 12
                    for round_i in range(max_rounds):
                        any_cut = False
                        for p in all_payloads:
                            cols = p.get("columns")
                            if not cols or not isinstance(cols, list):
                                continue
                            original = len(cols)
                            keep = max(original // 2, 0)
                            if keep == 0:
                                del p["columns"]
                                p["_notice"] = (
                                    "[토큰 제한으로 컬럼 상세 정보 전부 생략]"
                                )
                            else:
                                p["columns"] = cols[:keep]
                                p["_notice"] = (
                                    f"[토큰 제한으로 컬럼 {original} → {keep}개]"
                                )
                            any_cut = True

                        if not any_cut:
                            break

                        changed = True
                        new_content = _json.dumps(
                            parsed, ensure_ascii=False, default=str
                        )
                        new_messages[msg_idx] = ToolMessage(
                            content=new_content,
                            tool_call_id=msg.tool_call_id,
                            name=getattr(msg, "name", None),
                        )
                        estimated = _estimate_tokens(new_messages)
                        print(
                            f"[RAG] Compression round {round_i + 1}: "
                            f"{estimated} tokens",
                            flush=True,
                        )
                        if estimated <= SOFT_LIMIT:
                            break

                    # 컬럼 전부 제거 후에도 초과 → content 50%씩 축약
                    if estimated > SOFT_LIMIT:
                        for p in all_payloads:
                            ct = p.get("content", "")
                            if not ct or not isinstance(ct, str):
                                continue
                            original_len = len(ct)
                            while (
                                estimated > SOFT_LIMIT
                                and len(p.get("content", "")) > 200
                            ):
                                cur = len(p["content"])
                                keep = max(cur // 2, 200)
                                p["content"] = p["content"][:keep]
                                p["_content_notice"] = (
                                    f"[토큰 제한으로 원문 {original_len} → {keep}자]"
                                )
                                changed = True
                                new_content = _json.dumps(
                                    parsed, ensure_ascii=False, default=str
                                )
                                new_messages[msg_idx] = ToolMessage(
                                    content=new_content,
                                    tool_call_id=msg.tool_call_id,
                                    name=getattr(msg, "name", None),
                                )
                                estimated = _estimate_tokens(new_messages)

                # Step 3: 87.5% 초과 시 더 공격적 축약
                estimated = _estimate_tokens(new_messages)
                if estimated > HARD_LIMIT:
                    for key in result_keys:
                        results = parsed.get(key, [])
                        for r in results:
                            payload = r.get("payload", r)
                            if isinstance(payload, dict) and "content" in payload:
                                if len(payload["content"]) > 500:
                                    payload["content"] = payload["content"][:500]
                                    payload["_content_notice"] = (
                                        "[토큰 제한으로 원문이 500자로 축약되었습니다]"
                                    )
                                    changed = True

                    if changed:
                        new_content = _json.dumps(
                            parsed, ensure_ascii=False, default=str
                        )
                        new_messages[msg_idx] = ToolMessage(
                            content=new_content,
                            tool_call_id=msg.tool_call_id,
                            name=getattr(msg, "name", None),
                        )

                # 하나의 ToolMessage 처리 후 토큰 재확인
                estimated = _estimate_tokens(new_messages)
                if estimated <= SOFT_LIMIT:
                    break

            if changed:
                from langgraph.graph.message import REMOVE_ALL_MESSAGES
                from langchain_core.messages import RemoveMessage

                final_tokens = _estimate_tokens(new_messages)
                print(
                    f"[RAG] Context compressed: → {final_tokens} tokens",
                    flush=True,
                )
                return {
                    "messages": [
                        RemoveMessage(id=REMOVE_ALL_MESSAGES),
                        *new_messages,
                    ]
                }

            return None

        async def abefore_model(self, state, runtime=None):  # noqa: ARG002
            return self.before_model(state, runtime)

    return _ContextCompression


def _create_summary_to_system_middleware_class():
    """SummarizationMiddleware가 생성한 요약 HumanMessage를 SystemMessage로 변환.

    SummarizationMiddleware는 요약을 HumanMessage(lc_source=summarization)로 넣는데,
    LLM이 이를 사용자 메시지로 착각해 요약을 그대로 답변으로 출력하는 문제 방지.
    SystemMessage로 변환하여 "이전 세션 요약"임을 명시.
    """
    from langchain.agents.middleware import AgentMiddleware

    class _SummaryToSystem(AgentMiddleware):
        def before_model(self, state, runtime=None):  # noqa: ARG002
            from langchain_core.messages import HumanMessage, SystemMessage

            messages = state.get("messages", [])
            if not messages:
                return None

            new_messages = []
            changed = False
            for msg in messages:
                if (
                    isinstance(msg, HumanMessage)
                    and msg.additional_kwargs.get("lc_source") == "summarization"
                ):
                    # 요약 HumanMessage → SystemMessage로 변환
                    summary_content = msg.content
                    # "Here is a summary..." 접두사 제거
                    if ":\n\n" in summary_content:
                        summary_content = summary_content.split(":\n\n", 1)[1]
                    new_messages.append(
                        SystemMessage(
                            content=(
                                "[이전 세션 요약]\n"
                                "다음은 이전 대화의 요약입니다. 참고만 하고, "
                                "사용자의 현재 질문에 답변하세요.\n\n"
                                f"{summary_content}"
                            )
                        )
                    )
                    changed = True
                    logger.info(
                        "[RAG] Converted summary HumanMessage → SystemMessage (%d chars)",
                        len(summary_content),
                    )
                else:
                    new_messages.append(msg)

            return {"messages": new_messages} if changed else None

        async def abefore_model(self, state, runtime=None):  # noqa: ARG002
            return self.before_model(state, runtime)

    return _SummaryToSystem


def _strip_harmony_tokens(text: str) -> str:
    """응답 텍스트에서 harmony 특수 토큰/블록을 제거."""
    if not text:
        return text
    # 전체 harmony 블록 제거 (tool call이 content에 섞인 경우)
    cleaned = _HARMONY_BLOCK_RE.sub("", text)
    # 잔여 개별 토큰 제거
    cleaned = _HARMONY_TOKEN_RE.sub("", cleaned)
    return cleaned.strip()


# 기존 chat 시스템 프롬프트 + RAG 가이드
_RAG_SYSTEM_PROMPT_ADDITION = """

## RAG 검색 도구

rag_search로 사내 데이터를 검색할 수 있습니다. 반드시 먼저 아래 컬렉션에서 정보를 획득한 후 응답을 생성하세요.
**절대로 rag_search 결과(현재 또는 이전 대화의 검색 결과) 없이 테이블명이나 컬럼명을 만들어내지 마세요.** 검색 결과에 없는 테이블/컬럼을 추측하거나 지어내면 사용자에게 심각한 오류를 유발합니다.  

### 컬렉션
- **enterprise_tables**: 전사 테이블 메타데이터. 사용자가 '전사', 'Meta#', '메타샵' 단어를 명시할 때만 사용하세요. (테이블/컬럼/스키마)
- **bdp_tables**: BDP 테이블 메타데이터. 일반적인 테이블을 검색할 때 사용하세요. (쿼리 생성/검토 시 참조)
- **guide_docs**: BDP/bdpengine 가이드 (S3 접근 방법, Athena 쿼리 방법, Spark 활용 방법 등)
- **ds_guide_docs**: 데이터사이언스 가이드 (Pandas, PySpark 등)
- **codebase**: 사용자 코드베이스 (함수/클래스/메서드 검색)

### 도구 호출 규칙
1. **`load_skills`**: 필요한 스킬을 쉼표로 모두 포함하여 **1회 호출**. 이전 대화에서 이미 로드한 스킬은 재호출 금지.
   - **athena_sql**: Athena SQL 쿼리 작성/검토 시 (문법, 함수, Iceberg DML, 튜닝)
2. **`rag_search`**: queries 배열에 **최대 3개** 쿼리를 담아 **1회만 호출**. 절대 여러 번 병렬 호출하지 마세요.
   - **match_text**: 테이블 컬렉션(enterprise_tables, bdp_tables)에서만 사용. 정확한 테이블명을 알 때만 추가. match_text를 다양하게 변형하여 여러 쿼리를 만들지 마세요.
   - 예: `[{"query": "카드매출 스키마", "collection": "bdp_tables", "match_text": ["card_pchs"]}]`
3. **`get_table_columns`**: 테이블의 전체 컬럼 목록을 조회합니다. rag_search 결과에서 컬럼이 축약된 경우 사용하세요.
   - `table_name`: 테이블 이름, `collection`: enterprise_tables 또는 bdp_tables, `start_index`: 페이징 시작 인덱스
   - 100개씩 반환하며, `has_more`가 true이면 `next_index`로 다음 페이지를 요청하세요.
   - 예: `get_table_columns(table_name="card_pchs", collection="bdp_tables")`
   - 이어서 조회: `get_table_columns(table_name="card_pchs", collection="bdp_tables", start_index=100)`
4. 결과가 0건일 때만 쿼리를 변경하여 1회 재시도를 허용합니다.
5. 단순한 Python 문법, 수학 계산 등 RAG와 무관한 질문은 도구 없이 답변하세요.

### Python 코드 생성 시
- 반드시 guide_docs에서 관련 가이드를 먼저 검색한 후 코드를 작성하세요.
- 검색 없이 함수명이나 사용법을 추측하지 마세요.

### 검색 결과 사용 시 주의사항
- 테이블명, 컬럼명, 스키마명, 시스템명, 함수명 등 고유명사는 **RAG 검색 결과에 있는 값을 그대로** 사용하세요. 임의로 번역하거나 영문/한글로 치환하지 마세요.
- 검색 결과에 "[토큰 제한으로 컬럼 정보가 축약되었습니다]" 안내가 있으면, 사용자에게 "전체 컬럼 리스트(스키마)는 BDP Portal의 카탈로그를 참고하세요"라고 안내하세요.
- 가이드 검색 결과에 `source_url`이 있으면, 답변 마지막에 "출처: {source_url}" 형태로 Confluence 링크를 명시하세요.

### 도구 호출 시 주의사항 (매우 중요)
- 도구 호출(tool call)이 필요하면, content에는 반드시 "검색 중입니다"처럼 **한 줄 상태 메시지만** 넣으세요. 긴 설명이나 답변을 넣지 마세요.
"""


def _get_match_text_fields_info() -> str:
    """Qdrant에서 enterprise_tables/bdp_tables의 text index 필드를 조회."""
    try:
        from hdsp_agent_core.services.rag_collections import (
            COLLECTION_BDP,
            COLLECTION_ENTERPRISE,
            get_manager,
        )

        mgr = get_manager()
        if mgr is None:
            return ""

        client = mgr._client
        existing = {c.name for c in client.get_collections().collections}
        lines: list = []

        for col_name in [COLLECTION_ENTERPRISE, COLLECTION_BDP]:
            if col_name not in existing:
                continue
            try:
                col_info = client.get_collection(col_name)
                text_fields = [
                    fname
                    for fname, schema in (col_info.payload_schema or {}).items()
                    if "text" in str(getattr(schema, "params", "")).lower()
                    or getattr(schema, "data_type", "") == "text"
                ]
                if text_fields:
                    lines.append(
                        f"- **{col_name}**: {', '.join(f'`{f}`' for f in sorted(text_fields))}"
                    )
            except Exception:
                continue

        if not lines:
            return ""

        return "### match_text 검색 가능 컬렉션 및 인덱스 필드\n" + "\n".join(lines)
    except Exception:
        return ""


def _format_tool_status(queries_str: str) -> str:
    """tool_start 이벤트에서 사용자 친화적 상태 메시지 생성."""
    try:
        q_list = json.loads(queries_str) if queries_str else []
    except Exception:
        return "📚 지식 베이스 검색 중..."

    # codebase 컬렉션이 포함되어 있으면 코드 베이스 검색 표시
    has_codebase = any(
        isinstance(q, dict) and q.get("collection") == "codebase" for q in q_list
    )
    if has_codebase:
        return "📚 코드 베이스 검색 중..."

    # 쿼리 텍스트 추출 (중복 제거, 순서 유지)
    seen: set = set()
    queries: list = []
    for q in q_list:
        if not isinstance(q, dict):
            continue
        txt = q.get("query", "").strip()
        if txt and txt.lower() not in seen:
            seen.add(txt.lower())
            queries.append(txt)
    if queries:
        q_text = ", ".join(f'"{q}"' for q in queries[:3])
        return f"📚 지식 베이스 검색 중... {q_text}"

    return "📚 지식 베이스 검색 중..."


class RAGChatAgent:
    """LangChain create_agent 기반 RAG chat agent.

    chat mode에서 RAG가 가용할 때 LLMService 대신 사용.
    rag_search 도구 1개로 ReAct loop (최대 2회 tool call).
    """

    def __init__(self, llm_config: Dict[str, Any], checkpointer=None):
        self._llm_config = llm_config
        self._checkpointer = checkpointer
        self._agent = None

    async def _cleanup_state_after_fallback(
        self,
        config: Dict[str, Any],
        fallback_response: str,
        compressed_messages: Optional[List[Any]] = None,
    ):
        """fallback 성공 후 그래프 state를 compressed context + fallback 응답으로 교체.

        Args:
            fallback_response: fallback LLM이 생성한 응답 텍스트
            compressed_messages: fallback에서 사용한 compressed state messages
        """
        try:
            from langchain_core.messages import AIMessage

            if compressed_messages:
                messages = list(compressed_messages)
            else:
                state = await self._agent.aget_state(config)
                messages = list(state.values.get("messages", []))

            # 빈 AIMessage(실패한 응답)를 fallback 응답으로 교체
            replaced = False
            for i in range(len(messages) - 1, -1, -1):
                if isinstance(messages[i], AIMessage):
                    if not messages[i].content and not messages[i].tool_calls:
                        messages[i] = AIMessage(content=fallback_response)
                        replaced = True
                    break

            if not replaced:
                messages.append(AIMessage(content=fallback_response))

            await self._agent.aupdate_state(config, {"messages": messages})
            print(
                f"[RAG] State updated after fallback: {len(messages)} messages, "
                f"tokens≈{_estimate_tokens(messages)}",
                flush=True,
            )
        except Exception as e:
            print(f"[RAG] State update failed: {e}", flush=True)

    def _create_model(self):
        """vLLM 설정으로 LangChain ChatModel 생성."""
        from langchain.chat_models import init_chat_model

        cfg = self._llm_config.get("vllm", {})
        endpoint = cfg.get("endpoint", "").rstrip("/")
        if not endpoint.endswith("/v1"):
            endpoint += "/v1"

        return init_chat_model(
            f"openai:{cfg.get('model', 'default')}",
            base_url=endpoint,
            api_key=cfg.get("apiKey", ""),
            temperature=0.0,
            streaming=True,
            extra_body={"include_reasoning": False},
        )

    @staticmethod
    def _create_tools():
        """rag_search + get_table_columns + load_skills 도구 생성."""
        from jupyter_ext.agent.langchain_tools import (
            create_enhanced_rag_search_tool,
            create_get_table_columns_tool,
            create_load_skills_tool,
        )

        return [
            create_enhanced_rag_search_tool(),
            create_get_table_columns_tool(),
            create_load_skills_tool(),
        ]

    @staticmethod
    def _build_system_prompt() -> str:
        """관리자 커스텀 또는 기본 chat/rag 프롬프트를 결합."""
        base_prompt = ""
        rag_prompt = ""

        try:
            from hdsp_agent_core.managers.config_manager import get_config_manager

            prompts = get_config_manager().get_config().get("prompts", {})
            custom_base = prompts.get("chat_system_prompt")
            if custom_base and custom_base.strip():
                base_prompt = custom_base.strip()
            custom_rag = prompts.get("chat_rag_prompt")
            if custom_rag and custom_rag.strip():
                rag_prompt = custom_rag.strip()
        except Exception:
            pass

        if not base_prompt:
            from hdsp_agent_core.llm.service import _CHAT_SYSTEM_PROMPT

            base_prompt = _CHAT_SYSTEM_PROMPT

        if not rag_prompt:
            rag_prompt = _RAG_SYSTEM_PROMPT_ADDITION

        # MatchText 검색 가능 필드를 동적으로 주입
        match_text_info = _get_match_text_fields_info()
        if match_text_info:
            rag_prompt = rag_prompt + "\n\n" + match_text_info

        return base_prompt + "\n\n" + rag_prompt

    async def _fallback_llm_call(self, config: Dict[str, Any]):
        """그래프 실패 시 state에서 메시지를 가져와 compression 후 LLM 직접 호출."""
        from langchain_core.messages import (
            HumanMessage,
            SystemMessage,
            ToolMessage,
        )

        # checkpointer에서 현재 state 가져오기
        thread_id = (config.get("configurable") or {}).get("thread_id")
        state_messages = []
        if self._checkpointer and thread_id:
            try:
                state = await self._agent.aget_state(config)
                state_messages = state.values.get("messages", [])
            except Exception:
                pass

        if not state_messages:
            raise RuntimeError("No messages in state for fallback")

        print(
            f"[RAG] Fallback: state has {len(state_messages)} messages",
            flush=True,
        )

        # compression 미들웨어 로직 적용
        try:
            compressor = _create_context_compression_middleware_class()()
            compressed = compressor.before_model({"messages": state_messages})
            if compressed:
                state_messages = compressed["messages"]
                print("[RAG] Fallback: compression applied", flush=True)
        except Exception as comp_err:
            print(
                f"[RAG] Fallback: compression failed ({comp_err}), using raw messages",
                flush=True,
            )

        # 사용자 질문 + tool 결과 추출
        user_question = ""
        tool_contents = []
        for msg in state_messages:
            if isinstance(msg, HumanMessage) and not user_question:
                user_question = msg.content
            elif isinstance(msg, ToolMessage) and msg.content:
                tool_contents.append(msg.content[:2000])

        if not user_question:
            raise RuntimeError("No user question found in state")

        combined_results = "\n\n---\n\n".join(tool_contents[-3:])
        model = self._create_model()
        messages = [
            SystemMessage(
                content="사용자 질문과 검색 결과를 바탕으로 답변하세요. "
                "추가 도구 호출 없이 바로 답변만 생성하세요."
            ),
            HumanMessage(
                content=f"질문: {user_question}\n\n검색 결과:\n{combined_results}"
            ),
        ]

        fallback_tokens = _estimate_tokens(messages)
        print(
            f"[RAG] Fallback LLM call: question={user_question[:80]}, "
            f"tool_results={len(tool_contents)}, tokens={fallback_tokens}",
            flush=True,
        )
        async for chunk in model.astream(messages):
            if chunk.content:
                yield chunk.content

    def _ensure_agent(self):
        """create_agent로 agent graph 생성 (lazy)."""
        if self._agent is not None:
            return

        from langchain.agents import create_agent
        from langchain.agents.middleware import (
            ModelRetryMiddleware,
            SummarizationMiddleware,
        )

        model = self._create_model()
        tools = self._create_tools()
        system_prompt = self._build_system_prompt()

        create_kwargs: Dict[str, Any] = dict(
            model=model,
            tools=tools,
            system_prompt=system_prompt,
            middleware=[
                _create_developer_role_middleware_class()(),
                _create_strip_content_on_toolcall_middleware_class()(),
                _create_context_compression_middleware_class()(),
                ModelRetryMiddleware(
                    max_retries=3,
                    backoff_factor=1.5,
                    initial_delay=0.3,
                    max_delay=30.0,
                    on_failure=lambda exc: (
                        print(
                            f"[RAG] LLM API ERROR (all retries failed): {exc}",
                            flush=True,
                        )
                        or f"LLM 호출 실패: {str(exc)[:200]}"
                    ),
                ),
                SummarizationMiddleware(
                    model=model,
                    trigger=("tokens", 90000),
                    keep=("messages", 15),
                    summary_prompt=(
                        "아래 대화 기록에서 가장 중요하고 관련성 높은 정보를 추출하세요.\n"
                        "반드시 한국어로 작성하세요.\n\n"
                        "다음 섹션별로 정리하세요:\n\n"
                        "## 세션 목표\n"
                        "사용자의 주요 목표나 요청은 무엇인가?\n\n"
                        "## 핵심 요약\n"
                        "대화에서 도출된 중요한 결론, 검색 결과, 결정 사항을 기록하세요.\n\n"
                        "## 다음 단계\n"
                        "세션 목표 달성을 위해 남은 작업은 무엇인가?\n\n"
                        "추출한 요약만 출력하세요. 다른 텍스트를 추가하지 마세요.\n\n"
                        "<messages>\n{messages}\n</messages>"
                    ),
                ),
                _create_summary_to_system_middleware_class()(),
            ],
        )
        if self._checkpointer is not None:
            create_kwargs["checkpointer"] = self._checkpointer
        self._agent = create_agent(**create_kwargs)

    async def stream_response(
        self,
        user_message: str,
        history_messages: Optional[List[Dict[str, str]]] = None,
        file_context: Optional[str] = None,
        thread_id: Optional[str] = None,
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """Agent 응답을 스트리밍. SSE 호환 청크 yield.

        Args:
            history_messages: 첫 turn에만 전달 (checkpointer 미사용 또는 서버 재시작 후).
                checkpointer가 state를 유지하면 None으로 전달해 중복 방지.
            thread_id: checkpointer용 thread ID. conversation_id 사용 권장.

        Yields:
            {"content": str, "done": False} — LLM 토큰
            {"status": str, "icon": str, "done": False} — 도구 호출 상태
        """
        self._ensure_agent()

        from langchain_core.messages import AIMessage, HumanMessage

        # 메시지 구성
        messages = []
        if history_messages:
            for m in history_messages:
                if m["role"] == "user":
                    messages.append(HumanMessage(content=m["content"]))
                else:
                    messages.append(AIMessage(content=m["content"]))

        if file_context:
            messages.append(HumanMessage(content=f"[참고 컨텍스트]\n{file_context}"))

        messages.append(HumanMessage(content=user_message))

        input_dict = {"messages": messages}
        config: Dict[str, Any] = {"recursion_limit": 100}
        if thread_id:
            config["configurable"] = {"thread_id": thread_id}

        content_started = False
        tool_call_count = 0
        _rag_search_count = 0  # rag_search 호출 횟수 (과도한 병렬 호출 방어)
        _MAX_RAG_SEARCH = 5
        _pending_tool = False  # parallel tool call 방어: 첫 번째만 처리
        _content_buffer: list[str] = []  # LLM 턴별 content 버퍼 (할루시네이션 방지)
        _tool_processing = False  # tool call 실행 후 LLM 응답 대기 상태

        # Raw LLM 로깅 (핫리로드: 매 요청마다 config 확인)
        _raw_logging = _is_raw_logging_enabled()
        _raw_log_path: Optional[Path] = None
        if _raw_logging:
            _raw_log_path = _get_raw_log_path()
            _append_log(
                _raw_log_path,
                {
                    "type": "user_request",
                    "timestamp": datetime.now().isoformat(),
                    "thread_id": thread_id,
                    "system_prompt": self._build_system_prompt(),
                    "user_message": user_message,
                    "history_count": len(history_messages) if history_messages else 0,
                    "has_file_context": bool(file_context),
                    "file_context": file_context[:500] if file_context else None,
                    "input_messages": [
                        {"role": m.type, "content": m.content} for m in messages
                    ],
                },
            )

        print(f"[RAG] user_message: {user_message[:200]}", flush=True)

        try:
            async for event in self._agent.astream_events(
                input_dict, version="v2", config=config
            ):
                kind = event.get("event", "")

                # 디버그: chain/model 시작/종료 이벤트 로깅
                if kind in (
                    "on_chain_start",
                    "on_chain_end",
                    "on_chat_model_start",
                    "on_chat_model_end",
                    "on_tool_start",
                    "on_tool_end",
                ):
                    evt_name = event.get("name", "")
                    print(
                        f"[RAG] EVENT: {kind} name={evt_name}",
                        flush=True,
                    )

                if kind == "on_chat_model_stream":
                    chunk = event.get("data", {}).get("chunk")
                    if chunk and hasattr(chunk, "content") and chunk.content:
                        # GPT-OSS harmony 특수 토큰 필터링
                        text = chunk.content
                        if _HARMONY_TOKEN_RE.search(text):
                            text = _strip_harmony_tokens(text)
                            if not text:
                                continue

                        # 매 LLM 턴마다 버퍼링: tool call 오면 폐기, 안 오면 flush
                        _content_buffer.append(text)

                elif kind == "on_chat_model_end":
                    output = event.get("data", {}).get("output")
                    has_tc = bool(
                        output and hasattr(output, "tool_calls") and output.tool_calls
                    )
                    buf_len = len(_content_buffer)
                    buf_preview = (
                        "".join(_content_buffer)[:80] if _content_buffer else ""
                    )
                    # LLM 응답 내용 로깅
                    output_content = ""
                    if output and hasattr(output, "content"):
                        output_content = output.content or ""
                    print(
                        f"[RAG] chat_model_end: has_tool_calls={has_tc} "
                        f"buf={buf_len} "
                        f"output_len={len(output_content)} "
                        f"preview={buf_preview!r}",
                        flush=True,
                    )
                    # 빈 응답 감지 (buffer 0, tool_calls 0, output 0)
                    if not _content_buffer and not has_tc and not output_content:
                        print(
                            "[RAG] WARNING: LLM returned empty response",
                            flush=True,
                        )
                    # tool call이 있는 턴: 버퍼 폐기 (할루시네이션)
                    # tool call이 없는 턴: 버퍼 flush (최종 답변)
                    if _content_buffer and has_tc:
                        print(
                            f"[RAG] discarding content with tool_calls: "
                            f"{buf_len} chunks",
                            flush=True,
                        )
                        _content_buffer.clear()
                    elif _content_buffer:
                        # SummarizationMiddleware 출력 감지 → 폐기 + 상태 메시지
                        joined = "".join(_content_buffer)
                        _SUMMARY_PATTERNS = (
                            "SESSION",
                            "## Summary",
                            "## Intent",
                            "## Artifacts",
                            "## Next",
                            "## 세션 목표",
                            "## 핵심 요약",
                            "## 다음 단계",
                            "Here is a summary",
                        )
                        if any(
                            joined.lstrip().startswith(p) for p in _SUMMARY_PATTERNS
                        ):
                            print(
                                f"[RAG] discarding summarization output: {len(joined)} chars",
                                flush=True,
                            )
                            _content_buffer.clear()
                            if _tool_processing:
                                _tool_processing = False
                                yield {"tool_processing_end": True, "done": False}
                            yield {"summarizing": True, "done": False}
                        else:
                            # tool call 후 LLM 응답 시작 → tool_processing 해제
                            if _tool_processing:
                                _tool_processing = False
                                yield {"tool_processing_end": True, "done": False}
                            for buffered in _content_buffer:
                                content_started = True
                                yield {"content": buffered, "done": False}
                            _content_buffer.clear()

                    # Raw LLM 로깅: LLM turn 종료 시 전체 응답 기록
                    if _raw_log_path:
                        output = event.get("data", {}).get("output")
                        log_entry: Dict[str, Any] = {
                            "type": "llm_response",
                            "timestamp": datetime.now().isoformat(),
                            "thread_id": thread_id,
                        }
                        if output and hasattr(output, "content"):
                            log_entry["content"] = output.content or None
                        if output and hasattr(output, "tool_calls"):
                            tc = output.tool_calls
                            if tc:
                                log_entry["tool_calls"] = [
                                    {"name": t.get("name"), "args": t.get("args")}
                                    for t in tc
                                ]
                        _append_log(_raw_log_path, log_entry)

                elif kind == "on_tool_start":
                    # tool call 발생: 버퍼에 쌓인 할루시네이션 content 폐기
                    if _content_buffer:
                        print(
                            f"[RAG] discarding buffered hallucination: "
                            f"{len(_content_buffer)} chunks",
                            flush=True,
                        )
                        _content_buffer.clear()
                    content_started = False

                    # parallel tool call 방어: 이미 tool 실행 중이면 스킵
                    if _pending_tool:
                        print(
                            f"[RAG] parallel tool call skipped: {event.get('name', '')}",
                            flush=True,
                        )
                        continue
                    _pending_tool = True
                    tool_call_count += 1
                    tool_name = event.get("name", "")
                    tool_input = event.get("data", {}).get("input", {})

                    # rag_search 과도한 호출 방어
                    if "rag_search" in tool_name:
                        _rag_search_count += 1
                        if _rag_search_count > _MAX_RAG_SEARCH:
                            print(
                                f"[RAG] rag_search call #{_rag_search_count} "
                                f"blocked (max={_MAX_RAG_SEARCH})",
                                flush=True,
                            )
                            _pending_tool = False
                            continue

                    if "skill" in tool_name.lower():
                        # Skill 로드 도구
                        skill_names = ""
                        if isinstance(tool_input, dict):
                            skill_names = tool_input.get("names", "")
                        elif isinstance(tool_input, str):
                            skill_names = tool_input
                        print(
                            f"[RAG] tool_start (call #{tool_call_count}): {tool_name}",
                            flush=True,
                        )
                        if skill_names:
                            yield {
                                "status": f"🔧 스킬 로딩: {skill_names}",
                                "icon": "search",
                                "done": False,
                            }
                    elif "get_table_columns" in tool_name:
                        # get_table_columns 도구
                        tbl = (
                            tool_input.get("table_name", "")
                            if isinstance(tool_input, dict)
                            else ""
                        )
                        print(
                            f"[RAG] tool_start (call #{tool_call_count}): "
                            f"{tool_name} table={tbl}",
                            flush=True,
                        )
                        yield {
                            "status": f"📋 컬럼 목록 조회 중... {tbl}",
                            "icon": "search",
                            "done": False,
                        }
                    else:
                        # rag_search 도구
                        queries_str = ""
                        if isinstance(tool_input, dict):
                            queries_str = tool_input.get("queries", "")
                        elif isinstance(tool_input, str):
                            queries_str = tool_input
                        status_msg = _format_tool_status(queries_str)
                        print(
                            f"[RAG] tool_start (call #{tool_call_count}): "
                            f"input_type={type(tool_input).__name__} "
                            f"{queries_str[:200]}",
                            flush=True,
                        )
                        yield {
                            "status": status_msg,
                            "icon": "search",
                            "done": False,
                        }

                elif kind == "on_tool_end":
                    _pending_tool = False  # 다음 tool call 허용
                    tool_name = event.get("name", "")
                    output = event.get("data", {}).get("output", "")
                    if hasattr(output, "content"):
                        output = output.content

                    if "skill" in tool_name.lower():
                        # Skill 로드 완료 — 상태 메시지 없이 로깅만
                        print(f"[RAG] tool_end: {tool_name} loaded", flush=True)
                    elif "get_table_columns" in tool_name:
                        # get_table_columns 완료
                        total_cols = 0
                        tbl_name = ""
                        try:
                            parsed = (
                                json.loads(output)
                                if isinstance(output, str)
                                else output
                            )
                            if isinstance(parsed, dict):
                                total_cols = parsed.get("total_columns", 0)
                                tbl_name = parsed.get("table_name", "")
                        except Exception:
                            pass
                        print(
                            f"[RAG] tool_end: {tool_name} "
                            f"table={tbl_name} cols={total_cols}",
                            flush=True,
                        )
                        yield {
                            "status": f"📋 컬럼 조회 완료. {tbl_name} {total_cols}개",
                            "icon": "search",
                            "done": False,
                        }
                        if not _tool_processing:
                            _tool_processing = True
                            yield {"tool_processing": True, "done": False}
                    else:
                        # rag_search 결과
                        total = 0
                        q_summary = ""
                        try:
                            parsed = (
                                json.loads(output)
                                if isinstance(output, str)
                                else output
                            )
                            if isinstance(parsed, dict):
                                total = parsed.get("total", 0)
                        except Exception:
                            pass
                        # 쿼리 요약 텍스트 생성
                        try:
                            q_input = event.get("data", {}).get("input", {})
                            q_str = (
                                q_input.get("queries", "")
                                if isinstance(q_input, dict)
                                else ""
                            )
                            q_list = json.loads(q_str) if q_str else []
                            seen: set = set()
                            q_texts: list = []
                            for q in q_list:
                                txt = (
                                    q.get("query", "").strip()
                                    if isinstance(q, dict)
                                    else ""
                                )
                                if txt and txt.lower() not in seen:
                                    seen.add(txt.lower())
                                    q_texts.append(txt)
                            if q_texts:
                                q_summary = ", ".join(f'"{t}"' for t in q_texts[:3])
                        except Exception:
                            pass
                        print(f"[RAG] tool_end: total={total}", flush=True)
                        yield {
                            "status": f"📚 지식 베이스 검색 완료. {q_summary} {total}건"
                            if q_summary
                            else f"📚 지식 베이스 검색 완료. {total}건",
                            "icon": "search",
                            "replace": True,
                            "done": False,
                        }

                        # tool 실행 완료 → LLM이 결과 분석 중 상태
                        if not _tool_processing:
                            _tool_processing = True
                            yield {"tool_processing": True, "done": False}

                        # Raw LLM 로깅: tool_call 결과 기록
                        if _raw_log_path:
                            _append_log(
                                _raw_log_path,
                                {
                                    "type": "tool_result",
                                    "timestamp": datetime.now().isoformat(),
                                    "thread_id": thread_id,
                                    "tool_name": tool_name,
                                    "total": total,
                                    "output": output[:2000]
                                    if isinstance(output, str)
                                    else str(output)[:2000],
                                },
                            )

        except Exception as e:
            import traceback

            err_msg = str(e)
            print(f"[RAG] ERROR: {err_msg}", flush=True)
            traceback.print_exc()

            if "recursion limit" in err_msg.lower():
                print("[RAG] Recursion limit — attempting final LLM call", flush=True)
                if not content_started:
                    # 그래프 state에서 메시지를 가져와 LLM 직접 호출
                    try:
                        async for chunk in self._fallback_llm_call(config):
                            content_started = True
                            yield {"content": chunk, "done": False}
                    except Exception as fallback_err:
                        print(
                            f"[RAG] Fallback LLM call failed: {fallback_err}",
                            flush=True,
                        )
                        yield {
                            "content": "검색 결과를 바탕으로 답변을 준비했으나 "
                            "처리 한도에 도달했습니다. 질문을 더 구체적으로 "
                            "해주시면 정확한 답변을 드릴 수 있습니다.",
                            "done": False,
                        }
            else:
                yield {"error": f"RAG agent 오류: {err_msg}"}

        # 스트림 종료 후 content가 없으면 fallback LLM 호출
        if not content_started and _tool_processing:
            print(
                "[RAG] WARNING: stream ended without content after tool_end — attempting fallback",
                flush=True,
            )
            fallback_chunks: list[str] = []
            try:
                async for chunk in self._fallback_llm_call(config):
                    content_started = True
                    fallback_chunks.append(chunk)
                    yield {"content": chunk, "done": False}
            except Exception as fallback_err:
                print(f"[RAG] Fallback LLM call failed: {fallback_err}", flush=True)
                yield {
                    "content": "검색은 완료되었으나 응답 생성에 실패했습니다. 다시 시도해주세요.",
                    "done": False,
                }

            # fallback 성공 시 compressed context + 응답을 state에 반영
            if fallback_chunks and self._checkpointer and thread_id:
                # fallback에서 사용한 compressed messages 가져오기
                compressed_msgs = None
                try:
                    compressor = _create_context_compression_middleware_class()()
                    state = await self._agent.aget_state(config)
                    raw_msgs = list(state.values.get("messages", []))
                    result = compressor.before_model({"messages": raw_msgs})
                    compressed_msgs = result["messages"] if result else raw_msgs
                except Exception:
                    pass
                await self._cleanup_state_after_fallback(
                    config, "".join(fallback_chunks), compressed_msgs
                )
