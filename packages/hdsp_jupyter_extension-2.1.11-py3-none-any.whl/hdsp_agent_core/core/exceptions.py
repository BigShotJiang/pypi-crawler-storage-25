"""AgentError 계층 구조 — 에이전트 에러의 구조화된 분류."""

from __future__ import annotations


class AgentError(Exception):
    """에이전트 에러의 기본 클래스."""

    error_type: str = "agent_error"

    def __init__(self, message: str, *, cause: Exception | None = None):
        super().__init__(message)
        self.cause = cause


class LLMError(AgentError):
    """LLM 호출 관련 에러."""

    error_type: str = "llm_error"

    def __init__(
        self,
        message: str,
        *,
        provider: str = "",
        model: str = "",
        cause: Exception | None = None,
    ):
        super().__init__(message, cause=cause)
        self.provider = provider
        self.model = model


class ToolError(AgentError):
    """도구 실행 관련 에러."""

    error_type: str = "tool_error"

    def __init__(
        self, message: str, *, tool_name: str = "", cause: Exception | None = None
    ):
        super().__init__(message, cause=cause)
        self.tool_name = tool_name


class ValidationError(AgentError):
    """입력/출력 검증 에러."""

    error_type: str = "validation_error"
