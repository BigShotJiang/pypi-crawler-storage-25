"""
HDSP Agent Core 공통 Pydantic 모델

모든 에이전트 서비스에서 사용되는 공유 데이터 모델.
"""

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field


class ToolCall(BaseModel):
    """도구 호출 명세"""

    tool: str = Field(description="도구 이름 (예: 'jupyter_cell', 'file_operation')")
    parameters: Dict[str, Any] = Field(
        default_factory=dict, description="도구 매개변수"
    )


class ErrorInfo(BaseModel):
    """오류 정보 구조"""

    type: str = Field(default="runtime", description="오류 유형")
    message: str = Field(default="", description="오류 메시지")
    traceback: Optional[List[str]] = Field(
        default=None, description="스택 트레이스 라인"
    )


class NotebookContext(BaseModel):
    """노트북 실행 컨텍스트"""

    cellCount: int = Field(default=0, description="노트북의 셀 수")
    importedLibraries: List[str] = Field(
        default_factory=list, description="이미 import된 라이브러리"
    )
    definedVariables: List[str] = Field(
        default_factory=list, description="현재 정의된 변수"
    )
    recentCells: List[Dict[str, Any]] = Field(
        default_factory=list, description="최근 셀 내용과 출력"
    )


class APIResponse(BaseModel):
    """일반 API 응답 래퍼"""

    success: bool = Field(default=True)
    message: Optional[str] = None
    data: Optional[Dict[str, Any]] = None
    error: Optional[str] = None


# ============ LLM 설정 (클라이언트 제공) ============


class VLLMConfig(BaseModel):
    """vLLM 프로바이더 설정"""

    endpoint: str = Field(
        default="http://localhost:8000", description="vLLM 엔드포인트"
    )
    apiKey: Optional[str] = Field(default=None, description="선택적 API 키")
    model: str = Field(default="default", description="모델 이름")


class LLMConfig(BaseModel):
    """
    클라이언트가 제공하는 LLM 설정.
    API 키는 클라이언트 측에서 관리되며 각 요청과 함께 전달됩니다.
    """

    model_config = ConfigDict(populate_by_name=True)

    provider: str = Field(default="vllm", description="LLM 프로바이더 (vllm)")
    vllm: Optional[VLLMConfig] = Field(default=None, description="vLLM 설정")
    system_prompt: Optional[str] = Field(
        default=None,
        alias="systemPrompt",
        description="LangChain 시스템 프롬프트 오버라이드",
    )
