"""add_is_child_question_to_rfp_document_question

Revision ID: 8a15a8f4c3b7
Revises: 37444aa582fe
Create Date: 2026-03-08 00:10:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = '8a15a8f4c3b7'
down_revision: Union[str, Sequence[str], None] = '37444aa582fe'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """Upgrade schema."""
    op.add_column('rfp_document_question', sa.Column('is_child_question', sa.Boolean(), nullable=True))


def downgrade() -> None:
    """Downgrade schema."""
    op.drop_column('rfp_document_question', 'is_child_question')
