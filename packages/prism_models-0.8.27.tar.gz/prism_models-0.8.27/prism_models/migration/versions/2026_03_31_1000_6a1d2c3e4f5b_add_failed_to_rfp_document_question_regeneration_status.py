"""add failed to rfp_document_question regeneration_status

Revision ID: 6a1d2c3e4f5b
Revises: 2f7c1d9e4b6a
Create Date: 2026-03-31 10:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = '6a1d2c3e4f5b'
down_revision: Union[str, Sequence[str], None] = '2f7c1d9e4b6a'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """Upgrade schema."""
    op.alter_column(
        'rfp_document_question',
        'regeneration_status',
        existing_type=sa.Enum(
            'PENDING',
            'PROCESSING',
            'COMPLETED',
            name='rfpdocumentquestionregenerationstatus',
            native_enum=False,
        ),
        type_=sa.Enum(
            'PENDING',
            'PROCESSING',
            'COMPLETED',
            'FAILED',
            name='rfpdocumentquestionregenerationstatus',
            native_enum=False,
        ),
        existing_nullable=True,
    )


def downgrade() -> None:
    """Downgrade schema."""
    op.execute(
        """
        UPDATE rfp_document_question
        SET regeneration_status = NULL
        WHERE regeneration_status = 'FAILED'
        """
    )
    op.alter_column(
        'rfp_document_question',
        'regeneration_status',
        existing_type=sa.Enum(
            'PENDING',
            'PROCESSING',
            'COMPLETED',
            'FAILED',
            name='rfpdocumentquestionregenerationstatus',
            native_enum=False,
        ),
        type_=sa.Enum(
            'PENDING',
            'PROCESSING',
            'COMPLETED',
            name='rfpdocumentquestionregenerationstatus',
            native_enum=False,
        ),
        existing_nullable=True,
    )
