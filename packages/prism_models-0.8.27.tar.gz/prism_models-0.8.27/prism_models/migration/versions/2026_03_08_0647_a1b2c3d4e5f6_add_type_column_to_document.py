"""add_type_column_to_document

Revision ID: a1b2c3d4e5f6
Revises: 8a15a8f4c3b7
Create Date: 2026-03-08 06:47:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = 'a1b2c3d4e5f6'
down_revision: Union[str, Sequence[str], None] = '8a15a8f4c3b7'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """Upgrade schema."""
    # 1. Add column as nullable first
    op.add_column('document', sa.Column('type', sa.Enum('KNOWLEDGE_BASE', 'ENTERPRISE_PROJECT', name='documenttype', native_enum=False), server_default='knowledge_base', nullable=True))
    # 2. Backfill existing rows
    op.execute("UPDATE document SET type = 'knowledge_base' WHERE type IS NULL")
    # 3. Set column to NOT NULL
    op.alter_column('document', 'type', nullable=False)
    op.create_index(op.f('document_type_idx'), 'document', ['type'], unique=False)


def downgrade() -> None:
    """Downgrade schema."""
    op.drop_index(op.f('document_type_idx'), table_name='document')
    op.drop_column('document', 'type')
