"""fix document type enum casing to uppercase

Revision ID: 0806f4dcc1db
Revises: 9959d986bb48
Create Date: 2026-03-13 14:33:30.516628

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = '0806f4dcc1db'
down_revision: Union[str, Sequence[str], None] = '9959d986bb48'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.alter_column(
        'document',
        'type',
        type_=sa.Enum('knowledge_base', 'enterprise_project', name='documenttype', native_enum=False),
        existing_nullable=False,
        server_default='knowledge_base',
    )

def downgrade() -> None:
    op.alter_column(
        'document',
        'type',
        type_=sa.Enum('KNOWLEDGE_BASE', 'ENTERPRISE_PROJECT', name='documenttype', native_enum=False),
        existing_nullable=False,
        server_default='knowledge_base',
    )


