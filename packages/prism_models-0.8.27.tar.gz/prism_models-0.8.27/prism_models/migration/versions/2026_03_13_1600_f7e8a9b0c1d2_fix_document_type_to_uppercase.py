"""fix document type enum to use uppercase names (SQLAlchemy stores enum names not values)

Revision ID: f7e8a9b0c1d2
Revises: 24c4e6eee4f7
Create Date: 2026-03-13 16:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = 'f7e8a9b0c1d2'
down_revision: Union[str, Sequence[str], None] = '24c4e6eee4f7'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # 1. Normalize all data to uppercase enum names
    op.execute("UPDATE document SET type = 'KNOWLEDGE_BASE' WHERE type = 'knowledge_base'")
    op.execute("UPDATE document SET type = 'ENTERPRISE_PROJECT' WHERE type = 'enterprise_project'")

    # 2. Fix the column type / CHECK constraint to use uppercase
    op.alter_column(
        'document',
        'type',
        type_=sa.Enum('KNOWLEDGE_BASE', 'ENTERPRISE_PROJECT', name='documenttype', native_enum=False),
        existing_nullable=False,
        server_default='KNOWLEDGE_BASE',
    )


def downgrade() -> None:
    op.alter_column(
        'document',
        'type',
        type_=sa.Enum('knowledge_base', 'enterprise_project', name='documenttype', native_enum=False),
        existing_nullable=False,
        server_default='knowledge_base',
    )
    op.execute("UPDATE document SET type = 'knowledge_base' WHERE type = 'KNOWLEDGE_BASE'")
    op.execute("UPDATE document SET type = 'enterprise_project' WHERE type = 'ENTERPRISE_PROJECT'")
