"""add markdown_strategy to source

Revision ID: 1e2f3a4b5c6d
Revises: 0d29a4c7737d
Create Date: 2026-04-10 12:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = '1e2f3a4b5c6d'
down_revision: Union[str, None] = '0d29a4c7737d'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column(
        'source',
        sa.Column(
            'markdown_strategy',
            sa.Enum('docling_ocr', 'openai', 'gemini', name='markdownstrategy', native_enum=False),
            nullable=True,
            server_default='docling_ocr',
        ),
    )


def downgrade() -> None:
    op.drop_column('source', 'markdown_strategy')
