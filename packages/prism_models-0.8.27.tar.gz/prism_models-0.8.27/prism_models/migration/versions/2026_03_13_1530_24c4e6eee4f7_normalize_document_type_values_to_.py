"""normalize document type values to lowercase

Revision ID: 24c4e6eee4f7
Revises: 0806f4dcc1db
Create Date: 2026-03-13 15:30:00.000000

"""
from typing import Sequence, Union

from alembic import op


# revision identifiers, used by Alembic.
revision: str = '24c4e6eee4f7'
down_revision: Union[str, Sequence[str], None] = '0806f4dcc1db'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.execute("UPDATE document SET type = LOWER(type) WHERE type != LOWER(type)")


def downgrade() -> None:
    pass
