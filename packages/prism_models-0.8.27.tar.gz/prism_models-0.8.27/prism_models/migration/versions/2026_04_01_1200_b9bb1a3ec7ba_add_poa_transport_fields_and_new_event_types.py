"""add poa transport fields and new event types

Revision ID: b9bb1a3ec7ba
Revises: 1f2e3d4c5b6a
Create Date: 2026-04-01 12:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = 'b9bb1a3ec7ba'
down_revision: Union[str, Sequence[str], None] = '1f2e3d4c5b6a'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """Upgrade schema."""
    # 1. Expand PoaEventType to include CREW_REST, REFUEL
    op.alter_column(
        'poa_event',
        'event_type',
        existing_type=sa.Enum(
            'FLIGHT', 'LAYOVER', 'GROUND_TRANSPORT', 'HOTEL', 'BEDSIDE',
            'MEDICATION', 'PRE_FLIGHT_CHECK', 'POST_FLIGHT_CHECK', 'OTHER',
            name='poaeventtype', native_enum=False,
        ),
        type_=sa.Enum(
            'FLIGHT', 'LAYOVER', 'GROUND_TRANSPORT', 'HOTEL', 'BEDSIDE',
            'MEDICATION', 'PRE_FLIGHT_CHECK', 'POST_FLIGHT_CHECK',
            'CREW_REST', 'REFUEL', 'OTHER',
            name='poaeventtype', native_enum=False,
        ),
        existing_nullable=False,
    )

    # 2. Add transport_type and mrt_subtype columns to poa_plan
    op.add_column(
        'poa_plan',
        sa.Column(
            'transport_type',
            sa.Enum(
                'LOCAL_FIELD_RESCUE', 'FIELD_RESCUE', 'MEDICAL_EVACUATION',
                'MRT', 'SECURITY_EVACUATION_AND_SERVICES',
                name='poatransporttype', native_enum=False,
            ),
            nullable=True,
        ),
    )
    op.add_column(
        'poa_plan',
        sa.Column(
            'mrt_subtype',
            sa.Enum(
                'WHOLE_BODY', 'CREMATED',
                name='poamrtsubtype', native_enum=False,
            ),
            nullable=True,
        ),
    )


def downgrade() -> None:
    """Downgrade schema."""
    # 1. Drop new columns
    op.drop_column('poa_plan', 'mrt_subtype')
    op.drop_column('poa_plan', 'transport_type')

    # 2. Revert PoaEventType (null out new values first)
    op.execute(
        """
        UPDATE poa_event
        SET event_type = 'OTHER'
        WHERE event_type IN ('CREW_REST', 'REFUEL')
        """
    )
    op.alter_column(
        'poa_event',
        'event_type',
        existing_type=sa.Enum(
            'FLIGHT', 'LAYOVER', 'GROUND_TRANSPORT', 'HOTEL', 'BEDSIDE',
            'MEDICATION', 'PRE_FLIGHT_CHECK', 'POST_FLIGHT_CHECK',
            'CREW_REST', 'REFUEL', 'OTHER',
            name='poaeventtype', native_enum=False,
        ),
        type_=sa.Enum(
            'FLIGHT', 'LAYOVER', 'GROUND_TRANSPORT', 'HOTEL', 'BEDSIDE',
            'MEDICATION', 'PRE_FLIGHT_CHECK', 'POST_FLIGHT_CHECK', 'OTHER',
            name='poaeventtype', native_enum=False,
        ),
        existing_nullable=False,
    )
