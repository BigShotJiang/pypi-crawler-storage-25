"""add sharepoint_site_id and sharepoint_drive_name to source

Revision ID: a2b3c4d5e6f7
Revises: b9bb1a3ec7ba
Create Date: 2026-04-08 10:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = 'a2b3c4d5e6f7'
down_revision: Union[str, None] = 'b9bb1a3ec7ba'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column('source', sa.Column('sharepoint_site_id', sa.String(255), nullable=True))
    op.add_column('source', sa.Column('sharepoint_drive_name', sa.String(255), nullable=True))

    op.execute(
        """
        UPDATE source
        SET
            sharepoint_site_id = '5b647b7c-7239-4b20-8dd9-6278dbc24dfc',
            sharepoint_drive_name = 'GR-ACE'
        WHERE sharepoint_directory IS NOT NULL
        """
    )


def downgrade() -> None:
    op.drop_column('source', 'sharepoint_drive_name')
    op.drop_column('source', 'sharepoint_site_id')
