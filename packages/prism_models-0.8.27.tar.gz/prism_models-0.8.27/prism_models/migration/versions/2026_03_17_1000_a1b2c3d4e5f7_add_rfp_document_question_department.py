"""add rfp_document_question_department table

Revision ID: a1b2c3d4e5f7
Revises: f7e8a9b0c1d2
Create Date: 2026-03-17 10:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = 'a1b2c3d4e5f7'
down_revision: Union[str, Sequence[str], None] = 'f7e8a9b0c1d2'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        'rfp_document_question_department',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('rfp_document_question_id', sa.Integer(), nullable=False),
        sa.Column(
            'name',
            sa.Enum('hcm', 'it', 'legal', 'operations', 'sales', 'marketing', 'finance',
                    name='departmenttype', native_enum=False),
            nullable=False,
        ),
        sa.ForeignKeyConstraint(
            ['rfp_document_question_id'],
            ['rfp_document_question.id'],
            ondelete='CASCADE',
        ),
        sa.PrimaryKeyConstraint('id'),
    )
    op.create_index(
        'ix_rfp_document_question_department_rfp_document_question_id',
        'rfp_document_question_department',
        ['rfp_document_question_id'],
    )
    op.create_index(
        'ix_rfp_document_question_department_name',
        'rfp_document_question_department',
        ['name'],
    )


def downgrade() -> None:
    op.drop_index(
        'ix_rfp_document_question_department_name',
        table_name='rfp_document_question_department',
    )
    op.drop_index(
        'ix_rfp_document_question_department_rfp_document_question_id',
        table_name='rfp_document_question_department',
    )
    op.drop_table('rfp_document_question_department')
