"""migrate relevant_department to rfp_document_question_department

Revision ID: e5f6a7b8c9d0
Revises: d4e5f6a7b8c9
Create Date: 2026-03-24 10:01:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.sql import text


# revision identifiers, used by Alembic.
revision: str = 'e5f6a7b8c9d0'
down_revision: Union[str, Sequence[str], None] = 'd4e5f6a7b8c9'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

VALID_DEPARTMENTS = {'hcm', 'it', 'legal', 'operations', 'sales', 'marketing', 'finance'}


def upgrade() -> None:
    conn = op.get_bind()

    # Find all questions with a relevant_department not already in the new table
    rows = conn.execute(text("""
        SELECT q.id, LOWER(q.relevant_department) AS dept
        FROM rfp_document_question q
        WHERE q.relevant_department IS NOT NULL
          AND NOT EXISTS (
              SELECT 1
              FROM rfp_document_question_department d
              WHERE d.rfp_document_question_id = q.id
          )
    """)).fetchall()

    to_insert = [
        {'rfp_document_question_id': row.id, 'name': row.dept}
        for row in rows
        if row.dept in VALID_DEPARTMENTS
    ]

    if to_insert:
        conn.execute(
            text("""
                INSERT INTO rfp_document_question_department (rfp_document_question_id, name)
                VALUES (:rfp_document_question_id, :name)
            """),
            to_insert,
        )


def downgrade() -> None:
    # Remove department rows that were migrated from relevant_department
    conn = op.get_bind()
    conn.execute(text("""
        DELETE FROM rfp_document_question_department d
        WHERE EXISTS (
            SELECT 1
            FROM rfp_document_question q
            WHERE q.id = d.rfp_document_question_id
              AND LOWER(q.relevant_department) = d.name
        )
    """))
