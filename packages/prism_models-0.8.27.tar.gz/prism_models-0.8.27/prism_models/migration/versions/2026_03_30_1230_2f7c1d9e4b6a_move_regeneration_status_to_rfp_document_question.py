"""move regeneration_status to rfp_document_question

Revision ID: 2f7c1d9e4b6a
Revises: 1c9e4f7a2b6d
Create Date: 2026-03-30 12:30:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = '2f7c1d9e4b6a'
down_revision: Union[str, Sequence[str], None] = '1c9e4f7a2b6d'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """Upgrade schema."""
    op.drop_index(
        op.f('rfp_document_regeneration_status_idx'),
        table_name='rfp_document',
    )
    op.drop_column('rfp_document', 'regeneration_status')

    op.add_column(
        'rfp_document_question',
        sa.Column(
            'regeneration_status',
            sa.Enum(
                'PENDING',
                'PROCESSING',
                'COMPLETED',
                name='rfpdocumentquestionregenerationstatus',
                native_enum=False,
            ),
            nullable=True,
        ),
    )
    op.create_index(
        op.f('rfp_document_question_regeneration_status_idx'),
        'rfp_document_question',
        ['regeneration_status'],
        unique=False,
    )


def downgrade() -> None:
    """Downgrade schema."""
    op.drop_index(
        op.f('rfp_document_question_regeneration_status_idx'),
        table_name='rfp_document_question',
    )
    op.drop_column('rfp_document_question', 'regeneration_status')

    op.add_column(
        'rfp_document',
        sa.Column(
            'regeneration_status',
            sa.Enum(
                'PENDING',
                'PROCESSING',
                'COMPLETED',
                name='rfpdocumentregenerationstatus',
                native_enum=False,
            ),
            nullable=True,
        ),
    )
    op.create_index(
        op.f('rfp_document_regeneration_status_idx'),
        'rfp_document',
        ['regeneration_status'],
        unique=False,
    )
