"""add regeneration_instructions to rfp_document_question

Revision ID: 1f2e3d4c5b6a
Revises: 6a1d2c3e4f5b
Create Date: 2026-03-31 10:30:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = '1f2e3d4c5b6a'
down_revision: Union[str, Sequence[str], None] = '6a1d2c3e4f5b'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """Upgrade schema."""
    op.add_column(
        'rfp_document_question',
        sa.Column('regeneration_instructions', sa.Text(), nullable=True),
    )


def downgrade() -> None:
    """Downgrade schema."""
    op.drop_column('rfp_document_question', 'regeneration_instructions')
