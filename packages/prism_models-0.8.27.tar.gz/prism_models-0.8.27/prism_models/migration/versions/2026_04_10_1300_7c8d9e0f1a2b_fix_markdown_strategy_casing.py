"""fix markdown_strategy enum casing to uppercase

Revision ID: 7c8d9e0f1a2b
Revises: 1e2f3a4b5c6d
Create Date: 2026-04-10 13:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = '7c8d9e0f1a2b'
down_revision: Union[str, Sequence[str], None] = '1e2f3a4b5c6d'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.execute("UPDATE source SET markdown_strategy = 'DOCLING_OCR' WHERE markdown_strategy = 'docling_ocr'")
    op.execute("UPDATE source SET markdown_strategy = 'OPENAI' WHERE markdown_strategy = 'openai'")
    op.execute("UPDATE source SET markdown_strategy = 'GEMINI' WHERE markdown_strategy = 'gemini'")

    op.alter_column(
        'source',
        'markdown_strategy',
        existing_type=sa.Enum('docling_ocr', 'openai', 'gemini', name='markdownstrategy', native_enum=False),
        type_=sa.Enum('DOCLING_OCR', 'OPENAI', 'GEMINI', name='markdownstrategy', native_enum=False),
        existing_nullable=True,
        server_default='DOCLING_OCR',
    )


def downgrade() -> None:
    op.alter_column(
        'source',
        'markdown_strategy',
        existing_type=sa.Enum('DOCLING_OCR', 'OPENAI', 'GEMINI', name='markdownstrategy', native_enum=False),
        type_=sa.Enum('docling_ocr', 'openai', 'gemini', name='markdownstrategy', native_enum=False),
        existing_nullable=True,
        server_default='docling_ocr',
    )

    op.execute("UPDATE source SET markdown_strategy = 'docling_ocr' WHERE markdown_strategy = 'DOCLING_OCR'")
    op.execute("UPDATE source SET markdown_strategy = 'openai' WHERE markdown_strategy = 'OPENAI'")
    op.execute("UPDATE source SET markdown_strategy = 'gemini' WHERE markdown_strategy = 'GEMINI'")
