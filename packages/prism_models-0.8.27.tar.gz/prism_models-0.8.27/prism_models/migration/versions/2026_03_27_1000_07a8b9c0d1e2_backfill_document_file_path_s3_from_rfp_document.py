"""backfill document file_path_s3 from rfp_document s3_url

Revision ID: 07a8b9c0d1e2
Revises: f6a7b8c9d0e1
Create Date: 2026-03-27 10:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
from sqlalchemy.sql import text


# revision identifiers, used by Alembic.
revision: str = '07a8b9c0d1e2'
down_revision: Union[str, Sequence[str], None] = 'f6a7b8c9d0e1'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    conn = op.get_bind()

    # Backfill the persisted S3 path onto document rows that were linked to
    # ER/RFP uploads before document.file_path_s3 was consistently populated.
    result = conn.execute(text("""
        UPDATE document AS d
        SET file_path_s3 = rd.s3_url,
            updated_at = NOW()
        FROM rfp_document AS rd
        WHERE rd.document_id = d.id
          AND rd.document_id IS NOT NULL
          AND rd.s3_url IS NOT NULL
          AND rd.deleted_at IS NULL
          AND d.deleted_at IS NULL
          AND (d.file_path_s3 IS NULL OR d.file_path_s3 = '')
          AND d.file_path_s3 IS DISTINCT FROM rd.s3_url
    """))

    print(
        "Backfilled "
        f"{result.rowcount} document.file_path_s3 rows from rfp_document.s3_url"
    )


def downgrade() -> None:
    # No-op: this backfill copies persisted data into a canonical column and is
    # not safely reversible without risking removal of legitimate values.
    pass
