"""alter character_limit to string on rfp_document_question

Revision ID: c3d4e5f6a7b9
Revises: b2c3d4e5f6a8
Create Date: 2026-03-17 10:02:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = 'c3d4e5f6a7b9'
down_revision: Union[str, Sequence[str], None] = 'b2c3d4e5f6a8'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.alter_column(
        'rfp_document_question',
        'character_limit',
        type_=sa.String(255),
        existing_type=sa.Integer(),
        existing_nullable=True,
        postgresql_using='character_limit::varchar',
    )


def downgrade() -> None:
    op.alter_column(
        'rfp_document_question',
        'character_limit',
        type_=sa.Integer(),
        existing_type=sa.String(255),
        existing_nullable=True,
        postgresql_using='character_limit::integer',
    )
