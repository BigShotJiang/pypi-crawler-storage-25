"""add_type_column_to_rfp_profile

Revision ID: b2c3d4e5f6a7
Revises: a1b2c3d4e5f6
Create Date: 2026-03-08 07:12:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = 'b2c3d4e5f6a7'
down_revision: Union[str, Sequence[str], None] = 'a1b2c3d4e5f6'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """Upgrade schema."""
    # 1. Add column as nullable first
    op.add_column('rfp_profile', sa.Column('type', sa.Enum('RFP', 'VENDOR_ONBOARDING', name='rfpprofiletype', native_enum=False), server_default='RFP', nullable=True))
    # 2. Backfill existing rows
    op.execute("UPDATE rfp_profile SET type = 'RFP' WHERE type IS NULL")
    # 3. Set column to NOT NULL
    op.alter_column('rfp_profile', 'type', nullable=False)
    op.create_index(op.f('ix_rfp_profile_type'), 'rfp_profile', ['type'], unique=False)


def downgrade() -> None:
    """Downgrade schema."""
    op.drop_index(op.f('ix_rfp_profile_type'), table_name='rfp_profile')
    op.drop_column('rfp_profile', 'type')
