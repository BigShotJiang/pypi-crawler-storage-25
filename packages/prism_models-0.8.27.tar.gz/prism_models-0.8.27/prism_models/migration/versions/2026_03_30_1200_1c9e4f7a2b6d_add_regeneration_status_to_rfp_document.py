"""add regeneration_status to rfp_document

Revision ID: 1c9e4f7a2b6d
Revises: 07a8b9c0d1e2
Create Date: 2026-03-30 12:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = '1c9e4f7a2b6d'
down_revision: Union[str, Sequence[str], None] = '07a8b9c0d1e2'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """Upgrade schema."""
    op.add_column(
        'rfp_document',
        sa.Column(
            'regeneration_status',
            sa.Enum(
                'PENDING',
                'PROCESSING',
                'COMPLETED',
                name='rfpdocumentregenerationstatus',
                native_enum=False,
            ),
            nullable=True,
        ),
    )
    op.create_index(
        op.f('rfp_document_regeneration_status_idx'),
        'rfp_document',
        ['regeneration_status'],
        unique=False,
    )


def downgrade() -> None:
    """Downgrade schema."""
    op.drop_index(
        op.f('rfp_document_regeneration_status_idx'),
        table_name='rfp_document',
    )
    op.drop_column('rfp_document', 'regeneration_status')
