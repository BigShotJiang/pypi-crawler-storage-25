from functools import lru_cache

from django.contrib import admin
from django.contrib.auth import get_user_model
from django.utils.html import format_html
from django.urls import path, reverse

from .models import (
    LoginAuditEvent,
    ProcessAuditEvent,
    RegistrationAuditEvent,
    RequestAuditEvent,
    StepAuditEvent,
)
from .settings import DRF_AUDIT_TRAIL_USER_PK_NAME
from .views import get_process_for_report, render_process_report_response

UserModel = get_user_model()


@lru_cache(maxsize=128)
def _get_user_by_id(user_id: str | None):
    try:
        filter_param = {DRF_AUDIT_TRAIL_USER_PK_NAME: user_id}
        user = UserModel.objects.filter(**filter_param).first()
        if user is not None:
            return user
    except ValueError:
        pass


class ReadonlyAdminMixin(admin.ModelAdmin):
    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False

    def has_delete_permission(self, request, obj=None):
        return False


class RequestAuditEventModelAdmin(ReadonlyAdminMixin, admin.ModelAdmin):
    list_display = (
        "id",
        "method",
        "url",
        "status_code",
        "_user",
        "datetime",
        "request_type",
    )
    list_filter = ("method", "ip_addresses")
    search_fields = ("method", "ip_addresses", "status_code", "user", "url")

    def _user(self, obj: RequestAuditEvent):
        return _get_user_by_id(obj.user)


admin.site.register(RequestAuditEvent, RequestAuditEventModelAdmin)


class LoginAuditEventModelAdmin(ReadonlyAdminMixin, admin.ModelAdmin):
    list_display = (
        "id",
        "user",
        "status",
        "datetime",
        "request_ip_addresses",
        "request__status_code",
    )
    list_filter = ("status",)
    search_fields = ("request__ip_addresses", "request__user", "request__url")
    readonly_fields = ["request"]

    @admin.display()
    def request_ip_addresses(self, obj):
        if obj.request is not None:
            return obj.request.ip_addresses

    @admin.display()
    def request__status_code(self, obj):
        if obj.request is not None:
            return obj.request.status_code

    def user(self, obj):
        if obj.request is not None:
            return _get_user_by_id(obj.request.user)


admin.site.register(LoginAuditEvent, LoginAuditEventModelAdmin)


class ProcessAuditEventModelAdmin(admin.ModelAdmin):
    list_display = ("id", "name", "success", "request", "user", "download_audit_pdf")
    list_filter = ("name",)
    search_fields = ("name",)
    change_form_template = "admin/drf_audit_trail/processauditevent/change_form.html"

    def get_urls(self):
        urls = super().get_urls()
        opts = self.model._meta
        custom_urls = [
            path(
                "<path:object_id>/audit-report/",
                self.admin_site.admin_view(self.audit_report_view),
                name=f"{opts.app_label}_{opts.model_name}_audit_report",
            )
        ]
        return custom_urls + urls

    def change_view(self, request, object_id, form_url="", extra_context=None):
        extra_context = extra_context or {}
        extra_context["audit_report_url"] = self.get_audit_report_url(object_id)
        return super().change_view(
            request,
            object_id,
            form_url=form_url,
            extra_context=extra_context,
        )

    def audit_report_view(self, request, object_id):
        process = get_process_for_report(object_id)
        return render_process_report_response(
            [process],
            filename=f"process_audit_report_{process.pk}.pdf",
            content_disposition="attachment",
        )

    def get_audit_report_url(self, object_id):
        opts = self.model._meta
        return reverse(
            f"admin:{opts.app_label}_{opts.model_name}_audit_report",
            args=[object_id],
            current_app=self.admin_site.name,
        )

    @admin.display(description="Audit PDF")
    def download_audit_pdf(self, obj):
        return format_html(
            '<a class="button" href="{}">Download PDF</a>',
            self.get_audit_report_url(obj.pk),
        )

    def user(self, obj):
        return _get_user_by_id(obj.created_by)

    @admin.display(boolean=True)
    def success(self, obj):
        if obj.steps.filter(registrations__success=False).exists():
            return False
        return True


admin.site.register(ProcessAuditEvent, ProcessAuditEventModelAdmin)


class StepAuditEventModelAdmin(admin.ModelAdmin):
    list_display = ("id", "name", "success", "process", "user")
    list_filter = ("name",)
    search_fields = ("name",)

    def user(self, obj):
        return _get_user_by_id(obj.created_by)

    @admin.display(boolean=True)
    def success(self, obj):
        if obj.registrations.filter(success=True).count() == obj.total_registrations:
            return True
        return False


admin.site.register(StepAuditEvent, StepAuditEventModelAdmin)


class RegistrationAuditEventModelAdmin(admin.ModelAdmin):
    list_display = ("id", "name", "success", "step", "user")
    list_filter = ("success",)
    search_fields = ("message",)

    # @admin.display()
    # def step_name(self, obj):
    #     if obj.step is not None:
    #         return obj.step.name

    def user(self, obj):
        return _get_user_by_id(obj.created_by)


admin.site.register(RegistrationAuditEvent, RegistrationAuditEventModelAdmin)
