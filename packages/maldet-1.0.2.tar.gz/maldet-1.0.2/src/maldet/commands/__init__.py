"""maldet CLI subcommands."""
