#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author: qicongsheng
from setuptools import setup, find_packages

from forex_mcp import __version__

setup(
    name="forex-mcp",
    version=__version__,
    author="qicongsheng",
    author_email="qicongsheng@outlook.com",
    description="Forex MCP Server for MT5 market data via SSE",
    url="https://github.com/qicongsheng/forex-mcp",
    packages=find_packages(),
    install_requires=[
        "knify",
        "mcp[cli]"
    ],
    entry_points={
        "console_scripts": [
            "forex-mcp=forex_mcp.__main__:main"
        ]
    }
)
