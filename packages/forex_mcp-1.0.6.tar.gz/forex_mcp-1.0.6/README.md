# Forex MCP Server

A lightweight MCP (Model Context Protocol) server for forex market data, built on Python. Retrieves symbol lists and OHLC bar data from an MT5 API backend and exposes them as MCP tools via SSE transport.

## Features

- **get_symbols** — Get available forex symbol list
- **copy_rates_from** — Get N bars of OHLC data starting from a given date
- **copy_rates_range** — Get OHLC bars within a date range
- **get_all_bars** — Get all available OHLC bars for a symbol and timeframe

## Install

```bash
pip install -r requirements.txt
```

## Usage

### Start the server

```bash
python -m forex_mcp
```

Server listens on `http://127.0.0.1:3000`.

### MCP Client Configuration

Add to your MCP client config (e.g. Claude Desktop):

```json
{
  "mcpServers": {
    "forex": {
      "url": "http://127.0.0.1:3000/sse"
    }
  }
}
```

## Tools Reference

| Tool | Parameters | Description |
|------|-----------|-------------|
| `get_symbols` | none | Returns list of forex symbols with symbol_name, min_point, comment, status |
| `copy_rates_from` | symbol, time_frame, date_from, count | Returns N OHLC bars from a start date |
| `copy_rates_range` | symbol, time_frame, date_from, date_to | Returns OHLC bars within a date range |
| `get_all_bars` | symbol, time_frame | Returns all available OHLC bars |

**Timeframe options:** M1, M5, M15, M30, H1, H4, D1, W1, MN1

**Date format:** YYYYMMDDHHmmss (e.g. "20240101120000")
