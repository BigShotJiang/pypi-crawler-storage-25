#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author: qicongsheng
class Ohlc:
    def __init__(self):
        self.id = None
        self.symbol = None
        self.time_frame = None
        self.bar_time = None
        self.open = None
        self.high = None
        self.low = None
        self.close = None
        self.gmt_create = None
        self.gmt_modified = None


class Symbol:
    def __init__(self):
        self.id = None
        self.symbol_name = None
        self.min_point = None
        self.comment = None
        self.status = None
        self.gmt_create = None
        self.gmt_modified = None
