#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author: qicongsheng
import os

MT5_API_USER = os.environ.get('MT5_API_USER', 'admin')
MT5_API_PASSWD = os.environ.get('MT5_API_PASSWORD', 'password')
MT5_API_DOMAIN = os.environ.get('MT5_API_DOMAIN', 'http://127.0.0.1:8082')
MT5_API_COPY_RATES_RANGE_URL = '/copy_rates_range'
MT5_API_COPY_RATES_FROM_URL = '/copy_rates_from'
MT5_API_GET_SYMBOLS_URL = '/get_symbols'
MT5_API_GET_ALL_BARS_URL = '/get_all_bars'
