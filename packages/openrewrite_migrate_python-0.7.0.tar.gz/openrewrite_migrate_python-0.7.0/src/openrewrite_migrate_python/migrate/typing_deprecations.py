"""
Recipes for migrating deprecated typing module aliases to built-in generics.

PEP 585 (Python 3.9+) deprecated many typing module aliases in favor of
using built-in types directly as generics:

- typing.List[X] -> list[X]
- typing.Dict[K, V] -> dict[K, V]
- typing.Set[X] -> set[X]
- typing.FrozenSet[X] -> frozenset[X]
- typing.Tuple[X, ...] -> tuple[X, ...]
- typing.Type[X] -> type[X]

Additionally, typing.Text is deprecated (alias for str since Python 3.11).

See: https://peps.python.org/pep-0585/
"""

from typing import Any, Dict, List, Optional, cast

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.python.remove_import import RemoveImportOptions, maybe_remove_import
from rewrite.python.visitor import PythonVisitor
from rewrite.java.tree import Identifier, J

# Define category paths
_Python39 = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
    CategoryDescriptor(display_name="Python 3.9"),
]

_Python311 = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
    CategoryDescriptor(display_name="Python 3.11"),
]


# PEP 585 deprecated typing aliases -> built-in replacements
PEP585_DEPRECATIONS: Dict[str, str] = {
    "List": "list",
    "Dict": "dict",
    "Set": "set",
    "FrozenSet": "frozenset",
    "Tuple": "tuple",
    "Type": "type",
}


def _make_pep585_editor(old_name: str, new_name: str) -> "TreeVisitor[Any, ExecutionContext]":
    """Create a visitor that renames a typing alias to its built-in equivalent.

    The visitor:
    1. Checks whether ``from typing import <old_name>`` is present. If not,
       returns the compilation unit unchanged (fast-path).
    2. Renames every occurrence of the identifier outside of import statements.
    3. Removes the ``<old_name>`` entry from the ``from typing import …``
       statement (deleting the whole statement when it becomes empty).
    """
    from rewrite.python.tree import CompilationUnit, MultiImport
    from rewrite.java.support_types import JContainer
    from rewrite.java.tree import FieldAccess, Space

    class Pep585Visitor(PythonVisitor[ExecutionContext]):
        def __init__(self) -> None:
            super().__init__()
            self._has_import: bool = False

        # ------------------------------------------------------------------
        # Helpers
        # ------------------------------------------------------------------

        @staticmethod
        def _get_qualid_name(node: Any) -> str:
            """Get string representation of a qualified name (FieldAccess or Identifier)."""
            if isinstance(node, Identifier):
                return node.simple_name
            if isinstance(node, FieldAccess):
                target = Pep585Visitor._get_qualid_name(node.target)
                name = node.name.simple_name
                return f"{target}.{name}" if target else name
            # Empty or unknown
            return ""

        @staticmethod
        def _import_names(multi: MultiImport) -> list:
            """Return the list of name strings imported by a MultiImport."""
            return [
                Pep585Visitor._get_qualid_name(imp.qualid)
                for imp in multi.names
            ]

        @staticmethod
        def _is_typing_import(multi: MultiImport) -> bool:
            return (
                multi.from_ is not None
                and Pep585Visitor._get_qualid_name(multi.from_) == "typing"
            )

        # ------------------------------------------------------------------
        # Pre-scan: detect whether the import is present
        # ------------------------------------------------------------------

        def visit_compilation_unit(
            self, cu: CompilationUnit, p: ExecutionContext
        ) -> CompilationUnit:
            self._has_import = any(
                self._is_typing_import(stmt) and old_name in self._import_names(stmt)
                for stmt in cu.statements
                if isinstance(stmt, MultiImport)
            )
            if not self._has_import:
                return cu

            result = cast(CompilationUnit, super().visit_compilation_unit(cu, p))

            # After import removal, the first remaining statement may have an
            # unwanted leading newline in its prefix (the newline that
            # previously separated it from the removed import).  Strip it.
            from rewrite.java.support_types import JRightPadded

            padded_stmts = list(result.padding.statements)
            if padded_stmts:
                first_padded = padded_stmts[0]
                first_stmt = first_padded.element
                prefix = first_stmt.prefix
                if prefix.whitespace and prefix.whitespace.startswith('\n'):
                    new_ws = prefix.whitespace[1:]
                    new_prefix = prefix.replace(_whitespace=new_ws)
                    padded_stmts[0] = JRightPadded(
                        first_stmt.replace(prefix=new_prefix),
                        first_padded.after,
                        first_padded.markers,
                    )
                    result = result.padding.replace(_statements=padded_stmts)

            return result

        # ------------------------------------------------------------------
        # Import removal
        # ------------------------------------------------------------------

        def visit_multi_import(  # type: ignore[override]
            self, multi: MultiImport, p: ExecutionContext
        ) -> Optional[J]:
            if not self._has_import:
                return multi
            if not self._is_typing_import(multi):
                return multi
            if old_name not in self._import_names(multi):
                return multi

            # Remove old_name from the import list
            existing_padded = multi.padding.names.padding.elements
            new_padded = [
                ep for ep in existing_padded
                if self._get_qualid_name(ep.element.qualid) != old_name
            ]

            if len(new_padded) == 0:
                # All names removed — delete the statement
                return None

            # Fix prefix on the first remaining element
            if new_padded:
                first = new_padded[0]
                if first.element.prefix != Space.EMPTY:
                    new_padded[0] = first.replace(
                        _element=first.element.replace(prefix=Space.EMPTY)
                    )

            return multi.padding.replace(
                _names=JContainer(
                    multi.padding.names.before,
                    new_padded,
                    multi.padding.names.markers,
                )
            )

        # ------------------------------------------------------------------
        # Identifier renaming (outside imports)
        # ------------------------------------------------------------------

        def visit_identifier(
            self, ident: Identifier, p: ExecutionContext
        ) -> Identifier:
            ident = cast(Identifier, super().visit_identifier(ident, p))

            if ident.simple_name != old_name:
                return ident

            # Skip identifiers that are part of import statements
            if self.cursor.first_enclosing(MultiImport) is not None:
                return ident

            return ident.replace(_simple_name=new_name)

    return Pep585Visitor()


@categorize(_Python39)
class ReplaceTypingListWithList(Recipe):
    """
    Find and migrate `typing.List` to built-in `list`.

    PEP 585 deprecated `typing.List` in Python 3.9. The built-in `list` type
    can now be used directly as a generic type.

    Example:
        Before:
            from typing import List
            items: List[str] = []

        After:
            items: list[str] = []
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.ReplaceTypingListWithList"

    @property
    def display_name(self) -> str:
        return "Replace `typing.List` with `list`"

    @property
    def description(self) -> str:
        return (
            "PEP 585 deprecated `typing.List` in Python 3.9. "
            "Replace with the built-in `list` type for generic annotations."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        return _make_pep585_editor("List", "list")


@categorize(_Python39)
class ReplaceTypingDictWithDict(Recipe):
    """
    Find and migrate `typing.Dict` to built-in `dict`.

    PEP 585 deprecated `typing.Dict` in Python 3.9. The built-in `dict` type
    can now be used directly as a generic type.

    Example:
        Before:
            from typing import Dict
            mapping: Dict[str, int] = {}

        After:
            mapping: dict[str, int] = {}
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.ReplaceTypingDictWithDict"

    @property
    def display_name(self) -> str:
        return "Replace `typing.Dict` with `dict`"

    @property
    def description(self) -> str:
        return (
            "PEP 585 deprecated `typing.Dict` in Python 3.9. "
            "Replace with the built-in `dict` type for generic annotations."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        return _make_pep585_editor("Dict", "dict")


@categorize(_Python39)
class ReplaceTypingSetWithSet(Recipe):
    """
    Find and migrate `typing.Set` to built-in `set`.

    PEP 585 deprecated `typing.Set` in Python 3.9. The built-in `set` type
    can now be used directly as a generic type.

    Example:
        Before:
            from typing import Set
            items: Set[int] = set()

        After:
            items: set[int] = set()
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.ReplaceTypingSetWithSet"

    @property
    def display_name(self) -> str:
        return "Replace `typing.Set` with `set`"

    @property
    def description(self) -> str:
        return (
            "PEP 585 deprecated `typing.Set` in Python 3.9. "
            "Replace with the built-in `set` type for generic annotations."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        return _make_pep585_editor("Set", "set")


@categorize(_Python39)
class ReplaceTypingTupleWithTuple(Recipe):
    """
    Find and migrate `typing.Tuple` to built-in `tuple`.

    PEP 585 deprecated `typing.Tuple` in Python 3.9. The built-in `tuple` type
    can now be used directly as a generic type.

    Example:
        Before:
            from typing import Tuple
            point: Tuple[int, int] = (0, 0)

        After:
            point: tuple[int, int] = (0, 0)
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.ReplaceTypingTupleWithTuple"

    @property
    def display_name(self) -> str:
        return "Replace `typing.Tuple` with `tuple`"

    @property
    def description(self) -> str:
        return (
            "PEP 585 deprecated `typing.Tuple` in Python 3.9. "
            "Replace with the built-in `tuple` type for generic annotations."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        return _make_pep585_editor("Tuple", "tuple")


@categorize(_Python311)
class ReplaceTypingText(Recipe):
    """
    Find and migrate `typing.Text` to `str`.

    `typing.Text` was an alias for `str` provided for Python 2/3 compatibility.
    It is deprecated as of Python 3.11 since Python 2 is no longer supported.

    Example:
        Before:
            from typing import Text
            name: Text = "hello"

        After:
            name: str = "hello"
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.ReplaceTypingText"

    @property
    def display_name(self) -> str:
        return "Replace `typing.Text` with `str`"

    @property
    def description(self) -> str:
        return (
            "`typing.Text` is deprecated as of Python 3.11. "
            "It was an alias for `str` for Python 2/3 compatibility. Replace with `str`."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        from rewrite.python.tree import MultiImport

        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_identifier(
                self, ident: Identifier, p: ExecutionContext
            ) -> Identifier:
                ident = cast(Identifier, super().visit_identifier(ident, p))

                if ident.simple_name != "Text":
                    return ident

                # Skip identifiers inside import statements
                if self.cursor.first_enclosing(MultiImport) is not None:
                    return ident

                # Type attribution correctly resolves typing.Text to str
                # (since Text is just an alias), so we can't use field_type to
                # confirm the import origin. Instead we rely on the name check
                # and the import-context guard above.
                maybe_remove_import(
                    self, RemoveImportOptions(module="typing", name="Text")
                )
                return ident.replace(_simple_name="str")

        return Visitor()
