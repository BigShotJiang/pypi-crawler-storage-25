"""
Recipes for migrating deprecated pkgutil module functions.

Several pkgutil functions were deprecated in Python 3.12:

- pkgutil.find_loader() -> importlib.util.find_spec()
- pkgutil.get_loader() -> importlib.util.find_spec()

See: https://docs.python.org/3/library/pkgutil.html
"""

from typing import Any, Optional, cast

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.python.visitor import PythonVisitor
from rewrite.python.template import pattern, template, capture
from rewrite.python.add_import import AddImportOptions, maybe_add_import
from rewrite.python.remove_import import RemoveImportOptions, maybe_remove_import
from rewrite.java.tree import J, MethodInvocation

# Define category path: Python > Migrate > Python 3.12
_Python312 = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
    CategoryDescriptor(display_name="Python 3.12"),
]

# Pattern/template pairs
_mod = capture('mod')
_find_loader_pattern = pattern("pkgutil.find_loader({mod})", mod=_mod)
_get_loader_pattern = pattern("pkgutil.get_loader({mod})", mod=_mod)
_find_spec_template = template("importlib.util.find_spec({mod})", mod=_mod)


@categorize(_Python312)
class ReplacePkgutilFindLoader(Recipe):
    """
    Replace `pkgutil.find_loader()` with `importlib.util.find_spec()`.

    The `pkgutil.find_loader()` function was deprecated in Python 3.12.
    The recommended replacement is `importlib.util.find_spec()`.

    Note: The return types differ - `find_loader()` returns a loader while
    `find_spec()` returns a ModuleSpec. Code may need additional changes.

    Example:
        Before:
            import pkgutil
            loader = pkgutil.find_loader('mymodule')

        After:
            import importlib.util
            spec = importlib.util.find_spec('mymodule')
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.ReplacePkgutilFindLoader"

    @property
    def display_name(self) -> str:
        return "Replace `pkgutil.find_loader()` with `importlib.util.find_spec()`"

    @property
    def description(self) -> str:
        return (
            "The `pkgutil.find_loader()` function was deprecated in Python 3.12. "
            "Replace with `importlib.util.find_spec()`. Note: returns ModuleSpec, use .loader for loader."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(  # type: ignore[override]
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[J]:
                m = cast(MethodInvocation, super().visit_method_invocation(method, p))
                match = _find_loader_pattern.match(m, self.cursor)
                if match:
                    maybe_add_import(
                        self,
                        AddImportOptions(module="importlib.util", only_if_referenced=False),
                    )
                    maybe_remove_import(self, RemoveImportOptions(module="pkgutil"))
                    return _find_spec_template.apply(self.cursor, values=match)
                return m

        return Visitor()


@categorize(_Python312)
class ReplacePkgutilGetLoader(Recipe):
    """
    Replace `pkgutil.get_loader()` with `importlib.util.find_spec()`.

    The `pkgutil.get_loader()` function was deprecated in Python 3.12.
    The recommended replacement is `importlib.util.find_spec()`.

    Example:
        Before:
            import pkgutil
            loader = pkgutil.get_loader('mymodule')

        After:
            import importlib.util
            spec = importlib.util.find_spec('mymodule')
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.ReplacePkgutilGetLoader"

    @property
    def display_name(self) -> str:
        return "Replace `pkgutil.get_loader()` with `importlib.util.find_spec()`"

    @property
    def description(self) -> str:
        return (
            "The `pkgutil.get_loader()` function was deprecated in Python 3.12. "
            "Replace with `importlib.util.find_spec()`. Note: returns ModuleSpec, use .loader for loader."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(  # type: ignore[override]
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[J]:
                m = cast(MethodInvocation, super().visit_method_invocation(method, p))
                match = _get_loader_pattern.match(m, self.cursor)
                if match:
                    maybe_add_import(
                        self,
                        AddImportOptions(module="importlib.util", only_if_referenced=False),
                    )
                    maybe_remove_import(self, RemoveImportOptions(module="pkgutil"))
                    return _find_spec_template.apply(self.cursor, values=match)
                return m

        return Visitor()
