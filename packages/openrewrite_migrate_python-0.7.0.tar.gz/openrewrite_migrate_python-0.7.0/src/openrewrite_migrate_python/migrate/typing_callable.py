"""
Recipe for migrating typing.Callable to collections.abc.Callable.

PEP 585 (Python 3.9+) deprecated typing.Callable in favor of
collections.abc.Callable:

- typing.Callable[[int], str] -> collections.abc.Callable[[int], str]

See: https://peps.python.org/pep-0585/
"""

from typing import List

from rewrite import Recipe
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.python.recipes import ChangeImport

# Define category path
_Python39 = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
    CategoryDescriptor(display_name="Python 3.9"),
]


@categorize(_Python39)
class ReplaceTypingCallableWithCollectionsAbcCallable(Recipe):
    """
    Replace `typing.Callable` with `collections.abc.Callable`.

    PEP 585 deprecated `typing.Callable` in Python 3.9. Use
    `collections.abc.Callable` instead for type annotations.

    Example:
        Before:
            from typing import Callable
            handler: Callable[[int], str] = lambda x: str(x)

        After:
            from collections.abc import Callable
            handler: Callable[[int], str] = lambda x: str(x)
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.ReplaceTypingCallableWithCollectionsAbcCallable"

    @property
    def display_name(self) -> str:
        return "Replace `typing.Callable` with `collections.abc.Callable`"

    @property
    def description(self) -> str:
        return (
            "PEP 585 deprecated `typing.Callable` in Python 3.9. "
            "Replace with `collections.abc.Callable` for type annotations."
        )

    def recipe_list(self) -> List[Recipe]:
        return [ChangeImport(old_module="typing", old_name="Callable", new_module="collections.abc")]
