"""
Recipe for replacing deprecated sys.last_type/last_value/last_traceback
with sys.last_exc equivalents.

sys.last_type, sys.last_value, and sys.last_traceback were deprecated in
Python 3.12 in favor of sys.last_exc:

- sys.last_value     -> sys.last_exc
- sys.last_type      -> type(sys.last_exc)
- sys.last_traceback -> sys.last_exc.__traceback__

See: https://docs.python.org/3/whatsnew/3.12.html#deprecated
"""

from typing import Any, List, Optional, cast

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.python.visitor import PythonVisitor
from rewrite.python.template import pattern, template
from rewrite.java.tree import FieldAccess, J

# Define category path: Python > Migrate > Python 3.12
_Python312 = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
    CategoryDescriptor(display_name="Python 3.12"),
]

_last_value_pattern = pattern("sys.last_value")
_last_type_pattern = pattern("sys.last_type")
_last_traceback_pattern = pattern("sys.last_traceback")

_last_exc_template = template("sys.last_exc")
_type_last_exc_template = template("type(sys.last_exc)")
_last_exc_traceback_template = template("sys.last_exc.__traceback__")


@categorize(_Python312)
class ReplaceSysLastExcInfo(Recipe):
    """
    Replace `sys.last_type`, `sys.last_value`, and `sys.last_traceback` with
    their `sys.last_exc`-based equivalents.

    These attributes were deprecated in Python 3.12 in favor of `sys.last_exc`
    which provides the exception object directly.

    Example:
        Before:
            import sys
            exc_type = sys.last_type
            exc_value = sys.last_value
            exc_tb = sys.last_traceback

        After:
            import sys
            exc_type = type(sys.last_exc)
            exc_value = sys.last_exc
            exc_tb = sys.last_exc.__traceback__
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.ReplaceSysLastExcInfo"

    @property
    def display_name(self) -> str:
        return "Replace `sys.last_type` / `sys.last_value` / `sys.last_traceback` with `sys.last_exc`"

    @property
    def description(self) -> str:
        return (
            "`sys.last_type`, `sys.last_value`, and `sys.last_traceback` were "
            "deprecated in Python 3.12. Replace them with their `sys.last_exc`-"
            "based equivalents: `type(sys.last_exc)`, `sys.last_exc`, and "
            "`sys.last_exc.__traceback__` respectively."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.12", "sys"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_field_access(  # type: ignore[override]
                self, field_access: FieldAccess, p: ExecutionContext
            ) -> Optional[J]:
                fa = cast(FieldAccess, super().visit_field_access(field_access, p))
                if _last_value_pattern.matches(fa, self.cursor):
                    return _last_exc_template.apply(self.cursor)
                if _last_type_pattern.matches(fa, self.cursor):
                    return _type_last_exc_template.apply(self.cursor)
                if _last_traceback_pattern.matches(fa, self.cursor):
                    return _last_exc_traceback_template.apply(self.cursor)
                return fa

        return Visitor()
