"""
Structural equality comparison for LST nodes.

Compares two tree nodes by printing them with normalized whitespace
and checking that the printed representations match. This provides
the same functionality as ``SemanticallyEqual`` from the Java SDK.
"""

from rewrite.java.support_types import Space
from rewrite.python.printer import PythonPrinter

_printer = PythonPrinter()


class SemanticallyEqual:
    """Compare two LST nodes for structural equality."""

    @staticmethod
    def are_equal(a, b) -> bool:
        """Return True if *a* and *b* are semantically equal.

        Both nodes are printed after stripping their leading prefix so
        that insignificant whitespace differences are ignored.
        """
        if a is None and b is None:
            return True
        if a is None or b is None:
            return False
        return (
            _printer.print(a.replace(_prefix=Space.EMPTY))
            == _printer.print(b.replace(_prefix=Space.EMPTY))
        )
