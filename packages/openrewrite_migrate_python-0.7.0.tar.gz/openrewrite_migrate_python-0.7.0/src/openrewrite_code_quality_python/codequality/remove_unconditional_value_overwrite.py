"""
Recipe to remove unconditional overwrites of dict/object values.

When two consecutive statements assign to the same dict key or object
attribute, the first assignment is dead code -- its value is
immediately overwritten without ever being read.  Removing it
eliminates noise and prevents confusion about the author's intent.

See: https://rules.sonarsource.com/python/RSPEC-S4143/
"""

from typing import Any, List, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.python.visitor import PythonVisitor
from rewrite.python.tree import ExpressionStatement
from rewrite.java.support_types import Space
from rewrite.java.tree import (
    ArrayAccess,
    Assignment,
    Block,
    Expression,
    FieldAccess,
    Identifier,
    Statement,
)
from openrewrite_code_quality_python.codequality._semantically_equal import SemanticallyEqual

_CodeQuality = [
    *Python,
    CategoryDescriptor(display_name="Code quality"),
]


def _get_assignment(stmt: Statement) -> Optional[Assignment]:
    """Extract an Assignment from a statement, if present."""
    if isinstance(stmt, ExpressionStatement):
        expr = stmt.expression
        if isinstance(expr, Assignment):
            return expr
    if isinstance(stmt, Assignment):
        return stmt
    return None


def _is_subscript_assign(assign: Assignment) -> bool:
    """Return True if the assignment target is a subscript (d[key])."""
    return isinstance(assign.variable, ArrayAccess)


def _is_attribute_assign(assign: Assignment) -> bool:
    """Return True if the assignment target is an attribute (obj.x)."""
    return isinstance(assign.variable, FieldAccess)


def _same_subscript_target(a: Assignment, b: Assignment) -> bool:
    """Return True if both assign to the same dict with the same key."""
    va = a.variable
    vb = b.variable
    if not (isinstance(va, ArrayAccess) and isinstance(vb, ArrayAccess)):
        return False
    # Compare the receiver (dict) and the key
    return (
        SemanticallyEqual.are_equal(va.indexed, vb.indexed)
        and SemanticallyEqual.are_equal(va.dimension.index, vb.dimension.index)
    )


def _same_attribute_target(a: Assignment, b: Assignment) -> bool:
    """Return True if both assign to the same attribute (obj.x)."""
    va = a.variable
    vb = b.variable
    if not (isinstance(va, FieldAccess) and isinstance(vb, FieldAccess)):
        return False
    return (
        va.name.simple_name == vb.name.simple_name
        and SemanticallyEqual.are_equal(va.target, vb.target)
    )


def _is_duplicate_write(a: Assignment, b: Assignment) -> bool:
    """Return True if a and b write to the same target."""
    if _is_subscript_assign(a) and _is_subscript_assign(b):
        return _same_subscript_target(a, b)
    if _is_attribute_assign(a) and _is_attribute_assign(b):
        return _same_attribute_target(a, b)
    return False


@categorize(_CodeQuality)
class RemoveUnconditionalValueOverwrite(Recipe):
    """
    Remove consecutive assignments that write to the same dict key or
    object attribute.

    When a value written to a collection entry or attribute is
    immediately overwritten in the very next statement, the first
    write is dead code.  Removing it keeps the code focused on the
    value that actually persists.

    Example:
        Before:
            d["key"] = 1
            d["key"] = 2

        After:
            d["key"] = 2
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.codequality.RemoveUnconditionalValueOverwrite"

    @property
    def display_name(self) -> str:
        return "Remove unconditional value overwrites"

    @property
    def description(self) -> str:
        return (
            "Remove consecutive assignments that write to the same dict key "
            "or object attribute, since the first value is immediately "
            "overwritten and never used."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "code-quality", "RSPEC-S4143"]

    @property
    def estimated_effort_per_occurrence(self) -> int:
        return 5

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_compilation_unit(self, cu, p):
                cu = super().visit_compilation_unit(cu, p)
                new_stmts = _remove_overwrites_padded(cu._statements)
                if new_stmts is not None:
                    return cu.replace(_statements=new_stmts)
                return cu

            def visit_block(
                self, block: Block, p: ExecutionContext
            ) -> Optional[Block]:
                block = super().visit_block(block, p)

                if not isinstance(block, Block):
                    return block

                new_stmts = _remove_overwrites_padded(block._statements)
                if new_stmts is not None:
                    return block.replace(_statements=new_stmts)
                return block

        return Visitor()


def _remove_overwrites_padded(padded_stmts) -> Optional[list]:
    """Return a filtered padded list with dead writes removed, or None if unchanged."""
    if len(padded_stmts) < 2:
        return None

    stmts = [rp.element for rp in padded_stmts]
    to_remove: set[int] = set()
    for i in range(len(stmts) - 1):
        if i in to_remove:
            continue
        a_assign = _get_assignment(stmts[i])
        if a_assign is None:
            continue
        if not (_is_subscript_assign(a_assign) or _is_attribute_assign(a_assign)):
            continue

        b_assign = _get_assignment(stmts[i + 1])
        if b_assign is None:
            continue

        if _is_duplicate_write(a_assign, b_assign):
            to_remove.add(i)

    if not to_remove:
        return None

    result = [
        rp for idx, rp in enumerate(padded_stmts)
        if idx not in to_remove
    ]

    # If we removed the first statement(s), strip the leading newline
    # from the new first statement's prefix to avoid a blank line.
    if result and 0 in to_remove:
        first_rp = result[0]
        first = first_rp.element
        ws = first.prefix.whitespace
        if ws.startswith("\n"):
            ws = ws[1:]
            new_first = first.replace(_prefix=Space(
                _comments=first.prefix.comments,
                _whitespace=ws,
            ))
            result[0] = first_rp.replace(_element=new_first)

    return result
