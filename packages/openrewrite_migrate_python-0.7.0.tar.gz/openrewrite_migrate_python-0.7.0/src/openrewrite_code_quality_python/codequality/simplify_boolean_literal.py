"""
Recipe to simplify boolean comparisons against literal True/False.

Comparisons like ``x == True`` or ``x is False`` can be replaced with
simpler boolean expressions. This improves readability and follows
idiomatic Python style.

See: https://rules.sonarsource.com/python/RSPEC-1125/
"""

from typing import Any, List, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.markers import Markers
from rewrite.python.visitor import PythonVisitor
from rewrite.java.support_types import JLeftPadded, Space
from rewrite.java.tree import Binary as JBinary, Expression, Literal, Unary
from rewrite.python.tree import Binary as PyBinary
from rewrite.utils import random_id

_CodeQuality = [
    *Python,
    CategoryDescriptor(display_name="Code quality"),
]


def _is_bool_literal(expr: Expression) -> Optional[bool]:
    """Return the boolean value if expr is a True/False literal, else None."""
    if isinstance(expr, Literal) and isinstance(expr.value, bool):
        return expr.value
    return None


def _negate(expr: Expression, prefix: Space) -> Unary:
    """Wrap an expression in ``not ...``."""
    return Unary(
        _id=random_id(),
        _prefix=prefix,
        _markers=Markers.EMPTY,
        _operator=JLeftPadded(
            _before=Space.EMPTY,
            _element=Unary.Type.Not,
            _markers=Markers.EMPTY,
        ),
        _expression=expr.replace(_prefix=Space.SINGLE_SPACE),
        _type=None,
    )


@categorize(_CodeQuality)
class SimplifyBooleanLiteral(Recipe):
    """
    Simplify comparisons against boolean literals ``True`` and ``False``.

    Explicit comparisons to boolean constants add unnecessary verbosity
    without improving clarity. Idiomatic Python uses the boolean value
    directly or applies ``not`` to invert it.

    Example:
        Before:
            if x == True:
                pass

        After:
            if x:
                pass
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.codequality.SimplifyBooleanLiteral"

    @property
    def display_name(self) -> str:
        return "Simplify boolean literal comparisons"

    @property
    def description(self) -> str:
        return (
            "Replace comparisons against boolean literals (`== True`, `!= False`, "
            "`is True`, etc.) with the simpler equivalent boolean expression."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "code-quality", "RSPEC-S1125"]

    @property
    def estimated_effort_per_occurrence(self) -> int:
        return 2

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_binary(
                self, binary: JBinary, p: ExecutionContext
            ) -> Optional[Expression]:
                binary = super().visit_binary(binary, p)

                if not isinstance(binary, JBinary):
                    return binary

                op = binary.operator
                if op not in (JBinary.Type.Equal, JBinary.Type.NotEqual):
                    return binary

                return _simplify_comparison(
                    binary.left, binary.right, op == JBinary.Type.Equal, binary.prefix
                ) or binary

            def visit_python_binary(
                self, binary: PyBinary, p: ExecutionContext
            ) -> Optional[Expression]:
                binary = super().visit_python_binary(binary, p)

                if not isinstance(binary, PyBinary):
                    return binary

                op = binary.operator
                if op not in (PyBinary.Type.Is, PyBinary.Type.IsNot):
                    return binary

                return _simplify_comparison(
                    binary.left, binary.right, op == PyBinary.Type.Is, binary.prefix
                ) or binary

        return Visitor()


def _simplify_comparison(
    left: Expression,
    right: Expression,
    is_equality: bool,
    prefix: Space,
) -> Optional[Expression]:
    """Simplify a comparison against a boolean literal.

    Args:
        left: Left-hand side of the comparison.
        right: Right-hand side of the comparison.
        is_equality: True for == / is, False for != / is not.
        prefix: Whitespace prefix of the original binary expression.

    Returns:
        The simplified expression, or None if no simplification applies.
    """
    bool_val = _is_bool_literal(right)
    other = left
    if bool_val is None:
        bool_val = _is_bool_literal(left)
        other = right
    if bool_val is None:
        return None

    # Determine whether the result should be negated.
    # == True  / is True  -> x        (identity)
    # == False / is False -> not x     (negate)
    # != True  / is not True  -> not x (negate)
    # != False / is not False -> x     (identity)
    needs_negation = bool_val != is_equality

    if needs_negation:
        return _negate(other, prefix)
    else:
        return other.replace(_prefix=prefix)
