"""
Recipe to simplify redundant logical expressions.

Expressions like ``x and x`` or ``x or x`` always evaluate to ``x``,
so the duplication adds visual noise without changing behavior.
Removing the redundant operand makes the intent clearer.

Only targets ``and``/``or`` operators. Arithmetic and comparison
operators are left alone because they may have meaningful
side-effects or distinct semantics (e.g. ``n + n`` is ``2 * n``).

See: https://rules.sonarsource.com/python/RSPEC-S1764/
"""

from typing import Any, List, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.python.visitor import PythonVisitor
from rewrite.java.tree import Binary as JBinary, Expression
from openrewrite_code_quality_python.codequality._semantically_equal import SemanticallyEqual

_CodeQuality = [
    *Python,
    CategoryDescriptor(display_name="Code quality"),
]


@categorize(_CodeQuality)
class SimplifyRedundantLogicalExpression(Recipe):
    """
    Simplify logical expressions where both operands are identical.

    When the same expression appears on both sides of ``and`` or ``or``,
    the result is always equal to that expression. The redundant operand
    can be removed to reduce clutter and prevent readers from wondering
    whether a typo is hiding a real bug.

    Example:
        Before:
            if x and x:
                pass

        After:
            if x:
                pass
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.codequality.SimplifyRedundantLogicalExpression"

    @property
    def display_name(self) -> str:
        return "Simplify redundant logical expressions"

    @property
    def description(self) -> str:
        return (
            "Replace `x and x` with `x` and `x or x` with `x`. "
            "Identical operands in a logical expression are redundant "
            "and often indicate a copy-paste mistake."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "code-quality", "RSPEC-S1764"]

    @property
    def estimated_effort_per_occurrence(self) -> int:
        return 2

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_binary(
                self, binary: JBinary, p: ExecutionContext
            ) -> Optional[Expression]:
                binary = super().visit_binary(binary, p)

                if not isinstance(binary, JBinary):
                    return binary

                if binary.operator not in (JBinary.Type.And, JBinary.Type.Or):
                    return binary

                if SemanticallyEqual.are_equal(binary.left, binary.right):
                    return binary.left.replace(_prefix=binary.prefix)

                return binary

        return Visitor()
