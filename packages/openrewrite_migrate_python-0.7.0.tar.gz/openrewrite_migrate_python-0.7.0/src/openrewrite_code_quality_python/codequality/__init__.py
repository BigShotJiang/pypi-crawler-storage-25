"""Python code quality recipes."""

from .all_branches_identical import AllBranchesIdentical
from .boolean_checks_not_inverted import BooleanChecksNotInverted
from .collapsible_if_statements import CollapsibleIfStatements
from .merge_identical_branches import MergeIdenticalBranches
from .remove_duplicate_conditions import RemoveDuplicateConditions
from .remove_self_assignment import RemoveSelfAssignment
from .remove_unconditional_value_overwrite import RemoveUnconditionalValueOverwrite
from .simplify_boolean_literal import SimplifyBooleanLiteral
from .simplify_redundant_logical_expression import SimplifyRedundantLogicalExpression

__all__ = [
    "AllBranchesIdentical",
    "BooleanChecksNotInverted",
    "CollapsibleIfStatements",
    "MergeIdenticalBranches",
    "RemoveDuplicateConditions",
    "RemoveSelfAssignment",
    "RemoveUnconditionalValueOverwrite",
    "SimplifyBooleanLiteral",
    "SimplifyRedundantLogicalExpression",
]
