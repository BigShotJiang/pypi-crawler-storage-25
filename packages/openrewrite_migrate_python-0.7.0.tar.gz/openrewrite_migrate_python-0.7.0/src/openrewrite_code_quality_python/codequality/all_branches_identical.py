"""
Recipe to replace if/elif/else chains where every branch has the same body.

When all branches of a conditional execute identical code the condition
is meaningless.  The entire ``if``/``elif``/``else`` chain can be
replaced with a single copy of the body, removing unnecessary
complexity and making it obvious that the code always runs.

See: https://rules.sonarsource.com/python/RSPEC-S3923/
"""

from typing import Any, List, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.python.visitor import PythonVisitor
from rewrite.java.support_types import Space
from rewrite.java.tree import (
    Block,
    If,
    Statement,
)
from openrewrite_code_quality_python.codequality._semantically_equal import SemanticallyEqual

_CodeQuality = [
    *Python,
    CategoryDescriptor(display_name="Code quality"),
]


def _has_explicit_else(if_: If) -> bool:
    """Return True if the chain ends with a plain ``else`` (not elif)."""
    current = if_
    while True:
        else_part = current.else_part
        if else_part is None:
            return False
        branch = else_part.body
        if isinstance(branch, If):
            current = branch
        else:
            # Reached a plain else block
            return True


def _collect_bodies(if_: If) -> list[Statement]:
    """Collect the then-part of every branch including the final else."""
    bodies: list[Statement] = [if_.then_part]
    current = if_
    while True:
        else_part = current.else_part
        if else_part is None:
            break
        branch = else_part.body
        if isinstance(branch, If):
            bodies.append(branch.then_part)
            current = branch
        else:
            # Plain else body
            bodies.append(branch)
            break
    return bodies


def _all_bodies_equal(bodies: list[Statement]) -> bool:
    """Return True when every body is semantically equal to the first."""
    if len(bodies) < 2:
        return False
    first = bodies[0]
    return all(
        SemanticallyEqual.are_equal(first, body)
        for body in bodies[1:]
    )


@categorize(_CodeQuality)
class AllBranchesIdentical(Recipe):
    """
    Replace ``if``/``elif``/``else`` chains where every branch has
    the same body with just the body.

    When every branch of a conditional executes identical code, the
    condition serves no purpose.  Removing it makes the code shorter
    and eliminates a source of confusion for future readers.

    Only applies when the chain has an explicit ``else`` so that the
    branches truly cover all cases.

    Example:
        Before:
            if cond:
                x()
            else:
                x()

        After:
            x()
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.codequality.AllBranchesIdentical"

    @property
    def display_name(self) -> str:
        return "Remove conditional with identical branches"

    @property
    def description(self) -> str:
        return (
            "Replace `if`/`elif`/`else` chains where every branch has "
            "the same body with just the body, since the condition has "
            "no effect on what code executes."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "code-quality", "RSPEC-S3923"]

    @property
    def estimated_effort_per_occurrence(self) -> int:
        return 5

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_compilation_unit(self, cu, p):
                cu = super().visit_compilation_unit(cu, p)
                new_stmts = _replace_identical_ifs_padded(cu._statements)
                if new_stmts is not None:
                    return cu.replace(_statements=new_stmts)
                return cu

            def visit_block(
                self, block: Block, p: ExecutionContext
            ) -> Optional[Block]:
                block = super().visit_block(block, p)
                if not isinstance(block, Block):
                    return block
                new_stmts = _replace_identical_ifs_padded(block._statements)
                if new_stmts is not None:
                    return block.replace(_statements=new_stmts)
                return block

        return Visitor()


def _replace_identical_ifs_padded(padded_stmts) -> Optional[list]:
    """Replace if/elif/else with identical branches with just the body.

    Works on a list of JRightPadded[Statement] and returns a new padded list,
    or None if nothing changed.
    """
    from rewrite.java.support_types import JRightPadded
    from rewrite.markers import Markers

    result = []
    changed = False
    for rp in padded_stmts:
        s = rp.element
        if not isinstance(s, If):
            result.append(rp)
            continue
        if not _has_explicit_else(s):
            result.append(rp)
            continue
        bodies = _collect_bodies(s)
        if not _all_bodies_equal(bodies):
            result.append(rp)
            continue

        # Extract the body statements from the then_part Block.
        body = s.then_part
        if isinstance(body, Block) and body._statements:
            first = True
            for body_rp in body._statements:
                bs = body_rp.element
                if first:
                    # First body statement gets the if statement's prefix
                    new_elem = bs.replace(_prefix=s.prefix)
                    result.append(rp.replace(_element=new_elem))
                    first = False
                else:
                    # Subsequent body statements keep their whitespace
                    # but with one indent level removed
                    ws = bs.prefix.whitespace
                    if_ws = s.prefix.whitespace
                    base = if_ws.split("\n")[-1] if "\n" in if_ws else if_ws
                    body_indent = ws.split("\n")[-1] if "\n" in ws else ws
                    if len(body_indent) > len(base):
                        new_ws = ws.replace(body_indent, base, 1)
                    else:
                        new_ws = ws
                    new_elem = bs.replace(_prefix=Space(
                        _comments=bs.prefix.comments,
                        _whitespace=new_ws,
                    ))
                    result.append(body_rp.replace(_element=new_elem))
            changed = True
        else:
            result.append(rp)

    if not changed:
        return None
    return result
