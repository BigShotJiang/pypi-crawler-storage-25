"""
Recipe to remove duplicate conditions in if/elif chains.

When the same condition appears more than once in an ``if``/``elif``
chain, the second branch is dead code--it can never execute because
the first matching branch already handled that case. Removing the
dead branch eliminates confusion and potential maintenance hazards.

See: https://rules.sonarsource.com/python/RSPEC-S1862/
"""

from typing import Any, List, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.python.visitor import PythonVisitor
from rewrite.java.tree import If, Expression
from openrewrite_code_quality_python.codequality._semantically_equal import SemanticallyEqual

_CodeQuality = [
    *Python,
    CategoryDescriptor(display_name="Code quality"),
]


def _collect_conditions(if_: If) -> list[Expression]:
    """Walk an if/elif chain and return all conditions in order."""
    conditions: list[Expression] = [if_.if_condition.tree]
    else_part = if_.else_part
    while else_part is not None:
        branch = else_part.body
        if isinstance(branch, If):
            conditions.append(branch.if_condition.tree)
            else_part = branch.else_part
        else:
            break
    return conditions


@categorize(_CodeQuality)
class RemoveDuplicateConditions(Recipe):
    """
    Remove ``elif`` branches whose condition duplicates an earlier branch.

    In an ``if``/``elif`` chain, each condition is tested in order.
    If a later ``elif`` repeats a condition that already appeared, its
    body can never run--the earlier branch will always win. Removing
    the unreachable branch prevents dead code from misleading readers
    or hiding bugs.

    Example:
        Before:
            if x > 0:
                a()
            elif x > 0:
                b()
            else:
                c()

        After:
            if x > 0:
                a()
            else:
                c()
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.codequality.RemoveDuplicateConditions"

    @property
    def display_name(self) -> str:
        return "Remove duplicate conditions in if/elif chains"

    @property
    def description(self) -> str:
        return (
            "Remove `elif` branches whose condition is identical to an earlier "
            "branch in the same `if`/`elif` chain, since the duplicate branch "
            "is dead code that can never execute."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "code-quality", "RSPEC-S1862"]

    @property
    def estimated_effort_per_occurrence(self) -> int:
        return 10

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_if(
                self, if_: If, p: ExecutionContext
            ) -> Optional[If]:
                if_ = super().visit_if(if_, p)

                if not isinstance(if_, If):
                    return if_

                # Only process top-level if (not elif branches visited
                # as children -- those are handled by walking the chain)
                try:
                    parent = self.cursor.parent_tree_cursor()
                except ValueError:
                    parent = None
                if parent is not None and isinstance(parent.value, If):
                    parent_if = parent.value
                    if (parent_if.else_part is not None
                            and parent_if.else_part.body is if_):
                        return if_

                return _remove_duplicates(if_)

        return Visitor()


def _remove_duplicates(if_: If) -> If:
    """Remove elif branches that duplicate an earlier condition."""
    seen: list[Expression] = [if_.if_condition.tree]
    result = if_
    result = _prune_chain(result, result, seen)
    return result


def _prune_chain(root: If, current: If, seen: list[Expression]) -> If:
    """Recursively walk the elif chain, pruning duplicates."""
    else_part = current.else_part
    if else_part is None:
        return root

    branch = else_part.body
    if not isinstance(branch, If):
        return root

    cond = branch.if_condition.tree
    is_dup = any(SemanticallyEqual.are_equal(cond, prev) for prev in seen)

    if is_dup:
        # Skip this elif -- connect current to the duplicate's else
        new_else = branch.else_part
        # Rebuild from root, replacing current's else_part
        root = _replace_else(root, current, new_else)
        # Continue checking from the same position (current now points
        # to the next branch)
        updated_current = _find_same_node(root, current)
        if updated_current is not None:
            return _prune_chain(root, updated_current, seen)
        return root
    else:
        seen.append(cond)
        return _prune_chain(root, branch, seen)


def _replace_else(root: If, target: If, new_else) -> If:
    """Replace the else_part of target within the root if/elif chain."""
    if root is target:
        return root.replace(_else_part=new_else)

    # Walk the chain to find target
    else_part = root.else_part
    if else_part is None:
        return root

    branch = else_part.body
    if not isinstance(branch, If):
        return root

    updated_branch = _replace_else(branch, target, new_else)
    if updated_branch is branch:
        return root

    new_body_padded = else_part.padding.body.replace(_element=updated_branch)
    new_else_part = else_part.padding.replace(_body=new_body_padded)
    return root.replace(_else_part=new_else_part)


def _find_same_node(root: If, target: If) -> Optional[If]:
    """Find the node in the rebuilt chain that corresponds to target."""
    if root.id == target.id:
        return root
    else_part = root.else_part
    if else_part is None:
        return None
    branch = else_part.body
    if isinstance(branch, If):
        return _find_same_node(branch, target)
    return None
