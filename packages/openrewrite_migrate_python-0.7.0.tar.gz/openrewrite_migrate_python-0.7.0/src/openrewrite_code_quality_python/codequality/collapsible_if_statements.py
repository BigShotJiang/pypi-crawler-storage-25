"""
Recipe to merge collapsible ``if`` statements.

When an ``if`` block contains only another ``if`` and neither has an
``else`` branch, the two conditions can be combined with ``and`` into
a single ``if``. This reduces nesting and makes the control flow
easier to follow.

See: https://rules.sonarsource.com/python/RSPEC-S1066/
"""

from typing import Any, List, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.markers import Markers
from rewrite.python.visitor import PythonVisitor
from rewrite.java.support_types import JLeftPadded, JRightPadded, Space
from rewrite.java.tree import (
    Binary as JBinary,
    Block,
    ControlParentheses,
    Expression,
    If,
    Parentheses,
)
from rewrite.utils import random_id

_CodeQuality = [
    *Python,
    CategoryDescriptor(display_name="Code quality"),
]


def _contains_or(expr: Expression) -> bool:
    """Return True if the top-level expression is an ``or`` binary."""
    return isinstance(expr, JBinary) and expr.operator == JBinary.Type.Or


def _dedent_block(block: Block, indent: str) -> Block:
    """Remove one level of *indent* from every statement in *block*."""
    if not indent:
        return block
    new_stmts = []
    for rp in block._statements:
        s = rp.element
        ws = s.prefix.whitespace
        if indent in ws:
            ws = ws.replace(indent, "", 1)
            s = s.replace(_prefix=Space(_comments=s.prefix.comments, _whitespace=ws))
            rp = rp.replace(_element=s)
        new_stmts.append(rp)
    return block.replace(_statements=new_stmts)


@categorize(_CodeQuality)
class CollapsibleIfStatements(Recipe):
    """
    Merge nested ``if`` statements into a single ``if`` with ``and``.

    An ``if`` whose body is nothing but another ``if``--and neither has
    an ``else`` clause--can always be rewritten as one ``if`` that
    combines both conditions with ``and``. The merged form is shorter,
    has less indentation, and communicates the same logic.

    Example:
        Before:
            if a:
                if b:
                    do_something()

        After:
            if a and b:
                do_something()
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.codequality.CollapsibleIfStatements"

    @property
    def display_name(self) -> str:
        return "Merge collapsible if statements"

    @property
    def description(self) -> str:
        return (
            "Combine nested `if` statements that have no `else` branch into "
            "a single `if` joined with `and`."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "code-quality", "RSPEC-S1066"]

    @property
    def estimated_effort_per_occurrence(self) -> int:
        return 5

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_if(
                self, if_: If, p: ExecutionContext
            ) -> Optional[If]:
                if_ = super().visit_if(if_, p)

                if not isinstance(if_, If):
                    return if_

                # Outer if must have no else/elif
                if if_.else_part is not None:
                    return if_

                then = if_.then_part
                if not isinstance(then, Block):
                    return if_

                stmts = then.statements
                if len(stmts) != 1:
                    return if_

                inner = stmts[0]
                if not isinstance(inner, If):
                    return if_

                # Inner if must have no else/elif
                if inner.else_part is not None:
                    return if_

                outer_cond = if_.if_condition.tree
                inner_cond = inner.if_condition.tree

                # Wrap inner condition in parens if it contains `or`
                # to preserve precedence with the new `and`
                if _contains_or(inner_cond):
                    inner_cond = Parentheses(
                        _id=random_id(),
                        _prefix=Space.SINGLE_SPACE,
                        _markers=Markers.EMPTY,
                        _tree=JRightPadded(
                            _element=inner_cond.replace(_prefix=Space.EMPTY),
                            _after=Space.EMPTY,
                            _markers=Markers.EMPTY,
                        ),
                    )
                else:
                    inner_cond = inner_cond.replace(_prefix=Space.SINGLE_SPACE)

                combined = JBinary(
                    _id=random_id(),
                    _prefix=outer_cond.prefix,
                    _markers=Markers.EMPTY,
                    _left=outer_cond.replace(_prefix=Space.EMPTY),
                    _operator=JLeftPadded(
                        _before=Space.SINGLE_SPACE,
                        _element=JBinary.Type.And,
                        _markers=Markers.EMPTY,
                    ),
                    _right=inner_cond,
                    _type=None,
                )

                new_condition = ControlParentheses(
                    _id=if_.if_condition.id,
                    _prefix=if_.if_condition.prefix,
                    _markers=if_.if_condition.markers,
                    _tree=JRightPadded(
                        _element=combined,
                        _after=if_.if_condition.padding.tree.after,
                        _markers=if_.if_condition.padding.tree.markers,
                    ),
                )

                # Dedent the inner body by one level since it was
                # nested inside the inner if that we're removing.
                inner_body = inner.then_part
                if isinstance(inner_body, Block):
                    # The inner if's prefix tells us the indent unit
                    ws = inner.prefix.whitespace
                    indent = ws.split("\n")[-1] if "\n" in ws else ws
                    inner_body = _dedent_block(inner_body, indent)

                return if_.replace(
                    _if_condition=new_condition,
                ).padding.replace(
                    _then_part=JRightPadded(
                        _element=inner_body,
                        _after=if_.padding.then_part.after,
                        _markers=if_.padding.then_part.markers,
                    ),
                )

        return Visitor()
