"""
Recipe to simplify inverted boolean checks.

Negating a comparison operator is harder to read than using the
opposite operator directly. For example, ``not (a == b)`` is clearer
when written as ``a != b``, and ``not (not x)`` is just ``x``.

See: https://rules.sonarsource.com/python/RSPEC-S1940/
"""

from typing import Any, List, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.python.visitor import PythonVisitor
from rewrite.java.support_types import JLeftPadded, Space
from rewrite.java.tree import (
    Binary as JBinary,
    Expression,
    Parentheses,
    Unary,
)

_CodeQuality = [
    *Python,
    CategoryDescriptor(display_name="Code quality"),
]

_OPERATOR_INVERSE = {
    JBinary.Type.Equal: JBinary.Type.NotEqual,
    JBinary.Type.NotEqual: JBinary.Type.Equal,
    JBinary.Type.LessThan: JBinary.Type.GreaterThanOrEqual,
    JBinary.Type.GreaterThan: JBinary.Type.LessThanOrEqual,
    JBinary.Type.LessThanOrEqual: JBinary.Type.GreaterThan,
    JBinary.Type.GreaterThanOrEqual: JBinary.Type.LessThan,
}


@categorize(_CodeQuality)
class BooleanChecksNotInverted(Recipe):
    """
    Replace inverted boolean checks with the equivalent direct comparison.

    Writing ``not (a == b)`` obscures the intent when ``a != b`` says the
    same thing more directly. Likewise ``not (not x)`` is simply ``x``.
    Flipping the operator or removing the double negation makes the
    condition immediately obvious to the reader.

    Example:
        Before:
            if not (a == b):
                pass

        After:
            if a != b:
                pass
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.codequality.BooleanChecksNotInverted"

    @property
    def display_name(self) -> str:
        return "Boolean checks should not be inverted"

    @property
    def description(self) -> str:
        return (
            "Replace inverted boolean comparisons like `not (a == b)` with the "
            "equivalent direct operator (`a != b`), and remove double negations "
            "like `not (not x)`."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "code-quality", "RSPEC-S1940"]

    @property
    def estimated_effort_per_occurrence(self) -> int:
        return 2

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_unary(
                self, unary: Unary, p: ExecutionContext
            ) -> Optional[Expression]:
                unary = super().visit_unary(unary, p)

                if not isinstance(unary, Unary):
                    return unary

                if unary.operator != Unary.Type.Not:
                    return unary

                expr = unary.expression

                # Unwrap parentheses to inspect inner expression
                inner = expr
                if isinstance(inner, Parentheses):
                    inner = inner.tree

                # Double negation: not (not x) -> x
                if isinstance(inner, Unary) and inner.operator == Unary.Type.Not:
                    return inner.expression.replace(_prefix=unary.prefix)

                # Inverted comparison: not (a == b) -> a != b
                if isinstance(inner, JBinary):
                    inverse = _OPERATOR_INVERSE.get(inner.operator)
                    if inverse is not None:
                        return inner.padding.replace(
                            _operator=JLeftPadded(
                                _before=inner.padding.operator.before,
                                _element=inverse,
                                _markers=inner.padding.operator.markers,
                            )
                        ).replace(_prefix=unary.prefix)

                return unary

        return Visitor()
