"""
Recipe to remove self-assignments.

Assigning a variable to itself (``x = x``) has no effect and is
almost always a copy-paste error or leftover from a refactoring.
Removing these statements makes the code cleaner and avoids
confusion about the author's intent.

See: https://rules.sonarsource.com/python/RSPEC-S1656/
"""

from typing import Any, List, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.python.visitor import PythonVisitor
from rewrite.java.support_types import Space
from rewrite.java.tree import (
    Assignment,
    Block,
    Expression,
    FieldAccess,
    Identifier,
)

_CodeQuality = [
    *Python,
    CategoryDescriptor(display_name="Code quality"),
]


def _structurally_equal(left: Expression, right: Expression) -> bool:
    """Return True when two expressions represent the same l-value.

    Handles simple identifiers (``x = x``) and field access chains
    (``self.x = self.x``).
    """
    if type(left) is not type(right):
        return False

    if isinstance(left, Identifier) and isinstance(right, Identifier):
        return left.simple_name == right.simple_name

    if isinstance(left, FieldAccess) and isinstance(right, FieldAccess):
        return (
            left.name.simple_name == right.name.simple_name
            and _structurally_equal(left.target, right.target)
        )

    return False


@categorize(_CodeQuality)
class RemoveSelfAssignment(Recipe):
    """
    Remove assignments where a variable is assigned to itself.

    A self-assignment like ``x = x`` or ``self.x = self.x`` does
    nothing at runtime. These statements typically result from
    copy-paste mistakes or incomplete refactorings and should be
    deleted to keep the code clear.

    Example:
        Before:
            x = x

        After:
            (statement removed)
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.codequality.RemoveSelfAssignment"

    @property
    def display_name(self) -> str:
        return "Remove self-assignments"

    @property
    def description(self) -> str:
        return (
            "Remove statements that assign a variable to itself "
            "(`x = x`, `self.x = self.x`), since they have no effect."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "code-quality", "RSPEC-S1656"]

    @property
    def estimated_effort_per_occurrence(self) -> int:
        return 3

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_compilation_unit(self, cu, p):
                cu = super().visit_compilation_unit(cu, p)
                new_stmts = _remove_self_assigns_padded(cu._statements)
                if new_stmts is not None:
                    cu = cu.replace(_statements=new_stmts)
                    if not new_stmts:
                        cu = cu.replace(_eof=Space.EMPTY)
                    return cu
                return cu

            def visit_block(
                self, block: Block, p: ExecutionContext
            ) -> Optional[Block]:
                block = super().visit_block(block, p)
                if not isinstance(block, Block):
                    return block
                new_stmts = _remove_self_assigns_padded(block._statements)
                if new_stmts is not None:
                    return block.replace(_statements=new_stmts)
                return block

        return Visitor()


def _remove_self_assigns_padded(padded_stmts) -> Optional[list]:
    """Return a filtered padded list with self-assignments removed, or None if unchanged."""
    to_remove: set[int] = set()
    for i, rp in enumerate(padded_stmts):
        s = rp.element
        if isinstance(s, Assignment) and _structurally_equal(s.variable, s.assignment):
            to_remove.add(i)

    if not to_remove:
        return None

    result = [
        rp for idx, rp in enumerate(padded_stmts)
        if idx not in to_remove
    ]

    # If we removed the first statement(s), strip the leading newline
    # from the new first statement's prefix to avoid a blank line.
    if result and 0 in to_remove:
        first_rp = result[0]
        first = first_rp.element
        ws = first.prefix.whitespace
        if ws.startswith("\n"):
            ws = ws[1:]
            new_first = first.replace(_prefix=Space(
                _comments=first.prefix.comments,
                _whitespace=ws,
            ))
            result[0] = first_rp.replace(_element=new_first)

    return result
