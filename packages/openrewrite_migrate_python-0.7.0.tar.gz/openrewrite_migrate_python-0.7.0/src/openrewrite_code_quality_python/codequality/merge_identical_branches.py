"""
Recipe to merge consecutive if/elif branches with identical bodies.

When adjacent branches execute the same code, they can be combined
into a single branch whose condition uses ``or``. This removes
duplication and makes it clear that the same action applies to
multiple conditions.

See: https://rules.sonarsource.com/python/RSPEC-S1871/
"""

from typing import Any, List, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.markers import Markers
from rewrite.python.visitor import PythonVisitor
from rewrite.java.support_types import JLeftPadded, JRightPadded, Space
from rewrite.java.tree import (
    Binary as JBinary,
    Block,
    ControlParentheses,
    Expression,
    If,
    Parentheses,
    Statement,
)
from openrewrite_code_quality_python.codequality._semantically_equal import SemanticallyEqual
from rewrite.utils import random_id

_CodeQuality = [
    *Python,
    CategoryDescriptor(display_name="Code quality"),
]


def _contains_and(expr: Expression) -> bool:
    """Return True if the top-level expression is an ``and`` binary."""
    return isinstance(expr, JBinary) and expr.operator == JBinary.Type.And


def _bodies_equal(a: Statement, b: Statement) -> bool:
    """Return True if two branch bodies are semantically equal."""
    return SemanticallyEqual.are_equal(a, b)


@categorize(_CodeQuality)
class MergeIdenticalBranches(Recipe):
    """
    Merge consecutive ``if``/``elif`` branches that have identical bodies.

    When two adjacent branches in an ``if``/``elif`` chain execute
    exactly the same code, the conditions can be joined with ``or``
    and the duplicate body removed. This eliminates copy-paste
    redundancy and makes the relationship between the conditions
    explicit.

    Example:
        Before:
            if a:
                x()
            elif b:
                x()
            else:
                y()

        After:
            if a or b:
                x()
            else:
                y()
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.codequality.MergeIdenticalBranches"

    @property
    def display_name(self) -> str:
        return "Merge consecutive branches with identical bodies"

    @property
    def description(self) -> str:
        return (
            "Combine consecutive `if`/`elif` branches that have the same body "
            "into a single branch with conditions joined by `or`."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "code-quality", "RSPEC-S1871"]

    @property
    def estimated_effort_per_occurrence(self) -> int:
        return 10

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_if(
                self, if_: If, p: ExecutionContext
            ) -> Optional[If]:
                if_ = super().visit_if(if_, p)

                if not isinstance(if_, If):
                    return if_

                # Only process top-level if in a chain
                try:
                    parent = self.cursor.parent_tree_cursor()
                except ValueError:
                    parent = None
                if parent is not None and isinstance(parent.value, If):
                    parent_if = parent.value
                    if (parent_if.else_part is not None
                            and parent_if.else_part.body is if_):
                        return if_

                return _merge_chain(if_)

        return Visitor()


def _merge_chain(if_: If) -> If:
    """Merge consecutive branches with identical bodies."""
    result = if_
    changed = True
    while changed:
        changed = False
        result, changed = _merge_one_pass(result)
    return result


def _merge_one_pass(if_: If) -> tuple[If, bool]:
    """Do one pass over the chain, merging the first pair found."""
    current = if_
    while True:
        else_part = current.else_part
        if else_part is None:
            break

        branch = else_part.body
        if not isinstance(branch, If):
            break

        # Check if current and branch have the same body
        if _bodies_equal(current.then_part, branch.then_part):
            merged = _merge_conditions(current, branch)
            if_ = _replace_in_chain(if_, current, merged)
            return if_, True

        current = branch

    return if_, False


def _merge_conditions(first: If, second: If) -> If:
    """Merge two if nodes by combining conditions with ``or``."""
    first_cond = first.if_condition.tree
    second_cond = second.if_condition.tree

    # Wrap conditions in parens if they contain ``and`` to preserve precedence
    if _contains_and(first_cond):
        left = Parentheses(
            _id=random_id(),
            _prefix=first_cond.prefix,
            _markers=Markers.EMPTY,
            _tree=JRightPadded(
                _element=first_cond.replace(_prefix=Space.EMPTY),
                _after=Space.EMPTY,
                _markers=Markers.EMPTY,
            ),
        )
    else:
        left = first_cond

    if _contains_and(second_cond):
        right = Parentheses(
            _id=random_id(),
            _prefix=Space.SINGLE_SPACE,
            _markers=Markers.EMPTY,
            _tree=JRightPadded(
                _element=second_cond.replace(_prefix=Space.EMPTY),
                _after=Space.EMPTY,
                _markers=Markers.EMPTY,
            ),
        )
    else:
        right = second_cond.replace(_prefix=Space.SINGLE_SPACE)

    combined = JBinary(
        _id=random_id(),
        _prefix=left.prefix,
        _markers=Markers.EMPTY,
        _left=left.replace(_prefix=Space.EMPTY),
        _operator=JLeftPadded(
            _before=Space.SINGLE_SPACE,
            _element=JBinary.Type.Or,
            _markers=Markers.EMPTY,
        ),
        _right=right,
        _type=None,
    )

    new_condition = ControlParentheses(
        _id=first.if_condition.id,
        _prefix=first.if_condition.prefix,
        _markers=first.if_condition.markers,
        _tree=JRightPadded(
            _element=combined,
            _after=first.if_condition.padding.tree.after,
            _markers=first.if_condition.padding.tree.markers,
        ),
    )

    return first.replace(
        _if_condition=new_condition,
        _else_part=second.else_part,
    )


def _replace_in_chain(root: If, target: If, replacement: If) -> If:
    """Replace a specific If node in the chain with a new one."""
    if root.id == target.id:
        return replacement

    else_part = root.else_part
    if else_part is None:
        return root

    branch = else_part.body
    if not isinstance(branch, If):
        return root

    updated = _replace_in_chain(branch, target, replacement)
    if updated is branch:
        return root

    return root.replace(
        _else_part=else_part.replace(_body=updated),
    )
