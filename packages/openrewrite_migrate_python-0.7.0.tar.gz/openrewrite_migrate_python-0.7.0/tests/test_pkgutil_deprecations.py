"""Tests for pkgutil deprecation migration recipes."""

from rewrite.test import RecipeSpec, python
from openrewrite_migrate_python.migrate.pkgutil_deprecations import (
    ReplacePkgutilFindLoader,
    ReplacePkgutilGetLoader,
)


class TestReplacePkgutilFindLoader:
    """Tests for the ReplacePkgutilFindLoader recipe."""

    def test_replaces_pkgutil_find_loader(self):
        spec = RecipeSpec(recipe=ReplacePkgutilFindLoader())
        spec.rewrite_run(
            python(
                """
                import pkgutil
                loader = pkgutil.find_loader("mymodule")
                """,
                """
                import importlib.util
                loader = importlib.util.find_spec("mymodule")
                """,
            )
        )

    def test_no_change_when_walk_packages(self):
        spec = RecipeSpec(recipe=ReplacePkgutilFindLoader())
        spec.rewrite_run(
            python(
                """
                import pkgutil
                for pkg in pkgutil.walk_packages():
                    pass
                """
            )
        )


class TestReplacePkgutilGetLoader:
    """Tests for the ReplacePkgutilGetLoader recipe."""

    def test_replaces_pkgutil_get_loader(self):
        spec = RecipeSpec(recipe=ReplacePkgutilGetLoader())
        spec.rewrite_run(
            python(
                """
                import pkgutil
                loader = pkgutil.get_loader("mymodule")
                """,
                """
                import importlib.util
                loader = importlib.util.find_spec("mymodule")
                """,
            )
        )

    def test_no_change_when_iter_modules(self):
        spec = RecipeSpec(recipe=ReplacePkgutilGetLoader())
        spec.rewrite_run(
            python(
                """
                import pkgutil
                for mod in pkgutil.iter_modules():
                    pass
                """
            )
        )
