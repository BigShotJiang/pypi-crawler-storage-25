"""Tests for sys.last_type/value/traceback → sys.last_exc replacement recipe."""

from rewrite.test import RecipeSpec, python

from openrewrite_migrate_python.migrate.sys_last_deprecations import (
    ReplaceSysLastExcInfo,
)

class TestReplaceSysLastExcInfo:
    """Tests for ReplaceSysLastExcInfo recipe."""

    def test_replaces_sys_last_value(self):
        """last_value is semantically equivalent to last_exc — auto-replaced."""
        spec = RecipeSpec(recipe=ReplaceSysLastExcInfo())
        spec.rewrite_run(
            python(
                """
                import sys
                v = sys.last_value
                """,
                """
                import sys
                v = sys.last_exc
                """,
            )
        )

    def test_replaces_sys_last_type(self):
        """last_type is rewritten to type(sys.last_exc)."""
        spec = RecipeSpec(recipe=ReplaceSysLastExcInfo())
        spec.rewrite_run(
            python(
                """
                import sys
                t = sys.last_type
                """,
                """
                import sys
                t = type(sys.last_exc)
                """,
            )
        )

    def test_replaces_sys_last_traceback(self):
        """last_traceback is rewritten to sys.last_exc.__traceback__."""
        spec = RecipeSpec(recipe=ReplaceSysLastExcInfo())
        spec.rewrite_run(
            python(
                """
                import sys
                tb = sys.last_traceback
                """,
                """
                import sys
                tb = sys.last_exc.__traceback__
                """,
            )
        )

    def test_no_change_when_using_last_exc(self):
        spec = RecipeSpec(recipe=ReplaceSysLastExcInfo())
        spec.rewrite_run(
            python(
                """
                import sys
                exc = sys.last_exc
                """
            )
        )

    def test_no_change_when_different_module(self):
        spec = RecipeSpec(recipe=ReplaceSysLastExcInfo())
        spec.rewrite_run(
            python("t = other.last_type")
        )
