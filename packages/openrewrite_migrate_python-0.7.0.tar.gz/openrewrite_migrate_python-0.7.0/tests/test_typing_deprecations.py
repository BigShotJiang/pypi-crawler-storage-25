"""Tests for typing deprecation migration recipes."""

from rewrite.test import RecipeSpec, python
from openrewrite_migrate_python.migrate.typing_deprecations import (
    ReplaceTypingDictWithDict,
    ReplaceTypingListWithList,
    ReplaceTypingSetWithSet,
    ReplaceTypingText,
    ReplaceTypingTupleWithTuple,
)


class TestReplaceTypingListWithList:
    """Tests for the ReplaceTypingListWithList recipe."""

    def test_replaces_typing_list_with_builtin(self):
        spec = RecipeSpec(recipe=ReplaceTypingListWithList())
        spec.rewrite_run(
            python(
                """
                from typing import List
                items: List[str] = []
                """,
                """
                items: list[str] = []
                """,
            )
        )

    def test_no_change_when_builtin_list_used(self):
        spec = RecipeSpec(recipe=ReplaceTypingListWithList())
        spec.rewrite_run(
            python(
                """
                items: list[str] = []
                """
            )
        )

    def test_preserves_other_typing_imports(self):
        spec = RecipeSpec(recipe=ReplaceTypingListWithList())
        spec.rewrite_run(
            python(
                """
                from typing import List, Optional
                items: List[str] = []
                value: Optional[int] = None
                """,
                """
                from typing import Optional
                items: list[str] = []
                value: Optional[int] = None
                """,
            )
        )


class TestReplaceTypingDictWithDict:
    """Tests for the ReplaceTypingDictWithDict recipe."""

    def test_replaces_typing_dict_with_builtin(self):
        spec = RecipeSpec(recipe=ReplaceTypingDictWithDict())
        spec.rewrite_run(
            python(
                """
                from typing import Dict
                mapping: Dict[str, int] = {}
                """,
                """
                mapping: dict[str, int] = {}
                """,
            )
        )

    def test_no_change_when_builtin_dict_used(self):
        spec = RecipeSpec(recipe=ReplaceTypingDictWithDict())
        spec.rewrite_run(
            python(
                """
                mapping: dict[str, int] = {}
                """
            )
        )

    def test_preserves_other_typing_imports(self):
        spec = RecipeSpec(recipe=ReplaceTypingDictWithDict())
        spec.rewrite_run(
            python(
                """
                from typing import Dict, Optional
                mapping: Dict[str, int] = {}
                value: Optional[int] = None
                """,
                """
                from typing import Optional
                mapping: dict[str, int] = {}
                value: Optional[int] = None
                """,
            )
        )


class TestReplaceTypingSetWithSet:
    """Tests for the ReplaceTypingSetWithSet recipe."""

    def test_replaces_typing_set_with_builtin(self):
        spec = RecipeSpec(recipe=ReplaceTypingSetWithSet())
        spec.rewrite_run(
            python(
                """
                from typing import Set
                items: Set[int] = set()
                """,
                """
                items: set[int] = set()
                """,
            )
        )

    def test_no_change_when_builtin_set_used(self):
        spec = RecipeSpec(recipe=ReplaceTypingSetWithSet())
        spec.rewrite_run(
            python(
                """
                items: set[int] = set()
                """
            )
        )

    def test_preserves_other_typing_imports(self):
        spec = RecipeSpec(recipe=ReplaceTypingSetWithSet())
        spec.rewrite_run(
            python(
                """
                from typing import Set, Optional
                items: Set[int] = set()
                value: Optional[int] = None
                """,
                """
                from typing import Optional
                items: set[int] = set()
                value: Optional[int] = None
                """,
            )
        )


class TestReplaceTypingTupleWithTuple:
    """Tests for the ReplaceTypingTupleWithTuple recipe."""

    def test_replaces_typing_tuple_with_builtin(self):
        spec = RecipeSpec(recipe=ReplaceTypingTupleWithTuple())
        spec.rewrite_run(
            python(
                """
                from typing import Tuple
                point: Tuple[int, int] = (0, 0)
                """,
                """
                point: tuple[int, int] = (0, 0)
                """,
            )
        )

    def test_no_change_when_builtin_tuple_used(self):
        spec = RecipeSpec(recipe=ReplaceTypingTupleWithTuple())
        spec.rewrite_run(
            python(
                """
                point: tuple[int, int] = (0, 0)
                """
            )
        )

    def test_preserves_other_typing_imports(self):
        spec = RecipeSpec(recipe=ReplaceTypingTupleWithTuple())
        spec.rewrite_run(
            python(
                """
                from typing import Tuple, Optional
                point: Tuple[int, int] = (0, 0)
                value: Optional[int] = None
                """,
                """
                from typing import Optional
                point: tuple[int, int] = (0, 0)
                value: Optional[int] = None
                """,
            )
        )


class TestReplaceTypingText:
    """Tests for the ReplaceTypingText recipe."""

    def test_replaces_typing_text(self):
        """Test that typing.Text is replaced with str."""
        spec = RecipeSpec(recipe=ReplaceTypingText())
        spec.rewrite_run(
            python(
                """
                from typing import Text
                name: Text = "hello"
                """,
                """
                name: str = "hello"
                """,
            )
        )

    def test_preserves_other_typing_imports(self):
        """Test that other typing imports are preserved when Text is removed."""
        spec = RecipeSpec(recipe=ReplaceTypingText())
        spec.rewrite_run(
            python(
                """
                from typing import Text, Optional
                name: Text = "hello"
                """,
                """
                from typing import Optional
                name: str = "hello"
                """,
            )
        )

    def test_no_change_when_str(self):
        """Test that str is not changed."""
        spec = RecipeSpec(recipe=ReplaceTypingText())
        spec.rewrite_run(
            python(
                """
                name: str = "hello"
                """
            )
        )
