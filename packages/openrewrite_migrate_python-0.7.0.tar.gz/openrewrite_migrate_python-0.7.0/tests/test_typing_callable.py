"""Tests for typing.Callable migration recipe."""

from rewrite.test import RecipeSpec, python
from openrewrite_migrate_python.migrate.typing_callable import (
    ReplaceTypingCallableWithCollectionsAbcCallable,
)


class TestReplaceTypingCallableWithCollectionsAbcCallable:
    def test_replaces_from_typing_import_callable(self):
        spec = RecipeSpec(recipe=ReplaceTypingCallableWithCollectionsAbcCallable())
        spec.rewrite_run(
            python(
                """
                from typing import Callable
                handler: Callable[[int], str] = lambda x: str(x)
                """,
                """
                from collections.abc import Callable
                handler: Callable[[int], str] = lambda x: str(x)
                """,
            )
        )

    def test_no_change_when_collections_abc_callable(self):
        spec = RecipeSpec(recipe=ReplaceTypingCallableWithCollectionsAbcCallable())
        spec.rewrite_run(
            python(
                """
                from collections.abc import Callable
                handler: Callable[[int], str] = lambda x: str(x)
                """
            )
        )
