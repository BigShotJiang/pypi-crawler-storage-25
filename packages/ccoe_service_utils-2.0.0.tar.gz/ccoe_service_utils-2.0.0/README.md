# Python Package for CCoE Service Utils

## Overview

The CCoE Service Utils package is a comprehensive utility library designed to streamline and enhance the development of services within the Cloud Center of Excellence (CCoE).

## Features

- `get_variables_from_env`: Retrieves environment variables and returns them as a dictionary.
- `get_authorization_header`: Generates an authorization header for the given scope using the provided credentials.
- `get_http_session`: Creates and returns an HTTP session with automatic retry mechanisms.
- `strtobool`: Convert a string to a boolean.
- `MailContentType`: Enum class for specifying mail content types (`PLAIN`, `HTML`).
- `EmailMessage`: Data class for defining email messages with attributes such as recipients, subject, content, and more.
- `MailQueueService`: Class for sending emails using a queue service.
- `get_custom_logger`: Creates and returns a custom logger that logs at the info level to stdout.
- `get_admin_account_email`: Returns a string containing the email of an admin account.
- `DynamicWorkloadMapping`: Data class for mapping dynamic workload mapping.
- `CostManagementService`: Class for adding cost allocations to a workload.

## Installation

In order to install the package, you need [PIP](https://pip.pypa.io/en/stable/installation/)

If you already have PIP, it's recommended to run the following command

```bash
python -m pip install --upgrade pip
```

The package is published to DevOps Artifacts, because of this, the artifacts-keyring package is required.

```bash
pip install keyring artifacts-keyring
```

The artifacts-keyring package provides authentication for publishing or consuming Python packages to or from Azure Artifacts feeds within Azure DevOps.

After installing artifacts-keyring, you should be able to install our utils package.

```bash
pip install ccoe-service-utils --index-url https://pkgs.dev.azure.com/STARK-IT/d2528ce2-d2d9-4c8f-8ecf-1223114d729d/_packaging/ccoe-service-utils/pypi/simple/
```

## Development

If any updates are made to the package, the version needs to be incremented in order for the pipeline to publish properly.

- [pyproject](pyproject.toml)
- [init](src/ccoe_service_utils/__init__.py)

### Building and testing the package locally

If you've implemented new functionality or made some changes to the package and want to test this locally before pushing, then you could build and install the package locally.

This can be done by navigating to the directory containing the [pyproject.toml](pyproject.toml) and then running the build command.

```
py -m build
```

This will create a new directory (`dist`), which will contain the newly built package.

To then install the new package you can run a force reinstall.

```
pip install --force-reinstall dist/PACKAGE_NAME.tar.gz
```

This should install the newly built package and allow you to implement it for testing.

### Link to artifact feed / package in DevOps

[ccoe-service-utils](https://dev.azure.com/STARK-IT/Cloud%20Center%20of%20Excellence/_artifacts/feed/ccoe-service-utils)
