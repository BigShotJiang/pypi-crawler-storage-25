from azure.identity import DefaultAzureCredential
from azure.storage.queue import QueueClient, QueueMessage
import base64
from enum import Enum
from dataclasses import dataclass
import json
from typing import Optional


@dataclass
class MailContentType(str, Enum):
    """Mail Content Type Enum class."""

    PLAIN = "Plain"
    HTML = "Html"


@dataclass
class EmailMessage:
    """Email Message class for sending emails."""

    Recipients: list[str]
    Subject: Optional[str] = None
    From: Optional[str] = None
    Ccs: Optional[list[str]] = None
    Bccs: Optional[list[str]] = None
    MailContent: Optional[str] = None
    ContentType: Optional[MailContentType] = None
    TemplateId: Optional[str] = None
    TemplateData: Optional[any] = None


class MailQueueService:
    """MailQueueService class for sending messages to a queue."""

    def __init__(
        self, account_name: str, queue_name: str, credential: DefaultAzureCredential
    ):
        """Initializes the MailQueueService class.

        Parameters
        ----------
        account_name: str
            The account name.
        queue_name: str
            The queue name.
        credential: DefaultAzureCredential
            The credentials object.

        Examples
        --------
        >>> queue_service = MailQueueService(account_name, queue_name, credentials)
        """
        self.account_name = account_name
        self.queue_name = queue_name
        self.credential = credential
        self.account_url = f"https://{account_name}.queue.core.windows.net"
        self.queue_client = QueueClient(
            self.account_url, self.queue_name, self.credential
        )

    def send_message(self, email_message: EmailMessage) -> QueueMessage:
        """Sends a message to the queue.

        Parameters
        ----------
        email_message: EmailMessage
            The email message object.

        Returns
        -------
        QueueMessage
            The queue message object.

        Examples
        --------
        >>> queue_service.send_message(email_message)
        """
        message = json.dumps(vars(email_message))
        base64_message = base64.b64encode(message.encode("ascii")).decode("utf-8")

        return self.queue_client.send_message(base64_message)
