import logging
import sys


class CustomLogger:
    """Gets a custom logger that logs at info level to stdout.

    Returns
    -------
    logging.Logger
        The logger object.

    Examples
    --------
    >>> logger = CustomLogger()
    """

    def __new__(cls):
        if not hasattr(cls, "instance"):
            cls.instance = super(CustomLogger, cls).__new__(cls)
            logger = logging.getLogger("custom_logger")
            formatter = logging.Formatter("%(levelname)s - %(message)s")
            logger.setLevel(logging.INFO)
            handler = logging.StreamHandler(sys.stdout)
            handler.setFormatter(formatter)
            logger.addHandler(handler)
            logger.propagate = False
            cls.instance = logger
        return cls.instance
