from azure.identity import DefaultAzureCredential
from dataclasses import dataclass
import os
import requests
from requests.adapters import HTTPAdapter, Retry
from typing import Optional, Generic, TypeVar


def get_variables_from_env(environment_variables: list[str]):
    """Gets the environment variables.

    Parameters
    ----------
    environment_variables: list[str]
        Variable containing a list of environment variables.
        e.g. a constants file.

    Returns
    -------
    dict[str, str]
        Dict object with keys and values.

    Examples
    --------
    >>> get_variables_from_env(ENVIRONMENT_VARIABLES)
    """
    return {
        environment_var_name: os.environ.get(environment_var_name, None)
        for environment_var_name in environment_variables
    }


def get_authorization_header(
    SCOPE: str, credentials: DefaultAzureCredential
) -> dict[str, str]:
    """Gets an authorization header.

    Parameters
    ----------
    SCOPE: str
        The SCOPE of the token.

    credentials: DefaultAzureCredential
        The credentials object.

    Returns
    -------
    dict[str, str]
        Dict object with the authorization header.

    Examples
    --------
    >>> get_authorization_header("https://graph.microsoft.com/.default", credentials)
    """
    access_token = credentials.get_token(SCOPE)
    return {"Authorization": f"Bearer {access_token.token}"}


def get_http_session():
    """Gets an HTTP session with exponential backoff retry.

    Returns
    -------
    requests.Session
        The session object.
    """
    session = requests.Session()
    retries = Retry(total=3, backoff_factor=0.5)
    session.mount("https://", HTTPAdapter(max_retries=retries))
    return session


def strtobool(value: str) -> bool:
    """Convert a string to a boolean."""
    value = value.lower().strip()
    if value in {"y", "yes", "true", "t", "1"}:
        return True
    elif value in {"n", "no", "false", "f", "0"}:
        return False
    else:
        raise ValueError(f"Invalid truth value: {value}")


T = TypeVar("T")


@dataclass
class Result(Generic[T]):
    """Generic Result class for representing operation outcomes with or without data."""

    value: Optional[T] = None
    is_success: bool = False
    error: Optional[str] = None

    def __post_init__(self):
        if self.is_success and self.error is not None:
            raise ValueError("A successful result cannot have an error message.")
        if not self.is_success and not self.error:
            raise ValueError("A failed result must have an error message.")
        if self.is_success and self.value is None:
            raise ValueError("A successful result must have a value.")

    @property
    def is_failed(self) -> bool:
        return not self.is_success

    @staticmethod
    def success(value: T) -> "Result[T]":
        """Create a successful result with a value."""
        return Result(value=value, is_success=True)

    @staticmethod
    def failure(error: str) -> "Result[T]":
        """Create a failed result with an error message."""
        return Result(is_success=False, error=error)
