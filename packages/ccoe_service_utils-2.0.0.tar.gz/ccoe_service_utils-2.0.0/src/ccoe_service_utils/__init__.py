"""
CCoE Utils Package for Python.
Contains often utilized functions and classes for CCoE services.
"""

from .cost_management import CostManagementService, DynamicWorkloadAllocation, Workload
from .logger import CustomLogger
from .mail import MailContentType, EmailMessage, MailQueueService
from .utils import (
    get_variables_from_env,
    get_authorization_header,
    get_http_session,
    strtobool,
    Result,
)

__version__ = "2.0.0"

__all__ = [
    "MailContentType",
    "EmailMessage",
    "MailQueueService",
    "CustomLogger",
    "get_variables_from_env",
    "get_authorization_header",
    "get_http_session",
    "strtobool",
    "Result",
    "CostManagementService",
    "DynamicWorkloadAllocation",
    "Workload",
]
