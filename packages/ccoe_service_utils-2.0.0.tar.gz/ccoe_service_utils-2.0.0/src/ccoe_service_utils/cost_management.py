from azure.identity import DefaultAzureCredential
from dataclasses import dataclass
import json

from .utils import Result, get_http_session
from .logger import CustomLogger


@dataclass
class Workload:
    """Workload class for managing workloads."""

    workload_name: str
    environment: str

    def get_dto(self):
        return {
            "workloadName": self.workload_name,
            "environment": self.environment,
        }


@dataclass
class DynamicWorkloadAllocation:
    """Dynamic Workload Allocation class for managing workload allocations."""

    source_workload: Workload
    target_workload: Workload
    proportional_split: float
    allocation_date: str

    def get_dto(self):
        return {
            "sourceWorkload": self.source_workload.get_dto(),
            "targetWorkload": self.target_workload.get_dto(),
            "proportionalSplit": self.proportional_split,
            "allocationDate": self.allocation_date,
        }


class CostManagementService:
    """Cost Management Service class for managing workload mappings."""

    def __init__(
        self, base_url: str, credential: DefaultAzureCredential, logger=CustomLogger()
    ):
        """Initializes the Cost Management Service class.

        Parameters
        ----------
        base_url: str
            The base URL of the cost management service.
        credential: DefaultAzureCredential
            The credentials object for authentication.

        Examples
        --------
        >>> cost_management_service = CostManagementService("https://cost.ccoe.cloud.stark.group", credentials)
        """
        self.base_url = base_url
        self.scope = base_url + ".default"
        self.credential = credential
        self.logger = logger

    def __get_headers(self):
        token = self.credential.get_token(self.scope).token

        return {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
        }

    def add_dynamic_workload_allocations(
        self, workload_allocations: list[DynamicWorkloadAllocation]
    ) -> Result[int]:
        """Adds dynamic workload allocations to the cost management service.

        Parameters
        ----------
        workload_allocations: list[DynamicWorkloadAllocation]
            A list of DynamicWorkloadAllocation objects to be added.

        Returns
        -------
        Result[int]
            The number of successful allocations added or an error message.

        """
        DYNAMIC_WORKLOAD_MAPPING_ENDPOINT = "api/v1/WorkloadAllocation/dynamic/bulk"
        url = self.base_url + DYNAMIC_WORKLOAD_MAPPING_ENDPOINT

        payload = json.dumps(
            {
                "allocations": [
                    allocation.get_dto() for allocation in workload_allocations
                ]
            }
        )

        response = get_http_session().post(
            url, data=payload, headers=self.__get_headers()
        )

        if response.ok:
            data: dict = response.json()
            success_count = data.get("successCount", 0)
            failure_count = data.get("failureCount", 0)

            if success_count == len(workload_allocations):
                return Result.success(success_count)
            else:
                self.logger.warning(
                    f"Added {success_count} dynamic workload allocations, but {failure_count} failed."
                )
                for allocation in data.get("errors", []):
                    self.logger.error(f"Failed to add allocation: {allocation}")
                return Result.failure(
                    f"Failed to add {failure_count} dynamic workload allocations."
                )
        else:
            return Result.failure(
                f"Failed to add dynamic workload allocations. Status code: {response.status_code}"
            )

    def get_workload_by_subscription(self, subscription_id: str) -> Result[Workload]:
        """Get the workload for a subscription.

        Parameters
        ----------
        subscription_id: str
            The subscription id to resolve.
        Returns
        -------
        Result[Workload]
            The resolved workload.

        Examples
        --------
        >>> cost_management_service.get_workload_by_subscription("00000000-0000-0000-0000-000000000000")
        """
        WORKLOAD_ENDPOINT = f"api/v1/Workload/subscription/{subscription_id}"
        url = self.base_url + WORKLOAD_ENDPOINT

        response = get_http_session().get(url, headers=self.__get_headers())

        data: dict = response.json()

        if response.ok:

            return Result.success(
                Workload(data.get("workloadName"), data.get("environment"))
            )

        else:
            self.logger.info(
                f"Could not find a workload for subscription: {subscription_id}."
            )
            error_message = data.get("message", response.text)
            return Result.failure(error_message)
