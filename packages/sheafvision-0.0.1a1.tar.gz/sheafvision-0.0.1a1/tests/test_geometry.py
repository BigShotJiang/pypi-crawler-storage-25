import unittest

from sheafvision import Box, fit_box, iou, intersection_area


class GeometryTests(unittest.TestCase):
    def test_intersection_area(self) -> None:
        self.assertEqual(intersection_area(Box(0, 0, 10, 10), Box(5, 5, 10, 10)), 25)

    def test_iou(self) -> None:
        self.assertGreater(iou(Box(0, 0, 10, 10), Box(5, 5, 10, 10)), 0.0)

    def test_fit_box(self) -> None:
        fitted = fit_box(Box(-1, 2, 10, 10), canvas_width=8, canvas_height=8)
        self.assertEqual((fitted.x, fitted.width), (0, 8))

