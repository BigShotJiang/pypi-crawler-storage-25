from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Box:
    x: int
    y: int
    width: int
    height: int


def intersection_area(a: Box, b: Box) -> int:
    left = max(a.x, b.x)
    top = max(a.y, b.y)
    right = min(a.x + a.width, b.x + b.width)
    bottom = min(a.y + a.height, b.y + b.height)
    return max(0, right - left) * max(0, bottom - top)


def iou(a: Box, b: Box) -> float:
    inter = intersection_area(a, b)
    union = a.width * a.height + b.width * b.height - inter
    return inter / union if union else 0.0


def fit_box(box: Box, *, canvas_width: int, canvas_height: int) -> Box:
    return Box(
        max(0, min(box.x, canvas_width - box.width)),
        max(0, min(box.y, canvas_height - box.height)),
        min(box.width, canvas_width),
        min(box.height, canvas_height),
    )

