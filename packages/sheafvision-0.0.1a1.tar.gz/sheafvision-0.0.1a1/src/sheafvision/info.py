def project_info() -> dict[str, str]:
    return {
        "name": "sheafvision",
        "stage": "bootstrap",
        "homepage": "https://sheaflab.com",
        "repository": "https://github.com/SheafLab/sheafvision-python",
    }

