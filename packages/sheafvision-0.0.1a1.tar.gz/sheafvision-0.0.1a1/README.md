# sheafvision

`sheafvision` is the official Python package namespace for lightweight vision
geometry helpers used by the SheafLab project.

This initial public release provides boxes, overlap ratios, and canvas fitting
for compact visual-region reasoning.

