"""supython: a lightweight Postgres-first BaaS framework for Python."""

from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("supython")
except PackageNotFoundError:
    __version__ = "0.0.0+unknown"
