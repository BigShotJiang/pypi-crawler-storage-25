# Changelog

All notable changes to supython are recorded here. The format follows
[Keep a Changelog](https://keepachangelog.com/en/1.1.0/) and the
project uses **ZeroVer** (`0.x.y`) — see `docs/PROJECT.md` §14.0 for
what counts as a breaking change before v1.0.

Categories used per release:

- **Breaking** — frozen-surface change as defined in §14.0; bumps `MINOR`.
- **Added** — new capability (no breakage); bumps `MINOR` or `PATCH`.
- **Changed** — backwards-compatible behaviour change.
- **Deprecated** — still works, scheduled for removal.
- **Removed** — gone; pre-1.0 may appear under `Breaking` instead.
- **Fixed** — bug fix.
- **Security** — vulnerability fix or hardening.

Each entry links the relevant `PROJECT.md` section and decision-log row
(`§19 YYYY-MM-DD`) where one exists.

## [Unreleased]

### Breaking
### Added
### Changed
### Deprecated
### Removed
### Fixed
### Security

---

## [0.7.0] — YYYY-MM-DD

Milestone B: Production Observable (§14 v0.7).

### Added
- Structured JSON logging with `request_id` propagation (§14 v0.7).
- `/livez`, `/readyz`, deep `/health` with per-dependency timeouts (§14 v0.7).
- Request logging middleware with auth-header redaction (§14 v0.7).
- Security headers middleware (HSTS, nosniff, frame-deny, referrer, CSP).
- OAuth PKCE (`code_challenge_method="S256"`) on all providers (§15.6 #22).
- Email-send retry via `jobs.jobs` for `/recover`, magic link, OTP (§15.6 #21).
- Symmetric secret rotation: `supython secret {status,rotate,activate,prune}`
  for `STORAGE_SIGNED_URL_SECRET` and `OAUTH_STATE_SECRET` (§11.1.2).
- Postgres password rotation: `supython password rotate <role>` (§11.1.3).

### Changed
- `supython doctor` expanded to cover extensions, `wal_level`, role
  attributes, grants, schema ownership, migration drift (§14 v0.7).

### Security
- Input size guards on every write route (max body, email, password length).
- Audit-log completeness on refresh-reuse, password change, OAuth link.

---

## [0.6.0] — YYYY-MM-DD

Milestone A: grooming + security foundation (§14 v0.6).

### Breaking
- Removed  entirely; `JWT_SECRET` and its validator deleted.
  RS256 is the default; ES256 optional. Required: `JWT_PRIVATE_KEY_PATH`
  or inline `JWT_PRIVATE_KEY`. Public key published as JWKS for
  PostgREST. (§8.2, §19 2026-04-23)
- `CORS_ORIGINS` is now required for any browser client; default empty
  means no allowed origins (was previously `["*"]`). (§11, §15.6 #5)

### Added
- `supython keygen {init,rotate,activate,prune}` zero-downtime JWT
  rotation; PostgREST hot-reload via `SIGUSR2` (§11.1.1).
- Per-IP rate limiting on `/auth/v1/{token,signup,recover,otp}` backed
  by `auth.rate_limit_buckets` + conditional pg_cron pruning
  (`migrations/0009_auth_rate_limits.sql`).
- `db_statement_timeout_ms`, `db_pool_min_size`, `db_pool_max_size`
  settings (§15.6 #13, #14).
- `last_error` column on `jobs.jobs`; surfaced in `JobResponse`
  (`migrations/0008_jobs_last_error.sql`, §15.6 #19).
- `db.as_service_role(claims=...)` accepts optional claims; realtime
  router's bespoke `_ServiceRoleSession` retired (§15.6 #20).

### Changed
- Worker honours `JobDefinition.role` / `claims_from`; user-scoped jobs
  run under `db.as_role()` instead of always `service_role` (§15.6 #16).
- `Worker._poll` enforces `jobs_concurrency` via `asyncio.Semaphore`
  (§15.6 #17).
- `POST /jobs/v1/jobs/{id}/retry` gates on `failed`/`cancelled`; 409
  otherwise (§15.6 #18).
- Single source of truth for `__version__` — `supython/__init__.py`,
  FastAPI app version, and `/health` body all import the same constant
  (§15.6 #11).

### Fixed
- Test-fixture role leakage: `await c.execute("set role service_role")`
  outside transactions replaced with `db.as_service_role()` /
  `SET LOCAL` + `try/finally`. Conftest sentinel `_assert_no_role_leak`
  catches regressions (§15.6 #9).

---

## [0.5.0] — 2026-04-22

Workers + cron (§14 v0.5).

### Added
- `jobs.jobs` queue with `SELECT FOR UPDATE SKIP LOCKED`; 4-policy RLS;
  `SECURITY DEFINER` `jobs.enqueue` / `jobs.claim_next` granted to
  `service_role` only (§9.7, `migrations/0007_jobs_schema.sql`).
- `@app.cron(...)` decorator backed by `pg_cron` with `sync_pg_cron()`
  at startup; `InProcScheduler` fallback behind the `cron-inproc`
  extra (§9.7.3).
- `@job(name, version, max_attempts, backoff, queue, role, claims_from,
  accepts_payload)` decorator; idempotency keys; exponential / linear /
  constant backoff.
- Generic hooks system (`hooks.on` / `hooks.fire`); signup → welcome
  email wired through it.
- CLI: `supython worker run` (with SIGINT/SIGTERM drain),
  `supython jobs {list,show,cancel,retry,enqueue}`,
  `supython cron {list,sync}`.
- `POST /jobs/v1/enqueue`, `GET /jobs/v1/jobs`,
  `POST /jobs/v1/jobs/{id}/{cancel,retry}` endpoints.
- Optional `arq` / `dramatiq` extras declared in `pyproject.toml`.

### Changed
- v0.5 grooming pass (§19 2026-04-22): severed `auth → jobs` import edge
  by moving `HookCtx` to `supython.hooks`; collapsed `jobs/backends/`
  into `backends.py`; isolated `croniter` into `cron_inproc.py`; fixed
  `sync_pg_cron` SQL-injection / invalid-JSON f-string; introduced
  `db.as_service_role()`.

### Fixed
- `jobs.enqueue` rewritten as two `return query` branches (the
  `xmax = 0` after `RETURNING ... INTO` was prepare-rejected; idempotency
  hit produced a composite literal that crashed asyncpg).
- `grant usage on schema cron + execute on cron.{schedule,unschedule}
  to service_role` so `sync_pg_cron` registers schedules.
- `sync_pg_cron` hops to a LOGIN role around `cron.schedule` so pg_cron's
  background worker can initialise (`service_role` is NOLOGIN).

---

## [0.4.0] — Realtime v1 (§14 v0.4)

[backfill from git log]

## [0.3.0] — Storage + functions (§14 v0.3)

[backfill from git log]

## [0.2.0] — Make it usable (§14 v0.2)

[backfill from git log]

## [0.1.0] — Prove the core (§14 v0.1)

[backfill from git log]

[Unreleased]: https://github.com/Tkeby/supython/compare/v0.7.0...HEAD
[0.7.0]: https://github.com/Tkeby/supython/compare/v0.6.0...v0.7.0
[0.6.0]: https://github.com/Tkeby/supython/compare/v0.5.0...v0.6.0
[0.5.0]: https://github.com/Tkeby/supython/compare/v0.4.0...v0.5.0
