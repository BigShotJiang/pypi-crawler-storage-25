import os
import subprocess
from typing import Optional


def run_shell(
    argv: list[str],
    cwd: Optional[str] = None,
    env: Optional[dict] = None,
    timeout: int = 30,
) -> dict:
    """Execute argv-based command. No shell interpretation.

    Returns {"stdout": str, "stderr": str, "rc": int}.
    On timeout returns rc=124 with partial output captured so far.
    """
    effective_timeout = min(timeout, 300)

    merged_env = os.environ.copy()
    if env:
        merged_env.update(env)

    try:
        result = subprocess.run(
            argv,
            cwd=cwd,
            env=merged_env,
            capture_output=True,
            timeout=effective_timeout,
        )
        return {
            "stdout": result.stdout.decode("utf-8", errors="replace"),
            "stderr": result.stderr.decode("utf-8", errors="replace"),
            "rc": result.returncode,
        }
    except subprocess.TimeoutExpired as exc:
        stdout = exc.stdout.decode("utf-8", errors="replace") if exc.stdout else ""
        stderr = exc.stderr.decode("utf-8", errors="replace") if exc.stderr else ""
        return {
            "stdout": stdout,
            "stderr": stderr,
            "rc": 124,
        }
