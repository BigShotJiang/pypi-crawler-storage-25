from __future__ import annotations

from dataclasses import dataclass, field

SCHEMA_VERSION: int = 1

EVENT_IDLE: str = "idle"
EVENT_EXIT: str = "exit"
EVENT_MATCH: str = "match"
EVENT_FILE_CHANGE: str = "file_change"
EVENT_TIMEOUT: str = "timeout"

_TERMINAL_EVENTS: frozenset[str] = frozenset(
    {EVENT_IDLE, EVENT_EXIT, EVENT_MATCH, EVENT_FILE_CHANGE, EVENT_TIMEOUT}
)


@dataclass
class Event:
    type: str
    data: dict = field(default_factory=dict)
    schema_version: int = SCHEMA_VERSION

    def to_dict(self) -> dict:
        result = {"type": self.type, "schema_version": self.schema_version}
        result.update(self.data)
        return result

    def is_terminal(self) -> bool:
        return self.type in _TERMINAL_EVENTS
