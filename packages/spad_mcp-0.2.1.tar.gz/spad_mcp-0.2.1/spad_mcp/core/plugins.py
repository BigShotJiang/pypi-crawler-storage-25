from __future__ import annotations

from typing import Iterator, runtime_checkable, Protocol

from .events import Event


@runtime_checkable
class Plugin(Protocol):
    name: str

    def configure(self, config: dict) -> None: ...

    def on_session_start(self, session: object) -> list: ...

    def enrich_event(self, event: Event) -> Event: ...

    def tools(self) -> list[dict]: ...


class PluginHost:
    def __init__(self) -> None:
        self._plugins: dict[str, Plugin] = {}

    def register(self, plugin: Plugin) -> None:
        self._plugins[plugin.name] = plugin

    def configure_all(self, config: dict) -> None:
        for plugin in self._plugins.values():
            plugin.configure(config.get(plugin.name, {}))

    def all_tools(self) -> list[dict]:
        result: list[dict] = []
        for plugin in self._plugins.values():
            result.extend(plugin.tools())
        return result

    def get(self, name: str) -> Plugin | None:
        return self._plugins.get(name)

    def __iter__(self) -> Iterator[Plugin]:
        return iter(self._plugins.values())
