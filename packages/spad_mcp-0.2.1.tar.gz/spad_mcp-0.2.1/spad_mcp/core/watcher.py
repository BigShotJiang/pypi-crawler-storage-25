from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Callable

import inotify_simple

from .events import Event

_IN_FLAGS = (
    inotify_simple.flags.MODIFY
    | inotify_simple.flags.CREATE
    | inotify_simple.flags.DELETE_SELF
    | inotify_simple.flags.MOVE_SELF
)


@dataclass
class FileWatcher:
    path: str
    event: str
    parser: Callable[[str], str | None] | None = None


@dataclass
class _WatchEntry:
    spec: FileWatcher
    dispatch: Callable[[Event], None]
    watch_id: int
    wd: int | None = None
    pos: int = 0
    # leftover bytes from the last read that did not end with a newline
    _buf: str = field(default="", repr=False)


class WatcherHost:
    def __init__(self) -> None:
        self._inotify: inotify_simple.INotify = inotify_simple.INotify()
        self._entries: dict[int, _WatchEntry] = {}
        # wd (inotify watch descriptor) -> watch_id
        self._wd_map: dict[int, int] = {}
        # paths with no inotify watch yet (file did not exist at add() time)
        self._pending: set[int] = set()
        self._next_id: int = 1

    def add(self, spec: FileWatcher, dispatch: Callable[[Event], None]) -> int:
        watch_id = self._next_id
        self._next_id += 1
        entry = _WatchEntry(spec=spec, dispatch=dispatch, watch_id=watch_id)
        self._entries[watch_id] = entry
        self._attach_inotify(entry)
        return watch_id

    def _attach_inotify(self, entry: _WatchEntry) -> None:
        path = entry.spec.path
        if not os.path.exists(path):
            entry.wd = None
            self._pending.add(entry.watch_id)
            return
        try:
            wd = self._inotify.add_watch(path, _IN_FLAGS)
            entry.wd = wd
            self._wd_map[wd] = entry.watch_id
            self._pending.discard(entry.watch_id)
            # seed pos so we don't replay old content
            try:
                entry.pos = os.path.getsize(path)
            except OSError:
                entry.pos = 0
        except OSError:
            entry.wd = None
            self._pending.add(entry.watch_id)

    def remove(self, watch_id: int) -> None:
        entry = self._entries.pop(watch_id, None)
        if entry is None:
            return
        self._pending.discard(watch_id)
        if entry.wd is not None:
            self._wd_map.pop(entry.wd, None)
            try:
                self._inotify.rm_watch(entry.wd)
            except OSError:
                pass

    def poll(self, timeout_ms: int) -> None:
        # retry pending paths first (no inotify cost)
        if self._pending:
            for watch_id in list(self._pending):
                entry = self._entries.get(watch_id)
                if entry is not None:
                    self._attach_inotify(entry)

        events = self._inotify.read(timeout=timeout_ms)
        fired: set[int] = set()

        for ie in events:
            watch_id = self._wd_map.get(ie.wd)
            if watch_id is None:
                continue
            entry = self._entries.get(watch_id)
            if entry is None:
                continue

            flags = inotify_simple.flags.from_mask(ie.mask)

            deleted = any(
                f in flags
                for f in (
                    inotify_simple.flags.DELETE_SELF,
                    inotify_simple.flags.MOVE_SELF,
                )
            )
            if deleted:
                # file gone; clear wd, re-queue as pending for re-creation
                self._wd_map.pop(ie.wd, None)
                entry.wd = None
                entry.pos = 0
                entry._buf = ""
                self._pending.add(watch_id)
                continue

            if inotify_simple.flags.MODIFY in flags or inotify_simple.flags.CREATE in flags:
                fired.add(watch_id)

        for watch_id in fired:
            entry = self._entries.get(watch_id)
            if entry is None:
                continue
            self._process_entry(entry)

    def _process_entry(self, entry: _WatchEntry) -> None:
        path = entry.spec.path
        try:
            size = os.path.getsize(path)
        except OSError:
            return

        # truncation detection
        if size < entry.pos:
            entry.pos = 0
            entry._buf = ""

        if size == entry.pos:
            return

        try:
            with open(path, "r", errors="replace") as fh:
                fh.seek(entry.pos)
                chunk = fh.read(size - entry.pos)
                entry.pos = fh.tell()
        except OSError:
            return

        if entry.spec.parser is None:
            try:
                entry.dispatch(Event(type=entry.spec.event, data={"path": path}))
            except Exception:
                pass
            return

        # line-oriented parser path
        raw = entry._buf + chunk
        lines = raw.split("\n")
        # last element is either "" (chunk ended with newline) or partial line
        entry._buf = lines[-1]
        complete_lines = lines[:-1]

        for line in complete_lines:
            if not line:
                continue
            try:
                result = entry.spec.parser(line)
            except Exception:
                continue
            if result is not None:
                try:
                    entry.dispatch(
                        Event(
                            type=result,
                            data={"path": path, "line": line},
                        )
                    )
                except Exception:
                    pass

    def close(self) -> None:
        self._inotify.close()
        self._entries.clear()
        self._wd_map.clear()
        self._pending.clear()
