import base64
import json
import re
import os
from pathlib import Path
from typing import Optional


def _resolve_range(
    total: int,
    start: Optional[int],
    stop: Optional[int],
) -> tuple[int, int]:
    """Resolve a [start, stop) python-slice pair against a total length.

    - None means open-ended (0 for start, total for stop).
    - Negative values count from end.
    - Clamps to [0, total].
    - Returns (resolved_start, resolved_stop). Caller checks start >= stop.
    """
    if start is None:
        r_start = 0
    elif start < 0:
        r_start = max(0, total + start)
    else:
        r_start = min(start, total)

    if stop is None:
        r_stop = total
    elif stop < 0:
        r_stop = max(0, total + stop)
    else:
        r_stop = min(stop, total)

    return r_start, r_stop


def file_read(
    path: str,
    mode: str = "lines",
    range: Optional[list] = None,
    errors: str = "replace",
) -> dict:
    """Read a file with pythonic slice semantics.

    mode: "lines" (default), "chars", "bytes"
    range: [start, stop) -- 0-indexed, half-open, negative=from-end,
           None values = open-ended.

    Text modes return: {content, units_read, bytes_read, eof}
    Bytes mode returns: {content_b64, bytes_read, eof}
    """
    if mode not in ("lines", "chars", "bytes"):
        raise ValueError(f"mode must be 'lines', 'chars', or 'bytes', got {mode!r}")

    req_start: Optional[int] = None
    req_stop: Optional[int] = None
    if range is not None:
        if len(range) != 2:
            raise ValueError("range must be a 2-element list [start, stop]")
        req_start, req_stop = range[0], range[1]

    file_path = Path(path)
    if not file_path.exists():
        raise FileNotFoundError(f"No such file: {path!r}")
    if not file_path.is_file():
        raise ValueError(f"Path is not a regular file: {path!r}")

    _BYTE_CAP = 8192

    if mode == "bytes":
        raw = file_path.read_bytes()
        total = len(raw)
        r_start, r_stop = _resolve_range(total, req_start, req_stop)
        if r_start >= r_stop:
            chunk = b""
            truncated = False
            eof = r_stop >= total
        else:
            cap_stop = min(r_stop, r_start + _BYTE_CAP)
            chunk = raw[r_start:cap_stop]
            eof = cap_stop >= total
            truncated = cap_stop < r_stop and not eof
        return {
            "content_b64": base64.b64encode(chunk).decode("ascii"),
            "bytes_read": len(chunk),
            "truncated": truncated,
            "eof": eof,
        }

    if mode == "lines":
        _LINE_CAP = 200
        with open(path, "r", encoding="utf-8", errors=errors) as fh:
            all_lines = fh.readlines()
        total = len(all_lines)
        r_start, r_stop = _resolve_range(total, req_start, req_stop)
        if r_start >= r_stop:
            selected: list[str] = []
            truncated = False
            eof = r_stop >= total
        else:
            candidates = all_lines[r_start:r_stop]
            result_lines: list[str] = []
            accum_bytes = 0
            for line in candidates:
                if len(result_lines) >= _LINE_CAP:
                    break
                line_bytes = len(line.encode("utf-8"))
                if accum_bytes + line_bytes > _BYTE_CAP:
                    break
                result_lines.append(line)
                accum_bytes += line_bytes
            selected = result_lines
            actual_stop = r_start + len(selected)
            eof = actual_stop >= total
            truncated = len(selected) < len(candidates) and not eof
        content = "".join(selected)
        units_read = len(selected)
        bytes_read = len(content.encode("utf-8"))
        return {
            "content": content,
            "units_read": units_read,
            "bytes_read": bytes_read,
            "truncated": truncated,
            "eof": eof,
        }

    # mode == "chars"
    _CHAR_CAP = 8000
    with open(path, "r", encoding="utf-8", errors=errors) as fh:
        full_text = fh.read()
    total = len(full_text)
    r_start, r_stop = _resolve_range(total, req_start, req_stop)
    if r_start >= r_stop:
        chunk_str = ""
        truncated = False
        eof = r_stop >= total
    else:
        candidate = full_text[r_start:r_stop]
        # Apply char cap then byte cap (whichever fires first).
        char_capped = candidate[:_CHAR_CAP]
        encoded = char_capped.encode("utf-8")
        if len(encoded) > _BYTE_CAP:
            # Truncate to BYTE_CAP bytes without splitting a multibyte char.
            chunk_str = encoded[:_BYTE_CAP].decode("utf-8", errors="ignore")
        else:
            chunk_str = char_capped
        actual_stop = r_start + len(chunk_str)
        eof = actual_stop >= total
        truncated = len(chunk_str) < len(candidate) and not eof
    units_read = len(chunk_str)
    bytes_read = len(chunk_str.encode("utf-8"))
    return {
        "content": chunk_str,
        "units_read": units_read,
        "bytes_read": bytes_read,
        "truncated": truncated,
        "eof": eof,
    }


def file_write(path: str, content: str, overwrite: bool = False) -> dict:
    """Write text content to a file.

    Refuses if file exists unless overwrite=True.
    Returns {"ok": True, "bytes": int}.
    """
    file_path = Path(path)
    if file_path.exists() and not overwrite:
        raise FileExistsError(
            f"file exists at {path}. Use overwrite=true to replace, "
            "or file_edit/file_insert to modify in place."
        )
    file_path.parent.mkdir(parents=True, exist_ok=True)
    encoded = content.encode("utf-8")
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(content)
    return {"ok": True, "bytes": len(encoded)}


def file_edit(path: str, old: str, new: str, all: bool = False) -> dict:
    """Surgical string replacement in a file.

    If all=False, exactly one occurrence must exist (error otherwise).
    If all=True, replace every occurrence.
    Returns {"replacements": int}.
    """
    _CAP = 65536
    new_bytes = len(new.encode("utf-8"))
    if new_bytes > _CAP:
        raise ValueError(
            f"new string exceeds 64KB sanity cap (got {new_bytes} bytes). "
            "For new files use file_write; for bulk content use scp or /spad/upload (OOB)."
        )
    file_path = Path(path)
    if not file_path.exists():
        raise FileNotFoundError(
            f"file does not exist at {path}. Use file_write to create new files; "
            "file_edit only modifies existing files."
        )

    content = file_path.read_text(encoding="utf-8", errors="replace")
    count = content.count(old)

    if not all:
        if count == 0:
            raise ValueError(f"String not found in {path!r}")
        if count > 1:
            raise ValueError(
                f"String found {count} times in {path!r}; use all=True to replace all"
            )
        new_content = content.replace(old, new, 1)
        replacements = 1
    else:
        if count == 0:
            raise ValueError(f"String not found in {path!r}")
        new_content = content.replace(old, new)
        replacements = count

    file_path.write_text(new_content, encoding="utf-8")
    return {"replacements": replacements}


def file_grep(
    root: str,
    pattern: str,
    glob: Optional[str] = None,
) -> dict:
    """Regex search across files under root, optionally filtered by glob pattern.

    Returns {matches, truncated, match_count}. matches is capped at 8KB of
    serialized content. match_count is total matches found (even if truncated).
    line is 1-indexed.
    """
    _BYTE_CAP = 8192
    compiled = re.compile(pattern)
    root_path = Path(root)
    if not root_path.is_dir():
        raise ValueError(f"root is not a directory: {root!r}")

    if glob is not None:
        candidates = list(root_path.rglob(glob))
    else:
        candidates = [p for p in root_path.rglob("*") if p.is_file()]

    matches: list[dict] = []
    total_bytes = 0
    truncated = False
    match_count = 0
    for file_path in sorted(candidates):
        if not file_path.is_file():
            continue
        try:
            text = file_path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        for lineno, line_text in enumerate(text.splitlines(), start=1):
            if compiled.search(line_text):
                match_count += 1
                if not truncated:
                    entry: dict = {
                        "path": str(file_path),
                        "line": lineno,
                        "text": line_text,
                    }
                    entry_bytes = len(json.dumps(entry).encode("utf-8"))
                    if total_bytes + entry_bytes > _BYTE_CAP:
                        truncated = True
                    else:
                        matches.append(entry)
                        total_bytes += entry_bytes

    return {"matches": matches, "truncated": truncated, "match_count": match_count}


def file_glob(root: str, pattern: str) -> dict:
    """Glob pattern under root directory.

    Returns {files, truncated, match_count}. files is capped at 8KB of
    serialized content. match_count is total paths found (even if truncated).
    Paths are absolute.
    """
    _BYTE_CAP = 8192
    root_path = Path(root)
    if not root_path.is_dir():
        raise ValueError(f"root is not a directory: {root!r}")

    files: list[str] = []
    total_bytes = 0
    truncated = False
    match_count = 0
    for p in sorted(root_path.glob(pattern)):
        path_str = str(p.resolve())
        match_count += 1
        if not truncated:
            entry_bytes = len(json.dumps(path_str).encode("utf-8"))
            if total_bytes + entry_bytes > _BYTE_CAP:
                truncated = True
            else:
                files.append(path_str)
                total_bytes += entry_bytes

    return {"files": files, "truncated": truncated, "match_count": match_count}


def file_insert(
    path: str,
    content: str,
    position: str = "after",
    anchor: Optional[str] = None,
) -> dict:
    """Insert content at a position within an existing file.

    position: "start" | "end" | "before" | "after"
    anchor: required for "before"/"after"; substring matched against lines.
    File must already exist -- use file_write to create new files.
    Returns {"ok": True, "line": int} where line is 1-indexed.
    """
    if position not in ("start", "end", "before", "after"):
        raise ValueError(
            f"position must be 'start', 'end', 'before', or 'after', got {position!r}"
        )

    file_path = Path(path)
    if not file_path.exists():
        raise FileNotFoundError(
            f"file does not exist at {path}. Use file_write to create new files; "
            "file_insert only adds to existing files."
        )

    if position in ("start", "end") and anchor is not None:
        raise ValueError(
            f"anchor must not be provided when position is {position!r}"
        )
    if position in ("before", "after") and anchor is None:
        raise ValueError(
            f"anchor is required when position is {position!r}"
        )

    _CAP = 65536
    content_bytes = len(content.encode("utf-8"))
    if content_bytes > _CAP:
        raise ValueError(
            f"content exceeds 64KB sanity cap (got {content_bytes} bytes). "
            "For new files use file_write; for bulk content use scp or /spad/upload (OOB)."
        )

    if not content.endswith("\n"):
        content = content + "\n"

    with open(path, "r", encoding="utf-8", errors="replace") as fh:
        lines = fh.readlines()

    if position == "start":
        lines.insert(0, content)
        result_line = 1
    elif position == "end":
        lines.append(content)
        result_line = len(lines)
    else:
        # before or after -- find first anchor match
        anchor_idx = None
        for i, line in enumerate(lines):
            if anchor in line:  # type: ignore[operator]
                anchor_idx = i
                break
        if anchor_idx is None:
            raise ValueError(f"Anchor {anchor!r} not found in {path!r}")
        insert_idx = anchor_idx + 1 if position == "after" else anchor_idx
        lines.insert(insert_idx, content)
        result_line = insert_idx + 1

    with open(path, "w", encoding="utf-8") as fh:
        fh.writelines(lines)

    return {"ok": True, "line": result_line}
