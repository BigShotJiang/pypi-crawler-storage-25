from spad_mcp.server import main

main()
