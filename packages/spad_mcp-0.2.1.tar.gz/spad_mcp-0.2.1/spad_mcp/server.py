"""spad-mcp server entry point."""

from __future__ import annotations

import argparse
import logging
import threading
from pathlib import Path
from typing import Optional

import tomllib
import fastmcp
from starlette.requests import Request
from starlette.responses import JSONResponse, Response, StreamingResponse

from spad_mcp.core import files as _files
from spad_mcp.core import shell as _shell
from spad_mcp.core.watcher import WatcherHost
from spad_mcp.core.plugins import PluginHost

__version__ = "0.1.0"

log = logging.getLogger(__name__)


def _load_config(config_path: Optional[str]) -> dict:
    if config_path is None:
        config_path = str(Path(__file__).parent / "config" / "default.toml")
    with open(config_path, "rb") as fh:
        return tomllib.load(fh)


def _start_watcher_thread(watcher: WatcherHost) -> threading.Thread:
    stop_event = threading.Event()

    def _loop() -> None:
        while not stop_event.is_set():
            try:
                watcher.poll(100)
            except Exception:
                pass

    t = threading.Thread(target=_loop, daemon=True, name="spad-watcher")
    t.stop_event = stop_event  # type: ignore[attr-defined]
    t.start()
    return t


def _load_cc_plugin(config: dict, plugin_host: PluginHost) -> None:
    cc_cfg = config.get("plugins", {}).get("claude-code", {})
    if not cc_cfg.get("enabled", True):
        return
    try:
        from spad_mcp.plugins.claude_code import ClaudeCodePlugin  # type: ignore
        plugin = ClaudeCodePlugin()
        plugin.configure(cc_cfg)
        plugin_host.register(plugin)
        log.info("claude-code plugin loaded")
    except ImportError:
        log.warning("spad_mcp.plugins.claude_code not found -- skipping (phase 3)")


def _register_tmux_tools(
    mcp: fastmcp.FastMCP,
    plugin_host: PluginHost,
    watcher: WatcherHost,
) -> None:
    try:
        import spad_mcp.adapters.tmux as _tmux  # type: ignore
        if hasattr(_tmux, "register_tmux_tools"):
            _tmux.register_tmux_tools(mcp, plugin_host, watcher)
            log.info("tmux adapter registered")
        else:
            log.warning("spad_mcp.adapters.tmux has no register_tmux_tools -- skipping")
    except ImportError:
        log.warning("tmux adapter not available (install spad-mcp[tmux] for tmux tools)")


def build_server(config: dict) -> tuple[fastmcp.FastMCP, WatcherHost, PluginHost]:
    mcp = fastmcp.FastMCP("spad-mcp", version=__version__)
    watcher = WatcherHost()
    plugin_host = PluginHost()

    _load_cc_plugin(config, plugin_host)

    @mcp.tool(description=(
        "Execute an argv-based command on the host. "
        "No shell interpretation -- pass ['bash', '-c', '...'] explicitly for pipes/globs. "
        "Returns {stdout, stderr, rc}."
    ))
    def shell(
        argv: list[str],
        cwd: Optional[str] = None,
        env: Optional[dict] = None,
        timeout: int = 30,
    ) -> dict:
        try:
            return _shell.run_shell(argv, cwd=cwd, env=env, timeout=timeout)
        except Exception as exc:
            raise ValueError(str(exc)) from exc

    @mcp.tool(description=(
        "file_read is surgical, not bulk. Returns at most 8KB or 200 units per call. "
        "Use file_grep and file_glob to locate content first; use file_edit to modify "
        "without reading. For bulk transfer, use scp or /spad/download (OOB). "
        "IMPORTANT: range is 0-indexed half-open [start, stop) -- "
        "editor line numbers are 1-indexed, subtract 1 before passing. "
        "mode: lines (default), chars, bytes. Negative start/stop counts from end. null = open-ended."
    ))
    def file_read(
        path: str,
        mode: str = "lines",
        range: Optional[list] = None,
        errors: str = "replace",
    ) -> dict:
        try:
            return _files.file_read(path, mode=mode, range=range, errors=errors)
        except (FileNotFoundError, ValueError) as exc:
            raise ValueError(str(exc)) from exc

    @mcp.tool(description=(
        "file_write creates new files from agent-generated content. "
        "Refuses if file exists unless overwrite=true. "
        "Never use to write back content that originated from file_read -- "
        "that is read-modify-write, the anti-pattern this toolset is designed to prevent. "
        "Use file_edit for in-place modification."
    ))
    def file_write(
        path: str,
        content: str,
        overwrite: bool = False,
    ) -> dict:
        try:
            return _files.file_write(path, content, overwrite=overwrite)
        except (FileExistsError, Exception) as exc:
            raise ValueError(str(exc)) from exc

    @mcp.tool(description=(
        "file_edit modifies files in place via old-string/new-string replacement. "
        "Does not require reading the file first. "
        "Preferred over read-modify-write for any single-location change. "
        "Errors if file does not exist. "
        "all=False (default) requires exactly one match. all=True replaces all occurrences. "
        "Returns {replacements}."
    ))
    def file_edit(
        path: str,
        old: str,
        new: str,
        all: bool = False,
    ) -> dict:
        try:
            return _files.file_edit(path, old, new, all=all)
        except (FileNotFoundError, ValueError) as exc:
            raise ValueError(str(exc)) from exc

    @mcp.tool(description=(
        "file_grep returns at most 8KB of match text. "
        "If truncated, narrow the pattern with a more specific regex or glob filter "
        "rather than paginating. "
        "Regex search across files under root directory, optional glob file filter. "
        "Returns {matches: [{path, line, text}], truncated, match_count}. line is 1-indexed."
    ))
    def file_grep(
        root: str,
        pattern: str,
        glob: Optional[str] = None,
    ) -> dict:
        try:
            return _files.file_grep(root, pattern, glob=glob)
        except ValueError as exc:
            raise ValueError(str(exc)) from exc

    @mcp.tool(description=(
        "file_glob returns at most 8KB of path text. "
        "If truncated, narrow with a more specific pattern or root. "
        "Use **/*.py for recursive; bare *.py matches root-level only. "
        "Returns {files: [str], truncated, match_count}."
    ))
    def file_glob(
        root: str,
        pattern: str,
    ) -> dict:
        try:
            return _files.file_glob(root, pattern)
        except ValueError as exc:
            raise ValueError(str(exc)) from exc

    @mcp.tool(description=(
        "file_insert adds content at a position (start, end, before, after). "
        "Purely additive -- never removes existing content. "
        "Errors if file does not exist; use file_write to create new files. "
        "anchor required for before/after; not allowed for start/end. "
        "Returns {ok, line} (1-indexed)."
    ))
    def file_insert(
        path: str,
        content: str,
        position: str = "after",
        anchor: Optional[str] = None,
    ) -> dict:
        try:
            return _files.file_insert(path, content, position, anchor=anchor)
        except (FileNotFoundError, ValueError) as exc:
            raise ValueError(str(exc)) from exc

    @mcp.tool(description="Server status: version, loaded plugins, and per-plugin bound paths.")
    def status() -> dict:
        plugins_list = [p.name for p in plugin_host]
        bound_paths: dict[str, object] = {}
        extra: dict[str, object] = {}
        for p in plugin_host:
            bound_paths[p.name] = getattr(p, "bound_path", None)
            if hasattr(p, "status"):
                extra[p.name] = p.status()
        result: dict[str, object] = {
            "ok": True,
            "version": __version__,
            "plugins": plugins_list,
            "bound_paths": bound_paths,
        }
        result.update(extra)
        return result

    _CHUNK = 65536  # 64KB transfer chunk size

    @mcp.custom_route("/spad/upload", methods=["POST"])
    async def spad_upload(request: Request) -> Response:
        """OOB bulk file upload. POST /spad/upload?path=<absolute>[&overwrite=true].
        Body is raw file bytes (streamed). Trust model: same as MCP tools --
        whoever can reach this port has full host file-write access.
        Returns {ok, bytes} on success; error JSON on failure.
        """
        path_str = request.query_params.get("path")
        if not path_str:
            return JSONResponse({"error": "path query param required"}, status_code=400)
        upload_path = Path(path_str)
        if not upload_path.is_absolute():
            return JSONResponse({"error": "path must be absolute"}, status_code=400)

        overwrite_raw = request.query_params.get("overwrite", "false").lower()
        overwrite = overwrite_raw in ("true", "1", "yes")

        if upload_path.exists() and not overwrite:
            return JSONResponse(
                {"error": f"file exists at {path_str}"},
                status_code=409,
            )

        try:
            upload_path.parent.mkdir(parents=True, exist_ok=True)
            bytes_written = 0
            with open(upload_path, "wb") as fh:
                async for chunk in request.stream():
                    fh.write(chunk)
                    bytes_written += len(chunk)
            return JSONResponse({"ok": True, "bytes": bytes_written})
        except OSError as exc:
            return JSONResponse({"error": str(exc)}, status_code=500)

    @mcp.custom_route("/spad/download", methods=["GET"])
    async def spad_download(request: Request) -> Response:
        """OOB bulk file download. GET /spad/download?path=<absolute>.
        Streams file body with Content-Length and Content-Type: application/octet-stream.
        Trust model: same as MCP tools -- whoever can reach this port has full
        host file-read access.
        Returns 404 if file missing; 400 if path invalid.
        """
        path_str = request.query_params.get("path")
        if not path_str:
            return JSONResponse({"error": "path query param required"}, status_code=400)
        download_path = Path(path_str)
        if not download_path.is_absolute():
            return JSONResponse({"error": "path must be absolute"}, status_code=400)
        if not download_path.exists():
            return JSONResponse(
                {"error": f"no such file at {path_str}"},
                status_code=404,
            )

        file_size = download_path.stat().st_size

        async def _iter() -> None:
            with open(download_path, "rb") as fh:
                while True:
                    chunk = fh.read(_CHUNK)
                    if not chunk:
                        break
                    yield chunk

        return StreamingResponse(
            _iter(),
            media_type="application/octet-stream",
            headers={"Content-Length": str(file_size)},
        )

    _register_tmux_tools(mcp, plugin_host, watcher)

    for tool_def in plugin_host.all_tools():
        log.debug("registering plugin tool: %s", tool_def.get("name"))

    return mcp, watcher, plugin_host


def main() -> None:
    parser = argparse.ArgumentParser(description="spad-mcp MCP server")
    parser.add_argument("--host", default=None, help="Bind host (overrides config)")
    parser.add_argument("--port", type=int, default=None, help="Bind port (overrides config)")
    parser.add_argument("--config", default=None, help="Path to config YAML")
    args = parser.parse_args()

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )

    config = _load_config(args.config)
    server_cfg = config.get("server", {})

    host = args.host or server_cfg.get("host", "127.0.0.1")
    port = args.port or server_cfg.get("port", 9830)

    mcp, watcher, _plugin_host = build_server(config)
    watcher_thread = _start_watcher_thread(watcher)

    log.info("spad-mcp %s starting on %s:%d", __version__, host, port)
    try:
        mcp.run(transport="http", host=host, port=port)
    finally:
        watcher_thread.stop_event.set()  # type: ignore[attr-defined]
        watcher.close()
        log.info("spad-mcp stopped")


if __name__ == "__main__":
    main()
