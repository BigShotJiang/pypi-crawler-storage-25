"""spad-mcp tmux adapter.

Registers tmux_* MCP tools on the provided fastmcp server instance.
Requires the [tmux] extra (libtmux). Import fails fast if libtmux is absent --
the server wraps this module import in try/except and skips tmux tools cleanly.
"""

from __future__ import annotations

import os
import re
import shlex
import threading
import time
import uuid
from typing import Any, Optional

import libtmux

from spad_mcp.core.events import Event, EVENT_IDLE, EVENT_EXIT, EVENT_MATCH, EVENT_FILE_CHANGE, EVENT_TIMEOUT
from spad_mcp.core.watcher import FileWatcher, WatcherHost
from spad_mcp.core.plugins import PluginHost

# -- Module-level session registry --
# Maps session name -> _SessionEntry. Single server process; module-level state is fine.

_SESSIONS: dict[str, "_SessionEntry"] = {}
_SESSIONS_LOCK = threading.Lock()

_DEFAULT_SESSION = "spad"
_POLL_INTERVAL = 0.2


class _SessionEntry:
    def __init__(
        self,
        name: str,
        session: libtmux.Session,
        pane: libtmux.Pane,
        pid: int,
        plugin_name: Optional[str],
        watcher_ids: list[int],
    ) -> None:
        self.name = name
        self.session = session
        self.pane = pane
        self.pid = pid
        self.plugin_name = plugin_name
        self.watcher_ids = watcher_ids


def _get_pane(session_name: str) -> tuple["_SessionEntry", libtmux.Pane]:
    """Resolve session name to registry entry + pane. Raises ValueError if unknown."""
    with _SESSIONS_LOCK:
        entry = _SESSIONS.get(session_name)
    if entry is None:
        raise ValueError(f"unknown session: {session_name!r} -- use tmux_session_create first")
    return entry, entry.pane


def _find_pane_by_name(server: libtmux.Server, session_name: str) -> Optional[libtmux.Pane]:
    """Return first pane of first window in named session, or None."""
    try:
        session = server.find_where({"session_name": session_name})
        if session is None:
            return None
        window = session.active_window or session.windows[0]
        return window.active_pane or window.panes[0]
    except Exception:
        return None


def _capture_pane(pane: libtmux.Pane, lines: int = 50) -> str:
    """Capture last `lines` of pane output as a string."""
    result = pane.cmd("capture-pane", "-p", f"-S-{lines}")
    return "\n".join(result.stdout)


def _pid_alive(pid: int) -> bool:
    """Check if a PID exists in /proc without sending signals."""
    return os.path.exists(f"/proc/{pid}")


def _walk_foreground_pid(shell_pid: int) -> int:
    """Walk /proc/<pid>/task/<pid>/children to find the deepest single-child process.

    Tmux gives us the shell PID. The real foreground program (e.g. claude) is a
    child of that shell. We descend until we find a leaf or a fork. Returns the
    deepest single-descendant PID, or the original shell_pid if no children found.
    """
    current = shell_pid
    for _ in range(16):  # depth cap -- avoid infinite loops on pathological process trees
        children_path = f"/proc/{current}/task/{current}/children"
        try:
            with open(children_path, "r") as fh:
                raw = fh.read().strip()
        except OSError:
            break
        if not raw:
            break
        child_pids = [int(p) for p in raw.split() if p.isdigit()]
        if len(child_pids) == 1:
            current = child_pids[0]
        else:
            # Multiple children (e.g. shell spawned pipeline) -- stop here
            break
    return current


def _send_array(pane: libtmux.Pane, send: list[str]) -> None:
    """Execute the send array: s: for literal text, k: for key names."""
    for item in send:
        if item.startswith("s:"):
            text = item[2:]
            pane.send_keys(text, literal=True, enter=False)
        elif item.startswith("k:"):
            key = item[2:]
            pane.send_keys(key, literal=False, enter=False)
        else:
            raise ValueError(
                f"send element has no prefix: {item!r} -- "
                "use 's:' for literal text or 'k:' for key names"
            )


def _wait_for_events(
    pane: libtmux.Pane,
    entry: Optional[_SessionEntry],
    wait: dict,
    watcher_host: WatcherHost,
    plugin_host: PluginHost,
) -> dict:
    """Arm event sources, poll until first fires, return result dict."""
    events_spec: list = wait.get("events", [])
    timeout: float = float(wait.get("timeout", 30))

    start = time.monotonic()
    deadline = start + timeout

    # Shared firing state -- first event to set these wins.
    fired_event: list[Optional[Event]] = [None]
    fired_lock = threading.Lock()

    def _try_fire(ev: Event) -> None:
        with fired_lock:
            if fired_event[0] is None:
                fired_event[0] = ev

    # -- Arm file_change and idle watches via watcher_host --
    # Watches are armed BEFORE send so no inotify events are missed.
    # For pane-match events we capture a "before" pane offset to skip pre-existing matches.
    # This is the race-fix: arm inotify watches first, then capture baseline, then send.
    # Any file change that occurs between send and first poll will have been queued by
    # inotify already, so we never miss it. (rig.py uses a JSONL byte-mark for the same
    # reason -- we use pre-armed inotify + pane-line offset instead of a sentinel echo.)

    temp_watcher_ids: list[int] = []

    for spec in events_spec:
        if spec == "idle":
            # idle comes from plugin file watchers already registered for this session.
            # We subscribe a one-shot dispatch into _try_fire.
            if entry is not None and entry.plugin_name is not None:
                plugin = plugin_host.get(entry.plugin_name)
                if plugin is not None:
                    # Re-use the existing watcher entries bound to this session by
                    # adding a transient overlay watcher that fires the idle signal.
                    # Simpler: arm a plain FileWatcher if the plugin exposes bound_path.
                    bound_path = getattr(plugin, "bound_path", None)
                    if bound_path:
                        def _idle_dispatch(ev: Event) -> None:
                            if ev.type == EVENT_IDLE:
                                enriched = plugin.enrich_event(ev)
                                _try_fire(enriched)
                        fw = FileWatcher(path=bound_path, event=EVENT_IDLE,
                                         parser=getattr(plugin, "_parse_jsonl_line", None))
                        wid = watcher_host.add(fw, _idle_dispatch)
                        temp_watcher_ids.append(wid)

        elif isinstance(spec, dict) and "file_change" in spec:
            path = spec["file_change"]

            def _fc_dispatch(ev: Event, _path: str = path) -> None:
                _try_fire(Event(type=EVENT_FILE_CHANGE, data={"path": _path}))

            fw = FileWatcher(path=path, event=EVENT_FILE_CHANGE)
            wid = watcher_host.add(fw, _fc_dispatch)
            temp_watcher_ids.append(wid)

    # Capture pane baseline AFTER arming watches but BEFORE sending.
    # pane_offset = number of lines currently in pane so match checks only look at NEW lines.
    try:
        before_lines = _capture_pane(pane, lines=500).splitlines()
        pane_offset = len(before_lines)
    except Exception:
        pane_offset = 0

    # Compile match patterns keyed by spec index for tiebreak-ordered dispatch
    # KB-1: index preserves declared order so same-tick checks follow events list
    match_patterns_by_idx: dict[int, re.Pattern] = {}
    for i, spec in enumerate(events_spec):
        if isinstance(spec, dict) and "match" in spec:
            try:
                match_patterns_by_idx[i] = re.compile(spec["match"])
            except re.error as exc:
                raise ValueError(f"invalid match regex {spec['match']!r}: {exc}") from exc

    bound_pid = entry.pid if entry is not None else None
    has_match_specs = bool(match_patterns_by_idx)

    try:
        # Poll loop -- iterate events_spec in declared order each tick for same-tick tiebreak
        while time.monotonic() < deadline:
            if fired_event[0] is not None:
                break

            # Capture new pane lines once per tick if match specs exist
            # KB-2: capture per-line so we can report the full containing line
            new_lines: list[str] | None = None
            if has_match_specs:
                try:
                    current_lines = _capture_pane(pane, lines=500).splitlines()
                    new_lines = current_lines[pane_offset:]
                except Exception:
                    new_lines = []

            # KB-1: check each event type in declared order (same-tick tiebreak follows events list)
            for i, spec in enumerate(events_spec):
                if fired_event[0] is not None:
                    break
                if spec == "exit":
                    if bound_pid is not None and not _pid_alive(bound_pid):
                        _try_fire(Event(type=EVENT_EXIT, data={"pid": bound_pid}))
                elif isinstance(spec, dict) and "match" in spec:
                    pat = match_patterns_by_idx.get(i)
                    if pat is not None and new_lines:
                        for line in new_lines:
                            m = pat.search(line)
                            if m:
                                # KB-2: "line" is the full containing line; "text" is the match
                                _try_fire(Event(type=EVENT_MATCH,
                                                data={"text": m.group(), "line": line}))
                                break
                # idle and file_change fire via async callbacks -- no inline check needed

            time.sleep(_POLL_INTERVAL)

        elapsed = time.monotonic() - start
        ev = fired_event[0]
        if ev is None:
            return {"ok": False, "event": EVENT_TIMEOUT, "elapsed": round(elapsed, 2)}

        result: dict[str, Any] = {"ok": True, "event": ev.type, "elapsed": round(elapsed, 2)}
        result.update(ev.data)
        return result

    finally:
        # Always clean up transient watchers we added
        for wid in temp_watcher_ids:
            watcher_host.remove(wid)


def register_tmux_tools(
    mcp_server: Any,
    plugin_host: PluginHost,
    watcher_host: WatcherHost,
) -> None:
    """Register all tmux_* MCP tools on mcp_server.

    Conditional on libtmux being importable.
    Raises ImportError if libtmux is missing -- the server catches that.
    """

    _libtmux_server = libtmux.Server()

    # ------------------------------------------------------------------ #
    # tmux_interact                                                        #
    # ------------------------------------------------------------------ #

    @mcp_server.tool(description=(
        "Send input to a tmux session and optionally wait for events. "
        "send: list of prefixed strings -- 's:text' for literal text (paste-style), "
        "'k:keyname' for tmux keys (Enter, C-c, Tab, etc.). No prefix is an error. "
        "wait: {events: [...], timeout: int}. Events: 'idle' (plugin file watcher), "
        "'exit' (session PID gone), {'match': 'regex'} (pane content), "
        "{'file_change': '/path'} (inotify). First event wins. "
        "Without wait returns {sent: true} -- tmux accepted keys, NOT confirmation "
        "the program received or processed them. "
        "session: defaults to configured session or 'spad'."
    ))
    def tmux_interact(
        send: Optional[list[str]] = None,
        wait: Optional[dict] = None,
        session: Optional[str] = None,
    ) -> dict:
        session_name = session or _DEFAULT_SESSION

        try:
            entry, pane = _get_pane(session_name)
        except ValueError as exc:
            raise ValueError(str(exc)) from exc

        try:
            if send:
                if wait:
                    # Arm watches BEFORE send so no events are missed between send and first poll.
                    # _wait_for_events captures pane baseline then calls back to us -- but we
                    # can't split arm/send/poll across a function boundary cleanly here, so we
                    # pass send into the wait helper and it handles ordering internally.
                    # We do the send inside _wait_for_events's arm-baseline-send sequence.
                    # To keep the interface simple, do arm+baseline here, then send, then poll.

                    # Inline the race-fix sequence directly:
                    # 1. arm watches (done inside _wait_for_events before it returns the closure)
                    # 2. capture baseline -- done inside _wait_for_events before send
                    # 3. send user input
                    # 4. poll
                    # We thread this by having _wait_for_events accept a pre_send callback.
                    # Simpler: call _send_array inside _wait_for_events via a hook.
                    # Simplest: arm+baseline in _wait_for_events, then pass a flag to send first.
                    # We implement this by calling _wait_for_events with the send array.
                    return _wait_for_events_with_send(
                        pane, entry, wait, watcher_host, plugin_host, send
                    )
                else:
                    _send_array(pane, send)
                    return {"sent": True}
            elif wait:
                return _wait_for_events(pane, entry, wait, watcher_host, plugin_host)
            else:
                return {"sent": False, "note": "no send and no wait -- nothing to do"}

        except ValueError:
            raise
        except Exception as exc:
            raise ValueError(f"tmux_interact error: {exc}") from exc

    # ------------------------------------------------------------------ #
    # tmux_screenshot                                                      #
    # ------------------------------------------------------------------ #

    @mcp_server.tool(description=(
        "Capture tmux pane content. "
        "session: session name (default 'spad'). "
        "lines: number of lines to capture (default 50)."
    ))
    def tmux_screenshot(
        session: Optional[str] = None,
        lines: int = 50,
    ) -> dict:
        session_name = session or _DEFAULT_SESSION
        try:
            _entry, pane = _get_pane(session_name)
        except ValueError as exc:
            raise ValueError(str(exc)) from exc
        try:
            content = _capture_pane(pane, lines=lines)
            return {"content": content}
        except Exception as exc:
            raise ValueError(f"tmux_screenshot error: {exc}") from exc

    # ------------------------------------------------------------------ #
    # tmux_sessions                                                        #
    # ------------------------------------------------------------------ #

    @mcp_server.tool(description="List available tmux session names.")
    def tmux_sessions() -> dict:
        try:
            sessions = _libtmux_server.sessions
            return {"sessions": [s.session_name for s in sessions]}
        except Exception as exc:
            raise ValueError(f"tmux_sessions error: {exc}") from exc

    # ------------------------------------------------------------------ #
    # tmux_session_create                                                  #
    # ------------------------------------------------------------------ #

    @mcp_server.tool(description=(
        "Create a new tmux session running a command. "
        "command: argv array -- honored as no-shell at the API surface; tmux itself "
        "receives a string via shlex.join (tmux does not accept argv arrays natively). "
        "cwd: working directory. "
        "env: additional environment variables (set before session window starts). "
        "plugin: plugin name for event enrichment (e.g. 'claude-code'). "
        "Returns {ok, session, pid}."
    ))
    def tmux_session_create(
        name: str,
        command: list[str],
        cwd: Optional[str] = None,
        env: Optional[dict] = None,
        plugin: Optional[str] = None,
    ) -> dict:
        cmd_str = shlex.join(command)

        # Build session environment.
        # Propagate CLAUDE_CONFIG_DIR from the spad server's own env so CC
        # sessions use the same config/projects directory as the server process.
        # The tmux server may have a DIFFERENT CLAUDE_CONFIG_DIR (e.g. .sandy)
        # that is not writable, which prevents CC from creating JSONL transcripts.
        # User-supplied env takes precedence over automatic propagation.
        session_env: dict[str, str] = {}
        claude_config = os.environ.get("CLAUDE_CONFIG_DIR")
        if claude_config:
            session_env["CLAUDE_CONFIG_DIR"] = claude_config
        if env:
            session_env.update(env)

        kwargs: dict[str, Any] = {
            "session_name": name,
            "window_command": cmd_str,
        }
        if cwd:
            kwargs["start_directory"] = cwd
        if session_env:
            kwargs["environment"] = session_env

        # Validate plugin and take pre-start JSONL snapshot BEFORE new_session().
        # CC writes its transcript file within milliseconds of startup; if the
        # snapshot is taken after new_session() the new file lands in "before"
        # and discovery never fires. pre_start() must be called here -- before
        # the tmux session (and CC) actually starts.
        plug = None
        if plugin is not None:
            plug = plugin_host.get(plugin)
            if plug is None:
                raise ValueError(f"unknown plugin: {plugin!r}")
            if hasattr(plug, "pre_start"):
                plug.pre_start()

        try:
            session = _libtmux_server.new_session(**kwargs)
        except Exception as exc:
            raise ValueError(f"failed to create tmux session {name!r}: {exc}") from exc

        # Apply any remaining env vars via set-environment (for compat / legacy callers).
        if env:
            for k, v in env.items():
                try:
                    session.cmd("set-environment", k, str(v))
                except Exception:
                    pass  # non-fatal; env may have already been picked up by window_command

        try:
            window = session.active_window or session.windows[0]
            pane = window.active_pane or window.panes[0]
        except Exception as exc:
            raise ValueError(f"could not get pane for session {name!r}: {exc}") from exc

        # pane_pid is the shell / launched-program PID from tmux
        try:
            shell_pid = int(pane.pane_pid)
        except (TypeError, ValueError, AttributeError) as exc:
            raise ValueError(f"could not read pane_pid for session {name!r}: {exc}") from exc

        # Walk children to find the deepest single-descendant foreground PID.
        # The shell may have exec'd the target program as its only child.
        foreground_pid = _walk_foreground_pid(shell_pid)

        watcher_ids: list[int] = []

        # Plugin session-start hook
        if plug is not None:
            # Build a minimal session descriptor the plugin can inspect
            session_obj = _SessionDescriptor(
                name=name,
                pane_pid=foreground_pid,
                pane=pane,
            )

            watch_specs = plug.on_session_start(session_obj)

            for spec in (watch_specs or []):
                if isinstance(spec, FileWatcher):
                    def _dispatch(ev: Event, _p: str = spec.path) -> None:
                        # idle events from plugin watchers carry the plugin's event type
                        pass  # the wait loop subscribes its own dispatch; this is a no-op holder
                    wid = watcher_host.add(spec, _dispatch)
                    watcher_ids.append(wid)

        entry = _SessionEntry(
            name=name,
            session=session,
            pane=pane,
            pid=foreground_pid,
            plugin_name=plugin,
            watcher_ids=watcher_ids,
        )
        with _SESSIONS_LOCK:
            _SESSIONS[name] = entry

        return {"ok": True, "session": name, "pid": foreground_pid}

    # ------------------------------------------------------------------ #
    # tmux_session_destroy                                                 #
    # ------------------------------------------------------------------ #

    @mcp_server.tool(description=(
        "Destroy a tmux session. Sends signal to bound PID first (graceful), "
        "then kills the tmux session. "
        "signal: signal name (default 'TERM'). Returns {ok}."
    ))
    def tmux_session_destroy(
        name: str,
        signal: str = "TERM",
    ) -> dict:
        with _SESSIONS_LOCK:
            entry = _SESSIONS.get(name)

        if entry is None:
            raise ValueError(f"unknown session: {name!r}")

        # Graceful: send signal to bound PID
        sig_num = _resolve_signal(signal)
        if _pid_alive(entry.pid):
            try:
                os.kill(entry.pid, sig_num)
            except ProcessLookupError:
                pass
            except PermissionError as exc:
                raise ValueError(f"cannot signal PID {entry.pid}: {exc}") from exc

        # Clean up watcher entries scoped to this session
        for wid in entry.watcher_ids:
            watcher_host.remove(wid)

        # Kill the tmux session (ignore "session not found" -- may have already exited)
        try:
            entry.session.kill()
        except Exception as exc:
            msg = str(exc)
            if "can't find session" in msg or "no server running" in msg:
                pass  # session already gone -- that's fine
            else:
                raise ValueError(f"failed to kill tmux session {name!r}: {exc}") from exc

        with _SESSIONS_LOCK:
            _SESSIONS.pop(name, None)

        return {"ok": True}

    # ------------------------------------------------------------------ #
    # tmux_session_attach                                                  #
    # ------------------------------------------------------------------ #

    @mcp_server.tool(description=(
        "Look up metadata for a tmux session. Does NOT attach an interactive terminal "
        "-- that is a CLI concern. Returns {ok, session, pid, plugin}."
    ))
    def tmux_session_attach(name: str) -> dict:
        with _SESSIONS_LOCK:
            entry = _SESSIONS.get(name)

        if entry is None:
            # Try to find it in live tmux even if not in registry
            pane = _find_pane_by_name(_libtmux_server, name)
            if pane is None:
                raise ValueError(f"unknown session: {name!r}")
            return {"ok": True, "session": name, "pid": None, "plugin": None,
                    "note": "session exists in tmux but was not created via tmux_session_create"}

        return {
            "ok": True,
            "session": name,
            "pid": entry.pid,
            "plugin": entry.plugin_name,
        }


# ------------------------------------------------------------------ #
# Helpers used by register_tmux_tools (module level, not tools)       #
# ------------------------------------------------------------------ #

class _SessionDescriptor:
    """Minimal session object passed to plugin.on_session_start."""

    def __init__(self, name: str, pane_pid: int, pane: libtmux.Pane) -> None:
        self.name = name
        self.pane_pid = pane_pid
        self.pane = pane


def _resolve_signal(signal_name: str) -> int:
    """Resolve a signal name string (e.g. 'TERM', 'KILL') to signal number."""
    import signal as _signal_mod
    name = signal_name.upper()
    if not name.startswith("SIG"):
        name = "SIG" + name
    try:
        return getattr(_signal_mod, name).value
    except AttributeError:
        raise ValueError(f"unknown signal: {signal_name!r}")


def _wait_for_events_with_send(
    pane: libtmux.Pane,
    entry: Optional[_SessionEntry],
    wait: dict,
    watcher_host: WatcherHost,
    plugin_host: PluginHost,
    send: list[str],
) -> dict:
    """Arm watches, capture pane baseline, send input, then poll.

    Race-fix: watches are armed before send so inotify events fired between
    send and the first poll iteration are already queued. Pane baseline is
    captured after arming watches but before send so match checks skip
    pre-existing pane content. This mirrors the rig.py JSONL-mark pattern
    (rig.py lines 409-416, 524-535) which records a byte offset before sending
    so the wait loop ignores prior end_turn events. Here we use pre-armed
    inotify + a pane line offset instead of a sentinel echo, which is lighter
    and avoids injecting stray output into the target program.
    """
    events_spec: list = wait.get("events", [])
    timeout: float = float(wait.get("timeout", 30))

    start = time.monotonic()
    deadline = start + timeout

    fired_event: list[Optional[Event]] = [None]
    fired_lock = threading.Lock()

    def _try_fire(ev: Event) -> None:
        with fired_lock:
            if fired_event[0] is None:
                fired_event[0] = ev

    temp_watcher_ids: list[int] = []

    # Step 1: Arm file-based watches BEFORE send
    for spec in events_spec:
        if spec == "idle":
            if entry is not None and entry.plugin_name is not None:
                plugin = plugin_host.get(entry.plugin_name)
                if plugin is not None:
                    bound_path = getattr(plugin, "bound_path", None)
                    if bound_path:
                        def _idle_dispatch(ev: Event, _plugin: Any = plugin) -> None:
                            if ev.type == EVENT_IDLE:
                                enriched = _plugin.enrich_event(ev)
                                _try_fire(enriched)
                        fw = FileWatcher(path=bound_path, event=EVENT_IDLE,
                                         parser=getattr(plugin, "_parse_jsonl_line", None))
                        wid = watcher_host.add(fw, _idle_dispatch)
                        temp_watcher_ids.append(wid)

        elif isinstance(spec, dict) and "file_change" in spec:
            path = spec["file_change"]

            def _fc_dispatch(ev: Event, _path: str = path) -> None:
                _try_fire(Event(type=EVENT_FILE_CHANGE, data={"path": _path}))

            fw = FileWatcher(path=path, event=EVENT_FILE_CHANGE)
            wid = watcher_host.add(fw, _fc_dispatch)
            temp_watcher_ids.append(wid)

    # Step 2: Capture pane baseline AFTER arming watches, BEFORE send
    try:
        before_lines = _capture_pane(pane, lines=500).splitlines()
        pane_offset = len(before_lines)
    except Exception:
        pane_offset = 0

    # Compile match patterns keyed by spec index for tiebreak-ordered dispatch
    # KB-1: index preserves declared order so same-tick checks follow events list
    match_patterns_by_idx: dict[int, re.Pattern] = {}
    for i, spec in enumerate(events_spec):
        if isinstance(spec, dict) and "match" in spec:
            try:
                match_patterns_by_idx[i] = re.compile(spec["match"])
            except re.error as exc:
                for wid in temp_watcher_ids:
                    watcher_host.remove(wid)
                raise ValueError(f"invalid match regex {spec['match']!r}: {exc}") from exc

    bound_pid = entry.pid if entry is not None else None
    has_match_specs = bool(match_patterns_by_idx)

    # Lazy JSONL discovery flag: true when the idle spec is present but the
    # plugin has not yet bound to a JSONL file (bound_path is None).
    # Checked every poll tick after the prompt is sent -- CC writes its
    # transcript file shortly after receiving the first user message.
    _needs_idle_discovery: bool = (
        any(spec == "idle" for spec in events_spec)
        and entry is not None
        and entry.plugin_name is not None
    )

    # Step 3: Send user input
    try:
        _send_array(pane, send)
    except Exception as exc:
        for wid in temp_watcher_ids:
            watcher_host.remove(wid)
        raise ValueError(f"send error: {exc}") from exc

    # Step 4: Poll for events -- iterate events_spec in declared order each tick for same-tick tiebreak
    try:
        while time.monotonic() < deadline:
            if fired_event[0] is not None:
                break

            # Capture new pane lines once per tick if match specs exist
            # KB-2: capture per-line so we can report the full containing line
            new_lines: list[str] | None = None
            if has_match_specs:
                try:
                    current_lines = _capture_pane(pane, lines=500).splitlines()
                    new_lines = current_lines[pane_offset:]
                except Exception:
                    new_lines = []

            # KB-1: check each event type in declared order (same-tick tiebreak follows events list)
            for i, spec in enumerate(events_spec):
                if fired_event[0] is not None:
                    break
                if spec == "exit":
                    if bound_pid is not None and not _pid_alive(bound_pid):
                        _try_fire(Event(type=EVENT_EXIT, data={"pid": bound_pid}))
                elif isinstance(spec, dict) and "match" in spec:
                    pat = match_patterns_by_idx.get(i)
                    if pat is not None and new_lines:
                        for line in new_lines:
                            m = pat.search(line)
                            if m:
                                # KB-2: "line" is the full containing line; "text" is the match
                                _try_fire(Event(type=EVENT_MATCH,
                                                data={"text": m.group(), "line": line}))
                                break
                # idle and file_change fire via async callbacks -- no inline check needed

            # Lazy idle discovery: arm FileWatcher once CC writes its JSONL.
            # This fires after send so the prompt has been delivered and CC is
            # about to write (or has just written) its transcript file.
            if _needs_idle_discovery and fired_event[0] is None:
                _lz_plugin = plugin_host.get(entry.plugin_name)
                if _lz_plugin is not None and getattr(_lz_plugin, "bound_path", None) is None:
                    if hasattr(_lz_plugin, "poll_for_jsonl"):
                        _new_path = _lz_plugin.poll_for_jsonl()
                        if _new_path:
                            def _idle_lazy(
                                ev: Event, _pl: Any = _lz_plugin
                            ) -> None:
                                if ev.type == EVENT_IDLE:
                                    _try_fire(_pl.enrich_event(ev))
                            _lz_fw = FileWatcher(
                                path=_new_path,
                                event=EVENT_IDLE,
                                parser=getattr(_lz_plugin, "_parse_jsonl_line", None),
                            )
                            _lz_wid = watcher_host.add(_lz_fw, _idle_lazy)
                            temp_watcher_ids.append(_lz_wid)

            time.sleep(_POLL_INTERVAL)

        elapsed = time.monotonic() - start
        ev = fired_event[0]
        if ev is None:
            return {"ok": False, "event": EVENT_TIMEOUT, "elapsed": round(elapsed, 2)}

        result: dict[str, Any] = {"ok": True, "event": ev.type, "elapsed": round(elapsed, 2)}
        result.update(ev.data)
        return result

    finally:
        for wid in temp_watcher_ids:
            watcher_host.remove(wid)
