"""Claude Code plugin for spad-mcp.

Idle detection: watches the CC JSONL transcript for end_turn events.
Discovery: on session_start, polls for a new *.jsonl file in projects_dir
so the plugin binds to the live transcript without static config.
"""

from __future__ import annotations

import glob
import json
import logging
import os
import time
from os.path import expanduser
from typing import Optional

from spad_mcp.core.events import Event, EVENT_IDLE
from spad_mcp.core.watcher import FileWatcher

log = logging.getLogger(__name__)

# How long to poll for the new JSONL before giving up.
# CC typically writes its transcript within a few seconds of startup.
_DISCOVERY_TIMEOUT_S: float = 30.0
_DISCOVERY_POLL_S: float = 0.5

# Number of tail lines to read when enriching cost/model from the transcript.
_TAIL_LINES: int = 50


class ClaudeCodePlugin:
    name = "claude-code"

    def __init__(self) -> None:
        self.projects_dir: str = expanduser(self._default_projects_dir())
        # Set after on_session_start; read by tmux adapter to wire idle watches.
        self.bound_path: Optional[str] = None
        # Snapshot taken BEFORE session creation (see pre_start).
        # None means pre_start() has not been called; empty set is valid (dir was empty).
        self._before_jsonl: Optional[set] = None

    @staticmethod
    def _default_projects_dir() -> str:
        """Return the default projects_dir based on CLAUDE_CONFIG_DIR env var.

        CC writes JSONL to <CLAUDE_CONFIG_DIR>/projects/<encoded-cwd>/<uuid>.jsonl.
        If CLAUDE_CONFIG_DIR is unset, CC defaults to ~/.claude.
        """
        claude_config = os.environ.get("CLAUDE_CONFIG_DIR", "~/.claude")
        return os.path.join(claude_config, "projects")

    # ------------------------------------------------------------------ #
    # Plugin contract                                                       #
    # ------------------------------------------------------------------ #

    def configure(self, config: dict) -> None:
        self.projects_dir = expanduser(
            config.get("projects_dir", self._default_projects_dir())
        )

    def pre_start(self) -> None:
        """Snapshot existing JSONL files BEFORE the tmux session is created.

        Must be called by the adapter before new_session() so the before-set
        does not include the file CC is about to write. CC writes its JSONL
        within milliseconds of startup -- if the snapshot is taken after
        new_session(), the new file lands in "before" and discovery never fires.
        """
        self._before_jsonl = self._glob_jsonl()
        self.bound_path = None
        log.debug(
            "claude-code plugin: pre-start snapshot: %d existing JSONL files",
            len(self._before_jsonl),
        )

    def on_session_start(self, session: object) -> list:
        """Record session start. Does NOT block -- JSONL discovery is lazy.

        CC only writes its JSONL transcript when the first prompt is processed,
        not on startup. Discovery is deferred to poll_for_jsonl(), which is
        called from the wait loop in _wait_for_events_with_send after a prompt
        has been sent.

        pre_start() MUST be called before new_session() to capture the correct
        before-snapshot. Without it all existing JSONLs become candidates.

        Do NOT reset _before_jsonl here -- poll_for_jsonl() needs it.

        Returns [] always -- watchers are armed lazily.
        """
        if self._before_jsonl is None:
            # Fallback: pre_start was not called; take snapshot now.
            # This may already include the CC JSONL if CC started fast.
            self._before_jsonl = self._glob_jsonl()
            log.debug(
                "claude-code plugin: on_session_start fallback snapshot "
                "(pre_start not called -- discovery may miss fast-writing CC)"
            )

        self.bound_path = None
        log.debug(
            "claude-code plugin: on_session_start complete; "
            "lazy JSONL discovery armed (before-snapshot: %d files)",
            len(self._before_jsonl),
        )
        return []

    def poll_for_jsonl(self) -> Optional[str]:
        """Single non-blocking check for a new JSONL file.

        Fallback for when on_session_start() failed to discover the file
        (e.g. CC was slow to write). Uses current before-snapshot if set.
        Sets and returns self.bound_path when a new file is found; returns None
        if no new file has appeared yet.
        """
        before = self._before_jsonl if self._before_jsonl is not None else set()
        after = self._glob_jsonl()
        candidates = after - before
        if not candidates:
            return None
        new_path = max(candidates, key=os.path.getmtime)
        self.bound_path = new_path
        log.info("claude-code plugin: bound (lazy) to %s", new_path)
        return new_path

    def enrich_event(self, event: Event) -> Event:
        """Augment idle events with ctx_pct, cost_usd, and model where available."""
        if event.type != EVENT_IDLE:
            return event

        # ctx_pct: written by the CC ctx hook to a sidecar file.
        # If the hook is not installed this key simply won't appear -- that's fine.
        ctx_path = expanduser("~/.claude/spad_ctx_pct")
        try:
            with open(ctx_path, "r") as fh:
                raw = fh.read().strip()
            event.data["ctx_pct"] = int(raw)
        except (OSError, ValueError):
            pass

        # cost_usd / model: parse from the tail of the JSONL transcript.
        if self.bound_path:
            tail_data = self._read_tail_data(self.bound_path)
            if tail_data.get("model"):
                event.data["model"] = tail_data["model"]
            if tail_data.get("cost_usd") is not None:
                event.data["cost_usd"] = tail_data["cost_usd"]

        return event

    def tools(self) -> list:
        # No MCP tools added by this plugin in MVP.
        return []

    # ------------------------------------------------------------------ #
    # JSONL parsing                                                         #
    # ------------------------------------------------------------------ #

    def _parse_jsonl_line(self, line: str) -> Optional[str]:
        """Structural parse, not regex -- one json.loads per line.

        Returns the event-type string when the line signals end of turn,
        or None to ignore the line. The watcher_host calls this for every
        new appended line and fires an Event when the return value is not None.
        """
        try:
            obj = json.loads(line)
        except json.JSONDecodeError:
            return None
        msg = obj.get("message", {})
        if msg.get("stop_reason") == "end_turn":
            return EVENT_IDLE
        return None

    # ------------------------------------------------------------------ #
    # Helpers                                                              #
    # ------------------------------------------------------------------ #

    def _glob_jsonl(self) -> set[str]:
        """Return the set of *.jsonl paths currently under projects_dir."""
        pattern = os.path.join(self.projects_dir, "**", "*.jsonl")
        return set(glob.glob(pattern, recursive=True))

    def _read_tail_data(self, path: str) -> dict:
        """Read the last _TAIL_LINES of the transcript and extract cost/model.

        Walks backward through the tail to find the most recent assistant
        message with a usage block. Returns a dict with zero or more of:
        {"model": str, "cost_usd": float}.

        Cost is read from the CC-emitted "cost_usd" top-level field when
        present (CC versions that include it). If absent, omitted rather than
        estimated, because a wrong number is worse than no number.
        """
        try:
            with open(path, "r", errors="replace") as fh:
                # Efficient tail: seek to a window from the end.
                # 200 bytes per line is generous for JSONL transcript lines.
                window = _TAIL_LINES * 200
                try:
                    fh.seek(0, 2)  # seek end
                    size = fh.tell()
                    fh.seek(max(0, size - window))
                    if size > window:
                        # Discard partial first line.
                        fh.readline()
                except OSError:
                    fh.seek(0)
                raw_lines = fh.readlines()
        except OSError:
            return {}

        result: dict = {}
        # Walk newest-first to find the most recent assistant turn.
        for line in reversed(raw_lines):
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
            except json.JSONDecodeError:
                continue

            # Top-level cost_usd field (present in some CC versions).
            if "cost_usd" not in result and "cost_usd" in obj:
                try:
                    result["cost_usd"] = float(obj["cost_usd"])
                except (TypeError, ValueError):
                    pass

            # model and usage live inside message on assistant entries.
            if obj.get("type") == "assistant":
                msg = obj.get("message", {})
                if "model" not in result and msg.get("model"):
                    result["model"] = msg["model"]
                # Stop once we have everything we're looking for.
                if "model" in result and "cost_usd" in result:
                    break

        return result
