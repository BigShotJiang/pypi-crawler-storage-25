"""spad CLI -- client for the spad-mcp MCP server.

Usage:
    python -m spad_mcp.cli.spad [--server URL] [--json] <subcommand> [args...]
"""

from __future__ import annotations

import argparse
import asyncio
import http.client
import json
import sys
import urllib.parse
import urllib.request
from typing import Any, Optional


# ---------------------------------------------------------------------------
# Defaults
# ---------------------------------------------------------------------------

DEFAULT_SERVER = "http://localhost:9830/mcp"


# ---------------------------------------------------------------------------
# URL helpers
# ---------------------------------------------------------------------------

def _base_url(server_url: str) -> str:
    """Strip /mcp suffix to get the OOB transfer base URL."""
    if server_url.endswith("/mcp"):
        return server_url[:-4]
    return server_url


def _quote(s: str) -> str:
    return urllib.parse.quote(s, safe="")


# ---------------------------------------------------------------------------
# Error type
# ---------------------------------------------------------------------------

class _McpError(Exception):
    def __init__(self, message: str, structured: dict) -> None:
        super().__init__(message)
        self.structured = structured


# ---------------------------------------------------------------------------
# MCP call helper
# ---------------------------------------------------------------------------

async def _call(server_url: str, tool: str, args: dict) -> Any:
    """Call an MCP tool and return the parsed result dict.

    Raises _McpError on MCP error or transport error.
    Returns the dict from result.content[0].text.
    """
    from fastmcp import Client

    try:
        async with Client(server_url) as client:
            result = await client.call_tool(tool, args)
    except Exception as exc:
        msg = f"transport error: {exc}"
        raise _McpError(msg, {"error": msg, "isError": True}) from exc

    if result.is_error:
        try:
            err_text = result.content[0].text
        except (IndexError, AttributeError):
            err_text = str(result)
        msg = f"error: {err_text}"
        raise _McpError(msg, {"error": err_text, "isError": True})

    try:
        return json.loads(result.content[0].text)
    except (IndexError, AttributeError, json.JSONDecodeError) as exc:
        msg = f"parse error: {exc}"
        raise _McpError(msg, {"error": msg, "isError": True}) from exc


def _run(coro: Any) -> Any:
    return asyncio.run(coro)


# ---------------------------------------------------------------------------
# Output helpers
# ---------------------------------------------------------------------------

def _print_json(data: Any) -> None:
    print(json.dumps(data, indent=2))


# ---------------------------------------------------------------------------
# Custom argparse action for ordered -s/-k in tmux interact
# ---------------------------------------------------------------------------

class _SendAction(argparse.Action):
    def __call__(
        self,
        parser: argparse.ArgumentParser,
        namespace: argparse.Namespace,
        values: Any,
        option_string: Optional[str] = None,
    ) -> None:
        items = getattr(namespace, "send_parts", []) or []
        prefix = "s:" if option_string in ("-s", "--send-text") else "k:"
        items.append(prefix + values)
        setattr(namespace, "send_parts", items)


# ---------------------------------------------------------------------------
# Range parsing for file read
# ---------------------------------------------------------------------------

def _parse_range(range_str: Optional[str]) -> Optional[list]:
    """Parse 'START:STOP' range string to [start, stop] list with None for open ends."""
    if range_str is None:
        return None
    if ":" not in range_str:
        print(f"invalid --range {range_str!r}: expected START:STOP", file=sys.stderr)
        sys.exit(1)
    left, right = range_str.split(":", 1)
    start = int(left) if left.strip() else None
    stop = int(right) if right.strip() else None
    return [start, stop]


# ---------------------------------------------------------------------------
# Env parsing: KEY=VAL
# ---------------------------------------------------------------------------

def _parse_env(env_list: Optional[list[str]]) -> Optional[dict[str, str]]:
    if not env_list:
        return None
    result: dict[str, str] = {}
    for item in env_list:
        if "=" not in item:
            print(f"invalid env entry {item!r}: expected KEY=VAL", file=sys.stderr)
            sys.exit(1)
        k, v = item.split("=", 1)
        result[k] = v
    return result


# ---------------------------------------------------------------------------
# Wait spec parsing for tmux interact
# ---------------------------------------------------------------------------

def _parse_wait(wait_list: Optional[list[str]]) -> Optional[dict]:
    if not wait_list:
        return None
    events: list = []
    for spec in wait_list:
        if spec in ("idle", "exit"):
            events.append(spec)
        elif spec.startswith("match="):
            events.append({"match": spec[6:]})
        elif spec.startswith("file_change="):
            events.append({"file_change": spec[12:]})
        else:
            print(f"invalid --wait spec {spec!r}: use idle, exit, match=PAT, file_change=PATH",
                  file=sys.stderr)
            sys.exit(1)
    return {"events": events}


# ---------------------------------------------------------------------------
# Subcommand: status
# ---------------------------------------------------------------------------

def _cmd_status(args: argparse.Namespace) -> None:
    data = _run(_call(args.server, "status", {}))
    if args.json:
        _print_json(data)
        return
    print(f"version: {data.get('version', 'unknown')}")
    plugins = data.get("plugins", [])
    print(f"plugins: {', '.join(plugins) if plugins else '(none)'}")
    bound = data.get("bound_paths", {})
    if bound:
        print("bound_paths:")
        for k, v in bound.items():
            print(f"  {k}: {v}")
    else:
        print("bound_paths: (none)")


# ---------------------------------------------------------------------------
# Subcommand: shell
# ---------------------------------------------------------------------------

def _cmd_shell(args: argparse.Namespace) -> None:
    tool_args: dict[str, Any] = {"argv": args.argv}
    if args.cwd:
        tool_args["cwd"] = args.cwd
    env = _parse_env(args.env)
    if env:
        tool_args["env"] = env
    if args.timeout is not None:
        tool_args["timeout"] = args.timeout

    data = _run(_call(args.server, "shell", tool_args))

    if args.json:
        _print_json(data)
        return

    stdout = data.get("stdout", "")
    stderr = data.get("stderr", "")
    rc = data.get("rc", 0)

    if stdout:
        print(stdout, end="" if stdout.endswith("\n") else "\n")
    if stderr:
        print(stderr, end="" if stderr.endswith("\n") else "\n", file=sys.stderr)
    sys.exit(rc)


# ---------------------------------------------------------------------------
# Subcommand: file read
# ---------------------------------------------------------------------------

def _cmd_file_read(args: argparse.Namespace) -> None:
    tool_args: dict[str, Any] = {"path": args.path}
    if args.mode:
        tool_args["mode"] = args.mode
    range_val = _parse_range(args.range)
    if range_val is not None:
        tool_args["range"] = range_val

    data = _run(_call(args.server, "file_read", tool_args))

    if args.json:
        _print_json(data)
        return

    content = data.get("content", "")
    print(content, end="" if isinstance(content, str) and content.endswith("\n") else "\n")

    # Footer
    truncated = data.get("truncated", False)
    eof = data.get("eof", False)
    bytes_read = data.get("bytes_read", None)
    units_read = data.get("units_read", None)

    if args.mode == "bytes":
        print(f"[truncated={truncated}, eof={eof}, bytes_read={bytes_read}]")
    else:
        print(f"[truncated={truncated}, eof={eof}, units_read={units_read}, bytes_read={bytes_read}]")


# ---------------------------------------------------------------------------
# Subcommand: file write
# ---------------------------------------------------------------------------

def _cmd_file_write(args: argparse.Namespace) -> None:
    tool_args: dict[str, Any] = {
        "path": args.path,
        "content": args.content,
        "overwrite": args.overwrite,
    }
    data = _run(_call(args.server, "file_write", tool_args))

    if args.json:
        _print_json(data)
        return

    nbytes = data.get("bytes", 0)
    print(f"ok: {nbytes} bytes written")


# ---------------------------------------------------------------------------
# Subcommand: file edit
# ---------------------------------------------------------------------------

def _cmd_file_edit(args: argparse.Namespace) -> None:
    tool_args: dict[str, Any] = {
        "path": args.path,
        "old": args.old,
        "new": args.new,
        "all": args.all,
    }
    data = _run(_call(args.server, "file_edit", tool_args))

    if args.json:
        _print_json(data)
        return

    n = data.get("replacements", 0)
    print(f"replacements: {n}")


# ---------------------------------------------------------------------------
# Subcommand: file grep
# ---------------------------------------------------------------------------

def _cmd_file_grep(args: argparse.Namespace) -> None:
    tool_args: dict[str, Any] = {"root": args.root, "pattern": args.pattern}
    if args.glob:
        tool_args["glob"] = args.glob

    data = _run(_call(args.server, "file_grep", tool_args))

    if args.json:
        _print_json(data)
        return

    matches = data.get("matches", [])
    for m in matches:
        print(f"{m['path']}:{m['line']}:{m['text']}")

    truncated = data.get("truncated", False)
    match_count = data.get("match_count", len(matches))
    print(f"[match_count={match_count}, truncated={truncated}]")


# ---------------------------------------------------------------------------
# Subcommand: file glob
# ---------------------------------------------------------------------------

def _cmd_file_glob(args: argparse.Namespace) -> None:
    tool_args: dict[str, Any] = {"root": args.root, "pattern": args.pattern}
    data = _run(_call(args.server, "file_glob", tool_args))

    if args.json:
        _print_json(data)
        return

    files = data.get("files", [])
    for f in files:
        print(f)

    truncated = data.get("truncated", False)
    match_count = data.get("match_count", len(files))
    print(f"[match_count={match_count}, truncated={truncated}]")


# ---------------------------------------------------------------------------
# Subcommand: file insert
# ---------------------------------------------------------------------------

def _cmd_file_insert(args: argparse.Namespace) -> None:
    position = args.position
    anchor = args.anchor

    # Validate anchor requirements
    if position in ("before", "after") and anchor is None:
        print(f"--anchor required when --position is {position!r}", file=sys.stderr)
        sys.exit(1)
    if position in ("start", "end") and anchor is not None:
        print(f"--anchor not allowed when --position is {position!r}", file=sys.stderr)
        sys.exit(1)

    tool_args: dict[str, Any] = {
        "path": args.path,
        "content": args.content,
        "position": position,
    }
    if anchor is not None:
        tool_args["anchor"] = anchor

    data = _run(_call(args.server, "file_insert", tool_args))

    if args.json:
        _print_json(data)
        return

    line = data.get("line", "?")
    print(f"ok: inserted at line {line}")


# ---------------------------------------------------------------------------
# Subcommand: put (OOB upload)
# ---------------------------------------------------------------------------

def _cmd_put(args: argparse.Namespace) -> None:
    base = _base_url(args.server)
    remote = args.remote
    overwrite = "true" if args.overwrite else "false"
    parsed = urllib.parse.urlparse(base)
    host = parsed.hostname or "localhost"
    port = parsed.port or 80
    path = f"/spad/upload?path={urllib.parse.quote(remote, safe='/')}&overwrite={overwrite}"
    conn = http.client.HTTPConnection(host, port)
    try:
        conn.putrequest("POST", path)
        conn.putheader("Transfer-Encoding", "chunked")
        conn.putheader("Content-Type", "application/octet-stream")
        conn.endheaders()
        bytes_sent = 0
        with open(args.local, "rb") as fh:
            while True:
                chunk = fh.read(65536)
                if not chunk:
                    break
                conn.send(f"{len(chunk):X}\r\n".encode("ascii") + chunk + b"\r\n")
                bytes_sent += len(chunk)
        conn.send(b"0\r\n\r\n")
        resp = conn.getresponse()
        body = json.loads(resp.read().decode("utf-8"))
        if resp.status != 200:
            print(body.get("error", "upload failed"), file=sys.stderr)
            sys.exit(1)
        if args.json:
            print(json.dumps(body, indent=2))
        else:
            print(f"ok: {body.get('bytes', bytes_sent)} bytes uploaded")
    except (OSError, http.client.HTTPException) as exc:
        print(f"put error: {exc}", file=sys.stderr)
        sys.exit(1)
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Subcommand: get (OOB download)
# ---------------------------------------------------------------------------

def _cmd_get(args: argparse.Namespace) -> None:
    remote: str = args.remote
    local_path: str = args.local

    base = _base_url(args.server)
    url = f"{base}/spad/download?path={_quote(remote)}"

    bytes_written = 0
    try:
        with urllib.request.urlopen(url) as resp:
            with open(local_path, "wb") as fh:
                while True:
                    chunk = resp.read(65536)
                    if not chunk:
                        break
                    fh.write(chunk)
                    bytes_written += len(chunk)
    except urllib.error.HTTPError as exc:
        try:
            body = exc.read()
            err_data = json.loads(body)
            print(f"download error {exc.code}: {err_data.get('error', body)}", file=sys.stderr)
        except Exception:
            print(f"download error {exc.code}: {exc}", file=sys.stderr)
        sys.exit(1)
    except Exception as exc:
        print(f"download error: {exc}", file=sys.stderr)
        sys.exit(1)

    if args.json:
        _print_json({"ok": True, "bytes": bytes_written})
        return

    print(f"ok: {bytes_written} bytes written")


# ---------------------------------------------------------------------------
# Subcommand: tmux interact
# ---------------------------------------------------------------------------

def _cmd_tmux_interact(args: argparse.Namespace) -> None:
    send_parts: list[str] = getattr(args, "send_parts", []) or []
    wait_specs: Optional[list[str]] = args.wait

    tool_args: dict[str, Any] = {}
    if args.session:
        tool_args["session"] = args.session
    if send_parts:
        tool_args["send"] = send_parts

    wait_dict = _parse_wait(wait_specs)
    if wait_dict is not None:
        wait_dict["timeout"] = args.timeout if args.timeout is not None else 60
        tool_args["wait"] = wait_dict

    data = _run(_call(args.server, "tmux_interact", tool_args))

    if args.json:
        _print_json(data)
        return

    print(json.dumps(data, indent=2))


# ---------------------------------------------------------------------------
# Subcommand: tmux screenshot
# ---------------------------------------------------------------------------

def _cmd_tmux_screenshot(args: argparse.Namespace) -> None:
    tool_args: dict[str, Any] = {}
    if args.session:
        tool_args["session"] = args.session
    if args.lines is not None:
        tool_args["lines"] = args.lines

    data = _run(_call(args.server, "tmux_screenshot", tool_args))

    if args.json:
        _print_json(data)
        return

    print(data.get("content", ""))


# ---------------------------------------------------------------------------
# Subcommand: tmux sessions
# ---------------------------------------------------------------------------

def _cmd_tmux_sessions(args: argparse.Namespace) -> None:
    data = _run(_call(args.server, "tmux_sessions", {}))

    if args.json:
        _print_json(data)
        return

    sessions = data.get("sessions", [])
    for s in sessions:
        print(s)


# ---------------------------------------------------------------------------
# Subcommand: tmux session-create
# ---------------------------------------------------------------------------

def _cmd_tmux_session_create(args: argparse.Namespace) -> None:
    command: list[str] = args.command or []
    # Strip leading '--' if present (argparse REMAINDER artifact)
    if command and command[0] == "--":
        command = command[1:]

    tool_args: dict[str, Any] = {
        "name": args.name,
        "command": command,
    }
    if args.cwd:
        tool_args["cwd"] = args.cwd
    env = _parse_env(args.env)
    if env:
        tool_args["env"] = env
    if args.plugin:
        tool_args["plugin"] = args.plugin

    data = _run(_call(args.server, "tmux_session_create", tool_args))

    if args.json:
        _print_json(data)
        return

    print(json.dumps({"ok": data.get("ok"), "session": data.get("session"), "pid": data.get("pid")}, indent=2))


# ---------------------------------------------------------------------------
# Subcommand: tmux session-destroy
# ---------------------------------------------------------------------------

def _cmd_tmux_session_destroy(args: argparse.Namespace) -> None:
    tool_args: dict[str, Any] = {"name": args.name}
    if args.signal:
        tool_args["signal"] = args.signal

    data = _run(_call(args.server, "tmux_session_destroy", tool_args))

    if args.json:
        _print_json(data)
        return

    print(json.dumps({"ok": data.get("ok")}, indent=2))


# ---------------------------------------------------------------------------
# Subcommand: tmux session-attach
# ---------------------------------------------------------------------------

def _cmd_tmux_session_attach(args: argparse.Namespace) -> None:
    tool_args: dict[str, Any] = {"name": args.name}
    data = _run(_call(args.server, "tmux_session_attach", tool_args))

    if args.json:
        _print_json(data)
        return

    print(json.dumps(data, indent=2))


# ---------------------------------------------------------------------------
# Argument parser construction
# ---------------------------------------------------------------------------

def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="spad",
        description="spad-mcp CLI client",
    )
    parser.add_argument(
        "--server",
        default=DEFAULT_SERVER,
        metavar="URL",
        help=f"MCP server URL (default: {DEFAULT_SERVER})",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        default=False,
        help="print raw JSON output",
    )

    subparsers = parser.add_subparsers(dest="command", metavar="<command>")
    subparsers.required = True

    # -- status --
    p_status = subparsers.add_parser("status", help="show server status")
    p_status.set_defaults(func=_cmd_status)

    # -- shell --
    p_shell = subparsers.add_parser("shell", help="run a command on the host")
    p_shell.add_argument("argv", nargs=argparse.REMAINDER, help="command argv")
    p_shell.add_argument("--cwd", default=None, metavar="DIR", help="working directory")
    p_shell.add_argument(
        "--env", action="append", default=None, metavar="KEY=VAL", help="environment variable"
    )
    p_shell.add_argument("--timeout", type=int, default=None, metavar="SEC", help="timeout seconds")
    p_shell.set_defaults(func=_cmd_shell)

    # -- file --
    p_file = subparsers.add_parser("file", help="file operations")
    file_sub = p_file.add_subparsers(dest="file_command", metavar="<file-command>")
    file_sub.required = True

    # file read
    p_fread = file_sub.add_parser("read", help="read file content")
    p_fread.add_argument("path", help="file path")
    p_fread.add_argument(
        "--mode",
        choices=["lines", "chars", "bytes"],
        default=None,
        help="read mode (default: lines)",
    )
    p_fread.add_argument(
        "--range",
        default=None,
        metavar="START:STOP",
        help="range (e.g. 5:10, :50, -50:, :)",
    )
    p_fread.set_defaults(func=_cmd_file_read)

    # file write
    p_fwrite = file_sub.add_parser("write", help="write file content")
    p_fwrite.add_argument("path", help="file path")
    p_fwrite.add_argument("content", help="content to write")
    p_fwrite.add_argument("--overwrite", action="store_true", default=False)
    p_fwrite.set_defaults(func=_cmd_file_write)

    # file edit
    p_fedit = file_sub.add_parser("edit", help="edit file via old/new replacement")
    p_fedit.add_argument("path", help="file path")
    p_fedit.add_argument("old", help="string to replace")
    p_fedit.add_argument("new", help="replacement string")
    p_fedit.add_argument("--all", action="store_true", default=False, help="replace all occurrences")
    p_fedit.set_defaults(func=_cmd_file_edit)

    # file grep
    p_fgrep = file_sub.add_parser("grep", help="regex search in files")
    p_fgrep.add_argument("root", help="root directory")
    p_fgrep.add_argument("pattern", help="regex pattern")
    p_fgrep.add_argument("--glob", default=None, metavar="GLOB", help="file glob filter")
    p_fgrep.set_defaults(func=_cmd_file_grep)

    # file glob
    p_fglob = file_sub.add_parser("glob", help="list files matching a glob pattern")
    p_fglob.add_argument("root", help="root directory")
    p_fglob.add_argument("pattern", help="glob pattern")
    p_fglob.set_defaults(func=_cmd_file_glob)

    # file insert
    p_finsert = file_sub.add_parser("insert", help="insert content into a file")
    p_finsert.add_argument("path", help="file path")
    p_finsert.add_argument("content", help="content to insert")
    p_finsert.add_argument(
        "--position",
        required=True,
        choices=["start", "end", "before", "after"],
        help="insertion position",
    )
    p_finsert.add_argument("--anchor", default=None, help="anchor string (required for before/after)")
    p_finsert.set_defaults(func=_cmd_file_insert)

    # -- put --
    p_put = subparsers.add_parser("put", help="upload local file to server (OOB)")
    p_put.add_argument("local", help="local file path")
    p_put.add_argument("remote", help="remote (server) absolute path")
    p_put.add_argument("--overwrite", action="store_true", default=False)
    p_put.set_defaults(func=_cmd_put)

    # -- get --
    p_get = subparsers.add_parser("get", help="download file from server (OOB)")
    p_get.add_argument("remote", help="remote (server) absolute path")
    p_get.add_argument("local", help="local file path to write")
    p_get.set_defaults(func=_cmd_get)

    # -- tmux --
    p_tmux = subparsers.add_parser("tmux", help="tmux operations")
    tmux_sub = p_tmux.add_subparsers(dest="tmux_command", metavar="<tmux-command>")
    tmux_sub.required = True

    # tmux interact
    p_ti = tmux_sub.add_parser("interact", help="send input and/or wait for events")
    p_ti.add_argument("--session", default=None, metavar="NAME", help="session name")
    p_ti.add_argument(
        "-s", "--send-text",
        dest="send_parts",
        action=_SendAction,
        metavar="TEXT",
        help="send literal text (may be repeated, order preserved)",
    )
    p_ti.add_argument(
        "-k", "--send-key",
        dest="send_parts",
        action=_SendAction,
        metavar="KEY",
        help="send tmux key (may be repeated, order preserved)",
    )
    p_ti.add_argument(
        "--wait",
        action="append",
        default=None,
        metavar="COND",
        help="wait condition: idle, exit, match=PAT, file_change=PATH",
    )
    p_ti.add_argument("--timeout", type=float, default=None, metavar="SEC", help="wait timeout")
    p_ti.set_defaults(func=_cmd_tmux_interact)

    # tmux screenshot
    p_tss = tmux_sub.add_parser("screenshot", help="capture pane content")
    p_tss.add_argument("--session", default=None, metavar="NAME")
    p_tss.add_argument("--lines", type=int, default=None, metavar="N")
    p_tss.set_defaults(func=_cmd_tmux_screenshot)

    # tmux sessions
    p_tsessions = tmux_sub.add_parser("sessions", help="list session names")
    p_tsessions.set_defaults(func=_cmd_tmux_sessions)

    # tmux session-create
    p_tsc = tmux_sub.add_parser("session-create", help="create a new tmux session")
    p_tsc.add_argument("--name", required=True, metavar="NAME")
    p_tsc.add_argument("--cwd", default=None, metavar="DIR")
    p_tsc.add_argument("--env", action="append", default=None, metavar="K=V")
    p_tsc.add_argument("--plugin", default=None, metavar="NAME")
    p_tsc.add_argument(
        "command",
        nargs=argparse.REMAINDER,
        help="command to run in session (after --)",
    )
    p_tsc.set_defaults(func=_cmd_tmux_session_create)

    # tmux session-destroy
    p_tsd = tmux_sub.add_parser("session-destroy", help="destroy a tmux session")
    p_tsd.add_argument("--name", required=True, metavar="NAME")
    p_tsd.add_argument("--signal", default=None, metavar="SIG")
    p_tsd.set_defaults(func=_cmd_tmux_session_destroy)

    # tmux session-attach
    p_tsa = tmux_sub.add_parser("session-attach", help="get metadata for a tmux session")
    p_tsa.add_argument("--name", required=True, metavar="NAME")
    p_tsa.set_defaults(func=_cmd_tmux_session_attach)

    return parser


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main() -> None:
    parser = _build_parser()
    args = parser.parse_args()
    try:
        args.func(args)
    except _McpError as exc:
        if args.json:
            print(json.dumps(exc.structured, indent=2))
        else:
            print(str(exc), file=sys.stderr)
        sys.exit(1)
    except Exception as exc:
        if args.json:
            print(json.dumps({"error": str(exc), "isError": True}, indent=2))
        else:
            print(f"error: {exc}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
