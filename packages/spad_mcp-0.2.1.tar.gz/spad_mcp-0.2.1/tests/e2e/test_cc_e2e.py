"""Full CC E2E test. Requires SPAD_CC_E2E=1 env var.
IMPORTANT: This test launches real Claude Code against the user's OAuth session.
Each run costs real tokens. Default pytest runs MUST NOT execute this test.
Set SPAD_CC_E2E=1 and run: pytest -m cc
"""
from __future__ import annotations

import asyncio
import json
import logging
import time

import pytest

log = logging.getLogger(__name__)

pytestmark = pytest.mark.cc

SESSION_NAME = "spad-cc-e2e"


def _call_sync(spad_client, tool: str, args: dict | None = None) -> dict:
    r = spad_client(tool, args or {})
    if r.is_error:
        raise RuntimeError(r.content[0].text if r.content else "tool error")
    return json.loads(r.content[0].text)


def test_cc_one_round_trip(spad_client, tmux_isolated):
    """Single CC session: create, prompt, idle, screenshot, destroy."""
    # Step 1: create session
    result = _call_sync(spad_client, "tmux_session_create", {
        "name": SESSION_NAME,
        "command": ["claude", "--dangerously-skip-permissions"],
        "plugin": "claude-code",
    })
    assert result.get("ok") is True
    assert result.get("session") == SESSION_NAME
    pid = result.get("pid", 0)
    assert pid > 0, "Expected a real PID from tmux_session_create"

    try:
        # Step 2: give CC time to start up and render its initial UI.
        # CC only writes its JSONL when the first prompt is processed --
        # idle-discovery is lazy (poll_for_jsonl inside the wait loop).
        # 10s for CC to reach interactive state (TUI startup + render).
        log.info("waiting 10s for CC to reach interactive state")
        time.sleep(10)

        # Step 3: send prompt, wait for idle.
        # Lazy JSONL discovery fires inside tmux_interact once CC writes it.
        interact = _call_sync(spad_client, "tmux_interact", {
            "session": SESSION_NAME,
            "send": ["s:reply with the single word READY", "k:Enter"],
            "wait": {"events": ["idle"], "timeout": 120},
        })
        assert interact.get("event") == "idle", f"unexpected event: {interact.get('event')}"
        assert interact.get("elapsed", 0) > 0

        if "model" not in interact:
            log.warning("model field missing from idle event -- CC plugin version may differ")
        else:
            log.info("model: %s", interact["model"])

        if "ctx_pct" not in interact:
            log.warning("ctx_pct missing -- spad ctx hook not installed; idle detection still works")

        # Step 4: screenshot, assert READY visible
        screenshot = _call_sync(spad_client, "tmux_screenshot", {
            "session": SESSION_NAME,
            "lines": 50,
        })
        assert "READY" in screenshot.get("content", ""), \
            "READY not found in pane screenshot -- CC may not have responded"

    finally:
        # Step 5: destroy session
        try:
            _call_sync(spad_client, "tmux_session_destroy", {"name": SESSION_NAME})
        except Exception as exc:
            log.warning("session destroy failed: %s", exc)
