"""MCP-over-HTTP integration tests. Require a live spad-mcp server.
All tests are marked integration and run by default with plain pytest.
"""
from __future__ import annotations

import asyncio
import json
import os
import subprocess
import sys
import time

import httpx
import pytest

pytestmark = pytest.mark.integration


# Helper to extract dict from call result
def _data(result) -> dict:
    import json as _json
    return _json.loads(result.content[0].text)


def _is_error(result) -> bool:
    return bool(result.is_error)


# 1
def test_status_round_trip(spad_client):
    r = spad_client("status")
    assert not _is_error(r)
    d = _data(r)
    assert d["ok"] is True
    assert "version" in d
    assert "plugins" in d
    assert "bound_paths" in d


# 2
def test_shell_round_trip(spad_client):
    r = spad_client("shell", {"argv": ["echo", "hello"]})
    assert not _is_error(r)
    d = _data(r)
    assert d["stdout"].startswith("hello")
    assert d["rc"] == 0


# 3
def test_file_read_lines_truncation_flag(spad_client, tmp_path):
    p = tmp_path / "big.txt"
    p.write_text("\n".join(f"line{i}" for i in range(250)) + "\n")
    r = spad_client("file_read", {"path": str(p)})
    assert not _is_error(r)
    d = _data(r)
    assert d["truncated"] is True
    assert d["units_read"] == 200
    assert d["eof"] is False


# 4
def test_file_read_chars_truncation(spad_client, tmp_path):
    p = tmp_path / "chars.txt"
    p.write_text("x" * 9000)
    r = spad_client("file_read", {"path": str(p), "mode": "chars"})
    assert not _is_error(r)
    d = _data(r)
    assert d["truncated"] is True
    assert d["units_read"] == 8000


# 5
def test_file_read_bytes_truncation(spad_client, tmp_path):
    p = tmp_path / "bytes.bin"
    p.write_bytes(b"x" * 9000)
    r = spad_client("file_read", {"path": str(p), "mode": "bytes"})
    assert not _is_error(r)
    d = _data(r)
    assert d["truncated"] is True
    assert d["bytes_read"] == 8192


# 6
def test_file_read_eof_true_when_done(spad_client, tmp_path):
    p = tmp_path / "small.txt"
    p.write_text("\n".join(f"line{i}" for i in range(50)) + "\n")
    r = spad_client("file_read", {"path": str(p)})
    assert not _is_error(r)
    d = _data(r)
    assert d["eof"] is True
    assert d["truncated"] is False


# 7
def test_file_write_refuses_existing_no_overwrite(spad_client, tmp_path):
    p = tmp_path / "exists.txt"
    p.write_text("original")
    r = spad_client("file_write", {"path": str(p), "content": "new"})
    assert _is_error(r)
    err = r.content[0].text if r.content else ""
    assert "file exists at" in err


# 8
def test_file_write_succeeds_with_overwrite(spad_client, tmp_path):
    p = tmp_path / "exists.txt"
    p.write_text("original")
    r = spad_client("file_write", {"path": str(p), "content": "new", "overwrite": True})
    assert not _is_error(r)
    d = _data(r)
    assert d["ok"] is True


# 9
def test_file_edit_missing_file_message(spad_client, tmp_path):
    path = str(tmp_path / "nope.txt")
    r = spad_client("file_edit", {"path": path, "old": "x", "new": "y"})
    assert _is_error(r)
    err = r.content[0].text if r.content else ""
    assert "file does not exist at" in err
    assert "file_edit only modifies existing files" in err


# 10
def test_file_grep_match_count_present(spad_client, tmp_path):
    for i in range(5):
        (tmp_path / f"f{i}.txt").write_text("match_token\n")
    r = spad_client("file_grep", {"root": str(tmp_path), "pattern": "match_token"})
    assert not _is_error(r)
    d = _data(r)
    assert "match_count" in d
    assert "truncated" in d
    assert d["match_count"] >= len(d["matches"])


# 11
def test_file_glob_match_count_present(spad_client, tmp_path):
    for i in range(5):
        (tmp_path / f"f{i}.py").write_text("")
    r = spad_client("file_glob", {"root": str(tmp_path), "pattern": "*.py"})
    assert not _is_error(r)
    d = _data(r)
    assert "match_count" in d
    assert "truncated" in d
    assert d["match_count"] == 5


# 12
def test_file_insert_position_start(spad_client, tmp_path):
    p = tmp_path / "f.txt"
    p.write_text("line1\nline2\n")
    r = spad_client("file_insert", {"path": str(p), "content": "new\n", "position": "start"})
    assert not _is_error(r)
    d = _data(r)
    assert d["line"] == 1
    assert p.read_text().startswith("new\nline1\n")


# 13
def test_file_insert_position_end(spad_client, tmp_path):
    p = tmp_path / "f.txt"
    p.write_text("line1\nline2\n")
    r = spad_client("file_insert", {"path": str(p), "content": "new\n", "position": "end"})
    assert not _is_error(r)
    assert p.read_text().endswith("line2\nnew\n")


# 14
def test_file_insert_position_before(spad_client, tmp_path):
    p = tmp_path / "f.txt"
    p.write_text("line1\nline2\n")
    r = spad_client("file_insert", {"path": str(p), "content": "new\n", "position": "before", "anchor": "line2"})
    assert not _is_error(r)
    lines = p.read_text().splitlines()
    idx = lines.index("line2")
    assert lines[idx - 1] == "new"


# 15
def test_file_insert_position_after(spad_client, tmp_path):
    p = tmp_path / "f.txt"
    p.write_text("line1\nline2\n")
    r = spad_client("file_insert", {"path": str(p), "content": "new\n", "position": "after", "anchor": "line1"})
    assert not _is_error(r)
    lines = p.read_text().splitlines()
    idx = lines.index("line1")
    assert lines[idx + 1] == "new"


# 16
def test_oob_upload_download_round_trip_small(spad_server, tmp_path):
    base = spad_server.replace("/mcp", "")
    blob = b"hello oob e2e"
    dest = str(tmp_path / "blob.bin")
    r = httpx.post(f"{base}/spad/upload?path={dest}&overwrite=true", content=blob)
    assert r.status_code == 200
    dl = httpx.get(f"{base}/spad/download?path={dest}")
    assert dl.status_code == 200
    assert dl.content == blob


# 17
def test_oob_upload_download_streaming_10mb(spad_server, tmp_path):
    import os as _os
    base = spad_server.replace("/mcp", "")
    blob = _os.urandom(10 * 1024 * 1024)
    dest = str(tmp_path / "big.bin")
    r = httpx.post(f"{base}/spad/upload?path={dest}&overwrite=true", content=blob, timeout=30.0)
    assert r.status_code == 200
    dl = httpx.get(f"{base}/spad/download?path={dest}", timeout=30.0)
    assert dl.status_code == 200
    assert dl.content == blob


# 18
def test_oob_download_404_on_missing_file(spad_server, tmp_path):
    base = spad_server.replace("/mcp", "")
    r = httpx.get(f"{base}/spad/download?path={tmp_path}/nonexistent.bin")
    assert r.status_code == 404


# 19
def test_oob_upload_409_without_overwrite(spad_server, tmp_path):
    base = spad_server.replace("/mcp", "")
    p = tmp_path / "existing.bin"
    p.write_bytes(b"original")
    r = httpx.post(f"{base}/spad/upload?path={p}", content=b"new")
    assert r.status_code == 409


# 20
def test_oob_upload_200_with_overwrite(spad_server, tmp_path):
    base = spad_server.replace("/mcp", "")
    p = tmp_path / "existing.bin"
    p.write_bytes(b"original")
    r = httpx.post(f"{base}/spad/upload?path={p}&overwrite=true", content=b"replaced")
    assert r.status_code == 200
    assert p.read_bytes() == b"replaced"


# 21
def test_cli_status_subprocess(spad_server):
    r = subprocess.run(
        [sys.executable, "-m", "spad_mcp.cli.spad", "--server", spad_server, "status"],
        capture_output=True, text=True, timeout=15,
    )
    assert r.returncode == 0
    assert "version" in r.stdout


# 22
def test_cli_put_get_round_trip_subprocess(spad_server, tmp_path):
    import random
    base = spad_server.replace("/mcp", "")
    local = tmp_path / "local.bin"
    local.write_bytes(b"put-get-test-data")
    remote = f"/tmp/spad-e2e-{random.randint(100000, 999999)}.bin"
    recovered = tmp_path / "recovered.bin"

    put_r = subprocess.run(
        [sys.executable, "-m", "spad_mcp.cli.spad", "--server", spad_server,
         "put", str(local), remote],
        capture_output=True, text=True, timeout=15,
    )
    assert put_r.returncode == 0, put_r.stderr

    get_r = subprocess.run(
        [sys.executable, "-m", "spad_mcp.cli.spad", "--server", spad_server,
         "get", remote, str(recovered)],
        capture_output=True, text=True, timeout=15,
    )
    assert get_r.returncode == 0, get_r.stderr
    assert local.read_bytes() == recovered.read_bytes()


# 23
def test_concurrent_shell_calls(spad_client, spad_server):
    from fastmcp import Client as _Client
    async def _run():
        async with _Client(spad_server) as client:
            tasks = [client.call_tool("shell", {"argv": ["sleep", "0.1"]}) for _ in range(5)]
            results = await asyncio.gather(*tasks)
            return results
    import time as _time
    start = _time.monotonic()
    results = asyncio.run(_run())
    elapsed = _time.monotonic() - start
    assert elapsed < 3.0
    for r in results:
        d = json.loads(r.content[0].text)
        assert d["rc"] == 0


# 24
def test_error_path_keeps_server_responsive(spad_client, tmp_path):
    bad_path = str(tmp_path / "nope.txt")
    err_r = spad_client("file_read", {"path": bad_path})
    assert _is_error(err_r)
    ok_r = spad_client("status")
    assert not _is_error(ok_r)
    assert _data(ok_r)["ok"] is True
