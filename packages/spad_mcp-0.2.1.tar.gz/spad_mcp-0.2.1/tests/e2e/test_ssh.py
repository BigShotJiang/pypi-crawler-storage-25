"""SSH-tunnel integration tests. Marked ssh -- run with: pytest -m ssh

Requires at least one entry in tests/e2e/spad-test.toml under [ssh] targets.
Copy tests/e2e/spad-test.toml.example to spad-test.toml and populate.
Tests auto-skip with a clear reason when no targets are configured.
"""
from __future__ import annotations

import asyncio
import base64
import json
import os
import shlex
import subprocess
import sys

import pytest

pytestmark = pytest.mark.ssh


def _call_sync(url: str, tool: str, args: dict | None = None) -> dict:
    from fastmcp import Client
    async def _inner():
        async with Client(url) as c:
            return await c.call_tool(tool, args or {}, raise_on_error=False)
    r = asyncio.run(_inner())
    return json.loads(r.content[0].text)


def test_server_binds_127_0_0_1_only(spad_server):
    import re
    port = int(re.search(r":(\d+)/", spad_server).group(1))
    try:
        result = subprocess.run(["ss", "-tln"], capture_output=True, text=True)
    except FileNotFoundError:
        pytest.skip("ss not available on this system")
    if result.returncode != 0:
        pytest.skip("ss not available on this system")
    lines = result.stdout.splitlines()
    found_127 = any(f"127.0.0.1:{port}" in l for l in lines)
    found_open = any(f"0.0.0.0:{port}" in l or f":::{port}" in l for l in lines)
    assert found_127, f"spad server not listening on 127.0.0.1:{port}"
    assert not found_open, f"spad server is listening on a public interface (port {port})"


def test_status_through_tunnel(ssh_tunnel):
    url, inner_port, outer_port = ssh_tunnel
    d = _call_sync(url, "status")
    assert d["ok"] is True


def test_shell_through_tunnel(ssh_tunnel):
    url, _, _ = ssh_tunnel
    d = _call_sync(url, "shell", {"argv": ["echo", "tunnel-ok"]})
    assert d["stdout"].startswith("tunnel-ok")
    assert d["rc"] == 0


def test_file_read_through_tunnel(ssh_tunnel):
    url, _, _ = ssh_tunnel
    remote_path = "/tmp/spad-tunnel-test-read.txt"
    # Create the test file on the remote via shell tool, then read it back.
    # tmp_path is a local path; the remote spad server cannot see it.
    sh = _call_sync(url, "shell", {"argv": ["bash", "-c",
                                            f"printf 'tunnel content\\n' > {remote_path}"]})
    assert sh["rc"] == 0, f"shell failed: {sh}"
    d = _call_sync(url, "file_read", {"path": remote_path})
    assert "tunnel content" in d["content"]
    _call_sync(url, "shell", {"argv": ["rm", "-f", remote_path]})


def test_tmux_interact_send_only_through_tunnel(ssh_tunnel, tmux_isolated):
    url, _, _ = ssh_tunnel
    try:
        import libtmux  # noqa: F401
    except ImportError:
        pytest.skip("libtmux not installed -- skipping tmux tunnel test")
    session_name = "spad-e2e-ssh"
    try:
        create_d = _call_sync(url, "tmux_session_create", {
            "name": session_name,
            "command": ["bash"],
        })
        assert create_d.get("ok") is True
        send_d = _call_sync(url, "tmux_interact", {
            "session": session_name,
            "send": ["s:echo TUNNEL", "k:Enter"],
        })
        assert send_d.get("sent") is True
    finally:
        try:
            _call_sync(url, "tmux_session_destroy", {"name": session_name})
        except Exception:
            pass


def test_ssh_tunnel_teardown_clean(ssh_tunnel):
    url, inner_port, outer_port = ssh_tunnel
    # Verify tunnel is live now
    d = _call_sync(url, "status")
    assert d["ok"] is True
    # Teardown happens via fixture -- just assert the fixture cleaned up
    # by checking that we got this far without error.
    # The fixture teardown sends SIGTERM and waits.


def test_scp_then_file_read_round_trip(
    spad_client_through_tunnel,
    ssh_tunnel_target: dict,
    tmp_path,
) -> None:
    """SCP a binary blob to the remote then read it back via spad file_read.

    Validates the OOB scp story end-to-end: bytes written locally match bytes
    read from the remote spad server after transfer. Parametrizes over all
    configured ssh.targets the same way as the other tunnel tests.
    """
    # Generate a small random binary blob
    blob = os.urandom(4096)
    local_path = tmp_path / "spad-test-scp.bin"
    local_path.write_bytes(blob)

    # SCP the blob to the target
    scp_cmd: str = ssh_tunnel_target["scp_command"]
    scp_argv = shlex.split(
        scp_cmd.format(src=str(local_path), dst="/tmp/spad-test-scp.bin")
    )
    scp_result = subprocess.run(scp_argv, capture_output=True, text=True)
    if scp_result.returncode != 0:
        pytest.fail(
            f"scp failed (rc={scp_result.returncode})\n"
            f"  stdout: {scp_result.stdout.strip()}\n"
            f"  stderr: {scp_result.stderr.strip()}"
        )

    # Read it back through the tunnel via spad file_read (bytes mode)
    d = spad_client_through_tunnel(
        "file_read",
        {"path": "/tmp/spad-test-scp.bin", "mode": "bytes"},
    )

    assert "content_b64" in d, f"Expected content_b64 in response, got: {list(d.keys())}"
    returned_bytes = base64.b64decode(d["content_b64"])
    assert returned_bytes == blob, (
        f"Byte mismatch: sent {len(blob)} bytes, "
        f"got back {len(returned_bytes)} bytes"
    )
    # /tmp/spad-test-scp.bin cleanup is handled by ssh_tunnel fixture teardown
