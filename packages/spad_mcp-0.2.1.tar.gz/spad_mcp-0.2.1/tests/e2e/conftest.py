"""E2E test fixtures for spad-mcp."""
from __future__ import annotations

import asyncio
import json
import os
import shlex
import signal
import socket
import subprocess
import sys
import tempfile
import time
import tomllib
from pathlib import Path
from typing import Generator

import pytest
import httpx
from fastmcp import Client


# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------

_REPO_ROOT: Path = Path(__file__).parent.parent.parent
_E2E_DIR: Path = Path(__file__).parent
_TOML_PATH: Path = _E2E_DIR / "spad-test.toml"


# ---------------------------------------------------------------------------
# Config loading (module-level so parametrization can use it at collection)
# ---------------------------------------------------------------------------

def _load_e2e_config() -> dict:
    """Load tests/e2e/spad-test.toml via tomllib if present, else return {}."""
    if _TOML_PATH.exists():
        with open(_TOML_PATH, "rb") as fh:
            return tomllib.load(fh)
    return {}


_E2E_CONFIG: dict = _load_e2e_config()
_SSH_TARGETS: list[dict] = _E2E_CONFIG.get("ssh", {}).get("targets", [])

# When no targets are configured, parametrize with a single skip-marked param
# so that tests using ssh_tunnel are collected but marked as skip (not ERROR).
_SSH_FIXTURE_PARAMS: list = (
    _SSH_TARGETS
    if _SSH_TARGETS
    else [
        pytest.param(
            None,
            marks=pytest.mark.skip(
                reason="no ssh.targets configured in tests/e2e/spad-test.toml"
            ),
        )
    ]
)


# ---------------------------------------------------------------------------
# Port helpers
# ---------------------------------------------------------------------------

def _find_free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def _wait_for_server(url: str, timeout: float = 15.0) -> None:
    """Poll MCP endpoint until it responds or timeout expires."""
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            resp = httpx.post(
                url,
                json={
                    "jsonrpc": "2.0",
                    "id": 1,
                    "method": "tools/call",
                    "params": {"name": "status", "arguments": {}},
                },
                timeout=2.0,
            )
            if resp.status_code < 500:
                return
        except Exception:
            pass
        time.sleep(0.2)
    raise RuntimeError(f"spad server at {url} did not become ready in {timeout}s")


def _wait_for_port(host: str, port: int, timeout: float = 10.0) -> None:
    """Poll until a TCP port accepts connections."""
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            with socket.create_connection((host, port), timeout=1.0):
                return
        except OSError:
            time.sleep(0.2)
    raise RuntimeError(f"port {host}:{port} not ready after {timeout}s")


# ---------------------------------------------------------------------------
# SSH transport helpers
# ---------------------------------------------------------------------------

def _ssh_argv_prefix(ssh_cmd_template: str) -> list[str]:
    """Split the ssh prefix from a template like 'ssh user@host {cmd}'.

    Returns the token list up to (not including) the {cmd} placeholder.
    The caller appends the remote command string as a single additional token
    so the remote shell receives it intact (including any metacharacters).
    """
    prefix_str = ssh_cmd_template.split("{cmd}", 1)[0].rstrip()
    return shlex.split(prefix_str)


def _run_ssh(
    ssh_cmd_template: str,
    remote_cmd: str,
    *,
    check: bool = True,
) -> subprocess.CompletedProcess:
    """Run remote_cmd on the target via ssh_cmd_template.

    remote_cmd is passed as a single string argument to ssh so the remote
    shell interprets metacharacters (pipes, redirects, etc.) correctly.
    Calls pytest.fail on non-zero exit if check=True.
    """
    argv = _ssh_argv_prefix(ssh_cmd_template) + [remote_cmd]
    result = subprocess.run(argv, capture_output=True, text=True)
    if check and result.returncode != 0:
        pytest.fail(
            f"SSH command failed (rc={result.returncode})\n"
            f"  remote_cmd: {remote_cmd}\n"
            f"  stdout: {result.stdout.strip()}\n"
            f"  stderr: {result.stderr.strip()}"
        )
    return result


# ---------------------------------------------------------------------------
# Session fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(scope="session")
def _e2e_config() -> dict:
    """Session-scoped fixture: returns the loaded spad-test.toml dict (or {})."""
    return _E2E_CONFIG


@pytest.fixture(scope="session")
def spad_server() -> Generator[str, None, None]:
    """Spawn a local spad-mcp server on a random port. Yields the MCP URL."""
    port = _find_free_port()
    url = f"http://127.0.0.1:{port}/mcp"
    # TMUX_GATE_BYPASS=1 lets the spad server call libtmux send_keys through
    # the tmux-gate wrapper. The spad server IS the legitimate orchestration
    # layer -- blocking its send-keys defeats the purpose.
    server_env = os.environ.copy()
    server_env["TMUX_GATE_BYPASS"] = "1"

    proc = subprocess.Popen(
        [sys.executable, "-m", "spad_mcp.server", "--port", str(port)],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        env=server_env,
    )
    try:
        _wait_for_server(url)
        yield url
    finally:
        proc.send_signal(signal.SIGTERM)
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait()


@pytest.fixture(scope="session")
def tmux_isolated() -> Generator[str, None, None]:
    """Isolated tmux server on socket spad-e2e. Tears down on session end."""
    socket_name = "spad-e2e"
    yield socket_name
    subprocess.run(
        ["tmux", "-L", socket_name, "kill-server"],
        capture_output=True,
    )


# ---------------------------------------------------------------------------
# Per-request (function-scope) fixtures
# ---------------------------------------------------------------------------

@pytest.fixture()
def spad_client(spad_server: str):
    """Sync fastmcp.Client call helper bound to the local spad_server URL."""
    def call(tool_name: str, arguments: dict | None = None) -> dict:
        async def _inner():
            async with Client(spad_server) as client:
                return await client.call_tool(
                    tool_name, arguments or {}, raise_on_error=False
                )
        return asyncio.run(_inner())

    return call


# ---------------------------------------------------------------------------
# SSH parametrized fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(
    params=_SSH_FIXTURE_PARAMS,
    ids=lambda t: t["label"] if isinstance(t, dict) else "no-target",
)
def ssh_tunnel_target(request) -> dict:
    """Yield the target config dict for the current parametrized SSH target.

    Tests that use ssh_tunnel or ssh_tunnel_target are automatically
    parametrized once per entry in ssh.targets in spad-test.toml.
    When no targets are configured, the parametrize skip mark causes the
    test to be collected but skipped -- not errored.
    """
    if request.param is None:
        # Belt-and-suspenders: the pytest.mark.skip on the param handles
        # collection, but guard here in case fixture runs anyway.
        pytest.skip("no ssh.targets configured in tests/e2e/spad-test.toml")
    return request.param


@pytest.fixture()
def ssh_tunnel(
    ssh_tunnel_target: dict,
) -> Generator[tuple[str, int, int], None, None]:
    """Deploy spad-mcp to the target and establish an SSH tunnel.

    Setup sequence:
      1. Build wheel from local checkout.
      2. SCP wheel to target (/tmp/spad-mcp-test.whl).
      3. pip install --user --force-reinstall on target.
      4. Start spad-server on target (nohup, port 9830).
      5. Open local SSH tunnel; wait for MCP endpoint to respond.

    Yields (tunnel_url, remote_port, outer_port).

    Teardown: kills tunnel, ssh-stops server, removes temp files.
    Failures in the deploy chain are reported via pytest.fail (loud),
    not pytest.skip. Skip only happens when no targets are configured.

    Target preconditions: Python 3.12+, pip, sshd accepting your auth,
    write access to /tmp, ~/.local/bin on PATH.
    """
    target = ssh_tunnel_target
    ssh_cmd: str = target["ssh_command"]
    scp_cmd: str = target["scp_command"]
    tunnel_cmd: str = target["tunnel_command"]
    remote_port: int = 9830

    with tempfile.TemporaryDirectory() as tmp_dir:
        # -- Step 1: build wheel from local checkout --
        build_result = subprocess.run(
            [
                sys.executable, "-m", "pip", "wheel",
                str(_REPO_ROOT),
                "-w", tmp_dir,
                "--no-deps",
            ],
            capture_output=True,
            text=True,
        )
        if build_result.returncode != 0:
            pytest.fail(
                f"Wheel build failed (rc={build_result.returncode})\n"
                f"  stdout: {build_result.stdout.strip()}\n"
                f"  stderr: {build_result.stderr.strip()}"
            )
        wheel_files = list(Path(tmp_dir).glob("*.whl"))
        if not wheel_files:
            pytest.fail("Wheel build succeeded but produced no .whl file")
        wheel_path = str(wheel_files[0])
        # Preserve the wheel filename (e.g. spad_mcp-0.2.1-py3-none-any.whl).
        # pip rejects a renamed file that does not match the wheel naming spec.
        wheel_basename: str = wheel_files[0].name
        remote_wheel: str = f"/tmp/{wheel_basename}"

        # -- Step 2: scp wheel to target --
        scp_argv = shlex.split(
            scp_cmd.format(src=wheel_path, dst=remote_wheel)
        )
        scp_result = subprocess.run(scp_argv, capture_output=True, text=True)
        if scp_result.returncode != 0:
            pytest.fail(
                f"scp failed (rc={scp_result.returncode})\n"
                f"  stdout: {scp_result.stdout.strip()}\n"
                f"  stderr: {scp_result.stderr.strip()}"
            )

        # -- Step 3: pip install on target (core wheel + tmux extra) --
        # Install the wheel first, then libtmux so tmux tools are available.
        # libtmux is an optional extra; install it explicitly so the full
        # tool surface (including tmux_session_create etc.) is present.
        _run_ssh(
            ssh_cmd,
            f"pip install --user --force-reinstall {remote_wheel}",
        )
        _run_ssh(ssh_cmd, "pip install --user 'libtmux>=0.31'")

        # -- Step 4: start spad-server on target (background, PID recorded) --
        # The trailing 'sleep 2' lets the server bind before we proceed.
        _run_ssh(
            ssh_cmd,
            "(nohup ~/.local/bin/spad-server --port 9830 "
            "> /tmp/spad-test.log 2>&1 & echo $!) | tee /tmp/spad-test.pid; sleep 2",
        )

        # -- Step 5: open local SSH tunnel --
        outer_port = _find_free_port()
        tunnel_argv = shlex.split(tunnel_cmd.format(outer=outer_port))
        tunnel_proc = subprocess.Popen(
            tunnel_argv,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )

        try:
            # Wait for tunnel port to accept connections, then verify MCP endpoint.
            try:
                _wait_for_port("127.0.0.1", outer_port, timeout=10.0)
            except RuntimeError as exc:
                pytest.fail(f"SSH tunnel port did not open: {exc}")

            tunnel_url = f"http://localhost:{outer_port}/mcp"
            try:
                _wait_for_server(tunnel_url, timeout=20.0)
            except RuntimeError as exc:
                pytest.fail(f"Remote spad-server did not respond through tunnel: {exc}")

            yield tunnel_url, remote_port, outer_port

        finally:
            # -- Teardown: kill tunnel --
            try:
                tunnel_proc.send_signal(signal.SIGTERM)
                tunnel_proc.wait(timeout=5)
            except (subprocess.TimeoutExpired, OSError):
                try:
                    tunnel_proc.kill()
                    tunnel_proc.wait()
                except OSError:
                    pass

            # -- Teardown: stop server + remove temp files on target --
            # remote_wheel uses the real wheel filename (wheel naming spec).
            # spad-test-scp.bin is created by test_scp_then_file_read_round_trip;
            # including it here keeps teardown idempotent across all ssh tests.
            _run_ssh(
                ssh_cmd,
                f"pkill -F /tmp/spad-test.pid 2>/dev/null || true; "
                f"rm -f /tmp/spad-test.pid /tmp/spad-test.log "
                f"{remote_wheel} /tmp/spad-test-scp.bin",
                check=False,
            )


@pytest.fixture()
def spad_client_through_tunnel(ssh_tunnel: tuple[str, int, int]):
    """Sync fastmcp.Client call helper bound to the SSH tunnel URL.

    Returns a callable: call(tool_name, args) -> dict (JSON-parsed response).
    """
    url, _, _ = ssh_tunnel

    def call(tool_name: str, arguments: dict | None = None) -> dict:
        async def _inner():
            async with Client(url) as client:
                return await client.call_tool(
                    tool_name, arguments or {}, raise_on_error=False
                )
        r = asyncio.run(_inner())
        return json.loads(r.content[0].text)

    return call


# ---------------------------------------------------------------------------
# Pytest hooks
# ---------------------------------------------------------------------------

def pytest_configure(config) -> None:
    config.addinivalue_line("markers", "integration: MCP-over-HTTP integration tests")
    config.addinivalue_line(
        "markers",
        "ssh: SSH-tunnel tests -- configure targets in tests/e2e/spad-test.toml",
    )
    config.addinivalue_line(
        "markers",
        "cc: real Claude Code E2E tests (requires SPAD_CC_E2E=1 or cc.enabled=true in spad-test.toml)",
    )


def pytest_collection_modifyitems(config, items) -> None:
    # env var wins; spad-test.toml cc.enabled is the config-file alternative
    cc_enabled: bool = bool(os.environ.get("SPAD_CC_E2E")) or bool(
        _E2E_CONFIG.get("cc", {}).get("enabled", False)
    )
    for item in items:
        if item.get_closest_marker("cc"):
            if not cc_enabled:
                item.add_marker(
                    pytest.mark.skip(
                        reason=(
                            "set SPAD_CC_E2E=1 or cc.enabled=true in "
                            "tests/e2e/spad-test.toml to run CC E2E tests"
                        )
                    )
                )
