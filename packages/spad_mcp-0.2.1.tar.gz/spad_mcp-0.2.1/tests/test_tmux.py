"""Tests for spad_mcp.adapters.tmux.

Unit tests exercise _wait_for_events and _wait_for_events_with_send directly
with a mocked pane so they run without a live tmux server.

Integration tests (requires_tmux mark) use a real isolated tmux server socket
and are skipped when the tmux binary is not in PATH.

All tests are skipped when libtmux is not installed (pytest.importorskip).
"""
from __future__ import annotations

import os
import shutil
import time
from typing import Optional
from unittest.mock import MagicMock

import pytest

# Skip this entire module if libtmux is not installed.
libtmux = pytest.importorskip("libtmux")

# Integration-test guard: skip when the tmux binary is absent.
_tmux_bin = shutil.which("tmux")
requires_tmux = pytest.mark.skipif(
    _tmux_bin is None,
    reason="tmux binary not in PATH",
)

from spad_mcp.adapters.tmux import (  # noqa: E402  (libtmux guaranteed above)
    _SessionEntry,
    _capture_pane,
    _wait_for_events,
    _wait_for_events_with_send,
)
from spad_mcp.core.events import EVENT_EXIT, EVENT_MATCH, EVENT_TIMEOUT  # noqa: E402

# PID that exceeds Linux max (4194304) -- /proc/<pid> will not exist.
_DEAD_PID: int = 1 << 30


# ---------------------------------------------------------------------------
# Mock helpers
# ---------------------------------------------------------------------------

def _mock_pane(call_outputs: list[list[str]]) -> MagicMock:
    """Return a mock pane whose cmd() yields successive stdout lists.

    The last entry in call_outputs repeats indefinitely.
    Simulates _capture_pane: result.stdout is a list of strings that
    _capture_pane joins with newlines.
    """
    pane = MagicMock()
    outputs = list(call_outputs)
    call_idx: list[int] = [0]

    def _side(*args, **kwargs):
        result = MagicMock()
        idx = min(call_idx[0], len(outputs) - 1)
        result.stdout = list(outputs[idx])
        call_idx[0] += 1
        return result

    pane.cmd.side_effect = _side
    return pane


def _dead_entry() -> MagicMock:
    """Mock _SessionEntry whose PID is guaranteed not to exist in /proc."""
    entry = MagicMock(spec=_SessionEntry)
    entry.pid = _DEAD_PID
    entry.plugin_name = None
    return entry


def _mock_hosts() -> tuple[MagicMock, MagicMock]:
    """Return (watcher_host, plugin_host) mocks adequate for unit tests."""
    wh = MagicMock()
    wh.add.return_value = 1
    ph = MagicMock()
    return wh, ph


# ---------------------------------------------------------------------------
# KB-1 regression: same-tick tiebreak follows declared events list order
# ---------------------------------------------------------------------------
# Before the fix, exit was always checked before match regardless of events
# list order.  After the fix, the declared order wins.
# These tests arrange for BOTH exit and match to be satisfiable on the same
# poll tick (dead PID + matching pane content), then assert that whichever
# event type is listed first is the one that fires.

def _pane_exit_and_match() -> MagicMock:
    """Pane mock: empty baseline, then one line containing the KB1 marker."""
    return _mock_pane([
        [],                                  # call 0: baseline (empty)
        ["context before", "KB1_MARKER here", "context after"],  # call 1+: poll
    ])


def test_kb1_exit_wins_when_declared_first_wait_only():
    """KB-1: exit fires before match when events=['exit', {'match': ...}]."""
    pane = _pane_exit_and_match()
    entry = _dead_entry()
    wh, ph = _mock_hosts()

    result = _wait_for_events(
        pane=pane,
        entry=entry,
        wait={"events": ["exit", {"match": "KB1_MARKER"}], "timeout": 2},
        watcher_host=wh,
        plugin_host=ph,
    )

    assert result["event"] == EVENT_EXIT, (
        f"exit should win when declared first; got {result['event']!r}"
    )


def test_kb1_match_wins_when_declared_first_wait_only():
    """KB-1: match fires before exit when events=[{'match': ...}, 'exit']."""
    pane = _pane_exit_and_match()
    entry = _dead_entry()
    wh, ph = _mock_hosts()

    result = _wait_for_events(
        pane=pane,
        entry=entry,
        wait={"events": [{"match": "KB1_MARKER"}, "exit"], "timeout": 2},
        watcher_host=wh,
        plugin_host=ph,
    )

    assert result["event"] == EVENT_MATCH, (
        f"match should win when declared first; got {result['event']!r}"
    )


def test_kb1_exit_wins_when_declared_first_with_send():
    """KB-1 (with_send path): exit fires before match when listed first."""
    pane = _pane_exit_and_match()
    entry = _dead_entry()
    wh, ph = _mock_hosts()

    result = _wait_for_events_with_send(
        pane=pane,
        entry=entry,
        wait={"events": ["exit", {"match": "KB1_MARKER"}], "timeout": 2},
        watcher_host=wh,
        plugin_host=ph,
        send=[],
    )

    assert result["event"] == EVENT_EXIT


def test_kb1_match_wins_when_declared_first_with_send():
    """KB-1 (with_send path): match fires before exit when listed first."""
    pane = _pane_exit_and_match()
    entry = _dead_entry()
    wh, ph = _mock_hosts()

    result = _wait_for_events_with_send(
        pane=pane,
        entry=entry,
        wait={"events": [{"match": "KB1_MARKER"}, "exit"], "timeout": 2},
        watcher_host=wh,
        plugin_host=ph,
        send=[],
    )

    assert result["event"] == EVENT_MATCH


# ---------------------------------------------------------------------------
# KB-2 regression: pane-match 'line' is the full containing line
# ---------------------------------------------------------------------------
# Before the fix, both 'text' and 'line' were set to m.group() (the matched
# substring).  The watcher.py file-match path uses the full containing line
# for 'line'.  After the fix the two paths agree: 'text' = matched substring,
# 'line' = full containing line.

def _pane_with_embedded_match() -> MagicMock:
    """Pane mock: baseline empty, poll returns a line with surrounding text."""
    return _mock_pane([
        [],                                          # call 0: baseline
        ["prefix_text KB2_MARKER suffix_text"],      # call 1+: poll
    ])


def test_kb2_text_is_matched_substring_wait_only():
    """KB-2: 'text' field is m.group() -- the matched substring."""
    pane = _pane_with_embedded_match()
    entry = _dead_entry()
    wh, ph = _mock_hosts()

    result = _wait_for_events(
        pane=pane,
        entry=entry,
        wait={"events": [{"match": "KB2_MARKER"}], "timeout": 2},
        watcher_host=wh,
        plugin_host=ph,
    )

    assert result["event"] == EVENT_MATCH
    assert result["text"] == "KB2_MARKER", (
        f"text should be the matched substring, got {result['text']!r}"
    )


def test_kb2_line_is_full_containing_line_wait_only():
    """KB-2: 'line' field is the full containing line, not the matched text."""
    pane = _pane_with_embedded_match()
    entry = _dead_entry()
    wh, ph = _mock_hosts()

    result = _wait_for_events(
        pane=pane,
        entry=entry,
        wait={"events": [{"match": "KB2_MARKER"}], "timeout": 2},
        watcher_host=wh,
        plugin_host=ph,
    )

    assert result["event"] == EVENT_MATCH
    assert result["line"] == "prefix_text KB2_MARKER suffix_text", (
        f"line should be the full containing line, got {result['line']!r}"
    )


def test_kb2_text_is_matched_substring_with_send():
    """KB-2 (with_send path): 'text' is matched substring."""
    pane = _pane_with_embedded_match()
    entry = _dead_entry()
    wh, ph = _mock_hosts()

    result = _wait_for_events_with_send(
        pane=pane,
        entry=entry,
        wait={"events": [{"match": "KB2_MARKER"}], "timeout": 2},
        watcher_host=wh,
        plugin_host=ph,
        send=[],
    )

    assert result["event"] == EVENT_MATCH
    assert result["text"] == "KB2_MARKER"


def test_kb2_line_is_full_containing_line_with_send():
    """KB-2 (with_send path): 'line' is the full containing line."""
    pane = _pane_with_embedded_match()
    entry = _dead_entry()
    wh, ph = _mock_hosts()

    result = _wait_for_events_with_send(
        pane=pane,
        entry=entry,
        wait={"events": [{"match": "KB2_MARKER"}], "timeout": 2},
        watcher_host=wh,
        plugin_host=ph,
        send=[],
    )

    assert result["event"] == EVENT_MATCH
    assert result["line"] == "prefix_text KB2_MARKER suffix_text"


# ---------------------------------------------------------------------------
# Additional unit coverage: timeout, no-match, regex groups
# ---------------------------------------------------------------------------

def test_timeout_when_no_event_fires():
    """Wait with no satisfiable condition returns timeout event."""
    # Pane returns empty content, PID is alive (this process itself).
    pane = _mock_pane([[], []])
    entry = MagicMock(spec=_SessionEntry)
    entry.pid = os.getpid()  # alive PID
    entry.plugin_name = None
    wh, ph = _mock_hosts()

    result = _wait_for_events(
        pane=pane,
        entry=entry,
        wait={"events": [{"match": "WILL_NEVER_MATCH"}], "timeout": 0.4},
        watcher_host=wh,
        plugin_host=ph,
    )

    assert result["event"] == EVENT_TIMEOUT
    assert result["ok"] is False
    assert result["elapsed"] >= 0.0


def test_match_uses_first_matching_line():
    """When multiple new lines match, the first one (by line order) wins."""
    pane = _mock_pane([
        [],
        ["no match here", "FIRST_MATCH", "SECOND_MATCH"],
    ])
    entry = _dead_entry()
    wh, ph = _mock_hosts()

    result = _wait_for_events(
        pane=pane,
        entry=entry,
        wait={"events": [{"match": "MATCH"}], "timeout": 2},
        watcher_host=wh,
        plugin_host=ph,
    )

    # The 'line' should be FIRST_MATCH (first line containing the pattern)
    assert result["event"] == EVENT_MATCH
    assert result["line"] == "FIRST_MATCH"


def test_match_regex_group_captured_in_text():
    """Regex group match: 'text' is what the pattern captured."""
    pane = _mock_pane([
        [],
        ["output: value=42 end"],
    ])
    entry = _dead_entry()
    wh, ph = _mock_hosts()

    result = _wait_for_events(
        pane=pane,
        entry=entry,
        wait={"events": [{"match": r"value=\d+"}], "timeout": 2},
        watcher_host=wh,
        plugin_host=ph,
    )

    assert result["event"] == EVENT_MATCH
    assert result["text"] == "value=42"
    assert result["line"] == "output: value=42 end"


def test_invalid_regex_raises_value_error():
    """Malformed regex raises ValueError rather than crashing silently."""
    pane = _mock_pane([[]])
    entry = _dead_entry()
    wh, ph = _mock_hosts()

    with pytest.raises(ValueError, match="invalid match regex"):
        _wait_for_events(
            pane=pane,
            entry=entry,
            wait={"events": [{"match": "[unclosed"}], "timeout": 1},
            watcher_host=wh,
            plugin_host=ph,
        )


def test_exit_fires_for_dead_pid():
    """exit event fires when the bound PID does not exist."""
    pane = _mock_pane([[], []])
    entry = _dead_entry()
    wh, ph = _mock_hosts()

    result = _wait_for_events(
        pane=pane,
        entry=entry,
        wait={"events": ["exit"], "timeout": 2},
        watcher_host=wh,
        plugin_host=ph,
    )

    assert result["event"] == EVENT_EXIT
    assert result["ok"] is True


def test_exit_does_not_fire_for_live_pid():
    """exit event does not fire when the bound PID is alive."""
    pane = _mock_pane([[], []])
    entry = MagicMock(spec=_SessionEntry)
    entry.pid = os.getpid()
    entry.plugin_name = None
    wh, ph = _mock_hosts()

    result = _wait_for_events(
        pane=pane,
        entry=entry,
        wait={"events": ["exit"], "timeout": 0.4},
        watcher_host=wh,
        plugin_host=ph,
    )

    assert result["event"] == EVENT_TIMEOUT


# ---------------------------------------------------------------------------
# Integration tests -- real tmux required
# ---------------------------------------------------------------------------

@pytest.fixture(scope="module")
def tmux_srv(tmp_path_factory):
    """Isolated tmux server for integration tests."""
    sock = str(tmp_path_factory.mktemp("tmux") / "spad_test.sock")
    srv = libtmux.Server(socket_path=sock)
    yield srv
    try:
        srv.cmd("kill-server")
    except Exception:
        pass
    try:
        os.unlink(sock)
    except OSError:
        pass


@requires_tmux
def test_integration_capture_pane_returns_string(tmux_srv):
    """Integration smoke: _capture_pane returns a string from a real pane."""
    session = tmux_srv.new_session(session_name="spad-int-smoke", window_command="bash")
    try:
        window = session.active_window or session.windows[0]
        pane = window.active_pane or window.panes[0]
        content = _capture_pane(pane, lines=10)
        assert isinstance(content, str)
    finally:
        try:
            session.kill()
        except Exception:
            pass


@requires_tmux
def test_integration_kb2_line_field_real_pane(tmux_srv):
    """Integration KB-2: line field contains full line from a real pane."""
    session = tmux_srv.new_session(session_name="spad-int-kb2", window_command="bash")
    try:
        window = session.active_window or session.windows[0]
        pane = window.active_pane or window.panes[0]

        # Wait briefly for bash to start, then send a known line.
        time.sleep(0.3)
        pane.send_keys(
            "echo 'pre_text INT_KB2_MARKER post_text'",
            literal=True,
            enter=True,
        )
        time.sleep(0.5)

        content = _capture_pane(pane, lines=50)
        lines = content.splitlines()
        matched = [ln for ln in lines if "INT_KB2_MARKER" in ln]
        assert matched, f"Expected INT_KB2_MARKER in pane output:\n{content}"
        full_line = matched[0]
        assert "pre_text" in full_line
        assert "post_text" in full_line
        # The marker itself is a substring, not the whole line
        assert full_line != "INT_KB2_MARKER"
    finally:
        try:
            session.kill()
        except Exception:
            pass
