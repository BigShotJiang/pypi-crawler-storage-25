"""Tests for spad_mcp.core.files.

Covers file_read range slicing (all modes), file_write, file_edit,
file_grep, file_glob, file_insert. Uses tmp_path -- no mocks needed.
"""
import base64
import pytest
from spad_mcp.core.files import (
    file_read,
    file_write,
    file_edit,
    file_glob,
    file_grep,
    file_insert,
)


# ===========================================================================
# file_read -- helpers
# ===========================================================================

def _make_lines(tmp_path, n, prefix="line"):
    """Write n lines to a file, return path string."""
    p = tmp_path / "f.txt"
    p.write_text("\n".join(f"{prefix}{i}" for i in range(n)) + "\n", encoding="utf-8")
    return str(p)


# ===========================================================================
# file_read -- mode: lines
# ===========================================================================

class TestFileReadLines:
    def test_default_no_range_small_file(self, tmp_path):
        path = _make_lines(tmp_path, 10)
        r = file_read(path)
        assert r["units_read"] == 10
        assert r["eof"] is True
        assert "content" in r
        assert "content_b64" not in r

    def test_default_no_range_caps_at_200(self, tmp_path):
        path = _make_lines(tmp_path, 201)
        r = file_read(path)
        assert r["units_read"] == 200
        assert r["eof"] is False
        assert r["truncated"] is True

    def test_default_exactly_200_lines_eof_true(self, tmp_path):
        path = _make_lines(tmp_path, 200)
        r = file_read(path)
        assert r["units_read"] == 200
        assert r["eof"] is True

    def test_positive_range(self, tmp_path):
        path = _make_lines(tmp_path, 20)
        r = file_read(path, range=[5, 10])
        assert r["units_read"] == 5
        assert "line5" in r["content"]
        assert "line9" in r["content"]
        assert "line10" not in r["content"]  # half-open, stop excluded
        assert r["eof"] is False

    def test_range_start_none_first_n(self, tmp_path):
        path = _make_lines(tmp_path, 20)
        r = file_read(path, range=[None, 5])
        assert r["units_read"] == 5
        assert "line0" in r["content"]
        assert "line4" in r["content"]

    def test_range_stop_none_from_start(self, tmp_path):
        # [10, None] means from line 10 to end
        path = _make_lines(tmp_path, 20)
        r = file_read(path, range=[10, None])
        assert r["units_read"] == 10
        assert "line10" in r["content"]
        assert "line19" in r["content"]
        assert r["eof"] is True

    def test_negative_start_tail(self, tmp_path):
        path = _make_lines(tmp_path, 20)
        r = file_read(path, range=[-5, None])
        assert r["units_read"] == 5
        assert "line15" in r["content"]
        assert "line19" in r["content"]
        assert r["eof"] is True

    def test_negative_stop_all_but_last(self, tmp_path):
        # [None, -1] = all lines except last
        path = _make_lines(tmp_path, 5)
        r = file_read(path, range=[None, -1])
        assert r["units_read"] == 4
        assert "line4" not in r["content"]

    def test_out_of_range_stop_clamps(self, tmp_path):
        path = _make_lines(tmp_path, 5)
        r = file_read(path, range=[0, 9999])
        assert r["units_read"] == 5
        assert r["eof"] is True

    def test_out_of_range_start_clamps(self, tmp_path):
        path = _make_lines(tmp_path, 5)
        r = file_read(path, range=[-9999, None])
        assert r["units_read"] == 5
        assert r["eof"] is True

    def test_start_ge_stop_returns_empty(self, tmp_path):
        path = _make_lines(tmp_path, 10)
        r = file_read(path, range=[5, 5])
        assert r["units_read"] == 0
        assert r["content"] == ""

    def test_start_gt_stop_returns_empty(self, tmp_path):
        path = _make_lines(tmp_path, 10)
        r = file_read(path, range=[7, 3])
        assert r["units_read"] == 0
        assert r["content"] == ""

    def test_bytes_read_is_utf8_len(self, tmp_path):
        path = _make_lines(tmp_path, 3)
        r = file_read(path, range=[0, 3])
        assert r["bytes_read"] == len(r["content"].encode("utf-8"))

    def test_eof_true_when_range_reaches_end(self, tmp_path):
        path = _make_lines(tmp_path, 10)
        r = file_read(path, range=[8, 10])
        assert r["eof"] is True

    def test_eof_false_when_range_stops_before_end(self, tmp_path):
        path = _make_lines(tmp_path, 10)
        r = file_read(path, range=[0, 5])
        assert r["eof"] is False

    def test_null_null_range_still_capped(self, tmp_path):
        # Cap is universal -- explicit [null, null] no longer escapes it.
        path = _make_lines(tmp_path, 201)
        r = file_read(path, range=[None, None])
        assert r["units_read"] == 200
        assert r["truncated"] is True
        r2 = file_read(path, range=[0, None])
        assert r2["units_read"] == 200
        assert r2["truncated"] is True

    def test_file_not_found_raises(self, tmp_path):
        with pytest.raises(FileNotFoundError):
            file_read(str(tmp_path / "nope.txt"))

    def test_path_is_dir_raises(self, tmp_path):
        with pytest.raises(ValueError):
            file_read(str(tmp_path))

    def test_invalid_mode_raises(self, tmp_path):
        path = _make_lines(tmp_path, 1)
        with pytest.raises(ValueError, match="mode"):
            file_read(path, mode="invalid")

    def test_range_wrong_length_raises(self, tmp_path):
        path = _make_lines(tmp_path, 1)
        with pytest.raises(ValueError, match="range"):
            file_read(path, range=[0, 5, 10])

    def test_read_truncated_field_present(self, tmp_path):
        # truncated must be present in all mode responses.
        p_lines = _make_lines(tmp_path, 5)
        r_lines = file_read(p_lines)
        assert "truncated" in r_lines

        p_chars = tmp_path / "chars.txt"
        p_chars.write_text("hello")
        r_chars = file_read(str(p_chars), mode="chars")
        assert "truncated" in r_chars

        p_bytes = tmp_path / "b.bin"
        p_bytes.write_bytes(b"hello")
        r_bytes = file_read(str(p_bytes), mode="bytes")
        assert "truncated" in r_bytes


# ===========================================================================
# file_read -- mode: chars
# ===========================================================================

class TestFileReadChars:
    def test_chars_mode_returns_content_not_b64(self, tmp_path):
        p = tmp_path / "c.txt"
        p.write_text("abcdef", encoding="utf-8")
        r = file_read(str(p), mode="chars")
        assert "content" in r
        assert "content_b64" not in r

    def test_chars_range(self, tmp_path):
        p = tmp_path / "c.txt"
        p.write_text("abcdefghij", encoding="utf-8")
        r = file_read(str(p), mode="chars", range=[2, 5])
        assert r["content"] == "cde"
        assert r["units_read"] == 3

    def test_chars_negative_range_tail(self, tmp_path):
        p = tmp_path / "c.txt"
        p.write_text("abcdefghij", encoding="utf-8")
        r = file_read(str(p), mode="chars", range=[-3, None])
        assert r["content"] == "hij"
        assert r["eof"] is True

    def test_chars_default_cap_8k(self, tmp_path):
        # Cap is 8000 chars (whichever of char/byte cap fires first).
        p = tmp_path / "big.txt"
        p.write_text("x" * 8001, encoding="utf-8")
        r = file_read(str(p), mode="chars")
        assert r["units_read"] == 8000
        assert r["eof"] is False
        assert r["truncated"] is True

    def test_chars_units_read_matches_content_len(self, tmp_path):
        p = tmp_path / "c.txt"
        p.write_text("hello world", encoding="utf-8")
        r = file_read(str(p), mode="chars", range=[0, 5])
        assert r["units_read"] == len(r["content"])


# ===========================================================================
# file_read -- mode: bytes
# ===========================================================================

class TestFileReadBytes:
    def test_bytes_mode_returns_content_b64_not_content(self, tmp_path):
        p = tmp_path / "b.bin"
        p.write_bytes(b"hello")
        r = file_read(str(p), mode="bytes")
        assert "content_b64" in r
        assert "content" not in r
        assert "units_read" not in r

    def test_bytes_content_decodes_correctly(self, tmp_path):
        data = b"hello bytes world"
        p = tmp_path / "b.bin"
        p.write_bytes(data)
        r = file_read(str(p), mode="bytes", range=[0, len(data)])
        assert base64.b64decode(r["content_b64"]) == data

    def test_bytes_negative_range_tail(self, tmp_path):
        p = tmp_path / "b.bin"
        p.write_bytes(b"0123456789")
        r = file_read(str(p), mode="bytes", range=[-4, None])
        assert base64.b64decode(r["content_b64"]) == b"6789"
        assert r["eof"] is True

    def test_bytes_default_cap_8k(self, tmp_path):
        p = tmp_path / "b.bin"
        p.write_bytes(b"x" * 8193)
        r = file_read(str(p), mode="bytes")
        assert r["bytes_read"] == 8192
        assert r["eof"] is False
        assert r["truncated"] is True

    def test_bytes_eof_true_when_all_read(self, tmp_path):
        p = tmp_path / "b.bin"
        p.write_bytes(b"tiny")
        r = file_read(str(p), mode="bytes")
        assert r["eof"] is True

    def test_bytes_range_start_ge_stop_empty(self, tmp_path):
        p = tmp_path / "b.bin"
        p.write_bytes(b"hello")
        r = file_read(str(p), mode="bytes", range=[3, 3])
        assert r["bytes_read"] == 0
        assert base64.b64decode(r["content_b64"]) == b""

    def test_bytes_out_of_range_clamps(self, tmp_path):
        p = tmp_path / "b.bin"
        p.write_bytes(b"hello")
        r = file_read(str(p), mode="bytes", range=[0, 9999])
        assert r["bytes_read"] == 5
        assert r["eof"] is True


# ===========================================================================
# file_read -- errors param (text modes)
# ===========================================================================

class TestFileReadErrors:
    def _bad_utf8_file(self, tmp_path):
        p = tmp_path / "bad.txt"
        # \xff is invalid UTF-8
        p.write_bytes(b"hello \xff world\n")
        return str(p)

    def test_errors_replace_default(self, tmp_path):
        path = self._bad_utf8_file(tmp_path)
        r = file_read(path, mode="lines", errors="replace")
        # replacement char U+FFFD should appear
        assert "�" in r["content"]
        assert "hello" in r["content"]

    def test_errors_ignore_drops_bad_bytes(self, tmp_path):
        path = self._bad_utf8_file(tmp_path)
        r = file_read(path, mode="lines", errors="ignore")
        assert "�" not in r["content"]
        assert "hello" in r["content"]

    def test_errors_strict_raises(self, tmp_path):
        path = self._bad_utf8_file(tmp_path)
        with pytest.raises(UnicodeDecodeError):
            file_read(path, mode="lines", errors="strict")


# ===========================================================================
# file_write
# ===========================================================================

class TestFileWrite:
    def test_write_creates_file(self, tmp_path):
        path = str(tmp_path / "new.txt")
        r = file_write(path, "hello\n")
        assert r["ok"] is True
        assert r["bytes"] > 0
        assert (tmp_path / "new.txt").read_text() == "hello\n"

    def test_write_overwrites_existing(self, tmp_path):
        p = tmp_path / "f.txt"
        p.write_text("old content")
        file_write(str(p), "new content", overwrite=True)
        assert p.read_text() == "new content"

    def test_write_returns_byte_count(self, tmp_path):
        content = "hello world\n"
        path = str(tmp_path / "f.txt")
        r = file_write(path, content)
        assert r["bytes"] == len(content.encode("utf-8"))

    def test_write_creates_parent_dirs(self, tmp_path):
        path = str(tmp_path / "a" / "b" / "c.txt")
        r = file_write(path, "deep")
        assert r["ok"] is True
        import pathlib
        assert pathlib.Path(path).read_text() == "deep"

    def test_insert_end_appends_to_file(self, tmp_path):
        # Append via file_insert(position="end") -- replaces old append=True.
        p = tmp_path / "f.txt"
        p.write_text("first\n")
        r = file_insert(str(p), "second\n", "end")
        assert r["ok"] is True
        assert p.read_text() == "first\nsecond\n"

    def test_insert_end_returns_last_line(self, tmp_path):
        p = tmp_path / "f.txt"
        p.write_text("line1\nline2\n")
        r = file_insert(str(p), "line3\n", "end")
        assert r["ok"] is True
        assert r["line"] == 3

    def test_write_empty_string(self, tmp_path):
        path = str(tmp_path / "empty.txt")
        r = file_write(path, "")
        assert r["ok"] is True
        assert r["bytes"] == 0

    def test_write_refuses_existing_without_overwrite(self, tmp_path):
        p = tmp_path / "f.txt"
        p.write_text("existing")
        with pytest.raises(FileExistsError, match="file exists at"):
            file_write(str(p), "new content")

    def test_write_overwrite_true_replaces(self, tmp_path):
        p = tmp_path / "f.txt"
        p.write_text("old")
        r = file_write(str(p), "new", overwrite=True)
        assert r["ok"] is True
        assert p.read_text() == "new"


# ===========================================================================
# file_edit
# ===========================================================================

class TestFileEdit:
    def test_single_replacement(self, tmp_path):
        p = tmp_path / "f.txt"
        p.write_text("foo bar foo")
        # only first occurrence should fail when all=False and count > 1
        # Use a unique string:
        p.write_text("unique string here")
        r = file_edit(str(p), "unique string", "replaced value")
        assert r["replacements"] == 1
        assert p.read_text() == "replaced value here"

    def test_single_match_required_when_all_false(self, tmp_path):
        p = tmp_path / "f.txt"
        p.write_text("foo foo foo")
        with pytest.raises(ValueError, match="3 times"):
            file_edit(str(p), "foo", "bar", all=False)

    def test_zero_matches_raises(self, tmp_path):
        p = tmp_path / "f.txt"
        p.write_text("something else")
        with pytest.raises(ValueError, match="not found"):
            file_edit(str(p), "NOMATCH", "x")

    def test_all_true_replaces_all(self, tmp_path):
        p = tmp_path / "f.txt"
        p.write_text("x x x")
        r = file_edit(str(p), "x", "y", all=True)
        assert r["replacements"] == 3
        assert p.read_text() == "y y y"

    def test_all_true_zero_matches_raises(self, tmp_path):
        p = tmp_path / "f.txt"
        p.write_text("abc")
        with pytest.raises(ValueError, match="not found"):
            file_edit(str(p), "NOMATCH", "y", all=True)

    def test_returns_replacements_count(self, tmp_path):
        p = tmp_path / "f.txt"
        p.write_text("a a a b")
        r = file_edit(str(p), "a", "z", all=True)
        assert r["replacements"] == 3

    def test_file_not_found_raises(self, tmp_path):
        with pytest.raises(FileNotFoundError):
            file_edit(str(tmp_path / "nope.txt"), "x", "y")

    def test_replacement_writes_to_disk(self, tmp_path):
        p = tmp_path / "f.txt"
        p.write_text("before")
        file_edit(str(p), "before", "after")
        assert p.read_text() == "after"

    def test_edit_missing_file_message(self, tmp_path):
        path = str(tmp_path / "nope.txt")
        with pytest.raises(FileNotFoundError, match="file does not exist at"):
            file_edit(path, "x", "y")

    def test_edit_64k_sanity_cap(self, tmp_path):
        p = tmp_path / "f.txt"
        p.write_text("old")
        big = "x" * 65537
        with pytest.raises(ValueError, match="64KB sanity cap"):
            file_edit(str(p), "old", big)


# ===========================================================================
# file_grep
# ===========================================================================

class TestFileGrep:
    def test_finds_matching_lines(self, tmp_path):
        p = tmp_path / "f.txt"
        p.write_text("alpha\nbeta\ngamma\n")
        r = file_grep(str(tmp_path), "beta")
        assert len(r["matches"]) == 1
        assert r["matches"][0]["text"] == "beta"

    def test_line_numbers_are_1_indexed(self, tmp_path):
        p = tmp_path / "f.txt"
        p.write_text("line1\nline2\nline3\n")
        r = file_grep(str(tmp_path), "line3")
        assert r["matches"][0]["line"] == 3

    def test_match_includes_path(self, tmp_path):
        p = tmp_path / "f.txt"
        p.write_text("needle\n")
        r = file_grep(str(tmp_path), "needle")
        assert r["matches"][0]["path"] == str(p)

    def test_no_matches_returns_empty_list(self, tmp_path):
        p = tmp_path / "f.txt"
        p.write_text("nothing here\n")
        r = file_grep(str(tmp_path), "NOMATCH_SPAD")
        assert r["matches"] == []

    def test_regex_pattern(self, tmp_path):
        p = tmp_path / "f.txt"
        p.write_text("foo123\nbar456\nbaz\n")
        r = file_grep(str(tmp_path), r"\d+")
        assert len(r["matches"]) == 2

    def test_glob_filter(self, tmp_path):
        (tmp_path / "a.py").write_text("match_me\n")
        (tmp_path / "b.txt").write_text("match_me\n")
        r = file_grep(str(tmp_path), "match_me", glob="*.py")
        assert len(r["matches"]) == 1
        assert r["matches"][0]["path"].endswith(".py")

    def test_recursive_glob_filter(self, tmp_path):
        sub = tmp_path / "sub"
        sub.mkdir()
        (sub / "deep.py").write_text("deep_match\n")
        (tmp_path / "top.txt").write_text("deep_match\n")
        r = file_grep(str(tmp_path), "deep_match", glob="**/*.py")
        assert len(r["matches"]) == 1
        assert "deep.py" in r["matches"][0]["path"]

    def test_multiple_files_multiple_matches(self, tmp_path):
        (tmp_path / "a.txt").write_text("hit\nhit\n")
        (tmp_path / "b.txt").write_text("hit\n")
        r = file_grep(str(tmp_path), "hit")
        assert len(r["matches"]) == 3

    def test_root_not_dir_raises(self, tmp_path):
        p = tmp_path / "f.txt"
        p.write_text("x")
        with pytest.raises(ValueError, match="not a directory"):
            file_grep(str(p), "x")

    def test_grep_truncated_and_match_count(self, tmp_path):
        # Create many files with many matching lines to exceed 8KB.
        for i in range(50):
            lines = "\n".join(f"match_token line content padding {j}" for j in range(20))
            (tmp_path / f"f_{i}.txt").write_text(lines + "\n")
        r = file_grep(str(tmp_path), "match_token")
        assert r["match_count"] == 1000
        assert r["truncated"] is True
        assert len(r["matches"]) < 1000


# ===========================================================================
# file_glob
# ===========================================================================

class TestFileGlob:
    def test_simple_glob(self, tmp_path):
        (tmp_path / "a.py").write_text("")
        (tmp_path / "b.txt").write_text("")
        r = file_glob(str(tmp_path), "*.py")
        assert len(r["files"]) == 1
        assert r["files"][0].endswith("a.py")

    def test_returns_absolute_paths(self, tmp_path):
        (tmp_path / "f.py").write_text("")
        r = file_glob(str(tmp_path), "*.py")
        import os
        assert os.path.isabs(r["files"][0])

    def test_recursive_glob(self, tmp_path):
        sub = tmp_path / "pkg"
        sub.mkdir()
        (sub / "mod.py").write_text("")
        (tmp_path / "top.py").write_text("")
        r = file_glob(str(tmp_path), "**/*.py")
        assert len(r["files"]) == 2

    def test_no_matches_returns_empty_list(self, tmp_path):
        r = file_glob(str(tmp_path), "*.nonexistent")
        assert r["files"] == []

    def test_results_are_sorted(self, tmp_path):
        for name in ["c.py", "a.py", "b.py"]:
            (tmp_path / name).write_text("")
        r = file_glob(str(tmp_path), "*.py")
        names = [p.split("/")[-1] for p in r["files"]]
        assert names == sorted(names)

    def test_root_not_dir_raises(self, tmp_path):
        p = tmp_path / "f.txt"
        p.write_text("")
        with pytest.raises(ValueError, match="not a directory"):
            file_glob(str(p), "*")

    def test_glob_truncated_and_match_count(self, tmp_path):
        # Create enough files to exceed 8KB of serialized path text.
        for i in range(300):
            (tmp_path / f"file_{i:04d}.py").write_text("")
        r = file_glob(str(tmp_path), "*.py")
        assert r["match_count"] == 300
        assert r["truncated"] is True
        assert len(r["files"]) < 300


# ===========================================================================
# file_insert
# ===========================================================================

class TestFileInsert:
    def test_insert_after_anchor(self, tmp_path):
        p = tmp_path / "f.txt"
        p.write_text("line1\nanchor_line\nline3\n")
        r = file_insert(str(p), "inserted\n", "after", anchor="anchor_line")
        assert r["ok"] is True
        lines = p.read_text().splitlines()
        anchor_idx = lines.index("anchor_line")
        assert lines[anchor_idx + 1] == "inserted"

    def test_insert_before_anchor(self, tmp_path):
        p = tmp_path / "f.txt"
        p.write_text("line1\nanchor_line\nline3\n")
        r = file_insert(str(p), "inserted\n", "before", anchor="anchor_line")
        assert r["ok"] is True
        lines = p.read_text().splitlines()
        anchor_idx = lines.index("anchor_line")
        assert lines[anchor_idx - 1] == "inserted"

    def test_insert_adds_newline_if_missing(self, tmp_path):
        p = tmp_path / "f.txt"
        p.write_text("anchor\nend\n")
        file_insert(str(p), "no_newline", "after", anchor="anchor")
        content = p.read_text()
        assert "no_newline\n" in content

    def test_insert_returns_1indexed_line(self, tmp_path):
        p = tmp_path / "f.txt"
        # anchor is line 2 (0-indexed=1), after -> insert at index 2 -> line 3
        p.write_text("line0\nanchor\nline2\n")
        r = file_insert(str(p), "new\n", "after", anchor="anchor")
        # insert_idx = 2, returned line = 3
        assert r["line"] == 3

    def test_anchor_not_found_raises(self, tmp_path):
        p = tmp_path / "f.txt"
        p.write_text("nothing to match\n")
        with pytest.raises(ValueError, match="not found"):
            file_insert(str(p), "x\n", "after", anchor="NOANCHOR")

    def test_file_not_found_raises(self, tmp_path):
        with pytest.raises(FileNotFoundError):
            file_insert(str(tmp_path / "nope.txt"), "y\n", "after", anchor="x")

    def test_invalid_position_raises(self, tmp_path):
        p = tmp_path / "f.txt"
        p.write_text("anchor\n")
        with pytest.raises(ValueError, match="position"):
            file_insert(str(p), "x\n", "middle", anchor="anchor")

    def test_inserts_only_at_first_anchor(self, tmp_path):
        # anchor appears twice; only first match used
        p = tmp_path / "f.txt"
        p.write_text("anchor\nother\nanchor\n")
        file_insert(str(p), "inserted\n", "after", anchor="anchor")
        lines = p.read_text().splitlines()
        # "inserted" should appear right after the FIRST anchor (index 0)
        assert lines[0] == "anchor"
        assert lines[1] == "inserted"
        # second anchor should still be there, no extra insert
        assert lines.count("inserted") == 1

    def test_default_position_is_after(self, tmp_path):
        p = tmp_path / "f.txt"
        p.write_text("anchor\nend\n")
        file_insert(str(p), "here\n", anchor="anchor")
        lines = p.read_text().splitlines()
        assert lines[1] == "here"

    def test_insert_position_start(self, tmp_path):
        p = tmp_path / "f.txt"
        p.write_text("existing\n")
        r = file_insert(str(p), "prepended\n", "start")
        assert r["ok"] is True
        assert r["line"] == 1
        lines = p.read_text().splitlines()
        assert lines[0] == "prepended"
        assert lines[1] == "existing"

    def test_insert_position_end(self, tmp_path):
        p = tmp_path / "f.txt"
        p.write_text("first\nsecond\n")
        r = file_insert(str(p), "third\n", "end")
        assert r["ok"] is True
        lines = p.read_text().splitlines()
        assert lines[-1] == "third"
        assert r["line"] == len(lines)

    def test_insert_missing_file_message(self, tmp_path):
        path = str(tmp_path / "nope.txt")
        with pytest.raises(FileNotFoundError, match="file does not exist at"):
            file_insert(path, "x\n", "after", anchor="a")

    def test_insert_64k_sanity_cap(self, tmp_path):
        p = tmp_path / "f.txt"
        p.write_text("existing\n")
        big = "x" * 65537
        with pytest.raises(ValueError, match="64KB sanity cap"):
            file_insert(str(p), big, "end")
