"""Tests for spad_mcp.plugins.claude_code.ClaudeCodePlugin.

Uses tmp_path for filesystem isolation.  No tmux or libtmux required.
"""
from __future__ import annotations

import json
from os.path import expanduser
from pathlib import Path

import pytest

from spad_mcp.core.events import Event, EVENT_IDLE
from spad_mcp.plugins.claude_code import ClaudeCodePlugin


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_plugin(projects_dir: str | None = None) -> ClaudeCodePlugin:
    plugin = ClaudeCodePlugin()
    if projects_dir is not None:
        plugin.configure({"projects_dir": projects_dir})
    return plugin


def _write_jsonl(path: Path, stop_reason: str = "end_turn") -> None:
    """Write a single JSONL line that looks like a CC assistant turn."""
    line = json.dumps({"message": {"stop_reason": stop_reason}})
    path.write_text(line + "\n")


# ---------------------------------------------------------------------------
# configure()
# ---------------------------------------------------------------------------

def test_configure_default_projects_dir():
    """configure() with empty config keeps default ~/.claude/projects."""
    plugin = ClaudeCodePlugin()
    plugin.configure({})
    assert plugin.projects_dir == expanduser("~/.claude/projects")


def test_configure_stores_custom_projects_dir(tmp_path):
    """configure() stores the absolute custom projects_dir."""
    plugin = ClaudeCodePlugin()
    plugin.configure({"projects_dir": str(tmp_path)})
    assert plugin.projects_dir == str(tmp_path)


def test_configure_expands_tilde(tmp_path, monkeypatch):
    """configure() calls expanduser on the projects_dir value."""
    # Redirect HOME so we can verify tilde expansion without touching real ~
    monkeypatch.setenv("HOME", str(tmp_path))
    plugin = ClaudeCodePlugin()
    plugin.configure({"projects_dir": "~/custom_projects"})
    assert plugin.projects_dir == str(tmp_path / "custom_projects")


def test_constructor_default_bound_path():
    """bound_path is None before on_session_start is called."""
    plugin = ClaudeCodePlugin()
    assert plugin.bound_path is None


# ---------------------------------------------------------------------------
# pre_start() + on_session_start() -- non-blocking design
#
# Design: CC only creates its JSONL when the FIRST PROMPT is processed,
# not on startup. on_session_start() returns [] immediately. Lazy discovery
# happens via poll_for_jsonl() called from the wait loop after a prompt is
# sent. pre_start() must be called BEFORE new_session() to snapshot existing
# JSONL files so poll_for_jsonl() can identify the new one.
# ---------------------------------------------------------------------------

def test_on_session_start_returns_empty_list_immediately(tmp_path):
    """on_session_start() returns [] without blocking even if JSONL exists."""
    plugin = _make_plugin(projects_dir=str(tmp_path))
    plugin.pre_start()

    # Simulate JSONL appearing (as CC would write on first prompt)
    new_jsonl = tmp_path / "transcript.jsonl"
    _write_jsonl(new_jsonl)

    specs = plugin.on_session_start(session=None)
    assert specs == [], (
        "on_session_start must return [] immediately (non-blocking); "
        f"got {specs!r}"
    )


def test_on_session_start_bound_path_remains_none(tmp_path):
    """on_session_start() does not set bound_path -- discovery is lazy."""
    plugin = _make_plugin(projects_dir=str(tmp_path))
    plugin.pre_start()

    new_jsonl = tmp_path / "transcript.jsonl"
    _write_jsonl(new_jsonl)

    plugin.on_session_start(session=None)
    assert plugin.bound_path is None, (
        "bound_path should remain None after on_session_start; "
        f"got {plugin.bound_path!r}"
    )


def test_on_session_start_preserves_before_snapshot(tmp_path):
    """on_session_start() keeps _before_jsonl intact for poll_for_jsonl()."""
    plugin = _make_plugin(projects_dir=str(tmp_path))
    plugin.pre_start()
    before = plugin._before_jsonl

    plugin.on_session_start(session=None)

    assert plugin._before_jsonl is not None, (
        "_before_jsonl must not be reset to None -- poll_for_jsonl needs it"
    )
    assert plugin._before_jsonl == before, (
        "_before_jsonl should not change during on_session_start"
    )


def test_on_session_start_fallback_snapshot_when_no_pre_start(tmp_path):
    """on_session_start() takes a fallback snapshot when pre_start() not called."""
    plugin = _make_plugin(projects_dir=str(tmp_path))
    # Deliberately skip pre_start()

    plugin.on_session_start(session=None)

    assert plugin._before_jsonl is not None, (
        "fallback snapshot must be taken when pre_start was not called"
    )


def test_pre_start_ignores_preexisting_jsonl(tmp_path):
    """pre_start() snapshots existing files so poll_for_jsonl() ignores them."""
    old_jsonl = tmp_path / "old.jsonl"
    _write_jsonl(old_jsonl)

    plugin = _make_plugin(projects_dir=str(tmp_path))
    plugin.pre_start()  # snapshot includes old_jsonl
    plugin.on_session_start(session=None)

    new_jsonl = tmp_path / "new.jsonl"
    _write_jsonl(new_jsonl)

    result = plugin.poll_for_jsonl()
    assert result == str(new_jsonl), (
        f"Should find new.jsonl, not old.jsonl; got {result!r}"
    )
    assert plugin.bound_path == str(new_jsonl)


# ---------------------------------------------------------------------------
# poll_for_jsonl() -- lazy fallback discovery
# ---------------------------------------------------------------------------

def test_poll_for_jsonl_returns_none_when_no_new_file(tmp_path):
    """poll_for_jsonl() returns None when no new JSONL has appeared."""
    plugin = _make_plugin(projects_dir=str(tmp_path))
    plugin.pre_start()
    assert plugin.poll_for_jsonl() is None
    assert plugin.bound_path is None


def test_poll_for_jsonl_finds_new_file(tmp_path):
    """poll_for_jsonl() finds a new JSONL that appeared after pre_start."""
    plugin = _make_plugin(projects_dir=str(tmp_path))
    plugin.pre_start()
    new_jsonl = tmp_path / "late.jsonl"
    _write_jsonl(new_jsonl)
    result = plugin.poll_for_jsonl()
    assert result == str(new_jsonl)
    assert plugin.bound_path == str(new_jsonl)


# ---------------------------------------------------------------------------
# _parse_jsonl_line()
# ---------------------------------------------------------------------------

def test_parse_jsonl_line_end_turn_returns_idle():
    """Returns EVENT_IDLE ('idle') for a well-formed end_turn assistant line."""
    plugin = ClaudeCodePlugin()
    line = json.dumps({"message": {"stop_reason": "end_turn"}})
    result = plugin._parse_jsonl_line(line)
    assert result == EVENT_IDLE


def test_parse_jsonl_line_malformed_json_returns_none():
    """Returns None for malformed JSON -- no exception."""
    plugin = ClaudeCodePlugin()
    result = plugin._parse_jsonl_line("{not valid json")
    assert result is None


def test_parse_jsonl_line_empty_string_returns_none():
    """Returns None for an empty string."""
    plugin = ClaudeCodePlugin()
    result = plugin._parse_jsonl_line("")
    assert result is None


def test_parse_jsonl_line_non_end_turn_returns_none():
    """Returns None for a message with a different stop_reason."""
    plugin = ClaudeCodePlugin()
    line = json.dumps({"message": {"stop_reason": "max_tokens"}})
    result = plugin._parse_jsonl_line(line)
    assert result is None


def test_parse_jsonl_line_missing_stop_reason_returns_none():
    """Returns None when stop_reason key is absent."""
    plugin = ClaudeCodePlugin()
    line = json.dumps({"message": {"content": "hello"}})
    result = plugin._parse_jsonl_line(line)
    assert result is None


def test_parse_jsonl_line_missing_message_key_returns_none():
    """Returns None when the top-level message key is absent."""
    plugin = ClaudeCodePlugin()
    line = json.dumps({"type": "assistant"})
    result = plugin._parse_jsonl_line(line)
    assert result is None


def test_parse_jsonl_line_valid_but_unrelated_returns_none():
    """Returns None for a user-turn message (not an end_turn)."""
    plugin = ClaudeCodePlugin()
    line = json.dumps({"type": "user", "message": {"role": "user", "content": "hi"}})
    result = plugin._parse_jsonl_line(line)
    assert result is None


# ---------------------------------------------------------------------------
# enrich_event()
# ---------------------------------------------------------------------------

def _idle_event() -> Event:
    return Event(type=EVENT_IDLE, data={})


def test_enrich_event_reads_ctx_pct_from_file(tmp_path, monkeypatch):
    """enrich_event() populates ctx_pct from the spad_ctx_pct sidecar file."""
    ctx_file = tmp_path / "spad_ctx_pct"
    ctx_file.write_text("72\n")

    real_expanduser = expanduser

    def _patched_expanduser(path: str) -> str:
        if path == "~/.claude/spad_ctx_pct":
            return str(ctx_file)
        return real_expanduser(path)

    monkeypatch.setattr("spad_mcp.plugins.claude_code.expanduser", _patched_expanduser)

    plugin = ClaudeCodePlugin()
    plugin.bound_path = None  # skip cost/model tail read

    event = plugin.enrich_event(_idle_event())
    assert event.data.get("ctx_pct") == 72


def test_enrich_event_omits_ctx_pct_when_file_missing(tmp_path, monkeypatch):
    """enrich_event() omits ctx_pct key when the sidecar file does not exist."""
    ctx_file = tmp_path / "spad_ctx_pct_missing"  # deliberately absent

    real_expanduser = expanduser

    def _patched_expanduser(path: str) -> str:
        if path == "~/.claude/spad_ctx_pct":
            return str(ctx_file)
        return real_expanduser(path)

    monkeypatch.setattr("spad_mcp.plugins.claude_code.expanduser", _patched_expanduser)

    plugin = ClaudeCodePlugin()
    plugin.bound_path = None

    event = plugin.enrich_event(_idle_event())
    assert "ctx_pct" not in event.data


def test_enrich_event_omits_ctx_pct_when_file_not_integer(tmp_path, monkeypatch):
    """enrich_event() omits ctx_pct when the sidecar file contains non-integer."""
    ctx_file = tmp_path / "spad_ctx_pct"
    ctx_file.write_text("not_a_number\n")

    real_expanduser = expanduser

    def _patched_expanduser(path: str) -> str:
        if path == "~/.claude/spad_ctx_pct":
            return str(ctx_file)
        return real_expanduser(path)

    monkeypatch.setattr("spad_mcp.plugins.claude_code.expanduser", _patched_expanduser)

    plugin = ClaudeCodePlugin()
    plugin.bound_path = None

    event = plugin.enrich_event(_idle_event())
    assert "ctx_pct" not in event.data


def test_enrich_event_non_idle_not_modified():
    """enrich_event() returns non-idle events unchanged."""
    from spad_mcp.core.events import EVENT_EXIT
    plugin = ClaudeCodePlugin()
    event = Event(type=EVENT_EXIT, data={"pid": 123})
    result = plugin.enrich_event(event)
    assert result.type == EVENT_EXIT
    assert "ctx_pct" not in result.data


def test_enrich_event_reads_model_from_jsonl(tmp_path, monkeypatch):
    """enrich_event() populates model from transcript tail when bound_path is set."""
    # Write a minimal transcript with an assistant turn containing model info.
    transcript = tmp_path / "transcript.jsonl"
    line = json.dumps({
        "type": "assistant",
        "message": {"model": "claude-opus-4-5", "stop_reason": "end_turn"},
    })
    transcript.write_text(line + "\n")

    real_expanduser = expanduser

    def _patched_expanduser(path: str) -> str:
        if path == "~/.claude/spad_ctx_pct":
            return str(tmp_path / "no_ctx_file")  # absent -- skip ctx_pct
        return real_expanduser(path)

    monkeypatch.setattr("spad_mcp.plugins.claude_code.expanduser", _patched_expanduser)

    plugin = ClaudeCodePlugin()
    plugin.bound_path = str(transcript)

    event = plugin.enrich_event(_idle_event())
    assert event.data.get("model") == "claude-opus-4-5"


def test_enrich_event_reads_cost_usd_from_jsonl(tmp_path, monkeypatch):
    """enrich_event() populates cost_usd from transcript when the field is present."""
    transcript = tmp_path / "transcript.jsonl"
    line = json.dumps({
        "type": "assistant",
        "cost_usd": 0.0042,
        "message": {"stop_reason": "end_turn"},
    })
    transcript.write_text(line + "\n")

    real_expanduser = expanduser

    def _patched_expanduser(path: str) -> str:
        if path == "~/.claude/spad_ctx_pct":
            return str(tmp_path / "no_ctx_file")
        return real_expanduser(path)

    monkeypatch.setattr("spad_mcp.plugins.claude_code.expanduser", _patched_expanduser)

    plugin = ClaudeCodePlugin()
    plugin.bound_path = str(transcript)

    event = plugin.enrich_event(_idle_event())
    assert event.data.get("cost_usd") == pytest.approx(0.0042)
