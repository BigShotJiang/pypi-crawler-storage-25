"""Tests for spad_mcp.core.shell.run_shell.

Uses real subprocess calls -- no mocks needed.
"""
import os
import pytest
from spad_mcp.core.shell import run_shell


# ---------------------------------------------------------------------------
# Basic execution
# ---------------------------------------------------------------------------

def test_stdout_returned():
    result = run_shell(["echo", "hello"])
    assert result["stdout"].strip() == "hello"
    assert result["rc"] == 0
    assert result["stderr"] == ""


def test_multiword_stdout():
    result = run_shell(["echo", "foo", "bar"])
    assert "foo" in result["stdout"]
    assert "bar" in result["stdout"]


def test_empty_output():
    result = run_shell(["true"])
    assert result["stdout"] == ""
    assert result["stderr"] == ""
    assert result["rc"] == 0


# ---------------------------------------------------------------------------
# Exit code propagation
# ---------------------------------------------------------------------------

def test_rc_zero_on_success():
    result = run_shell(["true"])
    assert result["rc"] == 0


def test_rc_nonzero_on_failure():
    result = run_shell(["false"])
    assert result["rc"] != 0


def test_rc_specific_value():
    result = run_shell(["bash", "-c", "exit 42"])
    assert result["rc"] == 42


def test_rc_one_on_grep_nomatch():
    result = run_shell(["grep", "NOMATCH_SENTINEL", "/dev/null"])
    assert result["rc"] == 1


# ---------------------------------------------------------------------------
# Stderr capture
# ---------------------------------------------------------------------------

def test_stderr_captured():
    result = run_shell(["bash", "-c", "echo errline >&2"])
    assert "errline" in result["stderr"]
    assert result["rc"] == 0


def test_stdout_and_stderr_independent():
    result = run_shell(["bash", "-c", "echo OUT; echo ERR >&2"])
    assert "OUT" in result["stdout"]
    assert "ERR" in result["stderr"]
    # no cross-contamination
    assert "ERR" not in result["stdout"]
    assert "OUT" not in result["stderr"]


def test_stderr_empty_when_none():
    result = run_shell(["echo", "hi"])
    assert result["stderr"] == ""


# ---------------------------------------------------------------------------
# Timeout
# ---------------------------------------------------------------------------

def test_timeout_returns_rc124():
    result = run_shell(["sleep", "60"], timeout=1)
    assert result["rc"] == 124


def test_timeout_has_string_keys():
    # Verify shape even on timeout
    result = run_shell(["sleep", "60"], timeout=1)
    assert "stdout" in result
    assert "stderr" in result
    assert "rc" in result


def test_timeout_clamped_at_300():
    # Passing a huge timeout should still work (clamped to 300, but echo is fast)
    result = run_shell(["echo", "fast"], timeout=9999)
    assert result["rc"] == 0
    assert "fast" in result["stdout"]


# ---------------------------------------------------------------------------
# Environment variable layering
# ---------------------------------------------------------------------------

def test_env_overlay_adds_var():
    result = run_shell(
        ["bash", "-c", "echo $SPAD_TEST_SENTINEL"],
        env={"SPAD_TEST_SENTINEL": "found_it"},
    )
    assert "found_it" in result["stdout"]


def test_env_overlay_does_not_lose_path():
    # PATH must still be present so 'bash' can find other commands
    result = run_shell(
        ["bash", "-c", "echo $PATH"],
        env={"EXTRA_VAR": "extra"},
    )
    assert result["stdout"].strip() != ""
    assert result["rc"] == 0


def test_env_overlay_does_not_lose_home():
    result = run_shell(
        ["bash", "-c", "echo $HOME"],
        env={"SPAD_X": "1"},
    )
    assert result["stdout"].strip() != ""


def test_env_override_existing_var():
    # Override HOME with something recognizable
    result = run_shell(
        ["bash", "-c", "echo $HOME"],
        env={"HOME": "/tmp/spad_test_home"},
    )
    assert "/tmp/spad_test_home" in result["stdout"]


# ---------------------------------------------------------------------------
# Working directory
# ---------------------------------------------------------------------------

def test_cwd_sets_working_directory(tmp_path):
    result = run_shell(["pwd"], cwd=str(tmp_path))
    # resolve both to handle symlinks
    import pathlib
    assert pathlib.Path(result["stdout"].strip()).resolve() == tmp_path.resolve()


def test_cwd_default_uses_process_cwd():
    result = run_shell(["pwd"])
    assert result["rc"] == 0
    assert result["stdout"].strip() != ""


def test_cwd_affects_relative_paths(tmp_path):
    (tmp_path / "marker.txt").write_text("hi")
    result = run_shell(["ls", "marker.txt"], cwd=str(tmp_path))
    assert result["rc"] == 0
    assert "marker.txt" in result["stdout"]


# ---------------------------------------------------------------------------
# Missing executable
# ---------------------------------------------------------------------------

def test_missing_executable_raises():
    with pytest.raises(FileNotFoundError):
        run_shell(["__no_such_binary_spad_mcp_test__"])


# ---------------------------------------------------------------------------
# No-shell semantics
# ---------------------------------------------------------------------------

def test_no_shell_glob_not_expanded():
    # Without shell=True, * is passed literally
    result = run_shell(["echo", "*.py"])
    assert result["stdout"].strip() == "*.py"


def test_no_shell_pipe_not_interpreted():
    # | is a literal argument, not a pipe
    result = run_shell(["echo", "a", "|", "b"])
    assert "|" in result["stdout"]


def test_argv_as_list_not_string():
    # Passing a full command string as argv[0] should fail -- not interpreted by shell
    with pytest.raises((FileNotFoundError, PermissionError)):
        run_shell(["echo hello"])
