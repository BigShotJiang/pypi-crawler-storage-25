"""Tests for spad_mcp.server.

Tests build_server(), tool registration, plugin guard, and watcher thread.
Does NOT spin up an HTTP listener -- all testing is done via direct
introspection of the returned FastMCP object and other components.
"""
import asyncio
import os
import sys
import threading
import types
import pytest
from starlette.testclient import TestClient

import fastmcp
from spad_mcp.server import (
    _load_config,
    _start_watcher_thread,
    build_server,
)
from spad_mcp.core.watcher import WatcherHost
from spad_mcp.core.plugins import PluginHost


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _tool_names(mcp):
    """Return set of registered tool names from a FastMCP instance."""
    tools = asyncio.run(mcp.list_tools())
    return {t.name for t in tools}


EXPECTED_CORE_TOOLS = {
    "shell",
    "file_read",
    "file_write",
    "file_edit",
    "file_grep",
    "file_glob",
    "file_insert",
    "status",
}


# ---------------------------------------------------------------------------
# build_server() return types
# ---------------------------------------------------------------------------

def test_build_server_returns_fastmcp_instance():
    mcp, watcher, plugin_host = build_server({})
    assert isinstance(mcp, fastmcp.FastMCP)
    watcher.close()


def test_build_server_returns_watcher_host():
    mcp, watcher, plugin_host = build_server({})
    assert isinstance(watcher, WatcherHost)
    watcher.close()


def test_build_server_returns_plugin_host():
    mcp, watcher, plugin_host = build_server({})
    assert isinstance(plugin_host, PluginHost)
    watcher.close()


def test_build_server_returns_3_tuple():
    result = build_server({})
    assert len(result) == 3
    result[1].close()


# ---------------------------------------------------------------------------
# Core tool registration
# ---------------------------------------------------------------------------

def test_all_core_tools_registered():
    mcp, watcher, _ = build_server({})
    try:
        names = _tool_names(mcp)
        missing = EXPECTED_CORE_TOOLS - names
        assert missing == set(), f"Missing tools: {missing}"
    finally:
        watcher.close()


def test_shell_tool_registered():
    mcp, watcher, _ = build_server({})
    try:
        assert "shell" in _tool_names(mcp)
    finally:
        watcher.close()


def test_file_read_tool_registered():
    mcp, watcher, _ = build_server({})
    try:
        assert "file_read" in _tool_names(mcp)
    finally:
        watcher.close()


def test_status_tool_registered():
    mcp, watcher, _ = build_server({})
    try:
        assert "status" in _tool_names(mcp)
    finally:
        watcher.close()


# ---------------------------------------------------------------------------
# CC plugin guard -- server starts even if plugin module is missing/broken
# ---------------------------------------------------------------------------

def test_server_starts_without_cc_plugin(tmp_path, monkeypatch):
    """Server must start cleanly even when the CC plugin cannot be imported."""
    # Simulate missing CC plugin by patching the import to fail
    real_import = __builtins__.__import__ if hasattr(__builtins__, '__import__') else __import__

    import builtins
    real_import = builtins.__import__

    def mock_import(name, *args, **kwargs):
        if name == "spad_mcp.plugins.claude_code":
            raise ImportError("simulated missing plugin")
        return real_import(name, *args, **kwargs)

    monkeypatch.setattr(builtins, "__import__", mock_import)
    # Should not raise
    mcp, watcher, plugin_host = build_server({})
    try:
        assert isinstance(mcp, fastmcp.FastMCP)
    finally:
        watcher.close()


def test_server_starts_with_cc_plugin_disabled():
    config = {"plugins": {"claude-code": {"enabled": False}}}
    mcp, watcher, plugin_host = build_server(config)
    try:
        assert isinstance(mcp, fastmcp.FastMCP)
        # CC plugin should not be registered
        plugin_names = [p.name for p in plugin_host]
        assert "claude-code" not in plugin_names
    finally:
        watcher.close()


# ---------------------------------------------------------------------------
# Tmux tools: conditional registration
# ---------------------------------------------------------------------------

def test_tmux_tools_registered_only_when_adapter_available():
    """If libtmux is available, tmux_ tools should appear.
    If not, no tmux_ tools -- but server still starts fine.
    """
    mcp, watcher, _ = build_server({})
    try:
        names = _tool_names(mcp)
        try:
            import libtmux  # noqa: F401
            tmux_tools = {n for n in names if n.startswith("tmux_")}
            assert len(tmux_tools) > 0, "libtmux available but no tmux_ tools registered"
        except ImportError:
            # libtmux not installed -- no tmux tools expected
            tmux_tools = {n for n in names if n.startswith("tmux_")}
            assert tmux_tools == set(), f"Unexpected tmux tools without libtmux: {tmux_tools}"
    finally:
        watcher.close()


def test_core_tools_present_regardless_of_tmux(monkeypatch):
    """Core tools must be present whether tmux adapter loads or not."""
    # Simulate libtmux unavailable
    monkeypatch.setitem(sys.modules, "libtmux", None)
    monkeypatch.setitem(sys.modules, "spad_mcp.adapters.tmux", None)
    mcp, watcher, _ = build_server({})
    try:
        names = _tool_names(mcp)
        for tool in EXPECTED_CORE_TOOLS:
            assert tool in names, f"Core tool missing: {tool}"
    finally:
        watcher.close()


# ---------------------------------------------------------------------------
# status tool behavior
# ---------------------------------------------------------------------------

def _call_status(mcp):
    """Call the status tool and return structured_content dict."""
    result = asyncio.run(mcp.call_tool("status", {}))
    # FastMCP returns a ToolResult; structured_content holds the raw dict
    return result.structured_content


def test_status_tool_returns_ok_true():
    mcp, watcher, _ = build_server({})
    try:
        data = _call_status(mcp)
        assert data["ok"] is True
    finally:
        watcher.close()


def test_status_tool_returns_version():
    mcp, watcher, _ = build_server({})
    try:
        data = _call_status(mcp)
        assert data["version"] == "0.1.0"
    finally:
        watcher.close()


def test_status_tool_returns_plugins_key():
    mcp, watcher, _ = build_server({})
    try:
        data = _call_status(mcp)
        assert "plugins" in data
        assert isinstance(data["plugins"], list)
    finally:
        watcher.close()


def test_status_tool_returns_bound_paths_key():
    mcp, watcher, _ = build_server({})
    try:
        data = _call_status(mcp)
        assert "bound_paths" in data
        assert isinstance(data["bound_paths"], dict)
    finally:
        watcher.close()


# ---------------------------------------------------------------------------
# _load_config
# ---------------------------------------------------------------------------

def test_load_config_loads_toml(tmp_path):
    cfg = tmp_path / "conf.toml"
    cfg.write_bytes(b"[server]\nport = 9999\n")
    result = _load_config(str(cfg))
    assert result["server"]["port"] == 9999


def test_load_config_empty_toml_returns_dict(tmp_path):
    cfg = tmp_path / "empty.toml"
    cfg.write_bytes(b"")
    result = _load_config(str(cfg))
    assert isinstance(result, dict)
    assert result == {}


def test_load_config_default_when_none():
    # None path should load the built-in default.toml without error
    result = _load_config(None)
    assert isinstance(result, dict)


# ---------------------------------------------------------------------------
# _start_watcher_thread lifecycle
# ---------------------------------------------------------------------------

def test_watcher_thread_starts():
    watcher = WatcherHost()
    try:
        t = _start_watcher_thread(watcher)
        assert t.is_alive()
        t.stop_event.set()
        t.join(timeout=2)
    finally:
        watcher.close()


def test_watcher_thread_stops_on_event():
    watcher = WatcherHost()
    try:
        t = _start_watcher_thread(watcher)
        t.stop_event.set()
        t.join(timeout=2)
        assert not t.is_alive()
    finally:
        watcher.close()


def test_watcher_thread_is_daemon():
    watcher = WatcherHost()
    try:
        t = _start_watcher_thread(watcher)
        assert t.daemon is True
        t.stop_event.set()
        t.join(timeout=2)
    finally:
        watcher.close()


def test_watcher_thread_name():
    watcher = WatcherHost()
    try:
        t = _start_watcher_thread(watcher)
        assert "spad" in t.name.lower()
        t.stop_event.set()
        t.join(timeout=2)
    finally:
        watcher.close()


# ---------------------------------------------------------------------------
# Build with non-empty config
# ---------------------------------------------------------------------------

def test_build_server_with_server_config():
    config = {"server": {"host": "127.0.0.1", "port": 9831}}
    mcp, watcher, _ = build_server(config)
    try:
        assert isinstance(mcp, fastmcp.FastMCP)
    finally:
        watcher.close()


def test_build_server_idempotent_calls():
    # Two separate calls should each return fresh instances
    mcp1, w1, _ = build_server({})
    mcp2, w2, _ = build_server({})
    try:
        assert mcp1 is not mcp2
        assert w1 is not w2
    finally:
        w1.close()
        w2.close()


# ===========================================================================
# OOB /spad/upload + /spad/download endpoints
# ===========================================================================

@pytest.fixture()
def oob_client():
    mcp, watcher, _ = build_server({})
    app = mcp.http_app()
    with TestClient(app, raise_server_exceptions=True) as client:
        yield client
    watcher.close()


class TestOOBUpload:
    def test_small_blob_round_trip(self, oob_client, tmp_path):
        blob = b"hello oob world"
        dest = str(tmp_path / "blob.bin")
        r = oob_client.post(f"/spad/upload?path={dest}", content=blob)
        assert r.status_code == 200
        assert r.json()["ok"] is True
        assert r.json()["bytes"] == len(blob)
        dl = oob_client.get(f"/spad/download?path={dest}")
        assert dl.status_code == 200
        assert dl.content == blob

    def test_10mb_streaming_round_trip(self, oob_client, tmp_path):
        blob = os.urandom(10 * 1024 * 1024)
        dest = str(tmp_path / "big.bin")
        r = oob_client.post(f"/spad/upload?path={dest}", content=blob)
        assert r.status_code == 200
        assert r.json()["bytes"] == len(blob)
        dl = oob_client.get(f"/spad/download?path={dest}")
        assert dl.status_code == 200
        assert dl.content == blob

    def test_upload_409_on_existing_without_overwrite(self, oob_client, tmp_path):
        p = tmp_path / "existing.txt"
        p.write_bytes(b"original")
        r = oob_client.post(f"/spad/upload?path={p}", content=b"new")
        assert r.status_code == 409
        assert "file exists" in r.json()["error"]
        assert p.read_bytes() == b"original"

    def test_upload_overwrite_true_replaces(self, oob_client, tmp_path):
        p = tmp_path / "existing.txt"
        p.write_bytes(b"original")
        r = oob_client.post(f"/spad/upload?path={p}&overwrite=true", content=b"replaced")
        assert r.status_code == 200
        assert p.read_bytes() == b"replaced"

    def test_upload_400_on_missing_path(self, oob_client):
        r = oob_client.post("/spad/upload", content=b"data")
        assert r.status_code == 400

    def test_upload_400_on_relative_path(self, oob_client):
        r = oob_client.post("/spad/upload?path=relative/path.txt", content=b"data")
        assert r.status_code == 400

    def test_upload_creates_parent_dirs(self, oob_client, tmp_path):
        dest = str(tmp_path / "a" / "b" / "c.bin")
        r = oob_client.post(f"/spad/upload?path={dest}", content=b"deep")
        assert r.status_code == 200
        from pathlib import Path
        assert Path(dest).read_bytes() == b"deep"


class TestOOBDownload:
    def test_download_404_on_missing(self, oob_client, tmp_path):
        path = str(tmp_path / "nope.bin")
        r = oob_client.get(f"/spad/download?path={path}")
        assert r.status_code == 404
        assert "no such file" in r.json()["error"]

    def test_download_400_on_missing_path_param(self, oob_client):
        r = oob_client.get("/spad/download")
        assert r.status_code == 400

    def test_download_400_on_relative_path(self, oob_client):
        r = oob_client.get("/spad/download?path=relative/path.txt")
        assert r.status_code == 400

    def test_download_content_type_header(self, oob_client, tmp_path):
        p = tmp_path / "f.bin"
        p.write_bytes(b"data")
        r = oob_client.get(f"/spad/download?path={p}")
        assert r.status_code == 200
        assert "octet-stream" in r.headers["content-type"]

    def test_download_content_length_header(self, oob_client, tmp_path):
        data = b"x" * 1024
        p = tmp_path / "f.bin"
        p.write_bytes(data)
        r = oob_client.get(f"/spad/download?path={p}")
        assert r.status_code == 200
        assert int(r.headers["content-length"]) == len(data)
