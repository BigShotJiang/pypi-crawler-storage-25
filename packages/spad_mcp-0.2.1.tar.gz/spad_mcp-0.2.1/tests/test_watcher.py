"""Tests for spad_mcp.core.watcher.WatcherHost.

Uses real inotify -- no mocks. All file I/O is within tmp_path.
poll() is called directly (synchronous) with short timeouts.
"""
import os
import time
import pytest
from spad_mcp.core.watcher import WatcherHost, FileWatcher
from spad_mcp.core.events import Event

POLL_MS = 300  # ms to wait for inotify events


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _write_append(path, text):
    """Append text to path, flush, fsync."""
    with open(path, "a") as fh:
        fh.write(text)
        fh.flush()
        os.fsync(fh.fileno())


def _make_empty(tmp_path, name="test.txt"):
    p = tmp_path / name
    p.write_text("")
    return str(p)


# ---------------------------------------------------------------------------
# add() / basic registration
# ---------------------------------------------------------------------------

def test_add_returns_watch_id(tmp_path):
    watcher = WatcherHost()
    try:
        path = _make_empty(tmp_path)
        spec = FileWatcher(path=path, event="file_change")
        wid = watcher.add(spec, lambda e: None)
        assert isinstance(wid, int)
        assert wid >= 1
    finally:
        watcher.close()


def test_add_increments_watch_id(tmp_path):
    watcher = WatcherHost()
    try:
        p1 = _make_empty(tmp_path, "a.txt")
        p2 = _make_empty(tmp_path, "b.txt")
        w1 = watcher.add(FileWatcher(path=p1, event="file_change"), lambda e: None)
        w2 = watcher.add(FileWatcher(path=p2, event="file_change"), lambda e: None)
        assert w2 > w1
    finally:
        watcher.close()


# ---------------------------------------------------------------------------
# poll() detects file appends (no parser)
# ---------------------------------------------------------------------------

def test_poll_detects_append(tmp_path):
    watcher = WatcherHost()
    events = []
    try:
        path = _make_empty(tmp_path)
        watcher.add(FileWatcher(path=path, event="file_change"), events.append)

        _write_append(path, "hello\n")
        watcher.poll(POLL_MS)

        assert len(events) == 1
        assert events[0].type == "file_change"
        assert events[0].data["path"] == path
    finally:
        watcher.close()


def test_poll_dispatches_event_instance(tmp_path):
    watcher = WatcherHost()
    events = []
    try:
        path = _make_empty(tmp_path)
        watcher.add(FileWatcher(path=path, event="file_change"), events.append)
        _write_append(path, "data\n")
        watcher.poll(POLL_MS)
        assert isinstance(events[0], Event)
    finally:
        watcher.close()


def test_no_event_on_no_change(tmp_path):
    watcher = WatcherHost()
    events = []
    try:
        path = _make_empty(tmp_path)
        watcher.add(FileWatcher(path=path, event="file_change"), events.append)
        watcher.poll(POLL_MS)
        assert events == []
    finally:
        watcher.close()


# ---------------------------------------------------------------------------
# Parser: returns string -> fires event with that type
# ---------------------------------------------------------------------------

def test_parser_string_fires_named_event(tmp_path):
    watcher = WatcherHost()
    events = []
    try:
        path = _make_empty(tmp_path)

        def parser(line):
            if "DONE" in line:
                return "idle"
            return None

        watcher.add(FileWatcher(path=path, event="file_change", parser=parser), events.append)

        _write_append(path, "DONE\n")
        watcher.poll(POLL_MS)

        assert len(events) == 1
        assert events[0].type == "idle"
        assert events[0].data["line"] == "DONE"
    finally:
        watcher.close()


def test_parser_event_data_contains_path_and_line(tmp_path):
    watcher = WatcherHost()
    events = []
    try:
        path = _make_empty(tmp_path)
        watcher.add(
            FileWatcher(path=path, event="x", parser=lambda line: "x"),
            events.append,
        )
        _write_append(path, "content\n")
        watcher.poll(POLL_MS)
        assert events[0].data["path"] == path
        assert events[0].data["line"] == "content"
    finally:
        watcher.close()


def test_parser_fires_per_line(tmp_path):
    watcher = WatcherHost()
    events = []
    try:
        path = _make_empty(tmp_path)
        watcher.add(
            FileWatcher(path=path, event="got", parser=lambda line: "got"),
            events.append,
        )
        _write_append(path, "line1\nline2\nline3\n")
        watcher.poll(POLL_MS)
        assert len(events) == 3
    finally:
        watcher.close()


# ---------------------------------------------------------------------------
# Parser: returns None -> suppresses event
# ---------------------------------------------------------------------------

def test_parser_none_suppresses_event(tmp_path):
    watcher = WatcherHost()
    events = []
    try:
        path = _make_empty(tmp_path)
        watcher.add(
            FileWatcher(path=path, event="file_change", parser=lambda line: None),
            events.append,
        )
        _write_append(path, "anything\n")
        watcher.poll(POLL_MS)
        assert events == []
    finally:
        watcher.close()


def test_parser_selective_firing(tmp_path):
    watcher = WatcherHost()
    events = []
    try:
        path = _make_empty(tmp_path)

        def parser(line):
            return "hit" if line.startswith("HIT") else None

        watcher.add(FileWatcher(path=path, event="x", parser=parser), events.append)
        _write_append(path, "skip\nHIT this\nskip again\n")
        watcher.poll(POLL_MS)
        assert len(events) == 1
        assert events[0].data["line"] == "HIT this"
    finally:
        watcher.close()


# ---------------------------------------------------------------------------
# Parser exceptions don't kill the loop
# ---------------------------------------------------------------------------

def test_parser_exception_does_not_stop_loop(tmp_path):
    watcher = WatcherHost()
    events = []
    call_count = [0]

    def parser(line):
        call_count[0] += 1
        if call_count[0] == 1:
            raise RuntimeError("boom on first line")
        return "ok"

    try:
        path = _make_empty(tmp_path)
        watcher.add(FileWatcher(path=path, event="ok", parser=parser), events.append)

        _write_append(path, "first\nsecond\n")
        watcher.poll(POLL_MS)

        # first line raised, second line should still fire
        assert call_count[0] == 2
        assert len(events) == 1
        assert events[0].type == "ok"
    finally:
        watcher.close()


def test_dispatch_exception_does_not_stop_loop(tmp_path):
    watcher = WatcherHost()
    call_count = [0]

    def bad_dispatch(event):
        call_count[0] += 1
        raise RuntimeError("dispatch error")

    try:
        path = _make_empty(tmp_path)
        # No parser -- dispatches on MODIFY
        watcher.add(FileWatcher(path=path, event="file_change"), bad_dispatch)

        _write_append(path, "data\n")
        # Should not raise despite dispatch error
        watcher.poll(POLL_MS)

        assert call_count[0] >= 1
    finally:
        watcher.close()


# ---------------------------------------------------------------------------
# File truncation resets pos
# ---------------------------------------------------------------------------

def test_truncation_resets_and_redispatches(tmp_path):
    watcher = WatcherHost()
    events = []
    try:
        p = tmp_path / "log.txt"
        p.write_text("initial content\n")
        path = str(p)
        watcher.add(FileWatcher(path=path, event="file_change"), events.append)

        # Overwrite (truncate + write) with new content
        p.write_text("fresh\n")
        watcher.poll(POLL_MS)

        # Should dispatch for the new content (pos reset after truncation)
        assert len(events) >= 1
    finally:
        watcher.close()


def test_truncation_resets_partial_buf(tmp_path):
    """Truncation detected when new size < old pos (content shrinks).

    Implementation heuristic: size < entry.pos => truncation.
    Use a shorter replacement to reliably trigger this path.
    "partial" is 7 bytes (pos=7); replacement "ok\n" is 3 bytes (< 7).
    """
    watcher = WatcherHost()
    dispatched = []

    def parser(line):
        dispatched.append(line)
        return "got"

    try:
        p = tmp_path / "log.txt"
        p.write_text("")
        path = str(p)
        watcher.add(FileWatcher(path=path, event="got", parser=parser), lambda e: None)

        # Write a partial line (no newline) -- "partial" is 7 bytes, pos -> 7
        _write_append(path, "partial")
        watcher.poll(POLL_MS)
        assert dispatched == []  # no complete line yet, buf holds "partial"

        # Truncate to shorter content: 3 bytes < old pos (7) => truncation detected
        # pos and buf reset, then reads from 0 -> dispatches "ok"
        p.write_bytes(b"ok\n")
        watcher.poll(POLL_MS)
        assert "ok" in dispatched
    finally:
        watcher.close()


# ---------------------------------------------------------------------------
# File does not exist yet at add() time
# ---------------------------------------------------------------------------

def test_watch_file_created_after_add(tmp_path):
    watcher = WatcherHost()
    events = []
    try:
        path = str(tmp_path / "future.txt")
        # File does not exist
        wid = watcher.add(FileWatcher(path=path, event="file_change"), events.append)

        # Should be in pending (no inotify watch yet)
        assert wid in watcher._pending

        # Create the file
        with open(path, "w") as fh:
            fh.write("")
            fh.flush()

        # First poll re-attaches inotify, seeds pos to current size (0)
        watcher.poll(POLL_MS)

        # Now append -- should be detected on next poll
        _write_append(path, "new data\n")
        watcher.poll(POLL_MS)

        assert len(events) >= 1
        assert events[0].type == "file_change"
    finally:
        watcher.close()


def test_pending_watch_not_dispatched_before_attach(tmp_path):
    watcher = WatcherHost()
    events = []
    try:
        path = str(tmp_path / "missing.txt")
        watcher.add(FileWatcher(path=path, event="file_change"), events.append)
        # Poll before file exists -- should not error, no events
        watcher.poll(50)
        assert events == []
    finally:
        watcher.close()


# ---------------------------------------------------------------------------
# Partial-line accumulator
# ---------------------------------------------------------------------------

def test_partial_line_accumulator(tmp_path):
    watcher = WatcherHost()
    events = []
    parsed_lines = []

    def parser(line):
        parsed_lines.append(line)
        return "got_line"

    try:
        path = _make_empty(tmp_path, "stream.log")
        watcher.add(FileWatcher(path=path, event="got_line", parser=parser), events.append)

        # Write partial line (no trailing newline)
        _write_append(path, "abc")
        watcher.poll(POLL_MS)
        # No complete line yet -- no dispatch
        assert events == []
        assert parsed_lines == []

        # Complete the line
        _write_append(path, "def\n")
        watcher.poll(POLL_MS)

        assert len(events) == 1
        assert parsed_lines == ["abcdef"]
    finally:
        watcher.close()


def test_partial_line_multiple_completions(tmp_path):
    watcher = WatcherHost()
    parsed = []

    def parser(line):
        parsed.append(line)
        return "got"

    try:
        path = _make_empty(tmp_path, "s.log")
        watcher.add(FileWatcher(path=path, event="got", parser=parser), lambda e: None)

        _write_append(path, "lin")
        watcher.poll(POLL_MS)
        _write_append(path, "e1\nlin")
        watcher.poll(POLL_MS)
        _write_append(path, "e2\n")
        watcher.poll(POLL_MS)

        assert "line1" in parsed
        assert "line2" in parsed
    finally:
        watcher.close()


# ---------------------------------------------------------------------------
# remove() cleanup
# ---------------------------------------------------------------------------

def test_remove_stops_dispatch(tmp_path):
    watcher = WatcherHost()
    events = []
    try:
        path = _make_empty(tmp_path)
        wid = watcher.add(FileWatcher(path=path, event="file_change"), events.append)

        watcher.remove(wid)

        _write_append(path, "should be ignored\n")
        watcher.poll(POLL_MS)

        assert events == []
    finally:
        watcher.close()


def test_remove_nonexistent_is_noop(tmp_path):
    watcher = WatcherHost()
    try:
        # Should not raise
        watcher.remove(9999)
    finally:
        watcher.close()


def test_remove_clears_pending(tmp_path):
    watcher = WatcherHost()
    try:
        path = str(tmp_path / "nope.txt")
        wid = watcher.add(FileWatcher(path=path, event="x"), lambda e: None)
        assert wid in watcher._pending
        watcher.remove(wid)
        assert wid not in watcher._pending
    finally:
        watcher.close()


# ---------------------------------------------------------------------------
# Multiple watchers on different files
# ---------------------------------------------------------------------------

def test_multiple_watchers_independent(tmp_path):
    watcher = WatcherHost()
    events_a, events_b = [], []
    try:
        pa = _make_empty(tmp_path, "a.txt")
        pb = _make_empty(tmp_path, "b.txt")
        watcher.add(FileWatcher(path=pa, event="ev_a"), events_a.append)
        watcher.add(FileWatcher(path=pb, event="ev_b"), events_b.append)

        _write_append(pa, "data_a\n")
        watcher.poll(POLL_MS)

        assert len(events_a) == 1
        assert events_b == []

        _write_append(pb, "data_b\n")
        watcher.poll(POLL_MS)

        assert len(events_b) == 1
    finally:
        watcher.close()


# ---------------------------------------------------------------------------
# close() is safe to call
# ---------------------------------------------------------------------------

def test_close_is_safe(tmp_path):
    watcher = WatcherHost()
    path = _make_empty(tmp_path)
    watcher.add(FileWatcher(path=path, event="x"), lambda e: None)
    watcher.close()  # should not raise
    # Entries cleared
    assert watcher._entries == {}
