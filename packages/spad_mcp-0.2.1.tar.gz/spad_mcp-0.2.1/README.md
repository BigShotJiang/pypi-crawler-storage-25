# spad-mcp 👻🏗

[![License: MIT](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)
[![Python 3.12+](https://img.shields.io/badge/python-3.12%2B-blue.svg)](https://www.python.org)

SPAD: SPooky Action at a Distance.

Drive remote terminals and applications from agents, scripts, or your own code -- without shell escaping.

Utility:
- First use case: End-to-end, _agent-driven_ remote control for Claude Code extension development, debugging and testing.
- More efficient tools for agents, even locally (0 is a valid distance) - more on that below.
- Not just for claude; MCP: Any agent can use.
- Reference CLI included.
- Extensible remote functionality via plugin system.

... and more.

## Install

```bash
pip install spad-mcp          # core: file ops, shell, watcher, plugins
pip install spad-mcp[tmux]    # + tmux adapter (recommended for CC testing)
```

Run it:

```bash
spad-server                   # binds 127.0.0.1:9830 by default
```

Connect any MCP client at `http://localhost:9830/mcp`, or use the included `spad` CLI. See [QUICKSTART.md](QUICKSTART.md) for the 60-second tour.

## The problem

We needed to give developer agents "controllers" full unattended end-to-end development capabilites for remote Claude Code instance(s) "targets" in order to develop, test, and debug extensions for it. A week before this repo's publishing, prior art search found no existing libraries offering this complete lifecycle. Various adjacent libs existed, but none were found offering this level of control _outside_ of Claude Code. 

Along the way, we realized we could solve some common problems agents run into:
- **Shell Escape Hell**. Commands run through the Bash tool, the agent's primary execution mechanism, often require the agent to take multiple passes before it gets it right -- easily the #1 source of silent failures and token wastage in agent tooling.
- **Remote File Edits**. Without mounts, file edits require reading an entire file into context just to change one line, or writing complex regex-based wall-of-text command lines.
- **Event Monitoring**. Have any files we're interested in changed? Processes exited? Has text we're waiting for appeared in the output? Pre-spad, this was complicated and fragile, often causing the agent to wait for the full timeout duration before it "saw" an event.

Specific to Claude Code:
- **Native JSONL Streaming Support**. Event-based JSONL parsing and streaming. Triggers events for agent stop, parses responses, tool call outputs, thinking, etc. Avoids stop hooks -- when developing extensions for Claude Code, it's important to leave Claude Code as unencumbered as possible in order to avoid interaction side-effects.

These problems exist locally too: Even on the same machine, agents deal with quoting hell every time they touch the Bash tool.

## What spad does

spad-mcp is an MCP server that runs alongside the program you're
controlling -- locally or remotely. Agents (or humans, or scripts)
connect and call structured tools. No shell in the loop.

### Core tools (no tmux required)

- **`shell`** -- execute commands via argv array. No shell interpretation,
  no escaping.
- **`file_read`** -- surgical range slicing (lines/chars/bytes). Hard caps at 8KB/200-lines/8000-chars prevent context bombs. `truncated` field on all responses.
- **`file_edit`** -- surgical old-string/new-string replacement. Never
  read a whole file just to change one line.
- **`file_write`**, **`file_grep`**, **`file_glob`**, **`file_insert`**
  -- the full file toolkit.

### tmux tools (`pip install spad-mcp[tmux]`)

spad ships with a tmux plugin (optional; on by default if installed) that adds:

- **`tmux_interact`** -- send keystrokes and text to a tmux session,
  optionally wait for events (idle, exit, pattern match). One tool,
  composable kwargs.
- **`tmux_screenshot`** -- capture pane content on demand.
- **`tmux_session_create`** -- start sessions with structured command
  arrays. Full lifecycle management.
- **`tmux_session_destroy`**, **`tmux_session_attach`**, **`tmux_sessions`**

All tools accept structured JSON params. All responses are structured
JSON. No parsing, no regex on tool output, no surprises.

## Claude Code testing

spad ships with a Claude Code plugin that adds:

- **Idle detection** -- watches CC's JSONL transcript for `end_turn`
  events. Know the instant CC finishes responding, not 500ms later.
- **Context tracking** -- ctx%, cost, model surfaced in event data.
- **Session binding** -- auto-discovers CC's JSONL file on session start.

```python
# Start CC, send a prompt, wait for response
tmux_session_create(name="test", command=["claude", "--dangerously-skip-permissions"],
                    plugin="claude-code")
tmux_interact(
    send=["s:Write a haiku about testing.", "k:Enter"],
    wait={"events": ["idle"], "timeout": 60}
)
# -> {"ok": true, "event": "idle", "elapsed": 3.2, "ctx_pct": 8, "cost_usd": 0.02}

tmux_screenshot()
# -> {"content": "...\n  Tests pass silently\n  But edge cases lurk beneath\n  Ship it anyway\n..."}
```

## Not just for Claude Code

The core is program-agnostic. Anything that runs in tmux can be driven:
redis-cli, Python REPLs, psql, vim, custom CLIs. Programs with
introspectable state files get richer semantics via plugins. Write a
plugin, configure what "idle" means for your program, and spad handles
the rest.

And without tmux at all, spad is still a capable file ops + shell + file
watching toolkit -- useful anywhere an agent needs to interact with a
host without shell escaping.

## Install

```bash
pip install spad-mcp          # core: file ops, shell, watcher, plugins
pip install spad-mcp[tmux]    # + tmux adapter (default for CC testing)
```

## Quick start

### As an MCP server (for AI agents)

Add to your agent's MCP config:

```json
{
  "mcpServers": {
    "spad": {
      "url": "http://localhost:9830/mcp"
    }
  }
}
```

Start the server:

```bash
spad-server
```

For remote hosts, SSH tunnel:

```bash
ssh -L 9830:localhost:9830 user@host -N
```

### As a CLI (for humans)

```bash
spad tmux interact -s "ls -al" -k Enter
spad tmux screenshot
spad shell ls -la /tmp
spad file read /var/log/app.log --range -50:
spad file edit /tmp/config.yaml "old_value" "new_value"
spad put /local/file.bin /remote/path/file.bin   # OOB bulk upload
spad get /remote/path/file.bin /local/copy.bin   # OOB bulk download
```

Same server, same tools. The CLI is a thin MCP client (fastmcp.Client).
`spad put` / `spad get` use the /spad/upload and /spad/download HTTP routes
for binary bulk transfer without the MCP tool overhead.

## Why we built this

spad started as a tool for one specific use case -- Claude Code extension
testing -- and we kept building because the underlying primitives turned
out to be generally useful. The current shape is a remote-automation
server that happens to ship with a CC plugin, not a CC tool that happens
to be reachable remotely.

The original itch: we maintain a team of AI agents that test and develop
Claude Code extensions -- skills, hooks, plugins, agent teams. Unit tests
check code; they don't check whether a hook fires at the right time when
an agent does something unexpected. We needed one agent to control
another agent's full environment -- files, config, prompts -- and observe
what happened. The first version (rig v1) was a CLI that shelled out over
SSH. It worked, but shell escaping was a persistent failure mode. Every
multi-word prompt, every file path with spaces, every regex argument was
a potential silent breakage.

spad-mcp eliminates that entire class of bug by moving to structured
MCP tool calls. The agent sends JSON, the server acts on it. No shell
in the middle. No escaping. No quoting. It just works.

Along the way we realized the tool isn't specific to Claude Code or even
to testing. It's a general-purpose automation server that happens to ship
with a CC plugin and a tmux adapter. The core file ops, shell exec, and
file watching are useful on their own -- locally or remotely.

## Architecture

```
MCP Client (agent, CLI, script)
  |
  | HTTP/SSE (localhost or SSH tunnel)
  |
  v
[spad-mcp server]
  |- shell         argv-based command execution
  |- file_*        read/write/edit/grep/glob
  |- watcher       inotify-based file monitoring
  |- plugins       program-specific adapters (CC ships default)
  |
  |- tmux_*        tmux control adapter (optional, via libtmux)
```

## Key design decisions

- **tmux is optional.** Core (file ops, shell, watcher) works without it.
  `pip install spad-mcp[tmux]` adds the tmux adapter. No premature
  abstraction over "session" -- it means tmux session in MVP. Generalize
  when a second adapter (subprocess-PTY, etc.) exists.
- **`s:`/`k:` prefix on send arrays.** `["s:ls -al", "k:Enter"]` --
  explicit, no guessing whether a string is text or a key name.
- **argv-based shell.** `shell({argv: ["grep", "-r", "pattern", "/path"]})`
  -- no shell interpretation, no escaping.
- **Pythonic file_read.** `range: [-50, null]` for tail, 0-indexed,
  half-open, with mode (lines/chars/bytes) and default caps.
- **Plugin-defined events.** Core provides match, exit, file_change,
  timeout. Plugins add domain events (idle for CC, ready for Redis).
- **Agent drives recovery.** Server is stateless between restarts. If it
  dies, the agent (which is smart) decides what to do. No mechanical
  auto-recovery that might invalidate a test.

## Requirements

- Python 3.12+
- tmux (only if using tmux tools)
- Linux (inotify; macOS support deferred)

## Documentation

- [DESIGN.md](DESIGN.md) -- full design document with rationale
- [CHANGELOG.md](CHANGELOG.md) -- version history
- [QUICKSTART.md](QUICKSTART.md) -- getting started guide
- [docs/RELEASING.md](docs/RELEASING.md) -- release procedure (maintainers)
- [docs/adr/](docs/adr/) -- design decision records / architectural rationale

## Status

v0.2.1 -- MCP server, spad CLI, OOB transfer endpoints, and full test suite
(default + SSH + CC E2E) implemented and tested. Core tools (file ops, shell,
watcher, plugin host) and tmux adapter ship by default; the Claude Code plugin
is enabled by default and configurable via `spad.toml`. spad CLI is fully
implemented. SSH tier covers a full deploy + tunnel + scp round-trip via the
new template-based test target config (see [QUICKSTART](QUICKSTART.md) and
[docs/adr/0006](docs/adr/0006-ssh-test-target-template-config.md)).
Linux only (inotify).

See [docs/RELEASING.md](docs/RELEASING.md) for the release procedure.

## License

[MIT](LICENSE)
