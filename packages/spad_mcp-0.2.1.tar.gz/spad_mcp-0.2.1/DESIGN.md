# spad-mcp: Design Document v3

**Status:** Design complete -- ready for implementation
**Date:** 2026-05-06
**Author:** Sandy
**Reviews:** 3-agent panel (2026-05-05), Jara feedback x2 (2026-05-05)
**Name:** spad-mcp -- Spooky Action at a Distance

## What It Is

An MCP server for driving Claude Code (and any tmux program) from tests,
agents, or scripts, locally or over SSH. No shell escaping. Distance
optional.

Run it on the target host (or locally). Connect from any MCP client.
Execute commands, edit files, watch for events, and optionally control
tmux sessions -- all through structured tool calls.

Core (file ops, shell, watcher, plugin host) works without tmux. The
tmux adapter adds interactive session control. Claude Code ships as
the showcase plugin, on by default.

### Package tiers

```
pip install spad-mcp          # core: shell, file ops, watcher, plugins
pip install spad-mcp[tmux]    # + tmux adapter (default for CC testing)
```

Core imports must not depend on libtmux. Agents using spad purely for
file ops + shell + watching don't load tmux at all.

## Architecture

```
MCP Client (agent, CLI, script)
  |
  | HTTP/SSE (localhost, SSH tunnel for remote)
  |
  v
[spad-mcp server]
  |- shell         argv-based command execution
  |- file_*        read/write/edit/grep/glob
  |- watcher       inotify-based file monitoring
  |- plugins       program-specific adapters (CC ships default)
  |
  |- tmux_*        tmux adapter (optional, via [tmux] extra)
```

Server runs on the target host (or locally). Clients connect over HTTP.
For remote hosts, SSH port forwarding provides the tunnel.

### Trust Model

Anyone who can reach the listening port has full host access via `shell`
and `tmux_interact`. SSH tunnel is the access control. No in-band auth
in MVP. Document this plainly. The server binds `127.0.0.1` only.

## Core Tools (no tmux required)

### shell

Execute a command on the host. Argv-based, no shell interpretation.

| Param | Type | Required | Description |
|-------|------|----------|-------------|
| `argv` | `str[]` | yes | Command and arguments (no shell) |
| `cwd` | `str` | no | Working directory |
| `env` | `dict` | no | Additional environment variables |
| `timeout` | `int` | no | Max seconds (default 30, max 300) |

Returns: `{stdout, stderr, rc}`

If a caller genuinely needs shell features (pipes, globs, redirects),
they pass `["bash", "-c", "..."]` explicitly and own the escaping.

### status

Host and process state.

Returns: `{ok, ...}` + plugin data

### File Operations

#### File Operations (surgical)

MCP file operations are surgical, not bulk -- see docs/adr/0001-surgical-operations-philosophy.md.
Inference cost dominates; every byte returned costs ~1.3 tokens. Tools minimize what the agent
has to look at.

**Tool intent matrix:**

| Tool | Requires file exists? | Creates file? | Destructive? |
|------|----------------------|---------------|--------------|
| `file_write` | No | Yes (refuses if exists, unless `overwrite: true`) | Only with explicit `overwrite` |
| `file_edit` | Yes | No | Yes -- surgical replacement |
| `file_insert` | Yes | No | No -- purely additive |
| `file_read` | Yes | No | No |
| `file_grep` | N/A (operates on dir) | No | No |
| `file_glob` | N/A (operates on dir) | No | No |

#### file_read

Pythonic slice semantics across all modes. Hard caps enforce surgical use.

| Param | Type | Required | Description |
|-------|------|----------|-------------|
| `path` | `str` | yes | Absolute file path |
| `mode` | `str` | no | `"lines"` (default), `"chars"`, `"bytes"` |
| `range` | `[int\|null, int\|null]` | no | Python slice `[start, stop)`. 0-indexed, half-open. Negative = from end. null = open-ended. Out-of-range clamps. start >= stop returns empty. |
| `errors` | `str` | no | Text modes only. `"replace"` (default), `"strict"`, `"ignore"` |

**Hard caps (universal -- no escape hatch):**

| mode | cap |
|------|-----|
| lines | 200 lines AND 8192 bytes (whichever fires first) |
| chars | 8000 chars AND 8192 bytes (whichever fires first) |
| bytes | 8192 bytes |

Response shape (text modes):
```json
{"content": "...", "units_read": 50, "bytes_read": 4096, "truncated": false, "eof": true}
```

Response shape (bytes mode):
```json
{"content_b64": "...", "bytes_read": 1024, "truncated": false, "eof": false}
```

`truncated: true` when the cap fired before the requested range was exhausted.
`eof: true` when the end of the file was reached.
Both can be false (range stopped before EOF and before cap). They never overlap semantically.

**Important:** Line indexing is 0-based. grep, cat -n, and editors are
1-based. Agents will mix these up. Call this out in the tool description.

#### file_write

Creates new files from agent-generated content. Refuses if file exists unless `overwrite: true`.
No `append` flag -- appending is `file_insert({position: "end"})`.

| Param | Type | Required | Description |
|-------|------|----------|-------------|
| `path` | `str` | yes | Absolute file path |
| `content` | `str` | yes | Text content to write (UTF-8) |
| `overwrite` | `bool` | no | If true, replace existing file. Default false. |

Returns: `{ok: true, bytes: int}`

Error if file exists and overwrite is false:
`"file exists at <path>. Use overwrite=true to replace, or file_edit/file_insert to modify in place."`

#### Other File Tools

| Tool | Params | Returns | Notes |
|------|--------|---------|-------|
| `file_edit` | `{path, old, new, all?}` | `{replacements}` | File must exist. 64KB cap on `new`. |
| `file_grep` | `{root, pattern, glob?}` | `{matches, truncated, match_count}` | 8KB cap on match text. |
| `file_glob` | `{root, pattern}` | `{files, truncated, match_count}` | 8KB cap on path text. |
| `file_insert` | `{path, content, position, anchor?}` | `{ok, line}` | File must exist. position: start/end/before/after. anchor required for before/after. 64KB cap on content. |

`file_edit` does surgical old-string/new-string replacement. File must exist.

`file_grep` takes `root` (directory to search) and optional `glob` filter. Returns `match_count`
even when truncated.

`file_insert` position taxonomy:
- `start` -- prepend; no anchor needed
- `end` -- append; no anchor needed  
- `before` / `after` -- anchor required (substring match on first matching line)

File transfer (recursive, permissions-preserving) stays out-of-band via
scp over the SSH tunnel or the OOB HTTP endpoints (Phase 8.2). CLI client wraps this.

## tmux Tools (requires `[tmux]` extra)

Tools prefixed with `tmux_` to make the coupling explicit. Agents using
spad purely for file ops + shell don't load tmux at all.

### tmux_interact

The primary tmux tool. Sends input to a tmux session and optionally
waits for events. kwargs determine behavior.

```python
# Just send
tmux_interact(send=["s:ls -al", "k:Enter"])

# Send and wait for idle
tmux_interact(
    send=["s:fix the build", "k:Enter"],
    wait={"events": ["idle"], "timeout": 120}
)

# Multi-event wait: first one wins
tmux_interact(
    send=["s:run tests", "k:Enter"],
    wait={"events": ["idle", "exit", {"match": "PASS|FAIL"}], "timeout": 60}
)

# Just wait, no send
tmux_interact(wait={"events": ["idle", "exit"], "timeout": 30})

# Interrupt then wait for shell prompt
tmux_interact(send=["k:C-c"], wait={"events": [{"match": "\\$\\s*$"}], "timeout": 10})
```

**`send` array format:** Each element is prefixed to distinguish text from keys:
- `s:` -- literal string (text). Sent via tmux send-keys -l. Sent as one
  chunk (paste-style), not character-by-character.
- `k:` -- key name. Sent as tmux key (Enter, C-c, Tab, Space, etc.).
- No prefix -- error. Forces explicit, prevents ambiguity.

**`wait` dict:**
- `events` -- list of terminating conditions. Scalars for simple events
  (`"idle"`, `"exit"`), dicts when params needed (`{"match": "pattern"}`,
  `{"file_change": "/tmp/result.json"}`). First event that fires wins.
  Same-tick tiebreaker: order in the `events` list.
- `timeout` -- max seconds. Returns timeout event if nothing else fires.

**Returns:**
- No wait: `{sent: true}` (tmux accepted keystrokes -- not confirmation
  the program received or processed them. Document this explicitly.)
- With wait: `{ok, event, elapsed, ...}` with plugin-enriched data.

| Param | Type | Required | Description |
|-------|------|----------|-------------|
| `send` | `str[]` | no | Prefixed input array (`s:text`, `k:keyname`) |
| `wait` | `dict` | no | `{events: [...], timeout: int}` |
| `session` | `str` | no | tmux session name (default: configured session) |

### tmux_screenshot

Capture tmux pane content.

| Param | Type | Required | Description |
|-------|------|----------|-------------|
| `session` | `str` | no | tmux session name |
| `lines` | `int` | no | Lines to capture (default 50) |

Returns: `{content: str}`

### tmux_sessions

List available tmux sessions.

Returns: `{sessions: str[]}`

### tmux Session Lifecycle

| Tool | Params | Returns |
|------|--------|---------|
| `tmux_session_create` | `{name, command, cwd?, env?, plugin?}` | `{ok, session, pid}` |
| `tmux_session_destroy` | `{name, signal?}` | `{ok}` |
| `tmux_session_attach` | `{name}` | `{ok, session}` |

`tmux_session_create` accepts `command` as an argv array (not a shell
string) so the no-escaping promise holds end-to-end.

The `plugin` param declares which plugin owns the session for event
enrichment. For CC: `plugin: "claude-code"` triggers the JSONL discovery
handshake (see CC plugin section).

No abstraction over the session concept yet. "Session" means tmux session
in MVP. When a second adapter arrives (subprocess-PTY, etc.), generalize
with two concrete cases informing the design.

## Events

### Event Taxonomy

**Terminal events (v1):** fire once, resolve a `wait` call.

| Event | Payload | Source |
|-------|---------|--------|
| `idle` | `{elapsed}` + plugin data | Plugin (e.g., CC end_turn) |
| `exit` | `{code?}` | Session PID monitor |
| `match` | `{text, line}` | Pane or file watcher |
| `file_change` | `{path}` | inotify |
| `timeout` | `{elapsed}` | Deadline |

**Progressive events (v2, deferred):** streamed during long waits.
- `pane_delta`, `stderr_chunk`, etc.
- Clients opt in; default is terminal-only for backward compat.

**Protocol:** Every event carries a schema version field so v2 clients
can negotiate against v1 servers. Spec the full event type taxonomy and
payload shapes before v1 ships; implement terminal events only.

### Process Monitoring

Session-bound, not name-based. `tmux_session_create` gives the tmux
pane; pane gives the foreground PID via libtmux. Exit event fires when
that PID disappears. No `process_name` config, no fragile string match,
no misconfiguration possible.

## Plugin System

Plugins register event sources, enrich events, and optionally add tools.

### Plugin Contract

```python
class Plugin:
    name: str

    def configure(self, config: dict):
        """Receive deployment config."""

    def on_session_start(self, session) -> list:
        """Called on session_create with plugin=self.name.
        Returns watch specs dynamically (e.g., after discovering
        the JSONL path). Core owns the inotify instance; plugins
        return declarative watch specs, not raw watchers."""

    def enrich_event(self, event) -> event:
        """Add domain data to events before delivery."""

    def tools(self) -> list:
        """Return additional MCP tool definitions."""
```

Core owns one inotify instance. Plugins register watch specs
declaratively via `on_session_start`. Core dispatches events to the
owning plugin for enrichment.

### Claude Code Plugin (ships in the box, on by default)

```python
class ClaudeCodePlugin:
    name = "claude-code"

    def configure(self, config):
        self.projects_dir = config.get("projects_dir",
            "~/.claude/projects")

    def on_session_start(self, session):
        # Snapshot existing JSONL files, start CC, watch for
        # the new JSONL that appears. Bind it to this session.
        existing = set(glob(f"{self.projects_dir}/**/*.jsonl"))
        # ... after CC starts, detect new file ...
        new_jsonl = (new_files - existing).pop()
        return [
            FileWatcher(new_jsonl, event="idle",
                        parser=self._parse_jsonl_line),
        ]

    def _parse_jsonl_line(self, line):
        """Structural parse, not regex. One json.loads per line."""
        try:
            obj = json.loads(line)
            msg = obj.get("message", {})
            if msg.get("stop_reason") == "end_turn":
                return "idle"
        except json.JSONDecodeError:
            pass
        return None

    def enrich_event(self, event):
        if event.type == "idle":
            ctx = self._read_ctx_file()
            event.data.update(ctx)  # ctx_pct, cost_usd, model
        return event
```

**JSONL binding:** Dynamic, not static config. On `tmux_session_create`
with `plugin: "claude-code"`, the plugin snapshots existing JSONL files
in the projects dir, then watches for the new file that appears after CC
starts. Bound path exposed via `status` for debugging.

**JSONL parsing:** Structural (`json.loads` + field check), not regex.
Resilient to schema changes. One parse per appended line.

**No /clear rebinding.** Policy: spad-driven CC sessions don't use
`/clear`. Agent calls `tmux_session_destroy` + `tmux_session_create` for
a fresh session. Plugin only binds JSONL on session start.

**Compatibility:** Pin to CC version range. Warn on mismatch. Document
how users override idle detection for newer CC versions.

### Example: Redis Plugin

```python
class RedisPlugin:
    name = "redis"

    def on_session_start(self, session):
        return [
            # "idle" for redis = prompt visible
            # No JSONL, no special file. Use pane match.
        ]

    def tools(self):
        return [
            {"name": "redis_info", "description": "Run INFO command",
             "inputSchema": {...}}
        ]
```

## Client Story

### AI Agents (primary use case)

Configure as an MCP server in agent settings. Agent calls tools directly
with structured params. No Bash tool, no shell escaping. Context cost is
equivalent to Bash tool calls (both are MCP) with escaping eliminated.

### CLI: `spad`

Thin CLI that translates commands to MCP tool calls:

```bash
spad tmux interact -s "ls -al" -k Enter
spad tmux interact -s "fix the build" -k Enter --wait idle --timeout 120
spad tmux screenshot
spad shell ls -la /tmp
spad file read /tmp/app.log --range -50:
spad file edit /tmp/foo.py "old text" "new text"
spad status
```

Same server, same tools. Useful for humans verifying the harness or
driving tests manually.

### Mechanical Drivers (scripts, CI)

Any HTTP client can POST JSON-RPC. No SDK required.

## Implementation

### Stack

- Python 3.12
- `fastmcp` -- MCP transport (proven by browser-mcp, avoids hand-rolling
  JSON-RPC/SSE)
- `inotify_simple` -- Linux file change notifications
- `libtmux` -- native tmux API (optional, via `[tmux]` extra)

### Connectivity

Local: server binds `127.0.0.1:<port>`.
Remote: SSH port forward.

```bash
ssh -L 9830:localhost:9830 user@host -N
```

Agent MCP config points to `http://localhost:9830/mcp`.

### Server Lifecycle

Single long-running Python process. Ship daemonable -- user picks
supervision (nohup, supervisord, systemd, tmux detach).

If server dies, the client decides what to do. No mechanical
auto-recovery. No state persistence. tmux sessions survive independently.

### File Transfer

Bulk/binary: scp over SSH tunnel (CLI wraps this).
Small text: `file_read` / `file_write` through MCP.
Surgical: `file_edit` avoids reading the full file entirely.

## Project Structure

```
spad-mcp/
  server.py              -- MCP server entry point
  core/
    files.py             -- file operations (read/write/edit/grep/glob)
    shell.py             -- command execution (argv-based)
    watcher.py           -- inotify file watcher
  adapters/
    tmux.py              -- libtmux adapter (optional via [tmux] extra)
  plugins/
    claude_code.py       -- CC: JSONL idle, ctx tracking (default on)
  cli/
    spad.py              -- CLI client (MCP calls under the hood)
  config/
    default.yaml         -- default configuration
```

Core imports (`core/`) must not depend on libtmux. The tmux adapter
loads conditionally when `[tmux]` extra is installed and tmux tools
are configured.

Container image / deployment artifacts live outside the Python package.

### Plugin Loading

Explicit config for MVP. Entry-point discovery (`spad.plugins`) is a
post-MVP nice-to-have.

### Testing Strategy

Real tmux in CI. pytest + actual tmux server. Fast enough for the test
surface, and mocked libtmux tests less than we need for a testing tool.

## MVP Scope

**In:**
- Core: shell, file_read (pythonic slicing), file_write, file_edit,
  file_grep, file_glob, file_insert, status
- tmux adapter: tmux_interact, tmux_screenshot, tmux_sessions,
  tmux_session_create, tmux_session_destroy, tmux_session_attach
- inotify file watcher
- Plugin system with lifecycle hooks
- Claude Code plugin (in the box, default on)
- CLI client (`spad`) with core + tmux commands
- SSH tunnel connectivity docs
- SSE streaming protocol spec (terminal events only in v1)
- Two-tier install: `spad-mcp` (core) / `spad-mcp[tmux]`

**Out (post-MVP):**
- In-band auth (SSH tunnel sufficient)
- Multi-client coordination / advisory locks
- Plugin hot-reload / entry-point discovery
- pytest-spad companion package
- Progressive streaming events (v2)
- Non-Linux support (inotify is Linux-only)
- Encoding param on file_read (UTF-8 assumed)
- Session abstraction beyond tmux (subprocess-PTY, etc.)

## Decisions (resolved)

| Decision | Resolution |
|----------|------------|
| Project name | spad-mcp |
| CLI name | `spad` |
| MCP transport | fastmcp |
| send format | `s:`/`k:` prefix, no prefix = error |
| shell format | argv array, no shell interpretation |
| shell blocklist | dropped (theater) |
| process monitor | session-bound PID, not process name |
| CC /clear | no rebind; agent destroys + recreates session |
| JSONL parsing | structural (json.loads), not regex |
| file_read | pythonic slicing + universal 8KB/200/8000 caps; truncated field; no [null,null] escape hatch |
| file_get/file_put (b64) | replaced with OOB HTTP routes (/spad/upload, /spad/download). Not MCP tools to avoid agent-context cost. See ADR 0002. |
| file_write semantics | overwrite=true required to replace existing; no append (use file_insert(position=end)) |
| file_insert taxonomy | position: start/end/before/after; anchor only for before/after |
| file_edit/file_insert content cap | 64KB sanity cap; bulk via file_write or OOB scp |
| streaming | spec protocol v1, implement terminal events only |
| supervision | ship daemonable, don't prescribe |
| plugin loading | explicit config for MVP |
| tmux coupling | optional `[tmux]` extra; `tmux_` prefix on all tmux tools |
| session abstraction | none in MVP; "session" = tmux session. Generalize with 2 cases |
| packaging | `pip install spad-mcp` (core) / `spad-mcp[tmux]` (+ tmux adapter) |

## Decision Records

Architectural decisions are tracked in docs/adr/:

- [0001-surgical-operations-philosophy.md](docs/adr/0001-surgical-operations-philosophy.md) -- file ops are surgical, not bulk; hard caps; tool intent matrix
- [0002-oob-bulk-transfer.md](docs/adr/0002-oob-bulk-transfer.md) -- OOB HTTP upload/download endpoints vs. MCP file_get/file_put
- [0003-phase-8-build-plan.md](docs/adr/0003-phase-8-build-plan.md) -- Phase 8 phased build plan and locked decisions

## Implementation Sequencing

1. Lock tmux session lifecycle tools (tmux_session_create/destroy/attach)
2. Lock plugin contract (on_session_start lifecycle hook)
3. Implement core (files, watcher, shell) + MCP transport
4. Implement tmux adapter
5. Implement CC plugin against locked contract
6. CLI as MCP client last

## Pre-v0.1 Checklist

- [ ] PyPI / GitHub / npm name-collision check for "spad"
- [ ] Verify `spad` doesn't conflict in developer tooling space
- [ ] SSE event schema finalized (type taxonomy, payload shapes, version field)
- [ ] v1 mark-based race-fix pattern documented and ported to wait logic
