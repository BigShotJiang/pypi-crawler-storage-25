# Architecture Decision Records

This directory contains Architecture Decision Records (ADRs) for spad-mcp.

ADRs document significant design decisions: what was decided, why, and what
alternatives were considered. They are the durable record for architectural
choices and the why-trail future contributors depend on.

## Status values

- Proposed -- under discussion, not yet implemented
- Accepted -- decision made, in effect
- Superseded -- replaced by a newer ADR (link to successor)
- Deprecated -- no longer relevant
- Completed -- for plan-type ADRs: the work landed

## Numbering

Zero-padded 4 digits (0001, 0002, ...). Numbers are never reused, even when
an ADR is superseded or deprecated.

## Template

Start new ADRs from [`0000-template.md`](0000-template.md). It is the
canonical skeleton (Context, Decision, Alternatives considered with
For / Against / Reason rejected, Consequence). Copy, renumber, fill in.

## Index

| ADR | Title | Status |
|-----|-------|--------|
| [0001](0001-surgical-operations-philosophy.md) | Surgical operations philosophy | Accepted |
| [0002](0002-oob-bulk-transfer.md) | OOB bulk transfer endpoints | Accepted |
| [0003](0003-phase-8-build-plan.md) | Phase 8 build plan | Completed |
| [0004](0004-headline-feature-coverage-discipline.md) | Headline-feature coverage discipline | Accepted |
| [0005](0005-dual-remote-release-flow.md) | Dual-remote release flow (Gitea backup, GitHub seaport) | Accepted |
| [0006](0006-ssh-test-target-template-config.md) | SSH test target template-based config | Accepted |
