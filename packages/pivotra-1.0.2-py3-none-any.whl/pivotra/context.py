"""
Build fleet context summary to inject into BRO system prompt.
Keeps the context window lean — only sends relevant data.
"""
from __future__ import annotations

from typing import Optional

from . import api_client as api


def build_fleet_context(agent_id: Optional[str] = None) -> dict:
    """
    Returns a context dict with:
    - agents summary (count, online, list of hostnames/IDs)
    - anomalies summary (total count, recent critical ones)
    - selected agent details (if agent_id is given)
    """
    context: dict = {}

    try:
        agents = api.list_agents()
        online = [a for a in agents if a.get("status") == "online" or a.get("online")]
        context["agents_total"]  = len(agents)
        context["agents_online"] = len(online)
        context["agents_list"]   = [
            {"id": a.get("id"), "hostname": a.get("hostname"),
             "online": bool(a.get("status") == "online" or a.get("online"))}
            for a in agents[:30]
        ]
    except Exception:
        context["agents_total"]  = 0
        context["agents_online"] = 0
        context["agents_list"]   = []

    try:
        anomalies = api.get_alerts(limit=10)
        context["recent_alerts_count"] = len(anomalies)
        context["recent_alerts"] = [
            {
                "severity": a.get("severity"),
                "message":  (a.get("message") or a.get("title") or "")[:120],
                "agent_id": a.get("agent_id"),
                "timestamp": a.get("timestamp") or a.get("created_at"),
            }
            for a in anomalies[:5]
        ]
    except Exception:
        context["recent_alerts_count"] = 0
        context["recent_alerts"]       = []

    if agent_id:
        try:
            agent = api.get_agent(agent_id)
            context["selected_agent"] = {
                "id":       agent.get("id"),
                "hostname": agent.get("hostname"),
                "os":       agent.get("os"),
                "ip":       agent.get("ip") or agent.get("ip_address"),
                "online":   bool(agent.get("online")),
                "isolated": bool(agent.get("isolated")),
                "version":  agent.get("version"),
            }
        except Exception:
            context["selected_agent"] = {"id": agent_id}

        try:
            anomalies = api.get_agent_anomalies(agent_id, limit=5)
            context["agent_anomalies"] = [
                {
                    "severity": a.get("severity"),
                    "type":     a.get("type") or a.get("anomaly_type"),
                    "details":  (a.get("details") or a.get("description") or "")[:120],
                    "timestamp": a.get("timestamp"),
                }
                for a in anomalies
            ]
        except Exception:
            context["agent_anomalies"] = []

    return context


def context_to_system_prompt(context: dict) -> str:
    """Format context dict into a system prompt string."""
    lines = [
        "You are BRO, the Pivotra AI Platform assistant embedded in the CLI.",
        "You are conversational, analytical, and multilingual (French and English).",
        "You can write code, bash scripts, YAML playbooks, and detailed reports on demand.",
        "Always respond in the same language the user writes in.",
        "",
        "## Fleet Context",
        f"- Total agents: {context.get('agents_total', '?')}",
        f"- Online agents: {context.get('agents_online', '?')}",
        f"- Recent alerts: {context.get('recent_alerts_count', 0)}",
    ]

    agents = context.get("agents_list", [])
    if agents:
        lines.append("- Agent list:")
        for a in agents:
            status = "online" if a.get("online") else "offline"
            lines.append(f"  • {a.get('id')} ({a.get('hostname', '?')}) — {status}")

    alerts = context.get("recent_alerts", [])
    if alerts:
        lines.append("- Recent alerts:")
        for a in alerts:
            lines.append(f"  • [{a.get('severity','?').upper()}] {a.get('agent_id','?')} — {a.get('message','')}")

    sel = context.get("selected_agent")
    if sel:
        lines += [
            "",
            "## Selected Agent (current context)",
            f"- ID: {sel.get('id')}",
            f"- Hostname: {sel.get('hostname')}",
            f"- OS: {sel.get('os')}",
            f"- IP: {sel.get('ip')}",
            f"- Online: {sel.get('online')}",
            f"- Isolated: {sel.get('isolated')}",
        ]
        agent_anomalies = context.get("agent_anomalies", [])
        if agent_anomalies:
            lines.append("- Agent anomalies:")
            for a in agent_anomalies:
                lines.append(f"  • [{a.get('severity','?').upper()}] {a.get('type')} — {a.get('details','')}")

    lines += [
        "",
        "## Pivotra CLI Commands Reference",
        "The following commands are available directly in the Pivotra CLI (pivotra <command>):",
        "  status / agents                        — list all agents",
        "  agents <id>                            — agent detail",
        "  run <id> <cmd>                         — run shell command on agent",
        "  shell <id>                             — interactive PTY session",
        "  scan <id>                              — trigger security scan",
        "  isolate / unisolate <id>               — network isolation",
        "  restart / deregister <id>              — lifecycle management",
        "  rotate-key <id>                        — rotate agent API key",
        "  deploy <host> [--user] [--key]         — deploy new agent via SSH",
        "  spawn <id>                             — spawn sub-agent",
        "  block / unblock <ip> [--agent <id>]   — IP blocking",
        "  ip-check <ip>                          — threat intelligence lookup",
        "  logs <id> [--source] [-n N]            — log lines",
        "  anomalies [id] [-n N]                  — anomalies",
        "  alerts [-n N] [--severity]             — platform alerts",
        "  tail <id> <path> [-n N]                — tail remote log file",
        "  watch <secs> <cmd>                     — repeat command every N seconds",
        "  fleet-health [--format]                — fleet-wide health dashboard",
        "  threat-score [--format]                — AI threat score per agent",
        "  baseline <id>                          — capture security baseline",
        "  diff <id> --baseline <file>            — compare vs baseline",
        "  timeline <id> [--days N]               — event timeline",
        "  file <id> read <path>                  — read remote file",
        "  file <id> write <path> <content>       — write remote file",
        "  docker <id> ps/exec/logs               — container management",
        "  psql <id> <sql>                        — PostgreSQL query",
        "  broadcast <cmd>                        — run on ALL agents",
        "  quarantine list/add <id>               — quarantine management",
        "  hunt run/jobs/results                  — threat hunting",
        "  ioc lookup/list/add                    — IOC management",
        "  playbook list/run/log/external-runs    — playbook management",
        "  queue list/approve/reject              — approval queue",
        "  group list/create/assign               — agent groups",
        "  group-run <group_id> <cmd>             — run on all agents in group",
        "  report generate/list/download          — security reports",
        "  2fa status/enable/disable              — two-factor authentication",
        "  invite <email> --role <role>           — invite team member",
        "  token list/create/revoke               — personal API tokens",
        "  export [txt|json|csv]                  — export history",
        "",
        "## Available CLI Actions",
        "If you recommend an action, append it on its OWN LINE in this EXACT format:",
        "",
        "-- Agent control --",
        "ACTION: isolate <agent_id>",
        "ACTION: unisolate <agent_id>",
        "ACTION: block_ip <ip_address>",
        "ACTION: scan <agent_id>",
        "ACTION: restart <agent_id>",
        "ACTION: deregister <agent_id>",
        "ACTION: broadcast <shell_command>",
        "ACTION: rotate_key <agent_id>",
        "ACTION: deploy <host> <user> <key_path>",
        "ACTION: spawn <agent_id>",
        "",
        "-- Infra operations (files, docker, PostgreSQL) --",
        "ACTION: run_command <agent_id> <shell_cmd>",
        "ACTION: file_read <agent_id> <path>",
        "ACTION: file_write <agent_id> <path> <content>",
        "ACTION: docker_exec <agent_id> <container> <cmd>",
        "ACTION: docker_logs <agent_id> <container>",
        "ACTION: docker_ps <agent_id>",
        "ACTION: psql_query <agent_id> <sql>",
        "",
        "-- Forensics & Intelligence --",
        "ACTION: hunt <query>",
        "ACTION: investigate <anomaly_id>",
        "ACTION: ioc_add <type> <value>",
        "ACTION: ip_check <ip>",
        "",
        "-- Response & Playbooks --",
        "ACTION: playbook <playbook_id> [<target>]",
        "ACTION: queue_approve <action_id>",
        "ACTION: queue_reject <action_id>",
        "",
        "-- Logs & Anomalies --",
        "ACTION: logs <agent_id> <limit>",
        "ACTION: anomalies <agent_id> <limit>",
        "",
        "-- Reporting --",
        "ACTION: report pdf",
        "",
        "Rules:",
        "- Only include actions when genuinely necessary, never for informational responses.",
        "- Always explain WHY you recommend an action before the ACTION: line.",
        "- For destructive actions (deregister, broadcast), warn the user about impact.",
        "- If you need to read a file to analyze it, use ACTION: file_read.",
        "- If you suspect an IP, use ACTION: ip_check first, then ACTION: block_ip if confirmed.",
    ]

    return "\n".join(lines)
