"""
REST client for Pivotra backend API.
All calls authenticated with JWT stored by auth.py.
"""
from __future__ import annotations

import sys
from typing import Any, Optional

import httpx
from rich.console import Console

from .auth import get_base_url, require_token

console = Console()


_UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36 PivotraCLI/1.0"

def _headers() -> dict:
    return {
        "Authorization": f"Bearer {require_token()}",
        "User-Agent": _UA,
    }


def _base() -> str:
    return get_base_url()


class APIError(Exception):
    def __init__(self, status_code: int, message: str):
        self.status_code = status_code
        self.message = message
        super().__init__(f"API error {status_code}: {message}")


def _get(path: str, params: Optional[dict] = None, timeout: int = 10) -> Any:
    url = f"{_base()}{path}"
    try:
        with httpx.Client(timeout=timeout, follow_redirects=True) as c:
            r = c.get(url, headers=_headers(), params=params or {})
        if r.status_code == 401:
            console.print("[red]Session expired.[/red] Run [bold]pivotra login[/bold].")
            sys.exit(1)
        r.raise_for_status()
        return r.json()
    except httpx.HTTPStatusError as e:
        raise APIError(e.response.status_code, e.response.text[:200])
    except httpx.RequestError as e:
        raise APIError(0, str(e))


def _post(path: str, payload: dict, timeout: int = 15) -> Any:
    url = f"{_base()}{path}"
    try:
        with httpx.Client(timeout=timeout) as c:
            r = c.post(url, headers=_headers(), json=payload)
        if r.status_code == 401:
            console.print("[red]Session expired.[/red] Run [bold]pivotra login[/bold].")
            sys.exit(1)
        r.raise_for_status()
        return r.json()
    except httpx.HTTPStatusError as e:
        console.print(f"[red]API error {e.response.status_code}:[/red] {e.response.text[:200]}")
        sys.exit(1)
    except httpx.RequestError as e:
        console.print(f"[red]Connection error:[/red] {e}")
        sys.exit(1)


def _delete(path: str, timeout: int = 15) -> Any:
    url = f"{_base()}{path}"
    try:
        with httpx.Client(timeout=timeout) as c:
            r = c.delete(url, headers=_headers())
        if r.status_code == 401:
            console.print("[red]Session expired.[/red] Run [bold]pivotra login[/bold].")
            sys.exit(1)
        r.raise_for_status()
        return r.json()
    except httpx.HTTPStatusError as e:
        console.print(f"[red]API error {e.response.status_code}:[/red] {e.response.text[:200]}")
        sys.exit(1)
    except httpx.RequestError as e:
        console.print(f"[red]Connection error:[/red] {e}")
        sys.exit(1)


# ── Agents ────────────────────────────────────────────────────────────────────

def list_agents() -> list[dict]:
    return _get("/api/v1/agents/")


def get_agent(agent_id: str) -> dict:
    return _get(f"/api/v1/agents/{agent_id}/")


def get_agent_logs(agent_id: str, source: str = "", limit: int = 50) -> list[dict]:
    params = {"source": source, "limit": limit} if source else {"limit": limit}
    return _get(f"/api/v1/agents/{agent_id}/logs", params=params)


def get_agent_anomalies(agent_id: str, limit: int = 20) -> list[dict]:
    return _get(f"/api/v1/agents/{agent_id}/anomalies", params={"limit": limit})


def get_agent_processes(agent_id: str) -> list[dict]:
    return _get(f"/api/v1/agents/{agent_id}/processes")


def get_agent_connections(agent_id: str) -> list[dict]:
    return _get(f"/api/v1/agents/{agent_id}/connections")


def get_agent_metrics(agent_id: str) -> dict:
    return _get(f"/api/v1/agents/{agent_id}/metrics")


def get_agent_vulns(agent_id: str) -> list[dict]:
    return _get(f"/api/v1/agents/{agent_id}/vulns")


def send_command(agent_id: str, command_type: str, payload: dict = {}) -> dict:
    # Backend expects {"command": "...", "params": {...}} — not {"type":..., "payload":...}
    return _post(f"/api/v1/agents/{agent_id}/command",
                 {"command": command_type, "params": payload or None})


def isolate_agent(agent_id: str) -> dict:
    return _post(f"/api/v1/agents/{agent_id}/isolate", {})


def unisolate_agent(agent_id: str) -> dict:
    return _post(f"/api/v1/agents/{agent_id}/unisolate", {})


def block_ip(ip: str, agent_id: Optional[str] = None) -> dict:
    payload: dict = {"ip": ip}
    if agent_id:
        payload["agent_id"] = agent_id
    return _post("/api/v1/agents/broadcast",
                 {"command": "block_ip", "params": payload})


def run_command(agent_id: str, command: str) -> dict:
    return _post(f"/api/v1/agents/{agent_id}/command",
                 {"command": "run_script", "params": {"command": command}})


def trigger_scan(agent_id: str) -> dict:
    return _post(f"/api/v1/agents/{agent_id}/command",
                 {"command": "fast_scan", "params": {}})


# ── Orchestration ──────────────────────────────────────────────────────────────

def generate_key(label: str = "") -> dict:
    payload = {"label": label} if label else {}
    return _post("/api/v1/agents/generate-key", payload)


def spawn_agent(agent_id: str, config: dict = {}) -> dict:
    return _post(f"/api/v1/agents/{agent_id}/spawn", config)


def get_sub_agents(agent_id: str) -> list[dict]:
    return _get(f"/api/v1/agents/{agent_id}/sub-agents")


def mesh_cmd(agent_id: str, command: str, targets: list[str] = []) -> dict:
    return _post(f"/api/v1/agents/{agent_id}/mesh-cmd",
                 {"command": command, "targets": targets})


def broadcast_command(command: str) -> dict:
    return _post("/api/v1/agents/broadcast",
                 {"type": "run_script", "payload": {"command": command}})


def deregister_agent(agent_id: str) -> dict:
    url = f"{_base()}/api/v1/agents/{agent_id}"
    try:
        with httpx.Client(timeout=10) as c:
            r = c.delete(url, headers=_headers())
        if r.status_code == 401:
            console.print("[red]Session expired.[/red] Run [bold]pivotra login[/bold].")
            sys.exit(1)
        r.raise_for_status()
        return r.json() if r.content else {"status": "deleted"}
    except httpx.HTTPStatusError as e:
        raise APIError(e.response.status_code, e.response.text[:200])
    except httpx.RequestError as e:
        raise APIError(0, str(e))


def restart_agent(agent_id: str) -> dict:
    return _post(f"/api/v1/agents/{agent_id}/restart", {})


def rotate_key(agent_id: str) -> dict:
    return _post(f"/api/v1/agents/{agent_id}/rotate-key", {})


# ── Alerts ────────────────────────────────────────────────────────────────────

def get_alerts(limit: int = 20) -> list[dict]:
    data = _get("/api/v1/alerts/feed", params={"limit": limit})
    if isinstance(data, list):
        return data
    return data.get("items") or data.get("alerts") or data.get("data") or []


# ── Fleet stats ───────────────────────────────────────────────────────────────

def fleet_stats() -> dict:
    return _get("/api/v1/agents/fleet/stats")


def get_agent_timeline(agent_id: str, limit: int = 30) -> list[dict]:
    data = _get(f"/api/v1/agents/{agent_id}/timeline", params={"limit": limit})
    if isinstance(data, list):
        return data
    return data.get("items") or data.get("events") or []


def list_group_agents(group_id: str) -> list[dict]:
    data = _get(f"/api/v1/groups/{group_id}/agents")
    if isinstance(data, list):
        return data
    return data.get("items") or data.get("agents") or []


def get_2fa_status() -> dict:
    return _get("/api/v1/auth/2fa/status")


def export_resource(resource: str, fmt: str = "json", limit: int = 100,
                    agent_id: Optional[str] = None) -> list[dict]:
    endpoint_map = {
        "agents":    ("/api/v1/agents/", {}),
        "alerts":    ("/api/v1/alerts/", {"limit": limit}),
        "anomalies": ("/api/v1/anomalies/", {"limit": limit}),
        "iocs":      ("/api/v1/intel/iocs", {"limit": limit}),
        "audit":     ("/api/v1/audit/", {"limit": limit}),
    }
    results = {}
    if resource == "all":
        for name, (path, params) in endpoint_map.items():
            try:
                data = _get(path, params=params)
                results[name] = data if isinstance(data, list) else (data.get("items") or data.get("data") or [data])
            except Exception:
                results[name] = []
        return results  # type: ignore
    path, params = endpoint_map.get(resource, (f"/api/v1/{resource}/", {"limit": limit}))
    if agent_id:
        params["agent_id"] = agent_id
    data = _get(path, params=params)
    if isinstance(data, list):
        return data
    return data.get("items") or data.get("data") or []


# ── Infra ops (file, docker, psql) ────────────────────────────────────────────

def file_read(agent_id: str, path: str) -> str:
    result = run_command(agent_id, f"cat {path}")
    return result.get("output") or result.get("result") or ""


def file_list(agent_id: str, path: str) -> str:
    result = run_command(agent_id, f"ls -la {path}")
    return result.get("output") or result.get("result") or ""


def file_write(agent_id: str, path: str, content: str) -> dict:
    import shlex
    safe_content = content.replace("'", "'\\''")
    cmd = f"cat > {shlex.quote(path)} << 'PIVOTRA_EOF'\n{safe_content}\nPIVOTRA_EOF"
    return run_command(agent_id, cmd)


def docker_cmd(agent_id: str, subcmd: str) -> str:
    result = run_command(agent_id, f"docker {subcmd}")
    return result.get("output") or result.get("result") or ""


def psql_query(agent_id: str, sql: str, dbname: str = "") -> str:
    db_flag = f"-d {dbname}" if dbname else ""
    result = run_command(agent_id, f'psql {db_flag} -c "{sql}"')
    return result.get("output") or result.get("result") or ""


# ── Forensics & Hunt ──────────────────────────────────────────────────────────

def run_hunt(query: str) -> dict:
    return _post("/api/v1/hunt/run-adhoc", {"query": query})


def get_hunt_jobs() -> list[dict]:
    return _get("/api/v1/hunt/jobs")


def get_hunt_results(job_id: str) -> dict:
    return _get(f"/api/v1/hunt/jobs/{job_id}")


def get_hunt_artifacts() -> list[dict]:
    return _get("/api/v1/hunt/artifacts")


# ── Investigations ─────────────────────────────────────────────────────────────

def list_investigations(limit: int = 20) -> list[dict]:
    data = _get("/api/v1/investigations/", params={"limit": limit})
    if isinstance(data, list):
        return data
    return data.get("items") or data.get("data") or []


def get_investigation(case_id: str) -> dict:
    return _get(f"/api/v1/investigations/{case_id}")


def trigger_investigation(anomaly_id: str) -> dict:
    return _post("/api/v1/investigations/trigger", {"anomaly_id": anomaly_id})


# ── IOCs ───────────────────────────────────────────────────────────────────────

def lookup_ioc(value: str) -> dict:
    return _get("/api/v1/intel/lookup", params={"q": value})


def list_iocs(limit: int = 20) -> list[dict]:
    data = _get("/api/v1/intel/iocs", params={"limit": limit})
    if isinstance(data, list):
        return data
    return data.get("items") or data.get("data") or []


def add_ioc(ioc_type: str, value: str, severity: str = "medium") -> dict:
    return _post("/api/v1/intel/iocs", {
        "type": ioc_type, "value": value, "severity": severity
    })


# ── IP Reputation ──────────────────────────────────────────────────────────────

def check_ip(ip: str) -> dict:
    return _get(f"/api/v1/ip-reputation/check/{ip}")


# ── Reports ────────────────────────────────────────────────────────────────────

def generate_report(days: int = 7) -> dict:
    return _post("/api/v1/reports/generate", {"days": days})


def list_reports() -> list[dict]:
    data = _get("/api/v1/reports/runs")
    if isinstance(data, list):
        return data
    return data.get("items") or data.get("data") or []


def download_report(run_id: str, fmt: str = "pdf") -> bytes:
    url = f"{_base()}/api/v1/reports/runs/{run_id}/export-{fmt}"
    try:
        with httpx.Client(timeout=60) as c:
            r = c.get(url, headers=_headers())
        r.raise_for_status()
        return r.content
    except httpx.HTTPStatusError as e:
        raise APIError(e.response.status_code, e.response.text[:200])
    except httpx.RequestError as e:
        raise APIError(0, str(e))


# ── MITRE ATT&CK ──────────────────────────────────────────────────────────────

def get_mitre_coverage() -> dict:
    return _get("/api/v1/mitre/coverage")


def get_mitre_stats() -> dict:
    return _get("/api/v1/mitre/stats")


# ── EDR ────────────────────────────────────────────────────────────────────────

def get_edr_events(agent_id: Optional[str] = None, limit: int = 20) -> list[dict]:
    params: dict = {"limit": limit}
    if agent_id:
        params["agent_id"] = agent_id
    data = _get("/api/v1/edr/events", params=params)
    if isinstance(data, list):
        return data
    return data.get("items") or data.get("data") or []


def mitigate_edr_event(event_id: str) -> dict:
    url = f"{_base()}/api/v1/edr/events/{event_id}/mitigate"
    try:
        with httpx.Client(timeout=10) as c:
            r = c.patch(url, headers=_headers(), json={})
        r.raise_for_status()
        return r.json()
    except httpx.HTTPStatusError as e:
        raise APIError(e.response.status_code, e.response.text[:200])
    except httpx.RequestError as e:
        raise APIError(0, str(e))


# ── Playbooks ─────────────────────────────────────────────────────────────────

def list_playbooks() -> list[dict]:
    data = _get("/api/v1/playbooks/")
    if isinstance(data, list):
        return data
    return data.get("items") or data.get("data") or []


def get_playbook_flow(playbook_id: str) -> dict:
    return _get(f"/api/v1/playbooks/{playbook_id}/flow")


def run_playbook(playbook_id: str, target: str = "", dry_run: bool = False) -> dict:
    return _post(f"/api/v1/playbooks/{playbook_id}/run-flow",
                 {"target": target, "dry_run": dry_run})


def get_playbook_log(action_id: str) -> dict:
    return _get(f"/api/v1/playbooks/{action_id}/execution-log")


def get_external_runs(limit: int = 20) -> list[dict]:
    data = _get("/api/v1/playbooks/external-executions", params={"limit": limit})
    if isinstance(data, list):
        return data
    return data.get("items") or data.get("data") or []


def trigger_external_playbook(action_type: str, target: str,
                               reason: str = "", token: str = "") -> dict:
    import httpx as _httpx
    url = f"{_base()}/api/v1/playbooks/webhook-trigger"
    headers = {"X-Webhook-Token": token} if token else {}
    try:
        with _httpx.Client(timeout=15) as c:
            r = c.post(url, headers={**_headers(), **headers},
                       json={"action_type": action_type, "target": target, "reason": reason})
        r.raise_for_status()
        return r.json()
    except _httpx.HTTPStatusError as e:
        raise APIError(e.response.status_code, e.response.text[:200])
    except _httpx.RequestError as e:
        raise APIError(0, str(e))


# ── Response Queue ─────────────────────────────────────────────────────────────

def get_response_queue() -> list[dict]:
    data = _get("/api/v1/response/queue")
    if isinstance(data, list):
        return data
    return data.get("items") or data.get("data") or []


def approve_action(action_id: str) -> dict:
    return _post(f"/api/v1/response/{action_id}/approve", {})


def reject_action(action_id: str) -> dict:
    return _post(f"/api/v1/response/{action_id}/reject", {})


def get_response_stats() -> dict:
    return _get("/api/v1/response/stats")


# ── Agent Groups ───────────────────────────────────────────────────────────────

def list_groups() -> list[dict]:
    data = _get("/api/v1/groups")
    if isinstance(data, list):
        return data
    return data.get("items") or data.get("data") or []


def create_group(name: str, description: str = "") -> dict:
    return _post("/api/v1/agent-groups/", {"name": name, "description": description})


def assign_to_group(group_id: str, agent_ids: list[str]) -> dict:
    return _post(f"/api/v1/agent-groups/{group_id}/assign", {"agent_ids": agent_ids})


# ── Audit ─────────────────────────────────────────────────────────────────────

def get_audit_logs(limit: int = 20) -> list[dict]:
    data = _get("/api/v1/audit/logs", params={"limit": limit})
    if isinstance(data, list):
        return data
    return data.get("items") or data.get("data") or []


# ── Users & Invitations ────────────────────────────────────────────────────────

def list_users() -> list[dict]:
    data = _get("/api/v1/auth/users")
    if isinstance(data, list):
        return data
    return data.get("items") or data.get("data") or []


def invite_user(email: str, role: str = "analyst") -> dict:
    return _post("/api/v1/invitations/send", {"email": email, "role": role})


# ── Jobs ───────────────────────────────────────────────────────────────────────

def list_jobs() -> list[dict]:
    data = _get("/api/v1/jobs/")
    if isinstance(data, list):
        return data
    return data.get("items") or data.get("data") or []


# ── Dashboard ─────────────────────────────────────────────────────────────────

def get_dashboard() -> dict:
    return _get("/api/v1/dashboard")


# ── Personal API tokens ───────────────────────────────────────────────────────

def list_tokens() -> list[dict]:
    return _get("/api/v1/tokens") or []

def create_token(name: str, expires_days: Optional[int] = None) -> dict:
    body: dict = {"name": name}
    if expires_days:
        body["expires_days"] = expires_days
    return _post("/api/v1/tokens", body)

def revoke_token(token_id: int) -> dict:
    return _delete(f"/api/v1/tokens/{token_id}")


# ── BRO Chat stream (SSE) ─────────────────────────────────────────────────────

def bro_stream(messages: list[dict], context: dict) -> httpx.Response:
    """Returns a streaming response for BRO chat."""
    url = f"{_base()}/api/v1/cli/bro/stream"
    return httpx.stream(
        "POST", url,
        headers={**_headers(), "Accept": "text/event-stream"},
        json={"messages": messages, "context": context},
        timeout=120,
    )
