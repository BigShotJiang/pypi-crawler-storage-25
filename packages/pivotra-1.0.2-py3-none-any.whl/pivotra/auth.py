"""
Auth module — login flow + token storage.
Mirrors the backend WIK-228 browser auth flow:
  1. POST /api/v1/cli/auth-request → state token
  2. Open browser → user logs in on dashboard
  3. Poll /api/v1/cli/auth-poll?state=... until JWT arrives
  4. Store JWT in ~/.pivotra/config.json
"""
from __future__ import annotations

import json
import os
import sys
import time
import webbrowser
from pathlib import Path
from typing import Optional

import httpx
from rich.console import Console

console = Console()

_CONFIG_DIR  = Path.home() / ".pivotra"
_CONFIG_FILE = _CONFIG_DIR / "config.json"
_POLL_INTERVAL = 2   # seconds
_POLL_TIMEOUT  = 300 # 5 min


def _load_config() -> dict:
    if _CONFIG_FILE.exists():
        try:
            return json.loads(_CONFIG_FILE.read_text())
        except Exception:
            pass
    return {}


def _save_config(data: dict) -> None:
    _CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    _CONFIG_FILE.write_text(json.dumps(data, indent=2))
    _CONFIG_FILE.chmod(0o600)


def get_token() -> Optional[str]:
    env = os.environ.get("PIVOTRA_TOKEN")
    if env:
        return env
    return _load_config().get("token")


def set_api_token(pvt_token: str, base_url: Optional[str] = None) -> None:
    """Store a personal API token (pvt_xxx) as the active credential."""
    if not pvt_token.startswith("pvt_"):
        console.print("[red]Invalid token.[/red] Personal API tokens must start with [bold]pvt_[/bold]")
        sys.exit(1)
    cfg = _load_config()
    cfg["token"] = pvt_token
    if base_url:
        cfg["base_url"] = base_url
    elif "base_url" not in cfg:
        cfg["base_url"] = "https://demo.pivotraai.ai"
    _save_config(cfg)
    console.print(f"[bold green]Token stored.[/bold green] Saved in [dim]{_CONFIG_FILE}[/dim]")
    console.print("[dim]Revoke: [bold]pivotra token revoke <id>[/bold]  ·  Clear local: [bold]pivotra logout[/bold][/dim]")


def get_base_url() -> str:
    return _load_config().get("base_url", "https://demo.pivotraai.ai")


def get_kymns_url() -> str:
    return _load_config().get("kymns_url", "https://api.kymnscorp.com/v1")


def require_token() -> str:
    token = get_token()
    if not token:
        console.print("[red]Not logged in.[/red] Run [bold]pivotra login[/bold] first.")
        sys.exit(1)
    return token


def login(base_url: str = "https://demo.pivotraai.ai") -> None:
    """Full browser auth flow."""
    console.print(f"\n[bold cyan]Pivotra CLI[/bold cyan] — authenticating against [dim]{base_url}[/dim]\n")

    _UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36 PivotraCLI/1.0"
    with httpx.Client(timeout=10, follow_redirects=False, headers={"User-Agent": _UA}) as c:
        try:
            r = c.post(f"{base_url}/api/v1/cli/auth-request")
            # 302 → Cloudflare Access is blocking this path
            if r.status_code in (302, 301):
                cf_url = r.headers.get("location", "")
                if "cloudflareaccess.com" in cf_url or "cdn-cgi/access" in cf_url:
                    console.print(
                        "[red]Blocked by Cloudflare Access.[/red]\n\n"
                        "Fix: In Cloudflare Zero Trust → Access → Applications → monitor.kymnscorp.com\n"
                        "     Add a [bold]Bypass[/bold] policy for path [cyan]/api/v1/cli/*[/cyan]\n\n"
                        "[dim]These endpoints are already protected by Pivotra JWT — "
                        "CF Access is not needed here.[/dim]"
                    )
                    sys.exit(1)
            r.raise_for_status()
        except httpx.HTTPStatusError as e:
            console.print(f"[red]Cannot reach {base_url}:[/red] {e}")
            sys.exit(1)
        except Exception as e:
            console.print(f"[red]Cannot reach {base_url}:[/red] {e}")
            sys.exit(1)

    state = r.json()["state"]
    auth_url = f"{base_url}/cli-auth?state={state}"

    console.print(f"Opening browser for authentication...\n→ [link]{auth_url}[/link]\n")
    webbrowser.open(auth_url)

    # Poll until JWT arrives
    elapsed = 0
    with console.status("[bold green]Waiting for browser confirmation...[/bold green]") as status:
        while elapsed < _POLL_TIMEOUT:
            time.sleep(_POLL_INTERVAL)
            elapsed += _POLL_INTERVAL
            try:
                with httpx.Client(timeout=5) as c:
                    r = c.get(f"{base_url}/api/v1/cli/auth-poll", params={"state": state})
                if r.status_code == 404:
                    console.print("[red]Auth session expired.[/red]")
                    sys.exit(1)
                data = r.json()
                if data.get("status") == "ok":
                    token = data["token"]
                    break
                status.update(f"[bold green]Waiting... ({elapsed}s)[/bold green]")
            except Exception:
                pass
        else:
            console.print("[red]Timed out waiting for browser confirmation.[/red]")
            sys.exit(1)

    _save_config({"token": token, "base_url": base_url})
    console.print(f"\n[bold green]Authenticated.[/bold green] Token stored in [dim]{_CONFIG_FILE}[/dim]")


def logout() -> None:
    if _CONFIG_FILE.exists():
        _CONFIG_FILE.unlink()
        console.print("[dim]Logged out. Token removed.[/dim]")
    else:
        console.print("[dim]Not logged in.[/dim]")


def whoami() -> None:
    cfg = _load_config()
    token = cfg.get("token")
    base_url = cfg.get("base_url", "https://monitor.kymnscorp.com")
    if not token:
        console.print("[dim]Not logged in.[/dim]")
        return
    try:
        with httpx.Client(timeout=5) as c:
            r = c.get(f"{base_url}/api/v1/auth/me",
                      headers={"Authorization": f"Bearer {token}"})
        if r.status_code == 200:
            u = r.json()
            console.print(f"[bold]{u.get('email', '?')}[/bold] "
                          f"[dim]{u.get('role', '')}[/dim] @ [dim]{base_url}[/dim]")
        else:
            console.print("[yellow]Token may be expired. Run [bold]pivotra login[/bold] again.[/yellow]")
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
