"""
BRO REPL — interactive conversational AI session.
Uses Prompt Toolkit for input (history, arrow keys)
and Rich Live for streaming token display.
"""
from __future__ import annotations

import json
import re
import sys
from typing import Optional

import httpx
from prompt_toolkit import PromptSession
from prompt_toolkit.history import InMemoryHistory
from prompt_toolkit.styles import Style
from rich.console import Console
from rich.live import Live
from rich.markdown import Markdown
from rich.panel import Panel
from rich.spinner import Spinner
from rich.text import Text

from . import api_client as api
from .auth import get_base_url, require_token
from .context import build_fleet_context, context_to_system_prompt
from .display import bro_header, print_action_prompt

console = Console()

# Prompt Toolkit style
_PT_STYLE = Style.from_dict({
    "prompt": "bold magenta",
})

_ACTION_RE = re.compile(r"^ACTION:\s*(.+)$", re.MULTILINE)


def _execute_action(action_str: str) -> None:
    """Parse and execute a confirmed action."""
    parts = action_str.strip().split(maxsplit=1)
    if not parts:
        return
    verb = parts[0].lower()
    rest = parts[1] if len(parts) > 1 else ""

    try:
        if verb == "isolate":
            result = api.isolate_agent(rest.strip())
            console.print(f"[green]  Isolated {rest.strip()}[/green]")
        elif verb == "unisolate":
            result = api.unisolate_agent(rest.strip())
            console.print(f"[green]  Unisolated {rest.strip()}[/green]")
        elif verb == "block_ip":
            ip = rest.strip()
            result = api.block_ip(ip)
            console.print(f"[green]  Blocked IP {ip}[/green]")
        elif verb == "scan":
            result = api.trigger_scan(rest.strip())
            console.print(f"[green]  Scan triggered on {rest.strip()}[/green]")
        elif verb == "run_command":
            sub = rest.split(maxsplit=1)
            if len(sub) == 2:
                agent_id, command = sub
                result = api.run_command(agent_id, command)
                output = result.get("output") or result.get("result") or "Command sent."
                console.print(f"[cyan]{output}[/cyan]")
            else:
                console.print("[red]  run_command requires: <agent_id> <command>[/red]")
        elif verb == "spawn":
            result = api.spawn_agent(rest.strip())
            sub_id = result.get("id") or result.get("agent_id") or "?"
            console.print(f"[green]  Sub-agent spawned: {sub_id}[/green]")
        elif verb == "restart":
            api.restart_agent(rest.strip())
            console.print(f"[green]  Restart triggered on {rest.strip()}[/green]")
        elif verb == "deregister":
            api.deregister_agent(rest.strip())
            console.print(f"[green]  Agent {rest.strip()} deregistered[/green]")
        elif verb == "broadcast":
            api.broadcast_command(rest.strip())
            console.print(f"[green]  Broadcast sent[/green]")
        elif verb == "rotate_key":
            result = api.rotate_key(rest.strip())
            new_key = result.get("api_key") or result.get("key") or "?"
            console.print(f"[green]  Key rotated. New key: [yellow]{new_key}[/yellow][/green]")
        elif verb == "deploy":
            parts_d = rest.split()
            dep_host = parts_d[0] if parts_d else "?"
            dep_user = parts_d[1] if len(parts_d) > 1 else "root"
            dep_key  = parts_d[2] if len(parts_d) > 2 else ""
            console.print(f"[yellow]  To deploy agent on {dep_host}, run:[/yellow]")
            console.print(f"  [bold]pivotra deploy {dep_host} --user {dep_user}" +
                           (f" --key {dep_key}" if dep_key else "") + "[/bold]")
        # ── Infra operations ──────────────────────────────────────────────────
        elif verb == "file_read":
            parts_fr = rest.split(maxsplit=1)
            if len(parts_fr) == 2:
                content = api.file_read(parts_fr[0], parts_fr[1])
                console.print(content or "[dim](empty)[/dim]")
            else:
                console.print("[red]  file_read requires: <agent_id> <path>[/red]")
        elif verb == "file_write":
            parts_fw = rest.split(maxsplit=2)
            if len(parts_fw) == 3:
                api.file_write(parts_fw[0], parts_fw[1], parts_fw[2])
                console.print(f"[green]  Written to {parts_fw[1]}[/green]")
            else:
                console.print("[red]  file_write requires: <agent_id> <path> <content>[/red]")
        elif verb == "docker_exec":
            parts_de = rest.split(maxsplit=2)
            if len(parts_de) == 3:
                out = api.docker_cmd(parts_de[0], f"exec {parts_de[1]} {parts_de[2]}")
                console.print(out)
            else:
                console.print("[red]  docker_exec requires: <agent_id> <container> <cmd>[/red]")
        elif verb == "docker_logs":
            parts_dl = rest.split(maxsplit=1)
            if len(parts_dl) == 2:
                out = api.docker_cmd(parts_dl[0], f"logs --tail 50 {parts_dl[1]}")
                console.print(out)
            else:
                console.print("[red]  docker_logs requires: <agent_id> <container>[/red]")
        elif verb == "docker_ps":
            out = api.docker_cmd(rest.strip(), "ps")
            console.print(out)
        elif verb == "psql_query":
            parts_pq = rest.split(maxsplit=1)
            if len(parts_pq) == 2:
                out = api.psql_query(parts_pq[0], parts_pq[1])
                console.print(out)
            else:
                console.print("[red]  psql_query requires: <agent_id> <sql>[/red]")
        # ── Forensics & Intelligence ──────────────────────────────────────────
        elif verb == "hunt":
            result = api.run_hunt(rest.strip())
            job_id = result.get("job_id") or result.get("id") or "?"
            console.print(f"[green]  Hunt started. Job ID: [cyan]{job_id}[/cyan][/green]")
            console.print(f"  [dim]pivotra hunt results {job_id}[/dim]")
        elif verb == "investigate":
            result = api.trigger_investigation(rest.strip())
            case_id = result.get("id") or result.get("case_id") or "?"
            console.print(f"[green]  Investigation opened: {case_id}[/green]")
        elif verb == "ioc_add":
            parts_ioc = rest.split(maxsplit=1)
            if len(parts_ioc) == 2:
                result = api.add_ioc(parts_ioc[0], parts_ioc[1])
                console.print(f"[green]  IOC added: {result.get('id') or '?'}[/green]")
            else:
                console.print("[red]  ioc_add requires: <type> <value>[/red]")
        elif verb == "ip_check":
            result = api.check_ip(rest.strip())
            score = result.get("score") or result.get("risk_score") or "?"
            verdict = result.get("verdict") or result.get("category") or "unknown"
            console.print(f"[cyan]  IP {rest.strip()}[/cyan] — Score: [red]{score}[/red] — {verdict}")
        # ── Playbooks & Queue ─────────────────────────────────────────────────
        elif verb == "playbook":
            parts_pb = rest.split(maxsplit=1)
            pb_id = parts_pb[0]
            pb_target = parts_pb[1] if len(parts_pb) > 1 else ""
            result = api.run_playbook(pb_id, pb_target)
            log_id = result.get("log_id") or result.get("id") or "?"
            console.print(f"[green]  Playbook triggered. Log: {log_id}[/green]")
        elif verb == "queue_approve":
            api.approve_action(rest.strip())
            console.print(f"[green]  Action {rest.strip()} approved.[/green]")
        elif verb == "queue_reject":
            api.reject_action(rest.strip())
            console.print(f"[dim]  Action {rest.strip()} rejected.[/dim]")
        elif verb == "report":
            result = api.generate_report()
            run_id = result.get("run_id") or result.get("id") or "?"
            console.print(f"[green]  Report generated. Run ID: {run_id}[/green]")
        elif verb == "logs":
            # ACTION: logs <agent_id> [limit]
            sub = rest.strip().split()
            a_id = sub[0] if sub else ""
            limit = int(sub[1]) if len(sub) > 1 and sub[1].isdigit() else 20
            if a_id:
                lines = api.get_agent_logs(a_id, limit=limit)
                for ln in lines[-limit:]:
                    ts = ln.get("timestamp", "")[:19]
                    src = ln.get("source") or ln.get("type") or ""
                    msg = ln.get("line") or ln.get("message") or str(ln)
                    console.print(f"[dim]{ts}[/dim] [[cyan]{src}[/cyan]] {msg}")
            else:
                console.print("[red]  logs requires: <agent_id> [limit][/red]")
        elif verb == "anomalies":
            # ACTION: anomalies <agent_id> [limit]
            sub = rest.strip().split()
            a_id = sub[0] if sub else ""
            limit = int(sub[1]) if len(sub) > 1 and sub[1].isdigit() else 10
            if a_id:
                items = api.get_agent_anomalies(a_id, limit=limit)
                if not items:
                    console.print("[dim]  No anomalies found.[/dim]")
                for an in items:
                    sev = (an.get("severity") or "?").upper()
                    col = "red" if sev == "CRITICAL" else "yellow" if sev == "HIGH" else "cyan"
                    msg = an.get("details") or an.get("description") or an.get("type") or str(an)
                    console.print(f"[[{col}]{sev}[/{col}]] {msg[:120]}")
            else:
                console.print("[red]  anomalies requires: <agent_id> [limit][/red]")
        else:
            console.print(f"[dim]  Unknown action: {verb}[/dim]")
    except Exception as e:
        console.print(f"[red]  Action failed:[/red] {e}")


def _stream_bro_response(messages: list[dict], system_prompt: str) -> str:
    """
    Stream BRO response from backend SSE endpoint.
    Returns the full response text.
    """
    token = require_token()
    base  = get_base_url()
    url   = f"{base}/api/v1/cli/bro/stream"

    full_text = ""

    try:
        _UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36 PivotraCLI/1.0"
        with httpx.Client(timeout=120) as client:
            with client.stream(
                "POST", url,
                headers={
                    "Authorization": f"Bearer {token}",
                    "Accept": "text/event-stream",
                    "Content-Type": "application/json",
                    "User-Agent": _UA,
                },
                json={"messages": messages, "system": system_prompt},
            ) as response:
                if response.status_code == 401:
                    console.print("[red]Session expired.[/red] Run [bold]pivotra login[/bold].")
                    sys.exit(1)
                if response.status_code != 200:
                    body = response.read().decode()
                    console.print(f"[red]BRO error {response.status_code}:[/red] {body[:200]}")
                    return ""

                buf = ""
                _thinking = Panel(
                    Spinner("dots", text=" BRO is thinking..."),
                    border_style="magenta",
                    title="[bold magenta]◈ BRO[/bold magenta]",
                    padding=(0, 1),
                )
                with Live(_thinking, console=console, refresh_per_second=15) as live:
                    for line in response.iter_lines():
                        if not line.startswith("data: "):
                            continue
                        data = line[6:]
                        if data == "[DONE]":
                            break
                        try:
                            chunk = json.loads(data)
                            token_text = chunk.get("content", "")
                            if token_text:
                                buf += token_text
                                full_text += token_text
                                live.update(
                                    Panel(
                                        Markdown(buf),
                                        border_style="magenta",
                                        title="[bold magenta]◈ BRO[/bold magenta]",
                                        padding=(0, 1),
                                    )
                                )
                        except json.JSONDecodeError:
                            pass

    except httpx.RequestError as e:
        console.print(f"[red]Connection error:[/red] {e}")
        return ""

    return full_text


def _handle_actions(response_text: str) -> None:
    """Find ACTION: lines in BRO response and prompt for confirmation."""
    actions = _ACTION_RE.findall(response_text)
    for action in actions:
        if print_action_prompt(action):
            _execute_action(action)
        else:
            console.print("[dim]  Skipped.[/dim]")


def run_repl(agent_id: Optional[str] = None) -> None:
    """Launch the interactive BRO REPL."""
    # Build initial fleet context
    console.print("\n[dim]Loading fleet context...[/dim]")
    try:
        context = build_fleet_context(agent_id)
    except Exception:
        context = {}
        console.print("[yellow]Warning: could not load fleet context (offline?)[/yellow]")

    system_prompt = context_to_system_prompt(context)

    bro_header(
        online_count=context.get("agents_online", 0),
        total=context.get("agents_total", 0),
        anomaly_count=context.get("recent_alerts_count", 0),
    )

    if agent_id:
        console.print(f"[dim]Context: agent [cyan]{agent_id}[/cyan] selected.[/dim]\n")

    # Conversation history (in-session)
    messages: list[dict] = []
    session = PromptSession(history=InMemoryHistory(), style=_PT_STYLE)

    while True:
        try:
            user_input = session.prompt("\n bro › ", style=_PT_STYLE).strip()
        except (KeyboardInterrupt, EOFError):
            console.print("\n[dim]Bye.[/dim]")
            break

        if not user_input:
            continue
        if user_input.lower() in ("exit", "quit", "bye", "q"):
            console.print("[dim]Bye.[/dim]")
            break
        if user_input.lower() == "clear":
            console.clear()
            bro_header(
                online_count=context.get("agents_online", 0),
                total=context.get("agents_total", 0),
                anomaly_count=context.get("recent_alerts_count", 0),
            )
            messages = []
            continue
        if user_input.lower() == "context":
            console.print(Panel(system_prompt[:1200] + "...", title="[dim]System context[/dim]"))
            continue
        if user_input.lower().startswith("agent "):
            # switch context to a different agent mid-session
            new_id = user_input.split(maxsplit=1)[1].strip()
            console.print(f"[dim]Switching context to agent [cyan]{new_id}[/cyan]...[/dim]")
            context = build_fleet_context(new_id)
            system_prompt = context_to_system_prompt(context)
            agent_id = new_id
            console.print(f"[green]Context updated.[/green]")
            continue

        messages.append({"role": "user", "content": user_input})
        console.print()

        response_text = _stream_bro_response(messages, system_prompt)

        if response_text:
            messages.append({"role": "assistant", "content": response_text})
            _handle_actions(response_text)


def ask_once(question: str, agent_id: Optional[str] = None, quiet: bool = False) -> None:
    """Single non-interactive question to BRO."""
    if not quiet:
        console.print("\n[dim]Loading fleet context...[/dim]")
    try:
        context = build_fleet_context(agent_id)
    except Exception:
        context = {}

    system_prompt = context_to_system_prompt(context)
    messages = [{"role": "user", "content": question}]

    if quiet:
        # Plain text output — stream directly to stdout
        from .auth import get_base_url, require_token
        import httpx, sys
        token = require_token()
        base = get_base_url()
        url = f"{base}/api/v1/cli/bro/stream"
        payload = {"messages": messages, "system": system_prompt}
        with httpx.Client(timeout=120) as c:
            with c.stream("POST", url, json=payload,
                          headers={"Authorization": f"Bearer {token}"}) as r:
                for line in r.iter_lines():
                    if line.startswith("data:"):
                        chunk = line[5:].strip()
                        if chunk and chunk != "[DONE]":
                            sys.stdout.write(chunk)
                            sys.stdout.flush()
        sys.stdout.write("\n")
        return

    console.print()
    response_text = _stream_bro_response(messages, system_prompt)

    if response_text:
        _handle_actions(response_text)
