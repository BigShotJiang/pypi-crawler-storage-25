"""
Pivotra CLI — main entry point.
Usage: pivotra <command> [options]
"""
from __future__ import annotations

from typing import Optional

import typer
from rich.console import Console

from . import __version__

app = console_app = typer.Typer(
    name="pivotra",
    help="[bold cyan]Pivotra AI Platform CLI[/bold cyan] — Fleet management + BRO AI",
    rich_markup_mode="rich",
    no_args_is_help=True,
    add_completion=True,
)

console = Console()

# ── Auth ──────────────────────────────────────────────────────────────────────

@app.command()
def login(
    url: str = typer.Option(
        "https://demo.pivotraai.ai",
        "--url", "-u",
        help="Pivotra dashboard URL",
    )
):
    """Authenticate via browser (opens dashboard login page)."""
    from .auth import login as _login
    _login(base_url=url)


@app.command()
def logout():
    """Remove stored credentials."""
    from .auth import logout as _logout
    _logout()


@app.command()
def whoami():
    """Show current authenticated user."""
    from .auth import whoami as _whoami
    _whoami()


# ── Fleet overview ────────────────────────────────────────────────────────────

@app.command()
def status(
    json_out: bool = typer.Option(False, "--json", help="Output raw JSON"),
):
    """Show all agents (online/offline) with fleet overview."""
    from . import api_client as api
    from .display import agent_table

    try:
        agents = api.list_agents()
    except api.APIError as e:
        console.print(f"[red]API error {e.status_code}:[/red] {e.message}")
        raise typer.Exit(1)
    if json_out:
        import json; console.print_json(json.dumps(agents))
    else:
        agent_table(agents)
        online = sum(1 for a in agents if a.get("online") or a.get("status") == "online")
        console.print(f"[dim]{online}/{len(agents)} online[/dim]")


@app.command()
def agents(
    agent_id: Optional[str] = typer.Argument(None, help="Agent ID for detail view"),
    json_out: bool = typer.Option(False, "--json"),
):
    """Show agent details. Without ID, lists all agents."""
    from . import api_client as api
    from .display import agent_table, agent_detail

    if agent_id:
        a = api.get_agent(agent_id)
        if json_out:
            import json; console.print_json(json.dumps(a))
        else:
            agent_detail(a)
    else:
        status(json_out=json_out)


# ── Agent actions ─────────────────────────────────────────────────────────────

@app.command()
def run(
    agent_id: str = typer.Argument(..., help="Agent ID"),
    command: str = typer.Argument(..., help="Shell command to run"),
):
    """Execute a shell command on an agent."""
    from . import api_client as api
    with console.status(f"[cyan]Running on {agent_id}...[/cyan]"):
        result = api.run_command(agent_id, command)
    output = result.get("output") or result.get("result") or result
    console.print(output)


@app.command()
def scan(agent_id: str = typer.Argument(..., help="Agent ID")):
    """Trigger a security scan on an agent."""
    from . import api_client as api
    with console.status(f"[cyan]Triggering scan on {agent_id}...[/cyan]"):
        result = api.trigger_scan(agent_id)
    console.print(f"[green]Scan triggered.[/green] {result}")


@app.command()
def isolate(
    agent_id: str = typer.Argument(..., help="Agent ID"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
):
    """Network-isolate an agent (emergency response)."""
    from . import api_client as api
    if not force:
        confirm = typer.confirm(
            f"Isolate [bold red]{agent_id}[/bold red]? This cuts all network access."
        )
        if not confirm:
            console.print("[dim]Cancelled.[/dim]")
            raise typer.Exit()
    with console.status(f"[red]Isolating {agent_id}...[/red]"):
        result = api.isolate_agent(agent_id)
    console.print(f"[green]Isolated.[/green]")


@app.command()
def unisolate(agent_id: str = typer.Argument(..., help="Agent ID")):
    """Restore network access to an isolated agent."""
    from . import api_client as api
    with console.status(f"[cyan]Restoring network for {agent_id}...[/cyan]"):
        result = api.unisolate_agent(agent_id)
    console.print(f"[green]Network restored.[/green]")


@app.command()
def block(
    ip: str = typer.Argument(..., help="IP address to block"),
    agent_id: Optional[str] = typer.Option(None, "--agent", "-a", help="Target agent (default: all)"),
):
    """Block an IP address on all agents (or a specific one)."""
    from . import api_client as api
    target = agent_id or "all agents"
    confirm = typer.confirm(f"Block [red]{ip}[/red] on {target}?")
    if not confirm:
        raise typer.Exit()
    with console.status(f"[red]Blocking {ip}...[/red]"):
        result = api.block_ip(ip, agent_id)
    console.print(f"[green]Blocked.[/green]")


# ── Logs & Anomalies ──────────────────────────────────────────────────────────

@app.command()
def logs(
    agent_id: str = typer.Argument(..., help="Agent ID"),
    source: str = typer.Option("", "--source", "-s", help="Log source filter"),
    limit: int = typer.Option(50, "--limit", "-n", help="Number of lines"),
    json_out: bool = typer.Option(False, "--json"),
):
    """Show recent log lines from an agent."""
    from . import api_client as api
    from .display import logs_table

    data = api.get_agent_logs(agent_id, source=source, limit=limit)
    if json_out:
        import json; console.print_json(json.dumps(data))
    else:
        logs_table(data)


@app.command()
def anomalies(
    agent_id: str = typer.Argument(..., help="Agent ID"),
    limit: int = typer.Option(20, "--limit", "-n"),
    json_out: bool = typer.Option(False, "--json"),
):
    """Show anomalies detected on an agent."""
    from . import api_client as api
    from .display import anomalies_table

    data = api.get_agent_anomalies(agent_id, limit=limit)
    if json_out:
        import json; console.print_json(json.dumps(data))
    else:
        anomalies_table(data, agent_id)


@app.command()
def alerts(
    limit: int = typer.Option(20, "--limit", "-n"),
    json_out: bool = typer.Option(False, "--json"),
):
    """Show recent platform-wide alerts."""
    from . import api_client as api
    from .display import alerts_table

    data = api.get_alerts(limit=limit)
    if json_out:
        import json; console.print_json(json.dumps(data))
    else:
        alerts_table(data)


@app.command()
def processes(
    agent_id: str = typer.Argument(..., help="Agent ID"),
    json_out: bool = typer.Option(False, "--json"),
):
    """Show running processes on an agent."""
    from . import api_client as api
    from .display import processes_table

    data = api.get_agent_processes(agent_id)
    if json_out:
        import json; console.print_json(json.dumps(data))
    else:
        processes_table(data)


@app.command()
def connections(
    agent_id: str = typer.Argument(..., help="Agent ID"),
    json_out: bool = typer.Option(False, "--json"),
):
    """Show active network connections on an agent."""
    from . import api_client as api
    from .display import connections_table

    data = api.get_agent_connections(agent_id)
    if json_out:
        import json; console.print_json(json.dumps(data))
    else:
        connections_table(data)


@app.command()
def vulns(
    agent_id: str = typer.Argument(..., help="Agent ID"),
    json_out: bool = typer.Option(False, "--json"),
):
    """Show vulnerabilities detected on an agent."""
    from . import api_client as api

    data = api.get_agent_vulns(agent_id)
    if json_out:
        import json; console.print_json(json.dumps(data))
    else:
        from rich.table import Table
        from rich import box
        t = Table(box=box.ROUNDED, header_style="bold dim")
        t.add_column("CVE",      style="red bold")
        t.add_column("Severity", width=10)
        t.add_column("Package")
        t.add_column("Description")
        for v in data:
            sev = v.get("severity", "?").upper()
            t.add_row(
                v.get("cve_id") or "?",
                sev,
                v.get("package") or "—",
                (v.get("description") or "")[:80],
            )
        console.print(t)


# ── Orchestration ─────────────────────────────────────────────────────────────

@app.command()
def keygen(
    label: str = typer.Option("", "--label", "-l", help="Label for this key"),
):
    """Generate a new agent API key (for manual agent registration)."""
    from . import api_client as api
    with console.status("[cyan]Generating API key...[/cyan]"):
        result = api.generate_key(label)
    key = result.get("api_key") or result.get("key") or result.get("token")
    agent_id = result.get("agent_id") or result.get("id") or ""
    console.print(f"[bold green]API Key generated.[/bold green]")
    if agent_id:
        console.print(f"[dim]Agent ID:[/dim] [cyan]{agent_id}[/cyan]")
    if key:
        console.print(f"[dim]API Key:[/dim]  [bold yellow]{key}[/bold yellow]")
    console.print(f"\n[dim]Use this key when deploying an agent:[/dim]")
    console.print(f"  PIVOTRA_KEY={key} PIVOTRA_URL={_get_base_url()} ./pivotra-agent")


def _get_base_url() -> str:
    from .auth import get_base_url
    return get_base_url()


@app.command()
def deploy(
    host: str = typer.Argument(..., help="Target hostname or IP"),
    user: str = typer.Option("root", "--user", "-u", help="SSH user"),
    key_file: str = typer.Option("", "--key", "-k", help="SSH private key path"),
    label: str = typer.Option("", "--label", "-l", help="Agent label"),
    sudo_pass: str = typer.Option("", "--sudo-pass", help="Sudo password (if needed)"),
):
    """
    Deploy a new Pivotra agent to a remote host via SSH.

    Generates an API key, then runs the agent installer on the remote host.

    Examples:
      pivotra deploy 10.0.1.5
      pivotra deploy prod-web-01 --user ubuntu --key ~/.ssh/id_rsa
      pivotra deploy 192.168.1.10 --label "web-server-01"
    """
    import subprocess
    from . import api_client as api
    from .auth import get_base_url

    base_url = get_base_url()
    lbl = label or host

    console.print(f"[cyan]Deploying Pivotra agent to [bold]{host}[/bold]...[/cyan]")

    # 1. Generate API key
    with console.status("[cyan]Generating API key...[/cyan]"):
        try:
            result = api.generate_key(lbl)
        except api.APIError as e:
            console.print(f"[red]Failed to generate key:[/red] {e.message}")
            raise typer.Exit(1)

    api_key = result.get("api_key") or result.get("key") or result.get("token") or ""
    if not api_key:
        console.print(f"[red]No API key in response:[/red] {result}")
        raise typer.Exit(1)

    console.print(f"[dim]API key generated.[/dim]")

    # 2. Build install command
    install_cmd = (
        f"curl -sL {base_url}/install.sh | "
        f"sudo PIVOTRA_KEY={api_key} PIVOTRA_URL={base_url} bash"
    )
    if sudo_pass:
        install_cmd = f"echo '{sudo_pass}' | sudo -S bash -c \"{install_cmd}\""

    # 3. Build SSH command
    ssh_args = ["ssh", "-o", "StrictHostKeyChecking=no", "-o", "BatchMode=yes"]
    if key_file:
        ssh_args += ["-i", key_file]
    ssh_args += [f"{user}@{host}", install_cmd]

    console.print(f"[dim]SSH → {user}@{host}[/dim]")
    confirm = typer.confirm(f"Deploy agent to {host}?")
    if not confirm:
        console.print("[dim]Cancelled.[/dim]")
        raise typer.Exit()

    # 4. Run SSH
    try:
        proc = subprocess.run(ssh_args, capture_output=False, text=True)
        if proc.returncode == 0:
            console.print(f"[bold green]Agent deployed to {host}.[/bold green]")
        else:
            console.print(f"[red]Deployment failed (exit {proc.returncode}).[/red]")
            raise typer.Exit(proc.returncode)
    except FileNotFoundError:
        console.print("[red]SSH not found. Install openssh-client.[/red]")
        raise typer.Exit(1)


@app.command()
def spawn(
    agent_id: str = typer.Argument(..., help="Parent agent ID"),
    json_out: bool = typer.Option(False, "--json"),
):
    """Spawn a sub-agent from an existing agent."""
    from . import api_client as api
    with console.status(f"[cyan]Spawning sub-agent from {agent_id}...[/cyan]"):
        result = api.spawn_agent(agent_id)
    if json_out:
        import json; console.print_json(json.dumps(result))
    else:
        sub_id = result.get("id") or result.get("agent_id") or "?"
        console.print(f"[green]Sub-agent spawned:[/green] [cyan]{sub_id}[/cyan]")


@app.command()
def sub_agents(
    agent_id: str = typer.Argument(..., help="Parent agent ID"),
    json_out: bool = typer.Option(False, "--json"),
):
    """List sub-agents of an agent."""
    from . import api_client as api
    from .display import agent_table
    data = api.get_sub_agents(agent_id)
    if json_out:
        import json; console.print_json(json.dumps(data))
    else:
        agent_table(data)


@app.command()
def broadcast(
    command: str = typer.Argument(..., help="Shell command to broadcast to all agents"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
):
    """Broadcast a shell command to ALL online agents."""
    from . import api_client as api
    if not force:
        confirm = typer.confirm(
            f"Broadcast [bold red]{command!r}[/bold red] to ALL agents?"
        )
        if not confirm:
            console.print("[dim]Cancelled.[/dim]")
            raise typer.Exit()
    with console.status("[cyan]Broadcasting...[/cyan]"):
        result = api.broadcast_command(command)
    console.print(f"[green]Broadcast sent.[/green] {result}")


@app.command()
def mesh(
    agent_id: str = typer.Argument(..., help="Mesh orchestrator agent ID"),
    command: str = typer.Argument(..., help="Command to run across mesh"),
    targets: str = typer.Option("", "--targets", "-t", help="Comma-separated target agent IDs (default: all peers)"),
):
    """Run a mesh command via an agent's peer network."""
    from . import api_client as api
    target_list = [t.strip() for t in targets.split(",") if t.strip()] if targets else []
    with console.status(f"[cyan]Sending mesh command via {agent_id}...[/cyan]"):
        result = api.mesh_cmd(agent_id, command, target_list)
    console.print(f"[green]Mesh command sent.[/green] {result}")


@app.command()
def restart(agent_id: str = typer.Argument(..., help="Agent ID")):
    """Restart the Pivotra agent process on a host."""
    from . import api_client as api
    confirm = typer.confirm(f"Restart agent [bold]{agent_id}[/bold]?")
    if not confirm:
        console.print("[dim]Cancelled.[/dim]")
        raise typer.Exit()
    with console.status(f"[cyan]Restarting {agent_id}...[/cyan]"):
        result = api.restart_agent(agent_id)
    console.print(f"[green]Restart triggered.[/green]")


@app.command()
def rotate_key(agent_id: str = typer.Argument(..., help="Agent ID")):
    """Rotate the API key of an agent (revokes old key immediately)."""
    from . import api_client as api
    confirm = typer.confirm(f"Rotate key for [bold red]{agent_id}[/bold red]? Old key will be revoked.")
    if not confirm:
        console.print("[dim]Cancelled.[/dim]")
        raise typer.Exit()
    with console.status(f"[cyan]Rotating key for {agent_id}...[/cyan]"):
        result = api.rotate_key(agent_id)
    new_key = result.get("api_key") or result.get("key") or result.get("new_key") or "?"
    console.print(f"[green]Key rotated.[/green] New key: [yellow]{new_key}[/yellow]")


@app.command()
def deregister(
    agent_id: str = typer.Argument(..., help="Agent ID"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
):
    """Permanently deregister and remove an agent from the fleet."""
    from . import api_client as api
    if not force:
        confirm = typer.confirm(
            f"[bold red]Permanently deregister[/bold red] agent [bold]{agent_id}[/bold]? This cannot be undone."
        )
        if not confirm:
            console.print("[dim]Cancelled.[/dim]")
            raise typer.Exit()
    with console.status(f"[red]Deregistering {agent_id}...[/red]"):
        try:
            api.deregister_agent(agent_id)
        except api.APIError as e:
            console.print(f"[red]Error {e.status_code}:[/red] {e.message}")
            raise typer.Exit(1)
    console.print(f"[green]Agent {agent_id} deregistered.[/green]")


# ── BRO AI ────────────────────────────────────────────────────────────────────

@app.command()
def bro(
    agent_id: Optional[str] = typer.Option(None, "--agent", "-a", help="Set agent context for BRO"),
    question: Optional[str] = typer.Argument(None, help="Single question (non-interactive mode)"),
    file: Optional[str] = typer.Option(None, "--file", "-f", help="File to include in BRO context"),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Plain text output (no rich formatting, for piping)"),
    agents: Optional[str] = typer.Option(None, "--agents", help="Comma-separated agent IDs for multi-agent context"),
):
    """
    [bold magenta]BRO AI[/bold magenta] — conversational AI assistant.

    Interactive REPL mode (no question): full conversation with history.
    Single question mode: ask one question and get a streamed answer.

    Examples:
      pivotra bro
      pivotra bro "analyse les anomalies de prod-web-01"
      pivotra bro --agent prod-web-01 "is this a real threat?"
      pivotra bro "analyse ce log" --file /var/log/auth.log
      pivotra bro --quiet "résumé sécurité" > rapport.txt
      pivotra bro --agents wkx-abc,wkx-def "compare ces agents"
    """
    from .repl import run_repl, ask_once

    # Prepend file content to question if --file provided
    extra_context: Optional[str] = None
    if file:
        try:
            with open(file) as fh:
                content = fh.read()
            extra_context = f"[FILE: {file}]\n{content[:4000]}"
        except Exception as e:
            console.print(f"[red]Cannot read file {file}:[/red] {e}")
            raise typer.Exit(1)

    # Multi-agent IDs override single agent_id
    effective_agent = agent_id
    if agents:
        effective_agent = agents.split(",")[0].strip()

    full_question = question
    if extra_context and question:
        full_question = f"{question}\n\n{extra_context}"
    elif extra_context:
        full_question = f"Analyse le contenu suivant:\n\n{extra_context}"

    if full_question:
        ask_once(full_question, agent_id=effective_agent, quiet=quiet)
    else:
        run_repl(agent_id=effective_agent)


# ── Shell (PTY) ───────────────────────────────────────────────────────────────

@app.command()
def shell(
    agent_id: str = typer.Argument(..., help="Agent ID"),
):
    """Open an interactive PTY shell session on an agent."""
    from .auth import get_base_url, require_token
    import asyncio
    import websockets
    import sys
    import termios
    import tty
    import os

    token   = require_token()
    base    = get_base_url().replace("https://", "wss://").replace("http://", "ws://")
    ws_url  = f"{base}/api/v1/pty?token={token}&agent_id={agent_id}"

    console.print(f"[cyan]Opening shell on [bold]{agent_id}[/bold]...[/cyan] (Ctrl+D to exit)")

    async def _run():
        async with websockets.connect(ws_url) as ws:
            old_settings = termios.tcgetattr(sys.stdin)
            try:
                tty.setraw(sys.stdin.fileno())

                async def _send():
                    while True:
                        char = await asyncio.get_event_loop().run_in_executor(
                            None, lambda: sys.stdin.read(1)
                        )
                        if not char:
                            break
                        await ws.send(char)

                async def _recv():
                    async for msg in ws:
                        sys.stdout.write(msg)
                        sys.stdout.flush()

                await asyncio.gather(_send(), _recv())
            finally:
                termios.tcsetattr(sys.stdin, termios.TCSADRAIN, old_settings)

    try:
        asyncio.run(_run())
    except KeyboardInterrupt:
        console.print("\n[dim]Session closed.[/dim]")


# ── Infra ops: file, docker, psql ─────────────────────────────────────────────

file_app = typer.Typer(name="file", help="Read/write files on remote agents.", no_args_is_help=True)
app.add_typer(file_app)

@file_app.command("read")
def file_read(
    agent_id: str = typer.Argument(..., help="Agent ID"),
    path: str = typer.Argument(..., help="Remote file path"),
):
    """Read a file from a remote agent."""
    from . import api_client as api
    from rich.syntax import Syntax
    with console.status(f"[cyan]Reading {path} on {agent_id}...[/cyan]"):
        content = api.file_read(agent_id, path)
    if not content:
        console.print("[yellow]Empty or no output.[/yellow]")
        return
    ext = path.rsplit(".", 1)[-1] if "." in path else "text"
    lexer_map = {"py": "python", "sh": "bash", "yaml": "yaml", "yml": "yaml",
                 "json": "json", "conf": "nginx", "cfg": "ini", "toml": "toml"}
    lexer = lexer_map.get(ext, "text")
    console.print(Syntax(content, lexer, theme="monokai", line_numbers=True))


@file_app.command("list")
def file_list(
    agent_id: str = typer.Argument(..., help="Agent ID"),
    path: str = typer.Argument(".", help="Remote directory path"),
):
    """List files in a directory on a remote agent."""
    from . import api_client as api
    with console.status(f"[cyan]Listing {path} on {agent_id}...[/cyan]"):
        output = api.file_list(agent_id, path)
    console.print(output)


@file_app.command("write")
def file_write(
    agent_id: str = typer.Argument(..., help="Agent ID"),
    path: str = typer.Argument(..., help="Remote file path"),
    content: str = typer.Argument(..., help="Content to write"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
):
    """Write content to a file on a remote agent."""
    from . import api_client as api
    if not force:
        confirm = typer.confirm(f"Write to [bold]{path}[/bold] on [bold]{agent_id}[/bold]?")
        if not confirm:
            console.print("[dim]Cancelled.[/dim]")
            raise typer.Exit()
    with console.status(f"[cyan]Writing to {path}...[/cyan]"):
        api.file_write(agent_id, path, content)
    console.print(f"[green]Written to {path} on {agent_id}.[/green]")


docker_app = typer.Typer(name="docker", help="Docker management on remote agents.", no_args_is_help=True)
app.add_typer(docker_app)

@docker_app.command("ps")
def docker_ps(agent_id: str = typer.Argument(..., help="Agent ID")):
    """List running Docker containers on an agent."""
    from . import api_client as api
    with console.status(f"[cyan]docker ps on {agent_id}...[/cyan]"):
        output = api.docker_cmd(agent_id, "ps --format 'table {{.ID}}\t{{.Names}}\t{{.Image}}\t{{.Status}}\t{{.Ports}}'")
    console.print(output)


@docker_app.command("exec")
def docker_exec(
    agent_id: str = typer.Argument(..., help="Agent ID"),
    container: str = typer.Argument(..., help="Container name or ID"),
    cmd: str = typer.Argument(..., help="Command to run inside container"),
):
    """Execute a command inside a Docker container on an agent."""
    from . import api_client as api
    with console.status(f"[cyan]docker exec {container} on {agent_id}...[/cyan]"):
        output = api.docker_cmd(agent_id, f"exec {container} {cmd}")
    console.print(output)


@docker_app.command("logs")
def docker_logs(
    agent_id: str = typer.Argument(..., help="Agent ID"),
    container: str = typer.Argument(..., help="Container name or ID"),
    lines: int = typer.Option(50, "--lines", "-n", help="Number of log lines"),
):
    """Get logs from a Docker container on an agent."""
    from . import api_client as api
    with console.status(f"[cyan]docker logs {container} on {agent_id}...[/cyan]"):
        output = api.docker_cmd(agent_id, f"logs --tail {lines} {container}")
    console.print(output)


@docker_app.command("images")
def docker_images(agent_id: str = typer.Argument(..., help="Agent ID")):
    """List Docker images on an agent."""
    from . import api_client as api
    with console.status(f"[cyan]docker images on {agent_id}...[/cyan]"):
        output = api.docker_cmd(agent_id, "images")
    console.print(output)


@app.command()
def psql(
    agent_id: str = typer.Argument(..., help="Agent ID"),
    query: str = typer.Argument(..., help="SQL query to execute"),
    db: str = typer.Option("", "--db", "-d", help="Database name"),
):
    """Execute a PostgreSQL query on a remote agent."""
    from . import api_client as api
    with console.status(f"[cyan]Running SQL on {agent_id}...[/cyan]"):
        output = api.psql_query(agent_id, query, db)
    console.print(output)


# ── Forensics & Hunt ───────────────────────────────────────────────────────────

hunt_app = typer.Typer(name="hunt", help="Forensic threat hunting.", no_args_is_help=True)
app.add_typer(hunt_app)

@hunt_app.command("run")
def hunt_run(query: str = typer.Argument(..., help="Hunt query (natural language or structured)")):
    """Run an ad-hoc forensic hunt query."""
    from . import api_client as api
    with console.status("[cyan]Running hunt...[/cyan]"):
        result = api.run_hunt(query)
    job_id = result.get("job_id") or result.get("id") or "?"
    console.print(f"[green]Hunt started.[/green] Job ID: [cyan]{job_id}[/cyan]")
    console.print(f"[dim]Check results: pivotra hunt results {job_id}[/dim]")


@hunt_app.command("jobs")
def hunt_jobs():
    """List active/recent hunt jobs."""
    from . import api_client as api
    from rich.table import Table
    from rich import box
    jobs = api.get_hunt_jobs()
    t = Table(box=box.ROUNDED, header_style="bold dim")
    t.add_column("Job ID", style="cyan")
    t.add_column("Status")
    t.add_column("Query")
    t.add_column("Created")
    for j in jobs:
        t.add_row(str(j.get("id") or "?"), j.get("status") or "?",
                  (j.get("query") or "")[:50], j.get("created_at") or "")
    console.print(t)


@hunt_app.command("results")
def hunt_results(job_id: str = typer.Argument(..., help="Hunt job ID")):
    """Show results of a hunt job."""
    from . import api_client as api
    import json
    result = api.get_hunt_results(job_id)
    console.print_json(json.dumps(result))


@app.command()
def investigate(
    anomaly_id: str = typer.Argument(..., help="Anomaly/alert ID to investigate"),
    json_out: bool = typer.Option(False, "--json"),
):
    """Open or create an investigation for an anomaly."""
    from . import api_client as api
    import json
    with console.status(f"[cyan]Opening investigation for {anomaly_id}...[/cyan]"):
        result = api.trigger_investigation(anomaly_id)
    if json_out:
        console.print_json(json.dumps(result))
    else:
        case_id = result.get("id") or result.get("case_id") or "?"
        status = result.get("status") or "open"
        console.print(f"[green]Investigation created.[/green] Case: [cyan]{case_id}[/cyan] [{status}]")


@app.command()
def investigations(
    limit: int = typer.Option(20, "--limit", "-n"),
    json_out: bool = typer.Option(False, "--json"),
):
    """List open investigations."""
    from . import api_client as api
    from rich.table import Table
    from rich import box
    import json
    data = api.list_investigations(limit)
    if json_out:
        console.print_json(json.dumps(data))
    else:
        t = Table(box=box.ROUNDED, header_style="bold dim")
        t.add_column("Case ID", style="cyan")
        t.add_column("Status")
        t.add_column("Assignee")
        t.add_column("Anomaly")
        t.add_column("Created")
        for i in data:
            t.add_row(
                str(i.get("id") or "?"),
                i.get("status") or "?",
                i.get("assignee") or "—",
                str(i.get("anomaly_id") or "?"),
                (i.get("created_at") or "")[:16],
            )
        console.print(t)


# ── IOCs ───────────────────────────────────────────────────────────────────────

ioc_app = typer.Typer(name="ioc", help="Threat intelligence IOC management.", no_args_is_help=True)
app.add_typer(ioc_app)

@ioc_app.command("lookup")
def ioc_lookup(value: str = typer.Argument(..., help="IP, hash, domain, or URL")):
    """Look up a value in threat intelligence feeds."""
    from . import api_client as api
    import json
    with console.status(f"[cyan]Looking up {value}...[/cyan]"):
        result = api.lookup_ioc(value)
    console.print_json(json.dumps(result))


@ioc_app.command("list")
def ioc_list(
    limit: int = typer.Option(20, "--limit", "-n"),
    json_out: bool = typer.Option(False, "--json"),
):
    """List known IOCs in the intelligence database."""
    from . import api_client as api
    from rich.table import Table
    from rich import box
    import json
    data = api.list_iocs(limit)
    if json_out:
        console.print_json(json.dumps(data))
    else:
        t = Table(box=box.ROUNDED, header_style="bold dim")
        t.add_column("Type", style="yellow")
        t.add_column("Value", style="red")
        t.add_column("Severity")
        t.add_column("Added")
        for i in data:
            t.add_row(i.get("type") or "?", i.get("value") or "?",
                      i.get("severity") or "?", (i.get("created_at") or "")[:16])
        console.print(t)


@ioc_app.command("add")
def ioc_add(
    ioc_type: str = typer.Argument(..., help="Type: ip, hash, domain, url"),
    value: str = typer.Argument(..., help="IOC value"),
    severity: str = typer.Option("medium", "--severity", "-s"),
):
    """Add a new IOC to the intelligence database."""
    from . import api_client as api
    result = api.add_ioc(ioc_type, value, severity)
    console.print(f"[green]IOC added.[/green] ID: {result.get('id') or '?'}")


@app.command("ip-check")
def ip_check(ip: str = typer.Argument(..., help="IP address to check")):
    """Check IP reputation against threat intelligence."""
    from . import api_client as api
    import json
    with console.status(f"[cyan]Checking {ip}...[/cyan]"):
        result = api.check_ip(ip)
    score = result.get("score") or result.get("risk_score") or "?"
    country = result.get("country") or "?"
    verdict = result.get("verdict") or result.get("category") or "?"
    console.print(f"IP: [bold]{ip}[/bold]  Score: [red]{score}[/red]  Country: {country}  Verdict: {verdict}")
    if result.get("tags"):
        console.print(f"Tags: {', '.join(result['tags'])}")


# ── Reports ────────────────────────────────────────────────────────────────────

report_app = typer.Typer(name="report", help="Security reports.", no_args_is_help=True)
app.add_typer(report_app)

@report_app.command("generate")
def report_generate(
    days: int = typer.Option(7, "--days", "-d", help="Days to cover"),
):
    """Generate a security report."""
    from . import api_client as api
    with console.status(f"[cyan]Generating {days}-day report...[/cyan]"):
        result = api.generate_report(days)
    run_id = result.get("run_id") or result.get("id") or "?"
    console.print(f"[green]Report generated.[/green] Run ID: [cyan]{run_id}[/cyan]")
    console.print(f"[dim]Download: pivotra report download {run_id}[/dim]")


@report_app.command("list")
def report_list():
    """List generated reports."""
    from . import api_client as api
    from rich.table import Table
    from rich import box
    data = api.list_reports()
    t = Table(box=box.ROUNDED, header_style="bold dim")
    t.add_column("Run ID", style="cyan")
    t.add_column("Status")
    t.add_column("Generated")
    t.add_column("Duration")
    for r in data:
        t.add_row(
            str(r.get("id") or "?"),
            r.get("status") or "?",
            (r.get("created_at") or "")[:16],
            f"{r.get('duration_ms', 0) // 1000}s",
        )
    console.print(t)


@report_app.command("download")
def report_download(
    run_id: str = typer.Argument(..., help="Report run ID"),
    fmt: str = typer.Option("pdf", "--format", "-f", help="pdf, csv, or xlsx"),
    output: str = typer.Option("", "--output", "-o", help="Output file path"),
):
    """Download a report (PDF, CSV, or Excel)."""
    from . import api_client as api
    import pathlib
    with console.status(f"[cyan]Downloading report {run_id}...[/cyan]"):
        data = api.download_report(run_id, fmt)
    dest = output or f"pivotra_report_{run_id}.{fmt}"
    pathlib.Path(dest).write_bytes(data)
    console.print(f"[green]Saved to {dest}[/green] ({len(data)} bytes)")


# ── MITRE ATT&CK ───────────────────────────────────────────────────────────────

@app.command()
def mitre(json_out: bool = typer.Option(False, "--json")):
    """Show MITRE ATT&CK coverage for the current detection rules."""
    from . import api_client as api
    from rich.table import Table
    from rich import box
    import json
    stats = api.get_mitre_stats()
    if json_out:
        console.print_json(json.dumps(stats))
        return
    covered = stats.get("covered_techniques") or stats.get("covered") or 0
    total   = stats.get("total_techniques") or stats.get("total") or "?"
    pct     = stats.get("coverage_pct") or stats.get("percentage") or "?"
    console.print(f"[bold cyan]MITRE ATT&CK Coverage[/bold cyan]: {covered}/{total} techniques ({pct}%)")
    cov = api.get_mitre_coverage()
    t = Table(box=box.ROUNDED, header_style="bold dim")
    t.add_column("Tactic", style="cyan")
    t.add_column("Covered")
    t.add_column("Total")
    t.add_column("%")
    if isinstance(cov, list):
        for row in cov:
            t.add_row(
                row.get("tactic") or row.get("name") or "?",
                str(row.get("covered") or 0),
                str(row.get("total") or 0),
                str(row.get("pct") or row.get("percentage") or "?"),
            )
    console.print(t)


# ── EDR ─────────────────────────────────────────────────────────────────────────

@app.command()
def edr(
    agent_id: Optional[str] = typer.Option(None, "--agent", "-a", help="Filter by agent"),
    limit: int = typer.Option(20, "--limit", "-n"),
    json_out: bool = typer.Option(False, "--json"),
):
    """Show EDR events (endpoint detection)."""
    from . import api_client as api
    from rich.table import Table
    from rich import box
    import json
    data = api.get_edr_events(agent_id, limit)
    if json_out:
        console.print_json(json.dumps(data))
        return
    t = Table(box=box.ROUNDED, header_style="bold dim")
    t.add_column("ID", style="dim")
    t.add_column("Agent")
    t.add_column("Type", style="yellow")
    t.add_column("Severity", style="red")
    t.add_column("Details")
    t.add_column("Time")
    for e in data:
        t.add_row(
            str(e.get("id") or "?")[:8],
            e.get("agent_id") or "?",
            e.get("event_type") or e.get("type") or "?",
            (e.get("severity") or "?").upper(),
            (e.get("details") or e.get("description") or "")[:50],
            (e.get("timestamp") or e.get("created_at") or "")[:16],
        )
    console.print(t)


# ── Playbooks ─────────────────────────────────────────────────────────────────

playbook_app = typer.Typer(name="playbook", help="Incident response playbooks.", no_args_is_help=True)
app.add_typer(playbook_app)

@playbook_app.command("list")
def playbook_list(json_out: bool = typer.Option(False, "--json")):
    """List all available playbooks."""
    from . import api_client as api
    from rich.table import Table
    from rich import box
    import json
    data = api.list_playbooks()
    if json_out:
        console.print_json(json.dumps(data))
        return
    t = Table(box=box.ROUNDED, header_style="bold dim")
    t.add_column("ID", style="dim")
    t.add_column("Name", style="cyan")
    t.add_column("Action Type", style="yellow")
    t.add_column("Executor")
    t.add_column("Mode")
    t.add_column("Built-in")
    t.add_column("Active")
    for p in data:
        t.add_row(
            str(p.get("id") or "?"),
            p.get("name") or "?",
            p.get("action_type") or "?",
            p.get("executor_type") or "?",
            p.get("execution_mode") or "manual",
            "[green]yes[/green]" if p.get("is_builtin") else "no",
            "[green]on[/green]" if p.get("is_active") else "[dim]off[/dim]",
        )
    console.print(t)


@playbook_app.command("run")
def playbook_run(
    playbook_id: str = typer.Argument(..., help="Playbook ID or action type (e.g. BLOCK_IP)"),
    target: str = typer.Option("", "--target", "-t", help="Target (IP, hostname, etc.)"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Simulate without executing"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
):
    """Execute a playbook (optionally in dry-run / simulation mode)."""
    from . import api_client as api
    mode = "[yellow]DRY RUN[/yellow]" if dry_run else "[red]LIVE[/red]"
    if not force:
        confirm = typer.confirm(f"Run playbook [cyan]{playbook_id}[/cyan] {mode}" +
                                (f" on target [bold]{target}[/bold]" if target else "") + "?")
        if not confirm:
            console.print("[dim]Cancelled.[/dim]")
            raise typer.Exit()
    with console.status(f"[cyan]Running playbook {playbook_id}...[/cyan]"):
        result = api.run_playbook(playbook_id, target, dry_run)
    log_id = result.get("log_id") or result.get("action_id") or result.get("id") or "?"
    console.print(f"[green]Playbook triggered.[/green] Log ID: [cyan]{log_id}[/cyan]")
    console.print(f"[dim]See log: pivotra playbook log {log_id}[/dim]")


@playbook_app.command("log")
def playbook_log(action_id: str = typer.Argument(..., help="Action/log ID")):
    """Show execution log for a playbook run."""
    from . import api_client as api
    import json
    result = api.get_playbook_log(action_id)
    status = result.get("status") or "?"
    output = result.get("output") or result.get("logs") or ""
    error  = result.get("error") or ""
    dur    = result.get("duration_ms") or 0
    color  = "green" if status == "done" else "red" if status == "failed" else "yellow"
    console.print(f"Status: [{color}]{status}[/{color}]  Duration: {dur}ms")
    if output:
        console.print(output)
    if error:
        console.print(f"[red]Error:[/red] {error}")


@playbook_app.command("external-runs")
def playbook_external_runs(limit: int = typer.Option(20, "--limit", "-n")):
    """List playbook executions triggered by external systems (webhooks)."""
    from . import api_client as api
    from rich.table import Table
    from rich import box
    data = api.get_external_runs(limit)
    t = Table(box=box.ROUNDED, header_style="bold dim")
    t.add_column("Action ID", style="cyan")
    t.add_column("Playbook")
    t.add_column("Status")
    t.add_column("Duration")
    t.add_column("Started")
    for r in data:
        dur = r.get("duration_ms") or 0
        t.add_row(
            str(r.get("response_action_id") or "?"),
            r.get("playbook_name") or "?",
            r.get("status") or "?",
            f"{dur}ms",
            (r.get("started_at") or "")[:16],
        )
    console.print(t)


@playbook_app.command("trigger-external")
def playbook_trigger_external(
    action_type: str = typer.Argument(..., help="Playbook action type (e.g. BLOCK_IP)"),
    target: str = typer.Argument(..., help="Target value"),
    token: str = typer.Option("", "--token", "-k", help="Webhook token (X-Webhook-Token)"),
    reason: str = typer.Option("", "--reason", "-r", help="Reason for trigger"),
):
    """Trigger a playbook via external webhook API."""
    from . import api_client as api
    with console.status(f"[cyan]Triggering {action_type} on {target}...[/cyan]"):
        result = api.trigger_external_playbook(action_type, target, reason, token)
    status = result.get("status") or "?"
    action_id = result.get("action_id") or "?"
    console.print(f"[green]{status}.[/green] Action ID: [cyan]{action_id}[/cyan]")


# ── Response Queue ─────────────────────────────────────────────────────────────

queue_app = typer.Typer(name="queue", help="Response queue management.", no_args_is_help=True)
app.add_typer(queue_app)

@queue_app.command("list")
def queue_list(json_out: bool = typer.Option(False, "--json")):
    """Show all pending response actions awaiting approval."""
    from . import api_client as api
    from rich.table import Table
    from rich import box
    import json
    data = api.get_response_queue()
    if json_out:
        console.print_json(json.dumps(data))
        return
    t = Table(box=box.ROUNDED, header_style="bold dim")
    t.add_column("Action ID", style="cyan")
    t.add_column("Type", style="yellow")
    t.add_column("Target", style="red")
    t.add_column("Status")
    t.add_column("Severity")
    t.add_column("Created")
    for a in data:
        t.add_row(
            str(a.get("id") or "?"),
            a.get("action_type") or "?",
            a.get("target") or "?",
            a.get("status") or "?",
            (a.get("severity") or "?").upper(),
            (a.get("created_at") or "")[:16],
        )
    if not data:
        console.print("[dim]No pending actions.[/dim]")
    else:
        console.print(t)
        console.print(f"[dim]{len(data)} action(s). Use 'pivotra queue approve <id>' to approve.[/dim]")


@queue_app.command("approve")
def queue_approve(
    action_id: str = typer.Argument(..., help="Action ID to approve"),
    force: bool = typer.Option(False, "--force", "-f"),
):
    """Approve a pending response action (executes it)."""
    from . import api_client as api
    if not force:
        confirm = typer.confirm(f"Approve and execute action [bold cyan]{action_id}[/bold cyan]?")
        if not confirm:
            console.print("[dim]Cancelled.[/dim]")
            raise typer.Exit()
    result = api.approve_action(action_id)
    console.print(f"[green]Action {action_id} approved.[/green]")


@queue_app.command("reject")
def queue_reject(action_id: str = typer.Argument(..., help="Action ID to reject")):
    """Reject a pending response action."""
    from . import api_client as api
    result = api.reject_action(action_id)
    console.print(f"[dim]Action {action_id} rejected.[/dim]")


# ── Groups ─────────────────────────────────────────────────────────────────────

group_app = typer.Typer(name="group", help="Agent group management.", no_args_is_help=True)
app.add_typer(group_app)

@group_app.command("list")
def group_list(json_out: bool = typer.Option(False, "--json")):
    """List all agent groups."""
    from . import api_client as api
    from rich.table import Table
    from rich import box
    import json
    data = api.list_groups()
    if json_out:
        console.print_json(json.dumps(data))
        return
    t = Table(box=box.ROUNDED, header_style="bold dim")
    t.add_column("ID", style="dim")
    t.add_column("Name", style="cyan")
    t.add_column("Agents")
    t.add_column("Description")
    for g in data:
        t.add_row(
            str(g.get("id") or "?"),
            g.get("name") or "?",
            str(len(g.get("agents") or g.get("agent_ids") or [])),
            g.get("description") or "—",
        )
    console.print(t)


@group_app.command("create")
def group_create(
    name: str = typer.Argument(..., help="Group name"),
    description: str = typer.Option("", "--desc", "-d"),
):
    """Create a new agent group."""
    from . import api_client as api
    result = api.create_group(name, description)
    console.print(f"[green]Group created.[/green] ID: {result.get('id') or '?'}")


@group_app.command("assign")
def group_assign(
    group_id: str = typer.Argument(..., help="Group ID"),
    agents: str = typer.Argument(..., help="Comma-separated agent IDs"),
):
    """Assign agents to a group."""
    from . import api_client as api
    agent_list = [a.strip() for a in agents.split(",") if a.strip()]
    api.assign_to_group(group_id, agent_list)
    console.print(f"[green]Assigned {len(agent_list)} agent(s) to group {group_id}.[/green]")


# ── Audit ──────────────────────────────────────────────────────────────────────

@app.command()
def audit(
    limit: int = typer.Option(20, "--limit", "-n"),
    json_out: bool = typer.Option(False, "--json"),
):
    """Show platform audit logs (all user actions)."""
    from . import api_client as api
    from rich.table import Table
    from rich import box
    import json
    data = api.get_audit_logs(limit)
    if json_out:
        console.print_json(json.dumps(data))
        return
    t = Table(box=box.ROUNDED, header_style="bold dim")
    t.add_column("User", style="cyan")
    t.add_column("Action", style="yellow")
    t.add_column("Resource")
    t.add_column("IP")
    t.add_column("Time")
    for a in data:
        t.add_row(
            a.get("user_email") or a.get("user") or "?",
            a.get("action") or "?",
            a.get("resource") or "—",
            a.get("ip_address") or a.get("ip") or "?",
            (a.get("created_at") or a.get("timestamp") or "")[:16],
        )
    console.print(t)


# ── Users ──────────────────────────────────────────────────────────────────────

@app.command()
def users(json_out: bool = typer.Option(False, "--json")):
    """List platform users."""
    from . import api_client as api
    from rich.table import Table
    from rich import box
    import json
    data = api.list_users()
    if json_out:
        console.print_json(json.dumps(data))
        return
    t = Table(box=box.ROUNDED, header_style="bold dim")
    t.add_column("Email", style="cyan")
    t.add_column("Role", style="yellow")
    t.add_column("2FA")
    t.add_column("Active")
    t.add_column("Joined")
    for u in data:
        t.add_row(
            u.get("email") or "?",
            u.get("role") or "?",
            "[green]on[/green]" if u.get("totp_enabled") else "[dim]off[/dim]",
            "[green]yes[/green]" if u.get("is_active") else "[dim]no[/dim]",
            (u.get("created_at") or "")[:10],
        )
    console.print(t)


@app.command()
def invite(
    email: str = typer.Argument(..., help="Email address to invite"),
    role: str = typer.Option("analyst", "--role", "-r", help="Role: analyst, admin, manager, viewer"),
):
    """Invite a new user to the platform."""
    from . import api_client as api
    result = api.invite_user(email, role)
    console.print(f"[green]Invitation sent to {email}[/green] as [yellow]{role}[/yellow].")


# ── Jobs ───────────────────────────────────────────────────────────────────────

@app.command()
def jobs(json_out: bool = typer.Option(False, "--json")):
    """Show background jobs (ML retraining, report gen, etc.)."""
    from . import api_client as api
    from rich.table import Table
    from rich import box
    import json
    data = api.list_jobs()
    if json_out:
        console.print_json(json.dumps(data))
        return
    t = Table(box=box.ROUNDED, header_style="bold dim")
    t.add_column("ID", style="dim")
    t.add_column("Type", style="cyan")
    t.add_column("Status")
    t.add_column("Progress")
    t.add_column("Started")
    for j in data:
        t.add_row(
            str(j.get("id") or "?")[:8],
            j.get("job_type") or j.get("type") or "?",
            j.get("status") or "?",
            str(j.get("progress") or j.get("progress_pct") or "?"),
            (j.get("created_at") or "")[:16],
        )
    console.print(t)


# ── Dashboard ──────────────────────────────────────────────────────────────────

@app.command()
def dashboard():
    """Show SOC dashboard summary (KPIs, fleet health, top threats)."""
    from . import api_client as api
    from rich.table import Table
    from rich.panel import Panel
    from rich.columns import Columns
    from rich import box
    with console.status("[cyan]Loading dashboard...[/cyan]"):
        try:
            data = api.get_dashboard()
        except api.APIError as e:
            console.print(f"[red]Dashboard error {e.status_code}:[/red] {e.message}")
            raise typer.Exit(1)
    # KPIs
    total_anomalies = data.get("total_anomalies") or data.get("anomalies_count") or 0
    critical        = data.get("critical_count") or data.get("critical") or 0
    online_agents   = data.get("agents_online") or 0
    total_agents    = data.get("agents_total") or 0
    pending_actions = data.get("pending_actions") or 0

    console.print(Panel(
        f"[bold red]Critical: {critical}[/bold red]  "
        f"[yellow]Anomalies: {total_anomalies}[/yellow]  "
        f"[cyan]Agents: {online_agents}/{total_agents}[/cyan]  "
        f"[magenta]Pending: {pending_actions}[/magenta]",
        title="[bold cyan]SOC Dashboard[/bold cyan]",
        border_style="cyan",
    ))

    # Top threats
    top_threats = data.get("top_threats") or data.get("top_sources") or []
    if top_threats:
        t = Table(box=box.SIMPLE, header_style="bold dim", show_header=True)
        t.add_column("Source/Type", style="yellow")
        t.add_column("Count", style="red")
        for row in top_threats[:5]:
            t.add_row(str(row.get("source") or row.get("type") or "?"),
                      str(row.get("count") or "?"))
        console.print(t)


# ── Watch (live fleet refresh) ────────────────────────────────────────────────

@app.command()
def watch(
    interval: int = typer.Option(5, "--interval", "-i", help="Refresh interval in seconds (default: 5)"),
):
    """Live fleet monitor — auto-refreshes every N seconds. Ctrl+C to quit."""
    from . import api_client as api
    from rich.live import Live
    from rich.table import Table
    from rich import box
    from rich.text import Text
    import time

    def _make_table():
        try:
            agents_list = api.list_agents()
        except Exception:
            agents_list = []
        online = sum(1 for a in agents_list if a.get("online") or a.get("status") == "online")
        t = Table(
            title=f"[bold cyan]Fleet — {len(agents_list)} agents  ·  {online} online[/bold cyan]  [dim](refresh {interval}s)[/dim]",
            box=box.ROUNDED, header_style="bold dim",
        )
        t.add_column("ID", style="dim", max_width=20)
        t.add_column("Hostname", style="bold")
        t.add_column("Status", justify="center", width=8)
        t.add_column("OS", style="dim")
        t.add_column("IP", style="dim")
        for a in agents_list:
            on = a.get("online") or a.get("status") == "online"
            st = Text("● online", style="green") if on else Text("○ offline", style="red")
            t.add_row(str(a.get("id", "?"))[:18], a.get("hostname") or "?", st,
                      a.get("os") or "—", a.get("ip") or "—")
        return t

    console.print("[dim]Ctrl+C to quit[/dim]")
    with Live(_make_table(), console=console, refresh_per_second=2) as live:
        try:
            while True:
                time.sleep(interval)
                live.update(_make_table())
        except KeyboardInterrupt:
            pass


# ── Fleet health ───────────────────────────────────────────────────────────────

@app.command(name="fleet-health")
def fleet_health():
    """Show fleet health overview with security score per agent."""
    from . import api_client as api
    from rich.table import Table
    from rich import box

    with console.status("[cyan]Loading fleet health...[/cyan]"):
        try:
            data = api.fleet_stats()
        except api.APIError as e:
            console.print(f"[red]Error {e.status_code}:[/red] {e.message}")
            raise typer.Exit(1)

    fleet_score = data.get("fleet_score") or data.get("health_score") or 100
    sc_style = "green" if fleet_score >= 80 else "yellow" if fleet_score >= 50 else "red"
    console.print(
        f"\n[bold]Fleet Health:[/bold] [{sc_style}]{fleet_score}/100[/{sc_style}]  "
        f"[dim]{data.get('online', 0)}/{data.get('total', 0)} online  ·  "
        f"{data.get('critical_alerts', 0)} critical[/dim]\n"
    )

    agent_scores = data.get("agents") or []
    t = Table(box=box.ROUNDED, header_style="bold dim")
    t.add_column("Agent", style="dim", max_width=20)
    t.add_column("Hostname")
    t.add_column("Status")
    t.add_column("Score", justify="right")
    t.add_column("Anomalies 24h", justify="right")
    t.add_column("Crit Vulns", justify="right")

    for a in sorted(agent_scores, key=lambda x: x.get("score", 0), reverse=True):
        sc = a.get("score", 0)
        sc_s = "red" if sc >= 70 else "yellow" if sc >= 30 else "green"
        st = a.get("status", "offline")
        st_txt = "[green]● online[/green]" if st == "online" else f"[red]○ {st}[/red]"
        t.add_row(
            str(a.get("agent_id", "?"))[:18],
            a.get("hostname") or a.get("label") or "?",
            st_txt,
            f"[{sc_s}]{sc}[/{sc_s}]",
            str(a.get("anomalies_24h", 0)),
            str(a.get("critical_vulns", 0)),
        )
    console.print(t)


# ── Threat score ───────────────────────────────────────────────────────────────

@app.command(name="threat-score")
def threat_score():
    """Show AI threat score ranking for all agents (highest risk first)."""
    from . import api_client as api
    from rich.table import Table
    from rich import box

    with console.status("[cyan]Computing threat scores...[/cyan]"):
        try:
            data = api.fleet_stats()
        except api.APIError as e:
            console.print(f"[red]Error {e.status_code}:[/red] {e.message}")
            raise typer.Exit(1)

    agent_scores = data.get("agents") or []
    t = Table(title="[bold red]Threat Score Ranking[/bold red]", box=box.ROUNDED, header_style="bold dim")
    t.add_column("#", style="dim", width=4)
    t.add_column("Agent", style="dim", max_width=20)
    t.add_column("Hostname")
    t.add_column("Score", justify="center", width=8)
    t.add_column("Risk Level", justify="center")

    for i, a in enumerate(sorted(agent_scores, key=lambda x: x.get("score", 0), reverse=True), 1):
        sc = a.get("score", 0)
        if sc >= 70:
            level = "[bold red]CRITICAL[/bold red]"
        elif sc >= 40:
            level = "[yellow]HIGH[/yellow]"
        elif sc >= 15:
            level = "[dim yellow]MEDIUM[/dim yellow]"
        else:
            level = "[green]LOW[/green]"
        t.add_row(str(i), str(a.get("agent_id", "?"))[:18],
                  a.get("hostname") or a.get("label") or "?", str(sc), level)
    console.print(t)


# ── Timeline ───────────────────────────────────────────────────────────────────

@app.command()
def timeline(
    agent_id: str = typer.Argument(..., help="Agent ID"),
    limit: int = typer.Option(30, "--limit", "-n", help="Number of events (default: 30)"),
):
    """Show chronological security event timeline for an agent."""
    from . import api_client as api
    from .display import _ts
    from rich.table import Table
    from rich import box

    with console.status(f"[cyan]Loading timeline for {agent_id}...[/cyan]"):
        try:
            events = api.get_agent_timeline(agent_id, limit=limit)
        except api.APIError as e:
            console.print(f"[red]Error {e.status_code}:[/red] {e.message}")
            raise typer.Exit(1)

    if not events:
        console.print("[dim]No events found.[/dim]")
        return

    t = Table(title=f"[bold cyan]Timeline — {agent_id}[/bold cyan]",
              box=box.ROUNDED, header_style="bold dim")
    t.add_column("Time", style="dim", width=17)
    t.add_column("Type", style="cyan", width=15)
    t.add_column("Severity", width=10)
    t.add_column("Details")

    for e in events:
        sev = (e.get("severity") or "info").upper()
        sev_s = {"CRITICAL": "bold red", "HIGH": "red", "MEDIUM": "yellow", "LOW": "dim"}.get(sev, "dim")
        t.add_row(
            _ts(e.get("timestamp") or e.get("created_at")),
            e.get("type") or e.get("event_type") or "—",
            f"[{sev_s}]{sev}[/{sev_s}]",
            (e.get("details") or e.get("description") or e.get("message") or "")[:80],
        )
    console.print(t)


# ── Baseline ───────────────────────────────────────────────────────────────────

@app.command()
def baseline(
    agent_id: str = typer.Argument(..., help="Agent ID"),
    output: Optional[str] = typer.Option(None, "--output", "-o", help="Output file (default: <agent_id>-baseline.json)"),
):
    """Snapshot current agent state to a local JSON baseline file."""
    from . import api_client as api
    import json
    from datetime import datetime

    out_path = output or f"{agent_id}-baseline.json"
    with console.status(f"[cyan]Capturing baseline for {agent_id}...[/cyan]"):
        try:
            agent_data = api.get_agent(agent_id)
            anomalies = api.get_agent_anomalies(agent_id, limit=50)
            vulns = api.get_agent_vulns(agent_id)
        except api.APIError as e:
            console.print(f"[red]Error {e.status_code}:[/red] {e.message}")
            raise typer.Exit(1)

    snapshot = {
        "agent_id": agent_id,
        "captured_at": datetime.utcnow().isoformat() + "Z",
        "agent": agent_data,
        "anomalies": anomalies,
        "vulns": vulns,
    }
    with open(out_path, "w") as f:
        json.dump(snapshot, f, indent=2, default=str)

    console.print(f"[green]Baseline saved →[/green] [bold]{out_path}[/bold]")
    console.print(f"[dim]{len(anomalies)} anomalies  ·  {len(vulns)} vulns captured[/dim]")


# ── Diff ───────────────────────────────────────────────────────────────────────

@app.command()
def diff(
    agent_id: str = typer.Argument(..., help="Agent ID"),
    baseline_file: str = typer.Option(..., "--baseline", "-b", help="Baseline JSON file to compare against"),
):
    """Compare current agent state against a previously saved baseline."""
    from . import api_client as api
    import json
    from rich.table import Table
    from rich import box

    try:
        with open(baseline_file) as f:
            snap = json.load(f)
    except FileNotFoundError:
        console.print(f"[red]Baseline file not found:[/red] {baseline_file}")
        raise typer.Exit(1)

    with console.status(f"[cyan]Fetching current state for {agent_id}...[/cyan]"):
        try:
            current = api.get_agent(agent_id)
            current_anomalies = api.get_agent_anomalies(agent_id, limit=50)
        except api.APIError as e:
            console.print(f"[red]Error {e.status_code}:[/red] {e.message}")
            raise typer.Exit(1)

    snap_agent = snap.get("agent", {})
    snap_anomalies = snap.get("anomalies", [])
    captured_at = snap.get("captured_at", "?")

    console.print(f"\n[bold cyan]Diff — {agent_id}[/bold cyan]  [dim]baseline: {captured_at}[/dim]\n")

    changed = [(f, snap_agent.get(f), current.get(f))
               for f in ["hostname", "ip", "ip_external", "os", "version", "is_isolated", "label"]
               if snap_agent.get(f) != current.get(f)]

    if changed:
        t = Table(title="[yellow]Agent State Changes[/yellow]", box=box.ROUNDED, header_style="bold dim")
        t.add_column("Field")
        t.add_column("Baseline")
        t.add_column("Current")
        for field, old, new in changed:
            t.add_row(field, str(old), f"[yellow]{new}[/yellow]")
        console.print(t)
    else:
        console.print("[green]No agent state changes.[/green]")

    old_ids = {a.get("id") for a in snap_anomalies}
    new_anomalies = [a for a in current_anomalies if a.get("id") not in old_ids]
    resolved = len([a for a in snap_anomalies if a.get("id") not in {x.get("id") for x in current_anomalies}])
    console.print(f"\n[bold]Anomalies:[/bold] [red]+{len(new_anomalies)} new[/red]  [green]-{resolved} resolved[/green]")


# ── Group-run ──────────────────────────────────────────────────────────────────

@app.command(name="group-run")
def group_run(
    group_id: str = typer.Argument(..., help="Group ID"),
    command: str = typer.Argument(..., help="Command to run on all agents in the group"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
):
    """Run a shell command on all agents in a group."""
    from . import api_client as api
    from rich.table import Table
    from rich import box

    with console.status(f"[cyan]Fetching agents in group {group_id}...[/cyan]"):
        try:
            group_agents = api.list_group_agents(group_id)
        except api.APIError as e:
            console.print(f"[red]Error {e.status_code}:[/red] {e.message}")
            raise typer.Exit(1)

    if not group_agents:
        console.print("[yellow]No agents in this group.[/yellow]")
        raise typer.Exit()

    agent_ids = [str(a.get("agent_id") or a.get("id") or "") for a in group_agents if a.get("agent_id") or a.get("id")]
    console.print(f"[bold]{len(agent_ids)} agents[/bold] in group [cyan]{group_id}[/cyan]")

    if not force:
        typer.confirm(f"Run '{command}' on {len(agent_ids)} agents?", abort=True)

    t = Table(box=box.ROUNDED, header_style="bold dim")
    t.add_column("Agent", style="dim", max_width=20)
    t.add_column("Output")

    for aid in agent_ids:
        with console.status(f"[cyan]Running on {aid}...[/cyan]"):
            try:
                result = api.run_command(aid, command)
                output = (result.get("output") or result.get("result") or "")[:100]
                t.add_row(aid[:18], output or "[dim]OK[/dim]")
            except api.APIError as e:
                t.add_row(aid[:18], f"[red]Error {e.status_code}[/red]")
    console.print(t)


# ── Export ────────────────────────────────────────────────────────────────────

@app.command()
def export(
    resource: str = typer.Argument(..., help="agents | alerts | anomalies | iocs | audit | all"),
    fmt: str = typer.Option("json", "--format", "-f", help="Output format: json | csv"),
    output: Optional[str] = typer.Option(None, "--output", "-o", help="Output file (default: <resource>.<format>)"),
    agent_id: Optional[str] = typer.Option(None, "--agent", "-a", help="Filter by agent ID"),
    limit: int = typer.Option(100, "--limit", "-n", help="Max rows (default: 100)"),
):
    """Export platform data to JSON or CSV."""
    from . import api_client as api
    import json, csv, io

    valid = {"agents", "alerts", "anomalies", "iocs", "audit", "all"}
    if resource not in valid:
        console.print(f"[red]Invalid resource.[/red] Choose: {', '.join(sorted(valid))}")
        raise typer.Exit(1)

    with console.status(f"[cyan]Exporting {resource}...[/cyan]"):
        try:
            data = api.export_resource(resource, fmt=fmt, limit=limit, agent_id=agent_id)
        except api.APIError as e:
            console.print(f"[red]Error {e.status_code}:[/red] {e.message}")
            raise typer.Exit(1)

    out_path = output or f"{resource}.{fmt}"
    rows = data if isinstance(data, list) else (list(data.values())[0] if isinstance(data, dict) else [])

    if fmt == "csv":
        if not rows:
            console.print("[yellow]No data.[/yellow]")
            raise typer.Exit()
        fields = list(rows[0].keys())
        buf = io.StringIO()
        writer = csv.DictWriter(buf, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)
        content = buf.getvalue()
    else:
        content = json.dumps(data, indent=2, default=str)

    with open(out_path, "w") as f:
        f.write(content)
    console.print(f"[green]Exported →[/green] [bold]{out_path}[/bold]  [dim]{len(rows) if isinstance(rows, list) else '?'} rows[/dim]")


# ── 2FA ────────────────────────────────────────────────────────────────────────

tfa_app = typer.Typer(name="2fa", help="Two-factor authentication management.", no_args_is_help=True)
app.add_typer(tfa_app)


@tfa_app.command("status")
def tfa_status():
    """Show 2FA status for the current user."""
    from . import api_client as api

    try:
        data = api.get_2fa_status()
    except api.APIError as e:
        console.print(f"[red]Error {e.status_code}:[/red] {e.message}")
        raise typer.Exit(1)

    enabled = data.get("enabled") or data.get("totp_enabled") or False
    backup_codes = data.get("backup_codes_count") or data.get("remaining_backup_codes") or 0
    style = "green" if enabled else "red"
    console.print(f"2FA: [{style}]{'enabled' if enabled else 'disabled'}[/{style}]")
    if enabled:
        console.print(f"[dim]Backup codes remaining: {backup_codes}[/dim]")
    else:
        console.print("[dim]Enable via: pivotra login → Profile → Security[/dim]")


# ── Personal API tokens ───────────────────────────────────────────────────────

token_app = typer.Typer(name="token", help="Manage personal API tokens.", no_args_is_help=True)
app.add_typer(token_app)


@token_app.command("list")
def token_list(json_out: bool = typer.Option(False, "--json")):
    """List your active API tokens."""
    from . import api_client as api
    from rich.table import Table
    from rich import box
    tokens = api.list_tokens()
    if json_out:
        import json; console.print_json(json.dumps(tokens))
        return
    t = Table(box=box.ROUNDED, header_style="bold dim")
    t.add_column("ID", style="dim", width=6)
    t.add_column("Name", style="cyan")
    t.add_column("Prefix", style="yellow")
    t.add_column("Created", style="dim")
    t.add_column("Expires", style="dim")
    t.add_column("Last used", style="dim")
    for tok in tokens:
        t.add_row(
            str(tok.get("id") or "?"),
            tok.get("name") or "?",
            tok.get("prefix") or "?",
            (tok.get("created_at") or "")[:16],
            (tok.get("expires_at") or "never")[:16],
            (tok.get("last_used_at") or "never")[:16],
        )
    console.print(t)
    console.print(f"[dim]{len(tokens)} token(s)[/dim]")


@token_app.command("create")
def token_create(
    name: str = typer.Argument(..., help="Token name (e.g. 'ci-pipeline')"),
    expires: int = typer.Option(None, "--expires", "-e", help="Expiry in days (default: never)"),
):
    """Create a new API token. The full token is shown ONCE — save it immediately."""
    from . import api_client as api
    result = api.create_token(name=name, expires_days=expires)
    token_val = result.get("token") or "?"
    tok_id    = result.get("id") or "?"
    expires_at = result.get("expires_at") or "never"
    console.print(f"\n[bold green]Token created.[/bold green] ID: [cyan]{tok_id}[/cyan]")
    console.print(f"[bold yellow]{token_val}[/bold yellow]")
    console.print(f"[dim]Expires: {expires_at}[/dim]")
    console.print(f"[red]Save this token now — it will NOT be shown again.[/red]")


@token_app.command("revoke")
def token_revoke(
    token_id: int = typer.Argument(..., help="Token ID to revoke"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
):
    """Revoke (permanently deactivate) an API token."""
    from . import api_client as api
    if not yes:
        typer.confirm(f"Revoke token {token_id}?", abort=True)
    api.revoke_token(token_id)
    console.print(f"[green]Token {token_id} revoked.[/green]")


@token_app.command("use")
def token_use(
    pvt_token: str = typer.Argument(..., help="Personal API token (pvt_xxx)"),
    url: str = typer.Option(None, "--url", "-u", help="Override base URL (default: https://demo.pivotraai.ai)"),
):
    """Store a personal API token as active credential (replaces browser login)."""
    from .auth import set_api_token
    set_api_token(pvt_token, base_url=url)


# ── Version ───────────────────────────────────────────────────────────────────

@app.command()
def version():
    """Show CLI version."""
    console.print(f"[bold cyan]pivotra[/bold cyan] v{__version__}")


# ── Entry point ───────────────────────────────────────────────────────────────

def main():
    app()


if __name__ == "__main__":
    main()
