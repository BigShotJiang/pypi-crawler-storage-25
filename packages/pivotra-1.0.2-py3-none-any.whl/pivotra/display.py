"""
Rich-based display helpers for Pivotra CLI.
"""
from __future__ import annotations

from datetime import datetime
from typing import Any

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich import box
from rich.text import Text

console = Console()

# Brand colors
C_PRIMARY = "cyan"
C_ONLINE  = "green"
C_OFFLINE = "red"
C_WARN    = "yellow"
C_CRIT    = "bold red"
C_DIM     = "dim"
C_BRO     = "bold magenta"


def _ts(ts: Any) -> str:
    """Format ISO timestamp to short human-readable."""
    if not ts:
        return "—"
    try:
        if isinstance(ts, str):
            dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
        else:
            dt = datetime.fromtimestamp(ts)
        return dt.strftime("%Y-%m-%d %H:%M")
    except Exception:
        return str(ts)[:16]


def agent_table(agents: list[dict]) -> None:
    """Print full agent fleet table."""
    t = Table(
        title=f"[bold cyan]Fleet — {len(agents)} agents[/bold cyan]",
        box=box.ROUNDED,
        header_style="bold dim",
        show_lines=False,
    )
    t.add_column("ID",       style="dim", max_width=20)
    t.add_column("Hostname", style="bold")
    t.add_column("Status",   justify="center", width=8)
    t.add_column("OS",       style="dim")
    t.add_column("IP",       style="dim")
    t.add_column("Last Seen")

    for a in agents:
        online = a.get("online", False) or a.get("status") == "online"
        status = Text("● online", style=C_ONLINE) if online else Text("○ offline", style=C_OFFLINE)
        t.add_row(
            str(a.get("id", "?"))[:18],
            a.get("hostname") or a.get("name") or "?",
            status,
            a.get("os") or a.get("platform") or "—",
            a.get("ip") or a.get("ip_address") or "—",
            _ts(a.get("last_seen") or a.get("last_heartbeat")),
        )
    console.print(t)


def agent_detail(a: dict) -> None:
    """Print single agent detail panel."""
    online = a.get("online", False) or a.get("status") == "online"
    status_str = "[green]● online[/green]" if online else "[red]○ offline[/red]"
    lines = [
        f"[bold]Hostname:[/bold]   {a.get('hostname') or '?'}",
        f"[bold]Status:[/bold]     {status_str}",
        f"[bold]OS:[/bold]         {a.get('os') or '—'}",
        f"[bold]IP:[/bold]         {a.get('ip') or a.get('ip_address') or '—'}",
        f"[bold]Version:[/bold]    {a.get('version') or '—'}",
        f"[bold]Last seen:[/bold]  {_ts(a.get('last_seen') or a.get('last_heartbeat'))}",
        f"[bold]Isolated:[/bold]   {'[red]YES[/red]' if a.get('isolated') else 'no'}",
    ]
    console.print(Panel("\n".join(lines),
                        title=f"[bold cyan]{a.get('id', '?')}[/bold cyan]",
                        border_style="cyan"))


def logs_table(logs: list[dict]) -> None:
    t = Table(box=box.SIMPLE, header_style="bold dim", show_edge=False)
    t.add_column("Time",    style="dim", width=17)
    t.add_column("Source",  style="cyan", width=12)
    t.add_column("Level",   width=8)
    t.add_column("Message")
    for l in logs:
        lvl = l.get("level", "info").upper()
        lvl_style = {"ERROR": "red", "WARN": "yellow", "WARNING": "yellow",
                     "CRITICAL": "bold red"}.get(lvl, "dim")
        t.add_row(
            _ts(l.get("timestamp") or l.get("created_at")),
            l.get("source") or "—",
            Text(lvl, style=lvl_style),
            l.get("message") or l.get("msg") or "—",
        )
    console.print(t)


def anomalies_table(anomalies: list[dict], agent_id: str = "") -> None:
    title = f"[bold red]Anomalies[/bold red]" + (f" — {agent_id}" if agent_id else "")
    t = Table(title=title, box=box.ROUNDED, header_style="bold dim")
    t.add_column("Time",     style="dim", width=17)
    t.add_column("Severity", width=10)
    t.add_column("Type",     style="cyan")
    t.add_column("Details")
    for a in anomalies:
        sev = a.get("severity", "medium").upper()
        sev_style = {"CRITICAL": "bold red", "HIGH": "red",
                     "MEDIUM": "yellow", "LOW": "dim"}.get(sev, "dim")
        t.add_row(
            _ts(a.get("timestamp") or a.get("detected_at")),
            Text(sev, style=sev_style),
            a.get("type") or a.get("anomaly_type") or "—",
            (a.get("details") or a.get("description") or "")[:100],
        )
    if not anomalies:
        console.print("[green]No anomalies.[/green]")
    else:
        console.print(t)


def alerts_table(alerts: list[dict]) -> None:
    t = Table(title="[bold yellow]Alerts[/bold yellow]",
              box=box.ROUNDED, header_style="bold dim")
    t.add_column("Time",     style="dim", width=17)
    t.add_column("Severity", width=10)
    t.add_column("Agent",    style="cyan")
    t.add_column("Message")
    for a in alerts:
        sev = a.get("severity", "medium").upper()
        sev_style = {"CRITICAL": "bold red", "HIGH": "red",
                     "MEDIUM": "yellow", "LOW": "dim"}.get(sev, "dim")
        t.add_row(
            _ts(a.get("timestamp") or a.get("created_at")),
            Text(sev, style=sev_style),
            str(a.get("agent_id") or "—"),
            (a.get("message") or a.get("title") or "")[:80],
        )
    console.print(t)


def processes_table(procs: list[dict]) -> None:
    t = Table(box=box.SIMPLE, header_style="bold dim", show_edge=False)
    t.add_column("PID",     style="dim", width=8)
    t.add_column("Name",    style="bold")
    t.add_column("CPU%",    width=7)
    t.add_column("MEM%",    width=7)
    t.add_column("User",    style="dim")
    t.add_column("Command", style="dim")
    for p in procs[:40]:
        t.add_row(
            str(p.get("pid", "?")),
            p.get("name") or "—",
            f"{p.get('cpu_percent', 0):.1f}",
            f"{p.get('mem_percent', 0):.1f}",
            p.get("username") or "—",
            (p.get("cmdline") or "")[:50],
        )
    console.print(t)


def connections_table(conns: list[dict]) -> None:
    t = Table(box=box.SIMPLE, header_style="bold dim", show_edge=False)
    t.add_column("Proto",  width=6)
    t.add_column("Local",  style="cyan")
    t.add_column("Remote")
    t.add_column("State",  style="dim")
    t.add_column("PID",    width=8, style="dim")
    for c in conns[:40]:
        t.add_row(
            c.get("type") or "tcp",
            c.get("laddr") or "—",
            c.get("raddr") or "—",
            c.get("status") or "—",
            str(c.get("pid") or "—"),
        )
    console.print(t)


def bro_header(online_count: int, total: int, anomaly_count: int) -> None:
    """Print BRO REPL welcome header."""
    console.print(Panel(
        f"[bold magenta]BRO-IA[/bold magenta] v1.0  ·  "
        f"Fleet: [green]{online_count}[/green]/[dim]{total}[/dim] agents online  ·  "
        f"Anomalies: [{'red' if anomaly_count else 'green'}]{anomaly_count}[/{'red' if anomaly_count else 'green'}]\n"
        f"[dim]Type your question in French or English. 'exit' to quit. 'clear' to clear.[/dim]",
        border_style="magenta",
        title="[bold magenta]BRO AI Assistant[/bold magenta]",
    ))


def print_action_prompt(action: str) -> bool:
    """Show action confirmation prompt. Returns True if confirmed."""
    console.print(f"\n[bold yellow]  Action detected:[/bold yellow] [cyan]{action}[/cyan]")
    response = console.input("  [bold]Execute?[/bold] [dim][y/N][/dim] ").strip().lower()
    return response in ("y", "yes", "oui", "o")
