import os
import time
import threading
import subprocess
import sys
import platform
import shutil
import requests
import litellm
from strands import Agent
from strands.models.llamacpp import LlamaCppModel
from rich.console import Console
from config import load_config, config_exists, run_setup_wizard

os.environ["LITELLM_LOCAL_MODEL_COST_MAP"] = "True"
os.environ["LITELLM_REQUEST_TIMEOUT"] = "30"

litellm.suppress_debug_info = True
litellm.set_verbose = False

console = Console()

_lock = threading.Lock()
_server_started = False

# ── Load config ───────────────────────────────────────────
if not config_exists():
    run_setup_wizard()

_config = load_config()
MODEL_PATH = _config.get("model_path", "")
SERVER_URL = _config.get("server_url", "http://localhost:8080")
MODE = _config.get("mode", "local")
# ─────────────────────────────────────────────────────────


def print_typewriter(text: str, delay: float = 0.02):
    for char in text:
        print(char, end="", flush=True)
        time.sleep(delay)
    print()


def get_system() -> str:
    return platform.system().lower()


def find_llama_server() -> list | None:
    """Auto-detect correct way to start llama server on any OS."""
    system = get_system()

    # ── Option 1: llama-server binary ──
    binary_names = ["llama-server", "llama_server"]
    if system == "windows":
        binary_names = ["llama-server.exe", "llama_server.exe"]

    for binary in binary_names:
        path = shutil.which(binary)
        if path:
            console.print(f"[SERVER] Found binary: {path}")
            return [path]

    # ── Option 2: llama_cpp.server module ──
    try:
        result = subprocess.run(
            [sys.executable, "-c", "import llama_cpp.server; print('ok')"],
            capture_output=True, timeout=10
        )
        if b"ok" in result.stdout:
            return [sys.executable, "-m", "llama_cpp.server"]
    except:
        pass

    # ── Option 3: llama_cpp.server.app ──
    try:
        result = subprocess.run(
            [sys.executable, "-c", "from llama_cpp.server.app import create_app; print('ok')"],
            capture_output=True, timeout=10
        )
        if b"ok" in result.stdout:
            return [sys.executable, "-m", "llama_cpp.server"]
    except:
        pass

    # ── Option 4: llama_cpp direct ──
    try:
        result = subprocess.run(
            [sys.executable, "-c", "import llama_cpp; print('ok')"],
            capture_output=True, timeout=10
        )
        if b"ok" in result.stdout:
            console.print("[SERVER] Using llama_cpp direct mode...")
            return ["direct"]
    except:
        pass

    return None


def get_server_command(base: list) -> list:
    """Add OS-specific GPU flags."""
    system = get_system()
    cmd = base + [
        "--model", MODEL_PATH,
        "--host", "0.0.0.0",
        "--port", "8080",
        "--n_threads", str(min(os.cpu_count() or 4, 8)),
        "--n_ctx", "4096",
    ]

    if system == "darwin":
        try:
            result = subprocess.run(
                ["system_profiler", "SPDisplaysDataType"],
                capture_output=True, text=True, timeout=5
            )
            if "Apple" in result.stdout:
                cmd += ["--n_gpu_layers", "1"]
        except:
            pass

    elif system == "linux":
        try:
            subprocess.run(["nvidia-smi"], capture_output=True, check=True, timeout=5)
            cmd += ["--n_gpu_layers", "32"]
        except:
            pass

    return cmd


def install_llama_server():
    """Auto install llama-cpp-python with correct flags per OS."""
    console.print("[SERVER] Installing llama-cpp-python...")
    system = get_system()

    if system == "darwin":
        env = {**os.environ, "CMAKE_ARGS": "-DLLAMA_METAL=on"}
        subprocess.run(
            [sys.executable, "-m", "pip", "install",
             "llama-cpp-python", "--upgrade", "--force-reinstall"],
            env=env
        )
    elif system == "linux":
        try:
            subprocess.run(["nvidia-smi"], capture_output=True, check=True)
            env = {**os.environ, "CMAKE_ARGS": "-DLLAMA_CUDA=on"}
            subprocess.run(
                [sys.executable, "-m", "pip", "install",
                 "llama-cpp-python", "--upgrade", "--force-reinstall"],
                env=env
            )
        except:
            subprocess.run(
                [sys.executable, "-m", "pip", "install",
                 "llama-cpp-python", "--upgrade", "--force-reinstall"]
            )
    else:
        subprocess.run(
            [sys.executable, "-m", "pip", "install",
             "llama-cpp-python", "--upgrade", "--force-reinstall"]
        )


def _start_direct_server():
    """Start llama server directly in a thread."""
    global _server_started

    def run():
        try:
            from llama_cpp.server.app import create_app
            import uvicorn
            app = create_app()
            uvicorn.run(app, host="0.0.0.0", port=8080, log_level="error")
        except ImportError:
            try:
                from llama_cpp.server import app
                import uvicorn
                uvicorn.run(app, host="0.0.0.0", port=8080, log_level="error")
            except Exception as e:
                console.print(f"[bold red][SERVER][/bold red] ❌ Direct mode failed: {e}")

    t = threading.Thread(target=run, daemon=True)
    t.start()

    console.print("[SERVER] Starting in direct mode...")
    for i in range(40):
        for endpoint in [f"{SERVER_URL}/health", f"{SERVER_URL}/v1/models", f"{SERVER_URL}/"]:
            try:
                r = requests.get(endpoint, timeout=2)
                if r.status_code in (200, 404):
                    console.print("[SERVER] ✅ Model ready!")
                    _server_started = True
                    return
            except:
                pass
        time.sleep(3)
        if i % 5 == 0 and i > 0:
            console.print(f"[SERVER] Still loading... ({i * 3}s)")

    raise RuntimeError("❌ Direct server failed to start.")


def start_server():
    global _server_started
    if _server_started:
        return

    if MODE != "local":
        console.print("[SERVER] Using cloud model — no local server needed ✅")
        _server_started = True
        return

    # ── Validate model path ──
    if not MODEL_PATH or not os.path.exists(MODEL_PATH):
        console.print(f"[bold red][SERVER][/bold red] ❌ Model not found: {MODEL_PATH}")
        console.print(f"[bold red][SERVER][/bold red] Delete ~/.hdfc_ai/config.json and restart.")
        sys.exit(1)

    # ── Check if already running ──
    try:
        r = requests.get(f"{SERVER_URL}/health", timeout=2)
        if r.status_code == 200:
            console.print("[SERVER] ✅ Server already running!")
            _server_started = True
            return
    except:
        pass

    # ── Find server command ──
    base_cmd = find_llama_server()

    if base_cmd is None:
        console.print("[SERVER] llama-cpp-python not found — installing automatically...")
        install_llama_server()
        base_cmd = find_llama_server()

    if base_cmd is None:
        console.print("[bold red][SERVER][/bold red] ❌ Could not find or install llama server.")
        console.print("[bold red][SERVER][/bold red] Please run: pip install llama-cpp-python")
        sys.exit(1)

    # ── Direct mode ──
    if base_cmd == ["direct"]:
        _start_direct_server()
        return

    cmd = get_server_command(base_cmd)
    system = get_system()

    console.print("[SERVER] Starting llama-server in background...")

    try:
        if system == "windows":
            subprocess.Popen(
                cmd,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        else:
            subprocess.Popen(
                cmd,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                start_new_session=True,
                close_fds=True,
                env={**os.environ, "PYTHONUNBUFFERED": "1"}
            )
    except Exception as e:
        console.print(f"[bold red][SERVER][/bold red] ❌ Failed to start: {e}")
        sys.exit(1)

    # ── Wait for server ──
    max_retries = 80
    console.print("[SERVER] Waiting for model to load...")
    health_endpoints = [
        f"{SERVER_URL}/health",
        f"{SERVER_URL}/v1/models",
        f"{SERVER_URL}/",
    ]

    for i in range(max_retries):
        for endpoint in health_endpoints:
            try:
                r = requests.get(endpoint, timeout=2)
                if r.status_code in (200, 404):
                    console.print("[SERVER] ✅ Model ready!")
                    _server_started = True
                    return
            except:
                pass
        time.sleep(3)
        if i % 5 == 0 and i > 0:
            console.print(f"[SERVER] Still loading... ({i * 3}s elapsed)")

    raise RuntimeError(
        "❌ Server failed to start.\n"
        "Possible reasons:\n"
        "  1. Not enough RAM (need at least 8GB free)\n"
        "  2. Model file corrupted — re-download it\n"
        "  3. Port 8080 already in use\n"
        "Fix: delete ~/.hdfc_ai/config.json and restart"
    )


def ask_model(prompt: str, system: str = "") -> str:
    with _lock:
        if MODE == "local":
            model = LlamaCppModel(
                base_url=SERVER_URL,
                params={
                    "temperature": 0.2,
                    "max_tokens": 4096,
                }
            )
            agent = Agent(
                model=model,
                system_prompt=system if system else "You are HDFC_AI, a smart coding assistant.",
                callback_handler=None
            )
            response = agent(prompt)
            return str(response).strip()

        model_map = {
            "claude":  "claude-3-5-sonnet-20241022",
            "gpt4":    "gpt-4",
            "mistral": "mistral/mistral-7b-instruct",
        }
        messages = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})

        response = litellm.completion(
            model=model_map.get(MODE, "gpt-4"),
            messages=messages,
            temperature=0.2,
            max_tokens=4096,
        )
        return response.choices[0].message.content.strip()