"""Predefined persona library for *team* members.

Personas are stored as individual YAML files under the ``personas/`` directory
at the root of this repository (one file per persona, filename = key).  The
library is loaded lazily the first time it is needed.

Users can **add their own personas** by:

1. Dropping a YAML file into the built-in ``personas/`` directory (good for
   contributing back to the project).
2. Setting the ``TEAM_PERSONA_DIR`` environment variable to a custom directory
   that is scanned *in addition to* the built-in directory.  Files in the
   custom directory take precedence over built-in ones with the same key.

Each YAML file must have the following top-level keys:

.. code-block:: yaml

    role: Principal Investigator
    description: One-line summary shown in ``team personas``.
    persona: |
      Full persona text injected into the system prompt.

Members reference a library persona in their YAML with an ``@``-prefixed key::

    members:
      - name: alice
        model: llama3.1:70b
        persona: "@pi"         # expands role + persona text from personas/pi.yaml

The ``role`` field is optional when a library persona is used — the library's
default role is applied automatically.  You may still override it::

    members:
      - name: alice
        model: llama3.1:70b
        persona: "@pi"
        role: "Lab Director"   # overrides the library's "Principal Investigator"
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

import yaml

# --------------------------------------------------------------------------- #
# Paths
# --------------------------------------------------------------------------- #

# Built-in personas directory — sibling of this file's package root.
_BUILTIN_DIR = Path(__file__).parent.parent / "personas"


def _persona_dirs() -> list[Path]:
    """Return the list of directories to scan for persona YAML files.

    Custom dirs (from ``TEAM_PERSONA_DIR``) are listed first so they override
    built-in personas with the same key.
    """
    dirs: list[Path] = []
    env = os.environ.get("TEAM_PERSONA_DIR", "").strip()
    if env:
        custom = Path(env).expanduser().resolve()
        if custom.is_dir():
            dirs.append(custom)
    if _BUILTIN_DIR.is_dir():
        dirs.append(_BUILTIN_DIR)
    return dirs


# --------------------------------------------------------------------------- #
# Loading
# --------------------------------------------------------------------------- #

_CACHE: dict[str, dict[str, str]] | None = None


def _load() -> dict[str, dict[str, str]]:
    """Scan all persona directories and return the merged PERSONAS dict.

    Results are cached after the first call.  Set ``_CACHE = None`` to force
    a reload (useful in tests).
    """
    global _CACHE
    if _CACHE is not None:
        return _CACHE

    personas: dict[str, dict[str, str]] = {}
    # Process built-in dir last so custom dirs take precedence.
    for directory in reversed(_persona_dirs()):
        for yaml_path in sorted(directory.glob("*.yaml")):
            key = yaml_path.stem
            try:
                raw: Any = yaml.safe_load(yaml_path.read_text(encoding="utf-8"))
            except Exception as exc:  # noqa: BLE001
                # Skip unreadable / malformed files with a warning.
                import warnings
                warnings.warn(
                    f"team persona_library: skipping {yaml_path} — {exc}",
                    stacklevel=2,
                )
                continue
            if not isinstance(raw, dict):
                continue
            missing = [f for f in ("role", "description", "persona") if f not in raw]
            if missing:
                import warnings
                warnings.warn(
                    f"team persona_library: {yaml_path} missing fields {missing} — skipped",
                    stacklevel=2,
                )
                continue
            personas[key] = {
                "role": str(raw["role"]).strip(),
                "description": str(raw["description"]).strip(),
                "persona": str(raw["persona"]).strip(),
            }

    _CACHE = personas
    return _CACHE


# --------------------------------------------------------------------------- #
# Convenience shim — PERSONAS behaves like a dict but loads lazily
# --------------------------------------------------------------------------- #

class _LazyPersonas:
    """Proxy that loads persona files on first access."""

    def __getitem__(self, key: str) -> dict[str, str]:
        return _load()[key]

    def __contains__(self, key: object) -> bool:
        return key in _load()

    def __iter__(self):
        return iter(_load())

    def keys(self):
        return _load().keys()

    def values(self):
        return _load().values()

    def items(self):
        return _load().items()

    def get(self, key: str, default=None):
        return _load().get(key, default)


PERSONAS = _LazyPersonas()


# --------------------------------------------------------------------------- #
# Public API
# --------------------------------------------------------------------------- #


def resolve(name: str) -> tuple[str, str]:
    """Return ``(role, persona_text)`` for a library key, or raise :exc:`KeyError`."""
    entry = _load()[name]
    return entry["role"], entry["persona"]


def list_all() -> list[dict[str, str]]:
    """Return a list of dicts (``key``, ``role``, ``description``) for all personas."""
    return [
        {"key": k, "role": v["role"], "description": v["description"]}
        for k, v in _load().items()
    ]

