"""System-prompt rendering for team members.

Each member receives a system prompt that:

* States its identity (name + role) and persona.
* Describes the team goal and the other members it can address.
* Documents the small "protocol" the orchestrator understands so the
  member can address peers, write files, and signal completion.
* When the member has tools enabled, appends a tool-use protocol section.

Keeping the protocol tiny and explicit makes models far more reliable at
following it (especially smaller models).  See :func:`render_system_prompt`.
"""

from __future__ import annotations

from textwrap import dedent

from team.config import MemberConfig, TeamConfig

PROTOCOL = dedent(
    """\
    ## Collaboration protocol

    You are part of a TEAM.  At every turn, ONE member speaks; the others read
    the transcript and may speak on a later turn.  Always respect the protocol
    below — the orchestrator parses your reply mechanically.

    1. Begin your reply with one short sentence summarising your contribution.
    2. To explicitly address another member, prefix the relevant section with
       a line of the form `@<member-name>:` (lowercase, exact).  You may omit
       this if you are addressing the whole team.
    3. To create or overwrite a file in the SHARED workspace, use a fenced
       block with an `file:` info-string, e.g.

           ```file:report/intro.md
           # Introduction
           ...
           ```

       The orchestrator will atomically write the contents to that path under
       the shared workspace.  Paths must be relative and may not escape the
       workspace.  Any number of file blocks per reply is allowed.
    4. You also have a PRIVATE workspace (`/private` inside your container)
       for personal scratch files — drafts, notes, intermediate results — that
       are not shared with the team.  Files you create there persist between
       turns and are listed at the top of each of your turn prompts.
    5. To read an existing file, ask the team in plain text and a member with
       file access (or the orchestrator-provided context) will surface it.
       Recently written/changed files are listed at the top of every turn.
    6. When YOU believe the team's goal is fully achieved, end your reply
       with a line containing exactly: `[[TEAM_DONE]]`.
       Use this sparingly — only when the deliverables are complete and you
       have verified them.

    ## House rules
    * Be concrete.  Prefer artifacts (files, tables, code) over prose.
    * Disagree explicitly when warranted; reference earlier turns by member
      name.  Avoid sycophancy.
    * Stay strictly within your role; defer outside-scope work to the
      appropriate teammate.
    """
)

_TOOL_PROTOCOL_HEADER = dedent(
    """\
    ## Tool use

    You have access to external tools.  Invoke a tool by emitting a fenced
    block with a ``tool:<name>`` info-string **as your entire reply or as
    part of your reply**:

        ```tool:web_search
        query: your search query here
        ```

        ```tool:run_python
        import math
        print(math.sqrt(2))
        ```

    Rules:
    * After each tool block the orchestrator executes the tool and sends
      you the result as a follow-up message — you then continue reasoning.
    * You may call multiple tools across several rounds; each round counts
      against your turn budget.
    * Once you are done gathering information, write your **final reply in
      plain text** (no tool blocks) so it is recorded in the transcript.
    * Never invent tool results — always wait for the actual output.
    * **You have full system access.** If a library or CLI tool you need is
      not installed, install it first:

          ```tool:run_bash
          pip install scikit-learn seaborn --quiet
          ```

      Then proceed with the code that uses it.  You may also use
      ``apt-get install``, ``conda install``, ``npm install``, or any other
      package manager available on the system.

    Available tools:
    """
)


def _render_tool_section(
    tool_names: list[str],
    tool_descriptions: dict[str, str] | None = None,
) -> str:
    from team.tools import TOOL_DESCRIPTIONS  # local import to avoid circular

    descriptions = tool_descriptions if tool_descriptions is not None else TOOL_DESCRIPTIONS
    lines = [_TOOL_PROTOCOL_HEADER]
    for name in tool_names:
        desc = descriptions.get(name, TOOL_DESCRIPTIONS.get(name, "(no description)"))
        lines.append(f"    * ``{name}`` — {desc}")
    return "\n".join(lines)


def render_system_prompt(
    team: TeamConfig,
    member: MemberConfig,
    enabled_tools: list[str] | None = None,
    tool_descriptions: dict[str, str] | None = None,
) -> str:
    """Render the complete system prompt for *member*.

    Parameters
    ----------
    team:
        The full team configuration.
    member:
        The member whose system prompt is being rendered.
    enabled_tools:
        Names of built-in or skill tools this member may use.  When
        non-empty a tool-use protocol section is appended.  Pass ``None``
        or ``[]`` to omit the section.
    tool_descriptions:
        Merged tool descriptions dict (built-ins + skill tools).  Defaults
        to the built-in :data:`~team.tools.TOOL_DESCRIPTIONS` dict.
    """
    # Build the teammate list excluding the member itself.
    teammates = [
        f"- @{m.name} — {m.role}"
        for m in team.members
        if m.name != member.name
    ]
    teammate_block = "\n".join(teammates) if teammates else "- (you are working alone)"

    parts = [
        f"# You are @{member.name} — {member.role}",
        "",
        "## Persona",
        member.persona.strip(),
        "",
        "## Team goal",
        team.goal.strip(),
        "",
        "## Your teammates",
        teammate_block,
        "",
        PROTOCOL.strip(),
    ]
    # Append extra instructions last so they can override or extend the
    # boilerplate sections above without modifying the shared PROTOCOL constant.
    if member.extra_system:
        parts.extend(["", "## Additional instructions", member.extra_system.strip()])
    if getattr(member, "output_format", None) == "json":
        schema_hint = ""
        if getattr(member, "output_schema", None):
            import json as _json
            schema_hint = (
                "\n\nRequired JSON Schema:\n"
                f"```json\n{_json.dumps(member.output_schema, indent=2)}\n```"
            )
        parts.extend([
            "",
            "## Output format",
            (
                "**You must respond with valid JSON only.**  "
                "Do not include any prose, markdown formatting, or explanation "
                "outside the JSON structure.  Do not wrap the JSON in a code "
                "fence.  Your entire reply must be parseable by `json.loads()`."
                + schema_hint
            ),
        ])
    if enabled_tools:
        parts.extend(["", _render_tool_section(enabled_tools, tool_descriptions)])
    return "\n".join(parts)
