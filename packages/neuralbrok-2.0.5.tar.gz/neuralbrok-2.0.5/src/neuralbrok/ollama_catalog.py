"""
ollama_catalog.py — Live Ollama model library discovery.

Fetches the latest models from Ollama library and resolves them
against your hardware profile for smart model matching.
"""
import json
import logging
import re
from dataclasses import dataclass, field
from typing import Optional, List

import httpx

logger = logging.getLogger(__name__)

# ── Ollama Cloud models (run via `ollama run model:cloud`) ────────────────────
# These run in Ollama's cloud infra, not locally — no VRAM needed.
OLLAMA_CLOUD_MODELS = [
    {
        "tag": "gpt-oss:120b-cloud",
        "name": "GPT-OSS 120B",
        "params_b": 120.0,
        "description": "Open-source frontier performance — exceptional for complex reasoning & logic",
        "capabilities": ["chat", "reasoning", "math", "coding"],
        "context_k": 128,
        "tier": "flagship",
    },
    {
        "tag": "qwen3-coder:480b-cloud",
        "name": "Qwen3 Coder 480B",
        "params_b": 480.0,
        "description": "State-of-the-art coding and agentic performance — full-scale MoE",
        "capabilities": ["chat", "coding", "reasoning", "tools", "agentic"],
        "context_k": 128,
        "tier": "flagship",
    },
    {
        "tag": "kimi-k2.6:cloud",
        "name": "Kimi K2.6",
        "params_b": 1000.0,
        "description": "Moonshot AI flagship — 1T MoE, exceptional instruction following",
        "capabilities": ["chat", "coding", "reasoning", "tools", "agentic"],
        "context_k": 128,
        "tier": "flagship",
    },
    {
        "tag": "deepseek-r1:cloud",
        "name": "DeepSeek R1",
        "params_b": 671.0,
        "description": "DeepSeek R1 full via Ollama Cloud — frontier reasoning and STEM",
        "capabilities": ["chat", "reasoning", "math", "coding"],
        "context_k": 128,
        "tier": "flagship",
    },
    {
        "tag": "llama4-scout:cloud",
        "name": "Llama 4 Scout",
        "params_b": 109.0,
        "description": "Meta Llama 4 Scout — frontier vision + tool use, massive context",
        "capabilities": ["chat", "coding", "vision", "tools"],
        "context_k": 128,
        "tier": "standard",
    },
]

# ── Popular local model catalog (fallback if Ollama registry is unreachable) ──
KNOWN_LOCAL_MODELS = [
    # ── Llama family (confirmed tags from ollama.com/library) ─────────────────
    {"tag": "llama3.2:1b",            "params_b": 1.24,  "vram_gb": 0.9,   "capabilities": ['tools', 'chat', 'agentic']},
    {"tag": "llama3.2:3b",            "params_b": 3.21,  "vram_gb": 2.4,   "capabilities": ['tools', 'chat', 'agentic']},
    {"tag": "llama3.1:8b",            "params_b": 8.03,  "vram_gb": 5.5,   "capabilities": ['chat', 'agentic', 'coding', 'tools']},
    {"tag": "llama3.1:70b",           "params_b": 70.6,  "vram_gb": 43.7,  "capabilities": ['chat', 'agentic', 'coding', 'tools']},
    {"tag": "llama3.3:70b",           "params_b": 70.6,  "vram_gb": 43.7,  "capabilities": ['chat', 'agentic', 'coding', 'tools']},
    {"tag": "llama3.2-vision:11b",    "params_b": 10.6,  "vram_gb": 8.2,   "capabilities": ['tools', 'vision', 'chat', 'agentic']},
    {"tag": "llama3.2-vision:90b",    "params_b": 90.0,  "vram_gb": 56.0,  "capabilities": ['tools', 'vision', 'chat', 'agentic']},
    {"tag": "llama4:scout",           "params_b": 109,   "vram_gb": 66.1,  "capabilities": ['tools', 'vision', 'chat', 'agentic']},
    {"tag": "llama4:maverick",        "params_b": 400,   "vram_gb": 243.7, "capabilities": ['tools', 'vision', 'chat', 'agentic']},
    {"tag": "llava:7b",               "params_b": 7.0,   "vram_gb": 4.9,   "capabilities": ['vision', 'chat']},
    {"tag": "llava:13b",              "params_b": 13.0,  "vram_gb": 9.5,   "capabilities": ['vision', 'chat']},
    {"tag": "llava:34b",              "params_b": 34.0,  "vram_gb": 22.0,  "capabilities": ['vision', 'chat']},
    {"tag": "llava-llama3:8b",        "params_b": 8.0,   "vram_gb": 5.8,   "capabilities": ['vision', 'chat']},
    {"tag": "minicpm-v:8b",           "params_b": 8.0,   "vram_gb": 5.8,   "capabilities": ['vision', 'chat', 'tools']},
    {"tag": "moondream:1.8b",         "params_b": 1.8,   "vram_gb": 1.5,   "capabilities": ['vision', 'chat']},
    # ── Mistral / Mixtral family ──────────────────────────────────────────────
    {"tag": "mistral:7b",             "params_b": 7.24,  "vram_gb": 4.9,   "capabilities": ['tools', 'chat', 'coding']},
    {"tag": "mistral-nemo:12b",       "params_b": 12.2,  "vram_gb": 8.4,   "capabilities": ['tools', 'chat', 'agentic']},
    {"tag": "mistral-small3.1:24b",   "params_b": 23.6,  "vram_gb": 14.9,  "capabilities": ['chat', 'agentic', 'coding', 'vision', 'tools']},
    {"tag": "mistral-small3.2:24b",   "params_b": 23.6,  "vram_gb": 14.9,  "capabilities": ['chat', 'agentic', 'coding', 'vision', 'tools']},
    {"tag": "codestral:22b",          "params_b": 22.2,  "vram_gb": 14.2,  "capabilities": ['coding', 'chat', 'tools']},
    {"tag": "devstral:24b",           "params_b": 23.6,  "vram_gb": 14.9,  "capabilities": ['coding', 'agentic', 'chat', 'tools']},
    {"tag": "magistral:24b",          "params_b": 23.6,  "vram_gb": 14.9,  "capabilities": ['reasoning', 'math', 'agentic', 'chat', 'tools']},
    {"tag": "ministral-3:3b",         "params_b": 3.0,   "vram_gb": 2.1,   "capabilities": ['tools', 'chat', 'agentic']},
    {"tag": "ministral-3:8b",         "params_b": 8.0,   "vram_gb": 5.5,   "capabilities": ['tools', 'chat', 'agentic']},
    # ── Qwen 2.5 ─────────────────────────────────────────────────────────────
    {"tag": "qwen2.5:3b",             "params_b": 3.09,  "vram_gb": 2.1,   "capabilities": ['tools', 'chat', 'agentic']},
    {"tag": "qwen2.5:7b",             "params_b": 7.62,  "vram_gb": 4.9,   "capabilities": ['chat', 'agentic', 'coding', 'tools']},
    {"tag": "qwen2.5:14b",            "params_b": 14.7,  "vram_gb": 9.7,   "capabilities": ['chat', 'agentic', 'coding', 'tools']},
    {"tag": "qwen2.5:32b",            "params_b": 32.5,  "vram_gb": 20.8,  "capabilities": ['chat', 'agentic', 'coding', 'tools']},
    {"tag": "qwen2.5:72b",            "params_b": 72.7,  "vram_gb": 48.6,  "capabilities": ['chat', 'agentic', 'coding', 'tools']},
    {"tag": "qwen2.5-vl:3b",          "params_b": 3.09,  "vram_gb": 2.1,   "capabilities": ['vision', 'chat', 'tools']},
    {"tag": "qwen2.5-vl:7b",          "params_b": 7.62,  "vram_gb": 4.9,   "capabilities": ['tools', 'vision', 'chat', 'agentic']},
    {"tag": "qwen2.5-vl:72b",         "params_b": 72.7,  "vram_gb": 48.6,  "capabilities": ['tools', 'vision', 'chat', 'agentic']},
    {"tag": "qwen2.5-coder:1.5b",     "params_b": 1.5,   "vram_gb": 1.1,   "capabilities": ['coding', 'chat']},
    {"tag": "qwen2.5-coder:3b",       "params_b": 3.09,  "vram_gb": 2.1,   "capabilities": ['coding', 'chat']},
    {"tag": "qwen2.5-coder:7b",       "params_b": 7.62,  "vram_gb": 4.9,   "capabilities": ['coding', 'chat', 'tools']},
    {"tag": "qwen2.5-coder:14b",      "params_b": 14.7,  "vram_gb": 9.7,   "capabilities": ['coding', 'chat', 'tools']},
    {"tag": "qwen2.5-coder:32b",      "params_b": 32.5,  "vram_gb": 20.8,  "capabilities": ['coding', 'chat', 'tools']},
    # ── Qwen 3 ───────────────────────────────────────────────────────────────
    {"tag": "qwen3:0.6b",             "params_b": 0.6,   "vram_gb": 0.5,   "capabilities": ['reasoning', 'chat', 'tools']},
    {"tag": "qwen3:1.7b",             "params_b": 1.7,   "vram_gb": 1.3,   "capabilities": ['reasoning', 'chat', 'tools']},
    {"tag": "qwen3:4b",               "params_b": 4.0,   "vram_gb": 3.0,   "capabilities": ['reasoning', 'math', 'chat', 'tools']},
    {"tag": "qwen3:8b",               "params_b": 8.2,   "vram_gb": 5.6,   "capabilities": ['reasoning', 'math', 'agentic', 'chat', 'tools']},
    {"tag": "qwen3:14b",              "params_b": 14.0,  "vram_gb": 9.3,   "capabilities": ['reasoning', 'math', 'agentic', 'chat', 'tools']},
    {"tag": "qwen3:32b",              "params_b": 32.8,  "vram_gb": 20.8,  "capabilities": ['reasoning', 'math', 'agentic', 'chat', 'tools']},
    {"tag": "qwen3:30b",              "params_b": 30.5,  "vram_gb": 19.0,  "capabilities": ['reasoning', 'math', 'agentic', 'chat', 'tools']},
    {"tag": "qwen3:235b",             "params_b": 235.0, "vram_gb": 142.0, "capabilities": ['reasoning', 'math', 'agentic', 'chat', 'tools']},
    {"tag": "qwen3-coder:30b",        "params_b": 30.5,  "vram_gb": 19.0,  "capabilities": ['coding', 'agentic', 'chat', 'tools']},
    {"tag": "qwen3-coder:480b",       "params_b": 480.0, "vram_gb": 291.0, "capabilities": ['coding', 'agentic', 'chat', 'tools']},
    {"tag": "qwen3-vl:2b",            "params_b": 2.0,   "vram_gb": 1.6,   "capabilities": ['vision', 'reasoning', 'chat', 'tools']},
    {"tag": "qwen3-vl:4b",            "params_b": 4.0,   "vram_gb": 3.1,   "capabilities": ['vision', 'reasoning', 'chat', 'tools']},
    {"tag": "qwen3-vl:8b",            "params_b": 8.0,   "vram_gb": 5.6,   "capabilities": ['vision', 'reasoning', 'chat', 'tools']},
    {"tag": "qwen3-vl:30b",           "params_b": 30.5,  "vram_gb": 19.5,  "capabilities": ['vision', 'reasoning', 'chat', 'tools']},
    {"tag": "qwen3-vl:32b",           "params_b": 32.8,  "vram_gb": 21.0,  "capabilities": ['vision', 'reasoning', 'chat', 'tools']},
    {"tag": "qwq:32b",                "params_b": 32.5,  "vram_gb": 20.9,  "capabilities": ['reasoning', 'math', 'agentic', 'chat', 'tools']},
    # ── Qwen 3.5 (all confirmed tags) ────────────────────────────────────────
    {"tag": "qwen3.5:0.8b",           "params_b": 0.8,   "vram_gb": 0.6,   "capabilities": ['reasoning', 'chat', 'tools']},
    {"tag": "qwen3.5:2b",             "params_b": 2.0,   "vram_gb": 1.3,   "capabilities": ['reasoning', 'chat', 'tools']},
    {"tag": "qwen3.5:4b",             "params_b": 4.0,   "vram_gb": 2.9,   "capabilities": ['reasoning', 'math', 'chat', 'tools']},
    {"tag": "qwen3.5:9b",             "params_b": 9.0,   "vram_gb": 5.9,   "capabilities": ['reasoning', 'math', 'agentic', 'chat', 'tools']},
    {"tag": "qwen3.5:27b",            "params_b": 27.0,  "vram_gb": 17.5,  "capabilities": ['reasoning', 'math', 'agentic', 'chat', 'tools']},
    {"tag": "qwen3.5:35b",            "params_b": 35.0,  "vram_gb": 23.0,  "capabilities": ['reasoning', 'math', 'agentic', 'chat', 'tools']},
    {"tag": "qwen3.5:122b",           "params_b": 122.0, "vram_gb": 79.0,  "capabilities": ['reasoning', 'math', 'agentic', 'chat', 'tools']},
    # ── Qwen 3.6 (confirmed tags) ────────────────────────────────────────────
    {"tag": "qwen3.6:27b",            "params_b": 27.0,  "vram_gb": 17.5,  "capabilities": ['reasoning', 'math', 'agentic', 'chat', 'coding', 'tools']},
    {"tag": "qwen3.6:35b",            "params_b": 35.0,  "vram_gb": 23.0,  "capabilities": ['reasoning', 'math', 'agentic', 'chat', 'coding', 'tools']},
    # ── DeepSeek family ───────────────────────────────────────────────────────
    {"tag": "deepseek-r1:1.5b",       "params_b": 1.5,   "vram_gb": 1.1,   "capabilities": ['reasoning', 'math', 'chat', 'coding']},
    {"tag": "deepseek-r1:7b",         "params_b": 7.62,  "vram_gb": 4.9,   "capabilities": ['reasoning', 'math', 'chat', 'coding']},
    {"tag": "deepseek-r1:8b",         "params_b": 8.0,   "vram_gb": 5.5,   "capabilities": ['reasoning', 'math', 'chat', 'coding']},
    {"tag": "deepseek-r1:14b",        "params_b": 14.7,  "vram_gb": 9.7,   "capabilities": ['reasoning', 'math', 'chat', 'coding']},
    {"tag": "deepseek-r1:32b",        "params_b": 32.5,  "vram_gb": 20.8,  "capabilities": ['reasoning', 'math', 'chat', 'coding']},
    {"tag": "deepseek-r1:70b",        "params_b": 70.6,  "vram_gb": 43.7,  "capabilities": ['reasoning', 'math', 'chat', 'coding']},
    {"tag": "deepseek-r1:671b",       "params_b": 671.0, "vram_gb": 407.0, "capabilities": ['reasoning', 'math', 'chat', 'coding']},
    {"tag": "deepseek-v3:671b",       "params_b": 671.0, "vram_gb": 407.0, "capabilities": ['coding', 'reasoning', 'chat', 'tools']},
    {"tag": "deepseek-coder:6.7b",    "params_b": 6.74,  "vram_gb": 4.5,   "capabilities": ['coding', 'chat']},
    {"tag": "deepseek-coder:33b",     "params_b": 33.0,  "vram_gb": 21.0,  "capabilities": ['coding', 'chat']},
    {"tag": "deepseek-coder-v2:16b",  "params_b": 16.0,  "vram_gb": 10.2,  "capabilities": ['coding', 'chat', 'tools']},
    {"tag": "deepscaler:1.5b",        "params_b": 1.5,   "vram_gb": 1.1,   "capabilities": ['reasoning', 'math', 'chat']},
    # ── Gemma family ──────────────────────────────────────────────────────────
    {"tag": "gemma2:2b",              "params_b": 2.0,   "vram_gb": 1.6,   "capabilities": ['chat']},
    {"tag": "gemma2:9b",              "params_b": 9.24,  "vram_gb": 7.0,   "capabilities": ['chat', 'coding']},
    {"tag": "gemma2:27b",             "params_b": 27.2,  "vram_gb": 18.1,  "capabilities": ['chat', 'coding']},
    {"tag": "gemma3:270m",            "params_b": 0.27,  "vram_gb": 0.3,   "capabilities": ['chat']},
    {"tag": "gemma3:1b",              "params_b": 1.0,   "vram_gb": 0.8,   "capabilities": ['vision', 'chat']},
    {"tag": "gemma3:4b",              "params_b": 3.88,  "vram_gb": 3.1,   "capabilities": ['vision', 'chat', 'tools']},
    {"tag": "gemma3:12b",             "params_b": 11.8,  "vram_gb": 9.2,   "capabilities": ['coding', 'vision', 'chat', 'tools']},
    {"tag": "gemma3:27b",             "params_b": 27.0,  "vram_gb": 18.9,  "capabilities": ['coding', 'vision', 'chat', 'tools']},
    {"tag": "gemma3n:e2b",            "params_b": 2.0,   "vram_gb": 2.5,   "capabilities": ['vision', 'chat']},
    {"tag": "gemma3n:e4b",            "params_b": 4.0,   "vram_gb": 4.5,   "capabilities": ['vision', 'chat']},
    {"tag": "gemma4:e2b",             "params_b": 2.3,   "vram_gb": 3.4,   "capabilities": ['reasoning', 'math', 'chat', 'agentic', 'vision', 'tools']},
    {"tag": "gemma4:e4b",             "params_b": 4.5,   "vram_gb": 5.4,   "capabilities": ['reasoning', 'math', 'chat', 'agentic', 'vision', 'tools']},
    {"tag": "gemma4:26b",             "params_b": 26.0,  "vram_gb": 15.9,  "capabilities": ['reasoning', 'math', 'chat', 'agentic', 'vision', 'tools']},
    {"tag": "gemma4:31b",             "params_b": 31.0,  "vram_gb": 18.6,  "capabilities": ['reasoning', 'math', 'chat', 'agentic', 'vision', 'tools']},
    # ── Phi family ────────────────────────────────────────────────────────────
    {"tag": "phi3.5:3.8b",            "params_b": 3.84,  "vram_gb": 2.8,   "capabilities": ['chat', 'coding']},
    {"tag": "phi4-mini:3.8b",         "params_b": 3.84,  "vram_gb": 3.0,   "capabilities": ['reasoning', 'chat', 'coding', 'tools']},
    {"tag": "phi4:14b",               "params_b": 14.7,  "vram_gb": 9.8,   "capabilities": ['coding', 'reasoning', 'chat']},
    {"tag": "phi4-reasoning:14b",     "params_b": 14.7,  "vram_gb": 10.2,  "capabilities": ['reasoning', 'math', 'chat', 'coding']},
    # ── NVIDIA / IBM Granite / community ─────────────────────────────────────
    {"tag": "nemotron-mini:4b",       "params_b": 3.97,  "vram_gb": 2.8,   "capabilities": ['reasoning', 'math', 'agentic', 'chat', 'tools']},
    {"tag": "nemotron-cascade-2:30b", "params_b": 30.0,  "vram_gb": 19.5,  "capabilities": ['reasoning', 'math', 'agentic', 'chat', 'tools']},
    {"tag": "granite3.1-moe:1b",      "params_b": 1.0,   "vram_gb": 0.8,   "capabilities": ['coding', 'reasoning', 'chat', 'tools']},
    {"tag": "granite3.1-moe:3b",      "params_b": 3.0,   "vram_gb": 2.1,   "capabilities": ['coding', 'reasoning', 'chat', 'tools']},
    {"tag": "granite3.3:2b",          "params_b": 2.0,   "vram_gb": 1.5,   "capabilities": ['reasoning', 'coding', 'chat', 'tools']},
    {"tag": "granite3.3:8b",          "params_b": 8.0,   "vram_gb": 5.5,   "capabilities": ['reasoning', 'coding', 'chat', 'tools']},
    # ── Coding specialists ────────────────────────────────────────────────────
    {"tag": "starcoder2:3b",          "params_b": 3.0,   "vram_gb": 2.1,   "capabilities": ['coding', 'chat']},
    {"tag": "starcoder2:7b",          "params_b": 7.0,   "vram_gb": 4.8,   "capabilities": ['coding', 'chat']},
    {"tag": "starcoder2:15b",         "params_b": 15.6,  "vram_gb": 10.2,  "capabilities": ['coding', 'chat']},
    {"tag": "codegemma:2b",           "params_b": 2.0,   "vram_gb": 1.5,   "capabilities": ['coding', 'chat']},
    {"tag": "codegemma:7b",           "params_b": 7.0,   "vram_gb": 4.8,   "capabilities": ['coding', 'chat']},
    {"tag": "granite-code:8b",        "params_b": 8.0,   "vram_gb": 5.5,   "capabilities": ['coding', 'chat']},
    {"tag": "granite-code:20b",       "params_b": 20.0,  "vram_gb": 13.0,  "capabilities": ['coding', 'chat']},
    # ── Reasoning / thinking specialists ─────────────────────────────────────
    {"tag": "smallthinker:3b",        "params_b": 3.09,  "vram_gb": 2.1,   "capabilities": ['reasoning', 'math', 'chat']},
    {"tag": "openthinker:7b",         "params_b": 7.0,   "vram_gb": 4.9,   "capabilities": ['reasoning', 'math', 'chat']},
    {"tag": "openthinker:32b",        "params_b": 32.0,  "vram_gb": 20.5,  "capabilities": ['reasoning', 'math', 'chat']},
    {"tag": "deepscaler:1.5b",        "params_b": 1.5,   "vram_gb": 1.1,   "capabilities": ['reasoning', 'math', 'chat']},
    {"tag": "lfm2.5-thinking:1.2b",   "params_b": 1.2,   "vram_gb": 0.9,   "capabilities": ['reasoning', 'chat']},
    # ── Agentic / instruction-tuned ───────────────────────────────────────────
    {"tag": "hermes3:3b",             "params_b": 3.0,   "vram_gb": 2.1,   "capabilities": ['chat', 'tools', 'agentic']},
    {"tag": "hermes3:8b",             "params_b": 8.0,   "vram_gb": 5.5,   "capabilities": ['chat', 'tools', 'agentic']},
    {"tag": "hermes3:70b",            "params_b": 70.0,  "vram_gb": 43.0,  "capabilities": ['chat', 'tools', 'agentic']},
    {"tag": "cogito:3b",              "params_b": 3.0,   "vram_gb": 2.1,   "capabilities": ['reasoning', 'chat', 'tools']},
    {"tag": "cogito:8b",              "params_b": 8.0,   "vram_gb": 5.5,   "capabilities": ['reasoning', 'chat', 'tools']},
    {"tag": "cogito:14b",             "params_b": 14.0,  "vram_gb": 9.3,   "capabilities": ['reasoning', 'chat', 'tools']},
    {"tag": "cogito:32b",             "params_b": 32.0,  "vram_gb": 20.5,  "capabilities": ['reasoning', 'chat', 'tools']},
    {"tag": "cogito:70b",             "params_b": 70.0,  "vram_gb": 43.0,  "capabilities": ['reasoning', 'chat', 'tools']},
    {"tag": "command-r:35b",          "params_b": 34.9,  "vram_gb": 22.5,  "capabilities": ['chat', 'tools', 'agentic', 'coding']},
    # ── Small / edge models ───────────────────────────────────────────────────
    {"tag": "smollm2:135m",           "params_b": 0.135, "vram_gb": 0.2,   "capabilities": ['chat']},
    {"tag": "smollm2:360m",           "params_b": 0.36,  "vram_gb": 0.4,   "capabilities": ['chat']},
    {"tag": "smollm2:1.7b",           "params_b": 1.7,   "vram_gb": 1.2,   "capabilities": ['chat']},
    {"tag": "olmo2:7b",               "params_b": 7.0,   "vram_gb": 4.8,   "capabilities": ['chat']},
    {"tag": "olmo2:13b",              "params_b": 13.0,  "vram_gb": 8.7,   "capabilities": ['chat']},
    {"tag": "falcon3:1b",             "params_b": 1.0,   "vram_gb": 0.8,   "capabilities": ['chat']},
    {"tag": "falcon3:3b",             "params_b": 3.0,   "vram_gb": 2.1,   "capabilities": ['chat']},
    {"tag": "falcon3:7b",             "params_b": 7.0,   "vram_gb": 4.8,   "capabilities": ['chat', 'coding']},
    {"tag": "falcon3:10b",            "params_b": 10.0,  "vram_gb": 6.8,   "capabilities": ['chat', 'coding']},
    {"tag": "orca-mini:3b",           "params_b": 3.0,   "vram_gb": 2.1,   "capabilities": ['chat']},
    {"tag": "gpt-oss:20b",            "params_b": 21.0,  "vram_gb": 11.9,  "capabilities": ['reasoning', 'math', 'agentic', 'chat', 'tools']},
    {"tag": "glm-4.7-flash",          "params_b": 31.0,  "vram_gb": 18.5,  "capabilities": ['reasoning', 'math', 'agentic', 'chat', 'tools']},
]


@dataclass
class OllamaModelEntry:
    tag: str
    name: str
    params_b: float
    vram_gb: float
    description: str
    capabilities: List[str]
    context_k: int = 32
    is_cloud: bool = False
    cloud_tag: Optional[str] = None
    weight_gb: float = 0.0
    kv_per_1k_gb: float = 0.0


def _estimate_vram(params_b: float, quant: str = "Q4_K_M") -> float:
    """Estimate VRAM requirement from parameter count and quantization."""
    bits_map = {"q4_k_m": 4.5, "q8_0": 8.0, "fp16": 16.0, "f16": 16.0, "q5_k_m": 5.5, "q6_k": 6.5}
    bits = bits_map.get(quant.lower(), 4.5)
    weight_gb = (params_b * 1e9 * bits / 8) / (1024 ** 3)
    return weight_gb * 1.12  # 12% overhead for KV cache and system memory


def get_trending_ollama_models() -> List[dict]:
    """
    Scrape the Ollama library for trending models.
    Uses BeautifulSoup for robust discovery if the search API is limited.
    """
    try:
        from bs4 import BeautifulSoup
        url = "https://ollama.com/library"
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"}
        resp = httpx.get(url, headers=headers, timeout=5.0)
        if resp.status_code != 200:
            return []
        
        soup = BeautifulSoup(resp.text, "html.parser")
        models = []
        # Ollama library items are typically in li tags with x-data
        for item in soup.select("li[x-data]"):
            name_el = item.select_one("h2")
            desc_el = item.select_one("p")
            pulls_el = item.select_one("[title*='Pull']")
            
            if name_el:
                name = name_el.text.strip()
                desc = desc_el.text.strip() if desc_el else ""
                pulls = pulls_el.get("title", "") if pulls_el else ""
                
                models.append({
                    "tag": name,
                    "name": name,
                    "description": desc,
                    "pulls": pulls,
                    "capabilities": _infer_capabilities(name, desc)
                })
        return models
    except Exception as e:
        logger.debug(f"Trending scrape failed: {e}")
        return []


def fetch_latest_ollama_models(timeout: float = 4.0) -> List[OllamaModelEntry]:
    """
    Fetch the latest trending/featured models from Ollama library API.
    Returns a curated list combining live data with our known catalog.
    Falls back to KNOWN_LOCAL_MODELS if the registry is unreachable.
    """
    entries = []

    # Try Ollama registry API first
    try:
        with httpx.Client(timeout=timeout) as client:
            resp = client.get(
                "https://ollama.com/api/search?q=&p=1&sort=popular&limit=50",
                headers={"Accept": "application/json"},
            )
            if resp.status_code == 200:
                data = resp.json()
                models = data.get("models", [])
                for m in models:
                    tag = m.get("name", "")
                    if not tag:
                        continue
                    # Pull metadata
                    size_b = m.get("parameter_size", "")
                    params_b = _parse_params(size_b)
                    desc = m.get("description", "")[:120]
                    caps = _infer_capabilities(tag, desc)
                    vram = _estimate_vram(params_b)
                    entries.append(OllamaModelEntry(
                        tag=tag,
                        name=m.get("title", tag),
                        params_b=params_b,
                        vram_gb=vram,
                        description=desc,
                        capabilities=caps,
                        context_k=_infer_context(m),
                    ))
                logger.info(f"Fetched {len(entries)} models from Ollama registry")
    except Exception as e:
        logger.debug(f"Ollama registry fetch failed, using known catalog: {e}")

    # Always merge with our curated catalog (deduplicating by base tag)
    existing_tags = {e.tag.split(":")[0] for e in entries}
    for m in KNOWN_LOCAL_MODELS:
        base = m["tag"].split(":")[0]
        if base not in existing_tags:
            entries.append(OllamaModelEntry(
                tag=m["tag"],
                name=m["tag"],
                params_b=m["params_b"],
                vram_gb=m["vram_gb"],
                description="",
                capabilities=m["capabilities"],
            ))
            existing_tags.add(base)

    return entries


def _parse_params(size_str: str) -> float:
    """Parse parameter count string like '8B', '70B', '235B-A22B'."""
    if not size_str:
        return 7.0
    m = re.search(r"(\d+\.?\d*)B", size_str, re.IGNORECASE)
    if m:
        return float(m.group(1))
    return 7.0


def _infer_capabilities(tag: str, desc: str) -> List[str]:
    """Infer capabilities from model name and description."""
    caps = ["chat"]
    combined = (tag + " " + desc).lower()
    if any(x in combined for x in ["code", "coder", "coding", "programm"]):
        caps.append("coding")
    if any(x in combined for x in ["reason", "think", "r1", "r2", "qwq", "deepseek"]):
        caps.append("reasoning")
    if any(x in combined for x in ["vision", "vl", "visual", "image", "multimodal"]):
        caps.append("vision")
    if any(x in combined for x in ["math", "mathematic", "stem"]):
        caps.append("math")
    if any(x in combined for x in ["tool", "function", "agent", "agentic"]):
        caps.append("tools")
    if any(x in combined for x in ["embed", "embedding", "nomic", "mxbai", "bge"]):
        caps = ["embedding"]
    if any(x in combined for x in ["multilingual", "multi-lingual", "translation"]):
        caps.append("multilingual")
    return caps


def _infer_context(model_data: dict) -> int:
    """Infer context window from model metadata."""
    ctx = model_data.get("context_length", 0)
    if ctx >= 128000:
        return 128
    elif ctx >= 32000:
        return 32
    elif ctx >= 16000:
        return 16
    return 32


def get_runnable_local_models(
    vram_gb: float,
    entries: List[OllamaModelEntry],
    headroom_gb: float = 0.5,
) -> List[OllamaModelEntry]:
    """Filter entries to models that fit in available VRAM."""
    usable = vram_gb - headroom_gb
    return [m for m in entries if not m.is_cloud and m.vram_gb <= usable]


def get_cloud_recommendations(
    vram_gb: float,
    workload: List[str],
) -> List[dict]:
    """
    Returns Ollama Cloud model recommendations based on VRAM and workload.
    Always returns cloud models; scoring is workload-weighted.
    """
    scored = []
    for cm in OLLAMA_CLOUD_MODELS:
        score = 0.0
        for cap in cm["capabilities"]:
            if cap in workload:
                score += 20.0
        if cm["tier"] == "flagship":
            score += 10.0
        # Boost coding-focused models when workload includes coding
        if "coding" in workload and "coding" in cm["capabilities"]:
            score += 15.0
        scored.append((score, cm))

    scored.sort(key=lambda x: x[0], reverse=True)
    return [cm for _, cm in scored[:5]]


def assess_hardware(vram_gb: float, bandwidth_gbps: Optional[float] = None) -> dict:
    """
    Assess whether hardware is suitable for local LLM inference.
    Returns a structured assessment with tier, message and recommendations.
    """
    is_low_bandwidth = bandwidth_gbps is not None and bandwidth_gbps < 150.0

    if vram_gb == 0:
        # CPU only
        return {
            "tier": "cpu_only",
            "suitable_for_local": False,
            "message": "No GPU detected. Local inference will be very slow on CPU only.",
            "max_comfortable_model_gb": 0.0,
            "suggest_cloud": True,
            "speed_note": "CPU inference: typically 1-5 tok/s for quantized 7B models",
        }
    elif vram_gb < 4:
        return {
            "tier": "very_low",
            "suitable_for_local": False,
            "message": f"With {vram_gb:.1f}GB VRAM, only tiny models (0.6B–1.7B) run locally. Quality will be limited.",
            "max_comfortable_model_gb": vram_gb - 0.5,
            "suggest_cloud": True,
            "speed_note": "Can run small models but responses may feel slow and low-quality.",
        }
    elif vram_gb < 8:
        # Estimate speed if bandwidth known
        if bandwidth_gbps:
            est_tps_7b = bandwidth_gbps / (5.0 + 1.0)  # ~5GB Q4 7B model
            speed_note = f"~{est_tps_7b:.0f} tok/s estimated for a 7B Q4 model on your hardware"
        else:
            speed_note = "Good speed for models up to ~6B, slower for 7B+ models"

        return {
            "tier": "low",
            "suitable_for_local": True,
            "message": f"With {vram_gb:.1f}GB VRAM, you can run solid 4B–7B models. Quality is good for most tasks.",
            "max_comfortable_model_gb": vram_gb - 0.8,
            "suggest_cloud": True,  # suggest as an option, not required
            "speed_note": speed_note,
        }
    elif vram_gb < 12:
        if bandwidth_gbps:
            est_tps_7b = bandwidth_gbps / (5.0 + 1.0)
            speed_note = f"~{est_tps_7b:.0f} tok/s for a 7B Q4 model" + (" — snappy" if est_tps_7b > 15 else " — playable but slow")
        else:
            speed_note = "Great speed for 7B–8B models, capable for 14B with quantization"

        return {
            "tier": "mid",
            "suitable_for_local": True,
            "message": f"With {vram_gb:.1f}GB VRAM, you can run 7B–8B models comfortably.",
            "max_comfortable_model_gb": (vram_gb - 0.8) if not is_low_bandwidth else 8.0,
            "suggest_cloud": is_low_bandwidth,
            "speed_note": speed_note,
        }
    elif vram_gb < 24:
        speed_note = "Excellent local inference speed. Cloud mostly for spillover."
        if bandwidth_gbps:
            est_tps_14b = bandwidth_gbps / (10.0 + 1.0)
            speed_note = f"~{est_tps_14b:.0f} tok/s estimated for a 14B model"

        return {
            "tier": "good",
            "suitable_for_local": True,
            "message": f"With {vram_gb:.1f}GB VRAM, you can run 13B–20B models. Very capable local setup.",
            "max_comfortable_model_gb": (vram_gb - 1.0) if not is_low_bandwidth else 10.0,
            "suggest_cloud": False,
            "speed_note": speed_note,
        }
    else:
        speed_note = "Exceptional local speed. You're set."
        if bandwidth_gbps:
            est_tps_32b = bandwidth_gbps / (22.0 + 1.0)
            speed_note = f"~{est_tps_32b:.0f} tok/s estimated for a 32B model"

        return {
            "tier": "excellent",
            "suitable_for_local": True,
            "message": f"With {vram_gb:.1f}GB VRAM, you can run 30B–70B models. Near-frontier local quality.",
            "max_comfortable_model_gb": (vram_gb - 1.5) if not is_low_bandwidth else 12.0,
            "suggest_cloud": False,
            "speed_note": speed_note,
        }

