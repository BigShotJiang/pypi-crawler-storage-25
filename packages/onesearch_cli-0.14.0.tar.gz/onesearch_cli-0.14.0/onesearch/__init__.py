# Copyright (C) 2025 demigodmode
# SPDX-License-Identifier: AGPL-3.0-only

"""OneSearch CLI - Command-line interface for OneSearch."""

__version__ = "0.14.0"
