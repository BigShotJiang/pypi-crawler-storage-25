# plain.cli

**The `plain` command-line interface and tools for adding custom commands.**

- [Overview](#overview)
- [Adding commands](#adding-commands)
    - [Register a command group](#register-a-command-group)
    - [Register a shortcut command](#register-a-shortcut-command)
    - [Mark commands as common](#mark-commands-as-common)
    - [Bridge CLI options to settings](#bridge-cli-options-to-settings)
- [Shell](#shell)
    - [Run a script with app context](#run-a-script-with-app-context)
    - [SHELL_IMPORT](#shell_import)
- [Built-in commands](#built-in-commands)
- [FAQs](#faqs)
- [Installation](#installation)

## Overview

The `plain` CLI provides commands for running your app, managing databases, starting shells, and more. You can also add your own commands using the [`register_cli`](./registry.py#register_cli) decorator.

Commands are written using [Click](https://click.palletsprojects.com/), a popular Python CLI framework that is one of Plain's few dependencies.

```python
import click
from plain.cli import register_cli


@register_cli("hello")
@click.command()
def cli():
    """Say hello"""
    click.echo("Hello from my custom command!")
```

After defining this command, you can run it with `plain hello`:

```bash
$ plain hello
Hello from my custom command!
```

## Adding commands

You can register commands from anywhere, but Plain will automatically import `cli.py` modules from your app and installed packages. The most common locations are:

- `app/cli.py` for app-specific commands
- `<package>/cli.py` for package-specific commands

### Register a command group

Use [`@register_cli`](./registry.py#register_cli) with a Click group to create subcommands:

```python
@register_cli("users")
@click.group()
def cli():
    """User management commands"""
    pass


@cli.command()
@click.argument("email")
def create(email):
    """Create a new user"""
    click.echo(f"Creating user: {email}")


@cli.command()
def list():
    """List all users"""
    click.echo("Listing users...")
```

This creates `plain users create` and `plain users list` commands.

### Register a shortcut command

Use `shortcut_for` to create a top-level alias for a subcommand:

```python
@register_cli("fix", shortcut_for="code fix")
@cli.command("fix")
def fix():
    """Fix formatting and linting issues"""
    # ...
```

This registers `plain fix` as a shortcut for `plain code fix`. Both commands work identically. The shortcut appears in `plain --help` with a note showing the full command path.

### Mark commands as common

Use the [`common_command`](./runtime.py#common_command) decorator to highlight frequently used commands in help output:

```python
from plain.cli import register_cli
from plain.cli.runtime import common_command


@register_cli("dev")
@common_command
@click.command()
def dev():
    """Start development server"""
    # ...
```

Common commands appear in a separate "Common Commands" section when running `plain --help`.

### Bridge CLI options to settings

Use [`SettingOption`](./options.py#SettingOption) to connect a Click option to a Plain setting. The setting provides the default value, and CLI args take priority when explicitly passed.

```python
import click
from plain.cli import SettingOption, register_cli


@register_cli("jobs")
@click.group()
def cli():
    pass


@cli.command()
@click.option(
    "--max-processes",
    type=int,
    cls=SettingOption,
    setting="JOBS_WORKER_MAX_PROCESSES",
)
def worker(max_processes):
    click.echo(f"Max processes: {max_processes}")
```

Pass `cls=SettingOption` and `setting="SETTING_NAME"` to any `@click.option`. The setting name shown in `--help` output alongside the default value.

`SettingOption` cannot be combined with `envvar=` or `default=` — the setting is the single source of truth for both the default value and environment variable resolution.

## Shell

The `plain shell` command starts an interactive Python shell with your Plain app already loaded.

```bash
$ plain shell
```

If you have IPython installed, it will be used automatically. You can also specify an interface explicitly:

```bash
$ plain shell --interface ipython
$ plain shell --interface bpython
$ plain shell --interface python
```

For one-off commands, use the `-c` flag:

```bash
$ plain shell -c "from app.users.models import User; print(User.query.count())"
```

### Run a script with app context

The `plain run` command executes a Python script with your app context already set up:

```bash
$ plain run scripts/import_data.py
```

This is useful for one-off scripts that need access to your models and settings.

### SHELL_IMPORT

Customize what gets imported automatically when the shell starts by setting `SHELL_IMPORT` in your settings:

```python
# app/settings.py
SHELL_IMPORT = "app.shell"
```

Then create that module with the objects you want available:

```python
# app/shell.py
from app.projects.models import Project
from app.users.models import User

__all__ = ["Project", "User"]
```

Now when you run `plain shell`, those objects will be automatically imported and available.

## Built-in commands

Plain includes several built-in commands:

| Command               | Description                              |
| --------------------- | ---------------------------------------- |
| `plain check`         | Run core validation checks               |
| `plain shell`         | Interactive Python shell                 |
| `plain run <script>`  | Execute a Python script with app context |
| `plain server`        | Production-ready HTTP server             |
| `plain preflight`     | Validation checks before deployment      |
| `plain create <name>` | Create a new local package               |
| `plain settings`      | View current settings                    |
| `plain urls`          | List all URL patterns                    |
| `plain docs`          | View package documentation               |
| `plain build`         | Run build commands                       |
| `plain install`       | Install package dependencies             |
| `plain upgrade`       | Upgrade Plain packages                   |
| `plain memory`        | Memory profiling tools                   |

Additional commands are added by installed packages (like `plain migrations apply` from plain.postgres).

### `plain check`

Runs core validation checks in order, stopping on first failure:

1. Custom commands (see below)
2. `plain code check` (if `plain.code` is installed)
3. `plain preflight --quiet`
4. `plain migrations apply --check` (if DB connected)
5. `plain migrations create --dry-run --check` (if DB connected)
6. `plain test` (if `plain.pytest` is installed)

Use `--skip-test` to skip tests for faster iteration.

#### Custom check commands

Add custom commands to `plain check` by defining them in `pyproject.toml`:

```toml
[tool.plain.check.run]
my-check = {cmd = "echo 'running my check'"}
```

Custom commands run first, before any built-in checks.

### `plain memory`

Memory profiling tools for diagnosing boot-time costs and runtime leaks.

#### `plain memory baseline`

Measures which packages consume the most memory when a worker process starts — before any requests are handled. Runs in an isolated subprocess so results aren't contaminated by prior imports.

```bash
plain memory baseline
```

```
Worker RSS: 87 MB (245 modules)

Heaviest packages:
  stripe                           35.1 MB
  boto3                            12.3 MB
  plain.postgres                    8.7 MB
```

#### `plain memory leaks`

Checks a running server for memory leaks. See the [server docs](../server/README.md#memory-leak-detection) for details.

## FAQs

#### How do I run commands that don't need the app to be set up?

Use the [`without_runtime_setup`](./runtime.py#without_runtime_setup) decorator for commands that don't need access to settings or app code. This is useful for commands that fork processes (like `server`) where setup should happen in the worker process:

```python
from plain.cli.runtime import without_runtime_setup


@without_runtime_setup
@click.command()
def server():
    """Start the server"""
    # Setup happens in the worker process, not here
    # ...
```

#### Where should I put my custom commands?

Put app-specific commands in `app/cli.py`. Plain will automatically import this module. If you're building a reusable package, put commands in `<package>/cli.py`.

#### Can I use argparse instead of Click?

No, Plain's CLI is built on Click and the registration system expects Click commands. However, Click is well-documented and provides a better developer experience than argparse for most use cases.

## Installation

The CLI is included with Plain. No additional installation is required.
