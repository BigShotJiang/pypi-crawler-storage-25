"""
polymarket-news — News-to-trade signal pipeline for Polymarket.

Standalone re-export from polymarket-trading-mcp.
"""
from polymarket_mcp.tools.news import scan_news_for_markets, get_crypto_news

__all__ = ["scan_news_for_markets", "get_crypto_news"]
__version__ = "0.1.0"
