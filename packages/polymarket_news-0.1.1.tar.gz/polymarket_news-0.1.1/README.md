# polymarket-news

News-to-trade signal pipeline for Polymarket. Scans crypto headlines and surfaces mispricings.

Standalone re-export from [polymarket-trading-mcp](https://github.com/whitmorelabs/polymarket-mcp).

## Install

```bash
pip install polymarket-news
```

## Usage

```python
from polymarket_news import scan_news_for_markets
```

## Source

Part of [Whitmore Labs polymarket-mcp](https://github.com/whitmorelabs/polymarket-mcp).
