# Ubuntu Connector

A Python-based agent deployed directly on Ubuntu servers that discovers local resources, maps them to ArchiMate Technology Layer entities, and syncs them to the Archilence platform.

## How It Works

The connector runs as a **systemd service** on the target Ubuntu server. It periodically collects system information through modular collectors, transforms the data into ArchiMate entities and relations, and pushes them to Archilence Core via the standard connector API.

```
┌─────────────────────────────────────────────────┐
│  Ubuntu Server                                  │
│                                                 │
│  archilence-connector (systemd service)         │
│  ├── Collectors (system, docker, systemd, ...)  │
│  ├── Entity Mapper (→ ArchiMate types)          │
│  ├── Sync Engine (full + delta cycles)          │
│  ├── Tool Server (HTTP callback for Core)       │
│  └── Offline Buffer (SQLite queue)              │
│                                                 │
└──────────────────┬──────────────────────────────┘
                   │ POST /register
                   │ POST /heartbeat
                   │ POST /sync
                   ▼
          ┌─────────────────┐
          │ Archilence Core │
          └─────────────────┘
```

### Lifecycle

1. **Startup** — loads config, initializes collectors, starts HTTP tool server
2. **Registration** — `POST /register` with connector name, callback URL, capabilities
3. **Initial sync** — runs all collectors, maps to entities, sends full snapshot
4. **Scheduled syncs** — full snapshot every 5 min, delta every 1 min (configurable)
5. **Heartbeat** — every 30s, reports collector health status
6. **Shutdown** — reports `inactive` status, flushes buffer, exits cleanly

### Offline Resilience

When Core is unreachable, payloads are queued to a local SQLite database at `/var/lib/archilence/buffer.db` with 24-hour retention. Buffered payloads flush in order once connectivity is restored.

## Collectors

Each collector runs independently in isolation — a failure in one never affects others. Failed collectors report degraded status in the heartbeat.

| Collector | Default | What It Collects |
|-----------|---------|------------------|
| `system` | ON | Hostname, OS, kernel, architecture, CPU model, RAM, uptime, timezone |
| `performance` | ON | CPU/memory/disk percentages, load averages, swap, per-core CPU |
| `processes` | ON | Top 20 processes by CPU usage (PID, user, command, memory) |
| `docker` | ON | Containers, images, compose projects, ports, filtered env vars |
| `systemd` | ON | Service states (active/inactive/failed), enabled/disabled |
| `networking` | ON | Interfaces, IPs, MAC addresses, listening ports, firewall summary |
| `packages` | OFF | Installed apt packages with versions (~5-15s scan overhead) |
| `files` | OFF | User-defined path monitoring: size, mtime, SHA-256 checksum |

## ArchiMate Mapping

### Entities

| Ubuntu Resource | ArchiMate Type | Subtype | External ID Format |
|---|---|---|---|
| Ubuntu Host | `Node` | `Server` / `VirtualMachine` | `ubuntu:{hostname}` |
| Docker Container | `SystemSoftware` | `ContainerRuntime` | `ubuntu:{hostname}:docker:{name}` |
| Docker Compose Project | `ApplicationComponent` | — | `ubuntu:{hostname}:docker:{project}` |
| Systemd Service | `SystemSoftware` | — | `ubuntu:{hostname}:systemd:{unit}` |
| Network Interface | `CommunicationNetwork` | — | `ubuntu:{hostname}:networking:{iface}` |
| Installed Package | `Artifact` | — | `ubuntu:{hostname}:packages:{name}` |
| Watched File/Dir | `Artifact` | — | `ubuntu:{hostname}:files:{path}` |

### Relations

| From → To | Relation Type |
|---|---|
| Host → Container | `Hosts` |
| Host → Service | `Hosts` |
| Host → Network Interface | `Composition` |
| Host → Package | `Composition` |
| Compose Project → Container | `Aggregation` |
| Service → Listening Port | `Serving` |

## Installation

```bash
curl -fsSL https://cockpit.archilence.com/install/ubuntu.sh | sudo bash
```

This creates a dedicated `archilence` system user, bootstraps required Ubuntu packages, installs the connector into `/opt/archilence-connector/.venv`, writes a config skeleton, enables the systemd service, and starts it immediately.

### Manual Installation

```bash
# Install OS dependencies and connector runtime
sudo apt-get update
sudo DEBIAN_FRONTEND=noninteractive apt-get install -y python3 python3-venv ca-certificates
sudo mkdir -p /opt/archilence-connector
sudo python3 -m venv /opt/archilence-connector/.venv
sudo /opt/archilence-connector/.venv/bin/pip install --upgrade pip setuptools wheel
sudo /opt/archilence-connector/.venv/bin/pip install --upgrade archilence-ubuntu-connector
sudo ln -sf /opt/archilence-connector/.venv/bin/archilence-connector /usr/local/bin/archilence-connector
sudo ln -sf /opt/archilence-connector/.venv/bin/archilence-connector-smoke-test /usr/local/bin/archilence-connector-smoke-test

# Copy and edit config
sudo mkdir -p /etc/archilence
sudo cp connector.example.yml /etc/archilence/connector.yml
sudo nano /etc/archilence/connector.yml   # Set your API key

# Install and start the service
sudo cp systemd/archilence-connector.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now archilence-connector
```

The PyPI distribution is `archilence-ubuntu-connector`. The installed CLI command and systemd service remain `archilence-connector`.

## Release Versioning

The connector package version is derived from Git tags matching `ubuntu-connector-vX.Y.Z`.

- Each `main` update that changes `apps/ubuntu-connector/**` publishes a new PyPI release.
- The workflow picks the semantic bump level from conventional commits since the last connector tag:
  - `feat!:` or `BREAKING CHANGE:` => major
  - `feat:` => minor
  - everything else => patch
- The installer and manual install commands fetch the latest published release by default.

## Configuration

Edit `/etc/archilence/connector.yml`:

```yaml
archilence:
  endpoint: https://cockpit.archilence.com
  api_key: ak_YOUR_API_KEY          # From Cockpit connector setup

server:
  name: "production-web-01"          # Optional, defaults to hostname
  tags: ["production", "web"]
  environment: "production"          # production | staging | dev

collectors:
  system: true
  performance: true
  processes: true
  docker: true
  systemd: true
  networking: true
  packages: false                    # Slow, opt-in
  files:
    enabled: false
    paths: []                        # e.g. ["/var/www", "/etc/nginx"]

intervals:
  snapshot_full: 300                 # Full sync every 5 minutes
  snapshot_delta: 60                 # Delta sync every 1 minute
  heartbeat: 30                      # Heartbeat every 30 seconds

control:
  enabled: false                     # Enable control tools
  allow_exec: false                  # Enable shell execution (DANGEROUS)
```

## Tool Server

The connector runs an HTTP server (default port `8990`) that serves as the callback URL for Core. This enables on-demand data retrieval and remote tool invocation by SDLC agents.

### Read Tools (always available)

| Endpoint | Description |
|----------|-------------|
| `POST /tools/get_server_info` | Hostname, OS, uptime, CPU, RAM, tags |
| `POST /tools/get_performance` | Current CPU%, memory%, disk%, load average |
| `POST /tools/list_containers` | All Docker containers with status, image, ports |
| `POST /tools/list_services` | All systemd services with active/inactive/failed |
| `POST /tools/list_ports` | All listening TCP/UDP ports with process info |
| `POST /tools/get_processes` | Top N processes by CPU (accepts `{"top_n": 20}`) |
| `POST /tools/get_logs` | Last N journald lines (accepts `{"service": "nginx", "lines": 100}`) |
| `POST /tools/get_network_info` | Interfaces, IPs, connections, firewall summary |

### Control Tools (require `control.enabled: true`)

| Endpoint | Description |
|----------|-------------|
| `POST /tools/restart_service` | `systemctl restart {name}` |
| `POST /tools/restart_container` | Restart Docker container by name |
| `POST /tools/stop_container` | Stop Docker container by name |
| `POST /tools/exec_command` | Arbitrary shell (requires `control.allow_exec`) |

### Other Endpoints

| Endpoint | Description |
|----------|-------------|
| `GET /health` | Health check with collector status |
| `GET /analysis/full` | Local-only full raw collector output plus mapped entities/relations |
| `POST /sync` | Trigger an immediate full sync |

## Permissions

The connector runs as a dedicated `archilence` system user with:

- **Docker group** membership for `docker.sock` access
- **D-Bus access** for systemd queries via `systemctl`
- **Read access** to `/proc`, `/sys`, system metrics
- **Sudoers entries** (only when control tools are enabled):
  ```
  archilence ALL=(ALL) NOPASSWD: /bin/systemctl restart *, /bin/systemctl stop *
  ```

The systemd unit includes security hardening: `NoNewPrivileges`, `ProtectSystem=strict`, `ProtectHome`, `PrivateTmp`.

## Managing the Service

```bash
# Start / stop / restart
sudo systemctl start archilence-connector
sudo systemctl stop archilence-connector
sudo systemctl restart archilence-connector

# Check status
sudo systemctl status archilence-connector

# View logs
journalctl -u archilence-connector -f

# Inspect full local analysis payload
curl -s http://127.0.0.1:8990/analysis/full | jq

# View logs with debug level
sudo systemctl edit archilence-connector
# Add: Environment=LOG_LEVEL=DEBUG
sudo systemctl restart archilence-connector
```

## Smoke Testing

Run the bundled smoke test on the Ubuntu host after installation or config changes:

```bash
# Local service and tool-server checks
archilence-connector-smoke-test --local-only

# Local checks plus connector record verification in Core
archilence-connector-smoke-test \
  --core-url https://cockpit.archilence.com \
  --connector-api-key ak_YOUR_CONNECTOR_API_KEY

# Full end-to-end verification including active entity lookup in Core
archilence-connector-smoke-test \
  --core-url https://cockpit.archilence.com \
  --connector-api-key ak_YOUR_CONNECTOR_API_KEY \
  --internal-api-key YOUR_CORE_INTERNAL_API_KEY
```

For a single-shot local inventory dump without contacting Core:

```bash
curl -s http://127.0.0.1:8990/analysis/full | jq
```

Notes:

- `--connector-api-key` verifies the connector's Core-side `/config` record, callback URL, owner assignment, online state, and heartbeat recency.
- `--internal-api-key` enables the deeper entity-ingestion check via Core's `/api/entities/active`.
- Add `--expected-callback-host your-hostname-or-configured-server-name` when the connector registers with a configured `server.name` instead of the machine hostname.
- Add `--fail-on-degraded-collectors` if you want degraded collectors, such as a missing Docker runtime, to fail the smoke test instead of warning.
- For repo-local execution without installing the package, run `python3 smoke_test.py ...` from `apps/ubuntu-connector/`.

## Dependencies

| Package | Purpose |
|---------|---------|
| `psutil` | System metrics, processes, network |
| `docker` (docker-py) | Docker container/image/network discovery |
| `pyyaml` | Configuration file parsing |
| `httpx` | HTTP client for Core API |
| `apscheduler` | Scheduled sync and heartbeat jobs |
| `flask` | Tool server HTTP endpoint |

Requires Python 3.10+.
