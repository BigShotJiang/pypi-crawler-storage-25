from __future__ import annotations

import importlib
import sys
import types
import unittest
from pathlib import Path
from types import SimpleNamespace


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


class FakeRequest:
    remote_addr = "127.0.0.1"

    @staticmethod
    def get_json(silent: bool = True):
        return {}


class FakeFlask:
    def __init__(self, name: str) -> None:
        self.name = name
        self.config = {}
        self.routes: dict[tuple[str, tuple[str, ...]], object] = {}

    def route(self, path: str, methods: list[str] | None = None):
        methods_tuple = tuple(methods or ["GET"])

        def decorator(fn):
            self.routes[(path, methods_tuple)] = fn
            return fn

        return decorator


def install_fake_flask() -> None:
    flask_module = types.ModuleType("flask")
    flask_module.Flask = FakeFlask
    flask_module.request = FakeRequest
    flask_module.jsonify = lambda payload: payload
    sys.modules["flask"] = flask_module


class ToolServerAnalysisTests(unittest.TestCase):
    def setUp(self) -> None:
        install_fake_flask()
        sys.modules.pop("archilence_connector.tool_server", None)
        self.tool_server = importlib.import_module("archilence_connector.tool_server")

    def create_app(self):
        config = SimpleNamespace(
            server=SimpleNamespace(tags=["prod"], environment="production"),
            control=SimpleNamespace(enabled=False, allow_exec=False),
        )
        collector_manager = SimpleNamespace(get_collector=lambda _name: None)
        sync_engine = SimpleNamespace(
            analysis_snapshot=lambda: {
                "timestamp": "2026-04-14T14:00:00Z",
                "hostname": "host-a",
                "collector_health": {"system": "ok"},
                "summary": {
                    "raw_collectors": 1,
                    "raw_entities": 1,
                    "mapped_entities": 1,
                    "mapped_relations": 0,
                },
                "raw": {
                    "collectors": {
                        "system": {"ok": True, "entities": [], "metrics": {}, "error": None}
                    }
                },
                "mapped": {"entities": [], "relations": []},
            },
            full_sync=lambda: {"success": True, "entities_count": 0, "relations_count": 0},
        )
        return self.tool_server.create_app(config, collector_manager, sync_engine)

    def test_full_analysis_allows_localhost(self) -> None:
        app = self.create_app()
        self.tool_server.request.remote_addr = "127.0.0.1"

        response = app.routes[("/analysis/full", ("GET",))]()

        self.assertEqual(response["hostname"], "host-a")
        self.assertIn("raw", response)
        self.assertIn("mapped", response)
        self.assertEqual(response["summary"]["raw_collectors"], 1)

    def test_full_analysis_rejects_non_local_requests(self) -> None:
        app = self.create_app()
        self.tool_server.request.remote_addr = "10.0.0.5"

        response, status = app.routes[("/analysis/full", ("GET",))]()

        self.assertEqual(status, 403)
        self.assertEqual(
            response,
            {"error": "full analysis endpoint is only available from localhost"},
        )


if __name__ == "__main__":
    unittest.main()
