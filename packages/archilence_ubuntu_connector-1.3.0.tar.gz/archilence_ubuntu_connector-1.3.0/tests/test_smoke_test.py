from __future__ import annotations

import sys
import unittest
from pathlib import Path
from types import SimpleNamespace


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from archilence_connector.smoke_test import SmokeTester


class SmokeTestAnalysisTests(unittest.TestCase):
    def test_check_full_analysis_validates_raw_and_mapped_sections(self) -> None:
        args = SimpleNamespace(
            service_name="archilence-connector",
            port=8990,
            timeout=10,
            core_url=None,
            connector_api_key=None,
            internal_api_key=None,
            owner_id=None,
            expected_callback_host=None,
            heartbeat_max_age_seconds=180,
            fail_on_degraded_collectors=False,
            local_only=True,
        )
        tester = SmokeTester(args)
        recorded: list[tuple[str, str]] = []
        tester.pass_ = lambda name, detail: recorded.append((name, detail))
        tester.fail = lambda name, detail: (_ for _ in ()).throw(
            AssertionError(f"{name}: {detail}")
        )
        tester.request_json = lambda method, url, headers=None, body=None: {
            "timestamp": "2026-04-14T14:00:00Z",
            "hostname": "host-a",
            "collector_health": {"system": "ok"},
            "raw": {
                "collectors": {
                    "system": {"ok": True, "entities": [], "metrics": {}, "error": None}
                }
            },
            "mapped": {"entities": [], "relations": []},
            "summary": {
                "raw_collectors": 1,
                "raw_entities": 0,
                "mapped_entities": 0,
                "mapped_relations": 0,
            },
        }

        tester.check_full_analysis()

        self.assertEqual(recorded[0][0], "/analysis/full")


if __name__ == "__main__":
    unittest.main()
