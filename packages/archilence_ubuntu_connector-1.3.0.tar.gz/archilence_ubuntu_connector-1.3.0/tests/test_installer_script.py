from pathlib import Path
import unittest


ROOT = Path(__file__).resolve().parents[1]
INSTALLER_PATH = ROOT / "ubuntu.sh"


class InstallerScriptTests(unittest.TestCase):
    def test_installer_bootstraps_os_deps_and_uses_virtualenv(self) -> None:
        installer = INSTALLER_PATH.read_text(encoding="utf-8")

        self.assertIn(
            'DEBIAN_FRONTEND=noninteractive apt-get install -y "${APT_PACKAGES[@]}"',
            installer,
        )
        self.assertIn('python3 -m venv "${VENV_DIR}"', installer)
        self.assertIn(
            'ln -sf "${VENV_DIR}/bin/archilence-connector" /usr/local/bin/archilence-connector',
            installer,
        )
        self.assertIn('systemctl enable archilence-connector', installer)
        self.assertIn('systemctl restart archilence-connector', installer)
        self.assertNotIn('systemctl enable --now archilence-connector', installer)
        self.assertNotIn('pip3 install --quiet --upgrade archilence-ubuntu-connector', installer)


if __name__ == "__main__":
    unittest.main()
