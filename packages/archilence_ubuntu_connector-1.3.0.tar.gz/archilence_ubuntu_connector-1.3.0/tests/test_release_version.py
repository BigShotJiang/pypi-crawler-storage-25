from __future__ import annotations

import importlib.util
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MODULE_PATH = ROOT / "tools" / "release_version.py"


def load_release_version_module():
    if not MODULE_PATH.exists():
        return None

    spec = importlib.util.spec_from_file_location("release_version", MODULE_PATH)
    if spec is None or spec.loader is None:
        return None

    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class ReleaseVersionTests(unittest.TestCase):
    def setUp(self) -> None:
        self.module = load_release_version_module()

    def test_release_version_module_exists(self) -> None:
        self.assertIsNotNone(
            self.module,
            "apps/ubuntu-connector/tools/release_version.py must exist",
        )

    def test_fix_commits_default_to_patch(self) -> None:
        self.assertIsNotNone(self.module, "release_version module missing")
        level = self.module.determine_bump_level(
            [
                "fix(ubuntu-connector): handle installer retries",
                "chore: tidy docs",
            ]
        )

        self.assertEqual(level, "patch")

    def test_feat_commits_bump_minor(self) -> None:
        self.assertIsNotNone(self.module, "release_version module missing")
        level = self.module.determine_bump_level(
            ["feat(ubuntu-connector): collect package inventory"]
        )

        self.assertEqual(level, "minor")

    def test_breaking_change_bumps_major(self) -> None:
        self.assertIsNotNone(self.module, "release_version module missing")
        level = self.module.determine_bump_level(
            [
                "feat!(ubuntu-connector): replace sync payload format",
                "docs: describe migration",
            ]
        )

        self.assertEqual(level, "major")

    def test_breaking_change_footer_bumps_major(self) -> None:
        self.assertIsNotNone(self.module, "release_version module missing")
        level = self.module.determine_bump_level(
            [
                "feat(ubuntu-connector): replace sync payload format\n\nBREAKING CHANGE: sync payload schema changed"
            ]
        )

        self.assertEqual(level, "major")

    def test_patch_bump_increments_last_segment(self) -> None:
        self.assertIsNotNone(self.module, "release_version module missing")
        self.assertEqual(self.module.bump_version("1.2.3", "patch"), "1.2.4")

    def test_minor_bump_resets_patch(self) -> None:
        self.assertIsNotNone(self.module, "release_version module missing")
        self.assertEqual(self.module.bump_version("1.2.3", "minor"), "1.3.0")

    def test_major_bump_resets_minor_and_patch(self) -> None:
        self.assertIsNotNone(self.module, "release_version module missing")
        self.assertEqual(self.module.bump_version("1.2.3", "major"), "2.0.0")

    def test_release_tag_uses_connector_prefix(self) -> None:
        self.assertIsNotNone(self.module, "release_version module missing")
        self.assertEqual(
            self.module.release_tag("1.2.4"),
            "ubuntu-connector-v1.2.4",
        )


if __name__ == "__main__":
    unittest.main()
