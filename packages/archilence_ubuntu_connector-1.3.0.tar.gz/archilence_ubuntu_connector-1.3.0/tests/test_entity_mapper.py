from __future__ import annotations

import sys
import unittest
from pathlib import Path
from types import SimpleNamespace
import types

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

if "archilence_connector.collectors" not in sys.modules:
    collectors_pkg = types.ModuleType("archilence_connector.collectors")
    collectors_pkg.__path__ = []
    sys.modules["archilence_connector.collectors"] = collectors_pkg

if "archilence_connector.collectors.base" not in sys.modules:
    base_module = types.ModuleType("archilence_connector.collectors.base")

    class CollectorResult(SimpleNamespace):
        @property
        def ok(self) -> bool:
            return getattr(self, "error", None) is None

    base_module.CollectorResult = CollectorResult
    sys.modules["archilence_connector.collectors.base"] = base_module
    sys.modules["archilence_connector.collectors"].base = base_module

from archilence_connector.entity_mapper import EntityMapper


def result(entities: list[dict]) -> SimpleNamespace:
    return SimpleNamespace(entities=entities, metrics={}, ok=True)


class EntityMapperDeletionTests(unittest.TestCase):
    def test_removed_entity_becomes_empty_deleted_payload(self) -> None:
        mapper = EntityMapper(hostname="host-a")
        results = {
            "systemd": result(
                entities=[
                    {
                        "id": "service://nginx.service",
                        "type": "SystemSoftware",
                        "properties": {"name": "nginx.service"},
                        "_removed": True,
                    }
                ]
            )
        }

        entities, relations = mapper.map_results(results)

        self.assertEqual(
            entities,
            [
                {
                    "externalId": "ubuntu:host-a:systemd:nginx.service",
                    "entityType": "SystemSoftware",
                    "data": {},
                }
            ],
        )
        self.assertEqual(
            relations,
            [
                {
                    "source": "ubuntu:host-a",
                    "target": "ubuntu:host-a:systemd:nginx.service",
                    "type": "Hosts",
                    "is_relation": True,
                    "deleted": True,
                }
            ],
        )

    def test_removed_compose_project_removes_compose_relation(self) -> None:
        mapper = EntityMapper(hostname="host-a")
        results = {
            "docker": result(
                entities=[
                    {
                        "id": "compose://shop",
                        "type": "ApplicationComponent",
                        "properties": {"name": "shop", "containers": ["web"]},
                        "_removed": True,
                    }
                ]
            )
        }

        entities, relations = mapper.map_results(results)

        self.assertEqual(
            entities,
            [
                {
                    "externalId": "ubuntu:host-a:docker:shop",
                    "entityType": "ApplicationComponent",
                    "data": {},
                }
            ],
        )
        self.assertIn(
            {
                "source": "ubuntu:host-a",
                "target": "ubuntu:host-a:docker:shop",
                "type": "Hosts",
                "is_relation": True,
                "deleted": True,
            },
            relations,
        )
        self.assertIn(
            {
                "source": "ubuntu:host-a:docker:shop",
                "target": "ubuntu:host-a:docker:web",
                "type": "Aggregation",
                "is_relation": True,
                "deleted": True,
            },
            relations,
        )


if __name__ == "__main__":
    unittest.main()
