from __future__ import annotations

import sys
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock
import types

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

if "yaml" not in sys.modules:
    yaml_stub = types.ModuleType("yaml")
    yaml_stub.safe_load = lambda *_args, **_kwargs: {}
    sys.modules["yaml"] = yaml_stub

if "httpx" not in sys.modules:
    httpx_stub = types.ModuleType("httpx")

    class HTTPError(Exception):
        pass

    class Client:
        def __init__(self, *args, **kwargs) -> None:
            self.patch = Mock()

        def close(self) -> None:
            return None

    httpx_stub.HTTPError = HTTPError
    httpx_stub.Client = Client
    sys.modules["httpx"] = httpx_stub

from archilence_connector import core_client


class DummyBuffer:
    def enqueue(self, payload) -> None:
        return None

    def drain(self) -> list[dict]:
        return []


class CoreClientStatusTests(unittest.TestCase):
    def test_register_uses_runtime_connector_version(self) -> None:
        core_client.OfflineBuffer = DummyBuffer
        core_client.get_connector_version = Mock(return_value="1.2.3")
        config = SimpleNamespace(
            archilence=SimpleNamespace(
                endpoint="https://example.test",
                api_key="ak_test",
            ),
            server=SimpleNamespace(name="prod-01"),
            intervals=SimpleNamespace(snapshot_full=300),
        )
        client = core_client.CoreClient(config)
        try:
            mock_response = Mock()
            mock_response.raise_for_status.return_value = None
            mock_response.json.return_value = {"connector": {"id": 42}}
            client._client.post = Mock(return_value=mock_response)

            result = client.register("https://connector.example.test/callback")

            self.assertEqual(result, {"connector": {"id": 42}})
            client._client.post.assert_called_once_with(
                "/register",
                json={
                    "name": "ubuntu-prod-01",
                    "callbackUrl": "https://connector.example.test/callback",
                    "schedule": "*/300 * * * * *",
                    "version": "1.2.3",
                    "capabilities": [
                        "system",
                        "docker",
                        "systemd",
                        "networking",
                        "performance",
                    ],
                },
            )
        finally:
            client.close()

    def test_report_status_uses_setup_status_field(self) -> None:
        core_client.OfflineBuffer = DummyBuffer
        config = SimpleNamespace(
            archilence=SimpleNamespace(
                endpoint="https://example.test",
                api_key="ak_test",
            )
        )
        client = core_client.CoreClient(config)
        try:
            mock_response = Mock()
            mock_response.raise_for_status.return_value = None
            client._client.patch = Mock(return_value=mock_response)

            ok = client.report_status("active")

            self.assertTrue(ok)
            client._client.patch.assert_called_once_with(
                "/status",
                json={"setup_status": "active"},
            )
        finally:
            client.close()


if __name__ == "__main__":
    unittest.main()
