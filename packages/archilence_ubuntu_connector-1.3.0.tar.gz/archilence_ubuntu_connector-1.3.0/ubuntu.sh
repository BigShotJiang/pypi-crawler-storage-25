#!/usr/bin/env bash
#
# Archilence Ubuntu Connector — Installer
# Usage: curl -fsSL https://cockpit.archilence.com/install/ubuntu.sh | sudo bash
#
set -euo pipefail

CONFIG_DIR="/etc/archilence"
DATA_DIR="/var/lib/archilence"
INSTALL_DIR="/opt/archilence-connector"
VENV_DIR="${INSTALL_DIR}/.venv"
SERVICE_USER="archilence"
APT_PACKAGES=()

echo "=== Archilence Ubuntu Connector Installer ==="
echo ""

# Check for root
if [ "$(id -u)" -ne 0 ]; then
    echo "Error: This installer must be run as root (or with sudo)."
    exit 1
fi

# Check for Ubuntu
if ! grep -qi "ubuntu" /etc/os-release 2>/dev/null; then
    echo "Warning: This connector is designed for Ubuntu. Proceeding anyway..."
fi

# Check apt-get availability for dependency bootstrap
if ! command -v apt-get &>/dev/null; then
    echo "Error: apt-get is required for automatic dependency installation."
    exit 1
fi

ensure_apt_package() {
    local package="$1"
    if ! dpkg -s "${package}" >/dev/null 2>&1; then
        APT_PACKAGES+=("${package}")
    fi
}

if ! command -v python3 &>/dev/null; then
    APT_PACKAGES+=("python3")
fi
ensure_apt_package "python3-venv"
ensure_apt_package "ca-certificates"

if [ "${#APT_PACKAGES[@]}" -gt 0 ]; then
    echo "Installing OS dependencies: ${APT_PACKAGES[*]}..."
    apt-get update
    DEBIAN_FRONTEND=noninteractive apt-get install -y "${APT_PACKAGES[@]}"
fi

# Check Python 3.10+
PYTHON_VERSION=$(python3 -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')
if python3 -c "import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)"; then
    echo "Python ${PYTHON_VERSION} detected."
else
    echo "Error: Python 3.10+ is required (found ${PYTHON_VERSION})."
    exit 1
fi

if ! python3 -m venv --help >/dev/null 2>&1; then
    echo "Error: python3-venv is required but could not be initialized."
    exit 1
fi

# Create system user
if ! id "${SERVICE_USER}" &>/dev/null; then
    echo "Creating system user '${SERVICE_USER}'..."
    useradd --system --create-home --shell /bin/false "${SERVICE_USER}"
fi

# Add to docker group if Docker is installed
if getent group docker &>/dev/null; then
    echo "Adding '${SERVICE_USER}' to docker group..."
    usermod -aG docker "${SERVICE_USER}"
fi

# Create directories
echo "Creating directories..."
mkdir -p "${CONFIG_DIR}" "${DATA_DIR}" "${INSTALL_DIR}"
chown "${SERVICE_USER}:${SERVICE_USER}" "${DATA_DIR}"

if [ ! -x "${VENV_DIR}/bin/python" ]; then
    echo "Creating virtual environment..."
    python3 -m venv "${VENV_DIR}"
fi

# Install Python package
echo "Installing archilence-ubuntu-connector package into virtual environment..."
"${VENV_DIR}/bin/pip" install --quiet --upgrade pip setuptools wheel
"${VENV_DIR}/bin/pip" install --quiet --upgrade archilence-ubuntu-connector

echo "Linking CLI commands..."
ln -sf "${VENV_DIR}/bin/archilence-connector" /usr/local/bin/archilence-connector
ln -sf "${VENV_DIR}/bin/archilence-connector-smoke-test" /usr/local/bin/archilence-connector-smoke-test

# Write example config if none exists
if [ ! -f "${CONFIG_DIR}/connector.yml" ]; then
    echo "Writing example configuration to ${CONFIG_DIR}/connector.yml..."
    cat > "${CONFIG_DIR}/connector.yml" << 'YAML'
archilence:
  endpoint: https://cockpit.archilence.com
  api_key: ak_REPLACE_WITH_YOUR_API_KEY

server:
  name: ""
  tags: []
  environment: "production"

collectors:
  system: true
  performance: true
  processes: true
  docker: true
  systemd: true
  networking: true
  packages: false
  files:
    enabled: false
    paths: []

intervals:
  snapshot_full: 300
  snapshot_delta: 60
  heartbeat: 30

control:
  enabled: false
  allow_exec: false
YAML
fi

# Install systemd unit
echo "Installing systemd service..."
cat > /etc/systemd/system/archilence-connector.service << 'UNIT'
[Unit]
Description=Archilence Ubuntu Connector
Documentation=https://docs.archilence.com/connectors/ubuntu
After=network-online.target docker.service
Wants=network-online.target

[Service]
Type=simple
User=archilence
Group=archilence
ExecStart=/usr/local/bin/archilence-connector
Restart=on-failure
RestartSec=10
Environment=ARCHILENCE_CONFIG=/etc/archilence/connector.yml
Environment=LOG_LEVEL=INFO
NoNewPrivileges=yes
ProtectSystem=strict
ProtectHome=yes
ReadWritePaths=/var/lib/archilence
PrivateTmp=yes

[Install]
WantedBy=multi-user.target
UNIT

systemctl daemon-reload
systemctl enable archilence-connector
systemctl restart archilence-connector

echo ""
echo "=== Installation complete ==="
echo ""
echo "Next steps:"
echo "  1. Edit ${CONFIG_DIR}/connector.yml with your API key"
echo "  2. Check status:        systemctl status archilence-connector"
echo "  3. View logs:           journalctl -u archilence-connector -f"
echo "  4. Full analysis:       curl -s http://127.0.0.1:8990/analysis/full | jq"
echo "  5. Smoke test:          archilence-connector-smoke-test --local-only"
echo ""
