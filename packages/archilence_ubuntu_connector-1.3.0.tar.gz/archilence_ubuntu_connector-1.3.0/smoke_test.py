#!/usr/bin/env python3
"""Repo-local wrapper for the packaged smoke test entry point."""

from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from archilence_connector.smoke_test import main


if __name__ == "__main__":
    sys.exit(main())
