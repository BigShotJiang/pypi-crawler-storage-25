"""Configuration loader for /etc/archilence/connector.yml."""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

DEFAULT_CONFIG_PATH = "/etc/archilence/connector.yml"


@dataclass
class ArchilenceConfig:
    endpoint: str = ""
    api_key: str = ""


@dataclass
class ServerConfig:
    name: str = ""
    tags: list[str] = field(default_factory=list)
    environment: str = "production"


@dataclass
class FilesCollectorConfig:
    enabled: bool = False
    paths: list[str] = field(default_factory=list)


@dataclass
class CollectorsConfig:
    system: bool = True
    performance: bool = True
    processes: bool = True
    docker: bool = True
    systemd: bool = True
    networking: bool = True
    packages: bool = False
    files: FilesCollectorConfig = field(default_factory=FilesCollectorConfig)


@dataclass
class IntervalsConfig:
    snapshot_full: int = 300
    snapshot_delta: int = 60
    heartbeat: int = 30
    performance: int = 60


@dataclass
class ControlConfig:
    enabled: bool = False
    allow_exec: bool = False


@dataclass
class ConnectorConfig:
    archilence: ArchilenceConfig = field(default_factory=ArchilenceConfig)
    server: ServerConfig = field(default_factory=ServerConfig)
    collectors: CollectorsConfig = field(default_factory=CollectorsConfig)
    intervals: IntervalsConfig = field(default_factory=IntervalsConfig)
    control: ControlConfig = field(default_factory=ControlConfig)
    port: int = 8990


def load_config(path: str | None = None) -> ConnectorConfig:
    """Load configuration from YAML file.

    Priority: explicit path > ARCHILENCE_CONFIG env > default path.
    """
    config_path = path or os.environ.get("ARCHILENCE_CONFIG", DEFAULT_CONFIG_PATH)
    p = Path(config_path)

    if not p.exists():
        raise FileNotFoundError(f"Configuration file not found: {config_path}")

    with p.open() as f:
        raw: dict[str, Any] = yaml.safe_load(f) or {}

    cfg = ConnectorConfig()

    # Archilence section
    if a := raw.get("archilence"):
        cfg.archilence = ArchilenceConfig(
            endpoint=a.get("endpoint", ""),
            api_key=a.get("api_key", ""),
        )

    # Server section
    if s := raw.get("server"):
        cfg.server = ServerConfig(
            name=s.get("name", ""),
            tags=s.get("tags", []),
            environment=s.get("environment", "production"),
        )

    # Collectors section
    if c := raw.get("collectors"):
        files_raw = c.get("files", {})
        files_cfg = FilesCollectorConfig(
            enabled=files_raw.get("enabled", False) if isinstance(files_raw, dict) else False,
            paths=files_raw.get("paths", []) if isinstance(files_raw, dict) else [],
        )
        cfg.collectors = CollectorsConfig(
            system=c.get("system", True),
            performance=c.get("performance", True),
            processes=c.get("processes", True),
            docker=c.get("docker", True),
            systemd=c.get("systemd", True),
            networking=c.get("networking", True),
            packages=c.get("packages", False),
            files=files_cfg,
        )

    # Intervals section
    if i := raw.get("intervals"):
        cfg.intervals = IntervalsConfig(
            snapshot_full=i.get("snapshot_full", 300),
            snapshot_delta=i.get("snapshot_delta", 60),
            heartbeat=i.get("heartbeat", 30),
            performance=i.get("performance", 60),
        )

    # Control section
    if ct := raw.get("control"):
        cfg.control = ControlConfig(
            enabled=ct.get("enabled", False),
            allow_exec=ct.get("allow_exec", False),
        )

    # Port
    cfg.port = raw.get("port", int(os.environ.get("PORT", "8990")))

    return cfg
