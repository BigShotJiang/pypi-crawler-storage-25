"""HTTP server providing read/control tools as the connector's callback URL."""

from __future__ import annotations

import ipaddress
import logging
import os
import subprocess
from typing import TYPE_CHECKING, Any

from flask import Flask, jsonify, request

if TYPE_CHECKING:
    from .collector_manager import CollectorManager
    from .config import ConnectorConfig
    from .sync_engine import SyncEngine

logger = logging.getLogger("archilence.tool_server")


def _is_loopback_request(remote_addr: str | None) -> bool:
    if not remote_addr:
        return False

    try:
        return ipaddress.ip_address(remote_addr).is_loopback
    except ValueError:
        return False


def create_app(
    config: "ConnectorConfig",
    collector_manager: "CollectorManager",
    sync_engine: "SyncEngine",
) -> Flask:
    app = Flask("archilence-connector")
    app.config["JSON_SORT_KEYS"] = False

    # --- Health & Sync endpoints ---

    @app.route("/health", methods=["GET"])
    def health():
        return jsonify({"status": "ok", "collectors": collector_manager.get_health()})

    @app.route("/sync", methods=["POST"])
    def trigger_sync():
        result = sync_engine.full_sync()
        return jsonify(result)

    @app.route("/analysis/full", methods=["GET"])
    def full_analysis():
        if not _is_loopback_request(getattr(request, "remote_addr", None)):
            return jsonify(
                {"error": "full analysis endpoint is only available from localhost"}
            ), 403
        return jsonify(sync_engine.analysis_snapshot())

    # --- Read Tools ---

    @app.route("/tools/get_server_info", methods=["POST"])
    def tool_get_server_info():
        system_collector = collector_manager.get_collector("system")
        if not system_collector:
            return jsonify({"error": "system collector not enabled"}), 400
        result = system_collector.collect()
        data = result.entities[0]["properties"] if result.ok and result.entities else {}
        data["tags"] = config.server.tags
        data["environment"] = config.server.environment
        return jsonify(data)

    @app.route("/tools/get_performance", methods=["POST"])
    def tool_get_performance():
        perf_collector = collector_manager.get_collector("performance")
        if not perf_collector:
            return jsonify({"error": "performance collector not enabled"}), 400
        result = perf_collector.collect()
        return jsonify(result.metrics if result.ok else {"error": result.error})

    @app.route("/tools/list_containers", methods=["POST"])
    def tool_list_containers():
        docker_collector = collector_manager.get_collector("docker")
        if not docker_collector:
            return jsonify({"error": "docker collector not enabled"}), 400
        result = docker_collector.collect()
        if not result.ok:
            return jsonify({"error": result.error})
        containers = [
            e["properties"]
            for e in result.entities
            if e.get("type") == "SystemSoftware"
        ]
        return jsonify({"containers": containers, "metrics": result.metrics})

    @app.route("/tools/list_services", methods=["POST"])
    def tool_list_services():
        systemd_collector = collector_manager.get_collector("systemd")
        if not systemd_collector:
            return jsonify({"error": "systemd collector not enabled"}), 400
        result = systemd_collector.collect()
        if not result.ok:
            return jsonify({"error": result.error})
        services = [e["properties"] for e in result.entities]
        return jsonify({"services": services, "metrics": result.metrics})

    @app.route("/tools/list_ports", methods=["POST"])
    def tool_list_ports():
        net_collector = collector_manager.get_collector("networking")
        if not net_collector:
            return jsonify({"error": "networking collector not enabled"}), 400
        result = net_collector.collect()
        if not result.ok:
            return jsonify({"error": result.error})
        return jsonify({
            "listening_ports": result.metrics.get("listening_ports_detail", []),
            "total": result.metrics.get("listening_ports", 0),
        })

    @app.route("/tools/get_processes", methods=["POST"])
    def tool_get_processes():
        proc_collector = collector_manager.get_collector("processes")
        if not proc_collector:
            return jsonify({"error": "processes collector not enabled"}), 400
        body = request.get_json(silent=True) or {}
        top_n = body.get("top_n", 20)
        proc_collector._top_n = top_n
        result = proc_collector.collect()
        if not result.ok:
            return jsonify({"error": result.error})
        processes = [e["properties"] for e in result.entities]
        return jsonify({"processes": processes, "metrics": result.metrics})

    @app.route("/tools/get_logs", methods=["POST"])
    def tool_get_logs():
        body = request.get_json(silent=True) or {}
        service = body.get("service")
        lines = body.get("lines", 100)
        if not service:
            return jsonify({"error": "service parameter required"}), 400
        try:
            result = subprocess.run(
                ["journalctl", "-u", service, "-n", str(lines), "--no-pager"],
                capture_output=True, text=True, timeout=10,
            )
            return jsonify({"service": service, "lines": result.stdout.strip().splitlines()})
        except Exception as e:
            return jsonify({"error": str(e)})

    @app.route("/tools/get_network_info", methods=["POST"])
    def tool_get_network_info():
        net_collector = collector_manager.get_collector("networking")
        if not net_collector:
            return jsonify({"error": "networking collector not enabled"}), 400
        result = net_collector.collect()
        if not result.ok:
            return jsonify({"error": result.error})
        interfaces = [e["properties"] for e in result.entities]
        return jsonify({"interfaces": interfaces, "metrics": result.metrics})

    # --- Control Tools (require config.control.enabled) ---

    @app.route("/tools/restart_service", methods=["POST"])
    def tool_restart_service():
        if not config.control.enabled:
            return jsonify({"error": "control tools are disabled"}), 403
        body = request.get_json(silent=True) or {}
        name = body.get("name")
        if not name:
            return jsonify({"error": "name parameter required"}), 400
        try:
            result = subprocess.run(
                ["sudo", "systemctl", "restart", name],
                capture_output=True, text=True, timeout=30,
            )
            success = result.returncode == 0
            return jsonify({"success": success, "output": result.stdout or result.stderr})
        except Exception as e:
            return jsonify({"error": str(e)})

    @app.route("/tools/restart_container", methods=["POST"])
    def tool_restart_container():
        if not config.control.enabled:
            return jsonify({"error": "control tools are disabled"}), 403
        body = request.get_json(silent=True) or {}
        name = body.get("name")
        if not name:
            return jsonify({"error": "name parameter required"}), 400
        try:
            import docker
            client = docker.from_env()
            container = client.containers.get(name)
            container.restart()
            client.close()
            return jsonify({"success": True, "container": name})
        except Exception as e:
            return jsonify({"error": str(e)})

    @app.route("/tools/stop_container", methods=["POST"])
    def tool_stop_container():
        if not config.control.enabled:
            return jsonify({"error": "control tools are disabled"}), 403
        body = request.get_json(silent=True) or {}
        name = body.get("name")
        if not name:
            return jsonify({"error": "name parameter required"}), 400
        try:
            import docker
            client = docker.from_env()
            container = client.containers.get(name)
            container.stop()
            client.close()
            return jsonify({"success": True, "container": name})
        except Exception as e:
            return jsonify({"error": str(e)})

    @app.route("/tools/exec_command", methods=["POST"])
    def tool_exec_command():
        if not config.control.enabled or not config.control.allow_exec:
            return jsonify({"error": "exec_command requires control.enabled and control.allow_exec"}), 403
        body = request.get_json(silent=True) or {}
        cmd = body.get("cmd")
        if not cmd:
            return jsonify({"error": "cmd parameter required"}), 400
        try:
            result = subprocess.run(
                cmd, shell=True, capture_output=True, text=True, timeout=30,
            )
            return jsonify({
                "returncode": result.returncode,
                "stdout": result.stdout,
                "stderr": result.stderr,
            })
        except Exception as e:
            return jsonify({"error": str(e)})

    return app
