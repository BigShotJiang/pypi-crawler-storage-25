"""Manages collector lifecycle — runs collectors with isolation and tracks health."""

from __future__ import annotations

import logging
from typing import Any

from .collectors import ALL_COLLECTORS, BaseCollector, CollectorResult
from .collectors.files import FilesCollector
from .collectors.processes import ProcessesCollector
from .config import ConnectorConfig

logger = logging.getLogger("archilence.collector_manager")


class CollectorManager:
    """Instantiates and runs collectors based on configuration."""

    def __init__(self, config: ConnectorConfig) -> None:
        self._collectors: dict[str, BaseCollector] = {}
        self._health: dict[str, str] = {}
        self._previous_results: dict[str, CollectorResult] = {}

        collector_flags: dict[str, bool] = {
            "system": config.collectors.system,
            "performance": config.collectors.performance,
            "processes": config.collectors.processes,
            "docker": config.collectors.docker,
            "systemd": config.collectors.systemd,
            "networking": config.collectors.networking,
            "packages": config.collectors.packages,
            "files": config.collectors.files.enabled,
        }

        for name, enabled in collector_flags.items():
            if not enabled:
                continue

            cls = ALL_COLLECTORS.get(name)
            if not cls:
                continue

            # Special initialization for collectors with config
            if name == "files":
                self._collectors[name] = FilesCollector(paths=config.collectors.files.paths)
            elif name == "processes":
                self._collectors[name] = ProcessesCollector()
            else:
                self._collectors[name] = cls()

            self._health[name] = "ok"

        logger.info("Enabled collectors: %s", list(self._collectors.keys()))

    def collect_all(self) -> dict[str, CollectorResult]:
        """Run all enabled collectors. Each runs in isolation — one failure doesn't affect others."""
        results: dict[str, CollectorResult] = {}

        for name, collector in self._collectors.items():
            try:
                result = collector.collect()
                results[name] = result
                self._health[name] = "ok" if result.ok else f"degraded: {result.error}"
            except Exception as e:
                logger.error("Collector '%s' crashed: %s", name, e)
                results[name] = CollectorResult(error=str(e))
                self._health[name] = f"error: {e}"

        self._previous_results = results
        return results

    def collect_delta(self) -> dict[str, CollectorResult]:
        """Run all collectors in delta mode, comparing against previous full collection."""
        results: dict[str, CollectorResult] = {}

        for name, collector in self._collectors.items():
            try:
                previous = self._previous_results.get(name, CollectorResult())
                result = collector.collect_delta(previous)
                results[name] = result
                self._health[name] = "ok" if result.ok else f"degraded: {result.error}"
            except Exception as e:
                logger.error("Collector '%s' delta crashed: %s", name, e)
                results[name] = CollectorResult(error=str(e))
                self._health[name] = f"error: {e}"

        return results

    def get_health(self) -> dict[str, str]:
        """Return health status for each collector."""
        return dict(self._health)

    def get_collector(self, name: str) -> BaseCollector | None:
        return self._collectors.get(name)
