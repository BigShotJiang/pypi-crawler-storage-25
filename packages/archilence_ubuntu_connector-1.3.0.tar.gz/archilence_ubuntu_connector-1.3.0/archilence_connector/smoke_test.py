#!/usr/bin/env python3
"""Smoke-test the installed Archilence Ubuntu connector."""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any
from urllib import error, parse, request


ENV_PREFIX = "ARCHILENCE_SMOKE_"


@dataclass
class CheckResult:
    status: str
    name: str
    detail: str


class SmokeTestFailure(RuntimeError):
    """Raised when a smoke-test step cannot complete successfully."""


def env(name: str, default: str | None = None) -> str | None:
    return os.environ.get(f"{ENV_PREFIX}{name}", default)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Verify the Archilence Ubuntu connector locally and against Core."
    )
    parser.add_argument(
        "--service-name",
        default=env("SERVICE_NAME", "archilence-connector"),
        help="systemd service name",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=int(env("PORT", "8990") or "8990"),
        help="local tool-server port",
    )
    parser.add_argument(
        "--timeout",
        type=int,
        default=int(env("TIMEOUT", "10") or "10"),
        help="HTTP and process timeout in seconds",
    )
    parser.add_argument(
        "--core-url",
        default=env("CORE_URL"),
        help="Core base URL, for example https://cockpit.archilence.com",
    )
    parser.add_argument(
        "--connector-api-key",
        default=env("CONNECTOR_API_KEY"),
        help="connector API key used for /config and connector-authenticated checks",
    )
    parser.add_argument(
        "--internal-api-key",
        default=env("INTERNAL_API_KEY"),
        help="optional Core internal API key for entity-ingestion verification",
    )
    parser.add_argument(
        "--owner-id",
        default=env("OWNER_ID"),
        help="optional owner ID override for entity-ingestion verification",
    )
    parser.add_argument(
        "--expected-callback-host",
        default=env("EXPECTED_CALLBACK_HOST"),
        help="optional expected callback host; if omitted, callbackUrl is only checked for presence",
    )
    parser.add_argument(
        "--heartbeat-max-age-seconds",
        type=int,
        default=int(env("HEARTBEAT_MAX_AGE_SECONDS", "180") or "180"),
        help="maximum accepted age for connector.lastHeartbeatAt",
    )
    parser.add_argument(
        "--fail-on-degraded-collectors",
        action="store_true",
        default=(env("FAIL_ON_DEGRADED_COLLECTORS", "false") or "").lower() == "true",
        help="treat degraded collector states as failures instead of warnings",
    )
    parser.add_argument(
        "--local-only",
        action="store_true",
        help="skip all Core-side verification even if Core credentials are provided",
    )
    return parser.parse_args()


class SmokeTester:
    def __init__(self, args: argparse.Namespace) -> None:
        self.args = args
        self.results: list[CheckResult] = []
        self.base_url = f"http://127.0.0.1:{args.port}"
        self.core_url = args.core_url.rstrip("/") if args.core_url else None

    def add_result(self, status: str, name: str, detail: str) -> None:
        self.results.append(CheckResult(status=status, name=name, detail=detail))

    def pass_(self, name: str, detail: str) -> None:
        self.add_result("PASS", name, detail)

    def fail(self, name: str, detail: str) -> None:
        self.add_result("FAIL", name, detail)

    def warn(self, name: str, detail: str) -> None:
        self.add_result("WARN", name, detail)

    def skip(self, name: str, detail: str) -> None:
        self.add_result("SKIP", name, detail)

    def run(self) -> int:
        try:
            self.check_service()
            self.check_local_health()
            self.check_local_tools()
            self.check_full_analysis()
            self.check_manual_sync()
        except SmokeTestFailure:
            return self.finish()

        if self.args.local_only:
            self.skip("Core verification", "Skipped by --local-only")
            return self.finish()

        if not self.core_url and not self.args.connector_api_key and not self.args.internal_api_key:
            self.skip("Core verification", "No Core URL or credentials supplied")
            return self.finish()

        if not self.core_url or not self.args.connector_api_key:
            self.fail(
                "Core verification",
                "Remote checks require both --core-url and --connector-api-key",
            )
            return self.finish()

        try:
            connector = self.check_connector_config()
            self.check_callback(connector)
            self.check_owner(connector)
            self.check_online(connector)
            self.check_heartbeat(connector)
            self.check_ingested_entities(connector)
        except SmokeTestFailure:
            return self.finish()

        return self.finish()

    def finish(self) -> int:
        for result in self.results:
            print(f"[{result.status}] {result.name}: {result.detail}")

        failures = sum(1 for result in self.results if result.status == "FAIL")
        warnings = sum(1 for result in self.results if result.status == "WARN")
        print(
            f"\nSummary: {len(self.results)} checks, {failures} failure(s), {warnings} warning(s)"
        )
        return 1 if failures else 0

    def check_service(self) -> None:
        result = self.run_command(["systemctl", "is-active", self.args.service_name])
        if result.returncode != 0 or result.stdout.strip() != "active":
            self.fail(
                "systemd service",
                f"{self.args.service_name} is not active ({result.stdout.strip() or result.stderr.strip() or 'unknown'})",
            )
            raise SmokeTestFailure
        self.pass_("systemd service", f"{self.args.service_name} is active")

    def check_local_health(self) -> None:
        payload = self.request_json("GET", f"{self.base_url}/health")
        if payload.get("status") != "ok":
            self.fail("/health", f"Unexpected status payload: {payload!r}")
            raise SmokeTestFailure

        collectors = payload.get("collectors", {})
        if not isinstance(collectors, dict):
            self.fail("/health", "Collector status map missing from response")
            raise SmokeTestFailure

        self.pass_("/health", "Tool server responded successfully")

        errors = {
            name: state for name, state in collectors.items() if str(state).startswith("error:")
        }
        degraded = {
            name: state
            for name, state in collectors.items()
            if not str(state).startswith("ok") and not str(state).startswith("error:")
        }

        if errors:
            joined = ", ".join(f"{name}={state}" for name, state in sorted(errors.items()))
            self.fail("collector health", f"Collector errors detected: {joined}")
            raise SmokeTestFailure

        if degraded:
            joined = ", ".join(f"{name}={state}" for name, state in sorted(degraded.items()))
            if self.args.fail_on_degraded_collectors:
                self.fail("collector health", f"Degraded collectors detected: {joined}")
                raise SmokeTestFailure
            self.warn("collector health", f"Degraded collectors detected: {joined}")
        else:
            self.pass_("collector health", "All enabled collectors report ok")

    def check_local_tools(self) -> None:
        server_info = self.request_json("POST", f"{self.base_url}/tools/get_server_info")
        hostname = server_info.get("hostname")
        if not hostname:
            self.fail("/tools/get_server_info", f"hostname missing in response: {server_info!r}")
            raise SmokeTestFailure
        self.pass_("/tools/get_server_info", f"Reported hostname {hostname}")

        performance = self.request_json("POST", f"{self.base_url}/tools/get_performance")
        required_keys = {"cpu_percent", "mem_percent", "disk_percent"}
        missing = sorted(key for key in required_keys if key not in performance)
        if missing:
            self.fail(
                "/tools/get_performance",
                f"Missing expected metrics: {', '.join(missing)}",
            )
            raise SmokeTestFailure
        self.pass_("/tools/get_performance", "Performance metrics returned expected keys")

    def check_manual_sync(self) -> None:
        sync_response = self.request_json("POST", f"{self.base_url}/sync")
        if not isinstance(sync_response.get("success"), bool):
            self.fail("/sync", f"Unexpected sync response: {sync_response!r}")
            raise SmokeTestFailure
        if not sync_response["success"]:
            self.fail("/sync", f"Manual sync did not complete successfully: {sync_response!r}")
            raise SmokeTestFailure

        detail = (
            f"Manual sync succeeded with {sync_response.get('entities_count', 0)} entities "
            f"and {sync_response.get('relations_count', 0)} relations"
        )
        self.pass_("/sync", detail)

    def check_full_analysis(self) -> None:
        payload = self.request_json("GET", f"{self.base_url}/analysis/full")
        if not isinstance(payload, dict):
            self.fail("/analysis/full", f"Unexpected response payload: {payload!r}")
            raise SmokeTestFailure

        required_keys = {"timestamp", "hostname", "collector_health", "raw", "mapped", "summary"}
        missing = sorted(key for key in required_keys if key not in payload)
        if missing:
            self.fail("/analysis/full", f"Missing expected keys: {', '.join(missing)}")
            raise SmokeTestFailure

        raw_collectors = payload.get("raw", {}).get("collectors")
        if not isinstance(raw_collectors, dict):
            self.fail("/analysis/full", f"raw.collectors missing or invalid: {payload!r}")
            raise SmokeTestFailure

        mapped = payload.get("mapped")
        if not isinstance(mapped, dict):
            self.fail("/analysis/full", f"mapped section missing or invalid: {payload!r}")
            raise SmokeTestFailure

        entities = mapped.get("entities")
        relations = mapped.get("relations")
        if not isinstance(entities, list) or not isinstance(relations, list):
            self.fail(
                "/analysis/full",
                "mapped.entities and mapped.relations must both be arrays",
            )
            raise SmokeTestFailure

        self.pass_(
            "/analysis/full",
            f"Full analysis returned {len(raw_collectors)} collectors, {len(entities)} entities, {len(relations)} relations",
        )

    def check_connector_config(self) -> dict[str, Any]:
        connector = self.request_json(
            "GET",
            f"{self.core_url}/config",
            headers={"X-API-KEY": self.args.connector_api_key},
        )
        connector_id = connector.get("id")
        if not connector_id:
            self.fail("/config", f"Connector ID missing in response: {connector!r}")
            raise SmokeTestFailure
        self.pass_("/config", f"Fetched connector record {connector_id}")
        return connector

    def check_callback(self, connector: dict[str, Any]) -> None:
        callback_url = connector.get("callbackUrl")
        if not callback_url:
            self.fail("callbackUrl", "Connector is not registered with a callbackUrl in Core")
            raise SmokeTestFailure

        parsed_callback = parse.urlparse(callback_url)
        if not parsed_callback.scheme or not parsed_callback.hostname:
            self.fail("callbackUrl", f"Invalid callbackUrl returned by Core: {callback_url}")
            raise SmokeTestFailure

        if self.args.expected_callback_host:
            expected_port = self.args.port
            actual_port = parsed_callback.port or (80 if parsed_callback.scheme == "http" else 443)
            if (
                parsed_callback.hostname != self.args.expected_callback_host
                or actual_port != expected_port
            ):
                self.fail(
                    "callbackUrl",
                    f"Expected http://{self.args.expected_callback_host}:{expected_port}, got {callback_url}",
                )
                raise SmokeTestFailure

        self.pass_("callbackUrl", callback_url)

    def check_owner(self, connector: dict[str, Any]) -> None:
        owner_id = self.args.owner_id or connector.get("ownerId")
        if not owner_id:
            self.fail("owner assignment", "Connector has no ownerId assigned in Core")
            raise SmokeTestFailure
        self.pass_("owner assignment", f"Connector ownerId is {owner_id}")

    def check_online(self, connector: dict[str, Any]) -> None:
        if connector.get("isOnline") is not True:
            self.fail("connector online state", f"Core reports isOnline={connector.get('isOnline')!r}")
            raise SmokeTestFailure
        self.pass_("connector online state", "Core reports the connector as online")

    def check_heartbeat(self, connector: dict[str, Any]) -> None:
        raw_last_heartbeat = connector.get("lastHeartbeatAt")
        if not raw_last_heartbeat:
            self.fail("heartbeat recency", "Connector lastHeartbeatAt is missing in Core")
            raise SmokeTestFailure

        last_heartbeat = self.parse_timestamp(raw_last_heartbeat)
        age_seconds = (datetime.now(timezone.utc) - last_heartbeat).total_seconds()
        if age_seconds > self.args.heartbeat_max_age_seconds:
            self.fail(
                "heartbeat recency",
                f"Last heartbeat is {int(age_seconds)}s old, limit is {self.args.heartbeat_max_age_seconds}s",
            )
            raise SmokeTestFailure

        self.pass_("heartbeat recency", f"Last heartbeat is {int(age_seconds)}s old")

    def check_ingested_entities(self, connector: dict[str, Any]) -> None:
        if not self.args.internal_api_key:
            self.skip(
                "entity ingestion",
                "Skipped because --internal-api-key was not supplied",
            )
            return

        owner_id = self.args.owner_id or connector.get("ownerId")
        if not owner_id:
            self.fail(
                "entity ingestion",
                "Cannot verify ingested entities because ownerId is unavailable",
            )
            raise SmokeTestFailure

        query = parse.urlencode({"ownerId": owner_id})
        entities = self.request_json(
            "GET",
            f"{self.core_url}/api/entities/active?{query}",
            headers={"X-Internal-API-Key": self.args.internal_api_key},
        )
        if not isinstance(entities, list):
            self.fail("entity ingestion", f"Unexpected entities response: {entities!r}")
            raise SmokeTestFailure

        connector_id = connector.get("id")
        matched = 0
        for entity in entities:
            external_ids = entity.get("external_ids", [])
            if not isinstance(external_ids, list):
                continue
            for external_id in external_ids:
                if (
                    isinstance(external_id, dict)
                    and external_id.get("connector_id") == connector_id
                    and str(external_id.get("external_id", "")).startswith("ubuntu:")
                ):
                    matched += 1
                    break

        if matched == 0:
            self.fail(
                "entity ingestion",
                "No active entities were found for this connector in /api/entities/active",
            )
            raise SmokeTestFailure

        self.pass_("entity ingestion", f"Found {matched} active Ubuntu-backed entities in Core")

    def request_json(
        self,
        method: str,
        url: str,
        headers: dict[str, str] | None = None,
        body: dict[str, Any] | None = None,
    ) -> Any:
        payload = None
        merged_headers = {"Accept": "application/json"}
        if headers:
            merged_headers.update(headers)
        if body is not None:
            payload = json.dumps(body).encode("utf-8")
            merged_headers["Content-Type"] = "application/json"

        req = request.Request(url, method=method, headers=merged_headers, data=payload)
        try:
            with request.urlopen(req, timeout=self.args.timeout) as response:
                raw = response.read().decode("utf-8")
                return json.loads(raw) if raw else {}
        except error.HTTPError as exc:
            response_body = exc.read().decode("utf-8", errors="replace")
            self.fail(
                method + " " + parse.urlparse(url).path,
                f"HTTP {exc.code}: {response_body.strip() or exc.reason}",
            )
            raise SmokeTestFailure from exc
        except (error.URLError, TimeoutError, json.JSONDecodeError) as exc:
            self.fail(
                method + " " + parse.urlparse(url).path,
                f"Request failed: {exc}",
            )
            raise SmokeTestFailure from exc

    def run_command(self, command: list[str]) -> subprocess.CompletedProcess[str]:
        try:
            return subprocess.run(
                command,
                capture_output=True,
                text=True,
                timeout=self.args.timeout,
                check=False,
            )
        except FileNotFoundError as exc:
            self.fail(command[0], f"Command not found: {command[0]}")
            raise SmokeTestFailure from exc
        except subprocess.TimeoutExpired as exc:
            self.fail(command[0], f"Command timed out after {self.args.timeout}s")
            raise SmokeTestFailure from exc

    @staticmethod
    def parse_timestamp(value: str) -> datetime:
        normalized = value.replace("Z", "+00:00")
        timestamp = datetime.fromisoformat(normalized)
        if timestamp.tzinfo is None:
            return timestamp.replace(tzinfo=timezone.utc)
        return timestamp.astimezone(timezone.utc)


def main() -> int:
    return SmokeTester(parse_args()).run()


if __name__ == "__main__":
    sys.exit(main())
