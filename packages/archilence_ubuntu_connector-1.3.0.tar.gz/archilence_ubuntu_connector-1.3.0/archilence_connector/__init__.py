"""Archilence Ubuntu Connector — system resource discovery and ArchiMate mapping."""

from importlib.metadata import PackageNotFoundError, version

PACKAGE_NAME = "archilence-ubuntu-connector"


def get_connector_version() -> str:
    """Return the installed connector version, if available."""
    try:
        return version(PACKAGE_NAME)
    except PackageNotFoundError:
        return "0.0.0"


__version__ = get_connector_version()
