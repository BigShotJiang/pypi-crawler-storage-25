"""Main entry point for the Archilence Ubuntu Connector."""

from __future__ import annotations

import logging
import os
import signal
import socket
import sys
import threading

from apscheduler.schedulers.background import BackgroundScheduler

from .collector_manager import CollectorManager
from .config import ConnectorConfig, load_config
from .core_client import CoreClient
from .entity_mapper import EntityMapper
from .sync_engine import SyncEngine
from .tool_server import create_app

logger = logging.getLogger("archilence")


def setup_logging() -> None:
    level = os.environ.get("LOG_LEVEL", "INFO").upper()
    logging.basicConfig(
        level=getattr(logging, level, logging.INFO),
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )


def main() -> None:
    setup_logging()
    logger.info("Archilence Ubuntu Connector starting...")

    # 1. Load configuration
    config_path = os.environ.get("ARCHILENCE_CONFIG")
    try:
        config = load_config(config_path)
    except FileNotFoundError as e:
        logger.error("Configuration error: %s", e)
        sys.exit(1)

    if not config.archilence.endpoint or not config.archilence.api_key:
        logger.error("archilence.endpoint and archilence.api_key are required in config")
        sys.exit(1)

    hostname = config.server.name or socket.gethostname()
    logger.info("Server: %s (env: %s)", hostname, config.server.environment)

    # 2. Initialize components
    collector_manager = CollectorManager(config)
    core_client = CoreClient(config)
    entity_mapper = EntityMapper(hostname=hostname)
    sync_engine = SyncEngine(collector_manager, core_client, entity_mapper)

    # 3. Create tool server (Flask app for callback URL)
    app = create_app(config, collector_manager, sync_engine)
    callback_url = f"http://{hostname}:{config.port}"

    # 4. Register with Core
    registration = core_client.register(callback_url)
    if registration:
        core_client.report_status("active")
        logger.info("Registered with Core successfully")
    else:
        logger.warning("Failed to register with Core — will retry via heartbeat")

    # 5. Set up scheduler
    scheduler = BackgroundScheduler()

    # Heartbeat
    scheduler.add_job(
        sync_engine.heartbeat,
        "interval",
        seconds=config.intervals.heartbeat,
        id="heartbeat",
        name="Heartbeat",
    )

    # Full sync
    scheduler.add_job(
        sync_engine.full_sync,
        "interval",
        seconds=config.intervals.snapshot_full,
        id="full_sync",
        name="Full Sync",
    )

    # Delta sync
    scheduler.add_job(
        sync_engine.delta_sync,
        "interval",
        seconds=config.intervals.snapshot_delta,
        id="delta_sync",
        name="Delta Sync",
    )

    scheduler.start()
    logger.info(
        "Scheduler started — heartbeat: %ds, full sync: %ds, delta sync: %ds",
        config.intervals.heartbeat,
        config.intervals.snapshot_full,
        config.intervals.snapshot_delta,
    )

    # 6. Run initial full sync
    logger.info("Running initial full sync...")
    sync_engine.full_sync()

    # 7. Graceful shutdown handler
    shutdown_event = threading.Event()

    def handle_signal(signum, frame):
        logger.info("Received signal %d, shutting down...", signum)
        scheduler.shutdown(wait=False)
        core_client.report_status("inactive")
        core_client.close()
        shutdown_event.set()

    signal.signal(signal.SIGTERM, handle_signal)
    signal.signal(signal.SIGINT, handle_signal)

    # 8. Start Flask server (blocks until shutdown)
    logger.info("Tool server listening on port %d", config.port)
    app.run(
        host="0.0.0.0",
        port=config.port,
        threaded=True,
        use_reloader=False,
    )


if __name__ == "__main__":
    main()
