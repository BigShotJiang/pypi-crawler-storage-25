"""Maps raw collector output to ArchiMate entities and relations for Core ingestion."""

from __future__ import annotations

import socket
from typing import Any

from .collectors.base import CollectorResult

# ArchiMate type mapping from collector entity types
TYPE_MAP = {
    "Node": "Node",
    "SystemSoftware": "SystemSoftware",
    "ApplicationComponent": "ApplicationComponent",
    "CommunicationNetwork": "CommunicationNetwork",
    "Artifact": "Artifact",
}

# Subtype mapping based on collector entity ID prefix
SUBTYPE_MAP = {
    "host://": "Server",
    "container://": "ContainerRuntime",
    "service://": None,  # No standard subtype for systemd services
    "compose://": None,
    "nic://": None,
    "pkg://": None,
    "file://": None,
    "process://": None,
}

# Relation types based on entity type pairs
RELATION_MAP = {
    ("Node", "SystemSoftware"): "Hosts",
    ("Node", "CommunicationNetwork"): "Composition",
    ("Node", "Artifact"): "Composition",
    ("ApplicationComponent", "SystemSoftware"): "Aggregation",
    ("SystemSoftware", "SystemSoftware"): "Serving",
}


class EntityMapper:
    """Transforms collector results into entities and relations for POST /sync."""

    def __init__(self, hostname: str | None = None) -> None:
        self._hostname = hostname or socket.gethostname()

    @property
    def hostname(self) -> str:
        return self._hostname

    def map_results(
        self, results: dict[str, CollectorResult]
    ) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
        """Map all collector results to (entities, relations) for Core sync.

        Returns:
            Tuple of (entities list for POST /sync, relation payloads).
        """
        all_entities: list[dict[str, Any]] = []
        all_relations: list[dict[str, Any]] = []

        host_external_id = f"ubuntu:{self._hostname}"

        for collector_name, result in results.items():
            if not result.ok:
                continue

            for raw_entity in result.entities:
                if raw_entity.get("_removed"):
                    entity = self._map_deleted_entity(raw_entity, collector_name)
                    if entity:
                        all_entities.append(entity)

                        relation = self._map_host_relation(
                            host_external_id, entity, raw_entity
                        )
                        if relation:
                            relation["deleted"] = True
                            all_relations.append(relation)
                    continue

                entity = self._map_entity(raw_entity, collector_name)
                if entity:
                    all_entities.append(entity)

                    # Generate relation from host to this entity
                    relation = self._map_host_relation(
                        host_external_id, entity, raw_entity
                    )
                    if relation:
                        all_relations.append(relation)

            # Performance metrics get attached to the host entity's data
            if collector_name == "performance" and result.metrics:
                perf_entity = {
                    "externalId": host_external_id,
                    "entityType": "Node",
                    "data": {"metrics": result.metrics},
                }
                all_entities.append(perf_entity)

        # Compose project → container relations
        all_relations.extend(self._map_compose_relations(results))

        return all_entities, all_relations

    def _map_deleted_entity(
        self, raw: dict[str, Any], collector_name: str
    ) -> dict[str, Any] | None:
        """Map a removed collector entity into an empty deletion payload for Core."""
        raw_id = raw.get("id", "")
        raw_type = raw.get("type", "")

        archimate_type = TYPE_MAP.get(raw_type)
        if not archimate_type:
            return None

        local_id = raw_id.split("://", 1)[-1] if "://" in raw_id else raw_id
        external_id = f"ubuntu:{self._hostname}:{collector_name}:{local_id}"

        return {
            "externalId": external_id,
            "entityType": archimate_type,
            "data": {},
        }

    def _map_entity(self, raw: dict[str, Any], collector_name: str) -> dict[str, Any] | None:
        """Map a single collector entity to a Core sync payload."""
        raw_id = raw.get("id", "")
        raw_type = raw.get("type", "")
        properties = raw.get("properties", {})

        archimate_type = TYPE_MAP.get(raw_type)
        if not archimate_type:
            return None

        # Build external ID: ubuntu:{hostname}:{collector}:{local_id}
        local_id = raw_id.split("://", 1)[-1] if "://" in raw_id else raw_id
        external_id = f"ubuntu:{self._hostname}:{collector_name}:{local_id}"

        # Determine subtype
        subtype = None
        for prefix, st in SUBTYPE_MAP.items():
            if raw_id.startswith(prefix):
                subtype = st
                break

        entity: dict[str, Any] = {
            "externalId": external_id,
            "entityType": archimate_type,
            "data": {
                "name": properties.get("name") or properties.get("hostname") or local_id,
                "type": archimate_type,
                **({"subtype": subtype} if subtype else {}),
                "properties": properties,
                "source": "ubuntu-connector",
                "sourceHostname": self._hostname,
            },
        }

        return entity

    def _map_host_relation(
        self,
        host_external_id: str,
        entity: dict[str, Any],
        raw: dict[str, Any],
    ) -> dict[str, Any] | None:
        """Generate a relation from the host node to this entity."""
        entity_type = entity.get("entityType", "")
        # Don't relate host to itself or to performance metrics
        if entity_type == "Node":
            return None

        # Determine relation type
        type_pair = ("Node", entity_type)
        rel_type = RELATION_MAP.get(type_pair, "Hosts")

        return {
            "source": host_external_id,
            "target": entity["externalId"],
            "type": rel_type,
            "is_relation": True,
        }

    def _map_compose_relations(
        self, results: dict[str, CollectorResult]
    ) -> list[dict[str, Any]]:
        """Map relations from compose projects to their containers."""
        relations = []
        docker_result = results.get("docker")
        if not docker_result or not docker_result.ok:
            return relations

        # Find compose project entities and their containers
        compose_entities = {}
        container_entities = {}

        for raw in docker_result.entities:
            raw_id = raw.get("id", "")
            if raw_id.startswith("compose://"):
                project_name = raw_id.split("://", 1)[-1]
                compose_entities[project_name] = raw
            elif raw_id.startswith("container://"):
                container_name = raw_id.split("://", 1)[-1]
                container_entities[container_name] = raw

        for project_name, compose_raw in compose_entities.items():
            containers = compose_raw.get("properties", {}).get("containers", [])
            compose_ext_id = f"ubuntu:{self._hostname}:docker:{project_name}"
            is_deleted = bool(compose_raw.get("_removed"))

            for container_name in containers:
                container_ext_id = f"ubuntu:{self._hostname}:docker:{container_name}"
                relations.append(
                    {
                        "source": compose_ext_id,
                        "target": container_ext_id,
                        "type": "Aggregation",
                        "is_relation": True,
                        **({"deleted": True} if is_deleted else {}),
                    }
                )

        for container_name, container_raw in container_entities.items():
            if not container_raw.get("_removed"):
                continue

            compose_project = container_raw.get("properties", {}).get("compose_project")
            if not compose_project:
                continue

            relations.append(
                {
                    "source": f"ubuntu:{self._hostname}:docker:{compose_project}",
                    "target": f"ubuntu:{self._hostname}:docker:{container_name}",
                    "type": "Aggregation",
                    "is_relation": True,
                    "deleted": True,
                }
            )

        return relations
