"""HTTP client for communicating with Archilence Core."""

from __future__ import annotations

import json
import logging
import sqlite3
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import httpx

from . import get_connector_version
from .config import ConnectorConfig

logger = logging.getLogger("archilence.core_client")

BUFFER_DB_PATH = "/var/lib/archilence/buffer.db"
BUFFER_RETENTION_HOURS = 24


@dataclass
class SyncResult:
    success: bool
    count: int = 0
    sync_run_id: int | None = None
    error: str | None = None


class CoreClient:
    """Communicates with Archilence Core using the connector API."""

    def __init__(self, config: ConnectorConfig) -> None:
        self._config = config
        self._base_url = config.archilence.endpoint.rstrip("/")
        self._client = httpx.Client(
            base_url=self._base_url,
            headers={"X-API-KEY": config.archilence.api_key},
            timeout=30.0,
        )
        self._buffer = OfflineBuffer()

    def register(self, callback_url: str) -> dict[str, Any] | None:
        """Register this connector with Core (POST /register)."""
        payload = {
            "name": f"ubuntu-{self._config.server.name or 'unnamed'}",
            "callbackUrl": callback_url,
            "schedule": f"*/{self._config.intervals.snapshot_full} * * * * *",
            "version": get_connector_version(),
            "capabilities": ["system", "docker", "systemd", "networking", "performance"],
        }
        try:
            resp = self._client.post("/register", json=payload)
            resp.raise_for_status()
            data = resp.json()
            logger.info("Registered with Core: %s", data.get("connector", {}).get("id"))
            return data
        except httpx.HTTPError as e:
            logger.error("Registration failed: %s", e)
            return None

    def heartbeat(self, collector_status: dict[str, str] | None = None) -> bool:
        """Send heartbeat to Core (POST /heartbeat)."""
        payload: dict[str, Any] = {}
        if collector_status:
            payload["collectorStatus"] = collector_status
        try:
            resp = self._client.post("/heartbeat", json=payload)
            resp.raise_for_status()
            return True
        except httpx.HTTPError as e:
            logger.warning("Heartbeat failed: %s", e)
            return False

    def sync_entities(
        self,
        entities: list[dict[str, Any]],
        sync_run_id: int | None = None,
    ) -> SyncResult:
        """Send entities to Core (POST /sync).

        Falls back to SQLite buffer if Core is unreachable.
        """
        payload: dict[str, Any] = {"entities": entities}
        if sync_run_id:
            payload["syncRunId"] = sync_run_id

        try:
            resp = self._client.post("/sync", json=payload)
            resp.raise_for_status()
            data = resp.json()
            return SyncResult(
                success=True,
                count=data.get("count", len(entities)),
                sync_run_id=data.get("syncRunId"),
            )
        except httpx.HTTPError as e:
            logger.warning("Sync failed, buffering %d entities: %s", len(entities), e)
            self._buffer.enqueue(payload)
            return SyncResult(success=False, error=str(e))

    def report_status(self, status: str) -> bool:
        """Report setup status to Core (PATCH /status)."""
        try:
            resp = self._client.patch("/status", json={"setup_status": status})
            resp.raise_for_status()
            return True
        except httpx.HTTPError as e:
            logger.warning("Status report failed: %s", e)
            return False

    def flush_buffer(self) -> int:
        """Flush buffered payloads to Core. Returns count of flushed items."""
        flushed = 0
        for payload in self._buffer.drain():
            try:
                resp = self._client.post("/sync", json=payload)
                resp.raise_for_status()
                flushed += 1
            except httpx.HTTPError:
                self._buffer.enqueue(payload)
                break
        return flushed

    def close(self) -> None:
        self._client.close()


class OfflineBuffer:
    """SQLite-based offline queue for payloads when Core is unreachable."""

    def __init__(self, db_path: str = BUFFER_DB_PATH) -> None:
        self._db_path = db_path
        Path(db_path).parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(db_path)
        self._conn.execute(
            """CREATE TABLE IF NOT EXISTS buffer (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                payload TEXT NOT NULL,
                created_at REAL NOT NULL
            )"""
        )
        self._conn.commit()

    def enqueue(self, payload: dict[str, Any]) -> None:
        self._conn.execute(
            "INSERT INTO buffer (payload, created_at) VALUES (?, ?)",
            (json.dumps(payload), time.time()),
        )
        self._conn.commit()
        self._cleanup()

    def drain(self) -> list[dict[str, Any]]:
        """Return all buffered payloads in order, removing them from the queue."""
        cursor = self._conn.execute("SELECT id, payload FROM buffer ORDER BY id ASC")
        rows = cursor.fetchall()
        if rows:
            ids = [r[0] for r in rows]
            placeholders = ",".join("?" for _ in ids)
            self._conn.execute(f"DELETE FROM buffer WHERE id IN ({placeholders})", ids)
            self._conn.commit()
        return [json.loads(r[1]) for r in rows]

    def _cleanup(self) -> None:
        """Remove entries older than retention period."""
        cutoff = time.time() - (BUFFER_RETENTION_HOURS * 3600)
        self._conn.execute("DELETE FROM buffer WHERE created_at < ?", (cutoff,))
        self._conn.commit()
