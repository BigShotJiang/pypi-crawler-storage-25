"""Systemd collector — service states, unit files, enabled/disabled, restart history."""

from __future__ import annotations

import logging
import subprocess

from .base import BaseCollector, CollectorResult

logger = logging.getLogger("archilence.collectors.systemd")


def _run(cmd: list[str]) -> str:
    """Run a command and return stdout, empty string on failure."""
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
        return result.stdout.strip()
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return ""


class SystemdCollector(BaseCollector):
    name = "systemd"

    def collect(self) -> CollectorResult:
        try:
            entities = []

            # List all service units with their state
            output = _run([
                "systemctl", "list-units", "--type=service", "--all",
                "--no-pager", "--no-legend", "--plain",
            ])

            for line in output.splitlines():
                parts = line.split(None, 4)
                if len(parts) < 4:
                    continue

                unit_name = parts[0]
                load_state = parts[1]  # loaded, not-found, masked
                active_state = parts[2]  # active, inactive, failed, activating, deactivating
                sub_state = parts[3]  # running, exited, dead, failed, waiting

                # Skip template units and non-loaded
                if "@" in unit_name and load_state == "not-found":
                    continue

                # Check if enabled
                enabled_output = _run(["systemctl", "is-enabled", unit_name])
                is_enabled = enabled_output in ("enabled", "enabled-runtime", "static")

                entity = {
                    "id": f"service://{unit_name}",
                    "type": "SystemSoftware",
                    "properties": {
                        "name": unit_name,
                        "load_state": load_state,
                        "active_state": active_state,
                        "sub_state": sub_state,
                        "is_enabled": is_enabled,
                    },
                }
                entities.append(entity)

            # Count by state
            active_count = sum(
                1 for e in entities if e["properties"]["active_state"] == "active"
            )
            failed_count = sum(
                1 for e in entities if e["properties"]["active_state"] == "failed"
            )

            metrics = {
                "services_total": len(entities),
                "services_active": active_count,
                "services_failed": failed_count,
            }

            return CollectorResult(entities=entities, metrics=metrics)
        except Exception as e:
            return CollectorResult(error=str(e))
