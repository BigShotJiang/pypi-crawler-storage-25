"""Abstract base class for all collectors."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any


@dataclass
class CollectorResult:
    """Output from a single collector run."""

    entities: list[dict[str, Any]] = field(default_factory=list)
    metrics: dict[str, Any] = field(default_factory=dict)
    error: str | None = None

    @property
    def ok(self) -> bool:
        return self.error is None


class BaseCollector(ABC):
    """Abstract collector interface. Each collector discovers one domain of system resources."""

    name: str = "base"

    @abstractmethod
    def collect(self) -> CollectorResult:
        """Run full collection and return structured data."""

    def collect_delta(self, previous: CollectorResult) -> CollectorResult:
        """Return only changes since the previous collection.

        Default implementation returns a full collection. Subclasses can
        override for efficient delta tracking.
        """
        current = self.collect()
        if not previous.entities:
            return current

        prev_ids = {e.get("id") for e in previous.entities}
        curr_ids = {e.get("id") for e in current.entities}

        changed: list[dict[str, Any]] = []
        for entity in current.entities:
            eid = entity.get("id")
            if eid not in prev_ids:
                # New entity
                changed.append(entity)
            else:
                # Check if data changed
                prev_entity = next((e for e in previous.entities if e.get("id") == eid), None)
                if prev_entity and prev_entity.get("properties") != entity.get("properties"):
                    changed.append(entity)

        # Mark removed entities
        for entity in previous.entities:
            if entity.get("id") not in curr_ids:
                removed = dict(entity)
                removed["_removed"] = True
                changed.append(removed)

        return CollectorResult(entities=changed, metrics=current.metrics)
