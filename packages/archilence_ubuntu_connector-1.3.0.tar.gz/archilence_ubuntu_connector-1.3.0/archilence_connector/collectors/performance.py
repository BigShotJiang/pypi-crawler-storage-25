"""Performance collector — CPU/memory/disk percentages, load averages, swap."""

from __future__ import annotations

import os

import psutil

from .base import BaseCollector, CollectorResult


class PerformanceCollector(BaseCollector):
    name = "performance"

    def collect(self) -> CollectorResult:
        try:
            cpu_percent = psutil.cpu_percent(interval=1)
            cpu_per_core = psutil.cpu_percent(interval=0, percpu=True)
            mem = psutil.virtual_memory()
            swap = psutil.swap_memory()
            disk = psutil.disk_usage("/")
            load_1, load_5, load_15 = os.getloadavg()

            metrics = {
                "cpu_percent": cpu_percent,
                "cpu_per_core": cpu_per_core,
                "mem_percent": mem.percent,
                "mem_used_gb": round(mem.used / (1024**3), 2),
                "mem_available_gb": round(mem.available / (1024**3), 2),
                "mem_total_gb": round(mem.total / (1024**3), 2),
                "swap_percent": swap.percent,
                "swap_used_gb": round(swap.used / (1024**3), 2),
                "swap_total_gb": round(swap.total / (1024**3), 2),
                "disk_percent": disk.percent,
                "disk_used_gb": round(disk.used / (1024**3), 2),
                "disk_total_gb": round(disk.total / (1024**3), 2),
                "load_1m": round(load_1, 2),
                "load_5m": round(load_5, 2),
                "load_15m": round(load_15, 2),
            }

            return CollectorResult(metrics=metrics)
        except Exception as e:
            return CollectorResult(error=str(e))
