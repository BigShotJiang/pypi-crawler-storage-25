"""Networking collector — interfaces, IPs, listening ports, connections, firewall."""

from __future__ import annotations

import logging
import socket
import subprocess

import psutil

from .base import BaseCollector, CollectorResult

logger = logging.getLogger("archilence.collectors.networking")


class NetworkingCollector(BaseCollector):
    name = "networking"

    def collect(self) -> CollectorResult:
        try:
            entities = []

            # Network interfaces
            addrs = psutil.net_if_addrs()
            stats = psutil.net_if_stats()

            for iface_name, addr_list in addrs.items():
                iface_stat = stats.get(iface_name)
                ips = []
                mac = None
                for addr in addr_list:
                    if addr.family == socket.AF_INET:
                        ips.append({"type": "ipv4", "address": addr.address, "netmask": addr.netmask})
                    elif addr.family == socket.AF_INET6:
                        ips.append({"type": "ipv6", "address": addr.address})
                    elif addr.family == psutil.AF_LINK:
                        mac = addr.address

                entities.append(
                    {
                        "id": f"nic://{iface_name}",
                        "type": "CommunicationNetwork",
                        "properties": {
                            "name": iface_name,
                            "is_up": iface_stat.isup if iface_stat else False,
                            "speed_mbps": iface_stat.speed if iface_stat else 0,
                            "mtu": iface_stat.mtu if iface_stat else 0,
                            "mac_address": mac,
                            "addresses": ips,
                        },
                    }
                )

            # Listening ports
            listening = []
            for conn in psutil.net_connections(kind="inet"):
                if conn.status == "LISTEN":
                    try:
                        proc = psutil.Process(conn.pid) if conn.pid else None
                        proc_name = proc.name() if proc else "unknown"
                    except (psutil.NoSuchProcess, psutil.AccessDenied):
                        proc_name = "unknown"

                    listening.append(
                        {
                            "protocol": "tcp",
                            "address": conn.laddr.ip,
                            "port": conn.laddr.port,
                            "pid": conn.pid,
                            "process": proc_name,
                        }
                    )

            # Firewall rules summary
            firewall_rules = self._get_firewall_summary()

            metrics = {
                "interfaces_total": len(addrs),
                "interfaces_up": sum(
                    1 for s in stats.values() if s.isup
                ),
                "listening_ports": len(listening),
                "listening_ports_detail": listening,
                "firewall_rules": firewall_rules,
            }

            return CollectorResult(entities=entities, metrics=metrics)
        except Exception as e:
            return CollectorResult(error=str(e))

    def _get_firewall_summary(self) -> dict:
        """Get a summary of firewall rules (iptables or nftables)."""
        try:
            result = subprocess.run(
                ["iptables", "-L", "-n", "--line-numbers"],
                capture_output=True, text=True, timeout=5,
            )
            if result.returncode == 0:
                rule_count = sum(
                    1 for line in result.stdout.splitlines()
                    if line and not line.startswith("Chain") and not line.startswith("num")
                )
                return {"type": "iptables", "rule_count": rule_count}
        except (FileNotFoundError, subprocess.TimeoutExpired):
            pass

        try:
            result = subprocess.run(
                ["nft", "list", "ruleset"],
                capture_output=True, text=True, timeout=5,
            )
            if result.returncode == 0:
                rule_count = result.stdout.count("rule ")
                return {"type": "nftables", "rule_count": rule_count}
        except (FileNotFoundError, subprocess.TimeoutExpired):
            pass

        return {"type": "unknown", "rule_count": 0}
