"""Packages collector — installed apt packages with versions (opt-in, slow)."""

from __future__ import annotations

import logging
import subprocess

from .base import BaseCollector, CollectorResult

logger = logging.getLogger("archilence.collectors.packages")


class PackagesCollector(BaseCollector):
    name = "packages"

    def collect(self) -> CollectorResult:
        try:
            result = subprocess.run(
                ["dpkg-query", "-W", "-f=${Package}\t${Version}\t${Status}\n"],
                capture_output=True,
                text=True,
                timeout=30,
            )

            if result.returncode != 0:
                return CollectorResult(error=f"dpkg-query failed: {result.stderr}")

            entities = []
            for line in result.stdout.strip().splitlines():
                parts = line.split("\t")
                if len(parts) < 3:
                    continue
                name, version, status = parts[0], parts[1], parts[2]
                if "install ok installed" not in status:
                    continue
                entities.append(
                    {
                        "id": f"pkg://{name}",
                        "type": "Artifact",
                        "properties": {
                            "name": name,
                            "version": version,
                        },
                    }
                )

            metrics = {"packages_installed": len(entities)}
            return CollectorResult(entities=entities, metrics=metrics)
        except Exception as e:
            return CollectorResult(error=str(e))
