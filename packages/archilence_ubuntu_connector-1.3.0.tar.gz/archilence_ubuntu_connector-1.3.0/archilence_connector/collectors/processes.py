"""Processes collector — top N processes by CPU/memory usage."""

from __future__ import annotations

import psutil

from .base import BaseCollector, CollectorResult

DEFAULT_TOP_N = 20


class ProcessesCollector(BaseCollector):
    name = "processes"

    def __init__(self, top_n: int = DEFAULT_TOP_N) -> None:
        self._top_n = top_n

    def collect(self) -> CollectorResult:
        try:
            procs: list[dict] = []
            for proc in psutil.process_iter(
                ["pid", "name", "username", "cpu_percent", "memory_percent", "cmdline", "ppid"]
            ):
                try:
                    info = proc.info
                    procs.append(
                        {
                            "pid": info["pid"],
                            "name": info["name"],
                            "username": info.get("username", ""),
                            "cpu_percent": info.get("cpu_percent", 0.0) or 0.0,
                            "memory_percent": round(info.get("memory_percent", 0.0) or 0.0, 2),
                            "command": " ".join(info.get("cmdline") or [info.get("name", "")]),
                            "ppid": info.get("ppid"),
                        }
                    )
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue

            # Sort by CPU usage, take top N
            procs.sort(key=lambda p: p["cpu_percent"], reverse=True)
            top_procs = procs[: self._top_n]

            entities = []
            for p in top_procs:
                entities.append(
                    {
                        "id": f"process://{p['pid']}",
                        "type": "SystemSoftware",
                        "properties": p,
                    }
                )

            metrics = {
                "total_processes": len(procs),
                "top_cpu_process": top_procs[0]["name"] if top_procs else None,
            }

            return CollectorResult(entities=entities, metrics=metrics)
        except Exception as e:
            return CollectorResult(error=str(e))
