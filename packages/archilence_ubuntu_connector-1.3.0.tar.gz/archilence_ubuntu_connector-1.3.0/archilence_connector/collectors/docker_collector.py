"""Docker collector — containers, images, networks, volumes, compose projects."""

from __future__ import annotations

import logging
from typing import Any

from .base import BaseCollector, CollectorResult

logger = logging.getLogger("archilence.collectors.docker")

# Environment variable keys that may contain secrets
FILTERED_ENV_PREFIXES = (
    "PASSWORD", "SECRET", "TOKEN", "KEY", "CREDENTIAL", "AUTH",
    "AWS_SECRET", "DATABASE_URL", "API_KEY",
)


def _filter_env(env_list: list[str] | None) -> list[str]:
    """Remove environment variables that may contain secrets."""
    if not env_list:
        return []
    filtered = []
    for entry in env_list:
        key = entry.split("=", 1)[0].upper()
        if any(prefix in key for prefix in FILTERED_ENV_PREFIXES):
            filtered.append(f"{entry.split('=', 1)[0]}=***FILTERED***")
        else:
            filtered.append(entry)
    return filtered


class DockerCollector(BaseCollector):
    name = "docker"

    def collect(self) -> CollectorResult:
        try:
            import docker

            client = docker.from_env()
        except Exception as e:
            logger.info("Docker not available: %s", e)
            return CollectorResult(error=f"Docker not available: {e}")

        try:
            entities: list[dict[str, Any]] = []
            compose_projects: dict[str, list[str]] = {}

            # Containers
            for container in client.containers.list(all=True):
                labels = container.labels or {}
                compose_project = labels.get("com.docker.compose.project")
                compose_service = labels.get("com.docker.compose.service")

                ports_config = container.attrs.get("NetworkSettings", {}).get("Ports") or {}
                port_bindings = []
                for container_port, host_bindings in ports_config.items():
                    if host_bindings:
                        for binding in host_bindings:
                            port_bindings.append(
                                f"{binding.get('HostPort', '')}:{container_port}"
                            )
                    else:
                        port_bindings.append(container_port)

                entity = {
                    "id": f"container://{container.name}",
                    "type": "SystemSoftware",
                    "properties": {
                        "name": container.name,
                        "short_id": container.short_id,
                        "status": container.status,
                        "image": ",".join(container.image.tags) if container.image.tags else str(container.image.id)[:19],
                        "ports": port_bindings,
                        "environment": _filter_env(
                            container.attrs.get("Config", {}).get("Env")
                        ),
                        "compose_project": compose_project,
                        "compose_service": compose_service,
                        "restart_policy": container.attrs.get("HostConfig", {}).get(
                            "RestartPolicy", {}
                        ).get("Name", "no"),
                        "created": container.attrs.get("Created", ""),
                    },
                }
                entities.append(entity)

                if compose_project:
                    compose_projects.setdefault(compose_project, []).append(container.name)

            # Compose projects as ApplicationComponent entities
            for project_name, containers in compose_projects.items():
                entities.append(
                    {
                        "id": f"compose://{project_name}",
                        "type": "ApplicationComponent",
                        "properties": {
                            "name": project_name,
                            "containers": containers,
                            "container_count": len(containers),
                        },
                    }
                )

            # Summary metrics
            all_containers = client.containers.list(all=True)
            running = sum(1 for c in all_containers if c.status == "running")
            stopped = len(all_containers) - running

            metrics = {
                "containers_total": len(all_containers),
                "containers_running": running,
                "containers_stopped": stopped,
                "compose_projects": len(compose_projects),
                "images_total": len(client.images.list()),
                "volumes_total": len(client.volumes.list()),
                "networks_total": len(client.networks.list()),
            }

            client.close()
            return CollectorResult(entities=entities, metrics=metrics)
        except Exception as e:
            return CollectorResult(error=str(e))
