"""Files collector — user-defined path monitoring: size, mtime, checksum (opt-in)."""

from __future__ import annotations

import hashlib
import logging
import os
from pathlib import Path

from .base import BaseCollector, CollectorResult

logger = logging.getLogger("archilence.collectors.files")

MAX_CHECKSUM_SIZE = 100 * 1024 * 1024  # 100MB limit for checksumming


class FilesCollector(BaseCollector):
    name = "files"

    def __init__(self, paths: list[str] | None = None) -> None:
        self._paths = paths or []

    def collect(self) -> CollectorResult:
        try:
            entities = []

            for path_str in self._paths:
                p = Path(path_str)
                if not p.exists():
                    logger.warning("Watched path does not exist: %s", path_str)
                    continue

                if p.is_file():
                    entities.append(self._file_entity(p))
                elif p.is_dir():
                    entities.append(self._dir_entity(p))

            metrics = {"watched_paths": len(self._paths), "found_entities": len(entities)}
            return CollectorResult(entities=entities, metrics=metrics)
        except Exception as e:
            return CollectorResult(error=str(e))

    def _file_entity(self, p: Path) -> dict:
        stat = p.stat()
        checksum = None
        if stat.st_size <= MAX_CHECKSUM_SIZE:
            checksum = hashlib.sha256(p.read_bytes()).hexdigest()

        return {
            "id": f"file://{p.resolve()}",
            "type": "Artifact",
            "properties": {
                "path": str(p.resolve()),
                "name": p.name,
                "size_bytes": stat.st_size,
                "mtime": stat.st_mtime,
                "checksum_sha256": checksum,
                "is_directory": False,
            },
        }

    def _dir_entity(self, p: Path) -> dict:
        total_size = 0
        file_count = 0
        try:
            for root, _dirs, files in os.walk(p):
                for f in files:
                    fp = os.path.join(root, f)
                    try:
                        total_size += os.path.getsize(fp)
                        file_count += 1
                    except OSError:
                        pass
        except OSError:
            pass

        return {
            "id": f"file://{p.resolve()}",
            "type": "Artifact",
            "properties": {
                "path": str(p.resolve()),
                "name": p.name,
                "size_bytes": total_size,
                "file_count": file_count,
                "is_directory": True,
            },
        }
