"""Collector modules for Ubuntu system resource discovery."""

from .base import BaseCollector, CollectorResult
from .docker_collector import DockerCollector
from .files import FilesCollector
from .networking import NetworkingCollector
from .packages import PackagesCollector
from .performance import PerformanceCollector
from .processes import ProcessesCollector
from .system import SystemCollector
from .systemd import SystemdCollector

ALL_COLLECTORS: dict[str, type[BaseCollector]] = {
    "system": SystemCollector,
    "performance": PerformanceCollector,
    "processes": ProcessesCollector,
    "docker": DockerCollector,
    "systemd": SystemdCollector,
    "networking": NetworkingCollector,
    "packages": PackagesCollector,
    "files": FilesCollector,
}

__all__ = [
    "ALL_COLLECTORS",
    "BaseCollector",
    "CollectorResult",
    "DockerCollector",
    "FilesCollector",
    "NetworkingCollector",
    "PackagesCollector",
    "PerformanceCollector",
    "ProcessesCollector",
    "SystemCollector",
    "SystemdCollector",
]
