"""System collector — hostname, OS version, kernel, CPU, RAM, uptime."""

from __future__ import annotations

import platform
import socket
import time
from datetime import datetime, timezone

import psutil

from .base import BaseCollector, CollectorResult


class SystemCollector(BaseCollector):
    name = "system"

    def collect(self) -> CollectorResult:
        try:
            hostname = socket.gethostname()
            uname = platform.uname()
            boot_time = psutil.boot_time()
            uptime_seconds = int(time.time() - boot_time)
            cpu_count = psutil.cpu_count(logical=True)
            cpu_count_physical = psutil.cpu_count(logical=False)
            ram = psutil.virtual_memory()

            entity = {
                "id": f"host://{hostname}",
                "type": "Node",
                "properties": {
                    "hostname": hostname,
                    "os": f"{uname.system} {uname.release}",
                    "os_version": platform.version(),
                    "kernel": uname.release,
                    "architecture": uname.machine,
                    "cpu_model": platform.processor() or uname.processor,
                    "cpu_cores_logical": cpu_count,
                    "cpu_cores_physical": cpu_count_physical,
                    "ram_gb": round(ram.total / (1024**3), 1),
                    "uptime_seconds": uptime_seconds,
                    "boot_time": datetime.fromtimestamp(boot_time, tz=timezone.utc).isoformat(),
                    "timezone": time.tzname[0],
                    "python_version": platform.python_version(),
                },
            }

            return CollectorResult(entities=[entity])
        except Exception as e:
            return CollectorResult(error=str(e))
