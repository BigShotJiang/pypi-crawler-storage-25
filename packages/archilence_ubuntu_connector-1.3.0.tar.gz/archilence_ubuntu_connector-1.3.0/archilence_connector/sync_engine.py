"""Sync engine — orchestrates full/delta sync cycles and scheduling."""

from __future__ import annotations

from datetime import datetime, timezone
import logging
from typing import Any

from .collector_manager import CollectorManager
from .core_client import CoreClient
from .entity_mapper import EntityMapper

logger = logging.getLogger("archilence.sync_engine")


class SyncEngine:
    """Orchestrates collection, mapping, and syncing to Core."""

    def __init__(
        self,
        collector_manager: CollectorManager,
        core_client: CoreClient,
        entity_mapper: EntityMapper,
    ) -> None:
        self._collectors = collector_manager
        self._core = core_client
        self._mapper = entity_mapper
        self._sync_count = 0

    def full_sync(self) -> dict[str, Any]:
        """Run a full snapshot sync: collect all → map → send to Core."""
        self._sync_count += 1
        logger.info("Starting full sync #%d", self._sync_count)

        results = self._collectors.collect_all()
        entities, relations = self._mapper.map_results(results)

        entity_result = self._core.sync_entities(entities)

        # Send relations as separate sync (they use the is_relation flag in payload)
        if relations:
            relation_payloads = [
                {"externalId": r["source"], "entityType": "relation", "data": r}
                for r in relations
            ]
            self._core.sync_entities(relation_payloads)

        # Attempt to flush any buffered payloads
        flushed = self._core.flush_buffer()
        if flushed:
            logger.info("Flushed %d buffered payloads", flushed)

        logger.info(
            "Full sync #%d complete: %d entities, %d relations, success=%s",
            self._sync_count,
            len(entities),
            len(relations),
            entity_result.success,
        )

        return {
            "sync_number": self._sync_count,
            "entities_count": len(entities),
            "relations_count": len(relations),
            "success": entity_result.success,
            "collector_health": self._collectors.get_health(),
        }

    def analysis_snapshot(self) -> dict[str, Any]:
        """Build a read-only full analysis snapshot without syncing to Core."""
        results = self._collectors.collect_all()
        entities, relations = self._mapper.map_results(results)

        raw_collectors: dict[str, Any] = {}
        raw_entities = 0
        for name, result in results.items():
            result_entities = list(getattr(result, "entities", []))
            result_metrics = dict(getattr(result, "metrics", {}))
            result_error = getattr(result, "error", None)
            result_ok = getattr(result, "ok", result_error is None)
            raw_collectors[name] = {
                "ok": result_ok,
                "entities": result_entities,
                "metrics": result_metrics,
                "error": result_error,
            }
            raw_entities += len(result_entities)

        return {
            "timestamp": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
            "hostname": self._mapper.hostname,
            "collector_health": self._collectors.get_health(),
            "summary": {
                "raw_collectors": len(raw_collectors),
                "raw_entities": raw_entities,
                "mapped_entities": len(entities),
                "mapped_relations": len(relations),
            },
            "raw": {"collectors": raw_collectors},
            "mapped": {
                "entities": entities,
                "relations": relations,
            },
        }

    def delta_sync(self) -> dict[str, Any]:
        """Run a delta sync: collect changes only → map → send to Core."""
        logger.debug("Starting delta sync")

        results = self._collectors.collect_delta()
        entities, relations = self._mapper.map_results(results)

        if not entities and not relations:
            logger.debug("Delta sync: no changes detected")
            return {"entities_count": 0, "relations_count": 0, "success": True}

        entity_result = self._core.sync_entities(entities)

        if relations:
            relation_payloads = [
                {"externalId": r["source"], "entityType": "relation", "data": r}
                for r in relations
            ]
            self._core.sync_entities(relation_payloads)

        logger.info(
            "Delta sync: %d entities, %d relations, success=%s",
            len(entities),
            len(relations),
            entity_result.success,
        )

        return {
            "entities_count": len(entities),
            "relations_count": len(relations),
            "success": entity_result.success,
        }

    def heartbeat(self) -> bool:
        """Send heartbeat with collector health status."""
        health = self._collectors.get_health()
        return self._core.heartbeat(collector_status=health)
