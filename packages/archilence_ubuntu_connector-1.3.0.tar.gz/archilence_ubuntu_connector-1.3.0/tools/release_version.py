"""Backwards-compatible shim — delegates to tools/release_version.py.

The ubuntu-connector predates the generic versioning tool. Its CI job
still invokes this path; the shim preserves CLI compatibility while
eliminating duplicated logic.
"""
from __future__ import annotations

import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(REPO_ROOT))

from tools.release_version import main  # noqa: E402


def _build_argv() -> list[str]:
    argv = ["--app", "ubuntu-connector", "--default-version", "1.0.0"]
    # Pass through --default-version from callers. Silently consume
    # --fallback-ref-range and --repo-root (accepted by the legacy CLI
    # but no longer required).
    forwarded: list[str] = []
    it = iter(sys.argv[1:])
    for arg in it:
        if arg == "--default-version":
            forwarded.extend([arg, next(it)])
        elif arg.startswith("--default-version="):
            forwarded.append(arg)
        elif arg in {"--fallback-ref-range", "--repo-root"}:
            next(it, None)
        elif arg.startswith("--fallback-ref-range=") or arg.startswith("--repo-root="):
            continue
    if forwarded:
        argv = ["--app", "ubuntu-connector", *forwarded]
    return argv


if __name__ == "__main__":
    sys.argv = [sys.argv[0], *_build_argv()]
    raise SystemExit(main())
