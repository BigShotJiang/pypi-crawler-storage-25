"""
### Tribulnation Bitmex
> An SDK to connect Bitmex with the Tribulnation ecosystem.

- Details
"""