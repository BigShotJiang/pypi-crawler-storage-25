# Tribulnation Bitmex SDK

> An SDK to connect Bitmex with the Tribulnation ecosystem.

🚧 Under construction.