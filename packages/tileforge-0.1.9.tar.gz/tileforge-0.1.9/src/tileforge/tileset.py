from typing import Callable

import pygame


class Tileset:
    def __init__(self, path: str, tile_size: int):
        self.__path = path
        self.__tile_size = tile_size
        self.tiles: list[pygame.Surface] = []
        self.__tile_properties: dict[int, set[int]] = {}
        self.__listeners: list[Callable] = []

    @property
    def tile_size(self) -> int:
        return self.__tile_size

    @property
    def path(self) -> str:
        return self.__path

    @property
    def all_properties(self) -> dict[int, set[int]]:
        return self.__tile_properties

    def subscribe(self, callback: Callable):
        self.__listeners.append(callback)

    def __load_tileset(self):
        image = pygame.image.load(self.__path).convert_alpha()
        tiles = []
        w, h = image.get_size()

        for y in range(0, h - self.__tile_size + 1, self.__tile_size):
            for x in range(0, w - self.__tile_size + 1, self.__tile_size):
                tile = image.subsurface((x, y, self.__tile_size, self.__tile_size))
                tiles.append(tile)

        empty_tile = pygame.Surface((self.__tile_size, self.__tile_size), pygame.SRCALPHA)
        tiles.insert(0, empty_tile)

        return tiles

    def unsubscribe(self, callback: Callable):
        self.__listeners.remove(callback)

    def __notify_listeners(self):
        for callback in self.__listeners:
            try:
                callback()
            except Exception as e:
                print(f"Error in listener callback: {e}")

    def load(self):
        self.tiles = self.__load_tileset()
        self.__notify_listeners()

    def get_scaled_tiles(self, scale: int) -> list[pygame.Surface]:
        return [pygame.transform.scale(tile, (self.__tile_size * scale, self.__tile_size * scale)) for tile in
                self.tiles]

    def has_property(self, tile_index: int, property_id: int) -> bool:
        return tile_index in self.__tile_properties.get(property_id, set())

    def serialize_properties(self):
        return {str(index): list(props) for index, props in self.__tile_properties.items()}

    def deserialize_properties(self, properties: dict[str, list[int]]):
        self.__tile_properties = {int(index): set(props) for index, props in properties.items()}

    def set_properties(self, properties: dict[int, set[int]]):
        self.__tile_properties = properties

    def add_property_set(self, property_id: int, tile_indices: set[int]):
        self.__tile_properties[property_id] = tile_indices

    def set_property(self, tile_index: int, property_id: int):
        if property_id not in self.__tile_properties:
            self.__tile_properties[property_id] = set()
        self.__tile_properties[property_id].add(tile_index)

    def remove_property(self, tile_index: int, property_id: int):
        if property_id in self.__tile_properties:
            self.__tile_properties[property_id].discard(tile_index)
            if not self.__tile_properties[property_id]:
                del self.__tile_properties[property_id]

    def toggle_property(self, tile_index: int, property_id: int):
        if property_id not in self.__tile_properties:
            self.__tile_properties[property_id] = set()
        if tile_index in self.__tile_properties[property_id]:
            self.__tile_properties[property_id].remove(tile_index)
            if not self.__tile_properties[property_id]:
                del self.__tile_properties[property_id]
        else:
            self.__tile_properties[property_id].add(tile_index)

    def get_properties(self, property_id: int) -> set[int]:
        return self.__tile_properties.get(property_id, set())

    def set_tile_size(self, new_size: int):
        self.__tile_size = new_size
        self.load()

    def set_path(self, new_path: str):
        self.__path = new_path
        self.load()
