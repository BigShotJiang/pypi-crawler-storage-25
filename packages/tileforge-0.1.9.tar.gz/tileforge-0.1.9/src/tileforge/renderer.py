from .lib import DrawCallback
from .tileset import Tileset
from .map import Map
import pygame
from pygame import Surface


class Renderer:
    def __init__(self, tileset: Tileset, map_layout: Map, render_scale: int = 1):
        self.__render_scale = render_scale
        self.__tileset = tileset
        self.__tileset.subscribe(self.__tiles_got_updated)
        self.__tiles = self.__tileset.get_scaled_tiles(render_scale)
        self.__map = map_layout
        self.__rotated_tiles: dict[tuple[int, int], Surface] = {}

    def set_render_scale(self, new_scale: int):
        self.__render_scale = new_scale
        self.__tiles = self.__tileset.get_scaled_tiles(new_scale)
        self.__rotated_tiles = {}

    @property
    def tiles(self) -> list[Surface]:
        return self.__tiles

    @property
    def render_tile_size(self) -> int:
        return self.__tileset.tile_size * self.__render_scale

    @property
    def scale(self) -> int:
        return self.__render_scale

    @property
    def layout(self) -> Map:
        return self.__map

    @property
    def tileset(self) -> Tileset:
        return self.__tileset

    def __tiles_got_updated(self):
        self.__tiles = self.__tileset.get_scaled_tiles(self.__render_scale)

    def __get_tile(self, index: int, rotation: int) -> Surface:
        rotation = rotation % 4
        key = (index, rotation)

        if key not in self.__rotated_tiles:
            self.__rotated_tiles[key] = pygame.transform.rotate(
                self.__tiles[index],
                -90 * rotation,
            )

        return self.__rotated_tiles[key]

    def render(self, surface: Surface, offset: tuple[int, int] = (0, 0), callback: DrawCallback | None = None) -> None:
        offset_x, offset_y = offset
        for y in range(self.__map.height):
            for x in range(self.__map.width):
                draw_x = x * self.render_tile_size + offset_x
                draw_y = y * self.render_tile_size + offset_y

                for layer in self.__map.layers:
                    if y >= len(layer) or x >= len(layer[y]):
                        continue
                    index, rotation = layer[y][x]
                    if index >= len(self.__tiles):
                        continue
                    tile = self.__get_tile(index, rotation)
                    surface.blit(tile, (draw_x, draw_y))

                if callback:
                    try:
                        callback(x, y, draw_x, draw_y)
                    except Exception as e:
                        print(f"Error in callback for tile ({x}, {y}): {e}")

    def cell_has_property(self, pos: tuple[int, int], property_id: int | list[int]) -> bool:
        """Check if any tile in the cell at (x, y) across all layers has the specified property."""
        if isinstance(property_id, list):
            return any(self.__map.cell_has_property(self.__tileset, pos, pid) for pid in property_id)

        return self.__map.cell_has_property(self.__tileset, pos, property_id)
