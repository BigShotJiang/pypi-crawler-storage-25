"""
DBSKiter MCP Server

A Model Context Protocol server that exposes DBSKiter database skills as AI tools.

Usage:
    >>> from dbskiter_mcp import DBSKiterMCPServer
    >>> server = DBSKiterMCPServer()
    >>> server.run()

Version: 1.1.0
Author: MagiCzc
"""

from .server import DBSKiterMCPServer
from .tools import ToolRegistry

__version__ = "1.2.0"
__all__ = ["DBSKiterMCPServer", "ToolRegistry"]
