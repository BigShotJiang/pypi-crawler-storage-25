"""
DBSKiter MCP Server

Main server implementation that exposes DBSKiter database skills through
the Model Context Protocol. This server can be used with Claude Desktop,
Cursor, or any other MCP-compatible client.

Usage:
    # Run the server
    $ dbskiter-mcp
    
    # Or programmatically
    >>> from dbskiter_mcp import DBSKiterMCPServer
    >>> server = DBSKiterMCPServer()
    >>> server.run()

Version: 1.2.0
Author: MagiCzc
"""

import asyncio
import logging
import sys
from typing import Optional
from contextlib import asynccontextmanager
from collections.abc import AsyncIterator

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent, ImageContent, EmbeddedResource

from .tools import create_tool_registry, ToolRegistry, ParameterType

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def app_lifespan(server: Server) -> AsyncIterator[ToolRegistry]:
    """
    Manage application lifecycle.
    
    This context manager handles startup and shutdown of the MCP server,
    including initialization of the tool registry.
    
    Args:
        server: MCP server instance
        
    Yields:
        ToolRegistry: Initialized tool registry
    """
    logger.info("DBSKiter MCP Server starting up")
    
    # Initialize tool registry
    registry = create_tool_registry()
    logger.info(f"Loaded {len(registry.list_tools())} tools")
    
    try:
        yield registry
    finally:
        logger.info("DBSKiter MCP Server shutting down")


class DBSKiterMCPServer:
    """
    MCP Server for DBSKiter database tools.
    
    This server exposes DBSKiter's database monitoring, diagnosis,
    SQL processing, and security auditing capabilities through the
    Model Context Protocol.
    
    Attributes:
        server: Underlying MCP server instance
        registry: Tool registry containing all available tools
        
    Example:
        >>> server = DBSKiterMCPServer()
        >>> server.run()
    """
    
    def __init__(self, name: str = "dbskiter"):
        """
        Initialize the MCP server.
        
        Args:
            name: Server name identifier
        """
        self.server = Server(name, lifespan=app_lifespan)
        self._setup_handlers()
        logger.info(f"DBSKiterMCPServer initialized (name: {name})")
    
    def _setup_handlers(self) -> None:
        """Set up MCP protocol handlers."""
        
        @self.server.list_tools()
        async def list_tools() -> list[Tool]:
            """
            List all available tools.
            
            Returns:
                List of tool definitions
            """
            registry = self.server.request_context.lifespan_context
            tools = registry.list_tools()
            
            # Convert internal Tool to MCP Tool
            return [
                Tool(
                    name=tool.name,
                    description=tool.description,
                    inputSchema={
                        "type": "object",
                        "properties": {
                            p.name: {
                                "type": p.type.value,
                                "description": p.description,
                                **({"enum": p.enum} if p.enum else {}),
                            }
                            for p in tool.parameters
                        },
                        "required": [
                            p.name for p in tool.parameters if p.required
                        ],
                    },
                )
                for tool in tools
            ]
        
        @self.server.call_tool()
        async def call_tool(name: str, arguments: dict) -> list:
            """
            Execute a tool with the given arguments.
            
            Args:
                name: Tool name
                arguments: Tool arguments
                
            Returns:
                List of content items (TextContent, ImageContent, etc.)
            """
            registry = self.server.request_context.lifespan_context
            
            logger.info(f"Executing tool: {name}")
            
            result = await registry.execute(name, arguments)
            
            if result.get("success"):
                data = result.get("data", {})
                
                # Format successful result as JSON
                import json
                content = json.dumps(data, indent=2, ensure_ascii=False, default=str)
                
                return [TextContent(type="text", text=content)]
            else:
                # Return error message
                error_msg = result.get("error", "Unknown error")
                return [TextContent(type="text", text=f"Error: {error_msg}")]
    
    async def run_async(self) -> None:
        """
        Run the server asynchronously.
        
        This method starts the MCP server and listens for client connections
        via standard input/output (stdio).
        """
        logger.info("Starting DBSKiter MCP Server")
        
        async with stdio_server() as (read_stream, write_stream):
            await self.server.run(
                read_stream,
                write_stream,
                self.server.create_initialization_options()
            )
    
    def run(self) -> None:
        """
        Run the server (blocking).
        
        This is the main entry point for running the MCP server.
        """
        try:
            asyncio.run(self.run_async())
        except KeyboardInterrupt:
            logger.info("Server stopped by user")
        except Exception as e:
            logger.exception("Server error")
            sys.exit(1)


def main() -> None:
    """
    Main entry point for the MCP server.
    
    This function is called when running `dbskiter-mcp` from the command line.
    """
    server = DBSKiterMCPServer()
    server.run()


if __name__ == "__main__":
    main()
