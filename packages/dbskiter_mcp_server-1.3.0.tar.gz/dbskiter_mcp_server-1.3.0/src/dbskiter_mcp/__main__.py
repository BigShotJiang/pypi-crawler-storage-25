"""
Entry point for running dbskiter-mcp as a module.

Usage:
    python -m dbskiter_mcp
    python -m dbskiter_mcp.server
"""

from .server import main

if __name__ == "__main__":
    main()
