"""
MCP Tools for DBSKiter

This module defines and registers all MCP tools that expose DBSKiter functionality
to AI assistants through the Model Context Protocol.

Tools are organized by category:
- Diagnose: Database diagnosis and performance analysis
- Monitor: Health checks and metrics collection
- SQL: SQL execution and optimization
- Security: Security auditing and scanning
- Inspector: Intelligent database inspection and analysis
- Lock: Lock analysis and deadlock detection
- Scheduler: Backup, scheduling, and task management
- Auditor: SQL audit and quality analysis

Version: 1.2.0
Author: MagiCzc
"""

import logging
from typing import Dict, Any, List, Optional, Callable, Awaitable
from dataclasses import dataclass, field
from enum import Enum

from dbskiter.shared.unified_connector import UnifiedConnector
from dbskiter.cli.config import Config
from dbskiter.db_diagnose.skill import DiagnoseSkill
from dbskiter.db_monitor.skill import MonitorSkill
from dbskiter.sql_master.skill import SQLMasterSkill
from dbskiter.db_security.skill import SecuritySkill
from dbskiter.db_inspector.skill import InspectorSkill
from dbskiter.db_lock_analyzer.skill import LockAnalyzerSkill
from dbskiter.db_scheduler.skill import SchedulerSkill
from dbskiter.db_sql_auditor.skill import SQLAuditorSkill

logger = logging.getLogger(__name__)


def get_connector_for_database(database: str) -> UnifiedConnector:
    """
    Get a database connector for the specified database configuration.
    
    Args:
        database: Database identifier (e.g., "jump", "chenzc", "orcl", "dify")
                     Maps to environment variables DB_JUMP_*, DB_CHENZC_*, etc.
    
    Returns:
        UnifiedConnector configured for the specified database
    """
    prefix = database.upper()
    config = Config.from_env(prefix=prefix)
    
    connector = UnifiedConnector(
        dialect=config.dialect,
        host=config.host,
        port=config.port,
        username=config.username,
        password=config.password,
        database=config.database,
        **config.extra
    )
    
    return connector


class ParameterType(Enum):
    """Parameter type enumeration for MCP tool definitions."""
    STRING = "string"
    INTEGER = "integer"
    NUMBER = "number"
    BOOLEAN = "boolean"
    ARRAY = "array"
    OBJECT = "object"


@dataclass
class ToolParameter:
    """
    Defines a parameter for an MCP tool.
    
    Attributes:
        name: Parameter name
        type: Parameter data type
        description: Human-readable description
        required: Whether the parameter is required
        default: Default value if not provided
        enum: List of allowed values (optional)
    """
    name: str
    type: ParameterType
    description: str
    required: bool = False
    default: Any = None
    enum: Optional[List[Any]] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert parameter definition to dictionary format."""
        result = {
            "type": self.type.value,
            "description": self.description,
        }
        if self.required:
            result["required"] = True
        if self.default is not None:
            result["default"] = self.default
        if self.enum:
            result["enum"] = self.enum
        return result


@dataclass
class Tool:
    """
    Defines an MCP tool.
    
    Attributes:
        name: Unique tool name
        description: Human-readable description of what the tool does
        parameters: List of tool parameters
        handler: Async function that handles tool execution
    """
    name: str
    description: str
    parameters: List[ToolParameter] = field(default_factory=list)
    handler: Optional[Callable[[Dict[str, Any]], Awaitable[Dict[str, Any]]]] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert tool definition to dictionary format."""
        return {
            "name": self.name,
            "description": self.description,
            "parameters": {
                p.name: p.to_dict() for p in self.parameters
            },
        }
    
    def validate_params(self, params: Dict[str, Any]) -> tuple[bool, Optional[str]]:
        """
        Validate provided parameters against tool definition.
        
        Args:
            params: Dictionary of parameter names to values
            
        Returns:
            Tuple of (is_valid, error_message)
        """
        for param in self.parameters:
            if param.required and param.name not in params:
                return False, f"Missing required parameter: {param.name}"
            
            if param.name in params:
                value = params[param.name]
                
                # Type validation
                if param.type == ParameterType.STRING and not isinstance(value, str):
                    return False, f"Parameter '{param.name}' must be a string"
                elif param.type == ParameterType.INTEGER and not isinstance(value, int):
                    return False, f"Parameter '{param.name}' must be an integer"
                elif param.type == ParameterType.NUMBER and not isinstance(value, (int, float)):
                    return False, f"Parameter '{param.name}' must be a number"
                elif param.type == ParameterType.BOOLEAN and not isinstance(value, bool):
                    return False, f"Parameter '{param.name}' must be a boolean"
                
                # Enum validation
                if param.enum and value not in param.enum:
                    return False, f"Parameter '{param.name}' must be one of: {param.enum}"
        
        return True, None


class ToolRegistry:
    """
    Registry for managing MCP tools.
    
    Provides centralized registration, discovery, and execution of tools.
    Tools are organized by category for better organization.
    
    Example:
        >>> registry = ToolRegistry()
        >>> registry.register_tool(my_tool, category="diagnose")
        >>> result = await registry.execute("my_tool", {"param": "value"})
    """
    
    def __init__(self):
        """Initialize the tool registry."""
        self._tools: Dict[str, Tool] = {}
        self._categories: Dict[str, List[str]] = {}
        logger.info("ToolRegistry initialized")
    
    def register_tool(self, tool: Tool, category: str = "general") -> None:
        """
        Register a tool in the registry.
        
        Args:
            tool: Tool definition to register
            category: Category for organizing tools
            
        Raises:
            ValueError: If tool name already exists
        """
        if tool.name in self._tools:
            raise ValueError(f"Tool '{tool.name}' already exists")
        
        self._tools[tool.name] = tool
        
        if category not in self._categories:
            self._categories[category] = []
        self._categories[category].append(tool.name)
        
        logger.debug(f"Registered tool: {tool.name} (category: {category})")
    
    def get_tool(self, name: str) -> Optional[Tool]:
        """
        Get a tool by name.
        
        Args:
            name: Tool name
            
        Returns:
            Tool definition or None if not found
        """
        return self._tools.get(name)
    
    def list_tools(self, category: Optional[str] = None) -> List[Tool]:
        """
        List all registered tools.
        
        Args:
            category: Filter by category, None returns all
            
        Returns:
            List of tool definitions
        """
        if category:
            tool_names = self._categories.get(category, [])
            return [self._tools[name] for name in tool_names if name in self._tools]
        return list(self._tools.values())
    
    def list_categories(self) -> List[str]:
        """List all registered categories."""
        return list(self._categories.keys())
    
    async def execute(self, name: str, params: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute a tool with the given parameters.
        
        Args:
            name: Tool name
            params: Tool parameters
            
        Returns:
            Tool execution result
        """
        tool = self.get_tool(name)
        if not tool:
            return {"success": False, "error": f"Tool '{name}' not found"}
        
        # Validate parameters
        valid, error = tool.validate_params(params)
        if not valid:
            return {"success": False, "error": error}
        
        # Check handler
        if not tool.handler:
            return {"success": False, "error": f"Tool '{name}' has no handler"}
        
        try:
            result = await tool.handler(params)
            return {"success": True, "data": result}
        except Exception as e:
            logger.exception(f"Tool execution failed: {name}")
            return {"success": False, "error": f"Execution failed: {str(e)}"}


def create_database_param(required: bool = True) -> ToolParameter:
    """Create a standard database parameter definition."""
    return ToolParameter(
        name="database",
        type=ParameterType.STRING,
        description="Database connection identifier or name",
        required=required,
    )


def create_limit_param(default: int = 10) -> ToolParameter:
    """Create a standard limit parameter definition."""
    return ToolParameter(
        name="limit",
        type=ParameterType.INTEGER,
        description="Maximum number of results to return",
        required=False,
        default=default,
    )


# ============================================================================
# Diagnose Tools
# ============================================================================

async def handle_diagnose_realtime(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle real-time database diagnosis."""
    database = params["database"]
    threshold = params.get("threshold", 5)
    
    connector = get_connector_for_database(database)
    skill = DiagnoseSkill(connector)
    
    result = skill.realtime_diagnose(threshold=threshold)
    skill.close()
    return result


async def handle_diagnose_sql(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle SQL statement diagnosis."""
    database = params["database"]
    sql = params["sql"]
    sql_params = params.get("params")
    
    connector = get_connector_for_database(database)
    skill = DiagnoseSkill(connector)
    
    result = skill.analyze_sql(sql, sql_params)
    skill.close()
    return result


async def handle_diagnose_slow_queries(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle slow query analysis."""
    database = params["database"]
    limit = params.get("limit", 10)
    min_time = params.get("min_time", 1.0)
    
    connector = get_connector_for_database(database)
    skill = DiagnoseSkill(connector)
    
    result = skill.analyze_slow_queries(limit=limit, min_time=min_time)
    skill.close()
    return result


async def handle_diagnose_table(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle table diagnosis requests."""
    database = params["database"]
    table_name = params["table_name"]
    
    connector = get_connector_for_database(database)
    skill = DiagnoseSkill(connector)
    
    result = skill.diagnose_table(table_name)
    skill.close()
    return result


async def handle_diagnose_bottleneck(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle performance bottleneck analysis requests."""
    database = params["database"]
    
    connector = get_connector_for_database(database)
    skill = DiagnoseSkill(connector)
    
    result = skill.analyze_performance_bottleneck()
    skill.close()
    return result


async def handle_diagnose_space(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle tablespace analysis requests."""
    database = params["database"]
    top_n = params.get("top_n", 20)
    min_size_mb = params.get("min_size_mb", 100)
    
    connector = get_connector_for_database(database)
    skill = DiagnoseSkill(connector)
    
    result = skill.analyze_space(top_n=top_n, min_size_mb=min_size_mb, database=database)
    skill.close()
    return result


async def handle_diagnose_connections(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle connection analysis requests."""
    database = params["database"]
    show_idle = params.get("show_idle", False)
    
    connector = get_connector_for_database(database)
    skill = DiagnoseSkill(connector)
    
    result = skill.analyze_connections(show_idle=show_idle)
    skill.close()
    return result


async def handle_diagnose_replication(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle replication analysis requests."""
    database = params["database"]
    
    connector = get_connector_for_database(database)
    skill = DiagnoseSkill(connector)
    
    result = skill.analyze_replication()
    skill.close()
    return result


async def handle_diagnose_bloat(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle table bloat analysis requests."""
    database = params["database"]
    threshold = params.get("threshold", 30)
    
    connector = get_connector_for_database(database)
    skill = DiagnoseSkill(connector)
    
    result = skill.analyze_bloat(threshold=threshold)
    skill.close()
    return result


async def handle_diagnose_index_usage(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle index usage analysis requests."""
    database = params["database"]
    
    connector = get_connector_for_database(database)
    skill = DiagnoseSkill(connector)
    
    result = skill.analyze_index_usage()
    skill.close()
    return result


async def handle_diagnose_vacuum(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle vacuum analysis requests."""
    database = params["database"]
    
    connector = get_connector_for_database(database)
    skill = DiagnoseSkill(connector)
    
    result = skill.analyze_vacuum()
    skill.close()
    return result


async def handle_diagnose_indexes(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle index recommendation requests."""
    database = params["database"]
    table = params.get("table")
    
    connector = get_connector_for_database(database)
    skill = DiagnoseSkill(connector)
    
    result = skill.recommend_indexes(table=table)
    skill.close()
    return result


def register_diagnose_tools(registry: ToolRegistry) -> None:
    """Register all diagnosis tools."""
    logger.info("Registering diagnose tools")
    
    registry.register_tool(
        Tool(
            name="diagnose_realtime",
            description="Perform real-time database performance diagnosis to identify current bottlenecks",
            parameters=[
                create_database_param(),
                ToolParameter(
                    name="threshold",
                    type=ParameterType.INTEGER,
                    description="Slow query threshold in seconds",
                    required=False,
                    default=5,
                ),
            ],
            handler=handle_diagnose_realtime,
        ),
        category="diagnose",
    )
    
    registry.register_tool(
        Tool(
            name="diagnose_sql",
            description="Analyze SQL statement performance with execution plan and optimization suggestions",
            parameters=[
                create_database_param(),
                ToolParameter(
                    name="sql",
                    type=ParameterType.STRING,
                    description="SQL statement to analyze",
                    required=True,
                ),
                ToolParameter(
                    name="params",
                    type=ParameterType.OBJECT,
                    description="SQL parameters as dictionary",
                    required=False,
                ),
            ],
            handler=handle_diagnose_sql,
        ),
        category="diagnose",
    )
    
    registry.register_tool(
        Tool(
            name="diagnose_slow_queries",
            description="Analyze slow queries in the database",
            parameters=[
                create_database_param(),
                ToolParameter(
                    name="limit",
                    type=ParameterType.INTEGER,
                    description="Number of slow queries to return",
                    required=False,
                    default=10,
                ),
                ToolParameter(
                    name="min_time",
                    type=ParameterType.NUMBER,
                    description="Minimum execution time in seconds",
                    required=False,
                    default=1.0,
                ),
            ],
            handler=handle_diagnose_slow_queries,
        ),
        category="diagnose",
    )
    
    registry.register_tool(
        Tool(
            name="diagnose_table",
            description="Diagnose a specific table for performance issues and optimization opportunities",
            parameters=[
                create_database_param(),
                ToolParameter(
                    name="table_name",
                    type=ParameterType.STRING,
                    description="Table name to diagnose",
                    required=True,
                ),
            ],
            handler=handle_diagnose_table,
        ),
        category="diagnose",
    )
    
    registry.register_tool(
        Tool(
            name="diagnose_bottleneck",
            description="Analyze performance bottlenecks in the database",
            parameters=[create_database_param()],
            handler=handle_diagnose_bottleneck,
        ),
        category="diagnose",
    )
    
    registry.register_tool(
        Tool(
            name="diagnose_space",
            description="Analyze tablespace usage and identify large tables",
            parameters=[
                create_database_param(),
                ToolParameter(
                    name="top_n",
                    type=ParameterType.INTEGER,
                    description="Number of largest tables to return",
                    required=False,
                    default=20,
                ),
                ToolParameter(
                    name="min_size_mb",
                    type=ParameterType.INTEGER,
                    description="Minimum table size in MB to include",
                    required=False,
                    default=100,
                ),
            ],
            handler=handle_diagnose_space,
        ),
        category="diagnose",
    )
    
    registry.register_tool(
        Tool(
            name="diagnose_connections",
            description="Analyze database connections and identify connection issues",
            parameters=[
                create_database_param(),
                ToolParameter(
                    name="show_idle",
                    type=ParameterType.BOOLEAN,
                    description="Include idle connections in the analysis",
                    required=False,
                    default=False,
                ),
            ],
            handler=handle_diagnose_connections,
        ),
        category="diagnose",
    )
    
    registry.register_tool(
        Tool(
            name="diagnose_replication",
            description="Analyze database replication status and lag",
            parameters=[create_database_param()],
            handler=handle_diagnose_replication,
        ),
        category="diagnose",
    )
    
    registry.register_tool(
        Tool(
            name="diagnose_bloat",
            description="Analyze table bloat and fragmentation",
            parameters=[
                create_database_param(),
                ToolParameter(
                    name="threshold",
                    type=ParameterType.INTEGER,
                    description="Bloat threshold percentage",
                    required=False,
                    default=30,
                ),
            ],
            handler=handle_diagnose_bloat,
        ),
        category="diagnose",
    )
    
    registry.register_tool(
        Tool(
            name="diagnose_index_usage",
            description="Analyze index usage patterns and identify unused indexes",
            parameters=[create_database_param()],
            handler=handle_diagnose_index_usage,
        ),
        category="diagnose",
    )
    
    registry.register_tool(
        Tool(
            name="diagnose_vacuum",
            description="Analyze vacuum requirements for PostgreSQL databases",
            parameters=[create_database_param()],
            handler=handle_diagnose_vacuum,
        ),
        category="diagnose",
    )
    
    registry.register_tool(
        Tool(
            name="diagnose_indexes",
            description="Recommend indexes based on query patterns",
            parameters=[
                create_database_param(),
                ToolParameter(
                    name="table",
                    type=ParameterType.STRING,
                    description="Specific table to analyze (optional)",
                    required=False,
                ),
            ],
            handler=handle_diagnose_indexes,
        ),
        category="diagnose",
    )


# ============================================================================
# Monitor Tools
# ============================================================================

async def handle_monitor_health(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle health check requests."""
    database = params["database"]
    
    connector = get_connector_for_database(database)
    skill = MonitorSkill(connector)
    
    result = skill.assess_health()
    skill.close()
    return result


async def handle_monitor_metrics(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle metrics collection requests."""
    database = params["database"]
    metric_types = params.get("metric_types")
    
    connector = get_connector_for_database(database)
    skill = MonitorSkill(connector)
    
    result = skill.collect_metrics(metric_types=metric_types)
    skill.close()
    return result


async def handle_monitor_anomalies(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle anomaly detection requests."""
    database = params["database"]
    
    connector = get_connector_for_database(database)
    skill = MonitorSkill(connector)
    
    result = skill.detect_anomalies()
    skill.close()
    return result


async def handle_monitor_capacity(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle capacity prediction requests."""
    database = params["database"]
    metric = params.get("metric", "disk")
    days = params.get("days", 30)
    
    connector = get_connector_for_database(database)
    skill = MonitorSkill(connector)
    
    result = skill.predict_capacity(metric=metric, days=days)
    skill.close()
    return result


async def handle_monitor_trend(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle trend analysis requests."""
    database = params["database"]
    metric = params.get("metric")
    days = params.get("days", 7)
    
    connector = get_connector_for_database(database)
    skill = MonitorSkill(connector)
    
    result = skill.analyze_trend(metric=metric, days=days)
    skill.close()
    return result


async def handle_monitor_history(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle metric history requests."""
    database = params["database"]
    metric = params["metric"]
    hours = params.get("hours", 24)
    
    connector = get_connector_for_database(database)
    skill = MonitorSkill(connector)
    
    result = skill.get_metric_history(metric=metric, hours=hours)
    skill.close()
    return result


async def handle_monitor_alerts(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle alerts retrieval requests."""
    database = params["database"]
    status = params.get("status")
    
    connector = get_connector_for_database(database)
    skill = MonitorSkill(connector)
    
    result = skill.get_alerts(status=status)
    skill.close()
    return result


async def handle_monitor_baseline(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle baseline comparison requests."""
    database = params["database"]
    metric = params.get("metric")
    
    connector = get_connector_for_database(database)
    skill = MonitorSkill(connector)
    
    result = skill.compare_with_baseline(metric=metric)
    skill.close()
    return result


async def handle_monitor_degradation(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle performance degradation detection requests."""
    database = params["database"]
    
    connector = get_connector_for_database(database)
    skill = MonitorSkill(connector)
    
    result = skill.detect_performance_degradation()
    skill.close()
    return result


def register_monitor_tools(registry: ToolRegistry) -> None:
    """Register all monitoring tools."""
    logger.info("Registering monitor tools")
    
    registry.register_tool(
        Tool(
            name="monitor_health",
            description="Check database health status and overall condition",
            parameters=[create_database_param()],
            handler=handle_monitor_health,
        ),
        category="monitor",
    )
    
    registry.register_tool(
        Tool(
            name="monitor_metrics",
            description="Collect database performance metrics",
            parameters=[
                create_database_param(),
                ToolParameter(
                    name="metric_types",
                    type=ParameterType.ARRAY,
                    description="List of metric types to collect",
                    required=False,
                ),
            ],
            handler=handle_monitor_metrics,
        ),
        category="monitor",
    )
    
    registry.register_tool(
        Tool(
            name="monitor_anomalies",
            description="Detect anomalies in database metrics and performance patterns",
            parameters=[create_database_param()],
            handler=handle_monitor_anomalies,
        ),
        category="monitor",
    )
    
    registry.register_tool(
        Tool(
            name="monitor_capacity",
            description="Predict capacity requirements for the specified metric",
            parameters=[
                create_database_param(),
                ToolParameter(
                    name="metric",
                    type=ParameterType.STRING,
                    description="Metric to predict (disk, memory, cpu, connections)",
                    required=False,
                    default="disk",
                ),
                ToolParameter(
                    name="days",
                    type=ParameterType.INTEGER,
                    description="Number of days to predict ahead",
                    required=False,
                    default=30,
                ),
            ],
            handler=handle_monitor_capacity,
        ),
        category="monitor",
    )
    
    registry.register_tool(
        Tool(
            name="monitor_trend",
            description="Analyze performance trends over time",
            parameters=[
                create_database_param(),
                ToolParameter(
                    name="metric",
                    type=ParameterType.STRING,
                    description="Metric to analyze",
                    required=False,
                ),
                ToolParameter(
                    name="days",
                    type=ParameterType.INTEGER,
                    description="Number of days to analyze",
                    required=False,
                    default=7,
                ),
            ],
            handler=handle_monitor_trend,
        ),
        category="monitor",
    )
    
    registry.register_tool(
        Tool(
            name="monitor_history",
            description="Get historical metric data",
            parameters=[
                create_database_param(),
                ToolParameter(
                    name="metric",
                    type=ParameterType.STRING,
                    description="Metric name",
                    required=True,
                ),
                ToolParameter(
                    name="hours",
                    type=ParameterType.INTEGER,
                    description="Number of hours of history",
                    required=False,
                    default=24,
                ),
            ],
            handler=handle_monitor_history,
        ),
        category="monitor",
    )
    
    registry.register_tool(
        Tool(
            name="monitor_alerts",
            description="Get active and historical alerts",
            parameters=[
                create_database_param(),
                ToolParameter(
                    name="status",
                    type=ParameterType.STRING,
                    description="Filter by status (active, acknowledged, resolved)",
                    required=False,
                ),
            ],
            handler=handle_monitor_alerts,
        ),
        category="monitor",
    )
    
    registry.register_tool(
        Tool(
            name="monitor_baseline",
            description="Compare current metrics with established baseline",
            parameters=[
                create_database_param(),
                ToolParameter(
                    name="metric",
                    type=ParameterType.STRING,
                    description="Metric to compare",
                    required=False,
                ),
            ],
            handler=handle_monitor_baseline,
        ),
        category="monitor",
    )
    
    registry.register_tool(
        Tool(
            name="monitor_degradation",
            description="Detect performance degradation trends",
            parameters=[create_database_param()],
            handler=handle_monitor_degradation,
        ),
        category="monitor",
    )


# ============================================================================
# SQL Tools
# ============================================================================

async def handle_sql_execute(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle SQL execution requests."""
    database = params["database"]
    sql = params["sql"]
    sql_params = params.get("params")
    limit = params.get("limit", 1000)
    
    connector = get_connector_for_database(database)
    skill = SQLMasterSkill(connector, max_rows=limit)
    
    return skill.execute(sql, sql_params)


async def handle_sql_rewrite(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle SQL rewrite requests."""
    database = params["database"]
    sql = params["sql"]
    
    connector = get_connector_for_database(database)
    skill = SQLMasterSkill(connector)
    
    result = skill.rewrite_sql(sql)
    skill.close()
    return result


async def handle_sql_batch(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle batch SQL execution requests."""
    database = params["database"]
    sqls = params["sqls"]
    
    connector = get_connector_for_database(database)
    skill = SQLMasterSkill(connector)
    
    result = skill.execute_batch(sqls)
    skill.close()
    return result


async def handle_sql_export(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle data export requests."""
    database = params["database"]
    table = params.get("table")
    sql = params.get("sql")
    output_path = params["output_path"]
    format = params.get("format", "csv")
    
    connector = get_connector_for_database(database)
    skill = SQLMasterSkill(connector)
    
    if table:
        result = skill.export_table(table, output_path, format_type=format)
    else:
        result = skill.export_query(sql, output_path, format_type=format)
    skill.close()
    return result


async def handle_sql_import(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle data import requests."""
    database = params["database"]
    table = params["table"]
    input_path = params["input_path"]
    format = params.get("format", "csv")
    
    connector = get_connector_for_database(database)
    skill = SQLMasterSkill(connector)
    
    if format == "csv":
        result = skill.import_csv(table, input_path)
    elif format == "json":
        result = skill.import_json(table, input_path)
    else:
        result = skill.import_sql(input_path)
    skill.close()
    return result


async def handle_sql_audit(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle SQL audit records requests."""
    database = params["database"]
    days = params.get("days", 7)
    
    connector = get_connector_for_database(database)
    skill = SQLMasterSkill(connector)
    
    result = skill.get_audit_records(days=days)
    skill.close()
    return result


async def handle_sql_quality(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle SQL quality analysis requests."""
    database = params["database"]
    sql = params["sql"]
    
    connector = get_connector_for_database(database)
    skill = SQLMasterSkill(connector)
    
    result = skill.analyze_sql_quality(sql)
    skill.close()
    return result


async def handle_sql_schema(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle schema information requests."""
    database = params["database"]
    table_name = params["table_name"]
    
    connector = get_connector_for_database(database)
    skill = SQLMasterSkill(connector)
    
    result = skill.get_schema_info(table_name)
    skill.close()
    return result


async def handle_sql_tables(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle table listing requests."""
    database = params["database"]
    
    connector = get_connector_for_database(database)
    skill = SQLMasterSkill(connector)
    
    result = skill.list_tables()
    skill.close()
    return result


def register_sql_tools(registry: ToolRegistry) -> None:
    """Register all SQL processing tools."""
    logger.info("Registering SQL tools")
    
    registry.register_tool(
        Tool(
            name="sql_execute",
            description="Execute SQL statement and return results",
            parameters=[
                create_database_param(),
                ToolParameter(
                    name="sql",
                    type=ParameterType.STRING,
                    description="SQL statement to execute",
                    required=True,
                ),
                ToolParameter(
                    name="params",
                    type=ParameterType.OBJECT,
                    description="SQL parameters",
                    required=False,
                ),
                ToolParameter(
                    name="limit",
                    type=ParameterType.INTEGER,
                    description="Maximum rows to return",
                    required=False,
                    default=1000,
                ),
            ],
            handler=handle_sql_execute,
        ),
        category="sql",
    )
    
    registry.register_tool(
        Tool(
            name="sql_rewrite",
            description="Rewrite SQL statement for better performance",
            parameters=[
                create_database_param(),
                ToolParameter(
                    name="sql",
                    type=ParameterType.STRING,
                    description="SQL statement to rewrite",
                    required=True,
                ),
            ],
            handler=handle_sql_rewrite,
        ),
        category="sql",
    )
    
    registry.register_tool(
        Tool(
            name="sql_batch",
            description="Execute multiple SQL statements in batch",
            parameters=[
                create_database_param(),
                ToolParameter(
                    name="sqls",
                    type=ParameterType.ARRAY,
                    description="List of SQL statements to execute",
                    required=True,
                ),
            ],
            handler=handle_sql_batch,
        ),
        category="sql",
    )
    
    registry.register_tool(
        Tool(
            name="sql_export",
            description="Export data from database to file (CSV, JSON, SQL)",
            parameters=[
                create_database_param(),
                ToolParameter(
                    name="output_path",
                    type=ParameterType.STRING,
                    description="Output file path",
                    required=True,
                ),
                ToolParameter(
                    name="table",
                    type=ParameterType.STRING,
                    description="Table name to export",
                    required=False,
                ),
                ToolParameter(
                    name="sql",
                    type=ParameterType.STRING,
                    description="SQL query to export results",
                    required=False,
                ),
                ToolParameter(
                    name="format",
                    type=ParameterType.STRING,
                    description="Export format (csv, json, sql)",
                    required=False,
                    default="csv",
                ),
            ],
            handler=handle_sql_export,
        ),
        category="sql",
    )
    
    registry.register_tool(
        Tool(
            name="sql_import",
            description="Import data from file into database",
            parameters=[
                create_database_param(),
                ToolParameter(
                    name="table",
                    type=ParameterType.STRING,
                    description="Target table name",
                    required=True,
                ),
                ToolParameter(
                    name="input_path",
                    type=ParameterType.STRING,
                    description="Input file path",
                    required=True,
                ),
                ToolParameter(
                    name="format",
                    type=ParameterType.STRING,
                    description="Import format (csv, json, sql)",
                    required=False,
                    default="csv",
                ),
            ],
            handler=handle_sql_import,
        ),
        category="sql",
    )
    
    registry.register_tool(
        Tool(
            name="sql_audit",
            description="Get SQL execution audit records",
            parameters=[
                create_database_param(),
                ToolParameter(
                    name="days",
                    type=ParameterType.INTEGER,
                    description="Number of days of history",
                    required=False,
                    default=7,
                ),
            ],
            handler=handle_sql_audit,
        ),
        category="sql",
    )
    
    registry.register_tool(
        Tool(
            name="sql_quality",
            description="Analyze SQL statement quality and best practices",
            parameters=[
                create_database_param(),
                ToolParameter(
                    name="sql",
                    type=ParameterType.STRING,
                    description="SQL statement to analyze",
                    required=True,
                ),
            ],
            handler=handle_sql_quality,
        ),
        category="sql",
    )
    
    registry.register_tool(
        Tool(
            name="sql_schema",
            description="Get schema information for a table",
            parameters=[
                create_database_param(),
                ToolParameter(
                    name="table_name",
                    type=ParameterType.STRING,
                    description="Table name",
                    required=True,
                ),
            ],
            handler=handle_sql_schema,
        ),
        category="sql",
    )
    
    registry.register_tool(
        Tool(
            name="sql_tables",
            description="List all tables in the database",
            parameters=[create_database_param()],
            handler=handle_sql_tables,
        ),
        category="sql",
    )


# ============================================================================
# Security Tools
# ============================================================================

async def handle_security_sql_injection(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle SQL injection detection requests."""
    database = params["database"]
    sql = params["sql"]
    
    connector = get_connector_for_database(database)
    skill = SecuritySkill(connector)
    
    result = skill.detect_sql_injection(sql)
    skill.close()
    return result


async def handle_security_score(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle security score requests."""
    database = params["database"]
    
    connector = get_connector_for_database(database)
    skill = SecuritySkill(connector)
    
    result = skill.calculate_security_score()
    skill.close()
    return result


async def handle_security_sensitive_data(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle sensitive data scanning requests."""
    database = params["database"]
    
    connector = get_connector_for_database(database)
    skill = SecuritySkill(connector)
    
    result = skill.scan_sensitive_data()
    skill.close()
    return result


async def handle_security_permissions(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle permissions audit requests."""
    database = params["database"]
    
    connector = get_connector_for_database(database)
    skill = SecuritySkill(connector)
    
    result = skill.audit_permissions()
    skill.close()
    return result


async def handle_security_config(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle security configuration audit requests."""
    database = params["database"]
    
    connector = get_connector_for_database(database)
    skill = SecuritySkill(connector)
    
    result = skill.audit_config()
    skill.close()
    return result


async def handle_security_full_audit(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle full security audit requests."""
    database = params["database"]
    
    connector = get_connector_for_database(database)
    skill = SecuritySkill(connector)
    
    result = skill.full_audit()
    skill.close()
    return result


async def handle_security_password_policy(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle password policy check requests."""
    database = params["database"]
    
    connector = get_connector_for_database(database)
    skill = SecuritySkill(connector)
    
    result = skill.check_password_policy()
    skill.close()
    return result


async def handle_security_weak_passwords(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle weak password detection requests."""
    database = params["database"]
    
    connector = get_connector_for_database(database)
    skill = SecuritySkill(connector)
    
    result = skill.find_weak_passwords()
    skill.close()
    return result


async def handle_security_login(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle login security check requests."""
    database = params["database"]
    
    connector = get_connector_for_database(database)
    skill = SecuritySkill(connector)
    
    result = skill.check_login_security()
    skill.close()
    return result


async def handle_security_high_risk(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle high risk operation detection requests."""
    database = params["database"]
    
    connector = get_connector_for_database(database)
    skill = SecuritySkill(connector)
    
    result = skill.detect_high_risk_operations()
    skill.close()
    return result


async def handle_security_compliance(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle compliance check requests."""
    database = params["database"]
    standard = params.get("standard")
    
    connector = get_connector_for_database(database)
    skill = SecuritySkill(connector)
    
    result = skill.check_compliance(standard=standard)
    skill.close()
    return result


def register_security_tools(registry: ToolRegistry) -> None:
    """Register all security tools."""
    logger.info("Registering security tools")
    
    registry.register_tool(
        Tool(
            name="security_sql_injection",
            description="Detect SQL injection vulnerabilities in SQL statements",
            parameters=[
                create_database_param(),
                ToolParameter(
                    name="sql",
                    type=ParameterType.STRING,
                    description="SQL statement to check",
                    required=True,
                ),
            ],
            handler=handle_security_sql_injection,
        ),
        category="security",
    )
    
    registry.register_tool(
        Tool(
            name="security_score",
            description="Calculate overall database security score",
            parameters=[create_database_param()],
            handler=handle_security_score,
        ),
        category="security",
    )
    
    registry.register_tool(
        Tool(
            name="security_sensitive_data",
            description="Scan for sensitive data exposure risks",
            parameters=[create_database_param()],
            handler=handle_security_sensitive_data,
        ),
        category="security",
    )
    
    registry.register_tool(
        Tool(
            name="security_permissions",
            description="Audit database user permissions and access controls",
            parameters=[create_database_param()],
            handler=handle_security_permissions,
        ),
        category="security",
    )
    
    registry.register_tool(
        Tool(
            name="security_config",
            description="Audit security configuration settings",
            parameters=[create_database_param()],
            handler=handle_security_config,
        ),
        category="security",
    )
    
    registry.register_tool(
        Tool(
            name="security_audit",
            description="Perform comprehensive security audit",
            parameters=[create_database_param()],
            handler=handle_security_full_audit,
        ),
        category="security",
    )
    
    registry.register_tool(
        Tool(
            name="security_password_policy",
            description="Check password policy compliance",
            parameters=[create_database_param()],
            handler=handle_security_password_policy,
        ),
        category="security",
    )
    
    registry.register_tool(
        Tool(
            name="security_weak_passwords",
            description="Find users with weak passwords",
            parameters=[create_database_param()],
            handler=handle_security_weak_passwords,
        ),
        category="security",
    )
    
    registry.register_tool(
        Tool(
            name="security_login",
            description="Check login security and failed login attempts",
            parameters=[create_database_param()],
            handler=handle_security_login,
        ),
        category="security",
    )
    
    registry.register_tool(
        Tool(
            name="security_high_risk",
            description="Detect high risk database operations",
            parameters=[create_database_param()],
            handler=handle_security_high_risk,
        ),
        category="security",
    )
    
    registry.register_tool(
        Tool(
            name="security_compliance",
            description="Check compliance with security standards",
            parameters=[
                create_database_param(),
                ToolParameter(
                    name="standard",
                    type=ParameterType.STRING,
                    description="Compliance standard (GDPR, SOC2, PCI-DSS, etc.)",
                    required=False,
                ),
            ],
            handler=handle_security_compliance,
        ),
        category="security",
    )


# ============================================================================
# Inspector Tools
# ============================================================================

async def handle_inspector_inspect(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle database inspection requests."""
    database = params["database"]
    inspection_type = params.get("inspection_type")
    
    connector = get_connector_for_database(database)
    skill = InspectorSkill(connector)
    
    result = skill.inspect(inspection_type=inspection_type)
    skill.close()
    return result


async def handle_inspector_intelligent(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle intelligent inspection requests."""
    database = params["database"]
    scenario = params.get("scenario", "general")
    
    connector = get_connector_for_database(database)
    skill = InspectorSkill(connector)
    
    result = skill.intelligent_inspect(scenario=scenario)
    skill.close()
    return result


async def handle_inspector_anomalies(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle anomaly detection requests."""
    database = params["database"]
    metric = params.get("metric")
    
    connector = get_connector_for_database(database)
    skill = InspectorSkill(connector)
    
    result = skill.detect_anomalies(metric=metric)
    skill.close()
    return result


async def handle_inspector_root_cause(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle root cause analysis requests."""
    database = params["database"]
    issue = params["issue"]
    
    connector = get_connector_for_database(database)
    skill = InspectorSkill(connector)
    
    result = skill.analyze_root_causes(issue=issue)
    skill.close()
    return result


async def handle_inspector_risks(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle risk prediction requests."""
    database = params["database"]
    days = params.get("days", 7)
    
    connector = get_connector_for_database(database)
    skill = InspectorSkill(connector)
    
    result = skill.predict_risks(days=days)
    skill.close()
    return result


async def handle_inspector_baseline(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle baseline creation requests."""
    database = params["database"]
    name = params.get("name")
    
    connector = get_connector_for_database(database)
    skill = InspectorSkill(connector)
    
    result = skill.create_baseline(name=name)
    skill.close()
    return result


async def handle_inspector_compare(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle baseline comparison requests."""
    database = params["database"]
    baseline_name = params.get("baseline_name")
    
    connector = get_connector_for_database(database)
    skill = InspectorSkill(connector)
    
    result = skill.compare_with_baseline(baseline_name=baseline_name)
    skill.close()
    return result


async def handle_inspector_issues(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle top issues retrieval requests."""
    database = params["database"]
    limit = params.get("limit", 10)
    
    connector = get_connector_for_database(database)
    skill = InspectorSkill(connector)
    
    result = skill.get_top_issues(limit=limit)
    skill.close()
    return result


def register_inspector_tools(registry: ToolRegistry) -> None:
    """Register all inspector tools."""
    logger.info("Registering inspector tools")
    
    registry.register_tool(
        Tool(
            name="inspector_inspect",
            description="Run comprehensive database inspection including configuration, performance, and security checks",
            parameters=[
                create_database_param(),
                ToolParameter(
                    name="inspection_type",
                    type=ParameterType.STRING,
                    description="Type of inspection (configuration, performance, security, or all)",
                    required=False,
                    enum=["configuration", "performance", "security", "all"],
                ),
            ],
            handler=handle_inspector_inspect,
        ),
        category="inspector",
    )
    
    registry.register_tool(
        Tool(
            name="inspector_intelligent",
            description="Run AI-powered intelligent inspection with automated problem detection",
            parameters=[
                create_database_param(),
                ToolParameter(
                    name="scenario",
                    type=ParameterType.STRING,
                    description="Inspection scenario (general, performance_issue, capacity_planning)",
                    required=False,
                    default="general",
                ),
            ],
            handler=handle_inspector_intelligent,
        ),
        category="inspector",
    )
    
    registry.register_tool(
        Tool(
            name="inspector_anomalies",
            description="Detect anomalies in database metrics and performance patterns",
            parameters=[
                create_database_param(),
                ToolParameter(
                    name="metric",
                    type=ParameterType.STRING,
                    description="Specific metric to analyze (cpu, memory, connections, io, etc.)",
                    required=False,
                ),
            ],
            handler=handle_inspector_anomalies,
        ),
        category="inspector",
    )
    
    registry.register_tool(
        Tool(
            name="inspector_root_cause",
            description="Analyze root causes of database issues and provide actionable recommendations",
            parameters=[
                create_database_param(),
                ToolParameter(
                    name="issue",
                    type=ParameterType.STRING,
                    description="Description of the issue or problem observed",
                    required=True,
                ),
            ],
            handler=handle_inspector_root_cause,
        ),
        category="inspector",
    )
    
    registry.register_tool(
        Tool(
            name="inspector_risks",
            description="Predict potential risks and issues in the database over a specified time period",
            parameters=[
                create_database_param(),
                ToolParameter(
                    name="days",
                    type=ParameterType.INTEGER,
                    description="Number of days to predict ahead",
                    required=False,
                    default=7,
                ),
            ],
            handler=handle_inspector_risks,
        ),
        category="inspector",
    )
    
    registry.register_tool(
        Tool(
            name="inspector_baseline_create",
            description="Create a performance baseline for future comparisons",
            parameters=[
                create_database_param(),
                ToolParameter(
                    name="name",
                    type=ParameterType.STRING,
                    description="Name for the baseline",
                    required=False,
                ),
            ],
            handler=handle_inspector_baseline,
        ),
        category="inspector",
    )
    
    registry.register_tool(
        Tool(
            name="inspector_baseline_compare",
            description="Compare current performance with an existing baseline",
            parameters=[
                create_database_param(),
                ToolParameter(
                    name="baseline_name",
                    type=ParameterType.STRING,
                    description="Name of the baseline to compare against",
                    required=False,
                ),
            ],
            handler=handle_inspector_compare,
        ),
        category="inspector",
    )
    
    registry.register_tool(
        Tool(
            name="inspector_top_issues",
            description="Get the most critical issues found during inspection",
            parameters=[
                create_database_param(),
                ToolParameter(
                    name="limit",
                    type=ParameterType.INTEGER,
                    description="Maximum number of issues to return",
                    required=False,
                    default=10,
                ),
            ],
            handler=handle_inspector_issues,
        ),
        category="inspector",
    )


# ============================================================================
# Lock Analyzer Tools
# ============================================================================

async def handle_lock_analyze(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle current lock analysis requests."""
    database = params["database"]
    
    connector = get_connector_for_database(database)
    skill = LockAnalyzerSkill(connector)
    
    result = skill.analyze_current_locks()
    skill.close()
    return result


async def handle_lock_deadlocks(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle deadlock detection requests."""
    database = params["database"]
    
    connector = get_connector_for_database(database)
    skill = LockAnalyzerSkill(connector)
    
    result = skill.detect_deadlocks()
    skill.close()
    return result


async def handle_lock_chains(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle lock wait chain tracing requests."""
    database = params["database"]
    
    connector = get_connector_for_database(database)
    skill = LockAnalyzerSkill(connector)
    
    result = skill.trace_lock_wait_chain()
    skill.close()
    return result


async def handle_lock_statistics(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle lock statistics requests."""
    database = params["database"]
    
    connector = get_connector_for_database(database)
    skill = LockAnalyzerSkill(connector)
    
    result = skill.get_lock_statistics()
    skill.close()
    return result


async def handle_lock_report(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle lock report generation requests."""
    database = params["database"]
    
    connector = get_connector_for_database(database)
    skill = LockAnalyzerSkill(connector)
    
    result = skill.generate_lock_report()
    skill.close()
    return result


async def handle_lock_kill(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle blocking transaction termination requests."""
    database = params["database"]
    transaction_id = params["transaction_id"]
    
    connector = get_connector_for_database(database)
    skill = LockAnalyzerSkill(connector)
    
    result = skill.kill_blocking_transaction(transaction_id)
    skill.close()
    return result


def register_lock_tools(registry: ToolRegistry) -> None:
    """Register all lock analyzer tools."""
    logger.info("Registering lock analyzer tools")
    
    registry.register_tool(
        Tool(
            name="lock_analyze",
            description="Analyze current locks in the database including blocking relationships",
            parameters=[create_database_param()],
            handler=handle_lock_analyze,
        ),
        category="lock",
    )
    
    registry.register_tool(
        Tool(
            name="lock_deadlocks",
            description="Detect deadlocks in the database and provide detailed information",
            parameters=[create_database_param()],
            handler=handle_lock_deadlocks,
        ),
        category="lock",
    )
    
    registry.register_tool(
        Tool(
            name="lock_chains",
            description="Trace lock wait chains to understand blocking relationships",
            parameters=[create_database_param()],
            handler=handle_lock_chains,
        ),
        category="lock",
    )
    
    registry.register_tool(
        Tool(
            name="lock_statistics",
            description="Get lock statistics including wait times and lock types",
            parameters=[create_database_param()],
            handler=handle_lock_statistics,
        ),
        category="lock",
    )
    
    registry.register_tool(
        Tool(
            name="lock_report",
            description="Generate a comprehensive lock analysis report",
            parameters=[create_database_param()],
            handler=handle_lock_report,
        ),
        category="lock",
    )
    
    registry.register_tool(
        Tool(
            name="lock_kill_transaction",
            description="Terminate a blocking transaction by its ID",
            parameters=[
                create_database_param(),
                ToolParameter(
                    name="transaction_id",
                    type=ParameterType.STRING,
                    description="Transaction ID to terminate",
                    required=True,
                ),
            ],
            handler=handle_lock_kill,
        ),
        category="lock",
    )


# ============================================================================
# Scheduler Tools
# ============================================================================

async def handle_scheduler_backup(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle database backup requests."""
    database = params["database"]
    backup_type = params.get("backup_type", "full")
    tables = params.get("tables")
    
    connector = get_connector_for_database(database)
    skill = SchedulerSkill(connector)
    
    result = skill.backup(backup_type=backup_type, tables=tables)
    skill.close()
    return result


async def handle_scheduler_list_backups(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle list backups requests."""
    database = params["database"]
    
    connector = get_connector_for_database(database)
    skill = SchedulerSkill(connector)
    
    result = skill.list_backups()
    skill.close()
    return result


async def handle_scheduler_restore(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle backup restore requests."""
    database = params["database"]
    backup_file = params["backup_file"]
    target_db = params.get("target_db")
    
    connector = get_connector_for_database(database)
    skill = SchedulerSkill(connector)
    
    result = skill.restore_backup(backup_file, target_db)
    skill.close()
    return result


async def handle_scheduler_schedule_task(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle task scheduling requests."""
    database = params["database"]
    task_name = params["task_name"]
    cron = params["cron"]
    command = params["command"]
    description = params.get("description", "")
    
    connector = get_connector_for_database(database)
    skill = SchedulerSkill(connector)
    
    result = skill.schedule_task(
        task_name=task_name,
        cron=cron,
        command=command,
        description=description,
    )
    skill.close()
    return result


async def handle_scheduler_list_tasks(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle list scheduled tasks requests."""
    database = params["database"]
    
    connector = get_connector_for_database(database)
    skill = SchedulerSkill(connector)
    
    result = skill.list_tasks()
    skill.close()
    return result


async def handle_scheduler_run_now(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle immediate task execution requests."""
    database = params["database"]
    task_id = params["task_id"]
    
    connector = get_connector_for_database(database)
    skill = SchedulerSkill(connector)
    
    result = skill.run_task_now(task_id)
    skill.close()
    return result


async def handle_scheduler_dlq(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle dead letter queue tasks requests."""
    database = params["database"]
    status = params.get("status")
    limit = params.get("limit", 50)
    
    connector = get_connector_for_database(database)
    skill = SchedulerSkill(connector)
    
    result = skill.get_dlq_tasks(status=status, limit=limit)
    skill.close()
    return result


async def handle_scheduler_dlq_retry(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle DLQ task retry requests."""
    database = params["database"]
    dlq_id = params["dlq_id"]
    
    connector = get_connector_for_database(database)
    skill = SchedulerSkill(connector)
    
    result = skill.retry_dlq_task(dlq_id)
    skill.close()
    return result


async def handle_scheduler_task_logs(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle task logs retrieval requests."""
    database = params["database"]
    task_id = params["task_id"]
    limit = params.get("limit", 100)
    
    connector = get_connector_for_database(database)
    skill = SchedulerSkill(connector)
    
    result = skill.get_task_logs(task_id=task_id, limit=limit)
    skill.close()
    return result


async def handle_scheduler_status(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle scheduler status requests."""
    database = params["database"]
    
    connector = get_connector_for_database(database)
    skill = SchedulerSkill(connector)
    
    result = skill.get_scheduler_status()
    skill.close()
    return result


def register_scheduler_tools(registry: ToolRegistry) -> None:
    """Register all scheduler tools."""
    logger.info("Registering scheduler tools")
    
    registry.register_tool(
        Tool(
            name="scheduler_backup",
            description="Perform database backup (full or incremental)",
            parameters=[
                create_database_param(),
                ToolParameter(
                    name="backup_type",
                    type=ParameterType.STRING,
                    description="Backup type (full or incremental)",
                    required=False,
                    default="full",
                    enum=["full", "incremental"],
                ),
                ToolParameter(
                    name="tables",
                    type=ParameterType.ARRAY,
                    description="List of tables to backup (for partial backup)",
                    required=False,
                ),
            ],
            handler=handle_scheduler_backup,
        ),
        category="scheduler",
    )
    
    registry.register_tool(
        Tool(
            name="scheduler_list_backups",
            description="List all available database backups",
            parameters=[create_database_param()],
            handler=handle_scheduler_list_backups,
        ),
        category="scheduler",
    )
    
    registry.register_tool(
        Tool(
            name="scheduler_restore",
            description="Restore database from a backup file",
            parameters=[
                create_database_param(),
                ToolParameter(
                    name="backup_file",
                    type=ParameterType.STRING,
                    description="Backup file path or identifier",
                    required=True,
                ),
                ToolParameter(
                    name="target_db",
                    type=ParameterType.STRING,
                    description="Target database name (optional)",
                    required=False,
                ),
            ],
            handler=handle_scheduler_restore,
        ),
        category="scheduler",
    )
    
    registry.register_tool(
        Tool(
            name="scheduler_schedule_task",
            description="Schedule a new task with cron expression",
            parameters=[
                create_database_param(),
                ToolParameter(
                    name="task_name",
                    type=ParameterType.STRING,
                    description="Unique name for the task",
                    required=True,
                ),
                ToolParameter(
                    name="cron",
                    type=ParameterType.STRING,
                    description="Cron expression (e.g., '0 2 * * *' for daily at 2 AM)",
                    required=True,
                ),
                ToolParameter(
                    name="command",
                    type=ParameterType.STRING,
                    description="Command to execute",
                    required=True,
                ),
                ToolParameter(
                    name="description",
                    type=ParameterType.STRING,
                    description="Task description",
                    required=False,
                ),
            ],
            handler=handle_scheduler_schedule_task,
        ),
        category="scheduler",
    )
    
    registry.register_tool(
        Tool(
            name="scheduler_list_tasks",
            description="List all scheduled tasks",
            parameters=[create_database_param()],
            handler=handle_scheduler_list_tasks,
        ),
        category="scheduler",
    )
    
    registry.register_tool(
        Tool(
            name="scheduler_run_now",
            description="Execute a scheduled task immediately",
            parameters=[
                create_database_param(),
                ToolParameter(
                    name="task_id",
                    type=ParameterType.STRING,
                    description="Task ID or name to run",
                    required=True,
                ),
            ],
            handler=handle_scheduler_run_now,
        ),
        category="scheduler",
    )
    
    registry.register_tool(
        Tool(
            name="scheduler_dlq",
            description="Get tasks in the dead letter queue (failed tasks)",
            parameters=[
                create_database_param(),
                ToolParameter(
                    name="status",
                    type=ParameterType.STRING,
                    description="Filter by status (failed, pending)",
                    required=False,
                ),
                ToolParameter(
                    name="limit",
                    type=ParameterType.INTEGER,
                    description="Maximum number of tasks to return",
                    required=False,
                    default=50,
                ),
            ],
            handler=handle_scheduler_dlq,
        ),
        category="scheduler",
    )
    
    registry.register_tool(
        Tool(
            name="scheduler_dlq_retry",
            description="Retry a failed task from the dead letter queue",
            parameters=[
                create_database_param(),
                ToolParameter(
                    name="dlq_id",
                    type=ParameterType.INTEGER,
                    description="DLQ task ID to retry",
                    required=True,
                ),
            ],
            handler=handle_scheduler_dlq_retry,
        ),
        category="scheduler",
    )
    
    registry.register_tool(
        Tool(
            name="scheduler_task_logs",
            description="Get execution logs for a scheduled task",
            parameters=[
                create_database_param(),
                ToolParameter(
                    name="task_id",
                    type=ParameterType.STRING,
                    description="Task ID or name",
                    required=True,
                ),
                ToolParameter(
                    name="limit",
                    type=ParameterType.INTEGER,
                    description="Maximum number of log entries",
                    required=False,
                    default=100,
                ),
            ],
            handler=handle_scheduler_task_logs,
        ),
        category="scheduler",
    )
    
    registry.register_tool(
        Tool(
            name="scheduler_status",
            description="Get current scheduler status and statistics",
            parameters=[create_database_param()],
            handler=handle_scheduler_status,
        ),
        category="scheduler",
    )


# ============================================================================
# SQL Auditor Tools
# ============================================================================

async def handle_auditor_audit_sql(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle SQL auditing requests."""
    database = params["database"]
    sql = params["sql"]
    
    connector = get_connector_for_database(database)
    skill = SQLAuditorSkill(connector)
    
    result = skill.audit_sql(sql)
    skill.close()
    return result


async def handle_auditor_ddl_impact(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle DDL impact analysis requests."""
    database = params["database"]
    ddl_sql = params["ddl_sql"]
    
    connector = get_connector_for_database(database)
    skill = SQLAuditorSkill(connector)
    
    result = skill.analyze_ddl_impact(ddl_sql)
    skill.close()
    return result


async def handle_auditor_optimize(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle SQL optimization requests."""
    database = params["database"]
    sql = params["sql"]
    
    connector = get_connector_for_database(database)
    skill = SQLAuditorSkill(connector)
    
    result = skill.optimize_sql(sql)
    skill.close()
    return result


async def handle_auditor_indexes(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle index recommendation requests."""
    database = params["database"]
    sql = params.get("sql")
    
    connector = get_connector_for_database(database)
    skill = SQLAuditorSkill(connector)
    
    result = skill.recommend_indexes(sql=sql)
    skill.close()
    return result


async def handle_auditor_explain(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle execution plan analysis requests."""
    database = params["database"]
    sql = params["sql"]
    
    connector = get_connector_for_database(database)
    skill = SQLAuditorSkill(connector)
    
    result = skill.analyze_execution_plan(sql)
    skill.close()
    return result


async def handle_auditor_cost_estimate(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle SQL cost estimation requests."""
    database = params["database"]
    sql = params["sql"]
    
    connector = get_connector_for_database(database)
    skill = SQLAuditorSkill(connector)
    
    result = skill.estimate_cost(sql)
    skill.close()
    return result


async def handle_auditor_rules(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle audit rules listing requests."""
    database = params["database"]
    
    connector = get_connector_for_database(database)
    skill = SQLAuditorSkill(connector)
    
    result = skill.get_rules()
    skill.close()
    return result


async def handle_auditor_report(params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle audit report generation requests."""
    database = params["database"]
    sql_list = params.get("sql_list")
    
    connector = get_connector_for_database(database)
    skill = SQLAuditorSkill(connector)
    
    if sql_list:
        result = skill.generate_report(sql_list=sql_list)
    else:
        result = skill.generate_report()
    skill.close()
    return result


def register_auditor_tools(registry: ToolRegistry) -> None:
    """Register all SQL auditor tools."""
    logger.info("Registering SQL auditor tools")
    
    registry.register_tool(
        Tool(
            name="auditor_audit_sql",
            description="Audit a SQL statement against security and performance rules",
            parameters=[
                create_database_param(),
                ToolParameter(
                    name="sql",
                    type=ParameterType.STRING,
                    description="SQL statement to audit",
                    required=True,
                ),
            ],
            handler=handle_auditor_audit_sql,
        ),
        category="auditor",
    )
    
    registry.register_tool(
        Tool(
            name="auditor_ddl_impact",
            description="Analyze the impact of DDL changes on existing queries",
            parameters=[
                create_database_param(),
                ToolParameter(
                    name="ddl_sql",
                    type=ParameterType.STRING,
                    description="DDL statement to analyze (ALTER, CREATE, DROP)",
                    required=True,
                ),
            ],
            handler=handle_auditor_ddl_impact,
        ),
        category="auditor",
    )
    
    registry.register_tool(
        Tool(
            name="auditor_optimize",
            description="Get optimization suggestions for a SQL statement",
            parameters=[
                create_database_param(),
                ToolParameter(
                    name="sql",
                    type=ParameterType.STRING,
                    description="SQL statement to optimize",
                    required=True,
                ),
            ],
            handler=handle_auditor_optimize,
        ),
        category="auditor",
    )
    
    registry.register_tool(
        Tool(
            name="auditor_indexes",
            description="Recommend indexes based on query patterns",
            parameters=[
                create_database_param(),
                ToolParameter(
                    name="sql",
                    type=ParameterType.STRING,
                    description="SQL query to analyze for index recommendations",
                    required=False,
                ),
            ],
            handler=handle_auditor_indexes,
        ),
        category="auditor",
    )
    
    registry.register_tool(
        Tool(
            name="auditor_explain",
            description="Analyze SQL execution plan and identify bottlenecks",
            parameters=[
                create_database_param(),
                ToolParameter(
                    name="sql",
                    type=ParameterType.STRING,
                    description="SQL statement to analyze",
                    required=True,
                ),
            ],
            handler=handle_auditor_explain,
        ),
        category="auditor",
    )
    
    registry.register_tool(
        Tool(
            name="auditor_cost",
            description="Estimate the computational cost of a SQL statement",
            parameters=[
                create_database_param(),
                ToolParameter(
                    name="sql",
                    type=ParameterType.STRING,
                    description="SQL statement to estimate cost",
                    required=True,
                ),
            ],
            handler=handle_auditor_cost_estimate,
        ),
        category="auditor",
    )
    
    registry.register_tool(
        Tool(
            name="auditor_rules",
            description="List all available SQL audit rules",
            parameters=[create_database_param()],
            handler=handle_auditor_rules,
        ),
        category="auditor",
    )
    
    registry.register_tool(
        Tool(
            name="auditor_report",
            description="Generate a comprehensive SQL audit report",
            parameters=[
                create_database_param(),
                ToolParameter(
                    name="sql_list",
                    type=ParameterType.ARRAY,
                    description="List of SQL statements to audit",
                    required=False,
                ),
            ],
            handler=handle_auditor_report,
        ),
        category="auditor",
    )


def create_tool_registry() -> ToolRegistry:
    """
    Create and populate the tool registry with all available tools.
    
    Returns:
        Configured ToolRegistry with all DBSKiter tools registered
    """
    registry = ToolRegistry()
    
    register_diagnose_tools(registry)
    register_monitor_tools(registry)
    register_sql_tools(registry)
    register_security_tools(registry)
    register_inspector_tools(registry)
    register_lock_tools(registry)
    register_scheduler_tools(registry)
    register_auditor_tools(registry)
    
    logger.info(f"Tool registry created with {len(registry.list_tools())} tools")
    return registry
