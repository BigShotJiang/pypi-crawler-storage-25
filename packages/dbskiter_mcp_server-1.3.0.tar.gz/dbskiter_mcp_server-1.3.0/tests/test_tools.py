"""
Tests for MCP Tools

This module contains unit tests for the tool registry and tool handlers.

Version: 1.0.0
Author: DBSKiter Team
"""

import pytest
from dbskiter_mcp.tools import (
    ToolRegistry,
    Tool,
    ToolParameter,
    ParameterType,
    create_tool_registry,
    create_database_param,
    create_limit_param,
)


class TestToolParameter:
    """Test cases for ToolParameter class."""
    
    def test_to_dict_basic(self):
        """Test basic parameter serialization."""
        param = ToolParameter(
            name="test",
            type=ParameterType.STRING,
            description="Test parameter",
        )
        
        result = param.to_dict()
        
        assert result["type"] == "string"
        assert result["description"] == "Test parameter"
        assert "required" not in result
    
    def test_to_dict_required(self):
        """Test required parameter serialization."""
        param = ToolParameter(
            name="test",
            type=ParameterType.STRING,
            description="Test parameter",
            required=True,
        )
        
        result = param.to_dict()
        
        assert result["required"] is True
    
    def test_to_dict_with_default(self):
        """Test parameter with default value."""
        param = ToolParameter(
            name="limit",
            type=ParameterType.INTEGER,
            description="Result limit",
            default=10,
        )
        
        result = param.to_dict()
        
        assert result["default"] == 10
    
    def test_to_dict_with_enum(self):
        """Test parameter with enum values."""
        param = ToolParameter(
            name="mode",
            type=ParameterType.STRING,
            description="Operation mode",
            enum=["fast", "normal", "thorough"],
        )
        
        result = param.to_dict()
        
        assert result["enum"] == ["fast", "normal", "thorough"]


class TestTool:
    """Test cases for Tool class."""
    
    def test_to_dict(self):
        """Test tool serialization."""
        tool = Tool(
            name="test_tool",
            description="A test tool",
            parameters=[
                ToolParameter(
                    name="input",
                    type=ParameterType.STRING,
                    description="Input value",
                    required=True,
                ),
            ],
        )
        
        result = tool.to_dict()
        
        assert result["name"] == "test_tool"
        assert result["description"] == "A test tool"
        assert "input" in result["parameters"]
    
    def test_validate_params_missing_required(self):
        """Test validation with missing required parameter."""
        tool = Tool(
            name="test",
            description="Test",
            parameters=[
                ToolParameter(
                    name="required_param",
                    type=ParameterType.STRING,
                    description="Required",
                    required=True,
                ),
            ],
        )
        
        valid, error = tool.validate_params({})
        
        assert valid is False
        assert "Missing required parameter" in error
    
    def test_validate_params_wrong_type(self):
        """Test validation with wrong parameter type."""
        tool = Tool(
            name="test",
            description="Test",
            parameters=[
                ToolParameter(
                    name="count",
                    type=ParameterType.INTEGER,
                    description="Count",
                ),
            ],
        )
        
        valid, error = tool.validate_params({"count": "not_a_number"})
        
        assert valid is False
        assert "must be an integer" in error
    
    def test_validate_params_valid(self):
        """Test validation with valid parameters."""
        tool = Tool(
            name="test",
            description="Test",
            parameters=[
                ToolParameter(
                    name="name",
                    type=ParameterType.STRING,
                    description="Name",
                    required=True,
                ),
                ToolParameter(
                    name="count",
                    type=ParameterType.INTEGER,
                    description="Count",
                    required=False,
                    default=10,
                ),
            ],
        )
        
        valid, error = tool.validate_params({"name": "test", "count": 5})
        
        assert valid is True
        assert error is None
    
    def test_validate_params_enum(self):
        """Test validation with enum constraint."""
        tool = Tool(
            name="test",
            description="Test",
            parameters=[
                ToolParameter(
                    name="mode",
                    type=ParameterType.STRING,
                    description="Mode",
                    enum=["a", "b", "c"],
                ),
            ],
        )
        
        valid, error = tool.validate_params({"mode": "d"})
        
        assert valid is False
        assert "must be one of" in error


class TestToolRegistry:
    """Test cases for ToolRegistry class."""
    
    def test_register_tool(self):
        """Test tool registration."""
        registry = ToolRegistry()
        tool = Tool(name="test", description="Test tool")
        
        registry.register_tool(tool)
        
        assert registry.get_tool("test") is not None
    
    def test_register_duplicate_tool(self):
        """Test registering duplicate tool name raises error."""
        registry = ToolRegistry()
        tool = Tool(name="test", description="Test tool")
        
        registry.register_tool(tool)
        
        with pytest.raises(ValueError, match="already exists"):
            registry.register_tool(tool)
    
    def test_register_tool_with_category(self):
        """Test tool registration with category."""
        registry = ToolRegistry()
        tool = Tool(name="test", description="Test tool")
        
        registry.register_tool(tool, category="diagnose")
        
        tools = registry.list_tools(category="diagnose")
        assert len(tools) == 1
        assert tools[0].name == "test"
    
    def test_list_all_tools(self):
        """Test listing all tools."""
        registry = ToolRegistry()
        registry.register_tool(Tool(name="tool1", description="Tool 1"))
        registry.register_tool(Tool(name="tool2", description="Tool 2"))
        
        tools = registry.list_tools()
        
        assert len(tools) == 2
    
    def test_list_categories(self):
        """Test listing categories."""
        registry = ToolRegistry()
        registry.register_tool(Tool(name="t1", description="T1"), category="cat1")
        registry.register_tool(Tool(name="t2", description="T2"), category="cat2")
        
        categories = registry.list_categories()
        
        assert "cat1" in categories
        assert "cat2" in categories
    
    def test_get_nonexistent_tool(self):
        """Test getting a tool that doesn't exist."""
        registry = ToolRegistry()
        
        result = registry.get_tool("nonexistent")
        
        assert result is None
    
    @pytest.mark.asyncio
    async def test_execute_nonexistent_tool(self):
        """Test executing a tool that doesn't exist."""
        registry = ToolRegistry()
        
        result = await registry.execute("nonexistent", {})
        
        assert result["success"] is False
        assert "not found" in result["error"]
    
    @pytest.mark.asyncio
    async def test_execute_invalid_params(self):
        """Test executing with invalid parameters."""
        registry = ToolRegistry()
        tool = Tool(
            name="test",
            description="Test",
            parameters=[
                ToolParameter(
                    name="required",
                    type=ParameterType.STRING,
                    description="Required param",
                    required=True,
                ),
            ],
        )
        registry.register_tool(tool)
        
        result = await registry.execute("test", {})
        
        assert result["success"] is False
        assert "Missing required parameter" in result["error"]
    
    @pytest.mark.asyncio
    async def test_execute_no_handler(self):
        """Test executing tool without handler."""
        registry = ToolRegistry()
        tool = Tool(name="test", description="Test")
        registry.register_tool(tool)
        
        result = await registry.execute("test", {})
        
        assert result["success"] is False
        assert "no handler" in result["error"]
    
    @pytest.mark.asyncio
    async def test_execute_success(self):
        """Test successful tool execution."""
        registry = ToolRegistry()
        
        async def handler(params):
            return {"result": "success", "input": params.get("value")}
        
        tool = Tool(
            name="test",
            description="Test",
            parameters=[],
            handler=handler,
        )
        registry.register_tool(tool)
        
        result = await registry.execute("test", {"value": "hello"})
        
        assert result["success"] is True
        assert result["data"]["result"] == "success"


class TestHelperFunctions:
    """Test cases for helper functions."""
    
    def test_create_database_param(self):
        """Test database parameter creation."""
        param = create_database_param(required=True)
        
        assert param.name == "database"
        assert param.type == ParameterType.STRING
        assert param.required is True
    
    def test_create_limit_param(self):
        """Test limit parameter creation."""
        param = create_limit_param(default=20)
        
        assert param.name == "limit"
        assert param.type == ParameterType.INTEGER
        assert param.default == 20
        assert param.required is False


class TestCreateToolRegistry:
    """Test cases for create_tool_registry function."""
    
    def test_registry_created(self):
        """Test that registry is created with tools."""
        registry = create_tool_registry()
        
        assert len(registry.list_tools()) > 0
    
    def test_diagnose_tools_registered(self):
        """Test that diagnose tools are registered."""
        registry = create_tool_registry()
        
        tools = registry.list_tools(category="diagnose")
        assert len(tools) > 0
        
        tool_names = [t.name for t in tools]
        assert "diagnose_realtime" in tool_names
        assert "diagnose_sql" in tool_names
    
    def test_monitor_tools_registered(self):
        """Test that monitor tools are registered."""
        registry = create_tool_registry()
        
        tools = registry.list_tools(category="monitor")
        assert len(tools) > 0
        
        tool_names = [t.name for t in tools]
        assert "monitor_health" in tool_names
    
    def test_sql_tools_registered(self):
        """Test that SQL tools are registered."""
        registry = create_tool_registry()
        
        tools = registry.list_tools(category="sql")
        assert len(tools) > 0
        
        tool_names = [t.name for t in tools]
        assert "sql_execute" in tool_names
    
    def test_security_tools_registered(self):
        """Test that security tools are registered."""
        registry = create_tool_registry()
        
        tools = registry.list_tools(category="security")
        assert len(tools) > 0
        
        tool_names = [t.name for t in tools]
        assert "security_score" in tool_names
