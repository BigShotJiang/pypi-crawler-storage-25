# DBSKiter MCP Server

A Model Context Protocol (MCP) server that exposes DBSKiter database skills to AI assistants.

## Overview

DBSKiter MCP Server provides AI assistants with powerful database monitoring, diagnosis, SQL optimization, and security auditing capabilities through the Model Context Protocol. It exposes 74 tools across 8 categories.

## Features

### Diagnose Tools (12)

Performance diagnosis and analysis tools.

| Tool | Description |
|------|-------------|
| diagnose_realtime | Real-time database performance diagnosis |
| diagnose_sql | SQL statement analysis with execution plan |
| diagnose_slow_queries | Slow query analysis |
| diagnose_table | Table-level diagnosis |
| diagnose_bottleneck | Performance bottleneck analysis |
| diagnose_space | Tablespace usage analysis |
| diagnose_connections | Connection analysis |
| diagnose_replication | Replication status analysis |
| diagnose_bloat | Table bloat and fragmentation analysis |
| diagnose_index_usage | Index usage analysis |
| diagnose_vacuum | Vacuum requirements analysis |
| diagnose_indexes | Index recommendations |

### Monitor Tools (9)

Health monitoring and capacity planning.

| Tool | Description |
|------|-------------|
| monitor_health | Database health checks |
| monitor_metrics | Performance metrics collection |
| monitor_anomalies | Anomaly detection |
| monitor_capacity | Capacity prediction |
| monitor_trend | Trend analysis |
| monitor_history | Historical metric data |
| monitor_alerts | Alert retrieval |
| monitor_baseline | Baseline comparison |
| monitor_degradation | Performance degradation detection |

### SQL Tools (9)

SQL execution and data management.

| Tool | Description |
|------|-------------|
| sql_execute | Execute SQL statements |
| sql_rewrite | SQL optimization and rewriting |
| sql_batch | Batch SQL execution |
| sql_export | Export data to CSV/JSON/SQL |
| sql_import | Import data from file |
| sql_audit | SQL execution audit records |
| sql_quality | SQL quality analysis |
| sql_schema | Table schema information |
| sql_tables | List all tables |

### Security Tools (12)

Security auditing and compliance.

| Tool | Description |
|------|-------------|
| security_sql_injection | SQL injection detection |
| security_score | Database security scoring |
| security_sensitive_data | Sensitive data scanning |
| security_permissions | Permission auditing |
| security_config | Configuration auditing |
| security_audit | Comprehensive security audit |
| security_password_policy | Password policy checking |
| security_weak_passwords | Weak password detection |
| security_login | Login security checking |
| security_high_risk | High risk operation detection |
| security_compliance | Compliance checking |
| security_audit_log | Audit log analysis |

### Inspector Tools (8)

Intelligent inspection and analysis.

| Tool | Description |
|------|-------------|
| inspector_inspect | Comprehensive inspection |
| inspector_intelligent | AI-powered intelligent inspection |
| inspector_anomalies | Anomaly detection |
| inspector_root_cause | Root cause analysis |
| inspector_risks | Risk prediction |
| inspector_baseline_create | Performance baseline creation |
| inspector_baseline_compare | Baseline comparison |
| inspector_top_issues | Top issues retrieval |

### Lock Analyzer Tools (6)

Lock analysis and deadlock detection.

| Tool | Description |
|------|-------------|
| lock_analyze | Current lock analysis |
| lock_deadlocks | Deadlock detection |
| lock_chains | Lock wait chain tracing |
| lock_statistics | Lock statistics |
| lock_report | Lock analysis report |
| lock_kill_transaction | Blocking transaction termination |

### Scheduler Tools (10)

Backup, scheduling, and task management.

| Tool | Description |
|------|-------------|
| scheduler_backup | Database backup |
| scheduler_list_backups | List available backups |
| scheduler_restore | Backup restoration |
| scheduler_schedule_task | Task scheduling |
| scheduler_list_tasks | List scheduled tasks |
| scheduler_run_now | Immediate task execution |
| scheduler_dlq | Dead letter queue tasks |
| scheduler_dlq_retry | DLQ task retry |
| scheduler_task_logs | Task execution logs |
| scheduler_status | Scheduler status |

### Auditor Tools (8)

SQL audit and quality analysis.

| Tool | Description |
|------|-------------|
| auditor_audit_sql | SQL statement auditing |
| auditor_ddl_impact | DDL impact analysis |
| auditor_optimize | SQL optimization |
| auditor_indexes | Index recommendations |
| auditor_explain | Execution plan analysis |
| auditor_cost | Cost estimation |
| auditor_rules | Audit rules listing |
| auditor_report | Audit report generation |

## Installation

```bash
pip install dbskiter-mcp-server
```

## Configuration

### Environment Variables

Create a `.env` file with your database connections:

```env
# MySQL Example
DB_DIALECT=mysql
DB_HOST=localhost
DB_PORT=3306
DB_USER=root
DB_PASSWORD=your_password
DB_NAME=your_database

# Oracle Example
ORACLE_DIALECT=oracle+oracledb
ORACLE_HOST=localhost
ORACLE_PORT=1521
ORACLE_USER=system
ORACLE_PASSWORD=your_password
ORACLE_SERVICE_NAME=ORCL
```

### Claude Desktop Configuration

Add to your Claude Desktop configuration (`claude_desktop_config.json`):

```json
{
  "mcpServers": {
    "dbskiter": {
      "command": "dbskiter-mcp",
      "env": {
        "DB_DIALECT": "mysql",
        "DB_HOST": "localhost",
        "DB_PORT": "3306",
        "DB_USER": "root",
        "DB_PASSWORD": "your_password",
        "DB_NAME": "your_database"
      }
    }
  }
}
```

## Usage

### Running the Server

```bash
# Run directly
dbskiter-mcp

# Or with Python
python -m dbskiter_mcp
```

### Using with Claude

Once configured, you can ask Claude to:

- "Check the health of my database"
- "Analyze this slow SQL query"
- "Show me the top 10 slow queries"
- "Execute this SQL: SELECT COUNT(*) FROM orders"
- "Run a comprehensive security audit"
- "Detect any deadlocks in my database"
- "List all scheduled tasks and their status"
- "Predict my disk space usage for the next 30 days"

## Development

### Prerequisites

- Python 3.10+
- dbskiter >= 2.1.0

### Building from Source

```bash
# Clone the repository
git clone https://github.com/magicCzc/dbskiter-mcp-server.git
cd dbskiter-mcp-server

# Install development dependencies
pip install -e ".[dev]"

# Run tests
pytest tests/

# Build package
python -m build
```

## License

MIT License

## Author

MagiCzc - magiczc@139.com
