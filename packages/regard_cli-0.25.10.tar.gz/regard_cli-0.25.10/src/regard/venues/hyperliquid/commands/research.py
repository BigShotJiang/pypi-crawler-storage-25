"""Research commands — assets, prices, book, funding, candles."""

import time
from typing import Annotated

import typer

from regard.core.output import (
    bar,
    die,
    format_timestamp,
    interval_to_ms,
    make_table,
    output,
    parse_time,
    sparkline,
)
from regard.main import hypercore_app
from regard.venues.hyperliquid.client import (
    _validate,
    dex_name_from_universe,
    get_all_mids,
    get_all_perp_metas,
    get_info,
    get_perp_annotations,
)
from regard.venues.hyperliquid.models import Candle, FundingEntry, L2Snapshot
from regard.venues.hyperliquid.outcomes import decode_coin
from regard.venues.hyperliquid.resolver import get_resolver


@hypercore_app.command()
def assets(
    ctx: typer.Context,
    query: Annotated[str | None, typer.Argument(help="Search by name")] = None,
    deployer: Annotated[str | None, typer.Option("--deployer", help="Filter by deployer")] = None,
    sort: Annotated[str, typer.Option("--sort", help="Sort: volume|oi|name")] = "volume",
):
    """List and search all tradeable perps."""
    opts = ctx.obj
    info = get_info(opts["testnet"])

    # Default perps with full context (volume, OI, funding, etc.)
    meta_ctxs = info.meta_and_asset_ctxs()
    meta = meta_ctxs[0]
    ctxs = meta_ctxs[1]

    result = []
    for i, (asset_info, asset_ctx) in enumerate(zip(meta["universe"], ctxs)):
        if asset_info.get("isDelisted"):
            continue
        result.append({
            "asset": asset_info["name"],
            "asset_id": i,
            "max_leverage": asset_info.get("maxLeverage", 0),
            "sz_decimals": asset_info.get("szDecimals", 0),
            "mark_price": asset_ctx.get("markPx", ""),
            "funding_rate": asset_ctx.get("funding", ""),
            "open_interest": asset_ctx.get("openInterest", ""),
            "volume_24h": asset_ctx.get("dayNtlVlm", ""),
        })

    # HIP-3 assets via allPerpMetas (saves perpDexs call)
    try:
        all_metas = get_all_perp_metas(info)
        mids = get_all_mids(info)

        for idx, dex_meta_entry in enumerate(all_metas[1:]):
            dex_name = dex_name_from_universe(dex_meta_entry.get("universe", []))
            if not dex_name:
                continue
            try:
                # Try metaAndAssetCtxs with dex param for full data
                dex_data = info.post("/info", {"type": "metaAndAssetCtxs", "dex": dex_name})
                dex_meta = dex_data[0]
                dex_ctxs = dex_data[1]
                offset = 110000 + idx * 10000

                for j, (ai, ac) in enumerate(zip(dex_meta["universe"], dex_ctxs)):
                    if ai.get("isDelisted"):
                        continue
                    name = ai["name"]
                    result.append({
                        "asset": name,
                        "asset_id": j + offset,
                        "deployer": dex_name,
                        "max_leverage": ai.get("maxLeverage", 0),
                        "sz_decimals": ai.get("szDecimals", 0),
                        "mark_price": ac.get("markPx", mids.get(name, "")),
                        "funding_rate": ac.get("funding", ""),
                        "open_interest": ac.get("openInterest", ""),
                        "volume_24h": ac.get("dayNtlVlm", ""),
                    })
            except Exception:
                # Fallback: use meta from allPerpMetas + all_mids for price
                for ai in dex_meta_entry.get("universe", []):
                    if ai.get("isDelisted"):
                        continue
                    name = ai["name"]
                    result.append({
                        "asset": name,
                        "deployer": dex_name,
                        "max_leverage": ai.get("maxLeverage", 0),
                        "sz_decimals": ai.get("szDecimals", 0),
                        "mark_price": mids.get(name, ""),
                        "funding_rate": "",
                        "open_interest": "",
                        "volume_24h": "",
                    })
    except Exception:
        pass  # no HIP-3 data available

    # Filter
    if query:
        q = query.upper()
        result = [a for a in result if q in a["asset"].upper()]
    if deployer:
        result = [a for a in result if a.get("deployer", "") == deployer]

    # Sort
    sort_key = {"volume": "volume_24h", "oi": "open_interest", "name": "asset"}.get(sort, "volume_24h")
    if sort_key == "asset":
        result.sort(key=lambda x: x["asset"])
    else:
        result.sort(key=lambda x: float(x.get(sort_key) or "0"), reverse=True)

    output(result, opts["fields"], display=_display_assets(result))


@hypercore_app.command()
def prices(
    ctx: typer.Context,
    assets: Annotated[list[str] | None, typer.Argument(help="Asset names")] = None,
):
    """Current prices."""
    opts = ctx.obj
    info = get_info(opts["testnet"])

    if not assets:
        # Lightweight: all mid prices (including HIP-3)
        mids = get_all_mids(info)
        result = [{"asset": k, "mid": v} for k, v in sorted(mids.items()) if not k.startswith("@")]
        display = make_table(result, [("asset", "Asset", "<"), ("mid", "Mid", ">")])
        output(result, opts["fields"], display=display)
        return

    # Detailed: per-asset info
    resolver = get_resolver(info)
    mids = get_all_mids(info)

    # Build context + meta lookup from default perps + HIP-3 dexes
    meta_ctxs = info.meta_and_asset_ctxs()
    ctx_lookup = {}
    meta_lookup = {}
    for asset_info, asset_ctx in zip(meta_ctxs[0]["universe"], meta_ctxs[1]):
        ctx_lookup[asset_info["name"]] = asset_ctx
        meta_lookup[asset_info["name"]] = asset_info

    # Load HIP-3 context for any HIP-3 assets requested
    hip3_dexes_needed = set()
    for name in assets:
        resolved = resolver.resolve(name)
        if ":" in resolved and resolved not in ctx_lookup:
            hip3_dexes_needed.add(resolved.split(":")[0])
    for dex in hip3_dexes_needed:
        try:
            dex_data = info.post("/info", {"type": "metaAndAssetCtxs", "dex": dex})
            for ai, ac in zip(dex_data[0]["universe"], dex_data[1]):
                ctx_lookup[ai["name"]] = ac
                meta_lookup[ai["name"]] = ai
        except Exception:
            pass

    result = []
    for name in assets:
        resolved = resolver.resolve(name)
        ac = ctx_lookup.get(resolved, {})
        ai = meta_lookup.get(resolved, {})
        mid = mids.get(resolved, "")
        prev = ac.get("prevDayPx", "")
        change = ""
        if mid and prev:
            try:
                change = f"{(float(mid) / float(prev) - 1) * 100:.2f}"
            except (ValueError, ZeroDivisionError):
                pass
        result.append({
            "asset": resolved,
            "mid": mid,
            "mark": ac.get("markPx", mid),
            "oracle": ac.get("oraclePx", ""),
            "prev_day": prev,
            "change_pct": change,
            "sz_decimals": ai.get("szDecimals", 0),
        })

    display = _display_prices(result)
    output(result, opts["fields"], display=display)


@hypercore_app.command()
def book(
    ctx: typer.Context,
    asset: Annotated[str, typer.Argument(help="Asset name")],
    depth: Annotated[int, typer.Option("--depth", help="Levels per side (max 20)")] = 5,
):
    """Order book depth."""
    opts = ctx.obj
    info = get_info(opts["testnet"])
    resolver = get_resolver(info)
    resolved = resolver.resolve(asset)

    snapshot = info.l2_snapshot(resolved)
    _validate(L2Snapshot, snapshot, "l2_snapshot")
    levels = snapshot.get("levels", [[], []])

    bids = [{"price": lv["px"], "size": lv["sz"], "orders": lv["n"]} for lv in levels[0][:depth]]
    asks = [{"price": lv["px"], "size": lv["sz"], "orders": lv["n"]} for lv in levels[1][:depth]]

    result = {"asset": resolved, "bids": bids, "asks": asks}
    output(result, opts["fields"], display=_display_book(result))


# ---------------------------------------------------------------------------
# HIP-4 outcome markets
# ---------------------------------------------------------------------------


def _parse_outcome_id_arg(arg: str) -> tuple[int, int | None]:
    """Parse `regard hypercore outcome <id>` argument into `(outcome, side_or_none)`.

    Three accepted forms (per Constitutional alignment §I):
      `#<encoding>`     → e.g. `#10` → (1, 0); `#59150` → (5915, 0)
      `<outcome>:<side>`→ e.g. `5915:0`, `5915:yes`, `5915:no`, `5915:1`
      `<outcome>`       → bare integer, returns (5915, None) — caller shows BOTH sides

    Calls `die()` with `validation_error / INVALID_OUTCOME_ID` on malformed input.
    No silent picks; ambiguous future short-name forms surface
    `AMBIGUOUS_OUTCOME` (reserved code, used when underlying-aliasing lands).
    """
    arg = arg.strip()
    if not arg:
        die(
            "validation_error", "INVALID_OUTCOME_ID", "Outcome id is empty",
            hint="Use `#<encoding>` (e.g. #59150), `<outcome>:<side>` (e.g. 5915:yes), or `<outcome>` (e.g. 5915 — shows both sides)",
        )

    # Form 1: `#<encoding>` — defer to the canonical decoder.
    if arg.startswith("#"):
        decoded = decode_coin(arg)
        if decoded is None:
            die(
                "validation_error", "INVALID_OUTCOME_ID",
                f"Malformed outcome coin: {arg}",
                hint="Outcome coins are `#<integer>` like #59150 — ASCII digits only, no leading zeros",
            )
        _outcome_int, side_int = decoded
        # Phase 1 supports only binary outcomes (sides 0/1). Categorical
        # markets (>2 sides per market) are mainnet-deferred per brief §1.
        # Without this check, `#12` (outcome=1, side=2) would parse silently
        # and the outcome command would emit `{ok:true, implied_total:null}`
        # with no yes/no keys — agent can't distinguish from a thin market.
        if side_int not in (0, 1):
            die(
                "validation_error", "INVALID_OUTCOME_ID",
                f"Outcome coin {arg} encodes side {side_int}; only binary outcomes (sides 0/1) are supported",
                hint="Categorical multi-outcome markets are not yet enabled on mainnet",
            )
        return decoded

    # Form 2: `<outcome>:<side>`
    if ":" in arg:
        outcome_str, _, side_str = arg.partition(":")
        try:
            outcome = int(outcome_str)
        except ValueError:
            die(
                "validation_error", "INVALID_OUTCOME_ID",
                f"Outcome must be an integer, got {outcome_str!r}",
                hint="Use `<outcome>:<side>` like `5915:yes` or `5915:0`",
            )
        if outcome < 0:
            die(
                "validation_error", "INVALID_OUTCOME_ID",
                f"Outcome must be non-negative: {outcome}",
            )
        side_norm = side_str.strip().lower()
        if side_norm in ("0", "yes", "y"):
            return (outcome, 0)
        if side_norm in ("1", "no", "n"):
            return (outcome, 1)
        die(
            "validation_error", "INVALID_OUTCOME_ID",
            f"Side must be 0/yes/y or 1/no/n, got {side_str!r}",
            hint="Try `5915:yes` or `5915:no`",
        )

    # Form 3: bare `<outcome>` integer
    try:
        outcome = int(arg)
    except ValueError:
        die(
            "validation_error", "INVALID_OUTCOME_ID",
            f"Bare outcome must be an integer, got {arg!r}",
            hint="Use `#<encoding>`, `<outcome>:<side>`, or `<outcome>`",
        )
    if outcome < 0:
        die(
            "validation_error", "INVALID_OUTCOME_ID",
            f"Outcome must be non-negative: {outcome}",
        )
    return (outcome, None)


@hypercore_app.command()
def outcomes(ctx: typer.Context):
    """List HIP-4 outcome markets (metadata only — see `outcome <id>` for live books).

    Output is metadata-only: each entry has the outcome integer, name, parsed
    `description` fields (class / underlying / expiry / target_price / period),
    and both side coins (`#<enc>` for trade form, `+<enc>` for balance form).

    Live mid/book data is intentionally NOT in the list — call
    `regard hypercore outcome <id>` for a single-market view with both books. This
    keeps the list cheap (one network call regardless of market count) and
    matches the metadata-vs-live boundary used elsewhere in the CLI.
    """
    opts = ctx.obj
    info = get_info(opts["testnet"])
    resolver = get_resolver(info)

    raw = resolver.get_outcomes()
    rows = []
    for entry in raw:
        parsed = entry["parsed_description"]
        sides = entry["sides"]
        # Binary outcomes have exactly 2 sides (YES @ index 0, NO @ index 1).
        # Categorical markets (when mainnet enables them) will have more —
        # for now, list view collapses to a binary-shaped row and the
        # `outcome <id>` view is the place to expand.
        yes = sides[0] if len(sides) > 0 else {}
        no = sides[1] if len(sides) > 1 else {}
        rows.append({
            "outcome": entry["outcome"],
            "name": entry["name"],
            "class": parsed.get("class"),
            "underlying": parsed.get("underlying"),
            "expiry": parsed.get("expiry"),
            "target_price": parsed.get("target_price"),  # string per Article I
            "period": parsed.get("period"),
            "yes_coin": yes.get("coin"),
            "yes_side_name": yes.get("name"),
            "no_coin": no.get("coin"),
            "no_side_name": no.get("name"),
        })
    result = {"outcomes": rows}
    output(result, opts["fields"], display=_display_outcomes(rows))


@hypercore_app.command()
def outcome(
    ctx: typer.Context,
    outcome_id: Annotated[str, typer.Argument(help="Outcome id: #<enc> | <outcome>:<side> | <outcome>")],
    depth: Annotated[int, typer.Option("--depth", help="Levels per book (max 20)")] = 5,
    parity: Annotated[bool, typer.Option("--parity", help="Best-effort match to a Polymarket equivalent + spread")] = False,
):
    """Single HIP-4 outcome market with both YES/NO books.

    `<id>` accepts:
      `#<encoding>`        full coin form (e.g. `#10`, `#59150`)
      `<outcome>:<side>`   specific side (e.g. `5915:yes`, `5915:0`, `5915:no`)
      `<outcome>`          bare integer — returns BOTH sides (recommended)

    `--parity` adds a Polymarket-equivalent lookup (best-effort, themed
    matching by underlying + expiry-window + target-price). Returns
    `parity: null` when no defensible match exists.

    Output is structured: parsed description, YES book, NO book, implied
    probability total (YES_mid + NO_mid, sanity-checks ≈ 1.0). All numeric
    fields are strings per Article I.
    """
    opts = ctx.obj
    info = get_info(opts["testnet"])
    resolver = get_resolver(info)

    parsed_outcome, parsed_side = _parse_outcome_id_arg(outcome_id)
    record = resolver.get_outcome_by_id(parsed_outcome)
    if record is None:
        die(
            "validation_error", "UNKNOWN_OUTCOME",
            f"No outcome with id {parsed_outcome}",
            hint="Run `regard hypercore outcomes` to list all live HIP-4 markets",
        )

    sides_to_show: list[int] = [parsed_side] if parsed_side is not None else [0, 1]

    # Per-side book fetch. For binary (2 sides) this is at most 2 network
    # calls; categorical markets would need pagination, deferred to Phase 4.
    books: dict[str, dict] = {}
    for side_idx in sides_to_show:
        side_record = next(
            (s for s in record["sides"] if s["side"] == side_idx), None
        )
        if side_record is None:
            continue
        coin = side_record["coin"]
        snapshot = info.l2_snapshot(coin)
        _validate(L2Snapshot, snapshot, "l2_snapshot")
        levels = snapshot.get("levels", [[], []])
        bids = [
            {"price": lv["px"], "size": lv["sz"], "orders": lv["n"]}
            for lv in levels[0][:depth]
        ]
        asks = [
            {"price": lv["px"], "size": lv["sz"], "orders": lv["n"]}
            for lv in levels[1][:depth]
        ]
        top_bid = bids[0]["price"] if bids else None
        top_ask = asks[0]["price"] if asks else None
        mid = _mid_or_none(top_bid, top_ask)
        side_label = "yes" if side_idx == 0 else "no"
        books[side_label] = {
            "coin": coin,
            "asset_id": side_record["asset_id"],
            "balance_coin": side_record["balance_coin"],
            "side_name": side_record["name"],
            "top_bid": top_bid,
            "top_ask": top_ask,
            "mid": mid,
            "bids": bids,
            "asks": asks,
        }

    # Implied probability sanity check: yes_mid + no_mid ≈ 1.0. Use Decimal
    # to keep the arithmetic faithful to the string-typed inputs (Article I).
    implied_total = None
    if "yes" in books and "no" in books:
        yes_mid = books["yes"]["mid"]
        no_mid = books["no"]["mid"]
        if yes_mid is not None and no_mid is not None:
            from decimal import Decimal
            implied_total = str(Decimal(yes_mid) + Decimal(no_mid))

    result = {
        "outcome": record["outcome"],
        "name": record["name"],
        "description": record["description"],
        "parsed_description": record["parsed_description"],
        "implied_total": implied_total,
        **books,
    }

    if parity:
        # Best-effort Polymarket lookup. Network failures degrade to
        # parity: null — never raise. Caller treats null as "no match
        # found" rather than "lookup broken".
        from decimal import Decimal as _D

        from regard.venues.polymarket.client import get_gamma_client
        from regard.venues.polymarket.parity import find_polymarket_equivalent
        try:
            gamma = get_gamma_client()
            pm = find_polymarket_equivalent(record, gamma)
        except Exception:
            pm = None

        if pm and "yes" in books and books["yes"]["mid"] is not None:
            try:
                hl_yes = _D(books["yes"]["mid"])
                pm_yes = _D(pm["yes_price"])
                pm["spread_yes"] = str(hl_yes - pm_yes)
            except Exception:
                pm["spread_yes"] = ""
        if pm and "no" in books and books["no"]["mid"] is not None:
            try:
                hl_no = _D(books["no"]["mid"])
                pm_no = _D(pm["no_price"])
                pm["spread_no"] = str(hl_no - pm_no)
            except Exception:
                pm["spread_no"] = ""
        result["parity"] = pm

    output(result, opts["fields"], display=_display_outcome(result))


def _mid_or_none(bid: str | None, ask: str | None) -> str | None:
    """Compute a Decimal-precise mid as a string, or None if either side empty."""
    if bid is None or ask is None:
        return None
    from decimal import Decimal
    try:
        return str((Decimal(bid) + Decimal(ask)) / Decimal(2))
    except Exception:
        return None


@hypercore_app.command()
def funding(
    ctx: typer.Context,
    assets: Annotated[list[str] | None, typer.Argument(help="Asset names")] = None,
    history: Annotated[bool, typer.Option("--history", help="Show historical rates")] = False,
    limit: Annotated[int, typer.Option("--limit", help="Number of periods")] = 20,
    start: Annotated[str | None, typer.Option("--start", help="Start time (ISO 8601)")] = None,
    end: Annotated[str | None, typer.Option("--end", help="End time (ISO 8601)")] = None,
):
    """Funding rates (current or historical)."""
    opts = ctx.obj
    info = get_info(opts["testnet"])

    if history:
        if not assets:
            die("validation_error", "MISSING_ARGUMENT", "Specify at least one asset for --history", hint="regard hypercore funding BTC --history")
        resolver = get_resolver(info)
        result = []
        for name in assets:
            resolved = resolver.resolve(name)
            start_ms = parse_time(start) if start else int(time.time() * 1000) - limit * 8 * 3600 * 1000
            end_ms = parse_time(end) if end else None
            data = info.funding_history(resolved, start_ms, end_ms)
            for h in data:
                _validate(FundingEntry, h, "funding")
            for h in data[-limit:]:
                rate = h.get("fundingRate", "0")
                result.append({
                    "asset": resolved,
                    "rate": rate,
                    "premium": h.get("premium", ""),
                    "annualized": f"{float(rate) * 3 * 365:.2f}",
                    "time": format_timestamp(h.get("time", 0)),
                })
        output(result, opts["fields"], display=_display_funding_history(result))
    else:
        # Current rates from metaAndAssetCtxs across all dexes
        asset_filter = {a.upper() for a in assets} if assets else None
        result = []

        # Default perps
        meta_ctxs = info.meta_and_asset_ctxs()
        for asset_info, asset_ctx in zip(meta_ctxs[0]["universe"], meta_ctxs[1]):
            if asset_info.get("isDelisted"):
                continue
            name = asset_info["name"]
            if asset_filter and name.upper() not in asset_filter:
                continue
            rate = asset_ctx.get("funding", "0")
            result.append({
                "asset": name,
                "rate": rate,
                "premium": asset_ctx.get("premium", ""),
                "annualized": f"{float(rate) * 3 * 365:.2f}",
            })

        # HIP-3 dexes
        all_metas = get_all_perp_metas(info)
        for dex_meta in all_metas[1:]:
            dex_name = dex_name_from_universe(dex_meta.get("universe", []))
            if not dex_name:
                continue
            try:
                dex_ctxs = info.post("/info", {"type": "metaAndAssetCtxs", "dex": dex_name})
                for asset_info, asset_ctx in zip(dex_ctxs[0]["universe"], dex_ctxs[1]):
                    if asset_info.get("isDelisted"):
                        continue
                    name = asset_info["name"]
                    if asset_filter and name.upper() not in asset_filter:
                        continue
                    rate = asset_ctx.get("funding", "0")
                    result.append({
                        "asset": name,
                        "rate": rate,
                        "premium": asset_ctx.get("premium", ""),
                        "annualized": f"{float(rate) * 3 * 365:.2f}",
                    })
            except Exception:
                continue

        output(result, opts["fields"], display=_display_funding(result))


@hypercore_app.command()
def candles(
    ctx: typer.Context,
    asset: Annotated[str, typer.Argument(help="Asset name")],
    interval: Annotated[str, typer.Argument(help="1m 5m 15m 1h 4h 1d etc.")],
    limit: Annotated[int, typer.Option("--limit", help="Number of candles (max 5000)")] = 100,
    start: Annotated[str | None, typer.Option("--start", help="Start time (ISO 8601)")] = None,
    end: Annotated[str | None, typer.Option("--end", help="End time (ISO 8601)")] = None,
):
    """OHLCV price history."""
    opts = ctx.obj
    info = get_info(opts["testnet"])
    resolver = get_resolver(info)
    resolved = resolver.resolve(asset)

    end_ms = parse_time(end) if end else int(time.time() * 1000)
    if start:
        start_ms = parse_time(start)
    else:
        ms_per = interval_to_ms(interval)
        start_ms = end_ms - ms_per * limit

    data = info.candles_snapshot(resolved, interval, start_ms, end_ms)
    output_slice = data[-limit:]
    for c in output_slice:
        _validate(Candle, c, "candle")

    result = []
    for c in output_slice:
        result.append({
            "time": format_timestamp(c["t"]),
            "open": c["o"],
            "high": c["h"],
            "low": c["l"],
            "close": c["c"],
            "volume": c["v"],
            "trades": c["n"],
        })

    closes = [float(r["close"]) for r in result]
    spark = sparkline(closes)
    last = result[-1] if result else {}
    summary = f"{resolved}  {spark}  {last.get('close', '')}  ({interval}, {len(result)} candles)"
    output(result, opts["fields"], display=summary)


def _build_pulse_asset(name: str, asset_ctx: dict, category: str = "crypto") -> dict:
    """Build a pulse asset dict from API context data."""
    mid = asset_ctx.get("markPx", "")
    prev = asset_ctx.get("prevDayPx", "")
    change_pct = ""
    if mid and prev:
        try:
            change_pct = f"{(float(mid) / float(prev) - 1) * 100:.2f}"
        except (ValueError, ZeroDivisionError):
            pass
    rate = asset_ctx.get("funding", "0")
    try:
        ann = f"{float(rate) * 3 * 365:.2f}"
    except (ValueError, TypeError):
        ann = ""
    return {
        "asset": name,
        "asset_class": "crypto" if category == "crypto" else "tradfi",
        "category": category,
        "price": mid,
        "change_24h": change_pct,
        "funding_rate": rate,
        "funding_annualized": ann,
        "volume_24h": asset_ctx.get("dayNtlVlm", ""),
        "open_interest": asset_ctx.get("openInterest", ""),
    }


@hypercore_app.command()
def pulse(
    ctx: typer.Context,
    top: Annotated[int, typer.Option("--top", help="Items per category (0 = all)")] = 10,
):
    """Market pulse — top movers, volume leaders, funding outliers, composite signals. Scans all perps including HIP-3."""
    opts = ctx.obj
    info = get_info(opts["testnet"])

    # Asset categories from API (replaces hardcoded deployer heuristic)
    annotations = get_perp_annotations(info)

    # Default perps (all crypto by definition — not in annotations)
    meta_ctxs = info.meta_and_asset_ctxs()
    meta = meta_ctxs[0]
    ctxs = meta_ctxs[1]

    assets = []
    for asset_info, asset_ctx in zip(meta["universe"], ctxs):
        if asset_info.get("isDelisted"):
            continue
        assets.append(_build_pulse_asset(asset_info["name"], asset_ctx))

    # HIP-3 deployer assets via allPerpMetas (saves perpDexs call, gives collateral info)
    try:
        all_metas = get_all_perp_metas(info)
        for dex_meta in all_metas[1:]:  # skip index 0 (default, already fetched)
            try:
                dex_name = dex_name_from_universe(dex_meta.get("universe", []))
                if not dex_name:
                    continue
                dex_data = info.post("/info", {"type": "metaAndAssetCtxs", "dex": dex_name})
                for ai, ac in zip(dex_data[0]["universe"], dex_data[1]):
                    if ai.get("isDelisted"):
                        continue
                    name = ai["name"]
                    # Annotations use prefixed names (xyz:TSLA); handle both formats
                    ann_key = name if name in annotations else f"{dex_name}:{name}"
                    cat = annotations.get(ann_key, "crypto")
                    assets.append(_build_pulse_asset(name, ac, category=cat))
            except Exception:
                continue
    except Exception:
        pass

    # Sort categories
    movers = sorted(
        [a for a in assets if a["change_24h"]],
        key=lambda x: abs(float(x["change_24h"])),
        reverse=True,
    )

    volume = sorted(
        assets,
        key=lambda x: float(x["volume_24h"] or "0"),
        reverse=True,
    )

    funding = sorted(
        [a for a in assets if a["funding_annualized"]],
        key=lambda x: abs(float(x["funding_annualized"])),
        reverse=True,
    )

    # Composite signals: assets appearing in 2+ of the top-20 lists
    signal_depth = max(top, 20) if top > 0 else len(assets)
    mover_names = {a["asset"] for a in movers[:signal_depth]}
    volume_names = {a["asset"] for a in volume[:signal_depth]}
    funding_names = {a["asset"] for a in funding[:signal_depth]}

    signals = []
    seen = set()
    for a in assets:
        name = a["asset"]
        if name in seen:
            continue
        flags = []
        if name in mover_names:
            flags.append("mover")
        if name in volume_names:
            flags.append("volume")
        if name in funding_names:
            flags.append("funding")
        if len(flags) >= 2:
            signals.append({**a, "flags": flags})
            seen.add(name)

    # Spot markets (no funding, separate lists)
    spot_assets = []
    try:
        spot_data = info.spot_meta_and_asset_ctxs()
        spot_meta = spot_data[0]
        spot_ctxs = spot_data[1]
        tokens = spot_meta["tokens"]
        # CRITICAL: spot_meta["universe"] and spot_ctxs DRIFT in array
        # alignment after array index ~71 on mainnet. zip() silently
        # produces wrong prices for ~223 pairs. Look up ctx by `coin`
        # field instead. (Pre-existing bug fixed in v0.25.6.)
        ctx_by_coin = {c.get("coin"): c for c in spot_ctxs}

        for pair_info in spot_meta["universe"]:
            # Resolve human-readable pair name from token indices
            base_idx, quote_idx = pair_info["tokens"]
            base_name = tokens[base_idx]["name"] if base_idx < len(tokens) else "?"
            quote_name = tokens[quote_idx]["name"] if quote_idx < len(tokens) else "?"
            name = f"{base_name}/{quote_name}"

            sdk_name = pair_info.get("name", "")  # "@107"
            pair_ctx = ctx_by_coin.get(sdk_name) or ctx_by_coin.get(name) or {}
            mid = pair_ctx.get("markPx", "")
            prev = pair_ctx.get("prevDayPx", "")
            change_pct = ""
            if mid and prev:
                try:
                    change_pct = f"{(float(mid) / float(prev) - 1) * 100:.2f}"
                except (ValueError, ZeroDivisionError):
                    pass
            spot_assets.append({
                "asset": name,
                "price": mid,
                "change_24h": change_pct,
                "volume_24h": pair_ctx.get("dayNtlVlm", ""),
            })
    except Exception:
        pass

    # Filter spot movers to pairs with meaningful volume (>$10k/day)
    spot_with_volume = [a for a in spot_assets if float(a["volume_24h"] or "0") > 10000]

    spot_movers = sorted(
        [a for a in spot_with_volume if a["change_24h"]],
        key=lambda x: abs(float(x["change_24h"])),
        reverse=True,
    )

    spot_volume = sorted(
        spot_assets,
        key=lambda x: float(x["volume_24h"] or "0"),
        reverse=True,
    )

    # Apply top limit
    if top > 0:
        movers = movers[:top]
        volume = volume[:top]
        funding = funding[:top]
        spot_movers = spot_movers[:top]
        spot_volume = spot_volume[:top]

    data = {
        "movers": movers,
        "volume": volume,
        "funding": funding,
        "signals": signals,
        "spot_movers": spot_movers,
        "spot_volume": spot_volume,
        "total_assets": len(assets),
        "total_spot_assets": len(spot_assets),
    }
    output(data, opts["fields"], display=_display_pulse(data))


# ---------------------------------------------------------------------------
# Display builders
# ---------------------------------------------------------------------------

def _fmt_vol(v: str) -> str:
    """Format volume as human-readable string (e.g. 914M, 2.3B, 45k)."""
    try:
        n = float(v)
    except (ValueError, TypeError):
        return v
    if n >= 1_000_000_000:
        return f"{n / 1_000_000_000:.1f}B"
    if n >= 1_000_000:
        return f"{n / 1_000_000:.0f}M"
    if n >= 1_000:
        return f"{n / 1_000:.0f}k"
    return f"{n:.0f}"


def _arrow(change: str) -> str:
    """Return ↑/↓ arrow based on sign of change string."""
    try:
        return "↑" if float(change) >= 0 else "↓"
    except (ValueError, TypeError):
        return " "


def _display_assets(assets: list[dict]) -> str:
    if not assets:
        return "No assets found"
    lines = []
    for a in assets:
        vol = _fmt_vol(a.get("volume_24h", ""))
        lines.append(f"  {a['asset']:<16} {a.get('mark_price', ''):>12}  vol {vol:>6}  {a.get('max_leverage', '')}x")
    return "\n".join(lines)


def _display_prices(prices: list[dict]) -> str:
    if not prices:
        return "No prices"
    # Build display rows without mutating input
    display_rows = []
    for p in prices:
        c = p.get("change_pct", "")
        display_rows.append({
            "asset": p.get("asset", ""),
            "mid": p.get("mid", ""),
            "mark": p.get("mark", ""),
            "change": f"{_arrow(c)}{c}%" if c else "",
        })
    cols = [
        ("asset", "Asset", "<"),
        ("mid", "Mid", ">"),
        ("mark", "Mark", ">"),
        ("change", "24h", ">"),
    ]
    return make_table(display_rows, cols)


def _display_outcomes(rows: list[dict]) -> str:
    if not rows:
        return "No HIP-4 outcomes live"
    cols = [
        ("outcome", "id", ">"),
        ("underlying", "underlying", "<"),
        ("class", "class", "<"),
        ("expiry", "expiry", "<"),
        ("target_price", "target", ">"),
        ("period", "period", "<"),
        ("yes_coin", "yes", "<"),
        ("no_coin", "no", "<"),
    ]
    return make_table(rows, cols)


def _display_outcome(data: dict) -> str:
    parsed = data.get("parsed_description", {}) or {}
    lines = [
        f"  outcome={data['outcome']}  {data['name']}",
        f"  {parsed.get('class', '')} {parsed.get('underlying', '')} target={parsed.get('target_price', '')} expiry={parsed.get('expiry', '')} period={parsed.get('period', '')}",
        "",
    ]
    for label, key in (("YES", "yes"), ("NO", "no")):
        side = data.get(key)
        if not side:
            continue
        lines.append(f"  {label}  {side['coin']}  bid {side.get('top_bid') or '—'}  ask {side.get('top_ask') or '—'}  mid {side.get('mid') or '—'}")
    if data.get("implied_total") is not None:
        lines.append(f"  implied_total {data['implied_total']}")
    return "\n".join(lines)


def _display_book(data: dict) -> str:
    bids = data.get("bids", [])
    asks = data.get("asks", [])
    if not bids and not asks:
        return "Empty book"

    all_sizes = [float(l["size"]) for l in bids + asks]
    max_sz = max(all_sizes) if all_sizes else 1

    lines = [f"  {data['asset']}"]
    lines.append("")

    # Asks (reversed so best ask is closest to center)
    lines.append("  Asks")
    for lv in reversed(asks):
        sz = float(lv["size"])
        b = bar(sz, max_sz, 15)
        lines.append(f"  {lv['price']:>12}  {lv['size']:>10}  {b}")

    lines.append("  " + "─" * 42)

    # Bids
    lines.append("  Bids")
    for lv in bids:
        sz = float(lv["size"])
        b = bar(sz, max_sz, 15)
        lines.append(f"  {lv['price']:>12}  {lv['size']:>10}  {b}")

    return "\n".join(lines)


def _display_funding(result: list[dict]) -> str:
    if not result:
        return "No funding data"
    cols = [
        ("asset", "Asset", "<"),
        ("rate", "Rate", ">"),
        ("annualized", "Ann%", ">"),
        ("premium", "Premium", ">"),
    ]
    return make_table(result, cols)


def _display_funding_history(result: list[dict]) -> str:
    if not result:
        return "No funding history"
    # Sparkline of rates
    rates = [float(r["rate"]) for r in result]
    spark = sparkline(rates)
    cols = [
        ("asset", "Asset", "<"),
        ("annualized", "Ann%", ">"),
        ("time", "Time", "<"),
    ]
    header = f"Funding history  {spark}" if spark else "Funding history"
    return header + "\n" + make_table(result, cols)


def _display_pulse(data: dict) -> str:
    sections = []
    total = data.get("total_assets", 0)
    spot_total = data.get("total_spot_assets", 0)
    sections.append(f"Pulse — {total} perps, {spot_total} spot pairs")

    movers = data.get("movers", [])
    if movers:
        sections.append("")
        sections.append("Movers (24h)")
        for m in movers:
            c = m.get("change_24h", "")
            arrow = _arrow(c)
            cat_tag = f" [{m['category']}]" if m.get("category") != "crypto" else ""
            sections.append(f"  {m['asset']:<16} {arrow}{c:>6}%  {m['price']:>12}{cat_tag}")

    volume = data.get("volume", [])
    if volume:
        max_vol = float(volume[0].get("volume_24h", "0")) if volume else 1
        sections.append("")
        sections.append("Volume (24h)")
        for v in volume:
            vol = float(v.get("volume_24h", "0"))
            b = bar(vol, max_vol, 15)
            sections.append(f"  {v['asset']:<16} {b:<16} {_fmt_vol(v['volume_24h']):>6}")

    funding = data.get("funding", [])
    if funding:
        sections.append("")
        sections.append("Funding (annualized)")
        for f in funding:
            ann = f.get("funding_annualized", "")
            sections.append(f"  {f['asset']:<16} {ann:>8}%")

    signals = data.get("signals", [])
    if signals:
        sections.append("")
        sections.append("Composite signals (2+ factors)")
        for s in signals:
            flags = ", ".join(s.get("flags", []))
            c = s.get("change_24h", "")
            sections.append(f"  {s['asset']:<16} {_arrow(c)}{c:>6}%  [{flags}]")

    spot_movers = data.get("spot_movers", [])
    if spot_movers:
        sections.append("")
        sections.append("Spot movers (24h)")
        for m in spot_movers:
            c = m.get("change_24h", "")
            sections.append(f"  {m['asset']:<16} {_arrow(c)}{c:>6}%  {m['price']:>12}")

    return "\n".join(sections)
