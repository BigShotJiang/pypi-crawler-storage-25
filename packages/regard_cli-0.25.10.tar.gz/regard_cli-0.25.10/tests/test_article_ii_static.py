"""Article II static analysis — Decimal arithmetic enforcement.

Per Constitution Article II (`docs/CLI-CONSTITUTION.md` line 72-74), every
`Decimal(x)` constructor on a financial value MUST initialize from one of:
- string literal: `Decimal("5.0")`
- `str(...)` call: `Decimal(str(field))`
- integer-typed value: `Decimal(0)`, `Decimal(int(x))`, `Decimal(10**18)`,
  `Decimal(balance_raw)` where `balance_raw` is int wei

The dangerous compound is `Decimal(float_var)` — once a float enters the
system, every downstream `Decimal` constructed from it carries IEEE 754
representation error (`Decimal(0.1) == 0.1000000000000000055...`). The
string-intermediary rule eliminates the entry path entirely.

This test is the canonical static implementation of Article IV's
test-obligation clause for Article II's Decimal rule. Article II clause
(2) — `float(...)` boundary enforcement — is queued as Phase 2 (see
NOTES at bottom).

Sources:
- `docs/CLI-CONSTITUTION.md` Article II
- `references/CLI-CONSTITUTION-RATIONALE.md` Article 11
"""

import ast
from pathlib import Path

import pytest

SRC_ROOT = Path(__file__).parent.parent / "src" / "regard"


# Names that the AST cannot prove safe but are known-safe by codebase
# convention. Adding a new entry requires Constitution-aware review:
# the variable's value MUST be either int (raw wei / count) or str
# (Article I JSON wire-format string from venue API or user input).
ALLOWED_DECIMAL_NAME_ARGS = {
    # User-supplied amount strings (typer.Argument(str) parameter)
    "amount": "typer.Argument(str) — user-supplied amount string",
    # Raw wei / token base units (int from web3 / get_erc20_balance)
    "balance_raw": "int wei from get_balance / get_erc20_balance",
    "balance_wei": "int wei from web3 get_balance",
    "pol_balance_raw": "int wei from web3 get_balance",
    "gas_reserve_raw": "int wei (gas_limit * gas_price)",
    "gas_needed_raw": "int wei (gas_limit * gas_price)",
    # Venue API string fields (Article I wire format — strings on the wire)
    "size_str": "string from venue API position field (name suffix _str)",
    "size_held": "string from venue API position field",
    "size": "string from order params dict (Article I)",
    "target_price": "string from parsed.get(...) — venue API field",
    "yes_mid": "string from venue API mid price",
    "no_mid": "string from venue API mid price",
    "bid": "string from venue API order book",
    "ask": "string from venue API order book",
    # Defensive coding
    "value": "fallback in `Decimal(str(value)) if isinstance(value, int) else Decimal(value)` — else branch assumes string",
}

# Suffix conventions identifying int-typed locals/params. A Name with one of
# these suffixes is treated as int-typed for purposes of `Decimal(NAME)` and
# int-pure-binop classification.
INT_NAME_SUFFIXES = ("_decimals", "_wei", "_gas", "_raw", "_int", "_count", "_id", "_amount_raw")

# Specific bare names (not suffix-matched) known to be int-typed in this codebase.
INT_NAME_LITERALS = {"decimals", "wei_decimals"}


def _python_files() -> list[Path]:
    """Every .py file under src/regard/."""
    return sorted(SRC_ROOT.rglob("*.py"))


def _is_int_typed_name(node: ast.AST) -> bool:
    """Heuristic: a Name is int-typed if it matches a suffix convention,
    is one of the specific known-int names, or is uppercase (module constant)."""
    if not isinstance(node, ast.Name):
        return False
    name = node.id
    if name in INT_NAME_LITERALS:
        return True
    if any(name.endswith(s) for s in INT_NAME_SUFFIXES):
        return True
    # Uppercase-with-underscores module constants (e.g. ARB_USDC_DECIMALS,
    # COREEVM_BRIDGE_GAS). Conservative: must be ALL caps + underscores +
    # digits, no lowercase letters.
    if name.isupper() and not name.startswith("_"):
        return True
    return False


def _is_int_pure(node: ast.AST) -> bool:
    """Return True if `node` is provably int-typed by AST inspection alone.

    Conservatively true for:
    - integer literals
    - `int(...)` / `len(...)` / `abs(...)` / `pow(...)` calls
    - Names matching int-suffix convention or uppercase-constant convention
    - BinOp with both operands int-pure
    - UnaryOp on int-pure operand
    """
    if isinstance(node, ast.Constant):
        return isinstance(node.value, int) and not isinstance(node.value, bool)
    if isinstance(node, ast.Call) and isinstance(node.func, ast.Name):
        if node.func.id in {"int", "len", "abs"}:
            return True
        if node.func.id == "pow":
            return True
    if _is_int_typed_name(node):
        return True
    if isinstance(node, ast.BinOp):
        return _is_int_pure(node.left) and _is_int_pure(node.right)
    if isinstance(node, ast.UnaryOp):
        return _is_int_pure(node.operand)
    return False


def _is_str_typed_call(node: ast.AST) -> bool:
    """Heuristic: a Call returning a string. Currently recognizes
    `obj.get(key, default)` where default is a string literal."""
    if not (isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)):
        return False
    if node.func.attr != "get":
        return False
    if len(node.args) < 2:
        return False
    default = node.args[1]
    return isinstance(default, ast.Constant) and isinstance(default.value, str)


def _is_safe_decimal_arg(node: ast.AST) -> tuple[bool, str]:
    """Return (is_safe, reason). reason explains the disposition for diagnostics."""
    # String literal: Decimal("5.0")
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        return True, "string literal"
    # Integer literal: Decimal(0)
    if isinstance(node, ast.Constant) and isinstance(node.value, int) and not isinstance(node.value, bool):
        return True, "integer literal"
    # str(...) call: Decimal(str(field))
    if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == "str":
        return True, "str() call"
    # int(...) call: Decimal(int(x))
    if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == "int":
        return True, "int() call"
    # Int-pure expression: Decimal(10**18), Decimal(balance_raw - gas_reserve_raw) — only safe if BOTH operands are int-typed.
    # Use the allowlist for any Name operand. Treat int-pure (literal arithmetic) as safe.
    if _is_int_pure(node):
        return True, "int-pure expression"
    # BinOp where both operands are either int-pure or known-int-typed Name (per allowlist).
    if isinstance(node, ast.BinOp):
        left_ok = _is_int_pure(node.left) or (
            isinstance(node.left, ast.Name) and node.left.id in ALLOWED_DECIMAL_NAME_ARGS
        )
        right_ok = _is_int_pure(node.right) or (
            isinstance(node.right, ast.Name) and node.right.id in ALLOWED_DECIMAL_NAME_ARGS
        )
        if left_ok and right_ok:
            return True, "binop with allowed operands"
    # Subscript: Decimal(params["amount"]) — Article I guarantees params dict
    # values are JSON-wire strings.
    if isinstance(node, ast.Subscript):
        return True, "subscript (Article I JSON wire string)"
    # Allowed Name (variable known to be int- or str-typed by convention)
    if isinstance(node, ast.Name) and node.id in ALLOWED_DECIMAL_NAME_ARGS:
        return True, f"allowed name: {ALLOWED_DECIMAL_NAME_ARGS[node.id]}"
    # Int-typed Name (suffix convention or uppercase constant)
    if isinstance(node, ast.Name) and _is_int_typed_name(node):
        return True, f"int-typed name (convention): {node.id}"
    # `obj.get(key, str_default)` — string-or-string-default
    if _is_str_typed_call(node):
        return True, "Mapping.get(key, str_default) — returns string"
    return False, f"unsafe form: {ast.unparse(node)[:60]}"


def _decimal_aliases(tree: ast.Module) -> set[str]:
    """Collect every local name that resolves to `decimal.Decimal`.

    Handles `from decimal import Decimal`, `from decimal import Decimal as _D`,
    and `from decimal import Decimal, InvalidOperation`. The plain
    `import decimal` form would access via `decimal.Decimal(...)` (Attribute)
    and is handled separately by the caller.
    """
    aliases = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom) and node.module == "decimal":
            for alias in node.names:
                if alias.name == "Decimal":
                    aliases.add(alias.asname or alias.name)
    return aliases


def _find_decimal_calls(tree: ast.Module) -> list[tuple[int, ast.Call]]:
    """Collect (lineno, Call) for every Decimal(x) constructor call.

    Recognizes aliased imports (`from decimal import Decimal as _D` →
    matches `_D(x)`) and attribute access (`decimal.Decimal(x)`).
    """
    aliases = _decimal_aliases(tree)
    found = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        # Bare name call: Decimal(x) or _D(x)
        if isinstance(node.func, ast.Name) and node.func.id in aliases:
            if node.args:
                found.append((node.lineno, node))
        # Attribute call: decimal.Decimal(x)
        elif (
            isinstance(node.func, ast.Attribute)
            and node.func.attr == "Decimal"
            and isinstance(node.func.value, ast.Name)
            and node.func.value.id == "decimal"
        ):
            if node.args:
                found.append((node.lineno, node))
    return found


def test_decimal_purity():
    """Article II clause (1): every `Decimal(x)` MUST initialize from string,
    `str(...)`, or integer-typed value.

    Failures here mean a `Decimal()` constructor was called on something the
    AST cannot prove is safe. Either:
      - rewrite the call to use a string/int form
      - if the variable is known-safe by codebase convention, add it to
        ALLOWED_DECIMAL_NAME_ARGS at the top of this file with a one-line
        rationale
    """
    violations = []
    for path in _python_files():
        try:
            tree = ast.parse(path.read_text(), str(path))
        except SyntaxError:
            continue
        for lineno, call in _find_decimal_calls(tree):
            arg = call.args[0]
            ok, reason = _is_safe_decimal_arg(arg)
            if not ok:
                rel = path.relative_to(SRC_ROOT)
                violations.append(f"{rel}:{lineno}  Decimal({ast.unparse(arg)[:60]}) — {reason}")
    if violations:
        msg = "Article II clause (1) violations — Decimal() constructed from non-pure form:\n  " + "\n  ".join(violations)
        msg += "\n\nFix by rewriting to Decimal('...'), Decimal(str(x)), Decimal(int(x))"
        msg += ", or by adding the variable name to ALLOWED_DECIMAL_NAME_ARGS in this test if it's known-safe by convention."
        pytest.fail(msg)


# ---------------------------------------------------------------------------
# Phase 2 — float() boundary enforcement (NOT YET ENFORCED)
#
# Article II clause (2) requires `float(...)` calls to appear only as inline
# argument expressions of external-SDK calls. The codebase currently has ~25
# pre-existing monetary-float sites in the order/trade/research pipelines
# (`act.py:order`, `act.py:execute_order`, `act.py:_propose_transfer`,
# `research.py:_resolve_mid`, `polymarket/market.py:_extract_price`, etc.).
#
# Enforcing this rule strictly today would block any commit that touches
# those areas. Migrating them is a separate effort tracked in
# `docs/V025-IMPLEMENTATION.md` Out-of-scope. When that work lands, replace
# this skip with the real check.
# ---------------------------------------------------------------------------


@pytest.mark.skip(reason="Phase 2 — order/trade pipeline float() migration pending")
def test_float_boundary():
    """Article II clause (2): every `float(...)` on a financial value MUST be
    the inline argument expression of an external-SDK call. Not yet enforced
    pending order/trade pipeline migration."""
    pass
