"""Module containing Scipy's KDTree API equivalents"""

from __future__ import annotations

import logging
import warnings
from collections.abc import Sequence

import numpy as np
from numpy.typing import ArrayLike, NDArray

import packingcubes.bounding_box as bbox
import packingcubes.cubes as cubes
import packingcubes.octree as octree
from packingcubes.data_objects import (
    DataContainer,
    InMemory,
)
from packingcubes.data_objects import (
    MultiParticleDataset as Dataset,
)

LOGGER = logging.getLogger(__name__)
logging.captureWarnings(capture=True)


class OpTreeWarning(octree.OctreeWarning):
    """Warning for differences in API"""

    pass


class OpTreeError(octree.OctreeError):
    """Error for irreconcilable differences in API"""

    pass


def _check_data_shape(*, data: ArrayLike, copy_data: bool) -> tuple[NDArray, bool]:
    """Check shape of provided data and coerce to 3D if possible

    Args:
        data: NDArray
        Provided data array

        copy_data: bool
        Whether the data should be copied if it's already (N,3)

    Returns
    -------
        data: NDArray
        An (N,3) version of data

        data_copied: bool
        Whether the data was copied. data_copied=copy_data if data was already
        (N,3), otherwise True

    Raises
    ------
        OpTreeError if provided data cannot be coerced to (N,3)
    """
    data = np.atleast_2d(np.squeeze(data))
    data_shape = data.shape
    if len(data_shape) != 2 or data_shape[1] > 3:
        raise OpTreeError(
            "OpTrees only support (N,m) data. Provided data "
            + (
                f"was {data_shape}."
                if len(data_shape) >= 2
                else f"was {data_shape[1]}-dimensional."
            )
        )

    if data_shape[1] < 3:
        zero_pad = np.zeros_like(data, shape=(data_shape[0], 3))
        zero_pad[:, : data_shape[1]] = data
        # we can ignore the copy_data flag; the data was already copied
        return zero_pad, True
    return (data.copy() if copy_data else data), copy_data


def _process_boxsize(boxsize, data_box: bbox.BoundingBox) -> bbox.BoundingBox:
    if boxsize is not None:
        boxsize = np.atleast_1d(boxsize)
        box_warning = """
        OpTrees do not need or expect data points to be normalized to the
        [0, 1) interval. We will assume that the data is within [0, L_i] with
        no wrapping. If you have negative or overly-large data values, simply
        use the full 6 terms and provide the full bounding box or pass None to
        generate it from the data extents. If you truly need the toroidal
        geometry, please impose that before calling the constructor. \n\n
        You can suppress this message by passing the full 6 terms (or None).
        """
        match len(boxsize):
            case 1:
                warnings.warn(box_warning, OpTreeWarning, stacklevel=1)
                box = np.array([0, 0, 0, boxsize, boxsize, boxsize])
            case 3:
                warnings.warn(box_warning, OpTreeWarning, stacklevel=1)
                box = np.hstack(([0, 0, 0], boxsize.flatten()))
            case 6:
                box = boxsize
            case _:
                raise OpTreeError(
                    f"Cannot handle boxsize argument with length {len(boxsize)}. "
                    "Supported options are 1, 3, and 6."
                )
        bounding_box = bbox.make_bounding_box(box)
    else:
        bounding_box = data_box
    return bounding_box


class OpTree:
    """Class to mimic the SciPy KDTree API using ParticleCubes and PackedTrees

    Will provide identical API to SciPy's KDTree to the extent possible given
    that ParticleCubes and PackedTrees are fundamentally different. Where 1-1
    matches for a requested method, argument, or functionality are not possible,
    raise an OpTreeError if there is nothing similar and emit an OpTreeWarning
    explaining the replacement otherwise.

    Warning! PackedTrees are not robust against large amounts of degenerate
    input data! Please sanitize data prior to usage if expecting data
    degeneracy levels above ~100 (i.e. 100 data points with the same values).
    Note that multiple degenerate regions are acceptable, assuming they are
    sufficiently separated.

    Parameters
    ----------
    data : array_like, shape (n,m) | Dataset
        The `n` `m`-dimensional data points to be indexed. This array is
        preferentially not copied and will be sorted in place, so modifying
        this data will result in bogus results. The data are also copied if
        the `OpTree` is built with copy_data=True. Note: OpTrees are
        intended to support 3-dimensional data, so m>3 is not supported. For
        m<3, the data is padded with zeros (e.g. `[[1, 2], [3, 4]]` will become
        `[[1, 2, 0], [3, 4, 0]]`). This will lead to the data being copied.
        Can also pass in a Dataset directly for improved creation time.

    leafsize : positive int, optional
        The number of points at which the algorithm switches over to
        brute-force.  Default: `400`.

    compact_nodes : bool, optional
        This parameter is irrelevant for `OpTree`s and is only provided
        to match the `KDTree` API.

    copy_data : bool, optional
        If `True` the data is copied to protect the kd-tree against
        data corruption and to prevent the original data from being sorted.
        Default: `False`.

    balanced_tree : bool, optional
        `OpTree`s are always split at the bounding box midpoint, so this
        option is only provided to match the `KDTree` API

    boxsize : array_like or scalar, optional
        Provide an explicit bounding box for the data in the form
        `[x_min, y_min, z_min, dx, dy, dz]`. If `len(boxsize)==3`, `x_min = y_min =
        z_min = 0`. If `boxsize`` is a scalar, `dx = dy = dz = boxsize`. Other
        `boxsize` lengths are unsupported. SciPy's `KDTree` will impose a toroidal
        topology in addition; this functionality is currently unsupported.

    cubes_per_side: int, optional
        Size of the top-level grid. Must be between 3 and 32 or -1 (default).
        The default uses the number of available threads to ensure there are
        more grid cells than threads.

    save_dataset: bool, optional
        If data is a dataset, save sorted positions/indices to file. Default `False`
    """

    _cubes: cubes.ParticleCubes
    """
    The actual cubes grid structure containing the different trees, offsets, etc
    """
    _dataset: Dataset
    """
    Link to the dataset used. Needed for returning strict index lists.
    """
    _data_container: DataContainer
    """
    Pointer to the dataset's DataContainer object. 
    """
    _copied: bool
    """
    Whether the tree was constructed with copied data
    """
    data: NDArray
    """
    The `n` data points of dimension `m` to be indexed. The data is only copied if
    the "kd-tree" is built with copy_data=True.
    """
    n: int
    """
    The number of data points.
    """
    leafsize: int
    """
    The number of points at which the algorithm switches over to brute-force
    """
    maxs: NDArray
    """
    The maximum value in each dimension of the `n` data points
    """
    mins: NDArray
    """
    The minimum value in each dimension of the `n` data points
    """
    size: int
    """
    The number of nodes in the tree.
    """

    def __init__(
        self,
        data: NDArray | Dataset,
        leafsize: int | None = None,
        compact_nodes: bool | None = None,  # noqa: FBT001
        copy_data: bool = False,  # noqa: FBT001, FBT002
        balanced_tree: bool | None = None,  # noqa: FBT001
        boxsize=None,
        *,
        cubes_per_side: int = -1,
        save_dataset: bool = False,
    ):
        if compact_nodes is not None:
            if boxsize is None:
                extra = (
                    "which is set from the outermost datapoints."
                    " So setting compact_nodes does nothing."
                )
            else:
                extra = f"which has been manually set to {boxsize}."
            warnings.warn(
                "Node sizes in OpTrees are set by the geometry of the"
                "total bounding box, " + extra,
                OpTreeWarning,
                stacklevel=1,
            )
        if leafsize is None:
            LOGGER.info(
                "Using the default OpTree leaf size "
                f"({octree._DEFAULT_PARTICLE_THRESHOLD}) instead of the KDTree's (10)"
            )
        if balanced_tree is not None and balanced_tree:
            warnings.warn(
                "OpTree nodes are split at the middle of the bounding box, "
                "independent of the data contained. Setting balanced_tree does "
                "nothing.",
                OpTreeWarning,
                stacklevel=1,
            )

        if not isinstance(data, Dataset):
            # Note: this also handles if the data should be copied
            data, data_copied = _check_data_shape(data=data, copy_data=copy_data)

            self._dataset = InMemory(positions=data)
            self._copied = data_copied
            if save_dataset:
                warnings.warn(
                    "Can only save sorted positions when data is a Dataset",
                    OpTreeWarning,
                    stacklevel=1,
                )
                save_dataset = False
        else:
            self._dataset = data
            self._copied = False
        self._data_container = self._dataset.data_container
        self.data = self._dataset.positions
        self.n = len(self.data)
        data_box = self._dataset.bounding_box
        self.mins = data_box.box[:3]
        self.maxs = data_box.box[:3] + data_box.box[3:]

        bounding_box = _process_boxsize(boxsize=boxsize, data_box=data_box)

        self.leafsize = (
            octree._DEFAULT_PARTICLE_THRESHOLD if leafsize is None else leafsize
        )

        self._cubes = cubes.Cubes(
            dataset=self._dataset,
            particle_threshold=leafsize,
            cube_box=bounding_box,
            save_dataset=save_dataset,
            particle_type=self._dataset.particle_type,
        )

        # Each node is 5 fields, so number of nodes in a single tree = length/5
        # But we have 1 tree per cube...
        self.size = sum(int(len(ct._tree.tree) / 5) for ct in self._cubes.cube_trees)

    @property
    def sort_index(self):
        """Shuffle list for the original data, ie self.data = data[self.sort_index]"""
        if self._copied:
            warnings.warn(
                """
                Since the data was copied, the effective shuffle list is simply
                0:len(data) and this property is superfluous.
                """,
                OpTreeWarning,
                stacklevel=1,
            )
            return np.arange(len(self.dataset))
        index = self._dataset.index.view()
        index.flags.writeable = False
        return index

    def _query(
        self,
        *,
        x: NDArray,
        k: int | Sequence[int],
        distance_upper_bound: float,
        p: float,
        return_data_indices: bool,
        return_sorted: bool,
    ) -> tuple[float | NDArray, int | NDArray]:
        """Private helper that wraps the PackedTree get_closest_particles method

        See query for argument definitions
        """
        k_max = k if not isinstance(k, Sequence) else max(k)

        d = np.full((len(x), k_max), np.inf)
        i = np.full((len(x), k_max), self.n)
        for ind, xyz in enumerate(x):
            dists, inds = self._cubes.get_closest_particles(
                data=self._data_container,
                xyz=xyz,
                distance_upper_bound=distance_upper_bound,
                p=p,
                k=k_max,
                return_shuffle_indices=not return_data_indices,
                return_sorted=return_sorted,
            )
            d[ind, : len(dists)] = dists
            i[ind, : len(inds)] = inds
        if k_max == 1 and not isinstance(k, Sequence):
            return d.squeeze(), i.squeeze()
        if isinstance(k, Sequence):
            k_inds = np.fromiter(k, dtype=int) - 1
            return d[:, k_inds], i[:, k_inds]
        return d, i

    def query(
        self,
        x: ArrayLike,
        k: int | Sequence[int] = 1,
        eps: float | None = None,
        p: int | None = None,
        distance_upper_bound: float | None = None,
        workers: int | None = None,
        *,
        return_data_indices: bool | None = None,
        return_sorted: bool | None = None,
    ) -> tuple[float | NDArray, int | NDArray]:
        """Query the OpTree for nearest neighbors

        Parameters
        ----------
        x: NDArray
            An array of points to query

        k: int | Sequence[int], optional
            Either the number of nearest neighbors to return or a list of the
            kth nearest neighbors to return, starting from 1. E.g., `[2,3]` will
            return the 2nd and 3rd nearest neighbors

        eps: nonnegative float, optional
            Return approximate nearest neighbors; Note that this parameter is
            unused

        p: 1<=p<=infinity, optional
            The Minkowski p-norm to use. 1 is the sum of absolute-values
            distance ("Manhattan" distance). 2 is the Euclidean distance.
            infinity is the maximum-coordinate-difference distance. Currently
            only p=2 is supported

        distance_upper_bound: nonnegative float, optional
            Return only neighbors from other nodes within this distance. This
            is used for tree pruning, so if you are doing a series of
            nearest-neighbor queries, it may help to supply the distance to the
            nearest neighbor of the most recent point.

        workers: int, optional
            Number of workers to use for parallel processing. Only 1 is
            supported, for more, see Cubes

        return_data_indices: bool | None, optional
            Return indices into the sorted data if True instead of into the
            original. Specify None to have this set by the copy_data argument
            used during tree construction.

        return_sorted: bool, optional
            Flag to return the distances and indices in distance-sorted order.
            Set to `False` for a performance boost. Default `True`

        Returns
        -------
        d: float or array of floats
            The distances to the nearest neighbors. If `x` has shape
            `tuple+(self.m,)`, then `d` has shape `tuple+(k,)`. When `k==1`,
            the last dimension of the output is squeezed. Missing neighbors are
            indicated with infinite distances. Hits are sorted by distance
            (nearest first)

        i: integer or array of integers
            The index of each neighbor in `self.data`. `i` is the same shape as
            `d`. Missing neighbors are indicated with `self.n`.

        Raises
        ------
        NotImplementedError
            if `p!=2`

        """
        x, _ = _check_data_shape(data=x, copy_data=False)

        distance_upper_bound = (
            1e100 if distance_upper_bound is None else distance_upper_bound
        )
        p = 2 if p is None else p

        if eps is not None:
            if eps < 0:
                raise ValueError("eps must be nonnegative.")
            if eps > 0:
                warnings.warn(
                    (
                        """
                        OpTrees do not quantify the distance between points/nodes
                        in the same way as KDTrees and setting this parameter has no
                        effect
                        """
                    ),
                    OpTreeWarning,
                    stacklevel=1,
                )

        if workers is not None and workers != 1:
            warnings.warn(
                """
                OpTrees are single-threaded. For multi-threading consider
                switching to the Cubes API. Proceeding with workers=1.
                """,
                OpTreeWarning,
                stacklevel=1,
            )

        return_data_indices = (
            not self._copied if return_data_indices is None else return_data_indices
        )

        return_sorted = True if return_sorted is None else return_sorted

        return self._query(
            x=x,
            k=k,
            distance_upper_bound=distance_upper_bound,
            p=p,
            return_data_indices=return_data_indices,
            return_sorted=return_sorted,
        )

    def _query_ball_point(
        self,
        *,
        centers: NDArray,
        radius: float,
        return_length: bool,
        return_sorted: bool,
        return_lists: bool,
        return_data_indices: bool,
        strict: bool = False,
    ) -> int | list[int] | NDArray:
        """Private method to actually compute the query after inputs validated"""
        if return_length:
            # psuedocode:
            # for center in centers:
            #     sph = sphere(center, radius)
            #     nodes = list of tree nodes that overlap sph
            #     sum = 0
            #     for node in nodes:
            #         sum += node.end-node.start + 1
            #     append sum to result
            lengths = [
                sum(
                    e - s
                    for (s, e, _) in self._cubes.get_particle_indices_in_sphere(
                        center=center,
                        radius=radius,
                    )
                )
                for center in centers
            ]
            return lengths[0] if len(lengths) == 1 else lengths

        results = [
            self._cubes.get_particle_index_list_in_sphere(
                data=self._data_container,
                center=center,
                radius=radius,
                strict=strict,
                use_data_indices=return_data_indices,
            )
            for center in centers
        ]
        #  results is now list of list of (unsorted) indices
        if return_sorted:
            for r in results:
                r.sort()

        if return_lists:
            results = [r.tolist() for r in results]

        if len(centers) > 1:
            return np.fromiter(results, dtype=np.object_)
        return results[0]

    def query_ball_point(
        self,
        x: ArrayLike,
        r: float,
        p: float | None = 2.0,
        eps: float | None = None,
        workers: int = -1,
        *,
        return_sorted: bool | None = False,
        return_length: bool = False,
        return_lists: bool | None = False,
        return_data_indices: bool | None = None,
        strict: bool | None = None,
    ) -> int | list[int] | NDArray:
        """Find all points within distance r of point(s) x.

        Parameters
        ----------
        x : array_like, shape tuple + (self.m,)
            The point or points to search for neighbors of.

        r : array_like, float
            The radius of points to return, must broadcast to the length of `x`.

        p : float, optional
            Which Minkowski `p`-norm to use.  Should be in the range `[1, inf]`.
            A finite large `p` may cause a `ValueError` if overflow can occur.

        eps : nonnegative float, optional
            Approximate search. Branches of the tree are not explored if their
            nearest points are further than ``r / (1 + eps)``, and branches are
            added in bulk if their furthest points are nearer than
            ``r * (1 + eps)``.

        workers : int, optional
            Number of jobs to schedule for parallel processing. If -1 is given
            all processors are used. Default: -1. Note: SciPy's kdtree
            parallelizes across the number of points queried. Thus, querying
            on a single point gets no speed-up from parallelization. We
            parallelize on single point queries, thus the different default

        return_sorted : bool, optional
            Sorts returned indices if `True` and does not sort them if `False`. If
            `None`, does not sort single point queries, but does sort
            multi-point queries which was the behavior before this option
            was added. Default `False`.

        return_length : bool, optional
            Return the number of points inside the radius instead of a list
            of the indices. Note that this is much faster for large trees.

        return_lists : bool, optional
            Force returning lists instead of arrays. `OpTree`s return
            arrays of indices by default, but this doesn't match the
            expected query_ball_point signature. To exactly match SciPy,
            set this to `True`.

        return_data_indices: bool | None, optional
            Return indices into the sorted data if `True` instead of into the
            original. Specify `None` to have this set by the copy_data argument
            used during tree construction.

        strict: bool, optional
            If `False`, compare only the approximate node distance. Should be
            significantly faster, but may include some amount of false
            positives. Default `True`

        Returns
        -------
        results : list or array of lists
            If `x` is a single point, returns a list of the indices of the
            neighbors of `x`. If `x` is an array of points, returns an object
            array of shape tuple containing lists of neighbors.

        Notes
        -----
        If you have many points whose neighbors you want to find, you may save
        substantial amounts of time by putting them in a OpTree and using
        [query_ball_tree][query_ball_tree].

        Examples
        --------
        >>> import numpy as np
        >>> from packingcubes import OpTree
        >>> x, y = np.mgrid[0:5, 0:5]
        >>> points = np.c_[x.ravel(), y.ravel()]
        >>> tree = OpTree(points)
        >>> sorted(tree.query_ball_point([2, 0], 1))
        [5, 10, 11, 15]

        Query multiple points and plot the results:

        >>> import matplotlib.pyplot as plt
        >>> points = np.asarray(points)
        >>> plt.plot(points[:,0], points[:,1], '.')
        >>> for results in tree.query_ball_point(([2, 0], [3, 3]), 1):
        ...     nearby_points = points[results]
        ...     plt.plot(nearby_points[:,0], nearby_points[:,1], 'o')
        >>> plt.margins(0.1, 0.1)
        >>> plt.show()

        """
        x, _ = _check_data_shape(data=x, copy_data=False)

        p = 2 if p is None else p
        if p != 2:
            warnings.warn(
                (
                    "OpTrees currently only support the Minkowski 2-norm "
                    f"(requested {p}). Continuing with p=2."
                ),
                OpTreeWarning,
                stacklevel=1,
            )

        if eps is not None:
            if eps < 0:
                raise ValueError("eps must be nonnegative.")
            if eps > 0:
                warnings.warn(
                    (
                        """
                        OpTrees do not quantify the distance between points/nodes
                        in the same way as KDTrees. Setting eps>0 is equivalent to
                        strict=False (default).
                        """
                    ),
                    OpTreeWarning,
                    stacklevel=1,
                )
            else:
                strict = True if strict is None else strict
        strict = True if strict is None else strict

        if strict and return_length:
            raise NotImplementedError(
                "For performance, strict is only valid when return_length=False"
            )

        if workers != -1:
            warnings.warn(
                """
                Cubes use all available threads by default. 
                To reduce the number of threads used, run with the NUMBA_NUM_THREADS=N
                environmental variable set. Proceeding with workers=-1.
                """,
                OpTreeWarning,
                stacklevel=1,
            )

        return_lists = True if return_lists is None else return_lists
        return_sorted = x.shape[0] > 1 if return_sorted is None else return_sorted

        return_data_indices = (
            not self._copied if return_data_indices is None else return_data_indices
        )

        return self._query_ball_point(
            centers=x,
            radius=r,
            return_length=return_length,
            return_sorted=return_sorted,
            return_lists=return_lists,
            return_data_indices=return_data_indices,
            strict=strict,
        )

    def _query_ball_tree(
        self,
        *,
        other: OpTree,
        r: float,
        p: float,
        strict: bool,
        return_lists: bool,
        return_sorted: bool,
    ) -> list[list[int]] | list[NDArray[np.int64]]:
        """Private wrapper method for PackedTree's _get_pilis_tree"""
        pil = self._cubes._get_pilis_cubes(
            data=self._data_container,
            odata=other._data_container,
            ocubes=other._cubes,
            r=r,
            p=p,
            strict=strict,
        )
        # These are the indices into the sorted data. If it was copied, we'll
        # need to use the shuffle list(s). That applies for both self and other
        if other._copied:
            oindex = other._dataset._index
            # at least this is vectorized
            results = [oindex[a] for a in pil]
        else:
            results = pil
        if self._copied:
            # use empty array for typing. it'll be overwritten
            shuffle_results: list[NDArray] = [
                np.empty((1,)) for _ in self._dataset._index
            ]
            for i, ind in enumerate(self._dataset._index):
                shuffle_results[ind] = results[i]
            results = shuffle_results

        if return_sorted:
            for res in results:
                res.sort()

        if return_lists:
            return [r.tolist() for r in results]

        return results

    def query_ball_tree(
        self,
        other: OpTree,
        r,
        p: float = 2,
        eps: float | None = None,
        *,
        strict: bool | None = None,
        return_lists: bool | None = None,
        return_sorted: bool | None = None,
    ) -> list[list[int]] | list[NDArray[np.int64]]:
        """Find all pairs of points between self and other whose distance is at most r.

        Parameters
        ----------
        other: OpTree
            The tree containing points to search against

        r: float
            The maximum distance, has to be positive

        p: float, optional
            Which Minkowski norm to use. `p` has to meet the condition
            `1 <= p <= infinity`

        eps: float, optional
            Approximate search. Branches of the tree are not explored if their
            nearest points are further than `r/(1+eps)`, and branches are added
            in bulk if their furthest points are nearer than `r * (1+eps)`. eps
            has to be non-negative.

        strict: bool, optional
            If `False`, compare only the approximate node distance. Should be
            significantly faster, but may include substantial amounts of false
            positives. Default `True`

        return_lists: bool, optional
            Force returning lists instead of arrays. `OpTree`s return
            arrays of indices by default, but this doesn't match the
            expected `query_ball_tree` signature. For a slight performance
            increase, set this to `False`

        return_sorted: bool, optional
            Force returning sorted lists. If the `copy_data` flag was passed
            during tree construction, the data used to generate the results
            may be in a different order than originally imposed. For example,
            `results[0] = [5, 1, 2]`. If order of output is important, set this
            flag to `True`, at a performance penalty.

        Returns
        -------
        results: list of lists
            For each element `self.data[i]` of this tree, `results[i]` is a
            list of the indices of its neighbors in other.data

        Raises
        ------
        NotImplementedError
            if p!=2
        """
        if r <= 0:
            raise ValueError("r must be positive")

        if p < 1:
            raise ValueError("p must be greater than or equal to 1.")

        if eps:
            strict = True
            if eps > 0:
                warnings.warn(
                    """
                    OpTrees approximates search differently than KDTrees.
                    As such, numeric values for eps are not applicable. To skip
                    this warning, pass strict=False instead of a positive eps.
                    """,
                    OpTreeWarning,
                    stacklevel=1,
                )
                strict = False

        strict = True if strict is None else strict
        return_lists = True if return_lists is None else return_lists
        return_sorted = False if return_sorted is None else return_sorted

        return self._query_ball_tree(
            other=other,
            r=r,
            p=p,
            strict=strict,
            return_lists=return_lists,
            return_sorted=return_sorted,
        )

    def _query_pairs(
        self, *, r: float, strict: bool, return_set: bool
    ) -> set | NDArray:
        """Private wrapper method for PackedTree's _get_pilis_tree"""
        pil = self._cubes._get_pilis_cubes(
            data=self._data_container,
            odata=self._data_container,
            ocubes=self._cubes,
            r=r,
            p=2.0,
            strict=strict,
        )
        # These are the indices into the sorted data. If it was copied, we'll
        # need to use the shuffle list(s). That applies for both self and other
        if self._copied:
            index = self._dataset._index
            # at least this is vectorized
            index_list = [index[a] for a in pil]
            # use empty array for typing. it'll be overwritten
            shuffle_index_list: list[NDArray] = [
                np.empty((1,)) for _ in self._dataset._index
            ]
            for i, ind in enumerate(self._dataset._index):
                shuffle_index_list[ind] = index_list[i]
            index_list = shuffle_index_list
        else:
            index_list = pil

        results = []
        for i, sublist in enumerate(index_list):
            for ind in sublist:
                if ind < i:
                    results.append((i, ind))

        return set(results) if return_set else np.array(results)

    def query_pairs(
        self,
        r: float,
        p: float = 2.0,
        *,
        eps: float | None = None,
        output_type: str | None = None,
        strict: bool | None = None,
    ) -> set | NDArray:
        """Find all pairs of points in self whose distance is at most r.

        Parameters
        ----------
        r: float
            The maximum distance, has to be positive

        p: float, optional
            Which Minkowski norm to use. `p` has to meet the condition
            `1 <= p <= infinity`

        eps: float, optional
            Approximate search. Branches of the tree are not explored if their
            nearest points are further than `r/(1+eps)`, and branches are added
            in bulk if their furthest points are nearer than `r * (1+eps)`. eps
            has to be non-negative.

        output_type: str, optional
            Choose the output container, 'set' or 'ndarray'. Default: 'set'

        strict: bool, optional
            If `False`, compare only the approximate node distance. Should be
            significantly faster, but may include substantial amounts of false
            positives. Default `True`

        Returns
        -------
        results: set or NDArray
            Set of pairs `(i, j)` with `i<j`, for which the corresponding positions
            are close. If output_type is 'ndarray', an ndarray is returned
            instead of a set.

        Raises
        ------
        NotImplementedError
            if p!=2
        """
        if r <= 0:
            raise ValueError("r must be positive")

        if p < 1:
            raise ValueError("p must be greater than or equal to 1.")

        if eps:
            strict = True
            if eps > 0:
                warnings.warn(
                    """
                    OpTrees approximates search differently than KDTrees.
                    As such, numeric values for eps are not applicable. To skip
                    this warning, pass strict=False instead of a positive eps.
                    """,
                    OpTreeWarning,
                    stacklevel=1,
                )
                strict = False

        output_type = "set" if output_type is None else output_type
        if output_type not in ("set", "kdtree"):
            raise ValueError(f"Unknown output_type option: {output_type}")

        strict = True if strict is None else strict

        return self._query_pairs(r=r, strict=strict, return_set=output_type == "set")

    def count_neighbors(
        self,
        *,
        other: OpTree,
        r: float | NDArray,
        p: float | None = None,
        weights: tuple[float | None, float | None] | NDArray | None = None,
        cumulative: bool | None = None,
    ) -> int | float | NDArray:
        """
        Count how many nearby pairs can be formed.

        Count the number of pairs `(x1, x2)` can be formed, with `x1` drawn from
        `self` and `x2` drawn from `other`, and where `distance(x1, x2, p)`
        `<= r`.

        Data points on `self` and `other` are optionally weighted by the `weights`
        argument. (See below)

        WARNING
        -------
        Not currently implemented.

        Parameters
        ----------
        other: OpTree
            The other tree to draw points from, can be the same tree as self
        r: float or one-dimensional array of floats
            The radius to produce a count for. Mulltiple radii are searched
            with a single tree traversal. If the count is non-cumulative
            (`cumulative=False`), `r` defines the edges of the bins, and
            must be non-decreasing
        p: float, 1 <= p <= infinity
            Which Minkowski p-norm to use. Default 2.0. A finite large p
            may cause a `ValueError` if overflow can occur
        weights: tuple, array_like, or None, optional
            If None, the pair-counting is unweighted. If given as a tuple,
            `weights[0]` is the weights of points in `self`, and
            `weights[1]` is the weights of points in `other`; either can
            be None to indicate the points are unweighted. If given as an
            array_like, `weights` is the weights of points in `self` and
            `other`. For this to make sense, `self` and `other` must be the
            same tree. If `self` and `other` are two different trees, a
            `ValueError` is raised. Default: None
        cumulative: bool, optional
            Whether the returned counts are cumulative. When `cumulative` is
            set to `False` the algorithm is optimized to work with a large
            number of bins (>10) specified by `r`. When `cumulative` is set
            to `True`, the algorithm is optimized to work with a small
            number of `r`. Default: True

        Returns
        -------
        result: scalar or 1-D array
            The number of pairs. For unweighted counts, the result is
            integer. For weighted counts, the result is float. If
            `cumulative` is `False`, `result[i]` contains the counts with
            `(-inf if i == 0 else r[i-1]) < R <= r[i]`

        Raises
        ------
        NotImplementedError
        """
        raise NotImplementedError()

    def sparse_distance_matrix(
        self,
        *,
        other: OpTree,
        max_distance: float,
        p: float | None = None,
        output_type: str | None = None,
    ) -> dict[int, int] | NDArray:
        """
        Compute a sparse distance matrix

        Computes a distance matrix between two OpTrees, leaving as zero any
        distance greater than max_distance.

        WARNING
        -------
        Not currently implemented.

        Parameters
        ----------
        other: OpTree
        max_distance: positive float
        p: float, 1 <= p <= infinity
            Which Minkowski p-norm to use. A finite large p may cause a
            `ValueError` if overflow can occur
        output_type: ["dok_matrix", "coo_matrix", "dict", "ndarray""]
            Which container to use for output data. Default: "dok_matrix"

        Returns
        -------
        result: dok_matrix, coo_matrix, dict, or ndarray
            Sparse matrix representing the results in a "dictionary of
            keys" format. If a dict is returned the keys are (i,j) tuples
            of indices. If output_type is "ndarray" a record array with
            fields "i", "j", and "v" is returned.

        Raises
        ------
        NotImplementedError
        """
        raise NotImplementedError()
