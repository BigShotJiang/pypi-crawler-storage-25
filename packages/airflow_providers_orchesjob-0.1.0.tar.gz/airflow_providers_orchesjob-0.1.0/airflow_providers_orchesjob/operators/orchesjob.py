# SPDX-License-Identifier: MIT
# Copyright (c) 2026 Ryosuke Muraki
"""Deferrable Airflow operator that runs a job via orchesjob over SSH."""

from __future__ import annotations

import json
import shlex
import time
from typing import Any, Sequence

from airflow.exceptions import AirflowException
from airflow.models import BaseOperator
from airflow.utils.context import Context

from airflow_providers_orchesjob.triggers.orchesjob import OrchesJobTrigger


class OrchesJobOperator(BaseOperator):
    """Start a job on a remote host via ``orchesjob`` and wait for completion.

    The operator launches the job asynchronously (without ``--sync``) and
    immediately defers to :class:`OrchesJobTrigger`, which polls
    ``orchesjob status`` over SSH until the job reaches a terminal state.
    This means the Airflow worker slot is released while the job runs.

    Parameters
    ----------
    command:
        Command to execute on the remote host (passed after ``--`` to
        ``orchesjob start``).
    ssh_conn_id:
        Airflow SSH Connection ID used for all remote calls.
    run_key:
        orchesjob idempotency key.  Defaults to
        ``{dag_id}__{task_id}__{run_id}``.
    strict:
        Pass ``--strict`` to ``orchesjob start``.  When *True*, the same
        ``run_key`` can never start more than one execution, even after the
        previous job has finished.  Defaults to *False*.
    poll_interval:
        Seconds between ``orchesjob status`` polls inside the trigger.
        Defaults to ``30.0``.
    startup_timeout:
        Seconds to wait for the job to leave the ``STARTING`` state.
        Raises :class:`~airflow.exceptions.AirflowException` (and triggers
        an Airflow retry) if exceeded.  Defaults to ``60.0``.
    orchesjob_home:
        Override ``ORCHESJOB_HOME`` on the remote host.  Defaults to the
        orchesjob built-in default (``/var/lib/orchesjob``).
    """

    template_fields: Sequence[str] = ("command", "run_key", "orchesjob_home")

    def __init__(
        self,
        *,
        command: list[str],
        ssh_conn_id: str,
        run_key: str | None = None,
        strict: bool = False,
        poll_interval: float = 30.0,
        startup_timeout: float = 60.0,
        orchesjob_home: str | None = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.command = command
        self.ssh_conn_id = ssh_conn_id
        self.run_key = run_key
        self.strict = strict
        self.poll_interval = poll_interval
        self.startup_timeout = startup_timeout
        self.orchesjob_home = orchesjob_home

    # ------------------------------------------------------------------
    # execute / execute_complete
    # ------------------------------------------------------------------

    def execute(self, context: Context) -> None:
        run_key = self._resolve_run_key(context)
        self.log.info("Starting orchesjob job with run_key=%r", run_key)

        result = self._ssh_start(run_key)
        job_id: str = result["job_id"]
        status: str = result["status"]

        self.log.info(
            "orchesjob start accepted=%s job_id=%s status=%s",
            result.get("accepted"),
            job_id,
            status,
        )

        self.defer(
            trigger=OrchesJobTrigger(
                job_id=job_id,
                ssh_conn_id=self.ssh_conn_id,
                poll_interval=self.poll_interval,
                startup_timeout=self.startup_timeout,
                job_started_at=time.monotonic(),
                orchesjob_home=self.orchesjob_home,
            ),
            method_name="execute_complete",
        )

    def execute_complete(self, context: Context, event: dict[str, Any]) -> dict[str, Any]:
        """Resume after the trigger fires.  Raises on non-SUCCEEDED status."""
        status = event.get("status", "UNKNOWN")
        job_id = event.get("job_id", "?")

        if status == "SUCCEEDED":
            self.log.info("Job %s SUCCEEDED", job_id)
            return event

        if status == "STARTUP_TIMEOUT":
            raise AirflowException(
                f"Job {job_id} did not leave STARTING state within "
                f"{self.startup_timeout:.0f} s"
            )

        if status == "SSH_ERROR":
            raise AirflowException(
                f"SSH error while monitoring job {job_id}: {event.get('error')}"
            )

        # FAILED / LOST / CANCELLED or any unknown status
        raise AirflowException(
            f"Job {job_id} ended with status {status!r} "
            f"(exit_code={event.get('exit_code')})"
        )

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _resolve_run_key(self, context: Context) -> str:
        if self.run_key:
            return self.run_key
        dag_id = context["dag"].dag_id
        task_id = context["task"].task_id
        run_id = context["run_id"]
        return f"{dag_id}__{task_id}__{run_id}"

    def _ssh_start(self, run_key: str) -> dict[str, Any]:
        """Run ``orchesjob start`` over SSH and return the parsed JSON response."""
        from airflow.providers.ssh.hooks.ssh import SSHHook

        parts = ["orchesjob", "start", "--run-key", run_key]
        if self.strict:
            parts.append("--strict")
        parts += ["--"] + list(self.command)

        cmd = self._build_cmd(parts)
        self.log.debug("SSH command: %s", cmd)

        hook = SSHHook(ssh_conn_id=self.ssh_conn_id)
        client = hook.get_conn()
        try:
            _, stdout, stderr = client.exec_command(cmd)
            exit_status = stdout.channel.recv_exit_status()
            out = stdout.read().decode()
            err = stderr.read().decode()
        finally:
            client.close()

        if exit_status != 0:
            raise AirflowException(
                f"orchesjob start failed (exit {exit_status}): {err.strip()}"
            )

        try:
            return json.loads(out)
        except json.JSONDecodeError as exc:
            raise AirflowException(
                f"orchesjob start returned non-JSON output: {out!r}"
            ) from exc

    def _build_cmd(self, parts: list[str]) -> str:
        cmd = " ".join(shlex.quote(p) for p in parts)
        if self.orchesjob_home:
            cmd = f"ORCHESJOB_HOME={shlex.quote(self.orchesjob_home)} {cmd}"
        return cmd
