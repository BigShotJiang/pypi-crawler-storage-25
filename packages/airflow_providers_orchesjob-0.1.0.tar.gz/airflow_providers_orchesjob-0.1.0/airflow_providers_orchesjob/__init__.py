# SPDX-License-Identifier: MIT
# Copyright (c) 2026 Ryosuke Muraki
"""Apache Airflow provider for orchesjob."""

from __future__ import annotations


def get_provider_info() -> dict:
    return {
        "package-name": "airflow-providers-orchesjob",
        "name": "orchesjob",
        "description": "Deferrable operator that runs jobs via orchesjob over SSH.",
        "versions": ["0.1.0"],
    }
