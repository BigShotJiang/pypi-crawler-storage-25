# SPDX-License-Identifier: MIT
# Copyright (c) 2026 Ryosuke Muraki
"""Trigger that polls an orchesjob job status over SSH until terminal."""

from __future__ import annotations

import asyncio
import json
import shlex
import time
from typing import Any, AsyncIterator

from airflow.triggers.base import BaseTrigger, TriggerEvent

_TERMINAL_STATUSES = {"SUCCEEDED", "FAILED", "LOST", "CANCELLED"}


class OrchesJobTrigger(BaseTrigger):
    """Async trigger that polls ``orchesjob status`` over SSH.

    Yields a single :class:`~airflow.triggers.base.TriggerEvent` whose
    payload is a dict with at least the keys ``status`` and ``job_id``.

    Special ``status`` values emitted by this trigger:
    - ``"STARTUP_TIMEOUT"`` – job was still ``STARTING`` after
      ``startup_timeout`` seconds since ``job_started_at``.
    - ``"SSH_ERROR"`` – repeated SSH failures (after ``_SSH_RETRY_LIMIT``
      consecutive errors).
    - Any terminal orchesjob status: ``SUCCEEDED``, ``FAILED``, ``LOST``,
      ``CANCELLED``.
    """

    _SSH_RETRY_LIMIT = 5

    def __init__(
        self,
        *,
        job_id: str,
        ssh_conn_id: str,
        poll_interval: float,
        startup_timeout: float,
        job_started_at: float,
        orchesjob_home: str | None = None,
    ) -> None:
        super().__init__()
        self.job_id = job_id
        self.ssh_conn_id = ssh_conn_id
        self.poll_interval = poll_interval
        self.startup_timeout = startup_timeout
        self.job_started_at = job_started_at
        self.orchesjob_home = orchesjob_home

    def serialize(self) -> tuple[str, dict[str, Any]]:
        return (
            "airflow_providers_orchesjob.triggers.orchesjob.OrchesJobTrigger",
            {
                "job_id": self.job_id,
                "ssh_conn_id": self.ssh_conn_id,
                "poll_interval": self.poll_interval,
                "startup_timeout": self.startup_timeout,
                "job_started_at": self.job_started_at,
                "orchesjob_home": self.orchesjob_home,
            },
        )

    async def run(self) -> AsyncIterator[TriggerEvent]:
        loop = asyncio.get_event_loop()
        consecutive_errors = 0

        while True:
            try:
                status_json: dict[str, Any] = await loop.run_in_executor(
                    None, self._fetch_status
                )
                consecutive_errors = 0
            except Exception as exc:
                consecutive_errors += 1
                self.log.warning(
                    "SSH error while polling job %s (attempt %d/%d): %s",
                    self.job_id,
                    consecutive_errors,
                    self._SSH_RETRY_LIMIT,
                    exc,
                )
                if consecutive_errors >= self._SSH_RETRY_LIMIT:
                    yield TriggerEvent(
                        {
                            "status": "SSH_ERROR",
                            "job_id": self.job_id,
                            "error": str(exc),
                        }
                    )
                    return
                await asyncio.sleep(self.poll_interval)
                continue

            status: str = status_json.get("status", "UNKNOWN")

            # Check startup timeout before anything else
            if status == "STARTING":
                elapsed = time.monotonic() - self.job_started_at
                if elapsed > self.startup_timeout:
                    self.log.error(
                        "Job %s still STARTING after %.1f s (timeout=%.1f s)",
                        self.job_id,
                        elapsed,
                        self.startup_timeout,
                    )
                    yield TriggerEvent(
                        {
                            "status": "STARTUP_TIMEOUT",
                            "job_id": self.job_id,
                            "elapsed": elapsed,
                        }
                    )
                    return

            if status in _TERMINAL_STATUSES:
                self.log.info("Job %s reached terminal status: %s", self.job_id, status)
                yield TriggerEvent(
                    {
                        "status": status,
                        "job_id": self.job_id,
                        "exit_code": status_json.get("exit_code"),
                        "finished_at": status_json.get("finished_at"),
                        "stdout_file": status_json.get("stdout_file"),
                        "stderr_file": status_json.get("stderr_file"),
                    }
                )
                return

            self.log.debug("Job %s status=%s, sleeping %.1f s", self.job_id, status, self.poll_interval)
            await asyncio.sleep(self.poll_interval)

    def _fetch_status(self) -> dict[str, Any]:
        """Synchronous SSH call – executed in a thread-pool executor."""
        from airflow.providers.ssh.hooks.ssh import SSHHook

        cmd = self._build_cmd(["orchesjob", "status", "--job-id", self.job_id])
        hook = SSHHook(ssh_conn_id=self.ssh_conn_id)
        client = hook.get_conn()
        try:
            _, stdout, stderr = client.exec_command(cmd)
            exit_status = stdout.channel.recv_exit_status()
            out = stdout.read().decode()
            err = stderr.read().decode()
        finally:
            client.close()

        if exit_status != 0:
            raise RuntimeError(
                f"orchesjob status exited {exit_status}: {err.strip()}"
            )
        return json.loads(out)

    def _build_cmd(self, parts: list[str]) -> str:
        """Build shell command string, optionally prepending ORCHESJOB_HOME."""
        cmd = " ".join(shlex.quote(p) for p in parts)
        if self.orchesjob_home:
            cmd = f"ORCHESJOB_HOME={shlex.quote(self.orchesjob_home)} {cmd}"
        return cmd
