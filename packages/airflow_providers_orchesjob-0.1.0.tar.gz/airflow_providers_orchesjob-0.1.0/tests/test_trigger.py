# SPDX-License-Identifier: MIT
# Copyright (c) 2026 Ryosuke Muraki
"""Tests for OrchesJobTrigger."""

from __future__ import annotations

import time
from unittest.mock import MagicMock, patch

import pytest

from airflow_providers_orchesjob.triggers.orchesjob import OrchesJobTrigger


def _make_trigger(**kwargs) -> OrchesJobTrigger:
    defaults = dict(
        job_id="test-job-id",
        ssh_conn_id="my_ssh",
        poll_interval=0.01,
        startup_timeout=5.0,
        job_started_at=time.monotonic(),
        orchesjob_home=None,
    )
    defaults.update(kwargs)
    return OrchesJobTrigger(**defaults)


class TestOrchesJobTriggerSerialize:
    def test_serialize_roundtrip(self):
        t = _make_trigger(job_started_at=12345.0)
        classpath, kwargs = t.serialize()
        assert classpath.endswith("OrchesJobTrigger")
        t2 = OrchesJobTrigger(**kwargs)
        assert t2.job_id == t.job_id
        assert t2.ssh_conn_id == t.ssh_conn_id
        assert t2.poll_interval == t.poll_interval
        assert t2.startup_timeout == t.startup_timeout
        assert t2.job_started_at == t.job_started_at
        assert t2.orchesjob_home == t.orchesjob_home

    def test_serialize_includes_orchesjob_home(self):
        t = _make_trigger(orchesjob_home="/custom/home")
        _, kwargs = t.serialize()
        assert kwargs["orchesjob_home"] == "/custom/home"


class TestOrchesJobTriggerRun:
    async def _collect(self, trigger: OrchesJobTrigger):
        events = []
        async for event in trigger.run():
            events.append(event)
        return events

    @pytest.mark.asyncio
    async def test_succeeded_yields_event(self):
        trigger = _make_trigger()
        with patch.object(trigger, "_fetch_status", return_value={"status": "SUCCEEDED", "exit_code": 0, "finished_at": "2026-01-01T00:00:00Z", "stdout_file": "/tmp/a", "stderr_file": "/tmp/b"}):
            events = await self._collect(trigger)
        assert len(events) == 1
        assert events[0].payload["status"] == "SUCCEEDED"
        assert events[0].payload["exit_code"] == 0

    @pytest.mark.asyncio
    async def test_failed_yields_event(self):
        trigger = _make_trigger()
        with patch.object(trigger, "_fetch_status", return_value={"status": "FAILED", "exit_code": 1, "finished_at": "T", "stdout_file": "", "stderr_file": ""}):
            events = await self._collect(trigger)
        assert events[0].payload["status"] == "FAILED"

    @pytest.mark.asyncio
    async def test_startup_timeout(self):
        # job_started_at far in the past → timeout fires immediately
        trigger = _make_trigger(startup_timeout=0.0, job_started_at=time.monotonic() - 999)
        with patch.object(trigger, "_fetch_status", return_value={"status": "STARTING"}):
            events = await self._collect(trigger)
        assert events[0].payload["status"] == "STARTUP_TIMEOUT"

    @pytest.mark.asyncio
    async def test_running_then_succeeded(self):
        responses = [
            {"status": "RUNNING"},
            {"status": "SUCCEEDED", "exit_code": 0, "finished_at": "T", "stdout_file": "", "stderr_file": ""},
        ]
        trigger = _make_trigger()
        with patch.object(trigger, "_fetch_status", side_effect=responses):
            events = await self._collect(trigger)
        assert events[0].payload["status"] == "SUCCEEDED"

    @pytest.mark.asyncio
    async def test_ssh_error_limit(self):
        trigger = _make_trigger()
        with patch.object(trigger, "_fetch_status", side_effect=RuntimeError("connection refused")):
            events = await self._collect(trigger)
        assert events[0].payload["status"] == "SSH_ERROR"
        assert "connection refused" in events[0].payload["error"]

    @pytest.mark.asyncio
    async def test_ssh_transient_error_then_recovery(self):
        responses: list = [
            RuntimeError("timeout"),
            {"status": "SUCCEEDED", "exit_code": 0, "finished_at": "T", "stdout_file": "", "stderr_file": ""},
        ]
        trigger = _make_trigger()

        def _side_effect():
            r = responses.pop(0)
            if isinstance(r, Exception):
                raise r
            return r

        with patch.object(trigger, "_fetch_status", side_effect=_side_effect):
            events = await self._collect(trigger)
        assert events[0].payload["status"] == "SUCCEEDED"


class TestOrchesJobTriggerBuildCmd:
    def test_no_home(self):
        t = _make_trigger(orchesjob_home=None)
        cmd = t._build_cmd(["orchesjob", "status", "--job-id", "abc"])
        assert cmd == "orchesjob status --job-id abc"

    def test_with_home(self):
        t = _make_trigger(orchesjob_home="/var/lib/orchesjob")
        cmd = t._build_cmd(["orchesjob", "status", "--job-id", "abc"])
        assert cmd.startswith("ORCHESJOB_HOME=/var/lib/orchesjob")

    def test_home_with_spaces_is_quoted(self):
        t = _make_trigger(orchesjob_home="/path with spaces")
        cmd = t._build_cmd(["orchesjob", "status"])
        assert "'/path with spaces'" in cmd
