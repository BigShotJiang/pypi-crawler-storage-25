# SPDX-License-Identifier: MIT
# Copyright (c) 2026 Ryosuke Muraki
"""Tests for OrchesJobOperator."""

from __future__ import annotations

import json
from unittest.mock import MagicMock, patch

import pytest
from airflow.exceptions import AirflowException

from airflow_providers_orchesjob.operators.orchesjob import OrchesJobOperator
from airflow_providers_orchesjob.triggers.orchesjob import OrchesJobTrigger


def _make_operator(**kwargs) -> OrchesJobOperator:
    defaults = dict(
        task_id="test_task",
        command=["/jobs/import.sh"],
        ssh_conn_id="my_ssh",
    )
    defaults.update(kwargs)
    return OrchesJobOperator(**defaults)


def _make_context(dag_id="my_dag", task_id="my_task", run_id="manual__2026-01-01"):
    dag = MagicMock()
    dag.dag_id = dag_id
    task = MagicMock()
    task.task_id = task_id
    return {"dag": dag, "task": task, "run_id": run_id}


_START_RESPONSE = {
    "accepted": True,
    "existing": False,
    "job_id": "abc-123",
    "status": "RUNNING",
    "run_key": "test-key",
    "strict": False,
    "command": ["/jobs/import.sh"],
    "pid": 42,
    "stdout_file": "/var/lib/orchesjob/logs/abc-123.stdout",
    "stderr_file": "/var/lib/orchesjob/logs/abc-123.stderr",
    "exit_code": None,
    "started_at": "2026-01-01T00:00:00Z",
    "finished_at": None,
}


class TestOrchesJobOperatorResolveRunKey:
    def test_explicit_run_key(self):
        op = _make_operator(run_key="my-custom-key")
        ctx = _make_context()
        assert op._resolve_run_key(ctx) == "my-custom-key"

    def test_auto_run_key_format(self):
        op = _make_operator()
        ctx = _make_context(dag_id="d", task_id="t", run_id="r")
        assert op._resolve_run_key(ctx) == "d__t__r"


class TestOrchesJobOperatorExecute:
    def test_execute_defers(self):
        op = _make_operator()
        ctx = _make_context()

        with patch.object(op, "_ssh_start", return_value=_START_RESPONSE):
            with pytest.raises(Exception) as exc_info:
                op.execute(ctx)
            # Airflow raises TaskDeferred when defer() is called
            assert "TaskDeferred" in type(exc_info.value).__name__

    def test_execute_defers_with_correct_trigger(self):
        op = _make_operator(poll_interval=10.0, startup_timeout=120.0)
        ctx = _make_context()
        captured = {}

        def fake_defer(trigger, method_name):
            captured["trigger"] = trigger
            captured["method_name"] = method_name
            raise Exception("deferred")

        with patch.object(op, "_ssh_start", return_value=_START_RESPONSE):
            with patch.object(op, "defer", side_effect=fake_defer):
                with pytest.raises(Exception, match="deferred"):
                    op.execute(ctx)

        t = captured["trigger"]
        assert isinstance(t, OrchesJobTrigger)
        assert t.job_id == "abc-123"
        assert t.poll_interval == 10.0
        assert t.startup_timeout == 120.0
        assert captured["method_name"] == "execute_complete"

    def test_execute_passes_orchesjob_home(self):
        op = _make_operator(orchesjob_home="/custom/home")
        ctx = _make_context()
        captured = {}

        def fake_defer(trigger, method_name):
            captured["trigger"] = trigger
            raise Exception("deferred")

        with patch.object(op, "_ssh_start", return_value=_START_RESPONSE):
            with patch.object(op, "defer", side_effect=fake_defer):
                with pytest.raises(Exception):
                    op.execute(ctx)

        assert captured["trigger"].orchesjob_home == "/custom/home"

    def test_execute_ssh_failure_raises(self):
        op = _make_operator()
        ctx = _make_context()
        with patch.object(op, "_ssh_start", side_effect=AirflowException("SSH failed")):
            with pytest.raises(AirflowException, match="SSH failed"):
                op.execute(ctx)


class TestOrchesJobOperatorExecuteComplete:
    def test_succeeded_returns_event(self):
        op = _make_operator()
        event = {"status": "SUCCEEDED", "job_id": "abc-123", "exit_code": 0}
        result = op.execute_complete(context={}, event=event)
        assert result["status"] == "SUCCEEDED"

    def test_failed_raises(self):
        op = _make_operator()
        event = {"status": "FAILED", "job_id": "abc-123", "exit_code": 1}
        with pytest.raises(AirflowException, match="FAILED"):
            op.execute_complete(context={}, event=event)

    def test_lost_raises(self):
        op = _make_operator()
        event = {"status": "LOST", "job_id": "abc-123", "exit_code": None}
        with pytest.raises(AirflowException, match="LOST"):
            op.execute_complete(context={}, event=event)

    def test_startup_timeout_raises(self):
        op = _make_operator()
        event = {"status": "STARTUP_TIMEOUT", "job_id": "abc-123", "elapsed": 65.0}
        with pytest.raises(AirflowException, match="STARTING"):
            op.execute_complete(context={}, event=event)

    def test_ssh_error_raises(self):
        op = _make_operator()
        event = {"status": "SSH_ERROR", "job_id": "abc-123", "error": "connection refused"}
        with pytest.raises(AirflowException, match="SSH error"):
            op.execute_complete(context={}, event=event)


class TestOrchesJobOperatorBuildCmd:
    def test_command_quoting(self):
        op = _make_operator(command=["echo", "hello world"])
        cmd = op._build_cmd(["orchesjob", "start", "--", "echo", "hello world"])
        assert "'hello world'" in cmd

    def test_strict_flag_included(self):
        op = _make_operator(strict=True)
        ctx = _make_context()
        captured_cmd = {}

        def fake_ssh_start(run_key):
            # Check that _build_cmd was called with --strict in parts
            # We test via the full _ssh_start flow
            return _START_RESPONSE

        with patch.object(op, "_ssh_start", side_effect=fake_ssh_start):
            with patch.object(op, "defer", side_effect=Exception("deferred")):
                with pytest.raises(Exception):
                    op.execute(ctx)

    def test_ssh_start_includes_strict(self):
        """_build_cmd should include --strict when strict=True."""
        op = _make_operator(strict=True)
        parts = ["orchesjob", "start", "--run-key", "k", "--strict", "--", "true"]
        cmd = op._build_cmd(parts)
        assert "--strict" in cmd
