"""
_core.py
--------
Core FAPA estimation: ipsatization, SVD, person-level reconstruction.

Mirrors R FAPA functions:
  load_and_ipsatize()   row-centre a data matrix
  fapa_core()           thin SVD → core profiles, person weights, variance
  fapa_person()         person reconstruction R², pattern weights, CIs

Reference
---------
Kim, S.-K. (2024). Factorization of person response profiles to identify
    summative profiles carrying central response patterns.
    Psychological Methods, 29(4), 723–730. doi:10.1037/met0000568
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional, List

import numpy as np


# ─────────────────────────────────────────────────────────────────────────────
# Ipsatization
# ─────────────────────────────────────────────────────────────────────────────

def load_and_ipsatize(data, col_labels: Optional[List[str]] = None) -> dict:
    """
    Ipsatize (row-centre) a person-by-variable data matrix.

    Mirrors R ``FAPA::load_and_ipsatize()``.

    Parameters
    ----------
    data       : array-like or DataFrame (n_persons, n_vars).
    col_labels : optional list of variable names.

    Returns
    -------
    dict with keys:
      raw        original data as numpy array
      ipsatized  row-centred matrix (each row sums to ~0)
      row_means  per-person means (profile elevation)
      varnames   variable names
    """
    try:
        import pandas as pd
        if isinstance(data, pd.DataFrame):
            if col_labels is None:
                col_labels = list(data.columns)
            raw = data.values.astype(float)
        else:
            raw = np.asarray(data, dtype=float)
    except ImportError:
        raw = np.asarray(data, dtype=float)

    row_means  = raw.mean(axis=1)
    ipsatized  = raw - row_means[:, np.newaxis]

    return {
        "raw":       raw,
        "ipsatized": ipsatized,
        "row_means": row_means,
        "varnames":  col_labels or [f"V{j+1}" for j in range(raw.shape[1])],
    }


# ─────────────────────────────────────────────────────────────────────────────
# Core FAPA estimation
# ─────────────────────────────────────────────────────────────────────────────

def fapa_core(Xtilde, K: int, direction=None) -> dict:
    """
    Core FAPA estimation via thin SVD of an ipsatized matrix.

    Mirrors R ``FAPA::fapa_core()``.

    The core-profile (scale) matrix is defined as X = V * Sigma, so that
    each individual's ipsatized profile satisfies:
        m_tilde_p = X @ u_p   (rank-K reconstruction)

    Signs of singular vectors are normalised so that the element with the
    largest absolute value in each core-profile column is positive.

    Parameters
    ----------
    Xtilde    : array (n_persons, n_vars), already ipsatized.
    K         : int, number of components to extract.
    direction : array of ±1 (length K), override automatic sign convention.

    Returns
    -------
    dict with keys:
      U          (n_persons, K)  person-weight matrix
      S          (K,)            singular values
      V          (n_vars, K)     right singular vectors
      X          (n_vars, K)     core-profile matrix = V * S
      total_var  float           total ipsatized variance (Frobenius norm²)
      var_k      (K,)            variance per component (sigma_k²)
      prop_var   (K,)            proportion of variance per component
      cum_var    (K,)            cumulative proportion of variance
      person_cor (n_persons, K)  normalised person-core correlations
      direction  (K,)            sign vector applied
      K          int             number of components extracted
      varnames   list            variable names (empty if not supplied)
    """
    Xtilde = np.asarray(Xtilde, dtype=float)
    n, p   = Xtilde.shape

    if K < 1 or K > min(n, p):
        raise ValueError(f"K must be between 1 and min(n, p)={min(n,p)}; got {K}.")

    U_full, sv, Vt = np.linalg.svd(Xtilde, full_matrices=False)
    U = U_full[:, :K]
    S = sv[:K]
    V = Vt[:K].T          # (p, K)

    # Core-profile matrix X = V * S
    X = V * S[np.newaxis, :]   # (p, K) — each col is a core profile

    # Sign normalisation: largest-magnitude element in each col is positive
    if direction is None:
        direction = np.sign(X[np.abs(X).argmax(axis=0), np.arange(K)])
        direction[direction == 0] = 1.0
    else:
        direction = np.asarray(direction, dtype=float)

    U = U * direction[np.newaxis, :]
    V = V * direction[np.newaxis, :]
    X = X * direction[np.newaxis, :]

    # Variance decomposition
    total_var = float(np.sum(Xtilde ** 2))
    var_k     = S ** 2
    prop_var  = var_k / total_var if total_var > 0 else np.zeros(K)
    cum_var   = np.cumsum(prop_var)

    # Normalised person-core correlations
    u_norms       = np.linalg.norm(U, axis=1, keepdims=True)
    u_norms[u_norms < 1e-14] = 1.0
    person_cor    = U / u_norms

    return {
        "U":          U,
        "S":          S,
        "V":          V,
        "X":          X,
        "total_var":  total_var,
        "var_k":      var_k,
        "prop_var":   prop_var,
        "cum_var":    cum_var,
        "person_cor": person_cor,
        "direction":  direction,
        "K":          K,
        "varnames":   [],
    }


# ─────────────────────────────────────────────────────────────────────────────
# Person-level reconstruction
# ─────────────────────────────────────────────────────────────────────────────

def fapa_person(
    Xtilde,
    fit:         dict,
    participants: Optional[List[int]] = None,
    B_boot:      int   = 2000,
    alpha:       float = 0.05,
    seed:        Optional[int] = None,
) -> dict:
    """
    Person-level reconstruction R², pattern weights, and optional bootstrap CIs.

    Mirrors R ``FAPA::fapa_person()``.

    Parameters
    ----------
    Xtilde       : array (n_persons, n_vars), ipsatized.
    fit          : dict returned by fapa_core().
    participants : list of row indices for which bootstrap CIs are computed.
                   None = skip individual inference.
    B_boot       : bootstrap replicates for participant CIs (default 2000).
    alpha        : two-tailed significance level (default 0.05).
    seed         : random seed.

    Returns
    -------
    dict with keys:
      weights      DataFrame (n_persons rows): Person, Level, R2, w1..wK, rDim1..rDimK
      weights_B    bootstrap summary for selected participants (or None)
      R2_k         partial R² per dimension
      R2_mean      mean person reconstruction R² across all persons
    """
    try:
        import pandas as pd
        _has_pandas = True
    except ImportError:
        _has_pandas = False

    Xtilde = np.asarray(Xtilde, dtype=float)
    n, p   = Xtilde.shape
    K      = fit["K"]
    X      = fit["X"]          # core profiles (p, K)
    U      = fit["U"]          # person weights (n, K)
    S      = fit["S"]

    # Reconstruction R² per person
    X_hat  = U @ X.T           # (n, p) rank-K reconstruction
    ss_res = np.sum((Xtilde - X_hat) ** 2, axis=1)
    ss_tot = np.sum(Xtilde ** 2, axis=1)
    r2     = np.where(ss_tot > 1e-14, 1.0 - ss_res / ss_tot, 0.0)

    # Partial R² per dimension
    r2_k = fit["var_k"] / fit["total_var"] if fit["total_var"] > 0 else np.zeros(K)

    # Normalised person-core correlations
    u_norms = np.linalg.norm(U, axis=1, keepdims=True)
    u_norms[u_norms < 1e-14] = 1.0
    r_cor   = U / u_norms

    # Build weights DataFrame / dict
    rows = []
    for i in range(n):
        row = {
            "Person": i + 1,
            "R2":     round(float(r2[i]), 6),
        }
        for k in range(K):
            row[f"w{k+1}"]    = round(float(U[i, k]), 6)
            row[f"rDim{k+1}"] = round(float(r_cor[i, k]), 6)
        rows.append(row)

    if _has_pandas:
        weights_df = pd.DataFrame(rows)
    else:
        weights_df = rows

    # Optional bootstrap CIs for selected participants
    weights_B = None
    if participants is not None and len(participants) > 0:
        rng = np.random.default_rng(seed)
        boot_weights = np.zeros((B_boot, len(participants), K))
        for b in range(B_boot):
            idx    = rng.integers(0, n, n)
            Xb     = Xtilde[idx]
            _, sv_b, Vt_b = np.linalg.svd(Xb, full_matrices=False)
            Vb     = Vt_b[:K].T
            Xcore_b = Vb * sv_b[:K][np.newaxis, :]
            # Project selected participants
            for pi, pid in enumerate(participants):
                xp = Xtilde[pid]
                w_b = np.linalg.lstsq(Xcore_b, xp, rcond=None)[0]
                boot_weights[b, pi, :] = w_b

        z = float(np.abs(np.random.default_rng(seed).standard_normal(1)))
        alpha_half = alpha / 2.0
        weights_B = {
            "participants": participants,
            "mean":  boot_weights.mean(axis=0),
            "se":    boot_weights.std(axis=0),
            "lower": np.percentile(boot_weights, 100 * alpha_half, axis=0),
            "upper": np.percentile(boot_weights, 100 * (1 - alpha_half), axis=0),
        }

    return {
        "weights":   weights_df,
        "weights_B": weights_B,
        "R2_k":      r2_k,
        "R2_mean":   float(r2.mean()),
    }
