"""
_verification.py
----------------
Three-stage FAPA bootstrap verification framework.

Stage 1 — fapa_pa()         Variance-matched Horn's parallel analysis
Stage 2 — fapa_procrustes() Principal angles (subspace stability)
Stage 3 — fapa_tucker()     Tucker's congruence coefficients (profile replicability)

All three mirror the corresponding R FAPA functions exactly.

References
----------
Horn, J. L. (1965). Psychometrika, 30(2), 179–185.
Bjorck & Golub (1973). Mathematics of Computation, 27(123), 579–594.
Lorenzo-Seva & ten Berge (2006). Methodology, 2(2), 57–64.
Tucker, L. R. (1951). Personnel Research Section Report No. 984.
"""

from __future__ import annotations

from typing import Optional

import numpy as np


# ─────────────────────────────────────────────────────────────────────────────
# Internal helpers
# ─────────────────────────────────────────────────────────────────────────────

def _ipsatize(X: np.ndarray) -> np.ndarray:
    return X - X.mean(axis=1, keepdims=True)


def _svd_k(X: np.ndarray, K: int):
    """Return (U, sv[:K], V[:,:K]) from thin SVD of X."""
    U, sv, Vt = np.linalg.svd(X, full_matrices=False)
    return U[:, :K], sv[:K], Vt[:K].T


def _principal_angles(V_ref: np.ndarray, V_b: np.ndarray) -> np.ndarray:
    """
    Principal angles (degrees) between two column-orthonormal subspaces.
    V_ref and V_b are (p, K) matrices of right singular vectors.
    """
    sv = np.linalg.svd(V_ref.T @ V_b, compute_uv=False)
    sv = np.clip(sv, -1.0, 1.0)
    return np.sort(np.arccos(sv) * 180.0 / np.pi)


def _tucker_cc(v_ref: np.ndarray, v_b: np.ndarray) -> float:
    """Tucker's congruence coefficient between two vectors."""
    denom = float(np.sqrt((v_ref @ v_ref) * (v_b @ v_b)))
    return float(v_ref @ v_b) / denom if denom > 1e-14 else 0.0


def _align_signs(V_ref: np.ndarray, V_b: np.ndarray) -> np.ndarray:
    """
    Flip signs of each column of V_b so that it maximises |CC| with V_ref.
    """
    signs = np.sign(np.diag(V_ref.T @ V_b))
    signs[signs == 0] = 1.0
    return V_b * signs[np.newaxis, :]


# ─────────────────────────────────────────────────────────────────────────────
# Stage 1 — Variance-matched Horn's parallel analysis
# ─────────────────────────────────────────────────────────────────────────────

def fapa_pa(
    Xtilde,
    B:     int   = 2000,
    alpha: float = 0.05,
    seed:  Optional[int] = None,
) -> dict:
    """
    Stage 1 — Variance-matched Horn's parallel analysis.

    Mirrors R ``FAPA::fapa_pa()``.

    For each of B bootstrap replicates, a random matrix of identical
    dimensions is row-centred (ipsatized) and rescaled to the same Frobenius
    norm as Xtilde. This variance-matching step prevents raw-score data from
    trivially dominating N(0,1) random matrices.

    Components whose observed sigma_k² exceeds the (1-alpha) quantile of
    the matched null distribution are retained.

    Parameters
    ----------
    Xtilde : array (n_persons, n_vars), already ipsatized.
    B      : bootstrap replicates (default 2000).
    alpha  : significance level (default 0.05).
    seed   : random seed.

    Returns
    -------
    dict with keys:
      n_retain   int     number of components retained
      obs_sv2    array   observed squared singular values
      thresh     array   bootstrap (1-alpha) quantile per component
      prop_obs   array   proportion of variance per observed component
      prop_rand  array   mean proportion of variance per random component
      rand_sv2   array   (B, Kmax) matrix of random sigma²
      total_var  float   total ipsatized variance
      alpha, B   inputs echoed
    """
    rng    = np.random.default_rng(seed)
    X      = np.asarray(Xtilde, dtype=float)
    n, p   = X.shape
    Kmax   = min(n - 1, p - 1)

    _, sv, _ = np.linalg.svd(X, full_matrices=False)
    obs_sv2  = (sv ** 2)[:Kmax]
    total_var = float(np.sum(X ** 2))
    frob_norm = float(np.linalg.norm(X, "fro"))

    rand_sv2 = np.zeros((B, Kmax))
    for b in range(B):
        R   = rng.standard_normal((n, p))
        R   = _ipsatize(R)
        # Variance-match: scale to same Frobenius norm as Xtilde
        r_norm = float(np.linalg.norm(R, "fro"))
        if r_norm > 1e-14:
            R = R * (frob_norm / r_norm)
        _, sv_r, _ = np.linalg.svd(R, full_matrices=False)
        rand_sv2[b] = (sv_r ** 2)[:Kmax]

    thresh    = np.quantile(rand_sv2, 1.0 - alpha, axis=0)
    retain    = obs_sv2 > thresh
    n_retain  = max(1, int(retain.sum()))
    prop_obs  = obs_sv2 / total_var if total_var > 0 else np.zeros(Kmax)
    prop_rand = rand_sv2.mean(axis=0) / total_var if total_var > 0 else np.zeros(Kmax)

    return {
        "n_retain":  n_retain,
        "obs_sv2":   obs_sv2,
        "thresh":    thresh,
        "prop_obs":  prop_obs,
        "prop_rand": prop_rand,
        "rand_sv2":  rand_sv2,
        "total_var": total_var,
        "alpha":     alpha,
        "B":         B,
    }


# ─────────────────────────────────────────────────────────────────────────────
# Stage 2 — Procrustes principal angles (subspace stability)
# ─────────────────────────────────────────────────────────────────────────────

def fapa_procrustes(
    Xtilde,
    K:           int,
    B:           int   = 2000,
    angle_thresh: float = 30.0,
    seed:        Optional[int] = None,
) -> dict:
    """
    Stage 2 — Procrustes stability via principal angles.

    Mirrors R ``FAPA::fapa_procrustes()``.

    For each of B bootstrap resamples of the ipsatized data matrix, computes
    the K right singular vectors and measures the principal angles (degrees)
    between the bootstrap subspace and the original K-dimensional subspace.

    A replicate is declared stable when ALL K principal angles are strictly
    less than angle_thresh.

    Parameters
    ----------
    Xtilde       : array (n_persons, n_vars), already ipsatized.
    K            : number of dimensions to assess.
    B            : bootstrap replicates (default 2000).
    angle_thresh : upper stability bound in degrees (default 30°).
    seed         : random seed.

    Returns
    -------
    dict with keys:
      angles_mat   (B, K)   principal angles per replicate
      angle_mean   (K,)     per-dimension mean
      angle_sd     (K,)     per-dimension SD
      angle_q025   (K,)     2.5th percentile
      angle_q975   (K,)     97.5th percentile
      n_stable     int       number of stable replicates
      prop_stable  float     proportion of stable replicates
      angle_thresh, K, B    inputs echoed
    """
    rng    = np.random.default_rng(seed)
    X      = np.asarray(Xtilde, dtype=float)
    n, p   = X.shape

    _, _, V_ref = np.linalg.svd(X, full_matrices=False)
    V_ref = V_ref[:K].T    # (p, K) reference right singular vectors

    angles_mat = np.full((B, K), np.nan)
    for b in range(B):
        idx  = rng.integers(0, n, n)
        Xb   = X[idx]
        try:
            _, _, Vt_b = np.linalg.svd(Xb, full_matrices=False)
            V_b = Vt_b[:K].T
            angles_mat[b] = _principal_angles(V_ref, V_b)
        except Exception:
            pass

    angle_mean  = np.nanmean(angles_mat, axis=0)
    angle_sd    = np.nanstd(angles_mat, axis=0)
    angle_q025  = np.nanpercentile(angles_mat, 2.5, axis=0)
    angle_q975  = np.nanpercentile(angles_mat, 97.5, axis=0)
    stable      = np.all(angles_mat < angle_thresh, axis=1)
    n_stable    = int(np.nansum(stable))
    prop_stable = n_stable / B

    return {
        "angles_mat":   angles_mat,
        "angle_mean":   angle_mean,
        "angle_sd":     angle_sd,
        "angle_q025":   angle_q025,
        "angle_q975":   angle_q975,
        "n_stable":     n_stable,
        "prop_stable":  prop_stable,
        "angle_thresh": angle_thresh,
        "K":            K,
        "B":            B,
    }


# ─────────────────────────────────────────────────────────────────────────────
# Stage 3 — Tucker's congruence coefficients (profile replicability)
# ─────────────────────────────────────────────────────────────────────────────

def fapa_tucker(
    Xtilde,
    K:         int,
    B:         int   = 2000,
    cc_thresh: float = 0.85,
    seed:      Optional[int] = None,
) -> dict:
    """
    Stage 3 — Profile replicability via Tucker's congruence coefficients.

    Mirrors R ``FAPA::fapa_tucker()``.

    For each of B bootstrap resamples, computes Tucker's CC between each
    original core profile (V * S column) and its bootstrap counterpart.
    Sign ambiguity is resolved by choosing the sign that maximises |CC|.

    Conventional thresholds (Lorenzo-Seva & ten Berge, 2006):
      CC >= 0.95 : high similarity ("factor replication")
      CC >= 0.85 : fair similarity
      CC <  0.85 : poor similarity

    Parameters
    ----------
    Xtilde    : array (n_persons, n_vars), already ipsatized.
    K         : number of core profiles to assess.
    B         : bootstrap replicates (default 2000).
    cc_thresh : acceptability lower bound (default 0.85).
    seed      : random seed.

    Returns
    -------
    dict with keys:
      cc_mat     (B, K)   Tucker CCs per replicate
      cc_mean    (K,)     per-profile mean CC
      cc_sd      (K,)     per-profile SD
      cc_q025    (K,)     2.5th percentile
      cc_q975    (K,)     97.5th percentile
      cc_thresh, K, B     inputs echoed
    """
    rng   = np.random.default_rng(seed)
    X     = np.asarray(Xtilde, dtype=float)
    n, p  = X.shape

    _, sv_ref, Vt_ref = np.linalg.svd(X, full_matrices=False)
    V_ref = Vt_ref[:K].T             # (p, K)
    X_ref = V_ref * sv_ref[:K]       # core profiles (p, K)

    cc_mat = np.full((B, K), np.nan)
    for b in range(B):
        idx  = rng.integers(0, n, n)
        Xb   = X[idx]
        try:
            _, sv_b, Vt_b = np.linalg.svd(Xb, full_matrices=False)
            V_b   = Vt_b[:K].T
            X_b   = V_b * sv_b[:K]   # bootstrap core profiles
            V_b_aligned = _align_signs(V_ref, X_b)
            for k in range(K):
                cc_mat[b, k] = _tucker_cc(X_ref[:, k], V_b_aligned[:, k])
        except Exception:
            pass

    cc_mean  = np.nanmean(cc_mat, axis=0)
    cc_sd    = np.nanstd(cc_mat, axis=0)
    cc_q025  = np.nanpercentile(cc_mat, 2.5, axis=0)
    cc_q975  = np.nanpercentile(cc_mat, 97.5, axis=0)

    return {
        "cc_mat":    cc_mat,
        "cc_mean":   cc_mean,
        "cc_sd":     cc_sd,
        "cc_q025":   cc_q025,
        "cc_q975":   cc_q975,
        "cc_thresh": cc_thresh,
        "K":         K,
        "B":         B,
    }
