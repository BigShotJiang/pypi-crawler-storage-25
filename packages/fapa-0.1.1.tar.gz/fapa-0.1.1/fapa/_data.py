"""
_data.py — built-in dataset for FAPA.

fapa_simdata : 500 synthetic cases, 22 EDI-2 variables (11 pre + 11 post).

Simulates the two-component structure described in Kim (2024):
  CP1 — normative symptom gradient (pre/post correlated)
  CP2 — pre/post treatment change contrast (pre positive, post negative)

EDI-2 subscales (11):
  Dt  Drive for Thinness
  Bu  Bulimia
  Bd  Body Dissatisfaction
  In  Ineffectiveness
  Pf  Perfectionism
  Id  Interpersonal Distrust
  Ia  Interoceptive Awareness
  Mf  Maturity Fears
  As  Asceticism
  Ir  Impulse Regulation
  Si  Social Insecurity
"""

from __future__ import annotations
import numpy as np

EDI2_ABBR = ["Dt","Bu","Bd","In","Pf","Id","Ia","Mf","As","Ir","Si"]

FAPA_PRE_COLS  = [f"Before_{i+1}_{a}" for i, a in enumerate(EDI2_ABBR)]
FAPA_POST_COLS = [f"After_{i+1}_{a}"  for i, a in enumerate(EDI2_ABBR)]
FAPA_COLS      = FAPA_PRE_COLS + FAPA_POST_COLS


def _make_fapa_simdata(seed: int = 20260408) -> "np.ndarray":
    """
    Simulate 500 × 22 EDI-2 profile data with two latent components.

    CP1 (symptom severity): positively loads all 22 variables.
    CP2 (change contrast):  positively loads pre-, negatively loads post-.
    """
    rng = np.random.default_rng(seed)
    n, p = 500, 22

    # Two latent person scores
    severity = rng.normal(0, 1, n)     # CP1
    change   = rng.normal(0, 1, n)     # CP2

    # Loadings:  pre columns load +CP1 +0.6*CP2, post load +CP1 -0.6*CP2
    pre_load  = 0.7 * severity[:, np.newaxis] + 0.5 * change[:, np.newaxis]
    post_load = 0.7 * severity[:, np.newaxis] - 0.5 * change[:, np.newaxis]

    # Add item-specific variance
    noise = rng.normal(0, 0.6, (n, p))
    X_cont = np.hstack([pre_load + noise[:, :11],
                        post_load + noise[:, 11:]])

    # Scale and discretize to integer range 0–40
    for j in range(p):
        col = X_cont[:, j]
        col = (col - col.min()) / (col.max() - col.min() + 1e-9)
        X_cont[:, j] = np.round(col * 40).astype(float)

    return X_cont.astype(float)


fapa_simdata = _make_fapa_simdata()


def load_fapa_simdata():
    """
    Return fapa_simdata as a pandas DataFrame with proper column names.

    Raises ImportError if pandas is not installed.
    """
    try:
        import pandas as pd
    except ImportError as exc:
        raise ImportError(
            "load_fapa_simdata() requires pandas.  "
            "Install with: pip install pandas"
        ) from exc
    return pd.DataFrame(fapa_simdata, columns=FAPA_COLS)
