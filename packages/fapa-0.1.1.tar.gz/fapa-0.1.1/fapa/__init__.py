"""
fapa — Factor Analytic Profile Analysis of Ipsatized Data.
Python port of the R FAPA package (CRAN, Kim 2026).
"""
from ._core         import load_and_ipsatize, fapa_core, fapa_person
from ._verification import fapa_pa, fapa_procrustes, fapa_tucker
from ._bca          import fapa_bca
from ._utils        import (print_pa, print_procrustes, print_tucker,
                             write_fapa_results, write_verification)
from ._data         import fapa_simdata, load_fapa_simdata, FAPA_COLS, FAPA_PRE_COLS, FAPA_POST_COLS

__all__ = [
    "load_and_ipsatize", "fapa_core", "fapa_person",
    "fapa_pa", "fapa_procrustes", "fapa_tucker",
    "fapa_bca",
    "print_pa", "print_procrustes", "print_tucker",
    "write_fapa_results", "write_verification",
    "fapa_simdata", "load_fapa_simdata",
    "FAPA_COLS", "FAPA_PRE_COLS", "FAPA_POST_COLS",
]
__version__ = "0.1.1"
__author__  = "Se-Kang Kim"
__email__   = "se-kang.kim@bcm.edu"
__license__ = "MIT"
