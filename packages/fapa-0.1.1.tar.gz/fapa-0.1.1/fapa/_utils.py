"""
_utils.py — print and write utilities for FAPA.

Mirrors R functions:
  print_pa()           formatted Stage 1 summary
  print_procrustes()   formatted Stage 2 summary
  print_tucker()       formatted Stage 3 summary
  write_fapa_results() write BCa CI tables to CSV
  write_verification() write all three stages to CSV
"""

from __future__ import annotations

from typing import Optional
import numpy as np


def print_pa(pa: dict) -> None:
    """
    Print a formatted summary of Stage 1 parallel analysis.
    Mirrors R ``FAPA::print_pa()``.
    """
    n     = pa["n_retain"]
    obs   = pa["obs_sv2"]
    thr   = pa["thresh"]
    pobs  = pa["prop_obs"]
    prand = pa["prop_rand"]

    print(f"\n{'─'*60}")
    print(f"  Stage 1 — Horn's Parallel Analysis (B={pa['B']}, α={pa['alpha']})")
    print(f"  Components retained: {n}")
    print(f"{'─'*60}")
    print(f"  {'Comp':>4}  {'Obs σ²':>10}  {'Thresh':>10}  "
          f"{'%Obs':>7}  {'%Rand':>7}  {'Retain':>6}")
    print(f"  {'────':>4}  {'──────':>10}  {'──────':>10}  "
          f"{'────':>7}  {'─────':>7}  {'──────':>6}")
    for k in range(len(obs)):
        r = "✓" if obs[k] > thr[k] else "✗"
        print(f"  {k+1:>4}  {obs[k]:>10.4f}  {thr[k]:>10.4f}  "
              f"{pobs[k]*100:>6.1f}%  {prand[k]*100:>6.1f}%  {r:>6}")
    print(f"{'─'*60}\n")


def print_procrustes(pr: dict, K_pa: Optional[int] = None) -> None:
    """
    Print a formatted summary of Stage 2 principal angles.
    Mirrors R ``FAPA::print_procrustes()``.
    """
    print(f"\n{'─'*68}")
    print(f"  Stage 2 — Procrustes Stability  "
          f"(B={pr['B']}, thresh={pr['angle_thresh']}°)")
    print(f"  Stable replicates: {pr['n_stable']}/{pr['B']} "
          f"({pr['prop_stable']*100:.1f}%)")
    print(f"{'─'*68}")
    hdr = f"  {'Dim':>3}  {'Mean°':>8}  {'SD':>7}  {'Q2.5':>7}  {'Q97.5':>7}"
    if K_pa is not None:
        hdr += f"  {'PA_Ret':>6}"
    print(hdr)
    print(f"  {'───':>3}  {'─────':>8}  {'──':>7}  {'────':>7}  {'─────':>7}"
          + (f"  {'──────':>6}" if K_pa else ""))
    for k in range(pr["K"]):
        row = (f"  {k+1:>3}  {pr['angle_mean'][k]:>8.2f}  "
               f"{pr['angle_sd'][k]:>7.2f}  "
               f"{pr['angle_q025'][k]:>7.2f}  "
               f"{pr['angle_q975'][k]:>7.2f}")
        if K_pa is not None:
            row += f"  {'✓' if k < K_pa else '✗':>6}"
        print(row)
    print(f"{'─'*68}\n")


def print_tucker(tc: dict, cc_thresh: float = 0.85,
                 K_pa: Optional[int] = None) -> None:
    """
    Print a formatted summary of Stage 3 Tucker CCs.
    Mirrors R ``FAPA::print_tucker()``.
    """
    print(f"\n{'─'*68}")
    print(f"  Stage 3 — Tucker Congruence Coefficients  "
          f"(B={tc['B']}, thresh={cc_thresh})")
    print(f"{'─'*68}")
    hdr = f"  {'Prof':>4}  {'Mean CC':>8}  {'SD':>7}  {'Q2.5':>7}  {'Q97.5':>7}  {'Grade':>7}"
    if K_pa is not None:
        hdr += f"  {'PA_Ret':>6}"
    print(hdr)
    print(f"  {'────':>4}  {'───────':>8}  {'──':>7}  {'────':>7}  "
          f"{'─────':>7}  {'─────':>7}"
          + (f"  {'──────':>6}" if K_pa else ""))
    for k in range(tc["K"]):
        m = tc["cc_mean"][k]
        grade = "High" if m >= 0.95 else ("Fair" if m >= 0.85 else "Poor")
        row = (f"  {k+1:>4}  {m:>8.4f}  {tc['cc_sd'][k]:>7.4f}  "
               f"{tc['cc_q025'][k]:>7.4f}  {tc['cc_q975'][k]:>7.4f}  "
               f"{grade:>7}")
        if K_pa is not None:
            row += f"  {'✓' if k < K_pa else '✗':>6}"
        print(row)
    print(f"{'─'*68}\n")


def write_fapa_results(bca: dict, prefix: str) -> list:
    """
    Write core-profile BCa CI tables to CSV.
    Mirrors R ``FAPA::write_fapa_results()``.

    Parameters
    ----------
    bca    : dict returned by fapa_bca().
    prefix : base name for output files.

    Returns
    -------
    list of file paths written.
    """
    try:
        import pandas as pd
    except ImportError as exc:
        raise ImportError("write_fapa_results() requires pandas.") from exc

    paths = []
    for k, ci_df in enumerate(bca["ci"]):
        path = f"{prefix}_CoreProfile{k+1}.csv"
        if isinstance(ci_df, pd.DataFrame):
            ci_df.to_csv(path, index=False)
        else:
            pd.DataFrame(ci_df).to_csv(path, index=False)
        paths.append(path)
        print(f"  Written: {path}")
    return paths


def write_verification(pa: dict, pr: dict, tc: dict,
                       prefix: str, K_pa: Optional[int] = None) -> dict:
    """
    Write three-stage verification results to CSV.
    Mirrors R ``FAPA::write_verification()``.

    Returns
    -------
    dict of {"pa": path, "procrustes": path, "tucker": path}
    """
    try:
        import pandas as pd
    except ImportError as exc:
        raise ImportError("write_verification() requires pandas.") from exc

    # Stage 1
    path_pa = f"{prefix}_stage1_pa.csv"
    df_pa = pd.DataFrame({
        "Component": np.arange(1, len(pa["obs_sv2"]) + 1),
        "Obs_sv2":   np.round(pa["obs_sv2"], 6),
        "Thresh":    np.round(pa["thresh"], 6),
        "Prop_obs":  np.round(pa["prop_obs"], 6),
        "Prop_rand": np.round(pa["prop_rand"], 6),
        "Retain":    pa["obs_sv2"] > pa["thresh"],
    })
    df_pa.to_csv(path_pa, index=False)

    # Stage 2
    path_pr = f"{prefix}_stage2_procrustes.csv"
    df_pr = pd.DataFrame({
        "Dim":        np.arange(1, pr["K"] + 1),
        "Mean_angle": np.round(pr["angle_mean"], 4),
        "SD_angle":   np.round(pr["angle_sd"], 4),
        "Q025":       np.round(pr["angle_q025"], 4),
        "Q975":       np.round(pr["angle_q975"], 4),
    })
    if K_pa is not None:
        df_pr["PA_Retained"] = np.arange(1, pr["K"] + 1) <= K_pa
    df_pr.to_csv(path_pr, index=False)

    # Stage 3
    path_tc = f"{prefix}_stage3_tucker.csv"
    df_tc = pd.DataFrame({
        "Profile":  np.arange(1, tc["K"] + 1),
        "Mean_CC":  np.round(tc["cc_mean"], 4),
        "SD_CC":    np.round(tc["cc_sd"], 4),
        "Q025":     np.round(tc["cc_q025"], 4),
        "Q975":     np.round(tc["cc_q975"], 4),
    })
    if K_pa is not None:
        df_tc["PA_Retained"] = np.arange(1, tc["K"] + 1) <= K_pa
    df_tc.to_csv(path_tc, index=False)

    print(f"  Written: {path_pa}, {path_pr}, {path_tc}")
    return {"pa": path_pa, "procrustes": path_pr, "tucker": path_tc}
