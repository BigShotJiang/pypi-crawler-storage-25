"""
_bca.py
-------
BCa bootstrap confidence intervals for FAPA core-profile coordinates.

Mirrors R ``FAPA::fapa_bca()``.

BCa (bias-corrected and accelerated) intervals are the gold standard for
bootstrap inference because they correct for both bias and skewness in the
bootstrap distribution. They are superior to percentile intervals for small
samples and skewed distributions — both common in clinical profile data.

Sign ambiguity across bootstrap resamples is resolved via an inner-product
alignment rule, ensuring each bootstrap distribution is unimodal before
BCa adjustment.

Reference
---------
Davison, A. C., & Hinkley, D. V. (1997). Bootstrap Methods and Their
    Application. Cambridge University Press.
    doi:10.1017/CBO9780511802843
"""

from __future__ import annotations

from typing import Optional

import numpy as np
from scipy.stats import norm


# ─────────────────────────────────────────────────────────────────────────────
# Internal helpers
# ─────────────────────────────────────────────────────────────────────────────

def _align_boot_signs(x0: np.ndarray, x_boot: np.ndarray) -> np.ndarray:
    """
    Align signs of each bootstrap draw to match the reference x0,
    using inner-product sign rule (maximise dot product with reference).

    Parameters
    ----------
    x0     : (p,) reference core profile.
    x_boot : (B, p) bootstrap draws.

    Returns
    -------
    x_aligned : (B, p) sign-corrected bootstrap draws.
    """
    signs = np.sign(x_boot @ x0)
    signs[signs == 0] = 1.0
    return x_boot * signs[:, np.newaxis]


def _bca_interval(theta_hat: float, boot_vals: np.ndarray, alpha: float):
    """
    Compute BCa confidence interval for a scalar estimator.

    Parameters
    ----------
    theta_hat : observed statistic.
    boot_vals : (B,) bootstrap values of the statistic.
    alpha     : two-tailed significance level.

    Returns
    -------
    (lower, upper, bias_z0, accel_a)
    """
    B = len(boot_vals)

    # Bias correction z0
    prop_less = np.mean(boot_vals < theta_hat)
    prop_less = np.clip(prop_less, 1e-6, 1.0 - 1e-6)
    z0 = norm.ppf(prop_less)

    # Acceleration a via jackknife
    jack_vals = np.array([
        np.mean(np.delete(boot_vals, i)) for i in range(min(B, 200))
    ])
    jack_mean = jack_vals.mean()
    num   = np.sum((jack_mean - jack_vals) ** 3)
    denom = 6.0 * (np.sum((jack_mean - jack_vals) ** 2) ** 1.5)
    a = num / denom if denom > 1e-14 else 0.0

    z_alpha_lo = norm.ppf(alpha / 2.0)
    z_alpha_hi = norm.ppf(1.0 - alpha / 2.0)

    def _adj_quantile(z_alpha):
        num_  = z0 + z_alpha
        q     = norm.cdf(z0 + num_ / (1.0 - a * num_))
        return float(np.percentile(boot_vals, 100.0 * q))

    lo = _adj_quantile(z_alpha_lo)
    hi = _adj_quantile(z_alpha_hi)
    return lo, hi, z0, a


# ─────────────────────────────────────────────────────────────────────────────
# Public function
# ─────────────────────────────────────────────────────────────────────────────

def fapa_bca(
    Xtilde,
    K:     int,
    B:     int   = 2000,
    alpha: float = 0.05,
    seed:  Optional[int] = None,
) -> dict:
    """
    BCa bootstrap confidence intervals for FAPA core-profile coordinates.

    Mirrors R ``FAPA::fapa_bca()``.

    Parameters
    ----------
    Xtilde : array (n_persons, n_vars), already ipsatized.
    K      : number of core profiles (should equal n_retain from fapa_pa).
    B      : bootstrap replicates (default 2000).
    alpha  : two-tailed significance level (default 0.05).
    seed   : random seed.

    Returns
    -------
    dict with keys:
      ci        list of K DataFrames (one per core profile) with columns:
                  Var, Ori, Mean, SE, Lower, Upper, BCaLower, BCaUpper
      X0        (n_vars, K) original core-profile matrix
      boot_X    (B, n_vars, K) bootstrap core profiles (sign-aligned)
      K, B, alpha, varnames   inputs echoed

    Examples
    --------
    >>> from fapa import load_and_ipsatize, fapa_pa, fapa_bca, fapa_simdata
    >>> d = load_and_ipsatize(fapa_simdata)
    >>> pa = fapa_pa(d["ipsatized"], B=200, seed=42)
    >>> bca = fapa_bca(d["ipsatized"], K=pa["n_retain"], B=200, seed=42)
    >>> print(bca["ci"][0].round(3))
    """
    try:
        import pandas as pd
        _has_pandas = True
    except ImportError:
        _has_pandas = False

    rng   = np.random.default_rng(seed)
    X     = np.asarray(Xtilde, dtype=float)
    n, p  = X.shape

    # Reference core profiles
    _, sv_ref, Vt_ref = np.linalg.svd(X, full_matrices=False)
    V_ref = Vt_ref[:K].T
    X0    = V_ref * sv_ref[:K]   # (p, K)

    # Bootstrap draws
    boot_X = np.zeros((B, p, K))
    for b in range(B):
        idx    = rng.integers(0, n, n)
        Xb     = X[idx]
        _, sv_b, Vt_b = np.linalg.svd(Xb, full_matrices=False)
        V_b    = Vt_b[:K].T
        X_b    = V_b * sv_b[:K]
        # Sign alignment per core profile
        for k in range(K):
            sign = np.sign(float(X0[:, k] @ X_b[:, k]))
            boot_X[b, :, k] = X_b[:, k] * (sign if sign != 0 else 1.0)

    varnames = [f"V{j+1}" for j in range(p)]

    # BCa CIs per core profile
    ci_list = []
    for k in range(K):
        rows = []
        for j in range(p):
            theta_hat = float(X0[j, k])
            boot_vals = boot_X[:, j, k]
            mean_b    = float(boot_vals.mean())
            se_b      = float(boot_vals.std(ddof=1))
            lo_pct    = float(np.percentile(boot_vals, 100 * alpha / 2.0))
            hi_pct    = float(np.percentile(boot_vals, 100 * (1 - alpha / 2.0)))
            lo_bca, hi_bca, _, _ = _bca_interval(theta_hat, boot_vals, alpha)
            rows.append({
                "Var":       varnames[j],
                "Ori":       round(theta_hat, 6),
                "Mean":      round(mean_b, 6),
                "SE":        round(se_b, 6),
                "Lower":     round(lo_pct, 6),
                "Upper":     round(hi_pct, 6),
                "BCaLower":  round(lo_bca, 6),
                "BCaUpper":  round(hi_bca, 6),
            })
        if _has_pandas:
            import pandas as pd
            ci_list.append(pd.DataFrame(rows))
        else:
            ci_list.append(rows)

    return {
        "ci":       ci_list,
        "X0":       X0,
        "boot_X":   boot_X,
        "K":        K,
        "B":        B,
        "alpha":    alpha,
        "varnames": varnames,
    }
