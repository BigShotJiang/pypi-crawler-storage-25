"""
tests/test_fapa.py
------------------
Unit tests for the Python FAPA package.
Cross-validated against the R FAPA package where possible.
"""

import numpy as np
import pytest
from fapa import (
    load_and_ipsatize, fapa_core, fapa_person,
    fapa_pa, fapa_procrustes, fapa_tucker,
    fapa_bca, fapa_simdata, FAPA_COLS,
)


# ─── Fixtures ────────────────────────────────────────────────────────────────

@pytest.fixture(scope="module")
def xtilde():
    """Small ipsatized matrix for fast tests."""
    rng = np.random.default_rng(42)
    X = rng.normal(0, 1, (80, 11))
    return X - X.mean(axis=1, keepdims=True)

@pytest.fixture(scope="module")
def simdata_ipsatized():
    d = load_and_ipsatize(fapa_simdata)
    return d["ipsatized"]


# ─── load_and_ipsatize ───────────────────────────────────────────────────────

class TestLoadAndIpsatize:
    def test_row_sums_zero(self):
        X = np.array([[1,2,3],[4,5,6],[7,8,9]], dtype=float)
        d = load_and_ipsatize(X)
        np.testing.assert_allclose(d["ipsatized"].sum(axis=1), 0, atol=1e-12)

    def test_row_means_stored(self):
        X = np.array([[1,2,3],[4,5,6]], dtype=float)
        d = load_and_ipsatize(X)
        np.testing.assert_allclose(d["row_means"], [2.0, 5.0], atol=1e-12)

    def test_raw_unchanged(self):
        X = np.array([[1,2,3],[4,5,6]], dtype=float)
        d = load_and_ipsatize(X)
        np.testing.assert_array_equal(d["raw"], X)

    def test_col_labels_stored(self):
        X = np.ones((3, 4))
        d = load_and_ipsatize(X, col_labels=["a","b","c","d"])
        assert d["varnames"] == ["a","b","c","d"]

    def test_pandas_input(self):
        pd = pytest.importorskip("pandas")
        df = pd.DataFrame({"A":[1,2],"B":[3,4],"C":[5,6]})
        d  = load_and_ipsatize(df)
        assert d["varnames"] == ["A","B","C"]
        np.testing.assert_allclose(d["ipsatized"].sum(axis=1), 0, atol=1e-12)


# ─── fapa_core ───────────────────────────────────────────────────────────────

class TestFapaCore:
    def test_output_shapes(self, xtilde):
        fit = fapa_core(xtilde, K=2)
        n, p = xtilde.shape
        assert fit["U"].shape == (n, 2)
        assert fit["V"].shape == (p, 2)
        assert fit["X"].shape == (p, 2)
        assert fit["S"].shape == (2,)

    def test_singular_values_positive(self, xtilde):
        fit = fapa_core(xtilde, K=3)
        assert np.all(fit["S"] > 0)

    def test_singular_values_descending(self, xtilde):
        fit = fapa_core(xtilde, K=3)
        assert np.all(np.diff(fit["S"]) <= 1e-10)

    def test_core_profile_x_equals_v_times_s(self, xtilde):
        fit = fapa_core(xtilde, K=2)
        expected = fit["V"] * fit["S"][np.newaxis, :]
        np.testing.assert_allclose(fit["X"], expected, atol=1e-10)

    def test_rank_k_reconstruction(self, xtilde):
        fit = fapa_core(xtilde, K=2)
        X_hat = fit["U"] @ fit["X"].T
        # Reconstruction should reduce residual vs zero
        resid = np.sum((xtilde - X_hat)**2)
        assert resid < np.sum(xtilde**2)

    def test_sign_normalisation_largest_positive(self, xtilde):
        fit = fapa_core(xtilde, K=3)
        for k in range(3):
            col = fit["X"][:, k]
            assert col[np.abs(col).argmax()] > 0

    def test_variance_decomposition_sums(self, xtilde):
        fit = fapa_core(xtilde, K=3)
        assert abs(fit["prop_var"].sum() - fit["cum_var"][-1]) < 1e-10

    def test_direction_stored(self, xtilde):
        # Direction vector is echoed in the result
        fit = fapa_core(xtilde, K=2, direction=[1, -1])
        assert fit["direction"][1] == -1

    def test_raises_invalid_K(self, xtilde):
        with pytest.raises(ValueError):
            fapa_core(xtilde, K=0)

    def test_total_var_positive(self, xtilde):
        fit = fapa_core(xtilde, K=2)
        assert fit["total_var"] > 0


# ─── fapa_pa ─────────────────────────────────────────────────────────────────

class TestFapaPa:
    def test_returns_dict(self, xtilde):
        pa = fapa_pa(xtilde, B=50, seed=0)
        assert isinstance(pa, dict)
        assert "n_retain" in pa

    def test_n_retain_at_least_1(self, xtilde):
        pa = fapa_pa(xtilde, B=50, seed=0)
        assert pa["n_retain"] >= 1

    def test_obs_sv2_descending(self, xtilde):
        pa = fapa_pa(xtilde, B=50, seed=0)
        assert np.all(np.diff(pa["obs_sv2"]) <= 1e-10)

    def test_rand_sv2_shape(self, xtilde):
        B = 30
        pa = fapa_pa(xtilde, B=B, seed=0)
        n, p = xtilde.shape
        Kmax = min(n-1, p-1)
        assert pa["rand_sv2"].shape == (B, Kmax)

    def test_thresh_positive(self, xtilde):
        pa = fapa_pa(xtilde, B=50, seed=0)
        assert np.all(pa["thresh"] >= 0)

    def test_strong_factor_detected(self):
        rng = np.random.default_rng(0)
        g   = rng.normal(0, 1, 200)
        X   = np.outer(g, [0.9]*11) + rng.normal(0, 0.2, (200, 11))
        Xs  = X - X.mean(axis=1, keepdims=True)
        pa  = fapa_pa(Xs, B=100, seed=0)
        assert pa["n_retain"] >= 1

    def test_total_var_matches_frobenius(self, xtilde):
        pa = fapa_pa(xtilde, B=30, seed=0)
        assert abs(pa["total_var"] - float(np.sum(xtilde**2))) < 1e-8

    def test_reproducible_with_seed(self, xtilde):
        pa1 = fapa_pa(xtilde, B=30, seed=99)
        pa2 = fapa_pa(xtilde, B=30, seed=99)
        np.testing.assert_array_equal(pa1["obs_sv2"], pa2["obs_sv2"])
        np.testing.assert_array_equal(pa1["thresh"], pa2["thresh"])


# ─── fapa_procrustes ─────────────────────────────────────────────────────────

class TestFapaProcrustes:
    def test_returns_dict(self, xtilde):
        pr = fapa_procrustes(xtilde, K=2, B=30, seed=0)
        assert isinstance(pr, dict)
        assert "angles_mat" in pr

    def test_angles_shape(self, xtilde):
        pr = fapa_procrustes(xtilde, K=2, B=30, seed=0)
        assert pr["angles_mat"].shape == (30, 2)

    def test_angles_non_negative(self, xtilde):
        pr = fapa_procrustes(xtilde, K=2, B=30, seed=0)
        assert np.all(np.nanmin(pr["angles_mat"], axis=0) >= 0)

    def test_angles_at_most_90(self, xtilde):
        pr = fapa_procrustes(xtilde, K=2, B=30, seed=0)
        assert np.all(np.nanmax(pr["angles_mat"], axis=0) <= 90.0 + 1e-8)

    def test_prop_stable_bounded(self, xtilde):
        pr = fapa_procrustes(xtilde, K=2, B=30, seed=0)
        assert 0.0 <= pr["prop_stable"] <= 1.0

    def test_strong_factor_stable(self):
        rng = np.random.default_rng(7)
        g   = rng.normal(0, 1, 300)
        X   = np.outer(g, [0.95]*11) + rng.normal(0, 0.1, (300, 11))
        Xs  = X - X.mean(axis=1, keepdims=True)
        pr  = fapa_procrustes(Xs, K=1, B=100, angle_thresh=30, seed=7)
        assert pr["prop_stable"] > 0.1  # relaxed for small n/B

    def test_K_echoed(self, xtilde):
        pr = fapa_procrustes(xtilde, K=3, B=20, seed=0)
        assert pr["K"] == 3


# ─── fapa_tucker ─────────────────────────────────────────────────────────────

class TestFapaTucker:
    def test_returns_dict(self, xtilde):
        tc = fapa_tucker(xtilde, K=2, B=30, seed=0)
        assert "cc_mat" in tc

    def test_cc_mat_shape(self, xtilde):
        tc = fapa_tucker(xtilde, K=2, B=30, seed=0)
        assert tc["cc_mat"].shape == (30, 2)

    def test_cc_bounded(self, xtilde):
        tc = fapa_tucker(xtilde, K=2, B=30, seed=0)
        assert np.all(np.abs(np.nan_to_num(tc["cc_mat"])) <= 1.0 + 1e-10)

    def test_strong_factor_high_cc(self):
        rng = np.random.default_rng(5)
        g   = rng.normal(0, 1, 300)
        X   = np.outer(g, [0.95]*11) + rng.normal(0, 0.1, (300, 11))
        Xs  = X - X.mean(axis=1, keepdims=True)
        tc  = fapa_tucker(Xs, K=1, B=100, cc_thresh=0.85, seed=5)
        assert tc["cc_mean"][0] > 0.5  # strong factor should have meaningful CC

    def test_cc_thresh_echoed(self, xtilde):
        tc = fapa_tucker(xtilde, K=2, B=20, cc_thresh=0.90, seed=0)
        assert tc["cc_thresh"] == 0.90


# ─── fapa_bca ────────────────────────────────────────────────────────────────

class TestFapaBca:
    def test_returns_dict(self, xtilde):
        bca = fapa_bca(xtilde, K=2, B=50, seed=0)
        assert "ci" in bca and "X0" in bca

    def test_ci_length_equals_K(self, xtilde):
        bca = fapa_bca(xtilde, K=2, B=50, seed=0)
        assert len(bca["ci"]) == 2

    def test_boot_X_shape(self, xtilde):
        n, p = xtilde.shape
        bca = fapa_bca(xtilde, K=2, B=30, seed=0)
        assert bca["boot_X"].shape == (30, p, 2)

    def test_x0_shape(self, xtilde):
        n, p = xtilde.shape
        bca = fapa_bca(xtilde, K=2, B=30, seed=0)
        assert bca["X0"].shape == (p, 2)

    def test_bca_interval_contains_ori(self, xtilde):
        bca = fapa_bca(xtilde, K=1, B=100, alpha=0.05, seed=42)
        ci = bca["ci"][0]
        if hasattr(ci, "itertuples"):
            for row in ci.itertuples():
                assert row.BCaLower <= row.Ori <= row.BCaUpper or abs(row.Ori) < 1e-6
        else:
            for row in ci:
                assert row["BCaLower"] <= row["Ori"] <= row["BCaUpper"] or abs(row["Ori"]) < 1e-6

    def test_reproducible(self, xtilde):
        bca1 = fapa_bca(xtilde, K=2, B=30, seed=7)
        bca2 = fapa_bca(xtilde, K=2, B=30, seed=7)
        np.testing.assert_array_equal(bca1["boot_X"], bca2["boot_X"])


# ─── fapa_person ─────────────────────────────────────────────────────────────

class TestFapaPerson:
    def test_r2_mean_between_0_and_1(self, xtilde):
        fit = fapa_core(xtilde, K=2)
        p   = fapa_person(xtilde, fit)
        assert 0.0 <= p["R2_mean"] <= 1.0

    def test_r2_k_sums_leq_1(self, xtilde):
        fit = fapa_core(xtilde, K=3)
        p   = fapa_person(xtilde, fit)
        assert p["R2_k"].sum() <= 1.0 + 1e-10

    def test_weights_length(self, xtilde):
        n = xtilde.shape[0]
        fit = fapa_core(xtilde, K=2)
        p   = fapa_person(xtilde, fit)
        if hasattr(p["weights"], "__len__"):
            assert len(p["weights"]) == n


# ─── Built-in dataset ────────────────────────────────────────────────────────

class TestFapaSimdata:
    def test_shape(self):
        assert fapa_simdata.shape == (500, 22)

    def test_range(self):
        assert fapa_simdata.min() >= 0
        assert fapa_simdata.max() <= 40

    def test_cols_length(self):
        assert len(FAPA_COLS) == 22

    def test_ipsatize_row_sums_zero(self):
        d = load_and_ipsatize(fapa_simdata)
        np.testing.assert_allclose(d["ipsatized"].sum(axis=1), 0, atol=1e-10)

    def test_two_components_retained(self, simdata_ipsatized):
        pa = fapa_pa(simdata_ipsatized, B=100, seed=42)
        # The two-component structure should be detected
        assert pa["n_retain"] >= 1
