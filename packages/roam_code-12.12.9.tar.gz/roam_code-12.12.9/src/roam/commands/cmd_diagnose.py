"""Root cause analysis for a failing symbol.

Given a symbol suspected to be involved in a bug, ranks likely root
causes by combining four signals no other tool brings together:
(1) call graph proximity, (2) git churn, (3) cognitive complexity,
(4) co-change history with the failing symbol.
"""

from __future__ import annotations

import click

from roam.commands.next_steps import format_next_steps_text, suggest_next_steps
from roam.commands.resolve import ensure_index, find_symbol_with_alternatives, symbol_not_found
from roam.db.connection import open_db
from roam.graph.builder import build_symbol_graph
from roam.output.formatter import abbrev_kind, format_table, json_envelope, loc, to_json


def _get_symbol_metrics(conn, sym_id):
    """Fetch complexity and churn for a symbol."""
    sm = conn.execute(
        "SELECT cognitive_complexity, nesting_depth, line_count FROM symbol_metrics WHERE symbol_id = ?",
        (sym_id,),
    ).fetchone()

    gm = conn.execute(
        "SELECT pagerank, in_degree, out_degree, betweenness FROM graph_metrics WHERE symbol_id = ?",
        (sym_id,),
    ).fetchone()

    file_row = conn.execute(
        "SELECT fs.commit_count, fs.total_churn, fs.cochange_entropy, "
        "       fs.health_score, f.path, f.id AS file_id "
        "FROM symbols s "
        "JOIN files f ON s.file_id = f.id "
        "LEFT JOIN file_stats fs ON f.id = fs.file_id "
        "WHERE s.id = ?",
        (sym_id,),
    ).fetchone()

    commits = (file_row["commit_count"] or 0) if file_row else 0
    churn = (file_row["total_churn"] or 0) if file_row else 0

    # v12.12 — git_file_changes fallback (dogfood #11). file_stats is
    # populated by ``compute_file_stats`` during a full re-index but can
    # lag behind incremental runs, leaving recently-modified files with
    # commit_count=0 even when their git history is rich. When that
    # happens, fall back to a direct COUNT over git_file_changes so the
    # Commits column carries signal again (and the risk score doesn't
    # silently lose its churn dimension).
    if file_row and commits == 0:
        try:
            fb = conn.execute(
                "SELECT COUNT(DISTINCT commit_id) AS cc, "
                "       COALESCE(SUM(lines_added + lines_removed), 0) AS chu "
                "FROM git_file_changes WHERE file_id = ?",
                (file_row["file_id"],),
            ).fetchone()
        except Exception:
            fb = None
        if fb:
            commits = fb["cc"] or 0
            if churn == 0:
                churn = fb["chu"] or 0

    return {
        "complexity": (sm["cognitive_complexity"] or 0) if sm else 0,
        "nesting": (sm["nesting_depth"] or 0) if sm else 0,
        "line_count": (sm["line_count"] or 0) if sm else 0,
        "pagerank": round((gm["pagerank"] or 0), 4) if gm else 0,
        "in_degree": (gm["in_degree"] or 0) if gm else 0,
        "out_degree": (gm["out_degree"] or 0) if gm else 0,
        "betweenness": round((gm["betweenness"] or 0), 3) if gm else 0,
        "commits": commits,
        "churn": churn,
        "entropy": round((file_row["cochange_entropy"] or 0), 2) if file_row else 0,
        "health": (file_row["health_score"] or 0) if file_row else 0,
        "file_path": file_row["path"] if file_row else "",
    }


def _build_distribution_stats(conn):
    """Compute mean/stddev of key metrics across the codebase for z-scoring.

    Returns dict with {metric: (mean, stddev)} for adaptive normalization.
    """
    import math

    commit_rows = conn.execute("SELECT commit_count FROM file_stats WHERE commit_count IS NOT NULL").fetchall()
    cc_rows = conn.execute(
        "SELECT cognitive_complexity FROM symbol_metrics WHERE cognitive_complexity IS NOT NULL"
    ).fetchall()
    health_rows = conn.execute("SELECT health_score FROM file_stats WHERE health_score IS NOT NULL").fetchall()
    entropy_rows = conn.execute("SELECT cochange_entropy FROM file_stats WHERE cochange_entropy IS NOT NULL").fetchall()

    def _stats(values):
        if not values:
            return (1.0, 1.0)
        n = len(values)
        mean = sum(values) / n
        var = sum((v - mean) ** 2 for v in values) / max(n, 1)
        return (mean, max(math.sqrt(var), 0.01))

    return {
        "commits": _stats([r[0] for r in commit_rows]),
        "complexity": _stats([r[0] for r in cc_rows]),
        "health": _stats([r[0] for r in health_rows]),
        "entropy": _stats([r[0] for r in entropy_rows]),
    }


def _risk_score(metrics, dist_stats=None):
    """Compute a composite risk score for root-cause ranking.

    Higher = more likely to be a root cause.  Combines churn,
    complexity, low health, and co-change entropy.

    When *dist_stats* is provided (from ``_build_distribution_stats``),
    uses z-score normalization — each factor is measured in standard
    deviations from the codebase mean, making thresholds adaptive to
    any project.  Falls back to fixed normalization otherwise.
    """
    if dist_stats:

        def _z(value, key):
            mean, std = dist_stats[key]
            return max(0, (value - mean) / std)

        # Clip z-scores at 3σ then normalize to [0, 1]
        churn_norm = min(_z(metrics["commits"], "commits") / 3, 1.0)
        cc_norm = min(_z(metrics["complexity"], "complexity") / 3, 1.0)
        # Health is inverted: low health = high risk
        h_mean, h_std = dist_stats["health"]
        health_risk = max(0, min((h_mean - metrics["health"]) / max(h_std, 0.01) / 3, 1.0))
        entropy_risk = min(_z(metrics["entropy"], "entropy") / 3, 1.0)
    else:
        churn_norm = min(metrics["commits"] / 50, 1.0)
        cc_norm = min(metrics["complexity"] / 30, 1.0)
        health_risk = max(0, (7 - metrics["health"]) / 7) if metrics["health"] else 0.5
        entropy_risk = metrics["entropy"]

    return round(
        churn_norm * 0.30 + cc_norm * 0.30 + health_risk * 0.25 + entropy_risk * 0.15,
        3,
    )


def _cochange_partners(conn, file_id, limit=10):
    """Find files that frequently change together with the given file."""
    rows = conn.execute(
        """SELECT CASE WHEN cc.file_id_a = ? THEN cc.file_id_b ELSE cc.file_id_a END as partner_id,
                  cc.cochange_count, f.path
           FROM git_cochange cc
           JOIN files f ON f.id = CASE WHEN cc.file_id_a = ? THEN cc.file_id_b ELSE cc.file_id_a END
           WHERE cc.file_id_a = ? OR cc.file_id_b = ?
           ORDER BY cc.cochange_count DESC
           LIMIT ?""",
        (file_id, file_id, file_id, file_id, limit),
    ).fetchall()
    return [{"file": r["path"], "cochange_count": r["cochange_count"]} for r in rows]


def _recent_changes(conn, file_id, limit=5):
    """Get recent git commits touching this file."""
    rows = conn.execute(
        """SELECT gc.hash, gc.author, gc.message, gc.timestamp
           FROM git_commits gc
           JOIN git_file_changes gfc ON gc.id = gfc.commit_id
           WHERE gfc.file_id = ?
           ORDER BY gc.timestamp DESC
           LIMIT ?""",
        (file_id, limit),
    ).fetchall()
    return [
        {
            "hash": r["hash"][:8],
            "author": r["author"],
            "message": (r["message"] or "")[:80],
        }
        for r in rows
    ]


@click.command()
@click.argument("name")
@click.option("--depth", default=2, help="How many hops to analyze (default 2)")
@click.pass_context
def diagnose(ctx, name, depth):
    """Root cause analysis for a failing symbol.

    Unlike ``why`` (which explains a symbol's architectural role), this
    command ranks upstream and downstream symbols by risk score to find
    likely root causes of failures.

    Given a symbol suspected of causing a bug, ranks upstream callers
    and downstream callees by a composite risk score combining:
    git churn, cognitive complexity, file health, and co-change entropy.

    Also shows co-change partners and recent git history for the
    symbol's file.

    Example:

        roam diagnose handle_payment
        roam diagnose UserService.create --depth 3
    """
    json_mode = ctx.obj.get("json") if ctx.obj else False
    ensure_index()

    with open_db(readonly=True) as conn:
        sym, alternatives = find_symbol_with_alternatives(conn, name)
        if sym is None:
            click.echo(symbol_not_found(conn, name, json_mode=json_mode))
            raise SystemExit(1)

        sym_id = sym["id"]
        did_you_mean = [
            {
                "name": (alt["qualified_name"] or alt["name"]),
                "kind": alt["kind"],
                "location": loc(alt["file_path"], alt["line_start"]),
            }
            for alt in alternatives[:5]
        ]
        G = build_symbol_graph(conn)

        if sym_id not in G:
            click.echo(
                f"Symbol '{name}' is not in the dependency graph.\n"
                "  Tip: Run `roam index` to rebuild the graph. If the symbol has no\n"
                "       callers or callees, it may not appear in the graph."
            )
            raise SystemExit(1)

        target_metrics = _get_symbol_metrics(conn, sym_id)
        dist_stats = _build_distribution_stats(conn)

        # Upstream callers (predecessors in call graph) up to depth hops
        upstream_ids = set()
        frontier = {sym_id}
        for _ in range(depth):
            next_frontier = set()
            for nid in frontier:
                if nid in G:
                    for pred in G.predecessors(nid):
                        if pred != sym_id and pred not in upstream_ids:
                            upstream_ids.add(pred)
                            next_frontier.add(pred)
            frontier = next_frontier

        # Downstream callees (successors) up to depth hops
        downstream_ids = set()
        frontier = {sym_id}
        for _ in range(depth):
            next_frontier = set()
            for nid in frontier:
                if nid in G:
                    for succ in G.successors(nid):
                        if succ != sym_id and succ not in downstream_ids:
                            downstream_ids.add(succ)
                            next_frontier.add(succ)
            frontier = next_frontier

        # Rank upstream by risk score
        def _build_ranked(sym_ids, direction):
            ranked = []
            for sid in sym_ids:
                row = conn.execute(
                    "SELECT s.name, s.qualified_name, s.kind, s.line_start, f.path, f.id as file_id "
                    "FROM symbols s JOIN files f ON s.file_id = f.id WHERE s.id = ?",
                    (sid,),
                ).fetchone()
                if not row:
                    continue
                metrics = _get_symbol_metrics(conn, sid)
                risk = _risk_score(metrics, dist_stats)
                ranked.append(
                    {
                        "name": row["qualified_name"] or row["name"],
                        "kind": abbrev_kind(row["kind"]),
                        "location": loc(row["path"], row["line_start"]),
                        "risk_score": risk,
                        "complexity": metrics["complexity"],
                        "commits": metrics["commits"],
                        "health": metrics["health"],
                        "entropy": metrics["entropy"],
                        "direction": direction,
                    }
                )
            ranked.sort(key=lambda x: -x["risk_score"])
            return ranked

        upstream_ranked = _build_ranked(upstream_ids, "upstream")
        downstream_ranked = _build_ranked(downstream_ids, "downstream")

        # Co-change partners
        file_row = conn.execute(
            "SELECT f.id FROM symbols s JOIN files f ON s.file_id = f.id WHERE s.id = ?",
            (sym_id,),
        ).fetchone()
        cochanges = _cochange_partners(conn, file_row["id"]) if file_row else []
        recent = _recent_changes(conn, file_row["id"]) if file_row else []

        # Build verdict
        all_suspects = upstream_ranked[:5] + downstream_ranked[:5]
        if all_suspects:
            top = all_suspects[0]
            verdict = (
                f"Top suspect: {top['name']} "
                f"(risk={top['risk_score']:.2f}, cc={top['complexity']}, "
                f"commits={top['commits']}, health={top['health']}/10)"
            )
        else:
            verdict = "No upstream/downstream symbols found within depth range."

        _target_name = sym["qualified_name"] or sym["name"]
        _top_suspect = all_suspects[0]["name"] if all_suspects else ""
        _next_steps = suggest_next_steps(
            "diagnose",
            {
                "symbol": _target_name,
                "top_suspect": _top_suspect,
            },
        )

        # Round 4 #20 / U: index status is now a top-level envelope
        # field AND prints before the VERDICT in text mode so an agent
        # reading top-down can't miss a stale-index warning.
        from roam.commands.resolve import index_status as _index_status

        index_status_payload = _index_status()

        if json_mode:
            envelope = json_envelope(
                "diagnose",
                summary={
                    "target": _target_name,
                    "verdict": verdict,
                    "upstream_count": len(upstream_ranked),
                    "downstream_count": len(downstream_ranked),
                    "ambiguous": bool(did_you_mean),
                },
                target_metrics=target_metrics,
                upstream=upstream_ranked[:15],
                downstream=downstream_ranked[:15],
                cochange_partners=cochanges,
                recent_commits=recent,
                did_you_mean=did_you_mean,
                next_steps=_next_steps,
            )
            if index_status_payload is not None:
                envelope["index_status"] = index_status_payload
            click.echo(to_json(envelope))
            return

        # Text output — index-staleness warning lands FIRST so it can't
        # be missed when scanning top-down.
        if index_status_payload and not index_status_payload.get("fresh"):
            click.echo(f"NOTE: {index_status_payload['hint']}")
            click.echo()
        click.echo(f"VERDICT: {verdict}")
        sym_name = sym["qualified_name"] or sym["name"]
        click.echo(f"Diagnose: {sym_name}")
        click.echo(f"  {loc(target_metrics['file_path'], sym['line_start'])}")
        click.echo(
            f"  complexity={target_metrics['complexity']}, "
            f"commits={target_metrics['commits']}, "
            f"health={target_metrics['health']}/10\n"
        )
        if did_you_mean:
            click.echo("Did you mean (other matches, ranked by importance):")
            for alt in did_you_mean:
                click.echo(f"  {abbrev_kind(alt['kind'])}  {alt['name']}  {alt['location']}")
            click.echo("  Tip: use file:symbol (e.g. KiniseisEntryModal.vue:handleSave) to disambiguate.\n")

        if upstream_ranked:
            click.echo("Upstream suspects (callers, ranked by risk):\n")
            rows = [
                [
                    r["name"],
                    r["kind"],
                    f"{r['risk_score']:.2f}",
                    str(r["complexity"]),
                    str(r["commits"]),
                    f"{r['health']}/10",
                    r["location"],
                ]
                for r in upstream_ranked[:10]
            ]
            click.echo(
                format_table(
                    ["Symbol", "Kind", "Risk", "CC", "Commits", "Health", "Location"],
                    rows,
                )
            )

        if downstream_ranked:
            click.echo("\nDownstream suspects (callees, ranked by risk):\n")
            rows = [
                [
                    r["name"],
                    r["kind"],
                    f"{r['risk_score']:.2f}",
                    str(r["complexity"]),
                    str(r["commits"]),
                    f"{r['health']}/10",
                    r["location"],
                ]
                for r in downstream_ranked[:10]
            ]
            click.echo(
                format_table(
                    ["Symbol", "Kind", "Risk", "CC", "Commits", "Health", "Location"],
                    rows,
                )
            )

        if cochanges:
            click.echo("\nCo-change partners (files that change together):\n")
            for c in cochanges[:8]:
                click.echo(f"  {c['file']}  ({c['cochange_count']} co-changes)")

        if recent:
            click.echo(f"\nRecent commits to {target_metrics['file_path']}:\n")
            for c in recent:
                click.echo(f"  {c['hash']}  {c['author']:<20} {c['message']}")

        _ns_text = format_next_steps_text(_next_steps)
        if _ns_text:
            click.echo(_ns_text)
