"""
k-familiar — A holographic AI that thinks in six table lookups.

    from k_familiar import Familiar

    f = Familiar()
    result = f.classify("I feel stuck on this problem")
    print(result)
    # {'suit': 'hearts', 'confidence': 0.82, 'rank': 5, 'polarity': 'dark', ...}

Six operations. 313 bytes of tables. 16,000 classifications per second.
Zero training. Zero parameters. Provably safe by construction.

Author: Patrick J. Malthaner / K-Systems Research
License: MIT
"""

__version__ = "0.1.0"

from k_familiar.chips import (
    bind,
    bundle,
    bundle_many,
    retrieve,
    fold,
    fold_recursive,
    check,
    ask,
    protein_profile,
    classify_suit,
    vector_to_hex,
    hex_to_vector,
    kvector_encode,
    kvector_decode,
    gf4_agreement,
    gf4_distance,
    GF4_ADD,
    GF4_MUL,
    GF4_INV,
    GF4_COMPLEMENT,
    GENETIC_CODE,
    SUIT_NAMES,
    AA_NAMES,
)

from k_familiar.engine import Familiar

__all__ = [
    "Familiar",
    "bind", "bundle", "bundle_many", "retrieve",
    "fold", "fold_recursive", "check", "ask",
    "protein_profile", "classify_suit",
    "vector_to_hex", "hex_to_vector",
    "kvector_encode", "kvector_decode",
    "gf4_agreement", "gf4_distance",
    "GF4_ADD", "GF4_MUL", "GF4_INV", "GF4_COMPLEMENT",
    "GENETIC_CODE", "SUIT_NAMES", "AA_NAMES",
]
