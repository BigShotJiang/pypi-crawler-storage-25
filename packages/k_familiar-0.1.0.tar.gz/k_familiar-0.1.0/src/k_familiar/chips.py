#!/usr/bin/env python3
"""
chips.py — The Six Opcodes of the Holographic Onion Computer

Each chip is a pure function. No side effects. No state.
Wire them together in the runtime. Call them from KCODE.

    BIND ⊗      — associate two vectors (GF(4) multiply)
    BUNDLE ⊕    — superimpose vectors (GF(4) add)
    RETRIEVE ⊗⁻¹ — extract from bundle (multiply by complement)
    FOLD C()    — compress through codon table (triplet lookup)
    CHECK √d    — test holographic capacity
    ASK ?       — capacity exceeded, query human

K-address: +10D (THE PEAK — everything working, compiled)
guard_growth × ease_pain
"""

import numpy as np
from typing import Tuple, Optional, List, Dict, Any
import math
import json

# ================================================================
# GF(4) TABLES — The bedrock. The fixed point. The four.
# ================================================================

GF4_ADD = np.array([
    [0, 1, 2, 3],
    [1, 0, 3, 2],
    [2, 3, 0, 1],
    [3, 2, 1, 0],
], dtype=np.uint8)

GF4_MUL = np.array([
    [0, 0, 0, 0],
    [0, 1, 2, 3],
    [0, 2, 3, 1],
    [0, 3, 1, 2],
], dtype=np.uint8)

GF4_INV = np.array([0, 1, 3, 2], dtype=np.uint8)  # 0→0(undef), 1→1, 2→3, 3→2

GF4_COMPLEMENT = np.array([1, 0, 3, 2], dtype=np.uint8)

# The standard genetic code: 64 codons → 21 outputs (0-19=amino acids, 20=stop/Aether)
GENETIC_CODE = np.array([
    6,6,3,3,  8,8,8,8,  19,19,20,20,  10,10,20,18,   # UUx, UCx, UAx, UGx
    3,3,3,3,  5,5,5,5,  15,15,12,12,  14,14,14,14,   # CUx, CCx, CAx, CGx
    4,4,4,7,  9,9,9,9,  11,11,13,13,   8, 8,14,14,   # AUx, ACx, AAx, AGx
    2,2,2,2,  1,1,1,1,  16,16,17,17,   0, 0, 0, 0,   # GUx, GCx, GAx, GGx
], dtype=np.uint8)

# Degeneracy map: amino acid → list of synonymous codon indices
SYNONYMS = {}
for codon_idx in range(64):
    aa = int(GENETIC_CODE[codon_idx])
    SYNONYMS.setdefault(aa, []).append(codon_idx)

# Amino acid names
AA_NAMES = [
    "Gly","Ala","Val","Leu","Ile","Pro","Phe","Met",
    "Ser","Thr","Cys","Asn","Gln","Lys","Arg","His",
    "Asp","Glu","Trp","Tyr","STOP"
]

# Suit affinity per amino acid (H, S, D, C, Aether)
AA_SUIT = np.zeros((21, 5), dtype=np.float32)
for i in range(8):   AA_SUIT[i]  = [0.1, 0.1, 0.2, 0.5, 0.1]  # nonpolar → clubs
for i in range(8,13): AA_SUIT[i] = [0.5, 0.1, 0.2, 0.1, 0.1]  # polar → hearts
for i in range(13,16):AA_SUIT[i] = [0.1, 0.5, 0.2, 0.1, 0.1]  # positive → spades
for i in range(16,18):AA_SUIT[i] = [0.1, 0.1, 0.5, 0.2, 0.1]  # negative → diamonds
AA_SUIT[18] = [0.2, 0.3, 0.2, 0.2, 0.1]  # Trp
AA_SUIT[19] = [0.3, 0.2, 0.2, 0.2, 0.1]  # Tyr
AA_SUIT[20] = [0.05, 0.05, 0.05, 0.05, 0.8]  # STOP → Aether

SUIT_NAMES = ["hearts", "spades", "diamonds", "clubs", "aether"]


# ================================================================
# CHIP 1: BIND ⊗ — Associate two vectors
# ================================================================

def bind(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    """Element-wise GF(4) multiplication. Associates two representations.

    Bind(key, value) → bound pair. Invertible: Retrieve(bound, key) = value.
    Cost: d lookups. Zero multiplies.
    """
    return GF4_MUL[a, b]


# ================================================================
# CHIP 2: BUNDLE ⊕ — Superimpose vectors
# ================================================================

def bundle(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    """Element-wise GF(4) addition. Superimposes two representations.

    Bundle(a, b) → both stored in one vector. Capacity: k ≤ √d items.
    Cost: d lookups. Zero multiplies.
    """
    return GF4_ADD[a, b]


def bundle_many(vectors: List[np.ndarray]) -> np.ndarray:
    """Bundle multiple vectors into one superposition."""
    result = vectors[0].copy()
    for v in vectors[1:]:
        result = GF4_ADD[result, v]
    return result


# ================================================================
# CHIP 3: RETRIEVE ⊗⁻¹ — Extract from bundle
# ================================================================

def retrieve(bundle_vec: np.ndarray, key: np.ndarray) -> np.ndarray:
    """Multiply by inverse to extract bound item from bundle.

    If bundle contains Bind(key, value), Retrieve(bundle, key) ≈ value.
    Exact when k=1. Noisy when k>1. Fails when k > √d.
    Cost: d lookups. Zero multiplies.
    """
    inv_key = GF4_INV[key]
    return GF4_MUL[bundle_vec, inv_key]


# ================================================================
# CHIP 4: FOLD C() — Compress through codon table
# ================================================================

def fold(vector: np.ndarray, table: np.ndarray = None) -> np.ndarray:
    """Codon activation: triplet GF(4) symbols → lookup table → output.

    Compresses by 3:1. Each triplet (a,b,c) → table[a*16 + b*4 + c].
    Default table: biological genetic code (64 → 21 amino acids).
    Cost: d/3 lookups. Zero multiplies.
    """
    if table is None:
        table = GENETIC_CODE

    v = vector.astype(np.uint8) % 4
    n = len(v)
    pad = (3 - n % 3) % 3
    if pad:
        v = np.concatenate([v, np.zeros(pad, dtype=np.uint8)])

    n_codons = len(v) // 3
    out = np.empty(n_codons, dtype=np.uint8)
    for i in range(n_codons):
        idx = int(v[3*i]) * 16 + int(v[3*i+1]) * 4 + int(v[3*i+2])
        out[i] = table[idx]
    return out


def fold_recursive(vector: np.ndarray, levels: int = 3,
                   table: np.ndarray = None) -> List[np.ndarray]:
    """Recursive fold: fold L times, return all levels.

    Returns list of [level_0, level_1, ..., level_L] where each is the
    fold output at that depth. The onion — read at any level.
    """
    results = [vector.copy()]
    current = vector
    for _ in range(levels):
        current = fold(current, table)
        results.append(current.copy())
        if len(current) < 3:
            break
    return results


def protein_profile(amino_acids: np.ndarray) -> np.ndarray:
    """Compute suit affinity from amino acid sequence. Returns (5,) vector."""
    profile = np.zeros(5, dtype=np.float64)
    for aa in amino_acids:
        profile += AA_SUIT[min(int(aa), 20)]
    total = profile.sum()
    if total > 0:
        profile /= total
    else:
        profile = np.ones(5) / 5
    return profile


def classify_suit(profile: np.ndarray) -> Tuple[str, float]:
    """Classify suit from profile. Returns (suit_name, confidence)."""
    idx = int(np.argmax(profile))
    return SUIT_NAMES[idx], float(profile[idx])


# ================================================================
# CHIP 5: CHECK √d — Test holographic capacity
# ================================================================

def check(bundle_items: int, d: int = 64, q: int = 4) -> Dict[str, Any]:
    """Test if bundle is within holographic capacity.

    Capacity k* = (q/(q-1)) × √d.
    Returns status dict with items, capacity, ok, headroom/overflow.
    """
    capacity = (q / (q - 1)) * math.sqrt(d)
    ok = bundle_items <= capacity

    return {
        "items": bundle_items,
        "capacity": round(capacity, 2),
        "ok": ok,
        "headroom": round(capacity - bundle_items, 2) if ok else 0,
        "overflow": round(bundle_items - capacity, 2) if not ok else 0,
        "phase": "green" if bundle_items / capacity < 0.5 else
                 "yellow" if bundle_items / capacity < 0.8 else
                 "red" if ok else "STOP",
    }


# ================================================================
# CHIP 6: ASK ? — Query human
# ================================================================

def ask(reason: str, known: Any = None, unknown: str = None,
        suggested: str = None) -> Dict[str, Any]:
    """Capacity exceeded or uncertain. Package what we know and what we need.

    This is the ONLY chip that produces user-facing output.
    All other chips are internal computation.

    Reasons:
        capacity_exceeded — k > √d, retrieval would fail
        uncertain — fold confidence below threshold
        oath_boundary — fold hit stop codon (Aether)
        sop_blocked — SOP requires human verification at this step
    """
    return {
        "op": "ASK",
        "reason": reason,
        "known": known,
        "unknown": unknown,
        "suggested_question": suggested,
        "oath": "guard_growth × ease_pain",
    }


# ================================================================
# CODON CHOOSER — Select synonym given payload
# ================================================================

def choose_codon(amino_acid: int, payload_bits: int = 0,
                 context_amino: int = -1) -> int:
    """Choose which synonymous codon to emit.

    Args:
        amino_acid: target AA index (0-20)
        payload_bits: bits to encode in degeneracy channel
        context_amino: previous AA for attention signal (-1 = no context)

    Returns:
        codon_index (0-63)
    """
    syns = SYNONYMS.get(amino_acid, [])
    if not syns:
        return 0

    if len(syns) == 1:
        return syns[0]  # no degeneracy (Met, Trp)

    # Use payload bits to select among synonyms
    idx = payload_bits % len(syns)

    # Context attention: rotate selection based on previous amino acid
    if context_amino >= 0:
        idx = (idx + context_amino) % len(syns)

    return syns[idx]


def read_codon(codon_index: int, amino_acid: int,
               context_amino: int = -1) -> int:
    """Extract payload bits from codon synonym choice.

    Inverse of choose_codon. Returns the degeneracy payload.
    """
    syns = SYNONYMS.get(amino_acid, [])
    if len(syns) <= 1:
        return 0

    idx = syns.index(codon_index) if codon_index in syns else 0

    if context_amino >= 0:
        idx = (idx - context_amino) % len(syns)

    return idx


# ================================================================
# VECTOR ↔ HEX HASH — GF(4) ↔ GF(16) projection
# ================================================================

def vector_to_hex(vector: np.ndarray) -> str:
    """Convert GF(4) vector to hex hash string. Two qits per hex digit."""
    v = vector.astype(np.uint8) % 4
    if len(v) % 2:
        v = np.concatenate([v, [0]])
    hex_chars = []
    for i in range(0, len(v), 2):
        val = int(v[i]) * 4 + int(v[i+1])
        hex_chars.append(f"{val:x}")
    return "".join(hex_chars)


def hex_to_vector(hex_str: str, d: int = 64) -> np.ndarray:
    """Convert hex hash string to GF(4) vector."""
    v = np.zeros(d, dtype=np.uint8)
    for i, ch in enumerate(hex_str):
        if i * 2 >= d:
            break
        val = int(ch, 16)
        v[i*2] = val // 4
        v[i*2+1] = val % 4
    return v


# ================================================================
# K-VECTOR ENCODING — Suit/Rank/Polarity → GF(4)
# ================================================================

SUIT_MAP = {"H": 0, "S": 1, "D": 2, "C": 3,
            "hearts": 0, "spades": 1, "diamonds": 2, "clubs": 3}

def kvector_encode(suit: str, rank: int, polarity: str,
                   d: int = 64) -> np.ndarray:
    """Encode K-vector (suit, rank, polarity) to GF(4) vector."""
    v = np.zeros(d, dtype=np.uint8)

    # Suit: 2 qits
    s = SUIT_MAP.get(suit, 0)
    v[0] = s // 2
    v[1] = s % 2 + (0 if s < 2 else 1)  # spread across qits

    # Rank: 4 qits (1-14 in base 4)
    r = max(1, min(14, rank))
    v[2] = (r - 1) // 4
    v[3] = (r - 1) % 4

    # Polarity: 1 qit
    v[4] = 1 if polarity == "+" else 2

    # Fill remaining with deterministic hash of (suit, rank, polarity)
    seed = s * 1000 + r * 10 + (1 if polarity == "+" else 2)
    rng = np.random.RandomState(seed)
    v[5:] = rng.randint(0, 4, d - 5).astype(np.uint8)

    return v


def kvector_decode(v: np.ndarray) -> Dict[str, Any]:
    """Decode GF(4) vector to K-vector components."""
    suits = ["H", "S", "D", "C"]
    s_idx = int(v[0]) * 2 + (int(v[1]) if int(v[1]) < 2 else int(v[1]) - 1)
    s_idx = min(3, max(0, s_idx))
    suit = suits[s_idx]
    rank = int(v[2]) * 4 + int(v[3]) + 1
    polarity = "+" if int(v[4]) == 1 else "-"
    shorthand = f"{polarity}{rank}{suit}"

    return {"suit": suit, "rank": rank, "polarity": polarity, "shorthand": shorthand}


# ================================================================
# K-JSON — Interchange format
# ================================================================

def to_kjson(op: str, k_addr: str = None, inputs: list = None,
             output: str = None, **kwargs) -> Dict[str, Any]:
    """Create a K-JSON expression."""
    expr = {"op": op}
    if k_addr:
        expr["k"] = k_addr
    if inputs:
        expr["in"] = inputs
    if output:
        expr["out"] = output
    expr.update(kwargs)
    return expr


# ================================================================
# SIMILARITY — For retrieval quality assessment
# ================================================================

def gf4_agreement(a: np.ndarray, b: np.ndarray) -> float:
    """Fraction of positions where two GF(4) vectors agree."""
    return float(np.mean(a == b))


def gf4_distance(a: np.ndarray, b: np.ndarray) -> int:
    """Hamming distance over GF(4) (number of differing positions)."""
    return int(np.sum(a != b))
