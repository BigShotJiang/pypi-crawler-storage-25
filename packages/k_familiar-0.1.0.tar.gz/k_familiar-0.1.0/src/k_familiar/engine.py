"""
engine.py — The Familiar: A holographic classifier and router.

The minimal viable AI: classify any text into 4 domains (hearts/spades/
diamonds/clubs) using only GF(4) table lookups. No training, no parameters,
no API calls. Fits in L1 cache. 16K classifications per second.

Usage:
    from k_familiar import Familiar

    f = Familiar()

    # Classify text
    result = f.classify("I feel stuck on this problem")
    print(result["suit"])        # "spades"
    print(result["confidence"])  # 0.82

    # Route with templates
    f.set_template("H", 5, "+", "Take a breath. Name one thing you're grateful for.")
    result = f.route("I'm feeling overwhelmed today")
    print(result["response"])    # Template or ASK

    # Check capacity
    f.remember("morning", "breakfast meeting went well")
    print(f.status())            # Bundle items, capacity phase

Author: Patrick J. Malthaner / K-Systems Research
License: MIT
"""

import numpy as np
import time
from typing import Dict, Any, Optional, List

from k_familiar.chips import (
    bind, bundle, retrieve, fold, fold_recursive,
    protein_profile, classify_suit, check, ask,
    vector_to_hex, hex_to_vector,
    kvector_encode, kvector_decode,
    gf4_agreement,
    GF4_MUL, GF4_ADD, GF4_INV,
    SUIT_NAMES, AA_NAMES,
)


# Suit full names
SUIT_FULL = {
    "hearts": "H", "spades": "S", "diamonds": "D", "clubs": "C",
    "H": "H", "S": "S", "D": "D", "C": "C",
}

# Stop words for content extraction
STOP_WORDS = {
    "i", "me", "my", "we", "our", "you", "your", "he", "she", "it",
    "they", "them", "the", "a", "an", "is", "am", "are", "was", "were",
    "be", "been", "being", "have", "has", "had", "do", "does", "did",
    "will", "would", "could", "should", "may", "might", "shall", "can",
    "to", "of", "in", "for", "on", "with", "at", "by", "from", "as",
    "into", "about", "like", "through", "after", "over", "between",
    "out", "up", "down", "off", "and", "but", "or", "nor", "not", "so",
    "if", "then", "than", "that", "this", "these", "those", "what",
    "which", "who", "when", "where", "how", "why", "all", "each",
    "every", "both", "few", "more", "most", "some", "any", "no",
    "very", "just", "also", "too", "only", "own", "same", "other",
}


class Familiar:
    """A holographic classifier and router.

    Thinks in GF(4) table lookups. Classifies text into 4 domains
    (hearts/spades/diamonds/clubs) with confidence scoring.
    Optionally routes to templates and maintains working memory.

    Args:
        d: Vector dimension (default 64). Capacity = ~sqrt(d) items.
    """

    def __init__(self, d: int = 64):
        self.d = d
        self.q = 4  # GF(4)
        self.capacity = (self.q / (self.q - 1)) * (d ** 0.5)

        # Working memory (bundle state)
        self._bundle = np.zeros(d, dtype=np.uint8)
        self._bundle_items = 0
        self._bundle_keys: List[str] = []

        # Template store: (suit, rank, polarity) -> response text
        self._templates: Dict[str, str] = {}

        # History
        self._history: List[Dict] = []

    # ── Classification ───────────────────────────────────────

    def classify(self, text: str) -> Dict[str, Any]:
        """Classify text into a suit domain.

        Returns:
            Dict with: suit, confidence, rank, polarity, k_addr,
            profile (5-element suit distribution), latency_us
        """
        start = time.perf_counter()

        vector = self._text_to_vector(text)
        levels = fold_recursive(vector, levels=3)
        profile = protein_profile(levels[1]) if len(levels) > 1 else np.ones(5) / 5

        suit_name, confidence = classify_suit(profile)
        suit_char = SUIT_FULL.get(suit_name, "S")

        # Estimate rank from fold depth variance
        rank = self._estimate_rank(levels)

        # Polarity from sentiment keywords
        polarity = self._estimate_polarity(text)

        k_addr = f"{polarity}{rank}{suit_char}"

        elapsed_us = int((time.perf_counter() - start) * 1_000_000)

        result = {
            "suit": suit_name,
            "suit_char": suit_char,
            "confidence": round(confidence, 4),
            "rank": rank,
            "polarity": "light" if polarity == "+" else "dark",
            "k_addr": k_addr,
            "profile": {SUIT_NAMES[i]: round(float(profile[i]), 4) for i in range(5)},
            "latency_us": elapsed_us,
        }

        self._history.append({"text": text[:100], "result": k_addr})
        return result

    def route(self, text: str) -> Dict[str, Any]:
        """Classify text and route to a template if available.

        Returns classification result plus:
            response: template text or ASK dict
            source: "template" or "ask"
        """
        result = self.classify(text)

        # Try exact match first, then suit+rank, then suit only
        k = result["k_addr"]
        template = (
            self._templates.get(k) or
            self._templates.get(f"{k[0]}{result['rank']}{result['suit_char']}") or
            self._templates.get(result["suit_char"])
        )

        if template:
            result["response"] = template
            result["source"] = "template"
        else:
            result["response"] = ask(
                reason="no_template",
                known={"suit": result["suit"], "k_addr": k},
                suggested=f"Add a template for {k}",
            )
            result["source"] = "ask"

        return result

    # ── Templates ────────────────────────────────────────────

    def set_template(self, suit: str, rank: int = None,
                     polarity: str = None, response: str = ""):
        """Set a response template for a K-address.

        Args:
            suit: Suit character (H/S/D/C) or full name.
            rank: Rank 1-13 (optional, for specific addressing).
            polarity: "+" or "-" (optional).
            response: Template text to return when this address matches.
        """
        s = SUIT_FULL.get(suit, suit)
        if rank and polarity:
            key = f"{polarity}{rank}{s}"
        elif rank:
            key = f"+{rank}{s}"
        else:
            key = s
        self._templates[key] = response

    def load_templates(self, templates: Dict[str, str]):
        """Load multiple templates from a dict.

        Keys can be K-addresses ("+5H") or suit characters ("H").
        """
        self._templates.update(templates)

    # ── Working Memory ───────────────────────────────────────

    def remember(self, key_name: str, value_text: str) -> Dict[str, Any]:
        """Store something in working memory (holographic bundle).

        Returns capacity status. Raises ValueError if capacity exceeded.
        """
        key_vec = self._text_to_vector(key_name)
        val_vec = self._text_to_vector(value_text)

        status = check(self._bundle_items + 1, self.d, self.q)
        if not status["ok"]:
            raise ValueError(
                f"Working memory full: {self._bundle_items + 1} items "
                f"(capacity {status['capacity']})"
            )

        bound = bind(key_vec, val_vec)
        self._bundle = bundle(self._bundle, bound)
        self._bundle_items += 1
        self._bundle_keys.append(key_name)

        return status

    def recall(self, key_name: str) -> Optional[np.ndarray]:
        """Retrieve a value from working memory by key.

        Returns the raw GF(4) vector (for similarity comparisons).
        """
        if key_name not in self._bundle_keys:
            return None
        key_vec = self._text_to_vector(key_name)
        return retrieve(self._bundle, key_vec)

    def forget_all(self):
        """Clear working memory."""
        self._bundle = np.zeros(self.d, dtype=np.uint8)
        self._bundle_items = 0
        self._bundle_keys.clear()

    # ── Status ───────────────────────────────────────────────

    def status(self) -> Dict[str, Any]:
        """Get current Familiar status."""
        cap = check(self._bundle_items, self.d, self.q)
        return {
            "d": self.d,
            "bundle_items": self._bundle_items,
            "bundle_keys": list(self._bundle_keys),
            "capacity": cap,
            "templates": len(self._templates),
            "history_length": len(self._history),
        }

    # ── Internal ─────────────────────────────────────────────

    def _text_to_vector(self, text: str) -> np.ndarray:
        """Convert text to a GF(4) vector via byte decomposition."""
        raw = text.encode('utf-8')
        v = np.zeros(self.d, dtype=np.uint8)
        for i, byte in enumerate(raw):
            if i * 4 >= self.d:
                break
            v[i * 4] = (byte >> 6) & 3
            v[i * 4 + 1] = (byte >> 4) & 3
            v[i * 4 + 2] = (byte >> 2) & 3
            v[i * 4 + 3] = byte & 3
        return v

    def _estimate_rank(self, levels: List[np.ndarray]) -> int:
        """Estimate rank (1-13) from fold levels."""
        if len(levels) < 2:
            return 5
        # Use variance across fold levels as intensity proxy
        profile = protein_profile(levels[1])
        max_conf = float(np.max(profile[:4]))  # Exclude aether
        # Map confidence to rank: high confidence = high rank
        rank = max(1, min(13, int(max_conf * 13 + 0.5)))
        return rank

    def _estimate_polarity(self, text: str) -> str:
        """Estimate polarity from simple sentiment signals."""
        text_lower = text.lower()
        dark_signals = [
            "stuck", "frustrated", "angry", "sad", "lost", "broken",
            "can't", "won't", "hate", "fear", "anxious", "overwhelmed",
            "tired", "exhausted", "hurt", "pain", "fail", "wrong",
            "never", "worst", "ugly", "stupid", "alone", "hopeless",
        ]
        light_signals = [
            "happy", "good", "great", "love", "hope", "excited",
            "grateful", "calm", "peace", "strong", "better", "best",
            "beautiful", "kind", "warm", "bright", "clear", "free",
            "yes", "ready", "alive", "proud", "safe", "together",
        ]
        dark = sum(1 for w in dark_signals if w in text_lower)
        light = sum(1 for w in light_signals if w in text_lower)
        return "+" if light >= dark else "-"

    def __repr__(self):
        cap = check(self._bundle_items, self.d, self.q)
        return f"Familiar(d={self.d}, items={self._bundle_items}, phase={cap['phase']})"
