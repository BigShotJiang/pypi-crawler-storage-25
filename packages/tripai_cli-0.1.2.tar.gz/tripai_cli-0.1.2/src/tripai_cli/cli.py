"""Command-line entry point."""

from __future__ import annotations

import argparse
import json
import sys
import urllib.error
import urllib.request

API_URL = "https://wendao-skill-prod.ctrip.com/skill/query"
SOURCE = "pypi_cli"
DEFAULT_TIMEOUT = 60


def query(text: str, *, token: str | None = None, timeout: float = DEFAULT_TIMEOUT) -> str:
    body = {"query": text, "source": SOURCE}
    if token:
        body["token"] = token
    payload = json.dumps(body).encode("utf-8")
    req = urllib.request.Request(
        API_URL,
        data=payload,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.read().decode("utf-8")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="tripai",
        description="Query the TripAI skill endpoint.",
    )
    parser.add_argument("--query", required=True, help="query text")
    parser.add_argument("--token", default="", help="API token (optional)")
    parser.add_argument(
        "--timeout",
        type=float,
        default=DEFAULT_TIMEOUT,
        help=f"request timeout in seconds (default: {DEFAULT_TIMEOUT})",
    )
    args = parser.parse_args(argv)

    text = args.query
    token = args.token if args.token else None
    try:
        body = query(text, token=token, timeout=args.timeout)
    except urllib.error.HTTPError as e:
        sys.stderr.write(f"HTTP {e.code}: {e.reason}\n")
        err_body = e.read().decode("utf-8", errors="replace")
        if err_body:
            sys.stderr.write(err_body + "\n")
        return 1
    except urllib.error.URLError as e:
        sys.stderr.write(f"Request failed: {e.reason}\n")
        return 1

    sys.stdout.write(body)
    if not body.endswith("\n"):
        sys.stdout.write("\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
