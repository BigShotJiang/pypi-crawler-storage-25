"""tripai_cli — CLI for the TripAI skill endpoint."""

from .cli import main

__all__ = ["main"]
__version__ = "0.1.0"
