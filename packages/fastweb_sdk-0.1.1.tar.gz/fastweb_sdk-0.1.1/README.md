# FastWeb Python SDK

Python bindings for FastWeb: The Agentic Browser Engine.

## Installation

### 1. Install the FastWeb Binary

```bash
curl -sL https://fastweb.b4n1.com/install | bash
```

### 2. Install the Python SDK

```bash
pip install fastweb-sdk
```

On Ubuntu 23.04+ or other externally-managed environments, use a virtual environment:

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install fastweb-sdk
```

Or with pipx:

```bash
pipx install fastweb-sdk
```

## Quick Start

```python
from fastweb import BrowserMode, AgentBrowser

# Create a browser instance
browser = AgentBrowser(mode=BrowserMode.LIGHT)

# Navigate to a page
page = browser.goto("https://example.com")

# Access structured data
print("Page content:")
print(page.markdown)

print(f"Found {len(page.links)} links")
print("First 5 links:", page.links[:5])

# Extract main content
main_content = page.get_main_content()
print("Main content preview:", main_content[:200] + "...")

# Find specific links
github_links = page.find_links_by_text("github")
print("GitHub links:", github_links)

# Close browser when done
browser.close()
```

## Browser Modes

### Light Mode (Default)

- **Use case**: Reading articles, scraping static content, extracting links
- **Performance**: < 15MB RAM, instant startup
- **Capabilities**: HTML parsing, markdown conversion, link extraction
- **Limitations**: No JavaScript execution

```python
browser = AgentBrowser(mode=BrowserMode.LIGHT)
```

### Render Mode

- **Use case**: SPAs, form filling, visual verification
- **Performance**: Higher memory usage, slower startup
- **Capabilities**: Full JavaScript execution, screenshots, interaction

```python
browser = AgentBrowser(mode=BrowserMode.RENDER)
```

## API Reference

### AgentBrowser

Main browser class for web automation.

#### Methods

- `goto(url: str) -> Page`: Navigate to URL and return structured page data
- `close()`: Close the browser session

#### Parameters

- `mode`: BrowserMode.LIGHT or BrowserMode.RENDER
- `timeout`: Request timeout in seconds (default: 30)
- `user_agent`: Custom user agent string

### Page

Structured data from a web page.

#### Attributes

- `url: str`: The page URL
- `markdown: str`: Clean markdown content
- `links: List[str]`: Extracted links
- `screenshot: Optional[str]`: Base64-encoded screenshot (render mode only)

#### Methods

- `get_main_content() -> str`: Extract main content, skipping headers/footers
- `find_links_by_text(text: str) -> List[str]`: Find links containing specific text

## Context Manager

Use the browser as a context manager for automatic cleanup:

```python
from fastweb import BrowserMode, AgentBrowser

with AgentBrowser(mode=BrowserMode.LIGHT) as browser:
    page = browser.goto("https://example.com")
    print(page.markdown)
# Browser automatically closed
```

## Security

- All HTTP requests use TLS
- No arbitrary code execution
- Input validation and sanitization
- **Explicit Installation**: Binary must be installed separately via `curl -sL https://fastweb.b4n1.com/install | bash` — no automatic downloads

## License

MIT OR Apache-2.0