"""
FastWeb Python SDK - Browser automation for AI agents

This module provides a Python interface to the FastWeb Rust engine.
The FastWeb binary must be installed separately via: python -m fastweb install
"""

import ast
import json
import os
import subprocess
import sys
from dataclasses import dataclass
from enum import Enum
from typing import List, Optional
import requests

# Use system CA certificates instead of certifi bundle
os.environ.setdefault("REQUESTS_CA_BUNDLE", "/etc/ssl/certs/ca-certificates.crt")
os.environ.setdefault("SSL_CERT_FILE", "/etc/ssl/certs/ca-certificates.crt")


class BrowserMode(Enum):
    """Browser execution modes."""

    LIGHT = "light"
    RENDER = "render"


@dataclass
class Page:
    """Structured page data returned by FastWeb."""

    url: str
    markdown: str
    links: List[str]
    screenshot: Optional[str] = None

    def get_main_content(self) -> str:
        """Extract main content from markdown."""
        lines = self.markdown.split("\n")
        content_lines = lines[2:] if len(lines) > 2 else lines
        return "\n".join(content_lines).strip()

    def find_links_by_text(self, text: str) -> List[str]:
        """Find links containing specific text."""
        return [link for link in self.links if text.lower() in link.lower()]


def get_fastweb_binary() -> Optional[str]:
    """Find fastweb binary in common install locations."""
    import os
    from pathlib import Path
    import shutil

    # Check standard locations where the install script puts it
    possible_locations = [
        "/usr/local/bin/fastweb",
        "/usr/bin/fastweb",
        str(Path.home() / ".local/bin/fastweb"),
        str(Path.home() / ".fastweb/bin/fastweb"),
    ]

    for loc in possible_locations:
        if os.path.isfile(loc) and os.access(loc, os.X_OK):
            return loc

    return None


from .errors import BinaryNotFoundError


class AgentBrowser:
    """
    FastWeb Agent Browser

    A browser instance optimized for AI agent workflows.
    Requires FastWeb binary to be installed via: python -m fastweb install

    Example:
        >>> browser = AgentBrowser(mode=BrowserMode.LIGHT)
        >>> page = browser.goto("https://example.com")
        >>> print(page.markdown)
    """

    def __init__(
        self,
        mode: BrowserMode = BrowserMode.LIGHT,
        timeout: int = 30,
        user_agent: str = "FastWeb-Agent/1.0",
    ):
        self.mode = mode
        self.timeout = timeout
        self.user_agent = user_agent
        self.session = requests.Session()
        self.session.verify = "/etc/ssl/certs/ca-certificates.crt"
        self.session.headers.update(
            {
                "User-Agent": user_agent,
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                "Accept-Language": "en-US,en;q=0.5",
                "Accept-Encoding": "gzip, deflate",
                "DNT": "1",
                "Connection": "keep-alive",
                "Upgrade-Insecure-Requests": "1",
            }
        )
        # Verify binary is available - will raise BinaryNotFoundError if not found
        from .errors import BinaryNotFoundError

        binary_path = get_fastweb_binary()
        if not binary_path:
            raise BinaryNotFoundError()

    @property
    def binary_path(self) -> str:
        """Get fastweb binary path."""
        binary_path = get_fastweb_binary()
        if not binary_path:
            from .errors import BinaryNotFoundError

            raise BinaryNotFoundError()
        return binary_path

    def goto(self, url: str) -> Page:
        """Navigate to a URL and extract structured content using the Rust binary."""
        try:
            result = subprocess.run(
                [self.binary_path, "goto", url, "--mode", self.mode.value],
                capture_output=True,
                text=True,
                timeout=self.timeout,
            )

            if result.returncode != 0:
                raise RuntimeError(f"Binary error: {result.stderr.strip()}")

            return self._parse_output(url, result.stdout)

        except subprocess.TimeoutExpired:
            raise RuntimeError(f"Binary timed out after {self.timeout}s")

    def _parse_output(self, url: str, output: str) -> Page:
        """Parse text output from the Rust binary."""
        markdown = ""
        links = []

        for line in output.splitlines():
            if line.startswith("URL:"):
                continue
            elif line.startswith("Markdown:"):
                continue
            elif line.startswith("Links:"):
                try:
                    links = ast.literal_eval(line[6:].strip())
                except (ValueError, SyntaxError):
                    links = []
            else:
                markdown += line + "\n"

        return Page(
            url=url,
            markdown=markdown.strip(),
            links=links,
        )

    def close(self):
        """Close the browser session."""
        self.session.close()


def get_fastweb_version() -> str:
    """Get FastWeb binary version."""
    try:
        result = subprocess.run(
            [get_fastweb_binary(), "--version"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode == 0:
            return result.stdout.strip()
    except Exception:
        pass
    return "unknown"
