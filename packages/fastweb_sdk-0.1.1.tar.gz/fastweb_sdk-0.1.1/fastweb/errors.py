"""
FastWeb SDK Exceptions
"""


class BinaryNotFoundError(RuntimeError):
    """Raised when FastWeb binary is not found."""

    def __init__(self):
        super().__init__(
            "FastWeb binary not found. Please install it first:\n"
            "  python -m fastweb install\n"
            "Or manually:\n"
            "  curl -sL https://fastweb.b4n1.com/install | bash"
        )
