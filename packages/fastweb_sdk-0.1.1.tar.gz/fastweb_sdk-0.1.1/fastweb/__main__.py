"""
FastWeb CLI Entry Point
"""

import os
import sys
import tempfile
from pathlib import Path


def install_command():
    """Handle the 'python -m fastweb install' command."""
    from .browser import get_fastweb_binary, get_fastweb_version

    # Check if already installed
    existing = get_fastweb_binary()
    if existing:
        version = get_fastweb_version()
        print(f"FastWeb already installed at: {existing}")
        print(f"Version: {version}")
        response = input("Reinstall? (y/N): ").lower().strip()
        if response not in ("y", "yes"):
            print("Installation cancelled.")
            return

    # Determine install location
    if os.access("/usr/local/bin", os.W_OK):
        install_dir = Path("/usr/local/bin")
        use_sudo = False
    elif os.access(str(Path.home() / ".local/bin"), os.W_OK):
        install_dir = Path.home() / ".local/bin"
        use_sudo = False
    else:
        install_dir = Path.home() / ".fastweb" / "bin"
        use_sudo = False  # User directory, no sudo needed

    install_dir.mkdir(parents=True, exist_ok=True)
    binary_path = install_dir / "fastweb"

    # Download binary
    version_url = "https://fastweb.b4n1.com/latest-version"
    print(f"\nChecking latest version...")

    try:
        import requests

        resp = requests.get(version_url, timeout=10)
        version_info = resp.json()
        download_url = version_info.get("url")
        version = version_info.get("version", "unknown")
        print(f"Latest version: {version}")
        print(f"Downloading from: {download_url}")
    except Exception as e:
        print(f"Error getting version info: {e}")
        sys.exit(1)

    print(f"\nDownloading FastWeb {version}...")
    try:
        resp = requests.get(download_url, timeout=60)
        resp.raise_for_status()

        import tarfile

        with tempfile.NamedTemporaryFile(suffix=".tar.gz", delete=False) as tmp_tar:
            tmp_tar.write(resp.content)
            tmp_tar_path = tmp_tar.name

        try:
            # Extract and install binary
            with tarfile.open(tmp_tar_path, "r:gz") as tar:
                # Find the binary in the tar
                for member in tar.getmembers():
                    if member.isfile() and member.name.endswith(
                        "/fastweb-v0.1.0-x86_64"
                    ):
                        # Extract the binary
                        binary_data = tar.extractfile(member)
                        if binary_data:
                            with open(binary_path, "wb") as f:
                                f.write(binary_data.read())
                            break
                else:
                    # Fallback: look for any executable
                    for member in tar.getmembers():
                        if member.isfile():
                            binary_data = tar.extractfile(member)
                            if binary_data:
                                with open(binary_path, "wb") as f:
                                    f.write(binary_data.read())
                                break

            # Make executable
            if use_sudo:
                import subprocess

                subprocess.run(["chmod", "+x", str(binary_path)], check=True)
                if str(binary_path).startswith("/usr/local/bin") or str(
                    binary_path
                ).startswith("/usr/bin"):
                    subprocess.run(
                        ["sudo", "chmod", "+x", str(binary_path)], check=True
                    )
            else:
                os.chmod(binary_path, 0o755)

            # Verify installation
            installed_version = get_fastweb_version()
            print(f"✓ FastWeb {installed_version} installed to: {binary_path}")

            if not use_sudo:
                # Add to PATH instructions
                rc_file = Path.home() / (
                    ".bashrc"
                    if os.environ.get("SHELL", "").endswith("bash")
                    else ".zshrc"
                )
                path_line = f'export PATH="{install_dir}:$PATH"'
                if rc_file.exists():
                    content = rc_file.read_text()
                    if path_line not in content:
                        print(f"\nTo use FastWeb, add this to your {rc_file.name}:")
                        print(f"  {path_line}")
                else:
                    print(
                        f"\nTo use FastWeb, add this to your shell rc file (~/.bashrc or ~/.zshrc):"
                    )
                    print(f"  {path_line}")

        finally:
            try:
                os.unlink(tmp_tar_path)
            except:
                pass

    except Exception as e:
        print(f"Error installing FastWeb: {e}")
        sys.exit(1)


if __name__ == "__main__":
    install_command()
