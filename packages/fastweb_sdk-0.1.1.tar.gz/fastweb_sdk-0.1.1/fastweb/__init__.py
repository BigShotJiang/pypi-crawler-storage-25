"""
FastWeb Python SDK
Zero-overhead, high-speed web execution for sovereign AI agents.

NOTE: The FastWeb binary must be installed separately via:
    python -m fastweb install

Or manually:
    curl -sL https://fastweb.b4n1.com/install | bash
"""

from .browser import AgentBrowser, BrowserMode, Page
from .errors import BinaryNotFoundError

__version__ = "0.1.0"
__author__ = "Bani Montoya"
__email__ = "banimontoya@gmail.com"

__all__ = ["AgentBrowser", "BrowserMode", "Page", "BinaryNotFoundError"]
