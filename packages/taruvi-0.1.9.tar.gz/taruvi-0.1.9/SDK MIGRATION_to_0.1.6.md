# Migration Guide: → v0.1.6

This guide covers every code change you need to make when upgrading the Taruvi Python SDK.

---

## Breaking Changes at a Glance

| What changed | Old | New |
|---|---|---|
| Query entry point | `client.database.query("table")` | `client.database.from_("table")` |
| Query execution | `.get()` | `.execute()` |
| Query return type | `list[dict]` | `{"data": [...], "total": N}` |
| Graph type filter | `.relationship_types([...])` | `.types([...])` |
| Edge operations | `client.database.list_edges(...)` | `client.database.from_("table").edges().execute()` |
| Sort query param | `_sort=field&_order=desc` | `ordering=-field` |
| User methods | `get_user()`, `create_user()`, etc. | `get()`, `create()`, etc. |
| Secret methods | `list_secrets()`, `get_secret()`, `get_secrets()` | `list()`, `get()`, `list(keys=[...])` |
| Secrets list response | `result["results"]` | `result["data"]` |
| `get_invocation()` | `get_invocation(id, app_slug=...)` | `get_invocation(id)` |
| `list_invocations()` | `list_invocations(app_slug=...)` | `list_invocations()` |

---

## 1. Database Queries

### Entry point: `query()` → `from_()`

```python
# Old
users = client.database.query("users").get()

# New
result = client.database.from_("users").execute()
users = result["data"]
```

### Execution: `.get()` → `.execute()`

```python
# Old
active = client.database.query("users").filter("is_active", "eq", True).get()

# New
result = client.database.from_("users").filter("is_active", "eq", True).execute()
active = result["data"]
```

### Return type changed

`.execute()` now returns `{"data": [...], "total": N}` instead of a plain list.

```python
# Old
users = client.database.query("users").get()
for user in users:
    print(user["name"])
print(len(users))

# New
result = client.database.from_("users").execute()
for user in result["data"]:
    print(user["name"])
print(result["total"])
```

### `first()` and `count()` — no change needed

```python
user = client.database.from_("users").first()
total = client.database.from_("users").filter("is_active", "eq", True).count()
```

---

## 2. Graph Traversal

### `.relationship_types()` → `.types()`

```python
# Old
tree = (
    client.database.from_("employees")
    .relationship_types(["manager", "dotted_line"])
    .include("descendants")
    .execute()
)

# New
tree = (
    client.database.from_("employees")
    .types(["manager", "dotted_line"])
    .include("descendants")
    .execute()
)
```

`.format()`, `.include()`, `.depth()` are unchanged.

---

## 3. Edge Operations

Standalone edge methods (`list_edges`, `create_edges`, `update_edge`, `delete_edges`) have been removed. All edge operations now go through the `.edges()` query builder.

### List edges

```python
# Old
edges = client.database.list_edges("employees", types=["manager"], page=1, page_size=10)

# New
result = (
    client.database.from_("employees").edges()
    .filter("type", "eq", "manager")
    .page_size(10).page(1)
    .execute()
)
```

### Create edges

```python
# Old
result = client.database.create_edges("employees", [
    {"from_id": 1, "to_id": 2, "type": "manager"}
])

# New
result = (
    client.database.from_("employees").edges()
    .create([{"from_id": 1, "to_id": 2, "type": "manager"}])
    .execute()
)
```

### Update edge

```python
# Old
result = client.database.update_edge("employees", 10, {
    "metadata": {"end_date": "2026-01-29"}
})

# New
result = (
    client.database.from_("employees").edges()
    .get("10").update({"metadata": {"end_date": "2026-01-29"}})
    .execute()
)
```

### Delete edges

```python
# Old
result = client.database.delete_edges("employees", edge_ids=[9, 10])

# New
result = (
    client.database.from_("employees").edges()
    .delete([9, 10])
    .execute()
)
```

### Edge field names

The SDK no longer auto-converts `from_id`/`to_id` to `from`/`to`. The body is passed as-is — use whichever field names your backend expects.

---

## 4. Sort Query Parameter Fix

`sort()` was sending `_sort` and `_order` as separate query params, which the backend rejected with a 400 error. It now sends a single `ordering` param matching Django REST Framework format.

No code changes needed — `.sort("field", "desc")` works the same, but now actually produces correct API requests.

```python
# This now works (was broken before)
result = client.database.from_("users").sort("created_at", "desc").execute()
# Sends: ?ordering=-created_at (instead of ?_sort=created_at&_order=desc)
```

---

## 5. Users Module

All methods dropped their redundant prefixes.

```python
# Old                                       # New
client.users.get_user("alice")              client.users.get("alice")
client.users.create_user(...)               client.users.create(...)
client.users.update_user(...)               client.users.update(...)
client.users.delete_user("alice")           client.users.delete("alice")
client.users.list_users(...)                client.users.list(...)
client.users.get_user_apps("alice")         client.users.apps("alice")
```

### `create()` and `update()` now accept a dict (matching JS SDK)

```python
# Old — keyword arguments
client.users.create(
    username="alice",
    email="alice@example.com",
    password="secure123",
    confirm_password="secure123",
    first_name="Alice"
)

client.users.update(
    "alice",
    email="newemail@example.com",
    first_name="Alice Updated"
)

# New — dict body (consistent with JS SDK)
client.users.create({
    "username": "alice",
    "email": "alice@example.com",
    "password": "secure123",
    "confirm_password": "secure123",
    "first_name": "Alice"
})

client.users.update("alice", {
    "email": "newemail@example.com",
    "first_name": "Alice Updated"
})
```

---

## 6. Secrets Module

### Method renames

```python
# Old                                              # New
client.secrets.list_secrets()                      client.secrets.list()
client.secrets.get_secret("API_KEY")               client.secrets.get("API_KEY")
client.secrets.get_secrets(["K1", "K2"])            client.secrets.list(keys=["K1", "K2"])
```

### `list()` response format changed

```python
# Old
result = client.secrets.list_secrets(secret_type="api_key")
for s in result["results"]:
    print(s["key"])

# New
result = client.secrets.list(secret_type="api_key")
for s in result["data"]:
    print(s["key"])
print(result["total"])
```

### Auto-inherits `app_slug`

`list()` and `get()` now automatically use the client's `app_slug` if you don't pass an explicit `app` parameter. You can remove `app=` if it matches your client config.

---

## 7. Functions Module

### `get_invocation()` — `app_slug` parameter removed

```python
# Old
inv = client.functions.get_invocation("inv_123", app_slug="my-app")

# New
inv = client.functions.get_invocation("inv_123")
```

### `list_invocations()` — `app_slug` parameter removed

```python
# Old
invocations = client.functions.list_invocations(app_slug="my-app", status="SUCCESS")

# New
invocations = client.functions.list_invocations(status="SUCCESS")
```

---

## 8. New Features (no migration needed)

These are additive — no existing code breaks.

### Full-text search

```python
result = client.database.from_("articles").search("machine learning").execute()
```

### Aggregations

```python
result = (
    client.database.from_("orders")
    .aggregate("sum(total)", "count(*)")
    .group_by("status")
    .having("sum_total > 1000")
    .execute()
)
```

### App settings

```python
settings = client.app.settings()
```

---

## Migration Checklist

- [ ] `database.query(...)` → `database.from_(...)`
- [ ] `.get()` → `.execute()` on query builders
- [ ] Update all code consuming query results: iterate `result["data"]` instead of `result` directly
- [ ] `.relationship_types([...])` → `.types([...])`
- [ ] Migrate standalone edge methods to `.edges()` builder
- [ ] `sort()` now works correctly — no code changes needed, but verify sort results
- [ ] `users.get_user()` → `.get()`, `create_user()` → `.create()`, etc.
- [ ] `users.create(username=..., email=...)` → `users.create({"username": ..., "email": ...})`
- [ ] `users.update("alice", email=...)` → `users.update("alice", {"email": ...})`
- [ ] `secrets.list_secrets()` → `.list()`, `get_secret()` → `.get()`, `get_secrets(keys)` → `.list(keys=keys)`
- [ ] Secrets list: `result["results"]` → `result["data"]`
- [ ] Remove `app_slug` from `get_invocation()` and `list_invocations()` calls
