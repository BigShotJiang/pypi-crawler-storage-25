from .geodesy import haversine_distance

def trajectory_length(points):
    """
    计算轨迹总长度
    points: list of (lat, lon) 元组
    返回：米
    """
    total = 0.0
    for i in range(1, len(points)):
        total += haversine_distance(points[i-1][0], points[i-1][1],
                                    points[i][0], points[i][1])
    return total

def elevation_stats(elevations):
    """
    计算高程统计信息
    elevations: list of 高程值（米）
    返回字典：{'min', 'max', 'mean'}
    """
    if not elevations:
        return {'min': None, 'max': None, 'mean': None}
    return {
        'min': min(elevations),
        'max': max(elevations),
        'mean': sum(elevations) / len(elevations)
    }

def speed_between_points(lat1, lon1, lat2, lon2, time_seconds):
    """
    计算两点间的平均速度（米/秒）
    """
    dist = haversine_distance(lat1, lon1, lat2, lon2)
    if time_seconds > 0:
        return dist / time_seconds
    return 0.0