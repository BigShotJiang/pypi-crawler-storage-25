def parse_osm_response(data):
    """
    解析 OpenStreetMap 地理编码服务的返回结果
    data: requests.get(...).json()
    返回：{'lat': float, 'lon': float, 'display_name': str} 或 None
    """
    if not data or not isinstance(data, list):
        return None
    result = data[0]
    return {
        'lat': float(result['lat']),
        'lon': float(result['lon']),
        'display_name': result['display_name']
    }