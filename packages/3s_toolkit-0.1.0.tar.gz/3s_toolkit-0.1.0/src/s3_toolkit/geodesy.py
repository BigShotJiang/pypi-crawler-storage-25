import numpy as np

def haversine_distance(lat1, lon1, lat2, lon2):
    """
    计算两点间的大圆距离（单位：米）
    参数：纬度、经度，单位：度
    """
    R = 6371000  # 地球平均半径，米
    phi1 = np.radians(lat1)
    phi2 = np.radians(lat2)
    dphi = np.radians(lat2 - lat1)
    dlambda = np.radians(lon2 - lon1)

    a = np.sin(dphi / 2) ** 2 + np.cos(phi1) * np.cos(phi2) * np.sin(dlambda / 2) ** 2
    c = 2 * np.arctan2(np.sqrt(a), np.sqrt(1 - a))
    return R * c

def latlon_to_meters(lat, lon):
    """
    将经纬度转换为 Web 墨卡托米制坐标（近似）
    返回 (x, y)，单位：米
    """
    x = lon * 20037508.34 / 180
    y = np.log(np.tan((90 + lat) * np.pi / 360)) / (np.pi / 180)
    y = y * 20037508.34 / 180
    return x, y