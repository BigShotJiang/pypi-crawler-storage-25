import numpy as np
from scipy.spatial import distance_matrix

def nearest_neighbor_distance(points):
    """
    计算点集平均最近邻距离（简化版）
    points: list of (x, y) 坐标，单位：度（经纬度）
    返回：米（假设1度 ≈ 111公里）
    """
    coords = np.array(points)
    if len(coords) <= 1:
        return 0.0
    dist_mat = distance_matrix(coords, coords)
    np.fill_diagonal(dist_mat, np.inf)
    min_dists = np.min(dist_mat, axis=1)
    # 将平均最小距离（度）转换为米（粗略）
    return np.mean(min_dists) * 111000