# 3s-toolkit

轻量级 GNSS、大地测量和空间分析工具包，专为教学和快速原型设计。

## 安装
pip install 3s-toolkit
快速示例
python
from s3_toolkit import haversine_distance

dist = haversine_distance(30.5235, 114.3575, 39.9042, 116.4074)
print(f"武汉大学到天安门距离：{dist:.0f} 米")
功能列表
haversine_distance – 大圆距离计算

trajectory_length – 轨迹总长度

elevation_stats – 高程统计

speed_between_points – 点间速度

nearest_neighbor_distance – 最近邻分析

parse_osm_response – 地理编码响应解析

许可证
Apache 2.0

## 🧪 第四步：本地安装测试

在 `3s-toolkit` 根目录打开终端（PowerShell），执行：

pip install -e .
然后测试导入：

python -c "import s3_toolkit as stk; print(stk.haversine_distance(30, 114, 31, 115))"
如果没有报错并输出了一个数字（如 111195.08），说明包已正常工作。