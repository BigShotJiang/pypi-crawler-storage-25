import numpy as np
import pytest

from pyproximal.proximal import ETP, SCAD, Geman, Log, Log1, QuadraticEnvelopeCard
from pyproximal.utils import moreau

par1 = {
    "nx": 10,
    "sigma": 1.0,
    "a": 2.1,
    "gamma": 0.5,
    "mu": 0.5,
    "dtype": "float32",
}  # even float32
par2 = {
    "nx": 11,
    "sigma": 2.0,
    "a": 3.7,
    "gamma": 5.0,
    "mu": 1.5,
    "dtype": "float64",
}  # odd float64


def test_SCAD_sigmaneg():
    """Check SCAD returns an error for negative sigma"""
    with pytest.raises(ValueError, match='Variable "sigma" must be positive'):
        _ = SCAD(sigma=-1.0)

    with pytest.raises(ValueError, match='Variable "a" must be larger'):
        _ = SCAD(sigma=1.0, a=1.7)


@pytest.mark.parametrize("par", [(par1), (par2)])
def test_SCAD(par):
    """SCAD penalty and proximal/dual proximal"""
    np.random.seed(10)
    scad = SCAD(sigma=par["sigma"], a=par["a"])
    # SCAD should behave like l1-norm when values are small
    x = np.random.normal(0.0, 0.1, par["nx"]).astype(par["dtype"])
    assert scad(x) == par["sigma"] * np.linalg.norm(x, 1)

    # SCAD should behave like hard-thresholding when values are large
    x = np.random.normal(10.0, 0.1, par["nx"]).astype(par["dtype"])
    assert scad(x) == pytest.approx(
        (par["a"] + 1) * par["sigma"] ** 2 / 2 * np.count_nonzero(x)
    )

    # prox / dualprox
    tau = 2.0
    x = np.random.normal(0.0, 10.0, par["nx"]).astype(par["dtype"])
    assert moreau(scad, x, tau)


def test_Log_Log1_neg():
    """Check Log/Log1 returns an error for negative inputs"""
    with pytest.raises(ValueError, match='Variable "sigma" must be positive'):
        _ = Log(sigma=-1.0)

    with pytest.raises(ValueError, match='Variable "gamma" must be positive'):
        _ = Log(sigma=1.0, gamma=-1.0)

    with pytest.raises(ValueError, match='Variable "delta" must be positive'):
        _ = Log1(1.0, delta=-1.0)


@pytest.mark.parametrize("par", [(par1), (par2)])
def test_Log(par):
    """Log penalty and proximal/dual proximal"""
    np.random.seed(10)

    log = Log(sigma=par["sigma"], gamma=par["gamma"])
    x = np.random.normal(0.0, 10.0, par["nx"]).astype(par["dtype"])

    # norm
    expected = (
        par["sigma"]
        / np.log(par["gamma"] + 1)
        * np.linalg.norm(np.log(par["gamma"] * np.abs(x) + 1), 1)
    )
    assert log(x) == pytest.approx(expected)

    # prox / dualprox
    tau = 2.0
    assert moreau(log, x, tau)


@pytest.mark.parametrize("par", [(par1), (par2)])
def test_Log1(par):
    """Log1 penalty and proximal/dual proximal"""
    np.random.seed(10)

    log = Log1(sigma=par["sigma"])
    x = np.random.normal(0.0, 10.0, par["nx"]).astype(par["dtype"])

    # norm
    expected = float(np.sum(np.log(np.abs(x) + log.delta)))
    assert log(x) == pytest.approx(expected)

    # prox / dualprox
    tau = 2.0
    assert moreau(log, x, tau)


def test_ETP_sigma_gamma_neg():
    """Check ETP returns an error for negative sigma and gamma"""
    with pytest.raises(ValueError, match='Variable "sigma" must be positive'):
        _ = ETP(sigma=-1.0)

    with pytest.raises(ValueError, match='Variable "gamma" must be strictly'):
        _ = ETP(sigma=1.0, gamma=0.0)


@pytest.mark.parametrize("par", [(par1), (par2)])
def test_ETP(par):
    """Exponential-type penalty and proximal/dual proximal"""
    np.random.seed(10)

    etp = ETP(sigma=par["sigma"], gamma=par["gamma"])
    x = np.random.normal(0.0, 10.0, par["nx"]).astype(par["dtype"])

    # norm
    expected = (
        par["sigma"]
        / (1 - np.exp(-par["gamma"]))
        * np.linalg.norm((1 - np.exp(-par["gamma"] * np.abs(x))), 1)
    )
    assert etp(x) == pytest.approx(expected)

    # prox / dualprox
    tau = 2.0
    assert moreau(etp, x, tau)


def test_Geman_sigma_gamma_neg():
    """Check Geman returns an error for negative sigma and gamma"""
    with pytest.raises(ValueError, match='Variable "sigma" must be positive'):
        _ = Geman(sigma=-1.0)

    with pytest.raises(ValueError, match='Variable "gamma" must be strictly'):
        _ = Geman(sigma=1.0, gamma=0.0)


@pytest.mark.parametrize("par", [(par1), (par2)])
def test_Geman(par):
    """Geman penalty and proximal/dual proximal"""
    np.random.seed(10)

    geman = Geman(sigma=par["sigma"], gamma=par["gamma"])
    x = np.random.normal(0.0, 10.0, par["nx"]).astype(par["dtype"])

    # norm
    expected = par["sigma"] * np.linalg.norm(np.abs(x) / (np.abs(x) + par["gamma"]), 1)
    assert geman(x) == pytest.approx(expected)

    # prox / dualprox
    tau = 2.0
    assert moreau(geman, x, tau)


@pytest.mark.parametrize("par", [(par1), (par2)])
def test_QuadraticEnvelopeCard(par):
    """QuadraticEnvelopeCard penalty and proximal/dual proximal"""
    np.random.seed(10)

    fmu = QuadraticEnvelopeCard(mu=par["mu"])

    # Quadratic envelope of the l0-penalty
    x = np.random.normal(0.0, 10.0, par["nx"]).astype(par["dtype"])
    expected = np.linalg.norm(
        par["mu"] - 0.5 * np.maximum(0, np.sqrt(2 * par["mu"]) - np.abs(x)) ** 2, 1
    )
    assert fmu(x) == pytest.approx(expected)

    # Check proximal operator
    tau = 0.25
    assert moreau(fmu, x, tau)
    tau = 1.25
    assert moreau(fmu, x, tau)
