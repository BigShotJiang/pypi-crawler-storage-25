import numpy as np
import pytest
from numpy.testing import assert_array_almost_equal, assert_array_equal
from pylops import Identity, MatrixMult, Restriction

import pyproximal
from pyproximal.proximal import (
    L1,
    L2,
    Nonlinear,
    Orthogonal,
    Quadratic,
    QuadraticEnvelopeCardIndicator,
    QuadraticEnvelopeRankL2,
    SingularValuePenalty,
    VStack,
)
from pyproximal.utils import moreau

par1 = {"nx": 10, "ny": 10, "sigma": 1.0, "dtype": "float32"}  # even float32
par2 = {"nx": 11, "ny": 14, "sigma": 2.0, "dtype": "float64"}  # odd float64


def test_Quadratic_nonsquare():
    """Check Quadratic returns an error if the operator is not square"""
    np.random.seed(10)
    A = np.random.normal(0, 1, (10, 11))

    with pytest.raises(ValueError, match="Op must be square"):
        _ = Quadratic(Op=MatrixMult(A))


@pytest.mark.parametrize("par", [(par1), (par2)])
def test_Quadratic(par):
    """Quadratic functional and proximal/dual proximal"""
    np.random.seed(10)
    A = np.random.normal(0, 1, (par["nx"], par["nx"])).astype(par["dtype"])
    A = A.T @ A
    b = np.ones(par["nx"]).astype(par["dtype"])

    for explicit in [False, True]:
        Op = MatrixMult(A)
        Op.explicit = explicit
        quad = Quadratic(Op=Op, b=b, niter=500)
        x = np.random.normal(0.0, 1.0, par["nx"]).astype(par["dtype"])

        # call
        _ = quad(x)

        # grad
        grad = A @ x + b
        assert_array_almost_equal(quad.grad(x), grad, decimal=4)

        # prox / dualprox
        tau = 2.0
        assert moreau(quad, x, tau)


@pytest.mark.parametrize("par", [(par1), (par2)])
def test_DotProduct(par):
    """Dot product functional and proximal/dual proximal"""
    np.random.seed(10)
    b = np.ones(par["nx"]).astype(par["dtype"])
    quad = Quadratic(b=b)
    x = np.random.normal(0.0, 1.0, par["nx"]).astype(par["dtype"])

    # call
    _ = quad(x)

    # grad
    assert_array_almost_equal(quad.grad(x), b, decimal=4)

    # prox / dualprox
    tau = 2.0
    assert moreau(quad, x, tau)


@pytest.mark.parametrize("par", [(par1), (par2)])
def test_Constant(par):
    """Constant functional and proximal/dual proximal"""
    np.random.seed(10)
    quad = Quadratic(c=5.0)
    x = np.random.normal(0.0, 1.0, par["nx"]).astype(par["dtype"])

    # call
    _ = quad(x)

    # grad
    assert_array_almost_equal(quad.grad(x), 0.0, decimal=4)

    # prox / dualprox
    tau = 2.0
    assert moreau(quad, x, tau)


@pytest.mark.parametrize("par", [(par1), (par2)])
def test_SemiOrthogonal(par):
    """L1 functional with Semi-Orthogonal operator and proximal/dual proximal"""
    np.random.seed(10)
    l1 = L1()
    Op = 2 * Identity(par["nx"])
    b = np.arange(par["nx"])
    orth = Orthogonal(l1, Op, b=b, partial=True, alpha=4.0)

    # norm
    x = np.random.normal(0.0, 1.0, par["nx"]).astype(par["dtype"])
    assert orth(x) == pytest.approx(l1(Op @ x + b))

    # prox / dualprox
    tau = 2.0
    assert moreau(orth, x, tau)


@pytest.mark.parametrize("par", [(par1), (par2)])
def test_Orthogonal(par):
    """L1 functional with Orthogonal operator and proximal/dual proximal"""
    np.random.seed(10)
    l1 = L1()
    Op = Identity(par["nx"], inplace=False)
    b = np.arange(par["nx"])
    orth = Orthogonal(l1, Op, b=b)

    # norm
    x = np.random.normal(0.0, 1.0, par["nx"]).astype(par["dtype"])
    assert orth(x) == pytest.approx(l1(Op @ x + b))

    # prox / dualprox
    tau = 2.0
    assert moreau(orth, x, tau)


def test_VStack_nodim():
    """VStack operator raises error when neiter restr not dim are provided"""
    with pytest.raises(ValueError, match="Provide either nn or restr"):
        _ = VStack(
            [
                L2(),
            ],
            None,
            None,
        )


@pytest.mark.parametrize("par", [(par1), (par2)])
def test_VStack_wrongdim(par):
    """VStack call/prox/grad raise error when input has wrong dimensions"""
    np.random.seed(10)
    nxs = [par["nx"] // 4] * 4
    nxs[-1] = par["nx"] - np.sum(nxs[:-1])
    l2 = L2()
    vstack = VStack([l2] * 4, nxs)

    with pytest.raises(ValueError, match="x must have size"):
        vstack(np.ones(nxs[0]))

    with pytest.raises(ValueError, match="x must have size"):
        vstack.prox(np.ones(nxs[0]), 2.0)

    with pytest.raises(ValueError, match="x must have size"):
        vstack.grad(np.ones(nxs[0]))


@pytest.mark.parametrize("par", [(par1), (par2)])
def test_VStack(par):
    """L2 functional with VStack operator of multiple L1s"""
    np.random.seed(10)
    nxs = [par["nx"] // 4] * 4
    nxs[-1] = par["nx"] - np.sum(nxs[:-1])
    l2 = L2()
    vstack = VStack([l2] * 4, nxs)

    # functional
    x = np.random.normal(0.0, 1.0, par["nx"]).astype(par["dtype"])
    assert_array_almost_equal(l2(x), vstack(x), decimal=4)

    # gradient
    assert_array_almost_equal(l2.grad(x), vstack.grad(x), decimal=4)

    # prox / dualprox
    tau = 2.0
    assert_array_equal(l2.prox(x, tau), vstack.prox(x, tau))

    # moreau
    assert moreau(vstack, x, tau)


@pytest.mark.parametrize(
    "par",
    [
        (par1),
    ],
)
def test_VStack_restriction(par):
    """L2 functional with VStack operator of multiple L1s using restriction"""
    np.random.seed(10)
    nxs = [par["nx"] // 2] * 2
    nxs[-1] = par["nx"] - np.sum(nxs[:-1])
    l2 = L2()
    vstack = VStack(
        [l2] * 2,
        restr=[
            Restriction(par["nx"], np.arange(par["nx"] // 2)),
            Restriction(par["nx"], par["nx"] // 2 + np.arange(par["nx"] // 2)),
        ],
    )

    # functional
    x = np.random.normal(0.0, 1.0, par["nx"]).astype(par["dtype"])
    assert_array_almost_equal(l2(x), vstack(x), decimal=4)

    # gradient
    assert_array_almost_equal(l2.grad(x), vstack.grad(x), decimal=4)

    # prox / dualprox
    tau = 2.0
    assert_array_equal(l2.prox(x, tau), vstack.prox(x, tau))

    # moreau
    assert moreau(vstack, x, tau)


def test_Nonlinear():
    """Nonlinear proximal operator."""
    np.random.seed(10)

    # Check error if methods are not implemented
    with pytest.raises(TypeError, match="Can't instantiate abstract"):
        _ = Nonlinear(np.ones(10))

    # Implement basic nonlinear function and test methods
    class Sin(Nonlinear):
        def fun(self, x):
            return 1 - np.sin(np.pi * x)

        def grad(self, x):
            return -np.pi * np.cos(np.pi * x)

        def optimize(self):
            x = self.x0.copy()
            for _ in range(self.niter):
                _ = self._fungradprox(x, self.tau)  # just to test the method
                dx = self._gradprox(x, self.tau)
                x -= self.alpha * dx
            return x

    sin = Sin(x0=np.full(1, 0.2), niter=100)
    sin.alpha = 1e-1

    # call
    assert sin(0.5) == 0.0
    assert sin(0.0) == 1.0

    # call and grad
    assert sin.fungrad(0.5)[1] == pytest.approx(0.0)

    # prox
    assert sin.prox(np.full(1, 0.5), 1e5)[0] == pytest.approx(0.5)


@pytest.mark.parametrize("par", [(par1), (par2)])
def test_SingularValuePenalty(par):
    """Test SingularValuePenalty"""
    np.random.seed(10)
    f_mu = pyproximal.QuadraticEnvelopeCard(mu=par["sigma"])
    penalty = SingularValuePenalty((par["nx"], 2 * par["nx"]), f_mu)

    # norm, cross-check with svd (use tolerance as two methods don't provide
    # the exact same eigenvalues)
    X = np.random.uniform(0.0, 0.1, (par["nx"], 2 * par["nx"])).astype(par["dtype"])
    _, S, _ = np.linalg.svd(X)
    assert (penalty(X.ravel()) - f_mu(S)) < 1e-3

    # prox / dualprox
    tau = 0.75
    assert moreau(penalty, X.ravel(), tau)


def test_QuadraticEnvelopeCardIndicator():
    """QuadraticEnvelopeCardIndicator penalty for various edge cases"""
    fr0 = QuadraticEnvelopeCardIndicator(5)

    # Check value for input size smaller than threshold
    assert fr0(np.ones(2)) == 0

    # Prox input size smaller than threshold
    tau = 0.1
    x = np.ones(2)
    assert_array_equal(fr0.prox(x, tau), x)

    # Prox for tau larger than 1.0 (hard-thresholding on tau)
    tau = 2.0
    x = np.full(2, 5.0)
    assert_array_equal(fr0.prox(x, tau), x)


@pytest.mark.parametrize(
    "par,expected", [(par1, 94.89988856174841), (par2, 145.6421905545182)]
)
def test_QuadraticEnvelopeCardIndicator_case01(par, expected):
    """QuadraticEnvelopeCardIndicator penalty and proximal/dual proximal"""
    np.random.seed(10)
    fr0 = QuadraticEnvelopeCardIndicator(4)

    # Quadratic envelope of the indicator function of the l0-penalty
    x = np.random.normal(0.0, 10.0, par["nx"]).astype(par["dtype"])

    # Check value
    assert fr0(x) == pytest.approx(expected)

    # Check proximal operator
    tau = 0.35
    assert moreau(fr0, x, tau)


def test_QuadraticEnvelopeCardIndicator_case02():
    """QuadraticEnvelopeCardIndicator penalty and proximal/dual proximal"""
    fr0 = QuadraticEnvelopeCardIndicator(5)

    # Quadratic envelope of the indicator function of the l0-penalty
    x = np.array([1, 1.5, 1.3, 4.1, 2.1, 1.6, 1.8, 1.8])

    # Check value
    assert fr0(x) == pytest.approx(6.206249999999999)

    # Check proximal operator
    tau = 0.75
    expected = np.array([0, 0.68571429, 0, 4.1, 2.1, 1.08571429, 1.8, 1.8])
    np.testing.assert_array_almost_equal(fr0.prox(x, tau), expected)


def test_QuadraticEnvelopeCardIndicator_case03():
    """QuadraticEnvelopeCardIndicator penalty and proximal/dual proximal"""
    fr0 = QuadraticEnvelopeCardIndicator(4)
    # Quadratic envelope of the indicator function of the l0-penalty
    x = np.array([1, -1, 1, -0.1, 1])

    # Check value
    assert fr0(x) == pytest.approx(0.09624999999999995)

    # Check proximal operator
    tau = 0.75
    expected = np.array([1, -1, 1, 0, 1])
    np.testing.assert_array_almost_equal(fr0.prox(x, tau), expected)


@pytest.mark.parametrize(
    "par,expected", [(par1, 5.931525368112523), (par2, 14.146478354862971)]
)
def test_QuadraticEnvelopeRankL2(par, expected):
    """QuadraticEnvelopeRankL2 penalty and proximal/dual proximal"""
    np.random.seed(10)
    dim = (par["nx"], par["ny"])

    # Quadratic envelope of the indicator function of rank penalty
    r0 = 8
    f = QuadraticEnvelopeRankL2(dim, r0, np.zeros(dim))
    X = np.random.normal(0, 1, dim).astype(par["dtype"])

    # Check value
    assert f(X.ravel()) == pytest.approx(expected)

    # Check proximal operator
    tau = 0.75
    assert moreau(f, X.ravel(), tau)
