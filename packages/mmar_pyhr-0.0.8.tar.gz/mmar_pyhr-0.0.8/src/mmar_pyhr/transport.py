"""
HTTP transport implementation.

Wraps pyhr_client and deploy_pyhr_server in TransportAPI interface.
Auto-registers with mmar_mimpl when imported.
"""

from typing import Any, TypeVar

from mmar_mimpl.transport_registry import register_transport

from mmar_pyhr.io_http import deploy_pyhr_server as pyhr_deploy_server
from mmar_pyhr.pyhr_config import PyhrTransportConfig
from mmar_pyhr.pyhr_framework import pyhr_client

T = TypeVar("T")


class PyhrTransport:
    """
    HTTP transport implementation.

    Wraps mmar_pyhr functionality in TransportAPI interface.
    """

    def __init__(self, config: Any = None):
        """
        Initialize HTTP transport with optional configuration.

        Args:
            config: Optional configuration (arbitrary type - application decides structure)
        """
        self.config = config

    def make_client(self, api: type[T], **kwargs: Any) -> T:
        """
        Create an HTTP client proxy.

        Args:
            api: Service interface class
            **kwargs: Must include 'address', may include transport-specific options

        Returns:
            Client proxy implementing the API interface

        Example:
            >>> transport = PyhrTransport()
            >>> client = transport.make_client(UserService, address="localhost:8000")
        """
        address = kwargs.pop("address")
        # Config can be used by application if needed
        return pyhr_client(api, address, **kwargs)

    def deploy_server(self, service: T, **kwargs: Any) -> None:
        """
        Deploy an HTTP server.

        Args:
            service: Service implementation instance
            **kwargs: Must include 'config' and 'config_server'

        Example:
            >>> from mmar_pyhr import PyhrServerConfig
            >>> transport = PyhrTransport()
            >>> transport.deploy_server(
            ...     service,
            ...     config=config,
            ...     config_server=PyhrServerConfig.load()
            ... )
        """
        # Extract pyhr-specific parameters
        config = kwargs.pop("config")
        config_server = kwargs.pop("config_server")

        # Call existing deploy_pyhr_server with expected signature
        return pyhr_deploy_server(
            service=service,
            config=config,
            config_server=config_server,
        )


# Factory function for creating PyhrTransport instances
def create_pyhr_transport(config: Any = None) -> PyhrTransport:
    """
    Factory function for creating PyhrTransport instances.

    Args:
        config: Optional configuration (arbitrary type)

    Returns:
        PyhrTransport instance
    """
    return PyhrTransport(config=config)


# Auto-register when this module is imported
register_transport("mmar_pyhr", PyhrTransportConfig, create_pyhr_transport)
