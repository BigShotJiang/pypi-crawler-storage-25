"""PYHR ~ 'Pydantic HTTP RPC'"""

import json
import types
from typing import Any, Generic, TypeVar, cast

import httpx
from loguru import logger
from mmar_mimpl import TRACE_ID, TRACE_ID_VAR
from mmar_utils.utils_inspect import (
    FuncMetadata,
    Metadatas,
    bind_args_to_tuple,
    extract_and_validate_obj_methods_metadatas,
    extract_interface_metadatas,
    get_full_name,
)

X_TRACE_ID = "X-Trace-ID"

T = TypeVar("T")


def _is_valid_address(address: str) -> bool:
    """Check if address has valid host:port format."""
    if ":" not in address:
        return False
    host, port = address.rsplit(":", 1)
    if not port.isnumeric():
        return False
    return True


def _normalize_address(address: int | str) -> str:
    """
    Normalize address to full HTTP URL.

    Examples:
        9494 -> http://localhost:9494
        :9494 -> http://localhost:9494
        localhost:9494 -> http://localhost:9494
        http://localhost:9494 -> http://localhost:9494
        https://service.example.com -> https://service.example.com
    """
    # Handle integer port
    if isinstance(address, int):
        return f"http://localhost:{address}"

    # Handle string addresses
    address = str(address)

    # Already has protocol
    if address.startswith("http://") or address.startswith("https://"):
        return address

    # Port only: :9494
    if address.startswith(":") and address[1:].isnumeric():
        return f"http://localhost{address}"

    # Just port number as string: "9494"
    if address.isnumeric():
        return f"http://localhost:{address}"

    # host:port format
    if _is_valid_address(address):
        return f"http://{address}"

    logger.warning(f"Potentially invalid address: {address}")
    return address


class ClientProxy(Generic[T]):
    """
    HTTP client proxy that wraps a service interface.

    Creates dynamic methods that serialize arguments to JSON,
    send POST requests to /api/{method_name}, and deserialize responses.
    """

    def __init__(
        self,
        service_interface: type[T],
        address: str,
        timeout: float = 30.0,
        retry_attempts: int = 3,
    ):
        if not isinstance(service_interface, type):
            si_name = type(service_interface).__name__
            raise ValueError(
                f"Expected type, found: {type(service_interface)}. "
                f"Probably you passed pyhr_client({si_name}(), ...) instead of pyhr_client({si_name}, ...)"
            )

        self.service_interface = service_interface
        self.address = address
        self.timeout = timeout
        self.retry_attempts = retry_attempts

        metadatas = extract_interface_metadatas(service_interface)
        self.metadatas = metadatas

        self.client = httpx.Client(timeout=timeout)
        self._set_proxy_methods()

    def _set_proxy_methods(self):
        """Create proxy methods for each interface method."""
        for mm in self.metadatas.values():
            proxy = self._make_method_proxy(mm)
            bound_func = types.MethodType(proxy, self)
            setattr(self, mm.name, bound_func)

    def _make_method_proxy(self, func_metadata: FuncMetadata):
        """Create a proxy function for a single method."""

        def proxy(self, *args, **kwargs):
            if args:
                raise ValueError(f"Func `{func_metadata.name}`: only kwargs supported, but args found: `{args}`")

            # Extract trace_id
            kw_get_or_pop = kwargs.get if func_metadata.has_arg(TRACE_ID) else kwargs.pop
            trace_id = kw_get_or_pop(TRACE_ID, None) or TRACE_ID_VAR.get()

            # Prepare request - serialize to JSON
            args_tuple = bind_args_to_tuple(func_metadata.args_metadata, kwargs=kwargs)
            args_bytes = func_metadata.args_adapter.dump_json(args_tuple)

            # Parse JSON bytes to plain Python dict/list (not Pydantic models)
            args_list = json.loads(args_bytes)

            # Convert tuple/list to kwargs dict
            input_names = [am.name for am in func_metadata.args_metadata]
            request_kwargs = dict(zip(input_names, args_list))

            # Set headers
            headers = {"Content-Type": "application/json"}
            if trace_id:
                headers[X_TRACE_ID] = trace_id

            # Make request
            url = f"{self.address}/api/{func_metadata.name}"

            for attempt in range(self.retry_attempts + 1):
                try:
                    response = self.client.post(url, json=request_kwargs, headers=headers)
                    response.raise_for_status()

                    result_bytes = response.content
                    result = func_metadata.result_adapter.validate_json(result_bytes)
                    return result
                except Exception as ex:
                    if attempt < self.retry_attempts:
                        logger.warning(
                            f"Request to {url} failed (attempt {attempt + 1}/{self.retry_attempts + 1}): {ex}"
                        )
                    else:
                        raise

            raise Exception(f"Request to {url} failed after {self.retry_attempts + 1} attempts")

        return proxy

    def __del__(self):
        """Clean up HTTP client."""
        try:
            self.client.close()
        except Exception:
            pass

    def __str__(self):
        return f"pyhr-client('{get_full_name(self.service_interface)}' -> '{self.address}')"


def pyhr_client(service_interface: type[T], address: str | int, timeout: float = 30.0, retry_attempts: int = 3) -> T:
    """
    Create a dynamic HTTP client for the given service interface.

    Args:
        service_interface: Service interface class with method signatures
        address: Server address (e.g., 9494, "localhost:8000", "http://api.example.com")
        timeout: Request timeout in seconds (default: 30.0)
        retry_attempts: Number of retry attempts on failure (default: 3)

    Returns:
        Client proxy implementing the service interface

    Example:
        >>> class UserService:
        ...     def get_user(self, *, user_id: int) -> dict:
        ...         ...
        >>> client = pyhr_client(UserService, "localhost:8000")
        >>> result = client.get_user(user_id=123)
    """
    address = _normalize_address(address)
    proxy = ClientProxy(service_interface, address, timeout=timeout, retry_attempts=retry_attempts)
    return cast(T, proxy)


def get_service_methods(service: Any) -> dict[str, Any]:
    """Extract methods from service object."""
    methods, _ = extract_and_validate_obj_methods_metadatas(service)
    return methods


def get_service_metadatas(service: Any) -> Metadatas:
    """Extract method metadatas from service object."""
    _, metadatas = extract_and_validate_obj_methods_metadatas(service)
    return metadatas
