# -*- coding: utf-8 -*-
# skclust/__init__.py

"""
skclust: A comprehensive hierarchical clustering toolkit
========================================================================

A scikit-learn compatible implementation of hierarchical clustering with 
advanced tree cutting, visualization, and network analysis capabilities.

Author: Josh L. Espinoza
"""

__version__ = "2026.5.11"
__author__ = "Josh L. Espinoza"

from . import hierarchical
from . import neighbors
from . import graph
from . import metrics
