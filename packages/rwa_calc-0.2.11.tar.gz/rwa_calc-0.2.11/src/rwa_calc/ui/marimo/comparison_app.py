"""
CRR vs Basel 3.1 Comparison Marimo Application.

Interactive UI for dual-framework impact analysis, capital impact waterfall,
and transitional floor schedule modelling.

Pipeline position:
    Uses DualFrameworkRunner, CapitalImpactAnalyzer, TransitionalScheduleRunner
    from engine/comparison.py to produce ComparisonBundle, CapitalImpactBundle,
    TransitionalScheduleBundle.

Why: During the Basel 3.1 transition (PRA PS1/26, effective 1 Jan 2027),
firms must quantify the capital impact of moving from CRR to Basel 3.1
and model the transitional output floor phase-in from 50% (2027) to 72.5%
(2032+). This workbook provides interactive analysis of those impacts,
enabling capital planning and regulatory dialogue.

Usage:
    uv run marimo edit src/rwa_calc/ui/marimo/comparison_app.py
    uv run marimo run src/rwa_calc/ui/marimo/comparison_app.py

Features:
    - Dual-framework comparison (CRR vs Basel 3.1) on the same portfolio
    - Executive summary with headline delta metrics
    - Capital impact waterfall decomposition (4 regulatory drivers)
    - Summary breakdowns by exposure class and approach
    - Transitional floor schedule timeline (2027-2032) with interactive slider
    - Drill-down from portfolio delta to exposure-level drivers
    - Export comparison results to CSV

References:
    - PRA PS1/26 Ch.12: Output floor transitional period
    - CRR Art. 92: Own funds requirements
    - CRR Art. 501/501a: SME/infrastructure supporting factors
"""

import marimo

__generated_with = "0.19.4"
app = marimo.App(width="full", css_file="shared/theme.css", html_head_file="shared/head.html")


@app.cell
def _():
    import io
    import sys
    from datetime import date
    from decimal import Decimal
    from pathlib import Path

    import marimo as mo
    import polars as pl

    project_root = Path(__file__).parent.parent.parent.parent.parent
    if str(project_root) not in sys.path:
        sys.path.insert(0, str(project_root))

    return Decimal, Path, date, io, mo, pl, project_root


@app.cell
def _(mo):
    import sys as _sys
    from pathlib import Path as _P

    _shared = str(_P(__file__).parent / "shared")
    if _shared not in _sys.path:
        _sys.path.insert(0, _shared)
    from sidebar import create_sidebar as _create_sidebar

    _create_sidebar(mo)
    return


@app.cell
def _(mo):
    return mo.md("""
# CRR vs Basel 3.1 Impact Analysis

Run a dual-framework comparison on the same portfolio to quantify the capital impact
of moving from CRR to Basel 3.1. The analysis decomposes the RWA delta into four
regulatory drivers and models the transitional output floor phase-in (2027-2032).
    """)


# =============================================================================
# Data Configuration
# =============================================================================


@app.cell
def _(mo, project_root):
    default_path = str(project_root / "tests" / "fixtures")

    data_path_input = mo.ui.text(
        value=default_path,
        label="Data Path",
        placeholder="Enter path to data directory",
        full_width=True,
    )

    mo.output.replace(
        mo.vstack(
            [
                mo.md("### Data Configuration"),
                data_path_input,
            ]
        )
    )
    return (data_path_input,)


@app.cell
def _(date, mo):
    permission_mode_dropdown = mo.ui.dropdown(
        options={
            "Standardised (All SA)": "standardised",
            "IRB (Model Permissions)": "irb",
        },
        value="IRB (Model Permissions)",
        label="Permission Mode",
    )

    format_dropdown = mo.ui.dropdown(
        options=["parquet", "csv"],
        value="parquet",
        label="Data Format",
    )

    reporting_date_input = mo.ui.date(
        value=date(2027, 6, 30),
        label="Reporting Date",
    )

    mo.output.replace(
        mo.hstack(
            [permission_mode_dropdown, format_dropdown, reporting_date_input],
            justify="start",
            gap=2,
        )
    )
    return (format_dropdown, permission_mode_dropdown, reporting_date_input)


# =============================================================================
# Data Validation & Run
# =============================================================================


@app.cell
def _(Path, data_path_input, format_dropdown, mo):
    from rwa_calc.api import validate_data_path

    path = Path(data_path_input.value) if data_path_input.value else None

    if path and path.exists():
        validation_result = validate_data_path(
            data_path=path,
            data_format=format_dropdown.value,
        )
    else:
        validation_result = None

    if path is None or not data_path_input.value:
        validation_status = mo.callout("Please enter a data path", kind="warn")
    elif not path.exists():
        validation_status = mo.callout(f"Path does not exist: {path}", kind="danger")
    elif validation_result and validation_result.valid:
        validation_status = mo.callout(
            f"Data path valid. Found {validation_result.found_count} required files.",
            kind="success",
        )
    elif validation_result:
        missing = ", ".join(str(f) for f in validation_result.files_missing[:3])
        _more = (
            f" (+{len(validation_result.files_missing) - 3} more)"
            if len(validation_result.files_missing) > 3
            else ""
        )
        validation_status = mo.callout(f"Missing files: {missing}{_more}", kind="danger")
    else:
        validation_status = mo.callout("Unable to validate path", kind="warn")

    mo.output.replace(validation_status)
    return (validation_result,)


@app.cell
def _(mo, validation_result):
    can_run = validation_result is not None and validation_result.valid

    run_button = mo.ui.run_button(
        label="Run Comparison",
        disabled=not can_run,
    )

    mo.output.replace(
        mo.vstack(
            [
                mo.callout(
                    mo.md(
                        "This runs the portfolio through **both** CRR and Basel 3.1 pipelines, "
                        "then computes capital impact attribution and transitional floor schedule. "
                        "Takes roughly 2x a single-framework run."
                    ),
                    kind="info",
                ),
                mo.hstack([run_button], justify="center"),
            ]
        )
    )
    return (run_button,)


# =============================================================================
# Run Comparison
# =============================================================================


@app.cell
def _(
    Decimal,
    Path,
    data_path_input,
    format_dropdown,
    permission_mode_dropdown,
    mo,
    reporting_date_input,
    run_button,
):
    from datetime import date as date_type

    comparison_bundle = None
    impact_bundle = None
    schedule_bundle = None
    run_error = None

    if run_button.value:
        try:
            from rwa_calc.contracts.config import CalculationConfig
            from rwa_calc.domain.enums import PermissionMode
            from rwa_calc.engine.comparison import (
                CapitalImpactAnalyzer,
                DualFrameworkRunner,
                TransitionalScheduleRunner,
            )
            from rwa_calc.engine.loader import CSVLoader, ParquetLoader

            # Create loader and load data once
            data_path = Path(data_path_input.value)
            if format_dropdown.value == "csv":
                loader = CSVLoader(base_path=data_path)
            else:
                loader = ParquetLoader(base_path=data_path)

            raw_data = loader.load()

            mode = PermissionMode(permission_mode_dropdown.value)

            rd = reporting_date_input.value
            if not isinstance(rd, date_type):
                rd = date_type.fromisoformat(str(rd))

            # Create configs for both frameworks
            crr_config = CalculationConfig.crr(
                reporting_date=rd,
                permission_mode=mode,
                eur_gbp_rate=Decimal("0.8732"),
            )
            b31_config = CalculationConfig.basel_3_1(
                reporting_date=rd,
                permission_mode=mode,
            )

            # M3.1: Run dual-framework comparison
            runner = DualFrameworkRunner()
            comparison_bundle = runner.compare(raw_data, crr_config, b31_config)

            # M3.2: Capital impact analysis
            analyzer = CapitalImpactAnalyzer()
            impact_bundle = analyzer.analyze(comparison_bundle)

            # M3.3: Transitional floor schedule (only if IRB is enabled)
            if mode == PermissionMode.IRB:
                schedule_runner = TransitionalScheduleRunner()
                schedule_bundle = schedule_runner.run(raw_data, mode)

        except Exception as e:
            run_error = str(e)

    if run_button.value and run_error:
        mo.output.replace(mo.callout(f"Comparison failed: {run_error}", kind="danger"))
    elif run_button.value and comparison_bundle:
        mo.output.replace(mo.callout("Comparison completed successfully!", kind="success"))

    return comparison_bundle, impact_bundle, run_error, schedule_bundle


# =============================================================================
# Executive Summary
# =============================================================================


@app.cell
def _(comparison_bundle, mo, pl):
    def _sum_column(result, column: str) -> float:
        if result.summary_by_approach is None:
            return 0.0
        df = result.summary_by_approach.collect()
        if column in df.columns and df.height > 0:
            return float(df[column].sum())
        return 0.0

    def _avg_rw(rwa: float, ead: float) -> str:
        return f"{rwa / ead:.2%}" if ead else "N/A"

    def _build_summary_view(crr_agg, b31_agg):
        crr_rwa = _sum_column(crr_agg, "total_rwa")
        b31_rwa = _sum_column(b31_agg, "total_rwa")
        crr_ead = _sum_column(crr_agg, "total_ead")
        b31_ead = _sum_column(b31_agg, "total_ead")
        delta_rwa = b31_rwa - crr_rwa
        delta_pct = (delta_rwa / crr_rwa * 100) if crr_rwa != 0 else 0.0

        def _fmt(val: float) -> str:
            return f"{val:,.0f}"

        return mo.vstack(
            [
                mo.md("## Executive Summary"),
                mo.hstack(
                    [
                        mo.stat(value=_fmt(crr_rwa), label="CRR Total RWA"),
                        mo.stat(value=_fmt(b31_rwa), label="Basel 3.1 Total RWA"),
                        mo.stat(
                            value=f"{_fmt(delta_rwa)} ({delta_pct:+.1f}%)",
                            label="Delta RWA",
                        ),
                    ],
                    justify="space-around",
                ),
                mo.hstack(
                    [
                        mo.stat(value=_fmt(crr_ead), label="CRR Total EAD"),
                        mo.stat(value=_fmt(b31_ead), label="Basel 3.1 Total EAD"),
                        mo.stat(value=_avg_rw(crr_rwa, crr_ead), label="CRR Avg RW"),
                        mo.stat(value=_avg_rw(b31_rwa, b31_ead), label="B31 Avg RW"),
                    ],
                    justify="space-around",
                ),
            ]
        )

    if comparison_bundle is not None:
        mo.output.replace(
            _build_summary_view(comparison_bundle.crr_results, comparison_bundle.b31_results)
        )
    return


# =============================================================================
# Capital Impact Waterfall (M3.2)
# =============================================================================


@app.cell
def _(impact_bundle, mo, pl):
    def _impact_direction(impact: float) -> str:
        if impact > 0:
            return "increase"
        if impact < 0:
            return "decrease"
        return "neutral"

    def _build_waterfall_row(waterfall_df, i: int) -> dict:
        impact = float(waterfall_df["impact_rwa"][i])
        cumulative = float(waterfall_df["cumulative_rwa"][i])
        sign = "+" if impact >= 0 else ""
        return {
            "Step": int(waterfall_df["step"][i]),
            "Driver": waterfall_df["driver"][i],
            "Impact (RWA)": f"{sign}{impact:,.0f}",
            "Cumulative": f"{cumulative:,.0f}",
            "Direction": _impact_direction(impact),
        }

    def _render_waterfall(waterfall_df):
        rows = [_build_waterfall_row(waterfall_df, i) for i in range(waterfall_df.height)]
        waterfall_display = pl.DataFrame(rows)
        total_impact = sum(float(waterfall_df["impact_rwa"][i]) for i in range(waterfall_df.height))
        return mo.vstack(
            [
                mo.md("## Capital Impact Waterfall"),
                mo.md(
                    "The RWA delta is decomposed into four sequential regulatory drivers. "
                    "Each driver's impact is additive — they sum exactly to the total delta."
                ),
                mo.ui.table(waterfall_display, selection=None),
                mo.md(f"**Total RWA impact: {total_impact:+,.0f}**"),
            ]
        )

    if impact_bundle is not None:
        waterfall_df = impact_bundle.portfolio_waterfall.collect()
        if waterfall_df.height > 0:
            mo.output.replace(_render_waterfall(waterfall_df))
    return


# =============================================================================
# Summary by Exposure Class
# =============================================================================


@app.cell
def _(comparison_bundle, mo, pl):
    if comparison_bundle is not None:
        _class_df = comparison_bundle.summary_by_class.collect()

        if _class_df.height > 0:
            # Select and format relevant columns
            _schema = _class_df.columns
            _display_cols = [
                c
                for c in [
                    "exposure_class",
                    "exposure_count",
                    "total_ead_crr",
                    "total_ead_b31",
                    "total_rwa_crr",
                    "total_rwa_b31",
                    "total_delta_rwa",
                    "delta_rwa_pct",
                ]
                if c in _schema
            ]

            if _display_cols:
                _sorted_df = _class_df.select(_display_cols).sort(
                    "total_delta_rwa", descending=True
                )
                mo.output.replace(
                    mo.vstack(
                        [
                            mo.md("## Comparison by Exposure Class"),
                            mo.md(
                                "Positive delta = Basel 3.1 RWA higher than CRR (increased capital)."
                            ),
                            mo.ui.table(_sorted_df, selection=None),
                        ]
                    )
                )
    return


# =============================================================================
# Summary by Approach
# =============================================================================


@app.cell
def _(comparison_bundle, mo, pl):
    if comparison_bundle is not None:
        _approach_df = comparison_bundle.summary_by_approach.collect()

        if _approach_df.height > 0:
            _schema = _approach_df.columns
            _display_cols = [
                c
                for c in [
                    "approach_applied",
                    "exposure_count",
                    "total_ead_crr",
                    "total_ead_b31",
                    "total_rwa_crr",
                    "total_rwa_b31",
                    "total_delta_rwa",
                    "delta_rwa_pct",
                ]
                if c in _schema
            ]

            if _display_cols:
                _sorted_df = _approach_df.select(_display_cols).sort(
                    "total_delta_rwa", descending=True
                )
                mo.output.replace(
                    mo.vstack(
                        [
                            mo.md("## Comparison by Approach"),
                            mo.ui.table(_sorted_df, selection=None),
                        ]
                    )
                )
    return


# =============================================================================
# Capital Impact by Exposure Class (M3.2 attribution)
# =============================================================================


@app.cell
def _(impact_bundle, mo, pl):
    if impact_bundle is not None:
        class_attr_df = impact_bundle.summary_by_class.collect()

        if class_attr_df.height > 0:
            _schema = class_attr_df.columns
            _display_cols = [
                c
                for c in [
                    "exposure_class",
                    "total_delta_rwa",
                    "total_scaling_factor_impact",
                    "total_supporting_factor_impact",
                    "total_output_floor_impact",
                    "total_methodology_impact",
                ]
                if c in _schema
            ]

            if _display_cols:
                _sorted_df = class_attr_df.select(_display_cols).sort(
                    "total_delta_rwa", descending=True
                )
                mo.output.replace(
                    mo.vstack(
                        [
                            mo.md("## Capital Impact Attribution by Exposure Class"),
                            mo.md(
                                "Breakdown of each driver's contribution to the RWA delta "
                                "per exposure class. All four drivers sum to delta_rwa."
                            ),
                            mo.ui.table(_sorted_df, selection=None),
                        ]
                    )
                )
    return


# =============================================================================
# Transitional Floor Schedule (M3.3)
# =============================================================================


@app.cell
def _(mo, pl, schedule_bundle):
    if schedule_bundle is not None:
        timeline_df = schedule_bundle.timeline.collect()

        if timeline_df.height > 0:
            # Format timeline for display
            display_timeline = timeline_df.select(
                [
                    c
                    for c in [
                        "year",
                        "floor_percentage",
                        "total_rwa_pre_floor",
                        "total_rwa_post_floor",
                        "total_floor_impact",
                        "floor_binding_count",
                        "total_irb_exposure_count",
                        "total_ead",
                        "total_sa_rwa",
                    ]
                    if c in timeline_df.columns
                ]
            )

            mo.output.replace(
                mo.vstack(
                    [
                        mo.md("## Transitional Output Floor Schedule (2027-2032)"),
                        mo.md(
                            "PRA PS1/26 phases in the output floor from 50% (2027) to 72.5% "
                            "(2032+). The table shows total RWA pre- and post-floor for each "
                            "transitional year, including floor impact and how many IRB "
                            "exposures become floor-constrained."
                        ),
                        mo.ui.table(display_timeline, selection=None),
                    ]
                )
            )
    return


# =============================================================================
# Transitional Year Drill-Down (slider)
# =============================================================================


@app.cell
def _(mo, schedule_bundle):
    if schedule_bundle is not None and schedule_bundle.yearly_results:
        years = sorted(schedule_bundle.yearly_results.keys())

        year_slider = mo.ui.slider(
            start=min(years),
            stop=max(years),
            step=1,
            value=min(years),
            label="Select Transitional Year",
            show_value=True,
        )

        mo.output.replace(
            mo.vstack(
                [
                    mo.md("### Drill Down by Transitional Year"),
                    mo.md("Use the slider to explore floor impact detail for a specific year."),
                    year_slider,
                ]
            )
        )
    else:
        year_slider = None

    return (year_slider,)


@app.cell
def _(mo, pl, schedule_bundle, year_slider):
    if schedule_bundle is not None and year_slider is not None:
        selected_year = int(year_slider.value)
        year_result = schedule_bundle.yearly_results.get(selected_year)

        if year_result is not None and year_result.summary_by_approach is not None:
            _approach_df = year_result.summary_by_approach.collect()

            output_parts = [
                mo.md(f"#### {selected_year} Summary by Approach"),
                mo.ui.table(_approach_df, selection=None),
            ]

            if year_result.summary_by_class is not None:
                _class_df = year_result.summary_by_class.collect()
                output_parts.append(mo.md(f"#### {selected_year} Summary by Exposure Class"))
                output_parts.append(mo.ui.table(_class_df, selection=None))

            mo.output.replace(mo.vstack(output_parts))
    return


# =============================================================================
# Exposure-Level Drill-Down
# =============================================================================


@app.cell
def _(comparison_bundle, mo, pl):
    if comparison_bundle is not None:
        _deltas_lf = comparison_bundle.exposure_deltas
        _schema = _deltas_lf.collect_schema().names()

        # Get unique classes for filter
        exposure_classes = ["All"]
        if "exposure_class" in _schema:
            classes = _deltas_lf.select("exposure_class").unique().collect().to_series().to_list()
            exposure_classes += sorted(c for c in classes if c is not None)

        approaches = ["All"]
        if "approach_applied" in _schema:
            apps = _deltas_lf.select("approach_applied").unique().collect().to_series().to_list()
            approaches += sorted(a for a in apps if a is not None)

        drill_class_filter = mo.ui.dropdown(
            options=exposure_classes,
            value="All",
            label="Filter Exposure Class",
        )

        drill_approach_filter = mo.ui.dropdown(
            options=approaches,
            value="All",
            label="Filter Approach",
        )

        drill_sort = mo.ui.dropdown(
            options={
                "Largest RWA increase": "delta_rwa_desc",
                "Largest RWA decrease": "delta_rwa_asc",
                "Largest absolute delta": "delta_rwa_abs",
            },
            value="Largest RWA increase",
            label="Sort By",
        )

        mo.output.replace(
            mo.vstack(
                [
                    mo.md("## Exposure-Level Drill-Down"),
                    mo.md(
                        "Explore per-exposure deltas. Positive delta = Basel 3.1 requires "
                        "more capital than CRR for that exposure."
                    ),
                    mo.hstack(
                        [drill_class_filter, drill_approach_filter, drill_sort],
                        justify="start",
                        gap=2,
                    ),
                ]
            )
        )
    else:
        drill_class_filter = None
        drill_approach_filter = None
        drill_sort = None

    return drill_approach_filter, drill_class_filter, drill_sort


@app.cell
def _(comparison_bundle, drill_approach_filter, drill_class_filter, drill_sort, mo, pl):
    _DRILL_DEFAULT_COLS = [
        "exposure_reference",
        "exposure_class",
        "approach_applied",
        "ead_final_crr",
        "ead_final_b31",
        "risk_weight_crr",
        "risk_weight_b31",
        "rwa_final_crr",
        "rwa_final_b31",
        "delta_rwa",
        "delta_risk_weight",
        "delta_rwa_pct",
    ]

    _SORT_MAP = {
        "delta_rwa_desc": ("delta_rwa", True, False),
        "delta_rwa_asc": ("delta_rwa", False, False),
        "delta_rwa_abs": ("delta_rwa", True, True),
    }

    def _apply_drill_filters(lf, schema):
        predicates = []
        if drill_class_filter.value != "All" and "exposure_class" in schema:
            predicates.append(pl.col("exposure_class") == drill_class_filter.value)
        if drill_approach_filter.value != "All" and "approach_applied" in schema:
            predicates.append(pl.col("approach_applied") == drill_approach_filter.value)
        if not predicates:
            return lf
        combined = predicates[0]
        for p in predicates[1:]:
            combined = combined & p
        return lf.filter(combined)

    def _select_display_cols(schema):
        cols = [c for c in _DRILL_DEFAULT_COLS if c in schema]
        if cols:
            return cols
        fallback = [c for c in schema if c != "exposure_reference"][:10]
        if "exposure_reference" in schema:
            return ["exposure_reference", *fallback]
        return fallback

    def _apply_drill_sort(lf, schema):
        sort_val = drill_sort.value if drill_sort else "delta_rwa_desc"
        spec = _SORT_MAP.get(sort_val)
        if spec is None or "delta_rwa" not in schema:
            return lf
        col_name, descending, use_abs = spec
        sort_expr = pl.col(col_name).abs() if use_abs else col_name
        return lf.sort(sort_expr, descending=descending)

    def _extract_stat(stats, name: str) -> float:
        value = stats[name][0]
        return float(value) if value is not None else 0.0

    def _render_drilldown(lf, schema):
        filtered = _apply_drill_filters(lf, schema)
        display_cols = _select_display_cols(schema)
        sorted_lf = _apply_drill_sort(filtered, schema)
        result_df = sorted_lf.select(display_cols).head(200).collect()

        stats = filtered.select(
            [
                pl.len().alias("count"),
                pl.col("delta_rwa").sum().alias("total_delta"),
                pl.col("delta_rwa").mean().alias("avg_delta"),
            ]
        ).collect()

        count = int(stats["count"][0])
        total_delta = _extract_stat(stats, "total_delta")
        avg_delta = _extract_stat(stats, "avg_delta")

        return mo.vstack(
            [
                mo.hstack(
                    [
                        mo.stat(value=f"{count:,}", label="Exposures"),
                        mo.stat(value=f"{total_delta:+,.0f}", label="Total Delta RWA"),
                        mo.stat(value=f"{avg_delta:+,.0f}", label="Avg Delta RWA"),
                    ],
                    justify="space-around",
                ),
                mo.md(f"*Showing first {result_df.height:,} of {count:,} exposures*"),
                mo.ui.table(result_df, selection=None),
            ]
        )

    if comparison_bundle is not None and drill_class_filter is not None:
        _deltas_lf = comparison_bundle.exposure_deltas
        _schema = _deltas_lf.collect_schema().names()
        mo.output.replace(_render_drilldown(_deltas_lf, _schema))
    return


# =============================================================================
# Exposure-Level Attribution (M3.2 drill-down)
# =============================================================================


@app.cell
def _(impact_bundle, mo, pl):
    if impact_bundle is not None:
        _attr_lf = impact_bundle.exposure_attribution
        _schema = _attr_lf.collect_schema().names()

        _display_cols = [
            c
            for c in [
                "exposure_reference",
                "exposure_class",
                "approach_applied",
                "rwa_crr",
                "rwa_b31",
                "delta_rwa",
                "scaling_factor_impact",
                "supporting_factor_impact",
                "output_floor_impact",
                "methodology_impact",
            ]
            if c in _schema
        ]

        if _display_cols:
            # Show top 100 by absolute delta
            if "delta_rwa" in _schema:
                _sorted_lf = _attr_lf.sort(pl.col("delta_rwa").abs(), descending=True)
            else:
                _sorted_lf = _attr_lf

            attr_df = _sorted_lf.select(_display_cols).head(100).collect()

            mo.output.replace(
                mo.vstack(
                    [
                        mo.md("## Exposure-Level Driver Attribution"),
                        mo.md(
                            "Per-exposure breakdown of the four capital impact drivers. "
                            "Sorted by absolute delta — largest impacts first. "
                            "Scaling/supporting factor drivers only apply to IRB exposures."
                        ),
                        mo.ui.table(attr_df, selection=None),
                    ]
                )
            )
    return


# =============================================================================
# Export
# =============================================================================


@app.cell
def _(comparison_bundle, impact_bundle, io, mo, pl, schedule_bundle):
    if comparison_bundle is not None:

        def _make_deltas_csv() -> bytes:
            return comparison_bundle.exposure_deltas.collect().write_csv().encode("utf-8")

        def _make_waterfall_csv() -> bytes:
            if impact_bundle is not None:
                return impact_bundle.portfolio_waterfall.collect().write_csv().encode("utf-8")
            return b""

        def _make_attribution_csv() -> bytes:
            if impact_bundle is not None:
                return impact_bundle.exposure_attribution.collect().write_csv().encode("utf-8")
            return b""

        def _make_timeline_csv() -> bytes:
            if schedule_bundle is not None:
                return schedule_bundle.timeline.collect().write_csv().encode("utf-8")
            return b""

        downloads = [
            mo.download(
                data=_make_deltas_csv,
                filename="comparison_exposure_deltas.csv",
                label="Exposure Deltas CSV",
            ),
        ]

        if impact_bundle is not None:
            downloads.append(
                mo.download(
                    data=_make_waterfall_csv,
                    filename="capital_impact_waterfall.csv",
                    label="Waterfall CSV",
                )
            )
            downloads.append(
                mo.download(
                    data=_make_attribution_csv,
                    filename="exposure_attribution.csv",
                    label="Attribution CSV",
                )
            )

        if schedule_bundle is not None:
            downloads.append(
                mo.download(
                    data=_make_timeline_csv,
                    filename="transitional_timeline.csv",
                    label="Timeline CSV",
                )
            )

        mo.output.replace(
            mo.vstack(
                [
                    mo.md("### Export Comparison Results"),
                    mo.hstack(downloads, gap=2),
                ]
            )
        )
    return


# =============================================================================
# Error Display
# =============================================================================


@app.cell
def _(comparison_bundle, mo):
    if comparison_bundle is not None and comparison_bundle.errors:
        errors = comparison_bundle.errors
        # Show first 10 errors
        error_items = "\n".join([f"- {e}" for e in errors[:10]])
        _more = f"\n\n*({len(errors) - 10} more errors)*" if len(errors) > 10 else ""

        mo.output.replace(
            mo.callout(
                mo.md(f"### Data Quality Issues ({len(errors)})\n\n{error_items}{_more}"),
                kind="warn",
            )
        )
    return


if __name__ == "__main__":
    app.run()
