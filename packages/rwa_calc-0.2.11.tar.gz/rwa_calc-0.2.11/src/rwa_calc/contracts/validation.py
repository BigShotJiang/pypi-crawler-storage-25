"""
Schema validation functions for RWA calculator.

Provides utilities for validating LazyFrame schemas against
expected definitions without materializing data. This enables
early detection of schema mismatches at pipeline boundaries.

Key functions:
- validate_schema: Check LazyFrame schema against expected types
- validate_required_columns: Check for required columns
- validate_bundle_schemas: Validate all frames in a bundle
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import polars as pl

from rwa_calc.contracts.errors import (
    ERROR_EAD_NULL,
    ERROR_INVALID_COLUMN_VALUE,
    ERROR_INVALID_VALUE,
    ERROR_MATURITY_INVALID,
    ERROR_MISSING_FIELD,
    ERROR_RW_ABOVE_CAP,
    ERROR_RW_NEGATIVE,
    ERROR_RWA_NEGATIVE,
    ERROR_TYPE_MISMATCH,
    CalculationError,
    ErrorCategory,
    ErrorSeverity,
)
from rwa_calc.data.column_spec import ColumnSpec

if TYPE_CHECKING:
    from rwa_calc.contracts.bundles import (
        AggregatedResultBundle,
        ClassifiedExposuresBundle,
        CRMAdjustedBundle,
        RawDataBundle,
        ResolvedHierarchyBundle,
    )


def _as_dtype(entry: pl.DataType | ColumnSpec) -> pl.DataType:
    """Unwrap a schema entry to its dtype — accepts either a raw Polars dtype or a ColumnSpec."""
    return entry.dtype if isinstance(entry, ColumnSpec) else entry


def _is_required(entry: pl.DataType | ColumnSpec) -> bool:
    """True if a schema entry represents a required column (raw dtypes are treated as required)."""
    return entry.required if isinstance(entry, ColumnSpec) else True


def validate_schema(
    lf: pl.LazyFrame,
    expected_schema: dict[str, pl.DataType] | dict[str, ColumnSpec],
    context: str = "",
    strict: bool = False,
) -> list[str]:
    """
    Validate LazyFrame schema against expected schema.

    Checks that all expected columns exist with correct types.
    Does NOT materialize the LazyFrame.

    Args:
        lf: LazyFrame to validate
        expected_schema: Dict mapping column names to expected Polars types
        context: Context string for error messages (e.g., "facilities")
        strict: If True, also flag extra columns not in expected schema

    Returns:
        List of validation error messages (empty if valid)

    Example:
        >>> errors = validate_schema(
        ...     facilities_lf,
        ...     FACILITY_SCHEMA,
        ...     context="facilities"
        ... )
        >>> if errors:
        ...     print("\\n".join(errors))
    """
    errors: list[str] = []
    actual_schema = lf.collect_schema()
    context_prefix = f"[{context}] " if context else ""

    # Check for missing columns
    for col_name, entry in expected_schema.items():
        expected_type = _as_dtype(entry)
        if col_name not in actual_schema:
            if not _is_required(entry):
                continue
            errors.append(
                f"{context_prefix}Missing column: '{col_name}' (expected type: {expected_type})"
            )
        else:
            actual_type = actual_schema[col_name]
            if not _types_compatible(actual_type, expected_type):
                errors.append(
                    f"{context_prefix}Type mismatch for '{col_name}': "
                    f"expected {expected_type}, got {actual_type}"
                )

    # Check for unexpected columns (if strict mode)
    if strict:
        extra_columns = set(actual_schema.names()) - set(expected_schema.keys())
        for col_name in extra_columns:
            errors.append(
                f"{context_prefix}Unexpected column: '{col_name}' (type: {actual_schema[col_name]})"
            )

    return errors


def _types_compatible(actual: pl.DataType, expected: pl.DataType) -> bool:
    """
    Check if actual type is compatible with expected type.

    Allows some flexibility for compatible types (e.g., Int32 -> Int64).
    """
    # Exact match
    if actual == expected:
        return True

    # Allow integer type promotions
    int_types = {pl.Int8, pl.Int16, pl.Int32, pl.Int64}
    if actual in int_types and expected in int_types:
        return True

    # Allow float type promotions
    float_types = {pl.Float32, pl.Float64}
    if actual in float_types and expected in float_types:
        return True

    # Allow Utf8/String compatibility
    string_types = {pl.Utf8, pl.String}
    return actual in string_types and expected in string_types


def validate_required_columns(
    lf: pl.LazyFrame,
    required_columns: list[str],
    context: str = "",
) -> list[str]:
    """
    Validate that required columns are present in LazyFrame.

    Does not check types, only presence.

    Args:
        lf: LazyFrame to validate
        required_columns: List of column names that must be present
        context: Context string for error messages

    Returns:
        List of missing column names (empty if all present)
    """
    actual_columns = set(lf.collect_schema().names())
    missing = [col for col in required_columns if col not in actual_columns]

    context_prefix = f"[{context}] " if context else ""
    return [f"{context_prefix}Missing required column: '{col}'" for col in missing]


def validate_schema_to_errors(
    lf: pl.LazyFrame,
    expected_schema: dict[str, pl.DataType] | dict[str, ColumnSpec],
    context: str = "",
    optional_columns: set[str] | None = None,
) -> list[CalculationError]:
    """
    Validate schema and return CalculationError objects.

    Same as validate_schema but returns structured errors.

    Args:
        lf: LazyFrame to validate
        expected_schema: Dict mapping column names to expected Polars types
            or to ColumnSpec entries. Raw dtypes are treated as required.
        context: Context string for error messages
        optional_columns: Extra column names that may be absent without error
            (merged with any ``required=False`` markers on ColumnSpec entries).

    Returns:
        List of CalculationError objects for any schema issues
    """
    errors: list[CalculationError] = []
    actual_schema = lf.collect_schema()

    for col_name, entry in expected_schema.items():
        expected_type = _as_dtype(entry)
        if col_name not in actual_schema:
            if optional_columns and col_name in optional_columns:
                continue
            if not _is_required(entry):
                continue
            errors.append(
                CalculationError(
                    code=ERROR_MISSING_FIELD,
                    message=f"Missing column '{col_name}' in {context}",
                    severity=ErrorSeverity.ERROR,
                    category=ErrorCategory.SCHEMA_VALIDATION,
                    field_name=col_name,
                    expected_value=str(expected_type),
                )
            )
        else:
            actual_type = actual_schema[col_name]
            if not _types_compatible(actual_type, expected_type):
                errors.append(
                    CalculationError(
                        code=ERROR_TYPE_MISMATCH,
                        message=f"Type mismatch for '{col_name}' in {context}",
                        severity=ErrorSeverity.ERROR,
                        category=ErrorCategory.SCHEMA_VALIDATION,
                        field_name=col_name,
                        expected_value=str(expected_type),
                        actual_value=str(actual_type),
                    )
                )

    return errors


def validate_raw_data_bundle(
    bundle: RawDataBundle,
    schemas: dict[str, dict[str, pl.DataType] | dict[str, ColumnSpec]],
) -> list[CalculationError]:
    """
    Validate all LazyFrames in a RawDataBundle against expected schemas.

    Args:
        bundle: RawDataBundle to validate
        schemas: Dict mapping bundle attribute names to expected schemas

    Returns:
        List of CalculationError objects for any schema issues
    """
    all_errors: list[CalculationError] = []

    frame_mapping = {
        "facilities": bundle.facilities,
        "loans": bundle.loans,
        "contingents": bundle.contingents,
        "counterparties": bundle.counterparties,
        "collateral": bundle.collateral,
        "guarantees": bundle.guarantees,
        "provisions": bundle.provisions,
        "ratings": bundle.ratings,
        "facility_mappings": bundle.facility_mappings,
        "org_mappings": bundle.org_mappings,
        "lending_mappings": bundle.lending_mappings,
        "model_permissions": bundle.model_permissions,
    }

    # Optional-column semantics now live on ColumnSpec entries (required=False);
    # no separate optional_columns_registry is needed.
    for name, lf in frame_mapping.items():
        if name in schemas and lf is not None:
            errors = validate_schema_to_errors(lf, schemas[name], context=name)
            all_errors.extend(errors)

    return all_errors


def validate_resolved_hierarchy_bundle(
    bundle: ResolvedHierarchyBundle,
    expected_columns: list[str],
) -> list[CalculationError]:
    """
    Validate ResolvedHierarchyBundle has expected hierarchy columns.

    Args:
        bundle: ResolvedHierarchyBundle to validate
        expected_columns: List of column names expected in exposures frame

    Returns:
        List of CalculationError objects for any issues
    """
    errors: list[CalculationError] = []

    # Check exposures frame has hierarchy columns
    missing = validate_required_columns(
        bundle.exposures,
        expected_columns,
        context="resolved_exposures",
    )
    for msg in missing:
        errors.append(
            CalculationError(
                code=ERROR_MISSING_FIELD,
                message=msg,
                severity=ErrorSeverity.ERROR,
                category=ErrorCategory.SCHEMA_VALIDATION,
            )
        )

    return errors


def validate_classified_bundle(
    bundle: ClassifiedExposuresBundle,
    expected_columns: list[str],
) -> list[CalculationError]:
    """
    Validate ClassifiedExposuresBundle has expected classification columns.

    Args:
        bundle: ClassifiedExposuresBundle to validate
        expected_columns: List of column names expected in classified frames

    Returns:
        List of CalculationError objects for any issues
    """
    errors: list[CalculationError] = []

    for frame_name, lf in [
        ("all_exposures", bundle.all_exposures),
        ("sa_exposures", bundle.sa_exposures),
        ("irb_exposures", bundle.irb_exposures),
    ]:
        missing = validate_required_columns(lf, expected_columns, context=frame_name)
        for msg in missing:
            errors.append(
                CalculationError(
                    code=ERROR_MISSING_FIELD,
                    message=msg,
                    severity=ErrorSeverity.ERROR,
                    category=ErrorCategory.SCHEMA_VALIDATION,
                )
            )

    return errors


def validate_crm_adjusted_bundle(
    bundle: CRMAdjustedBundle,
    expected_columns: list[str],
) -> list[CalculationError]:
    """
    Validate CRMAdjustedBundle has expected CRM-related columns.

    Args:
        bundle: CRMAdjustedBundle to validate
        expected_columns: List of column names expected

    Returns:
        List of CalculationError objects for any issues
    """
    errors: list[CalculationError] = []

    for frame_name, lf in [
        ("exposures", bundle.exposures),
        ("sa_exposures", bundle.sa_exposures),
        ("irb_exposures", bundle.irb_exposures),
    ]:
        missing = validate_required_columns(lf, expected_columns, context=frame_name)
        for msg in missing:
            errors.append(
                CalculationError(
                    code=ERROR_MISSING_FIELD,
                    message=msg,
                    severity=ErrorSeverity.ERROR,
                    category=ErrorCategory.SCHEMA_VALIDATION,
                )
            )

    return errors


# =============================================================================
# BUSINESS RULE VALIDATORS
# =============================================================================


def validate_non_negative_amounts(
    lf: pl.LazyFrame,
    amount_columns: list[str],
    context: str = "",
) -> pl.LazyFrame:
    """
    Add validation expressions for non-negative amount columns.

    Returns a LazyFrame with validation flag columns added.
    Does NOT collect/materialize.

    Args:
        lf: LazyFrame to validate
        amount_columns: List of columns that should be non-negative
        context: Context for naming validation columns

    Returns:
        LazyFrame with _valid_{col} columns added
    """
    exprs = []
    schema_names = lf.collect_schema().names()
    for col in amount_columns:
        if col in schema_names:
            valid_col = f"_valid_{col}"
            exprs.append((pl.col(col) >= 0).alias(valid_col))

    if exprs:
        return lf.with_columns(exprs)
    return lf


def validate_pd_range(
    lf: pl.LazyFrame,
    pd_column: str = "pd",
    min_pd: float = 0.0,
    max_pd: float = 1.0,
) -> pl.LazyFrame:
    """
    Add validation expression for PD range [0, 1].

    Args:
        lf: LazyFrame to validate
        pd_column: Name of PD column
        min_pd: Minimum valid PD (default 0)
        max_pd: Maximum valid PD (default 1)

    Returns:
        LazyFrame with _valid_pd column added
    """
    if pd_column in lf.collect_schema().names():
        return lf.with_columns(
            ((pl.col(pd_column) >= min_pd) & (pl.col(pd_column) <= max_pd)).alias("_valid_pd")
        )
    return lf


def validate_lgd_range(
    lf: pl.LazyFrame,
    lgd_column: str = "lgd",
    min_lgd: float = 0.0,
    max_lgd: float = 1.25,  # Can exceed 1.0 in some cases
) -> pl.LazyFrame:
    """
    Add validation expression for LGD range.

    Args:
        lf: LazyFrame to validate
        lgd_column: Name of LGD column
        min_lgd: Minimum valid LGD (default 0)
        max_lgd: Maximum valid LGD (default 1.25)

    Returns:
        LazyFrame with _valid_lgd column added
    """
    if lgd_column in lf.collect_schema().names():
        return lf.with_columns(
            ((pl.col(lgd_column) >= min_lgd) & (pl.col(lgd_column) <= max_lgd)).alias("_valid_lgd")
        )
    return lf


# =============================================================================
# RISK TYPE AND CCF VALIDATORS
# =============================================================================

# Valid risk type codes (short form)
VALID_RISK_TYPE_CODES = {"fr", "frc", "mr", "oc", "mlr", "lr"}

# Valid risk type full values
VALID_RISK_TYPES = {
    "full_risk",
    "full_risk_commitment",
    "medium_risk",
    "other_commit",
    "medium_low_risk",
    "low_risk",
}

# Mapping from codes to full values
RISK_TYPE_CODE_TO_VALUE = {
    "fr": "full_risk",
    "frc": "full_risk_commitment",
    "mr": "medium_risk",
    "oc": "other_commit",
    "mlr": "medium_low_risk",
    "lr": "low_risk",
}


def validate_risk_type(
    lf: pl.LazyFrame,
    column: str = "risk_type",
) -> pl.LazyFrame:
    """
    Add validation expression for risk_type values.

    Validates that risk_type is one of:
    - Codes: FR, MR, OC, MLR, LR (case insensitive)
    - Full values: full_risk, medium_risk, other_commit, medium_low_risk, low_risk

    Args:
        lf: LazyFrame to validate
        column: Name of risk_type column

    Returns:
        LazyFrame with _valid_risk_type column added
    """
    if column not in lf.collect_schema().names():
        return lf

    # Create combined set of valid values (both codes and full values)
    all_valid = VALID_RISK_TYPE_CODES | VALID_RISK_TYPES

    return lf.with_columns(
        pl.col(column).str.to_lowercase().is_in(all_valid).alias("_valid_risk_type")
    )


def validate_ccf_modelled(
    lf: pl.LazyFrame,
    column: str = "ccf_modelled",
    min_ccf: float = 0.0,
    max_ccf: float = 1.5,
) -> pl.LazyFrame:
    """
    Add validation expression for ccf_modelled range.

    Validates that ccf_modelled is in range [0.0, 1.5] when present.
    Null values are considered valid (the field is optional).

    Note: Retail IRB CCFs can exceed 100% due to additional drawdown
    behaviour (borrowers may draw more than committed amounts during
    stress). A cap of 150% is applied as a reasonable upper bound.

    Args:
        lf: LazyFrame to validate
        column: Name of ccf_modelled column
        min_ccf: Minimum valid CCF (default 0.0)
        max_ccf: Maximum valid CCF (default 1.5, allowing for Retail IRB)

    Returns:
        LazyFrame with _valid_ccf_modelled column added
    """
    if column not in lf.collect_schema().names():
        return lf

    return lf.with_columns(
        pl.when(pl.col(column).is_null())
        .then(pl.lit(True))  # Null is valid (optional field)
        .otherwise((pl.col(column) >= min_ccf) & (pl.col(column) <= max_ccf))
        .alias("_valid_ccf_modelled")
    )


def normalize_risk_type(
    lf: pl.LazyFrame,
    column: str = "risk_type",
) -> pl.LazyFrame:
    """
    Normalize risk_type codes to full values.

    Converts short codes (FR, MR, MLR, LR) to full values
    (full_risk, medium_risk, medium_low_risk, low_risk).
    Values already in full form are preserved.

    Args:
        lf: LazyFrame with risk_type column
        column: Name of risk_type column

    Returns:
        LazyFrame with normalized risk_type values
    """
    if column not in lf.collect_schema().names():
        return lf

    # Normalize to lowercase first, then map codes to full values
    return lf.with_columns(
        pl.col(column).str.to_lowercase().replace(RISK_TYPE_CODE_TO_VALUE).alias(column)
    )


# =============================================================================
# COLUMN VALUE VALIDATORS
# =============================================================================


def validate_column_values(
    lf: pl.LazyFrame,
    column: str,
    valid_values: set[str],
    context: str = "",
) -> list[CalculationError]:
    """
    Validate that all non-null values in a column are in the valid set.

    Case-insensitive comparison. Null values are skipped (treated as
    missing data, not invalid values).

    Args:
        lf: LazyFrame to validate
        column: Column name to check
        valid_values: Set of allowed lowercase string values
        context: Context string for error messages (e.g. table name)

    Returns:
        List of CalculationError objects for invalid values found
    """
    schema = lf.collect_schema()
    if column not in schema.names():
        return []

    # Find distinct invalid values with counts
    valid_lower = {v.lower() for v in valid_values}
    invalid_df = (
        lf.filter(pl.col(column).is_not_null())
        .filter(~pl.col(column).str.to_lowercase().is_in(valid_lower))
        .group_by(column)
        .len()
        .collect()
    )

    if invalid_df.height == 0:
        return []

    errors: list[CalculationError] = []
    for row in invalid_df.iter_rows(named=True):
        bad_value = row[column]
        count = row["len"]
        sorted_valid = sorted(valid_values)
        errors.append(
            CalculationError(
                code=ERROR_INVALID_COLUMN_VALUE,
                message=(
                    f"[{context}] Invalid value '{bad_value}' for column '{column}' "
                    f"({count} row(s)). "
                    f"Valid values: {sorted_valid}"
                ),
                severity=ErrorSeverity.WARNING,
                category=ErrorCategory.DATA_QUALITY,
                field_name=column,
                expected_value=", ".join(sorted_valid),
                actual_value=str(bad_value),
            )
        )

    return errors


def validate_bundle_values(
    bundle: RawDataBundle,
    constraints: dict[str, dict[str, set[str]]] | None = None,
) -> list[CalculationError]:
    """
    Validate all categorical column values in a RawDataBundle.

    Iterates over all tables in the bundle and checks column values
    against the constraints registry. Batches all column checks per table
    into a single .collect() call for performance.

    Args:
        bundle: RawDataBundle to validate
        constraints: Override constraints dict; defaults to COLUMN_VALUE_CONSTRAINTS

    Returns:
        List of CalculationError objects for any invalid values found
    """
    if constraints is None:
        from rwa_calc.data.schemas import COLUMN_VALUE_CONSTRAINTS

        constraints = COLUMN_VALUE_CONSTRAINTS

    frame_mapping: dict[str, pl.LazyFrame | None] = {
        "facilities": bundle.facilities,
        "loans": bundle.loans,
        "contingents": bundle.contingents,
        "counterparties": bundle.counterparties,
        "collateral": bundle.collateral,
        "guarantees": bundle.guarantees,
        "provisions": bundle.provisions,
        "ratings": bundle.ratings,
        "specialised_lending": bundle.specialised_lending,
        "equity_exposures": bundle.equity_exposures,
        "facility_mappings": bundle.facility_mappings,
        "model_permissions": bundle.model_permissions,
    }

    all_errors: list[CalculationError] = []

    for table_name, lf in frame_mapping.items():
        if lf is None:
            continue
        table_constraints = constraints.get(table_name, {})
        if table_constraints:
            errors = _validate_table_columns_batched(lf, table_constraints, table_name)
            all_errors.extend(errors)

        # Art. 162(3) override is restricted to exposure tables — the 1-day to
        # 5-year range mirrors the regulatory cap; out-of-range values are clipped
        # downstream but flagged here so firms see the mismatch.
        if table_name in {"facilities", "loans", "contingents"}:
            all_errors.extend(_validate_effective_maturity_range(lf, table_name))

        # PRA PS1/26 Art. 120(2B) / Art. 122(3): short-term rating rows must
        # carry a scope (which exposure they attach to). Flag rows that violate
        # the is_short_term ↔ scope_type/scope_id contract.
        if table_name == "ratings":
            all_errors.extend(_validate_short_term_rating_scope(lf))

    return all_errors


def _validate_effective_maturity_range(
    lf: pl.LazyFrame,
    context: str,
) -> list[CalculationError]:
    """Flag effective_maturity values outside (0, 5.0] for an exposure table."""
    schema_names = lf.collect_schema().names()
    if "effective_maturity" not in schema_names:
        return []

    bad = (
        lf.filter(pl.col("effective_maturity").is_not_null())
        .filter((pl.col("effective_maturity") <= 0.0) | (pl.col("effective_maturity") > 5.0))
        .select(
            pl.len().alias("n"),
            pl.col("effective_maturity").min().alias("min_val"),
            pl.col("effective_maturity").max().alias("max_val"),
        )
        .collect()
    )
    if bad.height == 0 or bad["n"][0] == 0:
        return []

    row = bad.row(0, named=True)
    return [
        CalculationError(
            code=ERROR_MATURITY_INVALID,
            message=(
                f"[{context}] effective_maturity has {row['n']} value(s) outside the "
                f"regulatory range (0, 5.0] years (observed min={row['min_val']}, "
                f"max={row['max_val']}). Values will be clipped to [1/365, 5.0]."
            ),
            severity=ErrorSeverity.WARNING,
            category=ErrorCategory.DATA_QUALITY,
            field_name="effective_maturity",
            expected_value="(0, 5.0]",
        )
    ]


def _validate_short_term_rating_scope(lf: pl.LazyFrame) -> list[CalculationError]:
    """Flag short-term rating rows that violate the scope contract.

    Three violations are detected and reported via ``DQ002``:

    - **Missing scope**: ``is_short_term=True`` with null ``scope_type`` or
      null ``scope_id``. Short-term rating rows must identify the exposure they
      attach to.
    - **Stray scope**: ``is_short_term=False`` (or null) with a non-null
      ``scope_type``/``scope_id``. Scope columns are only meaningful for
      short-term rows; populated values on a long-term row indicate a
      data-entry error.

    ``scope_type`` value-set validation (must be one of
    ``VALID_RATING_SCOPE_TYPES``) is handled by the generic categorical-value
    pass via ``COLUMN_VALUE_CONSTRAINTS``.
    """
    schema_names = lf.collect_schema().names()
    if "is_short_term" not in schema_names:
        return []
    if "scope_type" not in schema_names or "scope_id" not in schema_names:
        return []

    is_st = pl.col("is_short_term").fill_null(False)
    scope_t = pl.col("scope_type")
    scope_id = pl.col("scope_id")

    bad = (
        lf.select(
            [
                (is_st & (scope_t.is_null() | scope_id.is_null())).sum().alias("missing"),
                (~is_st & (scope_t.is_not_null() | scope_id.is_not_null())).sum().alias("stray"),
            ]
        )
        .collect()
        .row(0, named=True)
    )

    errors: list[CalculationError] = []
    if bad["missing"]:
        errors.append(
            CalculationError(
                code=ERROR_INVALID_VALUE,
                message=(
                    f"[ratings] {bad['missing']} row(s) have is_short_term=True "
                    "but null scope_type or scope_id. Short-term rating rows must "
                    "identify the exposure they attach to (PRA PS1/26 Art. 120(2B))."
                ),
                severity=ErrorSeverity.ERROR,
                category=ErrorCategory.DATA_QUALITY,
                field_name="scope_type",
                regulatory_reference="PRA PS1/26 Art. 120(2B)",
            )
        )
    if bad["stray"]:
        errors.append(
            CalculationError(
                code=ERROR_INVALID_VALUE,
                message=(
                    f"[ratings] {bad['stray']} row(s) have is_short_term=False "
                    "but populated scope_type/scope_id. Scope columns apply only "
                    "to short-term rating rows."
                ),
                severity=ErrorSeverity.WARNING,
                category=ErrorCategory.DATA_QUALITY,
                field_name="scope_type",
            )
        )
    return errors


def _validate_table_columns_batched(
    lf: pl.LazyFrame,
    table_constraints: dict[str, set[str]],
    context: str,
) -> list[CalculationError]:
    """
    Validate multiple columns in a single table with one .collect() call.

    Builds a single LazyFrame query that checks all constrained columns at once,
    reducing N separate .collect() calls to 1.

    Args:
        lf: LazyFrame for the table
        table_constraints: Mapping of column name -> valid values
        context: Table name for error messages

    Returns:
        List of CalculationError objects for invalid values found
    """
    schema = lf.collect_schema()
    columns_to_check = [col for col in table_constraints if col in schema.names()]

    if not columns_to_check:
        return []

    # Build a single query that finds invalid values for all columns at once.
    # For each column, select rows where the value is not in the valid set,
    # then union them into a single frame with (column_name, bad_value, count).
    invalid_queries: list[pl.LazyFrame] = []
    for col_name in columns_to_check:
        valid_values = table_constraints[col_name]
        valid_lower = {v.lower() for v in valid_values}
        q = (
            lf.filter(pl.col(col_name).is_not_null())
            .filter(~pl.col(col_name).str.to_lowercase().is_in(valid_lower))
            .group_by(pl.col(col_name).alias("bad_value"))
            .len()
            .with_columns(pl.lit(col_name).alias("column_name"))
        )
        invalid_queries.append(q)

    if not invalid_queries:
        return []

    # Single collect for all column checks in this table
    combined = pl.concat(invalid_queries, how="diagonal_relaxed")
    try:
        invalid_df = combined.collect()
    except Exception:
        # Fallback to per-column validation if batching fails
        errors: list[CalculationError] = []
        for col_name in columns_to_check:
            errors.extend(
                validate_column_values(lf, col_name, table_constraints[col_name], context=context)
            )
        return errors

    if invalid_df.height == 0:
        return []

    errors = []
    for row in invalid_df.iter_rows(named=True):
        col_name = row["column_name"]
        bad_value = row["bad_value"]
        count = row["len"]
        sorted_valid = sorted(table_constraints[col_name])
        errors.append(
            CalculationError(
                code=ERROR_INVALID_COLUMN_VALUE,
                message=(
                    f"[{context}] Invalid value '{bad_value}' for column '{col_name}' "
                    f"({count} row(s)). "
                    f"Valid values: {sorted_valid}"
                ),
                severity=ErrorSeverity.WARNING,
                category=ErrorCategory.DATA_QUALITY,
                field_name=col_name,
                expected_value=", ".join(sorted_valid),
                actual_value=str(bad_value),
            )
        )

    return errors


# =============================================================================
# AGGREGATED OUTPUT BOUNDS VALIDATOR
# =============================================================================


# Per-bound configuration: (column, predicate-builder, error code, category, ref, message)
_AGG_BOUND_SPECS: tuple[
    tuple[str, str, ErrorCategory, str | None, str],
    ...,
] = (
    (
        "risk_weight",
        ERROR_RW_ABOVE_CAP,
        ErrorCategory.BUSINESS_RULE,
        "CRR Art. 92(3); CRE31.5 (RW <= 1250%)",
        "risk_weight exceeds 1250% cap (12.5)",
    ),
    (
        "risk_weight",
        ERROR_RW_NEGATIVE,
        ErrorCategory.BUSINESS_RULE,
        "CRR Art. 153; CRE31",
        "risk_weight is negative",
    ),
    (
        "rwa_final",
        ERROR_RWA_NEGATIVE,
        ErrorCategory.BUSINESS_RULE,
        "CRR Art. 92(3)",
        "rwa_final is negative beyond float64 round-off (< -1e-9)",
    ),
    (
        "ead_final",
        ERROR_EAD_NULL,
        ErrorCategory.DATA_QUALITY,
        None,
        "ead_final is null",
    ),
)


def validate_aggregated_bundle(
    bundle: AggregatedResultBundle,
    sample_cap: int = 5,
) -> list[CalculationError]:
    """
    Validate regulatory output bounds on AggregatedResultBundle.results.

    Checks four bound violations per the architect's spec:

    - OUT001: ``risk_weight > 12.5`` (1250% cap; CRR Art. 92(3); CRE31.5)
    - OUT002: ``risk_weight < 0``    (CRR Art. 153; CRE31)
    - OUT003: ``rwa_final < -1e-9``  (float64 round-off tolerance; CRR Art. 92(3))
    - OUT004: ``ead_final`` is null   (data quality)

    For each bound, up to ``sample_cap`` per-row errors are emitted with
    ``exposure_reference`` populated. If the violation count exceeds the
    cap, a single summary error is appended noting the omitted-row count.

    Missing target columns are silently skipped; an empty results frame
    returns ``[]``. Never raises — errors are accumulated, not thrown.

    Args:
        bundle: AggregatedResultBundle to inspect.
        sample_cap: Maximum per-row errors emitted per bound (default 5).

    Returns:
        List of CalculationError objects (empty if all bounds satisfied).
    """
    results_lf = bundle.results
    schema_names = set(results_lf.collect_schema().names())

    errors: list[CalculationError] = []
    for column, code, category, regulatory_reference, message in _AGG_BOUND_SPECS:
        if column not in schema_names:
            continue
        if "exposure_reference" not in schema_names:
            continue

        predicate = _bound_predicate(column, code)
        offending = (
            results_lf.filter(predicate)
            .select("exposure_reference", pl.col(column).alias("_bound_value"))
            .collect()
        )
        total = offending.height
        if total == 0:
            continue

        sampled = offending.head(sample_cap)
        for row in sampled.iter_rows(named=True):
            errors.append(
                CalculationError(
                    code=code,
                    message=f"{message} (value={row['_bound_value']})",
                    severity=ErrorSeverity.ERROR,
                    category=category,
                    exposure_reference=row["exposure_reference"],
                    regulatory_reference=regulatory_reference,
                    field_name=column,
                    actual_value=str(row["_bound_value"]),
                )
            )

        if total > sample_cap:
            omitted = total - sample_cap
            errors.append(
                CalculationError(
                    code=code,
                    message=(
                        f"{message}: {omitted} additional row(s) omitted beyond "
                        f"sample_cap={sample_cap}"
                    ),
                    severity=ErrorSeverity.ERROR,
                    category=category,
                    regulatory_reference=regulatory_reference,
                    field_name=column,
                )
            )

    return errors


def _bound_predicate(column: str, code: str) -> pl.Expr:
    """Build the Polars predicate that flags rows violating a given bound."""
    if code == ERROR_RW_ABOVE_CAP:
        return pl.col(column).is_not_null() & (pl.col(column) > 12.5)
    if code == ERROR_RW_NEGATIVE:
        return pl.col(column).is_not_null() & (pl.col(column) < 0.0)
    if code == ERROR_RWA_NEGATIVE:
        return pl.col(column).is_not_null() & (pl.col(column) < -1e-9)
    if code == ERROR_EAD_NULL:
        return pl.col(column).is_null()
    raise ValueError(f"Unknown bound code: {code}")
