# Regulatory References

This page provides links to key regulatory documents and resources.

!!! info "From article to implementation"
    For any CRR article or PS1/26 paragraph listed below, see the [Citation Coverage Matrix](../development/citation-matrix.md) to jump straight to the implementing function(s) in `src/rwa_calc/` — each article has a click-to-expand source snippet pulled live from the codebase. The mapping is auto-generated from `@cites(...)` decorators (see [Citation Tracking](../development/citation-tracking.md) for the conventions) and stays in sync with every code change.

## UK Regulations

### PRA Rulebook

| Document | Description | Link |
|----------|-------------|------|
| CRR Firms | PRA rules for CRR-regulated firms | [prarulebook.co.uk](https://www.prarulebook.co.uk/pra-rules/crr-firms) |

### UK CRR

| Document | Description | Link |
|----------|-------------|------|
| EU 575/2013 (Onshored) | Capital Requirements Regulation | [legislation.gov.uk](https://www.legislation.gov.uk/eur/2013/575/contents) |

### Basel 3.1 Implementation

| Document | Description | Link |
|----------|-------------|------|
| PRA PS1/26 | Basel 3.1 Final Rules | [bankofengland.co.uk](https://www.bankofengland.co.uk/prudential-regulation/publication/2026/january/implementation-of-the-basel-3-1-final-rules-policy-statement) |
| PRA CP16/22 (superseded) | Basel 3.1 Consultation Paper | [bankofengland.co.uk](https://www.bankofengland.co.uk/prudential-regulation/publication/2026/january/implementation-of-the-basel-3-1-final-rules-policy-statement) |

## Basel Committee Standards

### Basel Framework

| Standard | Description | Link |
|----------|-------------|------|
| CRE | Credit Risk Standards | [bis.org/CRE](https://www.bis.org/basel_framework/standard/CRE.htm) |
| CRE20 | Standardised Approach | [bis.org/CRE20](https://www.bis.org/basel_framework/chapter/CRE/20.htm) |
| CRE21 | Standardised - Risk Weights | [bis.org/CRE21](https://www.bis.org/basel_framework/chapter/CRE/21.htm) |
| CRE22 | Credit Risk Mitigation | [bis.org/CRE22](https://www.bis.org/basel_framework/chapter/CRE/22.htm) |
| CRE30 | IRB Overview | [bis.org/CRE30](https://www.bis.org/basel_framework/chapter/CRE/30.htm) |
| CRE31 | IRB Risk Weights | [bis.org/CRE31](https://www.bis.org/basel_framework/chapter/CRE/31.htm) |
| CRE32 | IRB Risk Components | [bis.org/CRE32](https://www.bis.org/basel_framework/chapter/CRE/32.htm) |
| CRE33 | Specialised Lending | [bis.org/CRE33](https://www.bis.org/basel_framework/chapter/CRE/33.htm) |
| CRE99 | Output Floor | [bis.org/CRE99](https://www.bis.org/basel_framework/chapter/CRE/99.htm) |

## Key CRR Articles

### Exposure Classes

| Article | Topic |
|---------|-------|
| Art. 112 | Exposure class definitions |
| Art. 114 | Sovereign exposures |
| Art. 115 | Regional governments |
| Art. 117 | MDB exposures |
| Art. 119-121 | Institution exposures |
| Art. 122 | Corporate exposures |
| Art. 123 | Retail exposures |
| Art. 124-125 | Real estate exposures (Basel 3.1 expands to Art. 124–124L: framework scope, Art. 124A qualifying criteria, Art. 124B underwriting-standards, Art. 124C LTV, Art. 124D valuation, Art. 124E material dependency, Art. 124F–124I risk-weight tables, Art. 124J other RE, Art. 124K ADC, Art. 124L counterparty RW) |
| Art. 127 | Defaulted exposures |
| Art. 128 | High risk items |
| Art. 129 | Covered bonds |
| Art. 133 | Equity exposures |

### Risk Weights and CCF

| Article | Topic |
|---------|-------|
| Art. 111 | Credit conversion factors |
| Art. 113-134 | Risk weight assignment |

### IRB Approach

| Article | Topic |
|---------|-------|
| Art. 142-150 | IRB overview |
| Art. 153 | K formula and risk weights |
| Art. 154 | Retail IRB |
| Art. 161 | Supervisory LGD |
| Art. 162 | Maturity |
| Art. 178 | Definition of default |
| Art. 179-184 | Risk parameter estimation standards (PD, LGD, CCF/EAD, downturn, LGD-AM, purchased receivables) — see [IRB Approach Specification — Art. 179-184](../specifications/basel31/irb-approach.md#risk-parameter-estimation-standards-art-179184) |
| Art. 181A-C | Economic downturn — nature, indicator set, 20-year time-span — see [IRB Approach Specification — Art. 181A-C](../specifications/basel31/irb-approach.md#art-181ac--economic-downturn-specification) |
| Art. 185 | Validation of internal estimates |

### Credit Risk Mitigation

| Article | Topic |
|---------|-------|
| Art. 192-194 | CRM overview |
| Art. 197-200 | Financial collateral |
| Art. 213-216 | Guarantees |
| Art. 224-227 | Haircuts |
| Art. 238-239 | Maturity mismatch |

### Supporting Factors

| Article | Topic |
|---------|-------|
| Art. 501 | SME supporting factor |
| Art. 501a | Infrastructure factor |

## Reference Documents (Project)

The `ref_docs/` directory contains PDF copies of key regulatory documents:

| File | Document |
|------|----------|
| `ps126app1.pdf` | PRA PS1/26 Appendix 1 (Regulations) |
| `ps126app17.pdf` | PRA PS1/26 Appendix 17 (Template Guidance) |
| `bcbs_cre.pdf` | BCBS CRE Standards |
| `uk_crr.pdf` | UK CRR Extract |

## Rating Agency Mappings

### CQS to External Ratings

| CQS | S&P | Moody's | Fitch |
|-----|-----|---------|-------|
| 1 | AAA to AA- | Aaa to Aa3 | AAA to AA- |
| 2 | A+ to A- | A1 to A3 | A+ to A- |
| 3 | BBB+ to BBB- | Baa1 to Baa3 | BBB+ to BBB- |
| 4 | BB+ to BB- | Ba1 to Ba3 | BB+ to BB- |
| 5 | B+ to B- | B1 to B3 | B+ to B- |
| 6 | CCC+ and below | Caa1 and below | CCC+ and below |

## Additional Resources

### Industry Guidance

| Source | Description |
|--------|-------------|
| UK Finance | Industry body guidance |
| ISDA | Derivatives documentation |
| LMA | Loan market standards |

### Academic References

| Topic | Key Papers |
|-------|------------|
| IRB Formula | Vasicek (1987), Gordy (2003) |
| Correlation | Lopez (2004) |
| LGD Estimation | Schuermann (2004) |

## Useful Links

- [PRA Publications](https://www.bankofengland.co.uk/prudential-regulation/publication)
- [Basel Committee](https://www.bis.org/bcbs/)
- [UK Legislation](https://www.legislation.gov.uk/)
- [EBA Publications](https://www.eba.europa.eu/publications-and-media)
