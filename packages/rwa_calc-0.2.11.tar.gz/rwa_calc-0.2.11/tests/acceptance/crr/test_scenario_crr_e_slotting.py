"""
CRR Group E: Specialised Lending Slotting Acceptance Tests.

These tests validate that the production RWA calculator correctly applies
the slotting approach for specialised lending exposures.

Regulatory References:
- CRR Art. 153(5): Slotting approach for specialised lending
- CRR Art. 147(8): Specialised lending sub-classes

UK CRR Slotting Note (P1.177 / CRR Art. 153(5)):
    UK CRR retains only ONE slotting table (Table 1). The EU CRR Table 2
    HVCRE uplift (Strong=95%, Good=120%, Satisfactory=140%) was not onshored.
    All SL exposures — including those flagged is_hvcre=True — use Table 1.
    Basel 3.1 (PRA PS1/26) does preserve the HVCRE differential.
"""

from typing import Any

import polars as pl
import pytest
from tests.acceptance.crr.conftest import (
    assert_risk_weight_match,
    assert_rwa_within_tolerance,
    get_result_for_exposure,
)

# Mapping of scenario IDs to exposure references
SCENARIO_EXPOSURE_MAP = {
    "CRR-E1": "LOAN_SL_PF_001",
    "CRR-E2": "LOAN_SL_PF_002",
    "CRR-E3": "LOAN_SL_IPRE_001",
    "CRR-E4": "LOAN_SL_HVCRE_001",
    "CRR-E5": "LOAN_SL_PF_003",
    "CRR-E6": "LOAN_SL_PF_004",
    "CRR-E7": "LOAN_SL_HVCRE_002",
    "CRR-E8": "LOAN_SL_HVCRE_003",
}


class TestCRRGroupE_SlottingApproach:
    """
    CRR Slotting acceptance tests.

    Each test loads fixture data, runs it through the production calculator,
    and compares the output against pre-calculated expected values.

    UK CRR Art. 153(5) has ONE weight table (Table 1) with maturity splits.
    The is_hvcre flag is preserved in the audit trail but does NOT alter the
    risk weight under UK CRR (P1.177 fix):
      >=2.5yr: Strong=70%, Good=90%, Satisfactory=115%, Weak=250%, Default=0%
      <2.5yr:  Strong=50%, Good=70%, Satisfactory=115%, Weak=250%, Default=0%

    Test fixtures use 5yr maturity (>=2.5yr), so the >=2.5yr weight set applies.
    Basel 3.1 (PRA PS1/26) has separate HVCRE weights; UK CRR does not.
    """

    def test_crr_e1_project_finance_strong(
        self,
        slotting_results_df: pl.DataFrame,
        expected_outputs_dict: dict[str, dict[str, Any]],
    ) -> None:
        """
        CRR-E1: Project finance with Strong slotting category.

        Input: Project finance, Strong category (>=2.5yr maturity)
        Expected: 70% RW (CRR Art. 153(5) Table 1)
        """
        expected = expected_outputs_dict["CRR-E1"]
        exposure_ref = SCENARIO_EXPOSURE_MAP["CRR-E1"]

        result = get_result_for_exposure(slotting_results_df, exposure_ref)

        if result is None:
            pytest.skip(f"Fixture data not available for {exposure_ref}")

        assert_risk_weight_match(
            result["risk_weight"],
            expected["risk_weight"],
            scenario_id="CRR-E1",
        )
        assert_rwa_within_tolerance(
            result["rwa_final"],
            expected["rwa_after_sf"],
            scenario_id="CRR-E1",
        )

    def test_crr_e2_project_finance_good(
        self,
        slotting_results_df: pl.DataFrame,
        expected_outputs_dict: dict[str, dict[str, Any]],
    ) -> None:
        """
        CRR-E2: Project finance with Good slotting category.

        Input: Project finance, Good category, 5yr maturity (>=2.5yr)
        Expected: 90% RW (CRR Art. 153(5) Table 1, non-HVCRE >=2.5yr)
        Note: Would be 70% if remaining maturity < 2.5 years.
        """
        expected = expected_outputs_dict["CRR-E2"]
        exposure_ref = SCENARIO_EXPOSURE_MAP["CRR-E2"]

        result = get_result_for_exposure(slotting_results_df, exposure_ref)

        if result is None:
            pytest.skip(f"Fixture data not available for {exposure_ref}")

        assert_risk_weight_match(
            result["risk_weight"],
            expected["risk_weight"],
            scenario_id="CRR-E2",
        )

    def test_crr_e3_ipre_weak(
        self,
        slotting_results_df: pl.DataFrame,
        expected_outputs_dict: dict[str, dict[str, Any]],
    ) -> None:
        """
        CRR-E3: Income-producing real estate with Weak category.

        Input: IPRE, Weak category
        Expected: 250% RW (punitive for weak credits)
        """
        expected = expected_outputs_dict["CRR-E3"]
        exposure_ref = SCENARIO_EXPOSURE_MAP["CRR-E3"]

        result = get_result_for_exposure(slotting_results_df, exposure_ref)

        if result is None:
            pytest.skip(f"Fixture data not available for {exposure_ref}")

        assert_risk_weight_match(
            result["risk_weight"],
            expected["risk_weight"],
            scenario_id="CRR-E3",
        )

    def test_crr_e4_hvcre_strong(
        self,
        slotting_results_df: pl.DataFrame,
        expected_outputs_dict: dict[str, dict[str, Any]],
    ) -> None:
        """
        CRR-E4: HVCRE with Strong slotting category.

        Input: HVCRE, Strong category, 5yr maturity (>=2.5yr)
        Expected: 70% RW (CRR Art. 153(5) Table 1 — UK CRR has no HVCRE Table 2)
        P1.177: is_hvcre=True does NOT change the RW under UK CRR.
        """
        expected = expected_outputs_dict["CRR-E4"]
        exposure_ref = SCENARIO_EXPOSURE_MAP["CRR-E4"]

        result = get_result_for_exposure(slotting_results_df, exposure_ref)

        if result is None:
            pytest.skip(f"Fixture data not available for {exposure_ref}")

        assert_risk_weight_match(
            result["risk_weight"],
            expected["risk_weight"],
            scenario_id="CRR-E4",
        )


class TestCRRGroupE_ShortMaturitySlotting:
    """
    CRR Slotting acceptance tests for short maturity (<2.5yr).

    CRR Art. 153(5) assigns reduced risk weights when remaining maturity < 2.5 years.
    UK CRR uses Table 1 only (P1.177 — no HVCRE differential):
    - Strong: 50% (vs 70% for >=2.5yr), regardless of is_hvcre
    - Good: 70% (vs 90% for >=2.5yr), regardless of is_hvcre
    """

    def test_crr_e5_pf_strong_short_maturity(
        self,
        slotting_results_df: pl.DataFrame,
        expected_outputs_dict: dict[str, dict[str, Any]],
    ) -> None:
        """
        CRR-E5: PF Strong with <2.5yr remaining maturity.

        Expected: 50% RW (CRR Art. 153(5) Table 1, <2.5yr)
        """
        expected = expected_outputs_dict["CRR-E5"]
        exposure_ref = SCENARIO_EXPOSURE_MAP["CRR-E5"]

        result = get_result_for_exposure(slotting_results_df, exposure_ref)

        if result is None:
            pytest.skip(f"Fixture data not available for {exposure_ref}")

        assert_risk_weight_match(
            result["risk_weight"],
            expected["risk_weight"],
            scenario_id="CRR-E5",
        )
        assert_rwa_within_tolerance(
            result["rwa_final"],
            expected["rwa_after_sf"],
            scenario_id="CRR-E5",
        )

    def test_crr_e6_pf_good_short_maturity(
        self,
        slotting_results_df: pl.DataFrame,
        expected_outputs_dict: dict[str, dict[str, Any]],
    ) -> None:
        """
        CRR-E6: PF Good with <2.5yr remaining maturity.

        Expected: 70% RW (CRR Art. 153(5) Table 1, <2.5yr)
        """
        expected = expected_outputs_dict["CRR-E6"]
        exposure_ref = SCENARIO_EXPOSURE_MAP["CRR-E6"]

        result = get_result_for_exposure(slotting_results_df, exposure_ref)

        if result is None:
            pytest.skip(f"Fixture data not available for {exposure_ref}")

        assert_risk_weight_match(
            result["risk_weight"],
            expected["risk_weight"],
            scenario_id="CRR-E6",
        )

    def test_crr_e7_hvcre_strong_short_maturity(
        self,
        slotting_results_df: pl.DataFrame,
        expected_outputs_dict: dict[str, dict[str, Any]],
    ) -> None:
        """
        CRR-E7: HVCRE Strong with <2.5yr remaining maturity.

        Expected: 50% RW (CRR Art. 153(5) Table 1, <2.5yr)
        P1.177: UK CRR ignores is_hvcre — Table 1 applies, so same as non-HVCRE Strong <2.5yr.
        """
        expected = expected_outputs_dict["CRR-E7"]
        exposure_ref = SCENARIO_EXPOSURE_MAP["CRR-E7"]

        result = get_result_for_exposure(slotting_results_df, exposure_ref)

        if result is None:
            pytest.skip(f"Fixture data not available for {exposure_ref}")

        assert_risk_weight_match(
            result["risk_weight"],
            expected["risk_weight"],
            scenario_id="CRR-E7",
        )

    def test_crr_e8_hvcre_good_short_maturity(
        self,
        slotting_results_df: pl.DataFrame,
        expected_outputs_dict: dict[str, dict[str, Any]],
    ) -> None:
        """
        CRR-E8: HVCRE Good with <2.5yr remaining maturity.

        Expected: 70% RW (CRR Art. 153(5) Table 1, <2.5yr)
        P1.177: UK CRR ignores is_hvcre — Table 1 applies, so same as non-HVCRE Good <2.5yr.
        """
        expected = expected_outputs_dict["CRR-E8"]
        exposure_ref = SCENARIO_EXPOSURE_MAP["CRR-E8"]

        result = get_result_for_exposure(slotting_results_df, exposure_ref)

        if result is None:
            pytest.skip(f"Fixture data not available for {exposure_ref}")

        assert_risk_weight_match(
            result["risk_weight"],
            expected["risk_weight"],
            scenario_id="CRR-E8",
        )


class TestCRRGroupE_ParameterizedValidation:
    """
    Parametrized tests to validate expected outputs structure.
    These tests run without the production calculator.
    """

    def test_all_crr_e_scenarios_exist(
        self,
        expected_outputs_dict: dict[str, dict[str, Any]],
    ) -> None:
        """Verify all CRR-E scenarios exist in expected outputs."""
        expected_ids = [f"CRR-E{i}" for i in range(1, 9)]
        for scenario_id in expected_ids:
            assert scenario_id in expected_outputs_dict, (
                f"Missing expected output for {scenario_id}"
            )

    def test_all_crr_e_scenarios_use_slotting_approach(
        self,
        crr_e_scenarios: list[dict[str, Any]],
    ) -> None:
        """Verify all CRR-E scenarios use Slotting approach."""
        for scenario in crr_e_scenarios:
            assert scenario["approach"] == "Slotting", (
                f"Scenario {scenario['scenario_id']} should use Slotting approach, "
                f"got {scenario['approach']}"
            )

    def test_crr_e_scenarios_have_valid_slotting_rw(
        self,
        crr_e_scenarios: list[dict[str, Any]],
        crr_slotting_rw: dict,
    ) -> None:
        """Verify slotting scenarios use valid CRR risk weights.

        Under UK CRR Art. 153(5) Table 1 only (P1.177):
        >=2.5yr: Strong=70%, Good=90%, Satisfactory=115%, Weak=250%, Default=0%
        <2.5yr:  Strong=50%, Good=70%, Satisfactory=115%, Weak=250%, Default=0%
        HVCRE exposures use the same Table 1 values — 0.95, 1.20, 1.40 are EU Table 2
        values that do NOT apply under UK CRR.
        """
        valid_rws = [0.50, 0.70, 0.90, 1.15, 2.50, 0.00]
        for scenario in crr_e_scenarios:
            rw = scenario["risk_weight"]
            assert any(rw == pytest.approx(v, rel=0.01) for v in valid_rws), (
                f"Scenario {scenario['scenario_id']} has invalid slotting RW: {rw}"
            )

    def test_crr_e_strong_higher_than_good(
        self,
        expected_outputs_dict: dict[str, dict[str, Any]],
    ) -> None:
        """Verify Good has higher RW than Strong under CRR (90% vs 70%)."""
        strong = expected_outputs_dict["CRR-E1"]
        good = expected_outputs_dict["CRR-E2"]
        assert strong["risk_weight"] == pytest.approx(0.70)
        assert good["risk_weight"] == pytest.approx(0.90)

    def test_crr_e_hvcre_same_as_non_hvcre(
        self,
        expected_outputs_dict: dict[str, dict[str, Any]],
    ) -> None:
        """Under UK CRR, HVCRE uses the SAME weights as non-HVCRE (Table 1 only).

        P1.177 / CRR Art. 153(5): UK CRR onshoring did not retain the EU HVCRE
        Table 2 uplift. Both PF Strong (CRR-E1) and HVCRE Strong (CRR-E4) are 70%.
        """
        pf_strong = expected_outputs_dict["CRR-E1"]  # Non-HVCRE Strong = 70%
        hvcre_strong = expected_outputs_dict["CRR-E4"]  # HVCRE Strong = 70% (Table 1)
        assert pf_strong["risk_weight"] == pytest.approx(0.70)
        assert hvcre_strong["risk_weight"] == pytest.approx(0.70)
        assert pf_strong["risk_weight"] == pytest.approx(hvcre_strong["risk_weight"])
