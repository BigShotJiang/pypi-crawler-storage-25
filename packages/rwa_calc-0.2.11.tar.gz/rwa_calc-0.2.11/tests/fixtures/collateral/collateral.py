"""
Generate collateral test fixtures for credit risk mitigation testing.

The output will be saved as `collateral.parquet` ready to get picked up within the wider
testing process.

Collateral types for testing:
    - Cash collateral (0% haircut)
    - Government bonds (supervisory haircuts by maturity)
    - Equity (25% haircut for main index)
    - Real estate (residential/commercial, LTV-based)
    - Receivables (IRB eligible)

CRM scenarios covered:
    D1: Cash collateral (SA) - £500k cash against £1m exposure
    D2: Government bond collateral - £600k gilts with maturity haircut
    D3: Equity collateral - £400k listed equity, 25% haircut
    D5: Maturity mismatch - 2yr collateral against 5yr exposure
    D6: Currency mismatch - EUR collateral against GBP exposure
    B2: Corporate with financial collateral (IRB)
    B3: Corporate with real estate (FIRB)
    A5/A6: Residential mortgages with different LTVs

Usage:
    uv run python tests/fixtures/collateral/collateral.py
"""

from dataclasses import dataclass
from datetime import date
from pathlib import Path

import polars as pl

from rwa_calc.data.column_spec import dtypes_of
from rwa_calc.data.schemas import COLLATERAL_SCHEMA


def main() -> None:
    """Entry point for collateral generation."""
    output_path = save_collateral()
    print_summary(output_path)


@dataclass(frozen=True)
class Collateral:
    """A collateral item for credit risk mitigation."""

    collateral_reference: str
    collateral_type: str
    currency: str
    maturity_date: date | None
    market_value: float
    nominal_value: float
    beneficiary_type: str
    beneficiary_reference: str
    issuer_cqs: int | None
    issuer_type: str | None
    residual_maturity_years: float | None
    is_eligible_financial_collateral: bool
    is_eligible_irb_collateral: bool
    valuation_date: date
    valuation_type: str
    property_type: str | None
    property_ltv: float | None
    is_income_producing: bool | None
    is_adc: bool | None
    is_presold: bool | None
    liquidation_period_days: int | None = None
    original_maturity_years: float | None = None
    rental_to_interest_ratio: float | None = None

    def to_dict(self) -> dict:
        return {
            "collateral_reference": self.collateral_reference,
            "collateral_type": self.collateral_type,
            "currency": self.currency,
            "maturity_date": self.maturity_date,
            "market_value": self.market_value,
            "nominal_value": self.nominal_value,
            "beneficiary_type": self.beneficiary_type,
            "beneficiary_reference": self.beneficiary_reference,
            "issuer_cqs": self.issuer_cqs,
            "issuer_type": self.issuer_type,
            "residual_maturity_years": self.residual_maturity_years,
            "original_maturity_years": self.original_maturity_years,
            "is_eligible_financial_collateral": self.is_eligible_financial_collateral,
            "is_eligible_irb_collateral": self.is_eligible_irb_collateral,
            "valuation_date": self.valuation_date,
            "valuation_type": self.valuation_type,
            "property_type": self.property_type,
            "property_ltv": self.property_ltv,
            "is_income_producing": self.is_income_producing,
            "is_adc": self.is_adc,
            "is_presold": self.is_presold,
            "liquidation_period_days": self.liquidation_period_days,
            "rental_to_interest_ratio": self.rental_to_interest_ratio,
        }


VALUE_DATE = date(2026, 1, 1)


def create_collateral() -> pl.DataFrame:
    """
    Create collateral test data.

    Returns:
        pl.DataFrame: Collateral matching COLLATERAL_SCHEMA
    """
    collateral = [
        *_cash_collateral(),
        *_government_bond_collateral(),
        *_equity_collateral(),
        *_residential_real_estate(),
        *_commercial_real_estate(),
        *_receivables_collateral(),
        *_crm_test_collateral(),
        *_crr_d_scenario_collateral(),
        *_complex_scenario_collateral(),
        *_p1_158_null_maturity_haircut_collateral(),
        *_p1_106_fcsm_institution_bond_collateral(),
        *_p1_107_fcsm_corporate_bond_collateral(),
        *_crr_d15_covered_bond_collateral(),
    ]

    return pl.DataFrame([c.to_dict() for c in collateral], schema=dtypes_of(COLLATERAL_SCHEMA))


def _cash_collateral() -> list[Collateral]:
    """
    Cash collateral - 0% haircut, highest quality CRM.

    Scenario D1: Cash collateral against corporate exposure.
    """
    return [
        # D1: Cash collateral for corporate loan - £500k cash
        # NOTE: Uses dedicated test loan to avoid affecting CRR-A12 test
        Collateral(
            collateral_reference="COLL_CASH_001",
            collateral_type="cash",
            currency="GBP",
            maturity_date=None,
            market_value=500_000.0,
            nominal_value=500_000.0,
            beneficiary_type="loan",
            beneficiary_reference="LOAN_COLL_TEST_CORP_003",  # Dedicated test loan
            issuer_cqs=None,
            issuer_type=None,
            residual_maturity_years=None,
            is_eligible_financial_collateral=True,
            is_eligible_irb_collateral=True,
            valuation_date=VALUE_DATE,
            valuation_type="market",
            property_type=None,
            property_ltv=None,
            is_income_producing=None,
            is_adc=None,
            is_presold=None,
        ),
        # Cash collateral for SME loan (uses dedicated test loan)
        Collateral(
            collateral_reference="COLL_CASH_002",
            collateral_type="cash",
            currency="GBP",
            maturity_date=None,
            market_value=200_000.0,
            nominal_value=200_000.0,
            beneficiary_type="loan",
            beneficiary_reference="LOAN_COLL_TEST_SME_001",  # Dedicated test loan
            issuer_cqs=None,
            issuer_type=None,
            residual_maturity_years=None,
            is_eligible_financial_collateral=True,
            is_eligible_irb_collateral=True,
            valuation_date=VALUE_DATE,
            valuation_type="market",
            property_type=None,
            property_ltv=None,
            is_income_producing=None,
            is_adc=None,
            is_presold=None,
        ),
    ]


def _government_bond_collateral() -> list[Collateral]:
    """
    Government bond collateral - supervisory haircuts by residual maturity.

    Scenario D2: UK gilts collateral.
    Haircuts (CRE22.52): <=1yr: 0.5%, 1-3yr: 2%, 3-5yr: 4%, 5-10yr: 4%, >10yr: 12%
    """
    return [
        # UK Gilts 5-year - 4% haircut (uses dedicated test loan)
        Collateral(
            collateral_reference="COLL_GILT_001",
            collateral_type="bond",
            currency="GBP",
            maturity_date=date(2031, 1, 1),
            market_value=600_000.0,
            nominal_value=600_000.0,
            beneficiary_type="loan",
            beneficiary_reference="LOAN_COLL_TEST_CORP_001",  # Dedicated test loan
            issuer_cqs=1,
            issuer_type="sovereign",
            residual_maturity_years=5.0,
            is_eligible_financial_collateral=True,
            is_eligible_irb_collateral=True,
            valuation_date=VALUE_DATE,
            valuation_type="market",
            property_type=None,
            property_ltv=None,
            is_income_producing=None,
            is_adc=None,
            is_presold=None,
        ),
        # Short-term gilt - 0.5% haircut
        Collateral(
            collateral_reference="COLL_GILT_002",
            collateral_type="bond",
            currency="GBP",
            maturity_date=date(2026, 6, 1),
            market_value=1_000_000.0,
            nominal_value=1_000_000.0,
            beneficiary_type="loan",
            beneficiary_reference="LOAN_INST_UK_001",
            issuer_cqs=1,
            issuer_type="sovereign",
            residual_maturity_years=0.4,
            is_eligible_financial_collateral=True,
            is_eligible_irb_collateral=True,
            valuation_date=VALUE_DATE,
            valuation_type="market",
            property_type=None,
            property_ltv=None,
            is_income_producing=None,
            is_adc=None,
            is_presold=None,
        ),
        # US Treasury bond - 2% haircut (1-3yr)
        Collateral(
            collateral_reference="COLL_UST_001",
            collateral_type="bond",
            currency="USD",
            maturity_date=date(2028, 6, 1),
            market_value=800_000.0,
            nominal_value=800_000.0,
            beneficiary_type="loan",
            beneficiary_reference="LOAN_SOV_US_001",
            issuer_cqs=1,
            issuer_type="sovereign",
            residual_maturity_years=2.4,
            is_eligible_financial_collateral=True,
            is_eligible_irb_collateral=True,
            valuation_date=VALUE_DATE,
            valuation_type="market",
            property_type=None,
            property_ltv=None,
            is_income_producing=None,
            is_adc=None,
            is_presold=None,
        ),
    ]


def _equity_collateral() -> list[Collateral]:
    """
    Equity collateral - 25% haircut for main index equities.

    Scenario D3: Listed equity collateral.
    """
    return [
        # Listed equity (FTSE 100) - 25% haircut (uses dedicated test loan)
        Collateral(
            collateral_reference="COLL_EQ_001",
            collateral_type="equity",
            currency="GBP",
            maturity_date=None,
            market_value=400_000.0,
            nominal_value=400_000.0,
            beneficiary_type="loan",
            beneficiary_reference="LOAN_COLL_TEST_CORP_002",  # Dedicated test loan
            issuer_cqs=None,
            issuer_type="corporate",
            residual_maturity_years=None,
            is_eligible_financial_collateral=True,
            is_eligible_irb_collateral=True,
            valuation_date=VALUE_DATE,
            valuation_type="market",
            property_type=None,
            property_ltv=None,
            is_income_producing=None,
            is_adc=None,
            is_presold=None,
        ),
        # Listed equity for subordinated loan
        Collateral(
            collateral_reference="COLL_EQ_002",
            collateral_type="equity",
            currency="GBP",
            maturity_date=None,
            market_value=1_000_000.0,
            nominal_value=1_000_000.0,
            beneficiary_type="loan",
            beneficiary_reference="LOAN_CORP_SUB_001",
            issuer_cqs=None,
            issuer_type="corporate",
            residual_maturity_years=None,
            is_eligible_financial_collateral=True,
            is_eligible_irb_collateral=True,
            valuation_date=VALUE_DATE,
            valuation_type="market",
            property_type=None,
            property_ltv=None,
            is_income_producing=None,
            is_adc=None,
            is_presold=None,
        ),
    ]


def _residential_real_estate() -> list[Collateral]:
    """
    Residential real estate collateral for mortgages.

    Scenario A5: 60% LTV residential = 20% RW
    Scenario A6: 85% LTV residential = 35% RW
    """
    return [
        # A5: Residential property 60% LTV (£500k loan / £833,333 property)
        Collateral(
            collateral_reference="COLL_RRE_001",
            collateral_type="real_estate",
            currency="GBP",
            maturity_date=None,
            market_value=833_333.0,
            nominal_value=833_333.0,
            beneficiary_type="loan",
            beneficiary_reference="LOAN_RTL_MTG_001",
            issuer_cqs=None,
            issuer_type=None,
            residual_maturity_years=None,
            is_eligible_financial_collateral=False,
            is_eligible_irb_collateral=True,
            valuation_date=VALUE_DATE,
            valuation_type="independent",
            property_type="residential",
            property_ltv=0.60,
            is_income_producing=False,
            is_adc=False,
            is_presold=None,
        ),
        # A6: Residential property 85% LTV (£850k loan / £1,000,000 property)
        Collateral(
            collateral_reference="COLL_RRE_002",
            collateral_type="real_estate",
            currency="GBP",
            maturity_date=None,
            market_value=1_000_000.0,
            nominal_value=1_000_000.0,
            beneficiary_type="loan",
            beneficiary_reference="LOAN_RTL_MTG_002",
            issuer_cqs=None,
            issuer_type=None,
            residual_maturity_years=None,
            is_eligible_financial_collateral=False,
            is_eligible_irb_collateral=True,
            valuation_date=VALUE_DATE,
            valuation_type="independent",
            property_type="residential",
            property_ltv=0.85,
            is_income_producing=False,
            is_adc=False,
            is_presold=None,
        ),
        # Additional residential property for lending group testing
        Collateral(
            collateral_reference="COLL_RRE_003",
            collateral_type="real_estate",
            currency="GBP",
            maturity_date=None,
            market_value=350_000.0,
            nominal_value=350_000.0,
            beneficiary_type="loan",
            beneficiary_reference="LOAN_LG2_OWNER",
            issuer_cqs=None,
            issuer_type=None,
            residual_maturity_years=None,
            is_eligible_financial_collateral=False,
            is_eligible_irb_collateral=True,
            valuation_date=VALUE_DATE,
            valuation_type="independent",
            property_type="residential",
            property_ltv=0.23,
            is_income_producing=False,
            is_adc=False,
            is_presold=None,
        ),
    ]


def _commercial_real_estate() -> list[Collateral]:
    """
    Commercial real estate collateral.

    Scenario B3: Corporate with real estate - FIRB supervisory LGD.
    Different RW treatment for income-producing properties.
    """
    return [
        # B3: Commercial property for corporate loan (non-income producing)
        Collateral(
            collateral_reference="COLL_CRE_001",
            collateral_type="real_estate",
            currency="GBP",
            maturity_date=None,
            market_value=2_000_000.0,
            nominal_value=2_000_000.0,
            beneficiary_type="loan",
            beneficiary_reference="LOAN_FAC_CORP_001_A",
            issuer_cqs=None,
            issuer_type=None,
            residual_maturity_years=None,
            is_eligible_financial_collateral=False,
            is_eligible_irb_collateral=True,
            valuation_date=VALUE_DATE,
            valuation_type="independent",
            property_type="commercial",
            property_ltv=0.55,
            is_income_producing=False,
            is_adc=False,
            is_presold=None,
        ),
        # Income-producing commercial property
        Collateral(
            collateral_reference="COLL_CRE_002",
            collateral_type="real_estate",
            currency="GBP",
            maturity_date=None,
            market_value=5_000_000.0,
            nominal_value=5_000_000.0,
            beneficiary_type="loan",
            beneficiary_reference="LOAN_FAC_CORP_002_A",
            issuer_cqs=None,
            issuer_type=None,
            residual_maturity_years=None,
            is_eligible_financial_collateral=False,
            is_eligible_irb_collateral=True,
            valuation_date=VALUE_DATE,
            valuation_type="independent",
            property_type="commercial",
            property_ltv=0.60,
            is_income_producing=True,
            is_adc=False,
            is_presold=None,
        ),
        # CRR-A7: Commercial property 40% LTV (£400k loan / £1m property)
        # Income-producing property that meets 1.5x interest coverage
        Collateral(
            collateral_reference="COLL_CRE_A7",
            collateral_type="real_estate",
            currency="GBP",
            maturity_date=None,
            market_value=1_000_000.0,  # £1m property value
            nominal_value=1_000_000.0,
            beneficiary_type="loan",
            beneficiary_reference="LOAN_CRE_001",
            issuer_cqs=None,
            issuer_type=None,
            residual_maturity_years=None,
            is_eligible_financial_collateral=False,
            is_eligible_irb_collateral=True,
            valuation_date=VALUE_DATE,
            valuation_type="independent",
            property_type="commercial",
            property_ltv=0.40,  # 40% LTV
            is_income_producing=True,  # Meets 1.5x interest coverage
            is_adc=False,
            is_presold=None,
        ),
        # CRR-A13: Commercial property 80% LTV (£800k loan / £1m property)
        # Art. 126(2)(d) proportion split: portion ≤ 50% of property value (£500k) → 50% RW,
        # remaining portion (£300k) falls back to unrated corporate → 100% RW.
        # rental_to_interest_ratio=1.5 satisfies the income-cover test (Art. 126(2)(a)).
        Collateral(
            collateral_reference="COLL_CRE_A13",
            collateral_type="real_estate",
            currency="GBP",
            maturity_date=None,
            market_value=1_000_000.0,  # £1m property value
            nominal_value=1_000_000.0,
            beneficiary_type="loan",
            beneficiary_reference="LOAN_CRE_002",
            issuer_cqs=None,
            issuer_type=None,
            residual_maturity_years=None,
            is_eligible_financial_collateral=False,
            is_eligible_irb_collateral=True,
            valuation_date=VALUE_DATE,
            valuation_type="independent",
            property_type="commercial",
            property_ltv=0.80,  # 80% LTV — triggers proportion split
            is_income_producing=True,
            is_adc=False,
            is_presold=None,
            rental_to_interest_ratio=1.5,  # Art. 126(2)(a) income-cover threshold exactly met
        ),
        # ADC property (150% RW unless pre-sold)
        Collateral(
            collateral_reference="COLL_CRE_003",
            collateral_type="real_estate",
            currency="GBP",
            maturity_date=None,
            market_value=3_000_000.0,
            nominal_value=3_000_000.0,
            beneficiary_type="loan",
            beneficiary_reference="LOAN_HIER_001_A",
            issuer_cqs=None,
            issuer_type=None,
            residual_maturity_years=None,
            is_eligible_financial_collateral=False,
            is_eligible_irb_collateral=True,
            valuation_date=VALUE_DATE,
            valuation_type="independent",
            property_type="commercial",
            property_ltv=0.50,
            is_income_producing=False,
            is_adc=True,
            is_presold=False,
        ),
        # Pre-sold commercial ADC property (150% RW — Art. 124K(2) concession is residential-only)
        Collateral(
            collateral_reference="COLL_CRE_004",
            collateral_type="real_estate",
            currency="GBP",
            maturity_date=None,
            market_value=4_000_000.0,
            nominal_value=4_000_000.0,
            beneficiary_type="loan",
            beneficiary_reference="LOAN_HIER_001_B",
            issuer_cqs=None,
            issuer_type=None,
            residual_maturity_years=None,
            is_eligible_financial_collateral=False,
            is_eligible_irb_collateral=True,
            valuation_date=VALUE_DATE,
            valuation_type="independent",
            property_type="commercial",
            property_ltv=0.50,
            is_income_producing=False,
            is_adc=True,
            is_presold=True,
        ),
    ]


def _receivables_collateral() -> list[Collateral]:
    """
    Receivables collateral - IRB eligible only.

    Supervisory LGD: 20% (FIRB), Floor 10% (AIRB).
    """
    return [
        # Trade receivables for SME loan
        Collateral(
            collateral_reference="COLL_REC_001",
            collateral_type="receivables",
            currency="GBP",
            maturity_date=date(2026, 4, 1),
            market_value=300_000.0,
            nominal_value=350_000.0,
            beneficiary_type="loan",
            beneficiary_reference="LOAN_FAC_SME_001_A",
            issuer_cqs=None,
            issuer_type=None,
            residual_maturity_years=0.25,
            is_eligible_financial_collateral=False,
            is_eligible_irb_collateral=True,
            valuation_date=VALUE_DATE,
            valuation_type="market",
            property_type=None,
            property_ltv=None,
            is_income_producing=None,
            is_adc=None,
            is_presold=None,
        ),
        # Invoice receivables for SME retail (uses dedicated test loan)
        Collateral(
            collateral_reference="COLL_REC_002",
            collateral_type="receivables",
            currency="GBP",
            maturity_date=date(2026, 3, 1),
            market_value=100_000.0,
            nominal_value=120_000.0,
            beneficiary_type="loan",
            beneficiary_reference="LOAN_COLL_TEST_RTL_001",  # Dedicated test loan
            issuer_cqs=None,
            issuer_type=None,
            residual_maturity_years=0.16,
            is_eligible_financial_collateral=False,
            is_eligible_irb_collateral=True,
            valuation_date=VALUE_DATE,
            valuation_type="market",
            property_type=None,
            property_ltv=None,
            is_income_producing=None,
            is_adc=None,
            is_presold=None,
        ),
    ]


def _crm_test_collateral() -> list[Collateral]:
    """
    Collateral specifically for CRM scenario testing.

    D5: Maturity mismatch - 2yr collateral against 5yr exposure
    D6: Currency mismatch - EUR collateral against GBP exposure
    B2: Corporate with financial collateral (IRB)
    """
    return [
        # =============================================================================
        # D5: Maturity mismatch scenario
        # £500k collateral with 2yr residual against 5yr exposure
        # Adjustment factor: (t-0.25)/(T-0.25) = (1.75)/(4.75) = 0.368
        # =============================================================================
        Collateral(
            collateral_reference="COLL_MAT_MISMATCH_001",
            collateral_type="bond",
            currency="GBP",
            maturity_date=date(2028, 1, 1),  # 2yr maturity
            market_value=500_000.0,
            nominal_value=500_000.0,
            beneficiary_type="loan",
            beneficiary_reference="LOAN_HIER_SUB_001_A",  # 5yr exposure
            issuer_cqs=1,
            issuer_type="sovereign",
            residual_maturity_years=2.0,
            is_eligible_financial_collateral=True,
            is_eligible_irb_collateral=True,
            valuation_date=VALUE_DATE,
            valuation_type="market",
            property_type=None,
            property_ltv=None,
            is_income_producing=None,
            is_adc=None,
            is_presold=None,
        ),
        # =============================================================================
        # D6: Currency mismatch scenario
        # €500k collateral against GBP exposure
        # FX haircut = 8% × √(20/10) = 11.314% (20-day liquidation period, non-SFT)
        # CRR Art. 224(2)(a) / Art. 226(2)
        # =============================================================================
        Collateral(
            collateral_reference="COLL_CCY_MISMATCH_001",
            collateral_type="cash",
            currency="EUR",
            maturity_date=None,
            market_value=500_000.0,
            nominal_value=500_000.0,
            beneficiary_type="loan",
            beneficiary_reference="LOAN_HIER_SUB_002_A",  # GBP exposure
            issuer_cqs=None,
            issuer_type=None,
            residual_maturity_years=None,
            is_eligible_financial_collateral=True,
            is_eligible_irb_collateral=True,
            valuation_date=VALUE_DATE,
            valuation_type="market",
            property_type=None,
            property_ltv=None,
            is_income_producing=None,
            is_adc=None,
            is_presold=None,
        ),
        # =============================================================================
        # B2: Corporate with financial collateral (IRB testing)
        # £500k cash collateral, LGD=0% for cash portion
        # =============================================================================
        Collateral(
            collateral_reference="COLL_IRB_CORP_001",
            collateral_type="cash",
            currency="GBP",
            maturity_date=None,
            market_value=500_000.0,
            nominal_value=500_000.0,
            beneficiary_type="facility",
            beneficiary_reference="FAC_CORP_001",
            issuer_cqs=None,
            issuer_type=None,
            residual_maturity_years=None,
            is_eligible_financial_collateral=True,
            is_eligible_irb_collateral=True,
            valuation_date=VALUE_DATE,
            valuation_type="market",
            property_type=None,
            property_ltv=None,
            is_income_producing=None,
            is_adc=None,
            is_presold=None,
        ),
        # Gold collateral (0% haircut like cash)
        Collateral(
            collateral_reference="COLL_GOLD_001",
            collateral_type="gold",
            currency="GBP",
            maturity_date=None,
            market_value=250_000.0,
            nominal_value=250_000.0,
            beneficiary_type="facility",
            beneficiary_reference="FAC_CORP_002",
            issuer_cqs=None,
            issuer_type=None,
            residual_maturity_years=None,
            is_eligible_financial_collateral=True,
            is_eligible_irb_collateral=True,
            valuation_date=VALUE_DATE,
            valuation_type="market",
            property_type=None,
            property_ltv=None,
            is_income_producing=None,
            is_adc=None,
            is_presold=None,
        ),
        # Corporate bond collateral (CQS 3, higher haircut)
        Collateral(
            collateral_reference="COLL_CORP_BOND_001",
            collateral_type="bond",
            currency="GBP",
            maturity_date=date(2029, 1, 1),
            market_value=400_000.0,
            nominal_value=400_000.0,
            beneficiary_type="loan",
            beneficiary_reference="LOAN_INST_UR_001",
            issuer_cqs=3,
            issuer_type="corporate",
            residual_maturity_years=3.0,
            is_eligible_financial_collateral=True,
            is_eligible_irb_collateral=True,
            valuation_date=VALUE_DATE,
            valuation_type="market",
            property_type=None,
            property_ltv=None,
            is_income_producing=None,
            is_adc=None,
            is_presold=None,
        ),
        # Ineligible collateral (for testing exclusion)
        Collateral(
            collateral_reference="COLL_INELIG_001",
            collateral_type="other_physical",
            currency="GBP",
            maturity_date=None,
            market_value=100_000.0,
            nominal_value=100_000.0,
            beneficiary_type="loan",
            beneficiary_reference="LOAN_DF_CORP_001",
            issuer_cqs=None,
            issuer_type=None,
            residual_maturity_years=None,
            is_eligible_financial_collateral=False,
            is_eligible_irb_collateral=False,
            valuation_date=VALUE_DATE,
            valuation_type="market",
            property_type=None,
            property_ltv=None,
            is_income_producing=None,
            is_adc=None,
            is_presold=None,
        ),
    ]


def _crr_d_scenario_collateral() -> list[Collateral]:
    """
    Collateral for CRR-D CRM acceptance test scenarios.

    D1: Cash collateral (0% haircut) - £500k against £1m exposure
    D2: Government bond (4% haircut for CQS 1, >5y) - £600k against £1m exposure
    D3: Equity main index (15% haircut) - £400k against £1m exposure
    D5: Maturity mismatch (2yr collateral vs 5yr exposure) - £500k
    D6: Currency mismatch (EUR vs GBP) - €500k against £1m GBP exposure
    """
    return [
        # =============================================================================
        # D1: Cash collateral - 0% haircut
        # £500k cash against £1m exposure
        # EAD = £1m - £500k = £500k
        # =============================================================================
        Collateral(
            collateral_reference="COLL_CRM_D1",
            collateral_type="cash",
            currency="GBP",
            maturity_date=None,
            market_value=500_000.0,
            nominal_value=500_000.0,
            beneficiary_type="loan",
            beneficiary_reference="LOAN_CRM_D1",
            issuer_cqs=None,
            issuer_type=None,
            residual_maturity_years=None,
            is_eligible_financial_collateral=True,
            is_eligible_irb_collateral=True,
            valuation_date=VALUE_DATE,
            valuation_type="market",
            property_type=None,
            property_ltv=None,
            is_income_producing=None,
            is_adc=None,
            is_presold=None,
        ),
        # =============================================================================
        # D2: Government bond collateral - 4% haircut (CQS 1, >5y maturity)
        # £600k gilt against £1m exposure
        # Effective collateral = £600k * (1 - 0.04) = £576k
        # EAD = £1m - £576k = £424k
        # =============================================================================
        Collateral(
            collateral_reference="COLL_CRM_D2",
            collateral_type="bond",
            currency="GBP",
            maturity_date=date(2032, 1, 1),  # >5y residual maturity
            market_value=600_000.0,
            nominal_value=600_000.0,
            beneficiary_type="loan",
            beneficiary_reference="LOAN_CRM_D2",
            issuer_cqs=1,  # CQS 1 sovereign
            issuer_type="sovereign",
            residual_maturity_years=6.0,  # >5y for 4% haircut
            is_eligible_financial_collateral=True,
            is_eligible_irb_collateral=True,
            valuation_date=VALUE_DATE,
            valuation_type="market",
            property_type=None,
            property_ltv=None,
            is_income_producing=None,
            is_adc=None,
            is_presold=None,
        ),
        # =============================================================================
        # D3: Equity collateral (main index) - 15% haircut
        # £400k FTSE 100 equity against £1m exposure
        # Effective collateral = £400k * (1 - 0.15) = £340k
        # EAD = £1m - £340k = £660k
        # =============================================================================
        Collateral(
            collateral_reference="COLL_CRM_D3",
            collateral_type="equity",
            currency="GBP",
            maturity_date=None,
            market_value=400_000.0,
            nominal_value=400_000.0,
            beneficiary_type="loan",
            beneficiary_reference="LOAN_CRM_D3",
            issuer_cqs=None,
            issuer_type="corporate",  # Listed equity
            residual_maturity_years=None,
            is_eligible_financial_collateral=True,
            is_eligible_irb_collateral=True,
            valuation_date=VALUE_DATE,
            valuation_type="market",
            property_type=None,
            property_ltv=None,
            is_income_producing=None,
            is_adc=None,
            is_presold=None,
        ),
        # =============================================================================
        # D5: Maturity mismatch - 2yr collateral vs 5yr exposure
        # £500k cash with 2yr maturity against 5yr loan
        # Adjustment = (t-0.25)/(T-0.25) = (2-0.25)/(5-0.25) = 1.75/4.75 = 0.3684
        # Effective collateral = £500k * 0.3684 = £184,210.53
        # EAD = £1m - £184,210.53 = £815,789.47
        # =============================================================================
        Collateral(
            collateral_reference="COLL_CRM_D5",
            collateral_type="bond",
            currency="GBP",
            maturity_date=date(2028, 1, 1),  # 2yr maturity (vs 5yr exposure)
            market_value=500_000.0,
            nominal_value=500_000.0,
            beneficiary_type="loan",
            beneficiary_reference="LOAN_CRM_D5",
            issuer_cqs=1,
            issuer_type="sovereign",
            residual_maturity_years=2.0,  # 2yr for maturity mismatch
            is_eligible_financial_collateral=True,
            is_eligible_irb_collateral=True,
            valuation_date=VALUE_DATE,
            valuation_type="market",
            property_type=None,
            property_ltv=None,
            is_income_producing=None,
            is_adc=None,
            is_presold=None,
        ),
        # =============================================================================
        # D6: Currency mismatch - EUR collateral vs GBP exposure
        # €500k cash (market value in GBP = £500k) against £1m GBP exposure
        # No liquidation_period_days override; is_sft=False → 20-day holding period
        # FX haircut = 8% × √(20/10) = 8% × √2 = 11.314%  (CRR Art. 224(2)(a) / Art. 226(2))
        # Value after haircut = £500k × (1 - 0.11314) = £443,431.46
        # EAD = £1m - £443,431.46 = £556,568.54  |  RWA = £556,568.54 (100% RW, unrated corp)
        # =============================================================================
        Collateral(
            collateral_reference="COLL_CRM_D6",
            collateral_type="cash",
            currency="EUR",  # Different from loan currency (GBP)
            maturity_date=None,
            market_value=500_000.0,  # GBP equivalent for simplicity
            nominal_value=500_000.0,
            beneficiary_type="loan",
            beneficiary_reference="LOAN_CRM_D6",
            issuer_cqs=None,
            issuer_type=None,
            residual_maturity_years=None,
            is_eligible_financial_collateral=True,
            is_eligible_irb_collateral=True,
            valuation_date=VALUE_DATE,
            valuation_type="market",
            property_type=None,
            property_ltv=None,
            is_income_producing=None,
            is_adc=None,
            is_presold=None,
        ),
    ]


def _complex_scenario_collateral() -> list[Collateral]:
    """
    Collateral for CRR-H complex scenario testing.

    CRR-H4: Full CRM chain - £500k cash collateral
        - Cash collateral: £500k (0% haircut)
        - Combined with guarantee and provision for full CRM demonstration
    """
    return [
        # =============================================================================
        # CRR-H4: Full CRM Chain - Cash Collateral
        # £500k cash collateral against £2m gross exposure
        # 0% haircut, fully reduces EAD
        # =============================================================================
        Collateral(
            collateral_reference="COLL_CRM_FULL_CASH",
            collateral_type="cash",
            currency="GBP",
            maturity_date=None,
            market_value=500_000.0,  # £500k cash
            nominal_value=500_000.0,
            beneficiary_type="loan",
            beneficiary_reference="LOAN_CRM_FULL",
            issuer_cqs=None,
            issuer_type=None,
            residual_maturity_years=None,
            is_eligible_financial_collateral=True,
            is_eligible_irb_collateral=True,
            valuation_date=VALUE_DATE,
            valuation_type="market",
            property_type=None,
            property_ltv=None,
            is_income_producing=None,
            is_adc=None,
            is_presold=None,
        ),
    ]


def _p1_158_null_maturity_haircut_collateral() -> list[Collateral]:
    """
    Collateral for P1.158: conservative fallback when residual_maturity_years is None.

    The bug in data/tables/haircuts.py uses ``residual_maturity_years or 5.0`` which
    lands the lookup in the 1_5y band instead of the conservative 5y_plus (CRR) /
    10y_plus (B31) band when maturity is unknown (None).

    This fixture exercises the engine-pipeline path:
        - Loan: £1m GBP corporate term loan (~6y maturity) to unrated counterparty.
        - Collateral: corp_bond CQS 2, residual_maturity_years=None, GBP, £500k market value,
          liquidation_period_days=10.
    Post-fix expected:
        - collateral haircut = 0.12  (corp_bond_cqs2_3_5y_plus, CRR)
        - C_adjusted = 500,000 × (1 − 0.12) = 440,000
        - E* = max(0, 1,000,000 − 440,000) = 560,000
        - RWA = 560,000  (unrated corporate SA RW = 100%)
    Pre-fix (buggy) collateral haircut = 0.06 → C_adjusted = 470,000 → E* = 530,000.

    References:
        - CRR Art. 224(1) Table 1; Art. 224(3) conservative fallback
        - src/rwa_calc/data/tables/haircuts.py:475 (defect line)
    """
    return [
        # =============================================================================
        # P1.158: corp_bond CQS 2, maturity unknown (None) — must use 5y_plus haircut
        # £500k GBP corp bond collateral against £1m corporate loan
        # Expected collateral_haircut = 0.12 (5y_plus band, CRR), 0.20 (10y_plus, B31)
        # =============================================================================
        Collateral(
            collateral_reference="COLL_P1158_CORP_BOND_001",
            collateral_type="bond",
            currency="GBP",
            maturity_date=None,  # Unknown maturity — triggers the conservative fallback
            market_value=500_000.0,
            nominal_value=500_000.0,
            beneficiary_type="loan",
            beneficiary_reference="LOAN_P1158_CORP_001",
            issuer_cqs=2,  # CQS 2 → uses corp_bond_cqs2_3 bands
            issuer_type="corporate",  # Non-sovereign → engine classifies as corp_bond
            residual_maturity_years=None,  # The critical None that must land in 5y_plus
            is_eligible_financial_collateral=True,
            is_eligible_irb_collateral=True,
            valuation_date=VALUE_DATE,
            valuation_type="market",
            property_type=None,
            property_ltv=None,
            is_income_producing=None,
            is_adc=None,
            is_presold=None,
            liquidation_period_days=10,  # Standard 10-day liquidation period (no scaling)
        ),
    ]


def _p1_106_fcsm_institution_bond_collateral() -> list[Collateral]:
    """
    Collateral for P1.106: FCSM institution-bond CQS 2 RW divergence (B31 vs CRR).

    Scenario B31-FCSM-INST-CQS2 (primary) and CRR-FCSM-INST-CQS2 (contrastive).

    Under CRR Art. 120 Table 3: institution CQS 2 = 50%.
    Under B31 / PRA PS1/26 Art. 120 ECRA Table 3: institution CQS 2 = 30%.

    The EUR currency (vs GBP loan exposure) means the same-currency carve-out
    in Art. 222(4)/(6) does not fire — the 20% FCSM floor applies instead.

    FCSM does not reduce EAD.  Secured share = 500,000 / 1,000,000 = 0.50.

    Hand-calc (B31):   RW_blended = 0.30 × 0.50 + 1.00 × 0.50 = 0.65  → RWA = 650,000
    Hand-calc (CRR):   RW_blended = 0.50 × 0.50 + 1.00 × 0.50 = 0.75  → RWA = 750,000

    References:
        - PRA PS1/26 Art. 120 ECRA Table 3 (docs/assets/ps126app1.pdf)
        - CRR Art. 120 Table 3 (docs/assets/crr.pdf)
        - CRR Art. 222(1) — FCSM secured-portion RW substitution, 20% floor
        - Bug site: src/rwa_calc/engine/crm/simple_method.py — _derive_collateral_rw_expr()
    """
    return [
        # =====================================================================
        # COLL_INST_BOND_CQS2
        # EUR 500k institution bond, CQS 2, 5yr residual maturity.
        # Beneficiary: LOAN_FCSM_INST_CQS2 (GBP 1m).
        # pledge_percentage = 1.0 (no haircut pledge shortfall).
        # is_eligible_financial_collateral = True → routes through FCSM.
        # =====================================================================
        Collateral(
            collateral_reference="COLL_INST_BOND_CQS2",
            collateral_type="bond",
            currency="EUR",  # EUR vs GBP exposure — same-ccy carve-out does not fire
            maturity_date=date(2031, 1, 1),
            market_value=500_000.0,
            nominal_value=500_000.0,
            beneficiary_type="loan",
            beneficiary_reference="LOAN_FCSM_INST_CQS2",
            issuer_cqs=2,  # CQS 2 — divergence point: 30% (B31) vs 50% (CRR)
            issuer_type="institution",  # Triggers institution branch in _derive_collateral_rw_expr
            residual_maturity_years=5.0,  # Long enough to bypass Art. 222(7) maturity check
            is_eligible_financial_collateral=True,
            is_eligible_irb_collateral=True,
            valuation_date=VALUE_DATE,
            valuation_type="market",
            property_type=None,
            property_ltv=None,
            is_income_producing=None,
            is_adc=None,
            is_presold=None,
            liquidation_period_days=None,
        ),
    ]


def _p1_107_fcsm_corporate_bond_collateral() -> list[Collateral]:
    """
    Collateral for P1.107: FCSM corporate-bond CQS 3 RW divergence (B31 vs CRR).

    Scenario B31-FCSM-CORP-CQS3 (primary) and CRR-FCSM-CORP-CQS3 (contrastive).

    Under CRR Art. 122 Table 5: corporate CQS 3 = 100%.
    Under B31 / PRA PS1/26 Art. 122(2) Table 6: corporate CQS 3 = 75%.

    The EUR currency (vs GBP loan exposure) means the same-currency carve-out
    in Art. 222(4)/(6) does not fire. Market value equals the loan EAD, so the
    FCSM secured share = 1,000,000 / 1,000,000 = 1.0 (fully secured).

    Hand-calc (B31):  RW_collateral = 75%  → RWA = 1,000,000 × 0.75 = 750,000
    Hand-calc (CRR):  RW_collateral = 100% → RWA = 1,000,000 × 1.00 = 1,000,000

    References:
        - PRA PS1/26 Art. 122(2) Table 6 (docs/assets/ps126app1.pdf)
        - CRR Art. 122 Table 5 (docs/assets/crr.pdf)
        - CRR Art. 222(1) — FCSM secured-portion RW substitution, 20% floor
        - Bug site: src/rwa_calc/engine/crm/simple_method.py — _derive_collateral_rw_expr()
          corporate_rw branch has cqs==3 hardcoded to 1.00 (CRR) instead of 0.75 (B31)
    """
    return [
        # =====================================================================
        # COLL_P1107
        # EUR 1m corporate bond, issuer_cqs=3, 5yr residual maturity.
        # Beneficiary: LN_P1107 (GBP 1m).
        # is_eligible_financial_collateral = True → routes through FCSM.
        # Currency mismatch (EUR vs GBP) — same-currency carve-out does not fire.
        # =====================================================================
        Collateral(
            collateral_reference="COLL_P1107",
            collateral_type="bond",
            currency="EUR",  # EUR vs GBP exposure — same-ccy carve-out does not fire
            maturity_date=date(2031, 1, 1),
            market_value=1_000_000.0,
            nominal_value=1_000_000.0,
            beneficiary_type="loan",
            beneficiary_reference="LN_P1107",
            issuer_cqs=3,  # CQS 3 — divergence point: 75% (B31) vs 100% (CRR)
            issuer_type="corporate",  # Triggers corporate branch in _derive_collateral_rw_expr
            residual_maturity_years=5.0,  # Long enough to bypass Art. 222(7) maturity check
            is_eligible_financial_collateral=True,
            is_eligible_irb_collateral=True,
            valuation_date=VALUE_DATE,
            valuation_type="market",
            property_type=None,
            property_ltv=None,
            is_income_producing=None,
            is_adc=None,
            is_presold=None,
            liquidation_period_days=None,
        ),
    ]


def _crr_d15_covered_bond_collateral() -> list[Collateral]:
    """
    Collateral for CRR-D15: covered bond securing an Art. 207(2) repo-style transaction.

    Scenario: £600k covered bond (institution issuer CQS 1, 2yr residual maturity)
    posted as collateral against a £1m GBP repo cash leg (LOAN_CRM_D15) to a
    CQS 2 institution (CP_D15, borrower RW = 50% under CRR Art. 120 Table 3).

    Covered bonds are eligible financial collateral under CRR Art. 197(1)(f) / Art. 129
    when issued by a CQS 1-3 institution. They fall into the COREP "covered_bond"
    waterfall category (LGDS = 11.25%) — distinct from plain financial collateral
    (LGDS = 0%) and corporate bonds.

    Haircut reference (CRR Art. 224 Table 1 / Art. 226(2)):
    - Base 10-day haircut for institution CQS 1 bond, 1-5y band = 4% (corp_bond_cqs1_1_5y)
    - Scaled for 5-day SFT liquidation: 4% × sqrt(5/10) = 4% × 0.7071 ≈ 2.828%
    - Value after haircut = 600,000 × (1 - 0.02828) ≈ 583,030

    is_main_index=None: not applicable for bond collateral.
    qualifies_for_zero_haircut=False: institution CQS 1 covered bond does not
        qualify for the Art. 227 zero-haircut treatment (reserved for govt/central-bank
        securities and cash).
    """
    return [
        # =====================================================================
        # COLL_D15: covered_bond, institution issuer CQS 1, 2yr residual maturity.
        # Beneficiary: LOAN_CRM_D15 (GBP 1m repo cash leg).
        # liquidation_period_days=5 — Art. 224(2)(a) SFT/repo standard period.
        # =====================================================================
        Collateral(
            collateral_reference="COLL_D15",
            collateral_type="covered_bond",
            currency="GBP",
            maturity_date=date(2027, 1, 1),  # 2yr residual from VALUE_DATE 2026-01-01
            market_value=600_000.0,
            nominal_value=600_000.0,
            beneficiary_type="loan",
            beneficiary_reference="LOAN_CRM_D15",
            issuer_cqs=1,  # CQS 1 — Art. 197(1)(f): eligible financial collateral
            issuer_type="institution",  # Covered bond issuer is an institution
            residual_maturity_years=2.0,  # 2yr — lands in 1_5y maturity band
            original_maturity_years=5.0,  # Original 5yr tenor (Art. 237 ineligibility check)
            is_eligible_financial_collateral=True,
            is_eligible_irb_collateral=True,
            valuation_date=VALUE_DATE,
            valuation_type="market",
            property_type=None,
            property_ltv=None,
            is_income_producing=None,
            is_adc=None,
            is_presold=None,
            liquidation_period_days=5,  # Art. 224(2)(a): repo-style SFT — 5-day period
        ),
    ]


def save_collateral(output_dir: Path | None = None) -> Path:
    """
    Create and save collateral to parquet format.

    Args:
        output_dir: Directory to save the parquet file. Defaults to fixtures/collateral directory.

    Returns:
        Path: Path to the saved parquet file.
    """
    if output_dir is None:
        output_dir = Path(__file__).parent

    df = create_collateral()
    output_path = output_dir / "collateral.parquet"
    df.write_parquet(output_path)

    return output_path


def print_summary(output_path: Path) -> None:
    """Print generation summary."""
    df = pl.read_parquet(output_path)

    print(f"Saved collateral to: {output_path}")
    print(f"\nCreated {len(df)} collateral items:")

    print("\nBy collateral type:")
    type_counts = df.group_by("collateral_type").len().sort("len", descending=True)
    for row in type_counts.iter_rows(named=True):
        print(f"  {row['collateral_type']}: {row['len']}")

    print("\nBy beneficiary type:")
    ben_counts = df.group_by("beneficiary_type").len().sort("beneficiary_type")
    for row in ben_counts.iter_rows(named=True):
        print(f"  {row['beneficiary_type']}: {row['len']}")

    print("\nTotal market value by type:")
    value_totals = (
        df.group_by("collateral_type")
        .agg(pl.col("market_value").sum().alias("total_value"))
        .sort("collateral_type")
    )
    for row in value_totals.iter_rows(named=True):
        print(f"  {row['collateral_type']}: £{row['total_value']:,.0f}")

    print("\nEligibility summary:")
    sa_eligible = df.filter(pl.col("is_eligible_financial_collateral")).height
    irb_eligible = df.filter(pl.col("is_eligible_irb_collateral")).height
    print(f"  SA eligible (financial collateral): {sa_eligible}")
    print(f"  IRB eligible: {irb_eligible}")

    print("\nReal estate breakdown:")
    re_df = df.filter(pl.col("collateral_type") == "real_estate")
    if re_df.height > 0:
        by_property = re_df.group_by("property_type").len().sort("property_type")
        for row in by_property.iter_rows(named=True):
            print(f"  {row['property_type']}: {row['len']}")


if __name__ == "__main__":
    main()
