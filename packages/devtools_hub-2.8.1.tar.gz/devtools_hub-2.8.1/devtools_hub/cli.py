#!/usr/bin/env python3
"""DevTools Hub CLI v2.7.0 - 开发者工具集"""
import sys
import subprocess
import json
import time
import platform
import os
import hashlib
import base64
import socket
import re
import urllib.request
import urllib.error

PORT = 5001
URL = f"http://localhost:{PORT}"

def check():
    try:
        import requests
        r = requests.get(f"{URL}/api/health", timeout=1)
        return r.ok
    except:
        return False

def main():
    if len(sys.argv) < 2:
        print("""
🔧 DevTools Hub v2.7.0 - 开发者工具集

用法: devtools <命令>

系统监控:
  status     系统状态
  cpu        CPU 信息
  cpu-usage  CPU 使用率趋势
  mem        内存信息
  disk       磁盘信息
  battery    电池状态
  temp       温度监控
  uptime     运行时间
  load       系统负载

网络工具:
  ip         本机 IP
  publicip   公网 IP
  ping       Ping 测试
  dns        DNS 查询
  speed      网速测试
  wifi       WiFi 信息
  tracert    路由追踪

进程管理:
  top        高占用进程
  ps         进程列表
  kill       结束进程
  zombie     僵尸进程

文件工具:
  du         磁盘使用
  find       查找文件
  hash       计算哈希
  json       JSON 工具
  base64     Base64 编解码
  env        环境变量

开发工具:
  ports      端口扫描
  services   系统服务
  git        Git 状态
  node       Node.js 信息
  python     Python 版本

系统:
  info       系统信息
  bench      性能测试
  clean      清理缓存
  update     检查更新
  selfupdate 一键自更新
  start      启动服务
  stop       停止服务
""")
        return

    cmd = sys.argv[1]
    args = sys.argv[2:]

    # ========== 系统监控 ==========
    if cmd == "status":
        if check():
            import requests
            r = requests.get(f"{URL}/api/health")
            print(json.dumps(r.json(), indent=2))
        else:
            print("❌ 服务未运行，请先 devtools start")

    elif cmd == "cpu":
        import psutil
        print(f"CPU: {psutil.cpu_percent()}%  核心: {psutil.cpu_count()}  物理核心: {psutil.cpu_count(logical=False)}")

    elif cmd == "cpu-usage":
        import psutil
        print("📊 CPU 使用率（5秒采样）...")
        for i in range(5):
            print(f"  {psutil.cpu_percent(interval=1)}%", end=" ", flush=True)
        print()

    elif cmd == "mem":
        import psutil
        m = psutil.virtual_memory()
        print(f"内存: {m.percent}%  已用: {m.used/1024**3:.1f}GB  可用: {m.available/1024**3:.1f}GB  总计: {m.total/1024**3:.1f}GB")
        # Swap
        s = psutil.swap_memory()
        print(f"Swap: {s.percent}%  已用: {s.used/1024**3:.1f}GB")

    elif cmd == "disk":
        import psutil
        for p in [('/', '/System/Volumes/Data', '/Users')]:
            try:
                d = psutil.disk_usage(p)
                print(f"{p}: {d.percent}%  已用: {d.used/1024**3:.1f}GB  可用: {d.free/1024**3:.1f}GB")
            except:
                pass

    elif cmd == "battery":
        import psutil
        try:
            b = psutil.sensors_battery()
            if b:
                print(f"电池: {b.percent}% {'🔌 充电中' if b.power_plugged else '🔋 使用电池'}")
                if b.secsleft and b.secsleft > 0:
                    h = b.secsleft // 3600
                    m = (b.secsleft % 3600) // 60
                    print(f"剩余时间: {h}h {m}m")
            else:
                print("❌ 无电池（台式机）")
        except:
            print("❌ 电池信息不可用")

    elif cmd == "temp":
        import psutil
        temps = getattr(psutil, 'sensors_temperatures', lambda: {})()
        if temps:
            for name, entries in temps.items():
                for entry in entries:
                    label = entry.label or name
                    current = entry.current
                    high = entry.high or "N/A"
                    print(f"🌡️ {label}: {current:.1f}°C  最高: {high}°C")
        else:
            print("❌ 温度信息不可用（虚拟机或权限不足）")

    elif cmd == "uptime":
        import psutil
        boot = psutil.boot_time()
        import datetime
        now = datetime.datetime.now()
        boot_time = datetime.datetime.fromtimestamp(boot)
        delta = now - boot_time
        print(f"系统运行: {delta.days}天 {delta.seconds//3600}小时 {(delta.seconds%3600)//60}分钟")
        print(f"启动时间: {boot_time.strftime('%Y-%m-%d %H:%M:%S')}")

    elif cmd == "load":
        import os
        load = os.getloadavg() if hasattr(os, 'getloadavg') else (0, 0, 0)
        print(f"负载: {load[0]:.2f} {load[1]:.2f} {load[2]:.2f} (1/5/15分钟)")

    # ========== 网络工具 ==========
    elif cmd == "ip":
        try:
            hostname = socket.gethostname()
            ip = socket.gethostbyname(hostname)
            print(f"主机: {hostname}")
            print(f"IP: {ip}")
        except:
            print(f"IP: {socket.gethostbyname(socket.gethostname())}")

    elif cmd == "publicip":
        try:
            ip = urllib.request.urlopen('https://api.ipify.org', timeout=5).read().decode()
            print(f"🌐 公网IP: {ip}")
            # 获取位置
            try:
                data = urllib.request.urlopen(f'https://ipapi.co/{ip}/json/', timeout=5).read().decode()
                loc = json.loads(data)
                print(f"📍 位置: {loc.get('city', '')}, {loc.get('country_name', '')}")
                print(f"🏢 运营商: {loc.get('org', '')}")
            except:
                pass
        except Exception as e:
            print(f"❌ 获取失败: {e}")

    elif cmd == "ping":
        if not args:
            args = ['8.8.8.8']
        host = args[0]
        print(f"📡 Ping {host}...")
        result = subprocess.run(['ping', '-c', '4', host], capture_output=True, text=True)
        lines = result.stdout.split('\n')
        for line in lines[-5:]:
            if line.strip():
                print(line)
        if result.returncode != 0:
            print("❌ Ping 失败")

    elif cmd == "dns":
        if not args:
            print("用法: devtools dns <域名>")
            return
        domain = args[0]
        print(f"🔍 DNS 查询: {domain}")
        try:
            import socket as sock
            ip = sock.gethostbyname(domain)
            print(f"✅ 解析: {ip}")
        except Exception as e:
            print(f"❌ 解析失败: {e}")

    elif cmd == "speed":
        print("📊 测速中（下载测试）...")
        try:
            start = time.time()
            urllib.request.urlopen('https://speed.cloudflare.com/__down?bytes=10000000', timeout=30)
            elapsed = time.time() - start
            speed = 10 / elapsed  # MB/s
            print(f"⚡ 网速: {speed:.1f} MB/s ({(speed*8):.1f} Mbps)")
        except Exception as e:
            print(f"❌ 测速失败: {e}")

    elif cmd == "wifi":
        try:
            result = subprocess.run(['networksetup', '-listallhardwareports'], capture_output=True, text=True)
            print(result.stdout)
        except:
            print("❌ WiFi 信息不可用")

    elif cmd == "tracert":
        if not args:
            args = ['8.8.8.8']
        host = args[0]
        print(f"🛤️ 路由追踪: {host}")
        result = subprocess.run(['traceroute', '-m', '15', host], capture_output=True, text=True)
        print(result.stdout[:2000])

    # ========== 进程管理 ==========
    elif cmd == "top":
        import psutil
        procs = []
        for p in psutil.process_iter(['pid', 'name', 'cpu_percent', 'memory_percent', 'username']):
            try:
                procs.append(p.info)
            except:
                pass
        by_cpu = sorted(procs, key=lambda x: x['cpu_percent'] or 0, reverse=True)[:8]
        by_mem = sorted(procs, key=lambda x: x['memory_percent'] or 0, reverse=True)[:5]
        print("🔥 CPU 高占用:")
        for p in by_cpu:
            print(f"  PID {p['pid']:>6} | {p['name'][:25]:<25} | {p['cpu_percent']:>5}% | {p.get('username', '')[:15]}")
        print("\n💾 内存高占用:")
        for p in by_mem:
            print(f"  PID {p['pid']:>6} | {p['name'][:25]:<25} | {p['memory_percent']:>5}%")

    elif cmd == "ps":
        import psutil
        procs = []
        for p in psutil.process_iter(['pid', 'name', 'status', 'cpu_percent']):
            try:
                procs.append(p.info)
            except:
                pass
        print(f"📋 总进程数: {len(procs)}")
        running = sum(1 for p in procs if p.get('status') == 'running')
        sleeping = sum(1 for p in procs if p.get('status') == 'sleeping')
        print(f"   运行中: {running}  睡眠中: {sleeping}")

    elif cmd == "kill":
        if not args:
            print("用法: devtools kill <进程名或PID>")
            return
        target = args[0]
        try:
            pid = int(target)
            p = psutil.Process(pid)
            name = p.name()
            p.kill()
            print(f"✅ 已结束进程: {name} (PID: {pid})")
        except ValueError:
            # 按名称结束
            killed = 0
            for p in psutil.process_iter(['pid', 'name']):
                try:
                    if target.lower() in p.info['name'].lower():
                        p.kill()
                        killed += 1
                except:
                    pass
            print(f"✅ 已结束 {killed} 个进程: {target}")
        except Exception as e:
            print(f"❌ 结束进程失败: {e}")

    elif cmd == "zombie":
        import psutil
        zombies = []
        for p in psutil.process_iter(['pid', 'name', 'status']):
            try:
                if p.info['status'] == 'zombie':
                    zombies.append(p.info)
            except:
                pass
        if zombies:
            print(f"🧟 僵尸进程 ({len(zombies)}):")
            for z in zombies:
                print(f"  PID {z['pid']}: {z['name']}")
        else:
            print("✅ 无僵尸进程")

    # ========== 文件工具 ==========
    elif cmd == "du":
        if not args:
            path = os.path.expanduser('~')
        else:
            path = args[0]
        print(f"📁 磁盘使用: {path}")
        import subprocess
        result = subprocess.run(['du', '-sh', path], capture_output=True, text=True)
        print(result.stdout.strip())

    elif cmd == "find":
        print("🔍 查找大文件...")
        import psutil
        import os
        home = os.path.expanduser('~')
        files = []
        for root, dirs, filenames in os.walk(home):
            # 跳过隐藏目录
            dirs[:] = [d for d in dirs if not d.startswith('.')]
            for f in filenames:
                fp = os.path.join(root, f)
                try:
                    size = os.path.getsize(fp)
                    if size > 100 * 1024 * 1024:  # > 100MB
                        files.append((size, fp))
                except:
                    pass
        files.sort(reverse=True)
        print(f"找到 {len(files)} 个大文件 (>100MB):")
        for size, fp in files[:20]:
            print(f"  {size/1024**3:.2f}GB {fp[:80]}")

    elif cmd == "hash":
        if not args:
            print("用法: devtools hash <文件路径>")
            return
        filepath = os.path.expanduser(args[0])
        if not os.path.exists(filepath):
            print(f"❌ 文件不存在: {filepath}")
            return
        print(f"🔐 计算哈希: {filepath}")
        with open(filepath, 'rb') as f:
            md5 = hashlib.md5(f.read()).hexdigest()
        with open(filepath, 'rb') as f:
            sha1 = hashlib.sha1(f.read()).hexdigest()
        with open(filepath, 'rb') as f:
            sha256 = hashlib.sha256(f.read()).hexdigest()
        print(f"MD5:    {md5}")
        print(f"SHA1:   {sha1}")
        print(f"SHA256: {sha256}")

    elif cmd == "json":
        if not args:
            print("用法: devtools json <JSON字符串或文件路径>")
            return
        text = args[0]
        import os
        if os.path.exists(os.path.expanduser(text)):
            with open(os.path.expanduser(text)) as f:
                text = f.read()
        try:
            obj = json.loads(text)
            print(json.dumps(obj, indent=2, ensure_ascii=False))
        except json.JSONDecodeError as e:
            print(f"❌ JSON 解析错误: {e}")

    elif cmd == "base64":
        if len(args) < 2:
            print("用法: devtools base64 <encode|decode> <文本或文件路径>")
            return
        mode = args[0]
        text = args[1]
        import os
        if os.path.exists(os.path.expanduser(text)):
            with open(os.path.expanduser(text), 'rb') as f:
                text = f.read()
                if mode == 'encode':
                    print(base64.b64encode(text).decode())
                elif mode == 'decode':
                    print(base64.b64decode(text).decode(errors='ignore'))
        else:
            text = text.encode()
            if mode == 'encode':
                print(base64.b64encode(text).decode())
            elif mode == 'decode':
                try:
                    print(base64.b64decode(text).decode(errors='ignore'))
                except:
                    print("❌ 解码失败")

    elif cmd == "env":
        if args:
            key = args[0]
            print(f"{key}={os.environ.get(key, '❌ 未设置')}")
        else:
            print("🔧 环境变量:")
            for k, v in sorted(os.environ.items()):
                if args and args[0].lower() in k.lower():
                    print(f"  {k}={v}")

    # ========== 开发工具 ==========
    elif cmd == "ports":
        from devtools_hub.scanner import scan_common_ports
        print("🔍 扫描常用端口...")
        ports = scan_common_ports()
        if ports:
            for p in ports:
                print(f"  ✅ {p['port']} ({p['name']}) - 开放")
        else:
            print("  未发现开放端口")

    elif cmd == "services":
        from devtools_hub.scanner import get_services
        print("📋 系统服务:")
        services = get_services()
        for s in services[:20]:
            pid_str = str(s['pid']) if s['pid'] else '-'
            print(f"  [{pid_str:>6}] {s['name']}")

    elif cmd == "git":
        try:
            result = subprocess.run(['git', 'status'], capture_output=True, text=True, cwd=os.path.dirname(os.path.dirname(__file__)))
            print(result.stdout)
            if result.returncode != 0:
                print(result.stderr)
        except FileNotFoundError:
            print("❌ Git 未安装")

    elif cmd == "node":
        try:
            v = subprocess.run(['node', '--version'], capture_output=True, text=True)
            npm = subprocess.run(['npm', '--version'], capture_output=True, text=True)
            print(f"Node.js: {v.stdout.strip()}")
            print(f"npm: {npm.stdout.strip()}")
        except FileNotFoundError:
            print("❌ Node.js 未安装")

    elif cmd == "python":
        v = sys.version_info
        print(f"Python: {v.major}.{v.minor}.{v.micro}")
        try:
            import pip
            print(f"pip: {pip.__version__}")
        except:
            pass

    # ========== 系统 ==========
    elif cmd == "info":
        print(f"""
🖥️  系统信息:
  系统: {platform.system()} {platform.release()} {platform.machine()}
  主机: {platform.node()}
  处理器: {platform.processor()}
  Python: {platform.python_version()}
  macOS: {platform.mac_ver()[0]}
""")

    elif cmd == "bench":
        if check():
            import requests
            r = requests.get(f"{URL}/api/benchmark/full")
            print(json.dumps(r.json(), indent=2))
        else:
            print("❌ 服务未运行，请先 devtools start")
            print("💡 或直接运行: devtools cpu")

    elif cmd == "clean":
        print("🧹 清理缓存...")
        dirs = [
            '~/Library/Caches/com.apple.nsurlsessiond',
            '~/.cache',
        ]
        cleaned = 0
        for d in dirs:
            path = os.path.expanduser(d)
            if os.path.exists(path):
                size = sum(os.path.getsize(os.path.join(r, f)) for r, _, fs in os.walk(path) for f in fs)
                cleaned += size
                print(f"  清理: {d} ({size/1024**2:.1f}MB)")
        print(f"✅ 可释放: {cleaned/1024**2:.1f}MB（手动清理更彻底）")
        print("💡 提示: 使用 'sudo periodic daily weekly monthly' 清理系统缓存")

    elif cmd == "update":
        print("🔄 检查更新...")
        import importlib.metadata as metadata
        try:
            current_version = metadata.version('devtools-hub')
        except:
            current_version = '2.8.1'
        try:
            import urllib.request
            req = urllib.request.urlopen('https://pypi.org/pypi/devtools-hub/json', timeout=5)
            data = json.loads(req.read())
            latest_version = data['info']['version']
            print(f"当前版本: {current_version}")
            print(f"PyPI 最新版本: {latest_version}")
            if latest_version != current_version:
                print(f"📦 发现新版本 {latest_version}，正在更新...")
                # 执行更新
                import os
                pip_cmd = [sys.executable, '-m', 'pip', 'install', '--upgrade', 'devtools-hub']
                result = os.system(' '.join(pip_cmd))
                if result == 0:
                    print("✅ 更新成功！")
                    print("💡 运行 'source ~/.zshrc' 使 PATH 生效")
                else:
                    print(f"❌ 更新失败")
            else:
                print("✅ 已是最新版本")
        except Exception as e:
            print(f"❌ 检查失败: {e}")

    elif cmd == "selfupdate":
        """自更新命令 - 一键更新自身"""
        print("🔄 正在自更新 devtools-hub...")
        try:
            # 使用 pip 更新
            result = subprocess.run([sys.executable, '-m', 'pip', 'install', '--upgrade', '--force-reinstall', 'devtools-hub'],
                                  capture_output=True, text=True)
            if result.returncode == 0:
                print("✅ 自更新成功！")
                print("💡 运行 'source ~/.zshrc' 使 PATH 生效")
            else:
                print(f"❌ 自更新失败:")
                print(result.stderr)
        except Exception as e:
            print(f"❌ 自更新异常: {e}")

    elif cmd == "start":
        print("🚀 启动服务...")
        subprocess.Popen([sys.executable, "-m", "devtools_hub.server"],
                        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        time.sleep(2)
        print(f"✅ 已启动: {URL}")

    elif cmd == "stop":
        subprocess.run(["pkill", "-f", "devtools_hub.server"])
        print("✅ 已停止")

    else:
        print(f"❌ 未知命令: {cmd}")

if __name__ == "__main__":
    main()
