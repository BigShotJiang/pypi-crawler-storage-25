"""Shared provider-hidden list-build contract for API capabilities, CLI recipes, and docs."""

from __future__ import annotations

from copy import deepcopy
from typing import Any, Dict, Tuple


LIST_BUILD_SCOPE = "search:run"

_LIST_BUILD_ENDPOINTS: Dict[str, Dict[str, Any]] = {
    "list_build_create": {
        "method": "POST",
        "path": "/api/list-builds",
        "required_scope": LIST_BUILD_SCOPE,
        "body": {
            "kind": "required companies|leads",
            "list_name": "optional display name",
            "keywords": "company keywords or optional lead keywords",
            "title": "optional lead title/persona query",
            "num_results": "optional 1-10000 target result count",
            "page_size": "optional provider page size; leads capped to 50",
            "filters": {
                "geo_ids": "optional geography IDs, comma-separated string or string[]",
                "industry_ids": "optional industry IDs, comma-separated string or string[]",
                "company_sizes": "optional company size buckets: 1-10, 11-50, 51-200, 201-500, 501-1000, 1001-5000, 5001-10,000, 10,001+",
                "has_jobs": "optional boolean for company lists",
                "current_company_ids": "optional company IDs returned by company list builds; used for lead lists",
                "profile_language": "optional language code such as en",
            },
        },
        "notes": "Provider-hidden durable list build. Does not require a user-owned professional-network connection.",
    },
    "list_build_status": {
        "method": "GET",
        "path": "/api/list-builds/{job_id}",
        "required_scope": LIST_BUILD_SCOPE,
    },
    "list_build_results": {
        "method": "GET",
        "path": "/api/list-builds/{job_id}/results",
        "required_scope": LIST_BUILD_SCOPE,
        "query": {"type": "optional items|companies|leads|all", "page": "optional page number", "page_size": "optional 1-500"},
    },
    "list_build_cancel": {
        "method": "DELETE",
        "path": "/api/list-builds/{job_id}",
        "required_scope": LIST_BUILD_SCOPE,
    },
    "list_build_pricing": {
        "method": "GET",
        "path": "/api/list-builds/pricing",
        "required_scope": LIST_BUILD_SCOPE,
        "notes": "Returns current page-based list-build pricing.",
    },
    "list_build_inputs": {
        "method": "GET",
        "path": "/api/list-builds/inputs",
        "required_scope": LIST_BUILD_SCOPE,
        "notes": "Returns documented input IDs and filter values for company and lead list builds.",
    },
}

_LIST_BUILD_CAPABILITIES: Dict[str, Any] = {
    "surface_type": "provider_hidden_durable_list_build",
    "connection_required": False,
    "requires_connected_account": False,
    "recommended_scope": LIST_BUILD_SCOPE,
    "public_modes": ["companies", "leads"],
    "known_input_ids": {
        "geo_ids": {"United States": "103644278"},
        "company_size_buckets": ["1-10", "11-50", "51-200", "201-500", "501-1000", "1001-5000", "5001-10,000", "10,001+"],
        "profile_language_examples": ["en"],
    },
    "workflow": [
        "Build companies first when the account universe is unknown.",
        "Use returned company IDs as current_company_ids for targeted lead lists.",
        "Run separate focused jobs for different markets, company sizes, or personas.",
    ],
    "pricing": {
        "charge_on": "successful_non_empty_result_page",
        "companies": "1 credit per successful company page, up to 100 companies",
        "leads": "1 credit per successful lead page, up to 50 leads",
    },
    "recommended_cli": [
        "autotouch list-build companies --keywords 'software' --geo-id 103644278 --company-size 1-10 --num-results 1000 --wait",
        "autotouch list-build leads --title 'Account Executive OR SDR' --current-company-id <company_id> --profile-language en --num-results 500 --wait",
        "autotouch list-build status --job-id <job_id>",
        "autotouch list-build results --job-id <job_id> --type companies",
    ],
}

_LIST_BUILD_RECIPES: Dict[str, Dict[str, Any]] = {
    "companies": {
        "payload": {
            "kind": "companies",
            "keywords": "software",
            "num_results": 1000,
            "filters": {"geo_ids": ["103644278"], "company_sizes": ["1-10"], "has_jobs": True},
        },
        "usage": "autotouch list-build companies --data-file <payload.json> --wait",
    },
    "leads": {
        "payload": {
            "kind": "leads",
            "title": "Account Executive OR SDR OR BDR",
            "num_results": 500,
            "filters": {"current_company_ids": ["<company_id>"], "geo_ids": ["103644278"], "profile_language": "en"},
        },
        "usage": "autotouch list-build leads --data-file <payload.json> --wait",
    },
}


def list_build_endpoint_entries() -> Dict[str, Dict[str, Any]]:
    return deepcopy(_LIST_BUILD_ENDPOINTS)


def list_build_capabilities_contract() -> Dict[str, Any]:
    return deepcopy(_LIST_BUILD_CAPABILITIES)


def list_build_recipe_types() -> Tuple[str, ...]:
    return tuple(_LIST_BUILD_RECIPES.keys())


def list_build_recipe_entries() -> Dict[str, Dict[str, Any]]:
    return deepcopy(_LIST_BUILD_RECIPES)


__all__ = [
    "LIST_BUILD_SCOPE",
    "list_build_capabilities_contract",
    "list_build_endpoint_entries",
    "list_build_recipe_entries",
    "list_build_recipe_types",
]
