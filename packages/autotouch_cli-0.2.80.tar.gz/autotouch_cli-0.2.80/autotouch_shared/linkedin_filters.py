"""LinkedIn/Sales Navigator search filter catalog.

The catalog is intentionally first-party and normalized for agents/CLI users.
It mirrors the public Unipile search schema at a stable abstraction layer so
clients do not need to scrape vendor docs or guess provider field names.
"""

from __future__ import annotations

from copy import deepcopy
from typing import Any, Dict, Iterable, List, Optional


HEADCOUNT_BUCKETS: List[Dict[str, Any]] = [
    {"label": "1", "min": 1, "max": 1},
    {"label": "1-10", "min": 1, "max": 10},
    {"label": "11-50", "min": 11, "max": 50},
    {"label": "51-200", "min": 51, "max": 200},
    {"label": "201-500", "min": 201, "max": 500},
    {"label": "501-1000", "min": 501, "max": 1000},
    {"label": "1001-5000", "min": 1001, "max": 5000},
    {"label": "5001-10000", "min": 5001, "max": 10000},
    {"label": "10001+", "min": 10001, "max": None},
]

TENURE_BUCKETS: List[Dict[str, Any]] = [
    {"label": "0-1", "min": 0, "max": 1},
    {"label": "1-2", "min": 1, "max": 2},
    {"label": "3-5", "min": 3, "max": 5},
    {"label": "6-10", "min": 6, "max": 10},
    {"label": "10+", "min": 10, "max": None},
]

SENIORITY_VALUES = [
    "owner/partner",
    "cxo",
    "vice_president",
    "director",
    "experienced_manager",
    "entry_level_manager",
    "strategic",
    "senior",
    "entry_level",
    "in_training",
]

COMPANY_TYPE_VALUES = [
    "public_company",
    "privately_held",
    "non_profit",
    "educational_institution",
    "partnership",
    "self_employed",
    "self_owned",
    "government_agency",
]


def _entry(
    field: str,
    *,
    label: str,
    provider_field: str,
    api_modes: Iterable[str],
    categories: Iterable[str],
    value_kind: str,
    shape: str,
    resolver_type: Optional[str] = None,
    supports_include_exclude: bool = False,
    values: Optional[List[Any]] = None,
    examples: Optional[List[Any]] = None,
    notes: Optional[List[str]] = None,
    aliases: Optional[List[str]] = None,
) -> Dict[str, Any]:
    payload: Dict[str, Any] = {
        "field": field,
        "label": label,
        "provider_field": provider_field,
        "api_modes": list(api_modes),
        "categories": list(categories),
        "value_kind": value_kind,
        "shape": shape,
        "supports_include_exclude": bool(supports_include_exclude),
    }
    if resolver_type:
        payload["resolver_type"] = resolver_type
    if values:
        payload["values"] = deepcopy(values)
    if examples:
        payload["examples"] = deepcopy(examples)
    if notes:
        payload["notes"] = list(notes)
    if aliases:
        payload["aliases"] = list(aliases)
    return payload


_FILTERS: List[Dict[str, Any]] = [
    _entry(
        "keywords",
        label="Keywords",
        provider_field="keywords",
        api_modes=["classic", "sales_navigator"],
        categories=["people", "companies", "jobs", "posts"],
        value_kind="string",
        shape="string",
        examples=["sales development", "developer OR engineer"],
        notes=["Boolean modifiers are provider-dependent; prefer URL replay for exact browser parity."],
    ),
    _entry(
        "url",
        label="LinkedIn search URL",
        provider_field="url",
        api_modes=["classic", "sales_navigator"],
        categories=["people", "companies", "jobs", "posts"],
        value_kind="url",
        shape="string",
        examples=["https://www.linkedin.com/sales/search/people?query=..."],
        notes=["URL mode overrides structured keyword/filter parameters."],
    ),
    _entry(
        "location",
        label="Location",
        provider_field="location",
        api_modes=["classic"],
        categories=["people", "companies", "jobs"],
        value_kind="id",
        resolver_type="LOCATION",
        shape='["102277331"]',
        examples=[["102277331"]],
    ),
    _entry(
        "location",
        label="Geography / headquarters location",
        provider_field="location",
        api_modes=["sales_navigator"],
        categories=["people", "companies"],
        value_kind="id",
        resolver_type="REGION",
        supports_include_exclude=True,
        shape='{"include":["103644278"],"exclude":["102448103"]}',
        examples=[{"include": ["103644278"]}],
    ),
    _entry(
        "location_by_postal_code",
        label="Postal-code radius",
        provider_field="location_by_postal_code",
        api_modes=["sales_navigator"],
        categories=["people", "companies"],
        value_kind="id",
        resolver_type="POSTAL_CODE",
        supports_include_exclude=True,
        shape='{"include":["90001"],"within_area":25}',
    ),
    _entry(
        "industry",
        label="Industry",
        provider_field="industry",
        api_modes=["classic"],
        categories=["people", "companies", "jobs"],
        value_kind="id",
        resolver_type="INDUSTRY",
        shape='["4"]',
        examples=[["4"]],
    ),
    _entry(
        "industry",
        label="Sales Navigator industry",
        provider_field="industry",
        api_modes=["sales_navigator"],
        categories=["people", "companies"],
        value_kind="id",
        resolver_type="SALES_INDUSTRY",
        supports_include_exclude=True,
        shape='{"include":["6"],"exclude":[]}',
        examples=[{"include": ["6"]}],
    ),
    _entry(
        "headcount",
        label="Company headcount",
        provider_field="headcount",
        api_modes=["classic", "sales_navigator"],
        categories=["companies"],
        value_kind="range_bucket",
        shape='[{"min":1,"max":10}]',
        values=HEADCOUNT_BUCKETS,
        examples=[[{"min": 1, "max": 10}]],
        aliases=["company_size", "employee_count"],
    ),
    _entry(
        "company_headcount",
        label="Current company headcount",
        provider_field="company_headcount",
        api_modes=["sales_navigator"],
        categories=["people"],
        value_kind="range_bucket",
        shape='[{"min":1,"max":10}]',
        values=HEADCOUNT_BUCKETS,
        examples=[[{"min": 1, "max": 10}]],
        aliases=["company_size", "employee_count"],
    ),
    _entry(
        "headcount_growth",
        label="Company headcount growth",
        provider_field="headcount_growth",
        api_modes=["sales_navigator"],
        categories=["companies"],
        value_kind="numeric_range",
        shape='{"min":10,"max":100}',
        examples=[{"min": 10}],
    ),
    _entry(
        "department_headcount",
        label="Department headcount",
        provider_field="department_headcount",
        api_modes=["sales_navigator"],
        categories=["companies"],
        value_kind="object",
        resolver_type="DEPARTMENT",
        shape='{"department":["3"],"min":1,"max":10}',
    ),
    _entry(
        "department_headcount_growth",
        label="Department headcount growth",
        provider_field="department_headcount_growth",
        api_modes=["sales_navigator"],
        categories=["companies"],
        value_kind="object",
        resolver_type="DEPARTMENT",
        shape='{"department":["3"],"min":10,"max":100}',
    ),
    _entry(
        "company",
        label="Current company",
        provider_field="company",
        api_modes=["classic"],
        categories=["people"],
        value_kind="id",
        resolver_type="COMPANY",
        shape='["1441"]',
        examples=[["1441"]],
    ),
    _entry(
        "company",
        label="Current company",
        provider_field="company",
        api_modes=["sales_navigator"],
        categories=["people"],
        value_kind="id_or_text",
        resolver_type="COMPANY",
        supports_include_exclude=True,
        shape='{"include":["1441"],"exclude":["1035"]}',
        examples=[{"include": ["1441"], "exclude": ["1035"]}],
        notes=["Sales Navigator also accepts plain company names for this field."],
    ),
    _entry(
        "company_location",
        label="Company headquarters location",
        provider_field="company_location",
        api_modes=["sales_navigator"],
        categories=["people"],
        value_kind="id",
        resolver_type="REGION",
        supports_include_exclude=True,
        shape='{"include":["103644278"]}',
    ),
    _entry(
        "company_type",
        label="Company type",
        provider_field="company_type",
        api_modes=["sales_navigator"],
        categories=["people"],
        value_kind="enum",
        shape='["privately_held"]',
        values=COMPANY_TYPE_VALUES,
    ),
    _entry(
        "role",
        label="Current job title",
        provider_field="role",
        api_modes=["sales_navigator"],
        categories=["people"],
        value_kind="id",
        resolver_type="JOB_TITLE",
        supports_include_exclude=True,
        shape='{"include":["1234"],"exclude":["5678"]}',
        examples=[{"include": ["1234"], "exclude": ["5678"]}],
        aliases=["job_title", "title"],
        notes=["Resolve human title text with /linkedin/search/parameters before using this structured filter."],
    ),
    _entry(
        "past_role",
        label="Past job title",
        provider_field="past_role",
        api_modes=["sales_navigator"],
        categories=["people"],
        value_kind="id",
        resolver_type="JOB_TITLE",
        supports_include_exclude=True,
        shape='{"include":["1234"],"exclude":[]}',
    ),
    _entry(
        "function",
        label="Function / department",
        provider_field="function",
        api_modes=["sales_navigator"],
        categories=["people"],
        value_kind="id",
        resolver_type="DEPARTMENT",
        supports_include_exclude=True,
        shape='{"include":["25"],"exclude":[]}',
        aliases=["department", "job_function"],
    ),
    _entry(
        "seniority",
        label="Seniority",
        provider_field="seniority",
        api_modes=["sales_navigator"],
        categories=["people"],
        value_kind="enum",
        supports_include_exclude=True,
        shape='{"include":["entry_level"],"exclude":["owner/partner","cxo"]}',
        values=SENIORITY_VALUES,
    ),
    _entry(
        "tenure",
        label="Years of experience",
        provider_field="tenure",
        api_modes=["sales_navigator"],
        categories=["people"],
        value_kind="range_bucket",
        shape='[{"min":3,"max":5}]',
        values=TENURE_BUCKETS,
    ),
    _entry(
        "tenure_at_company",
        label="Years at current company",
        provider_field="tenure_at_company",
        api_modes=["sales_navigator"],
        categories=["people"],
        value_kind="range_bucket",
        shape='[{"min":1,"max":2}]',
        values=TENURE_BUCKETS,
    ),
    _entry(
        "tenure_at_role",
        label="Years in current position",
        provider_field="tenure_at_role",
        api_modes=["sales_navigator"],
        categories=["people"],
        value_kind="range_bucket",
        shape='[{"min":0,"max":1}]',
        values=TENURE_BUCKETS,
    ),
    _entry(
        "school",
        label="School",
        provider_field="school",
        api_modes=["classic", "sales_navigator"],
        categories=["people"],
        value_kind="id",
        resolver_type="SCHOOL",
        supports_include_exclude=True,
        shape='{"include":["17926"],"exclude":[]}',
    ),
    _entry(
        "profile_language",
        label="Profile language",
        provider_field="profile_language",
        api_modes=["classic", "sales_navigator"],
        categories=["people"],
        value_kind="iso_639_1",
        shape='["en"]',
        examples=[["en"]],
    ),
    _entry(
        "network_distance",
        label="Network relationship",
        provider_field="network_distance",
        api_modes=["classic", "sales_navigator"],
        categories=["people", "companies"],
        value_kind="enum",
        shape="[1,2,3]",
        values=[1, 2, 3, "GROUP"],
        notes=["GROUP is Sales Navigator people-only."],
    ),
    _entry(
        "groups",
        label="LinkedIn groups",
        provider_field="groups",
        api_modes=["sales_navigator"],
        categories=["people"],
        value_kind="id",
        resolver_type="GROUPS",
        shape='["123456"]',
    ),
    _entry(
        "connections_of",
        label="Connections of",
        provider_field="connections_of",
        api_modes=["sales_navigator"],
        categories=["people"],
        value_kind="id",
        resolver_type="PEOPLE",
        shape='["ACw..."]',
    ),
    _entry(
        "persona",
        label="Persona",
        provider_field="persona",
        api_modes=["sales_navigator"],
        categories=["people"],
        value_kind="id",
        resolver_type="PERSONA",
        shape='["123"]',
    ),
    _entry(
        "account_lists",
        label="Account lists",
        provider_field="account_lists",
        api_modes=["sales_navigator"],
        categories=["people", "companies"],
        value_kind="id",
        resolver_type="ACCOUNT_LISTS",
        supports_include_exclude=True,
        shape='{"include":["ALL"],"exclude":[]}',
    ),
    _entry(
        "lead_lists",
        label="Lead lists",
        provider_field="lead_lists",
        api_modes=["sales_navigator"],
        categories=["people"],
        value_kind="id",
        resolver_type="LEAD_LISTS",
        supports_include_exclude=True,
        shape='{"include":["ALL"],"exclude":[]}',
    ),
    _entry(
        "saved_search_id",
        label="Saved search",
        provider_field="saved_search_id",
        api_modes=["sales_navigator"],
        categories=["people", "companies"],
        value_kind="id",
        resolver_type="SAVED_SEARCHES",
        shape='"123456"',
        notes=["Overrides other structured search parameters."],
    ),
    _entry(
        "recent_search_id",
        label="Recent search",
        provider_field="recent_search_id",
        api_modes=["sales_navigator"],
        categories=["people", "companies"],
        value_kind="id",
        resolver_type="RECENT_SEARCHES",
        shape='"123456"',
        notes=["Overrides other structured search parameters."],
    ),
    _entry(
        "has_job_offers",
        label="Hiring on LinkedIn",
        provider_field="has_job_offers",
        api_modes=["classic", "sales_navigator"],
        categories=["companies"],
        value_kind="boolean",
        shape="true",
    ),
    _entry(
        "annual_revenue",
        label="Annual revenue",
        provider_field="annual_revenue",
        api_modes=["sales_navigator"],
        categories=["companies"],
        value_kind="object",
        shape='{"currency":"USD","min":1,"max":10}',
    ),
    _entry(
        "followers_count",
        label="Number of followers",
        provider_field="followers_count",
        api_modes=["sales_navigator"],
        categories=["companies"],
        value_kind="range_bucket",
        shape='[{"min":51,"max":100}]',
    ),
    _entry(
        "fortune",
        label="Fortune rank",
        provider_field="fortune",
        api_modes=["sales_navigator"],
        categories=["companies"],
        value_kind="range_bucket",
        shape='[{"min":0,"max":50}]',
    ),
    _entry(
        "technologies",
        label="Technologies used",
        provider_field="technologies",
        api_modes=["sales_navigator"],
        categories=["companies"],
        value_kind="id",
        resolver_type="TECHNOLOGIES",
        shape='["123"]',
    ),
    _entry(
        "recent_activities",
        label="Recent company activities",
        provider_field="recent_activities",
        api_modes=["sales_navigator"],
        categories=["companies"],
        value_kind="enum",
        shape='["funding_events"]',
        values=["senior_leadership_changes", "funding_events"],
    ),
    _entry(
        "sort_by",
        label="Post/job sort",
        provider_field="sort_by",
        api_modes=["classic"],
        categories=["posts", "jobs"],
        value_kind="enum",
        shape='"date"',
        values=["relevance", "date"],
    ),
    _entry(
        "date_posted",
        label="Post/job date posted",
        provider_field="date_posted",
        api_modes=["classic"],
        categories=["posts", "jobs"],
        value_kind="enum_or_number",
        shape='"past_week"',
        values=["past_24h", "past_week", "past_month"],
    ),
    _entry(
        "content_type",
        label="Post content type",
        provider_field="content_type",
        api_modes=["classic"],
        categories=["posts"],
        value_kind="enum",
        shape='"images"',
        values=["images", "videos", "documents", "live_videos", "collaborative_articles"],
    ),
    _entry(
        "author",
        label="Post author filters",
        provider_field="author",
        api_modes=["classic"],
        categories=["posts"],
        value_kind="object",
        shape='{"keywords":"CEO","industry":["6"],"company":["1441"]}',
        notes=["Nested author fields can use keywords plus industry/company parameter IDs."],
    ),
]

_PARAMETER_TYPES: List[Dict[str, Any]] = [
    {
        "type": "LOCATION",
        "services": ["CLASSIC", "RECRUITER", "SALES_NAVIGATOR"],
        "description": "General location IDs.",
    },
    {"type": "PEOPLE", "services": ["CLASSIC", "SALES_NAVIGATOR"], "description": "LinkedIn people/member IDs."},
    {"type": "CONNECTIONS", "services": ["CLASSIC"], "description": "Classic connection filters."},
    {"type": "COMPANY", "services": ["CLASSIC", "SALES_NAVIGATOR"], "description": "Company IDs."},
    {"type": "SCHOOL", "services": ["CLASSIC", "SALES_NAVIGATOR"], "description": "School IDs."},
    {"type": "INDUSTRY", "services": ["CLASSIC", "RECRUITER"], "description": "Classic/Recruiter industry IDs."},
    {"type": "SERVICE", "services": ["CLASSIC"], "description": "Service category IDs."},
    {"type": "JOB_FUNCTION", "services": ["CLASSIC"], "description": "Classic job function IDs."},
    {"type": "JOB_TITLE", "services": ["CLASSIC", "RECRUITER", "SALES_NAVIGATOR"], "description": "Job title IDs."},
    {"type": "EMPLOYMENT_TYPE", "services": ["CLASSIC"], "description": "Employment type values."},
    {"type": "SKILL", "services": ["RECRUITER"], "description": "Skill IDs."},
    {"type": "GROUPS", "services": ["SALES_NAVIGATOR", "RECRUITER"], "description": "LinkedIn group IDs."},
    {"type": "SALES_INDUSTRY", "services": ["SALES_NAVIGATOR"], "description": "Sales Navigator industry IDs."},
    {"type": "DEPARTMENT", "services": ["SALES_NAVIGATOR", "RECRUITER"], "description": "Department/function IDs."},
    {"type": "PERSONA", "services": ["SALES_NAVIGATOR"], "description": "Sales Navigator persona IDs."},
    {"type": "ACCOUNT_LISTS", "services": ["SALES_NAVIGATOR"], "description": "Sales Navigator account list IDs."},
    {"type": "LEAD_LISTS", "services": ["SALES_NAVIGATOR"], "description": "Sales Navigator lead list IDs."},
    {"type": "TECHNOLOGIES", "services": ["SALES_NAVIGATOR"], "description": "Technology IDs for company search."},
    {"type": "SAVED_ACCOUNTS", "services": ["SALES_NAVIGATOR"], "description": "Saved account IDs."},
    {"type": "SAVED_SEARCHES", "services": ["SALES_NAVIGATOR", "RECRUITER"], "description": "Saved search IDs."},
    {"type": "RECENT_SEARCHES", "services": ["SALES_NAVIGATOR"], "description": "Recent search IDs."},
    {"type": "REGION", "services": ["SALES_NAVIGATOR"], "description": "Sales Navigator geography/region IDs."},
    {"type": "POSTAL_CODE", "services": ["SALES_NAVIGATOR"], "description": "Sales Navigator postal-code IDs."},
    {"type": "SAVED_FILTERS", "services": ["RECRUITER"], "description": "Recruiter saved filter IDs."},
    {"type": "HIRING_PROJECTS", "services": ["RECRUITER"], "description": "Recruiter hiring project IDs."},
    {"type": "DEGREE", "services": ["RECRUITER"], "description": "Recruiter degree IDs."},
]

_DOCS = {
    "source": "unipile",
    "source_urls": [
        "https://developer.unipile.com/docs/linkedin-search",
        "https://developer.unipile.com/reference/linkedincontroller_search",
        "https://developer.unipile.com/reference/linkedincontroller_getsearchparameterslist",
    ],
    "retrieved_at": "2026-05-11",
    "notes": [
        "Use URL replay when an exact LinkedIn/Sales Navigator browser search must be preserved.",
        "Use structured filters for agent-built lists; resolve ID-backed values with search-params first.",
        "Use background list-build jobs for large lists; direct search is for one page, replay, or debugging.",
    ],
}


def linkedin_filter_entries(
    *,
    api_mode: Optional[str] = None,
    category: Optional[str] = None,
    field: Optional[str] = None,
) -> List[Dict[str, Any]]:
    api = str(api_mode or "").strip().lower()
    cat = str(category or "").strip().lower()
    target_field = str(field or "").strip().lower()
    entries: List[Dict[str, Any]] = []
    for entry in _FILTERS:
        if api and api != "all" and api not in entry.get("api_modes", []):
            continue
        if cat and cat != "all" and cat not in entry.get("categories", []):
            continue
        aliases = [str(alias).lower() for alias in entry.get("aliases", [])]
        if target_field and target_field not in {str(entry.get("field", "")).lower(), *aliases}:
            continue
        entries.append(deepcopy(entry))
    return entries


def linkedin_parameter_types(*, service: Optional[str] = None) -> List[Dict[str, Any]]:
    target = str(service or "").strip().upper()
    if target in {"", "ALL", "AUTO"}:
        return deepcopy(_PARAMETER_TYPES)
    return [deepcopy(entry) for entry in _PARAMETER_TYPES if target in entry.get("services", [])]


def _find_filter_entry(field: str, *, api_mode: str, category: str) -> Optional[Dict[str, Any]]:
    target = str(field or "").strip().lower()
    api = str(api_mode or "").strip().lower()
    cat = str(category or "").strip().lower()
    for entry in _FILTERS:
        aliases = [str(alias).lower() for alias in entry.get("aliases", [])]
        if target not in {str(entry.get("field", "")).lower(), *aliases}:
            continue
        if api not in entry.get("api_modes", []):
            continue
        if cat not in entry.get("categories", []):
            continue
        return entry
    return None


def _list_values(value: Any) -> List[Any]:
    if value is None or value == "":
        return []
    if isinstance(value, list):
        values = value
    elif isinstance(value, tuple):
        values = list(value)
    else:
        values = [value]
    return [item for item in values if item not in (None, "")]


def _include_exclude(value: Any) -> Dict[str, List[Any]]:
    if isinstance(value, dict):
        return {
            "include": _list_values(value.get("include") or value.get("includes") or value.get("values")),
            "exclude": _list_values(value.get("exclude") or value.get("excludes")),
        }
    return {"include": _list_values(value), "exclude": []}


def _parse_range_filter(value: Any) -> List[Dict[str, int]]:
    if value is None or value == "":
        return []
    if isinstance(value, list):
        output: List[Dict[str, int]] = []
        for item in value:
            output.extend(_parse_range_filter(item))
        return output
    if isinstance(value, dict):
        try:
            minimum = int(value.get("min"))
        except Exception:
            return []
        parsed: Dict[str, int] = {"min": minimum}
        maximum = value.get("max")
        if maximum not in (None, ""):
            try:
                parsed["max"] = int(maximum)
            except Exception:
                pass
        return [parsed]

    raw = str(value).strip().lower().replace(",", "")
    for bucket in HEADCOUNT_BUCKETS:
        if raw == str(bucket["label"]).lower().replace(",", ""):
            parsed = {"min": int(bucket["min"])}
            if bucket.get("max") is not None:
                parsed["max"] = int(bucket["max"])
            return [parsed]
    numbers: List[int] = []
    current = ""
    for char in raw:
        if char.isdigit():
            current += char
        elif current:
            numbers.append(int(current))
            current = ""
    if current:
        numbers.append(int(current))
    if not numbers:
        return []
    parsed = {"min": numbers[0]}
    if "+" not in raw and len(numbers) > 1:
        parsed["max"] = numbers[1]
    return [parsed]


def _coerce_filter_value(entry: Dict[str, Any], value: Any) -> Any:
    field = str(entry.get("field") or "")
    kind = str(entry.get("value_kind") or "")
    shape = str(entry.get("shape") or "")

    if kind in {"range_bucket", "numeric_range"}:
        if kind == "numeric_range" and isinstance(value, dict):
            return value
        return _parse_range_filter(value)
    if kind == "boolean":
        if isinstance(value, bool):
            return value
        return str(value).strip().lower() in {"1", "true", "yes", "y", "on"}
    if kind == "object":
        return value if isinstance(value, dict) else {}
    if kind in {"enum", "iso_639_1", "enum_or_number"}:
        if shape.startswith("["):
            return _list_values(value)
        return value
    if field in {"saved_search_id", "recent_search_id"}:
        values = _list_values(value)
        return str(values[0]) if values else ""
    if entry.get("supports_include_exclude"):
        parts = _include_exclude(value)
        payload: Dict[str, Any] = {}
        if parts["include"]:
            payload["include"] = parts["include"]
        if parts["exclude"]:
            payload["exclude"] = parts["exclude"]
        return payload
    return _list_values(value) if shape.startswith("[") else value


def compile_linkedin_search_filters(
    filters: Optional[Dict[str, Any]],
    *,
    api_mode: str,
    category: str,
) -> Dict[str, Any]:
    """Compile catalog-level filter values into Unipile search extra_params.

    The caller should pass the already resolved LinkedIn API mode. This keeps
    CLI clients mode-neutral while still emitting classic vs Sales Navigator
    shapes correctly after account capability resolution.
    """
    if not isinstance(filters, dict):
        return {}
    compiled: Dict[str, Any] = {}
    for raw_field, raw_value in filters.items():
        field = str(raw_field or "").strip()
        if not field:
            continue
        entry = _find_filter_entry(field, api_mode=api_mode, category=category)
        if entry is None:
            raise ValueError(f"LinkedIn filter '{field}' is not supported for {api_mode}/{category}")
        value = _coerce_filter_value(entry, raw_value)
        if value in (None, "", [], {}):
            continue
        compiled[str(entry.get("provider_field") or field)] = value
    return compiled


def linkedin_filter_catalog(
    *,
    api_mode: Optional[str] = None,
    category: Optional[str] = None,
    field: Optional[str] = None,
) -> Dict[str, Any]:
    return {
        "version": "2026-05-11",
        "docs": deepcopy(_DOCS),
        "supported_api_modes": ["classic", "sales_navigator"],
        "supported_categories": ["people", "companies", "jobs", "posts"],
        "headcount_buckets": deepcopy(HEADCOUNT_BUCKETS),
        "parameter_types": linkedin_parameter_types(
            service=None if api_mode in {None, "", "all", "auto"} else str(api_mode).upper()
        ),
        "filters": linkedin_filter_entries(api_mode=api_mode, category=category, field=field),
    }


__all__ = [
    "HEADCOUNT_BUCKETS",
    "compile_linkedin_search_filters",
    "linkedin_filter_catalog",
    "linkedin_filter_entries",
    "linkedin_parameter_types",
]
