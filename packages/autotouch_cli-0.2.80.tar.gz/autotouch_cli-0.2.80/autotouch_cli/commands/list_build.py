from __future__ import annotations

import argparse
import json
import time
from dataclasses import dataclass
from typing import Any, Callable, Dict, Optional

from autotouch_cli.exceptions import AutotouchInputError, AutotouchTimeoutError


@dataclass(frozen=True)
class ListBuildCommandRuntime:
    resolve_token: Callable[[Optional[str], bool], Optional[str]]
    request_api: Callable[..., Any]
    print_json: Callable[[Any, bool], None]
    load_json_input: Callable[..., Any]


def _payload(args: argparse.Namespace, *, runtime: ListBuildCommandRuntime, kind: str) -> Dict[str, Any]:
    explicit = runtime.load_json_input(
        inline_json=getattr(args, "data_json", None),
        file_path=getattr(args, "data_file", None),
        context="data",
        default=None,
    )
    if explicit is not None:
        if not isinstance(explicit, dict):
            raise AutotouchInputError("list-build payload must be a JSON object")
        explicit.setdefault("kind", kind)
        return explicit
    filters: Dict[str, Any] = {}
    for attr, key in (
        ("geo_id", "geo_ids"),
        ("industry_id", "industry_ids"),
        ("company_size", "company_sizes"),
        ("current_company_id", "current_company_ids"),
        ("past_company_id", "past_company_ids"),
        ("school_id", "school_ids"),
    ):
        values = getattr(args, attr, None) or []
        if values:
            filters[key] = values
    if getattr(args, "has_jobs", False):
        filters["has_jobs"] = True
    profile_language = str(getattr(args, "profile_language", "") or "").strip()
    if profile_language:
        filters["profile_language"] = profile_language
    payload: Dict[str, Any] = {
        "kind": kind,
        "num_results": max(1, min(int(getattr(args, "num_results", 100) or 100), 10000)),
        "page_size": max(1, min(int(getattr(args, "page_size", 25) or 25), 100)),
        "filters": filters,
    }
    for attr in ("list_name", "keywords", "title"):
        value = str(getattr(args, attr, "") or "").strip()
        if value:
            payload[attr] = value
    return payload


def _wait(job_id: str, args: argparse.Namespace, *, runtime: ListBuildCommandRuntime, token: Optional[str]) -> Any:
    started = time.time()
    while True:
        data = runtime.request_api(
            "GET",
            f"/api/list-builds/{job_id}",
            base_url=args.base_url,
            token=token,
            use_x_api_key=args.use_x_api_key,
            timeout=args.timeout,
            verbose=args.verbose,
        )
        if str(data.get("status") or "").lower() in {"completed", "error", "cancelled"}:
            return data
        timeout = int(getattr(args, "wait_timeout", 0) or 0)
        if timeout and time.time() - started >= timeout:
            raise AutotouchTimeoutError(f"Timed out waiting for list build {job_id}")
        time.sleep(max(1, int(getattr(args, "poll_interval", 5) or 5)))


def _create(args: argparse.Namespace, *, runtime: ListBuildCommandRuntime, kind: str) -> None:
    token = runtime.resolve_token(args.token, required=True)
    data = runtime.request_api(
        "POST",
        "/api/list-builds",
        base_url=args.base_url,
        token=token,
        use_x_api_key=args.use_x_api_key,
        payload=_payload(args, runtime=runtime, kind=kind),
        timeout=args.timeout,
        verbose=args.verbose,
    )
    if getattr(args, "wait", False) and data.get("job_id"):
        data = _wait(str(data["job_id"]), args, runtime=runtime, token=token)
    runtime.print_json(data, args.compact)


def cmd_list_build_companies(args: argparse.Namespace, *, runtime: ListBuildCommandRuntime) -> None:
    _create(args, runtime=runtime, kind="companies")


def cmd_list_build_leads(args: argparse.Namespace, *, runtime: ListBuildCommandRuntime) -> None:
    _create(args, runtime=runtime, kind="leads")


def cmd_list_build_status(args: argparse.Namespace, *, runtime: ListBuildCommandRuntime) -> None:
    token = runtime.resolve_token(args.token, required=True)
    data = runtime.request_api(
        "GET",
        f"/api/list-builds/{args.job_id}",
        base_url=args.base_url,
        token=token,
        use_x_api_key=args.use_x_api_key,
        timeout=args.timeout,
        verbose=args.verbose,
    )
    runtime.print_json(data, args.compact)


def cmd_list_build_results(args: argparse.Namespace, *, runtime: ListBuildCommandRuntime) -> None:
    token = runtime.resolve_token(args.token, required=True)
    data = runtime.request_api(
        "GET",
        f"/api/list-builds/{args.job_id}/results?type={args.type}&page={args.page}&page_size={args.page_size}",
        base_url=args.base_url,
        token=token,
        use_x_api_key=args.use_x_api_key,
        timeout=args.timeout,
        verbose=args.verbose,
    )
    runtime.print_json(data, args.compact)


def register_list_build_subcommands(
    subparsers: argparse._SubParsersAction[argparse.ArgumentParser],
    *,
    add_api_common_arguments: Callable[[argparse.ArgumentParser], None],
    handlers: Dict[str, Callable[[argparse.Namespace], None]],
) -> None:
    parser = subparsers.add_parser("list-build", help="Build durable company and lead lists")
    sub = parser.add_subparsers(dest="list_build_cmd", required=True)

    def add_create_args(p: argparse.ArgumentParser) -> None:
        p.add_argument("--data-json", help="Explicit list-build payload JSON")
        p.add_argument("--data-file", help="Path to list-build payload JSON file")
        p.add_argument("--list-name", help="Optional display name")
        p.add_argument("--keywords", help="Search keywords")
        p.add_argument("--title", help="Lead title/persona query")
        p.add_argument("--geo-id", action="append", help="Geography ID; repeat or comma-separate in JSON")
        p.add_argument("--industry-id", action="append", help="Industry ID; repeat or comma-separate in JSON")
        p.add_argument("--company-size", action="append", help="Company size bucket, e.g. 1-10 or 11-50")
        p.add_argument("--current-company-id", action="append", help="Company ID for lead search")
        p.add_argument("--past-company-id", action="append", help="Past company ID for lead search")
        p.add_argument("--school-id", action="append", help="School ID for lead search")
        p.add_argument("--profile-language", help="Profile language code, e.g. en")
        p.add_argument("--has-jobs", action="store_true", help="Only include companies with active job listings")
        p.add_argument("--num-results", type=int, default=100, help="Target result count, 1-10000")
        p.add_argument("--page-size", type=int, default=25, help="Provider page size")
        p.add_argument("--wait", action="store_true", help="Poll until terminal status")
        p.add_argument("--poll-interval", type=int, default=5, help="Polling interval seconds for --wait")
        p.add_argument("--wait-timeout", type=int, default=0, help="Max seconds to wait (0 = no timeout)")
        add_api_common_arguments(p)

    companies = sub.add_parser("companies", help="Build a company/account list")
    add_create_args(companies)
    companies.set_defaults(func=handlers["companies"])

    leads = sub.add_parser("leads", help="Build a lead/contact list")
    add_create_args(leads)
    leads.set_defaults(func=handlers["leads"])

    status = sub.add_parser("status", help="Get list-build job status")
    status.add_argument("--job-id", required=True)
    add_api_common_arguments(status)
    status.set_defaults(func=handlers["status"])

    results = sub.add_parser("results", help="Get list-build results")
    results.add_argument("--job-id", required=True)
    results.add_argument("--type", choices=["items", "companies", "leads", "all"], default="items")
    results.add_argument("--page", type=int, default=1)
    results.add_argument("--page-size", type=int, default=50)
    add_api_common_arguments(results)
    results.set_defaults(func=handlers["results"])

