"""Scheduled agent CLI commands."""

from __future__ import annotations

import argparse
import json
import sys
import time
from dataclasses import dataclass
from typing import Any, Callable, Dict, Optional, Sequence


@dataclass(frozen=True)
class AgentCommandRuntime:
    resolve_token: Callable[[Optional[str], bool], Optional[str]]
    request_api: Callable[..., Any]
    print_json: Callable[[Any, bool], None]
    load_json_input: Callable[..., Any]
    api_url: Callable[[Optional[str]], str]
    default_timeout_seconds: int


# ---------------------------------------------------------------------------
# CRUD
# ---------------------------------------------------------------------------

def cmd_agents_list(args: argparse.Namespace, *, runtime: AgentCommandRuntime) -> None:
    token = runtime.resolve_token(args.token, required=True)
    data = runtime.request_api(
        "GET", "/api/agents",
        base_url=args.base_url, token=token,
        use_x_api_key=args.use_x_api_key,
        timeout=args.timeout, verbose=args.verbose,
    )
    runtime.print_json(data, args.compact)


def cmd_agents_get(args: argparse.Namespace, *, runtime: AgentCommandRuntime) -> None:
    token = runtime.resolve_token(args.token, required=True)
    data = runtime.request_api(
        "GET", f"/api/agents/{args.agent_id}",
        base_url=args.base_url, token=token,
        use_x_api_key=args.use_x_api_key,
        timeout=args.timeout, verbose=args.verbose,
    )
    runtime.print_json(data, args.compact)


def cmd_agents_create(args: argparse.Namespace, *, runtime: AgentCommandRuntime) -> None:
    token = runtime.resolve_token(args.token, required=True)

    if getattr(args, "from_file", None):
        payload = runtime.load_json_input(args.from_file)
    else:
        payload: Dict[str, Any] = {}
        if args.name:
            payload["name"] = args.name
        if args.target:
            payload["targetType"] = args.target
        if args.assigned_user:
            payload["assignedUserId"] = args.assigned_user
        # Build the schedule object from any provided schedule flags. We only
        # send a `schedule` key when the user actually set at least one field.
        schedule_payload: Dict[str, Any] = {}
        if args.schedule_time:
            schedule_payload["timeOfDay"] = args.schedule_time
        schedule_tz = getattr(args, "schedule_tz", None)
        if schedule_tz:
            schedule_payload["timezone"] = schedule_tz
        schedule_frequency = getattr(args, "schedule_frequency", None)
        if schedule_frequency:
            schedule_payload["frequency"] = schedule_frequency
        schedule_days = getattr(args, "schedule_days", None)
        if schedule_days:
            schedule_payload["days"] = schedule_days
        schedule_day_of_week = getattr(args, "schedule_day_of_week", None)
        if schedule_day_of_week is not None:
            schedule_payload["dayOfWeek"] = schedule_day_of_week
        schedule_window_start = getattr(args, "schedule_window_start", None)
        if schedule_window_start:
            schedule_payload["windowStart"] = schedule_window_start
        schedule_window_end = getattr(args, "schedule_window_end", None)
        if schedule_window_end:
            schedule_payload["windowEnd"] = schedule_window_end
        if schedule_payload:
            # Backfill required fields the API expects (timezone defaults to UTC,
            # timeOfDay defaults to 09:00 — required even for sub-daily frequencies).
            schedule_payload.setdefault("timezone", "UTC")
            schedule_payload.setdefault("timeOfDay", "09:00")
            payload["schedule"] = schedule_payload
        if getattr(args, "auto_find_email", False):
            payload["autoFindEmail"] = True
        if getattr(args, "auto_find_phone", False):
            payload["autoFindPhone"] = True
        if getattr(args, "auto_broaden", False):
            payload["autoBroadenSearch"] = True
        auto_create_lead_mode = getattr(args, "auto_create_lead_mode", None)
        if auto_create_lead_mode:
            payload["autoCreateLeadMode"] = auto_create_lead_mode
        auto_sequence_id = getattr(args, "auto_sequence_id", None)
        if auto_sequence_id:
            payload["autoSequenceId"] = auto_sequence_id
        status = getattr(args, "status", None)
        if status:
            payload["status"] = status

    # AI generation: generate persona, signals, and create in one shot
    if getattr(args, "generate", False) and "personaConfig" not in payload:
        target = payload.get("targetType", "LEADS")
        sys.stderr.write(f"Generating persona for {target}...\n")
        persona_data = runtime.request_api(
            "POST", "/api/agents/generate-persona",
            base_url=args.base_url, token=token,
            use_x_api_key=args.use_x_api_key,
            payload={"targetType": target},
            timeout=args.timeout, verbose=args.verbose,
        )
        persona = persona_data.get("persona") or persona_data.get("personaConfig") or {}
        payload["personaConfig"] = persona
        sys.stderr.write(f"  Persona generated: {json.dumps(persona, ensure_ascii=False)[:200]}...\n")

        # Generate topics
        sys.stderr.write("Generating topic suggestions...\n")
        topic_data = runtime.request_api(
            "POST", "/api/agents/generate-signal-topics",
            base_url=args.base_url, token=token,
            use_x_api_key=args.use_x_api_key,
            payload={"targetType": target, "personaConfig": persona},
            timeout=args.timeout, verbose=args.verbose,
        )
        topics = topic_data.get("topics") or []
        sys.stderr.write(f"  Topics: {topics}\n")

        # Generate job signal
        sys.stderr.write("Generating job signal config...\n")
        job_data = runtime.request_api(
            "POST", "/api/agents/generate-job-signal",
            base_url=args.base_url, token=token,
            use_x_api_key=args.use_x_api_key,
            payload={"targetType": target, "personaConfig": persona},
            timeout=args.timeout, verbose=args.verbose,
        )
        job_titles = job_data.get("jobTitles") or []
        job_keywords = job_data.get("keywords") or []
        sys.stderr.write(f"  Job titles: {job_titles}\n")

        # Assemble signals
        signals = []
        if topics:
            signals.append({
                "key": "linkedin-topic-post-engagement",
                "config": {"topics": [{"id": "", "label": t, "trackingMode": "all"} for t in topics[:5]]},
            })
        if job_titles or job_keywords:
            signals.append({
                "key": "hiring-signals",
                "config": {"jobTitles": job_titles, "keywords": job_keywords, "remoteOnly": False, "lookbackWindow": "24h"},
            })

        # News scan: derive buying trigger topics from persona
        news_topics = ["raised funding", "new executive hire"]
        industries = (persona.get("industries") or [])[:2]
        if industries:
            news_topics.append(f"expansion {industries[0]}")
        signals.append({
            "key": "news-scan",
            "config": {"topics": news_topics, "lookback": "24h"},
        })

        if signals:
            payload["selectedSignals"] = signals

    data = runtime.request_api(
        "POST", "/api/agents",
        base_url=args.base_url, token=token,
        use_x_api_key=args.use_x_api_key,
        payload=payload,
        timeout=args.timeout, verbose=args.verbose,
    )
    runtime.print_json(data, args.compact)


def cmd_agents_update(args: argparse.Namespace, *, runtime: AgentCommandRuntime) -> None:
    token = runtime.resolve_token(args.token, required=True)

    if getattr(args, "from_file", None):
        payload = runtime.load_json_input(args.from_file)
    else:
        payload: Dict[str, Any] = {}
        if getattr(args, "name", None):
            payload["name"] = args.name
        if getattr(args, "status", None):
            payload["status"] = args.status
        if getattr(args, "auto_find_email", None) is not None:
            payload["autoFindEmail"] = args.auto_find_email
        if getattr(args, "auto_find_phone", None) is not None:
            payload["autoFindPhone"] = args.auto_find_phone
        if getattr(args, "auto_broaden", None) is not None:
            payload["autoBroadenSearch"] = args.auto_broaden
        if getattr(args, "auto_create_lead_mode", None):
            payload["autoCreateLeadMode"] = args.auto_create_lead_mode
        # Pass an empty string to clear the auto-sequence link.
        auto_sequence_id_arg = getattr(args, "auto_sequence_id", None)
        if auto_sequence_id_arg is not None:
            payload["autoSequenceId"] = auto_sequence_id_arg or None

        # Schedule changes need a full schedule object, so we merge any
        # provided flags onto the agent's existing schedule.
        schedule_flag_values = {
            "timeOfDay": getattr(args, "schedule_time", None),
            "timezone": getattr(args, "schedule_tz", None),
            "frequency": getattr(args, "schedule_frequency", None),
            "days": getattr(args, "schedule_days", None),
            "dayOfWeek": getattr(args, "schedule_day_of_week", None),
            "windowStart": getattr(args, "schedule_window_start", None),
            "windowEnd": getattr(args, "schedule_window_end", None),
        }
        if any(v is not None for v in schedule_flag_values.values()):
            existing = runtime.request_api(
                "GET", f"/api/agents/{args.agent_id}",
                base_url=args.base_url, token=token,
                use_x_api_key=args.use_x_api_key,
                timeout=args.timeout, verbose=args.verbose,
            )
            existing_schedule = (existing or {}).get("schedule") or {}
            merged_schedule: Dict[str, Any] = {
                "timezone": existing_schedule.get("timezone") or "UTC",
                "timeOfDay": existing_schedule.get("timeOfDay") or "09:00",
                "frequency": existing_schedule.get("frequency") or "daily",
                "days": existing_schedule.get("days") or "all",
                "dayOfWeek": existing_schedule.get("dayOfWeek") or 0,
            }
            if existing_schedule.get("windowStart"):
                merged_schedule["windowStart"] = existing_schedule["windowStart"]
            if existing_schedule.get("windowEnd"):
                merged_schedule["windowEnd"] = existing_schedule["windowEnd"]
            for key, value in schedule_flag_values.items():
                if value is not None:
                    merged_schedule[key] = value
            payload["schedule"] = merged_schedule

    data = runtime.request_api(
        "PATCH", f"/api/agents/{args.agent_id}",
        base_url=args.base_url, token=token,
        use_x_api_key=args.use_x_api_key,
        payload=payload,
        timeout=args.timeout, verbose=args.verbose,
    )
    runtime.print_json(data, args.compact)


def cmd_agents_delete(args: argparse.Namespace, *, runtime: AgentCommandRuntime) -> None:
    token = runtime.resolve_token(args.token, required=True)
    data = runtime.request_api(
        "PATCH", f"/api/agents/{args.agent_id}",
        base_url=args.base_url, token=token,
        use_x_api_key=args.use_x_api_key,
        payload={"status": "DRAFT"},
        timeout=args.timeout, verbose=args.verbose,
    )
    sys.stderr.write(f"Agent {args.agent_id} deleted.\n")
    runtime.print_json(data, args.compact)


# ---------------------------------------------------------------------------
# Run management
# ---------------------------------------------------------------------------

def cmd_agents_run(args: argparse.Namespace, *, runtime: AgentCommandRuntime) -> None:
    token = runtime.resolve_token(args.token, required=True)
    data = runtime.request_api(
        "POST", f"/api/agents/{args.agent_id}/run-now",
        base_url=args.base_url, token=token,
        use_x_api_key=args.use_x_api_key,
        timeout=args.timeout, verbose=args.verbose,
    )
    runtime.print_json(data, args.compact)


def cmd_agents_runs(args: argparse.Namespace, *, runtime: AgentCommandRuntime) -> None:
    token = runtime.resolve_token(args.token, required=True)
    params = {"limit": max(1, int(getattr(args, "limit", 10) or 10))}
    data = runtime.request_api(
        "GET", f"/api/agents/{args.agent_id}/runs",
        base_url=args.base_url, token=token,
        use_x_api_key=args.use_x_api_key,
        params=params,
        timeout=args.timeout, verbose=args.verbose,
    )
    runtime.print_json(data, args.compact)


def cmd_agents_watch(args: argparse.Namespace, *, runtime: AgentCommandRuntime) -> None:
    """Trigger a run and poll until complete."""
    token = runtime.resolve_token(args.token, required=True)

    # Trigger
    run_data = runtime.request_api(
        "POST", f"/api/agents/{args.agent_id}/run-now",
        base_url=args.base_url, token=token,
        use_x_api_key=args.use_x_api_key,
        timeout=args.timeout, verbose=args.verbose,
    )
    run_id = run_data.get("id", "")
    sys.stderr.write(f"Run {run_id} queued. Watching...\n")

    interval = max(5, int(getattr(args, "interval", 10) or 10))
    max_wait = max(60, int(getattr(args, "max_wait", 1800) or 1800))
    elapsed = 0

    while elapsed < max_wait:
        time.sleep(interval)
        elapsed += interval

        runs_data = runtime.request_api(
            "GET", f"/api/agents/{args.agent_id}/runs",
            base_url=args.base_url, token=token,
            use_x_api_key=args.use_x_api_key,
            params={"limit": 1},
            timeout=args.timeout, verbose=args.verbose,
        )
        runs = runs_data.get("runs", [])
        if not runs:
            continue

        latest = runs[0]
        status = latest.get("status", "")
        leads = latest.get("resultCounts", {}).get("leads", 0)
        sys.stderr.write(f"  [{elapsed}s] {status} | leads={leads}\n")

        if status in ("SUCCEEDED", "FAILED"):
            runtime.print_json(latest, args.compact)
            return

    sys.stderr.write(f"Timed out after {max_wait}s. Run may still be in progress.\n")


# ---------------------------------------------------------------------------
# AI generation
# ---------------------------------------------------------------------------

def cmd_agents_generate_persona(args: argparse.Namespace, *, runtime: AgentCommandRuntime) -> None:
    token = runtime.resolve_token(args.token, required=True)
    payload: Dict[str, Any] = {"targetType": getattr(args, "target", "LEADS") or "LEADS"}

    current = getattr(args, "current_config", None)
    if current:
        payload["currentPersonaConfig"] = runtime.load_json_input(current)

    data = runtime.request_api(
        "POST", "/api/agents/generate-persona",
        base_url=args.base_url, token=token,
        use_x_api_key=args.use_x_api_key,
        payload=payload,
        timeout=args.timeout, verbose=args.verbose,
    )
    runtime.print_json(data, args.compact)


def cmd_agents_generate_topics(args: argparse.Namespace, *, runtime: AgentCommandRuntime) -> None:
    token = runtime.resolve_token(args.token, required=True)
    payload: Dict[str, Any] = {"targetType": getattr(args, "target", "LEADS") or "LEADS"}

    persona = getattr(args, "persona", None)
    if persona:
        payload["personaConfig"] = runtime.load_json_input(persona)

    current = getattr(args, "current_topics", None)
    if current:
        payload["currentTopics"] = [t.strip() for t in current.split(",") if t.strip()]

    data = runtime.request_api(
        "POST", "/api/agents/generate-signal-topics",
        base_url=args.base_url, token=token,
        use_x_api_key=args.use_x_api_key,
        payload=payload,
        timeout=args.timeout, verbose=args.verbose,
    )
    runtime.print_json(data, args.compact)


def cmd_agents_generate_job_signal(args: argparse.Namespace, *, runtime: AgentCommandRuntime) -> None:
    token = runtime.resolve_token(args.token, required=True)
    payload: Dict[str, Any] = {"targetType": getattr(args, "target", "LEADS") or "LEADS"}

    persona = getattr(args, "persona", None)
    if persona:
        payload["personaConfig"] = runtime.load_json_input(persona)

    current_titles = getattr(args, "current_titles", None)
    if current_titles:
        payload["currentJobTitles"] = [t.strip() for t in current_titles.split(",") if t.strip()]

    current_keywords = getattr(args, "current_keywords", None)
    if current_keywords:
        payload["currentKeywords"] = [k.strip() for k in current_keywords.split(",") if k.strip()]

    data = runtime.request_api(
        "POST", "/api/agents/generate-job-signal",
        base_url=args.base_url, token=token,
        use_x_api_key=args.use_x_api_key,
        payload=payload,
        timeout=args.timeout, verbose=args.verbose,
    )
    runtime.print_json(data, args.compact)


# ---------------------------------------------------------------------------
# Skill packs / signals
# ---------------------------------------------------------------------------

def cmd_agents_signals(args: argparse.Namespace, *, runtime: AgentCommandRuntime) -> None:
    token = runtime.resolve_token(args.token, required=True)
    data = runtime.request_api(
        "GET", "/api/agents/skill-packs",
        base_url=args.base_url, token=token,
        use_x_api_key=args.use_x_api_key,
        timeout=args.timeout, verbose=args.verbose,
    )
    runtime.print_json(data, args.compact)


# ---------------------------------------------------------------------------
# Parser registration
# ---------------------------------------------------------------------------

def register_agents_subcommands(
    subparsers: argparse._SubParsersAction[argparse.ArgumentParser],
    *,
    add_api_common_arguments: Callable[[argparse.ArgumentParser], None],
    handlers: Dict[str, Callable[[argparse.Namespace], None]],
) -> None:
    pa = subparsers.add_parser("agents", help="Scheduled agent management")
    agents_sub = pa.add_subparsers(dest="agents_cmd", required=True)

    # -- list --
    pal = agents_sub.add_parser("list", help="List all agents")
    add_api_common_arguments(pal)
    pal.set_defaults(func=handlers["list"])

    # -- get --
    pag = agents_sub.add_parser("get", help="Get one agent by id")
    pag.add_argument("agent_id", help="Agent ID")
    add_api_common_arguments(pag)
    pag.set_defaults(func=handlers["get"])

    # -- create --
    pac = agents_sub.add_parser("create", help="Create a new agent")
    pac.add_argument("--name", help="Agent name")
    pac.add_argument("--target", choices=["LEADS"], help="Target type")
    pac.add_argument("--assigned-user", dest="assigned_user", help="Assigned user ID")
    pac.add_argument("--schedule-time", dest="schedule_time", help="Time of day (HH:MM) — used by daily/weekly")
    pac.add_argument("--schedule-tz", dest="schedule_tz", help="Timezone (default: UTC)")
    pac.add_argument(
        "--schedule-frequency",
        dest="schedule_frequency",
        choices=["hourly", "every_6h", "every_12h", "daily", "weekly"],
        help="Run cadence (default: daily)",
    )
    pac.add_argument(
        "--schedule-days",
        dest="schedule_days",
        choices=["all", "weekdays"],
        help="Which days to run on for sub-weekly cadences (default: all)",
    )
    pac.add_argument(
        "--schedule-day-of-week",
        dest="schedule_day_of_week",
        type=int,
        choices=range(0, 7),
        metavar="0-6",
        help="Day of week for weekly cadence (0=Mon, 6=Sun)",
    )
    pac.add_argument(
        "--schedule-window-start",
        dest="schedule_window_start",
        help="Active-hours window start (HH:MM) — used by hourly/every_6h/every_12h",
    )
    pac.add_argument(
        "--schedule-window-end",
        dest="schedule_window_end",
        help="Active-hours window end (HH:MM) — used by hourly/every_6h/every_12h",
    )
    pac.add_argument("--auto-find-email", dest="auto_find_email", action="store_true", default=False, help="Enable auto email finder")
    pac.add_argument("--auto-find-phone", dest="auto_find_phone", action="store_true", default=False, help="Enable auto phone finder")
    pac.add_argument("--auto-broaden", dest="auto_broaden", action="store_true", default=False, help="Enable auto broaden search")
    pac.add_argument(
        "--auto-create-lead-mode",
        dest="auto_create_lead_mode",
        choices=["qualified_only", "everyone", "manual_only"],
        help="Which discovered prospects become leads (default: qualified_only)",
    )
    pac.add_argument(
        "--auto-sequence-id",
        dest="auto_sequence_id",
        help="Sequence ID — discovered leads get auto-enrolled. Triggers outreach automatically.",
    )
    pac.add_argument("--status", choices=["DRAFT", "ACTIVE", "PAUSED"], help="Initial status")
    pac.add_argument("--from-file", dest="from_file", help="Path to JSON payload file")
    pac.add_argument("--generate", action="store_true", help="Auto-generate persona, topics, and job signal config")
    add_api_common_arguments(pac)
    pac.set_defaults(func=handlers["create"])

    # -- update --
    pau = agents_sub.add_parser("update", help="Update an existing agent")
    pau.add_argument("agent_id", help="Agent ID")
    pau.add_argument("--name", help="New agent name")
    pau.add_argument("--status", choices=["DRAFT", "ACTIVE", "PAUSED"], help="New status")
    pau.add_argument("--auto-find-email", dest="auto_find_email", type=_bool_arg, default=None, help="Enable/disable auto email finder")
    pau.add_argument("--auto-find-phone", dest="auto_find_phone", type=_bool_arg, default=None, help="Enable/disable auto phone finder")
    pau.add_argument("--auto-broaden", dest="auto_broaden", type=_bool_arg, default=None, help="Enable/disable auto broaden search")
    pau.add_argument(
        "--auto-create-lead-mode",
        dest="auto_create_lead_mode",
        choices=["qualified_only", "everyone", "manual_only"],
        help="Which discovered prospects become leads",
    )
    pau.add_argument(
        "--auto-sequence-id",
        dest="auto_sequence_id",
        help="Sequence ID for auto-enrollment. Pass empty string to clear.",
    )
    pau.add_argument("--schedule-time", dest="schedule_time", help="Time of day (HH:MM) — used by daily/weekly")
    pau.add_argument("--schedule-tz", dest="schedule_tz", help="Timezone")
    pau.add_argument(
        "--schedule-frequency",
        dest="schedule_frequency",
        choices=["hourly", "every_6h", "every_12h", "daily", "weekly"],
        help="Run cadence",
    )
    pau.add_argument(
        "--schedule-days",
        dest="schedule_days",
        choices=["all", "weekdays"],
        help="Which days to run on for sub-weekly cadences",
    )
    pau.add_argument(
        "--schedule-day-of-week",
        dest="schedule_day_of_week",
        type=int,
        choices=range(0, 7),
        metavar="0-6",
        help="Day of week for weekly cadence (0=Mon, 6=Sun)",
    )
    pau.add_argument(
        "--schedule-window-start",
        dest="schedule_window_start",
        help="Active-hours window start (HH:MM) — used by hourly/every_6h/every_12h",
    )
    pau.add_argument(
        "--schedule-window-end",
        dest="schedule_window_end",
        help="Active-hours window end (HH:MM) — used by hourly/every_6h/every_12h",
    )
    pau.add_argument("--from-file", dest="from_file", help="Path to JSON patch payload file")
    add_api_common_arguments(pau)
    pau.set_defaults(func=handlers["update"])

    # -- delete --
    pad = agents_sub.add_parser("delete", help="Delete an agent (sets status to DRAFT)")
    pad.add_argument("agent_id", help="Agent ID")
    add_api_common_arguments(pad)
    pad.set_defaults(func=handlers["delete"])

    # -- run --
    par = agents_sub.add_parser("run", help="Trigger an immediate run")
    par.add_argument("agent_id", help="Agent ID")
    add_api_common_arguments(par)
    par.set_defaults(func=handlers["run"])

    # -- runs --
    pars = agents_sub.add_parser("runs", help="List recent runs for an agent")
    pars.add_argument("agent_id", help="Agent ID")
    pars.add_argument("--limit", type=int, default=10, help="Max runs to return (default: 10)")
    add_api_common_arguments(pars)
    pars.set_defaults(func=handlers["runs"])

    # -- watch --
    paw = agents_sub.add_parser("watch", help="Trigger a run and poll until complete")
    paw.add_argument("agent_id", help="Agent ID")
    paw.add_argument("--interval", type=int, default=10, help="Poll interval in seconds (default: 10)")
    paw.add_argument("--max-wait", dest="max_wait", type=int, default=1800, help="Max wait in seconds (default: 1800)")
    add_api_common_arguments(paw)
    paw.set_defaults(func=handlers["watch"])

    # -- generate-persona --
    pagp = agents_sub.add_parser("generate-persona", help="Generate ICP persona config via AI")
    pagp.add_argument("--target", choices=["LEADS"], default="LEADS", help="Target type")
    pagp.add_argument("--current-config", dest="current_config", help="Path to current persona config JSON")
    add_api_common_arguments(pagp)
    pagp.set_defaults(func=handlers["generate_persona"])

    # -- generate-topics --
    pagt = agents_sub.add_parser("generate-topics", help="Generate signal topic suggestions via AI")
    pagt.add_argument("--target", choices=["LEADS"], default="LEADS", help="Target type")
    pagt.add_argument("--persona", help="Path to persona config JSON")
    pagt.add_argument("--current-topics", dest="current_topics", help="Comma-separated current topics")
    add_api_common_arguments(pagt)
    pagt.set_defaults(func=handlers["generate_topics"])

    # -- generate-job-signal --
    pagj = agents_sub.add_parser("generate-job-signal", help="Generate job signal config via AI")
    pagj.add_argument("--target", choices=["LEADS"], default="LEADS", help="Target type")
    pagj.add_argument("--persona", help="Path to persona config JSON")
    pagj.add_argument("--current-titles", dest="current_titles", help="Comma-separated current job titles")
    pagj.add_argument("--current-keywords", dest="current_keywords", help="Comma-separated current keywords")
    add_api_common_arguments(pagj)
    pagj.set_defaults(func=handlers["generate_job_signal"])

    # -- signals --
    pass_ = agents_sub.add_parser("signals", help="List available signal skill packs")
    add_api_common_arguments(pass_)
    pass_.set_defaults(func=handlers["signals"])


def _bool_arg(v: str) -> bool:
    """Parse boolean CLI argument values."""
    if v.lower() in ("true", "1", "yes"):
        return True
    if v.lower() in ("false", "0", "no"):
        return False
    raise argparse.ArgumentTypeError(f"Expected true/false, got: {v}")
