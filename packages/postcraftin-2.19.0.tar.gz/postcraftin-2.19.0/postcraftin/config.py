OLLAMA_HOST = "http://localhost:11434"
DEFAULT_MODEL = "gemma4:e2b"
DEFAULT_OLLAMA_TIMEOUT = 300  # 5 minutes in seconds
