import json
from datetime import datetime
from pathlib import Path

from postcraftin.config import DEFAULT_MODEL, OLLAMA_HOST, DEFAULT_OLLAMA_TIMEOUT

CONFIG_DIR = Path.home() / ".postcraftin"
CONFIG_FILE = CONFIG_DIR / "config.json"

DEFAULT_CONFIG = {
    "version": "1.0",
    "selected_model": DEFAULT_MODEL,
    "ollama_host": OLLAMA_HOST,
    "ollama_timeout": DEFAULT_OLLAMA_TIMEOUT,
    "last_updated": None,
}


def _ensure_config_dir() -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)


def load_config() -> dict:
    """Load global config from ~/.postcraftin/config.json."""
    _ensure_config_dir()
    if not CONFIG_FILE.exists():
        return DEFAULT_CONFIG.copy()
    try:
        with open(CONFIG_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, IOError):
        return DEFAULT_CONFIG.copy()


def save_config(config: dict) -> None:
    """Save global config to ~/.postcraftin/config.json."""
    _ensure_config_dir()
    config["last_updated"] = datetime.now().isoformat()
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(config, f, indent=2, ensure_ascii=False)


def get_model() -> str:
    """Get the selected model, falling back to DEFAULT_MODEL."""
    config = load_config()
    return config.get("selected_model", DEFAULT_MODEL)


def set_model(model: str) -> None:
    """Set the selected model in config."""
    config = load_config()
    config["selected_model"] = model
    save_config(config)


def get_ollama_host() -> str:
    """Get the Ollama host URL."""
    config = load_config()
    return config.get("ollama_host", OLLAMA_HOST)


def set_ollama_host(host: str) -> None:
    """Set the Ollama host URL in config."""
    config = load_config()
    config["ollama_host"] = host
    save_config(config)


def get_ollama_timeout() -> int:
    """Get the Ollama client timeout in seconds."""
    config = load_config()
    return config.get("ollama_timeout", DEFAULT_OLLAMA_TIMEOUT)


def set_ollama_timeout(timeout: int) -> None:
    """Set the Ollama client timeout in config."""
    config = load_config()
    config["ollama_timeout"] = timeout
    save_config(config)


def get_config_value(key: str) -> str | None:
    """Get a specific config value."""
    config = load_config()
    return config.get(key)


def set_config_value(key: str, value: str) -> None:
    """Set a specific config value."""
    config = load_config()
    config[key] = value
    save_config(config)
