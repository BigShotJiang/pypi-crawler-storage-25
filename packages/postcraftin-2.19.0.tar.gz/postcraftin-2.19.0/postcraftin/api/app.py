import os

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from postcraftin.api.routes import generate, profiles, models, config

DEFAULT_CORS_ORIGINS = os.environ.get("POSTCRAFTIN_CORS_ORIGINS", "http://localhost:5173")
CORS_ORIGINS = [o.strip() for o in DEFAULT_CORS_ORIGINS.split(",") if o.strip()]

app = FastAPI(title="postcraftin API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(generate.router, prefix="/api")
app.include_router(profiles.router, prefix="/api")
app.include_router(models.router, prefix="/api")
app.include_router(config.router, prefix="/api")


@app.get("/api/health")
async def health():
    return {"status": "ok"}


def main():
    import uvicorn

    port = int(os.environ.get("POSTCRAFTIN_API_PORT", "8080"))
    uvicorn.run("postcraftin.api.app:app", host="0.0.0.0", port=port, reload=True)


if __name__ == "__main__":
    main()
