from fastapi import APIRouter

from postcraftin.config_manager import load_config

router = APIRouter()


@router.get("/config")
async def get_config():
    return load_config()
