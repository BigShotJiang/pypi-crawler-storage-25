import json

from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from ollama import Client, ResponseError
from pydantic import BaseModel

from postcraftin.config_manager import get_ollama_host, get_model as get_config_model
from postcraftin.generator import build_prompt
from postcraftin.profile import load_profile

router = APIRouter()


class GenerateRequest(BaseModel):
    topic: str
    profile: str = ""
    length: str = "mittel"
    model: str | None = None
    timeout: int | None = None


def _stream_generate(
    topic: str, profile_data: dict, model: str, post_length: str, profile_name: str = "", timeout: int | None = None
):
    user_prompt = build_prompt(topic, profile_data, post_length, profile_name)
    client = Client(host=get_ollama_host(), timeout=timeout or 120)
    messages = [{"role": "user", "content": user_prompt}]

    try:
        for chunk in client.chat(model=model, messages=messages, stream=True):
            content = chunk.get("message", {}).get("content", "")
            if content:
                yield f"data: {json.dumps({'content': content})}\n\n"
        yield f"data: {json.dumps({'done': True})}\n\n"
    except ResponseError as e:
        yield f"data: {json.dumps({'error': str(e)})}\n\n"
    except Exception as e:
        yield f"data: {json.dumps({'error': str(e)})}\n\n"


@router.post("/generate")
async def generate(req: GenerateRequest):
    if not req.topic:
        raise HTTPException(status_code=400, detail="topic is required")

    profile_name = req.profile or "default"
    try:
        profile_data = load_profile(profile_name)
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail=f"Profile '{profile_name}' not found")

    model = req.model or profile_data.get("technical_preferences", {}).get("model") or get_config_model()

    return StreamingResponse(
        _stream_generate(
            topic=req.topic,
            profile_data=profile_data,
            model=model,
            post_length=req.length,
            profile_name=profile_name,
            timeout=req.timeout,
        ),
        media_type="text/event-stream",
    )
