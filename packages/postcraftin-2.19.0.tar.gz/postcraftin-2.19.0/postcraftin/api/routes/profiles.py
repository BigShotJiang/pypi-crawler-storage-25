from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from postcraftin.profile import create_empty_profile, list_profiles, load_profile, save_profile

router = APIRouter()


class CreateProfileRequest(BaseModel):
    name: str
    identity: dict | None = None


@router.post("/profiles", status_code=201)
async def create_profile(req: CreateProfileRequest):
    try:
        load_profile(req.name)
        raise HTTPException(status_code=409, detail=f"Profile '{req.name}' already exists")
    except FileNotFoundError:
        pass

    profile = create_empty_profile()
    if req.identity:
        for key in ("name", "job_title", "industry"):
            if key in req.identity:
                profile["identity"][key] = req.identity[key]

    save_profile(req.name, profile)
    return {"name": req.name, "created_at": profile["meta"]["created_at"]}


@router.get("/profiles")
async def get_profiles():
    profiles = list_profiles()
    result = []
    for name in profiles:
        try:
            data = load_profile(name)
            result.append(
                {
                    "name": name,
                    "created_at": data.get("meta", {}).get("created_at", ""),
                }
            )
        except FileNotFoundError:
            continue
    return result


@router.get("/profiles/{name}")
async def get_profile(name: str):
    try:
        data = load_profile(name)
        return data
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail=f"Profile '{name}' not found")
