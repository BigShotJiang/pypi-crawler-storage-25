from fastapi import APIRouter

from postcraftin.model_selector import list_available_models

router = APIRouter()


@router.get("/models")
async def get_models():
    models = list_available_models()
    return [
        {
            "name": m.get("name", ""),
            "size": m.get("size", ""),
            "details": m.get("details", {}),
        }
        for m in models
    ]
