import json

import click
from rich.console import Console
from rich.table import Table

from postcraftin import config_manager, model_selector
from postcraftin.generator import generate_post
from postcraftin.onboarding import run_onboarding
from postcraftin.profile import (
    list_profiles,
    load_profile,
    get_default_profile_name,
    save_profile,
    get_available_topics,
    ensure_profile_dirs,
    init_history_stats,
)
from postcraftin import posts as posts_module

console = Console()

TEMPLATE_NAMES = [
    "verlierer-gewinner",
    "aha-moment",
    "weg-veraenderung",
    "herausforderung",
    "erkenntnisse",
    "experiment",
    "gegen-strom",
    "scheitern",
    "empfehlung",
    "perspektivwechsel",
]


@click.group()
def cli():
    """Postcraftin — AI-powered LinkedIn post generator."""
    pass


@cli.command()
@click.option("--name", default="default", show_default=True, help="Profile name to create.")
@click.option(
    "--module",
    "-m",
    "module",
    default=None,
    help="Module to update: identity, voice, audience, content_strategy, technical_preferences, or 'all'",
)
def onboard(name: str, module: str | None):
    """Run the interactive onboarding wizard to create a profile."""
    if module:
        from postcraftin.onboarding import run_module_onboarding

        run_module_onboarding(name, module)
    else:
        run_onboarding(name)


@cli.command()
@click.option("-t", "--topic", required=True, help="Topic for the LinkedIn post.")
@click.option(
    "--length",
    "-l",
    "post_length",
    default="mittel",
    type=click.Choice(["kurz", "mittel", "lang"], case_sensitive=False),
    help="Post length: kurz (150-500 Zeichen), mittel (1.200-1.500 Zeichen), lang (1.900-2.500 Zeichen).",
)
@click.option("--profile", default=None, help="Profile name to use (default: first available).")
@click.option("--model", default=None, help="Ollama model to use (overrides config).")
@click.option("--timeout", type=int, default=None, help="Ollama request timeout in seconds (overrides config).")
@click.option(
    "--template",
    "-T",
    "template",
    default=None,
    type=click.Choice(TEMPLATE_NAMES, case_sensitive=False),
    help="Storytelling template to use (optional).",
)
def generate(
    topic,
    post_length="mittel",
    profile=None,
    model=None,
    timeout=None,
    template=None,
):
    """Generate a LinkedIn post for a given topic."""
    profile_name = profile or get_default_profile_name()
    if not profile_name:
        console.print("[red]No profile found. Run 'postcraftin onboard' first.[/red]")
        raise SystemExit(1)
    try:
        profile_data = load_profile(profile_name)
    except FileNotFoundError as e:
        console.print(f"[red]{e}[/red]")
        raise SystemExit(1)

    ensure_profile_dirs(profile_name)
    init_history_stats(profile_name)
    posts_module.init_history(profile_name)

    tp = profile_data.get("technical_preferences", {})
    profile_model = tp.get("model", "")

    final_model = model or profile_model or config_manager.get_model()

    console.print(f"[cyan]Generating post about:[/cyan] {topic}")
    console.print(f"[dim]Profile: {profile_name} | Model: {final_model} | Length: {post_length}[/dim]")
    if template:
        console.print(f"[dim]Template: {template}[/dim]\n")
    else:
        console.print()

    generated_content = generate_post(
        topic,
        profile_data,
        post_length=post_length,
        model=final_model,
        return_content=True,
        profile_name=profile_name,
        timeout=timeout,
    )

    filepath = posts_module.create_post_with_frontmatter(
        profile_name,
        generated_content,
        template=template,
        topics=[],
    )
    console.print(f"[green]Post saved to drafts:[/green] {filepath.name}")


@cli.command(name="list-profiles")
def list_profiles_cmd():
    """List all available profiles."""
    profiles = list_profiles()
    if not profiles:
        console.print("[yellow]No profiles found. Run 'postcraftin onboard' to create one.[/yellow]")
        return
    table = Table(title="postcraftin Profiles")
    table.add_column("Name", style="cyan")
    for p in profiles:
        table.add_row(p)
    console.print(table)


@cli.command()
def models():
    """List available Ollama models."""
    console.print("[cyan]Fetching available models...[/cyan]\n")
    ollama_models = model_selector.list_available_models()
    if not ollama_models:
        console.print("[red]No models found. Make sure Ollama is running.[/red]")
        console.print("  ollama pull <model-name>")
        return
    table = model_selector.format_model_table(ollama_models)
    console.print(table)
    console.print("\n[dim]Modelle downloaden: https://ollama.com/library[/dim]")


@cli.group()
def config():
    """Manage global configuration."""
    pass


@config.command(name="model")
@click.option("--list", "list_models", is_flag=True, help="List available Ollama models.")
@click.option("--select", is_flag=True, help="Interactively select a model.")
@click.option("--set", "set_model", type=str, help="Set the global model.")
def config_model(list_models: bool, select: bool, set_model: str | None):
    """Manage model selection."""
    if list_models:
        models()
        return

    if select:
        ollama_models = model_selector.list_available_models()
        current = config_manager.get_model()
        selected = model_selector.select_model_interactive(ollama_models, current)
        if selected:
            config_manager.set_model(selected)
            console.print(f"[green]Model set to: {selected}[/green]")
        return

    if set_model:
        config_manager.set_model(set_model)
        console.print(f"[green]Model set to: {set_model}[/green]")
        return

    current = config_manager.get_model()
    console.print(f"[cyan]Current model:[/cyan] {current}")


@config.command(name="set")
@click.argument("key")
@click.argument("value")
def config_set(key: str, value: str):
    """Set a config value."""
    config_manager.set_config_value(key, value)
    console.print(f"[green]{key} set to: {value}[/green]")


@config.command()
def config_show():
    """Show global configuration."""
    cfg = config_manager.load_config()
    table = Table(title="Global Config")
    table.add_column("Key", style="cyan")
    table.add_column("Value", style="green")
    for key, value in cfg.items():
        table.add_row(key, str(value))
    console.print(table)


@cli.group()
def profile():
    """Manage profiles."""
    pass


@profile.command(name="show")
@click.argument("name")
def profile_show(name: str):
    """Show profile details."""
    try:
        data = load_profile(name)
    except FileNotFoundError:
        console.print(f"[red]Profile '{name}' not found.[/red]")
        raise SystemExit(1)
    console.print(f"\n[cyan]Profile: {name}[/cyan]\n")
    print(json.dumps(data, indent=2, ensure_ascii=False))


@profile.command(name="set")
@click.argument("name")
@click.argument("key")
@click.argument("value")
def profile_set(name: str, key: str, value: str):
    """Set a profile field."""
    try:
        data = load_profile(name)
    except FileNotFoundError:
        console.print(f"[red]Profile '{name}' not found.[/red]")
        raise SystemExit(1)

    parts = key.split(".")
    current = data
    for part in parts[:-1]:
        if part not in current:
            current[part] = {}
        current = current[part]

    current[parts[-1]] = value
    save_profile(name, data)
    console.print(f"[green]Set {key} = {value} in profile '{name}'[/green]")


@profile.group(name="posts")
def profile_posts():
    """Manage posts (list, show, publish, set-topics)."""
    pass


@profile_posts.command(name="list")
@click.argument("profile_name", required=False)
@click.option("--status", type=click.Choice(["draft", "published"], case_sensitive=False), help="Filter by status.")
@click.option("--topic", help="Filter by topic (single).")
@click.option("--topics", help="Filter by topics (comma-separated, OR logic).")
def profile_posts_list(profile_name: str | None, status: str | None, topic: str | None, topics: str | None):
    """List posts in a profile."""
    name = profile_name or get_default_profile_name()
    if not name:
        console.print("[red]No profile found.[/red]")
        raise SystemExit(1)

    topic_list = topics.split(",") if topics else None

    all_posts = posts_module.list_profile_posts(name, status_filter=status, topic_filter=topic, topics_or=topic_list)

    if not all_posts:
        console.print("[yellow]No posts found.[/yellow]")
        return

    table = Table(title=f"Posts in profile '{name}'")
    table.add_column("Filename", style="cyan")
    table.add_column("Status", style="green")
    table.add_column("Created", style="dim")
    table.add_column("Template", style="magenta")
    table.add_column("Topics", style="yellow")

    for post in all_posts:
        topics_str = ", ".join(post.get("topics", [])) or "-"
        template_str = post.get("template") or "-"
        table.add_row(
            post["filename"],
            post["status"],
            post.get("created", ""),
            template_str,
            topics_str,
        )
    console.print(table)


@profile_posts.command(name="show")
@click.argument("filename")
@click.argument("profile_name", required=False)
def profile_posts_show(filename: str, profile_name: str | None):
    """Show a specific post."""
    name = profile_name or get_default_profile_name()
    if not name:
        console.print("[red]No profile found.[/red]")
        raise SystemExit(1)

    filepath = posts_module.get_post_by_filename(name, filename)
    if not filepath:
        console.print(f"[red]Post '{filename}' not found.[/red]")
        raise SystemExit(1)

    content = filepath.read_text(encoding="utf-8")
    console.print(f"\n[cyan]--- {filename} ---[/cyan]\n")
    console.print(content)


@profile_posts.command(name="publish")
@click.argument("filename")
@click.argument("profile_name", required=False)
def profile_posts_publish(filename: str, profile_name: str | None):
    """Publish a draft post."""
    name = profile_name or get_default_profile_name()
    if not name:
        console.print("[red]No profile found.[/red]")
        raise SystemExit(1)

    try:
        new_path = posts_module.publish_post(name, filename)
        console.print(f"[green]Published:[/green] {new_path.name}")
    except FileNotFoundError as e:
        console.print(f"[red]{e}[/red]")
        raise SystemExit(1)
    except ValueError as e:
        console.print(f"[red]{e}[/red]")
        raise SystemExit(1)


@profile_posts.command(name="set-topic")
@click.argument("filename")
@click.option("--topic", required=True, help="Topic to set (single).")
@click.option("--profile-name", "profile_name", default=None, help="Profile name (optional).")
def profile_posts_set_topic(filename: str, topic: str, profile_name: str | None):
    """Set a single topic on a post."""
    name = profile_name or get_default_profile_name()
    if not name:
        console.print("[red]No profile found.[/red]")
        raise SystemExit(1)

    filepath = posts_module.get_post_by_filename(name, filename)
    if not filepath:
        console.print(f"[red]Post '{filename}' not found.[/red]")
        raise SystemExit(1)

    posts_module.update_post_topics(name, filepath, [topic])
    console.print(f"[green]Set topic '{topic}' on {filename}[/green]")


@profile_posts.command(name="set-topics")
@click.argument("filename")
@click.option("--topics", required=True, help="Topics to set (comma-separated).")
@click.option("--profile-name", "profile_name", default=None, help="Profile name (optional).")
def profile_posts_set_topics(filename: str, topics: str, profile_name: str | None):
    """Set multiple topics on a post."""
    name = profile_name or get_default_profile_name()
    if not name:
        console.print("[red]No profile found.[/red]")
        raise SystemExit(1)

    filepath = posts_module.get_post_by_filename(name, filename)
    if not filepath:
        console.print(f"[red]Post '{filename}' not found.[/red]")
        raise SystemExit(1)

    topic_list = [t.strip() for t in topics.split(",")]
    posts_module.update_post_topics(name, filepath, topic_list)
    console.print(f"[green]Set topics on {filename}:[/green] {', '.join(topic_list)}")


@profile_posts.command(name="set-url")
@click.argument("filename")
@click.option("--url", required=True, help="LinkedIn URL.")
@click.option("--profile-name", "profile_name", default=None, help="Profile name (optional).")
def profile_posts_set_url(filename: str, url: str, profile_name: str | None):
    """Set LinkedIn URL on a post."""
    name = profile_name or get_default_profile_name()
    if not name:
        console.print("[red]No profile found.[/red]")
        raise SystemExit(1)

    filepath = posts_module.get_post_by_filename(name, filename)
    if not filepath:
        console.print(f"[red]Post '{filename}' not found.[/red]")
        raise SystemExit(1)

    posts_module.update_post_linkedin_url(name, filepath, url)
    console.print(f"[green]Set URL on {filename}:[/green] {url}")


@profile.group(name="topics")
def profile_topics():
    """Manage topics (list, add)."""
    pass


@profile_topics.command(name="list")
@click.argument("profile_name", required=False)
def profile_topics_list(profile_name: str | None):
    """List available topics for a profile."""
    name = profile_name or get_default_profile_name()
    if not name:
        console.print("[red]No profile found.[/red]")
        raise SystemExit(1)

    topics = get_available_topics(name)

    if not topics:
        console.print("[yellow]No topics found. Complete onboarding to define content pillars.[/yellow]")
        return

    console.print(f"[cyan]Available topics for '{name}':[/cyan]")
    for topic in topics:
        console.print(f"  - {topic}")


@profile_topics.command(name="add")
@click.argument("topic")
@click.argument("profile_name", required=False)
def profile_topics_add(topic: str, profile_name: str | None):
    """Add a custom topic (for manual addition - topics are mainly from pillars)."""
    console.print("[yellow]Topics are auto-generated from content_strategy.pillars.[/yellow]")
    console.print(
        "[yellow]To add custom topics to posts, use: postcraftin profile posts set-topics  --topics ...[/yellow]"
    )


@profile.group(name="brandguide")
def profile_brandguide():
    """Manage brand guide (generate, view)."""
    pass


@profile_brandguide.command(name="regenerate")
@click.argument("profile_name", required=False)
def profile_brandguide_regenerate(profile_name: str | None):
    """Regenerate brand guide files (voice.md, vocabulary.md, anti-patterns.md)."""
    from postcraftin import brandguide

    name = profile_name or get_default_profile_name()
    if not name:
        console.print("[red]No profile found.[/red]")
        raise SystemExit(1)

    try:
        profile_data = load_profile(name)
        brandguide.generate_all_brand_guides(name, profile_data)
        console.print(f"[green]Brand guide regenerated for '{name}'[/green]")
        console.print("[dim]Files: voice.md, vocabulary.md, anti-patterns.md[/dim]")
    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")
        raise SystemExit(1)


@profile.group(name="templates")
def profile_templates():
    """Manage templates (list, init)."""
    pass


@profile_templates.command(name="list")
@click.argument("profile_name", required=False)
def profile_templates_list(profile_name: str | None):
    """List available templates (shows source: package or profile)."""
    from postcraftin.templates import list_templates, get_template

    name = profile_name or get_default_profile_name()

    console.print(f"[cyan]Templates for profile '{name}':[/cyan]\n")

    for tpl_name in list_templates():
        tmpl = get_template(tpl_name, profile_name=name)
        source = tmpl["source"] if tmpl else "not found"
        console.print(f"  {tpl_name}: [{'green' if source == 'profile' else 'dim'}]{source}[/]")


@profile_templates.command(name="init")
@click.argument("profile_name", required=False)
def profile_templates_init(profile_name: str | None):
    """Copy default templates to profile's templates folder for customization."""
    from postcraftin.templates import copy_templates_to_profile

    name = profile_name or get_default_profile_name()
    if not name:
        console.print("[red]No profile found.[/red]")
        raise SystemExit(1)

    dest_dir = copy_templates_to_profile(name)
    console.print(f"[green]Templates copied to:[/green] {dest_dir}")
    console.print("[dim]You can now edit these templates in your profile folder.[/dim]")


@profile.group(name="examples")
def profile_examples():
    """Manage example posts (Beispiele für Few-Shot-Prompting)."""
    pass


@profile_examples.command(name="list")
@click.argument("profile_name", required=False)
def profile_examples_list(profile_name: str | None):
    """List all example posts."""
    name = profile_name or get_default_profile_name()
    if not name:
        console.print("[red]No profile found.[/red]")
        raise SystemExit(1)

    examples = posts_module.list_example_posts(name)
    if not examples:
        console.print("[yellow]No example posts found.[/yellow]")
        return

    console.print(f"[cyan]Example posts for '{name}':[/cyan]\n")
    for ex in examples:
        fm = ex["frontmatter"]
        console.print(f"  {ex['filename']} (Example #{fm.get('example_num', '?')}, {fm.get('word_count', 0)} words)")


@profile_examples.command(name="show")
@click.argument("filename")
@click.option("--profile-name", "profile_name", default=None, help="Profile name (optional).")
def profile_examples_show(filename: str, profile_name: str | None):
    """Show content of an example post."""
    name = profile_name or get_default_profile_name()
    if not name:
        console.print("[red]No profile found.[/red]")
        raise SystemExit(1)

    examples = posts_module.list_example_posts(name)
    example = next((e for e in examples if e["filename"] == filename), None)

    if not example:
        console.print(f"[red]Example not found: {filename}[/red]")
        raise SystemExit(1)

    console.print(f"[cyan]{example['filename']}[/cyan]\n")
    console.print(example["content"])


@profile_examples.command(name="add")
@click.argument("content")
@click.option("--profile-name", "profile_name", default=None, help="Profile name (optional).")
@click.option("--example-num", default=None, type=int, help="Example number (1-3). Auto-assigned if not provided.")
def profile_examples_add(content: str, profile_name: str | None, example_num: int | None):
    """Add a new example post."""
    name = profile_name or get_default_profile_name()
    if not name:
        console.print("[red]No profile found.[/red]")
        raise SystemExit(1)

    if example_num is None:
        examples = posts_module.list_example_posts(name)
        example_num = len(examples) + 1

    if example_num < 1 or example_num > 3:
        console.print("[red]Example number must be between 1 and 3.[/red]")
        raise SystemExit(1)

    filepath = posts_module.save_example_post(name, content, example_num)
    console.print(f"[green]Example #{example_num} saved:[/green] {filepath.name}")


@profile_examples.command(name="delete")
@click.argument("filename")
@click.option("--profile-name", "profile_name", default=None, help="Profile name (optional).")
@click.confirmation_option(prompt="Are you sure you want to delete this example?")
def profile_examples_delete(filename: str, profile_name: str | None):
    """Delete an example post."""
    name = profile_name or get_default_profile_name()
    if not name:
        console.print("[red]No profile found.[/red]")
        raise SystemExit(1)

    examples = posts_module.list_example_posts(name)
    example = next((e for e in examples if e["filename"] == filename), None)

    if not example:
        console.print(f"[red]Example not found: {filename}[/red]")
        raise SystemExit(1)

    example["path"].unlink()
    console.print(f"[green]Deleted:[/green] {filename}")


if __name__ == "__main__":
    cli()
