import pytest
from fastapi.testclient import TestClient

from postcraftin.api.app import app

client = TestClient(app)


def test_create_profile_success(mock_profiles_dir):
    resp = client.post(
        "/api/profiles",
        json={"name": "testuser", "identity": {"name": "Test", "job_title": "Dev", "industry": "Tech"}},
    )
    assert resp.status_code == 201
    data = resp.json()
    assert data["name"] == "testuser"
    assert "created_at" in data


def test_create_profile_duplicate(mock_profiles_dir):
    client.post(
        "/api/profiles",
        json={"name": "testuser", "identity": {"name": "Test", "job_title": "Dev", "industry": "Tech"}},
    )
    resp = client.post(
        "/api/profiles",
        json={"name": "testuser", "identity": {"name": "Test", "job_title": "Dev", "industry": "Tech"}},
    )
    assert resp.status_code == 409
    assert "already exists" in resp.json()["detail"]


def test_create_profile_minimal(mock_profiles_dir):
    resp = client.post("/api/profiles", json={"name": "minimal"})
    assert resp.status_code == 201
    data = resp.json()
    assert data["name"] == "minimal"
