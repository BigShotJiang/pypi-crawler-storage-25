"""Tests for modular onboarding."""

from unittest.mock import patch

from click.testing import CliRunner

from postcraftin.cli import cli


class TestModularOnboarding:
    """Tests for modular onboarding via --module flag."""

    def test_run_module_onboarding_voice_via_cli(self, mock_profiles_dir):
        """CLI onboard --module voice should dispatch to run_module_onboarding."""
        with patch("postcraftin.onboarding.run_module_onboarding") as mock_run:
            runner = CliRunner()
            result = runner.invoke(cli, ["onboard", "--name", "testprofile", "--module", "voice"])
            mock_run.assert_called_once_with("testprofile", "voice")
            assert result.exit_code == 0

    def test_run_module_onboarding_updates_profile(self, mock_profiles_dir):
        """run_module_onboarding() should save profile with updated module data."""
        from postcraftin.onboarding import run_module_onboarding

        with (
            patch("postcraftin.onboarding.load_profile") as mock_load,
            patch("postcraftin.onboarding.save_profile") as mock_save,
            patch("postcraftin.onboarding._run_voice_module") as mock_voice,
        ):
            mock_load.return_value = {
                "meta": {"version": "2.0", "interview_completed": False},
                "voice": {"archetype": "analytisch"},
                "identity": {},
                "audience": {},
                "content_strategy": {},
                "post_history": {},
                "technical_preferences": {},
            }
            mock_voice.return_value = {"voice": {"archetype": "storytelling", "formality": 4}}

            run_module_onboarding("testprofile", "voice")

            mock_save.assert_called_once()
            saved = mock_save.call_args[0][1]
            assert saved["voice"]["archetype"] == "storytelling"
            assert saved["meta"]["version"] == "2.0"
            assert saved["meta"]["interview_completed"] is True

    def test_cli_module_flag_accepts_valid_modules(self, cli_runner, mock_profiles_dir):
        """CLI --module should accept all valid module names."""
        for module in ["identity", "voice", "audience", "content_strategy", "technical_preferences"]:
            with patch("postcraftin.onboarding.run_module_onboarding") as mock_run:
                result = cli_runner.invoke(cli, ["onboard", "--name", "test", "--module", module])
                mock_run.assert_called_once_with("test", module)
                assert result.exit_code == 0
