"""Tests for profile management."""

from postcraftin.profile import migrate_profile


class TestProfileMigration:
    """Tests for migrate_profile()."""

    def test_migrate_v1_to_v2(self):
        """migrate_profile() should convert v1 schema to v2 with defaults."""
        v1_data = {
            "name": "Test User",
            "role": "Developer",
            "company": "Test Corp",
            "industry": "Tech",
            "years_experience": 5,
            "keywords": ["Python", "AI"],
            "tonality": "inspirierend",
            "language": "DE",
            "formality": 4,
        }
        result = migrate_profile(v1_data)
        assert result["meta"]["version"] == "2.0"
        assert result["identity"]["name"] == "Test User"
        assert result["identity"]["job_title"] == "Developer"
        assert result["voice"]["archetype"] == "inspirierend"
        assert result["voice"]["formality"] == 4
        assert result["audience"]["language"] == "DE"
        assert result["content_strategy"]["pillars"][0]["name"] == "General"
        assert result["technical_preferences"]["output_language"] == "DE"

    def test_migrate_v2_unchanged(self):
        """migrate_profile() should return already v2 data unchanged."""
        v2_data = {
            "meta": {"version": "2.0", "created_at": "now", "last_updated": "now", "interview_completed": True},
            "identity": {
                "name": "Test",
                "job_title": "",
                "company": "",
                "is_freelance": False,
                "industry": "",
                "years_experience": 0,
                "expertise_areas": [],
                "recent_transformation": "",
            },
            "voice": {
                "formality": 3,
                "archetype": "inspirierend",
                "humor_level": "gelegentlich",
                "sentence_style": "mixtur",
                "personal_ratio": "50%",
            },
            "audience": {
                "primary_roles": [],
                "secondary_roles": [],
                "industries": [],
                "seniority_focus": [],
                "company_size": [],
                "geography": "DACH",
                "language": "DE",
                "follower_count": 0,
                "connection_intent": "Follow",
            },
            "content_strategy": {
                "pillars": [{"name": "General", "weight": 100, "subtopics": [], "post_types": ["insight"]}],
                "posting_frequency": "3x per week",
                "preferred_days": ["Di", "Do", "Mo"],
                "preferred_time": "08:00-10:00",
                "content_goals": ["Thought Leadership"],
            },
            "post_history": {"top_posts": [], "stylesamples": [], "performance_metrics": {}},
            "technical_preferences": {
                "model": "",
                "output_language": "DE",
                "post_length_target": "Medium",
                "emoji_style": "Minimal",
                "hashtag_style": "Standard",
                "cta_default": "Question",
                "formatting_style": "Gemischt",
                "include_hook_suggestion": True,
                "post_variants_count": 1,
            },
        }
        result = migrate_profile(v2_data)
        assert result["meta"]["version"] == "2.0"
        assert result["identity"]["name"] == "Test"

    def test_migrate_empty_dict(self):
        """migrate_profile() should handle empty dict with defaults."""
        result = migrate_profile({})
        assert result["meta"]["version"] == "2.0"
        assert result["identity"]["name"] == ""
        assert result["identity"]["job_title"] == ""
        assert result["voice"]["archetype"] == "inspirierend"
        assert result["audience"]["language"] == "DE"
