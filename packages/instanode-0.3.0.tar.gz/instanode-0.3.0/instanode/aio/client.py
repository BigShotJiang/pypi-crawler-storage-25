"""
instanode.aio.client — AsyncClient for the instanode.dev API.

Wraps the synchronous InstanodeClient in ``asyncio.to_thread`` calls so every
method is awaitable without any additional dependencies.

Scope matches the synchronous client: Postgres provisioning, webhook receivers,
and account-level resource management. See ``instanode.client`` for notes on
what landed in 0.3.0 and what stayed on ``feature/full-api``.
"""

from __future__ import annotations

import asyncio
from typing import Any, List, Optional

from instanode.client import InstanodeClient
from instanode.types import ClaimResult, ProvisionResult, Resource


class AsyncClient:
    """
    Async client for the instanode.dev API.

    All methods are coroutines that run the underlying synchronous HTTP calls
    in a thread-pool executor via ``asyncio.to_thread``.

    Parameters
    ----------
    api_key : str, optional
        Bearer JWT. Falls back to ``INSTANODE_API_KEY``.
    base_url : str, optional
        Override API base URL. Falls back to ``INSTANODE_API_URL`` or
        ``https://api.instanode.dev``.
    timeout : float
        Per-request HTTP timeout in seconds. Default is 30.
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: float = 30,
    ) -> None:
        self._sync = InstanodeClient(api_key=api_key, base_url=base_url, timeout=timeout)

    # ------------------------------------------------------------------
    # Provisioning
    # ------------------------------------------------------------------

    async def provision_database(self, name: str) -> ProvisionResult:
        """Async variant of ``InstanodeClient.provision_database()``."""
        return await asyncio.to_thread(self._sync.provision_database, name)

    async def provision_webhook(self, name: str) -> ProvisionResult:
        """Async variant of ``InstanodeClient.provision_webhook()``."""
        return await asyncio.to_thread(self._sync.provision_webhook, name)

    # ------------------------------------------------------------------
    # Account
    # ------------------------------------------------------------------

    async def claim(self, token: str) -> ClaimResult:
        """Async variant of ``InstanodeClient.claim()``."""
        return await asyncio.to_thread(self._sync.claim, token)

    async def list_resources(self) -> List[Resource]:
        """Async variant of ``InstanodeClient.list_resources()``."""
        return await asyncio.to_thread(self._sync.list_resources)

    async def delete_resource(self, token: str) -> bool:
        """Async variant of ``InstanodeClient.delete_resource()``."""
        return await asyncio.to_thread(self._sync.delete_resource, token)

    async def get_api_token(self) -> str:
        """Async variant of ``InstanodeClient.get_api_token()``."""
        return await asyncio.to_thread(self._sync.get_api_token)

    async def __aenter__(self) -> "AsyncClient":
        return self

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        pass
