"""
instanode.aio — Async client for the instanode.dev API.

Uses asyncio + urllib via an executor thread-pool so there are still
zero external dependencies. For most workloads this is sufficient;
if you need true non-blocking I/O at high concurrency, wrap the sync
client with ``asyncio.to_thread`` or use a library like httpx/aiohttp.

Usage
-----
    import asyncio
    import instanode.aio

    async def main():
        client = instanode.aio.AsyncClient()
        db = await client.provision_database(name="my-app")
        print(db.connection_url)

    asyncio.run(main())
"""

from instanode.aio.client import AsyncClient

__all__ = ["AsyncClient"]
