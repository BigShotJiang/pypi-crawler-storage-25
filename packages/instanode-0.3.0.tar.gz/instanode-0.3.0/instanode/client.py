"""
client.py — InstanodeClient: synchronous client for the instanode.dev API.

Zero external dependencies. Uses only urllib from the standard library.
For the async variant, see ``instanode.aio``.

This 0.3.0 release is a deliberate trim to features that the production
API actually exposes today. Monitor/heartbeat, cache (Redis), MongoDB,
queue (NATS), and credential rotation are all on the roadmap but not
wired up on ``api.instanode.dev`` yet. Those surfaces live on the
``feature/full-api`` branch and will land in a later minor release once
the backend ships them.

Quick start
-----------
    import instanode

    client = instanode.Client()

    db = client.provision_database(name="my-side-project")
    # use db.connection_url with psycopg / asyncpg / SQLAlchemy / Prisma / etc.
"""

from __future__ import annotations

import os
from typing import Any, List, Optional

from instanode import _http
from instanode.types import (
    ClaimResult,
    InstanodeError,
    Limits,
    ProvisionResult,
    Resource,
)

_DEFAULT_BASE_URL = "https://api.instanode.dev"
_SDK_VERSION = "0.3.0"
_USER_AGENT = f"instanode-python-sdk/{_SDK_VERSION}"


class InstanodeClient:
    """
    Synchronous client for the instanode.dev API.

    Parameters
    ----------
    api_key : str, optional
        Bearer JWT for authenticated requests. Falls back to the
        ``INSTANODE_API_KEY`` environment variable. Without a key the
        client operates anonymously (24h TTL resources, 5 provisions
        per /24 subnet per day).
    base_url : str, optional
        Override the API base URL. Falls back to ``INSTANODE_API_URL``
        or ``https://api.instanode.dev``. Useful for local development:
        ``base_url="http://localhost:30080"``.
    timeout : float
        Per-request HTTP timeout in seconds. Default is 30.
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: float = 30,
    ) -> None:
        self._api_key: Optional[str] = api_key or os.environ.get("INSTANODE_API_KEY")
        raw_url = base_url or os.environ.get("INSTANODE_API_URL") or _DEFAULT_BASE_URL
        self._base_url = raw_url.rstrip("/")
        self._timeout = timeout

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _url(self, path: str) -> str:
        return f"{self._base_url}{path}"

    def _get(self, path: str) -> Any:
        return _http.get(self._url(path), self._api_key, _USER_AGENT, self._timeout)

    def _post(self, path: str, body: Optional[dict] = None) -> Any:
        return _http.post(self._url(path), body or {}, self._api_key, _USER_AGENT, self._timeout)

    def _delete(self, path: str) -> Any:
        return _http.delete(self._url(path), self._api_key, _USER_AGENT, self._timeout)

    # ------------------------------------------------------------------
    # Provisioning
    # ------------------------------------------------------------------

    def provision_database(self, name: str) -> ProvisionResult:
        """
        Provision a new shared Postgres database.

        Returns a ``connection_url`` shaped like
        ``postgres://user:pass@pg.instanode.dev:5432/dbname?sslmode=require``.
        pgvector is enabled on every database.

        - Anonymous: 10 MB / 2 connections / 24h TTL, 5 provisions per /24
          subnet per day.
        - Developer ($12/mo): 500 MB / 5 connections, permanent, no subnet
          cap (set ``INSTANODE_API_KEY``).

        Parameters
        ----------
        name : str
            Short kebab-case label for the resource. Required, 1–120 chars.
        """
        if not name or not str(name).strip():
            raise ValueError("name is required and must be a non-empty string")
        data = self._post("/db/new", {"name": name})
        result = ProvisionResult.from_dict(data)
        if result.note:
            print(f"[instanode.dev] {result.note}")
        return result

    def provision_webhook(self, name: str) -> ProvisionResult:
        """
        Provision a new webhook receiver.

        Returns a ``connection_url`` (the receive URL) shaped like
        ``https://api.instanode.dev/webhook/receive/<token>``. The URL
        accepts any HTTP method and stores the last N request bodies for
        later inspection.

        - Anonymous: 100 requests stored / 24h TTL.
        - Developer: 1000 requests stored, permanent.

        Parameters
        ----------
        name : str
            Short label for the resource. Required, 1–120 chars.
        """
        if not name or not str(name).strip():
            raise ValueError("name is required and must be a non-empty string")
        data = self._post("/webhook/new", {"name": name})
        result = ProvisionResult.from_dict(data)
        if result.note:
            print(f"[instanode.dev] {result.note}")
        return result

    # ------------------------------------------------------------------
    # Account — claim, list, delete, token
    # ------------------------------------------------------------------

    def claim(self, token: str) -> ClaimResult:
        """
        Claim an anonymous resource into the authenticated account.

        Call this when a paid user wants to keep a resource that was
        originally provisioned anonymously (24h TTL). Sets ``tier='paid'``
        and clears the expiry.

        Requires ``api_key`` / ``INSTANODE_API_KEY``.

        Parameters
        ----------
        token : str
            The resource token returned by a prior ``provision_*`` call.

        Raises
        ------
        InstanodeError
            401 if no API key. 404 if the token is unknown. 409 if the
            token has already been claimed by someone else.
        """
        if not token:
            raise ValueError("token is required")
        data = self._post("/api/me/claim", {"token": token})
        return ClaimResult.from_dict(data)

    def list_resources(self) -> List[Resource]:
        """
        List every resource owned by the authenticated account.

        Requires ``api_key`` / ``INSTANODE_API_KEY``.
        """
        data = self._get("/api/me/resources")
        items = data.get("items") or data.get("resources") or []
        return [Resource.from_dict(item) for item in items]

    def delete_resource(self, token: str) -> bool:
        """
        Delete a resource by token.

        Requires ``api_key`` / ``INSTANODE_API_KEY``. Returns True on success.
        """
        if not token:
            raise ValueError("token is required")
        data = self._delete(f"/api/me/resources/{token}")
        return bool(data.get("ok", True))

    def get_api_token(self) -> str:
        """
        Return the authenticated user's API bearer token.

        The token is a 30-day JWT. Typically called once from a session-
        authenticated context to mint a token that an agent can then use
        via ``api_key=``.

        Requires an active session cookie (not an existing API key), so
        this is mostly used from dashboard-style flows rather than from
        agent code.
        """
        data = self._get("/api/me/token")
        return str(data.get("token", ""))

    # ------------------------------------------------------------------
    # Context manager support
    # ------------------------------------------------------------------

    def __enter__(self) -> "InstanodeClient":
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        # No persistent connections to close; included so callers can
        # use `with instanode.Client() as client:` idiomatically.
        pass


# Convenience alias — canonical import path
Client = InstanodeClient
