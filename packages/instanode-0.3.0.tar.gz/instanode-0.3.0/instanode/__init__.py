"""
instanode — Official Python SDK for instanode.dev.

Zero-friction developer infrastructure: provision real Postgres databases
and webhook receivers with a single function call. No account required
for the free tier. Anonymous resources work immediately and expire in 24h.
Claim them from an authenticated account to make them permanent.

Quick start
-----------
    import instanode

    client = instanode.Client()

    db = client.provision_database(name="my-side-project")
    print("DSN:", db.connection_url)   # postgres://...@pg.instanode.dev:5432/db_...

    hook = client.provision_webhook(name="stripe-events")
    print("receive URL:", hook.connection_url)

Async
-----
    import asyncio
    import instanode.aio

    async def main():
        client = instanode.aio.AsyncClient()
        db = await client.provision_database(name="my-app")
        print(db.connection_url)

    asyncio.run(main())

Authentication
--------------
Set ``INSTANODE_API_KEY`` in your environment (a JWT minted from the
dashboard), or pass ``api_key=`` to the constructor. Without a key the
SDK operates anonymously.

Scope
-----
This 0.3.0 release covers the features that the live API exposes today:
Postgres provisioning, webhook receivers, and account-level resource
management (``claim``, ``list_resources``, ``delete_resource``,
``get_api_token``). Monitor/heartbeat, cache (Redis), MongoDB, NATS
queue, and credential rotation are on the roadmap and live on the
``feature/full-api`` branch until the backend wires them up.

Links
-----
- Homepage:       https://instanode.dev
- Documentation:  https://instanode.dev/llms.txt
- GitHub:         https://github.com/InstaNode-dev/sdk-python
"""

__version__ = "0.3.0"
__all__ = [
    # Client
    "Client",
    "InstanodeClient",
    # Result types
    "ProvisionResult",
    "Resource",
    "ClaimResult",
    "Limits",
    # Error
    "InstanodeError",
]

from instanode.client import Client, InstanodeClient
from instanode.types import (
    ClaimResult,
    InstanodeError,
    Limits,
    ProvisionResult,
    Resource,
)
