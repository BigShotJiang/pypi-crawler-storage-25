"""
types.py — Dataclass definitions for instanode.dev API response types.

All types are plain Python dataclasses with no external dependencies.

This 0.3.0 module reflects only the resources the live API currently
provisions: Postgres databases and webhook receivers. Monitor, heartbeat,
cache (Redis), MongoDB, queue, and rotate surfaces are parked on the
``feature/full-api`` branch until the backend exposes them.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional


@dataclass
class Limits:
    """Operational limits attached to a provisioned resource."""

    storage_mb: int = 0
    """Storage limit in megabytes. 0 if not applicable (e.g. webhooks)."""

    connections: Optional[int] = None
    """Maximum concurrent connections (Postgres). None if not applicable."""

    expires_in: Optional[str] = None
    """TTL for anonymous resources, e.g. '24h'. None for permanent resources."""

    requests_stored: Optional[int] = None
    """Max webhook requests retained. None for non-webhook resources."""

    @classmethod
    def from_dict(cls, data: dict) -> "Limits":
        return cls(
            storage_mb=int(data.get("storage_mb", 0)),
            connections=int(data["connections"]) if data.get("connections") is not None else None,
            expires_in=data.get("expires_in"),
            requests_stored=int(data["requests_stored"]) if data.get("requests_stored") is not None else None,
        )


@dataclass
class ProvisionResult:
    """Returned by ``provision_database()`` and ``provision_webhook()``."""

    ok: bool
    """Always True on success."""

    token: str
    """Unique resource identifier used to claim, list, or delete later."""

    connection_url: str
    """
    Plaintext connection string.
    Postgres: postgres://user:pass@pg.instanode.dev:5432/dbname?sslmode=require
    Webhook:  https://api.instanode.dev/webhook/receive/<token>
    """

    tier: str
    """Plan tier: 'anonymous' or 'paid'."""

    limits: Limits
    """Storage / connection / expiry limits for this resource."""

    name: Optional[str] = None
    """Label set at provision time."""

    note: Optional[str] = None
    """Server-side advisory message. Typically a claim/upgrade CTA when anonymous."""

    warning: Optional[str] = None
    """Set when a limit is approaching or has been exceeded."""

    upgrade: Optional[str] = None
    """URL the developer can visit to upgrade the plan."""

    expires_at: Optional[str] = None
    """ISO 8601 timestamp when the resource will be deleted. None for permanent."""

    storage_exceeded: Optional[bool] = None
    """True when the resource has exceeded its storage limit."""

    id: Optional[str] = None
    """Internal resource UUID."""

    @classmethod
    def from_dict(cls, data: dict) -> "ProvisionResult":
        raw_limits = data.get("limits", {})
        limits = Limits.from_dict(raw_limits)
        return cls(
            ok=bool(data.get("ok", True)),
            token=data["token"],
            connection_url=data["connection_url"],
            tier=data.get("tier", "anonymous"),
            limits=limits,
            name=data.get("name"),
            note=data.get("note"),
            warning=data.get("warning"),
            upgrade=data.get("upgrade"),
            expires_at=data.get("expires_at"),
            storage_exceeded=data.get("storage_exceeded"),
            id=data.get("id"),
        )


@dataclass
class Resource:
    """A provisioned resource as returned by ``list_resources()``."""

    id: str
    """Internal resource UUID."""

    token: str
    """Unique resource identifier."""

    resource_type: str
    """Resource class. Currently 'postgres' or 'webhook'."""

    tier: str
    """Plan tier: 'anonymous' or 'paid'."""

    status: str
    """Lifecycle state: 'active', 'deleted', or 'suspended'."""

    created_at: str
    """ISO 8601 provisioning timestamp."""

    name: Optional[str] = None
    """Label set at provision time."""

    expires_at: Optional[str] = None
    """ISO 8601 expiry timestamp. None for permanent resources."""

    storage_bytes: Optional[int] = None
    """Current storage usage in bytes."""

    storage_exceeded: Optional[bool] = None
    """True when this resource has exceeded its storage limit."""

    @classmethod
    def from_dict(cls, data: dict) -> "Resource":
        return cls(
            id=data["id"],
            token=data["token"],
            resource_type=data["resource_type"],
            tier=data.get("tier", "anonymous"),
            status=data.get("status", "active"),
            created_at=data["created_at"],
            name=data.get("name"),
            expires_at=data.get("expires_at"),
            storage_bytes=int(data["storage_bytes"]) if data.get("storage_bytes") is not None else None,
            storage_exceeded=data.get("storage_exceeded"),
        )


@dataclass
class ClaimResult:
    """Returned by ``claim()``. Confirms transfer of an anonymous resource to the account."""

    ok: bool
    """Always True on success."""

    token: str
    """The resource token that was claimed (echoed back)."""

    tier: Optional[str] = None
    """New tier after claim (typically 'paid')."""

    message: Optional[str] = None
    """Human-readable confirmation from the server."""

    @classmethod
    def from_dict(cls, data: dict) -> "ClaimResult":
        return cls(
            ok=bool(data.get("ok", True)),
            token=str(data.get("token", "")),
            tier=data.get("tier"),
            message=data.get("message"),
        )


class InstanodeError(Exception):
    """
    Raised when the instanode.dev API responds with a non-2xx status code.

    Attributes
    ----------
    status_code : int
        HTTP status code returned by the server.
    code : str
        Machine-readable error code (e.g. 'not_found', 'rate_limited').
    message : str
        Human-readable error description.
    """

    def __init__(self, status_code: int, code: str, message: str) -> None:
        self.status_code = status_code
        self.code = code
        self.message = message
        super().__init__(f"instanode.dev API error {status_code} ({code}): {message}")

    def is_not_found(self) -> bool:
        """True when the error is 404 Not Found."""
        return self.status_code == 404

    def is_unauthorized(self) -> bool:
        """True when the error is 401 Unauthorized."""
        return self.status_code == 401

    def is_forbidden(self) -> bool:
        """True when the error is 403 Forbidden."""
        return self.status_code == 403

    def is_rate_limited(self) -> bool:
        """True when the error is 429 Too Many Requests."""
        return self.status_code == 429

    def is_conflict(self) -> bool:
        """True when the error is 409 Conflict."""
        return self.status_code == 409

    def is_service_unavailable(self) -> bool:
        """True when the error is 503 Service Unavailable."""
        return self.status_code == 503
