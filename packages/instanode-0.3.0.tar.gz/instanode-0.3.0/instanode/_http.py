"""
_http.py — Thin urllib.request wrapper for instanode.dev API calls.

Zero external dependencies. Uses only the Python standard library.
All public symbols are internal — import from instanode.client instead.
"""

from __future__ import annotations

import json
import urllib.error
import urllib.request
from typing import Any, Optional
from urllib.request import urlopen  # exported for test patching


def _build_request(
    method: str,
    url: str,
    body: Optional[dict],
    api_key: Optional[str],
    user_agent: str,
    timeout: float,
) -> urllib.request.Request:
    """Build a urllib.request.Request with JSON body and auth headers."""
    data: Optional[bytes] = None
    headers: dict[str, str] = {
        "Accept": "application/json",
        "User-Agent": user_agent,
    }

    if body is not None:
        data = json.dumps(body).encode("utf-8")
        headers["Content-Type"] = "application/json"

    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"

    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    return req


def _do_request(
    method: str,
    url: str,
    body: Optional[dict],
    api_key: Optional[str],
    user_agent: str,
    timeout: float,
) -> Any:
    """
    Execute an HTTP request and return the parsed JSON response.

    Raises
    ------
    instanode.types.InstanodeError
        On any non-2xx response.
    urllib.error.URLError
        On network-level errors (DNS failure, connection refused, timeout).
    """
    # Import here to avoid circular dependency at module load time.
    from instanode.types import InstanodeError

    req = _build_request(method, url, body, api_key, user_agent, timeout)

    try:
        with urlopen(req, timeout=timeout) as resp:
            raw = resp.read()
            if not raw:
                return {}
            return json.loads(raw.decode("utf-8"))
    except urllib.error.HTTPError as exc:
        raw = exc.read().decode("utf-8", errors="replace")
        status = exc.code
        try:
            payload = json.loads(raw)
            code = payload.get("error", str(status))
            message = payload.get("message", raw)
        except (json.JSONDecodeError, AttributeError):
            code = str(status)
            message = raw or exc.reason or "unexpected error"
        raise InstanodeError(status, code, message) from None


def get(
    url: str,
    api_key: Optional[str],
    user_agent: str,
    timeout: float,
) -> Any:
    """HTTP GET — returns parsed JSON."""
    return _do_request("GET", url, None, api_key, user_agent, timeout)


def post(
    url: str,
    body: Optional[dict],
    api_key: Optional[str],
    user_agent: str,
    timeout: float,
) -> Any:
    """HTTP POST with JSON body — returns parsed JSON."""
    return _do_request("POST", url, body, api_key, user_agent, timeout)


def delete(
    url: str,
    api_key: Optional[str],
    user_agent: str,
    timeout: float,
) -> Any:
    """HTTP DELETE — returns parsed JSON."""
    return _do_request("DELETE", url, None, api_key, user_agent, timeout)
