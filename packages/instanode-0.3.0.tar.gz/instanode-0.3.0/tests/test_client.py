"""
test_client.py — Unit tests for InstanodeClient.

All HTTP calls are mocked — no network access required. Covers the
live-only surface: provisioning (db + webhook), claim, list_resources,
delete_resource, get_api_token, auth/base-url handling, and error shapes.
"""

from __future__ import annotations

import json
import os
import sys
import unittest
import urllib.error
from unittest.mock import MagicMock, patch

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from instanode.client import InstanodeClient, _DEFAULT_BASE_URL
from instanode.types import (
    ClaimResult,
    InstanodeError,
    ProvisionResult,
    Resource,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _mock_response(data: dict, status: int = 200):
    """Build a mock object shaped like ``urllib.request.urlopen()`` returns."""
    raw = json.dumps(data).encode("utf-8")
    mock_resp = MagicMock()
    mock_resp.read.return_value = raw
    mock_resp.__enter__ = lambda s: s
    mock_resp.__exit__ = MagicMock(return_value=False)
    mock_resp.status = status
    return mock_resp


def _mock_http_error(status: int, body: dict, url: str = "https://api.instanode.dev/db/new"):
    """Build a mock ``urllib.error.HTTPError``."""
    raw = json.dumps(body).encode("utf-8")
    exc = urllib.error.HTTPError(url=url, code=status, msg=str(status), hdrs={}, fp=None)
    exc.read = lambda: raw  # type: ignore[assignment]
    return exc


def _provision_body(url: str = "postgres://u:p@pg.instanode.dev:5432/db_abc") -> dict:
    return {
        "ok": True,
        "token": "abc-123",
        "connection_url": url,
        "tier": "anonymous",
        "limits": {"storage_mb": 10, "connections": 2, "expires_in": "24h"},
    }


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------


class TestConfiguration(unittest.TestCase):
    def test_default_base_url(self):
        client = InstanodeClient()
        self.assertEqual(client._base_url, _DEFAULT_BASE_URL)

    def test_base_url_arg_overrides_default(self):
        client = InstanodeClient(base_url="http://localhost:30080/")
        # Trailing slash should be stripped
        self.assertEqual(client._base_url, "http://localhost:30080")

    def test_base_url_env_fallback(self):
        with patch.dict(os.environ, {"INSTANODE_API_URL": "http://example.test"}, clear=False):
            client = InstanodeClient()
            self.assertEqual(client._base_url, "http://example.test")

    def test_api_key_arg_overrides_env(self):
        with patch.dict(os.environ, {"INSTANODE_API_KEY": "env-key"}, clear=False):
            client = InstanodeClient(api_key="arg-key")
            self.assertEqual(client._api_key, "arg-key")

    def test_api_key_env_fallback(self):
        with patch.dict(os.environ, {"INSTANODE_API_KEY": "env-key"}, clear=False):
            client = InstanodeClient()
            self.assertEqual(client._api_key, "env-key")

    def test_context_manager(self):
        with InstanodeClient() as client:
            self.assertIsInstance(client, InstanodeClient)


# ---------------------------------------------------------------------------
# provision_database
# ---------------------------------------------------------------------------


class TestProvisionDatabase(unittest.TestCase):
    @patch("instanode._http.urlopen")
    def test_returns_provision_result(self, mock_urlopen):
        mock_urlopen.return_value = _mock_response(_provision_body())
        client = InstanodeClient()
        res = client.provision_database(name="my-db")
        self.assertIsInstance(res, ProvisionResult)
        self.assertEqual(res.token, "abc-123")
        self.assertTrue(res.connection_url.startswith("postgres://"))
        self.assertEqual(res.tier, "anonymous")
        self.assertEqual(res.limits.storage_mb, 10)
        self.assertEqual(res.limits.connections, 2)

    @patch("instanode._http.urlopen")
    def test_sends_name_in_body(self, mock_urlopen):
        mock_urlopen.return_value = _mock_response(_provision_body())
        client = InstanodeClient()
        client.provision_database(name="my-db")
        req = mock_urlopen.call_args[0][0]
        body = json.loads(req.data.decode())
        self.assertEqual(body, {"name": "my-db"})
        self.assertTrue(req.full_url.endswith("/db/new"))

    def test_rejects_empty_name(self):
        client = InstanodeClient()
        with self.assertRaises(ValueError):
            client.provision_database(name="")

    def test_rejects_whitespace_name(self):
        client = InstanodeClient()
        with self.assertRaises(ValueError):
            client.provision_database(name="   ")

    @patch("instanode._http.urlopen")
    def test_503_raises_instanode_error(self, mock_urlopen):
        mock_urlopen.side_effect = _mock_http_error(
            503, {"code": "unavailable", "message": "provisioner down"}
        )
        client = InstanodeClient()
        with self.assertRaises(InstanodeError) as ctx:
            client.provision_database(name="my-db")
        self.assertTrue(ctx.exception.is_service_unavailable())

    @patch("instanode._http.urlopen")
    def test_429_raises_rate_limited(self, mock_urlopen):
        mock_urlopen.side_effect = _mock_http_error(
            429, {"code": "rate_limited", "message": "slow down"}
        )
        client = InstanodeClient()
        with self.assertRaises(InstanodeError) as ctx:
            client.provision_database(name="x")
        self.assertTrue(ctx.exception.is_rate_limited())


# ---------------------------------------------------------------------------
# provision_webhook
# ---------------------------------------------------------------------------


class TestProvisionWebhook(unittest.TestCase):
    @patch("instanode._http.urlopen")
    def test_returns_webhook_url(self, mock_urlopen):
        body = _provision_body(url="https://api.instanode.dev/webhook/receive/xyz-789")
        body["token"] = "xyz-789"
        body["limits"] = {"requests_stored": 100, "expires_in": "24h"}
        mock_urlopen.return_value = _mock_response(body)
        client = InstanodeClient()
        res = client.provision_webhook(name="stripe-events")
        self.assertEqual(res.token, "xyz-789")
        self.assertIn("/webhook/receive/", res.connection_url)
        self.assertEqual(res.limits.requests_stored, 100)

    @patch("instanode._http.urlopen")
    def test_sends_name(self, mock_urlopen):
        mock_urlopen.return_value = _mock_response(_provision_body())
        client = InstanodeClient()
        client.provision_webhook(name="wh-1")
        req = mock_urlopen.call_args[0][0]
        body = json.loads(req.data.decode())
        self.assertEqual(body, {"name": "wh-1"})
        self.assertTrue(req.full_url.endswith("/webhook/new"))

    def test_rejects_empty_name(self):
        client = InstanodeClient()
        with self.assertRaises(ValueError):
            client.provision_webhook(name="")


# ---------------------------------------------------------------------------
# claim
# ---------------------------------------------------------------------------


class TestClaim(unittest.TestCase):
    @patch("instanode._http.urlopen")
    def test_claim_success(self, mock_urlopen):
        mock_urlopen.return_value = _mock_response(
            {"ok": True, "token": "abc-123", "tier": "paid", "message": "claimed"}
        )
        client = InstanodeClient(api_key="k")
        res = client.claim(token="abc-123")
        self.assertIsInstance(res, ClaimResult)
        self.assertEqual(res.token, "abc-123")
        self.assertEqual(res.tier, "paid")

    @patch("instanode._http.urlopen")
    def test_claim_hits_correct_endpoint(self, mock_urlopen):
        mock_urlopen.return_value = _mock_response({"ok": True, "token": "t"})
        client = InstanodeClient(api_key="k")
        client.claim(token="t")
        req = mock_urlopen.call_args[0][0]
        self.assertTrue(req.full_url.endswith("/api/me/claim"))
        body = json.loads(req.data.decode())
        self.assertEqual(body, {"token": "t"})

    def test_claim_rejects_empty_token(self):
        client = InstanodeClient(api_key="k")
        with self.assertRaises(ValueError):
            client.claim(token="")

    @patch("instanode._http.urlopen")
    def test_claim_401_raises_unauthorized(self, mock_urlopen):
        mock_urlopen.side_effect = _mock_http_error(
            401, {"code": "unauthorized", "message": "missing token"}
        )
        client = InstanodeClient()
        with self.assertRaises(InstanodeError) as ctx:
            client.claim(token="any")
        self.assertTrue(ctx.exception.is_unauthorized())


# ---------------------------------------------------------------------------
# list_resources, delete_resource, get_api_token
# ---------------------------------------------------------------------------


class TestResourceManagement(unittest.TestCase):
    @patch("instanode._http.urlopen")
    def test_list_resources_empty(self, mock_urlopen):
        mock_urlopen.return_value = _mock_response({"items": []})
        client = InstanodeClient(api_key="k")
        self.assertEqual(client.list_resources(), [])

    @patch("instanode._http.urlopen")
    def test_list_resources_parses_items(self, mock_urlopen):
        mock_urlopen.return_value = _mock_response(
            {
                "items": [
                    {
                        "id": "r-1",
                        "token": "tok-1",
                        "resource_type": "postgres",
                        "tier": "paid",
                        "status": "active",
                        "created_at": "2026-04-19T10:00:00Z",
                    }
                ]
            }
        )
        client = InstanodeClient(api_key="k")
        resources = client.list_resources()
        self.assertEqual(len(resources), 1)
        self.assertIsInstance(resources[0], Resource)
        self.assertEqual(resources[0].resource_type, "postgres")
        self.assertEqual(resources[0].tier, "paid")

    @patch("instanode._http.urlopen")
    def test_list_resources_hits_correct_path(self, mock_urlopen):
        mock_urlopen.return_value = _mock_response({"items": []})
        client = InstanodeClient(api_key="k")
        client.list_resources()
        req = mock_urlopen.call_args[0][0]
        self.assertTrue(req.full_url.endswith("/api/me/resources"))

    @patch("instanode._http.urlopen")
    def test_delete_resource_returns_true(self, mock_urlopen):
        mock_urlopen.return_value = _mock_response({"ok": True})
        client = InstanodeClient(api_key="k")
        self.assertTrue(client.delete_resource("tok-1"))

    @patch("instanode._http.urlopen")
    def test_delete_resource_hits_correct_path(self, mock_urlopen):
        mock_urlopen.return_value = _mock_response({"ok": True})
        client = InstanodeClient(api_key="k")
        client.delete_resource("tok-1")
        req = mock_urlopen.call_args[0][0]
        self.assertTrue(req.full_url.endswith("/api/me/resources/tok-1"))
        self.assertEqual(req.get_method(), "DELETE")

    def test_delete_rejects_empty_token(self):
        client = InstanodeClient(api_key="k")
        with self.assertRaises(ValueError):
            client.delete_resource("")

    @patch("instanode._http.urlopen")
    def test_delete_404_raises_not_found(self, mock_urlopen):
        mock_urlopen.side_effect = _mock_http_error(
            404, {"code": "not_found", "message": "unknown token"}
        )
        client = InstanodeClient(api_key="k")
        with self.assertRaises(InstanodeError) as ctx:
            client.delete_resource("missing")
        self.assertTrue(ctx.exception.is_not_found())

    @patch("instanode._http.urlopen")
    def test_get_api_token_returns_string(self, mock_urlopen):
        mock_urlopen.return_value = _mock_response({"token": "eyJabc..."})
        client = InstanodeClient(api_key="session")
        token = client.get_api_token()
        self.assertEqual(token, "eyJabc...")

    @patch("instanode._http.urlopen")
    def test_get_api_token_hits_correct_path(self, mock_urlopen):
        mock_urlopen.return_value = _mock_response({"token": "x"})
        client = InstanodeClient(api_key="session")
        client.get_api_token()
        req = mock_urlopen.call_args[0][0]
        self.assertTrue(req.full_url.endswith("/api/me/token"))


if __name__ == "__main__":
    unittest.main()
