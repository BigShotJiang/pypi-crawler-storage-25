"""
test_types.py — Unit tests for the instanode.types dataclasses.

Covers the trimmed 0.3.0 type surface: Limits, ProvisionResult, Resource,
ClaimResult, InstanodeError.
"""

from __future__ import annotations

import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from instanode.types import (
    ClaimResult,
    InstanodeError,
    Limits,
    ProvisionResult,
    Resource,
)


# ---------------------------------------------------------------------------
# Limits
# ---------------------------------------------------------------------------


class TestLimits(unittest.TestCase):
    def test_all_fields(self):
        limits = Limits.from_dict(
            {"storage_mb": 500, "connections": 5, "expires_in": "24h"}
        )
        self.assertEqual(limits.storage_mb, 500)
        self.assertEqual(limits.connections, 5)
        self.assertEqual(limits.expires_in, "24h")

    def test_missing_fields_use_defaults(self):
        limits = Limits.from_dict({})
        self.assertEqual(limits.storage_mb, 0)
        self.assertIsNone(limits.connections)
        self.assertIsNone(limits.expires_in)
        self.assertIsNone(limits.requests_stored)

    def test_webhook_shape(self):
        limits = Limits.from_dict({"requests_stored": 1000, "expires_in": None})
        self.assertEqual(limits.requests_stored, 1000)
        self.assertEqual(limits.storage_mb, 0)

    def test_connections_none_allowed(self):
        limits = Limits.from_dict({"storage_mb": 10})
        self.assertIsNone(limits.connections)


# ---------------------------------------------------------------------------
# ProvisionResult
# ---------------------------------------------------------------------------


class TestProvisionResult(unittest.TestCase):
    def _postgres_raw(self) -> dict:
        return {
            "ok": True,
            "token": "tok-1",
            "connection_url": "postgres://u:p@h:5432/db",
            "tier": "anonymous",
            "limits": {"storage_mb": 10, "connections": 2, "expires_in": "24h"},
            "name": "my-db",
            "note": "claim at https://instanode.dev/start?token=tok-1",
        }

    def test_postgres_shape(self):
        res = ProvisionResult.from_dict(self._postgres_raw())
        self.assertTrue(res.ok)
        self.assertEqual(res.token, "tok-1")
        self.assertEqual(res.connection_url, "postgres://u:p@h:5432/db")
        self.assertEqual(res.tier, "anonymous")
        self.assertEqual(res.name, "my-db")
        self.assertIn("claim", res.note or "")
        self.assertEqual(res.limits.storage_mb, 10)
        self.assertEqual(res.limits.connections, 2)

    def test_webhook_shape(self):
        res = ProvisionResult.from_dict(
            {
                "ok": True,
                "token": "wh-1",
                "connection_url": "https://api.instanode.dev/webhook/receive/wh-1",
                "tier": "paid",
                "limits": {"requests_stored": 1000},
            }
        )
        self.assertEqual(res.tier, "paid")
        self.assertEqual(res.limits.requests_stored, 1000)
        self.assertEqual(res.limits.storage_mb, 0)

    def test_defaults_when_optional_fields_missing(self):
        minimal = {
            "token": "t",
            "connection_url": "postgres://x",
        }
        res = ProvisionResult.from_dict(minimal)
        self.assertTrue(res.ok)
        self.assertEqual(res.tier, "anonymous")
        self.assertIsNone(res.name)
        self.assertIsNone(res.note)
        self.assertIsNone(res.warning)


# ---------------------------------------------------------------------------
# Resource
# ---------------------------------------------------------------------------


class TestResource(unittest.TestCase):
    def test_full_shape(self):
        r = Resource.from_dict(
            {
                "id": "uuid-1",
                "token": "tok-1",
                "resource_type": "postgres",
                "tier": "paid",
                "status": "active",
                "created_at": "2026-04-19T10:00:00Z",
                "name": "prod-db",
                "storage_bytes": 4096,
            }
        )
        self.assertEqual(r.resource_type, "postgres")
        self.assertEqual(r.tier, "paid")
        self.assertEqual(r.storage_bytes, 4096)

    def test_minimal_shape(self):
        r = Resource.from_dict(
            {
                "id": "u",
                "token": "t",
                "resource_type": "webhook",
                "created_at": "2026-04-19T10:00:00Z",
            }
        )
        self.assertEqual(r.status, "active")
        self.assertEqual(r.tier, "anonymous")
        self.assertIsNone(r.storage_bytes)


# ---------------------------------------------------------------------------
# ClaimResult
# ---------------------------------------------------------------------------


class TestClaimResult(unittest.TestCase):
    def test_full(self):
        c = ClaimResult.from_dict(
            {"ok": True, "token": "tok-1", "tier": "paid", "message": "claimed"}
        )
        self.assertTrue(c.ok)
        self.assertEqual(c.token, "tok-1")
        self.assertEqual(c.tier, "paid")

    def test_defaults(self):
        c = ClaimResult.from_dict({})
        self.assertTrue(c.ok)
        self.assertEqual(c.token, "")
        self.assertIsNone(c.tier)


# ---------------------------------------------------------------------------
# InstanodeError
# ---------------------------------------------------------------------------


class TestInstanodeError(unittest.TestCase):
    def test_construction_and_message(self):
        err = InstanodeError(404, "not_found", "resource missing")
        self.assertEqual(err.status_code, 404)
        self.assertEqual(err.code, "not_found")
        self.assertEqual(err.message, "resource missing")
        self.assertIn("404", str(err))
        self.assertIn("not_found", str(err))

    def test_status_helpers(self):
        self.assertTrue(InstanodeError(404, "", "").is_not_found())
        self.assertTrue(InstanodeError(401, "", "").is_unauthorized())
        self.assertTrue(InstanodeError(403, "", "").is_forbidden())
        self.assertTrue(InstanodeError(429, "", "").is_rate_limited())
        self.assertTrue(InstanodeError(409, "", "").is_conflict())
        self.assertTrue(InstanodeError(503, "", "").is_service_unavailable())

    def test_negative_cases(self):
        err = InstanodeError(500, "server_error", "oops")
        self.assertFalse(err.is_not_found())
        self.assertFalse(err.is_unauthorized())
        self.assertFalse(err.is_conflict())


if __name__ == "__main__":
    unittest.main()
