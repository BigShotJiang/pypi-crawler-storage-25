.. automodule:: pytools.graph
