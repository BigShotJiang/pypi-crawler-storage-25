<div align="center">
    <img src="docs/logo.png" alt="Logo" width="80" height="80">
</div>

# Crontable

A lightweight Python scheduler that unifies two task types in a single loop:

- **DateTask** — one-shot tasks triggered at a specific datetime, loaded from a semicolon-delimited CSV file
- **CronTask** — repeating tasks driven by standard 5-field cron expressions (or friendly `@aliases`), loaded from a crontab-style text file

Comes with a CLI entry-point and an optional tkinter GUI (`crontable-gui`).

---

## Installation

```bash
pip install crontable
```

Requires Python ≥ 3.10. The only runtime dependency is [`croniter`](https://pypi.org/project/croniter/).

---

## Quick start

### Programmatic usage

```python
from datetime import datetime, timedelta
from crontable import Scheduler, SubprocessExecutor, DateTask, CronTask

executor = SubprocessExecutor()
scheduler = Scheduler(executor=executor, interval=30.0)

scheduler.add_tasks([
    DateTask(
        scheduled_at=datetime.now() + timedelta(minutes=5),
        action="echo 'hello in 5 minutes'",
        name="greeting",
    ),
    CronTask(
        cron_expr="0 9 * * 1-5",
        action="python C:/scripts/daily_report.py",
        name="weekday_report",
    ),
])

try:
    scheduler.run()
except KeyboardInterrupt:
    scheduler.stop()
```

### From a CSV file

```
DATE;NAME;COMMAND
01/01/2027 09:00;morning_report;echo "Good morning"
15/06/2027 14:30;backup;python C:\scripts\backup.py
```

```python
from crontable import FileSource, Scheduler, SubprocessExecutor

source = FileSource("tasks.csv")
scheduler = Scheduler(executor=SubprocessExecutor(), interval=60.0)
scheduler.add_tasks(source.load())
scheduler.run()
```

### From a crontab file

```
# Every weekday at 9 am
0 9 * * 1-5   python C:\scripts\report.py
# French alias — every Monday at midnight
@lundi        echo "Bonne semaine"
```

```python
from crontable import FileSource, Scheduler, SubprocessExecutor

source = FileSource("jobs.txt")
scheduler = Scheduler(executor=SubprocessExecutor(), interval=60.0)
scheduler.add_tasks(source.load())
scheduler.run()
```

### Hot-reload on file change

Pass the source to the scheduler and set `reload_on_change=True`. Every tick,
the scheduler checks `source.has_changed()` and atomically swaps in
`source.load()` when the file is touched. A failing parse (half-saved edit,
invalid syntax) is logged and the previous task list is kept.

```python
source = FileSource("jobs.txt")
scheduler = Scheduler(
    executor=SubprocessExecutor(),
    interval=5.0,
    source=source,
    reload_on_change=True,
)
scheduler.add_tasks(source.load())
scheduler.run()
```

See [examples/](examples/) for more runnable patterns.

---

## CLI

```bash
# Programmatic demo
crontable

# Load from file (auto-detects CSV vs crontab by extension)
crontable tasks.csv
crontable crontab.txt
```

## GUI

```bash
crontable-gui
```

Features: file browser, configurable polling interval, live task list with right-click "Run now", color-coded log, hot-reload on file change, persistent config.

Build a standalone Windows `.exe`:

```bat
scripts\build_exe.bat
```

---

## Supported cron aliases

| Alias                 | Expression          | Alias                  | Expression      |
| --------------------- | ------------------- | ---------------------- | --------------- |
| `@hourly`             | `0 * * * *`         | `@daily` / `@midnight` | `0 0 * * *`     |
| `@weekly`             | `0 0 * * 0`         | `@monthly`             | `0 0 1 * *`     |
| `@annually` / `@year` | `0 0 1 1 *`         | `@noon`                | `0 12 * * *`    |
| `@biweekly`           | `0 0 * * 0,2,4`     | `@bimonthly`           | `0 0 1,15 * *`  |
| `@mon` … `@sun`       | weekday at midnight | `@lundi` … `@dimanche` | French weekdays |

---

## Path aliases in commands

| Alias      | Expands to                 |
| ---------- | -------------------------- |
| `@python`  | Current Python interpreter |
| `@home`    | User home directory        |
| `@desktop` | `~/Desktop`                |

---

## Development

```bash
pip install -e ".[dev]"
pytest
```
