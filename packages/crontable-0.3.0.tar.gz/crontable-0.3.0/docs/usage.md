# Usage Guide

## Installation

```bash
pip install crontable
# with dev dependencies (pytest, coverage)
pip install crontable[dev]
```

---

## CSV file format

The CSV parser expects a semicolon-delimited file with at least a `DATE` column.

```csv
DATE;NAME;COMMAND
01/01/2027 09:00;morning_report;echo "Good morning"
15/06/2027 14:30;backup_task;python C:\scripts\backup.py
31/12/2027 23:59;year_end;echo "Happy New Year"
```

- **DATE** — `dd/mm/YYYY HH:MM` by default (configurable via `CsvParser(date_format=...)`)
- **COMMAND** — shell command or path (optional, configurable column name)
- **NAME** — task label (optional, configurable column name)
- Any additional columns are stored in `task.metadata`

### Custom delimiter / date format

```python
from crontable.scheduler.parsers.csv_parser import CsvParser

tasks = CsvParser(
    date_format="%Y-%m-%d %H:%M",
    delimiter=",",
).parse("tasks.csv")
```

---

## Crontab file format

Standard 5-field cron expressions plus `@alias` shortcuts:

```
# min hour dom month dow  command
0 9 * * 1-5             python C:\scripts\report.py
*/30 * * * *             echo "Half-hourly tick"
@daily                   python C:\scripts\cleanup.py
@lundi                   echo "Bon lundi"
```

### Supported aliases

| Alias                  | Cron expression | Description                 |
| ---------------------- | --------------- | --------------------------- |
| `@hourly`              | `0 * * * *`     | Every hour                  |
| `@daily` / `@midnight` | `0 0 * * *`     | Every day at midnight       |
| `@noon`                | `0 12 * * *`    | Every day at noon           |
| `@weekly`              | `0 0 * * 0`     | Every Sunday at midnight    |
| `@monthly`             | `0 0 1 * *`     | 1st of every month          |
| `@annually` / `@year`  | `0 0 1 1 *`     | 1st January                 |
| `@biweekly`            | `0 0 * * 0,2,4` | Sun / Tue / Thu at midnight |
| `@bimonthly`           | `0 0 1,15 * *`  | 1st and 15th of every month |
| `@mon` … `@sun`        | `0 0 * * N`     | English weekday at midnight |
| `@lundi` … `@dimanche` | `0 0 * * N`     | French weekday at midnight  |

---

## Callable actions

Instead of a shell string, you can pass a Python callable as the action:

```python
from crontable import DateTask, CronTask, Scheduler, SubprocessExecutor
from datetime import datetime, timedelta

def on_fire(metadata: dict) -> None:
    print(f"Fired! metadata={metadata}")

scheduler = Scheduler(executor=SubprocessExecutor(), interval=5.0)
scheduler.add_tasks([
    # DateTask callables receive task.metadata as argument
    DateTask(
        scheduled_at=datetime.now() + timedelta(seconds=10),
        action=on_fire,
        name="demo",
        metadata={"env": "prod"},
    ),
    # CronTask callables are called with no arguments
    CronTask(
        cron_expr="* * * * *",
        action=lambda: print("tick"),
        name="heartbeat",
    ),
])
scheduler.run()
```

---

## Path aliases in commands

| Alias      | Expands to                                    |
| ---------- | --------------------------------------------- |
| `@python`  | Current Python interpreter (`sys.executable`) |
| `@home`    | User home directory (`Path.home()`)           |
| `@desktop` | `Path.home() / "Desktop"`                     |

```
# crontab.txt
@daily   @python @home/scripts/cleanup.py
@weekly  @python @desktop/report.py
```

---

## Hot-reload

`FileSource` tracks the file's `mtime`. When the file is modified on disk the scheduler can reload without restarting:

```python
source = FileSource("tasks.csv")
scheduler = Scheduler(executor=SubprocessExecutor(), interval=60.0)
scheduler.add_tasks(source.load())

while True:
    time.sleep(30)
    new_tasks = source.load_if_changed()
    if new_tasks is not None:
        scheduler.reload_tasks(new_tasks)
```

The GUI handles this automatically every 5 seconds.

---

## Subprocess timeout

```python
executor = SubprocessExecutor(timeout=30.0)  # kill after 30 s
```

---

## Building a standalone Windows exe

```bat
pip install pyinstaller
scripts\build_exe.bat
# → dist\crontable-gui.exe
```
