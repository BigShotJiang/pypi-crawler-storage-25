# Crontable Documentation

Crontable is a lightweight Python scheduler that merges two scheduling paradigms into one unified loop.

## Core concepts

| Concept                | Description                                                                                          |
| ---------------------- | ---------------------------------------------------------------------------------------------------- |
| **DateTask**           | One-shot task fired at a specific `datetime`. Loaded from a CSV file.                                |
| **CronTask**           | Repeating task driven by a 5-field cron expression or an `@alias`. Loaded from a crontab file.       |
| **Scheduler**          | Polling loop that checks tasks every `interval` seconds and delegates execution to an `Executor`.    |
| **SubprocessExecutor** | Runs string actions as shell commands, or calls Python callables directly.                           |
| **FileSource**         | Reads a CSV or crontab file, dispatches to the right parser, and tracks file changes for hot-reload. |

## Package layout

```
src/crontable/
├── __init__.py                   # Public API surface
├── main.py                       # CLI entry-point
├── gui.py                        # tkinter GUI entry-point
└── scheduler/
    ├── core/
    │   ├── task.py               # Abstract Task base class
    │   └── scheduler.py          # Scheduler loop
    ├── tasks/
    │   ├── date_task.py          # One-shot DateTask
    │   └── cron_task.py          # Repeating CronTask
    ├── executors/
    │   ├── base_executor.py      # Executor ABC
    │   └── subprocess_executor.py
    ├── parsers/
    │   ├── csv_parser.py         # CSV → DateTask list
    │   └── cron_parser.py        # Crontab → CronTask list
    └── sources/
        └── file_source.py        # File dispatcher + hot-reload
```

## Navigation

- [Usage guide](usage.md) — detailed examples and configuration options
