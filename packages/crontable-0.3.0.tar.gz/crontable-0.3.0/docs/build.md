# Build Guide

## Prerequisites

- Python 3.10+
- [pip](https://pip.pypa.io/)

---

## Development setup

Install the package in editable mode with all dev dependencies:

```bash
pip install -e ".[dev]"
```

---

## Running tests

```bash
# All tests
pytest tests/

# Single file
pytest tests/test_scheduler.py

# Single test by name
pytest tests/test_scheduler.py::TestSchedulerTick::test_executes_due_task

# With coverage report
pytest --cov=crontable --cov-report=term-missing tests/
```

---

## Building the Python package (sdist + wheel)

The project uses [Hatchling](https://hatch.pypa.io/) as its build backend.

```bash
pip install build
python -m build
```

Artifacts are written to `dist/`:

| File | Description |
|------|-------------|
| `dist/crontable-*.tar.gz` | Source distribution (sdist) |
| `dist/crontable-*.whl` | Wheel |

---

## Building the standalone Windows executable

The GUI can be packaged into a single `.exe` with [PyInstaller](https://pyinstaller.org/).

### Install PyInstaller

```bash
pip install pyinstaller
```

### Build

**Option A — batch script (recommended on Windows):**

```bat
scripts\build_exe.bat
```

**Option B — direct PyInstaller call from the project root:**

```bash
pyinstaller crontable-gui.spec --clean --noconfirm
```

Output: `dist\crontable-gui.exe`

### What the spec includes

- Entry-point: `src/crontable/gui.py`
- Bundled assets: `assets/` (icon.ico, icon.png)
- Hidden imports: `croniter`, `dateutil`, `dateutil.tz`, `dateutil.relativedelta`
- Excluded: `pytest`, `unittest`, `doctest`
- No console window (`console=False`)
- UPX compression enabled

---

## CI / CD

| Workflow | File | Trigger | What it does |
|----------|------|---------|--------------|
| Tests | `.github/workflows/tests.yml` | push / PR | Runs `pytest` |
| Build EXE | `.github/workflows/build_exe.yml` | push to `main`/`master` | Builds `crontable-gui.exe` with PyInstaller on `windows-latest`, zips it, uploads as a GitHub Actions artifact |
| Publish to PyPI | `.github/workflows/publish.yml` | GitHub Release published | Builds sdist + wheel and publishes to PyPI via OIDC trusted publishing |

### Releasing a new version

1. Bump `version` in [pyproject.toml](../pyproject.toml).
2. Commit and push to `main`.
3. Create a GitHub Release — the publish workflow triggers automatically and uploads to PyPI.
