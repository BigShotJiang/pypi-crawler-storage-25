# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Commands

```bash
# Install in editable mode with dev dependencies
pip install -e ".[dev]"

# Run all tests
pytest tests/

# Run a single test file
pytest tests/test_scheduler.py

# Run a single test by name
pytest tests/test_scheduler.py::TestSchedulerTick::test_executes_due_task

# Run with coverage
pytest --cov=crontable --cov-report=term-missing tests/

# Launch CLI demo
python -m crontable.main
python -m crontable.main tasks.csv
python -m crontable.main crontab.txt

# Launch GUI
python -m crontable.gui

# Build standalone Windows exe (requires pyinstaller)
scripts\build_exe.bat
```

## Architecture

The package is in `src/crontable/` with two entry-points (`main.py` CLI, `gui.py` tkinter GUI) and a `scheduler/` sub-package.

### Task types

- **`DateTask`** — one-shot; `is_due()` returns True once when `now >= scheduled_at`, then `mark_executed()` sets `_executed=True` so `next_run()` returns `None`
- **`CronTask`** — repeating; backed by `croniter`, `mark_executed()` advances `_next` to the following occurrence

### Execution flow

`Scheduler._tick()` → if `reload_on_change=True` and a `source` was provided, call `_check_and_reload()` (see Hot-reload below) → snapshot tasks under `_lock` → for each due task call `executor.run(task)` then `task.mark_executed(now)` in a `finally` block (so mark_executed always runs even on executor error) → prune tasks whose `next_run()` is `None` (DateTasks after execution) and log the next upcoming run.

`Scheduler(executor=None)` defaults to `AutoExecutor()` (lazy import inside the ctor to avoid a circular module load).

### Executor architecture — facade + strategies

`AutoExecutor` (in `src/crontable/scheduler/executors/auto.py`) is the default **facade**. It dispatches `task` to one of the built-in **strategies** based on `task.action`:

- `callable(action)` → `InProcessCallableExecutor` (synchronous, in-process). If the task carries a `metadata` attr (DateTask pattern), the dict is passed as the sole arg; otherwise `action()` is called with no args.
- `isinstance(action, str)` and non-empty → `ShellCommandExecutor`. Resolves `@python`/`@home`/`@desktop` aliases, uses first-token-directory as cwd if applicable, picks `shell=True` on Windows cmd.exe built-ins (`echo`, `dir` …), `shell=False` otherwise. Overridable via `shell=` on the ctor.
- Otherwise → warning, no-op.

`AutoExecutor.register(predicate, executor)` lets users plug in custom strategies. Predicates are checked **LIFO** (newest wins), so later registrations override earlier ones (including the built-ins if the predicate matches the same shape). Duck-typed: any object with a callable `run(task)` is accepted — no need to inherit from `Executor`.

Strategy modules are **siblings** — no inheritance between them:

- `shell.py` → `ShellCommandExecutor` (was the string path of `SubprocessExecutor`)
- `callable_.py` → `InProcessCallableExecutor` (was the callable path of `SubprocessExecutor`)
- `python_script_executor.py` → `PythonScriptExecutor` (no longer inherits from `SubprocessExecutor`; fixed `.py` script + metadata → argv list)
- `multiprocess.py` → `MultiprocessExecutor` (runs a top-level callable in a child process; reaps finished children on each `run()` so PIDs don't leak, plus a `close(timeout)` for shutdown)
- `_paths.py` → shared helpers: `PATH_ALIASES`, `resolve_aliases`, `split_cwd`, `needs_shell`

Backwards-compat aliases kept so existing user code doesn't break: `SubprocessExecutor = AutoExecutor`, `FunctionExecutor = MultiprocessExecutor`. The old module files `subprocess_executor.py` / `function_executor.py` are thin shims that re-export the new names.

### File loading

`FileSource` dispatches by extension: `.csv` → `CsvParser` → `List[DateTask]`; `.txt`/`.cron` → `CronParser` → `List[CronTask]`. Raises `ValueError("Unsupported...")` at construction for other extensions. Tracks `_last_mtime` set at construction and after each `load()` so `has_changed()` returns False until the file is modified.

`CsvParser` reads the file with `utf-8-sig` encoding to transparently strip the BOM that Excel-exported CSVs add.

`CronParser` expands `@alias` tokens (including French weekday names like `@lundi`) via the `REPLACEMENTS` dict before parsing. Exact token matching prevents `@monthly` being confused with `@mon`.

### Hot-reload

`Scheduler` accepts an optional `source: TaskSource` plus `reload_on_change: bool = False`. When both are set, `_tick()` calls `_check_and_reload()` first: `source.has_changed()` → if True, `source.load()` → `reload_tasks(fresh)`. Exceptions from either call are caught inside `_check_and_reload` and logged; the current task list is kept, so a half-saved edit or parse error never wipes the schedule. `TaskSource` is a `typing.Protocol` (structural) — `FileSource` satisfies it without inheritance. Default is `False` to preserve existing opt-in behavior.

### Thread safety

`Scheduler._lock` guards `_tasks`. Callers should use the public `list_tasks()`, `add_tasks()`, `clear_tasks()` and `reload_tasks()` methods rather than touching `_tasks` directly. The GUI polls every 5 s via `after()`, calling `source.has_changed()` and `scheduler.reload_tasks()` when the source file changes (pre-dates the built-in `reload_on_change` hook).

### Public API (`src/crontable/__init__.py`)

Exports: `Scheduler`, `Task`, `Executor`, `DateTask`, `CronTask`, `AutoExecutor`, `ShellCommandExecutor`, `InProcessCallableExecutor`, `PythonScriptExecutor`, `MultiprocessExecutor`, `FileSource`, plus deprecated aliases `SubprocessExecutor`, `FunctionExecutor`.

## Key test files

- `tests/conftest.py` — shared fixtures including `RecordingExecutor` (records tasks without side-effects) and `BrokenExecutor` (always raises)
- `tests/test_scheduler.py` — tick logic, error resilience, lifecycle, thread safety
- `tests/test_executors.py` — callable dispatch, alias resolution, timeout, subprocess errors
- `tests/test_file_source.py` — extension dispatch, mtime change detection, `load_if_changed`
- `tests/test_parsers.py` — CSV edge cases, all cron aliases including French weekdays
