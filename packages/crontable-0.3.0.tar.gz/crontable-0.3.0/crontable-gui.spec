# crontable-gui.spec  –  PyInstaller build definition
# Run from project root:  pyinstaller scripts/crontable-gui.spec --clean --noconfirm
# Or double-click:        scripts/build_exe.bat
# Out:                    dist/crontable-gui.exe

from pathlib import Path

block_cipher = None
src = str(Path("src").resolve())

a = Analysis(
    [str(Path("src/crontable/gui.py").resolve())],
    pathex=[src],
    binaries=[],
    datas=[
        ("assets", "assets"),  # bundles icon.ico + icon.png
    ],
    hiddenimports=[
        "croniter",
        "dateutil",
        "dateutil.tz",
        "dateutil.relativedelta",
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=["pytest", "unittest", "doctest"],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name="crontable-gui",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,          # no console window (windowed app)
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon="assets/icon.ico",
)
