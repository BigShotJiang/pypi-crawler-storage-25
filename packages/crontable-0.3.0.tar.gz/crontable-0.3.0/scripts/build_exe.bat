@echo off
setlocal
:: Move to project root (parent of this scripts/ folder)
cd /d "%~dp0.."

echo [crontable-gui] Building Windows executable...
echo.

where pyinstaller >nul 2>&1
if errorlevel 1 (
    echo ERROR: pyinstaller not found.
    echo Install it with:  pip install pyinstaller
    exit /b 1
)

pyinstaller crontable-gui.spec --clean --noconfirm

if errorlevel 1 (
    echo.
    echo BUILD FAILED.
    pause
    exit /b 1
)

echo.
echo ============================================================
echo  Build complete:  dist\crontable-gui.exe
echo ============================================================
pause
