"""Tests for the Scheduler (tick logic, lifecycle, thread safety)."""

import threading
import time
from datetime import datetime, timedelta

import pytest
from crontable.scheduler.core.scheduler import Scheduler
from crontable.scheduler.executors.base_executor import Executor
from crontable.scheduler.tasks.cron_task import CronTask
from crontable.scheduler.tasks.date_task import DateTask

from tests.conftest import BrokenExecutor, RecordingExecutor

# ---------------------------------------------------------------------------
# _tick() — task selection
# ---------------------------------------------------------------------------


class TestSchedulerTick:
    def test_executes_due_task(self, scheduler, recording_executor, date_task_past):
        scheduler.add_tasks([date_task_past])
        scheduler._tick()
        assert recording_executor.count == 1

    def test_skips_future_task(self, scheduler, recording_executor, date_task_future):
        scheduler.add_tasks([date_task_future])
        scheduler._tick()
        assert recording_executor.count == 0

    def test_executes_all_due_tasks_in_one_tick(self, recording_executor, past_dt):
        s = Scheduler(executor=recording_executor, interval=0.1)
        tasks = [DateTask(past_dt, action=f"echo {i}") for i in range(5)]
        s.add_tasks(tasks)
        s._tick()
        assert recording_executor.count == 5

    def test_only_due_tasks_fire_among_mixed_list(self, recording_executor, past_dt, future_dt):
        s = Scheduler(executor=recording_executor, interval=0.1)
        s.add_tasks(
            [
                DateTask(past_dt, action="echo due"),
                DateTask(future_dt, action="echo future"),
                DateTask(past_dt, action="echo due2"),
            ]
        )
        s._tick()
        assert recording_executor.count == 2

    def test_one_shot_task_pruned_after_execution(self, scheduler, date_task_past):
        scheduler.add_tasks([date_task_past])
        scheduler._tick()
        assert len(scheduler._tasks) == 0

    def test_cron_task_not_pruned_after_execution(self, recording_executor):
        s = Scheduler(executor=recording_executor, interval=0.1)
        task = CronTask("* * * * *", action="echo")
        s.add_tasks([task])
        # CronTask is due only when _next <= now; don't tick here, just verify retention
        assert len(s._tasks) == 1

    def test_no_double_fire_across_consecutive_ticks(self, scheduler, recording_executor, date_task_past):
        scheduler.add_tasks([date_task_past])
        scheduler._tick()
        scheduler._tick()  # task was pruned after first tick
        assert recording_executor.count == 1


# ---------------------------------------------------------------------------
# _tick() — error handling
# ---------------------------------------------------------------------------


class TestSchedulerTickErrors:
    def test_executor_exception_does_not_propagate(self, broken_executor, past_dt):
        s = Scheduler(executor=broken_executor, interval=0.1)
        s.add_tasks([DateTask(past_dt, action="echo")])
        s._tick()  # must not raise

    def test_task_marked_executed_even_on_executor_error(self, broken_executor, past_dt):
        s = Scheduler(executor=broken_executor, interval=0.1)
        task = DateTask(past_dt, action="echo")
        s.add_tasks([task])
        s._tick()
        assert task._executed is True

    def test_task_pruned_even_on_executor_error(self, broken_executor, past_dt):
        s = Scheduler(executor=broken_executor, interval=0.1)
        s.add_tasks([DateTask(past_dt, action="echo")])
        s._tick()
        assert len(s._tasks) == 0

    def test_remaining_tasks_fire_after_one_fails(self, past_dt):
        executed = []

        class PartialExecutor(Executor):
            def run(self, task):
                if task.name == "bad":
                    raise RuntimeError("boom")
                executed.append(task.name)

        s = Scheduler(executor=PartialExecutor(), interval=0.1)
        s.add_tasks(
            [
                DateTask(past_dt, action="echo", name="bad"),
                DateTask(past_dt, action="echo", name="good"),
            ]
        )
        s._tick()
        assert "good" in executed


# ---------------------------------------------------------------------------
# Task management
# ---------------------------------------------------------------------------


class TestSchedulerTaskManagement:
    def test_add_tasks_accumulates(self, scheduler, date_task_past, date_task_future):
        scheduler.add_tasks([date_task_past])
        scheduler.add_tasks([date_task_future])
        assert len(scheduler._tasks) == 2

    def test_clear_tasks_empties_list(self, scheduler, date_task_past):
        scheduler.add_tasks([date_task_past])
        scheduler.clear_tasks()
        assert len(scheduler._tasks) == 0

    def test_reload_tasks_replaces_list(self, scheduler, date_task_past, date_task_future):
        scheduler.add_tasks([date_task_past])
        scheduler.reload_tasks([date_task_future])
        assert len(scheduler._tasks) == 1
        assert scheduler._tasks[0] is date_task_future

    def test_reload_clears_previously_added_tasks(self, scheduler, date_task_past):
        scheduler.add_tasks([date_task_past])
        scheduler.reload_tasks([])
        assert scheduler._tasks == []

    def test_list_tasks_returns_snapshot(self, scheduler, date_task_past, date_task_future):
        scheduler.add_tasks([date_task_past, date_task_future])
        snapshot = scheduler.list_tasks()
        assert len(snapshot) == 2
        # Mutating the snapshot must not affect the scheduler
        snapshot.clear()
        assert len(scheduler.list_tasks()) == 2

    def test_executor_property_exposes_the_executor(self, recording_executor):
        s = Scheduler(executor=recording_executor, interval=0.1)
        assert s.executor is recording_executor


# ---------------------------------------------------------------------------
# Lifecycle
# ---------------------------------------------------------------------------


class TestSchedulerLifecycle:
    def test_run_and_stop(self, scheduler):
        t = threading.Thread(target=scheduler.run, daemon=True)
        t.start()
        time.sleep(0.15)
        scheduler.stop()
        t.join(timeout=1.0)
        assert not t.is_alive()

    def test_stop_before_run_does_not_hang(self, scheduler):
        scheduler.stop()
        # run() should exit immediately since stop_event is already set
        t = threading.Thread(target=scheduler.run, daemon=True)
        t.start()
        t.join(timeout=1.0)
        assert not t.is_alive()

    def test_tasks_fire_during_run(self, recording_executor, past_dt):
        s = Scheduler(executor=recording_executor, interval=0.05)
        s.add_tasks([DateTask(past_dt, action="echo")])
        t = threading.Thread(target=s.run, daemon=True)
        t.start()
        time.sleep(0.2)
        s.stop()
        t.join(timeout=1.0)
        assert recording_executor.count >= 1


# ---------------------------------------------------------------------------
# Thread safety
# ---------------------------------------------------------------------------


class TestSchedulerThreadSafety:
    def test_reload_concurrent_with_run(self, recording_executor, future_dt):
        s = Scheduler(executor=recording_executor, interval=0.01)
        runner = threading.Thread(target=s.run, daemon=True)
        runner.start()
        for _ in range(30):
            s.reload_tasks([DateTask(future_dt, action="echo")])
        s.stop()
        runner.join(timeout=1.0)
        assert not runner.is_alive()

    def test_add_tasks_concurrent_with_run(self, recording_executor, future_dt):
        s = Scheduler(executor=recording_executor, interval=0.01)
        runner = threading.Thread(target=s.run, daemon=True)
        runner.start()
        for _ in range(30):
            s.add_tasks([DateTask(future_dt, action="echo")])
        s.stop()
        runner.join(timeout=1.0)
        assert not runner.is_alive()


# ---------------------------------------------------------------------------
# _tick() — hot-reload from a TaskSource
# ---------------------------------------------------------------------------


class _FakeSource:
    """Minimal TaskSource double — no filesystem involved."""

    def __init__(self, tasks_by_call):
        self._queue = list(tasks_by_call)
        self.changed = False
        self.load_calls = 0
        self.raise_on_load = False
        self.raise_on_has_changed = False

    def has_changed(self) -> bool:
        if self.raise_on_has_changed:
            raise RuntimeError("stat boom")
        return self.changed

    def load(self):
        self.load_calls += 1
        if self.raise_on_load:
            raise ValueError("parse boom")
        self.changed = False
        return self._queue.pop(0) if self._queue else []


class TestSchedulerHotReload:
    def test_disabled_by_default_does_not_touch_source(self, recording_executor, future_dt):
        source = _FakeSource([[DateTask(future_dt, action="echo fresh")]])
        source.changed = True
        s = Scheduler(executor=recording_executor, interval=0.1, source=source)
        s._tick()
        assert source.load_calls == 0

    def test_opt_in_reload_swaps_tasks_when_source_changed(self, recording_executor, future_dt):
        fresh = [DateTask(future_dt, action="echo fresh", name="fresh")]
        source = _FakeSource([fresh])
        source.changed = True
        s = Scheduler(
            executor=recording_executor,
            interval=0.1,
            source=source,
            reload_on_change=True,
        )
        s.add_tasks([DateTask(future_dt, action="echo stale", name="stale")])
        s._tick()
        names = [t.name for t in s.list_tasks()]
        assert names == ["fresh"]
        assert source.load_calls == 1

    def test_no_reload_when_source_unchanged(self, recording_executor, future_dt):
        source = _FakeSource([])
        source.changed = False
        s = Scheduler(
            executor=recording_executor,
            interval=0.1,
            source=source,
            reload_on_change=True,
        )
        original = [DateTask(future_dt, action="echo", name="keep")]
        s.add_tasks(original)
        s._tick()
        assert source.load_calls == 0
        assert [t.name for t in s.list_tasks()] == ["keep"]

    def test_load_exception_keeps_current_task_list(self, recording_executor, future_dt):
        source = _FakeSource([])
        source.changed = True
        source.raise_on_load = True
        s = Scheduler(
            executor=recording_executor,
            interval=0.1,
            source=source,
            reload_on_change=True,
        )
        kept = [DateTask(future_dt, action="echo", name="kept")]
        s.add_tasks(kept)
        s._tick()  # must not raise
        assert [t.name for t in s.list_tasks()] == ["kept"]

    def test_has_changed_exception_keeps_current_task_list(self, recording_executor, future_dt):
        source = _FakeSource([])
        source.raise_on_has_changed = True
        s = Scheduler(
            executor=recording_executor,
            interval=0.1,
            source=source,
            reload_on_change=True,
        )
        kept = [DateTask(future_dt, action="echo", name="kept")]
        s.add_tasks(kept)
        s._tick()  # must not raise
        assert source.load_calls == 0
        assert [t.name for t in s.list_tasks()] == ["kept"]

    def test_reload_flag_without_source_is_noop(self, recording_executor, future_dt):
        s = Scheduler(
            executor=recording_executor,
            interval=0.1,
            source=None,
            reload_on_change=True,
        )
        s.add_tasks([DateTask(future_dt, action="echo", name="keep")])
        s._tick()  # must not raise
        assert [t.name for t in s.list_tasks()] == ["keep"]
