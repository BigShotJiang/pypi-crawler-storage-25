"""Tests for FileSource (dispatch, hot-reload detection)."""

import os
import time

import pytest
from crontable.scheduler.sources.file_source import FileSource
from crontable.scheduler.tasks.cron_task import CronTask
from crontable.scheduler.tasks.date_task import DateTask

# ---------------------------------------------------------------------------
# Loading
# ---------------------------------------------------------------------------


class TestFileSourceLoad:
    def test_csv_file_produces_date_tasks(self, csv_file):
        tasks = FileSource(csv_file).load()
        assert len(tasks) == 2
        assert all(isinstance(t, DateTask) for t in tasks)

    def test_txt_file_produces_cron_tasks(self, cron_file):
        tasks = FileSource(cron_file).load()
        assert len(tasks) == 2
        assert all(isinstance(t, CronTask) for t in tasks)

    def test_cron_extension_produces_cron_tasks(self, tmp_path):
        p = tmp_path / "jobs.cron"
        p.write_text("* * * * * echo ok\n", encoding="utf-8")
        tasks = FileSource(p).load()
        assert len(tasks) == 1
        assert isinstance(tasks[0], CronTask)

    def test_path_as_string_accepted(self, csv_file):
        tasks = FileSource(str(csv_file)).load()
        assert len(tasks) == 2

    def test_load_returns_list(self, csv_file):
        result = FileSource(csv_file).load()
        assert isinstance(result, list)


class TestFileSourceErrors:
    def test_unsupported_extension_raises_at_construction(self, tmp_path):
        p = tmp_path / "data.json"
        with pytest.raises(ValueError, match="Unsupported"):
            FileSource(p)

    def test_nonexistent_csv_raises_file_not_found(self, tmp_path):
        with pytest.raises(FileNotFoundError):
            FileSource(tmp_path / "ghost.csv").load()

    def test_nonexistent_txt_raises_file_not_found(self, tmp_path):
        with pytest.raises(FileNotFoundError):
            FileSource(tmp_path / "ghost.txt").load()


# ---------------------------------------------------------------------------
# Change detection
# ---------------------------------------------------------------------------


class TestFileSourceChangeDetection:
    def test_has_changed_false_right_after_construction(self, csv_file):
        source = FileSource(csv_file)
        assert source.has_changed() is False

    def test_has_changed_false_right_after_load(self, csv_file):
        source = FileSource(csv_file)
        source.load()
        assert source.has_changed() is False

    def test_has_changed_true_after_file_modified(self, csv_file):
        source = FileSource(csv_file)
        source.load()
        # Force mtime to a future value so the change is always detectable
        new_mtime = time.time() + 2
        os.utime(csv_file, (new_mtime, new_mtime))
        assert source.has_changed() is True

    def test_has_changed_resets_to_false_after_reload(self, csv_file):
        source = FileSource(csv_file)
        source.load()
        new_mtime = time.time() + 2
        os.utime(csv_file, (new_mtime, new_mtime))
        assert source.has_changed() is True
        source.load()  # resets _last_mtime
        assert source.has_changed() is False

    def test_has_changed_returns_false_on_missing_file(self, tmp_path):
        p = tmp_path / "will_be_deleted.csv"
        p.write_text("DATE\n", encoding="utf-8")
        source = FileSource(p)
        source.load()
        p.unlink()
        assert source.has_changed() is False  # OSError is silenced → False


class TestFileSourceLoadIfChanged:
    def test_returns_none_when_unchanged(self, csv_file):
        source = FileSource(csv_file)
        source.load()
        assert source.load_if_changed() is None

    def test_returns_tasks_when_file_changed(self, csv_file):
        source = FileSource(csv_file)
        source.load()
        new_mtime = time.time() + 2
        os.utime(csv_file, (new_mtime, new_mtime))
        result = source.load_if_changed()
        assert result is not None
        assert len(result) == 2

    def test_load_if_changed_resets_change_flag(self, csv_file):
        source = FileSource(csv_file)
        source.load()
        new_mtime = time.time() + 2
        os.utime(csv_file, (new_mtime, new_mtime))
        source.load_if_changed()
        assert source.load_if_changed() is None  # flag was reset
