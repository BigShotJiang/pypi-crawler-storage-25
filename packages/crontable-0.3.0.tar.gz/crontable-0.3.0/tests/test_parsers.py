"""Tests for CsvParser and CronParser."""

import csv
from pathlib import Path

import pytest
from crontable.scheduler.parsers.cron_parser import REPLACEMENTS, CronParser
from crontable.scheduler.parsers.csv_parser import CsvParser
from crontable.scheduler.tasks.cron_task import CronTask
from crontable.scheduler.tasks.date_task import DateTask

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def write_csv(path: Path, rows: list, delimiter: str = ";") -> Path:
    with path.open("w", newline="", encoding="utf-8") as fh:
        csv.writer(fh, delimiter=delimiter).writerows(rows)
    return path


# ---------------------------------------------------------------------------
# CsvParser
# ---------------------------------------------------------------------------


class TestCsvParserHappyPath:
    def test_uses_csv_file_fixture(self, csv_file):
        tasks = CsvParser().parse(csv_file)
        assert len(tasks) == 2
        assert all(isinstance(t, DateTask) for t in tasks)

    def test_name_and_action_from_fixture(self, csv_file):
        tasks = CsvParser().parse(csv_file)
        names = {t.name for t in tasks}
        assert names == {"morning", "noon"}

    def test_single_valid_row(self, tmp_path):
        path = write_csv(
            tmp_path / "d.csv",
            [
                ["DATE", "COMMAND", "NAME"],
                ["01/01/2099 10:00", "echo hi", "mytask"],
            ],
        )
        tasks = CsvParser().parse(path)
        assert len(tasks) == 1
        assert tasks[0].action == "echo hi"
        assert tasks[0].name == "mytask"

    def test_multiple_rows(self, tmp_path):
        path = write_csv(
            tmp_path / "d.csv",
            [
                ["DATE", "COMMAND"],
                ["01/01/2099 10:00", "echo a"],
                ["02/01/2099 10:00", "echo b"],
                ["03/01/2099 10:00", "echo c"],
            ],
        )
        assert len(CsvParser().parse(path)) == 3

    def test_metadata_stores_all_columns(self, tmp_path):
        path = write_csv(
            tmp_path / "d.csv",
            [
                ["DATE", "COMMAND", "EXTRA", "FOO"],
                ["01/01/2099 10:00", "echo", "val_extra", "val_foo"],
            ],
        )
        task = CsvParser().parse(path)[0]
        assert task.metadata["EXTRA"] == "val_extra"
        assert task.metadata["FOO"] == "val_foo"

    def test_custom_delimiter(self, tmp_path):
        path = write_csv(tmp_path / "d.csv", [["DATE", "COMMAND"], ["01/01/2099 10:00", "echo hi"]], delimiter=",")
        tasks = CsvParser(delimiter=",").parse(path)
        assert len(tasks) == 1

    def test_custom_date_format(self, tmp_path):
        path = write_csv(
            tmp_path / "d.csv",
            [
                ["DATE", "COMMAND"],
                ["2099-12-31 23:59", "echo"],
            ],
        )
        tasks = CsvParser(date_format="%Y-%m-%d %H:%M").parse(path)
        assert len(tasks) == 1
        assert tasks[0].scheduled_at.year == 2099

    def test_date_column_case_insensitive(self, tmp_path):
        path = write_csv(
            tmp_path / "d.csv",
            [
                ["date", "command"],
                ["01/01/2099 10:00", "echo"],
            ],
        )
        tasks = CsvParser().parse(path)
        assert len(tasks) == 1

    def test_empty_header_only_returns_no_tasks(self, tmp_path):
        path = write_csv(tmp_path / "d.csv", [["DATE", "COMMAND"]])
        assert CsvParser().parse(path) == []

    def test_no_command_column_action_is_empty(self, tmp_path):
        path = write_csv(
            tmp_path / "d.csv",
            [
                ["DATE"],
                ["01/01/2099 10:00"],
            ],
        )
        task = CsvParser().parse(path)[0]
        assert task.action == ""


class TestCsvParserEdgeCases:
    def test_skips_row_with_invalid_date(self, tmp_path):
        path = write_csv(
            tmp_path / "d.csv",
            [
                ["DATE", "COMMAND"],
                ["NOT-A-DATE", "echo bad"],
            ],
        )
        assert CsvParser().parse(path) == []

    def test_mixed_valid_and_invalid_rows(self, tmp_path):
        path = write_csv(
            tmp_path / "d.csv",
            [
                ["DATE", "COMMAND"],
                ["01/01/2099 10:00", "echo ok"],
                ["OOPS", "echo fail"],
                ["02/01/2099 10:00", "echo ok2"],
            ],
        )
        tasks = CsvParser().parse(path)
        assert len(tasks) == 2

    def test_raises_on_missing_date_column(self, tmp_path):
        path = write_csv(tmp_path / "d.csv", [["FOO", "BAR"], ["a", "b"]])
        with pytest.raises(ValueError, match="DATE"):
            CsvParser().parse(path)

    def test_raises_on_nonexistent_file(self, tmp_path):
        with pytest.raises(FileNotFoundError):
            CsvParser().parse(tmp_path / "does_not_exist.csv")

    def test_action_column_none_disables_action_extraction(self, tmp_path):
        path = write_csv(
            tmp_path / "d.csv",
            [
                ["DATE", "COMMAND"],
                ["01/01/2099 10:00", "echo hi"],
            ],
        )
        task = CsvParser(action_column=None).parse(path)[0]
        assert task.action == ""

    def test_utf8_bom_header_is_stripped(self, tmp_path):
        """Excel saves CSVs with a UTF-8 BOM; the header must still match."""
        path = tmp_path / "bom.csv"
        path.write_bytes(b"\xef\xbb\xbfDATE;COMMAND;NAME\r\n" b"01/01/2099 10:00;echo hi;task1\r\n")
        tasks = CsvParser().parse(path)
        assert len(tasks) == 1
        assert tasks[0].name == "task1"


# ---------------------------------------------------------------------------
# CronParser
# ---------------------------------------------------------------------------


class TestCronParserHappyPath:
    def test_uses_cron_file_fixture(self, cron_file):
        tasks = CronParser().parse(cron_file)
        assert len(tasks) == 2
        assert all(isinstance(t, CronTask) for t in tasks)

    def test_standard_five_field_line(self, tmp_path):
        p = tmp_path / "c.txt"
        p.write_text("* * * * * echo hello\n", encoding="utf-8")
        tasks = CronParser().parse(p)
        assert tasks[0].cron_expr == "* * * * *"
        assert tasks[0].action == "echo hello"

    def test_command_with_spaces_preserved(self, tmp_path):
        p = tmp_path / "c.txt"
        p.write_text("0 9 * * * /bin/script.sh --verbose --output /tmp/log\n", encoding="utf-8")
        task = CronParser().parse(p)[0]
        assert task.action == "/bin/script.sh --verbose --output /tmp/log"

    def test_skips_comment_lines(self, tmp_path):
        p = tmp_path / "c.txt"
        p.write_text("# this is a comment\n* * * * * echo ok\n", encoding="utf-8")
        assert len(CronParser().parse(p)) == 1

    def test_skips_blank_lines(self, tmp_path):
        p = tmp_path / "c.txt"
        p.write_text("\n\n* * * * * echo ok\n\n", encoding="utf-8")
        assert len(CronParser().parse(p)) == 1

    def test_skips_invalid_lines_without_error(self, tmp_path):
        p = tmp_path / "c.txt"
        p.write_text("bad line\n* * * * * echo ok\n", encoding="utf-8")
        assert len(CronParser().parse(p)) == 1

    def test_empty_file_returns_no_tasks(self, tmp_path):
        p = tmp_path / "c.txt"
        p.write_text("", encoding="utf-8")
        assert CronParser().parse(p) == []

    def test_raises_on_nonexistent_file(self, tmp_path):
        with pytest.raises(FileNotFoundError):
            CronParser().parse(tmp_path / "ghost.txt")


class TestCronParserAliases:
    @pytest.mark.parametrize(
        "alias,expected_expr",
        [
            ("@daily", "0 0 * * *"),
            ("@midnight", "0 0 * * *"),
            ("@hourly", "0 * * * *"),
            ("@monthly", "0 0 1 * *"),
            ("@weekly", "0 0 * * 0"),
            ("@noon", "0 12 * * *"),
            ("@annually", "0 0 1 1 *"),
            ("@year", "0 0 1 1 *"),
            ("@biweekly", "0 0 * * 0,2,4"),
            ("@bimonthly", "0 0 1,15 * *"),
            # English weekdays
            ("@mon", "0 0 * * 1"),
            ("@tue", "0 0 * * 2"),
            ("@wed", "0 0 * * 3"),
            ("@thu", "0 0 * * 4"),
            ("@fri", "0 0 * * 5"),
            ("@sat", "0 0 * * 6"),
            ("@sun", "0 0 * * 0"),
            # French weekdays
            ("@lundi", "0 0 * * 1"),
            ("@mardi", "0 0 * * 2"),
            ("@mercredi", "0 0 * * 3"),
            ("@jeudi", "0 0 * * 4"),
            ("@vendredi", "0 0 * * 5"),
            ("@samedi", "0 0 * * 6"),
            ("@dimanche", "0 0 * * 0"),
        ],
    )
    def test_alias_expansion(self, tmp_path, alias, expected_expr):
        p = tmp_path / "c.txt"
        p.write_text(f"{alias} /bin/cmd\n", encoding="utf-8")
        tasks = CronParser().parse(p)
        assert len(tasks) == 1
        assert tasks[0].cron_expr == expected_expr

    def test_monthly_not_confused_with_mon(self, tmp_path):
        p = tmp_path / "c.txt"
        p.write_text("@monthly /bin/backup\n", encoding="utf-8")
        assert CronParser().parse(p)[0].cron_expr == "0 0 1 * *"

    def test_mon_alias_expands_correctly(self, tmp_path):
        p = tmp_path / "c.txt"
        p.write_text("@mon /bin/weekly\n", encoding="utf-8")
        assert CronParser().parse(p)[0].cron_expr == "0 0 * * 1"

    def test_alias_command_preserved_after_expansion(self, tmp_path):
        p = tmp_path / "c.txt"
        p.write_text("@daily python /app/run.py --flag\n", encoding="utf-8")
        task = CronParser().parse(p)[0]
        assert task.action == "python /app/run.py --flag"
