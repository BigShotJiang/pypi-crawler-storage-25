"""Tests for DateTask and CronTask."""

from datetime import datetime, timedelta

import pytest
from crontable.scheduler.tasks.cron_task import CronTask
from crontable.scheduler.tasks.date_task import DateTask

# ---------------------------------------------------------------------------
# DateTask
# ---------------------------------------------------------------------------


class TestDateTaskDue:
    def test_is_due_when_time_reached(self, past_dt):
        task = DateTask(past_dt, action="echo hi")
        assert task.is_due(datetime.now())

    def test_not_due_when_in_future(self, future_dt):
        task = DateTask(future_dt, action="echo hi")
        assert not task.is_due(datetime.now())

    def test_due_at_exact_scheduled_time(self):
        now = datetime.now()
        task = DateTask(scheduled_at=now, action="echo")
        assert task.is_due(now)

    def test_not_due_one_second_before(self):
        t = datetime.now() + timedelta(seconds=1)
        task = DateTask(scheduled_at=t, action="echo")
        assert not task.is_due(datetime.now())


class TestDateTaskExecution:
    def test_not_due_after_mark_executed(self, past_dt):
        task = DateTask(past_dt, action="echo")
        task.mark_executed(datetime.now())
        assert not task.is_due(datetime.now())

    def test_next_run_is_none_after_execution(self, past_dt):
        task = DateTask(past_dt, action="echo")
        task.mark_executed(datetime.now())
        assert task.next_run() is None

    def test_next_run_returns_scheduled_at_before_execution(self, future_dt):
        task = DateTask(future_dt, action="echo")
        assert task.next_run() == future_dt

    def test_last_run_set_after_mark_executed(self, past_dt):
        task = DateTask(past_dt, action="echo")
        now = datetime.now()
        task.mark_executed(now)
        assert task._last_run == now

    def test_cannot_fire_twice(self, past_dt):
        fired = []
        task = DateTask(past_dt, action=lambda m: fired.append(1))
        task.mark_executed(datetime.now())
        # is_due returns False after first execution
        assert not task.is_due(datetime.now())
        assert len(fired) == 0


class TestDateTaskConstruction:
    def test_name_defaults_to_empty_string(self, past_dt):
        task = DateTask(past_dt, action="echo")
        assert task.name == ""

    def test_metadata_defaults_to_empty_dict(self, past_dt):
        task = DateTask(past_dt, action="echo")
        assert task.metadata == {}

    def test_metadata_stored(self):
        task = DateTask(datetime.now(), action="echo", metadata={"k": "v"})
        assert task.metadata["k"] == "v"

    def test_action_can_be_callable(self, past_dt):
        fn = lambda m: None
        task = DateTask(past_dt, action=fn)
        assert task.action is fn

    def test_repr_contains_class_name(self, future_dt):
        task = DateTask(future_dt, action="echo", name="mytask")
        r = repr(task)
        assert "DateTask" in r
        assert "mytask" in r


# ---------------------------------------------------------------------------
# CronTask
# ---------------------------------------------------------------------------


class TestCronTaskDue:
    def test_next_run_is_strictly_in_future(self, cron_task):
        assert cron_task.next_run() > datetime.now()

    def test_is_due_at_or_after_next_run(self, cron_task):
        far_future = cron_task.next_run() + timedelta(seconds=1)
        assert cron_task.is_due(far_future)

    def test_not_due_before_next_run(self, cron_task):
        just_before = cron_task.next_run() - timedelta(seconds=1)
        assert not cron_task.is_due(just_before)


class TestCronTaskExecution:
    def test_next_run_advances_after_mark_executed(self, cron_task):
        first = cron_task.next_run()
        cron_task.mark_executed(datetime.now())
        assert cron_task.next_run() > first

    def test_next_run_advances_monotonically_across_multiple_executions(self):
        task = CronTask("* * * * *", action="echo")
        previous = task.next_run()
        for _ in range(5):
            task.mark_executed(datetime.now())
            assert task.next_run() > previous
            previous = task.next_run()

    def test_next_run_never_returns_none(self, cron_task):
        for _ in range(3):
            cron_task.mark_executed(datetime.now())
        assert cron_task.next_run() is not None

    def test_last_run_set_after_mark_executed(self, cron_task):
        now = datetime.now()
        cron_task.mark_executed(now)
        assert cron_task._last_run == now


class TestCronTaskConstruction:
    def test_name_defaults_to_empty_string(self):
        task = CronTask("* * * * *", action="echo")
        assert task.name == ""

    def test_action_can_be_callable(self):
        fn = lambda: None
        task = CronTask("* * * * *", action=fn)
        assert task.action is fn

    def test_repr_contains_class_name(self, cron_task):
        assert "CronTask" in repr(cron_task)

    def test_repr_contains_name(self):
        task = CronTask("* * * * *", action="echo", name="heartbeat")
        assert "heartbeat" in repr(task)

    def test_invalid_expression_raises(self):
        with pytest.raises(Exception):
            CronTask(cron_expr="not a cron expression", action="echo")

    @pytest.mark.parametrize(
        "expr",
        [
            "0 0 * * *",
            "*/5 * * * *",
            "0 9 * * 1-5",
            "0 0 1,15 * *",
        ],
    )
    def test_various_valid_expressions(self, expr):
        task = CronTask(cron_expr=expr, action="echo")
        assert task.next_run() > datetime.now()
