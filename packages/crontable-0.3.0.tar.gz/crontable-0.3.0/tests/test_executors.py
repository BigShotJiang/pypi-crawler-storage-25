"""Tests for AutoExecutor, ShellCommandExecutor and InProcessCallableExecutor."""

import logging
import os
import sys
from pathlib import Path

import pytest
from crontable.scheduler.executors._paths import resolve_aliases
from crontable.scheduler.executors.auto import AutoExecutor
from crontable.scheduler.executors.callable_ import InProcessCallableExecutor
from crontable.scheduler.executors.shell import ShellCommandExecutor
from crontable.scheduler.tasks.cron_task import CronTask
from crontable.scheduler.tasks.date_task import DateTask

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def executor() -> AutoExecutor:
    """Default facade — dispatches to the right strategy implicitly."""
    return AutoExecutor()


@pytest.fixture
def cron_task_callable():
    """CronTask whose action is a callable (no metadata attribute)."""
    received = []
    task = CronTask("* * * * *", action=lambda: received.append("fired"), name="callable_cron")
    task._received = received
    return task


@pytest.fixture
def date_task_callable(past_dt):
    """DateTask whose action records the metadata dict it receives."""
    received = {}
    task = DateTask(
        past_dt,
        action=lambda m: received.update(m),
        name="callable_date",
        metadata={"KEY": "VALUE", "NUM": "42"},
    )
    task._received = received
    return task


# ---------------------------------------------------------------------------
# AutoExecutor dispatch
# ---------------------------------------------------------------------------


class TestAutoExecutorDispatch:
    def test_callable_action_goes_to_callable_executor(self, executor, cron_task_callable):
        executor.run(cron_task_callable)
        assert cron_task_callable._received == ["fired"]

    def test_string_action_goes_to_shell_executor(self, executor):
        task = CronTask("* * * * *", action=f"{sys.executable} -c \"print('ok')\"")
        executor.run(task)  # must not raise

    def test_empty_string_logs_warning(self, executor, caplog, past_dt):
        task = DateTask(past_dt, action="", name="no_action")
        with caplog.at_level(logging.WARNING):
            executor.run(task)
        assert any("no executable action" in r.message for r in caplog.records)

    def test_whitespace_only_logs_warning(self, executor, caplog, past_dt):
        task = DateTask(past_dt, action="   ", name="ws")
        with caplog.at_level(logging.WARNING):
            executor.run(task)
        assert any("no executable action" in r.message for r in caplog.records)

    def test_register_overrides_default_dispatch(self, past_dt):
        """Custom registrations are checked before built-in dispatch."""
        captured = []

        class Capture:
            def run(self, task):
                captured.append(task.name)

        auto = AutoExecutor()
        auto.register(lambda t: t.name.startswith("special_"), Capture())

        task = DateTask(past_dt, action="echo never", name="special_one")
        auto.run(task)
        assert captured == ["special_one"]

    def test_register_newest_wins(self, past_dt):
        """LIFO: the most recent registration takes precedence."""
        hit = []

        class A:
            def run(self, task):
                hit.append("A")

        class B:
            def run(self, task):
                hit.append("B")

        auto = AutoExecutor()
        auto.register(lambda t: True, A())
        auto.register(lambda t: True, B())  # newer, wins
        auto.run(DateTask(past_dt, action="x", name="any"))
        assert hit == ["B"]

    def test_register_rejects_non_callable_predicate(self):
        with pytest.raises(TypeError):
            AutoExecutor().register("not a fn", InProcessCallableExecutor())

    def test_register_rejects_non_executor(self):
        # `object()` has no run() method, so it should be rejected.
        with pytest.raises(TypeError):
            AutoExecutor().register(lambda t: True, object())

    def test_predicate_exception_is_swallowed(self, past_dt, caplog):
        """A broken predicate must not crash the scheduler."""

        def boom(task):
            raise RuntimeError("predicate boom")

        auto = AutoExecutor()
        auto.register(boom, InProcessCallableExecutor())
        task = DateTask(past_dt, action="echo ok", name="x")
        with caplog.at_level(logging.ERROR):
            auto.run(task)  # must not raise
        assert any("predicate raised" in r.message for r in caplog.records)

    def test_custom_shell_executor_override(self):
        """A pre-built shell_executor is reused instead of being re-created."""
        shell = ShellCommandExecutor(timeout=42.0)
        auto = AutoExecutor(shell_executor=shell)
        assert auto.shell_executor is shell

    def test_custom_callable_executor_override(self):
        cexec = InProcessCallableExecutor()
        auto = AutoExecutor(callable_executor=cexec)
        assert auto.callable_executor is cexec


# ---------------------------------------------------------------------------
# InProcessCallableExecutor
# ---------------------------------------------------------------------------


class TestInProcessCallable:
    def test_cron_callable_no_args(self, cron_task_callable):
        InProcessCallableExecutor().run(cron_task_callable)
        assert cron_task_callable._received == ["fired"]

    def test_date_callable_receives_metadata(self, date_task_callable):
        InProcessCallableExecutor().run(date_task_callable)
        assert date_task_callable._received["KEY"] == "VALUE"
        assert date_task_callable._received["NUM"] == "42"

    def test_exception_does_not_propagate(self, caplog):
        def boom():
            raise ValueError("deliberate error")

        task = CronTask("* * * * *", action=boom)
        with caplog.at_level(logging.ERROR):
            InProcessCallableExecutor().run(task)  # must not raise
        assert len(caplog.records) > 0

    def test_exception_logged_with_task_name(self, caplog):
        def boom():
            raise RuntimeError("oops")

        task = CronTask("* * * * *", action=boom, name="failing_task")
        with caplog.at_level(logging.ERROR):
            InProcessCallableExecutor().run(task)
        assert any("failing_task" in r.message for r in caplog.records)

    def test_rejects_non_callable_action(self, caplog, past_dt):
        task = DateTask(past_dt, action="not callable", name="nope")
        with caplog.at_level(logging.WARNING):
            InProcessCallableExecutor().run(task)
        assert any("no callable action" in r.message for r in caplog.records)


# ---------------------------------------------------------------------------
# ShellCommandExecutor — subprocess
# ---------------------------------------------------------------------------


class TestShellCommandExecutor:
    def test_successful_python_command(self):
        ex = ShellCommandExecutor()
        task = CronTask("* * * * *", action=f"{sys.executable} -c \"print('ok')\"")
        ex.run(task)  # must not raise

    def test_command_not_found_does_not_raise(self, caplog):
        ex = ShellCommandExecutor()
        task = CronTask("* * * * *", action="this_binary_does_not_exist_xyzabc")
        with caplog.at_level(logging.ERROR):
            ex.run(task)
        assert len(caplog.records) > 0

    def test_failing_command_logs_error(self, caplog, tmp_path):
        ex = ShellCommandExecutor()
        script = tmp_path / "fail.py"
        script.write_text("import sys; sys.exit(42)\n")
        task = CronTask("* * * * *", action=f"{sys.executable} {script}")
        with caplog.at_level(logging.ERROR, logger="crontable.scheduler.executors.shell"):
            ex.run(task)
        assert "42" in caplog.text

    def test_failing_command_does_not_raise(self, tmp_path):
        ex = ShellCommandExecutor()
        script = tmp_path / "fail.py"
        script.write_text("import sys; sys.exit(1)\n")
        task = CronTask("* * * * *", action=f"{sys.executable} {script}")
        ex.run(task)  # must not raise

    def test_empty_action_logs_warning(self, caplog, past_dt):
        ex = ShellCommandExecutor()
        task = DateTask(past_dt, action="", name="empty")
        with caplog.at_level(logging.WARNING):
            ex.run(task)
        assert any("no executable action" in r.message for r in caplog.records)


# ---------------------------------------------------------------------------
# Timeout
# ---------------------------------------------------------------------------


class TestSubprocessTimeout:
    def test_timeout_does_not_raise(self):
        ex = ShellCommandExecutor(timeout=0.1)
        task = CronTask(
            "* * * * *",
            action=f'{sys.executable} -c "import time; time.sleep(10)"',
        )
        ex.run(task)  # must not raise

    def test_timeout_logged_as_error(self, caplog, tmp_path):
        ex = ShellCommandExecutor(timeout=0.1)
        script = tmp_path / "slow.py"
        script.write_text("import time; time.sleep(10)\n")
        task = CronTask("* * * * *", action=f"{sys.executable} {script}")
        with caplog.at_level(logging.ERROR, logger="crontable.scheduler.executors.shell"):
            ex.run(task)
        assert "timed out" in caplog.text.lower()

    def test_no_timeout_by_default(self):
        assert ShellCommandExecutor().timeout is None

    def test_auto_executor_forwards_timeout_to_shell(self):
        auto = AutoExecutor(timeout=5.0)
        assert auto.shell_executor.timeout == 5.0


# ---------------------------------------------------------------------------
# Alias resolution
# ---------------------------------------------------------------------------


class TestAliasResolution:
    def test_home_alias_replaced(self):
        result = resolve_aliases("@home/scripts/run.sh")
        assert str(Path.home()) in result
        assert "@home" not in result

    def test_python_alias_replaced(self):
        result = resolve_aliases("@python -c 'pass'")
        assert sys.executable in result
        assert "@python" not in result

    def test_desktop_alias_replaced(self):
        result = resolve_aliases("@desktop/run.bat")
        assert str(Path.home() / "Desktop") in result

    def test_no_alias_unchanged(self):
        cmd = "echo hello world"
        assert resolve_aliases(cmd) == cmd

    def test_multiple_aliases_in_one_command(self):
        result = resolve_aliases("@python @home/script.py")
        assert "@python" not in result
        assert "@home" not in result


# ---------------------------------------------------------------------------
# Shell mode resolution
# ---------------------------------------------------------------------------


class TestShellModeResolution:
    def test_explicit_shell_true_is_honoured(self):
        ex = ShellCommandExecutor(shell=True)
        assert ex._resolve_shell_mode("anything") is True

    def test_explicit_shell_false_is_honoured(self):
        ex = ShellCommandExecutor(shell=False)
        assert ex._resolve_shell_mode("echo hi") is False

    @pytest.mark.skipif(os.name != "nt", reason="Windows-only behaviour")
    def test_windows_builtin_auto_uses_shell(self):
        ex = ShellCommandExecutor()
        assert ex._resolve_shell_mode("echo hello") is True
        assert ex._resolve_shell_mode("dir C:\\") is True

    @pytest.mark.skipif(os.name != "nt", reason="Windows-only behaviour")
    def test_windows_non_builtin_keeps_shell_false(self):
        ex = ShellCommandExecutor()
        assert ex._resolve_shell_mode("python --version") is False

    @pytest.mark.skipif(os.name == "nt", reason="POSIX-only behaviour")
    def test_posix_default_keeps_shell_false(self):
        ex = ShellCommandExecutor()
        assert ex._resolve_shell_mode("echo hi") is False

    @pytest.mark.skipif(os.name != "nt", reason="echo is a cmd.exe builtin")
    def test_windows_echo_builtin_runs_successfully(self, caplog):
        """Regression: `echo` is a cmd.exe built-in; it must run on Windows."""
        ex = ShellCommandExecutor()
        task = CronTask("* * * * *", action="echo crontable_echo_ok")
        with caplog.at_level(logging.INFO, logger="crontable.scheduler.executors.shell"):
            ex.run(task)
        assert "crontable_echo_ok" in caplog.text


# ---------------------------------------------------------------------------
# Backwards-compat aliases
# ---------------------------------------------------------------------------


class TestBackwardsCompatAliases:
    def test_subprocess_executor_alias_is_auto(self):
        from crontable import SubprocessExecutor

        assert SubprocessExecutor is AutoExecutor

    def test_function_executor_alias_is_multiprocess(self):
        from crontable import FunctionExecutor, MultiprocessExecutor

        assert FunctionExecutor is MultiprocessExecutor
