"""Tests for PythonScriptExecutor — argument building and subprocess execution."""

from __future__ import annotations

import logging
import sys
from pathlib import Path

import pytest
from crontable.scheduler.executors.python_script_executor import PythonScriptExecutor
from crontable.scheduler.tasks.cron_task import CronTask
from crontable.scheduler.tasks.date_task import DateTask

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _task(metadata: dict, action: str = "") -> DateTask:
    """Return a past DateTask carrying the given metadata dict."""
    from datetime import datetime, timedelta

    return DateTask(
        scheduled_at=datetime.now() - timedelta(seconds=1),
        action=action,
        name="test_task",
        metadata=metadata,
    )


def _script(tmp_path: Path, body: str) -> Path:
    """Write a small Python script and return its path."""
    p = tmp_path / "script.py"
    p.write_text(body, encoding="utf-8")
    return p


# ---------------------------------------------------------------------------
# _build_args — explicit arg_columns
# ---------------------------------------------------------------------------


class TestBuildArgsExplicit:
    def test_returns_values_in_declared_order(self):
        ex = PythonScriptExecutor("say.py", arg_columns=["MESSAGE", "VOICE"])
        args = ex._build_args({"MESSAGE": "hello", "VOICE": "french", "DATE": "..."})
        assert args == ["hello", "french"]

    def test_skips_missing_columns_silently(self):
        ex = PythonScriptExecutor("say.py", arg_columns=["MESSAGE", "MISSING"])
        args = ex._build_args({"MESSAGE": "hi"})
        assert args == ["hi"]

    def test_skips_empty_values(self):
        ex = PythonScriptExecutor("say.py", arg_columns=["MESSAGE", "VOICE"])
        args = ex._build_args({"MESSAGE": "hi", "VOICE": ""})
        assert args == ["hi"]

    def test_column_names_normalised_to_uppercase(self):
        ex = PythonScriptExecutor("say.py", arg_columns=["message", "voice"])
        args = ex._build_args({"MESSAGE": "hello", "VOICE": "en"})
        assert args == ["hello", "en"]

    def test_preserves_value_with_spaces(self):
        ex = PythonScriptExecutor("say.py", arg_columns=["MESSAGE"])
        args = ex._build_args({"MESSAGE": "hello world"})
        assert args == ["hello world"]

    def test_empty_column_list_produces_no_args(self):
        ex = PythonScriptExecutor("say.py", arg_columns=[])
        args = ex._build_args({"MESSAGE": "hi"})
        assert args == []


# ---------------------------------------------------------------------------
# _build_args — auto mode (arg_columns=None)
# ---------------------------------------------------------------------------


class TestBuildArgsAuto:
    def test_emits_keyword_args_for_non_skip_columns(self):
        ex = PythonScriptExecutor("say.py")
        args = ex._build_args({"MESSAGE": "hi", "VOICE": "fr"})
        assert "--message" in args
        assert "hi" in args
        assert "--voice" in args
        assert "fr" in args

    def test_skips_date_name_command_columns(self):
        ex = PythonScriptExecutor("say.py")
        args = ex._build_args(
            {
                "DATE": "01/01/2099",
                "NAME": "task",
                "COMMAND": "run",
                "MESSAGE": "hello",
            }
        )
        assert "--date" not in args
        assert "--name" not in args
        assert "--command" not in args
        assert "--message" in args

    def test_skips_empty_values(self):
        ex = PythonScriptExecutor("say.py")
        args = ex._build_args({"MESSAGE": "hi", "VOICE": ""})
        assert "--voice" not in args

    def test_keyword_is_lowercase_of_column(self):
        ex = PythonScriptExecutor("say.py")
        args = ex._build_args({"MYKEY": "val"})
        assert "--mykey" in args

    def test_empty_metadata_produces_no_args(self):
        ex = PythonScriptExecutor("say.py")
        assert ex._build_args({}) == []


# ---------------------------------------------------------------------------
# run() — actual subprocess execution
# ---------------------------------------------------------------------------


class TestRun:
    def test_runs_script_with_positional_args(self, tmp_path):
        script = _script(tmp_path, "import sys; print(' '.join(sys.argv[1:]))\n")
        ex = PythonScriptExecutor(script, arg_columns=["A", "B"])
        task = _task({"A": "foo", "B": "bar"})
        ex.run(task)  # must not raise

    def test_positional_args_received_by_script(self, tmp_path, caplog):
        script = _script(tmp_path, "import sys; print('ARGS:', *sys.argv[1:])\n")
        ex = PythonScriptExecutor(script, arg_columns=["MSG"])
        task = _task({"MSG": "hello"})
        with caplog.at_level(logging.INFO):
            ex.run(task)
        assert "hello" in caplog.text

    def test_keyword_args_received_by_script(self, tmp_path, caplog):
        script = _script(tmp_path, "import sys; print(' '.join(sys.argv[1:]))\n")
        ex = PythonScriptExecutor(script)
        task = _task({"MESSAGE": "world"})
        with caplog.at_level(logging.INFO):
            ex.run(task)
        assert "--message" in caplog.text
        assert "world" in caplog.text

    def test_python_alias_resolved(self, tmp_path):
        script = _script(tmp_path, "print('alias ok')\n")
        ex = PythonScriptExecutor(f"@python {script}")
        task = _task({})
        ex.run(task)  # must not raise

    def test_task_without_metadata_runs_without_args(self, tmp_path):
        script = _script(tmp_path, "import sys; assert len(sys.argv) == 1\n")
        ex = PythonScriptExecutor(script)
        task = CronTask("* * * * *", action="", name="no_meta")
        ex.run(task)  # must not raise

    def test_missing_script_does_not_raise(self, tmp_path, caplog):
        ex = PythonScriptExecutor(tmp_path / "nonexistent.py")
        task = _task({})
        with caplog.at_level(logging.ERROR):
            ex.run(task)
        assert len(caplog.records) > 0

    def test_script_failure_does_not_raise(self, tmp_path, caplog):
        script = _script(tmp_path, "import sys; sys.exit(42)\n")
        ex = PythonScriptExecutor(script)
        task = _task({})
        with caplog.at_level(logging.ERROR):
            ex.run(task)  # must not raise
        assert "42" in caplog.text

    def test_timeout_kwarg_cancels_hung_script(self, tmp_path, caplog):
        script = _script(tmp_path, "import time; time.sleep(10)\n")
        ex = PythonScriptExecutor(script, timeout=0.1)
        task = _task({})
        with caplog.at_level(logging.ERROR):
            ex.run(task)
        assert "timed out" in caplog.text.lower()

    def test_default_timeout_is_none(self):
        ex = PythonScriptExecutor("say.py")
        assert ex.timeout is None
