"""Tests for MultiprocessExecutor (multiprocessing-based callable runner).

Also validates the backwards-compat ``FunctionExecutor`` alias.
"""

from __future__ import annotations

import json
import multiprocessing
from datetime import datetime
from pathlib import Path

import pytest
from crontable import FunctionExecutor, MultiprocessExecutor
from crontable.scheduler.tasks.date_task import DateTask

# ---------------------------------------------------------------------------
# Top-level worker functions (must be picklable for multiprocessing)
# ---------------------------------------------------------------------------


def _write_args(path: str, *args) -> None:
    """Write positional args as JSON to *path*."""
    with open(path, "w") as f:
        json.dump(list(args), f)


def _write_kwargs(path: str, **kwargs) -> None:
    """Write keyword args as JSON to *path*."""
    with open(path, "w") as f:
        json.dump(kwargs, f)


def _raise_always() -> None:
    raise RuntimeError("deliberate failure")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_task(metadata: dict) -> DateTask:
    return DateTask(
        scheduled_at=datetime.now(),
        action="",
        name="test_task",
        metadata=metadata,
    )


def _join(executor: MultiprocessExecutor, timeout: float = 10.0) -> None:
    """Block until the last spawned process finishes."""
    assert executor._last_process is not None
    executor._last_process.join(timeout=timeout)


# ---------------------------------------------------------------------------
# Constructor validation
# ---------------------------------------------------------------------------


class TestFunctionExecutorInit:
    def test_requires_callable(self):
        with pytest.raises(TypeError, match="callable"):
            FunctionExecutor("not_a_function")  # type: ignore[arg-type]

    def test_arg_columns_uppercased(self):
        executor = FunctionExecutor(_write_args, arg_columns=["message", "voice"])
        assert executor.arg_columns == ["MESSAGE", "VOICE"]

    def test_arg_columns_none_by_default(self):
        executor = FunctionExecutor(_write_args)
        assert executor.arg_columns is None


# ---------------------------------------------------------------------------
# _build_call
# ---------------------------------------------------------------------------


class TestBuildCall:
    def test_explicit_columns_returns_positional_args(self):
        executor = FunctionExecutor(_write_args, arg_columns=["MSG", "LANG"])
        args, kwargs = executor._build_call({"MSG": "hello", "LANG": "fr", "DATE": "x"})
        assert args == ("hello", "fr")
        assert kwargs == {}

    def test_explicit_columns_skips_missing_keys(self):
        executor = FunctionExecutor(_write_args, arg_columns=["MSG", "MISSING"])
        args, _ = executor._build_call({"MSG": "hi"})
        assert args == ("hi",)

    def test_auto_mode_returns_kwargs(self):
        executor = FunctionExecutor(_write_kwargs)
        _, kwargs = executor._build_call(
            {"DATE": "2099", "NAME": "t", "COMMAND": "c", "MESSAGE": "hello", "VOICE": "en"}
        )
        assert kwargs == {"message": "hello", "voice": "en"}

    def test_auto_mode_excludes_system_columns(self):
        executor = FunctionExecutor(_write_kwargs)
        _, kwargs = executor._build_call({"DATE": "x", "NAME": "y", "COMMAND": "z"})
        assert kwargs == {}

    def test_auto_mode_skips_empty_values(self):
        executor = FunctionExecutor(_write_kwargs)
        _, kwargs = executor._build_call({"MESSAGE": "hi", "VOICE": ""})
        assert "voice" not in kwargs
        assert kwargs["message"] == "hi"


# ---------------------------------------------------------------------------
# run() — process lifecycle
# ---------------------------------------------------------------------------


class TestFunctionExecutorRun:
    def test_run_starts_a_process(self, tmp_path):
        output = tmp_path / "out.json"
        executor = FunctionExecutor(_write_args, arg_columns=["PATH", "MSG"])
        task = _make_task({"PATH": str(output), "MSG": "hello"})
        executor.run(task)
        assert executor._last_process is not None
        assert executor._last_process.pid is not None

    def test_explicit_columns_passes_positional_args(self, tmp_path):
        output = tmp_path / "out.json"
        executor = FunctionExecutor(_write_args, arg_columns=["PATH", "MSG"])
        task = _make_task({"PATH": str(output), "MSG": "hello"})
        executor.run(task)
        _join(executor)
        assert json.loads(output.read_text()) == ["hello"]

    def test_auto_mode_passes_kwargs(self, tmp_path):
        output = tmp_path / "out.json"
        executor = FunctionExecutor(_write_kwargs)
        task = _make_task(
            {
                "DATE": "2099",
                "NAME": "t",
                "PATH": str(output),
                "MSG": "world",
            }
        )
        executor.run(task)
        _join(executor)
        data = json.loads(output.read_text())
        assert data["msg"] == "world"
        # "path" is consumed as the positional arg of _write_kwargs, not in **kwargs
        assert "path" not in data

    def test_run_is_non_blocking(self, tmp_path):
        """run() must return before the child process finishes."""
        import time

        slow_script = tmp_path / "slow.py"
        slow_script.write_text("import time; time.sleep(2)\n")

        # Use a function that sleeps so we can check return-before-finish.
        # We verify by measuring that run() returns in << 2 s.
        def _sleep_long() -> None:
            import time

            time.sleep(2)

        # _sleep_long is defined locally — not picklable on Windows.
        # Use subprocess approach as a proxy: just check _last_process.is_alive()
        # immediately after run().
        executor = FunctionExecutor(_write_args, arg_columns=["PATH"])
        output = tmp_path / "out.json"
        task = _make_task({"PATH": str(output)})

        start = time.monotonic()
        executor.run(task)
        elapsed = time.monotonic() - start
        # run() itself should return in well under 1 second
        assert elapsed < 1.0

    def test_last_process_exitcode_zero_on_success(self, tmp_path):
        output = tmp_path / "out.json"
        executor = FunctionExecutor(_write_args, arg_columns=["PATH", "MSG"])
        task = _make_task({"PATH": str(output), "MSG": "ok"})
        executor.run(task)
        _join(executor)
        assert executor._last_process.exitcode == 0

    def test_child_exception_does_not_crash_parent(self):
        """A failing child process must not raise in the parent."""
        executor = FunctionExecutor(_raise_always)
        task = _make_task({})
        executor.run(task)  # must not raise
        _join(executor)
        assert executor._last_process.exitcode != 0

    def test_multiple_runs_each_spawn_new_process(self, tmp_path):
        pids = []
        for i in range(3):
            output = tmp_path / f"out_{i}.json"
            executor = FunctionExecutor(_write_args, arg_columns=["PATH"])
            task = _make_task({"PATH": str(output)})
            executor.run(task)
            pids.append(executor._last_process.pid)
            _join(executor)
        assert len(set(pids)) == 3
