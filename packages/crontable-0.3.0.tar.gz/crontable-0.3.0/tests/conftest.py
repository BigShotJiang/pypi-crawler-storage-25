"""
Shared fixtures for the crontable test suite.
"""

from __future__ import annotations

import csv
from datetime import datetime, timedelta
from pathlib import Path
from typing import List

import pytest
from crontable.scheduler.core.scheduler import Scheduler
from crontable.scheduler.executors.base_executor import Executor
from crontable.scheduler.tasks.cron_task import CronTask
from crontable.scheduler.tasks.date_task import DateTask

# ---------------------------------------------------------------------------
# Reusable executor implementation
# ---------------------------------------------------------------------------


class RecordingExecutor(Executor):
    """Executor that records every task it receives without side effects."""

    def __init__(self) -> None:
        self.ran: List = []

    def run(self, task) -> None:
        self.ran.append(task)

    @property
    def count(self) -> int:
        return len(self.ran)


class BrokenExecutor(Executor):
    """Executor that always raises, used to test error-resilience."""

    def run(self, task) -> None:
        raise RuntimeError("executor boom")


# ---------------------------------------------------------------------------
# Datetime fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def past_dt() -> datetime:
    """A datetime 10 seconds in the past."""
    return datetime.now() - timedelta(seconds=10)


@pytest.fixture
def future_dt() -> datetime:
    """A datetime 1 hour in the future."""
    return datetime.now() + timedelta(hours=1)


# ---------------------------------------------------------------------------
# Executor fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def recording_executor() -> RecordingExecutor:
    return RecordingExecutor()


@pytest.fixture
def broken_executor() -> BrokenExecutor:
    return BrokenExecutor()


# ---------------------------------------------------------------------------
# Task fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def date_task_past(past_dt) -> DateTask:
    return DateTask(scheduled_at=past_dt, action="echo past", name="past_task")


@pytest.fixture
def date_task_future(future_dt) -> DateTask:
    return DateTask(scheduled_at=future_dt, action="echo future", name="future_task")


@pytest.fixture
def cron_task() -> CronTask:
    return CronTask(cron_expr="* * * * *", action="echo cron", name="cron_task")


# ---------------------------------------------------------------------------
# Scheduler fixture
# ---------------------------------------------------------------------------


@pytest.fixture
def scheduler(recording_executor) -> Scheduler:
    return Scheduler(executor=recording_executor, interval=0.05)


# ---------------------------------------------------------------------------
# File fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def csv_file(tmp_path) -> Path:
    """CSV with two valid future date tasks."""
    path = tmp_path / "tasks.csv"
    with path.open("w", newline="", encoding="utf-8") as fh:
        writer = csv.writer(fh, delimiter=";")
        writer.writerows(
            [
                ["DATE", "COMMAND", "NAME"],
                ["01/01/2099 08:00", "echo morning", "morning"],
                ["01/01/2099 12:00", "echo noon", "noon"],
            ]
        )
    return path


@pytest.fixture
def cron_file(tmp_path) -> Path:
    """Crontab file with one alias and one explicit expression."""
    path = tmp_path / "crontab.txt"
    path.write_text(
        "# daily backup\n" "@daily /bin/backup.sh\n" "0 9 * * 1 echo monday_report\n",
        encoding="utf-8",
    )
    return path
