"""
crontable – usage examples.

Run modes (passed as argv):
  python -m crontable.main            → programmatic demo (no file)
  python -m crontable.main tasks.csv  → load date tasks from CSV
  python -m crontable.main crontab.txt → load cron tasks from crontab file
"""

from __future__ import annotations

import logging
import sys
from datetime import datetime, timedelta

from crontable import AutoExecutor, CronTask, DateTask, FileSource, Scheduler

logging.basicConfig(
    format="%(asctime)s %(levelname)-8s %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
    level=logging.INFO,
)


# ---------------------------------------------------------------------------
# Example callback for CSV-loaded DateTasks
# ---------------------------------------------------------------------------


def on_task_fired(metadata: dict) -> None:
    print(f"[CALLBACK] Task fired — metadata: {metadata}")


# ---------------------------------------------------------------------------
# Demo: purely programmatic tasks
# ---------------------------------------------------------------------------


def demo_programmatic() -> None:
    scheduler = Scheduler(executor=AutoExecutor(), interval=5.0)

    scheduler.add_tasks(
        [
            DateTask(
                scheduled_at=datetime.now() + timedelta(seconds=10),
                action=on_task_fired,
                name="hello_in_10s",
                metadata={"msg": "Hello from DateTask"},
            ),
            CronTask(
                cron_expr="* * * * *",
                action=lambda: print("[CRON] Every-minute heartbeat"),
                name="heartbeat",
            ),
        ]
    )

    print("Running programmatic demo — press Ctrl+C to stop.")
    try:
        scheduler.run()
    except KeyboardInterrupt:
        scheduler.stop()


# ---------------------------------------------------------------------------
# Demo: load from file (CSV or crontab)
# ---------------------------------------------------------------------------


def demo_from_file(path: str) -> None:
    source = FileSource(path)
    scheduler = Scheduler(executor=AutoExecutor(), interval=10.0)
    scheduler.add_tasks(source.load())

    print(f"Loaded tasks from {path} — press Ctrl+C to stop.")
    try:
        scheduler.run()
    except KeyboardInterrupt:
        scheduler.stop()


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def main() -> None:
    if len(sys.argv) == 1:
        demo_programmatic()
    else:
        demo_from_file(sys.argv[1])


if __name__ == "__main__":
    main()
