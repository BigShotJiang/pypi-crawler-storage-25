"""
crontable-gui — tkinter front-end for the crontable scheduler.

Features:
  • Browse for or create a new crontab (.txt / .cron) or CSV file
  • Edit tasks in a built-in editor window
  • Configurable polling interval (spinbox)
  • Start / stop the scheduler
  • Hot-reload when the source file changes on disk
  • Live task list with right-click "Run now" / "Edit"
  • Color-coded execution log with Clear button
  • Open source file in the system default editor
  • Toggle launching at OS startup (Windows)
  • Persistent last-used file and interval (~/.crontable.json)
"""

from __future__ import annotations

import json
import logging
import subprocess
import sys
import threading
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, scrolledtext, ttk
from typing import Optional

from crontable import AutoExecutor, FileSource, Scheduler, Task

if sys.platform == "win32":
    import winreg
else:
    winreg = None  # type: ignore[assignment]

logger = logging.getLogger(__name__)

_CONFIG_PATH = Path.home() / ".crontable.json"
_STARTUP_REG_KEY = r"Software\Microsoft\Windows\CurrentVersion\Run"
_STARTUP_APP_NAME = "Crontable"

_EXAMPLE_CRONTAB = """\
# Crontable crontab — format: <min> <hour> <dom> <mon> <dow>  <command>
# Fields : minute(0-59)  hour(0-23)  day(1-31)  month(1-12)  weekday(0-6, 0=Sun)
# Lines starting with # are ignored.
#
# @hourly   echo "Every hour"
# @daily    python C:\\scripts\\daily_report.py
# @weekly   echo "Every Sunday at midnight"
# */5 * * * *   echo "Every 5 minutes"
# 0 9 * * 1-5   echo "Weekdays at 9 am"
# 30 18 * * 5   echo "Fridays at 6:30 pm"
"""

_EXAMPLE_CSV = """\
DATE;NAME;COMMAND
# DATE format: dd/mm/YYYY HH:MM  |  delimiter: semicolon (;)
# 01/01/2027 09:00;morning_report;echo "Good morning"
# 15/06/2027 14:30;backup_task;python C:\\scripts\\backup.py
# 31/12/2027 23:59;year_end_task;echo "Happy New Year"
"""


def _find_icon() -> str | None:
    """Locate icon.ico for both development and PyInstaller one-file builds."""
    candidates: list[Path] = []
    if hasattr(sys, "_MEIPASS"):
        candidates.append(Path(sys._MEIPASS) / "assets" / "icon.ico")
    candidates += [
        Path(__file__).parent.parent.parent / "assets" / "icon.ico",  # editable install
        Path(__file__).parent / "assets" / "icon.ico",
    ]
    return next((str(p) for p in candidates if p.is_file()), None)


# ---------------------------------------------------------------------------
# OS-startup integration (Windows: HKCU\...\Run registry value)
# ---------------------------------------------------------------------------


def _startup_command() -> str:
    """Command line registered to run on OS startup."""
    if getattr(sys, "frozen", False):
        return f'"{sys.executable}"'
    return f'"{sys.executable}" -m crontable.gui'


def _is_startup_enabled() -> bool:
    if sys.platform != "win32" or winreg is None:
        return False
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, _STARTUP_REG_KEY) as key:
            winreg.QueryValueEx(key, _STARTUP_APP_NAME)
        return True
    except OSError:
        return False


def _enable_startup() -> None:
    if sys.platform != "win32" or winreg is None:
        raise RuntimeError("Startup integration is only supported on Windows.")
    with winreg.OpenKey(
        winreg.HKEY_CURRENT_USER, _STARTUP_REG_KEY, 0, winreg.KEY_SET_VALUE
    ) as key:
        winreg.SetValueEx(key, _STARTUP_APP_NAME, 0, winreg.REG_SZ, _startup_command())


def _disable_startup() -> None:
    if sys.platform != "win32" or winreg is None:
        return
    try:
        with winreg.OpenKey(
            winreg.HKEY_CURRENT_USER, _STARTUP_REG_KEY, 0, winreg.KEY_SET_VALUE
        ) as key:
            winreg.DeleteValue(key, _STARTUP_APP_NAME)
    except FileNotFoundError:
        pass


# ---------------------------------------------------------------------------
# Logging bridge: forward log records into the GUI text widget
# ---------------------------------------------------------------------------


class _WidgetHandler(logging.Handler):
    _COLORS: dict[str, str] = {
        "ERROR": "red",
        "WARNING": "#CC7700",
        "DEBUG": "gray",
    }

    def __init__(self, widget: scrolledtext.ScrolledText) -> None:
        super().__init__()
        self._widget = widget
        for level, color in self._COLORS.items():
            widget.tag_config(level, foreground=color)

    def emit(self, record: logging.LogRecord) -> None:
        msg = self.format(record) + "\n"
        tag = record.levelname if record.levelname in self._COLORS else ""
        self._widget.after(0, self._append, msg, tag)

    def _append(self, msg: str, tag: str) -> None:
        self._widget.configure(state="normal")
        self._widget.insert(tk.END, msg, tag)
        self._widget.see(tk.END)
        self._widget.configure(state="disabled")


# ---------------------------------------------------------------------------
# Application
# ---------------------------------------------------------------------------


class CrontableApp(tk.Tk):
    _POLL_MS = 5_000

    def __init__(self) -> None:
        super().__init__()
        self.title("Crontable")
        self.minsize(720, 560)
        self.resizable(True, True)

        self._scheduler: Optional[Scheduler] = None
        self._scheduler_thread: Optional[threading.Thread] = None
        self._source: Optional[FileSource] = None
        self._file_path = tk.StringVar()
        self._interval_var = tk.IntVar(value=60)
        self._startup_var = tk.BooleanVar(value=False)
        self._task_map: dict[str, Task] = {}
        self._editor_window: Optional[tk.Toplevel] = None

        self._build_ui()
        self._attach_log_handler()
        self._apply_icon()
        self._load_config()
        self._refresh_startup_state()
        self.protocol("WM_DELETE_WINDOW", self._on_close)

    # ------------------------------------------------------------------
    # UI construction
    # ------------------------------------------------------------------

    def _build_ui(self) -> None:
        # ── File row ──────────────────────────────────────────────────
        file_frame = ttk.Frame(self, padding=6)
        file_frame.pack(fill="x")

        ttk.Label(file_frame, text="File:").pack(side="left")
        ttk.Entry(file_frame, textvariable=self._file_path, width=52).pack(side="left", padx=4, expand=True, fill="x")
        ttk.Button(file_frame, text="Browse…", command=self._browse).pack(side="left")
        ttk.Button(file_frame, text="New…", command=self._new_example_file).pack(side="left", padx=(4, 0))
        ttk.Button(file_frame, text="Edit tasks", command=self._open_task_editor).pack(side="left", padx=(4, 0))
        ttk.Button(file_frame, text="Open in editor", command=self._open_in_editor).pack(side="left", padx=(4, 0))

        # ── Controls ──────────────────────────────────────────────────
        ctrl_frame = ttk.Frame(self, padding=(6, 0, 6, 6))
        ctrl_frame.pack(fill="x")

        self._btn_start = ttk.Button(ctrl_frame, text="▶  Start", command=self._start, state="disabled")
        self._btn_start.pack(side="left")
        self._btn_stop = ttk.Button(ctrl_frame, text="■  Stop", command=self._stop, state="disabled")
        self._btn_stop.pack(side="left", padx=4)

        self._status_var = tk.StringVar(value="Stopped")
        self._status_label = ttk.Label(ctrl_frame, textvariable=self._status_var, foreground="gray")
        self._status_label.pack(side="left", padx=8)

        self._startup_check = ttk.Checkbutton(
            ctrl_frame,
            text="Start with Windows",
            variable=self._startup_var,
            command=self._toggle_startup,
        )
        self._startup_check.pack(side="left", padx=8)

        # interval spinbox (right-aligned)
        ttk.Label(ctrl_frame, text="Interval (s):").pack(side="right")
        ttk.Spinbox(
            ctrl_frame,
            from_=10,
            to=3600,
            textvariable=self._interval_var,
            width=6,
        ).pack(side="right", padx=(0, 4))

        self._task_count_var = tk.StringVar(value="")
        ttk.Label(ctrl_frame, textvariable=self._task_count_var).pack(side="right", padx=8)

        # ── Task list ─────────────────────────────────────────────────
        list_frame = ttk.LabelFrame(self, text="Active tasks", padding=4)
        list_frame.pack(fill="both", padx=6, pady=(0, 4))

        cols = ("name", "type", "next_run")
        self._tree = ttk.Treeview(list_frame, columns=cols, show="headings", height=6)
        self._tree.heading("name", text="Name")
        self._tree.heading("type", text="Type")
        self._tree.heading("next_run", text="Next run")
        self._tree.column("name", width=220)
        self._tree.column("type", width=100)
        self._tree.column("next_run", width=160)
        self._tree.pack(fill="both", expand=True)
        self._tree.bind("<Button-3>", self._on_tree_right_click)

        # ── Log area ──────────────────────────────────────────────────
        log_frame = ttk.LabelFrame(self, text="Execution log", padding=4)
        log_frame.pack(fill="both", expand=True, padx=6, pady=(0, 6))

        log_toolbar = ttk.Frame(log_frame)
        log_toolbar.pack(fill="x", pady=(0, 2))
        ttk.Button(log_toolbar, text="Clear", command=self._clear_log).pack(side="right")

        self._log_widget = scrolledtext.ScrolledText(log_frame, state="disabled", font=("Courier New", 9))
        self._log_widget.pack(fill="both", expand=True)

        self._file_path.trace_add("write", self._on_path_change)

    def _attach_log_handler(self) -> None:
        handler = _WidgetHandler(self._log_widget)
        handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)-8s %(message)s", datefmt="%H:%M:%S"))
        logging.getLogger().addHandler(handler)
        logging.getLogger().setLevel(logging.INFO)

    def _apply_icon(self) -> None:
        icon = _find_icon()
        if icon:
            try:
                self.iconbitmap(icon)
            except Exception:
                pass

    # ------------------------------------------------------------------
    # Persistent config
    # ------------------------------------------------------------------

    def _load_config(self) -> None:
        try:
            data = json.loads(_CONFIG_PATH.read_text(encoding="utf-8"))
            if last := data.get("last_file"):
                self._file_path.set(last)
            if interval := data.get("interval"):
                self._interval_var.set(int(interval))
        except Exception:
            pass

    def _save_config(self) -> None:
        try:
            data = {
                "last_file": self._file_path.get().strip(),
                "interval": self._interval_var.get(),
            }
            _CONFIG_PATH.write_text(json.dumps(data, indent=2), encoding="utf-8")
        except Exception:
            pass

    # ------------------------------------------------------------------
    # File actions
    # ------------------------------------------------------------------

    def _browse(self) -> None:
        path = filedialog.askopenfilename(
            title="Select crontab or CSV file",
            filetypes=[
                ("Supported files", "*.txt *.cron *.csv"),
                ("All files", "*.*"),
            ],
        )
        if path:
            self._file_path.set(path)

    def _open_in_editor(self) -> None:
        path = self._file_path.get().strip()
        if not path:
            messagebox.showwarning("No file", "Please select a file first.")
            return
        try:
            if sys.platform == "win32":
                subprocess.run(["start", path], shell=True, check=True)
            elif sys.platform == "darwin":
                subprocess.run(["open", path], check=True)
            else:
                subprocess.run(["xdg-open", path], check=True)
        except Exception as exc:
            messagebox.showerror("Error opening file", str(exc))

    def _on_path_change(self, *_) -> None:
        path_str = self._file_path.get().strip()
        if path_str:
            path = Path(path_str)
            if path.suffix.lower() in {".txt", ".cron", ".csv"} and path.parent.is_dir() and not path.is_file():
                self._create_example_file(path)
        can_start = bool(path_str) and Path(path_str).is_file() and not self._is_running()
        self._btn_start.configure(state="normal" if can_start else "disabled")

    def _create_example_file(self, path: Path) -> None:
        content = _EXAMPLE_CSV if path.suffix.lower() == ".csv" else _EXAMPLE_CRONTAB
        try:
            path.write_text(content, encoding="utf-8")
            logger.info(f"Created example file: {path}")
        except Exception as exc:
            logger.error(f"Could not create {path}: {exc}")

    def _new_example_file(self) -> None:
        path_str = filedialog.asksaveasfilename(
            title="Create example file",
            defaultextension=".txt",
            filetypes=[
                ("Crontab", "*.txt *.cron"),
                ("CSV (date-based)", "*.csv"),
                ("All files", "*.*"),
            ],
        )
        if not path_str:
            return
        path = Path(path_str)
        if path.suffix.lower() not in {".txt", ".cron", ".csv"}:
            messagebox.showerror(
                "Unsupported extension",
                "Please choose a .txt, .cron, or .csv file.",
            )
            return
        if path.is_file():
            confirm = messagebox.askyesno(
                "Overwrite?",
                f"{path.name} already exists. Overwrite with the example template?",
            )
            if not confirm:
                self._file_path.set(str(path))
                return
        content = _EXAMPLE_CSV if path.suffix.lower() == ".csv" else _EXAMPLE_CRONTAB
        try:
            path.write_text(content, encoding="utf-8")
        except Exception as exc:
            messagebox.showerror("Error creating file", str(exc))
            return
        logger.info(f"Created example file: {path}")
        self._file_path.set(str(path))

    # ------------------------------------------------------------------
    # Task editor (Toplevel)
    # ------------------------------------------------------------------

    def _open_task_editor(self, focus_task: Optional[Task] = None) -> None:
        path_str = self._file_path.get().strip()
        if not path_str:
            messagebox.showwarning("No file", "Please select or create a file first.")
            return
        path = Path(path_str)
        if not path.is_file():
            messagebox.showwarning("Missing file", f"File does not exist: {path}")
            return

        if self._editor_window is not None and self._editor_window.winfo_exists():
            self._editor_window.lift()
            self._editor_window.focus_force()
            return

        try:
            current = path.read_text(encoding="utf-8-sig")
        except Exception as exc:
            messagebox.showerror("Read error", str(exc))
            return

        win = tk.Toplevel(self)
        self._editor_window = win
        win.title(f"Edit tasks — {path.name}")
        win.transient(self)
        win.minsize(640, 420)

        is_csv = path.suffix.lower() == ".csv"
        if is_csv:
            template_line = '01/01/2027 09:00;new_task;echo "hello"\n'
            help_text = "Format: dd/mm/YYYY HH:MM;NAME;COMMAND  (delimiter ;)"
        else:
            template_line = '0 9 * * 1-5  echo "hello"\n'
            help_text = "Format: <min> <hour> <dom> <mon> <dow>  <command>   (or @daily, @lundi, …)"

        ttk.Label(win, text=help_text, foreground="gray").pack(anchor="w", padx=6, pady=(6, 0))

        toolbar = ttk.Frame(win, padding=(6, 4))
        toolbar.pack(fill="x")

        text = scrolledtext.ScrolledText(win, font=("Courier New", 10), undo=True, wrap="none")
        text.pack(fill="both", expand=True, padx=6, pady=(0, 4))
        text.insert("1.0", current)
        text.focus_set()

        if focus_task is not None:
            self._highlight_task_line(text, focus_task, is_csv)

        def close_editor() -> None:
            self._editor_window = None
            win.destroy()

        def insert_template() -> None:
            text.insert("end", template_line)
            text.see("end")

        def save_changes() -> None:
            try:
                content = text.get("1.0", "end-1c")
                path.write_text(content, encoding="utf-8")
            except Exception as exc:
                messagebox.showerror("Save error", str(exc))
                return
            logger.info(f"Saved changes to {path.name}")
            close_editor()

        ttk.Button(toolbar, text=f"Insert {'CSV row' if is_csv else 'cron line'}", command=insert_template).pack(side="left")
        ttk.Button(toolbar, text="Cancel", command=close_editor).pack(side="right")
        ttk.Button(toolbar, text="Save", command=save_changes).pack(side="right", padx=4)

        win.protocol("WM_DELETE_WINDOW", close_editor)

    @staticmethod
    def _highlight_task_line(text: scrolledtext.ScrolledText, task: Task, is_csv: bool) -> None:
        needle = task.name.strip() if task.name else ""
        if not needle:
            return
        start = text.search(needle, "1.0", stopindex="end")
        if not start:
            return
        text.tag_remove("sel", "1.0", "end")
        text.tag_add("sel", start, f"{start} lineend")
        text.mark_set("insert", start)
        text.see(start)
        _ = is_csv  # reserved for future format-specific highlighting

    # ------------------------------------------------------------------
    # OS-startup integration
    # ------------------------------------------------------------------

    def _refresh_startup_state(self) -> None:
        if sys.platform != "win32":
            self._startup_var.set(False)
            self._startup_check.configure(state="disabled", text="Start with OS (Windows only)")
            return
        self._startup_var.set(_is_startup_enabled())

    def _toggle_startup(self) -> None:
        if sys.platform != "win32":
            messagebox.showwarning(
                "Not supported",
                "Launching at OS startup is currently only implemented on Windows.",
            )
            self._startup_var.set(False)
            return
        try:
            if self._startup_var.get():
                _enable_startup()
                logger.info("Added Crontable to Windows startup.")
            else:
                _disable_startup()
                logger.info("Removed Crontable from Windows startup.")
        except Exception as exc:
            messagebox.showerror("Startup error", str(exc))
            self._startup_var.set(_is_startup_enabled())

    # ------------------------------------------------------------------
    # Scheduler lifecycle
    # ------------------------------------------------------------------

    def _is_running(self) -> bool:
        return self._scheduler_thread is not None and self._scheduler_thread.is_alive()

    def _start(self) -> None:
        path = self._file_path.get().strip()
        if not path or not Path(path).is_file():
            messagebox.showerror("Error", "Please select a valid file.")
            return

        try:
            self._source = FileSource(path)
            tasks = self._source.load()
        except Exception as exc:
            messagebox.showerror("Load error", str(exc))
            return

        interval = float(max(10, self._interval_var.get()))
        self._scheduler = Scheduler(executor=AutoExecutor(), interval=interval)
        self._scheduler.add_tasks(tasks)
        self._refresh_task_list()

        self._scheduler_thread = threading.Thread(
            target=self._scheduler.run,
            daemon=True,
            name="crontable-scheduler",
        )
        self._scheduler_thread.start()

        self._set_running_state(True)
        self._poll()

    def _stop(self) -> None:
        if self._scheduler:
            self._scheduler.stop()
        self._set_running_state(False)

    def _set_running_state(self, running: bool) -> None:
        if running:
            self._status_var.set("Running")
            self._status_label.configure(foreground="green")
            self._btn_start.configure(state="disabled")
            self._btn_stop.configure(state="normal")
        else:
            has_file = bool(self._file_path.get().strip())
            self._status_var.set("Stopped")
            self._status_label.configure(foreground="gray")
            self._btn_start.configure(state="normal" if has_file else "disabled")
            self._btn_stop.configure(state="disabled")

    # ------------------------------------------------------------------
    # Log actions
    # ------------------------------------------------------------------

    def _clear_log(self) -> None:
        self._log_widget.configure(state="normal")
        self._log_widget.delete("1.0", tk.END)
        self._log_widget.configure(state="disabled")

    # ------------------------------------------------------------------
    # Task treeview – right-click context menu
    # ------------------------------------------------------------------

    def _on_tree_right_click(self, event: tk.Event) -> None:
        item = self._tree.identify_row(event.y)
        if not item:
            return
        task = self._task_map.get(item)
        if not task:
            return
        menu = tk.Menu(self, tearoff=0)
        menu.add_command(label=f"Run now: {task.name}", command=lambda: self._run_task_now(task))
        menu.add_command(label=f"Edit: {task.name}", command=lambda: self._open_task_editor(focus_task=task))
        menu.tk_popup(event.x_root, event.y_root)

    def _run_task_now(self, task: Task) -> None:
        executor = self._scheduler.executor if self._scheduler else AutoExecutor()
        threading.Thread(target=executor.run, args=(task,), daemon=True, name=f"manual-{task.name}").start()
        logger.info(f"Manually triggered task: {task.name!r}")

    # ------------------------------------------------------------------
    # Polling loop (runs on the main thread via after())
    # ------------------------------------------------------------------

    def _poll(self) -> None:
        if not self._is_running():
            self._set_running_state(False)
            return

        if self._source and self._source.has_changed():
            try:
                new_tasks = self._source.load()
                self._scheduler.reload_tasks(new_tasks)
                logger.info(f"Hot-reloaded {len(new_tasks)} task(s).")
            except Exception as exc:
                logger.error(f"Reload error: {exc}")

        self._refresh_task_list()
        self.after(self._POLL_MS, self._poll)

    def _refresh_task_list(self) -> None:
        if not self._scheduler:
            return

        tasks = self._scheduler.list_tasks()

        self._task_map.clear()
        for row in self._tree.get_children():
            self._tree.delete(row)

        for task in tasks:
            nxt = task.next_run()
            nxt_str = nxt.strftime("%Y-%m-%d %H:%M:%S") if nxt else "—"
            iid = self._tree.insert("", "end", values=(task.name, type(task).__name__, nxt_str))
            self._task_map[iid] = task

        self._task_count_var.set(f"{len(tasks)} task(s)")

    # ------------------------------------------------------------------
    # Close
    # ------------------------------------------------------------------

    def _on_close(self) -> None:
        self._save_config()
        self._stop()
        self.destroy()


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def main() -> None:
    app = CrontableApp()
    app.mainloop()


if __name__ == "__main__":
    main()
