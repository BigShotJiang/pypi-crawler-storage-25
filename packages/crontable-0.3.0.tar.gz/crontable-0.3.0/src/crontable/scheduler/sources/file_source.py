from __future__ import annotations

import logging
from pathlib import Path
from typing import List, Optional

from crontable.scheduler.core.task import Task
from crontable.scheduler.parsers.cron_parser import CronParser
from crontable.scheduler.parsers.csv_parser import CsvParser

logger = logging.getLogger(__name__)

_SUPPORTED = {".csv", ".txt", ".cron"}


class FileSource:
    """
    Load tasks from a file, dispatching to the correct parser by extension:
      .csv          → CsvParser  → List[DateTask]
      .txt / .cron  → CronParser → List[CronTask]

    Also supports hot-reload detection via mtime tracking.
    """

    def __init__(
        self,
        path: str | Path,
        csv_parser: Optional[CsvParser] = None,
        cron_parser: Optional[CronParser] = None,
    ) -> None:
        self._path = Path(path)
        self._csv_parser = csv_parser or CsvParser()
        self._cron_parser = cron_parser or CronParser()
        # Initialise to current mtime so has_changed() returns False until the
        # file is actually modified after construction. First explicit load()
        # call is still always needed to populate tasks.
        try:
            self._last_mtime: float = self._path.stat().st_mtime
        except OSError:
            self._last_mtime = 0.0

        suffix = self._path.suffix.lower()
        if suffix not in _SUPPORTED:
            raise ValueError(f"Unsupported extension {suffix!r}. Supported: {sorted(_SUPPORTED)}")

    def load(self) -> List[Task]:
        if not self._path.exists():
            raise FileNotFoundError(f"Source file not found: {self._path}")

        self._last_mtime = self._path.stat().st_mtime
        suffix = self._path.suffix.lower()

        if suffix == ".csv":
            return self._csv_parser.parse(self._path)
        return self._cron_parser.parse(self._path)

    def has_changed(self) -> bool:
        """Return True if the source file has been modified since last load()."""
        try:
            return self._path.stat().st_mtime != self._last_mtime
        except OSError:
            return False

    def load_if_changed(self) -> Optional[List[Task]]:
        """Return a fresh task list only when the file has changed, else None."""
        if self.has_changed():
            return self.load()
        return None
