"""Default facade executor — auto-dispatches on ``task.action`` type.

One executor to rule them all, from the user's perspective:

    Scheduler(executor=AutoExecutor())

Internally, three small strategy classes do the actual work
(:class:`InProcessCallableExecutor`, :class:`ShellCommandExecutor`, and
any custom strategies registered via :meth:`AutoExecutor.register`).

Dispatch rules (checked in order):
    1. Custom strategies registered via ``register()`` — most recent first.
    2. ``callable(task.action)`` → :class:`InProcessCallableExecutor`
    3. ``isinstance(task.action, str)`` and non-empty → :class:`ShellCommandExecutor`
    4. Otherwise → warning, no-op.
"""

from __future__ import annotations

import logging
from typing import Callable, List, Optional, Tuple

from crontable.scheduler.core.task import Task
from crontable.scheduler.executors.base_executor import Executor
from crontable.scheduler.executors.callable_ import InProcessCallableExecutor
from crontable.scheduler.executors.shell import ShellCommandExecutor

logger = logging.getLogger(__name__)

Predicate = Callable[[Task], bool]


class AutoExecutor(Executor):
    """
    Implicit, pluggable dispatch between the built-in executor strategies.

    Parameters
    ----------
    timeout:
        Forwarded to the default :class:`ShellCommandExecutor` and
        :class:`PythonScriptExecutor` if they are auto-constructed.
    shell:
        Forwarded to the default :class:`ShellCommandExecutor`.
    shell_executor, callable_executor:
        Explicit overrides for the built-in strategies. Pass a pre-built
        executor to customize timeout / retry / logging behavior without
        subclassing ``AutoExecutor``.
    """

    def __init__(
        self,
        *,
        timeout: Optional[float] = None,
        shell: Optional[bool] = None,
        shell_executor: Optional[Executor] = None,
        callable_executor: Optional[Executor] = None,
    ) -> None:
        self._shell: Executor = shell_executor or ShellCommandExecutor(timeout=timeout, shell=shell)
        self._callable: Executor = callable_executor or InProcessCallableExecutor()
        self._custom: List[Tuple[Predicate, Executor]] = []

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def register(self, predicate: Predicate, executor: Executor) -> None:
        """
        Register a custom (predicate, executor) pair.

        ``predicate(task)`` receives the task and returns True if
        ``executor`` should handle it. Newest registrations take
        precedence (LIFO), so users can override built-ins by matching
        the same shape.

        Example
        -------
        >>> auto = AutoExecutor()
        >>> auto.register(
        ...     lambda t: t.name.startswith("backup_"),
        ...     PythonScriptExecutor("@home/scripts/backup.py"),
        ... )
        """
        if not callable(predicate):
            raise TypeError("predicate must be callable")
        if not callable(getattr(executor, "run", None)):
            raise TypeError(f"executor must expose a callable run(task) method, " f"got {type(executor).__name__}")
        self._custom.append((predicate, executor))

    def run(self, task: Task) -> None:
        for predicate, executor in reversed(self._custom):
            try:
                matched = predicate(task)
            except Exception:
                logger.exception(
                    "AutoExecutor predicate raised for task %r — skipping strategy",
                    task.name,
                )
                continue
            if matched:
                executor.run(task)
                return

        action = task.action
        if callable(action):
            self._callable.run(task)
        elif isinstance(action, str) and action.strip():
            self._shell.run(task)
        else:
            logger.warning(f"Task {task.name!r} has no executable action.")

    # ------------------------------------------------------------------
    # Introspection helpers (useful for tests and debug)
    # ------------------------------------------------------------------

    @property
    def shell_executor(self) -> Executor:
        return self._shell

    @property
    def callable_executor(self) -> Executor:
        return self._callable
