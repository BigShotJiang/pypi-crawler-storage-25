"""Shared helpers for path-alias resolution and cwd detection.

These live in one place so that every executor strategy
(shell, python script, …) shares exactly the same rules.
"""
from __future__ import annotations

import logging
import os
import shlex
import subprocess
import sys
from pathlib import Path
from typing import Tuple

logger = logging.getLogger(__name__)

IS_WINDOWS = os.name == "nt"
POSIX_SPLIT = not IS_WINDOWS

PATH_ALIASES: dict[str, Path] = {
    "@home": Path.home(),
    "@desktop": Path.home() / "Desktop",
    "@python": Path(sys.executable),
    "@pythonw": Path(sys.executable.replace("python.exe", "pythonw.exe")),
}

# Windows cmd.exe built-ins that cannot be invoked as standalone binaries.
WIN_CMD_BUILTINS: frozenset[str] = frozenset({
    "assoc", "break", "call", "cd", "chdir", "cls", "color", "copy",
    "date", "del", "dir", "echo", "endlocal", "erase", "exit", "for",
    "ftype", "goto", "if", "md", "mkdir", "mklink", "more", "move",
    "path", "pause", "popd", "prompt", "pushd", "rd", "rem", "ren",
    "rename", "rmdir", "set", "setlocal", "shift", "start", "time",
    "title", "type", "ver", "verify", "vol",
})


def resolve_aliases(command: str) -> str:
    """Replace every ``@alias`` token in *command* by its absolute path."""
    for alias, path in PATH_ALIASES.items():
        command = command.replace(alias, str(path))
    return command


def split_cwd(command: str) -> Tuple[Path, str]:
    """If the first shell token is an existing directory, use it as cwd."""
    try:
        tokens = shlex.split(command, posix=POSIX_SPLIT)
    except ValueError:
        return Path.cwd(), command
    if not tokens:
        return Path.cwd(), command
    first = Path(tokens[0])
    if not first.is_dir():
        return Path.cwd(), command
    logger.info(f"Switched cwd to {first}")
    if POSIX_SPLIT:
        remainder = shlex.join(tokens[1:])
    else:
        remainder = subprocess.list2cmdline(tokens[1:])
    return first, remainder


def needs_shell(command: str) -> bool:
    """Return True if *command* should run via ``shell=True``.

    Only matters on Windows: the cmd.exe built-ins (``echo``, ``dir``, …)
    cannot be invoked as standalone executables, so we fall back to shell
    mode for those. Everywhere else, ``shell=False`` is the safe default.
    """
    if not IS_WINDOWS:
        return False
    stripped = command.lstrip()
    if not stripped:
        return False
    first = stripped.split(None, 1)[0].lower()
    return first in WIN_CMD_BUILTINS
