from __future__ import annotations

from abc import ABC, abstractmethod

from crontable.scheduler.core.task import Task


class Executor(ABC):
    """Contract for all task executors."""

    @abstractmethod
    def run(self, task: Task) -> None:
        """Execute the given task."""
