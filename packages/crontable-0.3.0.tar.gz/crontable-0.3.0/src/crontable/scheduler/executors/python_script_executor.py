"""Run a fixed Python script per task, with arguments derived from metadata."""

from __future__ import annotations

import logging
import subprocess
import sys
from pathlib import Path
from typing import List, Optional

from crontable.scheduler.core.task import Task
from crontable.scheduler.executors._paths import resolve_aliases
from crontable.scheduler.executors.base_executor import Executor

logger = logging.getLogger(__name__)

_SKIP_COLUMNS = {"DATE", "NAME", "COMMAND"}


class PythonScriptExecutor(Executor):
    """
    Run a fixed ``.py`` script via ``subprocess.run``, forwarding
    task metadata as argv.

    Unlike :class:`ShellCommandExecutor`, the command is built from a
    list — so paths with spaces are handled correctly on every OS.

    Parameters
    ----------
    script:
        Path to the .py file. Supports ``@home``/``@desktop``/``@python`` aliases.
    arg_columns:
        Ordered list of CSV column names to pass as positional arguments.
        If ``None``, every metadata column except DATE/NAME/COMMAND is
        forwarded as ``--column value`` keyword pairs.
    timeout:
        Maximum seconds to wait for the subprocess. None means no limit.
    """

    def __init__(
        self,
        script: str | Path,
        arg_columns: Optional[List[str]] = None,
        *,
        timeout: Optional[float] = None,
    ) -> None:
        self.script = Path(resolve_aliases(str(script)))
        self.arg_columns = [c.upper() for c in arg_columns] if arg_columns is not None else None
        self.timeout = timeout

    def run(self, task: Task) -> None:
        metadata = getattr(task, "metadata", {}) or {}
        args = self._build_args(metadata)
        cmd = [sys.executable, str(self.script), *args]

        logger.info(f"PythonScriptExecutor: {cmd}")
        try:
            result = subprocess.run(
                cmd,
                check=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=self.timeout,
            )
            if result.stdout:
                logger.info(result.stdout.decode("utf-8", errors="replace").rstrip())
        except subprocess.TimeoutExpired:
            logger.error(f"Script timed out after {self.timeout}s: {self.script.name}")
        except FileNotFoundError:
            logger.error(f"Script not found: {self.script}")
        except subprocess.CalledProcessError as exc:
            stderr = exc.stderr.decode("utf-8", errors="replace") if exc.stderr else ""
            logger.error(f"Script failed (exit {exc.returncode}): {stderr.rstrip()}")

    def _build_args(self, metadata: dict) -> List[str]:
        if self.arg_columns is not None:
            return [metadata[col] for col in self.arg_columns if metadata.get(col)]
        args: List[str] = []
        for key, val in metadata.items():
            if key not in _SKIP_COLUMNS and val:
                args += [f"--{key.lower()}", val]
        return args
