"""Executor package — one facade, many strategies.

Public API:
    Executor                    — abstract base / duck-typed contract
    AutoExecutor                — implicit dispatch (recommended default)
    ShellCommandExecutor        — str action → subprocess.run
    InProcessCallableExecutor   — callable action → direct call
    PythonScriptExecutor        — fixed .py script + metadata → argv
    MultiprocessExecutor        — callable → multiprocessing.Process

Backwards-compat aliases (deprecated, kept for existing imports):
    SubprocessExecutor → AutoExecutor
    FunctionExecutor   → MultiprocessExecutor
"""

from crontable.scheduler.executors.auto import AutoExecutor
from crontable.scheduler.executors.base_executor import Executor
from crontable.scheduler.executors.callable_ import InProcessCallableExecutor
from crontable.scheduler.executors.multiprocess import MultiprocessExecutor
from crontable.scheduler.executors.python_script_executor import \
    PythonScriptExecutor
from crontable.scheduler.executors.shell import ShellCommandExecutor

# Backwards-compatibility aliases.
SubprocessExecutor = AutoExecutor
FunctionExecutor = MultiprocessExecutor

__all__ = [
    "Executor",
    "AutoExecutor",
    "ShellCommandExecutor",
    "InProcessCallableExecutor",
    "PythonScriptExecutor",
    "MultiprocessExecutor",
    "SubprocessExecutor",
    "FunctionExecutor",
]
