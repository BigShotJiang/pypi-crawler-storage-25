"""Run a Python callable out-of-process via ``multiprocessing.Process``.

Non-blocking: ``run()`` returns as soon as the child process is spawned.
Finished child handles are reaped on the next call to ``run()`` so PIDs
do not accumulate over long-running schedulers.
"""

from __future__ import annotations

import logging
import multiprocessing
from typing import Callable, List, Optional

from crontable.scheduler.core.task import Task
from crontable.scheduler.executors.base_executor import Executor

logger = logging.getLogger(__name__)

_SKIP_COLUMNS = {"DATE", "NAME", "COMMAND"}


class MultiprocessExecutor(Executor):
    """
    Run a top-level Python callable in a child process for each task fire.

    The callable must be picklable (defined at module top-level) because
    ``multiprocessing`` uses ``spawn`` on Windows / macOS.

    Parameters
    ----------
    func:
        Top-level callable to invoke for each task.
    arg_columns:
        Ordered list of CSV column names to pass as positional arguments.
        If ``None``, every metadata column except DATE/NAME/COMMAND is
        forwarded as ``**kwargs`` with lowercased keys.
    """

    def __init__(
        self,
        func: Callable,
        arg_columns: Optional[List[str]] = None,
    ) -> None:
        if not callable(func):
            raise TypeError(f"func must be callable, got {type(func).__name__!r}")
        self.func = func
        self.arg_columns = [c.upper() for c in arg_columns] if arg_columns is not None else None
        self._children: List[multiprocessing.Process] = []
        self._last_process: Optional[multiprocessing.Process] = None

    def run(self, task: Task) -> None:
        self._reap_finished()

        metadata = getattr(task, "metadata", {}) or {}
        args, kwargs = self._build_call(metadata)

        p = multiprocessing.Process(target=self.func, args=args, kwargs=kwargs, daemon=True)
        p.start()
        self._children.append(p)
        self._last_process = p
        logger.info("MultiprocessExecutor: PID %d started for task %r", p.pid, task.name)

    def close(self, timeout: float = 2.0) -> None:
        """Join remaining children. Call on scheduler shutdown."""
        for p in self._children:
            if p.is_alive():
                p.join(timeout=timeout)
        self._children = [p for p in self._children if p.is_alive()]

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _reap_finished(self) -> None:
        still_alive: List[multiprocessing.Process] = []
        for p in self._children:
            if p.is_alive():
                still_alive.append(p)
            else:
                p.join(timeout=0)  # ensure OS resources are released
        self._children = still_alive

    def _build_call(self, metadata: dict) -> tuple[tuple, dict]:
        if self.arg_columns is not None:
            args = tuple(metadata[col] for col in self.arg_columns if col in metadata)
            return args, {}
        kwargs = {k.lower(): v for k, v in metadata.items() if k not in _SKIP_COLUMNS and v}
        return (), kwargs
