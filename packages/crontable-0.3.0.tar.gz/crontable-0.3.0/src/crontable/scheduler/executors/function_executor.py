"""Backwards-compat shim — renamed to :class:`MultiprocessExecutor`."""

from __future__ import annotations

from crontable.scheduler.executors.multiprocess import MultiprocessExecutor

FunctionExecutor = MultiprocessExecutor

__all__ = ["FunctionExecutor"]
