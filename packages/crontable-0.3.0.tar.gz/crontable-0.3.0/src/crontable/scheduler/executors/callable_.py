"""Execute a task whose ``action`` is a Python callable, in-process."""

from __future__ import annotations

import logging

from crontable.scheduler.core.task import Task
from crontable.scheduler.executors.base_executor import Executor

logger = logging.getLogger(__name__)


class InProcessCallableExecutor(Executor):
    """
    Call ``task.action()`` synchronously, in the scheduler thread.

    If the task carries a ``metadata`` dict (DateTask convention), it is
    forwarded as the first positional argument; otherwise the callable is
    invoked with no arguments. Exceptions are caught and logged — they
    never escape to the scheduler.
    """

    def run(self, task: Task) -> None:
        action = task.action
        if not callable(action):
            logger.warning(f"Task {task.name!r} has no callable action.")
            return

        metadata = getattr(task, "metadata", None)
        try:
            if metadata is not None:
                action(metadata)
            else:
                action()
        except Exception:
            logger.exception(f"Callable action failed for task {task.name!r}")
