"""Execute a task whose ``action`` is a shell-command string."""

from __future__ import annotations

import logging
import shlex
import subprocess
from pathlib import Path
from typing import Optional

from crontable.scheduler.core.task import Task
from crontable.scheduler.executors._paths import POSIX_SPLIT, needs_shell, resolve_aliases, split_cwd
from crontable.scheduler.executors.base_executor import Executor

logger = logging.getLogger(__name__)


class ShellCommandExecutor(Executor):
    """
    Run ``task.action`` as a shell command via ``subprocess.run``.

    Parameters
    ----------
    timeout:
        Maximum seconds to wait for the subprocess. None means no limit.
    shell:
        Controls the ``subprocess.run(shell=...)`` flag.
        - ``None`` (default) — auto: ``True`` on Windows when the command
          starts with a cmd.exe built-in (``echo``, ``dir``, …), ``False``
          otherwise.
        - ``True`` / ``False`` — explicit override.
    """

    def __init__(
        self,
        timeout: Optional[float] = None,
        shell: Optional[bool] = None,
    ) -> None:
        self.timeout = timeout
        self.shell = shell

    def run(self, task: Task) -> None:
        action = task.action
        if not (isinstance(action, str) and action.strip()):
            logger.warning(f"Task {task.name!r} has no executable action.")
            return
        self._run_command(action)

    def _resolve_shell_mode(self, command: str) -> bool:
        if self.shell is not None:
            return self.shell
        return needs_shell(command)

    def _run_command(self, command: str) -> str:
        command = resolve_aliases(command)
        cwd, command = split_cwd(command)
        use_shell = self._resolve_shell_mode(command)

        logger.info(f"Executing at {cwd}: {command}")
        try:
            if use_shell:
                popen_arg: object = command
            else:
                popen_arg = shlex.split(command, posix=POSIX_SPLIT)
                if not popen_arg:
                    logger.warning("Empty command after parsing.")
                    return ""

            result = subprocess.run(
                popen_arg,
                shell=use_shell,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                cwd=str(cwd),
                check=True,
                timeout=self.timeout,
            )
            stdout = result.stdout.decode("utf-8", errors="replace")
            if stdout:
                logger.info(f"stdout: {stdout.rstrip()}")
            return stdout

        except subprocess.TimeoutExpired:
            logger.error(f"Command timed out after {self.timeout}s: {command!r}")
        except FileNotFoundError:
            logger.error(f"Command not found: {command!r}")
        except PermissionError as exc:
            logger.error(f"Permission denied for {command!r}: {exc}")
        except subprocess.CalledProcessError as exc:
            stderr = exc.stderr.decode("utf-8", errors="replace") if exc.stderr else ""
            logger.error(f"Command failed (exit {exc.returncode}), stderr: {stderr.rstrip()}")
        except ValueError as exc:  # shlex parse errors
            logger.error(f"Cannot parse command {command!r}: {exc}")
        return ""

    # ------------------------------------------------------------------
    # Back-compat shims — keep the old SubprocessExecutor classmethods
    # alive for any user code that reached into the private API.
    # ------------------------------------------------------------------

    @staticmethod
    def _resolve_aliases(command: str) -> str:
        return resolve_aliases(command)

    @staticmethod
    def _split_cwd(command: str):
        return split_cwd(command)
