"""Backwards-compat shim.

``SubprocessExecutor`` used to dispatch on ``callable(action)`` vs ``str``
inside a single class. That role is now owned by :class:`AutoExecutor`,
which delegates to :class:`InProcessCallableExecutor` and
:class:`ShellCommandExecutor` respectively.

``SubprocessExecutor`` is kept as a thin alias so existing imports
continue to work. New code should prefer :class:`AutoExecutor` (for
implicit dispatch) or the dedicated strategy classes directly.

The ``_PATH_ALIASES`` module attribute is kept for any user code that
imported it. Prefer :mod:`crontable.scheduler.executors._paths` going
forward.
"""

from __future__ import annotations

from crontable.scheduler.executors._paths import PATH_ALIASES as _PATH_ALIASES  # noqa: F401
from crontable.scheduler.executors.auto import AutoExecutor

SubprocessExecutor = AutoExecutor

__all__ = ["SubprocessExecutor"]
__all__ = ["SubprocessExecutor"]
