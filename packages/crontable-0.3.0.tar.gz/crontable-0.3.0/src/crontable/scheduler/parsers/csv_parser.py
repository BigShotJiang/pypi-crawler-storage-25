from __future__ import annotations

import csv
import logging
from datetime import datetime
from pathlib import Path
from typing import List, Optional

from crontable.scheduler.tasks.date_task import DateTask

logger = logging.getLogger(__name__)

_DATE_COLUMN = "DATE"
_DEFAULT_DATE_FORMAT = "%d/%m/%Y %H:%M"
_DEFAULT_DELIMITER = ";"


class CsvParser:
    """
    Parse a semicolon-delimited CSV file into DateTask objects.

    Required column : DATE  (format configurable, default dd/mm/YYYY HH:MM)
    Optional columns: COMMAND (action string), NAME (task label)
    All other columns are stored in task.metadata.
    """

    def __init__(
        self,
        date_format: str = _DEFAULT_DATE_FORMAT,
        delimiter: str = _DEFAULT_DELIMITER,
        action_column: Optional[str] = "COMMAND",
        name_column: Optional[str] = "NAME",
    ) -> None:
        self.date_format = date_format
        self.delimiter = delimiter
        self.action_column = action_column.upper() if action_column else None
        self.name_column = name_column.upper() if name_column else None

    def parse(self, path: Path) -> List[DateTask]:
        tasks: List[DateTask] = []

        with path.open(newline="", encoding="utf-8-sig") as fh:
            reader = csv.DictReader(fh, delimiter=self.delimiter)

            if reader.fieldnames is None:
                raise ValueError(f"Empty or header-less CSV: {path}")

            headers_upper = {f.strip().upper() for f in reader.fieldnames}
            if _DATE_COLUMN not in headers_upper:
                raise ValueError(f"Missing '{_DATE_COLUMN}' column in {path}. " f"Found: {sorted(headers_upper)}")

            for row in reader:
                normalized = {k.strip().upper(): v.strip() for k, v in row.items() if k is not None}
                date_str = normalized.get(_DATE_COLUMN, "")
                if not date_str:
                    logger.warning(f"Skipping row with empty DATE: {row}")
                    continue
                try:
                    scheduled_at = datetime.strptime(date_str, self.date_format)
                except ValueError as exc:
                    logger.warning(f"Skipping row with invalid date {date_str!r}: {exc}")
                    continue

                action = normalized.get(self.action_column, "") if self.action_column else ""
                name = normalized.get(self.name_column, "") if self.name_column else ""

                tasks.append(
                    DateTask(
                        scheduled_at=scheduled_at,
                        action=action,
                        name=name,
                        metadata=normalized,
                    )
                )

        logger.info(f"CsvParser: loaded {len(tasks)} task(s) from {path.name}")
        return tasks
