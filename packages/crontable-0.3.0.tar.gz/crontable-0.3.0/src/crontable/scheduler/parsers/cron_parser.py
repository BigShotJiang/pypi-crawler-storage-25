from __future__ import annotations

import logging
from pathlib import Path
from typing import Dict, List

from crontable.scheduler.tasks.cron_task import CronTask

logger = logging.getLogger(__name__)

# Alias → 5-field cron expression
REPLACEMENTS: Dict[str, str] = {
    "@year": "0 0 1 1 *",
    "@annually": "0 0 1 1 *",
    "@daily": "0 0 * * *",
    "@midnight": "0 0 * * *",
    "@noon": "0 12 * * *",
    "@hourly": "0 * * * *",
    "@monthly": "0 0 1 * *",
    "@weekly": "0 0 * * 0",
    "@reboot": "* * * * *",
    # English weekday shortcuts
    "@mon": "0 0 * * 1",
    "@tue": "0 0 * * 2",
    "@wed": "0 0 * * 3",
    "@thu": "0 0 * * 4",
    "@fri": "0 0 * * 5",
    "@sat": "0 0 * * 6",
    "@sun": "0 0 * * 0",
    # French weekday shortcuts
    "@lundi": "0 0 * * 1",
    "@mardi": "0 0 * * 2",
    "@mercredi": "0 0 * * 3",
    "@jeudi": "0 0 * * 4",
    "@vendredi": "0 0 * * 5",
    "@samedi": "0 0 * * 6",
    "@dimanche": "0 0 * * 0",
    # Compound aliases
    "@biweekly": "0 0 * * 0,2,4",
    "@bimonthly": "0 0 1,15 * *",
}


class CronParser:
    """
    Parse a crontab-style text file into CronTask objects.

    Line format:  <min> <hour> <dom> <mon> <dow>  <command>
    Aliases like @daily, @lundi, etc. are expanded before parsing.
    Lines starting with # or blank lines are ignored.
    """

    def parse(self, path: Path) -> List[CronTask]:
        raw_lines = path.read_text(encoding="utf-8").splitlines()
        expanded = self._expand_aliases(raw_lines)

        tasks: List[CronTask] = []
        for lineno, line in enumerate(expanded, start=1):
            stripped = line.strip()
            if not stripped or stripped.startswith("#"):
                continue
            try:
                task = self._parse_line(stripped)
                tasks.append(task)
            except Exception as exc:
                logger.warning(f"Skipping line {lineno}: {stripped!r} — {exc}")

        logger.info(f"CronParser: loaded {len(tasks)} task(s) from {path.name}")
        return tasks

    # ------------------------------------------------------------------

    @staticmethod
    def _expand_aliases(lines: List[str]) -> List[str]:
        result: List[str] = []
        for line in lines:
            stripped = line.strip()
            for alias, expr in REPLACEMENTS.items():
                if stripped == alias or stripped.startswith(alias + " "):
                    rest = stripped[len(alias) :].strip()
                    line = f"{expr} {rest}"
                    break
            result.append(line)
        return result

    @staticmethod
    def _parse_line(line: str) -> CronTask:
        # Split into at most 6 parts: 5 cron fields + remainder as command
        tokens = line.split(None, 5)
        if len(tokens) < 6:
            raise ValueError(f"Expected 5 cron fields + command (got {len(tokens)} token(s)): {line!r}")
        cron_expr = " ".join(tokens[:5])
        command = tokens[5].strip()
        name = command[:50]
        return CronTask(cron_expr=cron_expr, action=command, name=name)
