from __future__ import annotations

import logging
import threading
from datetime import datetime
from typing import List, Optional, Protocol

from crontable.scheduler.core.task import Task
from crontable.scheduler.executors.base_executor import Executor

logger = logging.getLogger(__name__)


class TaskSource(Protocol):
    """Structural contract for anything the scheduler can hot-reload from.

    ``FileSource`` satisfies this implicitly — no inheritance needed.
    """

    def has_changed(self) -> bool: ...
    def load(self) -> List[Task]: ...


class Scheduler:
    """
    Main scheduling loop.

    - Holds a list of tasks.
    - Polls at a configurable interval.
    - Delegates execution to an Executor.
    - Optionally watches a ``TaskSource`` for changes and hot-reloads.
    - No I/O, no parsing, no subprocess logic here.
    - Thread-safe: add_tasks / reload_tasks / list_tasks can be called
      from any thread.

    Parameters
    ----------
    executor:
        Component that actually runs a due task. Defaults to
        :class:`AutoExecutor`, which dispatches implicitly based on
        ``task.action`` (callable → in-process call, str → shell command).
    interval:
        Seconds between ticks (and, when enabled, between reload checks).
    source:
        Optional ``TaskSource`` (e.g. ``FileSource``) to poll for changes.
    reload_on_change:
        When True and ``source`` is provided, each tick calls
        ``source.has_changed()`` and, on a positive answer, swaps the task
        list with ``source.load()`` atomically via ``reload_tasks``. A
        failing ``load()`` is logged and the current task list is kept.
        Default False (opt-in) to preserve existing behavior.
    """

    def __init__(
        self,
        executor: Optional[Executor] = None,
        interval: float = 60.0,
        source: Optional[TaskSource] = None,
        reload_on_change: bool = False,
    ) -> None:
        if executor is None:
            # Lazy import to avoid a circular dependency with the
            # executors package at module load time.
            from crontable.scheduler.executors.auto import AutoExecutor

            executor = AutoExecutor()
        self._executor = executor
        self._interval = interval
        self._source = source
        self._reload_on_change = reload_on_change
        self._tasks: List[Task] = []
        self._stop_event = threading.Event()
        self._lock = threading.Lock()

    # ------------------------------------------------------------------
    # Task management
    # ------------------------------------------------------------------

    def add_tasks(self, tasks: List[Task]) -> None:
        with self._lock:
            self._tasks.extend(tasks)
            total = len(self._tasks)
        logger.info(f"Added {len(tasks)} task(s). Total: {total}")

    def clear_tasks(self) -> None:
        with self._lock:
            self._tasks.clear()

    def reload_tasks(self, tasks: List[Task]) -> None:
        """Hot-reload: atomically replace the active task list."""
        with self._lock:
            self._tasks[:] = tasks
        logger.info(f"Reloaded {len(tasks)} task(s).")

    def list_tasks(self) -> List[Task]:
        """Return a thread-safe snapshot of the currently scheduled tasks."""
        with self._lock:
            return list(self._tasks)

    @property
    def executor(self) -> Executor:
        return self._executor

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def stop(self) -> None:
        logger.info("Stop requested.")
        self._stop_event.set()

    def run(self) -> None:
        logger.info("Scheduler started.")
        while not self._stop_event.is_set():
            self._tick()
            self._stop_event.wait(self._interval)
        logger.info("Scheduler stopped.")

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _tick(self) -> None:
        if self._reload_on_change and self._source is not None:
            self._check_and_reload()

        now = datetime.now()

        with self._lock:
            snapshot = list(self._tasks)

        for task in snapshot:
            if not task.is_due(now):
                continue
            try:
                self._executor.run(task)
            except Exception:
                logger.exception(f"Executor raised for task {task!r}")
            finally:
                task.mark_executed(now)

        # Prune completed one-shot tasks and collect the upcoming schedule
        # under a single lock acquisition.
        with self._lock:
            before = len(self._tasks)
            self._tasks = [t for t in self._tasks if t.next_run() is not None]
            pruned = before - len(self._tasks)
            upcoming = [t.next_run() for t in self._tasks]

        if pruned:
            logger.debug(f"Pruned {pruned} completed one-shot task(s).")

        future_runs = [r for r in upcoming if r is not None]
        if future_runs:
            logger.debug(f"Next scheduled run: {min(future_runs)}")

    def _check_and_reload(self) -> None:
        """Swap in fresh tasks if the source changed. Keep current list on error."""
        assert self._source is not None  # guarded by caller
        try:
            if not self._source.has_changed():
                return
            fresh = self._source.load()
        except Exception:
            logger.exception("Source reload failed — keeping current task list")
            return
        self.reload_tasks(fresh)
