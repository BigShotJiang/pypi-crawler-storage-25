from __future__ import annotations

from abc import ABC, abstractmethod
from datetime import datetime
from typing import Callable, Optional, Union


class Task(ABC):
    """Abstract base for all schedulable tasks."""

    def __init__(self, action: Union[str, Callable], name: str = "") -> None:
        self.action = action
        self.name = name
        self._last_run: Optional[datetime] = None

    @abstractmethod
    def is_due(self, now: datetime) -> bool:
        """Return True if the task should fire at *now*."""

    @abstractmethod
    def next_run(self) -> Optional[datetime]:
        """Return the next scheduled datetime, or None if no future run exists."""

    def mark_executed(self, at: datetime) -> None:
        self._last_run = at

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(name={self.name!r}, next={self.next_run()})"
