from __future__ import annotations

from datetime import datetime
from typing import Callable, Union

from croniter import croniter
from crontable.scheduler.core.task import Task


class CronTask(Task):
    """Repeating task driven by a standard 5-field cron expression."""

    def __init__(
        self,
        cron_expr: str,
        action: Union[str, Callable],
        name: str = "",
    ) -> None:
        super().__init__(action, name)
        self.cron_expr = cron_expr
        self._iter = croniter(cron_expr, datetime.now())
        self._next: datetime = self._iter.get_next(datetime)

    def is_due(self, now: datetime) -> bool:
        return now >= self._next

    def next_run(self) -> datetime:
        return self._next

    def mark_executed(self, at: datetime) -> None:
        super().mark_executed(at)
        self._next = self._iter.get_next(datetime)
