from __future__ import annotations

from datetime import datetime
from typing import Callable, Dict, Optional, Union

from crontable.scheduler.core.task import Task


class DateTask(Task):
    """One-shot task triggered at a specific datetime."""

    def __init__(
        self,
        scheduled_at: datetime,
        action: Union[str, Callable],
        name: str = "",
        metadata: Optional[Dict] = None,
    ) -> None:
        super().__init__(action, name)
        self.scheduled_at = scheduled_at
        self.metadata: Dict = metadata or {}
        self._executed = False

    def is_due(self, now: datetime) -> bool:
        return not self._executed and now >= self.scheduled_at

    def next_run(self) -> Optional[datetime]:
        return None if self._executed else self.scheduled_at

    def mark_executed(self, at: datetime) -> None:
        super().mark_executed(at)
        self._executed = True
