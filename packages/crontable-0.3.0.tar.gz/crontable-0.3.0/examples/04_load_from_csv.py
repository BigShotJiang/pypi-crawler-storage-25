"""Load one-shot DateTasks from a semicolon-delimited CSV file.

Required CSV column: DATE (format ``dd/mm/YYYY HH:MM`` by default).
Optional columns   : COMMAND (action string), NAME (label).
Any extra columns  : stored on ``task.metadata``.

The parser uses ``utf-8-sig`` encoding so Excel-exported CSVs (with a BOM)
load cleanly.

Run with:
    python examples/04_load_from_csv.py
"""

from __future__ import annotations

import logging
from pathlib import Path

from crontable import AutoExecutor, FileSource, Scheduler

CSV_PATH = Path(__file__).parent / "data" / "tasks.csv"


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(message)s")

    source = FileSource(CSV_PATH)
    tasks = source.load()

    print(f"Loaded {len(tasks)} task(s) from {CSV_PATH.name}:")
    for task in tasks:
        print(f"  - {task.name!r} at {task.next_run()}  metadata={task.metadata}")

    # The sample CSV has dates in 2027, so nothing fires right away — this
    # example is about loading/parsing, not execution. Start the loop only
    # if you actually want to wait.
    scheduler = Scheduler(executor=AutoExecutor(), interval=60.0)
    scheduler.add_tasks(tasks)
    print(f"Scheduler has {len(scheduler.list_tasks())} task(s) queued.")


if __name__ == "__main__":
    main()
