"""Minimal programmatic setup: one DateTask + one CronTask in a single loop.

Run with:
    python examples/01_quickstart.py

The DateTask fires once, 10 seconds after startup. The CronTask fires every
minute on the minute. Press Ctrl+C to stop.
"""

from __future__ import annotations

import logging
from datetime import datetime, timedelta

from crontable import AutoExecutor, CronTask, DateTask, Scheduler


def main() -> None:
    logging.basicConfig(
        format="%(asctime)s %(levelname)-8s %(message)s",
        datefmt="%H:%M:%S",
        level=logging.INFO,
    )

    scheduler = Scheduler(executor=AutoExecutor(), interval=2.0)
    scheduler.add_tasks(
        [
            DateTask(
                scheduled_at=datetime.now() + timedelta(seconds=10),
                action=lambda: print("[DATE] fired once, 10 s after startup"),
                name="one_shot",
            ),
            CronTask(
                cron_expr="* * * * *",
                action=lambda: print("[CRON] every-minute heartbeat"),
                name="heartbeat",
            ),
        ]
    )

    print("Scheduler running — Ctrl+C to stop.")
    try:
        scheduler.run()
    except KeyboardInterrupt:
        scheduler.stop()


if __name__ == "__main__":
    main()
