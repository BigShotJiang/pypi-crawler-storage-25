"""Minimal text-to-speech stub used by example 08.

Accepts arguments in two forms so it works with both executor modes:
  positional  (explicit arg_columns): say.py "Hello world" french
  keyword     (auto mode):            say.py --message "Hello world" --voice french

Replace the body of ``speak()`` with a real TTS call (e.g. pyttsx3) if needed.
"""
import sys


def speak(message: str, voice: str) -> None:
    print(f"[{voice}] {message}")


def main() -> None:
    if sys.argv[1:] and not sys.argv[1].startswith("--"):
        # Positional form: say.py <message> [voice]
        message = sys.argv[1]
        voice = sys.argv[2] if len(sys.argv) > 2 else "default"
    else:
        import argparse
        parser = argparse.ArgumentParser(description="Say a message")
        parser.add_argument("--message", default="", help="Text to say")
        parser.add_argument("--voice", default="default", help="Voice/language")
        args = parser.parse_args()
        message, voice = args.message, args.voice

    speak(message, voice)


if __name__ == "__main__":
    main()
