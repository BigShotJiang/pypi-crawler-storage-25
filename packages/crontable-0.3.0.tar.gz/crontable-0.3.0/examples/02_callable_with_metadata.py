"""Use a Python callable as the action and pass per-task metadata.

When a DateTask's ``action`` is callable, AutoExecutor delegates to
:class:`InProcessCallableExecutor`, which calls it with the task's
``metadata`` dict as the sole argument. This is the recommended pattern
for business logic that stays in-process (no subprocess overhead, full
access to Python objects).

Run with:
    python examples/02_callable_with_metadata.py
"""

from __future__ import annotations

import logging
from datetime import datetime, timedelta

from crontable import AutoExecutor, DateTask, Scheduler


def send_reminder(metadata: dict) -> None:
    """Action callback — receives the DateTask's metadata dict."""
    recipient = metadata.get("recipient", "?")
    subject = metadata.get("subject", "(no subject)")
    print(f"[REMINDER] to={recipient!r}  subject={subject!r}")


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(message)s")

    now = datetime.now()
    scheduler = Scheduler(executor=AutoExecutor(), interval=1.0)
    scheduler.add_tasks(
        [
            DateTask(
                scheduled_at=now + timedelta(seconds=3),
                action=send_reminder,
                name="reminder_alice",
                metadata={"recipient": "alice@example.com", "subject": "Stand-up"},
            ),
            DateTask(
                scheduled_at=now + timedelta(seconds=6),
                action=send_reminder,
                name="reminder_bob",
                metadata={"recipient": "bob@example.com", "subject": "Demo prep"},
            ),
        ]
    )

    print("Two reminders queued. Ctrl+C to stop early.")
    try:
        scheduler.run()
    except KeyboardInterrupt:
        scheduler.stop()


if __name__ == "__main__":
    main()
