# Crontable — Examples

Each script is standalone and runnable with `python examples/<file>.py` from
the repository root (the package must be installed first, e.g.
`pip install -e .`).

| #   | File                                                           | Demonstrates                                                    |
| --- | -------------------------------------------------------------- | --------------------------------------------------------------- |
| 01  | [`01_quickstart.py`](01_quickstart.py)                         | Minimal setup: a `DateTask` and a `CronTask` running together   |
| 02  | [`02_callable_with_metadata.py`](02_callable_with_metadata.py) | Python callable as action, with per-task metadata               |
| 03  | [`03_shell_command.py`](03_shell_command.py)                   | Shell commands via `AutoExecutor`, including path aliases       |
| 04  | [`04_load_from_csv.py`](04_load_from_csv.py)                   | Load one-shot `DateTask`s from a semicolon-delimited CSV        |
| 05  | [`05_load_from_crontab.py`](05_load_from_crontab.py)           | Load repeating `CronTask`s from a crontab-style file            |
| 06  | [`06_hot_reload.py`](06_hot_reload.py)                         | Watch a source file and hot-reload tasks when it changes        |
| 07  | [`07_custom_executor.py`](07_custom_executor.py)               | Subclass `Executor` to plug in custom dispatch logic            |
| 08  | [`08_python_script_executor.py`](08_python_script_executor.py) | Run a fixed `.py` script per task, with metadata-driven argv    |
| 09  | [`09_function_executor.py`](09_function_executor.py)           | Run a Python function out-of-process via `MultiprocessExecutor` |

Sample data files used by examples 04–06 live under [`data/`](data/).

## Best-practice patterns these examples follow

- Use `if __name__ == "__main__":` so examples can be imported without
  side effects.
- Configure logging at the top-level entry point only — libraries should
  not touch the root logger.
- Resolve sample-data paths relative to the script (`Path(__file__).parent`)
  so examples work regardless of the current working directory.
- Handle `KeyboardInterrupt` to shut the scheduler down cleanly.
- Prefer the public API exported from `crontable` — avoid reaching into
  `crontable.scheduler.*` submodules.
