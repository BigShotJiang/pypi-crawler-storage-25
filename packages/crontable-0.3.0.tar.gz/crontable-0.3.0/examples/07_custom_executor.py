"""Plug in a custom Executor by subclassing the ``Executor`` contract.

Any class implementing ``run(self, task) -> None`` can drive the scheduler,
which makes it easy to redirect task execution — e.g. push jobs onto a
queue, call a webhook, or (as here) tag every run with a correlation id
and record it for later inspection.

Run with:
    python examples/07_custom_executor.py
"""

from __future__ import annotations

import logging
import threading
import time
import uuid
from datetime import datetime, timedelta
from typing import List, Tuple

from crontable import CronTask, DateTask, Executor, Scheduler, Task

RUN_SECONDS = 5.0


class RecordingExecutor(Executor):
    """Records each run with a fresh correlation id instead of executing."""

    def __init__(self) -> None:
        self.history: List[Tuple[str, str, datetime]] = []
        self._lock = threading.Lock()

    def run(self, task: Task) -> None:
        correlation_id = uuid.uuid4().hex[:8]
        fired_at = datetime.now()
        with self._lock:
            self.history.append((correlation_id, task.name, fired_at))
        print(f"[{correlation_id}] {task.name!r} fired at {fired_at:%H:%M:%S}")


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(message)s")

    executor = RecordingExecutor()
    scheduler = Scheduler(executor=executor, interval=1.0)
    scheduler.add_tasks(
        [
            DateTask(
                scheduled_at=datetime.now() + timedelta(seconds=2),
                action="noop",  # ignored — RecordingExecutor never looks at action
                name="one_shot",
            ),
            CronTask(cron_expr="* * * * *", action="noop", name="heartbeat"),
        ]
    )

    worker = threading.Thread(target=scheduler.run, name="scheduler", daemon=True)
    worker.start()

    print(f"Running for ~{RUN_SECONDS:.0f} seconds…")
    try:
        time.sleep(RUN_SECONDS)
    finally:
        scheduler.stop()
        worker.join(timeout=5.0)

    print(f"Recorded {len(executor.history)} execution(s):")
    for cid, name, when in executor.history:
        print(f"  {cid}  {when:%H:%M:%S}  {name}")


if __name__ == "__main__":
    main()
