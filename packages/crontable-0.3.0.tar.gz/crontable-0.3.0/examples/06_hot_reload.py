"""Hot-reload the task list when the source file changes on disk.

Built-in since crontable 0.x: pass ``source=...`` and ``reload_on_change=True``
to the ``Scheduler``. Every tick, the scheduler calls ``source.has_changed()``
and, if the file was touched, atomically swaps the task list with the parsed
result. A failing parse is logged and the previous list is kept — no silent
wipe on a half-saved edit.

Try it: launch the script, then edit ``examples/data/jobs.cron`` (add a line,
save) and watch the reload log line appear on the next tick.

Run with:
    python examples/06_hot_reload.py
"""

from __future__ import annotations

import logging
from pathlib import Path

from crontable import AutoExecutor, FileSource, Scheduler

CRON_PATH = Path(__file__).parent / "data" / "jobs.cron"


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(message)s")

    source = FileSource(CRON_PATH)
    scheduler = Scheduler(
        executor=AutoExecutor(),
        interval=3.0,
        source=source,
        reload_on_change=True,
    )
    scheduler.add_tasks(source.load())

    print(f"Watching {CRON_PATH} — edit the file to trigger a reload. Ctrl+C to stop.")
    try:
        scheduler.run()
    except KeyboardInterrupt:
        scheduler.stop()


if __name__ == "__main__":
    main()
