"""Run a fixed Python script with arguments loaded from a CSV file.

``PythonScriptExecutor`` always launches the same script, passing CSV
columns as arguments.  Two modes:

- **explicit columns** — ``arg_columns`` selects which columns become
  positional arguments, in order.
- **auto mode** — every metadata column (except DATE / NAME / COMMAND) is
  forwarded as ``--column value`` keyword arguments.

CSV used here (examples/data/say_tasks.csv):

    DATE;NAME;MESSAGE;VOICE
    01/01/2099 08:00;morning_greeting;Good morning everyone;english
    ...

Run with:
    python examples/08_python_script_executor.py
"""

from __future__ import annotations

import logging
from datetime import datetime, timedelta
from pathlib import Path

from crontable import FileSource, PythonScriptExecutor, Scheduler
from crontable.scheduler.tasks.date_task import DateTask

SAY_SCRIPT = Path(__file__).parent / "data" / "say.py"
CSV_PATH = Path(__file__).parent / "data" / "say_tasks.csv"


def demo_explicit_columns() -> None:
    """Explicit arg_columns: MESSAGE and VOICE become positional args."""
    print("\n--- explicit arg_columns ---")
    executor = PythonScriptExecutor(SAY_SCRIPT, arg_columns=["MESSAGE", "VOICE"])

    now = datetime.now()
    tasks = [
        DateTask(
            scheduled_at=now + timedelta(seconds=1),
            action="",
            name="greeting",
            metadata={"MESSAGE": "Hello world", "VOICE": "english", "DATE": str(now)},
        ),
        DateTask(
            scheduled_at=now + timedelta(seconds=2),
            action="",
            name="alert",
            metadata={"MESSAGE": "Bonjour", "VOICE": "french", "DATE": str(now)},
        ),
    ]

    for task in tasks:
        print(f"  running {task.name!r} …")
        executor.run(task)


def demo_auto_mode() -> None:
    """Auto mode: all non-system columns forwarded as --key value."""
    print("\n--- auto mode (arg_columns=None) ---")
    executor = PythonScriptExecutor(SAY_SCRIPT)

    now = datetime.now()
    task = DateTask(
        scheduled_at=now,
        action="",
        name="auto_demo",
        metadata={
            "DATE": str(now),
            "NAME": "auto_demo",
            "MESSAGE": "Auto mode active",
            "VOICE": "english",
        },
    )
    print(f"  running {task.name!r} …")
    executor.run(task)


def demo_from_csv() -> None:
    """Load tasks from CSV — executor ignores task.action and uses metadata."""
    print("\n--- loaded from CSV (dates in 2099, nothing fires) ---")
    source = FileSource(CSV_PATH)
    tasks = source.load()
    executor = PythonScriptExecutor(SAY_SCRIPT, arg_columns=["MESSAGE", "VOICE"])

    print(f"  Loaded {len(tasks)} task(s) from {CSV_PATH.name}:")
    for task in tasks:
        print(f"    {task.name!r}  next={task.next_run()}  metadata={task.metadata}")

    scheduler = Scheduler(executor=executor, interval=60.0)
    scheduler.add_tasks(tasks)
    print(f"  Scheduler has {len(scheduler.list_tasks())} task(s) queued.")


def main() -> None:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)-8s %(message)s",
    )
    demo_explicit_columns()
    demo_auto_mode()
    demo_from_csv()


if __name__ == "__main__":
    main()
