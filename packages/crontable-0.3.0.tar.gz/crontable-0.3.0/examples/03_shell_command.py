"""Run shell commands as tasks, with path-alias resolution.

When a task's action is a string, :class:`AutoExecutor` delegates to
:class:`ShellCommandExecutor`, which resolves these aliases inside the
command before running it:

    @python    → sys.executable (current interpreter)
    @home      → user home directory
    @desktop   → ~/Desktop

If the first token of the command is an existing directory, the executor
uses it as the working directory and runs the rest of the command there.

Run with:
    python examples/03_shell_command.py
"""

from __future__ import annotations

import logging

from crontable import AutoExecutor, CronTask, Scheduler


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(message)s")

    # A 10-second timeout protects the scheduler loop from a hung command.
    executor = AutoExecutor(timeout=10.0)
    scheduler = Scheduler(executor=executor, interval=5.0)

    scheduler.add_tasks(
        [
            CronTask(
                cron_expr="* * * * *",
                action="@python -c \"import sys; print('python is', sys.version.split()[0])\"",
                name="python_version",
            ),
            CronTask(
                cron_expr="*/2 * * * *",
                action="echo Hello from the shell",
                name="echo_hello",
            ),
        ]
    )

    print("Scheduler running — Ctrl+C to stop.")
    try:
        scheduler.run()
    except KeyboardInterrupt:
        scheduler.stop()


if __name__ == "__main__":
    main()
