"""Load repeating CronTasks from a crontab-style text file.

File format — one task per line, five cron fields followed by a command:

    minute  hour  day-of-month  month  day-of-week  command

Blank lines and lines starting with ``#`` are ignored. Aliases like
``@daily``, ``@hourly``, ``@lundi`` are expanded before parsing.

Run with:
    python examples/05_load_from_crontab.py
"""

from __future__ import annotations

import logging
from pathlib import Path

from crontable import AutoExecutor, FileSource, Scheduler

CRON_PATH = Path(__file__).parent / "data" / "jobs.cron"


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(message)s")

    source = FileSource(CRON_PATH)
    scheduler = Scheduler(executor=AutoExecutor(), interval=5.0)
    scheduler.add_tasks(source.load())

    print(f"Loaded {len(scheduler.list_tasks())} cron task(s) from {CRON_PATH.name}.")
    print("Scheduler running — Ctrl+C to stop.")
    try:
        scheduler.run()
    except KeyboardInterrupt:
        scheduler.stop()


if __name__ == "__main__":
    main()
