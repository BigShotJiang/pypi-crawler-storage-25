"""Run a Python callable in a subprocess for each scheduled task.

``MultiprocessExecutor`` (previously ``FunctionExecutor``) is an
alternative to ``PythonScriptExecutor``: instead of pointing to a .py
file, you pass a Python function directly. The function runs in a
**separate process** (non-blocking) via ``multiprocessing.Process``, so
the scheduler thread is never stalled.

Two modes, identical to ``PythonScriptExecutor``:

- **explicit columns** — ``arg_columns`` selects which metadata columns
  become positional arguments, in order.
- **auto mode** — every non-system column is forwarded as ``**kwargs``
  with lowercased keys.

IMPORTANT: the function must be defined at **module top-level** (not
inside a class or another function) so that ``multiprocessing`` can
pickle it — required on Windows and macOS.

Run with:
    python examples/09_function_executor.py
"""

from __future__ import annotations

import logging
import time
from datetime import datetime, timedelta

from crontable import MultiprocessExecutor
from crontable.scheduler.tasks.date_task import DateTask

# ---------------------------------------------------------------------------
# Top-level functions (must be picklable for multiprocessing)
# ---------------------------------------------------------------------------


def say_message(message: str, voice: str) -> None:
    """Positional-args variant: called as say_message(message, voice)."""
    print(f"[say_message] voice={voice!r}  message={message!r}")


def say_message_kw(message: str = "", voice: str = "english") -> None:
    """Keyword-args variant: called as say_message_kw(message=..., voice=...)."""
    print(f"[say_message_kw] voice={voice!r}  message={message!r}")


def example_function(*params) -> None:
    """Variadic example matching the user's original signature."""
    print("main function called with params:")
    print(params[0])
    print("params : " + str(len(params)))
    if len(params) > 1:
        print(params[1])
    else:
        print("none")


# ---------------------------------------------------------------------------
# Demos
# ---------------------------------------------------------------------------


def demo_explicit_columns() -> None:
    print("\n--- explicit arg_columns (positional args) ---")
    executor = MultiprocessExecutor(say_message, arg_columns=["MESSAGE", "VOICE"])

    now = datetime.now()
    tasks = [
        DateTask(
            scheduled_at=now,
            action="",
            name="greeting",
            metadata={"MESSAGE": "Hello world", "VOICE": "english", "DATE": str(now)},
        ),
        DateTask(
            scheduled_at=now,
            action="",
            name="alert",
            metadata={"MESSAGE": "Bonjour", "VOICE": "french", "DATE": str(now)},
        ),
    ]
    for task in tasks:
        print(f"  running {task.name!r} …")
        executor.run(task)
        if executor._last_process:
            executor._last_process.join(timeout=5)


def demo_auto_mode() -> None:
    print("\n--- auto mode (arg_columns=None → **kwargs) ---")
    executor = MultiprocessExecutor(say_message_kw)

    now = datetime.now()
    task = DateTask(
        scheduled_at=now,
        action="",
        name="auto_demo",
        metadata={
            "DATE": str(now),
            "NAME": "auto_demo",
            "MESSAGE": "Auto mode active",
            "VOICE": "english",
        },
    )
    print(f"  running {task.name!r} …")
    executor.run(task)
    if executor._last_process:
        executor._last_process.join(timeout=5)


def demo_variadic() -> None:
    print("\n--- variadic *params function ---")
    executor = MultiprocessExecutor(example_function, arg_columns=["MESSAGE", "VOICE"])

    now = datetime.now()
    task = DateTask(
        scheduled_at=now,
        action="",
        name="variadic",
        metadata={"MESSAGE": "Fired from scheduler", "VOICE": "english", "DATE": str(now)},
    )
    print(f"  running {task.name!r} …")
    executor.run(task)
    if executor._last_process:
        executor._last_process.join(timeout=5)


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)-8s %(message)s")
    demo_explicit_columns()
    demo_auto_mode()
    demo_variadic()


if __name__ == "__main__":
    main()
