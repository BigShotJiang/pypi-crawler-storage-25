# CHANGELOG

<!-- version list -->

## v0.3.0 (2026-04-26)


## v0.2.0 (2026-04-26)

### Bug Fixes

- Add 'main' branch to push triggers in build workflow
  ([`32656e5`](https://github.com/Erim32/crontable/commit/32656e5ddf68086dfd749441e0696e784e3bb4f2))

- Update dependencies and enhance GUI features for crontable
  ([`7254587`](https://github.com/Erim32/crontable/commit/72545879661a4a3e367aa3fb880d5029396ce399))

### Features

- Enhance release workflow and add semantic release configuration
  ([`86b1cac`](https://github.com/Erim32/crontable/commit/86b1cacbab2939d258a994fedd4ca2f305c12dd8))

- Update build workflow for pre-release and add LICENSE file
  ([`0a6f015`](https://github.com/Erim32/crontable/commit/0a6f0150155f786af16b31ed45dcf1017cb6e0b6))

### Refactoring

- Streamline build workflow and remove unnecessary steps
  ([`c8bb6c4`](https://github.com/Erim32/crontable/commit/c8bb6c4f7625b3a544e32bbcfa5071ef680ceaf3))


## v0.1.1 (2026-04-26)

- Initial Release
