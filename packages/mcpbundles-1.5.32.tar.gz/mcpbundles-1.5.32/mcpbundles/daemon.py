"""Daemon process management with forking and signal handling."""

import asyncio
import os
import sys
import signal
import logging
import json
import platform
import socket
from pathlib import Path
from datetime import datetime, timezone
from mcpbundles.config import CONFIG_DIR, save_status
from mcpbundles.tunnel import TunnelClient
from mcpbundles.auth import refresh_token_if_needed
from mcpbundles.service_manager import ServiceManager

# File paths
LOG_FILE = CONFIG_DIR / 'tunnel.log'
PID_FILE = CONFIG_DIR / 'tunnel.pid'
STATUS_FILE = CONFIG_DIR / 'status.json'
_DESKTOP_MANAGED_MODE = False


def _emit_desktop_event(event: str, **fields: object) -> None:
    """Emit machine-readable events for the desktop supervisor."""
    if not _DESKTOP_MANAGED_MODE:
        return
    payload = {"event": event, **fields}
    try:
        print(json.dumps(payload), flush=True)
    except Exception:
        logging.getLogger(__name__).debug("Failed to emit desktop event %s", event, exc_info=True)


def _update_tunnel_status(tunnel_status: str, **extra: object) -> None:
    """Persist tunnel health for `mcpbundles proxy status`."""
    try:
        status = {}
        if STATUS_FILE.exists():
            status = json.loads(STATUS_FILE.read_text())
        status.update(
            {
                "running": True,
                "pid": os.getpid(),
                "tunnel_status": tunnel_status,
                "updated_at": datetime.now(timezone.utc).isoformat(),
                **extra,
            }
        )
        save_status(status)
    except Exception:
        logging.getLogger(__name__).debug("Failed to update tunnel status", exc_info=True)


async def _register_exposed_ports_once(default_token_data: dict | None = None) -> bool:
    """Register persisted exposed ports and return True if every registration succeeded."""
    from mcpbundles.commands.proxy_cmd import load_exposed_ports

    ports = load_exposed_ports()
    if not ports:
        return True

    all_ok = True
    import httpx

    async with httpx.AsyncClient(timeout=10.0) as client:
        for port_str, meta in ports.items():
            conn_name = meta.get("conn_name")
            scheme = meta.get("scheme", "http")
            stable_name = meta.get("name")
            try:
                if conn_name is None and default_token_data is not None:
                    token = str(default_token_data["access_token"])
                    url = str(default_token_data.get("server_url", "https://mcp.mcpbundles.com"))
                else:
                    from mcpbundles.auth_resolve import resolve_auth
                    from mcpbundles.config import CLISettings

                    settings = CLISettings.resolve()
                    auth = resolve_auth(settings, conn_name)
                    token = auth.token
                    url = auth.url
                is_api_key = token.startswith("mb_")
                auth_header = f"ApiKey {token}" if is_api_key else f"Bearer {token}"
                payload = {"port": int(port_str), "scheme": scheme}
                if stable_name:
                    payload["name"] = stable_name
                resp = await client.post(
                    f"{url.rstrip('/')}/api/tunnel/expose",
                    json=payload,
                    headers={"Authorization": auth_header},
                )
                if resp.status_code == 200:
                    logging.getLogger(__name__).info(
                        "Registered expose mapping for port %s scheme %s",
                        port_str,
                        scheme,
                    )
                else:
                    all_ok = False
                    logging.getLogger(__name__).warning(
                        "Expose registration failed for port %s: HTTP %s %s",
                        port_str,
                        resp.status_code,
                        resp.text[:300],
                    )
            except Exception as e:
                all_ok = False
                logging.getLogger(__name__).warning(
                    "Expose registration error for port %s: %s",
                    port_str,
                    e,
                )
    return all_ok


def _load_local_mcp_service_config() -> list[dict]:
    """Load configured local MCP connections for daemon supervision."""
    from mcpbundles.local_config import load_local_connections, serialize_connection

    return [serialize_connection(connection) for connection in load_local_connections().values()]


async def _build_local_runtime_payload(service_manager: ServiceManager) -> dict:
    from mcpbundles.local_config import get_or_create_runtime_key
    from mcpbundles.cli import __version__

    connections = _load_local_mcp_service_config()
    for connection in connections:
        discovery = await service_manager.discover_local_mcp_tools(
            connection_key=connection["connection_key"],
            timeout_seconds=10.0,
        )
        if discovery.get("success") is True:
            connection["discovery"] = {"tools": discovery.get("tools", [])}
        else:
            connection["discovery"] = {
                "tools": [],
                "error": discovery.get("error_message") or "Local MCP discovery failed",
            }
    hostname = socket.gethostname()
    return {
        "runtime_key": get_or_create_runtime_key(),
        "display_name": hostname,
        "hostname": hostname,
        "platform": platform.system().lower(),
        "proxy_version": __version__,
        "capabilities": {
            "cli_version": __version__,
            "transports": sorted(
                {connection["transport"].upper() for connection in connections}
            ),
        },
        "connections": connections,
    }


async def _register_local_runtime_once(token_data: dict, service_manager: ServiceManager) -> bool:
    """Send this machine's local MCP runtime declaration to the backend."""
    import httpx

    server_url = token_data.get("server_url", "https://mcp.mcpbundles.com")
    access_token = token_data["access_token"]
    auth_header = f"ApiKey {access_token}" if access_token.startswith("mb_") else f"Bearer {access_token}"
    payload = await _build_local_runtime_payload(service_manager)
    async with httpx.AsyncClient(timeout=10.0) as client:
        response = await client.post(
            f"{server_url}/api/local-runtime/heartbeat",
            json=payload,
            headers={"Authorization": auth_header},
        )
    if response.status_code == 200:
        logging.getLogger(__name__).info(
            "Registered local runtime with %s local MCP connections",
            len(payload["connections"]),
        )
        _emit_desktop_event(
            "local_runtime_heartbeat_ok",
            connection_count=len(payload["connections"]),
        )
        return True
    logging.getLogger(__name__).warning(
        "Local runtime registration failed: HTTP %s %s",
        response.status_code,
        response.text[:300],
    )
    _emit_desktop_event(
        "local_runtime_heartbeat_failed",
        status_code=response.status_code,
    )
    return False


def setup_logging():
    """Setup file logging for daemon."""
    CONFIG_DIR.mkdir(exist_ok=True)
    
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s [%(levelname)s] %(message)s',
        handlers=[
            logging.FileHandler(LOG_FILE),
            logging.StreamHandler(sys.stdout)  # Also log to stdout initially
        ]
    )

    # Sentry is initialised by the top-level CLI group (`cli` in
    # `mcpbundles.cli`) before any subcommand dispatch, so every CLI
    # path is covered — not just `proxy run`. The init is idempotent
    # and honours both env and config opt-outs, so we just ensure it
    # has run by the time the daemon starts logging.
    try:
        from mcpbundles.sentry_setup import init_sentry

        init_sentry()
    except Exception as error:
        logging.getLogger(__name__).warning("Sentry init failed: %s", error)


def get_pid_file():
    """Get PID file path."""
    return PID_FILE


def start_daemon(token_data):
    """Start tunnel as background daemon."""
    setup_logging()
    logger = logging.getLogger(__name__)
    
    # Fork to background
    try:
        pid = os.fork()
        if pid > 0:
            # Parent process: write PID and exit
            CONFIG_DIR.mkdir(exist_ok=True)
            PID_FILE.write_text(str(pid))
            return
    except OSError as e:
        logger.error(f"Fork failed: {e}")
        raise SystemExit(1)
    
    # Child process: detach from parent
    os.setsid()
    os.chdir('/')
    
    # Close standard file descriptors
    sys.stdout.flush()
    sys.stderr.flush()
    
    # Reopen stdin/stdout/stderr to /dev/null
    with open('/dev/null', 'r') as f:
        os.dup2(f.fileno(), sys.stdin.fileno())
    with open('/dev/null', 'a+') as f:
        os.dup2(f.fileno(), sys.stdout.fileno())
    with open('/dev/null', 'a+') as f:
        os.dup2(f.fileno(), sys.stderr.fileno())
    
    # Reconfigure logging to file only
    for handler in logging.root.handlers[:]:
        logging.root.removeHandler(handler)
    
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s [%(levelname)s] %(message)s',
        handlers=[logging.FileHandler(LOG_FILE)],
        force=True
    )
    
    logger = logging.getLogger(__name__)
    logger.info("=== Tunnel daemon started ===")
    
    # Setup signal handlers
    def signal_handler(signum, frame):
        logger.info(f"Received signal {signum}, shutting down...")
        cleanup_and_exit()
    
    signal.signal(signal.SIGTERM, signal_handler)
    signal.signal(signal.SIGINT, signal_handler)
    
    # Run tunnel
    try:
        asyncio.run(run_tunnel(token_data))
    except Exception as e:
        logger.error(f"Fatal error: {e}", exc_info=True)
        cleanup_and_exit()


def run_foreground(token_data, *, desktop_managed: bool = False):
    """Run tunnel in the current process for desktop supervisors and Windows."""
    global _DESKTOP_MANAGED_MODE
    _DESKTOP_MANAGED_MODE = desktop_managed
    setup_logging()
    logger = logging.getLogger(__name__)
    CONFIG_DIR.mkdir(exist_ok=True)
    PID_FILE.write_text(str(os.getpid()))
    logger.info(
        "=== Tunnel foreground process started%s ===",
        " (desktop managed)" if desktop_managed else "",
    )
    try:
        import sentry_sdk

        sentry_sdk.set_tag("runtime_owner", "desktop" if desktop_managed else "cli")
        sentry_sdk.set_tag("run_mode", "foreground")
        if token_data.get("auth_source"):
            sentry_sdk.set_tag("auth_source", str(token_data["auth_source"]))
        if token_data.get("server_url"):
            sentry_sdk.set_tag("server_url", str(token_data["server_url"]))
    except Exception:
        pass
    _emit_desktop_event("proxy_started", pid=os.getpid(), desktop_managed=desktop_managed)

    def signal_handler(signum, frame):
        logger.info("Received signal %s, shutting down foreground tunnel", signum)
        cleanup_and_exit()

    signal.signal(signal.SIGTERM, signal_handler)
    signal.signal(signal.SIGINT, signal_handler)

    try:
        asyncio.run(run_tunnel(token_data))
    except KeyboardInterrupt:
        cleanup_and_exit()
    except Exception as e:
        logger.error("Fatal foreground error: %s", e, exc_info=True)
        cleanup_and_exit()


async def run_tunnel(token_data):
    """Main tunnel loop with token refresh and service management."""
    logger = logging.getLogger(__name__)
    start_time = datetime.now()
    logger.info(
        "Tunnel init: env=%s auth_source=%s server=%s token_has_refresh=%s token_has_client=%s",
        os.getenv("ENVIRONMENT", "production"),
        token_data.get("auth_source", "global"),
        token_data.get("server_url", "https://mcp.mcpbundles.com"),
        bool(token_data.get("refresh_token")),
        bool(token_data.get("client_id")),
    )
    
    # Refresh OAuth tokens when refresh metadata is available. API keys and
    # access-token-only connections can still open a tunnel, but cannot renew.
    persist_refreshed_token = token_data.get("runtime_owner") != "desktop"
    if token_data.get("refresh_token") and token_data.get("expires_at"):
        token_data = await refresh_token_if_needed(
            token_data,
            persist=persist_refreshed_token,
        )
        if not token_data:
            logger.error("Token refresh failed. Run 'mcpbundles login' again.")
            _emit_desktop_event(
                "proxy_start_failed",
                code="TOKEN_REFRESH_FAILED",
                message="Desktop sign-in refresh failed.",
            )
            cleanup_and_exit()
        logger.info("Token refresh ok; expires_at=%s", token_data.get("expires_at"))
    else:
        logger.info("Token refresh skipped; auth_source=%s has no refresh metadata", token_data.get("auth_source", "unknown"))
    
    # Update status
    save_status({
        'running': True,
        'pid': os.getpid(),
        'started_at': start_time.isoformat(),
        'tunnel_status': 'connecting',
        'auth_source': token_data.get('auth_source', 'global'),
        'auth_type': token_data.get('auth_type', 'oauth' if token_data.get('refresh_token') else 'access-token'),
        'runtime_owner': token_data.get('runtime_owner', 'cli'),
        'server_url': token_data.get('server_url', 'https://mcp.mcpbundles.com'),
        'config_dir': str(CONFIG_DIR),
        'environment': os.getenv("ENVIRONMENT", "production"),
    })
    
    # Initialize service manager
    service_manager = ServiceManager()
    
    # Load service config from token data or use defaults
    service_config = token_data.get('service_config', {})
    local_mcp_config = _load_local_mcp_service_config()
    if local_mcp_config:
        service_config = {**service_config, "local_mcp": local_mcp_config}
    await service_manager.initialize(service_config)
    logger.info("Service manager initialized: services=%s", list(service_config.keys()))
    
    # Create tunnel client with the same server URL resolved by the CLI.
    client = TunnelClient(
        token_data['access_token'],
        service_manager=service_manager,
        server_url=token_data.get('server_url'),
    )
    
    # Token refresh task (every hour)
    async def refresh_loop():
        nonlocal token_data
        while True:
            await asyncio.sleep(3600)  # 1 hour
            if not token_data.get("refresh_token") or not token_data.get("expires_at"):
                logger.info("Skipping token refresh; auth_source=%s has no refresh metadata", token_data.get("auth_source", "unknown"))
                continue
            logger.info("Refreshing token...")
            new_token = await refresh_token_if_needed(
                token_data,
                persist=persist_refreshed_token,
            )
            if new_token:
                token_data = new_token
                # Reconnect with new token
                await client.stop()
                await asyncio.sleep(1)
                client.token = new_token['access_token']
                client.running = True
                asyncio.create_task(client.connect())
            else:
                logger.error("Token refresh failed, shutting down")
                _emit_desktop_event(
                    "proxy_runtime_error",
                    code="TOKEN_REFRESH_FAILED",
                    message="Desktop sign-in refresh failed.",
                )
                await service_manager.stop_all()
                cleanup_and_exit()

    async def expose_refresh_loop():
        """Re-register exposed ports immediately and then periodically.

        Wait for the WebSocket tunnel to actually report `connected`
        before the first registration. The backend's /api/tunnel/expose
        endpoint answers HTTP 409 "Proxy not connected" when the caller's
        WS slot has not been claimed yet, so firing the replay loop
        before the WS handshake completes guarantees a noisy 409 on every
        cold start (and races the very first MCP request through that
        port). The cap keeps the loop progressing even if the tunnel
        never reaches `connected` — the periodic retry path below will
        then absorb the failure mode without stalling forever.
        """
        retry_delay = 30
        gate_deadline = asyncio.get_event_loop().time() + 30.0
        while asyncio.get_event_loop().time() < gate_deadline:
            try:
                if STATUS_FILE.exists():
                    snapshot = json.loads(STATUS_FILE.read_text())
                    if snapshot.get("tunnel_status") == "connected":
                        break
            except Exception:
                pass
            await asyncio.sleep(0.5)
        while True:
            try:
                ok = await _register_exposed_ports_once(token_data)
                await asyncio.sleep(14400 if ok else retry_delay)
            except Exception as e:
                logger.warning("Expose refresh loop error: %s", e)
                await asyncio.sleep(retry_delay)

    async def local_runtime_heartbeat_loop():
        retry_delay = 30
        while True:
            try:
                ok = await _register_local_runtime_once(token_data, service_manager)
                await asyncio.sleep(60 if ok else retry_delay)
            except Exception as e:
                logger.warning("Local runtime heartbeat loop error: %s", e)
                await asyncio.sleep(retry_delay)

    # Start all tasks
    try:
        await asyncio.gather(
            client.connect(),
            refresh_loop(),
            expose_refresh_loop(),
            local_runtime_heartbeat_loop(),
        )
    except Exception as e:
        logger.error(f"Error in tunnel loop: {e}", exc_info=True)
        _emit_desktop_event(
            "proxy_runtime_error",
            code="TUNNEL_RUNTIME_ERROR",
            message=str(e),
        )
        await service_manager.stop_all()
        cleanup_and_exit()


def stop_daemon():
    """Stop running daemon."""
    if not PID_FILE.exists():
        return
    
    try:
        pid = int(PID_FILE.read_text())
        os.kill(pid, signal.SIGTERM)
        
        # Wait for process to stop (max 5 seconds)
        import time
        for _ in range(50):
            try:
                os.kill(pid, 0)
                time.sleep(0.1)
            except ProcessLookupError:
                break
        
        # Force kill if still running
        try:
            os.kill(pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
            
    except (ValueError, ProcessLookupError):
        pass
    finally:
        PID_FILE.unlink(missing_ok=True)
        STATUS_FILE.unlink(missing_ok=True)


def cleanup_and_exit():
    """Cleanup before exit."""
    PID_FILE.unlink(missing_ok=True)
    STATUS_FILE.unlink(missing_ok=True)
    sys.exit(0)


def get_status():
    """Get current daemon status."""
    if not PID_FILE.exists():
        return {'running': False}
    
    try:
        pid = int(PID_FILE.read_text())
        os.kill(pid, 0)  # Check if running
        
        # Load status file
        if STATUS_FILE.exists():
            with open(STATUS_FILE) as f:
                status = json.load(f)
                # Calculate uptime
                started_at = datetime.fromisoformat(status['started_at'])
                uptime = datetime.now() - started_at
                status['uptime'] = str(uptime).split('.')[0]  # Remove microseconds
                return status
        
        return {'running': True, 'pid': pid}
    except (ValueError, ProcessLookupError):
        PID_FILE.unlink(missing_ok=True)
        return {'running': False}

