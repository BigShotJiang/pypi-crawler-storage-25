"""Hidden diagnostics for the frozen sidecar.

Lives under `mcpbundles internal ...` so it does not appear in the user
help surface but is reachable for build-time smoke tests and runtime
self-diagnosis. The most important entry point is `internal browser-check`,
which proves at build time that the PyInstaller sidecar can actually
import Playwright and locate its driver bundle.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

import click


@click.group(name="internal", hidden=True)
def internal_group() -> None:
    """Internal diagnostics. Hidden from the user help surface."""


@internal_group.command(name="browser-check")
@click.option(
    "--json",
    "as_json",
    is_flag=True,
    help="Emit machine-readable JSON instead of human text.",
)
def browser_check(as_json: bool) -> None:
    """Verify Playwright is importable and its driver bundle is present.

    The desktop app bundles this binary via PyInstaller. Anything pip
    installs into the user's system Python after the fact is invisible to
    this interpreter, so we need a way to assert at build time (and
    diagnose at runtime) that the [browser] extra is actually inside the
    frozen archive.
    """
    result: dict[str, object] = {
        "frozen": bool(getattr(sys, "frozen", False)),
        "executable": sys.executable,
    }

    try:
        import playwright  # type: ignore

        try:
            from importlib.metadata import PackageNotFoundError, version as _pkg_version

            try:
                result["playwright_version"] = _pkg_version("playwright")
            except PackageNotFoundError:
                result["playwright_version"] = getattr(playwright, "__version__", "unknown")
        except ImportError:
            result["playwright_version"] = getattr(playwright, "__version__", "unknown")
        driver_dir = Path(playwright.__file__).resolve().parent / "driver"
        result["driver_dir"] = str(driver_dir)
        result["driver_present"] = driver_dir.exists()
    except ImportError as exc:
        result["status"] = "missing"
        result["error"] = str(exc)
        if as_json:
            click.echo(json.dumps(result))
        else:
            click.echo("browser-check: FAIL — playwright is not importable", err=True)
            click.echo(f"  reason: {exc}", err=True)
        sys.exit(1)

    if not result.get("driver_present"):
        result["status"] = "driver-missing"
        if as_json:
            click.echo(json.dumps(result))
        else:
            click.echo(
                "browser-check: FAIL — playwright imported but its driver "
                "bundle is missing. PyInstaller likely was not invoked with "
                "--collect-all playwright.",
                err=True,
            )
            click.echo(f"  expected at: {result['driver_dir']}", err=True)
        sys.exit(1)

    result["status"] = "ok"
    if as_json:
        click.echo(json.dumps(result))
    else:
        click.echo(
            f"browser-check: OK — playwright {result['playwright_version']} "
            f"with driver at {result['driver_dir']}"
        )
