TAG_MODEL_TYPE, TAG_PROMPT_TYPE = "model", "prompt"
SNAPSHOT_INTERVAL = 5


class Fields:
    _PROMPTS_TABLE = "prompts"
    _PROMPT_VERSIONS_TABLE = "prompt_versions"
    _PROMPT_CHANGES_TABLE = "prompt_changes"
    _TAG_TABLE = "tags"

    _PROMPT_ID = "id"
    PROMPT_NAME = "name"
    PROMPT_CREATED_AT = "created_at"

    PROMPT_VERSIONS_PROMPT_ID = "prompt_id"
    PROMPT_VERSIONS_NAME = "name"

    PROMPT_VERSIONS_MESSAGE = "message"
    PROMPT_VERSIONS_CREATED_AT = "created_at"

    TAG_NAME = "name"
    TAG_TYPE = "type"
    TAG_PROVIDER = "provider"


_INIT_SCHEMA_SQL = f"""
CREATE TABLE IF NOT EXISTS {Fields._PROMPTS_TABLE} (
    {Fields._PROMPT_ID} INTEGER PRIMARY KEY AUTOINCREMENT,
    {Fields.PROMPT_NAME} TEXT NOT NULL UNIQUE,
    snapshot_interval INTEGER DEFAULT 5,
    {Fields.PROMPT_CREATED_AT} TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS {Fields._PROMPT_VERSIONS_TABLE} (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    {Fields.PROMPT_VERSIONS_PROMPT_ID} INTEGER NOT NULL,

    {Fields.PROMPT_VERSIONS_NAME} TEXT NOT NULL,
    seq INTEGER NOT NULL,

    parent_version_id INTEGER NULL,
    snapshot_content TEXT NULL,

    {Fields.PROMPT_VERSIONS_MESSAGE} TEXT NULL,

    {Fields.PROMPT_VERSIONS_CREATED_AT} TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY ({Fields.PROMPT_VERSIONS_PROMPT_ID}) REFERENCES {Fields._PROMPTS_TABLE}(id) ON DELETE CASCADE,
    FOREIGN KEY (parent_version_id) REFERENCES {Fields._PROMPT_VERSIONS_TABLE}(id),

    UNIQUE({Fields.PROMPT_VERSIONS_PROMPT_ID}, seq)
);

CREATE TABLE IF NOT EXISTS prompt_changes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    version_id INTEGER NOT NULL,

    op_index INTEGER NOT NULL,
    op_type TEXT NOT NULL,

    pos INTEGER NULL,
    start INTEGER NULL,
    end INTEGER NULL,
    text TEXT NULL,

    CHECK (
        (op_type='insert'  AND pos IS NOT NULL AND text IS NOT NULL) OR
        (op_type='delete'  AND start IS NOT NULL AND end IS NOT NULL) OR
        (op_type='replace' AND start IS NOT NULL AND end IS NOT NULL AND text IS NOT NULL)
    ),

    FOREIGN KEY (version_id) REFERENCES {Fields._PROMPT_VERSIONS_TABLE}(id) ON DELETE CASCADE,
    UNIQUE(version_id, op_index)
);

CREATE TABLE IF NOT EXISTS {Fields._TAG_TABLE} (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    {Fields.TAG_NAME} TEXT NOT NULL,
    {Fields.TAG_TYPE} TEXT NOT NULL CHECK({Fields.TAG_TYPE} IN ('{TAG_MODEL_TYPE}', '{TAG_PROMPT_TYPE}')),
    {Fields.TAG_PROVIDER} TEXT NULL,
    UNIQUE({Fields.TAG_NAME}, {Fields.TAG_TYPE})
);

CREATE TABLE IF NOT EXISTS prompt_tags (
    prompt_id INTEGER NOT NULL,
    tag_id INTEGER NOT NULL,

    PRIMARY KEY(prompt_id, tag_id),

    FOREIGN KEY(prompt_id) REFERENCES {Fields._PROMPTS_TABLE}(id) ON DELETE CASCADE,
    FOREIGN KEY(tag_id) REFERENCES {Fields._TAG_TABLE}(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_prompt_tags_prompt ON prompt_tags(prompt_id);
CREATE INDEX IF NOT EXISTS idx_prompt_tags_tag ON prompt_tags(tag_id);

CREATE INDEX IF NOT EXISTS idx_pv_prompt_seq
ON {Fields._PROMPT_VERSIONS_TABLE}({Fields.PROMPT_VERSIONS_PROMPT_ID}, seq);

CREATE INDEX IF NOT EXISTS idx_pv_prompt_name
ON {Fields._PROMPT_VERSIONS_TABLE}({Fields.PROMPT_VERSIONS_PROMPT_ID}, {Fields.PROMPT_VERSIONS_NAME});

CREATE INDEX IF NOT EXISTS idx_pv_snapshot
ON {Fields._PROMPT_VERSIONS_TABLE}({Fields.PROMPT_VERSIONS_PROMPT_ID}, seq DESC)
WHERE snapshot_content IS NOT NULL;

CREATE TABLE IF NOT EXISTS model_tariffs (
    tag_name TEXT NOT NULL PRIMARY KEY,
    input_price_per_1m REAL DEFAULT 0.0,
    output_price_per_1m REAL DEFAULT 0.0,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
"""
