"""GitHub Copilot CLI v1.x normalizer.

Maps Copilot CLI's tool-call vocabulary onto AgentStream's unified schema.

Copilot tool name reference (observed in ``events.jsonl``):

  view              read a file (args: ``path``)
  bash              run a shell command (args: ``command``)
  local_shell       same as bash, used for user-initiated bang commands
  rg                ripgrep search (args: ``pattern``, ``paths``)
  glob              glob search (args: ``pattern``, ``paths``)
  task              spawn a subagent (args: ``description``, ``agent_type``,
                    ``name``, ``mode``, ``prompt``)
  skill             load a skill into context (args: ``skill``)
  report_intent     framing/telemetry; ignored
  fetch_copilot_cli_documentation
                    docs lookup; ignored
  web_fetch         HTTP fetch (args: ``url``, ``max_length``)

Tool names that may appear once Copilot starts editing files (not yet seen
in the wild but mirrored from Codex/Claude conventions to keep the
normalizer forward-compatible): ``create``, ``write``, ``edit``,
``str_replace``, ``apply_patch``.
"""

from __future__ import annotations

import json
import re
from datetime import UTC, datetime
from typing import Any, Literal

from agentstream.adapters.copilot import SWE_AGENT_MODEL

from ..base import BaseNormalizer, compute_diff_from_content
from ..schemas import (
    CompactionEvent,
    DiffHunk,
    ErrorEvent,
    SessionMetadata,
    TokenUsage,
    UnifiedDiff,
    UnifiedFileOperation,
    UnifiedGitCommit,
    UnifiedPullRequest,
    UnifiedSkill,
    UnifiedTodo,
)
from .codex_v1 import CodexV1Normalizer
from .git_patterns import (
    is_git_commit_command,
    is_pr_create_command,
    parse_branch_from_command,
    parse_branch_from_output,
    parse_commit_output,
    parse_pr_number_from_url,
    parse_pr_title_from_command,
    parse_pr_url_from_output,
)

# Copilot tool name conventions. Names from the official CLI plus
# forward-compatible aliases that we add when Copilot grows write tooling.
_FILE_READ_TOOLS = frozenset({"view"})
_FILE_WRITE_TOOLS = frozenset({"create", "write", "create_file", "write_file"})
_FILE_EDIT_TOOLS = frozenset(
    {"edit", "edit_file", "str_replace", "string_replace", "apply_patch", "patch"}
)
_FILE_SEARCH_TOOLS = frozenset({"rg", "grep", "search"})
_FILE_LIST_TOOLS = frozenset({"glob", "list_files", "ls"})
_SHELL_TOOLS = frozenset({"bash", "local_shell", "shell", "exec_command"})

# Copilot reports todos via either a forward-compatible ``write_todos`` /
# ``todo_write`` tool, or via direct SQL ``INSERT`` / ``UPDATE`` against the
# per-session ``todos`` table. We currently only normalise tool-based todos.
_TODO_TOOLS = frozenset({"write_todos", "todo_write", "update_plan"})

# Markdown checkbox line, anchored at the start with optional leading whitespace:
#   "- [ ] Item"   → pending
#   "- [x] Item"   → completed (case-insensitive)
_CHECKBOX_RE = re.compile(r"^\s*[-*]\s*\[([ xX])\]\s*(.*\S)\s*$")


def _parse_checkbox_list(text: str) -> list[tuple[str, str]]:
    """Parse a markdown checkbox list into ``(content, status)`` pairs.

    Cloud SWE-agent's ``report_progress`` tool ships the agent's running
    plan as a markdown checklist in the ``prDescription`` arg. Each
    ``- [ ]``/``- [x]`` line is a todo item; non-matching lines (prose,
    blank lines, sub-bullets) are ignored. Returns an empty list when no
    checklist is present.
    """
    items: list[tuple[str, str]] = []
    for line in text.splitlines():
        m = _CHECKBOX_RE.match(line)
        if not m:
            continue
        check, content = m.groups()
        status = "completed" if check.lower() == "x" else "pending"
        items.append((content, status))
    return items


def _normalize_todo_signature(items: list[tuple[str, str]]) -> tuple[tuple[str, str], ...]:
    """Build a dedup signature that ignores cosmetic content churn.

    Internal whitespace differences (extra spaces, tabs) shouldn't trigger
    a TODO_UPDATE re-emit. Trailing punctuation noise is harder to draw a
    clean line on without false negatives, so we only collapse whitespace.
    """
    return tuple((" ".join(content.split()), status) for content, status in items)


# Pattern emitted in tool result content when a shell command fails. Copilot
# wraps non-zero shell exits as ``<exited with exit code N>`` rather than
# flipping ``success`` to false, so detect it here.
_EXIT_CODE_RE = re.compile(r"<exited with exit code (\d+)>")

# Codex's apply_patch parsers are pure functions of the patch body, so we
# delegate to a singleton instead of duplicating the format logic. If we
# ever diverge (e.g. Copilot adds a marker Codex doesn't support), split
# the shared bits into agentstream/normalization/adapters/_apply_patch.py.
_CODEX_PARSER = CodexV1Normalizer()


def _result_text(result: Any) -> str:
    """Pull a plain-text payload out of Copilot's ``result`` dict.

    Copilot wraps results as ``{"content": "...", "detailedContent": "..."}``
    locally, but the server-side ``_agui_to_normalizer_events`` step re-wraps
    raw text results into ``{"output": "..."}``. Handle both shapes plus
    plain strings.
    """
    if isinstance(result, dict):
        for key in ("detailedContent", "content", "output", "Output"):
            value = result.get(key)
            if isinstance(value, str) and value:
                return value
        return ""
    if isinstance(result, str):
        return result
    return ""


class CopilotV1Normalizer(BaseNormalizer):
    """Normalizer for Copilot CLI v1.x ``events.jsonl`` format."""

    # ------------------------------------------------------------------
    # Todos
    # ------------------------------------------------------------------

    def extract_todo(self, event: dict, todo_state: dict | None = None) -> list[UnifiedTodo] | None:
        tool_name = event.get("tool_name")

        # Cloud SWE-agent's ``report_progress`` is the agent's running plan,
        # not a chat message. The dashboard was rendering the same checklist
        # as a chat turn after every tool call; treating it as a TODO update
        # (deduped against the previous checklist) collapses those repeats
        # into a single timeline item that only changes when the agent
        # actually flips a checkbox.
        if tool_name == "report_progress":
            args = event.get("args") or {}
            pr_desc = args.get("prDescription")
            if not isinstance(pr_desc, str) or not pr_desc:
                return None
            items = _parse_checkbox_list(pr_desc)
            if not items:
                return None
            signature = _normalize_todo_signature(items)
            if todo_state is not None:
                if todo_state.get("copilot_progress_signature") == signature:
                    return None
                todo_state["copilot_progress_signature"] = signature
            timestamp = datetime.fromtimestamp(event.get("timestamp_ms", 0) / 1000, tz=UTC)
            return [
                UnifiedTodo(
                    content=content,
                    status=status,
                    id=str(i + 1),
                    timestamp=timestamp,
                    source_tool="report_progress",
                    agent_type="copilot",
                )
                for i, (content, status) in enumerate(items)
            ]

        if tool_name not in _TODO_TOOLS:
            return None

        args = event.get("args") or {}
        # Forward-compatible: cover the most common arg shapes.
        items = (
            args.get("todos") or args.get("items") or args.get("plan") or args.get("tasks") or []
        )
        if not isinstance(items, list) or not items:
            return None

        timestamp = datetime.fromtimestamp(event.get("timestamp_ms", 0) / 1000, tz=UTC)
        out: list[UnifiedTodo] = []
        for item in items:
            if not isinstance(item, dict):
                continue
            content = item.get("content") or item.get("step") or item.get("text") or ""
            status = item.get("status") or item.get("state") or "pending"
            if not content:
                continue
            out.append(
                UnifiedTodo(
                    content=str(content),
                    status=status,
                    id=item.get("id"),
                    timestamp=timestamp,
                    source_tool=str(tool_name),
                    agent_type="copilot",
                    description=item.get("description"),
                    active_form=item.get("activeForm") or item.get("active_form"),
                )
            )
        return out or None

    # ------------------------------------------------------------------
    # File operations
    # ------------------------------------------------------------------

    def extract_file_operations(self, event: dict) -> list[UnifiedFileOperation]:
        """Override the default to expand multi-file ``apply_patch`` calls.

        ``apply_patch`` can touch several files in a single call, so we need
        a list-shaped extractor. All other Copilot tools yield zero or one
        operation, which the base class wraps for us.
        """
        if event.get("tool_name") == "apply_patch":
            return self._extract_file_ops_from_apply_patch(event)
        return super().extract_file_operations(event)

    def _extract_file_ops_from_apply_patch(self, event: dict) -> list[UnifiedFileOperation]:
        """Extract per-file operations from a Copilot ``apply_patch`` call.

        Mirrors Codex's behaviour: each ``*** Add File:`` becomes a write,
        each ``*** Update File:`` an edit, each ``*** Delete File:`` an
        edit (we don't have a "delete" op in the unified schema yet).
        """
        patch_input = self._patch_input(event)
        if not patch_input or "*** Begin Patch" not in patch_input:
            return []

        timestamp = datetime.fromtimestamp(event.get("timestamp_ms", 0) / 1000, tz=UTC)
        source_event_id = str(event.get("event_id") or "")

        per_file_hunks = _CODEX_PARSER._parse_codex_patch_per_file(patch_input)
        operations: list[UnifiedFileOperation] = []

        for path, op_type in _parse_apply_patch_files(patch_input):
            hunks = per_file_hunks.get(path, [])
            diff = _CODEX_PARSER._build_diff_from_hunks(hunks) if hunks else None
            operations.append(
                UnifiedFileOperation(
                    file_path=path,
                    operation=op_type,
                    timestamp=timestamp,
                    diff=diff,
                    confidence="high",
                    agent_type="copilot",
                    source_tool="apply_patch",
                    source_event_id=source_event_id,
                    content=None,
                )
            )
        return operations

    @staticmethod
    def _patch_input(event: dict) -> str:
        """Pull the raw patch body out of an apply_patch event.

        Copilot serialises the body two ways depending on the source:
          * Locally we wrap string args as ``{"input": <body>}`` (see
            :func:`agentstream.adapters.copilot._encode_tool_args`).
          * Some test paths pass the body as a top-level ``input`` key.
        Handle both, plus the raw-string fallback.
        """
        args = event.get("args")
        if isinstance(args, str):
            return args
        if isinstance(args, dict):
            value = args.get("input")
            if isinstance(value, str) and value:
                return value
        top = event.get("input")
        return top if isinstance(top, str) else ""

    def extract_file_operation(self, event: dict) -> UnifiedFileOperation | None:
        tool_name = event.get("tool_name")
        if not isinstance(tool_name, str):
            return None

        if tool_name == "apply_patch":
            ops = self._extract_file_ops_from_apply_patch(event)
            return ops[0] if ops else None

        args = event.get("args") or {}
        timestamp = datetime.fromtimestamp(event.get("timestamp_ms", 0) / 1000, tz=UTC)
        source_event_id = str(event.get("event_id") or "")

        op: Literal["read", "write", "edit", "search", "list"] | None = None
        if tool_name in _FILE_READ_TOOLS:
            op = "read"
        elif tool_name in _FILE_WRITE_TOOLS:
            op = "write"
        elif tool_name in _FILE_EDIT_TOOLS:
            op = "edit"
        elif tool_name in _FILE_SEARCH_TOOLS:
            op = "search"
        elif tool_name in _FILE_LIST_TOOLS:
            op = "list"
        elif tool_name in _SHELL_TOOLS:
            return self._extract_file_op_from_shell(event, timestamp, source_event_id)
        else:
            return None

        file_path = (
            args.get("path") or args.get("file_path") or args.get("file") or args.get("filename")
        )
        # rg/glob report the search root via ``paths``, which is a *list*. Pick
        # the first string entry; otherwise ``str(file_path)`` below would
        # serialize the list into a Python repr like
        # ``"['/Users/x/.copilot/session-state']"`` and surface that as a path.
        if op in ("search", "list") and not file_path:
            paths = args.get("paths")
            if isinstance(paths, list):
                file_path = next((p for p in paths if isinstance(p, str) and p), None)
            elif isinstance(paths, str):
                file_path = paths
            if not file_path:
                file_path = args.get("directory") or ""
        if op in ("read", "write", "edit") and not file_path:
            return None
        # Defensive: if some other arg shape sneaks a non-string in, drop it
        # rather than serialize it.
        if file_path and not isinstance(file_path, str):
            return None

        content: str | None = None
        if op == "read":
            content = _result_text(event.get("result")) or None
        elif op == "write":
            new_content = args.get("content") or args.get("contents") or args.get("text")
            if isinstance(new_content, str):
                content = new_content
        elif op == "edit":
            after = _result_text(event.get("result"))
            if after:
                content = after

        return UnifiedFileOperation(
            file_path=str(file_path) if file_path else "",
            operation=op,
            timestamp=timestamp,
            diff=None,  # populated by extract_diff
            confidence="high" if op in ("read", "write", "edit") else "medium",
            agent_type="copilot",
            source_tool=tool_name,
            source_event_id=source_event_id,
            content=content,
        )

    def _extract_file_op_from_shell(
        self, event: dict, timestamp: datetime, source_event_id: str
    ) -> UnifiedFileOperation | None:
        """Best-effort detection of file ops from ``bash``/``local_shell``."""
        args = event.get("args") or {}
        cmd = args.get("command") or args.get("cmd") or ""
        if not isinstance(cmd, str) or not cmd.strip():
            return None

        op, file_path = _parse_file_op_from_shell_cmd(cmd)
        if not op or not file_path:
            return None

        return UnifiedFileOperation(
            file_path=file_path,
            operation=op,
            timestamp=timestamp,
            diff=None,
            confidence="medium",
            agent_type="copilot",
            source_tool=str(event.get("tool_name") or "bash"),
            source_event_id=source_event_id,
            content=None,
        )

    # ------------------------------------------------------------------
    # Skills
    # ------------------------------------------------------------------

    def extract_skill(self, event: dict) -> UnifiedSkill | None:
        if event.get("tool_name") != "skill":
            return None

        args = event.get("args") or {}
        skill_name = args.get("skill") or args.get("name")
        if not skill_name:
            return None

        timestamp = datetime.fromtimestamp(event.get("timestamp_ms", 0) / 1000, tz=UTC)
        return UnifiedSkill(
            name=str(skill_name),
            method="tool",
            # Match Claude's "tool" taxonomy for tool-loaded skills so the
            # dashboard groups Copilot skills with the existing tool-based
            # emitters; ``agent_type`` already carries the Copilot identity.
            skill_type="tool",
            timestamp=timestamp,
            agent_type="copilot",
            source_event_id=str(event.get("event_id") or ""),
            file_path=None,
            args=json.dumps(args) if args else None,
        )

    # ------------------------------------------------------------------
    # Diffs
    # ------------------------------------------------------------------

    def extract_diff(self, event: dict, session: Any) -> UnifiedDiff | None:
        """Compute a unified diff from Copilot edit/write tool calls.

        Copilot ships ``apply_patch`` (string-bodied custom tool, same
        format as Codex) for all file mutations today. The other tool
        names below are forward-compat hooks for if/when Copilot adds
        a JSON-arg edit tool:

        * ``apply_patch`` — parse the patch body for per-file hunks.
        * ``write``/``create`` with a ``content`` arg — full-addition diff.
        * ``edit``/``str_replace`` with ``old_str`` + ``new_str`` —
          computed diff via :func:`compute_diff_from_content`.
        """
        tool_name = event.get("tool_name")
        if not isinstance(tool_name, str):
            return None

        if tool_name == "apply_patch":
            patch_input = self._patch_input(event)
            if not patch_input or "*** Begin Patch" not in patch_input:
                return None
            hunks = _CODEX_PARSER._parse_codex_patch(patch_input)
            return _CODEX_PARSER._build_diff_from_hunks(hunks) if hunks else None

        args = event.get("args") or {}

        if tool_name in _FILE_WRITE_TOOLS:
            new_content = args.get("content") or args.get("contents") or args.get("text")
            if isinstance(new_content, str) and new_content:
                return self._diff_for_new_file(new_content)
            return None

        if tool_name in _FILE_EDIT_TOOLS:
            old_str = args.get("old_str") or args.get("oldString") or args.get("oldText")
            new_str = args.get("new_str") or args.get("newString") or args.get("newText")
            if isinstance(old_str, str) and isinstance(new_str, str):
                return compute_diff_from_content(old_str, new_str)
            return None

        return None

    @staticmethod
    def _diff_for_new_file(content: str) -> UnifiedDiff:
        lines = content.split("\n")
        if lines and not lines[-1]:
            lines = lines[:-1]
        hunk = DiffHunk(
            old_start=0,
            old_count=0,
            new_start=1,
            new_count=len(lines),
            lines=[f"+{line}" for line in lines],
        )
        return UnifiedDiff(
            hunks=[hunk],
            format_source="computed",
            confidence="high",
            lines_added=list(range(1, len(lines) + 1)),
            lines_modified=[],
        )

    # ------------------------------------------------------------------
    # Session metadata
    # ------------------------------------------------------------------

    def extract_session_metadata(
        self,
        source_entries: list[dict],
        daemon_metadata: dict | None = None,
    ) -> SessionMetadata | None:
        if not source_entries:
            return None

        timestamp = datetime.fromtimestamp(source_entries[0]["entry_timestamp_ms"] / 1000, tz=UTC)

        # Find session.start (almost always entry 0) and the first
        # session.model_change so we know which model the session used.
        session_start: dict[str, Any] = {}
        first_model: str | None = None

        for entry in source_entries:
            try:
                parsed = json.loads(entry["entry_content"])
            except (json.JSONDecodeError, KeyError, TypeError):
                continue

            etype = parsed.get("type")
            if etype == "session.start" and not session_start:
                session_start = parsed.get("data") or {}
            elif etype == "session.model_change" and first_model is None:
                first_model = (parsed.get("data") or {}).get("newModel")

            if session_start and first_model:
                break

        context = session_start.get("context") or {}
        cwd = context.get("cwd") or (daemon_metadata.get("cwd") if daemon_metadata else None)
        agent_version = session_start.get("copilotVersion") or (
            daemon_metadata.get("agent_version") if daemon_metadata else None
        )
        git_branch = context.get("branch") or (
            daemon_metadata.get("git_branch") if daemon_metadata else None
        )
        git_commit = context.get("headCommit") or (
            daemon_metadata.get("git_commit") if daemon_metadata else None
        )
        git_repo = context.get("repository") or (
            daemon_metadata.get("git_repo") if daemon_metadata else None
        )
        primary_model = (
            first_model or (daemon_metadata.get("model") if daemon_metadata else None) or ""
        )
        # Cloud SWE-agent (output.log) never emits session.start or
        # session.model_change — the model lives only in API response
        # bodies the eBPF firewall sees as opaque bytes. The daemon
        # injects ``model = swe-agent`` for these sessions so the backend's
        # primary_model gate (processing.py SESSION_METADATA creation)
        # doesn't skip the event. This server-side fallback is defense in
        # depth: it covers older daemons or hand-uploaded source_entries
        # that didn't ship the placeholder, and gates on missing
        # session.start so it never overrides a real CLI session that
        # just happens to be missing model metadata briefly.
        if not primary_model and not session_start:
            primary_model = SWE_AGENT_MODEL

        return SessionMetadata(
            cwd=cwd,
            agent_type="copilot",
            agent_version=agent_version,
            git_branch=git_branch,
            git_commit=git_commit,
            git_repo=git_repo,
            primary_model=primary_model,
            timestamp=timestamp,
        )

    # ------------------------------------------------------------------
    # Token usage
    # ------------------------------------------------------------------

    def extract_token_usage(self, source_entry: dict) -> list[TokenUsage]:
        """Emit per-assistant-message token usage.

        Copilot CLI 1.0.40 logs ``outputTokens`` on each
        ``assistant.message`` but no ``inputTokens``, no cache breakdown,
        and no cumulative usage object — the companion
        ``session-store.db`` carries no token columns either. The daemon
        works around this by scraping the per-process log file (see
        ``agentstream/enrichment/copilot_logs.py``) and attaching
        ``_input_tokens`` to assistant messages during ``enrich_entries``
        — that's the same number the in-CLI ``/usage`` view reports for
        the input column. When the log isn't available (rotated, copied
        from another machine) ``_input_tokens`` is missing and we emit
        output-only.

        Cache and reasoning splits remain 0: those numbers don't appear
        anywhere local — they accumulate in-process from server response
        headers we don't see. GitHub's REST billing endpoints
        (``/users/{user}/settings/billing/usage`` and
        ``/orgs/{org}/copilot/metrics``) expose only daily aggregates
        with no session attribution. Worth revisiting if GitHub ships an
        admin usage-events API like Cursor's
        ``/teams/filtered-usage-events``.
        """
        if source_entry.get("type") != "assistant.message":
            return []

        data = source_entry.get("data")
        if not isinstance(data, dict):
            return []

        output_tokens = data.get("outputTokens")
        if not isinstance(output_tokens, int) or output_tokens <= 0:
            return []

        input_tokens_raw = source_entry.get("_input_tokens")
        input_tokens = (
            input_tokens_raw if isinstance(input_tokens_raw, int) and input_tokens_raw >= 0 else 0
        )

        timestamp = datetime.fromtimestamp(source_entry.get("_timestamp_ms", 0) / 1000, tz=UTC)
        return [
            TokenUsage(
                input_tokens=input_tokens,
                output_tokens=output_tokens,
                cache_read_tokens=0,
                cache_creation_tokens=0,
                reasoning_tokens=0,
                model=None,
                timestamp=timestamp,
                is_cumulative=False,
            )
        ]

    # ------------------------------------------------------------------
    # Errors
    # ------------------------------------------------------------------

    def extract_error(self, source_entry: dict) -> ErrorEvent | None:
        if source_entry.get("type") != "tool.execution_complete":
            return None

        data = source_entry.get("data") or {}
        success = data.get("success")
        result = data.get("result") or {}
        text = _result_text(result)

        # Copilot leaves ``success: true`` for shell commands that exit
        # non-zero; the only signal is the trailing ``<exited with exit code
        # N>`` marker. Treat success=False OR a non-zero exit as an error.
        exit_match = _EXIT_CODE_RE.search(text)
        non_zero_exit = bool(exit_match and int(exit_match.group(1)) != 0)

        if success is not False and not non_zero_exit:
            return None

        error_type: Literal[
            "tool_call_error",
            "interruption",
            "cancellation",
            "timeout",
            "rate_limit",
            "context_length",
            "authentication",
            "api_error",
            "other",
        ] = "tool_call_error"

        lower = text.lower()
        if "timed out" in lower or "timeout" in lower:
            error_type = "timeout"
        elif "rate limit" in lower:
            error_type = "rate_limit"
        elif "interrupted" in lower or "cancelled" in lower or "canceled" in lower:
            error_type = "interruption"

        timestamp = datetime.fromtimestamp(source_entry.get("_timestamp_ms", 0) / 1000, tz=UTC)
        return ErrorEvent(
            error_type=error_type,
            message=text or "Tool execution failed",
            tool_name=None,  # Copilot stores name in the matching execution_start; not in result
            tool_call_id=str(data.get("toolCallId") or "") or None,
            details=str(exit_match.group(0)) if exit_match else None,
            timestamp=timestamp,
        )

    # ------------------------------------------------------------------
    # Compaction
    # ------------------------------------------------------------------

    def extract_compaction(self, source_entries: list[dict]) -> list[CompactionEvent]:
        # Copilot doesn't currently emit a compaction event in events.jsonl.
        return []

    # ------------------------------------------------------------------
    # Git / PR detection
    # ------------------------------------------------------------------

    def extract_git_commit(self, event: dict, git_state: dict[str, Any]) -> UnifiedGitCommit | None:
        if event.get("tool_name") not in _SHELL_TOOLS:
            return None

        args = event.get("args") or {}
        cmd = args.get("command") or args.get("cmd") or ""
        if isinstance(cmd, list):
            cmd = " ".join(str(c) for c in cmd)
        if not cmd:
            return None

        output = _result_text(event.get("result"))

        branch = parse_branch_from_command(cmd)
        if not branch and output:
            branch = parse_branch_from_output(output)
        if branch:
            git_state["branch"] = branch

        if not is_git_commit_command(cmd):
            return None

        timestamp = datetime.fromtimestamp(event.get("timestamp_ms", 0) / 1000, tz=UTC)

        commit_branch = None
        commit_hash = None
        commit_message = None
        if output:
            parsed = parse_commit_output(output)
            if parsed:
                commit_branch, commit_hash, commit_message = parsed

        return UnifiedGitCommit(
            branch=commit_branch or git_state.get("branch") or "unknown",
            timestamp=timestamp,
            agent_type="copilot",
            source_tool=str(event.get("tool_name") or "bash"),
            source_event_id=str(event.get("event_id") or ""),
            commit_hash=commit_hash,
            message=commit_message,
        )

    def extract_pr(self, event: dict, git_state: dict[str, Any]) -> UnifiedPullRequest | None:
        if event.get("tool_name") not in _SHELL_TOOLS:
            return None

        args = event.get("args") or {}
        cmd = args.get("command") or args.get("cmd") or ""
        if isinstance(cmd, list):
            cmd = " ".join(str(c) for c in cmd)
        if not cmd or not is_pr_create_command(cmd):
            return None

        output = _result_text(event.get("result"))
        pr_url = parse_pr_url_from_output(output)
        if not pr_url:
            return None

        timestamp = datetime.fromtimestamp(event.get("timestamp_ms", 0) / 1000, tz=UTC)
        return UnifiedPullRequest(
            url=pr_url,
            branch=git_state.get("branch") or "unknown",
            timestamp=timestamp,
            agent_type="copilot",
            source_tool=str(event.get("tool_name") or "bash"),
            source_event_id=str(event.get("event_id") or ""),
            number=parse_pr_number_from_url(pr_url),
            title=parse_pr_title_from_command(cmd),
        )


def _parse_apply_patch_files(
    patch_input: str,
) -> list[tuple[str, Literal["write", "edit"]]]:
    """Walk an apply_patch body for ``*** Add/Update/Delete File:`` markers.

    Codex's helper (:meth:`CodexV1Normalizer._extract_file_ops_from_patch`)
    only emits ``Add`` and ``Update``; we add ``Delete`` so Copilot's
    cleanup steps still surface as a file operation. The unified schema
    has no ``delete`` op today, so we tag deletes as ``edit`` (the
    closest existing semantic — content went from "had stuff" to "gone").
    """
    out: list[tuple[str, Literal["write", "edit"]]] = []
    for line in patch_input.splitlines():
        if line.startswith("*** Update File:"):
            path = line[len("*** Update File:") :].strip()
            if path:
                out.append((path, "edit"))
        elif line.startswith("*** Add File:"):
            path = line[len("*** Add File:") :].strip()
            if path:
                out.append((path, "write"))
        elif line.startswith("*** Delete File:"):
            path = line[len("*** Delete File:") :].strip()
            if path:
                out.append((path, "edit"))
    return out


def _parse_file_op_from_shell_cmd(
    cmd: str,
) -> tuple[Literal["read", "write", "edit"] | None, str | None]:
    """Detect file ops in a shell command, with Copilot-specific extensions.

    Codex's helper covers ``cat``/``head``/``tail``/``less``/``more`` plus
    redirection writes; we add ``bat`` first (Copilot users alias it for
    syntax-highlighted reads) and fall through to Codex for the rest.
    """
    cmd_stripped = cmd.strip()
    if cmd_stripped.startswith("bat "):
        m = re.search(r"bat\s+([^\s;|&]+)", cmd_stripped)
        if m:
            file_path = m.group(1)
            if not any(c in file_path for c in "$`()"):
                return ("read", file_path)
    return _CODEX_PARSER._parse_file_operation_from_command(cmd)
