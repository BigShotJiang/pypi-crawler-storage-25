"""Version-aware normalizer registry."""

import fnmatch

from .adapters import (
    ClaudeV1Normalizer,
    ClaudeWebV1Normalizer,
    CodexV1Normalizer,
    CopilotV1Normalizer,
    CursorV1Normalizer,
    GeminiV1Normalizer,
    OpenCodeV1Normalizer,
)
from .base import BaseNormalizer


class DefaultNormalizer(BaseNormalizer):
    """Fallback normalizer that returns None for all operations."""

    def extract_todo(self, event, todo_state=None):
        return None

    def extract_file_operation(self, event):
        return None

    def extract_skill(self, event):
        return None

    def extract_diff(self, event, session):
        return None

    def extract_session_metadata(self, source_entries, daemon_metadata=None):
        return None

    def extract_token_usage(self, source_entry):
        return []

    def extract_error(self, source_entry):
        return None

    def extract_compaction(self, source_entries):
        return []


# Registry mapping (agent_type, version_pattern) -> Normalizer class
# Will be populated as we implement each normalizer
NORMALIZERS: dict[tuple[str, str], type[BaseNormalizer]] = {
    ("claude", "*"): ClaudeV1Normalizer,  # All Claude versions use same format
    ("claude_web", "*"): ClaudeWebV1Normalizer,  # Web sessions use web-specific format
    ("cursor", "*"): CursorV1Normalizer,  # All Cursor versions use same format
    ("codex", "*"): CodexV1Normalizer,  # All Codex versions use same format
    ("copilot", "*"): CopilotV1Normalizer,  # All Copilot CLI versions use same format
    ("gemini", "*"): GeminiV1Normalizer,  # All Gemini versions use same format
    ("opencode", "*"): OpenCodeV1Normalizer,  # All OpenCode versions use same format
}

# Cache for normalizer instances (agent_type, version) -> instance
_normalizer_cache: dict[tuple[str, str], BaseNormalizer] = {}


def get_normalizer(agent_type: str, version: str) -> BaseNormalizer:
    """Get version-aware normalizer for agent.

    Args:
        agent_type: Agent type (claude, cursor, codex, gemini)
        version: Agent version string (e.g., "1.2.3")

    Returns:
        Appropriate normalizer instance (cached)
    """
    cache_key = (agent_type, version)

    # Check cache first
    if cache_key in _normalizer_cache:
        return _normalizer_cache[cache_key]

    # Find matching normalizer
    for (agent, ver_pattern), normalizer_class in NORMALIZERS.items():
        if agent == agent_type and fnmatch.fnmatch(version, ver_pattern):
            instance = normalizer_class()
            _normalizer_cache[cache_key] = instance
            return instance

    # Fallback to default
    default = DefaultNormalizer()
    _normalizer_cache[cache_key] = default
    return default


def register_normalizer(
    agent_type: str, version_pattern: str, normalizer_class: type[BaseNormalizer]
):
    """Register a normalizer for an agent version pattern.

    Args:
        agent_type: Agent type (claude, cursor, etc.)
        version_pattern: Version glob pattern (e.g., "1.*", "2.1.*")
        normalizer_class: Normalizer class to register
    """
    NORMALIZERS[(agent_type, version_pattern)] = normalizer_class
    # Clear cache for this agent since registry changed
    keys_to_clear = [k for k in _normalizer_cache if k[0] == agent_type]
    for key in keys_to_clear:
        del _normalizer_cache[key]


def get_supported_agent_types() -> set[str]:
    """Get the set of agent types that have registered normalizers.

    Returns:
        Set of agent type strings (e.g., {"claude", "cursor", "codex", "gemini"})
    """
    return {agent_type for (agent_type, _) in NORMALIZERS}
