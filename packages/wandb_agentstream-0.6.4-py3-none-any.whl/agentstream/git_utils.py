"""Git utilities for resolving repository and commit information.

This module provides functions to determine the git repository and commit SHA
for a given working directory, using multiple strategies:

1. Claude Config Lookup (Priority 1): Read ~/.claude.json and reverse-lookup
   the repo slug from the githubRepoPaths mapping.

2. Filesystem Lookup (Priority 2): Walk up from cwd to find .git directory
   and parse the remote URL from .git/config.

These utilities are used to populate git_repo and git_commit fields in
session summaries for code survival tracking.
"""

from __future__ import annotations

import configparser
import json
import re
import subprocess
from os import PathLike
from pathlib import Path
from urllib.parse import urlparse, urlunparse


def resolve_git_repo_from_claude_config(
    cwd: str | PathLike[str],
    config_path: Path | None = None,
) -> str | None:
    """Resolve git repository from Claude config file.

    Reads ~/.claude.json and performs a reverse lookup: given a working
    directory, find which repo slug it belongs to based on the githubRepoPaths
    mapping.

    Args:
        cwd: The working directory to look up.
        config_path: Path to Claude config file. Defaults to ~/.claude.json.

    Returns:
        Repository in "github.com/org/repo" format, or None if not found.

    Note:
        This function handles nonexistent paths gracefully, which is important
        for historic sessions where the directory may no longer exist.
    """
    if config_path is None:
        config_path = Path.home() / ".claude.json"

    # Read and parse config file
    try:
        content = config_path.read_text(encoding="utf-8")
        config = json.loads(content)
    except (FileNotFoundError, OSError, json.JSONDecodeError):
        return None

    # Get githubRepoPaths mapping
    repo_paths = config.get("githubRepoPaths")
    if not repo_paths or not isinstance(repo_paths, dict):
        return None

    # Normalize cwd for comparison (resolve symlinks, normalize separators)
    # Note: We use str operations to handle nonexistent paths
    cwd_str = str(cwd).replace("\\", "/").rstrip("/")

    # Find best (longest) matching path
    best_match: tuple[str, int] | None = None  # (repo_slug, path_length)

    for repo_slug, repo_path in repo_paths.items():
        if not isinstance(repo_path, str):
            continue

        # Normalize repo path for comparison
        repo_path_normalized = repo_path.replace("\\", "/").rstrip("/")

        # Check if cwd is under this repo path
        # Either exact match or cwd starts with repo_path + "/"
        if cwd_str == repo_path_normalized or cwd_str.startswith(repo_path_normalized + "/"):
            path_len = len(repo_path_normalized)
            if best_match is None or path_len > best_match[1]:
                best_match = (repo_slug, path_len)

    if best_match is None:
        return None

    # Strip leading/trailing slashes and collapse internal "//" so a malformed
    # key like "/coreweave/sunk-anywhere" doesn't produce "github.com//coreweave/...".
    slug = re.sub(r"/+", "/", best_match[0].strip("/"))
    if not slug:
        return None
    return f"github.com/{slug}"


def find_git_root(start_path: Path | str | PathLike[str]) -> Path | None:
    """Find the git repository root by walking up from start_path.

    Args:
        start_path: Directory to start searching from.

    Returns:
        Path to the git repository root (directory containing .git), or None.
        For worktrees, returns the worktree directory (not the main repo).
    """
    path = Path(start_path)

    # Handle nonexistent paths by walking up until we find something that exists
    while not path.exists():
        parent = path.parent
        if parent == path:
            # Reached root without finding existing directory
            return None
        path = parent

    # Walk up looking for .git (can be directory or file for worktrees)
    current = path
    while True:
        git_marker = current / ".git"
        if git_marker.is_dir() or git_marker.is_file():
            return current

        parent = current.parent
        if parent == current:
            # Reached filesystem root
            return None
        current = parent


def get_git_dir(git_root: Path) -> Path | None:
    """Get the actual .git directory, handling worktrees.

    In a regular repo, .git is a directory.
    In a worktree, .git is a file containing: "gitdir: /path/to/.git/worktrees/<name>"

    Args:
        git_root: Path to the git repository root (from find_git_root).

    Returns:
        Path to the actual .git directory, or None if not found.
    """
    git_marker = git_root / ".git"

    if git_marker.is_dir():
        return git_marker

    if git_marker.is_file():
        # Worktree: .git is a file with "gitdir: <path>"
        try:
            content = git_marker.read_text(encoding="utf-8").strip()
            if content.startswith("gitdir: "):
                gitdir_path = content[8:]  # Remove "gitdir: " prefix
                # Handle relative paths
                if not Path(gitdir_path).is_absolute():
                    gitdir_path = str((git_root / gitdir_path).resolve())
                resolved = Path(gitdir_path)
                if resolved.is_dir():
                    return resolved
        except OSError:
            pass

    return None


def get_git_remote_url(git_root: Path) -> str | None:
    """Get the remote URL from git config.

    Parses .git/config to find the origin remote URL. If multiple remotes
    exist, prefers "origin".

    Args:
        git_root: Path to the git repository root (contains .git directory).

    Returns:
        Remote URL string, or None if not found.
    """
    git_dir = get_git_dir(git_root)
    if git_dir is None:
        return None

    # For worktrees, config is in the main repo's .git directory
    # The worktree's git dir is .git/worktrees/<name>, so config is at ../../config
    config_path = git_dir / "config"
    if not config_path.is_file():
        # Try parent's config (for worktrees)
        parent_config = git_dir.parent.parent / "config"
        if parent_config.is_file():
            config_path = parent_config
        else:
            return None

    if not config_path.is_file():
        return None

    try:
        # strict=False allows duplicate options (git configs can have multi-valued keys)
        config = configparser.ConfigParser(strict=False)
        config.read(config_path)

        # Look for origin remote first
        if 'remote "origin"' in config.sections():
            url = config.get('remote "origin"', "url", fallback=None)
            if url:
                return url

        # Fall back to any remote
        for section in config.sections():
            if section.startswith('remote "'):
                url = config.get(section, "url", fallback=None)
                if url:
                    return url

    except (configparser.Error, OSError):
        return None

    return None


def sanitize_git_url(url: str) -> str:
    """Strip credentials (user:pass@) from a git remote URL.

    Handles both full URLs (https://user:token@host/path) and
    already-normalized URLs (user:token@host/path) as stored in the DB.
    """
    if not url:
        return url
    parsed = urlparse(url)
    if parsed.scheme in ("http", "https") and (parsed.username or parsed.password):
        host = parsed.hostname or ""
        netloc = f"{host}:{parsed.port}" if parsed.port else host
        return urlunparse(parsed._replace(netloc=netloc))
    # Handle scheme-less normalized URLs like "user:token@github.com/org/repo"
    # but not SSH URLs like "git@github.com:org/repo" or "myuser@github.com:org/repo"
    if "@" in url and not (
        url.startswith("git@") or ("://" not in url and ":" in url.split("@", 1)[1])
    ):
        return re.sub(r"^[^@]+@", "", url)
    return url


def _canonicalize_path(raw_path: str) -> str | None:
    """Collapse ``/+`` → ``/``, strip leading/trailing slashes, drop ``.git`` from
    the final segment, and truncate to the first two segments (owner/repo).

    Returning at most two segments matches the contract that repo-access keys
    are ``host/owner/repo``: URLs like ``github.com/org/repo/tree/main`` must
    canonicalize to ``org/repo`` so ``user_repo_access.git_repo`` and
    ``sessions.git_repo`` agree.
    """
    segments = [p for p in re.split(r"/+", raw_path) if p]
    if not segments:
        return None
    # Remove trailing ".git" from the last meaningful segment — handles both
    # "org/repo.git" and "org/repo.git/" (the latter previously leaked ".git"
    # into the canonical key because the suffix was stripped before slashes).
    segments[-1] = segments[-1].removesuffix(".git")
    if not segments[-1]:
        return None
    return "/".join(segments[:2])


def normalize_git_url(url: str) -> str | None:
    """Normalize a git remote URL to host/org/repo format.

    Handles both HTTPS and SSH URL formats:
    - https://github.com/org/repo.git -> github.com/org/repo
    - git@github.com:org/repo.git -> github.com/org/repo

    Args:
        url: Git remote URL string.

    Returns:
        Normalized URL in "host/org/repo" format, or None if unrecognized.
    """
    if not url:
        return None

    url = sanitize_git_url(url)

    # HTTPS format: https://github.com/org/repo
    https_match = re.match(r"^https?://([^/]+)/+(.+)$", url)
    if https_match:
        host = https_match.group(1)
        path = _canonicalize_path(https_match.group(2))
        return f"{host}/{path}" if path else None

    # SSH format: git@github.com:org/repo
    ssh_match = re.match(r"^git@([^:]+):/*(.+)$", url)
    if ssh_match:
        host = ssh_match.group(1)
        path = _canonicalize_path(ssh_match.group(2))
        return f"{host}/{path}" if path else None

    # Already-normalized format: github.com/org/repo
    normalized_match = re.match(r"^([^/]+\.[^/]+)/+(.+)$", url)
    if normalized_match:
        host = normalized_match.group(1)
        path = _canonicalize_path(normalized_match.group(2))
        return f"{host}/{path}" if path else None

    # Bare slug: org/repo → assume github.com
    slug_match = re.match(r"^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$", url.removesuffix(".git"))
    if slug_match:
        return f"github.com/{url.removesuffix('.git')}"

    return None


# Backward-compatible alias
_normalize_git_url = normalize_git_url


def get_git_commit_sha(git_root: Path) -> str | None:
    """Get the current commit SHA from git.

    Reads the HEAD file to determine the current commit. Handles:
    - Symbolic refs (e.g., "ref: refs/heads/main")
    - Detached HEAD (direct SHA)
    - Packed refs (when loose ref file doesn't exist)
    - Worktrees

    Args:
        git_root: Path to the git repository root (contains .git directory).

    Returns:
        40-character commit SHA, or None if not found.
    """
    git_dir = get_git_dir(git_root)
    if git_dir is None:
        return None

    head_path = git_dir / "HEAD"

    if not head_path.is_file():
        return None

    try:
        head_content = head_path.read_text(encoding="utf-8").strip()
    except OSError:
        return None

    # Check if HEAD is a symbolic ref
    if head_content.startswith("ref: "):
        ref_path = head_content[5:]  # Remove "ref: " prefix
        return _resolve_ref(git_dir, ref_path)

    # HEAD is a direct SHA (detached HEAD)
    if len(head_content) == 40 and all(c in "0123456789abcdef" for c in head_content.lower()):
        return head_content

    return None


def _resolve_ref(git_dir: Path, ref_path: str) -> str | None:
    """Resolve a git ref to its commit SHA.

    First checks for a loose ref file, then falls back to packed-refs.
    For worktrees, also checks the main repository's refs.

    Args:
        git_dir: Path to .git directory (may be worktree's git dir).
        ref_path: Reference path (e.g., "refs/heads/main").

    Returns:
        40-character commit SHA, or None if not found.
    """
    # Directories to check: worktree's git_dir and main repo's git_dir
    # For worktrees, git_dir is .git/worktrees/<name>, main is .git/worktrees/<name>/../..
    dirs_to_check = [git_dir]
    if git_dir.name != ".git" and (git_dir.parent.parent / "HEAD").is_file():
        # This looks like a worktree dir, add main repo
        dirs_to_check.append(git_dir.parent.parent)

    for check_dir in dirs_to_check:
        # Try loose ref file first
        ref_file = check_dir / ref_path
        if ref_file.is_file():
            try:
                return ref_file.read_text(encoding="utf-8").strip()
            except OSError:
                pass

        # Fall back to packed-refs
        packed_refs_path = check_dir / "packed-refs"
        if packed_refs_path.is_file():
            try:
                content = packed_refs_path.read_text(encoding="utf-8")
                for line in content.splitlines():
                    # Skip comments and header
                    if line.startswith("#") or line.startswith("^"):
                        continue
                    parts = line.split()
                    if len(parts) >= 2 and parts[1] == ref_path:
                        return parts[0]
            except OSError:
                pass

    return None


def get_git_branch(git_root: Path) -> str | None:
    """Get the current git branch name.

    Reads the HEAD file to determine the current branch. Returns None
    for detached HEAD state.

    Args:
        git_root: Path to the git repository root.

    Returns:
        Branch name (e.g., "main"), or None if detached HEAD or not found.
    """
    git_dir = get_git_dir(git_root)
    if git_dir is None:
        return None

    head_path = git_dir / "HEAD"
    if not head_path.is_file():
        return None

    try:
        head_content = head_path.read_text(encoding="utf-8").strip()
    except OSError:
        return None

    # Check if HEAD is a symbolic ref
    if head_content.startswith("ref: refs/heads/"):
        # Extract branch name from "ref: refs/heads/branch-name"
        return head_content[16:]  # Remove "ref: refs/heads/" prefix

    # Detached HEAD - no branch
    return None


def resolve_git_repo(
    cwd: str | PathLike[str],
    claude_config_path: Path | None = None,
) -> str | None:
    """Resolve git repository using multiple strategies.

    Priority order:
    1. Claude config lookup (~/.claude.json githubRepoPaths)
    2. Filesystem lookup (.git/config remote URL)

    Args:
        cwd: The working directory to resolve.
        claude_config_path: Optional custom path to Claude config file.

    Returns:
        Repository in "github.com/org/repo" format, or None if not found.
    """
    # Priority 1: Claude config lookup
    result = resolve_git_repo_from_claude_config(cwd, config_path=claude_config_path)
    if result:
        return result

    # Priority 2: Filesystem lookup
    git_root = find_git_root(cwd)
    if git_root is None:
        return None

    remote_url = get_git_remote_url(git_root)
    if remote_url is None:
        return None

    return normalize_git_url(remote_url)


def get_default_branch(git_root: Path) -> str | None:
    """Get the default branch name for a repository.

    Checks for common default branch names (main, master).

    Args:
        git_root: Path to the git repository root.

    Returns:
        Default branch name, or None if not found.
    """
    git_dir = get_git_dir(git_root)
    if git_dir is None:
        return None

    # For worktrees, refs are in the main repo's git directory
    dirs_to_check = [git_dir]
    if git_dir.name != ".git" and (git_dir.parent.parent / "HEAD").is_file():
        dirs_to_check.append(git_dir.parent.parent)

    for check_dir in dirs_to_check:
        # Check for common default branch names
        for branch in ["main", "master"]:
            ref_path = check_dir / "refs" / "heads" / branch
            if ref_path.is_file():
                return branch

        # Check packed-refs for default branches
        packed_refs_path = check_dir / "packed-refs"
        if packed_refs_path.is_file():
            try:
                content = packed_refs_path.read_text(encoding="utf-8")
                for line in content.splitlines():
                    if line.startswith("#") or line.startswith("^"):
                        continue
                    parts = line.split()
                    if len(parts) >= 2:
                        ref = parts[1]
                        for branch in ["main", "master"]:
                            if ref == f"refs/heads/{branch}":
                                return branch
            except OSError:
                pass

    return None


def get_git_commit(cwd: Path | str | PathLike[str]) -> str | None:
    """Get the current git commit SHA from a working directory.

    Convenience wrapper that finds the git root and gets the commit SHA.

    Args:
        cwd: Working directory (will find git root from here).

    Returns:
        40-character commit SHA, or None if not in a git repo.
    """
    git_root = find_git_root(cwd)
    if git_root is None:
        return None
    return get_git_commit_sha(git_root)


def get_git_repo(cwd: Path | str | PathLike[str]) -> str | None:
    """Get git repository URL from a working directory.

    Convenience wrapper that resolves git repo using multiple strategies.
    This is an alias for resolve_git_repo().

    Args:
        cwd: Working directory.

    Returns:
        Repository in "host/org/repo" format, or None if not found.
    """
    return resolve_git_repo(cwd)


def get_git_branch_from_cwd(cwd: Path | str | PathLike[str]) -> str | None:
    """Get the current git branch from a working directory.

    Convenience wrapper that finds the git root and gets the branch.

    Args:
        cwd: Working directory (will find git root from here).

    Returns:
        Branch name, or None if not in a git repo or detached HEAD.
    """
    git_root = find_git_root(cwd)
    if git_root is None:
        return None
    return get_git_branch(git_root)


def get_commit_at_timestamp(
    git_root: Path,
    branch: str,
    timestamp_ms: int,
) -> str | None:
    """Find the last commit on a branch before a given timestamp.

    Uses git log to find the most recent commit on the specified branch
    that occurred before the given timestamp. This is useful for determining
    what commit was checked out at the start of a session.

    Args:
        git_root: Path to the git repository root.
        branch: Branch name to search.
        timestamp_ms: Unix timestamp in milliseconds. Finds commits before this time.

    Returns:
        40-character commit SHA, or None if not found or branch doesn't exist.
    """
    # Convert ms to seconds for git
    timestamp_sec = timestamp_ms // 1000

    try:
        result = subprocess.run(
            [
                "git",
                "log",
                "-1",
                "--format=%H",
                f"--before={timestamp_sec}",
                branch,
            ],
            cwd=git_root,
            capture_output=True,
            text=True,
            timeout=10,
        )

        if result.returncode == 0 and result.stdout.strip():
            sha = result.stdout.strip()
            # Validate it's a 40-char hex string
            if len(sha) == 40 and all(c in "0123456789abcdef" for c in sha.lower()):
                return sha

    except (subprocess.SubprocessError, OSError):
        pass

    return None
