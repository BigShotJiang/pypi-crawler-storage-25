"""Cost calculation from token usage and model pricing."""

import json
import logging
from pathlib import Path

logger = logging.getLogger(__name__)

# Load model prices once at module level
_PRICES_PATH = Path(__file__).resolve().parent / "data" / "model_prices.json"
_MODEL_PRICES: dict = {}

try:
    with open(_PRICES_PATH) as f:
        _MODEL_PRICES = json.load(f)
except FileNotFoundError:
    logger.warning(f"Model prices file not found: {_PRICES_PATH}")
except json.JSONDecodeError:
    logger.warning(f"Invalid JSON in model prices: {_PRICES_PATH}")


def _lookup_model(model: str) -> dict | None:
    """Look up model pricing, trying exact match then prefix stripping."""
    if not model:
        return None

    # Exact match
    if model in _MODEL_PRICES:
        return _MODEL_PRICES[model]

    # Strip common provider prefixes (e.g., "anthropic/claude-opus-4-6")
    if "/" in model:
        stripped = model.split("/", 1)[1]
        if stripped in _MODEL_PRICES:
            return _MODEL_PRICES[stripped]

    # Fall back to default pricing for unknown models
    return _MODEL_PRICES.get("_default")


def calculate_cost(
    model: str,
    input_tokens: int = 0,
    output_tokens: int = 0,
    cache_read_tokens: int = 0,
    cache_creation_tokens: int = 0,
    reasoning_tokens: int = 0,
) -> float:
    """Calculate cost in USD from token counts and model pricing.

    Each token field maps directly to a pricing tier:
    - input_tokens: base-rate input (not cached, not cache-written)
    - cache_read_tokens: discounted cached input
    - cache_creation_tokens: premium cache-write input (Anthropic only)

    Args:
        model: Model name (e.g., "claude-opus-4-6", "anthropic/claude-opus-4-6")
        input_tokens: Base-rate input tokens (excludes cached and cache-written)
        output_tokens: Number of output tokens
        cache_read_tokens: Number of cache read tokens (discounted rate)
        cache_creation_tokens: Number of cache creation tokens (premium rate)
        reasoning_tokens: Number of reasoning tokens

    Returns:
        Cost in USD. Uses default pricing ($1.25/$10 per M tokens) for unknown models.
        Returns 0.0 only if model is empty/None.
    """
    pricing = _lookup_model(model)
    if not pricing:
        return 0.0

    input_cost = input_tokens * pricing.get("input_cost_per_token", 0)
    output_cost = output_tokens * pricing.get("output_cost_per_token", 0)
    cache_read_cost = cache_read_tokens * pricing.get("cache_read_input_token_cost", 0)
    cache_creation_cost = cache_creation_tokens * pricing.get("cache_creation_input_token_cost", 0)

    # Use reasoning-specific cost if available, otherwise fall back to output cost
    reasoning_rate = pricing.get("output_cost_per_reasoning_token") or pricing.get(
        "output_cost_per_token", 0
    )
    reasoning_cost = reasoning_tokens * reasoning_rate

    return input_cost + output_cost + cache_read_cost + cache_creation_cost + reasoning_cost
