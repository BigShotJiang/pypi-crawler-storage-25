"""GitHub Copilot CLI adapter for reading and writing session logs.

Copilot CLI stores each session in:

    $COPILOT_HOME/session-state/<session-id>/events.jsonl
    $COPILOT_HOME/session-state/<session-id>/workspace.yaml

Where ``$COPILOT_HOME`` defaults to ``~/.copilot``. The same layout is used
when Copilot CLI runs inside GitHub Actions (the runner's $HOME is
``/home/runner``), so discovery just needs to honour the env var override
plus the default path.

The ``events.jsonl`` file is an append-only log; each line is a JSON object
with at minimum: ``type``, ``data``, ``id``, ``timestamp``, ``parentId``.
"""

from __future__ import annotations

import base64
import functools
import json
import logging
import mimetypes
import os
import re
from collections.abc import Iterable, Iterator
from datetime import UTC, datetime
from pathlib import Path
from typing import IO, Any

from agentstream.enrichment.copilot_logs import (
    find_log_for_session,
    parse_utilization_lines,
)
from agentstream.events import (
    CustomEvent,
    Event,
    Role,
    RunFinishedEvent,
    RunStartedEvent,
    TextMessageChunkEvent,
    ToolCallChunkEvent,
    ToolCallResultEvent,
)

from .base import Adapter, Session
from .timestamps import TimestampTracker, parse_timestamp_with_fallback

logger = logging.getLogger(__name__)

# Cap inlined image attachments at 10 MB to bound source_entry payload size.
_MAX_INLINE_IMAGE_BYTES = 10 * 1024 * 1024


def _is_subpath(child: Path, parent: Path) -> bool:
    """Check if child is equal to or a subdirectory of parent."""
    try:
        child.resolve().relative_to(parent.resolve())
        return True
    except ValueError:
        return False


def _resolve_image_attachments(attachments: list[Any]) -> bool:
    """Resolve image-file attachments to base64 ``data:`` URLs in place.

    Copilot stores user-pasted/dragged images as ``{"type": "file", "path":
    "/Users/.../foo.png", "displayName": "foo.png"}`` entries on
    ``user.message.data.attachments``. The path points at the user's local
    filesystem — only reachable from the daemon, not the backend. We resolve
    those files into base64 data URLs at adapter time so the backend's image
    extraction pipeline (which already understands ``data:image/...`` URLs)
    can upload them to GCS and emit ``IMAGE_CONTENT`` events that render
    inline with the user message.

    Mutates each image attachment dict by adding a ``data_url`` field and
    returns True if any attachment was modified.
    """
    modified = False
    for att in attachments:
        if not isinstance(att, dict):
            continue
        if att.get("type") != "file":
            continue
        path_str = att.get("path")
        if not isinstance(path_str, str) or not path_str:
            continue
        mime_type, _ = mimetypes.guess_type(path_str)
        if not mime_type or not mime_type.startswith("image/"):
            continue
        p = Path(path_str)
        try:
            if not p.is_file():
                continue
            raw = p.read_bytes()
        except OSError as e:
            logger.debug("Copilot attachment unreadable %s: %s", path_str, e)
            continue
        if len(raw) > _MAX_INLINE_IMAGE_BYTES:
            logger.debug("Copilot attachment too large (%d bytes): %s", len(raw), path_str)
            continue
        encoded = base64.b64encode(raw).decode("ascii")
        att["data_url"] = f"data:{mime_type};base64,{encoded}"
        modified = True
    return modified


def _maybe_resolve_attachments(entry: dict) -> str | None:
    """If ``entry`` is a ``user.message`` with image attachments, resolve them
    to data URLs and return the re-serialized JSON line. Returns None when no
    rewrite is needed so callers can preserve the byte-identical raw line.
    """
    if entry.get("type") != "user.message":
        return None
    data = entry.get("data")
    if not isinstance(data, dict):
        return None
    attachments = data.get("attachments")
    if not isinstance(attachments, list) or not attachments:
        return None
    if not _resolve_image_attachments(attachments):
        return None
    return json.dumps(entry, ensure_ascii=False, separators=(",", ":"))


def _encode_tool_args(arguments: Any) -> str:
    """Serialise a Copilot tool-call ``arguments`` value to a JSON delta.

    Copilot uses two argument shapes:

    * Standard tools (``view``, ``bash``, ``rg`` ...) use a JSON object.
    * Custom tools (``apply_patch``) use a single string body — the raw
      patch text. We wrap those as ``{"input": <body>}`` so the
      backend's ``_agui_to_normalizer_events`` step (which JSON-decodes
      the delta and expects a dict) can route them through the
      normalizer just like Codex's ``custom_tool_call``.
    """
    if isinstance(arguments, str):
        return json.dumps({"input": arguments})
    return json.dumps(arguments or {})


_OUTPUT_LOG_NAME = "output.log"
_OUTPUT_LOG_DIR = "runtime-logs"


def _is_copilot_output_log(path: Path) -> bool:
    """Return True if ``path`` looks like the Copilot cloud agent's
    runtime-logs/output.log.

    GitHub-hosted runners write the Copilot agent step's stdout/stderr to
    ``$RUNNER_TEMP/runtime-logs/output.log``. We discriminate on both the
    filename and the immediate parent directory name; that's specific
    enough to distinguish from any other ``output.log`` that might exist
    elsewhere on the runner.
    """
    return path.name == _OUTPUT_LOG_NAME and path.parent.name == _OUTPUT_LOG_DIR


# Stable model placeholder for cloud SWE-agent sessions. The cloud agent's
# real model lives only in API response bodies the eBPF firewall sees as
# opaque bytes — neither the daemon's metadata nor the on-disk session.start
# records it. Without a placeholder the backend's primary_model gate would
# skip SESSION_METADATA and the dashboard would 404. Sourced here so daemon
# (session_importer) and server (copilot_v1 normalizer) emit the same string.
SWE_AGENT_MODEL = "swe-agent"


# COPILOT_AGENT_MODEL format: "<provider>:<model>".
def resolve_swe_agent_model() -> str:
    """Resolve the model name for a cloud SWE-agent session.

    The runner exposes the real model via ``COPILOT_AGENT_MODEL`` (e.g.
    ``sweagent-capi:gpt-5.3-codex``). Strip the provider prefix and return the
    bare model name; fall back to the ``swe-agent`` placeholder if the env var
    is unset.
    """
    raw = os.environ.get("COPILOT_AGENT_MODEL", "").strip()
    if not raw:
        return SWE_AGENT_MODEL
    return raw.rsplit(":", 1)[-1].strip() or SWE_AGENT_MODEL


def _iso_from_ms(ms: int) -> str:
    if not ms:
        return ""
    return datetime.fromtimestamp(ms / 1000, tz=UTC).isoformat().replace("+00:00", "Z")


def _runner_temp_dir() -> Path | None:
    env = os.environ.get("RUNNER_TEMP")
    return Path(env).expanduser() if env else None


def _runtime_logs_output_path() -> Path | None:
    runner_temp = _runner_temp_dir()
    if runner_temp is None:
        return None
    return runner_temp / _OUTPUT_LOG_DIR / _OUTPUT_LOG_NAME


def _line_indent(line: str) -> int:
    return len(line) - len(line.lstrip(" "))


def _parse_literal_block(
    lines: list[str], start: int, end: int, body_indent: int
) -> tuple[str, int]:
    """Read a YAML ``|`` literal block starting at ``lines[start]``.

    Body lines are required to be indented by ``body_indent`` spaces.
    Blank lines are preserved (a multi-line shell heredoc legitimately
    contains them); only an out-dented non-blank line terminates the
    block. Returns the dedented body text plus the index of the first
    line *after* the block. Trailing blank lines are trimmed (YAML
    literal-block convention).
    """
    out: list[str] = []
    i = start
    while i < end:
        line = lines[i]
        if line == "":
            out.append("")
            i += 1
            continue
        if _line_indent(line) < body_indent:
            break
        out.append(line[body_indent:])
        i += 1
    while out and out[-1] == "":
        out.pop()
    return "\n".join(out), i


_BOOL_TRUE = frozenset({"true", "True", "TRUE"})
_BOOL_FALSE = frozenset({"false", "False", "FALSE"})
_NULL_LITERALS = frozenset({"null", "Null", "NULL", "~"})


def _coerce_scalar(value: str) -> Any:
    """Best-effort coerce a YAML-ish scalar string to its native type.

    Cloud SWE-agent prints tool args as YAML scalars: ``per_page: 5`` and
    ``-n: true`` come through as the strings ``"5"`` and ``"true"`` if we
    don't coerce. Downstream normalizers and the dashboard then see
    string-shaped numbers/booleans and can't reason about them as their
    real types. Coercion is best-effort — anything that doesn't match a
    recognised literal stays a plain string.
    """
    if value == "":
        return ""
    if value in _BOOL_TRUE:
        return True
    if value in _BOOL_FALSE:
        return False
    if value in _NULL_LITERALS:
        return None
    try:
        return int(value)
    except ValueError:
        pass
    try:
        f = float(value)
    except ValueError:
        return value
    # Reject inf/nan — float() accepts both, but YAML/JSON don't treat
    # "inf"/"nan" as numeric literals and we'd rather keep them as strings.
    if f != f or f in (float("inf"), float("-inf")):
        return value
    return f


def _coerce_literal_block(value: str) -> Any:
    """If a ``|`` literal-block body parses as a JSON dict or list, return
    the parsed structure; otherwise return the original string.

    Cloud SWE-agent's tool args sometimes encode structured data as a YAML
    literal block containing JSON (e.g. ``paths`` arrays for ``rg``,
    ``workflow_runs_filter`` objects for github-mcp-server tools). Without
    parsing, the dashboard renders raw escaped JSON and the normalizer
    sees a string instead of the structure. We only coerce dicts/lists —
    coercing scalar JSON values here would change behavior for literal
    blocks that genuinely contain a single number or word.
    """
    try:
        parsed = json.loads(value)
    except (json.JSONDecodeError, ValueError):
        return value
    if isinstance(parsed, (dict, list)):
        return parsed
    return value


def _parse_yaml_dict(
    lines: list[str], start: int, end: int, key_indent: int
) -> tuple[dict[str, Any], int]:
    """Parse YAML-ish ``key: value`` pairs at exactly ``key_indent`` spaces.

    Values are either single-line scalars (text after the ``:``) or ``|``
    literal blocks (continuation indented by ``key_indent + 2``). Stops at
    the first non-blank line that's out-dented from ``key_indent``. Scalars
    are coerced to int/float/bool/null when they parse cleanly; literal
    blocks are JSON-parsed when their body is a dict or list.
    """
    result: dict[str, Any] = {}
    body_indent = key_indent + 2
    i = start
    while i < end:
        line = lines[i]
        if line == "":
            i += 1
            continue
        indent = _line_indent(line)
        if indent < key_indent:
            break
        if indent > key_indent:
            i += 1
            continue
        stripped = line[key_indent:]
        if ":" not in stripped:
            i += 1
            continue
        key, _, value = stripped.partition(":")
        key = key.strip()
        value = value.strip()
        if value == "|":
            body, i = _parse_literal_block(lines, i + 1, end, body_indent)
            result[key] = _coerce_literal_block(body)
        else:
            result[key] = _coerce_scalar(value)
            i += 1
    return result, i


def _find_function_block_ranges(lines: list[str]) -> list[tuple[int, int]]:
    """Return ``(start, end)`` ranges for each ``function:`` block.

    ``start`` is the index of the literal ``function:`` line; ``end`` is
    the index of the first zero-indent non-blank line after it (exclusive)
    — or ``len(lines)`` if the block runs to EOF (mid-flight capture).
    """
    starts = [i for i, line in enumerate(lines) if line == "function:"]
    ranges: list[tuple[int, int]] = []
    for start in starts:
        end = len(lines)
        for i in range(start + 1, len(lines)):
            line = lines[i]
            if line and not line[0].isspace():
                end = i
                break
        ranges.append((start, end))
    return ranges


def _parse_function_block(lines: list[str], start: int, end: int) -> dict[str, Any]:
    """Parse a single ``function:`` block into ``{name, args, result}``.

    The block format is YAML-ish:

        function:
          name: <scalar>
          args:
            <key>: <scalar>
            <key>: |
              <multi-line>
          result: |
            <multi-line>

    ``result:`` may also be a single-line scalar (``result: <exited with
    exit code 0>``). Missing keys default to empty values.
    """
    block: dict[str, Any] = {"name": "", "args": {}, "result": ""}
    i = start + 1
    while i < end:
        line = lines[i]
        if line == "" or _line_indent(line) != 2:
            i += 1
            continue
        stripped = line[2:]
        if ":" not in stripped:
            i += 1
            continue
        key, _, value = stripped.partition(":")
        key = key.strip()
        value = value.strip()
        if key == "name":
            block["name"] = value
            i += 1
        elif key == "args":
            args, i = _parse_yaml_dict(lines, i + 1, end, key_indent=4)
            block["args"] = args
        elif key == "result":
            if value == "|":
                body, i = _parse_literal_block(lines, i + 1, end, body_indent=4)
                block["result"] = body
            else:
                block["result"] = value
                i += 1
        else:
            i += 1
    return block


def _extract_problem_statement(lines: list[str]) -> str | None:
    """Extract the user prompt from the ``Problem statement:`` block.

    The agent runtime prints ``Problem statement:`` on its own line,
    followed by a blank line, then a bare ``----`` opening fence, the body,
    and a closing ``----`` fence. We return the body text (with leading
    and trailing blank lines trimmed); ``None`` if either fence is absent
    (mid-flight capture before the prompt finished writing).
    """
    try:
        ps_idx = next(i for i, line in enumerate(lines) if line.strip() == "Problem statement:")
    except StopIteration:
        return None

    open_idx = ps_idx + 1
    while open_idx < len(lines) and lines[open_idx].strip() != "----":
        open_idx += 1
    if open_idx >= len(lines):
        return None

    body_start = open_idx + 1
    close_idx = body_start
    while close_idx < len(lines) and lines[close_idx].strip() != "----":
        close_idx += 1
    if close_idx >= len(lines):
        # Closing fence missing — treat the rest as truncated tail
        return None

    body = lines[body_start:close_idx]
    while body and body[0].strip() == "":
        body.pop(0)
    while body and body[-1].strip() == "":
        body.pop()
    return "\n".join(body) if body else None


# Author handles that map to the Copilot SWE-agent itself when role-tagging
# PR comments. The agent surfaces under several identities:
#   * ``@copilot`` — public-facing handle in problem-statement comments
#   * ``@copilot[bot]`` — generic GitHub bot suffix
#   * ``@copilot-swe-agent[bot]`` — the actual login of the cloud SWE-agent
# Matching is case-insensitive after stripping whitespace and a leading ``@``.
_COPILOT_AUTHOR_HANDLES = frozenset(
    {
        "copilot",
        "copilot[bot]",
        "copilot-swe-agent",
        "copilot-swe-agent[bot]",
    }
)


def _is_copilot_author(author: str) -> bool:
    n = author.strip().lower()
    if n.startswith("@"):
        n = n[1:]
    return n in _COPILOT_AUTHOR_HANDLES


_COMMENTS_OPEN_RE = re.compile(r"<comments>")
_COMMENTS_CLOSE_RE = re.compile(r"</comments>")
_COMMENT_BLOCK_RE = re.compile(r"<comment_(old|new)>(.*?)</comment_\1>", re.S)
_AUTHOR_RE = re.compile(r"<author>([^<]+)</author>")
_COMMENT_ID_STRIP_RE = re.compile(r"<comment_id>.*?</comment_id>", re.S)
_AUTHOR_STRIP_RE = re.compile(r"<author>.*?</author>", re.S)


def _split_problem_statement_comments(problem_text: str) -> list[dict[str, str]] | None:
    """Split the PR comment thread out of a problem statement.

    The cloud SWE-agent injects PR comments into the problem statement under
    a ``<comments>`` block. Each comment is wrapped in ``<comment_old>``
    (existing thread) or ``<comment_new>`` (the comment that triggered this
    run), with ``<author>@handle</author>`` and optional ``<comment_id>``
    metadata. Without this split, the whole problem statement (PR title,
    description, stacked-PR context, *and* every comment) collapses into a
    single user message — burying the actual prompt under boilerplate.

    Returns role-tagged messages in document order (oldest first):
    ``@copilot``-authored comments become ``assistant`` so the dashboard
    renders them as the agent's prior replies; everything else is ``user``.
    Returns None when no ``<comments>`` block is present — callers should
    fall back to emitting the whole text as a single user message.

    Tolerates a missing closing ``</comments>`` tag (mid-flight captures
    truncate the problem statement at arbitrary points): when the open tag
    is found but no close tag follows, the body extends from the opening
    tag to EOF and we still parse whichever ``<comment_*>`` blocks closed
    inside that window.
    """
    open_match = _COMMENTS_OPEN_RE.search(problem_text)
    if not open_match:
        return None
    body_start = open_match.end()
    close_match = _COMMENTS_CLOSE_RE.search(problem_text, body_start)
    body = (
        problem_text[body_start : close_match.start()] if close_match else problem_text[body_start:]
    )

    results: list[dict[str, str]] = []
    for m in _COMMENT_BLOCK_RE.finditer(body):
        block = m.group(2)
        author_match = _AUTHOR_RE.search(block)
        author = author_match.group(1).strip() if author_match else ""

        text = _COMMENT_ID_STRIP_RE.sub("", block)
        text = _AUTHOR_STRIP_RE.sub("", text)
        text = text.strip()
        if not text:
            continue

        role = "assistant" if _is_copilot_author(author) else "user"
        results.append({"role": role, "content": text, "author": author})

    return results if results else None


def _parse_output_log(text: str, file_mtime_ms: int) -> list[dict]:
    """Parse a Copilot cloud agent ``output.log`` into events.jsonl-shape entries.

    Output.log is the GitHub Actions runner's stdout/stderr capture for
    the Copilot agent step. It contains the user prompt
    (``Problem statement:`` block) — split per-comment when a
    ``<comments>`` thread is present — and N tool invocations as YAML-ish
    ``function:`` blocks. The agent's user-visible final response comes
    from the last ``reply_to_comment`` tool call's ``reply`` arg;
    ``report_progress`` is intentionally NOT promoted to a chat turn —
    its ``prDescription`` checklist is consumed by the normalizer as a
    TODO update instead (see ``CopilotV1Normalizer.extract_todo``).

    We synthesize entries in the same ``{type, data, id, timestamp,
    parentId}`` shape used by ``events.jsonl`` so ``_map_entry`` and
    ``parse_source_entry`` consume them unchanged. Synthesized fields:

    * ``id`` — ``out-<entry_index>`` (chained via ``parentId``)
    * ``timestamp`` — file mtime for every entry (no per-line timing)
    * ``toolCallId`` — ``out-tool-<function_index>``

    No per-event timing lives in output.log, so the downstream
    ``TimestampTracker`` stretches a single mtime over the entry stream.
    """
    timestamp_iso = _iso_from_ms(file_mtime_ms)
    lines = text.split("\n")
    entries: list[dict] = []

    def _next_id() -> str:
        return f"out-{len(entries)}"

    def _parent_id() -> str | None:
        return entries[-1]["id"] if entries else None

    problem = _extract_problem_statement(lines)
    if problem:
        comments = _split_problem_statement_comments(problem)
        if comments:
            for c in comments:
                if c["role"] == "assistant":
                    entries.append(
                        {
                            "type": "assistant.message",
                            "data": {
                                "messageId": f"out-msg-{len(entries)}",
                                "content": c["content"],
                                "toolRequests": [],
                            },
                            "id": _next_id(),
                            "timestamp": timestamp_iso,
                            "parentId": _parent_id(),
                        }
                    )
                else:
                    entries.append(
                        {
                            "type": "user.message",
                            "data": {"content": c["content"]},
                            "id": _next_id(),
                            "timestamp": timestamp_iso,
                            "parentId": _parent_id(),
                        }
                    )
        else:
            entries.append(
                {
                    "type": "user.message",
                    "data": {"content": problem},
                    "id": _next_id(),
                    "timestamp": timestamp_iso,
                    "parentId": _parent_id(),
                }
            )

    # Track the agent's final user-visible response. Cloud SWE-agent runs
    # have no native trailing assistant.message — only ``reply_to_comment``
    # carries the agent's closing word to the user. ``report_progress`` is
    # treated as a TODO update by the normalizer (see CopilotV1Normalizer.
    # extract_todo) so its ``prDescription`` checklist must NOT also leak
    # into a chat turn — that's what produced the duplicate "[ ]/[x]"
    # assistant messages users were seeing in the dashboard.
    final_message: str | None = None
    for fn_idx, (start, end) in enumerate(_find_function_block_ranges(lines)):
        block = _parse_function_block(lines, start, end)
        name = block["name"]
        if not name:
            continue
        tool_call_id = f"out-tool-{fn_idx}"
        entries.append(
            {
                "type": "assistant.message",
                "data": {
                    "messageId": f"out-msg-{len(entries)}",
                    "content": "",
                    "toolRequests": [
                        {
                            "toolCallId": tool_call_id,
                            "name": name,
                            "arguments": block["args"],
                            "type": "function",
                        }
                    ],
                },
                "id": _next_id(),
                "timestamp": timestamp_iso,
                "parentId": _parent_id(),
            }
        )
        result_text = block["result"]
        entries.append(
            {
                "type": "tool.execution_complete",
                "data": {
                    "toolCallId": tool_call_id,
                    "success": True,
                    "result": {
                        "content": result_text,
                        "detailedContent": result_text,
                    },
                },
                "id": _next_id(),
                "timestamp": timestamp_iso,
                "parentId": _parent_id(),
            }
        )
        if name == "reply_to_comment":
            reply = block["args"].get("reply")
            if isinstance(reply, str) and reply:
                final_message = reply

    if final_message:
        entries.append(
            {
                "type": "assistant.message",
                "data": {
                    "messageId": f"out-msg-{len(entries)}",
                    "content": final_message,
                    "toolRequests": [],
                },
                "id": _next_id(),
                "timestamp": timestamp_iso,
                "parentId": _parent_id(),
            }
        )

    return entries


@functools.lru_cache(maxsize=1)
def _copilot_home() -> Path:
    """Return the active Copilot CLI home directory.

    Honours the ``COPILOT_HOME`` env var (used by GitHub Actions setups and
    by users who want a non-default location) and falls back to
    ``~/.copilot``. Cached for the lifetime of the process — tests that
    monkeypatch ``COPILOT_HOME`` or ``HOME`` must call ``cache_clear()``.
    """
    env = os.environ.get("COPILOT_HOME")
    if env:
        return Path(env).expanduser()
    return Path.home() / ".copilot"


def _load_workspace_yaml(workspace_path: Path) -> dict[str, Any]:
    """Best-effort parse of a Copilot ``workspace.yaml`` file.

    The file is small and uses a flat ``key: value`` schema, so we parse it
    by hand to avoid pulling in PyYAML. Unknown lines are ignored.
    """
    metadata: dict[str, Any] = {}
    try:
        text = workspace_path.read_text()
    except OSError:
        return metadata

    for line in text.splitlines():
        if not line or line.startswith("#"):
            continue
        if ":" not in line:
            continue
        key, _, value = line.partition(":")
        key = key.strip()
        value = value.strip()
        # Strip surrounding quotes
        if value.startswith(("'", '"')) and value.endswith(("'", '"')) and len(value) >= 2:
            value = value[1:-1]
        if key:
            metadata[key] = value
    return metadata


class CopilotAdapter(Adapter):
    """Adapter for GitHub Copilot CLI ``events.jsonl`` session logs."""

    @property
    def name(self) -> str:
        return "copilot"

    # === Path Detection (for daemon watcher) ===

    def get_base_directories(self) -> list[Path]:
        """Return directories the daemon should watch for Copilot sessions.

        Includes the local CLI ``session-state`` dir plus, when running on
        a GitHub Actions runner with ``$RUNNER_TEMP`` set, the
        ``runtime-logs`` directory where the cloud SWE-agent's stdout is
        captured as ``output.log``.
        """
        dirs: list[Path] = [_copilot_home() / "session-state"]
        runner_temp = _runner_temp_dir()
        if runner_temp is not None:
            dirs.append(runner_temp / _OUTPUT_LOG_DIR)
        return dirs

    def matches_path(self, path: Path) -> bool:
        """Return True if ``path`` looks like a Copilot session file.

        Matches:

        * ``$COPILOT_HOME/session-state/<id>/events.jsonl`` — local CLI
        * ``$RUNNER_TEMP/runtime-logs/output.log`` — cloud SWE-agent
        """
        if _is_copilot_output_log(path):
            runner_temp = _runner_temp_dir()
            if runner_temp is None:
                return False
            try:
                path.relative_to(runner_temp / _OUTPUT_LOG_DIR)
                return True
            except ValueError:
                return False

        if path.name != "events.jsonl":
            return False
        # The parent dir is the session-id; its parent is "session-state".
        parents = list(path.parents)
        if len(parents) < 2 or parents[1].name != "session-state":
            return False
        # Don't resolve() here — the path may not exist in tests or stale
        # daemon state cleanup. relative_to() compares lexically and works
        # fine with absolute paths.
        try:
            path.relative_to(_copilot_home() / "session-state")
        except ValueError:
            return False
        return True

    def get_session_id(self, path: Path) -> str:
        """Extract a session id from a Copilot session file path.

        For ``events.jsonl`` it's the parent directory (Copilot's session-id
        UUID). For ``output.log`` we use ``$COPILOT_AGENT_SESSION_ID`` if
        set (the cloud agent's canonical id); otherwise fall back to the
        parent directory name so each invocation still gets a stable id.
        """
        if _is_copilot_output_log(path):
            env_id = os.environ.get("COPILOT_AGENT_SESSION_ID")
            if env_id:
                return env_id
            return path.parent.name
        return path.parent.name

    # === Raw Entry Reading (for incremental sync) ===

    def read_entries(self, session: Session) -> list[dict]:
        """Read all raw source entries from a Copilot session.

        Dispatches on the session file: an ``events.jsonl`` is the local
        Copilot CLI format; ``output.log`` is the cloud SWE-agent format.
        Both end up returning the same entry shape so downstream sync
        logic is format-agnostic.
        """
        if _is_copilot_output_log(session.path):
            return self._read_output_log_entries(session)
        return self._read_events_jsonl_entries(session)

    def _read_events_jsonl_entries(self, session: Session) -> list[dict]:
        """Read raw entries from a local Copilot CLI ``events.jsonl``.

        One entry per line. The raw line is preserved byte-identically
        except when a ``user.message`` carries image-file attachments: those
        get resolved to base64 data URLs in place so the backend (which can't
        see the user's local filesystem) can still upload and render the
        image.

        Falls back to a timestamp of 0 when Copilot omits the field —
        ``processing.py`` will inject a real ms value via ``_timestamp_ms``.
        """
        entries: list[dict] = []
        try:
            with open(session.path) as f:
                for i, line in enumerate(f):
                    stripped = line.strip()
                    if not stripped:
                        continue
                    try:
                        entry = json.loads(stripped)
                    except json.JSONDecodeError:
                        continue
                    rewritten = _maybe_resolve_attachments(entry)
                    timestamp_ms = parse_timestamp_with_fallback(entry.get("timestamp"), 0)
                    entries.append(
                        {
                            "entry_index": i,
                            "entry_content": rewritten if rewritten is not None else stripped,
                            "entry_timestamp_ms": timestamp_ms,
                        }
                    )
        except OSError:
            return entries
        return entries

    def _read_output_log_entries(self, session: Session) -> list[dict]:
        """Read a Copilot cloud SWE-agent ``output.log`` as synthetic entries.

        The cloud agent step's stdout/stderr is captured by the runner at
        ``$RUNNER_TEMP/runtime-logs/output.log``. There's no
        ``events.jsonl``, no per-event timestamp, no tool-call ids. We
        parse the file once into a sequence of dicts whose shape matches
        a real Copilot ``events.jsonl`` entry (``type``, ``data``, ``id``,
        ``timestamp``, ``parentId``) so the existing ``_map_entry`` and
        ``parse_source_entry`` paths can consume them unchanged.

        See :func:`_parse_output_log` for the synthesized entry shapes.
        """
        try:
            text = session.path.read_text()
        except OSError:
            return []
        file_mtime_ms = int(session.modified_at * 1000) if session.modified_at else 0
        synthetic = _parse_output_log(text, file_mtime_ms)
        entries: list[dict] = []
        for i, entry in enumerate(synthetic):
            entries.append(
                {
                    "entry_index": i,
                    "entry_content": json.dumps(entry, ensure_ascii=False, separators=(",", ":")),
                    "entry_timestamp_ms": file_mtime_ms,
                }
            )
        return entries

    # === Entry Enrichment (for daemon sync) ===

    def enrich_entries(self, entries: list[dict], session: Session) -> list[dict]:
        """Attach ``_input_tokens`` to ``assistant.message`` entries.

        Copilot's ``events.jsonl`` only logs ``outputTokens`` per message;
        the matching input-context size lives in the per-process log at
        ``$COPILOT_HOME/logs/process-*.log`` as ``CompactionProcessor:
        Utilization (Y/Z tokens)`` lines (the same data the in-CLI
        ``/usage`` view surfaces). We pair each assistant.message with
        the most recent Utilization line preceding its timestamp; when
        no log file is found or the gap is too large the entry is left
        untouched and the normalizer falls back to output-only TOKEN_USAGE.

        See ``agentstream/enrichment/copilot_logs.py`` for parsing rules
        and the rationale for this hack.
        """
        if not entries:
            return entries

        log_path = find_log_for_session(session.id)
        if log_path is None:
            return entries

        index = parse_utilization_lines(log_path)
        if not len(index):
            return entries

        for entry in entries:
            try:
                content = json.loads(entry["entry_content"])
            except (json.JSONDecodeError, KeyError, TypeError):
                continue
            if not isinstance(content, dict) or content.get("type") != "assistant.message":
                continue
            data = content.get("data")
            if not isinstance(data, dict) or not isinstance(data.get("outputTokens"), int):
                continue

            input_tokens = index.lookup(entry.get("entry_timestamp_ms", 0))
            if input_tokens is None:
                continue

            content["_input_tokens"] = input_tokens
            entry["entry_content"] = json.dumps(content, ensure_ascii=False, separators=(",", ":"))

        return entries

    # === Session Discovery ===

    def discover_sessions(self, project_dir: Path) -> list[Session]:
        """Find Copilot sessions whose ``cwd`` lives inside ``project_dir``.

        We read ``workspace.yaml`` for cheap metadata; if it's missing we fall
        back to scanning the first event of ``events.jsonl`` for a
        ``session.start`` entry containing the cwd.
        """
        sessions: list[Session] = []
        project_resolved = project_dir.resolve()

        base = _copilot_home() / "session-state"
        if not base.exists():
            # No local CLI sessions, but the cloud SWE-agent path may
            # still have an output.log to discover.
            sessions.extend(self._discover_output_log_sessions(project_resolved))
            sessions.sort(key=lambda s: s.modified_at, reverse=True)
            return sessions

        for session_dir in base.iterdir():
            if not session_dir.is_dir():
                continue

            events_path = session_dir / "events.jsonl"
            if not events_path.exists():
                continue

            workspace_path = session_dir / "workspace.yaml"
            metadata = _load_workspace_yaml(workspace_path) if workspace_path.exists() else {}

            session_cwd = metadata.get("cwd") or self._extract_cwd_from_first_entry(events_path)
            if not session_cwd:
                continue

            if not _is_subpath(Path(session_cwd), project_resolved):
                continue

            session_id = metadata.get("id") or session_dir.name
            try:
                stat = events_path.stat()
            except OSError:
                continue

            sessions.append(
                Session(
                    id=session_id,
                    path=events_path,
                    format=self.name,
                    modified_at=stat.st_mtime,
                    metadata=metadata or None,
                )
            )

        sessions.extend(self._discover_output_log_sessions(project_resolved))

        sessions.sort(key=lambda s: s.modified_at, reverse=True)
        return sessions

    def _discover_output_log_sessions(self, project_resolved: Path) -> list[Session]:
        """Find Copilot cloud SWE-agent ``output.log`` sessions.

        Looks for ``$RUNNER_TEMP/runtime-logs/output.log`` — the GitHub
        Actions runner's stdout capture for the Copilot agent step.
        Session id comes from ``$COPILOT_AGENT_SESSION_ID`` (cloud agent's
        canonical id). cwd comes from ``$GITHUB_WORKSPACE``; without it we
        skip discovery because we'd otherwise attribute the run to the
        wrong project.
        """
        sessions: list[Session] = []
        cwd_env = os.environ.get("GITHUB_WORKSPACE")
        if not cwd_env:
            return sessions
        if not _is_subpath(Path(cwd_env), project_resolved):
            return sessions

        output_log = _runtime_logs_output_path()
        if output_log is None or not output_log.is_file():
            return sessions
        try:
            stat = output_log.stat()
        except OSError:
            return sessions

        session_id = os.environ.get("COPILOT_AGENT_SESSION_ID")
        branch = os.environ.get("COPILOT_AGENT_BRANCH_NAME") or os.environ.get("GITHUB_REF_NAME")
        sid = session_id or output_log.parent.name
        metadata: dict[str, Any] = {"cwd": cwd_env}
        if branch:
            metadata["branch"] = branch
            metadata["git_branch"] = branch
        sessions.append(
            Session(
                id=sid,
                path=output_log,
                format=self.name,
                modified_at=stat.st_mtime,
                metadata=metadata,
            )
        )
        return sessions

    @staticmethod
    def _extract_cwd_from_first_entry(events_path: Path) -> str | None:
        """Read first entry of ``events.jsonl`` and return ``data.context.cwd``.

        Used when ``workspace.yaml`` is missing — for example a session that
        was killed before Copilot persisted workspace metadata.
        """
        try:
            with open(events_path) as f:
                # Scan a small prelude in case Copilot ever emits other events
                # (telemetry, etc.) before ``session.start``. Skip blank/invalid
                # lines rather than aborting on the first one.
                for _ in range(20):
                    line = f.readline()
                    if not line:
                        break
                    stripped = line.strip()
                    if not stripped:
                        continue
                    try:
                        entry = json.loads(stripped)
                    except json.JSONDecodeError:
                        continue
                    if entry.get("type") == "session.start":
                        ctx = (entry.get("data") or {}).get("context") or {}
                        cwd = ctx.get("cwd")
                        return cwd if isinstance(cwd, str) else None
        except OSError:
            return None
        return None

    # === Local Event Reading ===

    def read_events(self, session: Session) -> Iterator[Event]:
        """Stream AG-UI events from a Copilot session file.

        Dispatches on the session file: an ``events.jsonl`` is the local
        Copilot CLI format; ``output.log`` is the cloud SWE-agent format.
        """
        if _is_copilot_output_log(session.path):
            yield from self._read_output_log_iter(session)
        else:
            yield from self._read_events_jsonl_iter(session)

    def _read_events_jsonl_iter(self, session: Session) -> Iterator[Event]:
        """Stream AG-UI events from a local Copilot CLI ``events.jsonl``."""
        file_mtime_ms = int(session.modified_at * 1000) if session.modified_at else 0
        ts_tracker = TimestampTracker(file_mtime_ms)

        run_started = False
        run_id: str = session.id

        try:
            with open(session.path) as f:
                for line_index, line in enumerate(f):
                    stripped = line.strip()
                    if not stripped:
                        continue
                    try:
                        entry = json.loads(stripped)
                    except json.JSONDecodeError:
                        continue

                    ts = ts_tracker.parse(entry.get("timestamp", ""))

                    yield CustomEvent(
                        timestamp_ms=ts,
                        name="source_entry",
                        value={
                            "format": "copilot",
                            "entry_type": entry.get("type"),
                            "raw_line": stripped,
                            "index": line_index,
                        },
                    )

                    if entry.get("type") == "session.start" and not run_started:
                        data = entry.get("data") or {}
                        run_id = str(data.get("sessionId") or session.id)
                        yield RunStartedEvent(
                            timestamp_ms=ts,
                            run_id=run_id,
                            thread_id=run_id,
                        )
                        run_started = True

                    yield from self._map_entry(entry, ts)
        except OSError:
            return

        if run_started:
            yield RunFinishedEvent(
                timestamp_ms=ts_tracker.last_valid,
                run_id=run_id,
            )

    def _read_output_log_iter(self, session: Session) -> Iterator[Event]:
        """Stream AG-UI events from a cloud Copilot ``output.log``.

        Calls ``_parse_output_log`` directly rather than routing through
        ``_read_output_log_entries`` — the latter serialises each parsed
        dict to JSON for the upload path, which we'd then have to decode
        right back. There's only one synthesized timestamp (file mtime) —
        ``TimestampTracker`` still gets used so downstream code sees the
        same shape.
        """
        try:
            text = session.path.read_text()
        except OSError:
            return
        file_mtime_ms = int(session.modified_at * 1000) if session.modified_at else 0
        parsed_entries = _parse_output_log(text, file_mtime_ms)
        if not parsed_entries:
            return

        ts_tracker = TimestampTracker(file_mtime_ms)
        run_id = session.id
        ts = ts_tracker.parse(_iso_from_ms(file_mtime_ms))
        yield RunStartedEvent(timestamp_ms=ts, run_id=run_id, thread_id=run_id)

        for index, parsed in enumerate(parsed_entries):
            entry_ts = ts_tracker.parse(parsed.get("timestamp", ""))
            yield CustomEvent(
                timestamp_ms=entry_ts,
                name="source_entry",
                value={
                    "format": "copilot",
                    "entry_type": parsed.get("type"),
                    "raw_line": json.dumps(parsed, ensure_ascii=False, separators=(",", ":")),
                    "index": index,
                },
            )
            yield from self._map_entry(parsed, entry_ts)

        yield RunFinishedEvent(timestamp_ms=ts_tracker.last_valid, run_id=run_id)

    def _map_entry(self, entry: dict, ts: int) -> Iterator[Event]:
        """Map a single Copilot event entry to AG-UI events."""
        etype = entry.get("type")
        data = entry.get("data") or {}

        if etype == "user.message":
            content = data.get("content")
            # Copilot CLI itself injects a synthetic ``<skill-context name="...">``
            # user.message right after a ``skill.invoked`` event — it's the
            # skill scaffolding payload, not something the human typed. We
            # already emit a ``copilot_skill_invoked`` CustomEvent for the
            # skill activation, so dropping this prevents the dashboard from
            # rendering it as its own user turn (and avoids polluting turn
            # titling). The raw line is still preserved via the
            # ``source_entry`` CustomEvent for round-trip fidelity.
            if (
                isinstance(content, str)
                and content
                and not content.lstrip().startswith("<skill-context")
            ):
                yield TextMessageChunkEvent(
                    timestamp_ms=ts,
                    message_id=str(entry.get("id") or f"user-{ts}"),
                    role=Role.USER,
                    delta=content,
                )

        elif etype == "assistant.message":
            msg_id = str(data.get("messageId") or entry.get("id") or f"assistant-{ts}")
            content = data.get("content")
            if isinstance(content, str) and content:
                yield TextMessageChunkEvent(
                    timestamp_ms=ts,
                    message_id=msg_id,
                    role=Role.ASSISTANT,
                    delta=content,
                )
            for tc in data.get("toolRequests") or []:
                if not isinstance(tc, dict):
                    continue
                yield ToolCallChunkEvent(
                    timestamp_ms=ts,
                    tool_call_id=str(tc.get("toolCallId") or ""),
                    tool_call_name=str(tc.get("name") or ""),
                    # Without parent_message_id, group_events() treats these
                    # tool calls as orphaned standalone calls instead of
                    # attaching them to the assistant message that issued
                    # them — same pattern as the Claude adapter.
                    parent_message_id=msg_id,
                    delta=_encode_tool_args(tc.get("arguments")),
                )

        elif etype == "tool.user_requested":
            # User-initiated bang commands (!cmd) materialise as a tool call
            # with no preceding assistant.message, so emit a chunk for parity.
            yield ToolCallChunkEvent(
                timestamp_ms=ts,
                tool_call_id=str(data.get("toolCallId") or ""),
                tool_call_name=str(data.get("toolName") or ""),
                delta=_encode_tool_args(data.get("arguments")),
            )

        elif etype == "tool.execution_complete":
            tool_call_id = str(data.get("toolCallId") or "")
            if not tool_call_id:
                return
            result = data.get("result") or {}
            # Copilot wraps results as {content, detailedContent}; prefer the
            # detailed variant when present so downstream sees the full output.
            if isinstance(result, dict):
                payload = result.get("detailedContent") or result.get("content") or ""
            else:
                payload = str(result)
            yield ToolCallResultEvent(
                timestamp_ms=ts,
                tool_call_id=tool_call_id,
                tool_call_result_id=f"{tool_call_id}-result",
                result=str(payload),
            )

        elif etype == "skill.invoked":
            yield CustomEvent(
                timestamp_ms=ts,
                name="copilot_skill_invoked",
                value={
                    "name": data.get("name"),
                    "path": data.get("path"),
                    "content": data.get("content"),
                },
            )

        elif etype == "subagent.started":
            yield CustomEvent(
                timestamp_ms=ts,
                name="copilot_subagent_started",
                value={
                    "tool_call_id": data.get("toolCallId"),
                    "agent_name": data.get("agentName"),
                    "agent_display_name": data.get("agentDisplayName"),
                    "agent_description": data.get("agentDescription"),
                },
            )

        elif etype == "subagent.completed":
            yield CustomEvent(
                timestamp_ms=ts,
                name="copilot_subagent_completed",
                value={
                    "tool_call_id": data.get("toolCallId"),
                    "agent_name": data.get("agentName"),
                },
            )

        # session.start, session.model_change, session.info, hook.start,
        # hook.end, tool.execution_start, assistant.turn_start,
        # assistant.turn_end are intentionally not mapped — they're either
        # already handled (session.start) or pure framing/telemetry that the
        # source_entry CustomEvent already preserves losslessly.
        #
        # system.message is also intentionally dropped: Copilot CLI emits its
        # full system prompt as a system.message at the start of every turn,
        # which previously rendered as an assistant message in the dashboard
        # (the dashboard's role-extraction maps anything that isn't ``user``
        # to ``assistant_message``). Other adapters either don't surface the
        # system prompt at all or capture it as a CustomEvent — Copilot's
        # is static boilerplate so we drop the AG-UI emission entirely. The
        # raw line is still preserved in the ``source_entry`` CustomEvent
        # for round-trip fidelity.

    # === parse_source_entry (called by server-side processing.py) ===

    def parse_source_entry(
        self,
        entry: dict,
        entry_index: int,
        session_id: str,
    ) -> list[Event]:
        """Parse a single source entry into AG-UI events.

        This mirrors :meth:`read_events` but for a single entry, used by the
        normalization worker. Timestamps fall back to ``_timestamp_ms``
        injected by ``processing.py`` (never ``datetime.now()``).
        """
        events: list[Event] = []

        if entry.get("type") == "daemon_metadata":
            return events

        fallback_ts = entry.get("_timestamp_ms", 0)
        ts = parse_timestamp_with_fallback(entry.get("timestamp"), fallback_ts)

        # Emit RunStartedEvent for session.start so summary computation has a
        # well-defined run boundary.
        if entry.get("type") == "session.start":
            data = entry.get("data") or {}
            run_id = str(data.get("sessionId") or session_id)
            events.append(
                RunStartedEvent(
                    timestamp_ms=ts,
                    run_id=run_id,
                    thread_id=run_id,
                )
            )

        events.extend(self._map_entry(entry, ts))

        for event in events:
            if not hasattr(event, "_source"):
                event._source = {}  # type: ignore[attr-defined]
            event._source["entry_index"] = entry_index  # type: ignore[attr-defined, index]

        return events

    # === Round-trip writing ===

    def write_events(self, events: Iterable[Event], dest: IO[str]) -> None:
        """Write AG-UI events back as Copilot ``events.jsonl``.

        Same-format round-trip is lossless via the captured raw lines. We do
        not currently support cross-format reconstruction back into
        Copilot's schema (it would mean fabricating ids, parentIds, and
        encrypted reasoning blobs that Copilot generates server-side).
        """
        events_list = list(events)
        source_entries = [
            e.value
            for e in events_list
            if isinstance(e, CustomEvent)
            and e.name == "source_entry"
            and isinstance(e.value, dict)
            and e.value.get("format") == self.name
        ]
        for entry in sorted(source_entries, key=lambda e: int(e.get("index", 0))):
            raw_line = str(entry.get("raw_line", ""))
            if raw_line:
                dest.write(raw_line + "\n")
