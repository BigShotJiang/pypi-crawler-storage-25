"""Adapters for transforming between event formats.

Adapters are automatically registered when this module is imported.
"""

from __future__ import annotations

from pathlib import Path

from .base import Adapter, Session
from .claude import ClaudeAdapter
from .claude_web import ClaudeWebAdapter
from .codex import CodexAdapter
from .copilot import CopilotAdapter
from .cursor import (
    CursorAdapter,
    compute_synthetic_timestamps,
    entries_lack_bubble_timestamps,
    parse_cursor_timestamp,
)
from .gemini import GeminiAdapter
from .opencode import OpenCodeAdapter

_adapters: dict[str, Adapter] = {}


def register_adapter(adapter: Adapter) -> None:
    """Register an adapter instance."""
    _adapters[adapter.name] = adapter


def get_adapter(name: str) -> Adapter | None:
    """Get adapter by agent name."""
    return _adapters.get(name)


def get_adapter_for_path(path: Path) -> Adapter | None:
    """Get adapter that matches the given path."""
    for adapter in _adapters.values():
        if adapter.matches_path(path):
            return adapter
    return None


def get_all_adapters() -> list[Adapter]:
    """Get all registered adapters."""
    return list(_adapters.values())


def get_all_watch_paths() -> list[Path]:
    """Get all base directories from all registered adapters."""
    paths = []
    for adapter in _adapters.values():
        paths.extend(adapter.get_base_directories())
    return [p for p in paths if p.exists()]


def extract_sessions_from_path(path: Path) -> list[dict]:
    """Extract session info from a file using the appropriate adapter.

    Finds the adapter that matches the path and uses it to extract
    session information. For JSONL-based agents, returns a single session
    with the filename stem as ID. For Cursor, returns multiple composer
    sessions from the SQLite database.

    Args:
        path: Path to the session file.

    Returns:
        List of session dicts with keys: id, path, format, metadata (optional)
    """
    adapter = get_adapter_for_path(path)
    if not adapter:
        return []
    return adapter.extract_sessions_from_file(path)


# ---------------------------------------------------------------------------
# Auto-register all adapters when module is imported
# ---------------------------------------------------------------------------

register_adapter(ClaudeAdapter())
register_adapter(ClaudeWebAdapter())
register_adapter(CodexAdapter())
register_adapter(CopilotAdapter())
register_adapter(CursorAdapter())
register_adapter(GeminiAdapter())
register_adapter(OpenCodeAdapter())


__all__ = [
    "Adapter",
    "Session",
    "ClaudeAdapter",
    "ClaudeWebAdapter",
    "CodexAdapter",
    "CopilotAdapter",
    "CursorAdapter",
    "GeminiAdapter",
    "OpenCodeAdapter",
    "register_adapter",
    "get_adapter",
    "get_adapter_for_path",
    "get_all_adapters",
    "get_all_watch_paths",
    "extract_sessions_from_path",
    "compute_synthetic_timestamps",
    "entries_lack_bubble_timestamps",
    "parse_cursor_timestamp",
]
