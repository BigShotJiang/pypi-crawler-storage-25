"""Cursor adapter for reading session logs from Cursor's VSCode-based storage."""

from __future__ import annotations

import base64
import difflib
import json
import logging
import mimetypes
import sqlite3
import sys
import uuid
from collections.abc import Iterable, Iterator
from dataclasses import dataclass
from pathlib import Path
from typing import IO, Any
from urllib.parse import unquote, urlparse

from agentstream.analytics import normalize_path
from agentstream.events import (
    CustomEvent,
    Event,
    ReasoningMessageChunkEvent,
    Role,
    RunFinishedEvent,
    RunStartedEvent,
    TextMessageChunkEvent,
    ToolCallChunkEvent,
    ToolCallResultEvent,
)

from .base import Adapter, Session
from .timestamps import TimestampTracker

logger = logging.getLogger(__name__)


def _resolve_cursor_images(bubble: dict[str, Any]) -> list[str]:
    """Resolve selectedImages file paths to base64 data URLs.

    Cursor stores user-pasted images as local file paths in
    ``bubble["context"]["selectedImages"]``.  This helper reads each file,
    base64-encodes it, and returns a list of ``data:`` URL strings that the
    backend image extraction pipeline already knows how to handle.
    """
    selected = bubble.get("context", {}).get("selectedImages", [])
    if not selected:
        return []

    resolved: list[str] = []
    for entry in selected:
        if not isinstance(entry, dict):
            continue
        path_str = entry.get("path")
        if not path_str:
            continue
        p = Path(path_str)
        if not p.is_file():
            logger.debug("Cursor selectedImage not found: %s", path_str)
            continue
        try:
            raw = p.read_bytes()
        except OSError:
            logger.debug("Failed to read Cursor selectedImage: %s", path_str)
            continue
        # Skip images larger than 10 MB to avoid memory spikes
        if len(raw) > 10 * 1024 * 1024:
            logger.debug("Cursor selectedImage too large (%d bytes): %s", len(raw), path_str)
            continue
        mime_type, _ = mimetypes.guess_type(path_str)
        if not mime_type or not mime_type.startswith("image/"):
            mime_type = "image/png"
        encoded = base64.b64encode(raw).decode("ascii")
        resolved.append(f"data:{mime_type};base64,{encoded}")
    return resolved


# Tool names that perform file operations (Cursor conventions)
_FILE_READ_TOOLS = frozenset({"read_file", "read_file_v2", "view_file", "get_file_contents"})
_FILE_WRITE_TOOLS = frozenset({"write_file", "create_file", "save_file"})
_FILE_EDIT_TOOLS = frozenset(
    {
        "edit_file",
        "edit_file_v2",
        "apply_edit",
        "replace_in_file",
        "str_replace_editor",
        "search_replace",
        "reapply",
    }
)
_FILE_DELETE_TOOLS = frozenset({"delete_file", "remove_file"})
_FILE_LIST_TOOLS = frozenset({"list_files", "list_dir", "get_directory_tree", "glob_file_search"})
_FILE_SEARCH_TOOLS = frozenset(
    {
        "search_files",
        "grep",
        "grep_search",
        "codebase_search",
        "file_search",
        "ripgrep_raw_search",
        "semantic_search_full",
    }
)


def parse_cursor_timestamp(ts: int | float | str | None) -> int | None:
    """Parse a Cursor timestamp to milliseconds.

    Cursor stores timestamps in various formats:
    - Milliseconds since epoch (int/float)
    - ISO 8601 strings (e.g., "2026-01-11T19:49:31.405Z")

    Args:
        ts: Timestamp value (can be int, float, or ISO string)

    Returns:
        Timestamp in milliseconds, or None if parsing fails.
    """
    if ts is None:
        return None

    # Handle ISO 8601 strings (e.g., "2026-01-11T19:49:31.405Z")
    if isinstance(ts, str):
        try:
            from datetime import datetime  # noqa: PLC0415

            # Parse ISO format - handle both Z suffix and +00:00
            ts_str = ts.replace("Z", "+00:00")
            dt = datetime.fromisoformat(ts_str)
            return int(dt.timestamp() * 1000)
        except (ValueError, TypeError):
            pass
        # Try parsing as numeric string
        try:
            ts = float(ts)
        except (ValueError, TypeError):
            return None

    try:
        ts_int = int(ts)
        # Sanity check: if it looks like seconds (< 1e12), convert to ms
        if ts_int < 1e12:
            ts_int = ts_int * 1000
        return ts_int
    except (ValueError, TypeError):
        return None


def _parse_ms_timestamp(ts: int | float | str | None, fallback: int) -> int:
    """Parse a millisecond timestamp value, with fallback.

    Wrapper around parse_cursor_timestamp that returns a fallback value
    instead of None when parsing fails.

    Args:
        ts: Timestamp value (can be int, float, or ISO string)
        fallback: Fallback value if parsing fails

    Returns:
        Timestamp in milliseconds.
    """
    result = parse_cursor_timestamp(ts)
    return result if result is not None else fallback


def entries_lack_bubble_timestamps(source_entries: list[dict]) -> bool:
    """Check if all source entries lack individual bubble-level timestamps.

    Cursor v2 bubbles have no createdAt field. This checks by parsing entry
    content and looking for createdAt or timestamp fields.

    Args:
        source_entries: List of source entry dicts with entry_content

    Returns:
        True if no entries have bubble-level timestamps
    """
    for entry in source_entries:
        try:
            data = json.loads(entry.get("entry_content", "{}"))
        except (json.JSONDecodeError, TypeError):
            continue
        if data.get("createdAt") or data.get("timestamp"):
            return False
    return True


def compute_synthetic_timestamps(
    metadata: dict,
    source_entries: list[dict],
) -> list[int] | None:
    """Compute synthetic timestamps for Cursor entries without individual createdAt.

    Instead of spreading timestamps evenly (which produces absurd durations when
    lastUpdatedAt is days after createdAt), assigns realistic durations based on
    bubble type, derived from median timings observed in real Claude sessions:

        - User bubble (type 1): 5s (just submission overhead; idle time between
          turns is excluded by the active_duration calculator anyway)
        - Assistant bubble (type 2): 15s (model thinking + generating)

    Timestamps are anchored at session createdAt and advance by the per-bubble
    duration, capped so the total never exceeds the actual session window.

    Args:
        metadata: Daemon metadata with optional createdAt/lastUpdatedAt
        source_entries: The actual source entry dicts (used to read bubble type)

    Returns:
        List of synthetic timestamps in ms, or None if can't compute
    """
    if not source_entries:
        return None

    session_start = parse_cursor_timestamp(metadata.get("createdAt"))
    session_end = parse_cursor_timestamp(metadata.get("lastUpdatedAt"))

    if not session_start or not session_end:
        return None

    if session_start > session_end:
        session_start, session_end = session_end, session_start

    max_duration = session_end - session_start

    # Per-bubble durations in ms, based on real session timing data
    DURATION_USER_MS = 5_000  # User prompt submission
    DURATION_ASSISTANT_MS = 30_000  # Model response generation

    # Compute raw timestamps from bubble types
    timestamps = []
    cursor = session_start
    for entry in source_entries:
        timestamps.append(int(cursor))
        try:
            data = json.loads(entry.get("entry_content", "{}"))
            bubble_type = data.get("type", 2)
        except (json.JSONDecodeError, TypeError):
            bubble_type = 2

        if bubble_type == 1:
            cursor += DURATION_USER_MS
        else:
            cursor += DURATION_ASSISTANT_MS

    # If our synthetic duration exceeds the actual session window, scale down
    # proportionally so timestamps stay within [createdAt, lastUpdatedAt]
    synthetic_duration = cursor - session_start
    if synthetic_duration > max_duration and synthetic_duration > 0 and len(timestamps) > 1:
        scale = max_duration / synthetic_duration
        timestamps = [int(session_start + (ts - session_start) * scale) for ts in timestamps]

    return timestamps


def _get_cursor_user_dir() -> Path:
    """Get platform-specific Cursor user data directory.

    Returns:
        Path to Cursor's User directory where storage is located.
    """
    if sys.platform == "darwin":
        # macOS: ~/Library/Application Support/Cursor/User/
        return Path.home() / "Library" / "Application Support" / "Cursor" / "User"
    elif sys.platform == "win32":
        # Windows: %APPDATA%/Cursor/User/
        appdata = Path.home() / "AppData" / "Roaming"
        return appdata / "Cursor" / "User"
    else:
        # Linux: ~/.config/Cursor/User/
        return Path.home() / ".config" / "Cursor" / "User"


def _uri_to_path(file_uri: str) -> Path | None:
    """Convert file:// URI to Path.

    Args:
        file_uri: A file URI like "file:///Users/foo/bar"

    Returns:
        Path object, or None if not a valid file URI.
    """
    if not file_uri.startswith("file://"):
        return None
    parsed = urlparse(file_uri)
    # URL decode the path (handles %20 -> space, etc.)
    decoded_path = unquote(parsed.path)
    return Path(decoded_path)


@dataclass(frozen=True)
class ComposerInfo:
    """Normalized view of a Cursor composer session, regardless of storage schema.

    Returned by :func:`load_composers`. Callers translate this into their own
    shapes (discovery dicts, Session objects, daemon hot-tracker tuples).
    """

    composer_id: str
    workspace_id: str | None  # workspaceStorage subdir name; None for "empty-window"
    workspace_vscdb_path: Path | None  # cursor_user/workspaceStorage/<id>/state.vscdb
    fs_path: str | None  # project cwd (absolute filesystem path)
    created_at: int | None  # ms since epoch
    last_updated_at: int | None  # ms since epoch
    name: str | None
    model: str | None  # defaultModel/model from composer record, if present
    source: str  # "headers" (new schema) or "workspace" (deprecated fallback)


_fallback_warned = False  # module-level: log fallback path at most once per process


def _read_composer_headers(global_state_db: Path) -> list[ComposerInfo]:
    """Read composers from globalStorage ItemTable['composer.composerHeaders'].

    This is Cursor's post-migration authoritative index. Each entry includes
    workspaceIdentifier with uri.fsPath pointing at the project cwd.
    """
    if not global_state_db.exists():
        return []

    cursor_user = global_state_db.parent.parent  # globalStorage -> User

    try:
        conn = sqlite3.connect(f"file:{global_state_db}?mode=ro", uri=True, timeout=10)
        conn.row_factory = sqlite3.Row
        try:
            row = conn.execute(
                "SELECT value FROM ItemTable WHERE key = ?",
                ("composer.composerHeaders",),
            ).fetchone()
        finally:
            conn.close()
    except sqlite3.Error as e:
        logger.debug(f"Error reading composer.composerHeaders: {e}")
        return []

    if not row:
        return []

    try:
        value = row["value"]
        if isinstance(value, bytes):
            value = value.decode("utf-8", errors="replace")
        payload = json.loads(value)
    except (json.JSONDecodeError, UnicodeDecodeError, TypeError) as e:
        logger.debug(f"Failed to parse composer.composerHeaders: {e}")
        return []

    all_composers = payload.get("allComposers") if isinstance(payload, dict) else None
    if not isinstance(all_composers, list):
        return []

    infos: list[ComposerInfo] = []
    for composer in all_composers:
        if not isinstance(composer, dict):
            continue
        composer_id = composer.get("composerId")
        if not composer_id:
            continue

        ws_ident = composer.get("workspaceIdentifier") or {}
        workspace_id = ws_ident.get("id") if isinstance(ws_ident, dict) else None
        # fsPath is the most reliable cwd; fall back to parsing uri.external.
        fs_path: str | None = None
        uri = ws_ident.get("uri") if isinstance(ws_ident, dict) else None
        if isinstance(uri, dict):
            fs_path = uri.get("fsPath") or None
            if not fs_path:
                external = uri.get("external") or uri.get("path")
                if external:
                    parsed = (
                        _uri_to_path(str(external))
                        if "://" in str(external)
                        else Path(str(external))
                    )
                    if parsed is not None:
                        fs_path = str(parsed)

        workspace_vscdb_path: Path | None = None
        if workspace_id and workspace_id != "empty-window":
            workspace_vscdb_path = cursor_user / "workspaceStorage" / workspace_id / "state.vscdb"

        infos.append(
            ComposerInfo(
                composer_id=str(composer_id),
                workspace_id=workspace_id if isinstance(workspace_id, str) else None,
                workspace_vscdb_path=workspace_vscdb_path,
                fs_path=fs_path,
                created_at=_as_int(composer.get("createdAt")),
                last_updated_at=_as_int(composer.get("lastUpdatedAt")),
                name=composer.get("name") if isinstance(composer.get("name"), str) else None,
                model=composer.get("defaultModel") or composer.get("model"),
                source="headers",
            )
        )

    return infos


def _as_int(val: Any) -> int | None:
    """Coerce a JSON timestamp field to int milliseconds, tolerating floats and strings.

    Cursor stores timestamps as millisecond values ≥ 1e12. Legacy records
    sometimes carry seconds (< 1e12); these are normalized to milliseconds so
    callers always see a consistent unit.
    """
    if val is None:
        return None
    if isinstance(val, bool):
        return None
    if isinstance(val, (int, float)):
        n = int(val)
    elif isinstance(val, str):
        try:
            n = int(float(val))
        except ValueError:
            return None
    else:
        return None
    # Legacy rows may express time in seconds; normalize to ms.
    if 0 < n < 1_000_000_000_000:
        n *= 1000
    return n


def _read_workspace_composers(workspace_storage: Path) -> list[ComposerInfo]:
    """Read composers from per-workspace ItemTable['composer.composerData'].

    This is the deprecated pre-migration path. Only the
    ``{"allComposers": [...]}`` shape is supported; the bare-list form is no
    longer accepted.
    """
    if not workspace_storage.exists():
        return []

    infos: list[ComposerInfo] = []

    for workspace_dir in workspace_storage.iterdir():
        if not workspace_dir.is_dir():
            continue

        state_db = workspace_dir / "state.vscdb"
        if not state_db.exists():
            continue

        # fs_path from workspace.json (optional)
        fs_path: str | None = None
        workspace_json = workspace_dir / "workspace.json"
        if workspace_json.is_file():
            try:
                folder_uri = json.loads(workspace_json.read_text()).get("folder", "")
                parsed = _uri_to_path(folder_uri) if isinstance(folder_uri, str) else None
                if parsed is not None:
                    fs_path = str(parsed)
            except (json.JSONDecodeError, OSError):
                pass

        try:
            conn = sqlite3.connect(f"file:{state_db}?mode=ro", uri=True, timeout=10)
            conn.row_factory = sqlite3.Row
            try:
                row = conn.execute(
                    "SELECT value FROM ItemTable WHERE key = ?",
                    ("composer.composerData",),
                ).fetchone()
            finally:
                conn.close()
        except sqlite3.Error as e:
            logger.debug(f"Error reading workspace {workspace_dir.name}: {e}")
            continue

        if not row:
            continue

        try:
            value = row["value"]
            if isinstance(value, bytes):
                value = value.decode("utf-8", errors="replace")
            payload = json.loads(value)
        except (json.JSONDecodeError, UnicodeDecodeError, TypeError) as e:
            logger.debug(f"Failed to parse composer.composerData in {workspace_dir.name}: {e}")
            continue

        # Only accept dict-with-allComposers. Bare-list form is no longer supported.
        if not isinstance(payload, dict):
            continue
        all_composers = payload.get("allComposers")
        if not isinstance(all_composers, list):
            continue

        for composer in all_composers:
            if not isinstance(composer, dict):
                continue
            composer_id = composer.get("composerId")
            if not composer_id:
                continue

            infos.append(
                ComposerInfo(
                    composer_id=str(composer_id),
                    workspace_id=workspace_dir.name,
                    workspace_vscdb_path=state_db,
                    fs_path=fs_path,
                    created_at=_as_int(composer.get("createdAt")),
                    last_updated_at=_as_int(composer.get("lastUpdatedAt")),
                    name=composer.get("name") if isinstance(composer.get("name"), str) else None,
                    model=composer.get("defaultModel") or composer.get("model"),
                    source="workspace",
                )
            )

    return infos


def load_composers(
    cursor_user: Path,
    target_ids: set[str] | None = None,
) -> list[ComposerInfo]:
    """Enumerate Cursor composer sessions for a given Cursor User directory.

    Primary source (new schema, latest Cursor):
        ``globalStorage/state.vscdb`` → ``ItemTable['composer.composerHeaders']`` →
        ``{"allComposers": [...]}``. Each entry carries
        ``workspaceIdentifier.{id, uri.fsPath}``.

    Fallback (deprecated — for pre-migration Cursor builds):
        ``workspaceStorage/<ws>/state.vscdb`` →
        ``ItemTable['composer.composerData']`` → ``{"allComposers": [...]}``.
        Uses ``workspace.json`` for the fs path. The bare-JSON-list shape of
        ``composer.composerData`` is no longer supported.

    Results from the two sources are merged; primary (headers) wins on
    ``composer_id`` collisions. When the fallback path yields any composers,
    a one-time INFO log fires so operators can see that legacy Cursor
    installations still exist in the wild.

    Args:
        cursor_user: Path to Cursor's User directory.
        target_ids: Optional filter. When provided, the returned list is
            restricted to composers in this set, and — crucially — the
            per-workspace fallback scan is skipped entirely if the primary
            headers index already covers all requested IDs. This short-circuit
            matters for the daemon's live-sync hot path, which calls this on
            every globalStorage change and would otherwise re-scan every
            workspace DB each cycle.
    """
    global _fallback_warned

    global_state_db = cursor_user / "globalStorage" / "state.vscdb"
    workspace_storage = cursor_user / "workspaceStorage"

    primary = _read_composer_headers(global_state_db)

    # Hot-path short-circuit: when the caller names specific composer IDs and
    # they're all present in the (post-migration) headers index, skip the
    # potentially-expensive per-workspace scan.
    if target_ids is not None:
        primary_ids = {c.composer_id for c in primary}
        if target_ids.issubset(primary_ids):
            return [c for c in primary if c.composer_id in target_ids]

    fallback = _read_workspace_composers(workspace_storage)

    if fallback and not _fallback_warned:
        _fallback_warned = True
        logger.info(
            "Cursor composer discovery fell back to per-workspace "
            "composer.composerData (pre-migration Cursor schema). "
            "This path is deprecated."
        )

    known: dict[str, ComposerInfo] = {c.composer_id: c for c in primary}
    for info in fallback:
        known.setdefault(info.composer_id, info)

    if target_ids is not None:
        return [c for c in known.values() if c.composer_id in target_ids]
    return list(known.values())


class CursorAdapter(Adapter):
    """Adapter for Cursor IDE session logs.

    Cursor stores session data in VSCode-style SQLite databases:
    - Workspace state: workspaceStorage/<hash>/state.vscdb
    - Global state: globalStorage/state.vscdb

    Composer sessions are enumerated via :func:`load_composers`, which
    reads the new ``composer.composerHeaders`` entry from globalStorage
    (preferred) and falls back to per-workspace ``composer.composerData``
    for pre-migration Cursor installations. Individual bubble messages
    are stored in global state's ``cursorDiskKV`` table with keys like
    ``bubbleId:<composerId>:<bubbleId>``.
    """

    @property
    def name(self) -> str:
        return "cursor"

    # === Path Detection (for daemon watcher) ===

    def get_base_directories(self) -> list[Path]:
        """Return Cursor storage directories to watch.

        - workspaceStorage: composer metadata (allComposers); used to discover sessions.
        - globalStorage: bubble/message data (cursorDiskKV); updates on every turn.
        We must watch both so incremental sync runs when new messages are written.
        """
        cursor_user = _get_cursor_user_dir()
        return [cursor_user / "workspaceStorage", cursor_user / "globalStorage"]

    def matches_path(self, path: Path) -> bool:
        """Return True if path is a Cursor state file."""
        # Cursor sessions are in workspaceStorage/*/state.vscdb
        # Use Path.parts for cross-platform compatibility
        return "Cursor" in path.parts and path.suffix == ".vscdb"

    def extract_sessions_from_file(self, path: Path) -> list[dict]:
        """Extract composer sessions relevant to a changed Cursor .vscdb file.

        The daemon's file watcher special-cases globalStorage/state.vscdb (see
        daemon/src/hivemind/cli.py) so this method is effectively invoked for
        workspaceStorage/<ws>/state.vscdb changes. We enumerate all composers
        via :func:`load_composers` and filter to the changed workspace.
        """
        # Derive cursor_user from the .vscdb path. Supports both
        # workspaceStorage/<ws>/state.vscdb (cursor_user = path.parent.parent.parent)
        # and globalStorage/state.vscdb (cursor_user = path.parent.parent).
        parts = path.parts
        cursor_user: Path | None = None
        filter_workspace_id: str | None = None
        if "workspaceStorage" in parts:
            idx = parts.index("workspaceStorage")
            cursor_user = Path(*parts[:idx])
            if idx + 1 < len(parts) - 1:  # has subdir between "workspaceStorage" and filename
                filter_workspace_id = parts[idx + 1]
        elif "globalStorage" in parts:
            idx = parts.index("globalStorage")
            cursor_user = Path(*parts[:idx])
        else:
            return []

        if cursor_user is None:
            return []

        infos = load_composers(cursor_user)
        if filter_workspace_id is not None:
            infos = [i for i in infos if i.workspace_id == filter_workspace_id]

        sessions: list[dict] = []
        for info in infos:
            workspace_dir = (
                info.workspace_vscdb_path.parent
                if info.workspace_vscdb_path is not None
                else cursor_user / "workspaceStorage" / (info.workspace_id or "empty-window")
            )
            metadata: dict[str, Any] = {
                "composerId": info.composer_id,
                "workspace_dir": str(workspace_dir),
                "cursor_user": str(cursor_user),
                "folder_path": info.fs_path,
            }
            if info.created_at is not None:
                metadata["createdAt"] = info.created_at
            if info.last_updated_at is not None:
                metadata["lastUpdatedAt"] = info.last_updated_at

            sessions.append(
                {
                    "id": info.composer_id,
                    "path": info.workspace_vscdb_path or path,
                    "format": self.name,
                    "metadata": metadata,
                }
            )
        return sessions

    # === Raw Entry Reading (for incremental sync) ===

    def read_entries(self, session: Session) -> list[dict]:
        """Read all raw source entries from a Cursor session.

        Fetches bubble entries from the global state database.

        Returns:
            List of entry dicts with: entry_index, entry_content, entry_timestamp_ms
        """
        entries = []

        if not session.metadata:
            return entries

        composer_id = session.metadata.get("composerId", session.id)
        cursor_user_str = session.metadata.get("cursor_user")
        if not cursor_user_str:
            return entries

        cursor_user = Path(cursor_user_str)
        global_state_db = cursor_user / "globalStorage" / "state.vscdb"

        if not global_state_db.exists():
            return entries

        # Fetch bubbles using existing helper
        bubbles = self._fetch_bubbles(global_state_db, composer_id)

        # Sort bubbles by createdAt for chronological ordering.
        # This is critical for incremental sync: last_entry_idx tracks chronological
        # position, so new bubbles must have higher indices than previously synced ones.
        # Using bubbleId (random UUID) would cause new bubbles to get arbitrary indices,
        # breaking incremental sync.
        bubbles.sort(key=lambda b: b.get("createdAt", "") or "")

        # Check if bubbles have individual timestamps
        bubbles_have_timestamps = any(
            bubble.get("createdAt") or bubble.get("timestamp") for bubble in bubbles
        )

        # Convert to entry format (timestamps assigned below)
        for i, bubble in enumerate(bubbles):
            timestamp_ms = _parse_ms_timestamp(
                bubble.get("createdAt") or bubble.get("timestamp"),
                int(session.modified_at * 1000),
            )
            entries.append(
                {
                    "entry_index": i,
                    "entry_content": json.dumps(bubble),
                    "entry_timestamp_ms": timestamp_ms,
                }
            )

        # If bubbles don't have timestamps, try to synthesize from session metadata
        # This provides reasonable duration estimates for older Cursor sessions
        if not bubbles_have_timestamps and len(bubbles) > 1:
            synthetic_timestamps = compute_synthetic_timestamps(session.metadata, entries)
            if synthetic_timestamps:
                for i, entry in enumerate(entries):
                    entry["entry_timestamp_ms"] = synthetic_timestamps[i]

        return entries

    def read_entries_after(self, session: Session, after_index: int = -1) -> list[dict]:
        """Read entries after given index.

        For Cursor, we still need to read all bubbles since they're in SQLite,
        but we filter the results.
        """
        entries = self.read_entries(session)
        return [e for e in entries if e["entry_index"] > after_index]

    # === Entry Enrichment (for daemon sync) ===

    def enrich_entries(self, entries: list[dict], session: Session) -> list[dict]:
        """Enrich entries by resolving content IDs and computing diffs.

        For edit_file_v2 tool calls with afterContentId (and optionally
        beforeContentId), resolves the content from Cursor's globalStorage
        and computes a unified diff. The diff is added as _computed_diff.

        Handles both:
        - File modifications: beforeContentId + afterContentId
        - File creations: only afterContentId (treats as empty -> content)

        Args:
            entries: List of entry dicts from read_entries()
            session: Session with metadata (needs cursor_user path)

        Returns:
            Enriched entries with _computed_diff added where applicable
        """
        if not entries or not session.metadata:
            return entries

        cursor_user_str = session.metadata.get("cursor_user")
        if not cursor_user_str:
            return entries

        cursor_user = Path(cursor_user_str)
        global_state_db = cursor_user / "globalStorage" / "state.vscdb"

        if not global_state_db.exists():
            return entries

        # Collect all content IDs that need resolution
        content_ids_to_resolve: set[str] = set()
        entries_needing_enrichment: list[tuple[int, dict]] = []

        for i, entry in enumerate(entries):
            try:
                entry_content = json.loads(entry["entry_content"])
            except (json.JSONDecodeError, KeyError):
                continue

            tool_data = entry_content.get("toolFormerData", {})
            if not isinstance(tool_data, dict):
                continue

            # result can be a dict or a JSON string - parse if needed
            result = tool_data.get("result", {})
            if isinstance(result, str):
                try:
                    result = json.loads(result)
                except json.JSONDecodeError:
                    continue
            if not isinstance(result, dict):
                continue

            before_id = result.get("beforeContentId")
            after_id = result.get("afterContentId")

            # Need at least afterContentId to compute a diff
            # beforeContentId is optional (missing = new file creation)
            if after_id:
                if before_id:
                    content_ids_to_resolve.add(before_id)
                content_ids_to_resolve.add(after_id)
                entries_needing_enrichment.append((i, entry_content))

        if not content_ids_to_resolve:
            return entries

        # Resolve content IDs from database
        resolved_content = self._resolve_content_ids(global_state_db, content_ids_to_resolve)

        if not resolved_content:
            return entries

        # Enrich entries with computed diffs
        for i, entry_content in entries_needing_enrichment:
            tool_data = entry_content.get("toolFormerData", {})

            # result can be a dict or a JSON string - parse if needed
            raw_result = tool_data.get("result", {})
            result_was_string = isinstance(raw_result, str)
            if result_was_string:
                try:
                    result = json.loads(raw_result)
                except json.JSONDecodeError:
                    continue
            else:
                result = raw_result

            if not isinstance(result, dict):
                continue

            before_id = result.get("beforeContentId")
            after_id = result.get("afterContentId")

            # Get content - use empty string for missing beforeContentId (file creation)
            before_content = resolved_content.get(before_id, "") if before_id else ""
            after_content = resolved_content.get(after_id)

            if after_content is not None:
                # Compute diff (before_content may be empty for new files)
                diff = self._compute_diff_hunks(before_content, after_content)
                if diff:
                    result["_computed_diff"] = diff
                    # If result was originally a string, serialize it back
                    if result_was_string:
                        tool_data["result"] = json.dumps(result)
                    # Update the entry_content JSON
                    entries[i]["entry_content"] = json.dumps(entry_content)

        return entries

    def _resolve_content_ids(self, global_state_db: Path, content_ids: set[str]) -> dict[str, str]:
        """Resolve content IDs to their actual content from cursorDiskKV.

        Cursor stores file content in keys like "composer.content.<hash>".
        These are referenced by beforeContentId/afterContentId in tool results.

        Args:
            global_state_db: Path to globalStorage/state.vscdb
            content_ids: Set of content IDs to resolve

        Returns:
            Dict mapping content ID to resolved content string
        """
        resolved: dict[str, str] = {}

        if not content_ids:
            return resolved

        try:
            conn = sqlite3.connect(f"file:{global_state_db}?mode=ro", uri=True, timeout=10)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()

            # Build query with placeholders for all content IDs
            placeholders = ",".join("?" for _ in content_ids)
            query = f"SELECT key, value FROM cursorDiskKV WHERE key IN ({placeholders})"

            cursor.execute(query, list(content_ids))
            for row in cursor.fetchall():
                key = row["key"]
                value = row["value"]
                if value:
                    # Content is stored as raw text, not JSON
                    resolved[key] = value

            conn.close()

        except sqlite3.Error:
            # Database errors are expected if globalStorage is locked or corrupted;
            # return partial results (or empty dict) rather than failing the sync
            pass

        return resolved

    def _compute_diff_hunks(self, old_content: str, new_content: str) -> dict[str, Any] | None:
        """Compute unified diff hunks from old and new content.

        Returns a JSON-serializable dict that can be stored in source entries.

        Args:
            old_content: Original file content
            new_content: New file content

        Returns:
            Dict with 'hunks' list, or None if no changes
        """
        old_lines = old_content.splitlines(keepends=True)
        new_lines = new_content.splitlines(keepends=True)

        # Use difflib to compute unified diff
        diff_lines = list(
            difflib.unified_diff(
                old_lines,
                new_lines,
                lineterm="",
                n=3,  # 3 lines of context
            )
        )

        if len(diff_lines) < 3:
            # No actual changes (just headers or empty)
            return None

        # Parse unified diff into hunks
        hunks: list[dict[str, Any]] = []
        current_hunk: dict[str, Any] | None = None

        for line in diff_lines[2:]:  # Skip --- and +++ headers
            if line.startswith("@@"):
                # Parse hunk header: @@ -old_start,old_count +new_start,new_count @@
                if current_hunk:
                    hunks.append(current_hunk)

                # Extract line numbers from header
                parts = line.split()
                if len(parts) < 3:
                    # Malformed hunk header; skip starting a new hunk
                    continue
                old_range = parts[1][1:]  # Remove leading -
                new_range = parts[2][1:]  # Remove leading +

                old_start, old_count = self._parse_range(old_range)
                new_start, new_count = self._parse_range(new_range)

                current_hunk = {
                    "old_start": old_start,
                    "old_count": old_count,
                    "new_start": new_start,
                    "new_count": new_count,
                    "lines": [],
                }
            elif current_hunk is not None:
                # Strip trailing newline for cleaner storage
                current_hunk["lines"].append(line.rstrip("\n\r"))

        if current_hunk:
            hunks.append(current_hunk)

        if not hunks:
            return None

        return {"hunks": hunks}

    @staticmethod
    def _parse_range(range_str: str) -> tuple[int, int]:
        """Parse a diff range like '1,5' or '1' into (start, count)."""
        try:
            if "," in range_str:
                parts = range_str.split(",", 1)
                start = int(parts[0])
                count = int(parts[1]) if len(parts) > 1 and parts[1] else 0
                return start, count
            else:
                return int(range_str), 1
        except ValueError:
            # Malformed range; return safe defaults
            return 0, 0

    # === Session Discovery ===

    def discover_sessions(self, project_dir: Path) -> list[Session]:
        """Find Cursor sessions for this project.

        Scans workspaceStorage directories to find workspaces matching
        the project directory, then extracts composer sessions from each.
        """
        cursor_user = _get_cursor_user_dir()
        project_resolved = project_dir.resolve()

        sessions: list[Session] = []
        for info in load_composers(cursor_user):
            if not info.fs_path:
                continue
            try:
                composer_resolved = Path(info.fs_path).resolve()
            except OSError:
                continue
            if not self._is_subpath(composer_resolved, project_resolved):
                continue

            workspace_dir = (
                info.workspace_vscdb_path.parent
                if info.workspace_vscdb_path is not None
                else cursor_user / "workspaceStorage" / (info.workspace_id or "empty-window")
            )
            state_db = info.workspace_vscdb_path or (workspace_dir / "state.vscdb")

            # modified_at: prefer lastUpdatedAt (ms) or createdAt (ms), else state_db mtime
            if info.last_updated_at is not None:
                modified_at: float = info.last_updated_at / 1000.0
            elif info.created_at is not None:
                modified_at = info.created_at / 1000.0
            else:
                try:
                    modified_at = state_db.stat().st_mtime
                except OSError:
                    modified_at = 0.0

            metadata: dict[str, Any] = {
                "composerId": info.composer_id,
                "workspace_dir": str(workspace_dir),
                "cursor_user": str(cursor_user),
            }
            if info.name is not None:
                metadata["name"] = info.name
            if info.model is not None:
                metadata["model"] = info.model
            if info.created_at is not None:
                metadata["createdAt"] = info.created_at
            if info.last_updated_at is not None:
                metadata["lastUpdatedAt"] = info.last_updated_at

            sessions.append(
                Session(
                    id=info.composer_id,
                    path=state_db,
                    format=self.name,
                    modified_at=float(modified_at),
                    metadata=metadata,
                )
            )

        # Sort by modification time, newest first
        sessions.sort(key=lambda s: s.modified_at, reverse=True)
        return sessions

    def _is_subpath(self, child: Path, parent: Path) -> bool:
        """Check if child is equal to or a subdirectory of parent."""
        try:
            child.relative_to(parent)
            return True
        except ValueError:
            return False

    def read_events(self, session: Session) -> Iterator[Event]:
        """Read AG-UI events from a Cursor composer session.

        Fetches bubble entries from the global state database and maps
        them to AG-UI events.
        """
        if not session.metadata:
            return

        composer_id = session.metadata.get("composerId", session.id)
        cursor_user_str = session.metadata.get("cursor_user")
        if not cursor_user_str:
            return

        cursor_user = Path(cursor_user_str)
        global_state_db = cursor_user / "globalStorage" / "state.vscdb"

        if not global_state_db.exists():
            return

        # Get session CWD from workspace directory for path normalization
        session_cwd = session.metadata.get("workspace_dir")

        # Initialize timestamp tracker with session modification time
        file_mtime_ms = int(session.modified_at * 1000)
        ts_tracker = TimestampTracker(file_mtime_ms)

        # Get bubble entries from global state
        bubbles = self._fetch_bubbles(global_state_db, composer_id)

        if not bubbles:
            return

        # Sort bubbles by createdAt for chronological ordering
        bubbles.sort(key=lambda b: b.get("createdAt", "") or "")

        # Get first timestamp for RunStarted
        first_ts = file_mtime_ms
        if bubbles:
            first_bubble = bubbles[0]
            if "createdAt" in first_bubble:
                first_ts = _parse_ms_timestamp(first_bubble["createdAt"], file_mtime_ms)

        # Emit source_entry for the session envelope
        yield CustomEvent(
            timestamp_ms=first_ts,
            name="source_entry",
            value={
                "format": "cursor",
                "entry_type": "session",
                "entry": session.metadata,
                "index": 0,
            },
        )

        # Emit RunStarted
        yield RunStartedEvent(
            timestamp_ms=first_ts,
            thread_id=composer_id,
            run_id=composer_id,
        )

        # Process each bubble
        for bubble_index, bubble in enumerate(bubbles):
            yield from self._map_bubble_to_events(bubble, bubble_index + 1, ts_tracker, session_cwd)

        # Emit RunFinished
        yield RunFinishedEvent(
            timestamp_ms=ts_tracker.last_valid,
            run_id=composer_id,
        )

    def _fetch_bubbles(self, global_state_db: Path, composer_id: str) -> list[dict[str, Any]]:
        """Fetch bubble entries for a composer session from global state.

        Args:
            global_state_db: Path to globalStorage/state.vscdb
            composer_id: The composer session ID

        Returns:
            List of bubble dictionaries.
        """
        bubbles: list[dict[str, Any]] = []

        try:
            conn = sqlite3.connect(f"file:{global_state_db}?mode=ro", uri=True, timeout=10)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()

            # Query for bubbleId entries matching this composer
            # Keys are like: bubbleId:<composerId>:<bubbleId>
            prefix = f"bubbleId:{composer_id}:"
            cursor.execute(
                "SELECT key, value FROM cursorDiskKV WHERE key LIKE ?",
                (f"{prefix}%",),
            )

            for row in cursor.fetchall():
                try:
                    value = row["value"]
                    if not value:
                        continue
                    bubble_data = json.loads(value)
                    if isinstance(bubble_data, dict):
                        # Store the bubble ID from the key
                        key = row["key"]
                        bubble_id = key[len(prefix) :] if key.startswith(prefix) else ""
                        bubble_data["bubbleId"] = bubble_id
                        bubbles.append(bubble_data)
                except (json.JSONDecodeError, TypeError):
                    continue

            conn.close()

        except sqlite3.Error:
            pass

        # Resolve local image paths to base64 data URLs
        for bubble in bubbles:
            resolved = _resolve_cursor_images(bubble)
            if resolved:
                bubble["images"] = resolved

        return bubbles

    def _map_bubble_to_events(
        self,
        bubble: dict[str, Any],
        index: int,
        ts_tracker: TimestampTracker,
        session_cwd: str | None,
    ) -> Iterator[Event]:
        """Map a bubble entry to AG-UI events.

        Bubble types:
        - type: 1 = user message
        - type: 2 = assistant message
        - toolFormerData indicates tool calls
        - allThinkingBlocks indicates reasoning

        Args:
            bubble: The bubble data dictionary
            index: Source entry index
            ts_tracker: Timestamp tracker for fallback handling
            session_cwd: Working directory for path normalization

        Yields:
            AG-UI events corresponding to this bubble.
        """
        # Parse timestamp - use fallback from tracker
        fallback_ts = ts_tracker.last_valid
        ts = _parse_ms_timestamp(bubble.get("createdAt"), fallback_ts)

        bubble_id = bubble.get("bubbleId", str(uuid.uuid4()))
        bubble_type = bubble.get("type")

        # Emit source_entry for lossless round-trip
        yield CustomEvent(
            timestamp_ms=ts,
            name="source_entry",
            value={
                "format": "cursor",
                "entry_type": "bubble",
                "entry": bubble,
                "index": index,
            },
        )

        # Build raw_event metadata
        raw_meta: dict[str, object] = {"bubbleId": bubble_id}
        if "type" in bubble:
            raw_meta["bubbleType"] = bubble["type"]
        # Use model from bubble if present, otherwise default to "cursor"
        raw_meta["model"] = bubble.get("model") or "cursor"

        thinking_blocks = bubble.get("allThinkingBlocks", [])
        tool_data = bubble.get("toolFormerData", {})

        text_content = bubble.get("text", "") or bubble.get("content", "")

        # Handle reasoning blocks (allThinkingBlocks)
        if thinking_blocks and isinstance(thinking_blocks, list):
            for block in thinking_blocks:
                if isinstance(block, dict):
                    thinking_text = block.get("text", "") or block.get("thinking", "")
                    if thinking_text:
                        yield ReasoningMessageChunkEvent(
                            timestamp_ms=ts,
                            message_id=bubble_id,
                            delta=str(thinking_text),
                        )

        # Handle tool calls (toolFormerData)
        if tool_data and isinstance(tool_data, dict):
            yield from self._map_tool_former_data(
                tool_data,
                bubble_id,
                ts,
            )

        # Map bubble type to role and emit text message
        if bubble_type == 1 and text_content:
            # User message
            yield TextMessageChunkEvent(
                timestamp_ms=ts,
                message_id=bubble_id,
                role=Role.USER,
                delta=str(text_content),
            )
        elif bubble_type == 2 and text_content:
            # Assistant message
            yield TextMessageChunkEvent(
                timestamp_ms=ts,
                message_id=bubble_id,
                role=Role.ASSISTANT,
                delta=str(text_content),
            )

    def _map_tool_former_data(
        self,
        tool_data: dict[str, Any],
        parent_message_id: str,
        ts: int,
    ) -> Iterator[Event]:
        """Map toolFormerData to tool call events.

        Cursor's toolFormerData can have two structures:
        1. Direct tool call: { "name": "read_file", "params": "...", "result": "...", ... }
        2. Nested structure: { "toolCalls": [...], "toolResults": {...} }

        Args:
            tool_data: The toolFormerData dictionary
            parent_message_id: Parent bubble/message ID
            ts: Timestamp in milliseconds

        Yields:
            ToolCallChunkEvent and ToolCallResultEvent for each tool call.
        """
        if "name" in tool_data and tool_data.get("name"):
            tool_call_id = tool_data.get("toolCallId", str(uuid.uuid4()))
            tool_name = tool_data.get("name", "")
            # params can be a JSON string or dict
            tool_args = tool_data.get("params", "") or tool_data.get("rawArgs", "")
            if isinstance(tool_args, dict):
                tool_args = json.dumps(tool_args)

            yield ToolCallChunkEvent(
                timestamp_ms=ts,
                tool_call_id=str(tool_call_id),
                tool_call_name=str(tool_name),
                parent_message_id=parent_message_id,
                delta=str(tool_args),
            )

            # Emit result if present (with +1ms offset so duration > 0)
            result = tool_data.get("result")
            if result is not None:
                result_str = json.dumps(result) if isinstance(result, dict) else str(result)
                yield ToolCallResultEvent(
                    timestamp_ms=ts + 1,  # +1ms so result comes after chunk
                    tool_call_id=str(tool_call_id),
                    tool_call_result_id=f"{tool_call_id}-result",
                    result=result_str,
                )
            return

        # Fall back to nested structure: { "toolCalls": [...], "toolResults": {...} }
        tool_calls = tool_data.get("toolCalls", [])
        if not isinstance(tool_calls, list):
            tool_calls = []

        tool_results = tool_data.get("toolResults", {})
        if not isinstance(tool_results, dict):
            tool_results = {}

        for tc in tool_calls:
            if not isinstance(tc, dict):
                continue

            tool_call_id = tc.get("id", str(uuid.uuid4()))
            tool_name = tc.get("name", "") or tc.get("function", "")
            tool_args = tc.get("args", {}) or tc.get("arguments", {})

            # Ensure args is serialized as string
            args_str = json.dumps(tool_args) if isinstance(tool_args, dict) else str(tool_args)

            yield ToolCallChunkEvent(
                timestamp_ms=ts,
                tool_call_id=str(tool_call_id),
                tool_call_name=str(tool_name),
                parent_message_id=parent_message_id,
                delta=args_str,
            )

            # Check for corresponding result (with +1ms offset so duration > 0)
            result = tool_results.get(tool_call_id)
            if result is not None:
                result_str = json.dumps(result) if isinstance(result, dict) else str(result)
                yield ToolCallResultEvent(
                    timestamp_ms=ts + 1,  # +1ms so result comes after chunk
                    tool_call_id=str(tool_call_id),
                    tool_call_result_id=f"{tool_call_id}-result",
                    result=result_str,
                )

        # Handle standalone tool results not in toolCalls
        for result_id, result in tool_results.items():
            # Skip if we already handled this in the loop above
            if any(tc.get("id") == result_id for tc in tool_calls if isinstance(tc, dict)):
                continue

            result_str = json.dumps(result) if isinstance(result, dict) else str(result)
            yield ToolCallResultEvent(
                timestamp_ms=ts + 1,  # +1ms for consistency
                tool_call_id=str(result_id),
                tool_call_result_id=f"{result_id}-result",
                result=result_str,
            )

    @staticmethod
    def _has_tool_calls(tool_data: dict[str, Any] | None) -> bool:
        """Check if toolFormerData contains callable entries."""
        if not tool_data or not isinstance(tool_data, dict):
            return False
        if tool_data.get("name"):
            return True
        tool_calls = tool_data.get("toolCalls", [])
        if isinstance(tool_calls, list):
            return any(isinstance(tc, dict) for tc in tool_calls)
        return False

    @staticmethod
    def _extract_file_ops_from_tool_data(
        tool_data: dict[str, Any], session_cwd: str | None
    ) -> list[dict[str, Any]]:
        """Extract file operations from Cursor's toolFormerData.

        Args:
            tool_data: The toolFormerData dictionary.
            session_cwd: Working directory for path normalization.

        Returns:
            List of file operation dicts.
        """
        file_ops: list[dict[str, Any]] = []

        # Direct tool call structure
        if tool_data.get("name"):
            name = str(tool_data.get("name", ""))
            # Parse params - can be JSON string or dict
            params = tool_data.get("params") or tool_data.get("rawArgs") or {}
            if isinstance(params, str):
                try:
                    params = json.loads(params)
                except json.JSONDecodeError:
                    params = {}
            if not isinstance(params, dict):
                params = {}

            file_op = CursorAdapter._extract_file_op(name, params, session_cwd)
            if file_op:
                file_ops.append(file_op)
            return file_ops

        # Nested structure with toolCalls
        tool_calls = tool_data.get("toolCalls", [])
        if isinstance(tool_calls, list):
            for tc in tool_calls:
                if not isinstance(tc, dict):
                    continue
                name = str(tc.get("name", "") or tc.get("function", ""))
                args = tc.get("args", {}) or tc.get("arguments", {})
                if isinstance(args, str):
                    try:
                        args = json.loads(args)
                    except json.JSONDecodeError:
                        args = {}
                if not isinstance(args, dict):
                    args = {}

                file_op = CursorAdapter._extract_file_op(name, args, session_cwd)
                if file_op:
                    file_ops.append(file_op)

        return file_ops

    @staticmethod
    def _extract_file_op(
        name: str, args: dict[str, Any], session_cwd: str | None
    ) -> dict[str, Any] | None:
        """Extract a single file operation from tool name and args.

        Args:
            name: Tool name.
            args: Tool arguments.
            session_cwd: Working directory for path normalization.

        Returns:
            File operation dict or None.
        """
        if name in _FILE_READ_TOOLS:
            # read_file_v2 uses targetFile; read_file uses relativeWorkspacePath, target_file
            raw_path = (
                args.get("file_path")
                or args.get("path")
                or args.get("filePath")
                or args.get("relativeWorkspacePath")
                or args.get("targetFile")
                or args.get("target_file")
            )
            if raw_path:
                return {"op": "read", "path": normalize_path(raw_path, session_cwd)}

        elif name in _FILE_WRITE_TOOLS:
            raw_path = (
                args.get("file_path")
                or args.get("path")
                or args.get("filePath")
                or args.get("relativeWorkspacePath")
            )
            if raw_path:
                return {"op": "write", "path": normalize_path(raw_path, session_cwd)}

        elif name in _FILE_EDIT_TOOLS:
            # edit_file, edit_file_v2, search_replace all use relativeWorkspacePath
            raw_path = (
                args.get("file_path")
                or args.get("path")
                or args.get("filePath")
                or args.get("relativeWorkspacePath")
            )
            if raw_path:
                return {"op": "edit", "path": normalize_path(raw_path, session_cwd)}

        elif name in _FILE_DELETE_TOOLS:
            raw_path = (
                args.get("file_path")
                or args.get("path")
                or args.get("filePath")
                or args.get("relativeWorkspacePath")
            )
            if raw_path:
                return {"op": "delete", "path": normalize_path(raw_path, session_cwd)}

        elif name in _FILE_LIST_TOOLS:
            op_dict: dict[str, Any] = {"op": "list"}
            if "pattern" in args or "globPattern" in args:
                op_dict["pattern"] = args.get("pattern") or args.get("globPattern")
            # list_dir uses directoryPath, targetDirectory; glob_file_search uses targetDirectory
            raw_path = (
                args.get("path")
                or args.get("directory")
                or args.get("dirPath")
                or args.get("directoryPath")
                or args.get("targetDirectory")
            )
            if raw_path:
                op_dict["path"] = normalize_path(raw_path, session_cwd)
            return op_dict

        elif name in _FILE_SEARCH_TOOLS:
            op_dict = {"op": "search"}
            if "pattern" in args or "query" in args:
                op_dict["pattern"] = args.get("pattern") or args.get("query")
            raw_path = args.get("path") or args.get("directory")
            if raw_path:
                op_dict["path"] = normalize_path(raw_path, session_cwd)
            return op_dict

        return None

    def parse_source_entry(
        self,
        entry: dict,
        entry_index: int,
        session_id: str,
    ) -> list[Event]:
        """Parse a single source entry into AG-UI events.

        Args:
            entry: Parsed JSON from source_entry.entry_content
            entry_index: Position in session (for event ID generation)
            session_id: Session UUID

        Returns:
            List of AG-UI events (may be empty)
        """

        events: list[Event] = []

        # Skip synthetic daemon_metadata entry (from dump command fixtures)
        if entry.get("type") == "daemon_metadata":
            return events

        # Session metadata doesn't produce semantic events
        if "composerId" in entry and "bubbleId" not in entry:
            return events

        # This is a bubble entry
        bubble_type = entry.get("type")
        bubble_id = entry.get("bubbleId", str(uuid.uuid4()))
        text_content = entry.get("text", "") or entry.get("content", "")
        thinking_blocks = entry.get("allThinkingBlocks", [])
        tool_data = entry.get("toolFormerData", {})

        # Parse timestamp from entry (crucial for correct event ordering!)
        # Cursor uses "createdAt" field for timestamps, not "timestamp"
        # _timestamp_ms is injected by normalization pipeline as fallback
        raw_ts = entry.get("createdAt") or entry.get("timestamp") or entry.get("_timestamp_ms")
        # Use _timestamp_ms as fallback (never datetime.now() which produces future timestamps)
        fallback_ts = entry.get("_timestamp_ms", 0)
        ts = _parse_ms_timestamp(raw_ts, fallback_ts)

        # Handle reasoning blocks (allThinkingBlocks)
        if thinking_blocks and isinstance(thinking_blocks, list):
            for block in thinking_blocks:
                if isinstance(block, dict):
                    thinking_text = block.get("text", "") or block.get("thinking", "")
                    if thinking_text:
                        events.append(
                            ReasoningMessageChunkEvent(
                                timestamp_ms=ts,
                                message_id=bubble_id,
                                delta=str(thinking_text),
                            )
                        )

        # Handle tool calls (toolFormerData)
        if tool_data and isinstance(tool_data, dict):
            # Check for direct tool call structure (name field at top level)
            if "name" in tool_data and tool_data.get("name"):
                tool_call_id = tool_data.get("toolCallId", str(uuid.uuid4()))
                tool_name = tool_data.get("name", "")
                tool_args = tool_data.get("params", "") or tool_data.get("rawArgs", "")
                if isinstance(tool_args, dict):
                    tool_args = json.dumps(tool_args)

                events.append(
                    ToolCallChunkEvent(
                        timestamp_ms=ts,
                        tool_call_id=str(tool_call_id),
                        tool_call_name=str(tool_name),
                        parent_message_id=bubble_id,
                        delta=str(tool_args),
                    )
                )

                # Emit result if present
                result = tool_data.get("result")
                if result is not None:
                    result_str = json.dumps(result) if isinstance(result, dict) else str(result)
                    events.append(
                        ToolCallResultEvent(
                            timestamp_ms=ts + 1,  # +1ms so result comes after chunk
                            tool_call_id=str(tool_call_id),
                            tool_call_result_id=f"{tool_call_id}-result",
                            result=result_str,
                        )
                    )
            else:
                # Fall back to nested structure: { "toolCalls": [...], "toolResults": {...} }
                tool_calls = tool_data.get("toolCalls", [])
                if not isinstance(tool_calls, list):
                    tool_calls = []

                tool_results = tool_data.get("toolResults", {})
                if not isinstance(tool_results, dict):
                    tool_results = {}

                for tc in tool_calls:
                    if not isinstance(tc, dict):
                        continue

                    tool_call_id = tc.get("id", str(uuid.uuid4()))
                    tool_name = tc.get("name", "") or tc.get("function", "")
                    tool_args = tc.get("args", {}) or tc.get("arguments", {})

                    # Ensure args is serialized as string
                    args_str = (
                        json.dumps(tool_args) if isinstance(tool_args, dict) else str(tool_args)
                    )

                    events.append(
                        ToolCallChunkEvent(
                            timestamp_ms=ts,
                            tool_call_id=str(tool_call_id),
                            tool_call_name=str(tool_name),
                            parent_message_id=bubble_id,
                            delta=args_str,
                        )
                    )

                    # Check for corresponding result
                    result = tool_results.get(tool_call_id)
                    if result is not None:
                        result_str = json.dumps(result) if isinstance(result, dict) else str(result)
                        events.append(
                            ToolCallResultEvent(
                                timestamp_ms=ts + 1,
                                tool_call_id=str(tool_call_id),
                                tool_call_result_id=f"{tool_call_id}-result",
                                result=result_str,
                            )
                        )

        # Map bubble type to role and emit text message
        if bubble_type == 1 and text_content:
            # User message
            events.append(
                TextMessageChunkEvent(
                    timestamp_ms=ts,
                    message_id=bubble_id,
                    role=Role.USER,
                    delta=str(text_content),
                )
            )
        elif bubble_type == 2 and text_content:
            # Assistant message
            events.append(
                TextMessageChunkEvent(
                    timestamp_ms=ts,
                    message_id=bubble_id,
                    role=Role.ASSISTANT,
                    delta=str(text_content),
                )
            )

        # Tag all events with entry_index for incremental processing
        for event in events:
            if not hasattr(event, "_source"):
                event._source = {}  # type: ignore[attr-defined]
            event._source["entry_index"] = entry_index  # type: ignore[attr-defined, index]

        return events

    def write_events(self, events: Iterable[Event], dest: IO[str]) -> None:
        """Write AG-UI events as Cursor format.

        Currently not implemented as Cursor adapter is read-only.

        Raises:
            NotImplementedError: Always, as write is not supported.
        """
        raise NotImplementedError(
            "CursorAdapter is read-only. Writing to Cursor's SQLite databases is not supported."
        )

    def detect(self, project_dir: Path) -> bool:
        """Check if Cursor was used for this project.

        Overrides base implementation to also check for Cursor user directory
        existence before scanning for sessions.
        """
        cursor_user = _get_cursor_user_dir()
        if not cursor_user.exists():
            return False
        return len(self.discover_sessions(project_dir)) > 0
