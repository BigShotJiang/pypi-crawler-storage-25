"""GitHub Copilot CLI log scraping for token-usage enrichment.

Copilot 1.0.40's ``events.jsonl`` only carries ``outputTokens`` per
assistant message. The matching *input* token counts (the ones surfaced
by the in-CLI ``/usage`` command) live in the per-process log at
``$COPILOT_HOME/logs/process-<launch_ts>-<pid>.log`` as lines like::

    2026-05-05T05:28:07.856Z [INFO] CompactionProcessor: Utilization 11.6%
    (31607/272000 tokens) below threshold 80%

Each line is emitted right before the model call; the matching
``assistant.message`` arrives 3–7s later. We pair them up by walking
the log, then expose a lookup so the adapter's ``enrich_entries`` step
can attach ``_input_tokens`` to assistant messages.

This is a deliberate hack against an internal log format. If the
``CompactionProcessor`` log line ever disappears or changes shape we
just lose the enrichment and fall back to output-only TOKEN_USAGE —
nothing else breaks.
"""

from __future__ import annotations

import bisect
import logging
import os
import re
from datetime import datetime
from pathlib import Path

logger = logging.getLogger(__name__)

# Regex anchored on the literal Copilot 1.0.40 log format. Capture the
# ISO-8601 timestamp and the input-context token count.
_UTILIZATION_RE = re.compile(
    r"^(?P<ts>\S+) \[INFO\] CompactionProcessor: Utilization \S+ \((?P<tokens>\d+)/\d+ tokens\)"
)

# How many lines we scan at the head of each log to find the
# ``Workspace initialized: <session-id>`` marker. The marker is on
# line 2 in current Copilot, but we read ahead a bit to absorb any
# prelude logging that lands first.
_MAX_HEADER_LINES = 50

# Maximum allowable gap between an assistant.message timestamp and
# the most-recent preceding Utilization line. Today the gap is 3–7s;
# 60s leaves slack for slow generations (e.g. xhigh reasoning) without
# pairing across unrelated turns.
_MATCH_WINDOW_SECONDS = 60.0


def _copilot_logs_dir() -> Path:
    """Return ``$COPILOT_HOME/logs`` (or ``~/.copilot/logs``)."""
    env = os.environ.get("COPILOT_HOME")
    base = Path(env).expanduser() if env else Path.home() / ".copilot"
    return base / "logs"


def find_log_for_session(session_id: str, logs_dir: Path | None = None) -> Path | None:
    """Locate the per-process log file for a Copilot session.

    Each ``copilot`` invocation writes one ``process-<ts>-<pid>.log``
    into ``$COPILOT_HOME/logs/``. The second line typically reads
    ``Workspace initialized: <session-id>``; we scan the first
    ``_MAX_HEADER_LINES`` of each log and return the first match.

    Returns ``None`` if no log file mentions the session — common when
    logs have been pruned or the session was imported from another
    machine.
    """
    base = logs_dir or _copilot_logs_dir()
    if not base.is_dir():
        return None

    needle = f"Workspace initialized: {session_id}"
    # Newest first — typical case is the most recent process owns the
    # session, so we hit on the first file.
    candidates = sorted(
        (p for p in base.glob("process-*.log") if p.is_file()),
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    )
    for log_path in candidates:
        try:
            with open(log_path, encoding="utf-8", errors="replace") as f:
                for _ in range(_MAX_HEADER_LINES):
                    line = f.readline()
                    if not line:
                        break
                    if needle in line:
                        return log_path
        except OSError as e:
            logger.debug("Skipping unreadable copilot log %s: %s", log_path, e)
            continue
    return None


class InputTokenIndex:
    """Searchable index of ``(timestamp_ms, input_tokens)`` pairs from a log.

    Built once per session; exposes ``lookup(ts_ms)`` to find the input
    token count that preceded a given assistant message.
    """

    def __init__(self, entries: list[tuple[int, int]]) -> None:
        self._timestamps_ms = [ts for ts, _ in entries]
        self._tokens = [tk for _, tk in entries]

    def __len__(self) -> int:
        return len(self._tokens)

    def lookup(self, message_ts_ms: int) -> int | None:
        """Return the most recent input-token count ≤ ``message_ts_ms``.

        Returns ``None`` when the gap exceeds ``_MATCH_WINDOW_SECONDS``
        or no entry precedes the message. Robust to retries and missing
        log lines — callers fall back to output-only TOKEN_USAGE.
        """
        if not self._tokens:
            return None
        # bisect_right gives the index of the first entry strictly
        # *after* the message; the one we want is at idx-1.
        idx = bisect.bisect_right(self._timestamps_ms, message_ts_ms) - 1
        if idx < 0:
            return None
        if message_ts_ms - self._timestamps_ms[idx] > _MATCH_WINDOW_SECONDS * 1000:
            return None
        return self._tokens[idx]


def parse_utilization_lines(log_path: Path) -> InputTokenIndex:
    """Build an :class:`InputTokenIndex` from a Copilot process log.

    Lines that don't match the expected ``CompactionProcessor:
    Utilization`` shape are skipped silently. An empty index is
    returned on file errors.
    """
    entries: list[tuple[int, int]] = []
    try:
        with open(log_path, encoding="utf-8", errors="replace") as f:
            for line in f:
                m = _UTILIZATION_RE.match(line)
                if not m:
                    continue
                try:
                    ts = datetime.fromisoformat(m.group("ts").replace("Z", "+00:00"))
                except ValueError:
                    continue
                entries.append((int(ts.timestamp() * 1000), int(m.group("tokens"))))
    except OSError as e:
        logger.debug("Failed reading copilot log %s: %s", log_path, e)
    return InputTokenIndex(entries)
