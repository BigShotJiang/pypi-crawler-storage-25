"""Tests for the GitHub Copilot CLI adapter."""

from __future__ import annotations

import base64
import json
from datetime import datetime as _dt
from pathlib import Path
from typing import Any

from agentstream.adapters.base import Session
from agentstream.adapters.copilot import CopilotAdapter, resolve_swe_agent_model
from agentstream.events import (
    CustomEvent,
    Role,
    RunFinishedEvent,
    RunStartedEvent,
    TextMessageChunkEvent,
    ToolCallChunkEvent,
    ToolCallResultEvent,
)

FIXTURES = Path(__file__).parent.parent / "fixtures" / "copilot"
SAMPLE_SESSION_DIR = FIXTURES / "sample_session"
SAMPLE_EVENTS = SAMPLE_SESSION_DIR / "events.jsonl"


def _load_session(modified_at: float | None = None) -> Session:
    return Session(
        id="65e46d21-f547-4670-8515-fdd6c4dca5ac",
        path=SAMPLE_EVENTS,
        format="copilot",
        modified_at=modified_at if modified_at is not None else SAMPLE_EVENTS.stat().st_mtime,
    )


class TestCopilotAdapterMetadata:
    def test_name(self) -> None:
        assert CopilotAdapter().name == "copilot"

    def test_get_base_directories_default(self, monkeypatch: Any) -> None:
        monkeypatch.delenv("COPILOT_HOME", raising=False)
        monkeypatch.delenv("RUNNER_TEMP", raising=False)
        monkeypatch.setattr(Path, "home", lambda: Path("/home/runner"))
        dirs = CopilotAdapter().get_base_directories()
        assert dirs == [Path("/home/runner/.copilot/session-state")]

    def test_get_base_directories_honours_copilot_home(self, monkeypatch: Any) -> None:
        # Required for GitHub Actions setups that point Copilot CLI at a
        # workspace-mounted directory so artifacts persist across steps.
        monkeypatch.setenv("COPILOT_HOME", "/runner/_work/copilot")
        monkeypatch.delenv("RUNNER_TEMP", raising=False)
        dirs = CopilotAdapter().get_base_directories()
        assert dirs == [Path("/runner/_work/copilot/session-state")]


class TestCopilotMatchesPath:
    def test_matches_default_layout(self, monkeypatch: Any) -> None:
        monkeypatch.delenv("COPILOT_HOME", raising=False)
        monkeypatch.setattr(Path, "home", lambda: Path("/home/runner"))
        adapter = CopilotAdapter()
        path = Path("/home/runner/.copilot/session-state/abc123/events.jsonl")
        assert adapter.matches_path(path)

    def test_matches_overridden_copilot_home(self, monkeypatch: Any) -> None:
        monkeypatch.setenv("COPILOT_HOME", "/runner/_work/copilot")
        adapter = CopilotAdapter()
        path = Path("/runner/_work/copilot/session-state/abc123/events.jsonl")
        assert adapter.matches_path(path)

    def test_does_not_match_path_outside_copilot_home(self, monkeypatch: Any) -> None:
        """Structural lookalikes outside ``$COPILOT_HOME`` must not match —
        otherwise unrelated ``session-state/**/events.jsonl`` files would
        get attributed to Copilot during format detection."""
        monkeypatch.setenv("COPILOT_HOME", "/runner/_work/copilot")
        adapter = CopilotAdapter()
        assert not adapter.matches_path(Path("/some/other/tool/session-state/xyz/events.jsonl"))

    def test_does_not_match_other_jsonl(self, monkeypatch: Any) -> None:
        monkeypatch.setattr(Path, "home", lambda: Path("/home/runner"))
        adapter = CopilotAdapter()
        assert not adapter.matches_path(Path("/tmp/some-other.jsonl"))
        assert not adapter.matches_path(Path("/home/runner/.codex/sessions/2026/01/01/foo.jsonl"))

    def test_get_session_id_from_directory(self) -> None:
        adapter = CopilotAdapter()
        sid = adapter.get_session_id(
            Path("/home/runner/.copilot/session-state/65e46d21-abc/events.jsonl")
        )
        assert sid == "65e46d21-abc"


class TestCopilotDiscoverSessions:
    def _build_session(self, base: Path, session_id: str, cwd: str, branch: str = "main") -> Path:
        """Create a synthetic Copilot session under ``base``."""
        session_dir = base / "session-state" / session_id
        session_dir.mkdir(parents=True)
        # workspace.yaml — flat key:value file
        (session_dir / "workspace.yaml").write_text(
            f"id: {session_id}\ncwd: {cwd}\ngit_root: {cwd}\nbranch: {branch}\nname: Test\n"
        )
        # Minimal events.jsonl
        (session_dir / "events.jsonl").write_text(
            json.dumps(
                {
                    "type": "session.start",
                    "data": {
                        "sessionId": session_id,
                        "context": {"cwd": cwd, "branch": branch},
                    },
                    "id": "evt-0",
                    "timestamp": "2026-05-04T00:00:00.000Z",
                }
            )
            + "\n"
        )
        return session_dir

    def test_discovers_sessions_for_project(self, tmp_path: Path, monkeypatch: Any) -> None:
        copilot_home = tmp_path / "copilot-home"
        copilot_home.mkdir()
        monkeypatch.setenv("COPILOT_HOME", str(copilot_home))

        project = tmp_path / "myproject"
        project.mkdir()
        other = tmp_path / "other"
        other.mkdir()

        self._build_session(copilot_home, "session-mine", str(project))
        self._build_session(copilot_home, "session-other", str(other))

        sessions = CopilotAdapter().discover_sessions(project)

        assert len(sessions) == 1
        assert sessions[0].id == "session-mine"
        assert sessions[0].format == "copilot"
        assert sessions[0].path.name == "events.jsonl"

    def test_discover_falls_back_to_first_event_when_workspace_missing(
        self, tmp_path: Path, monkeypatch: Any
    ) -> None:
        copilot_home = tmp_path / "copilot-home"
        copilot_home.mkdir()
        monkeypatch.setenv("COPILOT_HOME", str(copilot_home))

        project = tmp_path / "myproject"
        project.mkdir()

        # Build a session, then delete workspace.yaml
        session_dir = self._build_session(copilot_home, "no-yaml", str(project))
        (session_dir / "workspace.yaml").unlink()

        sessions = CopilotAdapter().discover_sessions(project)
        assert len(sessions) == 1
        assert sessions[0].id == "no-yaml"

    def test_discover_falls_back_skips_prelude_events(
        self, tmp_path: Path, monkeypatch: Any
    ) -> None:
        """``_extract_cwd_from_first_entry`` should skip blank/invalid/non-matching
        lines before ``session.start`` instead of bailing on the first one."""
        copilot_home = tmp_path / "copilot-home"
        copilot_home.mkdir()
        monkeypatch.setenv("COPILOT_HOME", str(copilot_home))

        project = tmp_path / "myproject"
        project.mkdir()

        session_dir = copilot_home / "session-state" / "with-prelude"
        session_dir.mkdir(parents=True)
        # Prelude: blank line, malformed JSON, unrelated event — all before
        # the real session.start that carries cwd.
        (session_dir / "events.jsonl").write_text(
            "\n"
            + "{not valid json\n"
            + json.dumps({"type": "telemetry"})
            + "\n"
            + json.dumps(
                {
                    "type": "session.start",
                    "data": {
                        "sessionId": "with-prelude",
                        "context": {"cwd": str(project), "branch": "main"},
                    },
                    "id": "evt-0",
                    "timestamp": "2026-05-04T00:00:00.000Z",
                }
            )
            + "\n"
        )

        sessions = CopilotAdapter().discover_sessions(project)
        assert len(sessions) == 1
        assert sessions[0].id == "with-prelude"

    def test_discover_returns_empty_when_home_missing(
        self, tmp_path: Path, monkeypatch: Any
    ) -> None:
        monkeypatch.setenv("COPILOT_HOME", str(tmp_path / "nonexistent"))
        assert CopilotAdapter().discover_sessions(tmp_path) == []


class TestCopilotReadEntries:
    def test_read_entries_from_fixture(self) -> None:
        adapter = CopilotAdapter()
        session = _load_session()
        entries = adapter.read_entries(session)

        assert len(entries) == 456
        first = entries[0]
        assert first["entry_index"] == 0
        # Raw JSON line preserved for lossless round-trip
        assert first["entry_content"].startswith('{"type":"session.start"')
        # Timestamp parsed from the ISO field
        assert first["entry_timestamp_ms"] > 0

    def test_read_entries_after_filters_by_index(self) -> None:
        adapter = CopilotAdapter()
        session = _load_session()
        all_entries = adapter.read_entries(session)
        partial = adapter.read_entries_after(session, after_index=99)

        assert len(partial) == len(all_entries) - 100
        assert partial[0]["entry_index"] == 100

    def test_read_entries_resolves_image_attachments_to_data_urls(self, tmp_path: Path) -> None:
        """Copilot stores user-pasted images as local file paths in
        ``user.message.data.attachments``. The adapter resolves them to data
        URLs so the backend (which can't see the user's filesystem) can
        upload them and emit IMAGE_CONTENT events."""
        # Tiny valid PNG (1x1 transparent pixel)
        png_bytes = bytes.fromhex(
            "89504e470d0a1a0a0000000d49484452000000010000000108060000001f15c4"
            "890000000d49444154789c6300010000000500010d0a2db40000000049454e44"
            "ae426082"
        )
        image_path = tmp_path / "screenshot.png"
        image_path.write_bytes(png_bytes)

        events_path = tmp_path / "events.jsonl"
        entries = [
            {
                "type": "session.start",
                "data": {"sessionId": "x", "context": {"cwd": str(tmp_path)}},
                "id": "evt-0",
                "timestamp": "2026-05-04T00:00:00.000Z",
            },
            {
                "type": "user.message",
                "data": {
                    "content": "[📷 screenshot.png] What do you see?",
                    "attachments": [
                        {
                            "type": "file",
                            "path": str(image_path),
                            "displayName": "screenshot.png",
                        }
                    ],
                },
                "id": "evt-1",
                "timestamp": "2026-05-04T00:00:01.000Z",
            },
        ]
        events_path.write_text("\n".join(json.dumps(e) for e in entries) + "\n")

        session = Session(id="img-test", path=events_path, format="copilot", modified_at=0)
        result = CopilotAdapter().read_entries(session)
        # Second entry is the user.message — data_url should be injected.
        user_entry = json.loads(result[1]["entry_content"])
        att = user_entry["data"]["attachments"][0]
        assert att["data_url"].startswith("data:image/png;base64,")
        # Round-trips: decoded base64 matches the source file.
        encoded = att["data_url"].split(",", 1)[1]
        assert base64.b64decode(encoded) == png_bytes
        # Non-image entries (session.start) are NOT re-serialized, so the raw
        # line is preserved verbatim.
        assert result[0]["entry_content"].startswith('{"type": "session.start"')

    def test_read_entries_skips_missing_or_non_image_attachments(self, tmp_path: Path) -> None:
        events_path = tmp_path / "events.jsonl"
        entries = [
            {
                "type": "user.message",
                "data": {
                    "content": "hi",
                    "attachments": [
                        {
                            "type": "file",
                            "path": str(tmp_path / "does_not_exist.png"),
                            "displayName": "does_not_exist.png",
                        },
                        {
                            "type": "file",
                            "path": str(tmp_path / "notes.txt"),
                            "displayName": "notes.txt",
                        },
                    ],
                },
                "id": "evt-1",
                "timestamp": "2026-05-04T00:00:01.000Z",
            },
        ]
        # Create the txt file so isfile() succeeds — but mime type isn't image.
        (tmp_path / "notes.txt").write_text("plain text")
        events_path.write_text("\n".join(json.dumps(e) for e in entries) + "\n")

        session = Session(id="no-img", path=events_path, format="copilot", modified_at=0)
        result = CopilotAdapter().read_entries(session)
        # No attachment got a data_url, so we keep the original raw line.
        assert "data_url" not in result[0]["entry_content"]


class TestCopilotEnrichEntries:
    """Verify the log-scraping enrichment that attaches ``_input_tokens``."""

    @staticmethod
    def _make_session(tmp_path: Path, session_id: str) -> Session:
        events_path = tmp_path / "session-state" / session_id / "events.jsonl"
        events_path.parent.mkdir(parents=True)
        events_path.write_text("")
        return Session(
            id=session_id,
            path=events_path,
            format="copilot",
            modified_at=events_path.stat().st_mtime,
        )

    @staticmethod
    def _write_log(copilot_home: Path, session_id: str, util_lines: list[tuple[str, int]]) -> Path:
        logs = copilot_home / "logs"
        logs.mkdir(parents=True, exist_ok=True)
        path = logs / "process-1-1.log"
        body = [
            "2026-05-05T05:27:34.644Z [INFO] Session indexing debug",
            f"2026-05-05T05:27:34.676Z [INFO] Workspace initialized: {session_id} (checkpoints: 0)",
        ]
        for ts, tokens in util_lines:
            body.append(
                f"{ts} [INFO] CompactionProcessor: Utilization 11.6% "
                f"({tokens}/272000 tokens) below threshold 80%"
            )
        path.write_text("\n".join(body) + "\n")
        return path

    @staticmethod
    def _assistant_entry(idx: int, ts_ms: int, output_tokens: int) -> dict:
        content = json.dumps(
            {
                "type": "assistant.message",
                "data": {"messageId": f"m{idx}", "outputTokens": output_tokens},
                "id": f"evt-{idx}",
                "timestamp": "2026-05-05T05:28:12.292Z",
            },
            separators=(",", ":"),
        )
        return {
            "entry_index": idx,
            "entry_content": content,
            "entry_timestamp_ms": ts_ms,
        }

    def test_attaches_input_tokens_to_assistant_messages(
        self, tmp_path: Path, monkeypatch: Any
    ) -> None:
        copilot_home = tmp_path / "copilot-home"
        copilot_home.mkdir()
        monkeypatch.setenv("COPILOT_HOME", str(copilot_home))

        session = self._make_session(copilot_home, "abc-123")
        # Two log entries; assistant.messages arrive 4s after each one
        # (matches the real-world 3–7s lead between request-send and
        # response-arrival).
        self._write_log(
            copilot_home,
            "abc-123",
            [
                ("2026-05-04T18:13:22.000Z", 31607),
                ("2026-05-04T18:13:28.000Z", 34717),
            ],
        )

        def _ms(iso: str) -> int:
            return int(_dt.fromisoformat(iso).timestamp() * 1000)

        entries = [
            self._assistant_entry(0, _ms("2026-05-04T18:13:26+00:00"), output_tokens=196),
            self._assistant_entry(1, _ms("2026-05-04T18:13:32+00:00"), output_tokens=261),
        ]

        result = CopilotAdapter().enrich_entries(entries, session)

        c0 = json.loads(result[0]["entry_content"])
        c1 = json.loads(result[1]["entry_content"])
        assert c0["_input_tokens"] == 31607
        assert c1["_input_tokens"] == 34717

    def test_no_log_leaves_entries_untouched(self, tmp_path: Path, monkeypatch: Any) -> None:
        copilot_home = tmp_path / "copilot-home"
        copilot_home.mkdir()
        monkeypatch.setenv("COPILOT_HOME", str(copilot_home))

        session = self._make_session(copilot_home, "no-log-session")
        entries = [self._assistant_entry(0, 1_700_000_000_000, output_tokens=42)]
        original_content = entries[0]["entry_content"]

        result = CopilotAdapter().enrich_entries(entries, session)

        assert result[0]["entry_content"] == original_content
        assert "_input_tokens" not in json.loads(result[0]["entry_content"])

    def test_skips_non_assistant_entries(self, tmp_path: Path, monkeypatch: Any) -> None:
        copilot_home = tmp_path / "copilot-home"
        copilot_home.mkdir()
        monkeypatch.setenv("COPILOT_HOME", str(copilot_home))
        session = self._make_session(copilot_home, "x")
        self._write_log(
            copilot_home,
            "x",
            [("2026-05-04T18:13:22.000Z", 31607)],
        )

        user_entry = {
            "entry_index": 0,
            "entry_content": json.dumps(
                {"type": "user.message", "data": {"content": "hi"}}, separators=(",", ":")
            ),
            "entry_timestamp_ms": 1_700_000_000_000,
        }

        result = CopilotAdapter().enrich_entries([user_entry], session)
        assert result[0]["entry_content"] == user_entry["entry_content"]


class TestCopilotReadEvents:
    def test_emits_run_start_and_finish(self) -> None:
        adapter = CopilotAdapter()
        session = _load_session()
        events = list(adapter.read_events(session))

        run_started = [e for e in events if isinstance(e, RunStartedEvent)]
        run_finished = [e for e in events if isinstance(e, RunFinishedEvent)]
        assert len(run_started) == 1
        assert len(run_finished) == 1
        assert run_started[0].run_id == "65e46d21-f547-4670-8515-fdd6c4dca5ac"

    def test_user_messages_have_correct_role(self) -> None:
        adapter = CopilotAdapter()
        session = _load_session()
        events = list(adapter.read_events(session))

        user_msgs = [
            e for e in events if isinstance(e, TextMessageChunkEvent) and e.role == Role.USER
        ]
        assert any("chat transcripts" in (e.delta or "") for e in user_msgs)

    def test_system_messages_are_not_emitted_as_text_chunks(self) -> None:
        """``system.message`` is the static system prompt Copilot re-sends each
        turn; emitting it as a TextMessageChunkEvent caused the dashboard to
        render it as a duplicate assistant message at every turn boundary."""
        adapter = CopilotAdapter()
        session = _load_session()
        events = list(adapter.read_events(session))

        system_text_chunks = [
            e for e in events if isinstance(e, TextMessageChunkEvent) and e.role == Role.SYSTEM
        ]
        assert system_text_chunks == []

        # We should also not have leaked the system prompt text into any
        # assistant message — the giveaway in the fixture is the boilerplate
        # opening line.
        boilerplate = "You are the GitHub Copilot CLI"
        assistant_msgs = [
            e for e in events if isinstance(e, TextMessageChunkEvent) and e.role == Role.ASSISTANT
        ]
        assert not any(boilerplate in (e.delta or "") for e in assistant_msgs)

    def test_system_message_still_round_trips_via_source_entry(self) -> None:
        """Even though we drop ``system.message`` from the AG-UI stream, the
        raw line must still appear in a ``source_entry`` CustomEvent so that
        round-trip writers (and re-normalization) stay lossless."""
        from agentstream.events import CustomEvent  # noqa: PLC0415

        adapter = CopilotAdapter()
        session = _load_session()
        events = list(adapter.read_events(session))

        source_entries = [
            e
            for e in events
            if isinstance(e, CustomEvent)
            and e.name == "source_entry"
            and isinstance(e.value, dict)
            and e.value.get("entry_type") == "system.message"
        ]
        assert source_entries  # raw lines preserved
        assert all("system.message" in str(e.value.get("raw_line", "")) for e in source_entries)

    def test_tool_calls_paired_with_results(self) -> None:
        """Every tool execution should yield matching CHUNK + RESULT events."""
        adapter = CopilotAdapter()
        session = _load_session()
        events = list(adapter.read_events(session))

        chunk_ids = {
            e.tool_call_id for e in events if isinstance(e, ToolCallChunkEvent) and e.tool_call_id
        }
        result_ids = {
            e.tool_call_id for e in events if isinstance(e, ToolCallResultEvent) and e.tool_call_id
        }
        # Most tool calls should have matching results — allow some slack for
        # in-flight calls in a real session.
        assert chunk_ids
        assert result_ids
        overlap = chunk_ids & result_ids
        assert len(overlap) >= len(chunk_ids) - 2

    def test_subagent_emits_custom_event(self) -> None:
        adapter = CopilotAdapter()
        session = _load_session()
        events = list(adapter.read_events(session))

        subagent_started = [
            e for e in events if isinstance(e, CustomEvent) and e.name == "copilot_subagent_started"
        ]
        subagent_completed = [
            e
            for e in events
            if isinstance(e, CustomEvent) and e.name == "copilot_subagent_completed"
        ]
        assert len(subagent_started) == 1
        assert subagent_started[0].value["agent_name"] == "explore"
        assert len(subagent_completed) == 1

    def test_skill_invoked_emits_custom_event(self) -> None:
        adapter = CopilotAdapter()
        session = _load_session()
        events = list(adapter.read_events(session))

        skill_events = [
            e for e in events if isinstance(e, CustomEvent) and e.name == "copilot_skill_invoked"
        ]
        assert len(skill_events) == 1
        assert skill_events[0].value["name"] == "agent-browser"

    def test_source_entry_round_trip_preserves_raw_lines(self, tmp_path: Path) -> None:
        adapter = CopilotAdapter()
        session = _load_session()
        events = list(adapter.read_events(session))

        out = tmp_path / "out.jsonl"
        with open(out, "w") as f:
            adapter.write_events(events, f)

        # Round-trip should be byte-equivalent (modulo trailing newline)
        original = SAMPLE_EVENTS.read_text().rstrip("\n").splitlines()
        round_tripped = out.read_text().rstrip("\n").splitlines()
        assert round_tripped == original


class TestCopilotParseSourceEntry:
    def test_parse_session_start_emits_run_started(self) -> None:
        adapter = CopilotAdapter()
        entry = {
            "type": "session.start",
            "data": {"sessionId": "abc", "context": {"cwd": "/x"}},
            "id": "evt-0",
            "timestamp": "2026-05-04T00:00:00.000Z",
            "_timestamp_ms": 0,
        }
        events = adapter.parse_source_entry(entry, entry_index=0, session_id="abc")
        assert any(isinstance(e, RunStartedEvent) for e in events)

    def test_parse_assistant_message_emits_text_and_tool_chunks(self) -> None:
        adapter = CopilotAdapter()
        entry = {
            "type": "assistant.message",
            "data": {
                "messageId": "msg-1",
                "content": "hello",
                "toolRequests": [
                    {"toolCallId": "tc1", "name": "view", "arguments": {"path": "/x"}}
                ],
            },
            "id": "evt-2",
            "timestamp": "2026-05-04T00:00:01.000Z",
            "_timestamp_ms": 0,
        }
        events = adapter.parse_source_entry(entry, entry_index=2, session_id="abc")
        text = [e for e in events if isinstance(e, TextMessageChunkEvent)]
        tools = [e for e in events if isinstance(e, ToolCallChunkEvent)]
        assert len(text) == 1
        assert text[0].role == Role.ASSISTANT
        assert text[0].delta == "hello"
        assert text[0].message_id == "msg-1"
        assert len(tools) == 1
        assert tools[0].tool_call_name == "view"
        # Tool calls must point back at the assistant message that issued
        # them so group_events() can attach them rather than treating them
        # as orphaned standalone calls.
        assert tools[0].parent_message_id == "msg-1"
        # delta is the JSON-serialised arguments
        assert json.loads(tools[0].delta or "{}") == {"path": "/x"}

    def test_parse_tool_execution_complete_emits_result(self) -> None:
        adapter = CopilotAdapter()
        entry = {
            "type": "tool.execution_complete",
            "data": {
                "toolCallId": "tc1",
                "success": True,
                "result": {"content": "short", "detailedContent": "long form"},
            },
            "id": "evt-3",
            "timestamp": "2026-05-04T00:00:02.000Z",
            "_timestamp_ms": 0,
        }
        events = adapter.parse_source_entry(entry, entry_index=3, session_id="abc")
        results = [e for e in events if isinstance(e, ToolCallResultEvent)]
        assert len(results) == 1
        # Should prefer detailedContent over content for fidelity
        assert results[0].result == "long form"

    def test_timestamp_fallback_uses_injected_ms(self) -> None:
        """When ``timestamp`` is missing, fall back to ``_timestamp_ms`` (server-injected)."""
        adapter = CopilotAdapter()
        entry = {
            "type": "user.message",
            "data": {"content": "hi"},
            "id": "evt-x",
            "timestamp": "",
            "_timestamp_ms": 1234567890123,
        }
        events = adapter.parse_source_entry(entry, entry_index=1, session_id="abc")
        text_events = [e for e in events if isinstance(e, TextMessageChunkEvent)]
        assert len(text_events) == 1
        assert text_events[0].timestamp_ms == 1234567890123

    def test_skips_daemon_metadata(self) -> None:
        adapter = CopilotAdapter()
        entry = {"type": "daemon_metadata", "metadata": {}, "_timestamp_ms": 1}
        assert adapter.parse_source_entry(entry, 0, "abc") == []

    def test_skips_skill_context_user_message(self) -> None:
        """Copilot injects a synthetic ``<skill-context>`` user.message after
        ``skill.invoked``. It's scaffolding for the model, not a real user
        prompt — emitting it as a TextMessageChunkEvent makes the dashboard
        render it as its own user turn and pollutes turn titling. We already
        emit ``copilot_skill_invoked`` for the activation itself."""
        adapter = CopilotAdapter()
        entry = {
            "type": "user.message",
            "data": {
                "content": (
                    '<skill-context name="agent-browser">\n'
                    "Base directory for this skill: /tmp/skills/agent-browser\n"
                ),
            },
            "id": "evt-skill-ctx",
            "timestamp": "2026-05-04T00:00:00.000Z",
            "_timestamp_ms": 1,
        }
        events = adapter.parse_source_entry(entry, entry_index=1, session_id="abc")
        text_events = [e for e in events if isinstance(e, TextMessageChunkEvent)]
        assert text_events == []

    def test_real_user_message_still_emitted(self) -> None:
        """Sanity check that a normal user message still produces a
        TextMessageChunkEvent — i.e. the skill-context filter only catches
        the prefix it's meant to."""
        adapter = CopilotAdapter()
        entry = {
            "type": "user.message",
            "data": {"content": "hi there"},
            "id": "evt-real-user",
            "timestamp": "2026-05-04T00:00:00.000Z",
            "_timestamp_ms": 1,
        }
        events = adapter.parse_source_entry(entry, entry_index=1, session_id="abc")
        text_events = [e for e in events if isinstance(e, TextMessageChunkEvent)]
        assert len(text_events) == 1
        assert text_events[0].delta == "hi there"

    def test_apply_patch_string_args_wrapped_as_input(self) -> None:
        """Custom tools (``apply_patch``) ship a string body; we wrap it as
        ``{"input": <body>}`` so the backend's args decoder sees a dict."""
        adapter = CopilotAdapter()
        patch_body = "*** Begin Patch\n*** Add File: /tmp/x.md\n+hi\n*** End Patch\n"
        entry = {
            "type": "assistant.message",
            "data": {
                "messageId": "msg-1",
                "content": "",
                "toolRequests": [
                    {
                        "toolCallId": "custom_call_1",
                        "name": "apply_patch",
                        "arguments": patch_body,
                    }
                ],
            },
            "id": "evt-1",
            "timestamp": "2026-05-04T00:00:01.000Z",
            "_timestamp_ms": 0,
        }
        events = adapter.parse_source_entry(entry, entry_index=1, session_id="abc")
        tool_calls = [e for e in events if isinstance(e, ToolCallChunkEvent)]
        assert len(tool_calls) == 1
        delta = json.loads(tool_calls[0].delta or "{}")
        assert delta == {"input": patch_body}


class TestResolveSweAgentModel:
    def test_falls_back_to_placeholder_when_unset(self, monkeypatch: Any) -> None:
        monkeypatch.delenv("COPILOT_AGENT_MODEL", raising=False)
        assert resolve_swe_agent_model() == "swe-agent"

    def test_strips_provider_prefix(self, monkeypatch: Any) -> None:
        monkeypatch.setenv("COPILOT_AGENT_MODEL", "sweagent-capi:gpt-5.3-codex")
        assert resolve_swe_agent_model() == "gpt-5.3-codex"

    def test_returns_value_unchanged_when_no_colon(self, monkeypatch: Any) -> None:
        monkeypatch.setenv("COPILOT_AGENT_MODEL", "gpt-5.3-codex")
        assert resolve_swe_agent_model() == "gpt-5.3-codex"

    def test_falls_back_when_empty(self, monkeypatch: Any) -> None:
        monkeypatch.setenv("COPILOT_AGENT_MODEL", "  ")
        assert resolve_swe_agent_model() == "swe-agent"
