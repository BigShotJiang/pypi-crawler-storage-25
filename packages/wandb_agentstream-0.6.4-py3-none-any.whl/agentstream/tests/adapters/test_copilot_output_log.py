"""Tests for the Copilot cloud SWE-agent ``output.log`` adapter path.

The cloud agent step's stdout is captured by the GitHub Actions runner at
``$RUNNER_TEMP/runtime-logs/output.log``. The shared ``CopilotAdapter``
parses both this format and the local CLI's ``events.jsonl`` by
dispatching on filename. These tests exercise the output.log parser
against the captured fixture plus targeted inputs that cover scalar /
literal-block args, the ``Problem statement:`` block, the final-answer
synthesis from the last ``report_progress`` call, and mid-flight
truncation.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from agentstream.adapters.base import Session
from agentstream.adapters.copilot import (
    CopilotAdapter,
    _copilot_home,
    _extract_problem_statement,
    _parse_function_block,
    _parse_output_log,
    _parse_yaml_dict,
    _split_problem_statement_comments,
)
from agentstream.events import (
    CustomEvent,
    Role,
    TextMessageChunkEvent,
    ToolCallChunkEvent,
    ToolCallResultEvent,
)

CLOUD_FIXTURE = (
    Path(__file__).parent.parent / "fixtures" / "copilot" / "cloud" / "output_log_realworld.log"
)


def _session(path: Path, sid: str = "out-test") -> Session:
    return Session(
        id=sid,
        path=path,
        format="copilot",
        modified_at=path.stat().st_mtime,
    )


# ---------------------------------------------------------------------------
# Low-level YAML-ish parser primitives
# ---------------------------------------------------------------------------


class TestParseYamlDict:
    def test_scalar_key_value_pairs(self) -> None:
        """Pure strings stay strings; numeric scalars are coerced to int."""
        text = "    method: list_workflow_runs\n    owner: wandb\n    per_page: 5\n"
        result, _ = _parse_yaml_dict(text.split("\n"), 0, 4, key_indent=4)
        assert result == {"method": "list_workflow_runs", "owner": "wandb", "per_page": 5}

    def test_scalar_coercion_covers_int_float_bool_null(self) -> None:
        text = (
            "    a: 5\n"
            "    b: -3\n"
            "    c: 1.5\n"
            "    d: true\n"
            "    e: False\n"
            "    f: null\n"
            "    g: hello\n"
            "    h: 2026-05-09\n"  # date-like — not numeric, stays string
            "    i: 0123abc\n"  # non-numeric, stays string
        )
        result, _ = _parse_yaml_dict(text.split("\n"), 0, 9, key_indent=4)
        assert result == {
            "a": 5,
            "b": -3,
            "c": 1.5,
            "d": True,
            "e": False,
            "f": None,
            "g": "hello",
            "h": "2026-05-09",
            "i": "0123abc",
        }

    def test_scalar_with_embedded_colon_stays_string(self) -> None:
        """``commitMessage: chore: fix bug`` — value is everything after the
        FIRST colon. The result still must be a string, not coerced."""
        text = "    commitMessage: chore: fix bug\n"
        result, _ = _parse_yaml_dict(text.split("\n"), 0, 1, key_indent=4)
        assert result == {"commitMessage": "chore: fix bug"}

    def test_literal_block_value_with_json_parses_to_dict(self) -> None:
        """A YAML ``|`` block whose body is a JSON object — common shape for
        github-mcp-server tools' ``workflow_runs_filter`` arg — gets parsed
        into a real dict so the dashboard shows the structure instead of an
        escaped JSON string."""
        text = (
            "    workflow_runs_filter: |\n"
            "      {\n"
            '        "branch": "main"\n'
            "      }\n"
            "    method: list\n"
        )
        result, _ = _parse_yaml_dict(text.split("\n"), 0, 5, key_indent=4)
        assert result["method"] == "list"
        assert result["workflow_runs_filter"] == {"branch": "main"}

    def test_literal_block_value_with_json_array_parses_to_list(self) -> None:
        """``rg``/``glob``'s ``paths`` arg ships as a JSON array literal block."""
        text = '    paths: |\n      [\n        "src/foo",\n        "src/bar"\n      ]\n'
        result, _ = _parse_yaml_dict(text.split("\n"), 0, 5, key_indent=4)
        assert result["paths"] == ["src/foo", "src/bar"]

    def test_literal_block_value_keeps_non_json_body_as_string(self) -> None:
        """A literal block carrying a shell heredoc / source code / prose is
        NOT JSON and must stay as the original multi-line string."""
        text = "    command: |\n      python - <<'PY'\n      print('hi')\n      PY\n"
        result, _ = _parse_yaml_dict(text.split("\n"), 0, 4, key_indent=4)
        assert result["command"] == "python - <<'PY'\nprint('hi')\nPY"

    def test_literal_block_with_scalar_json_stays_string(self) -> None:
        """A literal block containing a bare JSON scalar (number, bool) is
        kept as the raw string. Only dicts/lists get coerced — coercing
        scalars here would change behavior for blocks that legitimately
        contain a single numeric token."""
        text = "    timeout: |\n      42\n"
        result, _ = _parse_yaml_dict(text.split("\n"), 0, 2, key_indent=4)
        assert result["timeout"] == "42"

    def test_stops_at_dedent(self) -> None:
        """Once we hit a line less-indented than ``key_indent`` we stop."""
        text = "    foo: 1\n    bar: 2\n  back: top\n    leftover: 3\n"
        result, end = _parse_yaml_dict(text.split("\n"), 0, 4, key_indent=4)
        assert result == {"foo": 1, "bar": 2}
        # Returned ``end`` points at the dedented line, so the caller can pick up
        assert end == 2


class TestParseFunctionBlock:
    def test_minimal_block_scalar_result(self) -> None:
        text = (
            "function:\n"
            "  name: bash\n"
            "  args:\n"
            "    command: ls\n"
            "  result: <exited with exit code 0>\n"
        )
        lines = text.split("\n")
        block = _parse_function_block(lines, 0, len(lines))
        assert block == {
            "name": "bash",
            "args": {"command": "ls"},
            "result": "<exited with exit code 0>",
        }

    def test_literal_block_args_and_result(self) -> None:
        text = (
            "function:\n"
            "  name: bash\n"
            "  args:\n"
            "    command: |\n"
            "      python - <<'PY'\n"
            "      print('hi')\n"
            "      PY\n"
            "    description: Run python\n"
            "  result: |\n"
            "    hi\n"
        )
        lines = text.split("\n")
        block = _parse_function_block(lines, 0, len(lines))
        assert block["name"] == "bash"
        assert block["args"]["command"] == "python - <<'PY'\nprint('hi')\nPY"
        assert block["args"]["description"] == "Run python"
        assert block["result"] == "hi"


# ---------------------------------------------------------------------------
# Problem statement extraction
# ---------------------------------------------------------------------------


class TestExtractProblemStatement:
    def test_basic_extraction(self) -> None:
        text = (
            "Reading job config for job ID abc.\n"
            "Problem statement:\n"
            "\n"
            "----\n"
            "Please fix the bug in foo.py.\n"
            "It crashes on startup.\n"
            "----\n"
            "Other context after the prompt.\n"
        )
        assert _extract_problem_statement(text.split("\n")) == (
            "Please fix the bug in foo.py.\nIt crashes on startup."
        )

    def test_returns_none_when_marker_missing(self) -> None:
        assert _extract_problem_statement(["nothing here"]) is None

    def test_returns_none_when_closing_fence_missing(self) -> None:
        """Mid-flight capture before the prompt finished writing."""
        text = "Problem statement:\n\n----\nUnfinished prompt body\n"
        assert _extract_problem_statement(text.split("\n")) is None

    def test_strips_leading_and_trailing_blanks(self) -> None:
        text = "Problem statement:\n\n----\n\n\nThe actual prompt.\n\n\n----\nfooter\n"
        assert _extract_problem_statement(text.split("\n")) == "The actual prompt."


# ---------------------------------------------------------------------------
# Comment splitting (PR comment thread → role-tagged messages)
# ---------------------------------------------------------------------------


class TestSplitProblemStatementComments:
    def test_returns_none_when_no_comments_block(self) -> None:
        assert _split_problem_statement_comments("just a plain prompt") is None

    def test_user_and_agent_comments_get_role_tagged(self) -> None:
        text = (
            "<comments>\n"
            "<pr_comments>\n"
            "<comment_old>\n"
            "<author>@vanpelt</author>\n"
            "@copilot please fix the bug\n"
            "</comment_old>\n"
            "<comment_old>\n"
            "<author>@copilot</author>\n"
            "Fixed in abc123.\n"
            "</comment_old>\n"
            "<comment_new>\n"
            "<comment_id>123</comment_id>\n"
            "<author>@vanpelt</author>\n"
            "Now please add a test.\n"
            "</comment_new>\n"
            "</pr_comments>\n"
            "</comments>\n"
        )
        result = _split_problem_statement_comments(text)
        assert result == [
            {"role": "user", "content": "@copilot please fix the bug", "author": "@vanpelt"},
            {"role": "assistant", "content": "Fixed in abc123.", "author": "@copilot"},
            {"role": "user", "content": "Now please add a test.", "author": "@vanpelt"},
        ]

    def test_copilot_bot_author_treated_as_assistant(self) -> None:
        text = (
            "<comments>\n"
            "<comment_old>\n"
            "<author>@copilot[bot]</author>\n"
            "From the bot account.\n"
            "</comment_old>\n"
            "</comments>\n"
        )
        result = _split_problem_statement_comments(text)
        assert result is not None
        assert result[0]["role"] == "assistant"

    def test_copilot_swe_agent_login_treated_as_assistant(self) -> None:
        """The cloud SWE-agent's actual GitHub login is
        ``copilot-swe-agent[bot]`` — it shows up under that handle in
        some PR comment thread captures, so role-mapping must accept it."""
        text = (
            "<comments>\n"
            "<comment_old>\n"
            "<author>@copilot-swe-agent[bot]</author>\n"
            "Posted from the SWE-agent service account.\n"
            "</comment_old>\n"
            "</comments>\n"
        )
        result = _split_problem_statement_comments(text)
        assert result is not None
        assert result[0]["role"] == "assistant"

    def test_author_matching_is_case_insensitive_and_whitespace_tolerant(self) -> None:
        """Matching tolerates ``  @Copilot \n`` etc. — comment captures
        sometimes carry trailing whitespace or differ in case across
        versions of the upstream renderer."""
        text = (
            "<comments>\n"
            "<comment_old>\n"
            "<author>  @Copilot  </author>\n"
            "Mixed-case, padded handle.\n"
            "</comment_old>\n"
            "</comments>\n"
        )
        result = _split_problem_statement_comments(text)
        assert result is not None
        assert result[0]["role"] == "assistant"

    def test_unrelated_bot_author_classified_as_user(self) -> None:
        """Other bot accounts (dependabot, github-actions, etc.) leaving
        comments on the same PR are NOT the agent — they're third-party
        actors and should classify as ``user``."""
        text = (
            "<comments>\n"
            "<comment_old>\n"
            "<author>@dependabot[bot]</author>\n"
            "Bumps requests from 2.31.0 to 2.32.0.\n"
            "</comment_old>\n"
            "</comments>\n"
        )
        result = _split_problem_statement_comments(text)
        assert result is not None
        assert result[0]["role"] == "user"

    def test_truncated_comments_block_still_parses_closed_comments(self) -> None:
        """Mid-flight captures may truncate the problem statement before
        ``</comments>`` is written. We still parse whichever
        ``<comment_*>`` blocks closed inside the partial window — better
        than dumping the whole problem statement as one giant user
        message (the prior fall-through behavior)."""
        text = (
            "<comments>\n"
            "<comment_old>\n"
            "<author>@vanpelt</author>\n"
            "First, fully-closed comment.\n"
            "</comment_old>\n"
            "<comment_new>\n"
            "<author>@vanpelt</author>\n"
            "Latest comment, also closed before the capture cut off.\n"
            "</comment_new>\n"
            # Note: no </comments> here — capture truncated mid-flight.
        )
        result = _split_problem_statement_comments(text)
        assert result is not None
        assert len(result) == 2
        assert result[0]["content"] == "First, fully-closed comment."
        assert result[1]["content"] == ("Latest comment, also closed before the capture cut off.")

    def test_strips_metadata_tags_from_body(self) -> None:
        text = (
            "<comments>\n"
            "<comment_new>\n"
            "<comment_id>4410852344</comment_id>\n"
            "<author>@vanpelt</author>\n"
            "Just the body, please.\n"
            "</comment_new>\n"
            "</comments>\n"
        )
        result = _split_problem_statement_comments(text)
        assert result == [
            {"role": "user", "content": "Just the body, please.", "author": "@vanpelt"},
        ]

    def test_returns_none_when_comments_block_is_empty(self) -> None:
        assert _split_problem_statement_comments("<comments>\n\n</comments>") is None


# ---------------------------------------------------------------------------
# _parse_output_log — direct unit tests
# ---------------------------------------------------------------------------


class TestParseOutputLog:
    def test_empty_input(self) -> None:
        assert _parse_output_log("", file_mtime_ms=0) == []

    def test_single_function_block_emits_assistant_and_result(self) -> None:
        text = (
            "function:\n  name: bash\n  args:\n    command: ls\n  result: |\n    file1\n    file2\n"
        )
        entries = _parse_output_log(text, file_mtime_ms=1_700_000_000_000)
        types = [e["type"] for e in entries]
        assert types == ["assistant.message", "tool.execution_complete"]
        assistant, result = entries
        tr = assistant["data"]["toolRequests"][0]
        assert tr["name"] == "bash"
        assert tr["arguments"] == {"command": "ls"}
        assert tr["toolCallId"] == "out-tool-0"
        # tool.execution_complete keys back to the same toolCallId
        assert result["data"]["toolCallId"] == "out-tool-0"
        assert result["data"]["result"]["content"] == "file1\nfile2"
        # Ids chained
        assert assistant["id"] == "out-0"
        assert assistant["parentId"] is None
        assert result["parentId"] == "out-0"

    def test_problem_statement_emitted_as_user_message(self) -> None:
        text = (
            "Problem statement:\n\n"
            "----\n"
            "Fix the failing test.\n"
            "----\n"
            "function:\n"
            "  name: bash\n"
            "  args:\n"
            "    command: pytest\n"
            "  result: <exited with exit code 0>\n"
        )
        entries = _parse_output_log(text, file_mtime_ms=0)
        assert entries[0]["type"] == "user.message"
        assert entries[0]["data"]["content"] == "Fix the failing test."
        assert [e["type"] for e in entries] == [
            "user.message",
            "assistant.message",
            "tool.execution_complete",
        ]

    def test_report_progress_does_not_synthesize_trailing_assistant_message(self) -> None:
        """``report_progress`` is the agent's running plan, not a chat turn.
        The normalizer converts its ``prDescription`` into TODO updates;
        the adapter must NOT also leak it into a trailing assistant.message
        — that produced the duplicate "[ ]/[x]" chat messages users saw."""
        text = (
            "function:\n"
            "  name: bash\n"
            "  args:\n"
            "    command: ls\n"
            "  result: <exited with exit code 0>\n"
            "function:\n"
            "  name: report_progress\n"
            "  args:\n"
            "    commitMessage: docs: update README\n"
            "    prDescription: |\n"
            "      - [x] Step one\n"
            "      - [ ] Step two\n"
            "  result: |\n"
            "    Progress reported successfully.\n"
        )
        entries = _parse_output_log(text, file_mtime_ms=0)
        # Two function blocks → two assistant.message + tool.execution_complete
        # pairs. No trailing synthetic assistant.message.
        assert [e["type"] for e in entries] == [
            "assistant.message",
            "tool.execution_complete",
            "assistant.message",
            "tool.execution_complete",
        ]
        # The report_progress tool call's args still carry prDescription so
        # the normalizer can pull the checklist out as TODO items.
        rp_call = entries[2]["data"]["toolRequests"][0]
        assert rp_call["name"] == "report_progress"
        assert "- [x] Step one" in rp_call["arguments"]["prDescription"]

    def test_problem_statement_with_comments_emits_per_comment_messages(self) -> None:
        """When the problem statement carries a ``<comments>`` block we split
        each comment into its own user/assistant turn instead of dumping the
        whole PR description + thread into one giant user message."""
        text = (
            "Problem statement:\n\n"
            "----\n"
            "<pr_title>some PR</pr_title>\n"
            "<comments>\n"
            "<comment_old>\n"
            "<author>@vanpelt</author>\n"
            "Initial ask.\n"
            "</comment_old>\n"
            "<comment_old>\n"
            "<author>@copilot</author>\n"
            "Earlier reply.\n"
            "</comment_old>\n"
            "<comment_new>\n"
            "<author>@vanpelt</author>\n"
            "Latest follow-up.\n"
            "</comment_new>\n"
            "</comments>\n"
            "----\n"
            "function:\n"
            "  name: bash\n"
            "  args:\n"
            "    command: ls\n"
            "  result: ok\n"
        )
        entries = _parse_output_log(text, file_mtime_ms=0)
        types = [e["type"] for e in entries]
        assert types[:3] == ["user.message", "assistant.message", "user.message"]
        assert entries[0]["data"]["content"] == "Initial ask."
        assert entries[1]["data"]["content"] == "Earlier reply."
        assert entries[1]["data"]["toolRequests"] == []
        assert entries[2]["data"]["content"] == "Latest follow-up."
        # The bash function block still parses as before.
        assert types[3] == "assistant.message"
        assert entries[3]["data"]["toolRequests"][0]["name"] == "bash"
        assert types[4] == "tool.execution_complete"

    def test_problem_statement_without_comments_falls_back_to_single_user_message(self) -> None:
        """Plain prompts (no ``<comments>`` block) keep the legacy behavior:
        one user.message containing the full body."""
        text = "Problem statement:\n\n----\nFix the failing test.\n----\n"
        entries = _parse_output_log(text, file_mtime_ms=0)
        assert [e["type"] for e in entries] == ["user.message"]
        assert entries[0]["data"]["content"] == "Fix the failing test."

    def test_reply_to_comment_synthesizes_final_assistant_message(self) -> None:
        """A trailing ``reply_to_comment`` tool call carries the agent's
        user-visible final response in its ``reply`` arg — promote it to a
        trailing assistant.message so the timeline ends on a proper turn."""
        text = (
            "function:\n"
            "  name: bash\n"
            "  args:\n"
            "    command: pytest\n"
            "  result: <exited with exit code 0>\n"
            "function:\n"
            "  name: reply_to_comment\n"
            "  args:\n"
            "    comment_id: '123'\n"
            "    reply: |\n"
            "      Done — all tests pass.\n"
            "      See commit abc123.\n"
            "  result: |\n"
            "    Reply posted.\n"
        )
        entries = _parse_output_log(text, file_mtime_ms=0)
        types = [e["type"] for e in entries]
        assert types == [
            "assistant.message",
            "tool.execution_complete",
            "assistant.message",
            "tool.execution_complete",
            "assistant.message",
        ]
        final = entries[-1]
        assert final["data"]["content"] == "Done — all tests pass.\nSee commit abc123."
        assert final["data"]["toolRequests"] == []

    def test_reply_to_comment_is_only_source_of_final_assistant_message(self) -> None:
        """``reply_to_comment`` is the only tool whose arg becomes the trailing
        assistant.message. ``report_progress`` calls in the same file are
        ignored for this purpose — they're TODO updates, not chat turns."""
        text = (
            "function:\n"
            "  name: report_progress\n"
            "  args:\n"
            "    prDescription: |\n"
            "      - [ ] Mid-run plan.\n"
            "  result: ok\n"
            "function:\n"
            "  name: reply_to_comment\n"
            "  args:\n"
            "    reply: |\n"
            "      Final answer to the user.\n"
            "  result: ok\n"
        )
        entries = _parse_output_log(text, file_mtime_ms=0)
        assert entries[-1]["type"] == "assistant.message"
        assert entries[-1]["data"]["content"] == "Final answer to the user."
        # And nothing else synthesized an extra trailing message — exactly one
        # closing assistant.message after the two function-block pairs.
        types = [e["type"] for e in entries]
        assert types.count("assistant.message") == 3  # 2 tool calls + 1 trailing

    def test_no_trailing_message_when_only_report_progress_present(self) -> None:
        """Truncated mid-flight runs that ended on ``report_progress`` (before
        the agent reached ``reply_to_comment``) should NOT synthesize a
        trailing chat turn — the run simply has no closing assistant message,
        which is accurate."""
        text = (
            "function:\n"
            "  name: report_progress\n"
            "  args:\n"
            "    prDescription: |\n"
            "      - [x] Done.\n"
            "  result: ok\n"
        )
        entries = _parse_output_log(text, file_mtime_ms=0)
        assert [e["type"] for e in entries] == [
            "assistant.message",
            "tool.execution_complete",
        ]

    def test_boot_noise_and_turn_markers_are_ignored(self) -> None:
        """``::add-mask::``, node warnings, ``in-session runtime checkQuota``
        markers etc. live at zero indent. They must not be treated as
        function: block boundaries or invent stray entries."""
        text = (
            "(node:5412) ExperimentalWarning: SQLite is experimental\n"
            "Loaded 4 secrets\n"
            "::add-mask::sha\n"
            "Reading job config for job ID abc.\n"
            "in-session runtime checkQuota callback: preRequest invoked\n"
            "function:\n"
            "  name: bash\n"
            "  args:\n"
            "    command: ls\n"
            "  result: ok\n"
            "in-session runtime checkQuota callback: skipped\n"
        )
        entries = _parse_output_log(text, file_mtime_ms=0)
        # Exactly one tool call + one result — no spurious entries from boot noise.
        assert [e["type"] for e in entries] == ["assistant.message", "tool.execution_complete"]

    def test_multiple_function_blocks_separated_by_blank_lines(self) -> None:
        text = (
            "function:\n"
            "  name: view\n"
            "  args:\n"
            "    path: /a\n"
            "  result: ok-a\n"
            "\n"
            "function:\n"
            "  name: view\n"
            "  args:\n"
            "    path: /b\n"
            "  result: ok-b\n"
        )
        entries = _parse_output_log(text, file_mtime_ms=0)
        assert [e["type"] for e in entries] == [
            "assistant.message",
            "tool.execution_complete",
            "assistant.message",
            "tool.execution_complete",
        ]
        assert entries[0]["data"]["toolRequests"][0]["arguments"] == {"path": "/a"}
        assert entries[2]["data"]["toolRequests"][0]["arguments"] == {"path": "/b"}
        # toolCallIds are positional and match across pairs
        assert entries[0]["data"]["toolRequests"][0]["toolCallId"] == "out-tool-0"
        assert entries[1]["data"]["toolCallId"] == "out-tool-0"
        assert entries[2]["data"]["toolRequests"][0]["toolCallId"] == "out-tool-1"
        assert entries[3]["data"]["toolCallId"] == "out-tool-1"

    def test_truncated_tail_function_block(self) -> None:
        """Mid-flight capture: file ends partway through a function: block.
        We should still emit what we got rather than dropping the block.
        """
        text = "function:\n  name: bash\n  args:\n    command: ls\n"
        entries = _parse_output_log(text, file_mtime_ms=0)
        # No `result:` was written, but we still emit the assistant.message +
        # an empty result. The empty result is fine — incremental sync will
        # replace it on the next pass when the file has grown.
        assert entries[0]["type"] == "assistant.message"
        assert entries[0]["data"]["toolRequests"][0]["name"] == "bash"
        assert entries[1]["type"] == "tool.execution_complete"
        assert entries[1]["data"]["result"]["content"] == ""


# ---------------------------------------------------------------------------
# CopilotAdapter — output.log path through the public API
# ---------------------------------------------------------------------------


class TestOutputLogAdapterEndToEnd:
    def test_read_entries_from_real_fixture(self) -> None:
        adapter = CopilotAdapter()
        # The real fixture is named output_log_realworld.log — the adapter
        # dispatches on the literal name "output.log" under "runtime-logs",
        # so we point at the fixture directly via session.path. We're
        # testing the parser path, not the matches_path gate.
        session = _session(CLOUD_FIXTURE)
        # Force the dispatch by using a path that triggers _is_copilot_output_log.
        # _read_output_log_entries reads from session.path regardless.
        entries = adapter._read_output_log_entries(session)
        assert len(entries) >= 40  # 22 tool calls × 2 + at least the comment thread
        decoded = [json.loads(e["entry_content"]) for e in entries]
        types = [d["type"] for d in decoded]
        # The captured run starts with the comment thread (split into per-author
        # turns) — the very first entry is a user comment.
        assert types[0] == "user.message"
        # The fixture is a mid-flight capture that ended on a tool execution;
        # there's no ``reply_to_comment`` in the file, so the parser
        # (correctly) does NOT synthesize a trailing assistant.message —
        # ``report_progress`` is treated as a TODO update instead.
        assert types[-1] == "tool.execution_complete"
        # Every tool.execution_complete must reference a toolCallId we saw
        # in a preceding assistant.message.
        known_ids: set[str] = set()
        for d in decoded:
            if d["type"] == "assistant.message":
                for tr in d["data"]["toolRequests"]:
                    known_ids.add(tr["toolCallId"])
            elif d["type"] == "tool.execution_complete":
                assert d["data"]["toolCallId"] in known_ids

    def test_read_events_emits_run_framing(self, tmp_path: Path, monkeypatch: Any) -> None:
        # Place an output.log at the canonical runtime-logs path so dispatch fires.
        runtime_logs = tmp_path / "runtime-logs"
        runtime_logs.mkdir()
        log = runtime_logs / "output.log"
        log.write_text(
            "Problem statement:\n\n----\nDo a thing.\n----\n"
            "function:\n  name: bash\n  args:\n    command: ls\n  result: ok\n"
        )
        adapter = CopilotAdapter()
        session = _session(log)
        events = list(adapter.read_events(session))
        types = [type(e).__name__ for e in events]
        assert types[0] == "RunStartedEvent"
        assert types[-1] == "RunFinishedEvent"
        assert any(isinstance(e, CustomEvent) and e.name == "source_entry" for e in events)
        text_chunks = [e for e in events if isinstance(e, TextMessageChunkEvent)]
        # User prompt + (nothing for the empty assistant.content) — at least one user chunk.
        assert any(e.role == Role.USER for e in text_chunks)
        tool_chunks = [e for e in events if isinstance(e, ToolCallChunkEvent)]
        assert tool_chunks and tool_chunks[0].tool_call_name == "bash"
        results = [e for e in events if isinstance(e, ToolCallResultEvent)]
        assert results and "ok" in results[0].result

    def test_parse_source_entry_round_trip(self) -> None:
        """Synthesized output.log entries must flow through the same
        ``parse_source_entry`` path as real ``events.jsonl`` entries — the
        normalization worker doesn't know which format produced them."""
        adapter = CopilotAdapter()
        session = _session(CLOUD_FIXTURE)
        entries = adapter._read_output_log_entries(session)
        for entry in entries:
            decoded = json.loads(entry["entry_content"])
            decoded["_timestamp_ms"] = entry["entry_timestamp_ms"]
            agui = adapter.parse_source_entry(decoded, entry["entry_index"], session.id)
            assert agui, f"empty AG-UI output for entry {entry['entry_index']}"


# ---------------------------------------------------------------------------
# Path detection + discovery
# ---------------------------------------------------------------------------


class TestOutputLogPathDetection:
    def test_matches_runtime_logs_output_log(self, tmp_path: Path, monkeypatch: Any) -> None:
        runner_temp = tmp_path / "_temp"
        runtime_logs = runner_temp / "runtime-logs"
        runtime_logs.mkdir(parents=True)
        log = runtime_logs / "output.log"
        log.write_text("x")
        monkeypatch.setenv("RUNNER_TEMP", str(runner_temp))
        adapter = CopilotAdapter()
        assert adapter.matches_path(log)

    def test_does_not_match_output_log_outside_runtime_logs(
        self, tmp_path: Path, monkeypatch: Any
    ) -> None:
        """A stray ``output.log`` not under ``runtime-logs/`` must not be
        attributed to the Copilot agent."""
        runner_temp = tmp_path / "_temp"
        other = runner_temp / "logs"
        other.mkdir(parents=True)
        log = other / "output.log"
        log.write_text("x")
        monkeypatch.setenv("RUNNER_TEMP", str(runner_temp))
        adapter = CopilotAdapter()
        assert not adapter.matches_path(log)

    def test_does_not_match_runtime_logs_when_outside_runner_temp(
        self, tmp_path: Path, monkeypatch: Any
    ) -> None:
        """A ``runtime-logs/output.log`` somewhere else on disk (not under
        ``$RUNNER_TEMP``) must not match — that name pattern is generic
        enough that other tools could write it."""
        unrelated = tmp_path / "elsewhere" / "runtime-logs"
        unrelated.mkdir(parents=True)
        log = unrelated / "output.log"
        log.write_text("x")
        runner_temp = tmp_path / "_temp"
        runner_temp.mkdir()
        monkeypatch.setenv("RUNNER_TEMP", str(runner_temp))
        adapter = CopilotAdapter()
        assert not adapter.matches_path(log)

    def test_session_id_uses_copilot_agent_session_id(
        self, tmp_path: Path, monkeypatch: Any
    ) -> None:
        runtime_logs = tmp_path / "runtime-logs"
        runtime_logs.mkdir()
        log = runtime_logs / "output.log"
        log.write_text("x")
        monkeypatch.setenv("COPILOT_AGENT_SESSION_ID", "bbc1c509-990c-41c7-af24-424ce8aea5b9")
        adapter = CopilotAdapter()
        assert adapter.get_session_id(log) == "bbc1c509-990c-41c7-af24-424ce8aea5b9"

    def test_session_id_falls_back_to_parent_dir_name(
        self, tmp_path: Path, monkeypatch: Any
    ) -> None:
        runtime_logs = tmp_path / "runtime-logs"
        runtime_logs.mkdir()
        log = runtime_logs / "output.log"
        log.write_text("x")
        monkeypatch.delenv("COPILOT_AGENT_SESSION_ID", raising=False)
        adapter = CopilotAdapter()
        assert adapter.get_session_id(log) == "runtime-logs"


class TestOutputLogDiscovery:
    def test_discovers_output_log_when_in_project(self, tmp_path: Path, monkeypatch: Any) -> None:
        runner_temp = tmp_path / "_temp"
        runtime_logs = runner_temp / "runtime-logs"
        runtime_logs.mkdir(parents=True)
        log = runtime_logs / "output.log"
        log.write_text("body")

        project = tmp_path / "workspace"
        project.mkdir()

        monkeypatch.setenv("RUNNER_TEMP", str(runner_temp))
        monkeypatch.setenv("GITHUB_WORKSPACE", str(project))
        monkeypatch.setenv("COPILOT_AGENT_SESSION_ID", "sess-42")
        monkeypatch.setenv("COPILOT_AGENT_BRANCH_NAME", "feat/x")
        # Isolate from the host's ~/.copilot
        monkeypatch.setenv("COPILOT_HOME", str(tmp_path / "no-copilot-home"))
        _copilot_home.cache_clear()

        adapter = CopilotAdapter()
        sessions = adapter.discover_sessions(project)
        assert len(sessions) == 1
        assert sessions[0].id == "sess-42"
        assert sessions[0].path == log
        assert sessions[0].metadata is not None
        assert sessions[0].metadata.get("cwd") == str(project)
        assert sessions[0].metadata.get("git_branch") == "feat/x"

    def test_skips_when_workspace_outside_project(self, tmp_path: Path, monkeypatch: Any) -> None:
        runner_temp = tmp_path / "_temp"
        runtime_logs = runner_temp / "runtime-logs"
        runtime_logs.mkdir(parents=True)
        (runtime_logs / "output.log").write_text("body")

        project = tmp_path / "myproject"
        project.mkdir()
        other = tmp_path / "other"
        other.mkdir()

        monkeypatch.setenv("RUNNER_TEMP", str(runner_temp))
        monkeypatch.setenv("GITHUB_WORKSPACE", str(other))
        monkeypatch.setenv("COPILOT_HOME", str(tmp_path / "no-copilot-home"))
        _copilot_home.cache_clear()

        adapter = CopilotAdapter()
        assert adapter.discover_sessions(project) == []

    def test_skips_when_workspace_env_missing(self, tmp_path: Path, monkeypatch: Any) -> None:
        runner_temp = tmp_path / "_temp"
        runtime_logs = runner_temp / "runtime-logs"
        runtime_logs.mkdir(parents=True)
        (runtime_logs / "output.log").write_text("body")

        project = tmp_path / "myproject"
        project.mkdir()

        monkeypatch.setenv("RUNNER_TEMP", str(runner_temp))
        monkeypatch.delenv("GITHUB_WORKSPACE", raising=False)
        monkeypatch.setenv("COPILOT_HOME", str(tmp_path / "no-copilot-home"))
        _copilot_home.cache_clear()

        adapter = CopilotAdapter()
        assert adapter.discover_sessions(project) == []
