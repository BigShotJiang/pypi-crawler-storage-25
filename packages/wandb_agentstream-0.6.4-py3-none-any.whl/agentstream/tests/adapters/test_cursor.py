"""Tests for Cursor adapter."""

from __future__ import annotations

import json
import sqlite3
import sys
from pathlib import Path
from typing import Any
from unittest.mock import patch

import pytest

from agentstream.adapters import cursor as cursor_module
from agentstream.adapters.base import Session
from agentstream.adapters.cursor import (
    CursorAdapter,
    _get_cursor_user_dir,
    _parse_ms_timestamp,
    _uri_to_path,
    compute_synthetic_timestamps,
    entries_lack_bubble_timestamps,
    load_composers,
)
from agentstream.events import (
    EventType,
    ReasoningMessageChunkEvent,
    Role,
    TextMessageChunkEvent,
    ToolCallChunkEvent,
    ToolCallResultEvent,
)

# =============================================================================
# Helper Functions Tests
# =============================================================================


class TestParseMsTimestamp:
    def test_integer_milliseconds(self) -> None:
        """Integer millisecond timestamps pass through."""
        ts = _parse_ms_timestamp(1704067200000, fallback=0)
        assert ts == 1704067200000

    def test_float_milliseconds(self) -> None:
        """Float millisecond timestamps are converted to int."""
        ts = _parse_ms_timestamp(1704067200000.5, fallback=0)
        assert ts == 1704067200000

    def test_seconds_converted_to_milliseconds(self) -> None:
        """Timestamps in seconds are converted to milliseconds."""
        ts = _parse_ms_timestamp(1704067200, fallback=0)
        assert ts == 1704067200000

    def test_iso_string(self) -> None:
        """ISO 8601 strings are parsed correctly."""
        ts = _parse_ms_timestamp("2024-01-01T00:00:00.000Z", fallback=0)
        assert ts == 1704067200000

    def test_iso_string_without_z(self) -> None:
        """ISO 8601 strings with +00:00 are parsed correctly."""
        ts = _parse_ms_timestamp("2024-01-01T00:00:00+00:00", fallback=0)
        assert ts == 1704067200000

    def test_none_returns_fallback(self) -> None:
        """None value returns fallback."""
        ts = _parse_ms_timestamp(None, fallback=12345)
        assert ts == 12345

    def test_invalid_string_returns_fallback(self) -> None:
        """Invalid string returns fallback."""
        ts = _parse_ms_timestamp("not-a-timestamp", fallback=12345)
        assert ts == 12345

    def test_numeric_string(self) -> None:
        """Numeric strings are parsed as timestamps."""
        ts = _parse_ms_timestamp("1704067200000", fallback=0)
        assert ts == 1704067200000


class TestUriToPath:
    def test_valid_file_uri(self) -> None:
        """Valid file:// URIs are converted to paths."""
        path = _uri_to_path("file:///Users/test/project")
        assert path == Path("/Users/test/project")

    def test_uri_with_spaces(self) -> None:
        """URIs with encoded spaces are decoded."""
        path = _uri_to_path("file:///Users/test/my%20project")
        assert path == Path("/Users/test/my project")

    def test_non_file_uri_returns_none(self) -> None:
        """Non-file URIs return None."""
        assert _uri_to_path("https://example.com") is None
        assert _uri_to_path("") is None
        assert _uri_to_path("not-a-uri") is None


class TestGetCursorUserDir:
    def test_darwin(self) -> None:
        """macOS returns ~/Library/Application Support/Cursor/User."""
        with (
            patch.object(sys, "platform", "darwin"),
            patch.object(Path, "home", return_value=Path("/Users/test")),
        ):
            path = _get_cursor_user_dir()
            assert path == Path("/Users/test/Library/Application Support/Cursor/User")

    def test_win32(self) -> None:
        """Windows returns %APPDATA%/Cursor/User."""
        with (
            patch.object(sys, "platform", "win32"),
            patch.object(Path, "home", return_value=Path("C:/Users/test")),
        ):
            path = _get_cursor_user_dir()
            assert path == Path("C:/Users/test/AppData/Roaming/Cursor/User")

    def test_linux(self) -> None:
        """Linux returns ~/.config/Cursor/User."""
        with (
            patch.object(sys, "platform", "linux"),
            patch.object(Path, "home", return_value=Path("/home/test")),
        ):
            path = _get_cursor_user_dir()
            assert path == Path("/home/test/.config/Cursor/User")


# =============================================================================
# load_composers Tests
# =============================================================================


def _write_headers(cursor_user: Path, composers: list[dict]) -> None:
    """Write a composer.composerHeaders entry to globalStorage."""
    global_storage = cursor_user / "globalStorage"
    global_storage.mkdir(parents=True, exist_ok=True)
    db = global_storage / "state.vscdb"
    conn = sqlite3.connect(db)
    conn.execute("CREATE TABLE IF NOT EXISTS ItemTable (key TEXT PRIMARY KEY, value BLOB)")
    conn.execute(
        "INSERT OR REPLACE INTO ItemTable (key, value) VALUES (?, ?)",
        ("composer.composerHeaders", json.dumps({"allComposers": composers})),
    )
    conn.commit()
    conn.close()


def _write_legacy_workspace(
    cursor_user: Path,
    workspace_id: str,
    composers: list[dict],
    folder_path: str | None = None,
) -> None:
    """Write a pre-migration per-workspace composer.composerData blob."""
    ws_dir = cursor_user / "workspaceStorage" / workspace_id
    ws_dir.mkdir(parents=True, exist_ok=True)
    if folder_path is not None:
        (ws_dir / "workspace.json").write_text(json.dumps({"folder": f"file://{folder_path}"}))
    db = ws_dir / "state.vscdb"
    conn = sqlite3.connect(db)
    conn.execute("CREATE TABLE IF NOT EXISTS ItemTable (key TEXT PRIMARY KEY, value BLOB)")
    conn.execute(
        "INSERT OR REPLACE INTO ItemTable (key, value) VALUES (?, ?)",
        ("composer.composerData", json.dumps({"allComposers": composers})),
    )
    conn.commit()
    conn.close()


class TestLoadComposers:
    def setup_method(self) -> None:
        # Reset the module-level "fallback warned" flag so each test sees a
        # fresh module state.
        cursor_module._fallback_warned = False

    def test_empty_cursor_user_returns_empty(self, tmp_path: Path) -> None:
        assert load_composers(tmp_path) == []

    def test_headers_only(self, tmp_path: Path) -> None:
        """Primary path: composer.composerHeaders enumerates everything."""
        _write_headers(
            tmp_path,
            [
                {
                    "composerId": "c1",
                    "name": "Alpha",
                    "createdAt": 1704067200000,
                    "lastUpdatedAt": 1704070800000,
                    "workspaceIdentifier": {
                        "id": "ws1",
                        "uri": {"fsPath": "/projects/alpha", "scheme": "file"},
                    },
                },
                {
                    "composerId": "empty-state-draft",
                    "workspaceIdentifier": {"id": "empty-window"},
                },
            ],
        )
        infos = load_composers(tmp_path)
        infos.sort(key=lambda i: i.composer_id)
        assert len(infos) == 2
        c1 = next(i for i in infos if i.composer_id == "c1")
        assert c1.source == "headers"
        assert c1.name == "Alpha"
        assert c1.fs_path == "/projects/alpha"
        assert c1.workspace_id == "ws1"
        assert c1.workspace_vscdb_path == tmp_path / "workspaceStorage" / "ws1" / "state.vscdb"
        assert c1.created_at == 1704067200000
        assert c1.last_updated_at == 1704070800000

        empty = next(i for i in infos if i.composer_id == "empty-state-draft")
        assert empty.fs_path is None
        assert empty.workspace_vscdb_path is None  # empty-window has no workspace DB

    def test_fallback_only(self, tmp_path: Path, caplog: Any) -> None:
        """Deprecated fallback: per-workspace composer.composerData -> allComposers."""
        _write_legacy_workspace(
            tmp_path,
            "ws-legacy",
            [{"composerId": "legacy-1", "createdAt": 1704067200}],
            folder_path="/projects/legacy",
        )
        with caplog.at_level("INFO"):
            infos = load_composers(tmp_path)
        assert len(infos) == 1
        info = infos[0]
        assert info.composer_id == "legacy-1"
        assert info.source == "workspace"
        assert info.fs_path == "/projects/legacy"
        assert info.workspace_id == "ws-legacy"
        # Timestamp in seconds is normalized to ms.
        assert info.created_at == 1704067200000
        # First-call fallback warning fires.
        assert any("pre-migration" in r.message for r in caplog.records)

    def test_headers_wins_on_duplicate_composer_id(self, tmp_path: Path) -> None:
        _write_headers(
            tmp_path,
            [
                {
                    "composerId": "shared",
                    "workspaceIdentifier": {
                        "id": "ws-new",
                        "uri": {"fsPath": "/new/path", "scheme": "file"},
                    },
                },
            ],
        )
        _write_legacy_workspace(
            tmp_path,
            "ws-old",
            [{"composerId": "shared"}],
            folder_path="/old/path",
        )
        infos = {i.composer_id: i for i in load_composers(tmp_path)}
        assert infos["shared"].source == "headers"
        assert infos["shared"].fs_path == "/new/path"
        # The legacy workspace also contributes the "shared" id via fallback,
        # which dedupe should drop — but any other legacy-only composers would
        # have been surfaced. Confirm only one composer with this id exists.
        assert len(infos) == 1

    def test_bare_list_composer_data_is_ignored(self, tmp_path: Path) -> None:
        """Bare-JSON-list composerData (very old format) is no longer supported."""
        ws_dir = tmp_path / "workspaceStorage" / "ws1"
        ws_dir.mkdir(parents=True)
        db = ws_dir / "state.vscdb"
        conn = sqlite3.connect(db)
        conn.execute("CREATE TABLE ItemTable (key TEXT PRIMARY KEY, value BLOB)")
        conn.execute(
            "INSERT INTO ItemTable (key, value) VALUES (?, ?)",
            ("composer.composerData", json.dumps([{"composerId": "bare"}])),
        )
        conn.commit()
        conn.close()

        assert load_composers(tmp_path) == []

    def test_headers_plus_fallback_union(self, tmp_path: Path) -> None:
        """Both sources are read; results are the union keyed by composer_id."""
        _write_headers(
            tmp_path,
            [
                {
                    "composerId": "from-headers",
                    "workspaceIdentifier": {
                        "id": "ws1",
                        "uri": {"fsPath": "/projects/alpha", "scheme": "file"},
                    },
                },
            ],
        )
        _write_legacy_workspace(
            tmp_path,
            "ws2",
            [{"composerId": "from-fallback"}],
            folder_path="/projects/beta",
        )
        infos = {i.composer_id: i for i in load_composers(tmp_path)}
        assert set(infos) == {"from-headers", "from-fallback"}
        assert infos["from-headers"].source == "headers"
        assert infos["from-fallback"].source == "workspace"

    def test_target_ids_short_circuits_workspace_scan(
        self, tmp_path: Path, monkeypatch: Any
    ) -> None:
        """When all target_ids are found in headers, fallback scan is skipped."""
        _write_headers(
            tmp_path,
            [
                {
                    "composerId": "in-headers",
                    "workspaceIdentifier": {
                        "id": "ws1",
                        "uri": {"fsPath": "/projects/alpha", "scheme": "file"},
                    },
                },
            ],
        )
        # A legacy workspace exists but its composerData reader should not be
        # invoked because the target is fully satisfied by the headers index.
        _write_legacy_workspace(
            tmp_path,
            "ws-legacy",
            [{"composerId": "legacy-unused"}],
            folder_path="/projects/legacy",
        )

        calls: list[Path] = []
        real_reader = cursor_module._read_workspace_composers
        monkeypatch.setattr(
            cursor_module,
            "_read_workspace_composers",
            lambda p: calls.append(p) or real_reader(p),
        )

        infos = load_composers(tmp_path, target_ids={"in-headers"})

        assert len(infos) == 1
        assert infos[0].composer_id == "in-headers"
        assert calls == []  # fallback was never read

    def test_target_ids_falls_back_when_headers_incomplete(self, tmp_path: Path) -> None:
        """If a requested composer isn't in headers, the fallback scan runs."""
        _write_headers(
            tmp_path,
            [
                {
                    "composerId": "in-headers",
                    "workspaceIdentifier": {
                        "id": "ws1",
                        "uri": {"fsPath": "/projects/alpha", "scheme": "file"},
                    },
                },
            ],
        )
        _write_legacy_workspace(
            tmp_path,
            "ws-legacy",
            [{"composerId": "only-in-workspace"}],
            folder_path="/projects/legacy",
        )

        infos = {
            i.composer_id: i
            for i in load_composers(tmp_path, target_ids={"in-headers", "only-in-workspace"})
        }
        assert set(infos) == {"in-headers", "only-in-workspace"}
        assert infos["in-headers"].source == "headers"
        assert infos["only-in-workspace"].source == "workspace"

    def test_target_ids_filters_unwanted_composers(self, tmp_path: Path) -> None:
        """Composers outside target_ids are filtered from the result."""
        _write_headers(
            tmp_path,
            [
                {
                    "composerId": "wanted",
                    "workspaceIdentifier": {
                        "id": "ws1",
                        "uri": {"fsPath": "/projects/alpha", "scheme": "file"},
                    },
                },
                {
                    "composerId": "not-wanted",
                    "workspaceIdentifier": {
                        "id": "ws1",
                        "uri": {"fsPath": "/projects/alpha", "scheme": "file"},
                    },
                },
            ],
        )
        infos = load_composers(tmp_path, target_ids={"wanted"})
        assert [i.composer_id for i in infos] == ["wanted"]


# =============================================================================
# Adapter Basic Tests
# =============================================================================


class TestCursorAdapterBasics:
    def test_name(self) -> None:
        """Adapter name is 'cursor'."""
        adapter = CursorAdapter()
        assert adapter.name == "cursor"

    def test_write_events_not_implemented(self) -> None:
        """write_events raises NotImplementedError."""
        adapter = CursorAdapter()
        with pytest.raises(NotImplementedError, match="read-only"):
            adapter.write_events([], None)


# =============================================================================
# Session Discovery Tests
# =============================================================================


class TestCursorSessionDiscovery:
    def test_discover_sessions_no_cursor_dir(self, tmp_path: Path, monkeypatch: Any) -> None:
        """Returns empty list when Cursor directory doesn't exist."""
        monkeypatch.setattr(Path, "home", lambda: tmp_path)
        adapter = CursorAdapter()
        sessions = adapter.discover_sessions(tmp_path / "project")
        assert sessions == []

    def test_discover_sessions_no_matching_workspace(
        self, tmp_path: Path, monkeypatch: Any
    ) -> None:
        """Returns empty list when no workspace matches project."""
        mock_home = tmp_path / "home"
        monkeypatch.setattr(Path, "home", lambda: mock_home)

        # Create Cursor structure with non-matching workspace
        cursor_user = mock_home / "Library" / "Application Support" / "Cursor" / "User"
        workspace_storage = cursor_user / "workspaceStorage" / "abc123"
        workspace_storage.mkdir(parents=True)

        workspace_json = workspace_storage / "workspace.json"
        workspace_json.write_text(json.dumps({"folder": "file:///other/project"}))

        project_dir = tmp_path / "my_project"
        project_dir.mkdir()

        with patch.object(sys, "platform", "darwin"):
            adapter = CursorAdapter()
            sessions = adapter.discover_sessions(project_dir)
            assert sessions == []

    def test_discover_sessions_finds_matching_workspace(
        self, tmp_path: Path, monkeypatch: Any
    ) -> None:
        """Finds sessions when workspace matches project directory."""
        mock_home = tmp_path / "home"
        monkeypatch.setattr(Path, "home", lambda: mock_home)

        # Create project directory
        project_dir = tmp_path / "my_project"
        project_dir.mkdir()

        # Create Cursor structure
        cursor_user = mock_home / "Library" / "Application Support" / "Cursor" / "User"
        workspace_storage = cursor_user / "workspaceStorage" / "abc123"
        workspace_storage.mkdir(parents=True)

        # Create workspace.json pointing to our project
        workspace_json = workspace_storage / "workspace.json"
        workspace_json.write_text(json.dumps({"folder": f"file://{project_dir}"}))

        # Create state.vscdb with composer data
        state_db = workspace_storage / "state.vscdb"
        conn = sqlite3.connect(state_db)
        cursor = conn.cursor()
        cursor.execute("CREATE TABLE ItemTable (key TEXT PRIMARY KEY, value BLOB)")

        composer_data = {
            "allComposers": [
                {
                    "composerId": "test-session-001",
                    "unifiedMode": "agent",
                    "createdAt": 1704067200000,
                    "lastUpdatedAt": 1704070800000,
                }
            ]
        }
        cursor.execute(
            "INSERT INTO ItemTable (key, value) VALUES (?, ?)",
            ("composer.composerData", json.dumps(composer_data)),
        )
        conn.commit()
        conn.close()

        with patch.object(sys, "platform", "darwin"):
            adapter = CursorAdapter()
            sessions = adapter.discover_sessions(project_dir)

            assert len(sessions) == 1
            assert sessions[0].id == "test-session-001"
            assert sessions[0].format == "cursor"

    def test_discover_sessions_from_composer_headers(
        self, tmp_path: Path, monkeypatch: Any
    ) -> None:
        """Finds composers via the new globalStorage composer.composerHeaders index."""
        mock_home = tmp_path / "home"
        monkeypatch.setattr(Path, "home", lambda: mock_home)

        project_dir = tmp_path / "my_project"
        project_dir.mkdir()

        cursor_user = mock_home / "Library" / "Application Support" / "Cursor" / "User"
        # Migrated workspace: composer.composerData present but only with migration flags
        workspace_storage = cursor_user / "workspaceStorage" / "abc123"
        workspace_storage.mkdir(parents=True)
        workspace_json = workspace_storage / "workspace.json"
        workspace_json.write_text(json.dumps({"folder": f"file://{project_dir}"}))
        ws_db = workspace_storage / "state.vscdb"
        conn = sqlite3.connect(ws_db)
        conn.execute("CREATE TABLE ItemTable (key TEXT PRIMARY KEY, value BLOB)")
        conn.execute(
            "INSERT INTO ItemTable (key, value) VALUES (?, ?)",
            (
                "composer.composerData",
                json.dumps(
                    {
                        "selectedComposerIds": ["new-schema-session"],
                        "hasMigratedComposerData": True,
                        "hasMigratedMultipleComposers": True,
                    }
                ),
            ),
        )
        conn.commit()
        conn.close()

        # Authoritative index lives in globalStorage
        global_storage = cursor_user / "globalStorage"
        global_storage.mkdir(parents=True)
        global_db = global_storage / "state.vscdb"
        conn = sqlite3.connect(global_db)
        conn.execute("CREATE TABLE ItemTable (key TEXT PRIMARY KEY, value BLOB)")
        conn.execute(
            "INSERT INTO ItemTable (key, value) VALUES (?, ?)",
            (
                "composer.composerHeaders",
                json.dumps(
                    {
                        "allComposers": [
                            {
                                "composerId": "new-schema-session",
                                "name": "Session grouping logic",
                                "createdAt": 1704067200000,
                                "lastUpdatedAt": 1704070800000,
                                "workspaceIdentifier": {
                                    "id": "abc123",
                                    "uri": {
                                        "fsPath": str(project_dir),
                                        "scheme": "file",
                                    },
                                },
                            }
                        ]
                    }
                ),
            ),
        )
        conn.commit()
        conn.close()

        with patch.object(sys, "platform", "darwin"):
            adapter = CursorAdapter()
            sessions = adapter.discover_sessions(project_dir)

            assert len(sessions) == 1
            assert sessions[0].id == "new-schema-session"
            assert sessions[0].metadata is not None
            assert sessions[0].metadata["name"] == "Session grouping logic"


# =============================================================================
# Read Events Tests
# =============================================================================


class TestCursorReadEvents:
    def test_read_events_no_metadata(self) -> None:
        """Returns empty when session has no metadata."""
        adapter = CursorAdapter()
        session = Session(
            id="test",
            path=Path("/tmp/test.db"),
            format="cursor",
            modified_at=0.0,
            metadata=None,
        )
        events = list(adapter.read_events(session))
        assert events == []

    def test_read_events_no_cursor_user(self) -> None:
        """Returns empty when cursor_user not in metadata."""
        adapter = CursorAdapter()
        session = Session(
            id="test",
            path=Path("/tmp/test.db"),
            format="cursor",
            modified_at=0.0,
            metadata={"composerId": "test"},
        )
        events = list(adapter.read_events(session))
        assert events == []

    def test_read_events_missing_global_db(self, tmp_path: Path) -> None:
        """Returns empty when global state database doesn't exist."""
        adapter = CursorAdapter()
        cursor_user = tmp_path / "cursor_user"
        cursor_user.mkdir()
        # Don't create globalStorage/state.vscdb

        session = Session(
            id="test",
            path=Path("/tmp/test.db"),
            format="cursor",
            modified_at=0.0,
            metadata={"composerId": "test", "cursor_user": str(cursor_user)},
        )
        events = list(adapter.read_events(session))
        assert events == []

    def test_read_events_basic_session(self, tmp_path: Path) -> None:
        """Reads events from a basic Cursor session."""
        cursor_user = tmp_path / "cursor_user"
        global_storage = cursor_user / "globalStorage"
        global_storage.mkdir(parents=True)

        # Create global state with bubbles
        global_db = global_storage / "state.vscdb"
        conn = sqlite3.connect(global_db)
        cursor = conn.cursor()
        cursor.execute("CREATE TABLE cursorDiskKV (key TEXT PRIMARY KEY, value BLOB)")

        bubbles = [
            {
                "bubbleId": "bubble-1",
                "type": 1,
                "text": "Hello assistant",
                "createdAt": 1704067200000,
            },
            {
                "bubbleId": "bubble-2",
                "type": 2,
                "text": "Hi there! How can I help?",
                "createdAt": 1704067201000,
            },
        ]

        for bubble in bubbles:
            key = f"bubbleId:composer-123:{bubble['bubbleId']}"
            cursor.execute(
                "INSERT INTO cursorDiskKV (key, value) VALUES (?, ?)",
                (key, json.dumps(bubble)),
            )
        conn.commit()
        conn.close()

        adapter = CursorAdapter()
        session = Session(
            id="composer-123",
            path=tmp_path / "state.vscdb",
            format="cursor",
            modified_at=1704070800.0,
            metadata={"composerId": "composer-123", "cursor_user": str(cursor_user)},
        )

        events = list(adapter.read_events(session))

        # Should have: source_entry (session), RunStarted, source_entry + text (bubble-1),
        # source_entry + text (bubble-2), RunFinished
        event_types = [e.type for e in events]
        assert EventType.RUN_STARTED in event_types
        assert EventType.RUN_FINISHED in event_types
        assert EventType.TEXT_MESSAGE_CHUNK in event_types

        # Check user message
        text_events = [e for e in events if e.type == EventType.TEXT_MESSAGE_CHUNK]
        assert len(text_events) == 2

        user_msg = text_events[0]
        assert isinstance(user_msg, TextMessageChunkEvent)
        assert user_msg.role == Role.USER
        assert user_msg.delta == "Hello assistant"

        assistant_msg = text_events[1]
        assert isinstance(assistant_msg, TextMessageChunkEvent)
        assert assistant_msg.role == Role.ASSISTANT
        assert assistant_msg.delta == "Hi there! How can I help?"


class TestCursorSyntheticTimestamps:
    """Tests for synthetic timestamp generation when bubbles lack createdAt.

    Uses the module-level compute_synthetic_timestamps function which assigns
    realistic per-bubble-type durations (5s user, 30s assistant).
    """

    def _make_entries(self, types: list[int]) -> list[dict]:
        return [{"entry_content": json.dumps({"type": t})} for t in types]

    def test_compute_synthetic_timestamps_assigns_type_based_durations(self) -> None:
        """Synthetic timestamps use per-bubble-type durations."""
        metadata = {
            "createdAt": 1704067200000,  # 2024-01-01 00:00:00
            "lastUpdatedAt": 1704070800000,  # 2024-01-01 01:00:00 (1 hour later)
        }
        # user, assistant, assistant, user, assistant
        entries = self._make_entries([1, 2, 2, 1, 2])
        timestamps = compute_synthetic_timestamps(metadata, entries)

        assert timestamps is not None
        assert len(timestamps) == 5
        assert timestamps[0] == 1704067200000  # Starts at createdAt
        # Gaps: user=5s, asst=30s, asst=30s, user=5s
        assert timestamps[1] == 1704067200000 + 5000
        assert timestamps[2] == 1704067200000 + 35000
        assert timestamps[3] == 1704067200000 + 65000
        assert timestamps[4] == 1704067200000 + 70000

    def test_compute_synthetic_timestamps_single_entry(self) -> None:
        """Single entry gets start timestamp."""
        metadata = {
            "createdAt": 1704067200000,
            "lastUpdatedAt": 1704070800000,
        }
        entries = self._make_entries([2])
        timestamps = compute_synthetic_timestamps(metadata, entries)

        assert timestamps is not None
        assert len(timestamps) == 1
        assert timestamps[0] == 1704067200000

    def test_compute_synthetic_timestamps_missing_start(self) -> None:
        """Returns None if session start timestamp is missing."""
        metadata = {"lastUpdatedAt": 1704070800000}
        assert compute_synthetic_timestamps(metadata, self._make_entries([2, 2])) is None

    def test_compute_synthetic_timestamps_missing_end(self) -> None:
        """Returns None if session end timestamp is missing."""
        metadata = {"createdAt": 1704067200000}
        assert compute_synthetic_timestamps(metadata, self._make_entries([2, 2])) is None

    def test_compute_synthetic_timestamps_handles_iso_strings(self) -> None:
        """Synthetic timestamps work with ISO 8601 string timestamps."""
        metadata = {
            "createdAt": "2024-01-01T00:00:00.000Z",
            "lastUpdatedAt": "2024-01-01T01:00:00.000Z",
        }
        entries = self._make_entries([1, 2, 2])
        timestamps = compute_synthetic_timestamps(metadata, entries)

        assert timestamps is not None
        assert len(timestamps) == 3
        assert timestamps[0] == 1704067200000
        assert timestamps[-1] > timestamps[0]


class TestCursorBubbleMapping:
    def test_thinking_blocks(self, tmp_path: Path) -> None:
        """Thinking blocks are converted to reasoning events."""
        cursor_user = tmp_path / "cursor_user"
        global_storage = cursor_user / "globalStorage"
        global_storage.mkdir(parents=True)

        global_db = global_storage / "state.vscdb"
        conn = sqlite3.connect(global_db)
        cursor = conn.cursor()
        cursor.execute("CREATE TABLE cursorDiskKV (key TEXT PRIMARY KEY, value BLOB)")

        bubble = {
            "bubbleId": "bubble-1",
            "type": 2,
            "text": "Here's the answer",
            "createdAt": 1704067200000,
            "allThinkingBlocks": [
                {"text": "Let me think about this..."},
                {"thinking": "Another thought"},
            ],
        }
        cursor.execute(
            "INSERT INTO cursorDiskKV (key, value) VALUES (?, ?)",
            ("bubbleId:composer-123:bubble-1", json.dumps(bubble)),
        )
        conn.commit()
        conn.close()

        adapter = CursorAdapter()
        session = Session(
            id="composer-123",
            path=tmp_path / "state.vscdb",
            format="cursor",
            modified_at=1704070800.0,
            metadata={"composerId": "composer-123", "cursor_user": str(cursor_user)},
        )

        events = list(adapter.read_events(session))
        reasoning_events = [e for e in events if e.type == EventType.REASONING_MESSAGE_CHUNK]

        assert len(reasoning_events) == 2
        assert isinstance(reasoning_events[0], ReasoningMessageChunkEvent)
        assert isinstance(reasoning_events[1], ReasoningMessageChunkEvent)
        assert reasoning_events[0].delta == "Let me think about this..."
        assert reasoning_events[1].delta == "Another thought"

    def test_direct_tool_call(self, tmp_path: Path) -> None:
        """Direct tool call format is converted to tool events."""
        cursor_user = tmp_path / "cursor_user"
        global_storage = cursor_user / "globalStorage"
        global_storage.mkdir(parents=True)

        global_db = global_storage / "state.vscdb"
        conn = sqlite3.connect(global_db)
        cursor = conn.cursor()
        cursor.execute("CREATE TABLE cursorDiskKV (key TEXT PRIMARY KEY, value BLOB)")

        bubble = {
            "bubbleId": "bubble-1",
            "type": 2,
            "text": "",
            "createdAt": 1704067200000,
            "toolFormerData": {
                "name": "read_file",
                "toolCallId": "call-123",
                "params": '{"path": "/tmp/test.txt"}',
                "result": "file contents here",
            },
        }
        cursor.execute(
            "INSERT INTO cursorDiskKV (key, value) VALUES (?, ?)",
            ("bubbleId:composer-123:bubble-1", json.dumps(bubble)),
        )
        conn.commit()
        conn.close()

        adapter = CursorAdapter()
        session = Session(
            id="composer-123",
            path=tmp_path / "state.vscdb",
            format="cursor",
            modified_at=1704070800.0,
            metadata={"composerId": "composer-123", "cursor_user": str(cursor_user)},
        )

        events = list(adapter.read_events(session))

        tool_call_events = [e for e in events if e.type == EventType.TOOL_CALL_CHUNK]
        tool_result_events = [e for e in events if e.type == EventType.TOOL_CALL_RESULT]

        assert len(tool_call_events) == 1
        assert isinstance(tool_call_events[0], ToolCallChunkEvent)
        assert tool_call_events[0].tool_call_name == "read_file"
        assert tool_call_events[0].tool_call_id == "call-123"

        assert len(tool_result_events) == 1
        assert isinstance(tool_result_events[0], ToolCallResultEvent)
        assert tool_result_events[0].result == "file contents here"

    def test_nested_tool_calls(self, tmp_path: Path) -> None:
        """Nested toolCalls format is converted to tool events."""
        cursor_user = tmp_path / "cursor_user"
        global_storage = cursor_user / "globalStorage"
        global_storage.mkdir(parents=True)

        global_db = global_storage / "state.vscdb"
        conn = sqlite3.connect(global_db)
        cursor = conn.cursor()
        cursor.execute("CREATE TABLE cursorDiskKV (key TEXT PRIMARY KEY, value BLOB)")

        bubble = {
            "bubbleId": "bubble-1",
            "type": 2,
            "text": "",
            "createdAt": 1704067200000,
            "toolFormerData": {
                "toolCalls": [
                    {"id": "tc-1", "name": "read_file", "args": {"path": "/a.txt"}},
                    {"id": "tc-2", "function": "write_file", "arguments": {"path": "/b.txt"}},
                ],
                "toolResults": {
                    "tc-1": "content of a.txt",
                    "tc-2": {"success": True},
                },
            },
        }
        cursor.execute(
            "INSERT INTO cursorDiskKV (key, value) VALUES (?, ?)",
            ("bubbleId:composer-123:bubble-1", json.dumps(bubble)),
        )
        conn.commit()
        conn.close()

        adapter = CursorAdapter()
        session = Session(
            id="composer-123",
            path=tmp_path / "state.vscdb",
            format="cursor",
            modified_at=1704070800.0,
            metadata={"composerId": "composer-123", "cursor_user": str(cursor_user)},
        )

        events = list(adapter.read_events(session))

        tool_call_events = [e for e in events if e.type == EventType.TOOL_CALL_CHUNK]
        tool_result_events = [e for e in events if e.type == EventType.TOOL_CALL_RESULT]

        assert len(tool_call_events) == 2
        assert isinstance(tool_call_events[0], ToolCallChunkEvent)
        assert isinstance(tool_call_events[1], ToolCallChunkEvent)
        assert tool_call_events[0].tool_call_name == "read_file"
        assert tool_call_events[1].tool_call_name == "write_file"

        assert len(tool_result_events) == 2

    def test_token_usage_extraction(self, tmp_path: Path) -> None:
        """Token usage is extracted from tokenCount field."""
        cursor_user = tmp_path / "cursor_user"
        global_storage = cursor_user / "globalStorage"
        global_storage.mkdir(parents=True)

        global_db = global_storage / "state.vscdb"
        conn = sqlite3.connect(global_db)
        cursor = conn.cursor()
        cursor.execute("CREATE TABLE cursorDiskKV (key TEXT PRIMARY KEY, value BLOB)")

        bubble = {
            "bubbleId": "bubble-1",
            "type": 2,
            "text": "Response with tokens",
            "createdAt": 1704067200000,
            "tokenCount": {"inputTokens": 100, "outputTokens": 50},
        }
        cursor.execute(
            "INSERT INTO cursorDiskKV (key, value) VALUES (?, ?)",
            ("bubbleId:composer-123:bubble-1", json.dumps(bubble)),
        )
        conn.commit()
        conn.close()

        adapter = CursorAdapter()
        session = Session(
            id="composer-123",
            path=tmp_path / "state.vscdb",
            format="cursor",
            modified_at=1704070800.0,
            metadata={"composerId": "composer-123", "cursor_user": str(cursor_user)},
        )

        events = list(adapter.read_events(session))
        text_events = [e for e in events if e.type == EventType.TEXT_MESSAGE_CHUNK]

        assert len(text_events) == 1


class TestCursorFileOperations:
    """Tests for file operation extraction in Cursor adapter."""

    def test_file_ops_extracted_from_direct_tool_call(self, tmp_path: Path) -> None:
        """File operations should be extracted from direct tool call format."""
        cursor_user = tmp_path / "cursor_user"
        global_storage = cursor_user / "globalStorage"
        global_storage.mkdir(parents=True)

        workspace_dir = tmp_path / "project"
        workspace_dir.mkdir()

        global_db = global_storage / "state.vscdb"
        conn = sqlite3.connect(global_db)
        cursor = conn.cursor()
        cursor.execute("CREATE TABLE cursorDiskKV (key TEXT PRIMARY KEY, value BLOB)")

        bubble = {
            "bubbleId": "bubble-1",
            "type": 2,
            "text": "",
            "createdAt": 1704067200000,
            "toolFormerData": {
                "name": "read_file",
                "toolCallId": "call-123",
                "params": json.dumps({"file_path": str(workspace_dir / "test.txt")}),
                "result": "file contents here",
            },
        }
        cursor.execute(
            "INSERT INTO cursorDiskKV (key, value) VALUES (?, ?)",
            ("bubbleId:composer-123:bubble-1", json.dumps(bubble)),
        )
        conn.commit()
        conn.close()

        adapter = CursorAdapter()
        session = Session(
            id="composer-123",
            path=tmp_path / "state.vscdb",
            format="cursor",
            modified_at=1704070800.0,
            metadata={
                "composerId": "composer-123",
                "cursor_user": str(cursor_user),
                "workspace_dir": str(workspace_dir),
            },
        )

        events = list(adapter.read_events(session))

        tool_events = [e for e in events if e.type == EventType.TOOL_CALL_CHUNK]
        assert len(tool_events) == 1

    def test_file_ops_extracted_from_nested_tool_calls(self, tmp_path: Path) -> None:
        """File operations should be extracted from nested toolCalls format."""
        cursor_user = tmp_path / "cursor_user"
        global_storage = cursor_user / "globalStorage"
        global_storage.mkdir(parents=True)

        workspace_dir = tmp_path / "project"
        workspace_dir.mkdir()

        global_db = global_storage / "state.vscdb"
        conn = sqlite3.connect(global_db)
        cursor = conn.cursor()
        cursor.execute("CREATE TABLE cursorDiskKV (key TEXT PRIMARY KEY, value BLOB)")

        bubble = {
            "bubbleId": "bubble-1",
            "type": 2,
            "text": "",
            "createdAt": 1704067200000,
            "toolFormerData": {
                "toolCalls": [
                    {
                        "id": "tc-1",
                        "name": "read_file",
                        "args": {"file_path": str(workspace_dir / "a.txt")},
                    },
                    {
                        "id": "tc-2",
                        "name": "write_file",
                        "args": {"file_path": str(workspace_dir / "b.txt")},
                    },
                ],
                "toolResults": {
                    "tc-1": "content of a.txt",
                    "tc-2": {"success": True},
                },
            },
        }
        cursor.execute(
            "INSERT INTO cursorDiskKV (key, value) VALUES (?, ?)",
            ("bubbleId:composer-123:bubble-1", json.dumps(bubble)),
        )
        conn.commit()
        conn.close()

        adapter = CursorAdapter()
        session = Session(
            id="composer-123",
            path=tmp_path / "state.vscdb",
            format="cursor",
            modified_at=1704070800.0,
            metadata={
                "composerId": "composer-123",
                "cursor_user": str(cursor_user),
                "workspace_dir": str(workspace_dir),
            },
        )

        events = list(adapter.read_events(session))

        tool_events = [e for e in events if e.type == EventType.TOOL_CALL_CHUNK]
        assert len(tool_events) == 2

        # Note: File operation extraction is now handled via normalizers and stored
        # as UNIFIED_FILE_OPERATION custom events, not in raw_event.

    def test_paths_normalized_to_workspace_relative(self, tmp_path: Path) -> None:
        """File paths should be normalized relative to workspace directory."""
        cursor_user = tmp_path / "cursor_user"
        global_storage = cursor_user / "globalStorage"
        global_storage.mkdir(parents=True)

        workspace_dir = tmp_path / "project"
        workspace_dir.mkdir()

        global_db = global_storage / "state.vscdb"
        conn = sqlite3.connect(global_db)
        cursor = conn.cursor()
        cursor.execute("CREATE TABLE cursorDiskKV (key TEXT PRIMARY KEY, value BLOB)")

        bubble = {
            "bubbleId": "bubble-1",
            "type": 2,
            "text": "",
            "createdAt": 1704067200000,
            "toolFormerData": {
                "name": "read_file",
                "toolCallId": "call-123",
                "params": json.dumps({"file_path": str(workspace_dir / "subdir" / "file.txt")}),
                "result": "content",
            },
        }
        cursor.execute(
            "INSERT INTO cursorDiskKV (key, value) VALUES (?, ?)",
            ("bubbleId:composer-123:bubble-1", json.dumps(bubble)),
        )
        conn.commit()
        conn.close()

        adapter = CursorAdapter()
        session = Session(
            id="composer-123",
            path=tmp_path / "state.vscdb",
            format="cursor",
            modified_at=1704070800.0,
            metadata={
                "composerId": "composer-123",
                "cursor_user": str(cursor_user),
                "workspace_dir": str(workspace_dir),
            },
        )

        events = list(adapter.read_events(session))

        tool_events = [e for e in events if e.type == EventType.TOOL_CALL_CHUNK]
        assert len(tool_events) > 0
        # Note: File path normalization is now tested via normalizer tests,
        # not via adapter raw_event extraction.

    def test_no_file_ops_for_text_only_messages(self, tmp_path: Path) -> None:
        """Messages without tool calls should not have file_ops."""
        cursor_user = tmp_path / "cursor_user"
        global_storage = cursor_user / "globalStorage"
        global_storage.mkdir(parents=True)

        global_db = global_storage / "state.vscdb"
        conn = sqlite3.connect(global_db)
        cursor = conn.cursor()
        cursor.execute("CREATE TABLE cursorDiskKV (key TEXT PRIMARY KEY, value BLOB)")

        bubble = {
            "bubbleId": "bubble-1",
            "type": 2,
            "text": "Just a text response",
            "createdAt": 1704067200000,
        }
        cursor.execute(
            "INSERT INTO cursorDiskKV (key, value) VALUES (?, ?)",
            ("bubbleId:composer-123:bubble-1", json.dumps(bubble)),
        )
        conn.commit()
        conn.close()

        adapter = CursorAdapter()
        session = Session(
            id="composer-123",
            path=tmp_path / "state.vscdb",
            format="cursor",
            modified_at=1704070800.0,
            metadata={
                "composerId": "composer-123",
                "cursor_user": str(cursor_user),
            },
        )

        events = list(adapter.read_events(session))

        text_events = [e for e in events if e.type == EventType.TEXT_MESSAGE_CHUNK]
        assert len(text_events) == 1


class TestCursorParseSourceEntry:
    """Tests for parse_source_entry method."""

    def test_uses_injected_timestamp_when_created_at_null(self) -> None:
        """parse_source_entry should use _timestamp_ms when createdAt is null.

        This is a regression test for the active_duration bug where entries
        with createdAt: null would fallback to datetime.now() instead of
        using the injected _timestamp_ms from the source entry.
        """
        adapter = CursorAdapter()

        # Simulate a Cursor bubble with createdAt: null (common in some Cursor versions)
        entry_data = {
            "type": 2,  # Assistant message
            "bubbleId": "bubble-123",
            "text": "Response text",
            "createdAt": None,  # This is the bug trigger
            # Injected by processing.py from source_entry.entry_timestamp_ms
            "_timestamp_ms": 1758322457260,  # Sept 2025
        }

        events = adapter.parse_source_entry(entry_data, entry_index=16, session_id="test-session")

        # Should have at least one text message event
        text_events = [e for e in events if e.type == EventType.TEXT_MESSAGE_CHUNK]
        assert len(text_events) == 1

        # The timestamp should be from _timestamp_ms, NOT from datetime.now()
        assert text_events[0].timestamp_ms == 1758322457260

    def test_prefers_created_at_over_injected_timestamp(self) -> None:
        """parse_source_entry should prefer createdAt when available."""
        adapter = CursorAdapter()

        entry_data = {
            "type": 2,
            "bubbleId": "bubble-456",
            "text": "Response",
            "createdAt": "2025-09-19T22:54:17.260Z",  # Valid ISO timestamp
            "_timestamp_ms": 9999999999999,  # Should be ignored
        }

        events = adapter.parse_source_entry(entry_data, entry_index=0, session_id="test-session")

        text_events = [e for e in events if e.type == EventType.TEXT_MESSAGE_CHUNK]
        assert len(text_events) == 1

        # Should use createdAt timestamp, not _timestamp_ms
        assert text_events[0].timestamp_ms == 1758322457260

    def test_tool_calls_use_correct_timestamp_when_created_at_null(self) -> None:
        """Tool call events should also use _timestamp_ms when createdAt is null."""
        adapter = CursorAdapter()

        entry_data = {
            "type": 2,
            "bubbleId": "bubble-789",
            "text": "",
            "createdAt": None,
            "_timestamp_ms": 1758322457260,
            "toolFormerData": {
                "name": "todo_write",
                "toolCallId": "call-123",
                "params": '{"todos": []}',
                "result": {"finalTodos": []},
            },
        }

        events = adapter.parse_source_entry(entry_data, entry_index=362, session_id="test-session")

        tool_events = [e for e in events if e.type == EventType.TOOL_CALL_CHUNK]
        assert len(tool_events) == 1

        # Should use _timestamp_ms, not datetime.now()
        assert tool_events[0].timestamp_ms == 1758322457260


class TestCursorDetect:
    def test_detect_returns_false_when_no_cursor(self, tmp_path: Path, monkeypatch: Any) -> None:
        """detect() returns False when Cursor user directory doesn't exist."""
        monkeypatch.setattr(Path, "home", lambda: tmp_path)
        adapter = CursorAdapter()

        with patch.object(sys, "platform", "darwin"):
            result = adapter.detect(tmp_path / "project")
            assert result is False


# =============================================================================
# entries_lack_bubble_timestamps tests
# =============================================================================


class TestEntriesLackBubbleTimestamps:
    """Tests for entries_lack_bubble_timestamps."""

    def test_v2_bubbles_without_created_at(self):
        entries = [
            {"entry_content": json.dumps({"_v": 2, "type": 1, "text": "hello"})},
            {"entry_content": json.dumps({"_v": 2, "type": 2, "text": "response"})},
        ]
        assert entries_lack_bubble_timestamps(entries) is True

    def test_v1_bubbles_with_created_at(self):
        entries = [
            {"entry_content": json.dumps({"type": 1, "createdAt": 1746206863741})},
            {"entry_content": json.dumps({"type": 2, "createdAt": 1746207863741})},
        ]
        assert entries_lack_bubble_timestamps(entries) is False

    def test_mixed_entries_with_one_timestamp(self):
        entries = [
            {"entry_content": json.dumps({"_v": 2, "text": "no ts"})},
            {"entry_content": json.dumps({"text": "has ts", "createdAt": 1746206863741})},
        ]
        assert entries_lack_bubble_timestamps(entries) is False

    def test_empty_entries(self):
        assert entries_lack_bubble_timestamps([]) is True

    def test_malformed_json(self):
        entries = [{"entry_content": "not valid json"}]
        assert entries_lack_bubble_timestamps(entries) is True


# =============================================================================
# compute_synthetic_timestamps tests
# =============================================================================


class TestComputeSyntheticTimestamps:
    """Tests for compute_synthetic_timestamps."""

    def _make_entries(self, types: list[int]) -> list[dict]:
        return [{"entry_content": json.dumps({"type": t, "_v": 2})} for t in types]

    def test_assigns_realistic_durations_by_type(self):
        metadata = {
            "createdAt": 1746206863741,
            "lastUpdatedAt": 1746208863741,
        }
        entries = self._make_entries([1, 2, 2, 1, 2])
        result = compute_synthetic_timestamps(metadata, entries)
        assert result is not None
        assert len(result) == 5
        assert result[0] == 1746206863741
        assert result[1] == 1746206863741 + 5000
        assert result[2] == 1746206863741 + 5000 + 30000
        assert result[3] == 1746206863741 + 5000 + 30000 + 30000
        assert result[4] == 1746206863741 + 5000 + 30000 + 30000 + 5000

    def test_scales_down_when_exceeds_session_window(self):
        metadata = {
            "createdAt": 1746206863741,
            "lastUpdatedAt": 1746206883741,  # Only 20s window
        }
        entries = self._make_entries([2, 2, 2, 2, 2])
        result = compute_synthetic_timestamps(metadata, entries)
        assert result is not None
        assert result[-1] <= 1746206883741

    def test_single_entry(self):
        metadata = {
            "createdAt": 1746206863741,
            "lastUpdatedAt": 1746207863741,
        }
        entries = self._make_entries([2])
        result = compute_synthetic_timestamps(metadata, entries)
        assert result == [1746206863741]

    def test_missing_created_at(self):
        metadata = {"lastUpdatedAt": 1746207863741}
        assert compute_synthetic_timestamps(metadata, self._make_entries([2, 2])) is None

    def test_missing_last_updated_at(self):
        metadata = {"createdAt": 1746206863741}
        assert compute_synthetic_timestamps(metadata, self._make_entries([2, 2])) is None

    def test_empty_entries(self):
        metadata = {"createdAt": 1746206863741, "lastUpdatedAt": 1746207863741}
        assert compute_synthetic_timestamps(metadata, []) is None

    def test_swapped_timestamps(self):
        metadata = {
            "createdAt": 1746207863741,
            "lastUpdatedAt": 1746206863741,
        }
        entries = self._make_entries([1, 2, 1])
        result = compute_synthetic_timestamps(metadata, entries)
        assert result is not None
        assert result[0] == 1746206863741

    def test_iso_string_timestamps(self):
        metadata = {
            "createdAt": "2025-05-02T15:07:43.741Z",
            "lastUpdatedAt": "2025-05-02T15:24:23.741Z",
        }
        entries = self._make_entries([1, 2, 2])
        result = compute_synthetic_timestamps(metadata, entries)
        assert result is not None
        assert len(result) == 3
        assert result[-1] > result[0]
