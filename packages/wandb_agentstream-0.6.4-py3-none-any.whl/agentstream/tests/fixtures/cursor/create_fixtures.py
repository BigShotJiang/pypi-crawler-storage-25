#!/usr/bin/env python3
"""
Script to create SQLite test fixtures for Cursor adapter tests.

Creates:
- workspace_state.vscdb: Contains composer session data
- global_state.vscdb: Contains bubble (message) data
"""

import json
import sqlite3
from pathlib import Path


def create_workspace_state_db(db_path: Path) -> None:
    """Create the workspace state database with composer data."""
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    # Create ItemTable
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS ItemTable (
            key TEXT PRIMARY KEY,
            value BLOB
        )
    """)

    # Composer data with test sessions
    composer_data = {
        "allComposers": [
            {
                "composerId": "test-session-001",
                "unifiedMode": "agent",
                "contextUsagePercent": 15.5,
                "totalLinesAdded": 50,
                "totalLinesRemoved": 10,
                "filesChangedCount": 3,
                "name": "Test Agent Session",
                "createdAt": 1704067200000,
                "lastUpdatedAt": 1704070800000,
            },
            {
                "composerId": "test-session-002",
                "unifiedMode": "chat",
                "contextUsagePercent": 5.2,
                "totalLinesAdded": 0,
                "totalLinesRemoved": 0,
                "filesChangedCount": 0,
                "name": "Test Chat Session",
                "createdAt": 1704067200000,
                "lastUpdatedAt": 1704068000000,
            },
        ]
    }

    cursor.execute(
        "INSERT OR REPLACE INTO ItemTable (key, value) VALUES (?, ?)",
        ("composer.composerData", json.dumps(composer_data)),
    )

    conn.commit()
    conn.close()
    print(f"Created: {db_path}")


def create_global_state_db(db_path: Path) -> None:
    """Create the global state database with bubble data.

    Also writes ``composer.composerHeaders`` to ItemTable so the fixture
    reflects the post-migration Cursor schema where composer enumeration
    happens globally rather than per-workspace.
    """
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    # Create cursorDiskKV table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS cursorDiskKV (
            key TEXT PRIMARY KEY,
            value BLOB
        )
    """)

    # Create ItemTable for composer.composerHeaders (new schema).
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS ItemTable (
            key TEXT PRIMARY KEY,
            value BLOB
        )
    """)
    composer_headers = {
        "allComposers": [
            {
                "composerId": "test-session-001",
                "name": "Test Agent Session",
                "createdAt": 1704067200000,
                "lastUpdatedAt": 1704070800000,
                "workspaceIdentifier": {
                    "id": "test-workspace-001",
                    "uri": {"fsPath": "/test/project", "scheme": "file"},
                },
            },
            {
                "composerId": "test-session-002",
                "name": "Test Chat Session",
                "createdAt": 1704067200000,
                "lastUpdatedAt": 1704068000000,
                "workspaceIdentifier": {
                    "id": "test-workspace-001",
                    "uri": {"fsPath": "/test/project", "scheme": "file"},
                },
            },
        ]
    }
    cursor.execute(
        "INSERT OR REPLACE INTO ItemTable (key, value) VALUES (?, ?)",
        ("composer.composerHeaders", json.dumps(composer_headers)),
    )

    # Bubbles for test-session-001 (agent mode)
    bubbles_session_001 = [
        {
            "bubbleId": "bubble-001",
            "type": 1,
            "text": "Help me write a function to sort a list",
            "createdAt": "2024-01-01T00:00:00.000Z",
            "isAgentic": True,
            "modelInfo": {"modelName": "default"},
        },
        {
            "bubbleId": "bubble-002",
            "type": 2,
            "text": "I'll help you write a sorting function.",
            "createdAt": "2024-01-01T00:00:05.000Z",
            "isAgentic": False,
            "toolFormerData": {
                "tool": 1,
                "toolCallId": "call_123",
                "name": "edit_file",
                "params": '{"file": "sort.py"}',
                "result": "File updated successfully",
            },
            "allThinkingBlocks": ["Let me think about the best sorting approach..."],
        },
    ]

    # Bubbles for test-session-002 (chat mode - simpler)
    bubbles_session_002 = [
        {
            "bubbleId": "bubble-003",
            "type": 1,
            "text": "What is Python?",
            "createdAt": "2024-01-01T00:00:00.000Z",
            "isAgentic": False,
            "modelInfo": {"modelName": "default"},
        },
        {
            "bubbleId": "bubble-004",
            "type": 2,
            "text": "Python is a high-level programming language "
            "known for its simplicity and readability.",
            "createdAt": "2024-01-01T00:00:02.000Z",
            "isAgentic": False,
        },
    ]

    # Insert bubbles for session 001
    for bubble in bubbles_session_001:
        key = f"bubbleId:test-session-001:{bubble['bubbleId']}"
        cursor.execute(
            "INSERT OR REPLACE INTO cursorDiskKV (key, value) VALUES (?, ?)",
            (key, json.dumps(bubble)),
        )

    # Insert bubbles for session 002
    for bubble in bubbles_session_002:
        key = f"bubbleId:test-session-002:{bubble['bubbleId']}"
        cursor.execute(
            "INSERT OR REPLACE INTO cursorDiskKV (key, value) VALUES (?, ?)",
            (key, json.dumps(bubble)),
        )

    conn.commit()
    conn.close()
    print(f"Created: {db_path}")


def create_workspace_json(json_path: Path) -> None:
    """Create the workspace mapping file."""
    workspace_data = {"folder": "file:///test/project"}

    with open(json_path, "w") as f:
        json.dump(workspace_data, f)

    print(f"Created: {json_path}")


def main() -> None:
    """Create all test fixtures."""
    fixtures_dir = Path(__file__).parent

    # Create all fixture files
    create_workspace_state_db(fixtures_dir / "workspace_state.vscdb")
    create_global_state_db(fixtures_dir / "global_state.vscdb")
    create_workspace_json(fixtures_dir / "workspace.json")

    print("\nAll fixtures created successfully!")

    # Verify the created files
    print("\nVerification:")
    for file_name in ["workspace_state.vscdb", "global_state.vscdb", "workspace.json"]:
        file_path = fixtures_dir / file_name
        if file_path.exists():
            print(f"  [OK] {file_name} ({file_path.stat().st_size} bytes)")
        else:
            print(f"  [FAIL] {file_name} not found")


if __name__ == "__main__":
    main()
