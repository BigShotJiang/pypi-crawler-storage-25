"""Tests for the Copilot CLI v1 normalizer."""

from __future__ import annotations

import json
from pathlib import Path

from agentstream.adapters.base import Session
from agentstream.adapters.copilot import CopilotAdapter
from agentstream.normalization.adapters.copilot_v1 import CopilotV1Normalizer
from agentstream.normalization.processor import EventProcessor
from agentstream.normalization.synthetic import (
    ERROR_EVENT,
    SESSION_METADATA,
    UNIFIED_FILE_OPERATION,
    UNIFIED_SKILL_ACTIVATION,
    UNIFIED_TODO_UPDATE,
)

FIXTURES = Path(__file__).parent.parent.parent / "fixtures" / "copilot"
SAMPLE_EVENTS = FIXTURES / "sample_session" / "events.jsonl"


def _build_normalizer_events_from_fixture() -> list[dict]:
    """Replicate the AG-UI → normalizer event conversion the backend does.

    Each ``assistant.message`` tool request becomes an event with
    ``tool_name``, ``args``, ``timestamp_ms``, ``event_id``, and (when a
    matching ``tool.execution_complete`` exists) ``result``.
    """
    adapter = CopilotAdapter()
    session = Session(
        id="fixture",
        path=SAMPLE_EVENTS,
        format="copilot",
        modified_at=SAMPLE_EVENTS.stat().st_mtime,
    )
    entries = adapter.read_entries(session)

    results: dict[str, dict] = {}
    for e in entries:
        raw = json.loads(e["entry_content"])
        if raw.get("type") == "tool.execution_complete":
            data = raw.get("data") or {}
            tcid = data.get("toolCallId")
            if tcid:
                results[tcid] = data.get("result") or {}

    out = []
    for e in entries:
        raw = json.loads(e["entry_content"])
        if raw.get("type") != "assistant.message":
            continue
        for tc in (raw.get("data") or {}).get("toolRequests") or []:
            tcid = tc.get("toolCallId")
            ev = {
                "tool_name": tc.get("name"),
                "args": tc.get("arguments") or {},
                "timestamp_ms": e["entry_timestamp_ms"],
                "event_id": tcid or "",
            }
            if tcid in results:
                ev["result"] = results[tcid]
            out.append(ev)
    return out


# ----------------------------------------------------------------------
# Session metadata
# ----------------------------------------------------------------------


class TestExtractSessionMetadata:
    def test_extracts_from_real_fixture(self) -> None:
        adapter = CopilotAdapter()
        session = Session(
            id="fixture",
            path=SAMPLE_EVENTS,
            format="copilot",
            modified_at=SAMPLE_EVENTS.stat().st_mtime,
        )
        entries = adapter.read_entries(session)

        metadata = CopilotV1Normalizer().extract_session_metadata(entries)
        assert metadata is not None
        assert metadata.agent_type == "copilot"
        assert metadata.cwd == "/Users/vanpelt/Development/agentstream-py"
        assert metadata.agent_version == "1.0.40"
        assert metadata.git_branch == "feat/docker-sidecar"
        assert metadata.git_commit == "e5b30c4a1f66aa140ee71e043183f439c52622d6"
        assert metadata.git_repo == "wandb/agentstream"
        assert metadata.primary_model == "gpt-5.4"

    def test_falls_back_to_daemon_metadata(self) -> None:
        # Session that has session.start but no model_change — should pull
        # model from daemon_metadata.
        entry = {
            "type": "session.start",
            "data": {
                "sessionId": "abc",
                "copilotVersion": "1.0.40",
                "context": {"cwd": "/x", "branch": "main"},
            },
            "timestamp": "2026-05-04T00:00:00.000Z",
        }
        source_entries = [
            {"entry_index": 0, "entry_content": json.dumps(entry), "entry_timestamp_ms": 1}
        ]
        daemon = {"model": "gpt-5.4-fallback", "git_commit": "abc123", "git_repo": "o/r"}

        metadata = CopilotV1Normalizer().extract_session_metadata(source_entries, daemon)
        assert metadata is not None
        assert metadata.primary_model == "gpt-5.4-fallback"
        assert metadata.git_commit == "abc123"
        assert metadata.git_repo == "o/r"

    def test_returns_none_for_no_entries(self) -> None:
        assert CopilotV1Normalizer().extract_session_metadata([]) is None

    def test_cloud_swe_agent_uses_placeholder_model(self) -> None:
        """Cloud SWE-agent sessions parsed from output.log have no
        session.start and no daemon_metadata.model — without a
        placeholder, the backend's primary_model gate would skip
        SESSION_METADATA emission and the session summary upsert would
        never run, 404'ing the dashboard. We emit ``swe-agent`` so the
        session lands with an honest placeholder model."""
        cloud_entries = [
            {
                "entry_index": 0,
                "entry_content": json.dumps(
                    {
                        "type": "user.message",
                        "data": {"content": "fix the bug"},
                    }
                ),
                "entry_timestamp_ms": 1_700_000_000_000,
            },
            {
                "entry_index": 1,
                "entry_content": json.dumps(
                    {
                        "type": "assistant.message",
                        "data": {
                            "toolRequests": [{"name": "bash", "arguments": {"command": "ls"}}]
                        },
                    }
                ),
                "entry_timestamp_ms": 1_700_000_001_000,
            },
        ]
        daemon = {"cwd": "/home/runner/work/repo/repo", "git_branch": "main"}
        metadata = CopilotV1Normalizer().extract_session_metadata(cloud_entries, daemon)
        assert metadata is not None
        assert metadata.primary_model == "swe-agent"
        assert metadata.cwd == "/home/runner/work/repo/repo"
        assert metadata.git_branch == "main"

    def test_placeholder_doesnt_override_real_cli_model(self) -> None:
        """The placeholder fallback only kicks in when there's no
        session.start. CLI sessions with session.start but no model
        should still defer SESSION_METADATA (primary_model stays
        empty) so a later sync cycle can fill in the real model."""
        entry = {
            "type": "session.start",
            "data": {"sessionId": "abc", "context": {"cwd": "/x"}},
        }
        source_entries = [
            {"entry_index": 0, "entry_content": json.dumps(entry), "entry_timestamp_ms": 1}
        ]
        metadata = CopilotV1Normalizer().extract_session_metadata(source_entries)
        assert metadata is not None
        assert metadata.primary_model == ""


# ----------------------------------------------------------------------
# File operations
# ----------------------------------------------------------------------


class TestExtractFileOperation:
    def test_view_is_a_read(self) -> None:
        n = CopilotV1Normalizer()
        op = n.extract_file_operation(
            {
                "tool_name": "view",
                "args": {"path": "/x/y.py"},
                "timestamp_ms": 1000,
                "event_id": "ev1",
                "result": {"content": "line1\nline2"},
            }
        )
        assert op is not None
        assert op.operation == "read"
        assert op.file_path == "/x/y.py"
        assert op.confidence == "high"
        assert op.source_tool == "view"
        assert op.content == "line1\nline2"

    def test_create_is_a_write(self) -> None:
        op = CopilotV1Normalizer().extract_file_operation(
            {
                "tool_name": "create",
                "args": {"path": "/x/y.py", "content": "hello\n"},
                "timestamp_ms": 1000,
                "event_id": "ev2",
            }
        )
        assert op is not None
        assert op.operation == "write"
        assert op.content == "hello\n"

    def test_str_replace_is_an_edit(self) -> None:
        op = CopilotV1Normalizer().extract_file_operation(
            {
                "tool_name": "str_replace",
                "args": {"path": "/x.py", "old_str": "a", "new_str": "b"},
                "timestamp_ms": 1000,
                "event_id": "ev3",
            }
        )
        assert op is not None
        assert op.operation == "edit"

    def test_rg_is_a_search(self) -> None:
        op = CopilotV1Normalizer().extract_file_operation(
            {
                "tool_name": "rg",
                "args": {"pattern": "foo", "paths": "/x"},
                "timestamp_ms": 1000,
                "event_id": "ev4",
            }
        )
        assert op is not None
        assert op.operation == "search"

    def test_glob_is_a_list(self) -> None:
        op = CopilotV1Normalizer().extract_file_operation(
            {
                "tool_name": "glob",
                "args": {"pattern": "**/*.py", "paths": "/x"},
                "timestamp_ms": 1000,
                "event_id": "ev5",
            }
        )
        assert op is not None
        assert op.operation == "list"

    def test_search_paths_as_list_takes_first_string(self) -> None:
        """``rg``/``glob`` send ``paths`` as a list — picking it directly used
        to surface as ``str([...])``-style Python repr in ``file_path``."""
        op = CopilotV1Normalizer().extract_file_operation(
            {
                "tool_name": "rg",
                "args": {
                    "pattern": "foo",
                    "paths": [
                        "/Users/vanpelt/.copilot/session-state",
                        "/Users/vanpelt/.copilot",
                    ],
                },
                "timestamp_ms": 1000,
                "event_id": "ev-rg-list",
            }
        )
        assert op is not None
        assert op.operation == "search"
        assert op.file_path == "/Users/vanpelt/.copilot/session-state"
        # Critical: must not be the Python list repr.
        assert "[" not in op.file_path
        assert "'" not in op.file_path

    def test_search_paths_empty_list_falls_back_to_directory(self) -> None:
        op = CopilotV1Normalizer().extract_file_operation(
            {
                "tool_name": "rg",
                "args": {"pattern": "foo", "paths": [], "directory": "/x"},
                "timestamp_ms": 1000,
                "event_id": "ev-rg-empty",
            }
        )
        assert op is not None
        assert op.file_path == "/x"

    def test_bash_cat_inferred_as_read(self) -> None:
        op = CopilotV1Normalizer().extract_file_operation(
            {
                "tool_name": "bash",
                "args": {"command": "cat /etc/hosts"},
                "timestamp_ms": 1000,
                "event_id": "ev6",
            }
        )
        assert op is not None
        assert op.operation == "read"
        assert op.file_path == "/etc/hosts"
        assert op.confidence == "medium"

    def test_unrelated_tool_returns_none(self) -> None:
        assert (
            CopilotV1Normalizer().extract_file_operation(
                {"tool_name": "report_intent", "args": {}, "timestamp_ms": 1}
            )
            is None
        )


# ----------------------------------------------------------------------
# Skills
# ----------------------------------------------------------------------


class TestExtractSkill:
    def test_skill_tool_returns_unified_skill(self) -> None:
        skill = CopilotV1Normalizer().extract_skill(
            {
                "tool_name": "skill",
                "args": {"skill": "agent-browser"},
                "timestamp_ms": 1000,
                "event_id": "ev1",
            }
        )
        assert skill is not None
        assert skill.name == "agent-browser"
        assert skill.method == "tool"
        assert skill.agent_type == "copilot"

    def test_other_tool_returns_none(self) -> None:
        assert (
            CopilotV1Normalizer().extract_skill(
                {"tool_name": "view", "args": {}, "timestamp_ms": 1}
            )
            is None
        )


# ----------------------------------------------------------------------
# Diffs
# ----------------------------------------------------------------------


class TestExtractDiff:
    def test_create_yields_full_addition_diff(self) -> None:
        diff = CopilotV1Normalizer().extract_diff(
            {
                "tool_name": "create",
                "args": {"path": "/x", "content": "a\nb\nc\n"},
                "timestamp_ms": 1,
            },
            session=None,
        )
        assert diff is not None
        assert diff.confidence == "high"
        assert diff.lines_added == [1, 2, 3]
        assert all(line.startswith("+") for line in diff.hunks[0].lines)

    def test_str_replace_yields_computed_diff(self) -> None:
        diff = CopilotV1Normalizer().extract_diff(
            {
                "tool_name": "str_replace",
                "args": {
                    "path": "/x",
                    "old_str": "alpha\nbeta\n",
                    "new_str": "alpha\nGAMMA\n",
                },
                "timestamp_ms": 1,
            },
            session=None,
        )
        assert diff is not None
        assert diff.format_source == "computed"
        assert diff.confidence == "medium"

    def test_view_returns_none(self) -> None:
        assert (
            CopilotV1Normalizer().extract_diff(
                {"tool_name": "view", "args": {"path": "/x"}, "timestamp_ms": 1},
                session=None,
            )
            is None
        )


# ----------------------------------------------------------------------
# Errors
# ----------------------------------------------------------------------


class TestExtractError:
    def test_detects_non_zero_exit_in_bash_result(self) -> None:
        # Copilot keeps success=true even for failed shells; the only signal
        # is the trailing exit code marker.
        entry = {
            "type": "tool.execution_complete",
            "data": {
                "toolCallId": "tc1",
                "success": True,
                "result": {"content": "boom\n<exited with exit code 17>"},
            },
            "_timestamp_ms": 1700000000000,
        }
        err = CopilotV1Normalizer().extract_error(entry)
        assert err is not None
        assert err.error_type == "tool_call_error"
        assert err.tool_call_id == "tc1"
        assert err.details == "<exited with exit code 17>"

    def test_explicit_success_false_is_an_error(self) -> None:
        entry = {
            "type": "tool.execution_complete",
            "data": {
                "toolCallId": "tc2",
                "success": False,
                "result": {"content": "request timed out"},
            },
            "_timestamp_ms": 1,
        }
        err = CopilotV1Normalizer().extract_error(entry)
        assert err is not None
        assert err.error_type == "timeout"

    def test_zero_exit_is_not_an_error(self) -> None:
        entry = {
            "type": "tool.execution_complete",
            "data": {
                "toolCallId": "tc3",
                "success": True,
                "result": {"content": "ok\n<exited with exit code 0>"},
            },
            "_timestamp_ms": 1,
        }
        assert CopilotV1Normalizer().extract_error(entry) is None

    def test_non_completion_entries_skipped(self) -> None:
        assert (
            CopilotV1Normalizer().extract_error(
                {"type": "user.message", "data": {"content": "hi"}, "_timestamp_ms": 1}
            )
            is None
        )


# ----------------------------------------------------------------------
# Token usage (output-only — Copilot doesn't log input tokens)
# ----------------------------------------------------------------------


class TestExtractTokenUsage:
    def test_emits_output_tokens_for_assistant_message(self) -> None:
        usages = CopilotV1Normalizer().extract_token_usage(
            {
                "type": "assistant.message",
                "data": {"messageId": "m1", "content": "hi", "outputTokens": 333},
                "_timestamp_ms": 1_700_000_000_000,
            }
        )
        assert len(usages) == 1
        u = usages[0]
        assert u.output_tokens == 333
        assert u.input_tokens == 0
        assert u.cache_read_tokens == 0
        assert u.cache_creation_tokens == 0
        assert u.reasoning_tokens == 0
        assert u.is_cumulative is False

    def test_emits_input_tokens_when_enrichment_attached(self) -> None:
        """When the daemon's log scraper attaches ``_input_tokens`` to
        the assistant.message entry, the normalizer should propagate it."""
        usages = CopilotV1Normalizer().extract_token_usage(
            {
                "type": "assistant.message",
                "data": {"messageId": "m1", "outputTokens": 333},
                "_input_tokens": 31607,
                "_timestamp_ms": 1_700_000_000_000,
            }
        )
        assert len(usages) == 1
        assert usages[0].input_tokens == 31607
        assert usages[0].output_tokens == 333

    def test_ignores_invalid_input_tokens(self) -> None:
        for bad in (-5, "100", None, 3.14):
            usages = CopilotV1Normalizer().extract_token_usage(
                {
                    "type": "assistant.message",
                    "data": {"outputTokens": 50},
                    "_input_tokens": bad,
                }
            )
            assert usages and usages[0].input_tokens == 0

    def test_skips_assistant_message_without_output_tokens(self) -> None:
        # Streaming intermediate chunks omit outputTokens; only the final
        # phase emits the token count. Don't synthesize zero-token rows.
        assert (
            CopilotV1Normalizer().extract_token_usage(
                {"type": "assistant.message", "data": {"content": "partial"}}
            )
            == []
        )

    def test_skips_zero_or_negative_output_tokens(self) -> None:
        assert (
            CopilotV1Normalizer().extract_token_usage(
                {"type": "assistant.message", "data": {"outputTokens": 0}}
            )
            == []
        )

    def test_skips_non_assistant_events(self) -> None:
        assert (
            CopilotV1Normalizer().extract_token_usage(
                {"type": "user.message", "data": {"outputTokens": 5}}
            )
            == []
        )


class TestUnsupportedExtractors:
    def test_compaction_returns_empty(self) -> None:
        assert CopilotV1Normalizer().extract_compaction([]) == []


# ----------------------------------------------------------------------
# Todos (forward-compat: tool not yet seen in the wild)
# ----------------------------------------------------------------------


class TestExtractTodo:
    def test_write_todos_tool(self) -> None:
        todos = CopilotV1Normalizer().extract_todo(
            {
                "tool_name": "write_todos",
                "args": {
                    "todos": [
                        {"content": "ship it", "status": "in_progress", "id": "t1"},
                        {"content": "write docs", "status": "pending"},
                    ]
                },
                "timestamp_ms": 1700000000000,
            }
        )
        assert todos is not None
        assert len(todos) == 2
        assert todos[0].content == "ship it"
        assert todos[0].status == "in_progress"
        assert todos[0].id == "t1"
        assert todos[0].agent_type == "copilot"

    def test_other_tools_return_none(self) -> None:
        assert (
            CopilotV1Normalizer().extract_todo({"tool_name": "view", "args": {}, "timestamp_ms": 1})
            is None
        )

    # ---- report_progress (markdown checkbox list in prDescription) ----

    def test_report_progress_parses_checkbox_list_into_todos(self) -> None:
        """``report_progress`` ships the running plan as a markdown checklist
        in ``prDescription``. Each ``- [ ]``/``- [x]`` line becomes a TODO
        item; the cloud SWE-agent's checklist is the agent's plan, not a
        chat turn, so this is the right shape for the dashboard."""
        todos = CopilotV1Normalizer().extract_todo(
            {
                "tool_name": "report_progress",
                "args": {
                    "commitMessage": "wip",
                    "prDescription": (
                        "- [x] Inspect CI status\n- [ ] Write the patch\n- [ ] Reply on the PR\n"
                    ),
                },
                "timestamp_ms": 1700000000000,
            },
            todo_state={},
        )
        assert todos is not None
        assert [(t.content, t.status) for t in todos] == [
            ("Inspect CI status", "completed"),
            ("Write the patch", "pending"),
            ("Reply on the PR", "pending"),
        ]
        assert todos[0].source_tool == "report_progress"
        assert todos[0].agent_type == "copilot"

    def test_report_progress_dedups_unchanged_checklists(self) -> None:
        """The agent calls ``report_progress`` repeatedly with the same
        checklist (no checkbox flips). Without state-change dedup, every
        repeat would emit a redundant TODO_UPDATE event — exactly the
        "checklist as assistant message over and over" problem users hit."""
        normalizer = CopilotV1Normalizer()
        state: dict = {}
        event = {
            "tool_name": "report_progress",
            "args": {"prDescription": "- [ ] Step one\n- [ ] Step two\n"},
            "timestamp_ms": 1700000000000,
        }
        first = normalizer.extract_todo(event, state)
        second = normalizer.extract_todo(event, state)
        assert first is not None and len(first) == 2
        # Same checklist, no state change → dedup returns None.
        assert second is None

    def test_report_progress_emits_again_when_state_changes(self) -> None:
        normalizer = CopilotV1Normalizer()
        state: dict = {}
        first = normalizer.extract_todo(
            {
                "tool_name": "report_progress",
                "args": {"prDescription": "- [ ] Step one\n- [ ] Step two\n"},
                "timestamp_ms": 1700000000000,
            },
            state,
        )
        # Flip first checkbox: state changed → must emit again.
        second = normalizer.extract_todo(
            {
                "tool_name": "report_progress",
                "args": {"prDescription": "- [x] Step one\n- [ ] Step two\n"},
                "timestamp_ms": 1700000001000,
            },
            state,
        )
        assert first is not None
        assert second is not None
        assert second[0].status == "completed"
        assert second[1].status == "pending"

    def test_report_progress_dedup_tolerates_whitespace_churn(self) -> None:
        """Cosmetic whitespace differences in checklist content (extra
        spaces between words, tab indentation, etc.) shouldn't trigger a
        redundant TODO_UPDATE — the agent's intent hasn't changed."""
        normalizer = CopilotV1Normalizer()
        state: dict = {}
        first = normalizer.extract_todo(
            {
                "tool_name": "report_progress",
                "args": {"prDescription": "- [ ] Step one\n- [ ] Step two\n"},
                "timestamp_ms": 1700000000000,
            },
            state,
        )
        # Same checklist, same status, but with extra internal whitespace.
        second = normalizer.extract_todo(
            {
                "tool_name": "report_progress",
                "args": {"prDescription": "- [ ] Step  one\n- [ ]   Step two\n"},
                "timestamp_ms": 1700000001000,
            },
            state,
        )
        assert first is not None
        assert second is None  # whitespace-normalized signature matches

    def test_report_progress_without_checkboxes_returns_none(self) -> None:
        """Plain prose in ``prDescription`` (no checklist) → no todos. The
        agent sometimes uses ``report_progress`` purely for the commit
        message; we shouldn't manufacture TODO items from random text."""
        todos = CopilotV1Normalizer().extract_todo(
            {
                "tool_name": "report_progress",
                "args": {"prDescription": "Just some narrative prose.\n"},
                "timestamp_ms": 1700000000000,
            },
            todo_state={},
        )
        assert todos is None


# ----------------------------------------------------------------------
# End-to-end via EventProcessor
# ----------------------------------------------------------------------


class TestProcessorIntegration:
    def test_processor_extracts_skills_and_file_ops_from_fixture(self) -> None:
        events = _build_normalizer_events_from_fixture()
        processor = EventProcessor("copilot", "1.0.40")
        synthetic = processor.process_events(events)

        names = {s.name for s in synthetic}
        assert UNIFIED_FILE_OPERATION in names
        assert UNIFIED_SKILL_ACTIVATION in names

        # The fixture exercises only `view` (read) and `bash` — no edits — so
        # we should NOT emit any todo updates from this short session.
        assert UNIFIED_TODO_UPDATE not in names
        # Same for explicit ERROR / SESSION metadata: those flow through a
        # different path in processing.py and aren't emitted here.
        assert ERROR_EVENT not in names
        assert SESSION_METADATA not in names

    def test_processor_extracts_apply_patch_writes_and_edits_from_fixture(self) -> None:
        """The refreshed fixture creates, deletes, recreates, and edits the
        same file via ``apply_patch``. All four should surface as
        ``UNIFIED_FILE_OPERATION`` events with diffs."""
        events = _build_normalizer_events_from_fixture()
        processor = EventProcessor("copilot", "1.0.40")
        synthetic = processor.process_events(events)

        patch_ops = [
            s
            for s in synthetic
            if s.name == UNIFIED_FILE_OPERATION and s.value["_source"]["tool"] == "apply_patch"
        ]
        # Add + Delete + Add + Update = 4 operations (all on the same file)
        assert len(patch_ops) == 4
        ops_by_index = [(op.value["operation"], op.value["file_path"]) for op in patch_ops]
        assert ops_by_index == [
            ("write", "/tmp/copilot-session-state-learnings.md"),
            ("edit", "/tmp/copilot-session-state-learnings.md"),  # Delete → edit
            ("write", "/tmp/copilot-session-state-learnings.md"),
            ("edit", "/tmp/copilot-session-state-learnings.md"),
        ]
        # All apply_patch ops with hunks should carry a high-confidence
        # diff. Delete patches have no hunks so legitimately no diff.
        ops_with_diff = [op for op in patch_ops if "diff" in op.value]
        assert len(ops_with_diff) == 3  # add, re-add, update — not the delete
        for op in ops_with_diff:
            assert op.value["diff"]["confidence"] == "high"
            assert op.value["diff"]["format_source"] == "codex_apply_patch"


# ----------------------------------------------------------------------
# apply_patch (custom tool body, same format as Codex)
# ----------------------------------------------------------------------


class TestApplyPatchFileOperations:
    PATCH_ADD = "*** Begin Patch\n*** Add File: /tmp/foo.md\n+# title\n+body\n*** End Patch\n"
    PATCH_UPDATE = (
        "*** Begin Patch\n*** Update File: /tmp/foo.md\n@@\n-body\n+new body\n*** End Patch\n"
    )
    PATCH_DELETE = "*** Begin Patch\n*** Delete File: /tmp/foo.md\n*** End Patch\n"
    PATCH_MULTI = (
        "*** Begin Patch\n"
        "*** Add File: /tmp/a.md\n"
        "+a1\n"
        "*** Update File: /tmp/b.md\n"
        "@@\n"
        "-old\n"
        "+new\n"
        "*** End Patch\n"
    )

    def _event(self, args: object) -> dict:
        return {
            "tool_name": "apply_patch",
            "args": args,
            "timestamp_ms": 1700000000000,
            "event_id": "ev-patch",
        }

    def test_add_file_yields_write(self) -> None:
        ops = CopilotV1Normalizer().extract_file_operations(self._event({"input": self.PATCH_ADD}))
        assert len(ops) == 1
        assert ops[0].operation == "write"
        assert ops[0].file_path == "/tmp/foo.md"
        assert ops[0].source_tool == "apply_patch"
        assert ops[0].confidence == "high"
        assert ops[0].diff is not None
        assert ops[0].diff.lines_added == [1, 2]

    def test_update_file_yields_edit_with_diff(self) -> None:
        ops = CopilotV1Normalizer().extract_file_operations(
            self._event({"input": self.PATCH_UPDATE})
        )
        assert len(ops) == 1
        assert ops[0].operation == "edit"
        assert ops[0].diff is not None
        # Diff should include the +/- lines
        joined = "\n".join(line for h in ops[0].diff.hunks for line in h.lines)
        assert "+new body" in joined
        assert "-body" in joined

    def test_delete_file_yields_edit(self) -> None:
        # The unified schema has no "delete" op today; we map deletes to
        # "edit" so the dashboard still records that the file was touched.
        ops = CopilotV1Normalizer().extract_file_operations(
            self._event({"input": self.PATCH_DELETE})
        )
        assert len(ops) == 1
        assert ops[0].operation == "edit"
        assert ops[0].file_path == "/tmp/foo.md"

    def test_multi_file_patch_yields_one_op_per_file(self) -> None:
        ops = CopilotV1Normalizer().extract_file_operations(
            self._event({"input": self.PATCH_MULTI})
        )
        assert len(ops) == 2
        assert (ops[0].operation, ops[0].file_path) == ("write", "/tmp/a.md")
        assert (ops[1].operation, ops[1].file_path) == ("edit", "/tmp/b.md")

    def test_string_args_handled_directly(self) -> None:
        """Some test paths pass the patch body as the raw string args."""
        ops = CopilotV1Normalizer().extract_file_operations(self._event(self.PATCH_ADD))
        assert len(ops) == 1
        assert ops[0].file_path == "/tmp/foo.md"

    def test_extract_diff_returns_merged_hunks(self) -> None:
        diff = CopilotV1Normalizer().extract_diff(
            self._event({"input": self.PATCH_MULTI}), session=None
        )
        assert diff is not None
        assert diff.format_source == "codex_apply_patch"
        # Merged: a's +a1 and b's +new
        assert len(diff.hunks) >= 2

    def test_empty_patch_returns_empty(self) -> None:
        assert CopilotV1Normalizer().extract_file_operations(self._event("")) == []
        assert CopilotV1Normalizer().extract_diff(self._event(""), session=None) is None
