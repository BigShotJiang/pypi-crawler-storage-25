"""Tests for Copilot CLI log scraping (input-token enrichment)."""

from __future__ import annotations

import os
from pathlib import Path

from agentstream.enrichment.copilot_logs import (
    InputTokenIndex,
    find_log_for_session,
    parse_utilization_lines,
)


def _write_log(
    logs_dir: Path,
    name: str,
    session_id: str,
    util_lines: list[tuple[str, int]],
) -> Path:
    """Synthesize a Copilot ``process-*.log`` for tests."""
    path = logs_dir / name
    body = [
        "2026-05-05T05:27:34.644Z [INFO] Session indexing debug: SESSION_INDEXING=false",
        f"2026-05-05T05:27:34.676Z [INFO] Workspace initialized: {session_id} (checkpoints: 0)",
    ]
    for ts, tokens in util_lines:
        body.append(
            f"{ts} [INFO] CompactionProcessor: Utilization 11.6% "
            f"({tokens}/272000 tokens) below threshold 80%"
        )
    path.write_text("\n".join(body) + "\n")
    return path


class TestFindLogForSession:
    def test_returns_log_when_session_id_matches(self, tmp_path: Path) -> None:
        logs = tmp_path / "logs"
        logs.mkdir()
        log = _write_log(logs, "process-1-1.log", "abc-123", [])

        assert find_log_for_session("abc-123", logs_dir=logs) == log

    def test_returns_none_when_session_id_absent(self, tmp_path: Path) -> None:
        logs = tmp_path / "logs"
        logs.mkdir()
        _write_log(logs, "process-1-1.log", "other-session", [])

        assert find_log_for_session("missing", logs_dir=logs) is None

    def test_returns_none_when_logs_dir_missing(self, tmp_path: Path) -> None:
        assert find_log_for_session("any", logs_dir=tmp_path / "nope") is None

    def test_picks_newest_among_multiple_matches(self, tmp_path: Path) -> None:
        """The newest process owns the active session, so prefer recent logs."""
        logs = tmp_path / "logs"
        logs.mkdir()
        old = _write_log(logs, "process-1-1.log", "shared-id", [])
        new = _write_log(logs, "process-2-2.log", "shared-id", [])
        # Force mtime ordering — file system tick resolution can otherwise
        # leave both at the same second.
        os.utime(old, (1_000_000, 1_000_000))
        os.utime(new, (2_000_000, 2_000_000))

        assert find_log_for_session("shared-id", logs_dir=logs) == new

    def test_skips_non_log_files(self, tmp_path: Path) -> None:
        logs = tmp_path / "logs"
        logs.mkdir()
        (logs / "not-a-log.txt").write_text("Workspace initialized: abc-123")

        assert find_log_for_session("abc-123", logs_dir=logs) is None


class TestParseUtilizationLines:
    def test_extracts_each_utilization_line(self, tmp_path: Path) -> None:
        log = _write_log(
            tmp_path,
            "p.log",
            "sid",
            [
                ("2026-05-05T05:28:07.856Z", 31607),
                ("2026-05-05T05:28:12.331Z", 34717),
                ("2026-05-05T05:28:17.393Z", 37565),
            ],
        )
        index = parse_utilization_lines(log)
        assert len(index) == 3

    def test_returns_empty_index_for_missing_file(self, tmp_path: Path) -> None:
        index = parse_utilization_lines(tmp_path / "no-such-file.log")
        assert len(index) == 0

    def test_skips_unrelated_log_lines(self, tmp_path: Path) -> None:
        log = tmp_path / "p.log"
        log.write_text(
            "2026-05-05T05:28:07.856Z [INFO] some other log line\n"
            "2026-05-05T05:28:08.000Z [INFO] CompactionProcessor: Utilization 11.6% "
            "(31607/272000 tokens) below threshold 80%\n"
            "2026-05-05T05:28:09.000Z [INFO] Workspace initialized: x\n"
        )
        index = parse_utilization_lines(log)
        assert len(index) == 1


class TestInputTokenIndexLookup:
    """All timestamps below are in milliseconds (epoch-style)."""

    BASE_MS = 1_700_000_000_000  # arbitrary epoch ms — readable test scale

    def test_returns_most_recent_preceding_entry(self) -> None:
        index = InputTokenIndex(
            [
                (self.BASE_MS + 1_000, 100),  # +1s
                (self.BASE_MS + 5_000, 200),  # +5s
                (self.BASE_MS + 9_000, 300),  # +9s
            ]
        )
        # Message at +6s — should pick the +5s entry (most recent before).
        assert index.lookup(self.BASE_MS + 6_000) == 200

    def test_returns_exact_match(self) -> None:
        index = InputTokenIndex([(self.BASE_MS, 50)])
        assert index.lookup(self.BASE_MS) == 50

    def test_returns_none_when_no_preceding_entry(self) -> None:
        index = InputTokenIndex([(self.BASE_MS + 5_000, 200)])
        # Message arrives 5s *before* the only entry — nothing to match.
        assert index.lookup(self.BASE_MS) is None

    def test_returns_none_when_gap_exceeds_window(self) -> None:
        # Default window is 60s; 90s gap exceeds it.
        index = InputTokenIndex([(self.BASE_MS, 500)])
        assert index.lookup(self.BASE_MS + 90_000) is None

    def test_accepts_gap_within_window(self) -> None:
        # 30s gap is well within the 60s window.
        index = InputTokenIndex([(self.BASE_MS, 500)])
        assert index.lookup(self.BASE_MS + 30_000) == 500

    def test_returns_none_for_empty_index(self) -> None:
        assert InputTokenIndex([]).lookup(self.BASE_MS) is None


class TestCopilotHomeOverride:
    def test_honours_copilot_home_env(self, tmp_path: Path, monkeypatch) -> None:
        """``find_log_for_session`` reads ``$COPILOT_HOME`` via its own
        helper — verify the env var override path works without an
        explicit ``logs_dir`` argument."""
        copilot_home = tmp_path / "custom-home"
        logs = copilot_home / "logs"
        logs.mkdir(parents=True)
        log = _write_log(logs, "process-x.log", "via-env", [])

        monkeypatch.setenv("COPILOT_HOME", str(copilot_home))
        assert find_log_for_session("via-env") == log
