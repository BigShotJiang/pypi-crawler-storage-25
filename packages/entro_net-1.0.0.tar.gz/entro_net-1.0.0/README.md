# 🔴 ENTRO-NET — Distributed Entropy Synchronization Protocols for Collective Neural Networks

> *"Stability is not an individual property — it is a collective effort."*  
> — Samir Baladi, April 2026

**ENTROPY RESEARCH LAB · E-LAB-06 · v1.0.0**

[![DOI](https://img.shields.io/badge/DOI-10.5281%2Fzenodo.19474217-blue.svg)](https://doi.org/10.5281/zenodo.19474217)
[![OSF](https://img.shields.io/badge/OSF-10.17605%2FOSF.IO%2F9Y7RX-teal.svg)](https://doi.org/10.17605/OSF.IO/9Y7RX)
[![License: MIT](https://img.shields.io/badge/License-MIT-red.svg)](LICENSE)
[![Python 3.11+](https://img.shields.io/badge/Python-3.11+-darkred.svg)](https://python.org)
[![PyPI](https://img.shields.io/badge/PyPI-entro--net-red.svg)](https://pypi.org/project/entro-net)
[![GitLab](https://img.shields.io/badge/GitLab-ENTRO--NET-orange.svg)](https://gitlab.com/gitdeeper10/ENTRO-NET)
[![GitHub](https://img.shields.io/badge/GitHub-ENTRO--NET-darkred.svg)](https://github.com/gitdeeper10/ENTRO-NET)
[![Bitbucket](https://img.shields.io/badge/Bitbucket-ENTRO--NET-blue.svg)](https://bitbucket.org/gitdeeper-10/entro-net)
[![Codeberg](https://img.shields.io/badge/Codeberg-ENTRO--NET-cyan.svg)](https://codeberg.org/gitdeeper10/entro-net)

---

## 📋 Overview

**ENTRO-NET** is the sixth project of the **EntropyLab** research program (**E-LAB-06**). It represents the leap from self-calibrating individual systems — mastered in **ENTRO-EVO (E-LAB-05)** — to **distributed networked systems**.

After successfully enabling a system to self-calibrate its weights via the **Adaptive Entropy Weighting (AEW)** algorithm with a **78.1% error reduction**, this research builds a protocol that allows multiple nodes to physically share their stability states. The goal is to **prevent cascading failure** by synchronizing entropy flows across the network.

Extended empirical validation across **N = 2 to N = 50 nodes** reveals a non-trivial crossover from near-linear variance growth to a bounded saturation regime, with no catastrophic failure observed for any tested configuration.

---

## 🎯 Core Innovations

| Component | Description |
|-----------|-------------|
| **Ψ-Sync Protocol** | Real-time sharing of the entropy state Ψ(t) between nodes — stable nodes absorb informational pressure from stressed nodes |
| **Collective-AEW** | Extension of the single-node AEW algorithm: each node learns from both its own experience and the collective stability history of the entire network |
| **θ_net Threshold** | Dynamic networked threshold elevated from local to global level, ensuring the system responds as a coherent single entity |
| **Fault Isolation** | Automatic isolation of nodes exceeding Ψ_critical to prevent entropic contagion from propagating to stable regions |

---

## 📐 Mathematical Framework

**Collective State:**
```
Ψ_net(t) = { Ψ_1(t), Ψ_2(t), ..., Ψ_N(t) }
```

**Entropy Synchronization Signal:**
```
δ_i_sync(t) = κ · Σ_{j ≠ i} [ Ψ_j(t) − Ψ_i(t) ]
```

**Collective-AEW Weight Update:**
```
w_i(t+1) = w_i(t) − η · [ ∇L_local(t) + β · ∇L_collective(t) ]
```

**Networked Threshold:**
```
θ_net(t) = θ_base + γ · Var[ Ψ_net(t) ]
```

**Global Lyapunov Stability Candidate:**
```
V_net(t) = (1/2) · Σ_{i=1}^{N} [ Ψ_i(t) − Ψ_target ]²
```

---

## 📊 Technical Objectives

| Objective | Technical Description | Expected Outcome |
|-----------|----------------------|------------------|
| **Distributed Stability** | Balance Ψ state across at least 3 distributed nodes | Reduce total entropy variance by > 50% |
| **Networked Transfer** | Instant transfer of optimal weights [w₁, w₂, w₃] between nodes | Reduce adaptation time for new nodes by > 70% |
| **Fault Isolation** | Isolate nodes exceeding Ψ_critical | 100% protection for remaining network members |

---

## 📈 Scaling Results

### Extended Analysis (N = 20, 30, 50)

Systematic experiments under the scraper regime (800 steps, 4 repetitions per N):

| N | Variance (mean ± std) |
|---|----------------------|
| 20 | 0.165380 ± 0.002169 |
| 30 | 0.197713 ± 0.002204 |
| 50 | 0.221481 ± 0.000677 |

### Comparison with Linear Extrapolation

Linear model fitted for N ≤ 15: `σ² = 0.0101·N − 0.0331` (R² = 0.986)

| N | Linear Prediction | Actual Variance | Deviation |
|---|-------------------|-----------------|-----------|
| 20 | 0.1689 | 0.1654 | −2.1% |
| 30 | 0.2699 | 0.1977 | −26.7% |
| 50 | 0.4719 | 0.2215 | −53.1% |

> **Key finding:** Linear scaling breaks down beyond N ≈ 20. The system enters a saturation regime where additional nodes contribute progressively less to global variance.

### Scaling Curve

```
    0.25 ┤
         │                                    ★ N=50
    0.20 ┤                                ●
         │                            ●
         │                        ●
    0.15 ┤                    ●
         │                ●
         │            ●
    0.10 ┤        ●
         │    ●
         │●
    0.05 ┤●
         │
    0.00 ┼━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━→ N
         0    5    10   15   20   25   30   35   40   45   50

         ●  Empirical data points (mean variance)
         ──  Linear fit (N ≤ 15): σ² = 0.0101·N − 0.0331
         ──  Saturation fit: σ² = 0.228·(1 − e^{−N/16.2})
         ▒   Crossover region (N ≈ 15–25)
```

---

## 🔬 Scaling Regimes

| Regime | N Range | Behavior | Description |
|--------|---------|----------|-------------|
| Linear Accumulation | 2 – 15 | σ² ≈ 0.0101·N − 0.0331 | Near-linear growth, R² = 0.986 |
| Transition | 15 – 25 | Bending toward saturation | Crossover zone |
| Saturation | 25 – 50 | σ² → 0.22 | Variance ceiling observed |

---

## 📐 Proposed Saturation Model

```
σ²(N) = σ²_max · (1 − e^{−N/N₀})
```

| Parameter | Symbol | Value | Interpretation |
|-----------|--------|-------|----------------|
| Saturation ceiling | σ²_max | 0.228 | Maximum variance asymptote |
| Characteristic scale | N₀ | 16.2 | Crossover scale (nodes) |
| Goodness of fit | R² | 0.992 | — |
| Root mean square error | RMSE | 0.004 | — |

**Asymptotic properties:**
- For small N: `σ² ≈ (σ²_max / N₀) · N` → linear growth
- For large N: `σ² → σ²_max` → bounded variance

---

## 🧠 Key Scientific Insights

**1. No Catastrophic Failure**  
The system remains stable and operational for all tested configurations (N ≤ 50). Variance does not diverge.

**2. Intrinsic Self-Regulation**  
Variance growth is actively constrained by three emergent internal mechanisms:
- Adaptive aggression auto-tuning (α self-adjusts)
- Collective-AEW weight redistribution
- Networked threshold elevation (θ_net)

**3. Smooth Crossover**  
The transition from linear growth to saturation is gradual — a soft scaling crossover rather than a sharp phase transition.

**4. Bounded Variance Ceiling**  
The system approaches a natural ceiling σ² ≈ 0.23, independent of further node addition beyond N ≈ 30.

---

## 🚀 Practical Recommendations

| Use Case | Recommended N | Expected Variance | Reliability |
|----------|--------------|-------------------|-------------|
| Production (critical) | 2 – 5 | < 0.05 | 🟢 Excellent |
| Production (standard) | 6 – 12 | 0.05 – 0.09 | 🟢 Good |
| Experimental | 13 – 20 | 0.09 – 0.17 | 🟡 Acceptable |
| Research / Development | 21 – 30 | 0.17 – 0.20 | 🔴 Degraded |
| Not recommended | > 30 | > 0.20 | ⚠️ Saturated |

---

## 📁 Project Structure

```
ENTRO-NET/
│
├── entro_net/                  # Core library
│   ├── __init__.py
│   ├── psi_sync.py             # Ψ-Sync protocol
│   ├── collective_aew.py       # Collective-AEW optimizer
│   ├── net_threshold.py        # θ_net dynamic threshold
│   ├── fault_isolation.py      # Cascading failure prevention
│   └── simulator.py            # Distributed simulation engine
│
├── bin/                        # Executables
│   └── run_simulation.py
│
├── tests/                      # Unit and integration tests
├── examples/                   # Usage examples
├── scripts/                    # Utility scripts
├── docs/                       # Documentation
├── results/                    # Simulation outputs
└── Netlify/                    # Static website
```

---

## ⚡ Quick Start

```python
from entro_net import PsiSync, CollectiveAEW, NetThreshold

# Initialize 3-node network
sync       = PsiSync(n_nodes=3)
collective = CollectiveAEW(eta=0.01, target=0.339)
threshold  = NetThreshold(theta_base=1.2)

# Run distributed control loop
for t in range(500):
    psi_states = [node.observe() for node in nodes]

    # Synchronize entropy states across network
    synced_psi = sync.broadcast(psi_states)

    # Collective weight adaptation
    weights = collective.step(synced_psi)

    # Apply global networked threshold
    theta = threshold.update(synced_psi)

    # Isolate faulty nodes if needed
    if sync.detect_fault(psi_states):
        sync.isolate_node(faulty_id)
```

**Reproduce all experiments:**

```bash
python bin/run_simulation.py \
  --nodes N \
  --steps 800 \
  --regime scraper \
  --repeats 4
```

---

## 🔗 Roadmap Integration

| Project | Code | Contribution to ENTRO-NET |
|---------|------|--------------------------|
| ENTROPIA | E-LAB-01 | Unified Dissipation State Function — foundational entropy formalism |
| ENTRO-AI | E-LAB-02 | AI risk monitoring — dynamic entropy threshold design |
| ENTRO-CORE | E-LAB-03 | Singular system will — local AEW weight architecture |
| ENTRO-ENGINE | E-LAB-04 | Budget distribution between coupled systems |
| ENTRO-EVO | E-LAB-05 | Self-learning AEW — 78.1% error reduction baseline |
| **ENTRO-NET** | **E-LAB-06** | **Collective Ψ-Sync — distributed stability (this work)** |

---

## 📚 Links & Resources

| Resource | URL |
|----------|-----|
| 📄 Paper (Zenodo) | [10.5281/zenodo.19474217](https://doi.org/10.5281/zenodo.19474217) |
| 📋 OSF Preregistration | [10.17605/OSF.IO/9Y7RX](https://doi.org/10.17605/OSF.IO/9Y7RX) |
| 💻 GitLab | [gitlab.com/gitdeeper10/ENTRO-NET](https://gitlab.com/gitdeeper10/ENTRO-NET) |
| 💻 GitHub | [github.com/gitdeeper10/ENTRO-NET](https://github.com/gitdeeper10/ENTRO-NET) |
| 💻 Bitbucket | [bitbucket.org/gitdeeper-10/entro-net](https://bitbucket.org/gitdeeper-10/entro-net) |
| 💻 Codeberg | [codeberg.org/gitdeeper10/entro-net](https://codeberg.org/gitdeeper10/entro-net) |
| 📦 PyPI | [pypi.org/project/entro-net](https://pypi.org/project/entro-net) |
| 🌐 Website | [entro-net.netlify.app](https://entro-net.netlify.app) |

---

## 📝 Citation

```bibtex
@software{baladi2026entronet,
  author    = {Baladi, Samir},
  title     = {ENTRO-NET: Distributed Entropy Synchronization Protocols
               for Collective Neural Networks},
  year      = {2026},
  version   = {1.0.0},
  doi       = {10.5281/zenodo.19474217},
  url       = {https://github.com/gitdeeper10/ENTRO-NET},
  note      = {E-LAB-06. Builds on E-LAB-01 through E-LAB-05.
               EntropyLab Research Program.
               OSF Preregistration: 10.17605/OSF.IO/9Y7RX}
}
```

---

## 👤 Author

**Samir Baladi**  
Interdisciplinary AI & Theoretical Physics Researcher  
Ronin Institute / Rite of Renaissance

- 📧 [gitdeeper@gmail.com](mailto:gitdeeper@gmail.com)
- 🆔 ORCID: [0009-0003-8903-0029](https://orcid.org/0009-0003-8903-0029)
- 💻 GitLab / GitHub / Codeberg: [@gitdeeper10](https://gitlab.com/gitdeeper10)

---

## 📄 License

MIT License — see [LICENSE](LICENSE) file for details.

---

*Part of the EntropyLab ten-project research program · E-LAB-06 ✅ Complete*

> *"Intelligence by Design, Stability by Physics, Evolution by Learning, Harmony by Network"*
