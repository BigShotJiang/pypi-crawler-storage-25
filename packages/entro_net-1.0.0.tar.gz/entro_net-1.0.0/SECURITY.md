# Security Policy for ENTRO-NET

## Supported Versions

| Version | Supported | Notes |
|---------|-----------|-------|
| 1.0.x   | ✅ Yes    | Current stable |
| < 1.0   | ❌ No     | Pre-release only |

## Reporting a Vulnerability

**Please DO NOT report security vulnerabilities through public GitHub issues.**

Instead, please report them via email to: **gitdeeper@gmail.com**

You should receive a response within 48 hours. If the issue is confirmed, we will:

1. Acknowledge receipt of the vulnerability report
2. Assess the severity and impact
3. Develop and test a fix
4. Release a patch version
5. Publicly disclose after fix is deployed

## Security Considerations for ENTRO-NET

### Network Communication
ENTRO-NET uses Ψ-Sync protocol for node communication. In production:

- Always use encrypted channels (TLS/SSL) for cross-node communication
- Implement authentication between nodes
- Use network isolation (VLANs, firewalls) for critical deployments

### Input Validation
All node inputs are validated:
- Ψ values clamped to [0, 1]
- Weights normalized to sum = 1.0
- Node count limited to ≤ 10 for stability

### Fault Isolation
ENTRO-NET includes automatic fault isolation:
- Nodes exceeding Ψ_critical are automatically isolated
- Isolated nodes cannot affect network stability
- Manual override available for administrators

## Known Vulnerabilities (None)

No security vulnerabilities are currently known.

## Responsible Disclosure

We follow responsible disclosure practices:

1. Reporter notifies us privately
2. We confirm and develop fix (typically within 7-14 days)
3. Fix is released with patch version
4. Public disclosure after 30 days or when users have had time to update

## Security Updates

Subscribe to GitHub/GitLab releases to receive security update notifications.

---

**Last updated:** April 8, 2026
