# Contributing to ENTRO-NET

Thank you for your interest in contributing to **ENTRO-NET** (E-LAB-06)!

## How to Contribute

### 1. Report Bugs
- Use GitHub/GitLab Issues
- Include: Python version, OS, steps to reproduce
- Label: `bug`

### 2. Suggest Features
- Open an issue with label `enhancement`
- Describe the use case and expected behavior
- Reference related EntropyLab projects if applicable

### 3. Submit Code Changes

#### Prerequisites
```bash
pip install -e .[dev]
pre-commit install
```

Development Workflow

```bash
# Fork and clone your fork
git clone https://github.com/YOUR_USERNAME/ENTRO-NET
cd ENTRO-NET

# Create a feature branch
git checkout -b feature/your-feature-name

# Make changes and run tests
pytest tests/ -v

# Commit with conventional commit format
git commit -m "feat: add new synchronization protocol"

# Push and create Pull Request
git push origin feature/your-feature-name
```

4. Update Documentation

· Edit README.md, docs/, or docstrings
· Ensure make docs builds successfully

Code Style

· Python: PEP 8 (use black)
· Type hints: Required for all public functions
· Docstrings: Google style

Testing Requirements

· All tests must pass: pytest tests/ -v
· Coverage should not decrease: pytest --cov=entro_net
· New features require tests

Commit Convention

Type Description
feat New feature
fix Bug fix
docs Documentation
test Testing
refactor Code refactor
perf Performance improvement

Questions?

Open an issue or email: gitdeeper@gmail.com

---

Thank you for contributing to collective intelligence stability! 🚀
