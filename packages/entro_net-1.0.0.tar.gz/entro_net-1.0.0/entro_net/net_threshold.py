"""
Networked Threshold: θ_net = θ_base + γ·Var(Ψ_i)

Where γ controls sensitivity to network variance
"""

from typing import List
from collections import deque


class NetThreshold:
    def __init__(self, theta_base: float = 1.4, gamma: float = 2.5,
                 variance_window: int = 20):
        """
        Parameters
        ----------
        theta_base : float
            Base threshold (θ_base) - classical value from ENTRO-EVO
        gamma : float
            Variance sensitivity coefficient (γ)
        variance_window : int
            Window for rolling variance calculation
        """
        self.theta_base = theta_base
        self.gamma = gamma                      # γ: variance sensitivity
        self.variance_window = variance_window
        self.variance_history = deque(maxlen=variance_window)
        
    def update(self, psi_states: List[float]) -> float:
        """
        Networked Threshold Equation:
        θ_net = θ_base + γ·Var(Ψ_i)
        
        Higher variance -> higher threshold (more cautious)
        """
        # Calculate variance across network
        variance = self._calculate_variance(psi_states)
        self.variance_history.append(variance)
        
        # Rolling average variance for stability
        if self.variance_history:
            avg_variance = sum(self.variance_history) / len(self.variance_history)
        else:
            avg_variance = variance
        
        # Networked threshold
        theta_net = self.theta_base + self.gamma * avg_variance
        
        # Clamp to reasonable range
        return max(1.0, min(2.5, theta_net))
    
    def _calculate_variance(self, values: List[float]) -> float:
        if not values:
            return 0.0
        mean = sum(values) / len(values)
        return sum((x - mean) ** 2 for x in values) / len(values)
    
    def get_threshold(self) -> float:
        if self.variance_history:
            return self.theta_base + self.gamma * (sum(self.variance_history) / len(self.variance_history))
        return self.theta_base
