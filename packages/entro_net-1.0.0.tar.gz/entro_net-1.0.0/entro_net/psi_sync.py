"""
Ψ-Sync Protocol: Enhanced Entropy Exchange with Fully Adaptive Aggression
E-LAB-06 - Advanced synchronization for collective intelligence
"""

from typing import List
from collections import deque
import math


class PsiSync:
    def __init__(self, n_nodes: int = 3, kappa: float = 0.1, 
                 aggression: float = None, adaptive_aggression: bool = True):
        """
        Enhanced Ψ-Sync with fully adaptive aggression
        
        Parameters
        ----------
        kappa : float
            Base synchronization constant
        aggression : float
            Initial aggression (if None, starts at 1.0 and adapts)
        adaptive_aggression : bool
            Fully adaptive mode
        """
        self.n_nodes = n_nodes
        self.kappa = kappa
        self.adaptive_aggression = adaptive_aggression
        
        # Initial aggression
        self.aggression = aggression if aggression is not None else 1.0
        self.base_aggression = self.aggression
        
        self.C_sync = 0.5
        self.lambda_weights = [1.0 / n_nodes] * n_nodes
        
        # Tracking for adaptation
        self.stress_history = deque(maxlen=30)
        self.aggression_history = deque(maxlen=30)
        self.performance_history = deque(maxlen=20)
        self.last_variance = 1.0
        
        # Learning parameters for aggression
        self.aggression_learning_rate = 0.05
        self.aggression_momentum = 0.9
        self.aggression_velocity = 0.0
        
    def collective_state(self, psi_states: List[float]) -> float:
        """Ψ_total(t) = Σ λ_i·Ψ_i(t) + α·C_sync(t)"""
        weighted_sum = sum(self.lambda_weights[i] * psi_states[i] 
                          for i in range(self.n_nodes))
        return weighted_sum + self.aggression * self.C_sync
    
    def entropy_exchange(self, psi_states: List[float]) -> List[float]:
        """
        Enhanced Entropy Exchange with adaptive cubic term:
        E_sync,i = Σ [α·κ·(Ψ_j - Ψ_i) + α²·(Ψ_j - Ψ_i)³]
        
        Cubic coefficient α² makes aggression amplify non-linear response
        """
        exchange_signals = []
        for i in range(self.n_nodes):
            total_exchange = 0.0
            for j in range(self.n_nodes):
                if j != i:
                    diff = psi_states[j] - psi_states[i]
                    # Linear term: α·κ·diff
                    linear = self.aggression * self.kappa * diff
                    # Cubic term: α²·diff³ (amplifies large differences)
                    cubic = (self.aggression ** 2) * (diff ** 3)
                    total_exchange += linear + cubic
            exchange_signals.append(total_exchange)
        return exchange_signals
    
    def calculate_network_stress(self, psi_states: List[float]) -> float:
        """Calculate multi-factor network stress"""
        variance = self._calculate_variance(psi_states)
        max_deviation = max(abs(psi - 0.339) for psi in psi_states)
        avg_deviation = sum(abs(psi - 0.339) for psi in psi_states) / self.n_nodes
        
        # Combined stress metric
        stress = variance + 0.3 * max_deviation + 0.2 * avg_deviation
        self.stress_history.append(stress)
        return stress
    
    def calculate_performance_reward(self, psi_states: List[float]) -> float:
        """Calculate reward based on stability improvement"""
        current_variance = self._calculate_variance(psi_states)
        
        if self.last_variance > 0:
            improvement = (self.last_variance - current_variance) / self.last_variance
        else:
            improvement = 0.0
        
        self.performance_history.append(improvement)
        self.last_variance = current_variance
        
        # Reward: positive for improvement, negative for deterioration
        return improvement
    
    def update_aggression(self, psi_states: List[float]):
        """Fully adaptive aggression using reinforcement learning"""
        if not self.adaptive_aggression:
            return
        
        # Calculate stress and reward
        stress = self.calculate_network_stress(psi_states)
        reward = self.calculate_performance_reward(psi_states)
        
        # Target aggression based on stress
        # Higher stress needs higher aggression
        stress_target = 1.0 + 3.0 * stress
        
        # Reward adjustment: good performance reduces need for high aggression
        reward_adjustment = -0.5 * max(0, reward) if reward > 0 else 0.2 * reward
        
        # Combined target
        target_aggression = max(0.5, min(5.0, stress_target + reward_adjustment))
        
        # Momentum-based update
        error = target_aggression - self.aggression
        self.aggression_velocity = (self.aggression_momentum * self.aggression_velocity +
                                    self.aggression_learning_rate * error)
        self.aggression += self.aggression_velocity
        
        # Clamp aggression
        self.aggression = max(0.5, min(5.0, self.aggression))
        self.aggression_history.append(self.aggression)
    
    def broadcast(self, psi_states: List[float]) -> List[float]:
        """Apply entropy exchange with fully adaptive aggression"""
        # Update aggression based on network state
        self.update_aggression(psi_states)
        
        # Calculate exchange
        exchange = self.entropy_exchange(psi_states)
        
        # Update coupling coefficient
        variance = self._calculate_variance(psi_states)
        self.C_sync = min(0.9, max(0.05, variance * 2.0 * math.sqrt(self.aggression)))
        
        # Synchronized states
        synced_states = [psi_states[i] + exchange[i] 
                        for i in range(self.n_nodes)]
        
        # Clamp to [0, 1]
        return [max(0.0, min(1.0, s)) for s in synced_states]
    
    def _calculate_variance(self, values: List[float]) -> float:
        if not values:
            return 0.0
        mean = sum(values) / len(values)
        return sum((x - mean) ** 2 for x in values) / len(values)
    
    def get_coupling(self) -> float:
        return self.C_sync
    
    def get_aggression(self) -> float:
        return self.aggression
    
    def get_aggression_history(self) -> List[float]:
        return list(self.aggression_history)
