"""
Fault Isolation: Prevent cascading failure (entropy infection)
Based on Lyapunov stability analysis
"""

from typing import List, Set, Dict
from collections import deque


class FaultIsolation:
    def __init__(self, psi_critical: float = 0.8, 
                 recovery_threshold: float = 0.4,
                 fault_window: int = 5,
                 min_faults: int = 3):
        self.psi_critical = psi_critical
        self.recovery_threshold = recovery_threshold
        self.fault_window = fault_window
        self.min_faults = min_faults
        
        self.isolated: Set[int] = set()
        self.fault_counter: Dict[int, int] = {}
        self.psi_history: Dict[int, deque] = {}
        
    def lyapunov_check(self, psi_states: List[float]) -> float:
        """
        Global Lyapunov Candidate:
        V_net(t) = Σ(Ψ_i - Ψ*)² + Σ coupling terms
        
        Returns True if system is stable (V_net decreasing)
        """
        # Simplified: check if any node is critically unstable
        return any(psi > self.psi_critical for psi in psi_states)
    
    def check_node(self, node_id: int, psi: float) -> bool:
        """Check if node should be isolated"""
        if node_id not in self.psi_history:
            self.psi_history[node_id] = deque(maxlen=self.fault_window)
        
        self.psi_history[node_id].append(psi)
        
        # Count consecutive faults
        recent = list(self.psi_history[node_id])
        faults = sum(1 for p in recent if p > self.psi_critical)
        
        if faults >= self.min_faults:
            self.isolate(node_id)
            return True
        return False
    
    def isolate(self, node_id: int):
        """Isolate node to prevent entropy infection"""
        self.isolated.add(node_id)
        self.fault_counter[node_id] = self.fault_counter.get(node_id, 0) + 1
    
    def recover(self, node_id: int, psi: float):
        """Recover node if entropy returns to safe level"""
        if node_id in self.isolated and psi < self.recovery_threshold:
            self.isolated.discard(node_id)
    
    def is_isolated(self, node_id: int) -> bool:
        return node_id in self.isolated
    
    def get_active_count(self, total_nodes: int) -> int:
        return total_nodes - len(self.isolated)
