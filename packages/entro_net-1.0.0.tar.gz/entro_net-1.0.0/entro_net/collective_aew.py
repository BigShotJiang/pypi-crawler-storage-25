"""
Collective-AEW: Reinforcement Learning with Dynamic Beta Adaptation
Enhanced with reward/punishment mechanism
"""

from typing import List
from collections import deque


class CollectiveAEW:
    def __init__(self, eta: float = 0.01, target: float = 0.339,
                 beta: float = 0.3, beta_min: float = 0.1, beta_max: float = 2.0,
                 momentum: float = 0.9, w_min: float = 0.1, w_max: float = 0.8):
        """
        Enhanced Collective AEW with adaptive beta
        
        Parameters
        ----------
        beta : float
            Initial cooperation coefficient
        beta_min, beta_max : float
            Bounds for beta adaptation
        """
        self.eta = eta
        self.target = target
        self.beta = beta
        self.beta_min = beta_min
        self.beta_max = beta_max
        self.momentum = momentum
        self.w_min = w_min
        self.w_max = w_max
        
        self.weights = [0.5, 0.3, 0.2]
        self.velocity = [0.0, 0.0, 0.0]
        self.last_local_grad = [0.0, 0.0, 0.0]
        
        # Beta adaptation
        self.beta_history = deque(maxlen=50)
        self.reward_history = deque(maxlen=30)
        self.beta_learning_rate = 0.02
        
        # Performance tracking
        self.error_history = deque(maxlen=20)
        self.consecutive_improvements = 0
        
    def local_gradient(self, psi_norm: float, d_psi: float, d2_psi: float) -> List[float]:
        """Local gradient with adaptive scaling"""
        error = psi_norm - self.target
        self.error_history.append(abs(error))
        
        # Adaptive scaling based on recent performance
        if len(self.error_history) > 5:
            avg_error = sum(self.error_history) / len(self.error_history)
            scale = 1.0 + min(2.0, avg_error)
        else:
            scale = 1.0
        
        return [
            scale * 2.0 * error * (1.0 - psi_norm),
            scale * 2.0 * error * d_psi,
            scale * 2.0 * error * d2_psi
        ]
    
    def calculate_reward(self, network_errors: List[float]) -> float:
        """Calculate reward/punishment signal"""
        if not network_errors:
            return 0.0
        
        current_error = abs(sum(network_errors) / len(network_errors))
        
        if len(self.error_history) > 1:
            prev_error = self.error_history[-2]
            improvement = prev_error - current_error
            reward = improvement * 10.0  # Scale reward
        else:
            reward = -current_error
        
        # Track consecutive improvements
        if reward > 0:
            self.consecutive_improvements += 1
        else:
            self.consecutive_improvements = 0
        
        self.reward_history.append(reward)
        return reward
    
    def update_beta(self, reward: float):
        """Dynamically adjust cooperation coefficient based on reward"""
        # Positive reward -> decrease beta (trust own learning)
        # Negative reward -> increase beta (need more cooperation)
        
        if reward > 0.05:
            # Good performance: reduce cooperation
            beta_change = -self.beta_learning_rate * reward
        elif reward < -0.05:
            # Poor performance: increase cooperation
            beta_change = -self.beta_learning_rate * reward  # reward is negative
        else:
            # Stable: small adjustment toward neutral
            beta_change = self.beta_learning_rate * (0.5 - self.beta) * 0.1
        
        self.beta += beta_change
        
        # Clamp beta
        self.beta = max(self.beta_min, min(self.beta_max, self.beta))
        self.beta_history.append(self.beta)
    
    def network_gradient(self, network_errors: List[float]) -> List[float]:
        """Network gradient with adaptive beta"""
        if not network_errors:
            return [0.0, 0.0, 0.0]
        
        # Calculate reward
        reward = self.calculate_reward(network_errors)
        
        # Update beta based on reward
        self.update_beta(reward)
        
        # Calculate network error trend
        avg_error = sum(network_errors) / len(network_errors)
        
        if len(self.error_history) > 5:
            recent = list(self.error_history)[-5:]
            trend = (recent[-1] - recent[0]) / 5
        else:
            trend = avg_error
        
        # Cooperation boost for consecutive failures
        if self.consecutive_improvements < -3:
            cooperation_boost = 1.5
        else:
            cooperation_boost = 1.0
        
        adaptive_beta = self.beta * cooperation_boost
        
        return [adaptive_beta * trend, adaptive_beta * trend, adaptive_beta * trend]
    
    def step(self, psi_norm: float, d_psi: float, d2_psi: float,
             network_errors: List[float] = None) -> List[float]:
        """
        Collective AEW Update with adaptive beta and momentum
        """
        # Local gradient
        local_grad = self.local_gradient(psi_norm, d_psi, d2_psi)
        self.last_local_grad = local_grad
        
        # Network gradient
        if network_errors:
            net_grad = self.network_gradient(network_errors)
        else:
            net_grad = [0.0, 0.0, 0.0]
        
        # Collective gradient
        collective_grad = [
            local_grad[0] + net_grad[0],
            local_grad[1] + net_grad[1],
            local_grad[2] + net_grad[2]
        ]
        
        # Momentum update
        for i in range(3):
            self.velocity[i] = self.momentum * self.velocity[i] - self.eta * collective_grad[i]
            self.weights[i] += self.velocity[i]
        
        # Clip weights
        self.weights = [max(self.w_min, min(self.w_max, w)) for w in self.weights]
        
        # L1 normalization
        total = sum(self.weights)
        if total > 0:
            self.weights = [w / total for w in self.weights]
        
        return self.weights.copy()
    
    def get_weights(self) -> List[float]:
        return self.weights.copy()
    
    def get_beta(self) -> float:
        return self.beta
    
    def get_reward(self) -> float:
        return self.reward_history[-1] if self.reward_history else 0.0
