#!/usr/bin/env python3
"""
Extended scaling test for ENTRO-NET: N = 20, 30, 50
Runs multiple repetitions to obtain average variance.
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import math
import random
import statistics
import time
from collections import defaultdict

from entro_net.psi_sync import PsiSync
from entro_net.collective_aew import CollectiveAEW
from entro_net.net_threshold import NetThreshold
from entro_net.fault_isolation import FaultIsolation

def run_single_simulation(n_nodes, steps=800, regime="scraper", kappa=1.0, beta=1.0, gamma=10.0, aggression=1.0, seed=None):
    """Run a single simulation and return final variance (average of last 100 steps)."""
    if seed is not None:
        random.seed(seed)
    
    sync = PsiSync(n_nodes=n_nodes, kappa=kappa, aggression=aggression)
    aew = CollectiveAEW(eta=0.01, target=0.339, beta=beta)
    threshold = NetThreshold(theta_base=1.4, gamma=gamma)
    isolation = FaultIsolation(psi_critical=0.8)
    
    # Pre-allocate per-node history for derivatives (optional, but we'll compute on fly)
    psi_hist = [[] for _ in range(n_nodes)]
    
    variances = []
    for step in range(steps):
        psi_states = []
        d_psi_states = []
        d2_psi_states = []
        for i in range(n_nodes):
            # Generate psi based on regime (scraper is high volatility)
            if regime == "scraper":
                psi = 0.3 + 0.4 * math.sin(step * 0.05) + 0.1 * random.random()
            elif regime == "phase_shift":
                if step < 250:
                    psi = 0.3 + 0.1 * random.random()
                else:
                    psi = 0.7 + 0.1 * random.random()
            else:  # mixed or default scraper
                psi = 0.3 + 0.4 * math.sin(step * 0.05) + 0.1 * random.random()
            
            psi_hist[i].append(psi)
            d_psi = 0.0
            d2_psi = 0.0
            if len(psi_hist[i]) > 1:
                d_psi = psi_hist[i][-1] - psi_hist[i][-2]
            if len(psi_hist[i]) > 2:
                d2_psi = d_psi - (psi_hist[i][-2] - psi_hist[i][-3])
            
            psi_states.append(psi)
            d_psi_states.append(d_psi)
            d2_psi_states.append(d2_psi)
        
        # Fault detection (optional, but keep)
        for i, p in enumerate(psi_states):
            isolation.check_node(i, p)
        
        # Sync and collective AEW
        synced = sync.broadcast(psi_states)
        network_errors = [p - 0.339 for p in synced]
        
        active = [i for i in range(n_nodes) if not isolation.is_isolated(i)]
        if active:
            avg_psi = sum(synced[i] for i in active) / len(active)
            avg_d = sum(d_psi_states[i] for i in active) / len(active)
            avg_d2 = sum(d2_psi_states[i] for i in active) / len(active)
            aew.step(avg_psi, avg_d, avg_d2, network_errors)
        
        # Compute variance across all nodes (synced)
        mean_psi = sum(synced) / n_nodes
        var = sum((p - mean_psi) ** 2 for p in synced) / n_nodes
        variances.append(var)
    
    # average over last 100 steps
    final_var = statistics.mean(variances[-100:])
    return final_var

def main():
    n_values = [20, 30, 50]
    repeats = 4  # number of runs per N
    steps = 800
    regime = "scraper"
    
    print("=" * 70)
    print("🔬 EXTENDED SCALING TEST (N = 20, 30, 50)")
    print(f"Regime: {regime}, Steps: {steps}, Repeats: {repeats}")
    print("=" * 70)
    
    results = {}
    for n in n_values:
        variances = []
        for r in range(repeats):
            seed = r * 101 + n
            var = run_single_simulation(n, steps=steps, regime=regime, seed=seed)
            variances.append(var)
            print(f"N={n:2d} run {r+1}: variance = {var:.6f}")
        mean_var = statistics.mean(variances)
        std_var = statistics.stdev(variances) if len(variances) > 1 else 0.0
        results[n] = (mean_var, std_var)
        print(f"N={n:2d} -> mean variance = {mean_var:.6f} ± {std_var:.6f}")
        print("-" * 50)
    
    print("\n" + "=" * 70)
    print("📊 SUMMARY")
    print("=" * 70)
    for n, (m, s) in results.items():
        print(f"N={n:3d} : variance = {m:.6f} ± {s:.6f}")
    
    # Compare with linear extrapolation from earlier model: variance = 0.0101*N - 0.0331
    print("\n📈 Comparison with linear extrapolation (σ² = 0.0101·N - 0.0331):")
    for n in n_values:
        linear_pred = 0.0101 * n - 0.0331
        actual = results[n][0]
        diff = actual - linear_pred
        print(f"N={n:3d} : predicted = {linear_pred:.4f}, actual = {actual:.4f}, diff = {diff:+.4f}")
    
    print("=" * 70)
    print("✅ Test completed.")
    print("Note: If actual variance deviates upward/downward significantly, scaling may not remain linear.")
    print("=" * 70)

if __name__ == "__main__":
    main()
