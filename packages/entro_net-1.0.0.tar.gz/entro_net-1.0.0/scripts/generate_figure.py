#!/usr/bin/env python3
"""
Generate Figure 1: Scaling Curve and Model Fits for ENTRO-NET
Outputs ASCII plot and data for external plotting tools
"""

import math

# Data from experiments
data = {
    2: 0.0003, 3: 0.0019, 4: 0.0062, 5: 0.0140,
    6: 0.0213, 7: 0.0313, 8: 0.0409, 9: 0.0527,
    10: 0.0686, 12: 0.0914, 15: 0.1272,
    20: 0.1654, 30: 0.1977, 50: 0.2215
}

# Linear fit (for N<=15)
def linear_pred(n):
    return 0.0101 * n - 0.0331

# Saturation model: σ² = σ²_max * (1 - e^(-N/N0))
sigma2_max = 0.228
N0 = 16.2

def saturation_pred(n):
    return sigma2_max * (1 - math.exp(-n / N0))

print("=" * 80)
print("FIGURE 1: Scaling Curve and Model Fits")
print("=" * 80)
print()
print("Variance")
print("   ↑")
print("0.25 │                                        ● (50)")
print("     │                                    ●●●")
print("0.20 │                                ●●●")
print("     │                            ●●●")
print("0.15 │                        ●●●")
print("     │                    ●●●")
print("0.10 │                ●●●")
print("     │            ●●●")
print("0.05 │        ●●●")
print("     │    ●●●")
print("0.00 │●●●")
print("     └────┴────┴────┴────┴────┴────┴────┴────┴────┴────┴──→ N")
print("     0    5   10   15   20   25   30   35   40   45   50")
print()
print("     ● data points (mean ± std)")
print("     ── linear fit (N≤15): σ² = 0.0101·N - 0.0331")
print("     ── saturation fit (full): σ² = 0.228·(1 - e^{-N/16.2})")
print("     ▒ crossover region (N≈15-25)")
print()
print("=" * 80)

# Generate data table for external plotting (gnuplot/matplotlib)
print("\n📊 DATA TABLE (for external plotting):")
print("-" * 50)
print(f"{'N':<6} {'Variance':<12} {'Linear(N≤15)':<15} {'Saturation':<12}")
print("-" * 50)
for n in sorted(data.keys()):
    v = data[n]
    l = linear_pred(n) if n <= 15 else linear_pred(15) + (n-15)*0.005
    s = saturation_pred(n)
    print(f"{n:<6} {v:<12.4f} {l:<15.4f} {s:<12.4f}")
print("-" * 50)

# Save to CSV for external tools
import csv
with open("results/scaling_data.csv", "w") as f:
    writer = csv.writer(f)
    writer.writerow(["N", "variance", "linear_pred", "saturation_pred"])
    for n in sorted(data.keys()):
        writer.writerow([n, data[n], linear_pred(n) if n<=15 else None, saturation_pred(n)])

print("\n✅ Data saved to: results/scaling_data.csv")
print("=" * 80)
