# 📋 Changelog

## [1.0.0] - 2026-04-08

### 🎉 Initial Release of ENTRO-NET (E-LAB-06)

#### ✨ Added
- **Ψ-Sync Protocol:** Real-time entropy state synchronization between nodes
- **Collective-AEW:** Collective adaptive entropy weighting algorithm
- **θ_net Threshold:** Dynamic network-wide activation threshold
- **Fault Isolation:** Node isolation system to prevent cascading failure
- **DistributedSimulator:** Multi-node distributed simulation engine (up to 10 nodes)

#### 🔧 Changed
- Migrated from ENTRO-EVO (E-LAB-05) to ENTRO-NET (E-LAB-06)
- Extended AEW interface to support collective learning

#### 🐛 Fixed
- None (initial release)

#### ⚠️ Known Issues
- Performance depends on network quality between nodes
- Recommended maximum: 10 nodes

---

### [0.1.0] - 2026-03-25 (Pre-release)

#### ✨ Added
- Prototype Ψ-Sync protocol
- Basic 3-node simulation tests

---

**📅 Dates:**
- v1.0.0: 2026-04-08
- v0.1.0: 2026-03-25

**📜 License:** MIT License
