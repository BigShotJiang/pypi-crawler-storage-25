# 👥 Authors

## Project: ENTRO-NET (E-LAB-06)
## Distributed Entropy Synchronization Protocols for Collective Neural Networks

---

### Lead Author

**Samir Baladi**
- Interdisciplinary AI & Theoretical Physics Researcher
- Ronin Institute / Rite of Renaissance
- 📧 gitdeeper@gmail.com
- 🆔 ORCID: 0009-0003-8903-0029

**Contributions:**
- Theoretical design of Ψ-Sync protocol
- Collective-AEW algorithm development
- Distributed network simulation architecture
- Research documentation and paper preparation

---

### Contributors

*Open for contributions from researchers*

| Name | Affiliation | Contribution | Dates |
|------|-------------|--------------|-------|
| *Available* | *Available* | *Available* | *Available* |

---

### Acknowledgments

- EntropyLab Research Program (E-LAB-01 through E-LAB-06)
- Open Science Community
- Anonymous peer reviewers

---

**📅 Last updated:** April 2026
**📜 License:** MIT License
