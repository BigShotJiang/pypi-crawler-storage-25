import subprocess
import sys
from pathlib import Path
from typing import List

from rich.console import Console

console = Console()

def run_local(cmd: List[str], dry_run: bool = False) -> None:
    if dry_run:
        console.print(f"[dim]DRY-RUN → {' '.join(cmd)}[/dim]")
        return
    try:
        subprocess.run(cmd, check=True, capture_output=True)
    except subprocess.CalledProcessError as e:
        console.print(f"[red]Локальная команда провалилась:[/red] {e}")
        sys.exit(1)


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)