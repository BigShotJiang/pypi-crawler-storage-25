import typer
from typing import Optional

from .core import GPUServer, get_plan
from .rich_console import header, plan_table, success, error
import secrets


app = typer.Typer(
    name="gpu-server-setup",
    help="Один клик — удалённый GPU-сервер с Ollama + VS Code Remote",
    rich_markup_mode="rich",
    add_completion=True,
)


@app.command()
def plan(
    ip: str = typer.Option(..., "--ip", help="IP-адрес сервера"),
    port: int = typer.Option(22, "--port", help="SSH порт (по умолчанию 22)"),
    user: str = typer.Option(..., "--user", help="Имя пользователя"),
    model: Optional[str] = typer.Option(None, "--model", help="Модель Ollama"),
    install_ollama: bool = typer.Option(True, "--install-ollama/--no-install"),
    no_vscode: bool = typer.Option(False, "--no-vscode"),
    pem_key: Optional[str] = typer.Option(
        None,
        "--pem-key",
        "--key-file",
        help="Путь к .pem-ключу от провайдера (вместо генерации своего ключа)",
    ),
):
    server = GPUServer(
        ip=ip,
        user=user,
        port=port,
        dry_run=True,
        external_key=pem_key,   
    )
    plan_list = get_plan(server, install_ollama, model, no_vscode)
    header(f"План для сервера {ip}")
    plan_table(plan_list)


@app.command()
def setup(
    ip: str = typer.Option(..., "--ip", help="IP-адрес сервера"),
    user: str = typer.Option(..., "--user", help="Имя пользователя"),
    port: int = typer.Option(22, "--port", help="SSH порт (по умолчанию 22)"),
    password: Optional[str] = typer.Option(
        None,
        "--password",
        hide_input=True,
        help="Пароль для sudo (если требуется, иначе можно не указывать)",
    ),
    model: Optional[str] = typer.Option(None, "--model", help="Модель Ollama (например llama3.2)"),
    install_ollama: bool = typer.Option(True, "--install-ollama/--no-install"),
    no_vscode: bool = typer.Option(False, "--no-vscode"),
    dry_run: bool = typer.Option(False, "--dry-run"),
    key_type: str = typer.Option("ed25519", "--key-type"),
    pem_key: Optional[str] = typer.Option(
        None,
        "--pem-key",
        "--key-file",
        help="Путь к .pem-ключу от провайдера (вместо генерации своего ключа)",
    ),
):
    if dry_run:
        plan(
            ip=ip,
            user=user,
            port=port,
            model=model,
            install_ollama=install_ollama,
            no_vscode=no_vscode,
            pem_key=pem_key,
        )
        return

    server = GPUServer(
        ip=ip,
        user=user,
        port=port,
        password=password,
        key_type=key_type,
        external_key=pem_key,
        dry_run=False,
    )

    server.generate_key()
    server.copy_pubkey()
    server.setup_ssh_config()
    server.test_connection()

    if install_ollama:
        server.install_ollama()

    if model:
        server.pull_model(model)

    if not no_vscode:
        server.open_vscode()

    success("Готово!")
    if model:
        typer.echo(f"\nЗапуск модели: [bold]ollama run {model}[/bold]")


@app.command()
def ssh(
    ip: str = typer.Option(..., "--ip", help="IP-адрес сервера"),
    user: str = typer.Option(..., "--user", help="Имя пользователя"),
    port: int = typer.Option(22, "--port", help="SSH порт (по умолчанию 22)"),
    password: Optional[str] = typer.Option(
        None,
        "--password",
        hide_input=True,
        help="Пароль для sudo (если требуется)",
    ),
    dry_run: bool = typer.Option(False, "--dry-run"),
    key_type: str = typer.Option("ed25519", "--key-type"),
    pem_key: Optional[str] = typer.Option(
        None,
        "--pem-key",
        "--key-file",
        help="Путь к .pem-ключу от провайдера",
    ),
):
    server = GPUServer(
        ip=ip,
        port=port,
        user=user,
        password=password,
        key_type=key_type,
        external_key=pem_key,
        dry_run=dry_run,
    )
    server.generate_key()
    server.copy_pubkey()
    server.setup_ssh_config()
    server.test_connection()
    success("SSH полностью настроен!")


@app.command("ollama-install")
def ollama_install(
    ip: str = typer.Option(..., "--ip"),
    port: int = typer.Option(22, "--port", help="SSH порт (по умолчанию 22)"),
    user: str = typer.Option(..., "--user"),
    password: Optional[str] = typer.Option(
        None,
        "--password",
        hide_input=True,
        help="Пароль для sudo (если требуется)",
    ),
    dry_run: bool = typer.Option(False, "--dry-run"),
    pem_key: Optional[str] = typer.Option(
        None,
        "--pem-key",
        "--key-file",
        help="Путь к .pem-ключу от провайдера",
    ),
):
    server = GPUServer(
        ip=ip,
        user=user,
        port=port,
        password=password,
        external_key=pem_key,
        dry_run=dry_run,
    )
    server.install_ollama()


@app.command("model-pull")
def model_pull(
    model: str = typer.Argument(..., help="Название модели (llama3.2, gemma2 и т.д.)"),
    ip: str = typer.Option(..., "--ip"),
    port: int = typer.Option(22, "--port", help="SSH порт (по умолчанию 22)"),
    user: str = typer.Option(..., "--user"),
    password: Optional[str] = typer.Option(None, "--password", hide_input=True),
    dry_run: bool = typer.Option(False, "--dry-run"),
    pem_key: Optional[str] = typer.Option(
        None,
        "--pem-key",
        "--key-file",
        help="Путь к .pem-ключу от провайдера",
    ),
):
    server = GPUServer(
        ip=ip,
        user=user,
        port=port,
        password=password,
        external_key=pem_key,
        dry_run=dry_run,
    )
    server.pull_model(model)


@app.command()
def vscode(
    ip: str = typer.Option(..., "--ip"),
    port: int = typer.Option(22, "--port", help="SSH порт (по умолчанию 22)"),
    user: str = typer.Option(..., "--user"),
    password: Optional[str] = typer.Option(None, "--password", hide_input=True),
    dry_run: bool = typer.Option(False, "--dry-run"),
    pem_key: Optional[str] = typer.Option(
        None,
        "--pem-key",
        "--key-file",
        help="Путь к .pem-ключу от провайдера",
    ),
):
    server = GPUServer(
        ip=ip,
        user=user,
        port=port,
        password=password,
        external_key=pem_key,
        dry_run=dry_run,
    )
    server.open_vscode()

@app.command()
def colab(
    ip: str = typer.Option(..., "--ip"),
    user: str = typer.Option(..., "--user"),
    password: Optional[str] = typer.Option(None, "--password", hide_input=True),
    port: int = typer.Option(8889, "--port"),
    token: Optional[str] = typer.Option(None, "--token"),
    dry_run: bool = typer.Option(False, "--dry-run"),
    pem_key: Optional[str] = typer.Option(None, "--pem-key", "--key-file"),
):
    token = token or secrets.token_hex(16)
    
    server = GPUServer(
        ip=ip,
        user=user,
        password=password,
        external_key=pem_key,
        dry_run=dry_run,
    )
    server.generate_key()
    server.copy_pubkey()
    server.setup_ssh_config()
    server.test_connection()
    
    port = server.setup_colab(port=port, token=token)

    success("Colab runtime готов!")
    typer.echo(f"\nToken: [bold]{token}[/bold]")
    typer.echo(f"Local URL: http://localhost:{port}/?token={token}")


if __name__ == "__main__":
    app()