from pathlib import Path
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_prefix="GPU_SETUP_",
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    default_key_type: str = "ed25519"
    config_dir: Path = Path.home() / ".config" / "gpu-setup"


settings = Settings()