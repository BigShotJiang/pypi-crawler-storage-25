from pathlib import Path
import sys
from typing import Optional

import paramiko
from paramiko import SSHClient, AutoAddPolicy, SSHException

from .utils import run_local, console
from .rich_console import header, success, error, warning
from .config import settings

import subprocess
import shutil
import time


class GPUServer:
    def __init__(
        self,
        ip: str,
        user: str,
        port: int = 22,
        password: Optional[str] = None,
        key_type: str = "ed25519",
        external_key: Optional[str] = None,
        dry_run: bool = False,
    ):
        self.ip = ip
        self.user = user
        self.port = port
        self.password = password
        self.dry_run = dry_run
        self.key_type = key_type
        self.external_key = Path(external_key).expanduser().resolve() if external_key else None
        self.use_external_key = self.external_key is not None

        self.alias = f"gpu-server-{ip.replace('.', '-')}"
        self.config_file = Path.home() / ".ssh/config"

        if self.use_external_key:
            self.key_path = self.external_key
            self.pub_path = None  
        else:
            self.key_path = Path.home() / f".ssh/id_{key_type}_gpu"
            self.pub_path = self.key_path.with_suffix(".pub")

    def _connect(self, use_password: bool = False) -> SSHClient:
        client = SSHClient()
        client.set_missing_host_key_policy(AutoAddPolicy())

        connect_kwargs = {
            "hostname": self.ip,
            "port": self.port,
            "username": self.user,
            "timeout": 15,
            "look_for_keys": False,
            "allow_agent": False,
        }

        if self.use_external_key:
            connect_kwargs["key_filename"] = str(self.key_path)
        elif use_password and self.password:
            connect_kwargs["password"] = self.password
        else:
            connect_kwargs["key_filename"] = str(self.key_path)

        client.connect(**connect_kwargs)
        return client
    
    def _sudo_stream(self, client: SSHClient, cmd: str):
        stdin, stdout, stderr = client.exec_command(
            f"sudo -S {cmd}",
            get_pty=True,
        )

        if self.password:
            stdin.write(self.password + "\n")
            stdin.flush()

        channel = stdout.channel
        while not channel.exit_status_ready():
            if channel.recv_ready():
                print(channel.recv(1024).decode("utf-8", errors="replace"), end="", flush=True)
            if channel.recv_stderr_ready():
                print(channel.recv_stderr(1024).decode("utf-8", errors="replace"), end="", flush=True)

        stdout.read()
        stderr.read()

    def ensure_pem_permissions(self) -> None:
        """chmod 600 для .pem-ключа провайдера"""
        if self.use_external_key and not self.dry_run:
            header("Проверка прав на PEM-ключ")
            if not self.key_path.exists():
                error(f"Файл ключа не найден: {self.key_path}")
                sys.exit(1)
            self.key_path.chmod(0o600)
            success(f"Права 600 установлены на {self.key_path.name}")

    def generate_key(self) -> None:
        if self.use_external_key:
            self.ensure_pem_permissions()
            return

        header("Генерация SSH-ключа")
        if self.key_path.exists():
            success("SSH-ключ уже существует")
            return

        if self.dry_run:
            console.print("[dim]DRY-RUN: ssh-keygen[/dim]")
            return

        cmd = (
            ["ssh-keygen", "-t", self.key_type, "-f", str(self.key_path), "-N", "", "-q"]
            if self.key_type == "ed25519"
            else ["ssh-keygen", "-t", "rsa", "-b", "4096", "-f", str(self.key_path), "-N", "", "-q"]
        )
        run_local(cmd)
        success(f"Ключ {self.key_type} создан")

    def copy_pubkey(self) -> None:
        if self.use_external_key:
            return

        header("Копирование публичного ключа на сервер")
        if self.dry_run:
            console.print("[dim]DRY-RUN: копирование ключа через paramiko[/dim]")
            return

        if not self.password:
            error("Для первого подключения нужен пароль")
            sys.exit(1)

        try:
            client = self._connect(use_password=True)
            pubkey = self.pub_path.read_text().strip()
            cmd = (
                f"mkdir -p ~/.ssh && chmod 700 ~/.ssh && "
                f"echo '{pubkey}' >> ~/.ssh/authorized_keys && "
                f"chmod 600 ~/.ssh/authorized_keys"
            )

            _, stdout, stderr = client.exec_command(cmd)
            stdout.read()
            stderr.read()
            client.close()
            success("Публичный ключ добавлен")
        except SSHException as e:
            error(f"Не удалось скопировать ключ: {e}")
            sys.exit(1)

    def setup_ssh_config(self) -> None:
        header("Настройка ~/.ssh/config")
        if self.dry_run:
            console.print("[dim]DRY-RUN: запись алиаса[/dim]")
            return

        entry = f"""
        Host {self.alias}
            HostName {self.ip}
            User {self.user}
            IdentityFile {self.key_path}
            StrictHostKeyChecking no
        """

        self.config_file.parent.mkdir(exist_ok=True)
        self.config_file.touch(exist_ok=True)

        content = self.config_file.read_text()
        if f"Host {self.alias}" not in content:
            with open(self.config_file, "a", encoding="utf-8") as f:
                f.write(entry)
            success(f"Алиас {self.alias} добавлен")
        else:
            success("Алиас уже существует")

    def test_connection(self) -> None:
        header("Тест SSH-подключения по ключу")
        if self.dry_run:
            console.print("[dim]DRY-RUN: тест SSH[/dim]")
            return

        try:
            client = self._connect()
            client.exec_command("exit")
            client.close()
            success("SSH по ключу работает")
        except Exception as e:
            error(f"Тест SSH провалился: {e}")
            sys.exit(1)

    def install_ollama(self) -> None:
        header("Установка Ollama")
        if self.dry_run:
            console.print("[dim]DRY-RUN: установка Ollama[/dim]")
            return

        client = self._connect()
        _, stdout, _ = client.exec_command("command -v ollama")
        if stdout.read().decode().strip():
            success("Ollama уже установлен")
            client.close()
            return

        sudo_prefix = "sudo -S " if self.password else "sudo "
        sudo_client = self._connect()
        
        self._sudo_stream(
            sudo_client,
            "bash -c 'curl -fsSL https://ollama.com/install.sh | sh'"
        )

        console.print("[dim]Проверяем статус Ollama...[/dim]")

        stdin, stdout, _ = sudo_client.exec_command(
            "systemctl is-active ollama",
            get_pty=True,
        )

        status = stdout.read().decode().strip()

        if status != "active":
            warning("Ollama не запущен — пробуем стартануть")
            self._sudo_stream(sudo_client, "systemctl start ollama")
        else:
            success("Ollama уже запущен")

        sudo_client.close()
        success("Ollama установлен")

    def pull_model(self, model: str) -> None:
        header(f"Скачивание модели {model}")
        if self.dry_run:
            console.print(f"[dim]DRY-RUN: ollama pull {model}[/dim]")
            return

        client = self._connect()

        _, stdout, _ = client.exec_command("command -v ollama")
        if not stdout.read().decode().strip():
            error("Ollama не установлен. Добавь --install-ollama")
            sys.exit(1)

        def check_ollama_service():
            _, stdout, stderr = client.exec_command("ollama list")
            exit_code = stdout.channel.recv_exit_status()
            if exit_code != 0:
                err_output = stderr.read().decode()
                if "could not connect to ollama server" in err_output.lower():
                    return False, err_output
            return True, None

        service_ok, err_msg = check_ollama_service()
        if not service_ok:
            warning("Ollama сервис не отвечает. Пытаемся запустить...")

            sudo_prefix = "sudo -S " if self.password else "sudo "
            sudo_client = self._connect()

            console.print("[dim]Запуск через systemctl...[/dim]")
            start_cmd = f"{sudo_prefix}systemctl start ollama"

            stdin, stdout, stderr = sudo_client.exec_command(start_cmd, get_pty=True)
            if self.password:
                stdin.write(self.password + "\n")
                stdin.flush()

            stdout.read()
            stderr.read()
            sudo_client.close()

            console.print("[dim]Даём 5 секунд на запуск...[/dim]")
            time.sleep(5)

            service_ok, err_msg = check_ollama_service()
            if not service_ok:
                warning(f"systemctl не помог: {err_msg}")
                console.print("[dim]Пробуем запустить ollama serve в фоне...[/dim]")

                sudo_client2 = self._connect()
                start_cmd = f"nohup ollama serve > /tmp/ollama.log 2>&1 &"
                stdin, stdout, stderr = sudo_client2.exec_command(
                    f"{sudo_prefix}-u {self.user} bash -c '{start_cmd}'", get_pty=True
                )
                if self.password:
                    stdin.write(self.password + "\n")
                    stdin.flush()
                stdout.read()
                stderr.read()
                sudo_client2.close()

                console.print("[dim]Даём 10 секунд на запуск...[/dim]")
                time.sleep(10)

                service_ok, err_msg = check_ollama_service()
                if not service_ok:
                    error(f"Не удалось запустить сервис: {err_msg}")
                    sys.exit(1)
                else:
                    success("Сервис Ollama успешно запущен (через nohup)")
            else:
                success("Сервис Ollama успешно запущен (через systemctl)")

        _, stdout, _ = client.exec_command(f"ollama list | grep -q '{model}'")
        if stdout.channel.recv_exit_status() == 0:
            success(f"Модель {model} уже есть")
            client.close()
            return

        console.print(f"[bold blue]Скачиваем {model}...[/bold blue]")
        stdin, stdout, stderr = client.exec_command(f"ollama pull {model}", get_pty=True)
        channel = stdout.channel

        while not channel.exit_status_ready():
            if channel.recv_ready():
                print(channel.recv(1024).decode("utf-8", errors="replace"), end="", flush=True)
            if channel.recv_stderr_ready():
                print(channel.recv_stderr(1024).decode("utf-8", errors="replace"), end="", flush=True)

        print(stdout.read().decode(), end="")
        err_out = stderr.read().decode()
        if err_out:
            print(err_out, end="")
        client.close()
        success(f"Модель {model} готова")

    def open_vscode(self) -> None:
        header("Открываем VS Code Remote")
        if self.dry_run:
            console.print(f"[dim]DRY-RUN: code --remote ssh-remote+{self.alias}[/dim]")
            return

        if shutil.which("code"):
            subprocess.run(["code", "--remote", f"ssh-remote+{self.alias}"])
            success("VS Code Remote открыт")
        else:
            warning("Команда 'code' не найдена. Установи VS Code CLI")
            
    def setup_colab(self, port: int = 8889, token: str = "token123") -> int:
        header("Настройка Colab (жёсткий режим)")

        if self.dry_run:
            console.print("[dim]DRY-RUN: colab setup[/dim]")
            return port

        def run_ssh(cmd: str, sudo: bool = False, print_output: bool = False) -> tuple[str, str]:
            if sudo:
                if self.password:
                    remote_cmd = f"echo '{self.password}' | sudo -S {cmd}"
                else:
                    remote_cmd = f"sudo {cmd}"
            else:
                remote_cmd = cmd

            if self.dry_run:
                console.print(f"[dim]DRY-RUN: ssh {self.alias} '{remote_cmd}'[/dim]")
                return "", ""

            ssh_cmd = ["ssh", self.alias, remote_cmd]

            try:
                result = subprocess.run(
                    ssh_cmd,
                    capture_output=True,
                    text=True,
                )
                out = result.stdout
                err = result.stderr

                if print_output and (out or err):
                    if out:
                        console.print(out, end="")
                    if err:
                        console.print(err, end="", style="red")

                return out, err
            except Exception as e:
                error(f"SSH-ошибка: {e}")
                return "", str(e)

        header("Чистка окружения")
        run_ssh("pkill -f jupyter || true", print_output=False)
        run_ssh(f"fuser -k {port}/tcp || true", print_output=False)
        subprocess.run(
            ["pkill", "-f", f"{port}:localhost:{port}"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )

        header("Подготовка окружения")
        run_ssh("apt update", sudo=True)
        run_ssh("apt install -y python3-venv", sudo=True)

        run_ssh("test -d ~/venv || python3 -m venv ~/venv")

        pip_cmd = (
            "bash -lc 'source ~/venv/bin/activate && "
            "pip install --upgrade pip -q && "
            "pip install -q jupyterlab notebook jupyter_server torch torchvision torchaudio'"
        )
        run_ssh(pip_cmd, print_output=False)   

        header("Запуск Jupyter")
        jupyter_cmd = (
            f"setsid nohup ~/venv/bin/jupyter notebook "
            f"--no-browser "
            f"--ip=0.0.0.0 "
            f"--port={port} "
            f"--IdentityProvider.token={token} "
            f"> /tmp/jupyter.log 2>&1 < /dev/null &"
        )
        run_ssh(jupyter_cmd)

        header("Ожидание запуска Jupyter")

        def wait_for_port() -> bool:
            for _ in range(30):
                out, _ = run_ssh(
                    f"ss -tuln | grep -q '{port}' && echo yes || echo no"
                )
                if out.strip() == "yes":
                    return True
                time.sleep(1)
            return False

        if not wait_for_port():
            error("Jupyter не запустился. Лог ниже:")
            run_ssh("cat /tmp/jupyter.log || echo NO_LOG", print_output=True)
            run_ssh("ps aux | grep -E 'jupyter|python' | grep -v grep", print_output=True)
            sys.exit(1)

        success("Jupyter запущен")

        header("Создание SSH-туннеля")
        tunnel_cmd = [
            "ssh", "-N", "-L", f"{port}:localhost:{port}", self.alias
        ]
        subprocess.Popen(tunnel_cmd)

        success("Туннель поднят")
        return port
        

def get_plan(server: GPUServer, install_ollama: bool, model: Optional[str], no_vscode: bool) -> list:
    plan = [
        ("SSH config", f"алиас {server.alias}"),
        ("Тест подключения", "по ключу"),
    ]

    if server.use_external_key:
        plan.insert(0, ("PEM-ключ", f"используем {server.key_path.name}"))
    else:
        plan.insert(0, ("Генерация ключа", "ed25519 (если нет)"))
        plan.insert(1, ("Копирование ключа", "на сервер"))

    if install_ollama:
        plan.append(("Ollama", "установка"))
    if model:
        plan.append(("Модель", f"ollama pull {model}"))
    if not no_vscode:
        plan.append(("VS Code", "открытие Remote"))

    return plan