from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.progress import Progress, SpinnerColumn, TextColumn

console = Console()

def header(text: str) -> None:
    console.print(Panel(f"[bold green]{text}[/bold green]", expand=False))


def success(text: str) -> None:
    console.print(f"[bold green]{text}[/bold green]")


def warning(text: str) -> None:
    console.print(f"[bold yellow]{text}[/bold yellow]")


def error(text: str) -> None:
    console.print(f"[bold red]{text}[/bold red]")


def plan_table(plan: list[tuple[str, str]]) -> None:
    table = Table(title="План выполнения", show_header=True, header_style="bold magenta")
    table.add_column("Шаг", style="cyan")
    table.add_column("Описание", style="dim")
    for step, desc in plan:
        table.add_row(step, desc)
    console.print(table)


def live_ollama_output() -> None:
    with Progress(
        SpinnerColumn(),
        TextColumn("[bold blue]Скачиваем модель...[/bold blue]"),
        transient=True,
    ) as progress:
        progress.add_task("pull", total=None)