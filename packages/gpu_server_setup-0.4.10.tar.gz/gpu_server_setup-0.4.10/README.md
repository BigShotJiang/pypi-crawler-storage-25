```markdown
# Gpu-setup — один клик до удалённого GPU-сервера с Ollama и VS Code Remote

Автоматическая настройка SSH, установка [Ollama](https://ollama.com/), загрузка LLM-моделей и открытие VS Code Remote на удалённом GPU-сервере — всё одной командой.

---

## Возможности

- Генерация SSH-ключей (ed25519 / RSA) **или** использование готового `.pem`-ключа от провайдера
- Автоматическое копирование публичного ключа (если используется свой ключ)
- Настройка `~/.ssh/config` с удобным алиасом
- Установка Ollama и запуск сервиса
- Загрузка моделей с живым выводом прогресса
- Автоматическое открытие VS Code Remote
- Полноценный Colab-режим: Jupyter Notebook + SSH-туннель на локальный порт + venv с torch
- Режим `--dry-run` для просмотра плана
- Красивый вывод с помощью `rich`

---

## Поддержка ключей

Скрипт поддерживает **два способа** аутентификации:

### 1. Обычный режим (генерация своего ключа)
Используется по умолчанию. Скрипт сам генерирует ключ и копирует его на сервер.

### 2. Режим `.pem`-ключа (для большинства облачных провайдеров)
Когда у вас уже есть скачанный приватный ключ (например `keyname-ubuntu.pem`).

В этом случае:
- Генерация своего ключа пропускается
- Автоматически выполняется `chmod 600` на `.pem`-файл
- Публичный ключ на сервер **не копируется** (он уже добавлен провайдером)

---

## Предварительные требования

- Python 3.8+
- SSH-клиент и `ssh-keygen`
- (опционально) `code` CLI для VS Code Remote
- Для `.pem`-ключа: файл должен быть скачан и доступен на локальной машине

---

## Установка

```bash
pip install gpu-server-setup
```

После установки команда `gpu-server-setup` будет доступна в терминале.

---

## Использование

```bash
gpu-server-setup [команда] [опции]
```

### Доступные команды

| Команда           | Описание                                      |
|-------------------|-----------------------------------------------|
| `setup`           | Полная настройка (SSH + Ollama + модель + VS Code) |
| `ssh`             | Только настройка SSH-доступа                  |
| `ollama-install`  | Установка Ollama                              |
| `model-pull`      | Загрузка модели                               |
| `vscode`          | Открытие VS Code 
colab                               |
| `colab`          | upyter Notebook + локальный туннель 
Remote                       |
| `plan`            | Показать план действий                        |

---

## Подробное описание команд

### `gpu-setup setup` (основная команда)

**Опции:**

- `--ip` (обязательно)
- `--user` (обязательно)
- `--password` — пароль для sudo (если требуется)
- `--model` — модель для скачивания (например `llama3.2`)
- `--pem-key`, `--key-file` — путь к `.pem`-ключу от провайдера
- `--install-ollama` / `--no-install`
- `--no-vscode`
- `--dry-run`
- `--key-type` (ed25519 по умолчанию)

### `gpu-setup ssh`

Только настройка SSH по ключу.

**Опции:**
- `--ip`, `--user`
- `--password`
- `--pem-key`
- `--dry-run`
- `--key-type`

### `gpu-setup ollama-install`

Установка Ollama.

**Опции:**
- `--ip`, `--user`
- `--password` (если sudo требует пароль)
- `--pem-key`
- `--dry-run`

### `gpu-setup model-pull <MODEL>`

Скачивание модели.

**Пример:**
```bash
gpu-server-setup model-pull llama3.2 --ip 123.45.67.89 --user ubuntu --pem-key ~/key.pem
```

**Опции:**
- `--ip`, `--user`
- `--password`
- `--pem-key`
- `--dry-run`

### `gpu-setup plan`

Показывает план без выполнения.

---

## Примеры использования

### 1. Полная настройка со своим ключом (классический способ)

```bash
gpu-server-setup setup --ip 123.45.67.89 --user ubuntu --password "pass" --model llama3.2
```

### 2. Полная настройка с `.pem`-ключом (самый удобный для облака)

```bash
gpu-server-setup setup --ip 111.11.111.111 --user ubuntu --pem-key ~/Downloads/keyname-ubuntu.pem --model llama3.2
```

### 3. Только SSH с `.pem`-ключом

```bash
gpu-server-setup ssh --ip 111.11.111.111 --user ubuntu --pem-key ~/Downloads/keyname-ubuntu.pem
```

### 4. Установка Ollama с `.pem`-ключом

```bash
gpu-server-setup ollama-install --ip 111.11.111.111 --user ubuntu --pem-key ~/Downloads/keyname-ubuntu.pem
```

### 5. Скачивание модели (после настройки SSH)

```bash
gpu-server-setup model-pull gemma2:27b --ip 111.11.111.111 --user ubuntu --pem-key ~/Downloads/keyname-ubuntu.pem
```

### 6. Настройка colab

```bash
gpu-server-setup colab --ip 123.45.67.89 --user ubuntu  --pem-key ~/key.pem (или --password) --port 9999
```

### 7. Просмотр плана

```bash
gpu-server-setup plan --ip 111.11.111.111 --user ubuntu --pem-key ~/Downloads/keyname-ubuntu.pem --model llama3.2
```

---

## Dry-run

Все команды поддерживают `--dry-run`:

```bash
gpu-server-setup setup --ip IP --user user --pem-key key.pem --dry-run
```

---

## Устранение неполадок

- **Ошибка при подключении** — проверьте правильность пути к `.pem`-файлу и права (`chmod 600`).
- **Ollama не устанавливается** — передайте `--password`, если sudo требует пароль.
- **VS Code не открывается** — установите `code` CLI в PATH.
- **"Permission denied" для ключа** — убедитесь, что выполнено `chmod 600 путь_к_ключу.pem`.

---

## Лицензия

MIT License.