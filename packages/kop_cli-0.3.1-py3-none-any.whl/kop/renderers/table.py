from textual import on
from textual.app import ComposeResult
from textual.widgets import ListItem, ListView, Static
from textual.containers import Horizontal, Vertical
from textual.message import Message
from textual.reactive import reactive
from textual.color import Color
from kop.registry import ActionRegistry
from typing import Optional, Union



class BaseCol(Static):
    DEFAULT_CSS = """
        BaseCol {
            padding: 0 1 0 0;
            text-overflow: ellipsis;
        }
        """
    text = reactive("")

    def __init__(self, text: Union[str,list], width: int,  **kwargs) -> None:
        if isinstance(text, list):
            text = str(len(text))
        self.set_reactive(BaseCol.text, text)
        super().__init__(text, **kwargs)
        self.width = width

    def on_mount(self) -> None:
        self.styles.width = f"{self.width}fr"

    def watch_text(self, old_value: str, new_value: str) -> None:
        if isinstance(new_value, list):
            new_value = str(len(new_value))
        if old_value == new_value:
            return
        self.content = new_value


class BaseHeader(ListItem):
    DEFAULT_CSS = """
        Horizontal {
            width: 100%;
        }
    """

    def __init__(self, columns, **kwargs) -> None:
        super().__init__(**kwargs)
        self.columns = columns

    def compose(self) -> ComposeResult:
        with Horizontal():
            for col in self.columns:
                yield BaseCol(text=col.title, width=col.width)
        # yield DetailRule()


class BaseRow(ListItem):

    DEFAULT_CSS = """
        Horizontal {
            width: 100%;
            align-vertical: middle;
        }
        # BaseRow {
        #     height: 2;
        #     width: 1fr;
        #     border-bottom: solid $block-hover-background;
        # }
    """

    row_data = reactive(dict)
    
    def __init__(self, row_data, columns) -> None:
        super().__init__()
        # self.row_data = row_data
        self.set_reactive(BaseRow.row_data, row_data)
        self.columns = columns

    def compose(self) -> ComposeResult:
        with Horizontal():
            for col in self.columns:
                text = self.row_data.get(col.field)
                if col.renderer:
                    text = col.renderer(text)
                yield BaseCol(text=text, width=col.width)

    def watch_row_data(self, old_value: dict, new_value: dict) -> None:
        if old_value == new_value:
            return
        for col_widget, col in zip(
            self.query(BaseCol),
            self.columns
        ):
            if old_value.get(col.field) == new_value.get(col.field):
                continue
            text = new_value.get(col.field)
            if col.renderer:
                text = col.renderer(text)
            col_widget.text = text

    def update_row_data(self, row_data):
        self.row_data = row_data


class TableRenderer(Vertical):
    DEFAULT_CSS = """
        TableRenderer {
          width: 1fr;
          height: 1fr;
          & > BaseHeader {
              height: 1;
              overflow: hidden hidden;
              width: 1fr;
              content-align: center middle;
              text-style: bold;
              background: $surface;
          }
          BaseRow {
                height: 1;
                width: 1fr;
                content-align: left middle;
            }
            ResourcePanel {
                height: 3;
            }
        }
    """

    data = reactive(list)
    raw_data = reactive(list)
    # save Selected or Highlighted row object
    picked_row: Optional[BaseRow] = None

    # not allow TableRenderer focus, let focus to ListView
    # focus on the first item when TableRenderer is focused
    can_focus = False

    def __init__(self, 
                columns: list, 
                data: list, 
                raw_data: list, 
                actions: Optional[list] = None,
                **kwargs) -> None:
        
        super().__init__(**kwargs)
        self.columns = columns
        # self.data = data
        self.set_reactive(TableRenderer.data, data)
        self.row_map: dict[str, BaseRow] = {}
        # self.raw_data = raw_data # cache raw data
        self.set_reactive(TableRenderer.raw_data, raw_data)

        self.bindings = []
        
        if actions:
            self.actions_map: dict[str, dict] = {a.name: a for a in actions}

            self.bindings = [
                dict(
                    keys=a.key,
                    action=f"dispatch('{a.action}')",
                    description=a.tooltip
                )
                for a in actions
            ]

        if self.raw_data:
            self.raw_data_map: dict[str, dict] = {row.metadata.name: row for row in self.raw_data}
        
    def compose(self) -> ComposeResult:
        yield BaseHeader(self.columns)
        with ListView(id="list_view"):
            for row in self.data:
                base_row = BaseRow(row_data=row, columns=self.columns)
                self.row_map[row.name] = base_row
                yield base_row
    
    def on_mount(self) -> None:
        if not self.bindings:
            return
        for bind in self.bindings:
            self._bindings.bind(**bind)


    async def watch_data(self, old_value: list, new_value: list) -> None:
        list_view = self.query_one(ListView)
        new_value_map: dict[str, dict] = {row.name: row for row in new_value}
        old_names = set(self.row_map.keys())
        new_names = set(new_value_map.keys())
        shared_count = len(old_names & new_names)

        # Fast path for page switches: avoid many async pop/insert operations.
        # If most rows are different, clear once and rebuild once.
        if (
            old_names
            and new_names
            and len(new_names) >= 5
            and shared_count <= max(3, len(new_names) // 10)
        ):
            # try to restore the previous picked row after table rebuild
            previous_index = list_view.index
            previous_picked_name = (
                self.picked_row.row_data.name
                if self.picked_row and self.picked_row.row_data
                else None
            )

            await list_view.clear()
            self.row_map.clear()
            rows: list[BaseRow] = []
            row_index_map: dict[str, int] = {}
            for row_data in new_value:
                row = BaseRow(row_data=row_data, columns=self.columns)
                self.row_map[row_data.name] = row
                row_index_map[row_data.name] = len(rows)
                rows.append(row)
            if rows:
                await list_view.extend(rows)

            # try to restore the previous picked row after table rebuild, the priority of restored row is: 
            # 1. same name, 2. same index, 3. first row
            restored_index = None
            if previous_picked_name in row_index_map:
                restored_index = row_index_map[previous_picked_name]
            elif previous_index is not None and 0 <= previous_index < len(rows):
                restored_index = previous_index
            elif rows:
                restored_index = 0

            list_view.index = restored_index
            self.picked_row = (
                rows[restored_index] if restored_index is not None else None
            )
            return

        # remove a row if it is not in new_value
        for name in list(self.row_map):
            if name not in new_value_map:
                
                # if current delete row is picked(selected)
                row = self.row_map[name]
                row_index = list_view.children.index(row)

                if self.picked_row is row:
                    self.picked_row = None

                # await self.row_map[name].remove()
                await list_view.pop(row_index)
                del self.row_map[name]

                # update the ListView index if deleted row before current ListView index
                # if list_view.index > row_index:
                #     list_view.index -= 1
        
        # add new row if it is not in self.row_map
        # update row if it is in self.row_map
        list_view = self.query_one(ListView)
        for new_index, new_row_data in enumerate(new_value):
            name = new_row_data.name
            if name in self.row_map:
                row = self.row_map[name]
                row.update_row_data(new_row_data)
                # determine if the position of an existing row in the table has changed.
                current_index = list_view.children.index(row)
                if current_index != new_index:
                    await list_view.pop(current_index)
                    await list_view.insert(new_index, [row])
            else:
                row = BaseRow(new_row_data, self.columns)
                self.row_map[name] = row
                # new row is inserted into the table based on its list position.
                await list_view.insert(new_index, [row])
                # update the ListView index if new row inserted before current ListView index
                if not list_view.index:
                    # if user switch to namespace and namespace has no resource, then ListView index is None
                    # after namespace switch to another one and cantains resource, ListView index should be reset to 0
                    list_view.index = 0
                if list_view.index >= new_index:
                    list_view.index += 1


    
    def watch_raw_data(self, old_value: list, new_value: list) -> None:
        if old_value == new_value:
            return
        self.raw_data_map = {row.metadata.name: row for row in new_value}

    @on(ListView.Selected)
    def handle_selected(self, event: ListView.Selected):
        """
        get selected item raw data to post
        """
        item: BaseRow = event.item
        selected  = item.row_data.name
        self.post_message(self.RowSelectedEvent(raw_data=self.raw_data_map[selected]))

        # self._style_row(prev_row=self.picked_row, next_row=item)
        self.picked_row = item

    @on(ListView.Highlighted)
    def handle_highlighted(self, event: ListView.Highlighted):
        event.stop()
        item: BaseRow = event.item
        # self._style_row(prev_row=self.picked_row, next_row=item)
        self.picked_row = item
    
    def action_dispatch(self, action_name: str) -> None:
        """
        all bindings action are unified as dispatch, and dispatch distinguishes
          the specific action based on the action_name passed in by the binding.
        see: https://textual.textualize.io/guide/actions/#bindings
        """
        if not self.picked_row:
            return
        action = self.actions_map.get(action_name)
        ActionRegistry.dispatch(
            action,
            self.picked_row.row_data,
            self.app
        )


    class RowSelectedEvent(Message):
        def __init__(self, raw_data):
            super().__init__()
            self.raw_data = raw_data
