from dataclasses import dataclass, field, fields, asdict
from kubernetes.client.models import (
    V1Node,
    V1Pod, 
    V1Deployment, 
    V1DaemonSet, 
    V1StatefulSet, 
    V1Container, 
    V1ContainerStatus, 
    V1EnvVar, 
    V1Toleration, 
    V1Probe,
    V1ContainerPort,
    V1VolumeMount,
    V1ResourceRequirements,
    V1Condition,
    V1Job,
    V1CronJob,
    V1ConfigMap,
    V1Secret,
    V1Service,
    V1ServicePort,
    V1LoadBalancerStatus,
    V1Endpoints,
    V1Endpoint,
    V1EndpointSubset,
    V1EndpointSlice,
    DiscoveryV1EndpointPort,
    V1Ingress,
    V1IngressSpec,
    V1IngressBackend,
    V1IngressLoadBalancerStatus,
    V1IngressTLS,
    V1IngressClass,
    V1NetworkPolicy,
    V1NetworkPolicyIngressRule,
    V1NetworkPolicyEgressRule,
    V1LabelSelector,
    V1PersistentVolume,
    V1PersistentVolumeClaim,
    V1StorageClass,
    V1Namespace,
    V1ServiceAccount,
    V1Role,
    V1ClusterRole,
    V1RoleBinding,
    V1ClusterRoleBinding,
    )
from datetime import datetime
from typing import List, Any, Callable, Optional, Union
from kop.renderers import fields as f




@dataclass
class ColumnModel:
    """    
    title: the title of the column to show
    width: the width of the column
    field: the field name in the model
    """
    title: str
    width: Optional[int]
    field: str
    renderer: Optional[Callable] = None


@dataclass
class ActionModel:
    """
    name: 
    label: 
    variant:
    tooltip:
    action: the field define the action to be performed, it's value will be the same as the handler class attribute.
    icon: the icon text to be displayed
    """
    name: str
    label: str
    variant: str
    tooltip: str
    action: str
    icon: Optional[str] = None

    key: Optional[str] = None # "ctrl+l"


@dataclass
class ViewModel:

    @classmethod
    def get_columns(cls) -> List[ColumnModel]:
        """
        Retrieve the table header from the model to be used as the table in the ResourceView screen.
        """
        columns: List[ColumnModel] = []
        for item in fields(cls):
            # if some field is not to be displayed in ResourceView screen, set column=False in metadata
            # all filed is displayed by default
            if item.name.startswith("_") or item.metadata.get("column", True) is False:
                continue
            columns.append(ColumnModel(item.metadata["title"], 
                                       item.metadata.get("width", None), 
                                       item.name,
                                       item.metadata.get("renderer", None))
            )
        return columns

    @classmethod
    def get_detail_columns(cls) -> List[ColumnModel]:
        """
        Retrieve fields from the model to display in the DetailModalRenderer screen.
        """
        columns: dict[str, ColumnModel] = {}
        field_metadata: dict[str, Any] = {}
        for item in fields(cls):
            # if some field is not to be displayed in detail screen, set detail=False in metadata
            # all filed is displayed by default
            if item.name.startswith("_") or item.metadata.get("detail", True) is False:
                continue
            columns[item.name] = ColumnModel(item.metadata["title"], 
                                       item.metadata["width"] if item.metadata.get("width") else None, 
                                       item.name)
            field_metadata[item.name] = item.metadata
        return cls._resorted_columns(columns, field_metadata)
    
    @classmethod
    def _resorted_columns(cls, columns: dict[str, ColumnModel], fields: dict[str, Any]) -> List[ColumnModel]:
        """
        Sort all fields based on the 'after' and 'before' values in the field metadata.
        """
        names = fields.keys()
        unexplain_names: list[str] = [] # fields that no `after` or `before` keyword specified to be sorted
        graph = {name: set() for name in names}
        for field_name, metadata in fields.items():
            after, before = metadata.get("after", None), metadata.get("before", None)
            if after is not None and after in names:
                graph[after].add(field_name)
                continue
            if before is not None and before in names:
                graph[field_name].add(before)
                continue
            unexplain_names.append(field_name)

        def visit(n):
            if n in visited:
                return
            visited.add(n)
            result.append(n)
            for m in graph[n]:
                visit(m)

        visited: set[str] = set()
        result: list[str] = []

        for n in unexplain_names:
            visit(n)

        return [columns[name] for name in result]
    

    def get(self, key: str) -> str:
        return getattr(self, key, "")
    
    @staticmethod
    def get_age_text(start_time: datetime) -> str:
        now = datetime.now(tz=start_time.tzinfo)
        diff = int((now - start_time).total_seconds())

        units = [
            ("y", 31536000),
            ("M", 2592000),
            ("d", 86400),
            ("h", 3600),
            ("m", 60),
            ("s", 1),
        ]

        parts = []

        for suffix, seconds in units:
            value, diff = divmod(diff, seconds)
            if value > 0:
                parts.append(f"{value}{suffix}")

            if len(parts) >= 2:
                break

        return "".join(parts) if parts else "0s"


    @staticmethod
    def get_created_text(start_time: datetime) -> str:
        created = start_time.strftime("%Y-%m-%d %H:%M:%S")
        age = ViewModel.get_age_text(start_time)
        return f"{created} ({age})"
                                 
    @classmethod
    def clean(cls, data):
        raise NotImplementedError
    

@dataclass
class NodeViewModel(ViewModel):
    name: str = field(metadata={"title": "Name", "width": 15})
    internalip: str = field(metadata={"title": "InternalIP", "width": 10, "detail": False, "renderer": f.node_internalip_renderer})
    osimage: str = field(metadata={"title": "OS-Image", "width": 10, "detail": False})
    taints: list = field(metadata={"title": "Taints", "width": 5})
    roles: str = field(metadata={"title": "Roles", "width": 10, "renderer": f.node_roles_renderer})
    version: str = field(metadata={"title": "Version", "width": 10, "detail": False})
    age: str = field(metadata={"title": "Age", "width": 5, "detail": False})
    conditions: list = field(metadata={"title": "Conditions", "width": 5, "renderer": f.node_conditions_renderer})

    @classmethod
    def clean(cls, data: V1Node):
        return cls(
            name=data.metadata.name,
            internalip=data.status.addresses,
            osimage=data.status.node_info.os_image,
            taints=data.spec.taints or [],
            roles=data.metadata.labels,
            version=data.status.node_info.kubelet_version,
            age=cls.get_age_text(data.metadata.creation_timestamp),
            conditions=data.status.conditions,
        )


@dataclass
class NodeDetailModel(NodeViewModel):
    created: str = field(default_factory=str, metadata={"title": "Created", "after": "name"})
    labels: dict = field(default_factory=dict, metadata={"title": "Lables", "after": "created"})
    annotations: dict = field(default_factory=dict, metadata={"title": "Annotations"})
    finalizers: list = field(default_factory=list, metadata={"title": "Finalizers"})
    addresses: list = field(default_factory=list, metadata={"title": "Addresses"})
    capacity: dict = field(default_factory=dict, metadata={"title": "Capacity"})
    allocatable: dict = field(default_factory=dict, metadata={"title": "Allocatable"})
    daemonendpoints: dict = field(default_factory=dict, metadata={"title": "Daemon Endpoints"})
    nodeinfo: dict = field(default_factory=dict, metadata={"title": "Node Info"})
    podcidr: str = field(default_factory=str, metadata={"title": "Pod CIDR"})
    podcidrs: list = field(default_factory=list, metadata={"title": "Pod CIDRs"})

    @classmethod
    def clean(cls, data: V1Node) -> "NodeDetailModel":
        base = super().clean(data).__dict__
        base.update({
            "created": cls.get_created_text(data.metadata.creation_timestamp),
            "labels": data.metadata.labels,
            "annotations": data.metadata.annotations,
            "finalizers": data.metadata.finalizers,
            "addresses": data.status.addresses,
            "capacity": data.status.capacity,
            "allocatable": data.status.allocatable,
            "daemonendpoints": data.status.daemon_endpoints,
            "nodeinfo": data.status.node_info,
            "podcidr": data.spec.pod_cidr,
            "podcidrs": data.spec.pod_cid_rs
        })
        return cls(**base)


@dataclass
class ContainerEnvironmentModel(ViewModel):
    name: Optional[str] = field(default=None, metadata={"title": "Name"})
    value: Optional[str] = field(default=None, metadata={"title": "Value"})

    _raw: Optional[V1EnvVar] = field(default=None, repr=False)

    @classmethod
    def clean(cls, data):
        return cls(name=data.name, value=data.value)
    

    def lazy_clean(self):
        if not self._raw:
            raise ValueError("No raw container environment data to clean.")
        return self.__class__.clean(self._raw)


@dataclass
class ContainerStatusModel(ViewModel):
    name: Optional[str] = field(default=None, metadata={"title": "Name"})
    state: Optional[str] = field(default=None, metadata={"title": "State"})
    last_state: Optional[dict] = field(default=None, metadata={"title": "Last State"})

    _raw: Optional[V1ContainerStatus] = field(default=None, repr=False)

    @classmethod
    def clean(cls, data: V1ContainerStatus) -> "ContainerStatusModel":
        return cls(
            name=data.name,
            state=data.state,
            last_state=data.last_state
        )
    
    def lazy_clean(self):
        if not self._raw:
            raise ValueError("No raw container status data to clean.")
        return self.__class__.clean(self._raw)



@dataclass
class ContainerModel(ViewModel):
    name: Optional[str] = field(default="", metadata={"title": "Name"})
    image: str = field(default="", metadata={"title": "Image"})
    image_pull_policy: str = field(default="", metadata={"title": "Pull Policy"})
    environmnet: Union[List[V1EnvVar], str] = field(default="", metadata={"title": "Environment"})
    arguments: str = field(default="", metadata={"title": "Arguments"})
    command: str = field(default="", metadata={"title": "Command"})
    container_status: Optional[V1ContainerStatus] = field(default=None, metadata={"title": "Status", "after": "image"})
    ports: Optional[List[V1ContainerPort]] = field(default=None, metadata={"title": "Port"})
    volume_mounts: Optional[List[V1VolumeMount]] = field(default=None, metadata={"title": "Volume Mount"})
    resources: Optional[V1ResourceRequirements] = field(default=None, metadata={"title": "Resources"})
    probe: Optional[dict[str, Optional[V1Probe]]] = field(default=None, metadata={"title": "Probe"})


    # _raw is used to cache the raw container data
    _raw: Optional[Any] = field(default=None, repr=False)

    @classmethod
    def clean(cls, data: V1Container) -> "ContainerModel":
        return cls(
            name=data.name,
            image=data.image, # type: ignore
            image_pull_policy=data.image_pull_policy, # type: ignore
            environmnet=data.env, # type: ignore
            arguments=data.args, # type: ignore
            command=data.command, # type: ignore
            probe={
                "liveness": getattr(data, "liveness_probe", None),
                "readiness": getattr(data, "readiness_probe", None),
                "startup": getattr(data, "startup_probe", None),
            },
            ports=getattr(data, "ports", None),
            volume_mounts=getattr(data, "volume_mounts", None),
            resources=getattr(data, "resources", None),
        )
    
    def lazy_clean(self):
        if not self._raw:
            raise ValueError("No raw container data to clean.")
        cleaned = self.__class__.clean(self._raw)
        # Preserve associated runtime status injected during container/status join.
        cleaned.container_status = self.container_status
        return cleaned


@dataclass
class PodViewModel(ViewModel):
    name: str = field(metadata={"title": "Name", "width": 22})
    namespace: str = field(metadata={"title": "Namespace", "width": 10})
    created: str = field(metadata={"title": "Created", "width": 5, "column": False})
    node: str = field(metadata={"title": "Node", "width": 10})
    containers: Union[str, List[ContainerModel]] = field(metadata={"title": "Containers", "width": 9, "after": "affinities", "column": False})
    all_container_status: Optional[List[V1ContainerStatus]] = field(metadata={"title": "Containers", "width": 20, "detail": False, "renderer": f.container_status_renderer})
    restarts: str = field(metadata={"title": "Restarts", "width": 8})
    controlled_by: str = field(metadata={"title": "ControlledBy", "width": 9})
    qos: str = field(metadata={"title": "QoS", "width": 9})
    age: str = field(metadata={"title": "Age", "width": 5, "detail": False})
    status: str = field(metadata={"title": "Status", "width": 8, "renderer": f.pod_status_renderer})

    @classmethod
    def clean(cls, data: V1Pod) -> "PodViewModel":
        """
        Clean a V1Pod object into a PodViewModel object
        """
        return cls(
            name=data.metadata.name, # type: ignore
            namespace=data.metadata.namespace, # type: ignore
            node=data.spec.node_name or "", # type: ignore
            status=cls.get_pod_status(data), # type: ignore
            containers=cls._make_containers(data.spec.containers or [], data.status.container_statuses if data.status else []), # type: ignore
            all_container_status=data.status,
            restarts=str(sum(cs.restart_count for cs in data.status.container_statuses)) if data.status.container_statuses else "", # type: ignore
            controlled_by=data.metadata.owner_references[0].kind if data.metadata.owner_references else "", # type: ignore
            qos=data.status.qos_class, # type: ignore
            age=cls.get_age_text(data.status.start_time) if data.status.start_time else "", # type: ignore
            created=cls.get_created_text(data.metadata.creation_timestamp), # type: ignore
        )
    
    @staticmethod
    def get_pod_status(pod: V1Pod) -> str:
        metadata = pod.metadata
        status = pod.status

        if metadata and metadata.deletion_timestamp:
            return "Terminating"

        # phase=Failed + reason=Evicted
        if status and status.phase == "Failed" and status.reason == "Evicted":
            return "Evicted"

        # default get pod phase
        if status and status.phase:
            return status.phase

        return "Unknown"
    
    @staticmethod
    def _make_containers(containers: List[Any], status: Optional[List[V1ContainerStatus]]) -> List[ContainerModel]:
        status_index = {st.name: st for st in status} if status else {}
        result = []
        for cs in containers:
            container_status = status_index.get(cs.name)
            result.append(
                ContainerModel(
                    _raw=cs,
                    container_status=container_status if container_status else None,
                )
            )
        return result

@dataclass
class PodDetailModel(PodViewModel):
    labels: dict = field(default_factory=dict, metadata={"title": "Labels", "after": "created"})
    annotations: list = field(default_factory=list, metadata={"title": "Annotations"})
    pod_ip: str = field(default="", metadata={"title": "Pod IP"})
    service_account: str = field(default="", metadata={"title": "Service Account"})
    priority: str = field(default="", metadata={"title": "Priority Class"})
    conditions: list[V1Condition] = field(default_factory=list, metadata={"title": "Conditions"})
    node_selector: list = field(default_factory=list, metadata={"title": "Node Selector"})
    tolerations: list[V1Toleration] = field(default_factory=list, metadata={"title": "Tolerations"})
    affinities: str = field(default="", metadata={"title": "Affinities"})
    init_containers: list[ContainerModel] = field(default_factory=list, metadata={"title": "Init Containers"})
    ephemeral_containers: list[ContainerModel] = field(default_factory=list, metadata={"title": "Ephemeral Containers"})

    _raw: Optional[V1Pod] = field(default=None, repr=False)

    @classmethod
    def clean(cls, data: V1Pod) -> "PodDetailModel":
        base = super().clean(data).__dict__
        base.update({
            'labels': data.metadata.labels,
            'annotations': data.metadata.annotations,
            'pod_ip': data.status.pod_ip,
            'service_account': data.spec.service_account_name,
            'priority': data.spec.priority_class_name,
            'conditions': data.status.conditions,
            'node_selector': data.spec.node_selector,
            'tolerations': [item for item in data.spec.tolerations],
            'affinities': data.spec.affinity,
            # 'containers': cls.make_containers(data),
            'init_containers': cls._make_containers(data.spec.init_containers, data.status.init_container_statuses) if data.spec.init_containers else [],
            'ephemeral_containers': cls._make_containers(data.spec.ephemeral_containers, data.status.ephemeral_container_statuses) if data.spec.ephemeral_containers else [],
        })
        base["_raw"] = data
        return cls(**base)
    


@dataclass
class DeploymentViewModel(ViewModel):
    name: str = field(metadata={"title": "Name", "width": 20})
    namespace: str = field(metadata={"title": "Namespace", "width": 10})
    created: str = field(metadata={"title": "Created", "width": 5, "column": False})
    pods: str = field(metadata={"title": "Pods", "width": 10})
    replicas: str = field(metadata={"title": "Replicas", "width": 10})
    age: str = field(metadata={"title": "Age", "width": 5, "detail": False})
    created: str = field(metadata={"title": "Created", "width": 5, "column": False})
    conditions: list[V1Condition] = field(
        default_factory=list,
        metadata={"title": "Conditions", "width": 20, "renderer": f.deployment_conditions_renderer},
    )

    @classmethod
    def clean(cls, data: V1Deployment) -> "DeploymentViewModel":
        return cls(
            name=data.metadata.name,
            namespace=data.metadata.namespace,
            pods="/".join([str(data.status.ready_replicas or 0), str(data.status.replicas or 0)]),
            replicas=str(data.spec.replicas),
            age=cls.get_age_text(data.metadata.creation_timestamp),
            created=f"{cls.get_created_text(data.metadata.creation_timestamp)}",
            conditions=sorted(data.status.conditions, key=lambda x: x.type) or []
        )


@dataclass
class DeploymentDetailModel(DeploymentViewModel):
    labels: dict = field(default_factory=dict, metadata={"title": "Labels", "after": "created"})
    annotations: dict = field(default_factory=dict, metadata={"title": "Annotations"})
    status_replicas: dict = field(default_factory=dict, metadata={"title": "Status Replicas"})
    selector: dict = field(default_factory=dict, metadata={"title": "Selector"})
    node_selector: list = field(default_factory=list, metadata={"title": "Node Selector"})
    strategy: dict = field(default_factory=dict, metadata={"title": "Strategy"})
    tolerations: list[V1Toleration] = field(default_factory=list, metadata={"title": "Tolerations"})

    @classmethod
    def clean(cls, data: V1Deployment) -> "DeploymentDetailModel":
        base = super().clean(data).__dict__
        base.update({
            'annotations': data.metadata.annotations,
            'labels': data.metadata.labels,
            'status_replicas': cls.get_status_replicas(data.status),
            'selector': data.spec.selector,
            'strategy': data.spec.strategy,
            'tolerations': data.spec.template.spec.tolerations
        })
        return cls(**base)
    
    @classmethod
    def get_status_replicas(cls, status) -> dict:
        return dict(
            available_replicas=status.available_replicas,
            ready_replicas=status.ready_replicas,
            terminating_replicas=status.terminating_replicas,
            unavailable_replicas=status.unavailable_replicas,
            updated_replicas=status.updated_replicas
        )


@dataclass
class DaemonSetViewModel(ViewModel):
    name: str = field(metadata={"title": "Name", "width": 20})
    namespace: str = field(metadata={"title": "Namespace", "width": 20})
    pods: str = field(metadata={"title": "Pods", "width": 10, "after": "annotations"})
    node_selector: str = field(metadata={"title": "NodeSelector", "width": 30})
    age: str = field(metadata={"title": "Age", "width": 10, "detail": False})
    
    @classmethod
    def clean(cls, data: V1DaemonSet) -> "DaemonSetViewModel":
        return cls(
            name=data.metadata.name,
            namespace=data.metadata.namespace,
            pods="/".join([str(data.status.current_number_scheduled), str(data.status.desired_number_scheduled)]),
            node_selector="".join(f"{k}={v}" for k, v in data.spec.template.spec.node_selector.items()) if data.spec.template.spec.node_selector else "",
            age=cls.get_age_text(data.metadata.creation_timestamp),
        )


@dataclass
class DaemonSetDetailModel(DaemonSetViewModel):
    created: str = field(default_factory=str, metadata={"title": "Created", "after": "namespace"})
    labels: dict = field(default_factory=dict, metadata={"title": "Lables"}) 
    annotations: dict = field(default_factory=dict, metadata={"title": "Annotations"})
    selector: dict = field(default_factory=dict, metadata={"title": "Selector"})
    strategy: dict = field(default_factory=dict, metadata={"title": "Strategy"})
    tolerations: list[V1Toleration] = field(default_factory=list, metadata={"title": "Tolerations"})

    @classmethod
    def clean(cls, data: V1DaemonSet) -> "DaemonSetDetailModel":
        base = super().clean(data).__dict__
        base.update({
            'labels': data.metadata.labels,
            'annotations': data.metadata.annotations,
            'selector': data.spec.selector,
            'strategy': data.spec.update_strategy,
            'created': cls.get_created_text(data.metadata.creation_timestamp),
            'tolerations': data.spec.template.spec.tolerations
        })
        return cls(**base)


@dataclass
class StatefulSetViewModel(ViewModel):
    name: str = field(metadata={"title": "Name", "width": 20})
    namespace: str = field(metadata={"title": "Namespace", "width": 10})
    pods: str = field(metadata={"title": "Pods", "width": 10, "after": "labels"})
    replicas: str = field(metadata={"title": "Replicas", "width": 10})
    age: str = field(metadata={"title": "Age", "width": 5})
    
    @classmethod
    def clean(cls, data: V1StatefulSet) -> "StatefulSetViewModel":
        return cls(
            name=data.metadata.name,
            namespace=data.metadata.namespace,
            pods="/".join([str(data.status.ready_replicas or 0), str(data.status.replicas)]),
            replicas=str(data.spec.replicas),
            age=cls.get_age_text(data.metadata.creation_timestamp),
        )


@dataclass
class StatefulSetDetailModel(StatefulSetViewModel):
    created: str = field(default_factory=str, metadata={"title": "Created", "after": "namespace"})
    labels: dict = field(default_factory=dict, metadata={"title": "Lables"}) 
    annotations: dict = field(default_factory=dict, metadata={"title": "Annotations"})
    selector: dict = field(default_factory=dict, metadata={"title": "Selector"})
    strategy: dict = field(default_factory=dict, metadata={"title": "Strategy"})

    @classmethod
    def clean(cls, data: V1StatefulSet) -> "StatefulSetDetailModel":
        base = super().clean(data).__dict__
        base.update({
            'labels': data.metadata.labels,
            'annotations': data.metadata.annotations,
            'selector': data.spec.selector,
            'strategy': data.spec.update_strategy,
            'created': cls.get_created_text(data.metadata.creation_timestamp),
        })
        return cls(**base)
    

@dataclass
class JobViewModel(ViewModel):
    name: str = field(metadata={"title": "Name", "width": 20})
    namespace: str = field(metadata={"title": "Namespace", "width": 10})
    completions: str = field(metadata={"title": "Completions", "width": 10, "after": "labels"})
    age: str = field(metadata={"title": "Age", "width": 5, "detail": False})
    start_time: str = field(metadata={"title": "Start Time", "width": 20, "after": "labels"})
    completion_time: str = field(metadata={"title": "Completion Time", "width": 20, "after": "start_time"})

    @classmethod
    def clean(cls, data: V1Job) -> "JobViewModel":
        return cls(
            name=data.metadata.name,
            namespace=data.metadata.namespace,
            completions=str(data.status.succeeded),
            age=cls.get_age_text(data.metadata.creation_timestamp),
            start_time=str(data.status.start_time),
            completion_time=str(data.status.completion_time),
        )


@dataclass
class JobDetailModel(JobViewModel):
    created: str = field(default_factory=str, metadata={"title": "Created", "after": "namespace"})
    labels: dict = field(default_factory=dict, metadata={"title": "Lables"}) 
    annotations: dict = field(default_factory=dict, metadata={"title": "Annotations"})
    selector: dict = field(default_factory=dict, metadata={"title": "Selector"})
    conditions: list[V1Condition] = field(default_factory=list,metadata={"title": "Conditions"})
    parallelism: str = field(default_factory=str, metadata={"title": "Parallelism"})
    backofflimit: str = field(default_factory=str, metadata={"title": "BackoffLimit"})
    completionmode: str = field(default_factory=str, metadata={"title": "CompletionMode"})
    podfailurepolicy: str = field(default_factory=str, metadata={"title": "PodFailurePolicy"})

    @classmethod
    def clean(cls, data: V1Job) -> "JobDetailModel":
        base = super().clean(data).__dict__
        base.update({
            'labels': data.metadata.labels,
            'annotations': data.metadata.annotations,
            'selector': data.spec.selector,
            'conditions': data.status.conditions,
            'completions': str(data.spec.completions),
            'parallelism': str(data.spec.parallelism),
            'backofflimit': str(data.spec.backoff_limit),
            'completionmode': str(data.spec.completion_mode),
            'podfailurepolicy': data.spec.pod_failure_policy,
            'created': cls.get_created_text(data.metadata.creation_timestamp),
        })
        return cls(**base)


@dataclass
class CronJobViewModel(ViewModel):
    name: str = field(metadata={"title": "Name", "width": 20})
    namespace: str = field(metadata={"title": "Namespace", "width": 10})
    schedule: str = field(metadata={"title": "Schedule", "width": 10})
    suspend: str = field(metadata={"title": "Suspend", "width": 10})
    active: str = field(metadata={"title": "Active", "width": 10})
    lastschedule: str = field(metadata={"title": "Last Schedule", "width": 20})
    age: str = field(metadata={"title": "Age", "width": 5, "detail": False})

    @classmethod
    def clean(cls, data: V1CronJob) -> "CronJobViewModel":
        return cls(
            name=data.metadata.name,
            namespace=data.metadata.namespace,
            schedule=str(data.spec.schedule),
            suspend=str(data.spec.suspend),
            active=str(len(data.status.active)) if data.status.active else "0",
            lastschedule=str(data.status.last_schedule_time),
            age=cls.get_age_text(data.metadata.creation_timestamp),
        )
    

@dataclass
class CronJobDetailModel(CronJobViewModel):
    created: str = field(default_factory=str, metadata={"title": "Created", "after": "namespace"})
    concurrencypolicy: str = field(default_factory=str, metadata={"title": "Concurrency"})
    successfuljobshistorylimit: str = field(default_factory=str, metadata={"title": "SuccessLimit"})
    failedjobshistorylimit: str = field(default_factory=str, metadata={"title": "FailedLimit"})

    @classmethod
    def clean(cls, data: V1CronJob) -> "CronJobDetailModel":
        base = super().clean(data).__dict__
        base.update({
            'concurrencypolicy': str(data.spec.concurrency_policy),
            'successfuljobshistorylimit': str(data.spec.successful_jobs_history_limit),
            'failedjobshistorylimit': str(data.spec.failed_jobs_history_limit),
            'created': cls.get_created_text(data.metadata.creation_timestamp),
        })
        return cls(**base)


@dataclass
class ConfigMapViewModel(ViewModel):
    name: str = field(metadata={"title": "Name", "width": 20})
    namespace: str = field(metadata={"title": "Namespace", "width": 10})
    keys: str = field(metadata={"title": "Keys", "width": 20, "detail": False})
    age: str = field(metadata={"title": "Age", "width": 5, "detail": False})

    @classmethod
    def clean(cls, data: V1ConfigMap) -> "ConfigMapViewModel":
        return cls(
            name=data.metadata.name,
            namespace=data.metadata.namespace,
            keys=','.join(data.data.keys() if data.data else []),
            age=cls.get_age_text(data.metadata.creation_timestamp),
        )
    

@dataclass
class ConfigMapDetailModel(ConfigMapViewModel):
    created: str = field(default_factory=str, metadata={"title": "Created", "after": "namespace"})
    labels: dict = field(default_factory=dict, metadata={"title": "Lables"})
    annotations: dict = field(default_factory=dict, metadata={"title": "Annotations"})
    data: dict = field(default_factory=dict, metadata={"title": "Data"})

    @classmethod
    def clean(cls, data: V1ConfigMap) -> "ConfigMapDetailModel":
        base = super().clean(data).__dict__
        base.update({
            'created': cls.get_created_text(data.metadata.creation_timestamp),
            'labels': data.metadata.labels,
            'annotations': data.metadata.annotations,
            'data': data.data
        })
        return cls(**base)
    

@dataclass
class SecretViewModel(ViewModel):
    name: str = field(metadata={"title": "Name", "width": 20})
    namespace: str = field(metadata={"title": "Namespace", "width": 10})
    keys: str = field(metadata={"title": "Keys", "width": 20, "detail": False})
    age: str = field(metadata={"title": "Age", "width": 5, "detail": False})

    @classmethod
    def clean(cls, data: V1Secret) -> "SecretViewModel":
        return cls(
            name=data.metadata.name,
            namespace=data.metadata.namespace,
            keys=','.join(data.data.keys() if data.data else []),
            age=cls.get_age_text(data.metadata.creation_timestamp),
        )
    

@dataclass
class SecretDetailModel(SecretViewModel):
    created: str = field(default_factory=str, metadata={"title": "Created", "after": "namespace"})
    labels: dict = field(default_factory=dict, metadata={"title": "Lables"})
    type: str = field(default_factory=str, metadata={"title": "Type"})
    data: dict = field(default_factory=dict, metadata={"title": "Data"})

    @classmethod
    def clean(cls, data: V1Secret) -> "SecretDetailModel":
        base = super().clean(data).__dict__
        base.update({
            'created': cls.get_created_text(data.metadata.creation_timestamp),
            'labels': data.metadata.labels,
            'type': data.type,
            'data': data.data
        })
        return cls(**base)
    

@dataclass
class ServiceViewModel(ViewModel):
    name: str = field(metadata={"title": "Name", "width": 15})
    namespace: str = field(metadata={"title": "Namespace", "width": 10})
    type: str = field(metadata={"title": "Type", "width": 10, "after": "labels"})
    clusterip: str = field(metadata={"title": "Cluster IP", "width": 10, "detail": False})
    externalip: str = field(metadata={"title": "External IP", "width": 10, "detail": False})
    ports: list[V1ServicePort] = field(metadata={"title": "Ports", "width": 15, "after": "selector", "renderer": f.service_ports_renderer})
    age: str = field(metadata={"title": "Age", "width": 5, "detail": False})

    @classmethod
    def clean(cls, data: V1Service) -> "ServiceViewModel":
        return cls(
            name=data.metadata.name,
            namespace=data.metadata.namespace,
            type=data.spec.type,
            clusterip=data.spec.cluster_ip if data.spec.cluster_ip else "",
            externalip=cls._get_externalip(data.status.load_balancer),
            ports=data.spec.ports,
            age=cls.get_age_text(data.metadata.creation_timestamp),
        )

    @staticmethod
    def _get_externalip(data: V1LoadBalancerStatus) -> str:
        if data.ingress:
            return ','.join([i.ip for i in data.ingress])
        return ""

@dataclass
class ServiceDetailModel(ServiceViewModel):
    created: str = field(default_factory=str, metadata={"title": "Created", "after": "namespace"})
    labels: dict = field(default_factory=dict, metadata={"title": "Lables"})
    annotations: dict = field(default_factory=dict, metadata={"title": "Annotations"})
    finalizers: list = field(default_factory=list, metadata={"title": "Finalizers"})
    selector: dict = field(default_factory=dict, metadata={"title": "Selector"})
    clusterips: list = field(default_factory=list, metadata={"title": "Cluster IPs"})
    externalips: list = field(default_factory=list, metadata={"title": "External IPs"})
    sessionaffinity: str = field(default_factory=str, metadata={"title": "Session Affinity"})

    @classmethod
    def clean(cls, data: V1Service) -> "ServiceDetailModel":
        base = super().clean(data).__dict__
        base.update({
            'created': cls.get_created_text(data.metadata.creation_timestamp),
            'labels': data.metadata.labels,
            'annotations': data.metadata.annotations,
            'finalizers': data.metadata.finalizers,
            'selector': data.spec.selector,
            'clusterips': data.spec.cluster_ip,
            'externalips': cls._get_externalip(data.status.load_balancer),
            'sessionaffinity': data.spec.session_affinity
        })
        return cls(**base)
    

@dataclass
class EndpointViewModel(ViewModel):
    name: str = field(metadata={"title": "Name", "width": 15})
    namespace: str = field(metadata={"title": "Namespace", "width": 10})
    endpoints: str = field(metadata={"title": "Endpoints", "width": 15, "detail": False})
    age: str = field(metadata={"title": "Age", "width": 5, "detail": False})

    @classmethod
    def clean(cls, data: V1Endpoints) -> "EndpointViewModel":
        return cls(
            name=data.metadata.name,
            namespace=data.metadata.namespace,
            endpoints=cls._get_endpoints(data.subsets),
            age=cls.get_age_text(data.metadata.creation_timestamp),
        )
    
    @staticmethod
    def _get_endpoints(data: list[V1EndpointSubset]) -> str:
        if not data:
            return ""
        endpoints = []
        for subset in data:
            ips = []
            ports = []
            if subset.addresses:
                ips.extend(i.ip for i in subset.addresses)
            if subset.ports:
                ports.extend(i.port for i in subset.ports)
            endpoints.append(f"{','.join(ips)}:{','.join(map(str, ports))}")
        return ",".join(endpoints)


@dataclass
class EndpointDetailModel(EndpointViewModel):
    created: str = field(default_factory=str, metadata={"title": "Created", "after": "namespace"})
    labels: dict = field(default_factory=dict, metadata={"title": "Lables"})
    subsets: list[V1EndpointSubset] = field(default_factory=list, metadata={"title": "Subsets"})

    @classmethod
    def clean(cls, data: V1Endpoints) -> "EndpointDetailModel":
        base = super().clean(data).__dict__
        base.update({
            'created': cls.get_created_text(data.metadata.creation_timestamp),
            'labels': data.metadata.labels,
            'subsets': data.subsets
        })
        return cls(**base)


@dataclass
class EndpointSliceViewModel(ViewModel):
    name: str = field(metadata={"title": "Name", "width": 15})
    namespace: str = field(metadata={"title": "Namespace", "width": 10})
    addresstype: str = field(metadata={"title": "Address Type", "width": 15, "after": "labels"})
    portslice: list[DiscoveryV1EndpointPort] = field(metadata={"title": "Ports", "width": 15, "after": "controlledby", "renderer": f.endpointslice_ports_renderer})
    endpointslice: list[V1Endpoint] = field(metadata={"title": "Endpoints", "width": 15, "after": "portslice"})
    age: str = field(metadata={"title": "Age", "width": 5, "detail": False})

    @classmethod
    def clean(cls, data: V1EndpointSlice) -> "EndpointSliceViewModel":
        return cls(
            name=data.metadata.name,
            namespace=data.metadata.namespace,
            addresstype=data.address_type,
            portslice=data.ports,
            endpointslice=data.endpoints,
            age=cls.get_age_text(data.metadata.creation_timestamp),
        )
    

@dataclass
class EndpointSliceDetailModel(EndpointSliceViewModel):
    created: str = field(default_factory=str, metadata={"title": "Created", "after": "namespace"})
    labels: dict = field(default_factory=dict, metadata={"title": "Lables"})
    annotations: dict = field(default_factory=dict, metadata={"title": "Annotations"})
    controlledby: str = field(default_factory=str, metadata={"title": "Controlled By"})

    @classmethod
    def clean(cls, data: V1EndpointSlice) -> "EndpointSliceDetailModel":
        base = super().clean(data).__dict__
        base.update({
            'created': cls.get_created_text(data.metadata.creation_timestamp),
            'labels': data.metadata.labels,
            'annotations': data.metadata.annotations,
            'controlledby': data.metadata.owner_references[0].kind if data.metadata.owner_references else "",
        })
        return cls(**base)


@dataclass
class IngressViewModel(ViewModel):
    name: str = field(metadata={"title": "Name", "width": 15})
    namespace: str = field(metadata={"title": "Namespace", "width": 10})
    ingressclass: str = field(metadata={"title": "Class", "width": 10, "after": "labels"})
    # determine a domain is HTTPS requires the TLS information in the spec.
    rules: V1IngressSpec = field(metadata={"title": "Rules", "width": 15, "after": "loadbalancers", "renderer": f.ingress_rules_renderer})
    age: str = field(metadata={"title": "Age", "width": 5, "detail": False})

    @classmethod
    def clean(cls, data: V1Ingress) -> "IngressViewModel":
        return cls(
            name=data.metadata.name,
            namespace=data.metadata.namespace,
            ingressclass=data.spec.ingress_class_name,
            rules=data.spec,
            age=cls.get_age_text(data.metadata.creation_timestamp),
        )
    

@dataclass
class IngressDetailModel(IngressViewModel):
    created: str = field(default_factory=str, metadata={"title": "Created", "after": "namespace"})
    labels: dict = field(default_factory=dict, metadata={"title": "Lables"})
    annotations: dict = field(default_factory=dict, metadata={"title": "Annotations"})
    tls: list[V1IngressTLS] = field(default_factory=list, metadata={"title": "TLS"})
    defaultbackend: str = field(default_factory=str, metadata={"title": "Default Backend"})
    loadbalancers: V1IngressLoadBalancerStatus = field(default_factory=V1IngressLoadBalancerStatus, metadata={"title": "Load Balancers"})

    @classmethod
    def clean(cls, data: V1Ingress) -> "IngressDetailModel":
        base = super().clean(data).__dict__
        base.update({
            'created': cls.get_created_text(data.metadata.creation_timestamp),
            'labels': data.metadata.labels,
            'annotations': data.metadata.annotations,
            'tls': cls._get_tls_secrets(data.spec.tls),
            'defaultbackend': cls._get_default_backend(data.spec.default_backend),
            'loadbalancers': data.status.load_balancer,
        })
        return cls(**base)

    @staticmethod
    def _get_default_backend(data: V1IngressBackend) -> str:
        if not data:
            return ""
        if data.resource:
            return data.resource.name
        if data.service:
            return data.service.name
        return ""
        
    
    @staticmethod
    def _get_tls_secrets(data: list[V1IngressTLS]) -> str:
        if not data:
            return ""
        secret_names = []
        for tls in data:
            secret_names.append(tls.secret_name)
        return ",".join(secret_names)
    

@dataclass
class IngressClassViewModel(ViewModel):
    name: str = field(metadata={"title": "Name", "width": 15})
    namespace: str = field(metadata={"title": "Namespace", "width": 10})
    default: str = field(metadata={"title": "Default", "width": 5, "after": "labels"})
    controller: str = field(metadata={"title": "Controller", "width": 20})
    scope: str = field(metadata={"title": "Scope", "width": 10})
    age: str = field(metadata={"title": "Age", "width": 5, "detail": False})

    @classmethod
    def clean(cls, data: V1IngressClass) -> "IngressClassViewModel":
        return cls(
            name=data.metadata.name,
            default="⭐" if data.metadata.annotations.get('ingressclass.kubernetes.io/is-default-class') == "true" else "",
            namespace=data.spec.parameters.namespace if data.spec.parameters and data.spec.parameters.scope == "Namespace" else "",
            controller=data.spec.controller,
            scope=data.spec.parameters.scope if data.spec.parameters else "",
            age=cls.get_age_text(data.metadata.creation_timestamp),
        )
    

@dataclass
class IngressClassDetailModel(IngressClassViewModel):
    created: str = field(default_factory=str, metadata={"title": "Created", "after": "namespace"})
    labels: dict = field(default_factory=dict, metadata={"title": "Lables"})
    annotations: dict = field(default_factory=dict, metadata={"title": "Annotations"})
    parameters: dict = field(default_factory=dict, metadata={"title": "Parameters"})

    @classmethod
    def clean(cls, data: V1IngressClass) -> "IngressClassDetailModel":
        base = super().clean(data).__dict__
        base.update({
            'created': cls.get_created_text(data.metadata.creation_timestamp),
            'labels': data.metadata.labels,
            'annotations': data.metadata.annotations,
            'parameters': data.spec.parameters
        })
        return cls(**base)
    

@dataclass
class NetworkPolicyViewModel(ViewModel):
    name: str = field(metadata={"title": "Name", "width": 15})
    namespace: str = field(metadata={"title": "Namespace", "width": 10})
    policytypes: list[str] = field(metadata={"title": "Policy Types", "width": 20, "after": "annotations", "renderer": f.networkpolicy_policytypes_renderer})
    age: str = field(metadata={"title": "Age", "width": 5, "detail": False})

    @classmethod
    def clean(cls, data: V1NetworkPolicy) -> "NetworkPolicyViewModel":
        return cls(
            name=data.metadata.name,
            namespace=data.metadata.namespace,
            policytypes=data.spec.policy_types,
            age=cls.get_age_text(data.metadata.creation_timestamp),
        )
    

@dataclass
class NetworkPolicyDetailModel(NetworkPolicyViewModel):
    created: str = field(default_factory=str, metadata={"title": "Created", "after": "namespace"})
    annotations: dict = field(default_factory=dict, metadata={"title": "Annotations"})
    podselector: V1LabelSelector = field(default_factory=V1LabelSelector, metadata={"title": "Pod Selector"})
    ingress: list[V1NetworkPolicyIngressRule] = field(default_factory=list, metadata={"title": "Ingress"})
    egress: list[V1NetworkPolicyEgressRule] = field(default_factory=list, metadata={"title": "Egress"})

    @classmethod
    def clean(cls, data: V1NetworkPolicy) -> "NetworkPolicyDetailModel":
        base = super().clean(data).__dict__
        base.update({
            'created': cls.get_created_text(data.metadata.creation_timestamp),
            'annotations': data.metadata.annotations,
            'podselector': data.spec.pod_selector,
            'ingress': data.spec.ingress,
            'egress': data.spec.egress,
        })
        return cls(**base)
    

@dataclass
class PersistentVolumeViewModel(ViewModel):
    name: str = field(metadata={"title": "Name", "width": 20})
    storageclass: str = field(metadata={"title": "Storage Class", "width": 10})
    capacity: dict = field(metadata={"title": "Capacity", "width": 5, "renderer": f.pv_capacity_renderer})
    claim: str = field(metadata={"title": "Claim", "width": 15})
    accessmodes: list[str] = field(metadata={"title": "Access Modes", "width": 10, "renderer": f.pv_accessmodes_renderer})
    age: str = field(metadata={"title": "Age", "width": 5, "detail": False})
    status: str = field(metadata={"title": "Status", "width": 5, "renderer": f.pv_status_renderer})

    @classmethod
    def clean(cls, data: V1PersistentVolume) -> "PersistentVolumeViewModel":
        return cls(
            name=data.metadata.name,
            storageclass=data.spec.storage_class_name,
            capacity=data.spec.capacity,
            claim=data.spec.claim_ref.name if data.spec.claim_ref else "",
            status=data.status.phase,
            accessmodes=data.spec.access_modes,
            age=cls.get_age_text(data.metadata.creation_timestamp),
        )
    

@dataclass
class PersistentVolumeDetailModel(PersistentVolumeViewModel):
    created: str = field(default_factory=str, metadata={"title": "Created", "after": "name"})
    annotations: dict = field(default_factory=dict, metadata={"title": "Annotations"})
    finalizers: list = field(default_factory=list, metadata={"title": "Finalizers"})
    reclaimpolicy: str = field(default_factory=str, metadata={"title": "Reclaim Policy"})
    volumemode: str = field(default_factory=str, metadata={"title": "Volume Mode"})
    localpath: str = field(default_factory=str, metadata={"title": "Local Path"})
    affinities: dict = field(default_factory=dict, metadata={"title": "Node Affinity"})

    @classmethod
    def clean(cls, data: V1PersistentVolume) -> "PersistentVolumeDetailModel":
        base = super().clean(data).__dict__
        base.update({
            'created': cls.get_created_text(data.metadata.creation_timestamp),
            'annotations': data.metadata.annotations,
            'finalizers': data.metadata.finalizers,
            'reclaimpolicy': data.spec.persistent_volume_reclaim_policy,
            'volumemode': data.spec.volume_mode,
            'localpath': data.spec.local.path if data.spec.local else "",
            'affinities': data.spec.node_affinity
        })
        return cls(**base)
    

@dataclass
class PersistentVolumeClaimViewModel(ViewModel):
    name: str = field(metadata={"title": "Name", "width": 15})
    namespace: str = field(metadata={"title": "Namespace", "width": 10})
    strorageclass: str = field(metadata={"title": "Storage", "width": 10, "after": "labels"})
    size: str = field(metadata={"title": "Size", "width": 10})
    age: str = field(metadata={"title": "Age", "width": 5, "detail": False})
    status: str = field(metadata={"title": "Status", "width": 5, "renderer": f.pv_status_renderer})

    @classmethod
    def clean(cls, data: V1PersistentVolumeClaim) -> "PersistentVolumeClaimViewModel":
        return cls(
            name=data.metadata.name,
            namespace=data.metadata.namespace,
            strorageclass=data.spec.storage_class_name,
            size=data.spec.resources.requests['storage'] if data.spec.resources else "",
            status=data.status.phase,
            age=cls.get_age_text(data.metadata.creation_timestamp),
        )
    

@dataclass
class PersistentVolumeClaimDetailModel(PersistentVolumeClaimViewModel):
    created: str = field(default_factory=str, metadata={"title": "Created", "after": "namespace"})
    labels: dict = field(default_factory=dict, metadata={"title": "Labels", "after": "created"})
    annotations: dict = field(default_factory=dict, metadata={"title": "Annotations"})
    finalizers: list = field(default_factory=list, metadata={"title": "Finalizers"})
    selector: dict = field(default_factory=dict, metadata={"title": "Selector"})
    accessmodes: list[str] = field(default_factory=list,metadata={"title": "Access Modes"})
    volumename: str = field(default_factory=str, metadata={"title": "Volume Name"})
    volumemode: str = field(default_factory=str, metadata={"title": "Volume Mode"})


    @classmethod
    def clean(cls, data: V1PersistentVolumeClaim) -> "PersistentVolumeClaimDetailModel":
        base = super().clean(data).__dict__
        base.update({
            'created': cls.get_created_text(data.metadata.creation_timestamp),
            'labels': data.metadata.labels,
            'annotations': data.metadata.annotations,
            'finalizers': data.metadata.finalizers,
            'selector': data.spec.selector,
            'accessmodes': data.spec.access_modes,
            'volumename': data.spec.volume_name,
            'volumemode': data.spec.volume_mode
        })
        return cls(**base)


@dataclass
class StorageClassViewModel(ViewModel):
    name: str = field(metadata={"title": "Name", "width": 15})
    default: str = field(metadata={"title": "Default", "width": 5, "after": "labels"})
    provisioner: str = field(metadata={"title": "Provisioner", "width": 15})
    reclaimpolicy: str = field(metadata={"title": "Reclaim Policy", "width": 10})
    age: str = field(metadata={"title": "Age", "width": 5, "detail": False})

    @classmethod
    def clean(cls, data: V1StorageClass) -> "StorageClassViewModel":
        return cls(
            name=data.metadata.name,
            default=cls._get_default(data),
            provisioner=data.provisioner,
            reclaimpolicy=data.reclaim_policy,
            age=cls.get_age_text(data.metadata.creation_timestamp),
        )
    
    @staticmethod
    def _get_default(data: V1StorageClass) -> str:
        if data.metadata.annotations.get('storageclass.kubernetes.io/is-default-class') == 'true':
            return '⭐'
        return ''


@dataclass
class StorageClassDetailModel(StorageClassViewModel):
    created: str = field(default_factory=str, metadata={"title": "Created", "after": "name"})
    labels: dict = field(default_factory=dict, metadata={"title": "Lables"})
    annotations: dict = field(default_factory=dict, metadata={"title": "Annotations"})
    providerparameters: dict = field(default_factory=dict, metadata={"title": "Parameters"})
    volumebindingmode: str = field(default_factory=str, metadata={"title": "Binding Mode"})
    mountoptions: list = field(default_factory=list, metadata={"title": "Mount Options"})
    allowvolumeexpansion: str = field(default_factory=str, metadata={"title": "Allow Expansion"})

    @classmethod
    def clean(cls, data: V1StorageClass) -> "StorageClassDetailModel":
        base = super().clean(data).__dict__
        base.update({
            'created': cls.get_created_text(data.metadata.creation_timestamp),
            'labels': data.metadata.labels,
            'annotations': data.metadata.annotations,
            'providerparameters': data.parameters,
            'volumebindingmode': data.volume_binding_mode,
            'mountoptions': data.mount_options,
            'allowvolumeexpansion': str(data.allow_volume_expansion or 'True')
        })
        return cls(**base)
    

@dataclass
class NamespaceViewModel(ViewModel):
    name: str = field(metadata={"title": "Name", "width": 15})
    age: str = field(metadata={"title": "Age", "width": 5, "detail": False})
    status: str = field(metadata={"title": "Status", "width": 5, "after": "labels", "renderer": f.namespace_status_renderer})

    @classmethod
    def clean(cls, data: V1Namespace) -> "NamespaceViewModel":
        return cls(
            name=data.metadata.name,
            age=cls.get_age_text(data.metadata.creation_timestamp),
            status=data.status.phase,
        )


@dataclass
class NamespaceDetailModel(NamespaceViewModel):
    created: str = field(default_factory=str, metadata={"title": "Created", "after": "name"})
    labels: dict = field(default_factory=dict, metadata={"title": "Labels"})
    annotations: dict = field(default_factory=dict, metadata={"title": "Annotations"})
    finalizers: list = field(default_factory=list, metadata={"title": "Finalizers"})

    @classmethod
    def clean(cls, data: V1Namespace) -> "NamespaceDetailModel":
        base = super().clean(data).__dict__
        base.update({
            'created': cls.get_created_text(data.metadata.creation_timestamp),
            'labels': data.metadata.labels,
            'annotations': data.metadata.annotations,
            'finalizers': data.metadata.finalizers,
        })
        return cls(**base)
    

@dataclass
class ServiceAccountViewModel(ViewModel):
    name: str = field(metadata={"title": "Name", "width": 15})
    namespace: str = field(metadata={"title": "Namespace", "width": 10})
    age: str = field(metadata={"title": "Age", "width": 5, "detail": False})

    @classmethod
    def clean(cls, data: V1ServiceAccount) -> "ServiceAccountViewModel":
        return cls(
            name=data.metadata.name,
            namespace=data.metadata.namespace,
            age=cls.get_age_text(data.metadata.creation_timestamp),
        )
    

@dataclass
class ServiceAccountDetailModel(ServiceAccountViewModel):
    created: str = field(default_factory=str, metadata={"title": "Created", "after": "namespace"})
    labels: dict = field(default_factory=dict, metadata={"title": "Labels"})
    annotations: dict = field(default_factory=dict, metadata={"title": "Annotations"})
    ownerreferences: list = field(default_factory=list, metadata={"title": "Owner References"})
    secrets: list = field(default_factory=list, metadata={"title": "Secrets"})
    automounttokens: str = field(default_factory=str, metadata={"title": "AutoMount Tokens"})
    imagepullsecrets: list = field(default_factory=list, metadata={"title": "Image Pull Secrets"})

    @classmethod
    def clean(cls, data: V1ServiceAccount) -> "ServiceAccountDetailModel":
        base = super().clean(data).__dict__
        base.update({
            'created': cls.get_created_text(data.metadata.creation_timestamp),
            'labels': data.metadata.labels,
            'annotations': data.metadata.annotations,
            'ownerreferences': cls._get_ownerreferences(data.metadata.owner_references),
            'secrets': data.secrets,
            'automounttokens': str(data.automount_service_account_token),
            'imagepullsecrets': data.image_pull_secrets
        })
        return cls(**base)
    
    @staticmethod
    def _get_ownerreferences(data) -> list:
        if not data:
            return []
        return [f"{x.kind}/{x.name}" for x in data]
    

@dataclass
class RoleViewModel(ViewModel):
    name: str = field(metadata={"title": "Name", "width": 15})
    namespace: str = field(metadata={"title": "Namespace", "width": 10})
    age: str = field(metadata={"title": "Age", "width": 5, "detail": False})

    @classmethod
    def clean(cls, data: V1Role) -> "RoleViewModel":
        return cls(
            name=data.metadata.name,
            namespace=data.metadata.namespace,
            age=cls.get_age_text(data.metadata.creation_timestamp),
        )
    

@dataclass
class RoleDetailModel(RoleViewModel):
    created: str = field(default_factory=str, metadata={"title": "Created", "after": "namespace"})
    labels: dict = field(default_factory=dict, metadata={"title": "Labels"})
    annotations: dict = field(default_factory=dict, metadata={"title": "Annotations"})
    rolerules: list = field(default_factory=list, metadata={"title": "Rules"})

    @classmethod
    def clean(cls, data: V1Role) -> "RoleDetailModel":
        base = super().clean(data).__dict__
        base.update({
            'created': cls.get_created_text(data.metadata.creation_timestamp),
            'labels': data.metadata.labels,
            'annotations': data.metadata.annotations,
            'rolerules': data.rules,
        })
        return cls(**base)
    

@dataclass
class ClusterRoleViewModel(ViewModel):
    name: str = field(metadata={"title": "Name", "width": 15})
    age: str = field(metadata={"title": "Age", "width": 5, "detail": False})

    @classmethod
    def clean(cls, data: V1ClusterRole) -> "ClusterRoleViewModel":
        return cls(
            name=data.metadata.name,
            age=cls.get_age_text(data.metadata.creation_timestamp),
        )
    

@dataclass
class ClusterRoleDetailModel(ClusterRoleViewModel):
    created: str = field(default_factory=str, metadata={"title": "Created", "after": "name"})
    labels: dict = field(default_factory=dict, metadata={"title": "Labels"})
    annotations: dict = field(default_factory=dict, metadata={"title": "Annotations"})
    rolerules: list = field(default_factory=list, metadata={"title": "Rules"})

    @classmethod
    def clean(cls, data: V1ClusterRole) -> "ClusterRoleDetailModel":
        base = super().clean(data).__dict__
        base.update({
            'created': cls.get_created_text(data.metadata.creation_timestamp),
            'labels': data.metadata.labels,
            'annotations': data.metadata.annotations,
            'rolerules': data.rules,
        })
        return cls(**base)
    

@dataclass
class RoleBindingViewModel(ViewModel):
    name: str = field(metadata={"title": "Name", "width": 15})
    namespace: str = field(metadata={"title": "Namespace", "width": 10})
    bindings: list = field(metadata={"title": "Bindings", "width": 10, "renderer": f.rolebinding_bindings_renderer, "after": "roleref"})
    age: str = field(metadata={"title": "Age", "width": 5, "detail": False})

    @classmethod
    def clean(cls, data: V1RoleBinding) -> "RoleBindingViewModel":
        return cls(
            name=data.metadata.name,
            namespace=data.metadata.namespace,
            bindings=data.subjects,
            age=cls.get_age_text(data.metadata.creation_timestamp),
        )
    

@dataclass
class RoleBindingDetailModel(RoleBindingViewModel): 
    created: str = field(default_factory=str, metadata={"title": "Created", "after": "namespace"})
    labels: dict = field(default_factory=dict, metadata={"title": "Labels"})
    annotations: dict = field(default_factory=dict, metadata={"title": "Annotations"})
    roleref: dict = field(default_factory=dict, metadata={"title": "Role Reference"})

    @classmethod
    def clean(cls, data: V1RoleBinding) -> "RoleBindingDetailModel":
        base = super().clean(data).__dict__
        base.update({
            'created': cls.get_created_text(data.metadata.creation_timestamp),
            'labels': data.metadata.labels,
            'annotations': data.metadata.annotations,
            'roleref': data.role_ref,
        })
        return cls(**base)
    

@dataclass
class ClusterRoleBindingViewModel(ViewModel):
    name: str = field(metadata={"title": "Name", "width": 15})
    bindings: list = field(metadata={"title": "Bindings", "width": 10, "renderer": f.rolebinding_bindings_renderer, "after": "roleref"})
    age: str = field(metadata={"title": "Age", "width": 5, "detail": False})

    @classmethod
    def clean(cls, data: V1ClusterRoleBinding) -> "ClusterRoleBindingViewModel":
        return cls(
            name=data.metadata.name,
            bindings=data.subjects,
            age=cls.get_age_text(data.metadata.creation_timestamp),
        )
    

@dataclass
class ClusterRoleBindingDetailModel(ClusterRoleBindingViewModel):
    created: str = field(default_factory=str, metadata={"title": "Created", "after": "name"})
    labels: dict = field(default_factory=dict, metadata={"title": "Labels"})
    annotations: dict = field(default_factory=dict, metadata={"title": "Annotations"})
    roleref: dict = field(default_factory=dict, metadata={"title": "Role Reference"})

    @classmethod
    def clean(cls, data: V1ClusterRoleBinding) -> "ClusterRoleBindingDetailModel":
        base = super().clean(data).__dict__
        base.update({
            'created': cls.get_created_text(data.metadata.creation_timestamp),
            'labels': data.metadata.labels,
            'annotations': data.metadata.annotations,
            'roleref': data.role_ref,
        })
        return cls(**base)
