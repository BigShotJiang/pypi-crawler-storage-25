# Contributing

Thanks for helping improve the Orloj Python SDK. This document describes how to set up a dev environment and what we expect before a change is merged.

## Prerequisites

- **Python 3.10+** (CI runs 3.10 through 3.13)
- A virtual environment is recommended

## Local setup

```bash
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -e ".[dev]"
```

## Checks (run before opening a PR)

These mirror [`.github/workflows/ci.yml`](.github/workflows/ci.yml):

```bash
ruff check src/orloj_sdk tests examples
ruff format src/orloj_sdk tests examples   # or: ruff format --check ... to verify only
mypy src/orloj_sdk
pytest --cov=orloj_sdk --cov-report=term-missing
```

Fix any failures locally; CI must pass on the matrix of Python versions.

## Tests

- Default tests are offline / mocked where applicable.
- Tests marked `integration` need a live Orloj API and are only run when you opt in (see `pytest` markers in `pyproject.toml`). Do not rely on integration tests for routine CI unless the workflow is updated accordingly.

## Release version

The published package version is taken from **Git tags** (`hatch-vcs` / setuptools-scm), not from editing `src/orloj_sdk/_version.py`. At release time, create an annotated tag whose name matches the version (for example `v0.2.0` for `0.2.0`) and push it; CI builds and uploads that version to PyPI. Runtime `orloj_sdk.__version__` comes from the installed package metadata (after `pip install -e .` or installing from PyPI).

## Pull requests

- Keep changes focused on one concern when possible.
- Update or add tests when behavior changes.
- Match existing style: typing, Pydantic usage, and public API patterns in `src/orloj_sdk`.

## License

By contributing, you agree that your contributions are licensed under the same terms as the project ([Apache-2.0](LICENSE)).
