from __future__ import annotations

import httpx
import respx
from httpx import Response

from orloj_sdk import OrlojClient

_AGENT = {
    "apiVersion": "orloj.dev/v1",
    "kind": "Agent",
    "metadata": {"name": "a", "namespace": "default"},
    "spec": {},
}
_AGENT_B = {
    "apiVersion": "orloj.dev/v1",
    "kind": "Agent",
    "metadata": {"name": "b", "namespace": "default"},
    "spec": {},
}


@respx.mock
def test_list_all_follows_continue_cursor(base_url: str) -> None:
    page1 = {"metadata": {"continue": "c2"}, "items": [_AGENT]}
    page2 = {"metadata": {"continue": None}, "items": [_AGENT_B]}

    def respond(request: httpx.Request) -> Response:
        if request.url.params.get("after") == "c2":
            return Response(200, json=page2)
        return Response(200, json=page1)

    respx.get(f"{base_url}/v1/agents").mock(side_effect=respond)

    client = OrlojClient(base_url=base_url, api_token="t")
    names = [a.metadata.name for a in client.agents.list_all()]
    assert names == ["a", "b"]
