from __future__ import annotations

import respx
from httpx import Response

from orloj_sdk import OrlojClient


@respx.mock
def test_whoami(base_url: str) -> None:
    respx.get(f"{base_url}/v1/auth/me").mock(
        return_value=Response(
            200,
            json={
                "authenticated": True,
                "username": "u",
                "role": "admin",
                "method": "token",
            },
        )
    )
    client = OrlojClient(base_url=base_url, api_token="t")
    w = client.auth.whoami()
    assert w.authenticated is True
    assert w.username == "u"


@respx.mock
def test_agents_list(base_url: str) -> None:
    respx.get(f"{base_url}/v1/agents", params={"namespace": "default"}).mock(
        return_value=Response(200, json={"metadata": {"continue": None}, "items": []})
    )
    client = OrlojClient(base_url=base_url, api_token="t")
    page = client.agents.list()
    assert page.items == []
