from __future__ import annotations

import pytest
import respx
from httpx import Response

from orloj_sdk import NotFoundError, OrlojClient


@respx.mock
def test_not_found_maps(base_url: str) -> None:
    respx.get(f"{base_url}/v1/agents/nope", params={"namespace": "default"}).mock(
        return_value=Response(404, text="not found")
    )
    client = OrlojClient(base_url=base_url, api_token="t")
    with pytest.raises(NotFoundError) as ei:
        client.agents.get("nope")
    assert ei.value.status_code == 404
    assert "not found" in ei.value.message
