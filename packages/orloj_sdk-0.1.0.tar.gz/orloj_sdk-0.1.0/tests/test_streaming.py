from __future__ import annotations

from unittest.mock import MagicMock

import httpx

from orloj_sdk._streaming import _parse_watch_payload, iter_sse_events
from orloj_sdk.models.agent import Agent


def test_iter_sse_events_parses_data_event() -> None:
    agent_json = (
        '{"apiVersion":"orloj.dev/v1","kind":"Agent",'
        '"metadata":{"name":"a","namespace":"default"},"spec":{}}'
    )
    lines = [
        b"event: resource",
        f'data: {{"type":"updated","resource":{agent_json}}}'.encode(),
        b"",
    ]
    resp = MagicMock(spec=httpx.Response)
    resp.iter_lines.return_value = iter(lines)

    evs = list(iter_sse_events(resp))
    assert len(evs) == 1
    assert evs[0]["event"] == "resource"
    assert '"kind":"Agent"' in evs[0]["data"]


def test_parse_watch_payload() -> None:
    raw = (
        '{"type":"updated","resource":{'
        '"apiVersion":"orloj.dev/v1","kind":"Agent",'
        '"metadata":{"name":"a","namespace":"default"},'
        '"spec":{}}}'
    )
    we = _parse_watch_payload(raw, Agent)
    assert we.type == "updated"
    assert isinstance(we.resource, Agent)
    assert we.resource.metadata.name == "a"
