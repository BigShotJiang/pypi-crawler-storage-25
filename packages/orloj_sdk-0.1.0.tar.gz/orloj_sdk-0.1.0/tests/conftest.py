import pytest


@pytest.fixture
def base_url() -> str:
    return "http://127.0.0.1:8080"
