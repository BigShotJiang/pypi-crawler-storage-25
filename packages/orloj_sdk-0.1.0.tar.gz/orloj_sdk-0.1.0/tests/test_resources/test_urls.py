"""Smoke-test that resource methods hit expected paths and query params."""

from __future__ import annotations

import respx
from httpx import Response

from orloj_sdk import OrlojClient


@respx.mock
def test_tools_get_includes_namespace(base_url: str) -> None:
    body = {
        "apiVersion": "orloj.dev/v1",
        "kind": "Tool",
        "metadata": {"name": "t", "namespace": "default"},
        "spec": {"type": "http"},
    }
    respx.get(f"{base_url}/v1/tools/t", params={"namespace": "default"}).mock(
        return_value=Response(200, json=body)
    )
    client = OrlojClient(base_url=base_url, api_token="x")
    t = client.tools.get("t")
    assert t.metadata.name == "t"


@respx.mock
def test_auth_create_token_json(base_url: str) -> None:
    respx.post(f"{base_url}/v1/tokens").mock(
        return_value=Response(
            200,
            json={
                "name": "tok",
                "role": "admin",
                "token": "secret",
                "createdAt": "2026-01-01T00:00:00Z",
            },
        )
    )
    client = OrlojClient(base_url=base_url, api_token="x")
    info = client.auth.create_token("tok", "admin")
    assert info.token == "secret"
