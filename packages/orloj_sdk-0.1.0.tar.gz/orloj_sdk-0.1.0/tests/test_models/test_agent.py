from __future__ import annotations

from orloj_sdk.models._base import ObjectMeta
from orloj_sdk.models.agent import Agent, AgentSpec


def test_agent_roundtrip_json_aliases() -> None:
    a = Agent(
        metadata=ObjectMeta(name="n"),
        spec=AgentSpec(prompt="hi"),
    )
    dumped = a.model_dump(mode="json", by_alias=True)
    b = Agent.model_validate(dumped)
    assert b.spec.prompt == "hi"
    assert b.metadata.name == "n"
