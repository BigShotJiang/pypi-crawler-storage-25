#!/usr/bin/env python3
"""AsyncOrlojClient: list agents and call whoami concurrently."""

from __future__ import annotations

import asyncio

from orloj_sdk import AsyncOrlojClient


async def main() -> None:
    async with AsyncOrlojClient() as client:
        who, page = await asyncio.gather(client.auth.whoami(), client.agents.list(limit=5))
        print(f"whoami: authenticated={who.authenticated}")
        print(f"agents: {len(page.items)} on first page")


if __name__ == "__main__":
    asyncio.run(main())
