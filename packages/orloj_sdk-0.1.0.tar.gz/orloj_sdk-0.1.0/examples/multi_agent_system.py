#!/usr/bin/env python3
"""
Create an AgentSystem with a simple graph (single agent node).

Adjust agent names and graph to match resources that already exist on your server.
"""

from __future__ import annotations

from orloj_sdk import OrlojClient
from orloj_sdk.models import AgentSystem, AgentSystemSpec, GraphEdge, ObjectMeta


def main() -> None:
    client = OrlojClient()

    agent_name = "researcher"
    system = client.agent_systems.create(
        AgentSystem(
            metadata=ObjectMeta(name="demo-pipeline"),
            spec=AgentSystemSpec(
                agents=[agent_name],
                graph={agent_name: GraphEdge()},
            ),
        )
    )
    print(f"created AgentSystem {system.metadata.name} namespace={system.metadata.namespace}")


if __name__ == "__main__":
    main()
