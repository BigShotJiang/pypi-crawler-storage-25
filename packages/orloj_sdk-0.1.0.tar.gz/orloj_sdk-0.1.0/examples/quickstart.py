#!/usr/bin/env python3
"""
Minimal Orloj client usage: auth and listing agents.

Requires a running Orloj API. Configure via env (see README) or pass arguments
to OrlojClient(base_url=..., api_token=...).
"""

from __future__ import annotations

from orloj_sdk import OrlojClient


def main() -> None:
    client = OrlojClient()
    me = client.auth.whoami()
    print(f"whoami: authenticated={me.authenticated} user={me.username!r} role={me.role!r}")

    page = client.agents.list(limit=10)
    cont = page.metadata.continue_ if page.metadata else None
    print(f"agents page: {len(page.items)} item(s), continue={cont}")


if __name__ == "__main__":
    main()
