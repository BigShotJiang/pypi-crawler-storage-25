#!/usr/bin/env python3
"""
Stream task updates over SSE until the task reaches a terminal phase.

Set TASK_NAME to an existing task name, or pass as first CLI argument.
Requires ORLOJ_API_TOKEN / server URL (or defaults to http://127.0.0.1:8080).
"""

from __future__ import annotations

import sys

from orloj_sdk import OrlojClient


def main() -> None:
    task_name = sys.argv[1] if len(sys.argv) > 1 else "my-task"
    client = OrlojClient()

    with client.tasks.watch(name=task_name) as stream:
        for event in stream:
            t = event.resource
            phase = t.status.phase if t.status else None
            print(f"{event.type}: {t.metadata.name} phase={phase}")
            if phase in ("Completed", "Failed", "Cancelled"):
                break


if __name__ == "__main__":
    main()
