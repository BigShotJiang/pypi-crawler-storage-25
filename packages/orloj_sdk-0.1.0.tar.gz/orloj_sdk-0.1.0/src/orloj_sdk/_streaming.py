from __future__ import annotations

import json
from collections.abc import AsyncIterator, Iterator
from contextlib import ExitStack
from typing import Any, Generic, TypeVar

import httpx

from orloj_sdk._transport import async_exit_cm
from orloj_sdk.models._base import OrlojModel
from orloj_sdk.models.event import ServerEvent, WatchEvent

T = TypeVar("T", bound=OrlojModel)


def _parse_sse_event_lines(lines: list[str]) -> dict[str, str] | None:
    """Parse one SSE event from accumulated non-empty lines (excluding blank separator)."""
    if not lines:
        return None
    event_name = "message"
    data_parts: list[str] = []
    for line in lines:
        if line.startswith(":"):
            continue
        if line.startswith("event:"):
            event_name = line[len("event:") :].strip()
        elif line.startswith("data:"):
            data_parts.append(line[len("data:") :].lstrip())
    if not data_parts:
        return None
    return {"event": event_name, "data": "\n".join(data_parts)}


def iter_sse_events(response: httpx.Response) -> Iterator[dict[str, str]]:
    """Yield SSE events as dicts with keys 'event' and 'data'."""
    buf: list[str] = []
    for raw in response.iter_lines():
        line = raw.decode("utf-8") if isinstance(raw, (bytes, bytearray)) else raw
        if line == "":
            ev = _parse_sse_event_lines(buf)
            buf = []
            if ev is not None:
                yield ev
            continue
        buf.append(line)
    ev = _parse_sse_event_lines(buf)
    if ev is not None:
        yield ev


async def aiter_sse_events(response: httpx.Response) -> AsyncIterator[dict[str, str]]:
    buf: list[str] = []
    async for raw in response.aiter_lines():
        line = raw.decode("utf-8") if isinstance(raw, (bytes, bytearray)) else raw
        if line == "":
            ev = _parse_sse_event_lines(buf)
            buf = []
            if ev is not None:
                yield ev
            continue
        buf.append(line)
    ev = _parse_sse_event_lines(buf)
    if ev is not None:
        yield ev


def _parse_watch_payload(data: str, model_cls: type[T]) -> WatchEvent[T]:
    payload: dict[str, Any] = json.loads(data)
    res = payload.get("resource")
    validated = model_cls.model_validate(res) if isinstance(res, dict) else res
    return WatchEvent(type=payload["type"], resource=validated)


class WatchStream(Generic[T]):
    """Iterable that yields WatchEvent[T] from an SSE stream."""

    def __init__(
        self,
        response: httpx.Response,
        model_cls: type[T],
        *,
        close_stack: ExitStack | None = None,
    ) -> None:
        self._response = response
        self._model_cls = model_cls
        self._close_stack = close_stack
        self._iterator = self._gen()

    def _gen(self) -> Iterator[WatchEvent[T]]:
        try:
            for ev in iter_sse_events(self._response):
                data = ev.get("data", "")
                if not data.strip():
                    continue
                yield _parse_watch_payload(data, self._model_cls)
        finally:
            self.close()

    def __iter__(self) -> Iterator[WatchEvent[T]]:
        return self._iterator

    def close(self) -> None:
        if self._close_stack is not None:
            self._close_stack.close()
        else:
            self._response.close()

    def __enter__(self) -> WatchStream[T]:
        return self

    def __exit__(self, *args: object) -> None:
        self.close()


class AsyncWatchStream(Generic[T]):
    """Async iterable of WatchEvent[T] from an SSE stream."""

    def __init__(
        self,
        response: httpx.Response,
        model_cls: type[T],
        *,
        stream_cm: Any | None = None,
    ) -> None:
        self._response = response
        self._model_cls = model_cls
        self._stream_cm = stream_cm
        self._closed = False

    def __aiter__(self) -> AsyncIterator[WatchEvent[T]]:
        return self._stream()

    async def _stream(self) -> AsyncIterator[WatchEvent[T]]:
        try:
            async for ev in aiter_sse_events(self._response):
                data = ev.get("data", "")
                if not data.strip():
                    continue
                yield _parse_watch_payload(data, self._model_cls)
        finally:
            await self.aclose()

    async def aclose(self) -> None:
        if self._closed:
            return
        self._closed = True
        if self._stream_cm is not None:
            await async_exit_cm(self._stream_cm)
        else:
            await self._response.aclose()


class AsyncWatchContext(Generic[T]):
    """`async with client.agents.watch(...) as stream` — opens the SSE request on enter."""

    def __init__(self, client: Any, path: str, params: dict[str, str], model_cls: type[T]) -> None:
        self._client = client
        self._path = path
        self._params = params
        self._model_cls = model_cls
        self._stream: AsyncWatchStream[T] | None = None

    async def __aenter__(self) -> AsyncWatchStream[T]:
        resp, cm = await self._client._open_stream_async("GET", self._path, params=self._params)
        self._stream = AsyncWatchStream(resp, self._model_cls, stream_cm=cm)
        return self._stream

    async def __aexit__(self, *args: object) -> None:
        if self._stream is not None:
            await self._stream.aclose()
            self._stream = None


class ServerEventStream:
    """SSE iterator for `/v1/events/watch`."""

    def __init__(self, response: httpx.Response, *, close_stack: ExitStack | None = None) -> None:
        self._response = response
        self._close_stack = close_stack
        self._iterator = self._gen()

    def _gen(self) -> Iterator[ServerEvent]:
        try:
            for ev in iter_sse_events(self._response):
                data = ev.get("data", "")
                if data.strip():
                    yield ServerEvent.model_validate(json.loads(data))
        finally:
            self.close()

    def __iter__(self) -> Iterator[ServerEvent]:
        return self._iterator

    def close(self) -> None:
        if self._close_stack is not None:
            self._close_stack.close()
        else:
            self._response.close()

    def __enter__(self) -> ServerEventStream:
        return self

    def __exit__(self, *args: object) -> None:
        self.close()


class AsyncServerEventStream:
    def __init__(self, response: httpx.Response, *, stream_cm: Any | None = None) -> None:
        self._response = response
        self._stream_cm = stream_cm
        self._closed = False

    def __aiter__(self) -> AsyncIterator[ServerEvent]:
        return self._stream()

    async def _stream(self) -> AsyncIterator[ServerEvent]:
        try:
            async for ev in aiter_sse_events(self._response):
                data = ev.get("data", "")
                if data.strip():
                    yield ServerEvent.model_validate(json.loads(data))
        finally:
            await self.aclose()

    async def aclose(self) -> None:
        if self._closed:
            return
        self._closed = True
        if self._stream_cm is not None:
            await async_exit_cm(self._stream_cm)
        else:
            await self._response.aclose()


class AsyncServerEventContext:
    def __init__(self, client: Any, params: dict[str, str] | None) -> None:
        self._client = client
        self._params = params
        self._stream: AsyncServerEventStream | None = None

    async def __aenter__(self) -> AsyncServerEventStream:
        resp, cm = await self._client._open_stream_async(
            "GET",
            "/v1/events/watch",
            params=self._params,
        )
        self._stream = AsyncServerEventStream(resp, stream_cm=cm)
        return self._stream

    async def __aexit__(self, *args: object) -> None:
        if self._stream is not None:
            await self._stream.aclose()
            self._stream = None
