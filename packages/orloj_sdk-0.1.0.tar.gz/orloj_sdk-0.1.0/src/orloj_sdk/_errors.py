from __future__ import annotations


class OrlojError(Exception):
    """Base exception for all SDK errors."""

    status_code: int | None
    message: str

    def __init__(self, message: str, *, status_code: int | None = None) -> None:
        super().__init__(message)
        self.message = message
        self.status_code = status_code


class OrlojAPIError(OrlojError):
    """Raised for non-2xx HTTP responses."""

    status_code: int

    def __init__(self, message: str, *, status_code: int) -> None:
        super().__init__(message, status_code=status_code)


class BadRequestError(OrlojAPIError):
    """HTTP 400."""


class AuthenticationError(OrlojAPIError):
    """HTTP 401."""


class NotFoundError(OrlojAPIError):
    """HTTP 404."""


class ConflictError(OrlojAPIError):
    """HTTP 409."""


class RateLimitError(OrlojAPIError):
    """HTTP 429."""


class InternalServerError(OrlojAPIError):
    """HTTP 500+."""


class ServiceUnavailableError(OrlojAPIError):
    """HTTP 503."""


class OrlojConnectionError(OrlojError):
    """Raised when the server is unreachable."""


class OrlojTimeoutError(OrlojError):
    """Raised when a request times out."""


def raise_for_status(status_code: int, body: str) -> None:
    """Map HTTP status to typed API errors."""
    exc_map: dict[int, type[OrlojAPIError]] = {
        400: BadRequestError,
        401: AuthenticationError,
        404: NotFoundError,
        409: ConflictError,
        429: RateLimitError,
        503: ServiceUnavailableError,
    }
    msg = body.strip()
    exc_class = exc_map.get(status_code)
    if exc_class is not None:
        raise exc_class(msg, status_code=status_code)
    if status_code >= 500:
        raise InternalServerError(msg, status_code=status_code)
    raise OrlojAPIError(msg, status_code=status_code)
