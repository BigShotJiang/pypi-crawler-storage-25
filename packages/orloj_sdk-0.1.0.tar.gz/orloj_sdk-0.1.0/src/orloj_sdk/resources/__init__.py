"""Resource accessors attached to OrlojClient / AsyncOrlojClient."""
