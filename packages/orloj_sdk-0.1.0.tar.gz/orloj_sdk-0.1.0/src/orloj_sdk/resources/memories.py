from __future__ import annotations

from orloj_sdk.models.memory import Memory, MemoryEntriesResponse, MemoryList
from orloj_sdk.resources._base import AsyncBaseResource, BaseResource, _path_seg


class Memories(BaseResource[Memory, MemoryList]):
    path = "/v1/memories"
    item_model = Memory
    list_model = MemoryList

    def query_entries(
        self,
        name: str,
        *,
        namespace: str | None = None,
        q: str | None = None,
        prefix: str | None = None,
        limit: int | None = None,
    ) -> MemoryEntriesResponse:
        p = f"{self.path}/{_path_seg(name)}/entries"
        params: dict[str, str | int] = {"namespace": self._ns(namespace)}
        if q is not None:
            params["q"] = q
        if prefix is not None:
            params["prefix"] = prefix
        if limit is not None:
            params["limit"] = limit
        r = self._client._request("GET", p, params=params)
        self._client._check_response(r)
        return MemoryEntriesResponse.model_validate(r.json())


class AsyncMemories(AsyncBaseResource[Memory, MemoryList]):
    path = "/v1/memories"
    item_model = Memory
    list_model = MemoryList

    async def query_entries(
        self,
        name: str,
        *,
        namespace: str | None = None,
        q: str | None = None,
        prefix: str | None = None,
        limit: int | None = None,
    ) -> MemoryEntriesResponse:
        p = f"{self.path}/{_path_seg(name)}/entries"
        params: dict[str, str | int] = {"namespace": self._ns(namespace)}
        if q is not None:
            params["q"] = q
        if prefix is not None:
            params["prefix"] = prefix
        if limit is not None:
            params["limit"] = limit
        r = await self._client._request("GET", p, params=params)
        self._client._check_response(r)
        return MemoryEntriesResponse.model_validate(r.json())
