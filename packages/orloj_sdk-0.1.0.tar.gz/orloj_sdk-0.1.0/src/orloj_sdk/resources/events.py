from __future__ import annotations

from typing import Any

from orloj_sdk._streaming import AsyncServerEventContext, ServerEventStream


class Events:
    def __init__(self, client: Any) -> None:
        self._client = client

    def watch(
        self,
        *,
        since: int | None = None,
        source: str | None = None,
        event_type: str | None = None,
        kind: str | None = None,
        name: str | None = None,
        namespace: str | None = None,
    ) -> ServerEventStream:
        params: dict[str, str] = {}
        if since is not None:
            params["since"] = str(since)
        if source is not None:
            params["source"] = source
        if event_type is not None:
            params["type"] = event_type
        if kind is not None:
            params["kind"] = kind
        if name is not None:
            params["name"] = name
        if namespace is not None:
            params["namespace"] = namespace
        r, stack = self._client._open_stream("GET", "/v1/events/watch", params=params or None)
        return ServerEventStream(r, close_stack=stack)


class AsyncEvents:
    def __init__(self, client: Any) -> None:
        self._client = client

    def watch(
        self,
        *,
        since: int | None = None,
        source: str | None = None,
        event_type: str | None = None,
        kind: str | None = None,
        name: str | None = None,
        namespace: str | None = None,
    ) -> AsyncServerEventContext:
        params: dict[str, str] = {}
        if since is not None:
            params["since"] = str(since)
        if source is not None:
            params["source"] = source
        if event_type is not None:
            params["type"] = event_type
        if kind is not None:
            params["kind"] = kind
        if name is not None:
            params["name"] = name
        if namespace is not None:
            params["namespace"] = namespace
        return AsyncServerEventContext(self._client, params)
