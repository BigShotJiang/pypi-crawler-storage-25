from __future__ import annotations

from typing import Any, cast

from orloj_sdk.models.auth import TokenInfo, WhoAmI
from orloj_sdk.resources._base import _path_seg


class Auth:
    def __init__(self, client: Any) -> None:
        self._client = client

    def whoami(self) -> WhoAmI:
        r = self._client._request("GET", "/v1/auth/me")
        self._client._check_response(r)
        return WhoAmI.model_validate(r.json())

    def list_tokens(self) -> list[TokenInfo]:
        r = self._client._request("GET", "/v1/tokens")
        self._client._check_response(r)
        data = r.json()
        if not isinstance(data, list):
            return []
        return [TokenInfo.model_validate(x) for x in data]

    def create_token(self, name: str, role: str) -> TokenInfo:
        r = self._client._request("POST", "/v1/tokens", json={"name": name, "role": role})
        self._client._check_response(r)
        return TokenInfo.model_validate(r.json())

    def delete_token(self, name: str) -> None:
        p = f"/v1/tokens/{_path_seg(name)}"
        r = self._client._request("DELETE", p)
        self._client._check_response(r)

    def health(self) -> dict[str, Any]:
        r = self._client._request("GET", "/healthz")
        self._client._check_response(r)
        if not r.content:
            return {}
        return cast("dict[str, Any]", r.json())

    def capabilities(self) -> dict[str, Any]:
        r = self._client._request("GET", "/v1/capabilities")
        self._client._check_response(r)
        return cast("dict[str, Any]", r.json())

    def list_namespaces(self) -> list[str]:
        r = self._client._request("GET", "/v1/namespaces")
        self._client._check_response(r)
        data = r.json()
        if isinstance(data, list):
            return [str(x) for x in data]
        return []

    def get_auth_config(self) -> dict[str, Any]:
        r = self._client._request("GET", "/v1/auth/config")
        self._client._check_response(r)
        return cast("dict[str, Any]", r.json())

    def setup(self, username: str, password: str) -> dict[str, Any]:
        r = self._client._request(
            "POST",
            "/v1/auth/setup",
            json={"username": username, "password": password},
        )
        self._client._check_response(r)
        return cast("dict[str, Any]", r.json())

    def login(self, username: str, password: str) -> dict[str, Any]:
        r = self._client._request(
            "POST",
            "/v1/auth/login",
            json={"username": username, "password": password},
        )
        self._client._check_response(r)
        return cast("dict[str, Any]", r.json())

    def logout(self) -> None:
        r = self._client._request("POST", "/v1/auth/logout")
        self._client._check_response(r)

    def change_password(self, current_password: str, new_password: str) -> None:
        r = self._client._request(
            "POST",
            "/v1/auth/change-password",
            json={"currentPassword": current_password, "newPassword": new_password},
        )
        self._client._check_response(r)

    def list_users(self) -> list[dict[str, Any]]:
        r = self._client._request("GET", "/v1/auth/users")
        self._client._check_response(r)
        data = r.json()
        if isinstance(data, list):
            return list(data)
        return []

    def create_user(self, username: str, password: str, role: str) -> dict[str, Any]:
        r = self._client._request(
            "POST",
            "/v1/auth/users",
            json={"username": username, "password": password, "role": role},
        )
        self._client._check_response(r)
        return cast("dict[str, Any]", r.json())

    def delete_user(self, username: str) -> None:
        p = f"/v1/auth/users/{_path_seg(username)}"
        r = self._client._request("DELETE", p)
        self._client._check_response(r)

    def admin_reset_password(self, username: str, new_password: str) -> None:
        r = self._client._request(
            "POST",
            "/v1/auth/admin/reset-password",
            json={"username": username, "newPassword": new_password},
        )
        self._client._check_response(r)


class AsyncAuth:
    def __init__(self, client: Any) -> None:
        self._client = client

    async def whoami(self) -> WhoAmI:
        r = await self._client._request("GET", "/v1/auth/me")
        self._client._check_response(r)
        return WhoAmI.model_validate(r.json())

    async def list_tokens(self) -> list[TokenInfo]:
        r = await self._client._request("GET", "/v1/tokens")
        self._client._check_response(r)
        data = r.json()
        if not isinstance(data, list):
            return []
        return [TokenInfo.model_validate(x) for x in data]

    async def create_token(self, name: str, role: str) -> TokenInfo:
        r = await self._client._request("POST", "/v1/tokens", json={"name": name, "role": role})
        self._client._check_response(r)
        return TokenInfo.model_validate(r.json())

    async def delete_token(self, name: str) -> None:
        p = f"/v1/tokens/{_path_seg(name)}"
        r = await self._client._request("DELETE", p)
        self._client._check_response(r)

    async def health(self) -> dict[str, Any]:
        r = await self._client._request("GET", "/healthz")
        self._client._check_response(r)
        if not r.content:
            return {}
        return cast("dict[str, Any]", r.json())

    async def capabilities(self) -> dict[str, Any]:
        r = await self._client._request("GET", "/v1/capabilities")
        self._client._check_response(r)
        return cast("dict[str, Any]", r.json())

    async def list_namespaces(self) -> list[str]:
        r = await self._client._request("GET", "/v1/namespaces")
        self._client._check_response(r)
        data = r.json()
        if isinstance(data, list):
            return [str(x) for x in data]
        return []

    async def get_auth_config(self) -> dict[str, Any]:
        r = await self._client._request("GET", "/v1/auth/config")
        self._client._check_response(r)
        return cast("dict[str, Any]", r.json())

    async def setup(self, username: str, password: str) -> dict[str, Any]:
        r = await self._client._request(
            "POST",
            "/v1/auth/setup",
            json={"username": username, "password": password},
        )
        self._client._check_response(r)
        return cast("dict[str, Any]", r.json())

    async def login(self, username: str, password: str) -> dict[str, Any]:
        r = await self._client._request(
            "POST",
            "/v1/auth/login",
            json={"username": username, "password": password},
        )
        self._client._check_response(r)
        return cast("dict[str, Any]", r.json())

    async def logout(self) -> None:
        r = await self._client._request("POST", "/v1/auth/logout")
        self._client._check_response(r)

    async def change_password(self, current_password: str, new_password: str) -> None:
        r = await self._client._request(
            "POST",
            "/v1/auth/change-password",
            json={"currentPassword": current_password, "newPassword": new_password},
        )
        self._client._check_response(r)

    async def list_users(self) -> list[dict[str, Any]]:
        r = await self._client._request("GET", "/v1/auth/users")
        self._client._check_response(r)
        data = r.json()
        if isinstance(data, list):
            return list(data)
        return []

    async def create_user(self, username: str, password: str, role: str) -> dict[str, Any]:
        r = await self._client._request(
            "POST",
            "/v1/auth/users",
            json={"username": username, "password": password, "role": role},
        )
        self._client._check_response(r)
        return cast("dict[str, Any]", r.json())

    async def delete_user(self, username: str) -> None:
        p = f"/v1/auth/users/{_path_seg(username)}"
        r = await self._client._request("DELETE", p)
        self._client._check_response(r)

    async def admin_reset_password(self, username: str, new_password: str) -> None:
        r = await self._client._request(
            "POST",
            "/v1/auth/admin/reset-password",
            json={"username": username, "newPassword": new_password},
        )
        self._client._check_response(r)
