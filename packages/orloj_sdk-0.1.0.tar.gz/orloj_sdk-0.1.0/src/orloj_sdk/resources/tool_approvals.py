from __future__ import annotations

from typing import Any

from orloj_sdk.models.tool_approval import ToolApproval, ToolApprovalList
from orloj_sdk.resources._base import AsyncBaseResource, BaseResource, _path_seg


class ToolApprovals(BaseResource[ToolApproval, ToolApprovalList]):
    path = "/v1/tool-approvals"
    item_model = ToolApproval
    list_model = ToolApprovalList
    supports_status = False

    def approve(
        self,
        name: str,
        *,
        namespace: str | None = None,
        decided_by: str | None = None,
        reason: str | None = None,
    ) -> ToolApproval:
        p = f"{self.path}/{_path_seg(name)}/approve"
        body: dict[str, Any] | None = None
        if decided_by is not None or reason is not None:
            body = {}
            if decided_by is not None:
                body["decidedBy"] = decided_by
            if reason is not None:
                body["reason"] = reason
        r = self._client._request(
            "POST",
            p,
            params={"namespace": self._ns(namespace)},
            json=body,
        )
        self._client._check_response(r)
        return ToolApproval.model_validate(r.json())

    def deny(
        self,
        name: str,
        *,
        namespace: str | None = None,
        decided_by: str | None = None,
        reason: str | None = None,
    ) -> ToolApproval:
        p = f"{self.path}/{_path_seg(name)}/deny"
        body: dict[str, Any] | None = None
        if decided_by is not None or reason is not None:
            body = {}
            if decided_by is not None:
                body["decidedBy"] = decided_by
            if reason is not None:
                body["reason"] = reason
        r = self._client._request(
            "POST",
            p,
            params={"namespace": self._ns(namespace)},
            json=body,
        )
        self._client._check_response(r)
        return ToolApproval.model_validate(r.json())


class AsyncToolApprovals(AsyncBaseResource[ToolApproval, ToolApprovalList]):
    path = "/v1/tool-approvals"
    item_model = ToolApproval
    list_model = ToolApprovalList
    supports_status = False

    async def approve(
        self,
        name: str,
        *,
        namespace: str | None = None,
        decided_by: str | None = None,
        reason: str | None = None,
    ) -> ToolApproval:
        p = f"{self.path}/{_path_seg(name)}/approve"
        body: dict[str, Any] | None = None
        if decided_by is not None or reason is not None:
            body = {}
            if decided_by is not None:
                body["decidedBy"] = decided_by
            if reason is not None:
                body["reason"] = reason
        r = await self._client._request(
            "POST",
            p,
            params={"namespace": self._ns(namespace)},
            json=body,
        )
        self._client._check_response(r)
        return ToolApproval.model_validate(r.json())

    async def deny(
        self,
        name: str,
        *,
        namespace: str | None = None,
        decided_by: str | None = None,
        reason: str | None = None,
    ) -> ToolApproval:
        p = f"{self.path}/{_path_seg(name)}/deny"
        body: dict[str, Any] | None = None
        if decided_by is not None or reason is not None:
            body = {}
            if decided_by is not None:
                body["decidedBy"] = decided_by
            if reason is not None:
                body["reason"] = reason
        r = await self._client._request(
            "POST",
            p,
            params={"namespace": self._ns(namespace)},
            json=body,
        )
        self._client._check_response(r)
        return ToolApproval.model_validate(r.json())
