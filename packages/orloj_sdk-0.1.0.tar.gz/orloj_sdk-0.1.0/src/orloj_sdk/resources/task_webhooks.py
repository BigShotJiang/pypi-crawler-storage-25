from __future__ import annotations

from orloj_sdk._streaming import AsyncWatchContext, WatchStream
from orloj_sdk.models.task_webhook import TaskWebhook, TaskWebhookList
from orloj_sdk.resources._base import AsyncBaseResource, BaseResource, _path_seg


class TaskWebhooks(BaseResource[TaskWebhook, TaskWebhookList]):
    path = "/v1/task-webhooks"
    item_model = TaskWebhook
    list_model = TaskWebhookList

    def watch(
        self,
        *,
        namespace: str | None = None,
        name: str | None = None,
        resource_version: str | None = None,
    ) -> WatchStream[TaskWebhook]:
        params: dict[str, str] = {"namespace": self._ns(namespace)}
        if name is not None:
            params["name"] = name
        if resource_version is not None:
            params["resourceVersion"] = resource_version
        r, stack = self._client._open_stream("GET", f"{self.path}/watch", params=params)
        return WatchStream(r, TaskWebhook, close_stack=stack)

    def deliver(self, delivery_id: str) -> None:
        p = f"/v1/webhook-deliveries/{_path_seg(delivery_id)}"
        r = self._client._request("POST", p)
        self._client._check_response(r)


class AsyncTaskWebhooks(AsyncBaseResource[TaskWebhook, TaskWebhookList]):
    path = "/v1/task-webhooks"
    item_model = TaskWebhook
    list_model = TaskWebhookList

    def watch(
        self,
        *,
        namespace: str | None = None,
        name: str | None = None,
        resource_version: str | None = None,
    ) -> AsyncWatchContext[TaskWebhook]:
        params: dict[str, str] = {"namespace": self._ns(namespace)}
        if name is not None:
            params["name"] = name
        if resource_version is not None:
            params["resourceVersion"] = resource_version
        return AsyncWatchContext(self._client, f"{self.path}/watch", params, TaskWebhook)

    async def deliver(self, delivery_id: str) -> None:
        p = f"/v1/webhook-deliveries/{_path_seg(delivery_id)}"
        r = await self._client._request("POST", p)
        self._client._check_response(r)
