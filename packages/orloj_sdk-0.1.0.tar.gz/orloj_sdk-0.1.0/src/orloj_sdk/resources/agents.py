from __future__ import annotations

from orloj_sdk._streaming import AsyncWatchContext, WatchStream
from orloj_sdk.models.agent import Agent, AgentList
from orloj_sdk.models.auth import NamedLogsResponse
from orloj_sdk.resources._base import AsyncBaseResource, BaseResource, _path_seg


class Agents(BaseResource[Agent, AgentList]):
    path = "/v1/agents"
    item_model = Agent
    list_model = AgentList

    def get_logs(self, name: str, *, namespace: str | None = None) -> NamedLogsResponse:
        p = f"{self.path}/{_path_seg(name)}/logs"
        r = self._client._request("GET", p, params={"namespace": self._ns(namespace)})
        self._client._check_response(r)
        return NamedLogsResponse.model_validate(r.json())

    def watch(
        self,
        *,
        namespace: str | None = None,
        name: str | None = None,
        resource_version: str | None = None,
    ) -> WatchStream[Agent]:
        params: dict[str, str] = {"namespace": self._ns(namespace)}
        if name is not None:
            params["name"] = name
        if resource_version is not None:
            params["resourceVersion"] = resource_version
        r, stack = self._client._open_stream("GET", f"{self.path}/watch", params=params)
        return WatchStream(r, Agent, close_stack=stack)


class AsyncAgents(AsyncBaseResource[Agent, AgentList]):
    path = "/v1/agents"
    item_model = Agent
    list_model = AgentList

    async def get_logs(self, name: str, *, namespace: str | None = None) -> NamedLogsResponse:
        p = f"{self.path}/{_path_seg(name)}/logs"
        r = await self._client._request("GET", p, params={"namespace": self._ns(namespace)})
        self._client._check_response(r)
        return NamedLogsResponse.model_validate(r.json())

    def watch(
        self,
        *,
        namespace: str | None = None,
        name: str | None = None,
        resource_version: str | None = None,
    ) -> AsyncWatchContext[Agent]:
        params: dict[str, str] = {"namespace": self._ns(namespace)}
        if name is not None:
            params["name"] = name
        if resource_version is not None:
            params["resourceVersion"] = resource_version
        return AsyncWatchContext(self._client, f"{self.path}/watch", params, Agent)
