from __future__ import annotations

from orloj_sdk.models.agent_role import AgentRole, AgentRoleList
from orloj_sdk.resources._base import AsyncBaseResource, BaseResource


class AgentRoles(BaseResource[AgentRole, AgentRoleList]):
    path = "/v1/agent-roles"
    item_model = AgentRole
    list_model = AgentRoleList
    supports_status = False


class AsyncAgentRoles(AsyncBaseResource[AgentRole, AgentRoleList]):
    path = "/v1/agent-roles"
    item_model = AgentRole
    list_model = AgentRoleList
    supports_status = False
