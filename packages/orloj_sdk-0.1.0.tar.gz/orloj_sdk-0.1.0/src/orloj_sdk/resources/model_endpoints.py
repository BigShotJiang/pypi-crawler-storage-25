from __future__ import annotations

from orloj_sdk.models.model_endpoint import ModelEndpoint, ModelEndpointList
from orloj_sdk.resources._base import AsyncBaseResource, BaseResource


class ModelEndpoints(BaseResource[ModelEndpoint, ModelEndpointList]):
    path = "/v1/model-endpoints"
    item_model = ModelEndpoint
    list_model = ModelEndpointList


class AsyncModelEndpoints(AsyncBaseResource[ModelEndpoint, ModelEndpointList]):
    path = "/v1/model-endpoints"
    item_model = ModelEndpoint
    list_model = ModelEndpointList
