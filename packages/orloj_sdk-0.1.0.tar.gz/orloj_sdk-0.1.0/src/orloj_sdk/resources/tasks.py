from __future__ import annotations

from typing import Any

from orloj_sdk._streaming import AsyncWatchContext, WatchStream
from orloj_sdk.models.auth import NamedLogsResponse
from orloj_sdk.models.task import Task, TaskList
from orloj_sdk.resources._base import AsyncBaseResource, BaseResource, _path_seg


class Tasks(BaseResource[Task, TaskList]):
    path = "/v1/tasks"
    item_model = Task
    list_model = TaskList

    def get_logs(self, name: str, *, namespace: str | None = None) -> NamedLogsResponse:
        p = f"{self.path}/{_path_seg(name)}/logs"
        r = self._client._request("GET", p, params={"namespace": self._ns(namespace)})
        self._client._check_response(r)
        return NamedLogsResponse.model_validate(r.json())

    def cancel(
        self,
        name: str,
        *,
        namespace: str | None = None,
        reason: str | None = None,
    ) -> None:
        p = f"{self.path}/{_path_seg(name)}/cancel"
        body: dict[str, Any] | None = {"reason": reason} if reason is not None else None
        r = self._client._request(
            "POST",
            p,
            params={"namespace": self._ns(namespace)},
            json=body,
        )
        self._client._check_response(r)

    def retry(
        self,
        name: str,
        *,
        namespace: str | None = None,
        overrides: dict[str, str] | None = None,
    ) -> Task:
        p = f"{self.path}/{_path_seg(name)}/retry"
        r = self._client._request(
            "POST",
            p,
            params={"namespace": self._ns(namespace)},
            json=overrides,
        )
        self._client._check_response(r)
        return Task.model_validate(r.json())

    def watch(
        self,
        *,
        namespace: str | None = None,
        name: str | None = None,
        resource_version: str | None = None,
    ) -> WatchStream[Task]:
        params: dict[str, str] = {"namespace": self._ns(namespace)}
        if name is not None:
            params["name"] = name
        if resource_version is not None:
            params["resourceVersion"] = resource_version
        r, stack = self._client._open_stream("GET", f"{self.path}/watch", params=params)
        return WatchStream(r, Task, close_stack=stack)


class AsyncTasks(AsyncBaseResource[Task, TaskList]):
    path = "/v1/tasks"
    item_model = Task
    list_model = TaskList

    async def get_logs(self, name: str, *, namespace: str | None = None) -> NamedLogsResponse:
        p = f"{self.path}/{_path_seg(name)}/logs"
        r = await self._client._request("GET", p, params={"namespace": self._ns(namespace)})
        self._client._check_response(r)
        return NamedLogsResponse.model_validate(r.json())

    async def cancel(
        self,
        name: str,
        *,
        namespace: str | None = None,
        reason: str | None = None,
    ) -> None:
        p = f"{self.path}/{_path_seg(name)}/cancel"
        body: dict[str, Any] | None = {"reason": reason} if reason is not None else None
        r = await self._client._request(
            "POST",
            p,
            params={"namespace": self._ns(namespace)},
            json=body,
        )
        self._client._check_response(r)

    async def retry(
        self,
        name: str,
        *,
        namespace: str | None = None,
        overrides: dict[str, str] | None = None,
    ) -> Task:
        p = f"{self.path}/{_path_seg(name)}/retry"
        r = await self._client._request(
            "POST",
            p,
            params={"namespace": self._ns(namespace)},
            json=overrides,
        )
        self._client._check_response(r)
        return Task.model_validate(r.json())

    def watch(
        self,
        *,
        namespace: str | None = None,
        name: str | None = None,
        resource_version: str | None = None,
    ) -> AsyncWatchContext[Task]:
        params: dict[str, str] = {"namespace": self._ns(namespace)}
        if name is not None:
            params["name"] = name
        if resource_version is not None:
            params["resourceVersion"] = resource_version
        return AsyncWatchContext(self._client, f"{self.path}/watch", params, Task)
