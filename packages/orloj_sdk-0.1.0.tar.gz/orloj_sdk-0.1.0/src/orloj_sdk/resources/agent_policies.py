from __future__ import annotations

from orloj_sdk.models.agent_policy import AgentPolicy, AgentPolicyList
from orloj_sdk.resources._base import AsyncBaseResource, BaseResource


class AgentPolicies(BaseResource[AgentPolicy, AgentPolicyList]):
    path = "/v1/agent-policies"
    item_model = AgentPolicy
    list_model = AgentPolicyList
    supports_status = False


class AsyncAgentPolicies(AsyncBaseResource[AgentPolicy, AgentPolicyList]):
    path = "/v1/agent-policies"
    item_model = AgentPolicy
    list_model = AgentPolicyList
    supports_status = False
