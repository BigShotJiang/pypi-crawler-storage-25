from __future__ import annotations

from collections.abc import AsyncIterator, Iterator
from typing import Any, ClassVar, Generic, Protocol, TypeVar, cast
from urllib.parse import quote

from orloj_sdk.models._base import ListMeta, OrlojModel, StatusEnvelope, dump_json_body

T = TypeVar("T", bound=OrlojModel)
TList = TypeVar("TList", bound=OrlojModel)


class _ListPage(Protocol[T]):
    """Structural type for *List models (items + pagination metadata)."""

    items: list[T]
    metadata: ListMeta | None


def _path_seg(name: str) -> str:
    return quote(name, safe="")


def _list_query_params(
    namespace: str,
    *,
    limit: int | None,
    after: str | None,
    label_selector: str | None,
) -> dict[str, str | int]:
    params: dict[str, str | int] = {"namespace": namespace}
    if limit is not None:
        params["limit"] = limit
    if after:
        params["after"] = after
    if label_selector:
        params["labelSelector"] = label_selector
    return params


def _if_match_headers(body: OrlojModel | None, if_match: str | None) -> dict[str, str]:
    headers: dict[str, str] = {}
    if if_match is not None:
        headers["If-Match"] = if_match
        return headers
    if body is not None:
        md = getattr(body, "metadata", None)
        if md is not None:
            rv = getattr(md, "resource_version", None)
            if rv:
                headers["If-Match"] = str(rv)
    return headers


class BaseResource(Generic[T, TList]):
    path: ClassVar[str]
    item_model: ClassVar[type[T]]
    list_model: ClassVar[type[TList]]
    supports_status: ClassVar[bool] = True

    def __init__(self, client: Any) -> None:
        self._client = client

    def _ns(self, namespace: str | None) -> str:
        return namespace if namespace is not None else self._client._namespace

    def list(
        self,
        *,
        namespace: str | None = None,
        limit: int | None = None,
        after: str | None = None,
        label_selector: str | None = None,
    ) -> TList:
        params = _list_query_params(
            self._ns(namespace),
            limit=limit,
            after=after,
            label_selector=label_selector,
        )
        r = self._client._request("GET", self.path, params=params)
        self._client._check_response(r)
        return self.list_model.model_validate(r.json())

    def list_all(
        self,
        *,
        namespace: str | None = None,
        label_selector: str | None = None,
    ) -> Iterator[T]:
        cursor: str | None = None
        while True:
            page = self.list(
                namespace=namespace,
                limit=100,
                after=cursor,
                label_selector=label_selector,
            )
            pl = cast("_ListPage[T]", page)
            yield from pl.items
            cont = pl.metadata.continue_ if pl.metadata else None
            if not cont:
                break
            cursor = cont

    def get(self, name: str, *, namespace: str | None = None) -> T:
        p = f"{self.path}/{_path_seg(name)}"
        r = self._client._request("GET", p, params={"namespace": self._ns(namespace)})
        self._client._check_response(r)
        return self.item_model.model_validate(r.json())

    def create(self, body: T, *, namespace: str | None = None) -> T:
        r = self._client._request(
            "POST",
            self.path,
            params={"namespace": self._ns(namespace)},
            json=dump_json_body(body),
        )
        self._client._check_response(r)
        return self.item_model.model_validate(r.json())

    def update(
        self,
        name: str,
        body: T,
        *,
        namespace: str | None = None,
        if_match: str | None = None,
    ) -> T:
        p = f"{self.path}/{_path_seg(name)}"
        extra = _if_match_headers(body, if_match)
        r = self._client._request(
            "PUT",
            p,
            params={"namespace": self._ns(namespace)},
            json=dump_json_body(body),
            headers=extra or None,
        )
        self._client._check_response(r)
        return self.item_model.model_validate(r.json())

    def delete(self, name: str, *, namespace: str | None = None) -> None:
        p = f"{self.path}/{_path_seg(name)}"
        r = self._client._request(
            "DELETE",
            p,
            params={"namespace": self._ns(namespace)},
        )
        self._client._check_response(r)

    def get_status(self, name: str, *, namespace: str | None = None) -> StatusEnvelope:
        if not self.supports_status:
            raise TypeError(f"{type(self).__name__} does not support status endpoints")
        p = f"{self.path}/{_path_seg(name)}/status"
        r = self._client._request("GET", p, params={"namespace": self._ns(namespace)})
        self._client._check_response(r)
        return StatusEnvelope.model_validate(r.json())

    def update_status(
        self,
        name: str,
        body: StatusEnvelope,
        *,
        namespace: str | None = None,
        if_match: str | None = None,
    ) -> StatusEnvelope:
        if not self.supports_status:
            raise TypeError(f"{type(self).__name__} does not support status endpoints")
        p = f"{self.path}/{_path_seg(name)}/status"
        extra = _if_match_headers(body, if_match)
        r = self._client._request(
            "PUT",
            p,
            params={"namespace": self._ns(namespace)},
            json=dump_json_body(body),
            headers=extra or None,
        )
        self._client._check_response(r)
        return StatusEnvelope.model_validate(r.json())


class AsyncBaseResource(Generic[T, TList]):
    path: ClassVar[str]
    item_model: ClassVar[type[T]]
    list_model: ClassVar[type[TList]]
    supports_status: ClassVar[bool] = True

    def __init__(self, client: Any) -> None:
        self._client = client

    def _ns(self, namespace: str | None) -> str:
        return namespace if namespace is not None else self._client._namespace

    async def list(
        self,
        *,
        namespace: str | None = None,
        limit: int | None = None,
        after: str | None = None,
        label_selector: str | None = None,
    ) -> TList:
        params = _list_query_params(
            self._ns(namespace),
            limit=limit,
            after=after,
            label_selector=label_selector,
        )
        r = await self._client._request("GET", self.path, params=params)
        self._client._check_response(r)
        return self.list_model.model_validate(r.json())

    async def list_all(
        self,
        *,
        namespace: str | None = None,
        label_selector: str | None = None,
    ) -> AsyncIterator[T]:
        cursor: str | None = None
        while True:
            page = await self.list(
                namespace=namespace,
                limit=100,
                after=cursor,
                label_selector=label_selector,
            )
            pl = cast("_ListPage[T]", page)
            for item in pl.items:
                yield item
            cont = pl.metadata.continue_ if pl.metadata else None
            if not cont:
                break
            cursor = cont

    async def get(self, name: str, *, namespace: str | None = None) -> T:
        p = f"{self.path}/{_path_seg(name)}"
        r = await self._client._request("GET", p, params={"namespace": self._ns(namespace)})
        self._client._check_response(r)
        return self.item_model.model_validate(r.json())

    async def create(self, body: T, *, namespace: str | None = None) -> T:
        r = await self._client._request(
            "POST",
            self.path,
            params={"namespace": self._ns(namespace)},
            json=dump_json_body(body),
        )
        self._client._check_response(r)
        return self.item_model.model_validate(r.json())

    async def update(
        self,
        name: str,
        body: T,
        *,
        namespace: str | None = None,
        if_match: str | None = None,
    ) -> T:
        p = f"{self.path}/{_path_seg(name)}"
        extra = _if_match_headers(body, if_match)
        r = await self._client._request(
            "PUT",
            p,
            params={"namespace": self._ns(namespace)},
            json=dump_json_body(body),
            headers=extra or None,
        )
        self._client._check_response(r)
        return self.item_model.model_validate(r.json())

    async def delete(self, name: str, *, namespace: str | None = None) -> None:
        p = f"{self.path}/{_path_seg(name)}"
        r = await self._client._request(
            "DELETE",
            p,
            params={"namespace": self._ns(namespace)},
        )
        self._client._check_response(r)

    async def get_status(self, name: str, *, namespace: str | None = None) -> StatusEnvelope:
        if not self.supports_status:
            raise TypeError(f"{type(self).__name__} does not support status endpoints")
        p = f"{self.path}/{_path_seg(name)}/status"
        r = await self._client._request("GET", p, params={"namespace": self._ns(namespace)})
        self._client._check_response(r)
        return StatusEnvelope.model_validate(r.json())

    async def update_status(
        self,
        name: str,
        body: StatusEnvelope,
        *,
        namespace: str | None = None,
        if_match: str | None = None,
    ) -> StatusEnvelope:
        if not self.supports_status:
            raise TypeError(f"{type(self).__name__} does not support status endpoints")
        p = f"{self.path}/{_path_seg(name)}/status"
        extra = _if_match_headers(body, if_match)
        r = await self._client._request(
            "PUT",
            p,
            params={"namespace": self._ns(namespace)},
            json=dump_json_body(body),
            headers=extra or None,
        )
        self._client._check_response(r)
        return StatusEnvelope.model_validate(r.json())
