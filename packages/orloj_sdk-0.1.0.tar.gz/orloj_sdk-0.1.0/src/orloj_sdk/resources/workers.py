from __future__ import annotations

from orloj_sdk.models.worker import Worker, WorkerList
from orloj_sdk.resources._base import AsyncBaseResource, BaseResource


class Workers(BaseResource[Worker, WorkerList]):
    path = "/v1/workers"
    item_model = Worker
    list_model = WorkerList


class AsyncWorkers(AsyncBaseResource[Worker, WorkerList]):
    path = "/v1/workers"
    item_model = Worker
    list_model = WorkerList
