from __future__ import annotations

from orloj_sdk.models.agent_system import AgentSystem, AgentSystemList
from orloj_sdk.resources._base import AsyncBaseResource, BaseResource


class AgentSystems(BaseResource[AgentSystem, AgentSystemList]):
    path = "/v1/agent-systems"
    item_model = AgentSystem
    list_model = AgentSystemList


class AsyncAgentSystems(AsyncBaseResource[AgentSystem, AgentSystemList]):
    path = "/v1/agent-systems"
    item_model = AgentSystem
    list_model = AgentSystemList
