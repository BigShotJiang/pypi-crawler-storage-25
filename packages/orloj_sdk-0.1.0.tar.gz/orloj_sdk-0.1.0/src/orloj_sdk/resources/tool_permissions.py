from __future__ import annotations

from orloj_sdk.models.tool_permission import ToolPermission, ToolPermissionList
from orloj_sdk.resources._base import AsyncBaseResource, BaseResource


class ToolPermissions(BaseResource[ToolPermission, ToolPermissionList]):
    path = "/v1/tool-permissions"
    item_model = ToolPermission
    list_model = ToolPermissionList
    supports_status = False


class AsyncToolPermissions(AsyncBaseResource[ToolPermission, ToolPermissionList]):
    path = "/v1/tool-permissions"
    item_model = ToolPermission
    list_model = ToolPermissionList
    supports_status = False
