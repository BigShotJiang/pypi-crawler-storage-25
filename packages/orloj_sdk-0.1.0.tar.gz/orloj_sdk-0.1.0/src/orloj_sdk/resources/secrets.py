from __future__ import annotations

from orloj_sdk.models.secret import Secret, SecretList
from orloj_sdk.resources._base import AsyncBaseResource, BaseResource


class Secrets(BaseResource[Secret, SecretList]):
    path = "/v1/secrets"
    item_model = Secret
    list_model = SecretList


class AsyncSecrets(AsyncBaseResource[Secret, SecretList]):
    path = "/v1/secrets"
    item_model = Secret
    list_model = SecretList
