from __future__ import annotations

from orloj_sdk.models.mcp_server import McpServer, McpServerList
from orloj_sdk.resources._base import AsyncBaseResource, BaseResource


class McpServers(BaseResource[McpServer, McpServerList]):
    path = "/v1/mcp-servers"
    item_model = McpServer
    list_model = McpServerList


class AsyncMcpServers(AsyncBaseResource[McpServer, McpServerList]):
    path = "/v1/mcp-servers"
    item_model = McpServer
    list_model = McpServerList
