from __future__ import annotations

from orloj_sdk.models.tool import Tool, ToolList
from orloj_sdk.resources._base import AsyncBaseResource, BaseResource


class Tools(BaseResource[Tool, ToolList]):
    path = "/v1/tools"
    item_model = Tool
    list_model = ToolList


class AsyncTools(AsyncBaseResource[Tool, ToolList]):
    path = "/v1/tools"
    item_model = Tool
    list_model = ToolList
