from __future__ import annotations

from orloj_sdk._streaming import AsyncWatchContext, WatchStream
from orloj_sdk.models.task_schedule import TaskSchedule, TaskScheduleList
from orloj_sdk.resources._base import AsyncBaseResource, BaseResource


class TaskSchedules(BaseResource[TaskSchedule, TaskScheduleList]):
    path = "/v1/task-schedules"
    item_model = TaskSchedule
    list_model = TaskScheduleList

    def watch(
        self,
        *,
        namespace: str | None = None,
        name: str | None = None,
        resource_version: str | None = None,
    ) -> WatchStream[TaskSchedule]:
        params: dict[str, str] = {"namespace": self._ns(namespace)}
        if name is not None:
            params["name"] = name
        if resource_version is not None:
            params["resourceVersion"] = resource_version
        r, stack = self._client._open_stream("GET", f"{self.path}/watch", params=params)
        return WatchStream(r, TaskSchedule, close_stack=stack)


class AsyncTaskSchedules(AsyncBaseResource[TaskSchedule, TaskScheduleList]):
    path = "/v1/task-schedules"
    item_model = TaskSchedule
    list_model = TaskScheduleList

    def watch(
        self,
        *,
        namespace: str | None = None,
        name: str | None = None,
        resource_version: str | None = None,
    ) -> AsyncWatchContext[TaskSchedule]:
        params: dict[str, str] = {"namespace": self._ns(namespace)}
        if name is not None:
            params["name"] = name
        if resource_version is not None:
            params["resourceVersion"] = resource_version
        return AsyncWatchContext(self._client, f"{self.path}/watch", params, TaskSchedule)
