from __future__ import annotations

import inspect
import time
from collections.abc import Awaitable, Callable
from typing import Any

import httpx

from orloj_sdk._errors import OrlojConnectionError, OrlojTimeoutError

# Exponential backoff after attempt 0: 0.5s, 1s, 2s, ...
_BACKOFF_BASE_S = 0.5


def backoff_seconds(attempt_index: int) -> float:
    return float(_BACKOFF_BASE_S * (2**attempt_index))


def should_retry_status(status_code: int) -> bool:
    return status_code in (429, 503)


def sync_request_with_retries(
    do_request: Callable[[], httpx.Response],
    *,
    max_retries: int,
) -> httpx.Response:
    """Execute a sync request with optional retries for transient failures."""
    for attempt in range(max_retries + 1):
        try:
            resp = do_request()
            if should_retry_status(resp.status_code) and attempt < max_retries:
                time.sleep(backoff_seconds(attempt))
                continue
            return resp
        except (httpx.ConnectError, httpx.ReadError, httpx.RemoteProtocolError) as e:
            if attempt < max_retries:
                time.sleep(backoff_seconds(attempt))
                continue
            raise OrlojConnectionError(str(e)) from e
        except httpx.TimeoutException as e:
            raise OrlojTimeoutError(str(e)) from e
    raise RuntimeError("sync_request_with_retries: unreachable")


async def async_request_with_retries(
    do_request: Callable[[], Awaitable[httpx.Response]],
    *,
    max_retries: int,
) -> httpx.Response:
    for attempt in range(max_retries + 1):
        try:
            resp = await do_request()
            if should_retry_status(resp.status_code) and attempt < max_retries:
                await _async_sleep(backoff_seconds(attempt))
                continue
            return resp
        except (httpx.ConnectError, httpx.ReadError, httpx.RemoteProtocolError) as e:
            if attempt < max_retries:
                await _async_sleep(backoff_seconds(attempt))
                continue
            raise OrlojConnectionError(str(e)) from e
        except httpx.TimeoutException as e:
            raise OrlojTimeoutError(str(e)) from e
    raise RuntimeError("async_request_with_retries: unreachable")


async def _async_sleep(seconds: float) -> None:
    import asyncio

    await asyncio.sleep(seconds)


async def async_exit_cm(cm: Any) -> None:
    """Call async or sync __aexit__ on a context manager (httpx stream)."""
    result = cm.__aexit__(None, None, None)
    if inspect.isawaitable(result):
        await result
