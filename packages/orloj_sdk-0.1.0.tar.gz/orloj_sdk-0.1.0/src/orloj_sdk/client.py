from __future__ import annotations

import time
from contextlib import ExitStack
from typing import Any

import httpx

from orloj_sdk._base_client import (
    build_default_headers,
    check_response,
    resolve_api_token,
    resolve_base_url,
    timeout_for_request,
)
from orloj_sdk._errors import OrlojConnectionError, OrlojTimeoutError
from orloj_sdk._transport import (
    async_exit_cm,
    async_request_with_retries,
    backoff_seconds,
    should_retry_status,
    sync_request_with_retries,
)
from orloj_sdk.resources.agent_policies import AgentPolicies, AsyncAgentPolicies
from orloj_sdk.resources.agent_roles import AgentRoles, AsyncAgentRoles
from orloj_sdk.resources.agent_systems import AgentSystems, AsyncAgentSystems
from orloj_sdk.resources.agents import Agents, AsyncAgents
from orloj_sdk.resources.auth import AsyncAuth, Auth
from orloj_sdk.resources.events import AsyncEvents, Events
from orloj_sdk.resources.mcp_servers import AsyncMcpServers, McpServers
from orloj_sdk.resources.memories import AsyncMemories, Memories
from orloj_sdk.resources.model_endpoints import AsyncModelEndpoints, ModelEndpoints
from orloj_sdk.resources.secrets import AsyncSecrets, Secrets
from orloj_sdk.resources.task_schedules import AsyncTaskSchedules, TaskSchedules
from orloj_sdk.resources.task_webhooks import AsyncTaskWebhooks, TaskWebhooks
from orloj_sdk.resources.tasks import AsyncTasks, Tasks
from orloj_sdk.resources.tool_approvals import AsyncToolApprovals, ToolApprovals
from orloj_sdk.resources.tool_permissions import AsyncToolPermissions, ToolPermissions
from orloj_sdk.resources.tools import AsyncTools, Tools
from orloj_sdk.resources.workers import AsyncWorkers, Workers


def _effective_timeout(
    method: str,
    stream: bool,
    override: float | httpx.Timeout | None,
    user_default: float | httpx.Timeout | None,
) -> httpx.Timeout:
    if override is not None:
        if isinstance(override, httpx.Timeout):
            return override
        return httpx.Timeout(float(override))
    if user_default is not None:
        if isinstance(user_default, httpx.Timeout):
            return user_default
        return httpx.Timeout(float(user_default))
    return timeout_for_request(method, stream)


class OrlojClient:
    def __init__(
        self,
        base_url: str | None = None,
        api_token: str | None = None,
        timeout: float | httpx.Timeout | None = None,
        namespace: str = "default",
        max_retries: int = 0,
    ) -> None:
        self._base_url = resolve_base_url(base_url)
        self._token = resolve_api_token(api_token)
        self._namespace = namespace
        self._max_retries = max_retries
        self._timeout_user = timeout
        self._headers = build_default_headers(self._token)
        self._client = httpx.Client(
            base_url=self._base_url,
            headers=self._headers,
            timeout=httpx.Timeout(30.0),
        )
        self.agents = Agents(self)
        self.agent_systems = AgentSystems(self)
        self.model_endpoints = ModelEndpoints(self)
        self.tools = Tools(self)
        self.secrets = Secrets(self)
        self.memories = Memories(self)
        self.agent_policies = AgentPolicies(self)
        self.agent_roles = AgentRoles(self)
        self.tool_permissions = ToolPermissions(self)
        self.tool_approvals = ToolApprovals(self)
        self.tasks = Tasks(self)
        self.task_schedules = TaskSchedules(self)
        self.task_webhooks = TaskWebhooks(self)
        self.workers = Workers(self)
        self.mcp_servers = McpServers(self)
        self.auth = Auth(self)
        self.events = Events(self)

    def _merge_headers(self, extra: dict[str, str] | None) -> dict[str, str]:
        if not extra:
            return dict(self._headers)
        merged = dict(self._headers)
        merged.update(extra)
        return merged

    def _request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json: Any | None = None,
        headers: dict[str, str] | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> httpx.Response:
        merged_headers = self._merge_headers(headers)
        eff = _effective_timeout(method, False, timeout, self._timeout_user)

        def do_request() -> httpx.Response:
            return self._client.request(
                method,
                path,
                params=params,
                json=json,
                headers=merged_headers,
                timeout=eff,
            )

        r = sync_request_with_retries(
            do_request,
            max_retries=self._max_retries,
        )
        check_response(r)
        return r

    def _open_stream(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json: Any | None = None,
        headers: dict[str, str] | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> tuple[httpx.Response, ExitStack]:
        merged_headers = self._merge_headers(headers)
        eff = _effective_timeout(method, True, timeout, self._timeout_user)

        for attempt in range(self._max_retries + 1):
            stack = ExitStack()
            try:
                cm = self._client.stream(
                    method,
                    path,
                    params=params,
                    json=json,
                    headers=merged_headers,
                    timeout=eff,
                )
                resp = stack.enter_context(cm)
                if resp.is_success:
                    return resp, stack
                if should_retry_status(resp.status_code) and attempt < self._max_retries:
                    stack.close()
                    time.sleep(backoff_seconds(attempt))
                    continue
                stack.close()
                check_response(resp)
            except (httpx.ConnectError, httpx.ReadError, httpx.RemoteProtocolError) as e:
                stack.close()
                if attempt < self._max_retries:
                    time.sleep(backoff_seconds(attempt))
                    continue
                raise OrlojConnectionError(str(e)) from e
            except httpx.TimeoutException as e:
                stack.close()
                raise OrlojTimeoutError(str(e)) from e
        raise RuntimeError("_open_stream: unreachable")

    @staticmethod
    def _check_response(response: httpx.Response) -> None:
        check_response(response)

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> OrlojClient:
        return self

    def __exit__(self, *args: object) -> None:
        self.close()


class AsyncOrlojClient:
    def __init__(
        self,
        base_url: str | None = None,
        api_token: str | None = None,
        timeout: float | httpx.Timeout | None = None,
        namespace: str = "default",
        max_retries: int = 0,
    ) -> None:
        self._base_url = resolve_base_url(base_url)
        self._token = resolve_api_token(api_token)
        self._namespace = namespace
        self._max_retries = max_retries
        self._timeout_user = timeout
        self._headers = build_default_headers(self._token)
        self._client = httpx.AsyncClient(
            base_url=self._base_url,
            headers=self._headers,
            timeout=httpx.Timeout(30.0),
        )
        self.agents = AsyncAgents(self)
        self.agent_systems = AsyncAgentSystems(self)
        self.model_endpoints = AsyncModelEndpoints(self)
        self.tools = AsyncTools(self)
        self.secrets = AsyncSecrets(self)
        self.memories = AsyncMemories(self)
        self.agent_policies = AsyncAgentPolicies(self)
        self.agent_roles = AsyncAgentRoles(self)
        self.tool_permissions = AsyncToolPermissions(self)
        self.tool_approvals = AsyncToolApprovals(self)
        self.tasks = AsyncTasks(self)
        self.task_schedules = AsyncTaskSchedules(self)
        self.task_webhooks = AsyncTaskWebhooks(self)
        self.workers = AsyncWorkers(self)
        self.mcp_servers = AsyncMcpServers(self)
        self.auth = AsyncAuth(self)
        self.events = AsyncEvents(self)

    def _merge_headers(self, extra: dict[str, str] | None) -> dict[str, str]:
        if not extra:
            return dict(self._headers)
        merged = dict(self._headers)
        merged.update(extra)
        return merged

    async def _request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json: Any | None = None,
        headers: dict[str, str] | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> httpx.Response:
        merged_headers = self._merge_headers(headers)
        eff = _effective_timeout(method, False, timeout, self._timeout_user)

        async def do_request() -> httpx.Response:
            return await self._client.request(
                method,
                path,
                params=params,
                json=json,
                headers=merged_headers,
                timeout=eff,
            )

        r = await async_request_with_retries(
            do_request,
            max_retries=self._max_retries,
        )
        check_response(r)
        return r

    async def _open_stream_async(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json: Any | None = None,
        headers: dict[str, str] | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> tuple[httpx.Response, Any]:
        import asyncio

        merged_headers = self._merge_headers(headers)
        eff = _effective_timeout(method, True, timeout, self._timeout_user)

        for attempt in range(self._max_retries + 1):
            cm = self._client.stream(
                method,
                path,
                params=params,
                json=json,
                headers=merged_headers,
                timeout=eff,
            )
            try:
                resp = await cm.__aenter__()
            except (httpx.ConnectError, httpx.ReadError, httpx.RemoteProtocolError) as e:
                if attempt < self._max_retries:
                    await asyncio.sleep(backoff_seconds(attempt))
                    continue
                raise OrlojConnectionError(str(e)) from e
            except httpx.TimeoutException as e:
                raise OrlojTimeoutError(str(e)) from e
            if resp.is_success:
                return resp, cm
            if should_retry_status(resp.status_code) and attempt < self._max_retries:
                await async_exit_cm(cm)
                await asyncio.sleep(backoff_seconds(attempt))
                continue
            try:
                check_response(resp)
            finally:
                await async_exit_cm(cm)
        raise RuntimeError("_open_stream_async: unreachable")

    @staticmethod
    def _check_response(response: httpx.Response) -> None:
        check_response(response)

    async def aclose(self) -> None:
        await self._client.aclose()

    async def __aenter__(self) -> AsyncOrlojClient:
        return self

    async def __aexit__(self, *args: object) -> None:
        await self.aclose()
