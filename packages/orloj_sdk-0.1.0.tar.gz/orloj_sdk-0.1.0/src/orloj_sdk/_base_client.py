from __future__ import annotations

import os
from typing import Any

import httpx

from orloj_sdk._errors import raise_for_status
from orloj_sdk._version import __version__

DEFAULT_BASE_URL = "http://127.0.0.1:8080"


def resolve_api_token(explicit: str | None) -> str | None:
    if explicit is not None:
        s = explicit.strip()
        return s if s else None
    for key in ("ORLOJCTL_API_TOKEN", "ORLOJ_API_TOKEN"):
        v = os.environ.get(key)
        if v and v.strip():
            return v.strip()
    return None


def resolve_base_url(explicit: str | None) -> str:
    if explicit is not None:
        return explicit.rstrip("/")
    for key in ("ORLOJCTL_SERVER", "ORLOJ_SERVER"):
        v = os.environ.get(key)
        if v and v.strip():
            return v.strip().rstrip("/")
    return DEFAULT_BASE_URL


def build_default_headers(token: str | None) -> dict[str, str]:
    headers: dict[str, str] = {
        "Content-Type": "application/json",
        "User-Agent": f"orloj-sdk-python/{__version__}",
    }
    if token:
        headers["Authorization"] = f"Bearer {token}"
    return headers


def timeout_for_request(method: str, stream: bool) -> httpx.Timeout:
    if stream:
        return httpx.Timeout(connect=30.0, read=None)
    read = 60.0 if method in ("POST", "PUT", "PATCH", "DELETE") else 30.0
    return httpx.Timeout(connect=30.0, read=read, write=60.0, pool=30.0)


def merge_timeout(
    method: str,
    stream: bool,
    override: float | httpx.Timeout | None,
) -> httpx.Timeout | float | None:
    if override is not None:
        return override
    return timeout_for_request(method, stream)


def check_response(response: httpx.Response) -> None:
    if response.is_success:
        return
    raise_for_status(response.status_code, response.text)


def json_or_empty(response: httpx.Response) -> Any:
    if not response.content:
        return None
    return response.json()
