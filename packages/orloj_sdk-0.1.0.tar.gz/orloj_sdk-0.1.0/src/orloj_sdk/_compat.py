"""Python version shims — reserved for future use."""
