from __future__ import annotations

from typing import Any

from pydantic import Field

from orloj_sdk.models._base import ListMeta, ObjectMeta, OrlojModel


class ToolCliEnvRef(OrlojModel):
    name: str
    secret_ref: str = Field(..., alias="secretRef")
    key: str | None = None


class ToolCliSpec(OrlojModel):
    command: str | None = None
    args: list[str] | None = None
    image: str | None = None
    network: str | None = None
    stdin_from_input: bool | None = None
    output: str | None = None
    working_dir: str | None = None
    env: dict[str, str] | None = None
    env_from: list[ToolCliEnvRef] | None = None


class ToolAuth(OrlojModel):
    profile: str | None = None
    secret_ref: str | None = Field(None, alias="secretRef")
    header_name: str | None = Field(None, alias="headerName")
    token_url: str | None = Field(None, alias="tokenURL")
    scopes: list[str] | None = None


class ToolRetryPolicy(OrlojModel):
    max_attempts: int | None = None
    backoff: str | None = None
    max_backoff: str | None = None
    jitter: str | None = None


class ToolRuntimePolicy(OrlojModel):
    timeout: str | None = None
    isolation_mode: str | None = None
    retry: ToolRetryPolicy | None = None


class ToolSpec(OrlojModel):
    type: str | None = None
    endpoint: str | None = None
    description: str | None = None
    input_schema: dict[str, Any] | None = None
    mcp_server_ref: str | None = None
    mcp_tool_name: str | None = None
    cli: ToolCliSpec | None = None
    capabilities: list[str] | None = None
    operation_classes: list[str] | None = None
    risk_level: str | None = None
    runtime: ToolRuntimePolicy | None = None
    auth: ToolAuth | None = None


class ToolStatus(OrlojModel):
    phase: str | None = None
    last_error: str | None = Field(None, alias="lastError")
    observed_generation: int | None = Field(None, alias="observedGeneration")


class Tool(OrlojModel):
    api_version: str = Field("orloj.dev/v1", alias="apiVersion")
    kind: str = "Tool"
    metadata: ObjectMeta
    spec: ToolSpec
    status: ToolStatus | None = None


class ToolList(OrlojModel):
    metadata: ListMeta | None = None
    items: list[Tool]
