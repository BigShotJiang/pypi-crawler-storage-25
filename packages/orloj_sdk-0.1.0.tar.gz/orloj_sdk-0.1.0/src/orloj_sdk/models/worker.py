from __future__ import annotations

from pydantic import Field

from orloj_sdk.models._base import ListMeta, ObjectMeta, OrlojModel


class WorkerCapabilities(OrlojModel):
    gpu: bool | None = None
    supported_models: list[str] | None = None


class WorkerSpec(OrlojModel):
    region: str | None = None
    capabilities: WorkerCapabilities | None = None
    max_concurrent_tasks: int | None = None


class WorkerStatus(OrlojModel):
    phase: str | None = None
    last_error: str | None = Field(None, alias="lastError")
    last_heartbeat: str | None = Field(None, alias="lastHeartbeat")
    observed_generation: int | None = Field(None, alias="observedGeneration")
    current_tasks: int | None = Field(None, alias="currentTasks")


class Worker(OrlojModel):
    api_version: str = Field("orloj.dev/v1", alias="apiVersion")
    kind: str = "Worker"
    metadata: ObjectMeta
    spec: WorkerSpec
    status: WorkerStatus | None = None


class WorkerList(OrlojModel):
    metadata: ListMeta | None = None
    items: list[Worker]
