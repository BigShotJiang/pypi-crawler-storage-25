from __future__ import annotations

from pydantic import Field

from orloj_sdk.models._base import ListMeta, ObjectMeta, OrlojModel


class TaskRetryPolicy(OrlojModel):
    max_attempts: int | None = None
    backoff: str | None = None


class TaskMessageRetryPolicy(OrlojModel):
    max_attempts: int | None = None
    backoff: str | None = None
    max_backoff: str | None = None
    jitter: str | None = None
    non_retryable: list[str] | None = None


class TaskRequirements(OrlojModel):
    region: str | None = None
    gpu: bool | None = None
    model: str | None = None


class TaskSpec(OrlojModel):
    system: str | None = None
    mode: str | None = None
    input: dict[str, str] | None = None
    priority: str | None = None
    max_turns: int | None = None
    retry: TaskRetryPolicy | None = None
    message_retry: TaskMessageRetryPolicy | None = None
    requirements: TaskRequirements | None = None


class TaskTraceEvent(OrlojModel):
    timestamp: str | None = None
    step_id: str | None = None
    attempt: int | None = None
    step: int | None = None
    branch_id: str | None = None
    type: str | None = None
    agent: str | None = None
    tool: str | None = None
    tool_contract_version: str | None = None
    tool_request_id: str | None = None
    tool_attempt: int | None = None
    error_code: str | None = None
    error_reason: str | None = None
    retryable: bool | None = None
    message: str | None = None
    latency_ms: int | None = None
    tokens: int | None = None
    input_tokens: int | None = None
    output_tokens: int | None = None
    token_usage_source: str | None = None
    tool_calls: int | None = None
    memory_writes: int | None = None
    tool_auth_profile: str | None = None
    tool_auth_secret_ref: str | None = None


class TaskHistoryEvent(OrlojModel):
    timestamp: str | None = None
    type: str | None = None
    worker: str | None = None
    message: str | None = None


class TaskMessage(OrlojModel):
    timestamp: str | None = None
    message_id: str | None = None
    idempotency_key: str | None = None
    task_id: str | None = None
    attempt: int | None = None
    system: str | None = None
    from_agent: str | None = None
    to_agent: str | None = None
    branch_id: str | None = None
    parent_branch_id: str | None = None
    type: str | None = None
    content: str | None = None
    trace_id: str | None = None
    parent_id: str | None = None
    phase: str | None = None
    attempts: int | None = None
    max_attempts: int | None = None
    last_error: str | None = None
    worker: str | None = None
    processed_at: str | None = None
    next_attempt_at: str | None = None


class TaskJoinSource(OrlojModel):
    message_id: str | None = None
    from_agent: str | None = None
    branch_id: str | None = None
    timestamp: str | None = None
    payload: str | None = None


class TaskJoinState(OrlojModel):
    attempt: int | None = None
    node: str | None = None
    mode: str | None = None
    expected: int | None = None
    quorum_required: int | None = None
    activated: bool | None = None
    activated_at: str | None = None
    activated_by: str | None = None
    sources: list[TaskJoinSource] | None = None


class TaskStatus(OrlojModel):
    phase: str | None = None
    last_error: str | None = Field(None, alias="lastError")
    started_at: str | None = Field(None, alias="startedAt")
    completed_at: str | None = Field(None, alias="completedAt")
    next_attempt_at: str | None = Field(None, alias="nextAttemptAt")
    attempts: int | None = None
    output: dict[str, str] | None = None
    assigned_worker: str | None = Field(None, alias="assignedWorker")
    claimed_by: str | None = Field(None, alias="claimedBy")
    lease_until: str | None = Field(None, alias="leaseUntil")
    last_heartbeat: str | None = Field(None, alias="lastHeartbeat")
    trace: list[TaskTraceEvent] | None = None
    history: list[TaskHistoryEvent] | None = None
    messages: list[TaskMessage] | None = None
    join_states: list[TaskJoinState] | None = None
    observed_generation: int | None = Field(None, alias="observedGeneration")


class Task(OrlojModel):
    api_version: str = Field("orloj.dev/v1", alias="apiVersion")
    kind: str = "Task"
    metadata: ObjectMeta
    spec: TaskSpec
    status: TaskStatus | None = None


class TaskList(OrlojModel):
    metadata: ListMeta | None = None
    items: list[Task]
