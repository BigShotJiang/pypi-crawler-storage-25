from __future__ import annotations

from pydantic import Field

from orloj_sdk.models._base import ListMeta, ObjectMeta, OrlojModel


class SecretSpec(OrlojModel):
    data: dict[str, str] | None = None
    string_data: dict[str, str] | None = Field(None, alias="stringData")


class SecretStatus(OrlojModel):
    phase: str | None = None
    last_error: str | None = Field(None, alias="lastError")
    observed_generation: int | None = Field(None, alias="observedGeneration")


class Secret(OrlojModel):
    api_version: str = Field("orloj.dev/v1", alias="apiVersion")
    kind: str = "Secret"
    metadata: ObjectMeta
    spec: SecretSpec
    status: SecretStatus | None = None


class SecretList(OrlojModel):
    metadata: ListMeta | None = None
    items: list[Secret]
