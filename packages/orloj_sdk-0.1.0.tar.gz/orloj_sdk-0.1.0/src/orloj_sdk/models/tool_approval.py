from __future__ import annotations

from pydantic import Field

from orloj_sdk.models._base import ListMeta, ObjectMeta, OrlojModel


class ToolApprovalSpec(OrlojModel):
    task_ref: str
    tool: str
    operation_class: str | None = None
    agent: str | None = None
    input: str | None = None
    reason: str | None = None
    ttl: str | None = None


class ToolApprovalStatus(OrlojModel):
    phase: str | None = None
    decision: str | None = None
    decided_by: str | None = None
    decided_at: str | None = None
    expires_at: str | None = None


class ToolApproval(OrlojModel):
    api_version: str = Field("orloj.dev/v1", alias="apiVersion")
    kind: str = "ToolApproval"
    metadata: ObjectMeta
    spec: ToolApprovalSpec
    status: ToolApprovalStatus | None = None


class ToolApprovalList(OrlojModel):
    metadata: ListMeta | None = None
    items: list[ToolApproval]
