from __future__ import annotations

from pydantic import Field

from orloj_sdk.models._base import ListMeta, ObjectMeta, OrlojModel


class AgentRoleSpec(OrlojModel):
    description: str | None = None
    permissions: list[str] | None = None


class AgentRoleStatus(OrlojModel):
    phase: str | None = None
    last_error: str | None = Field(None, alias="lastError")
    observed_generation: int | None = Field(None, alias="observedGeneration")


class AgentRole(OrlojModel):
    api_version: str = Field("orloj.dev/v1", alias="apiVersion")
    kind: str = "AgentRole"
    metadata: ObjectMeta
    spec: AgentRoleSpec
    status: AgentRoleStatus | None = None


class AgentRoleList(OrlojModel):
    metadata: ListMeta | None = None
    items: list[AgentRole]
