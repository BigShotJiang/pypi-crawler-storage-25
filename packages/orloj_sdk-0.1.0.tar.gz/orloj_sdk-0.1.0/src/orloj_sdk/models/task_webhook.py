from __future__ import annotations

from pydantic import Field

from orloj_sdk.models._base import ListMeta, ObjectMeta, OrlojModel


class TaskWebhookAuthSpec(OrlojModel):
    profile: str | None = None
    secret_ref: str | None = None
    signature_header: str | None = None
    signature_prefix: str | None = None
    timestamp_header: str | None = None
    max_skew_seconds: int | None = None


class TaskWebhookIdempotency(OrlojModel):
    event_id_header: str | None = None
    dedupe_window_seconds: int | None = None


class TaskWebhookPayloadSpec(OrlojModel):
    mode: str | None = None
    input_key: str | None = None


class TaskWebhookSpec(OrlojModel):
    task_ref: str | None = None
    suspend: bool | None = None
    auth: TaskWebhookAuthSpec | None = None
    idempotency: TaskWebhookIdempotency | None = None
    payload: TaskWebhookPayloadSpec | None = None


class TaskWebhookStatus(OrlojModel):
    phase: str | None = None
    last_error: str | None = Field(None, alias="lastError")
    observed_generation: int | None = Field(None, alias="observedGeneration")
    endpoint_id: str | None = Field(None, alias="endpointID")
    endpoint_path: str | None = Field(None, alias="endpointPath")
    last_delivery_time: str | None = Field(None, alias="lastDeliveryTime")
    last_event_id: str | None = Field(None, alias="lastEventID")
    last_triggered_task: str | None = Field(None, alias="lastTriggeredTask")
    accepted_count: int | None = Field(None, alias="acceptedCount")
    duplicate_count: int | None = Field(None, alias="duplicateCount")
    rejected_count: int | None = Field(None, alias="rejectedCount")


class TaskWebhook(OrlojModel):
    api_version: str = Field("orloj.dev/v1", alias="apiVersion")
    kind: str = "TaskWebhook"
    metadata: ObjectMeta
    spec: TaskWebhookSpec
    status: TaskWebhookStatus | None = None


class TaskWebhookList(OrlojModel):
    metadata: ListMeta | None = None
    items: list[TaskWebhook]
