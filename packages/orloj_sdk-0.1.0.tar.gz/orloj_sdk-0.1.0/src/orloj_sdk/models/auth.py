from __future__ import annotations

from typing import Any

from pydantic import Field

from orloj_sdk.models._base import OrlojModel


class WhoAmI(OrlojModel):
    authenticated: bool
    username: str | None = None
    role: str | None = None
    method: str | None = None


class TokenInfo(OrlojModel):
    name: str
    role: str | None = None
    token: str | None = None
    created_at: str | None = Field(None, alias="createdAt")


class NamedLogsResponse(OrlojModel):
    name: str
    logs: list[dict[str, Any]]
