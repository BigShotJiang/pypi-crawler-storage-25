from __future__ import annotations

from pydantic import Field

from orloj_sdk.models._base import ListMeta, ObjectMeta, OrlojModel


class ModelEndpointAuth(OrlojModel):
    secret_ref: str | None = Field(None, alias="secretRef")


class ModelEndpointSpec(OrlojModel):
    provider: str | None = None
    base_url: str | None = None
    default_model: str | None = None
    options: dict[str, str] | None = None
    auth: ModelEndpointAuth | None = None


class ModelEndpointStatus(OrlojModel):
    phase: str | None = None
    last_error: str | None = Field(None, alias="lastError")
    observed_generation: int | None = Field(None, alias="observedGeneration")


class ModelEndpoint(OrlojModel):
    api_version: str = Field("orloj.dev/v1", alias="apiVersion")
    kind: str = "ModelEndpoint"
    metadata: ObjectMeta
    spec: ModelEndpointSpec
    status: ModelEndpointStatus | None = None


class ModelEndpointList(OrlojModel):
    metadata: ListMeta | None = None
    items: list[ModelEndpoint]
