from __future__ import annotations

from pydantic import Field

from orloj_sdk.models._base import ListMeta, ObjectMeta, OrlojModel


class OperationRule(OrlojModel):
    operation_class: str | None = None
    verdict: str | None = None


class ToolPermissionSpec(OrlojModel):
    tool_ref: str | None = None
    action: str | None = None
    required_permissions: list[str] | None = None
    match_mode: str | None = None
    apply_mode: str | None = None
    target_agents: list[str] | None = None
    operation_rules: list[OperationRule] | None = None


class ToolPermissionStatus(OrlojModel):
    phase: str | None = None
    last_error: str | None = Field(None, alias="lastError")
    observed_generation: int | None = Field(None, alias="observedGeneration")


class ToolPermission(OrlojModel):
    api_version: str = Field("orloj.dev/v1", alias="apiVersion")
    kind: str = "ToolPermission"
    metadata: ObjectMeta
    spec: ToolPermissionSpec
    status: ToolPermissionStatus | None = None


class ToolPermissionList(OrlojModel):
    metadata: ListMeta | None = None
    items: list[ToolPermission]
