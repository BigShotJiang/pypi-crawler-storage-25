from __future__ import annotations

from typing import Generic, TypeVar

from orloj_sdk.models._base import OrlojModel

T = TypeVar("T", bound=OrlojModel)


class WatchEvent(OrlojModel, Generic[T]):
    """SSE event from /v1/{resource}/watch endpoints."""

    type: str
    resource: T  # validated per watch() resource type


class ServerEvent(OrlojModel):
    """SSE event from /v1/events/watch."""

    id: int | None = None
    timestamp: str | None = None
    source: str | None = None
    type: str | None = None
    kind: str | None = None
    name: str | None = None
    namespace: str | None = None
    action: str | None = None
    message: str | None = None
