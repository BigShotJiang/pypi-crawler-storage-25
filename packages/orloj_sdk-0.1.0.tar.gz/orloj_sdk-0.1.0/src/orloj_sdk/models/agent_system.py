from __future__ import annotations

from pydantic import Field

from orloj_sdk.models._base import ListMeta, ObjectMeta, OrlojModel


class GraphRoute(OrlojModel):
    to: str | None = None
    labels: dict[str, str] | None = None
    policy: dict[str, str] | None = None


class GraphJoin(OrlojModel):
    mode: str | None = None
    quorum_count: int | None = None
    quorum_percent: int | None = None
    on_failure: str | None = None


class GraphEdge(OrlojModel):
    next: str | None = None
    edges: list[GraphRoute] | None = None
    join: GraphJoin | None = None


class AgentSystemSpec(OrlojModel):
    agents: list[str] | None = None
    graph: dict[str, GraphEdge] | None = None


class AgentSystemStatus(OrlojModel):
    phase: str | None = None
    last_error: str | None = Field(None, alias="lastError")
    observed_generation: int | None = Field(None, alias="observedGeneration")


class AgentSystem(OrlojModel):
    api_version: str = Field("orloj.dev/v1", alias="apiVersion")
    kind: str = "AgentSystem"
    metadata: ObjectMeta
    spec: AgentSystemSpec
    status: AgentSystemStatus | None = None


class AgentSystemList(OrlojModel):
    metadata: ListMeta | None = None
    items: list[AgentSystem]
