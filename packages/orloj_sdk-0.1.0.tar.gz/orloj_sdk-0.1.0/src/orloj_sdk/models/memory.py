from __future__ import annotations

from typing import Any

from pydantic import Field

from orloj_sdk.models._base import ListMeta, ObjectMeta, OrlojModel


class MemoryAuthConfig(OrlojModel):
    secret_ref: str | None = Field(None, alias="secretRef")


class MemoryConfig(OrlojModel):
    type: str | None = None
    provider: str | None = None
    embedding_model: str | None = None
    endpoint: str | None = None
    auth: MemoryAuthConfig | None = None


class MemoryStatus(OrlojModel):
    phase: str | None = None
    last_error: str | None = Field(None, alias="lastError")
    observed_generation: int | None = Field(None, alias="observedGeneration")


class Memory(OrlojModel):
    api_version: str = Field("orloj.dev/v1", alias="apiVersion")
    kind: str = "Memory"
    metadata: ObjectMeta
    spec: MemoryConfig
    status: MemoryStatus | None = None


class MemoryList(OrlojModel):
    metadata: ListMeta | None = None
    items: list[Memory]


class MemoryEntry(OrlojModel):
    key: str | None = None
    value: str | None = None
    score: float | None = None
    metadata: dict[str, Any] | None = None


class MemoryEntriesResponse(OrlojModel):
    entries: list[MemoryEntry]
    count: int | None = None
