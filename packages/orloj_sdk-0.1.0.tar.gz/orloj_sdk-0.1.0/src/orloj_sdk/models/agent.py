from __future__ import annotations

from pydantic import Field

from orloj_sdk.models._base import ListMeta, ObjectMeta, OrlojModel


class AgentLimits(OrlojModel):
    max_steps: int | None = None
    timeout: str | None = None


class MemorySpec(OrlojModel):
    """Memory reference embedded in Agent spec."""

    ref: str | None = None
    type: str | None = None
    provider: str | None = None
    allow: list[str] | None = None


class AgentExecutionSpec(OrlojModel):
    profile: str | None = None
    tool_sequence: list[str] | None = None
    required_output_markers: list[str] | None = None
    duplicate_tool_call_policy: str | None = None
    on_contract_violation: str | None = None
    tool_use_behavior: str | None = None


class AgentSpec(OrlojModel):
    model_ref: str | None = None
    prompt: str | None = None
    tools: list[str] | None = None
    allowed_tools: list[str] | None = None
    roles: list[str] | None = None
    memory: MemorySpec | None = None
    execution: AgentExecutionSpec | None = None
    limits: AgentLimits | None = None


class AgentStatus(OrlojModel):
    phase: str | None = None
    last_error: str | None = Field(None, alias="lastError")
    observed_generation: int | None = Field(None, alias="observedGeneration")


class Agent(OrlojModel):
    api_version: str = Field("orloj.dev/v1", alias="apiVersion")
    kind: str = "Agent"
    metadata: ObjectMeta
    spec: AgentSpec
    status: AgentStatus | None = None


class AgentList(OrlojModel):
    metadata: ListMeta | None = None
    items: list[Agent]
