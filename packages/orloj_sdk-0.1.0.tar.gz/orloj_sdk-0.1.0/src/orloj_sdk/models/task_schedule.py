from __future__ import annotations

from pydantic import Field

from orloj_sdk.models._base import ListMeta, ObjectMeta, OrlojModel


class TaskScheduleSpec(OrlojModel):
    task_ref: str | None = None
    schedule: str | None = None
    time_zone: str | None = None
    suspend: bool | None = None
    starting_deadline_seconds: int | None = None
    concurrency_policy: str | None = None
    successful_history_limit: int | None = None
    failed_history_limit: int | None = None


class TaskScheduleStatus(OrlojModel):
    phase: str | None = None
    last_error: str | None = Field(None, alias="lastError")
    last_schedule_time: str | None = Field(None, alias="lastScheduleTime")
    last_successful_time: str | None = Field(None, alias="lastSuccessfulTime")
    next_schedule_time: str | None = Field(None, alias="nextScheduleTime")
    last_triggered_task: str | None = Field(None, alias="lastTriggeredTask")
    active_runs: list[str] | None = Field(None, alias="activeRuns")
    observed_generation: int | None = Field(None, alias="observedGeneration")


class TaskSchedule(OrlojModel):
    api_version: str = Field("orloj.dev/v1", alias="apiVersion")
    kind: str = "TaskSchedule"
    metadata: ObjectMeta
    spec: TaskScheduleSpec
    status: TaskScheduleStatus | None = None


class TaskScheduleList(OrlojModel):
    metadata: ListMeta | None = None
    items: list[TaskSchedule]
