from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class OrlojModel(BaseModel):
    model_config = ConfigDict(
        populate_by_name=True,
        extra="ignore",
    )


class ObjectMeta(OrlojModel):
    name: str
    namespace: str = "default"
    labels: dict[str, str] | None = None
    annotations: dict[str, str] | None = None
    resource_version: str | None = Field(None, alias="resourceVersion")
    generation: int | None = None
    created_at: str | None = Field(None, alias="createdAt")


class ListMeta(OrlojModel):
    continue_: str | None = Field(None, alias="continue")


class StatusEnvelope(OrlojModel):
    phase: str | None = None
    last_error: str | None = Field(None, alias="lastError")
    observed_generation: int | None = Field(None, alias="observedGeneration")


def dump_json_body(model: OrlojModel | dict[str, Any]) -> Any:
    if isinstance(model, OrlojModel):
        return model.model_dump(mode="json", by_alias=True, exclude_none=True)
    return model
