from __future__ import annotations

from pydantic import Field

from orloj_sdk.models._base import ListMeta, ObjectMeta, OrlojModel
from orloj_sdk.models.tool import ToolAuth


class McpServerEnvVar(OrlojModel):
    name: str
    value: str | None = None
    secret_ref: str | None = Field(None, alias="secretRef")


class McpToolFilter(OrlojModel):
    include: list[str] | None = None


class McpReconnectPolicy(OrlojModel):
    max_attempts: int | None = None
    backoff: str | None = None


class McpServerSpec(OrlojModel):
    transport: str
    command: str | None = None
    args: list[str] | None = None
    env: list[McpServerEnvVar] | None = None
    endpoint: str | None = None
    auth: ToolAuth | None = None
    tool_filter: McpToolFilter | None = None
    reconnect: McpReconnectPolicy | None = None


class McpServerStatus(OrlojModel):
    phase: str | None = None
    discovered_tools: list[str] | None = Field(None, alias="discoveredTools")
    generated_tools: list[str] | None = Field(None, alias="generatedTools")
    last_synced_at: str | None = Field(None, alias="lastSyncedAt")
    last_error: str | None = Field(None, alias="lastError")
    observed_generation: int | None = Field(None, alias="observedGeneration")


class McpServer(OrlojModel):
    api_version: str = Field("orloj.dev/v1", alias="apiVersion")
    kind: str = "McpServer"
    metadata: ObjectMeta
    spec: McpServerSpec
    status: McpServerStatus | None = None


class McpServerList(OrlojModel):
    metadata: ListMeta | None = None
    items: list[McpServer]
