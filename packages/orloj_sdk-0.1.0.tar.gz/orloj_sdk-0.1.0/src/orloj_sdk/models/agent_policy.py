from __future__ import annotations

from pydantic import Field

from orloj_sdk.models._base import ListMeta, ObjectMeta, OrlojModel


class AgentPolicySpec(OrlojModel):
    max_tokens_per_run: int | None = None
    allowed_models: list[str] | None = None
    blocked_tools: list[str] | None = None
    apply_mode: str | None = None
    target_systems: list[str] | None = None
    target_tasks: list[str] | None = None


class PolicyStatus(OrlojModel):
    phase: str | None = None
    last_error: str | None = Field(None, alias="lastError")
    observed_generation: int | None = Field(None, alias="observedGeneration")


class AgentPolicy(OrlojModel):
    api_version: str = Field("orloj.dev/v1", alias="apiVersion")
    kind: str = "AgentPolicy"
    metadata: ObjectMeta
    spec: AgentPolicySpec
    status: PolicyStatus | None = None


class AgentPolicyList(OrlojModel):
    metadata: ListMeta | None = None
    items: list[AgentPolicy]
