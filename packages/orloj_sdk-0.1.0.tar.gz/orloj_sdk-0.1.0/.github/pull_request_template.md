## Summary

<!-- What does this PR change and why? Link issues with: Fixes #123 -->

## Type of change

<!-- Mark with an `x` what applies -->

- [ ] Bug fix
- [ ] New feature / API surface
- [ ] Documentation or examples only
- [ ] Internal (tests, tooling, refactor without user-visible behavior change)

## Checklist

<!-- CI runs these; confirming locally speeds up review -->

- [ ] `ruff check src/orloj_sdk tests examples` passes
- [ ] `ruff format --check src/orloj_sdk tests examples` passes (or files formatted)
- [ ] `mypy src/orloj_sdk` passes
- [ ] `pytest` passes (add or update tests if behavior changed)

## Notes for reviewers

<!-- Optional: risk areas, follow-ups, or context that is not obvious from the diff. -->
