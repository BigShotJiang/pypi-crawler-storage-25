---
name: Bug report
about: Report incorrect behavior, crashes, or API mismatches in the Python SDK
title: "[bug] "
labels: ["bug"]
---

## Summary

<!-- What went wrong in one or two sentences? -->

## Expected behavior

<!-- What did you expect to happen? -->

## Actual behavior

<!-- What happened instead? Include full tracebacks for exceptions. -->

## How to reproduce

<!-- Minimal code, steps, and versions. -->

```python
# paste a minimal example
```

## Environment

- **orloj-sdk version** (or git commit): <!-- e.g. 0.1.0 -->
- **Python version**: <!-- e.g. 3.12 -->
- **OS**: <!-- e.g. macOS 14, Ubuntu 22.04 -->

## Server / API (if relevant)

- **Orloj API URL** (if not default): <!-- optional -->
- **Anything else** that helps reproduce the issue:
