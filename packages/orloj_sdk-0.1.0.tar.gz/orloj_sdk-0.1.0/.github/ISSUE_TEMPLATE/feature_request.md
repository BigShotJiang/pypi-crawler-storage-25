---
name: Feature request
about: Suggest an improvement or new capability for the Python SDK
title: "[feature] "
labels: ["enhancement"]
---

## Problem / motivation

<!-- What is awkward, missing, or inconsistent today? Who benefits? -->

## Proposed solution

<!-- How would you like the SDK to behave? Sketch APIs or usage if helpful. -->

```python
# optional: example of desired usage
```

## Alternatives considered

<!-- Other ways to solve this, or workarounds you use today. -->

## Additional context

<!-- Links to Orloj API docs, related issues, or prior art in other SDKs. -->
