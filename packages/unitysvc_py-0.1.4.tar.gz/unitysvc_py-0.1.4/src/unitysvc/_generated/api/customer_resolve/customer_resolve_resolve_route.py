from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.resolve_request import ResolveRequest
from ...models.resolve_response import ResolveResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    body: ResolveRequest,
    authorization: None | str | Unset = UNSET,
    x_role_id: None | str | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    if not isinstance(authorization, Unset):
        headers["authorization"] = authorization

    if not isinstance(x_role_id, Unset):
        headers["x-role-id"] = x_role_id

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/resolve",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | ResolveResponse | None:
    if response.status_code == 200:
        response_200 = ResolveResponse.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | ResolveResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: ResolveRequest,
    authorization: None | str | Unset = UNSET,
    x_role_id: None | str | Unset = UNSET,
) -> Response[HTTPValidationError | ResolveResponse]:
    """Resolve Route

     Dry-run resolve a gateway path + routing key to its candidate services.

    Mirrors the gateway's decision without executing or caching the
    result. Response shape is customer-safe — no wallet, no secrets,
    no upstream credentials.

    Args:
        authorization (None | str | Unset):
        x_role_id (None | str | Unset):
        body (ResolveRequest): Dry-run resolution input, mirroring what the gateway accepts.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | ResolveResponse]
    """

    kwargs = _get_kwargs(
        body=body,
        authorization=authorization,
        x_role_id=x_role_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: ResolveRequest,
    authorization: None | str | Unset = UNSET,
    x_role_id: None | str | Unset = UNSET,
) -> HTTPValidationError | ResolveResponse | None:
    """Resolve Route

     Dry-run resolve a gateway path + routing key to its candidate services.

    Mirrors the gateway's decision without executing or caching the
    result. Response shape is customer-safe — no wallet, no secrets,
    no upstream credentials.

    Args:
        authorization (None | str | Unset):
        x_role_id (None | str | Unset):
        body (ResolveRequest): Dry-run resolution input, mirroring what the gateway accepts.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | ResolveResponse
    """

    return sync_detailed(
        client=client,
        body=body,
        authorization=authorization,
        x_role_id=x_role_id,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: ResolveRequest,
    authorization: None | str | Unset = UNSET,
    x_role_id: None | str | Unset = UNSET,
) -> Response[HTTPValidationError | ResolveResponse]:
    """Resolve Route

     Dry-run resolve a gateway path + routing key to its candidate services.

    Mirrors the gateway's decision without executing or caching the
    result. Response shape is customer-safe — no wallet, no secrets,
    no upstream credentials.

    Args:
        authorization (None | str | Unset):
        x_role_id (None | str | Unset):
        body (ResolveRequest): Dry-run resolution input, mirroring what the gateway accepts.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | ResolveResponse]
    """

    kwargs = _get_kwargs(
        body=body,
        authorization=authorization,
        x_role_id=x_role_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: ResolveRequest,
    authorization: None | str | Unset = UNSET,
    x_role_id: None | str | Unset = UNSET,
) -> HTTPValidationError | ResolveResponse | None:
    """Resolve Route

     Dry-run resolve a gateway path + routing key to its candidate services.

    Mirrors the gateway's decision without executing or caching the
    result. Response shape is customer-safe — no wallet, no secrets,
    no upstream credentials.

    Args:
        authorization (None | str | Unset):
        x_role_id (None | str | Unset):
        body (ResolveRequest): Dry-run resolution input, mirroring what the gateway accepts.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | ResolveResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
            authorization=authorization,
            x_role_id=x_role_id,
        )
    ).parsed
