"""``usvc secrets`` — remote customer-secret operations.

Minimal surface for now:

- ``usvc secrets list``       — list the customer's secrets
- ``usvc secrets set NAME``   — upsert a secret by name (create or update)
- ``usvc secrets delete NAME`` — delete a secret by name

All commands read credentials from ``UNITYSVC_API_KEY`` /
``UNITYSVC_API_URL`` by default and accept ``--api-key`` / ``--base-url``
overrides.
"""

from __future__ import annotations

import json
import sys
from typing import Any

import typer
from rich.console import Console
from rich.table import Table

from ._helpers import (
    api_key_option,
    async_client,
    base_url_option,
    model_list,
    model_to_dict,
    run_async,
)

console = Console()

app = typer.Typer(
    help="Customer secret management (list, set, delete).",
)


# ---------------------------------------------------------------------------
# list
# ---------------------------------------------------------------------------
@app.command("list")
def list_secrets(
    skip: int = typer.Option(0, "--skip", help="Offset for pagination."),
    limit: int = typer.Option(100, "--limit", help="Max records to return."),
    output_format: str = typer.Option("table", "--format", "-f", help="Output format: table | json."),
    api_key: str | None = api_key_option(),
    base_url: str = base_url_option(),
) -> None:
    """List secrets owned by the authenticated customer."""

    async def _impl() -> list[dict[str, Any]]:
        async with async_client(api_key, base_url) as client:
            return model_list(await client.secrets.list(skip=skip, limit=limit))

    secrets = run_async(_impl(), error_prefix="Failed to list secrets")

    if not secrets:
        console.print("[dim]No secrets found[/dim]")
        return

    if output_format == "json":
        console.print(json.dumps(secrets, indent=2, default=str))
        return

    table = Table(title="Secrets")
    table.add_column("Name", style="bold")
    table.add_column("ID", style="dim")
    table.add_column("Owner type")
    for s in secrets:
        table.add_row(
            str(s.get("name", "")),
            str(s.get("id", "")),
            str(s.get("owner_type", "")),
        )
    console.print(table)


# ---------------------------------------------------------------------------
# set (upsert by name)
# ---------------------------------------------------------------------------
@app.command("set")
def set_secret(
    name: str = typer.Argument(..., help="Secret name (unique per customer)."),
    value: str | None = typer.Option(
        None,
        "--value",
        help=(
            "Secret value. If omitted: reads from stdin when piped, prompts with hidden input when run interactively."
        ),
    ),
    api_key: str | None = api_key_option(),
    base_url: str = base_url_option(),
) -> None:
    """Set a secret by name (idempotent — creates or rotates).

    Maps to ``PUT /v1/customer/secrets/{name}``. The value is encrypted
    server-side and cannot be retrieved later. Resolution order for
    the value, in order of precedence:

      1. ``--value VALUE``                     — explicit literal (or
                                                 ``--value "$ENV_NAME"``
                                                 via shell expansion).
      2. piped stdin                           — ``echo v | usvc secrets set X``
                                                 (trailing newline stripped).
      3. interactive prompt                    — TTY only; hidden input.

    Mirrors the convention used by ``gh secret set``, ``vault kv put``,
    and similar tools.
    """
    if value is None:
        if not sys.stdin.isatty():
            # Piped stdin (or closed stdin): read it. Strip a single
            # trailing newline so ``echo "$X" | ...`` works as expected.
            value = sys.stdin.read().rstrip("\n")
        else:
            # Terminal: prompt with hidden input + confirmation.
            value = typer.prompt(
                f"Value for secret '{name}'",
                hide_input=True,
                confirmation_prompt=True,
            )

    async def _impl() -> dict[str, Any]:
        async with async_client(api_key, base_url) as client:
            return model_to_dict(await client.secrets.set(name, value))

    result = run_async(_impl(), error_prefix="Failed to set secret")
    console.print(f"[green]✓[/green] set secret [bold]{result.get('name', name)}[/bold] ({result.get('id', '')})")


# ---------------------------------------------------------------------------
# delete
# ---------------------------------------------------------------------------
@app.command("delete")
def delete_secret(
    name: str = typer.Argument(..., help="Secret name."),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation prompt."),
    api_key: str | None = api_key_option(),
    base_url: str = base_url_option(),
) -> None:
    """Delete a secret by name."""
    if not yes and not typer.confirm(f"Delete secret '{name}'?"):
        console.print("[yellow]Cancelled[/yellow]")
        raise typer.Exit(code=0)

    async def _impl() -> dict[str, Any]:
        async with async_client(api_key, base_url) as client:
            result = await client.secrets.delete(name)
            return model_to_dict(result)

    result = run_async(_impl(), error_prefix="Failed to delete secret")
    console.print(f"[green]✓[/green] {result.get('message', f'deleted secret {name}')}")
