#!/usr/bin/python

# SPDX-FileCopyrightText: 2020-2022 Simone Persiani <iosonopersia@gmail.com>
# SPDX-FileCopyrightText: 2022-2026 Arcangelo Massari <arcangelo.massari@unibo.it>
#
# SPDX-License-Identifier: ISC

# -*- coding: utf-8 -*-
from __future__ import annotations

import json
import os
from typing import TYPE_CHECKING
from zipfile import ZipFile

from rdflib import Dataset, Graph, URIRef
from sparqlite import EndpointError, SPARQLClient
from triplelite import TripleLite, from_rdflib

from oc_ocdm.constants import CONTEXT, RDF_TYPE
from oc_ocdm.graph.graph_entity import GraphEntity
from oc_ocdm.support.reporter import Reporter
from oc_ocdm.support.support import build_graph_from_results, normalize_graph_literals

if TYPE_CHECKING:
    from typing import Dict, List, Optional, Set

    from oc_ocdm.graph.graph_set import GraphSet

from pyshacl import validate


class Reader(object):

    def __init__(self, repok: Optional[Reporter] = None, reperr: Optional[Reporter] = None) -> None:
        if repok is None:
            self.repok: Reporter = Reporter(prefix="[Reader: INFO] ")
        else:
            self.repok: Reporter = repok

        if reperr is None:
            self.reperr: Reporter = Reporter(prefix="[Reader: ERROR] ")
        else:
            self.reperr: Reporter = reperr

    def load(self, rdf_file_path: str) -> Optional[Dataset]:
        self.repok.new_article()
        self.reperr.new_article()

        loaded_graph: Optional[Dataset] = None
        if os.path.isfile(rdf_file_path):

            try:
                loaded_graph = self._load_graph(rdf_file_path)
            except Exception as e:
                self.reperr.add_sentence("[1] "
                                         "It was impossible to handle the format used for "
                                         "storing the file (stored in the temporary path) "
                                         f"'{rdf_file_path}'. Additional details: {e}")
        else:
            self.reperr.add_sentence("[2] "
                                     f"The file specified ('{rdf_file_path}') doesn't exist.")

        return loaded_graph

    _EXT_TO_FORMATS: dict[str, list[str]] = {
        ".json": ["json-ld"],
        ".jsonld": ["json-ld"],
        ".xml": ["rdfxml"],
        ".rdf": ["rdfxml"],
        ".ttl": ["turtle"],
        ".trig": ["trig"],
        ".nt": ["nt11"],
        ".nq": ["nquads"],
    }
    _ALL_FORMATS: list[str] = ["json-ld", "rdfxml", "turtle", "trig", "nt11", "nquads"]

    @staticmethod
    def _formats_for_file(file_name: str) -> list[str]:
        ext = os.path.splitext(file_name)[1].lower()
        preferred = Reader._EXT_TO_FORMATS.get(ext)
        if preferred is not None:
            return preferred + [f for f in Reader._ALL_FORMATS if f not in preferred]
        return Reader._ALL_FORMATS

    def _load_graph(self, file_path: str) -> Dataset:
        loaded_graph = Dataset()

        if file_path.endswith('.zip'):
            try:
                with ZipFile(file=file_path, mode="r") as archive:
                    for zf_name in archive.namelist():
                        formats = self._formats_for_file(zf_name)
                        with archive.open(zf_name) as f:
                            if self._try_parse(loaded_graph, f, formats):
                                for graph in loaded_graph.graphs():
                                    normalize_graph_literals(graph)
                                return loaded_graph
            except Exception as e:
                raise IOError(f"Error opening or reading zip file '{file_path}': {e}")
        else:
            formats = self._formats_for_file(file_path)
            try:
                with open(file_path, 'rt', encoding='utf-8') as f:
                    if self._try_parse(loaded_graph, f, formats):
                        for graph in loaded_graph.graphs():
                            normalize_graph_literals(graph)
                        return loaded_graph
            except Exception as e:
                raise IOError(f"Error opening or reading file '{file_path}': {e}")

        raise IOError(f"It was impossible to load the file '{file_path}' with supported formats.")

    def _try_parse(self, graph: Dataset, file_obj, formats: List[str]) -> bool:
        for cur_format in formats:
            file_obj.seek(0)
            try:
                if cur_format == "json-ld":
                    json_ld_file = json.load(file_obj)
                    if isinstance(json_ld_file, dict):
                        json_ld_file = [json_ld_file]
                    for json_ld_resource in json_ld_file:
                        json_ld_resource["@context"] = CONTEXT["@context"]
                    graph.parse(data=json.dumps(json_ld_file, ensure_ascii=False), format=cur_format)
                else:
                    graph.parse(file=file_obj, format=cur_format)
                return True
            except Exception:
                continue
        return False

    def graph_validation(self, graph: Graph, closed: bool = False) -> Graph:
        valid_graph: Graph = Graph(identifier=graph.identifier)
        sg = Graph()
        if closed:
            sg.parse(os.path.join('oc_ocdm', 'resources', 'shacle_closed.ttl'))
        else:
            sg.parse(os.path.join('oc_ocdm', 'resources', 'shacle.ttl'))
        _, report_result, _ = validate(graph,
            shacl_graph=sg,
            ont_graph=None,
            inference=None,
            abort_on_first=False,
            allow_infos=False,
            allow_warnings=False,
            meta_shacl=False,
            advanced=False,
            js=False,
            debug=False)
        if not isinstance(report_result, Graph):
            raise TypeError(f"Expected Graph from SHACL validation, got {type(report_result)}")
        invalid_nodes = set()
        for triple in report_result.triples((None, URIRef('http://www.w3.org/ns/shacl#focusNode'), None)):
            invalid_nodes.add(triple[2])
        for s in graph.subjects(unique=True):
            if isinstance(s, URIRef) and s not in invalid_nodes:
                for valid_subject_triple in graph.triples((s, None, None)):
                    valid_graph.add(valid_subject_triple)
        return valid_graph

    @staticmethod
    def import_entities_from_graph(g_set: GraphSet, results: List[Dict] | TripleLite | Graph | Dataset, resp_agent: str,
                                   enable_validation: bool = False, closed: bool = False) -> List[GraphEntity]:
        if isinstance(results, list):
            graph: TripleLite | Graph = build_graph_from_results(results)
        elif isinstance(results, Dataset):
            merged = TripleLite()
            for tl in from_rdflib(results):
                for triple in tl.triples((None, None, None)):
                    merged.add(triple)
            graph = merged
        elif isinstance(results, Graph):
            graph = results
        else:
            graph = results
        if enable_validation:
            reader = Reader()
            if not isinstance(graph, Graph):
                graph = graph.to_rdflib()
            graph = reader.graph_validation(graph, closed)
        if isinstance(graph, Graph):
            graph = from_rdflib(graph)[0]
        imported_entities: List[GraphEntity] = []
        for subject in graph.subjects():
            types: List[str] = [o.value for o in graph.objects(subject, RDF_TYPE)]
            preexisting = graph.subgraph(subject)
            if GraphEntity.iri_note in types:
                imported_entities.append(g_set.add_an(resp_agent=resp_agent, res=subject,
                                         preexisting_graph=preexisting))
            elif GraphEntity.iri_role_in_time in types:
                imported_entities.append(g_set.add_ar(resp_agent=resp_agent, res=subject,
                                         preexisting_graph=preexisting))
            elif GraphEntity.iri_bibliographic_reference in types:
                imported_entities.append(g_set.add_be(resp_agent=resp_agent, res=subject,
                                         preexisting_graph=preexisting))
            elif GraphEntity.iri_expression in types:
                imported_entities.append(g_set.add_br(resp_agent=resp_agent, res=subject,
                                         preexisting_graph=preexisting))
            elif GraphEntity.iri_citation in types:
                imported_entities.append(g_set.add_ci(resp_agent=resp_agent, res=subject,
                                         preexisting_graph=preexisting))
            elif GraphEntity.iri_discourse_element in types:
                imported_entities.append(g_set.add_de(resp_agent=resp_agent, res=subject,
                                         preexisting_graph=preexisting))
            elif GraphEntity.iri_identifier in types:
                imported_entities.append(g_set.add_id(resp_agent=resp_agent, res=subject,
                                         preexisting_graph=preexisting))
            elif GraphEntity.iri_singleloc_pointer_list in types:
                imported_entities.append(g_set.add_pl(resp_agent=resp_agent, res=subject,
                                         preexisting_graph=preexisting))
            elif GraphEntity.iri_agent in types:
                imported_entities.append(g_set.add_ra(resp_agent=resp_agent, res=subject,
                                         preexisting_graph=preexisting))
            elif GraphEntity.iri_manifestation in types:
                imported_entities.append(g_set.add_re(resp_agent=resp_agent, res=subject,
                                         preexisting_graph=preexisting))
            elif GraphEntity.iri_intextref_pointer in types:
                imported_entities.append(g_set.add_rp(resp_agent=resp_agent, res=subject,
                                         preexisting_graph=preexisting))
        return imported_entities

    @staticmethod
    def import_entity_from_triplestore(g_set: GraphSet, ts_url: str, res: str, resp_agent: str,
                                    enable_validation: bool = False) -> GraphEntity:
        query: str = f"SELECT ?s ?p ?o WHERE {{BIND (<{res}> AS ?s). ?s ?p ?o.}}"
        try:
            with SPARQLClient(ts_url, max_retries=3, backoff_factor=2.5) as client:
                result = client.query(query)['results']['bindings']

                if not result:
                    raise ValueError(f"The requested entity {res} was not found in the triplestore.")

                imported_entities: List[GraphEntity] = Reader.import_entities_from_graph(g_set, result, resp_agent, enable_validation)
                if len(imported_entities) <= 0:
                    raise ValueError("The requested entity was not recognized as a proper OCDM entity.")
                return imported_entities[0]

        except ValueError:
            raise
        except EndpointError as e:
            print(f"[3] Could not import entity due to communication problems: {e}")
            raise

    @staticmethod
    def import_entities_from_triplestore(g_set: GraphSet, ts_url: str, entities: List[str], resp_agent: str,
                                    enable_validation: bool = False, batch_size: int = 1000) -> List[GraphEntity]:
        if not entities:
            raise ValueError("No entities provided for import")

        imported_entities: List[GraphEntity] = []

        try:
            with SPARQLClient(ts_url, max_retries=3, backoff_factor=2.5) as client:
                for i in range(0, len(entities), batch_size):
                    batch = entities[i:i + batch_size]
                    not_found_entities = set(batch)

                    union_patterns = []
                    for entity in batch:
                        union_patterns.append(f"{{ BIND(<{entity}> AS ?s) ?s ?p ?o }}")

                    query = f"""
                    SELECT ?s ?p ?o
                    WHERE {{
                        {' UNION '.join(union_patterns)}
                    }}
                    """

                    results = client.query(query)['results']['bindings']

                    if not results:
                        entities_str = ', '.join(not_found_entities)
                        raise ValueError(f"The requested entities were not found in the triplestore: {entities_str}")

                    for result in results:
                        if 's' in result and 'value' in result['s']:
                            not_found_entities.discard(result['s']['value'])

                    batch_entities = Reader.import_entities_from_graph(
                        g_set=g_set,
                        results=results,
                        resp_agent=resp_agent,
                        enable_validation=enable_validation
                    )
                    imported_entities.extend(batch_entities)

                    if not_found_entities:
                        entities_str = ', '.join(not_found_entities)
                        raise ValueError(f"The following entities were not recognized as proper OCDM entities: {entities_str}")

        except ValueError:
            raise
        except EndpointError as e:
            print(f"[3] Could not import batch due to communication problems: {e}")
            raise

        if not imported_entities:
            raise ValueError("None of the requested entities were found or recognized as proper OCDM entities.")

        return imported_entities