//! Public types used across the kreuzcrawl crate.

mod config;
mod discovery;
mod metadata;
mod results;

pub use config::{
    AuthConfig, BrowserConfig, BrowserMode, BrowserWait, ContentConfig, CrawlConfig, ExtractionMeta, ProxyConfig,
};
pub use discovery::{
    AssetCategory, CookieInfo, CrawlEvent, DownloadedAsset, FeedInfo, FeedType, ImageInfo, ImageSource, JsonLdEntry,
    LinkInfo, LinkType,
};
pub use metadata::{ArticleMetadata, FaviconInfo, HeadingInfo, HreflangEntry, PageMetadata, ResponseMeta};
pub use results::{
    CachedPage, CrawlPageResult, CrawlResult, DownloadedDocument, MapResult, MarkdownResult, ScrapeResult, SitemapUrl,
};
