"""
config.py — 配置加载器

支持字段（优先级：CLI 参数 > 当前目录 .env > ~/.linkedin_lion/.env > 系统环境变量）：

  LION_API_KEY     LLM API 密钥（可选，未设置则使用 llmdog 内置配置）
  LION_API_URL     LLM API 端点 URL（可选，未设置则使用 llmdog 内置默认值）
  LION_MODEL       LLM 模型名称（可选，未设置则使用 llmdog 内置默认值）
  LION_TIMEOUT     LLM 请求超时秒数（可选，未设置则使用 llmdog 内置默认值）
  LION_VERIFY_SSL  是否验证 SSL 证书（可选，未设置则使用 llmdog 内置默认值）
  LION_COOKIE_FILE Selenium Cookie 文件路径（默认 cookie.json）

用法：
    from linkedin_lion.config import load_config, get_llm_config

    # 版本 A：最简配置，所有 LLM 参数均使用 llmdog 内置默认值
    cfg = load_config()
    llm_kwargs = get_llm_config(cfg)   # 返回空字典，llmdog 接管所有默认值

    # 版本 B：完整配置，显式指定所有参数
    cfg = load_config(
        api_key="sk-xxxx",
        api_url="https://api.deepseek.com/v1/chat/completions",
        model="deepseek-chat",
        timeout=60,
        verify_ssl=True,
    )
"""

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from dotenv import load_dotenv

# ==================== 默认值 ====================

_DEFAULT_COOKIE_FILE = "cookie.json"  # Cookie 文件为本地参数，保留默认值


# ==================== 配置数据类 ====================


@dataclass
class LionConfig:
    """
    linkedin-lion 全局配置对象。

    所有 LLM 相关参数均为可选（默认 None）：
      - 未设置时 get_llm_config() 不会将该字段传递给 llmdog
      - llmdog 自行使用其内置默认值
      - 仅 cookie_file 有本地默认值（linkedin-lion 自身管理）

    :param api_key:     LLM API 密钥（可选，优先于 llmdog 内置配置）
    :param api_url:     LLM API 端点 URL（可选，留空则不传递给 llmdog）
    :param model:       LLM 模型名称（可选，留空则不传递给 llmdog）
    :param timeout:     LLM 请求超时（秒，可选，留空则不传递给 llmdog）
    :param verify_ssl:  是否验证 HTTPS SSL 证书（可选，留空则不传递给 llmdog）
    :param cookie_file: Selenium 登录态 Cookie 文件路径
    """

    api_key: Optional[str] = None
    api_url: Optional[str] = None
    model: Optional[str] = None
    timeout: Optional[int] = None
    verify_ssl: Optional[bool] = None
    cookie_file: str = _DEFAULT_COOKIE_FILE


# ==================== .env 查找与加载 ====================


def _load_dotenv_files() -> None:
    """
    按优先级加载 .env 文件：
      1. 当前工作目录 .env
      2. ~/.linkedin_lion/.env
    已设置的环境变量不会被覆盖（override=False）。
    """
    candidates = [
        Path.cwd() / ".env",
        Path.home() / ".linkedin_lion" / ".env",
    ]
    for env_file in candidates:
        if env_file.exists():
            load_dotenv(dotenv_path=env_file, override=False)


# ==================== 公开 API ====================


def load_config(
    api_key: Optional[str] = None,
    api_url: Optional[str] = None,
    model: Optional[str] = None,
    timeout: Optional[int] = None,
    verify_ssl: Optional[bool] = None,
    cookie_file: Optional[str] = None,
) -> LionConfig:
    """
    加载并返回 LionConfig 实例。

    参数优先级（高→低）：
      函数参数 > 环境变量（含 .env）> None（交由 llmdog 使用内置默认值）

    LLM 相关参数均为可选：
      - 未设置时返回 None，get_llm_config() 不会将其传递给 llmdog
      - llmdog 将自行使用其内置默认值

    :param api_key:     覆盖 LION_API_KEY
    :param api_url:     覆盖 LION_API_URL
    :param model:       覆盖 LION_MODEL
    :param timeout:     覆盖 LION_TIMEOUT
    :param verify_ssl:  覆盖 LION_VERIFY_SSL
    :param cookie_file: 覆盖 LION_COOKIE_FILE
    :return: LionConfig 实例
    """
    _load_dotenv_files()

    # LLM 参数：函数参数 > 环境变量 > None（交 llmdog 决定）
    resolved_api_key = api_key or os.getenv("LION_API_KEY") or None
    resolved_api_url = api_url or os.getenv("LION_API_URL") or None
    resolved_model = model or os.getenv("LION_MODEL") or None

    _env_timeout = os.getenv("LION_TIMEOUT")
    resolved_timeout = timeout or (int(_env_timeout) if _env_timeout else None)

    # verify_ssl：将环境变量字符串转换为布尔值，未设置时保持 None
    if verify_ssl is not None:
        resolved_verify_ssl = verify_ssl
    else:
        _env_ssl = (os.getenv("LION_VERIFY_SSL") or "").strip().lower()
        if _env_ssl in ("false", "0", "no"):
            resolved_verify_ssl = False
        elif _env_ssl in ("true", "1", "yes"):
            resolved_verify_ssl = True
        else:
            resolved_verify_ssl = None  # 未设置，交 llmdog 决定

    # cookie_file：本地参数，保留默认值
    resolved_cookie = cookie_file or os.getenv("LION_COOKIE_FILE", _DEFAULT_COOKIE_FILE)

    return LionConfig(
        api_key=resolved_api_key,
        api_url=resolved_api_url,
        model=resolved_model,
        timeout=resolved_timeout,
        verify_ssl=resolved_verify_ssl,
        cookie_file=resolved_cookie,
    )


def get_llm_config(cfg: LionConfig) -> dict:
    """
    将 LionConfig 转换为 llmdog.config.load_config() 所需的关键字参数。

    仅包含已显式配置的字段（非 None / 非空字符串）；
    未配置的字段交由 llmdog 使用其内置默认值。

    返回字段（均为可选，已配置时才包含）：
      - api_key / api_url / model / timeout / verify_ssl

    用法示例::

        from llmdog.config import load_config as llm_load_config
        from linkedin_lion.config import load_config, get_llm_config

        lion_cfg = load_config()
        llm_cfg  = llm_load_config(**get_llm_config(lion_cfg))
        # 若未配置任何 LLM 参数，等价于: llm_load_config()

    :param cfg: LionConfig 实例
    :return:    仅含已配置字段的字典（可能为空字典）
    """
    result: dict = {}
    if cfg.api_key:                   # 非空字符串且非 None
        result["api_key"] = cfg.api_key
    if cfg.api_url:                   # 非空字符串且非 None
        result["api_url"] = cfg.api_url
    if cfg.model:                     # 非空字符串且非 None
        result["model"] = cfg.model
    if cfg.timeout is not None:       # int 用 is not None（振除 0 的歧义）
        result["timeout"] = cfg.timeout
    if cfg.verify_ssl is not None:    # bool 用 is not None
        result["verify_ssl"] = cfg.verify_ssl
    return result


def ensure_api_key(cfg: LionConfig) -> bool:
    """
    检查 api_key 是否已配置。

    :param cfg: LionConfig 实例
    :return: True 表示已配置，False 表示缺失
    """
    return bool(cfg.api_key and cfg.api_key.strip())


def validate_cookie_file(cookie_file: str) -> Optional[str]:
    """
    验证 cookie 文件是否存在。

    :param cookie_file: Cookie 文件路径
    :return: 文件存在返回 None，不存在返回详细错误提示字符串
    """
    path = Path(cookie_file)
    if path.exists():
        return None

    return (
        f"No cookies file found, please login first, default: {_DEFAULT_COOKIE_FILE}\n\n"
        f"Current specified path: {cookie_file}\n\n"
        f"Configuration priority (high → low):\n"
        f"  1. CLI option:   lion scrape <url> --cookie <path>\n"
        f"                   lion batch <file> --cookie <path>\n"
        f"  2. Environment:  LION_COOKIE_FILE=<path>  (in .env file)\n"
        f"  3. Default:      {_DEFAULT_COOKIE_FILE}\n\n"
        f"How to prepare cookie.json:\n"
        f"  1. Log in to LinkedIn via your browser\n"
        f"  2. Export cookies using a browser extension (e.g., Cookie-Editor) as JSON format\n"
        f"  3. Save the file to the specified path\n\n"
        f".env file example:\n"
        f"  LION_COOKIE_FILE=/path/to/your/cookie.json"
    )
