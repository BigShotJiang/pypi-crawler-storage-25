"""
commands/batch.py — 批量 LinkedIn 个人资料抓取模块

核心功能：
  - batch_scrape()   读取 URL 列表文件，逐条抓取并保存为 .txt 文件

CLI 命令（由 cli.py 注册）：
  lion batch <filepath> [选项]

整合自 001_linkedin_profile_downloader，依赖 scrape.py 的 login / scrape_profile 函数。
所有终端输出通过 linkedin_lion.output 统一输出。
"""

import os
from typing import Optional
from urllib.parse import unquote

import typer
from diskcache import Cache

from linkedin_lion.output import (
    print_error,
    print_header,
    print_info,
    print_success,
    print_table,
    print_warning,
)
from linkedin_lion.config import load_config
from linkedin_lion.commands.scrape import login, scrape_profile

# ==================== 可选依赖（降级处理）====================

try:
    from larkfunc.io import read_txt_to_list
    from larkfunc.text import extract_linkedin_id
except ImportError:
    import re as _re

    def read_txt_to_list(filepath: str):  # type: ignore[misc]
        """按行读取文本文件（降级实现）"""
        with open(filepath, "r", encoding="utf-8") as f:
            return [line.rstrip("\n") for line in f if line.strip()]

    def extract_linkedin_id(url: str) -> str:  # type: ignore[misc]
        """从 LinkedIn URL 提取用户 ID（降级实现）"""
        match = _re.search(r"/in/([^/?#]+)", url)
        return match.group(1).rstrip("/") if match else ""


# ==================== Typer App ====================

app = typer.Typer(
    name="batch",
    help="从 URL 列表文件批量抓取 LinkedIn Talent 个人资料，保存为 .txt 文件。",
    no_args_is_help=True,
)


# ==================== 内部辅助函数 ====================


def _get_profile_urn(linkedin_url: str, cache_dir: str) -> Optional[str]:
    """
    从本地 diskcache 缓存中获取 LinkedIn Profile URN。

    :param linkedin_url: 原始 LinkedIn URL（作为缓存键）
    :param cache_dir:    diskcache 缓存目录路径
    :return:             URN 字符串，缓存未命中返回 None
    """
    with Cache(cache_dir) as cache:
        result = cache.get(linkedin_url)
        if result:
            print_info(f"缓存命中：{linkedin_url}  →  URN: {result}")
        else:
            print_warning(f"缓存未命中：{linkedin_url}")
        return result


def _file_already_exists(linkedin_id: str, output_dir: str) -> bool:
    """
    检查该 ID 对应的 .txt 文件是否已存在（兼容 URL 编码差异）。

    :param linkedin_id: LinkedIn 用户 ID
    :param output_dir:  输出目录
    :return:            True 表示文件已存在，可跳过
    """
    path1 = os.path.join(output_dir, f"{linkedin_id}.txt")
    path2 = os.path.join(output_dir, f"{unquote(linkedin_id)}.txt")
    return os.path.exists(path1) or os.path.exists(path2)


# ==================== 核心函数（可导入）====================


def batch_scrape(
    filepath: str,
    output_dir: str = "./output",
    headless: bool = False,
    start: int = 0,
    end: Optional[int] = None,
    cookie_file: str = "cookie.json",
    cache_dir: str = "",
) -> bool:
    """
    批量抓取 LinkedIn Talent Profile 列表，提取纯文本保存为 .txt 文件。

    工作流：
      1. 读取 filepath 中的 URL 列表（每行一个 URL）
      2. 按 [start, end) 范围截取处理片段
      3. 从 diskcache 中获取每个 URL 对应的 Talent URN
      4. 调用 scrape_profile() 完成页面抓取与文本提取
      5. 已存在的文件自动跳过

    :param filepath:   URL 列表文件路径（每行一个 LinkedIn URL）
    :param output_dir: 输出目录（默认 ./output）
    :param headless:   无头模式（默认 False）
    :param start:      起始索引（从 0 开始，默认 0）
    :param end:        结束索引（不含，默认处理到文件末尾）
    :param cookie_file: Selenium Cookie 文件路径
    :param cache_dir:   diskcache 缓存目录路径（空字符串则跳过 URN 查询）
    :return:            全部处理完成返回 True，发生致命错误返回 False
    """
    # -- 验证输入文件 --
    if not os.path.exists(filepath):
        print_error(f"文件不存在：{filepath}")
        return False

    os.makedirs(output_dir, exist_ok=True)

    data_list = read_txt_to_list(filepath)
    if not data_list:
        print_warning("输入文件为空，无数据可处理。")
        return False

    # -- 验证并修正索引范围 --
    total = len(data_list)
    if start < 0:
        print_error("start 不能为负数。")
        return False
    if end is None:
        end = total
    if end > total:
        print_warning(f"end（{end}）超出文件行数（{total}），已自动调整为 {total}。")
        end = total
    if start >= end:
        print_error(f"start（{start}）必须小于 end（{end}）。")
        return False

    print_header("LinkedIn 批量个人资料抓取")
    print_info(f"输入文件：{filepath}")
    print_info(f"输出目录：{output_dir}")
    print_info(f"处理范围：第 {start + 1} 到 {end} 条（共 {end - start} 条）")

    # -- 初始化 WebDriver（统一登录一次）--
    driver = login(cookie_file=cookie_file, headless=headless)

    stats = {"success": 0, "skip": 0, "fail": 0}

    try:
        for idx in range(start, end):
            raw_url = data_list[idx].strip()
            if not raw_url:
                continue

            print_info(f"[{idx + 1}/{total}] 处理：{raw_url}")

            # 提取 LinkedIn ID
            linkedin_id = extract_linkedin_id(raw_url)
            if not linkedin_id:
                print_warning(f"无法提取 LinkedIn ID，跳过：{raw_url}")
                stats["fail"] += 1
                continue

            # 已存在则跳过
            if _file_already_exists(linkedin_id, output_dir):
                print_info(f"文件已存在，跳过：{linkedin_id}.txt")
                stats["skip"] += 1
                continue

            # 从缓存获取 Talent URN（若未配置 cache_dir 则直接使用原 URL）
            if cache_dir:
                urn = _get_profile_urn(raw_url, cache_dir)
                if not urn:
                    print_warning(f"缓存中未找到 URN，跳过：{raw_url}")
                    stats["fail"] += 1
                    continue
                final_url = (
                    f"https://www.linkedin.com/talent/profile/{urn}"
                    "?trk=FLAGSHIP_VIEW_IN_RECRUITER"
                )
            else:
                # 未配置缓存时直接使用原 URL（适用于 Talent Profile 直链）
                final_url = raw_url

            print_info(f"目标链接：{final_url}")

            try:
                result = scrape_profile(driver, final_url, f"{linkedin_id}.txt", output_dir)
                if result:
                    print_success(f"成功：{linkedin_id}")
                    stats["success"] += 1
                else:
                    print_error(f"抓取无内容：{linkedin_id}")
                    stats["fail"] += 1
            except Exception as exc:
                print_error(f"处理失败（索引 {idx + 1}）：{exc}")
                stats["fail"] += 1

    finally:
        try:
            driver.quit()
            print_info("浏览器已关闭。")
        except Exception:
            pass

    # -- 汇总报告 --
    print_table(
        columns=["状态", "数量"],
        rows=[
            ["✓ 成功", str(stats["success"])],
            ["⏭  跳过", str(stats["skip"])],
            ["✗ 失败", str(stats["fail"])],
            ["合计", str(stats["success"] + stats["skip"] + stats["fail"])],
        ],
        title="批量抓取汇总",
    )

    return stats["fail"] == 0


# ==================== CLI 命令 ====================


@app.command()
def run(
    filepath: str = typer.Argument(..., help="URL 列表文件路径（每行一个 LinkedIn URL）"),
    output_dir: str = typer.Option("./output", "--output-dir", "-o", help="输出目录"),
    headless: bool = typer.Option(False, "--headless", help="无头模式（不显示浏览器）"),
    start: int = typer.Option(0, "--start", "-s", help="起始索引（从 0 开始）"),
    end: Optional[int] = typer.Option(None, "--end", "-e", help="结束索引（不含，默认到末尾）"),
    cookie: str = typer.Option(
        "",
        "--cookie",
        "-c",
        help="Cookie 文件路径（默认读取 .env 中 LION_COOKIE_FILE 或 cookie.json）",
    ),
    cache_dir: str = typer.Option(
        "",
        "--cache-dir",
        help="diskcache 缓存目录路径（含 Talent URN 映射，留空则直接使用原 URL）",
    ),
) -> None:
    """
    从 URL 列表文件批量抓取 LinkedIn Talent 个人资料。

    示例::

        lion batch urls.txt --output-dir ./resumes --start 0 --end 50
        lion batch urls.txt --output-dir ./resumes --cache-dir /path/to/cache
    """
    cfg = load_config(cookie_file=cookie or None)
    effective_cookie = cfg.cookie_file

    ok = batch_scrape(
        filepath=filepath,
        output_dir=output_dir,
        headless=headless,
        start=start,
        end=end,
        cookie_file=effective_cookie,
        cache_dir=cache_dir,
    )

    if ok:
        print_success("所有任务完成！")
    else:
        print_error("部分任务失败，请查看上方日志。")
        raise typer.Exit(code=1)
