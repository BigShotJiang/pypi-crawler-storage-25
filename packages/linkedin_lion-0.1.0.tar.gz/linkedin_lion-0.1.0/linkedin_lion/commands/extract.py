"""
commands/extract.py — LLM 简历信息结构化提取模块

核心功能：
  - extract_resume()   读取 .txt 简历文件，调用 LLM 提取结构化 JSON 并保存

CLI 命令（由 cli.py 注册）：
  lion extract <input_path> [选项]

整合自 003_resume_extractor_llm，LLM 调用通过 llmdog + 配置文件（.env）管理。
所有终端输出通过 linkedin_lion.output 统一输出。
"""

import json
import os
import time
from pathlib import Path
from typing import List, Optional

import typer

from linkedin_lion.config import ensure_api_key, get_llm_config, load_config
from linkedin_lion.output import (
    print_error,
    print_header,
    print_info,
    print_separator,
    print_success,
    print_table,
    print_warning,
)

# ==================== 可选依赖（降级处理）====================

try:
    from llmdog import chat as _llmdog_chat
    from llmdog.config import load_config as _llm_load_config

    _llmdog_available = True
except ImportError:
    _llmdog_available = False

try:
    from larkfunc import read_txt_data
except ImportError:
    def read_txt_data(filepath: str) -> str:  # type: ignore[misc]
        """读取文本文件内容（降级实现）"""
        with open(filepath, "r", encoding="utf-8") as f:
            return f.read()

# ==================== 默认 Prompt 模板 ====================

DEFAULT_PROMPT_TEMPLATE = """
####
整理以上简历，json格式返回，按照如下格式

{
  "name": "",
  "title": "",
  "company": "",
  "position": "",
  "location": "",
  "email": "",
  "phone": "",
  "linkedin": "",
  "github": "",
  "google_scholar": "",
  "homepage": "",
  "summary": "",
  "bio_summary": "本科毕业于XX的XX专业，最高学历是XX，毕业于XX学校XX专业，毕业XX年，现在XX公司担任XX，主要负责XX，擅长技术方向XX，此前在XX公司担任XX，主要负责XX",
  "open_to_work": "",
  "skills": ["", "", "..."],
  "suitable_job_roles": [],
  "experience": [
    {
      "company": "",
      "title": "",
      "duration": "",
      "positions": [
        {
          "title": "",
          "start_date": "year-month",
          "end_date": "year-month",
          "location": "",
          "responsibilities": ["", ""],
          "achievements": ["", ""]
        }
      ]
    }
  ],
  "education": [
    {
      "school": "",
      "degree": "(Bachelor/Master/PhD)",
      "field": "",
      "dates": "year - year"
    }
  ],
  
}

#### 严格按照json格式返回，不包含任何解释性字符
"""

# ==================== Prompt 模板生成 ====================

_PROMPT_FILE_HEADER = """\
# ============================================================================
# LinkedIn-Lion 简历结构化提取 —— Prompt 模板文件
# ============================================================================
# 此文件由 `lion extract run --generate-prompt` 自动生成。
# 你可以直接编辑本文件来自定义 LLM 提取行为，然后通过以下命令使用：
#
#   lion extract run ./resumes --prompt-file prompt.txt
#
# 【模板使用规则】
#   1. 保持 JSON 结构完整，字段名不可更改，否则下游解析会失败
#   2. 修改字段值作为示例/提示，指导 LLM 如何填写各字段
#   3. 在 `####` 之后的说明文字会被附加到简历文本后一起发送给 LLM
#
# 【字段详细说明】
#   name              : 候选人姓名（如：张三）
#   title             : 当前职位头衔（如：高级软件工程师）
#   company           : 当前所在公司名称
#   position          : 当前职位（与 title 类似，更侧重岗位名称）
#   location          : 所在城市/地区（如：北京 / 上海）
#   email             : 联系邮箱地址
#   phone             : 联系电话
#   linkedin          : LinkedIn 个人主页完整 URL
#   github            : GitHub 主页 URL
#   google_scholar    : Google Scholar 学术主页 URL
#   homepage          : 个人主页/博客 URL
#   summary           : 简历摘要或个人简介（多行文本）
#   bio_summary       : 一句话生物简介，概括教育背景、工作年限、现任公司和专长方向
#   open_to_work      : 是否正在寻找新机会（是/否/Open to work）
#   skills            : 技能列表，字符串数组（如：["Python", "机器学习"]）
#   suitable_job_roles: 适合的职位角色列表，字符串数组（如：["算法工程师", "研究员"]）
#   experience        : 工作经历数组，每个元素代表一段公司经历
#     - company       : 公司名称
#     - title         : 在该公司的总职位头衔
#     - duration      : 总在职时长（如：2020.03 - 至今）
#     - positions     : 职位变动明细列表
#       - title       : 具体职位名称
#       - start_date  : 开始时间，格式 year-month（如：2020-03）
#       - end_date    : 结束时间，格式 year-month；在职写 present
#       - location    : 该职位的工作地点
#       - responsibilities : 职责描述，字符串数组
#       - achievements     : 主要成就/业绩，字符串数组
#   education         : 教育经历数组
#     - school        : 学校名称
#     - degree        : 学位级别（Bachelor / Master / PhD）
#     - field         : 专业/领域
#     - dates         : 就读时间，格式 year - year（如：2015 - 2019）
#   recently_viewed_by: 最近查看过该候选人资料的招聘人员列表
#     - name          : 查看者姓名
#     - date          : 查看日期
#     - time          : 查看时间
# ============================================================================
"""

DEFAULT_PROMPT_FILE_NAME = "prompt.txt"


def _generate_prompt_file(output_path: str = DEFAULT_PROMPT_FILE_NAME) -> None:
    """
    在当前目录生成带有详细注释的默认 prompt 模板文件。

    :param output_path: 输出文件路径，默认 prompt.txt
    :raises RuntimeError: 写入失败时抛出
    """
    content = _PROMPT_FILE_HEADER + DEFAULT_PROMPT_TEMPLATE
    path = Path(output_path)
    try:
        path.write_text(content, encoding="utf-8")
        print_success(f"默认 prompt 模板已生成：{path.resolve()}")
        print_info("编辑此文件后，使用 --prompt-file 参数指定自定义模板")
    except Exception as exc:
        raise RuntimeError(f"生成 prompt 模板文件失败：{exc}") from exc

# ==================== Typer App ====================

app = typer.Typer(
    name="extract",
    help="使用 LLM 从 .txt 简历文件中提取结构化 JSON 信息。",
    no_args_is_help=True,
)


# ==================== 内部辅助函数 ====================


def _clean_llm_response(response: str) -> str:
    """
    清理 LLM 返回的响应，移除代码块标记（```json ... ```）。

    :param response: LLM 原始返回文本
    :return:         清理后的纯 JSON 字符串
    """
    cleaned = response.strip()
    if cleaned.startswith("```json"):
        cleaned = cleaned[7:].strip()
    elif cleaned.startswith("```"):
        cleaned = cleaned[3:].strip()
    if cleaned.endswith("```"):
        cleaned = cleaned[:-3].strip()
    return cleaned


def _parse_json_safely(json_str: str) -> dict:
    """
    安全解析 JSON 字符串，包含错误处理。

    :param json_str: JSON 字符串
    :return:         解析成功返回字典，失败返回空字典
    """
    try:
        return json.loads(json_str)
    except json.JSONDecodeError as exc:
        print_error(f"JSON 解析失败：{exc}")
        print_warning(f"原始内容前 200 字符：{json_str[:200]}")
        return {}


def _save_json(data: dict, output_path: str) -> bool:
    """
    将字典数据保存为 JSON 文件。

    :param data:        待保存的字典
    :param output_path: 输出文件路径
    :return:            成功返回 True，失败返回 False
    """
    try:
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        print_success(f"JSON 已保存：{output_path}")
        return True
    except Exception as exc:
        print_error(f"保存文件失败 {output_path}：{exc}")
        return False


def _call_llm_with_retry(
    content: str,
    prompt_template: str,
    max_retries: int,
    llm_cfg,
) -> str:
    """
    调用 LLM（llmdog.chat）并支持自动重试。

    :param content:         简历文本内容
    :param prompt_template: 提示模板
    :param max_retries:     最大重试次数
    :param llm_cfg:         llmdog 配置对象
    :return:                LLM 返回的原始文本，失败返回空字符串
    """
    if not _llmdog_available:
        raise RuntimeError("缺少依赖，请运行：pip install llmdog")

    full_prompt = content + prompt_template

    for attempt in range(1, max_retries + 1):
        try:
            print_info(f"正在调用 LLM（第 {attempt}/{max_retries} 次）...")
            response = _llmdog_chat(full_prompt, config=llm_cfg)
            if response and isinstance(response, str):
                print_success(f"LLM 调用成功，返回长度：{len(response)} 字符")
                return response
            else:
                print_warning("LLM 返回无效（空或非字符串），将重试")
        except Exception as exc:
            print_error(f"LLM 调用异常（第 {attempt} 次）：{exc}")
            if attempt < max_retries:
                time.sleep(2)

    print_error(f"LLM 调用失败，已达最大重试次数（{max_retries}）")
    return ""


def _process_single_file(
    input_path: str,
    output_dir: str,
    max_retries: int,
    prompt_template: str,
    llm_cfg,
) -> bool:
    """
    处理单个 .txt 简历文件：读取 → LLM 提取 → JSON 保存。

    :param input_path:      输入文件路径
    :param output_dir:      输出目录
    :param max_retries:     LLM 重试次数
    :param prompt_template: 提示模板
    :param llm_cfg:         llmdog 配置对象
    :return:                成功返回 True，失败返回 False
    """
    print_info(f"正在处理：{input_path}")
    stem = Path(input_path).stem
    output_path = os.path.join(output_dir, f"{stem}.json")
    if os.path.exists(output_path):
        print_warning(f"跳过：{output_path} 已存在")
        return False

    content = read_txt_data(input_path)
    if not content or not content.strip():
        print_warning(f"文件为空，跳过：{input_path}")
        return False

    raw_response = _call_llm_with_retry(content, prompt_template, max_retries, llm_cfg)
    if not raw_response:
        print_error(f"LLM 未返回有效结果，跳过：{input_path}")
        return False

    cleaned = _clean_llm_response(raw_response)
    parsed = _parse_json_safely(cleaned)
    if not parsed:
        print_error(f"无法解析 JSON，跳过：{input_path}")
        return False

    
    return _save_json(parsed, output_path)


def _collect_txt_files(input_path: str) -> List[str]:
    """
    收集待处理的 .txt 文件列表。

    :param input_path: 单个 .txt 文件路径 或 包含 .txt 文件的目录
    :return:           文件路径列表
    :raises ValueError: 路径无效时抛出
    """
    path = Path(input_path)
    if path.is_file() and path.suffix.lower() == ".txt":
        return [str(path)]
    elif path.is_dir():
        files = sorted(path.glob("*.txt"))
        return [str(f) for f in files if f.is_file()]
    else:
        raise ValueError(
            f"输入路径无效：{input_path}\n请提供 .txt 文件或包含 .txt 文件的目录"
        )


# ==================== 核心函数（可导入）====================


def extract_resume(
    input_path: str,
    output_dir: str = "./output",
    max_retries: int = 3,
    prompt_template: Optional[str] = None,
) -> None:
    """
    简历信息结构化提取核心函数，可被其他脚本直接导入调用。

    工作流：
      1. 从 .env / 环境变量读取 LLM 配置（LION_API_KEY / LION_API_URL / LION_MODEL / LION_TIMEOUT / LION_VERIFY_SSL）
      2. 收集输入目录下所有 .txt 文件（或单文件）
      3. 逐个调用 LLM 提取结构化 JSON
      4. 保存到 output_dir，文件名与 .txt 同名，扩展名改为 .json

    :param input_path:      输入路径（单个 .txt 文件 或 含 .txt 文件的目录）
    :param output_dir:      输出 JSON 目录（默认 ./output）
    :param max_retries:     LLM 失败重试次数（默认 3）
    :param prompt_template: 自定义提示模板（None 则使用内置默认模板）
    """
    if not _llmdog_available:
        print_error("缺少依赖 llmdog，请运行：pip install llmdog")
        return

    lion_cfg = load_config()
    if not ensure_api_key(lion_cfg):
        print_warning(
            "未检测到 LION_API_KEY，将尝试使用 llmdog 内置配置。\n"
            "如需显式配置，请在 .env 文件中设置：LION_API_KEY=sk-xxxx"
        )

    llm_cfg = _llm_load_config(**get_llm_config(lion_cfg))

    print_header("简历信息结构化提取工具")
    print_info(f"LLM 模型：{lion_cfg.model}")

    os.makedirs(output_dir, exist_ok=True)

    try:
        txt_files = _collect_txt_files(input_path)
    except ValueError as exc:
        print_error(str(exc))
        return

    if not txt_files:
        print_warning(f"未找到任何 .txt 文件：{input_path}")
        return

    print_info(f"共找到 {len(txt_files)} 个简历文件，开始处理...")
    print_separator()

    effective_prompt = prompt_template if prompt_template is not None else DEFAULT_PROMPT_TEMPLATE

    stats = {"success": 0, "fail": 0}
    for file_path in txt_files:
        ok = _process_single_file(
            file_path, output_dir, max_retries, effective_prompt, llm_cfg
        )
        if ok:
            stats["success"] += 1
        else:
            stats["fail"] += 1

    print_separator()
    print_table(
        columns=["状态", "数量"],
        rows=[
            ["✓ 成功", str(stats["success"])],
            ["✗ 失败", str(stats["fail"])],
            ["合计", str(len(txt_files))],
        ],
        title="提取汇总",
    )
    print_success(f"所有简历处理完成！输出目录：{output_dir}")


# ==================== CLI 命令 ====================


@app.command()
def run(
    input_path: str = typer.Argument(
        "",
        help="输入路径：单个 .txt 文件 或 含 .txt 文件的目录",
    ),
    output_dir: str = typer.Option(
        "./output", "--output", "-o", help="输出 JSON 文件目录（默认 ./output）"
    ),
    max_retries: int = typer.Option(
        3, "--max-retries", "-r", help="LLM 请求失败时的最大重试次数（默认 3）"
    ),
    prompt_file: Optional[Path] = typer.Option(
        None,
        "--prompt-file",
        "-p",
        help="自定义提示模板文件路径（.txt，留空使用内置模板）",
    ),
    generate_prompt: bool = typer.Option(
        False,
        "--generate-prompt",
        "-g",
        help="在当前目录生成默认 prompt 模板文件 prompt.txt 并退出",
    ),
) -> None:
    """
    使用 LLM 从 .txt 简历中提取结构化 JSON 信息。

    示例::

        lion extract ./resumes --output ./json_output
        lion extract resume.txt --output ./json_output --max-retries 5
        lion extract ./resumes --prompt-file my_prompt.txt
        lion extract run --generate-prompt
    """
    if generate_prompt:
        _generate_prompt_file()
        raise typer.Exit(code=0)

    if not input_path:
        print_error("缺少输入路径，请提供 .txt 文件或包含 .txt 文件的目录")
        print_info("使用 --help 查看详细用法，或使用 --generate-prompt 生成模板")
        raise typer.Exit(code=1)

    custom_prompt: Optional[str] = None
    if prompt_file:
        try:
            custom_prompt = prompt_file.read_text(encoding="utf-8")
            print_info(f"已加载自定义提示模板：{prompt_file}")
        except Exception as exc:
            print_error(f"读取提示模板文件失败：{exc}")
            raise typer.Exit(code=1)

    extract_resume(
        input_path=input_path,
        output_dir=output_dir,
        max_retries=max_retries,
        prompt_template=custom_prompt,
    )
