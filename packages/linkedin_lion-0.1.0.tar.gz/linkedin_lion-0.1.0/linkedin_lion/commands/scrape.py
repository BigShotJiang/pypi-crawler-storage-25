"""
commands/scrape.py — 单个 LinkedIn 个人资料抓取模块

核心功能：
  - login()          初始化 Selenium WebDriver，通过 Cookie 登录 LinkedIn Talent
  - scrape_profile() 访问指定 Profile URL，提取纯文本并保存为 .txt 文件

CLI 命令（由 cli.py 注册）：
  lion scrape <profile_url> [选项]

整合自 002_linkedin_scraper，所有终端输出通过 linkedin_lion.output 统一输出。
"""

import os
import re
import time
from typing import Optional

import typer
from rich.progress import Progress, SpinnerColumn, TextColumn

from linkedin_lion.output import (
    console,
    print_error,
    print_header,
    print_info,
    print_success,
    print_warning,
)
from linkedin_lion.config import load_config, validate_cookie_file

# ==================== 可选依赖（降级处理）====================

try:
    from bs4 import BeautifulSoup
    from selenium.webdriver.common.action_chains import ActionChains
    from selenium.webdriver.common.by import By
    from selenium.webdriver.support import expected_conditions as EC
    from selenium.webdriver.support.ui import WebDriverWait
    from browser_dog.browser import BrowserDog

    _selenium_available = True
except ImportError as _e:
    _selenium_available = False
    _import_error_msg = str(_e)

try:
    from larkfunc.text import extract_linkedin_id
except ImportError:
    # 内置降级实现
    import re as _re

    def extract_linkedin_id(url: str) -> str:  # type: ignore[misc]
        """从 LinkedIn URL 中提取用户 ID（降级实现）"""
        match = _re.search(r"/in/([^/?#]+)", url)
        return match.group(1).rstrip("/") if match else ""


# ==================== Typer App ====================

app = typer.Typer(
    name="scrape",
    help="抓取单个 LinkedIn Talent 个人资料，提取纯文本保存为 .txt 文件。",
    no_args_is_help=True,
)


# ==================== 核心函数（可导入）====================


def login(cookie_file: str = "cookie.json", headless: bool = False):
    """
    初始化 BrowserDog，通过 Cookie 文件登录 LinkedIn Talent。

    :param cookie_file: Cookie JSON 文件路径（默认 cookie.json）
    :param headless:    是否无头模式（默认 False，显示浏览器窗口）
    :return:            已登录的 Selenium WebDriver 实例
    :raises RuntimeError: selenium/browser-dog 未安装时抛出
    """
    if not _selenium_available:
        raise RuntimeError(
            f"缺少依赖，请运行：pip install selenium browser-dog\n原因：{_import_error_msg}"
        )

    error = validate_cookie_file(cookie_file)
    if error:
        print_error(error)
        raise RuntimeError("No cookies file found, please login first")

    print_info("正在初始化 BrowserDog 客户端...")
    cat = BrowserDog(cookie_file, "https://www.linkedin.com/talent/home", headless=headless)
    driver = cat.get_driver()
    driver.maximize_window()

    print_info("正在打开 LinkedIn Talent 首页...")
    driver.get("https://www.linkedin.com/talent/home")
    cat.long_wait()

    print_success("已成功登录 LinkedIn Talent")
    return driver


def _extract_text_from_page(driver, filename: str, folder: str) -> str:
    """
    从当前页面的 #profile-container 提取纯文本并保存。

    :param driver:   已打开目标页面的 WebDriver
    :param filename: 保存文件名（备用，若能提取 linkedin_id 则以 id 命名）
    :param folder:   保存目录
    :return:         提取的纯文本，失败返回空字符串
    """
    os.makedirs(folder, exist_ok=True)
    default_path = os.path.join(folder, filename)

    # 如果文件已存在则直接读取缓存
    if os.path.exists(default_path):
        print_info(f"跳过已存在的文件：{default_path}")
        with open(default_path, "r", encoding="utf-8") as f:
            return f.read()

    target_id = "profile-container"
    print_info(f"正在定位页面元素：<div id='{target_id}'>")

    try:
        element = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.ID, target_id))
        )
        print_success(f"成功找到目标元素：#{target_id}")

        html_content = element.get_attribute("innerHTML")
        soup = BeautifulSoup(html_content, "html.parser")
        text_only = soup.get_text(separator="\n", strip=True)
        text_only = re.sub(r"\n+", "\n", text_only).strip()

        # 尝试从页面链接提取 LinkedIn ID 以精准命名文件
        link = soup.find("a", {"data-test-personal-info-profile-link": ""})
        if link:
            href = link.get("href", "")
            linkedin_id = extract_linkedin_id(href)
            if linkedin_id:
                save_path = os.path.join(folder, f"{linkedin_id}.txt")
                print_info(f"检测到 LinkedIn ID：{linkedin_id}，将以 ID 命名文件")
            else:
                save_path = default_path
        else:
            save_path = default_path

        with open(save_path, "w", encoding="utf-8") as f:
            f.write(text_only)
        print_success(f"文本已保存至：{save_path}")
        return text_only

    except Exception as exc:
        print_error(f"提取失败：无法找到或解析 #{target_id}。原因：{exc}")
        return ""


def scrape_profile(
    driver,
    profile_url: str,
    filename: str = "linkedin_resume.txt",
    folder: str = ".",
) -> Optional[str]:
    """
    访问 LinkedIn Talent Profile 页面，点击「更多操作」后提取纯文本。

    :param driver:      已登录的 Selenium WebDriver
    :param profile_url: LinkedIn Talent Profile 完整 URL
    :param filename:    备用保存文件名
    :param folder:      输出目录（默认当前目录）
    :return:            提取的纯文本字符串，失败返回 None
    """
    if not _selenium_available:
        raise RuntimeError("缺少依赖，请运行：pip install selenium browser-dog beautifulsoup4")

    print_header("LinkedIn 个人资料抓取")

    try:
        print_info(f"正在访问：{profile_url}")
        driver.get(profile_url)
        time.sleep(5)

        print_info("正在寻找并点击「更多操作」按钮...")
        more_button = WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.CLASS_NAME, "more-actions__trigger"))
        )
        ActionChains(driver).move_to_element(more_button).click().perform()
        print_success("已点击「更多操作」按钮")

        # 带进度动画等待页面加载
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
            transient=True,
        ) as progress:
            task = progress.add_task("正在等待页面加载...", total=8)
            for _ in range(8):
                progress.advance(task)
                time.sleep(1)

        print_info("正在提取个人资料纯文本...")
        text_content = _extract_text_from_page(driver, filename, folder)

        if text_content:
            print_success("个人资料提取完成！")
            return text_content
        else:
            print_error("未能成功提取文本内容。")
            return None

    except Exception as exc:
        print_error(f"操作失败：{exc}")
        return None


# ==================== CLI 命令 ====================


@app.command()
def run(
    profile_url: str = typer.Argument(..., help="LinkedIn Talent Profile 完整 URL"),
    filename: str = typer.Option(
        "linkedin_resume.txt",
        "--filename",
        "-f",
        help="备用保存文件名（若能提取 ID 则以 ID 命名）",
    ),
    folder: str = typer.Option(".", "--folder", "-d", help="输出目录（默认当前目录）"),
    cookie: str = typer.Option(
        "",
        "--cookie",
        "-c",
        help="Cookie 文件路径（默认读取 .env 中 LION_COOKIE_FILE 或 cookie.json）",
    ),
    headless: bool = typer.Option(False, "--headless", help="无头模式（不显示浏览器）"),
) -> None:
    """
    抓取单个 LinkedIn Talent Profile，将纯文本保存到本地 .txt 文件。

    示例::

        lion scrape https://www.linkedin.com/talent/profile/ACoAAA... --folder ./output
    """
    cfg = load_config(cookie_file=cookie or None)
    effective_cookie = cfg.cookie_file

    if not _selenium_available:
        print_error("缺少必要依赖，请运行：pip install linkedin-lion[selenium]")
        raise typer.Exit(code=1)

    driver = login(cookie_file=effective_cookie, headless=headless)
    try:
        result = scrape_profile(driver, profile_url, filename, folder)
        if result:
            print_success("抓取成功，文本已保存。")
        else:
            print_error("抓取失败，请检查 URL 和 Cookie 文件是否有效。")
            raise typer.Exit(code=1)
    finally:
        try:
            driver.quit()
            print_info("浏览器已关闭。")
        except Exception:
            pass
