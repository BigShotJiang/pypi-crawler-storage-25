"""
linkedin_lion — LinkedIn Talent 抓取 & LLM 简历结构化提取工具包

公开 API：
    login           初始化 Selenium WebDriver 并登录 LinkedIn Talent
    scrape_profile  抓取单个 LinkedIn Talent Profile，提取纯文本
    batch_scrape    批量抓取 LinkedIn Talent Profile 列表
    extract_resume  使用 LLM 提取 .txt 简历结构化 JSON

快速开始（Python 导入方式）::

    from linkedin_lion import login, scrape_profile, batch_scrape, extract_resume

    # 单个抓取
    driver = login(cookie_file="cookie.json")
    text = scrape_profile(driver, "https://www.linkedin.com/talent/profile/...", folder="./output")
    driver.quit()

    # 批量抓取
    batch_scrape("urls.txt", output_dir="./resumes")

    # LLM 提取（需在 .env 中配置 LION_API_KEY）
    extract_resume("./resumes", output_dir="./json_output")
"""

from linkedin_lion.commands.batch import batch_scrape
from linkedin_lion.commands.extract import extract_resume
from linkedin_lion.commands.scrape import login, scrape_profile

__version__ = "0.1.0"
__all__ = [
    "login",
    "scrape_profile",
    "batch_scrape",
    "extract_resume",
]
