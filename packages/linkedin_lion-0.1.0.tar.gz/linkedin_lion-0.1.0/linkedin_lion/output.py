"""
output.py — 统一 Rich 终端输出层

遵循 DESIGN_SPEC.md §3.1 配色规范：
  info      → cyan
  success   → bold bright_green
  warning   → bold bright_yellow
  error     → bold bright_red
  highlight → bold magenta
  dim       → dim white

所有模块必须通过本文件的函数输出，禁止裸 print()。
"""

from typing import List, Sequence

from rich import box
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from rich.theme import Theme

# ==================== 全局 Console（统一配色主题）====================

custom_theme = Theme(
    {
        "info": "cyan",
        "success": "bold bright_green",
        "warning": "bold bright_yellow",
        "error": "bold bright_red",
        "highlight": "bold magenta",
        "dim": "dim white",
    }
)

console = Console(theme=custom_theme)
err_console = Console(stderr=True, theme=custom_theme)


# ==================== 基础输出函数 ====================


def print_info(msg: str) -> None:
    """输出蓝绿色信息（ℹ）"""
    console.print(f"ℹ  {msg}", style="info")


def print_success(msg: str) -> None:
    """输出亮绿色成功信息（✓）"""
    console.print(f"✓  {msg}", style="success")


def print_warning(msg: str) -> None:
    """输出亮黄色警告信息（⚠）"""
    console.print(f"⚠  {msg}", style="warning")


def print_error(msg: str) -> None:
    """输出亮红色错误信息（✗），写入 stderr"""
    err_console.print(f"✗  {msg}", style="error")


def print_highlight(msg: str) -> None:
    """输出品红高亮信息"""
    console.print(msg, style="highlight")


def print_dim(msg: str) -> None:
    """输出低对比度补充信息"""
    console.print(msg, style="dim")


# ==================== 复合组件 ====================


def print_header(msg: str, style: str = "highlight") -> None:
    """
    输出带方框边框的标题面板。

    :param msg:   标题文字
    :param style: 边框与文字的 Rich 样式（默认 highlight/品红）
    """
    panel = Panel(
        Text(msg, style=style),
        border_style=style,
        expand=False,
        box=box.SQUARE,
    )
    console.print(panel)


def print_table(
    columns: Sequence[str],
    rows: Sequence[Sequence[str]],
    title: str = "",
) -> None:
    """
    输出带交替行底色的 Rich 表格。

    :param columns: 列标题列表
    :param rows:    数据行列表，每行为字符串序列
    :param title:   可选表格标题
    """
    table = Table(
        title=title,
        box=box.SIMPLE_HEAVY,
        show_header=True,
        header_style="bold magenta",
        row_styles=["", "dim"],  # 交替行底色
        expand=False,
    )
    for col in columns:
        table.add_column(col, overflow="fold")
    for row in rows:
        table.add_row(*[str(cell) for cell in row])
    console.print(table)


def print_separator(char: str = "─", width: int = 60) -> None:
    """输出分隔线"""
    console.print(char * width, style="dim")
