"""
cli.py — linkedin-lion 主 CLI 入口

将三个子命令注册到顶级 Typer app：
  lion scrape   — 单个 LinkedIn Profile 抓取
  lion batch    — 批量 LinkedIn Profile 抓取
  lion extract  — LLM 简历结构化提取

安装后通过 `lion` 命令调用（pyproject.toml [project.scripts] 配置）。
"""

import typer

from linkedin_lion.commands import batch, extract, scrape
from linkedin_lion.output import console, print_info, print_separator

# ==================== 顶级 App ====================

app = typer.Typer(
    name="lion",
    help=(
        "LinkedIn-Lion — LinkedIn Talent 抓取 & 简历结构化提取工具\n\n"
        "子命令概览：\n"
        "  scrape   抓取单个 LinkedIn Talent Profile\n"
        "  batch    批量抓取 LinkedIn Talent Profile 列表\n"
        "  extract  使用 LLM 提取 .txt 简历的结构化 JSON 信息"
    ),
    no_args_is_help=True,
    rich_markup_mode="rich",
    pretty_exceptions_enable=True,
    pretty_exceptions_show_locals=False,
)

# ==================== 注册子命令 ====================

app.add_typer(scrape.app, name="scrape")
app.add_typer(batch.app, name="batch")
app.add_typer(extract.app, name="extract")


# ==================== version 命令 ====================


@app.command()
def version() -> None:
    """显示 linkedin-lion 版本信息。"""
    from importlib.metadata import version as _version, PackageNotFoundError

    try:
        ver = _version("linkedin-lion")
    except PackageNotFoundError:
        ver = "dev"

    print_separator()
    console.print(f"  [bold magenta]linkedin-lion[/] [cyan]v{ver}[/]")
    console.print("  [dim]LinkedIn Talent 抓取 & LLM 简历结构化提取工具[/]")
    print_separator()


# ==================== 入口点 ====================


def main() -> None:
    """setuptools entry_point 入口，供 `lion` 命令调用。"""
    app()


if __name__ == "__main__":
    main()
