"""
test_output.py — linkedin_lion.output 模块单元测试

覆盖：
  - print_info / print_success / print_warning / print_error
  - print_highlight / print_dim
  - print_header (Panel + SQUARE box)
  - print_table (带列/行/标题)
  - print_separator (默认/自定义)
  - custom_theme 配色键完整性
  - 前缀图标校验（ℹ / ✓ / ⚠ / ✗）
  - error 输出定向到 stderr（err_console）
"""

import io

import pytest
from rich.console import Console

import linkedin_lion.output as out_module
from linkedin_lion.output import (
    custom_theme,
    print_dim,
    print_error,
    print_header,
    print_highlight,
    print_info,
    print_separator,
    print_success,
    print_table,
    print_warning,
)


# ==================== 辅助工具 ====================


def _make_console() -> tuple:
    """
    创建基于 StringIO 的 Console，用于捕获输出内容。
    返回 (Console, StringIO)。
    """
    buf = io.StringIO()
    con = Console(file=buf, theme=custom_theme, highlight=False, markup=False)
    return con, buf


# ==================== 基础输出函数 ====================


class TestPrintInfo:
    def test_outputs_message(self, monkeypatch):
        con, buf = _make_console()
        monkeypatch.setattr(out_module, "console", con)
        print_info("info test message")
        assert "info test message" in buf.getvalue()

    def test_has_info_prefix_icon(self, monkeypatch):
        con, buf = _make_console()
        monkeypatch.setattr(out_module, "console", con)
        print_info("msg")
        assert "ℹ" in buf.getvalue()

    def test_does_not_raise(self, monkeypatch):
        con, _ = _make_console()
        monkeypatch.setattr(out_module, "console", con)
        print_info("no exception check")


class TestPrintSuccess:
    def test_outputs_message(self, monkeypatch):
        con, buf = _make_console()
        monkeypatch.setattr(out_module, "console", con)
        print_success("operation done")
        assert "operation done" in buf.getvalue()

    def test_has_checkmark_icon(self, monkeypatch):
        con, buf = _make_console()
        monkeypatch.setattr(out_module, "console", con)
        print_success("ok")
        assert "✓" in buf.getvalue()


class TestPrintWarning:
    def test_outputs_message(self, monkeypatch):
        con, buf = _make_console()
        monkeypatch.setattr(out_module, "console", con)
        print_warning("watch out")
        assert "watch out" in buf.getvalue()

    def test_has_warning_icon(self, monkeypatch):
        con, buf = _make_console()
        monkeypatch.setattr(out_module, "console", con)
        print_warning("msg")
        assert "⚠" in buf.getvalue()


class TestPrintError:
    def test_outputs_message_to_err_console(self, monkeypatch):
        buf = io.StringIO()
        err_con = Console(file=buf, theme=custom_theme, highlight=False, markup=False)
        monkeypatch.setattr(out_module, "err_console", err_con)
        print_error("something failed")
        assert "something failed" in buf.getvalue()

    def test_has_cross_icon(self, monkeypatch):
        buf = io.StringIO()
        err_con = Console(file=buf, theme=custom_theme, highlight=False, markup=False)
        monkeypatch.setattr(out_module, "err_console", err_con)
        print_error("msg")
        assert "✗" in buf.getvalue()

    def test_does_not_write_to_stdout(self, monkeypatch):
        """print_error 不应写入 stdout console。"""
        stdout_buf = io.StringIO()
        con = Console(file=stdout_buf, theme=custom_theme, highlight=False, markup=False)
        stderr_buf = io.StringIO()
        err_con = Console(file=stderr_buf, theme=custom_theme, highlight=False, markup=False)
        monkeypatch.setattr(out_module, "console", con)
        monkeypatch.setattr(out_module, "err_console", err_con)
        print_error("error only in stderr")
        assert "error only in stderr" not in stdout_buf.getvalue()
        assert "error only in stderr" in stderr_buf.getvalue()


class TestPrintHighlight:
    def test_outputs_message(self, monkeypatch):
        con, buf = _make_console()
        monkeypatch.setattr(out_module, "console", con)
        print_highlight("highlighted text")
        assert "highlighted text" in buf.getvalue()


class TestPrintDim:
    def test_outputs_message(self, monkeypatch):
        con, buf = _make_console()
        monkeypatch.setattr(out_module, "console", con)
        print_dim("dim info")
        assert "dim info" in buf.getvalue()


# ==================== 复合组件 ====================


class TestPrintHeader:
    def test_renders_message_in_panel(self, monkeypatch):
        con, buf = _make_console()
        monkeypatch.setattr(out_module, "console", con)
        print_header("Dashboard Title")
        assert "Dashboard Title" in buf.getvalue()

    def test_custom_style_does_not_raise(self, monkeypatch):
        con, buf = _make_console()
        monkeypatch.setattr(out_module, "console", con)
        print_header("Header", style="info")
        assert "Header" in buf.getvalue()

    def test_default_style_is_highlight(self, monkeypatch):
        """默认调用不应抛出异常（验证 highlight 是合法样式）。"""
        con, buf = _make_console()
        monkeypatch.setattr(out_module, "console", con)
        print_header("Default Style Header")
        assert "Default Style Header" in buf.getvalue()


class TestPrintTable:
    def test_renders_column_names(self, monkeypatch):
        con, buf = _make_console()
        monkeypatch.setattr(out_module, "console", con)
        print_table(columns=["Name", "Score"], rows=[["Alice", "99"]])
        output = buf.getvalue()
        assert "Name" in output
        assert "Score" in output

    def test_renders_row_data(self, monkeypatch):
        con, buf = _make_console()
        monkeypatch.setattr(out_module, "console", con)
        print_table(columns=["Key", "Value"], rows=[["lang", "Python"], ["ver", "3.11"]])
        output = buf.getvalue()
        assert "lang" in output
        assert "Python" in output

    def test_renders_title(self, monkeypatch):
        con, buf = _make_console()
        monkeypatch.setattr(out_module, "console", con)
        print_table(columns=["A"], rows=[["1"]], title="Summary Table")
        assert "Summary Table" in buf.getvalue()

    def test_empty_rows_does_not_raise(self, monkeypatch):
        con, _ = _make_console()
        monkeypatch.setattr(out_module, "console", con)
        print_table(columns=["Col"], rows=[], title="Empty")

    def test_multiple_rows(self, monkeypatch):
        con, buf = _make_console()
        monkeypatch.setattr(out_module, "console", con)
        rows = [[str(i), f"item_{i}"] for i in range(5)]
        print_table(columns=["No.", "Item"], rows=rows)
        output = buf.getvalue()
        for i in range(5):
            assert f"item_{i}" in output


class TestPrintSeparator:
    def test_default_separator_character(self, monkeypatch):
        con, buf = _make_console()
        monkeypatch.setattr(out_module, "console", con)
        print_separator()
        assert "─" in buf.getvalue()

    def test_custom_character(self, monkeypatch):
        con, buf = _make_console()
        monkeypatch.setattr(out_module, "console", con)
        print_separator(char="=", width=10)
        assert "=" * 10 in buf.getvalue()

    def test_custom_width(self, monkeypatch):
        con, buf = _make_console()
        monkeypatch.setattr(out_module, "console", con)
        print_separator(char="-", width=20)
        assert "-" * 20 in buf.getvalue()


# ==================== 主题配色完整性 ====================


class TestCustomTheme:
    """验证 DESIGN_SPEC.md §3.1 要求的全部配色键均已定义。"""

    @pytest.mark.parametrize(
        "key",
        ["info", "success", "warning", "error", "highlight", "dim"],
    )
    def test_required_theme_key_exists(self, key):
        assert key in custom_theme.styles, f"缺少主题配色键：{key}"

    def test_theme_has_exactly_six_custom_keys(self):
        required = {"info", "success", "warning", "error", "highlight", "dim"}
        actual = set(custom_theme.styles.keys())
        assert required.issubset(actual)
