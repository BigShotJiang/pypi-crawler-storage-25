"""
test_config.py — linkedin_lion.config 模块单元测试

覆盖：
  - load_config()   默认值 / 显式参数 / 环境变量 / .env 文件加载
  - get_llm_config() 可选字段过滤 / 返回字段正确性
  - ensure_api_key() True / False 各条件
核心逻辑：所有 LLM 参数默认为 None，未配置时 get_llm_config() 返回空字典
"""

import pytest
from pathlib import Path
from unittest.mock import patch

from linkedin_lion.config import (
    LionConfig,
    ensure_api_key,
    get_llm_config,
    load_config,
)

_DEFAULT_COOKIE = "cookie.json"


# ==================== load_config ====================


class TestLoadConfigDefaults:
    """无参数、无环境变量时，LLM 字段应全部返回 None（交 llmdog 决定）。"""

    def test_api_key_defaults_to_none(self, monkeypatch):
        monkeypatch.delenv("LION_API_KEY", raising=False)
        with patch("linkedin_lion.config._load_dotenv_files"):
            cfg = load_config()
        assert cfg.api_key is None

    def test_api_url_defaults_to_none(self, monkeypatch):
        monkeypatch.delenv("LION_API_URL", raising=False)
        with patch("linkedin_lion.config._load_dotenv_files"):
            cfg = load_config()
        assert cfg.api_url is None

    def test_model_defaults_to_none(self, monkeypatch):
        monkeypatch.delenv("LION_MODEL", raising=False)
        with patch("linkedin_lion.config._load_dotenv_files"):
            cfg = load_config()
        assert cfg.model is None

    def test_timeout_defaults_to_none(self, monkeypatch):
        monkeypatch.delenv("LION_TIMEOUT", raising=False)
        with patch("linkedin_lion.config._load_dotenv_files"):
            cfg = load_config()
        assert cfg.timeout is None

    def test_verify_ssl_defaults_to_none(self, monkeypatch):
        monkeypatch.delenv("LION_VERIFY_SSL", raising=False)
        with patch("linkedin_lion.config._load_dotenv_files"):
            cfg = load_config()
        assert cfg.verify_ssl is None

    def test_cookie_file_defaults_to_cookie_json(self, monkeypatch):
        monkeypatch.delenv("LION_COOKIE_FILE", raising=False)
        with patch("linkedin_lion.config._load_dotenv_files"):
            cfg = load_config()
        assert cfg.cookie_file == _DEFAULT_COOKIE

    def test_returns_lion_config_instance(self, monkeypatch):
        with patch("linkedin_lion.config._load_dotenv_files"):
            cfg = load_config()
        assert isinstance(cfg, LionConfig)


class TestLoadConfigExplicitParams:
    """显式参数优先级高于环境变量与默认值。"""

    def test_api_key_explicit_overrides_env(self, monkeypatch):
        monkeypatch.setenv("LION_API_KEY", "env-key")
        with patch("linkedin_lion.config._load_dotenv_files"):
            cfg = load_config(api_key="explicit-key")
        assert cfg.api_key == "explicit-key"

    def test_api_url_explicit_overrides_env(self, monkeypatch):
        monkeypatch.setenv("LION_API_URL", "https://env.example.com")
        with patch("linkedin_lion.config._load_dotenv_files"):
            cfg = load_config(api_url="https://explicit.example.com")
        assert cfg.api_url == "https://explicit.example.com"

    def test_model_explicit_overrides_env(self, monkeypatch):
        monkeypatch.setenv("LION_MODEL", "env-model")
        with patch("linkedin_lion.config._load_dotenv_files"):
            cfg = load_config(model="explicit-model")
        assert cfg.model == "explicit-model"

    def test_timeout_explicit_overrides_default(self, monkeypatch):
        monkeypatch.delenv("LION_TIMEOUT", raising=False)
        with patch("linkedin_lion.config._load_dotenv_files"):
            cfg = load_config(timeout=30)
        assert cfg.timeout == 30

    def test_verify_ssl_explicit_false_overrides_default(self, monkeypatch):
        monkeypatch.delenv("LION_VERIFY_SSL", raising=False)
        with patch("linkedin_lion.config._load_dotenv_files"):
            cfg = load_config(verify_ssl=False)
        assert cfg.verify_ssl is False

    def test_cookie_file_explicit_overrides_default(self, monkeypatch):
        monkeypatch.delenv("LION_COOKIE_FILE", raising=False)
        with patch("linkedin_lion.config._load_dotenv_files"):
            cfg = load_config(cookie_file="custom_cookie.json")
        assert cfg.cookie_file == "custom_cookie.json"

    def test_partial_override_keeps_other_as_none(self, monkeypatch):
        """只设置 api_key，其余 LLM 字段保持 None。"""
        monkeypatch.delenv("LION_MODEL", raising=False)
        monkeypatch.delenv("LION_TIMEOUT", raising=False)
        monkeypatch.delenv("LION_VERIFY_SSL", raising=False)
        with patch("linkedin_lion.config._load_dotenv_files"):
            cfg = load_config(api_key="only-key")
        assert cfg.api_key == "only-key"
        assert cfg.model is None
        assert cfg.timeout is None
        assert cfg.verify_ssl is None


class TestLoadConfigEnvVars:
    """未设置显式参数时，应读取环境变量。"""

    def test_reads_api_key_from_env(self, monkeypatch):
        monkeypatch.setenv("LION_API_KEY", "env-api-key-abc")
        with patch("linkedin_lion.config._load_dotenv_files"):
            cfg = load_config()
        assert cfg.api_key == "env-api-key-abc"

    def test_reads_api_url_from_env(self, monkeypatch):
        monkeypatch.setenv("LION_API_URL", "https://env-url.example.com")
        with patch("linkedin_lion.config._load_dotenv_files"):
            cfg = load_config()
        assert cfg.api_url == "https://env-url.example.com"

    def test_reads_model_from_env(self, monkeypatch):
        monkeypatch.setenv("LION_MODEL", "gpt-4o")
        with patch("linkedin_lion.config._load_dotenv_files"):
            cfg = load_config()
        assert cfg.model == "gpt-4o"

    def test_reads_timeout_from_env(self, monkeypatch):
        monkeypatch.setenv("LION_TIMEOUT", "60")
        with patch("linkedin_lion.config._load_dotenv_files"):
            cfg = load_config()
        assert cfg.timeout == 60

    def test_reads_verify_ssl_false_from_env(self, monkeypatch):
        monkeypatch.setenv("LION_VERIFY_SSL", "false")
        with patch("linkedin_lion.config._load_dotenv_files"):
            cfg = load_config()
        assert cfg.verify_ssl is False

    def test_reads_verify_ssl_zero_from_env(self, monkeypatch):
        monkeypatch.setenv("LION_VERIFY_SSL", "0")
        with patch("linkedin_lion.config._load_dotenv_files"):
            cfg = load_config()
        assert cfg.verify_ssl is False

    def test_reads_verify_ssl_true_from_env(self, monkeypatch):
        monkeypatch.setenv("LION_VERIFY_SSL", "true")
        with patch("linkedin_lion.config._load_dotenv_files"):
            cfg = load_config()
        assert cfg.verify_ssl is True

    def test_reads_cookie_file_from_env(self, monkeypatch):
        monkeypatch.setenv("LION_COOKIE_FILE", "env_cookie.json")
        with patch("linkedin_lion.config._load_dotenv_files"):
            cfg = load_config()
        assert cfg.cookie_file == "env_cookie.json"


class TestLoadConfigDotenvFile:
    """.env 文件中的值应被正确加载（低优先级于已设置的环境变量）。"""

    def test_loads_api_key_from_dotenv(self, tmp_path, monkeypatch):
        env_file = tmp_path / ".env"
        env_file.write_text(
            "LION_API_KEY=dotenv-api-key\nLION_MODEL=dotenv-model\n",
            encoding="utf-8",
        )
        monkeypatch.chdir(tmp_path)
        monkeypatch.delenv("LION_API_KEY", raising=False)
        monkeypatch.delenv("LION_MODEL", raising=False)

        cfg = load_config()

        assert cfg.api_key == "dotenv-api-key"
        assert cfg.model == "dotenv-model"

    def test_env_var_overrides_dotenv(self, tmp_path, monkeypatch):
        """.env 设置的值不应覆盖已存在的环境变量（override=False）。"""
        env_file = tmp_path / ".env"
        env_file.write_text("LION_API_KEY=dotenv-key\n", encoding="utf-8")
        monkeypatch.chdir(tmp_path)
        monkeypatch.setenv("LION_API_KEY", "env-takes-priority")

        cfg = load_config()

        assert cfg.api_key == "env-takes-priority"


# ==================== get_llm_config ====================


class TestGetLlmConfig:
    def test_returns_empty_dict_when_nothing_configured(self):
        """全部 LLM 字段为 None 时，应返回空字典。"""
        cfg = LionConfig()  # 所有 LLM 字段为 None
        assert get_llm_config(cfg) == {}

    def test_returns_api_key(self, mock_lion_config):
        result = get_llm_config(mock_lion_config)
        assert result["api_key"] == mock_lion_config.api_key

    def test_returns_model(self, mock_lion_config):
        result = get_llm_config(mock_lion_config)
        assert result["model"] == mock_lion_config.model

    def test_returns_timeout(self, mock_lion_config):
        result = get_llm_config(mock_lion_config)
        assert result["timeout"] == mock_lion_config.timeout

    def test_returns_verify_ssl(self, mock_lion_config):
        result = get_llm_config(mock_lion_config)
        assert result["verify_ssl"] == mock_lion_config.verify_ssl

    def test_includes_api_url_when_set(self, mock_lion_config):
        """api_url 非空时应包含该字段。"""
        result = get_llm_config(mock_lion_config)
        assert "api_url" in result
        assert result["api_url"] == mock_lion_config.api_url

    def test_excludes_api_url_when_none(self):
        """api_url 为 None 时不应包含该字段。"""
        cfg = LionConfig(api_key="sk-test", api_url=None)
        result = get_llm_config(cfg)
        assert "api_url" not in result

    def test_excludes_api_url_when_empty_string(self):
        """api_url 为空字符串时同样不应包含（等同于未配置）。"""
        cfg = LionConfig(api_key="sk-test", api_url="")
        result = get_llm_config(cfg)
        assert "api_url" not in result

    def test_excludes_model_when_none(self):
        cfg = LionConfig(api_key="sk-test")  # model=None
        result = get_llm_config(cfg)
        assert "model" not in result

    def test_excludes_timeout_when_none(self):
        cfg = LionConfig(api_key="sk-test")  # timeout=None
        result = get_llm_config(cfg)
        assert "timeout" not in result

    def test_excludes_verify_ssl_when_none(self):
        cfg = LionConfig(api_key="sk-test")  # verify_ssl=None
        result = get_llm_config(cfg)
        assert "verify_ssl" not in result

    def test_does_not_include_cookie_file(self, mock_lion_config):
        result = get_llm_config(mock_lion_config)
        assert "cookie_file" not in result

    def test_returns_dict(self, mock_lion_config):
        assert isinstance(get_llm_config(mock_lion_config), dict)

    def test_only_api_key_configured(self):
        """只配置 api_key 时，应恰好返回一个键。"""
        cfg = LionConfig(api_key="sk-test")
        result = get_llm_config(cfg)
        assert set(result.keys()) == {"api_key"}

    def test_correct_keys_without_api_url(self):
        """配置 api_key/model/timeout/verify_ssl，不配置 api_url 时应有四个键。"""
        cfg = LionConfig(api_key="sk-test", model="gpt-4", timeout=30, verify_ssl=False)
        result = get_llm_config(cfg)
        assert set(result.keys()) == {"api_key", "model", "timeout", "verify_ssl"}

    def test_correct_keys_with_api_url(self, mock_lion_config):
        """配置所有字段时应包含全部五个键。"""
        result = get_llm_config(mock_lion_config)
        assert set(result.keys()) == {"api_key", "api_url", "model", "timeout", "verify_ssl"}


# ==================== ensure_api_key ====================


class TestEnsureApiKey:
    def test_returns_true_when_key_set(self):
        cfg = LionConfig(api_key="sk-abc123")
        assert ensure_api_key(cfg) is True

    def test_returns_false_when_none(self):
        """api_key 为 None（默认值）时应返回 False。"""
        cfg = LionConfig()
        assert ensure_api_key(cfg) is False

    def test_returns_false_when_empty_string(self):
        cfg = LionConfig(api_key="")
        assert ensure_api_key(cfg) is False

    def test_returns_false_when_whitespace_only(self):
        cfg = LionConfig(api_key="   ")
        assert ensure_api_key(cfg) is False

    def test_returns_true_with_minimal_key(self):
        cfg = LionConfig(api_key="x")
        assert ensure_api_key(cfg) is True

    def test_returns_false_on_default_config(self):
        cfg = LionConfig()
        assert ensure_api_key(cfg) is False
