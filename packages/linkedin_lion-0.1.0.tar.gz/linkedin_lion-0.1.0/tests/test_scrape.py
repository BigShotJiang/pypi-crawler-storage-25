"""
test_scrape.py — linkedin_lion.commands.scrape 模块单元测试

覆盖：
  - extract_linkedin_id()       URL 解析（标准 / 无尾斜杠 / 查询参数 / 无匹配）
  - login()                     selenium 不可用时抛出 RuntimeError / 成功路径
  - _extract_text_from_page()   文件缓存命中 / 成功提取 / 异常返回空串
  - scrape_profile()            selenium 不可用 / 成功 / 无内容返回 None / 异常

Mock 策略：
  - 通过 monkeypatch.setattr(..., raising=False) 注入或覆盖可选依赖
  - 使用 patch("time.sleep") 加速含 sleep 的函数
  - _extract_text_from_page 在测试 scrape_profile 时整体 mock，避免重复测试深层逻辑
"""

import os
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest


# ==================== extract_linkedin_id ====================


class TestExtractLinkedinId:
    """对内置降级实现（或 larkfunc 实现）进行功能验证。"""

    def _fn(self):
        from linkedin_lion.commands.scrape import extract_linkedin_id
        return extract_linkedin_id

    def test_standard_url_with_trailing_slash(self):
        fn = self._fn()
        assert fn("https://www.linkedin.com/in/johndoe/") == "johndoe"

    def test_url_without_trailing_slash(self):
        fn = self._fn()
        assert fn("https://www.linkedin.com/in/jane-smith") == "jane-smith"

    def test_url_with_query_params(self):
        fn = self._fn()
        result = fn("https://www.linkedin.com/in/johndoe/?ref=abc&trk=xyz")
        assert result == "johndoe"

    def test_url_with_fragment(self):
        fn = self._fn()
        result = fn("https://www.linkedin.com/in/johndoe/#section")
        assert result == "johndoe"

    def test_talent_url_without_in_returns_empty(self):
        fn = self._fn()
        result = fn("https://www.linkedin.com/talent/home")
        assert result == ""

    def test_empty_string_returns_empty(self):
        fn = self._fn()
        assert fn("") == ""

    def test_hyphenated_id(self):
        fn = self._fn()
        assert fn("https://www.linkedin.com/in/john-doe-123/") == "john-doe-123"


# ==================== login ====================


class TestLogin:
    def test_raises_runtime_error_when_selenium_unavailable(self, monkeypatch):
        monkeypatch.setattr(
            "linkedin_lion.commands.scrape._selenium_available", False
        )
        monkeypatch.setattr(
            "linkedin_lion.commands.scrape._import_error_msg",
            "No module named 'selenium'",
            raising=False,
        )
        from linkedin_lion.commands.scrape import login
        with pytest.raises(RuntimeError, match="缺少依赖"):
            login()

    def test_login_returns_driver_on_success(self, monkeypatch, tmp_path):
        monkeypatch.chdir(tmp_path)
        (tmp_path / "cookie.json").write_text("[]", encoding="utf-8")

        mock_driver = MagicMock()
        mock_cat = MagicMock()
        mock_cat.get_driver.return_value = mock_driver
        mock_browser_dog_cls = MagicMock(return_value=mock_cat)

        monkeypatch.setattr(
            "linkedin_lion.commands.scrape._selenium_available", True
        )
        monkeypatch.setattr(
            "linkedin_lion.commands.scrape.BrowserDog",
            mock_browser_dog_cls,
            raising=False,
        )
        from linkedin_lion.commands.scrape import login
        result = login("cookie.json", headless=True)

        assert result is mock_driver
        mock_driver.maximize_window.assert_called_once()
        mock_cat.long_wait.assert_called_once()

    def test_login_passes_correct_args_to_browser_dog(self, monkeypatch, tmp_path):
        monkeypatch.chdir(tmp_path)
        (tmp_path / "my_cookie.json").write_text("[]", encoding="utf-8")

        mock_cat = MagicMock()
        mock_cat.get_driver.return_value = MagicMock()
        mock_browser_dog_cls = MagicMock(return_value=mock_cat)

        monkeypatch.setattr(
            "linkedin_lion.commands.scrape._selenium_available", True
        )
        monkeypatch.setattr(
            "linkedin_lion.commands.scrape.BrowserDog",
            mock_browser_dog_cls,
            raising=False,
        )
        from linkedin_lion.commands.scrape import login
        login("my_cookie.json", headless=True)

        mock_browser_dog_cls.assert_called_once_with(
            "my_cookie.json",
            "https://www.linkedin.com/talent/home",
            headless=True,
        )

    def test_login_opens_linkedin_talent_home(self, monkeypatch, tmp_path):
        monkeypatch.chdir(tmp_path)
        (tmp_path / "cookie.json").write_text("[]", encoding="utf-8")

        mock_driver = MagicMock()
        mock_cat = MagicMock()
        mock_cat.get_driver.return_value = mock_driver
        monkeypatch.setattr(
            "linkedin_lion.commands.scrape._selenium_available", True
        )
        monkeypatch.setattr(
            "linkedin_lion.commands.scrape.BrowserDog",
            MagicMock(return_value=mock_cat),
            raising=False,
        )
        from linkedin_lion.commands.scrape import login
        login()
        mock_driver.get.assert_called_once_with(
            "https://www.linkedin.com/talent/home"
        )


# ==================== _extract_text_from_page ====================


class TestExtractTextFromPage:
    """_extract_text_from_page 是模块内部函数，通过导入直接测试。"""

    def test_returns_cached_content_when_file_exists(self, tmp_path, monkeypatch):
        monkeypatch.setattr(
            "linkedin_lion.commands.scrape._selenium_available", True
        )
        cached_file = tmp_path / "resume.txt"
        cached_file.write_text("cached resume content", encoding="utf-8")

        from linkedin_lion.commands.scrape import _extract_text_from_page
        result = _extract_text_from_page(MagicMock(), "resume.txt", str(tmp_path))

        assert result == "cached resume content"

    def test_extracts_text_and_saves_file(self, tmp_path, monkeypatch):
        """WebDriverWait 返回含 HTML 的 mock element，验证文本被提取并保存。"""
        mock_element = MagicMock()
        mock_element.get_attribute.return_value = (
            "<div><p>John Doe</p><span>Engineer</span></div>"
        )
        mock_wait_instance = MagicMock()
        mock_wait_instance.until.return_value = mock_element

        monkeypatch.setattr(
            "linkedin_lion.commands.scrape._selenium_available", True
        )
        monkeypatch.setattr(
            "linkedin_lion.commands.scrape.WebDriverWait",
            MagicMock(return_value=mock_wait_instance),
            raising=False,
        )
        monkeypatch.setattr(
            "linkedin_lion.commands.scrape.EC", MagicMock(), raising=False
        )
        monkeypatch.setattr(
            "linkedin_lion.commands.scrape.By", MagicMock(), raising=False
        )

        from linkedin_lion.commands.scrape import _extract_text_from_page
        result = _extract_text_from_page(MagicMock(), "resume.txt", str(tmp_path))

        assert "John Doe" in result
        assert "Engineer" in result
        saved_files = list(tmp_path.glob("*.txt"))
        assert len(saved_files) == 1

    def test_uses_linkedin_id_as_filename_when_detected(self, tmp_path, monkeypatch):
        """页面存在 data-test-personal-info-profile-link 时，以 LinkedIn ID 命名文件。"""
        mock_element = MagicMock()
        mock_element.get_attribute.return_value = (
            '<div><p>John</p>'
            '<a data-test-personal-info-profile-link="" href="/in/johndoe/">link</a>'
            "</div>"
        )
        mock_wait_instance = MagicMock()
        mock_wait_instance.until.return_value = mock_element

        monkeypatch.setattr(
            "linkedin_lion.commands.scrape._selenium_available", True
        )
        monkeypatch.setattr(
            "linkedin_lion.commands.scrape.WebDriverWait",
            MagicMock(return_value=mock_wait_instance),
            raising=False,
        )
        monkeypatch.setattr(
            "linkedin_lion.commands.scrape.EC", MagicMock(), raising=False
        )
        monkeypatch.setattr(
            "linkedin_lion.commands.scrape.By", MagicMock(), raising=False
        )

        from linkedin_lion.commands.scrape import _extract_text_from_page
        _extract_text_from_page(MagicMock(), "fallback.txt", str(tmp_path))

        saved_files = list(tmp_path.glob("*.txt"))
        assert any("johndoe" in f.name for f in saved_files)

    def test_returns_empty_string_on_webdriver_exception(self, tmp_path, monkeypatch):
        monkeypatch.setattr(
            "linkedin_lion.commands.scrape._selenium_available", True
        )
        monkeypatch.setattr(
            "linkedin_lion.commands.scrape.WebDriverWait",
            MagicMock(side_effect=Exception("Timeout waiting for element")),
            raising=False,
        )
        monkeypatch.setattr(
            "linkedin_lion.commands.scrape.EC", MagicMock(), raising=False
        )
        monkeypatch.setattr(
            "linkedin_lion.commands.scrape.By", MagicMock(), raising=False
        )

        from linkedin_lion.commands.scrape import _extract_text_from_page
        result = _extract_text_from_page(MagicMock(), "resume.txt", str(tmp_path))

        assert result == ""

    def test_creates_folder_if_not_exists(self, tmp_path, monkeypatch):
        new_folder = tmp_path / "new_subdir"
        assert not new_folder.exists()

        mock_element = MagicMock()
        mock_element.get_attribute.return_value = "<div>content</div>"
        mock_wait_instance = MagicMock()
        mock_wait_instance.until.return_value = mock_element

        monkeypatch.setattr(
            "linkedin_lion.commands.scrape._selenium_available", True
        )
        monkeypatch.setattr(
            "linkedin_lion.commands.scrape.WebDriverWait",
            MagicMock(return_value=mock_wait_instance),
            raising=False,
        )
        monkeypatch.setattr(
            "linkedin_lion.commands.scrape.EC", MagicMock(), raising=False
        )
        monkeypatch.setattr(
            "linkedin_lion.commands.scrape.By", MagicMock(), raising=False
        )

        from linkedin_lion.commands.scrape import _extract_text_from_page
        _extract_text_from_page(MagicMock(), "resume.txt", str(new_folder))

        assert new_folder.exists()


# ==================== scrape_profile ====================


class TestScrapeProfile:
    def test_raises_when_selenium_unavailable(self, monkeypatch):
        monkeypatch.setattr(
            "linkedin_lion.commands.scrape._selenium_available", False
        )
        from linkedin_lion.commands.scrape import scrape_profile
        with pytest.raises(RuntimeError):
            scrape_profile(MagicMock(), "https://example.com")

    def test_returns_text_on_success(self, tmp_path, monkeypatch):
        """整体 mock _extract_text_from_page，验证 scrape_profile 的主路径。"""
        mock_driver = MagicMock()
        mock_button = MagicMock()
        mock_wait_instance = MagicMock()
        mock_wait_instance.until.return_value = mock_button

        monkeypatch.setattr(
            "linkedin_lion.commands.scrape._selenium_available", True
        )
        monkeypatch.setattr(
            "linkedin_lion.commands.scrape.WebDriverWait",
            MagicMock(return_value=mock_wait_instance),
            raising=False,
        )
        monkeypatch.setattr(
            "linkedin_lion.commands.scrape.ActionChains",
            MagicMock(),
            raising=False,
        )
        monkeypatch.setattr(
            "linkedin_lion.commands.scrape.EC", MagicMock(), raising=False
        )
        monkeypatch.setattr(
            "linkedin_lion.commands.scrape.By", MagicMock(), raising=False
        )

        with patch(
            "linkedin_lion.commands.scrape._extract_text_from_page",
            return_value="scraped resume text",
        ), patch("time.sleep"):
            from linkedin_lion.commands.scrape import scrape_profile
            result = scrape_profile(
                mock_driver,
                "https://www.linkedin.com/talent/profile/ACoAAA",
                "resume.txt",
                str(tmp_path),
            )

        assert result == "scraped resume text"

    def test_returns_none_when_text_is_empty(self, tmp_path, monkeypatch):
        mock_driver = MagicMock()
        mock_wait_instance = MagicMock()
        mock_wait_instance.until.return_value = MagicMock()

        monkeypatch.setattr(
            "linkedin_lion.commands.scrape._selenium_available", True
        )
        monkeypatch.setattr(
            "linkedin_lion.commands.scrape.WebDriverWait",
            MagicMock(return_value=mock_wait_instance),
            raising=False,
        )
        monkeypatch.setattr(
            "linkedin_lion.commands.scrape.ActionChains",
            MagicMock(),
            raising=False,
        )
        monkeypatch.setattr(
            "linkedin_lion.commands.scrape.EC", MagicMock(), raising=False
        )
        monkeypatch.setattr(
            "linkedin_lion.commands.scrape.By", MagicMock(), raising=False
        )

        with patch(
            "linkedin_lion.commands.scrape._extract_text_from_page",
            return_value="",
        ), patch("time.sleep"):
            from linkedin_lion.commands.scrape import scrape_profile
            result = scrape_profile(
                mock_driver,
                "https://www.linkedin.com/talent/profile/ACoAAA",
                "resume.txt",
                str(tmp_path),
            )

        assert result is None

    def test_returns_none_on_driver_exception(self, tmp_path, monkeypatch):
        mock_driver = MagicMock()
        mock_driver.get.side_effect = Exception("network error")

        monkeypatch.setattr(
            "linkedin_lion.commands.scrape._selenium_available", True
        )

        with patch("time.sleep"):
            from linkedin_lion.commands.scrape import scrape_profile
            result = scrape_profile(
                mock_driver,
                "https://www.linkedin.com/talent/profile/xxx",
                "resume.txt",
                str(tmp_path),
            )

        assert result is None
