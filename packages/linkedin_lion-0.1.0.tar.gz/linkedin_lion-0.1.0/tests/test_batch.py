"""
test_batch.py — linkedin_lion.commands.batch 模块单元测试

覆盖：
  - _file_already_exists()   path1 存在 / path2 (URL 解码) 存在 / 均不存在
  - _get_profile_urn()       diskcache 命中 / 未命中
  - batch_scrape()           文件不存在 / 空文件 / 负数 start / start>=end /
                             end 超出自动调整 / 成功路径（无 cache）/
                             成功路径（有 cache 命中）/ cache 未命中计失败 /
                             已存在文件跳过 / driver.quit 必然被调用

Mock 策略：
  - patch("linkedin_lion.commands.batch.login")         避免启动浏览器
  - patch("linkedin_lion.commands.batch.scrape_profile") 避免真实网络请求
  - patch("linkedin_lion.commands.batch.Cache")          避免真实磁盘 diskcache
"""

import os
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest


# ==================== _file_already_exists ====================


class TestFileAlreadyExists:
    def test_returns_true_when_exact_file_exists(self, tmp_path):
        from linkedin_lion.commands.batch import _file_already_exists
        (tmp_path / "johndoe.txt").write_text("content")
        assert _file_already_exists("johndoe", str(tmp_path)) is True

    def test_returns_true_when_url_decoded_file_exists(self, tmp_path):
        """URL 编码的 ID（如 john%20doe）解码后文件存在时应返回 True。"""
        from linkedin_lion.commands.batch import _file_already_exists
        (tmp_path / "john doe.txt").write_text("content")
        assert _file_already_exists("john%20doe", str(tmp_path)) is True

    def test_returns_false_when_neither_exists(self, tmp_path):
        from linkedin_lion.commands.batch import _file_already_exists
        assert _file_already_exists("nobody", str(tmp_path)) is False

    def test_returns_false_for_empty_directory(self, tmp_path):
        from linkedin_lion.commands.batch import _file_already_exists
        assert _file_already_exists("anyone", str(tmp_path)) is False


# ==================== _get_profile_urn ====================


class TestGetProfileUrn:
    def _make_mock_cache(self, return_value):
        """创建一个支持 context manager 协议的 mock Cache。"""
        mock_cache = MagicMock()
        mock_cache.__enter__ = MagicMock(return_value=mock_cache)
        mock_cache.__exit__ = MagicMock(return_value=False)
        mock_cache.get.return_value = return_value
        return mock_cache

    def test_returns_urn_on_cache_hit(self, tmp_path):
        from linkedin_lion.commands.batch import _get_profile_urn
        mock_cache = self._make_mock_cache("ACoAAA123456")
        with patch("linkedin_lion.commands.batch.Cache", return_value=mock_cache):
            result = _get_profile_urn(
                "https://www.linkedin.com/in/johndoe/", str(tmp_path)
            )
        assert result == "ACoAAA123456"

    def test_returns_none_on_cache_miss(self, tmp_path):
        from linkedin_lion.commands.batch import _get_profile_urn
        mock_cache = self._make_mock_cache(None)
        with patch("linkedin_lion.commands.batch.Cache", return_value=mock_cache):
            result = _get_profile_urn(
                "https://www.linkedin.com/in/nobody/", str(tmp_path)
            )
        assert result is None

    def test_uses_url_as_cache_key(self, tmp_path):
        from linkedin_lion.commands.batch import _get_profile_urn
        mock_cache = self._make_mock_cache("URN_VALUE")
        with patch("linkedin_lion.commands.batch.Cache", return_value=mock_cache):
            _get_profile_urn("https://www.linkedin.com/in/foo/", str(tmp_path))
        mock_cache.get.assert_called_once_with(
            "https://www.linkedin.com/in/foo/"
        )


# ==================== batch_scrape ====================


class TestBatchScrapeValidation:
    """参数校验与边界条件测试（不涉及真实 driver）。"""

    def test_returns_false_when_file_not_found(self, output_dir):
        from linkedin_lion.commands.batch import batch_scrape
        result = batch_scrape("/nonexistent/path/urls.txt", output_dir=output_dir)
        assert result is False

    def test_returns_false_when_file_is_empty(self, tmp_path, output_dir):
        from linkedin_lion.commands.batch import batch_scrape
        empty_file = tmp_path / "empty.txt"
        empty_file.write_text("", encoding="utf-8")
        result = batch_scrape(str(empty_file), output_dir=output_dir)
        assert result is False

    def test_returns_false_when_start_is_negative(self, sample_urls_file, output_dir):
        from linkedin_lion.commands.batch import batch_scrape
        result = batch_scrape(sample_urls_file, output_dir=output_dir, start=-1)
        assert result is False

    def test_returns_false_when_start_equals_end(self, sample_urls_file, output_dir):
        from linkedin_lion.commands.batch import batch_scrape
        result = batch_scrape(sample_urls_file, output_dir=output_dir, start=2, end=2)
        assert result is False

    def test_returns_false_when_start_greater_than_end(
        self, sample_urls_file, output_dir
    ):
        from linkedin_lion.commands.batch import batch_scrape
        result = batch_scrape(sample_urls_file, output_dir=output_dir, start=5, end=2)
        assert result is False

    def test_auto_adjusts_end_exceeding_total(self, sample_urls_file, output_dir):
        """end > 文件行数时，自动调整为 total 并正常运行。"""
        from linkedin_lion.commands.batch import batch_scrape
        mock_driver = MagicMock()
        with patch("linkedin_lion.commands.batch.login", return_value=mock_driver), patch(
            "linkedin_lion.commands.batch.scrape_profile", return_value="text"
        ):
            # sample_urls_file 有 3 行，end=999 应自动调整为 3
            result = batch_scrape(
                sample_urls_file, output_dir=output_dir, start=0, end=999
            )
        assert result is True


class TestBatchScrapeSuccessPath:
    """主流程测试（均通过 mock 替代真实浏览器和网络）。"""

    def test_processes_all_urls_without_cache(self, sample_urls_file, output_dir):
        from linkedin_lion.commands.batch import batch_scrape
        mock_driver = MagicMock()
        with patch(
            "linkedin_lion.commands.batch.login", return_value=mock_driver
        ) as mock_login, patch(
            "linkedin_lion.commands.batch.scrape_profile", return_value="resume text"
        ) as mock_scrape:
            result = batch_scrape(
                sample_urls_file,
                output_dir=output_dir,
                start=0,
                end=2,
                cookie_file="cookie.json",
                cache_dir="",
            )

        assert result is True
        mock_login.assert_called_once_with(cookie_file="cookie.json", headless=False)
        assert mock_scrape.call_count == 2

    def test_headless_mode_passed_to_login(self, sample_urls_file, output_dir):
        from linkedin_lion.commands.batch import batch_scrape
        mock_driver = MagicMock()
        with patch(
            "linkedin_lion.commands.batch.login", return_value=mock_driver
        ) as mock_login, patch(
            "linkedin_lion.commands.batch.scrape_profile", return_value="text"
        ):
            batch_scrape(
                sample_urls_file,
                output_dir=output_dir,
                start=0,
                end=1,
                headless=True,
            )
        mock_login.assert_called_once_with(
            cookie_file="cookie.json", headless=True
        )

    def test_skips_existing_files(self, tmp_path, output_dir):
        from linkedin_lion.commands.batch import batch_scrape
        # 预先创建 johndoe.txt → 该条应被跳过
        (Path(output_dir) / "johndoe.txt").write_text("existing")
        urls_file = tmp_path / "urls.txt"
        urls_file.write_text("https://www.linkedin.com/in/johndoe/\n")

        mock_driver = MagicMock()
        with patch(
            "linkedin_lion.commands.batch.login", return_value=mock_driver
        ), patch(
            "linkedin_lion.commands.batch.scrape_profile"
        ) as mock_scrape:
            result = batch_scrape(str(urls_file), output_dir=output_dir)

        mock_scrape.assert_not_called()
        assert result is True  # 跳过也算成功（无失败）

    def test_scrape_failure_counted_as_fail(self, sample_urls_file, output_dir):
        from linkedin_lion.commands.batch import batch_scrape
        mock_driver = MagicMock()
        with patch(
            "linkedin_lion.commands.batch.login", return_value=mock_driver
        ), patch(
            "linkedin_lion.commands.batch.scrape_profile", return_value=None
        ):
            result = batch_scrape(
                sample_urls_file, output_dir=output_dir, start=0, end=1
            )
        # scrape_profile 返回 None → fail 计数 → batch 返回 False
        assert result is False

    def test_scrape_exception_counted_as_fail(self, sample_urls_file, output_dir):
        from linkedin_lion.commands.batch import batch_scrape
        mock_driver = MagicMock()
        with patch(
            "linkedin_lion.commands.batch.login", return_value=mock_driver
        ), patch(
            "linkedin_lion.commands.batch.scrape_profile",
            side_effect=Exception("network error"),
        ):
            result = batch_scrape(
                sample_urls_file, output_dir=output_dir, start=0, end=1
            )
        assert result is False


class TestBatchScrapeCacheIntegration:
    """cache_dir 参数相关测试。"""

    def _make_cache_mock(self, urn_value):
        mock_cache = MagicMock()
        mock_cache.__enter__ = MagicMock(return_value=mock_cache)
        mock_cache.__exit__ = MagicMock(return_value=False)
        mock_cache.get.return_value = urn_value
        return mock_cache

    def test_builds_talent_url_from_urn_on_cache_hit(
        self, sample_urls_file, output_dir
    ):
        from linkedin_lion.commands.batch import batch_scrape
        mock_driver = MagicMock()
        captured_urls = []

        def fake_scrape(driver, url, filename, folder):
            captured_urls.append(url)
            return "text"

        with patch(
            "linkedin_lion.commands.batch.login", return_value=mock_driver
        ), patch(
            "linkedin_lion.commands.batch.scrape_profile", side_effect=fake_scrape
        ), patch(
            "linkedin_lion.commands.batch.Cache",
            return_value=self._make_cache_mock("ACoAAA999"),
        ):
            batch_scrape(
                sample_urls_file,
                output_dir=output_dir,
                start=0,
                end=1,
                cache_dir="/fake/cache",
            )

        assert len(captured_urls) == 1
        assert "ACoAAA999" in captured_urls[0]
        assert "FLAGSHIP_VIEW_IN_RECRUITER" in captured_urls[0]

    def test_cache_miss_skips_url_and_counts_fail(
        self, sample_urls_file, output_dir
    ):
        from linkedin_lion.commands.batch import batch_scrape
        mock_driver = MagicMock()
        with patch(
            "linkedin_lion.commands.batch.login", return_value=mock_driver
        ), patch(
            "linkedin_lion.commands.batch.scrape_profile"
        ) as mock_scrape, patch(
            "linkedin_lion.commands.batch.Cache",
            return_value=self._make_cache_mock(None),
        ):
            result = batch_scrape(
                sample_urls_file,
                output_dir=output_dir,
                start=0,
                end=1,
                cache_dir="/fake/cache",
            )

        mock_scrape.assert_not_called()
        assert result is False


class TestBatchScrapeDriverLifecycle:
    """验证 driver.quit() 无论成功与否都被调用（finally 块）。"""

    def test_driver_quit_called_on_success(self, sample_urls_file, output_dir):
        from linkedin_lion.commands.batch import batch_scrape
        mock_driver = MagicMock()
        with patch(
            "linkedin_lion.commands.batch.login", return_value=mock_driver
        ), patch("linkedin_lion.commands.batch.scrape_profile", return_value="text"):
            batch_scrape(sample_urls_file, output_dir=output_dir, start=0, end=1)
        mock_driver.quit.assert_called_once()

    def test_driver_quit_called_even_on_exception(self, sample_urls_file, output_dir):
        from linkedin_lion.commands.batch import batch_scrape
        mock_driver = MagicMock()
        with patch(
            "linkedin_lion.commands.batch.login", return_value=mock_driver
        ), patch(
            "linkedin_lion.commands.batch.scrape_profile",
            side_effect=Exception("boom"),
        ):
            batch_scrape(sample_urls_file, output_dir=output_dir, start=0, end=1)
        mock_driver.quit.assert_called_once()
