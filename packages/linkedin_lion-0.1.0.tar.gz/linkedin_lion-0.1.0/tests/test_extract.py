"""
test_extract.py — linkedin_lion.commands.extract 模块单元测试

覆盖：
  - _clean_llm_response()      ```json / ``` / 纯 JSON / 仅尾部 ``` / 空白
  - _parse_json_safely()       合法 JSON / 非法 JSON / 嵌套 / 空对象
  - _save_json()               成功保存 / Unicode 保留 / 写入失败返回 False
  - _collect_txt_files()       单文件 / 目录 / 空目录 / 非 txt 抛 ValueError / 排序
  - _call_llm_with_retry()     llmdog 不可用抛 RuntimeError / 首次成功 /
                                空响应重试 / 异常后重试 / 耗尽重试返回空串
  - extract_resume()           llmdog 不可用 / 无 api_key / 成功单文件 /
                                成功目录批量 / 自定义 prompt 传递
"""

import json
import os
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from linkedin_lion.commands.extract import (
    DEFAULT_PROMPT_TEMPLATE,
    _clean_llm_response,
    _collect_txt_files,
    _parse_json_safely,
    _save_json,
)


# ==================== _clean_llm_response ====================


class TestCleanLlmResponse:
    def test_strips_json_code_block(self):
        raw = '```json\n{"name": "John"}\n```'
        assert _clean_llm_response(raw) == '{"name": "John"}'

    def test_strips_plain_code_block(self):
        raw = '```\n{"name": "John"}\n```'
        assert _clean_llm_response(raw) == '{"name": "John"}'

    def test_plain_json_unchanged(self):
        raw = '{"name": "John"}'
        assert _clean_llm_response(raw) == '{"name": "John"}'

    def test_strips_trailing_backticks_only(self):
        raw = '{"name": "John"}\n```'
        assert _clean_llm_response(raw) == '{"name": "John"}'

    def test_strips_surrounding_whitespace(self):
        raw = '  \n{"name": "John"}\n  '
        assert _clean_llm_response(raw) == '{"name": "John"}'

    def test_multiline_json_preserved(self):
        raw = '```json\n{\n  "name": "John",\n  "age": 30\n}\n```'
        cleaned = _clean_llm_response(raw)
        data = json.loads(cleaned)
        assert data["name"] == "John"
        assert data["age"] == 30

    def test_empty_string_returns_empty(self):
        assert _clean_llm_response("") == ""


# ==================== _parse_json_safely ====================


class TestParseJsonSafely:
    def test_valid_flat_json(self):
        result = _parse_json_safely('{"name": "Alice", "age": 25}')
        assert result == {"name": "Alice", "age": 25}

    def test_valid_nested_json(self):
        data = {"skills": ["Python", "Java"], "exp": [{"company": "Google"}]}
        result = _parse_json_safely(json.dumps(data))
        assert result == data

    def test_empty_object(self):
        result = _parse_json_safely("{}")
        assert result == {}

    def test_invalid_json_returns_empty_dict(self):
        result = _parse_json_safely("not valid json {{")
        assert result == {}

    def test_empty_string_returns_empty_dict(self):
        result = _parse_json_safely("")
        assert result == {}

    def test_unicode_values_preserved(self):
        result = _parse_json_safely('{"name": "张三", "city": "北京"}')
        assert result["name"] == "张三"


# ==================== _save_json ====================


class TestSaveJson:
    def test_saves_file_successfully(self, tmp_path):
        data = {"name": "John", "skills": ["Python"]}
        path = str(tmp_path / "output.json")
        assert _save_json(data, path) is True
        with open(path, encoding="utf-8") as f:
            loaded = json.load(f)
        assert loaded == data

    def test_unicode_content_preserved_in_file(self, tmp_path):
        data = {"name": "张三", "title": "工程师"}
        path = str(tmp_path / "output.json")
        _save_json(data, path)
        content = Path(path).read_text(encoding="utf-8")
        assert "张三" in content
        assert "工程师" in content

    def test_uses_indented_json_format(self, tmp_path):
        data = {"key": "value"}
        path = str(tmp_path / "output.json")
        _save_json(data, path)
        content = Path(path).read_text(encoding="utf-8")
        assert "  " in content  # indent=2 会有缩进

    def test_returns_false_when_directory_missing(self, tmp_path):
        """父目录不存在时，保存应失败并返回 False。"""
        invalid_path = str(tmp_path / "nonexistent_dir" / "output.json")
        result = _save_json({"key": "val"}, invalid_path)
        assert result is False


# ==================== _collect_txt_files ====================


class TestCollectTxtFiles:
    def test_single_txt_file_returns_list_with_one_element(
        self, sample_resume_file
    ):
        result = _collect_txt_files(sample_resume_file)
        assert result == [sample_resume_file]

    def test_directory_returns_only_txt_files(self, tmp_path):
        (tmp_path / "a.txt").write_text("a")
        (tmp_path / "b.txt").write_text("b")
        (tmp_path / "c.json").write_text("{}")  # 应被排除
        (tmp_path / "d.pdf").write_text("binary")  # 应被排除
        result = _collect_txt_files(str(tmp_path))
        assert len(result) == 2
        assert all(f.endswith(".txt") for f in result)

    def test_results_are_sorted_alphabetically(self, tmp_path):
        for name in ["c", "a", "b"]:
            (tmp_path / f"{name}.txt").write_text(name)
        result = _collect_txt_files(str(tmp_path))
        names = [Path(f).name for f in result]
        assert names == ["a.txt", "b.txt", "c.txt"]

    def test_empty_directory_returns_empty_list(self, tmp_path):
        result = _collect_txt_files(str(tmp_path))
        assert result == []

    def test_non_txt_file_raises_value_error(self, tmp_path):
        f = tmp_path / "resume.pdf"
        f.write_text("content")
        with pytest.raises(ValueError, match="输入路径无效"):
            _collect_txt_files(str(f))

    def test_nonexistent_path_raises_value_error(self, tmp_path):
        with pytest.raises(ValueError):
            _collect_txt_files(str(tmp_path / "ghost.txt"))

    def test_nested_files_not_included(self, tmp_path):
        """只扫描目录直接子文件，不递归。"""
        sub = tmp_path / "sub"
        sub.mkdir()
        (sub / "nested.txt").write_text("nested")
        (tmp_path / "top.txt").write_text("top")
        result = _collect_txt_files(str(tmp_path))
        assert len(result) == 1
        assert "top.txt" in result[0]


# ==================== _call_llm_with_retry ====================


class TestCallLlmWithRetry:
    def test_raises_runtime_error_when_llmdog_unavailable(self):
        from linkedin_lion.commands.extract import _call_llm_with_retry
        with patch("linkedin_lion.commands.extract._llmdog_available", False):
            with pytest.raises(RuntimeError, match="缺少依赖"):
                _call_llm_with_retry("content", "prompt", 3, MagicMock())

    def test_returns_response_on_first_attempt(self):
        from linkedin_lion.commands.extract import _call_llm_with_retry
        mock_response = '{"name": "John"}'
        with patch("linkedin_lion.commands.extract._llmdog_available", True), patch(
            "linkedin_lion.commands.extract._llmdog_chat",
            return_value=mock_response,
            raising=False,
        ):
            result = _call_llm_with_retry("resume", "prompt", 3, MagicMock())
        assert result == mock_response

    def test_retries_on_empty_response(self):
        from linkedin_lion.commands.extract import _call_llm_with_retry
        # 第一次返回空，第二次返回有效内容
        with patch("linkedin_lion.commands.extract._llmdog_available", True), patch(
            "linkedin_lion.commands.extract._llmdog_chat",
            side_effect=["", '{"name": "Retry"}'],
            raising=False,
        ), patch("time.sleep"):
            result = _call_llm_with_retry("content", "prompt", 3, MagicMock())
        assert result == '{"name": "Retry"}'

    def test_retries_on_exception_and_succeeds(self):
        from linkedin_lion.commands.extract import _call_llm_with_retry
        mock_chat = MagicMock(
            side_effect=[Exception("API error"), '{"name": "Jane"}']
        )
        with patch("linkedin_lion.commands.extract._llmdog_available", True), patch(
            "linkedin_lion.commands.extract._llmdog_chat",
            mock_chat,
            raising=False,
        ), patch("time.sleep"):
            result = _call_llm_with_retry("content", "prompt", 2, MagicMock())
        assert result == '{"name": "Jane"}'

    def test_returns_empty_string_after_exhausting_retries(self):
        from linkedin_lion.commands.extract import _call_llm_with_retry
        with patch("linkedin_lion.commands.extract._llmdog_available", True), patch(
            "linkedin_lion.commands.extract._llmdog_chat",
            side_effect=Exception("persistent error"),
            raising=False,
        ), patch("time.sleep"):
            result = _call_llm_with_retry("content", "prompt", 3, MagicMock())
        assert result == ""

    def test_correct_number_of_retry_attempts(self):
        from linkedin_lion.commands.extract import _call_llm_with_retry
        mock_chat = MagicMock(side_effect=Exception("error"))
        with patch("linkedin_lion.commands.extract._llmdog_available", True), patch(
            "linkedin_lion.commands.extract._llmdog_chat",
            mock_chat,
            raising=False,
        ), patch("time.sleep"):
            _call_llm_with_retry("content", "prompt", 3, MagicMock())
        assert mock_chat.call_count == 3

    def test_sleep_called_between_retries(self):
        from linkedin_lion.commands.extract import _call_llm_with_retry
        with patch("linkedin_lion.commands.extract._llmdog_available", True), patch(
            "linkedin_lion.commands.extract._llmdog_chat",
            side_effect=[Exception("e1"), Exception("e2"), '{"name": "ok"}'],
            raising=False,
        ), patch("time.sleep") as mock_sleep:
            _call_llm_with_retry("content", "prompt", 3, MagicMock())
        # 两次失败 → sleep 被调用两次（最后一次成功不 sleep）
        assert mock_sleep.call_count == 2


# ==================== extract_resume ====================


class TestExtractResume:
    def _patch_extract_deps(self, api_key="sk-test", llm_response='{"name": "Test"}'):
        """返回用于 extract_resume 成功路径的 patch 堆叠。"""
        from linkedin_lion.config import LionConfig

        return [
            patch("linkedin_lion.commands.extract._llmdog_available", True),
            patch(
                "linkedin_lion.commands.extract.load_config",
                return_value=LionConfig(api_key=api_key),
            ),
            patch(
                "linkedin_lion.commands.extract._llm_load_config",
                return_value=MagicMock(),
                raising=False,
            ),
            patch(
                "linkedin_lion.commands.extract._llmdog_chat",
                return_value=llm_response,
                raising=False,
            ),
        ]

    def test_returns_early_when_llmdog_unavailable(
        self, sample_resume_file, output_dir
    ):
        from linkedin_lion.commands.extract import extract_resume
        with patch("linkedin_lion.commands.extract._llmdog_available", False):
            extract_resume(sample_resume_file, output_dir)
        assert len(list(Path(output_dir).glob("*.json"))) == 0

    def test_returns_early_when_api_key_missing(
        self, sample_resume_file, output_dir
    ):
        from linkedin_lion.commands.extract import extract_resume
        from linkedin_lion.config import LionConfig
        with patch("linkedin_lion.commands.extract._llmdog_available", True), patch(
            "linkedin_lion.commands.extract.load_config",
            return_value=LionConfig(api_key=""),
        ):
            extract_resume(sample_resume_file, output_dir)
        assert len(list(Path(output_dir).glob("*.json"))) == 0

    def test_success_single_file_creates_json(self, sample_resume_file, output_dir):
        from linkedin_lion.commands.extract import extract_resume
        patches = self._patch_extract_deps(
            llm_response='{"name": "John Doe", "title": "Engineer"}'
        )
        with patches[0], patches[1], patches[2], patches[3]:
            extract_resume(sample_resume_file, output_dir)

        json_files = list(Path(output_dir).glob("*.json"))
        assert len(json_files) == 1
        data = json.loads(json_files[0].read_text(encoding="utf-8"))
        assert data["name"] == "John Doe"

    def test_success_directory_processes_all_txt_files(
        self, tmp_path, output_dir
    ):
        from linkedin_lion.commands.extract import extract_resume
        for name in ["alice", "bob", "carol"]:
            (tmp_path / f"{name}.txt").write_text(f"{name} resume")

        patches = self._patch_extract_deps()
        with patches[0], patches[1], patches[2], patches[3]:
            extract_resume(str(tmp_path), output_dir)

        assert len(list(Path(output_dir).glob("*.json"))) == 3

    def test_output_filename_matches_input_stem(self, sample_resume_file, output_dir):
        from linkedin_lion.commands.extract import extract_resume
        patches = self._patch_extract_deps()
        with patches[0], patches[1], patches[2], patches[3]:
            extract_resume(sample_resume_file, output_dir)

        expected_stem = Path(sample_resume_file).stem  # "johndoe"
        output_file = Path(output_dir) / f"{expected_stem}.json"
        assert output_file.exists()

    def test_custom_prompt_template_is_used(self, sample_resume_file, output_dir):
        from linkedin_lion.commands.extract import extract_resume
        captured = []

        def fake_chat(prompt, config=None):
            captured.append(prompt)
            return '{"name": "Test"}'

        from linkedin_lion.config import LionConfig
        with patch("linkedin_lion.commands.extract._llmdog_available", True), patch(
            "linkedin_lion.commands.extract.load_config",
            return_value=LionConfig(api_key="sk-test"),
        ), patch(
            "linkedin_lion.commands.extract._llm_load_config",
            return_value=MagicMock(),
            raising=False,
        ), patch(
            "linkedin_lion.commands.extract._llmdog_chat",
            side_effect=fake_chat,
            raising=False,
        ):
            extract_resume(
                sample_resume_file,
                output_dir,
                prompt_template="MY_CUSTOM_PROMPT",
            )

        assert len(captured) == 1
        assert "MY_CUSTOM_PROMPT" in captured[0]

    def test_default_prompt_used_when_none(self, sample_resume_file, output_dir):
        from linkedin_lion.commands.extract import extract_resume
        captured = []

        def fake_chat(prompt, config=None):
            captured.append(prompt)
            return '{"name": "Default"}'

        from linkedin_lion.config import LionConfig
        with patch("linkedin_lion.commands.extract._llmdog_available", True), patch(
            "linkedin_lion.commands.extract.load_config",
            return_value=LionConfig(api_key="sk-test"),
        ), patch(
            "linkedin_lion.commands.extract._llm_load_config",
            return_value=MagicMock(),
            raising=False,
        ), patch(
            "linkedin_lion.commands.extract._llmdog_chat",
            side_effect=fake_chat,
            raising=False,
        ):
            extract_resume(sample_resume_file, output_dir, prompt_template=None)

        assert DEFAULT_PROMPT_TEMPLATE in captured[0]

    def test_creates_output_dir_if_not_exists(self, sample_resume_file, tmp_path):
        from linkedin_lion.commands.extract import extract_resume
        new_output = str(tmp_path / "brand_new_dir")
        assert not Path(new_output).exists()

        patches = self._patch_extract_deps()
        with patches[0], patches[1], patches[2], patches[3]:
            extract_resume(sample_resume_file, new_output)

        assert Path(new_output).exists()

    def test_invalid_input_path_does_not_raise(self, output_dir):
        """非法路径（无 .txt 也非目录）应打印错误并平稳返回，不抛异常。"""
        from linkedin_lion.commands.extract import extract_resume
        from linkedin_lion.config import LionConfig
        with patch("linkedin_lion.commands.extract._llmdog_available", True), patch(
            "linkedin_lion.commands.extract.load_config",
            return_value=LionConfig(api_key="sk-test"),
        ), patch(
            "linkedin_lion.commands.extract._llm_load_config",
            return_value=MagicMock(),
            raising=False,
        ):
            # 不应抛出异常
            extract_resume("/nonexistent/file.pdf", output_dir)
