"""
test_integration.py — 端到端集成测试

验证模块间协作的完整工作流：

1. test_scrape_then_extract_workflow
   批量抓取（mock 浏览器，实际写入 .txt）→ LLM 提取（mock LLM）→ 校验 JSON 输出

2. test_batch_scrape_processes_only_specified_range
   batch_scrape 的 start/end 范围控制按预期只处理指定条目

3. test_extract_multiple_resumes_produces_correct_count
   目录中多个简历均被 LLM 提取并生成对应 JSON

4. test_config_api_key_flows_into_llm_call
   load_config() 的 api_key 最终传递到 llmdog 配置（端到端配置链）

5. test_batch_skip_and_success_mixed
   批量抓取中，已存在文件被跳过，新文件被处理，最终 stats 正确
"""

import json
import os
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from linkedin_lion.config import LionConfig


# ==================== 辅助函数 ====================


def _make_mock_llm_patches(
    api_key: str = "sk-integration-test",
    llm_response: str = '{"name": "Test", "title": "Engineer"}',
):
    """返回 extract_resume 所需的完整 mock patch 列表。"""
    return [
        patch("linkedin_lion.commands.extract._llmdog_available", True),
        patch(
            "linkedin_lion.commands.extract.load_config",
            return_value=LionConfig(api_key=api_key),
        ),
        patch(
            "linkedin_lion.commands.extract._llm_load_config",
            return_value=MagicMock(),
            raising=False,
        ),
        patch(
            "linkedin_lion.commands.extract._llmdog_chat",
            return_value=llm_response,
            raising=False,
        ),
    ]


# ==================== 集成测试 ====================


class TestScrapeToExtractWorkflow:
    """
    最典型的完整流程：
      batch_scrape (mock 浏览器 + 真实写文件) → extract_resume (mock LLM)
    """

    def test_scrape_then_extract_produces_json(self, tmp_path):
        from linkedin_lion.commands.batch import batch_scrape
        from linkedin_lion.commands.extract import extract_resume

        resumes_dir = tmp_path / "resumes"
        json_dir = tmp_path / "json_output"
        resumes_dir.mkdir()
        json_dir.mkdir()

        urls_file = tmp_path / "urls.txt"
        urls_file.write_text(
            "https://www.linkedin.com/in/johndoe/\n", encoding="utf-8"
        )

        # Step 1: batch_scrape — mock login/scrape_profile，但真实写入 .txt 文件
        mock_driver = MagicMock()

        def fake_scrape(driver, url, filename, folder):
            path = Path(folder) / filename
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text("John Doe\nEngineer at Google\nSF, CA", encoding="utf-8")
            return "John Doe\nEngineer at Google\nSF, CA"

        with patch(
            "linkedin_lion.commands.batch.login", return_value=mock_driver
        ), patch(
            "linkedin_lion.commands.batch.scrape_profile", side_effect=fake_scrape
        ):
            scrape_ok = batch_scrape(
                filepath=str(urls_file),
                output_dir=str(resumes_dir),
                start=0,
                end=1,
            )

        assert scrape_ok is True
        txt_files = list(resumes_dir.glob("*.txt"))
        assert len(txt_files) == 1

        # Step 2: extract_resume — mock LLM，读取 Step 1 产生的 .txt
        json_response = (
            '{"name": "John Doe", "title": "Engineer", "company": "Google"}'
        )
        patches = _make_mock_llm_patches(llm_response=json_response)
        with patches[0], patches[1], patches[2], patches[3]:
            extract_resume(str(resumes_dir), str(json_dir))

        json_files = list(json_dir.glob("*.json"))
        assert len(json_files) == 1
        data = json.loads(json_files[0].read_text(encoding="utf-8"))
        assert data["name"] == "John Doe"
        assert data["company"] == "Google"


class TestBatchScrapeRangeControl:
    def test_only_processes_specified_range(self, tmp_path):
        from linkedin_lion.commands.batch import batch_scrape

        urls_file = tmp_path / "urls.txt"
        urls_file.write_text(
            "https://www.linkedin.com/in/a/\n"
            "https://www.linkedin.com/in/b/\n"
            "https://www.linkedin.com/in/c/\n"
            "https://www.linkedin.com/in/d/\n"
            "https://www.linkedin.com/in/e/\n",
            encoding="utf-8",
        )
        output_dir = str(tmp_path / "output")
        os.makedirs(output_dir)

        processed_urls = []
        mock_driver = MagicMock()

        def fake_scrape(driver, url, filename, folder):
            processed_urls.append(url)
            return "text"

        with patch(
            "linkedin_lion.commands.batch.login", return_value=mock_driver
        ), patch(
            "linkedin_lion.commands.batch.scrape_profile", side_effect=fake_scrape
        ):
            batch_scrape(str(urls_file), output_dir=output_dir, start=1, end=4)

        # 索引 1、2、3 → 3 个 URL
        assert len(processed_urls) == 3

    def test_skip_and_success_mixed_stats(self, tmp_path):
        """已存在文件被跳过，新文件被处理，整体返回 True（无失败）。"""
        from linkedin_lion.commands.batch import batch_scrape

        output_dir = tmp_path / "output"
        output_dir.mkdir()
        # johndoe 已存在 → 跳过
        (output_dir / "johndoe.txt").write_text("existing")

        urls_file = tmp_path / "urls.txt"
        urls_file.write_text(
            "https://www.linkedin.com/in/johndoe/\n"
            "https://www.linkedin.com/in/janedoe/\n",
            encoding="utf-8",
        )

        mock_driver = MagicMock()
        with patch(
            "linkedin_lion.commands.batch.login", return_value=mock_driver
        ), patch(
            "linkedin_lion.commands.batch.scrape_profile", return_value="new text"
        ) as mock_scrape:
            result = batch_scrape(str(urls_file), output_dir=str(output_dir))

        # johndoe 跳过 → scrape 调用 1 次（janedoe）
        assert mock_scrape.call_count == 1
        assert result is True


class TestExtractMultipleResumes:
    def test_processes_all_files_in_directory(self, tmp_path):
        from linkedin_lion.commands.extract import extract_resume

        resumes_dir = tmp_path / "resumes"
        json_dir = tmp_path / "json_output"
        resumes_dir.mkdir()
        json_dir.mkdir()

        names = ["alice", "bob", "carol", "dave"]
        for name in names:
            (resumes_dir / f"{name}.txt").write_text(f"{name} resume content")

        patches = _make_mock_llm_patches()
        with patches[0], patches[1], patches[2], patches[3]:
            extract_resume(str(resumes_dir), str(json_dir))

        assert len(list(json_dir.glob("*.json"))) == len(names)

    def test_output_filenames_match_input_stems(self, tmp_path):
        from linkedin_lion.commands.extract import extract_resume

        resumes_dir = tmp_path / "resumes"
        json_dir = tmp_path / "json_output"
        resumes_dir.mkdir()
        json_dir.mkdir()
        (resumes_dir / "alice_resume.txt").write_text("Alice content")

        patches = _make_mock_llm_patches()
        with patches[0], patches[1], patches[2], patches[3]:
            extract_resume(str(resumes_dir), str(json_dir))

        assert (json_dir / "alice_resume.json").exists()


class TestConfigFlowsIntoLlm:
    """验证 load_config 的值通过完整链路传递至 LLM 调用。"""

    def test_api_key_and_model_reach_llm_config(self, sample_resume_file, output_dir):
        from linkedin_lion.commands.extract import extract_resume

        captured_kwargs = []

        def fake_llm_load_config(**kwargs):
            captured_kwargs.append(kwargs)
            return MagicMock()

        with patch("linkedin_lion.commands.extract._llmdog_available", True), patch(
            "linkedin_lion.commands.extract.load_config",
            return_value=LionConfig(
                api_key="sk-real-key-xyz",
                model="qwen-turbo",
                timeout=45,
            ),
        ), patch(
            "linkedin_lion.commands.extract._llm_load_config",
            side_effect=fake_llm_load_config,
            raising=False,
        ), patch(
            "linkedin_lion.commands.extract._llmdog_chat",
            return_value='{"name": "Test"}',
            raising=False,
        ):
            extract_resume(sample_resume_file, output_dir)

        assert len(captured_kwargs) == 1
        assert captured_kwargs[0]["api_key"] == "sk-real-key-xyz"
        assert captured_kwargs[0]["model"] == "qwen-turbo"
        assert captured_kwargs[0]["timeout"] == 45
