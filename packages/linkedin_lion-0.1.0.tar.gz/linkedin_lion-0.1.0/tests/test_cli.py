"""
test_cli.py — linkedin_lion.cli CLI 接口测试

使用 typer.testing.CliRunner 驱动 CLI，验证：
  - lion version          版本信息输出
  - lion --help           顶级帮助包含所有子命令
  - lion scrape --help    子命令帮助可访问
  - lion batch --help     子命令帮助可访问
  - lion extract --help   子命令帮助可访问
  - lion scrape run       成功路径 (exit_code=0) / 失败路径 (exit_code=1) /
                          selenium 不可用 (exit_code=1)
  - lion batch run        成功路径 / 文件不存在失败路径
  - lion extract run      成功路径 / 自定义 prompt 文件

命令调用格式：
  lion scrape run <url>   → Typer 子命令路由：group=scrape, cmd=run
  lion batch run <file>   → group=batch,   cmd=run
  lion extract run <path> → group=extract, cmd=run
"""

import json
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from typer.testing import CliRunner

from linkedin_lion.cli import app

runner = CliRunner(mix_stderr=False)


# ==================== version ====================


class TestVersionCommand:
    def test_exits_successfully(self):
        result = runner.invoke(app, ["version"])
        assert result.exit_code == 0

    def test_output_contains_linkedin_lion(self):
        result = runner.invoke(app, ["version"])
        assert "linkedin-lion" in result.output


# ==================== --help ====================


class TestHelpOutput:
    def test_top_level_help_exits_successfully(self):
        result = runner.invoke(app, ["--help"])
        assert result.exit_code == 0

    def test_top_level_help_shows_scrape(self):
        result = runner.invoke(app, ["--help"])
        assert "scrape" in result.output

    def test_top_level_help_shows_batch(self):
        result = runner.invoke(app, ["--help"])
        assert "batch" in result.output

    def test_top_level_help_shows_extract(self):
        result = runner.invoke(app, ["--help"])
        assert "extract" in result.output

    def test_top_level_help_shows_version(self):
        result = runner.invoke(app, ["--help"])
        assert "version" in result.output

    def test_scrape_help_accessible(self):
        result = runner.invoke(app, ["scrape", "--help"])
        assert result.exit_code == 0

    def test_batch_help_accessible(self):
        result = runner.invoke(app, ["batch", "--help"])
        assert result.exit_code == 0

    def test_extract_help_accessible(self):
        result = runner.invoke(app, ["extract", "--help"])
        assert result.exit_code == 0


# ==================== lion scrape run ====================


class TestScrapeRunCommand:
    _URL = "https://www.linkedin.com/talent/profile/ACoAAA"

    def test_success_exits_zero(self, tmp_path):
        mock_driver = MagicMock()
        with patch("linkedin_lion.commands.scrape._selenium_available", True), patch(
            "linkedin_lion.commands.scrape.login", return_value=mock_driver
        ), patch(
            "linkedin_lion.commands.scrape.scrape_profile", return_value="text"
        ):
            result = runner.invoke(
                app, ["scrape", "run", self._URL, "--folder", str(tmp_path)]
            )
        assert result.exit_code == 0

    def test_failure_exits_one_when_scrape_returns_none(self, tmp_path):
        mock_driver = MagicMock()
        with patch("linkedin_lion.commands.scrape._selenium_available", True), patch(
            "linkedin_lion.commands.scrape.login", return_value=mock_driver
        ), patch(
            "linkedin_lion.commands.scrape.scrape_profile", return_value=None
        ):
            result = runner.invoke(
                app, ["scrape", "run", self._URL, "--folder", str(tmp_path)]
            )
        assert result.exit_code == 1

    def test_selenium_unavailable_exits_one(self, tmp_path):
        with patch("linkedin_lion.commands.scrape._selenium_available", False):
            result = runner.invoke(
                app, ["scrape", "run", self._URL, "--folder", str(tmp_path)]
            )
        assert result.exit_code == 1

    def test_driver_quit_called_after_success(self, tmp_path):
        mock_driver = MagicMock()
        with patch("linkedin_lion.commands.scrape._selenium_available", True), patch(
            "linkedin_lion.commands.scrape.login", return_value=mock_driver
        ), patch(
            "linkedin_lion.commands.scrape.scrape_profile", return_value="text"
        ):
            runner.invoke(
                app, ["scrape", "run", self._URL, "--folder", str(tmp_path)]
            )
        mock_driver.quit.assert_called_once()

    def test_custom_cookie_option_accepted(self, tmp_path):
        mock_driver = MagicMock()
        with patch("linkedin_lion.commands.scrape._selenium_available", True), patch(
            "linkedin_lion.commands.scrape.login", return_value=mock_driver
        ) as mock_login, patch(
            "linkedin_lion.commands.scrape.scrape_profile", return_value="text"
        ):
            runner.invoke(
                app,
                [
                    "scrape",
                    "run",
                    self._URL,
                    "--cookie",
                    "my_cookie.json",
                    "--folder",
                    str(tmp_path),
                ],
            )
        # cookie 应被传递到 login
        call_kwargs = mock_login.call_args
        assert "my_cookie.json" in str(call_kwargs)


# ==================== lion batch run ====================


class TestBatchRunCommand:
    def test_success_exits_zero(self, sample_urls_file, output_dir):
        mock_driver = MagicMock()
        with patch(
            "linkedin_lion.commands.batch.login", return_value=mock_driver
        ), patch(
            "linkedin_lion.commands.batch.scrape_profile", return_value="text"
        ):
            result = runner.invoke(
                app,
                ["batch", "run", sample_urls_file, "--output-dir", output_dir],
            )
        assert result.exit_code == 0

    def test_file_not_found_exits_one(self, output_dir):
        result = runner.invoke(
            app,
            ["batch", "run", "/nonexistent/urls.txt", "--output-dir", output_dir],
        )
        assert result.exit_code == 1

    def test_start_end_options_accepted(self, sample_urls_file, output_dir):
        mock_driver = MagicMock()
        with patch(
            "linkedin_lion.commands.batch.login", return_value=mock_driver
        ), patch(
            "linkedin_lion.commands.batch.scrape_profile", return_value="text"
        ):
            result = runner.invoke(
                app,
                [
                    "batch",
                    "run",
                    sample_urls_file,
                    "--output-dir",
                    output_dir,
                    "--start",
                    "0",
                    "--end",
                    "1",
                ],
            )
        assert result.exit_code == 0

    def test_headless_flag_accepted(self, sample_urls_file, output_dir):
        mock_driver = MagicMock()
        with patch(
            "linkedin_lion.commands.batch.login", return_value=mock_driver
        ) as mock_login, patch(
            "linkedin_lion.commands.batch.scrape_profile", return_value="text"
        ):
            runner.invoke(
                app,
                [
                    "batch",
                    "run",
                    sample_urls_file,
                    "--output-dir",
                    output_dir,
                    "--headless",
                    "--end",
                    "1",
                ],
            )
        mock_login.assert_called_once_with(
            cookie_file="cookie.json", headless=True
        )


# ==================== lion extract run ====================


class TestExtractRunCommand:
    def _mock_extract_deps(self, api_key="sk-test"):
        from linkedin_lion.config import LionConfig
        return [
            patch("linkedin_lion.commands.extract._llmdog_available", True),
            patch(
                "linkedin_lion.commands.extract.load_config",
                return_value=LionConfig(api_key=api_key),
            ),
            patch(
                "linkedin_lion.commands.extract._llm_load_config",
                return_value=MagicMock(),
                raising=False,
            ),
            patch(
                "linkedin_lion.commands.extract._llmdog_chat",
                return_value='{"name": "Test"}',
                raising=False,
            ),
        ]

    def test_success_exits_zero(self, sample_resume_file, output_dir):
        patches = self._mock_extract_deps()
        with patches[0], patches[1], patches[2], patches[3]:
            result = runner.invoke(
                app,
                ["extract", "run", sample_resume_file, "--output", output_dir],
            )
        assert result.exit_code == 0

    def test_creates_json_output_file(self, sample_resume_file, output_dir):
        patches = self._mock_extract_deps()
        with patches[0], patches[1], patches[2], patches[3]:
            runner.invoke(
                app,
                ["extract", "run", sample_resume_file, "--output", output_dir],
            )
        assert len(list(Path(output_dir).glob("*.json"))) == 1

    def test_custom_prompt_file_option(self, sample_resume_file, output_dir, tmp_path):
        prompt_file = tmp_path / "prompt.txt"
        prompt_file.write_text("MY_CUSTOM_PROMPT_CONTENT")

        captured = []

        def fake_chat(prompt, config=None):
            captured.append(prompt)
            return '{"name": "Test"}'

        from linkedin_lion.config import LionConfig
        with patch("linkedin_lion.commands.extract._llmdog_available", True), patch(
            "linkedin_lion.commands.extract.load_config",
            return_value=LionConfig(api_key="sk-test"),
        ), patch(
            "linkedin_lion.commands.extract._llm_load_config",
            return_value=MagicMock(),
            raising=False,
        ), patch(
            "linkedin_lion.commands.extract._llmdog_chat",
            side_effect=fake_chat,
            raising=False,
        ):
            runner.invoke(
                app,
                [
                    "extract",
                    "run",
                    sample_resume_file,
                    "--output",
                    output_dir,
                    "--prompt-file",
                    str(prompt_file),
                ],
            )

        assert any("MY_CUSTOM_PROMPT_CONTENT" in p for p in captured)

    def test_max_retries_option_accepted(self, sample_resume_file, output_dir):
        patches = self._mock_extract_deps()
        with patches[0], patches[1], patches[2], patches[3]:
            result = runner.invoke(
                app,
                [
                    "extract",
                    "run",
                    sample_resume_file,
                    "--output",
                    output_dir,
                    "--max-retries",
                    "5",
                ],
            )
        assert result.exit_code == 0
