import re
from typing import List, Dict

from .models import RCAResult
from .utils import read_lines


ERROR_SIGNATURES = {
    "null_reference": r"(NoneType|undefined|null reference)",
    "assertion_failure": r"(AssertionError|expect\(.*\) to)",
    "network_failure": r"(ECONNREFUSED|timeout|5\d\d)",
    "selector_break": r"(locator|selector|element not found)",
}


def _extract_changed_files(diff_lines: List[str]) -> List[str]:
    files = []
    for line in diff_lines:
        if line.startswith("+++ b/"):
            files.append(line.replace("+++ b/", "").strip())
    return files


def analyze_failure(logs_path: str, diff_path: str) -> RCAResult:
    log_lines = read_lines(logs_path)
    diff_lines = read_lines(diff_path)
    log_blob = "\n".join(log_lines)

    likely_causes: List[str] = []
    evidence: Dict[str, List[str]] = {}
    changed_files = _extract_changed_files(diff_lines)

    for cause, pattern in ERROR_SIGNATURES.items():
        if re.search(pattern, log_blob, flags=re.IGNORECASE):
            likely_causes.append(cause)
            evidence[cause] = [line for line in log_lines if re.search(pattern, line, flags=re.IGNORECASE)][:5]

    if not likely_causes:
        likely_causes.append("unknown_failure")
        evidence["unknown_failure"] = log_lines[:5]

    suggested_fixes: List[str] = []
    if "selector_break" in likely_causes:
        suggested_fixes.append("Update brittle selectors to role/text/data-testid strategy.")
    if "network_failure" in likely_causes:
        suggested_fixes.append("Add service readiness checks and resilient retries in test setup.")
    if "assertion_failure" in likely_causes:
        suggested_fixes.append("Compare expected payload with latest API contract and update assertions.")
    if "null_reference" in likely_causes:
        suggested_fixes.append("Add defensive null checks and validate fixture/test data setup.")

    if changed_files:
        suggested_fixes.append("Prioritize review of recent changes in: " + ", ".join(changed_files[:5]))

    return RCAResult(
        likely_causes=likely_causes,
        evidence=evidence,
        suggested_fixes=list(dict.fromkeys(suggested_fixes)) or ["No concrete fix inferred; inspect full trace and recent commits."],
    )
