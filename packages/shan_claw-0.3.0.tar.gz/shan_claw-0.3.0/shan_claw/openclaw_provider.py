import json
import os
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, List

from .coverage import detect_coverage_gaps, parse_requirements
from .models import CoverageResult, RCAResult, Requirement
from .rca import analyze_failure
from .security import scan_dependencies
from .self_heal import suggest_healing_actions
from .testgen import generate_tests_for_gaps
from .utils import read_lines, slugify


class OpenClawExecutionError(RuntimeError):
    pass


@dataclass
class OpenClawConfig:
    mode: str = "local"
    api_key: str = ""
    agent_id: str = ""
    model: str = ""
    timeout_seconds: int = 120


class OpenClawProvider:
    def __init__(self, config: OpenClawConfig):
        self.config = config

    def _run(self, prompt: str) -> str:
        try:
            from openclaw import OpenClaw
            from cmdop.models.agent import AgentRunOptions, AgentType
        except Exception as exc:
            raise OpenClawExecutionError(f"OpenClaw import failed: {exc}") from exc

        client = None
        try:
            if self.config.mode == "remote":
                api_key = self.config.api_key or os.getenv("OPENCLAW_API_KEY", "") or os.getenv("CMDOP_API_KEY", "")
                if not api_key:
                    raise OpenClawExecutionError("Remote mode requires OPENCLAW_API_KEY or CMDOP_API_KEY.")
                client = OpenClaw.remote(api_key=api_key, agent_id=self.config.agent_id or None)
            else:
                client = OpenClaw.local()

            options = AgentRunOptions(timeout_seconds=max(10, int(self.config.timeout_seconds)))
            if self.config.model:
                options.model = self.config.model

            result = client.agent.run(prompt=prompt, agent_type=AgentType.CHAT, options=options)
            if not result.success:
                raise OpenClawExecutionError(result.error or "OpenClaw returned unsuccessful result.")
            return (result.text or "").strip()
        except OpenClawExecutionError:
            raise
        except Exception as exc:
            raise OpenClawExecutionError(str(exc)) from exc
        finally:
            if client is not None:
                try:
                    client.close()
                except Exception:
                    pass

    @staticmethod
    def _strip_code_fence(text: str) -> str:
        return re.sub(r"^```[a-zA-Z]*\n|\n```$", "", text.strip())

    @staticmethod
    def _extract_json(text: str) -> Any:
        try:
            return json.loads(text)
        except Exception:
            pass

        start_obj = text.find("{")
        end_obj = text.rfind("}")
        if start_obj != -1 and end_obj != -1 and end_obj > start_obj:
            try:
                return json.loads(text[start_obj : end_obj + 1])
            except Exception:
                pass

        start_arr = text.find("[")
        end_arr = text.rfind("]")
        if start_arr != -1 and end_arr != -1 and end_arr > start_arr:
            try:
                return json.loads(text[start_arr : end_arr + 1])
            except Exception:
                pass

        raise ValueError("Could not parse JSON from OpenClaw response")

    def parse_requirements_with_openclaw(self, requirements_path: str) -> List[Requirement]:
        lines = read_lines(requirements_path)
        prompt = (
            "You are a QA requirement parser. Return ONLY JSON array. "
            "Each item: {raw: string, normalized: string, tags: string[]}. "
            f"Input requirements: {json.dumps(lines)}"
        )
        try:
            data = self._extract_json(self._run(prompt))
            requirements: List[Requirement] = []
            for item in data:
                requirements.append(
                    Requirement(
                        raw=str(item.get("raw", "")).strip(),
                        normalized=str(item.get("normalized", "")).strip() or str(item.get("raw", "")).strip(),
                        tags=[str(tag).strip().lower() for tag in item.get("tags", []) if str(tag).strip()],
                    )
                )
            return [req for req in requirements if req.normalized]
        except Exception:
            return parse_requirements(requirements_path)

    def detect_coverage_with_openclaw(self, requirements: List[Requirement], tests_path: str) -> CoverageResult:
        test_inventory = read_lines(tests_path)
        prompt = (
            "You are a test coverage analyzer. Return ONLY JSON object: "
            "{matched: string[], gaps: string[]}. "
            f"Requirements={json.dumps([req.normalized for req in requirements])}; "
            f"ExistingTests={json.dumps(test_inventory)}"
        )
        try:
            data = self._extract_json(self._run(prompt))
            return CoverageResult(
                matched=[str(x) for x in data.get("matched", [])],
                gaps=[str(x) for x in data.get("gaps", [])],
            )
        except Exception:
            return detect_coverage_gaps(requirements, tests_path)

    def generate_tests_with_openclaw(self, gaps: List[str], output_dir: str = "generated_tests") -> List[str]:
        out = Path(output_dir)
        out.mkdir(parents=True, exist_ok=True)
        generated: List[str] = []

        for gap in gaps:
            prompt = (
                "Generate ONE Playwright TypeScript test for this requirement. "
                "Return code only, no markdown fences, no explanation. "
                f"Requirement: {gap}"
            )
            try:
                code = self._strip_code_fence(self._run(prompt))
                if "test(" not in code:
                    raise ValueError("No test function returned")
                filename = f"test_{slugify(gap)[:70]}.spec.ts"
                path = out / filename
                path.write_text(code + ("\n" if not code.endswith("\n") else ""), encoding="utf-8")
                generated.append(str(path))
            except Exception:
                generated.extend(generate_tests_for_gaps([gap], output_dir=output_dir))

        return generated

    def suggest_heal_with_openclaw(self, logs_path: str) -> List[str]:
        log_lines = read_lines(logs_path)
        prompt = (
            "You are a flaky-test healer. Return ONLY JSON array of concise healing actions. "
            f"Logs: {json.dumps(log_lines)}"
        )
        try:
            data = self._extract_json(self._run(prompt))
            if isinstance(data, list) and data:
                return [str(x) for x in data]
        except Exception:
            pass
        return suggest_healing_actions(logs_path)

    def rca_with_openclaw(self, logs_path: str, diff_path: str) -> RCAResult:
        log_lines = read_lines(logs_path)
        diff_lines = read_lines(diff_path)
        prompt = (
            "You are a QA RCA agent. Return ONLY JSON object with keys: "
            "likely_causes:string[], evidence:object<string,string[]>, suggested_fixes:string[]. "
            f"Logs: {json.dumps(log_lines)}; Diff: {json.dumps(diff_lines)}"
        )
        try:
            data = self._extract_json(self._run(prompt))
            return RCAResult(
                likely_causes=[str(x) for x in data.get("likely_causes", [])],
                evidence={str(k): [str(v) for v in vals] for k, vals in data.get("evidence", {}).items()},
                suggested_fixes=[str(x) for x in data.get("suggested_fixes", [])],
            )
        except Exception:
            return analyze_failure(logs_path, diff_path)

    def security_with_openclaw(self, deps_path: str):
        findings = scan_dependencies(deps_path)
        deps = read_lines(deps_path)
        prompt = (
            "Return ONLY JSON object mapping blocked package name to safer alternative package name. "
            f"Dependencies: {json.dumps(deps)}; "
            f"Current blocked: {json.dumps([f.name for f in findings if f.status == 'blocked'])}"
        )
        try:
            suggestions = self._extract_json(self._run(prompt))
            if isinstance(suggestions, dict):
                for finding in findings:
                    if finding.status == "blocked" and finding.name in suggestions:
                        finding.details = f"{finding.details} Suggested alternative: {suggestions[finding.name]}"
        except Exception:
            pass

        return findings