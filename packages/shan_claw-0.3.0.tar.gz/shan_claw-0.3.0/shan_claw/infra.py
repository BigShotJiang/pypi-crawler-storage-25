from pathlib import Path


def generate_regression_environment(service_name: str, out_dir: str = "output/env") -> dict:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)

    compose = out / "docker-compose.yml"
    seed_data = out / "seed-data.json"

    compose.write_text(
        f"""version: '3.9'
services:
  {service_name}:
    image: {service_name}:latest
    container_name: {service_name}-regression
    environment:
      - ENV=regression
      - LOG_LEVEL=debug
    ports:
      - \"8080:8080\"
    depends_on:
      - db

  db:
    image: postgres:16
    container_name: {service_name}-db
    environment:
      - POSTGRES_DB={service_name}
      - POSTGRES_USER=qa
      - POSTGRES_PASSWORD=qa
    ports:
      - \"5432:5432\"
""",
        encoding="utf-8",
    )

    seed_data.write_text(
        """{
  \"customers\": [
    {\"id\": \"cust-1001\", \"segment\": \"premium\"},
    {\"id\": \"cust-1002\", \"segment\": \"standard\"}
  ],
  \"orders\": [
    {\"id\": \"ord-9001\", \"status\": \"pending\"}
  ]
}
""",
        encoding="utf-8",
    )

    return {
        "service": service_name,
        "compose_file": str(compose),
        "seed_data": str(seed_data),
        "message": "Regression environment blueprint created.",
    }
