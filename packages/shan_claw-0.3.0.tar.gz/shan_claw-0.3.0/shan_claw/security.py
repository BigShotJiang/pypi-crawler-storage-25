import hashlib
import os
from typing import List

import requests

from .models import DependencyFinding
from .utils import read_lines


MOCK_BLOCKLIST = {
    "event-stream": "Known historical supply-chain compromise risk.",
    "ua-parser-js": "Past malicious package publication incident.",
}


def _parse_dependency(dep: str) -> tuple[str, str]:
    if "==" in dep:
        name, version = dep.split("==", 1)
        return name.strip(), version.strip()
    return dep.strip(), "unknown"


def _sha256_digest(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def _virustotal_check(digest: str, api_key: str) -> str:
    # This checks by file hash endpoint; useful when teams also track vendored artifacts.
    url = f"https://www.virustotal.com/api/v3/files/{digest}"
    headers = {"x-apikey": api_key}
    response = requests.get(url, headers=headers, timeout=8)
    if response.status_code == 404:
        return "not_found"
    if response.status_code >= 400:
        return f"error_{response.status_code}"

    data = response.json()
    stats = data.get("data", {}).get("attributes", {}).get("last_analysis_stats", {})
    malicious = int(stats.get("malicious", 0)) + int(stats.get("suspicious", 0))
    return "flagged" if malicious > 0 else "clean"


def scan_dependencies(deps_path: str) -> List[DependencyFinding]:
    lines = read_lines(deps_path)
    api_key = os.getenv("VIRUSTOTAL_API_KEY", "").strip()

    findings: List[DependencyFinding] = []
    for line in lines:
        name, version = _parse_dependency(line)

        if name in MOCK_BLOCKLIST:
            findings.append(
                DependencyFinding(
                    name=name,
                    version=version,
                    status="blocked",
                    details=MOCK_BLOCKLIST[name],
                )
            )
            continue

        digest = _sha256_digest(f"{name}=={version}")
        if api_key:
            vt_status = _virustotal_check(digest, api_key)
            if vt_status == "flagged":
                findings.append(
                    DependencyFinding(
                        name=name,
                        version=version,
                        status="blocked",
                        details="VirusTotal flagged this hash as malicious/suspicious.",
                    )
                )
                continue

        findings.append(
            DependencyFinding(
                name=name,
                version=version,
                status="allowed",
                details="No blocking signal detected.",
            )
        )

    return findings
