from pathlib import Path
from typing import List

from .utils import slugify


def _render_playwright_test(requirement: str) -> str:
    title = requirement.replace("'", "")
    return f"""import {{ test, expect }} from '@playwright/test';

test('{title}', async ({{ page }}) => {{
  // TODO: Implement steps derived from requirement
  await page.goto('http://localhost:3000');
  await expect(page).toHaveTitle(/.*/);
}});
"""


def generate_tests_for_gaps(gaps: List[str], output_dir: str = "generated_tests") -> List[str]:
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)

    generated: List[str] = []
    for gap in gaps:
        filename = f"test_{slugify(gap)[:70]}.spec.ts"
        path = out / filename
        path.write_text(_render_playwright_test(gap), encoding="utf-8")
        generated.append(str(path))

    return generated
