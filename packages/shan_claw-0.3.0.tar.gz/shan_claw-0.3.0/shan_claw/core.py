from .coverage import parse_requirements, detect_coverage_gaps
from .openclaw_provider import OpenClawConfig, OpenClawProvider
from .testgen import generate_tests_for_gaps
from .self_heal import suggest_healing_actions
from .rca import analyze_failure
from .security import scan_dependencies


def run_pipeline(
    requirements_path: str,
    tests_path: str,
    logs_path: str,
    diff_path: str,
    deps_path: str,
    provider: str = "local",
    openclaw_mode: str = "local",
    openclaw_api_key: str = "",
    openclaw_agent_id: str = "",
    openclaw_model: str = "",
    openclaw_timeout: int = 120,
):
    provider_used = "local"

    if provider == "openclaw":
        openclaw = OpenClawProvider(
            OpenClawConfig(
                mode=openclaw_mode,
                api_key=openclaw_api_key,
                agent_id=openclaw_agent_id,
                model=openclaw_model,
                timeout_seconds=openclaw_timeout,
            )
        )
        requirements = openclaw.parse_requirements_with_openclaw(requirements_path)
        coverage = openclaw.detect_coverage_with_openclaw(requirements, tests_path)
        generated_tests = openclaw.generate_tests_with_openclaw(coverage.gaps)
        heal_actions = openclaw.suggest_heal_with_openclaw(logs_path)
        rca = openclaw.rca_with_openclaw(logs_path, diff_path)
        dependency_findings = openclaw.security_with_openclaw(deps_path)
        provider_used = "openclaw"
    else:
        requirements = parse_requirements(requirements_path)
        coverage = detect_coverage_gaps(requirements, tests_path)
        generated_tests = generate_tests_for_gaps(coverage.gaps)
        heal_actions = suggest_healing_actions(logs_path)
        rca = analyze_failure(logs_path, diff_path)
        dependency_findings = scan_dependencies(deps_path)

    return {
        "provider": provider_used,
        "openclaw_mode": openclaw_mode if provider_used == "openclaw" else None,
        "requirements_count": len(requirements),
        "coverage": {
            "matched": coverage.matched,
            "gaps": coverage.gaps,
        },
        "generated_tests": generated_tests,
        "self_heal_actions": heal_actions,
        "rca": {
            "likely_causes": rca.likely_causes,
            "evidence": rca.evidence,
            "suggested_fixes": rca.suggested_fixes,
        },
        "dependency_findings": [finding.__dict__ for finding in dependency_findings],
    }
