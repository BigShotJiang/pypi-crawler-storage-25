import argparse
import json
import os
from pathlib import Path

from .core import run_pipeline
from .infra import generate_regression_environment


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Shan Claw autonomous QA prototype")
    sub = parser.add_subparsers(dest="command", required=True)

    run_cmd = sub.add_parser("run", help="Run full autonomous QA workflow")
    run_cmd.add_argument("--requirements", required=True, help="Path to requirements text file")
    run_cmd.add_argument("--tests", required=True, help="Path to existing tests inventory")
    run_cmd.add_argument("--logs", required=True, help="Path to failure logs")
    run_cmd.add_argument("--diff", required=True, help="Path to code diff")
    run_cmd.add_argument("--deps", required=True, help="Path to dependency list (name==version)")
    run_cmd.add_argument("--output", default="output/report.json", help="Path for JSON report output")
    run_cmd.add_argument("--provider", choices=["local", "openclaw"], default="local", help="Execution provider")
    run_cmd.add_argument("--openclaw-mode", choices=["local", "remote"], default="local", help="OpenClaw connection mode")
    run_cmd.add_argument(
        "--openclaw-api-key",
        default=os.getenv("OPENCLAW_API_KEY", os.getenv("CMDOP_API_KEY", "")),
        help="OpenClaw/CMDOP API key for remote mode",
    )
    run_cmd.add_argument("--openclaw-agent-id", default="", help="Target OpenClaw agent ID for remote mode")
    run_cmd.add_argument("--openclaw-model", default="", help="Model override for agent runs")
    run_cmd.add_argument("--openclaw-timeout", type=int, default=120, help="OpenClaw run timeout in seconds")

    provision_cmd = sub.add_parser("provision", help="Generate regression environment blueprint")
    provision_cmd.add_argument("--service", required=True, help="Service name, e.g. payment-v2")
    provision_cmd.add_argument("--out-dir", default="output/env", help="Output directory for compose and seed files")

    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()

    if args.command == "run":
        result = run_pipeline(
            requirements_path=args.requirements,
            tests_path=args.tests,
            logs_path=args.logs,
            diff_path=args.diff,
            deps_path=args.deps,
            provider=args.provider,
            openclaw_mode=args.openclaw_mode,
            openclaw_api_key=args.openclaw_api_key,
            openclaw_agent_id=args.openclaw_agent_id,
            openclaw_model=args.openclaw_model,
            openclaw_timeout=args.openclaw_timeout,
        )

        output_path = Path(args.output)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(json.dumps(result, indent=2), encoding="utf-8")
        print(f"Report written to {output_path}")

    if args.command == "provision":
        result = generate_regression_environment(service_name=args.service, out_dir=args.out_dir)
        print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
