import re
from typing import List

from .models import Requirement, CoverageResult
from .utils import read_lines


KEYWORD_MAP = {
    "login": ["auth", "login", "signin"],
    "payment": ["payment", "checkout", "invoice", "card"],
    "search": ["search", "query", "filter"],
    "profile": ["profile", "account", "user"],
    "security": ["security", "auth", "token", "permission"],
}


def _extract_tags(text: str) -> List[str]:
    lowered = text.lower()
    tags: List[str] = []
    for tag, aliases in KEYWORD_MAP.items():
        if any(alias in lowered for alias in aliases):
            tags.append(tag)
    return sorted(set(tags))


def parse_requirements(requirements_path: str) -> List[Requirement]:
    lines = read_lines(requirements_path)
    requirements: List[Requirement] = []
    for line in lines:
        normalized = re.sub(r"\s+", " ", line.strip())
        requirements.append(
            Requirement(
                raw=line,
                normalized=normalized,
                tags=_extract_tags(normalized),
            )
        )
    return requirements


def detect_coverage_gaps(requirements: List[Requirement], tests_path: str) -> CoverageResult:
    existing_tests = "\n".join(read_lines(tests_path)).lower()
    matched: List[str] = []
    gaps: List[str] = []

    for req in requirements:
        tokens = req.tags or req.normalized.lower().split()
        if any(token in existing_tests for token in tokens):
            matched.append(req.normalized)
        else:
            gaps.append(req.normalized)

    return CoverageResult(matched=matched, gaps=gaps)
