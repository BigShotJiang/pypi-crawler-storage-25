from dataclasses import dataclass, field
from typing import List, Dict


@dataclass
class Requirement:
    raw: str
    normalized: str
    tags: List[str] = field(default_factory=list)


@dataclass
class CoverageResult:
    matched: List[str]
    gaps: List[str]


@dataclass
class RCAResult:
    likely_causes: List[str]
    evidence: Dict[str, List[str]]
    suggested_fixes: List[str]


@dataclass
class DependencyFinding:
    name: str
    version: str
    status: str
    details: str
