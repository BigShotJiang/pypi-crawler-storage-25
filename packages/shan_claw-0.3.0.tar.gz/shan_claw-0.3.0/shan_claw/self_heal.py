import re
from typing import List

from .utils import read_lines


SELECTOR_PATTERNS = [
    r'Timeout\s+\d+ms\s+exceeded.*selector\s+"([^"]+)"',
    r"waiting for locator\('([^']+)'\)",
    r"No node found for selector:\s*(.+)$",
]


def suggest_healing_actions(logs_path: str) -> List[str]:
    lines = read_lines(logs_path)
    text = "\n".join(lines)
    actions: List[str] = []

    for pattern in SELECTOR_PATTERNS:
        for match in re.finditer(pattern, text, flags=re.IGNORECASE | re.MULTILINE):
            selector = match.group(1).strip()
            actions.append(
                f"Re-evaluate selector '{selector}' using semantic fallback (role/text/data-testid), then re-run test."
            )

    if not actions:
        actions.append("No selector-specific flake detected. Suggest retry with trace and screenshot for diagnosis.")

    return list(dict.fromkeys(actions))
