from shan_claw.security import scan_dependencies


def test_blocklisted_dependency(tmp_path):
    deps = tmp_path / "deps.txt"
    deps.write_text("event-stream==3.3.6\n", encoding="utf-8")

    findings = scan_dependencies(str(deps))
    assert findings[0].status == "blocked"
