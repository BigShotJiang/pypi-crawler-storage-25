from shan_claw.coverage import parse_requirements, detect_coverage_gaps


def test_parse_and_gap_detection(tmp_path):
    req = tmp_path / "req.txt"
    tst = tmp_path / "tests.txt"

    req.write_text("user can login\nuser can do payment\n", encoding="utf-8")
    tst.write_text("auth_login_test\n", encoding="utf-8")

    requirements = parse_requirements(str(req))
    result = detect_coverage_gaps(requirements, str(tst))

    assert len(requirements) == 2
    assert any("payment" in gap for gap in result.gaps)
