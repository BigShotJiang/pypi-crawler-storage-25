"""Agent prompt file discovery — AGENTS.md, CLAUDE.md, and workspace prompt roots."""

from __future__ import annotations

import sys
from pathlib import Path

AGENT_PROMPT_FILENAMES = (
    "AGENTS.md",
    "CLAUDE.md",
    "GEMINI.md",
    "COPILOT.md",
    "SYSTEM.md",
)

WORKSPACE_PROMPT_ROOTS = (
    ".agents/prompts",
    ".claude/prompts",
    ".augment/prompts",
)


def list_cwd_agent_prompt_files(root: Path | None = None) -> list[Path]:
    """List known agent prompt files in priority order from the cwd root."""
    cwd = root or Path.cwd()
    candidates: list[Path] = []
    for name in AGENT_PROMPT_FILENAMES:
        path = cwd / name
        if path.is_file():
            candidates.append(path)
    return candidates


def list_workspace_agent_prompt_files(root: Path | None = None) -> list[Path]:
    """List .md files from workspace prompt roots (.agents/prompts, etc.)."""
    cwd = root or Path.cwd()
    candidates: list[Path] = []
    for relative_root in WORKSPACE_PROMPT_ROOTS:
        prompt_dir = cwd / relative_root
        if not prompt_dir.is_dir():
            continue
        for path in sorted(prompt_dir.glob("*.md")):
            if path.is_file():
                candidates.append(path)
    return candidates


def list_available_agent_prompts(root: Path | None = None) -> list[Path]:
    """List all discoverable agent prompt files in priority order.

    Order:
    1. cwd root prompt files (AGENTS.md, CLAUDE.md, etc.) in priority order
    2. workspace prompt roots (.agents/prompts/, .claude/prompts/, etc.)
    """
    seen: set[Path] = set()
    candidates: list[Path] = []
    for path in [
        *list_cwd_agent_prompt_files(root),
        *list_workspace_agent_prompt_files(root),
    ]:
        resolved = path.resolve()
        if resolved in seen:
            continue
        seen.add(resolved)
        candidates.append(path)
    return candidates


def describe_agent_prompt_path(path: Path) -> str:
    """Return a friendly label for an agent prompt file."""
    try:
        relative = path.relative_to(Path.cwd())
        return f"cwd:{relative.as_posix()}"
    except ValueError:
        pass
    for relative_root in WORKSPACE_PROMPT_ROOTS:
        workspace_dir = Path.cwd() / relative_root
        try:
            relative = path.relative_to(workspace_dir)
            return f"workspace:{relative_root}/{relative.as_posix()}"
        except ValueError:
            pass
    return f"file:{path.name}"


def load_agent_prompt_content(path: Path) -> str | None:
    """Load and return agent prompt file content, or None on failure."""
    if not path.is_file():
        return None
    try:
        text = path.read_text(encoding="utf-8").strip()
    except UnicodeDecodeError:
        print(f"Warning: agent prompt file is not valid UTF-8 and was ignored: {path}", file=sys.stderr)
        return None
    return text or None


def auto_select_agent_prompt(root: Path | None = None) -> tuple[Path | None, str | None]:
    """Select the highest-priority agent prompt file.

    Returns (path, label) or (None, None) if none found.
    """
    candidates = list_available_agent_prompts(root)
    if not candidates:
        return None, None
    path = candidates[0]
    label = describe_agent_prompt_path(path)
    return path, label
