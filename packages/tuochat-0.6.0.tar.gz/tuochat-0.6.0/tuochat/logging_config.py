"""Logging configuration for tuochat.

Uses stdlib logging with JSON-structured output and token redaction.
"""

from __future__ import annotations

import logging
import re
from datetime import datetime, timezone
from pathlib import Path

from tuochat.serialization import json_dumps


class TokenRedactFilter(logging.Filter):
    """Redact GitLab tokens from log output."""

    patterns = [
        re.compile(r"(glpat-)\w+"),
        re.compile(r"(gloas-)\w+"),
        re.compile(r"(PRIVATE-TOKEN:\s*)\S+"),
        re.compile(r"(Authorization:\s*Bearer\s+)\S+"),
    ]

    def filter(self, record: logging.LogRecord) -> bool:
        """Redact tokens in the log message."""
        msg = record.getMessage()
        for pat in self.patterns:
            msg = pat.sub(r"\1***REDACTED***", msg)
        record.msg = msg
        record.args = None
        return True


class JsonFormatter(logging.Formatter):
    """Format log records as single-line JSON."""

    def format(self, record: logging.LogRecord) -> str:
        """Format a log record as JSON."""
        entry = {
            "ts": datetime.now(timezone.utc).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "msg": record.getMessage(),
        }
        if record.exc_info and record.exc_info[1]:
            entry["exception"] = self.formatException(record.exc_info)
        return json_dumps(entry, default=str)


def setup_logging(
    log_dir: Path | None = None,
    level: int = logging.WARNING,
    debug: bool = False,
    enable_file_logging: bool = True,
) -> None:
    """Configure logging for tuochat.

    Args:
        log_dir: Directory for log files. If None, logs to stderr only.
        level: Logging level for the root tuochat logger.
        debug: If True, set level to DEBUG regardless of level arg.
        enable_file_logging: If False, skip the file handler even when log_dir is set.
    """
    if debug:
        level = logging.DEBUG

    root = logging.getLogger("tuochat")
    root.setLevel(level)

    # Don't add handlers if already configured (e.g., in tests)
    if root.handlers:
        return

    redact_filter = TokenRedactFilter()

    # Console handler (stderr) — human-readable
    console = logging.StreamHandler()
    console.setLevel(level)
    console.setFormatter(logging.Formatter("%(levelname)s: %(message)s"))
    console.addFilter(redact_filter)
    root.addHandler(console)

    # File handler — JSON structured
    if log_dir and enable_file_logging:
        log_dir.mkdir(parents=True, exist_ok=True)
        log_file = log_dir / "tuochat.log"
        file_handler = logging.FileHandler(str(log_file), encoding="utf-8")
        file_handler.setLevel(logging.DEBUG)
        file_handler.setFormatter(JsonFormatter())
        file_handler.addFilter(redact_filter)
        root.addHandler(file_handler)

    # Suppress noisy loggers
    logging.getLogger("urllib3").setLevel(logging.WARNING)
