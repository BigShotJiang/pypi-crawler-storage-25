"""Minimal module entrypoint that verifies package integrity before importing CLI code."""

from __future__ import annotations

from tuochat.security.tamper import TamperError, verify_or_die


def main() -> int:
    """Run tamper verification and then dispatch to the real CLI."""
    try:
        verify_or_die("tuochat", allow_env_override=True)
    except TamperError as exc:
        print(str(exc), flush=True)
        return 2

    from tuochat.cli import main as cli_main

    return int(cli_main())


if __name__ == "__main__":
    raise SystemExit(main())
