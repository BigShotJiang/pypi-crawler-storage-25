"""Database introspection — discover tables, columns, types, and relationships."""

from __future__ import annotations

import asyncpg


async def introspect(conn_string: str) -> dict:
    """Connect to a PostgreSQL database and return full schema metadata."""
    conn = await asyncpg.connect(conn_string)
    try:
        # Get all tables with row counts
        tables_raw = await conn.fetch("""
            SELECT t.table_name,
                   COALESCE((SELECT reltuples::bigint FROM pg_class WHERE relname = t.table_name), 0) as row_count
            FROM information_schema.tables t
            WHERE t.table_schema = 'public' AND t.table_type = 'BASE TABLE'
            ORDER BY t.table_name
        """)

        tables = []
        for t in tables_raw:
            name = t["table_name"]

            # Get columns
            cols_raw = await conn.fetch("""
                SELECT column_name, data_type, is_nullable, column_default,
                       character_maximum_length, numeric_precision
                FROM information_schema.columns
                WHERE table_schema = 'public' AND table_name = $1
                ORDER BY ordinal_position
            """, name)

            columns = [
                {
                    "name": c["column_name"],
                    "type": c["data_type"],
                    "nullable": c["is_nullable"] == "YES",
                }
                for c in cols_raw
            ]

            tables.append({
                "name": name,
                "row_count": int(t["row_count"]),
                "columns": columns,
            })

        # Get foreign keys
        fks_raw = await conn.fetch("""
            SELECT
                tc.table_name as from_table,
                kcu.column_name as from_column,
                ccu.table_name as to_table,
                ccu.column_name as to_column
            FROM information_schema.table_constraints tc
            JOIN information_schema.key_column_usage kcu
                ON tc.constraint_name = kcu.constraint_name
            JOIN information_schema.constraint_column_usage ccu
                ON tc.constraint_name = ccu.constraint_name
            WHERE tc.constraint_type = 'FOREIGN KEY'
            AND tc.table_schema = 'public'
        """)

        foreign_keys = [
            {
                "from_table": fk["from_table"],
                "from_column": fk["from_column"],
                "to_table": fk["to_table"],
                "to_column": fk["to_column"],
            }
            for fk in fks_raw
        ]

        return {"tables": tables, "foreign_keys": foreign_keys}
    finally:
        await conn.close()


async def sample_rows(conn_string: str, table_name: str, limit: int = 5) -> dict:
    """Get sample rows from a table."""
    conn = await asyncpg.connect(conn_string)
    try:
        # Sanitize table name (prevent SQL injection)
        tables = await conn.fetch(
            "SELECT table_name FROM information_schema.tables WHERE table_schema = 'public' AND table_name = $1",
            table_name,
        )
        if not tables:
            return {"error": f"Table '{table_name}' not found"}

        rows = await conn.fetch(f'SELECT * FROM "{table_name}" LIMIT {int(limit)}')
        if not rows:
            return {"columns": [], "rows": []}

        columns = list(rows[0].keys())
        data = [dict(r) for r in rows]
        return {"columns": columns, "rows": data}
    finally:
        await conn.close()


async def column_stats(conn_string: str, table_name: str, column_name: str) -> dict:
    """Get cardinality and sample values for a column."""
    conn = await asyncpg.connect(conn_string)
    try:
        tables = await conn.fetch(
            "SELECT table_name FROM information_schema.tables WHERE table_schema = 'public' AND table_name = $1",
            table_name,
        )
        if not tables:
            return {"error": f"Table '{table_name}' not found"}

        distinct = await conn.fetchval(
            f'SELECT COUNT(DISTINCT "{column_name}") FROM "{table_name}"'
        )
        samples = await conn.fetch(
            f'SELECT DISTINCT "{column_name}" FROM "{table_name}" ORDER BY "{column_name}" LIMIT 20'
        )

        return {
            "distinct_count": distinct,
            "sample_values": [r[column_name] for r in samples],
        }
    finally:
        await conn.close()


def format_schema_markdown(schema: dict) -> str:
    """Format introspection result as readable Markdown."""
    lines = ["## Database Schema\n"]

    for table in schema["tables"]:
        lines.append(f"### `{table['name']}` ({table['row_count']:,} rows)")
        lines.append("| Column | Type | Nullable |")
        lines.append("|--------|------|----------|")
        for col in table["columns"]:
            nullable = "Yes" if col["nullable"] else "No"
            lines.append(f"| `{col['name']}` | {col['type']} | {nullable} |")
        lines.append("")

    if schema["foreign_keys"]:
        lines.append("### Relationships")
        for fk in schema["foreign_keys"]:
            lines.append(f"- `{fk['from_table']}.{fk['from_column']}` → `{fk['to_table']}.{fk['to_column']}`")
        lines.append("")

    return "\n".join(lines)


def format_sample_markdown(data: dict) -> str:
    """Format sample rows as a Markdown table."""
    if "error" in data:
        return f"**Error:** {data['error']}"

    columns = data["columns"]
    rows = data["rows"]

    if not rows:
        return "No data in this table."

    lines = [
        "| " + " | ".join(columns) + " |",
        "| " + " | ".join(["---"] * len(columns)) + " |",
    ]
    for row in rows:
        vals = [str(row.get(c, ""))[:40] for c in columns]
        lines.append("| " + " | ".join(vals) + " |")

    return "\n".join(lines)
