"""Auto-generate Lens YAML configs from database schema."""

from __future__ import annotations

import yaml


# Column types that suggest specific widget/filter types
NUMERIC_TYPES = {"smallint", "integer", "bigint", "real", "double precision", "numeric", "decimal"}
DATE_TYPES = {"date", "timestamp without time zone", "timestamp with time zone"}
TEXT_TYPES = {"character varying", "character", "text"}
BOOL_TYPES = {"boolean"}


def generate_config(
    schema: dict,
    title: str = "Dashboard",
    connection_string: str = "",
    tables: list[str] | None = None,
) -> str:
    """Generate a complete Lens YAML config from database schema.

    Uses heuristics to pick the best widgets and filters for each table.
    """
    all_tables = schema["tables"]
    fks = schema["foreign_keys"]

    if tables:
        all_tables = [t for t in all_tables if t["name"] in tables]

    if not all_tables:
        return "# No tables found to generate config from."

    # Build foreign key lookup
    fk_map: dict[str, list[dict]] = {}
    for fk in fks:
        fk_map.setdefault(fk["from_table"], []).append(fk)

    pages = []
    sidebar_pages = []

    for table in all_tables:
        page = _generate_page(table, fk_map.get(table["name"], []), all_tables)
        pages.append(page)
        sidebar_pages.append(table["name"])

    config = {
        "app": {
            "title": title,
            "theme": "system",
            "port": 8080,
            "debug": True,
            "database": {
                "connection": connection_string,
                "pool_size": 10,
                "query_timeout": 30,
            },
            "sidebar": {
                "title": title,
                "sections": [{"label": "Pages", "pages": sidebar_pages}],
            },
            "pages": pages,
        }
    }

    return yaml.dump(config, default_flow_style=False, sort_keys=False, allow_unicode=True)


def _generate_page(table: dict, fks: list[dict], all_tables: list[dict]) -> dict:
    """Generate a page config for a single table."""
    name = table["name"]
    columns = table["columns"]

    # Classify columns
    numeric_cols = [c for c in columns if c["type"] in NUMERIC_TYPES]
    date_cols = [c for c in columns if c["type"] in DATE_TYPES]
    text_cols = [c for c in columns if c["type"] in TEXT_TYPES]
    bool_cols = [c for c in columns if c["type"] in BOOL_TYPES]

    # Build filters
    filters = _generate_filters(name, text_cols, bool_cols)

    # Build rows
    rows = []

    # KPI row — from numeric columns
    if numeric_cols:
        kpi_items = []
        for col in numeric_cols[:4]:  # max 4 KPIs
            kpi_items.append({
                "type": "kpi",
                "title": _humanize(col["name"]),
                "query": f"SELECT SUM({col['name']})::numeric as current_value FROM {name}",
                "compact": True,
                "decimals": 0,
            })
        if kpi_items:
            rows.append({"height": "small", "items": kpi_items})

    # Chart row — time series if date column exists
    if date_cols and numeric_cols:
        date_col = date_cols[0]["name"]
        chart_items = []

        # Bar chart for first numeric column over time
        if len(numeric_cols) >= 1:
            num_col = numeric_cols[0]["name"]
            chart_items.append({
                "type": "chart",
                "chart_type": "bar",
                "title": f"{_humanize(num_col)} by Month",
                "query": (
                    f"SELECT TO_CHAR({date_col}, 'Mon YY') as month, "
                    f"SUM({num_col})::int as value "
                    f"FROM {name} "
                    f"GROUP BY TO_CHAR({date_col}, 'Mon YY'), DATE_TRUNC('month', {date_col}) "
                    f"ORDER BY DATE_TRUNC('month', {date_col})"
                ),
                "x": "month",
                "y": "value",
            })

        # Line chart for count over time
        chart_items.append({
            "type": "chart",
            "chart_type": "line",
            "title": f"{_humanize(name)} Count by Month",
            "query": (
                f"SELECT TO_CHAR({date_col}, 'Mon YY') as month, "
                f"COUNT(*) as count "
                f"FROM {name} "
                f"GROUP BY TO_CHAR({date_col}, 'Mon YY'), DATE_TRUNC('month', {date_col}) "
                f"ORDER BY DATE_TRUNC('month', {date_col})"
            ),
            "x": "month",
            "y": "count",
        })

        if chart_items:
            rows.append({"height": "medium", "items": chart_items})

    # Pie chart for low-cardinality text columns
    if text_cols:
        pie_items = []
        for col in text_cols[:2]:  # max 2 pie charts
            pie_items.append({
                "type": "chart",
                "chart_type": "pie",
                "title": f"By {_humanize(col['name'])}",
                "query": (
                    f"SELECT {col['name']}, COUNT(*) as count "
                    f"FROM {name} "
                    f"WHERE {col['name']} IS NOT NULL "
                    f"GROUP BY {col['name']} "
                    f"ORDER BY count DESC LIMIT 10"
                ),
                "x": col["name"],
                "y": "count",
            })
        if pie_items:
            rows.append({"height": "medium", "items": pie_items})

    # Data table — all columns
    table_columns = [{"id": c["name"], "label": _humanize(c["name"])} for c in columns[:10]]

    # Add formatting hints
    for tc in table_columns:
        col_info = next((c for c in columns if c["name"] == tc["id"]), None)
        if col_info and col_info["type"] in NUMERIC_TYPES:
            tc["format"] = "number"
        elif col_info and col_info["type"] in DATE_TYPES:
            tc["format"] = "date"

    col_names = ", ".join(c["name"] for c in columns[:10])
    rows.append({
        "height": "large",
        "items": [{
            "type": "table",
            "title": f"All {_humanize(name)}",
            "query": f"SELECT {col_names} FROM {name} ORDER BY 1 DESC LIMIT 200",
            "page_size": 25,
            "columns": table_columns,
        }],
    })

    page: dict = {
        "id": name,
        "name": _humanize(name),
        "icon": _pick_icon(name),
    }
    if filters:
        page["filters"] = filters
    page["rows"] = rows

    return page


def _generate_filters(table_name: str, text_cols: list[dict], bool_cols: list[dict]) -> list[dict]:
    """Generate filter configs for a table."""
    filters = []

    # Dropdown filters for text columns (max 3)
    for col in text_cols[:3]:
        filters.append({
            "id": col["name"],
            "type": "dropdown",
            "label": _humanize(col["name"]),
            "query": f"SELECT DISTINCT {col['name']} FROM {table_name} WHERE {col['name']} IS NOT NULL ORDER BY {col['name']}",
            "all": True,
            "default": "ALL",
        })

    # Toggle filters for boolean columns
    for col in bool_cols[:2]:
        filters.append({
            "id": col["name"],
            "type": "toggle",
            "label": _humanize(col["name"]),
            "default": False,
        })

    return filters


def _humanize(name: str) -> str:
    """Convert snake_case to Title Case."""
    return name.replace("_", " ").title()


def _pick_icon(table_name: str) -> str:
    """Pick a sensible icon based on table name."""
    icons = {
        "users": "users", "customers": "users", "employees": "briefcase",
        "orders": "shopping-cart", "sales": "bar-chart", "products": "package",
        "invoices": "file-text", "payments": "credit-card", "categories": "layers",
        "reviews": "book-open", "shipping": "truck",
    }
    lower = table_name.lower()
    for keyword, icon in icons.items():
        if keyword in lower:
            return icon
    return "layers"
