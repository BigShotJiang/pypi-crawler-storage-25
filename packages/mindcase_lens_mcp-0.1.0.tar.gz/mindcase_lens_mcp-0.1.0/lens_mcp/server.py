"""Lens MCP Server — build dashboards from PostgreSQL databases using Claude."""

import asyncio
import logging
import subprocess
import sys
from pathlib import Path

import yaml
from mcp.server.fastmcp import FastMCP

from lens_mcp.introspect import (
    introspect,
    sample_rows,
    format_schema_markdown,
    format_sample_markdown,
)
from lens_mcp.generator import generate_config

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("lens-mcp")

mcp = FastMCP(
    "lens",
    instructions=(
        "Lens is a YAML-driven analytics dashboarding library by Mindcase. "
        "It connects to PostgreSQL databases and renders beautiful dashboards from a YAML config. "
        "Use introspect_database to discover the database schema, generate_config to create a "
        "dashboard YAML, validate_config to check it, and serve_dashboard to start it. "
        "The user never needs to write YAML manually — you generate it for them."
    ),
)


# ── Database Introspection ──────────────────────────────────────────────────


@mcp.tool()
async def introspect_database(connection_string: str) -> str:
    """Discover all tables, columns, types, row counts, and foreign key relationships in a PostgreSQL database.

    Call this first to understand the database schema before generating a dashboard config.

    Args:
        connection_string: PostgreSQL connection string (e.g. postgresql://user:pass@localhost:5432/mydb)
    """
    try:
        schema = await introspect(connection_string)
        return format_schema_markdown(schema)
    except Exception as e:
        return f"**Error connecting to database:** {e}"


@mcp.tool()
async def sample_data(connection_string: str, table_name: str, limit: int = 5) -> str:
    """Get sample rows from a database table to understand the data shape and values.

    Args:
        connection_string: PostgreSQL connection string
        table_name: Name of the table to sample
        limit: Number of rows to return (default 5)
    """
    try:
        data = await sample_rows(connection_string, table_name, limit)
        return format_sample_markdown(data)
    except Exception as e:
        return f"**Error:** {e}"


# ── Config Generation ───────────────────────────────────────────────────────


@mcp.tool()
async def generate_dashboard(
    connection_string: str,
    title: str = "Dashboard",
    tables: str = "",
    output_path: str = "dashboard.yaml",
) -> str:
    """Auto-generate a complete Lens dashboard YAML config from a PostgreSQL database.

    Introspects the database schema and creates pages with KPIs, charts, tables, and filters
    based on column types. Writes the config to a file.

    Args:
        connection_string: PostgreSQL connection string
        title: Dashboard title
        tables: Comma-separated table names to include (empty = all tables)
        output_path: Where to write the YAML config file (default: dashboard.yaml)
    """
    try:
        schema = await introspect(connection_string)
        table_list = [t.strip() for t in tables.split(",") if t.strip()] or None

        yaml_content = generate_config(
            schema=schema,
            title=title,
            connection_string=connection_string,
            tables=table_list,
        )

        path = Path(output_path)
        path.write_text(yaml_content)

        # Count what was generated
        config = yaml.safe_load(yaml_content)
        page_count = len(config.get("app", {}).get("pages", []))

        return (
            f"Dashboard config generated and saved to `{path}`.\n\n"
            f"**{page_count} pages** created from the database schema.\n\n"
            f"To start the dashboard, run:\n```\nlens serve {path}\n```\n\n"
            f"Or use the `serve_dashboard` tool."
        )
    except Exception as e:
        return f"**Error generating config:** {e}"


# ── Config Validation ───────────────────────────────────────────────────────


@mcp.tool()
async def validate_config(config_path: str) -> str:
    """Validate a Lens YAML config file for correctness.

    Checks that the config has valid structure, all required fields, unique page IDs,
    and correct sidebar references.

    Args:
        config_path: Path to the YAML config file
    """
    try:
        # Import Lens config parser
        sys.path.insert(0, str(Path(__file__).parent))
        from _config_validator import validate
        return validate(config_path)
    except ImportError:
        # Fallback: try using the lens CLI
        try:
            result = subprocess.run(
                ["lens", "validate", config_path],
                capture_output=True, text=True, timeout=10,
            )
            if result.returncode == 0:
                return f"**Valid.** {result.stdout.strip()}"
            return f"**Invalid.** {result.stderr.strip()}"
        except FileNotFoundError:
            # No lens CLI available, do basic YAML validation
            path = Path(config_path)
            if not path.exists():
                return f"**Error:** File not found: {config_path}"
            try:
                with open(path) as f:
                    config = yaml.safe_load(f)
                if not config or "app" not in config:
                    return "**Invalid:** Config must have a top-level 'app' key."
                pages = config["app"].get("pages", [])
                if not pages:
                    return "**Invalid:** At least one page must be defined."
                page_ids = [p.get("id") for p in pages]
                if len(page_ids) != len(set(page_ids)):
                    return "**Invalid:** Page IDs must be unique."
                return f"**Valid (basic check).** {len(pages)} pages found."
            except Exception as e:
                return f"**Invalid YAML:** {e}"


# ── Dashboard Serving ───────────────────────────────────────────────────────


@mcp.tool()
async def serve_dashboard(config_path: str, port: int = 8080) -> str:
    """Start a Lens dashboard server from a YAML config file.

    The server runs in the background and serves the dashboard at the specified port.

    Args:
        config_path: Path to the Lens YAML config file
        port: Port to serve on (default 8080)
    """
    path = Path(config_path)
    if not path.exists():
        return f"**Error:** Config file not found: {config_path}"

    try:
        # Try using the lens CLI
        subprocess.Popen(
            ["lens", "serve", str(path), "--port", str(port), "--no-browser"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        return (
            f"Dashboard starting at **http://localhost:{port}**\n\n"
            f"Config: `{path}`"
        )
    except FileNotFoundError:
        # Fallback: use python -c
        subprocess.Popen(
            [
                sys.executable, "-c",
                f"from lens import Lens; Lens('{path}').serve(port={port}, open_browser=False)",
            ],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        return (
            f"Dashboard starting at **http://localhost:{port}**\n\n"
            f"Config: `{path}`"
        )


# ── Config Modification ─────────────────────────────────────────────────────


@mcp.tool()
async def add_page(
    config_path: str,
    page_name: str,
    table_name: str,
    connection_string: str,
) -> str:
    """Add a new page to an existing Lens dashboard config, based on a database table.

    Introspects the table and generates KPIs, charts, and a data table automatically.

    Args:
        config_path: Path to the existing YAML config file
        page_name: Name for the new page
        table_name: Database table to build the page from
        connection_string: PostgreSQL connection string
    """
    path = Path(config_path)
    if not path.exists():
        return f"**Error:** Config file not found: {config_path}"

    try:
        schema = await introspect(connection_string)
        table_info = next((t for t in schema["tables"] if t["name"] == table_name), None)
        if not table_info:
            return f"**Error:** Table '{table_name}' not found in the database."

        # Generate page config
        from lens_mcp.generator import _generate_page
        fks = [fk for fk in schema["foreign_keys"] if fk["from_table"] == table_name]
        page = _generate_page(table_info, fks, schema["tables"])
        page["name"] = page_name

        # Load existing config and append
        with open(path) as f:
            config = yaml.safe_load(f)

        config["app"]["pages"].append(page)

        # Update sidebar if it exists
        sidebar = config["app"].get("sidebar", {})
        if sidebar and sidebar.get("sections"):
            sidebar["sections"][-1]["pages"].append(page["id"])

        with open(path, "w") as f:
            yaml.dump(config, f, default_flow_style=False, sort_keys=False, allow_unicode=True)

        return f"**Added page '{page_name}'** (from table `{table_name}`) to `{path}`."
    except Exception as e:
        return f"**Error:** {e}"


@mcp.tool()
async def add_filter(
    config_path: str,
    page_id: str,
    filter_id: str,
    filter_type: str = "dropdown",
    label: str = "",
    query: str = "",
) -> str:
    """Add a filter to a page in an existing Lens dashboard config.

    Args:
        config_path: Path to the YAML config file
        page_id: ID of the page to add the filter to
        filter_id: Unique filter ID (used as SQL parameter name)
        filter_type: Filter type — dropdown, daterange, date, text, number_range, toggle
        label: Display label for the filter
        query: SQL query for dropdown options (e.g. "SELECT DISTINCT region FROM sales")
    """
    path = Path(config_path)
    if not path.exists():
        return f"**Error:** Config file not found: {config_path}"

    try:
        with open(path) as f:
            config = yaml.safe_load(f)

        page = next((p for p in config["app"]["pages"] if p["id"] == page_id), None)
        if not page:
            return f"**Error:** Page '{page_id}' not found."

        filter_def: dict = {
            "id": filter_id,
            "type": filter_type,
            "label": label or filter_id.replace("_", " ").title(),
        }

        if filter_type == "dropdown":
            filter_def["all"] = True
            filter_def["default"] = "ALL"
            if query:
                filter_def["query"] = query
        elif filter_type == "toggle":
            filter_def["default"] = False

        if "filters" not in page:
            page["filters"] = []
        page["filters"].append(filter_def)

        with open(path, "w") as f:
            yaml.dump(config, f, default_flow_style=False, sort_keys=False, allow_unicode=True)

        return f"**Added {filter_type} filter '{filter_id}'** to page `{page_id}`."
    except Exception as e:
        return f"**Error:** {e}"


if __name__ == "__main__":
    mcp.run()
