"""Lens MCP Server — build dashboards from PostgreSQL databases using Claude."""
