# Lens MCP Server

[![PyPI version](https://img.shields.io/pypi/v/mindcase-lens-mcp.svg)](https://pypi.org/project/mindcase-lens-mcp/)
[![License: MIT](https://img.shields.io/badge/License-MIT-black.svg)](https://opensource.org/licenses/MIT)

MCP server for [Lens](https://github.com/mindcase-co/lens) — build PostgreSQL dashboards from Claude using natural language. Built by [Mindcase](https://mindcase.co).

## What it does

Tell Claude to build you a dashboard. It will:

1. **Introspect your database** — discover tables, columns, types, relationships
2. **Generate a dashboard config** — KPIs, charts, tables, and filters auto-picked from your schema
3. **Serve it** — start the dashboard and give you a URL

No YAML knowledge required. No frontend code. Just describe what you want.

## Quick Start

### Claude Code

```bash
# Install Lens (the dashboard engine)
pip install mindcase-lens

# Add the MCP server
claude mcp add lens -- uvx mindcase-lens-mcp
```

Then tell Claude:

> "Connect to my database at postgresql://user:pass@localhost:5432/mydb and build me a dashboard"

### Claude Desktop

Add to `~/Library/Application Support/Claude/claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "lens": {
      "command": "uvx",
      "args": ["mindcase-lens-mcp"]
    }
  }
}
```

## Available Tools

| Tool | Description |
|------|-------------|
| `introspect_database` | Discover all tables, columns, types, row counts, and relationships |
| `sample_data` | Get sample rows from a table to understand the data |
| `generate_dashboard` | Auto-generate a complete Lens YAML config from database schema |
| `validate_config` | Validate a Lens YAML config file |
| `serve_dashboard` | Start serving a dashboard from a config file |
| `add_page` | Add a new page to an existing dashboard (from a database table) |
| `add_filter` | Add a filter to a page in an existing dashboard |

## Example Prompts

- "Show me what tables are in my database"
- "Build a dashboard for my sales and customers tables"
- "Add a page for the orders table"
- "Add a country filter to the sales page"
- "Start the dashboard on port 3000"

## Requirements

- Python 3.10+
- PostgreSQL database
- [mindcase-lens](https://pypi.org/project/mindcase-lens/) installed for serving dashboards

## License

MIT
