from pathlib import Path

from peridot import FileEntry, detect_sensitive_entries


def _entry(source_name: str, relative_path: str) -> FileEntry:
    return FileEntry(source=Path(source_name), relative_path=relative_path, size=1, mode=0o644)


def test_detect_sensitive_entries_flags_common_secret_files() -> None:
    entries = [
        _entry(".env", ".env"),
        _entry(".npmrc", ".npmrc"),
        _entry("id_rsa", ".ssh/id_rsa"),
        _entry("id_ed25519", ".ssh/id_ed25519"),
        _entry("id_dsa", ".ssh/id_dsa"),
        _entry("known_hosts", ".ssh/known_hosts"),
        _entry("authorized_keys", ".ssh/authorized_keys"),
        _entry("config", ".ssh/config"),
        _entry("config", ".ssh\\config"),
        _entry("work", ".ssh/config.d/work"),
        _entry("work", ".ssh\\config.d\\work"),
        _entry("config", ".aws/config"),
        _entry("credentials", ".aws/credentials"),
        _entry(".git-credentials", ".git-credentials"),
        _entry("config.json", ".docker/config.json"),
        _entry("my_token.txt", "secrets/my_token.txt"),
        _entry("config.json", "token/config.json"),
        _entry("creds", "credentials.json"),
    ]

    sensitive = detect_sensitive_entries(entries)
    assert {e.relative_path for e in sensitive} == {e.relative_path for e in entries}


def test_detect_sensitive_entries_avoids_token_substring_false_positive() -> None:
    entries = [
        _entry("stockton.txt", "notes/stockton.txt"),
        _entry("mytoken.txt", "notes/mytoken.txt"),
        _entry("tokenize.py", "src/tokenize.py"),
    ]

    sensitive = detect_sensitive_entries(entries)
    assert sensitive == []


def test_detect_sensitive_entries_does_not_flag_generic_config_files() -> None:
    entries = [
        _entry("config", "app/config"),
        _entry("config", "config"),
        _entry("config.yaml", "config.yaml"),
        _entry("config.json", "app/config.json"),
    ]

    sensitive = detect_sensitive_entries(entries)
    assert sensitive == []


def test_detect_sensitive_entries_does_not_flag_public_ssh_keys() -> None:
    entries = [
        _entry("id_ed25519.pub", ".ssh/id_ed25519.pub"),
        _entry("id_rsa.pub", ".ssh/id_rsa.pub"),
    ]

    sensitive = detect_sensitive_entries(entries)
    assert sensitive == []
