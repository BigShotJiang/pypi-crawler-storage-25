# Fixture Claude Entrypoint

This fixture models a repository that uses only `CLAUDE.md` as its agent entry.

## Fitness

- Entrix rules live in `docs/fitness/`
- Do not create an extra `AGENTS.md`
- Keep default local `python3 -m entrix run` green
