"""CToon – Compact TOON serialisation (C++ nanobind backend)"""

import enum


class ReadFlag(enum.Flag):
    NOFLAG = 0

    INSITU = 1

    STOP_WHEN_DONE = 2

    ALLOW_TRAILING_COMMAS = 4

    ALLOW_COMMENTS = 8

    ALLOW_INF_AND_NAN = 16

    NUMBER_AS_RAW = 32

    ALLOW_INVALID_UNICODE = 64

    BIGNUM_AS_RAW = 128

    ALLOW_BOM = 256

    ALLOW_EXT_NUMBER = 512

    ALLOW_EXT_ESCAPE = 1024

    ALLOW_EXT_WHITESPACE = 2048

    ALLOW_SINGLE_QUOTED_STR = 4096

    ALLOW_UNQUOTED_KEY = 8192

    def __or__(self, arg: object, /) -> object: ...

    def __ror__(self, arg: object, /) -> object: ...

    def __int__(self) -> int: ...

NOFLAG: WriteFlag = WriteFlag.NOFLAG

INSITU: ReadFlag = ReadFlag.INSITU

STOP_WHEN_DONE: ReadFlag = ReadFlag.STOP_WHEN_DONE

ALLOW_TRAILING_COMMAS: ReadFlag = ReadFlag.ALLOW_TRAILING_COMMAS

ALLOW_COMMENTS: ReadFlag = ReadFlag.ALLOW_COMMENTS

ALLOW_INF_AND_NAN: WriteFlag = WriteFlag.ALLOW_INF_AND_NAN

NUMBER_AS_RAW: ReadFlag = ReadFlag.NUMBER_AS_RAW

ALLOW_INVALID_UNICODE: WriteFlag = WriteFlag.ALLOW_INVALID_UNICODE

BIGNUM_AS_RAW: ReadFlag = ReadFlag.BIGNUM_AS_RAW

ALLOW_BOM: ReadFlag = ReadFlag.ALLOW_BOM

ALLOW_EXT_NUMBER: ReadFlag = ReadFlag.ALLOW_EXT_NUMBER

ALLOW_EXT_ESCAPE: ReadFlag = ReadFlag.ALLOW_EXT_ESCAPE

ALLOW_EXT_WHITESPACE: ReadFlag = ReadFlag.ALLOW_EXT_WHITESPACE

ALLOW_SINGLE_QUOTED_STR: ReadFlag = ReadFlag.ALLOW_SINGLE_QUOTED_STR

ALLOW_UNQUOTED_KEY: ReadFlag = ReadFlag.ALLOW_UNQUOTED_KEY

class WriteFlag(enum.Flag):
    NOFLAG = 0

    ESCAPE_UNICODE = 2

    ESCAPE_SLASHES = 4

    ALLOW_INF_AND_NAN = 8

    INF_AND_NAN_AS_NULL = 16

    ALLOW_INVALID_UNICODE = 32

    LENGTH_MARKER = 64

    NEWLINE_AT_END = 128

    def __or__(self, arg: object, /) -> object: ...

    def __ror__(self, arg: object, /) -> object: ...

    def __int__(self) -> int: ...

ESCAPE_UNICODE: WriteFlag = WriteFlag.ESCAPE_UNICODE

ESCAPE_SLASHES: WriteFlag = WriteFlag.ESCAPE_SLASHES

INF_AND_NAN_AS_NULL: WriteFlag = WriteFlag.INF_AND_NAN_AS_NULL

LENGTH_MARKER: WriteFlag = WriteFlag.LENGTH_MARKER

NEWLINE_AT_END: WriteFlag = WriteFlag.NEWLINE_AT_END

class Delimiter(enum.Enum):
    COMMA = 0

    TAB = 1

    PIPE = 2

COMMA: Delimiter = Delimiter.COMMA

TAB: Delimiter = Delimiter.TAB

PIPE: Delimiter = Delimiter.PIPE

def loads(s: object, flags: ReadFlag = ReadFlag.NOFLAG) -> object:
    """
    Parse a TOON string or bytes object. Returns a Python object.

        loads(s, flags=ReadFlag.NOFLAG) -> object
    """

def load(fp: object, flags: ReadFlag = ReadFlag.NOFLAG) -> object:
    """
    Load TOON from a file path (str) or a file-like object with .read().

        load(fp, flags=ReadFlag.NOFLAG) -> object

        with open('data.toon') as f:
            obj = ctoon.load(f)
        obj = ctoon.load('data.toon')
    """

def dumps(obj: object, indent: int = 2, delimiter: Delimiter = Delimiter.COMMA, flags: WriteFlag = WriteFlag.NOFLAG) -> str:
    """
    Serialize a Python object to a TOON string.

        dumps(obj, indent=2, delimiter=Delimiter.COMMA,
              flags=WriteFlag.NOFLAG) -> str
    """

def dump(obj: object, fp: object, indent: int = 2, delimiter: Delimiter = Delimiter.COMMA, flags: WriteFlag = WriteFlag.NOFLAG) -> None:
    """
    Serialize a Python object to a TOON file path or file-like object.

        dump(obj, fp, indent=2, delimiter=Delimiter.COMMA,
             flags=WriteFlag.NOFLAG)

        with open('out.toon', 'w') as f:
            ctoon.dump(data, f)
        ctoon.dump(data, 'out.toon')
    """

def loads_json(s: object, flags: ReadFlag = ReadFlag.NOFLAG) -> object:
    """
    Parse a JSON string or bytes object.

        loads_json(s, flags=ReadFlag.NOFLAG) -> object
    """

def load_json(fp: object, flags: ReadFlag = ReadFlag.NOFLAG) -> object:
    """
    Load JSON from a file path (str) or a file-like object with .read().

        load_json(fp, flags=ReadFlag.NOFLAG) -> object

        with open('data.json') as f:
            obj = ctoon.load_json(f)
    """

def dumps_json(obj: object, indent: int = 2, flags: WriteFlag = WriteFlag.NOFLAG) -> str:
    """
    Serialize a Python object to a JSON string.

        dumps_json(obj, indent=2, flags=WriteFlag.NOFLAG) -> str
    """

def dump_json(obj: object, fp: object, indent: int = 2, flags: WriteFlag = WriteFlag.NOFLAG) -> None:
    """
    Serialize a Python object to a JSON file path or file-like object.

        dump_json(obj, fp, indent=2, flags=WriteFlag.NOFLAG)

        with open('out.json', 'w') as f:
            ctoon.dump_json(data, f)
        ctoon.dump_json(data, 'out.json')
    """

encode = dumps

decode = loads
