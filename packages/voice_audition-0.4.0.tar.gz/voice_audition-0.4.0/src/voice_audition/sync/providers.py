import json
import os
import sys
import traceback
from datetime import datetime, timezone
from pathlib import Path

import httpx

from voice_audition.schema import make_voice

CATALOG_DIR = Path(__file__).parent.parent.parent.parent / "catalog"


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def write_catalog(provider: str, voices: list[dict]):
    CATALOG_DIR.mkdir(parents=True, exist_ok=True)
    path = CATALOG_DIR / f"{provider}.json"
    path.write_text(json.dumps(voices, indent=2, ensure_ascii=False))


def load_existing(provider: str) -> list[dict]:
    path = CATALOG_DIR / f"{provider}.json"
    if not path.exists():
        return []
    try:
        return json.loads(path.read_text())
    except (json.JSONDecodeError, OSError):
        return []


def map_gender(g: str | None) -> str:
    if not g:
        return "unknown"
    g = g.lower().strip()
    if g in ("male", "female", "neutral"):
        return g
    if g in ("masculine",):
        return "male"
    if g in ("feminine",):
        return "female"
    if g in ("gender_neutral",):
        return "neutral"
    return "unknown"


def map_age(a: str | None) -> str:
    if not a:
        return "unknown"
    a = a.lower().strip()
    if a in ("young", "young_adult", "youth"):
        return "young"
    if a in ("middle", "middle_aged", "middle aged", "middle-aged", "adult"):
        return "middle"
    if a in ("old", "senior", "mature"):
        return "mature"
    return "unknown"


_ENRICHMENT_KEYS = (
    "description", "gender", "age_group", "accent", "traits",
    "texture", "pitch", "speaking_style", "personality_tags",
    "style_tags", "use_cases", "enrichment", "metadata_source",
)

_ENRICHED_SOURCES = ("enriched_local", "enriched_cloud", "manual", "hybrid")

_PROVIDER_FIELDS = ("name", "provider_model", "preview_url", "provider_page_url", "provider_metadata")


def _provider_fields_changed(old: dict, new: dict) -> bool:
    for key in _PROVIDER_FIELDS:
        if old.get(key) != new.get(key):
            return True
    return False


def diff_sync(provider: str, new_voices: list[dict]) -> dict:
    existing = load_existing(provider)
    existing_by_id = {v["id"]: v for v in existing}
    new_by_id = {v["id"]: v for v in new_voices}

    now = _now()
    added = []
    removed = []
    updated = []
    unchanged = []

    for vid, voice in new_by_id.items():
        if vid not in existing_by_id:
            voice["first_seen"] = now
            voice["last_seen"] = now
            added.append(voice)
        else:
            old = existing_by_id[vid]
            voice["first_seen"] = old.get("first_seen", now)
            voice["last_seen"] = now
            if old.get("metadata_source") in _ENRICHED_SOURCES:
                for key in _ENRICHMENT_KEYS:
                    if key in old and old[key]:
                        voice[key] = old[key]
            if _provider_fields_changed(old, voice):
                updated.append(voice)
            else:
                voice["last_synced"] = now
                unchanged.append(voice)

    for vid, old in existing_by_id.items():
        if vid not in new_by_id:
            old["status"] = "deprecated"
            old["deprecated_at"] = now
            old["last_seen"] = old.get("last_seen", now)
            removed.append(old)

    return {"added": added, "removed": removed, "updated": updated, "unchanged": unchanged}


def apply_sync(provider: str, new_voices: list[dict]) -> dict:
    result = diff_sync(provider, new_voices)

    all_voices = result["added"] + result["updated"] + result["unchanged"] + result["removed"]
    write_catalog(provider, all_voices)

    total = len(all_voices)
    print(f"[{provider}] Sync results:")
    print(f"  Added:     {len(result['added'])} new voices")
    print(f"  Updated:   {len(result['updated'])} changed")
    print(f"  Removed:   {len(result['removed'])} deprecated")
    print(f"  Unchanged: {len(result['unchanged'])}")
    print(f"  Total:     {total}")

    return result


def sync_elevenlabs() -> list[dict]:
    api_key = os.environ.get("ELEVENLABS_API_KEY", "")
    if not api_key:
        print("[elevenlabs] WARNING: No ELEVENLABS_API_KEY. Skipping.")
        return []

    headers = {"xi-api-key": api_key}
    voices = []
    cursor = None
    page = 0

    with httpx.Client(timeout=30, headers=headers) as client:
        while True:
            params = {"page_size": 100}
            if cursor:
                params["last_sort_id"] = cursor

            resp = client.get("https://api.elevenlabs.io/v1/shared-voices", params=params)
            resp.raise_for_status()
            data = resp.json()

            batch = data.get("voices", [])
            if not batch:
                break

            for v in batch:
                vid = v.get("voice_id", "")
                name_ = v.get("name", "").strip()
                if not vid or not name_:
                    continue

                accent_ = v.get("accent", "")
                descriptive = v.get("descriptive", "")
                use_case = v.get("use_case", "")

                style_tags = [t.strip().lower() for t in descriptive.split(",") if t.strip()] if descriptive else []
                use_cases = [u.strip().lower().replace(" ", "_") for u in use_case.split(",") if u.strip()] if use_case else []

                usage_1y = v.get("usage_character_count_1y", 0) or 0
                cloned = v.get("cloned_by_count", 0) or 0

                voices.append(make_voice(
                    provider="elevenlabs",
                    provider_voice_id=vid,
                    name=name_,
                    provider_model="eleven_turbo_v2_5",
                    description=f"{name_}. {descriptive}. {use_case}." if descriptive else name_,
                    gender=map_gender(v.get("gender")),
                    age_group=map_age(v.get("age")),
                    accent=accent_.lower() if accent_ else None,
                    language=v.get("language", "en"),
                    additional_languages=[l.get("language", "") for l in v.get("verified_languages", []) if l.get("language")],
                    style_tags=style_tags,
                    use_cases=use_cases,
                    preview_url=v.get("preview_url"),
                    provider_page_url="https://elevenlabs.io/voice-library",
                    provider_metadata={
                        "category": v.get("category"),
                        "cloned_by_count": cloned,
                        "usage_character_count_1y": usage_1y,
                        "free_users_allowed": v.get("free_users_allowed"),
                        "featured": v.get("featured"),
                    },
                ))

            cursor = data.get("last_sort_id")
            page += 1
            print(f"[elevenlabs] Page {page}: {len(batch)} voices (total: {len(voices)})")

            if not data.get("has_more", True) or not cursor:
                break

    return voices


RIME_LANG_MAP = {
    "eng": "en", "spa": "es", "fra": "fr", "ger": "de",
    "hin": "hi", "ara": "ar", "heb": "he", "jpn": "ja", "por": "pt",
}


def sync_rime() -> list[dict]:
    resp = httpx.get("https://users.rime.ai/data/voices/all-v2.json", timeout=30)
    resp.raise_for_status()
    data = resp.json()

    voices = []
    for model_family, languages in data.items():
        if not isinstance(languages, dict):
            continue
        for lang_code, names in languages.items():
            if not isinstance(names, list):
                continue
            iso = RIME_LANG_MAP.get(lang_code, lang_code)
            for n in names:
                if not isinstance(n, str) or not n.strip():
                    continue
                voices.append(make_voice(
                    provider="rime",
                    provider_voice_id=f"{model_family}:{n}",
                    name=n.replace("_", " ").title(),
                    provider_model=model_family,
                    language=iso,
                    provider_page_url="https://rime.ai",
                    provider_metadata={"model_family": model_family, "original_lang_code": lang_code},
                ))

    return voices


DEEPGRAM_VOICES = [
    ("Thalia", "aura-2-thalia-en", "female", "middle", "american"),
    ("Andromeda", "aura-2-andromeda-en", "female", "young", "american"),
    ("Arcas", "aura-2-arcas-en", "male", "young", "american"),
    ("Asteria", "aura-2-asteria-en", "female", "middle", "american"),
    ("Athena", "aura-2-athena-en", "female", "middle", "british"),
    ("Atlas", "aura-2-atlas-en", "male", "middle", "american"),
    ("Helios", "aura-2-helios-en", "male", "middle", "british"),
    ("Hera", "aura-2-hera-en", "female", "mature", "american"),
    ("Luna", "aura-2-luna-en", "female", "young", "american"),
    ("Orion", "aura-2-orion-en", "male", "middle", "american"),
    ("Perseus", "aura-2-perseus-en", "male", "young", "american"),
    ("Stella", "aura-2-stella-en", "female", "young", "american"),
    ("Zeus", "aura-2-zeus-en", "male", "mature", "american"),
    ("Angus", "aura-2-angus-en", "male", "middle", "irish"),
    ("Apollo", "aura-2-apollo-en", "male", "middle", "american"),
    ("Cora", "aura-2-cora-en", "female", "middle", "american"),
    ("Daphne", "aura-2-daphne-en", "female", "young", "british"),
    ("Echo", "aura-2-echo-en", "male", "young", "american"),
    ("Electra", "aura-2-electra-en", "female", "young", "american"),
    ("Harmony", "aura-2-harmony-en", "female", "middle", "australian"),
    ("Helena", "aura-2-helena-en", "female", "middle", "american"),
    ("Hercules", "aura-2-hercules-en", "male", "mature", "american"),
    ("Hermes", "aura-2-hermes-en", "male", "young", "american"),
    ("Iris", "aura-2-iris-en", "female", "young", "american"),
    ("Jason", "aura-2-jason-en", "male", "middle", "american"),
    ("Juno", "aura-2-juno-en", "female", "middle", "american"),
    ("Leda", "aura-2-leda-en", "female", "young", "american"),
    ("Lyra", "aura-2-lyra-en", "female", "young", "american"),
    ("Minerva", "aura-2-minerva-en", "female", "mature", "american"),
    ("Neptune", "aura-2-neptune-en", "male", "mature", "british"),
    ("Odysseus", "aura-2-odysseus-en", "male", "middle", "american"),
    ("Ophelia", "aura-2-ophelia-en", "female", "young", "american"),
    ("Orpheus", "aura-2-orpheus-en", "male", "young", "american"),
    ("Pandora", "aura-2-pandora-en", "female", "middle", "american"),
    ("Phoenix", "aura-2-phoenix-en", "male", "young", "american"),
    ("Poseidon", "aura-2-poseidon-en", "male", "mature", "american"),
    ("Selene", "aura-2-selene-en", "female", "middle", "american"),
    ("Titan", "aura-2-titan-en", "male", "middle", "american"),
    ("Triton", "aura-2-triton-en", "male", "young", "american"),
    ("Vesta", "aura-2-vesta-en", "female", "middle", "american"),
]


def sync_deepgram() -> list[dict]:
    voices = []
    for name_, vid, gender_, age_, accent_ in DEEPGRAM_VOICES:
        model = "aura-2" if vid.startswith("aura-2") else "aura-1"
        voices.append(make_voice(
            provider="deepgram", provider_voice_id=vid, name=name_,
            provider_model=model, gender=gender_, age_group=age_, accent=accent_,
            language="en", provider_page_url="https://deepgram.com/product/text-to-speech",
            metadata_source="manual",
        ))
    return voices


OPENAI_VOICES = [
    ("Alloy", "alloy", "neutral", "middle", "american", "Neutral, versatile. Safe default for diverse audiences."),
    ("Ash", "ash", "male", "young", "american", "Soft-spoken, thoughtful. Calm and measured."),
    ("Ballad", "ballad", "male", "middle", "american", "Warm, melodic with gentle delivery."),
    ("Cedar", "cedar", "male", "middle", "american", "Grounded, steady. Reliable and clear."),
    ("Coral", "coral", "female", "young", "american", "Bright, warm. Friendly and engaging."),
    ("Echo", "echo", "male", "middle", "american", "Balanced. Reliable for long sessions."),
    ("Fable", "fable", "male", "middle", "british", "Expressive, storytelling with British accent."),
    ("Marin", "marin", "female", "young", "american", "Clear, youthful. Professional and articulate."),
    ("Nova", "nova", "female", "young", "american", "Bright and engaging. Great for consumer apps."),
    ("Onyx", "onyx", "male", "mature", "american", "Deep, commanding. Premium executive feel."),
    ("Sage", "sage", "female", "middle", "american", "Wise, calm. Measured and thoughtful."),
    ("Shimmer", "shimmer", "female", "middle", "american", "Warm, soothing. Care and wellness."),
    ("Verse", "verse", "male", "young", "american", "Dynamic, expressive. Good range and energy."),
]


def sync_openai() -> list[dict]:
    voices = []
    for name_, vid, gender_, age_, accent_, desc in OPENAI_VOICES:
        voices.append(make_voice(
            provider="openai", provider_voice_id=vid, name=name_,
            provider_model="gpt-4o-mini-tts", description=desc,
            gender=gender_, age_group=age_, accent=accent_, language="en",
            metadata_source="manual",
            provider_metadata={"supports_instructions": True},
        ))
    return voices


def sync_cartesia() -> list[dict]:
    api_key = os.environ.get("CARTESIA_API_KEY", "")
    if not api_key:
        print("[cartesia] WARNING: No CARTESIA_API_KEY. Skipping.")
        return []

    headers = {
        "X-API-Key": api_key,
        "Cartesia-Version": "2024-06-10",
    }

    resp = httpx.get("https://api.cartesia.ai/voices", headers=headers, timeout=30)
    resp.raise_for_status()
    data = resp.json()

    voices = []
    for v in data:
        vid = v.get("id", "")
        name_ = v.get("name", "").strip()
        if not vid or not name_:
            continue

        lang = v.get("language", "en")
        if isinstance(lang, list):
            lang = lang[0] if lang else "en"

        voices.append(make_voice(
            provider="cartesia",
            provider_voice_id=vid,
            name=name_,
            description=v.get("description"),
            language=lang,
            provider_page_url="https://play.cartesia.ai",
            provider_metadata={
                "is_public": v.get("is_public"),
            },
        ))

    print(f"[cartesia] Fetched {len(voices)} voices from API")
    return voices


def sync_playht() -> list[dict]:
    api_key = os.environ.get("PLAYHT_API_KEY", "")
    user_id = os.environ.get("PLAYHT_USER_ID", "")
    if not api_key or not user_id:
        print("[playht] WARNING: No PLAYHT_API_KEY or PLAYHT_USER_ID. Skipping.")
        return []

    headers = {
        "Authorization": f"Bearer {api_key}",
        "X-User-ID": user_id,
    }

    resp = httpx.get("https://api.play.ht/api/v2/voices", headers=headers, timeout=30)
    resp.raise_for_status()
    data = resp.json()

    voices = []
    for v in data:
        vid = v.get("id", "")
        name_ = v.get("name", "").strip()
        if not vid or not name_:
            continue

        lang = v.get("language_code", "en")
        if lang and "-" in lang:
            lang = lang.split("-")[0]

        voices.append(make_voice(
            provider="playht",
            provider_voice_id=vid,
            name=name_,
            gender=map_gender(v.get("gender")),
            age_group=map_age(v.get("age")),
            accent=v.get("accent"),
            language=lang or "en",
            texture=v.get("texture"),
            preview_url=v.get("sample"),
            provider_page_url="https://play.ht/voice-library",
            provider_metadata={
                "loudness": v.get("loudness"),
                "style": v.get("style"),
                "tempo": v.get("tempo"),
            },
        ))

    print(f"[playht] Fetched {len(voices)} voices from API")
    return voices


PROVIDERS = {
    "elevenlabs": sync_elevenlabs,
    "rime": sync_rime,
    "deepgram": sync_deepgram,
    "openai": sync_openai,
    "cartesia": sync_cartesia,
    "playht": sync_playht,
}


def run_sync(providers: list[str] | None = None):
    targets = providers or list(PROVIDERS.keys())

    results = {}
    for name in targets:
        fn = PROVIDERS.get(name)
        if not fn:
            print(f"Unknown provider: {name}")
            results[name] = "unknown"
            continue
        try:
            print(f"\n{'='*50}\nSyncing {name}\n{'='*50}")
            new_voices = fn()
            if new_voices:
                apply_sync(name, new_voices)
                results[name] = "ok"
            else:
                print(f"[{name}] No voices returned (missing API key or empty response)")
                results[name] = "skipped"
        except Exception as e:
            print(f"[{name}] FAILED: {e}")
            traceback.print_exc()
            results[name] = f"failed: {e}"

    print(f"\n{'='*50}\nResults:")
    for name, status in results.items():
        print(f"  {name}: {status}")

    if any("failed" in str(v) for v in results.values()):
        sys.exit(1)


def main():
    args = sys.argv[1:]

    if "--list" in args:
        print("Available providers:", ", ".join(PROVIDERS.keys()))
        return

    targets = [a for a in args if not a.startswith("-")] or None
    run_sync(targets)


if __name__ == "__main__":
    main()
