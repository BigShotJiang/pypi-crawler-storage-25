"""Manage objectives."""
