"""Manage worktree pool slots."""
