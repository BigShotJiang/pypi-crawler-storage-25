# Skills

A skill is a set of local instructions to follow that is stored in a `SKILL.md` file. Below is the list of skills that can be used. Each entry includes a name, description, and file path so you can open the source for full instructions when using a specific skill.

### Package Import Rules

- Packages in this repo do **not** publicly re-export symbols from `__init__.py`. Package `__init__.py` files should be empty or contain only a docstring.
- Consumers must import from the canonical source module (e.g., `from twerk_core.clinkr.group import ClinkrGroup`, not `from twerk_core.clinkr import ClinkrGroup`).
- Do not use `__all__` or `import X as X` re-export patterns in `__init__.py` files.
- Do not prefix module filenames with a leading underscore (e.g., `_gateway_access.py`). Because `__init__.py` files are empty, every module's canonical path is already its public path — there is nothing to mark "package-private." `__init__.py` itself is exempt; the rule is about regular `.py` modules.

### Fixing Lint and Format Failures

When `just` reports a lint or format failure, do not hand-edit files to satisfy the formatter. Run the corresponding autofix recipe instead:

- `ruff check` failures → `just fix` (runs `ruff check --fix --unsafe-fixes` then `ruff format`)
- `ruff format --check` failures → `just fix`
- `dprint check` failures (Markdown / TOML) → `just dprint-fix` (runs `dprint fmt`)

After autofixing, re-run `just` to confirm the suite is green. Only edit files by hand when the failure is a real lint/type/test bug that the autofixer cannot resolve.

### Public Skill Authoring — No Internal References

Public skills (those with a `skills/<name>` symlink for external discoverability) are user-facing documents. Do not reference twerk-internal module paths, class names, or implementation details (e.g., `twerk_core.gh.IssueGateway`, `RealIssueGateway.get_reviews`) in their `SKILL.md` files or frontmatter descriptions. Describe _what_ CLI operations to call (e.g., `pr-address exec get-reviews`), not _how_ they are implemented. Implementation details belong in Python source, not in public `SKILL.md` files. Internal skills (no `skills/` symlink) may reference internals freely.

### Vendored Skill Code

- `.agents/skills/<name>/` is either (a) a symlink back to a first-party skill at `skills/<name>/` or (b) a real directory containing vendored third-party code. Treat only real directories there as vendored; symlinked entries resolve to first-party twerk work under `skills/<name>/` and are subject to normal linting, typechecking, and review.
- Treat `.claude/skills/*` as symlinks into `.agents/skills/`; the vendored-vs-first-party distinction follows through the chain to the underlying directory.
- For repo-local skills, `skills/<name>/` is the canonical source — edit files there directly. `.agents/skills/<name>` is a symlink back to that source, and editing through either path is equivalent.
- Do not apply first-party Python standards or refactoring skills such as `ns-dignified-python`, `ns-py-fake-driven-testing`, or `fdt-refactor-mock-to-fake` to Python files inside vendored (real-directory) entries under `.agents/skills/` unless the user explicitly asks to modify the vendored dependency itself.
- When reviewing or editing the repo, exclude vendored entries — real directories under `.agents/skills/**/*.py` — from normal linting, typechecking, code review, and cleanup expectations; assume those files should remain as-shipped unless the task is specifically about updating vendored skill code.

### Dev Skill Naming Convention

Skills prefixed with `dev-` are developer-only tooling — either pure contributor helpers (`dev-gh`, `dev-fix-just`) or prototype features being dogfooded before graduation (`dev-plan-to-branch`). Dev skills additionally carry `metadata.internal: true` in their `SKILL.md` frontmatter to hide them from external `npx skills add` discovery. A prototype graduates to a published feature by (1) dropping the `dev-` prefix in all three directory locations and every reference, and (2) removing the `internal: true` frontmatter flag.

### GitHub Backend Interactions

When adding or editing any code that interacts with the GitHub backend — whether through GraphQL queries, REST API calls, or `gh` CLI commands — always consult the `dev-gh` skill (`.claude/skills/dev-gh/SKILL.md`) and its references first. This ensures correct API selection (REST vs GraphQL), proper rate-limit awareness, and consistency with the existing gateway patterns in `twerk-core`.

### CLI Scenario Testing Convention

Each CLI package has two entry points: a standalone CLI (e.g., `pr-address`) built by `build_cli()` in `<package>.cli.main`, and a twerk plugin subgroup discovered via `twerk.plugins` entry points. Test them separately:

**Scenario tests** live in their home package (e.g., `packages/twerk-pr-address/tests/scenario/`) and should exhaustively cover every user-facing scenario for that package's standalone CLI via `build_cli()`. This is the user-facing entry point and the right level to test. The fixture should be `cli_group = build_cli()`, not `discover_group(...)` directly. Include `--version` and `-h` tests alongside operation tests in the same file.

**Plugin smoke tests** (`tests/scenario/test_plugins.py` in the top-level twerk package): Verify that each plugin's entry point wires up correctly through `discover_plugins`. One test per plugin that mounts the subgroup and invokes a representative command. These live at the twerk scope because they test the plugin discovery contract.

### Available skills

- fdt-refactor-mock-to-fake: Refactor tests that use `unittest.mock.patch` or `MagicMock` into the gateway-based fake pattern. Use when test files patch module-level attributes like `subprocess.run`, `shutil.which`, or `os.environ`, or otherwise need source code made injectable before rewriting the tests. (file: /Users/schrockn/code/twerk/.claude/skills/fdt-refactor-mock-to-fake/SKILL.md)
- dev-fix-just: Run `just` and fix all failures (lint, format, type errors, test failures) by fixing the underlying code — not by deleting or weakening tests. If user input is needed, ask the user. If the current harness is in a planning or read-only mode, present a plan to fix the failures instead of applying changes. (file: /Users/schrockn/code/twerk/.claude/skills/dev-fix-just/SKILL.md)
- graphite: Work with Graphite (`gt`) for stacked PRs, including creating, navigating, and managing PR stacks. Use when the task involves Graphite workflows or stacked-PR operations. (file: /Users/schrockn/code/twerk/.claude/skills/graphite/SKILL.md)
- dev-gt-stackify-branch: Split a single mixed branch into a clean Graphite stack by planning PR slices, preserving the source branch, rebuilding each slice from trunk, validating the stack, and submitting it when requested. Use when the task is to turn one branch into 2+ stacked PRs. (file: /Users/schrockn/code/twerk/.claude/skills/dev-gt-stackify-branch/SKILL.md)
- ns-pytest: Pytest-specific style guide for writing and reviewing tests. Use when deciding between fixtures / context managers / plain helper functions, choosing whether to write a test class or a module-level `test_*` function, using `@pytest.mark.parametrize` / `tmp_path` / `monkeypatch` / `capsys`, structuring `unittest.mock.patch` usage (context manager vs decorator, `autospec`, where to patch), or cleaning up `autouse` fixtures and conftest nesting. Prescribes functional-only style (no `class Test*`), a strict setup hierarchy (plain helpers > context managers > fixtures for expensive shared resources only), and mocking best practice (`monkeypatch` first, then `patch` as a context manager with `autospec`, narrow scope, patch at point of use). For architecture-level questions use `fake-driven-testing`; for mock-to-fake migration use `fdt-refactor-mock-to-fake`. (file: /Users/schrockn/code/twerk/.claude/skills/ns-pytest/SKILL.md)
- objective-create: Create a GitHub issue for a new twerk objective. Use when the user wants to start an objective, capture a multi-session workstream in GitHub, turn a rough project brief into an issue-backed objective, or create something that should later appear in `twerk objective list`. (file: /Users/schrockn/code/twerk/.claude/skills/objective-create/SKILL.md)
- objective-list: Display the user's twerk objectives (GitHub issues labeled `objective`). Use when the user asks to list, view, or pick from current objectives, or wants details on a specific objective by number. Lists via `twerk objective list` and drills into specific issues with `gh issue view`. Read-only. (file: /Users/schrockn/code/twerk/.claude/skills/objective-list/SKILL.md)
- objective-progress: Progress an objective by reading its GitHub issue, assessing the codebase, and implementing the next piece of work. Use when the user wants to make progress on an existing twerk objective, pick up where they left off, or continue a multi-session workstream. (file: /Users/schrockn/code/twerk/.claude/skills/objective-progress/SKILL.md)
- objective-reconcile: Reconcile an objective after landing a PR. Auto-detects the PR from the current branch and the objective from Objective: #N trailers in commit messages. Reads the merged PR, updates the objective issue body, and posts a reconciliation comment. (file: /Users/schrockn/code/twerk/.claude/skills/objective-reconcile/SKILL.md)
- dev-plan-to-branch: Stamp an existing plan file onto a new Graphite branch. Resolves the plan from current conversation context (or an explicit path / most recent file in `~/.claude/plans/`), generates a kebab-case slug that summarizes the plan, runs `gt create`, writes `plan-<slug>.md` at the repo root, and commits it as the branch's first commit. Use right after exiting plan mode, or when the user says "branch this plan" or "stamp the plan". (file: /Users/schrockn/code/twerk/.claude/skills/dev-plan-to-branch/SKILL.md)
- pr-address: Address PR review comments end-to-end on the current branch's PR. Use when the user says "address PR comments", "fix review feedback", "resolve review threads", or asks to respond to a specific PR's review. Fetches unresolved review threads and discussion comments via `gh`, classifies them with LLM judgment (actionable vs informational, bot noise, pre-existing issues), plans batched execution, implements code changes, commits in batches, and resolves threads. Never pushes — the user pushes manually after reviewing local commits. (file: /Users/schrockn/code/twerk/.claude/skills/pr-address/SKILL.md)
- skill-creator: Create new skills, modify and improve existing skills, and measure skill performance. Use when users want to create a skill from scratch, edit or optimize an existing skill, or evaluate skill triggering/performance. (file: /Users/schrockn/code/twerk/.claude/skills/skill-creator/SKILL.md)
- ns-skill-management: Manage skills in nonslop projects with `npx skills`. Use whenever you need to add a new skill (local or from GitHub), edit an existing skill, remove one, update GitHub-sourced skills, inspect what's installed, or publish skills for external consumption. Covers the convention of `skills/<name>/` as the canonical source for local skills, `.agents/skills/` for vendored code, and the canonical `--agent codex claude-code -y` install flag. (file: /Users/schrockn/code/twerk/.claude/skills/ns-skill-management/SKILL.md)
- dev-gh: Use when working with GitHub CLI (`gh`) for pull requests, issues, releases, and GitHub automation. Use when users mention `gh` commands, GitHub workflows, PR operations, issue management, or GitHub API access. Essential for understanding `gh`'s mental model, command structure, and integration with git workflows. (file: /Users/schrockn/code/twerk/.claude/skills/dev-gh/SKILL.md)
- ns-changelog-update: Sync `CHANGELOG.md` unreleased section with recent commits. Use when the user wants to update the changelog, add recent changes to the changelog, sync the changelog with commits, or prepare changelog entries. Also handles first-time changelog initialization when no `CHANGELOG.md` exists. (file: /Users/schrockn/code/twerk/.claude/skills/ns-changelog-update/SKILL.md)
- ns-create-py-dev-cli: Scaffold a `-dev` CLI workspace package for development tooling. Use when the user wants to add a dev CLI to an existing Python project, create developer commands, set up a `-dev` package, or add project-specific tooling as a click CLI. Creates the full package structure inside `packages/<project>-dev/` with click CLI, static imports for shell completion, output routing, context injection, a starter `clean-pyproject` command, and wires up the uv workspace. (file: /Users/schrockn/code/twerk/.claude/skills/ns-create-py-dev-cli/SKILL.md)
- ns-create-pypackage-project: Scaffold a well-structured Python package project. Use when the user wants to create a new Python package, set up a Python project, initialize a pypackage, bootstrap a Python library or CLI tool, or start a new Python repo with modern tooling. Creates the full project structure: `pyproject.toml` (uv + hatchling), src layout, ruff, ty, pytest + pytest-xdist, justfile, and `.gitignore`. Produces a project that passes `just check` immediately. (file: /Users/schrockn/code/twerk/.claude/skills/ns-create-pypackage-project/SKILL.md)
- ns-dignified-python: Production Python coding standards with automatic version detection (3.10–3.13). Use when writing, reviewing, or refactoring Python to ensure adherence to modern type syntax, LBYL exception handling, pathlib operations, ABC-based interfaces, and production-tested patterns. (file: /Users/schrockn/code/twerk/.claude/skills/ns-dignified-python/SKILL.md)
- ns-fake-driven-test-layout: Per-package test directory convention for fake-driven Python projects. Defines the canonical layout `tests/{unit,integration,scenario,gateways}/` and what belongs in each subfolder. Use whenever creating a new package, reorganizing tests, or deciding which subdirectory a new test file goes in. Owns the on-disk layout that `ns-py-fake-driven-testing` defers to for placement decisions. (file: /Users/schrockn/code/twerk/.claude/skills/ns-fake-driven-test-layout/SKILL.md)
- ns-py-fake-driven-testing: Use when writing tests, fixing bugs, adding features, or modifying the gateway layer. Use when you need guidance on testing architecture, working with fakes, implementing ABC gateway interfaces, or understanding the defense-in-depth testing strategy. Essential for maintaining test quality and understanding where different types of tests belong. (file: /Users/schrockn/code/twerk/.claude/skills/ns-py-fake-driven-testing/SKILL.md)
- ns-refac-cli-push-down: Moving mechanical computation from LLM prompts into tested CLI commands. Use when writing or reviewing slash commands with embedded bash, when a skill/command exceeds ~100 lines of procedural steps, when adding parsing/validation/transformation logic to markdown prompts, when debugging flaky embedded scripts, or when refactoring commands to reduce token overhead. (file: /Users/schrockn/code/twerk/.claude/skills/ns-refac-cli-push-down/SKILL.md)
- ns-refactor-swarm: Parallel file-local refactors across many files using a swarm of haiku agents. Use when the same shape of refactor applies to 5+ files, each file is transformable from its own contents plus a shared brief (no cross-file coordination), and light per-file judgment is acceptable. Not for refactors where judgment must be unified across files. (file: /Users/schrockn/code/twerk/.claude/skills/ns-refactor-swarm/SKILL.md)
- ns-resolve-merge-conflicts: Resolve merge conflicts from an in-progress rebase. Use when a rebase hits conflicts and the user wants Claude to resolve them intelligently. (file: /Users/schrockn/code/twerk/.claude/skills/ns-resolve-merge-conflicts/SKILL.md)
- ns-setup-dprint: Set up dprint formatting for Markdown and TOML files. Use when adding dprint to a project or integrating format checks into the build system. (file: /Users/schrockn/code/twerk/.claude/skills/ns-setup-dprint/SKILL.md)
- ns-setup-python-ci: Generate GitHub Actions CI workflow for Python projects using uv and just. Use when the user wants to set up CI, add GitHub Actions, create a CI workflow, configure continuous integration, or add automated testing to their project. Produces `.github/workflows/python-ci.yml` and `.github/actions/setup-python-uv/action.yml` with jobs for lint, format-check, ty, and test (with Python version matrix). (file: /Users/schrockn/code/twerk/.claude/skills/ns-setup-python-ci/SKILL.md)
- ns-skillx: Run any skill from a GitHub repo without installing it. Like `npx` for skills — fetches into a temp dir, reads the `SKILL.md`, follows its instructions, then discards. No project pollution. Accepts: `owner/repo@skill`, GitHub URLs, `--skill` syntax, or natural language. (file: /Users/schrockn/code/twerk/.claude/skills/ns-skillx/SKILL.md)
- nsx: Run any skill from `nseng-ai/nonslop` without installing it. Shorthand for `skillx` against the nonslop repo. Pass a skill name to run it, or no arguments to list available skills. (file: /Users/schrockn/code/twerk/.claude/skills/nsx/SKILL.md)

### How to use skills

- Discovery: The list above is the skills available in this repo for Codex sessions. Skill bodies live on disk at the listed paths.
- Trigger rules: If the user names a skill (with `$SkillName` or plain text) OR the task clearly matches a skill's description shown above, you must use that skill for that turn. Multiple mentions mean use them all. Do not carry skills across turns unless re-mentioned.
- Missing/blocked: If a named skill isn't in the list or the path can't be read, say so briefly and continue with the best fallback.
- How to use a skill (progressive disclosure):
  1. After deciding to use a skill, open its `SKILL.md`. Read only enough to follow the workflow.
  2. When `SKILL.md` references relative paths, resolve them relative to the skill directory first.
  3. If `SKILL.md` points to extra folders such as `references/`, load only the specific files needed for the request; don't bulk-load everything.
  4. If `scripts/` exist, prefer running or patching them instead of retyping large code blocks.
  5. If `assets/` or templates exist, reuse them instead of recreating from scratch.
- Coordination and sequencing:
  - If multiple skills apply, choose the minimal set that covers the request and state the order you'll use them.
  - Announce which skill(s) you're using and why in one short line.
  - If you skip an obvious skill, say why.
- Context hygiene:
  - Keep context small: summarize long sections instead of pasting them; only load extra files when needed.
  - Avoid deep reference-chasing: prefer opening only files directly linked from `SKILL.md` unless you're blocked.
  - When variants exist, pick only the relevant reference file(s) and note that choice.
- Safety and fallback: If a skill can't be applied cleanly, state the issue, pick the next-best approach, and continue.

### Managing Skills With `npx skills`

All skill-management procedures — adding, editing, removing, updating, listing, and publishing skills — are documented in the `skill-management` skill at `.agents/skills/skill-management/SKILL.md`. Use that skill whenever you need to install or modify skills rather than running `npx skills` commands freehand. The canonical twerk install flag is `--agent codex claude-code -y`. Local skills live as real directories under `skills/<name>/`; `.agents/skills/<name>` is a symlink back to that canonical source, keeping the universal-agent directory populated without duplicating content. GitHub-sourced skills remain real directories under `.agents/skills/<name>/`.
