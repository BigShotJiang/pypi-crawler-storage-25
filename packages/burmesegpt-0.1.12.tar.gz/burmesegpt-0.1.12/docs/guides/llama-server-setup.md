# llama-server Setup

Optional manual setup: if you want to bring your own standalone `llama-server` binary, or you need a custom llama.cpp build, this guide shows how to install one yourself.

`burmesegpt` will bootstrap a compatible standalone `llama-server` automatically for the default beginner flow. Use this guide only if you want to manage the binary yourself.

For Padauk Gemma 4 shared-KV serving, use a standalone `llama.cpp` build at `b8751` or newer. `b8833` is the recommended target.

## macOS / Apple Silicon

```bash
git clone https://github.com/ggml-org/llama.cpp.git
cd llama.cpp
git checkout b8833

cmake -B build -S . -DGGML_METAL=ON -DCMAKE_BUILD_TYPE=Release
cmake --build build -j

export PATH="$PWD/build/bin:$PATH"
llama-server --version
```

## Verify

You want the version output to report `8833` or another build at or above `8751`.

```bash
which llama-server
llama-server --version
```

If you already have a compatible standalone `llama-server`, you can skip the build step and just make sure it is on `PATH`.
