from __future__ import annotations

import platform
import re
import shutil
import subprocess
import tarfile
import tempfile
from pathlib import Path
from typing import Any

import requests

LLAMA_CPP_REPOSITORY = "ggml-org/llama.cpp"
LLAMA_CPP_RELEASE_TAG = "b8833"
MIN_STANDALONE_LLAMA_CPP_BUILD = 8751
RECOMMENDED_STANDALONE_LLAMA_CPP_BUILD = 8833

_GITHUB_API_ROOT = "https://api.github.com"
_VERSION_PATTERN = re.compile(r"version[:\s]*b?(?P<build>\d+)", re.IGNORECASE)
_B_PREFIX_PATTERN = re.compile(r"\bb(?P<build>\d+)\b", re.IGNORECASE)


class LlamaServerBootstrapError(RuntimeError):
    """Raised when the managed llama-server bootstrap flow fails."""


class UnsupportedLlamaServerPlatformError(LlamaServerBootstrapError):
    """Raised when the host platform cannot use an official llama.cpp asset."""


def _normalize_arch(machine: str) -> str | None:
    normalized = machine.lower().strip()
    if normalized in {"arm64", "aarch64"}:
        return "arm64"
    if normalized in {"x86_64", "amd64"}:
        return "x64"
    return None


def select_platform_key(*, system: str | None = None, machine: str | None = None) -> str:
    system_name = (system or platform.system()).strip().lower()
    arch_name = _normalize_arch(machine or platform.machine())
    if arch_name is None:
        raise UnsupportedLlamaServerPlatformError(
            f"Unsupported llama-server architecture: {machine or platform.machine()!r}."
        )

    if system_name == "darwin":
        return f"macos-{arch_name}"
    if system_name == "linux":
        return f"ubuntu-{arch_name}"

    raise UnsupportedLlamaServerPlatformError(
        f"Unsupported llama-server platform: {system or platform.system()!r}."
    )


def select_release_asset_name(
    tag: str = LLAMA_CPP_RELEASE_TAG,
    *,
    system: str | None = None,
    machine: str | None = None,
) -> str:
    platform_key = select_platform_key(system=system, machine=machine)
    return f"llama-{tag}-bin-{platform_key}.tar.gz"


def managed_cache_dir(
    *,
    tag: str = LLAMA_CPP_RELEASE_TAG,
    platform_key: str | None = None,
    cache_root: str | Path | None = None,
) -> Path:
    base = Path(cache_root) if cache_root is not None else Path.home() / ".cache" / "burmesegpt" / "llama-server"
    resolved_platform = platform_key or select_platform_key()
    return base / tag / resolved_platform


def _parse_build(output: str) -> int | None:
    for pattern in (_VERSION_PATTERN, _B_PREFIX_PATTERN):
        match = pattern.search(output)
        if match is not None:
            return int(match.group("build"))
    return None


def _llama_server_build(path: Path) -> int | None:
    try:
        result = subprocess.run(
            [str(path), "--version"],
            capture_output=True,
            text=True,
            check=True,
        )
    except (OSError, subprocess.CalledProcessError):
        return None

    output = "\n".join(part for part in (result.stdout, result.stderr) if part)
    return _parse_build(output)


def _ensure_executable(path: Path) -> None:
    mode = path.stat().st_mode
    path.chmod(mode | 0o111)


def _find_llama_server(cache_dir: Path) -> Path | None:
    for candidate in cache_dir.rglob("llama-server"):
        if candidate.is_file():
            _ensure_executable(candidate)
            return candidate
    return None


def _fetch_release_assets(tag: str) -> dict[str, str]:
    url = f"{_GITHUB_API_ROOT}/repos/{LLAMA_CPP_REPOSITORY}/releases/tags/{tag}"
    response = requests.get(
        url,
        headers={
            "Accept": "application/vnd.github+json",
            "User-Agent": "burmesegpt-bootstrap",
        },
        timeout=30,
    )
    try:
        response.raise_for_status()
        payload: dict[str, Any] = response.json()
    except (requests.RequestException, ValueError) as exc:
        raise LlamaServerBootstrapError(
            f"Unable to query GitHub release {LLAMA_CPP_REPOSITORY}@{tag}: {exc}"
        ) from exc
    finally:
        response.close()
    assets = payload.get("assets")
    if not isinstance(assets, list):
        raise LlamaServerBootstrapError(f"GitHub release {tag} did not return a valid asset list.")

    release_assets: dict[str, str] = {}
    for asset in assets:
        if isinstance(asset, dict):
            name = asset.get("name")
            download_url = asset.get("browser_download_url")
            if isinstance(name, str) and isinstance(download_url, str):
                release_assets[name] = download_url
    return release_assets


def _download_archive(download_url: str, archive_path: Path) -> None:
    response = requests.get(
        download_url,
        stream=True,
        headers={"User-Agent": "burmesegpt-bootstrap"},
        timeout=60,
    )
    try:
        response.raise_for_status()
        with archive_path.open("wb") as fh:
            for chunk in response.iter_content(chunk_size=1024 * 1024):
                if chunk:
                    fh.write(chunk)
    except requests.RequestException as exc:
        raise LlamaServerBootstrapError(f"Failed to download llama-server archive: {exc}") from exc
    finally:
        response.close()


def _safe_extract_tar(archive_path: Path, destination: Path) -> None:
    destination.mkdir(parents=True, exist_ok=True)
    with tarfile.open(archive_path, mode="r:gz") as tar:
        resolved_destination = destination.resolve()
        for member in tar.getmembers():
            resolved_member = (destination / member.name).resolve(strict=False)
            if not resolved_member.is_relative_to(resolved_destination):
                raise LlamaServerBootstrapError(
                    f"Refusing to extract archive member outside cache directory: {member.name}"
                )
        tar.extractall(destination)


def _validate_managed_llama_server(path: Path) -> None:
    build = _llama_server_build(path)
    if build is None:
        raise LlamaServerBootstrapError(
            f"Downloaded llama-server at {path} did not report a parseable version."
        )
    if build < MIN_STANDALONE_LLAMA_CPP_BUILD:
        raise LlamaServerBootstrapError(
            f"Downloaded llama-server at {path} is too old (found b{build}, need >= b{MIN_STANDALONE_LLAMA_CPP_BUILD})."
        )


def bootstrap_llama_server(
    *,
    tag: str = LLAMA_CPP_RELEASE_TAG,
    cache_root: str | Path | None = None,
    system: str | None = None,
    machine: str | None = None,
) -> Path:
    platform_key = select_platform_key(system=system, machine=machine)
    cache_dir = managed_cache_dir(tag=tag, platform_key=platform_key, cache_root=cache_root)
    cached = _find_llama_server(cache_dir)
    if cached is not None:
        try:
            _validate_managed_llama_server(cached)
            return cached
        except LlamaServerBootstrapError:
            shutil.rmtree(cache_dir, ignore_errors=True)
            cache_dir.mkdir(parents=True, exist_ok=True)

    asset_name = select_release_asset_name(tag, system=system, machine=machine)
    release_assets = _fetch_release_assets(tag)
    download_url = release_assets.get(asset_name)
    if download_url is None:
        available = ", ".join(sorted(release_assets))
        raise LlamaServerBootstrapError(
            f"Official llama.cpp release {tag} does not contain {asset_name}. "
            f"Available assets: {available}"
        )

    cache_dir.mkdir(parents=True, exist_ok=True)
    archive_path = cache_dir / asset_name
    if archive_path.exists():
        archive_path.unlink()

    with tempfile.TemporaryDirectory(dir=cache_dir) as temp_dir:
        temp_archive = Path(temp_dir) / asset_name
        _download_archive(download_url, temp_archive)
        shutil.move(str(temp_archive), archive_path)
        extract_dir = Path(temp_dir) / "extract"
        _safe_extract_tar(archive_path, extract_dir)
        for child in extract_dir.iterdir():
            destination = cache_dir / child.name
            if destination.exists():
                if destination.is_dir():
                    shutil.rmtree(destination)
                else:
                    destination.unlink()
            shutil.move(str(child), str(destination))

    extracted = _find_llama_server(cache_dir)
    if extracted is None:
        raise LlamaServerBootstrapError(
            f"Downloaded llama.cpp archive {asset_name} did not contain a llama-server executable."
        )

    _ensure_executable(extracted)
    _validate_managed_llama_server(extracted)
    return extracted
