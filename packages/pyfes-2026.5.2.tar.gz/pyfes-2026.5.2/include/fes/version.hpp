/// @file fes/version.hpp
/// @brief Version of the library
#pragma once
/// Major version of the library
#define FES_VERSION_MAJOR 2026
/// Minor version of the library
#define FES_VERSION_MINOR 5
/// Patch version of the library
#define FES_VERSION_PATCH 2
