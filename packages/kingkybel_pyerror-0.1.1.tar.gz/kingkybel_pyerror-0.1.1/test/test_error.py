import unittest
import sys
from pathlib import Path

# Add parent directory to path for absolute imports
sys.path.insert(0, str(Path(__file__).parent.parent))

from error import fatal, critical, error


class TestError(unittest.TestCase):

    def test_fatal_default(self):
        with self.assertRaises(SystemExit) as cm:
            fatal("Test fatal message")
        self.assertEqual(cm.exception.code, 1)

    def test_fatal_custom_exception(self):
        class CustomException(Exception):
            def __init__(self, code, *args, **kwargs):
                super().__init__(*args, **kwargs)
                self.code = code

        with self.assertRaises(CustomException) as cm:
            fatal("Test fatal", exception=CustomException, error_code=42)
        self.assertEqual(cm.exception.code, 42)

    def test_fatal_with_args(self):
        class CustomException(Exception):
            def __init__(self, code, *args, **kwargs):
                super().__init__(*args, **kwargs)
                self.code = code

        with self.assertRaises(CustomException) as cm:
            fatal("Test fatal", CustomException, 2, "extra_arg")
        self.assertEqual(cm.exception.code, 2)

    def test_critical_default(self):
        with self.assertRaises(SystemExit) as cm:
            critical("Test critical message")
        self.assertEqual(cm.exception.code, 1)

    def test_error_default(self):
        with self.assertRaises(SystemExit) as cm:
            error("Test error message")
        self.assertEqual(cm.exception.code, 1)

    def test_fatal_with_kwargs(self):
        class CustomException(Exception):
            def __init__(self, code, *args, **kwargs):
                self.code = code
                self.extra_data = kwargs.get('extra_data')

        with self.assertRaises(CustomException) as cm:
            fatal("Test fatal", CustomException, 3, extra_data="test_data")
        self.assertEqual(cm.exception.code, 3)
        self.assertEqual(cm.exception.extra_data, "test_data")

    def test_fatal_with_args_and_kwargs(self):
        class CustomException(Exception):
            def __init__(self, code, *args, **kwargs):
                self.code = code
                self.args_list = args
                self.extra_data = kwargs.get('extra_data')

        with self.assertRaises(CustomException) as cm:
            fatal("Test fatal", CustomException, 5, "arg1", "arg2", extra_data="data")
        self.assertEqual(cm.exception.code, 5)
        self.assertEqual(cm.exception.args_list, ("arg1", "arg2"))
        self.assertEqual(cm.exception.extra_data, "data")

    def test_critical_with_custom_exception(self):
        class CustomException(Exception):
            def __init__(self, code, *args, **kwargs):
                super().__init__(*args, **kwargs)
                self.code = code

        with self.assertRaises(CustomException) as cm:
            critical("Test critical", CustomException, 10)
        self.assertEqual(cm.exception.code, 10)

    def test_error_with_custom_exception(self):
        class CustomException(Exception):
            def __init__(self, code, *args, **kwargs):
                super().__init__(*args, **kwargs)
                self.code = code

        with self.assertRaises(CustomException) as cm:
            error("Test error", CustomException, 20)
        self.assertEqual(cm.exception.code, 20)


if __name__ == '__main__':
    unittest.main()