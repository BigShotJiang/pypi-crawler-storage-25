from flashlogger import log_fatal, log_critical, log_error


def fatal(message, exception=SystemExit, error_code=1, *args, **kwargs):
    log_fatal(message=message)
    raise exception(error_code, *args, **kwargs)


def critical(message, exception=SystemExit, error_code=1, *args, **kwargs):
    log_critical(message=message)
    raise exception(error_code, *args, **kwargs)


def error(message, exception=SystemExit, error_code=1, *args, **kwargs):
    log_error(message=message)
    raise exception(error_code, *args, **kwargs)
