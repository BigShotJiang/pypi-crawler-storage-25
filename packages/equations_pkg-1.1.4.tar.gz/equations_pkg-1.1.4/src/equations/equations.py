import re
import math
import matplotlib.pyplot as plt
import numpy as np

class equations:
    @staticmethod
    def linear_onevar(lhs, rhs):
        match = re.match(r"(\d+)([a-zA-Z])([\+\-])(\d+)", lhs) #format: ax+b = c
        if not match:
            raise ValueError("Invalid format - format for linear equations (one variable) is 'ax+b = c'. Input 'ax+b' as LHS and 'c' as RHS. Make sure your equation is in standard simplified form.")
        a, var, op, b = match.groups()
        a, b, c = int(a), int(b), float(rhs)
        if op == '+':
            answer = (c - b) / a
        else:
            answer = (c + b) / a
        return f"{var} = {answer}"

    @staticmethod
    def linear_twovar_bisolution(lhs, rhs):
        match = re.match(r"(\d+)[a-zA-Z]([\+\-])(\d+)[a-zA-Z]([\+\-])(\d+)", lhs) #format: ax+by+c = d
        if not match:
            raise ValueError("Invalid format - format for linear equations (two variables) is 'ax+by+c = d'. Input 'ax+by+c' as LHS and 'd' as RHS. Make sure your equation is in standard simplified form.")
        a, op1, b, op2, c_val = match.groups()
        a, b, c_val, d = int(a), int(b), int(c_val), float(rhs)
        target = d - c_val if op2 == '+' else d + c_val
        x_ans = target / a
        y_ans = target / b if op1 == '+' else target / -b
        return f"Solutions: (0, {y_ans}) and ({x_ans}, 0)"

    @staticmethod
    def quadratic_onevar(equation_str, rhs=0):
        pattern = r"([+-]?\d*)[a-zA-Z]\^2([+-]?\d*)[a-zA-Z]([+-]?\d+)" #format: ax^2+bx+c
        match = re.search(pattern, equation_str.replace(" ", ""))
        if not match:
            raise ValueError("Invalid format - format for quadratic equations (one variable) is 'ax^2+by+c = 0'. Input 'ax+b' as LHS and RHS is preset to 0. Make sure your equation is in standard simplified form.")
        else:
            raw_a, raw_b, raw_c = match.groups()
            a = int(raw_a) if raw_a not in ["", "+", "-"] else int(raw_a + "1")
            b = int(raw_b) if raw_b not in ["", "+", "-"] else int(raw_b + "1")
            c = int(raw_c) - rhs 
            discriminant = b**2 - 4*a*c
            if discriminant < 0:
                return ValueError(f"No real solutions for {equation_str} as discriminant (b^2 - 4ac) < 0.")
            root1 = (-b + math.sqrt(discriminant)) / (2 * a)
            root2 = (-b - math.sqrt(discriminant)) / (2 * a)
            return f"x = {root1}, {root2}"

    @staticmethod
    def linear_twovar_custom(lhs, rhs, num):
        match = re.match(r"(\d+)[a-zA-Z]([\+\-])(\d+)[a-zA-Z]([\+\-])(\d+)", lhs) #format: ax+by+c = d
        if not match:
            raise ValueError("Invalid format - format for linear equations (two variables) is 'ax+by+c = d'. Input 'ax+by+c' as LHS and 'd' as RHS. Make sure your equation is in standard simplified form.")
        if not num:
            raise ValueError("Missing input - enter the number of solutions needed (num).")
        a, op1, b, op2, c_val = match.groups()
        a, b, c_val, d = int(a), int(b), int(c_val), float(rhs)
        rhs_const = d - c_val if op2 == '+' else d + c_val
        coeff_b = b if op1 == '+' else -b
        solutions = []
        for x in range(num):
            y = (rhs_const - (a * x)) / coeff_b
            solutions.append(f"({x}, {y})")
        return "Solutions: " + ", ".join(solutions)

    @staticmethod
    def quadratic_twovar_bisolution(lhs, rhs, x_val):
        pattern = r"([+-]?\d*)x\^2([+-]?\d*)xy([+-]?\d*)y\^2([+-]?\d*)x([+-]?\d*)y([+-]?\d+)" # format: ax^2 + bxy + cy^2 + dx + ey + f = rhs
        match = re.search(pattern, lhs.replace(" ", ""))
        if not match:
            raise ValueError("Invalid format - format for quadratic equations (two variables) is 'ax^2 + bxy + cy^2 + dx + ey + f = g'. Input 'ax^2 + bxy + cy^2 + dx + ey + f' as LHS and 'g' as RHS. Make sure your equation is in standard simplified form.")
        if not x_val:
            raise ValueError("Missing input - enter the value of 'x' for the solutions.")
        def clean(val):
            if val in ["", "+"]: return 1.0
            if val == "-": return -1.0
            return float(val)
        A, B, C, D, E, F = [clean(g) for g in match.groups()]
        G = float(rhs)
        a_q = C
        b_q = (B * x_val) + E
        c_q = (A * (x_val**2)) + (D * x_val) + F - G
        discriminant = (b_q**2) - (4 * a_q * c_q)
        if discriminant < 0:
            return ValueError(f"No real solutions for {equation_str} as discriminant < 0.")
        sqrt_disc = math.sqrt(discriminant)
        y1 = (-b_q + sqrt_disc) / (2 * a_q)
        y2 = (-b_q - sqrt_disc) / (2 * a_q)
        return f"At x={x_val}, y = {y1} or {y2}"

    @staticmethod
    def cubic_onevar(a, b, c, d): # input values of a, b, c and d for ax^3+bx^2+cx+d, rhs is preset to 0
        first_root = None
        if d == 0:
            first_root = 0
        else:
            factors = []
            for i in range(1, int(abs(d)) + 1):
                if d % i == 0:
                    factors.extend([i, -i])
            for r in factors:
                if (a * r**3 + b * r**2 + c * r + d) == 0:
                    first_root = r
                    break
        if first_root is None:
            return "No simple integer root found. Requires Cardano's Method."
        A = a
        B = b + (A * first_root)
        C = c + (B * first_root)
        discriminant = B**2 - 4*A*C
        roots = [float(first_root)]
        if discriminant > 0:
            roots.append((-B + math.sqrt(discriminant)) / (2*A))
            roots.append((-B - math.sqrt(discriminant)) / (2*A))
        elif discriminant == 0:
            roots.append(-B / (2*A))
        else:
            real_part = -B / (2*A)
            imag_part = math.sqrt(-discriminant) / (2*A)
            roots.append(f"{real_part} + {imag_part}j")
            roots.append(f"{real_part} - {imag_part}j")
        return f"Roots: {roots}"

    @staticmethod
    def linear_threevar_custom_multiplane(lhs, rhs, num, mode): 
        pattern = r"([+-]?\d*)[xX]([+-]?\d*)[yY]([+-]?\d*)[zZ]([+-]?\d+)" # format: ax+by+cz+d
        match = re.match(pattern, lhs.replace(" ", ""))
        if not match:
            raise ValueError("Invalid format - format for linear equations (three variables) is 'ax+by+cz+d = e'. Input 'ax+by+cz+d' as LHS and 'e' as RHS. Make sure your equation is in standard simplified form.")
        if not num:
            raise ValueError("Missing input - enter the number of solutions needed (num).")
        if not mode:
            raise ValueError("Missing input - enter the plane for solutions (xy/yz/zx).")
        def clean(val):
            if val in ["", "+"]: return 1.0
            if val == "-": return -1.0
            return float(val)
        a, b, c, d_val = [clean(g) for g in match.groups()]
        k = float(rhs)
        target = k - d_val    
        solutions = []
        for i in range(num):
            val = float(i)
            if mode == "yz":
                z = (target - (b * val)) / c
                solutions.append(f"(0.0, {val}, {z})")
            elif mode == "xy":
                y = (target - (a * val)) / b
                solutions.append(f"({val}, {y}, 0.0)") 
            elif mode == "zx":
                z = (target - (a * val)) / c
                solutions.append(f"({val}, 0.0, {z})")
        return f"Solutions ({mode}): " + " | ".join(solutions)

class visual:
    @staticmethod
    def graph_equation_2D(formula_func, x_range=(-20, 20)):
        x = np.linspace(x_range[0], x_range[1], 400)
        try:
            y = formula_func(x)
        except Exception as e:
            return f"Error calculating y: {e}"
        plt.figure(figsize=(8, 6))
        plt.plot(x, y, label="y = f(x)", color="blue", linewidth=2)
        plt.axhline(0, color='black', linewidth=1)
        plt.axvline(0, color='black', linewidth=1)
        plt.grid(True, linestyle='--', alpha=0.7)
        plt.title("Equation Graph")
        plt.xlabel("x")
        plt.ylabel("y")
        plt.legend()
        plt.show()

    @staticmethod
    def graph_equation_3D(a, b, c, d, k, x_range=(-20, 20), y_range=(-20, 20)):
        # equation: ax + by + cz + d = k
        # rearranged: z = (k - d - ax - by) / c
        x = np.linspace(x_range[0], x_range[1], 30)
        y = np.linspace(y_range[0], y_range[1], 30)
        X, Y = np.meshgrid(x, y)
        Z = (k - d - (a * X) - (b * Y)) / c
        fig = plt.figure(figsize=(10, 8))
        ax = fig.add_subplot(111, projection='3d')
        surface = ax.plot_surface(X, Y, Z, cmap='viridis', alpha=0.8)
        ax.set_xlabel('X Axis')
        ax.set_ylabel('Y Axis')
        ax.set_zlabel('Z Axis')
        plt.title(f"Plane: {a}x + {b}y + {c}z + {d} = {k}")
        plt.show()

class other_functions:
    @staticmethod
    def testers():
        print(equations.linear_onevar("10x+5", 25))
        print(equations.linear_twovar_bisolution("5x-3y+0", 6))
        print(equations.linear_twovar_custom("5x-3y+0", 6, 8))
        print(equations.linear_threevar_custom_multiplane("1x+1y+1z+0", 10, 5, 'xy'))
        print(equations.linear_threevar_custom_multiplane("1x+1y+1z+0", 10, 5, 'yz'))
        print(equations.linear_threevar_custom_multiplane("1x+1y+1z+0", 10, 5, 'zx'))
        print(equations.quadratic_onevar("1x^2 - 5x + 6"))
        print(equations.quadratic_twovar_bisolution("1x^2+0xy+1y^2+0x+0y-25", 0, 3))
        print(equations.cubic_onevar(1, -6, 11, -6))
        visual.graph_equation_2D(lambda x: x**2)
        visual.graph_equation_2D(lambda x: x**3 - 6*x**2 + 11*x - 6, x_range=(-2, 5))
        visual.graph_equation_3D(1, 1, 1, 0, 10)
        visual.graph_equation_3D(2, 3, 4, 5, 20)
        
    @staticmethod
    def help():
        print("This is a python module made to solve math equations.\n Version 1.0 features linear equations in one, two and three (multiplane) variables, quadratic equations in one and two variables, and cubic equations in one variable.")
        functions_with_formats = ["equations.linear_onevar: ax+b = c",
                                                     "equations.linear_twovar_bisolution: ax+by+c = d",
                                                     "equations.quadratic_onevar: ax^2+bx+c = 0",
                                                     "equations.linear_twovar_custom: ax+by+c = d and number of solutions needed (num)",
                                                     "equations.quadratic_twovar_bisolution: ax^2 + bxy + cy^2 + dx + ey + f = g",
                                                     "equations.cubic_onevar: input values of a, b, c and d for ax^3+bx^2+cx+d, rhs is preset to 0",
                                                     "equations.linear_threevar_custom_multiplane: ax+by+cz+d = e, number of solutions needed and plane (xy/yz/zx)",
                                                     "visual.graph_equation_2D: enter lambda x: {linear equation in one variable}"
                                                     "visual.graph_equation_3D: enter a, b, c, d and e for ax+by+cz+d = e equation"
                                                    ]
        print("Functions:")
        print("\n".join(functions_with_formats))
        print("In version 1.0, all equations are expected to be in standard simplified formats as mentioned.")
        print("Created by Aarsh Garg in 2026")
    
    @staticmethod
    def equation_classifier(lhs): #only the lhs (simplified)
        l_1v_match = re.match(r"(\d+)([a-zA-Z])([\+\-])(\d+)", lhs)
        l_2v_match = re.match(r"(\d+)[a-zA-Z]([\+\-])(\d+)[a-zA-Z]([\+\-])(\d+)", lhs)
        l_3v_match = re.match(r"([+-]?\d*)[xX]([+-]?\d*)[yY]([+-]?\d*)[zZ]([+-]?\d+)", lhs)
        q_1v_match = re.match(r"([+-]?\d*)[a-zA-Z]\^2([+-]?\d*)[a-zA-Z]([+-]?\d+)", lhs)
        q_2v_match = re.match(r"([+-]?\d*)x\^2([+-]?\d*)xy([+-]?\d*)y\^2([+-]?\d*)x([+-]?\d*)y([+-]?\d+)", lhs)
        c_1v_match = re.match(r"([+-]?\d*)[a-zA-Z]\^3([+-]?\d*)[a-zA-Z]\^2([+-]?\d*)[a-zA-Z]([+-]?\d+)", lhs)
        if c_1v_match:
            return "equation is cubic in one variable"
        elif q_2v_match:
            return "equation is quadratic in two variables"
        elif q_1v_match:
            return "equation is quadratic in one variable"
        elif l_3v_match:
            return "equation is linear in three variables"
        elif l_2v_match:
            return "equation is linear in two variables"
        elif l_1v_match:
            return "equation is linear in one variables"
        else:
            return "equation is not recognised (v1.0)"

other_functions.testers()
