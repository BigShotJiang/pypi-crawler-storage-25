# equations-pkg

A comprehensive Python module designed to solve and visualize a variety of mathematical equations, ranging from basic linear algebra to complex cubic and multi-variable equations.

## Installation

Install the package via pip:

```bash
pip install equations-pkg
```

## Usage:

import equations #the module is name 'equations-pkg' but the src is just 'equations'

from equations import equations, visual, other_functions


# class 'equations' consists of equation solver functions.


# linear equation solvers (one, two and three variables):

print(equations.linear_onevar("10x+5", 25)) #--> input LHS as 'ax+b' and RHS as 'c' (ax+b = c). One variable.

print(equations.linear_twovar_bisolution("5x-3y+0", 6)) #--> input LHS as 'ax+by+c' and RHS as 'd' (ax+by+c = d). Two variables, two solution output.

print(equations.linear_twovar_custom("5x-3y+0", 6, 8)) #--> input LHS as 'ax+by+c', RHS as 'd' (ax+by+c = d) and number of solutions needed (num). Two variables, (num) solutions output.

print(equations.linear_threevar_custom_multiplane("1x+1y+1z+0", 10, 5, 'xy')) #--> input LHS as 'ax+by+cz+d', RHS as 'e', number of solutions needed (num) and plane of solutions (xy/yz/zx). Three variables, (num) solutions output for the plane input.


# quadratic equation solvers (one and two variables):

print(equations.quadratic_onevar("1x^2 - 5x + 6")) #--> input LHS as 'ax^2+bx+c' and RHS is preset to 0. One variable, two solutions output.

print(equations.quadratic_twovar_bisolution("1x^2+0xy+1y^2+0x+0y-25", 0, 3)) #--> input LHS as 'ax^2+bxy+cy^2+dx+ey+f', RHS as 'g' and value of X to solve two solutions for Y. Two variables, two solutions of Y for X.


# cubic equation solvers (one variable):

print(equations.cubic_onevar(1, -6, 11, -6)) #--> input values for a, b, c and d for LHS as 'ax^3+bx^2+cx+d' and RHS is preset to 0. One variable, many solutions.


# class 'visual' consists of graphing functions (2D and 3D):

visual.graph_equation_2D(lambda x: x**3 - 6*x**2 + 11*x - 6, x_range=(-2, 5)) #--> input LHS as 'lambda x: {lhs}' and x_range as x_range=(a,b). Value of x_range is optional and default x_range is set to (-20, 20).

visual.graph_equation_3D(1, 1, 1, 0, 10) #--> input values for a, b, c, d and k for LHS as 'ax + by + cz + d = k'.


# class 'other_functions' consists of other required functions that do not fit in either categories of equation solving and visual graphing:

other_functions.testers() # no input, used to test all functions.

other_functions.help() # no input, prints information about functions.

other_functions.equation_classifier(lhs) # input the simplified, standard LHS of an equation to find the type of equation.


## Expected simplified Standard Equation Formats:


Linear:

	One Variable --> ax+b = c

	Two Variable --> ax+by+c = d

	Three Variable --> ax+by+cz+d = e


Quadratic:

	One Variable --> ax^2+bx+c = 0

	Two Variable --> ax^2+bxy+cy^2+dx+ey+f = g


Cubic:

	One Variable --> ax^3+bx^2+cx+d = e


## Expected Output Formats:


Linear:

	One Variable --> 'x = {solution}'

	Two Variable --> 'Solutions = {solutions}' --> 2 Solutions for _bisolution and Custom no. of Solutions for _custom

	Three Variable --> 'Solutions ({plane}): {solutions}' --> Custom no. of Solutions


Quadratic:

	One Variable --> 'x = {solutions}' --> Two solutions

	Two Variable --> 'At x={x_val}, y = {solutions}' --> Two solutions of Y for an input value of X


Cubic

	One Variable --> 'Roots: [{roots}]' --> Three solutions


Have fun using this module to solve equations.