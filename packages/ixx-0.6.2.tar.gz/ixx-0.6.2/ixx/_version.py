# Single source of truth for the IXX version.
# Import this from __main__.py and shell/repl.py — never hardcode VERSION elsewhere.
VERSION = "0.6.2"
