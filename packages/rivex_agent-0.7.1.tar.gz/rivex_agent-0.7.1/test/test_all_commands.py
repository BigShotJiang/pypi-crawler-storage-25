from __future__ import annotations

import argparse
import json
import platform
import subprocess
import sys
import traceback
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Sequence

SCRIPT_DIR = Path(__file__).resolve().parent
LAUNCHER_PATH = SCRIPT_DIR / "agent_launcher.py"
if not LAUNCHER_PATH.exists():
    parent_launcher = SCRIPT_DIR.parent / "agent_launcher.py"
    if parent_launcher.exists():
        LAUNCHER_PATH = parent_launcher

AGENT_DIR = LAUNCHER_PATH.parent
REPO_ROOT = AGENT_DIR.parent.parent
RUNTIME_DIR = AGENT_DIR / ".runtime"
DEFAULT_REPORT_DIR = RUNTIME_DIR / "tests"

VERSION_FILES = [
    AGENT_DIR / "agent_launcher.py",
    AGENT_DIR / "core" / "config_manager.py",
    AGENT_DIR / "config.json",
    AGENT_DIR.parent / "server" / "frontend" / "public" / "agent" / "version.json",
]

RUNTIME_CONFIG_PATH = RUNTIME_DIR / "config.json"


@dataclass
class CaseResult:
    name: str
    status: str
    command: str
    expected_exit_codes: List[int]
    exit_code: int
    duration_ms: int
    notes: List[str]
    stdout: str
    stderr: str


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def clip_text(value: str, max_chars: int = 12000) -> str:
    text = value or ""
    if len(text) <= max_chars:
        return text
    head = text[: max_chars // 2]
    tail = text[-max_chars // 2 :]
    return (
        f"{head}\n\n... output truncated ({len(text)} chars total) ...\n\n{tail}"
    )


def snapshot_files(paths: Sequence[Path]) -> Dict[str, Optional[bytes]]:
    snapshot: Dict[str, Optional[bytes]] = {}
    for path in paths:
        key = str(path)
        if path.exists():
            snapshot[key] = path.read_bytes()
        else:
            snapshot[key] = None
    return snapshot


def restore_files(snapshot: Dict[str, Optional[bytes]]) -> List[str]:
    errors: List[str] = []
    for raw_path, content in snapshot.items():
        path = Path(raw_path)
        try:
            if content is None:
                if path.exists():
                    path.unlink()
                continue
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(content)
        except Exception as exc:
            errors.append(f"{path}: {exc}")
    return errors


def run_command(command: Sequence[str], timeout_seconds: int, cwd: Path) -> tuple[subprocess.CompletedProcess[str], int]:
    started = datetime.now(timezone.utc)
    try:
        completed = subprocess.run(
            list(command),
            cwd=str(cwd),
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout_seconds,
            check=False,
        )
    except subprocess.TimeoutExpired as exc:
        stdout = exc.stdout or ""
        stderr = (exc.stderr or "") + f"\nTIMEOUT after {timeout_seconds}s"
        completed = subprocess.CompletedProcess(
            args=list(command),
            returncode=124,
            stdout=stdout,
            stderr=stderr,
        )
    except Exception as exc:
        completed = subprocess.CompletedProcess(
            args=list(command),
            returncode=125,
            stdout="",
            stderr=f"{type(exc).__name__}: {exc}\n{traceback.format_exc()}",
        )

    duration_ms = int((datetime.now(timezone.utc) - started).total_seconds() * 1000)
    return completed, duration_ms


def parse_json_output(raw: str) -> Optional[Dict[str, Any]]:
    data = (raw or "").strip()
    if not data:
        return None
    try:
        parsed = json.loads(data)
    except json.JSONDecodeError:
        return None
    if isinstance(parsed, dict):
        return parsed
    return None


def check_contains(text: str, expected: Sequence[str]) -> List[str]:
    issues: List[str] = []
    for token in expected:
        if token not in text:
            issues.append(f"Missing token in output: {token}")
    return issues


def check_not_contains(text: str, forbidden: Sequence[str]) -> List[str]:
    issues: List[str] = []
    for token in forbidden:
        if token in text:
            issues.append(f"Unexpected token in output: {token}")
    return issues


def render_text_report(summary: Dict[str, Any], results: List[CaseResult]) -> str:
    lines: List[str] = []
    lines.append("Rivex Agent full CLI self-test report")
    lines.append(f"Generated at: {summary['generated_at']}")
    lines.append(f"Workspace: {summary['workspace']}")
    lines.append(f"Launcher: {summary['launcher_path']}")
    lines.append(f"Python: {summary['python_executable']}")
    lines.append(f"Platform: {summary['platform']}")
    lines.append("")
    lines.append(
        "Totals: "
        f"{summary['total']} total | "
        f"{summary['passed']} passed | "
        f"{summary['failed']} failed | "
        f"{summary['skipped']} skipped"
    )
    lines.append("")

    for case in results:
        lines.append("=" * 88)
        lines.append(f"Case: {case.name}")
        lines.append(f"Status: {case.status}")
        lines.append(f"Command: {case.command}")
        lines.append(f"Exit code: {case.exit_code} (expected: {case.expected_exit_codes})")
        lines.append(f"Duration: {case.duration_ms} ms")
        if case.notes:
            lines.append("Notes:")
            for note in case.notes:
                lines.append(f"- {note}")
        lines.append("STDOUT:")
        lines.append(case.stdout if case.stdout else "<empty>")
        lines.append("STDERR:")
        lines.append(case.stderr if case.stderr else "<empty>")
        lines.append("")

    return "\n".join(lines) + "\n"


def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(
        description="Run a full Rivex-Agent CLI self-test suite and generate copy/paste reports.",
    )
    parser.add_argument("--python", dest="python_executable", default=sys.executable)
    parser.add_argument("--timeout", type=int, default=180)
    parser.add_argument("--report_dir", default=str(DEFAULT_REPORT_DIR))
    parser.add_argument("--server_url", default="", help="Optional. If provided, enroll path is tested.")
    parser.add_argument("--enroll_key", default="", help="Optional enroll key used with --server_url.")
    parser.add_argument("--enroll_comment", default="selftest")
    parser.add_argument("--enroll_tag", default="selftest")
    parser.add_argument(
        "--no_restore",
        action="store_true",
        help="Do not restore modified files at the end (not recommended).",
    )
    args = parser.parse_args(argv)

    if not LAUNCHER_PATH.exists():
        print(f"ERROR: launcher not found at {LAUNCHER_PATH}")
        return 2

    report_dir = Path(args.report_dir)
    report_dir.mkdir(parents=True, exist_ok=True)

    timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    json_report_path = report_dir / f"agent_selftest_{timestamp}.json"
    txt_report_path = report_dir / f"agent_selftest_{timestamp}.txt"
    scan_output_path = report_dir / f"selftest_scan_{timestamp}.json"
    patch_path = report_dir / f"selftest_patch_{timestamp}.json"

    patch_payload = {
        "selftest": {
            "last_run_at": utc_now_iso(),
            "marker": f"selftest-{timestamp}",
        }
    }
    patch_path.write_text(json.dumps(patch_payload, indent=2) + "\n", encoding="utf-8")

    files_to_snapshot = VERSION_FILES + [RUNTIME_CONFIG_PATH]
    snapshots = snapshot_files(files_to_snapshot)

    results: List[CaseResult] = []

    def add_skip(name: str, notes: List[str]) -> None:
        results.append(
            CaseResult(
                name=name,
                status="skipped",
                command="<skipped>",
                expected_exit_codes=[],
                exit_code=0,
                duration_ms=0,
                notes=notes,
                stdout="",
                stderr="",
            )
        )

    def run_case(
        name: str,
        launcher_args: Sequence[str],
        expected_exit_codes: Sequence[int],
        checker: Optional[Callable[[subprocess.CompletedProcess[str]], List[str]]] = None,
    ) -> subprocess.CompletedProcess[str]:
        command = [args.python_executable, str(LAUNCHER_PATH)] + list(launcher_args)
        completed, duration_ms = run_command(command, timeout_seconds=args.timeout, cwd=REPO_ROOT)

        notes: List[str] = []
        if completed.returncode not in expected_exit_codes:
            notes.append(
                f"Unexpected exit code {completed.returncode}; expected {list(expected_exit_codes)}"
            )

        if checker is not None:
            try:
                notes.extend(checker(completed))
            except Exception as exc:
                notes.append(f"Checker error: {exc}")

        status = "passed" if not notes else "failed"
        results.append(
            CaseResult(
                name=name,
                status=status,
                command=" ".join(command),
                expected_exit_codes=list(expected_exit_codes),
                exit_code=completed.returncode,
                duration_ms=duration_ms,
                notes=notes,
                stdout=clip_text(completed.stdout),
                stderr=clip_text(completed.stderr),
            )
        )
        print(f"[{status.upper()}] {name} -> exit {completed.returncode}")
        return completed

    baseline_version = ""

    try:
        run_case(
            name="help_output_hidden_options",
            launcher_args=["--help"],
            expected_exit_codes=[0],
            checker=lambda cp: (
                check_contains(cp.stdout, ["--pull_remote_commands", "--scan", "--update"]) +
                check_not_contains(cp.stdout, ["--bump_version", "--set_version"]) 
            ),
        )

        version_cp = run_case(
            name="version",
            launcher_args=["--version"],
            expected_exit_codes=[0],
            checker=lambda cp: ["Version output is empty"] if not cp.stdout.strip() else [],
        )
        baseline_version = version_cp.stdout.strip()

        run_case("show_config", ["--show_config"], [0])
        run_case("status", ["--status"], [0])
        run_case("diagnostic", ["--diag"], [0])

        run_case(
            name="show_log_path",
            launcher_args=["--show_log_path"],
            expected_exit_codes=[0],
            checker=lambda cp: ["Log path output is empty"] if not cp.stdout.strip() else [],
        )

        run_case(
            name="scan",
            launcher_args=["--scan", "--output", str(scan_output_path)],
            expected_exit_codes=[0],
            checker=lambda _cp: [
                f"Scan output file not found: {scan_output_path}"
            ] if not scan_output_path.exists() else [],
        )

        run_case("score", ["--score"], [0])

        run_case(
            name="patch",
            launcher_args=["--patch", str(patch_path)],
            expected_exit_codes=[0],
            checker=lambda cp: [
                "Patch output missing marker 'patch_applied'"
            ] if "patch_applied" not in cp.stdout else [],
        )

        run_case("local_tag_update", ["--tag", "selftest-local-tag"], [0])

        run_case(
            name="sync",
            launcher_args=["--sync"],
            expected_exit_codes=[0, 1],
        )

        run_case(
            name="pull_remote_commands",
            launcher_args=["--pull_remote_commands"],
            expected_exit_codes=[0, 1],
        )

        run_case(
            name="update",
            launcher_args=["--update"],
            expected_exit_codes=[0, 1],
        )

        run_case(
            name="enable_auto_scan",
            launcher_args=["--enable_auto_scan"],
            expected_exit_codes=[0, 1],
        )

        run_case(
            name="disable_auto_scan",
            launcher_args=["--disable_auto_scan"],
            expected_exit_codes=[0, 1],
        )

        run_case(
            name="bump_version_patch",
            launcher_args=["--bump_version", "patch"],
            expected_exit_codes=[0],
            checker=lambda cp: [
                "bump_version output does not contain updated_files"
            ] if "updated_files" not in cp.stdout else [],
        )

        if baseline_version:
            run_case(
                name="set_version_restore",
                launcher_args=["--bump_version", "patch", "--set_version", baseline_version],
                expected_exit_codes=[0],
            )

            run_case(
                name="version_restored",
                launcher_args=["--version"],
                expected_exit_codes=[0],
                checker=lambda cp: [
                    f"Version mismatch after restore. expected={baseline_version} got={cp.stdout.strip()}"
                ] if cp.stdout.strip() != baseline_version else [],
            )
        else:
            add_skip("set_version_restore", ["Skipped because baseline version could not be read"]) 
            add_skip("version_restored", ["Skipped because baseline version could not be read"]) 

        run_case(
            name="arg_validation_set_version_without_bump",
            launcher_args=["--sync", "--set_version", "1.2.3"],
            expected_exit_codes=[2],
        )

        run_case(
            name="arg_validation_output_without_scan",
            launcher_args=["--status", "--output", "x.json"],
            expected_exit_codes=[2],
        )

        run_case(
            name="arg_validation_url_without_enroll",
            launcher_args=["--status", "--url", "https://example.invalid"],
            expected_exit_codes=[2],
        )

        run_case(
            name="deprecated_alias_removed",
            launcher_args=["--poll_remote_commands"],
            expected_exit_codes=[2],
        )

        if args.server_url.strip():
            enroll_args = [
                "--enroll",
                "--url",
                args.server_url.strip(),
                "--c",
                args.enroll_comment,
                "--tag",
                args.enroll_tag,
            ]
            if args.enroll_key.strip():
                enroll_args.extend(["--enroll_key", args.enroll_key.strip()])

            run_case(
                name="enroll_with_server",
                launcher_args=enroll_args,
                expected_exit_codes=[0],
            )

            run_case(
                name="sync_after_enroll",
                launcher_args=["--sync"],
                expected_exit_codes=[0, 1],
            )

            run_case(
                name="pull_remote_after_enroll",
                launcher_args=["--pull_remote_commands"],
                expected_exit_codes=[0, 1],
            )

            run_case(
                name="unenroll_after_enroll",
                launcher_args=["--unenroll"],
                expected_exit_codes=[0],
            )
        else:
            add_skip(
                "enroll_with_server",
                [
                    "Skipped: no --server_url provided.",
                    "Provide --server_url (and optionally --enroll_key) to test real enroll flow.",
                ],
            )
            add_skip("sync_after_enroll", ["Skipped because enroll_with_server was skipped"]) 
            add_skip("pull_remote_after_enroll", ["Skipped because enroll_with_server was skipped"]) 
            add_skip("unenroll_after_enroll", ["Skipped because enroll_with_server was skipped"]) 

        # Keep local state clean even when enroll tests are skipped.
        run_case("final_unenroll_cleanup", ["--unenroll"], [0])

    finally:
        restore_errors: List[str] = []
        if not args.no_restore:
            restore_errors = restore_files(snapshots)
        else:
            restore_errors = ["Restoration skipped because --no_restore was passed"]

    total = len(results)
    passed = len([r for r in results if r.status == "passed"])
    failed = len([r for r in results if r.status == "failed"])
    skipped = len([r for r in results if r.status == "skipped"])

    summary: Dict[str, Any] = {
        "generated_at": utc_now_iso(),
        "workspace": str(REPO_ROOT),
        "launcher_path": str(LAUNCHER_PATH),
        "python_executable": args.python_executable,
        "platform": f"{platform.system()} {platform.release()} ({platform.machine()})",
        "total": total,
        "passed": passed,
        "failed": failed,
        "skipped": skipped,
        "restore_errors": restore_errors,
        "report_json": str(json_report_path),
        "report_text": str(txt_report_path),
        "cases": [asdict(case) for case in results],
    }

    json_report_path.write_text(
        json.dumps(summary, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )

    txt_report_path.write_text(
        render_text_report(summary, results),
        encoding="utf-8",
    )

    print("\nSelf-test completed.")
    print(f"Summary: total={total}, passed={passed}, failed={failed}, skipped={skipped}")
    print(f"JSON report: {json_report_path}")
    print(f"Text report: {txt_report_path}")
    if restore_errors:
        print("Restore warnings:")
        for item in restore_errors:
            print(f"- {item}")

    return 0 if failed == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
