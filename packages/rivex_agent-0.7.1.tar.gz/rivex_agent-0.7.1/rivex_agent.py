"""Point d entree Python canonique pour `pip install rivex-agent`.

Ce fichier est le **shim PyPI** : il expose `main()` et permet l invocation
`python -m rivex_agent` en plus de la commande CLI `rivex-agent` (installee
par le `[project.scripts]` de `pyproject.toml`).

La logique metier reste entierement dans `agent_launcher.py` pour preserver
100% la compatibilite avec la version portable (`python agent_launcher.py
--scan`, `python agent_launcher.py --install`, etc.) qui continue d etre
livree sous forme de tarball `rivex-agent-latest.tar.gz` via le pipeline
CI/CD existant.
"""

from __future__ import annotations

import sys
from pathlib import Path


_PACKAGE_DIR = Path(__file__).resolve().parent
if str(_PACKAGE_DIR) not in sys.path:
	# Garantit que `import agent_launcher`, `import core.xxx`, `import modules.xxx`
	# resolvent depuis le meme repertoire que ce shim, que l on soit installe
	# via pip (site-packages/) ou en mode portable (src/agent/).
	sys.path.insert(0, str(_PACKAGE_DIR))

from agent_launcher import main  # noqa: E402

__all__ = ["main"]


if __name__ == "__main__":  # pragma: no cover
	raise SystemExit(main())
