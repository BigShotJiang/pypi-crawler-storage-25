# rivex-agent

Agent collecteur multi-plateforme pour la plateforme de surveillance de
posture de securite **Rivex**. Collecte logs systeme, version OS, niveaux de
patchs, ports ouverts, permissions de fichiers sensibles et remonte le tout
vers le serveur central chiffre.

> Composant PMEs : s installe sur chaque machine (serveur Linux ou poste
> Windows) pour alimenter le score de securite en temps reel du dashboard.

## Installation

### A. Via PyPI (recommande pour developpeurs / tests)

```bash
pip install rivex-agent
rivex-agent --version
```

### B. Installation systeme (service au demarrage)

Linux (root requis) :

```bash
pip install rivex-agent
sudo rivex-agent --install
# => /opt/rivex-agent/ + systemd unit + symlink /usr/local/bin/rivex-agent
sudo systemctl status rivex-agent
```

Windows (admin requis) :

```powershell
pip install rivex-agent
rivex-agent --install            # UAC prompt automatique
Get-Service RivexAgent
```

### C. Binaire autonome (sans Python)

Telecharger depuis le dashboard Rivex ou la page releases :

- Linux : `rivex-agent-linux-x86_64`
- Windows : `rivex-agent-windows-x86_64.exe`

Binaires PyInstaller sans dependance externe. Fonctionnement identique a la
version pip.

### D. Mode portable (developpement)

```bash
git clone https://gitlab.com/rivex/pa4a
cd pa4a/src/agent
python agent_launcher.py --version
```

Tous les modes partagent la meme CLI. Seuls les chemins de config / logs
different (voir "Chemins" ci-dessous).

## Commandes principales

| Commande | Description |
|---|---|
| `rivex-agent --enroll --url https://rivex.example.com --c "srv-prod"` | Enregistre l agent sur le serveur |
| `rivex-agent --scan` | Effectue un scan complet et envoie le payload |
| `rivex-agent --sync` | Synchronise l etat avec le serveur |
| `rivex-agent --status` | Affiche l etat local |
| `rivex-agent --diagnostic` | Rapport complet (config, log, deps systeme, etc.) |
| `rivex-agent --install` | Installe comme service systeme (root/admin) |
| `rivex-agent --uninstall [--purge]` | Retire l installation |
| `rivex-agent --install_status` | Etat de l installation (JSON) |
| `rivex-agent --check_system_deps` | Audit des outils OS requis |
| `rivex-agent --install_system_deps` | Installe les outils OS manquants |
| `rivex-agent --check_protection` | Verifie l integrite des fichiers critiques |
| `rivex-agent --patch <source>` | Applique un patch de remediation (file / URL) |
| `rivex-agent --help` | Aide complete groupee par categorie |

## Elevation automatique

Les actions `--install`, `--uninstall`, `--service-run`, `--patch`,
`--install_system_deps`, `--update`, `--set_scan_interval`,
`--enable_auto_scan`, `--disable_auto_scan` declenchent une elevation
automatique :

- Linux : re-exec via `sudo -E`
- Windows : UAC prompt via `ShellExecuteW runas`

Si deja admin, aucune invite n apparait.

## Chemins

| Mode | Config | Runtime | Logs |
|---|---|---|---|
| Portable | `.runtime/config.json` | `.runtime/` | `.runtime/logs/` |
| Installe Linux | `/etc/rivex-agent/config.json` (seed) + `/var/lib/rivex-agent/.runtime/config.json` (live) | `/var/lib/rivex-agent/.runtime/` | `/var/log/rivex-agent/` |
| Installe Windows | `%ProgramData%\Rivex\Agent\config.json` (seed) + `.runtime\config.json` (live) | `%ProgramData%\Rivex\Agent\.runtime\` | `%ProgramData%\Rivex\Agent\logs\` |

## Compatibilite

- Python 3.9 - 3.12
- Linux : Debian / Ubuntu / RHEL / Fedora / Arch (detection auto du gestionnaire
  de paquets avec priorite `apt-get` > `yum` > `pacman` > `dnf`)
- Windows : 10 / 11 / Server 2016+

## Support

Documentation complete : `_agent_explication.md` (FR).
Changelog : `CHANGELOG.md`.
Issues / support : https://gitlab.com/rivex/pa4a/-/issues
