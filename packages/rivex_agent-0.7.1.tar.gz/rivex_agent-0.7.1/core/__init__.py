"""Core runtime package for Rivex-Agent."""
