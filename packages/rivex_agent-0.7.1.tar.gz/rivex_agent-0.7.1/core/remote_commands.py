from __future__ import annotations

import json
from typing import Any, Dict, List
from urllib.parse import urljoin
from urllib.request import Request, urlopen

from core.agent_http_auth import rivex_agent_signature_headers


DEFAULT_PULL_PATH = "/api/agent/commands/pull"
DEFAULT_RESULT_PATH = "/api/agent/commands/result"


def _as_int(value: Any, fallback: int) -> int:
    try:
        parsed = int(value)
    except (TypeError, ValueError):
        return fallback
    if parsed <= 0:
        return fallback
    return parsed


def _resolve_url(server_url: str, explicit_url: str, default_path: str) -> str:
    explicit = str(explicit_url or "").strip()
    if explicit:
        return explicit

    base = str(server_url or "").strip()
    if not base:
        return ""
    return urljoin(base.rstrip("/") + "/", default_path.lstrip("/"))


def _normalize_command_items(payload: Any) -> List[Dict[str, Any]]:
    if isinstance(payload, list):
        return [item for item in payload if isinstance(item, dict)]

    if isinstance(payload, dict):
        for key in ("commands", "items"):
            value = payload.get(key)
            if isinstance(value, list):
                return [item for item in value if isinstance(item, dict)]

        if any(key in payload for key in ("action", "type", "command")):
            return [payload]

    return []


class RemoteCommandClient:
    def __init__(
        self,
        server_url: str,
        pull_url: str = "",
        result_url: str = "",
        auth_token: str = "",
        timeout_seconds: int = 10,
        agent_id: str = "",
        machine_id: str = "",
    ):
        self.pull_url = _resolve_url(server_url, pull_url, DEFAULT_PULL_PATH)
        self.result_url = _resolve_url(server_url, result_url, DEFAULT_RESULT_PATH)
        self.auth_token = str(auth_token or "").strip()
        self.agent_id = str(agent_id or "").strip()
        self.machine_id = str(machine_id or "").strip()
        self.timeout_seconds = _as_int(timeout_seconds, 10)

    def pull_commands(self, agent_payload: Dict[str, Any]) -> Dict[str, Any]:
        if not self.pull_url:
            return {
                "ok": False,
                "reason": "pull_url_not_configured",
                "commands": [],
            }

        raw_response = self._post_json(self.pull_url, agent_payload)
        commands = _normalize_command_items(raw_response)
        return {
            "ok": True,
            "commands": commands,
        }

    def push_results(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        if not self.result_url:
            return {
                "ok": False,
                "reason": "result_url_not_configured",
            }

        _ = self._post_json(self.result_url, payload)
        return {
            "ok": True,
            "submitted": True,
        }

    def _post_json(self, url: str, payload: Dict[str, Any]) -> Any:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "User-Agent": "Rivex-Agent",
        }
        if self.auth_token and self.agent_id and self.machine_id:
            headers.update(
                rivex_agent_signature_headers(
                    "POST",
                    url,
                    body,
                    self.agent_id,
                    self.machine_id,
                    self.auth_token,
                )
            )
        elif self.auth_token:
            headers["Authorization"] = f"Bearer {self.auth_token}"

        request = Request(url, data=body, headers=headers, method="POST")
        with urlopen(request, timeout=self.timeout_seconds) as response:
            raw = response.read().decode("utf-8", errors="replace").strip()

        if not raw:
            return {}

        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            return {"message": raw}
