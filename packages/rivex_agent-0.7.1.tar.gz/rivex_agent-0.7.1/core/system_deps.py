"""Gestion des dependances systeme de l'agent Rivex.

L'agent s'appuie sur des outils externes pour deux familles de fonctionnalites:

- **Planification** (`core/scheduler.py`):
    - Linux: `crontab` (paquet `cron`/`cronie`) OU `systemctl` (fourni par `systemd`).
    - Windows: `schtasks` (toujours present, integre a Windows).

- **Remediation de vulnerabilites** (`core/patch_engine.py`):
    - Linux: `apt-get` / `dnf` / `yum` (gestionnaire de paquets selon distro),
      `ufw` ou `iptables` (firewall), `systemctl` (services).
    - Windows: `winget` ou `choco` (paquets), `netsh` (firewall), `sc` (services).

Ce module cartographie ces dependances, permet de:

- lister l'etat (present / manquant) de chaque outil pour l'OS courant,
- distinguer les outils **obligatoires** (au moins un gestionnaire de paquets
  doit etre present) des outils **optionnels mais recommandes** (ufw, winget...),
- installer automatiquement les paquets manquants sur Linux via le gestionnaire
  de paquets detecte (apt-get / dnf / yum),
- donner des instructions claires a l'operateur sur Windows (winget / choco)
  ou sur les distros ou l'installation automatique n'est pas possible.

Le module ne modifie jamais la configuration de l'agent et n'installe rien sans
demande explicite via la CLI (`--install_system_deps`) ou sans confirmation
cote serveur (action forcee). Sur une machine en production, l'operateur garde
la main.
"""

from __future__ import annotations

import os
import platform
import shutil
import subprocess
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple


# ---------------------------------------------------------------------------
# Gestionnaires de paquets Linux supportes (ordre de priorite)
# ---------------------------------------------------------------------------
#
# La resolution du gestionnaire suit strictement cet ordre:
#   1. apt-get  -> Debian, Ubuntu et derives (Raspbian, Linux Mint...)
#   2. yum      -> RHEL/CentOS 7 (legacy) -- detecte avant dnf car certains
#                  parcs utilisent encore yum comme commande principale
#   3. pacman   -> Arch Linux, Manjaro, EndeavourOS
#   4. dnf      -> Fedora, RHEL 8+, Rocky, AlmaLinux
#
# Si aucun de ces gestionnaires n est detecte, un message explicite est
# retourne a l operateur.

LINUX_PACKAGE_MANAGERS_ORDER: Tuple[str, ...] = ("apt-get", "yum", "pacman", "dnf")


# ---------------------------------------------------------------------------
# Catalogue des dependances
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class SystemDependency:
    """Description d'un outil systeme requis par l'agent.

    - `command`: nom de l'executable (ce qui sera teste via `shutil.which`).
    - `purpose`: description lisible du role de l'outil.
    - `required`: True si l'agent ne peut pas fonctionner sans cet outil OU
      sans un de ses alternatives. Le statut global est calcule au niveau du
      groupe (voir `DEPENDENCY_GROUPS`).
    - `packages`: dictionnaire `gestionnaire_de_paquets -> nom_paquet`.
      Utilise pour l'installation automatique sur Linux.
    - `windows_install_hint`: message pour l'operateur sur Windows quand
      l'outil n'est pas installable automatiquement.
    """

    command: str
    purpose: str
    packages: Dict[str, str] = field(default_factory=dict)
    windows_install_hint: str = ""


# --- Linux ------------------------------------------------------------------
# Sur Linux, on a besoin:
#   * d'un planificateur: cron (via crontab) OU systemd (via systemctl)
#   * d'un gestionnaire de paquets: apt-get OU dnf OU yum
#   * d'un firewall (recommande, non strict): ufw OU iptables
#   * systemctl pour la gestion de services (souvent deja present avec systemd)

LINUX_DEPS: Dict[str, SystemDependency] = {
    "crontab": SystemDependency(
        command="crontab",
        purpose="Planification des scans automatiques (backend cron)",
        packages={
            "apt-get": "cron",
            "yum": "cronie",
            "pacman": "cronie",
            "dnf": "cronie",
        },
    ),
    "systemctl": SystemDependency(
        command="systemctl",
        purpose="Planification systemd + gestion des services (remediation)",
        packages={
            "apt-get": "systemd",
            "yum": "systemd",
            "pacman": "systemd",
            "dnf": "systemd",
        },
    ),
    "apt-get": SystemDependency(
        command="apt-get",
        purpose="Gestionnaire de paquets Debian/Ubuntu (apt)",
        packages={},
    ),
    "yum": SystemDependency(
        command="yum",
        purpose="Gestionnaire de paquets RHEL/CentOS 7 (legacy)",
        packages={},
    ),
    "pacman": SystemDependency(
        command="pacman",
        purpose="Gestionnaire de paquets Arch Linux / Manjaro",
        packages={},
    ),
    "dnf": SystemDependency(
        command="dnf",
        purpose="Gestionnaire de paquets Fedora / RHEL 8+",
        packages={},
    ),
    "ufw": SystemDependency(
        command="ufw",
        purpose="Firewall (fermeture de ports lors d'une remediation)",
        packages={
            "apt-get": "ufw",
            "yum": "ufw",
            "pacman": "ufw",
            "dnf": "ufw",
        },
    ),
    "iptables": SystemDependency(
        command="iptables",
        purpose="Firewall alternatif a ufw (fallback pour close_port)",
        packages={
            "apt-get": "iptables",
            "yum": "iptables",
            "pacman": "iptables",
            "dnf": "iptables",
        },
    ),
}


# --- Windows ----------------------------------------------------------------
# Sur Windows, la plupart des outils sont fournis nativement:
#   * schtasks (Task Scheduler) -> toujours present
#   * netsh (firewall)          -> toujours present
#   * sc (services)             -> toujours present
# Seul le gestionnaire de paquets doit etre confirme:
#   * winget (App Installer)    -> recent (Windows 10 2004+, Windows 11), pas systematique
#   * choco (Chocolatey)        -> alternative, manuel a installer

WINDOWS_DEPS: Dict[str, SystemDependency] = {
    "schtasks": SystemDependency(
        command="schtasks",
        purpose="Planification native Windows (Task Scheduler)",
        windows_install_hint="Outil integre a Windows: si absent, verifier les composants Windows.",
    ),
    "netsh": SystemDependency(
        command="netsh",
        purpose="Firewall Windows (fermeture de ports lors d'une remediation)",
        windows_install_hint="Outil integre a Windows: si absent, installation manuelle requise.",
    ),
    "sc": SystemDependency(
        command="sc",
        purpose="Gestionnaire de services Windows (remediation)",
        windows_install_hint="Outil integre a Windows: si absent, installation manuelle requise.",
    ),
    "winget": SystemDependency(
        command="winget",
        purpose="Gestionnaire de paquets (App Installer) pour update_package",
        windows_install_hint=(
            "Installer 'App Installer' depuis le Microsoft Store "
            "(https://aka.ms/getwinget) ou via la commande PowerShell admin: "
            "Add-AppxPackage -RegisterByFamilyName -MainPackage Microsoft.DesktopAppInstaller_8wekyb3d8bbwe"
        ),
    ),
    "choco": SystemDependency(
        command="choco",
        purpose="Gestionnaire de paquets alternatif a winget pour update_package",
        windows_install_hint=(
            "Installer Chocolatey (PowerShell admin): "
            "Set-ExecutionPolicy Bypass -Scope Process -Force; "
            "iex ((New-Object System.Net.WebClient).DownloadString('https://community.chocolatey.org/install.ps1'))"
        ),
    ),
}


# --- Groupes de dependances -------------------------------------------------
# Chaque groupe represente une capacite. Un groupe est "ok" des qu au moins
# une des commandes listees est presente.

LINUX_GROUPS: Dict[str, Tuple[str, ...]] = {
    "package_manager": LINUX_PACKAGE_MANAGERS_ORDER,  # apt-get, yum, pacman, dnf
    "scheduler":        ("crontab", "systemctl"),
    "firewall":         ("ufw", "iptables"),
    "service_manager":  ("systemctl",),
}

WINDOWS_GROUPS: Dict[str, Tuple[str, ...]] = {
    "package_manager": ("winget", "choco"),
    "scheduler":        ("schtasks",),
    "firewall":         ("netsh",),
    "service_manager":  ("sc",),
}


# ---------------------------------------------------------------------------
# Helpers - elevation de privileges
# ---------------------------------------------------------------------------
#
# Les operations d installation systeme (apt-get install, pacman -Sy, etc.) ne
# peuvent pas s executer sans droits root. Plutot que de laisser la commande
# echouer avec un message obscur ("Permission denied"), on detecte explicitement
# l absence d elevation et on retourne un resultat structure. La CLI, elle, est
# configuree pour relancer automatiquement le processus avec sudo (Linux) ou
# UAC (Windows) -- ce garde-fou est une seconde ligne de defense pour les
# appels directs au module (tests, actions forcees serveur).

def is_elevated() -> bool:
    """Retourne True si le processus dispose des privileges root/admin."""
    system = platform.system().lower()
    if system == "windows":
        try:
            import ctypes
            return bool(ctypes.windll.shell32.IsUserAnAdmin())
        except Exception:
            return False
    try:
        return os.geteuid() == 0  # type: ignore[attr-defined]
    except AttributeError:
        return False


class ElevationRequiredError(PermissionError):
    """Leve quand une operation privilegiee est declenchee sans droits root/admin."""


def ensure_elevated(operation: str) -> None:
    """Leve ElevationRequiredError si le processus n est pas root/admin.

    - Sur Linux, si le processus n est pas `euid == 0`, retourne une erreur
      structuree invitant a relancer avec sudo.
    - Sur Windows, meme verification via `IsUserAnAdmin`.
    """
    if is_elevated():
        return
    system = platform.system().lower()
    hint = "sudo -E python3 ..." if system == "linux" else "run as Administrator (UAC elevation)"
    raise ElevationRequiredError(
        f"Operation '{operation}' requires root/admin privileges. Retry with: {hint}"
    )


# ---------------------------------------------------------------------------
# Helpers generiques
# ---------------------------------------------------------------------------

def _current_platform() -> str:
    system = platform.system().lower()
    if system in {"linux", "windows"}:
        return system
    return system or "unknown"


def _catalog() -> Dict[str, SystemDependency]:
    if _current_platform() == "linux":
        return LINUX_DEPS
    if _current_platform() == "windows":
        return WINDOWS_DEPS
    return {}


def _groups() -> Dict[str, Tuple[str, ...]]:
    if _current_platform() == "linux":
        return LINUX_GROUPS
    if _current_platform() == "windows":
        return WINDOWS_GROUPS
    return {}


def _run(command: List[str], timeout: int = 600) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        command,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=timeout,
        check=False,
    )


def _command_tail(process: subprocess.CompletedProcess[str]) -> Dict[str, Any]:
    return {
        "exit_code": process.returncode,
        "stdout_tail": [line for line in (process.stdout or "").splitlines()[-10:]],
        "stderr_tail": [line for line in (process.stderr or "").splitlines()[-10:]],
    }


# ---------------------------------------------------------------------------
# Detection (lecture seule)
# ---------------------------------------------------------------------------

def check_dependencies() -> Dict[str, Any]:
    """Retourne un rapport complet sur les outils systeme installes.

    Format:
        {
          "platform": "linux" | "windows" | "<autre>",
          "tools": {
              "crontab": {"present": True,  "path": "/usr/bin/crontab", "purpose": "..."},
              "ufw":     {"present": False, "path": None,               "purpose": "..."},
              ...
          },
          "groups": {
              "package_manager": {"ok": True,  "detected": ["apt-get"], "candidates": [...]},
              "scheduler":       {"ok": True,  "detected": ["systemctl","crontab"], ...},
              ...
          },
          "missing": ["ufw"],           # commandes manquantes (informatif)
          "missing_required_groups": [] # groupes critiques sans aucune commande presente
        }
    """

    plat = _current_platform()
    catalog = _catalog()
    groups = _groups()

    tools: Dict[str, Dict[str, Any]] = {}
    missing: List[str] = []
    for name, dep in catalog.items():
        path = shutil.which(dep.command)
        present = bool(path)
        tools[name] = {
            "present": present,
            "path": path,
            "purpose": dep.purpose,
        }
        if not present:
            missing.append(name)

    groups_report: Dict[str, Dict[str, Any]] = {}
    missing_required_groups: List[str] = []
    for group_name, candidates in groups.items():
        detected = [cmd for cmd in candidates if tools.get(cmd, {}).get("present")]
        ok = bool(detected)
        groups_report[group_name] = {
            "ok": ok,
            "detected": detected,
            "candidates": list(candidates),
        }
        if not ok and group_name in {"package_manager", "scheduler"}:
            missing_required_groups.append(group_name)

    return {
        "platform": plat,
        "tools": tools,
        "groups": groups_report,
        "missing": sorted(missing),
        "missing_required_groups": sorted(missing_required_groups),
    }


# ---------------------------------------------------------------------------
# Installation (ecriture, privilegee)
# ---------------------------------------------------------------------------

def resolve_linux_package_manager() -> Optional[str]:
    """Detecte le gestionnaire de paquets Linux actif.

    Ordre de resolution (strict):
        apt-get -> yum -> pacman -> dnf

    Retourne le nom de la commande detectee, ou None si aucun gestionnaire
    connu n est present sur la machine.
    """
    for mgr in LINUX_PACKAGE_MANAGERS_ORDER:
        if shutil.which(mgr):
            return mgr
    return None


def _linux_install_command(manager: str, packages: List[str]) -> List[str]:
    """Retourne la commande d installation adaptee au gestionnaire."""
    if manager == "apt-get":
        # -y: no prompt; install (pas install --only-upgrade, on veut ajouter
        # les paquets manquants).
        return ["apt-get", "install", "-y", *packages]
    if manager == "yum":
        return ["yum", "install", "-y", *packages]
    if manager == "pacman":
        # -S: install ; -y: refresh BDD paquets ; --noconfirm: pas de prompt ;
        # --needed: ne reinstalle pas un paquet deja a jour.
        return ["pacman", "-S", "-y", "--noconfirm", "--needed", *packages]
    if manager == "dnf":
        return ["dnf", "install", "-y", *packages]
    raise ValueError(f"Unsupported Linux package manager: {manager}")


def _linux_update_command(manager: str) -> Optional[List[str]]:
    """Retourne une commande de rafraichissement du cache de paquets (ou None).

    - apt-get: `apt-get update -y` (indispensable sinon les paquets peuvent etre
      introuvables).
    - pacman: `pacman -Sy --noconfirm` (refresh de la BDD sans upgrade complet).
    - yum / dnf: pas d update dedie prealable requis (cache gere auto).
    """
    if manager == "apt-get":
        return ["apt-get", "update", "-y"]
    if manager == "pacman":
        return ["pacman", "-Sy", "--noconfirm"]
    return None


def _install_missing_linux(names: List[str], report: Dict[str, Any]) -> Dict[str, Any]:
    manager = resolve_linux_package_manager()
    if manager is None:
        return {
            "platform": "linux",
            "attempted": False,
            "reason": "unsupported_package_manager",
            "message": (
                "package-manager non pris en charge. "
                "Gestionnaires attendus (ordre de priorite): "
                + " -> ".join(LINUX_PACKAGE_MANAGERS_ORDER)
                + ". Installer manuellement l un d eux (apt, yum, pacman ou dnf) "
                  "puis relancer l agent."
            ),
            "expected_managers": list(LINUX_PACKAGE_MANAGERS_ORDER),
        }

    # Garde-fou d elevation: installer des paquets systeme exige root.
    # Si la CLI a ete relancee avec sudo, is_elevated() est True et on passe.
    try:
        ensure_elevated(f"install_system_deps ({manager})")
    except ElevationRequiredError as exc:
        return {
            "platform": "linux",
            "attempted": False,
            "reason": "elevation_required",
            "manager": manager,
            "message": str(exc),
        }

    packages: List[str] = []
    resolved: List[Dict[str, str]] = []
    unresolved: List[str] = []
    for name in names:
        dep = LINUX_DEPS.get(name)
        if dep is None:
            unresolved.append(name)
            continue
        package = dep.packages.get(manager)
        if not package:
            unresolved.append(name)
            continue
        packages.append(package)
        resolved.append({"tool": name, "package": package})

    if not packages:
        return {
            "platform": "linux",
            "attempted": False,
            "reason": "nothing_to_install",
            "manager": manager,
            "resolved": resolved,
            "unresolved": unresolved,
        }

    update_cmd = _linux_update_command(manager)
    update_result: Optional[Dict[str, Any]] = None
    if update_cmd is not None:
        update_proc = _run(update_cmd, timeout=300)
        update_result = {"command": update_cmd, **_command_tail(update_proc)}

    install_cmd = _linux_install_command(manager, packages)
    install_proc = _run(install_cmd, timeout=900)
    install_result = {"command": install_cmd, **_command_tail(install_proc)}

    post_report = check_dependencies()
    still_missing = [name for name in names if name in post_report["missing"]]

    return {
        "platform": "linux",
        "attempted": True,
        "manager": manager,
        "resolved": resolved,
        "unresolved": unresolved,
        "update": update_result,
        "install": install_result,
        "success": install_proc.returncode == 0 and not still_missing,
        "still_missing": still_missing,
    }


def _install_missing_windows(names: List[str], report: Dict[str, Any]) -> Dict[str, Any]:
    hints: List[Dict[str, str]] = []
    for name in names:
        dep = WINDOWS_DEPS.get(name)
        if dep is None:
            continue
        hints.append({"tool": name, "hint": dep.windows_install_hint})

    # Meme garde-fou qu en Linux: winget installe les paquets sous HKLM ->
    # requiert des droits admin. Sans elevation, on renvoie les hints sans
    # tenter l install.
    try:
        ensure_elevated("install_system_deps (windows)")
    except ElevationRequiredError as exc:
        return {
            "platform": "windows",
            "attempted": False,
            "reason": "elevation_required",
            "message": str(exc),
            "hints": hints,
            "still_missing": list(names),
            "success": False,
        }

    auto_targets = []
    if shutil.which("winget"):
        for name in names:
            if name == "choco":
                auto_targets.append({
                    "tool": "choco",
                    "command": ["winget", "install", "--id", "Chocolatey.Chocolatey", "--silent",
                                "--accept-source-agreements", "--accept-package-agreements"],
                })

    attempts: List[Dict[str, Any]] = []
    for target in auto_targets:
        process = _run(target["command"], timeout=900)
        attempts.append({
            "tool": target["tool"],
            "command": target["command"],
            **_command_tail(process),
            "success": process.returncode == 0,
        })

    post_report = check_dependencies()
    still_missing = [name for name in names if name in post_report["missing"]]

    return {
        "platform": "windows",
        "attempted": bool(attempts),
        "attempts": attempts,
        "hints": hints,
        "still_missing": still_missing,
        "success": bool(attempts) and not still_missing,
    }


def install_missing_dependencies(include_optional: bool = False) -> Dict[str, Any]:
    """Tente d installer les dependances manquantes sur l OS courant.

    - Sur Linux: utilise apt-get / dnf / yum pour installer les paquets
      manquants (cron, ufw, iptables, systemd si vraiment absent).
    - Sur Windows: les outils integres (schtasks/netsh/sc) ne sont pas
      installables via un gestionnaire de paquets; la fonction se contente
      de retourner des instructions pour winget/choco. Si winget est present,
      une tentative d installation de Chocolatey est faite si demandee.
    - Si `include_optional` est False (defaut), seules les dependances des
      groupes critiques (`package_manager`, `scheduler`) sont ciblees quand
      leur groupe est entierement manquant. Cela evite d installer ufw sur
      une machine qui utilise deja iptables par exemple.
    """

    report = check_dependencies()
    plat = report["platform"]

    if plat not in {"linux", "windows"}:
        return {
            "platform": plat,
            "attempted": False,
            "reason": "unsupported_platform",
            "report": report,
        }

    targets: List[str] = []
    if include_optional:
        targets = list(report["missing"])
    else:
        for group_name in report["missing_required_groups"]:
            candidates = report["groups"][group_name]["candidates"]
            for candidate in candidates:
                if candidate in report["missing"]:
                    targets.append(candidate)
        targets = sorted(set(targets))

    if not targets:
        return {
            "platform": plat,
            "attempted": False,
            "reason": "nothing_to_install",
            "include_optional": include_optional,
            "report": report,
        }

    if plat == "linux":
        outcome = _install_missing_linux(targets, report)
    else:
        outcome = _install_missing_windows(targets, report)

    outcome["targets"] = targets
    outcome["include_optional"] = include_optional
    outcome["report_before"] = report
    outcome["report_after"] = check_dependencies()
    return outcome
