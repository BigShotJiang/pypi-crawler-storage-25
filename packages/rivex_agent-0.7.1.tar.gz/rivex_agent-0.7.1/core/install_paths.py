"""Resolution cross-platform des chemins selon le mode d execution.

L agent peut etre lance dans trois contextes :

1. **Portable** (dossier source) : `python src/agent/agent_launcher.py`
   - config + runtime + logs vivent dans `src/agent/.runtime/`
   - c est le mode de developpement historique, qui doit rester fonctionnel
     apres introduction de l installation systeme.

2. **Installe Linux** : `/opt/rivex-agent/lib/agent_launcher.py`
   - code: `/opt/rivex-agent/lib/` (read-only pour le service)
   - config: `/etc/rivex-agent/config.json` (editable)
   - runtime: `/var/lib/rivex-agent/.runtime/`
   - logs: `/var/log/rivex-agent/`

3. **Installe Windows** : `C:\\Program Files\\Rivex\\Agent\\agent_launcher.py`
   - code: `%ProgramFiles%\\Rivex\\Agent\\` (read-only)
   - config + runtime + logs: `%ProgramData%\\Rivex\\Agent\\`

Ce module centralise la detection + la resolution dans un seul endroit pour
eviter la derive entre agent_launcher.py, logger.py, updater.py, etc.
"""

from __future__ import annotations

import os
import platform
from pathlib import Path
from typing import Any, Dict


# ---------------------------------------------------------------------------
# Emplacements canoniques - doivent rester synchronises avec core.system_install
# ---------------------------------------------------------------------------

_LINUX_INSTALL_LIB = Path("/opt/rivex-agent/lib")
_LINUX_CONFIG_DIR = Path("/etc/rivex-agent")
_LINUX_RUNTIME_DIR = Path("/var/lib/rivex-agent/.runtime")
_LINUX_LOG_DIR = Path("/var/log/rivex-agent")


def _windows_install_root() -> Path:
	return Path(os.environ.get("ProgramFiles") or r"C:\Program Files") / "Rivex" / "Agent"


def _windows_data_root() -> Path:
	return Path(os.environ.get("ProgramData") or r"C:\ProgramData") / "Rivex" / "Agent"


# ---------------------------------------------------------------------------
# Detection du mode
# ---------------------------------------------------------------------------


def is_installed_mode(agent_dir: Path) -> bool:
	"""Retourne True si `agent_dir` est le layout installe systeme.

	Utilise par `agent_launcher.py` des l initialisation pour decider ou
	ecrire config / runtime / logs.
	"""
	system = platform.system().lower()
	try:
		resolved = agent_dir.resolve()
	except Exception:
		return False

	if system == "linux":
		try:
			return resolved == _LINUX_INSTALL_LIB.resolve()
		except Exception:
			return False

	if system == "windows":
		try:
			return resolved == _windows_install_root().resolve()
		except Exception:
			return False

	return False


# ---------------------------------------------------------------------------
# Resolution des paths
# ---------------------------------------------------------------------------


def resolve_paths(agent_dir: Path) -> Dict[str, Any]:
	"""Retourne un dict des chemins a utiliser par le launcher.

	Cles retournees :
		- mode: "portable" | "installed_linux" | "installed_windows"
		- template_config_file: seed JSON (lecture seule, config par defaut)
		- runtime_dir: repertoire de travail mutable
		- runtime_config_file: config "vivante" (enrollment state, token, etc.)
		- scan_dir / update_dir: sous-repertoires de runtime
		- log_dir / log_file: chemin ou ecrire le journal
	"""
	if is_installed_mode(agent_dir):
		system = platform.system().lower()
		if system == "linux":
			# Seed /etc/rivex-agent/config.json si present, sinon fallback au
			# config.json embarque dans /opt/rivex-agent/lib/.
			template = _LINUX_CONFIG_DIR / "config.json"
			if not template.exists():
				template = agent_dir / "config.json"
			runtime_dir = _LINUX_RUNTIME_DIR
			return {
				"mode": "installed_linux",
				"template_config_file": template,
				"runtime_dir": runtime_dir,
				"runtime_config_file": runtime_dir / "config.json",
				"scan_dir": runtime_dir / "scans",
				"update_dir": runtime_dir / "updates",
				"log_dir": _LINUX_LOG_DIR,
				"log_file": _LINUX_LOG_DIR / "agent.log",
			}
		if system == "windows":
			data_root = _windows_data_root()
			template = data_root / "config.json"
			if not template.exists():
				template = agent_dir / "config.json"
			runtime_dir = data_root / ".runtime"
			return {
				"mode": "installed_windows",
				"template_config_file": template,
				"runtime_dir": runtime_dir,
				"runtime_config_file": runtime_dir / "config.json",
				"scan_dir": runtime_dir / "scans",
				"update_dir": runtime_dir / "updates",
				"log_dir": data_root / "logs",
				"log_file": data_root / "logs" / "agent.log",
			}

	runtime_dir = agent_dir / ".runtime"
	return {
		"mode": "portable",
		"template_config_file": agent_dir / "config.json",
		"runtime_dir": runtime_dir,
		"runtime_config_file": runtime_dir / "config.json",
		"scan_dir": runtime_dir / "scans",
		"update_dir": runtime_dir / "updates",
		"log_dir": runtime_dir / "logs",
		"log_file": runtime_dir / "logs" / "rivex-agent.log",
	}


def ensure_runtime_dirs(paths: Dict[str, Any]) -> None:
	"""Cree les repertoires runtime (idempotent)."""
	for key in ("runtime_dir", "scan_dir", "update_dir", "log_dir"):
		value = paths.get(key)
		if isinstance(value, Path):
			value.mkdir(parents=True, exist_ok=True)
