"""En-têtes d authentification agent (signature HMAC, sans Bearer en clair)."""

from __future__ import annotations

import hashlib
import hmac
import time
from typing import Dict
from urllib.parse import urlparse


def rivex_agent_signature_headers(
	method: str,
	url: str,
	body_bytes: bytes,
	agent_id: str,
	machine_id: str,
	agent_token: str,
) -> Dict[str, str]:
	"""Calcule X-Rivex-* pour une requête ; doit rester aligné avec le serveur (`agent_service`)."""
	path = urlparse(url).path or "/"
	ts = str(int(time.time()))
	body_hash = hashlib.sha256(body_bytes).hexdigest()
	canonical = (
		f"{str(method or 'GET').upper()}\n{path}\n{ts}\n{body_hash}\n{agent_id}\n{machine_id}"
	).encode("utf-8")
	sig = hmac.new(
		str(agent_token or "").encode("utf-8"),
		canonical,
		hashlib.sha256,
	).hexdigest()
	return {
		"X-Rivex-Agent-Id": str(agent_id or "").strip(),
		"X-Rivex-Machine-Id": str(machine_id or "").strip(),
		"X-Rivex-Timestamp": ts,
		"X-Rivex-Signature": sig,
	}
