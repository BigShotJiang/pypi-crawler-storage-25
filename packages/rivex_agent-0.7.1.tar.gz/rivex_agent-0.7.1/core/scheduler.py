from __future__ import annotations

import platform
import re
import shlex
import subprocess
from pathlib import Path
from typing import Dict, List


DEFAULT_WINDOWS_TASK_NAME = "Rivex-Agent-AutoScan"
DEFAULT_LINUX_CRON_MARKER = "# RIVEX_AGENT_AUTO_SCAN"
DEFAULT_SCAN_COMMAND_ARGS = "--scan"
DEFAULT_LINUX_BACKEND = "cron"
DEFAULT_SYSTEMD_UNIT_PREFIX = "rivex-agent-autoscan"


def _run_command(command: List[str], input_text: str | None = None) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        command,
        input=input_text,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        check=False,
    )


class Scheduler:
    def __init__(
        self,
        python_executable: str,
        launcher_path: Path,
        interval_minutes: int = 30,
        task_name: str = DEFAULT_WINDOWS_TASK_NAME,
        linux_cron_marker: str = DEFAULT_LINUX_CRON_MARKER,
        scan_command_args: str = DEFAULT_SCAN_COMMAND_ARGS,
        linux_backend: str = DEFAULT_LINUX_BACKEND,
        systemd_unit_prefix: str = DEFAULT_SYSTEMD_UNIT_PREFIX,
    ):
        self.python_executable = python_executable
        self.launcher_path = launcher_path
        self.interval_minutes = int(interval_minutes)
        self.task_name = task_name.strip() or DEFAULT_WINDOWS_TASK_NAME
        self.linux_cron_marker = linux_cron_marker.strip() or DEFAULT_LINUX_CRON_MARKER
        self.scan_command_args = scan_command_args.strip() or DEFAULT_SCAN_COMMAND_ARGS
        self.linux_backend = str(linux_backend or DEFAULT_LINUX_BACKEND).strip().lower()
        self.systemd_unit_prefix = self._sanitize_systemd_prefix(systemd_unit_prefix)

        if self.interval_minutes <= 0:
            raise ValueError("interval_minutes must be greater than 0")

    def enable_every_30_minutes(self) -> Dict[str, str]:
        system = platform.system().lower()
        if system == "windows":
            return self._enable_windows_task()
        if system == "linux":
            linux_mode = self._resolve_linux_backend()
            if linux_mode == "systemd":
                if self.linux_backend == "auto":
                    # In auto mode, gracefully fallback to cron if systemd setup fails.
                    try:
                        return self._enable_linux_systemd_timer()
                    except Exception as exc:
                        self._disable_linux_systemd_timer(ignore_missing=True)
                        _ = exc
                        return self._enable_linux_cron()
                return self._enable_linux_systemd_timer()
            return self._enable_linux_cron()
        raise RuntimeError(f"Automatic scheduling is not supported on {system}")

    def disable_every_30_minutes(self) -> Dict[str, str]:
        system = platform.system().lower()
        if system == "windows":
            return self._disable_windows_task()
        if system == "linux":
            if self.linux_backend == "auto":
                systemd_result = self._disable_linux_systemd_timer(ignore_missing=True)
                cron_result = self._disable_linux_cron(ignore_missing=True)
                return {
                    "mode": "linux-auto",
                    "systemd": systemd_result.get("status", "unknown"),
                    "cron": cron_result.get("status", "unknown"),
                }

            linux_mode = self._resolve_linux_backend()
            if linux_mode == "systemd":
                return self._disable_linux_systemd_timer(ignore_missing=False)
            return self._disable_linux_cron(ignore_missing=False)
        raise RuntimeError(f"Automatic scheduling is not supported on {system}")

    def _resolve_linux_backend(self) -> str:
        if self.linux_backend in {"timerd", "systemd", "systemd-timer", "systemd_timer"}:
            return "systemd"
        if self.linux_backend in {"cron", "crontab"}:
            return "cron"
        if self.linux_backend == "auto":
            return "systemd" if self._systemd_user_available() else "cron"
        raise ValueError("scheduler.linux_backend must be one of: auto, cron, systemd")

    def _systemd_user_available(self) -> bool:
        version_check = _run_command(["systemctl", "--user", "--version"])
        if version_check.returncode != 0:
            return False

        env_check = _run_command(["systemctl", "--user", "show-environment"])
        if env_check.returncode != 0:
            return False

        state_check = _run_command(["systemctl", "--user", "is-system-running"])
        if state_check.returncode == 0:
            return True

        state_text = (state_check.stdout or state_check.stderr or "").strip().lower()
        return state_text in {"running", "degraded", "starting", "initializing"}

    def _sanitize_systemd_prefix(self, value: str) -> str:
        normalized = re.sub(r"[^a-zA-Z0-9_.-]+", "-", str(value or "").strip())
        normalized = normalized.strip(".-")
        return normalized or DEFAULT_SYSTEMD_UNIT_PREFIX

    def _build_execution_args(self) -> List[str]:
        args = [str(self.python_executable), str(self.launcher_path)]
        try:
            extra = shlex.split(self.scan_command_args)
        except ValueError:
            extra = [token for token in self.scan_command_args.split(" ") if token]
        args.extend(extra)
        return args

    def _build_linux_cron_command(self) -> str:
        return " ".join(shlex.quote(arg) for arg in self._build_execution_args())

    def _enable_windows_task(self) -> Dict[str, str]:
        run_command = f'"{self.python_executable}" "{self.launcher_path}" {self.scan_command_args}'
        result = _run_command(
            [
                "schtasks",
                "/Create",
                "/SC",
                "MINUTE",
                "/MO",
                str(self.interval_minutes),
                "/TN",
                self.task_name,
                "/TR",
                run_command,
                "/F",
            ]
        )

        if result.returncode != 0:
            raise RuntimeError(result.stderr.strip() or result.stdout.strip() or "Failed to create scheduled task")

        return {
            "mode": "windows-task-scheduler",
            "task_name": self.task_name,
            "interval_minutes": str(self.interval_minutes),
        }

    def _disable_windows_task(self) -> Dict[str, str]:
        result = _run_command(["schtasks", "/Delete", "/TN", self.task_name, "/F"])

        if result.returncode != 0:
            text = (result.stderr or result.stdout or "").lower()
            if "cannot find" in text or "introuvable" in text:
                return {
                    "mode": "windows-task-scheduler",
                    "task_name": self.task_name,
                    "status": "already_disabled",
                }
            raise RuntimeError(result.stderr.strip() or result.stdout.strip() or "Failed to delete scheduled task")

        return {
            "mode": "windows-task-scheduler",
            "task_name": self.task_name,
            "status": "disabled",
        }

    def _build_linux_cron_schedule(self) -> str:
        # For uncommon intervals (e.g. 90), use a minute-level modulo guard.
        if 60 % self.interval_minutes == 0 and self.interval_minutes <= 60:
            if self.interval_minutes == 60:
                return "0 * * * *"
            return f"*/{self.interval_minutes} * * * *"
        return f"* * * * * [ $(((($(date +\\%s))/60)%{self.interval_minutes})) -eq 0 ] &&"

    def _enable_linux_cron(self) -> Dict[str, str]:
        existing = self._read_linux_crontab_lines()
        kept = [line for line in existing if self.linux_cron_marker not in line]
        schedule_prefix = self._build_linux_cron_schedule()
        command = (
            f"{schedule_prefix} "
            f"{self._build_linux_cron_command()} "
            f">/dev/null 2>&1 {self.linux_cron_marker}"
        )
        kept.append(command)
        payload = "\n".join(kept).rstrip() + "\n"

        result = _run_command(["crontab", "-"], input_text=payload)
        if result.returncode != 0:
            raise RuntimeError(result.stderr.strip() or result.stdout.strip() or "Failed to install crontab")

        return {
            "mode": "linux-cron",
            "marker": self.linux_cron_marker,
            "interval_minutes": str(self.interval_minutes),
        }

    def _disable_linux_cron(self, ignore_missing: bool) -> Dict[str, str]:
        existing = self._read_linux_crontab_lines()
        kept = [line for line in existing if self.linux_cron_marker not in line]

        if kept == existing:
            return {
                "mode": "linux-cron",
                "marker": self.linux_cron_marker,
                "status": "already_disabled",
            }

        payload = "\n".join(kept).rstrip()
        if payload:
            payload += "\n"

        result = _run_command(["crontab", "-"], input_text=payload)
        if result.returncode != 0:
            if ignore_missing and self._is_missing_entry_text(result.stderr or result.stdout):
                return {
                    "mode": "linux-cron",
                    "marker": self.linux_cron_marker,
                    "status": "already_disabled",
                }
            raise RuntimeError(result.stderr.strip() or result.stdout.strip() or "Failed to update crontab")

        return {
            "mode": "linux-cron",
            "marker": self.linux_cron_marker,
            "status": "disabled",
        }

    def _systemd_user_dir(self) -> Path:
        return Path.home() / ".config" / "systemd" / "user"

    def _systemd_unit_names(self) -> tuple[str, str]:
        service_unit = f"{self.systemd_unit_prefix}.service"
        timer_unit = f"{self.systemd_unit_prefix}.timer"
        return service_unit, timer_unit

    def _systemd_service_file_path(self) -> Path:
        service_unit, _ = self._systemd_unit_names()
        return self._systemd_user_dir() / service_unit

    def _systemd_timer_file_path(self) -> Path:
        _, timer_unit = self._systemd_unit_names()
        return self._systemd_user_dir() / timer_unit

    def _systemd_quote_arg(self, value: str) -> str:
        escaped = value.replace("\\", "\\\\").replace('"', '\\"')
        return f'"{escaped}"'

    def _build_systemd_execstart(self) -> str:
        return " ".join(self._systemd_quote_arg(arg) for arg in self._build_execution_args())

    def _build_systemd_service_content(self) -> str:
        working_dir = self._systemd_quote_arg(str(self.launcher_path.parent))
        return (
            "[Unit]\n"
            "Description=Rivex-Agent automatic scan service\n\n"
            "[Service]\n"
            "Type=oneshot\n"
            f"WorkingDirectory={working_dir}\n"
            f"ExecStart={self._build_systemd_execstart()}\n"
            "StandardOutput=null\n"
            "StandardError=journal\n"
        )

    def _build_systemd_timer_content(self) -> str:
        _, timer_unit = self._systemd_unit_names()
        service_unit = timer_unit.replace(".timer", ".service")
        return (
            "[Unit]\n"
            "Description=Rivex-Agent automatic scan timer\n\n"
            "[Timer]\n"
            "OnBootSec=1min\n"
            f"OnUnitActiveSec={self.interval_minutes}min\n"
            f"Unit={service_unit}\n"
            "Persistent=true\n\n"
            "[Install]\n"
            "WantedBy=timers.target\n"
        )

    def _run_systemctl_user(self, args: List[str]) -> subprocess.CompletedProcess[str]:
        return _run_command(["systemctl", "--user", *args])

    def _enable_linux_systemd_timer(self) -> Dict[str, str]:
        if not self._systemd_user_available():
            raise RuntimeError("systemd user services are not available on this host")

        user_dir = self._systemd_user_dir()
        user_dir.mkdir(parents=True, exist_ok=True)

        service_path = self._systemd_service_file_path()
        timer_path = self._systemd_timer_file_path()
        service_path.write_text(self._build_systemd_service_content(), encoding="utf-8")
        timer_path.write_text(self._build_systemd_timer_content(), encoding="utf-8")

        service_unit, timer_unit = self._systemd_unit_names()

        daemon_reload = self._run_systemctl_user(["daemon-reload"])
        if daemon_reload.returncode != 0:
            raise RuntimeError(daemon_reload.stderr.strip() or daemon_reload.stdout.strip() or "systemctl daemon-reload failed")

        enable_timer = self._run_systemctl_user(["enable", "--now", timer_unit])
        if enable_timer.returncode != 0:
            raise RuntimeError(enable_timer.stderr.strip() or enable_timer.stdout.strip() or "Failed to enable systemd timer")

        return {
            "mode": "linux-systemd-timer",
            "timer_unit": timer_unit,
            "service_unit": service_unit,
            "interval_minutes": str(self.interval_minutes),
        }

    def _disable_linux_systemd_timer(self, ignore_missing: bool) -> Dict[str, str]:
        if not self._systemd_user_available():
            if ignore_missing:
                return {
                    "mode": "linux-systemd-timer",
                    "status": "already_disabled",
                }
            raise RuntimeError("systemd user services are not available on this host")

        service_unit, timer_unit = self._systemd_unit_names()
        disable_timer = self._run_systemctl_user(["disable", "--now", timer_unit])
        if disable_timer.returncode != 0:
            text = disable_timer.stderr.strip() or disable_timer.stdout.strip()
            if not (ignore_missing or self._is_missing_entry_text(text)):
                raise RuntimeError(text or "Failed to disable systemd timer")

        removed_any = False
        for path in (self._systemd_timer_file_path(), self._systemd_service_file_path()):
            if path.exists():
                path.unlink()
                removed_any = True

        daemon_reload = self._run_systemctl_user(["daemon-reload"])
        if daemon_reload.returncode != 0 and not ignore_missing:
            raise RuntimeError(daemon_reload.stderr.strip() or daemon_reload.stdout.strip() or "systemctl daemon-reload failed")

        return {
            "mode": "linux-systemd-timer",
            "timer_unit": timer_unit,
            "service_unit": service_unit,
            "status": "disabled" if removed_any else "already_disabled",
        }

    def _is_missing_entry_text(self, text: str) -> bool:
        normalized = str(text or "").lower()
        markers = [
            "no such file",
            "not loaded",
            "does not exist",
            "not found",
            "introuvable",
            "no crontab",
        ]
        return any(marker in normalized for marker in markers)

    def _read_linux_crontab_lines(self) -> List[str]:
        result = _run_command(["crontab", "-l"])

        if result.returncode != 0:
            text = (result.stderr or result.stdout or "").lower()
            if "no crontab" in text:
                return []
            raise RuntimeError(result.stderr.strip() or result.stdout.strip() or "Failed to read crontab")

        return [line for line in result.stdout.splitlines() if line.strip()]
