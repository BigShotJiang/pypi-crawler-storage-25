"""Installation systeme de Rivex-Agent (service au demarrage + commande globale).

Ce module gere la transition d une version **portable** (dossier source
executee via `python agent_launcher.py`) vers une installation **systeme**
complete :

- Linux : copie des fichiers vers `/opt/rivex-agent/`, symlink
  `/usr/local/bin/rivex-agent`, unit systemd `/etc/systemd/system/rivex-agent.service`
  active au demarrage via `systemctl enable --now`.
- Windows : copie vers `C:\\Program Files\\Rivex\\Agent\\`, ajout au `PATH`
  systeme, creation d un service natif via `nssm.exe` (mode AutoStart,
  LocalSystem), demarrage automatique au boot.

Apres installation, l agent tourne en arriere-plan avec les droits
root/SYSTEM et la commande `rivex-agent` est accessible a tout utilisateur
non-privilegie.

Les fonctions publiques retournent toutes un dict structure (success,
reason, message, details). En cas d absence de droits root/admin, le
module delegue au garde-fou `core.system_deps.ensure_elevated` qui leve
`ElevationRequiredError`.
"""

from __future__ import annotations

import hashlib
import json
import os
import platform
import re
import shutil
import subprocess
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple


# ---------------------------------------------------------------------------
# Constantes - chemins / noms
# ---------------------------------------------------------------------------

SERVICE_NAME = "rivex-agent"  # Linux systemd unit name (sans .service)
WINDOWS_SERVICE_NAME = "RivexAgent"  # Windows service name (nssm/sc)
WINDOWS_RUNTIME_EXE_NAME = "rivex-agent.exe"  # copie de l exe PyInstaller sous Program Files (service LocalSystem)

# Linux
LINUX_INSTALL_ROOT = Path("/opt/rivex-agent")
LINUX_LIB_DIR = LINUX_INSTALL_ROOT / "lib"
LINUX_BIN_DIR = LINUX_INSTALL_ROOT / "bin"
LINUX_BIN_ENTRY = LINUX_BIN_DIR / "rivex-agent"
LINUX_CONFIG_DIR = Path("/etc/rivex-agent")
LINUX_CONFIG_FILE = LINUX_CONFIG_DIR / "config.json"
LINUX_LOG_DIR = Path("/var/log/rivex-agent")
LINUX_GLOBAL_SYMLINK = Path("/usr/local/bin/rivex-agent")
LINUX_SYSTEMD_UNIT = Path("/etc/systemd/system") / f"{SERVICE_NAME}.service"

# Windows (resolu a l execution : ProgramFiles varie selon la langue de l OS)
def _win_program_files() -> Path:
	return Path(os.environ.get("ProgramFiles") or r"C:\Program Files")


def _win_program_data() -> Path:
	return Path(os.environ.get("ProgramData") or r"C:\ProgramData")


# NSSM - gestionnaire de service leger et public domain.
# On privilegie une copie embarquee (apres PyInstaller --add-binary) ; a defaut
# telechargement avec URL de secours (nssm.cc peut repondre 503) + SHA256.
NSSM_DOWNLOAD_URLS: Tuple[str, ...] = (
	"https://nssm.cc/release/nssm-2.24.zip",
	"https://github.com/fawno/nssm.cc/releases/download/v2.24.1/nssm-v2.24.1-Win64.zip",
)
# Empreintes connues : zip nssm.cc (structure win64/), zip GitHub fawno (racine nssm.exe).
NSSM_ZIP_SHA256_ACCEPTED = frozenset(
	{
		"727d1e42275c605e0f04aba98095c38a8e1e46def453cdffce42869428aa6743",  # nssm.cc
		"be7b3816d1415f3dbc0b07d561fba720da9b41dcaed5d2dd3b4f61a1dddc8b8f",  # ancien zip nssm.cc
		"243ab5617a3d4266a3ce5edec08736b7a64a0de13a66e23f329048d56b177511",  # fawno Win64 release
	}
)
NSSM_EXE_NAME = "nssm.exe"


def _http_download_file(url: str, dest: Path, *, attempts: int = 4) -> None:
	"""Telecharge une URL vers dest avec retries sur erreurs transitoires (503, timeout)."""
	headers = {"User-Agent": "Rivex-Agent/system_install (NSSM bootstrap)"}
	for attempt in range(attempts):
		try:
			req = urllib.request.Request(url, headers=headers, method="GET")
			with urllib.request.urlopen(req, timeout=120) as resp:
				dest.write_bytes(resp.read())
			return
		except urllib.error.HTTPError as exc:
			retryable = exc.code in {408, 429, 500, 502, 503, 504}
			if retryable and attempt < attempts - 1:
				time.sleep(min(2**attempt, 20))
				continue
			raise
		except (urllib.error.URLError, TimeoutError, OSError):
			if attempt < attempts - 1:
				time.sleep(min(2**attempt, 20))
				continue
			raise


def _nssm_zip_member_for_exe(zf: Any) -> Optional[str]:
	"""Retourne le membre zip contenant nssm.exe (layout nssm.cc ou zip plat GitHub)."""
	names = zf.namelist()
	for n in names:
		norm = n.replace("\\", "/")
		if norm.endswith("win64/nssm.exe") or norm.endswith("win32/nssm.exe"):
			return n
	for n in names:
		if n.replace("\\", "/").rstrip("/").split("/")[-1].lower() == NSSM_EXE_NAME.lower():
			return n
	return None


def _extract_nssm_exe_from_zip(archive: Path, tmp_path: Path, install_root: Path, target: Path) -> bool:
	import zipfile

	extract_root = tmp_path / "nssm_extract"
	extract_root.mkdir(parents=True, exist_ok=True)
	with zipfile.ZipFile(archive) as zf:
		member = _nssm_zip_member_for_exe(zf)
		if not member:
			return False
		zf.extract(member, extract_root)
		src = extract_root / member.replace("\\", "/")
		if not src.is_file():
			return False
		install_root.mkdir(parents=True, exist_ok=True)
		shutil.copy2(src, target)
		return True


def _win_append_to_process_path(directory: Path) -> None:
	"""Apres mise a jour Path machine, le processus courant garde souvent l ancien PATH : on ajoute le dossier pour la suite de l install."""
	if _current_platform() != "windows":
		return
	frag = str(directory)
	cur = os.environ.get("Path", "")
	segs = [s for s in cur.split(os.pathsep) if s]
	if frag not in segs:
		os.environ["Path"] = frag if not cur else cur + os.pathsep + frag


def _win_broadcast_environment_change() -> None:
	"""Signale aux applications (Explorer, etc.) que les variables machine ont change."""
	if _current_platform() != "windows":
		return
	try:
		import ctypes

		HWND_BROADCAST = 0xFFFF
		WM_SETTINGCHANGE = 0x001A
		SMTO_ABORTIFHUNG = 0x0002
		result = ctypes.c_ulong()
		ctypes.windll.user32.SendMessageTimeoutW(
			HWND_BROADCAST,
			WM_SETTINGCHANGE,
			0,
			"Environment",
			SMTO_ABORTIFHUNG,
			5000,
			ctypes.byref(result),
		)
	except Exception:
		pass


def _is_pyinstaller_frozen() -> bool:
	"""True si ce processus est un one-file PyInstaller (Linux ou Windows)."""
	return bool(getattr(sys, "frozen", False)) and bool(getattr(sys, "_MEIPASS", None))


def _win_sc_query_service_running(service_name: str) -> bool:
	"""True si sc query indique que le service tourne (RUNNING / etat 4)."""
	try:
		proc = _run(["sc", "query", service_name], timeout=20)
		text = ((proc.stdout or "") + "\n" + (proc.stderr or "")).upper()
	except Exception:
		return False
	if "RUNNING" in text:
		return True
	# Etat numerique 4 = SERVICE_RUNNING (souvent present meme sur OS localise)
	if "STATE" in text and " 4 " in text:
		return True
	return False


def _install_windows_copy_frozen_runtime(install_root: Path, details: Dict[str, Any]) -> Optional[Path]:
	"""Copie l exe PyInstaller en cours vers Program Files pour NSSM (LocalSystem sans acces au dossier utilisateur)."""
	if not _is_pyinstaller_frozen():
		return None
	dest = install_root / WINDOWS_RUNTIME_EXE_NAME
	try:
		src = Path(sys.executable).resolve()
		try:
			if dest.exists() and dest.resolve() == src:
				details["steps"].append({"step": "copy_runtime_exe", "ok": True, "skipped": "same_as_installer"})
				return dest
		except OSError:
			pass
		shutil.copy2(src, dest)
		details["steps"].append({"step": "copy_runtime_exe", "ok": True, "target": str(dest)})
		return dest
	except Exception as exc:
		details["steps"].append({"step": "copy_runtime_exe", "ok": False, "error": str(exc)})
		return None


def _nssm_start_then_verify(nssm_path: Path, service_name: str) -> Dict[str, Any]:
	"""Demarre le service ; en cas d erreur NSSM transitoire, verifie RUNNING via sc query."""
	start_proc = _run([str(nssm_path), "start", service_name], timeout=90)
	tail = _command_tail(start_proc)
	if start_proc.returncode == 0:
		return {"step": "nssm_start", "ok": True, **tail}
	time.sleep(1.0)
	if _win_sc_query_service_running(service_name):
		return {"step": "nssm_start", "ok": True, **tail, "recovered_by_sc_query": True}
	return {"step": "nssm_start", "ok": False, **tail}


# ---------------------------------------------------------------------------
# Helpers de base
# ---------------------------------------------------------------------------


def _current_platform() -> str:
	return platform.system().lower()


def _is_installed_layout(agent_dir: Path) -> bool:
	"""Retourne True si `agent_dir` correspond a un layout deja installe."""
	if _current_platform() == "linux":
		try:
			return agent_dir.resolve() == (LINUX_LIB_DIR).resolve()
		except Exception:
			return False
	if _current_platform() == "windows":
		install_root = _win_program_files() / "Rivex" / "Agent"
		try:
			return agent_dir.resolve() == install_root.resolve()
		except Exception:
			return False
	return False


def _run(
	command: List[str],
	timeout: int = 120,
	input_text: Optional[str] = None,
) -> subprocess.CompletedProcess[str]:
	return subprocess.run(
		command,
		capture_output=True,
		text=True,
		encoding="utf-8",
		errors="replace",
		timeout=timeout,
		input=input_text,
		check=False,
	)


def _command_tail(proc: subprocess.CompletedProcess[str]) -> Dict[str, Any]:
	stdout = (proc.stdout or "").strip()
	stderr = (proc.stderr or "").strip()
	return {
		"exit_code": proc.returncode,
		"stdout_tail": stdout[-400:] if stdout else "",
		"stderr_tail": stderr[-400:] if stderr else "",
	}


def _copy_tree(src: Path, dst: Path) -> None:
	"""Copie `src` vers `dst` en excluant les repertoires temporaires de runtime."""

	def _ignore(_: str, names: List[str]) -> List[str]:
		return [
			n for n in names
			if n in {".runtime", "__pycache__", ".git", "node_modules", ".pytest_cache"}
			or n.endswith(".pyc")
		]

	if dst.exists():
		shutil.rmtree(dst)
	shutil.copytree(src, dst, ignore=_ignore)


# ---------------------------------------------------------------------------
# Linux - systemd + filesystem
# ---------------------------------------------------------------------------


LINUX_UNIT_TEMPLATE = """[Unit]
Description=Rivex Agent - Security posture collector
Documentation=https://rivex.local/docs/agent
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=root
ExecStart={exec_start}
WorkingDirectory={working_dir}
Restart=on-failure
RestartSec=10
StandardOutput=append:{log_dir}/service.log
StandardError=append:{log_dir}/service.err

[Install]
WantedBy=multi-user.target
"""


LINUX_ENTRY_SCRIPT = """#!/usr/bin/env bash
# Wrapper genere par --install. Point d entree global Rivex-Agent.
set -eo pipefail

AGENT_LIB="{lib_dir}"
exec "{python_exe}" "$AGENT_LIB/agent_launcher.py" "$@"
"""

LINUX_ENTRY_SCRIPT_FROZEN = """#!/usr/bin/env bash
# Wrapper genere par --install (binaire PyInstaller). Point d entree global Rivex-Agent.
set -eo pipefail

exec "{python_exe}" "$@"
"""


def _detect_source_dir() -> Path:
	"""Retourne le repertoire source contenant agent_launcher.py / core / modules."""
	# `core/system_install.py` -> `core/` -> parent = `src/agent/`
	return Path(__file__).resolve().parent.parent


def _install_linux(force: bool, source_dir: Path) -> Dict[str, Any]:
	python_exe = sys.executable or "/usr/bin/python3"
	details: Dict[str, Any] = {
		"install_root": str(LINUX_INSTALL_ROOT),
		"systemd_unit": str(LINUX_SYSTEMD_UNIT),
		"global_symlink": str(LINUX_GLOBAL_SYMLINK),
		"config_path": str(LINUX_CONFIG_FILE),
		"log_dir": str(LINUX_LOG_DIR),
		"steps": [],
	}

	if LINUX_LIB_DIR.exists() and not force:
		return {
			"success": False,
			"reason": "already_installed",
			"message": (
				f"Installation existante detectee a {LINUX_INSTALL_ROOT}. "
				f"Utiliser --install --force pour reinstaller."
			),
			"details": details,
		}

	# 1. Structure filesystem
	LINUX_INSTALL_ROOT.mkdir(parents=True, exist_ok=True)
	LINUX_BIN_DIR.mkdir(parents=True, exist_ok=True)
	LINUX_CONFIG_DIR.mkdir(parents=True, exist_ok=True)
	LINUX_LOG_DIR.mkdir(parents=True, exist_ok=True)
	details["steps"].append({"step": "create_dirs", "ok": True})

	# 2. Copie du code de l agent
	_copy_tree(source_dir, LINUX_LIB_DIR)
	# On ne veut pas embarquer le baseline local, il sera regenere par l appelant
	stale_baseline = LINUX_LIB_DIR / "integrity_baseline.json"
	if stale_baseline.exists():
		stale_baseline.unlink()
	details["steps"].append({"step": "copy_code", "ok": True, "target": str(LINUX_LIB_DIR)})

	# 3. Config : deplacee dans /etc/rivex-agent/ (si pas deja presente)
	embedded_config = LINUX_LIB_DIR / "config.json"
	if not LINUX_CONFIG_FILE.exists() and embedded_config.exists():
		shutil.copy2(embedded_config, LINUX_CONFIG_FILE)
		os.chmod(LINUX_CONFIG_FILE, 0o644)
	details["steps"].append({"step": "provision_config", "ok": True})

	# 4. Entry script /opt/rivex-agent/bin/rivex-agent
	if _is_pyinstaller_frozen():
		entry = LINUX_ENTRY_SCRIPT_FROZEN.format(python_exe=python_exe)
	else:
		entry = LINUX_ENTRY_SCRIPT.format(lib_dir=str(LINUX_LIB_DIR), python_exe=python_exe)
	LINUX_BIN_ENTRY.write_text(entry, encoding="utf-8")
	os.chmod(LINUX_BIN_ENTRY, 0o755)
	details["steps"].append({"step": "write_entry_script", "ok": True, "path": str(LINUX_BIN_ENTRY)})

	# 5. Symlink global /usr/local/bin/rivex-agent
	try:
		if LINUX_GLOBAL_SYMLINK.exists() or LINUX_GLOBAL_SYMLINK.is_symlink():
			LINUX_GLOBAL_SYMLINK.unlink()
		LINUX_GLOBAL_SYMLINK.symlink_to(LINUX_BIN_ENTRY)
		details["steps"].append({"step": "global_symlink", "ok": True})
	except OSError as exc:
		details["steps"].append({"step": "global_symlink", "ok": False, "error": str(exc)})

	# 6. Unit file systemd
	unit_content = LINUX_UNIT_TEMPLATE.format(
		exec_start=f"{LINUX_BIN_ENTRY} --service-run",
		working_dir=str(LINUX_INSTALL_ROOT),
		log_dir=str(LINUX_LOG_DIR),
	)
	LINUX_SYSTEMD_UNIT.write_text(unit_content, encoding="utf-8")
	os.chmod(LINUX_SYSTEMD_UNIT, 0o644)
	details["steps"].append({"step": "write_unit", "ok": True, "path": str(LINUX_SYSTEMD_UNIT)})

	# 7. Activation systemd
	daemon_reload = _run(["systemctl", "daemon-reload"], timeout=30)
	details["steps"].append({
		"step": "systemctl_daemon_reload",
		"ok": daemon_reload.returncode == 0,
		**_command_tail(daemon_reload),
	})
	enable_now = _run(["systemctl", "enable", "--now", f"{SERVICE_NAME}.service"], timeout=60)
	details["steps"].append({
		"step": "systemctl_enable_now",
		"ok": enable_now.returncode == 0,
		**_command_tail(enable_now),
	})

	success = enable_now.returncode == 0
	return {
		"success": success,
		"reason": "installed" if success else "systemd_enable_failed",
		"message": (
			f"Rivex-Agent installed at {LINUX_INSTALL_ROOT} and service {SERVICE_NAME}.service enabled."
			if success else
			"Installation completed but systemd enable --now failed. See details.steps."
		),
		"details": details,
	}


def _uninstall_linux(purge: bool) -> Dict[str, Any]:
	details: Dict[str, Any] = {"steps": []}

	if not LINUX_LIB_DIR.exists() and not LINUX_SYSTEMD_UNIT.exists():
		return {
			"success": True,
			"reason": "not_installed",
			"message": "No installation detected on this system.",
			"details": details,
		}

	# Stop + disable service
	stop_proc = _run(["systemctl", "disable", "--now", f"{SERVICE_NAME}.service"], timeout=60)
	details["steps"].append({
		"step": "systemctl_disable_now",
		"ok": stop_proc.returncode == 0,
		**_command_tail(stop_proc),
	})

	# Remove unit + reload
	if LINUX_SYSTEMD_UNIT.exists():
		LINUX_SYSTEMD_UNIT.unlink()
		details["steps"].append({"step": "remove_unit", "ok": True})

	daemon_reload = _run(["systemctl", "daemon-reload"], timeout=30)
	details["steps"].append({
		"step": "systemctl_daemon_reload",
		"ok": daemon_reload.returncode == 0,
		**_command_tail(daemon_reload),
	})

	# Remove symlink + install tree
	if LINUX_GLOBAL_SYMLINK.exists() or LINUX_GLOBAL_SYMLINK.is_symlink():
		LINUX_GLOBAL_SYMLINK.unlink()
		details["steps"].append({"step": "remove_symlink", "ok": True})

	if LINUX_INSTALL_ROOT.exists():
		shutil.rmtree(LINUX_INSTALL_ROOT, ignore_errors=True)
		details["steps"].append({"step": "remove_install_root", "ok": True})

	if purge:
		if LINUX_CONFIG_DIR.exists():
			shutil.rmtree(LINUX_CONFIG_DIR, ignore_errors=True)
			details["steps"].append({"step": "purge_config", "ok": True})
		if LINUX_LOG_DIR.exists():
			shutil.rmtree(LINUX_LOG_DIR, ignore_errors=True)
			details["steps"].append({"step": "purge_logs", "ok": True})
	else:
		details["steps"].append({"step": "keep_config", "ok": True, "path": str(LINUX_CONFIG_FILE)})

	return {
		"success": True,
		"reason": "uninstalled",
		"message": f"Rivex-Agent removed. {'Config purged.' if purge else 'Config kept.'}",
		"details": details,
	}


def _status_linux() -> Dict[str, Any]:
	installed = LINUX_LIB_DIR.exists()
	unit_installed = LINUX_SYSTEMD_UNIT.exists()
	service_state: Optional[str] = None
	service_enabled: Optional[bool] = None

	if unit_installed:
		is_active = _run(["systemctl", "is-active", f"{SERVICE_NAME}.service"], timeout=15)
		service_state = (is_active.stdout or "").strip() or None
		is_enabled = _run(["systemctl", "is-enabled", f"{SERVICE_NAME}.service"], timeout=15)
		service_enabled = (is_enabled.stdout or "").strip() == "enabled"

	return {
		"platform": "linux",
		"installed": installed,
		"install_path": str(LINUX_INSTALL_ROOT) if installed else None,
		"config_path": str(LINUX_CONFIG_FILE) if LINUX_CONFIG_FILE.exists() else None,
		"log_dir": str(LINUX_LOG_DIR) if LINUX_LOG_DIR.exists() else None,
		"service_name": f"{SERVICE_NAME}.service",
		"service_unit_present": unit_installed,
		"service_state": service_state,
		"service_enabled": service_enabled,
		"global_symlink": str(LINUX_GLOBAL_SYMLINK) if LINUX_GLOBAL_SYMLINK.exists() else None,
	}


# ---------------------------------------------------------------------------
# Windows - NSSM + filesystem
# ---------------------------------------------------------------------------


WINDOWS_ENTRY_BATCH = """@echo off
REM Wrapper genere par --install. Point d entree global Rivex-Agent.
set "AGENT_ROOT={install_root}"
"{python_exe}" "%AGENT_ROOT%\\agent_launcher.py" %*
"""

WINDOWS_ENTRY_BATCH_FROZEN = """@echo off
REM Wrapper genere par --install (binaire PyInstaller installe sous Program Files).
set "AGENT_ROOT={install_root}"
"%AGENT_ROOT%\\{runtime_exe}" %*
"""


def _win_paths() -> Dict[str, Path]:
	pf = _win_program_files()
	pd = _win_program_data()
	install_root = pf / "Rivex" / "Agent"
	return {
		"install_root": install_root,
		"config_dir": pd / "Rivex" / "Agent",
		"config_file": pd / "Rivex" / "Agent" / "config.json",
		"log_dir": pd / "Rivex" / "Agent" / "logs",
		"entry_batch": install_root / "rivex-agent.cmd",
		"nssm_local": install_root / NSSM_EXE_NAME,
	}


def _ensure_nssm(paths: Dict[str, Path]) -> Tuple[Optional[Path], Dict[str, Any]]:
	"""Assure la disponibilite de `nssm.exe` dans le repertoire d installation.

	Ordre de resolution :
		1. Copie embarquee dans le binaire PyInstaller (sys._MEIPASS/nssm.exe).
		2. `nssm.exe` adjacent au script (packaging/windows/nssm.exe).
		3. `nssm` dans le PATH systeme.
		4. Telechargement depuis nssm.cc + verification SHA256.
	"""
	info: Dict[str, Any] = {}
	install_root = paths["install_root"]
	target = paths["nssm_local"]

	if target.exists():
		info["source"] = "already_present"
		return target, info

	# 1. PyInstaller bundled
	meipass = getattr(sys, "_MEIPASS", None)
	if meipass:
		bundled = Path(meipass) / NSSM_EXE_NAME
		if bundled.exists():
			install_root.mkdir(parents=True, exist_ok=True)
			shutil.copy2(bundled, target)
			info["source"] = "pyinstaller_bundle"
			return target, info

	# 2. Adjacent au dossier agent (packaging/windows/nssm.exe)
	source_dir = _detect_source_dir()
	adjacent = source_dir / "packaging" / "windows" / NSSM_EXE_NAME
	if adjacent.exists():
		install_root.mkdir(parents=True, exist_ok=True)
		shutil.copy2(adjacent, target)
		info["source"] = "packaging_dir"
		return target, info

	# 3. PATH
	path_nssm = shutil.which("nssm")
	if path_nssm:
		install_root.mkdir(parents=True, exist_ok=True)
		shutil.copy2(path_nssm, target)
		info["source"] = "path"
		return target, info

	# 4. Telechargement (plusieurs URLs + retries ; nssm.cc peut repondre 503)
	try:
		import tempfile

		with tempfile.TemporaryDirectory() as tmp:
			tmp_path = Path(tmp)
			archive = tmp_path / "nssm.zip"
			errors: List[str] = []
			for url in NSSM_DOWNLOAD_URLS:
				try:
					_http_download_file(url, archive)
				except Exception as exc:
					errors.append(f"{url}: {type(exc).__name__}: {exc}")
					continue
				digest = hashlib.sha256(archive.read_bytes()).hexdigest()
				info["downloaded_sha256"] = digest
				info["url_tried"] = url
				if digest.lower() not in {x.lower() for x in NSSM_ZIP_SHA256_ACCEPTED}:
					errors.append(f"{url}: sha256_inattendu:{digest}")
					continue
				if _extract_nssm_exe_from_zip(archive, tmp_path, install_root, target):
					info["source"] = "download"
					return target, info
				errors.append(f"{url}: membre_nssm_exe_introuvable_dans_zip")
			info["source"] = "download_failed_all_urls"
			info["errors"] = errors
			return None, info
	except Exception as exc:
		info["source"] = "download_error"
		info["error"] = f"{type(exc).__name__}: {exc}"
		return None, info


_WIN_MACHINE_ENV_KEY = r"SYSTEM\CurrentControlSet\Control\Session Manager\Environment"


def _win_registry_read_machine_path() -> tuple[str, int]:
	"""Lit Path machine (HKLM) ; retourne (valeur, type winreg)."""
	import winreg

	with winreg.OpenKey(
		winreg.HKEY_LOCAL_MACHINE,
		_WIN_MACHINE_ENV_KEY,
		0,
		winreg.KEY_READ,
	) as key:
		try:
			value, typ = winreg.QueryValueEx(key, "Path")
		except FileNotFoundError:
			return "", winreg.REG_EXPAND_SZ
	return str(value or ""), int(typ)


def _win_registry_write_machine_path(value: str, typ: int) -> None:
	"""Ecrit Path machine (HKLM). Utiliser REG_EXPAND_SZ si c etait le type d origine."""
	import winreg

	out_type = typ if typ in (winreg.REG_SZ, winreg.REG_EXPAND_SZ) else winreg.REG_EXPAND_SZ
	with winreg.OpenKey(
		winreg.HKEY_LOCAL_MACHINE,
		_WIN_MACHINE_ENV_KEY,
		0,
		winreg.KEY_SET_VALUE,
	) as key:
		winreg.SetValueEx(key, "Path", 0, out_type, value)


def _win_path_segment_key(segment: str) -> str:
	"""Cle de comparaison insensible a la casse (Windows)."""
	return os.path.normcase(os.path.normpath(segment.strip()))


def _win_remove_segment_from_machine_path(directory: Path) -> Dict[str, Any]:
	"""Retire un repertoire du Path machine uniquement (pas setx : evite corruption user+machine)."""
	dir_str = str(directory)
	target_key = _win_path_segment_key(dir_str)
	try:
		raw, typ = _win_registry_read_machine_path()
		segments = [
			s.strip()
			for s in raw.split(os.pathsep)
			if s.strip() and _win_path_segment_key(s) != target_key
		]
		new_val = os.pathsep.join(segments)
		_win_registry_write_machine_path(new_val, typ)
		_win_broadcast_environment_change()
		return {"step": "setx_path_remove", "ok": True, "method": "winreg"}
	except Exception as exc:
		return {"step": "setx_path_remove", "ok": False, "error": str(exc), "method": "winreg"}


def _add_to_system_path(directory: Path) -> Dict[str, Any]:
	"""Ajoute `directory` au Path **machine** (HKLM) via le registre (pas setx).

	`setx /M` reprend le Path du processus courant (souvent machine+utilisateur melanges)
	et peut tronquer a 1024 caracteres. Ici on ne modifie que la valeur machine.
	L elevation admin est deja garantie par `ensure_elevated()` avant l install.
	"""
	if _current_platform() != "windows":
		return {"step": "setx_path", "ok": False, "error": "Path machine: Windows uniquement"}
	dir_str = str(directory)
	target_key = _win_path_segment_key(dir_str)
	try:
		raw, typ = _win_registry_read_machine_path()
		segments = [s.strip() for s in raw.split(os.pathsep) if s.strip()]
		if any(_win_path_segment_key(s) == target_key for s in segments):
			return {"step": "setx_path", "ok": True, "skipped": "already_in_machine_path", "method": "winreg"}
		segments.append(dir_str)
		new_val = os.pathsep.join(segments)
		_win_registry_write_machine_path(new_val, typ)
		_win_broadcast_environment_change()
		return {
			"step": "setx_path",
			"ok": True,
			"method": "winreg",
			"added": dir_str,
			"stdout_tail": "Path machine (HKLM) mis a jour.",
			"stderr_tail": "",
			"exit_code": 0,
		}
	except Exception as exc:
		return {"step": "setx_path", "ok": False, "error": str(exc), "method": "winreg"}


def _install_windows(force: bool, source_dir: Path) -> Dict[str, Any]:
	paths = _win_paths()
	python_exe = sys.executable or "python.exe"
	details: Dict[str, Any] = {
		"install_root": str(paths["install_root"]),
		"config_path": str(paths["config_file"]),
		"log_dir": str(paths["log_dir"]),
		"service_name": WINDOWS_SERVICE_NAME,
		"steps": [],
	}

	install_root = paths["install_root"]
	if install_root.exists() and not force:
		return {
			"success": False,
			"reason": "already_installed",
			"message": (
				f"Installation existante detectee a {install_root}. "
				f"Utiliser --install --force pour reinstaller."
			),
			"details": details,
		}

	# 1. Filesystem
	install_root.mkdir(parents=True, exist_ok=True)
	paths["config_dir"].mkdir(parents=True, exist_ok=True)
	paths["log_dir"].mkdir(parents=True, exist_ok=True)
	details["steps"].append({"step": "create_dirs", "ok": True})

	# 2. Copie du code (agent_launcher.py + core/ + modules/ + config.json)
	for entry in source_dir.iterdir():
		if entry.name in {".runtime", "__pycache__", ".git"}:
			continue
		target = install_root / entry.name
		if entry.is_dir():
			if target.exists():
				shutil.rmtree(target)
			shutil.copytree(entry, target, ignore=shutil.ignore_patterns(
				".runtime", "__pycache__", "*.pyc", ".git",
			))
		else:
			shutil.copy2(entry, target)
	details["steps"].append({"step": "copy_code", "ok": True, "target": str(install_root)})

	# 2b. Binaire PyInstaller : copie sous Program Files pour NSSM (LocalSystem ne doit pas dependre du dossier utilisateur).
	frozen_runtime_exe = _install_windows_copy_frozen_runtime(install_root, details)
	if _is_pyinstaller_frozen() and frozen_runtime_exe is None:
		return {
			"success": False,
			"reason": "runtime_copy_failed",
			"message": "Impossible de copier l executable sous Program Files. Verifiez les droits administrateur et l espace disque.",
			"details": details,
		}

	# 3. Config : deplacee dans %PROGRAMDATA%\Rivex\Agent\config.json (si absente)
	embedded_config = install_root / "config.json"
	if not paths["config_file"].exists() and embedded_config.exists():
		shutil.copy2(embedded_config, paths["config_file"])
	details["steps"].append({"step": "provision_config", "ok": True})

	# 4. Wrapper batch (point d entree commande globale)
	if frozen_runtime_exe is not None:
		batch = WINDOWS_ENTRY_BATCH_FROZEN.format(
			install_root=str(install_root),
			runtime_exe=WINDOWS_RUNTIME_EXE_NAME,
		)
	else:
		batch = WINDOWS_ENTRY_BATCH.format(install_root=str(install_root), python_exe=python_exe)
	paths["entry_batch"].write_text(batch, encoding="utf-8")
	details["steps"].append({"step": "write_entry_batch", "ok": True, "path": str(paths["entry_batch"])})

	# 5. Ajout au PATH systeme
	path_step = _add_to_system_path(install_root)
	details["steps"].append(path_step)
	if path_step.get("ok"):
		_win_append_to_process_path(install_root)
		path_step["path_reload_hint"] = (
			"Path machine (HKLM) mis a jour : les processus deja ouverts gardent l ancien Path. "
			"Ouvrez un **nouveau** terminal, ou dans PowerShell : "
			"$env:Path = [Environment]::GetEnvironmentVariable('Path','Machine') + ';' + "
			"[Environment]::GetEnvironmentVariable('Path','User'). "
			"Dans le dossier d installation, PowerShell exige le prefixe .\\ (ex. .\\rivex-agent.exe --status). "
			"WM_SETTINGCHANGE a ete envoye pour rafraichir les autres applications."
		)

	# 6. NSSM
	nssm_path, nssm_info = _ensure_nssm(paths)
	details["steps"].append({"step": "ensure_nssm", "ok": nssm_path is not None, **nssm_info})
	if nssm_path is None:
		return {
			"success": False,
			"reason": "nssm_unavailable",
			"message": (
				"NSSM.exe non disponible. Fournir nssm.exe dans packaging/windows/, "
				"l ajouter au PATH, ou autoriser le telechargement sortant."
			),
			"details": details,
		}

	# 7. Service NSSM (idempotent : remove si existe deja)
	_run([str(nssm_path), "stop", WINDOWS_SERVICE_NAME], timeout=30)
	_run([str(nssm_path), "remove", WINDOWS_SERVICE_NAME, "confirm"], timeout=30)

	if frozen_runtime_exe is not None:
		nssm_application = str(frozen_runtime_exe)
		nssm_arguments: List[str] = ["--service-run"]
	else:
		nssm_application = python_exe
		nssm_arguments = [str(install_root / "agent_launcher.py"), "--service-run"]

	install_service = _run(
		[str(nssm_path), "install", WINDOWS_SERVICE_NAME, nssm_application, *nssm_arguments],
		timeout=60,
	)
	details["steps"].append({
		"step": "nssm_install",
		"ok": install_service.returncode == 0,
		**_command_tail(install_service),
	})

	# Configuration : AutoStart + LocalSystem + logs redirigees
	for nssm_cmd in [
		["set", WINDOWS_SERVICE_NAME, "Start", "SERVICE_AUTO_START"],
		["set", WINDOWS_SERVICE_NAME, "ObjectName", "LocalSystem"],
		["set", WINDOWS_SERVICE_NAME, "AppDirectory", str(install_root)],
		["set", WINDOWS_SERVICE_NAME, "AppStdout", str(paths["log_dir"] / "service.log")],
		["set", WINDOWS_SERVICE_NAME, "AppStderr", str(paths["log_dir"] / "service.err")],
		["set", WINDOWS_SERVICE_NAME, "Description",
		 "Rivex Agent - Security posture collector (auto-start at boot)"],
	]:
		proc = _run([str(nssm_path), *nssm_cmd], timeout=30)
		details["steps"].append({
			"step": "nssm_" + "_".join(nssm_cmd[:2]).lower(),
			"ok": proc.returncode == 0,
			**_command_tail(proc),
		})

	start_step = _nssm_start_then_verify(Path(nssm_path), WINDOWS_SERVICE_NAME)
	details["steps"].append(start_step)
	start_ok = bool(start_step.get("ok"))

	success = install_service.returncode == 0 and start_ok
	# Le PATH machine est dans le registre ; le shell parent (PowerShell/CMD) ne se met pas a jour tout seul.
	if path_step.get("ok"):
		details["path_session_reload"] = {
			"registry_updated": True,
			"why_session_stale": (
				"Windows ne propage pas une modification HKLM Path aux processus deja demarres ; "
				"c est attendu, pas un echec d installation."
			),
			"powershell_reload_this_session": (
				"$env:Path = [Environment]::GetEnvironmentVariable('Path','Machine') + ';' + "
				"[Environment]::GetEnvironmentVariable('Path','User')"
			),
			"or_open_new_terminal": "Nouvelle fenetre PowerShell ou CMD : le PATH est lu depuis le registre au demarrage.",
		}
	return {
		"success": success,
		"reason": "installed" if success else "service_setup_failed",
		"message": (
			f"Rivex-Agent installed at {install_root} and service {WINDOWS_SERVICE_NAME} started."
			if success else
			"Installation completed but NSSM service setup failed. See details.steps."
		),
		"details": details,
	}


def _uninstall_windows(purge: bool) -> Dict[str, Any]:
	paths = _win_paths()
	details: Dict[str, Any] = {"steps": []}

	install_root = paths["install_root"]
	service_present = False
	nssm_path = paths["nssm_local"] if paths["nssm_local"].exists() else None

	# Stop + remove service (tente via nssm, fallback sc)
	if nssm_path is not None:
		_run([str(nssm_path), "stop", WINDOWS_SERVICE_NAME], timeout=30)
		remove = _run([str(nssm_path), "remove", WINDOWS_SERVICE_NAME, "confirm"], timeout=30)
		service_present = True
		details["steps"].append({
			"step": "nssm_remove",
			"ok": remove.returncode == 0,
			**_command_tail(remove),
		})
	else:
		sc_stop = _run(["sc", "stop", WINDOWS_SERVICE_NAME], timeout=30)
		sc_delete = _run(["sc", "delete", WINDOWS_SERVICE_NAME], timeout=30)
		service_present = sc_delete.returncode == 0
		details["steps"].append({
			"step": "sc_delete",
			"ok": sc_delete.returncode == 0,
			**_command_tail(sc_delete),
		})

	if not install_root.exists() and not service_present:
		return {
			"success": True,
			"reason": "not_installed",
			"message": "No installation detected on this system.",
			"details": details,
		}

	# Retrait du Path machine uniquement (best-effort)
	details["steps"].append(_win_remove_segment_from_machine_path(install_root))

	if install_root.exists():
		shutil.rmtree(install_root, ignore_errors=True)
		details["steps"].append({"step": "remove_install_root", "ok": True})

	if purge:
		if paths["config_dir"].exists():
			shutil.rmtree(paths["config_dir"], ignore_errors=True)
			details["steps"].append({"step": "purge_config", "ok": True})
	else:
		details["steps"].append({"step": "keep_config", "ok": True, "path": str(paths["config_file"])})

	return {
		"success": True,
		"reason": "uninstalled",
		"message": f"Rivex-Agent removed. {'Config purged.' if purge else 'Config kept.'}",
		"details": details,
	}


def _status_windows() -> Dict[str, Any]:
	paths = _win_paths()
	installed = paths["install_root"].exists()

	service_state: Optional[str] = None
	query = _run(["sc", "query", WINDOWS_SERVICE_NAME], timeout=15)
	if query.returncode == 0:
		match = re.search(r"STATE\s+:\s+\d+\s+(\w+)", query.stdout or "")
		if match:
			service_state = match.group(1).lower()

	return {
		"platform": "windows",
		"installed": installed,
		"install_path": str(paths["install_root"]) if installed else None,
		"config_path": str(paths["config_file"]) if paths["config_file"].exists() else None,
		"log_dir": str(paths["log_dir"]) if paths["log_dir"].exists() else None,
		"service_name": WINDOWS_SERVICE_NAME,
		"service_state": service_state,
		"entry_batch": str(paths["entry_batch"]) if paths["entry_batch"].exists() else None,
	}


# ---------------------------------------------------------------------------
# API publique
# ---------------------------------------------------------------------------


def install_agent(force: bool = False) -> Dict[str, Any]:
	"""Installe Rivex-Agent sur le systeme (cross-platform).

	Requiert root/admin. En cas d absence d elevation, delegue au garde-fou
	centralise pour un message coherent avec `install_system_deps`.
	"""
	system = _current_platform()
	try:
		from core.system_deps import ensure_elevated
		ensure_elevated("install_agent")
	except PermissionError as exc:
		return {
			"success": False,
			"reason": "elevation_required",
			"message": str(exc),
			"details": {"platform": system},
		}

	source_dir = _detect_source_dir()
	if _is_installed_layout(source_dir) and not force:
		return {
			"success": False,
			"reason": "running_from_installed_layout",
			"message": (
				"L installation est deja en place: --install ne doit pas etre "
				"relance depuis le layout installe. Utiliser --uninstall puis "
				"re-executer depuis la version portable si besoin."
			),
			"details": {"platform": system, "source_dir": str(source_dir)},
		}

	if system == "linux":
		return _install_linux(force=force, source_dir=source_dir)
	if system == "windows":
		return _install_windows(force=force, source_dir=source_dir)
	return {
		"success": False,
		"reason": "unsupported_platform",
		"message": f"--install n est pas supporte sur {system}",
		"details": {"platform": system},
	}


def uninstall_agent(purge: bool = False) -> Dict[str, Any]:
	"""Desinstalle Rivex-Agent (arret service + retrait fichiers)."""
	system = _current_platform()
	try:
		from core.system_deps import ensure_elevated
		ensure_elevated("uninstall_agent")
	except PermissionError as exc:
		return {
			"success": False,
			"reason": "elevation_required",
			"message": str(exc),
			"details": {"platform": system},
		}

	if system == "linux":
		return _uninstall_linux(purge=purge)
	if system == "windows":
		return _uninstall_windows(purge=purge)
	return {
		"success": False,
		"reason": "unsupported_platform",
		"message": f"--uninstall n est pas supporte sur {system}",
		"details": {"platform": system},
	}


def installation_status() -> Dict[str, Any]:
	"""Retourne l etat d installation (lecture seule, sans elevation)."""
	system = _current_platform()
	if system == "linux":
		return _status_linux()
	if system == "windows":
		return _status_windows()
	return {
		"platform": system,
		"installed": False,
		"message": f"Platform {system} not supported for system install.",
	}


def is_running_from_installed_layout() -> bool:
	"""Retourne True si le processus courant s execute depuis l emplacement installe."""
	return _is_installed_layout(_detect_source_dir())
