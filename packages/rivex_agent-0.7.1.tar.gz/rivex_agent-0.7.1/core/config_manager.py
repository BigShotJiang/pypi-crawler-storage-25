from __future__ import annotations

import json
from copy import deepcopy
from pathlib import Path
from typing import Any, Dict, List, Optional


DEFAULT_CONFIG: Dict[str, Any] = {
    "agent_name": "Rivex-Agent",
    "version": "0.7.1",
    "enrolled": False,
    "server_url": "",
    "comment": "",
    "tags": [],
    "agent_uuid": "",
    "agent_token": "",
    "machine_id": "",
    "status": "stopped",
    "last_sync": None,
    "scan": {
        "max_files": 200,
        "file_roots": [],
    },
    "update": {
        "version_url": "",
        "channel": "stable",
        "cleanup_paths": [
            "test_checker",
        ],
    },
    "agent_api": {
        "register_url": "",
        "sync_url": "",
        "me_url": "",
        "commands_pull_url": "",
        "commands_result_url": "",
        "alerts_url": "",
        "timeout_seconds": 15,
        "enroll_key": "",
    },
    "scheduler": {
        "enabled": False,
        "interval_minutes": 30,
        "task_name": "Rivex-Agent-AutoScan",
        "linux_cron_marker": "# RIVEX_AGENT_AUTO_SCAN",
        "scan_command_args": "--scan",
        "linux_backend": "cron",
        "systemd_unit_prefix": "rivex-agent-autoscan",
    },
    "remote_commands": {
        "enabled": True,
        "pull_url": "",
        "result_url": "",
        "auth_token": "",
        "timeout_seconds": 10,
        "max_commands_per_poll": 10,
        "allowed_actions": [
            "scan",
            "sync",
            "status",
            "diag",
            "score",
            "update",
            "reboot",
            "patch",
            "set_scan_interval",
            "enable_auto_scan",
            "disable_auto_scan",
            "tag",
            "check_protection",
            "refresh_protection_baseline",
            "check_system_deps",
            "install_system_deps",
        ],
    },
    "protection": {
        "enabled": True,
        "alert_url": "",
        "alert_timeout_seconds": 10,
        "baseline_auto_refresh_on_update": True,
    },
    "system_deps": {
        "audit_on_diag": True,
        "install_missing_on_enroll": False,
        "install_include_optional": False,
    },
}


def _deep_merge(base: Dict[str, Any], override: Dict[str, Any]) -> Dict[str, Any]:
    merged = deepcopy(base)
    for key, value in override.items():
        if isinstance(value, dict) and isinstance(merged.get(key), dict):
            merged[key] = _deep_merge(merged[key], value)
        else:
            merged[key] = value
    return merged


class ConfigManager:
    def __init__(self, config_path: Path | str):
        self.config_path = Path(config_path)

    def ensure_exists(self) -> None:
        self.config_path.parent.mkdir(parents=True, exist_ok=True)
        if not self.config_path.exists():
            self.save(DEFAULT_CONFIG)

    def load(self) -> Dict[str, Any]:
        self.ensure_exists()
        raw = self.config_path.read_text(encoding="utf-8").strip()
        if not raw:
            self.save(DEFAULT_CONFIG)
            return deepcopy(DEFAULT_CONFIG)

        data = json.loads(raw)
        if not isinstance(data, dict):
            raise ValueError("config.json must contain a JSON object")

        merged = _deep_merge(DEFAULT_CONFIG, data)
        if merged != data:
            self.save(merged)
        return merged

    def save(self, config: Dict[str, Any]) -> None:
        self.config_path.parent.mkdir(parents=True, exist_ok=True)
        self.config_path.write_text(json.dumps(config, indent=2), encoding="utf-8")

    def update_values(self, updates: Dict[str, Any]) -> Dict[str, Any]:
        config = self.load()
        config = _deep_merge(config, updates)
        self.save(config)
        return config

    def enroll(
        self,
        url: str,
        comment: str = "",
        tags: Optional[List[str]] = None,
        agent_uuid: Optional[str] = None,
        agent_token: Optional[str] = None,
        machine_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        config = self.load()
        config["enrolled"] = True
        config["server_url"] = url
        config["comment"] = comment
        config["tags"] = tags or []

        if agent_uuid is not None:
            config["agent_uuid"] = str(agent_uuid).strip()
        if agent_token is not None:
            config["agent_token"] = str(agent_token).strip()
            config.setdefault("remote_commands", {})["auth_token"] = str(agent_token).strip()
        if machine_id is not None:
            config["machine_id"] = str(machine_id).strip()

        self.save(config)
        return config

    def unenroll(self) -> Dict[str, Any]:
        config = self.load()
        config["enrolled"] = False
        config["server_url"] = ""
        config["comment"] = ""
        config["tags"] = []
        config["agent_uuid"] = ""
        config["agent_token"] = ""
        config["machine_id"] = ""
        config.setdefault("remote_commands", {})["auth_token"] = ""
        self.save(config)
        return config

    def set_tags(self, tags: List[str], append: bool = True) -> Dict[str, Any]:
        config = self.load()

        incoming: List[str] = []
        for tag in tags:
            value = str(tag).strip()
            if not value:
                continue
            if value not in incoming:
                incoming.append(value)

        if append:
            existing = [str(tag).strip() for tag in config.get("tags", []) if str(tag).strip()]
            for tag in incoming:
                if tag not in existing:
                    existing.append(tag)
            config["tags"] = existing
        else:
            config["tags"] = incoming

        self.save(config)
        return config
