from __future__ import annotations

import json
import re
import shutil
import tarfile
import tempfile
from pathlib import Path
from typing import Any, Dict, List, Tuple
from urllib.parse import urljoin, urlparse
from urllib.request import Request, urlopen


DEFAULT_LEGACY_CLEANUP_PATHS = (
    "test_checker",
)


def _version_tuple(version: str) -> Tuple[int, int, int]:
    parts = []
    for token in version.split("."):
        digits = []
        for char in token:
            if char.isdigit():
                digits.append(char)
            else:
                break
        parts.append(int("".join(digits) or "0"))
    while len(parts) < 3:
        parts.append(0)
    return tuple(parts[:3])


class Updater:
    def __init__(self, current_version: str, version_url: str = "", timeout: int = 10):
        self.current_version = current_version
        self.version_url = version_url
        self.timeout = timeout

    def fetch_remote_metadata(self) -> Dict[str, Any]:
        if not self.version_url:
            return {}

        request = Request(self.version_url, headers={"User-Agent": "Rivex-Agent"})
        with urlopen(request, timeout=self.timeout) as response:
            payload = response.read().decode("utf-8").strip()

        if not payload:
            return {}

        # Reverse proxies can return an HTML fallback page for missing JSON files.
        # Treat it as "no metadata" instead of parsing noisy content as a version.
        payload_lower = payload.lstrip().lower()
        if payload_lower.startswith("<!doctype html") or payload_lower.startswith("<html"):
            return {}

        try:
            data = json.loads(payload)
        except json.JSONDecodeError:
            data = {"version": payload}

        if isinstance(data, str):
            data = {"version": data}
        if not isinstance(data, dict):
            raise ValueError("Remote version payload must be JSON object or plain version string")
        return data

    def _resolve_download_url(self, download_url: str) -> str:
        value = str(download_url or "").strip()
        if not value:
            return ""

        parsed = urlparse(value)
        if parsed.scheme and parsed.netloc:
            return value

        if self.version_url:
            return urljoin(self.version_url, value)

        return value

    def check_for_update(self) -> Dict[str, Any]:
        metadata = self.fetch_remote_metadata()
        remote_version = str(metadata.get("version", "")).strip()
        download_url = self._resolve_download_url(str(metadata.get("download_url", "")).strip())

        if remote_version and not re.match(r"^\d+(?:\.\d+){0,3}$", remote_version):
            return {
                "update_available": False,
                "local_version": self.current_version,
                "remote_version": None,
                "download_url": None,
                "message": "Remote version format is invalid",
            }

        if not remote_version:
            return {
                "update_available": False,
                "local_version": self.current_version,
                "remote_version": None,
                "download_url": None,
                "message": "No remote version information available",
            }

        update_available = _version_tuple(remote_version) > _version_tuple(self.current_version)
        return {
            "update_available": update_available,
            "local_version": self.current_version,
            "remote_version": remote_version,
            "download_url": download_url or None,
        }

    def prepare_update(self, download_url: str, target_dir: Path | str) -> Dict[str, str]:
        if not download_url:
            raise ValueError("download_url is required")

        resolved_download_url = self._resolve_download_url(download_url)
        parsed_download = urlparse(resolved_download_url)
        if not parsed_download.scheme:
            raise ValueError(f"download_url is not a valid absolute URL: {download_url!r}")

        target_path = Path(target_dir)
        target_path.mkdir(parents=True, exist_ok=True)

        parsed = parsed_download
        file_name = Path(parsed.path).name or "rivex-agent-update.bin"

        staging_dir = Path(tempfile.mkdtemp(prefix="rivex-agent-update-"))
        downloaded_file = staging_dir / file_name
        request = Request(resolved_download_url, headers={"User-Agent": "Rivex-Agent"})

        with urlopen(request, timeout=self.timeout) as response, downloaded_file.open("wb") as output:
            shutil.copyfileobj(response, output)

        planned_target = target_path / file_name
        shutil.copy2(downloaded_file, planned_target)

        return {
            "downloaded_file": str(downloaded_file),
            "planned_target": str(planned_target),
            "staged_file": str(planned_target),
            "message": "Update package downloaded and staged locally",
        }

    def _cleanup_legacy_paths(
        self,
        install_path: Path,
        cleanup_paths: List[str] | None,
    ) -> Dict[str, List[str]]:
        removed: List[str] = []
        failed: List[str] = []

        requested: List[str] = list(DEFAULT_LEGACY_CLEANUP_PATHS)
        if cleanup_paths:
            requested.extend([str(item) for item in cleanup_paths])

        unique_requested: List[str] = []
        for raw_item in requested:
            normalized = str(raw_item or "").strip().replace("\\", "/")
            if not normalized or normalized in {".", "./"}:
                continue
            if normalized not in unique_requested:
                unique_requested.append(normalized)

        for relative_item in unique_requested:
            candidate = (install_path / relative_item).resolve()
            try:
                candidate.relative_to(install_path)
            except ValueError:
                failed.append(f"{relative_item}: unsafe_cleanup_path")
                continue

            if candidate == install_path:
                failed.append(f"{relative_item}: refuses_to_remove_install_root")
                continue
            if candidate.name == ".runtime":
                continue

            if not candidate.exists() and not candidate.is_symlink():
                continue

            try:
                if candidate.is_dir() and not candidate.is_symlink():
                    shutil.rmtree(candidate)
                else:
                    candidate.unlink()
                removed.append(relative_item)
            except Exception as exc:
                failed.append(f"{relative_item}: {exc}")

        return {
            "removed_legacy_paths": removed,
            "failed_legacy_paths": failed,
        }

    def apply_update_package(
        self,
        package_file: Path | str,
        install_dir: Path | str,
        cleanup_paths: List[str] | None = None,
    ) -> Dict[str, Any]:
        package_path = Path(package_file)
        if not package_path.exists():
            raise FileNotFoundError(f"Update package not found: {package_path}")

        install_path = Path(install_dir).resolve()
        extract_dir = Path(tempfile.mkdtemp(prefix="rivex-agent-extract-"))

        try:
            if not tarfile.is_tarfile(package_path):
                raise ValueError("Unsupported update package format (expected tar archive)")

            with tarfile.open(package_path, mode="r:*") as archive:
                extract_root = extract_dir.resolve()
                for member in archive.getmembers():
                    member_path = (extract_dir / member.name).resolve()
                    try:
                        member_path.relative_to(extract_root)
                    except ValueError as exc:
                        raise ValueError(f"Unsafe path in update package: {member.name}") from exc
                archive.extractall(path=extract_dir)

            source_root = extract_dir / "agent"
            if not source_root.exists() or not source_root.is_dir():
                raise ValueError("Update package is invalid: expected top-level 'agent/' directory")

            try:
                shutil.copytree(
                    source_root,
                    install_path,
                    dirs_exist_ok=True,
                    ignore=shutil.ignore_patterns(".runtime", "__pycache__", "*.pyc"),
                )
            except PermissionError as exc:
                raise PermissionError(
                    "Unable to replace local agent files. Close running agent processes and retry --update"
                ) from exc

            cleanup_result = self._cleanup_legacy_paths(install_path, cleanup_paths)
        finally:
            shutil.rmtree(extract_dir, ignore_errors=True)

        return {
            "package_file": str(package_path),
            "installed_to": str(install_path),
            "message": "Update package applied locally. Restart the agent process.",
            **cleanup_result,
        }
