from __future__ import annotations

import argparse
import importlib.util
import json
import os
import platform
import re
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional
from uuid import uuid4
from urllib.error import HTTPError, URLError
from urllib.parse import urljoin, urlparse
from urllib.request import Request, urlopen

# PyInstaller one-file : __file__ pointe vers _MEI... ; le layout installe se deduit de sys.executable.
if getattr(sys, "frozen", False):
	AGENT_DIR = Path(sys.executable).resolve().parent
else:
	AGENT_DIR = Path(__file__).resolve().parent
if str(AGENT_DIR) not in sys.path:
	sys.path.insert(0, str(AGENT_DIR))

from core.agent_http_auth import rivex_agent_signature_headers
from core.config_manager import ConfigManager
from core.logger import get_log_path, get_logger
from core import install_paths as agent_paths
from core import patch_engine
from core import protection as agent_protection
from core import system_deps
from core.remote_commands import RemoteCommandClient
from core.scheduler import Scheduler
from core.updater import Updater

APP_NAME = "Rivex-Agent"
APP_VERSION = "0.7.1"
DEFAULT_REQUIREMENTS = ["psutil==5.9.8"]
DEFAULT_REQUIREMENTS_LINUX = ["psutil==5.9.8"]
DEFAULT_REQUIREMENTS_WINDOWS = ["psutil==5.9.8"]
REQUIREMENTS_FILE = "requirements.txt"
REQUIREMENTS_LINUX_FILE = "requirements-linux.txt"
REQUIREMENTS_WINDOWS_FILE = "requirements-windows.txt"
AGENT_PATHS = agent_paths.resolve_paths(AGENT_DIR)
AGENT_MODE = str(AGENT_PATHS.get("mode", "portable"))
RUNTIME_DIR = AGENT_PATHS["runtime_dir"]
RUNTIME_CONFIG_PATH = AGENT_PATHS["runtime_config_file"]
RUNTIME_SCAN_DIR = AGENT_PATHS["scan_dir"]
RUNTIME_UPDATE_DIR = AGENT_PATHS["update_dir"]
TEMPLATE_CONFIG_PATH = AGENT_PATHS["template_config_file"]
LOG_DIR_OVERRIDE = AGENT_PATHS["log_dir"]
LOG_FILE_OVERRIDE = AGENT_PATHS["log_file"]
RUNTIME_ALWAYS_STATE_KEYS = {
	"agent_uuid",
	"agent_token",
	"machine_id",
	"status",
	"last_sync",
}
RUNTIME_SESSION_STATE_KEYS = {
	"enrolled",
	"server_url",
	"comment",
	"tags",
}
DEFAULT_REMOTE_ALLOWED_ACTIONS = {
	"scan",
	"sync",
	"status",
	"diag",
	"score",
	"update",
	"reboot",
	"patch",
	"set_scan_interval",
	"enable_auto_scan",
	"disable_auto_scan",
	"tag",
	"check_protection",
	"refresh_protection_baseline",
	"check_system_deps",
	"install_system_deps",
}
AGENT_API_DEFAULT_PATHS = {
	"register_url": "/api/agent/register",
	"sync_url": "/api/agent/sync",
	"me_url": "/api/agent/me",
	"commands_pull_url": "/api/agent/commands/pull",
	"commands_result_url": "/api/agent/commands/result",
	"alerts_url": "/api/agent/alerts",
}
SEMVER_RE = re.compile(r"^\d+\.\d+\.\d+$")
FRONTEND_AGENT_VERSION_METADATA_PATH = AGENT_DIR.parent / "server" / "frontend" / "public" / "agent" / "version.json"
MANPAGE_BUNDLE_CANDIDATES = [
	AGENT_DIR / "agent_launcher.py.1",
	AGENT_DIR / "test" / "agent_launcher.py.1",
]
MANPAGE_TARGET_DIR_CANDIDATES = [
	Path.home() / ".local" / "share" / "man" / "man1",
	Path.home() / ".local" / "man" / "man1",
]
MANPAGE_TARGET_PAGE_NAMES = [
	"agent_launcher.py.1",
	"agent_launcher.1",
]
UPDATE_RESTART_GUARD_ENV = "RIVEX_AGENT_UPDATE_RESTARTED"
ELEVATION_REEXEC_GUARD_ENV = "RIVEX_AGENT_ELEVATED_REEXEC"


def _is_valid_semver(value: str) -> bool:
	return bool(SEMVER_RE.match(str(value or "").strip()))


def _parse_semver(value: str) -> tuple[int, int, int]:
	if not _is_valid_semver(value):
		raise ValueError("Version must use semantic format x.y.z")
	parts = [int(token) for token in value.strip().split(".")]
	return parts[0], parts[1], parts[2]


def _bump_semver(value: str, part: str) -> str:
	major, minor, patch = _parse_semver(value)
	bump_part = str(part or "patch").strip().lower()
	if bump_part == "major":
		major += 1
		minor = 0
		patch = 0
	elif bump_part == "minor":
		minor += 1
		patch = 0
	else:
		patch += 1
	return f"{major}.{minor}.{patch}"


def _replace_version_in_text(text: str, pattern: re.Pattern[str], new_version: str) -> tuple[str, str]:
	match = pattern.search(text)
	if not match:
		raise ValueError("Version token not found in target file")
	old_version = match.group(2)

	def _repl(found: re.Match[str]) -> str:
		group4 = found.group(4) if found.lastindex and found.lastindex >= 4 else ""
		return f"{found.group(1)}{new_version}{found.group(3)}{group4}"

	updated = pattern.sub(_repl, text, count=1)
	return old_version, updated


def _update_optional_frontend_agent_version(new_version: str) -> Dict[str, Any] | None:
	if not FRONTEND_AGENT_VERSION_METADATA_PATH.exists():
		return None

	try:
		content = FRONTEND_AGENT_VERSION_METADATA_PATH.read_text(encoding="utf-8")
		payload = json.loads(content)
	except Exception as exc:
		return {
			"path": FRONTEND_AGENT_VERSION_METADATA_PATH.as_posix(),
			"updated": False,
			"reason": f"invalid_json: {exc}",
		}

	if not isinstance(payload, dict):
		return {
			"path": FRONTEND_AGENT_VERSION_METADATA_PATH.as_posix(),
			"updated": False,
			"reason": "invalid_json_object",
		}

	old_version = str(payload.get("version", "") or "").strip()
	payload["version"] = new_version
	FRONTEND_AGENT_VERSION_METADATA_PATH.write_text(
		json.dumps(payload, indent=2, ensure_ascii=False) + "\n",
		encoding="utf-8",
	)
	return {
		"path": FRONTEND_AGENT_VERSION_METADATA_PATH.as_posix(),
		"old_version": old_version,
		"new_version": new_version,
		"updated": old_version != new_version,
	}


def run_version_bump(part: str = "patch", set_version: str = "") -> Dict[str, Any]:
	bump_part = str(part or "patch").strip().lower()
	if bump_part not in {"major", "minor", "patch"}:
		raise ValueError("bump part must be one of: major, minor, patch")

	explicit_version = str(set_version or "").strip()
	if explicit_version and not _is_valid_semver(explicit_version):
		raise ValueError("--set_version must follow semantic format x.y.z")

	current_version = APP_VERSION
	target_version = explicit_version or _bump_semver(current_version, bump_part)

	targets = [
		{
			"path": AGENT_DIR / "agent_launcher.py",
			"pattern": re.compile(r'^(APP_VERSION\s*=\s*")(\d+\.\d+\.\d+)(")(\s*)$', re.MULTILINE),
		},
		{
			"path": AGENT_DIR / "core" / "config_manager.py",
			"pattern": re.compile(r'^(\s*"version"\s*:\s*")(\d+\.\d+\.\d+)(")(\s*,\s*)$', re.MULTILINE),
		},
		{
			"path": AGENT_DIR / "config.json",
			"pattern": re.compile(r'^(\s*"version"\s*:\s*")(\d+\.\d+\.\d+)(")(\s*,\s*)$', re.MULTILINE),
		},
		# pyproject.toml (PyPI package rivex-agent). Version TOML standard :
		#     version = "x.y.z"
		{
			"path": AGENT_DIR / "pyproject.toml",
			"pattern": re.compile(r'^(version\s*=\s*")(\d+\.\d+\.\d+)(")(\s*)$', re.MULTILINE),
		},
	]

	updated_files: List[Dict[str, Any]] = []
	for target in targets:
		path = target["path"]
		if not path.exists():
			raise FileNotFoundError(f"Version target file not found: {path}")

		content = path.read_text(encoding="utf-8")
		old_version, rewritten = _replace_version_in_text(content, target["pattern"], target_version)
		changed = rewritten != content
		if changed:
			path.write_text(rewritten, encoding="utf-8")

		updated_files.append(
			{
				"path": path.as_posix(),
				"old_version": old_version,
				"new_version": target_version,
				"updated": changed,
			}
		)

	metadata_update = _update_optional_frontend_agent_version(target_version)
	if metadata_update is not None:
		updated_files.append(metadata_update)

	return {
		"bump_part": bump_part,
		"from_version": current_version,
		"to_version": target_version,
		"set_version": explicit_version or None,
		"updated_files": updated_files,
	}


def utc_now_iso() -> str:
	return datetime.now(timezone.utc).isoformat()


def ensure_runtime_storage() -> None:
	RUNTIME_DIR.mkdir(parents=True, exist_ok=True)
	RUNTIME_SCAN_DIR.mkdir(parents=True, exist_ok=True)
	RUNTIME_UPDATE_DIR.mkdir(parents=True, exist_ok=True)

	if RUNTIME_CONFIG_PATH.exists():
		return

	template_data: Dict[str, Any] | None = None
	if TEMPLATE_CONFIG_PATH.exists():
		try:
			loaded = json.loads(TEMPLATE_CONFIG_PATH.read_text(encoding="utf-8"))
			if isinstance(loaded, dict):
				template_data = loaded
		except Exception:
			template_data = None

	if template_data is not None:
		RUNTIME_CONFIG_PATH.write_text(json.dumps(template_data, indent=2, ensure_ascii=False), encoding="utf-8")
		return

	ConfigManager(RUNTIME_CONFIG_PATH).ensure_exists()


def _resolve_manpage_bundle_path() -> Optional[Path]:
	for candidate in MANPAGE_BUNDLE_CANDIDATES:
		if candidate.exists():
			return candidate
	return None


def ensure_linux_manpage(logger: Any) -> None:
	if not sys.platform.startswith("linux"):
		return
	bundle_path = _resolve_manpage_bundle_path()
	if bundle_path is None:
		return

	try:
		bundled = bundle_path.read_text(encoding="utf-8")
		installed_targets: List[str] = []
		for target_dir in MANPAGE_TARGET_DIR_CANDIDATES:
			try:
				target_dir.mkdir(parents=True, exist_ok=True)
			except Exception:
				continue

			for page_name in MANPAGE_TARGET_PAGE_NAMES:
				target_path = target_dir / page_name
				current = target_path.read_text(encoding="utf-8") if target_path.exists() else ""
				if current != bundled:
					target_path.write_text(bundled, encoding="utf-8")
				installed_targets.append(target_path.as_posix())

		if installed_targets:
			try:
				subprocess.run(
					["mandb", "-q"],
					capture_output=True,
					text=True,
					encoding="utf-8",
					errors="replace",
					check=False,
				)
			except Exception:
				pass
		else:
			logger.warning("Unable to install local man page into user man paths")
	except Exception as exc:
		logger.warning("Unable to install local man page: %s", exc)


def _read_template_config() -> Dict[str, Any]:
	if not TEMPLATE_CONFIG_PATH.exists():
		return {}

	try:
		loaded = json.loads(TEMPLATE_CONFIG_PATH.read_text(encoding="utf-8"))
	except Exception:
		return {}

	if not isinstance(loaded, dict):
		return {}
	return loaded


def sync_runtime_config_from_template(
	manager: ConfigManager,
	runtime_config: Dict[str, Any],
	preserve_runtime_session: bool = True,
) -> tuple[Dict[str, Any], bool]:
	template_config = _read_template_config()
	if not template_config:
		return runtime_config, False

	synced = json.loads(json.dumps(runtime_config))
	preserved_keys = set(RUNTIME_ALWAYS_STATE_KEYS)
	if preserve_runtime_session:
		preserved_keys.update(RUNTIME_SESSION_STATE_KEYS)

	for key, value in template_config.items():
		if key in preserved_keys:
			continue

		if key == "scheduler" and isinstance(value, dict):
			runtime_scheduler = runtime_config.get("scheduler", {})
			new_scheduler = dict(value)
			if isinstance(runtime_scheduler, dict):
				if "enabled" in runtime_scheduler:
					new_scheduler["enabled"] = runtime_scheduler["enabled"]
				for runtime_key, runtime_value in runtime_scheduler.items():
					if runtime_key not in new_scheduler:
						new_scheduler[runtime_key] = runtime_value
			synced["scheduler"] = new_scheduler
			continue

		if key == "agent_api" and isinstance(value, dict):
			runtime_agent_api = runtime_config.get("agent_api", {})
			new_agent_api = dict(value)
			if preserve_runtime_session and isinstance(runtime_agent_api, dict):
				for runtime_key in (
					"register_url",
					"sync_url",
					"me_url",
					"commands_pull_url",
					"commands_result_url",
					"alerts_url",
					"timeout_seconds",
					"enroll_key",
				):
					if runtime_key in runtime_agent_api and runtime_agent_api[runtime_key] not in (None, ""):
						new_agent_api[runtime_key] = runtime_agent_api[runtime_key]
				for runtime_key, runtime_value in runtime_agent_api.items():
					if runtime_key not in new_agent_api:
						new_agent_api[runtime_key] = runtime_value
			synced["agent_api"] = new_agent_api
			continue

		if key == "protection" and isinstance(value, dict):
			runtime_protection = runtime_config.get("protection", {})
			new_protection = dict(value)
			if preserve_runtime_session and isinstance(runtime_protection, dict):
				# Les reglages runtime (enabled / alert_url / ...) prennent
				# toujours le pas sur le template pour que les decisions
				# d exploitation ne soient pas ecrasees par un sync automatique.
				for runtime_key, runtime_value in runtime_protection.items():
					new_protection[runtime_key] = runtime_value
			synced["protection"] = new_protection
			continue

		if key == "remote_commands" and isinstance(value, dict):
			runtime_remote = runtime_config.get("remote_commands", {})
			new_remote = dict(value)
			if preserve_runtime_session and isinstance(runtime_remote, dict):
				for runtime_key in (
					"enabled",
					"pull_url",
					"result_url",
					"auth_token",
					"timeout_seconds",
					"max_commands_per_poll",
					"allowed_actions",
				):
					if runtime_key in runtime_remote:
						new_remote[runtime_key] = runtime_remote[runtime_key]

				runtime_allowed = runtime_remote.get("allowed_actions", [])
				template_allowed = value.get("allowed_actions", [])
				merged_allowed: List[str] = []

				if isinstance(runtime_allowed, list):
					for item in runtime_allowed:
						action = str(item).strip().lower()
						if action and action not in merged_allowed:
							merged_allowed.append(action)

				if isinstance(template_allowed, list):
					for item in template_allowed:
						action = str(item).strip().lower()
						if action and action not in merged_allowed:
							merged_allowed.append(action)

				if merged_allowed:
					new_remote["allowed_actions"] = merged_allowed

				for runtime_key, runtime_value in runtime_remote.items():
					if runtime_key not in new_remote:
						new_remote[runtime_key] = runtime_value
			synced["remote_commands"] = new_remote
			continue

		synced[key] = value

	for key in preserved_keys:
		if key in runtime_config:
			synced[key] = runtime_config[key]

	if synced != runtime_config:
		manager.save(synced)
		return synced, True
	return runtime_config, False


def _write_requirements_file(path: Path, entries: List[str]) -> None:
	path.write_text("\n".join(entries) + "\n", encoding="utf-8")


def _platform_requirements_info(agent_dir: Path) -> tuple[Path, List[str]]:
	system = platform.system().lower()
	if system == "linux":
		return agent_dir / REQUIREMENTS_LINUX_FILE, DEFAULT_REQUIREMENTS_LINUX
	if system == "windows":
		return agent_dir / REQUIREMENTS_WINDOWS_FILE, DEFAULT_REQUIREMENTS_WINDOWS
	return agent_dir / REQUIREMENTS_FILE, DEFAULT_REQUIREMENTS


def ensure_requirements_file(agent_dir: Path) -> Path:
	fallback_requirements = agent_dir / REQUIREMENTS_FILE
	if not fallback_requirements.exists():
		_write_requirements_file(fallback_requirements, DEFAULT_REQUIREMENTS)

	platform_requirements, defaults = _platform_requirements_info(agent_dir)
	if not platform_requirements.exists():
		_write_requirements_file(platform_requirements, defaults)

	return platform_requirements if platform_requirements.exists() else fallback_requirements


def _normalize_requirement_name(spec: str) -> str:
	name = re.split(r"[<>=!~\[;\s]", spec, maxsplit=1)[0].strip().lower()
	return name


def _module_name_from_requirement(spec: str) -> str:
	package_name = _normalize_requirement_name(spec)
	module_name = package_name.replace("-", "_")
	mapping = {
		"pyyaml": "yaml",
	}
	return mapping.get(package_name, module_name)


def _read_requirements(requirements_path: Path) -> List[str]:
	if not requirements_path.exists():
		return []
	lines = requirements_path.read_text(encoding="utf-8").splitlines()
	specs: List[str] = []
	for line in lines:
		item = line.strip()
		if not item or item.startswith("#"):
			continue
		if item.startswith("-"):
			continue
		specs.append(item)
	return specs


def _is_installed(spec: str) -> bool:
	module_name = _module_name_from_requirement(spec)
	return importlib.util.find_spec(module_name) is not None


def ensure_runtime_dependencies(agent_dir: Path, logger: Any, force_reinstall: bool = False) -> Dict[str, Any]:
	requirements_path = ensure_requirements_file(agent_dir)
	requirements = _read_requirements(requirements_path)
	missing = [spec for spec in requirements if not _is_installed(spec)]
	should_install = bool(force_reinstall or missing)

	if not should_install:
		return {
			"requirements_file": str(requirements_path),
			"installed": [],
			"missing_before_install": [],
			"attempted_install": False,
			"install_reason": "already_satisfied",
			"status": "ok",
		}

	if force_reinstall:
		logger.info("Installing dependencies from requirements.txt (forced refresh)")
	else:
		logger.info("Installing missing dependencies: %s", ", ".join(missing))

	def _run_pip(extra_flags: List[str]) -> subprocess.CompletedProcess[str]:
		return subprocess.run(
			[sys.executable, "-m", "pip", "install", "--disable-pip-version-check", *extra_flags, "-r", str(requirements_path)],
			capture_output=True,
			text=True,
			encoding="utf-8",
			errors="replace",
			check=False,
		)

	process = _run_pip([])

	# Sur Windows, si Python a ete installe pour tous les utilisateurs, pip
	# refuse l installation globale sans elevation. On retente automatiquement
	# avec `--user` pour eviter l echec silencieux du bootstrap dependances.
	if process.returncode != 0:
		error_text = (process.stderr or process.stdout or "").lower()
		retryable_markers = (
			"permission denied",
			"access is denied",
			"could not install",
			"[winerror 5]",
			"winerror 5",
			"externally-managed-environment",
		)
		if any(marker in error_text for marker in retryable_markers):
			logger.info("Retrying pip install with --user after privilege error")
			retry = _run_pip(["--user"])
			if retry.returncode == 0:
				process = retry
			else:
				process = retry if retry.stderr else process

	if process.returncode != 0:
		logger.warning("Dependency installation failed: %s", process.stderr.strip())
		return {
			"requirements_file": str(requirements_path),
			"installed": [],
			"missing_before_install": missing,
			"attempted_install": True,
			"install_reason": "forced_refresh" if force_reinstall else "missing_dependencies",
			"status": "failed",
			"error": process.stderr.strip() or process.stdout.strip() or "Unknown pip error",
		}

	installed = [spec for spec in requirements if _is_installed(spec)]
	return {
		"requirements_file": str(requirements_path),
		"installed": installed,
		"missing_before_install": missing,
		"attempted_install": True,
		"install_reason": "forced_refresh" if force_reinstall else "missing_dependencies",
		"status": "ok",
	}


def _is_windows_admin() -> bool:
	if platform.system().lower() != "windows":
		return False

	try:
		import ctypes

		return bool(ctypes.windll.shell32.IsUserAnAdmin())
	except Exception:
		return False


def _is_process_elevated() -> bool:
	system = platform.system().lower()
	if system == "windows":
		return _is_windows_admin()
	if hasattr(os, "geteuid"):
		return os.geteuid() == 0
	return False


def _requested_privileged_actions(args: argparse.Namespace) -> List[str]:
	"""Liste des actions CLI qui exigent obligatoirement root/admin.

	Toute action presente ici declenche une relance automatique via sudo
	(Linux) ou UAC (Windows) si le processus courant n est pas deja eleve.
	"""
	actions: List[str] = []
	patch_value = str(getattr(args, "patch", "") or "").strip()
	if patch_value:
		# Execute des commandes systeme (apt/yum/pacman/dnf, ufw, systemctl).
		actions.append("patch")
	if bool(getattr(args, "pull_remote_commands", False)):
		# Peut declencher des patches/installations a distance.
		actions.append("pull_remote_commands")
	if bool(getattr(args, "enable_auto_scan", False)):
		# Ecrit dans crontab/systemd/schtasks niveau systeme.
		actions.append("enable_auto_scan")
	if bool(getattr(args, "disable_auto_scan", False)):
		actions.append("disable_auto_scan")
	if getattr(args, "set_scan_interval", None) is not None:
		# Re-applique le scheduler OS si le scan automatique est actif.
		actions.append("set_scan_interval")
	if bool(getattr(args, "update", False)):
		# Ecrit les fichiers de l agent (souvent root-owned en production).
		actions.append("update")
	if bool(getattr(args, "install_system_deps", False)):
		actions.append("install_system_deps")
	if bool(getattr(args, "install_system_deps_all", False)):
		actions.append("install_system_deps_all")
	if bool(getattr(args, "install", False)):
		# Ecrit dans /opt/, /etc/, /usr/local/bin/, /etc/systemd/ (Linux) ou
		# C:\Program Files\, HKLM PATH, services Windows.
		actions.append("install")
	if bool(getattr(args, "uninstall", False)):
		# Arrete le service + retrait des fichiers installes (proteges).
		actions.append("uninstall")
	if bool(getattr(args, "service_run", False)):
		# Point d entree du service: doit tourner avec les droits du demon
		# (root sur Linux, LocalSystem sur Windows).
		actions.append("service_run")
	return actions


def _relaunch_with_elevation(raw_args: List[str]) -> Dict[str, Any]:
	system = platform.system().lower()
	script_path = str(Path(__file__).resolve())
	command = [sys.executable, script_path, *raw_args]

	if system == "linux":
		sudo_executable = shutil.which("sudo")
		if not sudo_executable:
			raise RuntimeError("sudo is required to run this command as root on Linux")

		env = os.environ.copy()
		env[ELEVATION_REEXEC_GUARD_ENV] = "1"
		elevated_command = [sudo_executable, "-E", *command]
		result = subprocess.run(
			elevated_command,
			cwd=str(AGENT_DIR),
			env=env,
			check=False,
		)
		return {
			"attempted": True,
			"platform": "linux",
			"command": elevated_command,
			"exit_code": result.returncode,
		}

	if system == "windows":
		try:
			import ctypes
		except Exception as exc:
			raise RuntimeError(f"Unable to request Windows elevation: {exc}") from exc

		parameters = subprocess.list2cmdline([script_path, *raw_args])
		result = ctypes.windll.shell32.ShellExecuteW(
			None,
			"runas",
			sys.executable,
			parameters,
			str(AGENT_DIR),
			1,
		)
		if int(result) <= 32:
			raise RuntimeError(f"Windows elevation failed or was cancelled (code={int(result)})")
		return {
			"attempted": True,
			"platform": "windows",
			"command": command,
			"spawned": True,
		}

	raise RuntimeError(f"Automatic privilege elevation is not supported on {system}")


def build_parser() -> argparse.ArgumentParser:
	parser = argparse.ArgumentParser(
		prog="rivex-agent",
		description="Rivex-Agent multiplatform collector launcher",
		formatter_class=argparse.RawDescriptionHelpFormatter,
		epilog=(
			"Notes on argument relationships:\n"
			"  * Primary actions below are mutually exclusive (pick exactly one).\n"
			"  * Enrollment options (--url, --c, --enroll_key) require --enroll.\n"
			"  * --tag may be used alone (local tag update) or combined with --enroll.\n"
			"  * --output / -o is only valid with --scan.\n"
			"  * --enroll_key used alone implicitly triggers --enroll (URL/comment prompted).\n"
			"  * On Linux, a man page is installed at ~/.local/share/man/man1/ (use: man agent_launcher.py).\n"
			"\n"
			"Examples:\n"
			"  rivex-agent --enroll --url https://controller.local --enroll_key KEY --tag prod --c 'first enroll'\n"
			"  rivex-agent --scan -o scan.json\n"
			"  rivex-agent --tag urgent   # update local tags without re-enrolling\n"
			"  rivex-agent --patch https://controller.local/api/patches/PTCH-2026-0001.json\n"
			"  rivex-agent --check_protection\n"
			"  rivex-agent --refresh_protection_baseline\n"
		),
	)

	primary = parser.add_argument_group(
		"Primary actions (mutually exclusive)",
		"Exactly one of these actions drives the agent run. Without any primary action, --help is shown.",
	)
	primary_group = primary.add_mutually_exclusive_group(required=False)
	primary_group.add_argument("-v", "--version", action="store_true", help="Show agent version")
	primary_group.add_argument(
		"--enroll",
		action="store_true",
		help="Enroll the agent (see 'Enrollment options' below for related flags)",
	)
	primary_group.add_argument("--unenroll", action="store_true", help="Unenroll the agent")
	primary_group.add_argument("--show_config", action="store_true", help="Print local config JSON")
	primary_group.add_argument("--update", action="store_true", help="Check, download and apply update")
	primary_group.add_argument(
		"--bump_version",
		nargs="?",
		const="patch",
		choices=["major", "minor", "patch"],
		metavar="PART",
		help=argparse.SUPPRESS,
	)
	primary_group.add_argument("--sync", action="store_true", help="Force synchronization")
	primary_group.add_argument("--status", action="store_true", help="Show agent status")
	primary_group.add_argument(
		"--diag",
		"--diagnostic",
		dest="diagnostic",
		action="store_true",
		help="Run diagnostics",
	)
	primary_group.add_argument("--show_log_path", action="store_true", help="Show log file path")
	primary_group.add_argument(
		"--scan",
		action="store_true",
		help="Run immediate scan (see 'Scan options' below for --output)",
	)
	primary_group.add_argument(
		"--enable_auto_scan",
		action="store_true",
		help="Enable automatic scan using scheduler.interval_minutes from config",
	)
	primary_group.add_argument(
		"--disable_auto_scan",
		action="store_true",
		help="Disable automatic scheduled scan",
	)
	primary_group.add_argument(
		"--set_scan_interval",
		type=int,
		metavar="MINUTES",
		help="Change the automatic scan interval (in minutes). Re-applies the OS-level scheduler if it is currently enabled.",
	)
	primary_group.add_argument(
		"--patch",
		nargs="?",
		const="",
		metavar="SOURCE",
		help=(
			"Apply a corrective patch JSON from a local file path or an http(s) URL. "
			"Expected Phase 2 format: {\"vulnerabilities\": [{...}]} (update_package, "
			"close_port, disable_service). Legacy config-merge JSON is still supported "
			"for backward compatibility but deprecated."
		),
	)
	primary_group.add_argument("--score", action="store_true", help="Compute health score")
	primary_group.add_argument(
		"--pull_remote_commands",
		action="store_true",
		help="Pull remote forced commands from server and execute allowed actions",
	)
	primary_group.add_argument(
		"--check_protection",
		action="store_true",
		help="Verify agent files integrity against local baseline and alert the server if tampering is detected",
	)
	primary_group.add_argument(
		"--refresh_protection_baseline",
		action="store_true",
		help="Rebuild the local integrity baseline of critical agent files (use after a legitimate update)",
	)
	primary_group.add_argument(
		"--check_system_deps",
		action="store_true",
		help=(
			"Audit OS-level tools required by the agent (cron, ufw, iptables, systemctl, "
			"schtasks, netsh, sc, winget, choco, apt-get/dnf/yum). Read-only; reports what "
			"is present and what is missing."
		),
	)
	primary_group.add_argument(
		"--install_system_deps",
		action="store_true",
		help=(
			"Install missing OS-level tools required by the agent. On Linux: apt-get/dnf/yum. "
			"On Windows: integrated tools cannot be installed automatically; the command prints "
			"the exact command to run for winget/choco. Requires root/admin privileges."
		),
	)
	primary_group.add_argument(
		"--install_system_deps_all",
		action="store_true",
		help=argparse.SUPPRESS,
	)
	primary_group.add_argument(
		"--install",
		action="store_true",
		help=(
			"Install the agent system-wide (root/admin required). "
			"Linux: /opt/rivex-agent/ + systemd service enabled at boot. "
			"Windows: %%PROGRAMFILES%%/Rivex/Agent/ + NSSM service (AutoStart, LocalSystem). "
			"After install, the 'rivex-agent' command is available to any user."
		),
	)
	primary_group.add_argument(
		"--uninstall",
		action="store_true",
		help=(
			"Uninstall the agent from the system (root/admin required). "
			"Stops the service, removes installed files, keeps config by default. "
			"Use --purge to also remove /etc/rivex-agent/ (Linux) or %%PROGRAMDATA%%/Rivex/Agent/ (Windows)."
		),
	)
	primary_group.add_argument(
		"--install_status",
		action="store_true",
		help="Report the current installation status (read-only). JSON output.",
	)
	primary_group.add_argument(
		"--service-run",
		dest="service_run",
		action="store_true",
		help=argparse.SUPPRESS,
	)

	install_options = parser.add_argument_group(
		"Install options (require --install or --uninstall)",
		"Modifiers applied on top of --install / --uninstall.",
	)
	install_options.add_argument(
		"--force",
		action="store_true",
		help="With --install: reinstall over an existing installation.",
	)
	install_options.add_argument(
		"--purge",
		action="store_true",
		help="With --uninstall: also remove /etc/rivex-agent/ (Linux) or %%PROGRAMDATA%%/Rivex/Agent/ (Windows).",
	)

	enroll_options = parser.add_argument_group(
		"Enrollment options (require --enroll, except --tag)",
		"Modifiers applied on top of --enroll. --tag is the only one also usable alone to update local tags.",
	)
	enroll_options.add_argument(
		"--url",
		help="Server URL for agent registration. Requires --enroll.",
	)
	enroll_options.add_argument(
		"--c",
		dest="comment",
		default="",
		help="Enrollment comment attached to the machine. Requires --enroll.",
	)
	enroll_options.add_argument(
		"--enroll_key",
		default="",
		help=(
			"Enrollment key: either the server global key (AGENT_ENROLL_KEY) or the "
			"per-machine key from the admin API/UI. Implicitly triggers --enroll when used alone. "
			"If the agent is already enrolled locally, this option is required to re-enroll "
			"(e.g. after revocation on the server); use the machine-specific key to avoid duplicates."
		),
	)
	enroll_options.add_argument(
		"--tag",
		action="append",
		default=[],
		help=(
			"Tag to attach to the agent. With --enroll: included in the enrollment payload. "
			"Without any other primary action: updates local tags only."
		),
	)

	scan_options = parser.add_argument_group(
		"Scan options (require --scan)",
		"Modifiers applied on top of --scan.",
	)
	scan_options.add_argument(
		"-o",
		"--output",
		dest="output_file",
		help="Write scan payload to this file path. Requires --scan.",
	)

	version_options = parser.add_argument_group(
		"Version maintenance (internal)",
		"Helpers used during release workflows. Normally not invoked by end users.",
	)
	version_options.add_argument("--set_version", default="", help=argparse.SUPPRESS)

	return parser


def validate_args(parser: argparse.ArgumentParser, args: argparse.Namespace) -> None:
	bump_version_value = getattr(args, "bump_version", None)
	set_version_value = str(getattr(args, "set_version", "") or "")

	primary_actions = [
		args.version,
		args.enroll,
		args.unenroll,
		args.show_config,
		args.update,
		bump_version_value is not None,
		args.sync,
		args.status,
		args.diagnostic,
		args.show_log_path,
		args.scan,
		args.enable_auto_scan,
		args.disable_auto_scan,
		args.set_scan_interval is not None,
		args.patch is not None,
		args.score,
		args.pull_remote_commands,
		args.check_protection,
		args.refresh_protection_baseline,
		args.check_system_deps,
		args.install_system_deps,
		args.install_system_deps_all,
		getattr(args, "install", False),
		getattr(args, "uninstall", False),
		getattr(args, "install_status", False),
		getattr(args, "service_run", False),
	]
	has_primary_action = any(primary_actions)

	# Raccourci : `--enroll_key <clé>` (éventuellement combiné avec --url / --c /
	# --tag) déclenche implicitement l'enrôlement. Evite à l'utilisateur de
	# devoir saisir `--enroll --enroll_key <clé>`.
	if not has_primary_action and args.enroll_key:
		args.enroll = True
		has_primary_action = True

	if not has_primary_action and not args.tag:
		parser.print_help()
		raise SystemExit(0)

	if args.tag and has_primary_action and not args.enroll:
		parser.error("--tag can only be used alone or with --enroll")

	if args.url and not args.enroll:
		parser.error("--url can only be used with --enroll")
	if args.comment and not args.enroll:
		parser.error("--c can only be used with --enroll")
	if set_version_value and bump_version_value is None:
		parser.error("--set_version can only be used with --bump_version")
	if set_version_value and not _is_valid_semver(set_version_value):
		parser.error("--set_version must follow semantic format x.y.z")
	if args.output_file and not args.scan:
		parser.error("--output can only be used with --scan")
	if args.set_scan_interval is not None and args.set_scan_interval <= 0:
		parser.error("--set_scan_interval must be a positive integer (minutes)")


def _interactive_input(prompt: str, default: str = "") -> str:
	label = f"{prompt} [{default}]" if default else prompt
	try:
		value = input(f"{label}: ").strip()
	except EOFError:
		return default
	return value or default


def _prompt_enroll_values(args: argparse.Namespace) -> tuple[str, str, List[str]]:
	url_value = (args.url or "").strip()
	while True:
		if not url_value:
			url_value = _interactive_input("Server URL (http/https)")

		parsed = urlparse(url_value)
		if parsed.scheme in ("http", "https") and parsed.netloc:
			break

		print("Invalid URL. Example: https://controller.local")
		url_value = ""

	comment_value = args.comment if args.comment else _interactive_input("Comment (optional)", "")

	tags = [str(tag).strip() for tag in (args.tag or []) if str(tag).strip()]
	if not tags:
		tags_raw = _interactive_input("Tags (optional, comma-separated)", "")
		if tags_raw:
			tags = [item.strip() for item in tags_raw.split(",") if item.strip()]

	unique_tags: List[str] = []
	for tag in tags:
		if tag not in unique_tags:
			unique_tags.append(tag)

	return url_value, comment_value, unique_tags


def _safe_timeout(value: Any, fallback: int = 15) -> int:
	try:
		parsed = int(value)
	except (TypeError, ValueError):
		return fallback
	if parsed <= 0:
		return fallback
	return parsed


def _agent_api_config(config: Dict[str, Any]) -> Dict[str, Any]:
	agent_api = config.get("agent_api", {})
	if not isinstance(agent_api, dict):
		agent_api = {}

	merged: Dict[str, Any] = {
		"timeout_seconds": _safe_timeout(agent_api.get("timeout_seconds", 15), 15),
		"enroll_key": str(agent_api.get("enroll_key", "") or "").strip(),
	}
	for key, default_path in AGENT_API_DEFAULT_PATHS.items():
		value = str(agent_api.get(key, "") or "").strip()
		merged[key] = value
		merged[f"{key}_default_path"] = default_path
	return merged


def _resolve_agent_api_url(config: Dict[str, Any], endpoint_key: str) -> str:
	agent_api = _agent_api_config(config)
	explicit = str(agent_api.get(endpoint_key, "") or "").strip()
	if explicit:
		return explicit

	server_url = str(config.get("server_url", "") or "").strip()
	if not server_url:
		return ""

	default_path = str(agent_api.get(f"{endpoint_key}_default_path", "") or "").strip()
	if not default_path:
		return ""

	return urljoin(server_url.rstrip("/") + "/", default_path.lstrip("/"))


class AgentHttpError(RuntimeError):
	def __init__(self, status_code: int, url: str, message: str, response_body: str = ""):
		super().__init__(f"HTTP {status_code} for {url}: {message}")
		self.status_code = int(status_code)
		self.url = url
		self.response_body = response_body


def _request_json(
	url: str,
	method: str,
	payload: Dict[str, Any],
	timeout_seconds: int,
	extra_headers: Optional[Dict[str, str]] = None,
	*,
	sign_as_agent: Optional[tuple[str, str, str]] = None,
) -> Dict[str, Any]:
	if not url:
		raise RuntimeError("Agent API URL is not configured")

	headers = {
		"Content-Type": "application/json",
		"Accept": "application/json",
		"User-Agent": APP_NAME,
	}
	if extra_headers:
		for hk, hv in extra_headers.items():
			if sign_as_agent and hk.lower() == "authorization":
				continue
			headers[hk] = hv

	body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
	if sign_as_agent:
		agent_id, machine_id, agent_token = sign_as_agent
		if agent_id.strip() and machine_id.strip() and agent_token.strip():
			headers.update(
				rivex_agent_signature_headers(
					method.upper(),
					url,
					body,
					agent_id.strip(),
					machine_id.strip(),
					agent_token.strip(),
				)
			)

	request = Request(url, data=body, headers=headers, method=method.upper())

	try:
		with urlopen(request, timeout=timeout_seconds) as response:
			raw = response.read().decode("utf-8", errors="replace").strip()
	except HTTPError as exc:
		try:
			raw_error = exc.read().decode("utf-8", errors="replace").strip()
		except Exception:
			raw_error = ""
		message = raw_error or str(exc)
		raise AgentHttpError(int(exc.code), url, message, response_body=raw_error) from exc
	except URLError as exc:
		raise RuntimeError(f"Network error for {url}: {exc}") from exc

	if not raw:
		return {}

	try:
		parsed = json.loads(raw)
	except json.JSONDecodeError:
		return {"message": raw}
	if not isinstance(parsed, dict):
		return {"value": parsed}
	return parsed


def _build_enroll_payload(config: Dict[str, Any], comment: str, tags: List[str]) -> Dict[str, Any]:
	from modules.base_info import collect_base_info
	from modules.fingerprint import collect_fingerprint

	base_info = collect_base_info()
	fingerprint = collect_fingerprint(config)

	payload = {
		"agent": {
			"version": str(config.get("version", APP_VERSION)),
		},
		"base_info": {
			"hostname": base_info.get("hostname"),
			"ip_address": base_info.get("ip_address"),
			"os": base_info.get("os"),
			"machine_type": base_info.get("machine_type"),
		},
		"os": {
			"name": base_info.get("os_name"),
			"version": base_info.get("os_version"),
		},
		"fingerprint": {
			"fingerprint": fingerprint.get("fingerprint"),
		},
		"snapshot": {
			"comment": comment,
			"tags": tags,
		},
	}

	agent_uuid = str(config.get("agent_uuid", "") or "").strip()
	if agent_uuid:
		payload["fingerprint"]["agent_uuid"] = agent_uuid

	return payload


def enroll_with_server(
	config: Dict[str, Any],
	server_url: str,
	comment: str,
	tags: List[str],
	enroll_key_override: str,
) -> Dict[str, Any]:
	config["server_url"] = server_url
	agent_api = _agent_api_config(config)
	register_url = _resolve_agent_api_url(config, "register_url")
	timeout_seconds = _safe_timeout(agent_api.get("timeout_seconds", 15), 15)

	enroll_key = str(enroll_key_override or "").strip() or str(agent_api.get("enroll_key", "")).strip()
	headers: Dict[str, str] = {}
	if enroll_key:
		headers["X-Agent-Enroll-Key"] = enroll_key

	payload = _build_enroll_payload(config, comment, tags)
	response = _request_json(
		url=register_url,
		method="POST",
		payload=payload,
		timeout_seconds=timeout_seconds,
		extra_headers=headers,
	)

	agent_uuid = str(response.get("agent_uuid", "") or "").strip()
	agent_token = str(response.get("agent_token", "") or "").strip()
	machine_id = str(response.get("machine_id", "") or "").strip()
	if not (agent_uuid and agent_token and machine_id):
		raise RuntimeError("Register response missing agent_uuid, agent_token or machine_id")

	endpoints = response.get("endpoints", {})
	if not isinstance(endpoints, dict):
		endpoints = {}

	config["enrolled"] = True
	config["server_url"] = server_url
	config["comment"] = comment
	config["tags"] = tags
	config["agent_uuid"] = agent_uuid
	config["agent_token"] = agent_token
	config["machine_id"] = machine_id

	remote_cfg = config.setdefault("remote_commands", {})
	if not isinstance(remote_cfg, dict):
		remote_cfg = {}
		config["remote_commands"] = remote_cfg
	remote_cfg["auth_token"] = agent_token

	pull_url = str(endpoints.get("commands_pull", "") or "").strip()
	result_url = str(endpoints.get("commands_result", "") or "").strip()
	if pull_url:
		remote_cfg["pull_url"] = pull_url
	if result_url:
		remote_cfg["result_url"] = result_url

	agent_api_cfg = config.setdefault("agent_api", {})
	if not isinstance(agent_api_cfg, dict):
		agent_api_cfg = {}
		config["agent_api"] = agent_api_cfg

	sync_url = str(endpoints.get("sync", "") or "").strip()
	if sync_url:
		agent_api_cfg["sync_url"] = sync_url

	alerts_url_ep = str(endpoints.get("alerts", "") or "").strip()
	if alerts_url_ep:
		agent_api_cfg["alerts_url"] = alerts_url_ep

	if pull_url:
		agent_api_cfg["commands_pull_url"] = pull_url
	if result_url:
		agent_api_cfg["commands_result_url"] = result_url

	return {
		"agent_uuid": agent_uuid,
		"agent_token": agent_token,
		"machine_id": machine_id,
		"register_url": register_url,
		"sync_url": sync_url or _resolve_agent_api_url(config, "sync_url"),
		"commands_pull_url": pull_url or _resolve_agent_api_url(config, "commands_pull_url"),
		"commands_result_url": result_url or _resolve_agent_api_url(config, "commands_result_url"),
		"raw": response,
	}


def _http_status_code_from_exception(exc: Exception) -> Optional[int]:
	if isinstance(exc, AgentHttpError):
		return int(exc.status_code)
	if isinstance(exc, HTTPError):
		try:
			return int(exc.code)
		except Exception:
			return None

	text = str(exc).lower()
	match = re.search(r"http\s*(?:error\s*)?(\d{3})", text)
	if not match:
		return None

	try:
		return int(match.group(1))
	except Exception:
		return None


def _is_invalid_agent_token_error(exc: Exception) -> bool:
	status_code = _http_status_code_from_exception(exc)
	if status_code != 401:
		return False

	if isinstance(exc, AgentHttpError):
		body_text = str(exc.response_body or "").lower()
		if "token invalide" in body_text or "invalid token" in body_text:
			return True

	text = str(exc).lower()
	if "token" in text and ("invalid" in text or "invalide" in text):
		return True

	# Most 401 responses on agent endpoints are token-related.
	return True


_AGENT_STATE_REVOKED_MARKERS = (
	"revoked",
	"revoque",
	"revoqu",
	"disabled",
	"desactive",
	"desactiv",
	"agent inactive",
	"agent inactif",
	"deleted",
	"supprime",
	"supprim",
	"not found",
	"introuvable",
	"agent_not_found",
	"agent_revoked",
	"agent_disabled",
	"machine_not_found",
	"machine_deleted",
	"machine_revoked",
)


def _is_agent_state_revoked_error(exc: Exception) -> bool:
	"""Detecte qu un agent n est plus valide cote serveur (revoque/supprime/desactive)."""
	status_code = _http_status_code_from_exception(exc)
	if status_code not in (403, 404, 410):
		return False

	body_text = ""
	if isinstance(exc, AgentHttpError):
		body_text = str(exc.response_body or "").lower()
	text = f"{body_text} {str(exc).lower()}"

	if any(marker in text for marker in _AGENT_STATE_REVOKED_MARKERS):
		return True

	# Un 410 Gone sur endpoint agent = ressource supprimee cote serveur,
	# on considere l agent comme revoque meme sans marqueur explicite.
	if status_code == 410:
		return True

	# Un 404 sur /api/agent/sync ou /api/agent/commands/pull signifie que le
	# serveur ne reconnait plus cet agent_uuid / machine_id.
	if status_code == 404 and "agent" in text:
		return True

	return False


def _agent_state_revoked_reason(exc: Exception) -> str:
	status_code = _http_status_code_from_exception(exc)
	if status_code == 404:
		return "agent_not_found"
	if status_code == 410:
		return "agent_deleted"
	body_text = ""
	if isinstance(exc, AgentHttpError):
		body_text = str(exc.response_body or "").lower()
	text = f"{body_text} {str(exc).lower()}"
	if "revok" in text:
		return "agent_revoked"
	if "delet" in text or "supprim" in text:
		return "agent_deleted"
	if "disabl" in text or "desactiv" in text or "inactif" in text or "inactive" in text:
		return "agent_disabled"
	return "agent_state_invalid"


def _mark_agent_as_revoked(
	config: Dict[str, Any],
	manager: ConfigManager,
	logger: Any | None,
	reason: str,
) -> Dict[str, Any]:
	"""Nettoie proprement l etat local quand le serveur a revoque/supprime l agent."""
	previous_uuid = str(config.get("agent_uuid", "") or "")
	previous_machine_id = str(config.get("machine_id", "") or "")
	previous_server = str(config.get("server_url", "") or "")

	config["enrolled"] = False
	config["agent_uuid"] = ""
	config["agent_token"] = ""
	config["machine_id"] = ""
	config["status"] = "revoked"

	remote_cfg = config.setdefault("remote_commands", {})
	if isinstance(remote_cfg, dict):
		remote_cfg["auth_token"] = ""

	try:
		manager.save(config)
	except Exception:
		if logger is not None:
			logger.exception("Failed to persist revoked state locally")

	if logger is not None:
		logger.warning(
			"Agent marked as revoked locally (reason=%s, previous_uuid=%s, machine_id=%s)",
			reason, previous_uuid or "<none>", previous_machine_id or "<none>",
		)

	return {
		"revoked": True,
		"reason": reason,
		"previous_agent_uuid": previous_uuid,
		"previous_machine_id": previous_machine_id,
		"server_url": previous_server,
	}


def _current_config_tags(config: Dict[str, Any]) -> List[str]:
	raw_tags = config.get("tags", [])
	if not isinstance(raw_tags, list):
		return []

	unique_tags: List[str] = []
	for item in raw_tags:
		tag = str(item).strip()
		if tag and tag not in unique_tags:
			unique_tags.append(tag)
	return unique_tags


def _recover_agent_token(
	config: Dict[str, Any],
	manager: ConfigManager,
	logger: Any | None = None,
) -> Dict[str, Any]:
	server_url = str(config.get("server_url", "") or "").strip()
	if not server_url:
		return {
			"attempted": False,
			"recovered": False,
			"reason": "missing_server_url",
		}

	try:
		registration = enroll_with_server(
			config,
			server_url,
			str(config.get("comment", "") or ""),
			_current_config_tags(config),
			enroll_key_override="",
		)
		manager.save(config)
		return {
			"attempted": True,
			"recovered": True,
			"agent_uuid": registration.get("agent_uuid"),
			"machine_id": registration.get("machine_id"),
			"sync_url": registration.get("sync_url"),
		}
	except Exception as exc:
		if logger is not None:
			logger.warning("Automatic token recovery failed: %s", exc)
		return {
			"attempted": True,
			"recovered": False,
			"reason": str(exc),
		}


def sync_to_server(
	config: Dict[str, Any],
	manager: ConfigManager,
	scan_payload: Optional[Dict[str, Any]] = None,
) -> tuple[Dict[str, Any], Dict[str, Any], int]:
	agent_token = str(config.get("agent_token", "") or "").strip()
	if not bool(config.get("enrolled", False)) or not agent_token:
		config["last_sync"] = utc_now_iso()
		config["status"] = "running"
		manager.save(config)
		return config, {
			"synced": False,
			"mode": "local_only",
			"reason": "agent_not_enrolled_or_missing_token",
			"last_sync": config["last_sync"],
		}, 1

	sync_url = _resolve_agent_api_url(config, "sync_url")
	timeout_seconds = _safe_timeout(_agent_api_config(config).get("timeout_seconds", 15), 15)

	payload = scan_payload if isinstance(scan_payload, dict) else run_scan(config, manager)
	token_recovery_result: Optional[Dict[str, Any]] = None

	def _sync_request(current_token: str) -> Dict[str, Any]:
		payload.setdefault("agent", {})["agent_uuid"] = str(config.get("agent_uuid", "") or "")
		payload.setdefault("agent", {})["machine_id"] = str(config.get("machine_id", "") or "")
		agent_id = str(config.get("agent_uuid", "") or "").strip()
		machine_id = str(config.get("machine_id", "") or "").strip()
		return _request_json(
			url=sync_url,
			method="POST",
			payload=payload,
			timeout_seconds=timeout_seconds,
			sign_as_agent=(agent_id, machine_id, current_token),
		)

	try:
		response = _sync_request(agent_token)
	except Exception as exc:
		if _is_agent_state_revoked_error(exc):
			reason = _agent_state_revoked_reason(exc)
			revocation = _mark_agent_as_revoked(config, manager, None, reason)
			return config, {
				"synced": False,
				"mode": "revoked",
				"reason": reason,
				"message": "Agent revoked or deleted server-side. Local state reset.",
				"revocation": revocation,
				"last_sync": config.get("last_sync"),
			}, 1

		if not _is_invalid_agent_token_error(exc):
			raise

		token_recovery_result = _recover_agent_token(config, manager)
		if not token_recovery_result.get("recovered"):
			# Si la re-inscription echoue avec un 403/404, on est dans le cas
			# d un agent desactive cote serveur : on nettoie l etat local
			# plutot que de laisser une erreur remonter sans action.
			recovery_reason = str(token_recovery_result.get("reason", "") or "")
			if any(marker in recovery_reason.lower() for marker in _AGENT_STATE_REVOKED_MARKERS):
				revocation = _mark_agent_as_revoked(
					config, manager, None, "agent_revoked_on_recovery"
				)
				return config, {
					"synced": False,
					"mode": "revoked",
					"reason": "agent_revoked_on_recovery",
					"message": "Agent token recovery rejected by server. Local state reset.",
					"revocation": revocation,
					"token_recovery": token_recovery_result,
				}, 1
			raise RuntimeError(
				f"{exc} | automatic token recovery failed: {token_recovery_result.get('reason', 'unknown')}"
			) from exc

		refreshed_token = str(config.get("agent_token", "") or "").strip()
		if not refreshed_token:
			raise RuntimeError(f"{exc} | automatic token recovery failed: missing refreshed token") from exc

		response = _sync_request(refreshed_token)

	config["last_sync"] = utc_now_iso()
	config["status"] = "running"
	manager.save(config)

	result = {
		"synced": True,
		"mode": "server",
		"sync_url": sync_url,
		"last_sync": config["last_sync"],
		"server_response": response,
	}
	if token_recovery_result is not None:
		result["token_recovery"] = token_recovery_result

	return config, result, 0


def merge_patch(base: Dict[str, Any], patch: Dict[str, Any]) -> Dict[str, Any]:
	result = dict(base)
	for key, value in patch.items():
		if isinstance(value, dict) and isinstance(result.get(key), dict):
			result[key] = merge_patch(result[key], value)
		else:
			result[key] = value
	return result


def run_patch_action(
	source: str,
	config: Dict[str, Any],
	manager: ConfigManager,
	logger: Any,
	timeout_seconds: int = 15,
) -> tuple[Dict[str, Any], Dict[str, Any], int]:
	"""Execute `--patch <source>` en supportant URL + nouveau format vuln.

	- Si le document contient `vulnerabilities` / `patches` / `fixes` /
	  `remediations`, on applique la remediation via `core.patch_engine`
	  (action de Phase 2: mise a jour d'un paquet, fermeture d'un port,
	  desactivation d'un service - PAS de modification de config.json).
	- Sinon, on retombe sur l'ancien comportement (merge dans config.json)
	  pour ne pas casser la compatibilite des tests / scripts existants.
	"""
	document = patch_engine.load_patch_document(source, timeout=timeout_seconds)

	if patch_engine.looks_like_vulnerability_patch(document):
		result = patch_engine.apply_vulnerability_patch(document)
		result.setdefault("source", source)
		failed_count = len(result.get("failed", []) or [])
		exit_code = 0 if failed_count == 0 else 1
		if logger is not None:
			logger.info(
				"Vulnerability patch applied (source=%s, applied=%d, failed=%d, skipped=%d)",
				source,
				len(result.get("applied", []) or []),
				failed_count,
				len(result.get("skipped", []) or []),
			)
		return config, result, exit_code

	merged = merge_patch(config, document)
	manager.save(merged)
	if logger is not None:
		logger.info("Legacy config patch merged from %s", source)
	return merged, {
		"patch_applied": source,
		"mode": "config_merge",
		"deprecated": True,
		"message": (
			"Legacy config-merge patch applied. Use the 'vulnerabilities' format for "
			"Phase 2 remediation patches. Config merge will be removed in a future release."
		),
		"patched_keys": sorted(list(document.keys())),
	}, 0


def _scheduler_from_config(config: Dict[str, Any]) -> Scheduler:
	scheduler_cfg = config.get("scheduler", {})
	interval_raw = scheduler_cfg.get("interval_minutes", 30)
	try:
		interval_minutes = int(interval_raw)
	except (TypeError, ValueError):
		raise ValueError("scheduler.interval_minutes must be an integer")

	task_name = str(scheduler_cfg.get("task_name", "Rivex-Agent-AutoScan"))
	linux_cron_marker = str(scheduler_cfg.get("linux_cron_marker", "# RIVEX_AGENT_AUTO_SCAN"))
	scan_command_args = str(scheduler_cfg.get("scan_command_args", "--scan"))
	linux_backend = str(scheduler_cfg.get("linux_backend", "cron"))
	systemd_unit_prefix = str(scheduler_cfg.get("systemd_unit_prefix", "rivex-agent-autoscan"))

	return Scheduler(
		python_executable=sys.executable,
		launcher_path=Path(__file__).resolve(),
		interval_minutes=interval_minutes,
		task_name=task_name,
		linux_cron_marker=linux_cron_marker,
		scan_command_args=scan_command_args,
		linux_backend=linux_backend,
		systemd_unit_prefix=systemd_unit_prefix,
	)


def apply_scan_interval_minutes(
	config: Dict[str, Any],
	manager: ConfigManager,
	new_interval: int,
	*,
	logger: Any = None,
) -> tuple[Dict[str, Any], Dict[str, Any]]:
	if new_interval <= 0:
		raise ValueError("interval_minutes must be a positive integer")
	scheduler_cfg = config.setdefault("scheduler", {})
	previous_interval = int(scheduler_cfg.get("interval_minutes", 30) or 30)
	was_enabled = bool(scheduler_cfg.get("enabled", False))
	scheduler_cfg["interval_minutes"] = new_interval
	manager.save(config)

	response: Dict[str, Any] = {
		"scheduler_interval": "updated",
		"previous_interval_minutes": previous_interval,
		"interval_minutes": new_interval,
		"reapplied": False,
	}
	if was_enabled:
		try:
			scheduler = _scheduler_from_config(config)
			reapply_result = scheduler.enable_every_30_minutes()
			response["reapplied"] = True
			response.update(reapply_result)
		except Exception as exc:
			if logger is not None:
				logger.exception("Failed to re-apply scheduler with new interval")
			response["reapplied"] = False
			response["reapply_error"] = str(exc)
	return config, response


def run_scan(config: Dict[str, Any], manager: ConfigManager) -> Dict[str, Any]:
	from modules.base_info import collect_base_info
	from modules.filesystem import collect_files
	from modules.fingerprint import collect_fingerprint
	from modules.metrics import collect_metrics
	from modules.network import collect_network
	from modules.security import collect_certificates
	from modules.services import collect_services
	from modules.software import collect_software

	base_info = collect_base_info()
	network_data = collect_network()
	fingerprint = collect_fingerprint(config)

	if config.get("agent_uuid") != fingerprint.get("agent_uuid"):
		config["agent_uuid"] = fingerprint["agent_uuid"]
		manager.save(config)

	# Le snapshot envoyé au serveur ne doit pas réinjecter les tags : ils sont
	# gérés côté admin (UI / API) et seraient écrasés à chaque sync si on les
	# envoyait depuis l'agent. On les enlève donc explicitement de la copie.
	snapshot = {k: v for k, v in config.items() if k != "tags"}

	payload = {
		"scan_id": str(uuid4()),
		"collected_at": utc_now_iso(),
		"agent": {
			"version": str(config.get("version", APP_VERSION)),
			"last_heartbeat": utc_now_iso(),
		},
		"base_info": {
			"hostname": base_info.get("hostname"),
			"ip_address": base_info.get("ip_address"),
			"os": base_info.get("os"),
			"machine_type": base_info.get("machine_type"),
		},
		"os": {
			"name": base_info.get("os_name"),
			"version": base_info.get("os_version"),
		},
		"metrics": collect_metrics(),
		"softwares": collect_software(),
		"files": collect_files(config.get("scan", {})),
		"ports": network_data.get("ports", []),
		"services": collect_services(),
		"certs": collect_certificates(),
		"fingerprint": fingerprint,
		"http_endpoints": network_data.get("http_endpoints", []),
		"snapshot": snapshot,
	}
	return payload


def compute_health_score(scan_payload: Dict[str, Any]) -> Dict[str, Any]:
	score = 100
	reasons: List[str] = []

	metrics = scan_payload.get("metrics", {})
	cpu_percent = metrics.get("cpu_percent")
	ram_percent = metrics.get("ram_percent")
	disk_percent = metrics.get("disk_percent")

	if isinstance(cpu_percent, (int, float)) and cpu_percent > 85:
		score -= 20
		reasons.append("High CPU usage")
	if isinstance(ram_percent, (int, float)) and ram_percent > 85:
		score -= 20
		reasons.append("High RAM usage")
	if isinstance(disk_percent, (int, float)) and disk_percent > 90:
		score -= 20
		reasons.append("High disk usage")

	open_ports = len(scan_payload.get("ports", []))
	if open_ports > 20:
		score -= min(20, (open_ports - 20) // 2)
		reasons.append("Large open port exposure")

	cert_count = len(scan_payload.get("certs", []))
	if cert_count == 0:
		score -= 5
		reasons.append("No local TLS certificate detected")

	score = max(0, min(100, score))
	return {
		"score": score,
		"grade": "A" if score >= 90 else "B" if score >= 75 else "C" if score >= 60 else "D",
		"reasons": reasons,
	}


def build_status_payload(config: Dict[str, Any], config_path: Path, startup_sync_changed: bool) -> Dict[str, Any]:
	return {
		"agent": APP_NAME,
		"version": str(config.get("version", APP_VERSION)),
		"enrolled": config.get("enrolled", False),
		"status": config.get("status", "stopped"),
		"last_sync": config.get("last_sync"),
		"config_synced_on_startup": startup_sync_changed,
		"scheduler": config.get("scheduler", {}),
		"remote_commands": config.get("remote_commands", {}),
		"log_path": LOG_FILE_OVERRIDE.as_posix(),
		"config_path": config_path.as_posix(),
		"install_mode": AGENT_MODE,
	}


def build_diagnostic_payload(config: Dict[str, Any], config_path: Path) -> Dict[str, Any]:
	parsed = urlparse(config.get("server_url", "")) if config.get("server_url") else None
	system_deps_report = system_deps.check_dependencies()
	diagnostics = {
		"config_exists": config_path.exists(),
		"log_path": LOG_FILE_OVERRIDE.as_posix(),
		"config_path": config_path.as_posix(),
		"install_mode": AGENT_MODE,
		"enrolled": config.get("enrolled", False),
		"server_url_valid": bool(parsed and parsed.scheme and parsed.netloc),
		"last_sync": config.get("last_sync"),
		"system_deps": {
			"platform": system_deps_report.get("platform"),
			"groups": system_deps_report.get("groups"),
			"missing": system_deps_report.get("missing"),
			"missing_required_groups": system_deps_report.get("missing_required_groups"),
		},
	}
	config_ok = diagnostics["config_exists"] and (not diagnostics["enrolled"] or diagnostics["server_url_valid"])
	deps_ok = not diagnostics["system_deps"].get("missing_required_groups")
	diagnostics["ok"] = config_ok and deps_ok
	return diagnostics


def run_update_check(config: Dict[str, Any], manager: ConfigManager, logger: Any) -> tuple[Dict[str, Any], Dict[str, Any], int]:
	config, update_sync_changed = sync_runtime_config_from_template(
		manager,
		config,
		preserve_runtime_session=True,
	)
	if str(config.get("version", "")).strip() != APP_VERSION:
		config["version"] = APP_VERSION
		manager.save(config)
	update_cfg = config.get("update", {})
	if not isinstance(update_cfg, dict):
		update_cfg = {}
	local_version = APP_VERSION
	configured_version_url = str(update_cfg.get("version_url", "") or "").strip()
	resolved_version_url = configured_version_url
	if not resolved_version_url:
		server_url = str(config.get("server_url", "") or "").strip()
		if server_url:
			resolved_version_url = urljoin(server_url.rstrip("/") + "/", "agent/version.json")
	updater = Updater(
		current_version=local_version,
		version_url=resolved_version_url,
	)
	update_code = 0
	try:
		result = updater.check_for_update()
		result["version_url"] = resolved_version_url or None
		result["version_url_source"] = "config" if configured_version_url else "server_url_fallback"
		result["config_sync"] = {
			"performed": True,
			"changed": update_sync_changed,
		}
		if result.get("update_available") and result.get("download_url"):
			prepared = updater.prepare_update(result["download_url"], RUNTIME_UPDATE_DIR)
			result["prepared_update"] = prepared
			package_path = str(prepared.get("staged_file") or prepared.get("downloaded_file") or "").strip()
			if not package_path:
				raise RuntimeError("Update package path is missing after download")
			cleanup_paths_cfg = update_cfg.get("cleanup_paths", [])
			cleanup_paths: List[str] = []
			if isinstance(cleanup_paths_cfg, list):
				cleanup_paths = [str(item).strip() for item in cleanup_paths_cfg if str(item).strip()]
			elif isinstance(cleanup_paths_cfg, str) and cleanup_paths_cfg.strip():
				cleanup_paths = [cleanup_paths_cfg.strip()]

			applied = updater.apply_update_package(
				package_path,
				AGENT_DIR,
				cleanup_paths=cleanup_paths,
			)
			result["applied_update"] = applied
			remote_version = str(result.get("remote_version", "") or "").strip()
			if remote_version:
				config["version"] = remote_version
				manager.save(config)
				result["local_version_after_apply"] = remote_version

			dependencies = ensure_runtime_dependencies(AGENT_DIR, logger, force_reinstall=True)
			result["dependencies"] = dependencies

			if dependencies.get("status") == "ok":
				result["message"] = "Update downloaded, applied locally, and requirements were refreshed."
			else:
				update_code = 1
				result["message"] = "Update applied locally, but requirements installation failed."
		elif result.get("update_available"):
			result["message"] = "Update available but no download URL was provided"
		return config, result, update_code
	except Exception as exc:
		logger.exception("Update check failed")
		return config, {"error": str(exc)}, 1


def _detached_popen_kwargs() -> Dict[str, Any]:
	"""Kwargs Popen multiplateformes pour detacher un process de fa on compatible Linux/Windows.

	L ancienne implementation utilisait `start_new_session=True` (POSIX uniquement),
	ce qui faisait lever une erreur sur Windows au moment d un auto-restart post-update
	et bloquait en pratique l auto-redemarrage apres `--update` sur les postes Windows.
	"""
	kwargs: Dict[str, Any] = {
		"stdin": subprocess.DEVNULL,
		"stdout": subprocess.DEVNULL,
		"stderr": subprocess.DEVNULL,
	}
	if os.name == "nt":
		detached_process = 0x00000008
		create_new_process_group = 0x00000200
		kwargs["creationflags"] = detached_process | create_new_process_group
		kwargs["close_fds"] = True
	else:
		kwargs["start_new_session"] = True
	return kwargs


def _restart_after_update(logger: Any) -> Dict[str, Any]:
	if str(os.getenv(UPDATE_RESTART_GUARD_ENV, "")).strip() == "1":
		return {
			"attempted": False,
			"restarted": False,
			"reason": "already_restarted_once",
		}

	restart_args = [arg for arg in sys.argv[1:] if arg != "--update"]
	if not restart_args:
		restart_args = ["--status"]

	command = [sys.executable, str(Path(__file__).resolve()), *restart_args]
	env = os.environ.copy()
	env[UPDATE_RESTART_GUARD_ENV] = "1"

	popen_kwargs = _detached_popen_kwargs()
	popen_kwargs.update({
		"cwd": str(AGENT_DIR),
		"env": env,
	})

	try:
		subprocess.Popen(command, **popen_kwargs)
		return {
			"attempted": True,
			"restarted": True,
			"command": command,
			"platform": platform.system().lower(),
		}
	except Exception as exc:
		logger.warning("Unable to auto-restart agent process after update: %s", exc)
		return {
			"attempted": True,
			"restarted": False,
			"error": str(exc),
			"command": command,
			"platform": platform.system().lower(),
		}


def _safe_int(value: Any, fallback: int) -> int:
	try:
		parsed = int(value)
	except (TypeError, ValueError):
		return fallback
	if parsed <= 0:
		return fallback
	return parsed


def _remote_allowed_actions(config: Dict[str, Any]) -> set[str]:
	remote_cfg = config.get("remote_commands", {})
	if not isinstance(remote_cfg, dict):
		return set(DEFAULT_REMOTE_ALLOWED_ACTIONS)

	value = remote_cfg.get("allowed_actions", [])
	if not isinstance(value, list):
		return set(DEFAULT_REMOTE_ALLOWED_ACTIONS)

	allowed: set[str] = set()
	for item in value:
		action = str(item).strip().lower()
		if action:
			allowed.add(action)

	return allowed or set(DEFAULT_REMOTE_ALLOWED_ACTIONS)


def _normalize_remote_action(command_payload: Dict[str, Any]) -> str:
	action_value = command_payload.get("action") or command_payload.get("type") or command_payload.get("command")
	return str(action_value or "").strip().lower()


def _resolve_output_path(output_name: str | None, prefix: str = "scan") -> Path:
	if output_name:
		output_path = Path(output_name)
		if not output_path.is_absolute():
			output_path = Path.cwd() / output_path
		return output_path

	timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
	return RUNTIME_SCAN_DIR / f"{prefix}_{timestamp}.json"


def _execute_reboot_command() -> Dict[str, Any]:
	system = platform.system().lower()
	if system == "windows":
		command = ["shutdown", "/r", "/t", "0", "/f"]
	elif system == "linux":
		command = ["systemctl", "reboot"]
	else:
		raise RuntimeError(f"Unsupported platform for reboot action: {system}")

	process = subprocess.run(
		command,
		capture_output=True,
		text=True,
		encoding="utf-8",
		errors="replace",
		check=False,
	)
	if process.returncode != 0:
		stderr = (process.stderr or "").strip()
		stdout = (process.stdout or "").strip()
		message = stderr or stdout or "reboot command failed"
		raise RuntimeError(message)

	return {
		"requested": True,
		"platform": system,
		"command": command,
	}


def _protection_config(config: Dict[str, Any]) -> Dict[str, Any]:
	protection_cfg = config.get("protection", {})
	if not isinstance(protection_cfg, dict):
		return {}
	return protection_cfg


def _resolve_alert_url(config: Dict[str, Any]) -> str:
	protection_cfg = _protection_config(config)
	explicit = str(protection_cfg.get("alert_url", "") or "").strip()
	if explicit:
		return explicit
	# Fallback via agent_api.alerts_url (defini dans les endpoints serveur
	# par defaut) puis derivation depuis server_url.
	return _resolve_agent_api_url(config, "alerts_url")


def run_protection_check(
	config: Dict[str, Any],
	logger: Any,
	force_alert: bool = False,
) -> tuple[Dict[str, Any], Optional[Dict[str, Any]]]:
	"""Execute un controle d integrite et remonte une alerte si necessaire.

	- Initialise silencieusement le baseline au premier run.
	- Si un ecart est detecte, tente d envoyer une alerte au serveur.
	  L echec d envoi ne fait pas echouer la commande.
	"""
	protection_cfg = _protection_config(config)
	report = agent_protection.detect_tampering(AGENT_DIR, RUNTIME_DIR, auto_initialize=True)

	if logger is not None and report.get("tampered"):
		logger.warning(
			"Agent integrity check: tampered=True, tampered_files=%d, missing_files=%d",
			len(report.get("tampered_files", []) or []),
			len(report.get("missing_files", []) or []),
		)

	if not (report.get("tampered") or force_alert):
		return report, None

	if not bool(protection_cfg.get("enabled", True)):
		return report, {
			"sent": False,
			"reason": "protection_disabled_in_config",
		}

	alert_url = _resolve_alert_url(config)
	timeout_seconds = _safe_timeout(
		protection_cfg.get("alert_timeout_seconds", 10), 10
	)
	payload = agent_protection.build_tamper_alert_payload(
		agent_uuid=str(config.get("agent_uuid", "") or ""),
		machine_id=str(config.get("machine_id", "") or ""),
		agent_version=str(config.get("version", APP_VERSION)),
		tamper_report=report,
	)
	alert_result = agent_protection.send_tamper_alert(
		server_url=str(config.get("server_url", "") or ""),
		alert_url=alert_url,
		auth_token=str(config.get("agent_token", "") or ""),
		payload=payload,
		timeout_seconds=timeout_seconds,
		agent_id=str(config.get("agent_uuid", "") or ""),
		machine_id=str(config.get("machine_id", "") or ""),
	)
	if logger is not None:
		if alert_result.get("sent"):
			logger.info("Tamper alert sent successfully to %s", alert_result.get("url"))
		else:
			logger.warning(
				"Tamper alert not sent (reason=%s)",
				alert_result.get("reason") or alert_result.get("error"),
			)
	return report, alert_result


def execute_forced_action(
	action: str,
	params: Dict[str, Any],
	config: Dict[str, Any],
	manager: ConfigManager,
	logger: Any,
	config_path: Path,
	startup_sync_changed: bool,
) -> tuple[Dict[str, Any], Dict[str, Any], bool]:
	if action == "scan":
		payload = run_scan(config, manager)
		output_name = str(params.get("output_file", "")).strip() if isinstance(params, dict) else ""
		output_path = _resolve_output_path(output_name, prefix="forced_scan")
		output_path.parent.mkdir(parents=True, exist_ok=True)
		output_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
		config, sync_result, sync_code = sync_to_server(config, manager, scan_payload=payload)
		return config, {
			"scan_saved_to": output_path.as_posix(),
			"scan_sync": sync_result,
		}, sync_code == 0

	if action == "sync":
		config, sync_result, sync_code = sync_to_server(config, manager)
		return config, sync_result, sync_code == 0

	if action == "status":
		return config, build_status_payload(config, config_path, startup_sync_changed), True

	if action in {"diag", "diagnostic"}:
		return config, build_diagnostic_payload(config, config_path), True

	if action == "score":
		score_payload = compute_health_score(run_scan(config, manager))
		return config, score_payload, True

	if action == "update":
		config, update_result, exit_code = run_update_check(config, manager, logger)
		return config, update_result, exit_code == 0

	if action == "reboot":
		return config, _execute_reboot_command(), True

	if action == "patch":
		# Le serveur peut envoyer soit un document JSON directement, soit une
		# URL (patch_url) pointant vers le document genere par l analyse de
		# vulnerabilites. Les deux voies sont supportees.
		patch_source: Any = None
		if isinstance(params, dict):
			patch_source = params.get("patch_url") or params.get("url") or params.get("source")
			if patch_source is None and "patch" in params:
				patch_source = params.get("patch")
			elif patch_source is None:
				patch_source = params

		if isinstance(patch_source, str):
			try:
				timeout_seconds = _safe_timeout(
					_agent_api_config(config).get("timeout_seconds", 15), 15
				)
				config, patch_result, exit_code = run_patch_action(
					patch_source, config, manager, logger, timeout_seconds=timeout_seconds
				)
			except (FileNotFoundError, ValueError) as exc:
				raise ValueError(f"Remote patch source error: {exc}") from exc
			return config, patch_result, exit_code == 0

		if not isinstance(patch_source, dict):
			raise ValueError(
				"Remote patch action requires a JSON object, an URL string, or a local path"
			)

		if patch_engine.looks_like_vulnerability_patch(patch_source):
			result = patch_engine.apply_vulnerability_patch(patch_source)
			return config, result, not result.get("failed")

		config = merge_patch(config, patch_source)
		manager.save(config)
		return config, {
			"patch_applied": True,
			"mode": "config_merge",
			"deprecated": True,
			"patched_keys": sorted(list(patch_source.keys())),
		}, True

	if action == "enable_auto_scan":
		scheduler = _scheduler_from_config(config)
		result = scheduler.enable_every_30_minutes()
		config.setdefault("scheduler", {})["enabled"] = True
		manager.save(config)
		return config, {"auto_scan": "enabled", **result}, True

	if action == "disable_auto_scan":
		scheduler = _scheduler_from_config(config)
		result = scheduler.disable_every_30_minutes()
		config.setdefault("scheduler", {})["enabled"] = False
		manager.save(config)
		return config, {"auto_scan": "disabled", **result}, True

	if action == "set_scan_interval":
		params = params or {}
		raw: Any = params.get("interval_minutes", params.get("minutes"))
		try:
			new_interval = int(raw)
		except (TypeError, ValueError) as exc:
			raise ValueError(
				"set_scan_interval requires integer 'interval_minutes' or 'minutes' in params"
			) from exc
		config, result = apply_scan_interval_minutes(config, manager, new_interval, logger=logger)
		ok = "reapply_error" not in result
		if logger is not None:
			logger.info(
				"Scan interval (remote) set to %s minutes (reapplied=%s, ok=%s)",
				new_interval, result.get("reapplied"), ok,
			)
		return config, result, ok

	if action == "check_protection":
		report, alert_result = run_protection_check(config, logger)
		return config, {
			"protection": report,
			"alert": alert_result,
		}, not report.get("tampered")

	if action == "refresh_protection_baseline":
		baseline = agent_protection.update_baseline(AGENT_DIR, RUNTIME_DIR)
		return config, {
			"baseline_refreshed": True,
			"generated_at": baseline.get("generated_at"),
		}, True

	if action == "check_system_deps":
		report = system_deps.check_dependencies()
		ok = not report.get("missing_required_groups")
		return config, {"system_deps": report}, ok

	if action == "install_system_deps":
		include_optional = bool(params.get("include_optional", False))
		outcome = system_deps.install_missing_dependencies(include_optional=include_optional)
		attempted = bool(outcome.get("attempted"))
		success = bool(outcome.get("success"))
		ok = (not attempted) or success
		return config, {"system_deps_install": outcome}, ok

	if action == "tag":
		tags_value: Any = params.get("tags", params.get("tag", []))
		append_mode = bool(params.get("append", True))

		incoming_tags: List[str] = []
		if isinstance(tags_value, list):
			incoming_tags = [str(item).strip() for item in tags_value if str(item).strip()]
		elif isinstance(tags_value, str):
			incoming_tags = [item.strip() for item in tags_value.split(",") if item.strip()]

		if not incoming_tags:
			raise ValueError("Remote tag action requires 'tag' or 'tags' parameter")

		config = manager.set_tags(incoming_tags, append=append_mode)
		return config, {"enrolled": config.get("enrolled", False), "tags": config.get("tags", [])}, True

	raise ValueError(f"Unsupported forced action: {action}")


def process_remote_forced_commands(
	config: Dict[str, Any],
	manager: ConfigManager,
	logger: Any,
	config_path: Path,
	startup_sync_changed: bool,
) -> tuple[Dict[str, Any], Dict[str, Any], int]:
	remote_cfg = config.get("remote_commands", {})
	if not isinstance(remote_cfg, dict):
		remote_cfg = {}

	if not bool(remote_cfg.get("enabled", False)):
		return (
			config,
			{
				"remote_commands": {
					"enabled": False,
					"message": "Remote commands are disabled in config.remote_commands.enabled",
				}
			},
			0,
		)

	client = RemoteCommandClient(
		server_url=str(config.get("server_url", "")),
		pull_url=str(remote_cfg.get("pull_url", "")),
		result_url=str(remote_cfg.get("result_url", "")),
		auth_token=str(remote_cfg.get("auth_token", "") or config.get("agent_token", "")),
		timeout_seconds=_safe_int(remote_cfg.get("timeout_seconds", 10), 10),
		agent_id=str(config.get("agent_uuid", "") or "").strip(),
		machine_id=str(config.get("machine_id", "") or "").strip(),
	)

	pull_payload = {
		"agent_uuid": config.get("agent_uuid", ""),
		"machine_id": config.get("machine_id", ""),
		"agent_name": config.get("agent_name", APP_NAME),
		"agent_version": str(config.get("version", APP_VERSION)),
		"enrolled": bool(config.get("enrolled", False)),
		"requested_at": utc_now_iso(),
	}
	token_recovery_result: Optional[Dict[str, Any]] = None

	try:
		pull_response = client.pull_commands(pull_payload)
	except Exception as exc:
		if _is_agent_state_revoked_error(exc):
			reason = _agent_state_revoked_reason(exc)
			revocation = _mark_agent_as_revoked(config, manager, logger, reason)
			return config, {
				"remote_commands": {
					"enabled": True,
					"pulled": 0,
					"executed": 0,
					"failed": 0,
					"reason": reason,
					"message": "Agent revoked or deleted server-side. Local state reset.",
					"revocation": revocation,
				},
			}, 1

		if _is_invalid_agent_token_error(exc):
			token_recovery_result = _recover_agent_token(config, manager, logger=logger)
			if token_recovery_result.get("recovered"):
				client = RemoteCommandClient(
					server_url=str(config.get("server_url", "")),
					pull_url=str(remote_cfg.get("pull_url", "")),
					result_url=str(remote_cfg.get("result_url", "")),
					auth_token=str(remote_cfg.get("auth_token", "") or config.get("agent_token", "")),
					timeout_seconds=_safe_int(remote_cfg.get("timeout_seconds", 10), 10),
					agent_id=str(config.get("agent_uuid", "") or "").strip(),
					machine_id=str(config.get("machine_id", "") or "").strip(),
				)
				pull_payload["agent_uuid"] = config.get("agent_uuid", "")
				pull_payload["machine_id"] = config.get("machine_id", "")
				pull_payload["agent_version"] = str(config.get("version", APP_VERSION))
				try:
					pull_response = client.pull_commands(pull_payload)
				except Exception as retry_exc:
					logger.exception("Remote command pull failed after token recovery")
					return config, {
						"error": str(retry_exc),
						"stage": "pull_commands",
						"token_recovery": token_recovery_result,
					}, 1
			else:
				logger.exception("Remote command pull failed and token recovery failed")
				return config, {
					"error": str(exc),
					"stage": "pull_commands",
					"token_recovery": token_recovery_result,
				}, 1
		else:
			logger.exception("Remote command pull failed")
			return config, {"error": str(exc), "stage": "pull_commands"}, 1

	if not pull_response.get("ok"):
		return (
			config,
			{
				"remote_commands": {
					"enabled": True,
					"pulled": 0,
					"executed": 0,
					"failed": 0,
					"reason": pull_response.get("reason", "unknown"),
				}
			},
			0,
		)

	raw_commands = pull_response.get("commands", [])
	if not isinstance(raw_commands, list):
		raw_commands = []

	max_commands = _safe_int(remote_cfg.get("max_commands_per_poll", 10), 10)
	commands = raw_commands[:max_commands]
	allowed_actions = _remote_allowed_actions(config)

	results: List[Dict[str, Any]] = []
	executed = 0
	failed = 0

	for command in commands:
		if not isinstance(command, dict):
			continue

		command_id = str(command.get("id") or command.get("command_id") or "")
		action = _normalize_remote_action(command)
		params = command.get("params", {})
		if not isinstance(params, dict):
			params = {}

		if not action:
			results.append(
				{
					"id": command_id,
					"status": "skipped",
					"reason": "missing_action",
				}
			)
			continue

		if action not in allowed_actions:
			results.append(
				{
					"id": command_id,
					"action": action,
					"status": "skipped",
					"reason": "action_not_allowed",
				}
			)
			continue

		executed += 1
		try:
			config, action_result, ok = execute_forced_action(
				action,
				params,
				config,
				manager,
				logger,
				config_path,
				startup_sync_changed,
			)
			if not ok:
				failed += 1
			results.append(
				{
					"id": command_id,
					"action": action,
					"status": "ok" if ok else "error",
					"result": action_result,
				}
			)
		except Exception as exc:
			failed += 1
			logger.exception("Forced remote action failed: %s", action)
			results.append(
				{
					"id": command_id,
					"action": action,
					"status": "error",
					"error": str(exc),
				}
			)

	ack_payload = {
		"agent_uuid": config.get("agent_uuid", ""),
		"machine_id": config.get("machine_id", ""),
		"submitted_at": utc_now_iso(),
		"results": results,
	}

	try:
		ack_result = client.push_results(ack_payload)
	except Exception as exc:
		logger.exception("Remote command result submission failed")
		ack_result = {
			"ok": False,
			"error": str(exc),
		}

	response = {
		"remote_commands": {
			"enabled": True,
			"pull_url": client.pull_url,
			"result_url": client.result_url,
			"pulled": len(raw_commands),
			"processed": len(commands),
			"executed": executed,
			"failed": failed,
			"allowed_actions": sorted(allowed_actions),
			"results": results,
			"ack": ack_result,
		}
	}
	if token_recovery_result is not None:
		response["remote_commands"]["token_recovery"] = token_recovery_result

	return config, response, 0 if failed == 0 else 1


def run_service_loop(
	config: Dict[str, Any],
	manager: ConfigManager,
	logger: Any,
	config_path: Path,
) -> int:
	"""Boucle principale du mode service (declenchee par --service-run).

	Utilisee comme `ExecStart` de l unit systemd (Linux) et de l executable
	NSSM (Windows). La boucle :

	1. Verifie que l agent est enrole; sinon log + attente (pas de crash).
	2. A chaque cycle (plan AGENT, points 1.2 et 1.3, hors migration socket) :
	   - `sync_to_server` avec le resultat d un scan quand l intervalle de scan
	     est atteint, sinon sync avec un nouveau scan cote `sync` (comportement
	     `sync_to_server` existant) ;
	   - enchainement systematique d un pull / execution de commandes distantes
	     (`process_remote_forced_commands`) apres chaque sync reussi.
	3. Gere SIGTERM (Linux) / CTRL_BREAK (Windows) pour un arret propre.

	Retourne 0 a la sortie propre, 1 si erreur bloquante (relance geree par
	systemd / NSSM via leur mecanisme `Restart=on-failure` / RestartCtrl).
	"""
	import signal
	import threading
	import time

	stop_event = threading.Event()

	def _signal_handler(signum: int, _frame: Any) -> None:
		logger.info("Service received signal %s, stopping gracefully", signum)
		stop_event.set()

	# SIGTERM (tous OS) + SIGINT (Ctrl+C lors d une exec manuelle).
	try:
		signal.signal(signal.SIGTERM, _signal_handler)
		signal.signal(signal.SIGINT, _signal_handler)
		if platform.system().lower() == "windows" and hasattr(signal, "SIGBREAK"):
			signal.signal(signal.SIGBREAK, _signal_handler)  # type: ignore[attr-defined]
	except Exception:
		logger.exception("Service signal handler setup failed; continuing")

	scheduler_cfg = config.get("scheduler", {}) if isinstance(config, dict) else {}
	scan_interval_s = max(60, int(scheduler_cfg.get("interval_minutes", 60) or 60) * 60)
	sync_interval_s = max(30, int(scheduler_cfg.get("sync_interval_seconds", 120) or 120))

	logger.info(
		"Service loop started (sync every %ss, full scan every %ss)",
		sync_interval_s, scan_interval_s,
	)

	last_scan_ts = 0.0

	while not stop_event.is_set():
		cycle_start = time.time()
		enrolled = bool(config.get("enrolled"))

		try:
			if enrolled:
				now = time.time()
				should_scan = (now - last_scan_ts) >= scan_interval_s
				if should_scan:
					logger.info("Service loop: running scheduled scan")
					scan_payload = run_scan(config, manager)
					config, _, _ = sync_to_server(config, manager, scan_payload=scan_payload)
					last_scan_ts = now
				else:
					config, _, _ = sync_to_server(config, manager)

				# Pull des commandes distantes (non bloquant; erreurs logguees).
				try:
					config, _, _ = process_remote_forced_commands(
						config, manager, logger, config_path,
						startup_sync_changed=False,
					)
				except Exception:
					logger.exception("Service loop: remote commands pull failed")
			else:
				logger.info("Service loop: agent not enrolled, waiting (use --enroll first)")
		except Exception:
			logger.exception("Service loop: cycle failed, will retry")

		elapsed = time.time() - cycle_start
		sleep_for = max(5.0, sync_interval_s - elapsed)
		stop_event.wait(timeout=sleep_for)

	logger.info("Service loop stopped cleanly")
	return 0


def _cli_arguments(argv: Optional[List[str]]) -> List[str]:
	"""Arguments a parser (hors nom du programme).

	L'installation Linux depuis le binaire PyInstaller utilisait un wrapper qui
	passait ``agent_launcher.py`` au bootloader en plus des drapeaux ; ce token
	est retire s'il correspond au fichier courant pour compatibilite avec les
	deploiements deja en place.
	"""
	args = list(argv) if argv is not None else sys.argv[1:]
	if not args:
		return args
	try:
		if Path(args[0]).resolve() == Path(__file__).resolve():
			return args[1:]
	except (OSError, ValueError):
		pass
	return args


def main(argv: Optional[List[str]] = None) -> int:
	raw_args = _cli_arguments(argv)
	parser = build_parser()
	args = parser.parse_args(raw_args)
	validate_args(parser, args)

	privileged_actions = _requested_privileged_actions(args)
	if privileged_actions and not _is_process_elevated():
		if str(os.getenv(ELEVATION_REEXEC_GUARD_ENV, "")).strip() == "1":
			print(
				json.dumps(
					{
						"error": "Command requires root/admin privileges",
						"actions": privileged_actions,
						"stage": "elevation",
					},
					indent=2,
					ensure_ascii=False,
				)
			)
			return 1

		try:
			elevation_result = _relaunch_with_elevation(raw_args)
		except Exception as exc:
			print(
				json.dumps(
					{
						"error": str(exc),
						"actions": privileged_actions,
						"stage": "elevation",
					},
					indent=2,
					ensure_ascii=False,
				)
			)
			return 1

		if elevation_result.get("platform") == "linux":
			return int(elevation_result.get("exit_code", 1))

		print(
			json.dumps(
				{
					"message": "Elevation requested. Command relaunched with administrator privileges.",
					"actions": privileged_actions,
				},
				indent=2,
			)
		)
		return 0

	if getattr(args, "bump_version", None) is not None:
		try:
			result = run_version_bump(
				part=str(getattr(args, "bump_version", "patch") or "patch"),
				set_version=str(getattr(args, "set_version", "") or ""),
			)
		except Exception as exc:
			print(json.dumps({"error": str(exc), "stage": "bump_version"}, indent=2, ensure_ascii=False))
			return 1

		print(json.dumps(result, indent=2, ensure_ascii=False))
		return 0

	ensure_runtime_storage()

	config_path = RUNTIME_CONFIG_PATH
	first_install = not config_path.exists()
	manager = ConfigManager(config_path)
	config = manager.load()
	config, startup_sync_changed = sync_runtime_config_from_template(manager, config)

	if str(config.get("version", "")).strip() != APP_VERSION:
		config["version"] = APP_VERSION
		manager.save(config)

	logger = get_logger(APP_NAME, LOG_FILE_OVERRIDE)
	ensure_linux_manpage(logger)
	dependency_status = ensure_runtime_dependencies(AGENT_DIR, logger, force_reinstall=first_install)
	if dependency_status.get("status") != "ok":
		logger.warning("Runtime dependency bootstrap status: %s", dependency_status)

	if args.version:
		print(str(config.get("version", APP_VERSION)))
		return 0

	if args.enroll:
		# Un agent deja marque enrole localement ne peut pas refaire un enroll
		# « normal » (cle globale / fingerprint seul) : risque de doublon ou de
		# comportement ambigu. La reprise apres revocation / re-attachement explicite
		# passe par --enroll_key (cle machine ou cle globale fournie en CLI).
		enroll_key_cli = str(args.enroll_key or "").strip()
		if bool(config.get("enrolled", False)) and not enroll_key_cli:
			print(
				json.dumps(
					{
						"error": (
							"Agent deja enrole localement. Pour re-enroler (ex. apres revocation "
							"cote serveur), fournissez une cle sur la ligne de commande : "
							"`--enroll --enroll_key <CLE>` (cle machine recommandee, voir admin). "
							"Pour repartir de zero : `--unenroll` puis `--enroll`."
						),
						"stage": "enroll_guard",
						"enrolled": True,
					},
					indent=2,
					ensure_ascii=False,
				)
			)
			return 1

		enroll_url, enroll_comment, enroll_tags = _prompt_enroll_values(args)
		try:
			registration = enroll_with_server(
				config,
				enroll_url,
				enroll_comment,
				enroll_tags,
				enroll_key_cli,
			)
		except Exception as exc:
			logger.exception("Agent enrollment via API failed")
			print(json.dumps({"error": str(exc), "stage": "agent_register"}, indent=2, ensure_ascii=False))
			return 1

		manager.save(config)
		# Initialise le baseline d integrite au premier enrolement: la machine
		# devient "officiellement enrolee" et on fige le hash des fichiers
		# critiques pour pouvoir detecter une tentative de suppression future.
		baseline_info: Optional[Dict[str, Any]] = None
		if bool(_protection_config(config).get("enabled", True)):
			try:
				baseline = agent_protection.update_baseline(AGENT_DIR, RUNTIME_DIR)
				baseline_info = {
					"refreshed": True,
					"generated_at": baseline.get("generated_at"),
				}
			except Exception as exc:
				logger.warning("Failed to initialize integrity baseline at enroll: %s", exc)
				baseline_info = {"refreshed": False, "error": str(exc)}

		logger.info("Agent enrolled to %s", enroll_url)
		response_payload = {
			"enrolled": True,
			"server_url": config.get("server_url"),
			"agent_uuid": registration.get("agent_uuid"),
			"machine_id": registration.get("machine_id"),
			"sync_url": registration.get("sync_url"),
			"commands_pull_url": registration.get("commands_pull_url"),
			"commands_result_url": registration.get("commands_result_url"),
			"tags": config.get("tags", []),
		}
		if baseline_info is not None:
			response_payload["protection_baseline"] = baseline_info
		print(json.dumps(response_payload, indent=2, ensure_ascii=False))
		return 0

	if args.tag and not args.enroll:
		config = manager.set_tags(args.tag, append=True)
		logger.info("Agent tags updated")
		print(json.dumps({"enrolled": config.get("enrolled", False), "tags": config.get("tags", [])}, indent=2, ensure_ascii=False))
		return 0

	if args.unenroll:
		config = manager.unenroll()
		logger.info("Agent unenrolled")
		print(json.dumps({"enrolled": config.get("enrolled", False)}, indent=2))
		return 0

	if args.show_config:
		print(json.dumps(config, indent=2))
		return 0

	if args.update:
		config, update_result, update_code = run_update_check(config, manager, logger)
		if update_code == 0 and isinstance(update_result, dict) and update_result.get("applied_update"):
			# Update legitime => on reconstruit le baseline d integrite pour
			# ne pas confondre la nouvelle version avec du tampering.
			if bool(_protection_config(config).get("baseline_auto_refresh_on_update", True)):
				try:
					baseline = agent_protection.update_baseline(AGENT_DIR, RUNTIME_DIR)
					update_result["protection_baseline"] = {
						"refreshed": True,
						"generated_at": baseline.get("generated_at"),
					}
				except Exception as exc:
					logger.warning("Failed to refresh integrity baseline after update: %s", exc)
					update_result["protection_baseline"] = {
						"refreshed": False,
						"error": str(exc),
					}
			update_result["process_restart"] = _restart_after_update(logger)
		print(json.dumps(update_result, indent=2))
		return update_code

	if args.sync:
		try:
			config, sync_result, sync_code = sync_to_server(config, manager)
		except Exception as exc:
			logger.exception("Manual sync failed")
			print(json.dumps({"error": str(exc), "stage": "agent_sync"}, indent=2, ensure_ascii=False))
			return 1

		remote_code = 0
		remote_out: Any = None
		if bool(config.get("enrolled")):
			try:
				config, remote_out, remote_code = process_remote_forced_commands(
					config, manager, logger, config_path, startup_sync_changed
				)
			except Exception as exc:
				logger.exception("Remote commands after manual sync failed")
				remote_out = {"error": str(exc), "stage": "process_remote_forced_commands"}
				remote_code = 1

		out: Dict[str, Any] = {"sync": sync_result}
		if remote_out is not None:
			out["remote_after_sync"] = remote_out
		logger.info("Manual sync requested (remote_code=%s)", remote_code)
		print(json.dumps(out, indent=2, ensure_ascii=False))
		return 0 if sync_code == 0 and remote_code == 0 else 1

	if args.pull_remote_commands:
		config, remote_result, remote_code = process_remote_forced_commands(
			config,
			manager,
			logger,
			config_path,
			startup_sync_changed,
		)
		print(json.dumps(remote_result, indent=2, ensure_ascii=False))
		return remote_code

	if args.status:
		status_payload = build_status_payload(config, config_path, startup_sync_changed)
		print(json.dumps(status_payload, indent=2))
		return 0

	if args.diagnostic:
		diagnostics = build_diagnostic_payload(config, config_path)
		print(json.dumps(diagnostics, indent=2))
		return 0

	if args.show_log_path:
		print(LOG_FILE_OVERRIDE.as_posix())
		return 0

	if args.enable_auto_scan:
		scheduler = _scheduler_from_config(config)
		try:
			result = scheduler.enable_every_30_minutes()
		except Exception as exc:
			logger.exception("Failed to enable automatic scan schedule")
			print(json.dumps({"error": str(exc)}, indent=2, ensure_ascii=False))
			return 1

		config.setdefault("scheduler", {})["enabled"] = True
		manager.save(config)

		logger.info("Automatic scan enabled every %s minutes", result.get("interval_minutes", "?"))
		print(json.dumps({"auto_scan": "enabled", **result}, indent=2, ensure_ascii=False))
		return 0

	if args.disable_auto_scan:
		scheduler = _scheduler_from_config(config)
		try:
			result = scheduler.disable_every_30_minutes()
		except Exception as exc:
			logger.exception("Failed to disable automatic scan schedule")
			print(json.dumps({"error": str(exc)}, indent=2, ensure_ascii=False))
			return 1

		config.setdefault("scheduler", {})["enabled"] = False
		manager.save(config)

		logger.info("Automatic scan disabled")
		print(json.dumps({"auto_scan": "disabled", **result}, indent=2, ensure_ascii=False))
		return 0

	if args.set_scan_interval is not None:
		new_interval = int(args.set_scan_interval)
		_, response = apply_scan_interval_minutes(
			config, manager, new_interval, logger=logger
		)
		previous = int(response.get("previous_interval_minutes", 0) or 0)
		logger.info(
			"Scan interval changed from %s to %s minutes (reapplied=%s)",
			previous, new_interval, response.get("reapplied"),
		)
		print(json.dumps(response, indent=2, ensure_ascii=False))
		return 0 if "reapply_error" not in response else 1

	if args.check_protection:
		report, alert_result = run_protection_check(config, logger)
		response: Dict[str, Any] = {"protection": report}
		if alert_result is not None:
			response["alert"] = alert_result
		print(json.dumps(response, indent=2, ensure_ascii=False))
		return 0 if not report.get("tampered") else 1

	if args.refresh_protection_baseline:
		baseline = agent_protection.update_baseline(AGENT_DIR, RUNTIME_DIR)
		logger.info("Agent integrity baseline refreshed")
		print(json.dumps({
			"baseline_refreshed": True,
			"generated_at": baseline.get("generated_at"),
			"files": list((baseline.get("files") or {}).keys()),
		}, indent=2, ensure_ascii=False))
		return 0

	if args.check_system_deps:
		report = system_deps.check_dependencies()
		missing_groups = report.get("missing_required_groups") or []
		if missing_groups:
			logger.warning(
				"System dependency audit: missing required groups=%s",
				",".join(missing_groups),
			)
		else:
			logger.info("System dependency audit: all required groups satisfied")
		print(json.dumps(report, indent=2, ensure_ascii=False))
		return 0 if not missing_groups else 1

	if args.install_system_deps or args.install_system_deps_all:
		include_optional = bool(args.install_system_deps_all)
		outcome = system_deps.install_missing_dependencies(
			include_optional=include_optional,
		)
		attempted = bool(outcome.get("attempted"))
		success = bool(outcome.get("success"))
		reason = outcome.get("reason") or "unknown"
		# Raisons "fatales" qui doivent faire echouer la CLI meme si aucune
		# commande n a pu etre tentee (permet a un operateur / la CI de
		# detecter l etat erratique au lieu de croire que tout va bien).
		fatal_reasons = {"elevation_required", "unsupported_package_manager"}
		if attempted:
			logger.info(
				"System deps install: platform=%s success=%s",
				outcome.get("platform"), success,
			)
		elif reason in fatal_reasons:
			logger.error(
				"System deps install blocked: reason=%s message=%s",
				reason, outcome.get("message", ""),
			)
		else:
			logger.info(
				"System deps install skipped: reason=%s", reason,
			)
		print(json.dumps(outcome, indent=2, ensure_ascii=False))
		if attempted:
			return 0 if success else 1
		return 1 if reason in fatal_reasons else 0

	if getattr(args, "install_status", False):
		from core import system_install
		status = system_install.installation_status()
		print(json.dumps(status, indent=2, ensure_ascii=False))
		return 0

	if getattr(args, "install", False):
		from core import system_install
		outcome = system_install.install_agent(force=bool(getattr(args, "force", False)))
		print(json.dumps(outcome, indent=2, ensure_ascii=False))
		if outcome.get("success"):
			# Apres une installation reussie, on rafraichit le baseline
			# d integrite pour refleter l emplacement installe. `update_baseline`
			# est le nom de la fonction exportee par core.protection.
			try:
				agent_protection.update_baseline(AGENT_DIR, RUNTIME_DIR)
				logger.info("Integrity baseline refreshed post-install")
			except Exception:
				logger.exception("Failed to refresh integrity baseline after install")
			return 0
		return 1

	if getattr(args, "uninstall", False):
		from core import system_install
		outcome = system_install.uninstall_agent(purge=bool(getattr(args, "purge", False)))
		print(json.dumps(outcome, indent=2, ensure_ascii=False))
		return 0 if outcome.get("success") else 1

	if getattr(args, "service_run", False):
		return run_service_loop(config, manager, logger, config_path)

	if args.scan:
		# Controle d integrite passif avant le scan, pour detecter une tentative
		# de suppression/modification des fichiers critiques de l agent. En cas
		# de tampering, une alerte est envoyee au serveur sans bloquer le scan.
		try:
			run_protection_check(config, logger)
		except Exception:
			logger.exception("Integrity pre-check failed, continuing with scan")
		payload = run_scan(config, manager)
		if args.output_file:
			output_path = Path(args.output_file)
			if not output_path.is_absolute():
				output_path = Path.cwd() / output_path
		else:
			timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
			output_path = RUNTIME_SCAN_DIR / f"scan_{timestamp}.json"

		output_path.parent.mkdir(parents=True, exist_ok=True)
		output_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
		scan_response: Dict[str, Any] = {
			"scan_saved_to": output_path.as_posix(),
		}
		try:
			config, sync_result, _sync_code = sync_to_server(config, manager, scan_payload=payload)
			synced = bool(sync_result.get("synced", False))
			scan_response["scan_sync"] = sync_result
			if synced:
				scan_response["message"] = "Scan termine et envoye au serveur"
			else:
				scan_response["message"] = "Scan termine, envoi serveur non effectue"
			if bool(config.get("enrolled")):
				try:
					config, remote_out, remote_code = process_remote_forced_commands(
						config, manager, logger, config_path, startup_sync_changed
					)
					scan_response["remote_after_sync"] = remote_out
					scan_response["remote_code"] = remote_code
				except Exception as exc:
					logger.exception("Remote commands after scan sync failed")
					scan_response["remote_after_sync"] = {
						"error": str(exc),
						"stage": "process_remote_forced_commands",
					}
					scan_response["remote_code"] = 1
		except Exception as exc:
			logger.exception("Automatic sync after scan failed")
			scan_response["scan_sync"] = {"synced": False, "error": str(exc)}
			scan_response["message"] = "Scan termine, envoi serveur en echec"

		print(json.dumps(scan_response, indent=2, ensure_ascii=False))
		return 0

	if args.patch is not None:
		if args.patch == "":
			print(json.dumps({"message": "No patch file given. Nothing applied."}, indent=2))
			return 0

		try:
			timeout_seconds = _safe_timeout(
				_agent_api_config(config).get("timeout_seconds", 15), 15
			)
			config, patch_result, patch_code = run_patch_action(
				args.patch, config, manager, logger, timeout_seconds=timeout_seconds
			)
		except (FileNotFoundError, ValueError) as exc:
			print(json.dumps({"error": str(exc), "stage": "patch"}, indent=2, ensure_ascii=False))
			return 1
		except Exception as exc:
			logger.exception("Patch application failed")
			print(json.dumps({"error": str(exc), "stage": "patch"}, indent=2, ensure_ascii=False))
			return 1

		print(json.dumps(patch_result, indent=2, ensure_ascii=False))
		return patch_code

	if args.score:
		payload = run_scan(config, manager)
		score_payload = compute_health_score(payload)
		print(json.dumps(score_payload, indent=2))
		return 0

	parser.print_help()
	return 0


if __name__ == "__main__":
	raise SystemExit(main())
