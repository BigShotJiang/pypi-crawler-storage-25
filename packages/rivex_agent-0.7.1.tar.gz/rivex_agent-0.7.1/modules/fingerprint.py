from __future__ import annotations

import hashlib
import platform
import uuid
from typing import Any, Dict


def _machine_fingerprint() -> str:
    material = "|".join(
        [
            platform.node(),
            platform.platform(),
            str(uuid.getnode()),
            platform.machine(),
        ]
    )
    return hashlib.sha256(material.encode("utf-8", errors="ignore")).hexdigest()


def collect_fingerprint(config: Dict[str, Any]) -> Dict[str, str]:
    agent_uuid = str(config.get("agent_uuid") or "").strip()
    return {
        "agent_uuid": agent_uuid,
        "fingerprint": _machine_fingerprint(),
    }
