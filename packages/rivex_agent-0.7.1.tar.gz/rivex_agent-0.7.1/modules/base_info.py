from __future__ import annotations

import os
import platform
import socket
from pathlib import Path
from typing import Any, Dict


def _detect_ip_address() -> str:
    # Certaines machines Windows sans default gateway (postes offline, VPN avec
    # split-tunnel, certaines VMs) font echouer la connexion UDP vers 8.8.8.8.
    # On combine plusieurs strategies avec fallbacks pour ne jamais renvoyer
    # d adresse invalide qui ferait rater l enrolement.
    candidates = [("8.8.8.8", 80), ("1.1.1.1", 80), ("9.9.9.9", 80)]
    for target_host, target_port in candidates:
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
                sock.settimeout(1.5)
                sock.connect((target_host, target_port))
                address = sock.getsockname()[0]
                if address and address != "0.0.0.0":
                    return address
        except OSError:
            continue

    try:
        hostname = socket.gethostname()
        try:
            infos = socket.getaddrinfo(hostname, None, socket.AF_INET)
            for info in infos:
                address = info[4][0]
                if address and not address.startswith("127."):
                    return address
        except OSError:
            pass
        fallback = socket.gethostbyname(hostname)
        if fallback:
            return fallback
    except OSError:
        pass

    return "127.0.0.1"


def _detect_machine_type() -> str:
    system = platform.system().lower()

    if system == "linux":
        if Path("/.dockerenv").exists():
            return "container"

        cgroup_path = Path("/proc/1/cgroup")
        if cgroup_path.exists():
            text = cgroup_path.read_text(encoding="utf-8", errors="ignore").lower()
            if any(token in text for token in ("docker", "containerd", "kubepods", "lxc")):
                return "container"

        product_name = Path("/sys/class/dmi/id/product_name")
        if product_name.exists():
            text = product_name.read_text(encoding="utf-8", errors="ignore").lower()
            if any(token in text for token in ("kvm", "virtualbox", "vmware", "qemu", "hyper-v")):
                return "vm"

        return "server"

    if system == "windows":
        if os.environ.get("SESSIONNAME", "").upper().startswith("RDP"):
            return "server"
        return "workstation"

    return "computer"


def collect_base_info() -> Dict[str, Any]:
    os_name = platform.system()
    os_version = platform.version()
    return {
        "hostname": socket.gethostname(),
        "ip_address": _detect_ip_address(),
        "os": os_name,
        "machine_type": _detect_machine_type(),
        "os_name": os_name,
        "os_version": os_version,
    }
