from __future__ import annotations

import hashlib
import socket
import ssl
from typing import Any, Dict, Iterable, List, Tuple


DEFAULT_TLS_TARGETS: Tuple[Tuple[str, int], ...] = (
    ("127.0.0.1", 443),
    ("127.0.0.1", 8443),
)


def _extract_dn_value(dn: Iterable[Tuple[Tuple[str, str], ...]], key: str) -> str | None:
    for rdn in dn:
        for item_key, item_value in rdn:
            if item_key == key:
                return item_value
    return None


def collect_certificates(targets: Iterable[Tuple[str, int]] | None = None, timeout: int = 2) -> List[Dict[str, Any]]:
    certs: List[Dict[str, Any]] = []
    target_list = tuple(targets) if targets is not None else DEFAULT_TLS_TARGETS

    context = ssl.create_default_context()
    context.check_hostname = False
    context.verify_mode = ssl.CERT_NONE

    for host, port in target_list:
        try:
            with socket.create_connection((host, port), timeout=timeout) as conn:
                with context.wrap_socket(conn, server_hostname=host) as tls:
                    cert_info = tls.getpeercert()
                    cert_binary = tls.getpeercert(binary_form=True)
        except Exception:
            continue

        subject = cert_info.get("subject", ())
        issuer = cert_info.get("issuer", ())
        certs.append(
            {
                "cn": _extract_dn_value(subject, "commonName"),
                "issuer": _extract_dn_value(issuer, "commonName"),
                "valid_from": cert_info.get("notBefore"),
                "valid_to": cert_info.get("notAfter"),
                "fingerprint": hashlib.sha256(cert_binary).hexdigest(),
            }
        )

    return certs
