from __future__ import annotations

import json
import platform
import shutil
import subprocess
from typing import Any, Dict, List


def _run_command(command: List[str], timeout: int = 20, encoding: str | None = None) -> str:
    result = subprocess.run(
        command,
        capture_output=True,
        text=True,
        encoding=encoding,
        errors="replace",
        timeout=timeout,
        check=False,
    )
    return result.stdout.strip()


def _clean_text(value: Any) -> str | None:
    if value is None:
        return None
    text = str(value).replace("\ufeff", "").replace("\x00", "").replace("\u00ff", " ").strip()
    return " ".join(text.split()) or None


def _collect_windows_software(limit: int) -> List[Dict[str, Any]]:
    powershell_query = (
        "[Console]::OutputEncoding = [System.Text.Encoding]::UTF8;"
        "$OutputEncoding = [System.Text.Encoding]::UTF8;"
        "$items = @(Get-ItemProperty HKLM:\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\*;"
        "Get-ItemProperty HKLM:\\Software\\WOW6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\*);"
        "$items | Where-Object { $_.DisplayName } | "
        "Select-Object DisplayName,DisplayVersion,Publisher | ConvertTo-Json -Depth 3"
    )
    try:
        raw = _run_command(["powershell", "-NoProfile", "-Command", powershell_query], encoding="utf-8")
    except Exception:
        return []

    if not raw:
        return []

    try:
        data = json.loads(raw)
    except json.JSONDecodeError:
        return []

    if isinstance(data, dict):
        data = [data]
    if not isinstance(data, list):
        return []

    output: List[Dict[str, Any]] = []
    for item in data[:limit]:
        if not isinstance(item, dict):
            continue
        output.append(
            {
                "name": _clean_text(item.get("DisplayName")),
                "version": _clean_text(item.get("DisplayVersion")),
                "vendor": _clean_text(item.get("Publisher")),
            }
        )
    return output


def _collect_linux_software(limit: int) -> List[Dict[str, Any]]:
    output: List[Dict[str, Any]] = []

    if shutil.which("dpkg-query"):
        try:
            raw = _run_command(["dpkg-query", "-W", "-f=${Package}\t${Version}\n"])
        except Exception:
            raw = ""

        for line in raw.splitlines()[:limit]:
            package, _, version = line.partition("\t")
            if package:
                output.append({"name": package, "version": version or None, "vendor": None})
        return output

    if shutil.which("rpm"):
        try:
            raw = _run_command(["rpm", "-qa", "--queryformat", "%{NAME}\t%{VERSION}\n"])
        except Exception:
            raw = ""

        for line in raw.splitlines()[:limit]:
            package, _, version = line.partition("\t")
            if package:
                output.append({"name": package, "version": version or None, "vendor": None})
        return output

    return output


def collect_software(limit: int = 400) -> List[Dict[str, Any]]:
    system = platform.system().lower()
    raw_items: List[Dict[str, Any]] = []
    if system == "windows":
        raw_items = _collect_windows_software(limit)
    elif system == "linux":
        raw_items = _collect_linux_software(limit)

    # Some sources (notably Windows registry uninstall keys) can expose duplicates.
    # Keep only the first unique (name, version) tuple to prevent backend sync failures.
    deduped: List[Dict[str, Any]] = []
    seen: set[tuple[str, str]] = set()
    for item in raw_items:
        if not isinstance(item, dict):
            continue
        name = _clean_text(item.get("name"))
        if not name:
            continue
        version = _clean_text(item.get("version"))
        vendor = _clean_text(item.get("vendor"))

        key = (name.casefold(), (version or "").casefold())
        if key in seen:
            continue
        seen.add(key)
        deduped.append(
            {
                "name": name,
                "version": version,
                "vendor": vendor,
            }
        )

    return deduped
