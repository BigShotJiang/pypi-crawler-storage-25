from __future__ import annotations

import json
import platform
import shutil
import subprocess
import time
from typing import Any, Dict

def _to_gb(value: float) -> float:
    return round(value / (1024 ** 3), 2)


def _load_psutil() -> Any | None:
    try:
        import psutil  # type: ignore
    except ImportError:
        return None
    return psutil


def _run_command(command: list[str], timeout: int = 15, encoding: str | None = None) -> str:
    result = subprocess.run(
        command,
        capture_output=True,
        text=True,
        encoding=encoding,
        errors="replace",
        timeout=timeout,
        check=False,
    )
    return result.stdout.strip()


def _collect_metrics_windows_fallback() -> Dict[str, Any]:
    root_path = "C:\\"
    disk = shutil.disk_usage(root_path)

    powershell_query = (
        "[Console]::OutputEncoding = [System.Text.Encoding]::UTF8;"
        "$os = Get-CimInstance Win32_OperatingSystem;"
        "$cpu = (Get-CimInstance Win32_Processor | Measure-Object -Property LoadPercentage -Average).Average;"
        "$uptime = [int]((Get-Date) - $os.LastBootUpTime).TotalSeconds;"
        "[PSCustomObject]@{"
        "cpu = [double]$cpu;"
        "total_kb = [double]$os.TotalVisibleMemorySize;"
        "free_kb = [double]$os.FreePhysicalMemory;"
        "uptime = $uptime"
        "} | ConvertTo-Json -Compress"
    )

    cpu_percent: float | None = None
    ram_total_gb: float | None = None
    ram_used_gb: float | None = None
    ram_percent: float | None = None
    uptime_seconds: int | None = None

    try:
        raw = _run_command(["powershell", "-NoProfile", "-Command", powershell_query], encoding="utf-8")
        if raw:
            data = json.loads(raw)
            total_kb = float(data.get("total_kb", 0.0))
            free_kb = float(data.get("free_kb", 0.0))
            used_kb = max(0.0, total_kb - free_kb)

            cpu_raw = data.get("cpu")
            cpu_percent = round(float(cpu_raw), 2) if cpu_raw is not None else None
            ram_total_gb = round(total_kb / (1024 ** 2), 2) if total_kb > 0 else None
            ram_used_gb = round(used_kb / (1024 ** 2), 2) if used_kb >= 0 else None
            ram_percent = round((used_kb / total_kb) * 100, 2) if total_kb > 0 else None
            uptime_raw = data.get("uptime")
            uptime_seconds = int(uptime_raw) if uptime_raw is not None else None
    except Exception:
        pass

    metrics: Dict[str, Any] = {
        "cpu_percent": cpu_percent,
        "ram_total_gb": ram_total_gb,
        "ram_used_gb": ram_used_gb,
        "ram_percent": ram_percent,
        "disk_total_gb": _to_gb(float(disk.total)),
        "disk_used_gb": _to_gb(float(disk.used)),
        "disk_percent": round((float(disk.used) / float(disk.total)) * 100, 2) if disk.total else None,
        "uptime_seconds": uptime_seconds,
        "note": "Fallback metrics without psutil",
    }
    return metrics


def _read_linux_cpu_percent() -> float | None:
    def read_cpu() -> tuple[int, int]:
        with open("/proc/stat", "r", encoding="utf-8") as handle:
            line = handle.readline().strip()
        parts = [int(item) for item in line.split()[1:8]]
        idle = parts[3] + parts[4]
        total = sum(parts)
        return idle, total

    try:
        idle_1, total_1 = read_cpu()
        time.sleep(0.2)
        idle_2, total_2 = read_cpu()
    except Exception:
        return None

    total_delta = total_2 - total_1
    idle_delta = idle_2 - idle_1
    if total_delta <= 0:
        return None
    usage = (1.0 - (idle_delta / total_delta)) * 100
    return round(usage, 2)


def _collect_metrics_linux_fallback() -> Dict[str, Any]:
    disk = shutil.disk_usage("/")

    mem_total_kb = 0.0
    mem_available_kb = 0.0
    try:
        with open("/proc/meminfo", "r", encoding="utf-8") as handle:
            for line in handle:
                if line.startswith("MemTotal:"):
                    mem_total_kb = float(line.split()[1])
                elif line.startswith("MemAvailable:"):
                    mem_available_kb = float(line.split()[1])
    except Exception:
        pass

    used_kb = max(0.0, mem_total_kb - mem_available_kb)

    uptime_seconds: int | None = None
    try:
        with open("/proc/uptime", "r", encoding="utf-8") as handle:
            uptime_seconds = int(float(handle.read().split()[0]))
    except Exception:
        pass

    metrics: Dict[str, Any] = {
        "cpu_percent": _read_linux_cpu_percent(),
        "ram_total_gb": round(mem_total_kb / (1024 ** 2), 2) if mem_total_kb > 0 else None,
        "ram_used_gb": round(used_kb / (1024 ** 2), 2) if used_kb >= 0 else None,
        "ram_percent": round((used_kb / mem_total_kb) * 100, 2) if mem_total_kb > 0 else None,
        "disk_total_gb": _to_gb(float(disk.total)),
        "disk_used_gb": _to_gb(float(disk.used)),
        "disk_percent": round((float(disk.used) / float(disk.total)) * 100, 2) if disk.total else None,
        "uptime_seconds": uptime_seconds,
        "note": "Fallback metrics without psutil",
    }
    return metrics


def _add_db_aliases(metrics: Dict[str, Any]) -> Dict[str, Any]:
    cpu_percent = metrics.get("cpu_percent")
    ram_used_gb = metrics.get("ram_used_gb")
    disk_total_gb = metrics.get("disk_total_gb")
    uptime_seconds = metrics.get("uptime_seconds")

    metrics["cpu"] = int(round(float(cpu_percent))) if isinstance(cpu_percent, (int, float)) else None
    metrics["ram"] = float(ram_used_gb) if isinstance(ram_used_gb, (int, float)) else None
    metrics["disk_size"] = float(disk_total_gb) if isinstance(disk_total_gb, (int, float)) else None
    metrics["uptime"] = int(uptime_seconds) if isinstance(uptime_seconds, (int, float)) else None
    return metrics


def collect_metrics() -> Dict[str, Any]:
    psutil_module = _load_psutil()
    if psutil_module is not None:
        root_path = "C:\\" if platform.system().lower() == "windows" else "/"
        vm = psutil_module.virtual_memory()
        disk = psutil_module.disk_usage(root_path)
        metrics = {
            "cpu_percent": round(psutil_module.cpu_percent(interval=0.3), 2),
            "ram_total_gb": _to_gb(float(vm.total)),
            "ram_used_gb": _to_gb(float(vm.used)),
            "ram_percent": round(float(vm.percent), 2),
            "disk_total_gb": _to_gb(float(disk.total)),
            "disk_used_gb": _to_gb(float(disk.used)),
            "disk_percent": round(float(disk.percent), 2),
            "uptime_seconds": int(time.time() - psutil_module.boot_time()),
        }
        return _add_db_aliases(metrics)

    if platform.system().lower() == "windows":
        return _add_db_aliases(_collect_metrics_windows_fallback())
    if platform.system().lower() == "linux":
        return _add_db_aliases(_collect_metrics_linux_fallback())

    metrics = {
        "cpu_percent": None,
        "ram_total_gb": None,
        "ram_used_gb": None,
        "ram_percent": None,
        "disk_total_gb": None,
        "disk_used_gb": None,
        "disk_percent": None,
        "uptime_seconds": None,
        "note": "Metrics not supported on this OS",
    }
    return _add_db_aliases(metrics)
