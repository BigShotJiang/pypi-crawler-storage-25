from __future__ import annotations

import platform
import socket
import subprocess
from typing import Any, Dict, List, Set, Tuple

HTTP_PORTS = {80, 443, 8080, 8443, 8000, 3000, 5000}


def _load_psutil() -> Any | None:
    try:
        import psutil  # type: ignore
    except ImportError:
        return None
    return psutil


def _run_command(command: List[str], timeout: int = 20, encoding: str | None = None) -> str:
    result = subprocess.run(
        command,
        capture_output=True,
        text=True,
        encoding=encoding,
        errors="replace",
        timeout=timeout,
        check=False,
    )
    return result.stdout.strip()


def _service_name(port: int, protocol: str) -> str | None:
    try:
        proto = "tcp" if protocol == "tcp" else "udp"
        return socket.getservbyport(port, proto)
    except OSError:
        return None


def _extract_port(local_endpoint: str) -> int | None:
    endpoint = local_endpoint.strip("[]")
    if ":" not in endpoint:
        return None
    port_candidate = endpoint.rsplit(":", 1)[-1]
    if not port_candidate.isdigit():
        return None
    return int(port_candidate)


def _collect_ports_psutil() -> List[Dict[str, Any]]:
    psutil_module = _load_psutil()
    if psutil_module is None:
        return []

    ports: List[Dict[str, Any]] = []
    seen: Set[Tuple[int, str]] = set()

    try:
        connections = psutil_module.net_connections(kind="inet")
    except Exception:
        return []

    for conn in connections:
        if not conn.laddr:
            continue

        status = (conn.status or "").lower()
        protocol = "tcp" if conn.type == socket.SOCK_STREAM else "udp"

        if protocol == "tcp" and status != "listen":
            continue

        port = int(conn.laddr.port)
        key = (port, protocol)
        if key in seen:
            continue

        ports.append(
            {
                "port": port,
                "protocol": protocol,
                "status": "open",
                "service_name": _service_name(port, protocol),
            }
        )
        seen.add(key)

    ports.sort(key=lambda item: (item["port"], item["protocol"]))
    return ports


def _collect_ports_windows_fallback() -> List[Dict[str, Any]]:
    try:
        raw = _run_command(["netstat", "-ano"], encoding="utf-8")
    except Exception:
        return []

    ports: List[Dict[str, Any]] = []
    seen: Set[Tuple[int, str]] = set()

    for line in raw.splitlines():
        text = line.strip()
        if not text:
            continue
        if not (text.startswith("TCP") or text.startswith("UDP")):
            continue

        parts = text.split()
        proto = parts[0].lower()
        if proto not in ("tcp", "udp"):
            continue

        if proto == "tcp":
            if len(parts) < 4 or parts[3].upper() != "LISTENING":
                continue
            local = parts[1]
        else:
            if len(parts) < 2:
                continue
            local = parts[1]

        port = _extract_port(local)
        if port is None:
            continue

        key = (port, proto)
        if key in seen:
            continue
        seen.add(key)

        ports.append(
            {
                "port": port,
                "protocol": proto,
                "status": "open",
                "service_name": _service_name(port, proto),
            }
        )

    ports.sort(key=lambda item: (item["port"], item["protocol"]))
    return ports


def _collect_ports_linux_fallback() -> List[Dict[str, Any]]:
    try:
        raw = _run_command(["ss", "-lntu"])
    except Exception:
        return []

    ports: List[Dict[str, Any]] = []
    seen: Set[Tuple[int, str]] = set()

    for line in raw.splitlines():
        text = line.strip()
        if not text or text.lower().startswith("netid"):
            continue

        parts = text.split()
        if len(parts) < 5:
            continue

        proto = parts[0].lower()
        if proto not in ("tcp", "udp"):
            continue

        local = parts[4]
        port = _extract_port(local)
        if port is None:
            continue

        key = (port, proto)
        if key in seen:
            continue
        seen.add(key)

        ports.append(
            {
                "port": port,
                "protocol": proto,
                "status": "open",
                "service_name": _service_name(port, proto),
            }
        )

    ports.sort(key=lambda item: (item["port"], item["protocol"]))
    return ports


def _collect_ports_system_fallback() -> List[Dict[str, Any]]:
    system = platform.system().lower()
    if system == "windows":
        return _collect_ports_windows_fallback()
    if system == "linux":
        return _collect_ports_linux_fallback()
    return []


def _merge_ports(*sources: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    merged: List[Dict[str, Any]] = []
    seen: Set[Tuple[int, str]] = set()

    for source in sources:
        for item in source:
            port = item.get("port")
            protocol = item.get("protocol")
            if not isinstance(port, int) or not isinstance(protocol, str):
                continue
            key = (port, protocol.lower())
            if key in seen:
                continue
            seen.add(key)
            merged.append(item)

    merged.sort(key=lambda item: (item["port"], item["protocol"]))
    return merged


def _infer_http_endpoints(ports: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    endpoints: List[Dict[str, Any]] = []
    for port_data in ports:
        port = int(port_data.get("port", 0))
        if port not in HTTP_PORTS:
            continue

        scheme = "https" if port in (443, 8443) else "http"
        url = f"{scheme}://127.0.0.1:{port}/"
        endpoints.append({"method": "GET", "url": url})
    return endpoints


def collect_network() -> Dict[str, Any]:
    ports = _merge_ports(_collect_ports_psutil(), _collect_ports_system_fallback())
    endpoints = _infer_http_endpoints(ports)
    return {
        "ports": ports,
        "http_endpoints": endpoints,
    }
