from __future__ import annotations

import json
import platform
import subprocess
from typing import Any, Dict, List


def _run_command(command: List[str], timeout: int = 20, encoding: str | None = None) -> str:
    result = subprocess.run(
        command,
        capture_output=True,
        text=True,
        encoding=encoding,
        errors="replace",
        timeout=timeout,
        check=False,
    )
    return result.stdout.strip()


def _clean_text(value: Any) -> str | None:
    if value is None:
        return None
    text = str(value).replace("\ufeff", "").replace("\x00", "").strip()
    return " ".join(text.split()) or None


def _collect_windows_services(limit: int) -> List[Dict[str, Any]]:
    powershell_query = (
        "[Console]::OutputEncoding = [System.Text.Encoding]::UTF8;"
        "$OutputEncoding = [System.Text.Encoding]::UTF8;"
        "Get-Service | Where-Object { $_.Status -eq 'Running' } | "
        "Select-Object Name,DisplayName,@{Name='StatusText';Expression={$_.Status.ToString()}} | "
        "ConvertTo-Json -Depth 3"
    )
    try:
        raw = _run_command(["powershell", "-NoProfile", "-Command", powershell_query], encoding="utf-8")
    except Exception:
        return []

    if not raw:
        return []

    try:
        data = json.loads(raw)
    except json.JSONDecodeError:
        return []

    if isinstance(data, dict):
        data = [data]
    if not isinstance(data, list):
        return []

    services: List[Dict[str, Any]] = []
    for item in data[:limit]:
        if not isinstance(item, dict):
            continue
        services.append(
            {
                "name": _clean_text(item.get("Name")),
                "version": None,
                "product": _clean_text(item.get("DisplayName")),
                "port": None,
                "banner": _clean_text(item.get("StatusText")) or "running",
            }
        )
    return services


def _collect_linux_services(limit: int) -> List[Dict[str, Any]]:
    try:
        raw = _run_command(
            [
                "systemctl",
                "list-units",
                "--type=service",
                "--state=running",
                "--no-pager",
                "--no-legend",
            ]
        )
    except Exception:
        return []

    services: List[Dict[str, Any]] = []
    for line in raw.splitlines()[:limit]:
        columns = line.split()
        if not columns:
            continue
        unit_name = columns[0]
        product = " ".join(columns[4:]) if len(columns) >= 5 else unit_name
        services.append(
            {
                "name": unit_name,
                "version": None,
                "product": product,
                "port": None,
                "banner": "running",
            }
        )
    return services


def collect_services(limit: int = 300) -> List[Dict[str, Any]]:
    system = platform.system().lower()
    if system == "windows":
        return _collect_windows_services(limit)
    if system == "linux":
        return _collect_linux_services(limit)
    return []
