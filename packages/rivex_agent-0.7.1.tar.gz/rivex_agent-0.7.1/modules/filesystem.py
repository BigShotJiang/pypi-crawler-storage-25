from __future__ import annotations

import hashlib
import os
import platform
from pathlib import Path
from typing import Any, Dict, List


def _default_roots() -> List[str]:
    if platform.system().lower() == "windows":
        return [r"C:\Windows\System32\drivers\etc"]
    return ["/etc", "/var/log"]


def _sha256_file(path: Path) -> str | None:
    digest = hashlib.sha256()
    try:
        with path.open("rb") as handle:
            while True:
                chunk = handle.read(8192)
                if not chunk:
                    break
                digest.update(chunk)
    except (OSError, PermissionError):
        return None
    return digest.hexdigest()


def collect_files(scan_config: Dict[str, Any] | None = None) -> List[Dict[str, Any]]:
    config = scan_config or {}
    roots = config.get("file_roots") or _default_roots()
    max_files = int(config.get("max_files", 200))

    collected: List[Dict[str, Any]] = []
    for root in roots:
        root_path = Path(root)
        if not root_path.exists():
            continue

        for current_dir, _, file_names in os.walk(root_path):
            for file_name in file_names:
                file_path = Path(current_dir) / file_name
                try:
                    file_size = file_path.stat().st_size
                except (OSError, PermissionError):
                    file_size = None

                collected.append(
                    {
                        "path": file_path.as_posix(),
                        "hash": _sha256_file(file_path),
                        "size": file_size,
                    }
                )

                if len(collected) >= max_files:
                    return collected

    return collected
