# This source code is licensed under the S-Lab License 1.0 found in the
# LICENSE file in the current directory.
"""
The code has been adopted from FAST-VQA-and-FasterVQA
(https://github.com/VQAssessment/FAST-VQA-and-FasterVQA/blob/dev/fastvqa/version.py)
"""


__version__ = "3.1.0"


def parse_version_info(version_str):
    version_info = []
    for x in version_str.split("."):
        if x.isdigit():
            version_info.append(int(x))
        elif x.find("rc") != -1:
            patch_version = x.split("rc")
            version_info.append(int(patch_version[0]))
            version_info.append(f"rc{patch_version[1]}")
    return tuple(version_info)


version_info = parse_version_info(__version__)
