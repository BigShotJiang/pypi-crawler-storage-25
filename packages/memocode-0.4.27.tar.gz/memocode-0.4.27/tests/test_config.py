"""Tests for control/chatmem/config.py"""
import os
import sys

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from control.chatmem.config import (
    DEFAULT_DIMENSIONS,
    DimensionConfig,
    ContextConfig,
    LLMConfig,
)


def test_default_dimensions_keys():
    assert set(DEFAULT_DIMENSIONS.keys()) == {"interaction_style", "delegation"}


def test_default_dimensions_stability():
    assert DEFAULT_DIMENSIONS["interaction_style"].stability == 30.0
    assert DEFAULT_DIMENSIONS["delegation"].stability == 35.0


def test_default_dimensions_labels():
    assert DEFAULT_DIMENSIONS["interaction_style"].label == "Interaction Style"
    assert DEFAULT_DIMENSIONS["delegation"].label == "Delegation"


def test_context_config_defaults_to_default_dimensions():
    cfg = ContextConfig()
    assert set(cfg.dimensions.keys()) == {"interaction_style", "delegation"}


def test_context_config_from_dict_custom_dimensions():
    data = {
        "dimensions": {
            "custom_dim": {"label": "Custom", "stability": 20.0}
        }
    }
    cfg = ContextConfig.from_dict(data)
    assert "custom_dim" in cfg.dimensions
    assert cfg.dimensions["custom_dim"].stability == 20.0


def test_context_config_from_dict_empty_uses_defaults():
    cfg = ContextConfig.from_dict({})
    assert set(cfg.dimensions.keys()) == {"interaction_style", "delegation"}


def test_context_config_from_dict_llm_fields():
    data = {
        "llm": {
            "model": "gpt-4o",
            "context_window": 64000,
            "provider": "openai",
        }
    }
    cfg = ContextConfig.from_dict(data)
    assert cfg.llm.model == "gpt-4o"
    assert cfg.llm.context_window == 64000


def test_context_config_to_dict_round_trip():
    cfg = ContextConfig(
        dimensions={"interaction_style": DimensionConfig(label="IS", stability=30.0)},
        llm=LLMConfig(model="gpt-4o-mini"),
    )
    d = cfg.to_dict()
    cfg2 = ContextConfig.from_dict(d)
    assert cfg2.dimensions["interaction_style"].stability == 30.0
    assert cfg2.llm.model == "gpt-4o-mini"


def test_context_config_from_json(tmp_path):
    import json
    config_file = tmp_path / "config.json"
    config_file.write_text(json.dumps({
        "llm": {"model": "test-model"},
        "dimensions": {
            "interaction_style": {"label": "IS", "stability": 30.0},
            "delegation": {"label": "DL", "stability": 35.0},
        }
    }))
    cfg = ContextConfig.from_json(str(config_file))
    assert cfg.llm.model == "test-model"
    assert "interaction_style" in cfg.dimensions


def test_llm_config_resolve_api_key_direct():
    llm = LLMConfig(api_key="sk-test")
    assert llm.resolve_api_key() == "sk-test"


def test_llm_config_resolve_api_key_from_env(monkeypatch):
    monkeypatch.setenv("MY_API_KEY", "sk-from-env")
    llm = LLMConfig(api_key_env="MY_API_KEY")
    assert llm.resolve_api_key() == "sk-from-env"


def test_llm_config_resolve_api_key_missing():
    llm = LLMConfig()
    assert llm.resolve_api_key() is None
