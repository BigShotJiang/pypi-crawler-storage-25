"""Tests for control/chatmem/compressor.py — pure utility functions + real LLM compression"""
import os
import sys

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from control.chatmem.compressor import (
    _extract_json_array,
    _detect_compression_mode,
    _is_chinese,
    Compressor,
)


# ── _extract_json_array ───────────────────────────────────────────────────────

def test_extract_clean_json():
    raw = '[{"key": "a", "value": "b"}]'
    result = _extract_json_array(raw)
    assert result == [{"key": "a", "value": "b"}]


def test_extract_with_think_block():
    raw = '<think>reasoning here</think>\n[{"key": "x", "value": "y"}]'
    result = _extract_json_array(raw)
    assert result == [{"key": "x", "value": "y"}]


def test_extract_empty_array():
    result = _extract_json_array("[]")
    assert result == []


def test_extract_no_array_returns_empty():
    result = _extract_json_array("no json here")
    assert result == []


def test_extract_invalid_json_returns_empty():
    result = _extract_json_array("[{broken json")
    assert result == []


def test_extract_multiline_array():
    raw = '[\n  {"key": "a", "value": "b"},\n  {"key": "c", "value": "d"}\n]'
    result = _extract_json_array(raw)
    assert len(result) == 2


def test_extract_array_with_surrounding_text():
    raw = 'Here is the result:\n[{"key": "test"}]\nEnd.'
    result = _extract_json_array(raw)
    assert result == [{"key": "test"}]


# ── _detect_compression_mode ──────────────────────────────────────────────────

def test_detect_code_fenced_block():
    text = "Here is the fix:\n```python\ndef foo(): pass\n```"
    assert _detect_compression_mode(text) == "code"


def test_detect_code_file_extension():
    assert _detect_compression_mode("Edit control/brain.py to fix this") == "code"


def test_detect_code_import_statement():
    assert _detect_compression_mode("import os\nimport sys") == "code"


def test_detect_code_def_statement():
    assert _detect_compression_mode("def my_function():\n    pass") == "code"


def test_detect_code_traceback():
    text = "Traceback (most recent call last):\n  File \"foo.py\", line 5"
    assert _detect_compression_mode(text) == "code"


def test_detect_code_shell_prompt():
    assert _detect_compression_mode("$ npm install\n$ npm test") == "code"


def test_detect_plan_no_code_signals():
    text = "We should redesign the architecture to improve scalability. The main concern is latency."
    assert _detect_compression_mode(text) == "plan"


# ── _is_chinese ───────────────────────────────────────────────────────────────

def test_is_chinese_true():
    assert _is_chinese("你好世界") is True


def test_is_chinese_false_english():
    assert _is_chinese("Hello world") is False


def test_is_chinese_mixed_prefers_chinese():
    assert _is_chinese("这是一个测试 test") is True


def test_is_chinese_empty():
    assert _is_chinese("") is False


# ── Compressor.compress_for_session_context (real LLM) ───────────────────────

@pytest.fixture
def compressor(llm_cfg):
    return Compressor(
        api_key=llm_cfg["api_key"],
        model=llm_cfg["model"],
        base_url=llm_cfg["base_url"],
    )


def test_compress_returns_nonempty_string(compressor):
    conversation = (
        "user: 帮我实现一个快速排序算法\n"
        "assistant: 好的，这是快速排序的实现：\n```python\ndef quicksort(arr): ...\n```\n"
        "user: 能加上注释吗\n"
        "assistant: 当然，已添加注释。"
    )
    result = compressor.compress_for_session_context(conversation)
    assert isinstance(result, str)
    assert len(result) > 20


def test_compress_code_mode_shorter_than_original(compressor):
    conversation = "\n".join([
        f"user: 问题{i}\nassistant: 回答{i}，详细解释如下：" + "内容 " * 50
        for i in range(5)
    ])
    result = compressor.compress_for_session_context(conversation, mode="code")
    assert len(result) < len(conversation)


def test_compress_plan_mode_preserves_key_facts(compressor):
    conversation = (
        "user: 我们的 API key 是 sk-test-12345，服务器地址是 192.168.1.100\n"
        "assistant: 好的，已记录。\n"
        "user: 截止日期是2026-05-01\n"
        "assistant: 明白，已记录截止日期。"
    )
    result = compressor.compress_for_session_context(conversation, mode="plan")
    # plan mode should preserve specific values
    assert "2026-05-01" in result or "05-01" in result or "5月" in result or "May" in result


def test_compress_auto_mode_detects_code(compressor):
    conversation = (
        "user: fix this function\n"
        "assistant: ```python\ndef foo(): pass\n```"
    )
    result = compressor.compress_for_session_context(conversation, mode="auto")
    assert isinstance(result, str)
    assert len(result) > 0


def test_compress_chinese_conversation(compressor):
    conversation = (
        "user: 这个项目的架构是什么\n"
        "assistant: 项目采用MVC架构，分为三层：控制层、业务层、数据层。\n"
        "user: 好的，数据库用什么\n"
        "assistant: 使用SQLite作为本地存储。"
    )
    result = compressor.compress_for_session_context(conversation)
    assert isinstance(result, str)
    assert len(result) > 0
