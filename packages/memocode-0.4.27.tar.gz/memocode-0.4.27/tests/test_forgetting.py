"""Tests for control/chatmem/memory/forgetting.py"""
import math
import os
import sys
import time

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from control.chatmem.memory.forgetting import compute_score, ForgettingManager
from control.chatmem.memory.core_memory import CoreMemory
from control.chatmem.config import DimensionConfig


DIMS = {
    "interaction_style": DimensionConfig(label="Interaction Style", stability=30.0),
    "delegation":        DimensionConfig(label="Delegation",        stability=35.0),
}


def test_compute_score_fresh_entry():
    # Just created — score should be very close to 1.0
    score = compute_score(created_at=time.time(), stability=30.0)
    assert score > 0.99


def test_compute_score_decays_over_time():
    old_time = time.time() - 30 * 86400  # 30 days ago
    score = compute_score(created_at=old_time, stability=30.0)
    # e^(-30/30) = e^-1 ≈ 0.368
    assert abs(score - math.exp(-1)) < 0.01


def test_compute_score_never_exceeds_one():
    score = compute_score(created_at=time.time() + 1000, stability=30.0)
    assert score <= 1.0


def test_compute_score_uses_last_accessed():
    old_created = time.time() - 60 * 86400
    recent_access = time.time() - 1 * 86400  # accessed yesterday
    score_with_access = compute_score(old_created, stability=30.0, last_accessed_at=recent_access)
    score_without = compute_score(old_created, stability=30.0)
    assert score_with_access > score_without


def test_compute_score_higher_stability_slower_decay():
    old_time = time.time() - 10 * 86400
    score_stable = compute_score(old_time, stability=50.0)
    score_fragile = compute_score(old_time, stability=10.0)
    assert score_stable > score_fragile


def test_forgetting_manager_run_decay(tmp_path):
    cm = CoreMemory(
        db_path=str(tmp_path / "core.db"),
        api_key="test",
        model="test",
        dimensions=DIMS,
    )
    # Write a fresh entry
    cm.set("delegation", "高委托", dimension="delegation")

    fm = ForgettingManager(cm)
    fm.run_decay()

    entries = cm.get_all_with_scores()
    match = next(e for e in entries if e["key"] == "delegation")
    # Score should still be very high (entry is fresh)
    assert match["score"] > 0.9


def test_forgetting_manager_decays_old_entry(tmp_path):
    import sqlite3
    cm = CoreMemory(
        db_path=str(tmp_path / "core.db"),
        api_key="test",
        model="test",
        dimensions=DIMS,
    )
    old_time = time.time() - 60 * 86400  # 60 days ago
    with sqlite3.connect(cm.db_path) as conn:
        conn.execute(
            "INSERT INTO core_memory (key, value, dimension, stability, score, created_at, updated_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?)",
            ("delegation", "高委托", "delegation", 30.0, 1.0, old_time, old_time),
        )

    fm = ForgettingManager(cm)
    fm.run_decay()

    entries = cm.get_all_with_scores()
    match = next(e for e in entries if e["key"] == "delegation")
    # e^(-60/30) = e^-2 ≈ 0.135
    assert match["score"] < 0.2
