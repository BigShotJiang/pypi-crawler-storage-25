"""Tests for brain._project_context_fn — unified project memory + tasks context injection"""
import os
import sys
import types

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from control.chatmem.memory.core_memory import CoreMemory
from control.chatmem.config import DimensionConfig
from control.tasks import TaskManager


PROJECT_DIMS = {
    "context":   DimensionConfig(label="Project context", stability=30.0),
    "decisions": DimensionConfig(label="Decisions",       stability=35.0),
}


def make_brain_stub(tmp_path, with_pm=True, with_tasks=True):
    """
    Minimal stub that has project_memory and tasks attributes,
    and the _project_context_fn method copied from Brain.
    """
    import importlib, inspect
    brain_mod = importlib.import_module("control.brain")
    Brain = brain_mod.Brain

    stub = types.SimpleNamespace()

    if with_pm:
        pm = CoreMemory(
            db_path=str(tmp_path / "proj.db"),
            api_key="test",
            model="test",
            dimensions=PROJECT_DIMS,
            context_label="Project Memory",
        )
        stub.project_memory = pm
    else:
        stub.project_memory = None

    if with_tasks:
        tm = TaskManager(project="test")
        tm._path = str(tmp_path / "tasks.json")
        stub.tasks = tm
    else:
        pass  # no tasks attr

    # Bind the method from Brain
    stub._project_context_fn = Brain._project_context_fn.__get__(stub, type(stub))
    return stub


def test_empty_project_memory_and_no_tasks(tmp_path):
    stub = make_brain_stub(tmp_path)
    result = stub._project_context_fn()
    assert result == ""


def test_project_memory_shown(tmp_path):
    stub = make_brain_stub(tmp_path)
    stub.project_memory.set("context", "Python CLI agent", dimension="context")
    result = stub._project_context_fn()
    assert "Python CLI agent" in result


def test_open_tasks_shown(tmp_path):
    stub = make_brain_stub(tmp_path)
    stub.tasks.add("Fix Safari crash", "Login page crashes on Safari")
    result = stub._project_context_fn()
    assert "Fix Safari crash" in result
    assert "Open Tasks" in result


def test_done_tasks_not_shown(tmp_path):
    stub = make_brain_stub(tmp_path)
    t = stub.tasks.add("Old task")
    stub.tasks.done(t["id"])
    result = stub._project_context_fn()
    assert "Old task" not in result


def test_project_memory_and_tasks_combined(tmp_path):
    stub = make_brain_stub(tmp_path)
    stub.project_memory.set("context", "mcode project", dimension="context")
    stub.tasks.add("Bug #1")
    stub.tasks.add("Bug #2")
    result = stub._project_context_fn()
    assert "mcode project" in result
    assert "Bug #1" in result
    assert "Bug #2" in result


def test_no_project_memory_only_tasks(tmp_path):
    stub = make_brain_stub(tmp_path, with_pm=False)
    stub.tasks.add("Task A")
    result = stub._project_context_fn()
    assert "Task A" in result
    assert "Open Tasks" in result


def test_task_description_shown(tmp_path):
    stub = make_brain_stub(tmp_path)
    stub.tasks.add("Fix crash", "Detailed description of crash")
    result = stub._project_context_fn()
    assert "Detailed description of crash" in result


def test_no_tasks_attr_no_crash(tmp_path):
    stub = make_brain_stub(tmp_path, with_tasks=False)
    stub.project_memory.set("context", "test", dimension="context")
    result = stub._project_context_fn()
    assert "test" in result


def test_multiple_open_tasks_all_shown(tmp_path):
    stub = make_brain_stub(tmp_path)
    for i in range(5):
        stub.tasks.add(f"Task {i}")
    result = stub._project_context_fn()
    for i in range(5):
        assert f"Task {i}" in result


def test_cancelled_tasks_not_shown(tmp_path):
    stub = make_brain_stub(tmp_path)
    t = stub.tasks.add("Cancelled task")
    stub.tasks.cancel(t["id"])
    result = stub._project_context_fn()
    assert "Cancelled task" not in result
