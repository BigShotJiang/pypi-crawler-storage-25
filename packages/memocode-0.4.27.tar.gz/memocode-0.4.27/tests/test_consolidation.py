"""Tests for control/chatmem/memory/consolidation.py — real LLM calls"""
import os
import sys

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from control.chatmem.memory.consolidation import ConsolidationTask
from control.chatmem.memory.core_memory import CoreMemory
from control.chatmem.memory.recent_memory import RecentMemory
from control.chatmem.compressor import Compressor
from control.chatmem.config import DimensionConfig

DIMS = {
    "interaction_style": DimensionConfig(label="Interaction Style", stability=30.0),
    "delegation":        DimensionConfig(label="Delegation",        stability=35.0),
}

VALID_DIMS = set(DIMS.keys())

DELEGATION_SESSIONS = [
    "用户说：直接帮我做就行，不用给选项。AI立即执行。",
    "用户说：不用解释，直接实现。AI直接写代码。",
    "用户说：你来决定就好，直接做。AI直接执行。",
]

INTERACTION_SESSIONS = [
    "用户全程使用中文，消息简短，偏好列表格式。",
    "用户再次以中文简短提问，要求简洁回答。",
    "用户：一句话概括。AI：简洁回答。",
]


@pytest.fixture
def core_mem(tmp_path):
    return CoreMemory(
        db_path=str(tmp_path / "core.db"),
        api_key="test",
        model="test",
        dimensions=DIMS,
    )


@pytest.fixture
def recent_mem(tmp_path, llm_cfg):
    compressor = Compressor(
        api_key=llm_cfg["api_key"],
        model=llm_cfg["model"],
        base_url=llm_cfg["base_url"],
    )
    return RecentMemory(db_path=str(tmp_path / "recent.db"), compressor=compressor)


def make_task(core_mem, llm_cfg, recent_mem, lookback=20):
    return ConsolidationTask(
        recent_memory=recent_mem,
        core_memory=core_mem,
        api_key=llm_cfg["api_key"],
        model=llm_cfg["model"],
        base_url=llm_cfg["base_url"],
        lookback=lookback,
    )


# ── no LLM ────────────────────────────────────────────────────────────────────

def test_consolidation_empty_recent_skips_llm(core_mem, llm_cfg, recent_mem):
    task = make_task(core_mem, llm_cfg, recent_mem)
    result = task.run()
    assert result == []


# ── real LLM ──────────────────────────────────────────────────────────────────

def test_consolidation_returns_list(core_mem, llm_cfg, recent_mem):
    for i, s in enumerate(DELEGATION_SESSIONS):
        recent_mem.add(turn_id=i, compressed_content=s)
    task = make_task(core_mem, llm_cfg, recent_mem)
    result = task.run()
    assert isinstance(result, list)


def test_consolidation_written_entries_have_valid_dimensions(core_mem, llm_cfg, recent_mem):
    for i, s in enumerate(DELEGATION_SESSIONS):
        recent_mem.add(turn_id=i, compressed_content=s)
    task = make_task(core_mem, llm_cfg, recent_mem)
    result = task.run()
    for entry in result:
        assert entry.get("dimension") in VALID_DIMS, f"Invalid dimension: {entry.get('dimension')}"


def test_consolidation_written_entries_persisted(core_mem, llm_cfg, recent_mem):
    for i, s in enumerate(INTERACTION_SESSIONS):
        recent_mem.add(turn_id=i, compressed_content=s)
    task = make_task(core_mem, llm_cfg, recent_mem)
    result = task.run()
    for entry in result:
        assert core_mem.get(entry["key"]) is not None


def test_consolidation_respects_lookback(core_mem, llm_cfg, recent_mem):
    # Add 5 sessions, only lookback=2 should be read
    for i in range(5):
        recent_mem.add(turn_id=i, compressed_content=f"Session {i}: user uses Chinese")
    task = make_task(core_mem, llm_cfg, recent_mem, lookback=2)
    result = task.run()
    # Verify get_recent_entries was called with correct limit
    entries = recent_mem.get_recent_entries(limit=2)
    assert len(entries) == 2


def test_consolidation_does_not_duplicate_existing_memory(core_mem, llm_cfg, recent_mem):
    core_mem.set("delegation", "高委托模式", dimension="delegation")
    for i, s in enumerate(DELEGATION_SESSIONS):
        recent_mem.add(turn_id=i, compressed_content=s)
    task = make_task(core_mem, llm_cfg, recent_mem)
    task.run()
    val = core_mem.get("delegation")
    if val:
        # LLM should not blindly duplicate existing content
        assert val.count("高委托模式") <= 1
