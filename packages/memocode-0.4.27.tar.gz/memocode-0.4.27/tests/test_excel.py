"""Tests for tools/excel.py — _format_table, _excel_read, _excel_write"""
import os
import sys
import tempfile

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from tools.excel import _format_table, _excel_read, _excel_write


# ── _format_table ─────────────────────────────────────────────────────────────

def test_format_table_empty():
    assert _format_table([], "Sheet1", 500, 50, "/tmp/x.csv") == "[Sheet: Sheet1] (empty)"


def test_format_table_header_only():
    result = _format_table([["Name", "Age"]], "Sheet1", 500, 50, "/tmp/x.csv")
    assert "Name" in result
    assert "Age" in result


def test_format_table_with_data():
    rows = [["Name", "Age"], ["Alice", "30"], ["Bob", "25"]]
    result = _format_table(rows, "Data", 500, 50, "/tmp/x.csv")
    assert "Alice" in result
    assert "Bob" in result
    assert "-+-" in result  # separator between header and data


def test_format_table_truncates_long_values():
    long_val = "A" * 40
    rows = [[long_val]]
    result = _format_table(rows, "S", 500, 50, "/tmp/x.csv")
    # Values are capped at 30 chars
    assert "A" * 30 in result
    assert "A" * 31 not in result


def test_format_table_shows_truncation_message():
    rows = [["x"]] * 10
    result = _format_table(rows, "S", 5, 50, "/tmp/x.csv")
    assert "more rows" in result


def test_format_table_trims_columns():
    rows = [["a", "b", "c", "d", "e"]]
    result = _format_table(rows, "S", 500, 3, "/tmp/x.csv")
    assert "a" in result
    assert "d" not in result


# ── CSV read/write ────────────────────────────────────────────────────────────

def test_csv_write_and_read_roundtrip():
    with tempfile.NamedTemporaryFile(suffix=".csv", delete=False) as f:
        path = f.name
    try:
        _excel_write(path, [["Name", "Age"], ["Alice", "30"]])
        result = _excel_read(path)
        assert "Name" in result
        assert "Alice" in result
        assert "30" in result
    finally:
        os.unlink(path)


def test_csv_write_overwrite():
    with tempfile.NamedTemporaryFile(suffix=".csv", delete=False) as f:
        path = f.name
    try:
        _excel_write(path, [["first"]])
        _excel_write(path, [["second"]])
        result = _excel_read(path)
        assert "second" in result
        assert "first" not in result
    finally:
        os.unlink(path)


def test_csv_write_append():
    with tempfile.NamedTemporaryFile(suffix=".csv", delete=False) as f:
        path = f.name
    try:
        _excel_write(path, [["row1"]])
        _excel_write(path, [["row2"]], mode="append")
        result = _excel_read(path)
        assert "row1" in result
        assert "row2" in result
    finally:
        os.unlink(path)


def test_csv_read_max_rows():
    with tempfile.NamedTemporaryFile(suffix=".csv", delete=False) as f:
        path = f.name
    try:
        _excel_write(path, [[f"row{i}"] for i in range(10)])
        result = _excel_read(path, max_rows=3)
        assert "more rows" in result
    finally:
        os.unlink(path)


def test_excel_read_missing_file():
    with pytest.raises(FileNotFoundError):
        _excel_read("/nonexistent/path/file.csv")


def test_excel_write_invalid_data():
    with tempfile.NamedTemporaryFile(suffix=".csv", delete=False) as f:
        path = f.name
    try:
        with pytest.raises(ValueError):
            _excel_write(path, "not a list of lists")
    finally:
        os.unlink(path)


# ── xlsx read/write ───────────────────────────────────────────────────────────

openpyxl = pytest.importorskip("openpyxl", reason="openpyxl not installed")


def test_xlsx_write_and_read_roundtrip():
    with tempfile.NamedTemporaryFile(suffix=".xlsx", delete=False) as f:
        path = f.name
    try:
        _excel_write(path, [["Name", "Score"], ["Alice", "95"]], sheet="Results")
        result = _excel_read(path, sheet="Results")
        assert "Alice" in result
        assert "95" in result
    finally:
        os.unlink(path)


def test_xlsx_read_invalid_sheet():
    with tempfile.NamedTemporaryFile(suffix=".xlsx", delete=False) as f:
        path = f.name
    try:
        _excel_write(path, [["x"]])
        result = _excel_read(path, sheet="NoSuchSheet")
        assert "[Error]" in result
        assert "not found" in result
    finally:
        os.unlink(path)


def test_xlsx_write_append():
    with tempfile.NamedTemporaryFile(suffix=".xlsx", delete=False) as f:
        path = f.name
    try:
        _excel_write(path, [["first"]])
        _excel_write(path, [["second"]], mode="append")
        result = _excel_read(path)
        assert "first" in result
        assert "second" in result
    finally:
        os.unlink(path)
