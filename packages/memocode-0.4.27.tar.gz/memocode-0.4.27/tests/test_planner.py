"""Tests for control/planner.py"""
import os
import sys
import json
from unittest.mock import MagicMock

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from control.planner import _is_chinese, _format_tools, Planner, Task
from tools.registry import ToolSchema


# ── _is_chinese ───────────────────────────────────────────────────────────────

def test_is_chinese_pure_chinese():
    assert _is_chinese("你好世界") is True


def test_is_chinese_english():
    assert _is_chinese("hello world") is False


def test_is_chinese_mixed_above_threshold():
    assert _is_chinese("这是一个test") is True


def test_is_chinese_empty():
    assert _is_chinese("") is False


def test_is_chinese_below_threshold():
    # 1 chinese char out of 20+ total → below 0.3
    assert _is_chinese("a" * 20 + "你") is False


# ── _format_tools ─────────────────────────────────────────────────────────────

def _make_schema(name, description):
    s = MagicMock(spec=ToolSchema)
    s.name = name
    s.description = description
    return s


def test_format_tools_single():
    schemas = [_make_schema("shell_exec", "Run shell commands")]
    result = _format_tools(schemas)
    assert result == "- shell_exec: Run shell commands"


def test_format_tools_multiple():
    schemas = [
        _make_schema("shell_exec", "Run shell commands"),
        _make_schema("file_read", "Read a file"),
    ]
    result = _format_tools(schemas)
    lines = result.strip().split("\n")
    assert len(lines) == 2
    assert "shell_exec" in lines[0]
    assert "file_read" in lines[1]


def test_format_tools_empty():
    assert _format_tools([]) == ""


# ── Planner.plan() ────────────────────────────────────────────────────────────

def _make_planner(llm_response: str, tool_names: list[str]) -> Planner:
    llm = MagicMock()
    llm.complete.return_value = llm_response

    registry = MagicMock()
    registry.list.return_value = [_make_schema(n, f"{n} tool") for n in tool_names]
    registry.has.side_effect = lambda name: name in tool_names

    return Planner(llm=llm, registry=registry)


def test_plan_parses_single_task():
    response = json.dumps([
        {"id": 1, "tool": "shell_exec", "args": {"command": "ls"}, "description": "list files", "depends_on": []}
    ])
    planner = _make_planner(response, ["shell_exec"])
    tasks, missing = planner.plan("list files")
    assert missing == []
    assert len(tasks) == 1
    assert tasks[0].tool == "shell_exec"
    assert tasks[0].args == {"command": "ls"}


def test_plan_parses_multiple_tasks_with_deps():
    response = json.dumps([
        {"id": 1, "tool": "shell_exec", "args": {"command": "ls"}, "description": "list", "depends_on": []},
        {"id": 2, "tool": "file_read", "args": {"path": "/tmp/out"}, "description": "read", "depends_on": [1]},
    ])
    planner = _make_planner(response, ["shell_exec", "file_read"])
    tasks, missing = planner.plan("list then read")
    assert missing == []
    assert len(tasks) == 2
    assert tasks[1].depends_on == [1]


def test_plan_returns_missing_tools():
    response = json.dumps([
        {"id": 1, "tool": "nonexistent_tool", "args": {}, "description": "x", "depends_on": []}
    ])
    planner = _make_planner(response, ["shell_exec"])
    tasks, missing = planner.plan("do something")
    assert "nonexistent_tool" in missing
    assert tasks == []


def test_plan_strips_markdown_code_block():
    inner = json.dumps([
        {"id": 1, "tool": "shell_exec", "args": {"command": "pwd"}, "description": "print dir", "depends_on": []}
    ])
    response = f"```json\n{inner}\n```"
    planner = _make_planner(response, ["shell_exec"])
    tasks, missing = planner.plan("print working dir")
    assert missing == []
    assert len(tasks) == 1


def test_plan_raises_on_invalid_json():
    planner = _make_planner("not valid json at all {{", ["shell_exec"])
    with pytest.raises(ValueError, match="Planner could not parse"):
        planner.plan("do something")


def test_plan_uses_chinese_prompt_for_chinese_goal():
    response = json.dumps([
        {"id": 1, "tool": "shell_exec", "args": {"command": "ls"}, "description": "列出文件", "depends_on": []}
    ])
    planner = _make_planner(response, ["shell_exec"])
    tasks, _ = planner.plan("列出当前目录的文件")
    # Verify LLM was called with Chinese prompt content
    call_args = planner.llm.complete.call_args
    messages = call_args[0][0]
    user_content = messages[1]["content"]
    assert "目标" in user_content  # Chinese prompt uses "目标" not "Goal"


def test_plan_uses_english_prompt_for_english_goal():
    response = json.dumps([
        {"id": 1, "tool": "shell_exec", "args": {"command": "ls"}, "description": "list files", "depends_on": []}
    ])
    planner = _make_planner(response, ["shell_exec"])
    tasks, _ = planner.plan("list files in current directory")
    call_args = planner.llm.complete.call_args
    messages = call_args[0][0]
    user_content = messages[1]["content"]
    assert "Goal" in user_content


# ── Planner.plan() — real LLM ─────────────────────────────────────────────────

@pytest.fixture
def real_planner(llm_cfg):
    from control.llm import LLMAdapter
    from tools.registry import ToolRegistry
    from tools.loader import _register_from_module
    import tools.shell, tools.file

    llm = LLMAdapter(
        provider="openai",
        api_key=llm_cfg["api_key"],
        model=llm_cfg["model"],
        base_url=llm_cfg["base_url"],
    )
    registry = ToolRegistry()
    for mod in [tools.shell, tools.file]:
        _register_from_module(registry, mod, mod.__file__ or "", verbose=False)
    return Planner(llm=llm, registry=registry)


def test_plan_real_llm_returns_valid_tasks(real_planner):
    tasks, missing = real_planner.plan("列出 /tmp 目录下的文件")
    assert missing == []
    assert len(tasks) >= 1
    assert all(isinstance(t, Task) for t in tasks)
    assert any(t.tool == "shell_exec" for t in tasks)
