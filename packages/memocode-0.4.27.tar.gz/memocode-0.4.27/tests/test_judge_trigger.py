"""Tests for core memory judge auto-trigger and _run_judge in ContextManager"""
import os
import sys
import threading
import time

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from control.chatmem.context_manager import ContextManager
from control.chatmem.config import ContextConfig, DimensionConfig, LLMConfig


DIMS = {
    "interaction_style": DimensionConfig(label="Interaction Style", stability=30.0),
    "delegation":        DimensionConfig(label="Delegation",        stability=35.0),
}


@pytest.fixture
def ctx(tmp_path, llm_cfg):
    cfg = ContextConfig(
        dimensions=DIMS,
        llm=LLMConfig(
            model=llm_cfg["model"],
            base_url=llm_cfg["base_url"],
            api_key=llm_cfg["api_key"],
        ),
    )
    cm = ContextManager.create(
        config=cfg,
        api_key=llm_cfg["api_key"],
        db_path=str(tmp_path / "ctx.db"),
        core_db_path=str(tmp_path / "core.db"),
    )
    return cm


# ── _run_judge directly ───────────────────────────────────────────────────────

def test_run_judge_does_not_crash(ctx):
    ctx._run_judge("user: 你好\nassistant: 你好")


def test_run_judge_writes_valid_entries(ctx):
    ctx._run_judge(
        "user: 直接帮我实现，不要给我选项\n"
        "assistant: 好的，直接实现。\n"
        "user: 用中文回答，简洁一点\n"
        "assistant: 明白。"
    )
    entries = ctx.core_memory.get_all()
    for e in entries:
        assert e["key"].strip() != ""
        assert e["dimension"] in DIMS


def test_run_judge_async_returns_thread(ctx):
    t = ctx._run_judge_async("user: hello\nassistant: hi")
    assert isinstance(t, threading.Thread)
    t.join(timeout=30)


# ── forgetting decay trigger (every 10 turns) ─────────────────────────────────

def test_forgetting_decay_triggered_at_turn_10(tmp_path, llm_cfg):
    """Verify decay runs at turn 10 without error."""
    cfg = ContextConfig(
        dimensions=DIMS,
        llm=LLMConfig(
            model=llm_cfg["model"],
            base_url=llm_cfg["base_url"],
            api_key=llm_cfg["api_key"],
        ),
    )
    cm = ContextManager.create(
        config=cfg,
        api_key=llm_cfg["api_key"],
        db_path=str(tmp_path / "ctx10.db"),
        core_db_path=str(tmp_path / "core10.db"),
    )
    cm.core_memory.set("interaction_style", "中文", dimension="interaction_style")

    # Simulate 10 turns
    for i in range(10):
        cm._post_turn(
            user_text=f"user message {i}",
            assistant_text=f"assistant reply {i}",
            original_messages=[],
        )
    time.sleep(0.5)  # let background decay thread finish

    # Score should still be valid (close to 1 since entries are fresh)
    entries = cm.core_memory.get_all_with_scores()
    for e in entries:
        assert 0.0 <= e["score"] <= 1.0


# ── rewind_to ─────────────────────────────────────────────────────────────────

def test_rewind_to_zero_clears_history(ctx):
    ctx._post_turn("hello", "hi", original_messages=[])
    ctx._post_turn("second", "reply", original_messages=[])
    ctx.rewind_to(0)
    turns = ctx.list_turns()
    assert turns == []


def test_rewind_to_n_keeps_n_turns(ctx):
    for i in range(5):
        ctx._post_turn(f"msg {i}", f"reply {i}", original_messages=[])
    ctx.rewind_to(3)
    turns = ctx.list_turns()
    assert len(turns) == 3


def test_rewind_to_invalid_index_raises(ctx):
    ctx._post_turn("hello", "hi", original_messages=[])
    with pytest.raises((IndexError, Exception)):
        ctx.rewind_to(99)


# ── session count ─────────────────────────────────────────────────────────────

def test_session_count_increments_on_end(ctx):
    count_before = ctx._session_count
    ctx.end_session()
    assert ctx._session_count == count_before + 1
