"""Tests for control/tasks.py — TaskManager"""
import json
import os
import tempfile

import pytest

import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from control.tasks import TaskManager


@pytest.fixture
def tm(tmp_path):
    manager = TaskManager(project="test")
    manager._path = str(tmp_path / "tasks.json")
    return manager


def test_add_creates_task(tm):
    t = tm.add("Fix login bug", "Safari crashes on login page")
    assert t["id"] == 1
    assert t["title"] == "Fix login bug"
    assert t["status"] == "open"
    assert t["done_at"] is None


def test_add_dedup_same_title(tm):
    t1 = tm.add("Fix login bug")
    t2 = tm.add("Fix login bug")
    assert t1["id"] == t2["id"]
    assert len(tm.list()) == 1


def test_add_dedup_case_insensitive(tm):
    t1 = tm.add("Fix Login Bug")
    t2 = tm.add("fix login bug")
    assert t1["id"] == t2["id"]


def test_add_dedup_allows_after_done(tm):
    t1 = tm.add("Fix login bug")
    tm.done(t1["id"])
    t2 = tm.add("Fix login bug")
    assert t2["id"] != t1["id"]
    assert t2["status"] == "open"


def test_done_marks_task(tm):
    t = tm.add("Task A")
    result = tm.done(t["id"])
    assert result["status"] == "done"
    assert result["done_at"] is not None


def test_done_missing_id(tm):
    assert tm.done(999) is None


def test_cancel_marks_task(tm):
    t = tm.add("Task B")
    result = tm.cancel(t["id"])
    assert result["status"] == "cancelled"


def test_update_title(tm):
    t = tm.add("Old title")
    result = tm.update(t["id"], title="New title")
    assert result["title"] == "New title"


def test_update_description(tm):
    t = tm.add("Task", "old desc")
    result = tm.update(t["id"], description="new desc")
    assert result["description"] == "new desc"


def test_list_all(tm):
    tm.add("Task 1")
    tm.add("Task 2")
    tasks = tm.list()
    assert len(tasks) == 2


def test_list_filter_by_status(tm):
    t = tm.add("Task 1")
    tm.add("Task 2")
    tm.done(t["id"])
    open_tasks = tm.list(status="open")
    assert len(open_tasks) == 1
    assert open_tasks[0]["title"] == "Task 2"


def test_open_tasks(tm):
    t = tm.add("Task 1")
    tm.add("Task 2")
    tm.cancel(t["id"])
    open_tasks = tm.open_tasks()
    assert len(open_tasks) == 1


def test_ids_increment(tm):
    t1 = tm.add("Task 1")
    t2 = tm.add("Task 2")
    t3 = tm.add("Task 3")
    assert t1["id"] < t2["id"] < t3["id"]


def test_persists_to_disk(tmp_path):
    manager = TaskManager(project="persist-test")
    manager._path = str(tmp_path / "tasks.json")
    manager.add("Persisted task")

    manager2 = TaskManager(project="persist-test")
    manager2._path = str(tmp_path / "tasks.json")
    tasks = manager2.list()
    assert len(tasks) == 1
    assert tasks[0]["title"] == "Persisted task"


def test_switch_project(tmp_path):
    manager = TaskManager(project="proj-a")
    manager._path = str(tmp_path / "proj-a.json")
    manager.add("Task in A")

    manager.switch_project("proj-b")
    manager._path = str(tmp_path / "proj-b.json")
    assert manager.list() == []
