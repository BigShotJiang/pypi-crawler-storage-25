"""Tests for control/chatmem/memory/recent_memory.py"""
import os
import sys
from unittest.mock import MagicMock

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from control.chatmem.memory.recent_memory import RecentMemory


@pytest.fixture
def rm(tmp_path):
    compressor = MagicMock()
    return RecentMemory(db_path=str(tmp_path / "recent.db"), compressor=compressor)


def test_add_and_get_recent(rm):
    rm.add(turn_id=1, compressed_content="Session 1 summary")
    entries = rm.get_recent_entries(limit=10)
    assert len(entries) == 1
    assert "Session 1 summary" in entries[0]


def test_get_recent_entries_order(rm):
    rm.add(turn_id=1, compressed_content="First session")
    rm.add(turn_id=2, compressed_content="Second session")
    rm.add(turn_id=3, compressed_content="Third session")
    entries = rm.get_recent_entries(limit=10)
    # Should be in chronological order (oldest first)
    assert entries[0].index("First") >= 0 or "First" in entries[0]


def test_get_recent_entries_limit(rm):
    for i in range(10):
        rm.add(turn_id=i, compressed_content=f"Session {i}")
    entries = rm.get_recent_entries(limit=3)
    assert len(entries) == 3


def test_get_recent_entries_empty(rm):
    entries = rm.get_recent_entries(limit=10)
    assert entries == []


def test_add_multiple_entries(rm):
    for i in range(5):
        rm.add(turn_id=i, compressed_content=f"Content {i}")
    entries = rm.get_recent_entries(limit=10)
    assert len(entries) == 5


def test_inject_context_respects_token_cap(rm):
    # Add a large entry that exceeds the token cap
    large_content = "word " * 5000  # ~5000 tokens
    rm.add(turn_id=1, compressed_content=large_content)
    rm.add(turn_id=2, compressed_content="short")
    context = rm.get_for_context()
    # Context should be non-empty but token-capped
    assert context is not None
