"""Tests for tools/pdf.py — _parse_page_range, _format_table, _pdf_read"""
import os
import sys
import tempfile

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from tools.pdf import _parse_page_range, _format_table


# ── _parse_page_range ─────────────────────────────────────────────────────────

def test_parse_single_page():
    assert _parse_page_range("1", 5) == [0]


def test_parse_range():
    assert _parse_page_range("1-3", 5) == [0, 1, 2]


def test_parse_comma_separated():
    assert _parse_page_range("1,3,5", 5) == [0, 2, 4]


def test_parse_mixed_range_and_single():
    assert _parse_page_range("1-2,4", 5) == [0, 1, 3]


def test_parse_out_of_bounds_clipped():
    # page 10 doesn't exist in a 5-page doc
    result = _parse_page_range("1,10", 5)
    assert 0 in result
    assert 9 not in result


def test_parse_range_clipped_at_total():
    # "3-10" in a 5-page doc → pages 3,4,5 (indices 2,3,4)
    result = _parse_page_range("3-10", 5)
    assert result == [2, 3, 4]


def test_parse_returns_sorted():
    result = _parse_page_range("5,1,3", 5)
    assert result == sorted(result)


# ── _format_table ─────────────────────────────────────────────────────────────

def test_format_table_empty():
    assert _format_table([]) == ""


def test_format_table_single_row():
    result = _format_table([["Name", "Value"]])
    assert "Name" in result
    assert "Value" in result


def test_format_table_separator_present():
    result = _format_table([["A", "B"], ["1", "2"]])
    assert "-+-" in result


def test_format_table_handles_none():
    result = _format_table([[None, "hello"]])
    assert "hello" in result


def test_format_table_truncates_long_cell():
    result = _format_table([["X" * 40]])
    assert "X" * 25 in result
    assert "X" * 26 not in result


def test_format_table_jagged_rows():
    # Rows with different column counts
    result = _format_table([["A", "B", "C"], ["1"]])
    assert "A" in result
    assert "1" in result


# ── _pdf_read (integration) ───────────────────────────────────────────────────

pdfplumber = pytest.importorskip("pdfplumber", reason="pdfplumber not installed")


@pytest.fixture
def simple_pdf(tmp_path):
    """Create a minimal valid PDF with one page of text using fpdf2 or reportlab."""
    pdf_path = tmp_path / "test.pdf"

    # Try fpdf2
    try:
        from fpdf import FPDF
        pdf = FPDF()
        pdf.add_page()
        pdf.set_font("Helvetica", size=12)
        pdf.cell(200, 10, txt="Hello PDF World", ln=True)
        pdf.output(str(pdf_path))
        return str(pdf_path)
    except ImportError:
        pass

    # Try reportlab
    try:
        from reportlab.pdfgen import canvas
        c = canvas.Canvas(str(pdf_path))
        c.drawString(100, 750, "Hello PDF World")
        c.save()
        return str(pdf_path)
    except ImportError:
        pass

    pytest.skip("No PDF generation library (fpdf2/reportlab) installed")


def test_pdf_read_returns_text(simple_pdf):
    from tools.pdf import _pdf_read
    result = _pdf_read(simple_pdf, extract_images=False)
    assert "Hello PDF World" in result


def test_pdf_read_page_filter(simple_pdf):
    from tools.pdf import _pdf_read
    result = _pdf_read(simple_pdf, pages="1", extract_images=False)
    assert "[Page 1]" in result


def test_pdf_read_missing_file():
    from tools.pdf import _pdf_read
    with pytest.raises(FileNotFoundError):
        _pdf_read("/nonexistent/file.pdf")


def test_pdf_read_max_chars(simple_pdf):
    from tools.pdf import _pdf_read
    result = _pdf_read(simple_pdf, extract_images=False, max_chars=10)
    assert "truncated" in result


def test_pdf_image_attach_marker(tmp_path):
    """IMAGE_ATTACH markers are emitted for successfully saved images."""
    from tools.pdf import _pdf_read
    import re

    # Try to find a PDF with images, otherwise skip
    try:
        from fpdf import FPDF
    except ImportError:
        pytest.skip("fpdf2 not installed — cannot create test PDF with images")

    # Create a PDF with an embedded image using fpdf2
    try:
        from PIL import Image as PILImage
        import numpy as np
    except ImportError:
        pytest.skip("Pillow not installed — cannot create test image")

    # Create a small test image
    img_path = tmp_path / "test_img.png"
    img = PILImage.fromarray(
        __import__("numpy").zeros((10, 10, 3), dtype=__import__("numpy").uint8)
    )
    img.save(str(img_path))

    pdf_path = tmp_path / "with_image.pdf"
    pdf = FPDF()
    pdf.add_page()
    pdf.image(str(img_path), x=10, y=10, w=10)
    pdf.output(str(pdf_path))

    result = _pdf_read(str(pdf_path), extract_images=True, image_dir=str(tmp_path))
    # If image extracted successfully, IMAGE_ATTACH marker should appear
    if "[Images" in result:
        markers = re.findall(r"\[IMAGE_ATTACH:([^\]]+)\]", result)
        assert len(markers) >= 1
        for m in markers:
            assert os.path.isfile(m)
