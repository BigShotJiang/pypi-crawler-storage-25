"""Tests for pending_sessions DB: save, load, task_ops flag"""
import os
import sys
import sqlite3
import tempfile

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))


def make_minimal_db(db_path: str):
    """Create minimal pending_sessions table for testing."""
    with sqlite3.connect(db_path) as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS pending_sessions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                verbatim_text TEXT NOT NULL,
                summary_json TEXT NOT NULL,
                turn_count INTEGER NOT NULL,
                created_at REAL NOT NULL,
                compression_mode TEXT DEFAULT 'code',
                task_ops INTEGER NOT NULL DEFAULT 0
            )
        """)


def save_pending(db_path, verbatim_text, summary_json, turn_count,
                 compression_mode="code", task_ops=False):
    import time
    with sqlite3.connect(db_path) as conn:
        conn.execute(
            "INSERT INTO pending_sessions (verbatim_text, summary_json, turn_count, created_at, compression_mode, task_ops) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (verbatim_text, summary_json, turn_count, time.time(), compression_mode, int(task_ops)),
        )


def load_pending(db_path):
    with sqlite3.connect(db_path) as conn:
        rows = conn.execute(
            "SELECT id, verbatim_text, summary_json, turn_count, compression_mode, task_ops FROM pending_sessions ORDER BY created_at"
        ).fetchall()
    return [
        {"id": r[0], "verbatim_text": r[1], "summary_json": r[2], "turn_count": r[3],
         "compression_mode": r[4] or "code", "task_ops": bool(r[5])}
        for r in rows
    ]


@pytest.fixture
def db_path(tmp_path):
    path = str(tmp_path / "chatmem.db")
    make_minimal_db(path)
    return path


def test_save_and_load_basic(db_path):
    save_pending(db_path, "user: hello", "[]", turn_count=1)
    sessions = load_pending(db_path)
    assert len(sessions) == 1
    assert sessions[0]["verbatim_text"] == "user: hello"
    assert sessions[0]["turn_count"] == 1


def test_task_ops_false_by_default(db_path):
    save_pending(db_path, "user: hello", "[]", turn_count=1)
    sessions = load_pending(db_path)
    assert sessions[0]["task_ops"] is False


def test_task_ops_true_when_set(db_path):
    save_pending(db_path, "user: hello", "[]", turn_count=1, task_ops=True)
    sessions = load_pending(db_path)
    assert sessions[0]["task_ops"] is True


def test_task_ops_distinguishes_sessions(db_path):
    save_pending(db_path, "mid-session content", "[]", turn_count=5, task_ops=False)
    save_pending(db_path, "end session content", "[]", turn_count=10, task_ops=True)
    sessions = load_pending(db_path)
    assert sessions[0]["task_ops"] is False
    assert sessions[1]["task_ops"] is True


def test_multiple_sessions_ordered_by_created_at(db_path):
    import time
    save_pending(db_path, "first", "[]", turn_count=1)
    time.sleep(0.01)
    save_pending(db_path, "second", "[]", turn_count=2)
    sessions = load_pending(db_path)
    assert sessions[0]["verbatim_text"] == "first"
    assert sessions[1]["verbatim_text"] == "second"


def test_empty_db_returns_empty_list(db_path):
    assert load_pending(db_path) == []


def test_compression_mode_stored(db_path):
    save_pending(db_path, "text", "[]", turn_count=3, compression_mode="plan")
    sessions = load_pending(db_path)
    assert sessions[0]["compression_mode"] == "plan"


def test_compression_mode_defaults_to_code(db_path):
    save_pending(db_path, "text", "[]", turn_count=3)
    sessions = load_pending(db_path)
    assert sessions[0]["compression_mode"] == "code"
