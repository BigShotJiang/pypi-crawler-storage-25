"""Tests for tools/web.py — _html_to_text, _web_fetch, _web_search"""
import os
import sys

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from tools.web import _html_to_text, _web_fetch, _web_search


# ── _html_to_text ─────────────────────────────────────────────────────────────

def test_strips_script_tags():
    html = "<html><script>alert(1)</script><body>Hello</body></html>"
    result = _html_to_text(html)
    assert "alert" not in result
    assert "Hello" in result


def test_strips_style_tags():
    html = "<style>body { color: red }</style><p>Content</p>"
    result = _html_to_text(html)
    assert "color" not in result
    assert "Content" in result


def test_block_tags_become_newlines():
    html = "<p>First</p><p>Second</p>"
    result = _html_to_text(html)
    assert "First" in result
    assert "Second" in result
    assert "\n" in result


def test_link_keeps_text_and_url():
    html = '<a href="https://example.com">Click here</a>'
    result = _html_to_text(html)
    assert "Click here" in result
    assert "https://example.com" in result


def test_html_entities_decoded():
    html = "<p>A &amp; B &lt; C &gt; D</p>"
    result = _html_to_text(html)
    assert "A & B < C > D" in result


def test_nbsp_becomes_space():
    result = _html_to_text("Hello&nbsp;World")
    assert "Hello World" in result


def test_plain_text_passthrough():
    result = _html_to_text("no tags here")
    assert result == "no tags here"


def test_empty_string():
    assert _html_to_text("") == ""


def test_strips_all_remaining_tags():
    html = "<div><span><em>text</em></span></div>"
    result = _html_to_text(html)
    assert "<" not in result
    assert "text" in result


# ── _web_fetch (real network) ─────────────────────────────────────────────────

def test_fetch_json_endpoint():
    result = _web_fetch("https://httpbin.org/get")
    assert "[Error]" not in result
    assert "httpbin" in result.lower() or "url" in result.lower()


def test_fetch_truncates_at_max_chars():
    result = _web_fetch("https://httpbin.org/get", max_chars=50)
    assert len(result) <= 50 + len("\n\n... [truncated — 9999999 chars omitted]")


def test_fetch_http_error_returns_prefix():
    result = _web_fetch("https://httpbin.org/status/404")
    assert "[HTTP 404]" in result or "[Error]" in result or "NOT FOUND" in result.upper()


def test_fetch_invalid_url_returns_error():
    result = _web_fetch("https://this-domain-does-not-exist-xyz-abc.com/path")
    assert "[Error]" in result or "[URL Error]" in result


# ── _web_search (real network) ────────────────────────────────────────────────

def test_search_returns_results():
    result = _web_search("python programming language")
    assert "[Search Error]" not in result
    assert "http" in result


def test_search_max_results_respected():
    result = _web_search("python", max_results=3)
    # Count numbered result lines "1. ... 2. ... 3. ..."
    import re
    matches = re.findall(r"^\d+\.", result, re.MULTILINE)
    assert len(matches) <= 3


def test_search_no_results_returns_message():
    # Extremely unlikely query to get results
    result = _web_search("xkqzwvpqmrblfjsdf")
    # Either returns no results message or some results
    assert isinstance(result, str)
    assert len(result) > 0
