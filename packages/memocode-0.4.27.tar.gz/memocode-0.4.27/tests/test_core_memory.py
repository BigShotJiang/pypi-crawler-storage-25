"""Tests for control/chatmem/memory/core_memory.py"""
import os
import sqlite3
import sys
import time

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from control.chatmem.memory.core_memory import CoreMemory, _dedup_sentences
from control.chatmem.config import DimensionConfig

DIMS = {
    "interaction_style": DimensionConfig(label="Interaction Style", stability=30.0),
    "delegation":        DimensionConfig(label="Delegation",        stability=35.0),
}


@pytest.fixture
def cm(tmp_path):
    return CoreMemory(
        db_path=str(tmp_path / "core.db"),
        api_key="test",
        model="test-model",
        dimensions=DIMS,
    )


@pytest.fixture
def cm_llm(tmp_path, llm_cfg):
    return CoreMemory(
        db_path=str(tmp_path / "core_llm.db"),
        api_key=llm_cfg["api_key"],
        model=llm_cfg["model"],
        base_url=llm_cfg["base_url"],
        dimensions=DIMS,
    )


# ── _dedup_sentences ──────────────────────────────────────────────────────────

def test_dedup_removes_exact_duplicates():
    text = "A；B；A；C；"
    result = _dedup_sentences(text)
    assert result.count("A") == 1
    assert "B" in result
    assert "C" in result


def test_dedup_preserves_order():
    text = "第一句；第二句；第三句；第一句；"
    result = _dedup_sentences(text)
    assert result.index("第一句") < result.index("第二句")


def test_dedup_handles_newlines():
    text = "line1\nline2\nline1\n"
    result = _dedup_sentences(text)
    assert result.count("line1") == 1


def test_dedup_empty_string():
    assert _dedup_sentences("") == ""


def test_dedup_no_duplicates_unchanged():
    text = "A；B；C；"
    result = _dedup_sentences(text)
    assert "A" in result and "B" in result and "C" in result


def test_dedup_quote_only_value():
    assert _dedup_sentences('""').strip('"').strip() == ""


# ── CoreMemory.set / get ──────────────────────────────────────────────────────

def test_set_and_get(cm):
    cm.set("interaction_style", "中文；简洁；", dimension="interaction_style")
    assert cm.get("interaction_style") == "中文；简洁；"


def test_set_deduplicates_on_write(cm):
    cm.set("interaction_style", "中文；简洁；中文；", dimension="interaction_style")
    val = cm.get("interaction_style")
    assert val.count("中文") == 1


def test_set_overwrites(cm):
    cm.set("delegation", "高委托", dimension="delegation")
    cm.set("delegation", "中等委托", dimension="delegation")
    assert cm.get("delegation") == "中等委托"


def test_get_missing_key(cm):
    assert cm.get("nonexistent") is None


def test_get_all_returns_entries(cm):
    cm.set("interaction_style", "中文", dimension="interaction_style")
    cm.set("delegation", "高委托", dimension="delegation")
    entries = cm.get_all()
    keys = {e["key"] for e in entries}
    assert "interaction_style" in keys
    assert "delegation" in keys


def test_delete_removes_entry(cm):
    cm.set("interaction_style", "中文", dimension="interaction_style")
    result = cm.delete("interaction_style")
    assert result is True
    assert cm.get("interaction_style") is None


def test_delete_missing_key(cm):
    assert cm.delete("nonexistent") is False


def test_clear_removes_all(cm):
    cm.set("interaction_style", "中文", dimension="interaction_style")
    cm.set("delegation", "高委托", dimension="delegation")
    count = cm.clear()
    assert count == 2
    assert cm.get_all() == []


# ── compact ───────────────────────────────────────────────────────────────────

def test_compact_deduplicates_bloated_entry(cm):
    bloated = "直接做；给方案；直接做；执行模式；给方案；"
    cm.set("delegation", bloated, dimension="delegation")
    with sqlite3.connect(cm.db_path) as conn:
        conn.execute("UPDATE core_memory SET value = ? WHERE key = ?", (bloated, "delegation"))
    keys = cm.compact()
    assert "delegation" in keys
    val = cm.get("delegation")
    assert val.count("直接做") == 1
    assert val.count("给方案") == 1


def test_compact_deletes_empty_value(cm):
    now = time.time()
    with sqlite3.connect(cm.db_path) as conn:
        conn.execute(
            "INSERT INTO core_memory (key, value, dimension, stability, score, created_at, updated_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?)",
            ("empty_key", "", "interaction_style", 30.0, 1.0, now, now),
        )
    cm.compact()
    assert cm.get("empty_key") is None


def test_compact_deletes_quote_only_value(cm):
    now = time.time()
    with sqlite3.connect(cm.db_path) as conn:
        conn.execute(
            "INSERT INTO core_memory (key, value, dimension, stability, score, created_at, updated_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?)",
            ("junk", '""', "interaction_style", 30.0, 0.75, now, now),
        )
    cm.compact()
    assert cm.get("junk") is None


def test_compact_accepts_threshold_param(cm):
    cm.compact(threshold=200)


def test_compact_no_changes_returns_empty(cm):
    cm.set("delegation", "高委托", dimension="delegation")
    keys = cm.compact()
    assert keys == []


# ── judge_and_update (real LLM) ───────────────────────────────────────────────

def test_judge_returns_list(cm_llm):
    result = cm_llm.judge_and_update(
        "user: 你好\nassistant: 你好，有什么可以帮你的？"
    )
    assert isinstance(result, list)


def test_judge_written_entries_have_valid_structure(cm_llm):
    result = cm_llm.judge_and_update(
        "user: 直接帮我做，不用给我选项\nassistant: 好的，直接执行。"
    )
    for entry in result:
        assert "key" in entry
        assert entry["key"].strip() != ""
        assert "value" in entry


def test_judge_written_entries_have_valid_dimensions(cm_llm):
    result = cm_llm.judge_and_update(
        "user: 用中文回答，越简洁越好\nassistant: 明白。"
    )
    valid_dims = set(DIMS.keys())
    for entry in result:
        dim = entry.get("dimension")
        if dim:
            assert dim in valid_dims, f"Invalid dimension: {dim}"


def test_judge_does_not_write_empty_key(cm_llm):
    cm_llm.judge_and_update("user: hello\nassistant: hi")
    entries = cm_llm.get_all()
    for e in entries:
        assert e["key"].strip() != ""


def test_judge_updates_are_persisted(cm_llm):
    cm_llm.judge_and_update(
        "user: 帮我实现这个功能，直接写代码\nassistant: 好的。\n"
        "user: 不用解释，直接给代码\nassistant: 好。"
    )
    entries = cm_llm.get_all()
    # If LLM wrote anything, verify it persisted
    for e in entries:
        assert cm_llm.get(e["key"]) is not None


def test_judge_existing_memory_not_duplicated(cm_llm):
    cm_llm.set("interaction_style", "中文", dimension="interaction_style")
    cm_llm.judge_and_update(
        "user: 你好\nassistant: 你好"
    )
    val = cm_llm.get("interaction_style")
    if val:
        assert val.count("中文") == 1


# ── to_context_string ─────────────────────────────────────────────────────────

def test_to_context_string_format(cm):
    cm.set("interaction_style", "中文；简洁", dimension="interaction_style")
    s = cm.to_context_string()
    assert "Interaction Style" in s
    assert "中文；简洁" in s


def test_to_context_string_empty(cm):
    assert cm.to_context_string() == ""


# ── score / history ───────────────────────────────────────────────────────────

def test_update_score(cm):
    cm.set("delegation", "高委托", dimension="delegation")
    cm.update_score("delegation", 0.5)
    entries = cm.get_all_with_scores()
    match = next(e for e in entries if e["key"] == "delegation")
    assert abs(match["score"] - 0.5) < 0.001


def test_low_score_hidden_from_get_all(cm):
    cm.set("delegation", "高委托", dimension="delegation")
    cm.update_score("delegation", 0.05)
    entries = cm.get_all()
    assert not any(e["key"] == "delegation" for e in entries)


def test_enable_history_archives_old_value(tmp_path):
    cm_h = CoreMemory(
        db_path=str(tmp_path / "core_h.db"),
        api_key="test",
        model="test-model",
        dimensions=DIMS,
        enable_history=True,
    )
    cm_h.set("delegation", "高委托", dimension="delegation")
    cm_h.set("delegation", "中等委托", dimension="delegation")
    history = cm_h.get_history("delegation")
    assert len(history) == 1
    assert history[0]["value"] == "高委托"
