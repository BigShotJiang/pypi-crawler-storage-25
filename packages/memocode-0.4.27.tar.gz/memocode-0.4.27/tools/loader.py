"""
Tool auto-discovery: scans tools/*.py for *_TOOL variables or TOOLS lists.
Skips registry.py, shell.py (built-in), loader.py itself, and file.py (built-in).

Adding a custom tool:
  1. Copy tools/example_tool.py.template → ~/.mcode/tools/mytool.py
  2. Implement your function and fill in the ToolSchema
  3. Restart mcode — it loads automatically, verify with /tools
  Note: user tools are loaded by file path (no package structure needed).
        `from tools.registry import Tool, ToolSchema` works out of the box.
"""
from __future__ import annotations
import importlib
import importlib.util
import os
import sys
from .registry import Tool, ToolRegistry

_BUILTIN = {"registry", "loader", "shell", "file"}


def _scan_dir(registry: ToolRegistry, tools_dir: str, package_prefix: str, verbose: bool = False):
    """Scan a built-in tools package directory for tool modules."""
    if not os.path.isdir(tools_dir):
        return
    if os.path.dirname(tools_dir) not in sys.path:
        sys.path.insert(0, os.path.dirname(tools_dir))

    for filename in sorted(os.listdir(tools_dir)):
        if not filename.endswith(".py") or filename.startswith("_"):
            continue
        module_name = filename[:-3]
        if module_name in _BUILTIN:
            continue

        try:
            mod = importlib.import_module(f"{package_prefix}.{module_name}")
        except Exception as e:
            print(f"[tools] failed to load {module_name}: {e}")
            continue

        _register_from_module(registry, mod, filename, verbose)


def _scan_user_dir(registry: ToolRegistry, tools_dir: str):
    """
    Scan ~/.mcode/tools/ by loading each file directly via spec_from_file_location.
    No package structure required — any .py file with *_TOOL or TOOLS works.
    """
    if not os.path.isdir(tools_dir):
        return

    # Make mcode's own tools package importable so user tools can do:
    # from tools.registry import Tool, ToolSchema
    _mcode_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    if _mcode_root not in sys.path:
        sys.path.insert(0, _mcode_root)

    for filename in sorted(os.listdir(tools_dir)):
        if not filename.endswith(".py") or filename.startswith("_"):
            continue
        filepath = os.path.join(tools_dir, filename)
        module_name = f"_user_tool_{filename[:-3]}"
        try:
            spec = importlib.util.spec_from_file_location(module_name, filepath)
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
        except Exception as e:
            print(f"[tools] failed to load {filename}: {e}")
            continue

        _register_from_module(registry, mod, filename, verbose=True)


def _register_from_module(registry: ToolRegistry, mod, filename: str, verbose: bool):
    registered = 0
    tools_list = getattr(mod, "TOOLS", None)
    if isinstance(tools_list, list):
        for tool in tools_list:
            if isinstance(tool, Tool):
                registry.register(tool)
                registered += 1

    for attr in dir(mod):
        if attr.endswith("_TOOL") and not attr.startswith("_"):
            obj = getattr(mod, attr)
            if isinstance(obj, Tool) and not registry.has(obj.schema.name):
                registry.register(obj)
                registered += 1

    if registered and verbose:
        print(f"[tools] loaded {registered} tool(s) from {filename}")


def load_external_tools(registry: ToolRegistry, tools_dir: str | None = None):
    """
    Scan tools/ directory and ~/.mcode/tools/ for external tool modules.
    Looks for module-level variables named *_TOOL (Tool instance) or TOOLS (list of Tool).
    """
    # Built-in tools dir (package) — silent
    builtin_dir = tools_dir or os.path.dirname(__file__)
    _scan_dir(registry, builtin_dir, "tools", verbose=False)

    # User tools dir (~/.mcode/tools/) — loaded by file path, no package needed
    user_tools_dir = os.path.join(os.path.expanduser("~/.mcode"), "tools")
    _scan_user_dir(registry, user_tools_dir)
