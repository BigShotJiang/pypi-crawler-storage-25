"""
Built-in tools: excel_read, excel_write
Read and write Excel files (.xlsx, .xls, .csv).
Requires: pip install openpyxl  (for .xlsx)
CSV files use stdlib csv module (no extra dependency).
"""
import os
from .registry import Tool, ToolSchema


def _excel_read(
    path: str,
    sheet: str | None = None,
    max_rows: int = 500,
    max_cols: int = 50,
) -> str:
    """Read an Excel or CSV file and return as a formatted table."""
    path = os.path.expanduser(path)
    if not os.path.isfile(path):
        raise FileNotFoundError(f"File not found: {path}")

    ext = os.path.splitext(path)[1].lower()

    # CSV — no dependency needed
    if ext == ".csv":
        import csv
        with open(path, encoding="utf-8", errors="replace", newline="") as f:
            reader = csv.reader(f)
            rows = [row for _, row in zip(range(max_rows + 1), reader)]
        sheet_name = os.path.basename(path)
        return _format_table(rows, sheet_name, max_rows, max_cols, path)

    # Excel
    try:
        import openpyxl
    except ImportError:
        return "[Error] openpyxl not installed. Run: pip install openpyxl"

    wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    sheet_names = wb.sheetnames

    if sheet:
        if sheet not in sheet_names:
            return f"[Error] Sheet '{sheet}' not found. Available: {', '.join(sheet_names)}"
        ws = wb[sheet]
        sheet_name = sheet
    else:
        ws = wb.active
        sheet_name = ws.title

    rows = []
    for _, row in zip(range(max_rows + 1), ws.iter_rows(values_only=True)):
        rows.append([str(cell) if cell is not None else "" for cell in row])
    wb.close()

    header = f"[{os.path.basename(path)}] Sheets: {', '.join(sheet_names)}\n"
    return header + _format_table(rows, sheet_name, max_rows, max_cols, path)


def _format_table(
    rows: list[list],
    sheet_name: str,
    max_rows: int,
    max_cols: int,
    path: str,
) -> str:
    if not rows:
        return f"[Sheet: {sheet_name}] (empty)"

    # Trim columns
    rows = [r[:max_cols] for r in rows]
    total_rows = len(rows)
    shown_rows = rows[:max_rows]

    # Compute column widths
    col_count = max(len(r) for r in shown_rows)
    widths = [0] * col_count
    for row in shown_rows:
        for i, cell in enumerate(row):
            widths[i] = max(widths[i], min(len(str(cell)), 30))

    def fmt_row(r):
        cells = list(r) + [""] * (col_count - len(r))
        return " | ".join(str(c)[:30].ljust(widths[i]) for i, c in enumerate(cells))

    lines = [f"[Sheet: {sheet_name}]", fmt_row(shown_rows[0])]
    if len(shown_rows) > 1:
        lines.append("-+-".join("-" * w for w in widths))
        for row in shown_rows[1:]:
            lines.append(fmt_row(row))

    if total_rows > max_rows:
        lines.append(f"... [{total_rows - max_rows} more rows — use max_rows to see more]")

    return "\n".join(lines)


def _excel_write(
    path: str,
    data: list,
    sheet: str = "Sheet1",
    mode: str = "overwrite",
) -> str:
    """
    Write data to an Excel or CSV file.
    data: list of rows, each row is a list of values.
    mode: 'overwrite' (default) or 'append'.
    """
    path = os.path.expanduser(path)
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    ext = os.path.splitext(path)[1].lower()

    if not isinstance(data, list) or not all(isinstance(r, list) for r in data):
        raise ValueError("data must be a list of lists")

    # CSV
    if ext == ".csv":
        import csv
        file_mode = "a" if mode == "append" else "w"
        with open(path, file_mode, encoding="utf-8", newline="") as f:
            writer = csv.writer(f)
            writer.writerows(data)
        action = "Appended" if mode == "append" else "Written"
        return f"{action} {len(data)} rows to {path}"

    # Excel
    try:
        import openpyxl
    except ImportError:
        return "[Error] openpyxl not installed. Run: pip install openpyxl"

    if mode == "append" and os.path.isfile(path):
        wb = openpyxl.load_workbook(path)
        ws = wb[sheet] if sheet in wb.sheetnames else wb.create_sheet(sheet)
        for row in data:
            ws.append(row)
    else:
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = sheet
        for row in data:
            ws.append(row)

    wb.save(path)
    return f"Written {len(data)} rows to sheet '{sheet}' in {path}"


EXCEL_READ_TOOL = Tool(
    schema=ToolSchema(
        name="excel_read",
        description=(
            "Read an Excel (.xlsx) or CSV file and return its contents as a table. "
            "Requires openpyxl for Excel files (pip install openpyxl). "
            "CSV files work without any extra dependency."
        ),
        parameters={
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "Path to the Excel or CSV file",
                },
                "sheet": {
                    "type": "string",
                    "description": "Sheet name to read (default: first/active sheet)",
                },
                "max_rows": {
                    "type": "integer",
                    "description": "Maximum rows to return (default: 500)",
                },
                "max_cols": {
                    "type": "integer",
                    "description": "Maximum columns to return (default: 50)",
                },
            },
            "required": ["path"],
        },
    ),
    fn=_excel_read,
)

EXCEL_WRITE_TOOL = Tool(
    schema=ToolSchema(
        name="excel_write",
        description=(
            "Write data to an Excel (.xlsx) or CSV file. "
            "Creates the file if it doesn't exist. "
            "Requires openpyxl for Excel files (pip install openpyxl)."
        ),
        parameters={
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "Path to the output Excel or CSV file",
                },
                "data": {
                    "type": "array",
                    "items": {"type": "array"},
                    "description": "List of rows, each row is a list of values. First row is typically headers.",
                },
                "sheet": {
                    "type": "string",
                    "description": "Sheet name (default: Sheet1)",
                },
                "mode": {
                    "type": "string",
                    "description": "'overwrite' (default) to replace file, 'append' to add rows",
                },
            },
            "required": ["path", "data"],
        },
    ),
    fn=_excel_write,
)
