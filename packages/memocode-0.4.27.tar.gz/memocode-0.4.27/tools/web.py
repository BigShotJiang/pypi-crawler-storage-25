"""
Built-in tool: web_fetch
Fetch a URL and return readable text content.
HTML is stripped to plain text; JSON/plain text returned as-is.
"""
from .registry import Tool, ToolSchema

_MAX_CHARS = 30_000


def _make_ssl_context():
    """Return an SSL context. Uses certifi bundle if available, else system default."""
    import ssl
    try:
        import certifi
        return ssl.create_default_context(cafile=certifi.where())
    except ImportError:
        pass
    return ssl.create_default_context()


def _web_fetch(
    url: str,
    method: str = "GET",
    headers: dict | None = None,
    body: str | None = None,
    json_body: dict | None = None,
    max_chars: int = _MAX_CHARS,
) -> str:
    import urllib.request
    import urllib.error
    import ssl
    import json as _json

    method = method.upper()

    # Build request body
    data: bytes | None = None
    default_headers: dict = {"User-Agent": "Mozilla/5.0 (compatible; mcode-agent/1.0)"}
    if json_body is not None:
        data = _json.dumps(json_body).encode("utf-8")
        default_headers["Content-Type"] = "application/json"
    elif body is not None:
        data = body.encode("utf-8") if isinstance(body, str) else body
        if "Content-Type" not in (headers or {}):
            default_headers["Content-Type"] = "application/x-www-form-urlencoded"

    merged_headers = {**default_headers, **(headers or {})}
    req = urllib.request.Request(url, data=data, headers=merged_headers, method=method)

    def _fetch(ctx=None):
        kwargs = {"timeout": 15}
        if ctx is not None:
            kwargs["context"] = ctx
        with urllib.request.urlopen(req, **kwargs) as resp:
            return resp.status, resp.headers.get("Content-Type", ""), resp.read()

    def _is_ssl_error(exc) -> bool:
        if isinstance(exc, ssl.SSLError):
            return True
        reason = getattr(exc, "reason", None)
        return isinstance(reason, ssl.SSLError)

    def _fallback_no_verify():
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        return _fetch(ctx)

    status, content_type, raw = 200, "", b""
    try:
        status, content_type, raw = _fetch(_make_ssl_context())
    except (ssl.SSLError, urllib.error.URLError) as e:
        if _is_ssl_error(e):
            try:
                status, content_type, raw = _fallback_no_verify()
                raw = b"[SSL verification skipped]\n" + raw
            except Exception as e2:
                return f"[Error] {e2}"
        else:
            return f"[URL Error] {getattr(e, 'reason', e)}: {url}"
    except urllib.error.HTTPError as e:
        # For non-2xx, still return body so LLM can read the error message
        try:
            raw = e.read()
            content_type = e.headers.get("Content-Type", "")
            status = e.code
        except Exception:
            return f"[HTTP {e.code}] {e.reason}: {url}"
    except Exception as e:
        return f"[Error] {e}"

    # Decode
    charset = "utf-8"
    if "charset=" in content_type:
        charset = content_type.split("charset=")[-1].split(";")[0].strip()
    try:
        text = raw.decode(charset, errors="replace")
    except (LookupError, UnicodeDecodeError):
        text = raw.decode("utf-8", errors="replace")

    # Strip HTML → plain text
    if "html" in content_type.lower():
        text = _html_to_text(text)
    elif "json" in content_type.lower():
        pass  # return as-is
    # else: plain text, xml, etc. — return as-is

    text = text.strip()
    if len(text) > max_chars:
        text = text[:max_chars] + f"\n\n... [truncated — {len(text) - max_chars} chars omitted]"
    prefix = f"[HTTP {status}]\n" if status != 200 else ""
    return prefix + (text or "(empty response)")


def _html_to_text(html: str) -> str:
    """Minimal HTML → readable text conversion without external dependencies."""
    import re

    # Remove <script>, <style>, <head> blocks entirely
    html = re.sub(r"<(script|style|head)[^>]*>.*?</\1>", " ", html,
                  flags=re.DOTALL | re.IGNORECASE)
    # Replace block-level tags with newlines
    html = re.sub(r"<(br|p|div|h[1-6]|li|tr|blockquote)[^>]*>", "\n", html,
                  flags=re.IGNORECASE)
    # Replace links: keep text + URL
    html = re.sub(r'<a\s[^>]*href=["\']([^"\']+)["\'][^>]*>(.*?)</a>',
                  lambda m: f"{m.group(2).strip()} ({m.group(1)})" if m.group(2).strip() else m.group(1),
                  html, flags=re.DOTALL | re.IGNORECASE)
    # Strip all remaining tags
    html = re.sub(r"<[^>]+>", "", html)
    # Decode common HTML entities
    for ent, ch in (("&amp;", "&"), ("&lt;", "<"), ("&gt;", ">"),
                    ("&quot;", '"'), ("&#39;", "'"), ("&nbsp;", " ")):
        html = html.replace(ent, ch)
    # Collapse excessive blank lines
    html = re.sub(r"\n{3,}", "\n\n", html)
    return html.strip()


def _web_search(query: str, max_results: int = 8) -> str:
    """
    Search the web via DuckDuckGo Lite (no API key required).
    Returns formatted list of results: title, URL, snippet.
    """
    import urllib.parse
    import urllib.request
    import urllib.error
    import gzip
    import re

    max_results = min(max(1, max_results), 20)

    # Use DuckDuckGo Lite (POST) — simpler HTML, no bot-challenge JS
    post_data = urllib.parse.urlencode({"q": query, "kl": "wt-wt"}).encode()
    req = urllib.request.Request(
        "https://lite.duckduckgo.com/lite/",
        data=post_data,
        method="POST",
        headers={
            "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36",
            "Content-Type": "application/x-www-form-urlencoded",
            "Accept": "text/html,application/xhtml+xml",
            "Accept-Language": "en-US,en;q=0.9",
            "Accept-Encoding": "gzip, deflate",
            "Origin": "https://lite.duckduckgo.com",
            "Referer": "https://lite.duckduckgo.com/",
        },
    )

    try:
        ssl_ctx = _make_ssl_context()
        with urllib.request.urlopen(req, context=ssl_ctx, timeout=15) as resp:
            raw = resp.read()
    except urllib.error.HTTPError as e:
        return f"[HTTP {e.code}] Search failed: {e.reason}"
    except Exception as e:
        return f"[Search Error] {e}"

    try:
        raw = gzip.decompress(raw)
    except Exception:
        pass

    html = raw.decode("utf-8", errors="replace")

    if len(html) < 500 or (
        "result-link" not in html and "result__a" not in html
    ):
        return "[Search Error] Unexpected response from DuckDuckGo. Try again in a moment."

    def _clean(s: str) -> str:
        s = re.sub(r"<[^>]+>", "", s)
        for ent, ch in (("&amp;", "&"), ("&lt;", "<"), ("&gt;", ">"),
                        ("&quot;", '"'), ("&#39;", "'"), ("&nbsp;", " ")):
            s = s.replace(ent, ch)
        return " ".join(s.split()).strip()

    # DDG Lite HTML structure (mixed quote styles):
    #   <a rel="nofollow" href="URL" class='result-link'>Title</a>
    #   <td class='result-snippet'>Snippet</td>
    title_matches = re.findall(
        r'href="([^"]+)"[^>]*class=[\'"]result-link[\'"]>(.*?)</a>',
        html, re.DOTALL
    )
    snippet_matches = re.findall(
        r"class=['\"]result-snippet['\"][^>]*>\s*(.*?)\s*</td>",
        html, re.DOTALL
    )

    results = []
    for i, (link, title_raw) in enumerate(title_matches[:max_results]):
        title = _clean(title_raw)
        snippet = _clean(snippet_matches[i]) if i < len(snippet_matches) else ""
        if title and link.startswith("http"):
            results.append((title, link, snippet))

    if not results:
        return f"[No results found for: {query}]"

    lines = [f"Search results for: {query}\n"]
    for idx, (title, link, snippet) in enumerate(results, 1):
        lines.append(f"{idx}. {title}")
        lines.append(f"   {link}")
        if snippet:
            lines.append(f"   {snippet}")
        lines.append("")
    return "\n".join(lines).strip()


WEB_SEARCH_TOOL = Tool(
    schema=ToolSchema(
        name="web_search",
        description=(
            "Search the web for current information. "
            "Returns a list of results with title, URL, and snippet. "
            "Use this to find recent news, documentation, package versions, or any topic. "
            "Does not require an API key."
        ),
        parameters={
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "The search query",
                },
                "max_results": {
                    "type": "integer",
                    "description": "Maximum number of results to return (default: 8, max: 20)",
                },
            },
            "required": ["query"],
        },
    ),
    fn=_web_search,
)


WEB_FETCH_TOOL = Tool(
    schema=ToolSchema(
        name="web_fetch",
        description=(
            "Fetch a URL and return its text content. Supports GET, POST, PUT, PATCH, DELETE. "
            "HTML pages are converted to readable plain text; JSON returned as-is. "
            "Use for REST APIs, webhooks, reading documentation, or any HTTP request."
        ),
        parameters={
            "type": "object",
            "properties": {
                "url": {
                    "type": "string",
                    "description": "The URL to fetch (http or https)",
                },
                "method": {
                    "type": "string",
                    "description": "HTTP method: GET (default), POST, PUT, PATCH, DELETE",
                },
                "headers": {
                    "type": "object",
                    "description": "Custom request headers as key-value pairs",
                },
                "json_body": {
                    "type": "object",
                    "description": "Request body as JSON object (sets Content-Type: application/json)",
                },
                "body": {
                    "type": "string",
                    "description": "Raw request body string (use json_body for JSON payloads)",
                },
                "max_chars": {
                    "type": "integer",
                    "description": f"Maximum characters to return (default: {_MAX_CHARS})",
                },
            },
            "required": ["url"],
        },
    ),
    fn=_web_fetch,
)
