"""
Backup utility: timestamped file backups before destructive operations.

Backups are stored in a centralized directory:
  {backup_dir}/{timestamp_ms}_{safe_original_path}

Dedup: if the file content is identical to the most recent backup for that
original path, the backup is skipped and the existing backup path is returned.
"""
from __future__ import annotations
import hashlib
import os
import shutil
import time


def _file_hash(path: str) -> str:
    h = hashlib.md5()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def _safe_name(original_path: str) -> str:
    """Encode original path into a filename-safe string (cross-platform)."""
    import re
    norm = os.path.normpath(os.path.abspath(original_path))
    # Escape any existing __ in the path using DUNDER (no leading/trailing underscore)
    # so it never merges with the __ path separator during decoding
    norm = norm.replace("__", "DUNDER")
    # Replace all path separators and Windows-illegal chars with __
    safe = re.sub(r'[/\\:*?"<>|]', "__", norm)
    # Remove exactly the leading __ produced by the root / separator
    return safe[2:] if safe.startswith("__") else safe


def _latest_backup(backup_dir: str, safe_name: str) -> str | None:
    """Return the most recent backup file for this original path, or None."""
    try:
        entries = [
            e for e in os.listdir(backup_dir)
            if e.endswith("__" + safe_name) or e.endswith("_" + safe_name)
        ]
    except FileNotFoundError:
        return None
    if not entries:
        return None
    entries.sort(reverse=True)  # timestamp prefix → latest first
    return os.path.join(backup_dir, entries[0])


def backup_file(path: str, backup_dir: str | None = None) -> str | None:
    """
    Back up a file if it exists.
    If backup_dir is given, stores backup there with deduplication.
    Returns the backup path, or None if the file didn't exist or was a duplicate.
    """
    path = os.path.expanduser(path)
    if not os.path.isfile(path):
        return None

    if backup_dir is None:
        # Legacy: store adjacent to original file
        ts = int(time.time() * 1000)
        backup_path = f"{path}.bak.{ts}"
        shutil.copy2(path, backup_path)
        return backup_path

    # Centralized backup with dedup
    os.makedirs(backup_dir, exist_ok=True)
    safe = _safe_name(path)
    current_hash = _file_hash(path)

    latest = _latest_backup(backup_dir, safe)
    if latest and os.path.isfile(latest):
        if _file_hash(latest) == current_hash:
            return latest  # identical — reuse existing backup

    ts = int(time.time() * 1000)
    backup_path = os.path.join(backup_dir, f"{ts}__{safe}")
    shutil.copy2(path, backup_path)
    return backup_path


def backup_files(paths: list[str], backup_dir: str | None = None) -> dict[str, str]:
    """
    Back up multiple files. Returns {original_path: backup_path} for files backed up.
    Skipped (non-existent or duplicate) files are omitted from result.
    """
    result = {}
    for path in paths:
        bp = backup_file(path, backup_dir=backup_dir)
        if bp:
            result[path] = bp
    return result


def restore_backup(backup_path: str) -> bool:
    """
    Restore a backup file.
    Supports both legacy ({path}.bak.{ts}) and centralized ({ts}__{safe_path}) formats.
    """
    import re
    if not os.path.exists(backup_path):
        return False

    # Legacy format
    legacy_match = re.match(r"^(.+)\.bak\.\d+$", backup_path)
    if legacy_match:
        shutil.copy2(backup_path, legacy_match.group(1))
        return True

    # Centralized format: decode __-separated path segments
    basename = os.path.basename(backup_path)
    encoded = re.sub(r"^\d+__", "", basename)
    # Detect Windows drive path: starts with single letter + ____  (e.g. C____Users__...)
    win_drive = re.match(r"^([A-Za-z])____(.+)$", encoded)
    if win_drive:
        original = win_drive.group(1) + ":\\" + win_drive.group(2).replace("__", "\\").replace("DUNDER", "__")
    else:
        original = "/" + encoded.replace("__", "/").replace("DUNDER", "__")
    shutil.copy2(backup_path, original)
    return True


def list_backups(backup_dir: str) -> list[str]:
    """List all backup files in backup_dir, sorted oldest first."""
    try:
        entries = sorted(os.listdir(backup_dir))
        return [os.path.join(backup_dir, e) for e in entries]
    except FileNotFoundError:
        return []
