"""
Task planner: decompose a goal into an ordered list of tasks.
Each task maps to exactly one tool call.
"""
from __future__ import annotations
import json
import re
import sys
import os
from dataclasses import dataclass, field
from .llm import LLMAdapter

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from tools.registry import ToolRegistry, ToolSchema


@dataclass
class Task:
    id: int
    tool: str
    args: dict
    description: str
    depends_on: list[int] = field(default_factory=list)
    reversible: bool = True
    backup_paths: list[str] = field(default_factory=list)


_PLAN_PROMPT = """You are a task planner for an AI agent.

Break down the following goal into an ordered list of atomic tasks.
Rules:
- Each task must use exactly ONE tool call
- Tasks can depend on previous tasks (use depends_on with task ids)
- Only use tools from the available tools list
- Be specific with args — provide exact commands, not placeholders
- Use recent context to resolve any references (e.g. "these files", "that directory")
- If a task needs the OUTPUT of a previous task, use {{{{task_N_output}}}} as placeholder in args (DOUBLE braces, e.g. "command": "gzip {{{{task_1_output}}}}")
- Working directory: {work_dir}. Use ABSOLUTE paths for all file operations.

Tool argument names (use EXACTLY these key names):
- shell_exec: command (required), cwd (optional), timeout (optional)
- file_read: path (NOT file_path, NOT filename)
- file_write: path (NOT file_path), content (required), append (optional bool)

Recent context (previous actions in this session):
{context}

Goal: {goal}

Available tools:
{tools}

Respond with JSON only:
[
  {{"id": 1, "tool": "tool_name", "args": {{"command": "exact command"}}, "description": "what this does", "depends_on": []}},
  {{"id": 2, "tool": "file_read", "args": {{"path": "/absolute/path/to/file"}}, "description": "read the file", "depends_on": [1]}}
]"""

_PLAN_PROMPT_ZH = """你是一个AI agent的任务规划器。

将以下目标拆解为有序的原子任务列表。
规则：
- 每个任务只能调用一个工具
- 任务可以依赖前面的任务（使用depends_on填写任务id）
- 只能使用可用工具列表中的工具
- args要具体明确，提供精确的命令，不用占位符
- 利用近期上下文解析引用（如"这些文件"、"那个目录"指的是什么）
- 如果某个任务需要用到前一个任务的输出，在args中使用 {{{{task_N_output}}}} 占位符（双花括号，如 "command": "gzip {{{{task_1_output}}}}"）
- 工作目录：{work_dir}。所有文件操作必须使用绝对路径。

工具参数名（必须使用以下准确的键名）：
- shell_exec: command（必填），cwd（可选），timeout（可选）
- file_read: path（不是 file_path，不是 filename）
- file_write: path（不是 file_path），content（必填），append（可选布尔值）

近期上下文（本次会话的历史操作）：
{context}

目标：{goal}

可用工具：
{tools}

只输出JSON：
[
  {{"id": 1, "tool": "工具名", "args": {{"command": "精确命令"}}, "description": "这个任务做什么", "depends_on": []}},
  {{"id": 2, "tool": "file_read", "args": {{"path": "/绝对路径/文件名"}}, "description": "读取文件", "depends_on": [1]}}
]"""


def _is_chinese(text: str, threshold: float = 0.3) -> bool:
    chinese = len(re.findall(r"[\u4e00-\u9fff]", text))
    total = len(text.replace(" ", "").replace("\n", ""))
    return total > 0 and chinese / total >= threshold


def _format_tools(schemas: list[ToolSchema]) -> str:
    return "\n".join(f"- {s.name}: {s.description}" for s in schemas)


class Planner:
    def __init__(self, llm: LLMAdapter, registry: ToolRegistry):
        self.llm = llm
        self.registry = registry

    def plan(self, goal: str, context: str = "", work_dir: str | None = None) -> tuple[list[Task], list[str]]:
        """
        Returns (tasks, missing_tools).
        If missing_tools is non-empty, tasks is empty — caller should abort.
        """
        tools_str = _format_tools(self.registry.list())
        prompt = _PLAN_PROMPT_ZH if _is_chinese(goal) else _PLAN_PROMPT
        wd_str = work_dir or os.getcwd()
        messages = [
            {"role": "system", "content": "You are a JSON-only task planner. Output only a valid JSON array, no explanations, no code blocks."},
            {"role": "user", "content": prompt.format(goal=goal, tools=tools_str, context=context or "(none)", work_dir=wd_str)},
        ]
        raw = self.llm.complete(messages, max_tokens=800).strip()
        raw = re.sub(r"<think>.*?</think>", "", raw, flags=re.DOTALL).strip()
        if raw.startswith("```"):
            raw = re.sub(r"```[a-z]*\n?", "", raw).strip("`").strip()
        try:
            items = json.loads(raw)
        except json.JSONDecodeError:
            raise ValueError(f"Planner could not parse LLM response: {raw[:200]}")

        tasks = []
        missing = []
        for item in items:
            tool_name = item.get("tool", "")
            if not self.registry.has(tool_name):
                missing.append(tool_name)
            tasks.append(Task(
                id=item.get("id", len(tasks) + 1),
                tool=tool_name,
                args=item.get("args", {}),
                description=item.get("description", ""),
                depends_on=item.get("depends_on", []),
            ))

        if missing:
            return [], list(set(missing))
        return tasks, []
