"""
Task store — lightweight persistent task/bug tracker.
Dynamic state (bugs, todos) separated from static project memory.
Stored at ~/.mcode/tasks/<project>.json
"""
from __future__ import annotations
import json
import os
import time

_DATA_DIR = os.path.expanduser("~/.mcode/tasks")


def _project_path(project: str) -> str:
    os.makedirs(_DATA_DIR, exist_ok=True)
    safe = project.replace("/", "_").replace(" ", "_")
    return os.path.join(_DATA_DIR, f"{safe}.json")


class TaskManager:
    def __init__(self, project: str = "default"):
        self._project = project
        self._path = _project_path(project)

    def _load(self) -> list[dict]:
        if not os.path.exists(self._path):
            return []
        with open(self._path, encoding="utf-8") as f:
            return json.load(f)

    def _save(self, tasks: list[dict]) -> None:
        with open(self._path, "w", encoding="utf-8") as f:
            json.dump(tasks, f, indent=2, ensure_ascii=False)
            f.write("\n")

    def _next_id(self, tasks: list[dict]) -> int:
        return max((t["id"] for t in tasks), default=0) + 1

    # ── Write ──────────────────────────────────────────────────────────────────

    def add(self, title: str, description: str = "") -> dict:
        tasks = self._load()
        # Deduplicate: skip if an open task with the same title already exists
        title_norm = title.strip().lower()
        for t in tasks:
            if t["status"] == "open" and t["title"].strip().lower() == title_norm:
                return t  # return existing task, don't create duplicate
        task = {
            "id": self._next_id(tasks),
            "title": title,
            "description": description,
            "status": "open",
            "created_at": _now(),
            "updated_at": _now(),
            "done_at": None,
        }
        tasks.append(task)
        self._save(tasks)
        return task

    def done(self, task_id: int) -> dict | None:
        tasks = self._load()
        for t in tasks:
            if t["id"] == task_id:
                t["status"] = "done"
                t["done_at"] = _now()
                t["updated_at"] = _now()
                self._save(tasks)
                return t
        return None

    def cancel(self, task_id: int) -> dict | None:
        tasks = self._load()
        for t in tasks:
            if t["id"] == task_id:
                t["status"] = "cancelled"
                t["updated_at"] = _now()
                self._save(tasks)
                return t
        return None

    def update(self, task_id: int, title: str = "", description: str = "") -> dict | None:
        tasks = self._load()
        for t in tasks:
            if t["id"] == task_id:
                if title:
                    t["title"] = title
                if description:
                    t["description"] = description
                t["updated_at"] = _now()
                self._save(tasks)
                return t
        return None

    # ── Read ───────────────────────────────────────────────────────────────────

    def list(self, status: str = "") -> list[dict]:
        tasks = self._load()
        if status:
            tasks = [t for t in tasks if t["status"] == status]
        return tasks

    def open_tasks(self) -> list[dict]:
        return self.list("open")

    def switch_project(self, project: str) -> None:
        self._project = project
        self._path = _project_path(project)


def _now() -> str:
    return time.strftime("%Y-%m-%d %H:%M", time.localtime())
