"""
Brain: control layer entry point.
Agentic tool-use loop — LLM decides when/which tools to call.
"""
from __future__ import annotations
import re
import sys
import os
import json
import threading
import time

# Insert paths first so control/chatmem/ (bundled) takes priority
_ROOT = os.path.dirname(os.path.dirname(__file__))
_CONTROL = os.path.dirname(__file__)
_DATA_DIR = os.path.expanduser("~/.mcode")
sys.path.insert(0, _ROOT)
sys.path.insert(0, _CONTROL)

from prompt_toolkit import prompt as _pt_prompt
from chatmem import ContextManager, ContextConfig
from .llm import make_adapter, ToolCall
from .planner import Task  # Task dataclass used for safety interface
from .audit import AuditLog
from .project_manager import ProjectManager
from .fmt import p_dim, p_info, p_warn, p_ok, p_err, dim, cyan, yellow, green, red
from tools.registry import ToolRegistry
from tools.shell import SHELL_TOOL
from tools.file import FILE_READ_TOOL, FILE_WRITE_TOOL, FILE_EDIT_TOOL, GLOB_TOOL, GREP_TOOL
from tools.web import WEB_FETCH_TOOL
from tools.loader import load_external_tools
from .resources import ResourceManager
from .tasks import TaskManager
import tools.resource as _resource_tools
import tools.task as _task_tools
import safety.safety as _safety


_THINK_RE = __import__("re").compile(r"<think>.*?</think>", __import__("re").DOTALL)


def _content_to_text(content) -> str:
    """Extract plain text from a message content value (str or list of content blocks)."""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        return " ".join(p.get("text", "") for p in content if p.get("type") == "text")
    return ""


def _tool_hint(name: str, args: dict) -> str:
    """Return a one-line dim hint shown after the tool name."""
    if name == "shell_exec":
        cmd = args.get("command", "")
        first = next((l for l in cmd.splitlines() if l.strip()), cmd)
        return dim(f"$ {first}")
    if name in ("file_read", "file_write", "file_edit"):
        return dim(args.get("path", ""))
    if name == "grep":
        pattern = args.get("pattern", "")
        path = args.get("path", "") or args.get("directory", "")
        return dim(f'"{pattern}"' + (f"  {path}" if path else ""))
    if name == "glob":
        return dim(args.get("pattern", ""))
    if name == "web_fetch":
        return dim(args.get("url", ""))
    if name == "memory_search":
        return dim(args.get("query", ""))
    return ""


def _print_tool_header(call: ToolCall):
    """Print tool call header + full multiline command if applicable."""
    hint = _tool_hint(call.name, call.args)
    print(cyan(f"▶  {call.name}") + (f"  {hint}" if hint else ""))
    if call.name == "shell_exec":
        lines = call.args.get("command", "").splitlines()
        if len(lines) > 1:
            for extra in lines[1:]:
                print(dim(f"   {extra}"))


def _print_tool_header_simple(name: str, args: dict):
    """Print tool call header for parsed tool calls (non-ToolCall object)."""
    hint = _tool_hint(name, args)
    print(cyan(f"▶  {name}") + (f"  {hint}" if hint else ""))
    if name == "shell_exec":
        lines = args.get("command", "").splitlines()
        if len(lines) > 1:
            for extra in lines[1:]:
                print(dim(f"   {extra}"))




_PROJECT_MEMORY_JSON = os.path.join(_DATA_DIR, "project_memory.json")

_DEFAULT_PROJECT_MEMORY = {
    "dimensions": {
        "architecture": {"label": "Tech stack, modules, structure",             "stability": 40.0},
        "decisions":    {"label": "Confirmed design decisions and rationale",   "stability": 35.0},
        "conventions":  {"label": "Naming, interface, format conventions",      "stability": 35.0},
        "context":      {"label": "Project background, goals, constraints",     "stability": 30.0},
        "progress":     {"label": "Current development phase and major milestones", "stability": 20.0},
        "completed":    {"label": "Completed tasks and milestones",             "stability": 25.0},
    },
}

def _resolve_date_str(s: str) -> str:
    """Resolve a natural language date string to YYYY-MM-DD. Returns s unchanged on failure."""
    from tools.date import _date_calc as _resolve_date
    if not s or re.match(r"\d{4}-\d{2}-\d{2}$", s):
        return s
    resolved = _resolve_date(s)
    return resolved if not resolved.startswith("[") else s


def _build_project_judge_prompt(dimensions: dict) -> str:
    dim_lines = "\n".join(f"- {name}: {cfg.label}" for name, cfg in dimensions.items())
    dim_names = ", ".join(f'"{name}"' for name in dimensions)
    return f"""You are a project memory editor. Review the conversation and update the project's knowledge base.

Project memory dimensions:
{dim_lines}

Existing project memory:
{{existing}}

New conversation:
{{text}}

Rules:
- One entry per dimension. Key must equal the dimension name (e.g. key="decisions").
- For each dimension, choose one action:
  SKIP       — no new project-relevant information for this dimension.
  SUPPLEMENT — new info extends existing (merge into one updated value).
  UPDATE     — existing info is clearly superseded or corrected.
  DELETE     — the entire dimension entry is explicitly invalidated with nothing to replace it
               (e.g. "we're dropping the X feature entirely", "forget everything about the old auth system").
               Use DELETE only when UPDATE with a replacement value is not possible.
- Special rules by dimension:
  completed: SUPPLEMENT with major milestones only (feature shipped, version released, module implemented).
             Do NOT record individual bug fixes or small tasks — those belong in the task store, not here.
             Never DELETE.
  progress:  Record the current development phase only (e.g. "design", "implementation", "testing", "v0.5 release").
             Do NOT record bugs, unresolved issues, or pending tasks — use task_add tool for those.
             UPDATE when the phase genuinely shifts.
  decisions: SUPPLEMENT by default; UPDATE only if the user makes an explicit statement reversing a prior decision
             (e.g. "we're switching from X to Y", "decided to drop X"). Do NOT update based on the assistant
             discussing alternatives, or the user asking hypothetical questions about other options.
  architecture/conventions: SUPPLEMENT by default; UPDATE on explicit refactor or migration.
- Return ONLY entries that changed. Omit SKIPped ones.
- Exclude: user personal preferences, one-time questions, reasoning processes, bug status, pending tasks.
- Never fabricate or infer information not present in the conversation.
- TASK STORE RULE: If the conversation reveals a new bug, unresolved issue, or pending task that was not
  already recorded, note it in the "task_ops" array (see output format below) — do NOT write it to project memory.
- VALUE FORMAT RULES (critical for later retrieval):
  * Rejected/abandoned options: write "abandoned X — reason" or "rejected X: reason" inline.
    e.g. "Use JWT HS256. Rejected RS256: performance. Rejected Redis sessions: deployment complexity."
  * Reversed decisions: write "changed from X to Y — reason" inline.
    e.g. "Port: 8080 (changed from 3000 — conflicts with existing service)."
  * Active choices: state plainly without hedging.
  These markers must appear in the value text itself so retrieval can surface them directly.

Return a JSON object with two fields:
{{
  "memory": [...],
  "task_ops": [...]
}}

"memory": array of project memory changes (empty if nothing changed):
[{{"key": "<dimension_name>", "value": "<merged or new value>", "dimension": "<dimension_name>", "action": "supplement|update|delete"}}]
Dimension name must be one of: {dim_names}

"task_ops": array of task store operations (empty if none):
[{{"op": "add", "title": "...", "description": "..."}},
 {{"op": "done", "id": <int>}},
 {{"op": "cancel", "id": <int>}}]
Use "add" for newly discovered bugs or tasks. Use "done"/"cancel" only if the conversation clearly resolves a task.

Output JSON only:"""


def _build_project_judge_prompt_zh(dimensions: dict) -> str:
    dim_lines = "\n".join(f"- {name}: {cfg.label}" for name, cfg in dimensions.items())
    dim_names = ", ".join(f'"{name}"' for name in dimensions)
    return f"""你是一个项目记忆编辑器。审查对话内容，更新项目知识库。

项目记忆维度：
{dim_lines}

当前项目记忆：
{{existing}}

新对话：
{{text}}

规则：
- 每个维度只有一条记录，key 等于维度名（如 key="decisions"）。
- 对每个维度，选择以下操作之一：
  跳过 — 该维度没有新的项目相关信息。
  补充 — 新信息扩展了已有内容（合并为一个更新后的 value）。
  修正 — 已有信息被明确推翻或替换。
  删除 — 整个维度条目被明确作废且无替代内容
         （如"我们整个X功能都不做了"、"忘掉旧认证系统的一切"）。
         仅在无法用修正+新值替代时才使用删除。
- 各维度特殊规则：
  completed：仅补充里程碑级成果（功能上线、版本发布、模块实现完成）。
             不记录单个 bug 修复或小任务——这些属于 task store，不属于项目记忆。不可删除。
  progress：只记录当前开发阶段（如"设计期"、"实现期"、"测试期"、"v0.5 发布"）。
            不记录 bug、待修问题或待办任务——这些用 task_add 工具处理。
            阶段真正转换时才修正。
  decisions：默认补充；仅当用户明确陈述推翻先前决策时才修正
             （如"我们从X换成Y了"、"决定放弃X"）。不得因为
             AI 讨论替代方案、或用户询问假设性问题而修正。
  architecture/conventions：默认补充；仅在明确重构或迁移时修正。
- 只返回发生变化的条目，跳过的不返回。
- 不包括：用户个人偏好、一次性问题、推理过程、bug 状态、待办任务。
- 严禁捏造或推断对话中未出现的信息。
- TASK STORE 规则：对话中出现新 bug、未解决问题或待办任务时，写入 task_ops 数组，不写入项目记忆。
- VALUE 格式要求（影响后续检索质量，必须遵守）：
  * 已放弃/拒绝的方案：在 value 文字中直接写明"放弃X——原因"或"拒绝X：原因"。
    例："使用 JWT HS256。放弃 RS256——性能问题。放弃 Redis 会话——部署复杂度。"
  * 发生变更的决策：写明"从X改为Y——原因"。
    例："端口：8080（从3000改过来——与已有服务冲突）。"
  * 当前有效的选择：直接陈述，不加模糊措辞。
  这些标记必须写在 value 文字本身中，便于检索时直接获取语义。

返回包含两个字段的 JSON 对象：
{{
  "memory": [...],
  "task_ops": [...]
}}

"memory"：项目记忆变更数组（无变化则为空数组）：
[{{"key": "<维度名>", "value": "<合并后或新的内容>", "dimension": "<维度名>", "action": "supplement|update|delete"}}]
维度名必须是以下之一：{dim_names}

"task_ops"：task store 操作数组（无操作则为空数组）：
[{{"op": "add", "title": "...", "description": "..."}},
 {{"op": "done", "id": <整数>}},
 {{"op": "cancel", "id": <整数>}}]
"add" 用于新发现的 bug 或任务；"done"/"cancel" 仅在对话明确解决了某任务时使用。

只输出JSON："""


_DEFAULT_CHATMEM = {
    "llm": {},
    "dimensions": {
        "communication": {"label": "Expression style, language preference, tone, detail level",                                        "stability": 45.0},
        "autonomy":      {"label": "How much decision authority delegated to LLM: executes directly vs presents options vs validates", "stability": 40.0},
    },
}

_DEFAULT_AGENT = {
    "auto_mode": False,
    "verbose": False,
    "parallel_tasks": True,
    "llm_timeout": 30,
    "max_tool_iter": 40,
    "auto_max_tool_iter": 100,
    "max_tool_output": 20000,
    "require_confirm_on_irreversible": True,
    "active_model": "",
    "models": {
        "minimax": {
            "provider": "openai",
            "model": "MiniMax-M2.7",
            "base_url": "https://api.minimaxi.com/v1",
            "api_key_env": "MINIMAX_API_KEY",
            "context_window": 128000
        },
        "kimi": {
            "provider": "openai",
            "model": "kimi-k2.6",
            "base_url": "https://api.moonshot.cn/v1",
            "api_key_env": "MOONSHOT_API_KEY",
            "context_window": 128000,
            "compress_model": "kimi-k2.6",
            "vision": True,
            "extra_body": {
                "thinking": {
                    "type": "disabled"
                }
            }
        },
        "glm": {
            "provider": "openai",
            "model": "glm-5.1",
            "base_url": "https://open.bigmodel.cn/api/paas/v4",
            "api_key_env": "GLM_API_KEY",
            "context_window": 128000,
            "vision": True,
            "extra_body": {
                "thinking": {
                    "type": "disabled"
                }
            }
        },
        "claude-haiku": {
            "provider": "anthropic",
            "model": "claude-haiku-4-5-20251001",
            "api_key_env": "ANTHROPIC_API_KEY",
            "context_window": 200000,
            "vision": True
        }
    },
}


def _init_data_dir() -> tuple[str, str, str]:
    """
    Ensure ~/.mcode/ exists with agent.json, chatmem.json, project_memory.json.
    Migrates from control/ if old files exist and new ones don't.
    Returns (agent_json_path, chatmem_json_path, project_memory_json_path).
    """
    import json as _json
    import shutil as _shutil

    os.makedirs(_DATA_DIR, exist_ok=True)
    os.makedirs(os.path.join(_DATA_DIR, "tools"), exist_ok=True)

    agent_path = os.path.join(_DATA_DIR, "agent.json")
    chatmem_path = os.path.join(_DATA_DIR, "chatmem.json")
    project_memory_path = _PROJECT_MEMORY_JSON

    # Migrate agent.json from old location
    old_agent = os.path.join(_CONTROL, "agent.json")
    if not os.path.exists(agent_path):
        if os.path.exists(old_agent):
            _shutil.copy2(old_agent, agent_path)
        else:
            with open(agent_path, "w", encoding="utf-8") as f:
                _json.dump(_DEFAULT_AGENT, f, indent=2, ensure_ascii=False)
                f.write("\n")

    # Migrate chatmem.json from old location (only dimensions, llm is auto-managed)
    old_chatmem = os.path.join(_CONTROL, "chatmem.json")
    if not os.path.exists(chatmem_path):
        if os.path.exists(old_chatmem):
            _shutil.copy2(old_chatmem, chatmem_path)
        else:
            with open(chatmem_path, "w", encoding="utf-8") as f:
                _json.dump(_DEFAULT_CHATMEM, f, indent=2, ensure_ascii=False)
                f.write("\n")

    # Create project_memory.json with default project dimensions
    if not os.path.exists(project_memory_path):
        with open(project_memory_path, "w", encoding="utf-8") as f:
            _json.dump(_DEFAULT_PROJECT_MEMORY, f, indent=2, ensure_ascii=False)
            f.write("\n")

    return agent_path, chatmem_path, project_memory_path


def _sync_active_model(agent_cfg: dict, chatmem_json_path: str | None):
    """Write the active model profile into chatmem.json's llm section."""
    import os as _os

    if not chatmem_json_path or not os.path.exists(chatmem_json_path):
        return
    models = agent_cfg.get("models", {})
    active = agent_cfg.get("active_model", "")
    profile = models.get(active)

    # Auto-detect: if active_model is empty, find the first model with a valid API key
    if not active or not profile:
        for model_name, model_cfg in models.items():
            api_key_env = model_cfg.get("api_key_env", "")
            if api_key_env and _os.environ.get(api_key_env):
                active = model_name
                profile = model_cfg
                agent_cfg["active_model"] = active
                # Save the updated active_model back to agent.json
                agent_path, *_ = _init_data_dir()
                with open(agent_path, encoding="utf-8") as f:
                    import json as _json
                    data = _json.load(f)
                data["active_model"] = active
                with open(agent_path, "w", encoding="utf-8") as f:
                    _json.dump(data, f, indent=2, ensure_ascii=False)
                    f.write("\n")
                break

    if not profile:
        return

    import json as _json
    with open(chatmem_json_path, encoding="utf-8") as f:
        data = _json.load(f)
    # Replace llm section with profile entirely (don't merge — avoids stale keys from previous model)
    # Preserve non-LLM keys in existing llm section that aren't model-specific (none currently)
    data["llm"] = dict(profile)
    with open(chatmem_json_path, "w", encoding="utf-8") as f:
        _json.dump(data, f, indent=2, ensure_ascii=False)
        f.write("\n")


class Brain:
    def __init__(
        self,
        config_path: str | None = None,
        verbose: bool | None = None,
        project: str | None = None,
        no_lock: bool = False,
    ):
        # Ensure ~/.mcode/ exists; migrate old files if needed
        agent_path, chatmem_path, project_memory_path = _init_data_dir()

        self._agent_cfg_path = agent_path
        self._config_path = config_path or chatmem_path

        import json as _json
        agent_cfg: dict = {}
        if os.path.exists(self._agent_cfg_path):
            with open(self._agent_cfg_path, encoding="utf-8") as f:
                agent_cfg = _json.load(f)

        # Sync active model profile → chatmem.json before loading ContextConfig
        _sync_active_model(agent_cfg, chatmem_path)

        cfg = ContextConfig.from_json(chatmem_path)

        # Agent-level config (CLI args override chatmem.json)
        self.auto_mode: bool = agent_cfg.get("auto_mode", False)
        self.bypass_safety: bool = False  # session-only, never persisted
        self.tool_choice: str = "auto"  # "auto" | "required"; first-iteration only, session-only
        self.verbose = verbose if verbose is not None else agent_cfg.get("verbose", False)
        llm_timeout: int = agent_cfg.get("llm_timeout", 30)
        self._agent_cfg = agent_cfg

        # Inject api_key_env from agent_cfg into cfg.llm so make_adapter can resolve it
        active = agent_cfg.get("active_model", "")
        profile = agent_cfg.get("models", {}).get(active, {})
        if profile.get("api_key_env"):
            cfg.llm.api_key_env = profile["api_key_env"]
        if profile.get("api_key"):
            cfg.llm.api_key = profile["api_key"]
        if profile.get("base_url"):
            cfg.llm.base_url = profile["base_url"]

        # Validate API key is resolvable (fail fast with a clear message)
        _api_key = cfg.llm.resolve_api_key()
        if not _api_key:
            if not active:
                raise RuntimeError(
                    "Your agent.json is missing 'active_model' configuration.\n"
                    "Please configure your LLM model in ~/.mcode/agent.json:\n"
                    "  1. Set 'active_model' to your desired model name (e.g., 'minimax')\n"
                    "  2. Configure the corresponding model in 'models' section\n"
                    "  3. Set the required API key environment variable"
                )
            env_var = profile.get("api_key_env", "")
            msg = f"API key not found for model '{active}'."
            if env_var:
                msg += f" Set the {env_var} environment variable."
            raise RuntimeError(msg)

        self.llm = make_adapter(cfg, timeout=llm_timeout)

        # Project/session management
        self.projects = ProjectManager()
        if project:
            self.projects.switch_project(project)
        else:
            self.projects.find_or_create_for_cwd()

        # Project memory — per-project CoreMemory in the same project DB
        self.project_memory = self._make_project_memory(
            cfg, _api_key, project_memory_path
        )

        # Memory layer — one DB per project, core DB shared
        self.memory = ContextManager.create(
            config=cfg,
            api_key=_api_key,
            db_path=self.projects.project_db_path,
            core_db_path=self.projects.core_db_path,
            no_lock=no_lock,
            extra_context_fn=self._project_context_fn,
            on_compress_fn=(
                self._run_project_judge if self.project_memory else None
            ),
            auto_recall=False,
        )

        # Audit log
        self.audit = AuditLog(os.path.join(_DATA_DIR, "audit.db"))

        # Resource registry — local file index shared across projects
        active_model = agent_cfg.get("active_model", "")
        _model_cfg = agent_cfg.get("models", {}).get(active_model, {})
        self.resources = ResourceManager(
            api_key=os.environ.get(_model_cfg.get("api_key_env", ""), ""),
            model=_model_cfg.get("compress_model") or _model_cfg.get("model", ""),
            base_url=_model_cfg.get("base_url"),
            extra_body=_model_cfg.get("extra_body"),
            provider=_model_cfg.get("provider", "openai"),
        )
        _resource_tools._manager = self.resources
        threading.Thread(target=self.resources.sync, daemon=True, name="resource-sync").start()

        self.tasks = TaskManager(project=self.projects.current_project)
        _task_tools._manager = self.tasks

        # Tool registry — built-ins + auto-discovered externals
        self.registry = ToolRegistry()
        self.registry.register(SHELL_TOOL)
        self.registry.register(FILE_READ_TOOL)
        self.registry.register(FILE_WRITE_TOOL)
        self.registry.register(FILE_EDIT_TOOL)
        self.registry.register(GLOB_TOOL)
        self.registry.register(GREP_TOOL)
        self.registry.register(WEB_FETCH_TOOL)
        self.registry.register(self._make_memory_search_tool())
        self.registry.register(self._make_project_query_tool())
        self.registry.register(self._make_activity_log_tool())
        load_external_tools(self.registry)

        self._max_tool_iter: int = agent_cfg.get("max_tool_iter", 40)
        self._auto_max_tool_iter: int = agent_cfg.get("auto_max_tool_iter", 100)
        self._max_tool_output: int = agent_cfg.get("max_tool_output", 20000)

        # Interrupt support
        self._stop_event = threading.Event()
        self._last_was_action = False
        self._spinner_stop: threading.Event | None = None  # set by run.py before each turn
        self._judge_thread: threading.Thread | None = None

    # ------------------------------------------------------------------
    # Main entry point
    # ------------------------------------------------------------------

    def run(self, user_input: str) -> str:
        """Process one user turn. Returns response string."""
        return "".join(self.stream_run(user_input))

    def _is_vision_model(self) -> bool:
        """Return True if the active model has vision: true in its config."""
        active = self._agent_cfg.get("active_model", "")
        profile = self._agent_cfg.get("models", {}).get(active, {})
        return bool(profile.get("vision", False))

    _IMAGE_ATTACH_RE = __import__("re").compile(r"\[IMAGE_ATTACH:([^\]]+)\]")

    def _extract_image_attachments(self, tool_results: list[dict]) -> tuple[list[str], list[dict]]:
        """
        Scan tool result content for [IMAGE_ATTACH:/path] markers.
        Returns (image_paths, cleaned_tool_results) with markers stripped.
        """
        import re
        paths: list[str] = []
        cleaned = []
        for msg in tool_results:
            content = msg.get("content", "")
            found = re.findall(r"\[IMAGE_ATTACH:([^\]]+)\]", content)
            paths.extend(found)
            stripped = re.sub(r"\[IMAGE_ATTACH:[^\]]+\]", "", content).strip()
            cleaned.append({**msg, "content": stripped})
        return paths, cleaned

    def _build_image_message(self, image_paths: list[str]) -> dict | None:
        """
        Build a multimodal user message with base64-encoded images.
        Resizes to max 1024px on longest side to keep token count low.
        Returns None if no valid images.
        """
        import base64, os as _os
        parts: list[dict] = []
        for path in image_paths:
            path = _os.path.expanduser(path)
            if not _os.path.isfile(path):
                continue
            # Attempt resize with PIL; fall back to raw bytes
            try:
                from PIL import Image as _PIL
                import io as _io
                with _PIL.open(path) as img:
                    max_side = 1024
                    w, h = img.size
                    if max(w, h) > max_side:
                        scale = max_side / max(w, h)
                        img = img.resize((int(w * scale), int(h * scale)), _PIL.LANCZOS)
                    buf = _io.BytesIO()
                    fmt = "JPEG" if path.lower().endswith(".jpg") else "PNG"
                    if img.mode in ("RGBA", "P") and fmt == "JPEG":
                        img = img.convert("RGB")
                    img.save(buf, format=fmt)
                    raw = buf.getvalue()
                    media_type = "image/jpeg" if fmt == "JPEG" else "image/png"
            except Exception:
                with open(path, "rb") as f:
                    raw = f.read()
                media_type = "image/jpeg" if path.lower().endswith(".jpg") else "image/png"

            b64 = base64.b64encode(raw).decode("ascii")
            parts.append({
                "type": "image_url",
                "image_url": {"url": f"data:{media_type};base64,{b64}"},
            })

        if not parts:
            return None
        parts.insert(0, {"type": "text", "text": "Extracted images from PDF:"})
        return {"role": "user", "content": parts}

    def stream_run(self, user_input: str):
        """Generator for the REPL. Yields text chunks."""
        self._stop_event.clear()
        yield from self._agent_loop(user_input)


    def _agent_loop(self, user_input: str):
        """
        Tool-use agentic loop using native function calling (OpenAI / Anthropic).
        Generator — yields text chunks for the final response.
        """
        from .llm import LLMResponse
        from safety.backup import backup_file as _backup_file
        if self.auto_mode:
            _system = (
                "You are an autonomous coding agent. Complete the user's task fully and independently.\n\n"
                "EXECUTION RULES:\n"
                "- Use tools to do everything: read files, write files, run commands, search code, fetch URLs.\n"
                "- NEVER guess, fabricate, or recall information that must come from a tool. "
                "If the task requires fetching a URL, reading a file, or running a command — call the tool. "
                "Do not invent the result.\n"
                "- To fetch any URL or HTTP endpoint, always call web_fetch. Never guess the response.\n"
                "- Do NOT output text mid-task. Keep calling tools until the task is 100% done.\n"
                "- Before editing a file, always read it first with file_read.\n"
                "- For targeted changes use file_edit; for new files use file_write.\n"
                "- If a tool fails, diagnose the error from the output and retry with a corrected approach.\n"
                "- Verify your work: run tests, check command output, re-read files after editing.\n"
                "- Only output text ONCE at the very end: a concise summary of what was done. "
                "Do not output diffs, patch format, or full file contents — describe changes in plain text.\n\n"
                "DECISION RULES:\n"
                "- When multiple approaches exist, pick the most direct one and execute it.\n"
                "- Do not ask for clarification. Make a reasonable assumption and proceed.\n"
                "- If genuinely blocked (missing credentials, hardware dependency, etc.), "
                "stop and explain clearly why."
            )
        else:
            _system = (
                "You are a coding assistant with access to tools. Never guess, describe, or simulate — always act via tools.\n\n"
                "TOOL USAGE:\n"
                "- run commands → shell_exec | read files → file_read | write files → file_write\n"
                "- edit files → file_edit (read first) | fetch URLs → web_fetch\n"
                "- arithmetic / percentages / formulas → calc (never compute mentally)\n"
                "- Keep calling tools until the task is fully done.\n\n"
                "INFORMATION SOURCES (use in this order):\n"
                "1. Current context — use directly if available\n"
                "2. Project files — for technical details, use shell_exec or file_read\n"
                "3. Recent activity — for 'today / this session / just now / in the past N days', "
                "MUST call activity_log_query FIRST; if it returns nothing, say so — "
                "do not supplement from other memory sources\n"
                "4. Past sessions — if information may be from a previous session, "
                "call memory_search before concluding it is unknown\n"
                "5. If none of the above yields an answer, say so explicitly — never guess\n\n"
                "LOCAL RESOURCES: If the task needs local files or data (spreadsheets, documents, reports), "
                "call resource_find first to locate relevant files, then read them with the appropriate tool. "
                "Registration workflow: call resource_scan (single file) or resource_scan_dir (directory) — "
                "the CLI will automatically prompt the user for confirmation. "
                "Never call resource_confirm or resource_register directly. "
                "Deletion workflow: call resource_delete to stage entries — the CLI will prompt for confirmation.\n\n"
                "TASK TRACKING: Use task_add when a bug is discovered or follow-up work is identified. "
                "Use task_list when the user says '继续', 'continue', or asks what's pending. "
                "Use task_done when a bug is fixed or a task is completed. "
                "NEVER write bug status or pending tasks to project memory.\n\n"
                "IMPLEMENTATION RULE: Before writing any files or running build commands, ALWAYS call "
                "project_query first to check existing tech stack and decisions. "
                "If project_query returns empty AND the directory is empty (ls shows no files), "
                "stop and ask the user ONE clarifying question (e.g. what tech stack, what the project is for). "
                "Never infer or assume a tech stack — do not write a single file until context is confirmed.\n\n"
                "MEMORY RULES:\n"
                "- Project memory entries show age like (14d ago) — entries older than 30 days may be stale, consider verifying with memory_search\n"
                "- Entries with 'Rejected' / 'abandoned' / '放弃' mean explicitly ruled out — do not re-suggest"
            )
        _effective_input = user_input
        user_msg = [
            {"role": "system", "content": _system},
            {"role": "user", "content": _effective_input},
        ]
        enriched = self.memory._build_context(user_msg)
        loop_msgs = list(enriched)
        tools = self.registry.to_openai_tools()

        any_tool_called = False
        final_text = ""
        tool_log = []
        _interrupted = False

        max_iter = self._auto_max_tool_iter if self.auto_mode else self._max_tool_iter
        # Stuck detection: track last seen (tool, args_repr) per iteration
        _stuck_streak = 0
        _last_call_sig: str | None = None
        _STUCK_THRESHOLD = 3  # abort if same call repeated this many times
        for iteration in range(max_iter):
            if self._stop_event.is_set():
                break

            # Stream with native function calling; collect text, capture final LLMResponse
            text_chunks: list[str] = []
            llm_response: LLMResponse | None = None
            try:
                # Enforce tool_choice only on the first iteration.
                # Subsequent iterations must stay "auto" so the model can
                # give a final text response after completing multi-step tasks.
                tc = self.tool_choice if iteration == 0 else "auto"
                for item in self.llm.stream_with_tools(loop_msgs, tools,
                                                       tool_choice=tc):
                    if self._stop_event.is_set():
                        break
                    if isinstance(item, str):
                        text_chunks.append(item)
                    else:
                        llm_response = item
            except KeyboardInterrupt:
                self._stop_event.set()
                _interrupted = True
                print()
                break

            if self._stop_event.is_set():
                break

            if llm_response is None:
                # Unexpected — treat accumulated text as final response
                full_text = "".join(text_chunks)
                if full_text.strip():
                    yield _THINK_RE.sub("", full_text).strip()
                break

            calls = llm_response.tool_calls

            if not calls:
                # No tool calls — final text response
                self._last_was_action = any_tool_called
                text = llm_response.text or "".join(text_chunks)
                yield _THINK_RE.sub("", text).strip()
                break

            # Stuck detection: if all calls in this iteration are identical to last, count streak
            call_sig = "|".join(f"{tc.name}:{json.dumps(tc.args, sort_keys=True)}" for tc in calls)
            if call_sig == _last_call_sig:
                _stuck_streak += 1
            else:
                _stuck_streak = 0
            _last_call_sig = call_sig

            if _stuck_streak >= _STUCK_THRESHOLD:
                final_text = (
                    f"(agent stuck: same tool call repeated {_stuck_streak + 1} times — "
                    f"aborting to prevent infinite loop)"
                )
                yield red(final_text)
                break

            # Append the assistant message (contains tool_calls in OpenAI format)
            if llm_response.assistant_msg:
                loop_msgs.append(llm_response.assistant_msg)
            any_tool_called = True

            tool_results = []
            _aborted = False
            for i, tc in enumerate(calls):
                if self._stop_event.is_set():
                    _aborted = True
                    break

                print()  # blank line before each tool call

                # Build Task for safety interface
                task = Task(
                    id=iteration * 100 + i,
                    tool=tc.name,
                    args=tc.args,
                    description=f"{tc.name}({tc.args})",
                    depends_on=[],
                )
                # Inject work_dir for path resolution
                exec_args = dict(tc.args)
                work_dir = self.projects.work_dir
                if work_dir:
                    if tc.name == "shell_exec" and "cwd" not in exec_args:
                        exec_args["cwd"] = work_dir
                    elif tc.name in ("file_read", "file_write", "file_edit", "grep"):
                        p = exec_args.get("path", "")
                        if p and not os.path.isabs(p) and not p.startswith("~"):
                            exec_args["path"] = os.path.join(work_dir, p)
                    elif tc.name == "glob":
                        if "base_dir" not in exec_args:
                            exec_args["base_dir"] = work_dir

                # Stop spinner before any user-visible output or confirmation prompt
                if self._spinner_stop and not self._spinner_stop.is_set():
                    self._spinner_stop.set()
                    time.sleep(0.05)

                if not self._confirm_tool_call(task):
                    # User said no — stop the loop
                    self._stop_event.set()
                    _aborted = True
                    yield "\n" + yellow("Operation cancelled. What would you like to do instead?")
                    break

                # Backup file before destructive edits (enables /undo)
                _backup_map: dict[str, str] = {}
                if tc.name in ("file_write", "file_edit"):
                    _target = exec_args.get("path", "")
                    if _target:
                        _bp = _backup_file(_target, self.projects.backup_dir)
                        if _bp:
                            _backup_map[_target] = _bp

                # Show file_write/file_edit diff before executing
                if tc.name == "file_write":
                    self._show_write_diff(tc.args)
                elif tc.name == "file_edit":
                    self._show_edit_diff(exec_args)

                _print_tool_header_simple(tc.name, tc.args)

                try:
                    result = self.registry.call(
                        tc.name, exec_args,
                        output_cb=lambda line: print(f"  {line}"),
                    )
                except KeyboardInterrupt:
                    self._stop_event.set()
                    _aborted = True
                    print(red("\n🚫  interrupted"))
                    break

                icon = green("✓") if result.success else red("✗")
                #summary = (result.output if result.success else result.error)[:120].splitlines()[0]
                summary = ((result.output if result.success else result.error)[:120].splitlines() or [""])[0] 
                backup_hint = dim(f"  💾 backup saved") if _backup_map else ""
                print(f"{icon}  {dim(summary)}{backup_hint}")
                content = result.output if result.success else f"ERROR: {result.error}"

                if len(content) > self._max_tool_output:
                    omitted = len(content) - self._max_tool_output
                    content = content[:self._max_tool_output] + f"\n... [truncated, {omitted} chars omitted]"
                entry: dict = {
                    "tool": tc.name, "args": tc.args,
                    "success": result.success, "output": content[:500],
                }
                if _backup_map:
                    entry["backups"] = _backup_map
                tool_log.append(entry)
                tool_results.append({
                    "role": "tool",
                    "tool_call_id": tc.id,
                    "content": content,
                })

            if _aborted:
                # Remove the assistant message we already appended — loop_msgs stays consistent
                if llm_response.assistant_msg and loop_msgs and loop_msgs[-1] is llm_response.assistant_msg:
                    loop_msgs.pop()
            else:
                # Extract [IMAGE_ATTACH:] markers from tool results before sending to LLM
                if self._is_vision_model():
                    img_paths, tool_results = self._extract_image_attachments(tool_results)
                    loop_msgs.extend(tool_results)
                    if img_paths:
                        img_msg = self._build_image_message(img_paths)
                        if img_msg:
                            loop_msgs.append(img_msg)
                else:
                    loop_msgs.extend(tool_results)
        else:
            # Hit max iterations
            final_text = f"(stopped after {max_iter} iterations)"
            yield final_text

        # Capture turn count before _post_turn adds the current turn
        _turn_idx = len(self.memory.list_turns())

        # Save to memory — skip if interrupted (avoid empty/partial turn polluting context)
        if not _interrupted:
            self.memory._post_turn(_content_to_text(user_input), final_text, user_msg)

        if any_tool_called:
            _user_text = _content_to_text(user_input)
            self.audit.record(_user_text, _user_text, [], True, tool_log,
                              project=self.projects.current_project,
                              turn_idx=_turn_idx)

    # ------------------------------------------------------------------
    # Per-tool safety + confirmation
    # ------------------------------------------------------------------

    def _confirm_tool_call(self, task: Task) -> bool:
        from safety.backup import backup_files

        work_dir = self.projects.work_dir

        # ── Auto mode: hard boundaries, zero prompts ───────────────────────────
        # ── Bypass safety: skip all checks ────────────────────────────────────
        if self.bypass_safety:
            return True

        if self.auto_mode:
            user_wl = self._agent_cfg.get("auto_whitelist", None)
            whitelist = list(set(_safety.DEFAULT_AUTO_WHITELIST) | set(user_wl)) if user_wl else None
            result = _safety.check_auto(task, work_dir=work_dir, whitelist=whitelist)
            if result.violation:
                print(red(f"\n🛑  AUTO-BLOCKED  {result.reason}"))
                return False
            if result.backup_paths:
                backed_up = backup_files(result.backup_paths, backup_dir=self.projects.backup_dir)
                for orig, bp in backed_up.items():
                    print(dim(f"💾  backup → {bp}"))
            return True

        # ── Human mode: zone checks + confirmation prompts ─────────────────────
        from safety.policy import is_always_allowed, remember_always, get_allowed_paths

        result = _safety.check(task, work_dir=work_dir, allowed_paths=get_allowed_paths())

        if result.violation:
            print(red(f"\n🛑  BLOCKED  {task.description}"))
            print(dim(f"   {result.reason}"))
            return False

        if result.backup_paths:
            backed_up = backup_files(result.backup_paths, backup_dir=self.projects.backup_dir)
            for orig, bp in backed_up.items():
                print(dim(f"💾  backup → {bp}"))

        if result.requires_confirmation:
            op = result.operation_class
            if op and is_always_allowed(op):
                return True

            if result.script_path and os.path.isfile(result.script_path):
                try:
                    content = open(result.script_path, encoding="utf-8").read()
                    print(yellow(f"\n📄  Script: {result.script_path}"))
                    print(dim("─" * 60))
                    for line in content.splitlines()[:40]:
                        print(dim(f"   {line}"))
                    print(dim("─" * 60))
                except OSError:
                    pass

            print(yellow(f"\n⚠️   {result.reason}"))
            print(dim(f"    {task.description}"))

            if result.can_always:
                raw = _pt_prompt("    Proceed? [y]es  [n]o  [a]lways ❯ ").strip().lower()
            else:
                raw = _pt_prompt("    Proceed? [y]es  [n]o ❯ ").strip().lower()

            if raw in ("a", "always") and result.can_always:
                remember_always(op)
                print(cyan(f"📌  policy saved: always allow [{op}]"))
            elif raw not in ("y", "yes"):
                print(red("🚫  cancelled"))
                return False
            return True

        return True

    # ------------------------------------------------------------------
    # File write/edit diff
    # ------------------------------------------------------------------

    def _print_diff(self, old_content: str, new_content: str, path: str):
        import difflib
        if old_content == new_content:
            print(dim("  (no changes)"))
            return
        diff = list(difflib.unified_diff(
            old_content.splitlines(keepends=True),
            new_content.splitlines(keepends=True),
            fromfile=f"a/{path}",
            tofile=f"b/{path}",
            lineterm="",
        ))
        print()
        for line in diff[:60]:
            if line.startswith("+"):
                print(green(f"  {line}"))
            elif line.startswith("-"):
                print(red(f"  {line}"))
            else:
                print(dim(f"  {line}"))
        if len(diff) > 60:
            print(dim(f"  ... ({len(diff)-60} more lines)"))
        print()

    def _resolve_full_path(self, path: str) -> str | None:
        full = os.path.expanduser(path)
        if not os.path.isabs(full):
            full = os.path.join(self.projects.work_dir, full)
        return full if os.path.isfile(full) else None

    def _show_write_diff(self, args: dict):
        path = args.get("path", "")
        new_content = args.get("content", "")
        if not path:
            return
        full_path = self._resolve_full_path(path)
        if not full_path:
            return  # new file, no diff needed
        try:
            old_content = open(full_path, encoding="utf-8").read()
        except OSError:
            return
        self._print_diff(old_content, new_content, path)

    def _show_edit_diff(self, args: dict):
        path = args.get("path", "")
        old_str = args.get("old_str", "")
        if not path or not old_str:
            return
        full_path = self._resolve_full_path(path)
        if not full_path:
            return
        try:
            old_content = open(full_path, encoding="utf-8").read()
        except OSError:
            return
        new_content = old_content.replace(old_str, args.get("new_str", ""), 1)
        self._print_diff(old_content, new_content, path)

    # ------------------------------------------------------------------
    # Model switching
    # ------------------------------------------------------------------

    def list_models(self) -> dict:
        """Return the models dict from agent.json."""
        return self._agent_cfg.get("models", {})

    def switch_model(self, name: str):
        """Switch to a named model profile. Updates agent.json + chatmem.json + live adapters."""
        import json as _json
        models = self._agent_cfg.get("models", {})
        if name not in models:
            raise KeyError(f"Model '{name}' not found in agent.json models")
        # Update agent.json
        self._agent_cfg["active_model"] = name
        with open(self._agent_cfg_path, "w", encoding="utf-8") as f:
            _json.dump(self._agent_cfg, f, indent=2, ensure_ascii=False)
            f.write("\n")
        # Sync to chatmem.json and rebuild adapters
        _sync_active_model(self._agent_cfg, self._config_path)
        cfg = ContextConfig.from_json(self._config_path) if self._config_path else ContextConfig()
        key = cfg.llm.resolve_api_key()
        if not key:
            profile = models.get(name, {})
            env_var = profile.get("api_key_env", "")
            msg = f"API key not found for model '{name}'."
            if env_var:
                msg += f" Set the {env_var} environment variable."
            raise RuntimeError(msg)
        timeout = self._agent_cfg.get("llm_timeout", 30)
        self.llm = make_adapter(cfg, timeout=timeout)
        self._reinit_memory()

    # ------------------------------------------------------------------
    # Project / session switching
    # ------------------------------------------------------------------

    def switch_project(self, name: str):
        self.end_session()
        self.projects.switch_project(name)
        self._reinit_memory()
        self.tasks.switch_project(name)
        _task_tools._manager = self.tasks

    def _make_memory_search_tool(self):
        """Build a memory_search Tool that searches recent_memory for relevant past context."""
        from tools.registry import Tool, ToolSchema
        recent_memory = self.memory.recent_memory

        def _search(
            query: str = "",
            top_k: int = 5,
            start_date: str = "",
            end_date: str = "",
        ) -> str:
            results = recent_memory.search(
                query,
                top_k=top_k,
                min_score=0.0,
                start_date=_resolve_date_str(start_date) or None,
                end_date=_resolve_date_str(end_date) or None,
            )
            if not results:
                return "No relevant memory found."
            return "\n\n---\n\n".join(results)

        return Tool(
            schema=ToolSchema(
                name="memory_search",
                description=(
                    "Search compressed summaries of past conversation sessions for relevant context. "
                    "ALWAYS call this before saying something is unknown, undecided, or not recorded — "
                    "the information may exist in a previous session even if it is not in the current context. "
                    "Use key terms from the user's question as the query. "
                    "start_date/end_date accept YYYY-MM-DD or natural language (昨天, 上周六, last Saturday…). "
                    "If query is empty and date range is set, returns all sessions in that range by recency.\n"
                    "搜索过去对话的压缩摘要，获取相关上下文。"
                    "在说某事未知、未决定或未记录之前，必须先调用此工具。"
                    "start_date/end_date 接受 YYYY-MM-DD 或自然语言（昨天、上周六等）。"
                ),
                parameters={
                    "type": "object",
                    "properties": {
                        "query": {
                            "type": "string",
                            "description": "Key terms to search for. Can be empty if filtering by date range only.",
                            "default": "",
                        },
                        "top_k": {
                            "type": "integer",
                            "description": "Max results to return (default 5)",
                            "default": 5,
                        },
                        "start_date": {
                            "type": "string",
                            "description": "Filter sessions on or after this date. YYYY-MM-DD or natural language (昨天, 上周六, last Saturday…).",
                            "default": "",
                        },
                        "end_date": {
                            "type": "string",
                            "description": "Filter sessions on or before this date. YYYY-MM-DD or natural language.",
                            "default": "",
                        },
                    },
                    "required": [],
                },
            ),
            fn=_search,
        )

    def _make_project_query_tool(self):
        """Build a project_query Tool that reads structured project_memory entries directly."""
        from tools.registry import Tool, ToolSchema

        brain = self  # capture for closure

        def _query(keyword: str = "", include_history: bool = False) -> str:
            pm = brain.project_memory
            if pm is None:
                return "No project memory available for this project."
            entries = pm.get_all()
            if not entries:
                return "Project memory is empty."
            kw = keyword.strip().lower()
            if kw:
                entries = [
                    e for e in entries
                    if kw in e.get("key", "").lower() or kw in e.get("value", "").lower()
                ]
            if not entries:
                return f"No project memory entries matching '{keyword}'."
            lines = []
            for e in entries:
                lines.append(f"[{e.get('dimension', '?')}] {e['key']}: {e['value']}")
            if include_history:
                hist = pm.get_history(key=keyword.strip() if keyword.strip() else None)
                if hist:
                    lines.append("\n[History — previous values, newest first]")
                    for h in hist:
                        from datetime import datetime
                        dt = datetime.fromtimestamp(h["archived_at"]).strftime("%Y-%m-%d")
                        lines.append(f"  {dt}  [{h['key']}]: {h['value']}")
            return "\n".join(lines)

        return Tool(
            schema=ToolSchema(
                name="project_query",
                description=(
                    "Read structured project memory — decisions, architecture choices, conventions, "
                    "and progress tracked for this project. "
                    "Use this for questions about current state, decisions made, or project conventions. "
                    "Prefer this over memory_search for questions about decisions, tech stack, or architecture. "
                    "Set include_history=true to see previous values for a key (useful for 'what changed' questions).\n"
                    "读取结构化的项目记忆——本项目的决策、架构选择、约定和进展。"
                    "对于决策、技术栈、架构等问题，优先调用此工具，而非 memory_search。"
                    "include_history=true 可查看某个条目的历史变更记录（适用于【之前是什么/改了什么】类问题）。"
                ),
                parameters={
                    "type": "object",
                    "properties": {
                        "keyword": {
                            "type": "string",
                            "description": (
                                "Optional keyword to filter entries (case-insensitive substring match on key and value). "
                                "Leave empty to return all project memory entries."
                            ),
                        },
                        "include_history": {
                            "type": "boolean",
                            "description": "If true, append the history of previous values (newest first). Use for 'what changed' or 'what was it before' questions.",
                        },
                    },
                    "required": [],
                },
            ),
            fn=_query,
        )

    def _make_activity_log_tool(self):
        """Build an activity_log_query Tool that returns per-turn activity records by date."""
        from tools.registry import Tool, ToolSchema
        activity_log = self.memory.activity_log

        def _query(date: str = "", start_date: str = "", end_date: str = "") -> str:
            # Resolve natural language dates internally
            date = _resolve_date_str(date)
            start_date = _resolve_date_str(start_date)
            end_date = _resolve_date_str(end_date)
            # Single date → query that exact day
            sd = start_date or date or ""
            ed = end_date or date or ""
            entries = activity_log.query(sd or None, ed or None)
            label = date or (f"{sd} – {ed}" if (sd or ed) else "今天")
            if not entries:
                return f"No activity recorded for {label}."
            lines = [f"Activity for {label}:"]
            cur_date = None
            for e in entries:
                if e["date"] != cur_date:
                    cur_date = e["date"]
                    lines.append(f"\n[{cur_date}]")
                asst = e["assistant_preview"]
                asst_line = f"  → {asst}" if asst else ""
                lines.append(f"  {e['time']}  {e['user_msg']}{asst_line}")
            return "\n".join(lines).strip()

        return Tool(
            schema=ToolSchema(
                name="activity_log_query",
                description=(
                    "Query the exact per-turn activity log for a specific date or date range. "
                    "THIS IS THE ONLY CORRECT SOURCE for 'what did we do today/on date X' questions. "
                    "It returns the actual user messages and assistant replies recorded in real time — not summaries or inferences. "
                    "If it returns no entries, report that directly. Do NOT supplement with memory_search or project_query. "
                    "Accepts YYYY-MM-DD or natural language: '今天', '昨天', '上周六', 'last Saturday', etc. "
                    "Pass a single date to 'date' for one day, or use start_date+end_date for a range.\n"
                    "查询精确的每轮活动记录，是回答「今天/某日做了什么」的唯一正确来源。"
                    "接受 YYYY-MM-DD 或自然语言日期：今天、昨天、上周六等。"
                    "若无记录，直接报告，不得用 memory_search 或 project_query 补充。"
                ),
                parameters={
                    "type": "object",
                    "properties": {
                        "date": {
                            "type": "string",
                            "description": "Exact day to query. YYYY-MM-DD or natural language (今天, 昨天, 上周六, last Saturday…). Defaults to today.",
                            "default": "",
                        },
                        "start_date": {
                            "type": "string",
                            "description": "Range start (inclusive). YYYY-MM-DD or natural language.",
                            "default": "",
                        },
                        "end_date": {
                            "type": "string",
                            "description": "Range end (inclusive). YYYY-MM-DD or natural language.",
                            "default": "",
                        },
                    },
                    "required": [],
                },
            ),
            fn=_query,
        )

    def _project_context_fn(self) -> str:
        """Inject project memory + open tasks as a single context block."""
        parts = []
        if self.project_memory:
            s = self.project_memory.to_context_string()
            if s:
                parts.append(s)
        if hasattr(self, "tasks"):
            open_tasks = self.tasks.open_tasks()
            if open_tasks:
                lines = ["[Open Tasks]"]
                for t in open_tasks:
                    desc = f" — {t['description']}" if t.get("description") else ""
                    lines.append(f"  #{t['id']} {t['title']}{desc}")
                parts.append("\n".join(lines))
        return "\n\n".join(parts)

    def _make_project_memory(self, cfg: "ContextConfig", api_key: str, project_memory_path: str):
        """Instantiate a CoreMemory for project-scoped knowledge."""
        import json as _json
        from chatmem.memory.core_memory import CoreMemory
        from chatmem.config import DimensionConfig

        try:
            with open(project_memory_path, encoding="utf-8") as f:
                pm_data = _json.load(f)
            dims = {
                k: DimensionConfig(label=v["label"], stability=float(v["stability"]))
                for k, v in pm_data.get("dimensions", {}).items()
            }
        except Exception:
            dims = {}
        if not dims:
            return None

        compress_model = cfg.llm.compress_model or cfg.llm.model
        _STRIP_KEYS = {"reasoning_split", "reasoning_effort"}
        extra_body = (
            {k: v for k, v in cfg.llm.extra_body.items() if k not in _STRIP_KEYS}
            if cfg.llm.extra_body else None
        ) or None
        provider = getattr(cfg.llm, "provider", "openai") or "openai"

        pm = CoreMemory(
            db_path=self.projects.project_db_path,
            api_key=api_key,
            model=compress_model,
            base_url=cfg.llm.base_url,
            dimensions=dims,
            extra_body=extra_body,
            provider=provider,
            context_label="Project Memory",
            enable_history=True,
        )

        # Override judge prompts with project-specific framing
        pm._judge_prompt_en = _build_project_judge_prompt(dims)
        pm._judge_prompt_zh = _build_project_judge_prompt_zh(dims)
        return pm

    def _reinit_memory(self):
        if getattr(self, "memory", None) is not None:
            self.memory.close()
        cfg = ContextConfig.from_json(self._config_path) if self._config_path else ContextConfig()
        api_key = cfg.llm.resolve_api_key()
        self.project_memory = self._make_project_memory(cfg, api_key, _PROJECT_MEMORY_JSON)
        self.memory = ContextManager.create(
            config=cfg,
            api_key=api_key,
            db_path=self.projects.project_db_path,
            core_db_path=self.projects.core_db_path,
            extra_context_fn=self._project_context_fn,
            on_compress_fn=(
                self._run_project_judge if self.project_memory else None
            ),
            auto_recall=False,
        )
        self.registry.register(self._make_memory_search_tool())
        self.registry.register(self._make_project_query_tool())
        self.registry.register(self._make_activity_log_tool())

    def _save_agent_cfg(self):
        """Persist current _agent_cfg to agent.json."""
        import json as _json
        with open(self._agent_cfg_path, "w", encoding="utf-8") as f:
            _json.dump(self._agent_cfg, f, indent=2, ensure_ascii=False)
            f.write("\n")

    # ------------------------------------------------------------------
    # Session lifecycle
    # ------------------------------------------------------------------

    def _run_project_judge(self, text: str, allow_task_ops: bool = False):
        if not self.project_memory:
            return
        import json as _json
        import logging as _logging
        from control.chatmem.compressor import _is_chinese, _llm_complete
        logger = _logging.getLogger("chatmem")
        try:
            # Build prompt and call LLM directly so we can parse both sections
            pm = self.project_memory
            judge_prompt = pm._judge_prompt_zh if _is_chinese(text) else pm._judge_prompt_en
            existing = pm.get_all()
            existing_str = (
                "\n".join(f"- {e['key']} (stability={e['stability']:.0f}): {e['value']}"
                          for e in existing)
                if existing else "(empty)"
            )
            prompt = judge_prompt.replace("{existing}", existing_str).replace("{text}", text)
            raw = _llm_complete(
                [{"role": "user", "content": prompt}],
                pm.api_key, pm.model, pm.base_url, pm.extra_body, pm.provider,
            )

            # Parse outer object; fall back to treating raw as a plain memory array
            parsed = None
            m = __import__("re").search(r"\{.*\}", raw, __import__("re").DOTALL)
            if m:
                try:
                    parsed = _json.loads(m.group())
                except Exception:
                    pass
            memory_entries = []
            task_ops = []
            if isinstance(parsed, dict):
                memory_entries = parsed.get("memory") or []
                task_ops = parsed.get("task_ops") or []
            elif isinstance(parsed, list):
                memory_entries = parsed  # old format fallback
            else:
                # Try plain array
                arr_m = __import__("re").search(r"\[.*\]", raw, __import__("re").DOTALL)
                if arr_m:
                    try:
                        memory_entries = _json.loads(arr_m.group())
                    except Exception:
                        pass

            # Apply memory updates
            written = []
            for entry in memory_entries:
                if "key" not in entry:
                    continue
                action = entry.get("action", "").lower()
                if action == "delete":
                    pm.delete(entry["key"])
                    written.append({**entry, "action": "delete"})
                    logger.info("[project] judge deleted  key=%r", entry["key"])
                elif "value" in entry:
                    pm.set(entry["key"], entry["value"],
                           dimension=entry.get("dimension", "progress"))
                    written.append(entry)
                    logger.info("[project] judge wrote  key=%r  dim=%s  value=%r",
                                entry["key"], entry.get("dimension"), entry["value"][:60])
            if not written:
                logger.info("[project] judge: no memory changes")

            # Apply task_ops — only when processing the current (just-ended) session,
            # not when replaying historical backlog (allow_task_ops=False by default).
            if allow_task_ops and task_ops and hasattr(self, "tasks"):
                for op in task_ops:
                    if not isinstance(op, dict):
                        continue
                    kind = op.get("op", "")
                    if kind == "add":
                        t = self.tasks.add(op.get("title", ""), op.get("description", ""))
                        logger.info("[tasks] judge added  #%d  %r", t["id"], t["title"])
                    elif kind == "done" and op.get("id"):
                        self.tasks.done(int(op["id"]))
                        logger.info("[tasks] judge done  #%s", op["id"])
                    elif kind == "cancel" and op.get("id"):
                        self.tasks.cancel(int(op["id"]))
                        logger.info("[tasks] judge cancel  #%s", op["id"])

        except Exception as exc:
            logger.warning("[project] judge error: %s", exc)

    def end_session(self):
        """Save pending session to DB and exit. All LLM work deferred to next startup."""
        self.memory.end_session()

    _JUDGE_CHUNK_TURNS = 30          # core judge chunk size
    _PENDING_TIMEOUT_SECS = 120  # max wall-clock seconds to wait for background sync threads

    @staticmethod
    def _chunk_verbatim(text: str, chunk_turns: int) -> list[str]:
        """Split verbatim text into chunks of ~chunk_turns user/assistant pairs."""
        lines = text.splitlines()
        chunks, current = [], []
        user_count = 0
        for line in lines:
            current.append(line)
            if line.startswith("user:"):
                user_count += 1
                if user_count >= chunk_turns:
                    chunks.append("\n".join(current))
                    current, user_count = [], 0
        if current:
            chunks.append("\n".join(current))
        return chunks

    def process_pending_sessions(self) -> int:
        """
        Process any pending sessions from previous exits in background threads.
        Returns the count immediately so the caller can show a message without blocking.

        Compression: runs on full verbatim text (preserves narrative coherence).
        Judge: runs on 30-turn chunks (reduces signal dilution for low-frequency facts).
        """
        import json as _json
        pending = self.memory.load_pending_sessions()
        if not pending:
            return 0

        def _process_one(p: dict):
            verbatim_text = p["verbatim_text"]
            summary_blocks: list[str] = _json.loads(p["summary_json"]) if p["summary_json"] else []
            turn_count = p["turn_count"]

            _compressed: list[str | None] = [None]
            verbatim_turns = verbatim_text.count("\nuser:") + (
                1 if verbatim_text.startswith("user:") else 0
            )
            threads: list[threading.Thread] = []

            # Compression: full text → recent_memory
            if verbatim_text:
                if verbatim_turns >= self.memory._MIN_TURNS_TO_COMPRESS:
                    def _compress(vt=verbatim_text, _mode=p.get("compression_mode", self.memory.mode)):
                        try:
                            _compressed[0] = self.memory.compressor.compress_for_session_context(vt, mode=_mode)
                        except Exception as _e:
                            import logging as _logging
                            _logging.getLogger("chatmem").warning("[compress] failed, keeping verbatim: %s", _e)
                            _compressed[0] = vt
                    t = threading.Thread(target=_compress, daemon=True)
                else:
                    def _passthrough(vt=verbatim_text):
                        _compressed[0] = vt
                    t = threading.Thread(target=_passthrough, daemon=True)
                threads.append(t)
                t.start()

            # Core memory judge: chunked to improve extraction of low-frequency facts
            if verbatim_text:
                chunks = self._chunk_verbatim(verbatim_text, self._JUDGE_CHUNK_TURNS)
                for chunk in chunks:
                    t = threading.Thread(
                        target=self.memory._run_judge, args=(chunk,), daemon=True
                    )
                    threads.append(t)
                    t.start()

            # Project judge: chunked sequentially (existing memory updated between chunks)
            if verbatim_text:
                t = threading.Thread(
                    target=self._run_project_judge,
                    args=(verbatim_text,),
                    kwargs={"allow_task_ops": p.get("task_ops", False)},
                    daemon=True,
                )
                threads.append(t)
                t.start()

            for t in threads:
                t.join(timeout=self._PENDING_TIMEOUT_SECS)

            import logging as _logging
            _logger = _logging.getLogger("chatmem")

            # Fallback: if compression returned empty, save truncated verbatim to avoid data loss
            if verbatim_text and not _compressed[0]:
                _logger.warning(
                    "[session] compress returned empty, falling back to verbatim (turns=%d)", verbatim_turns
                )
                _compressed[0] = verbatim_text[:3000] + ("\n…[truncated]" if len(verbatim_text) > 3000 else "")

            blocks = summary_blocks[:]
            if _compressed[0]:
                blocks.append(_compressed[0])
            if blocks:
                self.memory.recent_memory.add(
                    turn_id=turn_count,
                    compressed_content="\n\n".join(blocks),
                )
                _logger.info("[session] saved to recent_memory  turns=%d  len=%d", turn_count, sum(len(b) for b in blocks))
            else:
                _logger.warning("[session] nothing to save to recent_memory  turns=%d", turn_count)
            self.memory.delete_pending_session(p["id"])

        for p in pending:
            threading.Thread(target=_process_one, args=(p,), daemon=True).start()

        return len(pending)
