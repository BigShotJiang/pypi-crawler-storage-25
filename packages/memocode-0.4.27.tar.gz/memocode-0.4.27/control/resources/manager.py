"""
ResourceManager: coordinates DB, scanner, and LLM re-classification.
Instantiated by Brain; tools call into it.
"""
import logging
import os
import re

from . import db as _db
from .scanner import check_status, compute_hash, compute_mtime, read_file_summary

logger = logging.getLogger("chatmem")


class ResourceManager:
    def __init__(
        self,
        api_key: str = "",
        model: str = "",
        base_url: str | None = None,
        extra_body: dict | None = None,
        provider: str = "openai",
        db_path: str | None = None,
    ):
        self._api_key = api_key
        self._model = model
        self._base_url = base_url
        self._extra_body = extra_body
        self._provider = provider
        self._db_path = db_path or os.path.expanduser("~/.mcode/resources/index.db")
        self._pending: list[dict] = []         # staged register proposals awaiting resource_confirm
        self._pending_delete: list[dict] = []  # staged delete proposals awaiting resource_confirm
        _db.init_db(self._db_path)

    # ── Public API (called by tools) ───────────────────────────────────────────

    def scan_file(self, path: str) -> str:
        """Read file content for LLM classification. Returns summary text."""
        path = os.path.expanduser(os.path.normpath(path))
        if not os.path.isfile(path):
            raise FileNotFoundError(f"File not found: {path}")
        return read_file_summary(path)

    def register(
        self,
        path: str,
        name: str,
        description: str,
        tags: list[str],
        scope: str,
    ) -> dict:
        """Write a resource entry to the DB. Returns the registered record."""
        path = os.path.expanduser(os.path.normpath(path))
        if not os.path.isfile(path):
            raise FileNotFoundError(f"File not found: {path}")
        fhash = compute_hash(path)
        fmtime = compute_mtime(path)
        _db.upsert(path, name, description, tags, scope, fhash, fmtime, self._db_path)
        return {"path": path, "name": name, "scope": scope, "tags": tags}

    def find(self, query: str) -> list[dict]:
        """Search resources by keyword."""
        results = _db.search(query, self._db_path)
        for r in results:
            _db.record_use(r["path"], self._db_path)
        return results

    def list_all(self, scope: str | None = None) -> list[dict]:
        if scope:
            return _db.get_by_scope(scope, self._db_path)
        return _db.get_all(self._db_path)

    def delete(self, path: str) -> None:
        path = os.path.expanduser(os.path.normpath(path))
        _db.delete(path, self._db_path)

    def classify_dir(self, directory: str, recursive: bool = False) -> tuple[list[dict], list[str]]:
        """
        Scan directory, classify each new file with internal LLM, store in _pending.
        Returns (proposals, already_registered_paths).
        """
        import json as _json
        from .scanner import _SCANNABLE_EXTS  # reuse constant

        directory = os.path.expanduser(os.path.normpath(directory))
        registered = {r["path"] for r in _db.get_all(self._db_path)}

        files = []
        if recursive:
            for root, _, fnames in os.walk(directory):
                for fname in sorted(fnames):
                    if not fname.startswith("."):
                        files.append(os.path.join(root, fname))
        else:
            files = [
                os.path.join(directory, f)
                for f in sorted(os.listdir(directory))
                if os.path.isfile(os.path.join(directory, f)) and not f.startswith(".")
            ]

        files = [f for f in files if os.path.splitext(f)[1].lower() in _SCANNABLE_EXTS]
        already = [f for f in files if f in registered]
        new_files = [f for f in files if f not in registered]

        proposals = []
        for path in new_files:
            summary = read_file_summary(path)
            classification = self._classify_file(path, summary)
            proposals.append({"path": path, **classification})

        self._pending = proposals
        return proposals, already

    def stage_delete(self, query: str) -> list[dict]:
        """Search for resources matching query and stage them for deletion.
        Pass query='*' or 'all' to stage every registered resource."""
        if query.strip().lower() in ("*", "all", ""):
            results = _db.get_all(self._db_path)
        else:
            results = _db.search(query, self._db_path)
        self._pending_delete = list(results)
        return results

    def commit_pending(self) -> dict:
        """
        Commit all staged operations (register + delete) and clear staging areas.
        Returns {"registered": [...], "deleted": [...]}.
        """
        registered = []
        for item in self._pending:
            try:
                rec = self.register(
                    path=item["path"],
                    name=item["name"],
                    description=item["description"],
                    tags=item.get("tags", []),
                    scope=item.get("scope", "public"),
                )
                registered.append(rec)
            except Exception as e:
                logger.warning("[resources] commit failed for %s: %s", item.get("path"), e)
        self._pending = []

        deleted = []
        for item in self._pending_delete:
            try:
                _db.delete(item["path"], self._db_path)
                deleted.append(item)
            except Exception as e:
                logger.warning("[resources] delete failed for %s: %s", item.get("path"), e)
        self._pending_delete = []

        return {"registered": registered, "deleted": deleted}

    def _classify_file(self, path: str, content_summary: str) -> dict:
        """Ask internal LLM to classify a single file. Returns dict with name/description/tags/scope."""
        import json as _json
        default = {
            "name": os.path.basename(path),
            "description": "",
            "tags": [],
            "scope": "public",
        }
        if not self._api_key or not self._model:
            return default
        prompt = (
            f"File: {os.path.basename(path)}\n"
            f"Content excerpt:\n{content_summary}\n\n"
            "Classify this file for a personal knowledge resource registry.\n"
            "Reply with JSON only, no other text:\n"
            '{"name": "short display name", '
            '"description": "what this file contains and what tasks it helps with (1-2 sentences)", '
            '"tags": ["tag1", "tag2", "tag3"], '
            '"scope": "public"}\n\n'
            'scope: use "public" if this file has cross-project general value '
            "(contacts, price lists, templates, policies). "
            "Otherwise use the project name it belongs to."
        )
        try:
            raw = self._llm(prompt)
            m = re.search(r"\{.*\}", raw, re.DOTALL)
            if m:
                data = _json.loads(m.group())
                return {
                    "name": data.get("name", default["name"]),
                    "description": data.get("description", ""),
                    "tags": data.get("tags", []),
                    "scope": data.get("scope", "public"),
                }
        except Exception as e:
            logger.warning("[resources] classify failed for %s: %s", path, e)
        return default

    # ── Sync (called at startup in background thread) ─────────────────────────

    def sync(self) -> dict:
        """
        Check all registered files for changes or deletion.
        Deleted → remove from DB.
        Modified → re-read content, LLM updates description/tags.
        Returns summary counts.
        """
        records = _db.get_all(self._db_path)
        removed = updated = 0

        for rec in records:
            path = rec["path"]
            status = check_status(path, rec["file_hash"], rec["file_mtime"])

            if status == "deleted":
                _db.delete(path, self._db_path)
                removed += 1
                logger.info("[resources] removed (file deleted): %s", path)

            elif status == "modified":
                try:
                    summary = read_file_summary(path)
                    description, tags = self._reclassify(
                        path, summary, rec["description"], rec["tags"]
                    )
                    _db.update_content(
                        path, description, tags,
                        compute_hash(path), compute_mtime(path),
                        self._db_path,
                    )
                    updated += 1
                    logger.info("[resources] updated (content changed): %s", path)
                except Exception as e:
                    logger.warning("[resources] sync error for %s: %s", path, e)

        return {"checked": len(records), "removed": removed, "updated": updated}

    # ── LLM re-classification ─────────────────────────────────────────────────

    def _reclassify(
        self, path: str, content_summary: str,
        old_description: str, old_tags: list[str],
    ) -> tuple[str, list[str]]:
        """
        Ask LLM to update description and tags based on new file content.
        Returns (description, tags).
        Falls back to old values on any error.
        """
        if not self._api_key or not self._model:
            return old_description, old_tags

        prompt = (
            f"File: {os.path.basename(path)}\n"
            f"Previous description: {old_description}\n"
            f"Previous tags: {old_tags}\n\n"
            f"New file content (excerpt):\n{content_summary}\n\n"
            "The file content has changed. Update the description and tags to reflect "
            "the current content.\n"
            "Reply in this exact format (JSON, no other text):\n"
            '{"description": "...", "tags": ["tag1", "tag2", ...]}'
        )
        try:
            raw = self._llm(prompt)
            import json
            m = re.search(r"\{.*\}", raw, re.DOTALL)
            if m:
                data = json.loads(m.group())
                return data.get("description", old_description), data.get("tags", old_tags)
        except Exception:
            pass
        return old_description, old_tags

    def _llm(self, user_content: str) -> str:
        import re as _re
        messages = [{"role": "user", "content": user_content}]
        if self._provider == "anthropic":
            import anthropic
            client = anthropic.Anthropic(api_key=self._api_key, base_url=self._base_url)
            response = client.messages.create(
                model=self._model, max_tokens=512, messages=messages
            )
            raw = "".join(b.text for b in response.content if b.type == "text")
        else:
            from openai import OpenAI
            client = OpenAI(api_key=self._api_key, base_url=self._base_url)
            kwargs = dict(model=self._model, messages=messages)
            if self._extra_body:
                kwargs["extra_body"] = self._extra_body
            response = client.chat.completions.create(**kwargs)
            raw = response.choices[0].message.content or ""
        return _re.sub(r"<think>.*?</think>", "", raw, flags=_re.DOTALL).strip()
