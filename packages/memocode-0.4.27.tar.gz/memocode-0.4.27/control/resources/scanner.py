"""
File change detection and content extraction for the resource registry.
"""
import hashlib
import os

_SCANNABLE_EXTS = {
    ".xlsx", ".xls", ".csv",
    ".pdf",
    ".txt", ".md", ".rst",
    ".json", ".yaml", ".yml",
    ".docx", ".doc",
}

# ── Hash / mtime ───────────────────────────────────────────────────────────────

def compute_hash(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def compute_mtime(path: str) -> float:
    return os.path.getmtime(path)


def check_status(path: str, stored_hash: str, stored_mtime: float) -> str:
    """
    Returns: 'unchanged' | 'modified' | 'deleted'
    Uses mtime as fast pre-check; only computes hash if mtime changed.
    """
    if not os.path.isfile(path):
        return "deleted"
    current_mtime = os.path.getmtime(path)
    if current_mtime == stored_mtime:
        return "unchanged"
    if compute_hash(path) == stored_hash:
        return "unchanged"  # content same despite touch
    return "modified"


# ── Content extraction ─────────────────────────────────────────────────────────

def read_file_summary(path: str, max_chars: int = 4000) -> str:
    """
    Read file content for LLM classification.
    Returns a truncated plain-text summary appropriate for the file type.
    """
    ext = os.path.splitext(path)[1].lower()

    if ext == ".pdf":
        return _read_pdf(path, max_chars)
    if ext in (".xlsx", ".xls"):
        return _read_excel(path, max_chars)
    # plain text (csv, txt, md, json, etc.)
    return _read_text(path, max_chars)


def _read_text(path: str, max_chars: int) -> str:
    try:
        with open(path, encoding="utf-8", errors="replace") as f:
            content = f.read(max_chars)
        return content + ("..." if os.path.getsize(path) > max_chars else "")
    except OSError as e:
        return f"[read error: {e}]"


def _read_pdf(path: str, max_chars: int) -> str:
    try:
        import pdfplumber
        parts = []
        with pdfplumber.open(path) as pdf:
            total = len(pdf.pages)
            parts.append(f"[PDF, {total} pages]")
            for page in pdf.pages[:5]:
                text = (page.extract_text() or "").strip()
                if text:
                    parts.append(text)
                if sum(len(p) for p in parts) >= max_chars:
                    break
        result = "\n".join(parts)
        return result[:max_chars] + ("..." if len(result) > max_chars else "")
    except ImportError:
        return "[pdfplumber not installed — install with: pip install pdfplumber]"
    except Exception as e:
        return f"[PDF read error: {e}]"


def _read_excel(path: str, max_chars: int) -> str:
    try:
        import openpyxl
        wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
        parts = []
        for sheet_name in wb.sheetnames:
            ws = wb[sheet_name]
            parts.append(f"[Sheet: {sheet_name}]")
            row_count = 0
            for row in ws.iter_rows(values_only=True):
                cells = [str(c) if c is not None else "" for c in row]
                if any(c.strip() for c in cells):
                    parts.append("\t".join(cells))
                    row_count += 1
                if row_count >= 30 or sum(len(p) for p in parts) >= max_chars:
                    break
            if sum(len(p) for p in parts) >= max_chars:
                break
        wb.close()
        result = "\n".join(parts)
        return result[:max_chars] + ("..." if len(result) > max_chars else "")
    except ImportError:
        return "[openpyxl not installed — install with: pip install openpyxl]"
    except Exception as e:
        return f"[Excel read error: {e}]"
