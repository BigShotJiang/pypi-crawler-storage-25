"""
Resource registry — SQLite storage layer.
Stores metadata about local files so the LLM can find them by topic/task.
"""
import json
import os
import sqlite3
from contextlib import contextmanager

_DEFAULT_DB = os.path.expanduser("~/.mcode/resources/index.db")


def init_db(db_path: str = _DEFAULT_DB) -> None:
    os.makedirs(os.path.dirname(db_path), exist_ok=True)
    with _conn(db_path) as cx:
        cx.execute("""
            CREATE TABLE IF NOT EXISTS resources (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                name        TEXT NOT NULL,
                path        TEXT NOT NULL UNIQUE,
                description TEXT DEFAULT '',
                tags        TEXT DEFAULT '[]',
                scope       TEXT DEFAULT 'public',
                file_hash   TEXT DEFAULT '',
                file_mtime  REAL DEFAULT 0,
                created_at  TEXT DEFAULT (datetime('now')),
                updated_at  TEXT DEFAULT (datetime('now')),
                use_count   INTEGER DEFAULT 0,
                last_used   TEXT
            )
        """)


@contextmanager
def _conn(db_path: str):
    con = sqlite3.connect(db_path)
    con.row_factory = sqlite3.Row
    try:
        yield con
        con.commit()
    finally:
        con.close()


def _row_to_dict(row: sqlite3.Row) -> dict:
    d = dict(row)
    d["tags"] = json.loads(d.get("tags") or "[]")
    return d


# ── Write ──────────────────────────────────────────────────────────────────────

def upsert(
    path: str,
    name: str,
    description: str,
    tags: list[str],
    scope: str,
    file_hash: str,
    file_mtime: float,
    db_path: str = _DEFAULT_DB,
) -> None:
    with _conn(db_path) as cx:
        cx.execute("""
            INSERT INTO resources (name, path, description, tags, scope, file_hash, file_mtime)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(path) DO UPDATE SET
                name        = excluded.name,
                description = excluded.description,
                tags        = excluded.tags,
                scope       = excluded.scope,
                file_hash   = excluded.file_hash,
                file_mtime  = excluded.file_mtime,
                updated_at  = datetime('now')
        """, (name, path, description, json.dumps(tags, ensure_ascii=False),
              scope, file_hash, file_mtime))


def update_content(
    path: str,
    description: str,
    tags: list[str],
    file_hash: str,
    file_mtime: float,
    db_path: str = _DEFAULT_DB,
) -> None:
    """Update description/tags after file content changed."""
    with _conn(db_path) as cx:
        cx.execute("""
            UPDATE resources
            SET description = ?, tags = ?, file_hash = ?, file_mtime = ?,
                updated_at = datetime('now')
            WHERE path = ?
        """, (description, json.dumps(tags, ensure_ascii=False), file_hash, file_mtime, path))


def delete(path: str, db_path: str = _DEFAULT_DB) -> None:
    with _conn(db_path) as cx:
        cx.execute("DELETE FROM resources WHERE path = ?", (path,))


def record_use(path: str, db_path: str = _DEFAULT_DB) -> None:
    with _conn(db_path) as cx:
        cx.execute("""
            UPDATE resources
            SET use_count = use_count + 1, last_used = datetime('now')
            WHERE path = ?
        """, (path,))


# ── Read ───────────────────────────────────────────────────────────────────────

def get_all(db_path: str = _DEFAULT_DB) -> list[dict]:
    with _conn(db_path) as cx:
        rows = cx.execute(
            "SELECT * FROM resources ORDER BY scope, name"
        ).fetchall()
    return [_row_to_dict(r) for r in rows]


def get_by_scope(scope: str, db_path: str = _DEFAULT_DB) -> list[dict]:
    with _conn(db_path) as cx:
        rows = cx.execute(
            "SELECT * FROM resources WHERE scope = ? ORDER BY name", (scope,)
        ).fetchall()
    return [_row_to_dict(r) for r in rows]


def search(query: str, db_path: str = _DEFAULT_DB) -> list[dict]:
    """
    Simple keyword search across name, description, tags.
    Returns results sorted by relevance (match count desc) then use_count desc.
    """
    terms = [t.strip().lower() for t in query.split() if t.strip()]
    if not terms:
        return get_all(db_path)

    with _conn(db_path) as cx:
        rows = cx.execute(
            "SELECT * FROM resources ORDER BY use_count DESC"
        ).fetchall()

    results = []
    for row in rows:
        d = _row_to_dict(row)
        import os as _os
        haystack = " ".join([
            d["name"],
            _os.path.basename(d["path"]),           # also match on filename
            _os.path.splitext(_os.path.basename(d["path"]))[0],  # stem without ext
            d["description"],
            " ".join(d["tags"]),
            d["scope"],
        ]).lower()
        score = sum(1 for t in terms if t in haystack)
        if score > 0:
            results.append((score, d))

    results.sort(key=lambda x: (-x[0], -x[1]["use_count"]))
    return [d for _, d in results]
