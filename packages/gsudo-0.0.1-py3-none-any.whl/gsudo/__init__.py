"""
gsudo - PyPI alias for the zhmiscellanygsudo package.

All functionality lives in zhmiscellanygsudo. This package is a thin
re-export so users can `pip install gsudo` and `import gsudo`.

Both names resolve to the same code; updates land in zhmiscellanygsudo.
"""
import sys as _sys

import zhmiscellanygsudo as _zhg
from zhmiscellanygsudo import rerun_as_admin, is_admin, admin_subprocess

# Expose `gsudo.admin_subprocess` as the same module object so
# `from gsudo import admin_subprocess` and `gsudo.admin_subprocess.Popen`
# both work without surprises.
_sys.modules[__name__ + ".admin_subprocess"] = admin_subprocess

__all__ = ["rerun_as_admin", "is_admin", "admin_subprocess"]
__version__ = getattr(_zhg, "__version__", None)
