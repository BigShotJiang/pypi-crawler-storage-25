"""
Print outcome recorder — stores print results to improve future strategies (v0.6).

Each print produces a feedback record:
  model_hash, support_config, quality_score, defects, printer, material, user_rating

The feedback database grows over time and feeds into the optimizer to
replace hardcoded angle thresholds with learned parameters.
"""
from __future__ import annotations

import json
import hashlib
import os
import time
from pathlib import Path
from dataclasses import dataclass, field, asdict
from typing import Dict, List, Optional, Any


# ─── Default storage path ──────────────────────────────────────

DEFAULT_DATA_DIR = os.path.expanduser("~/.supportsage/learning")
FEEDBACK_FILE = "feedback.json"
MODEL_CACHE_FILE = "model_cache.json"


# ─── Data Structures ────────────────────────────────────────────

@dataclass
class SupportConfig:
    """The support configuration used for a print."""
    angle_threshold: float = 45.0
    strategy: str = "balanced"       # light, balanced, heavy
    support_type: str = "tree"       # tree, pillar
    branch_radius: float = 1.0       # mm — base branch radius multiplier
    merge_distance: float = 5.0      # mm — branch merge threshold
    interface_thickness: float = 0.3 # mm
    density_mult: float = 1.0        # overall density multiplier


@dataclass
class PrintFeedback:
    """A single print outcome record."""
    model_hash: str                  # SHA256 of STL geometry summary
    model_name: str                  # original filename
    support_config: SupportConfig
    quality_score: float             # 0-100 from Printsight or user
    defects: Dict[str, float] = field(default_factory=dict)
    printer: str = "unknown"
    material: str = "PLA"
    user_rating: int = 0             # 1-5 stars, 0 = not rated
    timestamp: float = field(default_factory=time.time)
    duration_min: float = 0.0        # print time in minutes
    notes: str = ""


@dataclass
class FeedbackDB:
    """Collection of print feedback records with query methods."""
    records: List[PrintFeedback] = field(default_factory=list)
    _by_hash: Dict[str, List[PrintFeedback]] = field(default_factory=dict)

    def add(self, record: PrintFeedback):
        self.records.append(record)
        h = record.model_hash
        if h not in self._by_hash:
            self._by_hash[h] = []
        self._by_hash[h].append(record)

    def get_by_hash(self, model_hash: str) -> List[PrintFeedback]:
        return self._by_hash.get(model_hash, [])

    def get_by_printer(self, printer: str) -> List[PrintFeedback]:
        return [r for r in self.records if r.printer == printer]

    def get_by_material(self, material: str) -> List[PrintFeedback]:
        return [r for r in self.records if r.material == material]

    def get_recent(self, n: int = 10) -> List[PrintFeedback]:
        return sorted(self.records, key=lambda r: r.timestamp, reverse=True)[:n]

    def avg_quality(self) -> float:
        if not self.records:
            return 0.0
        return sum(r.quality_score for r in self.records) / len(self.records)

    def count(self) -> int:
        return len(self.records)


# ─── Storage ────────────────────────────────────────────────────

def _ensure_dir(path: str):
    Path(path).mkdir(parents=True, exist_ok=True)


def hash_model(mesh_path: str) -> str:
    """
    Compute a stable hash for an STL model based on its geometry signature.

    Uses vertex count + bounding box + surface area for a fast, deterministic
    fingerprint that's robust to file format variations.
    """
    try:
        import trimesh
        mesh = trimesh.load_mesh(mesh_path)
        sig = f"{len(mesh.vertices)}|{mesh.bounds}|{mesh.area:.2f}"
        return hashlib.sha256(sig.encode()).hexdigest()[:16]
    except Exception:
        # Fallback: file hash
        digest = hashlib.sha256()
        with open(mesh_path, "rb") as f:
            for chunk in iter(lambda: f.read(1024 * 1024), b""):
                digest.update(chunk)
        return digest.hexdigest()[:16]


def load_feedback(data_dir: str = DEFAULT_DATA_DIR) -> FeedbackDB:
    """Load feedback database from disk."""
    path = os.path.join(data_dir, FEEDBACK_FILE)
    if not os.path.exists(path):
        return FeedbackDB()

    try:
        with open(path) as f:
            raw = json.load(f)
    except (json.JSONDecodeError, Exception):
        return FeedbackDB()

    db = FeedbackDB()
    for r in raw:
        try:
            sc = SupportConfig(**r.pop("support_config", {}))
            record = PrintFeedback(support_config=sc, **r)
            db.add(record)
        except Exception:
            continue
    return db


def save_feedback(db: FeedbackDB, data_dir: str = DEFAULT_DATA_DIR):
    """Save feedback database to disk."""
    _ensure_dir(data_dir)
    path = os.path.join(data_dir, FEEDBACK_FILE)
    raw = []
    for r in db.records:
        d = asdict(r)
        d["support_config"] = asdict(r.support_config)
        raw.append(d)
    with open(path, "w") as f:
        json.dump(raw, f, indent=2, default=str)


def record_feedback(
    mesh_path: str,
    quality_score: float,
    support_config: Optional[SupportConfig] = None,
    printer: str = "unknown",
    material: str = "PLA",
    user_rating: int = 0,
    defects: Optional[Dict[str, float]] = None,
    duration_min: float = 0.0,
    notes: str = "",
    data_dir: str = DEFAULT_DATA_DIR,
) -> PrintFeedback:
    """Record a print outcome and save to disk.

    This is the main entry point for logging feedback.
    Call after a print completes, with the Printsight quality score.
    """
    db = load_feedback(data_dir)
    model_hash = hash_model(mesh_path)
    quality_score = max(0.0, min(100.0, quality_score))

    record = PrintFeedback(
        model_hash=model_hash,
        model_name=os.path.basename(mesh_path),
        support_config=support_config or SupportConfig(),
        quality_score=quality_score,
        defects=defects or {},
        printer=printer,
        material=material,
        user_rating=user_rating,
        duration_min=duration_min,
        notes=notes,
    )
    db.add(record)
    save_feedback(db, data_dir)
    return record


# ─── Query & Analysis ───────────────────────────────────────────

def best_config_for(
    printer: str = "",
    material: str = "",
    data_dir: str = DEFAULT_DATA_DIR,
) -> Optional[SupportConfig]:
    """
    Find the best-performing support config for a given printer + material combo.

    Returns the config with the highest average quality score.
    """
    db = load_feedback(data_dir)
    candidates = db.records

    if printer:
        candidates = [r for r in candidates if r.printer == printer]
    if material:
        candidates = [r for r in candidates if r.material == material]

    if not candidates:
        return None

    # Group by config signature
    config_scores: Dict[str, List[float]] = {}
    config_map: Dict[str, SupportConfig] = {}

    for r in candidates:
        key = json.dumps(asdict(r.support_config), sort_keys=True)
        if key not in config_scores:
            config_scores[key] = []
            config_map[key] = r.support_config
        config_scores[key].append(r.quality_score)

    # Find best average
    best_key = max(config_scores, key=lambda k: sum(config_scores[k]) / len(config_scores[k]))
    return config_map[best_key]


def print_feedback_summary(data_dir: str = DEFAULT_DATA_DIR) -> str:
    """Format a human-readable feedback summary."""
    db = load_feedback(data_dir)
    lines = []
    lines.append(f"\n  📊 Learning Engine — Print History")
    lines.append(f"  {'=' * 40}")
    lines.append(f"  Total prints: {db.count()}")
    lines.append(f"  Avg quality:  {db.avg_quality():.1f}/100")

    # By material
    materials = {}
    for r in db.records:
        materials.setdefault(r.material, []).append(r.quality_score)
    if materials:
        lines.append(f"\n  🧵 By Material:")
        for mat, scores in sorted(materials.items()):
            avg = sum(scores) / len(scores)
            lines.append(f"     {mat:12s}  {avg:.1f}/100  ({len(scores)} prints)")

    # By printer
    printers = {}
    for r in db.records:
        printers.setdefault(r.printer, []).append(r.quality_score)
    if printers:
        lines.append(f"\n  🖨️  By Printer:")
        for p, scores in sorted(printers.items()):
            avg = sum(scores) / len(scores)
            lines.append(f"     {p:12s}  {avg:.1f}/100  ({len(scores)} prints)")

    # Recent records
    recent = db.get_recent(5)
    if recent:
        lines.append(f"\n  🕐 Recent:")
        for r in recent:
            lines.append(f"     {r.model_name:24s}  {r.quality_score:.0f}/100  {r.printer} / {r.material}")

    lines.append("")
    return "\n".join(lines)
