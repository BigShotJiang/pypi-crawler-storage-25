"""
Printer and material profile management (v0.6).

Each profile stores:
- Calibrated parameters for a specific printer model
- Material-specific settings (temperatures, flow rates)
- Learned support preferences (what works best on this machine)
- Success history: which configs yielded good prints

Profiles improve over time as more feedback is collected.
"""
from __future__ import annotations

import json
import os
import time
from pathlib import Path
from dataclasses import dataclass, field, asdict
from typing import Dict, List, Optional, Tuple


DEFAULT_DATA_DIR = os.path.expanduser("~/.supportsage/learning")
PRINTERS_FILE = "printers.json"
MATERIALS_FILE = "materials.json"


# ─── Data Structures ────────────────────────────────────────────

@dataclass
class PrinterProfile:
    """A printer-specific calibration profile."""
    name: str
    model: str = "unknown"                     # e.g. "Bambu Lab X1C"
    nozzle_diameter: float = 0.4               # mm
    max_volumetric_speed: float = 15.0         # mm³/s
    build_volume: Tuple[float, float, float] = (256, 256, 256)
    preferred_support_type: str = "tree"       # tree, pillar, mixed
    max_bridge_length: float = 15.0            # mm
    fan_cooling: bool = True
    notes: str = ""
    created: float = field(default_factory=time.time)
    updated: float = field(default_factory=time.time)

    calibrated_params: Dict[str, float] = field(default_factory=dict)
    """Learned from feedback: optimal support parameters for this printer."""


@dataclass
class MaterialProfile:
    """Material-specific print settings."""
    name: str                                   # e.g. "eSun PLA+"
    brand: str = ""
    type: str = "PLA"                           # PLA, PETG, ABS, PVA, HIPS, etc.
    nozzle_temp_c: int = 215
    bed_temp_c: int = 60
    fan_speed: int = 100                        # percent
    retraction_distance: float = 0.8            # mm
    retraction_speed: float = 40.0              # mm/s
    shrinkage_pct: float = 0.0                  # material shrinkage
    support_interface_required: bool = False    # does this material need PVA interface?
    notes: str = ""
    created: float = field(default_factory=time.time)


# ─── Storage ────────────────────────────────────────────────────

def _ensure_dir(path: str):
    Path(path).mkdir(parents=True, exist_ok=True)


def load_printers(data_dir: str = DEFAULT_DATA_DIR) -> Dict[str, PrinterProfile]:
    """Load printer profiles from disk."""
    path = os.path.join(data_dir, PRINTERS_FILE)
    if not os.path.exists(path):
        return {}
    try:
        with open(path) as f:
            raw = json.load(f)
    except json.JSONDecodeError:
        return {}
    return {k: PrinterProfile(**v) for k, v in raw.items()}


def save_printers(profiles: Dict[str, PrinterProfile], data_dir: str = DEFAULT_DATA_DIR):
    _ensure_dir(data_dir)
    path = os.path.join(data_dir, PRINTERS_FILE)
    raw = {k: asdict(v) for k, v in profiles.items()}
    with open(path, "w") as f:
        json.dump(raw, f, indent=2, default=str)


def load_materials(data_dir: str = DEFAULT_DATA_DIR) -> Dict[str, MaterialProfile]:
    """Load material profiles from disk."""
    path = os.path.join(data_dir, MATERIALS_FILE)
    if not os.path.exists(path):
        return {}
    try:
        with open(path) as f:
            raw = json.load(f)
    except json.JSONDecodeError:
        return {}
    return {k: MaterialProfile(**v) for k, v in raw.items()}


def save_materials(profiles: Dict[str, MaterialProfile], data_dir: str = DEFAULT_DATA_DIR):
    _ensure_dir(data_dir)
    path = os.path.join(data_dir, MATERIALS_FILE)
    raw = {k: asdict(v) for k, v in profiles.items()}
    with open(path, "w") as f:
        json.dump(raw, f, indent=2, default=str)


# ─── Default Profiles ───────────────────────────────────────────

def get_default_printers() -> Dict[str, PrinterProfile]:
    """Return a set of common printer profiles."""
    return {
        "bambu_x1c": PrinterProfile(
            name="Bambu X1C",
            model="Bambu Lab X1 Carbon",
            nozzle_diameter=0.4,
            max_volumetric_speed=32.0,
            build_volume=(256, 256, 256),
            max_bridge_length=20.0,
        ),
        "bambu_p1s": PrinterProfile(
            name="Bambu P1S",
            model="Bambu Lab P1S",
            nozzle_diameter=0.4,
            max_volumetric_speed=28.0,
            build_volume=(256, 256, 256),
            max_bridge_length=18.0,
        ),
        "bambu_a1": PrinterProfile(
            name="Bambu A1 Mini",
            model="Bambu Lab A1 Mini",
            nozzle_diameter=0.4,
            max_volumetric_speed=22.0,
            build_volume=(180, 180, 180),
            max_bridge_length=15.0,
        ),
        "prusa_mk4": PrinterProfile(
            name="Prusa MK4",
            model="Prusa i3 MK4",
            nozzle_diameter=0.4,
            max_volumetric_speed=25.0,
            build_volume=(250, 210, 220),
            max_bridge_length=15.0,
        ),
        "ender_3": PrinterProfile(
            name="Ender 3",
            model="Creality Ender 3",
            nozzle_diameter=0.4,
            max_volumetric_speed=12.0,
            build_volume=(220, 220, 250),
            max_bridge_length=12.0,
        ),
    }


def get_default_materials() -> Dict[str, MaterialProfile]:
    """Return a set of common material profiles."""
    return {
        "pla_generic": MaterialProfile(
            name="PLA (Generic)",
            brand="Generic",
            type="PLA",
            nozzle_temp_c=215,
            bed_temp_c=60,
            fan_speed=100,
            retraction_distance=0.8,
        ),
        "petg_generic": MaterialProfile(
            name="PETG (Generic)",
            brand="Generic",
            type="PETG",
            nozzle_temp_c=240,
            bed_temp_c=80,
            fan_speed=50,
            retraction_distance=1.0,
        ),
        "abs_generic": MaterialProfile(
            name="ABS (Generic)",
            brand="Generic",
            type="ABS",
            nozzle_temp_c=250,
            bed_temp_c=100,
            fan_speed=20,
            retraction_distance=1.2,
            shrinkage_pct=0.8,
        ),
        "pva_generic": MaterialProfile(
            name="PVA (Generic)",
            brand="Generic",
            type="PVA",
            nozzle_temp_c=190,
            bed_temp_c=45,
            fan_speed=80,
            retraction_distance=2.0,
            support_interface_required=True,
        ),
        "hips_generic": MaterialProfile(
            name="HIPS (Generic)",
            brand="Generic",
            type="HIPS",
            nozzle_temp_c=230,
            bed_temp_c=75,
            fan_speed=50,
            retraction_distance=1.5,
            support_interface_required=True,
        ),
    }


# ─── Profile Manager ───────────────────────────────────────────

class ProfileManager:
    """Manages printer and material profiles with lazy loading."""

    def __init__(self, data_dir: str = DEFAULT_DATA_DIR):
        self.data_dir = data_dir
        self._printers: Optional[Dict[str, PrinterProfile]] = None
        self._materials: Optional[Dict[str, MaterialProfile]] = None

    @property
    def printers(self) -> Dict[str, PrinterProfile]:
        if self._printers is None:
            self._printers = load_printers(self.data_dir)
            if not self._printers:
                self._printers = get_default_printers()
                save_printers(self._printers, self.data_dir)
        return self._printers

    @property
    def materials(self) -> Dict[str, MaterialProfile]:
        if self._materials is None:
            self._materials = load_materials(self.data_dir)
            if not self._materials:
                self._materials = get_default_materials()
                save_materials(self._materials, self.data_dir)
        return self._materials

    def get_printer(self, name: str) -> Optional[PrinterProfile]:
        return self.printers.get(name)

    def get_material(self, name: str) -> Optional[MaterialProfile]:
        return self.materials.get(name)

    def add_printer(self, profile: PrinterProfile):
        key = profile.name.lower().replace(" ", "_")
        self.printers[key] = profile
        save_printers(self.printers, self.data_dir)

    def add_material(self, profile: MaterialProfile):
        key = profile.name.lower().replace(" ", "_")
        self.materials[key] = profile
        save_materials(self.materials, self.data_dir)

    def calibrate_from_feedback(self, printer_name: str, material_name: str, quality_score: float, config: dict):
        """Update a printer's calibrated params based on feedback."""
        if quality_score < 50:
            return

        printer = self.get_printer(printer_name)
        if not printer:
            return

        alpha = 0.3 * (quality_score / 100.0)  # learning rate scaled by print quality
        for key, value in config.items():
            if isinstance(value, (int, float)):
                old = printer.calibrated_params.get(key, value)
                printer.calibrated_params[key] = old * (1 - alpha) + value * alpha

        printer.updated = time.time()
        save_printers(self.printers, self.data_dir)

    def list_printers(self) -> str:
        lines = ["\n  🖨️  Printer Profiles:"]
        for key, p in self.printers.items():
            lines.append(f"     {key:20s}  {p.model:30s}  {p.nozzle_diameter}mm nozzle")
        return "\n".join(lines)

    def list_materials(self) -> str:
        lines = ["\n  🧵 Material Profiles:"]
        for key, m in self.materials.items():
            lines.append(f"     {key:20s}  {m.brand:15s} {m.type:6s}  {m.nozzle_temp_c}°C / {m.bed_temp_c}°C")
        return "\n".join(lines)
