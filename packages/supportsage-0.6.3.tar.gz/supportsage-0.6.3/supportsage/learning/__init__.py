"""SupportSage AI Learning Engine (v0.6)

Records print outcomes and uses them to improve support strategies over time.
"""
