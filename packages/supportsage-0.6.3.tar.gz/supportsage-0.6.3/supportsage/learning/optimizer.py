"""
Feedback-driven strategy optimizer (v0.6).

Replaces hardcoded angle thresholds and density presets with learned
parameters derived from print outcome history.

The optimizer uses a simple but effective approach:
1. Start with sensible defaults (same as v0.5)
2. As feedback accumulates, adjust thresholds based on what actually worked
3. Printer + material combos develop their own optimal profiles
4. The more you print, the smarter the suggestions get
"""
from __future__ import annotations

import json
import math
import os
from dataclasses import dataclass, field, asdict
from typing import Dict, List, Optional, Tuple

from .feedback import (
    load_feedback, SupportConfig, best_config_for, FeedbackDB, hash_model
)
from .profile import ProfileManager


# ─── Default tuning parameters ─────────────────────────────────

@dataclass
class LearnedParams:
    """
    Parameters learned from print feedback history.

    These replace the hardcoded constants in tree_supports.py
    and optimizer.py with values tuned by actual print outcomes.
    """
    critical_angle: float = 120.0       # degrees from vertical
    moderate_angle: float = 70.0
    borderline_angle: float = 45.0
    critical_density: float = 1.0       # density multiplier
    moderate_density: float = 0.6
    borderline_density: float = 0.3
    branch_radius_critical: float = 1.5
    branch_radius_moderate: float = 1.0
    branch_radius_borderline: float = 0.8
    merge_distance: float = 5.0         # mm
    prefer_tree_support: bool = True
    confidence: float = 0.0             # 0-1 — how much data supports these params

    @classmethod
    def defaults(cls) -> "LearnedParams":
        return cls()

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "LearnedParams":
        return cls(**{k: v for k, v in d.items() if k in cls.__dataclass_fields__})


# ─── Optimizer ──────────────────────────────────────────────────

class StrategyOptimizer:
    """
    Core optimizer that uses feedback history to tune support strategies.

    Usage:
        opt = StrategyOptimizer()
        params = opt.learn(printer="bambu_x1c", material="PLA")
        # params contains angle thresholds tuned by history

    The more print outcomes are recorded, the more params diverge
    from defaults toward printer-specific optima.
    """

    def __init__(self, data_dir: str = ""):
        self.data_dir = data_dir or os.path.expanduser("~/.supportsage/learning")
        self.feedback = load_feedback(self.data_dir)
        self.profiles = ProfileManager(self.data_dir)

    def learn(
        self,
        printer: str = "",
        material: str = "",
    ) -> LearnedParams:
        """
        Compute learned parameters from feedback history.

        Start with defaults, then adjust based on:
        - Which configs produced the highest quality scores
        - Printer-specific calibrated params
        - Material-specific preferences
        """
        params = LearnedParams.defaults()

        if self.feedback.count() < 3:
            # Not enough data — return defaults with low confidence
            params.confidence = self.feedback.count() / 3.0
            return params

        # Filter relevant records
        candidates = self.feedback.records
        if printer:
            candidates = [r for r in candidates if r.printer == printer]
        if material:
            candidates = [r for r in candidates if r.material == material]

        if not candidates:
            params.confidence = 0.1
            return params

        # Compute quality-weighted average of observed config targets.
        total_weight = sum(r.quality_score for r in candidates if r.quality_score > 0)
        if total_weight == 0:
            params.confidence = 0.2
            return params

        defaults = LearnedParams.defaults()
        density_map = {"light": 0.5, "balanced": 1.0, "heavy": 1.5}
        observed = {
            "critical_angle": 0.0,
            "moderate_angle": 0.0,
            "borderline_angle": 0.0,
            "critical_density": 0.0,
            "moderate_density": 0.0,
            "borderline_density": 0.0,
        }

        for r in candidates:
            if r.quality_score <= 0:
                continue
            w = r.quality_score / total_weight
            cfg = r.support_config
            target_density = density_map.get(cfg.strategy, 1.0)

            observed["critical_angle"] += cfg.angle_threshold * 2.5 * w
            observed["moderate_angle"] += cfg.angle_threshold * 1.5 * w
            observed["borderline_angle"] += cfg.angle_threshold * w
            observed["critical_density"] += target_density * w
            observed["moderate_density"] += target_density * 0.7 * w
            observed["borderline_density"] += target_density * 0.4 * w

        # Confidence increases with data volume and controls how far learned
        # values move from defaults toward the weighted observations.
        params.confidence = min(1.0, len(candidates) / 20.0)
        for key, weighted_avg in observed.items():
            default = getattr(defaults, key)
            setattr(params, key, params.confidence * weighted_avg + (1 - params.confidence) * default)

        # Check if high-quality prints prefer tree vs pillar
        high_quality = [r for r in candidates if r.quality_score >= 80]
        if high_quality:
            tree_count = sum(1 for r in high_quality if r.support_config.support_type == "tree")
            params.prefer_tree_support = tree_count > len(high_quality) / 2

        # Apply printer-calibrated params if available
        printer_profile = self.profiles.get_printer(printer) if printer else None
        if printer_profile and printer_profile.calibrated_params:
            cal = printer_profile.calibrated_params
            if "branch_radius" in cal:
                params.branch_radius_critical = cal["branch_radius"]
                params.branch_radius_moderate = cal["branch_radius"] * 0.7
            if "merge_distance" in cal:
                params.merge_distance = cal["merge_distance"]

        return params

    def suggest_config(
        self,
        printer: str = "",
        material: str = "",
        model_path: str = "",
    ) -> SupportConfig:
        """
        Suggest the best support config for a given print job.

        Uses learned parameters to generate a config optimized for
        this printer + material combination.
        """
        params = self.learn(printer, material)

        # Check if there's a known best config for this combo
        known_best = best_config_for(printer, material, self.data_dir)
        if known_best and params.confidence > 0.5:
            return known_best

        # Generate config from learned params
        strategy = "balanced"
        if params.critical_density > 1.2:
            strategy = "heavy"
        elif params.critical_density < 0.7:
            strategy = "light"

        return SupportConfig(
            angle_threshold=params.borderline_angle,
            strategy=strategy,
            support_type="tree" if params.prefer_tree_support else "pillar",
            branch_radius=params.branch_radius_critical,
            merge_distance=params.merge_distance,
            density_mult=params.critical_density,
        )

    def report(self, printer: str = "", material: str = "") -> str:
        """Format a human-readable learning report."""
        params = self.learn(printer, material)
        lines = []

        conf_bar = "█" * int(params.confidence * 10) + "░" * (10 - int(params.confidence * 10))
        lines.append(f"\n  🧠 SupportSage Learning Engine")
        lines.append(f"  {'=' * 40}")

        if printer or material:
            context = f"{printer or 'any'} / {material or 'any'}"
            lines.append(f"  Context: {context}")
        lines.append(f"  Confidence: {params.confidence:.0%} {conf_bar}")
        lines.append(f"  Data points: {self.feedback.count()}")

        lines.append(f"\n  📐 Learned Angles:")
        lines.append(f"     🔴 Critical:   {params.critical_angle:.0f}° from vertical")
        lines.append(f"     🟠 Moderate:   {params.moderate_angle:.0f}°")
        lines.append(f"     🟡 Borderline: {params.borderline_angle:.0f}°")

        lines.append(f"\n  📊 Learned Densities:")
        lines.append(f"     Critical:   {params.critical_density:.1f}x")
        lines.append(f"     Moderate:   {params.moderate_density:.1f}x")
        lines.append(f"     Borderline: {params.borderline_density:.1f}x")

        lines.append(f"\n  🌳 Prefer tree supports: {'✅' if params.prefer_tree_support else '❌'}")

        if params.confidence < 0.3:
            lines.append(f"\n  ⚠️  Low confidence — keep printing and recording feedback!")
            lines.append(f"     Run 'supportsage learn feedback <model.stl> --score N' after each print")

        lines.append("")
        return "\n".join(lines)


# ─── Analysis helpers ───────────────────────────────────────────

def analyze_model_for_learning(
    model_path: str,
    printer: str = "",
    material: str = "",
    data_dir: str = "",
) -> dict:
    """
    Analyze an STL and return learning-optimized config suggestions.

    Combines:
    - Geometry analysis (overhang distribution)
    - Learned history (what worked before)
    - Profile defaults (printer/material capabilities)
    """
    from .. import analyzer as an

    data_dir = data_dir or os.path.expanduser("~/.supportsage/learning")
    mesh = an.load_stl(model_path)
    faces, overhang_mask = an.detect_overhangs(mesh, 45.0)
    severity = an.classify_overhang_severity(mesh, overhang_mask)
    islands = an.detect_islands(mesh, overhang_mask)

    n_critical = int(severity["critical"].sum())
    n_moderate = int(severity["moderate"].sum())

    opt = StrategyOptimizer(data_dir)
    params = opt.learn(printer, material)
    suggested = opt.suggest_config(printer, material, model_path)

    return {
        "model": model_path,
        "mesh_stats": {
            "vertices": len(mesh.vertices),
            "faces": len(faces),
        },
        "overhangs": {
            "critical": n_critical,
            "moderate": n_moderate,
            "islands": len(islands),
        },
        "learning": {
            "confidence": round(params.confidence, 2),
            "total_feedback_records": opt.feedback.count(),
        },
        "suggested_config": asdict(suggested),
    }
