"""
GCode preflight analyzer — predict print failures before you hit "print" (v0.5).

Parses GCode files and detects printability risks:
- Bridge spans that exceed safe length
- Overhang moves without adequate cooling
- Retraction patterns that cause stringing
- Layer time violations (insufficient cooling time)
- Travel moves through open air (blobs, zits)

This is the 3D printing equivalent of a static code analyzer.
"""
from __future__ import annotations

import math
import re
import numpy as np
from typing import List, Tuple, Dict, Optional
from dataclasses import dataclass, field


# ─── Constants ───────────────────────────────────────────────────

# Safe limits (conservative defaults — user can override)
MAX_BRIDGE_LENGTH_MM = 15.0      # mm — beyond this, bridging fails without fan
MAX_OVERHANG_ANGLE_DEG = 60.0    # degrees from vertical — beyond this needs support
MIN_LAYER_TIME_SEC = 15.0        # seconds — below this, layer cooling is insufficient
MAX_RETRACTIONS_PER_LAYER = 50   # above this, risk of grinding/heat creep
MAX_TRAVEL_GAP_MM = 5.0          # mm above print — beyond this risks stringing
MIN_WALL_THICKNESS_MM = 0.4      # mm — below this, walls collapse

# GCode command patterns
RE_G1 = re.compile(r'^G1\s', re.IGNORECASE)
RE_G0 = re.compile(r'^G0\s', re.IGNORECASE)
RE_G92 = re.compile(r'^G92\s', re.IGNORECASE)

RE_X = re.compile(r'X([-\d.]+)')
RE_Y = re.compile(r'Y([-\d.]+)')
RE_Z = re.compile(r'Z([-\d.]+)')
RE_E = re.compile(r'E([-\d.]+)')
RE_F = re.compile(r'F([\d.]+)')

RE_LAYER_CHANGE = re.compile(r';LAYER_CHANGE|;LAYER:(\d+)', re.IGNORECASE)
RE_COMMENT = re.compile(r';.*$')


# ─── Data Structures ─────────────────────────────────────────────

@dataclass
class GCodeMove:
    """A single GCode movement."""
    line_no: int
    cmd: str          # G1, G0, G92
    x: Optional[float] = None
    y: Optional[float] = None
    z: Optional[float] = None
    e: Optional[float] = None
    f: Optional[float] = None  # feed rate (mm/min)
    is_extruding: bool = False
    is_retracting: bool = False


@dataclass
class BridgeSpan:
    """A detected bridge (extrusion across open space)."""
    length_mm: float
    start_pos: Tuple[float, float, float]
    end_pos: Tuple[float, float, float]
    layer: int
    line_no_start: int
    line_no_end: int


@dataclass
class OverhangMove:
    """An extrusion move at a steep angle (potential overhang issue)."""
    angle_deg: float
    length_mm: float
    position: Tuple[float, float, float]
    layer: int
    line_no: int


@dataclass
class QuickMove:
    """A fast travel move above the print (stringing risk)."""
    distance_mm: float
    height_above_print: float
    start_pos: Tuple[float, float, float]
    end_pos: Tuple[float, float, float]
    layer: int
    line_no: int


@dataclass
class RetractionEvent:
    """A retraction or de-retraction."""
    amount_mm: float
    position: Tuple[float, float, float]
    layer: int
    line_no: int
    is_retraction: bool  # True=retract, False=de-retract


@dataclass
class LayerInfo:
    """Statistics for a single layer."""
    layer_no: int
    z_height: float
    extrusion_mm: float = 0.0
    time_sec: float = 0.0
    retraction_count: int = 0
    min_x: float = float('inf')
    max_x: float = float('-inf')
    min_y: float = float('inf')
    max_y: float = float('-inf')
    move_count: int = 0


@dataclass
class GCodeAnalysis:
    """Complete analysis result."""
    risky_bridges: List[BridgeSpan] = field(default_factory=list)
    risky_overhangs: List[OverhangMove] = field(default_factory=list)
    risky_travels: List[QuickMove] = field(default_factory=list)
    retractions: List[RetractionEvent] = field(default_factory=list)
    layers: Dict[int, LayerInfo] = field(default_factory=dict)
    total_extrusion_mm: float = 0.0
    total_retraction_mm: float = 0.0
    max_bridge_length: float = 0.0
    max_retractions_per_layer: int = 0
    min_layer_time: float = float('inf')
    travel_distance_mm: float = 0.0
    print_time_estimate_min: float = 0.0


# ─── Parser ─────────────────────────────────────────────────────

def parse_gcode(filepath: str) -> Tuple[List[GCodeMove], Dict[int, LayerInfo]]:
    """Parse a GCode file into structured moves and layer info."""
    moves = []
    layers: Dict[int, LayerInfo] = {}
    current_layer = 0
    current_z = 0.0
    last_pos: Dict[str, float] = {"x": 0, "y": 0, "z": 0}
    prev_extrusion = 0.0  # absolute E value tracking
    e_is_absolute = True

    with open(filepath) as f:
        for line_no, raw_line in enumerate(f, 1):
            # Strip comments
            line = RE_COMMENT.sub('', raw_line).strip()
            if not line:
                continue

            # Track layer changes
            layer_match = RE_LAYER_CHANGE.search(raw_line)
            if layer_match:
                layer_val = layer_match.group(1)
                current_layer = int(layer_val) if layer_val else current_layer + 1

            # Detect E-relative mode
            if RE_G92.search(line):
                e_match = RE_E.search(line)
                if e_match:
                    prev_extrusion = float(e_match.group(1))
                moves.append(GCodeMove(
                    line_no=line_no, cmd="G92",
                    **{k: v for k, v in _parse_axes(line).items()}
                ))
                continue

            # G0/G1 moves
            g1_match = RE_G1.search(line)
            g0_match = RE_G0.search(line)
            if not g1_match and not g0_match:
                continue

            cmd = "G1" if g1_match else "G0"
            axes = _parse_axes(line)
            e_val = axes.get("e")

            # Update relative/absolute mode from G90/G91 — skip for now
            # Assume absolute positioning (typical sliced GCode)

            # Build move
            move = GCodeMove(
                line_no=line_no,
                cmd=cmd,
                x=axes.get("x", last_pos["x"]),
                y=axes.get("y", last_pos["y"]),
                z=axes.get("z", last_pos["z"]),
                e=e_val,
                f=axes.get("f"),
            )

            # Compute extrusion delta
            if e_val is not None:
                e_delta = e_val - prev_extrusion
                prev_extrusion = e_val
                move.is_extruding = e_delta > 0.01
                move.is_retracting = e_delta < -0.01
            elif cmd == "G1":
                # Extrusion was explicitly zero — still a "move" but no filament
                pass

            moves.append(move)

            # Update last position
            for axis in ["x", "y", "z"]:
                if axes.get(axis) is not None:
                    last_pos[axis] = axes[axis]

            # Track layer info
            if cmd == "G1" and move.z is not None:
                current_z = move.z

            if current_layer not in layers:
                layers[current_layer] = LayerInfo(
                    layer_no=current_layer,
                    z_height=current_z,
                )

            layer_info = layers[current_layer]
            layer_info.move_count += 1
            if cmd == "G1" and move.is_extruding:
                if move.x is not None and move.y is not None:
                    if layer_info.min_x > move.x: layer_info.min_x = move.x
                    if layer_info.max_x < move.x: layer_info.max_x = move.x
                    if layer_info.min_y > move.y: layer_info.min_y = move.y
                    if layer_info.max_y < move.y: layer_info.max_y = move.y

    return moves, layers


def _parse_axes(line: str) -> Dict[str, float]:
    """Extract axis values from a GCode line."""
    result = {}
    for pattern, key in [
        (RE_X, "x"), (RE_Y, "y"), (RE_Z, "z"),
        (RE_E, "e"), (RE_F, "f"),
    ]:
        match = pattern.search(line)
        if match:
            result[key] = float(match.group(1))
    return result


# ─── Analysis ────────────────────────────────────────────────────

def analyze_gcode(filepath: str, **kwargs) -> GCodeAnalysis:
    """
    Analyze a GCode file for printability risks.

    Returns a full GCodeAnalysis with detected:
    - Bridge spans exceeding safe length
    - Overhang moves at risky angles
    - Travel moves prone to stringing
    - Retraction pattern issues
    - Layer time violations
    """
    moves, layers = parse_gcode(filepath)

    analysis = GCodeAnalysis()
    analysis.layers = layers

    max_bridge = kwargs.get("max_bridge_length", MAX_BRIDGE_LENGTH_MM)
    max_overhang = kwargs.get("max_overhang_angle", MAX_OVERHANG_ANGLE_DEG)
    min_layer_time = kwargs.get("min_layer_time", MIN_LAYER_TIME_SEC)

    # Pass 1: collect state
    pos = {"x": 0.0, "y": 0.0, "z": 0.0}
    e_pos = 0.0
    prev_extrude_pos = None
    prev_move = None
    current_layer = 0

    # Bridge detection state
    bridge_start = None
    bridge_pos_start = None

    # Per-layer retraction tracking
    layer_retractions: Dict[int, int] = {}
    layer_extrusion: Dict[int, float] = {}

    # Travel move tracking
    last_extrude_pos = None

    for move in moves:
        # Track layer
        for ln, li in layers.items():
            if abs(li.z_height - (move.z or pos["z"])) < 0.01:
                current_layer = ln
                break

        new_pos = {
            "x": move.x if move.x is not None else pos["x"],
            "y": move.y if move.y is not None else pos["y"],
            "z": move.z if move.z is not None else pos["z"],
        }

        # Compute segment length
        dx = new_pos["x"] - pos["x"]
        dy = new_pos["y"] - pos["y"]
        dz = new_pos["z"] - pos["z"]
        seg_length = math.sqrt(dx*dx + dy*dy + dz*dz)

        # --- Extruding move (G1 with E) ---
        if move.cmd == "G1" and move.is_extruding and seg_length > 0.1:
            xy_length = math.sqrt(dx*dx + dy*dy)

            # Bridge detection: extruding across with no support below
            # A bridge is a long XY move at constant Z with extrusion
            if xy_length > max_bridge * 0.7 and abs(dz) < 0.1:
                if bridge_start is None:
                    bridge_start = (pos["x"], pos["y"], pos["z"])
                    bridge_pos_start = pos.copy()
                else:
                    # Extend bridge
                    pass
            else:
                if bridge_start is not None:
                    bridge_length = math.sqrt(
                        (pos["x"] - bridge_start[0])**2 +
                        (pos["y"] - bridge_start[1])**2
                    )
                    if bridge_length > max_bridge:
                        analysis.risky_bridges.append(BridgeSpan(
                            length_mm=bridge_length,
                            start_pos=(bridge_start[0], bridge_start[1], bridge_start[2]),
                            end_pos=(pos["x"], pos["y"], pos["z"]),
                            layer=current_layer,
                            line_no_start=move.line_no - 10,
                            line_no_end=move.line_no,
                        ))
                        analysis.max_bridge_length = max(
                            analysis.max_bridge_length, bridge_length
                        )
                    bridge_start = None
                    bridge_pos_start = None

            # Overhang detection: angled XY + Z move
            if xy_length > 0 and abs(dz) > 0.1:
                angle_deg = math.degrees(math.atan2(dz, xy_length))
                if angle_deg > max_overhang:
                    analysis.risky_overhangs.append(OverhangMove(
                        angle_deg=abs(angle_deg),
                        length_mm=seg_length,
                        position=(new_pos["x"], new_pos["y"], new_pos["z"]),
                        layer=current_layer,
                        line_no=move.line_no,
                    ))

            # Track extrusion per layer
            e_delta = (move.e or 0) - e_pos
            analysis.total_extrusion_mm += max(0, e_delta)
            layer_extrusion[current_layer] = \
                layer_extrusion.get(current_layer, 0) + max(0, e_delta)

            last_extrude_pos = new_pos.copy()

        # --- Retraction ---
        if move.is_retracting:
            e_delta = (move.e or 0) - e_pos
            analysis.retractions.append(RetractionEvent(
                amount_mm=abs(e_delta),
                position=(pos["x"], pos["y"], pos["z"]),
                layer=current_layer,
                line_no=move.line_no,
                is_retraction=True,
            ))
            analysis.total_retraction_mm += abs(e_delta)
            layer_retractions[current_layer] = \
                layer_retractions.get(current_layer, 0) + 1

        # --- Travel move (G0 or G1 without E) ---
        if move.cmd == "G0" or (move.cmd == "G1" and not move.is_extruding
                                 and not move.is_retracting and seg_length > 1.0):
            if last_extrude_pos is not None and new_pos["z"] > pos["z"] + 0.1:
                # Travel move moving up and across — stringing risk
                gap = new_pos["z"] - (last_extrude_pos.get("z", pos["z"]))
                if gap > MAX_TRAVEL_GAP_MM:
                    analysis.risky_travels.append(QuickMove(
                        distance_mm=seg_length,
                        height_above_print=gap,
                        start_pos=(pos["x"], pos["y"], pos["z"]),
                        end_pos=(new_pos["x"], new_pos["y"], new_pos["z"]),
                        layer=current_layer,
                        line_no=move.line_no,
                    ))
                    analysis.travel_distance_mm += seg_length

        # Update state
        e_pos = move.e if move.e is not None else e_pos
        pos = new_pos
        prev_move = move

    # Layer time estimation (very rough: assume 30mm³/min flow rate typical)
    # This is intentionally conservative — actual time depends on printer
    for ln, info in layers.items():
        info.extrusion_mm = layer_extrusion.get(ln, 0)
        # Approximate: 1mm of 0.4mm filament ≈ 0.125mm³ volume
        vol_mm3 = info.extrusion_mm * 0.125
        # Flow rate ~8mm³/s for a typical hotend
        info.time_sec = vol_mm3 / 8.0 if vol_mm3 > 0 else 0.1
        info.retraction_count = layer_retractions.get(ln, 0)

    # Compute aggregates
    analysis.max_retractions_per_layer = max(layer_retractions.values()) if layer_retractions else 0
    analysis.min_layer_time = min(
        (l.time_sec for l in layers.values() if l.time_sec > 0),
        default=float('inf'),
    )
    analysis.print_time_estimate_min = sum(
        l.time_sec for l in layers.values()
    ) / 60.0

    return analysis


def compute_printability_score(analysis: GCodeAnalysis) -> Tuple[float, Dict[str, float]]:
    """
    Compute a 0-100 printability score based on detected risks.

    Score breakdown:
    - Bridges: 25 points (deduct 5 per risky bridge, min 0)
    - Overhangs: 20 points (deduct 4 per risky overhang, min 0)
    - Retractions: 15 points (deduct 3 per 10 excess retractions/layer)
    - Layer time: 20 points (deduct 5 per sec below min_layer_time)
    - Travel moves: 10 points (deduct 2 per risky travel)
    - General: 10 points (reserve)
    """
    subscores = {}

    # Bridges (25 pts)
    bridge_penalty = min(25, len(analysis.risky_bridges) * 5)
    subscores["bridges"] = max(0, 25 - bridge_penalty)

    # Overhangs (20 pts)
    overhang_penalty = min(20, len(analysis.risky_overhangs) * 4)
    subscores["overhangs"] = max(0, 20 - overhang_penalty)

    # Retractions (15 pts)
    excess_retractions = max(0, analysis.max_retractions_per_layer - MAX_RETRACTIONS_PER_LAYER)
    retraction_penalty = min(15, (excess_retractions // 10) * 3)
    subscores["retractions"] = max(0, 15 - retraction_penalty)

    # Layer time (20 pts)
    if analysis.min_layer_time < MIN_LAYER_TIME_SEC:
        time_penalty = min(20, int((MIN_LAYER_TIME_SEC - analysis.min_layer_time) * 5))
    else:
        time_penalty = 0
    subscores["layer_time"] = max(0, 20 - time_penalty)

    # Travel moves (10 pts)
    travel_penalty = min(10, len(analysis.risky_travels) * 2)
    subscores["travel_moves"] = max(0, 10 - travel_penalty)

    # General (10 pts) — reserve for future checks
    subscores["general"] = 10

    total = sum(subscores.values())
    return total, subscores


def format_preflight_report(
    analysis: GCodeAnalysis,
    score: float,
    subscores: Dict[str, float],
) -> str:
    """Format a human-readable preflight analysis report."""
    lines = []
    lines.append("")
    lines.append("=" * 55)
    lines.append("  🖨️  SupportSage GCode Preflight")
    lines.append("=" * 55)

    # Score
    grade = "🟢 Excellent" if score >= 85 else \
            "🟡 Good" if score >= 65 else \
            "🟠 Fair" if score >= 45 else \
            "🔴 Poor"
    lines.append(f"\n  Printability Score: {score:.0f}/100 — {grade}")
    lines.append(f"  Estimated print time: {analysis.print_time_estimate_min:.1f} min")

    # Subscore breakdown
    lines.append(f"\n  📊 Breakdown:")
    for key, val in sorted(subscores.items(), key=lambda x: -x[1]):
        bar = "█" * int(val / 5) + "░" * (5 - int(val / 5))
        lines.append(f"     {key:15s} {val:5.0f}/25  {bar}" if key == "bridges" else
                     f"     {key:15s} {val:5.0f}/20  {bar}" if key in ("overhangs", "layer_time") else
                     f"     {key:15s} {val:5.0f}/15  {bar}" if key == "retractions" else
                     f"     {key:15s} {val:5.0f}/10  {bar}")

    # Risks
    if analysis.risky_bridges:
        lines.append(f"\n  🌉 Risky Bridges ({len(analysis.risky_bridges)}):")
        for b in analysis.risky_bridges[:5]:
            lines.append(f"     • {b.length_mm:.0f}mm at layer {b.layer} (L{b.line_no_start})")
        if len(analysis.risky_bridges) > 5:
            lines.append(f"     ... and {len(analysis.risky_bridges) - 5} more")

    if analysis.risky_overhangs:
        lines.append(f"\n  ⛰️  Risky Overhangs ({len(analysis.risky_overhangs)}):")
        for o in analysis.risky_overhangs[:5]:
            lines.append(f"     • {o.angle_deg:.0f}° at L{o.line_no}")
        if len(analysis.risky_overhangs) > 5:
            lines.append(f"     ... and {len(analysis.risky_overhangs) - 5} more")

    if analysis.risky_travels:
        lines.append(f"\n  🏃 Risky Travel Moves ({len(analysis.risky_travels)}):")
        for t in analysis.risky_travels[:3]:
            lines.append(f"     • {t.distance_mm:.0f}mm gap at {t.height_above_print:.1f}mm above print")
        if len(analysis.risky_travels) > 3:
            lines.append(f"     ... and {len(analysis.risky_travels) - 3} more")

    # Retraction stats
    lines.append(f"\n  📌 Retraction Stats:")
    lines.append(f"     Total retraction: {analysis.total_retraction_mm:.1f}mm")
    lines.append(f"     Max retractions/layer: {analysis.max_retractions_per_layer}")

    # Fix suggestions
    lines.append(f"\n  💡 Fix Suggestions:")
    if analysis.risky_bridges:
        lines.append(f"     🔧 Add supports under bridges >{MAX_BRIDGE_LENGTH_MM:.0f}mm (found {len(analysis.risky_bridges)})")
    if analysis.min_layer_time < MIN_LAYER_TIME_SEC:
        lines.append(f"     🔧 Increase minimum layer time to {MIN_LAYER_TIME_SEC:.0f}s (min found: {analysis.min_layer_time:.1f}s)")
    if analysis.risky_overhangs:
        lines.append(f"     🔧 Add tree supports for overhangs >{MAX_OVERHANG_ANGLE_DEG:.0f}°")
    if analysis.risky_travels:
        lines.append(f"     🔧 Reduce travel height or enable retraction on long moves")
    if not any([analysis.risky_bridges, analysis.risky_overhangs,
                analysis.min_layer_time < MIN_LAYER_TIME_SEC, analysis.risky_travels]):
        lines.append(f"     ✅ No issues detected — this GCode looks clean!")

    lines.append("")
    return "\n".join(lines)


def analyze_stl_preprint(
    stl_path: str,
    angle_threshold: float = 45.0,
) -> Dict:
    """
    Analyze an STL for printability without slicing.

    Returns:
    - Overhang distribution
    - Island count and severity
    - Minimum feature size (estimated)
    - Printability concerns
    """
    from . import analyzer as an

    try:
        mesh = an.load_stl(stl_path)
    except Exception as e:
        return {"error": str(e), "score": 0}

    # Overhang analysis
    faces, overhang_mask = an.detect_overhangs(mesh, angle_threshold)
    islands = an.detect_islands(mesh, overhang_mask)
    severity = an.classify_overhang_severity(mesh, overhang_mask)

    n_critical = int(severity["critical"].sum())
    n_moderate = int(severity["moderate"].sum())
    n_borderline = int(severity["borderline"].sum())
    n_safe = len(faces) - n_critical - n_moderate - n_borderline

    # Compute printability concerns
    concerns = []
    score = 100

    if n_critical > 0:
        concerns.append(f"{n_critical} critical overhang faces — tree supports recommended")
        score -= min(30, n_critical * 3)

    if len(islands) > 20:
        concerns.append(f"{len(islands)} overhang islands — risk of missed supports")
        score -= min(15, len(islands))

    if n_moderate > 50:
        concerns.append(f"{n_moderate} moderate overhang faces — may need support")
        score -= min(10, n_moderate // 10)

    # Estimate minimum feature size
    min_feature = _estimate_min_feature(mesh)

    return {
        "mesh_stats": {
            "vertices": len(mesh.vertices),
            "faces": len(faces),
            "volume_mm3": mesh.volume,
        },
        "overhangs": {
            "total_overhang_pct": (n_critical + n_moderate + n_borderline) / max(1, len(faces)) * 100,
            "critical": n_critical,
            "moderate": n_moderate,
            "borderline": n_borderline,
            "safe": n_safe,
            "islands": len(islands),
        },
        "min_feature_size_mm": round(min_feature, 2),
        "printability_score": max(0, score),
        "concerns": concerns,
        "suggestion": (
            "Run supportsage tree to generate optimized supports"
            if n_critical > 0 or n_moderate > 10
            else "Model looks printable with standard settings"
        ),
    }


def _estimate_min_feature(mesh) -> float:
    """Estimate the minimum feature size of a mesh."""
    if len(mesh.vertices) < 10:
        return 10.0

    # Sample edge lengths
    edges = mesh.edges_unique
    if len(edges) < 5:
        return 5.0

    edge_lengths = np.linalg.norm(
        mesh.vertices[edges[:, 0]] - mesh.vertices[edges[:, 1]],
        axis=1,
    )

    # Minimum feature is approximately the 5th percentile edge length
    return float(np.percentile(edge_lengths, 5))
