"""
SupportSage CLI - AI-optimized support structures for 3D printing.

Usage:
    supportsage analyze model.stl
    supportsage optimize model.stl -o output.stl --strategy balanced
    supportsage export model.stl -f cura-json
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from . import __version__
from .analyzer import full_analysis
from .optimizer import generate_support_strategy, generate_support_geometry
from .tree_supports import add_tree_parser, tree_command
from .gcode_preflight import (
    analyze_gcode,
    compute_printability_score,
    format_preflight_report,
    analyze_stl_preprint,
)
from .learning.feedback import record_feedback, print_feedback_summary, hash_model, SupportConfig
from .learning.profile import ProfileManager
from .learning.optimizer import StrategyOptimizer, analyze_model_for_learning


def _print_filament_info(filament_arg: str) -> None:
    """Lazy-import filamentdb and print recommended temperatures."""
    try:
        from filamentdb.database import recommend
    except ImportError:
        print(
            "  💡 FilamentDB not installed. Install with: pip install filamentdb\n"
        )
        return

    # Parse "Brand Model" — split on first space
    parts = filament_arg.strip().split(None, 1)
    if len(parts) == 2:
        brand, model = parts[0], parts[1]
        result = recommend(brand, model)
    else:
        # Treat the whole string as material type
        result = recommend(None, None, filament_arg.strip())

    if not result:
        print(f"  ⚠️  No filament data found for '{filament_arg}'.\n")
        return

    nt = result.get("nozzle_temp", {})
    bt = result.get("bed_temp", {})

    print(f"  💡 Filament Recommendations ({result.get('brand', '?')} {result.get('model', '?')}):")
    if nt:
        rec = nt.get("recommended", "—")
        lo = nt.get("min", "—")
        hi = nt.get("max", "—")
        print(f"     🔥 Nozzle: {rec}°C  (range: {lo}–{hi}°C)")
    if bt:
        rec = bt.get("recommended", "—")
        lo = bt.get("min", "—")
        hi = bt.get("max", "—")
        print(f"     🛏️  Bed:    {rec}°C  (range: {lo}–{hi}°C)")

    extra = []
    if result.get("max_volumetric_speed"):
        extra.append(f"Max volumetric: {result['max_volumetric_speed']} mm³/s")
    if result.get("retraction_distance"):
        extra.append(f"Retraction: {result['retraction_distance']} mm @ {result.get('retraction_speed', '?')} mm/s")
    if result.get("fan_speed"):
        extra.append(f"Fan speed: {result['fan_speed']}%")
    if result.get("bed_adhesion"):
        extra.append(f"Adhesion: {result['bed_adhesion']}")
    if extra:
        print(f"     ℹ️  {'  |  '.join(extra)}")
    if result.get("notes"):
        print(f"     📝 {result['notes']}")
    print()


def main():
    parser = argparse.ArgumentParser(
        prog="supportsage",
        description="AI-optimized support structures for 3D printing",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  supportsage analyze model.stl
      Analyze overhangs and estimate support material needed.

  supportsage optimize model.stl -o output.stl --strategy balanced
      Generate optimized support structures for the model.

  supportsage analyze model.stl --json
      Output analysis as JSON for programmatic use.
        """,
    )

    parser.add_argument(
        "--version", action="version", version=f"%(prog)s {__version__}"
    )

    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # analyze
    analyze_parser = subparsers.add_parser("analyze", help="Analyze STL overhangs")
    analyze_parser.add_argument("model", type=str, help="Path to STL file")
    analyze_parser.add_argument(
        "--angle", type=float, default=45.0, help="Overhang angle threshold (default: 45)"
    )
    analyze_parser.add_argument(
        "--json", action="store_true", help="Output as JSON"
    )
    analyze_parser.add_argument(
        "--filament", type=str, default=None,
        help='Filament lookup, e.g. "Bambu Lab PLA Basic" (requires filamentdb)'
    )

    # optimize
    optimize_parser = subparsers.add_parser("optimize", help="Generate optimized supports")
    optimize_parser.add_argument("model", type=str, help="Path to STL file")
    optimize_parser.add_argument(
        "-o", "--output", type=str, default="model_with_supports.stl",
        help="Output STL path"
    )
    optimize_parser.add_argument(
        "--angle", type=float, default=45.0, help="Overhang angle threshold"
    )
    optimize_parser.add_argument(
        "--strategy", choices=["light", "balanced", "heavy"],
        default="balanced", help="Support density strategy"
    )
    optimize_parser.add_argument(
        "--filament", type=str, default=None,
        help='Filament lookup, e.g. "Bambu Lab PLA Basic" (requires filamentdb)'
    )

    # export
    export_parser = subparsers.add_parser("export", help="Export support strategy")
    export_parser.add_argument("model", type=str, help="Path to STL file")
    export_parser.add_argument(
        "-f", "--format", choices=["json", "cura-json", "orca-config"],
        default="json", help="Export format"
    )
    export_parser.add_argument(
        "-o", "--output", type=str, default=None,
        help="Output file path (default: stdout)"
    )

    # tree
    tree_parser = add_tree_parser(subparsers)

    # preflight — GCode pre-print analysis (v0.5)
    preflight_parser = subparsers.add_parser(
        "preflight", help="Analyze GCode for printability risks before printing"
    )
    preflight_parser.add_argument("gcode", type=str, help="Path to GCode file")
    preflight_parser.add_argument(
        "--json", action="store_true", help="Output as JSON"
    )
    preflight_parser.add_argument(
        "--max-bridge", type=float, default=15.0,
        help="Max safe bridge length in mm (default: 15)"
    )
    preflight_parser.add_argument(
        "--max-overhang", type=float, default=60.0,
        help="Max safe overhang angle in degrees (default: 60)"
    )

    # precheck — STL printability analysis (v0.5)
    precheck_parser = subparsers.add_parser(
        "precheck", help="Check STL printability without slicing"
    )
    precheck_parser.add_argument("model", type=str, help="Path to STL file")
    precheck_parser.add_argument(
        "--angle", type=float, default=45.0,
        help="Overhang angle threshold (default: 45)"
    )
    precheck_parser.add_argument(
        "--json", action="store_true", help="Output as JSON"
    )

    # learn — AI learning engine (v0.6)
    learn_parser = subparsers.add_parser(
        "learn", help="AI Learning Engine — improve strategies from print outcomes"
    )
    learn_sub = learn_parser.add_subparsers(dest="learn_cmd")

    # learn feedback
    fb_parser = learn_sub.add_parser("feedback", help="Record a print outcome")
    fb_parser.add_argument("model", type=str, help="Path to STL file that was printed")
    fb_parser.add_argument("--score", type=float, required=True, help="Quality score 0-100 (from Printsight or manual)")
    fb_parser.add_argument("--printer", type=str, default="unknown", help="Printer name/profile")
    fb_parser.add_argument("--material", type=str, default="PLA", help="Material used")
    fb_parser.add_argument("--rating", type=int, default=0, help="User rating 1-5 (optional)")
    fb_parser.add_argument("--strategy", type=str, default="balanced", choices=["light", "balanced", "heavy"])
    fb_parser.add_argument("--support-type", type=str, default="tree", choices=["tree", "pillar"])
    fb_parser.add_argument("--duration", type=float, default=0.0, help="Print duration in minutes")
    fb_parser.add_argument("--notes", type=str, default="", help="Optional notes")

    # learn report
    lr_parser = learn_sub.add_parser("report", help="Show learned parameters and statistics")
    lr_parser.add_argument("--printer", type=str, default="", help="Filter by printer")
    lr_parser.add_argument("--material", type=str, default="", help="Filter by material")

    # learn suggest
    ls_parser = learn_sub.add_parser("suggest", help="Get config suggestion for a model")
    ls_parser.add_argument("model", type=str, help="Path to STL file")
    ls_parser.add_argument("--printer", type=str, default="", help="Printer name/profile")
    ls_parser.add_argument("--material", type=str, default="", help="Material")

    # learn profiles
    lp_parser = learn_sub.add_parser("profiles", help="Manage printer and material profiles")
    lp_parser.add_argument("--printer", type=str, default=None, help="Show specific printer profile")
    lp_parser.add_argument("--material", type=str, default=None, help="Show specific material profile")

    args = parser.parse_args()

    if args.command == "analyze":
        _cmd_analyze(args)
    elif args.command == "optimize":
        _cmd_optimize(args)
    elif args.command == "export":
        _cmd_export(args)
    elif args.command == "tree":
        tree_command(args)
    elif args.command == "preflight":
        _cmd_preflight(args)
    elif args.command == "precheck":
        _cmd_precheck(args)
    elif args.command == "learn":
        _cmd_learn(args)
    else:
        parser.print_help()
        sys.exit(1)


def _cmd_analyze(args):
    try:
        result = full_analysis(args.model, args.angle)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)

    if args.json:
        print(json.dumps(result, indent=2))
        return

    oh = result["overhang"]
    ms = result["mesh_stats"]

    print(f"\n{'='*50}")
    print(f"  SupportSage Analysis")
    print(f"  {result['mesh_path']}")
    print(f"{'='*50}")
    print(f"\n  📐 Model Stats:")
    print(f"     Vertices: {ms['vertices']:,}")
    print(f"     Faces:    {ms['faces']:,}")
    print(f"     Volume:   {ms['volume']:.1f} mm³")
    print(f"     Area:     {ms['area']:.1f} mm²")
    print(f"     Watertight: {'✅' if ms['is_watertight'] else '❌'}")

    print(f"\n  ⚠️ Overhang Analysis (threshold: {args.angle}°):")
    print(f"     Total overhang faces: {oh['total_faces']:,} ({oh['percentage']:.1f}%)")
    print(f"     🔴 Critical:  {oh['critical_faces']:,}")
    print(f"     🟡 Moderate:  {oh['moderate_faces']:,}")
    print(f"     🟢 Borderline: {oh['borderline_faces']:,}")
    print(f"     Islands:       {oh['num_islands']}")

    print(f"\n  💰 Support Material Estimate:")
    print(f"     Volume: {oh['estimated_support_volume_mm3']:.0f} mm³")
    print(f"     Weight: {oh['estimated_support_material_g']:.1f} g (PLA)")
    print(f"\n  💡 Run 'supportsage optimize {Path(args.model).name}'")
    print(f"     to generate optimized support structures.\n")

    if args.filament:
        _print_filament_info(args.filament)


def _cmd_optimize(args):
    try:
        strategy = generate_support_strategy(
            args.model, args.angle, args.strategy
        )
        output_path = generate_support_geometry(strategy, args.output)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)

    print(f"\n{'='*50}")
    print(f"  SupportSage Optimization Complete")
    print(f"{'='*50}")
    print(f"\n  📊 Strategy: {args.strategy}")
    print(f"  🏝️ Overhang islands: {strategy['analysis']['num_islands']}")
    print(f"  📦 Estimated support: {strategy['analysis']['estimated_support_volume_mm3']:.0f} mm³")
    print(f"  💾 Saved: ~{strategy['savings_estimate']['material_saved_vs_uniform']}")
    print(f"\n  ✅ Output: {output_path}")
    print()

    if args.filament:
        _print_filament_info(args.filament)


def _cmd_export(args):
    try:
        strategy = generate_support_strategy(args.model)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)

    if args.format == "json":
        output = json.dumps(strategy, indent=2)
    elif args.format == "cura-json":
        # Cura plugin format - simplified
        output = json.dumps({
            "type": "custom_support",
            "name": "SupportSage Optimized",
            "settings": {
                "support_angle": strategy["config"]["angle_threshold"],
                "support_density": strategy["config"]["density"],
                "support_type": strategy["config"]["support_type"],
                "support_interface_enable": strategy["config"]["interface_layers"],
            },
            "islands": [
                {
                    "id": s["island_id"],
                    "strategy": s["strategy"],
                    "center": s["center"],
                }
                for s in strategy["island_strategies"]
            ],
        }, indent=2)
    elif args.format == "orca-config":
        output = json.dumps({
            "support": {
                "enabled": True,
                "type": strategy["config"]["support_type"],
                "threshold_angle": strategy["config"]["angle_threshold"],
                "density": strategy["config"]["density"],
            },
        }, indent=2)
    else:
        output = json.dumps(strategy, indent=2)

    if args.output:
        Path(args.output).write_text(output)
        print(f"✅ Exported to {args.output}")
    else:
        print(output)


def _cmd_preflight(args):
    """Handle 'supportsage preflight' command."""
    try:
        analysis = analyze_gcode(
            args.gcode,
            max_bridge_length=args.max_bridge,
            max_overhang_angle=args.max_overhang,
        )
        score, subscores = compute_printability_score(analysis)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)

    if args.json:
        import json as _json
        print(_json.dumps({
            "score": score,
            "subscores": subscores,
            "bridges": len(analysis.risky_bridges),
            "overhangs": len(analysis.risky_overhangs),
            "travels": len(analysis.risky_travels),
            "retractions": len(analysis.retractions),
            "print_time_min": round(analysis.print_time_estimate_min, 1),
        }, indent=2))
        return

    report = format_preflight_report(analysis, score, subscores)
    print(report)


def _cmd_precheck(args):
    """Handle 'supportsage precheck' command."""
    try:
        result = analyze_stl_preprint(args.model, args.angle)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)

    if "error" in result:
        print(f"Error: {result['error']}")
        sys.exit(1)

    if args.json:
        import json as _json
        print(_json.dumps(result, indent=2))
        return

    stats = result["mesh_stats"]
    oh = result["overhangs"]

    print(f"\n{'='*55}")
    print(f"  🖨️  SupportSage Printability Check")
    print(f"  {args.model}")
    print(f"{'='*55}")

    print(f"\n  📐 Mesh: {stats['vertices']:,} verts | {stats['faces']:,} faces")
    print(f"     Volume: {stats['volume_mm3']:.0f} mm³")

    print(f"\n  ⛰️  Overhang Distribution (threshold: {args.angle}°):")
    print(f"     🔴 Critical:    {oh['critical']}")
    print(f"     🟠 Moderate:    {oh['moderate']}")
    print(f"     🟡 Borderline:  {oh['borderline']}")
    print(f"     🟢 Safe:        {oh['safe']}")
    print(f"     🏝️  Islands:      {oh['islands']}")

    print(f"\n  📏 Min feature size: ~{result['min_feature_size_mm']:.1f} mm")

    score = result["printability_score"]
    grade = "🟢 Excellent" if score >= 85 else \
            "🟡 Good" if score >= 65 else \
            "🟠 Fair" if score >= 45 else \
            "🔴 Poor"
    print(f"\n  🖨️  Printability Score: {score}/100 — {grade}")

    if result["concerns"]:
        print(f"\n  ⚠️  Concerns:")
        for c in result["concerns"]:
            print(f"     • {c}")

    print(f"\n  💡 {result['suggestion']}\n")


def _cmd_learn(args):
    """Handle 'supportsage learn' subcommands."""
    if not hasattr(args, 'learn_cmd') or not args.learn_cmd:
        print("Usage: supportsage learn {feedback|report|suggest|profiles}")
        print("  supportsage learn feedback model.stl --score 85 --printer bambu_x1c --material PLA")
        print("  supportsage learn report")
        print("  supportsage learn suggest model.stl --printer bambu_x1c")
        print("  supportsage learn profiles")
        return

    if args.learn_cmd == "feedback":
        _cmd_learn_feedback(args)
    elif args.learn_cmd == "report":
        _cmd_learn_report(args)
    elif args.learn_cmd == "suggest":
        _cmd_learn_suggest(args)
    elif args.learn_cmd == "profiles":
        _cmd_learn_profiles(args)


def _cmd_learn_feedback(args):
    """Record a print outcome."""
    config = SupportConfig(
        strategy=args.strategy,
        support_type=args.support_type,
    )
    record = record_feedback(
        mesh_path=args.model,
        quality_score=args.score,
        support_config=config,
        printer=args.printer,
        material=args.material,
        user_rating=args.rating,
        duration_min=args.duration,
        notes=args.notes,
    )
    model_hash = hash_model(args.model)
    print(f"\n  ✅ Print outcome recorded")
    print(f"  Model:    {record.model_name}")
    print(f"  Hash:     {model_hash}")
    print(f"  Score:    {record.quality_score:.0f}/100")
    print(f"  Printer:  {record.printer}")
    print(f"  Material: {record.material}")

    # Show updated learning stats
    opt = StrategyOptimizer()
    learned = opt.learn(args.printer, args.material)
    print(f"\n  📈 Learning confidence: {learned.confidence:.0%}")
    if learned.confidence >= 0.3:
        print(f"  💡 Run 'supportsage learn report' for full stats")
    print()


def _cmd_learn_report(args):
    """Show learning report."""
    opt = StrategyOptimizer()
    report = opt.report(args.printer, args.material)
    print(report)

    # Also show feedback summary
    summary = print_feedback_summary(opt.data_dir)
    print(summary)


def _cmd_learn_suggest(args):
    """Get config suggestion for a model."""
    result = analyze_model_for_learning(
        args.model, args.printer, args.material,
    )

    print(f"\n  💡 SupportSage Suggestion")
    print(f"  {'=' * 40}")
    print(f"  Model: {result['model']}")
    print(f"  Confidence: {result['learning']['confidence']:.0%}")
    print(f"  Feedback records: {result['learning']['total_feedback_records']}")

    cfg = result["suggested_config"]
    print(f"\n  📋 Recommended Config:")
    print(f"     Strategy:         {cfg['strategy']}")
    print(f"     Support type:     {cfg['support_type']}")
    print(f"     Angle threshold:  {cfg['angle_threshold']:.0f}°")
    print(f"     Branch radius:    {cfg['branch_radius']:.1f}mm")
    print(f"     Merge distance:   {cfg['merge_distance']:.1f}mm")

    if result["learning"]["confidence"] < 0.3:
        print(f"\n  ⚠️  Low confidence — more feedback needed")
    print()


def _cmd_learn_profiles(args):
    """Show available printer and material profiles."""
    pm = ProfileManager()
    print(pm.list_printers())
    print(pm.list_materials())

    if args.printer:
        p = pm.get_printer(args.printer)
        if p:
            print(f"\n  📋 Printer: {p.name} ({p.model})")
            print(f"     Nozzle: {p.nozzle_diameter}mm")
            print(f"     Build volume: {p.build_volume[0]}×{p.build_volume[1]}×{p.build_volume[2]}mm")
            print(f"     Max bridge: {p.max_bridge_length}mm")
            if p.calibrated_params:
                print(f"     Calibrated: {p.calibrated_params}")
        else:
            print(f"  ❌ Printer '{args.printer}' not found")
    if args.material:
        m = pm.get_material(args.material)
        if m:
            print(f"\n  🧵 Material: {m.name} ({m.brand})")
            print(f"     Type: {m.type}")
            print(f"     Nozzle: {m.nozzle_temp_c}°C / Bed: {m.bed_temp_c}°C")
        else:
            print(f"  ❌ Material '{args.material}' not found")
    print()


if __name__ == "__main__":
    main()
