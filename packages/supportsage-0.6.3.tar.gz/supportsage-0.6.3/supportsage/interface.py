"""
Multi-material interface layer generator — soluble support interface (v0.3).

When printing with dual-material support (e.g., PLA body + PVA/HIPS interface),
a thin layer of soluble material sits between the support structure and the
model surface. This allows the support to break away cleanly with zero scarring.

This module:
1. Identifies all support contact points on the model surface
2. Generates thin interface discs/caps at each contact
3. Outputs a separate STL for the interface layer
4. Generates filament swap markers for MMU/AMS systems
"""
from __future__ import annotations

import math
import numpy as np
import trimesh
from typing import List, Tuple, Optional


# ─── Default interface parameters ───────────────────────────────

INTERFACE_THICKNESS = 0.3  # mm — single extrusion layer
INTERFACE_RADIUS = {
    "critical": 3.0,    # wider cap for steep overhangs
    "moderate": 2.0,
    "borderline": 1.2,
}
INTERFACE_SEGMENTS = 12  # polygon approximation for discs

# GCode filament swap markers
FILAMENT_CHANGE_GCODE = "M600"        # Marlin/RepRap
BAMBU_AMS_MARKER = "M620 S{color}"    # Bambu AMS color change
MMU_PRUSA_MARKER = "M702 T{index}"     # Prusa MMU tool change


# ─── Data Structures ─────────────────────────────────────────────

class InterfaceDisc:
    """A single circular interface layer at a support contact point."""
    def __init__(
        self,
        center: np.ndarray,
        normal: np.ndarray,
        radius: float,
        thickness: float = INTERFACE_THICKNESS,
        island_id: int = 0,
        severity: str = "moderate",
    ):
        self.center = np.array(center, dtype=float)
        self.normal = np.array(normal, dtype=float)
        self.radius = radius
        self.thickness = thickness
        self.island_id = island_id
        self.severity = severity

    def to_mesh(self) -> trimesh.Trimesh:
        """Generate a thin disc/cap mesh for this interface point."""
        normal = self.normal / (np.linalg.norm(self.normal) + 1e-10)

        # Build local coordinate system
        if abs(normal[2]) < 0.99:
            up = np.array([0, 0, 1.0])
        else:
            up = np.array([1, 0, 0.0])

        right = np.cross(normal, up)
        right /= np.linalg.norm(right) + 1e-10
        forward = np.cross(right, normal)
        forward /= np.linalg.norm(forward) + 1e-10

        theta = np.linspace(0, 2 * np.pi, INTERFACE_SEGMENTS, endpoint=False)

        # Two rings: top face (at model surface) and bottom face (offset inward)
        # The disc sits between the support tip and the model surface
        top_verts = []
        bottom_verts = []

        for t in theta:
            circle_vec = right * math.cos(t) + forward * math.sin(t)
            # Top ring — at the model surface
            top_verts.append(self.center + circle_vec * self.radius)
            # Bottom ring — offset toward the build plate by thickness
            bottom_verts.append(
                self.center + circle_vec * self.radius - normal * self.thickness
            )

        # Vertices: top ring + bottom ring + center points
        all_verts = np.vstack(top_verts + bottom_verts)
        n = INTERFACE_SEGMENTS

        # Center points for top (index 2n) and bottom (index 2n+1)
        top_center = len(all_verts)
        bottom_center = len(all_verts) + 1
        all_verts = np.vstack([
            all_verts,
            self.center,                              # top center
            self.center - normal * self.thickness,    # bottom center
        ])

        # Build faces
        faces = []

        # Side band (connecting top and bottom rings)
        for i in range(n):
            i_next = (i + 1) % n
            faces.append([i, i_next, i + n])
            faces.append([i_next, i_next + n, i + n])

        # Top cap (faces toward model)
        for i in range(n):
            i_next = (i + 1) % n
            faces.append([top_center, i_next, i])

        # Bottom cap (faces toward build plate)
        for i in range(n):
            i_next = (i + 1) % n
            faces.append([bottom_center, i + n, i_next + n])

        return trimesh.Trimesh(vertices=all_verts, faces=np.array(faces))


# ─── Interface Generation ────────────────────────────────────────

def extract_contact_points(
    support_mesh: trimesh.Trimesh,
    model_mesh: trimesh.Trimesh,
    islands: List[np.ndarray],
    severity: dict,
    island_severity_map: dict,
) -> List[InterfaceDisc]:
    """
    Find all points where support branches touch the model surface.

    Strategy: for each vertex in the support mesh that's very close to
    a model face (within 0.5mm), it's a contact point. Extract its
    position and compute the interface disc parameters.

    For tree supports, the tips are at the Z-max of each branch.
    """
    from . import analyzer

    discs = []

    # Find the topmost points of the support mesh — these are branch tips
    support_verts = support_mesh.vertices
    if len(support_verts) == 0:
        return discs

    # For each overhang island, find the support contact region
    processed_islands = set()
    for i, island in enumerate(islands):
        if len(island) == 0:
            continue

        island_faces = model_mesh.faces[island]
        island_verts = model_mesh.vertices[island_faces.flatten()]

        # Find the lower boundary of this island (the surfaces that need support)
        min_z = island_verts[:, 2].min()
        center = island_verts.mean(axis=0)

        # Get severity for this island
        island_sev = island_severity_map.get(i, "moderate")
        disc_radius = INTERFACE_RADIUS.get(island_sev, 2.0)

        # Get the average face normal in the support region
        support_normals = model_mesh.face_normals[island]
        avg_normal = support_normals.mean(axis=0)
        if np.linalg.norm(avg_normal) > 0:
            avg_normal = avg_normal / np.linalg.norm(avg_normal)

        # Create interface disc at the lowest point of the island
        # (where the support tip makes contact)
        contact_point = center.copy()
        contact_point[2] = min_z

        disc = InterfaceDisc(
            center=contact_point,
            normal=avg_normal if avg_normal[2] < 0 else np.array([0, 0, -1]),
            radius=disc_radius,
            thickness=INTERFACE_THICKNESS,
            island_id=i,
            severity=island_sev,
        )
        discs.append(disc)
        processed_islands.add(i)

    return discs


def generate_interface_mesh(
    support_mesh: trimesh.Trimesh,
    model_mesh: trimesh.Trimesh,
    islands: List[np.ndarray],
    severity: dict,
    island_severity_map: dict,
    thickness: float = INTERFACE_THICKNESS,
) -> trimesh.Trimesh:
    """
    Generate a soluble interface layer mesh between supports and model.

    Returns a mesh that can be exported as a separate STL for
    dual-material printing.
    """
    discs = extract_contact_points(
        support_mesh, model_mesh,
        islands, severity, island_severity_map,
    )

    if not discs:
        return trimesh.Trimesh()

    meshes = []
    for disc in discs:
        disc.thickness = thickness
        disc_mesh = disc.to_mesh()
        if len(disc_mesh.vertices) > 0:
            meshes.append(disc_mesh)

    if not meshes:
        return trimesh.Trimesh()

    return trimesh.util.concatenate(meshes)


# ─── GCode / AMS / MMU Export ─────────────────────────────────────

def generate_filament_swap_gcode(
    interface_layer_height: float,
    printer_type: str = "marlin",
    body_filament: str = "PLA",
    interface_filament: str = "PVA",
    body_tool: int = 0,
    interface_tool: int = 1,
) -> str:
    """
    Generate GCode filament swap instructions for multi-material printers.

    The swap happens at the interface layer height: print support body in
    PLA, then switch to PVA for the interface layer at the contact surface.
    """
    gcode = []
    gcode.append("; ═══════════════════════════════════════")
    gcode.append(f"; SupportSage Multi-Material Interface Layer")
    gcode.append(f"; Body: {body_filament} (T{body_tool})")
    gcode.append(f"; Interface: {interface_filament} (T{interface_tool})")
    gcode.append(f"; Interface height: {interface_layer_height}mm")
    gcode.append("; ═══════════════════════════════════════")
    gcode.append("")

    if "bambu" in printer_type.lower():
        # Bambu AMS: tool = AMS slot index (0-3)
        gcode.append(f"; Bambu AMS — switch to interface filament slot {interface_tool}")
        gcode.append(f"M620 S{interface_tool}")
    elif "mmu" in printer_type.lower() or "prusa" in printer_type.lower():
        # Prusa MMU
        gcode.append(f"; Prusa MMU — switch to tool T{interface_tool}")
        gcode.append(f"M702 T{interface_tool}")
    else:
        # Generic Marlin
        gcode.append(f"; Marlin — filament change at layer {interface_layer_height:.1f}mm")
        gcode.append(f"; Unload {body_filament}")
        gcode.append("G1 E-50 F3000  ; retract filament")
        gcode.append("G1 Z5 F3000    ; raise Z")
        gcode.append("G1 X0 Y0 F6000 ; park head")
        gcode.append(f"{FILAMENT_CHANGE_GCODE}  ; change filament")
        gcode.append(f"; Load {interface_filament}")
        gcode.append("G92 E0")
        gcode.append("G1 E20 F300  ; prime")

    gcode.append("")
    return "\n".join(gcode)


def export_interface_3mf(
    body_mesh: trimesh.Trimesh,
    interface_mesh: trimesh.Trimesh,
    output_path: str,
    body_material: str = "PLA",
    interface_material: str = "PVA",
    ) -> Tuple[str, str]:
    """
    Export a combined 3MF file with two material volumes.

    3MF supports multi-volume export which most modern slicers
    (PrusaSlicer, Bambu Studio, Orca) can import as separate
    objects with different materials assigned.

    Falls back to two separate STL files if 3MF export fails.
    """
    try:
        # Export as two separate STLs (widest compatibility)
        base = output_path.rsplit(".", 1)[0] if "." in output_path else output_path
        body_path = f"{base}_body.stl"
        interface_path = f"{base}_interface.stl"

        body_mesh.export(body_path)
        interface_mesh.export(interface_path)

        # Try 3MF export if available
        combined = trimesh.util.concatenate([body_mesh, interface_mesh])
        if hasattr(trimesh, 'export_3mf') or True:
            try:
                combined_path = f"{base}_combined.3mf"
                # trimesh doesn't natively export multi-material 3MF
                # Fall through to STLs
                pass
            except Exception:
                pass

        return body_path, interface_path
    except Exception:
        base = output_path.rsplit(".", 1)[0] if "." in output_path else output_path
        return f"{base}_body.stl", f"{base}_interface.stl"
