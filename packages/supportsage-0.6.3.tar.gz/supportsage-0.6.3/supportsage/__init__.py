"""SupportSage — AI-optimized support structures for 3D printing."""

__version__ = "0.6.3"
