"""Tests for supportsage.learning.profile module."""
import json
import os
import time

import pytest

from supportsage.learning.profile import (
    PrinterProfile,
    MaterialProfile,
    ProfileManager,
    load_printers,
    save_printers,
    load_materials,
    save_materials,
    get_default_printers,
    get_default_materials,
    PRINTERS_FILE,
    MATERIALS_FILE,
)


# ─── Data Classes ────────────────────────────────────────────────

class TestPrinterProfile:
    def test_default_values(self):
        p = PrinterProfile(name="test")
        assert p.model == "unknown"
        assert p.nozzle_diameter == 0.4
        assert p.max_volumetric_speed == 15.0
        assert p.build_volume == (256, 256, 256)
        assert p.preferred_support_type == "tree"
        assert p.max_bridge_length == 15.0
        assert p.fan_cooling is True
        assert p.calibrated_params == {}

    def test_custom_values(self):
        p = PrinterProfile(
            name="fast_printer",
            model="Custom F1",
            nozzle_diameter=0.6,
            max_volumetric_speed=40.0,
            build_volume=(350, 350, 400),
            max_bridge_length=25.0,
            fan_cooling=False,
            calibrated_params={"overhang_angle": 50.0},
        )
        assert p.name == "fast_printer"
        assert p.nozzle_diameter == 0.6
        assert p.calibrated_params["overhang_angle"] == 50.0

    def test_timestamps_auto_set(self):
        p = PrinterProfile(name="fresh")
        assert p.created == pytest.approx(time.time(), rel=1)
        assert p.updated == pytest.approx(time.time(), rel=1)


class TestMaterialProfile:
    def test_default_values(self):
        m = MaterialProfile(name="default")
        assert m.type == "PLA"
        assert m.nozzle_temp_c == 215
        assert m.bed_temp_c == 60
        assert m.fan_speed == 100
        assert m.retraction_distance == 0.8
        assert m.support_interface_required is False

    def test_support_interface_materials(self):
        pva = MaterialProfile(name="PVA", type="PVA", support_interface_required=True)
        assert pva.support_interface_required is True

    def test_custom_temps(self):
        abs = MaterialProfile(name="ABS", type="ABS", nozzle_temp_c=250, bed_temp_c=100)
        assert abs.nozzle_temp_c == 250
        assert abs.bed_temp_c == 100


# ─── Default Profiles ────────────────────────────────────────────

class TestDefaultProfiles:
    def test_get_default_printers_has_expected_keys(self):
        printers = get_default_printers()
        expected = {"bambu_x1c", "bambu_p1s", "bambu_a1", "prusa_mk4", "ender_3"}
        assert set(printers.keys()) == expected

    def test_default_printers_types(self):
        printers = get_default_printers()
        for key, p in printers.items():
            assert isinstance(p, PrinterProfile)
            assert p.name

    def test_x1c_specs(self):
        printers = get_default_printers()
        x1c = printers["bambu_x1c"]
        assert x1c.max_volumetric_speed == 32.0
        assert x1c.build_volume == (256, 256, 256)

    def test_get_default_materials_has_expected_keys(self):
        materials = get_default_materials()
        expected = {"pla_generic", "petg_generic", "abs_generic", "pva_generic", "hips_generic"}
        assert set(materials.keys()) == expected

    def test_default_materials_types(self):
        materials = get_default_materials()
        for key, m in materials.items():
            assert isinstance(m, MaterialProfile)
            assert m.name

    def test_pva_requires_interface(self):
        mats = get_default_materials()
        assert mats["pva_generic"].support_interface_required is True

    def test_abs_has_shrinkage(self):
        mats = get_default_materials()
        assert mats["abs_generic"].shrinkage_pct == 0.8


# ─── Storage IO ──────────────────────────────────────────────────

class TestProfileIO:
    def test_save_and_load_printers_roundtrip(self, tmp_data_dir, sample_printer):
        profiles = {"test": sample_printer}
        save_printers(profiles, tmp_data_dir)
        loaded = load_printers(tmp_data_dir)
        assert "test" in loaded
        assert loaded["test"].name == "test_printer"
        assert loaded["test"].nozzle_diameter == 0.4

    def test_save_and_load_materials_roundtrip(self, tmp_data_dir, sample_material):
        profiles = {"test_pla": sample_material}
        save_materials(profiles, tmp_data_dir)
        loaded = load_materials(tmp_data_dir)
        assert "test_pla" in loaded
        assert loaded["test_pla"].nozzle_temp_c == 215

    def test_load_printers_nonexistent(self, tmp_data_dir):
        assert load_printers(tmp_data_dir) == {}

    def test_load_materials_nonexistent(self, tmp_data_dir):
        assert load_materials(tmp_data_dir) == {}

    def test_save_printers_creates_dir(self, tmp_data_dir):
        subdir = os.path.join(tmp_data_dir, "printers_test")
        save_printers({"x": PrinterProfile(name="x")}, subdir)
        assert os.path.exists(os.path.join(subdir, PRINTERS_FILE))

    def test_printers_file_format(self, tmp_data_dir, sample_printer):
        save_printers({"test": sample_printer}, tmp_data_dir)
        path = os.path.join(tmp_data_dir, PRINTERS_FILE)
        with open(path) as f:
            data = json.load(f)
        assert "test" in data
        assert data["test"]["name"] == "test_printer"
        assert data["test"]["nozzle_diameter"] == 0.4
        assert "calibrated_params" in data["test"]

    def test_materials_file_format(self, tmp_data_dir, sample_material):
        save_materials({"pla": sample_material}, tmp_data_dir)
        path = os.path.join(tmp_data_dir, MATERIALS_FILE)
        with open(path) as f:
            data = json.load(f)
        assert data["pla"]["type"] == "PLA"
        assert data["pla"]["nozzle_temp_c"] == 215

    def test_load_printers_corrupted_json(self, tmp_data_dir):
        """Corrupted printers.json should return empty dict, not crash."""
        path = os.path.join(tmp_data_dir, PRINTERS_FILE)
        os.makedirs(tmp_data_dir, exist_ok=True)
        with open(path, "w") as f:
            f.write("{invalid json garbage}")
        result = load_printers(tmp_data_dir)
        assert result == {}

    def test_load_materials_corrupted_json(self, tmp_data_dir):
        """Corrupted materials.json should return empty dict, not crash."""
        path = os.path.join(tmp_data_dir, MATERIALS_FILE)
        os.makedirs(tmp_data_dir, exist_ok=True)
        with open(path, "w") as f:
            f.write("{invalid json garbage}")
        result = load_materials(tmp_data_dir)
        assert result == {}


# ─── ProfileManager ──────────────────────────────────────────────

class TestProfileManager:
    def test_init(self):
        pm = ProfileManager()
        assert pm._printers is None
        assert pm._materials is None

    def test_printers_property_lazy_loads_defaults(self, tmp_data_dir):
        pm = ProfileManager(data_dir=tmp_data_dir)
        printers = pm.printers
        assert len(printers) == 5  # All default printers
        assert "bambu_x1c" in printers

    def test_materials_property_lazy_loads_defaults(self, tmp_data_dir):
        pm = ProfileManager(data_dir=tmp_data_dir)
        mats = pm.materials
        assert len(mats) == 5  # All default materials
        assert "pla_generic" in mats

    def test_defaults_persisted_after_first_access(self, tmp_data_dir):
        pm = ProfileManager(data_dir=tmp_data_dir)
        _ = pm.printers
        _ = pm.materials
        # Check they were saved to disk
        assert os.path.exists(os.path.join(tmp_data_dir, PRINTERS_FILE))
        assert os.path.exists(os.path.join(tmp_data_dir, MATERIALS_FILE))

    def test_get_printer_found(self, tmp_data_dir):
        pm = ProfileManager(data_dir=tmp_data_dir)
        p = pm.get_printer("bambu_x1c")
        assert p is not None
        assert p.model == "Bambu Lab X1 Carbon"

    def test_get_printer_not_found(self, tmp_data_dir):
        pm = ProfileManager(data_dir=tmp_data_dir)
        assert pm.get_printer("nonexistent") is None

    def test_get_material_found(self, tmp_data_dir):
        pm = ProfileManager(data_dir=tmp_data_dir)
        m = pm.get_material("pla_generic")
        assert m is not None
        assert m.type == "PLA"

    def test_get_material_not_found(self, tmp_data_dir):
        pm = ProfileManager(data_dir=tmp_data_dir)
        assert pm.get_material("nonexistent") is None

    def test_add_printer(self, tmp_data_dir, sample_printer):
        pm = ProfileManager(data_dir=tmp_data_dir)
        pm.add_printer(sample_printer)
        assert "test_printer" in pm.printers
        # Verify persisted
        loaded = load_printers(tmp_data_dir)
        assert "test_printer" in loaded

    def test_add_material(self, tmp_data_dir, sample_material):
        pm = ProfileManager(data_dir=tmp_data_dir)
        pm.add_material(sample_material)
        assert "test_pla" in pm.materials
        loaded = load_materials(tmp_data_dir)
        assert "test_pla" in loaded

    def test_add_printer_key_generation(self, tmp_data_dir):
        pm = ProfileManager(data_dir=tmp_data_dir)
        p = PrinterProfile(name="My Custom Printer")
        pm.add_printer(p)
        assert "my_custom_printer" in pm.printers

    def test_calibrate_from_feedback(self, tmp_data_dir):
        pm = ProfileManager(data_dir=tmp_data_dir)
        pm.calibrate_from_feedback("bambu_x1c", "PLA", 90.0, {"branch_radius": 0.8, "merge_distance": 3.0})
        printer = pm.get_printer("bambu_x1c")
        assert printer is not None
        # Should have applied exponential moving average with alpha=0.3
        # Default branch_radius is not in calibrated_params, so new value is just used
        assert "branch_radius" in printer.calibrated_params
        assert "merge_distance" in printer.calibrated_params

    def test_calibrate_nonexistent_printer(self, tmp_data_dir):
        pm = ProfileManager(data_dir=tmp_data_dir)
        # Should not crash
        pm.calibrate_from_feedback("nonexistent_printer", "PLA", 90.0, {"branch_radius": 0.8})

    def test_calibrate_skips_low_quality(self, tmp_data_dir):
        """quality_score < 50 should skip the update entirely."""
        pm = ProfileManager(data_dir=tmp_data_dir)

        # First calibrate with high quality to set a value
        pm.calibrate_from_feedback("bambu_x1c", "PLA", 90.0, {"branch_radius": 0.8})
        val_before = pm.get_printer("bambu_x1c").calibrated_params["branch_radius"]
        assert val_before == pytest.approx(0.8)

        # Then try with low quality — should be skipped
        pm.calibrate_from_feedback("bambu_x1c", "PLA", 20.0, {"branch_radius": 2.0})
        val_after = pm.get_printer("bambu_x1c").calibrated_params["branch_radius"]
        assert val_after == pytest.approx(0.8)  # unchanged

    def test_calibrate_zero_quality_skipped(self, tmp_data_dir):
        """quality_score of 0 should be skipped (0 < 50)."""
        pm = ProfileManager(data_dir=tmp_data_dir)
        pm.calibrate_from_feedback("bambu_x1c", "PLA", 90.0, {"branch_radius": 0.8})

        pm.calibrate_from_feedback("bambu_x1c", "PLA", 0.0, {"branch_radius": 2.0})
        val = pm.get_printer("bambu_x1c").calibrated_params["branch_radius"]
        assert val == pytest.approx(0.8)  # unchanged

    def test_calibrate_boundary_quality_50(self, tmp_data_dir):
        """quality_score of exactly 50 should NOT be skipped (50 is not < 50)."""
        pm = ProfileManager(data_dir=tmp_data_dir)
        pm.calibrate_from_feedback("bambu_x1c", "PLA", 50.0, {"branch_radius": 1.5})
        val = pm.get_printer("bambu_x1c").calibrated_params["branch_radius"]
        # Should have been applied (with alpha = 0.3 * 0.5 = 0.15)
        assert val == pytest.approx(1.5)

    def test_calibrate_with_ema(self, tmp_data_dir):
        """Verify exponential moving average works."""
        pm = ProfileManager(data_dir=tmp_data_dir)
        # First update: old value doesn't exist, so new value is used
        pm.calibrate_from_feedback("bambu_x1c", "PLA", 90.0, {"branch_radius": 0.8})
        first_val = pm.get_printer("bambu_x1c").calibrated_params["branch_radius"]
        assert first_val == pytest.approx(0.8)
        # Second update: ema with alpha=0.3 * (quality_score / 100) = 0.3 * 0.95 = 0.285
        # new_val = old * (1-0.285) + new * 0.285 = 0.8 * 0.715 + 1.2 * 0.285 = 0.914
        pm.calibrate_from_feedback("bambu_x1c", "PLA", 95.0, {"branch_radius": 1.2})
        second_val = pm.get_printer("bambu_x1c").calibrated_params["branch_radius"]
        expected = 0.8 * 0.715 + 1.2 * 0.285
        assert second_val == pytest.approx(expected)

    def test_updated_timestamp_changes_on_calibrate(self, tmp_data_dir):
        pm = ProfileManager(data_dir=tmp_data_dir)
        printer = pm.get_printer("bambu_x1c")
        old_updated = printer.updated
        pm.calibrate_from_feedback("bambu_x1c", "PLA", 85.0, {"branch_radius": 1.0})
        assert printer.updated > old_updated

    def test_list_printers_format(self, tmp_data_dir):
        pm = ProfileManager(data_dir=tmp_data_dir)
        output = pm.list_printers()
        assert "Printer Profiles" in output
        assert "bambu_x1c" in output
        assert "Bambu Lab X1 Carbon" in output

    def test_list_materials_format(self, tmp_data_dir):
        pm = ProfileManager(data_dir=tmp_data_dir)
        output = pm.list_materials()
        assert "Material Profiles" in output
        assert "pla_generic" in output
        assert "215°C" in output


# ─── Custom data_dir ─────────────────────────────────────────────

def test_custom_data_dir_isolation(tmp_data_dir):
    """Two ProfileManagers with different data dirs should be isolated."""
    dir1 = os.path.join(tmp_data_dir, "dir1")
    dir2 = os.path.join(tmp_data_dir, "dir2")
    pm1 = ProfileManager(data_dir=dir1)
    pm2 = ProfileManager(data_dir=dir2)

    p1 = PrinterProfile(name="custom_printer_x")
    p2 = PrinterProfile(name="custom_printer_y")
    pm1.add_printer(p1)
    pm2.add_printer(p2)

    assert "custom_printer_x" in pm1.printers
    assert "custom_printer_x" not in pm2.printers
