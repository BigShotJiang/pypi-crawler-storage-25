"""Tests for supportsage.learning.feedback module."""
import json
import os
import tempfile
from pathlib import Path
from unittest.mock import patch, MagicMock, mock_open

import pytest

from supportsage.learning.feedback import (
    SupportConfig,
    PrintFeedback,
    FeedbackDB,
    load_feedback,
    save_feedback,
    record_feedback,
    best_config_for,
    print_feedback_summary,
    hash_model,
    DEFAULT_DATA_DIR,
    FEEDBACK_FILE,
)


# ─── Data Classes ────────────────────────────────────────────────

class TestSupportConfig:
    def test_default_values(self):
        cfg = SupportConfig()
        assert cfg.angle_threshold == 45.0
        assert cfg.strategy == "balanced"
        assert cfg.support_type == "tree"
        assert cfg.branch_radius == 1.0
        assert cfg.merge_distance == 5.0
        assert cfg.interface_thickness == 0.3
        assert cfg.density_mult == 1.0

    def test_custom_values(self):
        cfg = SupportConfig(
            angle_threshold=60.0,
            strategy="light",
            support_type="pillar",
            branch_radius=0.8,
            merge_distance=3.0,
            interface_thickness=0.2,
            density_mult=0.8,
        )
        assert cfg.angle_threshold == 60.0
        assert cfg.strategy == "light"
        assert cfg.support_type == "pillar"


class TestPrintFeedback:
    def test_default_values(self):
        fb = PrintFeedback(model_hash="abc", model_name="test.stl", quality_score=75.0,
                            support_config=SupportConfig())
        assert fb.printer == "unknown"
        assert fb.material == "PLA"
        assert fb.user_rating == 0
        assert fb.defects == {}
        assert fb.duration_min == 0.0
        assert fb.notes == ""

    def test_all_fields(self, sample_record):
        assert sample_record.model_hash == "abc123def456"
        assert sample_record.model_name == "bracket.stl"
        assert sample_record.quality_score == 85.0
        assert sample_record.user_rating == 4
        assert sample_record.printer == "bambu_x1c"
        assert sample_record.support_config.strategy == "balanced"


# ─── FeedbackDB ──────────────────────────────────────────────────

class TestFeedbackDB:
    def test_empty_db(self):
        db = FeedbackDB()
        assert db.count() == 0
        assert db.avg_quality() == 0.0
        assert db.get_by_hash("nonexistent") == []

    def test_add_and_count(self, sample_record):
        db = FeedbackDB()
        db.add(sample_record)
        assert db.count() == 1

    def test_add_updates_hash_index(self, sample_record):
        db = FeedbackDB()
        db.add(sample_record)
        assert len(db._by_hash) == 1
        assert db._by_hash["abc123def456"][0] is sample_record

    def test_get_by_hash_found(self, sample_record):
        db = FeedbackDB()
        db.add(sample_record)
        results = db.get_by_hash("abc123def456")
        assert len(results) == 1
        assert results[0] is sample_record

    def test_get_by_hash_not_found(self, sample_record):
        db = FeedbackDB()
        db.add(sample_record)
        assert db.get_by_hash("xyz") == []

    def test_get_by_printer(self, filled_db):
        results = filled_db.get_by_printer("bambu_x1c")
        assert len(results) == 4  # sample_record + i=0 + i=2 + i=4
        for r in results:
            assert r.printer == "bambu_x1c"

    def test_get_by_printer_no_match(self, filled_db):
        assert filled_db.get_by_printer("nonexistent") == []

    def test_get_by_material(self, filled_db):
        results = filled_db.get_by_material("PLA")
        assert len(results) == 4  # sample_record + i=0,1,2
        for r in results:
            assert r.material == "PLA"

    def test_get_recent(self, filled_db):
        recent = filled_db.get_recent(3)
        assert len(recent) == 3
        # Most recent first (lower timestamp = newer)
        timestamps = [r.timestamp for r in recent]
        assert timestamps == sorted(timestamps, reverse=True)

    def test_get_recent_more_than_available(self, filled_db):
        assert len(filled_db.get_recent(100)) == filled_db.count()

    def test_avg_quality(self, filled_db):
        expected = sum(r.quality_score for r in filled_db.records) / filled_db.count()
        assert filled_db.avg_quality() == pytest.approx(expected)

    def test_avg_quality_empty(self):
        assert FeedbackDB().avg_quality() == 0.0


# ─── Storage IO ──────────────────────────────────────────────────

class TestLoadSaveFeedback:
    def test_save_and_load_roundtrip(self, filled_db, tmp_data_dir):
        """Verify that saving then loading preserves all data."""
        save_feedback(filled_db, tmp_data_dir)
        loaded = load_feedback(tmp_data_dir)
        assert loaded.count() == filled_db.count()
        assert loaded.avg_quality() == filled_db.avg_quality()

    def test_load_nonexistent(self, tmp_data_dir):
        db = load_feedback(tmp_data_dir)
        assert db.count() == 0

    def test_save_creates_directory(self, tmp_data_dir):
        subdir = os.path.join(tmp_data_dir, "nested", "dir")
        db = FeedbackDB()
        save_feedback(db, subdir)
        assert os.path.exists(os.path.join(subdir, FEEDBACK_FILE))

    def test_save_file_content(self, sample_record, tmp_data_dir):
        db = FeedbackDB()
        db.add(sample_record)
        save_feedback(db, tmp_data_dir)

        path = os.path.join(tmp_data_dir, FEEDBACK_FILE)
        with open(path) as f:
            data = json.load(f)
        assert len(data) == 1
        assert data[0]["model_hash"] == "abc123def456"
        assert data[0]["quality_score"] == 85.0
        assert data[0]["support_config"]["strategy"] == "balanced"

    def test_load_corrupted_file(self, tmp_data_dir):
        path = os.path.join(tmp_data_dir, FEEDBACK_FILE)
        os.makedirs(tmp_data_dir, exist_ok=True)
        with open(path, "w") as f:
            f.write("{invalid json")
        db = load_feedback(tmp_data_dir)
        assert db.count() == 0  # Should handle gracefully

    def test_load_partial_corruption(self, tmp_data_dir):
        """Dataclass doesn't validate types at runtime — both records load."""
        path = os.path.join(tmp_data_dir, FEEDBACK_FILE)
        os.makedirs(tmp_data_dir, exist_ok=True)
        data = [
            {"model_hash": "good", "model_name": "a.stl", "quality_score": 90.0,
             "support_config": {"angle_threshold": 45.0}},
            {"model_hash": "bad", "model_name": "b.stl", "quality_score": "not_a_number",
             "support_config": {"angle_threshold": 45.0}},
        ]
        with open(path, "w") as f:
            json.dump(data, f)
        db = load_feedback(tmp_data_dir)
        assert db.count() == 2  # Both load (no runtime type validation in dataclass)
        assert db.records[1].quality_score == "not_a_number"  # stored as-is


# ─── hash_model ──────────────────────────────────────────────────

class TestHashModel:
    def test_hash_with_trimesh(self):
        """If trimesh is available, it should use geometry signature."""
        mock_mesh = MagicMock()
        mock_mesh.vertices = [(0, 0, 0), (1, 0, 0), (0, 1, 0)]
        mock_mesh.bounds = [[0, 0, 0], [1, 1, 1]]
        mock_mesh.area = 0.5

        with patch("trimesh.load_mesh", return_value=mock_mesh):
            result = hash_model("dummy.stl")
            assert isinstance(result, str)
            assert len(result) == 16

    def test_hash_fallback(self):
        """When trimesh fails, fall back to file content hash."""
        with patch("trimesh.load_mesh", side_effect=ImportError("no trimesh")):
            with patch("builtins.open", mock_open(read_data=b"STL binary data here")):
                result = hash_model("dummy.stl")
                assert isinstance(result, str)
                assert len(result) == 16

    def test_hash_consistency(self):
        """Same file content should produce same hash."""
        content = b"consistent stl data for testing"
        with patch("trimesh.load_mesh", side_effect=ImportError("no trimesh")):
            with patch("builtins.open", mock_open(read_data=content)):
                h1 = hash_model("dummy.stl")
            with patch("builtins.open", mock_open(read_data=content)):
                h2 = hash_model("dummy.stl")
            assert h1 == h2


# ─── record_feedback ─────────────────────────────────────────────

class TestRecordFeedback:
    def test_record_minimal(self, tmp_data_dir):
        """Minimal call with just mesh_path and quality_score."""
        with patch("supportsage.learning.feedback.hash_model", return_value="testhash001"):
            record = record_feedback(
                mesh_path="model.stl",
                quality_score=75.0,
                data_dir=tmp_data_dir,
            )
        assert record.model_hash == "testhash001"
        assert record.model_name == "model.stl"
        assert record.quality_score == 75.0
        assert record.printer == "unknown"
        assert record.material == "PLA"

    def test_record_full(self, sample_config, tmp_data_dir):
        with patch("supportsage.learning.feedback.hash_model", return_value="fullhash"):
            record = record_feedback(
                mesh_path="benchmark.stl",
                quality_score=92.0,
                support_config=sample_config,
                printer="prusa_mk4",
                material="PETG",
                user_rating=5,
                defects={"warping": 1.5, "layer_shift": 0.5},
                duration_min=180.0,
                notes="Excellent quality",
                data_dir=tmp_data_dir,
            )
        assert record.model_hash == "fullhash"
        assert record.printer == "prusa_mk4"
        assert record.material == "PETG"
        assert record.user_rating == 5
        assert record.duration_min == 180.0
        assert record.support_config.strategy == "balanced"

    def test_record_is_persisted(self, tmp_data_dir):
        with patch("supportsage.learning.feedback.hash_model", return_value="persisthash"):
            record_feedback(
                mesh_path="model.stl",
                quality_score=80.0,
                data_dir=tmp_data_dir,
            )
        # Load it back
        loaded = load_feedback(tmp_data_dir)
        assert loaded.count() == 1
        assert loaded.records[0].quality_score == 80.0

    def test_record_appends(self, tmp_data_dir):
        with patch("supportsage.learning.feedback.hash_model", return_value="multi"):
            for i in range(3):
                record_feedback(
                    mesh_path="model.stl",
                    quality_score=70.0 + i * 10,
                    data_dir=tmp_data_dir,
                )
        loaded = load_feedback(tmp_data_dir)
        assert loaded.count() == 3

    def test_record_clamps_negative_quality(self, tmp_data_dir):
        """quality_score below 0 should be clamped to 0."""
        with patch("supportsage.learning.feedback.hash_model", return_value="clampneg"):
            record = record_feedback(
                mesh_path="model.stl",
                quality_score=-50.0,
                data_dir=tmp_data_dir,
            )
        assert record.quality_score == 0.0

    def test_record_clamps_over_100_quality(self, tmp_data_dir):
        """quality_score above 100 should be clamped to 100."""
        with patch("supportsage.learning.feedback.hash_model", return_value="clampovr"):
            record = record_feedback(
                mesh_path="model.stl",
                quality_score=150.0,
                data_dir=tmp_data_dir,
            )
        assert record.quality_score == 100.0

    def test_record_clamps_boundary_low(self, tmp_data_dir):
        """quality_score of 0 should stay 0 (boundary)."""
        with patch("supportsage.learning.feedback.hash_model", return_value="clampbdl"):
            record = record_feedback(
                mesh_path="model.stl",
                quality_score=0.0,
                data_dir=tmp_data_dir,
            )
        assert record.quality_score == 0.0

    def test_record_clamps_boundary_high(self, tmp_data_dir):
        """quality_score of 100 should stay 100 (boundary)."""
        with patch("supportsage.learning.feedback.hash_model", return_value="clampbdh"):
            record = record_feedback(
                mesh_path="model.stl",
                quality_score=100.0,
                data_dir=tmp_data_dir,
            )
        assert record.quality_score == 100.0


# ─── best_config_for ─────────────────────────────────────────────

class TestBestConfigFor:
    def test_no_data_returns_none(self, tmp_data_dir):
        result = best_config_for(printer="bambu_x1c", data_dir=tmp_data_dir)
        assert result is None

    def test_best_config_for_printer(self, filled_db, tmp_data_dir):
        save_feedback(filled_db, tmp_data_dir)
        result = best_config_for(printer="bambu_x1c", data_dir=tmp_data_dir)
        assert result is not None
        assert isinstance(result, SupportConfig)

    def test_best_config_for_material(self, filled_db, tmp_data_dir):
        save_feedback(filled_db, tmp_data_dir)
        result = best_config_for(material="PETG", data_dir=tmp_data_dir)
        assert result is not None

    def test_best_config_no_match(self, filled_db, tmp_data_dir):
        save_feedback(filled_db, tmp_data_dir)
        result = best_config_for(printer="nonexistent", data_dir=tmp_data_dir)
        assert result is None

    def test_best_config_empty_printer_material(self, filled_db, tmp_data_dir):
        """Both printer and material empty should consider all records."""
        save_feedback(filled_db, tmp_data_dir)
        result = best_config_for(data_dir=tmp_data_dir)
        assert result is not None


# ─── print_feedback_summary ──────────────────────────────────────

class TestPrintFeedbackSummary:
    def test_empty_db(self, tmp_data_dir):
        summary = print_feedback_summary(tmp_data_dir)
        assert "Total prints: 0" in summary
        assert "Avg quality:  0.0" in summary

    def test_with_data(self, filled_db, tmp_data_dir):
        save_feedback(filled_db, tmp_data_dir)
        summary = print_feedback_summary(tmp_data_dir)
        assert "Total prints: 6" in summary
        assert "By Material" in summary
        assert "By Printer" in summary
        assert "Recent" in summary

    def test_summary_includes_scores(self, filled_db, tmp_data_dir):
        save_feedback(filled_db, tmp_data_dir)
        summary = print_feedback_summary(tmp_data_dir)
        avg = filled_db.avg_quality()
        assert f"{avg:.1f}/100" in summary
