"""Tests for supportsage.learning.optimizer module."""
import json
import os
from unittest.mock import patch, MagicMock

import pytest

from supportsage.learning.optimizer import (
    LearnedParams,
    StrategyOptimizer,
    analyze_model_for_learning,
)
from supportsage.learning.feedback import (
    SupportConfig, PrintFeedback, FeedbackDB, save_feedback,
)


# ─── LearnedParams ───────────────────────────────────────────────

class TestLearnedParams:
    def test_default_values(self):
        params = LearnedParams.defaults()
        assert params.critical_angle == 120.0
        assert params.moderate_angle == 70.0
        assert params.borderline_angle == 45.0
        assert params.critical_density == 1.0
        assert params.confidence == 0.0
        assert params.prefer_tree_support is True

    def test_to_dict(self):
        params = LearnedParams.defaults()
        d = params.to_dict()
        assert d["critical_angle"] == 120.0
        assert d["confidence"] == 0.0

    def test_from_dict(self):
        d = {
            "critical_angle": 130.0,
            "moderate_angle": 75.0,
            "confidence": 0.5,
            "extra_field": "ignored",
        }
        params = LearnedParams.from_dict(d)
        assert params.critical_angle == 130.0
        assert params.confidence == 0.5
        assert not hasattr(params, "extra_field")

    def test_from_dict_partial(self):
        """Only provided fields should override defaults."""
        params = LearnedParams.from_dict({"critical_angle": 140.0})
        assert params.critical_angle == 140.0
        assert params.moderate_angle == 70.0  # default


# ─── StrategyOptimizer — learn() ─────────────────────────────────

class TestStrategyOptimizerLearn:
    def test_init_with_default_data_dir(self):
        opt = StrategyOptimizer()
        assert "supportsage" in opt.data_dir

    def test_init_with_custom_data_dir(self, tmp_data_dir):
        opt = StrategyOptimizer(data_dir=tmp_data_dir)
        assert opt.data_dir == tmp_data_dir

    def test_learn_with_no_data_returns_low_confidence(self, tmp_data_dir):
        opt = StrategyOptimizer(data_dir=tmp_data_dir)
        params = opt.learn()
        assert params.confidence == 0.0  # 0 data points / 3.0
        assert params.critical_angle == 120.0  # defaults

    def test_learn_with_one_record(self, tmp_data_dir):
        _seed_data(tmp_data_dir, 1)
        opt = StrategyOptimizer(data_dir=tmp_data_dir)
        params = opt.learn()
        assert params.confidence == pytest.approx(1.0 / 3.0)

    def test_learn_with_enough_data_adjusts_angles(self, tmp_data_dir):
        _seed_data(tmp_data_dir, 10)
        opt = StrategyOptimizer(data_dir=tmp_data_dir)
        params = opt.learn()
        # With 10 data points, angles should have shifted from defaults
        assert params.critical_angle != 120.0 or params.moderate_angle != 70.0
        assert params.confidence > 0.0

    def test_learn_with_printer_filter(self, tmp_data_dir):
        _seed_data(tmp_data_dir, 10)
        opt = StrategyOptimizer(data_dir=tmp_data_dir)
        params = opt.learn(printer="bambu_x1c")
        assert params.confidence > 0.0

    def test_learn_with_printer_no_match(self, tmp_data_dir):
        _seed_data(tmp_data_dir, 10)
        opt = StrategyOptimizer(data_dir=tmp_data_dir)
        params = opt.learn(printer="nonexistent_printer")
        assert params.confidence == 0.1

    def test_learn_with_material_filter(self, tmp_data_dir):
        _seed_data(tmp_data_dir, 10)
        opt = StrategyOptimizer(data_dir=tmp_data_dir)
        params = opt.learn(material="PLA")
        assert params.confidence > 0.0

    def test_learn_prefers_tree_when_high_quality_trees(self, tmp_data_dir):
        """If high-quality prints use tree supports, prefer_tree_support should be True."""
        _seed_data(tmp_data_dir, 10, all_trees=True)
        opt = StrategyOptimizer(data_dir=tmp_data_dir)
        params = opt.learn()
        assert params.prefer_tree_support is True

    def test_learn_confidence_scales_with_data(self, tmp_data_dir):
        _seed_data(tmp_data_dir, 5)
        opt_5 = StrategyOptimizer(data_dir=tmp_data_dir)
        c5 = opt_5.learn().confidence

        _seed_data(tmp_data_dir, 15)  # add more
        opt_20 = StrategyOptimizer(data_dir=tmp_data_dir)
        c20 = opt_20.learn().confidence

        assert c20 > c5

    def test_learn_with_no_quality_scores(self, tmp_data_dir):
        """If all quality scores are 0, should return low confidence."""
        db = FeedbackDB()
        for i in range(5):
            db.add(PrintFeedback(
                model_hash=f"z{i:04x}",
                model_name=f"z{i}.stl",
                quality_score=0.0,
                support_config=SupportConfig(),
            ))
        save_feedback(db, tmp_data_dir)
        opt = StrategyOptimizer(data_dir=tmp_data_dir)
        params = opt.learn()
        assert params.confidence == 0.2  # special case for zero scores

    def test_learn_uses_calibrated_params(self, tmp_data_dir):
        """If printer has calibrated branch_radius, optimizer should use it."""
        _seed_data(tmp_data_dir, 10)
        # Manually set calibrated param
        from supportsage.learning.profile import ProfileManager
        pm = ProfileManager(data_dir=tmp_data_dir)
        pm.calibrate_from_feedback("bambu_x1c", "PLA", 90.0, {"branch_radius": 0.7})

        opt = StrategyOptimizer(data_dir=tmp_data_dir)
        params = opt.learn(printer="bambu_x1c")
        assert params.branch_radius_critical == pytest.approx(0.7)


# ─── StrategyOptimizer — suggest_config() ────────────────────────

class TestStrategyOptimizerSuggest:
    def test_suggest_with_no_data_returns_defaults(self, tmp_data_dir):
        opt = StrategyOptimizer(data_dir=tmp_data_dir)
        config = opt.suggest_config()
        assert isinstance(config, SupportConfig)
        assert config.angle_threshold == 45.0  # borderline_angle default

    def test_suggest_strategy_heavy(self, tmp_data_dir):
        """Very high critical_density should suggest 'heavy' strategy."""
        # Seed data with heavy-support prints
        _seed_data(tmp_data_dir, 10, strategy="heavy")
        opt = StrategyOptimizer(data_dir=tmp_data_dir)
        config = opt.suggest_config()
        # May or may not be heavy depending on learned density
        assert isinstance(config, SupportConfig)

    def test_suggest_with_high_confidence_uses_best_config(self, tmp_data_dir):
        """When confidence > 0.5 and a best config exists, use it."""
        _seed_data(tmp_data_dir, 20)
        opt = StrategyOptimizer(data_dir=tmp_data_dir)
        config = opt.suggest_config(printer="bambu_x1c", material="PLA")
        assert isinstance(config, SupportConfig)

    def test_suggest_returns_valid_config(self, tmp_data_dir):
        _seed_data(tmp_data_dir, 8)
        opt = StrategyOptimizer(data_dir=tmp_data_dir)
        config = opt.suggest_config()
        assert config.angle_threshold > 0
        assert config.branch_radius > 0
        assert config.support_type in ("tree", "pillar")
        assert config.strategy in ("light", "balanced", "heavy")


# ─── StrategyOptimizer — report() ────────────────────────────────

class TestStrategyOptimizerReport:
    def test_report_empty(self, tmp_data_dir):
        opt = StrategyOptimizer(data_dir=tmp_data_dir)
        report = opt.report()
        assert "SupportSage Learning Engine" in report
        assert "Confidence:" in report
        assert "Data points: 0" in report

    def test_report_with_data(self, tmp_data_dir):
        _seed_data(tmp_data_dir, 10)
        opt = StrategyOptimizer(data_dir=tmp_data_dir)
        report = opt.report()
        assert "Data points: 10" in report
        assert "Critical" in report
        assert "Moderate" in report
        assert "Borderline" in report

    def test_report_with_context(self, tmp_data_dir):
        _seed_data(tmp_data_dir, 10)
        opt = StrategyOptimizer(data_dir=tmp_data_dir)
        report = opt.report(printer="bambu_x1c", material="PLA")
        assert "bambu_x1c / PLA" in report

    def test_report_low_confidence_hint(self, tmp_data_dir):
        opt = StrategyOptimizer(data_dir=tmp_data_dir)
        report = opt.report()
        assert "Low confidence" in report
        assert "keep printing" in report

    def test_report_high_confidence_no_hint(self, tmp_data_dir):
        _seed_data(tmp_data_dir, 20)
        opt = StrategyOptimizer(data_dir=tmp_data_dir)
        report = opt.report()
        assert "Low confidence" not in report


# ─── analyze_model_for_learning ──────────────────────────────────

class TestAnalyzeModel:
    def test_analyze_with_mock_analyzer(self, tmp_data_dir):
        """Test with a mocked analyzer module."""
        mock_mesh = MagicMock()
        mock_mesh.vertices = [(0, 0, 0), (1, 0, 0), (0, 1, 0), (1, 1, 0)]

        with (
            patch("supportsage.analyzer.load_stl") as mock_load_stl,
            patch("supportsage.analyzer.detect_overhangs") as mock_detect,
            patch("supportsage.analyzer.classify_overhang_severity") as mock_classify,
            patch("supportsage.analyzer.detect_islands") as mock_islands,
            patch("supportsage.learning.optimizer.load_feedback", return_value=FeedbackDB()),
            patch("supportsage.learning.optimizer.best_config_for", return_value=None),
        ):
            mock_load_stl.return_value = mock_mesh
            mock_detect.return_value = (MagicMock(), MagicMock())
            mock_classify.return_value = {
                "critical": MagicMock(sum=MagicMock(return_value=10)),
                "moderate": MagicMock(sum=MagicMock(return_value=5)),
            }
            mock_islands.return_value = [{"id": 1}, {"id": 2}]

            result = analyze_model_for_learning(
                "test_model.stl",
                printer="bambu_x1c",
                data_dir=tmp_data_dir,
            )

        assert result["model"] == "test_model.stl"
        assert "overhangs" in result
        assert result["overhangs"]["critical"] == 10
        assert result["overhangs"]["islands"] == 2
        assert "suggested_config" in result
        assert result["suggested_config"]["support_type"] in ("tree", "pillar")


# ─── Helpers ────────────────────────────────────────────────────

def _seed_data(data_dir: str, count: int, strategy: str = "balanced", all_trees: bool = False):
    """Seed feedback data for testing."""
    db = FeedbackDB()
    for i in range(count):
        db.add(PrintFeedback(
            model_hash=f"h{i:04x}",
            model_name=f"part_{i}.stl",
            support_config=SupportConfig(
                angle_threshold=45.0 + (i % 5) * 5,
                strategy=strategy,
                support_type="tree" if (all_trees or i % 2 == 0) else "pillar",
                branch_radius=1.0 + i * 0.1,
            ),
            quality_score=70.0 + (i % 5) * 5,
            printer="bambu_x1c" if i % 2 == 0 else "prusa_mk4",
            material="PLA" if i < count / 2 else "PETG",
        ))
    save_feedback(db, data_dir)
