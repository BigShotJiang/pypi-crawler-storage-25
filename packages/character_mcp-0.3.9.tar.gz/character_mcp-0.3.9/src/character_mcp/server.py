from __future__ import annotations

import argparse
import os
import time
from dataclasses import asdict
from pathlib import Path
from typing import Any, Callable

from mcp.server.fastmcp import FastMCP

from .debug_log import DebugLog
from .service import CharacterService
from .trace import ToolTrace
from .watcher import PollingEntityWatcher
from .version import __version__, format_build_info, get_build_info

DEFAULT_SERVER_NAME = "Character MCP"
ENV_ROOT = "CHARACTER_MCP_ROOT"
ENV_TRANSPORT = "CHARACTER_MCP_TRANSPORT"
ENV_WATCH = "CHARACTER_MCP_WATCH"
ENV_WATCH_INTERVAL = "CHARACTER_MCP_WATCH_INTERVAL"
ENV_OPENCLAW_CONFIG = "CHARACTER_MCP_OPENCLAW_CONFIG"
ENV_DEBUG_LOG = "CHARACTER_MCP_DEBUG_LOG"
ENV_LOG_LEVEL = "CHARACTER_MCP_LOG_LEVEL"


class CharacterMCPRuntime:
    def __init__(self, server: FastMCP, service: CharacterService, watcher: PollingEntityWatcher | None, trace: ToolTrace, debug_log: DebugLog):
        self.server = server
        self.service = service
        self.watcher = watcher
        self.trace = trace
        self.debug_log = debug_log


def resolve_root(explicit_root: str | Path | None = None) -> Path:
    if explicit_root is not None:
        return Path(explicit_root).expanduser().resolve()

    env_root = os.getenv(ENV_ROOT)
    if env_root:
        return Path(env_root).expanduser().resolve()

    raise ValueError(f"Character data root is required via argument or {ENV_ROOT}")


def build_runtime(
    root: str | Path,
    name: str = DEFAULT_SERVER_NAME,
    *,
    watch: bool = False,
    watch_interval: float = 1.0,
    openclaw_config_path: str | Path | None = None,
    debug_log: bool = False,
    log_level: str = "info",
) -> CharacterMCPRuntime:
    service = CharacterService(root, openclaw_config_path=openclaw_config_path)
    watcher = PollingEntityWatcher(service, interval=watch_interval) if watch else None
    trace = ToolTrace(root)
    dlog = DebugLog(enabled=debug_log, level=log_level, root=root)
    server = FastMCP(
        name=f"{name} v{__version__}",
        instructions=(
            "Serve structured character, place, and object data from a filesystem root.\n\n"
            "Session startup: call get_visual_profile(entity_id) first — the response includes available_facets, "
            "the full list of facets for that entity. Use available_facets to select scene-relevant facets "
            "(outfit-*, ritual-*, location-specific) before fetching by name. "
            "Call get_entity_summary(entity_id) for the relationship manifest and contextual hints.\n\n"
            "available_facets is also included in every get_entity_facet response, so discovery is always one step away. "
            "For objects and places, get_entity_facet responses include owned_by with a hint to call "
            "get_visual_profile on the owning character before generating images.\n\n"
            "Entity and facet IDs are exact kebab-case: 'dara-of-chaos' not 'dara', 'coffee-shop-look' not 'coffee_shop_look'."
        ),
    )

    def call_with_trace(tool_name: str, arguments: dict[str, Any], fn: Callable[[], Any]) -> Any:
        t0 = time.monotonic()
        try:
            result = fn()
            duration_ms = (time.monotonic() - t0) * 1000
            trace.log(tool=tool_name, status="ok", arguments=arguments, result=result)
            dlog.record(tool_name, arguments, result=result, duration_ms=duration_ms)
            return result
        except Exception as exc:
            duration_ms = (time.monotonic() - t0) * 1000
            trace.log(tool=tool_name, status="error", arguments=arguments, error=str(exc))
            dlog.record(tool_name, arguments, error=str(exc), duration_ms=duration_ms)
            raise

    @server.tool(description="Report whether the configured character root is empty and what the next comfortable setup actions are.", structured_output=True)
    def get_dataset_status() -> dict[str, Any]:
        return call_with_trace(
            "get_dataset_status",
            {},
            lambda: service.get_dataset_status(),
        )

    @server.tool(description="Initialize an empty character root with the basic folders and starter README.", structured_output=True)
    def initialize_character_root() -> dict[str, Any]:
        def run() -> dict[str, Any]:
            result = service.initialize_character_root()
            if watcher is not None:
                watcher._snapshot = watcher._take_snapshot()
            return result

        return call_with_trace("initialize_character_root", {}, run)

    @server.tool(description="Start importing an already-known character into the dataset as a gradual, confirmable intake flow.", structured_output=True)
    def start_existing_character_import(character_id: str, name: str, summary: str | None = None) -> dict[str, Any]:
        def run() -> dict[str, Any]:
            result = service.start_existing_character_import(character_id, name, summary=summary)
            if watcher is not None:
                watcher._snapshot = watcher._take_snapshot()
            return result

        return call_with_trace(
            "start_existing_character_import",
            {"character_id": character_id, "name": name, "summary": summary},
            run,
        )

    @server.tool(description="Return the running Character MCP package version and build commit.", structured_output=True)
    def get_server_build_info() -> dict[str, Any]:
        return call_with_trace(
            "get_server_build_info",
            {},
            lambda: get_build_info(),
        )

    @server.tool(description="List known entities, optionally filtered by type.", structured_output=True)
    def list_entities(entity_type: str | None = None) -> list[dict[str, Any]]:
        return call_with_trace(
            "list_entities",
            {"entity_type": entity_type},
            lambda: [asdict(entity) for entity in service.list_entities(entity_type=entity_type)],
        )

    @server.tool(description="Get the summary metadata for one entity, including relationship manifest, available facets, and contextual hints for next steps.", structured_output=True)
    def get_entity_summary(entity_id: str) -> dict[str, Any]:
        def run() -> dict[str, Any]:
            result = asdict(service.get_entity_summary(entity_id))
            hints = service.get_entity_hints(entity_id)
            if hints:
                result["hints"] = hints
            return result
        return call_with_trace("get_entity_summary", {"entity_id": entity_id}, run)

    @server.tool(description="List the available markdown facets for one entity. Note: available_facets is already included in get_visual_profile and get_entity_facet responses — use this tool for maintenance or explicit listing only.", structured_output=True)
    def list_entity_facets(entity_id: str) -> list[str]:
        return call_with_trace(
            "list_entity_facets",
            {"entity_id": entity_id},
            lambda: service.list_entity_facets(entity_id),
        )

    @server.tool(description="Fetch the full markdown content for one entity facet. Response includes available_facets (all facets for this entity) and, for objects and places, owned_by (the owning character id, name, and a hint to call get_visual_profile before generating images).", structured_output=True)
    def get_entity_facet(entity_id: str, facet: str) -> dict[str, Any]:
        return call_with_trace(
            "get_entity_facet",
            {"entity_id": entity_id, "facet": facet},
            lambda: _facet_payload(service, entity_id, facet),
        )

    @server.tool(description="List the raw outgoing relationships for one entity. Note: the related_entities manifest is already included in get_entity_summary — use this tool for explicit relationship inspection only.", structured_output=True)
    def list_entity_relationships(entity_id: str) -> list[dict[str, Any]]:
        return call_with_trace(
            "list_entity_relationships",
            {"entity_id": entity_id},
            lambda: service.list_entity_relationships(entity_id),
        )

    @server.tool(description="Resolve an entity's outgoing relationships into target summaries. Note: the related_entities manifest is already included in get_entity_summary — use this tool for explicit relationship inspection only.", structured_output=True)
    def get_related_entities(entity_id: str) -> list[dict[str, Any]]:
        return call_with_trace(
            "get_related_entities",
            {"entity_id": entity_id},
            lambda: service.get_related_entities(entity_id),
        )

    @server.tool(description="Return the visual consistency profile for one entity, including canonical image refs and generation hints. Response includes available_facets — use these to select scene-relevant facets (outfit-*, ritual-*, location-specific) before proceeding.", structured_output=True)
    def get_visual_profile(entity_id: str) -> dict[str, Any]:
        return call_with_trace(
            "get_visual_profile",
            {"entity_id": entity_id},
            lambda: service.get_visual_profile(entity_id),
        )

    @server.tool(description="Report what a character still lacks, which facets are weak, and the single best next improvement.", structured_output=True)
    def get_character_gap_report(entity_id: str) -> dict[str, Any]:
        return call_with_trace(
            "get_character_gap_report",
            {"entity_id": entity_id},
            lambda: service.get_character_gap_report(entity_id),
        )

    @server.tool(description="Inspect a character's current OpenClaw agent binding, behavior hint, and relink metadata.", structured_output=True)
    def get_character_agent_binding(entity_id: str) -> dict[str, Any]:
        return call_with_trace(
            "get_character_agent_binding",
            {"entity_id": entity_id},
            lambda: service.get_character_agent_binding(entity_id),
        )

    @server.tool(description="Validate the configured character root and report issues plus summary counts.", structured_output=True)
    def doctor_entity_index() -> dict[str, Any]:
        return call_with_trace("doctor_entity_index", {}, lambda: _doctor_payload(service))

    @server.tool(description="Scan for recoverable dataset mess such as orphan entity directories and stale facet references. Use apply=true to quarantine/prune them instead of editing files manually.", structured_output=True)
    def cleanup_dataset(apply: bool = False) -> dict[str, Any]:
        def run() -> dict[str, Any]:
            result = service.cleanup_dataset(apply=apply)
            if watcher is not None and apply:
                watcher._snapshot = watcher._take_snapshot()
            return result

        return call_with_trace("cleanup_dataset", {"apply": apply}, run)

    @server.tool(description="Reload the entity index from disk.", structured_output=True)
    def rescan_entities() -> dict[str, Any]:
        def run() -> dict[str, Any]:
            service.rescan()
            if watcher is not None:
                watcher._snapshot = watcher._take_snapshot()
            return {"status": "ok", "entity_count": len(service.list_entities())}

        return call_with_trace("rescan_entities", {}, run)

    @server.tool(description="Create a new entity skeleton with one default markdown facet. Use this instead of creating entity files directly.", structured_output=True)
    def create_entity(
        entity_type: str,
        entity_id: str,
        name: str,
        summary: str | None = None,
        tags: list[str] | None = None,
        status: str | None = None,
    ) -> dict[str, Any]:
        def run() -> dict[str, Any]:
            result = service.create_entity(
                entity_type=entity_type,
                entity_id=entity_id,
                name=name,
                summary=summary,
                tags=tags,
                status=status,
            )
            if watcher is not None:
                watcher._snapshot = watcher._take_snapshot()
            return result

        return call_with_trace(
            "create_entity",
            {
                "entity_type": entity_type,
                "entity_id": entity_id,
                "name": name,
                "summary": summary,
                "tags": tags,
                "status": status,
            },
            run,
        )

    @server.tool(description="Start a draft character intake, seed core facets, and return the single next question plus resume metadata.", structured_output=True)
    def start_character_intake(character_id: str, name: str, agent_id: str | None = None, summary: str | None = None) -> dict[str, Any]:
        def run() -> dict[str, Any]:
            result = service.start_character_intake(character_id, name, agent_id=agent_id, summary=summary)
            if watcher is not None:
                watcher._snapshot = watcher._take_snapshot()
            return result

        return call_with_trace(
            "start_character_intake",
            {"character_id": character_id, "name": name, "agent_id": agent_id, "summary": summary},
            run,
        )

    @server.tool(description="Show what a draft character still lacks so the agent can settle it in deliberately.", structured_output=True)
    def get_character_intake_status(entity_id: str) -> dict[str, Any]:
        return call_with_trace(
            "get_character_intake_status",
            {"entity_id": entity_id},
            lambda: service.get_character_intake_status(entity_id),
        )

    @server.tool(description="Return the single next logical intake question so character onboarding can stay gradual and resumable.", structured_output=True)
    def get_character_intake_next_step(entity_id: str) -> dict[str, Any]:
        return call_with_trace(
            "get_character_intake_next_step",
            {"entity_id": entity_id},
            lambda: service.get_character_intake_next_step(entity_id),
        )

    @server.tool(description="Suggest the next best guided questions for settling a character into something real.", structured_output=True)
    def suggest_next_character_questions(entity_id: str) -> list[str]:
        return call_with_trace(
            "suggest_next_character_questions",
            {"entity_id": entity_id},
            lambda: service.suggest_next_character_questions(entity_id),
        )

    @server.tool(description="Apply one or many intake answers to a draft character in one validated write.", structured_output=True)
    def apply_character_intake_answers(entity_id: str, answers: dict[str, Any]) -> dict[str, Any]:
        def run() -> dict[str, Any]:
            result = service.apply_character_intake_answers(entity_id, answers)
            if watcher is not None:
                watcher._snapshot = watcher._take_snapshot()
            return result

        return call_with_trace(
            "apply_character_intake_answers",
            {"entity_id": entity_id, "answers": answers},
            run,
        )

    @server.tool(description="Link a character to an existing OpenClaw agent ID from the current OpenClaw config, optionally with a behavior hint.", structured_output=True)
    def link_character_agent(entity_id: str, agent_id: str, behavior_hint: str | None = None) -> dict[str, Any]:
        def run() -> dict[str, Any]:
            result = service.link_character_agent(entity_id, agent_id, behavior_hint=behavior_hint)
            if watcher is not None:
                watcher._snapshot = watcher._take_snapshot()
            return result

        return call_with_trace("link_character_agent", {"entity_id": entity_id, "agent_id": agent_id, "behavior_hint": behavior_hint}, run)

    @server.tool(description="Update a limited set of top-level entity.yaml fields. Use this instead of editing entity.yaml directly.", structured_output=True)
    def update_entity_yaml(entity_id: str, changes: dict[str, Any]) -> dict[str, Any]:
        def run() -> dict[str, Any]:
            result = service.update_entity_yaml(entity_id, changes)
            if watcher is not None:
                watcher._snapshot = watcher._take_snapshot()
            return result

        return call_with_trace("update_entity_yaml", {"entity_id": entity_id, "changes": changes}, run)

    @server.tool(description="Create or overwrite one markdown facet for an entity. Use this instead of editing facet files directly.", structured_output=True)
    def write_entity_facet(entity_id: str, facet: str, content: str) -> dict[str, Any]:
        def run() -> dict[str, Any]:
            result = service.write_entity_facet(entity_id, facet, content)
            if watcher is not None:
                watcher._snapshot = watcher._take_snapshot()
            return result

        return call_with_trace(
            "write_entity_facet",
            {"entity_id": entity_id, "facet": facet, "content": content},
            run,
        )

    @server.tool(description="Add one relationship entry to an entity and validate the result. Use this instead of editing relationship arrays directly.", structured_output=True)
    def add_relationship(
        entity_id: str,
        target_id: str,
        kind: str,
        status: str | None = None,
        notes: str | None = None,
    ) -> dict[str, Any]:
        def run() -> dict[str, Any]:
            result = service.add_relationship(
                entity_id,
                target_id=target_id,
                kind=kind,
                status=status,
                notes=notes,
            )
            if watcher is not None:
                watcher._snapshot = watcher._take_snapshot()
            return result

        return call_with_trace(
            "add_relationship",
            {
                "entity_id": entity_id,
                "target_id": target_id,
                "kind": kind,
                "status": status,
                "notes": notes,
            },
            run,
        )

    @server.tool(description="Append one alias to an entity without rewriting the alias list by hand.", structured_output=True)
    def append_entity_alias(entity_id: str, alias: str) -> dict[str, Any]:
        def run() -> dict[str, Any]:
            result = service.append_entity_alias(entity_id, alias)
            if watcher is not None:
                watcher._snapshot = watcher._take_snapshot()
            return result

        return call_with_trace("append_entity_alias", {"entity_id": entity_id, "alias": alias}, run)

    @server.tool(
        description=(
            "Add an image or audio asset to an entity. "
            "Provide local_path (file copied into the dataset), url (downloaded locally by default), or both. "
            "When only url is provided, the file is downloaded locally and stored as a dual ref (local copy + url provenance). "
            "Set remote_only=True to store the url without downloading — use this for very large files or consciously external resources. "
            "Files over 500 MB require confirm_large=True. "
            "asset_id is auto-generated from the filename if not provided; collisions are resolved with a numeric suffix. "
            "Response includes a hint when a ref is stored as remote-only."
        ),
        structured_output=True,
    )
    def add_asset_reference(
        entity_id: str,
        bucket: str,
        local_path: str | None = None,
        url: str | None = None,
        remote_only: bool = False,
        label: str | None = None,
        kind: str | None = None,
        tags: list[str] | None = None,
        asset_id: str | None = None,
        confirm_large: bool = False,
    ) -> dict[str, Any]:
        def run() -> dict[str, Any]:
            result = service.add_asset_reference(
                entity_id,
                bucket=bucket,
                local_path=local_path,
                url=url,
                remote_only=remote_only,
                label=label,
                kind=kind,
                tags=tags,
                asset_id=asset_id,
                confirm_large=confirm_large,
            )
            if watcher is not None:
                watcher._snapshot = watcher._take_snapshot()
            return result

        return call_with_trace(
            "add_asset_reference",
            {
                "entity_id": entity_id,
                "bucket": bucket,
                "local_path": local_path,
                "url": url,
                "remote_only": remote_only,
                "label": label,
                "kind": kind,
                "tags": tags,
                "asset_id": asset_id,
                "confirm_large": confirm_large,
            },
            run,
        )

    @server.tool(
        description=(
            "Download a remote-only asset ref into the dataset and update it to a dual ref (local copy + url provenance). "
            "Use when an asset was registered with remote_only=True or as a URL-only ref. "
            "Files over 500 MB require confirm_large=True. "
            "If the download fails the ref is left unchanged."
        ),
        structured_output=True,
    )
    def localize_asset_reference(
        entity_id: str,
        asset_id: str,
        confirm_large: bool = False,
    ) -> dict[str, Any]:
        def run() -> dict[str, Any]:
            result = service.localize_asset_reference(
                entity_id,
                asset_id=asset_id,
                confirm_large=confirm_large,
            )
            if watcher is not None:
                watcher._snapshot = watcher._take_snapshot()
            return result

        return call_with_trace(
            "localize_asset_reference",
            {"entity_id": entity_id, "asset_id": asset_id, "confirm_large": confirm_large},
            run,
        )

    @server.tool(description="Set canonical image refs and generation hints for consistent image generation without editing raw YAML.", structured_output=True)
    def update_visual_profile(
        entity_id: str,
        canonical_image_ids: list[str] | None = None,
        optional_image_ids: list[str] | None = None,
        preferred_models: list[str] | None = None,
        default_seed: int | None = None,
        prompt_notes: str | None = None,
        negative_prompt: str | None = None,
        lora_refs: list[dict[str, Any]] | None = None,
    ) -> dict[str, Any]:
        def run() -> dict[str, Any]:
            result = service.update_visual_profile(
                entity_id,
                canonical_image_ids=canonical_image_ids,
                optional_image_ids=optional_image_ids,
                preferred_models=preferred_models,
                default_seed=default_seed,
                prompt_notes=prompt_notes,
                negative_prompt=negative_prompt,
                lora_refs=lora_refs,
            )
            if watcher is not None:
                watcher._snapshot = watcher._take_snapshot()
            return result

        return call_with_trace(
            "update_visual_profile",
            {
                "entity_id": entity_id,
                "canonical_image_ids": canonical_image_ids,
                "optional_image_ids": optional_image_ids,
                "preferred_models": preferred_models,
                "default_seed": default_seed,
                "prompt_notes": prompt_notes,
                "negative_prompt": negative_prompt,
                "lora_refs": lora_refs,
            },
            run,
        )

    return CharacterMCPRuntime(server=server, service=service, watcher=watcher, trace=trace, debug_log=dlog)


def build_server(root: str | Path, name: str = DEFAULT_SERVER_NAME) -> FastMCP:
    return build_runtime(root, name=name).server


def _facet_payload(service: CharacterService, entity_id: str, facet: str) -> dict[str, Any]:
    document = service.get_entity_facet(entity_id, facet)
    entity = service.get_entity_summary(entity_id)
    payload: dict[str, Any] = {
        "entity_id": document.entity_id,
        "facet": document.facet,
        "path": str(document.path),
        "content": document.content,
        "available_facets": service.list_entity_facets(entity_id),
    }
    if entity.type != "character":
        owner_refs = service.get_character_owner_refs(entity_id)
        if owner_refs:
            payload["owned_by"] = owner_refs
    return payload


def _doctor_payload(service: CharacterService) -> dict[str, Any]:
    report = service.doctor_report()
    payload: dict[str, Any] = {
        "entity_count": report.entity_count,
        "load_error_count": report.load_error_count,
        "issue_count": report.issue_count,
        "error_count": report.error_count,
        "warning_count": report.warning_count,
        "issues": [
            {
                "level": issue.level,
                "entity_id": issue.entity_id,
                "file": str(issue.file) if issue.file else None,
                "code": issue.code,
                "message": issue.message,
            }
            for issue in report.issues
        ],
    }
    if report.issue_count > 0:
        payload["hint"] = "Run cleanup_dataset(apply=true) to fix recoverable issues automatically."
    return payload


def _env_bool(name: str, default: bool = False) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


def _env_float(name: str, default: float) -> float:
    value = os.getenv(name)
    if value is None:
        return default
    return float(value)


def main() -> None:
    parser = argparse.ArgumentParser(prog="character-mcp-server")
    parser.add_argument("--version", action="version", version=f"%(prog)s {format_build_info()}")
    parser.parse_args()

    root = resolve_root()
    transport = os.getenv(ENV_TRANSPORT, "stdio")
    runtime = build_runtime(
        root,
        watch=_env_bool(ENV_WATCH, default=False),
        watch_interval=_env_float(ENV_WATCH_INTERVAL, default=1.0),
        openclaw_config_path=os.getenv(ENV_OPENCLAW_CONFIG),
        debug_log=_env_bool(ENV_DEBUG_LOG, default=False),
        log_level=os.getenv(ENV_LOG_LEVEL, "info"),
    )

    if runtime.watcher is not None:
        runtime.watcher.start()

    try:
        runtime.server.run(transport=transport)
    finally:
        if runtime.watcher is not None:
            runtime.watcher.stop()
