from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

VALID_ENTITY_TYPES = {"character", "place", "object"}
REQUIRED_FIELDS_BY_TYPE = {
    "character": {"id", "type", "name", "status"},
    "place": {"id", "type", "name"},
    "object": {"id", "type", "name"},
}
ALLOWED_FACETS_BY_TYPE = {
    "character": None,
    "place": {"profile", "history", "layout", "atmosphere"},
    "object": {"profile", "appearance", "usage", "history"},
}


@dataclass(slots=True)
class AssetRef:
    id: str | None
    path: Path | None = None  # local path; relative to entity_dir when stored in YAML
    url: str | None = None    # remote URL
    label: str | None = None
    kind: str | None = None
    tags: list[str] = field(default_factory=list)


@dataclass(slots=True)
class VisualLoraRef:
    name: str
    path: Path | None = None
    weight: float | None = None
    notes: str | None = None


@dataclass(slots=True)
class VisualProfile:
    canonical_image_ids: list[str] = field(default_factory=list)
    optional_image_ids: list[str] = field(default_factory=list)
    preferred_models: list[str] = field(default_factory=list)
    default_seed: int | None = None
    prompt_notes: str | None = None
    negative_prompt: str | None = None
    lora_refs: list[VisualLoraRef] = field(default_factory=list)


@dataclass(slots=True)
class Relationship:
    target_id: str
    kind: str
    status: str | None = None
    notes: str | None = None


@dataclass(slots=True)
class Entity:
    root: Path
    entity_dir: Path
    entity_file: Path
    schema_version: int | None
    id: str
    type: str
    name: str
    aliases: list[str] = field(default_factory=list)
    status: str | None = None
    tags: list[str] = field(default_factory=list)
    summary: str | None = None
    facets: list[str] = field(default_factory=list)
    files: dict[str, Path] = field(default_factory=dict)
    assets: dict[str, list[AssetRef]] = field(default_factory=dict)
    visual: VisualProfile = field(default_factory=VisualProfile)
    relationships: list[Relationship] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)
    raw: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class ValidationIssue:
    level: str
    entity_id: str | None
    file: Path | None
    code: str
    message: str


@dataclass(slots=True)
class EntityLoadError:
    entity_dir: Path
    entity_file: Path | None
    message: str


@dataclass(slots=True)
class LoadResult:
    entities: list[Entity] = field(default_factory=list)
    errors: list[EntityLoadError] = field(default_factory=list)


@dataclass(slots=True)
class EntitySummary:
    id: str
    type: str
    name: str
    status: str | None
    summary: str | None
    tags: list[str] = field(default_factory=list)
    facets: list[str] = field(default_factory=list)
    related_entities: list[dict[str, Any]] = field(default_factory=list)
    owned_by: list[dict[str, Any]] = field(default_factory=list)


@dataclass(slots=True)
class FacetDocument:
    entity_id: str
    facet: str
    path: Path
    content: str


@dataclass(slots=True)
class DoctorReport:
    entity_count: int
    load_error_count: int
    issue_count: int
    error_count: int
    warning_count: int
    issues: list[ValidationIssue] = field(default_factory=list)
