from __future__ import annotations

import re
import shutil
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import yaml

from .loader import load_entities
from .models import Entity, VALID_ENTITY_TYPES
from .validator import BROAD_CHARACTER_FACETS, FACET_PATTERN, validate_load_result

EDITABLE_ENTITY_KEYS = {"name", "aliases", "status", "tags", "summary", "metadata", "integration"}
INTAKE_EDITABLE_KEYS = {
    "summary",
    "status",
    "aliases",
    "tags",
    "identity",
    "appearance",
    "voice",
    "proposed_identity",
    "agent_id",
    "agent_behavior_hint",
    "home_location_id",
    "home_location",
    "signature_object_id",
    "signature_object",
    "relationships",
    "image_paths",
    "audio_paths",
    "image_refs",
    "audio_refs",
    "canonical_image_ids",
    "optional_image_ids",
    "preferred_models",
    "default_image_seed",
    "image_prompt_notes",
    "negative_image_prompt",
    "lora_refs",
}
COLLECTION_BY_TYPE = {
    "character": "characters",
    "place": "places",
    "object": "objects",
}
DEFAULT_FACET_BY_TYPE = {
    "character": "identity",
    "place": "profile",
    "object": "profile",
}


class WriteError(Exception):
    pass


class DatasetWriter:
    def __init__(self, root: str | Path):
        self.root = Path(root).expanduser().resolve()
        self.backup_root = self.root / ".character-mcp-backups"

    def create_entity(
        self,
        *,
        entity_type: str,
        entity_id: str,
        name: str,
        summary: str | None = None,
        tags: list[str] | None = None,
        status: str | None = None,
    ) -> dict[str, Any]:
        if entity_type not in VALID_ENTITY_TYPES:
            raise WriteError(f"invalid entity type '{entity_type}'")
        if entity_type == "character" and not status:
            raise WriteError("character entities require status")
        if entity_type in {"place", "object"} and not (isinstance(summary, str) and summary.strip()):
            raise WriteError(f"{entity_type} entities require summary")

        collection = COLLECTION_BY_TYPE[entity_type]
        entity_dir = self.root / collection / entity_id
        if entity_dir.exists():
            raise WriteError(f"intake child entity '{entity_id}' already exists")
        entity_file = entity_dir / "entity.yaml"
        default_facet = DEFAULT_FACET_BY_TYPE[entity_type]
        facet_file = entity_dir / f"{default_facet}.md"

        if entity_dir.exists():
            raise WriteError(f"entity '{entity_id}' already exists")

        raw: dict[str, Any] = {
            "schema_version": 1,
            "id": entity_id,
            "type": entity_type,
            "name": name,
            "facets": [default_facet],
            "files": {default_facet: facet_file.name},
            "metadata": {"source": "character-mcp-write-tool"},
        }
        if summary:
            raw["summary"] = summary
        if tags:
            raw["tags"] = tags
        if status:
            raw["status"] = status

        default_markdown = self._default_facet_content(entity_type, name, summary=summary)

        touched = [entity_file, facet_file]
        backup = self._backup_files(touched)
        entity_dir.mkdir(parents=True, exist_ok=True)
        try:
            self._write_yaml(entity_file, raw)
            facet_file.write_text(default_markdown, encoding="utf-8")
            self._validate_or_rollback()
        except Exception:
            self._restore_backup(backup)
            raise

        return {
            "status": "ok",
            "entity_id": entity_id,
            "created": [str(entity_file), str(facet_file)],
            "backup_dir": str(backup["backup_dir"]),
        }

    def update_entity_yaml(self, entity: Entity, changes: dict[str, Any]) -> dict[str, Any]:
        unsupported = sorted(set(changes) - EDITABLE_ENTITY_KEYS)
        if unsupported:
            raise WriteError(f"unsupported editable keys: {', '.join(unsupported)}")

        raw = dict(entity.raw)
        for key, value in changes.items():
            if key in {"aliases", "tags"} and value is not None and not isinstance(value, list):
                raise WriteError(f"{key} must be a list of strings")
            if key in {"metadata", "integration"} and value is not None and not isinstance(value, dict):
                raise WriteError(f"{key} must be a mapping")
            raw[key] = value

        backup = self._backup_files([entity.entity_file])
        try:
            self._write_yaml(entity.entity_file, raw)
            self._validate_or_rollback()
        except Exception:
            self._restore_backup(backup)
            raise

        return {
            "status": "ok",
            "entity_id": entity.id,
            "updated_keys": sorted(changes),
            "backup_dir": str(backup["backup_dir"]),
        }

    def write_entity_facet(self, entity: Entity, facet: str, content: str) -> dict[str, Any]:
        facet = facet.strip()
        if not facet:
            raise WriteError("facet must be non-empty")
        if not FACET_PATTERN.match(facet):
            raise WriteError(f"facet '{facet}' must be kebab-case (lowercase letters, digits, hyphens only)")
        if entity.type == "character" and facet in BROAD_CHARACTER_FACETS:
            raise WriteError(
                f"character facet '{facet}' is too broad; split it into narrower ritual-* or outfit-* files"
            )

        raw = dict(entity.raw)
        raw.setdefault("facets", [])
        raw.setdefault("files", {})
        filename = f"{facet}.md"
        facet_path = entity.entity_dir / filename

        if facet not in raw["facets"]:
            raw["facets"].append(facet)
        raw["files"][facet] = filename

        backup = self._backup_files([entity.entity_file, facet_path])
        try:
            self._write_yaml(entity.entity_file, raw)
            facet_path.write_text(content, encoding="utf-8")
            self._validate_or_rollback()
        except Exception:
            self._restore_backup(backup)
            raise

        return {
            "status": "ok",
            "entity_id": entity.id,
            "facet": facet,
            "path": str(facet_path),
            "backup_dir": str(backup["backup_dir"]),
        }

    def prune_missing_facets(self, entity: Entity, facets: list[str]) -> dict[str, Any]:
        if not facets:
            return {
                "status": "ok",
                "entity_id": entity.id,
                "removed_facets": [],
                "backup_dir": None,
            }

        raw = dict(entity.raw)
        declared_facets = list(raw.get("facets", []))
        files = dict(raw.get("files", {}))
        removed_facets: list[str] = []
        for facet in facets:
            removed = False
            if facet in files:
                files.pop(facet, None)
                removed = True
            if facet in declared_facets:
                declared_facets = [item for item in declared_facets if item != facet]
                removed = True
            if removed and facet not in removed_facets:
                removed_facets.append(facet)

        if "files" in raw or files:
            if files:
                raw["files"] = files
            else:
                raw.pop("files", None)
        if "facets" in raw or declared_facets:
            if declared_facets:
                raw["facets"] = declared_facets
            else:
                raw.pop("facets", None)

        backup = self._backup_files([entity.entity_file])
        try:
            self._write_yaml(entity.entity_file, raw)
            self._validate_or_rollback()
        except Exception:
            self._restore_backup(backup)
            raise

        return {
            "status": "ok",
            "entity_id": entity.id,
            "removed_facets": removed_facets,
            "backup_dir": str(backup["backup_dir"]),
        }

    def fix_legacy_facet_names(self, entity: Entity) -> dict[str, Any]:
        """Rename underscore facet files to kebab-case and update entity.yaml."""
        renames: list[tuple[Path, Path, str, str]] = []
        raw = dict(entity.raw)
        facets = list(raw.get("facets", []))
        files = dict(raw.get("files", {}))

        for old_facet, path in list(entity.files.items()):
            if FACET_PATTERN.match(old_facet):
                continue
            new_facet = old_facet.replace("_", "-")
            if not FACET_PATTERN.match(new_facet):
                continue  # Cannot auto-fix; skip
            new_filename = f"{new_facet}.md"
            new_path = entity.entity_dir / new_filename
            if old_facet in facets:
                facets[facets.index(old_facet)] = new_facet
            if old_facet in files:
                files.pop(old_facet)
                files[new_facet] = new_filename
            renames.append((path, new_path, old_facet, new_facet))

        if not renames:
            return {"status": "ok", "entity_id": entity.id, "renames": []}

        raw["facets"] = facets
        raw["files"] = files

        backup = self._backup_files([entity.entity_file] + [r[0] for r in renames])
        try:
            for old_path, new_path, _, _ in renames:
                old_path.rename(new_path)
            self._write_yaml(entity.entity_file, raw)
            self._validate_or_rollback()
        except Exception:
            for old_path, new_path, _, _ in renames:
                if new_path.exists() and not old_path.exists():
                    new_path.rename(old_path)
            self._restore_backup(backup)
            raise

        return {
            "status": "ok",
            "entity_id": entity.id,
            "renames": [{"from": r[2], "to": r[3]} for r in renames],
            "backup_dir": str(backup["backup_dir"]),
        }

    def add_relationship(
        self,
        entity: Entity,
        *,
        target_id: str,
        kind: str,
        status: str | None = None,
        notes: str | None = None,
    ) -> dict[str, Any]:
        raw = dict(entity.raw)
        relationships = list(raw.get("relationships", []))
        relationship = {"target_id": target_id, "kind": kind}
        if status:
            relationship["status"] = status
        if notes:
            relationship["notes"] = notes

        if self._relationship_exists(relationships, relationship):
            raise WriteError("relationship already exists for this target and kind")

        relationships.append(relationship)
        raw["relationships"] = relationships

        backup = self._backup_files([entity.entity_file])
        try:
            self._write_yaml(entity.entity_file, raw)
            self._validate_or_rollback()
        except Exception:
            self._restore_backup(backup)
            raise

        return {
            "status": "ok",
            "entity_id": entity.id,
            "relationship": relationship,
            "backup_dir": str(backup["backup_dir"]),
        }

    def append_entity_alias(self, entity: Entity, alias: str) -> dict[str, Any]:
        raw = dict(entity.raw)
        aliases = list(raw.get("aliases", []))
        if alias in aliases:
            raise WriteError("alias already exists")
        aliases.append(alias)
        raw["aliases"] = aliases

        backup = self._backup_files([entity.entity_file])
        try:
            self._write_yaml(entity.entity_file, raw)
            self._validate_or_rollback()
        except Exception:
            self._restore_backup(backup)
            raise

        return {
            "status": "ok",
            "entity_id": entity.id,
            "alias": alias,
            "backup_dir": str(backup["backup_dir"]),
        }

    _LARGE_FILE_BYTES = 500 * 1024 * 1024  # 500 MB

    def add_asset_reference(
        self,
        entity: Entity,
        *,
        bucket: str,
        local_path: str | None = None,
        url: str | None = None,
        remote_only: bool = False,
        label: str | None = None,
        kind: str | None = None,
        tags: list[str] | None = None,
        asset_id: str | None = None,
        confirm_large: bool = False,
    ) -> dict[str, Any]:
        if not local_path and not url:
            raise WriteError("provide local_path, url, or both")

        entry: dict[str, Any] = {}

        if local_path:
            src = Path(local_path).expanduser().resolve()
            if not src.is_file():
                raise WriteError(f"local_path does not exist or is not a file: {local_path}")
            size = src.stat().st_size
            if size > self._LARGE_FILE_BYTES and not confirm_large:
                return {
                    "status": "confirmation_required",
                    "entity_id": entity.id,
                    "size_bytes": size,
                    "size_mb": round(size / (1024 * 1024), 1),
                    "message": f"File is {round(size / (1024 * 1024), 1)} MB. Re-call with confirm_large=True to proceed.",
                }
            dest_dir = entity.entity_dir / "assets" / bucket
            dest_dir.mkdir(parents=True, exist_ok=True)
            dest_filename = self._safe_asset_filename(src.name, dest_dir)
            dest = dest_dir / dest_filename
            shutil.copy2(str(src), str(dest))
            rel_path = str(dest.relative_to(entity.entity_dir))
            entry["path"] = rel_path
            if url:
                entry["url"] = url

        elif url and not remote_only:
            dest_dir = entity.entity_dir / "assets" / bucket
            dest_dir.mkdir(parents=True, exist_ok=True)
            filename = self._filename_from_url(url)
            dest_filename = self._safe_asset_filename(filename, dest_dir)
            dest = dest_dir / dest_filename
            try:
                urllib.request.urlretrieve(url, dest)
            except Exception as exc:
                if dest.exists():
                    dest.unlink()
                raise WriteError(f"download failed: {exc}") from exc
            size = dest.stat().st_size
            if size > self._LARGE_FILE_BYTES and not confirm_large:
                dest.unlink()
                return {
                    "status": "confirmation_required",
                    "entity_id": entity.id,
                    "size_bytes": size,
                    "size_mb": round(size / (1024 * 1024), 1),
                    "message": f"Downloaded file is {round(size / (1024 * 1024), 1)} MB. Re-call with confirm_large=True to proceed.",
                }
            rel_path = str(dest.relative_to(entity.entity_dir))
            entry["path"] = rel_path
            entry["url"] = url

        else:
            # remote_only
            entry["url"] = url

        generated_id = asset_id or self._asset_id_from_path(local_path or url or "asset")
        resolved_id = self._unique_asset_id(generated_id, entity)
        entry["id"] = resolved_id

        if label:
            entry["label"] = label
        if kind:
            entry["kind"] = kind
        if tags:
            entry["tags"] = tags

        raw = dict(entity.raw)
        assets = dict(raw.get("assets", {}))
        bucket_items = list(assets.get(bucket, []))
        bucket_items.append(entry)
        assets[bucket] = bucket_items
        raw["assets"] = assets

        backup = self._backup_files([entity.entity_file])
        try:
            self._write_yaml(entity.entity_file, raw)
            self._validate_or_rollback()
        except Exception:
            self._restore_backup(backup)
            raise

        result: dict[str, Any] = {
            "status": "ok",
            "entity_id": entity.id,
            "asset": {"bucket": bucket, **entry},
            "backup_dir": str(backup["backup_dir"]),
        }
        if "url" in entry and "path" not in entry:
            result["hint"] = f"This ref is remote-only. Call localize_asset_reference('{entity.id}', '{resolved_id}') to create a local copy."
        return result

    def localize_asset_reference(
        self,
        entity: Entity,
        *,
        asset_id: str,
        confirm_large: bool = False,
    ) -> dict[str, Any]:
        raw = dict(entity.raw)
        assets = dict(raw.get("assets", {}))

        target_bucket: str | None = None
        target_index: int | None = None
        target_item: dict[str, Any] | None = None

        for bucket, items in assets.items():
            for i, item in enumerate(items):
                if item.get("id") == asset_id:
                    target_bucket = bucket
                    target_index = i
                    target_item = dict(item)
                    break
            if target_bucket is not None:
                break

        if target_item is None:
            raise WriteError(f"asset '{asset_id}' not found")
        if "path" in target_item:
            raise WriteError(f"asset '{asset_id}' already has a local path")
        url = target_item.get("url")
        if not url:
            raise WriteError(f"asset '{asset_id}' has no url to download")

        dest_dir = entity.entity_dir / "assets" / target_bucket
        dest_dir.mkdir(parents=True, exist_ok=True)
        filename = self._filename_from_url(url)
        dest_filename = self._safe_asset_filename(filename, dest_dir)
        dest = dest_dir / dest_filename

        try:
            urllib.request.urlretrieve(url, dest)
        except Exception as exc:
            if dest.exists():
                dest.unlink()
            raise WriteError(f"download failed: {exc}") from exc

        size = dest.stat().st_size
        if size > self._LARGE_FILE_BYTES and not confirm_large:
            dest.unlink()
            return {
                "status": "confirmation_required",
                "entity_id": entity.id,
                "asset_id": asset_id,
                "size_bytes": size,
                "size_mb": round(size / (1024 * 1024), 1),
                "message": f"Downloaded file is {round(size / (1024 * 1024), 1)} MB. Re-call with confirm_large=True to proceed.",
            }

        rel_path = str(dest.relative_to(entity.entity_dir))
        target_item["path"] = rel_path
        bucket_items = list(assets[target_bucket])
        bucket_items[target_index] = target_item
        assets[target_bucket] = bucket_items
        raw["assets"] = assets

        backup = self._backup_files([entity.entity_file])
        try:
            self._write_yaml(entity.entity_file, raw)
            self._validate_or_rollback()
        except Exception:
            self._restore_backup(backup)
            if dest.exists():
                dest.unlink()
            raise

        return {
            "status": "ok",
            "entity_id": entity.id,
            "asset": {"bucket": target_bucket, **target_item},
            "local_path": rel_path,
            "backup_dir": str(backup["backup_dir"]),
        }

    @staticmethod
    def _safe_asset_filename(name: str, dest_dir: Path) -> str:
        sanitized = re.sub(r"[^\w.\-]", "-", name).strip("-") or "asset"
        stem = Path(sanitized).stem
        suffix = Path(sanitized).suffix
        candidate = sanitized
        counter = 2
        while (dest_dir / candidate).exists():
            candidate = f"{stem}-{counter}{suffix}"
            counter += 1
        return candidate

    @staticmethod
    def _filename_from_url(url: str) -> str:
        path_part = url.split("?")[0].rstrip("/")
        name = path_part.split("/")[-1]
        return name or "asset"

    @staticmethod
    def _unique_asset_id(base_id: str, entity: Entity) -> str:
        existing = {ref.id for bucket in entity.assets.values() for ref in bucket if ref.id}
        if base_id not in existing:
            return base_id
        counter = 2
        while f"{base_id}-{counter}" in existing:
            counter += 1
        return f"{base_id}-{counter}"

    def update_visual_profile(
        self,
        entity: Entity,
        *,
        canonical_image_ids: list[str] | None = None,
        optional_image_ids: list[str] | None = None,
        preferred_models: list[str] | None = None,
        default_seed: int | None = None,
        prompt_notes: str | None = None,
        negative_prompt: str | None = None,
        lora_refs: list[dict[str, Any]] | None = None,
    ) -> dict[str, Any]:
        raw = dict(entity.raw)
        visual = dict(raw.get("visual", {}))
        if canonical_image_ids is not None:
            visual["canonical_image_ids"] = list(canonical_image_ids)
        if optional_image_ids is not None:
            visual["optional_image_ids"] = list(optional_image_ids)
        if preferred_models is not None:
            visual["preferred_models"] = list(preferred_models)
        if default_seed is not None:
            visual["default_seed"] = default_seed
        if prompt_notes is not None:
            visual["prompt_notes"] = prompt_notes
        if negative_prompt is not None:
            visual["negative_prompt"] = negative_prompt
        if lora_refs is not None:
            visual["lora_refs"] = list(lora_refs)
        raw["visual"] = visual

        backup = self._backup_files([entity.entity_file])
        try:
            self._write_yaml(entity.entity_file, raw)
            self._validate_or_rollback()
        except Exception:
            self._restore_backup(backup)
            raise

        return {
            "status": "ok",
            "entity_id": entity.id,
            "visual": visual,
            "backup_dir": str(backup["backup_dir"]),
        }

    def link_character_agent(self, entity: Entity, agent_id: str, behavior_hint: str | None = None) -> dict[str, Any]:
        raw = dict(entity.raw)
        integration = dict(raw.get("integration", {}))
        openclaw = dict(integration.get("openclaw", {}))
        previous_agent_id = openclaw.get("agent_id")
        if isinstance(previous_agent_id, str) and previous_agent_id and previous_agent_id != agent_id:
            openclaw["previous_agent_id"] = previous_agent_id
        openclaw["agent_id"] = agent_id
        openclaw["last_linked_at"] = datetime.now(timezone.utc).isoformat()
        if behavior_hint is not None:
            openclaw["behavior_hint"] = behavior_hint
        integration["openclaw"] = openclaw
        raw["integration"] = integration

        backup = self._backup_files([entity.entity_file])
        try:
            self._write_yaml(entity.entity_file, raw)
            self._validate_or_rollback()
        except Exception:
            self._restore_backup(backup)
            raise

        return {
            "status": "ok",
            "entity_id": entity.id,
            "agent_id": agent_id,
            "previous_agent_id": previous_agent_id if isinstance(previous_agent_id, str) and previous_agent_id else None,
            "behavior_hint": behavior_hint,
            "backup_dir": str(backup["backup_dir"]),
        }

    def apply_character_intake_answers(self, entity: Entity, answers: dict[str, Any]) -> dict[str, Any]:
        unsupported = sorted(set(answers) - INTAKE_EDITABLE_KEYS)
        if unsupported:
            raise WriteError(f"unsupported intake answer keys: {', '.join(unsupported)}")

        raw = dict(entity.raw)
        touched: list[Path] = [entity.entity_file]
        facet_writes: dict[Path, str] = {}

        if "summary" in answers:
            raw["summary"] = answers["summary"]
        if "status" in answers:
            raw["status"] = answers["status"]
        if "aliases" in answers:
            raw["aliases"] = self._merge_unique_strings(raw.get("aliases"), answers["aliases"], "aliases")
        if "tags" in answers:
            raw["tags"] = self._merge_unique_strings(raw.get("tags"), answers["tags"], "tags")
        if "agent_id" in answers and answers["agent_id"] is not None:
            integration = dict(raw.get("integration", {}))
            openclaw = dict(integration.get("openclaw", {}))
            previous_agent_id = openclaw.get("agent_id")
            if isinstance(previous_agent_id, str) and previous_agent_id and previous_agent_id != answers["agent_id"]:
                openclaw["previous_agent_id"] = previous_agent_id
            openclaw["agent_id"] = answers["agent_id"]
            openclaw["last_linked_at"] = datetime.now(timezone.utc).isoformat()
            if "agent_behavior_hint" in answers:
                openclaw["behavior_hint"] = answers["agent_behavior_hint"]
            integration["openclaw"] = openclaw
            raw["integration"] = integration

        relationships = list(raw.get("relationships", []))
        child_entity_writes: dict[Path, dict[str, Any]] = {}
        child_text_writes: dict[Path, str] = {}

        if answers.get("home_location"):
            child = self._stage_intake_child_entity("place", answers["home_location"], relationship_kind="lives-in")
            touched.extend([child["entity_file"], child["facet_file"]])
            child_entity_writes[child["entity_file"]] = child["raw"]
            child_text_writes[child["facet_file"]] = child["facet_content"]
            self._append_relationship(relationships, {"target_id": child["entity_id"], "kind": "lives-in"})
        elif answers.get("home_location_id"):
            self._append_relationship(
                relationships,
                {"target_id": answers["home_location_id"], "kind": "lives-in"},
            )

        if answers.get("signature_object"):
            child = self._stage_intake_child_entity("object", answers["signature_object"], relationship_kind="uses")
            touched.extend([child["entity_file"], child["facet_file"]])
            child_entity_writes[child["entity_file"]] = child["raw"]
            child_text_writes[child["facet_file"]] = child["facet_content"]
            self._append_relationship(relationships, {"target_id": child["entity_id"], "kind": "uses"})
        elif answers.get("signature_object_id"):
            self._append_relationship(
                relationships,
                {"target_id": answers["signature_object_id"], "kind": "uses"},
            )
        for relationship in answers.get("relationships", []) or []:
            if not isinstance(relationship, dict):
                raise WriteError("relationships must be a list of mappings")
            candidate = {
                "target_id": relationship.get("target_id"),
                "kind": relationship.get("kind"),
            }
            if not candidate["target_id"] or not candidate["kind"]:
                raise WriteError("each relationship requires target_id and kind")
            if relationship.get("status"):
                candidate["status"] = relationship["status"]
            if relationship.get("notes"):
                candidate["notes"] = relationship["notes"]
            self._append_relationship(relationships, candidate)
        if relationships:
            raw["relationships"] = relationships

        assets = dict(raw.get("assets", {}))
        if "image_paths" in answers:
            assets["images"] = self._merge_asset_paths(assets.get("images"), answers["image_paths"], "image_paths")
        if "audio_paths" in answers:
            assets["audio"] = self._merge_asset_paths(assets.get("audio"), answers["audio_paths"], "audio_paths")
        if "image_refs" in answers:
            assets["images"] = self._merge_asset_refs(assets.get("images"), answers["image_refs"], "image_refs")
        if "audio_refs" in answers:
            assets["audio"] = self._merge_asset_refs(assets.get("audio"), answers["audio_refs"], "audio_refs")
        if assets:
            raw["assets"] = assets

        visual = dict(raw.get("visual", {}))
        if "canonical_image_ids" in answers:
            visual["canonical_image_ids"] = self._merge_unique_strings([], answers["canonical_image_ids"], "canonical_image_ids")
        if "optional_image_ids" in answers:
            visual["optional_image_ids"] = self._merge_unique_strings([], answers["optional_image_ids"], "optional_image_ids")
        if "preferred_models" in answers:
            visual["preferred_models"] = self._merge_unique_strings([], answers["preferred_models"], "preferred_models")
        if "default_image_seed" in answers:
            visual["default_seed"] = answers["default_image_seed"]
        if "image_prompt_notes" in answers:
            visual["prompt_notes"] = answers["image_prompt_notes"]
        if "negative_image_prompt" in answers:
            visual["negative_prompt"] = answers["negative_image_prompt"]
        if "lora_refs" in answers:
            visual["lora_refs"] = self._normalize_lora_refs(answers["lora_refs"])
        if visual:
            raw["visual"] = visual

        for answer_key, facet, title in (
            ("identity", "identity", "Identity"),
            ("appearance", "appearance", "Appearance"),
            ("voice", "voice", "Voice"),
            ("proposed_identity", "proposed-identity", "Proposed Identity"),
        ):
            if answer_key not in answers or answers[answer_key] is None:
                continue
            raw.setdefault("facets", [])
            raw.setdefault("files", {})
            filename = f"{facet}.md"
            facet_path = entity.entity_dir / filename
            if facet not in raw["facets"]:
                raw["facets"].append(facet)
            raw["files"][facet] = filename
            touched.append(facet_path)
            facet_writes[facet_path] = self._normalize_markdown_section(title, answers[answer_key])

        backup = self._backup_files(list(dict.fromkeys(touched)))
        try:
            self._write_yaml(entity.entity_file, raw)
            for path, child_raw in child_entity_writes.items():
                self._write_yaml(path, child_raw)
            for path, content in facet_writes.items():
                path.write_text(content, encoding="utf-8")
            for path, content in child_text_writes.items():
                path.write_text(content, encoding="utf-8")
            self._validate_or_rollback()
        except Exception:
            self._restore_backup(backup)
            raise

        return {
            "status": "ok",
            "entity_id": entity.id,
            "updated_sections": sorted(answers),
            "backup_dir": str(backup["backup_dir"]),
        }

    def _validate_or_rollback(self) -> None:
        result = load_entities(self.root)
        issues = validate_load_result(result)
        errors = [issue for issue in issues if issue.level == "error"]
        if errors:
            raise WriteError(
                "validation failed after write: "
                + "; ".join(f"{issue.code}:{issue.message}" for issue in errors)
            )

    def _backup_files(self, paths: list[Path]) -> dict[str, Any]:
        timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S.%fZ")
        backup_dir = self.backup_root / timestamp
        backup_dir.mkdir(parents=True, exist_ok=True)
        entries: list[dict[str, Any]] = []
        for path in paths:
            existed = path.exists()
            backup_path = backup_dir / path.relative_to(self.root)
            if existed:
                backup_path.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(path, backup_path)
            entries.append({"path": path, "existed": existed, "backup_path": backup_path})
        return {"backup_dir": backup_dir, "entries": entries}

    def _restore_backup(self, backup: dict[str, Any]) -> None:
        for entry in backup["entries"]:
            path: Path = entry["path"]
            if entry["existed"]:
                path.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(entry["backup_path"], path)
            elif path.exists():
                path.unlink()
                self._prune_empty_parent_dirs(path.parent)

    @staticmethod
    def _write_yaml(path: Path, raw: dict[str, Any]) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(yaml.safe_dump(raw, sort_keys=False, allow_unicode=False), encoding="utf-8")

    def _prune_empty_parent_dirs(self, start: Path) -> None:
        collection_roots = {self.root / collection for collection in COLLECTION_BY_TYPE.values()}
        current = start
        while current != self.root and current not in collection_roots:
            if not current.exists() or not current.is_dir():
                current = current.parent
                continue
            try:
                next(current.iterdir())
                break
            except StopIteration:
                current.rmdir()
                current = current.parent

    @staticmethod
    def _default_facet_content(entity_type: str, name: str, summary: str | None = None) -> str:
        if entity_type == "character":
            return f"# Identity\n\nDescribe {name} here.\n"
        if isinstance(summary, str) and summary.strip():
            return f"# Profile\n\n{summary.strip()}\n"
        return f"# Profile\n\nDescribe {name} here.\n"


    @staticmethod
    def _merge_unique_strings(existing: Any, incoming: Any, field_name: str) -> list[str]:
        if incoming is None:
            return list(existing or [])
        if not isinstance(incoming, list) or not all(isinstance(item, str) for item in incoming):
            raise WriteError(f"{field_name} must be a list of strings")
        merged = list(existing or [])
        for item in incoming:
            if item not in merged:
                merged.append(item)
        return merged

    @staticmethod
    def _append_relationship(relationships: list[dict[str, Any]], candidate: dict[str, Any]) -> None:
        if not DatasetWriter._relationship_exists(relationships, candidate):
            relationships.append(candidate)

    @staticmethod
    def _relationship_exists(relationships: list[dict[str, Any]], candidate: dict[str, Any]) -> bool:
        return any(
            relationship.get("target_id") == candidate.get("target_id")
            and relationship.get("kind") == candidate.get("kind")
            for relationship in relationships
        )

    def _stage_intake_child_entity(self, entity_type: str, payload: Any, *, relationship_kind: str) -> dict[str, Any]:
        if not isinstance(payload, dict):
            raise WriteError(f"{entity_type} intake payload must be a mapping")
        entity_id = payload.get("id")
        name = payload.get("name")
        if not isinstance(entity_id, str) or not entity_id.strip():
            raise WriteError(f"{entity_type} intake payload requires id")
        if not isinstance(name, str) or not name.strip():
            raise WriteError(f"{entity_type} intake payload requires name")

        entity_id = entity_id.strip()
        name = name.strip()
        collection = COLLECTION_BY_TYPE[entity_type]
        default_facet = DEFAULT_FACET_BY_TYPE[entity_type]
        entity_dir = self.root / collection / entity_id
        if entity_dir.exists():
            raise WriteError(f"intake child entity '{entity_id}' already exists")
        entity_file = entity_dir / "entity.yaml"
        facet_file = entity_dir / f"{default_facet}.md"

        raw: dict[str, Any] = {
            "schema_version": 1,
            "id": entity_id,
            "type": entity_type,
            "name": name,
            "facets": [default_facet],
            "files": {default_facet: facet_file.name},
            "metadata": {"source": "character-mcp-intake"},
        }
        if isinstance(payload.get("summary"), str) and payload["summary"].strip():
            raw["summary"] = payload["summary"].strip()
        if isinstance(payload.get("tags"), list) and all(isinstance(tag, str) for tag in payload["tags"]):
            raw["tags"] = payload["tags"]

        title = "Profile"
        profile = payload.get("profile")
        if not isinstance(profile, str) or not profile.strip():
            raise WriteError(f"{entity_type} intake payload requires profile")
        facet_content = self._normalize_markdown_section(title, profile)

        return {
            "entity_id": entity_id,
            "entity_file": entity_file,
            "facet_file": facet_file,
            "raw": raw,
            "facet_content": facet_content,
            "relationship_kind": relationship_kind,
        }


    @classmethod
    def _merge_asset_paths(cls, existing: Any, paths: Any, field_name: str) -> list[dict[str, Any]]:
        if paths is None:
            return list(existing or [])
        if not isinstance(paths, list) or not all(isinstance(item, str) for item in paths):
            raise WriteError(f"{field_name} must be a list of strings")
        merged = list(existing or [])
        for path in paths:
            candidate = {"id": cls._asset_id_from_path(path), "path": path, "kind": "reference"}
            if candidate not in merged:
                merged.append(candidate)
        return merged

    @staticmethod
    def _merge_asset_refs(existing: Any, refs: Any, field_name: str) -> list[dict[str, Any]]:
        if refs is None:
            return list(existing or [])
        if not isinstance(refs, list) or not all(isinstance(item, dict) for item in refs):
            raise WriteError(f"{field_name} must be a list of mappings")
        merged = list(existing or [])
        for item in refs:
            if not isinstance(item.get("path"), str) or not item["path"].strip():
                raise WriteError(f"{field_name} entries require path")
            candidate = {"path": item["path"].strip()}
            candidate["id"] = item.get("id") or DatasetWriter._asset_id_from_path(candidate["path"])
            if item.get("label"):
                candidate["label"] = item["label"]
            if item.get("kind"):
                candidate["kind"] = item["kind"]
            elif field_name == "image_refs":
                candidate["kind"] = "reference"
            if item.get("tags"):
                if not isinstance(item["tags"], list) or not all(isinstance(tag, str) for tag in item["tags"]):
                    raise WriteError(f"{field_name} tags must be a list of strings")
                candidate["tags"] = item["tags"]
            if candidate not in merged:
                merged.append(candidate)
        return merged

    @staticmethod
    def _normalize_lora_refs(refs: Any) -> list[dict[str, Any]]:
        if refs is None:
            return []
        if not isinstance(refs, list) or not all(isinstance(item, dict) for item in refs):
            raise WriteError("lora_refs must be a list of mappings")
        normalized: list[dict[str, Any]] = []
        for item in refs:
            name = item.get("name")
            if not isinstance(name, str) or not name.strip():
                raise WriteError("lora_refs entries require a non-empty name")
            candidate: dict[str, Any] = {"name": name.strip()}
            if item.get("path") is not None:
                if not isinstance(item["path"], str) or not item["path"].strip():
                    raise WriteError("lora_refs path must be a non-empty string")
                candidate["path"] = item["path"].strip()
            if item.get("weight") is not None:
                if not isinstance(item["weight"], (int, float)):
                    raise WriteError("lora_refs weight must be numeric")
                candidate["weight"] = float(item["weight"])
            if item.get("notes") is not None:
                if not isinstance(item["notes"], str):
                    raise WriteError("lora_refs notes must be a string")
                candidate["notes"] = item["notes"]
            normalized.append(candidate)
        return normalized

    @staticmethod
    def _asset_id_from_path(path: str) -> str:
        stem = Path(path).stem.strip().lower()
        cleaned = [character if character.isalnum() else '-' for character in stem]
        slug = ''.join(cleaned).strip('-')
        while '--' in slug:
            slug = slug.replace('--', '-')
        return slug or 'asset'

    @staticmethod
    def _normalize_markdown_section(title: str, content: str) -> str:
        stripped = content.strip()
        if not stripped:
            raise WriteError(f"{title.lower()} content must be non-empty")
        if stripped.startswith("#"):
            return stripped + "\n"
        return f"# {title}\n\n{stripped}\n"
