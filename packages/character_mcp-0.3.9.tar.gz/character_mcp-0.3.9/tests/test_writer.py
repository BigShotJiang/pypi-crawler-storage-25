import shutil
from pathlib import Path

import pytest
import yaml

from character_mcp.service import CharacterService
from character_mcp.writer import WriteError


BROKEN_TARGET_YAML = """schema_version: 1
id: broken-target
type: character
name: Broken Target
status: active
facets:
  - identity
files:
  identity: identity.md
relationships:
  - target_id: obsidian-sanctuary
    kind: knows
"""


def copy_root(sample_root, tmp_path, *, healthy: bool = False) -> Path:
    root = tmp_path / "characters_root"
    shutil.copytree(sample_root, root)
    if healthy:
        shutil.rmtree(root / "characters" / "bad-yaml")
        (root / "characters" / "broken-target" / "entity.yaml").write_text(BROKEN_TARGET_YAML, encoding="utf-8")
    return root


def test_create_entity_writes_new_files(sample_root, tmp_path):
    root = copy_root(sample_root, tmp_path, healthy=True)
    service = CharacterService(root)

    result = service.create_entity(
        entity_type="object",
        entity_id="shadow-notebook",
        name="Shadow Notebook",
        summary="A private notebook for Sanctuary notes.",
        tags=["notes", "sanctuary"],
    )

    assert result["status"] == "ok"
    assert (root / "objects" / "shadow-notebook" / "entity.yaml").exists()
    assert (root / "objects" / "shadow-notebook" / "profile.md").exists()
    assert "A private notebook for Sanctuary notes." in (root / "objects" / "shadow-notebook" / "profile.md").read_text(encoding="utf-8")
    assert any(entity.id == "shadow-notebook" for entity in service.list_entities())


def test_create_entity_requires_summary_for_object(sample_root, tmp_path):
    root = copy_root(sample_root, tmp_path, healthy=True)
    service = CharacterService(root)

    with pytest.raises(WriteError):
        service.create_entity(
            entity_type="object",
            entity_id="shadow-notebook",
            name="Shadow Notebook",
        )


def test_create_entity_rolls_back_new_entity_dir_when_validation_fails(sample_root, tmp_path):
    root = copy_root(sample_root, tmp_path, healthy=True)
    entity_path = root / "characters" / "dara" / "entity.yaml"
    payload = yaml.safe_load(entity_path.read_text(encoding="utf-8"))
    payload["facets"].append("rituals-and-wardrobe")
    payload["files"]["rituals-and-wardrobe"] = "rituals-and-wardrobe.md"
    entity_path.write_text(yaml.safe_dump(payload, sort_keys=False), encoding="utf-8")
    service = CharacterService(root)

    with pytest.raises(WriteError):
        service.create_entity(
            entity_type="object",
            entity_id="shadow-notebook",
            name="Shadow Notebook",
            summary="A private notebook for Sanctuary notes.",
        )

    assert not (root / "objects" / "shadow-notebook").exists()


def test_write_entity_facet_creates_new_facet(sample_root, tmp_path):
    root = copy_root(sample_root, tmp_path, healthy=True)
    service = CharacterService(root)

    result = service.write_entity_facet("dara", "voice", "# Voice\n\nLow, warm, deliberate.\n")

    assert result["facet"] == "voice"
    assert "voice" in service.list_entity_facets("dara")
    assert "Low, warm, deliberate." in service.get_entity_facet("dara", "voice").content


def test_write_entity_facet_rejects_broad_character_bucket(sample_root, tmp_path):
    root = copy_root(sample_root, tmp_path, healthy=True)
    service = CharacterService(root)

    with pytest.raises(WriteError, match="too broad"):
        service.write_entity_facet("dara", "wardrobe", "# Wardrobe\n\nMultiple outfits jammed together.\n")


def test_update_entity_yaml_changes_summary(sample_root, tmp_path):
    root = copy_root(sample_root, tmp_path, healthy=True)
    service = CharacterService(root)

    result = service.update_entity_yaml("dara", {"summary": "Updated summary"})

    assert result["status"] == "ok"
    assert service.get_entity_summary("dara").summary == "Updated summary"


def test_add_relationship_rolls_back_on_invalid_target(sample_root, tmp_path):
    root = copy_root(sample_root, tmp_path, healthy=True)
    service = CharacterService(root)
    before = (root / "characters" / "dara" / "entity.yaml").read_text(encoding="utf-8")

    with pytest.raises(WriteError):
        service.add_relationship("dara", target_id="missing-target", kind="knows")

    after = (root / "characters" / "dara" / "entity.yaml").read_text(encoding="utf-8")
    assert after == before


def test_add_relationship_succeeds_for_existing_target(sample_root, tmp_path):
    root = copy_root(sample_root, tmp_path, healthy=True)
    service = CharacterService(root)

    result = service.add_relationship("dara", target_id="obsidian-sanctuary", kind="visits")

    assert result["status"] == "ok"
    yaml_text = (root / "characters" / "dara" / "entity.yaml").read_text(encoding="utf-8")
    assert "visits" in yaml_text


def test_append_entity_alias(sample_root, tmp_path):
    root = copy_root(sample_root, tmp_path, healthy=True)
    service = CharacterService(root)

    result = service.append_entity_alias("dara", "The Well-Armed Smile")

    assert result["status"] == "ok"
    yaml_text = (root / "characters" / "dara" / "entity.yaml").read_text(encoding="utf-8")
    assert "The Well-Armed Smile" in yaml_text


def test_add_asset_reference_local_path(sample_root, tmp_path):
    root = copy_root(sample_root, tmp_path, healthy=True)
    service = CharacterService(root)
    src_file = tmp_path / "portrait.png"
    src_file.write_bytes(b"test image data")

    result = service.add_asset_reference(
        "dara",
        bucket="images",
        local_path=str(src_file),
        label="Portrait",
        kind="reference",
        tags=["canonical"],
        asset_id="portrait",
    )

    assert result["status"] == "ok"
    yaml_text = (root / "characters" / "dara" / "entity.yaml").read_text(encoding="utf-8")
    assert "assets/images/portrait.png" in yaml_text
    assert "portrait" in yaml_text
    assert (root / "characters" / "dara" / "assets" / "images" / "portrait.png").exists()


def test_add_asset_reference_remote_only(sample_root, tmp_path):
    root = copy_root(sample_root, tmp_path, healthy=True)
    service = CharacterService(root)

    result = service.add_asset_reference(
        "dara",
        bucket="images",
        url="https://example.com/portrait.jpg",
        remote_only=True,
        label="Remote Portrait",
        asset_id="remote-portrait",
    )

    assert result["status"] == "ok"
    assert "hint" in result
    yaml_text = (root / "characters" / "dara" / "entity.yaml").read_text(encoding="utf-8")
    assert "https://example.com/portrait.jpg" in yaml_text
    assert "path" not in result["asset"]


def test_add_asset_reference_auto_id_collision(sample_root, tmp_path):
    root = copy_root(sample_root, tmp_path, healthy=True)
    service = CharacterService(root)
    src = tmp_path / "portrait.png"
    src.write_bytes(b"img")

    result1 = service.add_asset_reference("dara", bucket="images", local_path=str(src))
    result2 = service.add_asset_reference("dara", bucket="images", local_path=str(src))

    assert result1["status"] == "ok"
    assert result2["status"] == "ok"
    assert result1["asset"]["id"] != result2["asset"]["id"]


def test_add_asset_reference_missing_local_path(sample_root, tmp_path):
    root = copy_root(sample_root, tmp_path, healthy=True)
    service = CharacterService(root)

    from character_mcp.writer import WriteError
    with pytest.raises(WriteError):
        service.add_asset_reference("dara", bucket="images", local_path="/nonexistent/file.png")


def test_add_asset_reference_requires_source(sample_root, tmp_path):
    root = copy_root(sample_root, tmp_path, healthy=True)
    service = CharacterService(root)

    from character_mcp.writer import WriteError
    with pytest.raises(WriteError):
        service.add_asset_reference("dara", bucket="images")


def test_update_visual_profile(sample_root, tmp_path):
    root = copy_root(sample_root, tmp_path, healthy=True)
    service = CharacterService(root)
    lora_dir = root / "characters" / "dara" / "loras"
    lora_dir.mkdir(parents=True, exist_ok=True)
    (lora_dir / "portrait-style.safetensors").write_bytes(b"lora")

    result = service.update_visual_profile(
        "dara",
        canonical_image_ids=["main-reference"],
        preferred_models=["flux-kontext-max"],
        default_seed=112233,
        prompt_notes="Keep the silver piercings and tattoo density stable.",
        lora_refs=[{"name": "portrait-style", "path": "loras/portrait-style.safetensors", "weight": 0.7}],
    )

    assert result["status"] == "ok"
    yaml_text = (root / "characters" / "dara" / "entity.yaml").read_text(encoding="utf-8")
    assert "canonical_image_ids" in yaml_text
    assert "flux-kontext-max" in yaml_text
    assert "portrait-style.safetensors" in yaml_text


def test_add_relationship_rejects_duplicate_target_and_kind(sample_root, tmp_path):
    root = copy_root(sample_root, tmp_path, healthy=True)
    service = CharacterService(root)
    service.add_relationship("dara", target_id="obsidian-sanctuary", kind="visits")

    with pytest.raises(WriteError):
        service.add_relationship("dara", target_id="obsidian-sanctuary", kind="visits", notes="second copy")
