import json
import shutil
from pathlib import Path

import pytest
import yaml

from character_mcp.service import CharacterService, EntityNotFoundError, FacetNotFoundError
from character_mcp.writer import WriteError


BROKEN_TARGET_YAML = """schema_version: 1
id: broken-target
type: character
name: Broken Target
status: active
facets:
  - identity
files:
  identity: identity.md
relationships:
  - target_id: obsidian-sanctuary
    kind: knows
"""


def copy_root(sample_root, tmp_path, *, healthy: bool = False) -> Path:
    root = tmp_path / "characters_root"
    shutil.copytree(sample_root, root)
    if healthy:
        shutil.rmtree(root / "characters" / "bad-yaml")
        (root / "characters" / "broken-target" / "entity.yaml").write_text(BROKEN_TARGET_YAML, encoding="utf-8")
    return root


def test_service_lists_entities(sample_root):
    service = CharacterService(sample_root)

    entities = service.list_entities()

    assert [entity.id for entity in entities] == ["broken-target", "dara", "obsidian-sanctuary"]


def test_service_returns_summary_and_facet_content(sample_root):
    service = CharacterService(sample_root)

    summary = service.get_entity_summary("dara")
    document = service.get_entity_facet("dara", "identity")

    assert summary.name == "Dara"
    assert "Identity" in document.content


def test_service_returns_relationships_related_entities_and_visual_profile(sample_root):
    service = CharacterService(sample_root)

    relationships = service.list_entity_relationships("dara")
    related = service.get_related_entities("dara")
    visual = service.get_visual_profile("dara")

    assert relationships[0]["target_id"] == "obsidian-sanctuary"
    assert related[0]["target"]["id"] == "obsidian-sanctuary"
    assert visual["canonical_image_ids"] == ["main-reference"]
    assert visual["preferred_models"] == ["flux-dev"]


def test_service_returns_doctor_report(sample_root):
    service = CharacterService(sample_root)

    report = service.doctor_report()

    assert report.entity_count == 3
    assert report.load_error_count == 1
    assert report.error_count >= 2
    assert report.warning_count >= 1


def test_service_can_link_character_to_openclaw_agent(sample_root, tmp_path):
    root = copy_root(sample_root, tmp_path, healthy=True)
    config_path = tmp_path / "openclaw.json"
    config_path.write_text(json.dumps({"acp": {"defaultAgent": "main"}, "agents": {"list": [{"id": "watcher"}]}}), encoding="utf-8")
    service = CharacterService(root, openclaw_config_path=config_path)

    result = service.link_character_agent("dara", "main", behavior_hint="Use the premium roleplay agent for this character.")
    binding = service.get_character_agent_binding("dara")

    assert result["status"] == "ok"
    assert binding["agent_id"] == "main"
    assert binding["behavior_hint"] == "Use the premium roleplay agent for this character."
    assert binding["is_valid"] is True


def test_service_rejects_unknown_openclaw_agent(sample_root, tmp_path):
    root = copy_root(sample_root, tmp_path, healthy=True)
    config_path = tmp_path / "openclaw.json"
    config_path.write_text(json.dumps({"agents": {"list": [{"id": "watcher"}]}}), encoding="utf-8")
    service = CharacterService(root, openclaw_config_path=config_path)

    with pytest.raises(WriteError):
        service.link_character_agent("dara", "main")


def test_service_starts_character_intake_and_reports_gaps(sample_root, tmp_path):
    config_path = tmp_path / "openclaw.json"
    config_path.write_text(json.dumps({"agents": {"list": [{"id": "main"}]}}), encoding="utf-8")
    service = CharacterService(tmp_path / "root", openclaw_config_path=config_path)
    (tmp_path / "root" / "characters").mkdir(parents=True)

    result = service.start_character_intake("vesper", "Vesper", agent_id="main")
    status = service.get_character_intake_status("vesper")
    visual = service.get_visual_profile("vesper")

    assert result["status"] == "ok"
    assert result["questions"] == ["What is the one-line summary of this character?"]
    assert result["next_step"]["step"] == "summary"
    assert result["next_step"]["optional"] is False
    assert (tmp_path / "root" / "characters" / "vesper" / "appearance.md").exists()
    assert (tmp_path / "root" / "characters" / "vesper" / "voice.md").exists()
    assert "identity" in status["missing_steps"]
    assert "appearance" in status["missing_steps"]
    assert "voice" in status["missing_steps"]
    assert status["linked_agent_id"] == "main"


def test_service_applies_character_intake_answers(sample_root, tmp_path):
    root = copy_root(sample_root, tmp_path, healthy=True)
    config_path = tmp_path / "openclaw.json"
    config_path.write_text(json.dumps({"agents": {"list": [{"id": "main"}]}}), encoding="utf-8")
    service = CharacterService(root, openclaw_config_path=config_path)

    service.create_entity(entity_type="object", entity_id="shadow-ring", name="Shadow Ring", summary="A dark ring used as a personal anchor.")
    service.start_character_intake("vesper", "Vesper")
    (root / "characters" / "vesper" / "images").mkdir(parents=True)
    (root / "characters" / "vesper" / "audio").mkdir(parents=True)
    (root / "characters" / "vesper" / "images" / "vesper.png").write_bytes(b"png")
    (root / "characters" / "vesper" / "audio" / "vesper.ogg").write_bytes(b"ogg")

    result = service.apply_character_intake_answers(
        "vesper",
        {
            "summary": "A poised court operative with dangerous calm.",
            "identity": "A dangerous court operative who prefers precision over spectacle.",
            "appearance": "Silver hair, mirrored nails, and an obsidian silk silhouette.",
            "voice": "Low, warm, and deliberate.",
            "aliases": ["Night Vesper"],
            "tags": ["chaos", "court"],
            "agent_id": "main",
            "home_location_id": "obsidian-sanctuary",
            "signature_object_id": "shadow-ring",
            "relationships": [{"target_id": "dara", "kind": "ally"}],
            "image_paths": ["images/vesper.png"],
            "audio_paths": ["audio/vesper.ogg"],
            "canonical_image_ids": ["vesper"],
            "preferred_models": ["flux-kontext-max"],
            "default_image_seed": 12345,
            "image_prompt_notes": "Keep Nyx-level polish out; Vesper should read colder and more severe.",
            "status": "active",
        },
    )

    summary = service.get_entity_summary("vesper")
    identity = service.get_entity_facet("vesper", "identity")
    appearance = service.get_entity_facet("vesper", "appearance")
    voice = service.get_entity_facet("vesper", "voice")
    relationships = service.list_entity_relationships("vesper")
    status = service.get_character_intake_status("vesper")
    visual = service.get_visual_profile("vesper")

    assert result["status"] == "ok"
    assert result["questions"] == []
    assert result["next_step"]["is_complete"] is True
    assert summary.summary == "A poised court operative with dangerous calm."
    assert "Night Vesper" in service._get_entity("vesper").aliases
    assert "dangerous court operative" in identity.content
    assert "obsidian silk" in appearance.content
    assert "Low, warm, and deliberate." in voice.content
    assert any(item["target_id"] == "obsidian-sanctuary" and item["kind"] == "lives-in" for item in relationships)
    assert any(item["target_id"] == "shadow-ring" and item["kind"] == "uses" for item in relationships)
    assert any(item["target_id"] == "dara" and item["kind"] == "ally" for item in relationships)
    assert status["missing_steps"] == []
    assert status["linked_agent_id"] == "main"
    assert result["completion_summary"]["core_ready"] is True
    assert visual["canonical_image_ids"] == ["vesper"]
    assert visual["preferred_models"] == ["flux-kontext-max"]
    assert visual["default_seed"] == 12345


def test_service_rejects_invalid_home_location_type(sample_root, tmp_path):
    root = copy_root(sample_root, tmp_path, healthy=True)
    service = CharacterService(root)
    service.start_character_intake("vesper", "Vesper")

    with pytest.raises(WriteError):
        service.apply_character_intake_answers("vesper", {"home_location_id": "dara"})


def test_service_raises_for_missing_entity_or_facet(sample_root):
    service = CharacterService(sample_root)

    with pytest.raises(EntityNotFoundError):
        service.get_entity_summary("missing")

    with pytest.raises(FacetNotFoundError):
        service.get_entity_facet("dara", "missing-facet")


def test_service_can_update_visual_profile(sample_root, tmp_path):
    root = copy_root(sample_root, tmp_path, healthy=True)
    service = CharacterService(root)
    lora_dir = root / "characters" / "dara" / "loras"
    lora_dir.mkdir(parents=True, exist_ok=True)
    (lora_dir / "dara-style.safetensors").write_bytes(b"lora")

    result = service.update_visual_profile(
        "dara",
        canonical_image_ids=["main-reference"],
        optional_image_ids=[],
        preferred_models=["flux-kontext-max"],
        default_seed=98765,
        prompt_notes="Keep Dara's facial structure and tattoo placement locked.",
        negative_prompt="No extra fingers, no missing piercings.",
        lora_refs=[{"name": "dara-style", "path": "loras/dara-style.safetensors", "weight": 0.8}],
    )

    visual = service.get_visual_profile("dara")

    assert result["status"] == "ok"
    assert visual["canonical_image_ids"] == ["main-reference"]
    assert visual["preferred_models"] == ["flux-kontext-max"]
    assert visual["default_seed"] == 98765
    assert visual["lora_refs"][0]["name"] == "dara-style"


def test_service_doctor_warns_on_uncurated_image_assets(sample_root, tmp_path):
    root = copy_root(sample_root, tmp_path, healthy=True)
    entity_path = root / "characters" / "dara" / "entity.yaml"
    text = entity_path.read_text(encoding="utf-8")
    text = text.replace("""visual:
  canonical_image_ids:
    - main-reference
  preferred_models:
    - flux-dev
  default_seed: 424242
  prompt_notes: Keep Dara's golden hair, silver piercings, and blackwork tattoos consistent.
""", "")
    entity_path.write_text(text, encoding="utf-8")
    service = CharacterService(root)

    report = service.doctor_report()

    assert any(issue.code == "uncurated-image-references" for issue in report.issues)


def test_service_intake_can_create_home_and_signature_entities(sample_root, tmp_path):
    root = copy_root(sample_root, tmp_path, healthy=True)
    service = CharacterService(root)
    service.start_character_intake("noctis", "Noctis")

    result = service.apply_character_intake_answers(
        "noctis",
        {
            "summary": "A nocturnal operator who keeps his world unnervingly tidy.",
            "identity": "A quiet court fixer who prefers leverage to noise.",
            "appearance": "Black velvet layers, silver rings, and controlled posture.",
            "voice": "Measured, low, and almost too calm.",
            "home_location": {
                "id": "mirror-study",
                "name": "Mirror Study",
                "summary": "A private study lined with smoked mirrors.",
                "profile": "Smoked mirrors, a lacquered desk, and a silence that feels deliberate.",
            },
            "signature_object": {
                "id": "glass-ledger",
                "name": "Glass Ledger",
                "summary": "A translucent ledger etched with debt marks.",
                "profile": "A translucent ledger whose etched marks only appear under low light.",
            },
            "status": "active",
        },
    )

    relationships = service.list_entity_relationships("noctis")
    completion = result["completion_summary"]

    assert (root / "places" / "mirror-study" / "entity.yaml").exists()
    assert (root / "places" / "mirror-study" / "profile.md").exists()
    assert (root / "objects" / "glass-ledger" / "entity.yaml").exists()
    assert (root / "objects" / "glass-ledger" / "profile.md").exists()
    assert "Smoked mirrors, a lacquered desk" in (root / "places" / "mirror-study" / "profile.md").read_text(encoding="utf-8")
    assert "status:" not in (root / "places" / "mirror-study" / "entity.yaml").read_text(encoding="utf-8")
    assert "status:" not in (root / "objects" / "glass-ledger" / "entity.yaml").read_text(encoding="utf-8")
    assert any(item["target_id"] == "mirror-study" and item["kind"] == "lives-in" for item in relationships)
    assert any(item["target_id"] == "glass-ledger" and item["kind"] == "uses" for item in relationships)
    assert completion["core_ready"] is True
    assert completion["linked_entities"]["home_location"] == "mirror-study"
    assert completion["linked_entities"]["signature_object"] == "glass-ledger"


def test_service_rejects_mixed_existing_and_new_home_location(sample_root, tmp_path):
    root = copy_root(sample_root, tmp_path, healthy=True)
    service = CharacterService(root)
    service.start_character_intake("vesper", "Vesper")

    with pytest.raises(WriteError):
        service.apply_character_intake_answers(
            "vesper",
            {
                "home_location_id": "obsidian-sanctuary",
                "home_location": {"id": "mirror-study", "name": "Mirror Study"},
            },
        )


def test_service_reports_character_gaps_and_best_next_step(sample_root):
    service = CharacterService(sample_root)

    report = service.get_character_gap_report("dara")

    assert any(item["facet"] == "voice" for item in report["weak_facets"])
    assert report["best_next_improvement"] == "What visual anchors define this character's appearance?"


def test_start_character_intake_status_includes_gap_report(tmp_path):
    service = CharacterService(tmp_path / "root")
    (tmp_path / "root" / "characters").mkdir(parents=True)

    service.start_character_intake("vesper", "Vesper")
    status = service.get_character_intake_status("vesper")

    assert status["gap_report"]["required_missing"] == ["summary", "identity", "appearance", "voice"]
    assert status["gap_report"]["best_next_improvement"] == "What is the one-line summary of this character?"


def test_service_tracks_previous_agent_on_relink(sample_root, tmp_path):
    root = copy_root(sample_root, tmp_path, healthy=True)
    config_path = tmp_path / "openclaw.json"
    config_path.write_text(json.dumps({"agents": {"list": [{"id": "main"}, {"id": "watcher"}]}}), encoding="utf-8")
    service = CharacterService(root, openclaw_config_path=config_path)

    service.link_character_agent("dara", "main", behavior_hint="Primary persona agent.")
    service.link_character_agent("dara", "watcher", behavior_hint="Use the cheaper watcher agent for low-stakes tasks.")
    binding = service.get_character_agent_binding("dara")

    assert binding["agent_id"] == "watcher"
    assert binding["previous_agent_id"] == "main"
    assert binding["behavior_hint"] == "Use the cheaper watcher agent for low-stakes tasks."
    assert binding["last_linked_at"] is not None


def test_service_doctor_warns_on_orphaned_agent_behavior_hint(sample_root, tmp_path):
    root = copy_root(sample_root, tmp_path, healthy=True)
    service = CharacterService(root)
    service.update_entity_yaml("dara", {"integration": {"openclaw": {"behavior_hint": "Use premium reasoning."}}})

    report = service.doctor_report()

    assert any(issue.code == "orphaned-agent-behavior-hint" for issue in report.issues)


def test_service_doctor_reports_duplicate_relationships(sample_root, tmp_path):
    root = copy_root(sample_root, tmp_path, healthy=True)
    entity_path = root / "characters" / "dara" / "entity.yaml"
    payload = yaml.safe_load(entity_path.read_text(encoding="utf-8"))
    payload["relationships"] = [
        {"target_id": "obsidian-sanctuary", "kind": "inhabits"},
        {"target_id": "obsidian-sanctuary", "kind": "inhabits"},
    ]
    entity_path.write_text(yaml.safe_dump(payload, sort_keys=False), encoding="utf-8")
    service = CharacterService(root)

    report = service.doctor_report()

    assert any(issue.code == "duplicate-relationship" for issue in report.issues)


def test_service_reports_empty_dataset_status_and_can_initialize_root(tmp_path):
    root = tmp_path / "characters_root"
    service = CharacterService(root)

    status = service.get_dataset_status()
    init = service.initialize_character_root()

    assert status["is_empty"] is True
    assert status["next_actions"] == ["initialize_character_root", "start_character_intake", "start_existing_character_import"]
    assert init["status"] == "ok"
    assert (root / "characters").is_dir()
    assert (root / "places").is_dir()
    assert (root / "objects").is_dir()
    assert (root / "README.md").exists()


def test_service_can_start_existing_character_import(tmp_path):
    root = tmp_path / "characters_root"
    service = CharacterService(root)
    service.initialize_character_root()

    result = service.start_existing_character_import("corwin", "Corwin", summary="A recalled chaos prince with too much history.")

    assert result["status"] == "ok"
    assert result["mode"] == "existing-character-import"
    assert result["next_step"]["step"] == "identity"
    assert "visual_profile" in result["storage_concepts"]
    assert "Treat recalled knowledge as proposed data" in result["import_prompt"]


def test_service_cleanup_dataset_dry_run_reports_orphans_and_stale_facets(sample_root, tmp_path):
    root = copy_root(sample_root, tmp_path, healthy=True)
    entity_path = root / "characters" / "dara" / "entity.yaml"
    payload = yaml.safe_load(entity_path.read_text(encoding="utf-8"))
    payload["facets"].append("rituals-and-wardrobe")
    payload["files"]["rituals-and-wardrobe"] = "rituals-and-wardrobe.md"
    entity_path.write_text(yaml.safe_dump(payload, sort_keys=False), encoding="utf-8")
    orphan_dir = root / "objects" / "dark-porcelain-espresso-cup"
    orphan_dir.mkdir(parents=True)
    (orphan_dir / "profile.md").write_text("# Profile\n\nTiny dark porcelain cup.\n", encoding="utf-8")
    service = CharacterService(root)

    result = service.cleanup_dataset()

    assert result["apply"] is False
    assert result["orphan_entity_dir_count"] == 1
    assert result["stale_facet_ref_count"] == 1
    assert result["orphan_entity_dirs"][0]["entity_id"] == "dark-porcelain-espresso-cup"
    assert result["stale_facet_refs"][0]["entity_id"] == "dara"
    assert result["stale_facet_refs"][0]["facets"] == ["rituals-and-wardrobe"]


def test_service_cleanup_dataset_apply_quarantines_orphans_and_prunes_stale_facets(sample_root, tmp_path):
    root = copy_root(sample_root, tmp_path, healthy=True)
    entity_path = root / "characters" / "dara" / "entity.yaml"
    payload = yaml.safe_load(entity_path.read_text(encoding="utf-8"))
    payload["facets"].append("rituals-and-wardrobe")
    payload["files"]["rituals-and-wardrobe"] = "rituals-and-wardrobe.md"
    entity_path.write_text(yaml.safe_dump(payload, sort_keys=False), encoding="utf-8")
    orphan_dir = root / "objects" / "dark-porcelain-espresso-cup"
    orphan_dir.mkdir(parents=True)
    (orphan_dir / "profile.md").write_text("# Profile\n\nTiny dark porcelain cup.\n", encoding="utf-8")
    service = CharacterService(root)

    result = service.cleanup_dataset(apply=True)
    report = service.doctor_report()
    repaired = yaml.safe_load(entity_path.read_text(encoding="utf-8"))

    assert result["apply"] is True
    assert result["quarantine_root"] is not None
    assert len(result["quarantined"]) == 1
    assert len(result["pruned_facet_refs"]) == 1
    assert not orphan_dir.exists()
    assert (Path(result["quarantined"][0]["to"]) / "profile.md").exists()
    assert "rituals-and-wardrobe" not in repaired.get("facets", [])
    assert "rituals-and-wardrobe" not in repaired.get("files", {})
    assert report.load_error_count == 0
    assert not any(issue.code == "missing-file" for issue in report.issues)


def test_service_rejects_placeholder_profile_for_new_linked_entity(sample_root, tmp_path):
    root = copy_root(sample_root, tmp_path, healthy=True)
    service = CharacterService(root)
    service.start_character_intake("vesper", "Vesper")

    with pytest.raises(WriteError):
        service.apply_character_intake_answers(
            "vesper",
            {
                "home_location": {
                    "id": "mirror-study",
                    "name": "Mirror Study",
                    "summary": "A private study lined with smoked mirrors.",
                    "profile": "Describe Mirror Study here.",
                },
            },
        )


def test_service_rejects_missing_profile_for_new_linked_entity(sample_root, tmp_path):
    root = copy_root(sample_root, tmp_path, healthy=True)
    service = CharacterService(root)
    service.start_character_intake("vesper", "Vesper")

    with pytest.raises(WriteError):
        service.apply_character_intake_answers(
            "vesper",
            {
                "signature_object": {
                    "id": "glass-ledger",
                    "name": "Glass Ledger",
                    "summary": "A translucent ledger etched with debt marks.",
                },
            },
        )


def test_service_can_store_proposed_identity(sample_root, tmp_path):
    root = copy_root(sample_root, tmp_path, healthy=True)
    service = CharacterService(root)
    service.start_character_intake("vesper", "Vesper")

    service.apply_character_intake_answers(
        "vesper",
        {
            "proposed_identity": "A tentative import sketch: neon-chaotic foil to Dara before the full canon wording is locked.",
        },
    )

    content = service.get_entity_facet("vesper", "proposed-identity").content
    assert "tentative import sketch" in content


def test_service_allows_short_profile_for_new_linked_entity(sample_root, tmp_path):
    root = copy_root(sample_root, tmp_path, healthy=True)
    service = CharacterService(root)
    service.start_character_intake("vesper", "Vesper")

    result = service.apply_character_intake_answers(
        "vesper",
        {
            "home_location": {
                "id": "mirror-study",
                "name": "Mirror Study",
                "profile": "Smoked mirrors. Quiet desk.",
            },
        },
    )

    assert result["status"] == "ok"
    assert (root / "places" / "mirror-study" / "profile.md").exists()


def test_doctor_warns_on_absolute_asset_path(sample_root, tmp_path):
    root = copy_root(sample_root, tmp_path, healthy=True)
    entity_yaml = root / "characters" / "dara" / "entity.yaml"
    import yaml as _yaml
    data = _yaml.safe_load(entity_yaml.read_text(encoding="utf-8"))
    data.setdefault("assets", {})["images"] = [
        {"id": "external-ref", "path": "/tmp/some-external-file.jpg", "label": "External"}
    ]
    entity_yaml.write_text(_yaml.dump(data), encoding="utf-8")

    service = CharacterService(root)
    issues = service.doctor()
    codes = [issue.code for issue in issues]
    assert "absolute-asset-path" in codes


def test_doctor_warns_on_remote_only_visual_ref(sample_root, tmp_path):
    root = copy_root(sample_root, tmp_path, healthy=True)
    entity_yaml = root / "characters" / "dara" / "entity.yaml"
    import yaml as _yaml
    data = _yaml.safe_load(entity_yaml.read_text(encoding="utf-8"))
    data["assets"] = {"images": [{"id": "remote-only", "url": "https://example.com/img.jpg"}]}
    data["visual"] = {"canonical_image_ids": ["remote-only"], "preferred_models": ["flux-dev"]}
    entity_yaml.write_text(_yaml.dump(data), encoding="utf-8")

    service = CharacterService(root)
    issues = service.doctor()
    codes = [issue.code for issue in issues]
    assert "remote-only-asset-ref" in codes


def test_visual_profile_includes_asset_hints_for_remote_only(sample_root, tmp_path):
    root = copy_root(sample_root, tmp_path, healthy=True)
    entity_yaml = root / "characters" / "dara" / "entity.yaml"
    import yaml as _yaml
    data = _yaml.safe_load(entity_yaml.read_text(encoding="utf-8"))
    data["assets"] = {"images": [{"id": "remote-only", "url": "https://example.com/img.jpg"}]}
    data["visual"] = {"canonical_image_ids": ["remote-only"], "preferred_models": ["flux-dev"]}
    entity_yaml.write_text(_yaml.dump(data), encoding="utf-8")

    service = CharacterService(root)
    profile = service.get_visual_profile("dara")
    assert "asset_hints" in profile
    assert any("localize_asset_reference" in hint for hint in profile["asset_hints"])
