from pathlib import Path

import yaml

from character_mcp.loader import load_entities


def test_load_entities_returns_valid_entities_and_load_errors(sample_root):
    result = load_entities(sample_root)

    assert len(result.entities) == 3
    assert len(result.errors) == 1

    dara = next(entity for entity in result.entities if entity.id == "dara")
    assert dara.type == "character"
    assert dara.files["identity"].name == "identity.md"
    assert dara.relationships[0].target_id == "obsidian-sanctuary"

    assert result.errors[0].entity_dir.name == "bad-yaml"


def test_schema_validation_rejects_invalid_character_without_status(sample_root, tmp_path):
    invalid_root = tmp_path / "characters_root"
    entity_dir = invalid_root / "characters" / "no-status"
    entity_dir.mkdir(parents=True)
    (entity_dir / "entity.yaml").write_text(
        """
        schema_version: 1
        id: no-status
        type: character
        name: No Status
        files:
          identity: identity.md
        """,
        encoding="utf-8",
    )
    (entity_dir / "identity.md").write_text("# Identity\n", encoding="utf-8")

    result = load_entities(invalid_root)

    assert len(result.entities) == 0
    assert len(result.errors) == 1
    assert "schema validation failed" in result.errors[0].message


def test_asset_ref_local_path_resolved(sample_root):
    result = load_entities(sample_root)
    dara = next(entity for entity in result.entities if entity.id == "dara")
    images = dara.assets.get("images", [])
    assert images, "expected at least one image ref"
    ref = images[0]
    assert ref.path is not None
    assert ref.path.is_absolute()
    assert ref.url is None


def test_asset_ref_url_stored_as_is(tmp_path):
    entity_dir = tmp_path / "characters" / "test-char"
    entity_dir.mkdir(parents=True)
    (entity_dir / "entity.yaml").write_text(
        yaml.dump({
            "schema_version": 1,
            "id": "test-char",
            "type": "character",
            "name": "Test Char",
            "status": "active",
            "assets": {
                "images": [
                    {"id": "remote-ref", "url": "https://example.com/image.jpg", "label": "Remote"},
                ]
            },
        }),
        encoding="utf-8",
    )

    result = load_entities(tmp_path)
    assert len(result.entities) == 1
    ref = result.entities[0].assets["images"][0]
    assert ref.url == "https://example.com/image.jpg"
    assert ref.path is None


def test_asset_ref_dual_ref_loaded(tmp_path):
    entity_dir = tmp_path / "characters" / "test-char"
    entity_dir.mkdir(parents=True)
    asset_dir = entity_dir / "assets" / "images"
    asset_dir.mkdir(parents=True)
    (asset_dir / "portrait.jpg").write_bytes(b"img")
    (entity_dir / "entity.yaml").write_text(
        yaml.dump({
            "schema_version": 1,
            "id": "test-char",
            "type": "character",
            "name": "Test Char",
            "status": "active",
            "assets": {
                "images": [
                    {
                        "id": "portrait",
                        "path": "assets/images/portrait.jpg",
                        "url": "https://example.com/portrait.jpg",
                    },
                ]
            },
        }),
        encoding="utf-8",
    )

    result = load_entities(tmp_path)
    assert len(result.entities) == 1
    ref = result.entities[0].assets["images"][0]
    assert ref.path is not None and ref.path.name == "portrait.jpg"
    assert ref.url == "https://example.com/portrait.jpg"


def test_asset_schema_requires_path_or_url(tmp_path):
    entity_dir = tmp_path / "characters" / "test-char"
    entity_dir.mkdir(parents=True)
    (entity_dir / "entity.yaml").write_text(
        yaml.dump({
            "schema_version": 1,
            "id": "test-char",
            "type": "character",
            "name": "Test Char",
            "status": "active",
            "assets": {
                "images": [{"id": "no-source", "label": "Missing path and url"}],
            },
        }),
        encoding="utf-8",
    )

    result = load_entities(tmp_path)
    assert len(result.errors) == 1
    assert "schema validation failed" in result.errors[0].message
