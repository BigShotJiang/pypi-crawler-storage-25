from pathlib import Path
import logging
import warnings
import numpy as np
import pandas as pd
import SimpleITK as sitk
from radiomics import featureextractor

try:
    from radiomics import featureextractor
except ImportError:
    featureextractor = None
    warnings.warn("PyRadiomics no está instalado. Si deseas usar la extracción de texturas, instala PyRadiomics en tu entorno con `pip install pyradiomics`")

logger = logging.getLogger(__name__)

def build_radiomics_extractor(
    bin_width: int = 5,
    force_2d: bool = True,
    force_2d_dimension: int = 0,
    normalize: bool = False,
    normalize_scale: int = 1,
    distances: list[int] | None = None,
):
    """
    Crea el extractor de PyRadiomics con la configuración usada
    para las texturas del recto femoral.
    """
    if distances is None:
        distances = [8]

    settings = {
        "binWidth": bin_width,
        "force2D": force_2d,
        "force2Ddimension": force_2d_dimension,
        "normalize": normalize,
        "normalizeScale": normalize_scale,
        "distances": distances,
    }

    extractor = featureextractor.RadiomicsFeatureExtractor(**settings)

    extractor.disableAllFeatures()

    extractor.enableFeaturesByName(
        firstorder=[
            "Mean",
            "Variance",
            "Kurtosis",
        ],
        glcm=[
            "Contrast",
            "Correlation",
            "JointEnergy",
            "JointEntropy",
            "Idm",
        ],
    )

    return extractor


def extract_rectus_femoral_mask(
    label_image: sitk.Image,
    rectus_label: int = 3,
    min_pixels: int = 20,
) -> sitk.Image:
    """
    Extrae la máscara binaria del recto femoral a partir de una segmentación.

    Parameters
    ----------
    label_image : sitk.Image
        Máscara segmentada.

    rectus_label : int
        Etiqueta correspondiente al recto femoral.
        Por defecto: 3.

    min_pixels : int
        Número mínimo de píxeles aceptado para calcular texturas.

    Returns
    -------
    sitk.Image
        Máscara binaria del recto femoral.
    """

    label_arr = sitk.GetArrayFromImage(label_image)
    rf_mask = (label_arr == rectus_label).astype(np.uint8)

    if np.sum(rf_mask) < min_pixels:
        raise ValueError(
            f"La máscara del recto femoral es demasiado pequeña: "
            f"{np.sum(rf_mask)} píxeles"
        )

    mask_sitk = sitk.GetImageFromArray(rf_mask)
    mask_sitk.CopyInformation(label_image)

    return mask_sitk


def extract_textures_dataframe(
    image_path: str,
    mask_path: str,
    case_id: str | None = None,
    rectus_label: int = 3,
    min_pixels: int = 20,
) -> pd.DataFrame:
    """
    Calcula las texturas del recto femoral y devuelve un DataFrame.

    No guarda Excel directamente. Esto permite usar la función en múltiples
    casos y luego concatenar los DataFrames con pandas.

    Parameters
    ----------
    image_path : str
        Ruta de la imagen de ecografía.

    mask_path : str
        Ruta de la segmentación/máscara.

    case_id : str, optional
        Identificador del caso. Si no se indica, se usa el nombre del archivo
        de la máscara.

    rectus_label : int
        Label del recto femoral en la segmentación.
        Por defecto: 3.

    min_pixels : int
        Tamaño mínimo de la máscara para calcular texturas.

    Returns
    -------
    pd.DataFrame
        DataFrame con una fila y las texturas calculadas.
    """

    if featureextractor is None:
        raise ImportError("PyRadiomics no está instalado. Instala la librería con `pip install pyradiomics`.")

    image_path = Path(image_path)
    mask_path = Path(mask_path)

    if not image_path.exists():
        raise FileNotFoundError(f"No existe la imagen: {image_path}")

    if not mask_path.exists():
        raise FileNotFoundError(f"No existe la máscara: {mask_path}")

    if case_id is None:
        case_id = mask_path.name.replace(".nii.gz", "").replace(".mha", "")

    logger.info(f"Leyendo imagen: {image_path}")
    img_sitk = sitk.ReadImage(str(image_path))

    logger.info(f"Leyendo máscara: {mask_path}")
    lab_sitk = sitk.ReadImage(str(mask_path))

    if img_sitk.GetSize() != lab_sitk.GetSize():
        raise ValueError(
            f"La imagen y la máscara no tienen el mismo tamaño: "
            f"image={img_sitk.GetSize()}, mask={lab_sitk.GetSize()}"
        )

    mask_sitk = extract_rectus_femoral_mask(
        label_image=lab_sitk,
        rectus_label=rectus_label,
        min_pixels=min_pixels,
    )

    extractor = build_radiomics_extractor()

    features = extractor.execute(img_sitk, mask_sitk)

    row = {
        "case_id": case_id,

        # FIRST ORDER
        "rf_mean": features.get("original_firstorder_Mean"),
        "rf_std": np.sqrt(features.get("original_firstorder_Variance", 0)),
        "rf_kurtosis": features.get("original_firstorder_Kurtosis"),

        # GLCM, distancia 8
        "glcm_contrast_d8": features.get("original_glcm_Contrast"),
        "glcm_correlation_d8": features.get("original_glcm_Correlation"),
        "glcm_energy_d8": features.get("original_glcm_JointEnergy"),
        "glcm_entropy_d8": features.get("original_glcm_JointEntropy"),
        "glcm_homogeneity_d8": features.get("original_glcm_Idm"),
    }

    return pd.DataFrame([row])