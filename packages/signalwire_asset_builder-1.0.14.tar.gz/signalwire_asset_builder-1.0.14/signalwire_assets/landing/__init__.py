"""
signalwire_assets.landing -- branded landing page builder.

Public API
----------
build_page       Build a single HTML landing page from a JSON section list.
build_batch      Build every JSON file in a directory.
generate_css     Convert DTCG tokens into CSS custom properties.
load_tokens      Load tokens from a dict or the bundled DTCG file.
SECTION_RENDERERS  Dict mapping section type names to renderer functions.
"""

from .page import build_page, build_batch
from .tokens import generate_css, load_tokens
from .renderers import SECTION_RENDERERS

__all__ = [
    "build_page",
    "build_batch",
    "generate_css",
    "load_tokens",
    "SECTION_RENDERERS",
]
