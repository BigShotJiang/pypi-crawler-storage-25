"""
Landing page component CSS loader.

Loads ``landing.css`` from the package assets directory.
The CSS file is the source of truth for all landing page component styles.
Edit the CSS file directly; this module reads it.

``generate_css`` is re-exported from ``.tokens`` for convenience.
"""

from importlib import resources as _pkg_resources

from .tokens import generate_css  # noqa: F401 – re-export


def _load_component_css():
    """Load landing.css from bundled assets."""
    ref = _pkg_resources.files("signalwire_assets").joinpath("assets", "landing.css")
    return ref.read_text(encoding="utf-8")


COMPONENT_CSS = _load_component_css()
