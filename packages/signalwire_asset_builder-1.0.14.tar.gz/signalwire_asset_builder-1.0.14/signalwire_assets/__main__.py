"""
CLI: signalwire-assets

Commands:
    signalwire-assets slides list            # show all 30 layouts
    signalwire-assets slides show L04        # view layout source
    signalwire-assets slides build           # build reference deck
    signalwire-assets slides docs            # full API reference

    signalwire-assets landing build page.json           # build single page
    signalwire-assets landing build page.json -o out.html
    signalwire-assets landing batch content_dir/        # build all JSONs
    signalwire-assets landing batch content_dir/ -o out/
"""

import argparse
import json
import os
import sys


def main():
    parser = argparse.ArgumentParser(
        prog="signalwire-assets",
        description="SignalWire branded asset builder: slide decks and landing pages",
    )
    sub = parser.add_subparsers(dest="asset_type")

    # ── slides ──────────────────────────────────────────────────────────────
    slides_p = sub.add_parser("slides", help="Slide deck builder")
    slides_sub = slides_p.add_subparsers(dest="slides_cmd")

    slides_sub.add_parser("list", help="Show all available layouts")

    show_p = slides_sub.add_parser("show", help="View source code of a layout")
    show_p.add_argument("layout", help="Layout ID (L04) or name (content)")

    build_p = slides_sub.add_parser("build", help="Build reference deck")
    build_p.add_argument("--theme", choices=["dark", "light", "both"], default="both")
    build_p.add_argument("-o", "--output-dir", default=".")

    slides_sub.add_parser("docs", help="Full API reference, writing rules, word limits")

    # ── landing ─────────────────────────────────────────────────────────────
    landing_p = sub.add_parser("landing", help="Landing page builder")
    landing_sub = landing_p.add_subparsers(dest="landing_cmd")

    lbuild_p = landing_sub.add_parser("build", help="Build a single landing page from JSON")
    lbuild_p.add_argument("json_file", help="Path to JSON content file")
    lbuild_p.add_argument("-o", "--output", help="Output HTML path (default: <name>.html)")

    lbatch_p = landing_sub.add_parser("batch", help="Build all JSON files in a directory")
    lbatch_p.add_argument("content_dir", help="Directory containing JSON content files")
    lbatch_p.add_argument("-o", "--output-dir", default=".", help="Output directory")

    args = parser.parse_args()

    if args.asset_type == "slides":
        from .slides.cli import cmd_list, cmd_show, cmd_build, cmd_docs

        if args.slides_cmd == "list":
            cmd_list(args)
        elif args.slides_cmd == "show":
            cmd_show(args)
        elif args.slides_cmd == "build":
            cmd_build(args)
        elif args.slides_cmd == "docs":
            cmd_docs(args)
        else:
            slides_p.print_help()

    elif args.asset_type == "landing":
        if args.landing_cmd == "build":
            _landing_build(args)
        elif args.landing_cmd == "batch":
            _landing_batch(args)
        else:
            landing_p.print_help()

    else:
        parser.print_help()
        print("\nQuick start:")
        print("  signalwire-assets slides list       # see all slide layouts")
        print("  signalwire-assets slides docs        # slide API reference")
        print("  signalwire-assets landing build page.json  # build a landing page")


def _landing_build(args):
    """Build a single landing page from JSON."""
    from .landing import build_page

    with open(args.json_file) as f:
        page_data = json.load(f)

    html = build_page(page_data)

    if args.output:
        out = args.output
    else:
        out = os.path.splitext(os.path.basename(args.json_file))[0] + ".html"

    with open(out, "w") as f:
        f.write(html)
    print(f"Built: {out}")


def _landing_batch(args):
    """Build all JSON files in a directory."""
    from .landing import build_page

    os.makedirs(args.output_dir, exist_ok=True)
    count = 0
    for name in sorted(os.listdir(args.content_dir)):
        if not name.endswith(".json"):
            continue
        with open(os.path.join(args.content_dir, name)) as f:
            page_data = json.load(f)
        html = build_page(page_data)
        out = os.path.join(args.output_dir, name.replace(".json", ".html"))
        with open(out, "w") as f:
            f.write(html)
        count += 1

    print(f"Built {count} pages in {args.output_dir}")


if __name__ == "__main__":
    main()
