"""L24: Metric Dashboard (4 KPI cards)."""
LAYOUT_ID = "L24"
LAYOUT_NAME = "Metric Dashboard"
LAYOUT_DESC = "4 KPI cards with values, labels, and context."
from .core import *

def L24_metric_dashboard(prs, bk, T, logo, title=None, metrics=None, ai_notes=None):
    S = SlideBuilder(prs, bk, T, logo, ai_notes=ai_notes or "L24 Metric Dashboard: 4 KPI cards with values, labels, and context")
    S.title(title or "Performance at a glance")
    _metrics = metrics or [("2.7B", "Minutes", "Processed annually", T["emphasis"]),
                            ("2000+", "Customers", "Enterprise and carrier scale", T["emphasis_alt"]),
                            ("800ms", "Latency", "Sub-second response time", T["emphasis"]),
                            ("85", "People", "Serving global scale", T["emphasis_alt"])]
    S.metric_cards(_metrics)
    S.done()
