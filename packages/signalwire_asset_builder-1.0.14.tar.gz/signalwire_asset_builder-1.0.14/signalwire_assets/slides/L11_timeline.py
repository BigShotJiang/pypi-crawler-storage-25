"""L11: Timeline / Roadmap slide."""
LAYOUT_ID = "L11"
LAYOUT_NAME = "Timeline"
LAYOUT_DESC = "Chronological roadmap with milestones and descriptions."
from .core import *

def L11_timeline(prs, bk, T, logo, title=None, milestones=None, descriptions=None, ai_notes=None):
    S = SlideBuilder(prs, bk, T, logo, ai_notes=ai_notes or "L11 Timeline: chronological roadmap with milestones and descriptions")
    S.title(title or "Timeline headline goes here")
    _ms = milestones or ["Q1 2026", "Q2 2026", "Q3 2026", "Q4 2026"]
    _descs = descriptions or ["Multi-agent\norchestration GA", "Real-time analytics\ndashboard",
              "EU region\ndeployment", "On-premise\noption"]
    S.timeline(_ms, _descs)
    S.done()
