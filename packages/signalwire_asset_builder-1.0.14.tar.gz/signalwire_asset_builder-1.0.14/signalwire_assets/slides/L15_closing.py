"""L15: Closing / Next Steps slide."""
LAYOUT_ID = "L15"
LAYOUT_NAME = "Closing"
LAYOUT_DESC = "Next steps with action items and contact information."
from .core import *

def L15_closing(prs, bk, T, logo, logo_white=None, title=None, actions=None, contact=None, ai_notes=None):
    S = SlideBuilder(prs, bk, T, logo, ai_notes=ai_notes or "L15 Closing: next steps with action items and contact information")
    S.title(title or "Next Steps", size=TITLE_LG, top=2.0)
    items = actions or ["Action item one", "Action item two", "Action item three"]
    S.body(items, top=3.9, left=Inches(3.5), width=Inches(6.3))
    S.text(contact or "your.name@signalwire.com",
           2.5, 6.2, w=8.3, h=0.5, size=20, color="emphasis", align=PP_ALIGN.CENTER)
    S.done()
