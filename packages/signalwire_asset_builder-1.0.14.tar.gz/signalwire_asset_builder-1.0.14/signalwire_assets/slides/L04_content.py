"""L04: Content (Single Message) slide."""
LAYOUT_ID = "L04"
LAYOUT_NAME = "Content"
LAYOUT_DESC = "Assertion headline with 3 supporting bullet points. The workhorse slide."
from .core import *

def L04_content(prs, bk, T, logo, title=None, bullets=None, ai_notes=None):
    S = SlideBuilder(prs, bk, T, logo, ai_notes=ai_notes or "L04 Content: assertion headline with 3 supporting bullet points")
    S.title(title or "State the key takeaway as a sentence")
    S.body(
        bullets or ["First point: 6-8 words max",
         "Second point: supporting evidence",
         "Third point: implication or data"])
    S.done()
