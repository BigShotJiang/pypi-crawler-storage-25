"""L06: Image + Text slide."""
LAYOUT_ID = "L06"
LAYOUT_NAME = "Image + Text"
LAYOUT_DESC = "Visual evidence left with supporting text and bullets right."
from .core import *

def L06_image_text(prs, bk, T, logo, title=None, eyebrow_text=None, bullets=None, image_label=None, ai_notes=None):
    S = SlideBuilder(prs, bk, T, logo, ai_notes=ai_notes or "L06 Image+Text: visual evidence with supporting text and bullets")
    iw = 7.0
    S.image_area(ML, 0.8, iw, 5.5,
                 image_label or "[ Image or screenshot ]")
    rx = ML + Inches(iw) + Inches(0.5)
    rw = CW - Inches(iw) - Inches(0.5)
    S.label(eyebrow_text or "PRODUCT", left=rx, top=1.0)
    S.text(title or "Image slide title goes here",
           rx, 1.4, w=rw, h=1.2, font="h", size=28, bold=True, line_spacing=1.15)
    items = bullets or ["Supporting point one", "Supporting point two", "Supporting point three"]
    S.body(items, top=2.8, left=rx + Inches(0.35), width=rw - Inches(0.4), size=BODY_SM)
    S.done()
