"""L12: Big Number / KPI slide."""
LAYOUT_ID = "L12"
LAYOUT_NAME = "KPI"
LAYOUT_DESC = "Single headline metric at 96pt with context caption."
from .core import *

def L12_kpi(prs, bk, T, logo, metric=None, caption=None, label=None, ai_notes=None):
    S = SlideBuilder(prs, bk, T, logo, ai_notes=ai_notes or "L12 KPI: single headline metric with context caption")
    S.kpi(
        metric or "2.7B",
        caption or "Minutes processed annually",
        label or "KEY METRIC")
    S.done()
