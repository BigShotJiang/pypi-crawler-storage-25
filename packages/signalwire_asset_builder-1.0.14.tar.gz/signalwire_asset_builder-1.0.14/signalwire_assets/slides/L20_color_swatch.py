"""L20: Color Reference swatch sheet."""
LAYOUT_ID = "L20"
LAYOUT_NAME = "Color Reference"
LAYOUT_DESC = "Brand and theme color swatches with hex values."
from .core import *

def L20_color_swatch(prs, bk, T, logo, ai_notes=None):
    """Color swatch reference showing all brand and theme colors."""
    S = SlideBuilder(prs, bk, T, logo, ai_notes=ai_notes or "L20 Color Reference: brand and theme color swatches with hex values")
    S.label("BRAND RESOURCES", top=0.35, color="muted")
    S.title("Color Reference", top=0.65)

    s = S.s
    sw_w = Inches(1.4)
    sw_h = Inches(0.7)
    gap = Inches(0.15)
    start_y = Inches(1.6)

    def swatch_row(y, label, colors_list):
        txt(s, ML, y, Inches(2), Inches(0.3), label, FONT_H, Pt(14), T["emphasis"], bold=True)
        for i, (name, color, hex_str) in enumerate(colors_list):
            x = ML + (sw_w + gap) * i
            sy = y + Inches(0.35)
            rect(s, x, sy, sw_w, sw_h, color)
            txt(s, x, sy + sw_h + Inches(0.02), sw_w, Inches(0.2),
                name, FONT_H, Pt(10), T["text2"], align=PP_ALIGN.CENTER)
            txt(s, x, sy + sw_h + Inches(0.2), sw_w, Inches(0.18),
                hex_str, FONT_B, Pt(8), T["subtle"], align=PP_ALIGN.CENTER)

    swatch_row(start_y, "Brand (Locked)", [
        ("Blue", BLUE, "#044EF4"),
        ("Fuchsia", FUCHSIA, "#F72A72"),
        ("Turquoise", TURQUOISE, "#40E0D0"),
        ("Gold", GOLD, "#FFD700"),
    ])

    def _rgb_hex(c): return "#%02X%02X%02X" % (c[0], c[1], c[2])
    page_bg = LIGHT_PAGE_BG if not T["is_gradient"] else _hex_to_rgb(GRADIENT_STOPS[0][1] if GRADIENT_STOPS else "1E1E1F")
    swatch_row(start_y + Inches(1.6), "Surfaces", [
        ("Page", page_bg, _rgb_hex(page_bg)),
        ("Surface", T["surface"], _rgb_hex(T["surface"])),
        ("Raised", T["raised"], _rgb_hex(T["raised"])),
        ("Footer", T["footer_bg"], _rgb_hex(T["footer_bg"])),
    ])

    swatch_row(start_y + Inches(3.2), "Text", [
        ("Primary", T["text_hi"], "%02X%02X%02X" % (T["text_hi"][0], T["text_hi"][1], T["text_hi"][2])),
        ("Secondary", T["text2"], "%02X%02X%02X" % (T["text2"][0], T["text2"][1], T["text2"][2])),
        ("Muted", T["muted"], "%02X%02X%02X" % (T["muted"][0], T["muted"][1], T["muted"][2])),
        ("Subtle", T["subtle"], "%02X%02X%02X" % (T["subtle"][0], T["subtle"][1], T["subtle"][2])),
        ("Emphasis", T["emphasis"], "%02X%02X%02X" % (T["emphasis"][0], T["emphasis"][1], T["emphasis"][2])),
    ])

    S.done()
