"""L28: Why Now / Market Inflection slide — timing argument with converging forces."""
LAYOUT_ID = "L28"
LAYOUT_NAME = "Why Now"
LAYOUT_DESC = "Market inflection with 3 converging forces that create urgency."
from .core import *

def L28_why_now(prs, bk, T, logo, title=None, forces=None, convergence=None, ai_notes=None):
    S = SlideBuilder(prs, bk, T, logo, ai_notes=ai_notes or "L28 Why Now: market inflection with converging forces that create urgency")
    S.label("MARKET INFLECTION", top=0.35, color="muted")
    S.title(title or "Why now", top=0.65)

    # Three converging forces as cards
    cw_c = Inches(3.65); gap = Inches(0.28); cy = 1.8; ch = 3.0
    _forces = forces or [("AI needs real-time", "Language models can talk but cannot call, route, or govern. They need a control plane."),
                          ("CPaaS hit a ceiling", "Middleware cannot add authority. Retrofitting programmability into closed systems takes years."),
                          ("Developers expect composability", "Modern infrastructure is addressable, declarative, and programmable. Telecom is not. Until now.")]
    accents = [T["emphasis"], BLUE, FUCHSIA]
    for i, (title, body) in enumerate(_forces):
        cx = ML + (cw_c + gap) * i
        S.card(cx, cy, cw_c, ch, accent=accents[i], title=title, title_size=18, body_text=body, body_size=16)

    # Convergence arrow / summary
    S.text(convergence or "These forces converge now. The window is open for a new category.",
           ML, 5.2, w=CW, h=0.6, size=20, color="emphasis", bold=True,
           align=PP_ALIGN.CENTER)
    S.done()
