"""L01: Title / Cover slide."""
LAYOUT_ID = "L01"
LAYOUT_NAME = "Title / Cover"
LAYOUT_DESC = "Opening slide with presentation title and presenter info."
from .core import *

def L01_title(prs, bk, T, logo, title=None, subtitle=None, ai_notes=None):
    S = SlideBuilder(prs, bk, T, logo, ai_notes=ai_notes or "L01 Title/Cover: opening slide with presentation title and presenter info")
    S.title(title or "Presentation Title", large=True, top=2.0)
    S.subtitle(subtitle or "Presenter  |  Role  |  Date", top=4.5)
    S.done()
