"""L07: Full-Bleed Quote slide."""
LAYOUT_ID = "L07"
LAYOUT_NAME = "Quote"
LAYOUT_DESC = "Customer or stakeholder testimonial with attribution."
from .core import *

def L07_quote(prs, bk, T, logo, quote_text=None, name=None, company=None, ai_notes=None):
    S = SlideBuilder(prs, bk, T, logo, ai_notes=ai_notes or "L07 Quote: customer or stakeholder testimonial with attribution")
    S.quote(
        quote_text or "Add a quote here, one to two sentences for impact.",
        name or "Name, Title",
        company or "Company")
    S.done()
