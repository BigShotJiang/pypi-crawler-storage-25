#!/usr/bin/env node
// Renders D2 source (from stdin) to SVG (to stdout)
// Requires: npm install @terrastruct/d2
const { compile, render } = require("@terrastruct/d2");

let input = "";
process.stdin.setEncoding("utf8");
process.stdin.on("data", (chunk) => (input += chunk));
process.stdin.on("end", async () => {
  try {
    const diagram = await compile(input);
    const svg = await render(diagram, { themeID: 200 }); // dark theme
    process.stdout.write(svg);
  } catch (e) {
    process.stderr.write("d2 render error: " + e.message + "\n");
    process.exit(1);
  }
});
