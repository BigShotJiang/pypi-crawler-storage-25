# SignalWire Slide Builder

Build branded SignalWire slide decks from Python. 29 layouts, DTCG design tokens, auto-fit text, dark and light themes.

## Install

```bash
pip install signalwire-slide-builder
```

## Quick start

```python
from signalwire_slides import *

prs = Presentation()
prs.slide_width = SW; prs.slide_height = SH
bk = prs.slide_layouts[6]
lw = svg_to_png(LOGO_WHITE_SVG, width=800)

S = lambda: SlideBuilder(prs, bk, GRAD, lw)

# Title
S().title("Platform Overview", large=True, top=2.0).subtitle("Name | Role | Date").done()

# Content (most common)
s = S(); s.title("Sub-second latency on every call")
s.body(["800ms typical response", "AI at $0.16/min", "2000+ customers"])
s.done()

# KPI
S().kpi("2.7B", "Minutes processed annually").done()

# Use a preset layout
from signalwire_slides import L13_case_study
L13_case_study(prs, bk, GRAD, lw)

prs.save("my_deck.pptx")
```

## CLI

```bash
signalwire-slides                    # both themes, current directory
signalwire-slides --theme dark       # dark only
signalwire-slides -o /tmp            # output to /tmp
```

## 29 layouts

| # | Name | Use for |
|---|------|---------|
| L01 | Title | Opening slide |
| L02 | Section | Section divider |
| L03 | Agenda | Numbered topic list |
| L04 | Content | Assertion headline + 3 bullets |
| L05 | Two-Column | Side-by-side comparison |
| L06 | Image + Text | Visual + supporting text |
| L07 | Quote | Customer testimonial |
| L08 | Chart | Data with assertion headline |
| L09 | Table | Structured data comparison |
| L10 | Process | 4-step chevron flow |
| L11 | Timeline | Horizontal roadmap |
| L12 | KPI | Single big stat |
| L13 | Case Study | Challenge / Solution / Result |
| L14 | Architecture | Diagram placeholder |
| L15 | Closing | Next steps + contact |
| L16 | Appendix | Reference material |
| L21 | Bento Grid | Multi-fact dashboard |
| L22 | Before / After | Problem vs solution |
| L23 | Logo Wall | Customer logos |
| L24 | Metric Dashboard | 4 KPI cards |
| L25 | Full-Bleed Image | Photo with overlay |
| L26 | Team | Photo + name + title |
| L27 | Thesis | Bold claim + 2 proof blocks |
| L28 | Why Now | Market inflection |
| L29 | Competitive | Narrative comparison matrix |
| L30 | How It Works | Layered systems diagram |
| L17/L18 | Blank | Dark/light blank |
| L19 | Icon Reference | Brand icon grid |
| L20 | Color Reference | Brand color swatches |

## Auto-fit

Text automatically shrinks if too wide for its container. Warnings print when shrinking occurs so you know to tighten the copy.

## License

MIT
