"""Backward-compat shim. Use signalwire_assets.slides instead."""
import warnings
warnings.warn(
    "signalwire_slides is deprecated. Use signalwire_assets.slides",
    DeprecationWarning, stacklevel=2,
)
from signalwire_assets.slides import *  # noqa: F401,F403
from signalwire_assets.slides import __version__  # noqa: F401
