"""Backward-compat shim. Use signalwire-assets CLI instead."""
from signalwire_assets.__main__ import main  # noqa: F401
