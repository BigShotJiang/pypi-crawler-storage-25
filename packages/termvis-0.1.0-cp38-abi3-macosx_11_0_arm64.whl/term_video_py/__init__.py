from .term_video_py import *

__doc__ = term_video_py.__doc__
if hasattr(term_video_py, "__all__"):
    __all__ = term_video_py.__all__