"""AgentsMD - Intelligent workspace scaffolding and file synchronization."""
__version__ = "1.0.3"
