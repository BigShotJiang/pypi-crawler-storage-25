# AgentsMD

CLI tool for scaffolding and syncing AI agent workspace configuration files.

## Installation

```bash
pip install agentsmd
```

## Quick Start

```bash
# Initialize a new workspace
agentsmd init

# Sync workspace across machines
agentsmd sync

# Check sync status
agentsmd status

# Authenticate
agentsmd login
```

## Features

- **Workspace Scaffolding** — Interactive interview to generate AGENTS.md, CLAUDE.md, .cursorrules, and more
- **Cross-Tool Sync** — Convert between AI tool config formats (Claude Code, Cursor, Copilot, Windsurf)
- **Format Migration** — Migrate existing config files between formats
- **Reconciliation** — Re-derive all tool formats from a single source of truth

## Commands

| Command | Description |
|---------|-------------|
| `agentsmd init` | Initialize a new workspace with interactive setup |
| `agentsmd sync` | Synchronize workspace to/from cloud storage |
| `agentsmd status` | Show workspace synchronization status |
| `agentsmd login` | Authenticate via API token |
| `agentsmd logout` | Clear local credentials |
| `agentsmd migrate` | Convert between AI tool config formats |
| `agentsmd reconcile` | Re-derive all tool config formats from source of truth |
| `agentsmd tool-list` | Show detected AI tools in this workspace |
| `agentsmd tool-add` | Register a custom AI tool interactively |

## Supported AI Tools

- Claude Code (CLAUDE.md)
- Cursor (.cursorrules)
- GitHub Copilot (.github/copilot-instructions.md)
- Windsurf (.windsurfrules)
- AGENTS.md (universal format)

## Requirements

- Python 3.13+
