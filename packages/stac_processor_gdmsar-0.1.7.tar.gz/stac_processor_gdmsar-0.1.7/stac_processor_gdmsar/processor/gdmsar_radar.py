import logging
import stac_processor_gdmsar.processor.gdmsar_items_list as items
from stac_processor_gdmsar.processor.utils import extract_date_intervals, get_sublist_by_tags
from stac_processor_gdmsar.processor.gdmsar_collection import GDMCollection

logger = logging.getLogger(__name__)

class GDMRadarExtra(GDMCollection):
    def __init__(self, main_id: str, files: list[str]) -> None:
        super().__init__(
            main_id=main_id,
            folder_name="extra_text_files_collection",
            files=files,
            title=f"Extra text files from run {main_id} in radar geometry",
            codes=["extra"], geometry="RADAR", 
            template_list=["extra_text_files.md"], 
            default_keywords=["extra text files"]
        )


class GDMRadarAux(GDMCollection):
    def __init__(self, main_id: str, files: list[str]) -> None:
        super().__init__(
            main_id=main_id,
            folder_name="auxiliary_data_collection",
            files=files,
            title=f"The auxiliary data collection from run {main_id} in radar geometry",
            codes=[], geometry="RADAR", 
            template_list=["auxiliary_data_collection.md"], 
            child_items=[
                items.GDMRadarDEM(main_id, files),
                items.GDMRadarTCoh(main_id, files),
                items.GDMRadarCosEnu(main_id, files),
                items.GDMRadarCosNeu(main_id, files),
                # lookup tables for both geo and radar geometries are stored here on purpose
                items.GDMGeoLut(main_id, files),
                items.GDMRadarLut(main_id, files)
            ],
            child_collections=[
                GDMRadarExtra(main_id, files),
            ], 
        )

class GDMRadarDateInterval(GDMCollection):
    def __init__(self, main_id: str, date: str, files: list[str]) -> None:
        super().__init__(
            main_id=main_id,
            folder_name=f"interferogram_date_interval_{date}_collection",
            files=files,
            title=f"Interferograms Collection for the date interval {date} for {main_id} in radar geometry",
            geometry="RADAR", # no assets for this collection
            date=date,
            template_list=["interferogram.md"], 
            child_items=[
                items.GDMRadarCoh(main_id, files, date=date),
                items.GDMRadarInW(main_id, files, date=date),
                items.GDMRadarInWF(main_id, files, date=date),
                items.GDMRadarInU(main_id, files, date=date)
            ], 
        )
    
class GDMRadarInterferograms(GDMCollection):
    def __init__(self, main_id: str, files: list[str]) -> None:
        # extract the date intervals from the file names
        interferogram_files = get_sublist_by_tags(files, ["_Coh_radar_", "_InW_radar_", "_InWF_radar_", "_INU_radar_"])
        date_intervals = extract_date_intervals(interferogram_files)
        date_interval_collections = []
        for date_interval in date_intervals:
            date_interval_collections.append(GDMRadarDateInterval(main_id, date_interval, files))
        # call the super constructor
        super().__init__(
            main_id=main_id,
            folder_name="interferogram_collection",
            files=files,
            title=f"Interferograms collection from run {main_id} in radar geometry",
            geometry="RADAR", # no assets for this collection
            template_list=["interferogram_collection.md"], 
            child_collections=date_interval_collections, 
        )


class GDMRadarInversionParameter(GDMCollection):
    def __init__(self, main_id: str, files: list[str]) -> None:
        super().__init__(
            main_id=main_id,
            folder_name="inversion_parameter_collection",
            files=files,
            title=f"Inversion parameters from run {main_id} in radar geometry",
            codes=["inversion"], geometry="RADAR", 
            template_list=["inversion_parameters.md"],
            default_keywords=["inversion parameter"]
        )

class GDMRadarTimeSerie(GDMCollection):
    def __init__(self, main_id: str, files: list[str]) -> None:
        super().__init__(
            main_id=main_id,
            folder_name="time_serie_collection",
            files=files,
            title=f"Time Series collection from run {main_id} in radar geometry",
            codes=[], geometry="RADAR", 
            template_list=["time_series.md"], 
            child_items=[
                items.GDMRadarDts(main_id, files),
                items.GDMRadarNet(main_id, files),
                items.GDMRadarMvlos(main_id, files)
            ],
            child_collections=[
                GDMRadarInversionParameter(main_id, files)
            ], 
        )

class GDMRadar(GDMCollection):
    def __init__(self, main_id: str, files: list[str]) -> None:
        super().__init__(
            main_id=main_id,
            folder_name="radar_collection",
            files=files,
            title=f"Run {main_id} from the GDM-SAR-In processing pipeline in radar geometry",
            geometry="RADAR", # no assets for this collection
            template_list=["run_geocoded_radar_collection.md"], 
            child_collections=[
                GDMRadarAux(main_id, files),
                GDMRadarInterferograms(main_id, files),
                GDMRadarTimeSerie(main_id, files)
            ], 
        )

