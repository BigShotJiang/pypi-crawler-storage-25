from datetime import datetime
import logging
import pystac

from stac_processor_gdmsar.processor.gdmsar_element import GDMElement
import stac_processor_gdmsar.metadata.common_metadata as metadata
import stac_processor_gdmsar.metadata.extensions as extensions
import stac_processor_gdmsar.metadata.templates as templates

logger = logging.getLogger(__name__)

class GDMItem(GDMElement):
    json_files: dict = {} # contains the content of all the json files associated to this element
    json: dict = None # this will contain the content of the future stac file

    def __init__(self, main_id: str, folder_name: str, files: list[str], codes: list[str], geometry: str, date: str = "", resolution: str = "", default_keywords: list[str] = None) -> None:
        # store the information, but wait until the parent collection is created to create the stac item, because we need the collection id to create the item id and to extract the keywords from the templates
        self.main_id = main_id
        self.file_name = f"{folder_name}.json"
        self.folder_name = folder_name
        self.files = files
        self.codes = codes
        self.geometry = geometry
        self.date = date
        self.resolution = resolution
        self.default_keywords = default_keywords

    def generate_stac_object(self, collection_id: str):
        # this function can be used to generate the stac item after the properties have been updated, for example to update the keywords after creating the item
        # self.json_files = products.get_json_files(self.files, self.codes, self.geometry)
        self.json_files = templates.get_json_files(self.files, self.codes, self.geometry)
        # it's possible that there are no files corresponding to this code and geometry, in this case we will not create a stac item
        if len(self.json_files) == 0:
            logger.debug(f"No json files found for item in folder {self.folder_name} with codes {self.codes} and geometry {self.geometry}. Skipping item creation.")
            return
        self.stac_id = collection_id.replace("_collection", "") + "_" + self.codes[0]
        self.processing_id=self.get_processing_id()
        self.keywords = templates.get_keywords(self.files, self.codes, self.geometry, self.default_keywords, _id=self.stac_id, _processing_id=self.processing_id, date=self.date)
        assets = templates.get_assets(self.files, self.codes, self.geometry, self.date, self.resolution, _id=self.stac_id, _processing_id=self.processing_id)

        self.title = templates.get_title(self.codes[0], self.geometry) + " for " + self.main_id
        self.description = templates.get_description(self.codes[0], self.geometry, _id=self.stac_id, _processing_id=self.processing_id, date=self.date)
        self.update_properties()

        # create the stac item
        self.stac_object = pystac.Item(
            id=self.stac_id, 
            geometry=self.get_geometry(), 
            bbox=self.get_bbox(), 
            properties=self.get_properties(),
            datetime=self.get_datetime(), 
            assets = assets if len(assets) > 0 else None,
        )
        # add links to the stac item
        self.add_common_links()
        logger.debug(f"Stac item {self.stac_id} created with {len(assets)} assets")
        

    def update_properties(self):
        # use the content from the original json file as much as possible
        if len(self.json_files) > 0:
            # take the first json file as a base, but some fields can be extracted from the others if they are not present in the first one
            self.json = list(self.json_files.values())[0]
            # at this point, we know that self.json has a "properties" field
            updated_properties = self.json["properties"].copy()
            # change the title, description, etc.
            updated_properties["uuid"] = self.main_id
            updated_properties["title"] = self.title
            updated_properties["description"] = self.description
            providers_json = []
            for provider in metadata.providers:
                providers_json.append({
                    "name": provider.name,
                    "description": provider.description,
                    "roles": [role.value for role in provider.roles],
                    "url": provider.url,
                })
            updated_properties["providers"] = providers_json
            updated_properties["platforms"] = metadata.platforms
            updated_properties["instruments"] = metadata.instruments
            updated_properties["constellation"] = metadata.constellation
            updated_properties["mission"] = metadata.mission
            updated_properties["licenses"] = metadata.license_name
            # add the extensions
            updated_properties.update(extensions.get_sat_extension_properties(self.json))
            updated_properties.update(extensions.get_sar_extension_properties(self.json))
            updated_properties.update(extensions.get_processing_extension_properties(self.json))
            updated_properties.update(extensions.get_insar_extension_properties(self.json))
            updated_properties.update(extensions.get_projection_extension_properties(self.json))
            updated_properties.update(extensions.get_scientific_extension_properties(self.json))
            # if pystac does not do it, add the links and the stac version
            self.json["properties"] = updated_properties
            # if the properties contain a "sat:orbit_state" field, we can add its value to the keywords
            if "sat:orbit_state" in updated_properties:
                self.keywords.append(updated_properties["sat:orbit_state"])

    def get_processing_id(self) -> str:
        # search in all the json files for a processing id in the properties, quit as soon as we find one
        for json in self.json_files.values():
            if "properties" in json and "processingId" in json["properties"]:
                return json["properties"]["processingId"]
        logger.warning(f"No processingId found in the json files for item {self.stac_id}")
        return "" # this should not happen, but we need to return something

    def get_geometry(self) -> dict: return self.json["geometry"] if "geometry" in self.json else {}
    def get_bbox(self) -> list[float]: return self.json["bbox"] if "bbox" in self.json else []
    def get_properties(self) -> dict: return self.json["properties"] if "properties" in self.json else {}
    def get_datetime(self) -> datetime: 
        for field in ["created", "updated", "datetime", "start_datetime"]:
            try:
                return datetime.fromisoformat(self.json["properties"][field])
            except:
                continue
        return None

    def update_keywords(self, keywords: list[str]):
        # updates the current list of keywords with keywords from the parent collection, without duplicates
        current_keywords = set(self.keywords)
        parent_keywords = set(keywords)
        self.keywords = list(current_keywords.union(parent_keywords))
        if self.stac_object is not None:
            self.stac_object.properties["keywords"] = self.keywords
