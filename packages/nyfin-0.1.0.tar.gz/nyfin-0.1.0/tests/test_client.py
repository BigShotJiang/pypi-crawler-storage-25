"""nyfin SDK tests — lightweight subset suitable for any egress.

This module covers:
  - Manifest correctness (no network)
  - Local input validation (no network)
  - Discovery endpoints — hits the Worker only, no upstream fetch, won't trip CF

The full 12-endpoint round-trip smoke lives in tests/test_full_smoke.py and is
intended to run from a fresh egress (DigitalOcean droplet / EC2 / Lambda) to
avoid the per-IP rate limit on the upstream NYSE host.
"""
from __future__ import annotations
import unittest

from nyfin_client import Client, NyfinError, NyfinValidationError, quote
from nyfin_client._manifest import MANIFEST


class TestManifest(unittest.TestCase):
    def test_manifest_has_12_endpoints(self):
        self.assertEqual(MANIFEST["endpoint_count"], 12)
        self.assertEqual(len(MANIFEST["endpoints"]), 12)

    def test_manifest_families(self):
        families = MANIFEST["by_family"]
        self.assertIn("quote", families)
        self.assertIn("etf", families)
        self.assertIn("regulatory", families)
        self.assertIn("corporate_actions", families)
        self.assertIn("dividends", families)
        self.assertIn("search", families)

    def test_no_raw_passthrough(self):
        """No /v1/raw/ endpoint should be present in the manifest or on the client."""
        c = Client()
        self.assertFalse(hasattr(c, "raw"))
        for ep in MANIFEST["endpoints"]:
            self.assertFalse(ep["path"].startswith("/v1/raw"))

    def test_each_manifest_endpoint_has_a_method(self):
        """Every shipped endpoint must be reachable through a SDK method."""
        c = Client()
        expected = {
            "nyse.quote.snapshot": "quote",
            "nyse.quote.resolve": "quote_resolve",
            "nyse.quote.screener": "quote_screener",
            "nyse.corpax": "corporate_actions",
            "nyse.dividends.ex_dates": "dividends_ex_dates",
            "nyse.etf.quote": "etf_quote",
            "nyse.etf.price": "etf_price",
            "nyse.etf.most_popular": "etf_most_popular",
            "nyse.etf.market_state": "etf_market_state",
            "nyse.regulatory.noncompliant_directory": "noncompliant_directory",
            "nyse.regulatory.noncompliant_lookup": "noncompliant_lookup",
            "nyse.search": "search",
        }
        manifest_ids = {ep["id"] for ep in MANIFEST["endpoints"]}
        self.assertEqual(set(expected), manifest_ids)
        for method in expected.values():
            self.assertTrue(hasattr(c, method), f"Client missing method {method}")


class TestLocalValidation(unittest.TestCase):
    """Local input validation raises before any HTTP request."""

    def setUp(self):
        self.client = Client()

    def test_empty_symbol_quote(self):
        with self.assertRaises(ValueError):
            self.client.quote("")

    def test_empty_symbol_quote_resolve(self):
        with self.assertRaises(ValueError):
            self.client.quote_resolve("")

    def test_empty_instrument_type(self):
        with self.assertRaises(ValueError):
            self.client.quote_screener("")

    def test_empty_search_query(self):
        with self.assertRaises(ValueError):
            self.client.search("")

    def test_empty_corpax_dates(self):
        with self.assertRaises(ValueError):
            self.client.corporate_actions("", "2026-12-31")
        with self.assertRaises(ValueError):
            self.client.corporate_actions("2026-04-01", "")


class TestDiscovery(unittest.TestCase):
    """Discovery endpoints serve from the Worker only — no upstream fetch."""

    def setUp(self):
        self.client = Client()

    def test_endpoints(self):
        body = self.client.endpoints()
        self.assertEqual(body["version"], "0.1.0")
        self.assertEqual(len(body["records"]), 12)
        ids = {r["id"] for r in body["records"]}
        self.assertIn("nyse.quote.snapshot", ids)
        self.assertIn("nyse.corpax", ids)

    def test_openapi(self):
        body = self.client.openapi()
        self.assertEqual(body["openapi"], "3.1.0")
        self.assertIn("paths", body)
        self.assertIn("/v1/quote", body["paths"])

    def test_health(self):
        body = self.client.health()
        self.assertEqual(body["status"], "ok")
        self.assertEqual(body["version"], "0.1.0")


class TestExports(unittest.TestCase):
    def test_module_top_level(self):
        from nyfin_client import Client as C, NyfinError as E
        self.assertIsNotNone(C)
        self.assertTrue(issubclass(E, RuntimeError))

    def test_compat_alias(self):
        from nyfin import Client as C
        from nyfin.client import Client as C2
        self.assertIs(C, C2)


if __name__ == "__main__":
    unittest.main()
