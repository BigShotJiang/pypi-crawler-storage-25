"""Full 12-endpoint live smoke test for the nyfin SDK.

Hits every shipped endpoint with a representative input and validates the
{data, meta} envelope. Intended to run from a fresh egress (DigitalOcean droplet
/ AWS Lambda / EC2) to avoid the per-IP rate-limit on www.nyse.com.

Run from local box only after the upstream has cooled down (~5 min idle):
    PYTHONPATH=src python3 -m unittest tests.test_full_smoke

Skip via env var if needed:
    NYFIN_SKIP_FULL_SMOKE=1 python3 -m unittest discover -s tests
"""
from __future__ import annotations
import os
import time
import unittest

from nyfin_client import Client


SKIP = os.environ.get("NYFIN_SKIP_FULL_SMOKE")


@unittest.skipIf(SKIP, "NYFIN_SKIP_FULL_SMOKE=1 set")
class TestFullSmoke(unittest.TestCase):
    """One request per endpoint, paced to avoid CF rate limit."""

    @classmethod
    def setUpClass(cls):
        cls.client = Client()
        cls.pace = float(os.environ.get("NYFIN_PACE_SECONDS", "1.5"))

    def setUp(self):
        time.sleep(self.pace)

    def _check_envelope(self, body, endpoint_id):
        self.assertIn("data", body, f"{endpoint_id} missing data")
        self.assertIn("meta", body, f"{endpoint_id} missing meta")
        self.assertEqual(body["meta"]["endpoint_id"], endpoint_id)
        self.assertIn(body["meta"]["served_from"], ("origin", "cache", "stale", "origin-revalidate"))

    def test_01_quote_snapshot(self):
        body = self.client.quote("IBM")
        self._check_envelope(body, "nyse.quote.snapshot")
        self.assertIn("quote", body["data"])

    def test_02_quote_resolve(self):
        body = self.client.quote_resolve("IBM", "XNYS")
        self._check_envelope(body, "nyse.quote.resolve")

    def test_03_quote_screener(self):
        body = self.client.quote_screener("EQUITY", page=1, page_size=5)
        self._check_envelope(body, "nyse.quote.screener")

    def test_04_corporate_actions(self):
        body = self.client.corporate_actions("2026-04-01", "2026-12-31", page=1, page_size=5)
        self._check_envelope(body, "nyse.corpax")
        self.assertIn("results", body["data"])

    def test_05_dividends_ex_dates(self):
        body = self.client.dividends_ex_dates()
        self._check_envelope(body, "nyse.dividends.ex_dates")

    def test_06_etf_quote(self):
        body = self.client.etf_quote("SPY")
        self._check_envelope(body, "nyse.etf.quote")

    def test_07_etf_price(self):
        body = self.client.etf_price("SPY")
        self._check_envelope(body, "nyse.etf.price")

    def test_08_etf_most_popular(self):
        body = self.client.etf_most_popular()
        self._check_envelope(body, "nyse.etf.most_popular")

    def test_09_etf_market_state(self):
        body = self.client.etf_market_state()
        self._check_envelope(body, "nyse.etf.market_state")

    def test_10_noncompliant_directory(self):
        body = self.client.noncompliant_directory(page_size=5)
        self._check_envelope(body, "nyse.regulatory.noncompliant_directory")

    def test_11_noncompliant_lookup(self):
        body = self.client.noncompliant_lookup("ALUR")
        self._check_envelope(body, "nyse.regulatory.noncompliant_lookup")

    def test_12_search(self):
        body = self.client.search("IBM")
        self._check_envelope(body, "nyse.search")


if __name__ == "__main__":
    unittest.main()
