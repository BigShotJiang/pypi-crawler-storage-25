"""Python SDK for the hosted nyfin NYSE finance data API."""

from nyfin_client import (
    Client,
    NyfinClient,
    NyfinError,
    NyfinRateLimitError,
    NyfinValidationError,
    corporate_actions,
    dividends_ex_dates,
    etf_quote,
    quote,
    search,
)

__all__ = [
    "Client",
    "NyfinClient",
    "NyfinError",
    "NyfinRateLimitError",
    "NyfinValidationError",
    "corporate_actions",
    "dividends_ex_dates",
    "etf_quote",
    "quote",
    "search",
]
__version__ = "0.1.0"
