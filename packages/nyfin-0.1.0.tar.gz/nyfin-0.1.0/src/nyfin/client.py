"""Compatibility shim for `from nyfin.client import Client`."""

from nyfin_client.client import *  # noqa: F401,F403
