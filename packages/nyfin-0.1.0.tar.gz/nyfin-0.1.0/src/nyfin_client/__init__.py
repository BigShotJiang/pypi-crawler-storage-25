"""Unofficial client for the hosted nyfin NYSE data API."""

from .client import (
    Client,
    NyfinClient,
    NyfinError,
    NyfinRateLimitError,
    NyfinValidationError,
    corporate_actions,
    dividends_ex_dates,
    etf_quote,
    quote,
    search,
)

__all__ = [
    "Client",
    "NyfinClient",
    "NyfinError",
    "NyfinRateLimitError",
    "NyfinValidationError",
    "corporate_actions",
    "dividends_ex_dates",
    "etf_quote",
    "quote",
    "search",
]
__version__ = "0.1.0"
