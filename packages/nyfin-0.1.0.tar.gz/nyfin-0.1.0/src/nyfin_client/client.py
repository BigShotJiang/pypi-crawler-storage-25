"""nyfin Python SDK — typed thin REST client.

Contract: hosted at https://api.nyfin.bluedoor.sh. The Worker exposes 12 friendly
endpoints + 4 discovery routes. This client wraps every shipped endpoint as a
typed method. There is no raw passthrough.
"""
from __future__ import annotations

import json
import os
import ssl
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from typing import Any, Mapping

DEFAULT_BASE_URL = os.environ.get("NYFIN_BASE_URL", "https://api.nyfin.bluedoor.sh")
SDK_VERSION = "0.1.0"


class NyfinError(RuntimeError):
    """Base exception for nyfin client errors."""


class NyfinRateLimitError(NyfinError):
    """Raised when the API returns HTTP 429."""


class NyfinValidationError(NyfinError):
    """Raised when the API returns HTTP 400 for input that didn't pass schema validation."""


@dataclass(frozen=True)
class _Response:
    status: int
    headers: Mapping[str, str]
    body: bytes


class Client:
    """nyfin REST client.

    Identity tiers (`contact`, `api_key`) are not yet enforced server-side in
    v0.1.0 (hosted API is anonymous-only). Headers are included for forward
    compatibility with v0.2.0 which will introduce contact + key tiers.
    """

    def __init__(
        self,
        *,
        base_url: str | None = None,
        contact: str | None = None,
        api_key: str | None = None,
        timeout: float = 20.0,
        session: Any = None,
    ) -> None:
        self.base_url = (base_url or DEFAULT_BASE_URL).rstrip("/")
        self.contact = contact or os.environ.get("NYFIN_CONTACT")
        self.api_key = api_key or os.environ.get("NYFIN_API_KEY")
        self.timeout = timeout
        self.session = session

    # ----- discovery -----

    def endpoints(self) -> dict[str, Any]:
        """Return the public endpoint manifest (`/v1/endpoints`)."""
        return self._get("/v1/endpoints")

    def openapi(self) -> dict[str, Any]:
        """Return the OpenAPI 3.1 document (`/v1/openapi.json`)."""
        return self._get("/v1/openapi.json")

    def health(self) -> dict[str, Any]:
        """Return service health (`/v1/health`)."""
        return self._get("/v1/health")

    # ----- quote family -----

    def quote(self, symbol: str) -> dict[str, Any]:
        """Quote snapshot for a NYSE symbol.

        Returns the full 88-path payload: quote, quoteHistory, boardMember,
        totalReturns, options, trends.
        """
        return self._get("/v1/quote", params={"symbol": _required_symbol(symbol)})

    def quote_resolve(self, symbol: str, mic_code: str = "XNYS") -> dict[str, Any]:
        """Resolve a normalized ticker on a market to a canonical NYSE row.

        `mic_code` defaults to `XNYS`. Other markets: ARCX, XASE, XNAS.
        """
        return self._post(
            "/v1/quote/resolve",
            body={"symbol": _required_symbol(symbol), "mic_code": _required_text(mic_code, "mic_code")},
        )

    def quote_screener(
        self,
        instrument_type: str,
        *,
        sort_column: str = "NORMALIZED_TICKER",
        sort_order: str = "ASC",
        page: int = 1,
        page_size: int = 25,
        filter_token: str = "",
    ) -> dict[str, Any]:
        """Paginated NYSE quote directory filtered by instrument type.

        `instrument_type` must be one of:
            EQUITY, INDEX, WARRANT, RIGHT, CLOSED_END_FUND, REIT, UNIT, TRUST.
        Other values (STOCK, ETF, ETN, BOND, OPTION, IPO, ADR, etc.) are
        silently empty upstream — the server validates and rejects them.
        """
        body = {
            "instrument_type": _required_text(instrument_type, "instrument_type").upper(),
            "sort_column": sort_column,
            "sort_order": sort_order,
            "page": int(page),
            "page_size": int(page_size),
            "filter_token": filter_token,
        }
        return self._post("/v1/quote/screener", body=body)

    # ----- corporate actions / dividends -----

    def corporate_actions(
        self,
        from_date: str,
        to_date: str,
        *,
        page: int = 1,
        page_size: int = 50,
    ) -> dict[str, Any]:
        """Paginated corporate-actions feed.

        `from_date` and `to_date` are ISO `YYYY-MM-DD`.
        """
        return self._get(
            "/v1/corporate-actions",
            params={
                "from_date": _required_text(from_date, "from_date"),
                "to_date": _required_text(to_date, "to_date"),
                "page": int(page),
                "page_size": int(page_size),
            },
        )

    def dividends_ex_dates(self) -> dict[str, Any]:
        """Upcoming and recent dividend ex-dates from NYSE Listing Manager."""
        return self._get("/v1/dividends/ex-dates")

    # ----- ETF Central -----

    def etf_quote(self, symbol: str, *, mic_code: str = "ARCX", timezone: str = "America/New_York") -> dict[str, Any]:
        """ETF Central JSON quote for a NYSE-listed ETF symbol."""
        return self._get(
            "/v1/etf/quote",
            params={"symbol": _required_symbol(symbol), "mic_code": mic_code, "timezone": timezone},
        )

    def etf_price(self, symbol: str, *, mic_code: str = "ARCX") -> dict[str, Any]:
        """ETF Central JSON price for a NYSE-listed ETF symbol."""
        return self._get(
            "/v1/etf/price",
            params={"symbol": _required_symbol(symbol), "mic_code": mic_code},
        )

    def etf_most_popular(self) -> dict[str, Any]:
        """ETF Central curated list of most-popular ETFs."""
        return self._get("/v1/etf/most-popular")

    def etf_market_state(self) -> dict[str, Any]:
        """ETF Central state-of-the-market commentary."""
        return self._get("/v1/etf/market-state")

    # ----- regulatory -----

    def noncompliant_directory(
        self,
        *,
        market: str = "NYSE",
        page: int = 1,
        page_size: int = 25,
        offset: int = 0,
    ) -> dict[str, Any]:
        """Paginated directory of NYSE noncompliant issuers."""
        return self._get(
            "/v1/regulatory/noncompliant",
            params={"market": market, "page": int(page), "page_size": int(page_size), "offset": int(offset)},
        )

    def noncompliant_lookup(self, symbol: str) -> dict[str, Any]:
        """Per-symbol noncompliant-issuer lookup. Compliant symbols return empty array."""
        clean = _required_symbol(symbol)
        return self._get(f"/v1/regulatory/noncompliant/{urllib.parse.quote(clean, safe='')}")

    # ----- search -----

    def search(self, q: str, *, collection: str = "nyse_quotes", page: int = 1) -> dict[str, Any]:
        """Site search across NYSE.com content.

        `collection` ∈ {nyse_quotes, nyse_pages_cms2, nyse_uploadedfiles, nyse_appurls}.
        """
        return self._get(
            "/v1/search",
            params={"q": _required_text(q, "q"), "collection": collection, "page": int(page)},
        )

    # ----- transport -----

    def _get(self, path: str, *, params: Mapping[str, Any] | None = None) -> dict[str, Any]:
        return self._request("GET", path, params=params)

    def _post(self, path: str, *, body: Any) -> dict[str, Any]:
        return self._request("POST", path, body=body)

    def _request(
        self,
        method: str,
        path: str,
        *,
        params: Mapping[str, Any] | None = None,
        body: Any = None,
    ) -> dict[str, Any]:
        url = self._build_url(path, params=params)
        headers = {
            "accept": "application/json",
            "user-agent": f"nyfin-python/{SDK_VERSION}",
        }
        encoded_body: bytes | None = None
        if body is not None:
            encoded_body = json.dumps(body).encode("utf-8")
            headers["content-type"] = "application/json"
        if self.contact:
            headers["x-nyfin-contact"] = self.contact
        if self.api_key:
            headers["authorization"] = f"Bearer {self.api_key}"

        resp = self._send(method.upper(), url, headers, encoded_body)
        if resp.status == 429:
            raise NyfinRateLimitError(_error_message(resp))
        if resp.status == 400:
            raise NyfinValidationError(_error_message(resp))
        if resp.status >= 400:
            raise NyfinError(_error_message(resp))
        try:
            data = json.loads(resp.body.decode("utf-8"))
        except json.JSONDecodeError as exc:
            raise NyfinError(f"invalid JSON response: {exc}") from exc
        if not isinstance(data, dict):
            raise NyfinError("invalid JSON response: expected object")
        return data

    def _build_url(self, path: str, *, params: Mapping[str, Any] | None = None) -> str:
        url = f"{self.base_url}{path if path.startswith('/') else '/' + path}"
        query: dict[str, Any] = {}
        if params:
            for k, v in params.items():
                if v is None or v == "":
                    continue
                query[k] = v
        if query:
            url = f"{url}?{urllib.parse.urlencode(query, doseq=True)}"
        return url

    def _send(
        self,
        method: str,
        url: str,
        headers: Mapping[str, str],
        body: bytes | None,
    ) -> _Response:
        # Optional curl_cffi-style session (matching cfin pattern)
        if self.session is not None:
            try:
                response = self.session.request(
                    method, url, headers=dict(headers), data=body, timeout=self.timeout, impersonate="chrome",
                )
                return _Response(response.status_code, dict(response.headers), response.content)
            except TypeError:
                response = self.session.request(
                    method, url, headers=dict(headers), data=body, timeout=self.timeout,
                )
                return _Response(response.status_code, dict(response.headers), response.content)
            except Exception as exc:
                raise NyfinError(f"could not reach nyfin API: {exc}") from exc

        req = urllib.request.Request(url, data=body, headers=dict(headers), method=method)
        try:
            with urllib.request.urlopen(req, timeout=self.timeout, context=_ssl_context()) as response:
                return _Response(response.status, dict(response.headers), response.read())
        except urllib.error.HTTPError as exc:
            return _Response(exc.code, dict(exc.headers), exc.read())
        except urllib.error.URLError as exc:
            raise NyfinError(f"could not reach nyfin API: {exc}") from exc


# Public alias matching naming convention used by other -fin SDKs.
NyfinClient = Client


# Module-level convenience constructors
def quote(symbol: str) -> dict[str, Any]:
    return Client().quote(symbol)


def corporate_actions(from_date: str, to_date: str, **params: Any) -> dict[str, Any]:
    return Client().corporate_actions(from_date, to_date, **params)


def dividends_ex_dates() -> dict[str, Any]:
    return Client().dividends_ex_dates()


def etf_quote(symbol: str, **params: Any) -> dict[str, Any]:
    return Client().etf_quote(symbol, **params)


def search(q: str, **params: Any) -> dict[str, Any]:
    return Client().search(q, **params)


# ----- helpers -----

def _required_text(value: object, name: str) -> str:
    clean = str(value).strip()
    if not clean:
        raise ValueError(f"{name} must not be empty")
    return clean


def _required_symbol(value: str) -> str:
    return _required_text(value, "symbol").upper()


def _error_message(response: _Response) -> str:
    text = response.body.decode("utf-8", errors="replace")
    try:
        parsed = json.loads(text)
        if isinstance(parsed, dict):
            msg = parsed.get("message") or parsed.get("error") or text[:200]
            field = parsed.get("field")
            if field:
                return f"HTTP {response.status}: {msg} (field={field})"
            return f"HTTP {response.status}: {msg}"
    except json.JSONDecodeError:
        pass
    return f"HTTP {response.status}: {text[:200]}"


def _ssl_context() -> ssl.SSLContext:
    try:
        import certifi  # type: ignore
        return ssl.create_default_context(cafile=certifi.where())
    except Exception:
        return ssl.create_default_context()
