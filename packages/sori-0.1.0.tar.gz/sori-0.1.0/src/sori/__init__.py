def hello() -> str:
    return "Hello from sori!"
