# keypledge

Cooperative API key pooling for AI teams.
