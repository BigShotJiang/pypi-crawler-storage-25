|Docs| |Tests| |Linter| |PythonV| |Pypi| |Codecov| |Zenodo| |Binder|

.. |Docs| image:: https://github.com/NatLabRockies/reV/workflows/Documentation/badge.svg
    :target: https://natlabrockies.github.io/reV/

.. |Tests| image:: https://github.com/NatLabRockies/reV/workflows/Pytests/badge.svg
    :target: https://github.com/NatLabRockies/reV/actions?query=workflow%3A%22Pytests%22

.. |Linter| image:: https://github.com/NatLabRockies/reV/workflows/Lint%20Code%20Base/badge.svg
    :target: https://github.com/NatLabRockies/reV/actions?query=workflow%3A%22Lint+Code+Base%22

.. |PythonV| image:: https://img.shields.io/pypi/pyversions/NLR-reV.svg
    :target: https://pypi.org/project/NLR-reV/

.. |Pypi| image:: https://badge.fury.io/py/NLR-reV.svg
    :target: https://badge.fury.io/py/NLR-reV

.. |Codecov| image:: https://codecov.io/gh/NatLabRockies/reV/branch/main/graph/badge.svg?token=U4ZU9F0K0Z
    :target: https://codecov.io/gh/NatLabRockies/reV

.. |Zenodo| image:: https://zenodo.org/badge/201343076.svg
   :target: https://zenodo.org/badge/latestdoi/201343076

.. |Binder| image:: https://mybinder.org/badge_logo.svg
    :target: https://mybinder.org/v2/gh/NatLabRockies/reV/HEAD

|

.. inclusion-intro

**reV** is an open-source geospatial techno-economic tool that
estimates energy technical potential (capacity and generation),
system cost, and supply curves for a variety of technologies, including
but not limited to, geothermal (GT), pumped storage hydropower (PSH),
solar photovoltaics (PV), concentrating solar power (CSP), wind energy, etc.
reV allows researchers to include exhaustive spatial representation
of the built and natural environment into the generation and cost estimates
that it computes.

reV is highly dynamic, allowing analysts to assess potential at varying levels
of detail — from a single site up to an entire continent at temporal resolutions
ranging from five minutes to hourly, spanning a single year or multiple decades.
The reV model can (and has been used to) provide broad coverage across large spatial
extents, including North America, South and Central Asia, the Middle East, South America,
and South Africa to inform national and international-scale analyses. Still, reV is
equally well-suited for regional infrastructure and deployment planning and analysis.


For a detailed description of reV capabilities and functionality, see the
`NLR reV technical report <https://www.nlr.gov/docs/fy19osti/73067.pdf>`_.

How does reV work?
==================
reV is a set of `Python classes and functions <https://natlabrockies.github.io/reV/_autosummary/reV.html>`_
that can be executed on HPC systems using `CLI commands <https://natlabrockies.github.io/reV/_cli/cli.html>`_.
A full reV execution consists of one or more compute modules
(each consisting of their own Python class/CLI command)
strung together using a `pipeline framework <https://natlabrockies.github.io/reV/_cli/reV%20pipeline.html>`_,
or configured using `batch <https://natlabrockies.github.io/reV/_cli/reV%20batch.html>`_.

A typical reV workflow begins with input resource data
(following the `rex data format <https://natlabrockies.github.io/rex/misc/examples.nsrdb.html#data-format>`_)
that is passed through the generation module. This output is then collected across space and time
(if executed on the HPC), before being sent off to be aggregated under user-specified land exclusion scenarios.
Exclusion data is typically provided via a collection of high-resolution spatial data layers stored in an HDF5 file.
This file must be readable by reV's
`ExclusionLayers <https://natlabrockies.github.io/reV/_autosummary/reV.handlers.exclusions.ExclusionLayers.html#reV.handlers.exclusions.ExclusionLayers>`_
class. See the `reVX Setbacks utility <https://natlabrockies.github.io/reVX/misc/examples.setbacks.html>`_
for instructions on generating setback exclusions for use in reV.
Next, transmission costs are computed for each aggregated
"supply-curve point" using user-provided transmission cost tables.
See the `reVX transmission cost calculator utility <https://github.com/NatLabRockies/reVX/tree/main/reVX/least_cost_xmission/>`_
for instructions on generating transmission cost tables.
Finally, the supply curves and initial generation data can be used to
extract representative generation profiles for each supply curve point.




.. inclusion-flowchart



|

.. inclusion-get-started

To get up and running with reV, first head over to the `installation page <https://natlabrockies.github.io/reV/misc/installation.html>`_,
then check out some of the `Examples <https://natlabrockies.github.io/reV/misc/examples.html>`_ or
go straight to the `CLI Documentation <https://natlabrockies.github.io/reV/_cli/cli.html>`_!
You can also check out the `guide on running GAPs models <https://natlabrockies.github.io/gaps/misc/examples.users.html>`_.

.. inclusion-install


Installing reV
==============

NOTE: The installation instruction below assume that you have python installed
on your machine and are using `conda <https://docs.conda.io/en/latest/index.html>`_
as your package/environment manager.

Option 1: Install from PIP (recommended for analysts):

1. Create a new environment:
    ``conda create --name rev python=3.11``

2. Activate directory:
    ``conda activate rev``

3. Install reV:
    1) ``pip install NLR-reV`` or

       - NOTE: If you install using conda and want to use `HSDS <https://github.com/NatLabRockies/hsds-examples>`_
         you will also need to install HSDS dependencies: ``pip install NLR-reV[hsds]``

Option 2: Clone repo (recommended for developers)

1. from home dir, ``git clone git@github.com:NatLabRockies/reV.git``

2. Create ``reV`` environment and install package
    1) Create a conda env: ``conda create -n rev``
    2) Run the command: ``conda activate rev``
    3) cd into the repo cloned in 1.
    4) prior to running ``pip`` below, make sure the branch is correct (install
       from main!)
    5) Install ``reV`` and its dependencies by running:
       ``pip install .`` (or ``pip install -e .`` if running a dev branch
       or working on the source code)

3. Check that ``reV`` was installed successfully
    1) From any directory, run the following commands. This should return the
       help pages for the CLI's.

        - ``reV``


reV Ecosystem
=============
The reV model suite comes with a set of tools that can be used alongside the core model
to assist with data preparation and analysis:

- `reVX <https://natlabrockies.github.io/reVX/>`_ - Collection of helper methods to pre- and post- process geospatial reV data (e.g. setback layers, inclusion masks, etc.)
- `rex <https://natlabrockies.github.io/rex/>`_ - Library to assist with reV-style data I/O, especially resource data
- `reVRt <https://natlabrockies.github.io/reVRt/>`_ - reV routing tool used to compute transmission costs
- `NRWAL <https://natlabrockies.github.io/NRWAL/>`_ - Equation Library for detailed cost analysis (offshore, hydrogen, etc.)
- `reVeal <https://natlabrockies.github.io/reVeal/>`_ - reV extension for load analysis and land characterization
- `reVReports <https://natlabrockies.github.io/reVReports/>`_ - Tool for generating publication-ready maps of reV supply curve outputs
- `reView <https://github.com/NatLabRockies/reView>`_ - Dashboard for interactive visualization of reV supply curve outputs
- `reV tutorial <https://github.com/NatLabRockies/reV-tutorial>`_ - Collection of tutorials for learning how to use reV
- `gaps <https://natlabrockies.github.io/gaps/>`_ - Underlying reV pipeline job submission and management system


reV command line tools
======================

- `reV <https://natlabrockies.github.io/reV/_cli/reV.html#reV>`_
- `reV template-configs <https://natlabrockies.github.io/reV/_cli/reV%20template-configs.html>`_
- `reV batch <https://natlabrockies.github.io/reV/_cli/reV%20batch.html>`_
- `reV pipeline <https://natlabrockies.github.io/reV/_cli/reV%20pipeline.html>`_
- `reV project-points <https://natlabrockies.github.io/reV/_cli/reV%20project-points.html>`_
- `reV bespoke <https://natlabrockies.github.io/reV/_cli/reV%20bespoke.html>`_
- `reV generation <https://natlabrockies.github.io/reV/_cli/reV%20generation.html>`_
- `reV econ <https://natlabrockies.github.io/reV/_cli/reV%20econ.html>`_
- `reV collect <https://natlabrockies.github.io/reV/_cli/reV%20collect.html>`_
- `reV multiyear <https://natlabrockies.github.io/reV/_cli/reV%20multiyear.html>`_
- `reV supply-curve-aggregation <https://natlabrockies.github.io/reV/_cli/reV%20supply-curve-aggregation.html>`_
- `reV supply-curve <https://natlabrockies.github.io/reV/_cli/reV%20supply-curve.html>`_
- `reV rep-profiles <https://natlabrockies.github.io/reV/_cli/reV%20rep-profiles.html>`_
- `reV hybrids <https://natlabrockies.github.io/reV/_cli/reV%20hybrids.html>`_
- `reV nrwal <https://natlabrockies.github.io/reV/_cli/reV%20nrwal.html>`_
- `reV qa-qc <https://natlabrockies.github.io/reV/_cli/reV%20qa-qc.html>`_
- `reV script <https://natlabrockies.github.io/reV/_cli/reV%20script.html>`_
- `reV status <https://natlabrockies.github.io/reV/_cli/reV%20status.html>`_
- `reV reset-status <https://natlabrockies.github.io/reV/_cli/reV%20reset-status.html>`_


Launching a run

Tips

- Only use a screen session if running the pipeline module: `screen -S rev`
- `Full pipeline execution <https://natlabrockies.github.io/reV/misc/examples.full_pipeline_execution.html>`_

.. code-block:: bash

    reV pipeline -c "/scratch/user/rev/config_pipeline.json"

- Running simply generation or econ can just be done from the console:

.. code-block:: bash

    reV generation -c "/scratch/user/rev/config_gen.json"

General Run times and Node configuration on Eagle

- WTK Conus: 10-20 nodes per year walltime 1-4 hours
- NSRDB Conus: 5 nodes walltime 2 hours

`Eagle node requests <https://natlabrockies.github.io/reV/misc/examples.eagle_node_requests.html>`_


.. inclusion-citation


Recommended Citation
====================

Please cite both the technical paper and the software with the version and
DOI you used:

Maclaurin, Galen J., Nicholas W. Grue, Anthony J. Lopez, Donna M. Heimiller,
Michael Rossol, Grant Buster, and Travis Williams. 2019. “The Renewable Energy
Potential (reV) Model: A Geospatial Platform for Technical Potential and Supply
Curve Modeling.” Golden, Colorado, United States: National Renewable Energy
Laboratory. NREL/TP-6A20-73067. https://doi.org/10.2172/1563140.

Buster, G., Pinchuk, P., Rossol, M., Benton, B., Gleason, M., Stanley, A. P.,
Spencer, R., Bannister, M., & Williams, T. (2020). reV (Version 0.14.5)
[Computer software]. https://github.com/NatLabRockies/reV
