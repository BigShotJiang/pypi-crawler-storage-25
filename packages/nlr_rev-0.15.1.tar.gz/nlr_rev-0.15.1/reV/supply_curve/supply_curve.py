# -*- coding: utf-8 -*-
"""
reV supply curve module
- Calculation of LCOT
- Supply Curve creation
"""
import json
import logging
import os
from itertools import chain
from warnings import warn

import numpy as np
import pandas as pd
from rex import Resource
from rex.utilities import SpawnProcessPool, parse_table

from reV.handlers.transmission import POIFeatures as PF
from reV.handlers.transmission import TransmissionCosts as TC
from reV.handlers.transmission import TransmissionFeatures as TF
from reV.supply_curve.competitive_wind_farms import CompetitiveWindFarms
from reV.utilities import SupplyCurveField, log_versions
from reV.utilities.exceptions import SupplyCurveError, SupplyCurveInputError

logger = logging.getLogger(__name__)

# map is column name to relative order in which it should appear in output file
_REQUIRED_COMPUTE_AND_OUTPUT_COLS = {
    SupplyCurveField.TRANS_GID: 0,
    SupplyCurveField.TRANS_TYPE: 1,
    SupplyCurveField.N_PARALLEL_TRANS: 2,
    SupplyCurveField.DIST_SPUR_KM: 3,
    SupplyCurveField.TOTAL_TRANS_CAP_COST_PER_MW: 10,
    SupplyCurveField.LCOT: 11,
    SupplyCurveField.TOTAL_LCOE: 12,
}
_REQUIRED_OUTPUT_COLS = {SupplyCurveField.DIST_EXPORT_KM: 4,
                         SupplyCurveField.REINFORCEMENT_DIST_KM: 5,
                         SupplyCurveField.TIE_LINE_COST_PER_MW: 6,
                         SupplyCurveField.CONNECTION_COST_PER_MW: 7,
                         SupplyCurveField.EXPORT_COST_PER_MW: 8,
                         SupplyCurveField.REINFORCEMENT_COST_PER_MW: 9,
                         SupplyCurveField.POI_LAT: 13,
                         SupplyCurveField.POI_LON: 14,
                         SupplyCurveField.REINFORCEMENT_POI_LAT: 15,
                         SupplyCurveField.REINFORCEMENT_POI_LON: 16}
DEFAULT_COLUMNS = tuple(str(field)
                        for field in chain(_REQUIRED_COMPUTE_AND_OUTPUT_COLS,
                                           _REQUIRED_OUTPUT_COLS))
"""Default output columns from supply chain computation (not ordered)"""


class SupplyCurve:
    """SupplyCurve"""

    def __init__(self, sc_points, trans_table, sc_features=None,
                 # str() to fix docs
                 sc_capacity_col=str(SupplyCurveField.CAPACITY_AC_MW),
                 poi_info=None):
        """ReV LCOT calculation and SupplyCurve sorting class.

        ``reV`` supply curve computes the transmission costs associated
        with each supply curve point output by ``reV`` supply curve
        aggregation. Transmission costs can either be computed
        competitively (where total capacity remaining on the
        transmission grid is tracked and updated after each new
        connection) or non-competitively (where the cheapest connections
        for each supply curve point are allowed regardless of the
        remaining transmission grid capacity). In both cases, the
        permutation of transmission costs between supply curve points
        and transmission grid features should be computed using the
        `reVX Least Cost Transmission Paths
        <https://github.com/NatLabRockies/reVX/tree/main/reVX/least_cost_xmission>`_
        utility.

        Parameters
        ----------
        sc_points : str | pandas.DataFrame
            Path to CSV or JSON or DataFrame containing supply curve
            point summary. Can also be a filepath to a ``reV`` bespoke
            HDF5 output file where the ``meta`` dataset has the same
            format as the supply curve aggregation output.

            .. Note:: If executing ``reV`` from the command line, this
              input can also be ``"PIPELINE"`` to parse the output of
              the previous pipeline step and use it as input to this
              call. However, note that duplicate executions of any
              preceding commands within the pipeline may invalidate this
              parsing, meaning the `sc_points` input will have to be
              specified manually.

        trans_table : str | pandas.DataFrame | list
            Path to CSV or JSON or DataFrame containing supply curve
            transmission mapping. This can also be a list of
            transmission tables with different line voltage (capacity)
            ratings. See the `reVX Least Cost Transmission Paths
            <https://github.com/NatLabRockies/reVX/tree/main/reVX/least_cost_xmission>`_
            utility to generate these input tables.
        sc_features : str | pandas.DataFrame, optional
            Path to CSV or JSON or DataFrame containing additional
            supply curve features (e.g. transmission multipliers,
            regions, etc.). These features will be merged to the
            `sc_points` input table on ALL columns that both have in
            common. If ``None``, no extra supply curve features are
            added. By default, ``None``.
        sc_capacity_col : str, optional
            Name of capacity column in `trans_sc_table`. The values in
            this column determine the size of transmission lines built.
            The transmission capital costs per MW and the reinforcement
            costs per MW will be returned in terms of these capacity
            values. Note that if this column != "capacity", then
            "capacity" must also be included in `trans_sc_table` since
            those values match the "mean_cf" data (which is used to
            calculate LCOT and Total LCOE). This input can be used to,
            e.g., size transmission lines based on solar AC capacity (
            ``sc_capacity_col="capacity_ac"``). By default,
            ``"capacity"``.
        poi_info : str | pandas.DataFrame, optional
            Path to CSV or DataFrame containing POI point connection
            summary. This table should have at least the following
            columns:

                - "POI_limit" *or* "ac_cap": POI connection capacity (MW)
                - "POI_name": String identifier for the POI used to
                              merge with the ``"end"`` column from the
                              `trans_table` input
                - "POI_cost_MW": Connection cost for this POI, in $/MW.

            This input is required if you are running ``poi_sort``.
            By default, ``None``.

        Examples
        --------
        Standard outputs in addition to the values provided in
        `sc_points`, produced by
        :class:`reV.supply_curve.sc_aggregation.SupplyCurveAggregation`:

            - transmission_multiplier : int | float
                Transmission cost multiplier that scales the line cost
                but not the tie-in cost in the calculation of LCOT.
            - trans_gid : int
                Unique transmission feature identifier that each supply
                curve point was connected to.
            - trans_capacity : float
                Total capacity (not available capacity) of the
                transmission feature that each supply curve point was
                connected to. Default units are MW.
            - trans_type : str
                Tranmission feature type that each supply curve point
                was connected to (e.g. Transline, Substation).
            - trans_cap_cost_per_mw : float
                Capital cost of connecting each supply curve point to
                their respective transmission feature. This value
                includes line cost with transmission_multiplier and the
                tie-in cost. Default units are $/MW.
            - dist_km : float
                Distance in km from supply curve point to transmission
                connection.
            - lcot : float
                Levelized cost of connecting to transmission ($/MWh).
            - total_lcoe : float
                Total LCOE of each supply curve point (mean_lcoe + lcot)
                ($/MWh).
            - total_lcoe_friction : float
                Total LCOE of each supply curve point considering the
                LCOE friction scalar from the aggregation step
                (mean_lcoe_friction + lcot) ($/MWh).
        """
        log_versions(logger)
        logger.info("Supply curve points input: {}".format(sc_points))
        logger.info("Transmission table input: {}".format(trans_table))
        logger.info("Supply curve capacity column: {}".format(sc_capacity_col))

        self._poi_info = self._parse_poi_info(poi_info)
        self._sc_capacity_col = sc_capacity_col
        self._sc_points = self._parse_sc_points(sc_points,
                                                sc_features=sc_features)
        self._trans_table = self._map_tables(self._sc_points,
                                             trans_table,
                                             sc_capacity_col=sc_capacity_col,
                                             poi_info=self._poi_info)
        self._sc_gids, self._sc_capacities = self._parse_sc_gids(
            self._trans_table)

    def __repr__(self):
        msg = "{} with {} points".format(self.__class__.__name__, len(self))

        return msg

    def __len__(self):
        return len(self._sc_gids)

    def __getitem__(self, gid):
        if gid not in self._sc_gids:
            msg = "Invalid supply curve gid {}".format(gid)
            logger.error(msg)
            raise KeyError(msg)

        i = self._sc_gids.index(gid)

        return self._sc_points.iloc[i]

    @staticmethod
    def _parse_poi_info(poi_info=None):
        """Parse and format user POI input"""
        if poi_info is None:
            return None

        poi_info = parse_table(poi_info)
        poi_info.index.name = SupplyCurveField.TRANS_GID
        poi_info = poi_info.reset_index()
        poi_info = poi_info.rename(columns={"POI_limit": "ac_cap"})
        poi_info[SupplyCurveField.TRANS_TYPE] = "loadcen"
        return poi_info

    @staticmethod
    def _parse_sc_points(sc_points, sc_features=None):
        """
        Import supply curve point summary and add any additional features

        Parameters
        ----------
        sc_points : str | pandas.DataFrame
            Path to .csv or .json or DataFrame containing supply curve point
            summary. Can also now be a filepath to a bespoke h5 where the
            "meta" dataset has the same format as the sc aggregation output.
        sc_features : str | pandas.DataFrame
            Path to .csv or .json or DataFrame containing additional supply
            curve features, e.g. transmission multipliers, regions

        Returns
        -------
        sc_points : pandas.DataFrame
            DataFrame of supply curve point summary with additional features
            added if supplied
        """
        if isinstance(sc_points, str) and sc_points.endswith(".h5"):
            with Resource(sc_points) as res:
                sc_points = res.meta
                sc_points.index.name = SupplyCurveField.SC_GID
                sc_points = sc_points.reset_index()
        else:
            sc_points = parse_table(sc_points)
            sc_points = sc_points.rename(
                columns=SupplyCurveField.map_from_legacy())

        logger.debug(
            "Supply curve points table imported with columns: {}".format(
                sc_points.columns.values.tolist()
            )
        )

        if sc_features is not None:
            sc_features = parse_table(sc_features)
            sc_features = sc_features.rename(
                columns=SupplyCurveField.map_from_legacy())
            merge_cols = [c for c in sc_features if c in sc_points]
            sc_points = sc_points.merge(sc_features, on=merge_cols, how="left")
            logger.debug(
                "Adding Supply Curve Features table with columns: {}".format(
                    sc_features.columns.values.tolist()
                )
            )

        if "transmission_multiplier" in sc_points:
            col = "transmission_multiplier"
            sc_points.loc[:, col] = sc_points.loc[:, col].fillna(1)

        logger.debug(
            "Final supply curve points table has columns: {}".format(
                sc_points.columns.values.tolist()
            )
        )

        return sc_points

    @staticmethod
    def _get_merge_cols(sc_columns, trans_columns):
        """
        Get columns with 'row' or 'col' in them to use for merging

        Parameters
        ----------
        sc_columns : list
            Columns to search
        trans_cols

        Returns
        -------
        merge_cols : dict
            Columns to merge on which maps the sc columns (keys) to the
            corresponding trans table columns (values)
        """
        sc_columns = [c for c in sc_columns if c.startswith("sc_")]
        trans_columns = [c for c in trans_columns if c.startswith("sc_")]
        merge_cols = {}
        for c_val in ["row", "col"]:
            trans_col = [c for c in trans_columns if c_val in c]
            sc_col = [c for c in sc_columns if c_val in c]
            if trans_col and sc_col:
                merge_cols[sc_col[0]] = trans_col[0]

        if len(merge_cols) != 2:
            msg = (
                "Did not find a unique set of sc row and column ids to "
                "merge on: {}".format(merge_cols)
            )
            logger.error(msg)
            raise RuntimeError(msg)

        return merge_cols

    @staticmethod
    def _parse_trans_table(trans_table):
        """
        Import transmission features table

        Parameters
        ----------
        trans_table : pd.DataFrame | str
            Table mapping supply curve points to transmission features
            (either str filepath to table file or pre-loaded dataframe).

        Returns
        -------
        trans_table : pd.DataFrame
            Loaded transmission feature table.
        """

        trans_table = parse_table(trans_table)

        # Update legacy transmission table columns to match new less ambiguous
        # column names:
        # trans_gid -> the transmission feature id, legacy name: trans_line_gid
        # trans_line_gids -> gids of transmission lines connected to the given
        # transmission feature (only used for Substations),
        # legacy name: trans_gids
        # also xformer_cost_p_mw -> xformer_cost_per_mw (not sure why there
        # would be a *_p_mw but here we are...)
        rename_map = {
            "trans_line_gid": SupplyCurveField.TRANS_GID,
            "trans_gids": "trans_line_gids",
            "xformer_cost_p_mw": "xformer_cost_per_mw",
        }
        trans_table = trans_table.rename(columns=rename_map)

        contains_dist_in_miles = "dist_mi" in trans_table
        missing_km_dist = SupplyCurveField.DIST_SPUR_KM not in trans_table
        if contains_dist_in_miles and missing_km_dist:
            trans_table = trans_table.rename(
                columns={"dist_mi": SupplyCurveField.DIST_SPUR_KM}
            )
            trans_table[SupplyCurveField.DIST_SPUR_KM] *= 1.60934

        drop_cols = [SupplyCurveField.SC_GID, 'cap_left',
                     SupplyCurveField.SC_POINT_GID]
        drop_cols = [c for c in drop_cols if c in trans_table]
        if drop_cols:
            trans_table = trans_table.drop(columns=drop_cols)

        return trans_table.rename(columns=SupplyCurveField.map_from_legacy())

    @staticmethod
    def _map_trans_capacity(trans_sc_table,
                            sc_capacity_col=SupplyCurveField.CAPACITY_AC_MW):
        """
        Map SC gids to transmission features based on capacity. For any SC
        gids with capacity > the maximum transmission feature capacity, map
        SC gids to the feature with the largest capacity

        Parameters
        ----------
        trans_sc_table : pandas.DataFrame
            Table mapping supply curve points to transmission features.
        sc_capacity_col : str, optional
            Name of capacity column in `trans_sc_table`. The values in
            this column determine the size of transmission lines built.
            The transmission capital costs per MW and the reinforcement
            costs per MW will be returned in terms of these capacity
            values. Note that if this column != "capacity", then
            "capacity" must also be included in `trans_sc_table` since
            those values match the "mean_cf" data (which is used to
            calculate LCOT and Total LCOE). By default, ``"capacity"``.

        Returns
        -------
        trans_sc_table : pandas.DataFrame
            Updated table mapping supply curve points to transmission features
            based on maximum capacity
        """

        nx = trans_sc_table[sc_capacity_col] / trans_sc_table["max_cap"]
        nx = np.ceil(nx).astype(int)
        trans_sc_table[SupplyCurveField.N_PARALLEL_TRANS] = nx

        if (nx > 1).any():
            mask = nx > 1
            tie_line_cost = (
                trans_sc_table.loc[mask, "tie_line_cost"] * nx[mask]
            )

            xformer_cost = (
                trans_sc_table.loc[mask, "xformer_cost_per_mw"]
                * trans_sc_table.loc[mask, "max_cap"]
                * nx[mask]
            )

            conn_cost = (
                xformer_cost
                + trans_sc_table.loc[mask, "sub_upgrade_cost"]
                + trans_sc_table.loc[mask, "new_sub_cost"]
            )

            trans_cap_cost = tie_line_cost + conn_cost

            trans_sc_table.loc[mask, "tie_line_cost"] = tie_line_cost
            trans_sc_table.loc[mask, "xformer_cost"] = xformer_cost
            trans_sc_table.loc[mask, "connection_cost"] = conn_cost
            trans_sc_table.loc[mask, "trans_cap_cost"] = trans_cap_cost

            msg = (
                "{} SC points have a capacity that exceeds the maximum "
                "transmission feature capacity and will be connected with "
                "multiple parallel transmission features.".format(
                    (nx > 1).sum()
                )
            )
            logger.info(msg)

        return trans_sc_table

    @staticmethod
    def _parse_trans_line_gids(trans_line_gids):
        """
        Parse json string of trans_line_gids if needed

        Parameters
        ----------
        trans_line_gids : str | list
            list of transmission line 'trans_gid's, if a json string, convert
            to list

        Returns
        -------
        trans_line_gids : list
            list of transmission line 'trans_gid's
        """
        if isinstance(trans_line_gids, str):
            trans_line_gids = json.loads(trans_line_gids)

        return trans_line_gids

    @classmethod
    def _check_sub_trans_lines(cls, features):
        """
        Check to make sure all trans-lines are available for all sub-stations

        Parameters
        ----------
        features : pandas.DataFrame
            Table of transmission feature to check substation to transmission
            line gid connections

        Returns
        -------
        line_gids : list
            List of missing transmission line 'trans_gid's for all substations
            in features table
        """
        features = features.rename(
            columns={
                "trans_line_gid": SupplyCurveField.TRANS_GID,
                "trans_gids": "trans_line_gids",
            }
        )
        mask = (features[SupplyCurveField.TRANS_TYPE].str.casefold()
                == "substation")

        if not any(mask):
            return []

        line_gids = features.loc[mask, "trans_line_gids"].apply(
            cls._parse_trans_line_gids
        )

        line_gids = np.unique(np.concatenate(line_gids.values))

        test = np.isin(line_gids, features[SupplyCurveField.TRANS_GID].values)

        return line_gids[~test].tolist()

    @classmethod
    def _check_substation_conns(cls, trans_table,
                                sc_cols=SupplyCurveField.SC_GID):
        """
        Run checks on substation transmission features to make sure that
        every sc point connecting to a substation can also connect to its
        respective transmission lines

        Parameters
        ----------
        trans_table : pd.DataFrame
            Table mapping supply curve points to transmission features
            (should already be merged with SC points).
        sc_cols : str | list, optional
            Column(s) in trans_table with unique supply curve id,
            by default SupplyCurveField.SC_GID
        """
        missing = {}
        for sc_point, sc_table in trans_table.groupby(sc_cols):
            tl_gids = cls._check_sub_trans_lines(sc_table)
            if tl_gids:
                missing[sc_point] = tl_gids

        if any(missing):
            msg = (
                "The following sc_gid (keys) were connected to substations "
                "but were not connected to the respective transmission line"
                " gids (values) which is required for full SC sort: {}".format(
                    missing
                )
            )
            logger.error(msg)
            raise SupplyCurveInputError(msg)

    @classmethod
    def _check_sc_trans_table(cls, sc_points, trans_table):
        """Run self checks on sc_points table and the merged trans_table

        Parameters
        ----------
        sc_points : pd.DataFrame
            Table of supply curve point summary
        trans_table : pd.DataFrame
            Table mapping supply curve points to transmission features
            (should already be merged with SC points).
        """
        sc_gids = set(sc_points[SupplyCurveField.SC_GID].tolist())
        trans_sc_gids = set(trans_table[SupplyCurveField.SC_GID].tolist())
        missing = sorted(list(sc_gids - trans_sc_gids))
        if any(missing):
            msg = (
                "There are {} Supply Curve points with missing "
                "transmission mappings. Supply curve points with no "
                "transmission features will not be connected! "
                "Missing sc_gid's: {}".format(len(missing), missing)
            )
            logger.warning(msg)
            warn(msg)

        if not trans_sc_gids or not sc_gids:
            msg = (
                "Merging of sc points table and transmission features "
                "table failed with {} original sc gids and {} transmission "
                "sc gids after table merge.".format(
                    len(sc_gids), len(trans_sc_gids)
                )
            )
            logger.error(msg)
            raise SupplyCurveError(msg)

        logger.debug(
            "There are {} original SC gids and {} sc gids in the "
            "merged transmission table.".format(
                len(sc_gids), len(trans_sc_gids)
            )
        )
        logger.debug(
            "Transmission Table created with columns: {}".format(
                trans_table.columns.values.tolist()
            )
        )

    @classmethod
    def _merge_sc_trans_tables(cls, sc_points, trans_table,
                               sc_cols=(SupplyCurveField.SC_GID,
                                        SupplyCurveField.CAPACITY_AC_MW,
                                        SupplyCurveField.MEAN_CF_AC,
                                        SupplyCurveField.MEAN_LCOE),
                               sc_capacity_col=SupplyCurveField.CAPACITY_AC_MW
                               ):
        """
        Merge the supply curve table with the transmission features table.

        Parameters
        ----------
        sc_points : pd.DataFrame
            Table of supply curve point summary
        trans_table : pd.DataFrame | str
            Table mapping supply curve points to transmission features
            (either str filepath to table file, list of filepaths to tables by
             line voltage (capacity) or pre-loaded dataframe).
        sc_cols : tuple | list, optional
            List of column from sc_points to transfer into the trans table,
            If the `sc_capacity_col` is not included, it will get added.
            by default (SupplyCurveField.SC_GID, 'capacity', 'mean_cf',
            'mean_lcoe')
        sc_capacity_col : str, optional
            Name of capacity column in `trans_sc_table`. The values in
            this column determine the size of transmission lines built.
            The transmission capital costs per MW and the reinforcement
            costs per MW will be returned in terms of these capacity
            values. Note that if this column != "capacity", then
            "capacity" must also be included in `trans_sc_table` since
            those values match the "mean_cf" data (which is used to
            calculate LCOT and Total LCOE). By default, ``"capacity"``.

        Returns
        -------
        trans_sc_table : pd.DataFrame
            Updated table mapping supply curve points to transmission features.
            This is performed by an inner merging with trans_table
        """
        if sc_capacity_col not in sc_cols:
            sc_cols = tuple([sc_capacity_col] + list(sc_cols))

        if isinstance(trans_table, (list, tuple)):
            trans_sc_table = []
            for table in trans_table:
                trans_sc_table.append(
                    cls._merge_sc_trans_tables(
                        sc_points,
                        table,
                        sc_cols=sc_cols,
                        sc_capacity_col=sc_capacity_col,
                    )
                )

            trans_sc_table = pd.concat(trans_sc_table)
        else:
            trans_table = cls._parse_trans_table(trans_table)

            merge_cols = cls._get_merge_cols(
                sc_points.columns, trans_table.columns
            )
            logger.info(
                "Merging SC table and Trans Table with "
                "{} mapping: {}".format(
                    "sc_table_col: trans_table_col", merge_cols
                )
            )
            sc_points = sc_points.rename(columns=merge_cols)
            merge_cols = list(merge_cols.values())

            if isinstance(sc_cols, tuple):
                sc_cols = list(sc_cols)

            extra_cols = [SupplyCurveField.CAPACITY_DC_MW,
                          SupplyCurveField.MEAN_CF_DC,
                          SupplyCurveField.MEAN_LCOE_FRICTION,
                          "transmission_multiplier"]
            for col in extra_cols:
                if col in sc_points:
                    sc_cols.append(col)

            sc_cols += merge_cols
            sc_points = sc_points[sc_cols].copy()
            trans_sc_table = trans_table.merge(
                sc_points, on=merge_cols, how="inner"
            )

        return trans_sc_table

    @classmethod
    def _map_tables(cls, sc_points, trans_table,
                    sc_cols=(SupplyCurveField.SC_GID,
                             SupplyCurveField.CAPACITY_AC_MW,
                             SupplyCurveField.MEAN_CF_AC,
                             SupplyCurveField.MEAN_LCOE),
                    sc_capacity_col=SupplyCurveField.CAPACITY_AC_MW,
                    poi_info=None):
        """
        Map supply curve points to transmission features

        Parameters
        ----------
        sc_points : pd.DataFrame
            Table of supply curve point summary
        trans_table : pd.DataFrame | str
            Table mapping supply curve points to transmission features
            (either str filepath to table file, list of filepaths to tables by
             line voltage (capacity) or pre-loaded DataFrame).
        sc_cols : tuple | list, optional
            List of column from sc_points to transfer into the trans table,
            If the `sc_capacity_col` is not included, it will get added.
            by default (SupplyCurveField.SC_GID,
            SupplyCurveField.CAPACITY_AC_MW, SupplyCurveField.MEAN_CF_AC,
            SupplyCurveField.MEAN_LCOE)
        sc_capacity_col : str, optional
            Name of capacity column in `trans_sc_table`. The values in
            this column determine the size of transmission lines built.
            The transmission capital costs per MW and the reinforcement
            costs per MW will be returned in terms of these capacity
            values. Note that if this column != "capacity", then
            "capacity" must also be included in `trans_sc_table` since
            those values match the "mean_cf" data (which is used to
            calculate LCOT and Total LCOE). By default, ``"capacity"``.
        poi_info : str | pandas.DataFrame, optional
            Path to CSV or DataFrame containing POI point connection
            summary. This table should have at least the following
            columns:

                - "POI_limit" *or* "ac_cap": POI connection capacity (MW)
                - "POI_name": String identifier for the POI used to
                              merge with the ``"end"`` column from the
                              `trans_table` input
                - "POI_cost_MW": Connection cost for this POI, in $/MW.

            This input is only required if you are performing a "poi"
            connection sort. by default, ``None``.

        Returns
        -------
        trans_sc_table : pd.DataFrame
            Updated table mapping supply curve points to transmission features.
            This is performed by an inner merging with trans_table
        """
        scc = sc_capacity_col
        trans_sc_table = cls._merge_sc_trans_tables(
            sc_points, trans_table, sc_cols=sc_cols, sc_capacity_col=scc
        )
        gid_missing = SupplyCurveField.TRANS_GID not in trans_sc_table.columns
        if gid_missing and poi_info is not None:
            trans_sc_table = cls._pull_trans_gid_from_poi(trans_sc_table,
                                                          poi_info)

        if "max_cap" in trans_sc_table:
            trans_sc_table = cls._map_trans_capacity(
                trans_sc_table, sc_capacity_col=scc
            )

        sort_cols = [SupplyCurveField.SC_GID, SupplyCurveField.TRANS_GID]
        trans_sc_table = trans_sc_table.sort_values(sort_cols)
        trans_sc_table = trans_sc_table.reset_index(drop=True)

        cls._check_sc_trans_table(sc_points, trans_sc_table)

        return trans_sc_table

    @staticmethod
    def _pull_trans_gid_from_poi(trans_sc_table, poi_info):
        """Extract trans gid from POI table"""
        trans_sc_table = trans_sc_table.rename(columns={"end": "POI_name"})
        merge_data = poi_info[["POI_name", SupplyCurveField.TRANS_GID,
                               SupplyCurveField.TRANS_TYPE, "ac_cap"]]
        return trans_sc_table.merge(merge_data, on="POI_name")

    @staticmethod
    def _create_handler(trans_table, trans_costs=None, avail_cap_frac=1):
        """
        Create TransmissionFeatures handler from supply curve transmission
        mapping table.  Update connection costs if given.

        Parameters
        ----------
        trans_table : str | pandas.DataFrame
            Path to .csv or .json or DataFrame containing supply curve
            transmission mapping
        trans_costs : str | dict
            Transmission feature costs to use with TransmissionFeatures
            handler: line_tie_in_cost, line_cost, station_tie_in_cost,
            center_tie_in_cost, sink_tie_in_cost
        avail_cap_frac: int, optional
            Fraction of transmissions features capacity 'ac_cap' to make
            available for connection to supply curve points, by default 1

        Returns
        -------
        trans_features : TransmissionFeatures
            TransmissionFeatures or TransmissionCosts instance initilized
            with specified transmission costs
        """
        if trans_costs is not None:
            kwargs = TF._parse_dictionary(trans_costs)
        else:
            kwargs = {}

        trans_features = TF(
            trans_table, avail_cap_frac=avail_cap_frac, **kwargs
        )

        return trans_features

    @staticmethod
    def _parse_sc_gids(trans_table, gid_key=SupplyCurveField.SC_GID):
        """Extract unique sc gids, make float SC cap from transmission table

        Parameters
        ----------
        trans_table : pd.DataFrame
            reV Supply Curve table joined with transmission features table.
        gid_key : str
            Column label in trans_table containing the supply curve points
            primary key.

        Returns
        -------
        sc_gids : list
            List of unique integer supply curve gids (non-nan)
        sc_capacities : np.ndarray
            Float array initialized as all zeros. Length is equal to the
            maximum SC gid so that the SC gids can be used to index the
            SC capacity directly.
        """
        sc_gids = list(np.sort(trans_table[gid_key].unique()))
        sc_gids = [int(gid) for gid in sc_gids]
        sc_capacities = np.zeros(int(1 + max(sc_gids)), dtype=np.float32)

        return sc_gids, sc_capacities

    @staticmethod
    def _get_capacity(sc_gid, sc_table, connectable=True,
                      sc_capacity_col=SupplyCurveField.CAPACITY_AC_MW):
        """
        Get capacity of supply curve point

        Parameters
        ----------
        sc_gid : int
            Supply curve gid
        sc_table : pandas.DataFrame
            DataFrame of sc point to transmission features mapping for given
            sc_gid
        connectable : bool, optional
            Flag to ensure SC point can connect to transmission features,
            by default True
        sc_capacity_col : str, optional
            Name of capacity column in `trans_sc_table`. The values in
            this column determine the size of transmission lines built.
            The transmission capital costs per MW and the reinforcement
            costs per MW will be returned in terms of these capacity
            values. Note that if this column != "capacity", then
            "capacity" must also be included in `trans_sc_table` since
            those values match the "mean_cf" data (which is used to
            calculate LCOT and Total LCOE). By default, ``"capacity"``.

        Returns
        -------
        capacity : float
            Capacity of supply curve point
        """
        if connectable:
            capacity = sc_table[sc_capacity_col].unique()
            if len(capacity) == 1:
                capacity = capacity[0]
            else:
                msg = (
                    "Each supply curve point should only have "
                    "a single capacity, but {} has {}".format(sc_gid, capacity)
                )
                logger.error(msg)
                raise RuntimeError(msg)
        else:
            capacity = None

        return capacity

    @classmethod
    def _compute_trans_cap_cost(cls, trans_table, trans_costs=None,
                                avail_cap_frac=1, max_workers=None,
                                connectable=True, line_limited=False,
                                sc_capacity_col=(
                                    SupplyCurveField.CAPACITY_AC_MW)):
        """
        Compute levelized cost of transmission for all combinations of
        supply curve points and tranmission features in trans_table

        Parameters
        ----------
        trans_table : pd.DataFrame
            Table mapping supply curve points to transmission features
            MUST contain `sc_capacity_col` column.
        fcr : float
            Fixed charge rate needed to compute LCOT
        trans_costs : str | dict
            Transmission feature costs to use with TransmissionFeatures
            handler: line_tie_in_cost, line_cost, station_tie_in_cost,
            center_tie_in_cost, sink_tie_in_cost
        avail_cap_frac: int, optional
            Fraction of transmissions features capacity 'ac_cap' to make
            available for connection to supply curve points, by default 1
        max_workers : int | NoneType
            Number of workers to use to compute lcot, if > 1 run in parallel.
            None uses all available cpu's.
        connectable : bool, optional
            Flag to only compute tranmission capital cost if transmission
            feature has enough available capacity, by default True
        line_limited : bool
            Substation connection is limited by maximum capacity of the
            attached lines, legacy method
        sc_capacity_col : str, optional
            Name of capacity column in `trans_sc_table`. The values in
            this column determine the size of transmission lines built.
            The transmission capital costs per MW and the reinforcement
            costs per MW will be returned in terms of these capacity
            values. Note that if this column != "capacity", then
            "capacity" must also be included in `trans_sc_table` since
            those values match the "mean_cf" data (which is used to
            calculate LCOT and Total LCOE). By default, ``"capacity"``.

        Returns
        -------
        lcot : list
            Levelized cost of transmission for all supply curve -
            tranmission feature connections
        cost : list
            Capital cost of tramsmission for all supply curve - transmission
            feature connections
        """
        scc = sc_capacity_col
        if scc not in trans_table:
            raise SupplyCurveInputError(
                "Supply curve table must have "
                "supply curve point capacity column"
                "({}) to compute lcot".format(scc)
            )

        if trans_costs is not None:
            trans_costs = TF._parse_dictionary(trans_costs)
        else:
            trans_costs = {}

        if max_workers is None:
            max_workers = os.cpu_count()

        logger.info('Computing LCOT costs for all possible connections...')
        groups = trans_table.groupby(SupplyCurveField.SC_GID)
        if max_workers > 1:
            loggers = [__name__, "reV.handlers.transmission", "reV"]
            with SpawnProcessPool(
                max_workers=max_workers, loggers=loggers
            ) as exe:
                futures = []
                for sc_gid, sc_table in groups:
                    capacity = cls._get_capacity(
                        sc_gid,
                        sc_table,
                        connectable=connectable,
                        sc_capacity_col=scc,
                    )
                    futures.append(
                        exe.submit(
                            TC.feature_costs,
                            sc_table,
                            capacity=capacity,
                            avail_cap_frac=avail_cap_frac,
                            line_limited=line_limited,
                            **trans_costs,
                        )
                    )

                cost = [future.result() for future in futures]
        else:
            cost = []
            for sc_gid, sc_table in groups:
                capacity = cls._get_capacity(
                    sc_gid,
                    sc_table,
                    connectable=connectable,
                    sc_capacity_col=scc,
                )
                cost.append(
                    TC.feature_costs(
                        sc_table,
                        capacity=capacity,
                        avail_cap_frac=avail_cap_frac,
                        line_limited=line_limited,
                        **trans_costs,
                    )
                )

        cost = np.hstack(cost).astype("float32")
        logger.info("LCOT cost calculation is complete.")

        return cost

    def compute_total_lcoe(
        self,
        fcr,
        transmission_costs=None,
        avail_cap_frac=1,
        line_limited=False,
        connectable=True,
        max_workers=None,
        consider_friction=True,
        trans_table=None,
    ):
        """
        Compute LCOT and total LCOE for all sc point to transmission feature
        connections

        Parameters
        ----------
        fcr : float
            Fixed charge rate, used to compute LCOT
        transmission_costs : str | dict, optional
            Transmission feature costs to use with TransmissionFeatures
            handler: line_tie_in_cost, line_cost, station_tie_in_cost,
            center_tie_in_cost, sink_tie_in_cost, by default None
        avail_cap_frac : int, optional
            Fraction of transmissions features capacity 'ac_cap' to make
            available for connection to supply curve points, by default 1
        line_limited : bool, optional
            Flag to have substation connection is limited by maximum capacity
            of the attached lines, legacy method, by default False
        connectable : bool, optional
            Flag to only compute tranmission capital cost if transmission
            feature has enough available capacity, by default True
        max_workers : int | NoneType, optional
            Number of workers to use to compute lcot, if > 1 run in parallel.
            None uses all available cpu's. by default None
        consider_friction : bool, optional
            Flag to consider friction layer on LCOE when "mean_lcoe_friction"
            is in the sc points input, by default True
        trans_table : pd.DataFrame, optional
            Optional transmission table to compute costs for. If no table
            is provided, the object's `_trans_table` attribute is used
            instead. By default, ``None``.
        """
        if trans_table is None:
            trans_table = self._trans_table

        tcc_per_mw_col = SupplyCurveField.TOTAL_TRANS_CAP_COST_PER_MW
        if tcc_per_mw_col in trans_table:
            cost = trans_table[tcc_per_mw_col].values.copy()
        elif "trans_cap_cost" not in trans_table:
            scc = self._sc_capacity_col
            cost = self._compute_trans_cap_cost(
                trans_table,
                trans_costs=transmission_costs,
                avail_cap_frac=avail_cap_frac,
                line_limited=line_limited,
                connectable=connectable,
                max_workers=max_workers,
                sc_capacity_col=scc,
            )
            trans_table[tcc_per_mw_col] = cost  # $/MW
        else:
            cost = trans_table["trans_cap_cost"].values.copy()  # $
            cost /= trans_table[SupplyCurveField.CAPACITY_AC_MW]  # $/MW
            trans_table[tcc_per_mw_col] = cost

        trans_table[tcc_per_mw_col] = (
            trans_table[tcc_per_mw_col].astype("float32")
        )
        cost = cost.astype("float32")
        cf_mean_arr = trans_table[SupplyCurveField.MEAN_CF_AC]
        cf_mean_arr = cf_mean_arr.values.astype("float32")
        resource_lcoe = trans_table[SupplyCurveField.MEAN_LCOE]
        resource_lcoe = resource_lcoe.values.astype("float32")

        if 'reinforcement_cost_floored_per_mw' in trans_table:
            logger.info("'reinforcement_cost_floored_per_mw' column found in "
                        "transmission table. Adding floored reinforcement "
                        "cost LCOE as sorting option.")
            fr_cost = (trans_table['reinforcement_cost_floored_per_mw']
                       .values.copy())

            lcot_fr = ((cost + fr_cost) * fcr) / (cf_mean_arr * 8760)
            lcoe_fr = lcot_fr + resource_lcoe
            trans_table['lcot_floored_reinforcement'] = lcot_fr
            trans_table['lcoe_floored_reinforcement'] = lcoe_fr

        rcpmw = SupplyCurveField.REINFORCEMENT_COST_PER_MW
        if (rcpmw in trans_table and not trans_table[rcpmw].isna().all()):
            logger.info("%s column found in transmission table. Adding "
                        "reinforcement costs to total LCOE.",
                        SupplyCurveField.REINFORCEMENT_COST_PER_MW)
            lcot_nr = (cost * fcr) / (cf_mean_arr * 8760)
            lcoe_nr = lcot_nr + resource_lcoe
            trans_table['lcot_no_reinforcement'] = lcot_nr
            trans_table['lcoe_no_reinforcement'] = lcoe_nr

            col_name = SupplyCurveField.REINFORCEMENT_COST_PER_MW
            r_cost = trans_table[col_name].astype("float32")
            r_cost = r_cost.values.copy()
            trans_table[tcc_per_mw_col] += r_cost
            cost += r_cost  # $/MW

        lcot = (cost * fcr) / (cf_mean_arr * 8760)
        trans_table[SupplyCurveField.LCOT] = lcot
        trans_table[SupplyCurveField.TOTAL_LCOE] = lcot + resource_lcoe

        if consider_friction:
            trans_table = self._calculate_total_lcoe_friction(trans_table)

        return trans_table

    def _calculate_total_lcoe_friction(self, trans_table):
        """Look for site mean LCOE with friction in the trans table and if
        found make a total LCOE column with friction."""

        if SupplyCurveField.MEAN_LCOE_FRICTION in trans_table:
            lcoe_friction = (
                trans_table[SupplyCurveField.LCOT]
                + trans_table[SupplyCurveField.MEAN_LCOE_FRICTION])
            trans_table[SupplyCurveField.TOTAL_LCOE_FRICTION] = (
                lcoe_friction
            )
            logger.info('Found mean LCOE with friction. Adding key '
                        '"total_lcoe_friction" to trans table.')

        return trans_table

    def _exclude_noncompetitive_wind_farms(
        self, comp_wind_dirs, sc_gid, downwind=False
    ):
        """
        Exclude non-competitive wind farms for given sc_gid

        Parameters
        ----------
        comp_wind_dirs : CompetitiveWindFarms
            Pre-initilized CompetitiveWindFarms instance
        sc_gid : int
            Supply curve gid to exclude non-competitive wind farms around
        downwind : bool, optional
            Flag to remove downwind neighbors as well as upwind neighbors,
            by default False

        Returns
        -------
        comp_wind_dirs : CompetitiveWindFarms
            updated CompetitiveWindFarms instance
        """
        gid = comp_wind_dirs.check_sc_gid(sc_gid)
        if gid is not None:
            if comp_wind_dirs.mask[gid]:
                exclude_gids = comp_wind_dirs["upwind", gid]
                if downwind:
                    exclude_gids = np.append(
                        exclude_gids, comp_wind_dirs["downwind", gid]
                    )
                for n in exclude_gids:
                    check = comp_wind_dirs.exclude_sc_point_gid(n)
                    if check:
                        sc_gids = comp_wind_dirs[SupplyCurveField.SC_GID, n]
                        for sc_id in sc_gids:
                            if self._sc_capacities[sc_id] > 0:
                                logger.debug(
                                    "Excluding sc_gid {}".format(sc_id)
                                )
                                self._sc_capacities[sc_id] = 0

        return comp_wind_dirs

    @staticmethod
    def add_sum_cols(table, sum_cols):
        """Add a summation column to table.

        Parameters
        ----------
        table : pd.DataFrame
            Supply curve table.
        sum_cols : dict
            Mapping of new column label(s) to multiple column labels to sum.
            Example: sum_col={'total_cap_cost': ['cap_cost1', 'cap_cost2']}
            Which would add a new 'total_cap_cost' column which would be the
            sum of 'cap_cost1' and 'cap_cost2' if they are present in table.

        Returns
        -------
        table : pd.DataFrame
            Supply curve table with additional summation columns.
        """

        for new_label, sum_labels in sum_cols.items():
            missing = [s for s in sum_labels if s not in table]

            if any(missing):
                logger.info(
                    'Could not make sum column "{}", missing: {}'.format(
                        new_label, missing
                    )
                )
            else:
                sum_arr = np.zeros(len(table))
                for s in sum_labels:
                    temp = table[s].values
                    temp[np.isnan(temp)] = 0
                    sum_arr += temp

                table[new_label] = sum_arr

        return table

    def _full_sort(  # noqa: C901
        self,
        trans_table,
        trans_features,
        fcr,
        comp_wind_dirs=None,
        sort_on=SupplyCurveField.TOTAL_LCOE,
        columns=(
            SupplyCurveField.TRANS_GID,
            SupplyCurveField.TRANS_CAPACITY,
            SupplyCurveField.TRANS_TYPE,
            SupplyCurveField.TOTAL_TRANS_CAP_COST_PER_MW,
            SupplyCurveField.DIST_SPUR_KM,
            SupplyCurveField.LCOT,
            SupplyCurveField.TOTAL_LCOE,
        ),
        downwind=False,
        max_cap_tie_in_cost_per_mw=None,
        scale_with_capacity=False,
        connection_upper_limit=None,
        **kwargs
    ):
        """
        Internal method to handle full supply curve sorting

        Parameters
        ----------
        trans_table : pandas.DataFrame
            Supply Curve Transmission table to sort on
        trans_features : TransmissionFeatures
            TransmissionFeatures handler instance to get transmission
            cost information.
        fcr : float
            Fixed charge rate, used to compute LCOT
        comp_wind_dirs : CompetitiveWindFarms, optional
            Pre-initialized CompetitiveWindFarms instance, by default None
        sort_on : str, optional
            Column label to sort the Supply Curve table on. This affects the
            build priority - connections with the lowest value in this column
            will be built first, by default 'total_lcoe'
        columns : tuple, optional
            Columns to preserve in output connections dataframe,
            by default ('trans_gid', 'trans_capacity', 'trans_type',
                        'trans_cap_cost_per_mw', 'dist_km', 'lcot',
                        'total_lcoe')
        downwind : bool, optional
            Flag to remove downwind neighbors as well as upwind neighbors,
            by default False
        max_cap_tie_in_cost_per_mw : int | float, optional
            Cost ($/MW) to tie into transmission features *after* they
            have reached maximum capacity. If ``None``, then connections
            after reaching max transmission feature capacity are
            disallowed. By default, ``None``.
        scale_with_capacity : bool, default=False
            Option to scale the costs as capacity changes. If ``False``,
            costs are only computed once at the beginning of the sort.
            If ``True``, costs are re-computed as parts of a plant are
            connected, leaving the remainder of the plant capacity with
            higher connection costs (since new lines have to be built
            for a smaller amount of capacity). By default, ``False``.
        connection_upper_limit : int | float, optional
            Optional upper limit for total capacity (MW). If specified,
            the sort will stop when this amount of capacity has been
            connected. By default, ``None`` which does not impose any
            limits.
        **kwargs
            Extra keyword-value pair arguments to pass to
            :meth:`SupplyCurve.compute_total_lcoe`. Should **NOT**
            include ``trans_table``.

        Returns
        -------
        supply_curve : pandas.DataFrame
            Updated sc_points table with transmission connections, LCOT
            and LCOE+LCOT based on full supply curve connections
        """
        all_cols = _get_connection_cols(columns, sort_on)
        self._reset_sc_capacities()

        if scale_with_capacity:
            conn_lists = self._connect_while_cap_available(
                trans_table, trans_features, all_cols, comp_wind_dirs,
                downwind, sort_on, fcr, connection_upper_limit, **kwargs)
        else:
            conn_lists = self._connect_while_cap_available_no_scale(
                trans_table, trans_features, all_cols, comp_wind_dirs,
                downwind, connection_upper_limit)

        if max_cap_tie_in_cost_per_mw:
            conn_lists = self._connect_at_max_cap(conn_lists, all_cols,
                                                  comp_wind_dirs,
                                                  downwind, fcr, sort_on,
                                                  max_cap_tie_in_cost_per_mw,
                                                  scale_with_capacity,
                                                  connection_upper_limit,
                                                  **kwargs)

        _warn_about_unconnected_gids(self._sc_capacities)

        return self._merge_sc_with_connections(columns, conn_lists, sort_on)

    def _reset_sc_capacities(self):
        """Reset SC caps to have max SC point capacities for each SC GID"""
        self._sc_capacities[:] = 0
        sc_pt_capacities = self._sc_points.set_index(SupplyCurveField.SC_GID)
        sc_pt_capacities = sc_pt_capacities[self._sc_capacity_col]
        for gid, cap in sc_pt_capacities.to_dict().items():
            self._sc_capacities[gid] = cap

    def _check_feature_capacity(self, avail_cap_frac=1):
        """
        Add the transmission connection feature capacity to the trans table if
        needed
        """
        if SupplyCurveField.TRANS_CAPACITY not in self._trans_table:
            kwargs = {"avail_cap_frac": avail_cap_frac}
            fc = TF.feature_capacity(self._trans_table, **kwargs)
            self._trans_table = self._trans_table.merge(
                fc, on=SupplyCurveField.TRANS_GID)

    def _connect_while_cap_available(self, trans_table, trans_features,
                                     all_cols, comp_wind_dirs, downwind,
                                     sort_on, fcr,
                                     connection_upper_limit=None, **kwargs):
        """Connect SC points to trans features that have available capacity"""
        connected = 0
        progress = 0
        conn_lists = {k: [] for k in all_cols}
        conn_lists[self._sc_capacity_col] = []

        i = 0
        while self._sc_capacities.any() and len(trans_table) > 0:
            logger.debug("Entering while loop with {:,.2f} MW of capacity "
                         "still to connect and {:,d} possible connections"
                         .format(self._sc_capacities.sum(), len(trans_table)))
            i += 1
            if i > 1e7:
                raise RuntimeError("Too many iterations while connecting "
                                   "supply curve points!")

            trans_table, row, sc_gid, trans_gid = _best_connection(
                trans_table, sort_on)

            if not trans_features.check_availability(trans_gid):
                trans_table = _remove_trans_gid(trans_table, trans_gid)
                continue

            cap_remaining = self._determine_cap_to_connect(
                conn_lists, sc_gid, connection_upper_limit)

            if cap_remaining < 0:
                logger.info("Total capacity limit of %.2f MW reached, "
                            "stopping connection procedure",
                            connection_upper_limit)
                break
            elif np.isclose(cap_remaining, 0):
                logger.debug("No remaining capacity found for sc_gid %d",
                             sc_gid)
                mask = trans_table[SupplyCurveField.SC_GID] != sc_gid
                trans_table = trans_table[mask].copy()
                continue

            logger.debug("Examining SC GID {} connected to Transmission GID {}"
                         .format(sc_gid, trans_gid))

            cap_connected = trans_features.connect(trans_gid, cap_remaining)
            if cap_connected <= 0:
                continue

            connected += 1
            logger.debug("Connecting sc gid {} to trans gid {}: {:.2f} MW"
                         .format(sc_gid, trans_gid, cap_connected))
            self._sc_capacities[sc_gid] -= cap_connected

            self._track_connection(all_cols, conn_lists, row, sc_gid,
                                   cap_connected, downwind, comp_wind_dirs)

            current_prog = connected // (len(self) / 100)
            if current_prog > progress:
                progress = current_prog
                logger.info("{} % of supply curve points connected"
                            .format(progress))

            if self._sc_capacities[sc_gid] <= 0:
                trans_table = _remove_sc_gid(trans_table, sc_gid)

            trans_table = self._update_costs_new_capacity(
                trans_table, sc_gid, trans_gid, cap_connected,
                fcr, **kwargs)

        return conn_lists

    def _update_costs_new_capacity(self, trans_table, sc_gid, trans_gid,
                                   cap_connected, fcr, **kwargs):
        """Update TX costs based on remaining capacity to connect"""
        mask = ((trans_table[SupplyCurveField.TRANS_GID] == trans_gid)
                | (trans_table[SupplyCurveField.SC_GID] == sc_gid))
        new_tt = trans_table[mask].copy()

        new_tt = _update_remaining_cap_trans_feature(new_tt, trans_gid,
                                                     cap_connected)

        new_tt = _update_remaining_cap_sc_gid(new_tt, sc_gid,
                                              self._sc_capacities[sc_gid],
                                              self._sc_capacity_col)

        if self._poi_info is not None:
            new_tt = _add_tcc_mw_for_poi(new_tt, self._poi_info)
        elif "trans_cap_cost" in trans_table:
            tcc_per_mw_col = SupplyCurveField.TOTAL_TRANS_CAP_COST_PER_MW
            new_tt = new_tt.drop(columns=tcc_per_mw_col, errors="ignore")
        else:  # originally had trans cap cost per MW input, so don't scale
            return trans_table

        new_costs = self.compute_total_lcoe(fcr=fcr, trans_table=new_tt,
                                            **kwargs)
        return pd.concat([trans_table[~mask], new_costs])

    def _connect_at_max_cap(self, conn_lists, all_cols,
                            comp_wind_dirs, downwind, fcr, sort_on,
                            max_cap_tie_in_cost_per_mw=None,
                            scale_with_capacity=False,
                            connection_upper_limit=None,
                            **kwargs):
        """Connect SC points to trans features beyond max capacity"""
        if not self._sc_capacities.any():
            return conn_lists

        tt = self._get_max_cap_tt(scale_with_capacity=scale_with_capacity)
        tt = max_tcc_per_mw_for_poi(tt, max_cap_tie_in_cost_per_mw)
        tt = self.compute_total_lcoe(fcr=fcr, trans_table=tt, **kwargs)
        tt = tt.sort_values(sort_on)
        zero_cap_gids = set()
        for ind, (__, row) in enumerate(tt.iterrows()):
            sc_gid = row[SupplyCurveField.SC_GID]
            if sc_gid in zero_cap_gids:
                continue

            cap_remaining = self._determine_cap_to_connect(
                conn_lists, sc_gid, connection_upper_limit)

            if cap_remaining < 0:
                logger.info("Total capacity limit of %.2f MW reached, "
                            "stopping connection procedure",
                            connection_upper_limit)
                break
            elif np.isclose(cap_remaining, 0):
                logger.debug("No remaining capacity found for sc_gid %d",
                             sc_gid)
                zero_cap_gids.add(sc_gid)
                continue

            if sc_gid not in self._sc_gids:
                logger.debug("SC GID {} (capacity {:.2f}) has no possible "
                             "connections; cannot connect at max-capacity "
                             "cost value"
                             .format(sc_gid, cap_remaining))
                continue

            logger.debug("Connecting SC GID {} at max cap ({:,d}/{:,d})"
                         .format(sc_gid, ind + 1, len(self._trans_table)))
            mask = tt[SupplyCurveField.SC_GID] == sc_gid
            sc_tt = tt[mask].copy()

            row = sc_tt.iloc[sc_tt[sort_on].argmin(skipna=True)]
            self._sc_capacities[sc_gid] = 0

            self._track_connection(all_cols, conn_lists, row, sc_gid,
                                   cap_remaining, downwind, comp_wind_dirs)

        return conn_lists

    def _connect_while_cap_available_no_scale(self, trans_table,
                                              trans_features, all_cols,
                                              comp_wind_dirs, downwind,
                                              connection_upper_limit=None):
        """Connect SC points to trans features that have available capacity"""
        connected = 0
        progress = 0
        conn_lists = {k: [] for k in all_cols}
        conn_lists[self._sc_capacity_col] = []

        for __, row in trans_table.iterrows():
            sc_gid = row[SupplyCurveField.SC_GID]
            cap_remaining = self._determine_cap_to_connect(
                conn_lists, sc_gid, connection_upper_limit)

            if cap_remaining < 0:
                logger.info("Total capacity limit of %.2f MW reached, "
                            "stopping connection procedure",
                            connection_upper_limit)
                break
            elif np.isclose(cap_remaining, 0):
                logger.debug("No remaining capacity found for sc_gid %d",
                             sc_gid)
                continue

            trans_gid = row[SupplyCurveField.TRANS_GID]
            cap_connected = trans_features.connect(trans_gid, cap_remaining)
            if cap_connected <= 0:
                continue

            connected += 1
            logger.debug("Connecting sc gid {} to trans gid {}: {:.2f} MW"
                         .format(sc_gid, trans_gid, cap_connected))
            self._sc_capacities[sc_gid] -= cap_connected

            self._track_connection(all_cols, conn_lists, row, sc_gid,
                                   cap_connected, downwind, comp_wind_dirs)

            current_prog = connected // (len(self) / 100)
            if current_prog > progress:
                progress = current_prog
                logger.info("{} % of supply curve points connected"
                            .format(progress))

        return conn_lists

    def _track_connection(self, all_cols, conn_lists, row, sc_gid,
                          cap_connected, downwind, comp_wind_dirs):
        """Add and track information about connected capacity"""
        for col in all_cols:
            conn_lists[col].append(row[col])

        conn_lists[self._sc_capacity_col].append(cap_connected)

        if comp_wind_dirs is not None:
            comp_wind_dirs = (
                self._exclude_noncompetitive_wind_farms(
                    comp_wind_dirs, sc_gid, downwind=downwind
                )
            )

    def _get_max_cap_tt(self, scale_with_capacity):
        """Get transmission table for max capacity connections"""
        tt = self._trans_table.copy()
        if scale_with_capacity:
            logger.debug("Scaling cost with remaining capacities...")
            sc_gids = np.where(self._sc_capacities)[0].tolist()
            for sc_gid in sc_gids:
                cap_remaining = self._sc_capacities[sc_gid]
                mask = tt[SupplyCurveField.SC_GID] == sc_gid
                tt.loc[mask, SupplyCurveField.CAPACITY_AC_MW] = cap_remaining
        return tt

    def _determine_cap_to_connect(self, conn_lists, sc_gid,
                                  connection_upper_limit=None):
        """Determine how much of the points capacity is left to connect"""

        if not connection_upper_limit:
            return max(0, self._sc_capacities[sc_gid])

        connected_cap = sum(conn_lists[self._sc_capacity_col])
        if connected_cap >= connection_upper_limit:
            return -1

        cap_remaining = min(self._sc_capacities[sc_gid],
                            connection_upper_limit - connected_cap)
        return max(0, cap_remaining)

    def _merge_sc_with_connections(self, columns, conn_lists, sort_on):
        """Merge connections and SC for output"""
        connections = pd.DataFrame(conn_lists).dropna(subset=[sort_on])

        keep_for_merge_cols = list(columns)
        if self._sc_capacity_col not in keep_for_merge_cols:
            keep_for_merge_cols.append(self._sc_capacity_col)

        to_drop = [str(col) for col in keep_for_merge_cols
                   if col in self._sc_points.columns]
        sc_points = self._sc_points.drop(columns=to_drop)

        if SupplyCurveField.SC_GID not in keep_for_merge_cols:
            keep_for_merge_cols.append(SupplyCurveField.SC_GID)

        supply_curve = sc_points.merge(connections[keep_for_merge_cols],
                                       on=SupplyCurveField.SC_GID)
        return supply_curve.reset_index(drop=True)

    def _adjust_output_columns(self, columns, consider_friction):
        """Add extra output columns, if needed."""

        for col in _REQUIRED_COMPUTE_AND_OUTPUT_COLS:
            if col not in columns:
                columns.append(col)

        for col in _REQUIRED_OUTPUT_COLS:
            if col not in self._trans_table:
                self._trans_table[col] = np.nan
            if col not in columns:
                columns.append(col)

        missing_cols = [col for col in columns if col not in self._trans_table]
        if missing_cols:
            msg = (f"The following requested columns are not found in "
                   f"transmission table: {missing_cols}.\nSkipping...")
            logger.warning(msg)
            warn(msg)

        columns = [col for col in columns if col in self._trans_table]

        fric_col = SupplyCurveField.TOTAL_LCOE_FRICTION
        if consider_friction and fric_col in self._trans_table:
            columns.append(fric_col)

        return sorted(columns, key=_column_sort_key)

    def _determine_sort_on(self, sort_on):
        """Determine the `sort_on` column from user input and trans table"""
        r_cost_col = SupplyCurveField.REINFORCEMENT_COST_PER_MW
        found_reinforcement_costs = (
            r_cost_col in self._trans_table
            and not self._trans_table[r_cost_col].isna().all()
        )
        if found_reinforcement_costs:
            sort_on = sort_on or "lcoe_no_reinforcement"
        return sort_on or SupplyCurveField.TOTAL_LCOE

    def full_sort(
        self,
        fcr,
        transmission_costs=None,
        avail_cap_frac=1,
        line_limited=False,
        connectable=True,
        max_workers=None,
        consider_friction=True,
        sort_on=None,
        columns=(
            SupplyCurveField.TRANS_GID,
            SupplyCurveField.TRANS_CAPACITY,
            SupplyCurveField.TRANS_TYPE,
            SupplyCurveField.TOTAL_TRANS_CAP_COST_PER_MW,
            SupplyCurveField.DIST_SPUR_KM,
            SupplyCurveField.LCOT,
            SupplyCurveField.TOTAL_LCOE,
        ),
        wind_dirs=None,
        n_dirs=2,
        downwind=False,
        offshore_compete=False,
    ):
        """
        run full supply curve sorting

        Parameters
        ----------
        fcr : float
            Fixed charge rate, used to compute LCOT
        transmission_costs : str | dict, optional
            Transmission feature costs to use with TransmissionFeatures
            handler: line_tie_in_cost, line_cost, station_tie_in_cost,
            center_tie_in_cost, sink_tie_in_cost, by default None
        avail_cap_frac : int, optional
            Fraction of transmissions features capacity 'ac_cap' to make
            available for connection to supply curve points, by default 1
        line_limited : bool, optional
            Flag to have substation connection is limited by maximum capacity
            of the attached lines, legacy method, by default False
        connectable : bool, optional
            Flag to only compute transmission capital cost if transmission
            feature has enough available capacity, by default True
        max_workers : int | NoneType, optional
            Number of workers to use to compute lcot, if > 1 run in parallel.
            None uses all available cpu's. by default None
        consider_friction : bool, optional
            Flag to consider friction layer on LCOE when "mean_lcoe_friction"
            is in the sc points input, by default True
        sort_on : str, optional
            Column label to sort the Supply Curve table on. This affects the
            build priority - connections with the lowest value in this column
            will be built first, by default `None`, which will use
            total LCOE without any reinforcement costs as the sort value.
        columns : list | tuple, optional
            Columns to preserve in output connections dataframe,
            by default ('trans_gid', 'trans_capacity', 'trans_type',
            'trans_cap_cost_per_mw', 'dist_km', 'lcot', 'total_lcoe')
        wind_dirs : pandas.DataFrame | str, optional
            path to .csv or reVX.wind_dirs.wind_dirs.WindDirs output with
            the neighboring supply curve point gids and power-rose value at
            each cardinal direction, by default None
        n_dirs : int, optional
            Number of prominent directions to use, by default 2
        downwind : bool, optional
            Flag to remove downwind neighbors as well as upwind neighbors,
            by default False
        offshore_compete : bool, default
            Flag as to whether offshore farms should be included during
            CompetitiveWindFarms, by default False

        Returns
        -------
        supply_curve : pandas.DataFrame
            Updated sc_points table with transmission connections, LCOT
            and LCOE+LCOT based on full supply curve connections
        """
        logger.info("Starting full competitive supply curve sort.")
        self._check_substation_conns(self._trans_table)
        self.compute_total_lcoe(
            fcr,
            transmission_costs=transmission_costs,
            avail_cap_frac=avail_cap_frac,
            line_limited=line_limited,
            connectable=connectable,
            max_workers=max_workers,
            consider_friction=consider_friction,
        )
        self._check_feature_capacity(avail_cap_frac=avail_cap_frac)

        if isinstance(columns, tuple):
            columns = list(columns)

        columns = self._adjust_output_columns(columns, consider_friction)
        sort_on = self._determine_sort_on(sort_on)

        trans_table = self._trans_table.copy()
        pos = trans_table[SupplyCurveField.LCOT].isnull()
        trans_table = trans_table.loc[~pos].sort_values(
            [sort_on, SupplyCurveField.TRANS_GID]
        )

        comp_wind_dirs = None
        if wind_dirs is not None:
            msg = "Excluding {} upwind".format(n_dirs)
            if downwind:
                msg += " and downwind"

            msg += " onshore"
            if offshore_compete:
                msg += " and offshore"

            msg += " windfarms"
            logger.info(msg)
            comp_wind_dirs = CompetitiveWindFarms(
                wind_dirs,
                self._sc_points,
                n_dirs=n_dirs,
                offshore=offshore_compete,
            )

        trans_features = self._create_handler(
            self._trans_table,
            trans_costs=transmission_costs,
            avail_cap_frac=avail_cap_frac,
        )

        supply_curve = self._full_sort(
            trans_table,
            trans_features,
            fcr,
            comp_wind_dirs=comp_wind_dirs,
            sort_on=sort_on,
            columns=columns,
            downwind=downwind,
            transmission_costs=transmission_costs,
            avail_cap_frac=avail_cap_frac,
            line_limited=line_limited,
            connectable=connectable,
            max_workers=max_workers,
            consider_friction=consider_friction,
            max_cap_tie_in_cost_per_mw=None,  # no conns after max cap
        )

        return supply_curve

    def poi_sort(
        self,
        fcr,
        max_cap_tie_in_cost_per_mw=None,
        consider_friction=True,
        sort_on=None,
        scale_with_capacity=False,
        connection_upper_limit=None,
        columns=(
            SupplyCurveField.TRANS_GID,
            SupplyCurveField.TRANS_CAPACITY,
            SupplyCurveField.TRANS_TYPE,
            SupplyCurveField.TOTAL_TRANS_CAP_COST_PER_MW,
            SupplyCurveField.DIST_SPUR_KM,
            SupplyCurveField.LCOT,
            SupplyCurveField.TOTAL_LCOE,
        ),
    ):
        """
        run POI-based supply curve sorting

        Parameters
        ----------
        fcr : float
            Fixed charge rate, used to compute LCOT
        max_cap_tie_in_cost_per_mw : float, optional
            Cost to tie into a POI after it has reached maximum
            capacity. If you don't want to allow connections after the
            POI capacity is reached, leave this input unspecified.
            By default, ``None``.
        consider_friction : bool, optional
            Flag to consider friction layer on LCOE when
            ``"mean_lcoe_friction"`` is in the sc points input.
            By default, ``True``.
        sort_on : str, optional
            Column label to sort the Supply Curve table on. This affects
            the build priority - connections with the lowest value in
            this column will be built first. By default, ``None``, which
            will use total LCOE without any reinforcement costs as the
            sort value.
        scale_with_capacity : bool, default=False
            Option to scale the costs as capacity changes. If ``False``,
            costs are only computed once at the beginning of the sort.
            If ``True``, costs are re-computed as parts of a plant are
            connected, leaving the remainder of the plant capacity with
            higher connection costs (since new lines have to be built
            for a smaller amount of capacity). By default, ``False``.
        connection_upper_limit : int | float, optional
            Optional upper limit for total capacity (MW). If specified,
            the sort will stop when this amount of capacity has been
            connected. By default, ``None`` which does not impose any
            limits.
        columns : list | tuple, optional
            Columns to preserve in output connections dataframe,
            by default ('trans_gid', 'trans_capacity', 'trans_type',
            'trans_cap_cost_per_mw', 'dist_km', 'lcot', 'total_lcoe')

        Returns
        -------
        supply_curve : pandas.DataFrame
            Updated sc_points table with POI transmission connections,
            LCOT and LCOE+LCOT based on POI supply curve connections.
        """
        logger.info("Starting POI-based supply curve sort.")

        msg = "Must set poi_info before running poi_sort"
        assert self._poi_info is not None, msg
        self._trans_table = _add_tcc_mw_for_poi(self._trans_table,
                                                self._poi_info)

        self.compute_total_lcoe(fcr)

        self._trans_table = self._trans_table.rename(
            columns={"length_km": SupplyCurveField.DIST_SPUR_KM})
        self._check_feature_capacity()

        if isinstance(columns, tuple):
            columns = list(columns)

        columns = self._adjust_output_columns(columns, consider_friction)
        sort_on = self._determine_sort_on(sort_on)
        trans_table = self._trans_table.copy()

        no_lcot_mask = trans_table[SupplyCurveField.LCOT].isnull()
        no_ac_cap_mask = trans_table["ac_cap"] <= 0
        final_mask = ~(no_lcot_mask | no_ac_cap_mask)
        trans_table = trans_table.loc[final_mask].sort_values(
            [sort_on, SupplyCurveField.TRANS_GID]
        )

        trans_features = PF(self._poi_info)

        supply_curve = self._full_sort(
            trans_table,
            trans_features,
            fcr,
            sort_on=sort_on,
            columns=columns,
            comp_wind_dirs=None,
            downwind=False,
            max_cap_tie_in_cost_per_mw=max_cap_tie_in_cost_per_mw,
            scale_with_capacity=scale_with_capacity,
            connection_upper_limit=connection_upper_limit,
        )

        return supply_curve

    def simple_sort(
        self,
        fcr,
        transmission_costs=None,
        avail_cap_frac=1,
        max_workers=None,
        consider_friction=True,
        sort_on=None,
        columns=DEFAULT_COLUMNS,
        wind_dirs=None,
        n_dirs=2,
        downwind=False,
        offshore_compete=False,
    ):
        """
        Run simple supply curve sorting that does not take into account
        available capacity

        Parameters
        ----------
        fcr : float
            Fixed charge rate, used to compute LCOT
        transmission_costs : str | dict, optional
            Transmission feature costs to use with TransmissionFeatures
            handler: line_tie_in_cost, line_cost, station_tie_in_cost,
            center_tie_in_cost, sink_tie_in_cost, by default None
        avail_cap_frac : int, optional
            Fraction of transmissions features capacity 'ac_cap' to make
            available for connection to supply curve points, by default 1
        line_limited : bool, optional
            Flag to have substation connection is limited by maximum capacity
            of the attached lines, legacy method, by default False
        connectable : bool, optional
            Flag to only compute tranmission capital cost if transmission
            feature has enough available capacity, by default True
        max_workers : int | NoneType, optional
            Number of workers to use to compute lcot, if > 1 run in parallel.
            None uses all available cpu's. by default None
        consider_friction : bool, optional
            Flag to consider friction layer on LCOE when "mean_lcoe_friction"
            is in the sc points input, by default True
        sort_on : str, optional
            Column label to sort the Supply Curve table on. This affects the
            build priority - connections with the lowest value in this column
            will be built first, by default `None`, which will use
            total LCOE without any reinforcement costs as the sort value.
        columns : list | tuple, optional
            Columns to preserve in output connections dataframe.
            By default, :obj:`DEFAULT_COLUMNS`.
        wind_dirs : pandas.DataFrame | str, optional
            path to .csv or reVX.wind_dirs.wind_dirs.WindDirs output with
            the neighboring supply curve point gids and power-rose value at
            each cardinal direction, by default None
        n_dirs : int, optional
            Number of prominent directions to use, by default 2
        downwind : bool, optional
            Flag to remove downwind neighbors as well as upwind neighbors
        offshore_compete : bool, default
            Flag as to whether offshore farms should be included during
            CompetitiveWindFarms, by default False

        Returns
        -------
        supply_curve : pandas.DataFrame
            Updated sc_points table with transmission connections, LCOT
            and LCOE+LCOT based on simple supply curve connections
        """
        logger.info("Starting simple supply curve sort (no capacity limits).")
        self.compute_total_lcoe(
            fcr,
            transmission_costs=transmission_costs,
            avail_cap_frac=avail_cap_frac,
            connectable=False,
            max_workers=max_workers,
            consider_friction=consider_friction,
        )
        sort_on = self._determine_sort_on(sort_on)

        if isinstance(columns, tuple):
            columns = list(columns)
        columns = self._adjust_output_columns(columns, consider_friction)

        trans_table = self._trans_table.copy()
        connections = trans_table.sort_values(
            [sort_on, SupplyCurveField.TRANS_GID])
        connections = connections.groupby(SupplyCurveField.SC_GID).first()
        connections = connections[columns].reset_index()

        supply_curve = self._sc_points.merge(connections,
                                             on=SupplyCurveField.SC_GID)
        if wind_dirs is not None:
            supply_curve = CompetitiveWindFarms.run(
                wind_dirs,
                supply_curve,
                n_dirs=n_dirs,
                offshore=offshore_compete,
                sort_on=sort_on,
                downwind=downwind,
            )

        supply_curve = supply_curve.reset_index(drop=True)

        return supply_curve

    def run_poi(
        self,
        out_fpath,
        fixed_charge_rate,
        max_cap_tie_in_cost_per_mw=None,
        scale_with_capacity=False,
        consider_friction=True,
        sort_on=None,
        columns=DEFAULT_COLUMNS,
        competition=None,
    ):
        """Run POI Supply Curve sort calculations

        Run full POI-base supply curve transmission sort taking into
        account available capacity of transmission features and POI's
        when making connections.

        Parameters
        ----------
        out_fpath : str
            Full path to output CSV file. Does not need to include file
            ending - it will be added automatically if missing.
        fixed_charge_rate : float
            Fixed charge rate, (in decimal form: 5% = 0.05). This value
            is used to compute LCOT.
        max_cap_tie_in_cost_per_mw : float, optional
            Cost to tie into a POI after it has reached maximum
            capacity. If you don't want to allow connections after the
            POI capacity is reached, leave this input unspecified.
            By default, ``None``.
        scale_with_capacity : bool, default=False
            Option to scale the costs as capacity changes. If ``False``,
            costs are only computed once at the beginning of the sort.
            If ``True``, costs are re-computed as parts of a plant are
            connected, leaving the remainder of the plant capacity with
            higher connection costs (since new lines have to be built
            for a smaller amount of capacity). By default, ``False``.
        consider_friction : bool, optional
            Flag to add a new ``"total_lcoe_friction"`` column to the
            supply curve output that contains the sum of the computed
            ``"total_lcoe"`` value and the input
            ``"mean_lcoe_friction"`` values. If ``"mean_lcoe_friction"``
            is not in the `sc_points` input, this option is ignored.
            By default, ``True``.
        sort_on : str, optional
            Column label to sort the supply curve table on. This affects
            the build priority when doing a "full" sort - connections
            with the lowest value in this column will be built first.
            For a "simple" sort, only connections with the lowest value
            in this column will be considered. If ``None``, the sort is
            performed on the total LCOE *without* any reinforcement
            costs added (this is typically what you want - it avoids
            unrealistically long spur-line connections).
            By default ``None``.
        columns : list | tuple, optional
            Columns to preserve in output supply curve dataframe.
            By default, :obj:`DEFAULT_COLUMNS`.
        competition : dict, optional
            Optional dictionary of arguments for competitive wind farm
            exclusions, which removes supply curve points upwind (and
            optionally downwind) of the lowest LCOE supply curves.
            If ``None``, no competition is applied. Otherwise, this
            dictionary can have up to four keys:

                - ``wind_dirs`` (required) : A path to a CSV file or
                  :py:class:`reVX ProminentWindDirections
                  <reVX.wind_dirs.prominent_wind_dirs.ProminentWindDirections>`
                  output with the neighboring supply curve point gids
                  and power-rose values at each cardinal direction.
                - ``n_dirs`` (optional) : An integer representing the
                  number of prominent directions to use during wind farm
                  competition. By default, ``2``.
                - ``downwind`` (optional) : A flag indicating that
                  downwind neighbors should be removed in addition to
                  upwind neighbors during wind farm competition.
                  By default, ``False``.
                - ``offshore_compete`` (optional) : A flag indicating
                  that offshore farms should be included during wind
                  farm competition. By default, ``False``.

            By default ``None``.

        Returns
        -------
        str
            Path to output supply curve.
        """
        kwargs = {
            "fcr": fixed_charge_rate,
            "consider_friction": consider_friction,
            "sort_on": sort_on,
            "columns": columns,
            "scale_with_capacity": scale_with_capacity,
            "max_cap_tie_in_cost_per_mw": max_cap_tie_in_cost_per_mw,
        }
        kwargs.update(competition or {})
        supply_curve = self.poi_sort(**kwargs)
        out_fpath = _format_sc_out_fpath(out_fpath)
        supply_curve.to_csv(out_fpath, index=False)
        return out_fpath

    def run(
        self,
        out_fpath,
        fixed_charge_rate,
        simple=True,
        avail_cap_frac=1,
        line_limited=False,
        transmission_costs=None,
        consider_friction=True,
        sort_on=None,
        columns=DEFAULT_COLUMNS,
        max_workers=None,
        competition=None,
    ):
        """Run Supply Curve Transmission calculations.

        Run full supply curve taking into account available capacity of
        transmission features when making connections.

        Parameters
        ----------
        out_fpath : str
            Full path to output CSV file. Does not need to include file
            ending - it will be added automatically if missing.
        fixed_charge_rate : float
            Fixed charge rate, (in decimal form: 5% = 0.05). This value
            is used to compute LCOT.
        simple : bool, optional
            Option to run the simple sort (does not keep track of
            capacity available on the existing transmission grid). If
            ``False``, a full transmission sort (where connections are
            limited based on available transmission capacity) is run.
            Note that the full transmission sort requires the
            `avail_cap_frac` and `line_limited` inputs.
            By default, ``True``.
        avail_cap_frac : int, optional
            This input has no effect if ``simple=True``. Fraction of
            transmissions features capacity ``ac_cap`` to make available
            for connection to supply curve points. By default, ``1``.
        line_limited : bool, optional
            This input has no effect if ``simple=True``. Flag to have
            substation connection limited by maximum capacity
            of the attached lines. This is a legacy method.
            By default, ``False``.
        transmission_costs : str | dict, optional
            Dictionary of transmission feature costs or path to JSON
            file containing a dictionary of transmission feature costs.
            These costs are used to compute transmission capital cost
            if the input transmission tables do not have a
            ``"trans_cap_cost"`` column (this input is ignored
            otherwise). The dictionary must include:

                - line_tie_in_cost
                - line_cost
                - station_tie_in_cost
                - center_tie_in_cost
                - sink_tie_in_cost

            By default, ``None``.
        consider_friction : bool, optional
            Flag to add a new ``"total_lcoe_friction"`` column to the
            supply curve output that contains the sum of the computed
            ``"total_lcoe"`` value and the input
            ``"mean_lcoe_friction"`` values. If ``"mean_lcoe_friction"``
            is not in the `sc_points` input, this option is ignored.
            By default, ``True``.
        sort_on : str, optional
            Column label to sort the supply curve table on. This affects
            the build priority when doing a "full" sort - connections
            with the lowest value in this column will be built first.
            For a "simple" sort, only connections with the lowest value
            in this column will be considered. If ``None``, the sort is
            performed on the total LCOE *without* any reinforcement
            costs added (this is typically what you want - it avoids
            unrealistically long spur-line connections).
            By default ``None``.
        columns : list | tuple, optional
            Columns to preserve in output supply curve dataframe.
            By default, :obj:`DEFAULT_COLUMNS`.
        max_workers : int, optional
            Number of workers to use to compute LCOT. If > 1,
            computation is run in parallel. If ``None``, computation
            uses all available CPU's. By default, ``None``.
        competition : dict, optional
            Optional dictionary of arguments for competitive wind farm
            exclusions, which removes supply curve points upwind (and
            optionally downwind) of the lowest LCOE supply curves.
            If ``None``, no competition is applied. Otherwise, this
            dictionary can have up to four keys:

                - ``wind_dirs`` (required) : A path to a CSV file or
                  :py:class:`reVX ProminentWindDirections
                  <reVX.wind_dirs.prominent_wind_dirs.ProminentWindDirections>`
                  output with the neighboring supply curve point gids
                  and power-rose values at each cardinal direction.
                - ``n_dirs`` (optional) : An integer representing the
                  number of prominent directions to use during wind farm
                  competition. By default, ``2``.
                - ``downwind`` (optional) : A flag indicating that
                  downwind neighbors should be removed in addition to
                  upwind neighbors during wind farm competition.
                  By default, ``False``.
                - ``offshore_compete`` (optional) : A flag indicating
                  that offshore farms should be included during wind
                  farm competition. By default, ``False``.

            By default ``None``.

        Returns
        -------
        str
            Path to output supply curve.
        """
        kwargs = {
            "fcr": fixed_charge_rate,
            "transmission_costs": transmission_costs,
            "consider_friction": consider_friction,
            "sort_on": sort_on,
            "columns": columns,
            "max_workers": max_workers,
        }
        kwargs.update(competition or {})

        if simple:
            supply_curve = self.simple_sort(**kwargs)
        else:
            kwargs["avail_cap_frac"] = avail_cap_frac
            kwargs["line_limited"] = line_limited
            supply_curve = self.full_sort(**kwargs)

        out_fpath = _format_sc_out_fpath(out_fpath)
        supply_curve.to_csv(out_fpath, index=False)

        return out_fpath


def _format_sc_out_fpath(out_fpath):
    """Add CSV file ending and replace underscore, if necessary."""
    if not out_fpath.endswith(".csv"):
        out_fpath = "{}.csv".format(out_fpath)

    project_dir, out_fn = os.path.split(out_fpath)
    out_fn = out_fn.replace("supply_curve", "supply-curve")
    out_fn = out_fn.replace("poi_sort", "poi-sort")
    return os.path.join(project_dir, out_fn)


def _column_sort_key(col):
    """Determine the sort order of the input column. """
    col_value = _REQUIRED_COMPUTE_AND_OUTPUT_COLS.get(col)
    if col_value is None:
        col_value = _REQUIRED_OUTPUT_COLS.get(col)
    if col_value is None:
        col_value = 1e6

    return col_value, str(col)


def _get_connection_cols(columns, sort_on):
    """Get user cols + essential connection output columns"""
    all_cols = list(columns)
    essentials = [SupplyCurveField.SC_GID,
                  SupplyCurveField.TRANS_GID,
                  SupplyCurveField.TRANS_CAPACITY,
                  SupplyCurveField.TRANS_TYPE,
                  SupplyCurveField.DIST_SPUR_KM,
                  SupplyCurveField.TOTAL_TRANS_CAP_COST_PER_MW,
                  SupplyCurveField.LCOT,
                  SupplyCurveField.TOTAL_LCOE,
                  sort_on]

    for col in essentials:
        if col not in all_cols:
            all_cols.append(col)

    return list(map(str, all_cols))


def _warn_about_unconnected_gids(remaining_capacities):
    """If any values in `remaining_capacities` are non-zero, throw warning"""
    unconnected_sc_gids = np.where(remaining_capacities)[0].tolist()
    if unconnected_sc_gids:
        msg = (
            "{} supply curve points were not fully connected to transmission! "
            "Unconnected sc_gid's: {}".format(
                len(unconnected_sc_gids), unconnected_sc_gids
            )
        )
        logger.warning(msg)
        warn(msg)


def _add_tcc_mw_for_poi(trans_table, poi_info):
    """Add transmission capital cost per MW using POI info"""
    connectable_capacity = np.minimum(
        trans_table[SupplyCurveField.CAPACITY_AC_MW], trans_table["ac_cap"])
    tie_line_cost_per_mw = trans_table["cost"] / connectable_capacity

    tie_in_cost_per_mw = (
        trans_table[[SupplyCurveField.TRANS_GID]].merge(
            poi_info[[SupplyCurveField.TRANS_GID, "POI_cost_MW"]],
            on=SupplyCurveField.TRANS_GID
        )["POI_cost_MW"])

    tcc_per_mw_col = SupplyCurveField.TOTAL_TRANS_CAP_COST_PER_MW
    trans_table[tcc_per_mw_col] = (tie_line_cost_per_mw.to_numpy()
                                   + tie_in_cost_per_mw.to_numpy())
    return trans_table


def max_tcc_per_mw_for_poi(trans_table, max_cap_tie_in_cost_per_mw):
    """Add transmission capital cost per MW at max capacity using POI info"""
    logger.debug("Adding extra connections at max capacity for "
                 "{:,.2f} $/MW".format(max_cap_tie_in_cost_per_mw))

    extra_conns = (trans_table.sort_values("cost")
                   .groupby(SupplyCurveField.SC_GID).first()
                   .reset_index())

    tie_line_cost_per_mw = (extra_conns["cost"]
                            / extra_conns[SupplyCurveField.CAPACITY_AC_MW])

    tcc_per_mw_col = SupplyCurveField.TOTAL_TRANS_CAP_COST_PER_MW
    extra_conns[tcc_per_mw_col] = (tie_line_cost_per_mw
                                   + max_cap_tie_in_cost_per_mw)
    return extra_conns


def _update_remaining_cap_trans_feature(trans_table, trans_gid, cap_connected):
    """Update remaining capacity for transmission feature after connection"""
    conn_mask = trans_table[SupplyCurveField.TRANS_GID] == trans_gid
    trans_table["ac_cap"] = trans_table["ac_cap"].astype("float32")
    trans_table.loc[conn_mask, "ac_cap"] -= cap_connected
    trans_table.loc[conn_mask, "ac_cap"] = np.maximum(
        0, trans_table.loc[conn_mask, "ac_cap"])
    return trans_table


def _update_remaining_cap_sc_gid(trans_table, sc_gid, remaining_cap, cap_col):
    """Update remaining capacity for sc_gid feature after connection"""
    sc_mask = trans_table[SupplyCurveField.SC_GID] == sc_gid
    trans_table.loc[sc_mask, cap_col] = remaining_cap
    return trans_table


def _best_connection(trans_table, sort_on):
    """Get row with best connection based on `sort_on` input"""
    row = trans_table.iloc[trans_table[sort_on].argmin(skipna=True)]
    trans_table = trans_table.drop(index=row.name)
    sc_gid = row[SupplyCurveField.SC_GID]
    trans_gid = row[SupplyCurveField.TRANS_GID]
    return trans_table, row, sc_gid, trans_gid


def _remove_trans_gid(trans_table, trans_gid):
    """Remove a trans_gid from the transmission table"""
    mask = trans_table[SupplyCurveField.TRANS_GID] != trans_gid
    return trans_table[mask].copy()


def _remove_sc_gid(trans_table, sc_gid):
    """Remove an sc_gid from the transmission table"""
    mask = trans_table[SupplyCurveField.SC_GID] != sc_gid
    return trans_table[mask].copy()
